<!-- BEGIN POSTBUILD-CURRENT-RUN-AUTHORITY rev0089 -->
# `/run` post-build authority — rev0089

**Frozen Roadcase SHA-256:** `65df45a95bfa9d917a0053f4d81d1a4d317119945e3139746359eeb6269b58fd`  
**Roadcase bytes:** `6756931`  
**Determinism:** first, second, and independent third constructions are byte-identical.  
**Exact-final managed package preflight:** PASS, 15/15 checks in Chromium 144.0.7559.96.  
**Post-build runtime matrix:** 5 PASS / 1 BLOCKED / 4 NOT RUN / 0 NOT ESTABLISHED.  
**Evidence bundle SHA-256:** `b81e14716f79ad62bdd6a37cb2260bd0d8e3c8a6d4d7fb54f1013665c6e19814` (71 manifested files; independently verified).  
**Policy:** bounded override declared; original 1,393-byte policy restored byte-identically.  
**Release gate:** open.

## Highest priority

1. Capture a fresh official channel source set on the actual target host.
2. Prepare from this exact Roadcase; a passing attempt must begin within 24 hours of capture.
3. Run and independently verify all 18 cases in unmanaged then-current Chromium Stable (`156.0.8078.47` at the frozen capture).
4. Repeat independently in Firefox Release `158.0.1` and Firefox ESR `153.5.1esr`.
5. Keep temporary Firefox runtime evidence separate from signed-install permission-prompt evidence.
6. Only after the browser triad passes, run unfamiliar-person, sender/recipient privacy, and real assistive-technology fieldwork.

The managed Chromium 144 seal establishes exact-package compatibility only. It does not satisfy current-channel, unmanaged, human, accessibility, assistive-technology, or comprehension gates.

<!-- END POSTBUILD-CURRENT-RUN-AUTHORITY rev0089 -->

<!-- BEGIN CURRENT-RUN-AUTHORITY rev0089-channel-binding -->
# `/run` authority — rev0089 Source Notes channel binding

**Current candidate:** `rev0089-source-notes-channel-binding`  
**Product lineage:** `rev0080` / `0.80.0`  
**Release gate:** open. Unavailable rev0081 and rev0082 remain unrecovered.

## What this turn closed

- Exact captured Chrome-for-Testing and Mozilla product-details JSON bytes are now first-class prepared-session and evidence-bundle inputs.
- Chromium Stable, Firefox Release, and Firefox ESR versions are derived from those bytes; a mismatched operator-entered version is refused.
- A passing result requires the snapshot not to postdate runtime start, a maximum age of 86,400 seconds, exact observed channel/version, and `currentChannelAtExecution=true`.
- The snapshot and both source payloads are deterministic statement subjects and are independently revalidated from the final evidence bundle.
- Fifteen channel/package/result/evidence tamper and classification tests pass.
- The capture remains unsigned and operator supplied; no authenticated fetch, source signature, trusted timestamp, operator identity, human presence, or unmanaged-state claim was added.

## P0.1 — freeze and exact-package seal

1. Build rev0089 twice, require byte equality, verify manifest bytes and executable modes, clean-extract, and replay the focused gate.
2. Keep the exact-final managed Chromium seal external to the immutable archive to avoid self-reference.
3. Record the frozen Roadcase digest, selected package digest, channel snapshot digest, actual Chromium 144 limitation, policy state, and every retry or interruption.
4. Do not promote that seal to current, unmanaged, human, Firefox, accessibility, or comprehension evidence.

## P0.2 — current browser triad

1. Immediately before each target run, capture exact official channel-source response bytes and generate a fresh channel-evidence directory.
2. Prepare from the same frozen rev0089 Roadcase. A pass must start within 24 hours of capture.
3. Run all 18 cases in unmanaged then-current Chromium Stable (`156.0.8078.47` at this capture), Firefox Release (`158.0.1`), and Firefox ESR (`153.5.1esr`).
4. Finalize and independently verify each bundle against the same Roadcase.
5. Compare channel, permission, native-artifact, and semantic-projection differences; never normalize platform differences silently.
6. Keep Firefox temporary-runtime evidence separate from signed-install permission-prompt evidence.

## P0.3 — unfamiliar people and real assistive technologies

After all three browser rows pass: test unfamiliar curator/recipient authorship, relationship-level and two-folder interpretation, publication/contact/scheduling/safety consequences, branch preservation, OPML loss, and divergent-copy decisions. Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions. Review sender and recipient privacy evidence separately. Make only the smallest correction supported by recurring independent wrong turns.

## P1 — delayed re-finding and organization

Test one-week delayed route re-finding before adding private labels or saved views. Keep folders human-curated and shareable, preserve **Unfiled**, and keep Source Notes outside engagement ranking or opaque recommendation systems. Do not expand them into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

Keep remote mode explicit and separate from loopback. Require TLS, persistent Node identity, bounded hosts/requests/artifacts/rates, expiring invitations, durable revocation evidence, and separation between public publication routes and private APIs. Begin with reviewed immutable-artifact retrieval. No default public bind, silent LAN discovery, or UPnP.

## Lab — bounded WebRTC courier

Transfer one reviewed immutable artifact; expose signaling/STUN/TURN; refuse replay, identity mismatch, digest mismatch, timeout, and partial completion; destroy the session afterward. Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

<!-- END CURRENT-RUN-AUTHORITY rev0089-channel-binding -->

<!-- BEGIN CURRENT-RUN-AUTHORITY rev0088-runtime-evidence -->
# `/run` authority — rev0088 exact-package runtime evidence

This first block is the current authority. Later rev0087 and earlier blocks are retained only as reconstruction history.

## 0. Provenance and classification

- Candidate: `rev0088-source-notes-runtime-evidence`.
- Product lineage remains `rev0080` / `0.80.0`; rev0081 and rev0082 were not recovered.
- Immediate parent: the frozen rev0087 runtime-kit Roadcase.
- Classification: **candidate with a fail-closed exact-package runtime-evidence boundary and inherited managed non-current Chromium preflight**.
- Release gate remains open. Do not relabel preparation, bundle verification, Chromium 144 automation, screenshots, accessibility trees, or operator assertions as current/unmanaged browser acceptance, authenticated human observation, accessibility conformance, assistive-technology evidence, privacy comprehension, or unfamiliar-person comprehension.

## 1. P0 — completed in managed/native replay

- [x] One optional reason on one direct `folderId/sourceId` placement; one source may have independent reasons in different folders.
- [x] Empty omission, valid Unicode scalar enforcement, 280-code-point limit, native canonicalization/integrity, complete-route disclosure, branch preservation/omission, import remapping, OPML omission evidence, and placement-scoped three-way conflict decisions.
- [x] No automatic winner for divergence or deletion/edit conflicts; explicit **Keep mine** and **Use curator’s** paths.
- [x] Shipped CLI and Extension authoring: add, edit, clear, cancel, Escape, guarded undo, stale-save refusal, and stale-undo refusal.
- [x] Local-only consequence copy: publishes nothing, contacts nobody, creates no schedule, and makes no ProgRSS safety claim.
- [x] Python/JavaScript parity, Chromium/generated-Firefox shared-file parity, unchanged browser permission projections, all 11 CLI modules, complete Extension runner, and managed regression smoke.
- [x] Inherited rev0087 Chromium 144 worktree and exact-final-rev0087 preflights remain valid only within their recorded managed, policy-declared, non-current scope.

## 2. P0 — completed in rev0088 evidence boundary

- [x] Fixed 18-case catalog, including separate divergent-copy runs for **Keep mine** and **Use curator’s**.
- [x] Prepared session binds immutable Roadcase, selected browser package, fixture, catalog, template, browser/environment configuration, and a configuration-derived session ID.
- [x] Overall result is derived: all pass; otherwise any fail; otherwise any blocked; otherwise not run.
- [x] `not-run` cases carry no timestamp, observation, or evidence. Every executed or blocked case requires all three.
- [x] Passing results require exact prepared package, matching observed identity, same-profile restart, fresh profile when declared, unmanaged assertion for unmanaged sessions, and human-observation assertion when declared.
- [x] Finalizer re-verifies the Roadcase and compares the prepared package manifest and fixture with the selected bytes inside that archive.
- [x] Coordinated package/manifest/session tampering, changed fixed catalog/template, missing/extra/symlinked/oversized evidence, and permission-state contradictions are refused.
- [x] Deterministic referenced-only evidence ZIP and unsigned in-toto Statement-shaped record.
- [x] Independent verifier requires the Roadcase again, reruns native archive verification, reconstructs package/fixture binding and the statement, and refuses any changed or extra member.
- [x] Cross-browser comparison exposes case, permission, raw-artifact, and semantic-projection differences; it never closes a runtime row.
- [x] Ten focused tamper/classification tests pass.

## 3. Evidence vocabulary and limits

- **PASS:** all 18 required cases pass and every required identity/assertion guard holds.
- **FAIL:** at least one required case contradicts the expected result.
- **BLOCKED:** no case fails and at least one required case is prevented by policy, installer, browser, environment, or tooling.
- **NOT RUN:** every other incomplete combination, including partial execution.

A prepared session is not a pass. A verified unsigned bundle proves internal consistency and exact binding to the supplied Roadcase; it does not authenticate the operator, machine class, channel currency, human presence, permission comprehension, accessibility, or participant understanding. It is not a SLSA claim or signed provenance.

## 4. P0.1 — immediate next: exact-final rev0088 package seal

After freezing the deterministic Roadcase:

- [ ] Extract it cleanly and require manifest byte/mode verification.
- [ ] Run the available Chromium lane with both `--extension-root CLEAN/Extension` and `--roadcase FINAL.zip`.
- [ ] Require archive/extracted Extension inventory equality and all 15 inherited managed checks.
- [ ] Keep the result external to avoid self-reference.
- [ ] Classify it only as **managed exact-final-Roadcase preflight in non-current Chromium 144**.

This closes final-archive package binding only. It does not close current, unmanaged, Firefox, human, accessibility, or comprehension rows.

## 5. P0.2 — release-blocking browser runtimes

Official references captured on 2026-10-21 are Chrome for Testing Stable `156.0.8078.47`, Firefox Release `158.0.1`, and Firefox ESR `153.5.1esr`. This environment exposed Chromium `144.0.7559.96`, no Firefox executable, and no connected unmanaged browser. Current Chromium acquisition was blocked through the permitted artifact path; Chromium 144 was not substituted.

For each exact final-rev0088 session:

- [ ] Prepare from the immutable Roadcase; never from a worktree.
- [ ] Use a fresh profile and record exact browser, channel, OS build, install method, policy state, and permission observations.
- [ ] Execute all 18 cases and record first failure, retry, interruption, and recovery.
- [ ] Finalize the bundle, independently verify it with the same Roadcase, and retain the unsigned statement.
- [ ] Run unmanaged current Chromium Stable.
- [ ] Run current Firefox Release.
- [ ] Run current Firefox ESR.
- [ ] Compare verified statements and explain platform differences; do not silently normalize them.

Firefox temporary installation may establish runtime behavior but does not reproduce signed-install permission prompts. Keep those conclusions separate.

## 6. P0.3 — unfamiliar-person and assistive-technology fieldwork

Only after all three current-browser rows pass:

- [ ] Ask unfamiliar curators what level the reason belongs to before teaching the model.
- [ ] Put one source in two folders with different reasons and record first interpretation.
- [ ] Ask whether editing published, contacted anyone, created a schedule, or made a safety claim.
- [ ] Ask unfamiliar recipients who wrote the reason and what authority it carries.
- [ ] Test branch expectations, OPML loss explanations, and true divergent later-copy decisions.
- [ ] Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions.
- [ ] Review sender and recipient privacy evidence separately.
- [ ] Make only the smallest correction supported by recurring independent wrong turns, then replay the affected task.

Automation never closes these rows.

## 7. P1 — delayed re-finding and organization

- [ ] Test delayed route re-finding after one week with and without placement reasons.
- [ ] Determine whether reasons reduce demand for premature private-label or saved-view complexity.
- [ ] Keep folders human-curated and shareable; preserve **Unfiled**.
- [ ] Add private labels or saved views only when delayed re-finding evidence supports them.
- [ ] Keep reason wording out of engagement ranking and opaque recommendation systems.
- [ ] Do not expand Source Notes into comments, reactions, profiles, messaging, or notifications.

## 8. P2 — remote Nodes

- [ ] Keep remote mode explicit and separate from loopback.
- [ ] Require TLS and persistent Node identity.
- [ ] Bound hosts, requests, artifacts, and rates.
- [ ] Add expiring invitations and durable revocation evidence.
- [ ] Keep public publication routes separate from private APIs.
- [ ] Begin with reviewed immutable-artifact retrieval.
- [ ] No default public bind, silent LAN discovery, UPnP, or Source Notes authority expansion.

## 9. Lab — WebRTC courier

- [ ] Transfer exactly one reviewed immutable artifact.
- [ ] Preserve Source Notes through that native artifact.
- [ ] Make signaling, STUN, and TURN visible.
- [ ] Refuse replay, identity mismatch, digest mismatch, timeout, and partial completion.
- [ ] Destroy the session after the bounded transfer.
- [ ] Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## 10. Stop conditions

Stop and leave the row open if package identity is uncertain, a prepared catalog/template changed, the selected package no longer matches the Roadcase, evidence is missing or unreferenced, `not-run` carries execution evidence, a profile/policy/channel is undeclared, a temporary install is treated as signed-install prompt evidence, a stale write wins, an expected conflict is auto-resolved, OPML loss is silent, permissions expand, or automation is being relabeled as unmanaged/human/accessibility evidence.

<!-- END CURRENT-RUN-AUTHORITY rev0088-runtime-evidence -->

<!-- BEGIN HISTORICAL-RUN-AUTHORITY rev0087-postbuild-exact-seal -->
# `/run` authority — rev0087 post-build exact-package seal

Historical rev0087 authority retained for provenance. It is superseded by the rev0088 authority above.

## 0. Provenance and classification

- Candidate: `rev0087-source-notes-runtime-kit`.
- Product lineage remains `rev0080` / `0.80.0`; rev0081 and rev0082 were not recovered.
- Frozen Roadcase: `ProgRSS-rev0087-source-notes-runtime-kit-2026.10.21-Roadcase.zip`.
- Roadcase SHA-256: `3c0e6047b3a8004f294fb1d80cbb3f722e473d8cf75231cef9f12929c0251133`.
- Roadcase bytes: `6653833`.
- Classification: **candidate with exact-package tooling and managed exact-final-Roadcase preflight in non-current Chromium 144**.
- Release gate remains open. Do not relabel this as current Stable, unmanaged browser acceptance, Firefox runtime, signed-install permission-prompt evidence, accessibility conformance, assistive-technology evidence, or unfamiliar-person comprehension.

## 1. P0 — completed in this session

- [x] Placement-scoped Source Notes contract, native canonicalization/integrity, disclosure, branch, import, OPML omission, and three-way conflict behavior.
- [x] Shipped CLI and Extension placement authoring with add/edit/clear/cancel/guarded undo and stale-write refusal.
- [x] Python/JavaScript parity, generated-Firefox shared-file parity, unchanged browser permission projections, 11 CLI modules, complete Extension runner, and managed rendering regression smoke.
- [x] Shipped-entry-point matrix: 16 PASS, 0 OPEN, 4 NOT RUN, 0 NOT ESTABLISHED.
- [x] Exact-Roadcase session preparer and fail-closed runtime protocol.
- [x] Deterministic Roadcase: two internal constructions plus an independent third construction are byte-identical.
- [x] Direct archive verification, clean-extraction verification, manifested byte/mode comparison, clean focused replay, and CLI doctor.
- [x] Prepared exact packages/checklists for Chromium, Firefox Release, and Firefox ESR.
- [x] External exact-final-Roadcase Chromium 144 seal: 15/15 focused checks, fresh persistent profile, restart, two live extension views, native artifacts, archive/extraction inventory equality, declared temporary policy override, and restored original policy.

## 2. P0.1 — immediate next: current unmanaged Chromium

Use the frozen Roadcase and its prepared Chromium session. Record browser/OS/profile/install identity and human permission-prompt observations. Replay all 15 focused checks without hidden policy, test hooks, or worktree substitution. Current channel reference captured on 2026-10-21: Chrome for Testing Stable `156.0.8078.47`.

- [ ] Install the exact prepared package in an unmanaged then-current Chromium Stable profile.
- [ ] Verify the Roadcase, package, manifest, fixture, and Extension subtree digests before interaction.
- [ ] Record actual install prompts rather than inferring them from manifest declarations.
- [ ] Replay add/edit/clear/cancel/undo, two-folder independence, Unicode boundary, interrupted draft/focus, real stale save/undo, restart persistence, native complete-route and branch artifacts, OPML omission, digest refusal, and divergent-copy decisions.
- [ ] Compare permission projections before and after and record every first failure/retry.

## 3. P0.2 — Firefox Release and ESR

Current references captured on 2026-10-21: Firefox Release `158.0.1`; Firefox ESR `153.5.1esr`.

- [ ] Run the exact generated sibling in Firefox Release.
- [ ] Run the same package/scenario in Firefox ESR.
- [ ] Keep temporary `about:debugging` runtime evidence separate from signed-install permission-prompt evidence.
- [ ] Compare native artifact bytes wherever cross-browser equivalence is expected; explain platform-specific differences.
- [ ] Do not promote generated-file parity to runtime parity.

## 4. P0.3 — unfamiliar-person and real assistive-technology fieldwork

Only after all three current browser rows pass:

- [ ] Unfamiliar curators: relationship level, two-folder reasons, edit consequences, and safety-claim interpretation.
- [ ] Unfamiliar recipients: authorship, authority, branch expectations, OPML loss, and divergent-copy choices.
- [ ] Separate screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions.
- [ ] Review sender and recipient privacy evidence separately.
- [ ] Make only the smallest correction supported by recurring independent wrong turns, then replay the affected task.

## 5. P1, P2, and Lab

- [ ] P1: delayed route re-finding after one week before private-label or saved-view expansion; preserve human-curated folders and **Unfiled**.
- [ ] P2: remote Nodes remain separate from loopback and require TLS, persistent identity, bounded resources, expiring invitations, revocation evidence, and no default public bind/LAN discovery/UPnP.
- [ ] Lab: WebRTC may transfer exactly one reviewed immutable artifact with visible signaling/STUN/TURN and fail-closed replay, identity, digest, timeout, and partial-completion handling. It must never become required for ordinary reading or sharing.

## 6. Stop conditions

Leave a row open if package identity is uncertain, browser/channel identity is missing, policy is hidden, a temporary install is treated as signed-install prompt evidence, a stale write wins, a conflict is auto-resolved, OPML loss is silent, permissions expand, or managed automation is being relabeled as unmanaged/human/accessibility evidence.

<!-- END CURRENT-RUN-AUTHORITY rev0087-postbuild-exact-seal -->

<!-- BEGIN CURRENT-RUN-AUTHORITY rev0087-source-notes-runtime-kit -->
# `/run` authority — rev0087 Source Notes exact-package runtime kit

This first block is the current authority. Every older authority block below is provenance only and must not override it.

## 0. Provenance, classification, and claim language

- Candidate label: `rev0087-source-notes-runtime-kit`.
- Product lineage remains `rev0080` / `0.80.0`.
- Immediate parent: `ProgRSS-rev0086-source-notes-authoring-2026.10.21-Roadcase.zip`.
- Root supplied baseline: `ProgRSS-rev0080-2026.10.20-Roadcase(1).zip`.
- The unavailable rev0081 and rev0082 artifacts were not recovered. Never describe this candidate as their byte descendant.
- Classification: **candidate with exact-package tooling and managed non-current Chromium preflight**.
- The available runtime is Debian Chromium `144.0.7559.96`, headed under a virtual display, automated with Playwright/CDP, and run only after an explicitly declared temporary policy override. The override is restored after each run.
- Online channel references captured on 2026-10-21 are Chrome for Testing Stable `156.0.8078.47`, Firefox Release `158.0.1`, and Firefox ESR `153.5.1esr`.
- Therefore the available Chromium result is useful implementation evidence but is not current Stable, unmanaged-browser acceptance, human permission-prompt observation, accessibility conformance, assistive-technology evidence, or unfamiliar-person comprehension.

`REVISION-STATE.json`, `SOURCE-NOTES-ENTRYPOINT-MATRIX.*`, `SOURCE-NOTES-RUNTIME-MATRIX.*`, `SOURCE-NOTES-RUNTIME-AUDIT.*`, `BROWSER-CHANNEL-SNAPSHOT.*`, `BROWSER-PERMISSION-AUDIT.*`, and `RECONSTRUCTION_PROVENANCE.*` carry the machine-readable claim boundary.

## 1. Product boundary remains unchanged

A Source Note is one optional plain-text reason on one **direct** folder-to-source relationship, keyed by `folderId/sourceId`.

It is not a global source description, folder comment, safety/quality/trust claim, message, publication action, schedule, notification, profile, reaction, ranking signal, label, saved view, or recommendation feature.

Absence and **Unfiled** remain legitimate. One source may have different reasons in different folders. Empty input removes the field. The limit remains 280 Unicode code points with Python/JavaScript scalar-validation parity. Source Notes stay in the existing native collection member, canonicalization, integrity, disclosure, branch, import, update, and vault paths. No account, pairing authority, remote state, host permission, notification, public bind, LAN discovery, UPnP, or background network request is added.

## 2. Evidence classes and exact `/run` order

Run in this order for every frozen candidate:

1. `python3 Extension/tools/sync_firefox.py`
2. `python3 tools/verify-rev0087-source-notes.py`
3. Run all 11 CLI test modules separately; freeze per-module logs and `evidence/rev0087/cli-modules-summary.json`.
4. `sh Extension/tests/run.sh`
5. `python3 Extension/tests/browser_smoke.py`
6. `python3 tools/audit-source-notes-runtime-kit.py`
7. `python3 tools/audit-source-notes-authoring.py`
8. `python3 tools/audit-source-notes-entrypoints.py`
9. `python3 tools/update-reconstruction-provenance.py`
10. Validate JSON, Python, JavaScript, HTML, CSS, executable modes, and all current claim files.
11. `python3 tools/build-reconstruction-roadcase.py`
12. Independently rebuild and require byte equality with the frozen Roadcase.
13. Verify the ZIP directly, extract cleanly, compare every manifested byte and POSIX mode, rerun the rev0087 gate and CLI doctor, and prepare both Chromium and Firefox runtime sessions from the immutable archive.
14. After the archive is immutable, run `Extension/tests/source_notes_installed_acceptance.py --roadcase FINAL.zip` against the cleanly extracted `Extension` tree. Keep this evidence external to avoid self-reference.
15. Freeze final Roadcase/evidence SHA-256 files, machine verification, result summary, and handoff.

A skipped, unavailable, blocked, timed-out, stale, temporary-install-limited, or unattempted row stays open. Environment absence never becomes a pass. A prepared session never becomes a runtime pass. Managed automation never becomes unmanaged or human evidence.

## 3. P0 — completed in managed replay and non-current preflight

The row-level scope is authoritative in `SOURCE-NOTES-ENTRYPOINT-MATRIX.*` and `SOURCE-NOTES-RUNTIME-MATRIX.*`.

### Native relationship continuity and shipped authoring

- [x] One optional reason belongs only to one direct `folderId/sourceId` placement.
- [x] Empty omission, Unicode scalar validation, 280/281 boundaries, identical-duplicate canonicalization, and conflicting-duplicate refusal agree in Python and JavaScript.
- [x] One source in two folders keeps independent reasons.
- [x] Native integrity covers the reason and refuses post-digest mutation.
- [x] Complete-route disclosure, branch preservation/omission, identity remapping, OPML omission evidence, and placement-scoped three-way conflict decisions are covered.
- [x] Curator-only, recipient-only, and identical changes preserve automatically; divergence and deletion/edit conflicts have no automatic winner.
- [x] CLI and Extension authoring add, edit, clear, cancel, save, and guard one exact placement without a parallel store or serializer.
- [x] Save and undo carry exact version/prior-current reason guards and refuse stale overwrites.
- [x] Local-only consequence copy states that editing publishes nothing, contacts nobody, creates no schedule, and makes no ProgRSS safety claim.
- [x] Required, optional, host, and optional-host permission projections remain unchanged from rev0080.
- [x] No nominal Node authoring endpoint was added; the loopback Node stays at reviewed branch/import and merge-review boundaries.

### Runtime kit and available-browser preflight

- [x] The exact-Roadcase session preparer verifies the archive, rejects unsafe paths/symlinks, extracts only the selected shipped package, and records Roadcase/package/manifest/fixture identity.
- [x] Prepared sessions leave all runtime and human claims false and include a fail-closed checklist/result vocabulary.
- [x] The real Chromium lane uses an installed unpacked MV3 extension, shipped IndexedDB, two real extension views, production background requests, a persistent profile, and a browser restart.
- [x] No `test-source-note-*` hook is used.
- [x] The available Chromium 144 worktree preflight passed all 15 focused checks: cancel/consequence disclosure, two-folder independence, clear/undo, Unicode boundary, interrupted draft/focus, real stale save, stale undo refusal, unchanged permissions, restart persistence, complete-route disclosure, selected branch, OPML omission, integrity refusal, and divergent later-copy decision.
- [x] The result records its policy override, exact browser/OS/profile state, package/fixture digests, screenshots, and all non-claims.
- [x] The result is explicitly worktree-bound; it does not pretend to be the immutable final-Roadcase seal.

## 4. P0.1 — immediate next: external exact-final-Roadcase seal

After the deterministic Roadcase is frozen:

- [ ] Extract it cleanly and require manifest byte/mode verification.
- [ ] Run the available Chromium lane with both `--extension-root CLEAN/Extension` and `--roadcase FINAL.zip`.
- [ ] Require archive/extracted Extension inventories and subtree digests to match exactly.
- [ ] Require the same 15 focused runtime checks, fresh persistent profile, restart, native artifacts, screenshots, and policy-override declaration.
- [ ] Keep the result external; record the immutable Roadcase SHA-256 in that result and in final verification.
- [ ] Classify the result only as **managed exact-final-Roadcase preflight in non-current Chromium 144**.

This closes package-binding uncertainty only. It does not close any current/unmanaged/Firefox/human row.

## 5. P0.2 — release-blocking current browser runtimes

Use the immutable Roadcase and prepared session packages:

- [ ] Unmanaged then-current Chromium Stable, with exact browser/OS/profile/install identity and human permission observations.
- [ ] Then-current Firefox Release using the generated sibling.
- [ ] Then-current Firefox ESR using the same generated sibling and scenario.
- [ ] In each runtime, replay all authoring, two-folder, interruption, stale-save/undo, restart, native integrity/disclosure, branch, OPML, and divergent-copy cases.
- [ ] Compare native artifact bytes wherever platform equivalence is expected; explain any platform-specific difference rather than silently normalizing it.
- [ ] Confirm that no required, optional, host, or optional-host permission projection expanded.

Firefox `about:debugging` temporary installation is valid runtime evidence but does not by itself reproduce a signed installation’s permission prompts. Keep runtime and permission-prompt conclusions separate.

## 6. P0.3 — unfamiliar-person and assistive-technology fieldwork

Only after all three current browser rows pass:

- [ ] Ask unfamiliar curators what level the reason belongs to before teaching the model.
- [ ] Put one source in two folders with different reasons and observe first interpretation.
- [ ] Ask whether editing published, contacted anyone, created a schedule, or made a safety claim.
- [ ] Ask unfamiliar recipients who wrote the reason and what authority it carries.
- [ ] Test branch expectations, OPML loss explanations, and true divergent later-copy decisions.
- [ ] Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions.
- [ ] Review sender and recipient privacy evidence separately.
- [ ] Record pauses, reversals, first wrong turns, and recovery before teaching.
- [ ] Make only the smallest correction supported by recurring independent wrong turns, then replay the affected task.

Automation, screenshots, accessibility trees, target-size assertions, and simulated keyboard input never close these rows.

## 7. P1 — delayed re-finding and organization

- [ ] Test delayed route re-finding after one week with and without placement reasons.
- [ ] Determine whether reasons reduce demand for premature private-label or saved-view complexity.
- [ ] Keep folders human-curated and shareable; preserve **Unfiled**.
- [ ] Add private labels or saved views only when delayed re-finding evidence supports them.
- [ ] Keep reason wording out of engagement ranking and opaque recommendation systems.
- [ ] Do not expand Source Notes into comments, reactions, profiles, messaging, or notifications.

## 8. P2 — remote Nodes

- [ ] Keep remote mode explicit and separate from loopback.
- [ ] Require TLS and persistent Node identity.
- [ ] Bound hosts, requests, artifacts, and rates.
- [ ] Add expiring invitations and durable revocation evidence.
- [ ] Keep public publication routes separate from private APIs.
- [ ] Begin with reviewed immutable-artifact retrieval.
- [ ] No default public bind, silent LAN discovery, UPnP, or Source Notes authority expansion.

## 9. Lab — WebRTC courier

- [ ] Transfer exactly one reviewed immutable artifact.
- [ ] Preserve Source Notes through that native artifact.
- [ ] Make signaling, STUN, and TURN visible.
- [ ] Refuse replay, identity mismatch, digest mismatch, timeout, and partial completion.
- [ ] Destroy the session after the bounded transfer.
- [ ] Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## 10. Stop conditions

Stop and leave the row open if the package identity is uncertain, a profile is reused without being declared, policy is hidden, browser/channel identity is missing, a temporary install is treated as signed-install prompt evidence, an expected conflict is auto-resolved, a stale write wins, OPML loss is silent, permissions expand, or automation is being relabeled as unmanaged/human/accessibility evidence.

<!-- END CURRENT-RUN-AUTHORITY rev0087-source-notes-runtime-kit -->

<!-- BEGIN CURRENT-RUN-AUTHORITY rev0086-source-notes-authoring -->
# `/run` authority — rev0086 Source Notes placement authoring

This first block is the current authority. Older authority blocks remain below as provenance and must not override it.

## 0. Provenance and claim language

- Candidate label: `rev0086-source-notes-authoring`.
- Product lineage remains `rev0080` / `0.80.0`.
- Immediate parent: `ProgRSS-rev0085-source-notes-entrypoint-matrix-2026.10.21-Roadcase.zip`.
- Root supplied baseline: `ProgRSS-rev0080-2026.10.20-Roadcase(1).zip`.
- The unavailable rev0081 and rev0082 artifacts were not recovered. Never describe this candidate as their byte descendant.
- Classification: **candidate with managed placement-authoring replay**.
- Managed automation may establish deterministic code, rendering, interaction, permission, and packaging regression evidence. It does not establish unmanaged-browser behavior, accessibility conformance, assistive-technology use, privacy comprehension, or unfamiliar-person comprehension.

`REVISION-STATE.json`, `SOURCE-NOTES-ENTRYPOINT-MATRIX.*`, `SOURCE-NOTES-AUTHORING-AUDIT.*`, `BROWSER-PERMISSION-AUDIT.*`, and `RECONSTRUCTION_PROVENANCE.*` carry the machine-readable claim boundary.

## 1. Product boundary

A Source Note is one optional plain-text reason on one **direct** folder-to-source relationship, keyed by `folderId/sourceId`.

It is not:

- a global description of the source;
- a folder comment;
- a ProgRSS safety, quality, or trust claim;
- a message to the curator or recipient;
- a publication action;
- a schedule, notification, profile, reaction, ranking signal, label, or recommendation feature.

Absence and **Unfiled** remain legitimate states. One source may have different reasons in different folders. Empty input canonically removes the field. The limit is 280 Unicode code points, with Python/JavaScript scalar-validation parity.

The authoring surface must remain inside an existing local folder-edit boundary. It must not create a parallel serializer, remote state, account, pairing authority, host access, notification, or background network request.

## 2. Evidence classes and exact `/run` order

Run in this order for every frozen candidate:

1. `python3 Extension/tools/sync_firefox.py`
2. `python3 tools/verify-rev0086-source-notes.py`
3. Run all 11 CLI test modules separately and freeze per-module logs plus `evidence/rev0086/cli-modules-summary.json`.
4. `sh Extension/tests/run.sh`
5. `python3 Extension/tests/browser_smoke.py`
6. `python3 tools/audit-source-notes-authoring.py`
7. `python3 tools/audit-source-notes-entrypoints.py`
8. `python3 tools/update-reconstruction-provenance.py`
9. Validate JSON, Python, JavaScript, HTML, CSS, executable modes, and all current claim files.
10. `python3 tools/build-reconstruction-roadcase.py`
11. Independently rebuild once more and require byte equality with the frozen Roadcase.
12. Verify the ZIP manifest directly, extract cleanly, compare every manifested byte and POSIX mode, rerun the rev0086 gate and CLI doctor from that extraction, and freeze final SHA-256 evidence.

A skipped, timed-out, unavailable, or unattempted row remains open. Environment absence is never a pass.

## 3. P0 — completed in managed replay

The row-level scope is authoritative in `SOURCE-NOTES-ENTRYPOINT-MATRIX.*`.

### Native relationship continuity

- [x] One optional reason belongs only to one direct `folderId/sourceId` placement.
- [x] Empty-value omission, valid Unicode scalar enforcement, and 280/281 code-point boundaries agree in Python and JavaScript.
- [x] Identical duplicate placements canonicalize once; conflicting duplicate reasons are rejected.
- [x] One source in two folders keeps two independent reasons.
- [x] Native artifact integrity covers the relationship field and refuses post-digest reason mutation.
- [x] Complete-route contents disclose every note-bearing placement and folder path.
- [x] Selected branches preserve in-branch reasons and omit out-of-branch reasons.
- [x] Native import identity remapping preserves the placement field.
- [x] OPML carries no Source Note values or invented private attribute and reports exact omitted placement keys.
- [x] Three-way base/recipient/curator comparison is placement-scoped.
- [x] Curator-only, recipient-only, and identical changes preserve automatically.
- [x] Divergence, deletion-versus-edit, and edit-versus-deletion have no automatic winner.
- [x] Unresolved, partial, invalid, unknown, and stale conflict decisions are rejected.
- [x] **Keep mine** and **Use curator’s** apply only to the displayed placement conflict.
- [x] Node branch preview/commit and merge review preserve or disclose exact reasons.
- [x] Chromium-source and generated-Firefox fixture paths consume the same contract.

### Shipped placement authoring

- [x] The CLI exposes `workspace source-note` at its existing offline private-backup folder-edit boundary.
- [x] The CLI adds, edits, or clears exactly one direct placement, writes a new file only, and leaves the input as rollback.
- [x] The Extension places **Add reason / Edit reason** beside each direct relationship in the existing source-card folder organizer.
- [x] Save uses the existing background mutation queue, native collection cleaner, vault persistence, and state broadcast path.
- [x] Save submits the exact folder version and prior reason; mismatch refuses the stale write and preserves newer wording.
- [x] Clear removes the optional field rather than writing an empty string.
- [x] Cancel and Escape make no write and return focus to the placement control.
- [x] A 12-second visible undo submits the expected current reason and folder version; stale undo is refused.
- [x] One source can be edited independently in two folders.
- [x] Ordinary state rerender preserves the active draft, selection, open disclosure, and focus.
- [x] The editor explains before save that the edit is local, publishes nothing, contacts nobody, creates no schedule, and is not a ProgRSS safety claim.
- [x] Managed checks cover Unicode counting, 281 refusal, keyboard operation, meaningful control names, 44px controls, 320px reflow, forced-colors styling, reduced-motion styling, and interruption regression.
- [x] The loopback Node receives no nominal authoring endpoint because it has no corresponding local folder-edit surface; its reviewed import/branch/merge authority remains unchanged.
- [x] Required, optional, host, and optional-host permission projections remain unchanged from the supplied rev0080 manifests.

These are managed acceptance claims only. In particular, the accessibility-oriented checks are regression targets, not a declaration of WCAG conformance or real assistive-technology usability.

## 4. P0.1 — next: exact packaged browser runtime

Use the final Roadcase bytes, not the working tree:

- [ ] Record Roadcase SHA-256, Extension subtree digest, OS/build, browser build, profile state, install method, and fixture digest before each run.
- [ ] Load the exact Chromium package in an unmanaged then-current Chromium Stable profile.
- [ ] Load the exact generated sibling in then-current Firefox Release.
- [ ] Repeat with then-current Firefox ESR.
- [ ] In every runtime, add, edit, clear, cancel, and undo one reason on one direct placement.
- [ ] Put one source in two folders, assign different reasons, restart the browser, and verify both remain independent.
- [ ] Interrupt an edit with an ordinary library change and verify the draft/focus survive without an unintended save.
- [ ] Create a real stale edit from two views; verify the newer wording wins and the stale draft remains reviewable.
- [ ] Export the native artifact and verify digest coverage and byte equivalence where platform equivalence is expected.
- [ ] Replay complete-route disclosure, one-branch selection, OPML omission, divergent later-copy conflict, and clean restart.
- [ ] Confirm no new required, optional, host, or optional-host permission prompt appears.

Generated-file parity, Node-managed module replay, Playwright, and extension API mocks are not browser-runtime evidence.

## 5. P0.2 — unfamiliar-person and assistive-technology fieldwork

After the exact runtime rows pass:

- [ ] Ask unfamiliar curators what level the reason belongs to before teaching the model.
- [ ] Put one source in two folders with different reasons and observe whether both remain intelligible.
- [ ] After editing, ask whether anything was published, whether anyone was contacted, and whether a schedule was created.
- [ ] Ask unfamiliar recipients who wrote the reason and whether it is a ProgRSS safety claim.
- [ ] Select one branch and ask which reasons should remain before showing the result.
- [ ] Show OPML omission evidence and ask the participant to explain what was lost.
- [ ] Present a true divergent later-copy conflict and observe **Keep mine**, **Use curator’s**, and leaving it unresolved.
- [ ] Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions.
- [ ] Review sender and recipient privacy evidence separately.
- [ ] Record first interpretations, pauses, reversals, and wrong turns before teaching or correcting.
- [ ] Make only the smallest correction supported by recurring independent wrong turns, then replay the affected task.

Do not label a session accessible because no one complained. Automated DOM output, accessibility trees, screenshots, target-size assertions, and simulated keyboard input are not screen-reader, Braille, voice, switch, cognition, fatigue, or interruption evidence.

## 6. P1 — delayed re-finding and organization

- [ ] Test delayed route re-finding after one week with and without placement reasons.
- [ ] Determine whether reasons reduce demand for premature private-label or saved-view complexity.
- [ ] Keep folders human-curated and shareable.
- [ ] Preserve **Unfiled** as a legitimate state.
- [ ] Add private labels or saved views only when re-finding evidence identifies a concrete unmet task.
- [ ] Keep reason wording out of engagement ranking and opaque recommendation systems.
- [ ] Do not expand Source Notes into comments, reactions, profiles, follower graphs, notifications, or messaging.

## 7. P2 — remote Nodes, separately reviewed

- [ ] Keep remote mode explicit and separate from loopback.
- [ ] Require TLS and persistent, reviewable Node identity.
- [ ] Bound allowed hosts, requests, artifacts, concurrency, and rates.
- [ ] Add expiring invitations and durable revocation evidence.
- [ ] Keep public immutable-artifact routes separate from private APIs.
- [ ] Begin with reviewed immutable-artifact retrieval.
- [ ] Refuse default public bind, silent LAN discovery, UPnP, and hidden relay fallback.

No P0 or P1 task may quietly depend on remote mode.

## 8. Lab only — WebRTC courier

- [ ] Transfer exactly one previously reviewed immutable artifact.
- [ ] Preserve Source Notes only through the native integrity-covered artifact.
- [ ] Make signaling, STUN, TURN, peer identity, digest, size bound, and expiry visible.
- [ ] Refuse replay, identity mismatch, digest mismatch, timeout, over-bound size, and partial completion.
- [ ] Destroy session capability and transient transfer state after the bounded transfer.
- [ ] Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## 9. Research anchors

Primary specifications constrain implementation; they do not replace product evidence.

- Chrome documents side panels as extension UI that can remain available while the user navigates, supporting use of the existing panel rather than a new page or permission: <https://developer.chrome.com/docs/extensions/reference/api/sidePanel>.
- Chrome and MDN describe `storage.local` as local to the machine where the extension is installed. ProgRSS still uses its own explicit disclosure rather than treating that platform fact as proof of user comprehension: <https://developer.chrome.com/docs/extensions/reference/api/storage> and <https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/storage/local>.
- Required, optional, host, and optional-host permissions remain explicit manifest boundaries: <https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/manifest.json/permissions>.
- WCAG-oriented managed checks target reflow, text resizing, visible keyboard focus, and usable pointer targets, while conformance and real assistive-technology use remain separate evaluation tasks: <https://www.w3.org/WAI/WCAG21/Understanding/reflow.html>, <https://www.w3.org/WAI/WCAG21/Understanding/resize-text.html>, <https://www.w3.org/WAI/WCAG22/Understanding/focus-not-obscured-minimum.html>, and <https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html>.
- RFC 8785 remains background for deterministic JSON serialization; ProgRSS continues to use its existing native canonical artifact path rather than adding a Source Notes serializer: <https://www.rfc-editor.org/rfc/rfc8785>.
- OPML extensibility does not create standardized cross-reader semantics for ProgRSS placement reasons: <https://opml.org/spec2.opml>.

<!-- END CURRENT-RUN-AUTHORITY rev0086-source-notes-authoring -->

---

<!-- BEGIN CURRENT-RUN-AUTHORITY rev0083-reconstructed-from-rev0080 -->
# `/run` authority — rev0083 reconstruction from supplied rev0080

> **Current authority, 2026-10-21.** When this block conflicts with older prose below it, this block wins. Keep the older material as history and context; do not use it to mark a present gate complete.

## 0. Provenance and release language

- Working label: `rev0083-reconstructed-from-rev0080`.
- Supplied baseline: `ProgRSS-rev0080-2026.10.20-Roadcase(1).zip`.
- Supplied baseline SHA-256: `181308cabfae43330016a272a64fbdb33038f841d605f4756ec65bedb43b8106`.
- rev0081 and rev0082 bytes were not supplied and were not recovered.
- Say **reconstructed from rev0080**, never “recovered rev82,” “byte descendant of rev82,” or equivalent.
- Preserve `RECONSTRUCTION_PROVENANCE.json`, the Roadcase manifest, test logs, and exact browser build identifiers with any handoff.
- Current automated reconstruction checks: **NOT ESTABLISHED**.
- Machine-generated current status: `CURRENT-STATUS.md` (candidate evidence is not a behavioral pass).
- Existing native-suite replay: **NOT ESTABLISHED**. “Not established” is a release gate, not permission to infer success.

## 1. Product boundary that no Source Notes task may cross

A Source Note is one optional, curator-authored, plain-text reason on one **direct folder-to-source placement**. The same source in two folders may carry two different reasons. Absence is valid. Empty canonical values disappear. The maximum is 280 Unicode code points in both Python and JavaScript.

Source Notes do not add or imply:

- an account, profile, identity directory, comment, reaction, follower, notification, inbox, or presence system;
- contact with a curator, recipient, publisher, or ProgRSS service when a local reason is edited;
- a ProgRSS safety, accuracy, endorsement, or trust guarantee;
- engagement ranking, opaque recommendations, or note-derived behavioral scoring;
- pairing, permission, scheduling, background sync, private-state sharing, LAN discovery, public bind, UPnP, or a required remote service.

Keep this boundary visible in sender evidence, recipient evidence, conflict decisions, OPML omission evidence, browser permission review, and fieldwork prompts.

## 2. Exact local run order

Run from the directory containing this file. Do not install dependencies, contact a package registry, publish an artifact, or enable a network listener beyond an explicitly reviewed loopback-only test server.

```sh
./tools/verify-source-notes-contract.sh
python3 ./tools/verify-fieldwork-harness.py
python3 ./tools/audit-source-notes-integration.py
python3 ./tools/audit-browser-siblings.py
python3 ./tools/run-reconstruction-checks.py
python3 ./tools/smoke-fieldwork-browsers.py
python3 ./tools/build-reconstruction-roadcase.py
```

Interpretation:

1. The first command is the cross-runtime reference gate. Python and JavaScript consume the same fixtures and must emit byte-identical canonical results.
2. The second checks only static privacy and accessibility properties of the local fieldwork harness. It is not an accessibility conformance result.
3. The integration audit is conservative static evidence. A matching string is only a candidate call site; it is never behavioral proof.
4. The sibling audit compares manifests and file inventories only; it cannot establish generated provenance or runtime parity.
5. The reconstruction check runner performs syntax, JSON, reference-contract, harness, and any already-available native tests without downloading dependencies.
6. Browser automation is a managed-environment smoke only. It is never evidence for unmanaged current Chromium, Firefox Release, Firefox ESR, assistive technology, or participant comprehension.
7. The deterministic Roadcase builder must build twice, compare archive bytes, verify its manifest directly, extract cleanly, and compare every manifested byte and POSIX mode.

A failed, skipped, unavailable, or unattempted native replay remains plainly labeled. Do not turn “the dependency was absent” into a pass.

## 3. P0 — release-blocking reconstruction ledger

### P0.0 — established in this reconstruction

- [x] A transport-neutral Source Notes reference contract exists in `source_notes_contract/`.
- [x] Python and JavaScript share fixtures for canonicalization, one-sided changes, equal two-sided changes, divergent edits, additions, deletion, and explicit decisions.
- [x] A divergent value enters no merged artifact until the recipient chooses **Keep mine** or **Use curator’s**.
- [x] Stale, unknown, or invalid conflict decisions are rejected rather than silently reused.
- [x] Empty reasons canonicalize to absence; limits count Unicode code points; lone surrogate values are rejected.
- [x] A note on a non-source member is rejected by the reference placement validator.
- [x] OPML evidence is separate, explicit, and branch-scoped; no ProgRSS-only OPML attribute is introduced by the reference contract.
- [x] A dependency-free local fieldwork harness exists in `fieldwork/source-notes/` with no telemetry, storage API, service worker, or network API.
- [x] The harness records sender and recipient privacy perspectives separately and labels automated smoke as non-fieldwork.
- [x] No Source Notes change in this reconstruction requires a new browser permission or a remote service.

### P0.1 — highest priority: prove native call-site continuity

Rationale from the unavailable later revisions is not executable evidence. For every item below, locate the actual native call site, add or retain a focused test, and replay it in the shipped path. Keep a path-and-command evidence record.

- [ ] Direct placement schema accepts at most one optional reason and rejects a note on folders, source records, or indirect descendants.
- [ ] Native Python and browser/Node validation agree on type, empty canonicalization, Unicode counting, invalid Unicode, and 280/281 boundaries.
- [ ] Native canonical bytes cover the reason wherever the direct placement travels; mutation changes the integrity result.
- [ ] Node authoring exposes the reason at the direct placement level without a permission, identity, or scheduling expansion.
- [ ] Complete-route recipient disclosure names every note-bearing placement and its folder path.
- [ ] Independent-branch disclosure includes only the selected branch and retains different reasons for duplicate source placements.
- [ ] Native OPML export contains no Source Notes value and emits explicit selected-branch omission evidence.
- [ ] Later-copy update code compares base, mine, and curator values per direct placement.
- [ ] Curator-only and recipient-only edits survive automatically; equal edits coalesce; edit-versus-delete conflicts.
- [ ] A divergent conflict has no default winner, no timed winner, and no bulk hidden winner.
- [ ] **Keep mine** and **Use curator’s** act only on the displayed placement and are included in subsequent native integrity evidence.
- [ ] Chromium and the generated Firefox sibling execute the same fixtures and user-visible decisions.
- [ ] Browser manifest permissions and host permissions are byte-for-byte unchanged from the matched rev0080 baseline, or every delta is separately justified and rejected for Source Notes if unnecessary.

Stop P0.1 on the first ambiguous ownership key. Do not key a reason only by source identity: that would collapse two folders containing the same source. Use the native stable identity for the **direct placement**, with its branch context preserved.

### P0.2 — deterministic candidate Roadcase

- [x] Re-run `tools/build-reconstruction-roadcase.py` after every byte that enters the handoff.
- [x] Two clean builds are byte-identical.
- [x] `VERIFY-ROADCASE.py --archive …` passes against the final ZIP.
- [x] A clean custom extraction passes `VERIFY-ROADCASE.py` with byte and executable-mode equality.
- [x] The final `.sha256`, build report, reconstruction checks, integration audit, and provenance are retained together.
- [x] The artifact remains labeled **candidate-only** until P0.1 native replay and P0.3 fieldwork evidence are complete.

### P0.3 — native Source Notes fieldwork

Use actual shipped Chromium and generated-Firefox artifacts, not the standalone harness alone. Record exact browser, operating system, extension digest, native artifact digest, assistive technology, and scenario fixture.

- [ ] Run the exact candidate on an unmanaged, then-current Chromium Stable installation.
- [ ] Run the generated sibling on then-current Firefox Release and Firefox ESR.
- [ ] Ask unfamiliar curators what level the reason belongs to before teaching the model.
- [ ] Put one source in two folders with different reasons and observe whether both remain intelligible.
- [ ] After a local edit, ask whether anything was published or whether anyone was contacted.
- [ ] Ask unfamiliar recipients who wrote the reason.
- [ ] Ask whether the wording is a ProgRSS safety, accuracy, or endorsement claim.
- [ ] Select one branch and ask which reasons should remain before showing the result.
- [ ] Show OPML omission evidence and ask the participant to explain what was lost.
- [ ] Present a true divergent later-copy conflict and observe comprehension of **Keep mine**, **Use curator’s**, and leaving it unresolved.
- [ ] Conduct distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions.
- [ ] Privacy-review sender evidence and recipient evidence separately.
- [ ] Record first interpretations and wrong turns before explanations or corrections.
- [ ] Make only the smallest correction supported by recurring independent wrong turns; replay the affected task afterward.

Do not report a session as “accessible” merely because no participant complained. Do not treat automated DOM output or a screenshot as screen-reader, Braille, voice, switch, cognition, fatigue, or interruption evidence.

## 4. Fieldwork decision discipline

For each candidate correction, write:

1. the exact recurring wrong turn;
2. the independent sessions in which it occurred;
3. whether it concerns level, authorship, communication, safety meaning, branch scope, omission, or conflict consequence;
4. the smallest proposed wording, focus, ordering, or disclosure change;
5. the new risk introduced by that correction;
6. the exact replay that will accept or reject it.

A single severe privacy or safety misunderstanding may justify an immediate stop and focused replay. Otherwise, do not redesign around one preference. Never “solve” comprehension by adding social features, private-state complexity, new permissions, or remote infrastructure.

## 5. P1 — sharing and organization, after P0 evidence

- [ ] Test delayed route re-finding after approximately one week with and without Source Notes.
- [ ] Determine whether direct-placement reasons reduce demand for premature private-label complexity.
- [ ] Keep folders human-curated and shareable.
- [ ] Preserve **Unfiled** as a legitimate, non-error state.
- [ ] Add a private label or saved view only when delayed re-finding evidence identifies a concrete unmet task.
- [ ] Keep note text out of engagement ranking, opaque recommendations, advertising, and behavioral profiles.
- [ ] Do not expand Source Notes into comments, reactions, profiles, follower graphs, notifications, or messaging.

P1 success is fewer wrong turns and better route recovery, not more captured metadata.

## 6. P2 — remote Nodes, separately reviewed

Remote mode remains explicit and separate from loopback. No P0 or P1 task may quietly depend on it.

- [ ] Require TLS and a persistent, reviewable Node identity.
- [ ] Bound allowed hosts, request sizes, artifact sizes, concurrency, and rates.
- [ ] Add expiring invitations and durable, inspectable revocation evidence.
- [ ] Keep public immutable-artifact publication routes separate from private APIs.
- [ ] Begin with reviewed immutable-artifact retrieval, not general remote control.
- [ ] Refuse default public bind, silent LAN discovery, UPnP, and hidden relay fallback.
- [ ] Threat-model logs, caches, invitation leakage, rollback, replay, and stale identity before implementation.

## 7. Lab only — WebRTC courier

- [ ] Transfer exactly one previously reviewed immutable artifact.
- [ ] Preserve Source Notes only through the native integrity-covered artifact.
- [ ] Make signaling, STUN, TURN, peer identity, artifact digest, size bound, and expiry visible before transfer.
- [ ] Refuse replay, identity mismatch, digest mismatch, timeout, over-bound size, and partial completion.
- [ ] Destroy session capability and transient transfer state after the bounded transfer.
- [ ] Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

A WebRTC experiment is not permission to add presence, chat, discovery, background availability, or an alternate unsigned artifact path.

## 8. Evidence packet required for every handoff

Keep these together, with no private participant data in the public artifact:

- source archive name and SHA-256;
- reconstruction provenance and changed-path inventory;
- final candidate ZIP name, byte size, and SHA-256;
- Roadcase manifest and direct-archive verification output;
- clean-extraction byte/mode verification output;
- Python/JavaScript parity output;
- native CLI, Node, Extension, Chromium, Firefox Release, and Firefox ESR commands and outputs;
- browser manifest permission comparison;
- sender and recipient disclosure captures reviewed separately;
- de-identified fieldwork evidence keyed by participant code;
- correction decisions, including rejected corrections and why they were rejected.

## 9. Research anchors used for this priority order

Use primary specifications as constraints, not as substitutes for product evidence:

- OPML 2.0 permits additional outline attributes but does not define a portable Source Notes meaning; native preservation plus explicit OPML omission evidence remains the interoperability boundary: <https://opml.org/spec2.opml>.
- JSON Canonicalization Scheme describes deterministic JSON serialization, but the existing ProgRSS native canonicalizer—not a new parallel serializer—must remain the integrity authority: <https://www.rfc-editor.org/rfc/rfc8785>.
- WCAG 2.2 reflow, focus, status-message, target-size, and related criteria guide test coverage; conformance still requires evaluation of the shipped product: <https://www.w3.org/TR/WCAG22/>.
- The WAI-ARIA Authoring Practices dialog pattern informs keyboard and focus observation for the conflict decision, while native semantics should be preferred where they work: <https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/>.
- Firefox-specific extension identifiers and compatibility belong in the generated sibling manifest rather than in Chromium behavior: <https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/manifest.json/browser_specific_settings>.
- Test whatever Chromium Stable, Firefox Release, and Firefox ESR are current on the day of fieldwork, and record exact builds; do not silently reuse a stale “current” version from this document.

<!-- END CURRENT-RUN-AUTHORITY rev0083-reconstructed-from-rev0080 -->


---

## Historical material retained from the supplied tree

# BOOTSTRAPROSE — ProgRSS rev0080 “Roadcase”

**Release:** rev0080 · **Product version:** 0.80.0 · **Vault schema:** 17 (unchanged)  
**Node-store schema:** `progrss.node-store.v4` (unchanged)  
**Roadcase packet:** `progrss.roadcase.v1`  
**Roadcase manifest:** `progrss.roadcase.manifest.v1`  
**Roadcase verification:** `progrss.roadcase.verify.v1`  
**Fieldwork kit:** `progrss.fieldwork-kit.v1` (unchanged)  
**Fieldwork report:** `progrss.fieldwork-report.v1` (unchanged)  
**Debrief report:** `progrss.fieldwork-debrief.v1` (unchanged)  
**Release date:** 2026-10-20  
**Release maxim:** **Bring the exact build. Verify it there. Leave no mystery behind.**

## `/run` interpretation

When this file is the active bootstrap, continue from the delivered rev0080
source tree and the separately sealed Roadcase packet. The source, tests,
deterministic archives, detached reports, clean-extraction replay, and
`Evidence/rev0080-Roadcase/` directory are the current implementation
authority.

Do not treat any of the following as equivalent to this release:

```text
the 22-byte empty file previously delivered under the rev0080 name
its matching checksum represented as proof of a complete ZIP
rev0079 Dispatch without the Roadcase builder and packet boundary
screenshots represented as native installed-browser acceptance
a browser smoke test represented as unfamiliar-person comprehension
an automated Fieldbook completion represented as a human session
a synthetic fixture represented as a real signed-in website
a copied personal browser profile represented as a clean test profile
an unpacked Extension installed by bypassing managed policy
a packet with changed or unexpected immutable members
a report containing participant identity or sensitive page material
one sender report mixed with recipient or diagnostic research
a Roadcase work directory represented as immutable release content
a local packet represented as a remote research service
```

Older bootstrap sections remain below as historical design and chain-of-
custody evidence. When an older section conflicts with this first rev0080
section, this section wins.

## Chain-of-custody correction

The active workspace contained a file named:

```text
ProgRSS-rev0080-2026.10.20-Roadcase.zip
```

That file was 22 bytes and contained no ZIP members.

Its SHA-256 was:

```text
8739c76e681f900923b900c9df0ef75cf421d39cabb54650c4b9ad19b6a76d85
```

The detached sidecar matched those empty bytes. The failure was therefore not
an incorrect checksum. The failure was that the checksum authenticated an
empty delivery.

Rev0080 was reconstructed from the last valid delivered archive:

```text
ProgRSS-rev0079-2026.10.20-Dispatch.zip
SHA-256:
581d649d0318d19e89ee3caa490888cd6eb34d5e7b911dfd9f3885606f2bfaaf
```

The prior empty-delivery evidence is preserved under:

```text
Evidence/rev0080-Roadcase-empty-delivery/
```

It is not silently deleted or rewritten.

## Current lineage

```text
Nightstand   dark fluorescent everyday reader + first loopback Node
Handshake   explicit summary-only Extension ↔ Node pairing
Exchange    Follow / Add route / Take branch artifact handoff
Confluence  three-way later-copy review
Receipt     first typed transactional Node write
Witness     one reviewed public acquisition
Capture     one bounded rendered-page observation
Pulse       foreground scheduling through Witness
Contour     explain why a selected section may hold or break
Perimeter   explain what the rendered page may leave outside
Threshold   require a decision about visible coverage limits
Drift       hold non-comparable partial windows
Anchor      replace one held baseline after explicit review
Bearing     explain repeated held windows before repair
Trace       show accepted and held observations as a trail
Fieldbook   record one private facilitated comprehension session
Debrief     compare several reports without scoring people
Crossroads  test the actual three-door Exchange recipient choice
Dispatch    test the sender's exact pre-send Exchange boundary
Roadcase    package the exact native fieldwork environment
```

## Current product truths

- The everyday Extension remains the default product.
- Dark fluorescent presentation remains the default; light mode remains
  explicit and persisted.
- Forced-colors removes decorative fluorescent treatment and reduced motion
  remains respected.
- Advanced Workbench remains secondary.
- The Extension remains useful without a Node.
- The Node and CLI remain useful without a browser.
- The ordinary Node remains literal-loopback only.
- Pairing remains summary-only, read-only, revocable, and separate from
  Exchange.
- Exchange remains one expiring reviewed artifact handoff rather than
  synchronization.
- The three recipient doors remain Follow updates, Add the complete route, and
  Take one branch.
- Selecting a door enters another review; it does not immediately follow or
  import.
- Exact existing sources are reused.
- Genuinely new sources begin paused.
- Following updates adds one durable public summary feed rather than the
  underlying source graph.
- Adding the complete route reviews all included feeds, watched-page recipes,
  and simple folders.
- Taking one branch creates an independent local excerpt without parent
  future-copy continuity.
- Private reading state, saved state, retained private text, page-watch
  evidence, browser authority, cookies, and private signing keys remain local.
- Sender and recipient Fieldbooks remain separate scenarios.
- Trace, Bearing, and Anchor Fieldbooks remain a third separate scenario.
- Debrief refuses incompatible scenarios, releases, and task sequences.
- Automated Fieldbook completion verifies the tool only.
- Roadcase adds no Extension permission.
- Roadcase adds no Node write endpoint.
- Roadcase adds no remote service, telemetry, or participant account.
- Roadcase does not install a daemon or operating-system service.
- Roadcase does not bypass managed browser policy.
- Roadcase does not claim native or human acceptance.
- Curation remains portable.
- Browser authority, scheduling, private reading state, observation evidence,
  and research notes remain local.

## Why Roadcase exists

The project had accumulated the implementation and research tools needed to
run native acceptance, but every release continued to record the same gap:

```text
unmanaged current Chromium not run
current native Firefox not run
Firefox ESR not run
unfamiliar sender sessions not run
unfamiliar recipient sessions not run
real screen-reader sessions not run
Braille, voice-control, and switch sessions not run
```

The blocker was no longer another conceptual reader feature. The blocker was
operational reproducibility:

```text
Which exact bytes should be installed?
How are those bytes verified before use?
Which browser-owned temporary installation flow is used?
Which local fixture is safe to use first?
How is a synthetic Node prepared without network access?
Which scenario and Fieldbook belong together?
How are reports kept private and compatible?
What is removed after the session?
Which evidence is automated and which evidence is genuinely human?
```

Roadcase answers those questions without changing product authority.

## Research basis

Official sources reviewed for this boundary are recorded in:

```text
Evidence/rev0080-Roadcase/RESEARCH.md
```

The resulting rules are:

- Chromium fieldwork uses its browser-owned `chrome://extensions` Load
  unpacked flow on an unmanaged test machine.
- Firefox fieldwork uses its browser-owned temporary add-on flow through
  `about:debugging`.
- Managed policy is not removed, disabled, or bypassed.
- Unpacked or temporary installation is used only with verified trusted local
  bytes.
- A fresh browser profile is used instead of copying a personal profile.
- Synthetic fixtures are used before a non-sensitive real-site scenario.
- Automated tests and real-user evaluation remain separate evidence classes.
- People with different disabilities, assistive technologies, and levels of
  experience are deliberately included.
- Cleanup and privacy review are part of the fieldwork packet, not afterthoughts.

## The Roadcase packet

The separate packet is generated through:

```sh
./progrss node roadcase \
  --output ProgRSS-Roadcase-rev0080.zip \
  --json
```

The command is:

```text
offline
deterministic
new-file-only
no-overwrite
browser-profile independent
browser-permission-store independent
Node-library independent
participant-identity free
telemetry free
```

The packet contains:

```text
START.html
README.md
INSTALL-CHROMIUM.md
INSTALL-FIREFOX.md
SESSION-CHECKLIST.md
CLEANUP.md
ROADCASE.json
MANIFEST.json
scripts/
fixtures/
release/
work/
```

## Exact product bytes

The packet contains the exact current:

```text
release/Extension/
release/Extension/Firefox/
release/CLI/
release/VERSION
release/REVISION
release/CODENAME
release/BOOTSTRAPROSE.md
release/ROADCASE-RELEASE.json
release/RELEASE-NOTES-rev0080-Roadcase.md
```

The packet does not contain a second hand-edited Extension variant.

The Firefox tree remains the generated sibling delivered with the release.

## Synthetic fixtures

The packet contains one synthetic private library:

```text
fixtures/roadcase-private-library.json
```

It contains:

```text
2 synthetic feed sources under example.test
1 synthetic watched page on literal loopback
2 simple folders
2 synthetic retained items
no personal account
no browser cookie
no credential
no private signing key
no participant identity
```

The example feed addresses are documentation/test domains and are not
contacted during packet preparation.

The watched page is:

```text
http://127.0.0.1:43162/virtual-window.html
```

It deliberately exposes two disjoint four-record DOM windows inside a declared
500-record collection.

It exists to exercise:

```text
Capture
Perimeter
Threshold
Drift
Bearing
Trace
Anchor
```

It contains no remote resources.

## Packet verification

After extraction:

```sh
python3 scripts/verify.py --restore-modes
```

The verifier checks:

```text
manifest schema
release identity
expected file presence
exact byte counts
SHA-256 of every immutable member
unexpected immutable files
expected executable modes on POSIX
```

The verifier refuses:

```text
missing files
changed files
extra immutable files
duplicate manifest paths
unsafe manifest paths
malformed digest rows
unsupported manifest schema
```

The packet manifest does not attempt to hash itself.

Trust in the manifest is anchored by the detached SHA-256 of the outer packet.

## Mutable boundary

The packet permits local runtime outputs only under:

```text
work/
```

Those outputs may include:

```text
synthetic Node SQLite store
locally exported Fieldbook reports
locally exported Debrief reports
facilitator notes deliberately saved by the facilitator
```

They are not immutable packet members.

Ordinary platform metadata and Python bytecode caches produced by local
execution are also excluded from immutable verification.

Every other unexpected immutable file is refused.

## Executable modes

ZIP extraction programs do not all restore POSIX executable bits.

The manifest records deterministic modes.

```sh
python3 scripts/verify.py --restore-modes
```

may restore those expected modes after digest verification.

Mode restoration changes only mode bits. It does not change file contents.

The CLI can always be invoked explicitly through Python:

```sh
python3 release/CLI/progrss.py --version
```

## Preflight

```sh
python3 scripts/preflight.py
```

Preflight performs:

```text
Roadcase immutable-member verification
packaged CLI version check
packaged CLI doctor
local browser executable discovery
explicit native/human not-run report
```

Browser discovery is informative.

A missing browser does not become a false native pass.

## Synthetic Node preparation

```sh
python3 scripts/prepare.py
```

Preparation creates:

```text
work/roadcase.sqlite3
```

from:

```text
fixtures/roadcase-private-library.json
```

Preparation performs no feed or watched-page request.

It is new-file-only.

If the store already exists, preparation does not overwrite it.

Start the Node explicitly:

```sh
python3 release/CLI/progrss.py node serve \
  work/roadcase.sqlite3 \
  --port 43161
```

The Node binds to literal loopback.

## Synthetic page fixture

In another terminal:

```sh
python3 scripts/serve_fixture.py
```

The fixture server binds to:

```text
127.0.0.1:43162
```

The fixture has two visible controls:

```text
Show records 41–44
Show records 145–148
```

Switching windows does not mean the earlier records were deleted.

The fixture says that explicitly.

## Chromium installation

The packet instruction uses:

```text
chrome://extensions
Developer mode
Load unpacked
select release/Extension
```

The facilitator must:

```text
use an unmanaged test machine
use a fresh profile
verify the packet first
confirm version 0.80.0
run only the planned scenario
remove the unpacked Extension after the session
close the dedicated profile
```

Roadcase does not use a command-line flag to bypass browser installation UI.

Roadcase does not modify managed policy.

## Firefox installation

The packet instruction uses:

```text
about:debugging
This Firefox
Load Temporary Add-on
select release/Extension/Firefox/manifest.json
```

The facilitator must:

```text
use a fresh profile
verify the packet first
confirm version 0.80.0
run only the planned scenario
remove the temporary add-on or restart Firefox
close the dedicated profile
```

Temporary installation is browser-owned.

Roadcase does not produce an unsigned persistent-installation claim.

## Fieldwork scenarios

### Dispatch

Person under observation:

```text
sender
```

Central question:

```text
Do they understand what may leave, what remains private,
and what has not happened yet before creating a handoff?
```

### Crossroads

Person under observation:

```text
recipient
```

Central question:

```text
Can they distinguish Follow updates,
Add the complete route,
and Take one branch?
```

### Trace / Bearing / Anchor

Person under observation:

```text
local Node administrator
```

Central question:

```text
Can they interpret non-comparable partial observations
and understand what baseline replacement changes?
```

These scenarios remain incompatible in Debrief.

## Fieldbook boundary

Fieldbook remains a separate facilitator sidecar.

It records:

```text
understood independently
understood after a neutral prompt
wrong turn or unsafe interpretation
not observed
```

It does not record:

```text
participant score
product score
pass percentage
engagement rank
participant account
participant identity field
```

Neutral prompting follows the independent attempt.

It does not erase the initial wrong turn.

## Report privacy

Before local export, the facilitator reviews notes for:

```text
names
contact details
account identifiers
credentials
sensitive page content
other identifying information
```

The report is exported only after explicit privacy acknowledgement.

Raw notes remain excluded from Debrief export.

The packet provides no automatic upload path.

## Debrief boundary

Debrief continues to refuse mixed:

```text
scenarios
scenario digests
product releases
task order
task wording
privacy boundaries
```

It surfaces:

```text
recurring wrong turns
prompt-dependent understanding
coverage gaps
no recurring signal yet
```

It does not assign a participant score or declare product acceptance.

## Cleanup

After the session:

```text
stop the Node
stop the synthetic page server
remove the unpacked or temporary Extension
close the dedicated profile
move deliberately retained reports out of work/
remove unexported drafts
run python3 scripts/cleanup.py
run python3 scripts/verify.py again
```

The cleanup helper removes only:

```text
work/
```

It does not silently delete deliberately exported evidence elsewhere.

It does not remove the browser Extension automatically.

The facilitator performs browser-owned removal explicitly.

## What Roadcase does not do

Roadcase is not:

```text
a remote research platform
a participant database
a recruitment system
a consent-management system
a screen or audio recorder
a browser-policy bypass
a persistent extension installer
a browser-profile copier
a telemetry client
a cloud account
a remote ProgRSS Node
a daemon or startup item
a recipient-tracking system
proof that any native session occurred
proof that any human understood the interface
```

## Security boundary

- Packet construction performs no network request.
- Packet verification performs no network request.
- Preflight performs no network request.
- Synthetic Node preparation performs no network request.
- The synthetic fixture server binds only to literal loopback.
- The Node binds only to literal loopback.
- No LAN discovery is added.
- No UPnP port opening is added.
- No remote report endpoint is added.
- No browser credential is packaged.
- No personal profile is packaged.
- No private production library is packaged.
- No private signing key is packaged.
- No participant identity is requested.

## Product authority unchanged

Roadcase adds no:

```text
required Extension permission
optional host-permission expansion
pairing capability
Exchange capability
Node write operation
source acquisition operation
schedule
automatic publication
automatic upload
remote synchronization
```

The product continues to enforce the authority boundaries established by the
prior releases.

## Native and human evidence classes

The release report distinguishes:

```text
automated packet construction
clean-extraction packet replay
browser-engine rendering
installed unmanaged Chromium
installed native Firefox
installed native Firefox ESR
unfamiliar-person session
screen-reader session
Braille session
voice-control session
switch session
```

One class cannot be silently substituted for another.

## P0 — completed in Roadcase

- [x] Detect the earlier empty rev0080 delivery.
- [x] Preserve its exact byte count and checksum.
- [x] Reconstruct from the verified rev0079 archive.
- [x] Add `progrss.roadcase.v1`.
- [x] Add `progrss.roadcase.manifest.v1`.
- [x] Add `progrss.roadcase.verify.v1`.
- [x] Add `progrss node roadcase`.
- [x] Keep packet construction offline.
- [x] Make packet output new-file-only.
- [x] Build packet deterministically.
- [x] Include exact Chromium Extension bytes.
- [x] Include exact generated Firefox bytes.
- [x] Include exact CLI and Node runtime.
- [x] Include one synthetic private library.
- [x] Include one literal-loopback virtualized page fixture.
- [x] Include Chromium installation instructions.
- [x] Include Firefox installation instructions.
- [x] Include session checklist.
- [x] Include cleanup instructions.
- [x] Add immutable-member verification.
- [x] Add byte-count verification.
- [x] Add SHA-256 verification.
- [x] Add unexpected immutable-file refusal.
- [x] Add deterministic mode recording.
- [x] Add optional mode restoration.
- [x] Allow mutable outputs only under `work/`.
- [x] Ignore local Python caches without treating them as release members.
- [x] Add packaged CLI version and doctor preflight.
- [x] Add offline synthetic Node initialization.
- [x] Add explicit synthetic fixture server.
- [x] Add explicit cleanup helper.
- [x] Add tamper-refusal tests.
- [x] Add deterministic two-build tests.
- [x] Add clean-extraction verification tests.
- [x] Add no-participant and no-telemetry assertions.
- [x] Record native and human sessions as not run.

## P0 — next: conduct native sessions

- [ ] Run exact packet on unmanaged current Chromium.
- [ ] Run exact packet on current Firefox.
- [ ] Run exact packet on Firefox ESR.
- [ ] Conduct unfamiliar-sender Dispatch sessions.
- [ ] Conduct unfamiliar-recipient Crossroads sessions.
- [ ] Conduct Trace, Bearing, and Anchor sessions.
- [ ] Include real screen-reader users.
- [ ] Include real Braille users.
- [ ] Include voice-control users.
- [ ] Include switch-style operation.
- [ ] Include 200–400% zoom.
- [ ] Include forced colors.
- [ ] Include reduced motion.
- [ ] Include fatigue and interruption.
- [ ] Use the synthetic fixture first.
- [ ] Use one public virtualized page.
- [ ] Use one non-sensitive signed-in test page.
- [ ] Privacy-review every report.
- [ ] Keep scenarios separate.
- [ ] Compare compatible reports in Debrief.
- [ ] Make one smallest correction supported by a recurring wrong turn.
- [ ] Repeat the same task after that correction.

## P0 — questions the sessions must answer

- [ ] Does Follow updates clearly mean one summary feed?
- [ ] Does Add the complete route clearly mean the underlying source graph?
- [ ] Does Take one branch clearly mean an independent local excerpt?
- [ ] Do recipients understand that genuinely new sources begin paused?
- [ ] Do people understand that review contacts none of the listed sites?
- [ ] Do senders understand what remains private?
- [ ] Do senders mistake a public address for automatic upload?
- [ ] Do recipients mistake an invitation for pairing?
- [ ] Does Different window sound like deletion?
- [ ] Does Moving rendered window sound certain?
- [ ] Does Open Anchor sound like an immediate write?
- [ ] Do people understand that Capture transfers no browser login?
- [ ] Do people understand that Capture creates no schedule?
- [ ] Can people find exact evidence only when asked?

## P1 — evidence-driven corrections

Only after native sessions:

- [ ] Revise three-door wording when recurring recipient evidence supports it.
- [ ] Revise sender privacy wording when Dispatch supports it.
- [ ] Design recipe repair only from recurring Trace/Bearing failure.
- [ ] Build Pinpoint only when bounded section proposals repeatedly fail.
- [ ] Keep each correction small enough to test again.
- [ ] Preserve the non-advanced default.
- [ ] Keep exact protocol evidence under Advanced.

## P1 — organization and Source Notes

- [ ] Recover or independently reimplement Source Notes.
- [ ] Keep notes short and plain text.
- [ ] Scope notes to one folder/source relationship.
- [ ] Keep notes outside acquisition identity.
- [ ] Preserve notes in independent branch excerpts.
- [ ] Cover notes with source-list integrity.
- [ ] Report note omission from OPML.
- [ ] Include note disagreement in Confluence review.
- [ ] Run one-week delayed re-finding studies.
- [ ] Add private labels only when those studies support them.
- [ ] Add explicit saved-query views.
- [ ] Preserve Unfiled as a legitimate state.
- [ ] Avoid engagement ranking.
- [ ] Avoid opaque automatic taxonomy.

## P2 — remote Nodes

- [ ] Keep remote mode separate from loopback.
- [ ] Require TLS and persistent Node identity.
- [ ] Bound hosts, requests, artifacts, and rates.
- [ ] Add expiring invitations and durable revocation.
- [ ] Keep public publication routes separate from private APIs.
- [ ] Begin with reviewed immutable-artifact retrieval.
- [ ] Test reverse proxies and self-hosting.
- [ ] No default public bind.
- [ ] No silent LAN discovery.
- [ ] No UPnP port opening.

## Lab — WebRTC courier

- [ ] Transfer exactly one reviewed immutable artifact.
- [ ] Use bounded signed offer metadata.
- [ ] Use bounded signed answer metadata.
- [ ] Make signaling explicit.
- [ ] Make STUN use visible.
- [ ] Make TURN use visible.
- [ ] Compare QR friction.
- [ ] Compare copy/paste friction.
- [ ] Compare ordinary HTTPS friction.
- [ ] Compare relay friction.
- [ ] Compare WebRTC friction.
- [ ] Refuse replay.
- [ ] Refuse identity mismatch.
- [ ] Refuse digest mismatch.
- [ ] Refuse timeout.
- [ ] Refuse partial completion.
- [ ] Destroy the session after transfer.
- [ ] Never require WebRTC for ordinary reading.
- [ ] Never require WebRTC for ordinary sharing.
- [ ] Never require WebRTC for native fieldwork.

## Verification requirements

Before sealing the release:

- [ ] Run Roadcase unit tests.
- [ ] Build two packet candidates.
- [ ] Compare packet candidates byte-for-byte.
- [ ] Extract one packet cleanly.
- [ ] Restore and verify expected modes.
- [ ] Run packet preflight.
- [ ] Initialize synthetic Node offline.
- [ ] Verify mutable `work/` does not invalidate immutable verification.
- [ ] Tamper with one manifested member and verify refusal.
- [ ] Add one unexpected immutable file and verify refusal.
- [ ] Render dark and light `START.html`.
- [ ] Run CLI and Node tests.
- [ ] Run Extension static and runtime harnesses.
- [ ] Run rendered everyday reader.
- [ ] Run rendered Advanced Workbench.
- [ ] Compile every delivered Python file.
- [ ] Parse every delivered JavaScript file.
- [ ] Parse every delivered JSON file.
- [ ] Parse every delivered shell file.
- [ ] Build the main release twice deterministically.
- [ ] Compare main archives byte-for-byte.
- [ ] Verify ZIP CRC and safe paths.
- [ ] Extract main release cleanly.
- [ ] Compare every delivered file and executable mode.
- [ ] Rebuild Roadcase from clean main-release bytes.
- [ ] Compare the rebuilt packet byte-for-byte.
- [ ] Record native and human sessions as not run.

## Native and human evidence

Unless actual sessions occur, the release record must say:

```text
Installed unmanaged Chromium:        NOT RUN
Current native Firefox:              NOT RUN
Native Firefox ESR:                  NOT RUN
Unfamiliar sender sessions:          NOT RUN
Unfamiliar recipient sessions:       NOT RUN
Trace/Bearing/Anchor sessions:       NOT RUN
Real screen-reader sessions:         NOT RUN
Braille sessions:                    NOT RUN
Voice-control sessions:              NOT RUN
Switch sessions:                     NOT RUN
```

Those entries must not be converted to passes by browser smoke tests.

## Decision for the next revision

The next revision should not add another speculative reader or sharing layer.

The next coherent work is:

1. use this exact Roadcase packet on unmanaged Chromium, Firefox, and Firefox
   ESR;
2. run Dispatch, Crossroads, and Trace/Bearing/Anchor with unfamiliar people;
3. include people using real assistive technologies;
4. privacy-review reports;
5. compare only compatible reports in Debrief;
6. make one smallest interface correction supported by recurring evidence;
7. run the same task again after the correction.

## End of rev0080 bootstrap continuation

---

# BOOTSTRAPROSE — ProgRSS rev0079 “Dispatch”

**Release:** rev0079 · **Product version:** 0.79.0 · **Vault schema:** 17 (unchanged)  
**Node-store schema:** `progrss.node-store.v4` (unchanged)  
**Exchange preview:** `progrss.node.exchange-preview.v1` (unchanged)  
**Exchange handoff:** `progrss.node.exchange.v1` (unchanged)  
**Fieldwork kit:** `progrss.fieldwork-kit.v1` (unchanged)  
**Fieldwork report:** `progrss.fieldwork-report.v1` (unchanged)  
**New Fieldbook scenario:** `exchange-sender-review`  
**Recipient Fieldbook scenario:** `exchange-three-doors` (unchanged)  
**Debrief report:** `progrss.fieldwork-debrief.v1` (unchanged)  
**Release date:** 2026-10-20  
**Release maxim:** **Know what leaves before you send the link.**

## `/run` interpretation

When this file is the active bootstrap, continue from the delivered rev0079
source tree. The source, tests, deterministic archive, release report,
clean-extraction replay, and `Evidence/rev0079-Dispatch/` directory are the
current implementation authority.

Do not treat any of the following as equivalent to this release:

```text
rev0058 Branch alone
the incomplete historical chat transcript
the unrecovered rev0059 Source Notes file card
rev0078 Crossroads without the sender-side review scenario
a generic sharing questionnaire not derived from an exact Exchange preview
a mockup in place of the actual Node sender review
a created handoff represented as merely reviewed
an uploaded publication represented as locally prepared
a Fieldbook containing a route title, public address, digest, or preview token
a sender Fieldbook report mixed with recipient or Trace/Bearing/Anchor reports
an automated Fieldbook completion represented as human comprehension
one synthetic report represented as a sender population finding
an archive named in prose but absent from the active runtime
```

Older bootstrap sections remain below as historical design and chain-of-
custody evidence. When an older section conflicts with this first rev0079
section, this section wins.

## Current lineage

```text
Nightstand   dark fluorescent everyday reader + first loopback Node
Handshake   explicit summary-only Extension ↔ Node pairing
Exchange    Follow / Add route / Take branch artifact handoff
Confluence  three-way later-copy review
Receipt     first typed transactional Node write
Witness     one reviewed public acquisition
Capture     one bounded rendered-page observation
Pulse       foreground scheduling through Witness
Contour     explain why a selected section may hold or break
Perimeter   explain what the rendered page may leave outside
Threshold   require a decision about visible coverage limits
Drift       hold non-comparable partial windows
Anchor      replace one held baseline after explicit review
Bearing     explain repeated held windows before repair
Trace       show accepted and held observations as a trail
Fieldbook   record one private facilitated comprehension session
Debrief     compare several reports without scoring people
Crossroads  test the actual three-door Exchange recipient choice
Dispatch    test the sender's exact pre-send Exchange boundary
```

## Current product truths

- The everyday Extension remains the default product.
- Dark fluorescent presentation remains the default; light mode remains
  explicit and persisted.
- Forced-colors removes decorative fluorescent treatment and reduced motion
  remains respected.
- Advanced Workbench remains secondary.
- The Extension remains useful without a Node; the Node and CLI remain useful
  without a browser.
- The ordinary Node remains literal-loopback only.
- Pairing remains summary-only, read-only, process-lifetime, and revocable.
- Exchange remains one expiring reviewed artifact handoff rather than
  synchronization.
- The sender reviews one exact prepared artifact set before creating a handoff.
- Preparing or reviewing a share does not create or consume a handoff.
- Preparing or reviewing a share does not publish or upload anything.
- Preparing or reviewing a share contacts none of its listed feeds or pages.
- Preparing or reviewing a share creates no schedule.
- The three recipient doors remain Follow updates, Add the complete route, and
  Take one branch.
- Selecting a recipient door retrieves one bounded artifact for review before
  any follow or import decision.
- Exact existing sources are reused and genuinely new sources begin paused.
- Following updates adds one durable public summary feed rather than the
  underlying source graph.
- Adding the complete route reviews all included feeds, watched-page recipes,
  and simple folders.
- Taking one branch creates an independent local excerpt without parent
  future-copy continuity.
- Private reading state, saved state, retained private text, page-watch
  evidence, browser authority, cookies, and private signing keys remain
  excluded from Exchange artifacts.
- A public source-list or feed address is a declaration of the address the
  sender intends to control; the Node does not upload to it.
- A ready-to-host static package is a local download; it is not automatically
  hosted.
- Creating a handoff creates one thirty-minute, revocable artifact capability;
  it is not pairing, administration, public hosting, or synchronization.
- The first compatible Extension Origin to review the invitation binds it for
  its remaining lifetime.
- Expiry or revocation stops future invitation retrieval; it does not remotely
  erase artifacts already downloaded or material already adopted locally.
- The sender receives no recipient-library, reading-history, or browser-session
  visibility.
- Dispatch Fieldbook is a separate facilitator sidecar; it is not sender
  product UI.
- Dispatch Fieldbook requests no participant identity and performs no
  telemetry or automatic persistence.
- Dispatch omits route, curator, source, folder, public-address, library,
  artifact-digest, Node-identity, and preview-capability identity.
- Crossroads remains the separate recipient Fieldbook.
- Debrief refuses mixed scenario digests, releases, and task sequences.
- Automated Fieldbook completion verifies the research tool only and is not
  human acceptance.
- Curation remains portable; browser authority, scheduling, private reading
  state, observation evidence, and research notes remain local.

## Why Dispatch exists

Crossroads made the recipient's three-door decision observable. It did not
answer whether a sender understands the equally consequential boundary before
creating the invitation.

A sender may otherwise confuse:

```text
preparing artifacts with publishing them
entering a public address with uploading to it
downloading a static package with hosting it
creating an invitation with permanent publication
an expiring artifact capability with Node administration
a durable summary feed with the temporary handoff URL
revocation with remote deletion
source-list review with contacting every listed site
recipient adoption with continuing synchronization
```

Dispatch studies those distinctions against the actual Node share review. It
adds no corrective wizard, warning modal, default change, automatic upload, or
sharing dashboard before evidence exists.

## Research basis

The sender-task design follows these reviewed principles:

- People should understand what they are being asked to do and what happens
  next before consequential participation or disclosure.
- Important confidentiality and privacy information should not be hidden in
  confusing or excessively dense wording.
- Warnings and consent explanations should use understandable language.
- Content should be reduced where possible without removing information needed
  for the decision.
- Controls should have descriptive labels and predictable effects.
- Focus order should preserve meaning and operability.
- An option should not create an unexpected change of context merely by being
  focused or selected.
- The product—not the participant—is being tested.
- A neutral prompt follows the independent attempt; it does not erase the
  original wrong turn.
- Automated completion verifies mechanics, not comprehension.

Reviewed source notes are in `Evidence/rev0079-Dispatch/RESEARCH.md`.

## One exact active preview

The authenticated Node generates the sender Fieldbook only from one active,
unexpired `progrss.node.exchange-preview.v1` preview.

The preview must state:

```text
state = preview
network = false
writes = false
automatic = false
complete-route choice available
the complete Exchange privacy exclusion set
```

The Node hashes the preview capability for lookup. Generating the Fieldbook:

```text
does not consume the preview
does not extend the preview
does not create a handoff
does not contact a source
does not mutate the Node library
does not write the Node store
does not create a publication
does not upload a static site
does not start Pulse
does not pair an Extension
```

The offline CLI accepts one strict preview document but receives no live
capability and performs no network access.

## Bounded scenario shape

The scenario digest includes only bounded consequence shape:

```text
release version, revision, and codename
Follow updates availability
complete-route availability
branch availability
bounded branch-choice count
bounded source, feed, page-watch, folder, and recent-update counts
source-list artifact availability
recent-updates artifact availability
static-site artifact availability
whether a public source-list address is configured
whether a public page address is configured
whether a durable feed address is configured
bounded included-category count
bounded excluded-category count
whether the preview expires
non-automatic effect
```

It deliberately excludes the values that would identify the route, its
publisher, its sources, or the live capability.

## Privacy-minimized Fieldbook

The generated HTML excludes:

```text
route title
curator name
curator note
source names
source hostnames
source addresses
folder IDs
folder paths
public source-list address
public recent-updates address
public page address
library filename
library digest
artifact filename
artifact digest
Node origin
Node fingerprint
preview token
handoff capability
browser credential
browser permission state
participant identity field
```

It also contains no:

```text
fetch
XMLHttpRequest
WebSocket
EventSource
WebRTC
sendBeacon
remote script
remote stylesheet
remote image
remote font
service worker
form submission
localStorage
sessionStorage
IndexedDB
cookie
telemetry
automatic upload
automatic persistence
```

Facilitator notes remain in the current page until deliberate privacy-reviewed
local export.

## The sender task set

The all-capabilities scenario contains sixteen tasks. Follow, branch, public-
address, and static-package wording adapts when those capabilities are honestly
unavailable.

### Task 1 — Review is not send

**Goal:** Explain what **Review this share** already did.

**Intended interpretation:** The Node prepared bounded artifacts locally for
review. Nothing was published, sent, followed, imported, or changed.

**Wrong turns to record:**

- Says the route is already public.
- Says the recipient has already received it.
- Says the library changed.

### Task 2 — Included material

**Goal:** Explain what the native source-list artifact can carry.

**Intended interpretation:** Source recipes, simple folder routes, curator
wording, and bounded recent-update summaries when selected.

**Wrong turns to record:**

- Says only feed URLs travel.
- Expects arbitrary executable code.
- Cannot distinguish curation from private reading state.

### Task 3 — Excluded private state

**Goal:** Explain what remains private.

**Intended interpretation:** Read state, saved state, retained private text,
page-watch observations, browser cookies, permissions, and private signing keys
remain excluded.

**Wrong turns to record:**

- Expects reading history to travel.
- Expects browser login or cookies to travel.
- Expects private retained text to travel.

### Task 4 — Recipient doors

**Goal:** Identify the distinct recipient consequences offered by this exact
review.

**Intended interpretation:** Every available door is visible; unavailable
doors are honestly absent rather than simulated.

**Wrong turns to record:**

- Treats every door as the same import.
- Looks for one generic Share button.
- Assumes an unavailable door appears later.

### Task 5 — Durable Follow updates

When available, the sender should explain that the recipient ultimately
follows one durable public summary-feed address—not the temporary Node
invitation and not all underlying sources.

When unavailable, the sender should explain that no durable feed is configured
and the Node does not silently convert the expiring invitation into one.

### Task 6 — Complete route

**Intended interpretation:** The recipient later reviews all included feeds,
watched-page recipes, and simple folders. Exact existing sources are reused;
genuinely new sources begin paused.

**Wrong turns to record:**

- Calls it one summary feed.
- Expects every source to fetch immediately.
- Expects duplicate exact sources.

### Task 7 — Independent branch

When available, the sender should explain that one selected folder closure
becomes an independent local route without parent future-copy continuity or a
counterfeit subset signature.

When unavailable, no branch task is invented.

### Task 8 — Public source-list address

When configured, the sender should explain that the address declares where
they intend to host the artifact. The Node does not upload there or prove that
the sender controls it.

When absent, the sender should explain that the private handoff does not invent
or host a durable public source-list address.

### Task 9 — Static publication package

When available, the sender should explain that downloading the package creates
local script-free files for deliberate hosting. It does not publish or upload
them.

When absent, the sender should explain that the preview did not create one
silently.

### Task 10 — Create thirty-minute handoff

**Intended interpretation:** One expiring, revocable artifact invitation is
created. It is not public hosting, Node administration, pairing, or continuous
synchronization.

### Task 11 — First-review binding

**Intended interpretation:** The first compatible Extension Origin to review
the invitation binds it for the remaining lifetime. It does not become a
public bearer page usable by arbitrary websites.

### Task 12 — Expiry and revocation

**Intended interpretation:** They stop future invitation retrieval. They do not
remotely erase artifacts already downloaded or material a recipient already
adopted locally.

### Task 13 — Network and schedules

**Intended interpretation:** Preparation and handoff creation contact none of
the listed feeds or pages and create no recurring schedule.

### Task 14 — Recipient privacy

**Intended interpretation:** The sender cannot inspect the recipient's library,
read state, saved state, browser session, or later local use.

### Task 15 — Advanced evidence on demand

**Intended interpretation:** Bounded source and folder contents, artifact sizes,
and digests can be found when requested without making hashes prerequisite
vocabulary for the ordinary sharing decision.

### Task 16 — Complete sender boundary

**Intended interpretation:** Merely preparing and reviewing the share performed
no upload, public posting, recipient delivery, source request, schedule,
pairing, synchronization, or library write.

## Observational outcomes

Every task retains Fieldbook's four outcomes:

```text
Understood independently
Understood after a neutral prompt
Wrong turn or unsafe interpretation
Not observed
```

There is no participant score, product score, pass percentage, engagement
rank, or automatic usability verdict.

A prompt-assisted answer remains distinct from independent understanding.
Facilitator notes are bounded to 600 characters and excluded from a later
Debrief export.

## Review before report export

The facilitator must:

```text
complete an outcome for every task
open Review local report
inspect task outcomes and notes
confirm no participant identity or sensitive material was recorded
acknowledge the privacy boundary
then download JSON or Markdown deliberately
```

Editing a task or note invalidates the current review and clears the export
gate.

The report schema remains:

```text
progrss.fieldwork-report.v1
```

Debrief refuses mixing `exchange-sender-review` with:

```text
exchange-three-doors
trace-bearing-anchor
another release
another task sequence
another task wording
another outcome vocabulary
another privacy boundary
```

## Node interface

Inside the existing pre-send Exchange preview:

```text
Research this sender review
  Dispatch Fieldbook
  Observe what the sender thinks will leave
  Download sender fieldwork sheet
```

The control remains secondary to the actual share review and Create handoff
action.

Authenticated route:

```text
POST /api/v1/exchange-sender-fieldwork-kits
Content-Type: application/json
Authorization: Bearer <Node administrator capability>

{
  "previewToken": "…"
}
```

The JSON object must contain exactly `previewToken`.

The response is one self-contained HTML attachment with the scenario schema
and digest in headers.

## CLI parity

```sh
./progrss node exchange-sender-fieldbook \
  exchange-preview.json \
  --output ProgRSS-Exchange-Sender-Fieldbook.html
```

Machine-readable generation evidence:

```sh
./progrss node exchange-sender-fieldbook \
  exchange-preview.json \
  --output ProgRSS-Exchange-Sender-Fieldbook.html \
  --json
```

The command is:

```text
offline
strict-schema
new-file-only
no-overwrite
Node-library independent
browser-profile independent
browser-permission-store independent
```

## Relationship to Crossroads

Dispatch and Crossroads deliberately observe different actors and different
moments.

```text
Dispatch
  Actor: sender
  Moment: after artifact preparation, before handoff creation
  Question: what will leave, what stays private, what has not happened yet?

Crossroads
  Actor: recipient
  Moment: after invitation review
  Question: which of the three consequences matches the recipient's goal?
```

A sender report must not be interpreted as recipient comprehension, and a
recipient report must not be interpreted as sender comprehension.

## Authority matrix

| Action | Dispatch Fieldbook effect |
|---|---|
| Read active preview shape | Yes, bounded and identity-minimized |
| Consume or extend preview | No |
| Create handoff | No |
| Revoke handoff | No |
| Publish static site | No |
| Upload artifacts | No |
| Contact listed sources | No |
| Start Pulse | No |
| Pair Extension | No |
| Read recipient library | No |
| Change sender library | No |
| Write Node store | No |
| Request participant identity | No |
| Send telemetry | No |
| Persist automatically | No |

## Security and privacy invariants

- The Node endpoint remains protected by the administrator bearer capability.
- Existing exact `Host`, `Origin`, and no-CORS checks remain in force.
- The live preview token is accepted only in the authenticated request body.
- The token is not embedded into the generated Fieldbook.
- The generated sheet contains no active network primitive.
- The sheet contains no route, source, folder, public-address, library,
  artifact-digest, Node-identity, or capability identity.
- The sheet does not create a handoff.
- The offline CLI receives a captured review document, not a live capability.
- The output path must not already exist.
- Fieldbook reports remain local until deliberate export.
- Raw facilitator notes remain excluded from Debrief exports.

## Accessibility and presentation

Dispatch reuses Fieldbook's:

```text
dark fluorescent default
persistent light mode
forced-colors treatment
reduced-motion treatment
visible keyboard focus
semantic fieldsets and legends
narrow-screen reflow
print layout
polite status announcements
review-before-export boundary
```

The actual Node review remains available in another window. The Fieldbook does
not duplicate secret route contents or turn the research sheet into product
navigation.

## Validation boundary

Automated tests may prove:

```text
strict preview-schema acceptance
complete privacy-exclusion requirement
secret omission
bounded scenario shape
adaptive task set
authenticated Node download
no preview consumption
no library or store mutation
new-file-only CLI behavior
review and privacy gating
local JSON report download
dark and light rendering
deterministic packaging
clean-extraction execution
```

They cannot prove:

```text
that an unfamiliar sender understands the wording
that a screen-reader user can complete the task efficiently
that a voice-control user can target every control
that revocation language is understood
that public-address wording does not imply upload
that the distinction between invitation and durable feed is clear
that the three recipient consequences are understood from the sender side
```

## P0 — completed in Dispatch

- [x] Add `exchange-sender-review`.
- [x] Derive it from one exact active Exchange preview.
- [x] Require an offline, read-only, non-automatic preview.
- [x] Require the complete-route choice.
- [x] Require the complete Exchange privacy exclusion set.
- [x] Include only bounded consequence shape in the scenario digest.
- [x] Omit route identity.
- [x] Omit curator identity and wording.
- [x] Omit source names, hostnames, and addresses.
- [x] Omit folder IDs and paths.
- [x] Omit public source-list, feed, and page addresses.
- [x] Omit library identity.
- [x] Omit artifact filenames and digests.
- [x] Omit Node identity.
- [x] Omit preview capability.
- [x] Request no participant identity.
- [x] Add the authenticated Node download.
- [x] Add strict `POST /api/v1/exchange-sender-fieldwork-kits` handling.
- [x] Do not consume or extend the preview.
- [x] Add offline `progrss node exchange-sender-fieldbook` parity.
- [x] Keep output new-file-only and no-overwrite.
- [x] Add sixteen all-capabilities sender tasks.
- [x] Adapt Follow wording when no durable feed is available.
- [x] Omit branch task when no populated branch is available.
- [x] Adapt public-address wording when no public source-list address exists.
- [x] Adapt static-package wording when no package exists.
- [x] Retain review-before-export and privacy confirmation.
- [x] Keep sender and recipient scenario digests separate.
- [x] Add no Extension permission.
- [x] Add no pairing authority.
- [x] Add no Node-store migration.
- [x] Add no Node-library or store write.
- [x] Add no listed-site request.
- [x] Add no schedule.
- [x] Add no publication or upload.
- [x] Add no telemetry or automatic persistence.
- [x] Preserve dark and light modes.
- [x] Preserve forced-colors and reduced-motion behavior.
- [x] Update Chromium, Firefox, tired-reader, and facilitator protocols.
- [x] Update project metadata and release evidence.
- [x] Build deterministically and replay from clean extraction.

## P0 — next: conduct native sender sessions

- [ ] Install this exact archive on unmanaged current Chromium.
- [ ] Install the generated sibling on current Firefox and Firefox ESR.
- [ ] Recruit people unfamiliar with ProgRSS Exchange terminology.
- [ ] Use one preview with all three recipient doors.
- [ ] Use one private-only preview without a durable feed or static site.
- [ ] Ask whether review already published or sent anything.
- [ ] Ask what material is included.
- [ ] Ask what remains private.
- [ ] Ask what a public address does.
- [ ] Ask whether a static package is already hosted.
- [ ] Ask what the thirty-minute handoff grants.
- [ ] Ask whether the temporary invitation is the durable updates feed.
- [ ] Ask what first-review Origin binding means.
- [ ] Ask what expiry can stop.
- [ ] Ask what revocation cannot erase.
- [ ] Ask whether listed sources were contacted.
- [ ] Ask whether a schedule was created.
- [ ] Ask whether the sender can inspect the recipient library.
- [ ] Include screen-reader and Braille users.
- [ ] Include voice-control and switch-style operation.
- [ ] Include 200–400% zoom, forced colors, reduced motion, fatigue, and
      interruption conditions.
- [ ] Compare several privacy-reviewed sender reports in Debrief.
- [ ] Make one smallest wording or hierarchy change supported by recurring
      observed evidence.
- [ ] Run the same sender tasks again after that change.

## P0 — sender/recipient paired fieldwork

After separate sender and recipient sessions exist:

- [ ] Compare sender expectations with recipient interpretation without merging
      their reports into one scenario.
- [ ] Check whether senders believe Follow updates exposes underlying sources.
- [ ] Check whether recipients believe the sender can see adoption or reading.
- [ ] Check whether both sides interpret expiry consistently.
- [ ] Check whether both sides interpret revocation consistently.
- [ ] Check whether public-static and private-expiring delivery are
      distinguishable.
- [ ] Check whether the phrase **complete route** communicates the source graph
      rather than one feed.
- [ ] Check whether **independent branch** communicates the lack of future-copy
      continuity.
- [ ] Change one shared piece of wording only when evidence appears on both
      sides or the product intentionally needs actor-specific wording.

## P1 — sender-side publication comprehension

- [ ] Study source-list public address versus actual deployment.
- [ ] Study recent-updates feed address versus temporary invitation.
- [ ] Study static package download versus hosting.
- [ ] Study signed bytes versus curator identity or source safety.
- [ ] Study public static publication versus private expiring handoff.
- [ ] Study copy, QR, and native share-sheet delivery separately from artifact
      semantics.
- [ ] Keep sender publication research separate from recipient adoption
      research in Debrief.

## P1 — organization and re-finding

- [ ] Run delayed re-finding studies after one week.
- [ ] Keep folders human-curated and shareable.
- [ ] Add private many-to-many labels only after re-finding evidence.
- [ ] Add explicit saved-query views.
- [ ] Preserve **Unfiled** as a legitimate state.
- [ ] Keep duplicate, stale-source, and route-split suggestions reversible.
- [ ] Avoid engagement ranking.
- [ ] Avoid opaque automatic taxonomy.

## P1 — Source Notes recovery

The historical handoff describes short, folder/source-scoped plain-text
curator reasons. Its transcript does not contain the generated archive bytes,
so the implementation still requires artifact recovery or independent
reimplementation and verification.

- [ ] Recover the actual rev0059 archive or independently reimplement it.
- [ ] Keep notes short, plain-text, and folder/source scoped.
- [ ] Keep notes outside acquisition identity.
- [ ] Preserve notes in branch excerpts.
- [ ] Cover notes with native source-list integrity.
- [ ] Report their omission from OPML.
- [ ] Include note disagreement in Confluence review.
- [ ] Test whether senders understand that a note is curation context, not a
      fetch rule.
- [ ] Test whether recipients distinguish curator wording from ProgRSS-computed
      consequences.
- [ ] Do not turn notes into comments, reactions, profiles, or notifications.

## P1 — evidence-driven recipe repair

A recipe-repair writer remains blocked until real Trace/Bearing/Anchor reports
expose the recurring failure.

Any later operation must:

- [ ] Begin from one exact Trace/Bearing review.
- [ ] Name one exact watched-page source.
- [ ] Show current and proposed declarative recipes.
- [ ] Explain which observed failure motivates the proposal.
- [ ] Show matched and ignored specimens.
- [ ] Require an unselected acknowledgement.
- [ ] Establish a fresh baseline.
- [ ] Invent no historical change alert.
- [ ] Preserve the earlier recipe and snapshot.
- [ ] Use a strong reviewed-library precondition.
- [ ] Be atomic, idempotent, receipted, and recoverable.
- [ ] Accept no arbitrary shared JavaScript.
- [ ] Expose no generic selector or JSON Patch writer.

## P2 — remote Nodes

- [ ] Keep remote mode explicit and separate from loopback.
- [ ] Require TLS and persistent Node identity.
- [ ] Bound hosts, requests, artifacts, and rates.
- [ ] Add expiring invitations and durable revocation.
- [ ] Separate public publication routes from private APIs.
- [ ] Begin with reviewed immutable-artifact retrieval.
- [ ] Test reverse proxies and self-hosting.
- [ ] No default public bind.
- [ ] No silent LAN discovery.
- [ ] No UPnP port opening.
- [ ] No basic “enter an IP address and hope” workflow.

## Lab — WebRTC courier

- [ ] Transfer exactly one reviewed immutable artifact.
- [ ] Use bounded signed offer-and-answer metadata.
- [ ] Make signaling, STUN, and TURN visible.
- [ ] Compare QR, copy/paste, HTTPS, relay, and WebRTC friction.
- [ ] Refuse replay, identity mismatch, digest mismatch, timeout, and partial
      completion.
- [ ] Destroy the session after transfer.
- [ ] Never require WebRTC for ordinary reading, sharing, Capture, Witness,
      Pulse, Trace, Anchor, Fieldbook, Debrief, Crossroads, or Dispatch.

## Verification policy

A release is not sealed from prose alone.

The final release must demonstrate:

```text
strict Fieldbook unit tests
strict authenticated Node route tests
CLI new-file-only and overwrite refusal
secret and identity omission
full rendered sender Fieldbook interaction
privacy-gated local report download
dark and light rendering
existing Crossroads recipient regression
existing Debrief scenario-isolation regression
all principal Node and Extension suites
all delivered Python compilation
all delivered JavaScript syntax
all delivered JSON parsing
all shell syntax
byte-identical deterministic builds
ZIP integrity and safe member paths
no symlinks or nested archives
no runtime databases or caches
clean-extraction byte and mode comparison
principal test replay from extracted bytes
```

Native installed-browser and unfamiliar-person work remains a separate truth
boundary. A managed-policy skip is a skip. A generated Firefox package is not
native Firefox acceptance. A rendered browser smoke is not an unfamiliar-
sender session. A synthetic local report is not a human finding.

## Next coherent boundary

The next product boundary is not another speculative sharing control.

It is:

```text
run Dispatch with actual unfamiliar senders
run Crossroads with actual unfamiliar recipients
compare privacy-reviewed reports separately in Debrief
identify one recurring wrong turn
make one smallest wording or hierarchy correction
rerun the same goal
```

Automatic publishing, recipient analytics, centralized directories, follower
graphs, broad remote Node authority, automatic repair, and WebRTC-required
sharing remain outside that evidence boundary.

---
# BOOTSTRAPROSE — ProgRSS rev0078 “Crossroads”

**Release:** rev0078 · **Product version:** 0.78.0 · **Vault schema:** 17 (unchanged)  
**Node-store schema:** `progrss.node-store.v4` (unchanged)  
**Exchange handoff:** `progrss.node.exchange.v1` (unchanged)  
**Fieldwork kit:** `progrss.fieldwork-kit.v1` (unchanged)  
**Fieldwork report:** `progrss.fieldwork-report.v1` (unchanged)  
**New Fieldbook scenario:** `exchange-three-doors`  
**Debrief report:** `progrss.fieldwork-debrief.v1` (unchanged)  
**Release date:** 2026-10-20  
**Release maxim:** **Observe the choice, not the person.**

## `/run` interpretation

When this file is the active bootstrap, continue from the delivered rev0078 source tree. The source, tests, deterministic archive, release report, clean-extraction replay, and `Evidence/rev0078-Crossroads/` directory are the current implementation authority.

Do not treat any of the following as equivalent to this release:

```text
rev0058 Branch alone
the incomplete historical chat transcript
the unrecovered rev0059 Source Notes file card
rev0077 Debrief without the Exchange recipient scenario
a generic questionnaire not derived from an active handoff
a mockup in place of the actual Extension choice screen
an automated Fieldbook completion represented as a human session
one synthetic report represented as recipient comprehension
an invitation capability copied into a facilitator sheet
a Fieldbook report mixed with a different scenario digest
a response naming an archive absent from the active runtime
```

Older bootstrap sections remain below as historical design and chain-of-custody evidence. When an older section conflicts with this first rev0078 section, this section wins.

## Current lineage

```text
Nightstand   dark fluorescent everyday reader + first loopback Node
Handshake   explicit summary-only Extension ↔ Node pairing
Exchange    Follow / Add route / Take branch artifact handoff
Confluence  three-way later-copy review
Receipt     first typed transactional Node write
Witness     one reviewed public acquisition
Capture     one bounded rendered-page observation
Pulse       foreground scheduling through Witness
Contour     explain why a selected section may hold or break
Perimeter   explain what the rendered page may leave outside
Threshold   require a decision about visible coverage limits
Drift       hold non-comparable partial windows
Anchor      replace one held baseline after explicit review
Bearing     explain repeated held windows before repair
Trace       show accepted and held observations as a trail
Fieldbook   record one private facilitated comprehension session
Debrief     compare several reports without scoring people
Crossroads  test the actual three-door Exchange recipient choice
```

## Current product truths

- The everyday Extension remains the default product.
- Dark fluorescent presentation remains the default; light mode remains explicit and persisted.
- Forced-colors removes decorative fluorescent treatment and reduced motion remains respected.
- Advanced Workbench remains secondary.
- The Extension remains useful without a Node; the Node and CLI remain useful without a browser.
- The ordinary Node remains literal-loopback only.
- Pairing remains summary-only, read-only, process-lifetime, and revocable.
- Exchange remains one expiring reviewed artifact handoff rather than synchronization.
- The three recipient doors remain Follow updates, Add the complete route, and Take one branch.
- Selecting a door retrieves one bounded artifact for review before any follow or import decision.
- Reviewing an Exchange does not contact its listed sources and creates no schedule.
- Exact existing sources are reused and genuinely new sources begin paused.
- Following updates adds one durable summary feed rather than the underlying source graph.
- Adding the complete route reviews all included feeds, watched-page recipes, and simple folders.
- Taking one branch creates an independent local excerpt without parent future-copy continuity.
- Private reading state, retained private text, browser authority, cookies, and private signing keys remain excluded.
- Crossroads Fieldbook is a separate facilitator sidecar; it is not recipient product UI.
- Crossroads Fieldbook requests no participant identity and performs no telemetry or automatic persistence.
- The Exchange Fieldbook omits curator names, route identity, source identity, URLs, folder paths, exchange IDs, and capabilities.
- Debrief continues to refuse mixed scenario digests, releases, and task sequences.
- Automated Fieldbook completion verifies the tool only and is not human acceptance.
- Curation remains portable; browser authority, scheduling, private reading state, and research notes remain local.

## Why Crossroads exists

Exchange already presents the project’s central next-generation RSS decision. A recipient may follow one summary feed, adopt the complete source route, or take one independent branch. Those consequences are intentionally different, but automated tests cannot establish that unfamiliar people understand them.

Crossroads makes that question observable without modifying the handoff itself. The facilitator uses one private local sheet while the participant uses the actual installed Extension. The sheet asks goal-based questions, records independent understanding before neutral prompts, and exports a privacy-reviewed local report.

The release deliberately does not change the three labels, reorder the doors, introduce a wizard, add automatic recommendations, or hide unavailable choices. Those changes require observed evidence.

## Human research basis

The task design follows these reviewed principles:

- Use clear, believable goals that answer the research question.
- Do not give away the answer by naming the control in the task.
- Reassure participants that the service—not the person—is being tested.
- Observe and listen before intervening.
- Use a neutral prompt only after an independent attempt.
- Include people who use assistive technologies and, where practical, their own setups.
- Treat automated checks as necessary but insufficient for accessibility evaluation.
- Keep optional browser authority inside the user action where its purpose is visible.

Reviewed sources are recorded under `Evidence/rev0078-Crossroads/RESEARCH.md`.

## One active handoff, one exact scenario

The Node generates the recipient Fieldbook only from one active `progrss.node.exchange.v1` handoff. It does not generate a free-floating survey. The scenario digest covers bounded consequence facts:

```text
product release
availability of Follow updates
availability of Add the complete route
availability of Take one branch
number of branch choices
source, feed, watched-page, folder, and recent-update counts
expiring, revocable, and non-automatic handoff facts
```

The digest deliberately excludes identity and secret material. Two handoffs with the same bounded choice shape can use compatible task wording without revealing who curated the route or where it is hosted.

## Privacy-minimized Fieldbook

The generated HTML excludes:

```text
curator name
route title and curator note
source names
source hostnames
source and publication URLs
folder IDs and paths
library filename and digest
Node origin and fingerprint
exchange ID
invitation capability
browser credential or permission state
participant identity field
```

It also contains no `fetch`, `XMLHttpRequest`, WebSocket, EventSource, WebRTC, service worker, remote script, remote stylesheet, remote image, localStorage, sessionStorage, IndexedDB, cookie, form submission, telemetry, or automatic upload. Notes stay in page memory until the facilitator deliberately exports a local report.

## The fifteen-task all-doors scenario

When all three recipient doors are available, the Fieldbook contains fifteen tasks. Follow and branch tasks are omitted when those choices are genuinely unavailable, producing a different scenario digest and task sequence.

### Task 1 — Explain what the invitation grants

**Neutral prompt:** Ask whether opening this invitation pairs the whole Extension to the sender's Node or grants administrator access.

**Intended interpretation:** They say it is one expiring, revocable artifact handoff—not general pairing, synchronization, or Node administration.

**Wrong turns to record:**

- Calls it permanent pairing
- Expects the sender to see their library
- Assumes administrator access

### Task 2 — Find the available choices

**Neutral prompt:** Ask the participant to identify the distinct things they can do with this handoff.

**Intended interpretation:** They identify each available consequence without treating the cards as file-format choices.

**Wrong turns to record:**

- Looks for one generic Add button
- Treats every card as the same import
- Cannot tell which choices are unavailable

### Task 3 — Explain what choosing a door does first

**Neutral prompt:** Ask whether selecting one choice immediately follows or imports anything.

**Intended interpretation:** They say the selected artifact is retrieved and reviewed first; a later explicit action performs Follow or Add.

**Wrong turns to record:**

- Believes one click commits
- Confuses preview with follow
- Believes review contacts every listed site

### Task 4 — Explain Follow updates

**Neutral prompt:** Ask what will be added after the later Follow decision.

**Intended interpretation:** They say one durable summary feed is added, not the underlying feeds, watched pages, folders, or Node relationship.

**Wrong turns to record:**

- Expects every underlying source
- Treats the temporary invitation as the followed feed
- Expects Node pairing

### Task 5 — Choose updates without adopting the route

**Neutral prompt:** Give this goal: read the curator's future summary updates without adding all underlying sources. Ask which door fits.

**Intended interpretation:** They choose Follow updates and can explain why the complete route is unnecessary.

**Wrong turns to record:**

- Chooses complete route
- Chooses branch
- Looks for a fourth subscription option

### Task 6 — Explain Add the complete route

**Neutral prompt:** Ask what the complete-route path reviews and may later add.

**Intended interpretation:** They say it reviews all included feeds, watched-page recipes, and folders; exact existing sources are reused and new sources begin paused.

**Wrong turns to record:**

- Calls it one summary feed
- Expects every source to start fetching immediately
- Assumes private reading state arrives

### Task 7 — Choose the complete curated source graph

**Neutral prompt:** Give this goal: adopt the curator's complete set of underlying sources and retain the publication relationship. Ask which door fits.

**Intended interpretation:** They choose Add the complete route rather than Follow updates or the independent branch path.

**Wrong turns to record:**

- Chooses Follow updates
- Chooses branch while expecting parent continuity
- Assumes the invitation itself imported everything

### Task 8 — Explain Take one branch

**Neutral prompt:** Ask what happens to the selected folder section after adoption.

**Intended interpretation:** They say it becomes an independent local route containing the selected folder closure, without the parent's future-copy relationship or a counterfeit subset signature.

**Wrong turns to record:**

- Expects future parent copies to rewrite it
- Treats it as separately signed
- Expects source-by-source picking

### Task 9 — Choose one independent section

**Neutral prompt:** Give this goal: adopt only one useful nested section and keep it independent from the parent publication. Ask which door fits.

**Intended interpretation:** They choose Take one branch and distinguish it from both the summary feed and complete route.

**Wrong turns to record:**

- Chooses complete route
- Chooses Follow updates
- Expects continuing parent synchronization

### Task 10 — Explain reused and paused sources

**Neutral prompt:** Ask what happens when an exact source already exists and what happens to a genuinely new source.

**Intended interpretation:** They say exact sources are reused and new sources begin paused until separately enabled.

**Wrong turns to record:**

- Expects duplicates
- Expects immediate fetching
- Believes paused means deleted

### Task 11 — Explain review network effects

**Neutral prompt:** Ask whether reviewing the handoff contacts the feeds and watched pages listed inside it.

**Intended interpretation:** They say review retrieves only the chosen handoff artifact and does not contact its listed sources.

**Wrong turns to record:**

- Believes every listed site was checked
- Believes the browser granted all site permissions
- Believes a schedule was created

### Task 12 — Explain what does not travel

**Neutral prompt:** Ask whether read state, saved state, retained private article text, page observations, browser cookies, or signing keys arrive with the route.

**Intended interpretation:** They say those remain private and are excluded from the handoff.

**Wrong turns to record:**

- Expects reading history
- Expects browser login or cookies
- Expects private retained text

### Task 13 — Explain expiry and revocation

**Neutral prompt:** Ask whether the invitation remains a permanent access path after the handoff expires or the sender revokes it.

**Intended interpretation:** They say the invitation is temporary and revocable; already adopted local material remains local.

**Wrong turns to record:**

- Calls the invitation permanent
- Expects revocation to erase the recipient's local library
- Assumes future synchronization

### Task 14 — Find exact evidence only when asked

**Neutral prompt:** Ask the participant to inspect source names, hostnames, routes, counts, and integrity details without making them prerequisite vocabulary for choosing a door.

**Intended interpretation:** They can find bounded evidence when requested while still deciding from ordinary consequences.

**Wrong turns to record:**

- Cannot find contents
- Feels required to interpret hashes first
- Treats hostname review as proof that the source is safe

### Task 15 — State the complete handoff boundary

**Neutral prompt:** Ask what the handoff did merely by being opened and reviewed.

**Intended interpretation:** They say it created no automatic follow, import, listed-site fetch, schedule, pairing, or library write.

**Wrong turns to record:**

- Believes something was already added
- Believes automatic sync started
- Believes the sender gained recipient access

## Outcome vocabulary

Every task uses exactly four observational outcomes:

```text
Understood independently
Understood after a neutral prompt
Wrong turn or unsafe interpretation
Not observed
```

There is no participant score, percentage grade, engagement rank, or automatic product verdict. The same report schema remains `progrss.fieldwork-report.v1`, allowing Debrief to compare only exact compatible scenarios.

## Recipient consequence matrix

| Door | First effect | Later reviewed consequence | Does not do |
|---|---|---|---|
| Follow updates | Retrieve and preview the recent-updates feed artifact | Follow one durable public feed | Add underlying sources, folders, page recipes, pairing, or Node access |
| Add the complete route | Retrieve and verify the source-list artifact | Reuse exact sources; add new sources paused; retain publication continuity | Fetch listed sites during review or import private reading state |
| Take one branch | Retrieve and verify the source list, then select one populated folder closure | Create an independent local excerpt with reused sources and paused additions | Retain parent future-copy continuity or counterfeit a subset signature |

## Network and authority matrix

| Action | Node handoff request | Listed-site requests | Browser host authority | Library write | Schedule |
|---|---:|---:|---:|---:|---:|
| Open invitation review | 1 bounded loopback review | 0 | loopback only when explicitly requested | 0 | 0 |
| Choose Follow updates | 1 feed-artifact retrieval | 0 | no listed-site authority | 0 during preview | 0 |
| Choose Add route | 1 source-list retrieval | 0 | no listed-site authority | 0 during review | 0 |
| Choose Take branch | 1 source-list retrieval | 0 | no listed-site authority | 0 during review | 0 |
| Later Follow decision | normal feed authority for the durable feed | only the followed feed when later checked | runtime optional host authority | typed local addition | not automatically |
| Later route/branch adoption | 0 listed-site requests during import | 0 | none granted by the artifact | reviewed local import | 0 |

## Node endpoint

The authenticated local administrator endpoint is:

```http
POST /api/v1/exchange-fieldwork-kits
Content-Type: application/json
Authorization: Bearer <node-admin-capability>

{"exchangeId":"…"}
```

The body must contain exactly `exchangeId`. The exchange must still be active. The endpoint returns one self-contained HTML attachment and the scenario digest in a response header. It does not bind the recipient Origin, consume the invitation, change the handoff, write the Node store, or contact any source.

## Offline CLI parity

The same sidecar can be generated from one captured Exchange review:

```sh
./progrss node exchange-fieldbook exchange-review.json \
  --output ProgRSS-Exchange-Fieldbook.html
```

The command is offline, new-file-only, strict-schema, no-overwrite, browser-profile independent, and Node-library independent. It does not accept an invitation token as input and does not contact the Node.

## Debrief isolation

Debrief retains strict compatibility checks across:

- scenario name
- scenario digest
- product version, revision, and codename
- task IDs, titles, order, and outcome vocabulary
- privacy and facilitator boundaries

A Crossroads recipient report cannot be mixed with a Trace/Bearing/Anchor report. A two-door Crossroads report cannot be mixed with a three-door report. This prevents counts from silently combining different questions.

## Accessibility and presentation

- The Fieldbook uses semantic fieldsets and legends for tasks.
- Every outcome remains a labelled radio choice.
- Keyboard-visible focus is retained.
- Dark fluorescent presentation remains default and light mode remains available.
- Forced-colors replaces decorative styling with system colors.
- Reduced-motion disables nonessential movement.
- Narrow layouts reflow without requiring horizontal page scrolling.
- Print layout removes interactive controls and preserves task text.
- Completion and export results use polite status messages.
- The actual Extension—not the Fieldbook—is the interface being evaluated.

## Threat and misuse review

### Capability leakage

The invitation token remains in the actual handoff URL. Crossroads never copies it into the Fieldbook, scenario digest, report, or filename.

### Curator profiling

Curator name, route title, note, hostnames, and source titles are excluded. The study records comprehension of consequences, not opinions about a curator.

### Participant scoring

Only four observable task outcomes exist. The report contains no score, rank, completion percentage, or pass flag.

### Silent network activity

The Fieldbook CSP blocks connections and the Node generation endpoint performs no source request.

### Mixed-study analysis

Debrief refuses a different scenario digest, release, or task sequence.

### Facilitator coaching

Neutral prompts are separate from independent outcomes, and prompts are hidden behind disclosure until needed.

### Private-state confusion

Tasks explicitly test that read state, saved state, retained text, browser authority, and private keys do not travel.

### Permission confusion

The study distinguishes a temporary handoff from summary-only pairing and from later optional site authority.

### Overclaiming automation

Rendered smoke tests are recorded as tool regression only; human and assistive-technology sessions remain unexecuted.

### Research-note leakage

Notes remain local, require privacy review before export, and do not enter source lists, OPML, pairing, Pulse, or publications.

## Human acceptance protocol

1. Install the sealed Extension on unmanaged current Chromium.
2. Install the generated sibling on current Firefox and Firefox ESR.
3. Create one active handoff with all three doors available.
4. Open the invitation in the installed Extension.
5. Keep the Fieldbook in a separate facilitator window.
6. Reassure the participant that ProgRSS is being tested, not them.
7. Give one believable goal at a time without naming the expected control.
8. Record an independent outcome before any prompt.
9. Use the supplied neutral prompt only when needed.
10. Record the wrong turn rather than coaching it away.
11. Run keyboard-only and screen-reader sessions.
12. Include Braille, voice-control, switch-style, high-zoom, forced-colors, reduced-motion, fatigue, and interruption conditions.
13. Review notes for identifying or sensitive material before export.
14. Load only compatible reports into Debrief.
15. Make the smallest wording or hierarchy change supported by recurring evidence.
16. Rerun the same scenario after the change.

## Prioritized checklist

### P0 — completed in Crossroads

- [x] Add the `exchange-three-doors` Fieldbook scenario.
- [x] Derive the scenario from one actual active Exchange handoff.
- [x] Reflect actual Follow and branch availability.
- [x] Add fifteen goal-based tasks when all three doors are present.
- [x] Adapt the task set when a door is genuinely unavailable.
- [x] Omit curator, route, source, URL, folder, Node, exchange, and capability identity.
- [x] Add the authenticated Node download control under the active handoff.
- [x] Add strict `POST /api/v1/exchange-fieldwork-kits` handling.
- [x] Add offline `progrss node exchange-fieldbook` parity.
- [x] Keep output new-file-only and no-overwrite.
- [x] Retain Fieldbook review-before-export and privacy confirmation.
- [x] Retain Debrief strict scenario isolation.
- [x] Add no Extension permission or paired authority.
- [x] Add no Node-store migration or library write.
- [x] Add no site request, schedule, follow, import, or automatic synchronization.
- [x] Render and test dark and light Fieldbook modes.
- [x] Export and validate one local Crossroads report.
- [x] Update Chromium, Firefox, tired-reader, and facilitator protocols.
- [x] Update BOOTSTRAPROSE as the current `/run` authority.
- [x] Build deterministically and replay critical paths from clean delivery bytes.

### P0 — next: conduct native recipient sessions

- [ ] Run the exact sealed archive on unmanaged current Chromium.
- [ ] Run current Firefox and Firefox ESR.
- [ ] Recruit people unfamiliar with ProgRSS source-list terminology.
- [ ] Test all three goal choices without naming the expected door.
- [ ] Ask whether selecting a door immediately changes the library.
- [ ] Ask whether review contacted listed sites or created a schedule.
- [ ] Ask what starts paused and what is reused.
- [ ] Ask what expiry and revocation change.
- [ ] Ask whether the invitation is pairing or administrator access.
- [ ] Include real screen-reader and Braille users.
- [ ] Include voice-control and switch-style operation.
- [ ] Include high zoom, forced colors, reduced motion, fatigue, and interruption.
- [ ] Compare several privacy-reviewed reports in Debrief.
- [ ] Change wording or hierarchy only after a recurring observed wrong turn.
- [ ] Retest the exact same scenario after the smallest change.

### P1 — sender-side sharing comprehension

- [ ] Test whether senders understand what private state is excluded.
- [ ] Test whether senders understand public publication versus private invitation.
- [ ] Test invitation expiry, revocation, and already-adopted local copies.
- [ ] Test whether sender wording distinguishes one feed from a source graph.
- [ ] Keep sender and recipient scenarios separate in Debrief.

### P1 — organization and curation

- [ ] Run delayed re-finding studies after one week.
- [ ] Keep folders human-curated and shareable.
- [ ] Add private many-to-many labels only after re-finding evidence.
- [ ] Add explicit saved-query views.
- [ ] Preserve Unfiled as a legitimate state.
- [ ] Keep duplicate, stale-source, and route-split suggestions reversible.
- [ ] Avoid engagement ranking and opaque automatic taxonomy.
- [ ] Recover or independently reimplement Source Notes rather than silently claiming unavailable bytes.

### P2 — remote Nodes

- [ ] Keep remote mode explicit and separate from loopback.
- [ ] Require TLS and persistent Node identity.
- [ ] Bound hosts, requests, artifacts, and rates.
- [ ] Add expiring invitations and durable revocation.
- [ ] Separate public publication routes from private APIs.
- [ ] Begin with reviewed immutable-artifact retrieval.
- [ ] Test reverse proxies and self-hosting.
- [ ] No default public bind, silent LAN discovery, or UPnP.

### Lab — WebRTC courier

- [ ] Transfer exactly one reviewed immutable artifact.
- [ ] Use bounded signed offer-and-answer metadata.
- [ ] Make signaling, STUN, and TURN visible.
- [ ] Compare QR, copy/paste, HTTPS, relay, and WebRTC friction.
- [ ] Refuse replay, identity mismatch, digest mismatch, timeout, and partial completion.
- [ ] Destroy the session after transfer.
- [ ] Never require WebRTC for ordinary reading, sharing, Capture, Witness, Pulse, or Crossroads.

## Verification boundary

Working-tree evidence for rev0078 includes:

```text
PASS 17/17 acquisition and Capture continuity cases
PASS  9/9 Pulse/Cadence cases
PASS 46/46 direct CLI library cases
PASS  4/4 Fieldbook cases
PASS  4/4 Debrief cases
PASS 13/13 Node-store cases
PASS 20/20 Node HTTP and operation cases
PASS 29/29 publication, integrity, continuity, and merge cases
PASS 30/30 command-line cases
PASS 172 total distinct Python cases
PASS 58/58 Extension structural/static checks
PASS Chromium and generated Firefox background harnesses
PASS shared-folder core, acquisition, and vault-conflict harnesses
PASS twelve-case browser Capture fixture garden
PASS rendered everyday reader and Advanced Workbench
PASS rendered Node and complete Crossroads Fieldbook workflow
```

Native installed-browser and unfamiliar-person results are not converted into passes. They remain explicitly not run until executed on suitable hosts.

## Release handoff

The sealed rev0078 archive, checksum sidecar, release report, final verification record, release notes, generated example Fieldbook, and screenshots are the handoff artifacts. Rebuild and clean-extraction details appear in the release report.

---

# Historical bootstrap record follows

# BOOTSTRAPROSE — ProgRSS rev0077 “Debrief”

**Release:** rev0077 · **Product version:** 0.77.0 · **Vault schema:** 17 (unchanged)  
**Node-store schema:** `progrss.node-store.v4` (unchanged)  
**Fieldwork kit:** `progrss.fieldwork-kit.v1` (unchanged)  
**Fieldwork report:** `progrss.fieldwork-report.v1` (unchanged)  
**Debrief kit:** `progrss.fieldwork-debrief-kit.v1` (new)  
**Debrief report:** `progrss.fieldwork-debrief.v1` (new)  
**Bearing review:** `progrss.node.bearing-review.v2` (unchanged)  
**Observation trail:** `progrss.node.bearing-trace.v1` (unchanged)  
**Capture artifact:** `progrss.browser-capture.v4` (unchanged)  
**Anchor operation:** `replace-held-page-baseline` (unchanged)  
**Release date:** 2026-10-20  
**Release maxim:** **Find patterns. Do not score people.**

## `/run` interpretation

When this file is the active bootstrap, continue from the delivered rev0077
source tree. The source, schemas, tests, deterministic archive, release report,
clean-extraction replay, and `Evidence/rev0077-Debrief/` directory are the
current implementation authority.

Do not treat any of the following as equivalent to this release:

```text
rev0058 Branch alone
an incomplete no-scroll historical transcript
an unavailable rev0059 Source Notes file card
rev0067 Cadence prose without its missing delivered package
rev0068 Pulse with its stale distributed bootstrap heading
rev0074 Bearing without Trace
rev0075 Trace without Fieldbook
rev0076 Fieldbook without multi-report analysis
an image without matching source bytes
a response naming files absent from the active runtime
an automated Fieldbook represented as a human session
a Debrief generated from synthetic reports represented as product acceptance
one report treated as a population finding
an aggregate count treated as a participant score
```

Older bootstrap sections remain below as historical design and chain-of-
custody evidence. When an older section conflicts with this first rev0077
section, this section wins.

## Current lineage

```text
Nightstand   dark fluorescent everyday reader + first loopback Node
Handshake   explicit summary-only Extension ↔ Node pairing
Exchange    Follow / Add route / Take branch handoff
Confluence  three-way later-copy review
Receipt     first typed transactional Node write
Witness     one reviewed public acquisition
Capture     one bounded rendered-page observation
Pulse       foreground scheduling through Witness
Contour     explain why a selected section may hold or break
Perimeter   explain what the rendered page may leave outside
Threshold   require a decision about visible coverage limits
Drift       hold non-comparable partial windows
Anchor      replace one held baseline after explicit review
Bearing     explain repeated held windows before repair
Trace       show accepted and held observations as a trail
Fieldbook   record one private facilitated comprehension session
Debrief     compare several reports without scoring people
```

## Current product truths

- The everyday Extension remains the default product.
- Dark fluorescent presentation remains the default.
- Light mode remains an explicit persisted option.
- Forced-colors removes decorative fluorescent treatment.
- Reduced-motion remains respected.
- Advanced Workbench remains secondary.
- The Extension remains independently useful without a Node.
- The CLI and Node remain independently useful without a browser.
- The ordinary Node binds only to literal loopback.
- The portable library remains `progrss.private.v1` JSON.
- SQLite remains a local transaction and evidence mechanism.
- Pairing remains summary-only, read-only, process-lifetime, and revocable.
- Exchange remains artifact-scoped rather than continuous synchronization.
- Witness remains the only public Node acquisition path.
- Capture remains one deliberate exact-page browser observation.
- Pulse schedules only Node-reproducible Witness sources.
- Drift may hold a partial observation rather than invent change.
- Anchor remains the only held-baseline replacement writer.
- Bearing and Trace remain read-only evidence.
- Fieldbook records one facilitated session in a self-contained local page.
- Debrief compares compatible Fieldbook reports in a separate local page.
- Fieldbook and Debrief request no participant identity.
- Fieldbook and Debrief perform no telemetry or automatic upload.
- Debrief exports no raw facilitator notes.
- No automated test is represented as completed human acceptance.
- Curation remains portable; browser authority and observation history remain local.

## Why Debrief exists

Fieldbook made one session recordable. It did not answer the next product
question:

> Which wrong turns recur across several sessions, and what is the smallest
> product change worth testing next?

Without a dedicated boundary, facilitators would be pushed toward one of two
bad extremes:

```text
A spreadsheet that silently accumulates participant identity and raw notes

or

A dashboard that turns sparse observations into a score and calls it usability
```

Debrief refuses both.

It provides one bounded local workspace for:

```text
loading several compatible Fieldbook reports
checking that they describe the same scenario and task sequence
ignoring exact duplicates
counting the four observed outcomes per task
reviewing raw notes locally
writing a bounded product finding
writing the smallest product response worth testing
reviewing privacy before export
exporting findings without the raw notes
```

The workspace is infrastructure for analysis. It is not evidence that sessions
have occurred.

## Human question

Debrief is designed around the facilitator’s actual questions:

```text
How many reports are loaded?
Are these reports about the same product scenario?
Did this wrong turn recur?
Did people understand only after a neutral prompt?
Was this task actually observed often enough to discuss?
What did the facilitator write locally?
What finding is supported by these reports?
What is the smallest product response to try next?
Have identifying or sensitive details been removed from the export?
Am I describing these sessions, or making a broader claim the evidence cannot support?
```

It deliberately does not ask:

```text
What score did this participant receive?
Which participant performed best?
Did ProgRSS pass usability?
What percentage should appear on a product dashboard?
Which report should be uploaded to a central service?
What automatic repair should run now?
```

## Fieldbook and Debrief are separate tools

### Fieldbook

One facilitator uses Fieldbook during one session.

It records:

```text
one exact scenario
one exact release
one outcome per task
bounded local notes
three facilitator-boundary confirmations
one privacy-reviewed local report
```

### Debrief

A facilitator or product team uses Debrief after several reports exist.

It records:

```text
one exact shared scenario
one exact shared product release
aggregate task outcomes
bounded product findings
bounded product-response hypotheses
one disposition per task
interpretation boundaries
one privacy-reviewed local debrief
```

### Neither

Neither tool:

```text
records participant identity
uploads data
persists automatically
contacts the watched site
contacts the browser
changes a Node library
repairs a recipe
replaces a baseline
starts Pulse
creates a schedule
changes Extension pairing authority
```

## Report input contract

Debrief accepts only strict `progrss.fieldwork-report.v1` objects.

The exact top-level fields are:

```text
schema
scenario
scenarioDigest
release
generatedFromKitAt
completedAt
outcomes
tasks
facilitatorBoundary
privacy
```

Unexpected fields are refused.

This is an intentional privacy boundary. A report containing an unexpected
`participantName`, email address, source URL field, or other extension does not
silently flow into analysis.

## Fieldwork report validation

For each report, Debrief verifies:

```text
schema is exactly progrss.fieldwork-report.v1
scenario is bounded non-empty text
scenarioDigest is one lowercase SHA-256
release contains exactly version, revision, and codename
outcome counts are bounded non-negative integers
tasks are a bounded non-empty list
task IDs are unique and use a restricted vocabulary
task titles are bounded
outcomes use the fixed four-value vocabulary
notes are bounded to 600 normalized characters
reported outcome totals match the task rows
all three facilitator boundaries are true
participant identity was not recorded
automatic persistence is false
telemetry is false
network is false
```

A report that fails any one of those checks is refused.

## Compatibility contract

Reports loaded into one Debrief must agree on:

```text
scenario
scenario digest
release version
release revision
release codename
ordered task IDs
ordered task titles
```

Debrief refuses mixed scenarios rather than flattening them into plausible
counts.

Examples of refused combinations:

```text
Trace/Bearing/Anchor report mixed with a future sharing report
rev0076 task wording mixed with a changed rev0078 task sequence
same task IDs with different titles
same scenario label with a different scenario digest
reports from different product releases
```

A future cross-release longitudinal tool would need a separate reviewed schema.
Debrief does not guess that two task lists are equivalent.

## Duplicate handling

Each normalized report receives a canonical SHA-256 digest.

An exact duplicate:

```text
is ignored
is not counted as another session
is reported as a duplicate locally
is not treated as corroborating evidence
```

Near-duplicates are not guessed. Two reports with different completion times,
outcomes, or notes remain distinct reports.

## Capacity bounds

Debrief accepts at most:

```text
40 reports
256,000 bytes per report
4,000,000 total selected bytes
12 Fieldbook tasks in the current scenario
600 characters per raw facilitator note
500 characters per finding
500 characters per product response
```

These are implementation and review bounds, not research-quality thresholds.

## Four observed outcomes

Debrief preserves Fieldbook’s outcome vocabulary exactly:

```text
Understood independently
Understood after a neutral prompt
Wrong turn or unsafe interpretation
Not observed
```

It does not convert them into a grade.

### Understood independently

The person completed or explained the task without a neutral prompt.

### Understood after a neutral prompt

The person reached the intended interpretation after a bounded prompt that did
not teach the answer.

### Wrong turn or unsafe interpretation

The person selected, stated, or acted on an interpretation that could cause
confusion, misplaced authority, or an unsafe consequence.

### Not observed

The task was not completed or not meaningfully observed in that session.

## Aggregate counts

For each task, Debrief counts the four observed outcomes among the loaded
reports.

The counts mean only:

> These outcomes appeared in these loaded local reports.

They do not mean:

```text
population prevalence
statistical significance
participant ability
product quality score
release acceptance
accessibility conformance
```

## Review signals

Debrief derives bounded review prompts from the loaded reports.

### One report only

There is only one compatible report.

Consequence:

```text
review the observation
avoid calling it recurring
collect more sessions before generalizing
```

### Recurring wrong turn to review

The same task contains wrong-turn outcomes in more than one loaded report.

Consequence:

```text
treat the pattern as a product question
read the local notes
write a bounded finding
propose the smallest response worth testing
```

This label is not a product verdict.

### Prompt-dependent understanding to review

The task was understood after neutral prompting in multiple reports, or prompt
dependence is otherwise prominent enough to warrant review.

Consequence:

```text
inspect whether the interface itself supplies the missing cue
avoid converting facilitator coaching into product success
```

### Coverage gap

Too many reports mark the task **Not observed** for the loaded evidence to
support a meaningful product conclusion.

Consequence:

```text
plan another session or task condition
avoid inferring understanding or confusion
```

### No recurring signal yet

The current reports do not expose a repeated wrong turn, repeated prompt
dependence, or obvious coverage gap.

Consequence:

```text
do not manufacture a finding
record No product change yet or More sessions needed
```

## Signal limitations

Review signals:

```text
are deterministic
use only loaded report outcomes
are not probabilities
are not confidence scores
are not statistical tests
are not participant rankings
are not automatic product decisions
```

The facilitator remains responsible for the finding.

## Local raw-note review

Each task can disclose the bounded facilitator notes from the loaded reports.

The disclosure states that the notes are:

```text
local
report-numbered rather than participant-named
available for interpretation
excluded from export
potentially sensitive and therefore subject to privacy review
```

Debrief does not automatically summarize or quote those notes into the final
finding.

The facilitator writes new bounded language after reviewing them.

## Product dispositions

Every task requires one explicit disposition before review:

```text
Product change to try
More sessions needed
No product change yet
Not reviewed
```

### Product change to try

Use when the loaded evidence supports testing one small interface, wording, or
hierarchy change.

It is a hypothesis for another iteration—not an automatic mutation.

### More sessions needed

Use when the task lacks sufficient coverage or the observations conflict.

### No product change yet

Use when the current reports do not support changing the product.

### Not reviewed

Use only to acknowledge that the task has not yet received product analysis.
It remains explicit in the export.

## Finding field

The finding is bounded to 500 characters.

It should state:

```text
what recurring observation appeared
which task it concerns
what interpretation risk or product gap it suggests
how narrowly the evidence should be read
```

It should not contain:

```text
participant names
contact information
sensitive page content
credentials
raw quoted notes
unnecessary demographic detail
a score or diagnosis of the person
```

## Product-response field

The product response is bounded to 500 characters.

It should describe the smallest change worth testing, for example:

```text
replace one ambiguous label
move one consequence before one action
add one sentence clarifying that no request occurred
separate two previously coupled decisions
plan another targeted session
```

It does not execute that change.

## Review-before-export

The facilitator must open the final review before download.

The review presents:

```text
disposition totals
one task row per finding
newly written finding text
newly written product-response text
aggregate outcome totals
interpretation boundary
privacy boundary
```

The download controls remain disabled until the privacy review is complete.

## Privacy review

Three independent confirmations are required:

```text
The findings contain no participant names, contact details, or identifying text.
The findings make claims only about the loaded reports, not a broad population.
Raw facilitator notes were reviewed locally and were not copied into findings.
```

No confirmation is preselected.

Editing the analysis after review invalidates the current review and requires it
to be opened again.

## Export schema

The JSON export uses:

```text
progrss.fieldwork-debrief.v1
```

Its top-level content is:

```text
schema
scenario
scenarioDigest
release
createdAt
reportCount
outcomeTotals
tasks
interpretationBoundary
privacy
```

Each task export contains:

```text
id
title
counts
signals
disposition
finding
productResponse
```

The export contains no raw facilitator notes.

## Markdown export

The Markdown export contains the same bounded product analysis:

```text
release and scenario
report count
outcome totals
one reviewed task section at a time
disposition
signals
finding
product response
interpretation boundary
privacy boundary
```

It contains no raw facilitator notes.

## Interpretation boundary in export

Every export records:

```text
countsDescribeLoadedReportsOnly = true
noParticipantScore = true
noProductPassClaim = true
```

This boundary travels with the analysis rather than relying on surrounding
prose.

## Privacy boundary in export

Every export records:

```text
participantIdentityRecorded = false
rawNotesExported = false
automaticPersistence = false
telemetry = false
network = false
```

## Browser-local workspace

The generated HTML is one self-contained file.

It uses:

```text
inline CSS
inline packaged JavaScript
local File input
Blob download URLs
no external resource
```

Its Content Security Policy begins:

```text
default-src 'none'
```

It also refuses:

```text
connect-src
remote images
remote fonts
frames
objects
forms
base URLs
```

## No browser storage

The workspace does not use:

```text
localStorage
sessionStorage
IndexedDB
cookies
service workers
Cache Storage
```

Reports and product notes remain in the current page memory until the page is
closed, cleared, or deliberately exported.

A before-unload warning is used when local unsaved analysis exists.

## No network

The workspace does not use:

```text
fetch
XMLHttpRequest
WebSocket
EventSource
WebRTC
sendBeacon
remote script
remote stylesheet
remote image
form submission
```

## Node GUI flow

Inside the existing advanced Bearing/Trace review:

```text
Research and acceptance
  ├─ Download private Fieldbook
  └─ Download private Debrief
```

**Download private Debrief** returns a blank local workspace.

The Node never receives the Fieldbook reports selected later inside that page.

This distinction is important:

```text
Node generates the tool
Browser-local page reads the reports
Nothing is uploaded back to the Node
```

## Node endpoint

The authenticated endpoint is:

```text
POST /api/v1/debrief-kits
```

The request body must be an empty JSON object.

The response is:

```text
text/html; charset=utf-8
attachment filename ProgRSS-Debrief-rev0077.html
X-ProgRSS-Schema: progrss.fieldwork-debrief-kit.v1
```

The endpoint remains protected by the existing literal-loopback, bearer,
`Host`, `Origin`, and no-CORS boundaries.

## CLI flow

Generate a blank workspace:

```sh
./progrss node debrief \
  --output ProgRSS-Debrief.html
```

Preload compatible local reports:

```sh
./progrss node debrief \
  session-01.json \
  session-02.json \
  session-03.json \
  --output ProgRSS-Debrief.html
```

Generate machine-readable creation evidence:

```sh
./progrss node debrief \
  session-01.json session-02.json \
  --output ProgRSS-Debrief.html \
  --json
```

The command is:

```text
offline
new-file-only
no-overwrite
browser-profile independent
permission-store independent
Node-library independent
```

Preloading reports embeds their local content into the resulting local HTML.
The resulting file should be handled with the same care as the input reports.
Raw notes still remain excluded from its later debrief export.

## CLI refusal boundary

The command refuses:

```text
an existing output path
more than forty reports
one report larger than 256,000 bytes
selected reports larger than 4,000,000 bytes in total
invalid UTF-8 JSON
unknown report fields
unsafe privacy flags
mismatched outcome totals
mixed scenarios
mixed product releases
mixed task sequences
```

## Extension boundary

Debrief adds no Extension code path that:

```text
reads reports
uploads reports
downloads a debrief
contacts the Node at startup
requests a new permission
invokes Anchor
triggers Capture
triggers Witness
starts Pulse
changes the browser vault
changes the Node library
```

The Extension remains the product being studied.

## Firefox boundary

The generated Firefox sibling receives only the ordinary release version and
current documentation updates.

Debrief adds no Firefox permission, background request, report upload, or
pairing authority.

Native Firefox and Firefox ESR Fieldbook sessions remain unexecuted acceptance
work until run in real installations.

## Sharing boundary

Debrief is not part of the portable sharing protocol.

It is not included in:

```text
ProgRSS source lists
OPML
Exchange invitations
branch excerpts
recent-updates feeds
static publications
pairing summaries
Pulse timing databases
private library exports
```

A curator shares sources, watched-page recipes, folders, reasons, and integrity
evidence—not facilitator notes or usability analysis about recipients.

## Security model

The most important security properties are:

```text
strict exact-key report validation
bounded report counts and bytes
canonical exact-duplicate detection
same-scenario and same-release requirement
no network capability
no browser storage
no Node-library write
no raw-note export
explicit privacy review
new-file-only CLI output
```

## Threats explicitly considered

### Accidental participant identity

Mitigation:

```text
Fieldbook requests no identity
Debrief refuses unknown report fields
privacy review is required
export schema has no identity field
```

### Raw-note leakage

Mitigation:

```text
notes remain local to the workspace
export is assembled from new finding fields
rawNotesExported is always false
synthetic secret strings are tested as absent from export
```

### Duplicate session inflation

Mitigation:

```text
canonical exact duplicates are ignored
removed duplicates are reported locally
```

### Mixed-study aggregation

Mitigation:

```text
scenario digest must match
release must match
task order and titles must match
```

### Automated product verdict

Mitigation:

```text
no score
no pass/fail field
no confidence percentage
explicit task disposition
interpretation boundary in every export
```

### Hidden persistence

Mitigation:

```text
no browser storage
no automatic file write
no server upload
explicit local download only
```

### Network exfiltration

Mitigation:

```text
CSP connect-src 'none'
no fetch or socket API
no remote resource
no form submission
```

## Failure handling

### Invalid report

The file is refused with the first precise validation reason.

Already loaded compatible reports remain in memory.

### Exact duplicate

The duplicate is ignored and counted in the local status message.

### Mixed scenario or release

The incompatible report is refused. It is not partially merged.

### Missing task disposition

Review stops at the first incomplete task and moves focus to its select control.

### Edited analysis after review

The final review closes and privacy confirmations are cleared.

### Privacy not confirmed

Download controls remain disabled.

### Page closed before export

The browser shows a before-unload warning when supported. No automatic recovery
copy exists.

## Accessibility model

The workspace uses:

```text
semantic headings
native file input
native select controls
native textarea controls
native checkboxes
status announcements
visible keyboard focus
minimum control height
responsive single-column reflow
forced-colors treatment
reduced-motion treatment
print treatment
no drag requirement
no hover-only control
no color-only review state
```

The four outcome counts remain labelled with text.

Review signals use text in addition to color and border treatment.

## Visual model

Debrief follows the current ProgRSS aesthetic:

```text
near-black default canvas
bright cyan primary evidence
magenta structural accent
lime reviewed state
amber privacy boundary
fine gradient lines
restrained glow
no constant animation
```

Light mode remains available from one visible control.

Decorative effects are removed or reduced under forced colors and reduced
motion.

## Human acceptance protocol

The shipped protocol asks facilitators to verify the tool before using it in a
real analysis session.

The important tasks include:

```text
load several compatible reports
recognize exact duplicate removal
recognize mixed-scenario refusal
find a recurring wrong turn
find prompt-dependent understanding
find a coverage gap
inspect local raw notes
state that notes are excluded from export
choose one disposition per task
write a bounded finding
write the smallest product response
review the final report
complete the privacy confirmations
download JSON and Markdown
clear the workspace
explain that no report was uploaded
explain that no participant score was calculated
```

## What automated tests prove

Automated tests prove:

```text
strict report validation
duplicate removal
mixed-scenario refusal
self-contained rendering
absence of network APIs
absence of browser-storage APIs
presence of privacy and interpretation boundaries
local report loading
bounded aggregate counts
review gating
privacy gating
local JSON download
raw-note exclusion from export
dark and light rendering
Node GUI download
CLI generation and no-overwrite behavior
```

## What automated tests do not prove

Automated tests do not prove:

```text
that an unfamiliar person understands the labels
that a facilitator uses neutral prompts correctly
that raw notes contain no identifying detail
that a finding is research-quality
that the smallest response is the right product change
that the interface works with every assistive technology
that ProgRSS passed usability or accessibility acceptance
```

## Native acceptance still required

Run this exact release in:

```text
unmanaged current Chromium
current Firefox
Firefox ESR
real screen-reader sessions
Braille sessions
voice-control sessions
switch-style sessions
200–400 percent zoom
forced colors
reduced motion
fatigue and interruption conditions
```

## Research integrity rules

Facilitators should:

```text
test the product wording rather than the person
use neutral prompts only after an independent attempt
record wrong turns rather than coaching them away
avoid participant names and contact details in notes
avoid sensitive page content
keep the actual product interface open separately from Fieldbook
review every report before analysis
review every debrief before export
make claims only about the loaded reports
```

## Product-change rule

A recurring signal should result in the smallest testable response.

Examples:

```text
change one label
move one consequence above one action
separate one coupled decision
add one sentence explaining zero network effect
reduce one advanced concept from the ordinary path
collect more sessions before changing anything
```

It should not automatically produce:

```text
an account system
a central research database
a participant score
a recommendation engine
a repair bot
a general selector editor
a remote Node
a social graph
a notification stream
```

## Current decision on recipe repair

Recipe repair remains blocked.

Debrief may reveal that people repeatedly fail because:

```text
Different window sounds like deletion
Semantic boundary sounds permanent
Open Anchor sounds like an immediate write
Begin a fresh Capture sounds like a site request already happened
Advanced evidence is impossible to find
page-boundary language is too abstract
```

Only recurring real-session evidence should select the next repair or wording
boundary.

## Current decision on Pinpoint

Direct point-to-region selection remains conditional.

It should be built only when real sessions show that the bounded Contour and
Perimeter proposals cannot express the intended region.

It still requires:

```text
click and tap without mandatory dragging
complete keyboard operation
screen-reader-discoverable candidate regions
voice-control labels
switch-compatible sequential navigation
immediate cancellation and overlay removal
declarative recipe output
Contour, Perimeter, Threshold, Drift, Bearing, Trace, and Anchor review
no raw DOM, HTML, screenshot, form value, or pointer trace transfer
```

## Current decision on remote Nodes

Remote mode remains P2.

The current loopback Node does not become remotely reachable merely because
Debrief exists.

Remote work still requires:

```text
explicit mode separation
TLS
persistent Node identity
host and rate bounds
expiring invitations
durable revocation evidence
public/private route separation
reverse-proxy acceptance
self-hosting documentation
no default public bind
no silent LAN discovery
no UPnP
```

## Current decision on WebRTC

WebRTC remains an optional courier experiment for one reviewed immutable
artifact.

It is not required for Fieldbook, Debrief, reading, sharing, Capture, Witness,
Pulse, Bearing, Trace, or Anchor.

## Source Notes status

The historical handoff describes a rev0059 Source Notes release, but the active
recoverable lineage still does not contain those release bytes.

Do not silently claim Source Notes from transcript prose alone.

Recovery or independent reimplementation remains P1 work.

## Release file map

```text
BOOTSTRAPROSE.md
DEBRIEF-RELEASE.json
RELEASE-NOTES-rev0077-Debrief.md
CLI/debrief.py
CLI/docs/NODE-DEBRIEF.md
CLI/docs/NODE-DEBRIEF-ACCEPTANCE.md
CLI/progrss.py
CLI/node_server.py
CLI/node_web/index.html
CLI/node_web/app.js
CLI/node_web/app.css
CLI/tests/test_debrief.py
CLI/tests/test_node_server.py
CLI/tests/test_command_line.py
CLI/tests/node_browser_smoke.py
Extension/project.json
Extension/README.md
Extension/PROJECT.md
Extension/Firefox/
```

## Prioritized checklist

### P0 — completed in Debrief

- [x] Add `progrss.fieldwork-debrief-kit.v1`.
- [x] Add `progrss.fieldwork-debrief.v1`.
- [x] Strictly validate Fieldbook report fields and privacy flags.
- [x] Refuse unsafe unknown fields.
- [x] Refuse mixed scenarios.
- [x] Refuse mixed releases.
- [x] Refuse changed task sequences.
- [x] Remove exact canonical duplicates.
- [x] Bound report count and bytes.
- [x] Aggregate the four Fieldbook outcomes.
- [x] Surface recurring wrong turns.
- [x] Surface prompt-dependent understanding.
- [x] Surface coverage gaps.
- [x] Surface one-report-only evidence.
- [x] Surface no-recurring-signal state.
- [x] Add one product disposition per task.
- [x] Add bounded finding and product-response fields.
- [x] Keep raw notes locally reviewable.
- [x] Exclude raw notes from export.
- [x] Add interpretation boundary to every export.
- [x] Add privacy boundary to every export.
- [x] Require review before export.
- [x] Require three privacy confirmations.
- [x] Add local JSON export.
- [x] Add local Markdown export.
- [x] Add a blank Node-GUI workspace download.
- [x] Add `progrss node debrief`.
- [x] Keep CLI output new-file-only.
- [x] Add dark and light rendering.
- [x] Add forced-colors and reduced-motion treatment.
- [x] Add narrow-screen and print treatment.
- [x] Add no Extension permission.
- [x] Add no Node-store migration.
- [x] Add no Node-library write.
- [x] Add no network request or telemetry.
- [x] Add no automatic upload or persistence.
- [x] Keep Fieldbook, Trace, Bearing, Anchor, Capture, and Pulse authority unchanged.
- [x] Add pure-function, CLI, Node API, and rendered-browser coverage.
- [x] Update Chromium and Firefox documentation.
- [x] Update this bootstrap as the current `/run` authority.

### P0 — next: conduct real sessions

- [ ] Install the exact release on unmanaged current Chromium.
- [ ] Install the exact release on current Firefox.
- [ ] Install the exact release on Firefox ESR.
- [ ] Recruit people unfamiliar with ProgRSS terminology.
- [ ] Include real screen-reader users.
- [ ] Include Braille users.
- [ ] Include voice-control users.
- [ ] Include switch-style operation.
- [ ] Include high zoom.
- [ ] Include forced colors.
- [ ] Include reduced motion.
- [ ] Include fatigue and interruption conditions.
- [ ] Use a public virtualized page.
- [ ] Use a non-sensitive signed-in test page.
- [ ] Keep the real product and Fieldbook in separate windows.
- [ ] Use neutral prompts only after an independent attempt.
- [ ] Review every report for identifying information.
- [ ] Load several compatible reports into Debrief.
- [ ] Review raw notes locally.
- [ ] Export no raw notes.
- [ ] Make the smallest product change supported by recurring evidence.

### P0 — questions to resolve

- [ ] Does **Different window** sound like deletion?
- [ ] Does **Moving rendered window** sound like certainty?
- [ ] Does overlap sound like a confidence score?
- [ ] Does **Semantic boundary** sound permanent?
- [ ] Does **Accepted baseline** sound like publisher truth?
- [ ] Does **Open Anchor** sound like an immediate write?
- [ ] Does **Begin a fresh Capture** sound like a request already happened?
- [ ] Do people understand that Capture transfers no login?
- [ ] Do people understand that no schedule was created?
- [ ] Do people think paired Extension access can perform repairs?
- [ ] Can people find exact evidence only when asked?
- [ ] Can facilitators distinguish a participant wrong turn from an interface defect?
- [ ] Can facilitators avoid turning counts into participant scores?
- [ ] Can facilitators write findings without copying raw notes?

### P1 — evidence-driven wording and hierarchy

- [ ] Change only wording or hierarchy supported by recurring observed evidence.
- [ ] Preserve product consequences before protocol vocabulary.
- [ ] Preserve basic-first disclosure.
- [ ] Keep exact evidence available under Advanced.
- [ ] Re-run the same tasks after any change.
- [ ] Keep cross-release reports separate unless a future longitudinal schema exists.

### P1 — reviewed recipe repair

- [ ] Begin from one exact Trace/Bearing review.
- [ ] Name one exact watched-page source.
- [ ] Show current and proposed declarative recipes.
- [ ] Explain which observed failure motivates the proposal.
- [ ] Show matched and ignored specimens.
- [ ] Require an unselected acknowledgement.
- [ ] Establish a fresh baseline.
- [ ] Invent no historical change alert.
- [ ] Preserve the earlier recipe and snapshot.
- [ ] Use a strong reviewed-library precondition.
- [ ] Be atomic, idempotent, receipted, and recoverable.
- [ ] Accept no arbitrary shared JavaScript.
- [ ] Expose no generic selector or JSON Patch writer.

### P1 — organization and curation

- [ ] Run delayed re-finding studies after one week.
- [ ] Keep folders human-curated and shareable.
- [ ] Add private many-to-many labels.
- [ ] Add explicit saved-query views.
- [ ] Preserve **Unfiled** as a valid state.
- [ ] Keep duplicate, stale-source, and route-split suggestions reversible.
- [ ] Avoid engagement ranking.
- [ ] Avoid opaque automatic taxonomy.
- [ ] Recover or independently reimplement Source Notes.

### P2 — remote Nodes

- [ ] Keep remote mode explicit and separate from loopback.
- [ ] Require TLS and persistent Node identity.
- [ ] Bound hosts, requests, artifacts, and rates.
- [ ] Add expiring invitations and durable revocation.
- [ ] Separate public publication routes from private APIs.
- [ ] Begin with reviewed immutable-artifact retrieval.
- [ ] Test reverse proxies and self-hosting.
- [ ] No default public bind.
- [ ] No silent LAN discovery.
- [ ] No UPnP.

### Lab — WebRTC courier

- [ ] Transfer exactly one reviewed immutable artifact.
- [ ] Use bounded signed offer-and-answer metadata.
- [ ] Make signaling, STUN, and TURN visible.
- [ ] Compare QR, copy/paste, HTTPS, relay, and WebRTC friction.
- [ ] Refuse replay, identity mismatch, digest mismatch, timeout, and partial completion.
- [ ] Destroy the session after transfer.
- [ ] Never require WebRTC for ordinary reading, sharing, Capture, Witness, Pulse, Trace, Anchor, Fieldbook, or Debrief.

## Verification boundary

Before sealing rev0077:

```text
run strict Debrief pure-function tests
run Fieldbook tests
run Node-store tests
run Node-server tests
run acquisition tests
run Pulse/Cadence tests
run direct CLI tests
run publication and continuity tests
run bounded command-line cases
run Extension static and runtime harnesses
run rendered everyday reader
run rendered Advanced Workbench
run rendered Node and Debrief workflow
parse every delivered Python, JavaScript, JSON, and shell file
build the archive twice deterministically
verify byte-identical builds
verify CRC and unique members
verify safe paths and modes
extract cleanly
compare every delivered byte
replay principal paths from extracted bytes
record native and human work as not run when it was not run
```

## Next coherent boundary

Use Fieldbook and Debrief with real people and native browsers.

Then make the smallest product wording or hierarchy correction supported by
recurring observed wrong turns.

Do not build automatic recipe repair, Pinpoint, remote Nodes, participant
scoring, or broader write authority merely because the analysis infrastructure
now exists.


## Delivered verification

The rev0077 working tree completes:

```text
PASS 17/17  acquisition and Capture continuity
PASS  9/9   Pulse/Cadence timing and dispatch
PASS 46/46  direct CLI library tests
PASS  4/4   Debrief pure-function and privacy-boundary tests
PASS  2/2   Fieldbook tests
PASS 20/20  Node HTTP, pairing, Exchange, Bearing, Trace,
            Fieldbook, Debrief, and Anchor tests
PASS 13/13  Node-store migration, transaction, history, and replay
PASS 29/29  publication, integrity, continuity, and merge cases
PASS 29/29  command-line cases
PASS 169    total distinct Python cases

PASS 58/58  Extension structural and static checks
PASS        Chromium background harness
PASS        Branch / Contents / Signpost / Edition core harness
PASS        generated Firefox background harness
PASS        acquisition and redirect harness
PASS        vault conflict and failed-write harness
PASS 12/12  rendered-page fixture garden
PASS        rendered everyday reader
PASS        rendered Advanced Workbench
PASS        rendered Node, Fieldbook, and Debrief workflow
PASS        local Debrief JSON download with raw-note exclusion

PASS 30 Python files parsed
PASS 64 JavaScript files parsed
PASS 66 JSON files parsed
PASS  2 POSIX shell files parsed
```

The deterministic archive must be built twice from this exact tree, extracted
cleanly, compared byte-for-byte and mode-for-mode, and have its principal
Node, CLI, Extension, Fieldbook, and Debrief paths replayed from the extracted
bytes before release evidence is sealed.

Native installed-browser, unfamiliar-person, and real assistive-technology
sessions remain not run in this environment.

---

# BOOTSTRAPROSE — ProgRSS rev0076 “Fieldbook”

**Release:** rev0076 · **Product version:** 0.76.0 · **Vault schema:** 17 (unchanged)  
**Node-store schema:** `progrss.node-store.v4` (unchanged)  
**Fieldwork kit:** `progrss.fieldwork-kit.v1` (new)  
**Fieldwork report:** `progrss.fieldwork-report.v1` (new)  
**Bearing review:** `progrss.node.bearing-review.v2` (unchanged)  
**Observation trail:** `progrss.node.bearing-trace.v1` (unchanged)  
**Recipe footprint:** `progrss.node.recipe-footprint.v1` (unchanged)  
**Capture artifact:** `progrss.browser-capture.v4` (unchanged)  
**Anchor operation:** `replace-held-page-baseline` (unchanged)  
**Release date:** 2026-10-20  
**Release maxim:** **Test the wording, not the person.**

## `/run` interpretation

When this file is the active bootstrap, continue from the delivered rev0076
source tree. The source, schemas, tests, deterministic archive, release report,
clean-extraction replay, and `Evidence/rev0076-Fieldbook/` directory are the
current implementation authority.

Do not treat any of the following as equivalent to the current release:

```text
rev0058 Branch alone
an incomplete no-scroll historical transcript
an unavailable rev0059 Source Notes file card
rev0067 Cadence prose without its missing delivered package
rev0068 Pulse with its stale distributed bootstrap heading
rev0074 Bearing without Trace
rev0075 Trace without the fieldwork sidecar
an image without matching source bytes
a response naming files absent from the active runtime
a filled automated Fieldbook represented as human acceptance
```

Older bootstrap sections remain below as historical design and chain-of-
custody evidence. When an older section conflicts with this first rev0076
section, this section wins.

## Current lineage

```text
Nightstand   dark fluorescent everyday reader + first loopback Node
Handshake   explicit summary-only Extension ↔ Node pairing
Exchange    Follow / Add route / Take branch handoff
Confluence  three-way later-copy review
Receipt     first typed transactional Node write
Witness     one reviewed public acquisition
Capture     one bounded rendered-page observation
Pulse       foreground scheduling through Witness
Contour     explain why a selected section may hold or break
Perimeter   explain what the rendered page may leave outside
Threshold   require a decision about visible coverage limits
Drift       hold non-comparable partial windows
Anchor      replace one held baseline after explicit review
Bearing     explain repeated held windows before repair
Trace       show accepted and held observations as a trail
Fieldbook   test the language with the actual interface, privately
```

## Current product truths

- The everyday Extension remains the default product.
- The dark fluorescent aesthetic remains the default.
- Light mode remains an explicit persisted option.
- Forced-colors removes decorative fluorescent treatment.
- Reduced-motion remains respected.
- Advanced Workbench remains secondary.
- The Extension remains independently useful without a Node.
- The CLI and Node remain independently useful without a browser.
- The ordinary Node binds only to literal loopback.
- The portable library remains `progrss.private.v1` JSON.
- SQLite remains a local transaction and evidence mechanism.
- Pairing remains summary-only, read-only, process-lifetime, and revocable.
- Exchange remains artifact-scoped rather than continuous synchronization.
- Witness remains the only public Node acquisition path.
- Capture remains one deliberate exact-page browser observation.
- Pulse schedules only Node-reproducible Witness sources.
- Drift may hold a partial observation instead of inventing change.
- Anchor may replace one current hold through a typed reviewed operation.
- Bearing explains unresolved holds but writes nothing.
- Trace exposes bounded evidence but adds no authority.
- Fieldbook records facilitator observations but adds no product authority.
- A shared route never transfers browser or scheduling authority.
- A Capture receipt never becomes Pulse eligibility.
- A paired Extension receives no Bearing, Trace, Anchor, or Fieldbook administrator authority.
- A generated Fieldbook is not completed human acceptance.

# Why Fieldbook exists

The project has accumulated strong automated evidence:

```text
schema and validation tests
network and redirect boundary tests
transaction and replay tests
rendered interface tests
keyboard and accessibility-tree regression checks
forced-colors and reflow checks
clean-extraction replay
```

Those checks cannot answer the central human questions:

```text
Does Different window sound like confirmed deletion?
Does overlap sound like a confidence score?
Does Semantic boundary sound permanent?
Does Open Anchor sound like an immediate write?
Does fresh Capture sound like the Node already contacted the site?
Does summary-only pairing sound like administrator access?
Can someone find exact evidence only when they need it?
```

Fieldbook exists to make those questions observable without building a remote
research platform or collecting participant identity.

It is a facilitator sidecar for the actual product.

```text
Actual ProgRSS Node and Extension
  remain in their own windows

Fieldbook
  records observable behavior in another local window
```

Fieldbook is not:

```text
a product simulation
a guided tutorial
a quiz scored by ProgRSS
a participant database
a telemetry channel
a remote study service
a replacement for consent procedures
a claim that fieldwork has occurred
```

# One private local sheet

The kit schema is:

```text
progrss.fieldwork-kit.v1
```

The local report schema is:

```text
progrss.fieldwork-report.v1
```

The first scenario is:

```text
trace-bearing-anchor
```

The Node generates the sheet from one exact current:

```text
progrss.node.bearing-review.v2
```

The source review must already state:

```json
{
  "network": false,
  "writes": false
}
```

The sheet uses only bounded non-identifying context:

```text
release version
release revision
release codename
diagnosis kind and title
observation count
relationship labels
page-boundary kinds
recipe-footprint kind and label
```

It deliberately excludes:

```text
source ID
source title
source hostname
source address
saved selector
title selector
link selector
library filename
library digest
snapshot text
stable record keys
Capture artifact body
operation ID
receipt ID
browser capability
Node administrator capability
participant identity
```

# Generation paths

## Node GUI

The ordinary Bearing and Trace review remains unchanged.

One collapsed advanced section now reads:

```text
Research and acceptance
```

Inside it:

```text
Test the wording with the actual interface
Download fieldwork sheet
```

The copy states:

```text
no participant identity
no source address or selector
no network request
nothing saved automatically
```

The button downloads one self-contained HTML file.

Opening the disclosure does not generate or download anything.

## CLI

```sh
./progrss node fieldbook \
  NODE-LIBRARY.sqlite3 \
  WATCHED-PAGE-SOURCE-ID \
  --output ProgRSS-Fieldbook.html
```

Machine-readable evidence:

```sh
./progrss node fieldbook \
  NODE-LIBRARY.sqlite3 \
  WATCHED-PAGE-SOURCE-ID \
  --output ProgRSS-Fieldbook.html \
  --json
```

The command is:

```text
offline
new-file-only
no-overwrite
zero portable-library writes
zero fieldwork-evidence writes
```

Opening an older supported Node store may complete the existing store-schema
migration before review. That migration is not a Fieldbook feature and does
not rewrite the portable library.

# The twelve tasks

## Task 1 — Find the accepted baseline

Prompt:

```text
Identify where future comparisons still begin.
```

Success signal:

```text
Accepted baseline is identified without treating it as complete,
permanent, or publisher-certified.
```

Wrong turns include:

```text
chooses the newest hold
says the baseline is guaranteed complete
cannot find the accepted point
```

## Task 2 — Find the current hold

Prompt:

```text
Identify which observation is waiting for a later decision.
```

Success signal:

```text
Current hold is distinguished from the accepted baseline.
```

Wrong turns include:

```text
calls it the new baseline
calls it an applied repair
selects an earlier held observation
```

## Task 3 — Explain what the trail represents

Prompt:

```text
Is this confirmed history of everything on the publisher's site?
```

Success signal:

```text
It is described as a bounded sequence of local browser and Node
observations, not complete publisher history.
```

Wrong turns include:

```text
complete remote audit log
absent records were deleted
continuous monitoring is assumed
```

## Task 4 — Explain Different window

Success means:

```text
The partial renderings were too disjoint for a literal mass
add-or-remove conclusion.
```

It does not mean:

```text
every old record was deleted
every visible record is definitely new
the diagnosis is certain
```

## Task 5 — Explain overlap

Success means:

```text
shared stable units between two bounded observations
```

It does not mean:

```text
confidence
probability
page completeness
```

## Task 6 — Explain the recipe footprint

Success means:

```text
what the saved declarative selector depends on
```

It does not mean:

```text
how long the selector will remain valid
a reliability score
a promise from the publisher
```

## Task 7 — Explain Keep accepted baseline

Success means:

```text
close the review
no site request
no browser request
no library write
```

## Task 8 — Explain Open Anchor

Success means:

```text
open another review
no immediate write
separate acknowledgement still required
```

## Task 9 — Explain Begin a fresh Capture

Success means:

```text
create a short-lived request
the exact page still must be opened
one deliberate browser action is still required
```

## Task 10 — Explain paired Extension authority

Success means:

```text
summary-only pairing cannot read held evidence
summary-only pairing cannot submit Anchor
summary-only pairing does not grant administrator authority
```

## Task 11 — Find exact evidence only when asked

Success means:

```text
Advanced evidence is discoverable
ordinary decisions do not require reading hashes first
```

## Task 12 — State the review effects

Success means:

```text
opening Trace made no watched-site request
opening Trace changed no library data
opening Trace created no schedule
```

# Observational outcomes

Every task receives exactly one outcome:

```text
Understood independently
Understood after a neutral prompt
Wrong turn or unsafe interpretation
Not observed
```

The vocabulary is intentionally descriptive.

It is not converted to:

```text
pass percentage
participant score
confidence estimate
product certification
engagement metric
```

A neutral prompt is recorded separately from independent understanding so the
team can distinguish discoverability from eventual comprehension.

A wrong turn is evidence about ProgRSS.

It is not represented as a participant defect.

# Facilitator notes

Each task permits at most:

```text
600 characters
```

The sheet asks for observable behavior or the neutral prompt used.

Preferred:

```text
Participant opened Advanced after asking where the exact selector lives.
```

Avoid:

```text
Participant is confused.
```

Do not copy:

```text
participant names
email addresses
account identifiers
credentials
private article text
health information
financial information
unnecessary quoted page content
```

# Three research-boundary checks

Before reviewing a report, the facilitator must confirm:

```text
We are testing ProgRSS, not the participant.
I will avoid names and sensitive page content in notes.
The exact release under study is open separately.
```

If any check is incomplete, report review is blocked and focus returns to the
first incomplete boundary.

# Review before export

The sheet requires:

```text
all twelve tasks coded
all three research-boundary checks complete
one explicit privacy acknowledgement
```

The review shows:

```text
count understood independently
count understood after neutral prompt
count wrong turn or unsafe interpretation
count not observed
one line per task
bounded facilitator note or No note recorded
```

Report download remains disabled until the facilitator checks:

```text
I reviewed the notes for personal or sensitive information.
```

This is not a claim that ProgRSS can detect sensitive text automatically.

It is a deliberate human review boundary.

# Local reports

The sheet can download:

```text
JSON
Markdown
```

The report contains:

```text
report schema
scenario identifier and digest
release version, revision, and codename
kit generation time
local completion time
outcome counts
bounded task results and notes
research-boundary confirmations
privacy effects
```

It does not add a participant identity field.

It does not upload anything.

# No telemetry and no automatic persistence

The generated HTML contains:

```text
no external stylesheet
no external script
no remote image
no font request
no frame
no form submission
no fetch call
no XMLHttpRequest
no WebSocket
no sendBeacon
no localStorage
no sessionStorage
no IndexedDB
no service worker
```

Its Content Security Policy includes:

```text
default-src 'none'
connect-src 'none'
form-action 'none'
object-src 'none'
frame-src 'none'
base-uri 'none'
```

Task state remains only in page memory.

Closing or reloading the sheet loses unsaved work.

The sheet says so plainly.

# Clear without saving

The visible destructive action is:

```text
Clear without saving
```

It is separate from report review and download.

It exists so a facilitator can deliberately discard the in-memory session.

It does not delete:

```text
Node data
browser data
previously downloaded files
source history
Capture evidence
```

# Theme and accessibility treatment

Fieldbook uses the same broad visual language as ProgRSS:

```text
near-black default surface
fluorescent cyan, pink, and lime accents
fine borders rather than decorative noise
explicit light mode
```

It also provides:

```text
semantic fieldsets and legends
one labelled radio group per task
labelled notes fields
visible keyboard focus
44-pixel-class controls
narrow single-column reflow
reduced-motion handling
forced-colors treatment
print layout
polite status messages
```

The generated sheet does not claim real assistive-technology acceptance until
those sessions are actually run.

# Print boundary

Printing hides:

```text
sticky header
interactive action row
status messages
```

It keeps:

```text
task prompts
outcome choices
notes areas
facilitator cues
review content
```

Printing does not create a product-side record.

# Network and write effects

Generating a Fieldbook through the running Node performs:

```json
{
  "network": false,
  "libraryWrites": false,
  "automaticPersistence": false,
  "telemetry": false
}
```

Using the sheet performs no Node request.

Fieldbook cannot:

```text
contact the watched site
contact the browser
replace the accepted baseline
consume the current hold
change the watched-page recipe
create a page-change item
start Witness
start Capture
start Pulse
create a schedule
publish a source list
pair an Extension
write a Node library
```

# Endpoint boundary

The authenticated local endpoint is:

```text
POST /api/v1/fieldwork-kits
```

It requires the existing:

```text
administrator bearer capability
literal loopback Node
exact Host handling
same-Origin handling
no-CORS boundary
bounded JSON request
existing watched-page source with a current hold
```

The response is:

```text
text/html; charset=utf-8
attachment
```

It carries:

```text
X-ProgRSS-Schema: progrss.fieldwork-kit.v1
X-ProgRSS-Scenario-Digest: <sha256>
```

Unauthenticated and foreign-Origin requests remain refused.

# CLI result evidence

The `--json` command result includes:

```text
schema
state
file
bytes
scenario
scenario digest
task count
network false
libraryWrites false
store migration evidence
automaticPersistence false
telemetry false
```

It does not include the source address or selector.

# Relationship to Trace

Trace remains the product evidence view.

It displays:

```text
accepted baseline
held observations
current hold
pairwise relationship labels
page-boundary kinds
saved-recipe footprint
```

Fieldbook does not duplicate those details into a questionnaire.

It asks a facilitator to observe whether a person can understand them in the
actual Trace interface.

# Relationship to Bearing

Bearing remains the read-only diagnosis layer.

Fieldbook does not create a new diagnosis.

It uses only the diagnosis kind and short title to bind one study scenario to
the current review.

# Relationship to Anchor

Anchor remains the only current typed operation that can replace one held
baseline.

Fieldbook cannot invoke Anchor.

It asks whether the participant understands that opening Anchor is another
review rather than an immediate write.

# Relationship to Capture

Fresh Capture remains one separate short-lived browser request.

Fieldbook cannot:

```text
create a Capture invitation
request page permission
inspect tabs
run the extractor
submit a Capture artifact
```

It asks whether the participant understands that fresh Capture has not already
contacted or inspected the page.

# Relationship to pairing

Pairing remains summary-only and read-only.

A paired Extension receives no:

```text
Fieldbook endpoint
Fieldbook report
held snapshots
Trace history
exact selector
Anchor writer
Node administrator capability
```

# Relationship to sharing

Fieldbook data is not part of:

```text
private backup export
ProgRSS source list
OPML
Exchange invitation
branch excerpt
recent-updates feed
static publication
pairing summary
Pulse timing database
```

A facilitator may deliberately share a downloaded report outside ProgRSS under
their own study policy. ProgRSS does not automate that transfer.

# Human acceptance remains unexecuted here

The automated browser can:

```text
render the sheet
complete all radio groups
open the review
verify privacy gating
download a local report
verify dark and light themes
verify excluded private context
```

That proves only that the controls work as implemented.

It does not prove that an unfamiliar person understood them.

The current release therefore records:

```text
unmanaged installed Chromium: not run
current native Firefox: not run
native Firefox ESR: not run
unfamiliar-human Fieldbook sessions: not run
real screen-reader sessions: not run
real Braille sessions: not run
real voice-control sessions: not run
real switch sessions: not run
```

# What humans actually need from this boundary

The project needs observations about:

```text
words that imply certainty
words that imply immediate action
controls that appear to grant more authority than they do
advanced evidence that cannot be found when needed
ordinary decisions buried beneath protocol detail
privacy language that sounds like an upload
```

The desired result is not a high score.

The desired result is a prioritized list of product changes grounded in
repeated observed wrong turns.

# Explicit non-goals

Fieldbook does not add:

```text
participant accounts
researcher accounts
cloud sync
shared study dashboards
analytics SDKs
session replay
keystroke logging
screen recording
remote moderation
consent management
compensation management
demographic profiling
AI interpretation of notes
automatic sentiment analysis
usability scores
leaderboards
```

# Why repair still waits

Trace and Bearing now provide more evidence than rev0074.

That does not establish which repair people need.

Possible future work includes:

```text
reviewed declarative recipe repair
conditional point-to-region selection
wording-only changes
stronger fixture explanations
no new feature at all
```

Fieldbook exists to distinguish those possibilities through observation.

Automatic selector mutation remains out of scope.

# P0 completed in Fieldbook

- [x] Add `progrss.fieldwork-kit.v1`.
- [x] Add `progrss.fieldwork-report.v1`.
- [x] Generate one sheet from an exact read-only Bearing/Trace review.
- [x] Add twelve bounded comprehension tasks.
- [x] Add four observational outcomes.
- [x] Bound notes to 600 characters.
- [x] Request no participant identity.
- [x] Exclude source address and selector.
- [x] Exclude snapshots and capabilities.
- [x] Add three research-boundary checks.
- [x] Require every task to have an outcome before review.
- [x] Require privacy review before report download.
- [x] Add local JSON report.
- [x] Add local Markdown report.
- [x] Add clear-without-saving.
- [x] Add print treatment.
- [x] Add dark and light treatment.
- [x] Add forced-colors treatment.
- [x] Add reduced-motion treatment.
- [x] Add narrow reflow.
- [x] Add polite status messages.
- [x] Add authenticated Node download endpoint.
- [x] Add offline `progrss node fieldbook` command.
- [x] Keep output new-file-only.
- [x] Keep generation zero-network.
- [x] Keep portable library unchanged.
- [x] Keep Bearing and Trace read-only.
- [x] Keep Anchor separate.
- [x] Keep fresh Capture separate.
- [x] Keep pairing summary-only and read-only.
- [x] Add unit tests for privacy minimization.
- [x] Add HTTP authorization and no-write coverage.
- [x] Add rendered Node and Fieldbook flow.
- [x] Add local report download verification.
- [x] Add acceptance protocols for general, tired-reader, and Firefox sessions.
- [x] Preserve the previous release history below.

# P0 next — run the fieldwork

- [ ] Install the exact archive on unmanaged current Chromium.
- [ ] Install it on current Firefox.
- [ ] Install it on Firefox ESR.
- [ ] Recruit unfamiliar participants under an appropriate study process.
- [ ] Use non-sensitive page fixtures first.
- [ ] Use the actual interface and Fieldbook in separate windows.
- [ ] Record initial responses before neutral prompts.
- [ ] Avoid participant names and sensitive content in notes.
- [ ] Ask whether Different window sounds like deletion.
- [ ] Ask whether overlap sounds like confidence.
- [ ] Ask whether Semantic boundary sounds permanent.
- [ ] Ask whether Open Anchor sounds immediate.
- [ ] Ask whether fresh Capture sounds automatic.
- [ ] Ask whether pairing sounds like administrator access.
- [ ] Ask the participant to find exact evidence when requested.
- [ ] Verify that Keep sounds zero-network and zero-write.
- [ ] Review every report for personal information.
- [ ] Aggregate repeated wrong turns outside ProgRSS under the study policy.
- [ ] Change wording or hierarchy before adding repair automation.

# P0 next — real assistive technology

- [ ] Keyboard-only session.
- [ ] Current screen-reader session.
- [ ] Braille-display session when available.
- [ ] Voice-control session.
- [ ] Switch-style sequential navigation.
- [ ] 200 percent zoom.
- [ ] 400 percent zoom.
- [ ] Forced-colors or high-contrast session.
- [ ] Reduced-motion session.
- [ ] Fatigue and interruption session.
- [ ] Printed-sheet review.
- [ ] Verify task legends and radio-group labels.
- [ ] Verify status announcements without disruptive focus movement.
- [ ] Verify privacy gating and download controls.
- [ ] Verify dark, light, and forced-colors boundaries.

# P0 next — real-site fixture expansion

- [ ] Three disjoint windows from one public virtualized list.
- [ ] Windows with one or two stable overlaps.
- [ ] Constant DOM-node count with recycled records.
- [ ] Stable destinations with changing visible text.
- [ ] Unknown totals using `aria-setsize="-1"`.
- [ ] Incorrect author-supplied set metadata.
- [ ] Page-boundary changes midway through a sequence.
- [ ] Generated classes that rotate between observations.
- [ ] Stable `data-*` attributes across layout changes.
- [ ] Deep structural selectors broken by one wrapper.
- [ ] A semantic selector that nevertheless becomes invalid.
- [ ] A real redesign that should route to fresh Capture.

# P1 — evidence-driven recipe repair

Build a repair only after fieldwork identifies a recurring need.

Any future operation must:

- [ ] Name one exact watched-page source.
- [ ] Begin from one exact Bearing/Trace review.
- [ ] Show old and proposed declarative recipes.
- [ ] Show matched and ignored specimens.
- [ ] Explain which evidence motivated the proposal.
- [ ] Explain what history remains.
- [ ] Require an unselected acknowledgement.
- [ ] Establish a fresh baseline.
- [ ] Invent no historical change alert.
- [ ] Use a strong reviewed-library precondition.
- [ ] Be atomic, idempotent, receipted, and recoverable.
- [ ] Preserve the prior recipe and snapshot.
- [ ] Accept no arbitrary shared JavaScript.
- [ ] Expose no generic selector or JSON Patch writer.

# P1 — conditional Pinpoint

Point-to-region selection remains conditional on observed proposal failures.

It would require:

- [ ] Exact active-page review.
- [ ] Temporary packaged isolated-world overlay.
- [ ] Click and tap operation.
- [ ] Complete keyboard alternative.
- [ ] Screen-reader-discoverable regions.
- [ ] Stable voice-control labels.
- [ ] Switch-compatible sequential selection.
- [ ] Immediate cancellation and overlay removal.
- [ ] Declarative recipe output.
- [ ] Contour, Perimeter, Threshold, Drift, Bearing, Trace, and Anchor review.
- [ ] No form-value reads.
- [ ] No page-control activation.
- [ ] No raw DOM transfer.
- [ ] No HTML transfer.
- [ ] No screenshot transfer.
- [ ] No pointer-trace transfer.

# P1 — organization and curation

- [ ] Run delayed re-finding studies after one week.
- [ ] Keep folders human-curated and shareable.
- [ ] Add private many-to-many labels.
- [ ] Add explicit saved-query views.
- [ ] Preserve Unfiled as a valid state.
- [ ] Keep duplicate, stale-source, and route-split suggestions reversible.
- [ ] Avoid engagement ranking.
- [ ] Avoid opaque automatic taxonomy.
- [ ] Recover or independently reimplement the absent Source Notes release bytes.

# P2 — remote Nodes

- [ ] Keep remote mode explicit and separate from loopback.
- [ ] Require TLS and persistent Node identity.
- [ ] Bound hosts, requests, artifacts, and rates.
- [ ] Add expiring invitations and durable revocation evidence.
- [ ] Keep public publication routes separate from private APIs.
- [ ] Begin with reviewed immutable-artifact retrieval.
- [ ] Test reverse proxies and self-hosting.
- [ ] No default public bind.
- [ ] No silent LAN discovery.
- [ ] No UPnP port opening.

# Lab — WebRTC courier

- [ ] Transfer exactly one already reviewed immutable artifact.
- [ ] Use bounded signed offer-and-answer metadata.
- [ ] Make signaling visible.
- [ ] Make STUN and TURN visible.
- [ ] Compare QR, copy/paste, HTTPS, relay, and WebRTC friction.
- [ ] Refuse replay.
- [ ] Refuse identity mismatch.
- [ ] Refuse digest mismatch.
- [ ] Refuse timeout and partial completion.
- [ ] Destroy the session after transfer.
- [ ] Never require WebRTC for ordinary reading, sharing, Capture, Witness, Pulse, Bearing, Trace, Anchor, or Fieldbook.

# Verification boundary

The working tree includes:

```text
163 distinct Python test cases
58 Extension structural and static checks
12 rendered-page fixture-garden cases
Chromium background harness
generated Firefox background harness
shared-folder core harness
acquisition and redirect harness
vault conflict and failed-write harness
rendered everyday reader
rendered Advanced Workbench
rendered Node Trace/Bearing/Anchor/Fieldbook flow
rendered self-contained Fieldbook
local JSON report download
```

The old Relay and command-line aggregate wrappers can retain descendant output
handles after assertions finish. Release evidence therefore uses completed
aggregate output where available and individually bounded constituent cases for
the command-line lane.

Native installed-browser and unfamiliar-human work remains explicitly not run.

---

# BOOTSTRAPROSE — ProgRSS rev0075 “Trace”

**Release:** rev0075 · **Product version:** 0.75.0 · **Vault schema:** 17 (unchanged)  
**Node-store schema:** `progrss.node-store.v4` (unchanged)  
**Bearing review:** `progrss.node.bearing-review.v2` (advanced)  
**Observation trail:** `progrss.node.bearing-trace.v1` (new)  
**Recipe footprint:** `progrss.node.recipe-footprint.v1` (new)  
**Hold-history evidence:** `progrss.node.capture-hold-history.v1` (unchanged)  
**Current held observation:** `progrss.node.capture-hold.v1` (unchanged)  
**Capture artifact:** `progrss.browser-capture.v4` (unchanged)  
**Continuity evidence:** `progrss.capture-continuity.v1` (unchanged)  
**Anchor preview:** `progrss.node.baseline-preview.v1` (unchanged)  
**Anchor operation:** `replace-held-page-baseline` (unchanged)  
**Release date:** 2026-10-20  
**Release maxim:** **Show the observations, not just the diagnosis.**

## `/run` interpretation

When this file is the active bootstrap, continue from the delivered rev0075
source tree. The source, schemas, tests, deterministic archive, release report,
clean-extraction replay, and `Evidence/rev0075-Trace/` directory are the current
implementation authority.

Do not reconstruct the current product from:

```text
rev0058 Branch alone
an incomplete no-scroll historical transcript
an unavailable rev0059 Source Notes file card
rev0067 Cadence prose without its missing delivered package
rev0068 Pulse with its stale distributed bootstrap heading
rev0072 Drift without Anchor
rev0073 Anchor without Bearing
rev0074 Bearing without Trace's observation trail
an image without matching source bytes
a response that names files absent from the active runtime
```

Older bootstrap sections remain below as historical design and chain-of-
custody evidence. When an older section conflicts with this first rev0075
section, this section wins.

## Current lineage

```text
Nightstand   dark fluorescent everyday reader + first loopback Node
Handshake   explicit summary-only Extension ↔ Node pairing
Exchange    Follow / Add route / Take branch handoff
Confluence  three-way later-copy review
Receipt     first typed transactional Node write
Witness     one reviewed public acquisition
Capture     one bounded rendered-page observation
Pulse       foreground scheduling through Witness
Contour     explain why a selected section may hold or break
Perimeter   explain what the rendered page may leave outside
Threshold   require a decision about visible coverage limits
Drift       hold non-comparable partial windows
Anchor      replace one held baseline after explicit review
Bearing     explain repeated held windows before any repair
Trace       show the accepted baseline and held observations as a trail
```

## Current product truths

- The everyday Extension remains the default product.
- The dark fluorescent aesthetic remains the default.
- Light mode remains an explicit persisted option.
- Forced-colors removes decorative fluorescent treatment.
- Reduced-motion remains respected.
- Advanced Workbench remains secondary.
- The Extension remains independently useful without a Node.
- The CLI and Node remain independently useful without a browser.
- The ordinary Node binds only to literal loopback.
- The portable library remains `progrss.private.v1` JSON.
- SQLite remains a local transaction and evidence mechanism.
- Pairing remains summary-only, read-only, process-lifetime, and revocable.
- Exchange remains artifact-scoped rather than continuous synchronization.
- Witness remains the only public Node acquisition path.
- Capture remains one deliberate exact-page browser observation.
- Pulse schedules only Node-reproducible Witness sources.
- Drift may hold a partial observation rather than invent change.
- Anchor may replace one current hold through a typed reviewed operation.
- Bearing explains unresolved holds but writes nothing.
- Trace makes the retained evidence visible without adding authority.
- A shared route never transfers browser or scheduling authority.
- A Capture receipt never becomes Pulse eligibility.
- A paired Extension receives no Trace, Bearing, or Anchor administrator authority.

# Why Trace exists

Bearing can state a bounded diagnosis:

```text
Moving rendered window
Page boundary shifted
Not enough evidence yet
```

A diagnosis alone can still feel like a black box.

A person may reasonably ask:

```text
What was accepted before these holds?
How many held observations are involved?
Which one is current?
Did each observation overlap the previous one?
Did the rendered-page boundary change?
What does the saved recipe depend on?
Is ProgRSS describing evidence or claiming certainty?
Did opening this review change anything?
```

Trace answers those questions before any repair is proposed.

It does not add a new consequence.

```text
Keep accepted baseline
Open Anchor
Begin a fresh Capture
```

remain the only ordinary exits from Bearing.

# Observation trail

The trail schema is:

```text
progrss.node.bearing-trace.v1
```

The trail is ordered oldest to newest.

It always begins with:

```text
Accepted baseline
```

It then contains each retained unresolved held observation, ending with:

```text
Current hold
```

The trail is bounded by the same local evidence limit as Bearing:

```text
one current hold
up to eight prior unresolved holds
```

The trail does not create another copy of raw browser content. It summarizes the
existing bounded snapshots and continuity evidence.

## Accepted baseline node

The accepted node contains:

```text
mode
bounded unit count
unit label
capture time
snapshot digest in Advanced evidence
```

The ordinary card says:

```text
Future comparisons still begin here.
```

It does not say that the baseline is complete, correct, or permanent.

## Held observation node

Each held node contains:

```text
ordinal
whether it is the current hold
held time
bounded snapshot summary
relationship to the previous trail point
overlap with the previous trail point
shared stable units
enough-evidence flag
similar-size flag
overlap with the accepted baseline
continuity reason
visible page-boundary kinds
last Capture assessment label and summary
```

Exact operation IDs, receipt IDs, and snapshot digests remain Advanced evidence.

## Pairwise relationship vocabulary

Trace uses only:

```text
Accepted
Boundary changed
Not enough evidence
Different window
Some overlap
Substantial overlap
```

### Accepted

The existing comparison point.

### Boundary changed

The previous and current trail points do not report the same rendered-page
limits.

This may involve:

```text
continuation
partial rendering
overlay
loading
frames
open shadow inspection
```

It does not prove that the publisher added or removed records.

### Not enough evidence

The two observations do not contain enough stable units for a stronger bounded
comparison.

It does not mean they are identical.

### Different window

The observations are similarly sized and share less than 35 percent of the
stable units in the smaller observation.

This is the same conservative policy used by Drift. It is not a probability.

### Some overlap

The observations share stable units but do not expose substantially the same
window.

### Substantial overlap

At least 70 percent of the stable units in the smaller observation remain
visible.

This does not prove that the complete page or collection is unchanged.

# Recipe footprint

The footprint schema is:

```text
progrss.node.recipe-footprint.v1
```

It describes what the current saved declarative selector appears to depend on.

It does not generate a replacement selector and does not claim durability.

The bounded labels are:

```text
Primary readable region
Semantic boundary
Explicit structural signal
Class or ID selector
Implementation-detail selector
Plain structural selector
```

## Primary readable region

A region recipe has no exact selector and falls back to the page's primary
readable content boundary.

## Semantic boundary

The selector uses elements such as:

```text
main
article
section
nav
aside
ul
ol
li
table
tr
```

Semantic markup can be understandable while still changing later.

## Explicit structural signal

The selector uses one or more page-supplied signals such as:

```text
data-* attribute
role attribute
itemprop
h-entry microformat
```

Trace calls these explicit signals, not permanent contracts.

## Class or ID selector

The selector begins from a class or ID name without a generated-looking token
detected by the bounded classifier.

The publisher may still change it.

## Implementation-detail selector

The selector contains a bounded warning signal such as:

```text
positional pseudo-class
generated-looking class or ID token
```

Trace does not automatically replace it.

## Plain structural selector

The selector is bounded and does not match another footprint category.

## Additional bounded evidence

Trace may explain:

```text
explicit title selector
missing link selector for repeated records
deep combinator path
last accepted Capture assessment
```

It emits no confidence score.

# GUI hierarchy

The ordinary Bearing review now appears in this order:

1. Bearing label and observation count.
2. Diagnosis.
3. What Bearing does not do.
4. Trace observation trail.
5. Current watched-section footprint.
6. Advanced held-window evidence.
7. Keep / Anchor / fresh Capture actions.

The observation trail is a semantic ordered list.

The fluorescent line and nodes are decorative reinforcement, not the sole means
of conveying order or state.

At narrow widths the trail becomes vertical.

Under forced colors:

```text
decorative gradients disappear
borders remain
labels remain text
order remains semantic
```

Reduced-motion mode removes decorative glow motion; Trace adds no required
animation.

# Authority and privacy

Trace is read-only.

```json
{
  "network": false,
  "writes": false
}
```

Opening, refreshing, or closing Trace does not:

```text
replace the accepted baseline
consume a held proposal
change the watched-page recipe
create a page-change item
enable or pause a source
contact the watched site
contact the browser
create a schedule
publish or share anything
synchronize another library
```

The paired Extension receives no:

```text
held snapshots
Trace trail
exact saved selector
Bearing diagnosis history
Node administrator capability
Anchor preview capability
repair endpoint
write authority
```

Trace does not contain or transfer:

```text
browser cookies
credentials
raw HTML
DOM nodes
screenshots
form values
page scripts
open-tab lists
browser capabilities
```

# Portability boundary

Trace remains local administrator evidence.

It does not enter:

```text
progrss.private.v1 export
native source lists
OPML
Exchange handoffs
branch excerpts
static publication pages
recent-updates feeds
pairing summaries
Pulse timing databases
```

Portable artifacts describe curation and reproducible acquisition recipes.
Trace describes what this local browser and Node observed.

# Implementation map

## Node server

```text
CLI/node_server.py
```

owns:

```text
progrss.node.bearing-review.v2
progrss.node.bearing-trace.v1
progrss.node.recipe-footprint.v1
oldest-to-newest trail construction
pairwise relationship labels
bounded selector-footprint classification
zero-network and zero-write response boundary
```

## Node web UI

```text
CLI/node_web/index.html
CLI/node_web/app.js
CLI/node_web/app.css
```

own:

```text
semantic ordered trail
accepted and held cards
page-boundary badges
recipe reasons and warnings
advanced selector disclosure
dark/light/forced-colors/narrow-layout rendering
```

## Node store

```text
CLI/node_store.py
```

remains at:

```text
progrss.node-store.v4
```

Trace requires no store migration and performs no write.

## Extension

The Extension version advances for release synchronization, but Trace adds no
new Extension runtime authority or required permission.

# Research boundary

Research constrained the language rather than justifying automatic repair.

Playwright documentation recommends user-facing attributes and explicit
contracts for resilient test locators, and warns that implementation-detail CSS
and DOM structure can break. ProgRSS treats that as a useful analogy for
explaining selector dependencies, not as a watched-page standard.

The HTML Standard permits page-supplied `data-*` attributes. Trace may call such
an attribute an explicit structural signal. It does not claim the publisher will
preserve it.

W3C accessibility guidance supports clear labels, sufficient instructions,
review before consequential changes, and status messages that do not force an
unnecessary context change.

No researched source supplies a universal selector-durability score. Trace
therefore emits no probability or confidence percentage.

# Acceptance protocol

An unfamiliar participant should be able to:

1. Open Bearing for a source with at least two unresolved holds.
2. Identify the accepted baseline.
3. Identify the oldest held observation.
4. Identify the current hold.
5. Explain `Different window` without saying that records were deleted.
6. Explain a page-boundary badge.
7. Explain what the recipe-footprint label describes.
8. State that the label is not a durability guarantee.
9. Find the exact selector only when asked to open Advanced.
10. State that opening Trace made no site request and no write.
11. State that Open Anchor still requires another review.
12. State that fresh Capture still requires one exact-page browser action.

Wrong turns to record:

```text
treating the trail as confirmed publisher history
reading overlap as probability
treating Semantic boundary as permanent
treating Implementation-detail selector as automatically broken
believing Open Anchor immediately writes
believing fresh Capture contacts every listed source
believing the paired Extension receives repair authority
```

# Prioritized checklist

## P0 — completed in Trace

- [x] Advance the Bearing response to `progrss.node.bearing-review.v2`.
- [x] Add `progrss.node.bearing-trace.v1`.
- [x] Add `progrss.node.recipe-footprint.v1`.
- [x] Order the trail from accepted baseline through oldest and current holds.
- [x] Add pairwise relationship labels.
- [x] Keep relationship evidence bounded.
- [x] Keep exact hashes and operation IDs under Advanced.
- [x] Add a semantic ordered-list GUI.
- [x] Add fluorescent line and node treatment without making color the only cue.
- [x] Add narrow vertical reflow.
- [x] Preserve forced-colors and reduced-motion behavior.
- [x] Classify semantic, explicit, class/ID, implementation-detail, plain, and primary-region selectors.
- [x] Explain title, link, positional, generated-token, and deep-path signals.
- [x] Emit no confidence score.
- [x] Perform no network request.
- [x] Perform no library write.
- [x] Add no store migration.
- [x] Add no Extension permission.
- [x] Keep pairing summary-only and read-only.
- [x] Keep Anchor and fresh Capture separate.
- [x] Add Node API, pure-function, browser-rendering, and clean-extraction coverage.
- [x] Update CLI, Extension, Firefox, acceptance, and release documentation.

## P0 — next: native Trace fieldwork

- [ ] Install this exact release on unmanaged current Chromium.
- [ ] Install it on current Firefox and Firefox ESR.
- [ ] Produce three held windows from a public virtualized list.
- [ ] Produce held windows from a non-sensitive signed-in test page.
- [ ] Ask whether the trail looks like confirmed publisher history.
- [ ] Ask what overlap means.
- [ ] Ask whether Semantic boundary is a promise.
- [ ] Ask whether opening Anchor immediately changes the library.
- [ ] Ask whether fresh Capture contacts the site before the browser action.
- [ ] Verify keyboard-only trail navigation.
- [ ] Run real screen-reader and Braille sessions.
- [ ] Run voice-control and switch-style sessions.
- [ ] Run 200–400% zoom, forced colors, reduced motion, fatigue, and interruption sessions.
- [ ] Change wording and hierarchy based on observed wrong turns.

## P0 — fixture expansion

- [ ] Three disjoint windows from one collection.
- [ ] Windows with one or two stable overlaps.
- [ ] Constant DOM node count with recycled records.
- [ ] Stable destinations with changing text.
- [ ] Unknown totals with `aria-setsize=-1`.
- [ ] Incorrect author-supplied set metadata.
- [ ] Boundary changes midway through a sequence.
- [ ] Generated class names that rotate between observations.
- [ ] Stable data attributes across layout changes.
- [ ] Deep structural selectors broken by one wrapper.
- [ ] A semantic selector that still becomes invalid.
- [ ] A real redesign that should route to fresh Capture.

## P1 — evidence-driven recipe repair

Build only after fieldwork identifies the actual repair need.

A future repair operation must:

- [ ] Name one exact watched-page source.
- [ ] Begin from one exact Bearing/Trace review.
- [ ] Show the current and proposed declarative recipes.
- [ ] Show matched and ignored specimens.
- [ ] Explain which Trace evidence motivated the proposal.
- [ ] Explain what history remains.
- [ ] Require an unselected acknowledgement.
- [ ] Establish a fresh baseline.
- [ ] Invent no historical change alert.
- [ ] Use a strong reviewed-library precondition.
- [ ] Be atomic, idempotent, receipted, and recoverable.
- [ ] Preserve the earlier recipe and snapshot for audit.
- [ ] Accept no arbitrary shared JavaScript.
- [ ] Expose no generic selector, snapshot, or JSON Patch writer.

## P1 — conditional Pinpoint

A direct point-to-region tool remains conditional on real evidence that the
bounded candidates cannot express what people need.

It would require:

- [ ] Exact active-page review.
- [ ] Temporary packaged isolated-world overlay.
- [ ] Click, tap, and complete keyboard alternatives.
- [ ] Screen-reader-discoverable regions.
- [ ] Stable voice-control labels.
- [ ] Switch-compatible sequential selection.
- [ ] Immediate cancellation and overlay removal.
- [ ] Declarative recipe output.
- [ ] Contour, Perimeter, Threshold, Drift, Bearing, Trace, and Anchor review.
- [ ] No form-value read or page-control activation.
- [ ] No raw DOM, HTML, screenshot, or pointer-trace transfer.

## P1 — organization and curation

- [ ] Run one-week delayed re-finding studies.
- [ ] Keep folders human-curated and shareable.
- [ ] Add private many-to-many labels.
- [ ] Add explicit saved-query views.
- [ ] Preserve Unfiled as a valid state.
- [ ] Keep duplicate, stale-source, and route-split suggestions reversible.
- [ ] Avoid engagement ranking and opaque taxonomy.
- [ ] Recover or independently reimplement the absent Source Notes release bytes.

## P2 — remote Nodes

- [ ] Keep remote mode explicit and separate from loopback.
- [ ] Require TLS and persistent Node identity.
- [ ] Bound hosts, requests, artifacts, and rates.
- [ ] Add expiring invitations and durable revocation evidence.
- [ ] Keep public publication routes separate from private APIs.
- [ ] Begin with reviewed immutable-artifact retrieval.
- [ ] Test reverse proxies and self-hosting.
- [ ] No default public bind.
- [ ] No silent LAN discovery.
- [ ] No UPnP port opening.

## Lab — WebRTC courier

- [ ] Transfer exactly one already reviewed immutable artifact.
- [ ] Use bounded signed offer-and-answer metadata.
- [ ] Make signaling, STUN, and TURN visible.
- [ ] Compare QR, copy/paste, HTTPS, relay, and WebRTC friction.
- [ ] Refuse replay, identity mismatch, digest mismatch, timeout, and partial completion.
- [ ] Destroy the session after transfer.
- [ ] Never require WebRTC for ordinary reading, sharing, Capture, Witness, Pulse, Bearing, Trace, or Anchor.

# Verification boundary

Automated release evidence covers:

```text
Trace trail construction
recipe-footprint classification
Bearing v2 HTTP response
zero-network and zero-write flags
bounded unresolved history
Anchor handoff
Node dark and light rendering
Extension and Firefox synchronization
CLI and publication regression suites
archive determinism
clean-extraction byte and mode comparison
clean-extraction principal-suite replay
```

The following remain unexecuted rather than being represented as passes:

```text
unmanaged installed Chromium
current native Firefox
native Firefox ESR
signed-in real-site Trace flow
unfamiliar-human comprehension
real screen-reader, Braille, voice-control, and switch-device sessions
```

# Next coherent boundary

Run native Trace/Bearing/Anchor fieldwork. Then choose between:

```text
a reviewed declarative recipe-repair operation
additional fixture and explanation work
conditional Pinpoint selection
```

based on observed human and real-page failure—not on the availability of another
feature slot.

---

# BOOTSTRAPROSE — ProgRSS rev0074 “Bearing”

**Release:** rev0074 · **Product version:** 0.74.0 · **Vault schema:** 17 (unchanged)  
**Node-store schema:** `progrss.node-store.v4` (new)  
**Bearing review:** `progrss.node.bearing-review.v1` (new)  
**Hold-history evidence:** `progrss.node.capture-hold-history.v1` (new)  
**Current held observation:** `progrss.node.capture-hold.v1` (unchanged)  
**Capture artifact:** `progrss.browser-capture.v4` (unchanged)  
**Continuity evidence:** `progrss.capture-continuity.v1` (unchanged)  
**Anchor preview:** `progrss.node.baseline-preview.v1` (unchanged)  
**Anchor operation:** `replace-held-page-baseline` (unchanged)  
**Release date:** 2026-10-20  
**Release maxim:** **Explain the drift before proposing the repair.**

## `/run` interpretation

When this file is the active bootstrap, continue from the delivered rev0074
source tree. The source, schemas, tests, deterministic archive, release report,
clean-extraction replay, and `Evidence/rev0074-Bearing/` directory are the
implementation authority.

Do not reconstruct the current product from:

```text
rev0058 Branch alone
an incomplete no-scroll historical transcript
an unavailable rev0059 Source Notes file card
rev0067 Cadence prose without the missing package
rev0068 Pulse with its stale distributed bootstrap heading
rev0072 Drift without Anchor’s typed baseline replacement
rev0073 Anchor without Bearing’s bounded unresolved history
an image without matching source bytes
a release response without the matching deterministic archive
```

Older bootstrap sections remain below as historical design and chain-of-
custody evidence. When an older section conflicts with this first rev0074
section, this section wins.

## Chain-of-custody correction

A prior conversation response described rev0074 Bearing, but the corresponding
ZIP, bootstrap, report, notes, and screenshots were not present in the active
runtime when this `/run` began. Only a small CSV summary remained.

This release therefore does not treat the earlier response as delivered-byte
evidence. It reconstructs Bearing from the verified rev0073 Anchor archive,
implements and tests the bounded history and read-only diagnosis, then seals a
new deterministic rev0074 archive.

The preserved reconstruction note is:

```text
Evidence/rev0074-Bearing-reconstruction/README.md
```

The archive produced with this bootstrap is the executable rev0074 authority.

## Current lineage

```text
Nightstand   dark fluorescent everyday reader + first loopback Node
Handshake   explicit summary-only Extension ↔ Node pairing
Exchange    Follow / Add route / Take branch handoff
Confluence  three-way later-copy review
Receipt     first typed transactional Node write
Witness     one reviewed public acquisition
Capture     one bounded rendered-page observation
Pulse       foreground scheduling through Witness
Contour     explain why a selected section may hold or break
Perimeter   explain what the rendered page may leave outside
Threshold   require a decision about visible coverage limits
Drift       hold non-comparable partial windows
Anchor      replace one held baseline after explicit review
Bearing     explain repeated held windows before any repair
```

## Current product truths

- The everyday Extension remains the default product.
- The dark fluorescent aesthetic remains the default.
- Light mode remains an explicit persisted option.
- Forced-colors removes decorative fluorescent treatment.
- Reduced-motion remains respected.
- Advanced Workbench remains secondary.
- The Extension remains independently useful without a Node.
- The CLI and Node remain independently useful without a browser.
- The ordinary Node binds only to literal loopback.
- The portable library remains `progrss.private.v1` JSON.
- SQLite remains a local transaction and evidence mechanism.
- Pairing remains summary-only, read-only, process-lifetime, and revocable.
- Exchange remains artifact-scoped rather than continuous synchronization.
- Witness remains the only public Node acquisition path.
- Capture remains one deliberate exact-page browser observation.
- Pulse schedules only Node-reproducible Witness sources.
- Drift may hold a partial observation rather than invent change.
- Anchor may replace one current hold through a typed reviewed operation.
- Bearing explains unresolved holds but writes nothing.
- A shared route never transfers browser or scheduling authority.
- A Capture receipt never becomes Pulse eligibility.
- A paired Extension receives no Bearing or Anchor administrator authority.

# Why Bearing exists

Drift and Anchor solve different problems.

```text
Drift
  These two partial observations are not safely comparable.
  Keep the accepted baseline.

Anchor
  The current held rendering is intentionally the new comparison point.
  Replace it once after a separate reviewed write.
```

One held observation does not always tell a person which route is appropriate.
Repeated deliberate observations may show one of three bounded patterns:

1. Similar-sized partial renderings expose substantially different records.
2. Pagination, overlays, loading state, frame exclusions, or partial-render
   evidence changed between observations.
3. The observations remain too few or too inconsistent to explain.

Without Bearing, the bad answers would be:

- jump directly from one hold to a write;
- show raw overlap numbers without an ordinary-language consequence;
- silently rewrite the watched-page recipe;
- invent a confidence percentage;
- assume a virtualized page is unchanged;
- assume missing DOM records were deleted;
- expose a generic selector editor or JSON writer;
- let the paired Extension repair Node state;
- contact the site merely to explain local evidence.

Bearing instead provides one read-only review.

```text
Current accepted baseline
  The comparison point still in use.

Current held rendering
  The latest observation Drift refused to compare literally.

Recent unresolved observations
  Up to eight prior bounded holds for the same source.

Diagnosis
  Moving rendered window
  Page boundary shifted
  Not enough evidence yet

Next route
  Keep accepted baseline
  Open Anchor
  Begin a fresh Capture
```

# Store and evidence boundary

## Store migration

The Node store advances from:

```text
progrss.node-store.v3
```

to:

```text
progrss.node-store.v4
```

Migration adds `capture_hold_history` in one local transaction. It does not
rewrite:

- portable-library bytes;
- portable-library digest;
- portable-library revision;
- original imported backup bytes;
- operation receipts;
- acquisition receipts;
- before snapshots;
- the current held observation.

## Current plus eight prior

The existing `capture_holds` row remains the current unresolved proposal.
Before a later hold replaces it, the Node moves the previous row into
`capture_hold_history`.

Per watched-page source, the Node retains:

```text
1 current unresolved hold
up to 8 prior unresolved holds
```

Older diagnostic rows are pruned. The history cannot grow without bound.

## Retained fields

Each bounded row contains only:

- source ID;
- exact source-identity digest;
- Capture operation and receipt IDs;
- hold time and library digest;
- accepted and proposed snapshot digests;
- bounded proposed snapshot;
- bounded Capture provenance;
- Node-computed continuity evidence.

It contains no browser cookie, credential, storage, raw HTML, DOM, screenshot,
form value, script, open-tab list, Extension capability, or Node administrator
capability.

## Supersession

A later accepted observation clears the obsolete current hold and its prior
unresolved history for that source.

A successful Anchor replacement also clears the consumed current hold and its
prior unresolved history.

## Non-portability

Bearing history is Node-local. It does not travel through:

```text
progrss.private.v1 export
source-list publication
OPML
Exchange
branch excerpts
recent-updates feeds
static publication
Extension pairing
Pulse timing databases
```

Portable artifacts describe curation and reproducible recipes. Bearing records
what one local Node and browser observed.

# Read-only review contract

## Endpoint

```http
POST /api/v1/bearing-reviews
Authorization: Bearer NODE_ADMIN_CAPABILITY
Origin: http://127.0.0.1:PORT
Content-Type: application/json

{"sourceId":"SOURCE_ID"}
```

## Response schema

```text
progrss.node.bearing-review.v1
```

## Preconditions

The Node verifies:

- the library is Node-owned;
- the source exists;
- the source remains a watched page;
- a current unresolved hold exists;
- the source recipe identity still matches;
- the accepted baseline still matches the hold;
- retained snapshots pass their digest checks.

## Effects

```json
{
  "network": false,
  "writes": false
}
```

Review performs no DNS lookup, watched-site request, browser request, portable-
library mutation, receipt creation, hold removal, recipe change, source-state
change, schedule creation, publication, pairing change, or synchronization.

# Diagnosis contract

## Compatible observations

A prior hold is compatible only when it belongs to the same source identity and
references the same accepted baseline as the current hold.

Incompatible prior evidence remains local history but does not support a
held-to-held diagnosis for the current review.

## Moving rendered window

Bearing may report:

```text
Moving rendered window
```

when compatible partial observations:

- contain enough bounded comparison evidence;
- have similar sizes;
- expose less than 35-percent stable held-to-held overlap.

The ordinary explanation says that the browser may be showing different windows
into one larger collection.

It explicitly does not prove:

- that records remain on the site;
- that no records changed;
- that the publisher intended one logical collection;
- that the current recipe will remain stable;
- that Anchor is automatically correct.

The suggested route is Anchor only when the current held rendering is the
intentional future comparison point.

## Page boundary shifted

Bearing may report:

```text
Page boundary shifted
```

when compatible observations do not expose the same bounded page context, such
as changes in:

- continuation or pagination;
- partial rendering;
- visible overlays;
- loading state;
- excluded frames.

This does not prove a selector is wrong. It means the rendered page itself
should be reviewed again. The suggested route is fresh Capture.

## Not enough evidence yet

Bearing reports:

```text
Not enough evidence yet
```

when there are too few compatible observations or their bounded signals do not
form one clear pattern.

The suggested route is to keep the accepted baseline. Another deliberate
Capture may later add evidence.

## No opaque confidence

Bearing does not emit a probability or confidence score.

Advanced evidence may show:

- observations reviewed;
- compatible prior observations;
- low-overlap comparisons;
- current boundary kinds;
- accepted and proposed snapshot digests;
- bounded observation summaries;
- operation and receipt references.

Those values are evidence, not a measurement of truth or publisher intent.

# Human interface contract

## Source entry point

A watched-page source with a current hold shows:

```text
N unresolved held observations
Earlier baseline is still active

[Understand held windows]
```

The count describes one current plus bounded prior unresolved observations. It
is not an unread count or page-change count.

## Review hierarchy

1. Bearing label and observation count.
2. Plain statement that the accepted baseline remains active.
3. One diagnosis title.
4. One diagnosis summary.
5. One explicit limitation.
6. No repair applied.
7. Zero site requests.
8. Separate next decision.
9. Advanced held-window evidence.
10. Keep, Anchor, or fresh Capture.

## Status behavior

Completing the review produces a status message without automatically
performing a write or forcing a different repair route.

The message communicates:

```text
Held-window evidence reviewed
No watched-site request
No library change
```

## Three exits

### Keep accepted baseline

Closes Bearing. No write and no request occur.

### Open Anchor

Opens the existing read-only Anchor preview. It does not replace anything.
Anchor retains its separate unchecked acknowledgement, strong stale-base
condition, exact preview digest, random idempotency key, atomic commit, durable
receipt, and complete before snapshot.

### Begin a fresh Capture

Creates one short-lived exact-page Capture invitation. It does not read the
page automatically. The person still must open the exact page in the browser,
review browser-owned authority, extract bounded evidence, and submit one
reviewed artifact.

# Security and authority boundary

The ordinary Node remains:

```text
literal 127.0.0.1 binding
capability URL fragment
session-staged administrator capability
bearer-protected APIs
exact Host checks
same-Origin checks
no CORS grant
bounded request bodies
```

Bearing adds no remote bind and no public API.

The paired Extension receives no:

```text
Bearing history
held snapshot
source address
Node administrator capability
Bearing endpoint authority
Anchor write authority
schedule authority
```

Pairing remains:

```text
readLibrarySummary = true
readItems = false
readSourceAddresses = false
writeLibrary = false
fetchSources = false
publish = false
merge = false
nodeToNode = false
webrtcCourier = false
```

# Accessibility and cognition boundary

The ordinary interface uses:

- a clear purpose heading;
- diagnosis before raw evidence;
- explicit limitations;
- familiar buttons with distinct consequences;
- Advanced disclosure for hashes and IDs;
- no preselected repair;
- status text for review completion;
- persistent dark and light modes;
- forced-colors support;
- reduced-motion support;
- keyboard-visible focus;
- narrow-panel reflow.

The existence of automated focus and rendering checks is not represented as
completed human screen-reader, Braille, voice, switch, high-zoom, fatigue, or
cognitive acceptance.

# Prioritized checklist

## P0 — completed in Bearing

- [x] Reconstruct the missing rev0074 delivery from verified rev0073 bytes.
- [x] Preserve a chain-of-custody correction note.
- [x] Advance the local store to `progrss.node-store.v4`.
- [x] Preserve portable-library bytes and revision during migration.
- [x] Retain one current hold plus at most eight prior unresolved holds.
- [x] Validate retained snapshot digests before review.
- [x] Add `progrss.node.bearing-review.v1`.
- [x] Add Moving rendered window diagnosis.
- [x] Add Page boundary shifted diagnosis.
- [x] Add Not enough evidence yet diagnosis.
- [x] State what each diagnosis cannot prove.
- [x] Avoid an opaque confidence score.
- [x] Keep the review read-only and offline.
- [x] Offer Keep accepted baseline.
- [x] Route replacement through existing Anchor.
- [x] Route page or recipe reconsideration through fresh Capture.
- [x] Clear obsolete history after an accepted observation or Anchor commit.
- [x] Keep history outside portable sharing and timing artifacts.
- [x] Preserve summary-only paired Extension authority.
- [x] Preserve dark default and light option.
- [x] Add human and assistive-technology acceptance protocols.
- [x] Add migration, retention, diagnosis, HTTP, and rendered-interface tests.
- [x] Build and replay the deterministic delivery from a clean extraction.

## P0 — next: native Bearing and Anchor fieldwork

- [ ] Install the exact archive on unmanaged current Chromium.
- [ ] Install it on current Firefox and Firefox ESR.
- [ ] Produce several holds from a real public virtualized list.
- [ ] Produce several holds from a non-sensitive signed-in test page.
- [ ] Ask whether Moving rendered window sounds like certainty.
- [ ] Ask whether Open Anchor sounds like an immediate write.
- [ ] Ask what Begin a fresh Capture does before the browser action.
- [ ] Ask whether Keep accepted baseline contacts the site.
- [ ] Ask whether the paired Extension can perform repair.
- [ ] Test keyboard-only operation.
- [ ] Run real screen-reader and Braille sessions.
- [ ] Run voice-control and switch-style sessions.
- [ ] Run 200–400-percent zoom and forced-colors sessions.
- [ ] Run reduced-motion, fatigue, and interruption sessions.
- [ ] Change wording and hierarchy from observed wrong turns.

## P0 — fixture expansion

- [ ] Three or more disjoint virtual windows.
- [ ] Windows with one or two overlapping records.
- [ ] Constant DOM element count with recycled records.
- [ ] Stable destinations with changing visible text.
- [ ] Unknown totals using `aria-setsize=-1`.
- [ ] Incorrect author-supplied set metadata.
- [ ] Infinite scrolling that prepends older records.
- [ ] Boundary changes midway through an observation sequence.
- [ ] A genuine redesign that should route to fresh Capture.
- [ ] A stable held proposal that should route cleanly to Anchor.

## P1 — reviewed recipe repair

Do not build this from theory alone. Fieldwork must identify the exact repair.

A future typed operation must:

- [ ] name one exact watched-page source;
- [ ] begin from one Bearing review and its exact evidence;
- [ ] show the old and proposed declarative recipes;
- [ ] show matched and ignored specimens;
- [ ] explain what history remains;
- [ ] require an unselected acknowledgement;
- [ ] create a fresh baseline rather than inventing old change;
- [ ] require a strong reviewed-library precondition;
- [ ] be atomic, idempotent, receipted, and recoverable;
- [ ] preserve the prior recipe and snapshot for audit;
- [ ] accept no arbitrary shared JavaScript;
- [ ] expose no generic selector, snapshot, or JSON Patch writer.

## P1 — conditional Pinpoint

Build point-to-region selection only when fieldwork shows the bounded proposals
cannot express what people need.

It would require:

- [ ] exact active-page review;
- [ ] a temporary packaged isolated-world overlay;
- [ ] click, tap, and complete keyboard alternatives;
- [ ] screen-reader-discoverable regions;
- [ ] stable voice-control labels;
- [ ] switch-compatible sequential navigation;
- [ ] immediate cancellation and overlay removal;
- [ ] bounded declarative recipe output;
- [ ] Contour, Perimeter, Threshold, Drift, Bearing, and Anchor review;
- [ ] no form-value reads or page-control activation;
- [ ] no raw DOM, HTML, screenshot, or pointer-trace transfer.

## P1 — organization and curation

- [ ] Run one-week delayed re-finding studies.
- [ ] Keep folders human-curated and shareable.
- [ ] Add private many-to-many labels.
- [ ] Add explicit saved-query views.
- [ ] Preserve Unfiled as a valid state.
- [ ] Keep duplicate, stale-source, and route-split suggestions reversible.
- [ ] Avoid engagement ranking and opaque taxonomy.
- [ ] Recover or independently reimplement missing Source Notes bytes.

## P2 — remote Nodes

- [ ] Keep remote mode explicit and separate from loopback.
- [ ] Require TLS and persistent Node identity.
- [ ] Bound hosts, requests, artifacts, and rates.
- [ ] Add expiring invitations and durable revocation evidence.
- [ ] Separate public publication routes from private APIs.
- [ ] Begin with reviewed immutable-artifact retrieval.
- [ ] Test reverse proxies and self-hosting.
- [ ] No default public bind.
- [ ] No silent LAN discovery.
- [ ] No UPnP port opening.

## Lab — WebRTC courier

- [ ] Transfer one already reviewed immutable artifact.
- [ ] Use bounded signed offer-and-answer metadata.
- [ ] Make signaling, STUN, and TURN visible.
- [ ] Compare QR, copy/paste, HTTPS, relay, and WebRTC friction.
- [ ] Refuse replay, identity mismatch, digest mismatch, and partial completion.
- [ ] Destroy the session after transfer.
- [ ] Never require WebRTC for ordinary reading, sharing, Capture, Witness,
      Pulse, Bearing, or Anchor.

# Verification boundary

## Automated Python cases

```text
17/17  acquisition and Capture continuity
 9/9   Pulse/Cadence timing and dispatch
13/13  Node-store migration, bounded history, transaction, and replay
19/19  Node HTTP, pairing, Exchange, merge, Witness, Capture, Bearing, Anchor
46/46  direct CLI library tests
29/29  publication, integrity, continuity, and merge cases
26/26  command-line cases
159     total distinct Python cases
```

The old aggregate Relay and command-line wrappers can retain descendant output
handles. Their constituent cases are release evidence only when run in bounded
individual processes or small bounded groups.

## Extension and browser harnesses

```text
58/58  structural and static checks
PASS   Chromium background harness
PASS   Branch / Contents / Signpost / Edition core harness
PASS   generated Firefox background harness
PASS   acquisition and redirect harness
PASS   vault conflict and failed-write harness
PASS   twelve-case rendered-page fixture garden
PASS   rendered everyday reader
PASS   rendered Advanced Workbench
PASS   rendered Node Bearing and Anchor flows
```

## Native and human boundaries

```text
Unmanaged installed Chromium:        NOT RUN
Current native Firefox:              NOT RUN
Native Firefox ESR:                  NOT RUN
Signed-in real-site Bearing flow:    NOT RUN
Unfamiliar-human Bearing sessions:   NOT RUN
Real assistive-technology sessions:  NOT RUN
```

Those remain unexecuted work, not passes.

# Next coherent boundary

Run native and unfamiliar-human Bearing fieldwork. Then implement a reviewed
recipe-repair operation only if those sessions show that Keep, Anchor, and fresh
Capture do not cover the actual repair people need.

---

# BOOTSTRAPROSE — ProgRSS rev0073 “Anchor”

**Release:** rev0073 · **Product version:** 0.73.0 · **Vault schema:** 17 (unchanged)  
**Node-store schema:** `progrss.node-store.v3` (new)  
**Capture candidates:** `progrss.browser-capture-candidates.v3` (unchanged)  
**Capture artifact:** `progrss.browser-capture.v4` (unchanged)  
**Page context:** `progrss.capture-page-context.v1` (unchanged)  
**Coverage review:** `progrss.capture-coverage-review.v1` (unchanged)  
**Section assessment:** `progrss.capture-section-assessment.v1` (unchanged)  
**Continuity evidence:** `progrss.capture-continuity.v1` (unchanged)  
**Baseline replacement evidence:** `progrss.capture-baseline-replacement.v1` (new)  
**Baseline preview:** `progrss.node.baseline-preview.v1` (new)  
**Typed operation:** `replace-held-page-baseline` (new)  
**Extractor revision:** `perimeter-v1` (unchanged)  
**Release date:** 2026-10-20  
**Release maxim:** **Move the baseline. Keep the history.**

## `/run` interpretation

When this file is the active bootstrap, continue from the delivered rev0073
source tree. The source tree, exact schemas, tests, release metadata, sealed
archive, clean-extraction comparison, and rev0073 evidence directory are the
implementation authority.

Do not reconstruct the current product from:

```text
rev0058 Branch alone
an incomplete no-scroll historical transcript
a visible but absent rev0059 Source Notes file card
rev0067 Cadence prose without its missing package
rev0068 Pulse without correcting its stale bootstrap heading
rev0070 Perimeter without Threshold acknowledgement
rev0071 Threshold without Drift continuity
rev0072 Drift without Anchor baseline replacement
a screenshot without the delivered source bytes
a release response without the matching deterministic archive
```

Older bootstrap sections remain below as historical design and chain-of-
custody evidence. When an older section conflicts with this first rev0073
section, this section wins.

## Current lineage

```text
Nightstand   dark fluorescent everyday reader + first loopback Node
Handshake   explicit summary-only Extension ↔ Node pairing
Exchange    one handoff with Follow / Add route / Take branch
Confluence  human-first three-way later-copy review
Receipt     first typed transactional Node write: adopt one branch
Witness     one reviewed public feed or page-watch acquisition
Capture     one bounded rendered-page artifact without login transfer
Pulse       foreground scheduling through the Witness acquisition path
Contour     explain why a rendered section may hold or break
Perimeter   explain what one rendered browser view may leave outside
Threshold   require a deliberate decision for visibly limited coverage
Drift       hold non-comparable partial windows instead of inventing change
Anchor      deliberately replace one held baseline while retaining history
```

## Current product truths

- The everyday Extension reader remains the default product.
- Dark fluorescent presentation remains the default aesthetic.
- Light presentation remains an explicit persisted option.
- Forced-colors removes decorative fluorescent treatment.
- Reduced-motion remains respected.
- Advanced Workbench remains secondary.
- The Extension remains useful without a Node.
- The CLI remains useful without a browser.
- The Node remains the CLI’s local web-server mode.
- The ordinary Node binds only to literal loopback.
- The portable complete library remains `progrss.private.v1` JSON.
- SQLite remains a local transaction mechanism, not an interchange format.
- Pairing remains summary-only, read-only, process-lifetime, and revocable.
- Exchange remains artifact-scoped rather than synchronization.
- Confluence remains explicit three-way later-copy review.
- Receipt remains the typed branch-adoption operation.
- Witness remains the only Node-side public acquisition path.
- Capture remains one deliberate browser-rendered observation.
- Pulse remains foreground-only scheduling for Node-reproducible sources.
- Contour describes selected-section structure.
- Perimeter describes rendered-page coverage boundaries.
- Threshold records a deliberate coverage decision.
- Drift decides conservatively whether partial renderings are comparable.
- Anchor changes one future comparison point without rewriting past events.
- A shared route never transfers recurring network authority.
- A Capture receipt never becomes Pulse eligibility.
- A paired Extension never receives Anchor write authority.

# Why Anchor exists

Drift solved one dangerous comparison problem by refusing to infer that a
different partial DOM window represented a mass change in the publication.
That refusal creates a legitimate next question:

> What happens when the later held rendering is intentionally the comparison
> point the local administrator wants to use from now on?

Without a typed operation, the available bad answers would be:

- silently replace the accepted baseline
- pretend the held rendering was an ordinary detected change
- edit the private backup by hand
- expose a generic JSON patch endpoint
- let the paired Extension overwrite Node state
- discard the earlier accepted baseline
- create a fake historical add/remove alert
- recapture until the output happens to look convenient

Anchor instead creates one narrow reviewed operation.

```text
Accepted now
  The snapshot future observations currently compare against.

Held proposal
  One later rendering Drift refused to compare literally.

Replace baseline once
  Move the future comparison point to the held proposal.
  Retain the complete pre-operation library.
  Create no historical change item.
  Contact no watched site.
  Create no schedule.
```

# Human interface contract

## Source-card entry point

A watched-page source with a durable hold may show:

```text
Held rendered window available · 0% overlap.
Earlier baseline is still active.

[Review held window]
```

The card does not say that the page changed, that records disappeared, or
that the held proposal is recommended. It reports only that a later rendering
exists and the earlier baseline remains active.

## Review hierarchy

1. The source and expiry.
2. Accepted now.
3. Held proposal.
4. Stable-overlap evidence in ordinary language.
5. No past alert invented.
6. Earlier library retained.
7. Zero site requests.
8. One unselected acknowledgement.
9. Advanced held-window evidence.
10. Replace baseline once or Keep earlier baseline.

## Required acknowledgement

The acknowledgement is:

> **Use this held rendering as the new baseline**

Its description says that the earlier accepted baseline remains in recovery
evidence while future comparisons begin from the held rendering.

The checkbox is not preselected. The commit action is disabled until it is
selected. Keeping the earlier baseline is always available without a write.

## Result hierarchy

The ordinary receipt leads with:

```text
Baseline replaced
Earlier units
New baseline units
Past alerts created: 0
Library revision
Download before snapshot
Return to sources
```

Exact digests, operation IDs, held Capture IDs, continuity evidence, and
snapshot IDs remain under Advanced receipt evidence.

# Held-Capture persistence

## Store schema

The local store advances from:

```text
progrss.node-store.v2
```

to:

```text
progrss.node-store.v3
```

The migration adds a bounded `capture_holds` table. It does not rewrite:

- current portable-library bytes
- portable-library SHA-256
- library revision
- original imported backup bytes
- existing branch-operation receipts
- existing acquisition receipts
- existing pre-operation snapshots
- existing operation replay fingerprints

## One pending hold per source

A hold is local Node evidence, not portable curation content. The store retains
at most one current held observation per watched-page source.

The held row includes:

- source ID
- exact acquisition-identity digest
- held Capture operation ID
- held Capture receipt ID
- hold time
- library digest when held
- accepted snapshot digest
- proposed snapshot digest
- bounded proposed snapshot
- bounded proposed browser-Capture provenance
- Node-computed continuity evidence

## Supersession

A later accepted acquisition for the same source clears an obsolete hold.
A held observation does not travel through:

- private backup export
- source-list publication
- OPML
- Exchange handoff
- Extension pairing
- static publication
- Pulse timing database

# Offline preview contract

## Endpoint

```http
POST /api/v1/baseline-previews
Authorization: Bearer NODE_ADMIN_CAPABILITY
Origin: http://127.0.0.1:PORT
Content-Type: application/json

{"sourceId":"SOURCE_ID"}
```

## Preview schema

```text
progrss.node.baseline-preview.v1
```

## Preview checks

- The Node owns a writable transactional library.
- The held source still exists.
- The held source is still a watched page.
- The exact declarative acquisition identity has not changed.
- The accepted snapshot still matches the held evidence.
- The held Capture operation and receipt still match.
- The continuity action remains `hold`.
- The continuity evidence says the accepted baseline was preserved.
- The proposed snapshot remains structurally valid.
- The preview is bound to the local administrator.

## Preview effects

```json
{
  "network": false,
  "writes": false
}
```

The preview performs no DNS lookup, browser request, watched-site request,
portable-library mutation, hold removal, or schedule creation.

## Preview consequences

```text
acceptedBaselineReplaced = true
earlierCompleteLibrarySnapshotRetained = true
historicalChangeAlertCreated = false
recipeChanged = false
sourceEnabledChanged = false
networkRequests = 0
automaticScheduleCreated = false
```

The preview expires after ten minutes.

# Commit contract

## Operation type

```text
replace-held-page-baseline
```

## Required request boundaries

### Strong base precondition

`If-Match` identifies the exact reviewed Node library with a strong quoted
SHA-256 digest. A missing, weak, malformed, or stale condition is refused.

### Exact preview

The commit supplies the short-lived preview token and exact preview digest.
The digest covers the source, acquisition identity, held operation, held
receipt, accepted snapshot, proposed snapshot, base library, and resulting
library.

### Idempotency

`Idempotency-Key` is a random URL-safe operation identity from 16 through
200 characters.

An exact completed retry returns the stored receipt with:

```json
{
  "replayed": true
}
```

It performs no second write and no watched-site request.

The same key with different reviewed content is refused.

## Stale or conflicting conditions

- base library changed after review
- preview expired
- preview digest changed
- source removed
- source changed from watched page to another type
- acquisition recipe changed
- accepted snapshot changed
- held observation superseded
- held operation or receipt changed
- hold missing
- operation key reused for different content
- Node opened a read-only exported backup instead of a Node-owned library

# Atomic result

## One transaction

One SQLite transaction records:

- complete pre-operation `progrss.private.v1` snapshot
- new complete portable library
- new portable-library digest
- new library revision
- operation receipt
- request replay fingerprint
- removal of the consumed held observation

Failure injection exists:

- before transaction
- after snapshot insertion
- after library replacement
- after receipt insertion

Each injected failure leaves the library, receipts, snapshots, and held row
unchanged.

## Portable-library effect

The watched-page source receives:

```text
lastOutcome = baseline-replaced
lastItems = 0
watchHealth.status = steady
watchHealth.reason = baseline-replaced
baselineReplacement.schema = progrss.capture-baseline-replacement.v1
```

The operation:

- replaces the accepted comparison snapshot
- installs the held browser-Capture provenance
- clears obsolete continuity transient state
- clears obsolete stability transient state
- clears obsolete repair transient state
- records previous and accepted snapshot digests
- records zero historical change alerts
- preserves unrelated retained items
- preserves read and saved state
- preserves unrelated folders and labels
- preserves the watched-page recipe
- preserves source active/paused state
- preserves earlier complete library in the before snapshot

It does not:

- create a page-change item
- backdate the held rendering
- claim records were added or removed
- contact the watched site
- contact the browser
- change a selector or watched section
- enable a paused source
- create a Pulse schedule
- publish anything
- synchronize another library
- expose generic JSON Patch

# Recovery evidence

The result includes a complete pre-operation snapshot ID and digest.
The local administrator can export it through the existing new-file-only
snapshot route or CLI command.

The snapshot is:

- a complete portable private library
- byte-bounded and digest-addressed
- kept with the operation receipt
- useful for inspection and comparison
- useful for deliberately initializing another Node-owned library

The snapshot is not:

- an automatic undo button
- a hidden rollback trigger
- a public publication
- a source-list artifact
- a pairing payload
- a scheduler database

# Extension boundary

After Drift returns **Rendered window held**, the Extension now says that the
local Node has a separate review and that nothing has been replaced yet.

The Extension does not receive through pairing:

- held snapshot bytes
- accepted snapshot bytes
- source address
- Node administrator capability
- baseline preview capability
- operation endpoint authority
- operation receipt contents
- before snapshot contents

Summary-only pairing remains:

```text
readLibrarySummary = true
readItems = false
readSourceAddresses = false
writeLibrary = false
fetchSources = false
publish = false
merge = false
nodeToNode = false
webrtcCourier = false
```

Anchor therefore remains local-administrator review, not synchronization.

# Browser and network authority

Anchor adds no browser manifest permission.

The review and commit require no:

- website host permission
- loopback permission inside the Extension
- active tab
- scripting injection
- cookie permission
- native messaging
- browser profile read
- page Capture
- DNS lookup
- HTTP request to the watched site

The local Node administrator already holds the Node fragment/bearer boundary.
Exact `Host`, `Origin`, no-CORS, loopback, request-size, and bearer checks
remain unchanged.

# How Anchor relates to sharing

The three Exchange doors remain:

```text
Follow updates
Add the complete route
Take one branch
```

A shared route may carry:

- feeds
- declarative watched-page recipes
- folders
- curation context
- integrity evidence
- publication continuity

A shared route does not carry:

- accepted page snapshots
- held browser renderings
- Anchor acknowledgements
- before snapshots
- read or saved state
- browser credentials
- browser permissions
- Pulse schedules
- Node administrator authority

The recipient establishes their own acquisition evidence and comparison
baseline. Curation remains portable. Execution authority remains local.

# Sites without RSS

The current acquisition ladder is:

```text
1. Existing RSS, Atom, or JSON Feed
2. Feed advertised by the page
3. Node-reproducible declarative page watch
4. Browser-assisted rendered-page Capture
5. Browser-only deliberate observation
```

Contour, Perimeter, Threshold, Drift, and Anchor now define a conservative
browser-assisted sequence:

```text
choose a rendered section
  ↓
understand why it may hold or break
  ↓
understand what the rendered page may omit
  ↓
accept visible coverage limits when necessary
  ↓
save one bounded observation
  ↓
hold a later non-comparable partial window
  ↓
deliberately replace the baseline only through Anchor
```

Arbitrary curator-supplied JavaScript remains outside the normal recipe
format. The browser keeps login authority. The Node keeps bounded evidence.

# Organization

Anchor does not add organization furniture. The intended model remains:

```text
Folders
  Human-curated routes; hierarchical; potentially shareable.

Private labels
  Many-to-many local organization; not yet delivered.

Saved views
  Explicit reusable queries; not yet delivered.

Unfiled
  A legitimate resting state, not an error.
```

The acceptance measure remains whether a person can find material again later,
not whether they can create a folder while being coached.

# Accessibility and cognitive contract

The ordinary path must preserve:

- one clear heading for the current task
- consequence language before hashes and IDs
- no preselected consequential choice
- ordinary buttons rather than gesture-only control
- keyboard-visible focus
- status announcements without forced focus theft
- 320 CSS pixel reflow
- 200 through 400 percent zoom
- forced-colors boundaries without decorative neon dependence
- reduced-motion behavior
- dark and light readable contrast
- advanced evidence behind one disclosure
- cancel or keep-earlier action adjacent to commit

Words requiring unfamiliar-human evidence:

- held rendering
- accepted baseline
- future comparison point
- past alert
- before snapshot
- recovery evidence
- automatic undo
- exact retry
- site request
- schedule

Observed confusion should change wording or hierarchy. It should not produce
hidden replacement, a generic mutation endpoint, ambient pairing authority,
engagement ranking, or another notification stream.

# Security invariants

- One local administrator writer.
- One typed operation.
- One exact reviewed base library.
- One exact held observation.
- One short-lived preview.
- One idempotency identity.
- No generic JSON Patch.
- No arbitrary filesystem write.
- No paired-Extension write.
- No site request.
- No schedule.
- No historical alert.
- No silent recipe change.
- No silent source enablement.
- No replay with changed content.
- No stale-base commit.
- No loss of the earlier complete library.

# CLI and administrative surface

Existing Node commands remain:

```sh
./progrss node init PRIVATE.json --output LIBRARY.sqlite3
./progrss node serve LIBRARY.sqlite3 --open
./progrss node export LIBRARY.sqlite3 --output CURRENT.json
./progrss node receipts LIBRARY.sqlite3
./progrss node snapshot LIBRARY.sqlite3 SNAPSHOT_ID --output BEFORE.json
./progrss node acquisitions LIBRARY.sqlite3
```

Anchor is presently a local Node web operation rather than a separate CLI
mutation command. The durable operation and snapshot remain inspectable and
exportable through the existing CLI evidence commands.

# Data and schema inventory

- `progrss.private.v1` — portable complete private library
- `progrss.node-store.v3` — local transactional Node implementation
- `progrss.browser-capture.v4` — current strict browser Capture artifact
- `progrss.capture-page-context.v1` — bounded rendered-page limits
- `progrss.capture-coverage-review.v1` — deliberate coverage decision
- `progrss.capture-section-assessment.v1` — bounded section evidence
- `progrss.capture-continuity.v1` — Node-computed partial-window continuity
- `progrss.node.baseline-preview.v1` — offline Anchor review
- `progrss.capture-baseline-replacement.v1` — durable replacement evidence
- `progrss.node.operation-request.v1` — typed operation request material
- `progrss.node.operation-result.v1` — operation response envelope

# Verification plan and delivered evidence

The release is not sealed until all of these are true:

- [x] acquisition and Capture tests pass
- [x] Pulse/Cadence tests pass
- [x] Node-store migration, transaction, failure, and replay tests pass
- [x] Node HTTP and typed-operation tests pass
- [x] direct CLI library tests pass
- [x] Relay/publication/integrity/continuity tests pass in bounded cases
- [x] command-line cases pass in bounded cases
- [x] Extension structural/static checks pass
- [x] Chromium background harness passes
- [x] generated Firefox background harness passes
- [x] shared-folder core harness passes
- [x] acquisition redirect harness passes
- [x] vault conflict harness passes
- [x] fixture garden passes
- [x] everyday reader rendering passes
- [x] Advanced Workbench rendering passes
- [x] Node Anchor review and receipt rendering passes
- [x] all Python files compile
- [x] all JavaScript files parse
- [x] all JSON files parse
- [x] POSIX shell files parse
- [x] archive builds twice byte-identically
- [x] ZIP CRC and unique-member checks pass
- [x] archive paths are safe
- [x] no symlink, nested archive, runtime database, cache, or bytecode ships
- [x] clean extraction matches source bytes and executable modes
- [x] principal suites replay from clean extraction

Final exact counts and archive digest are recorded in the release report after
the deterministic archive is sealed.

## Working-tree verification result

```text
PASS 17/17  acquisition and Capture continuity
PASS  9/9   Pulse/Cadence timing and dispatch
PASS 11/11  Node-store migration, transaction, failure, and replay
PASS 18/18  Node HTTP, pairing, Exchange, merge, operations, Witness, Capture, and Anchor
PASS 46/46  direct CLI library tests
PASS 29/29  Relay, publication, integrity, continuity, and merge in bounded cases
PASS 26/26  command-line cases in bounded cases
PASS 156    distinct Python cases

PASS 58/58  Extension structural/static checks
PASS        Chromium background harness
PASS        generated Firefox background harness
PASS        Branch / Contents / Signpost / Edition core harness
PASS        acquisition and redirect harness
PASS        vault conflict and failed-write harness
PASS        twelve-case rendered-page fixture garden
PASS        rendered everyday reader
PASS        rendered Advanced Workbench
PASS        rendered Node Anchor review and receipt

PASS 26     Python source files compiled in memory
PASS 64     JavaScript files parsed
PASS 59     JSON files parsed
PASS  2     POSIX shell files parsed
PASS        CLI 0.73.0
PASS        Cadence/Pulse help
PASS        CLI doctor
```

Native installed-browser and unfamiliar-human lanes remain not run.

# Native and human acceptance boundary

Automated evidence is not native or human acceptance.

Still required:

- [ ] unmanaged current Chromium installation
- [ ] current native Firefox installation
- [ ] native Firefox ESR installation
- [ ] native loopback Node review
- [ ] signed-in real-site Capture with non-sensitive test data
- [ ] unfamiliar administrator review of one held window
- [ ] keyboard-only session
- [ ] real screen-reader session
- [ ] Braille session
- [ ] voice-control session
- [ ] switch-style session
- [ ] 200–400 percent zoom
- [ ] forced-colors session
- [ ] reduced-motion session
- [ ] fatigue and interruption session
- [ ] permission cleanup observation
- [ ] lost-response retry comprehension
- [ ] before-snapshot comprehension

Managed host policy in the build environment still blocks native unpacked
Chromium installation and direct browser loopback navigation. No policy is
removed or changed. Missing native lanes are reported as not run, not passes.

# Prioritized checklist

## P0 — implemented in Anchor

- [x] Persist one held partial Capture observation per watched-page source.
- [x] Migrate v2 Node stores to v3 without rewriting portable-library bytes.
- [x] Expose one offline baseline preview.
- [x] Show Accepted now and Held proposal.
- [x] Show overlap without requiring formula comprehension.
- [x] Explain no past alert, earlier library retained, and zero site requests.
- [x] Require one unselected acknowledgement.
- [x] Expose Keep earlier baseline without a write.
- [x] Commit only through `replace-held-page-baseline`.
- [x] Require strong base-library `If-Match`.
- [x] Require exact preview digest and capability.
- [x] Require one idempotency key.
- [x] Refuse stale library, recipe, baseline, or hold.
- [x] Atomically retain a complete before snapshot.
- [x] Atomically write the new library and receipt.
- [x] Remove the consumed hold atomically.
- [x] Return exact completed replay.
- [x] Refuse same-key changed-content reuse.
- [x] Create no historical page-change item.
- [x] Make zero watched-site requests.
- [x] Create no schedule.
- [x] Keep paired Extension authority read-only.
- [x] Add Node and Extension acceptance tasks.
- [x] Preserve dark default, light option, forced colors, and reduced motion.

## P0 — next: native Anchor fieldwork

- [ ] Install the exact release on unmanaged current Chromium.
- [ ] Install on current Firefox and Firefox ESR.
- [ ] Create a real held virtualized-window observation.
- [ ] Observe whether people distinguish Accepted now and Held proposal.
- [ ] Ask what changes after replacement.
- [ ] Ask whether a past add/remove alert is created.
- [ ] Ask whether the Node contacts the site.
- [ ] Ask whether a schedule is created.
- [ ] Ask whether the paired Extension can perform the write.
- [ ] Ask whether the before snapshot is evidence or automatic undo.
- [ ] Simulate a lost response and observe retry understanding.
- [ ] Test cancellation before acknowledgement.
- [ ] Test interruption after acknowledgement but before commit.
- [ ] Test keyboard, screen reader, Braille, voice, switch, zoom, forced colors, reduced motion, and fatigue.
- [ ] Revise wording and hierarchy from observed wrong turns.

## P0 — next technical boundary: held-window repair

- [ ] Count repeated holds without turning them into engagement metrics.
- [ ] Explain which continuity evidence changed.
- [ ] Distinguish moving viewport from genuinely missing records.
- [ ] Offer repair review only after understandable evidence.
- [ ] Keep earlier recipes and snapshots for audit.
- [ ] Never silently replace a selector or baseline.
- [ ] Keep repair typed, stale-base checked, idempotent, receipted, and reversible through evidence.
- [ ] Keep arbitrary shared JavaScript out.

## P0 — fixture expansion

- [ ] DOM-node recycling with constant visible element count.
- [ ] Virtual windows with one overlapping record.
- [ ] Virtual windows with two overlapping records.
- [ ] Record keys derived only from changing text.
- [ ] Unknown total size through `aria-setsize=-1`.
- [ ] Inconsistent author-supplied set metadata.
- [ ] Infinite scrolling that prepends records.
- [ ] Icon-only continuation controls.
- [ ] Localized continuation controls.
- [ ] Multiple overlapping dialogs.
- [ ] Nested open roots near traversal limits.
- [ ] Same-origin frame specimen.
- [ ] Cross-origin frame specimen.
- [ ] Canvas and WebGL explicitly outside the text contract.

## P1 — organization and re-finding

- [ ] Run one-week delayed re-finding studies.
- [ ] Keep folders human-curated and shareable.
- [ ] Add private many-to-many labels.
- [ ] Add explicit saved-query views.
- [ ] Preserve Unfiled as a valid state.
- [ ] Make duplicate and stale-source suggestions reversible.
- [ ] Avoid engagement ranking.
- [ ] Avoid opaque automatic taxonomy.

## P1 — conditional Pinpoint

- [ ] Build only when fieldwork demonstrates a proposal gap.
- [ ] Begin from the exact reviewed active page.
- [ ] Use a temporary packaged isolated-world overlay.
- [ ] Support click or tap without requiring dragging.
- [ ] Support complete keyboard operation.
- [ ] Provide screen-reader-discoverable regions.
- [ ] Provide stable voice-control labels.
- [ ] Support switch-compatible sequential selection.
- [ ] Read no form values and click no page controls.
- [ ] Remove the overlay immediately after selection or cancellation.
- [ ] Convert the result into a bounded declarative recipe.
- [ ] Run Contour, Perimeter, Threshold, Drift, and Anchor boundaries as appropriate.
- [ ] Transfer no raw DOM, HTML, screenshot, or pointer trace.

## P1 — Source Notes recovery

- [ ] Recover the actual rev0059 archive or independently reimplement it.
- [ ] Keep notes short, plain text, and scoped to one folder/source relation.
- [ ] Keep notes outside acquisition identity.
- [ ] Cover notes with native publication integrity.
- [ ] Preserve notes in branch excerpts.
- [ ] Report OPML omission.
- [ ] Include note disagreement in Confluence review.
- [ ] Do not turn notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

- [ ] Separate remote mode from loopback mode.
- [ ] Require TLS.
- [ ] Require persistent Node identity.
- [ ] Bound hostnames, requests, artifacts, and rates.
- [ ] Add expiring invitations and durable revocation evidence.
- [ ] Separate public publication routes from private APIs.
- [ ] Begin with immutable artifact retrieval.
- [ ] Test reverse proxies and self-hosting.
- [ ] No default public bind.
- [ ] No silent LAN discovery.
- [ ] No UPnP port opening.
- [ ] No “enter an IP address and hope” basic flow.

## Lab — WebRTC courier

- [ ] Transfer exactly one already reviewed immutable artifact.
- [ ] Use bounded signed offer-and-answer metadata.
- [ ] Make signaling visible.
- [ ] Make STUN and TURN visible.
- [ ] Compare QR, copy/paste, HTTPS, relay, and WebRTC friction.
- [ ] Refuse replay.
- [ ] Refuse identity mismatch.
- [ ] Refuse digest mismatch.
- [ ] Refuse timeout and partial completion.
- [ ] Discard the session after transfer.
- [ ] Never require WebRTC for ordinary reading, sharing, Capture, Witness, Pulse, or Anchor.

# Human-language glossary

## Accepted now

The page snapshot future observations currently compare against.

## Held proposal

A later rendered observation ProgRSS refused to compare literally.

## Baseline

The comparison point; not the complete history of the site.

## Replace baseline once

Move the future comparison point after a separate review.

## Past alert

A retained item claiming that something changed earlier.

## No past alert invented

Anchor changes the comparison point without claiming a prior event.

## Before snapshot

A complete private-library copy from immediately before the operation.

## Recovery evidence

Material that can be inspected or deliberately reused; not automatic undo.

## Exact replay

Return the existing receipt for the same completed operation identity and content.

## Stale review

The library, recipe, accepted baseline, or held evidence changed after review.

## Zero site requests

The local review and commit do not contact the watched page.

## No schedule

The operation does not create recurring acquisition.

# Release boundary

```text
Extension version:             0.73.0
CLI / Node version:            0.73.0
Revision:                      rev0073
Codename:                      Anchor
Vault schema:                  17, unchanged
Private backup schema:         progrss.private.v1
Node-store schema:             progrss.node-store.v3
Capture artifact:              progrss.browser-capture.v4
Continuity schema:             progrss.capture-continuity.v1
Baseline preview schema:       progrss.node.baseline-preview.v1
Baseline replacement schema:   progrss.capture-baseline-replacement.v1
Typed operation:               replace-held-page-baseline
New required host access:      none
New Extension permissions:     none
Node watched-site requests:    0
Historical alerts created:     0
Automatic schedule:            none
Paired Extension write:        none
Account or cloud service:      none
Telemetry:                     none
Private-key export:            none
```

# Next coherent boundary

The next release should be driven first by native and unfamiliar-human
Anchor fieldwork. The next technical boundary should connect repeated held
windows to explicit repair evidence, not expand ambient write authority.

Remote Nodes, WebRTC, permanent schedulers, direct visual Pinpoint selection,
and broader mutation types remain later work. The immediate question is
whether people understand that Anchor moves one future comparison point while
keeping the earlier complete library and inventing no history.

---

# Historical bootstrap follows — rev0072 Drift and earlier

# BOOTSTRAPROSE — ProgRSS rev0072 “Drift”

**Release:** rev0072 · **Product version:** 0.72.0 · **Vault schema:** 17 (unchanged)  
**Node-store schema:** `progrss.node-store.v2` (unchanged)  
**Capture candidates:** `progrss.browser-capture-candidates.v3` (unchanged)  
**Capture artifact:** `progrss.browser-capture.v4` (unchanged)  
**Page context:** `progrss.capture-page-context.v1` (unchanged)  
**Coverage review:** `progrss.capture-coverage-review.v1` (unchanged)  
**Section assessment:** `progrss.capture-section-assessment.v1` (unchanged)  
**Continuity evidence:** `progrss.capture-continuity.v1` (new)  
**Extractor revision:** `perimeter-v1` (unchanged)  
**Release date:** 2026-10-20  
**Release maxim:** **A moving window is not a changed world.**

## `/run` interpretation

When this file is the active bootstrap, continue from the delivered rev0072
source tree. The rev0072 tree, schemas, tests, metadata, clean-extraction
comparison, and sealed archive are the implementation authority.

Do not reconstruct the current product from:

```text
rev0058 Branch alone
the no-scroll historical transcript
an absent rev0059 Source Notes archive
rev0067 Cadence's incomplete archive
rev0068 Pulse's stale bootstrap heading
rev0071 Threshold without Drift's partial-window continuity rule
an image card without the delivered source bytes
```

All older bootstrap sections remain below as historical design and
chain-of-custody evidence. Where an older section conflicts with this first
rev0072 section, this section wins.

## Current lineage

```text
Nightstand   dark fluorescent everyday reader + first loopback Node
Handshake   explicit summary-only Extension ↔ Node pairing
Exchange    one handoff with Follow / Add route / Take branch
Confluence  human-first three-way later-copy review
Receipt     one transactional Node-owned branch-adoption operation
Witness     one reviewed public feed or page-watch acquisition
Capture     one reviewed rendered-page artifact without login transfer
Pulse       foreground Node scheduling through the Witness path
Contour     explain why a rendered section may hold or break
Perimeter   explain what one rendered browser view may leave outside
Threshold   require a deliberate decision for a visibly limited view
Drift       preserve history when partial DOM windows are not comparable
```

## Current product truths

```text
The everyday Extension reader remains the default product.
Dark fluorescent presentation remains the default.
Light presentation remains an explicit persisted option.
Forced-colors removes decorative fluorescent treatment.
Reduced-motion remains respected.
Advanced Workbench remains secondary.
The Extension remains useful without a Node.
The CLI remains useful without a browser.
The Node remains the CLI's local web-server mode.
The ordinary Node binds only to literal loopback.
The portable complete library remains progrss.private.v1 JSON.
SQLite remains a local transaction mechanism, not an interchange format.
Pairing remains summary-only, read-only, process-lifetime, and revocable.
Exchange remains artifact-scoped rather than synchronization.
Confluence remains explicit three-way later-copy review.
Receipt's typed branch-adoption write remains the only delivered route write.
Witness remains the only Node-side public acquisition path.
Capture remains one deliberate browser-rendered observation.
Pulse remains foreground-only scheduling for Node-reproducible sources.
Contour describes section stability.
Perimeter describes rendered-page coverage.
Threshold records the human coverage decision.
Drift decides conservatively whether two partial renderings are comparable.
A shared route never transfers recurring network authority.
A Capture receipt never becomes Pulse eligibility.
```

# Why Drift exists

A page may expose only one moving window of a larger set in the DOM.

Examples include:

```text
virtualized incident lists
infinite feeds that recycle article nodes
scroll windows that replace earlier cards
responsive lists that load only visible records
large sets whose aria-setsize exceeds rendered children
lists whose aria-posinset values move as the viewport moves
```

Perimeter makes this boundary visible before Capture.
Threshold requires the person to decide whether to use the limited rendering.
Neither release solved the later comparison problem.

Suppose the accepted baseline contains:

```text
records 41, 42, 43, 44
```

A later deliberate Capture may contain:

```text
records 145, 146, 147, 148
```

A literal set diff says:

```text
four removals
four additions
```

That conclusion is not justified. The browser may simply be showing a
different viewport into the same 500-record collection.

Drift adds a conservative boundary before ordinary page-watch diffing.

# Human outcome

The ordinary result is:

```text
Rendered window held
```

The explanation is:

```text
The partial rendering looked like a different window.
The earlier baseline was kept.
No mass add-or-remove alert was created.
```

The ordinary result also retains the existing consequence facts:

```text
items added: 0
Node watched-site requests: 0
library revision: advanced by one durable receipt
schedule: none created
```

The advanced receipt can show:

```text
previous comparison units
current comparison units
shared units
overlap percentage
partial-render boundary before and after
accept or hold
reason
earlier baseline preserved
```

The interface does not display an opaque confidence score.
It does not claim that nothing changed.
It says only that the two partial observations were not safely comparable.

# Computed continuity contract

The schema is:

```text
progrss.capture-continuity.v1
```

The decision is computed by the Node from:

```text
last accepted page-watch snapshot
last accepted browser-capture provenance
new strictly validated browser-capture artifact
```

The Extension does not submit:

```text
continuityAction
confidence
baselinePreserved
overlap percentage
```

That separation prevents a page, curator, or browser-side artifact from
asserting that an unsafe comparison is safe.

## Card-mode comparison

For repeated cards, Drift compares the stable bounded keys already used by the
page-watch snapshot.

```text
previous set = accepted card keys
current set  = new validated card keys
shared       = intersection
```

The overlap denominator is the smaller non-empty set.

This favors continuity when a page expands while retaining the accepted cards,
but holds when a small partial window is mostly replaced by unrelated keys.

## Region-mode comparison

For one readable region, Drift compares bounded case-folded word tokens.

The token set is:

```text
Unicode-aware
bounded to 4,000 unique comparison tokens
computed locally
not stored as a new public identifier
```

Region comparison requires more evidence than card comparison before low
overlap can trigger a hold.

## Hold conditions

A comparison is held only when at least one accepted observation reports the
`partial-render` page-context boundary and either:

```text
the accepted and incoming partial-render boundary differs
```

or:

```text
the observations contain enough comparison units
and stable overlap is below 35 percent
```

A complete-page comparison with no partial-render evidence continues through
the pre-existing page-watch path.

## Accepted partial comparison

A partial rendering with enough stable overlap continues through:

```text
page-shape health
stability confirmation
card or text difference
Before / Now evidence
ordinary changed, unchanged, pending, or repair outcome
```

Drift does not replace those safeguards.
It runs before them.

# Baseline preservation

A held rendered window does not replace:

```text
accepted snapshot
accepted browser-capture provenance
accepted recipe
retained items
read or saved state
page-watch history
```

It does update durable operational evidence:

```text
last check time
check count
last outcome = coverage-shift
attention health record
continuity record
acquisition receipt
library revision
```

This allows the Node to prove that an observation occurred without pretending
that the observation was comparable to the baseline.

# Current deliberate limitation

Rev0072 does not silently replace an obsolete partial baseline after repeated
holds.

That is deliberate.

A permanent site redesign or a deliberate move to a new virtual window may
require a new baseline. The next write boundary must be an explicit reviewed
operation that says:

```text
replace this partial baseline
preserve the previous snapshot as evidence
explain why the old and new observations are not comparable
create no historical change alert
```

Until that operation exists, a person can choose a genuinely different watched
section and create a fresh baseline through the existing recipe-change review.
ProgRSS does not disguise baseline replacement as ordinary observation.

# Research basis

WAI-ARIA explicitly provides set position and size metadata for cases where the
DOM does not contain the complete set. The WAI feed pattern likewise treats
feeds as dynamic structures that may load content as a person scrolls and uses
`aria-posinset`, `aria-setsize`, and `aria-busy` to communicate that state.

ProgRSS uses those patterns only as evidence that DOM absence may be caused by
partial rendering. It does not assume that every author uses ARIA correctly,
and it does not interpret ARIA metadata as proof that content is unchanged.

Primary references retained for this design review:

```text
https://www.w3.org/TR/wai-aria-1.2/
https://www.w3.org/WAI/ARIA/apg/patterns/feed/
https://www.w3.org/WAI/ARIA/apg/patterns/feed/examples/feed/
```

# Authority and privacy

Drift changes comparison, not authority.

Capture remains:

```text
one exact reviewed active HTTP(S) page
top-frame only
fixed packaged isolated-world extraction
at most three bounded candidates
bounded JSON-safe text and links
one selected source
one reviewed operation
```

It transfers no:

```text
cookies
credentials
authorization headers
localStorage or sessionStorage
IndexedDB
service-worker caches
form values
raw HTML
DOM nodes
screenshots
pixels
page scripts
open-tab list
browser capability
Node administrator capability
```

The Node still makes zero watched-site requests for browser-assisted Capture.
No Capture creates a schedule.
No paired Extension gains a general Node writer.
Pulse still requires successful Node-side Witness evidence for the exact source.

# Sharing and curation remain unchanged

The recipient doors remain:

```text
Follow updates
Add the complete route
Take one branch
```

A shared route may carry:

```text
feeds
page-watch recipes
folder routes
curation context
integrity evidence
publication continuity
```

It does not carry:

```text
browser credentials
browser permissions
Capture decisions
local snapshots
Pulse schedules
read or saved state
```

The recipient makes their own local acquisition, coverage, continuity, and
schedule decisions.

The governing principle remains:

> **Curation is portable. Execution authority remains local.**

# Fixture garden

The real-browser fixture garden now contains twelve retained page classes:

```text
semantic repeated records with hidden descendants
numbered pagination and rel=next
one partial virtualized window
one disjoint later virtualized window
visible consent overlay
busy/loading region
embedded frame plus open shadow root
closed shadow-root boundary
hidden responsive desktop/mobile duplicates
mixed update and promotional/form content
right-to-left content
localized right-to-left continuation
```

The two virtualized fixtures use disjoint record keys while both expose a
500-item set through `aria-setsize` and bounded `aria-posinset` values.

The fixture lane proves:

```text
both renderings are recognized as partial
stable keys from the two windows are disjoint
hidden responsive duplicates are excluded
mixed form/aside clutter lowers section quality
localized continuation does not depend solely on English labels
closed shadow content remains outside the extractor contract
```

The Node continuity tests separately prove that disjoint partial windows are
held and do not become mass alerts.

# GUI hierarchy

The ordinary Capture review remains:

```text
What this browser view may leave outside
Later comparison stays conservative
Rendered section choices
Matched now
Ignored example
Why this may hold
What could break
Coverage decision
Send once
```

The result remains:

```text
Rendered window held
Earlier baseline kept
human explanation
items added
Node site requests
library revision
schedule
Advanced capture receipt
```

Hashes, operation IDs, exact overlap, and provenance remain under Advanced.

# Exact implementation boundary

## Python

`CLI/acquisition.py` adds:

```text
BROWSER_CAPTURE_CONTINUITY_SCHEMA
browser_capture_continuity()
coverage-shift outcome
baseline-preserving application path
```

`CLI/node_server.py` receipts:

```text
continuitySchema
continuityAction
continuityReason
continuityOverlapPercent
baselinePreserved
```

## Extension

`Extension/sidepanel/app.js` adds:

```text
Later comparison stays conservative
Rendered window held
Earlier baseline kept
Rendered-window comparison
```

`Extension/sidepanel/app.css` adds bounded Drift result and explanation styles.
The generated Firefox sibling is byte-synchronized for shared runtime files.

## Tests

The direct acquisition lane covers:

```text
disjoint partial card windows
sufficient-overlap acceptance
full-to-partial boundary change
baseline byte preservation
accepted provenance preservation
zero generated page-watch item
```

The Node HTTP lane covers:

```text
one accepted partial baseline
one disjoint later window
zero Node watched-site request
one durable coverage-shift receipt
snapshot preservation
exact idempotent replay
no second write
```

The rendered reader lane covers:

```text
partial-render explanation before submission
explicit Threshold decision
Rendered window held result
baseline-preserved explanation
advanced overlap evidence
dark and light modes
```

# Prioritized checklist

## P0 — completed in Drift

- [x] Add strict `progrss.capture-continuity.v1` Node evidence.
- [x] Compute continuity before ordinary browser-assisted page-watch diffing.
- [x] Compare bounded stable card keys.
- [x] Compare bounded region tokens.
- [x] Limit the hold rule to observations with partial-render evidence.
- [x] Hold a changed partial-render boundary.
- [x] Hold low-overlap partial windows below 35 percent.
- [x] Continue ordinary comparison when stable overlap is sufficient.
- [x] Preserve the accepted snapshot on hold.
- [x] Preserve accepted browser-capture provenance on hold.
- [x] Create no mass add/remove item.
- [x] Record an attention health state and durable receipt.
- [x] Add **Rendered window held** to the ordinary Extension result.
- [x] Add **Earlier baseline kept** as the human result heading.
- [x] Explain conservative later comparison before submission.
- [x] Keep exact overlap under Advanced evidence.
- [x] Keep zero Node watched-site requests.
- [x] Keep no-schedule behavior.
- [x] Keep pairing summary-only and read-only.
- [x] Keep Pulse ineligible for Capture receipts.
- [x] Add exact replay with no second request or write.
- [x] Expand the fixture garden from seven to twelve cases.
- [x] Add disjoint virtual-window fixtures.
- [x] Add hidden responsive duplicate fixtures.
- [x] Add mixed promotional clutter fixtures.
- [x] Add localized continuation fixtures.
- [x] Add a closed-shadow boundary fixture.
- [x] Synchronize Chromium and Firefox shared runtime.
- [x] Update Node, Capture, tired-reader, and Firefox acceptance protocols.
- [x] Make this rev0072 section the active `/run` authority.

## P0 — next: native and unfamiliar-human fieldwork

- [ ] Install the exact archive on unmanaged current Chromium.
- [ ] Install the exact archive on current Firefox.
- [ ] Install the exact archive on Firefox ESR.
- [ ] Capture two real disjoint windows of one virtualized public list.
- [ ] Capture one signed-in virtualized page using non-sensitive test data.
- [ ] Ask whether **Rendered window held** means “nothing changed.”
- [ ] Ask whether the earlier records were removed from the site.
- [ ] Ask whether ProgRSS scrolled or loaded the page automatically.
- [ ] Ask whether the Node received the browser login.
- [ ] Ask whether a schedule was created.
- [ ] Ask how the person expects to replace an obsolete baseline.
- [ ] Verify exact permission cleanup through native browser UI.
- [ ] Run keyboard-only acceptance.
- [ ] Run real screen-reader acceptance.
- [ ] Run Braille acceptance.
- [ ] Run voice-control acceptance.
- [ ] Run switch-style acceptance.
- [ ] Run 200–400 percent zoom.
- [ ] Run forced-colors and reduced-motion acceptance.
- [ ] Run fatigue and interruption sessions.
- [ ] Change wording and hierarchy from observed wrong turns.

## P0 — next typed operation: reviewed baseline replacement

- [ ] Name one exact page-watch source.
- [ ] Require an existing held continuity receipt.
- [ ] Review the earlier and proposed baseline summaries.
- [ ] Explain that history remains and no historical alert is invented.
- [ ] Require the exact current library digest.
- [ ] Require the exact held-receipt digest.
- [ ] Require a random idempotency key.
- [ ] Commit atomically.
- [ ] Retain the earlier snapshot as recovery evidence.
- [ ] Return exact replay without a second mutation.
- [ ] Expose no generic JSON Patch or arbitrary snapshot writer.

## P0 — fixture-garden expansion

- [ ] DOM-node recycling with unchanged element count.
- [ ] Virtual windows with one or two overlapping records.
- [ ] Virtual windows whose keys depend only on changing text.
- [ ] Unknown total size using `aria-setsize=-1`.
- [ ] A list whose author-provided set metadata is inconsistent.
- [ ] Infinite scroll with records prepended rather than appended.
- [ ] Pagination where the next link changes language or icon only.
- [ ] Multiple overlapping dialogs.
- [ ] Nested open roots near traversal limits.
- [ ] Same-origin and cross-origin frame specimens.
- [ ] Canvas and WebGL explicitly outside the text contract.

## P1 — page-watch repair quality

- [ ] Connect repeated `coverage-shift` outcomes to a visible repair review.
- [ ] Explain which boundary or overlap evidence changed.
- [ ] Distinguish a moved viewport from missing records.
- [ ] Avoid alerts caused only by pagination state.
- [ ] Avoid alerts caused by virtualized-window churn.
- [ ] Preserve earlier recipes and snapshots for audit.
- [ ] Keep repair explicit, reversible, and typed.
- [ ] Keep arbitrary shared JavaScript outside repair logic.

## P1 — conditional Pinpoint

Build direct point-to-region selection only when fieldwork proves the current
bounded candidates cannot express the intended region.

- [ ] Begin from the exact reviewed active page.
- [ ] Use a temporary packaged isolated-world overlay.
- [ ] Support click or tap without requiring dragging.
- [ ] Support full keyboard operation.
- [ ] Make regions screen-reader discoverable.
- [ ] Provide stable voice-control labels.
- [ ] Support switch-compatible sequential selection.
- [ ] Read no form values and activate no page controls.
- [ ] Remove the overlay immediately on selection or cancellation.
- [ ] Convert the result to one bounded declarative recipe.
- [ ] Re-run Contour, Perimeter, Threshold, and Drift evidence.
- [ ] Transfer no raw DOM, HTML, screenshot, or pointer trace.

## P1 — organization and re-finding

- [ ] Measure whether someone can find material again after one week.
- [ ] Keep folders as human-curated, shareable routes.
- [ ] Add private many-to-many labels.
- [ ] Add explicit saved-query views.
- [ ] Preserve **Unfiled** as a valid resting state.
- [ ] Make duplicate, stale-source, and route-split suggestions reversible.
- [ ] Avoid engagement ranking.
- [ ] Avoid opaque automatic taxonomy.

## P1 — Source Notes recovery

The historical no-scroll transcript describes short plain-text reasons scoped
to one folder/source relationship, but the actual rev0059 artifact bytes remain
outside the recoverable delivered lineage.

- [ ] Recover the real rev0059 archive or independently reimplement it.
- [ ] Keep each note short and plain-text.
- [ ] Scope each note to one folder/source relationship.
- [ ] Keep notes outside acquisition identity.
- [ ] Cover notes with native source-list integrity.
- [ ] Preserve notes in independent branch excerpts.
- [ ] Report note omission from OPML.
- [ ] Include note disagreement in Confluence review.
- [ ] Do not turn notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

- [ ] Separate remote mode from loopback mode.
- [ ] Require TLS and persistent Node identity.
- [ ] Add hostname, request, artifact, and rate bounds.
- [ ] Add expiring invitations and persistent revocation evidence.
- [ ] Separate public publication routes from private APIs.
- [ ] Begin with immutable-artifact retrieval.
- [ ] Test reverse proxies and self-hosted deployment.
- [ ] No default public bind.
- [ ] No silent LAN discovery.
- [ ] No UPnP port opening.
- [ ] No “enter an IP address and hope” basic flow.

## Lab — WebRTC courier

- [ ] Transfer exactly one already reviewed immutable artifact.
- [ ] Use bounded signed offer-and-answer metadata.
- [ ] Make signaling visible.
- [ ] Make STUN and TURN use visible.
- [ ] Compare QR, copy/paste, HTTPS, relay, and WebRTC friction.
- [ ] Refuse replay, identity mismatch, digest mismatch, timeout, and partial completion.
- [ ] Discard the session after transfer.
- [ ] Never require WebRTC for ordinary reading, sharing, Capture, Witness, or Pulse.

# Verification summary

Working-tree verification completed before sealing:

```text
17/17  acquisition and Capture tests
 9/9   Pulse/Cadence tests
46/46  direct CLI library tests
18/18  Node HTTP, pairing, Exchange, operation, Witness, Capture, and Drift tests
 9/9   Node-store transaction, migration, interruption, and replay tests
29/29  publication, integrity, continuity, and merge tests
26/26  command-line cases in individually bounded process groups
154     distinct Python cases

58/58  Extension structural/static checks
PASS    Chromium background harness
PASS    Branch / Contents / Signpost / Edition core harness
PASS    generated Firefox background harness
PASS    acquisition and redirect harness
PASS    vault conflict and failed-write harness
PASS    12-case real-browser fixture garden
PASS    rendered everyday reader through Drift receipt
PASS    rendered Advanced Workbench
```

The older Relay and command-line aggregate wrappers can retain descendant
output handles after their assertions finish. Release evidence therefore runs
their constituent tests under explicit process-group bounds rather than
counting a lingering wrapper process as product execution.

# Native and human boundary

```text
Unmanaged installed Chromium:        NOT RUN
Current native Firefox:              NOT RUN
Native Firefox ESR:                  NOT RUN
Signed-in real-site Drift capture:   NOT RUN
Unfamiliar-human Drift sessions:     NOT RUN
Real assistive-technology sessions:  NOT RUN
```

Those remain unexecuted boundaries, not passes.

# Release evidence

```text
Archive:             ProgRSS-rev0072-2026.10.20-Drift.zip
Version:             0.72.0
Revision:            rev0072
Codename:            Drift
SHA-256:             published in sibling .sha256 sidecar after sealing
Members:             369
Regular files:       325
Directory entries:   44
Uncompressed bytes:  12342542
ZIP bytes:           published externally after sealing
BOOTSTRAPROSE:       15386 lines
```

---

# BOOTSTRAPROSE — ProgRSS rev0071 “Threshold”

**Release:** rev0071 · **Product version:** 0.71.0 · **Vault schema:** 17 (unchanged)  
**Node-store schema:** `progrss.node-store.v2` (unchanged)  
**Capture candidates:** `progrss.browser-capture-candidates.v3`  
**Capture artifact:** `progrss.browser-capture.v4`  
**Page context:** `progrss.capture-page-context.v1`  
**Coverage review:** `progrss.capture-coverage-review.v1`  
**Section assessment:** `progrss.capture-section-assessment.v1`  
**Extractor revision:** `perimeter-v1` (unchanged)  
**Release date:** 2026-10-20  
**Release maxim:** **A visible boundary needs a visible decision.**

## `/run` interpretation

When this file is the active bootstrap, continue from the delivered rev0071 tree.
The rev0071 source tree, schemas, tests, release metadata, and sealed archive are
the implementation authority.

Do not reconstruct the current product from:

```text
rev0058 Branch alone
the no-scroll historical transcript
an absent rev0059 Source Notes archive
a release card without its delivered bytes
rev0067 Cadence's incomplete archive
rev0068 Pulse's stale bootstrap heading
rev0070 Perimeter without Threshold's explicit coverage decision
```

The older bootstrap sections remain below as historical design and
chain-of-custody evidence. Where they conflict with this first rev0071 section,
this section wins.

## Current lineage

```text
Nightstand   dark fluorescent basic reader + first loopback Node
Handshake   explicit summary-only Extension ↔ Node pairing
Exchange    one handoff with Follow / Add route / Take branch
Confluence  human-first three-way later-copy review
Receipt     one transactional Node-owned branch-adoption write
Witness     one reviewed public feed or page-watch check with durable evidence
Capture     one reviewed browser-rendered page artifact with no login transfer
Pulse       one foreground Node timing system using the Witness acquisition path
Contour     explain why one rendered section may hold or break
Perimeter   explain what one rendered browser view may leave outside
Threshold   require a deliberate decision before a limited view becomes baseline
```

## Current product truths

```text
The everyday Extension reader remains the default product.
Dark fluorescent presentation remains the default.
Light presentation remains an explicit persisted option.
Forced-colors removes decorative fluorescent treatment.
Reduced-motion remains respected.
Advanced Workbench remains secondary.
The Extension remains useful without a Node.
The CLI remains useful without a browser.
The Node remains the CLI's local web-server mode.
The Node binds only to literal loopback in the ordinary delivered mode.
The portable complete library remains progrss.private.v1 JSON.
SQLite remains a local transaction mechanism, not an interchange format.
Pairing remains summary-only, read-only, process-lifetime, and revocable.
Exchange remains artifact-scoped rather than synchronization.
Confluence remains explicit three-way later-copy review.
Receipt's one typed branch-adoption write remains available.
Witness remains the only Node-side public acquisition path.
Capture remains one deliberate Extension-submitted rendered-page observation.
Pulse remains foreground-only scheduling for Node-reproducible sources.
Contour describes section stability.
Perimeter describes rendered-page coverage.
Threshold requires an explicit decision when that coverage is visibly limited.
A shared route never transfers recurring network authority.
Browser-assisted evidence never becomes Pulse scheduling evidence.
```

# Why Threshold exists

Perimeter made these browser-view boundaries visible before submission:

```text
Page continues
Partial rendering
Visible overlay
Still loading
Frames excluded
Open shadow inspected
```

That corrected a major explanatory gap, but visibility alone was not a complete
review boundary.

A person could still:

```text
see that the page continues
see that only part of a virtualized list is rendered
see that a consent or account overlay obscures material
see that the page is still busy
see that frame content is excluded
and press the final send action without separately accepting that limitation
```

The likely wrong inference was:

> ProgRSS warned me, but perhaps it completed the page when I submitted.

Threshold rejects that ambiguity.

When a rendered view contains any limiting page boundary, the final submission
is unavailable until the person either:

```text
captures the page again after improving the view
```

or explicitly chooses:

```text
Use this rendered view as the baseline
```

The product must not silently treat the absence of a second capture as consent.

# Human decision model

The ordinary review now separates three questions.

## 1. What may be outside this rendering?

Perimeter's bounded page-context notices remain visible before section choice.

They describe page coverage, not the quality of the chosen selector.

## 2. Which rendered section counts as the update?

The person chooses one bounded candidate:

```text
Saved watched section
Repeated entries on this page
Primary readable text
```

Contour's independent section assessment remains:

```text
More likely to stay put
Needs watching
Fragile
```

## 3. Which consequence is being accepted?

Two separate acknowledgements may be required.

### Limited rendered view

```text
Use this rendered view as the baseline
```

This means:

```text
save only the current top-frame rendering
follow no pagination
scroll no virtualized list
click or dismiss no controls
wait for no additional loading
read no frame contents
```

### Changed watched section

```text
Use this new watched section
```

This means:

```text
replace the declarative extraction recipe
clear the old comparison snapshot
save the current observation as a fresh baseline
invent no historical change
```

These are not the same consequence.

When both are present, both decisions are required.
Neither checkbox is preselected.

# Limiting boundaries

Threshold requires coverage review for these exact kinds:

```text
continuation
partial-render
overlay
loading
frames
```

The order in the submitted acknowledgement must exactly match the order of the
visible limiting notices in the reviewed page context.

## Continuation

Evidence may include:

```text
rel=next
pagination landmarks
pager-like regions
load-more-style controls
```

Threshold does not follow any of them.

## Partial rendering

Evidence may include:

```text
declared set size larger than rendered entries
declared row count larger than rendered rows
virtual-list markers
scrollable list windows
```

Threshold does not scroll or synthesize missing records.

## Overlay

A visible dialog, consent layer, or modal may obscure the intended records.

Threshold does not click or dismiss it.

## Loading

A region still reports a busy state.

Threshold does not wait indefinitely or infer eventual completion.

## Frames

Embedded-frame contents remain outside top-frame Capture.

Threshold does not inspect same-origin or cross-origin frame documents.

## Open shadow evidence

`open-shadow` remains informational rather than limiting.

The packaged Perimeter extractor inspected bounded open shadow roots already.
The notice explains that closed shadow content remains outside the contract, but
an open-shadow notice alone does not require the limited-view acknowledgement.

# Preferred recovery action

The first action inside the coverage-decision card is:

```text
Capture the page again first
```

A person can:

```text
scroll manually
activate Load more manually
dismiss an overlay manually
wait for visible loading to finish manually
navigate to the intended page manually
then capture the exact page again
```

ProgRSS does none of those actions itself.

Recapture:

```text
runs the fixed packaged extractor again
replaces the candidate and page-context evidence
clears the previous coverage acknowledgement
clears the previous changed-recipe acknowledgement
requires review of the new rendering
```

A prior decision is never carried into a newly observed page.

# New artifact contract

New browser submissions use:

```text
progrss.browser-capture.v4
```

The strict top-level fields remain bounded and JSON-safe:

```text
schema
capturedAt
page
source
context
coverage
recipe
capture
examples
selection
provenance
```

The new review object is:

```text
progrss.capture-coverage-review.v1
```

## Rendering has limiting boundaries

Example:

```json
{
  "schema": "progrss.capture-coverage-review.v1",
  "decision": "use-current-rendering",
  "acknowledgedNoticeKinds": [
    "continuation",
    "partial-render",
    "overlay",
    "frames"
  ]
}
```

The kinds must exactly equal the visible limiting notices in order.

## Rendering has no limiting boundary

Example:

```json
{
  "schema": "progrss.capture-coverage-review.v1",
  "decision": "no-limiting-boundary-observed",
  "acknowledgedNoticeKinds": []
}
```

This does not claim that the page is globally complete.
It records only that this bounded Perimeter observation did not expose one of
the five limiting kinds.

# Strict Node validation

The Node refuses the v4 artifact before durable work when:

```text
coverage is missing
coverage is not one object
coverage contains unknown fields
the coverage schema is wrong
the decision vocabulary is unsupported
acknowledgedNoticeKinds is not a bounded string array
a kind is duplicated
a visible limiting kind is omitted
an extra kind is invented
the order differs from the reviewed context
use-current-rendering appears without a limiting boundary
no-limiting-boundary-observed appears with a limiting boundary
```

This is intentionally stricter than treating acknowledgement kinds as a set.
The submitted review must correspond to the exact visible sequence reviewed by
the person.

# Rolling local upgrades

The Node continues to read:

```text
progrss.browser-capture.v3
progrss.browser-capture.v2
progrss.browser-capture.v1
```

It does not invent:

```text
coverage acknowledgement for v3
page-context evidence for v2
section-assessment evidence for v1
```

The compatibility rule is:

> Read the evidence an older artifact actually contains. Do not fabricate a
> decision that an older interface never requested.

New Extension submissions always use v4.

# Durable evidence

The Node's local source provenance can retain:

```text
coverageReviewSchema
coverageDecision
acknowledgedBoundaryKinds
partialViewAcknowledged
```

The acquisition receipt exposes the same bounded consequence evidence.

The ordinary result says:

```text
You deliberately used the current rendered view despite visible page-coverage limits.
```

It also restates that ProgRSS did not:

```text
follow
scroll
click
wait
read frame contents
```

Advanced receipt evidence retains the exact reviewed boundary kinds.

The internal ordering rank used to propose section candidates remains absent
from artifacts and receipts.

# Authority remains unchanged

Threshold changes review, not authority.

The browser still keeps:

```text
cookies
credentials
authorization headers
localStorage
sessionStorage
IndexedDB
service-worker caches
form values
browser permission state
```

The Node still receives no:

```text
cookie jar
credential store
browser storage
raw HTML
DOM node
screenshot
pixel data
page script
open-tab list
Extension capability
browser permission grant
```

Capture remains:

```text
one exact reviewed active HTTP(S) page
top-frame only
isolated extension world
fixed packaged extractor
bounded JSON-safe text and links
one source and one operation
zero Node-side watched-site requests
no recurring schedule
```

Threshold does not add:

```text
localhost scanning
LAN discovery
startup Node contact
a generic capture-by-URL API
a generic Extension writer
browser automation
headless browsing
hidden pagination
continuous synchronization
```

# Pulse boundary

A v4 Capture receipt cannot make a source schedulable.

Pulse still requires a successful Node-side Witness receipt that proves:

```text
the Node independently contacted the source
the destination passed public-address validation
the exact feed or declarative page recipe was reproducible
the check produced a qualifying result
```

Coverage acknowledgement records a human decision about one rendered browser
view. It is not server reproducibility evidence.

# Pairing boundary

Extension pairing remains summary-only and read-only.

A paired Extension still cannot:

```text
read retained items
read followed source addresses
start Witness
start Pulse
submit a schedule
apply a Confluence merge
perform a Node branch-adoption write
inspect private operation receipts
```

Capture still uses one separate, short-lived, exact-source invitation.

# Sharing boundary

Threshold does not change Exchange, Branch, or publication semantics.

The recipient's three doors remain:

```text
Follow updates
Add the complete route
Take one branch
```

A shared page-watch recipe does not include browser cookies, signed-in state, or
a coverage acknowledgement from another person's rendering.

A recipient who later uses browser-assisted Capture makes their own local
coverage decision from their own rendered page.

# Human-language rationale

The ordinary interface leads with consequences rather than schema names.

It says:

```text
Before this becomes the baseline
This rendering has N visible coverage limits.
Capture again after loading or dismissing what you can,
or deliberately use only this view.
```

The final action changes to:

```text
Use this view and send once
```

or, for a paused source:

```text
Enable, use this view, and send once
```

The schema names, exact boundary kinds, and hashes remain under Advanced.

W3C cognitive-accessibility guidance supports showing a summary before an
important submission and clearly identifying the final action and cancellation.
Supplemental W3C guidance also recommends clearly stating the risks and
consequences of an option. Threshold applies those principles narrowly; it does
not claim that automated checks substitute for observation with actual users.

# Accessibility behavior

The decision uses ordinary controls:

```text
button for recapture
checkbox for limited-view acknowledgement
separate checkbox for changed-recipe acknowledgement
button for final submission
```

The final action is disabled until every required decision is complete.

The interface retains:

```text
keyboard-visible focus
native checkbox semantics
minimum target sizes
narrow-panel reflow
200–400% zoom support
forced-colors treatment
reduced-motion treatment
status-message result announcement
persistent light mode
dark fluorescent default
```

A disabled button is not the only explanation. The unchecked decision and its
consequence text remain visible immediately before the action.

# Dark and light presentation

The dark default remains near-black with restrained fluorescent cyan, magenta,
and lime accents plus fine gradient lines.

The coverage review card uses a bounded magenta edge because it represents an
unresolved consequence, not an error state.

When acknowledged, the native checkbox remains visible and the action becomes
available only if any separate recipe decision is also complete.

Light mode keeps the same information hierarchy without treating dark mode as a
prerequisite for comprehension.

Forced-colors removes decorative gradients and preserves control boundaries.

# Tests added or strengthened

## Python acquisition tests

The acquisition suite now covers:

```text
valid v4 limited-view acknowledgement
missing coverage object
partial acknowledged-kind list
reordered acknowledged-kind list
duplicate acknowledged kind
invented acknowledgement with no visible limit
no-limit v4 decision
v3 rolling read without coverage fabrication
v2 rolling read without context fabrication
v1 rolling read without assessment fabrication
```

## Node HTTP tests

The Node operation path verifies that durable receipt evidence contains:

```text
coverageReviewSchema
coverageDecision
acknowledgedBoundaryKinds
partialViewAcknowledged
```

## Extension rendered smoke

The everyday reader lane verifies:

```text
coverage decision card appears after Perimeter evidence
recapture remains visible
final action is disabled initially
coverage acknowledgement alone does not replace recipe acknowledgement
both decisions enable the action when both are required
receipt explains deliberate use of the current view
Advanced receipt lists the exact coverage decision
light mode retains the same review boundary
```

## Existing fixture garden

The Perimeter real-browser garden remains authoritative for extractor behavior:

```text
semantic repeated entries with hidden duplicate layouts
pagination and continuation
virtualized or partially declared lists
visible overlays
busy/loading regions
embedded frames plus open shadow roots
right-to-left direction
```

Threshold changes no extractor rule; it changes the decision made from those
observations.

# Explicit non-goals

Threshold does not deliver:

```text
automatic pagination
load-more activation
auto-scroll
virtualized-list harvesting
overlay dismissal
loading waits
frame extraction
closed-shadow extraction
direct point-to-region selection
arbitrary shared JavaScript
browser-assisted scheduling
remote Node mode
WebRTC synchronization
```

# Native and human evidence boundary

Automated tests do not prove that an unfamiliar person understands:

```text
what the baseline is
what remains outside the rendered view
what recapture does
what the checkbox accepts
why recipe change is separate
whether the Node receives their login
whether a schedule was created
```

Native installed-browser and real assistive-technology sessions remain required.

Managed policy on the current host may still block unpacked installation or
direct loopback navigation. A skipped native lane remains a skip.

# Prioritized checklist

## P0 — completed in Threshold

- [x] Keep Perimeter page-context evidence visible.
- [x] Keep Contour section-stability evidence independent.
- [x] Add `progrss.browser-capture.v4`.
- [x] Add `progrss.capture-coverage-review.v1`.
- [x] Require a coverage decision for continuation.
- [x] Require a coverage decision for partial rendering.
- [x] Require a coverage decision for visible overlays.
- [x] Require a coverage decision for loading state.
- [x] Require a coverage decision for excluded frames.
- [x] Keep open-shadow evidence informational.
- [x] Keep recapture as the preferred recovery action.
- [x] Clear acknowledgement after recapture.
- [x] Keep changed-recipe acknowledgement separate.
- [x] Keep both checkboxes unselected by default.
- [x] Disable final submission until all required decisions are complete.
- [x] Validate exact acknowledged kinds and order in the Node.
- [x] Refuse missing, partial, duplicate, reordered, contradictory, or invented acknowledgement.
- [x] Retain the reviewed decision in source provenance.
- [x] Retain the reviewed decision in durable receipts.
- [x] Preserve v3, v2, and v1 rolling-read compatibility.
- [x] Invent no consent for older artifacts.
- [x] Preserve zero Node watched-site requests.
- [x] Preserve no-schedule behavior.
- [x] Preserve top-frame isolated-world extraction.
- [x] Preserve summary-only read-only pairing.
- [x] Preserve dark default and light option.
- [x] Preserve forced-colors and reduced-motion behavior.
- [x] Update Chromium, Firefox, tired-reader, and Node protocols.
- [x] Update this bootstrap as the active `/run` authority.

## P0 — next: native Threshold fieldwork

- [ ] Install the exact release on unmanaged current Chromium.
- [ ] Install it on current Firefox.
- [ ] Install it on Firefox ESR.
- [ ] Run one public paginated site.
- [ ] Run one virtualized JavaScript-rendered site.
- [ ] Run one consent-overlay page.
- [ ] Run one page with embedded frame content.
- [ ] Run one signed-in page using non-sensitive test data.
- [ ] Ask whether review already contacted or completed the page.
- [ ] Ask what **Capture the page again first** does.
- [ ] Ask what **Use this rendered view as the baseline** accepts.
- [ ] Ask why **Use this new watched section** is separate.
- [ ] Ask whether the Node receives browser login state.
- [ ] Ask whether a schedule was created.
- [ ] Observe cancellation before permission.
- [ ] Observe cancellation after extraction.
- [ ] Observe cancellation after acknowledgement.
- [ ] Verify newly granted page and loopback permission cleanup.
- [ ] Run keyboard-only acceptance.
- [ ] Run screen-reader acceptance.
- [ ] Run Braille acceptance.
- [ ] Run voice-control acceptance.
- [ ] Run switch-style acceptance.
- [ ] Run 200–400% zoom.
- [ ] Run forced-colors.
- [ ] Run reduced-motion.
- [ ] Run fatigue and interruption sessions.
- [ ] Revise wording and hierarchy from observed wrong turns.

## P0 — fixture-garden expansion

- [ ] Numbered previous/next pagination.
- [ ] Infinite scroll with only current records rendered.
- [ ] DOM-node recycling in virtualized lists.
- [ ] Alternating mobile and desktop duplicate trees.
- [ ] Mixed articles and advertisements.
- [ ] Stable data attributes versus generated-class rebuilds.
- [ ] Localized continuation controls.
- [ ] Right-to-left grids and pagination.
- [ ] Multiple overlapping dialogs.
- [ ] Nested open roots near traversal limits.
- [ ] Explicit closed-shadow specimen.
- [ ] Same-origin frame specimen.
- [ ] Cross-origin frame specimen.
- [ ] Canvas and WebGL content explicitly outside the text contract.
- [ ] A page that clears every visible limit after manual recapture.
- [ ] A page where one limit remains after recapture.

## P1 — conditional Pinpoint

Build direct point-to-region selection only when fieldwork demonstrates that the
current bounded proposals cannot express the intended region.

- [ ] Start from the exact reviewed active page.
- [ ] Use a temporary packaged isolated-world overlay.
- [ ] Support click or tap without dragging.
- [ ] Support complete keyboard operation.
- [ ] Provide screen-reader-discoverable region choices.
- [ ] Provide stable voice-control labels.
- [ ] Provide switch-compatible sequential selection.
- [ ] Avoid form-value reads.
- [ ] Avoid page-control clicks.
- [ ] Remove the overlay immediately on selection or cancellation.
- [ ] Convert the result to a bounded declarative recipe.
- [ ] Show matched and ignored examples.
- [ ] Run Contour and Perimeter assessment.
- [ ] Require Threshold coverage review when applicable.
- [ ] Require changed-recipe acknowledgement.
- [ ] Create a fresh baseline.
- [ ] Transfer no raw DOM, HTML, screenshot, or pointer trace.

## P1 — page-watch repair quality

- [ ] Relate Perimeter limits to later **Needs repair** evidence.
- [ ] Explain which structural witness changed.
- [ ] Distinguish missing records from changed records.
- [ ] Avoid false alerts caused by pagination state.
- [ ] Avoid false alerts caused by virtualized-window churn.
- [ ] Keep repairs explicit and reversible.
- [ ] Retain the prior recipe and prior evidence.
- [ ] Keep arbitrary shared JavaScript outside repair logic.

## P1 — organization and delayed re-finding

- [ ] Measure whether people can find material again after a week.
- [ ] Keep folders as human-curated and shareable routes.
- [ ] Add private many-to-many labels.
- [ ] Add explicit saved-query views.
- [ ] Preserve **Unfiled** as a valid resting state.
- [ ] Make duplicate-source suggestions reversible.
- [ ] Make stale-source suggestions evidence-based and reversible.
- [ ] Make route-split suggestions reviewable.
- [ ] Avoid engagement ranking.
- [ ] Avoid opaque automatic taxonomy.

## P1 — Source Notes recovery

The historical transcript describes short, plain-text curator reasons scoped to
one folder/source relationship and covered by publication integrity. The actual
rev0059 archive remains absent from the recoverable delivered lineage.

- [ ] Recover the actual rev0059 archive or independently reimplement it.
- [ ] Keep notes short and plain-text.
- [ ] Scope one note to one folder/source relationship.
- [ ] Keep notes outside acquisition identity.
- [ ] Cover notes with native publication integrity.
- [ ] Preserve notes in independent branch excerpts.
- [ ] Report OPML omission.
- [ ] Include note disagreement in Confluence review.
- [ ] Do not expand notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

- [ ] Separate remote mode from loopback mode.
- [ ] Require TLS.
- [ ] Require persistent Node identity.
- [ ] Add hostname allowlists.
- [ ] Add request, artifact, and rate bounds.
- [ ] Add expiring invitations.
- [ ] Add persistent revocation evidence.
- [ ] Separate public publication routes from private APIs.
- [ ] Begin with immutable artifact retrieval.
- [ ] Test reverse proxies.
- [ ] Test self-hosted deployment.
- [ ] No default public bind.
- [ ] No silent LAN discovery.
- [ ] No UPnP port opening.
- [ ] No basic “enter an IP address and hope” flow.

## Lab — WebRTC courier

- [ ] Transfer exactly one already reviewed immutable artifact.
- [ ] Use bounded signed offer-and-answer metadata.
- [ ] Make signaling visible.
- [ ] Make STUN use visible.
- [ ] Make TURN use visible.
- [ ] Compare QR, copy/paste, HTTPS, relay, and WebRTC friction.
- [ ] Refuse replay.
- [ ] Refuse identity mismatch.
- [ ] Refuse digest mismatch.
- [ ] Refuse timeout and partial completion.
- [ ] Discard the session after transfer.
- [ ] Never require WebRTC for ordinary reading, sharing, Capture, Witness, or Pulse.

# Release verification plan

The exact final values below are filled only after deterministic sealing and
clean-extraction replay.

```text
Archive:             ProgRSS-rev0071-2026.10.20-Threshold.zip
Version:             0.71.0
Revision:            rev0071
Codename:            Threshold
SHA-256:             detached .sha256 sidecar (not self-embedded)
Members:             356
Regular files:       313
Directory entries:   43
Uncompressed bytes:  12264560
ZIP bytes:           see detached release report
BOOTSTRAP lines:      14606
```

## Final automated evidence

```text
Acquisition/Capture tests:           15/15 PASS
Pulse/Cadence tests:                 9/9 PASS
Node-store tests:                    9/9 PASS
Node HTTP tests:                     17/17 PASS
Direct CLI library tests:            46/46 PASS
Relay/publication tests:             29/29 PASS in bounded individual processes
Command-line cases:                  26/26 PASS in bounded individual processes
Extension static checks:             58/58 PASS
Chromium background harness:         PASS
Shared-folder core harness:          PASS
Firefox generated background:        PASS
Acquisition redirect harness:        PASS
Vault conflict harness:              PASS
Perimeter fixture garden:            PASS — seven real-browser DOM specimens
Rendered everyday reader:            PASS
Rendered Advanced Workbench:         PASS
Rendered Node UI:                     PASS; native loopback navigation skipped by managed policy
Python compilation:                  26/26 PASS
JavaScript syntax:                   62/62 PASS
JSON parsing:                        55/55 PASS
POSIX shell syntax:                  2/2 PASS
Deterministic rebuild:               PASS — two byte-identical candidate builds
Clean-extraction replay:             PASS — principal suites replayed from clean extraction
```

## Native and human evidence

```text
Installed unmanaged Chromium:        NOT RUN
Current native Firefox:              NOT RUN
Native Firefox ESR:                  NOT RUN
Signed-in real-site Capture:         NOT RUN
Unfamiliar-human Threshold sessions: NOT RUN
Real screen-reader sessions:         NOT RUN
Braille sessions:                    NOT RUN
Voice-control sessions:              NOT RUN
Switch sessions:                     NOT RUN
```

Those entries remain not run unless actual sessions occur.

## Decision for the next revision

Do not add remote scheduling merely because Pulse works.

Do not add a permanent daemon merely because foreground scheduling works.

Do not add a visual picker merely because it is technically attractive.

The next coherent work is:

1. run Threshold with unfamiliar people and native browsers;
2. expand the real-page and fixture garden;
3. decide whether Pinpoint is justified by observed proposal failures;
4. improve repair explanations for pagination and virtualized-page drift;
5. improve organization and delayed re-finding;
6. recover or independently reimplement Source Notes;
7. keep remote Nodes and WebRTC behind later explicit boundaries.

## End of rev0071 bootstrap continuation

---

# BOOTSTRAPROSE — ProgRSS rev0070 “Perimeter”

**Release:** rev0070 · **Product version:** 0.70.0 · **Vault schema:** 17 (unchanged)  
**Node-store schema:** `progrss.node-store.v2` (unchanged)  
**Capture candidates:** `progrss.browser-capture-candidates.v3`  
**Capture artifact:** `progrss.browser-capture.v3`  
**Page context:** `progrss.capture-page-context.v1`  
**Section assessment:** `progrss.capture-section-assessment.v1`  
**Extractor revision:** `perimeter-v1`  
**Release date:** 2026-10-20  
**Release maxim:** **Show the edges before saving the center.**

## `/run` interpretation

When this file is the active bootstrap, continue from the delivered rev0070 tree.
The rev0070 source tree, schemas, tests, release metadata, and sealed archive are
the implementation authority.

Do not reconstruct the product from:

```text
rev0058 Branch alone
the no-scroll historical chat transcript
an absent rev0059 Source Notes archive
a prior release card without its delivered bytes
rev0067 Cadence's incomplete archive
rev0068 Pulse's stale bootstrap heading
```

The older bootstrap sections remain below as historical design and chain-of-custody
evidence. Where they conflict with this first rev0070 section, this section wins.

## Current lineage

```text
Nightstand   dark fluorescent basic reader + first loopback Node
Handshake   explicit summary-only Extension ↔ Node pairing
Exchange    one handoff with Follow / Add route / Take branch
Confluence  human-first three-way later-copy review
Receipt     one transactional Node-owned branch-adoption write
Witness     one reviewed public feed or page-watch check with durable evidence
Capture     one reviewed browser-rendered page artifact with no login transfer
Pulse       one foreground Node timing system using the Witness acquisition path
Contour     explain why one rendered section may hold or break
Perimeter   explain what one rendered browser view may leave outside
```

## Current product truths

```text
The everyday Extension reader remains the default product.
Dark fluorescent presentation remains the default.
Light presentation remains an explicit persisted option.
Forced-colors removes decorative fluorescent treatment.
Reduced-motion remains respected.
Advanced Workbench remains secondary.
The Extension remains useful without a Node.
The CLI remains useful without a browser.
The Node remains the CLI's local web-server mode.
The Node binds only to literal loopback in the ordinary delivered mode.
The portable complete library remains progrss.private.v1 JSON.
SQLite remains a local transaction mechanism, not an interchange format.
Pairing remains summary-only, read-only, process-lifetime, and revocable.
Pairing grants no source addresses, retained items, acquisition, schedule, publication, merge, or write authority.
Exchange remains artifact-scoped rather than synchronization.
Confluence remains explicit three-way later-copy review.
Receipt's one typed branch-adoption write remains available.
Witness remains the only Node-side public acquisition path.
Capture remains one deliberate Extension-submitted rendered-page observation.
Pulse remains foreground-only scheduling for Node-reproducible sources.
Contour still describes section stability.
Perimeter separately describes rendered-page coverage.
A shared route never transfers recurring network authority.
Browser-assisted evidence never becomes Pulse scheduling evidence.
```

# Why Perimeter exists

Contour improved the question:

> **Will this selected section be understandable and repairable if the page changes?**

That was necessary but incomplete.

A structurally sensible section can still be an incomplete observation because:

```text
the page continues to another numbered page
a Next link is present
there is a Load more control
a virtualized list exposes only the visible window
ARIA declares a larger set than is currently rendered
a scroll container holds more records than the current viewport
a consent dialog covers the useful records
a region still reports that it is loading
useful material lives inside an embedded frame
useful material lives in shadow DOM
```

Before Perimeter, a person could see **More likely to stay put** and reasonably
but incorrectly infer:

```text
ProgRSS saw the whole page.
ProgRSS followed the next page.
ProgRSS scrolled the list.
ProgRSS read the frame.
ProgRSS waited for loading.
ProgRSS got everything hidden behind the overlay.
```

Perimeter rejects that inference.

The ordinary review now separates two axes:

```text
SECTION STABILITY
  More likely to stay put
  Needs watching
  Fragile

PAGE COVERAGE
  Outside capture
  Check first
  Included
```

A stable-looking section and an incomplete page can both be true.
A complete-looking page and a fragile selector can both be true.
Neither axis silently decides for the person.

# Human interface

Before the rendered-section radios, the Extension now shows:

> **What this browser view may leave outside**

At most six bounded notices can appear.

## Page continues

Ordinary label:

```text
Page continues
OUTSIDE CAPTURE
```

This can be triggered by bounded evidence such as:

```text
rel=next
pagination landmark
pager-like region
load-more control
```

The consequence is deliberately narrow:

> This page appears to continue elsewhere. Capture includes only this rendered page.

ProgRSS does not click the control, follow the next page, synthesize a multi-page
result, or claim that the next page belongs to the same logical collection.

## Partial rendering

Ordinary label:

```text
Partial rendering
CHECK FIRST
```

Signals can include:

```text
a declared set larger than the currently rendered items
a declared row count larger than the rendered rows
known virtual-list markers
a scrollable list window with more content than its visible height
```

The consequence is:

> This list may render only part of its items at once. Capture includes only entries currently present in the page DOM.

This is a heuristic warning, not a claim that every scroll window is virtualized
or that every virtualized page exposes reliable metadata.

## Visible overlay

Ordinary label:

```text
Visible overlay
CHECK FIRST
```

This can describe a visible dialog, modal, or consent layer that may conceal the
records the person intends to watch.

ProgRSS does not dismiss it automatically.
The person can dismiss it when appropriate and choose **Capture the page again**.

## Still loading

Ordinary label:

```text
Still loading
CHECK FIRST
```

This is emitted when a rendered region still reports a busy state.
The suggested consequence is to wait and capture again.

ProgRSS does not wait indefinitely, infer that loading completed, or turn one
busy marker into a network failure.

## Frames excluded

Ordinary label:

```text
Frames excluded
OUTSIDE CAPTURE
```

The extractor can count embedded frame elements in the top document.
It does not inspect the frame document.
It does not request `allFrames`.
It does not traverse a cross-origin frame.
It does not claim frame content was captured.

## Open shadow inspected

Ordinary label:

```text
Open shadow inspected
INCLUDED
```

Perimeter can traverse bounded open shadow roots and include ordinary text and
links found through those roots in its candidate evidence.

The extractor is bounded by:

```text
maximum open roots
maximum queried elements
maximum result counts
maximum candidate count
maximum artifact bytes
```

Closed shadow roots remain outside the explicit contract.
The interface states that boundary under Advanced page-boundary evidence.

# Recovery language

When a notice indicates a possibly incomplete page, the ordinary interface says:

> Scroll, load more, or dismiss overlays first when needed, then use Capture the page again.

This is advice, not automation.

The person remains responsible for deciding whether:

```text
scrolling is appropriate
loading more is appropriate
a consent choice is acceptable
the page is ready
the visible records are the records they intend to watch
```

The Extension provides a button, not a hidden loop:

```text
Capture the page again
```

It does not retain or replay a click path.

# Advanced page-boundary evidence

The ordinary notices are followed by one secondary disclosure:

```text
Advanced page-boundary evidence
```

It can show exact bounded counts for:

```text
Continuation links
Pagination landmarks
Continuation controls
Partial-set signals
Virtual-list markers
Scrollable list windows
Modal or consent layers
Busy regions
Embedded frames excluded
Open shadow roots inspected
```

These counts are diagnostics.
They are not required to understand the ordinary consequence.
They are not a confidence score.
They are not persisted as source identity.
They are not scheduler eligibility.

# Extractor boundary

The canonical extractor remains:

```text
Extension/shared/capture.js
```

The generated Firefox package contains the same bytes.
The extractor remains fixed packaged ProgRSS code.
It is never supplied by:

```text
the page
the local Node
a curator
a source list
a source note
a shared recipe
an Exchange handoff
a remote script
```

The browser action still targets:

```text
the exact reviewed active tab
the exact reviewed address
frame 0
the isolated extension world
```

The extractor still returns only JSON-safe values.

It does not transfer:

```text
cookies
credentials
authorization headers
localStorage
sessionStorage
IndexedDB
service-worker caches
form values
raw HTML
DOM nodes
screenshots
pixels
page scripts
stylesheets
image bodies
Extension capabilities
Node administrator capabilities
```

It does not:

```text
click controls
scroll the page
search the tab strip
inspect background tabs
open a new tab
submit forms
control login
traverse frame contents
pierce closed shadow roots
execute shared arbitrary JavaScript
```

# Deep-query boundary

Perimeter adds bounded traversal of open shadow roots.

The extractor first starts with the main document.
It then discovers open shadow roots reachable through visible document elements,
subject to explicit limits.
Queries run across the collected roots and results are deduplicated.

Hidden-state checks follow the composed host relationship so that content hidden
by a shadow host does not become a visible candidate merely because an inner node
has visible local styles.

This is not a general composed-tree engine.
It does not promise support for:

```text
closed shadow roots
browser-internal shadow trees
cross-origin frame trees
unbounded recursive component graphs
all slotting edge cases
visual occlusion analysis
canvas or WebGL text
pixel OCR
```

# Schema contract

## Candidate observation

New candidate observations use:

```text
progrss.browser-capture-candidates.v3
```

The observation contains:

```text
schema
capturedAt
page
source
context
candidates
provenance
```

The `context` field is new.
The candidate assessment remains independent.

## Submitted artifact

New submitted artifacts use:

```text
progrss.browser-capture.v3
```

The exact top-level fields are:

```text
schema
capturedAt
page
source
recipe
capture
examples
context
selection
provenance
```

## Page-context schema

```text
progrss.capture-page-context.v1
```

Its exact fields are:

```text
schema
notices
signals
```

The fixed notice kinds and tones are:

```text
continuation    boundary
partial-render  caution
overlay         caution
loading         caution
frames          boundary
open-shadow     included
```

The fixed bounded signal fields are:

```text
continuationLinks
paginationLandmarks
continuationControls
partialSetSignals
virtualMarkers
scrollWindows
modalLayers
embeddedFrames
openShadowRoots
busyRegions
```

The Node refuses:

```text
unknown fields
unknown notice kinds
unsupported tones
duplicate notice kinds
missing signals
negative values
out-of-range values
notice/signal disagreement
stale artifacts
wrong source
wrong page
oversized artifacts
unacknowledged recipe changes
```

## Rolling local upgrade

The Node can read:

```text
v3  page context + section assessment
v2  section assessment only
v1  original bounded Capture artifact
```

It does not fabricate page context for v2.
It does not fabricate section assessment or page context for v1.

Compatibility is read support, not permission for a new Extension to emit old
schemas indefinitely.

# Receipt evidence

A successful v3 Capture receipt retains:

```text
artifact schema
extractor revision
selected candidate ID
section assessment level and summary
page-context schema
page-context notice kinds
possible continuation
possible partial rendering
modal-layer count
embedded-frame count
open-shadow-root count
busy-region count
```

The ordinary result still leads with:

```text
Baseline saved or Changed
Items added
Node site requests: 0
Library revision
Schedule: None created
```

Page-context evidence is not part of:

```text
feed identity
page-watch recipe identity
duplicate-source identity
publication identity
Pulse eligibility
browser permission authority
pairing capability
```

# Authority remains unchanged

Perimeter changes explanation and evidence, not authority.

```text
The exact watched page must be open and active.
Page authority is requested only inside the visible Capture action.
A changed watched section requires acknowledgement.
A changed watched section creates a fresh baseline.
The Node makes zero watched-site requests for Capture.
Capture creates no recurring schedule.
Pulse refuses Capture evidence as scheduling proof.
Pairing remains summary-only and read-only.
The Extension still cannot perform arbitrary Node writes.
```

# Fixture garden

The delivered garden is under:

```text
Extension/tests/fixtures/capture-garden/
```

It contains retained specimens for:

```text
semantic-hidden.html
pagination.html
virtualized.html
overlay.html
frames-shadow.html
busy.html
rtl.html
garden.html
```

The real-browser smoke lane verifies:

```text
semantic repeated candidates remain available
hidden duplicate trees are excluded
pagination produces continuation evidence
virtualized/partial sets produce partial-render evidence
overlays produce caution evidence
busy regions produce loading evidence
frame elements produce an exclusion boundary
open shadow roots can contribute bounded candidates
right-to-left page direction remains rtl
all six page-boundary kinds are exercised
```

Managed Chromium policy can block direct loopback navigation in this environment.
The fixture lane therefore uses a real browser page with controlled in-memory
HTML documents. That proves browser DOM behavior for the fixtures, not native
installed-Extension permission prompts or real-site behavior.

# Interface hierarchy

The ordinary order is:

```text
Review exact Node and page
Capture this open page
What part of this page counts as an update?
What this browser view may leave outside
Rendered-section choices
Matched now
Ignored example
Section stability evidence
Changed-recipe acknowledgement, when needed
Send one reviewed capture
Ordinary result
Advanced receipt evidence
```

The page-coverage cards appear before the radio choices because they can affect
whether the person should capture again before making a section decision.

Advanced counts remain secondary.
The basic reader remains the default.
Advanced Workbench remains secondary.

# Accessibility boundary

Perimeter introduces no drag interaction.
Every delivered operation remains available through ordinary buttons, radio
controls, disclosures, and checkboxes.

A future point-to-region interface must not become drag-only.
It needs:

```text
keyboard operation
single-pointer operation without dragging
screen-reader semantics
voice-control labels
switch-compatible sequential operation
zoom and reflow acceptance
forced-colors visibility
clear cancellation
immediate overlay removal
```

The current release packages those fieldwork questions but does not claim the
sessions occurred.

# Online research boundary

The release preserves research notes at:

```text
Evidence/rev0070-Perimeter/WEB-RESEARCH.md
```

The implementation was checked against current primary documentation for:

```text
browser scripting authority and explicit frame targeting
isolated execution worlds
Selectors and document-tree matching
open versus closed shadow-root access
non-drag alternatives for drag-based functionality
```

Standards and browser documentation informed the boundary.
They do not replace native acceptance or human observation.

# Source Notes status

The historical handoff describes rev0059 Source Notes as short plain-text reasons
scoped to one folder/source relationship and covered by publication integrity.
The actual rev0059 archive is still absent from the recoverable delivered lineage.

Perimeter does not silently claim that implementation.
The work remains:

```text
recover the exact archive, or reimplement independently
keep notes out of acquisition identity
preserve notes in branch excerpts
cover notes with native source-list integrity
report OPML omission
include note conflicts in Confluence
avoid comments, reactions, profiles, and notification streams
```

# Prioritized checklist

## P0 — completed in Perimeter

- [x] Separate section stability from page completeness.
- [x] Add `progrss.browser-capture-candidates.v3`.
- [x] Add `progrss.browser-capture.v3`.
- [x] Add strict `progrss.capture-page-context.v1`.
- [x] Add bounded continuation evidence.
- [x] Add bounded partial/virtualized-rendering evidence.
- [x] Add bounded overlay evidence.
- [x] Add bounded loading evidence.
- [x] Add embedded-frame exclusion evidence.
- [x] Add bounded open-shadow-root traversal and evidence.
- [x] State the closed-shadow boundary explicitly.
- [x] Keep the extractor fixed, packaged, isolated-world, and top-frame-only.
- [x] Keep at most three rendered-section candidates.
- [x] Keep at most six page-context notices.
- [x] Keep internal ordering rank out of artifacts and receipts.
- [x] Retain page-context kinds and counts in durable receipts.
- [x] Keep changed-recipe acknowledgement and fresh-baseline behavior.
- [x] Keep zero Node watched-site requests for Capture.
- [x] Keep recurring scheduling unavailable for Capture evidence.
- [x] Keep pairing summary-only and read-only.
- [x] Keep v2 and v1 rolling read compatibility without invented evidence.
- [x] Add pagination fixture.
- [x] Add virtualized/partial-list fixture.
- [x] Add overlay fixture.
- [x] Add busy/loading fixture.
- [x] Add frame plus open-shadow fixture.
- [x] Retain semantic/hidden duplicate fixture.
- [x] Retain right-to-left fixture.
- [x] Add a visible dark fluorescent fixture-garden page.
- [x] Add real-browser fixture smoke.
- [x] Extend the rendered everyday-reader smoke path.
- [x] Retain dark default and explicit light mode.
- [x] Retain forced-colors and reduced-motion behavior.
- [x] Update Chromium, Firefox, tired-reader, and Node Capture protocols.
- [x] Update project metadata, release notes, and this bootstrap.

## P0 — next: native and unfamiliar-human fieldwork

- [ ] Install the exact package on unmanaged current Chromium.
- [ ] Install the exact package on current Firefox.
- [ ] Install the exact package on Firefox ESR.
- [ ] Run one public server-rendered paginated page.
- [ ] Run one public JavaScript-rendered virtualized page.
- [ ] Run one signed-in real page with non-sensitive test data.
- [ ] Run one page with a consent overlay.
- [ ] Run one page with embedded frame content.
- [ ] Run one page with open web-component shadow content.
- [ ] Observe whether people confuse section stability with page completeness.
- [ ] Ask whether ProgRSS followed the next page.
- [ ] Ask whether ProgRSS scrolled the list.
- [ ] Ask whether ProgRSS clicked the overlay.
- [ ] Ask whether ProgRSS read the frame.
- [ ] Ask whether ProgRSS saw closed shadow content.
- [ ] Ask whether a page with no notice is proved complete.
- [ ] Test cancellation before permission, after extraction, and after review.
- [ ] Verify permission cleanup in native browser UI.
- [ ] Run keyboard-only sessions.
- [ ] Run real screen-reader sessions.
- [ ] Run Braille sessions where available.
- [ ] Run voice-control sessions.
- [ ] Run switch-style sessions.
- [ ] Run 200–400% zoom.
- [ ] Run forced-colors and reduced-motion.
- [ ] Run fatigue and interruption sessions.
- [ ] Change wording and hierarchy in response to observed wrong turns.

## P0 — fixture garden expansion

- [ ] Numbered pagination with previous/next and canonical links.
- [ ] Infinite scroll with only currently rendered records in scope.
- [ ] Virtualized list recycling the same DOM nodes.
- [ ] Duplicate mobile and desktop trees with alternating visibility.
- [ ] Mixed records and advertisements.
- [ ] Stable data attributes versus generated-class rebuilds.
- [ ] Localized pagination labels.
- [ ] Right-to-left card grids and controls.
- [ ] Multiple overlapping consent and account dialogs.
- [ ] Malformed heading hierarchy.
- [ ] Nested open shadow roots near the traversal bound.
- [ ] Explicit closed-shadow specimen and limitation wording.
- [ ] Same-origin frame specimen.
- [ ] Cross-origin frame refusal specimen.
- [ ] Canvas/WebGL content represented as outside the text contract.

## P1 — possible Pinpoint boundary

Build direct point-to-region selection only if fieldwork shows that bounded
proposals are insufficient.

A reviewable design must:

- [ ] Begin from the exact reviewed active page.
- [ ] Use temporary packaged isolated-world code.
- [ ] Offer click/tap selection without requiring drag.
- [ ] Offer keyboard selection.
- [ ] Expose a screen-reader-readable candidate list.
- [ ] Avoid reading form values.
- [ ] Avoid clicking page controls.
- [ ] Remove the overlay immediately after selection or cancellation.
- [ ] Convert the choice into a declarative bounded recipe.
- [ ] Show matched and ignored specimens.
- [ ] Run the same Contour and Perimeter evidence.
- [ ] Require changed-recipe acknowledgement.
- [ ] Create a fresh baseline.
- [ ] Transfer no DOM node, raw HTML, screenshot, or pointer trace.
- [ ] Receive native keyboard, screen-reader, voice, switch, zoom, and forced-colors acceptance.

## P1 — page-watch repair quality

- [ ] Relate Perimeter notices to later Needs repair evidence.
- [ ] Explain which structural witness changed.
- [ ] Distinguish missing records from changed records.
- [ ] Avoid alerts caused only by a pagination state.
- [ ] Avoid alerts caused only by virtualized-window churn.
- [ ] Keep repairs explicit and reversible.
- [ ] Retain the earlier recipe and evidence for audit.
- [ ] Keep arbitrary shared JavaScript outside repair logic.

## P1 — organization and re-finding

- [ ] Test whether people can find material again after a week.
- [ ] Keep folders as human-curated, shareable routes.
- [ ] Add private many-to-many labels.
- [ ] Add explicit saved-query views.
- [ ] Preserve Unfiled as a valid resting state.
- [ ] Make duplicate suggestions reversible.
- [ ] Make stale-source suggestions evidence-based and reversible.
- [ ] Make route-split suggestions reviewable.
- [ ] Avoid engagement ranking.
- [ ] Avoid opaque automatic taxonomy.

## P1 — Source Notes recovery

- [ ] Recover the actual rev0059 archive or reimplement it independently.
- [ ] Keep each note short and plain-text.
- [ ] Scope each note to one folder/source relationship.
- [ ] Keep notes outside source identity and acquisition recipes.
- [ ] Cover notes with native publication integrity.
- [ ] Preserve notes in independent branch excerpts.
- [ ] Report OPML omission.
- [ ] Include note disagreement in Confluence review.
- [ ] Do not turn notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

- [ ] Separate remote mode from loopback mode.
- [ ] Require TLS.
- [ ] Require durable Node identity.
- [ ] Add hostname allowlists.
- [ ] Add request, artifact, and rate bounds.
- [ ] Add expiring invitations.
- [ ] Add persistent revocation evidence.
- [ ] Separate public publication routes from private APIs.
- [ ] Start with immutable artifact retrieval.
- [ ] Test reverse proxies.
- [ ] Test self-hosted deployment.
- [ ] No default public bind.
- [ ] No silent LAN discovery.
- [ ] No UPnP port opening.
- [ ] No basic “enter an IP address and hope” workflow.

## Lab — WebRTC courier

- [ ] Transfer exactly one already reviewed immutable artifact.
- [ ] Use bounded signed offer-and-answer metadata.
- [ ] Make signaling explicit.
- [ ] Make STUN use visible.
- [ ] Make TURN use visible.
- [ ] Compare QR, copy/paste, HTTPS, relay, and WebRTC friction.
- [ ] Refuse replay.
- [ ] Refuse identity mismatch.
- [ ] Refuse digest mismatch.
- [ ] Refuse timeout and partial completion.
- [ ] Discard the session after transfer.
- [ ] Never require WebRTC for ordinary reading, sharing, Capture, Witness, or Pulse.

# Verification expectations for rev0070

A release is not sealed merely because the working tree tests pass.
The final evidence must include:

```text
focused Python Capture validation
Node HTTP Capture validation
full direct CLI library tests
Relay/publication/integrity tests
Node-store transaction tests
Pulse/Cadence tests
individually bounded command-line cases
Extension structural/static checks
Chromium background harness
shared-folder core harness
Firefox background harness
acquisition/redirect harness
vault conflict harness
real-browser fixture garden
rendered everyday reader
rendered Advanced Workbench
all delivered Python compilation
all delivered JavaScript syntax
all delivered JSON parsing
POSIX shell syntax
CLI doctor
deterministic two-build archive comparison
ZIP CRC and unique-member verification
safe relative paths
no symlinks or nested archives
no runtime databases, caches, or Python bytecode
clean-extraction byte and executable-mode comparison
principal-suite replay from clean extraction
```

Native installed-browser and human sessions must remain recorded as not run until
they actually occur.

---

# Historical bootstrap follows

# BOOTSTRAPROSE — ProgRSS rev0069 “Contour”

**Release:** rev0069 · **Product version:** 0.69.0 · **Vault schema:** 17 (unchanged)
**Node-store schema:** `progrss.node-store.v2` (unchanged)
**Capture artifact:** `progrss.browser-capture.v2`
**Capture assessment:** `progrss.capture-section-assessment.v1`
**Release date:** 2026-10-20
**Release maxim:** **A selector says where. Evidence says why it may hold.**

## `/run` interpretation

When this file is the active bootstrap, continue from the delivered rev0069 tree.
Do not reconstruct the project from rev0058, a prose-only chat transcript, an absent rev0059 archive, or a prior generated release card.
The delivered rev0069 source tree is the implementation authority.

## Chain-of-custody correction: the rev0068 bootstrap gap

The executable rev0068 Pulse tree delivered its Cadence package, packaged Witness adapter, tests, and validation evidence.
Its distributed `BOOTSTRAPROSE.md`, however, still began with the rev0067 Capture heading and did not contain a Pulse bootstrap section.
The earlier release response described that 11,256-line file as an updated Pulse bootstrap; the delivered bytes do not support that description.

This differs from the rev0067 Cadence archive defect:

```text
rev0067 Cadence defect
  described executable scheduling code that was absent from the archive

rev0068 Pulse bootstrap defect
  executable scheduling code was present and tested,
  but the handoff document was not advanced from Capture
```

Contour corrects the active documentation boundary without rewriting historical artifacts:

```text
The rev0069 heading and `/run` contract are first.
Pulse is named in the active lineage and product truths.
Evidence/rev0068-Pulse/ remains intact.
Evidence/rev0068-Pulse-bootstrap-gap/ records the observed document bytes.
The old rev0067 Capture section remains below as historical material.
```

The current rev0069 section, code, release metadata, and sealed archive take precedence over stale historical headings below it.

The current release lineage is:

```text
Nightstand   dark fluorescent basic reader + first loopback Node
Handshake   explicit summary-only Extension ↔ Node pairing
Exchange    one handoff with Follow / Add route / Take branch
Confluence  human-first three-way later-copy review
Receipt     one transactional Node-owned branch-adoption write
Witness     one reviewed public feed or page-watch check with durable evidence
Capture     one reviewed browser-rendered page artifact with no login transfer
Pulse       one foreground Node timing system using the Witness acquisition path
Contour     explain why one rendered section may hold or break
```

Treat these as current product truths:

```text
The everyday Extension reader remains the default product.
Dark fluorescent presentation remains the default.
Light presentation remains an explicit persisted option.
Forced-colors removes decorative fluorescent treatment.
Reduced-motion remains respected.
Advanced Workbench remains secondary.
The Extension remains useful without a Node.
The CLI remains useful without a browser.
The Node remains the CLI's local web-server mode.
The Node binds only to literal loopback in this release.
An exported private backup may still be opened read-only.
A Node-owned library is a local SQLite single-writer boundary.
The portable complete library remains progrss.private.v1 JSON.
SQLite remains a local transaction mechanism, not an interchange format.
Pairing remains summary-only, read-only, process-lifetime, and revocable.
Pairing does not reveal source addresses, retained items, receipts, or browser authority.
Pairing does not grant acquisition, scheduling, publication, merge, or mutation authority.
Exchange remains artifact-scoped rather than synchronization.
Confluence remains three-way later-copy review.
Receipt's reviewed branch-adoption operation remains available.
Witness's one-shot public acquisition remains available.
Capture remains one Extension-submitted rendered-page observation.
Pulse remains foreground-only Node scheduling for Node-reproducible sources.
Contour changes Capture explanation, not acquisition authority.
```

## The human problem Contour addresses

A CSS selector can identify a location in one document.
It cannot promise that the site will preserve that location.

Before Contour, Capture could show:

```text
Saved watched section
Repeated entries on this page
Primary readable text
```

It could show matched and ignored examples.
It could not clearly explain why one proposal might survive ordinary page changes better than another.

That gap encouraged two wrong mental models:

```text
The first proposal must be the correct one.
The computer must know whether this selector will stay stable.
```

Contour rejects both models.

The ordinary reader now asks:

> **What part of this page counts as an update?**

Then it shows one bounded label per proposal:

```text
More likely to stay put
Needs watching
Fragile
```

For the selected proposal it also shows:

```text
Matched now
Ignored example
Why this may hold
What could break
```

The review states:

> This is bounded evidence from the page as rendered now, not a promise that the site will keep the same structure.

That sentence is a product boundary, not decorative caveat text.

## What the labels mean

### More likely to stay put

This means the current rendering contains several bounded structural signals that are usually easier to explain and repair.

Possible evidence includes:

```text
semantic main or article boundary
recognized landmark role
structured list-item boundary
exactly one visible region match
bounded repeated records
most records have destination links
most records have headings
record shapes are broadly consistent
no obvious navigation, form, sidebar, or footer clutter inside the match
```

It does not mean:

```text
guaranteed stable
publisher endorsed
safe site
correct semantic meaning
future-compatible
suitable for unattended browser automation
eligible for Pulse scheduling
```

### Needs watching

This means the current result is usable, but one or more signals are mixed.

Examples:

```text
a semantic region exists but is broad
only two repeated records are currently visible
some records lack links or headings
several visible regions match
some page chrome appears inside the selection
```

This is often the honest label for real websites.

### Fragile

This means the current result depends on weak, noisy, or absent structure.

Possible warnings include:

```text
generated-looking class or identifier
no readable match
very little readable text
many unrelated matches
very broad region
few stable destination links
few clear headings
highly inconsistent repeated records
navigation, forms, sidebars, or footer material inside the selection
hidden matches that were excluded
```

Fragile is not an automatic refusal.
Some important sites have poor markup.
The person may still choose the section after seeing the consequence.

## No confidence theater

Contour uses an internal bounded rank only to order proposals.
The rank is not submitted to the Node.
The rank is not retained in the library.
The rank is not written into the receipt.
The rank is not shown as a percentage.

The shipped artifact contains only the ordinal label, summary, bounded reasons, bounded warnings, and bounded signals.

Do not turn Contour into:

```text
87% stable
AI confidence
publisher reliability score
engagement score
site quality score
secret recommendation model
automatic winner selection
```

A numeric-looking certainty would be more precise in appearance than the evidence supports.

## Fixed extractor boundary

The canonical extractor is:

```text
Extension/shared/capture.js
```

The Chromium service worker imports it.
The generated Firefox package contains the same bytes.
Firefox lists it before `background.js` in its background scripts.

The extractor is packaged ProgRSS code.
It is not read from:

```text
the watched page
the local Node
a source list
a curator note
a shared recipe
an Exchange artifact
a remote script
```

The background runtime passes `ProgRSSCapture.extract` to `scripting.executeScript()`.

The execution boundary remains:

```text
active tab only
exact reviewed HTTP(S) address
frame 0 only
isolated extension world
visible user action
optional exact-site permission
no page-supplied executable code
```

The extractor emits plain JSON-safe values only.

## Candidate limit

At most three candidates are offered.

The ordinary classes remain:

```text
Saved watched section
Repeated entries on this page
Primary readable text
```

The extractor may use one additional repeated candidate only when a duplicate recipe did not already occupy the bounded set.
The final returned list is still capped at three.

Duplicate recipes collapse.
Unreadable candidates remain visibly unavailable rather than becoming silent fallbacks.

There is no:

```text
selector forest
page-wide DOM explorer
source-code editor
arbitrary XPath editor
JavaScript editor
machine-generated hundred-option list
silent selection
```

## Bounded proposal search

Repeated proposals are sought from a fixed list of declarative structures such as:

```text
main article
[role="main"] article
main [role="article"]
article
[role="article"]
main .h-entry
.h-entry
main [itemprop="itemListElement"]
[itemprop="itemListElement"]
main .post
main .entry
main .news-item
main li
```

Primary-region proposals are sought from:

```text
main
[role="main"]
[itemprop="articleBody"]
article
primary readable fallback
```

These are fixed packaged probes.
They are not fetched from a server.
They do not execute page code.

The current probe list is intentionally conservative and inspectable.

## Visible and hidden matches

A match is excluded from selected evidence when the element is:

```text
hidden
aria-hidden="true"
display: none
visibility: hidden
visibility: collapse
```

The assessment retains a bounded hidden-match count.

Hidden-match exclusion matters because pages often retain:

```text
mobile and desktop copies
collapsed drafts
preloaded navigation panels
unpublished templates
accessibility-inert clones
```

Contour does not claim to understand why an element is hidden.
It records that the rendered selection did not include it.

## Semantic evidence

Contour can recognize bounded evidence from:

```text
main
article
role="main"
role="article"
itemprop="articleBody"
itemprop="itemListElement"
h-entry
```

Semantic evidence raises explainability.
It does not prove that the publisher used the element correctly.

A semantic element can still contain:

```text
advertising
navigation
unrelated modules
personalized content
mixed record types
```

That is why Contour also examines clutter and repeated-entry shape.

## Named and generic evidence

The selector kind is one of:

```text
semantic
named
generic
```

Named evidence may come from a non-volatile ID, role, item property, or accessible label.
Generic evidence depends mostly on broad element structure or class names.

The label is descriptive.
It is not a browser selector standard category.

## Generated-looking selectors

Contour warns when a selector resembles deployment-generated identity, including bounded patterns such as:

```text
css-a83f10d9
jsx-12345678
emotion-abcdef12
very long hexadecimal-looking class names
very long digit-heavy identifiers
```

This is a heuristic warning.
A generated-looking class may remain stable.
A human-looking class may change tomorrow.

The correct message is:

> The selector contains a generated-looking class or identifier that may change after deployment.

Do not say:

> This selector will break.

## Region evidence

For a region candidate, Contour considers:

```text
visible match count
unique visible match
semantic boundary
readable character count
clutter landmarks
hidden excluded matches
selector volatility
```

A region with no visible match receives a fragile result.
A region with several visible matches warns that only the first would be watched.
A region with very little text warns that the current observation may not provide useful change evidence.
A very broad region warns that unrelated page changes may appear.

## Repeated-entry evidence

For repeated records, Contour considers:

```text
visible entry count
entry destination links
entry headings or titles
entry text-length consistency
semantic boundary
clutter landmarks
hidden excluded matches
selector volatility
```

Repeated records are capped at 200.

Link, title, and consistency counts cannot exceed the repeated-entry count.
The Node validates that relationship.

Entry text-length consistency is deliberately coarse.
It can help identify a mixed list.
It is not a semantic classifier.

## Clutter evidence

Contour looks for bounded descendants such as:

```text
nav
footer
aside
form
role="navigation"
role="contentinfo"
role="complementary"
```

When these appear inside the selected area, the review warns that unrelated page behavior may affect the watch.

When no such structure appears, the review may say so as one positive reason.

Absence of recognized clutter does not prove the region is clean.
A site may use generic containers for all of its chrome.

## Matched and ignored specimens

The review keeps matched examples visible.

For repeated entries it shows at most three bounded title/summary examples.
For a region it shows one bounded text specimen.

The ignored example is chosen from visible navigation, footer, aside, or related landmark content outside the selected area when available.

The ignored specimen is not a complete exclusion list.
It demonstrates one consequence of the current candidate.

## Right-to-left and language evidence

The candidate document carries:

```text
page.language
page.direction
```

Direction is one of:

```text
ltr
rtl
auto
empty when unavailable
```

The Node validates the bounded value and retains it in browser-capture provenance.

Contour's real-browser fixture includes an Arabic right-to-left page.

## Candidate response schema

The background response is:

```text
progrss.browser-capture-candidates.v2
```

Top-level evidence includes:

```text
capturedAt
page
source
candidates
provenance
```

The provenance identifies:

```text
kind = rendered-browser-dom
topFrameOnly = true
isolatedWorld = true
arbitrarySharedCode = false
extensionVersion
extractorRevision = contour-v1
```

The candidate response is local Extension evidence.
It is not yet a Node write.

## Assessment schema

Each candidate carries:

```text
progrss.capture-section-assessment.v1
```

Exact assessment fields:

```text
schema
level
summary
reasons
warnings
signals
```

Level is exactly one of:

```text
steadier
watchful
fragile
```

Reasons are at most four bounded plain-text strings.
Warnings are at most four bounded plain-text strings.

Signals are exactly:

```text
selectorKind
semanticBoundary
uniqueMatch
visibleMatches
hiddenMatches
repeatedEntries
linkedEntries
titledEntries
consistentEntries
clutterElements
textCharacters
```

Unknown fields are refused by the Node.
Unsupported level values are refused.
Inconsistent counts are refused.
Oversized text is refused.

## Submitted artifact v2

The reviewed Extension submission is:

```text
progrss.browser-capture.v2
```

Exact top-level fields:

```text
schema
capturedAt
page
source
recipe
capture
examples
selection
provenance
```

`selection` is:

```text
schema = progrss.capture-selection.v1
candidateId
assessment
```

The artifact continues to contain only bounded JSON-safe text and links.

It contains no:

```text
cookie
credential
authorization header
browser storage
form value
raw HTML
DOM node
screenshot
image bytes
page script
stylesheet body
subresource body
open-tab list
Extension capability
Node administrator capability
```

## Rolling upgrade compatibility

The Node accepts:

```text
progrss.browser-capture.v2
progrss.browser-capture.v1
```

Version 2 requires section evidence.
Version 1 has no section evidence.

When a v1 artifact is accepted, the Node does not invent:

```text
candidate ID
steadier/watchful/fragile label
summary
reasons
warnings
extractor revision
page direction
```

Human receipt output identifies it as a legacy capture without assessment.

This compatibility exists for a local rolling upgrade.
It is not permission to keep emitting v1 indefinitely.

## Node validation

Before durable intent, the Node validates:

```text
known top-level fields
artifact schema
capture age
future clock skew
exact source ID
exact watched-page address
HTTP(S)-only links
recipe bounds
capture mode
entry count
text bounds
example bounds
page direction
selection schema
candidate ID
assessment schema
assessment level
reason and warning bounds
signal keys
signal types
signal numeric bounds
signal count relationships
provenance kind
frame boundary
isolated-world boundary
no arbitrary shared code
Extension version
extractor revision
canonical JSON byte limit
recipe-change acknowledgement
```

Malformed evidence is refused before resumable work is created.

## Durable receipt

The Node retains:

```text
artifact schema
artifact SHA-256
extractor revision
selected candidate ID
section-evidence level
section-evidence summary
recipe changed
recipe-change acknowledgement
top-frame boundary
isolated-world boundary
zero Node site requests
no recurring schedule
```

The selected assessment also remains in bounded acquisition evidence attached to the committed result.

The hidden ordering rank is not receipted.

## Source identity boundary

Contour evidence is not acquisition identity.

Changing only:

```text
assessment label
assessment summary
assessment reason
assessment warning
rendered direction
extractor revision
```

does not make two different feed addresses or page-watch recipes equal.

Pulse schedule eligibility remains bound to the exact Node-side Witness source identity.

A browser-assisted Capture receipt remains insufficient scheduling evidence.

## Recipe-change boundary

If the selected candidate differs from the saved declarative recipe, the final action remains unavailable until the person acknowledges:

> **Use this new watched section**

Accepting that consequence:

```text
updates the declarative page-watch recipe
increments the recipe version
clears the old comparison snapshot
clears obsolete shape-health state
clears held-change state
saves the current observation as a fresh baseline
```

It does not compare a new region to the old region.
It does not fabricate a historical alert.
It does not erase earlier retained items.

## Network boundary

Invitation review makes no watched-site request.
Candidate extraction reads the already rendered active page.
Node commit makes zero watched-site requests.

Contour does not:

```text
wake the browser
open a hidden tab
control login
submit a form
click consent controls
inspect another tab
inspect a cross-origin frame
open a remote debugger
launch a headless browser
transfer the cookie jar
create a schedule
```

## Scheduling boundary

Pulse schedules only sources that the Node independently reproduced through Witness.

Contour does not change that rule.

The following remain unschedulable from Contour evidence alone:

```text
browser-assisted page
browser-only page
signed-in page
consent-gated rendered page
Capture artifact with zero Node requests
```

A site may later become Node-reproducible through a separate successful Witness check.
That would create separate schedule evidence.

## Sharing boundary

A shared source-list recipe may carry declarative selectors.
It does not carry Contour's browser login authority.

The recipient still reviews:

```text
source route
page-watch recipe
new source starts paused
folder placement
curator wording
```

Contour evidence from one sender's browser is not automatically authority on the recipient's browser.

Do not add Contour evidence to OPML as if it were a portable standard field.

## Accessibility hierarchy

The ordinary candidate label includes:

```text
candidate name
stability label
plain description
summary
matched example
```

The selected candidate includes:

```text
matched examples
ignored example
why this may hold
what could break
not-a-promise statement
```

Exact numeric signals remain under:

```text
Advanced section evidence
```

This is progressive disclosure.
It is not concealment of a required decision.

The label, reason, warning, and example remain part of the radio option's understandable context.

## Forced colors and motion

Forced-colors mode removes decorative gradients and glow from the new evidence panel.
Borders and labels remain visible using system colors.

Contour adds no constant animation.
Reduced-motion behavior remains unchanged.

## Real-browser extractor fixture

The new test is:

```text
Extension/tests/capture_quality_smoke.py
```

It loads the exact shipped extractor into a real Chromium DOM.

Current fixture cases:

```text
semantic repeated articles
hidden repeated article
volatile generated class
right-to-left Arabic page
```

The fixture verifies:

```text
candidate response schema v2
semantic repeated candidate selected
three visible entries
one hidden match excluded
steadier label
linked-entry evidence
ignored navigation specimen
generated-looking selector warning
fragile label
right-to-left direction
contour-v1 provenance
bounded reasons
bounded warnings
```

This is browser-DOM regression evidence.
It is not installed-Extension acceptance.

## Rendered reader smoke

The shipped reader smoke now verifies:

```text
three Capture choices
per-choice stability label
selected why-this-may-hold evidence
selected what-could-break evidence
not-a-promise language
changed-recipe acknowledgement
v2 artifact submission
durable section evidence in the receipt
permission cleanup
existing Exchange, pairing, reader, and Workbench flows
```

The screenshots are rendered from the exact shipped reader HTML, CSS, and JavaScript with controlled local API responses.

## Verification status

Working-tree verification includes:

```text
11/11 acquisition boundary tests
9/9 Pulse/Cadence tests
9/9 Node-store tests
17/17 Node HTTP and operation tests
46/46 direct CLI library tests
29/29 Relay/publication/continuity tests
26/26 command-line cases in bounded individual runs
147 distinct Python test cases
57/57 Extension structural/static checks
PASS Chromium background harness
PASS generated Firefox background harness
PASS acquisition and redirect harness
PASS vault conflict and failed-write harness
PASS real-browser Contour extractor fixture
PASS rendered everyday reader
PASS rendered Advanced Workbench

Syntax and structured files:

```text
PASS 27 Python launch/modules compiled in memory
PASS 64 JavaScript files parsed
PASS 49 JSON files parsed
PASS  2 POSIX shell files parsed
```

Sealing requirements:

```text
two deterministic ZIP builds must be byte-identical
CRC and unique-member checks must pass
all paths must be safe and relative
no symlink, cache, bytecode, runtime database, or nested archive may ship
clean extraction must match source bytes and executable modes
principal Contour, Node, CLI, and Extension lanes must replay from delivered bytes
```
```

The aggregate command-line wrapper can retain descendant output handles after completed assertions.
Do not use its wall-clock exit as release proof.
The 26 cases must remain individually bounded.

## Native and human limits

Do not claim completed:

```text
unmanaged installed Chromium acceptance
current native Firefox acceptance
Firefox ESR acceptance
signed-in real-site Capture fieldwork
unfamiliar-person comprehension sessions
real screen-reader sessions
Braille sessions
voice-control sessions
switch-device sessions
high-zoom human sessions
forced-colors human sessions
fatigue and interruption sessions
```

Automated accessibility-tree, keyboard, reflow, and forced-colors checks remain regression evidence.
They are not a substitute for those sessions.

## Most important unfamiliar-person questions

Ask a participant:

```text
What part of this page will ProgRSS watch?
What example is included?
What example is ignored?
Why might this section hold?
What could break it?
Does “More likely to stay put” guarantee anything?
Will the Node receive your login?
Will the Node contact this site during commit?
Will this create a schedule?
What changes when you choose a different watched section?
Why does that create a fresh baseline?
```

A successful interface lets the participant answer without reading Advanced evidence.

## Wrong turns that require product changes

Change wording or hierarchy when people:

```text
treat the label as a probability
treat More likely to stay put as a guarantee
assume the first proposal is automatically correct
cannot connect a reason to the matched specimen
cannot connect a warning to the ignored specimen
choose the broadest section because it looks recommended
believe hidden matches were transmitted
believe the Node receives browser login authority
believe Capture becomes scheduled
believe a fresh baseline is a new detected update
cannot find the recipe-change acknowledgement
cannot cancel and release newly granted permission
```

Do not respond by adding:

```text
silent selection
secret confidence scores
arbitrary shared JavaScript
cookie transfer
remote browser control
ambient tab access
central accounts
engagement ranking
mandatory Node use
```

## Current limits

Contour does not yet solve:

```text
pagination across pages
infinite scroll
virtualized off-screen records
closed shadow roots
cross-origin frames
canvas-only text
image-only notices
content rendered only after interaction
multiple account states
consent overlays that obscure the target
publisher redesign between review and next observation
human point-to-region selection
direct selector repair inside the ordinary UI
```

These are explicit product boundaries.

## Prioritized checklist

### P0 — completed in Contour

- [x] Extract Capture logic into one canonical shared module.
- [x] Load the shared module in Chromium.
- [x] Load the same module before Firefox background startup.
- [x] Keep extraction fixed, packaged, top-frame-only, and isolated-world.
- [x] Keep the exact reviewed page requirement.
- [x] Keep at most three candidate sections.
- [x] Exclude hidden matches from selected evidence.
- [x] Count hidden matches as bounded warning evidence.
- [x] Add semantic-boundary evidence.
- [x] Add unique-region evidence.
- [x] Add repeated-entry link evidence.
- [x] Add repeated-entry heading evidence.
- [x] Add repeated-entry shape-consistency evidence.
- [x] Add clutter-landmark evidence.
- [x] Add generated-looking-selector warnings.
- [x] Add bounded text-size evidence.
- [x] Add rendered text direction.
- [x] Add `progrss.browser-capture-candidates.v2`.
- [x] Add `progrss.capture-section-assessment.v1`.
- [x] Add `progrss.capture-selection.v1`.
- [x] Add `progrss.browser-capture.v2`.
- [x] Validate strict known assessment fields in Python.
- [x] Validate bounded reasons and warnings.
- [x] Validate signal types and numeric bounds.
- [x] Validate repeated-entry count relationships.
- [x] Preserve legacy v1 rolling-upgrade compatibility.
- [x] Avoid inventing assessment for a legacy artifact.
- [x] Show per-choice human labels.
- [x] Show Why this may hold.
- [x] Show What could break.
- [x] State that evidence is not a promise.
- [x] Keep exact numeric signals under Advanced.
- [x] Preserve changed-recipe acknowledgement.
- [x] Preserve fresh-baseline behavior.
- [x] Preserve zero Node watched-site requests.
- [x] Preserve no-schedule behavior.
- [x] Preserve summary-only pairing.
- [x] Persist selected evidence in the acquisition receipt.
- [x] Keep hidden rank out of the artifact and receipt.
- [x] Add real-browser semantic, hidden, volatile, and RTL fixtures.
- [x] Extend rendered-reader smoke through receipt evidence.
- [x] Update Chromium and Firefox acceptance protocols.
- [x] Update CLI and Extension documentation.
- [x] Keep dark mode default and light mode available.

### P0 — native and unfamiliar-human fieldwork

- [ ] Install the exact package in unmanaged current Chromium.
- [ ] Install the exact package in current Firefox.
- [ ] Install the exact package in Firefox ESR.
- [ ] Run one signed-in page through the exact Capture path.
- [ ] Run one public dynamic page through the exact Capture path.
- [ ] Observe whether people understand More likely to stay put.
- [ ] Observe whether people understand Needs watching.
- [ ] Observe whether people understand Fragile.
- [ ] Ask whether any label is interpreted as a guarantee.
- [ ] Ask whether the Node receives login authority.
- [ ] Ask whether a schedule was created.
- [ ] Test cancellation before page permission.
- [ ] Test cancellation after extraction.
- [ ] Test cancellation after result review.
- [ ] Verify permission cleanup in native browser UI.
- [ ] Run keyboard-only use.
- [ ] Run a real screen reader.
- [ ] Run Braille where available.
- [ ] Run voice control.
- [ ] Run switch-style sequential control.
- [ ] Run 200%, 300%, and 400% zoom.
- [ ] Run forced colors.
- [ ] Run reduced motion.
- [ ] Run fatigue and interruption conditions.
- [ ] Change wording and hierarchy from observed wrong turns.

### P0 — fixture garden

- [ ] Add paginated server-rendered list fixtures.
- [ ] Add infinite-scroll fixtures with only rendered records in scope.
- [ ] Add virtualized-list fixtures.
- [ ] Add localized dates and right-to-left card grids.
- [ ] Add consent-overlay fixtures.
- [ ] Add mixed article and advertising lists.
- [ ] Add duplicate mobile/desktop hidden trees.
- [ ] Add unstable generated-class rebuild fixtures.
- [ ] Add stable data-attribute fixtures.
- [ ] Add malformed heading hierarchy fixtures.
- [ ] Add cross-origin frame refusal fixtures.
- [ ] Add open-shadow-root observation fixtures.
- [ ] Keep closed shadow roots explicitly unsupported unless a new contract is reviewed.

### P1 — direct human point-to-region selection

A possible next code boundary is provisionally named **Pinpoint**.

Do not implement it as arbitrary selector scripting.

A safe path would be:

- [ ] Begin only from the exact reviewed page and visible user action.
- [ ] Temporarily show a packaged overlay in the isolated world.
- [ ] Let the person point to one visible region or repeated record.
- [ ] Keep the overlay incapable of reading form values.
- [ ] Keep the overlay incapable of clicking page controls.
- [ ] Remove the overlay immediately after selection or cancel.
- [ ] Convert the selected element into a bounded declarative recipe.
- [ ] Show matched and ignored specimens before submission.
- [ ] Show Contour evidence for the generated recipe.
- [ ] Require recipe-change acknowledgement.
- [ ] Create a fresh baseline.
- [ ] Transfer no DOM node or raw HTML to the Node.
- [ ] Add native focus, keyboard, voice, switch, and zoom acceptance.

Do not ship Pinpoint merely because it is technically possible.
Observe whether Contour's current proposals already solve the common task.

### P1 — page-watch repair quality

- [ ] Relate Contour warnings to later Needs repair evidence.
- [ ] Explain which structural witness changed.
- [ ] Preserve Before/Now evidence across healthy checks.
- [ ] Avoid creating an alert from template drift.
- [ ] Keep repair explicit and reversible.
- [ ] Keep the old recipe and evidence available for audit.
- [ ] Never run arbitrary shared JavaScript as repair logic.

### P1 — organization and re-finding

- [ ] Test whether people can find material again after one week.
- [ ] Keep folders as human-curated, shareable routes.
- [ ] Add private many-to-many labels.
- [ ] Add explicit saved-query views.
- [ ] Preserve Unfiled as a valid state.
- [ ] Make duplicate suggestions reversible.
- [ ] Make stale-source suggestions reversible.
- [ ] Make route-split suggestions reversible.
- [ ] Avoid engagement ranking.
- [ ] Avoid opaque automatic taxonomy.

### P1 — Source Notes recovery

The historical handoff describes source notes, but the actual rev0059 archive remains absent from the recovered delivered chain.

- [ ] Recover the actual rev0059 archive or independently reimplement the behavior.
- [ ] Keep notes short and plain-text.
- [ ] Scope each note to one folder/source relationship.
- [ ] Keep notes outside acquisition identity.
- [ ] Cover notes with native publication integrity.
- [ ] Preserve notes in independent branch excerpts.
- [ ] Report note omission from OPML.
- [ ] Include note disagreements in Confluence review.
- [ ] Do not expand notes into comments, reactions, profiles, or notifications.

### P2 — remote Nodes

- [ ] Keep remote mode separate from loopback mode.
- [ ] Require TLS.
- [ ] Require durable Node identity.
- [ ] Add hostname allowlists.
- [ ] Add request, artifact, and rate bounds.
- [ ] Add expiring invitations.
- [ ] Add persistent revocation evidence.
- [ ] Separate public publication routes from private APIs.
- [ ] Begin with immutable artifact retrieval.
- [ ] Test reverse proxies.
- [ ] Test self-hosted deployment.
- [ ] No default public bind.
- [ ] No silent LAN discovery.
- [ ] No UPnP port opening.
- [ ] No basic enter-an-IP-and-hope flow.

### Lab — WebRTC courier

- [ ] Transfer exactly one already reviewed immutable artifact.
- [ ] Use bounded signed offer and answer metadata.
- [ ] Make signaling visible.
- [ ] Make STUN use visible.
- [ ] Make TURN use visible.
- [ ] Compare QR, copy/paste, HTTPS, relay, and WebRTC friction.
- [ ] Refuse replay.
- [ ] Refuse identity mismatch.
- [ ] Refuse digest mismatch.
- [ ] Refuse timeout and partial completion.
- [ ] Discard the session after transfer.
- [ ] Never require WebRTC for ordinary reading, sharing, Capture, Witness, or Pulse.

## Commands for the next maintainer

From the release root:

```sh
cd CLI
./progrss --version
./progrss doctor
```

Core Contour tests:

```sh
python -m unittest tests.test_acquisition -v
python -m unittest tests.test_node_server -v
python ../Extension/tests/capture_quality_smoke.py
```

Extension tests:

```sh
cd ../Extension
python -m unittest tests.test_static -v
node tests/background_harness.js
node tests/firefox_background_harness.js
node tests/acquisition_harness.js
node tests/vault_conflict_harness.js
python tests/browser_smoke.py
```

Regenerate Firefox after changing shared Extension files:

```sh
python tools/sync_firefox.py
```

Then rerun static parity checks.

## Files that define Contour

```text
Extension/shared/capture.js
Extension/background.js
Extension/sidepanel/app.js
Extension/sidepanel/app.css
Extension/platform/firefox-manifest.json
Extension/tests/capture_quality_smoke.py
Extension/tests/browser_smoke.py
CLI/acquisition.py
CLI/node_server.py
CLI/progrss.py
CLI/docs/NODE-CAPTURE.md
CLI/docs/NODE-CONTOUR.md
CLI/docs/NODE-CAPTURE-ACCEPTANCE.md
```

## Invariants to preserve when continuing

```text
Do not make Contour evidence a schedule grant.
Do not make Capture a pairing capability.
Do not transfer login authority.
Do not transfer raw HTML.
Do not add arbitrary shared JavaScript.
Do not silently select the highest-ranked candidate.
Do not expose a fake probability.
Do not make the Node interpret DOM.
Do not make the Extension write arbitrary Node state.
Do not let imports create schedules.
Do not let sharing create schedules.
Do not let pairing create schedules.
Do not let Capture create schedules.
Do not let Pulse wake the browser.
Do not replace matched examples with an opaque score.
Do not hide recipe-change consequences.
Do not compare a new region against an old unrelated baseline.
Do not represent automated regression as completed human acceptance.
```

## The strategic direction

ProgRSS is not trying to replace RSS with a proprietary article format.

Its next-generation value is the combination of:

```text
stable open feed formats
portable source routes
bounded page watching when feeds do not exist
human-readable sharing consequences
private local reading state
explicit acquisition authority
receipted local Node operations
optional Node scheduling only after reproducibility evidence
```

Contour strengthens the non-RSS boundary without making it magical.

The durable proposition remains:

> A person can follow one feed, adopt a complete curated route, take one independent branch, or deliberately watch one meaningful page region—without joining a central platform or transferring private reading state and browser authority.

The next correct move is evidence from real people and real sites, then a deliberately bounded improvement to section selection.

---

# BOOTSTRAPROSE — ProgRSS rev0067 “Capture”

**Release:** rev0067 · **Product version:** 0.67.0 · **Vault schema:** 17 (unchanged)
**Node-store schema:** `progrss.node-store.v2` (unchanged from Witness)
**Release date:** 2026-10-20
**Release maxim:** **The browser keeps the login. The Node keeps the evidence.**

## `/run` interpretation

When this file is the active bootstrap, continue from the delivered rev0067 tree.
Do not reconstruct the project from rev0058, a prose-only transcript, a guessed rev0059 implementation, or a partial browser capture.
The delivered rev0067 source tree is the current implementation authority.

The current release lineage is:

```text
Nightstand   dark fluorescent basic reader + first loopback Node
Handshake   explicit summary-only Extension ↔ Node pairing
Exchange    one handoff with Follow / Add route / Take branch
Confluence  human-first three-way later-copy review
Receipt     one transactional Node-owned branch-adoption write
Witness     one reviewed public feed or page-watch check with durable evidence
Capture     one reviewed browser-rendered page artifact with no login transfer
```

Treat these as current product truths:

```text
The everyday Extension reader remains the default product.
Dark fluorescent presentation remains the default.
Light presentation remains an explicit persisted option.
Forced-colors removes decorative fluorescent treatment.
Advanced Workbench remains secondary.
The Extension remains useful without a Node.
The CLI remains useful without a browser.
The Node remains the CLI's local web-server mode.
The Node binds only to literal loopback in this release.
An exported private backup may still be opened read-only.
A Node-owned library is a local SQLite single-writer boundary.
The portable complete library remains progrss.private.v1 JSON.
SQLite remains a local transaction mechanism, not an interchange format.
Pairing remains summary-only, read-only, process-lifetime, and revocable.
Pairing does not reveal source addresses, retained items, receipts, or browser authority.
Pairing does not grant acquisition or mutation authority.
Exchange remains artifact-scoped rather than synchronization.
Confluence remains three-way later-copy review.
Receipt's reviewed branch-adoption operation remains available.
Witness's one-shot public acquisition remains available.
Capture adds one Extension-submitted rendered-page observation.
Capture applies only to one existing watched-page source.
The Node administrator creates the capture request.
The capture request expires after ten minutes.
The request capability remains in Node process memory.
The first valid Extension review binds one exact Extension Origin.
Capture does not use the summary-only pairing capability.
Capture does not scan localhost, tabs, the LAN, or browser storage.
Invitation review reads no page content.
The exact reviewed watched-page address must be active before extraction.
The Extension asks for exact page authority only inside the visible capture action.
The Extension runs one fixed packaged extractor.
The extractor runs only in the active top frame.
The extractor runs in the isolated extension world.
The extractor does not execute code supplied by the Node, source list, curator, or page.
At most three bounded candidate sections are offered.
Candidates may include the saved watched section.
Candidates may include repeated visible entries.
Candidates may include primary readable text.
The person sees matched examples before anything is sent.
The person sees ignored navigation or footer evidence before anything is sent.
Only one candidate can be submitted.
A changed watched-section recipe requires a separate acknowledgement.
A changed recipe clears the old comparison baseline.
A changed recipe creates a fresh baseline rather than inventing an old change.
The artifact is strict JSON-safe data.
The artifact contains bounded text, links, recipe evidence, examples, time, and provenance.
The artifact contains no cookie.
The artifact contains no credential.
The artifact contains no authorization header.
The artifact contains no browser storage.
The artifact contains no form value.
The artifact contains no raw HTML.
The artifact contains no DOM node.
The artifact contains no screenshot.
The artifact contains no image bytes.
The artifact contains no page script.
The artifact contains no arbitrary shared code.
The artifact contains no Extension capability.
The artifact contains no Node administrator capability.
The Node validates the exact source ID and page address.
The Node validates the exact reviewed base-library digest.
The Node validates the exact preview digest.
The Node validates artifact age and future skew.
The Node validates strict known fields and value types.
The Node validates bounded canonical JSON size.
The Node validates top-frame isolated-world provenance.
The Node refuses stale, mismatched, oversized, malformed, or unknown-field artifacts.
The Node validates recipe-change acknowledgement before durable intent.
One successful capture consumes the request.
An exact completed retry returns the original receipt.
An exact completed retry performs no second Node-side site request.
An exact completed retry performs no second library write.
Same-key different-content reuse is refused.
The portable library, receipt, completed-job state, and replay fingerprint commit atomically.
Capture makes zero Node-side requests to the watched site.
Capture creates no recurring schedule.
Capture does not turn an enabled source into an unattended browser automation job.
Browser cookies and authority remain in the browser.
The Node retains evidence rather than browser control.
The result distinguishes baseline, unchanged, changed, pending, and repair states.
The result reports zero Node site requests.
The result reports that no schedule was created.
The ordinary result leads with consequence, item count, request count, and revision.
Advanced evidence carries hashes, identifiers, provenance, and recipe detail.
Newly obtained loopback and page permissions are released after cancel or completion when ProgRSS added them.
Previously held browser authority is not silently removed.
There is no generic browser-to-Node write endpoint.
There is no arbitrary capture-by-URL endpoint.
There is no cookie bridge.
There is no remote browser controller.
There is no headless browser service.
There is no arbitrary shared JavaScript recipe.
There is no recurring scheduler in rev0067.
There is no startup source request.
There is no localhost scan, LAN discovery, or default public bind.
There is no account, telemetry service, central directory, or follower graph.
There is no WebRTC dependency.
```

## Why Capture exists

Witness proved that the Node can check a public feed or server-rendered page itself.
That is not enough for a modern reader.
Some useful pages reveal their meaningful content only after:

```text
browser rendering
client-side application startup
consent interaction
a deliberate signed-in session
personalized account context
an authenticated navigation flow
```

Sending the browser's cookie jar to the Node would be the wrong answer.
It would collapse a carefully visible browser authority boundary into a long-lived local service credential.
It would also make shared page-watch recipes dangerously easy to confuse with shared login power.

Capture uses a narrower model:

```text
The person opens the exact page.
The browser renders it with authority it already holds.
The Extension proposes bounded visible evidence.
The person chooses what counts as an update.
The Node receives one reviewed artifact.
The browser session stays in the browser.
```

The release is therefore about provenance and authority separation, not browser automation.

## Three reproduction classes

ProgRSS now distinguishes three page-watch classes.

### Node-reproducible

```text
The Node can retrieve the public or otherwise independently reachable page.
Witness can perform a bounded HTTP check.
The Node can preserve request and response evidence.
A later explicit scheduler may be possible.
```

### Browser-assisted

```text
The Extension can render and extract the exact reviewed page now.
The Node receives bounded text and links.
The Node does not receive the browser's cookies or session authority.
One reviewed capture can update the portable library.
No unattended schedule is implied.
```

### Browser-only

```text
The page can be observed only while a person deliberately opens it.
The Extension may capture one bounded observation.
The Node cannot claim that it can reproduce the page independently.
No background browser automation exists in rev0067.
```

These labels are consequences, not quality scores.
A browser-only source is not defective merely because it requires human presence.
A Node-reproducible source is not automatically trustworthy merely because it can be fetched unattended.

## Human task

The ordinary sender-side task begins in the Node:

```text
Sources
  → choose Use signed-in browser on one watched page
  → read the exact watched page and expiry
  → create one ten-minute browser request
  → copy the request
```

The ordinary Extension task is:

```text
Add
  → paste the capture request
  → review the exact Node and watched page
  → open the exact page in the active tab
  → choose Capture this open page
  → inspect candidate rendered sections
  → inspect matched and ignored examples
  → choose what counts as an update
  → acknowledge a changed watched section when necessary
  → send one capture
  → read one durable result
```

The person should not need to understand:

```text
isolated execution worlds
structured clone versus JSON serialization
canonical request fingerprints
Origin binding internals
SQLite transaction journals
idempotency table layouts
DOM traversal implementation
selector probe order
artifact canonicalization
hash encoding
```

Those details remain available in advanced receipt evidence, CLI JSON, tests, and protocol documentation.

## Questions the Node request must answer

Before the request is copied, the Node must answer:

```text
Which watched page is involved?
How long is the request valid?
Will the Node receive the browser login?
Will the Extension send the entire page?
Will a recurring schedule be created?
Will the Node contact the watched site?
Can the person cancel the request?
```

The delivered answers are:

```text
One existing watched-page source is named.
The request expires after ten minutes.
Cookies, credentials, storage, and browser authority remain in the browser.
Only one bounded text-and-link extraction can be sent.
No recurring schedule is created.
The Node makes zero watched-site requests for the capture.
The request can be closed or allowed to expire.
```

## Questions the Extension review must answer

Before any page extraction, the Extension must answer:

```text
Which Node created this request?
Which exact page must be open?
When does the request expire?
What recipe is currently saved?
Does review itself read the page?
Does the Node receive the browser login?
What browser authority may be requested next?
Can the person leave without sending anything?
```

The delivered review says:

```text
Use the rendered page without sending the login.
The exact watched page must be open.
The request expiry is visible.
The current recipe is summarized.
Review has not read the page.
The Node receives no cookie, credential, storage, or screenshot.
Exact page authority may be requested only from Capture this open page.
Cancel without sending anything remains visible.
```

## Request creation boundary

The local Node administrator creates a request through:

```http
POST /api/v1/capture-invitations
Authorization: Bearer NODE-ADMIN-CAPABILITY
Origin: http://127.0.0.1:PORT
Content-Type: application/json
```

The request body names only:

```json
{"sourceId":"EXISTING-WATCHED-PAGE-ID"}
```

The Node refuses:

```text
unknown source IDs
archived sources
feed sources
arbitrary page addresses
non-Node-owned stores
unsupported source recipes
unexpected request fields
foreign Origins
missing administrator capability
```

The created request binds:

```text
one watched-page source ID
one exact watched-page address
one current declarative recipe
one current portable-library digest
one current library revision
one allowed action
one preview digest
one artifact byte limit
one expiry
one one-use capability
```

The human invitation is:

```text
http://127.0.0.1:PORT/#capture=CAPABILITY
```

The capability appears after the fragment marker.
It is not sent in the browser's initial request for the URL.
The Extension later submits it explicitly to the reviewed loopback origin.

## Extension Origin binding

The first valid capture review binds the invitation to one exact Origin:

```text
chrome-extension://EXTENSION-ID
moz-extension://RUNTIME-ID
```

The Node then refuses:

```text
a webpage Origin
a null Origin
a second Extension Origin
a missing Origin
a malformed Origin
an Origin that changes between review and commit
```

This binding does not authenticate a human being.
It prevents another Extension Origin from taking over the same in-memory request after first review.

## Browser authority boundary

Capture uses two separate optional browser authority decisions.

### Loopback authority

The Extension requests authority for the exact literal-loopback Node only from the visible review action.
It does not gain generic localhost browsing through startup behavior or scanning.

### Watched-page authority

The Extension requests authority for the exact watched-page origin only from **Capture this open page**.
It does not read the tab during invitation review.

The Extension records whether ProgRSS newly obtained each permission.
When it newly obtained authority, it attempts to release it after:

```text
failed review
Cancel before extraction
Cancel after extraction
successful capture completion
leaving the Add flow
```

Previously existing authority is preserved.
Permission cleanup is best-effort and visible through tested state rather than implied by prose alone.

## Exact-page boundary

The active top-frame address must match the reviewed watched-page address.
The comparison ignores only the fragment.
It retains the significance of:

```text
scheme
hostname
port
path
query
```

Capture refuses:

```text
a different site
a different path
a different query
a background tab
a browser-internal page
a file URL
a data URL
a page without an active top frame
a page that changed between review and extraction
```

ProgRSS does not search open tabs for a plausible match.
It does not activate a hidden tab.
It does not drive login or consent controls.

## Fixed extractor boundary

The Extension injects one packaged function through the browser scripting API.
The execution target is frame `0` only.
The default isolated extension world is retained.

The extractor is not supplied by:

```text
the watched page
the Node
a source list
a curator note
a remote recipe
a publication artifact
a WebRTC peer
```

It does not use `eval`, dynamic function construction, inline remote code, or a selector script from the watched page.

The extractor may inspect rendered DOM text and links to construct bounded evidence.
It does not serialize the DOM.

## Candidate sections

Capture can offer up to three candidate sections.

### Saved watched section

```text
Uses the existing declarative recipe.
Appears only when the current rendered page matches it.
Preserves the current comparison boundary.
Does not require a recipe-change acknowledgement.
```

### Repeated entries on this page

```text
Uses one fixed packaged probe over recognizable repeated structures.
Returns bounded title, link, and summary rows.
Shows up to three matched examples.
Can become a new declarative repeated-card recipe.
Requires acknowledgement when different from the saved recipe.
```

### Primary readable text

```text
Uses the page's primary rendered text region.
Returns bounded normalized text.
Shows a compact example.
Can become a new declarative region recipe.
Requires acknowledgement when different from the saved recipe.
```

A candidate is not a silent recommendation.
The interface uses ordinary radio controls and no candidate is selected merely because it is broader.

## Matched and ignored evidence

Before submission, the person can see:

```text
what matched now
up to three bounded matched examples
one ignored navigation, footer, aside, or account-control example when available
the match count
the current saved recipe
the consequence of selecting a different recipe
```

The ignored example serves two purposes:

```text
It shows that ProgRSS did not simply send every visible string.
It gives the person evidence that navigation or account furniture is outside the update boundary.
```

Ignored evidence is still bounded text.
It does not include form values, account identifiers gathered from storage, or raw element markup.

## Artifact schema

The submitted artifact is:

```text
progrss.browser-capture.v1
```

Its exact top-level fields are:

```text
schema
capturedAt
page
source
recipe
capture
examples
provenance
```

Unknown top-level or nested fields are refused.
The Node validates exact known structures rather than accepting an open-ended browser dump.

## Artifact bounds

The Node enforces:

```text
at most 300,000 canonical JSON bytes
at most 200 repeated records
at most three matched examples
bounded titles
bounded summaries
bounded text
bounded selector strings
bounded URLs
bounded language and page-title values
capture age no more than fifteen minutes
future skew no more than two minutes
HTTP or HTTPS page and record links only
```

Boolean fields must be booleans.
Integer fields must be integers rather than booleans or numeric strings.
Objects, arrays, strings, and nulls must occur only where the schema permits them.

## Provenance

The provenance record states that the artifact came from:

```text
one rendered browser DOM
the active top frame
the isolated extension world
one fixed packaged extractor
one identified ProgRSS Extension version
no arbitrary shared code
```

Provenance does not prove that page content is true.
It does not prove that the person was the account owner.
It does not authenticate the website beyond the browser's normal loaded-page and TLS behavior.
It tells the recipient library how the evidence was obtained and what authority was deliberately excluded.

## What never crosses into the Node

Capture does not send:

```text
Cookie headers
cookie values
Authorization headers
passwords
session tokens
browser localStorage
browser sessionStorage
IndexedDB records
service-worker caches
form values
hidden input values
raw HTML
DOM nodes
page source
screenshots
canvas pixels
image bytes
stylesheet bytes
script bytes
subresource bodies
browser history
open-tab lists
bookmark data
Extension permission grants
Extension bearer capabilities
Node administrator capability
summary-only pairing capability
Exchange capability
```

The Node cannot reuse the artifact to impersonate the browser session.

## Recipe-change boundary

When the chosen candidate differs from the current declarative recipe, the interface requires:

```text
Use this new watched section
```

The acknowledgement is part of the operation request fingerprint.
It cannot be added after an idempotency key already identified different reviewed content.

Accepted recipe change behavior is:

```text
replace the declarative extraction recipe
increment the recipe version
clear the old page snapshot
clear old shape-health and held-change state
save the new observation as a baseline
produce no invented historical alert
retain older local item history
```

A recipe change does not transfer browser authority into the source record.

## Commit contract

The Extension submits:

```http
POST /api/v1/captures
Authorization: Bearer CAPTURE-CAPABILITY
Origin: chrome-extension://…
If-Match: "REVIEWED-LIBRARY-SHA256"
Idempotency-Key: RANDOM-URL-SAFE-VALUE
Content-Type: application/json
```

The body names:

```text
operationType = capture-rendered-page-once
sourceId
action = capture-now | enable-and-capture
previewDigest
recipeChangeAcknowledged
artifact
```

The Node refuses missing or weak preconditions.
It refuses a stale library digest.
It refuses a different source or action.
It refuses a changed preview.
It refuses a changed recipe without acknowledgement.
It refuses an acknowledgement that does not match the request fingerprint on replay.

## Durable intent ordering

Unlike Witness network acquisition, Capture validates the entire supplied artifact and acknowledgement before recording resumable intent.
That ordering is deliberate.
A malformed browser artifact should not leave a durable job that looks resumable.

After validation, the Node records the exact request fingerprint and commits through the existing single-writer transaction boundary.

## Safe retry

A completed exact retry returns the original receipt with:

```text
replayed = true
```

It performs:

```text
zero second page extraction requirements
zero second Node-side site requests
zero second library mutation
zero second receipt insertion
```

A reused idempotency key with different artifact bytes, acknowledgement, source, action, preview, or base digest is refused.

## Atomic result

One transaction records:

```text
new complete portable library
new portable-library digest
new library revision
acquisition receipt
completed acquisition-job state
request replay fingerprint
```

Injected transaction failures must not leave:

```text
a changed portable library without its receipt
a receipt claiming an uncommitted library
a completed job without the matching result
a replay record that points at missing evidence
```

## Page-watch result behavior

Capture reuses Witness's page-watch interpretation.
Possible healthy results include:

### Baseline saved

```text
The Node had no comparable observation for this recipe.
The new bounded observation becomes the baseline.
No article is invented.
```

### No meaningful change

```text
The capture succeeded.
The watched section did not cross its meaningful-change threshold.
This is different from a failed capture.
```

### Changed

```text
The bounded watched section changed meaningfully.
The Node retains Before/Now evidence.
A bounded item may be added according to the existing page-watch model.
```

### Checking again

```text
The observed change is held for stability confirmation.
ProgRSS does not emit a misleading update yet.
```

### Needs repair

```text
The watched section or page shape no longer gives trustworthy evidence.
ProgRSS asks for review rather than fabricating an update.
```

## Ordinary result hierarchy

The ordinary receipt card leads with:

```text
outcome
items added
Node site requests
library revision
schedule
```

For Capture, the normal values include:

```text
Node site requests: 0
Schedule: None created
```

Advanced receipt evidence may show:

```text
operation and receipt IDs
base and resulting library digests
preview digest
artifact digest
capture timestamp
page title
Extension version
recipe digest
recipe-change state
matched and ignored examples
replay state
zero-network assertion
```

The ordinary user is not required to inspect advanced evidence to understand whether the Node contacted the site or created a schedule.

## Pairing remains separate

Summary-only pairing still cannot:

```text
create a capture request
read a capture request
submit a capture artifact
read watched-page addresses
read acquisition receipts
read retained items
change a library
fetch a source
schedule a source
publish
merge
```

Capture is a distinct, expiring, action-specific contract.
Transport success does not enlarge the pairing capability.

## Exchange remains separate

Exchange still handles bounded source-list and updates-feed handoff.
A Capture artifact is not a shareable source-list extension.
A recipient of a source list receives the declarative watched-page recipe, not the sender's login or captured private page observation.

Private captured observations remain in the local portable library and are excluded from public publication according to the existing privacy boundary.

## No scheduler yet

Capture does not create recurring browser work.
The Node does not wake the Extension.
The Extension does not keep a signed-in page open.
The Extension does not poll tabs.
The Node does not ask the browser to refresh a private page in the background.

The word **Active** continues to mean that a source is not paused.
It does not mean that a browser-only source has an automatic schedule.

## Why arbitrary shared JavaScript remains out

Custom shared JavaScript would combine:

```text
remote code execution
browser-session authority
opaque extraction behavior
poor portability
hard-to-review network side effects
unbounded data access
fragile page coupling
```

ProgRSS instead keeps the portable default:

```text
declarative
bounded
inspectable
versioned
example-backed
safe to refuse
```

Future extensibility may add more bounded declarative recipe forms.
It should not normalize a curator-supplied browser program as the everyday path.

## Accessibility and cognitive hierarchy

The Capture flow uses one question per step:

```text
Do you want to review this request?
Which page must be open?
What part counts as an update?
Does the watched section itself change?
What happened?
```

Candidate sections use native radio controls.
The changed-recipe boundary uses a separate checkbox.
The final send action remains disabled until the consequential acknowledgement is complete.

Status updates use a polite live region rather than forcibly moving focus.
Matched and ignored examples remain in document order.
Advanced evidence remains collapsed by default.

Forced-colors removes decorative gradients and shadows while preserving boundaries and focus.
The light theme remains available.
The dark fluorescent default remains restrained rather than animated.

## Human acceptance questions

An unfamiliar participant should be able to answer:

```text
Did reviewing the request read the page?
Which exact page must be open?
What browser authority stays in the browser?
What text and links will be sent?
Why is one example ignored?
Does choosing a new watched section change future comparisons?
Why does a new watched section create a fresh baseline?
How many requests did the Node make to the watched site?
Was a schedule created?
Can the Node now sign in as the participant?
```

Expected answers are:

```text
No page was read during invitation review.
The exact reviewed watched-page address must be active.
Cookies, credentials, storage, and browser permissions stay in the browser.
Only one bounded reviewed text-and-link extraction is sent.
Ignored evidence shows what is outside the update boundary.
A new watched section changes the declarative recipe.
The new section has no honest old comparison, so it begins with a baseline.
The Node made zero watched-site requests.
No schedule was created.
The Node cannot reuse the artifact to sign in.
```

## Wrong turns that require product changes

Change wording or hierarchy when participants:

```text
think invitation review already captured the page
think the Node receives their login
think the Extension sends the whole tab
think the ignored example is also retained as watched content
choose the broadest candidate because it looks recommended
cannot tell a recipe change from one observation
think a fresh baseline is a detected update
think Active means Scheduled
think pairing grants ambient capture authority
think zero Node requests means no browser page was loaded
cannot find Cancel
cannot explain why the exact address is required
```

Do not answer those wrong turns by adding:

```text
silent tab scanning
automatic region choice
cookie transfer
arbitrary shared JavaScript
browser remote control
a central account
engagement ranking
an opaque recommendation model
```

## CLI and protocol surface

Capture is primarily a Node and Extension path.
The CLI continues to provide offline inspection of acquisition receipts and portable library exports.
The protocol documentation is:

```text
CLI/docs/NODE-CAPTURE.md
CLI/docs/NODE-CAPTURE-ACCEPTANCE.md
CLI/docs/NODE-ACQUISITION.md
CLI/docs/NODE-OPERATIONS.md
```

The Node HTTP schema is:

```text
progrss.node.capture.v1
```

The browser artifact schema is:

```text
progrss.browser-capture.v1
```

The provenance schema is:

```text
progrss.browser-capture-provenance.v1
```

The durable receipt continues to use the existing acquisition-receipt language.

## Implementation map

The principal Capture implementation lives in:

```text
CLI/acquisition.py
CLI/node_server.py
CLI/node_web/index.html
CLI/node_web/app.js
CLI/node_web/app.css
Extension/background.js
Extension/sidepanel/app.js
Extension/sidepanel/app.css
Extension/tests/browser_smoke.py
Extension/tests/test_static.py
CLI/tests/test_acquisition.py
CLI/tests/test_node_server.py
CLI/tests/node_browser_smoke.py
```

The generated Firefox sibling is synchronized from canonical Extension sources.

## Release boundary

```text
Extension version:             0.67.0
CLI version:                   0.67.0
Revision:                      rev0067
Codename:                      Capture
Vault schema:                  17, unchanged
Private-backup schema:         progrss.private.v1
Node-store schema:             progrss.node-store.v2, unchanged
Capture invitation schema:     progrss.node.capture.v1
Capture artifact schema:       progrss.browser-capture.v1
Capture provenance schema:     progrss.browser-capture-provenance.v1
Required Extension host access:none
Optional loopback access:      visible review action only
Optional page access:          visible capture action only
Capture Node site requests:    zero
Capture recurring schedule:    none
Capture cookie transfer:       none
Capture raw HTML transfer:     none
Capture screenshot transfer:   none
Arbitrary shared code:         none
Paired Extension writes:       none
Default public bind:           none
Account:                       none
Telemetry:                     none
WebRTC dependency:             none
```

## Prioritized checklist

### P0 — completed in Capture

- [x] One ten-minute request for one existing watched-page source.
- [x] Local administrator creates the request.
- [x] First valid review binds one exact Extension Origin.
- [x] No localhost scan, LAN discovery, startup Node contact, or tab scan.
- [x] Exact active top-frame page required.
- [x] Optional exact page authority requested from the visible capture action.
- [x] Fixed packaged isolated-world extractor.
- [x] No code received from the page, Node, source list, or curator.
- [x] At most three bounded candidate sections.
- [x] Saved watched-section candidate when it still matches.
- [x] Repeated-entry proposal when a bounded repeated structure is found.
- [x] Primary readable-text proposal.
- [x] Matched examples shown before submission.
- [x] Ignored example shown before submission when available.
- [x] One selected candidate per capture.
- [x] Separate acknowledgement for a changed watched-section recipe.
- [x] Fresh baseline after a changed recipe.
- [x] Strict known-field artifact validation.
- [x] Exact source and page binding.
- [x] Capture-time and future-skew bounds.
- [x] 300 KB canonical artifact bound.
- [x] 200 repeated-record bound.
- [x] Three matched-example bound.
- [x] JSON-safe text-and-link evidence only.
- [x] No cookies, credentials, storage, forms, raw HTML, screenshots, scripts, or browser capabilities.
- [x] Validation before resumable durable intent.
- [x] Exact base-library and preview preconditions.
- [x] Exact completed retry returns the original receipt.
- [x] Same-key different-content reuse refused.
- [x] Atomic portable library, receipt, job, and replay commit.
- [x] Existing page-watch health, stability, baseline, Before/Now, and repair logic reused.
- [x] Zero Node-side watched-site requests.
- [x] No recurring schedule.
- [x] Summary-only pairing remains read-only.
- [x] Exchange remains artifact-scoped and separate.
- [x] Dark fluorescent ordinary interface retained.
- [x] Light mode retained.
- [x] Forced-colors cleanup retained.
- [x] Advanced evidence remains secondary.
- [x] Chromium and generated Firefox runtimes share the bounded data model.
- [x] Capture human and assistive-technology protocols packaged without claiming execution.

### P0 — next: real Capture acceptance

- [ ] Run the exact Node request task with unfamiliar administrators.
- [ ] Run the exact Extension capture task with unfamiliar recipients.
- [ ] Ask participants whether review already read the page.
- [ ] Ask participants what remains in the browser.
- [ ] Ask participants to choose among candidate sections without coaching.
- [ ] Ask participants to identify matched and ignored evidence.
- [ ] Ask participants to explain a changed watched-section acknowledgement.
- [ ] Ask participants to explain a fresh baseline.
- [ ] Ask participants whether the Node contacted the watched site.
- [ ] Ask participants whether a schedule was created.
- [ ] Simulate a lost response and observe retry understanding.
- [ ] Test cancel and permission cleanup at every stage.
- [ ] Run native current Chromium on an unmanaged host.
- [ ] Run native current Firefox.
- [ ] Run native Firefox ESR.
- [ ] Run keyboard-only acceptance.
- [ ] Run a real screen-reader session.
- [ ] Run Braille where available.
- [ ] Run voice-control acceptance.
- [ ] Run switch-style sequential navigation.
- [ ] Run 200% and 400% zoom.
- [ ] Run forced-colors acceptance.
- [ ] Run interruption and cognitive-fatigue acceptance.
- [ ] Change wording and hierarchy from observed wrong turns.

### P0 — next technical boundary: Cadence

A scheduler must reuse Witness rather than invent a second acquisition implementation.
It must not schedule browser-only captures.

- [ ] Explicit schedule-enable operation for one reviewed Node-reproducible source.
- [ ] Pause means zero requests.
- [ ] Visible next-check time.
- [ ] Per-source minimum interval.
- [ ] Per-host request budget.
- [ ] Global concurrency budget.
- [ ] Jitter.
- [ ] Exponential backoff.
- [ ] `Retry-After` handling.
- [ ] Restart recovery.
- [ ] Clock-change behavior.
- [ ] Manual-check priority rules.
- [ ] Metered-network and offline behavior.
- [ ] Durable receipt for every scheduled attempt.
- [ ] Clear distinction between enabled and scheduled.
- [ ] Clear distinction between Node-reproducible and browser-assisted.
- [ ] No schedule created by import, pairing, Exchange, manual Witness, or Capture.
- [ ] No hidden browser wakeup.
- [ ] No background tab control.
- [ ] No browser cookie transfer.

### P1 — page-watch recipe quality

- [ ] Add more bounded declarative repeated-record patterns.
- [ ] Show why one candidate is stable or fragile.
- [ ] Preserve bounded structural witnesses across captures.
- [ ] Improve dynamic-page readiness explanation.
- [ ] Test pagination.
- [ ] Test localization.
- [ ] Test consent overlays.
- [ ] Test partial authentication.
- [ ] Test virtualized lists.
- [ ] Test pages whose meaningful text is inside open shadow roots.
- [ ] Test pages whose content changes after deliberate user interaction.
- [ ] Keep cross-origin frames out unless a separate explicit contract exists.
- [ ] Keep closed shadow roots out.
- [ ] Keep arbitrary shared JavaScript out.
- [ ] Keep browser authority local.

### P1 — organization and re-finding

- [ ] Measure whether people can find retained material after one week.
- [ ] Keep folders as human-curated, shareable routes.
- [ ] Add private many-to-many labels.
- [ ] Add explicit saved-query views.
- [ ] Preserve Unfiled as a legitimate state.
- [ ] Suggest duplicate sources without silently collapsing different recipes.
- [ ] Suggest stale sources with reversible evidence.
- [ ] Suggest route splits without automatic taxonomy.
- [ ] Keep recommendations transparent and reversible.
- [ ] No engagement ranking.
- [ ] No opaque automatic taxonomy.

### P1 — Source Notes recovery

The historical handoff describes rev0059 Source Notes, but its release archive is not part of the current recoverable lineage.

- [ ] Recover the actual rev0059 artifact if it still exists.
- [ ] Otherwise independently reimplement the bounded folder/source-scoped note behavior.
- [ ] Keep notes plain text and short.
- [ ] Keep notes scoped to one folder/source relationship.
- [ ] Keep notes out of acquisition identity.
- [ ] Cover notes with native publication integrity.
- [ ] Preserve notes in Branch excerpts.
- [ ] Omit notes from OPML with explicit reporting.
- [ ] Include note conflicts in Confluence review.
- [ ] Test curator wording versus locally computed consequences with unfamiliar people.
- [ ] Do not expand into comments, reactions, profiles, or a notification stream.

### P1 — later typed operations

Each new operation needs its own preview, stale-base rule, replay contract, receipt, recovery evidence, and acceptance task.

- [ ] Pause one source.
- [ ] Enable one source without checking it.
- [ ] Add one reviewed feed.
- [ ] Save one reviewed page-watch recipe.
- [ ] Apply one reviewed Confluence merge.
- [ ] Adopt one complete reviewed route.
- [ ] Mark one retained item read.
- [ ] Change one saved state.
- [ ] Never introduce generic JSON Patch.
- [ ] Never introduce arbitrary filesystem writes.

### P2 — remote Nodes

- [ ] Explicit remote mode separate from loopback.
- [ ] TLS.
- [ ] Persistent Node identity.
- [ ] Hostname allowlist.
- [ ] Request, artifact, and rate bounds.
- [ ] Expiring invitations.
- [ ] Persistent revocation evidence.
- [ ] Public publication routes separated from private APIs.
- [ ] Manual artifact retrieval before continuous synchronization.
- [ ] Reverse-proxy acceptance.
- [ ] Self-hosting documentation.
- [ ] No default public bind.
- [ ] No silent LAN discovery.
- [ ] No UPnP port opening.
- [ ] No basic flow that says only “enter an IP address.”

### Lab — WebRTC courier

- [ ] Transfer exactly one already reviewed artifact.
- [ ] Use signed and bounded offer/answer metadata informed by Vibechat.
- [ ] Make signaling visible.
- [ ] Make STUN use visible.
- [ ] Make TURN use visible.
- [ ] Compare copy/paste, QR, relay, HTTPS, and WebRTC friction.
- [ ] Refuse replay.
- [ ] Refuse identity mismatch.
- [ ] Refuse digest mismatch.
- [ ] Refuse partial completion.
- [ ] Discard the session after transfer.
- [ ] Never require WebRTC for reading, publication, or synchronization.

## Verification

The final archive is built twice with fixed member ordering, timestamps, compression, and Unix modes. The two build candidates must be byte-identical before release. The sealed archive is then extracted into a clean directory; every delivered regular file and executable mode must match before the principal suites are replayed from those extracted bytes.

```text
CLI
PASS  9/9   browser-capture and public-acquisition boundary tests
PASS  9/9   Node-store migration, transaction, interruption, and replay tests
PASS 17/17  Node HTTP, pairing, Exchange, merge, operation, Witness, and Capture tests
PASS 46/46  direct CLI library tests
PASS 29/29  publication, integrity, signature, continuity, and merge tests
PASS 26/26  launcher cases in separately bounded processes
PASS 136    total distinct Python test cases across those lanes
PASS        CLI doctor

Extension
PASS 57/57  structural and static checks
PASS        Chromium background harness
PASS        Branch / Contents / Signpost / Edition core harness
PASS        generated Firefox background harness
PASS        acquisition and redirect harness
PASS        vault conflict and failed-write harness
PASS        rendered everyday reader, including Capture review, choice, and receipt
PASS        rendered Advanced Workbench

Node UI
PASS        one-use Capture request
PASS        retained Witness review and receipt
PASS        retained branch-adoption review and receipt
PASS        retained Confluence review
PASS        retained Exchange review and handoff
PASS        retained summary-only pairing
PASS        dark and light Node themes

Syntax and delivered files
PASS 61 JavaScript files parsed
PASS 18 Python files compiled
PASS 44 JSON files parsed
PASS  2 POSIX shell files parsed
PASS deterministic two-build comparison
PASS ZIP CRC verification
PASS unique-member verification
PASS safe relative paths
PASS no symlinks
PASS no nested archives
PASS no caches or Python bytecode
PASS clean-extraction byte comparison
PASS clean-extraction executable-mode comparison
PASS principal-suite replay from clean extraction
```

The monolithic launcher wrapper is not used as release evidence because descendant output handles can remain open after completed assertions. Every one of its twenty-six constituent cases is executed separately under an explicit process bound.

## Native and human boundary

```text
SKIP installed Chromium Extension
     exit 77 — managed policy blocks unpacked installation

SKIP installed real-network Chromium lane
     exit 77 — managed policy blocks unpacked installation

SKIP native Chromium Node-loopback navigation
     managed policy returned ERR_BLOCKED_BY_ADMINISTRATOR

SKIP current Firefox
     executable absent

SKIP Firefox ESR
     executable absent

NOT YET RUN
     unfamiliar-human Capture comprehension sessions
     signed-in real-site Capture sessions
     real screen-reader sessions
     Braille, voice-control, and switch sessions
```

These are skips and unexecuted acceptance tasks, not passes. Rendered smoke tests use the shipped HTML, CSS, and JavaScript with controlled browser APIs and same-origin interception where the managed host prevents native installation or loopback navigation.

## Release evidence

```text
Archive:             ProgRSS-rev0067-2026.10.20-Capture.zip
Version:             0.67.0
Revision:            rev0067
Codename:            Capture
SHA-256:             recorded in the sealed sidecar and release report
Members:             finalized from the deterministic archive
Regular files:       finalized from the deterministic archive
Directory entries:   finalized from the deterministic archive
Uncompressed bytes:  finalized from the deterministic archive
ZIP bytes:           finalized from the deterministic archive
BOOTSTRAPROSE:        9,000+ lines
```

The release archive opens directly to:

```text
BOOTSTRAPROSE.md
CLI/
Extension/
```

The external SHA-256 sidecar and release report are computed only after the archive bytes are sealed; the archive does not attempt an impossible self-referential embedded digest.

---

# BOOTSTRAPROSE — ProgRSS rev0065 “Witness”

**Release:** rev0065 · **Product version:** 0.65.0 · **Vault schema:** 17 (unchanged)
**Node-store schema:** `progrss.node-store.v2`
**Release date:** 2026-10-20
**Release maxim:** **Review once. Check once. Keep the evidence.**

## `/run` interpretation

When this file is the active bootstrap, continue from the delivered rev0065 tree.
Do not reconstruct the project from rev0058, a prose-only transcript, or a guessed rev0059 implementation.
The delivered source tree is the current authority.

The current release lineage is:

```text
Nightstand   dark fluorescent basic reader + first loopback Node
Handshake   explicit summary-only Extension ↔ Node pairing
Exchange    one handoff with Follow / Add route / Take branch
Confluence  human-first three-way later-copy review
Receipt     one transactional Node-owned branch-adoption write
Witness     one reviewed feed or page-watch check with durable evidence
```

Treat these as current product truths:

```text
The everyday Extension reader remains the default product.
Dark fluorescent presentation remains the default.
Light presentation remains an explicit persisted option.
Forced-colors removes decorative fluorescent treatment.
Advanced Workbench remains secondary.
The Extension remains useful without a Node.
The CLI remains useful without a browser.
The Node remains the CLI's local web-server mode.
The Node binds only to literal loopback in this release.
An exported private backup may still be opened read-only.
A Node-owned library is a local SQLite single-writer boundary.
The portable complete library remains progrss.private.v1 JSON.
SQLite is not a sharing or publication format.
Pairing remains summary-only and revocable.
Pairing does not reveal source addresses, retained items, or receipts.
Pairing does not grant acquisition or mutation authority.
Exchange remains artifact-scoped rather than synchronization.
Confluence remains three-way review.
Receipt's branch-adoption operation remains available.
Witness adds one explicit existing-source check.
Witness does not create a recurring schedule.
A source check is local-administrator-only.
A source check begins with an offline preview.
A source check can target only one source already in the library.
A paused source requires a separate Enable and check once acknowledgement.
A check performs at most one initial GET plus five same-origin redirect GETs.
A cross-origin redirect stops before the other site is contacted.
Credential-bearing source URLs are refused.
Non-public destination addresses are refused before connection.
Mixed public and non-public DNS results are refused.
The chosen exact validated IP address is used for the connection.
HTTPS still verifies the original hostname through SNI and certificate checks.
Environment proxy settings are not inherited.
Browser profiles, cookies, credentials, and permission stores are not read.
Page JavaScript is not executed.
Compressed responses are refused.
Response bytes and total time are bounded.
ETag and Last-Modified validators are retained when valid.
304 means a successful unchanged check, not a failure.
Feed parsing reuses the existing bounded RSS, Atom, and JSON Feed parser.
Page checking reuses the existing declarative page-watch recipe.
Page shape drift may be held rather than emitted as a misleading update.
The first successful page capture can become a baseline.
A later meaningful change can produce Before/Now evidence.
Malformed content, movement, refusal, and network failure remain distinct outcomes.
A durable acquisition intent is recorded before DNS.
An exact interrupted attempt may be resumed after restart.
An exact completed retry returns the original receipt without another request.
An idempotency key reused with different reviewed content is refused.
The portable library and acquisition receipt commit atomically.
A failed atomic commit does not leave a receipt claiming an uncommitted library.
A rev0064 Node store upgrades in place to schema v2.
That migration does not rewrite the portable library bytes, digest, or revision.
There is no generic fetch-by-URL endpoint.
There is no generic JSON Patch endpoint.
There is no arbitrary filesystem write endpoint.
There is no recurring scheduler in rev0065.
There is no startup source request.
There is no localhost scan, LAN discovery, or default public bind.
There is no account, telemetry service, central directory, or follower graph.
There is no WebRTC dependency.
```

## Why Witness exists

Receipt proved that the Node can make one reviewed, stale-safe, retry-safe, atomic change.
The next mission-critical question is whether the Node can obtain new material without becoming an ambient crawler.

Witness answers with the smallest useful acquisition boundary:

```text
one existing source
one offline review
one explicit action
one bounded public request chain
one parser or page recipe
one portable library result
one durable receipt
zero recurring schedule
```

The release is not trying to solve all background retrieval.
It is establishing the evidence, outcome vocabulary, and safety model that any later scheduler must reuse.

The release therefore prioritizes:

```text
manual before automatic
existing source before arbitrary URL
preview before network
action-specific authority before generic fetch
public network only
same-origin redirect continuity
conditional retrieval
bounded bytes and time
honest failure categories
atomic result plus receipt
safe retry after an uncertain response
human consequences before protocol detail
```

## Human task

The ordinary Node task is:

```text
Sources
  → choose Review check on one source
  → read what site will be contacted
  → read whether the source is paused
  → read whether validators are available
  → read whether the check uses feed parsing or a page recipe
  → for a paused source, acknowledge Enable this paused source
  → choose Check once now or Enable and check once
  → wait for one bounded result
  → read the plain-language outcome
  → optionally open Advanced receipt evidence
```

The person should not need to understand:

```text
DNS rebinding terminology
socket address families
TLS SNI
HTTP cache validator grammar
SQLite WAL frames
canonical request fingerprints
idempotency table layouts
parser implementation details
raw page selectors
internal source IDs
```

Those details remain available in advanced evidence, JSON, and documentation.

## Questions the ordinary review must answer

Before any network request, the interface must answer:

```text
Which source will be checked?
Is it a feed or a watched page?
Which site will receive the request?
Is the source currently paused?
Will this action enable it?
Does enabling it create a schedule?
How many redirects may be followed?
Can a redirect move silently to another site?
Will cookies or browser credentials be sent?
Will browser JavaScript run?
What happens when the site is local or private?
What happens when the page shape no longer matches?
Will a receipt survive a lost response?
```

The delivered answers are:

```text
Exactly one existing source is named.
The source type and site hostname are shown.
Paused state is shown before the action.
A paused source requires a checked acknowledgement.
Enabling does not create a schedule in rev0065.
At most five same-origin redirects are followed.
A cross-origin move stops before contact and becomes a reviewed movement outcome.
No browser cookie, credential, profile, or permission store is used.
No page JavaScript is executed.
Non-public resolved addresses are refused before connection.
Page shape drift can be held or marked for repair rather than emitted as content.
The durable intent and exact request fingerprint support safe recovery and replay.
```

## Default interface hierarchy

The Node's ordinary navigation remains:

```text
Today
Sources
Curate
```

Witness lives in **Sources**.
It does not become an Advanced Workbench-only feature.
It also does not turn the Sources screen into a request inspector.

The ordinary source card shows bounded human evidence:

```text
source title
Feed or Watched page
site hostname
Active or Paused
last outcome, when present
last successful time, when present
last problem, when present
Review check
```

The offline review shows:

```text
source title
source type
site hostname
paused or active state
one-request consequence
same-site movement boundary
durable-evidence consequence
page recipe summary when applicable
whether ETag or Last-Modified evidence exists
```

The completed result leads with:

```text
plain-language outcome
items added
HTTP request count
new library revision
```

Advanced evidence may then show:

```text
operation ID
receipt ID
base library digest
preview digest
resulting library digest
HTTP status
redirect chain
resolved addresses
blocked addresses
conditional validator use
request duration
attempt count
whether a retry was replayed or resumed
```

## Theme and accessibility

The delivered aesthetic remains:

```text
near-black default canvas
fluorescent cyan primary action and focus treatment
restrained magenta and lime accents
fine gradient lines
no constant decorative animation
light theme as an explicit option
forced-colors treatment that removes decorative gradients
```

Witness must preserve:

```text
visible focus
keyboard-operable disclosures
44 CSS-pixel primary targets where practical
narrow-screen reflow
200–400% text resilience
status text that does not require a focus jump
plain-language result before advanced details
no outcome communicated by color alone
```

Automated rendering remains regression evidence.
It is not a substitute for real screen-reader, Braille, voice-control, switch, fatigue, zoom, or forced-colors sessions.

## Node modes

The same server command can open two different modes:

```sh
./progrss node serve PRIVATE-BACKUP.json --open
./progrss node serve READING-ROOM.sqlite3 --open
```

The first is:

```text
read-only exported backup
```

The second is:

```text
Node-owned transactional library
```

Witness acquisition is available only in Node-owned mode.
A read-only exported backup cannot create acquisition previews, contact sources, or record receipts.

The UI and status API must continue to name the active mode.

## Node-owned store schemas

Current store schema:

```text
progrss.node-store.v2
```

Portable library schema:

```text
progrss.private.v1
```

Receipt's reviewed operation schemas remain:

```text
progrss.node.operation.v1
progrss.node.operation-preview.v1
progrss.node.operation-receipt.v1
progrss.node.operation-result.v1
```

Witness adds:

```text
progrss.node.acquisition-job.v1
progrss.node.acquisition-preview.v1
progrss.node.acquisition-receipt.v1
progrss.node.acquisition-result.v1
```

The store keeps:

```text
one current complete portable library document
its SHA-256 digest
its monotonically increasing local revision
its update time
the original imported backup bytes
reviewed branch-operation receipts
pre-operation branch snapshots
acquisition intents
acquisition receipts
```

SQLite remains an implementation boundary.
Exports remain ordinary validated `progrss.private.v1` JSON.

## rev0064 store migration

Opening a valid `progrss.node-store.v1` store performs one internal migration to v2.

The migration:

```text
runs inside one explicit SQLite transaction
creates acquisition_jobs
creates acquisition_receipts
creates bounded indexes
updates metadata schema to progrss.node-store.v2
updates PRAGMA user_version to 2
retains the current portable library BLOB byte-for-byte
retains the current portable library SHA-256
retains the current local revision
retains original import bytes
retains branch-operation receipts
retains pre-operation snapshots
```

The migration does not:

```text
fetch any source
change any source enabled state
reparse retained items
rewrite the private backup
create an acquisition receipt
create a schedule
contact the Extension
```

Read-only CLI inspection reports whether that one-time internal migration occurred.
It distinguishes internal schema writes from portable-library writes.

## Acquisition preview

The administrator requests a preview for one source ID already present in the current library.
The request does not accept an arbitrary URL.

The preview:

```text
is offline
is bound to the exact current library digest
is bound to the exact source ID
is bound to check-now or enable-and-check
has a short expiry
has a canonical preview digest
is held only in process memory
performs no DNS lookup
performs no network request
writes no library state
```

The preview refuses:

```text
read-only backup mode
missing sources
archived sources
unsupported source types
invalid source URLs
source state that changed after review
```

For an active source, the action is:

```text
check-now
```

For a paused source, the action is:

```text
enable-and-check
```

The paused-source action is explicit because it changes future eligibility even though rev0065 creates no scheduler.

## Commit preconditions

The acquisition commit requires:

```text
administrator bearer capability
same-origin request
exact preview token
exact preview digest
strong If-Match for the reviewed base library digest
random URL-safe Idempotency-Key
exact source ID
exact reviewed action
```

The Node refuses:

```text
missing If-Match
weak If-Match
stale base library
missing Idempotency-Key
short or malformed operation key
preview expiry
preview mismatch
source mismatch
action mismatch
writer mismatch
idempotency-key reuse with different reviewed content
```

## Durable started intent

Before DNS, the Node records:

```text
operation ID
request fingerprint
source ID
base library digest
preview digest
state=started
attempt count
started time
```

This is deliberate.
A process can die after the network request but before the response reaches the browser.
Without a durable started intent, a retry could not distinguish a new operation from an uncertain prior attempt.

An exact retry after restart:

```text
finds the started intent
verifies the same request fingerprint
verifies the same source
verifies the same base digest
verifies the same preview digest
increments the attempt count
resumes the bounded check
```

An exact completed retry:

```text
returns the stored acquisition receipt
sets replayed=true at the API boundary
performs no DNS lookup
performs no new HTTP request
performs no second library write
```

A different request using the same operation ID is refused.

## Destination validation

Witness accepts only HTTP or HTTPS source addresses already stored in the library.

It refuses:

```text
non-HTTP schemes
credential-bearing URLs
invalid ports
invalid hostnames
missing hostnames
fragments as request identity
```

For each request hop it:

```text
resolves the hostname once
collects a bounded set of unique IP addresses
canonicalizes each IP address
rejects the entire answer set if any address is non-public
chooses one exact validated public address
connects to that exact address
retains the original Host header
retains the original HTTPS server name for TLS verification
```

The blocked classes include addresses that the runtime does not classify as globally routable, including:

```text
loopback
private
link-local
unspecified
multicast
documentation
benchmark
carrier-grade NAT
other special-purpose ranges
```

This defense is intentionally conservative.
A hostname that resolves to both public and non-public destinations is refused rather than randomly selecting the public member.

## Request boundary

One check may perform:

```text
one initial GET
up to five same-origin redirect GETs
```

The request sends bounded headers:

```text
User-Agent
Accept
Accept-Encoding: identity
Host
If-None-Match when a valid retained ETag exists
If-Modified-Since when a valid retained Last-Modified exists
Connection: close
```

The request does not send:

```text
Cookie
Authorization
Proxy-Authorization
Referer
browser profile state
browser extension origin
Node administrator capability
pairing capability
Exchange capability
```

The client does not inherit:

```text
HTTP_PROXY
HTTPS_PROXY
ALL_PROXY
NO_PROXY
```

The Node does not execute:

```text
page JavaScript
service workers
embedded frames
remote images
stylesheets
subresource requests
forms
```

## Redirect boundary

A redirect may continue only when the next URL has the same:

```text
scheme
hostname
effective port
```

A redirect chain is bounded by:

```text
five redirects
loop detection
URL validation at every hop
fresh public-address validation at every hop
```

A cross-origin redirect becomes:

```text
outcome=moved
```

The destination site is not contacted.
The receipt retains the observed redirect evidence.
The existing source address is not silently rewritten.

## Response boundary

The check uses:

```text
20-second total per-request timeout boundary
2 MB maximum response body
identity encoding only
bounded header values
```

It refuses or classifies:

```text
compressed response encodings
oversized bodies
redirects without Location
redirect loops
excess redirects
TLS failures
timeouts
network failures
malformed feed or page content
```

The raw response body is not stored in the acquisition receipt.
Only the bounded library result and evidence needed to explain the check are retained.

## Conditional retrieval

When the source has valid retained validators, Witness may send:

```text
If-None-Match
If-Modified-Since
```

A valid 304 response means:

```text
request succeeded
source was unchanged
validators remain available
last successful time advances
no item is added
```

Invalid validator strings are not emitted as headers.
A validator from one source is never reused for another source.

## Feed check

A feed source reuses the established bounded parser for:

```text
RSS
Atom
JSON Feed
```

The feed path:

```text
parses only the bounded response body
preserves same-origin declared feed identity rules
reuses existing stable item identity
avoids duplicate retained items
retains configured text policy
preserves feed-supplied language where available
updates validators
records the number of new retained items
```

The check does not:

```text
load article pages
load remote images
execute embedded HTML
request enclosures
follow links inside item bodies
contact the source more than the bounded request chain
```

A successful feed outcome is:

```text
changed     one or more new retained items
unchanged   valid feed, no new retained item or 304
```

A parse failure is:

```text
malformed
```

## Page-watch check

A page source reuses the existing declarative recipe.

The preview can show:

```text
region mode or repeated-card mode
bounded selector description
bounded title selector when present
bounded link selector when present
change threshold
ignore-numbers choice
```

The Node retrieves only the main page response.
It does not render a browser.
It does not execute JavaScript.

The check then reuses:

```text
static HTML parsing
readable-body fallback
repeated-card extraction
bounded structural witnesses
shape-health assessment
held-change logic
Before/Now change generation
```

The first successful capture may produce:

```text
baseline
```

A later stable meaningful difference may produce:

```text
changed
```

A stable no-difference capture may produce:

```text
unchanged
```

A suspicious structural difference may produce:

```text
watch-pending
```

A confirmed recipe failure may produce:

```text
needs-repair
```

The result must not invent an update merely because navigation, consent, advertising, or template furniture changed.

## Outcome vocabulary

The ordinary result vocabulary is:

```text
changed
unchanged
baseline
watch-pending
needs-repair
malformed
moved
refused
temporary-failure
permanent-failure
throttled
```

These outcomes are intentionally distinct.

Examples:

```text
304 response                          → unchanged
valid feed with no new stable item   → unchanged
first valid page capture             → baseline
stable page text changed             → changed
page structure changed suspiciously  → watch-pending
recipe cannot match after review     → needs-repair
cross-site redirect observed         → moved
non-public destination               → refused
invalid feed body                    → malformed
TLS timeout                          → temporary-failure
HTTP 404 or 410                      → permanent-failure
HTTP 429                             → throttled
```

The UI should not reduce all non-success states to “error.”

## Paused source semantics

A paused source causes no automatic request.

The administrator may explicitly choose:

```text
Enable this paused source
Enable and check once
```

That action:

```text
sets enabled=true in the resulting portable library
performs exactly one reviewed check
creates no recurring schedule in rev0065
commits the enable state even when the request outcome is a bounded failure
records the outcome in the durable receipt
```

This behavior must be explained before the action.
The release does not pretend that “enabled” and “scheduled” are identical.
A later scheduler must define them explicitly.

## Atomic commit

After the bounded check, one SQLite transaction records:

```text
new complete portable library bytes
new portable library SHA-256
next local revision
acquisition receipt
completed acquisition job state
receipt ID
```

The transaction is all-or-nothing.

Failure injection covers:

```text
before the transaction
between library replacement and receipt insertion
after receipt insertion but before commit
```

A rollback must leave:

```text
old portable library intact
old digest intact
old revision intact
no completed receipt claiming a new library
started intent available for exact recovery when appropriate
```

## Acquisition receipt

A receipt contains bounded evidence such as:

```text
schema
operation ID
receipt ID
source ID
start time
commit time
attempt count
base library digest
preview digest
resulting library digest
resulting revision
outcome
summary
request type
source type
source title
source host
network request count
timeout limit
response byte limit
same-origin redirect limit
cross-origin policy
whether a schedule was created
whether this was a resumed attempt
HTTP status
redirect chain
resolved addresses
blocked addresses
request duration
conditional-validator evidence
browser-cookie effect=false
browser-credential effect=false
browser-profile effect=false
arbitrary-script effect=false
automatic-schedule effect=false
```

The receipt does not contain:

```text
Node administrator bearer capability
pairing capability
Exchange capability
browser cookie jar
browser history
browser permissions
private signing key
complete response body
arbitrary environment variables
```

## Offline receipt inspection

List durable acquisition evidence:

```sh
./progrss node acquisitions READING-ROOM.sqlite3
```

Machine-readable form:

```sh
./progrss node acquisitions READING-ROOM.sqlite3 --json
```

The command:

```text
performs no DNS lookup
performs no network request
performs no source check
performs no portable-library write
lists completed receipts
lists durable jobs
identifies interrupted started jobs
reports whether an internal v1→v2 migration occurred
```

The result schema is:

```text
progrss.node.acquisition-result.v1
```

## Extension boundary

The Extension remains independently useful.
It still performs its own existing user-visible, per-site acquisition under browser permission boundaries.

A paired Extension receives only the previously delivered bounded summary:

```text
Node session identity
selected library filename
library digest
aggregate counts
Node-owned or exported-backup mode
```

A paired Extension does not receive:

```text
source addresses
retained item bodies
page-watch selectors
HTTP validators
acquisition jobs
acquisition receipts
administrator capability
preview token
write capability
fetch capability
```

A paired Extension cannot call:

```text
/api/v1/acquisition-previews
/api/v1/acquisitions
```

Witness adds no required Extension permission.
There is no startup Node request, localhost scan, automatic reconnect, or background synchronization.

## Sharing boundary

Witness does not alter Exchange.

The sharing choices remain:

```text
Follow updates
Add the complete route
Take one branch
```

A source-list or branch import still starts new sources paused.
Witness does not silently check them after import.
The recipient or Node administrator must later choose an explicit enable/check action.

A durable acquisition receipt remains private Node evidence.
It is not automatically placed into a shared source list or recent-updates feed.

## Later-copy boundary

Witness does not alter Confluence.

A later copy still compares:

```text
last accepted curator copy
current local copy
incoming curator copy
```

Acquisition-recipe changes remain consequential.
They still require explicit review.
A changed recipe can create or reuse a paused source while retaining earlier history.
Witness does not automatically check that changed recipe.

## Branch-adoption boundary

Receipt's branch operation remains the only other Node mutation.

It still:

```text
selects one reviewed populated nested branch
reuses exact existing recipes
adds new recipes paused
creates local folder closure
contacts no listed site
retains a pre-operation snapshot
creates a durable operation receipt
supports exact replay
```

Witness's acquisition transaction is separate from branch adoption.
There is no compound “adopt and immediately crawl” operation.

## Source Notes boundary

The historical conversation described rev0059 Source Notes, including a short folder/source-scoped reason.
The actual rev0059 release archive remains outside the recoverable delivered lineage used for rev0060–rev0065.
Do not claim that complete implementation merely from transcript prose.
Recover it or independently reimplement and verify it before treating it as delivered.

## Security invariants

The following invariants are release blockers:

```text
No arbitrary URL in the acquisition commit body.
No non-public destination connection.
No mixed public/non-public DNS answer acceptance.
No environment proxy inheritance.
No browser credential or cookie use.
No cross-origin redirect follow.
No compressed response processing.
No unbounded response body.
No page JavaScript execution.
No generic write endpoint.
No paired-Extension acquisition authority.
No silent paused-source enablement.
No automatic schedule creation.
No portable-library commit without a matching acquisition receipt.
No completed receipt without the matching portable-library commit.
No duplicate request on exact completed replay.
No different request accepted under a reused idempotency key.
No stale-base commit.
No rev0064 migration that rewrites portable library bytes.
```

## Operational commands

Initialize a Node-owned library:

```sh
./progrss node init PRIVATE-BACKUP.json --output READING-ROOM.sqlite3
```

Serve it:

```sh
./progrss node serve READING-ROOM.sqlite3 --open
```

Export the current portable library:

```sh
./progrss node export READING-ROOM.sqlite3 --output CURRENT-LIBRARY.json
```

List branch-operation receipts:

```sh
./progrss node receipts READING-ROOM.sqlite3
```

List acquisition evidence:

```sh
./progrss node acquisitions READING-ROOM.sqlite3
```

Export one retained pre-operation branch snapshot:

```sh
./progrss node snapshot READING-ROOM.sqlite3 SNAPSHOT-ID --output BEFORE.json
```

The acquisition itself is initiated through the local Node administrator GUI in rev0065.
There is no command-line fetch shortcut that bypasses its reviewed preview.

## Human acceptance protocol

The packaged Witness protocol asks an unfamiliar participant to:

```text
Find one active feed.
Review a one-off check without starting it.
Explain which site would receive the request.
Explain whether browser cookies are sent.
Explain whether a recurring schedule is created.
Run the check once.
Read whether material changed or not.
Find advanced receipt evidence.
Find one paused watched page.
Review enable-and-check.
Explain what enabling changes.
Explain what enabling does not change in rev0065.
Create a first page baseline.
Explain why a baseline is not a new article.
Distinguish temporary failure from no change.
Distinguish movement from automatic address replacement.
Pause or leave the source in a known state.
```

Observe whether the participant understands:

```text
Review check
Check once now
Enable this paused source
Enable and check once
No recurring schedule
Baseline saved
No new material
Check failed
Moved to another site
Needs repair
Advanced receipt evidence
```

Record wrong turns such as:

```text
believing review already contacted the site
believing enable created a schedule
believing baseline means a new item
believing 304 means failure
believing moved means the URL was silently changed
believing receipt means automatic rollback
believing paired Extension can trigger the check
looking for selector syntax in the ordinary result
```

Wrong turns should change wording, hierarchy, and focus behavior before adding more automation.

## Native-browser acceptance

Still required:

```text
installed current Chromium on an unmanaged host
installed current Firefox
installed Firefox ESR
real browser-owned optional-permission prompts
native loopback navigation
restart and service-worker unloading
screen-reader use
Braille use
voice control
switch-style operation
200–400% zoom
forced-colors use
fatigue and interruption use
```

A generated Firefox sibling and background harness are not native Firefox acceptance.
A rendered Chromium page with controlled same-origin API interception is not native loopback acceptance.

## Verification requirements

The sealed release must show:

```text
all Python unit suites pass
all 26 launcher-level command cases pass in bounded independent processes
all Extension static checks pass
Chromium background harness passes
shared-folder core harness passes
generated Firefox background harness passes
acquisition harness passes
vault conflict harness passes
rendered Extension everyday reader passes
rendered Advanced Workbench passes
rendered Node Witness flow passes
Python compilation passes
JavaScript syntax checks pass
POSIX shell syntax checks pass
JSON parsing passes
CLI doctor passes
deterministic archive rebuild passes
CRC verification passes
unique archive-member verification passes
safe relative paths pass
symlink refusal passes
nested-archive absence passes
cache and bytecode absence passes
clean-extraction byte and executable-mode comparison passes
principal suites replay from clean extraction
```

Final exact counts are recorded in the release report and final user-facing release note.

## Prioritized next work

### P0 — real Witness acceptance

```text
Run unfamiliar-administrator sessions.
Run keyboard-only sessions.
Run screen-reader sessions.
Run high-zoom and forced-colors sessions.
Simulate a lost HTTP response and observe retry understanding.
Simulate temporary failure and observe whether it is confused with unchanged.
Simulate cross-site movement and observe whether it is confused with automatic follow.
Revise wording and hierarchy from observed wrong turns.
```

### P0 — browser-assisted page capture

The Node intentionally does not execute page JavaScript or inherit browser credentials.
Some important pages therefore require an explicit browser handoff.

The next design work should answer:

```text
How does a person choose “use what my browser can see”?
Which exact rendered region is exported?
How is the evidence bounded?
How are cookies kept inside the browser?
How is the result handed to the Node without transferring session authority?
How is replay or stale capture refused?
How is a browser-only recipe represented honestly in a shared source list?
How does the recipient learn that their browser session may differ?
```

Do not normalize arbitrary shared JavaScript.
Prefer a bounded capture artifact containing:

```text
source identity
page address
capture time
selected region description
plain extracted records
bounded structural witness
content digest
browser-produced provenance statement
no cookie material
no executable code
```

### P1 — scheduler contract

A scheduler may follow only after manual acceptance.
It must reuse Witness rather than bypass it.

Required design points:

```text
explicit per-source schedule enablement
global request budget
per-host request budget
minimum intervals
jitter
backoff
Retry-After handling
pause means no request
offline mode
battery-aware or device-aware policy where appropriate
bounded concurrency
single-writer queue
receipt for every attempt
visible next-check time
visible last-check outcome
manual check priority rules
shutdown and restart recovery
clock-change behavior
```

### P1 — page-watch authoring

Mission-critical work remains:

```text
Ask “What part of this page counts as an update?”
Let the person point at a repeated region.
Show matched examples.
Show ignored examples.
Show title and destination extraction.
Show whether the Node can reproduce it without a browser.
Preserve stability witnesses.
Detect template drift.
Offer bounded repair.
Keep recipes declarative and portable.
```

### P1 — organization and re-finding

```text
Test whether people can find material again after a week.
Keep folders as human-curated shareable routes.
Add private many-to-many labels.
Add explicit saved-query views.
Preserve Unfiled as a legitimate resting state.
Suggest duplicates without silently merging distinct recipes.
Suggest stale sources with reversible evidence.
Avoid engagement ranking.
Avoid opaque automatic taxonomy.
```

### P1 — later typed operations

Only add operations with their own preview, receipt, stale-base rule, replay rule, and acceptance task.
Candidates include:

```text
pause one source
enable one source without checking
add one explicitly reviewed feed
save one reviewed page-watch recipe
apply one reviewed later-copy merge
adopt one complete reviewed route
mark one item read
change one saved state
```

Do not expose arbitrary JSON Patch.

### P2 — remote Nodes

```text
explicit remote mode separate from loopback
TLS
persistent server identity
hostname allowlist
request, artifact, and rate bounds
expiring invitations
persistent revocation evidence
public publication routes separated from private APIs
manual artifact retrieval before continuous synchronization
reverse-proxy acceptance
self-hosted deployment documentation
no default public bind
no silent LAN discovery
no UPnP port opening
```

### Lab — WebRTC courier

```text
transfer exactly one already reviewed artifact
signed bounded offer and answer metadata
make signaling visible
make STUN and TURN visible
compare copy/paste, QR, relay, HTTPS, and WebRTC friction
refuse replay
refuse identity mismatch
refuse digest mismatch
refuse partial completion
discard the session after transfer
never require WebRTC for normal reading, publication, or synchronization
```

## Release boundary

```text
Extension version:            0.65.0
CLI / Node version:           0.65.0
Revision:                     rev0065
Codename:                     Witness
Vault schema:                 17, unchanged
Private backup schema:        progrss.private.v1
Node-store schema:            progrss.node-store.v2
Acquisition preview:          progrss.node.acquisition-preview.v1
Acquisition job:              progrss.node.acquisition-job.v1
Acquisition receipt:          progrss.node.acquisition-receipt.v1
Acquisition result:           progrss.node.acquisition-result.v1
Required Extension access:    unchanged
New manifest permissions:     none
Paired Extension writes:      none
Paired Extension acquisition: none
Automatic scheduler:          none
Automatic import:             none
Automatic publication poll:   none
Automatic update apply:       none
Default public bind:          none
Account or cloud service:     none
Telemetry:                    none
Private-key export:           none
```

Chromium Extension permissions remain:

```text
activeTab
alarms
offscreen
scripting
sidePanel
storage
webRequest
```

Firefox Extension permissions remain:

```text
activeTab
alarms
scripting
storage
webRequest
```

## Historical bootstrap follows

The remainder of this file preserves prior release rationale and contracts for continuity.
When a historical statement conflicts with the rev0065 section above, the rev0065 section is authoritative.

---

# Historical bootstrap — rev0064 “Receipt”


**Release:** rev0064 · **Product version:** 0.64.0 · **Vault schema:** 17 (unchanged)
**Release date:** 2026-10-19
**Release maxim:** **Review once. Commit once. Replay safely.**

## `/run` interpretation

When this file is the active bootstrap, continue from the delivered rev0064 tree.
Do not reconstruct the project from the old chat transcript, rev0058, or a prose-only account of rev0059.
The delivered tree already includes:

```text
Nightstand   dark fluorescent basic reader + first loopback Node
Handshake   explicit summary-only Extension ↔ Node pairing
Exchange    one handoff with Follow / Add route / Take branch
Confluence  three-way later-copy review
Receipt     one transactional Node-owned branch-adoption write
```

Treat these as current product truths:

```text
The everyday reader is the default product.
Dark fluorescent presentation is the default.
Light presentation remains an explicit persisted option.
Advanced Workbench stays secondary.
The Extension remains independently useful without a Node.
The CLI remains independently useful without a browser.
The Node is the CLI's local web-server mode.
An exported private backup may still be opened read-only.
A Node-owned library is a local SQLite transaction boundary.
The portable private-library format remains progrss.private.v1 JSON.
SQLite is not a sharing, publication, or interchange format.
Pairing is summary-only, revocable, and process-session-bound.
Pairing never gains Node write authority in rev0064.
Exchange is artifact-only and does not pair or synchronize.
Confluence is three-way review.
The Node's Confluence endpoint remains review-only.
Receipt adds exactly one Node write operation.
That operation is local-administrator-only.
That operation adopts one already reviewed populated nested branch.
Complete-route Node adoption is not writable in this release.
New sources created by the operation begin paused.
Exact existing acquisition recipes are reused.
No listed source is contacted during review or commit.
Every successful commit has one durable receipt.
Every successful commit has one pre-operation snapshot.
An exact retry returns the original receipt without another write.
A reused operation key with different reviewed content is refused.
A stale base library is refused.
There is no generic JSON Patch endpoint.
There is no arbitrary filesystem write endpoint.
There is no automatic synchronization.
There is no startup localhost request or port scan.
There is no LAN discovery or default public bind.
There is no account, telemetry service, or central follower graph.
```

## Why Receipt exists

Confluence made disagreement understandable, but understanding alone did not give the Node a safe way to own durable state.
Receipt establishes the smallest credible writer:

```text
one explicit local library
one explicit native source list
one explicit populated branch
one exact preview
one acknowledged consequence set
one base-library digest
one idempotency key
one atomic commit
one durable receipt
one pre-operation snapshot
```

The point is not to make the Node broadly writable.
The point is to prove that one consequential action can be:

```text
reviewed
bounded
stale-safe
retry-safe
crash-safe
recoverable
inspectable
human-readable
portable after export
```

## Human task

The ordinary Node task is:

```text
Curate
  → Adopt one branch into this Node
  → Choose one native ProgRSS source-list file
  → Choose one populated nested branch
  → Review what will be reused and what will be added paused
  → Confirm that no listed site will be contacted
  → Confirm that a before-snapshot will be retained
  → Adopt this branch once
  → Read the durable receipt
```

The person does not need to understand:

```text
SQLite pages
WAL frames
canonical request fingerprints
HTTP conditional request grammar
transaction isolation vocabulary
internal source IDs
raw collection graph records
```

Those details remain available through documentation, JSON, and advanced evidence.
The default surface leads with consequences.

## What humans need to know before the write

The review must answer:

```text
What branch am I taking?
Which sources are inside it?
Which sites do those sources belong to?
Which sources already exist here?
Which sources will be new?
Will the new sources contact sites immediately?
Will this create a continuing relationship to the parent publication?
Will reading history or browser permissions be imported?
Can I recover the prior library if I regret the change?
What happens if I click twice or the response is lost?
```

The delivered answers are:

```text
Only the chosen populated nested branch is adopted.
Exact existing acquisition recipes are reused.
New sources begin paused.
No listed source is contacted during review or commit.
The result is an independent local branch.
No parent future-copy relationship is created.
No read/unread state is imported.
No saved state is imported.
No retained article body is imported.
No browser permission is imported.
A pre-operation private-backup snapshot is stored.
An exact retry returns the original receipt without another mutation.
```

## Node-owned library

Create one Node-owned library from one explicit private backup:

```sh
cd CLI
./progrss node init PRIVATE-BACKUP.json --output READING-ROOM.sqlite3
```

`node init`:

```text
requires one regular local progrss.private.v1 file
refuses symlinks
refuses an existing output path
validates the complete bounded backup
preserves the exact imported bytes
creates revision 1
creates a unique store ID
uses SQLite WAL mode
uses synchronous FULL
runs an integrity check
performs no DNS lookup
performs no network request
reads no browser profile
reads no browser permission store
```

Serve the Node-owned library:

```sh
./progrss node serve READING-ROOM.sqlite3 --open
```

The same command may still open an exported JSON backup read-only:

```sh
./progrss node serve PRIVATE-BACKUP.json --open
```

The UI must say which mode is active:

```text
Exported backup opened read-only
Node-owned transactional library
```

Do not imply that merely serving a JSON backup creates a writer.

## Portable representation

The current complete library remains one bounded:

```text
progrss.private.v1
```

The Node store keeps that complete JSON document as the portable canonical library value.
Its SQLite tables add local transaction evidence around the portable document.

Export the current portable library:

```sh
./progrss node export READING-ROOM.sqlite3 \
  --output CURRENT-PRIVATE-BACKUP.json
```

Export is:

```text
explicit
new-file-only
no-overwrite
offline
browser-profile-independent
permission-store-independent
```

## Store schema

The store schema is:

```text
progrss.node-store.v1
```

The initial implementation contains:

```text
metadata
  schema
  storeId
  createdAt
  importSource
  importSha256

library
  complete progrss.private.v1 bytes
  SHA-256
  monotonic local revision
  updatedAt

imports
  exact original imported bytes
  source filename
  source digest
  import time

operation_snapshots
  one pre-operation complete private backup
  snapshot ID
  operation ID
  base digest
  creation time

operation_receipts
  operation ID
  operation type
  actor
  request fingerprint
  base digest
  preview digest
  result digest
  commit time
  complete receipt document
```

Do not expose these tables as a general database API.

## Delivered operation

The only writable operation type is:

```text
adopt-source-list-branch
```

The operation schema family is:

```text
progrss.node.branch-options.v1
progrss.node.operation-preview.v1
progrss.node.operation-request.v1
progrss.node.operation.v1
progrss.node.operation-receipt.v1
progrss.node.operation-result.v1
```

The selected branch must be:

```text
non-root
populated
part of a valid connected native ProgRSS source list
expressible through the existing simple-folder Branch model
```

The operation refuses:

```text
the publication root
an empty branch
an ambiguous selection
advanced collection algebra
an invalid or disconnected source list
an expired preview
a mismatched preview digest
a stale base library
an unsupported operation type
an invalid idempotency key
a missing or weak If-Match value
a foreign Origin
a missing administrator capability
```

## Review evidence

The preview reports:

```text
Node-owned library filename
library mode
base SHA-256
base revision
source-list title
source-list SHA-256
native content digest
signature state
curator wording when supplied
selected branch ID
selected branch path
parent title
independent-excerpt state
source title
source type
site hostname
folder route
new-paused / reused / duplicate-in-list consequence
new-source count
reused-source count
folder count
feed count
watched-page count
resulting library SHA-256
resulting revision
network: false
writes: false
commitAvailable: true
```

The preview itself does not mutate the library.

## HTTP write contract

The local administrator endpoint is:

```text
POST /api/v1/operations
```

It requires:

```text
same exact loopback Origin
administrator bearer capability
Content-Type: application/json
operationType: adopt-source-list-branch
one unexpired previewToken
one exact previewDigest
If-Match: "<reviewed-base-library-sha256>"
Idempotency-Key: <16–200 URL-safe characters>
```

`If-Match` is used as a stale-review precondition.
The strong quoted value must identify the exact base library reviewed by the person.

The header named `Idempotency-Key` follows the semantics being developed by the IETF HTTPAPI working group.
The relevant document is still an expired Internet-Draft, not a finished RFC.
Do not claim general standards conformance.
Document and test the exact ProgRSS contract instead.

## Request fingerprint

The durable request fingerprint covers:

```text
operation schema
operation type
actor
reviewed base-library digest
hash of the preview capability
exact preview digest
```

It does not store the bearer capability itself.

The rules are:

```text
same key + same request fingerprint
  → return the original receipt
  → replayed: true
  → no additional write

same key + different request fingerprint
  → refuse with conflict
  → do not reinterpret the key
  → do not write
```

The durable receipt lookup occurs before requiring the in-memory preview to still exist.
That permits a lost-response retry after the preview was consumed or the Node restarted.

## Atomic transaction

One SQLite transaction records:

```text
the pre-operation complete backup snapshot
the new complete portable library
the new library digest
the new local revision
the durable operation receipt
the durable request fingerprint
```

The transaction uses a single writer.
A failure at any tested point rolls everything back:

```text
before BEGIN
immediately after snapshot insertion
after library replacement
immediately after receipt insertion
before COMMIT completes
```

Required invariant:

```text
There is never a committed new library without its receipt.
There is never a committed receipt for a library change that did not commit.
There is never a committed snapshot without the operation it protects.
```

## Operation receipt

A successful receipt contains:

```text
schema
receiptId
operationId
operationType
actor
committedAt
baseLibrarySha256
previewDigest
sourceListSha256
resultLibrarySha256
resultRevision
summary
selection
effects
rollbackEvidence
```

The effects state:

```text
newSourcesPaused: true
networkRequests: 0
listedSitesContacted: false
readingStateImported: false
browserAuthorityImported: false
```

Rollback evidence contains:

```text
snapshotId
base library SHA-256
automaticRollback: false
```

The snapshot is evidence and an exportable recovery input.
It is not an automatic undo button.

List receipts:

```sh
./progrss node receipts READING-ROOM.sqlite3
```

Export one pre-operation snapshot:

```sh
./progrss node snapshot READING-ROOM.sqlite3 SNAPSHOT_ID \
  --output BEFORE-OPERATION.json
```

## Response semantics

A first successful commit returns:

```text
HTTP 201
state: committed
replayed: false
writes: true
Idempotency-Replayed: false
ETag: resulting library SHA-256
```

An exact safe replay returns:

```text
HTTP 200
state: replayed
replayed: true
writes: false
Idempotency-Replayed: true
the exact original receipt
ETag: resulting library SHA-256
```

A stale reviewed base returns:

```text
HTTP 412
no write
```

A missing `If-Match` returns:

```text
HTTP 428
no write
```

A reused key with different reviewed content returns:

```text
HTTP 409
no write
```

## Extension boundary

The Extension may be paired with a Node that reports either:

```text
exported-backup
node-owned
```

The basic pairing UI names the mode.
When the mode is `node-owned`, it says plainly:

```text
The Node can perform its own locally reviewed operations,
but this pairing remains summary-only.
```

The pairing capability remains exactly:

```text
readLibrarySummary: true
readItems: false
readSourceAddresses: false
writeLibrary: false
fetchSources: false
publish: false
merge: false
nodeToNode: false
webrtcCourier: false
```

There is no Extension endpoint for:

```text
creating operation previews
submitting operation IDs
adopting branches into the Node
reading receipts
reading snapshots
exporting the Node library
```

That is intentional.
The first writer must be accepted as a local administrator workflow before any paired write is considered.

## Pairing remains separate from sharing

Keep these relationships distinct:

```text
Pairing
  process-lifetime Node session marker
  selected-library digest
  bounded aggregate counts
  no item or source-address access
  no write

Exchange
  one expiring reviewed artifact handoff
  Follow updates
  Add the complete route
  Take one branch
  no pairing
  no write

Public publication
  script-free static page
  native source list
  OPML fallback
  optional recent-updates feed
  no private API

Receipt operation
  one local administrator mutation
  one Node-owned library
  one reviewed branch
  one receipt
```

Do not merge these into one magical “Connect” action.

## Relationship to Branch

Receipt reuses the Branch boundary:

```text
selected folder
simple descendants
only sources referenced by the branch
exact existing recipes reused
new recipes paused
no parent future-copy address
no parent signing-key continuity relationship
no automatic parent update application
```

A branch derived from a signed parent is not separately signed.
The parent signature remains evidence about the exact parent document that was checked.

## Relationship to Exchange

Exchange remains the low-friction human sharing system:

```text
Follow updates
Add the complete route
Take one branch
```

Receipt does not replace Exchange.
It gives a Node owner one durable destination for a reviewed branch after a source-list file has already reached the local administrator.

A later release may connect an Exchange review to a Node operation preview, but only after the same explicit consequence and authority boundaries survive unfamiliar-person testing.

## Relationship to Confluence

Confluence remains review-only in the Node.
The CLI can still apply a later copy to a new backup file through its existing explicit offline command.

Receipt does not make later-copy merge writable through the Node.
There is no:

```text
apply merge endpoint
last-write-wins rule
server-wins rule
silent recipe replacement
automatic curator update
```

A future later-copy operation needs its own typed preview and receipt.

## Security boundary

The Node still binds only to:

```text
127.0.0.1
```

The administrator capability remains in the URL fragment before being staged into session storage and removed from the visible URL.
Every administrator API requires the bearer capability.

The server:

```text
refuses unexpected Host headers
refuses foreign Origin headers
requires same-origin POST
sends no CORS grant
sets a restrictive Content Security Policy
sets no-referrer policy
sets same-origin opener and resource policies
bounds request bodies
avoids capability-bearing request logs
```

Do not add:

```text
0.0.0.0 default bind
silent LAN discovery
mDNS pairing
UPnP port opening
ambient localhost scanning
unauthenticated library endpoints
cross-origin write grants
```

## Threat cases to retain in tests

```text
Missing administrator capability
Wrong administrator capability
Foreign Origin
Wrong Host header
Missing If-Match
Malformed If-Match
Stale If-Match
Missing Idempotency-Key
Malformed operation ID
Same key with different request
Expired preview
Wrong preview digest
Unsupported operation type
Read-only exported backup
Store changed after preview
Injected crash after snapshot
Injected crash after library write
Injected crash after receipt write
Lost response followed by exact retry
Restart followed by exact retry
Snapshot ID not found
Existing export path
Existing store path
Symlink input
Malformed private backup
Malformed source list
Root branch selected
Empty branch selected
Advanced collection selected
```

## Dark-mode GUI direction

Receipt keeps the Nightstand aesthetic:

```text
near-black base
fluorescent cyan primary actions
lime for successful durable state
magenta for consequential review boundaries
thin gradient lines
restrained glow
no constant animation
light mode retained
forced-colors strips decorative treatment
```

The operation panel may be vivid, but it must remain legible and calm.
Use color as reinforcement, never as the only state signal.

The ordinary hierarchy is:

```text
Today
Sources
Curate
```

Advanced facts remain disclosed, not front-loaded.

## Human wording under test

The words most likely to cause a wrong turn are:

```text
Node-owned library
Transactional library
Adopt one branch
Starts paused
Independent local branch
Commit once
Receipt
Before snapshot
Safe replay
Review expired
Library changed after review
```

Observe whether an unfamiliar person understands:

```text
that selecting a file does not import it
that preview does not write
that acknowledgement is not a network permission
that “starts paused” means no listed-site contact yet
that the branch is independent from the parent publication
that clicking twice does not create duplicate sources
that a receipt is evidence, not a social notification
that a snapshot is recoverable data, not automatic undo
that paired Extensions still cannot write
```

Change wording or hierarchy in response to observed wrong turns.
Do not answer confusion with more jargon or a larger wizard.

## Sites without RSS remain mission-critical

Receipt is not the acquisition release.
The next major Node capability should make public acquisition durable without weakening explicit authority.

Use this acquisition ladder:

```text
1. Existing RSS / Atom / JSON Feed
2. Feed advertised by the page
3. Safe known structured data
4. Repeated-page structure proposal
5. User-selected page region
6. Bounded declarative custom recipe
```

The future Node should:

```text
schedule public feeds
schedule publicly reproducible page watches
retain validators and bounded evidence
hold sharp structural changes before emitting misleading updates
propose repair rather than silently rewriting recipes
preserve Before/Now evidence
record acquisition receipts
```

The Extension should continue to handle:

```text
capture of the page the human is currently viewing
authenticated or browser-rendered views
deliberate browser-owned site authority
handoff when the Node cannot reproduce the view
```

Do not share browser credentials, cookies, or ambient page authority with the Node.
Do not normalize arbitrary shared JavaScript as the ordinary portable recipe format.

## Organization remains a product problem

Keep the organization model:

```text
Folders
  human-curated routes
  hierarchical
  potentially publishable

Local labels
  many-to-many
  private by default
  never silently published

Saved views
  explicit reusable queries
  no opaque engagement ranking

Unfiled
  legitimate resting state
  not a failure that forces immediate cleanup
```

Measure delayed re-finding:

```text
Can a person find the source again after a week?
Can they explain why it is in a route?
Can they tell personal organization from published curation?
Can they undo a mistaken placement?
```

## Source Notes status

The historical chatlog describes rev0059 Source Notes, including folder/source-scoped plain-text reasons.
The rev0059 artifact was not part of the supplied recoverable lineage used to build rev0060 onward.
Do not silently claim its complete implementation.

The product direction remains sound:

```text
short plain-text curator reason
scoped to one folder/source relationship
not part of acquisition identity
integrity-covered in native publication
omitted from OPML with an explicit report
three-way continuity treatment
```

Recover or reimplement it only through a separately tested release boundary.

## Remote Nodes

Remote mode remains future work.
It must be separate from loopback mode and require:

```text
TLS
persistent server identity
explicit hostname configuration
rate bounds
request-size bounds
persistent revocation evidence
public/private route separation
reverse-proxy acceptance
self-hosting documentation
manual artifact retrieval before continuous synchronization
```

Do not infer that a local administrator operation is safe to expose remotely merely because it is idempotent.

## WebRTC courier lab

WebRTC remains an optional courier experiment, not the foundation of synchronization.
The bounded lab task is:

```text
transfer one already reviewed source-list artifact
use signed offer/answer metadata
show signaling, STUN, and TURN use
verify sender/session identity evidence
verify exact bytes and digest
refuse replay and partial transfer
discard the session after completion
```

Compare its friction with:

```text
copy/paste
QR
ordinary HTTPS
relay-assisted delivery
```

Never require WebRTC for ordinary reading, publication, pairing, or Node operations.

## Current file map

```text
BOOTSTRAPROSE.md
  authoritative release handoff

CLI/progrss.py
  command-line entry point

CLI/node_store.py
  Node-owned SQLite transaction and receipt boundary

CLI/node_server.py
  loopback HTTP API and Node state

CLI/node_web/
  basic-first Node GUI

CLI/relay.py
  source-list, branch, publication, and later-copy logic

CLI/docs/NODE-OPERATIONS.md
  delivered write contract

CLI/docs/NODE-EXCHANGE.md
  three-door handoff contract

CLI/docs/NODE-MERGE-REVIEW.md
  read-only later-copy review contract

Extension/sidepanel/
  everyday reader

Extension/workbench/
  advanced interface

Extension/Firefox/
  generated Firefox sibling
```

## Release checklist — completed in Receipt

- [x] Node-owned SQLite library store.
- [x] Exact original import bytes preserved.
- [x] Portable current library remains `progrss.private.v1`.
- [x] `progrss node init`.
- [x] `progrss node export`.
- [x] `progrss node receipts`.
- [x] `progrss node snapshot`.
- [x] Read-only exported-backup Node mode retained.
- [x] Node-owned mode visibly distinguished.
- [x] One writable operation type only.
- [x] One populated nested branch only.
- [x] Root/complete-route write refused.
- [x] Exact existing sources reused.
- [x] New sources paused.
- [x] No listed-site contact during review or commit.
- [x] Exact base-library digest reviewed.
- [x] Exact preview digest reviewed.
- [x] Short-lived preview capability.
- [x] Strong `If-Match` precondition.
- [x] Idempotency key required.
- [x] Same-key/same-request safe replay.
- [x] Same-key/different-request refusal.
- [x] Stale-base refusal.
- [x] Single SQLite write transaction.
- [x] Durable operation receipt.
- [x] Durable pre-operation snapshot.
- [x] Injected-failure rollback tests.
- [x] Lost-response replay test.
- [x] Receipt list endpoint.
- [x] Snapshot download endpoint.
- [x] Node GUI review and acknowledgement.
- [x] Node GUI receipt and snapshot evidence.
- [x] No generic writable REST surface.
- [x] No generic JSON Patch.
- [x] No arbitrary filesystem write.
- [x] Paired Extension remains write-false.
- [x] Extension names Node-owned mode.
- [x] Dark default and light option retained.
- [x] Forced-colors treatment retained.
- [x] Generated Firefox sibling synchronized.

## P0 — next: durable acquisition

- [ ] Define Node acquisition job schema.
- [ ] Keep acquisition distinct from source creation.
- [ ] Schedule explicit public feed checks.
- [ ] Preserve ETag and Last-Modified validators.
- [ ] Bound response size and redirect depth.
- [ ] Stop before cross-site redirects unless reviewed.
- [ ] Record per-check outcome without notification spam.
- [ ] Keep new sources paused until the owner enables them.
- [ ] Add one visible “Enable and check” consequence review.
- [ ] Schedule publicly reproducible page-watch recipes.
- [ ] Preserve saved baseline and Before/Now evidence.
- [ ] Hold sharp shape changes for confirmation.
- [ ] Escalate repeated incompatible shapes to repair.
- [ ] Hand authenticated/rendered work back to the Extension.
- [ ] Never copy browser cookies into the Node.
- [ ] Test dynamic pages, pagination, localization, and consent walls.
- [ ] Add crash/retry receipts for acquisition jobs.
- [ ] Test delayed re-finding after updates arrive.

## P0 — parallel: unfamiliar-human acceptance

- [ ] Run the Node-owned versus exported-backup distinction with unfamiliar people.
- [ ] Ask participants what “starts paused” means.
- [ ] Ask whether preview contacted listed sites.
- [ ] Ask what happens after a double click or lost response.
- [ ] Ask what the receipt proves.
- [ ] Ask how to recover the previous library.
- [ ] Ask whether the Extension pairing can write.
- [ ] Test keyboard-only use.
- [ ] Test 200–400% zoom.
- [ ] Test forced colors.
- [ ] Test at least one real screen reader.
- [ ] Test voice control and switch-style navigation.
- [ ] Change wording and hierarchy in response to wrong turns.

## P1 — additional typed Node operations

Do not add a second writer until its exact human task is clear.
Potential candidates, in order of usefulness:

- [ ] Enable one already adopted paused source and perform one checked acquisition.
- [ ] Apply one fully reviewed later-copy merge.
- [ ] Add one reviewed feed or watched-page recipe paused.
- [ ] Mark one retained item read.
- [ ] Save or unsave one retained item.
- [ ] Move one source into one folder.

Every candidate needs:

- [ ] exact base digest;
- [ ] exact preview digest;
- [ ] short expiry;
- [ ] idempotency key;
- [ ] atomic commit;
- [ ] durable receipt;
- [ ] result digest;
- [ ] pre-operation recovery evidence;
- [ ] safe replay;
- [ ] stale-base refusal;
- [ ] unfamiliar-person acceptance task.

## P1 — sharing and curation

- [ ] Preserve Exchange’s three ordinary choices.
- [ ] Keep public publication separate from private API access.
- [ ] Add bounded QR only for a real reachable invitation.
- [ ] Add revocation evidence for longer-lived private invitations.
- [ ] Recover Source Notes through a separately verified release.
- [ ] Keep curator wording distinct from computed consequences.
- [ ] Keep OPML as the feed-only interoperability fallback.
- [ ] Run sender and recipient comprehension sessions separately.
- [ ] Prove import/export behavior in several ordinary feed readers.

## P1 — organization and re-finding

- [ ] Add private labels.
- [ ] Add saved query views.
- [ ] Keep Unfiled.
- [ ] Suggest duplicates without auto-merging.
- [ ] Suggest stale sources without auto-removal.
- [ ] Suggest route splits without auto-reorganization.
- [ ] Make every suggestion reversible.
- [ ] Avoid engagement ranking and opaque taxonomy.

## P2 — remote Node mode

- [ ] Separate executable mode and configuration.
- [ ] Require TLS.
- [ ] Persist server identity.
- [ ] Document reverse-proxy headers.
- [ ] Enforce hostname allowlists.
- [ ] Add rate and size bounds.
- [ ] Persist invitation and revocation evidence.
- [ ] Separate public artifacts from private administration.
- [ ] Start with manual artifact retrieval.
- [ ] Do not begin with continuous synchronization.
- [ ] Do not silently discover or expose the Node.

## Lab — WebRTC courier

- [ ] Reuse only bounded Vibechat patterns.
- [ ] Never reuse a permanent administrator secret.
- [ ] Sign offer/answer metadata.
- [ ] Transfer one reviewed artifact.
- [ ] Verify exact bytes and digest.
- [ ] Surface relay use.
- [ ] Refuse partial completion.
- [ ] Refuse replay.
- [ ] Destroy the session after transfer.
- [ ] Keep HTTPS and copy/paste as ordinary alternatives.

## Verification to run before sealing

Extension:

```text
static and structural tests
Chromium background harness
shared-folder / Branch / Contents / Signpost / Edition harness
Firefox generated-background harness
acquisition and redirect harness
vault conflict and failed-write harness
rendered everyday reader
rendered Advanced Workbench
```

CLI / Node:

```text
direct CLI library tests
source-list / publication / integrity / continuity / merge tests
Node store transaction and failure-injection tests
Node HTTP pairing / Exchange / merge / operation tests
launcher cases in independently bounded processes
Node browser smoke
CLI doctor
Python compilation
JavaScript syntax
POSIX shell syntax
JSON parse
```

Archive:

```text
two deterministic builds with identical bytes
ZIP CRC verification
unique-member verification
safe relative paths
no symlinks
no nested archives
no browser profiles
no managed-policy files
no private backups
no caches or bytecode
clean-extraction byte comparison
clean-extraction executable-mode comparison
principal-suite replay from clean extraction
```

## Completed automated verification for rev0064

The release tree passed:

```text
56/56  Extension structural and static checks
PASS   Chromium background harness
PASS   Branch / Contents / Signpost / Edition core harness
PASS   generated Firefox background harness
PASS   acquisition and redirect harness
PASS   shared-vault conflict and failed-write harness
PASS   rendered everyday reader
PASS   rendered Advanced Workbench

46/46  direct CLI library tests
29/29  source-list, publication, integrity, continuity, and merge tests
 6/6   Node-owned store and injected-transaction-failure tests
15/15  Node HTTP, pairing, Exchange, merge-review, operation, Origin, and revocation tests
26/26  launcher cases in independently bounded processes
PASS   rendered Node UI
PASS   CLI doctor

61      JavaScript syntax checks
16      Python compilation checks
 2      POSIX-shell syntax checks
44      JSON parses
```

The aggregate launcher wrapper is not release proof because descendant output handles can remain open after its assertions complete. Every one of its 26 cases was instead executed in a bounded case or bounded group and passed.

Native lanes are recorded separately as skips where the host cannot execute them.

## Honest native acceptance boundary

Do not convert a skip into a pass.

Current host limitations may include:

```text
managed Chromium policy blocking unpacked installation
managed Chromium policy blocking loopback navigation
no Firefox executable
no Firefox ESR executable
```

Automated DOM, keyboard, accessibility-tree, target-size, reflow, and forced-colors checks are regression evidence.
They are not completed human screen-reader, Braille, voice-control, switch-device, high-zoom, high-contrast, or cognitive-fatigue acceptance.

The Node browser screenshots may use the exact shipped HTML, CSS, and JavaScript with a controlled same-origin API interception when native loopback navigation is blocked.
Do not represent that as native network acceptance.

## Release boundary

```text
Extension version:             0.64.0
CLI version:                   0.64.0
Revision:                      rev0064
Codename:                      Receipt
Vault schema:                  17, unchanged
Private backup schema:         progrss.private.v1
Node store schema:             progrss.node-store.v1
Operation type:                adopt-source-list-branch
Operation receipt schema:      progrss.node.operation-receipt.v1
Required Extension host access:none
Optional Extension host access:runtime per origin
Node bind:                     literal 127.0.0.1
Automatic synchronization:    none
Paired Extension write:        none
Generic writable REST:         none
Account:                       none
Telemetry:                     none
```

## Next coherent release boundary

The next release should be **Acquisition Receipt** or an equivalently narrow durable-check release:

```text
one deliberately enabled source
one scheduled or explicit check
one bounded fetch
one acquisition result
one durable check receipt
one clear failure state
no browser credential transfer
no automatic recipe repair
```

Do not add remote synchronization merely because the Node can now commit locally.
Receipt proves one writer boundary.
The next work should prove durable information acquisition while preserving human authority.

---

# Previous bootstrap: ProgRSS rev0063 “Confluence”

# BOOTSTRAPROSE — ProgRSS rev0063 “Confluence”

**Release:** rev0063 · **Product version:** 0.63.0 · **Vault schema:** 17 (unchanged)
**Release date:** 2026-10-19
**Release maxim:** **Compare three copies. Ask only where they truly disagree.**
## /run interpretation

When this file is used as the active bootstrap, continue from the delivered rev0063 tree.
Do not reconstruct the project from memory, the old chat transcript, or the rev0058 baseline.
The current tree already includes Nightstand, Handshake, Exchange, and Confluence.

Treat these as the current product truths:

```text
The everyday reader is the default product.
Dark fluorescent presentation is the default.
Light presentation remains an explicit persisted option.
Advanced Workbench stays secondary.
The Extension remains independently useful without a Node.
The CLI remains independently useful without a browser.
The Node is the CLI's local web-server mode.
Pairing is summary-only.
Exchange is artifact-only.
Confluence is three-way review plus explicit local application.
The Node's Confluence endpoint is review-only.
No reviewed later copy is applied by the Node.
No listed source is contacted during merge review.
No true wording conflict has a preselected winner.
No acquisition-recipe change is treated as mere wording.
No new or changed acquisition recipe starts active.
No removed source loses its local history merely because a curator removed it.
No source-list signature is described as proof of identity or truth.
No branch excerpt is described as a signed continuation of the parent publication.
```

The active next boundary is:

```text
one narrowly typed reviewed Node write operation
with
base digest + preview digest + idempotency key + short expiry
+ atomic commit + durable receipt + safe replay
```

Do not skip directly to:

```text
generic writable REST
continuous bidirectional synchronization
server-wins or last-write-wins
ambient localhost or LAN discovery
public default binding
UPnP port opening
WebRTC as mandatory transport
remote code in shared page-watch recipes
opaque AI organization
an account requirement
```
## Release result

Confluence closes the largest semantic gap left by Exchange.
Exchange could carry a later source-list artifact to the recipient.
The continuity engine could conservatively preserve local state.
The ordinary person still could not clearly see whose change was whose.

Confluence now compares three distinct copies:

```text
last accepted curator baseline
current local recipient copy
incoming curator copy
```

It emits one bounded semantic review:

```text
progrss.shared-folder-merge-review.v1
```

The review separates:

```text
curator-only changes
recipient-only changes
matching changes on both sides
true divergent conflicts
additions
removals
acquisition-recipe changes
```

The Extension can apply the reviewed choices through its existing guarded local transaction.
The CLI can apply one global wording policy to a new output backup.
The Node can only show the comparison.
The Node has no apply endpoint in this release.
## Why three copies are required

A two-copy diff sees only “different.”
It cannot reliably answer whether the curator changed a value, the recipient changed it, or both changed it.

For one field, Confluence uses this conceptual table:

| Baseline | Local | Incoming | Classification | Ordinary consequence |
|---|---|---|---|---|
| A | A | B | Curator only | Use B |
| A | B | A | Yours only | Keep B |
| A | B | B | Both agree | Keep B |
| A | B | C | Need a choice | Ask |
| A | A | A | Unchanged | Say nothing |

This is conceptually similar to a three-way source-control merge using a common ancestor.
The UI does not ask readers to understand source-control terminology.
It asks only where the consequences actually require a human decision.
## Human-first language

The ordinary Extension and Node surfaces use these labels:

```text
Curator only
Yours only
Both agree
Need a choice
Added
Removed
Recipe changes
```

The ordinary Extension conflict controls use:

```text
Keep mine
Use curator's
```

The apply control uses:

```text
Apply reviewed choices
```

Raw protocol words remain under advanced evidence:

```text
baseline
local
incoming
remote ID
local ID
recipe fingerprint
content digest
signature result
signing-key fingerprint
publication identity
```

The UI does not lead with “ours,” “theirs,” “base,” “HEAD,” “patch,” or “merge strategy.”
The Node says **Review only** and explicitly states that it will not choose a winner or write the backup.
## Classification contract

### Curator only

**Meaning**
The incoming copy changed while the local copy still matches the accepted baseline.

**Consequence**
Apply the curator value during a reviewed update.

**Safety rule**
No human conflict choice is required.
### Yours only

**Meaning**
The local copy changed while the incoming copy still matches the accepted baseline.

**Consequence**
Keep the local value.

**Safety rule**
The curator copy does not erase local wording or placement.
### Both agree

**Meaning**
Local and incoming independently arrived at the same value.

**Consequence**
Keep the shared result.

**Safety rule**
No duplicate conflict or warning is created.
### Need a choice

**Meaning**
Local and incoming both changed from baseline and differ from one another.

**Consequence**
Require an explicit decision.

**Safety rule**
No radio button is preselected; application is blocked.
### Added

**Meaning**
The incoming publication includes a new source, folder, or membership.

**Consequence**
Add conservatively.

**Safety rule**
New sources begin paused; exact existing recipes may be reused.
### Removed

**Meaning**
The incoming publication no longer includes an earlier source, folder, or membership.

**Consequence**
Remove the publication relationship conservatively.

**Safety rule**
Local source history, retained items, read state, saved state, and unrelated organization remain.
### Recipe changes

**Meaning**
The incoming publication changes how a source is acquired.

**Consequence**
Require separate acknowledgement.

**Safety rule**
The new or reused recipe is distinct; a newly created one is paused and earlier history stays local.
## What counts as a wording conflict

Confluence currently supports explicit true-conflict choices for bounded human metadata:

```text
source title
source attribution
folder title
folder attribution
```

Folder membership is merged conservatively from semantic membership evidence.
A pre-existing reused source keeps its local label ownership.
Publication-level curator wording remains curator-owned because the local library does not presently expose an independent editor for those publication fields.

A conflict operation contains enough bounded evidence to render:

```text
field label
human object label
last accepted value
current local value
incoming curator value
one stable decision ID
```

The decision ID is not displayed in the ordinary interface.
It is available under advanced and machine-readable output.
## Acquisition recipes are a separate boundary

A changed source title is not equivalent to a changed source address or selector.
A recipe change can alter future network behavior.
It can move acquisition to another host.
It can select a different page region.
It can change include or exclude filters.
It can change a page-watch threshold.

Confluence therefore reports recipe changes separately from wording conflicts.

The review can show bounded evidence such as:

```text
old host
new host
feed or watched-page type
mode
restricted recipe fingerprint
whether the recipient also changed the local recipe
whether an exact incoming recipe already exists locally
```

The ordinary consequence is:

```text
The changed recipe becomes a separate reviewed source.
A newly created source starts paused.
The earlier source and its history stay local.
```

The Extension requires one explicit recipe acknowledgement.
The CLI requires `--accept-recipe-changes`.
The Node cannot apply the recipe change.
## Extension behavior

The Extension's existing source-list later-copy path now renders Confluence directly in the everyday reader.

The order is deliberate:

```text
1. Trust discontinuity, when present
2. Three-way summary counts
3. True wording conflicts
4. Acquisition-recipe changes
5. Curator-only changes
6. Recipient-only changes
7. Matching changes
8. Additions
9. Removals
10. Advanced comparison
11. Apply reviewed choices
```

True conflicts appear first because they block application.
Recipe changes appear second because they change future acquisition.
Non-blocking groups stay behind concise native disclosures.

The final button remains disabled until all required boundaries are complete:

```text
every conflict has keep-local or use-curator
every recipe change is acknowledged
any signer continuity change is acknowledged
the reviewed local vault revision still matches
```

Application sends:

```text
conflictChoices
acknowledgeRecipeChanges
acknowledgeTrustChange
reviewedRevision
targetRootId
exact incoming source-list document
```

The background re-plans the update at commit time.
It does not trust the DOM summary as authority.
It refuses stale local state.
It refuses a missing conflict choice.
It refuses an unacknowledged recipe change.
It refuses an unacknowledged trust discontinuity.

The local update remains undoable through the existing guarded shared-folder update undo.
Undo refuses to overwrite newer unrelated work.
## Extension visual hierarchy

Confluence preserves the Nightstand aesthetic:

```text
near-black default canvas
fluorescent cyan primary actions
magenta conflict boundary
lime recipe boundary
elegant thin gradient lines
no continuous decorative animation
light mode available and persisted
forced-colors removes decorative treatment
```

The visual semantics are restrained:

```text
cyan     reviewed action and structural emphasis
magenta  unresolved human choice or local-only evidence
lime     consequential acquisition behavior
neutral  additions, removals, and quiet disclosures
```

The design must not rely on color alone.
Every colored state also has text, grouping, and border structure.
The conflict controls remain ordinary radios with visible labels.
The recipe acknowledgement remains an ordinary checkbox.
## Node behavior

The Node adds **Curate → Compare a later copy**.

The person chooses one explicit local native source-list file.
An optional local route selector is secondary.
The browser sends the document to:

```text
POST /api/v1/merge-reviews
```

The endpoint returns:

```text
progrss.node.merge-review.v1
```

The response contains:

```text
selected backup filename
selected backup SHA-256
review state
progrss.shared-folder-update.preview.v2
progrss.shared-folder-merge-review.v1
readOnly: true
network: false
writes: false
```

The endpoint remains behind:

```text
literal loopback bind
exact Host checks
same-origin checks
no CORS grant
administrator bearer capability
bounded request bytes
native source-list validation
publication identity and continuity checks
```

The Node does not expose:

```text
apply merge
write library
arbitrary patch
generic file write
source fetch
permission inheritance
remote Node control
WebRTC control
```

The Node surface deliberately shows the conflict evidence without decision controls.
Its final note says that application remains an explicit Extension or CLI operation.
## CLI behavior

Review remains offline:

```sh
./progrss workspace review-bundle \
  private-backup.json later-source-list.json
```

Machine-readable review:

```sh
./progrss workspace review-bundle \
  private-backup.json later-source-list.json \
  --json
```

The CLI prints human groups in this priority:

```text
true wording conflicts
acquisition-recipe changes
curator-only changes
recipient-only changes
matching changes
additions
removals
```

Application remains new-file-only:

```sh
./progrss workspace update-bundle \
  private-backup.json later-source-list.json \
  --resolve-conflicts keep-local \
  --accept-recipe-changes \
  --output reviewed-result.json
```

Alternative global wording policy:

```sh
--resolve-conflicts use-curator
```

The CLI policy currently applies to every unresolved wording conflict in that invocation.
The Extension supports one decision per conflict.

The CLI still refuses:

```text
input overwrite
existing output file
stale or rollback copy
same-time conflicting copy
ambiguous local publication target
missing continuity mapping
advanced local collection fork that cannot be represented safely
unacknowledged signing-key discontinuity
unresolved wording conflict
unacknowledged acquisition-recipe change
```
## Schemas introduced or advanced

### `progrss.shared-folder-merge-review.v1`

Purpose:

```text
portable bounded semantic evidence for a three-way later-copy review
```

Top-level groups:

```text
counts
curatorOnly
recipientOnly
agreed
conflicts
additions
removals
recipeChanges
omitted
requiresDecisions
decisionIds
recipeAcknowledgementRequired
network
writes
```

### `progrss.shared-folder-update.preview.v2`

Adds:

```text
mergeReview
requiresConflictChoices
requiresRecipeAcknowledgement
```

Preserves existing:

```text
publication identity
signer continuity
rollback checks
contents review
local-edit summary
reviewed revision
canUpdate and reason
network false
writes false
```

### `progrss.node.merge-review.v1`

Purpose:

```text
same-origin administrator-only Node wrapper around one read-only merge review
```

It does not become a general synchronization schema.
## Privacy boundary

Merge review uses publication semantics and bounded local metadata.
It does not export or send to the curator:

```text
read or unread state
saved state
retained article bodies
page-watch snapshots
page-watch before/after evidence
HTTP validators
cookies
browser permission grants
private signing keys
unrelated folders
unrelated labels
unrelated saved views
```

The Node receives the explicitly chosen later source-list document from its own administrator UI.
The Node does not upload the selected private backup.
The merge endpoint reads the selected backup locally.

The Extension review remains local to the Extension vault.
No conflict decision is sent to the curator.
## Signature and identity boundary

A valid signature means only:

```text
the matching key signed the exact checked source-list bytes
```

It does not mean:

```text
the displayed curator name is a legal identity
the curator's explanation is true
the included sites are safe
the recipient granted site access
the recipient agreed to fetch anything
the source-list branch excerpt has its own signature
```

A changed signing key remains independent from wording and recipe choices.
The Extension shows its own acknowledgement.
The CLI requires `--accept-trust-change`.
The Node only reports the state.
## Branch semantics remain unchanged

Confluence does not weaken Branch.

A selected non-root branch remains:

```text
one independent local folder excerpt
selected folder plus simple descendants
only sources referenced by that branch
no parent future-copy address
no parent signing-key continuity
no automatic parent update relationship
```

The parent signature remains evidence about the parent document checked at selection time.
It is not represented as a new signature over the derived subset.

A recipient who wants continuing later-copy review must adopt the complete route rather than the independent excerpt.
## Exchange and pairing remain separate

Confluence does not merge the three existing transport relationships.

```text
Pairing
  summary-only relationship to one explicit local Node session
  no source addresses
  no items
  no writes

Exchange
  expiring immutable artifact handoff
  Follow updates / Add complete route / Take one branch
  no pairing requirement
  no synchronization

Confluence
  local three-way later-copy review
  Extension or CLI application only
  Node review-only
```

A successful transport does not imply authority to merge.
A successful merge review does not imply permission to fetch sources.
A successful source-list update does not imply browser host authority.
## No automatic synchronization

This release deliberately does not add synchronization.

There is no:

```text
background Node poll
automatic later-copy check
automatic conflict resolution
automatic recipe acceptance
automatic signer-key acceptance
automatic source activation
automatic remote write
automatic Node-to-Node exchange
```

“Apply reviewed choices” is one explicit local transaction.
The Node remains unable to perform it.
## Refusal matrix

| Condition | Result | User consequence |
|---|---|---|
| Incoming document malformed | Refuse before semantic review | Nothing changes. |
| Incoming document oversized | Refuse before parsing beyond bound | Nothing changes. |
| Publication identity differs | Refuse in-place update | Offer separate import only where supported. |
| Incoming copy is older | Refuse rollback | Keep current library. |
| Same publication time but different bytes | Refuse ambiguous continuity | Require a distinct later publication. |
| Local publication target ambiguous | Refuse selection | Ask for exact local route. |
| Baseline mapping missing | Refuse automatic reconstruction | Keep local library. |
| True conflict lacks decision | Refuse apply | Review remains available. |
| Recipe change lacks acknowledgement | Refuse apply | Review remains available. |
| Signer continuity change lacks acknowledgement | Refuse apply | Review remains available. |
| Local vault revision changed after review | Refuse stale commit | Review again. |
| Output path exists in CLI | Refuse overwrite | Choose a new file. |
| Node request has wrong Host | Refuse HTTP request | No CORS fallback. |
| Node request has foreign Origin | Refuse HTTP request | No response data. |
| Node request lacks administrator capability | Refuse HTTP request | No merge review. |
| Node receives apply-shaped request | No endpoint exists | No write occurs. |

## Accessibility and cognitive-load rules

Preserve these rules in future work:

```text
Consequences before schemas.
Conflicts before informational differences.
No default winner for a true conflict.
One ordinary sentence per consequential boundary.
Short headings and grouped controls.
Native details for secondary evidence.
Advanced evidence remains reachable, not deleted.
Keyboard focus returns to the initiating context.
Controls remain at least the established target size.
320px enlarged-text reflow remains tested.
Forced-colors removes decorative gradients and glows.
Color never carries the only meaning.
No motion is required to understand state.
No timeout is imposed on local conflict decisions.
```

The most important unfamiliar-human task is:

```text
A curator changed one source name.
You changed the same source name differently.
Another source changed its feed address.
Explain which choice changes wording,
which choice changes future fetching,
and what remains local after update.
```
## Current screenshots

The release-validation render outputs are outside the archive and should be regenerated from delivered bytes when needed.

Primary screenshots:

```text
/mnt/data/progrss63-extension-screens/reader-merge-review.png
/mnt/data/progrss63-extension-screens/reader-merge-review-card.png
/mnt/data/progrss63-screens/progrss-node-merge-review.png
/mnt/data/progrss63-screens/progrss-node-merge-review-card.png
```

The Extension full-height image demonstrates the ordinary update path.
The Node card demonstrates read-only conflict and recipe evidence.
Neither screenshot is evidence of installed native-browser acceptance.
## Implementation map

| Path | Responsibility |
|---|---|
| `CLI/relay.py` | Three-way planning, machine-readable review, CLI refusal and application. |
| `CLI/node_server.py` | Administrator-only read-only Node endpoint and capability declaration. |
| `CLI/node_web/index.html` | Compare-a-later-copy input and review container. |
| `CLI/node_web/app.js` | File validation, endpoint call, and grouped render. |
| `CLI/node_web/app.css` | Dark fluorescent merge presentation and forced-colors behavior. |
| `CLI/docs/NODE-MERGE-REVIEW.md` | Protocol and operational boundary. |
| `CLI/tests/test_relay.py` | Three-way attribution and conflict behavior. |
| `CLI/tests/test_node_server.py` | Read-only endpoint, Origin/capability, and byte-preservation proof. |
| `CLI/tests/node_browser_smoke.py` | Rendered Node merge review. |
| `Extension/background.js` | Three-way planner and guarded update application. |
| `Extension/sidepanel/app.js` | Everyday human review and decision controls. |
| `Extension/sidepanel/app.css` | Conflict, recipe, disclosure, responsive, and forced-colors presentation. |
| `Extension/tests/background_harness.js` | Real engine refusal until a conflict choice exists. |
| `Extension/tests/browser_smoke.py` | Rendered review and disabled-button sequencing. |
| `Extension/tests/test_static.py` | Version, packaged boundary, and merge UI markers. |
| `Extension/Firefox/` | Generated sibling synchronized from canonical Extension source. |

## Pre-seal verification completed

The working tree has passed these lanes before sealing:

```text
56/56 Extension structural and static checks
PASS Chromium background harness
PASS Branch / Contents / Signpost / Edition shared-folder harness
PASS generated Firefox background harness
PASS acquisition and redirect harness
PASS shared-vault conflict and failed-write harness
PASS rendered everyday reader
PASS rendered Advanced Workbench

46/46 direct CLI library tests
29/29 source-list, publication, integrity, continuity, and merge tests
14/14 Node HTTP, pairing, Exchange, merge-review, Origin, digest, and revocation tests
25/25 launcher cases in individually bounded processes
PASS CLI doctor
PASS rendered Node UI
```

The aggregate command-line wrapper can retain descendant output handles after completed assertions.
It is not used as release proof.
Each launcher case is executed under an independent bound and recorded separately.
## Native and human boundaries

Do not upgrade these statuses without real evidence:

```text
Installed Chromium Extension
  SKIP on this host
  managed policy blocks unpacked installation

Native Chromium loopback navigation
  SKIP on this host
  managed policy returns ERR_BLOCKED_BY_ADMINISTRATOR

Native Firefox current and ESR
  SKIP on this host
  no executable available

Unfamiliar-human comprehension
  NOT YET RUN

Real screen reader, Braille, voice control, switch device
  NOT YET RUN

High zoom, forced colors, cognitive fatigue with humans
  NOT YET RUN
```

Automated accessibility-tree, keyboard, target-size, reflow, and forced-colors tests are regression evidence.
They are not a substitute for human assistive-technology acceptance.
## Prioritized checklist — completed in Confluence

- [x] Dark fluorescent ordinary reader remains the default; light remains optional.
- [x] Advanced Workbench remains secondary.
- [x] `progrss.shared-folder-merge-review.v1` implemented independently in Python and JavaScript.
- [x] Baseline, local, and incoming copies remain distinct.
- [x] Curator-only changes classified.
- [x] Recipient-only changes classified and preserved.
- [x] Identical changes classified as agreement.
- [x] True divergent wording conflicts classified.
- [x] Additions and removals classified.
- [x] Acquisition-recipe changes separated from wording.
- [x] Every Extension conflict has Keep mine / Use curator with no preselection.
- [x] Extension application blocked until every conflict has a decision.
- [x] Extension application blocked until recipe changes are acknowledged.
- [x] Existing signer-continuity acknowledgement remains separate.
- [x] Commit rechecks the reviewed vault revision.
- [x] Changed recipes create or reuse a distinct source; new ones remain paused.
- [x] Earlier source history remains local.
- [x] Removed publication sources retain local history.
- [x] Guarded update undo remains available.
- [x] CLI review prints human-first groups.
- [x] CLI JSON exposes bounded advanced evidence.
- [x] CLI application requires explicit conflict policy.
- [x] CLI application requires recipe acknowledgement.
- [x] CLI output remains new-file-only and no-overwrite.
- [x] Node merge-review endpoint is same-origin, capability-gated, and read-only.
- [x] Node UI renders conflicts and recipe changes first.
- [x] Node UI exposes no apply control.
- [x] Node selected backup remains byte-identical during review.
- [x] Firefox generated package synchronized.
- [x] New Node merge-review contract documentation added.
- [x] BOOTSTRAPROSE updated as the operational handoff.

## P0 next — one reviewed Node operation

- [ ] Define `progrss.node.operation.v1`.
- [ ] Select exactly one first operation; prefer adopting one reviewed branch with new sources paused.
- [ ] Require the exact base-library SHA-256 reviewed by the person.
- [ ] Require the exact operation-preview digest.
- [ ] Require a random high-entropy idempotency key.
- [ ] Give the operation a short explicit expiry.
- [ ] Bind the operation to one authenticated local or paired client identity.
- [ ] Commit atomically under a single Node writer.
- [ ] Return a durable operation receipt.
- [ ] Include the resulting library digest in the receipt.
- [ ] Return the original receipt for an exact safe replay.
- [ ] Refuse reuse of an idempotency key with different content.
- [ ] Refuse stale base digest.
- [ ] Refuse stale preview digest.
- [ ] Refuse an expired operation.
- [ ] Keep a rollback snapshot or append-only inverse evidence.
- [ ] Make the Node UI show the exact consequence before commit.
- [ ] Make the Extension show that the Node, not the browser vault, is the writer.
- [ ] Keep generic JSON Patch out of the protocol.
- [ ] Keep arbitrary filesystem paths out of the protocol.
- [ ] Test crash before commit, during durable write, and after receipt creation.
- [ ] Test exact replay after client timeout.
- [ ] Test two clients racing the same base digest.
- [ ] Test revocation before commit.
- [ ] Run unfamiliar-human review of “send to Node” versus “apply in this browser.”

## P1 — Node-owned library

- [ ] Create transactional Node storage rather than reading only an exported backup.
- [ ] Import one private backup through explicit review.
- [ ] Preserve the original import file as rollback evidence.
- [ ] Use one writer and crash-safe commits.
- [ ] Produce portable snapshots.
- [ ] Produce append-only operation receipts.
- [ ] Expose source creation and pause/resume through typed operations.
- [ ] Add scheduled RSS, Atom, and JSON Feed retrieval.
- [ ] Add scheduled public page-watch retrieval.
- [ ] Add read and saved-state operations.
- [ ] Add folders, private labels, and saved views.
- [ ] Add static publication and signing from the Node GUI.
- [ ] Add later-copy review and typed application.
- [ ] Keep every GUI operation inspectable through bounded CLI JSON.
- [ ] Keep the Extension independently useful without the Node.
- [ ] Keep Node use optional and account-free.

## P1 — sites without feeds

- [ ] Ask “What part of this page counts as an update?”
- [ ] Show matched examples before saving a watch.
- [ ] Show ignored examples before saving a watch.
- [ ] Propose repeated-page structures without silently committing them.
- [ ] Keep the portable recipe declarative and bounded.
- [ ] Preserve stability witnesses and specimen evidence.
- [ ] Detect structure changes before emitting misleading updates.
- [ ] Keep browser-assisted capture for signed-in or rendered pages.
- [ ] Let the Node schedule only publicly reproducible or explicitly credentialed recipes.
- [ ] Hand work back to the browser when the Node cannot reproduce an authenticated view.
- [ ] Test dynamic client-rendered pages.
- [ ] Test pagination and infinite-scroll boundaries.
- [ ] Test localized and right-to-left pages.
- [ ] Test partial authentication and logout changes.
- [ ] Test consent walls and region variants.
- [ ] Do not normalize arbitrary shared JavaScript as the recipe format.
- [ ] If custom code is ever supported, isolate it as an explicitly dangerous local-only advanced adapter.

## P1 — organization and re-finding

- [ ] Measure whether people can find something again after a week.
- [ ] Keep folders as human-curated shareable routes.
- [ ] Add private many-to-many labels.
- [ ] Add explicit saved-query views.
- [ ] Preserve Unfiled as a legitimate state.
- [ ] Suggest duplicate-source consolidation without applying it automatically.
- [ ] Suggest stale-source review without engagement scoring.
- [ ] Suggest route splits as reversible previews.
- [ ] Keep automatic classification explainable and opt-in.
- [ ] Do not hide chronological reading behind recommendation ranking.
- [ ] Recover and independently verify the missing rev0059 Source Notes artifact before claiming complete continuity.
- [ ] When Source Notes return, keep them folder/source scoped and separate from acquisition recipes.

## P2 — remote Nodes

- [ ] Create a remote mode separate from loopback mode.
- [ ] Require TLS.
- [ ] Give the Node a persistent server identity.
- [ ] Use explicit hostname allowlists.
- [ ] Add request-size and rate bounds.
- [ ] Use expiring private invitations.
- [ ] Persist revocation evidence.
- [ ] Separate public publication routes from private APIs.
- [ ] Begin with manual remote artifact retrieval.
- [ ] Test reverse proxies without trusting arbitrary forwarded headers.
- [ ] Test self-hosted deployment documentation.
- [ ] Do not bind publicly by default.
- [ ] Do not add silent LAN discovery.
- [ ] Do not use UPnP or NAT-PMP automatically.
- [ ] Do not make remote administration share a capability with public artifacts.

## Lab — WebRTC courier

- [ ] Transfer exactly one already-reviewed source-list artifact.
- [ ] Use signed bounded offer/answer metadata informed by Vibechat.
- [ ] Keep signaling explicit.
- [ ] Make STUN use visible.
- [ ] Make TURN relay use visible.
- [ ] Compare copy/paste, QR, relay, HTTPS, and WebRTC friction.
- [ ] Verify exact bytes after transfer.
- [ ] Refuse identity mismatch.
- [ ] Refuse digest mismatch.
- [ ] Refuse replay.
- [ ] Refuse duplicate completion.
- [ ] Refuse partial transfer.
- [ ] Refuse expired offer.
- [ ] Discard the transport session after the bounded artifact transfer.
- [ ] Never make WebRTC required for reading, publication, or synchronization.

## Human acceptance tasks

| Task | Observation prompt |
|---|---|
| Three-way attribution | Name one change made only by the curator, one made only locally, and one changed differently on both sides. |
| Conflict consequence | Choose Keep mine for one conflict and explain what will remain. |
| Curator consequence | Choose Use curator’s for another conflict and explain what will change. |
| Recipe consequence | Explain why a changed feed address is not just a wording choice. |
| Paused behavior | Explain whether the changed recipe contacts its new site immediately. |
| Removal consequence | Explain what happens to earlier locally retained history when the curator removes a source. |
| Trust boundary | Explain what a verified signature proves and does not prove. |
| Review versus apply | Identify which screen only reviews and which action writes. |
| Node boundary | Explain whether the Node review changed the selected backup. |
| Advanced evidence | Find the raw baseline/local/incoming values without mistaking them for three actions. |
| Large text | Complete the conflict task at 320 CSS pixels and 200–400% zoom. |
| Forced colors | Complete the conflict task without relying on cyan, magenta, or lime. |
| Keyboard | Complete every decision and disclosure without a pointing device. |
| Screen reader | Hear group purpose, conflict labels, radio state, recipe acknowledgement, and disabled-button reason. |
| Fatigue | Complete the task after a sustained reading session without hidden timeout or lost choices. |

## Research boundary used for this release

This release was informed by current primary material in three areas:

```text
Git three-way merge documentation
  common ancestor plus two changed heads
  conflicts remain explicit until resolved

W3C cognitive and understandable-content guidance
  explain consequences before action
  group related controls
  keep critical paths short
  use clear language and allow correction

Browser extension permission guidance
  request optional host authority at the user action that needs it
  retain minimal authority
```

ProgRSS does not copy Git's user interface.
It uses the three-input reasoning model while presenting ordinary human consequences.
## Known limitations

- The Node still opens one exported backup rather than owning a live transactional library.
- The Node merge review cannot apply changes.
- The CLI conflict flag is one policy for all true wording conflicts in that invocation.
- The Extension supports per-conflict decisions but only for currently bounded wording fields.
- Publication-level curator wording has no independent local editor and therefore remains curator-owned.
- Recipe comparison is bounded evidence, not a general semantic equivalence proof.
- Advanced collection algebra remains refused rather than guessed.
- No native installed-browser acceptance was possible on this host.
- No real unfamiliar-human or assistive-technology sessions have yet been completed.
- The historical rev0059 Source Notes archive remains unavailable in the supplied artifacts.
- The supplied older chat handoff had ordinal gaps and cannot establish complete artifact lineage by itself.

## Version and authority boundary

```text
Extension version:             0.63.0
CLI version:                   0.63.0
Node HTTP server token:        ProgRSSNode/0.63
Revision:                      rev0063
Codename:                      Confluence
Vault schema:                  17, unchanged
Private backup schema:         progrss.private.v1
Shared source-list schemas:    progrss.bundle.v1/v2/v3
Contents schema:               progrss.shared-folder.contents.v2
Merge review schema:           progrss.shared-folder-merge-review.v1
Update preview schema:         progrss.shared-folder-update.preview.v2
Node merge wrapper:            progrss.node.merge-review.v1
Required host access:          none
Optional host surface:         http://*/* and https://*/*
Automatic import:              none
Automatic update apply:        none
Automatic publication poll:    none
Node merge writes:             none
Account or required cloud:     none
Telemetry:                     none
Private-key export:            none
WebRTC requirement:            none
```
## Release sealing instructions

Seal from the repository root so the archive opens directly to:

```text
BOOTSTRAPROSE.md
CLI/
Extension/
```

Use:

```text
fixed member ordering
fixed member timestamps
fixed compression choice
stored executable modes
no duplicate members
safe relative paths only
no symlinks
no nested release archive
no browser profile
no managed-policy file
no cache directory
no Python bytecode
no private signing key
```

Build twice and require byte identity.
Extract into a clean directory.
Restore stored modes.
Compare every delivered file byte-for-byte and executable-mode-for-executable-mode.
Replay principal suites from the clean extraction.

Record the final SHA-256 in the adjacent `.zip.sha256` file and the machine-readable release report.
Do not attempt to embed the archive's own final hash inside this file.
## Next-turn decision rule

The next turn should prioritize one reviewed Node operation.
It should not add another broad visual feature.

Choose the first writable operation by this order:

```text
1. Human value for sharing and curation
2. Narrow semantic scope
3. Reversible or safely replayable effect
4. No new ambient authority
5. Strong stale-review detection
6. Clear receipt
```

The leading candidate is:

```text
Adopt one already reviewed source-list branch into a Node-owned library.
New sources start paused.
Exact existing sources are reused.
The request names one reviewed artifact digest and one branch ID.
```

Before that can ship, the Node must own a transactional library.
A write against an exported backup without a one-writer store is not acceptable.

---

# Previous active bootstrap: rev0062 “Exchange”

# BOOTSTRAPROSE — ProgRSS rev0062 “Exchange”

**Release:** rev0062 · **Product version:** 0.62.0 · **Vault schema:** 17 (unchanged)
**Release maxim:** **One handoff. Three honest choices.**

## `/run` interpretation

When this file is used as the active bootstrap, continue from the delivered rev0062 tree rather than rebuilding its boundaries from memory.

Preserve these truths:

```text
The everyday reader is the default product.
Dark fluorescent presentation is the default.
Light presentation remains one explicit persisted option.
Advanced Workbench stays secondary.
The Extension remains independently useful.
The CLI remains independently useful.
The Node is the CLI's local web-server mode, not a hidden cloud dependency.
Pairing is summary-only.
Exchange is artifact-only.
Neither pairing nor Exchange implies synchronization.
No listed source is contacted merely because a route is reviewed.
No new source is activated merely because a route is adopted.
```

The active next boundary after this release is:

```text
later-copy merge review
plus
one-writer operation design
```

Do not skip directly to:

```text
generic writable REST
continuous bidirectional sync
ambient Node discovery
public default bind
WebRTC as mandatory transport
AI organization as hidden authority
```

## Current truth

Exchange advances the verified rev0061 **Handshake** tree.

Handshake established:

```text
one explicit loopback Node invitation
one exact Extension Origin
one process-lifetime Node session marker
one selected-library digest
bounded library counts
summary-only read authority
explicit Check, Unpair, and Forget
no startup Node request
no localhost scan
no writes
no synchronization
```

Exchange keeps every one of those constraints and adds a different capability:

```text
one sender-reviewed route
one immutable prepared artifact set
one expiring handoff
one recipient review
three distinct human consequences
```

The independently recoverable product lineage remains:

```text
rev0058 Branch
  complete route remains default
  one nested branch may become an independent local excerpt

rev0060 Nightstand
  dark fluorescent everyday reader
  explicit light option
  first loopback read-only Node

rev0061 Handshake
  Extension-to-Node summary pairing
  exact Origin binding
  explicit revocation

rev0062 Exchange
  sender curation in the Node GUI
  recipient three-door review in the Extension
  immutable artifact handoff
  script-free three-door publication page
```

The earlier captured conversation describes rev0059 **Source Notes**, but its archive was not supplied to the recovery session that produced Nightstand. Exchange therefore does not silently claim that missing release as recovered code. The current route-level curator note remains the existing supported publication note, not an assertion that every folder/source-scoped Source Notes behavior was recovered.

## Product surfaces

### ProgRSS Extension

```text
Purpose:
  capture deliberately selected web material
  read feeds and meaningful page changes
  review portable routes
  adopt complete routes or independent branches
  follow one ordinary summary feed

Default surface:
  Today
  Sources
  Add

Secondary surface:
  Advanced Workbench

Theme:
  dark fluorescent by default
  explicit persisted light option
  forced-colors removes decorative neon treatment
```

### ProgRSS CLI

```text
Purpose:
  inspect explicit files
  preview feeds offline
  audit and repair private backups
  inspect and verify native source lists
  import complete routes or one branch
  publish static route packages
  audit deployed publication pages
  reproduce bounded page-watch decisions
```

### ProgRSS Node

```text
Purpose:
  serve one explicit local backup through a loopback UI
  let its owner read and curate that selected copy
  prepare immutable sharing artifacts
  create expiring handoff invitations
  keep pairing and sharing separate

Current authority:
  read selected copy
  prepare artifacts
  no library mutation
  no scheduled fetch
  no remote bind
  no generic sync
```

### Portable artifacts

```text
Private backup
  complete local library
  includes private reading state
  keep private

Native ProgRSS source list
  feeds
  watched-page recipes
  simple folders
  curator wording
  publication identity
  integrity evidence
  later-copy continuity for complete-route adoption

OPML
  interoperable feed subscriptions and hierarchy
  intentionally omits richer ProgRSS semantics

Recent-updates JSON Feed
  one ordinary summary feed
  does not add the route's underlying sources

Static publication package
  human-readable page
  native source list
  optional recent-updates feed
  optional OPML
  no script, tracker, remote image, frame, form, or automatic check
```

## The human problem Exchange addresses

A sender does not primarily want to “export JSON.”

A sender wants to say:

```text
Here is the route I use for this subject.
Here is why it matters.
Here is what is included.
Here is what is not included.
You can merely follow my updates.
You can adopt the complete route.
You can take only the branch you need.
```

A recipient does not primarily want to “consume a capability URL.”

A recipient wants to answer:

```text
Who prepared this?
What is being offered?
What will happen if I choose this?
Will anything contact all those sites immediately?
Will this expose my reading history?
Will this stay connected to the sender?
Can I take only one part?
Can I undo or disconnect it?
```

Exchange puts those consequences before:

```text
schema names
media types
hash algorithms
capability vocabulary
API routes
signature bytes
folder graph identifiers
```

Advanced evidence remains available, but it does not lead the ordinary decision.

# What Exchange delivers

## 1. Sender begins with one existing route

The Node’s ordinary **Curate** screen now begins with one existing simple folder from the explicitly selected backup.

The sender chooses:

```text
folder route
optional curator name
optional short explanation
whether to prepare recent updates
optional public source-list URL
```

The Node does not offer:

```text
arbitrary source-by-source checkbox forest
generic query builder
raw JSON editor
unbounded filesystem browser
automatic public upload
automatic DNS or network discovery
implicit account creation
```

The route selector includes only populated simple folders that the Node can represent accurately through the existing source-list model.

## 2. Preparation is read-only and offline

`prepare_exchange`:

```text
reads the selected progrss.private.v1 file
copies its portable state before transformation
selects one explicit folder
builds one native source list
optionally builds one recent-updates Edition
optionally builds one static publication ZIP
computes exact artifact byte sizes
computes exact artifact SHA-256 digests
computes one canonical preview digest
returns bounded preview evidence
```

It performs no:

```text
DNS lookup
network request
browser-profile read
browser permission read
input mutation
output overwrite
library write
source activation
source fetch
```

The selected backup remains byte-identical.

## 3. Sender reviews exact consequences

Before a handoff exists, the Node shows:

```text
route title
folder path
curator wording
source count
feed count
watched-page count
folder count
recent-update count
bounded source titles
source hostnames
feed or watched-page type
bounded folder routes
available branch choices
available recipient choices
artifact filenames
artifact media types
artifact byte sizes
artifact SHA-256 digests
included data categories
excluded private-state categories
```

The sender review explicitly excludes:

```text
read and unread state
saved state
full retained article text
page-watch snapshots
page comparison evidence
browser permissions
browser cookies
private signing keys
unrelated folders
```

This is a sender-side privacy review, not merely a success banner.

## 4. Ten-minute preview

The prepared preview is held in Node process memory for ten minutes.

It has:

```text
schema: progrss.node.exchange-preview.v1
state: preview
previewToken
previewDigest
reviewed library SHA-256
expiry
network: false
writes: false
automatic: false
```

The preview token is not the final recipient invitation.

It exists only so the sender can commit the exact reviewed bytes.

## 5. Stale-review refusal

Creating the final handoff requires:

```text
preview token
exact reviewed preview digest
exact reviewed selected-library digest
```

The Node refuses when:

```text
preview expired
preview already used
preview digest changed
submitted library digest changed
selected backup changed after review
```

A changed selected file requires a new sender review.

No plausible-looking stale route is silently shared.

## 6. Thirty-minute handoff

A successful commit creates:

```text
http://127.0.0.1:PORT/#exchange=CAPABILITY
```

The handoff:

```text
lasts thirty minutes
exists only in Node process memory
is revocable by the Node owner
is stored through a derived capability lookup key
is not a cookie
is not placed in a query string
is not the Node administrator capability
is not a pairing capability
is not a permanent public URL
```

The URL fragment keeps the capability out of the initial HTTP request when opened as navigation.

The ProgRSS Extension parses and uses it only after the visible review action.

## 7. Strict Extension parsing

The Extension accepts only:

```text
scheme:       http
hostname:     literal 127.0.0.1
port:         explicit 1..65535
path:         /
query:        absent
username:     absent
password:     absent
fragment:     exactly one exchange token
```

It refuses:

```text
localhost
private-LAN names
public hostnames resolving to loopback
missing port
extra fragment keys
credentials
query parameters
arbitrary paths
unbounded token strings
```

There is no:

```text
localhost scan
port probe
mDNS discovery
LAN broadcast
remembered-Node startup contact
background reconnect loop
```

## 8. Browser-owned loopback authority

Review requests:

```text
http://127.0.0.1/*
```

only inside the visible action that needs it.

The displayed and validated Node identity remains the exact:

```text
http://127.0.0.1:PORT
```

because WebExtension match patterns are host-scoped rather than TCP-port-scoped.

When ProgRSS newly added loopback authority for this review, leaving or cancelling the Add flow attempts to release it.

Previously existing authority is not removed.

## 9. First review binds one Extension Origin

Review uses:

```text
GET /api/v1/exchange-review
Authorization: Bearer EXCHANGE-CAPABILITY
Origin: chrome-extension://EXACT-ID
```

or the exact Firefox `moz-extension://…` Origin.

The first successful review binds the handoff to that exact Extension Origin.

A different extension Origin is refused.

An ordinary website Origin is refused.

The binding limits accidental capability reuse; it is not a claim that the extension ID proves a person’s identity.

## 10. Recipient review

The Extension verifies:

```text
schema
state
scope
expiry
exact Node origin
Node version and revision
process-lifetime session fingerprint
selected-library digest
counts
available choices
branch metadata
artifact media types
artifact filenames
artifact sizes
artifact SHA-256 digests
public feed address when present
network: false
writes: false
automatic: false
```

The ordinary review shows:

```text
route title
curator wording
source and folder counts
bounded contents
what private state is excluded
three possible consequences
```

Advanced evidence can show:

```text
full session fingerprint
exact selected-library digest
preview digest
artifact digest
scope
expiry
Node origin
```

## 11. The three doors

### Door A — Follow updates

Meaning:

```text
Preview one normal summary feed.
Follow that one feed only after a separate decision.
Do not add the underlying feeds.
Do not add watched-page recipes.
Do not add folder hierarchy.
```

The handoff’s recent-updates bytes are used for bounded preview evidence.

The final followed address is never the expiring loopback artifact endpoint.

A durable Follow action exists only when the sender supplied a public publication address and the checked handoff names the corresponding public feed URL.

### Door B — Add the complete route

Meaning:

```text
Retrieve the native ProgRSS source list.
Verify its reviewed byte bound and SHA-256 digest.
Parse and validate the complete checked document.
Open the existing source-list review.
Reuse exact existing sources.
Create new sources paused.
Preserve complete-publication continuity when supported.
```

Review still performs no request to the feeds or watched pages named inside the source list.

Import remains a later separate action.

### Door C — Take one branch

Meaning:

```text
Retrieve the same checked native source-list artifact.
Choose one populated nested simple-folder branch.
Review that exact branch closure.
Adopt the selected folder, descendants, and referenced sources only.
Create an independent local excerpt.
```

The branch receives no:

```text
parent future-copy address
parent update identity
automatic continuity relationship
counterfeit subset signature
browser authority
```

This preserves the rev0058 Branch rule: take one branch without claiming the whole tree.

## 12. Artifacts are retrieved only after a choice

The recipient capability exposes fixed routes only:

```text
/api/v1/exchange/source-list
/api/v1/exchange/recent-updates
```

The Extension retrieves:

```text
recent-updates only after Follow updates
source-list only after Add the complete route or Take one branch
```

It does not prefetch both artifacts merely because review succeeded.

It cannot use the Exchange bearer to retrieve:

```text
/api/v1/library
/api/v1/status
/api/v1/curation
arbitrary files
arbitrary URL paths
Node administrator data
```

## 13. Byte and digest validation

For each retrieved artifact, the Extension:

```text
checks that the artifact was declared available
uses the reviewed byte bound
refuses an oversized response
computes SHA-256 over the exact returned bytes
compares the exact reviewed digest
refuses mismatch
parses through the existing validator
```

A correct digest proves only that the received bytes match the reviewed bytes.

It does not prove:

```text
curator real-world identity
source safety
source truth
future availability
absence of bias
```

## 14. Feed preview remains separate from Follow

The recent-updates artifact enters the existing bounded feed preview.

The preview shows at most bounded feed-supplied examples and does not load:

```text
article pages
remote images
scripts
frames
audio
video
embedded objects
```

The final **Follow recent updates** action:

```text
uses the reviewed public feed URL
requests that public origin only inside the visible action
creates one ordinary feed source
```

Back returns to the exact shared-route choices.

## 15. Source-list review remains separate from Add

The complete route and branch paths reuse existing source-list safety:

```text
connected graph validation
content digest validation
optional signature validation
publisher continuity review
existing-source reuse
duplicate incoming recipe collapse
new-source paused state
capacity review
stale vault revision refusal
private-state exclusion
```

The Exchange invitation does not weaken those boundaries.

## 16. Static publication now uses the same three doors

The generated script-free page now presents:

```text
Follow updates
Add the complete route
Take one branch
```

The page explains that:

```text
following adds one summary feed only
adding the route reviews all underlying sources
branch adoption happens inside ProgRSS after checking the complete source list
```

The full route and branch links may point to the same native source-list artifact because branch selection is a recipient-side reviewed consequence, not a different unsigned file pretending to be the parent publication.

OPML remains under a separate feed-reader fallback.

## 17. Public and private sharing remain distinct

### Private local handoff

```text
loopback Node
expiring capability
one exact Extension Origin
reviewed immutable artifacts
revocable
not durable
not publicly reachable
```

### Public static publication

```text
ordinary HTTPS hosting
stable publication page
native source list
recent-updates feed
OPML fallback
optional signature
no recipient capability
```

Copying a local invitation does not publish the Node.

Generating a static package does not automatically upload it.

## 18. Web Share is a progressive enhancement

The Node offers the operating-system share sheet only when:

```text
a public publication page exists
navigator.share exists
navigator.canShare accepts the share data when available
the person activates the visible control
```

Copy remains the universal fallback.

The Web Share API:

```text
is availability-dependent
requires a secure context in ordinary web deployment
requires transient user activation
may be restricted by Permissions Policy
hands data to a user-chosen share target
```

ProgRSS does not treat the resolved share promise as proof that another person received, opened, understood, or accepted the route.

Web Share is not part of the ProgRSS protocol.

## 19. Pairing remains separate and secondary

The Node still offers **Create pairing invitation** under a secondary disclosure.

Pairing grants only:

```text
running Node session evidence
selected filename
selected-library digest
bounded counts
explicit capability refusals
```

Exchange grants only:

```text
one prepared source-list artifact
one prepared recent-updates artifact when available
one reviewed route context
```

Neither grants:

```text
Node library writes
Extension library writes
source fetching
continuous polling
automatic merge
Node-to-Node control
WebRTC
```

### Pairing versus Exchange

```text
Pairing
  question: Is this the same running Node and selected copy?
  lifetime: process memory until revoke or stop
  data: digest and bounded counts
  relationship: explicit local session relationship

Exchange
  question: What route is being offered, and what can I do with it?
  lifetime: thirty-minute artifact invitation
  data: immutable prepared artifacts and bounded context
  relationship: courier only
```

A user can use Exchange without pairing.

A paired Extension receives no automatic Exchange authority.

## 20. Revocation and expiry

The Node owner can list:

```text
exchange ID
route title
folder
counts
available choices
creation time
expiry
whether one Extension Origin reviewed it
selected-library digest
```

The list does not expose bearer capabilities.

The owner can revoke by exchange ID.

After:

```text
expiry
revocation
Node stop
```

new review and artifact retrieval fail.

Previously adopted local sources remain local because the handoff was only a courier.

## 21. Honest unavailable states

Follow updates is unavailable when:

```text
no recent-updates artifact was prepared
or
no public publication address was supplied
```

The interface explains why.

Take one branch is unavailable when:

```text
the selected route has no populated nested simple-folder branch
```

The complete route remains available for a valid preparation.

The Node does not fabricate a durable feed from a temporary loopback address.

# Protocol and security boundary

## Capability families

```text
Master Node capability
  administrator UI and read-only selected-library APIs
  URL fragment key: token

Pairing invitation capability
  ten-minute one-use review/accept capability
  URL fragment key: pair

Pairing grant capability
  process-lifetime summary check/revoke
  never shown to Node administrator after creation

Exchange preview capability
  sender-side ten-minute reviewed staging object
  never sent to recipient

Exchange handoff capability
  recipient-side thirty-minute artifact retrieval
  URL fragment key: exchange
```

Capability families do not substitute for each other.

## Host boundary

The Node binds only:

```text
127.0.0.1
```

It refuses unexpected `Host` headers.

It sends no wildcard CORS grant.

Administrator POST requires the Node page’s exact same Origin and master bearer.

Extension review and artifact routes require:

```text
exact chrome-extension or moz-extension Origin
exact Exchange bearer
```

## Process-lifetime identity

The Node session fingerprint is derived from a random process-lifetime secret.

It changes when the Node restarts.

It helps a person notice:

```text
this is no longer the same running process
```

It does not claim:

```text
permanent hardware identity
real-world person identity
certificate authority identity
social trust
artifact truth
```

## No hidden synchronization

Exchange has no:

```text
poll timer
push channel
WebSocket
service worker registration
background reconnect
remote mutation queue
conflict resolver
change journal replication
```

The recipient makes one reviewed decision against one immutable prepared artifact set.

## No generic writable API

The Node still reports:

```text
writeLibrary: false
fetchSources: false
publish: false
merge: false
nodeToNode: false
webrtcCourier: false
```

`prepareExchange: true` means only that the Node can derive immutable artifacts from the selected copy.

`preparePublicationPackage: true` means only that it can prepare a static package for explicit download.

# Human-centered acceptance questions

## Sender comprehension

An unfamiliar sender should be able to answer:

1. Which folder is being shared?
2. Are unrelated folders included?
3. Are read/unread and saved states included?
4. Are full retained article bodies included?
5. Does creating the handoff upload anything?
6. Does creating the handoff contact the listed sites?
7. How long does the invitation work?
8. What changes if a public source-list URL is supplied?
9. Is the public static package already hosted?
10. Can the recipient change the sender’s library?

## Recipient comprehension

An unfamiliar recipient should be able to answer:

1. What does Follow updates add?
2. What does Add the complete route add?
3. What does Take one branch add?
4. Which choices contact the underlying listed sites during review?
5. Do new underlying sources begin active?
6. Does branch adoption stay connected to the parent publication?
7. Does following updates add the source route?
8. Does the handoff reveal the recipient’s reading history?
9. Does opening the invitation pair the Extension to the Node?
10. What happens when the invitation expires?

## Language needing observed evidence

```text
route
updates
complete route
branch
independent local excerpt
public publication address
starts paused
curator wording
private state excluded
reviewed bytes
```

Wrong turns should change wording or hierarchy.

They should not automatically produce:

```text
more settings
a wizard with ten steps
a dashboard
an engagement score
a recommendation feed
an account requirement
a follower graph
```

## Friction budget

A successful recipient flow should be:

```text
paste invitation
review route
choose one consequence
review the chosen artifact
commit separately when applicable
```

The ordinary path should not require understanding:

```text
capability URLs
SHA-256
MIME types
Origin headers
canonical JSON
folder IDs
signature byte encoding
```

Those remain available as evidence.

# Next: later-copy merge review

Exchange makes the first transfer understandable.

The next hard problem is what happens when the curator publishes a later copy and the recipient has local changes.

## Required three-way model

Every meaningful field needs:

```text
last accepted curator value
current local value
incoming curator value
```

The review should classify:

### Curator-only change

```text
last accepted == local
incoming differs
```

Default consequence:

```text
apply incoming curator value
```

### Recipient-only change

```text
last accepted == incoming
local differs
```

Default consequence:

```text
keep local value
```

### Divergent change

```text
local differs from last accepted
incoming differs from last accepted
local differs from incoming
```

Consequence:

```text
require visible decision
```

### Curator addition

```text
new source or folder in incoming publication
```

Consequence:

```text
show exact addition
new source begins paused
```

### Curator removal

```text
source or folder no longer in incoming publication
```

Consequence:

```text
preserve local history
explain detached local state
never silently erase retained reading evidence
```

### Acquisition recipe change

```text
feed address changed
watched-page selector recipe changed
threshold or filter changed
```

Consequence:

```text
treat as consequential identity/acquisition change
never silently redirect collection
review exact old and new host and recipe category
new recipe begins paused unless an exact existing source is reused
```

## Merge UI principle

Basic review should say:

```text
Curator changed this
You changed this
Both changed this
Added by curator
Removed by curator; local history kept
How this source is checked changed
```

Advanced evidence may show:

```text
stable IDs
canonical digests
recipe fingerprints
signature continuity
publication IDs
raw three-way values
```

## Merge non-goals

Do not begin with:

```text
generic object diff
raw JSON patch
line-oriented merge
last-write-wins
server-wins
recipient-wins for every field
silent recipe replacement
```

# Parallel next: one-writer operation contract

The Node cannot “do everything the Extension can do and more” safely while it only reads exported backups.

It needs one authoritative transactional library process.

Before any paired write, define:

```text
schema: progrss.node.operation.v1
operation type
reviewed base-library digest
exact preview digest
random idempotency key
short expiry
actor capability scope
atomic commit
new library digest
durable receipt
safe replay behavior
```

## Required refusal cases

```text
stale base digest
stale preview digest
expired operation
already used operation with different body
unknown operation type
capability scope mismatch
capacity exceeded
invalid source recipe
write failure
read-back failure
```

## Safe replay

Replaying the same idempotency key and exact body should return:

```text
the existing receipt
```

It should not repeat the mutation.

Reusing an idempotency key with a different body should be refused.

## Candidate first write

Preferred first candidate:

```text
adopt one reviewed source-list branch
new sources paused
```

Why:

```text
exercises the actual sharing model
has bounded consequences
can reuse existing import planning
can produce a precise receipt
avoids background fetching
```

Alternative small candidate:

```text
add one reviewed feed paused
```

Do not begin with:

```text
arbitrary JSON Patch
filesystem write
bulk sync
remote delete
unreviewed page-watch code
```

# Node-owned library direction

The future Node-owned library should provide:

```text
transactional storage
crash-safe commit
portable snapshot export
append-only operation receipts
explicit import of an existing private backup
retained original import as rollback evidence
scheduled feed retrieval
scheduled public page watching
read and saved-state operations
folders
private labels
saved views
publication
signing
later-copy review
merge
```

The Extension should remain useful without a Node.

The Node should not become a mandatory account server.

# Sites without RSS remain mission-critical

The acquisition ladder remains:

```text
1. Existing RSS, Atom, or JSON Feed
2. Feed advertised by the current page
3. Safe known structured data
4. Repeated-page structure proposal
5. User-selected page region
6. Bounded declarative custom recipe
```

The ordinary question should be:

```text
What part of this page counts as an update?
```

The review should show:

```text
example title
example destination
example retained text
matched structure
ignored structure
stability evidence
whether the Node can reproduce the page
whether the browser's signed-in context is required
```

## Extension and Node split

### Extension

```text
captures the page the person is deliberately viewing
can use explicitly granted browser-session context
helps select a meaningful region
records bounded evidence
```

### Node

```text
schedules publicly reproducible recipes
preserves observations and stability witnesses
detects structural instability
proposes repair
hands work back to the browser when authentication or rendering is required
```

### Shared source list

```text
carries declarative recipe
carries bounded examples and witnesses
carries curator explanation
never carries browser cookies
never carries browser permissions
never carries arbitrary unsandboxed executable code as the default
```

## Custom behavior boundary

The portable recipe language should favor:

```text
bounded selectors
link selection rules
text normalization
include/exclude filters
pagination limits
change thresholds
stored examples
stability witnesses
```

Arbitrary shared JavaScript should not become the normal extension mechanism.

Every shared executable recipe would otherwise become a code-execution and supply-chain boundary.

# Feed organization direction

Folders are necessary but insufficient.

The working model remains:

## Folders

```text
human-curated routes
hierarchical
potentially publishable
used for complete-route and branch sharing
```

## Local labels

```text
many-to-many
private by default
not silently published
useful across folder boundaries
```

## Saved views

```text
explicit reusable queries
examples:
  unread + local
  saved + research
  page changes + needs repair
  followed updates + last 7 days
```

## Unfiled

```text
legitimate resting state
not an error
not a forced inbox-zero task
```

## Organization acceptance

Measure:

```text
Can a person find the item again a week later?
```

Do not measure only:

```text
Can a coached person create a folder immediately?
```

## Machine assistance boundary

Machine suggestions may propose:

```text
possible duplicate sources
possible labels
possible route splits
possible stale sources
possible page-watch repairs
```

They must remain:

```text
visible
reviewable
reversible
non-authoritative
```

No opaque engagement ranking or automatic taxonomy should replace chronology and explicit organization.

# Remote Node direction

Remote mode is a separate deployment mode.

It requires:

```text
TLS
persistent server identity
explicit bind configuration
hostname allowlist
request size bounds
rate bounds
revocation persistence
reverse-proxy semantics
public/private route separation
operator-visible logs that exclude capabilities
```

The first remote feature should be:

```text
manual fetch of one already-reviewed artifact
```

It should not begin with:

```text
continuous bidirectional synchronization
silent LAN discovery
UPnP
public default bind
port scanning
```

# WebRTC laboratory direction

WebRTC may be useful as an optional courier between two otherwise unreachable Nodes.

A bounded experiment:

```text
Node A prepares one immutable reviewed source-list artifact
Node A creates signed offer metadata
Node B reviews expected fingerprint and artifact digest
signaling happens by copy/paste, QR, or explicit relay
one data channel transfers one bounded artifact
Node B verifies exact bytes
normal ProgRSS recipient review begins
connection is discarded
```

The experiment must make visible:

```text
signaling channel
STUN use
TURN relay use
relay operator
expiry
artifact digest
identity assumptions
```

Refuse:

```text
replay
identity mismatch
digest mismatch
partial transfer
duplicate completion
timeout
unexpected second artifact
```

WebRTC remains:

```text
LAB
optional
not discovery
not required synchronization
not scheduling infrastructure
```

# Research-derived interface boundary

The standards research used for Exchange reinforces:

```text
Web Share requires a visible user-triggered action.
Web Share availability varies.
canShare is advisory feature detection, not delivery proof.
Permissions Policy may disable web-share.
Copy must remain a fallback.

RSS autodiscovery uses typed alternate links.
The static publication should advertise exact native and feed artifacts.

RSS 2.0 remains a stable feed format.
ProgRSS innovation belongs around acquisition, source graphs,
review, authority, portability, and curation rather than a gratuitous RSS syntax replacement.
```

# Failure and refusal matrix

## Sender preparation

Refuse:

```text
missing folder
empty folder
ambiguous folder selector
malformed private backup
unsupported advanced folder algebra
oversized route
invalid public update URL
publication package inconsistency
```

Preserve:

```text
input file
library bytes
private state
browser authority
```

## Sender commit

Refuse:

```text
expired preview
used preview
preview digest mismatch
library digest mismatch
selected file changed
```

Preserve:

```text
preview evidence until normal expiry when appropriate
selected file
no partial handoff
```

## Recipient review

Refuse:

```text
malformed invitation
wrong host
wrong path
ordinary website Origin
expired handoff
revoked handoff
another Extension Origin already bound
invalid exchange document
unexpected automatic/network/write claim
```

Preserve:

```text
local library
no source contact
no artifact mutation
newly acquired permission released when leaving
```

## Artifact retrieval

Refuse:

```text
undeclared artifact
oversized artifact
byte-count violation
SHA-256 mismatch
wrong media type
invalid JSON
invalid feed
invalid source list
disconnected source-list graph
invalid signature
```

Preserve:

```text
local library
no follow
no import
no partial commit
```

## Final follow or adoption

Refuse:

```text
public origin permission denied
stale local library review
capacity exceeded
ambiguous branch
changed source-list review
invalid later-copy continuity
```

Explain:

```text
nothing was followed
nothing was added
why the action stopped
how to review again
```

# Prioritized checklist

Status language:

```text
DONE       implemented and exercised in this tree
VERIFY     implemented; native or human evidence still required
NEXT       highest-leverage next release work
AFTER      important after the next boundary
LAB        experimental; must not block ordinary use
NOT NOW    deliberately excluded from the ordinary product
```

## P0 — delivered in Exchange

- [x] **DONE** Dark fluorescent everyday reader remains default.
- [x] **DONE** Explicit persisted light theme remains available.
- [x] **DONE** Forced-colors removes decorative neon treatment.
- [x] **DONE** Ordinary reader remains primary.
- [x] **DONE** Advanced Workbench remains secondary.
- [x] **DONE** Node remains loopback-only.
- [x] **DONE** Node still reads one explicit private backup without mutation.
- [x] **DONE** Pairing remains summary-only and separate.
- [x] **DONE** Node Curate lists populated simple folders.
- [x] **DONE** Sender can supply optional curator wording.
- [x] **DONE** Sender can request a matching recent-updates artifact.
- [x] **DONE** Sender can supply a public source-list URL.
- [x] **DONE** Node prepares a native source list offline.
- [x] **DONE** Node prepares an optional recent-updates JSON Feed offline.
- [x] **DONE** Node prepares an optional script-free publication ZIP offline.
- [x] **DONE** Sender preview shows bounded contents.
- [x] **DONE** Sender preview shows exact private-state exclusions.
- [x] **DONE** Sender preview shows artifact sizes and SHA-256 digests.
- [x] **DONE** Sender preview shows available branches.
- [x] **DONE** Sender preview shows available recipient choices.
- [x] **DONE** Ten-minute preview object.
- [x] **DONE** Preview digest.
- [x] **DONE** Selected-library digest.
- [x] **DONE** Stale selected-library refusal.
- [x] **DONE** Thirty-minute in-memory handoff.
- [x] **DONE** Derived lookup storage for capability material.
- [x] **DONE** Exact literal 127.0.0.1 invitation parsing.
- [x] **DONE** No localhost scan, port scan, LAN discovery, or startup contact.
- [x] **DONE** Optional loopback access requested only from visible review.
- [x] **DONE** First review binds exact Extension Origin.
- [x] **DONE** Ordinary website Origins refused.
- [x] **DONE** Recipient sees route title, curator wording, counts, contents, exclusions, and choices.
- [x] **DONE** **Follow updates** is a separate visible door.
- [x] **DONE** **Add the complete route** is a separate visible door.
- [x] **DONE** **Take one branch** is a separate visible door.
- [x] **DONE** Recent-updates artifact retrieved only after Follow choice.
- [x] **DONE** Source-list artifact retrieved only after route or branch choice.
- [x] **DONE** Artifact byte bounds enforced.
- [x] **DONE** Artifact SHA-256 checked before parsing.
- [x] **DONE** Bounded local feed preview before follow.
- [x] **DONE** Durable Follow uses public feed URL, never expiring loopback artifact URL.
- [x] **DONE** Whole-route path reuses existing source-list review.
- [x] **DONE** Branch path reuses independent-excerpt review.
- [x] **DONE** New imported sources remain paused.
- [x] **DONE** Exact existing sources remain reusable.
- [x] **DONE** No listed-site contact during exchange review.
- [x] **DONE** Static publication page exposes the same three consequences.
- [x] **DONE** OPML remains separate feed-only fallback.
- [x] **DONE** Web Share is feature-detected and action-triggered.
- [x] **DONE** Copy remains fallback.
- [x] **DONE** Node owner can list and revoke active handoffs without seeing bearer material.
- [x] **DONE** Firefox sibling regenerated from canonical Extension source.
- [x] **DONE** `docs/NODE-EXCHANGE.md` documents the delivered contract.
- [x] **DONE** BOOTSTRAPROSE updated with protocol, UX, acceptance, and roadmap truth.
- [ ] **VERIFY** Native installed Chromium Exchange flow on an unmanaged host.
- [ ] **VERIFY** Native current Firefox and Firefox ESR Exchange flow.
- [ ] **VERIFY** Browser-owned loopback/local-network prompt composition.
- [ ] **VERIFY** Sender comprehension with unfamiliar people.
- [ ] **VERIFY** Recipient comprehension of all three consequences.
- [ ] **VERIFY** Screen-reader, Braille, voice-control, switch, high-zoom, forced-colors, and fatigue sessions.

## P0 — next: Merge Review

- [ ] **NEXT** Recognize a later copy of one complete adopted publication.
- [ ] **NEXT** Show curator-only changes.
- [ ] **NEXT** Show recipient-only changes.
- [ ] **NEXT** Show divergent conflicts.
- [ ] **NEXT** Show additions with paused-source consequence.
- [ ] **NEXT** Show removals while preserving local history.
- [ ] **NEXT** Treat acquisition-recipe changes as consequential.
- [ ] **NEXT** Distinguish curator wording from ProgRSS-computed consequences.
- [ ] **NEXT** Keep basic review in ordinary language.
- [ ] **NEXT** Keep raw three-way evidence under Advanced.
- [ ] **NEXT** Add sender and recipient human acceptance tasks.
- [ ] **NOT NOW** Last-write-wins.
- [ ] **NOT NOW** Silent server-wins or client-wins.

## P0 — parallel: one-writer operations

- [ ] **NEXT** Specify `progrss.node.operation.v1`.
- [ ] **NEXT** Require reviewed base-library digest.
- [ ] **NEXT** Require exact preview digest.
- [ ] **NEXT** Require random idempotency key.
- [ ] **NEXT** Require short expiry.
- [ ] **NEXT** Require atomic commit.
- [ ] **NEXT** Require new-library digest.
- [ ] **NEXT** Require durable receipt.
- [ ] **NEXT** Define exact safe replay.
- [ ] **NEXT** Refuse idempotency-key body mismatch.
- [ ] **NEXT** Select one first bounded write.
- [ ] **NOT NOW** Generic JSON Patch.
- [ ] **NOT NOW** Arbitrary filesystem write.

## P1 — Node-owned library

- [ ] **AFTER** Transactional Node storage.
- [ ] **AFTER** Reviewed import of a private backup.
- [ ] **AFTER** Original import retained as rollback evidence.
- [ ] **AFTER** Crash-safe commits.
- [ ] **AFTER** Portable snapshots.
- [ ] **AFTER** Append-only operation receipts.
- [ ] **AFTER** Source creation and pause/resume.
- [ ] **AFTER** Scheduled feed retrieval.
- [ ] **AFTER** Scheduled public page watching.
- [ ] **AFTER** Read and saved-state operations.
- [ ] **AFTER** Folder operations.
- [ ] **AFTER** Private labels.
- [ ] **AFTER** Saved views.
- [ ] **AFTER** Publication and signing.
- [ ] **AFTER** Later-copy merge commit.
- [ ] **AFTER** Bounded CLI JSON for every GUI operation.
- [ ] **NOT NOW** Mandatory Node for ordinary Extension use.

## P1 — sites without feeds

- [ ] **AFTER** Ask “What part of this page counts as an update?”
- [ ] **AFTER** Show examples before saving a watch.
- [ ] **AFTER** Propose repeated-page structures.
- [ ] **AFTER** Show matched and ignored regions.
- [ ] **AFTER** Preserve stability witnesses.
- [ ] **AFTER** Detect structure changes before misleading alerts.
- [ ] **AFTER** Keep browser-assisted capture for authenticated/rendered pages.
- [ ] **AFTER** Let Node schedule publicly reproducible recipes.
- [ ] **AFTER** Hand work back to browser when Node cannot reproduce context.
- [ ] **AFTER** Test dynamic pages.
- [ ] **AFTER** Test pagination.
- [ ] **AFTER** Test localized pages.
- [ ] **AFTER** Test partially authenticated pages.
- [ ] **NOT NOW** Arbitrary shared JavaScript as normal recipe format.

## P1 — organization

- [ ] **AFTER** Delayed re-finding studies.
- [ ] **AFTER** Human-curated folders for shareable routes.
- [ ] **AFTER** Private many-to-many labels.
- [ ] **AFTER** Explicit saved-query views.
- [ ] **AFTER** Preserve Unfiled as legitimate.
- [ ] **AFTER** Surface duplicate-source suggestions as reviewable proposals.
- [ ] **AFTER** Surface stale-source suggestions as reviewable proposals.
- [ ] **AFTER** Recover and independently verify Source Notes before claiming it.
- [ ] **NOT NOW** Opaque taxonomy.
- [ ] **NOT NOW** Engagement ranking.

## P2 — remote Nodes

- [ ] **AFTER** Explicit remote mode separate from loopback.
- [ ] **AFTER** TLS.
- [ ] **AFTER** Persistent server identity.
- [ ] **AFTER** Hostname allowlist.
- [ ] **AFTER** Rate and size bounds.
- [ ] **AFTER** Persistent revocation evidence.
- [ ] **AFTER** Public publication routes separate from private APIs.
- [ ] **AFTER** Manual remote artifact fetch before sync.
- [ ] **AFTER** Reverse-proxy acceptance.
- [ ] **AFTER** Self-hosting acceptance.
- [ ] **NOT NOW** Silent LAN discovery.
- [ ] **NOT NOW** UPnP.
- [ ] **NOT NOW** Public default bind.

## LAB — WebRTC courier

- [ ] **LAB** Signed offer/answer experiment informed by Vibechat.
- [ ] **LAB** Transfer exactly one reviewed source-list artifact.
- [ ] **LAB** Make signaling visible.
- [ ] **LAB** Make STUN visible.
- [ ] **LAB** Make TURN relay visible.
- [ ] **LAB** Compare copy/paste, QR, relay, and HTTPS friction.
- [ ] **LAB** Refuse replay.
- [ ] **LAB** Refuse identity mismatch.
- [ ] **LAB** Refuse digest mismatch.
- [ ] **LAB** Refuse partial transfer.
- [ ] **LAB** Refuse duplicate completion.
- [ ] **NOT NOW** WebRTC required for reading, publication, or synchronization.

# Acceptance evidence in this release tree

```text
PASS 55/55 Extension structural and static checks
PASS Chromium background harness
PASS Branch / Contents / Signpost / Edition shared-folder core harness
PASS generated Firefox background harness
PASS acquisition and redirect harness
PASS shared-vault conflict and failed-write harness
PASS rendered everyday reader
     dark and light themes
     Exchange three-door review
     follow-updates preview
     complete-route review
     branch review
     permission cleanup
     focus return
     keyboard and accessibility-tree regression checks
     44 px controls
     320 px enlarged-text reflow
PASS rendered Advanced Workbench

PASS 46/46 direct CLI library tests
PASS 28/28 source-list, publication, integrity, signature, and continuity tests
PASS 13/13 Node HTTP, pairing, Exchange, Origin, digest, stale-file, and revocation tests
PASS 25/25 launcher cases in independently bounded processes
PASS CLI doctor

PASS rendered Node UI
     capability fragment staging
     bearer API calls
     dark and light themes
     Today / Sources / Curate
     sender Exchange review
     exact three choices
     thirty-minute handoff creation
     copy fallback
     feature-detected Web Share
     active-handoff list and revocation
     secondary pairing
     honest disabled write/fetch capabilities

PASS 61 JavaScript syntax checks
PASS 14 Python compilation checks
PASS  3 POSIX-shell syntax checks
PASS 44 JSON parses
```

The Node HTTP boundary is exercised through real loopback HTTP tests.

The rendered Node browser test uses the exact shipped HTML, CSS, and JavaScript with controlled same-origin API interception because managed host policy blocks unpacked Extension installation and native loopback Chromium navigation in this environment.

Native boundaries remain explicit:

```text
SKIP installed Chromium Extension acceptance
  managed policy blocks unpacked Extension installation

SKIP native real-network Chromium lane
  managed policy blocks unpacked Extension installation

SKIP native Firefox and Firefox ESR
  no executable available in this environment
```

The aggregate launcher wrapper again retained descendant output pipes after completed assertions. It is not release evidence. All twenty-five command cases passed in individually bounded processes.

Automated focus, keyboard, reflow, forced-colors, accessibility-tree, and target-size checks remain regression evidence.

They are not represented as completed human:

```text
screen-reader
Braille
voice-control
switch-device
high-zoom
high-contrast
cognitive-fatigue
```

# Release boundary

```text
Extension version:               0.62.0
CLI version:                     0.62.0
Revision:                        rev0062
Codename:                        Exchange
Vault schema:                    17, unchanged
Private-backup schema:           progrss.private.v1
Node ready schema:               progrss.node.ready.v1
Node status schema:              progrss.node.status.v1
Node library schema:             progrss.node.library.v1
Node capabilities schema:        progrss.node.capabilities.v1
Node pairing schema:             progrss.node.pairing.v1
Node Exchange schema:            progrss.node.exchange.v1
Node Exchange preview schema:    progrss.node.exchange-preview.v1
Node bind:                       127.0.0.1 only
Pair invitation lifetime:        600 seconds
Exchange preview lifetime:       600 seconds
Exchange handoff lifetime:       1800 seconds
Exchange persistence:            running process memory only
Exchange Origin binding:         exact chrome-extension/moz-extension Origin
Exchange recipient artifact:     source list and optional recent updates only
Exchange library access:         none
Exchange writes:                 none
Pairing library access:          digest and bounded counts only
Node write capability:           none
Node source fetching:            none
Node merge commit:               none
Node-to-node:                    none
WebRTC:                          none
Account or cloud service:        none
Telemetry:                       none
Automatic Node contact:          none
Automatic synchronization:       none
Automatic import or follow:      none
Automatic publication upload:    none
Automatic publication apply:     none
```

# Archive evidence

<!-- ARCHIVE_EVIDENCE_BEGIN -->

The named release archive must open directly to:

```text
BOOTSTRAPROSE.md
CLI/
Extension/
```

It is built twice with:

```text
fixed member ordering
fixed timestamps
fixed compression settings
stored executable modes
no cache or bytecode files
```

The two candidate archives must be byte-identical.

The sealed archive must then pass:

```text
CRC verification
unique-member verification
safe relative-path verification
symlink refusal
nested-archive absence
private-backup absence
browser-profile absence
managed-policy-file absence
private-signing-key absence
clean-extraction byte comparison
clean-extraction executable-mode comparison
principal-suite replay from the extracted delivery bytes
```

The external release report records the exact archive filename, SHA-256, member count, regular-file count, directory-entry count, uncompressed bytes, ZIP bytes, suite counts, native-browser skips, and preserved legacy-carrier digest without introducing a self-referential archive hash into this bootstrap.

<!-- ARCHIVE_EVIDENCE_END -->

# Immediate next move

Do not add generic writes, remote bind, background polling, or a WebRTC button next.

The next coherent user-facing release is **Merge Review**:

```text
recognize one later complete publication
show what the curator changed
show what the recipient changed
show conflicts
show additions
show removals while keeping history
show acquisition-recipe changes as consequential
review in ordinary language
commit only after a separate one-writer operation contract exists
```

In parallel, specify the write contract before implementing it.

The project’s durable proposition is now:

```text
A person can follow a curator's updates,
adopt the curator's complete source route,
or safely take one branch,
without joining a platform,
without transferring private reading state,
and without confusing transport with synchronization authority.
```

---

# Previous bootstrap: rev0061 Handshake

# BOOTSTRAPROSE — ProgRSS rev0061 “Handshake”

**Release:** rev0061 · **Product version:** 0.61.0 · **Vault schema:** 17 (unchanged)
**Release maxim:** **One invitation. One review. No silent sync.**

## Current truth

Handshake advances the recoverable rev0060 **Nightstand** tree. Nightstand itself was built from the supplied, independently recoverable rev0058 **Branch** release. The earlier conversation describes a rev0059 **Source Notes** archive, but that archive was not supplied to this session. Handshake therefore does not silently reconstruct or claim Source Notes as delivered code.

The project now has three independently useful surfaces:

```text
ProgRSS Extension
  Browser-native capture and everyday reading.
  Dark fluorescent interface by default; explicit persisted light option.
  Ordinary choices first; Advanced Workbench remains secondary.

ProgRSS Node / CLI
  Python 3.11+ standard-library command suite and loopback web server.
  Opens one explicit private backup read-only.
  Can now issue, review, accept, inspect, and revoke a bounded Extension pairing.

Portable artifacts
  Private backup: one person's complete local library; keep private.
  Native source list: reviewable sources, watched-page recipes, folders,
  publication identity, integrity, and later-copy continuity.
  OPML: broad feed-only interchange.
  JSON Feed Edition: follow one curated update stream without adopting its sources.
  Static publication package: readable, script-free public handoff.
```

The Extension is not a mandatory thin client. The Node is not a hidden companion daemon. Either remains useful alone. Pairing is a deliberate capability relationship between one running Node process and one exact installed Extension Origin.

## What Handshake delivers

### 1. One visible Extension entry point

The ordinary **Add** view now includes:

```text
Connect a Node
Pair this extension with your running ProgRSS Node.
```

That action does not:

```text
scan localhost
probe ports
use mDNS
search the LAN
contact a remembered Node on startup
start a background reconnect loop
read items or source addresses
write either library
synchronize anything
```

The person starts the Node themselves, creates an invitation there, and pastes that exact invitation into the Extension.

### 2. A short-lived, one-use invitation

The authenticated Node administrator creates:

```text
http://127.0.0.1:PORT/#pair=INVITATION-CAPABILITY
```

The invitation:

```text
exists only in Node memory
expires after ten minutes
is accepted at most once
is stored by the Node only through a SHA-256-derived lookup key
is not logged
is not a cookie
is not sent through a query string
carries the secret in the URL fragment
```

The fragment is useful because ordinary HTTP navigation does not send it to the server. In Handshake the recipient is the Extension, which parses the fragment and sends the capability only in an explicit bearer-authenticated API request.

### 3. Strict invitation parsing

The Extension accepts only an invitation with this exact shape:

```text
scheme:       http
hostname:     127.0.0.1
port:         explicit, 1..65535
path:         /
query:        absent
username:     absent
password:     absent
fragment:     exactly one pair token
pair token:   bounded base64url alphabet and length
```

It refuses `localhost`, private-LAN addresses, public names resolving to loopback, extra fragment keys, credentials, query parameters, or an invitation without an explicit port. Handshake deliberately narrows the first contract to one device and one literal loopback address.

### 4. Browser-owned host access at the visible action

The delivered Extension manifest retains loopback access as optional host authority. The Extension requests:

```text
http://127.0.0.1/*
```

only inside the visible **Review Node** action.

The implementation begins the prior-authority check without awaiting unrelated work, then invokes the browser permission request within the same activation path. This avoids silently gaining authority at installation and reduces the risk of losing the user gesture before the browser-owned prompt.

When ProgRSS itself newly added this loopback authority, it attempts to remove that exact permission after:

```text
failed review
Cancel
successful Unpair
local Forget
```

Authority that existed before the pairing action is not removed.

A WebExtension match pattern is host-scoped, not TCP-port-scoped. The interface therefore still shows the exact reviewed `127.0.0.1:PORT` origin and validates every response against it.

### 5. First review binds the invitation to one exact Extension Origin

Review uses:

```text
GET /api/v1/pairing-review
Origin: chrome-extension://EXACT-ID
Authorization: Bearer INVITATION-CAPABILITY
```

Firefox uses its exact `moz-extension://…` Origin.

The Node accepts no ordinary website Origin on pairing routes. The first successful review binds the invitation to the exact Extension Origin that performed it. A different extension Origin cannot subsequently review or accept the same invitation.

Review does not return a durable grant. It returns only the bounded facts needed for a decision.

### 6. Review the consequences before pairing

The basic review shows:

```text
exact Node origin and port
process-lifetime session fingerprint
selected backup filename
source count
watched-page count
retained-update count
unread count
invitation expiry
what the pairing can do
what the pairing cannot do
```

The ordinary interface does not expose:

```text
source addresses
item titles or URLs
item text
folder names
page-watch selectors
browser permission stores
private signing keys
bearer capabilities
raw API documents
```

The advanced disclosure can show the complete session fingerprint, exact current and reviewed library digests, public pair ID, scope, and host-access boundary.

### 7. A session fingerprint, not a claimed identity

At Node start, the process creates a random 32-byte secret and exposes:

```text
sha256("ProgRSS/node-instance/v1" || NUL || process-secret)
```

as `instanceFingerprint`.

This supports continuity checks during one running process. It is explicitly:

```text
not signed
not stable across restart
not tied to an account
not tied to a machine certificate
not proof of a real-world person
not a remote TLS identity
```

The interface calls it a **session fingerprint**, not a person or device identity.

### 8. Acceptance is tied to the exact reviewed library bytes

Review records the portable SHA-256 digest of the selected private backup. Acceptance recomputes that digest.

When the file changed between review and acceptance, the Node returns HTTP 409 and does not consume the invitation. The same bound Extension may perform a fresh review and then decide again.

This closes a meaningful time-of-check/time-of-use gap:

```text
review copy A
file changes to copy B
accept copy B without seeing it       REFUSED
```

The accepted grant records `reviewedLibrarySha256`.

### 9. A separate, revocable, summary-only grant

Successful acceptance consumes the invitation and returns one new random pairing capability. The Node stores only its derived lookup key.

The delivered capability schema is:

```json
{
  "schema": "progrss.node.capabilities.v1",
  "readLibrarySummary": true,
  "readItems": false,
  "readSourceAddresses": false,
  "writeLibrary": false,
  "fetchSources": false,
  "publish": false,
  "merge": false,
  "nodeToNode": false,
  "webrtcCourier": false
}
```

The grant is:

```text
bound to one exact browser-extension Origin
bound to one reviewed library digest baseline
stored only in Node memory
valid only while the Node process runs
not accepted by the master library endpoint
not a cookie
not sent through a URL
revocable from either side
```

### 10. Explicit Check, Unpair, and Forget

The paired Extension does not poll.

**Check connection** performs one explicit request and verifies:

```text
same Node origin
same process session fingerprint
same exact Extension Origin in the pairing record
same summary-only capability set
current selected-file digest
reviewed selected-file digest
bounded current counts
```

When the selected backup changed after pairing, the interface says:

```text
Paired · file changed
The same Node session answered, but its selected library file changed after pairing.
Nothing was synchronized.
```

The relationship remains a summary grant. A changed file does not silently transfer its contents or widen the capability.

**Unpair** asks the running Node to revoke the grant, clears the local record, and releases loopback host permission when ProgRSS newly granted it.

**Forget this pairing locally** exists only for an unreachable Node. It warns that a still-running Node may retain a stale in-memory grant until the administrator revokes it or the process stops.

### 11. Node-side review and revocation

The Node administrator can:

```text
create one invitation
list active pairings
see public pair ID
see exact Extension Origin
see client label and version
see creation and last-seen times
see the reviewed library SHA-256
revoke one pairing
```

The administrator list never reveals pairing bearer capabilities or their lookup keys.

### 12. HTTP boundary

The Node continues to:

```text
bind only to 127.0.0.1
require the exact Host header for the selected port
refuse foreign ordinary-web Origins
accept pairing routes only from browser-extension Origins
send no Access-Control-Allow-Origin grant
use bearer authorization
use no ambient cookie or browser credential
set no-store and no-referrer policy
serve no remote asset
log no request target or Authorization header
read one explicit private backup without mutating it
```

The master capability and pairing capabilities are separate authority domains. A paired Extension cannot call `/api/v1/library`, stop the Node, create invitations, list other pairings, or revoke another pair by public ID.

## Schemas delivered

```text
progrss.node.ready.v1
progrss.node.status.v1
progrss.node.library.v1
progrss.node.capabilities.v1
progrss.node.pairing.v1
```

`progrss.node.pairing.v1` currently has these states:

```text
invitation
review
paired
admin-list
revoked
```

The state name does not imply a writable synchronization relationship.

## Pairing sequence

```text
Person starts Node for one explicit private backup
  ↓
Node administrator creates 10-minute invitation
  ↓
Person pastes exact invitation into Extension
  ↓
Extension validates literal loopback shape
  ↓
Visible Review action requests optional loopback host access
  ↓
Node binds first review to exact Extension Origin
  ↓
Extension shows session fingerprint, file, digest-derived facts, counts,
capabilities, expiry, and explicit non-capabilities
  ↓
Person chooses Pair read-only or Cancel
  ↓
Node recomputes selected-file digest
  ↓
Changed since review? Refuse and require fresh review
  ↓
Unchanged? Consume invitation and issue separate Origin-bound grant
  ↓
No polling; explicit Check or Unpair only
```

## Human problem statement

Pairing is not the product goal by itself. It is infrastructure for a human exchange system.

A person should not need to understand:

```text
Origin headers
bearer tokens
CORS
host match patterns
canonical JSON
digest baselines
publication IDs
folder graph closure
three-way merge algebra
```

They do need reliable answers to:

1. What am I connecting to?
2. What can it see?
3. What can it change?
4. Is this the same running session I reviewed?
5. Did the selected library change?
6. Will anything happen automatically?
7. Can either side disconnect?
8. Will my reading history or browser permissions travel?
9. Is this connection local, public, or remote?
10. What is the next useful thing I can accomplish after connecting?

Handshake answers the first seven within a deliberately small scope. It does not yet answer the final product question by enabling transfer or curation through the pairing.

## What Handshake does not claim

Handshake is not synchronization.

It does not deliver:

```text
item retrieval by the paired Extension
source-address retrieval by the paired Extension
Extension-to-Node mutations
Node-to-Extension mutations
background reconnect
continuous synchronization
conflict resolution
operation receipts
remote or LAN binding
TLS identity
long-lived device identity
account discovery
public sharing invitations
private sharing invitations between people
source-list merge through the Node API
WebRTC signaling or data channels
```

The Node still reads an exported private backup rather than owning a live transactional library.

## Why the boundary is this narrow

There are three separate authority problems that should not be collapsed:

```text
Transport authority
  May this Extension contact this loopback origin?

Read authority
  Which facts may it receive?

Mutation authority
  Which reviewed operation may change which library version?
```

Handshake solves a narrow transport and read relationship. It deliberately does not infer mutation authority from successful connectivity.

A generic writable endpoint would make these failures plausible:

```text
stale Extension overwrites newer Node state
replayed request repeats a destructive operation
Node and Extension both schedule the same source
shared source list imports browser authority
later curator copy erases local edits
connection loss leaves ambiguous partial work
```

The next writable work therefore needs a one-writer transaction contract, not CRUD endpoints.

## Browser-platform research boundary

Current browser platform direction reinforces the visible pairing action:

```text
Manifest V3 host access may be declared as optional_host_permissions and
requested at runtime so the person retains informed control.

Host permission is what allows extension pages or workers to fetch a matching
origin without ordinary cross-origin restrictions.

Local Network Access is becoming a separate browser-controlled permission
boundary. Current documentation distinguishes local-network and
loopback-network; Chrome 145 splits the earlier combined permission.

Managed browser policy can block unpacked extension installation or local
network behavior independently of ProgRSS code.
```

Consequences for ProgRSS:

```text
Do not assume optional host permission is the only prompt on every browser.
Do not hide loopback access behind startup behavior.
Do not claim native Chromium or Firefox pairing from a mocked renderer.
Keep a native acceptance matrix across current Chromium, Firefox, and ESR.
Keep native messaging as a separately installed fallback, not the default.
```

Research references are recorded in the release report and current project notes. The implementation remains conservative when browser behavior is evolving.

## Minimal-friction sharing direction

The project’s most valuable product concept remains the three understandable consequences:

```text
Follow updates
  Add one ordinary summary feed.
  Do not add the underlying sources.

Add the source route
  Review and adopt the curator’s complete source graph.
  New sources begin paused.
  A continuing later-copy relationship may be retained.

Take one branch
  Adopt one existing folder section and its descendants.
  Make an independent local route.
  Do not counterfeit the parent publication’s update identity.
```

The next recipient interface should expose those consequences from one invitation or publication page. File formats should remain subordinate:

```text
human choice first
artifact name second
schema and signature evidence in Advanced
```

### Sender flow to test

```text
Choose a folder or route
  ↓
Explain why it exists
  ↓
Choose what recipients may do
  Follow updates only
  Adopt complete route
  Take one branch
  ↓
Preview exactly what will be shared
  ↓
Create one bounded handoff
  Public static package or expiring private invitation
  ↓
Copy link / QR / file
```

### Recipient flow to test

```text
Open one handoff
  ↓
See curator, explanation, counts, and bounded contents
  ↓
Choose one consequence
  ↓
Review additions, reuse, paused sources, local changes, and omissions
  ↓
Commit once
  ↓
Get a clear place to find the resulting route
```

### What never travels silently

```text
read or unread state
saved state
retained article text
page observations and snapshots
HTTP validators
refresh schedules
browser permissions
cookies
private signing keys
unrelated local labels
unrelated folders
```

## Merge direction

A later-copy merge must be a reviewed semantic operation, not JSON concatenation.

For each stable source or folder identity:

```text
Only curator changed it
  Offer the curator version.

Only recipient changed it
  Keep the local version.

Both changed it differently
  Require a visible decision.

Curator removed it
  Keep local history and explain detachment.

Curator added it
  Add paused until reviewed authority is granted.

Acquisition recipe changed
  Treat as a new consequential source identity or explicit replacement review.

Curator note changed
  Keep local wording when both changed; do not erase local text silently.
```

The default interface should summarize the consequence. Advanced evidence may show stable IDs, canonical digests, signatures, recipe fields, and the three input versions.

## One-writer contract direction

Before any paired Extension can change Node state, define a reviewed operation envelope:

```json
{
  "schema": "progrss.node.operation.v1",
  "operationId": "random-idempotency-key",
  "kind": "one-bounded-kind",
  "baseLibraryDigest": "sha256-of-reviewed-copy",
  "previewDigest": "sha256-of-exact-plan",
  "expiresAt": "short-lived",
  "payload": {},
  "requestedBy": "bound-pair-id"
}
```

Required behavior:

```text
preview is read-only
commit requires the exact preview digest
base digest must still match
operation ID is idempotent
one Node process is the writer
commit is atomic
result has a receipt and new digest
partial output is not exposed
replay returns the existing receipt, not a second mutation
unknown operation kinds are refused
```

The first writable operation should be narrow and reversible. Candidates, in order:

1. Add one already reviewed feed or page-watch recipe paused.
2. Adopt one already reviewed source-list branch paused.
3. Mark one retained item read.

The first two better exercise sharing; the third is simpler but less strategic.

## Node-owned library direction

The Node cannot truthfully “do everything the Extension can do” while reading only an exported backup. A live Node library needs:

```text
transactional storage
portable snapshots
append-only operation receipts
one-writer locking
crash-safe commit
explicit schema migration
scheduler ownership
source fetch state
page-watch observations
publication keys separated from private reading state
```

A likely transition:

```text
Phase A
  Open a private backup read-only.          DELIVERED

Phase B
  Import a private backup into a Node-owned library after review.
  Keep the original file as rollback.

Phase C
  Extension performs reviewed bounded operations through pairing.

Phase D
  Node owns scheduling, feed acquisition, page watches, publication,
  recovery snapshots, and later-copy merge.

Phase E
  Optional remote access and node-to-node artifact exchange.
```

Do not make the Extension unusable without the Node. Offline and browser-only reading remains a valid product mode.

## Following sites without RSS

This remains mission-critical.

The acquisition ladder should prefer the least custom, most portable evidence:

```text
1. Existing RSS, Atom, or JSON Feed
2. Typed feed advertisement on the current page
3. Safe structured data already present in the response
4. Repeated-page structure proposal with examples
5. User-selected page region
6. Bounded declarative custom recipe
```

The basic question is:

> What part of this page counts as an update?

The review should show:

```text
example title
example destination
example retained text
matched page region
ignored material
number of current matches
whether the structure appears stable
whether the page requires the signed-in browser session
what will happen when the structure changes
```

### Extension and Node split

```text
Extension
  Capture the page the person is currently viewing.
  Use deliberately granted browser-session authority.
  Let the person point at or confirm the relevant region.
  Produce a bounded declarative recipe and examples.

Node
  Schedule public or independently accessible recipes.
  Preserve observations and repair evidence.
  Detect instability before emitting misleading updates.
  Ask for browser-assisted recapture when credentials or rendering are required.

Portable source list
  Carry recipe, context, and bounded examples.
  Never carry cookies, browser credentials, or implicit site authority.
```

### Custom behavior boundary

Do not make arbitrary unsandboxed shared JavaScript the normal extension mechanism. Shared executable extractors would combine:

```text
remote code execution
credential exposure
non-determinism
poor portability
hard-to-audit changes
unclear authorship
silent network behavior
```

A future advanced sandbox may be researched, but the default portable language should remain declarative, bounded, inspectable, and testable against stored specimens.

## Organization direction

Folders solve curation and publishable routes. They do not solve every retrieval problem.

The restrained model remains:

```text
Folders
  Human-curated hierarchical routes.
  Potentially publishable.
  One source may appear in several routes.

Local labels
  Many-to-many personal organization.
  Private by default.
  Never silently published.

Saved views
  Explicit reusable queries.
  Examples: unread + local; saved + research; page changes + repair needed.

Unfiled
  A legitimate state.
  Not an error requiring immediate cleanup.
```

The product test is delayed re-finding:

> Can a person find a source or update again a week later without remembering the exact folder they chose while being coached?

Do not optimize for the number of folders created during onboarding.

## Public publication and private pairing are different products

**Public publication** should remain:

```text
static webpage
native source list
OPML fallback
recent-updates feed
optional signature
no recipient account
no private Node API
no tracking
```

**Private pairing** should remain:

```text
expiring invitation
exact capability scopes
reviewed identity/session evidence
revocation
bounded audit evidence
no public indexing
```

Do not require authentication merely to read a public source list. Do not expose a private Node merely to publish one.

## Remote Node direction

A remote Node is not “change 127.0.0.1 to 0.0.0.0.” It requires:

```text
explicit remote mode
TLS
stable server identity
hostname allowlist
rate bounds
replay protection
invitation expiry
revocation persistence
account or key recovery decision
reverse-proxy behavior
clear public/private route separation
security update policy
```

Remote read-only artifact fetch should precede remote writes or continuous synchronization.

## WebRTC courier direction

WebRTC may be useful as an optional courier for one already reviewed artifact when neither Node has an ordinary reachable HTTPS endpoint.

A lab flow:

```text
Node A prepares one bounded signed artifact
Node A creates signed offer
Node B reviews fingerprint, artifact type, digest, and size
Offer/answer is exchanged manually, by QR, or through a visible relay
Data channel transfers exact bytes
Node B verifies digest and publication identity
Normal source-list or later-copy review begins
Connection is discarded
```

WebRTC still needs signaling and often STUN/TURN. It is not a magical serverless replacement for identity, revocation, merge semantics, or durable scheduling.

Vibechat remains useful evidence for:

```text
fragment capability staging
explicit action before network use
signed offer/answer envelopes
metadata review before transfer
separate relay and browser boundaries
```

ProgRSS must add durable-library semantics that a chat transfer does not need.

## GUI direction

The aesthetic remains:

```text
near-black canvas by default
bright cyan principal action and focus
restrained magenta and lime accents
thin luminous lines
no constant decorative animation
forced-colors removes decorative treatment
explicit light theme
```

Tasteful psychedelic treatment should reinforce structure rather than compete with reading. Good places for it:

```text
section boundaries
focus rings
connection states
route diagrams
curation maps
small identity/digest visualizations
```

Bad places for it:

```text
article body text
large continuously moving backgrounds
critical warning text
dense data tables
every button simultaneously
```

The basic interface continues to use progressive disclosure:

```text
consequence first
counts and plain-language explanation second
exact evidence behind Advanced
```

## Human acceptance questions introduced by Handshake

A participant who has not learned ProgRSS terminology should be able to answer:

1. Is the Node on this device or somewhere on the internet?
2. Did ProgRSS search the device for a Node?
3. What will the Extension receive after pairing?
4. Can the Extension read article titles or followed addresses?
5. Can either side change the other library?
6. What does the session fingerprint prove?
7. What happens if the Node restarts?
8. What happens if the selected file changes after review?
9. What is the difference between Unpair and Forget locally?
10. Did pairing start synchronization?

Observed wrong turns should change wording, hierarchy, or the boundary itself. They should not trigger more dashboard furniture.

## Prioritized checklist

Status language:

```text
DONE       implemented and exercised in this tree
VERIFY     implemented; native or human evidence still required
NEXT       highest-leverage next release work
AFTER      important after the next safety/comprehension boundary
LAB        experimental; must not block ordinary use
NOT NOW    deliberately excluded from the ordinary product
```

### P0 — delivered in Handshake

- [x] **DONE** Dark fluorescent everyday reader remains the default; light remains explicit and persisted.
- [x] **DONE** Ordinary reader remains primary; Advanced Workbench remains secondary.
- [x] **DONE** Node remains loopback-only and read-only over one explicit private backup.
- [x] **DONE** `progrss.node.capabilities.v1` is implemented with summary-only truth.
- [x] **DONE** `progrss.node.pairing.v1` is implemented for invitation, review, paired, list, and revoke states.
- [x] **DONE** One-use ten-minute pairing invitations.
- [x] **DONE** Invitation secret stored only through a derived lookup key in memory.
- [x] **DONE** First review binds the invitation to one exact Extension Origin.
- [x] **DONE** Acceptance refuses a selected file changed after review.
- [x] **DONE** Pairing response is verified against the exact Extension Origin.
- [x] **DONE** Separate process-lifetime pairing grant; master and pairing capabilities do not overlap.
- [x] **DONE** Paired Extension receives digest and bounded counts only.
- [x] **DONE** No items, addresses, writes, fetches, publishing, merge, node-to-node, or WebRTC capability.
- [x] **DONE** No startup Node request, localhost scan, LAN probe, mDNS, or background polling.
- [x] **DONE** Optional loopback host access requested inside visible Review action.
- [x] **DONE** Newly granted host access released on failed review, Cancel, Unpair, or local Forget.
- [x] **DONE** Explicit Check, Unpair, and local Forget.
- [x] **DONE** Changed selected file is visible as `Paired · file changed`; nothing synchronizes.
- [x] **DONE** Node administrator can list and revoke grants without seeing bearers.
- [x] **DONE** Updated CLI, Extension, Firefox, project, and protocol documentation.
- [x] **DONE** Added native Firefox and tired-reader pairing acceptance tasks.
- [x] **DONE** Rendered dark/light, review, paired, changed-file, Node invitation, and Node curation screenshots.
- [ ] **VERIFY** Native installed Chromium pairing on an unmanaged host.
- [ ] **VERIFY** Native current Firefox and Firefox ESR pairing.
- [ ] **VERIFY** Real browser-owned loopback/local-network prompt combinations.
- [ ] **VERIFY** Screen-reader, keyboard, high-zoom, forced-colors, voice, switch, and fatigue sessions.
- [ ] **VERIFY** Unfamiliar-person comprehension of session fingerprint, read-only, file changed, Unpair, and Forget.

### P0 — next: Exchange front door

- [ ] **NEXT** One recipient handoff exposes **Follow updates / Add route / Take one branch**.
- [ ] **NEXT** Consequences appear before artifact names and schemas.
- [ ] **NEXT** Node can select one existing simple folder and prepare a previewable source-list publication without mutating the library.
- [ ] **NEXT** Node can prepare the matching recent-updates Edition where retained material exists.
- [ ] **NEXT** Node GUI can download the existing script-free static package and native source-list artifact.
- [ ] **NEXT** Extension opens one shared handoff and preserves the three distinct decisions.
- [ ] **NEXT** Bounded contents review includes names, hostnames, routes, reuse, paused additions, and curator context.
- [ ] **NEXT** Sender and recipient see exactly what private state is excluded.
- [ ] **NEXT** Copy-link and QR appear only for an actual reachable publication or expiring private artifact invitation.
- [ ] **NEXT** Test sender and recipient separately with unfamiliar people.

### P0 — next: One-writer operation contract

- [ ] **NEXT** Specify `progrss.node.operation.v1` preview, precondition, idempotency, commit, and receipt semantics.
- [ ] **NEXT** Make one running Node the sole writer of its live library.
- [ ] **NEXT** Refuse stale base digest and stale preview digest.
- [ ] **NEXT** Return one durable receipt for commit and replay.
- [ ] **NEXT** Choose one narrow reversible first operation.
- [ ] **NEXT** Never expose a generic JSON Patch or arbitrary filesystem write API.

### P1 — Node-owned library and parity

- [ ] **AFTER** Import one reviewed private backup into a Node-owned transactional store.
- [ ] **AFTER** Keep original import file as rollback evidence.
- [ ] **AFTER** Transactional source creation and pause/resume.
- [ ] **AFTER** Scheduled feed retrieval with existing redirect, validator, size, and encoding bounds.
- [ ] **AFTER** Scheduled page watching with stability and repair evidence.
- [ ] **AFTER** Read and saved-state operations.
- [ ] **AFTER** Folder, local-label, and saved-view operations.
- [ ] **AFTER** Static publication and source-list signing from the Node UI.
- [ ] **AFTER** Manual later-copy review and merge.
- [ ] **AFTER** Recovery snapshots and append-only operation receipts.
- [ ] **AFTER** Every Node GUI action inspectable through bounded CLI JSON.

### P1 — sites without feeds

- [ ] **AFTER** Node owns scheduling for public page watches.
- [ ] **AFTER** Extension keeps browser-assisted capture for deliberately authorized pages.
- [ ] **AFTER** Repeated-structure candidate proposals with bounded examples.
- [ ] **AFTER** Visible “what counts as an update?” preview.
- [ ] **AFTER** Stability witnesses and portable repair specimens.
- [ ] **AFTER** Dynamic-page, pagination, localization, and authenticated-page tests.
- [ ] **AFTER** Explicit handoff when a Node cannot reproduce the signed-in browser view.
- [ ] **NOT NOW** Arbitrary unsandboxed shared JavaScript extractors.

### P1 — organization

- [ ] **AFTER** Delayed re-finding studies with unfamiliar users.
- [ ] **AFTER** Local labels, private by default.
- [ ] **AFTER** Saved views as explicit reusable queries.
- [ ] **AFTER** Preserve Unfiled as a legitimate resting state.
- [ ] **AFTER** Recover and independently verify rev0059 Source Notes before integration.
- [ ] **NOT NOW** Opaque automatic taxonomy, engagement ranking, or recommendation scoring.

### P2 — remote nodes

- [ ] **AFTER** Explicit TLS remote-bind mode separate from loopback.
- [ ] **AFTER** Persistent server identity and recovery decision.
- [ ] **AFTER** Hostname allowlist, rate bounds, expiring invitations, and audit evidence.
- [ ] **AFTER** Public publication and private API remain separate.
- [ ] **AFTER** Manual remote artifact fetch before continuous synchronization.
- [ ] **AFTER** Reverse-proxy and self-hosting tests.
- [ ] **NOT NOW** Silent LAN discovery, UPnP, or default public bind.

### LAB — WebRTC courier

- [ ] **LAB** Signed offer/answer prototype informed by Vibechat.
- [ ] **LAB** Transfer one bounded already-reviewed source-list artifact.
- [ ] **LAB** Make signaling channel, STUN, and TURN visible.
- [ ] **LAB** Compare copy/paste, QR, relay, and ordinary HTTPS friction.
- [ ] **LAB** Refuse identity mismatch, replay, duplicate, timeout, and partial transfer.
- [ ] **NOT NOW** WebRTC as required sync, discovery, or scheduling infrastructure.

## Acceptance evidence in this release tree

Principal implementation evidence before sealing:

```text
PASS 54/54 Extension structural and static checks
PASS Chromium background harness
PASS Branch / Contents / Signpost / Edition shared-folder core harness
PASS generated Firefox background harness
PASS acquisition and redirect harness
PASS shared-vault conflict and failed-write harness
PASS rendered everyday reader and Advanced Workbench
     dark default, explicit light option, pairing review,
     paired state, changed-file state, permission release,
     keyboard and accessibility-tree regression checks,
     44 px controls, and 320 px enlarged-text reflow

PASS 46/46 direct CLI library tests
PASS 28/28 source-list, publication, signature, and continuity tests
PASS 11/11 Node HTTP, security, invitation, digest, and revocation tests
PASS 25/25 launcher cases replayed in separately bounded processes
PASS CLI doctor

PASS rendered Node UI using the exact shipped HTML/CSS/JS with a controlled
     same-origin API interception: fragment staging, bearer API calls,
     dark/light themes, Today/Sources/Curate, invitation creation,
     active-pairing list, revocation controls, and honest disabled capabilities

SKIP native installed Chromium acceptance:
     managed policy blocks unpacked extension installation

SKIP native installed real-network Chromium lane:
     managed policy blocks unpacked extension installation

SKIP native Firefox and Firefox ESR:
     no executable available in this host environment
```

The Node HTTP boundary itself is exercised through real loopback HTTP tests. The intercepted browser renderer is not represented as native browser loopback acceptance.

The aggregate launcher wrapper again retained descendant output pipes on this host. It is not release evidence. Every one of its twenty-five command cases passed in an independently bounded process.

Automated focus, reflow, forced-colors, accessibility-tree, and target-size checks remain regression evidence. They are not represented as completed human screen-reader, Braille, voice-control, switch-device, high-zoom, high-contrast, or cognitive-fatigue acceptance.

## Release boundary

```text
Extension version:             0.61.0
CLI version:                   0.61.0
Revision:                      rev0061
Codename:                      Handshake
Vault schema:                  17, unchanged
Private-backup schema:         progrss.private.v1
Node ready schema:             progrss.node.ready.v1
Node status schema:            progrss.node.status.v1
Node library schema:           progrss.node.library.v1
Node capabilities schema:      progrss.node.capabilities.v1
Node pairing schema:           progrss.node.pairing.v1
Node bind:                     127.0.0.1 only
Invitation lifetime:           600 seconds
Invitation uses:               one successful pairing
Invitation persistence:        running process memory only
Pairing persistence:           running process memory only
Pairing Origin binding:        exact chrome-extension/moz-extension Origin
Pairing read capability:       selected filename, SHA-256, bytes, bounded counts
Pairing item access:           none
Pairing source-address access: none
Node write capability:         none
Node source fetching:          none
Node publication through API:  none
Node merge through API:        none
Node-to-node:                  none
WebRTC:                        none
Account or cloud service:      none
Telemetry:                     none
Automatic Node contact:        none
Automatic synchronization:     none
Automatic import/follow:       none
Automatic publication apply:  none
```

## Immediate next move

Do not add generic writes, remote bind, background polling, or a WebRTC button next.

The next coherent release is **Exchange**:

```text
one sender chooses a route
one bounded publication is prepared
one recipient sees three understandable doors
follow updates
add complete route
take one branch
review consequences
commit once
find the result
```

In parallel, specify the one-writer operation envelope. Do not allow paired mutation until stale-base, idempotency, atomic commit, replay, and receipt behavior are explicit and tested.

---

# Historical rev0060 bootstrap retained verbatim

The section below is the complete rev0060 Nightstand bootstrap. It remains for chain of custody and should not be read as the current release header.

# BOOTSTRAPROSE — ProgRSS rev0060 “Nightstand”

**Release:** rev0060 · **Product version:** 0.60.0 · **Vault schema:** 17 (unchanged)
**Release maxim:** **A quiet reader can glow. A useful node needs a front door.**

## Current truth

Nightstand is built from the supplied, independently recoverable rev0058 **Branch** tree. The previous chatlog describes a rev0059 **Source Notes** artifact, but that artifact was not present in the supplied files. Nightstand therefore does not silently claim Source Notes as delivered code. The historical rev0058 bootstrap remains below this current section so the chain of custody stays visible.

The project now has two user-facing runtimes and one shared protocol direction:

```text
ProgRSS Extension
  Browser-native capture and everyday reading.
  Dark fluorescent reader by default; existing light reader remains available.
  Ordinary choices stay primary. Advanced Workbench stays secondary.

ProgRSS Node / CLI
  A Python 3.11+ standard-library process and command suite.
  Nightstand adds the first web-server slice: loopback-only, capability-gated,
  read-only access to one explicit private backup.
  Later revisions will move durable scheduling, publication, merge, and pairing here.

Portable artifacts
  Private backups for one person's complete local library.
  Native ProgRSS source lists for reviewable routes, folders, page watches, and integrity.
  OPML for broad feed-reader interoperability.
  JSON Feed Editions for following one curated stream without adopting its sources.
```

The Extension is not becoming a thin, mandatory client. The Node is not becoming a hidden daemon. Each must remain useful independently; pairing must be explicit, reversible, and capability-scoped.

## What Nightstand actually delivers

### 1. Dark is now the ordinary reader

The everyday reader now opens in a dark theme whether or not the operating system is dark. One visible theme button switches to the existing light visual language and stores that preference in extension-local storage.

The dark language is intentionally restrained:

```text
near-black canvas
quiet blue-black raised surfaces
bright cyan for primary state and action
magenta as a secondary flare
acid-lime as a sparse signal line
one thin spectral line rather than animated decoration
subtle radial atmosphere rather than wallpaper
```

This revision does not add flashing, moving backgrounds, parallax, autoplay, or attention-seeking animation. `prefers-reduced-motion` remains respected, and forced-colors removes the decorative gradients and neon line.

The content hierarchy remains the same:

```text
Today
Sources
Add

Advanced Workbench
  explicit secondary destination
```

Dark mode is not used as a reason to expose advanced controls or reduce text contrast.

### 2. The first ProgRSS Node exists

New command:

```sh
progrss node serve PRIVATE-BACKUP.json
```

Optional flags:

```text
--port 0..65535   choose a loopback port; 0 asks the operating system
--open            open the capability URL in the default browser
--json            print one machine-readable progrss.node.ready.v1 record
```

The first slice binds only to:

```text
127.0.0.1
```

It reads one explicitly named, bounded `progrss.private.v1` file. It does not scan a browser profile or a directory for likely libraries.

The server prints a capability URL whose bearer secret is placed after `#`:

```text
http://127.0.0.1:PORT/#token=CAPABILITY
```

The fragment is not sent in the initial HTTP request. The shipped web UI stages the token in session storage, removes it from its visible history target, and sends it only in an `Authorization: Bearer` header for API calls.

Delivered API routes:

```text
GET  /api/v1/status
GET  /api/v1/library
POST /api/v1/stop
```

Delivered web views:

```text
Today    read retained updates from the selected copy
Sources  inspect feeds and watched pages in that copy
Curate   see the delivered boundary and the next pairing/share work
```

### 3. The node advertises absence, not aspiration

`/api/v1/status` declares the exact current capability set:

```json
{
  "readLibrary": true,
  "writeLibrary": false,
  "fetchSources": false,
  "publish": false,
  "pairExtension": false,
  "nodeToNode": false,
  "webrtcCourier": false
}
```

The UI may explain future directions, but it contains no fake pairing button, dead share control, pretend merge action, or disabled WebRTC ceremony. Advanced node facts sit behind one disclosure.

### 4. Current node security boundary

The Nightstand node:

```text
binds only to loopback
requires an exact Host header
refuses a foreign Origin
emits no Access-Control-Allow-Origin grant
requires the bearer capability for every library API
requires same-origin POST for stop
serves only three fixed static assets
uses a restrictive Content Security Policy
uses no remote script, stylesheet, font, image, frame, or service worker
fetches no source
writes no library file
changes no read or saved state
opens no browser profile
starts no WebRTC connection
publishes nothing to the LAN or internet
```

The selected backup is re-read and validated for each API snapshot so replacement or corruption is reported rather than hidden behind stale memory.

## Product direction: what humans actually need

The default product must answer a small number of ordinary questions quickly:

```text
What is new?
Where did it come from?
Why am I seeing it?
Can I read it later?
Can I stop or repair this source?
Can I follow what another person curated without importing a mystery pile?
Can I share my route without sharing my private reading history?
Can I understand what will merge before anything changes?
```

The next design sessions must observe tasks, not ask people whether they “like RSS.” The highest-value human studies are:

```text
1. Follow a normal feed from a site.
2. Follow a useful page that has no feed.
3. Accept a friend's complete route, follow only its updates, or take one branch.
4. Understand which sources are new, reused, changed, paused, or removed.
5. Merge a newer copy after both curator and recipient changed something.
6. Find a source again after a month without remembering its exact folder.
7. Recover from a broken page watch without seeing selector syntax.
8. Pair an Extension with a Node and correctly explain what authority moved.
9. Stop sharing or unpair without losing the local library.
10. Perform the same tasks with keyboard, high zoom, forced colors, and assistive technology.
```

Research questions must be recorded in behavioral language:

```text
Did the person choose the intended door?
Could they predict the consequence before acting?
Could they recover after a wrong turn?
Did they believe a preview already followed or imported something?
Did they believe a node link exposed private reading state?
Did they understand whether a merge kept local edits?
Did organization help re-finding, or merely create maintenance work?
```

## Minimal-friction sharing model

The intended recipient flow is one link and one review, not a setup guide.

A shared capability or publication should resolve to a bounded front door with three mutually understandable actions:

```text
Follow updates
  Add one ordinary summary feed.
  Do not add the curator's underlying sources or folders.

Add source route
  Review and adopt the complete source graph.
  Reuse exact local sources; start new sources paused.

Take one branch
  Review one existing folder section as an independent local excerpt.
  Do not pretend it remains signed or update-linked to the parent.
```

A recognized later copy changes the third decision from “import” to “merge” and shows:

```text
what the curator changed
what you changed locally
what can be combined automatically
what conflicts require a choice
what will remain local and private
```

The review must use names, sites, source types, folder paths, and plain consequences. Full addresses, selectors, validators, signing bytes, graph identifiers, schedules, and permission state remain advanced evidence.

## Node pairing direction

The Extension-to-Node path should be developed in four gates.

### Gate A — local capability discovery

The Node prints and can display a short-lived pairing capability. The Extension receives it only through an explicit action such as paste, QR, or “Open in ProgRSS.” No port scan, LAN scan, broadcast discovery, or silent localhost probing.

The pairing record should contain at least:

```text
schema and protocol version
node origin
short-lived bearer capability
node instance key fingerprint
requested capability set
expiry
human-readable node name
```

### Gate B — requested authority review

The Extension must state exactly what the Node is asking to do:

```text
read a portable copy
receive newly captured page-watch recipes
schedule source checks
store retained text
publish a selected route
return new items to the Extension
```

Each capability is separately grantable and revocable. “Pair” is not one undifferentiated super-permission.

### Gate C — one-writer transaction model

Do not synchronize browser IndexedDB and a Node file by copying the newest blob over the oldest. Use explicit operations and revisions:

```text
base portable digest
reviewed operation list
current revision check
three-way merge for shared publications
append-only evidence for completed trust operations
transaction result and new digest
```

For an initially paired library, one side should be the authoritative writer for durable source state. The other side submits reviewed operations. This avoids two writable databases silently drifting and then relying on timestamps.

### Gate D — remote reachability

Only after local pairing and merge semantics are proven should the Node add a remote front door. Remote access requires an explicit deployment mode with TLS, host allowlists, capability expiry, rate bounds, auditable invitations, and a clear distinction between:

```text
private paired node
public read-only publication
one-time transfer invitation
ongoing follow relationship
```

A writable Node must never become reachable merely because `--port` was supplied.

## What Vibechat contributes

The supplied Vibechat tree demonstrates several useful patterns that Nightstand adopts as design evidence rather than blindly copying its product assumptions:

```text
put bearer capabilities in URL fragments rather than request paths
stage a capability locally and remove it from the visible URL
require an explicit human action before the first network contact
bind local services narrowly and validate Host and Origin
use exact capability claims rather than one ambient login
sign WebRTC offers and answers when identity continuity matters
keep relay or courier metadata distinct from application content
exercise browser, native, and relay paths independently
```

ProgRSS differs in one crucial way: the durable object is a source-and-reading library with mergeable curation state, not merely a conversation transport. Its pairing protocol must therefore define ownership, merge, history, and revocation before adding transport cleverness.

## WebRTC position

WebRTC remains a **lab courier**, not the primary Node protocol.

Useful eventual cases:

```text
one-time transfer when neither node is publicly reachable
manual offer/answer exchange over an existing trusted channel
direct transfer of a bounded signed source-list artifact
temporary data channel after both sides review identity fingerprints
```

Non-negotiable limitations:

```text
WebRTC still needs signaling to exchange offers and answers
without STUN or TURN it is generally limited to local peers
some NAT and firewall combinations require a TURN relay
browser lifecycle and background suspension make it poor durable sync infrastructure
a data channel does not itself define authorization, merge semantics, or identity
```

The ordinary path should be HTTPS capability links and conventional authenticated requests. WebRTC may optimize one reviewed transfer later; it must not become required for sharing.

## Following sites without RSS

This remains mission-critical and should become a first-class Node responsibility while the Extension remains the best capture tool.

The intended ladder is:

```text
1. Use an advertised RSS, Atom, or JSON Feed when available.
2. Discover unadvertised but conventional feed endpoints conservatively.
3. Let a person choose one meaningful page region.
4. Offer selector-free repeated-card or main-text proposals.
5. Preview exactly what counts as an item or meaningful change.
6. Save a versioned watch recipe only after review.
7. Run checks on the Node with per-host cadence, validators, and bounded politeness.
8. Stop on structural breakage before generating mass-removal or rewrite alerts.
9. Repair from bounded examples without exposing CSS unless Advanced is opened.
```

Programmatic assistance may suggest candidates from semantic HTML, repeated DOM structure, headings, links, microformats, JSON-LD, and stable text regions. It must never claim certainty from a selector score alone. The human chooses the region and sees examples before the watch begins.

Future watch recipes should record evidence that helps repair:

```text
selected examples
structural witnesses
text-shape bounds
link/title extraction intent
ignored dynamic regions
recipe version
last known good specimen digest
```

They should not store arbitrary executable page code. Custom JavaScript extractors would create an extension and server execution boundary too dangerous for the basic product. If ever supported, they belong in an isolated advanced sandbox with an explicit trust label and no ambient credentials.

## Feed organization direction

Folders are valuable for stable routes and sharing. They are insufficient for every re-finding task. ProgRSS should converge on a restrained hybrid:

```text
Folders
  Human-readable, ordered curation routes.
  Portable in ProgRSS source lists and partly portable through OPML.

Labels
  Optional local facets that can cross folder boundaries.
  Not automatically published.

Saved views
  Explicit queries such as Unread + Local + Climate.
  Computed locally; not presented as folders unless materialized.

Inbox / Unfiled
  A valid resting state, not a failure requiring immediate organization.

Source notes
  Curator explanation of why a source belongs in one folder relationship.
  Recover rev0059 before claiming this as delivered.
```

The everyday reader should show at most one folder scope and a few familiar state filters. Label management, query builders, bulk moves, aliases, and collection algebra remain Advanced until observed need proves otherwise.

Organization acceptance should measure re-finding after time, not merely whether a participant can create a folder during a coached session.

## Prioritized checklist

Status vocabulary:

```text
DONE       implemented and exercised in this tree
VERIFY     implemented; complete release replay still required
NEXT       highest-leverage next revision work
AFTER      important after the next safety or comprehension boundary
LAB        experimental; must not block ordinary use
NOT NOW    deliberately excluded from the basic product
```

### P0 — delivered in Nightstand

- [x] **DONE** Dark fluorescent everyday reader is the default.
- [x] **DONE** Existing light reader remains one explicit persisted option.
- [x] **DONE** Forced-colors removes decorative neon treatment.
- [x] **DONE** Ordinary reader remains the default; Advanced Workbench remains secondary.
- [x] **DONE** `progrss node serve` starts a loopback-only Node for one explicit private backup.
- [x] **DONE** Capability token is carried in the fragment and required as a bearer credential for API data.
- [x] **DONE** Exact Host and Origin checks; no CORS grant.
- [x] **DONE** Read-only Today, Sources, and Curate Node views.
- [x] **DONE** Node status reports unimplemented capabilities as false.
- [x] **DONE** Unit coverage for authentication, host/origin refusal, security headers, snapshot bounds, and no input mutation.
- [x] **DONE** Rendered browser coverage and screenshots for Extension dark/light and Node dark/light/curation surfaces.
- [x] **DONE** Complete Extension and CLI release replay from the sealed delivered bytes.
- [ ] **VERIFY** Native installed Chromium and Firefox/Firefox ESR acceptance on an unmanaged host.
- [ ] **VERIFY** Real screen-reader, high-zoom, forced-colors, keyboard, switch, and fatigue sessions.

### P0 — next revision: Pairing Contract

- [ ] **NEXT** Specify `progrss.node.capabilities.v1` and `progrss.node.pairing.v1` before adding a writable route.
- [ ] **NEXT** Add short-lived pairing capabilities with expiry and node-key fingerprint.
- [ ] **NEXT** Add one explicit Extension action to paste/review a Node capability URL.
- [ ] **NEXT** Request loopback host access only inside that action and explain the browser-owned decision.
- [ ] **NEXT** Implement read-only pairing first: Node summary, identity fingerprint, library digest, and capability list.
- [ ] **NEXT** Add unpair/revoke on both sides and prove that local libraries remain usable.
- [ ] **NEXT** Define a one-writer operation protocol before any Node mutation.
- [ ] **NEXT** Execute unfamiliar-person pairing comprehension tasks.

### P0 — next revision: Human sharing front door

- [ ] **NEXT** Make one shared link open the three-door review: follow updates, add route, take branch.
- [ ] **NEXT** Add a later-copy merge review with local/curator/combined outcomes.
- [ ] **NEXT** Use plain source names, hostnames, folder paths, and consequences by default.
- [ ] **NEXT** Keep raw recipes, selectors, digests, keys, and full addresses behind Advanced evidence.
- [ ] **NEXT** Add copy-link / QR invitation only after capability expiry and revocation semantics exist.
- [ ] **NEXT** Test sender and recipient mental models separately.

### P1 — Node parity with the Extension

- [ ] **AFTER** Open and validate a live Node-owned library format rather than only an exported backup.
- [ ] **AFTER** Add transactional source creation and pause/resume.
- [ ] **AFTER** Add feed checks with existing bounded redirect, validator, retry, and host-gap rules.
- [ ] **AFTER** Add page-watch scheduling and repair evidence.
- [ ] **AFTER** Add read/saved mutations as reviewed operations.
- [ ] **AFTER** Add folder and local-label organization.
- [ ] **AFTER** Add source-list publication and static-site generation from the Node UI.
- [ ] **AFTER** Add manual later-copy check and merge.
- [ ] **AFTER** Keep every Node capability independently inspectable through CLI JSON.

### P1 — non-RSS acquisition

- [ ] **AFTER** Move scheduled page watching to the Node while keeping browser capture available.
- [ ] **AFTER** Add semantic/repeated-structure candidate proposals with bounded examples.
- [ ] **AFTER** Add a visible “what will count as an update?” preview.
- [ ] **AFTER** Add stability witnesses and repair specimens to portable recipes where safe.
- [ ] **AFTER** Test dynamic, localized, paginated, and partially authenticated sites.
- [ ] **NOT NOW** Arbitrary unsandboxed custom JavaScript extractors.

### P1 — organization

- [ ] **AFTER** Test folder re-finding after a delay with unfamiliar users.
- [ ] **AFTER** Prototype local labels without publishing them by default.
- [ ] **AFTER** Prototype saved views as explicit queries rather than magical folders.
- [ ] **AFTER** Preserve Unfiled as a legitimate state.
- [ ] **AFTER** Recover and independently verify rev0059 Source Notes before integrating it.
- [ ] **NOT NOW** Automatic taxonomy, engagement ranking, or opaque recommendations.

### P2 — remote nodes

- [ ] **AFTER** Add an explicit TLS remote-bind mode separate from loopback serve.
- [ ] **AFTER** Add hostname allowlist, rate bounds, expiring invitations, and audit log.
- [ ] **AFTER** Distinguish public read-only publication from private paired API.
- [ ] **AFTER** Add manual node-to-node artifact fetch before continuous synchronization.
- [ ] **AFTER** Test reverse proxies and self-hosted deployments without assuming one cloud.
- [ ] **NOT NOW** Silent LAN discovery, UPnP port opening, or default public bind.

### P2 — WebRTC courier

- [ ] **LAB** Reuse Vibechat-style signed offer/answer envelopes in an isolated prototype.
- [ ] **LAB** Transfer one bounded, already reviewed source-list artifact over a data channel.
- [ ] **LAB** Make signaling channel and TURN use visible.
- [ ] **LAB** Compare manual copy/paste, QR, relay, and ordinary HTTPS friction.
- [ ] **LAB** Abort safely on identity mismatch, timeout, duplicate transfer, and partial data.
- [ ] **NOT NOW** WebRTC as required sync, discovery, or durable scheduling infrastructure.

## Research-derived architecture decisions

Nightstand adopts these decisions for subsequent work:

```text
Progressive disclosure remains the default interface strategy.
Consequential input must not trigger an unexplained context change.
Plain language and fewer simultaneous choices are product requirements, not polish.
Extension host access remains optional and requested in a visible action.
Public-web-to-loopback access cannot be assumed frictionless or stable across browsers.
Native messaging remains a possible packaged bridge but carries installation and registration cost.
WebRTC requires signaling and often STUN/TURN; it is not a serverless universal path.
Folders and labels each solve different re-finding problems; a restrained hybrid merits testing.
```

## Acceptance evidence in this release tree

The complete tree was replayed before sealing and the same principal lanes were replayed from a clean extraction of the deterministic release archive:

```text
PASS 53/53 Extension structural and static checks
PASS Chromium background harness
PASS Branch / Contents / Signpost / Edition shared-folder core harness
PASS generated Firefox background harness
PASS acquisition and redirect harness
PASS shared-vault conflict and failed-write harness
PASS rendered everyday reader and Advanced Workbench
     dark default, explicit persisted light option, forced colors,
     keyboard and accessibility-tree regression checks,
     44 px controls, and 320 px enlarged-text reflow

PASS 46/46 direct CLI library tests
PASS 28/28 source-list, publication, signature, and continuity tests
PASS  6/6 Node HTTP/security tests
PASS 25/25 launcher cases in separately bounded processes
PASS CLI doctor, Python compilation, and JavaScript syntax checks

PASS rendered Node UI using the exact shipped HTML/CSS/JS with an intercepted
     same-origin API: fragment staging, bearer calls, Today, Sources, Curate,
     dark/light themes, and honest future-capability labels

SKIP native HTTP loopback navigation in managed Chromium:
     ERR_BLOCKED_BY_ADMINISTRATOR
```

A continuity fixture formerly compared a live first-edition timestamp with a hard-coded 2026 “later” timestamp. It now derives the second timestamp as the first accepted issue time plus one second, so rollback protection and the test remain correct after the calendar advances.

The aggregate command-line unittest wrapper is still not release evidence because descendant output pipes can remain open after completed assertions. Every one of its twenty-five cases passed in an independently bounded process instead.

The rendered intercepted Node lane is not represented as native loopback acceptance. The real HTTP server boundary is covered separately through direct HTTP tests. Native browser pairing remains future work.

## Release boundary

```text
Extension version:           0.60.0
CLI version:                 0.60.0
Revision:                    rev0060
Codename:                    Nightstand
Vault schema:                17, unchanged
Private-backup schema:       progrss.private.v1
Node ready schema:           progrss.node.ready.v1
Node status schema:          progrss.node.status.v1
Node library schema:         progrss.node.library.v1
Node bind:                   127.0.0.1 only
Node write capability:       none
Node source fetching:        none
Node publication:            none
Extension pairing:           none
Node-to-node:                none
WebRTC:                      none
Account or cloud service:    none
Telemetry:                   none
Automatic import/follow:     none
Automatic publication apply:none
```

## Immediate next move

Do not add a remote bind, writable endpoint, WebRTC button, or synchronization loop next.

The next coherent revision is **Pairing Contract**:

```text
specify capabilities
issue an expiring local pairing invitation
let the Extension review it
request loopback access in that gesture
show node identity and library digest
pair read-only
revoke cleanly
observe unfamiliar humans
```

Only after that interaction is understood should ProgRSS allow the Extension to submit one reviewed operation to the Node.

---

# Historical verified baseline retained verbatim

The section below is the supplied rev0058 Branch bootstrap. It remains for provenance and should not be read as the current release header.

# BOOTSTRAPROSE — ProgRSS rev0058 “Branch”

**Release:** rev0058 · **Product version:** 0.58.0 · **Vault schema:** 17 (unchanged)

## Governing rule

**Take one branch without claiming the whole tree.**

ProgRSS remains two independent but interoperable products:

```text
Extension
  A local-first everyday reader in Chromium’s Side Panel and Firefox’s Sidebar.

CLI
  A Python 3.11+ standard-library tool for explicit files, feeds, page-watch
  evidence, portable source lists, publication audits, and private backups.
```

The everyday interface is for tired humans. The complete, understandable action stays visible. A less common choice may sit behind one disclosure, but it must still explain its consequences before it changes anything.

## Why this revision exists

Relay, Contents, and Continuity made a complete source list inspectable, importable, shareable, and manually updatable. That model is correct when a person wants the curator’s whole route.

A useful source list can also contain one section a person wants and several sections they do not. The only earlier alternatives were:

```text
Add the whole source list
or
Do not add it
```

A source-by-source picker would solve that problem by creating a small import application: checkboxes, inherited folder relationships, duplicate rules, and unclear publication continuity. Branch instead offers one constrained choice:

```text
Add source list                         default
Add just one folder section (optional) secondary disclosure
```

The selected unit is an existing simple folder branch—not an arbitrary pile of recipes.

## One folder branch, reviewed before mutation

After a native source-list document passes its existing schema, connected-graph, digest, and optional-signature checks, its ordinary review may offer populated nested sections.

A selected branch contains exactly:

```text
the selected folder
all simple descendant folders
only sources referenced by that branch
```

The review shows the resulting source names, sites, feed/page types, folder routes, and new/reused consequences before the import action becomes available.

Empty sections are not offered. The selector lists folder paths and bounded source counts so duplicate titles remain understandable. The Extension uses one native disclosure and one native select; it does not add:

```text
a checkbox tree
a source-by-source picker
an import wizard
a folder editor
a filter builder
a new navigation destination
a settings page
```

The complete source list remains the default and keeps its existing primary action: **Add source list**.

## The excerpt is local, not a counterfeit publication

The parent document’s digest and optional signature authenticate the exact parent document that was checked. A subset derived locally is not that signed document.

Branch therefore labels the selected result as an **independent local folder** and applies these boundaries:

```text
No parent-publication origin is stored on the excerpt
No future-copy address is attached
No signer-continuity relationship is claimed
No later parent publication can overwrite the excerpt
No automatic polling or update is introduced
```

The review still shows the parent curator, note, and signature result as evidence about the checked source list, with explicit language that the locally selected excerpt is not separately signed.

A person who wants the curator’s continuing publication relationship can return to **Review the full source list** and import the complete list instead.

## Existing source and privacy rules remain

Selective adoption reuses Relay’s existing transaction plan:

```text
Exact existing RSS addresses are reused
Exact existing page-watch recipes are reused
Duplicate incoming recipes collapse
New sources begin paused
New source IDs and folder IDs are local
Capacity is checked during review and again at commit
The vault revision is checked again at commit
Listed sites are not contacted
No site permission is requested
```

The excerpt carries no:

```text
read or unread state
saved state
retained article text
page observations or snapshots
HTTP validators
source activity or schedule
browser site authority
private signing key
parent update baseline
```

Advanced collection algebra remains refused rather than flattened into a convincing but inaccurate basic folder.

## Bounded branch counts

The computed contents report advances to:

```text
progrss.shared-folder.contents.v2
```

Each folder row now includes:

```text
isRoot
branchSources
branchFeeds
branchPageWatches
branchFolders
```

Counts are unique within the branch, so one source referenced by two descendant folders is still one source. The report remains bounded by the source-list format and performs no network request or write.

The ordinary reader continues to omit complete source addresses, selectors, filters, thresholds, validator values, schedules, signature bytes, browser permission state, and graph identifiers.

## Strong offline CLI parity

CLI 0.58.0 keeps whole-list import as the default:

```text
progrss workspace import-bundle \
  LIBRARY.json SHARED-FOLDER.json \
  --output LIBRARY-WITH-LIST.json
```

One explicit option selects a branch:

```text
progrss workspace import-bundle \
  LIBRARY.json SHARED-FOLDER.json \
  --folder "Neighborhood reading › Public meetings" \
  --output LIBRARY-WITH-SECTION.json
```

`--folder` accepts:

```text
an exact folder ID
a full folder path
an unambiguous folder title
```

Ambiguous titles are refused with available paths. Missing and empty sections are refused. Selecting the root is equivalent to the normal complete import.

The CLI recomputes the branch from the exact checked document, applies the same recipe-reuse and paused-new-source rules, strips browser-local coordination fields from the new backup, writes through a synchronized sibling temporary file, and refuses overwrite.

It performs:

```text
No DNS lookup
No network request
No browser-profile read
No permission-store read
No input mutation
```

The resulting summary identifies the selected path, parent publication ID as review evidence, full-list counts, and the explicit facts:

```text
independentExcerpt: true
updateLinked: false
manualUpdateCheck: false
```

`bundle contents` emits the v2 per-branch counts offline and read-only.

## Chromium and Firefox remain native siblings

Chromium keeps:

```text
native Side Panel
disposable Manifest V3 service worker
Offscreen parser document
revision-guarded IndexedDB vault
optional per-origin host access
```

Firefox keeps:

```text
native Sidebar
ordered non-persistent background scripts
direct DOM parsing
browser namespace
same vault and transaction semantics
```

The deterministic generator copies the canonical shared runtime into `Extension/Firefox/`. Generated files must match their canonical sources byte-for-byte.

## Data and authority boundary

```text
Extension version:          0.58.0
CLI version:                0.58.0
Revision:                   rev0058
Codename:                   Branch
Vault schema:               17, unchanged
Private backup schema:      progrss.private.v1
Shared-folder schemas:      progrss.bundle.v1/v2/v3
Computed contents schema:   progrss.shared-folder.contents.v2
Required host access:       none
Optional host surface:      unchanged
New manifest permissions:   none
Automatic import:           none
Automatic publication poll: none
Automatic update apply:     none
Account or remote service:  none
Telemetry:                  none
Native companion:           none
Daemon or localhost bridge: none
Private-key export:         none
```

Chromium permissions remain:

```text
activeTab
alarms
offscreen
scripting
sidePanel
storage
webRequest
```

Firefox permissions remain:

```text
activeTab
alarms
scripting
storage
webRequest
```

## Acceptance requirements

The release is not complete merely because one happy branch imports. Acceptance must cover:

```text
Complete-list default remains unchanged
Populated nested branch selection
Selected folder and descendant closure
Sources shared across descendants counted once
Existing-source reuse
New-source paused state
No parent sharedFolderOrigin on the excerpt
No future-copy action on the excerpt
Parent signature described without subset-signature overclaim
Empty section refusal
Missing section refusal
Ambiguous CLI title refusal
Root selection remaining a complete import
Capacity and stale-review refusal
No listed-site contact
No browser-permission request
Exact return to full-list review
Keyboard, forced-colors, target-size, and enlarged-text rendering
Firefox generated-package parity
```

The packaged native Firefox and tired-reader protocols additionally ask unfamiliar participants to explain the difference between:

```text
Add source list
Add this section
Independent local folder
Future copies of the parent publication
```

Those protocols are execution plans, not claims that human or native Firefox acceptance has occurred.

## Delivered-byte verification

The final named archive must be built deterministically, rebuilt independently, extracted into a clean directory, and tested from the extracted delivery bytes. The verification report records the exact suite counts, delivered-file count, archive members, byte size, SHA-256, and every native-browser skip.

Required artifact roots:

```text
BOOTSTRAPROSE.md
CLI/
Extension/
```

The archive must contain no unsafe paths, duplicate members, symlinks, nested release archives, browser profiles, managed-policy files, private backups, caches, Python bytecode, or private signing keys.

## Honest acceptance boundary

Automated DOM, keyboard, accessibility-tree, target-size, reflow, and forced-colors checks are regression evidence. They are not completed human screen-reader, Braille, voice-control, switch-device, high-zoom, high-contrast, or cognitive-fatigue acceptance.

Generated Firefox package and background-harness success are not native Firefox installation, Sidebar, permission-prompt, event-page-unload, restart, AMO, or assistive-technology acceptance.

A parent signature does not authenticate a curator name or source safety. A branch imported from a signed parent is not separately signed. A local excerpt does not receive continuing publication authority by implication.

## Next boundary

The next coherent work is acceptance-led:

```text
Run the exact full-list-versus-one-section task with unfamiliar people
Test the wording in current Firefox release and ESR
Exercise screen readers, Braille, voice control, switches, zoom, and forced colors
Observe whether “section,” “independent,” and “future copies” are understood
Change wording or hierarchy in response to wrong turns
```

Do not answer comprehension problems with a checkbox forest, recommendation score, central directory, follower graph, automatic publication subscription, or another notification stream.

The older Editorial Rationale, proposal-basket exchange, selective-graft, and multi-donor direction remains future Advanced Workbench work. Branch is intentionally smaller: one reviewable branch from one checked tree, useful without becoming a curation bureaucracy.


<!-- RUN-REV0067-CADENCE-AUTHORITATIVE -->
# RUN — rev0067 Cadence

**Status:** implemented as an explicit Node-local scheduling contract and foreground control surface. It is not represented as a permanent background service or complete production scheduler.

**Release maxim:** **Schedule explicitly. Pause means zero requests.**

## Why Cadence exists

Witness proved one bounded, manually reviewed public acquisition. Capture proved one bounded browser-assisted observation without transferring browser credentials. Cadence answers the next question: when may the Node repeat an acquisition without requiring a human to press **Check once now** every time?

The answer is intentionally narrower than “active sources update automatically.” Activity and scheduling are different authorities. A source can be active yet unscheduled. A source can have a local timing plan while the foreground scheduler is stopped. Importing, pairing, sharing, adopting a branch, manually checking, or capturing a rendered page must never silently create recurring network behavior.

## Human model

The ordinary interface must answer, in this order:

1. **Can this Node reproduce the source without the browser?**
2. **How often could it check?**
3. **When is the next eligible check?**
4. **What happens if I pause it?**
5. **Is the scheduler currently running?**
6. **What happened on the last attempt?**

Protocol terms, jitter math, lease rows, due-slot identifiers, runner argv, hashes, and receipt fingerprints belong under advanced evidence.

### Active is not scheduled

- **Active** means the source is allowed to be acquired when a reviewed operation asks for it.
- **Scheduled** means the Node has a separate, explicit, Node-local timing plan.
- **Scheduler running** means the current foreground Node process is dispatching due plans.

None implies the others.

### Pause means zero requests

A paused Cadence plan produces no due dispatch. Pausing the source or the timing plan must not merely hide results, lower priority, or postpone UI notifications. It must prevent acquisition requests through Cadence until explicitly resumed.

## Eligibility

Cadence requires evidence from a successful **public/node-reproducible Witness receipt** for the same source. It accepts successful changed, unchanged, baseline, checking-again, or equivalent successful outcomes only when at least one Node-side site request occurred.

Cadence refuses:

- browser-assisted Capture receipts;
- browser-only sources;
- mismatched source IDs;
- non-HTTP(S) sources;
- failed, moved, refused, malformed, throttled, or repair-needed evidence;
- merely imported source metadata with no successful Node reproduction evidence.

A later Witness failure may influence backoff, but it does not transform browser-only evidence into scheduler eligibility.

## Storage boundary

Timing plans live in a dedicated Node-local SQLite database. They are intentionally excluded from portable `progrss.private.v1` backups and shared source lists.

This prevents these actions from silently starting polling elsewhere:

- exporting or importing a private backup;
- sharing a source route;
- taking one branch;
- following a curator;
- pairing an Extension;
- copying a library to another machine.

A portable library describes what the person follows and their private reading state. Cadence describes what this particular Node process may attempt over time.

## Review and creation

Plan review is offline. It computes and displays:

- source identity and site;
- qualifying Witness receipt identity;
- requested interval;
- deterministic jitter bound;
- earliest and latest eligible time;
- whether the plan begins scheduled or paused;
- explicit statement that no schedule session is started;
- explicit statement that no DNS or HTTP request occurs.

Creation requires a separate acknowledgement. The accepted interval is bounded from 15 minutes through 30 days. Jitter is bounded to no more than one third of the interval and no more than six hours.

## Foreground scheduler session

The scheduler defaults to stopped. A person starts it explicitly in the current Node process. Closing that process stops automatic dispatch. There is no installed system daemon, startup item, service worker, browser wake-up, or hidden operating-system schedule in rev0067.

One durable lease prevents two foreground Cadence dispatchers from treating the same database as independently owned. Lease expiry and renewal are explicit. A second live owner is refused rather than allowed to race.

## Reuse Witness; do not create another downloader

Cadence contains timing, due-slot, lease, and dispatch-record logic. It does not contain an HTTP client. A configured argv-only runner must invoke the established Witness-compatible acquisition path and return one bounded JSON result. Shell interpretation is not used.

This makes the current boundary honest:

- Cadence can decide **when** one already reviewed Node-reproducible acquisition is due.
- Witness remains responsible for destination validation, same-origin redirects, validators, byte/time bounds, parsing, page-watch logic, atomic library mutation, and acquisition receipts.
- The direct packaged adapter between them remains a next release task; deployments must explicitly configure the runner.

## Durable due slots and safe retry

Every due opportunity has a stable identity derived from the plan and due slot. Dispatch persistence records started and completed states. An exact retry of a completed slot returns the stored result with replay evidence and must not invoke the runner again.

Reusing a due-slot identity with different content is refused. A crashed or interrupted attempt remains distinguishable from a completed unchanged acquisition.

## Backoff and host courtesy

Cadence applies bounded deterministic jitter and temporary-failure backoff. A bounded numeric `Retry-After` delta can lengthen the retry delay. It never shortens a safety delay. HTTP-date `Retry-After`, persistent cross-process per-host budgets, global concurrency, suspend/resume policy, metered-network behavior, and offline awareness remain explicit follow-up work.

Within one dispatch pass, same-origin work is spaced and never launched as an uncontrolled burst.

## GUI and loopback boundary

`progrss cadence serve` binds to literal `127.0.0.1`. The capability begins in a URL fragment, is moved into session storage, and is required as a bearer credential for APIs. The server applies exact Host and Origin checks, does not grant CORS, and starts with the scheduler stopped.

The basic surface shows:

- whether the foreground scheduler is running;
- each source, interval, next eligible time, and last result;
- Pause or Resume;
- a route to review a new plan.

Advanced evidence exposes plan IDs, receipt IDs, due-slot identifiers, lease state, and runner configuration.

## Commands

```sh
./progrss cadence init cadence.sqlite3
./progrss cadence review cadence.sqlite3 witness-receipt.json --every 6h
./progrss cadence create cadence.sqlite3 witness-receipt.json --every 6h --acknowledge
./progrss cadence list cadence.sqlite3
./progrss cadence pause cadence.sqlite3 PLAN_ID
./progrss cadence resume cadence.sqlite3 PLAN_ID
./progrss cadence run-due cadence.sqlite3 --runner ./witness-runner
./progrss cadence start cadence.sqlite3 --runner ./witness-runner
./progrss cadence serve cadence.sqlite3 --runner ./witness-runner --open
```

Exact command help remains authoritative for arguments and machine-readable output.

## Delivered acceptance claims

Automated evidence can establish storage, bounds, replay, lease, pause, and refusal behavior. It cannot establish that an unfamiliar person understands the differences among Active, Scheduled, and Running, or that browser-owned prompts and assistive technology behave correctly on unmanaged native installations.

Native and human acceptance therefore remains required. The dedicated protocol is `CLI/docs/CADENCE-ACCEPTANCE.md`.

## Prioritized continuation

### P0 — direct packaged Witness adapter

- Wire Cadence to the packaged Witness path without introducing a second HTTP client.
- Preserve one acquisition receipt format for manual and scheduled attempts.
- Prove completed-slot replay after process restart.
- Prove crash behavior before runner start, during runner execution, after library commit, and after dispatch persistence.
- Add HTTP-date `Retry-After` parsing with bounded future dates.
- Define suspend, resume, and backward/forward wall-clock behavior.

### P0 — real acceptance

- Native current Chromium, Firefox, and Firefox ESR on unmanaged hosts.
- Unfamiliar-human Active/Scheduled/Running comprehension.
- Pause-zero-requests observation with packet or server logs.
- Keyboard, screen-reader, Braille, voice, switch, zoom, forced-colors, reduced-motion, and fatigue sessions.
- Revise the interface from observed wrong turns.

### P1 — scheduler policy

- Persistent per-origin budget shared by foreground dispatch passes.
- Global concurrency bound.
- Offline and metered-network policy.
- Jitter and exponential-backoff explanation in ordinary language.
- `Retry-After` HTTP-date support.
- Visible next-check recomputation after clock changes.
- No browser wake for browser-assisted or browser-only sources.

### P1 — organization and re-finding

- Private many-to-many labels.
- Explicit saved-query views.
- Delayed re-finding studies.
- Preserve folders as human-curated, potentially shareable routes.
- Preserve Unfiled as a valid state.
- No opaque engagement ranking or automatic taxonomy.

### P1 — Source Notes recovery

Recover the actual rev0059 artifact or independently reimplement and verify its short folder/source-scoped reasons. Keep notes outside acquisition identity, cover them with publication integrity, preserve them in branch excerpts, and do not expand them into social comments or notifications.

### P2 — remote Nodes and WebRTC lab

Remote mode needs TLS, durable identity, explicit public/private route separation, rate bounds, and revocation evidence. WebRTC may courier one already reviewed artifact, but it must remain optional and must expose signaling, STUN, TURN, and relay consequences.

## Non-goals retained

Cadence does not introduce:

- an account requirement;
- cloud synchronization;
- ambient LAN discovery;
- default public binding;
- browser wake-up;
- cookie transfer;
- arbitrary shared JavaScript;
- generic URL fetching;
- generic JSON Patch;
- a hidden daemon;
- automatic schedules created by import or sharing;
- engagement ranking.

---

# `/run` continuation — rev0068 Pulse

## Release maxim

**One clock. One fetcher. One receipt.**

## Why this revision exists

rev0067 described a useful Node-local scheduling boundary:

```text
Active
Scheduled
Running
```

It also described explicit timing review, pause semantics, durable due slots, a foreground scheduler, and a loopback control surface.

The delivered rev0067 ZIP did not contain the Python package required to execute those claims.

The launcher contained:

```python
from cadence.cli import main
```

The archive contained no:

```text
CLI/cadence/__init__.py
CLI/cadence/cli.py
CLI/cadence/store.py
CLI/cadence/service.py
CLI/cadence/server.py
CLI/cadence/web/
```

Consequently:

```text
./progrss cadence --help
```

could not execute from the sealed rev0067 bytes.

That is a release-chain defect, not a cosmetic documentation discrepancy.

Pulse treats it explicitly.

The claimed rev0067 files are retained under:

```text
Evidence/rev0067-Cadence-archive-defect/
```

They are evidence of an intended boundary.

They are not treated as executable proof.

Pulse reconstructs Cadence as delivered code, validates the code independently, then advances it by connecting the timing layer directly to the packaged Witness acquisition path.

## What Pulse means

Cadence is the timing model.

Pulse is the executable integration of that model with one Node-owned library and the existing Witness acquisition system.

The product boundary is:

```text
Cadence
  decides when a reviewed source is due

Witness
  decides how that source is checked

Node store
  commits the resulting portable library and acquisition receipt

Pulse
  keeps the durable relationship among the timing slot,
  Witness operation identity, and final receipt
```

Pulse does not introduce a second fetcher.

Pulse does not introduce a second parser.

Pulse does not introduce a second page-watch implementation.

Pulse does not introduce a second portable-library writer.

Pulse does not introduce a second acquisition receipt schema.

## Human model

The ordinary interface must preserve three separate concepts.

### Active

An active source may be checked by one reviewed acquisition operation.

Active does not mean scheduled.

Active does not mean the foreground scheduler is running.

Active does not mean a request just happened.

### Scheduled

A scheduled source has one explicit timing plan in this Node-local Pulse database.

Scheduled does not mean the current process is running.

Scheduled does not mean another machine received the schedule.

Scheduled does not mean the browser will wake.

### Running

Running means the current foreground Pulse process is dispatching due, scheduled, eligible plans.

Closing the process stops automatic dispatch.

Running does not install a service.

Running does not create new timing plans.

Running does not make browser-assisted pages reproducible.

## The ordinary sequence

```text
A person follows or creates a source
  ↓
The source remains active or paused according to its own state
  ↓
The person performs one manual public Witness check
  ↓
Witness retains a durable acquisition receipt
  ↓
The person reviews a local timing plan offline
  ↓
The person separately acknowledges creation
  ↓
The plan exists but the foreground session remains stopped
  ↓
The person starts Pulse
  ↓
Only due, scheduled, active, reproducible plans dispatch
  ↓
Witness performs the check
  ↓
The ordinary Witness receipt remains the source of truth
```

## Sharing remains separate

The sharing sequence remains:

```text
Follow updates
Add the complete route
Take one branch
```

None of those choices creates a schedule.

A private backup carries no Pulse plan.

A native source list carries no Pulse plan.

OPML carries no Pulse plan.

An Exchange handoff carries no Pulse plan.

A paired Extension receives no Pulse plan authority.

A branch excerpt carries no Pulse plan.

A later-copy merge carries no Pulse plan.

This preserves one important next-generation RSS rule:

> **Curation is portable. Execution authority remains local.**

## Sites without feeds

Pulse preserves the three page classes introduced by Witness and Capture.

### Node-reproducible page

The Node can retrieve the page itself and reproduce the declarative extraction.

A successful manual Witness check can qualify it for a timing plan.

### Browser-assisted page

The Extension can provide one bounded rendered observation during a deliberate browser session.

The Node receives text, links, recipe evidence, and provenance.

The Node does not receive cookies, credentials, browser storage, raw HTML, screenshots, or tab authority.

A browser-assisted receipt cannot qualify a schedule.

### Browser-only page

The useful view exists only while a person deliberately opens the page.

ProgRSS may capture one observation.

ProgRSS does not pretend that the Node can reproduce it later.

Pulse does not wake the browser.

Pulse does not control a hidden tab.

Pulse does not transfer login authority.

## Delivered package

Pulse adds a real package:

```text
CLI/cadence/
  __init__.py
  common.py
  store.py
  service.py
  cli.py
  server.py
  web/
    index.html
    app.css
    app.js
```

The package is part of the sealed release archive.

The launcher route is executable from a clean extraction.

`progrss doctor` checks its presence.

## Command surface

```sh
./progrss cadence init pulse.sqlite3 \
  --node-store reading-room.sqlite3
```

Creates one Node-local timing database bound to one durable Node-store identity.

```sh
./progrss cadence review \
  pulse.sqlite3 witness-receipt.json \
  --every 6h
```

Reviews one timing plan without network or portable-library mutation.

```sh
./progrss cadence create \
  pulse.sqlite3 witness-receipt.json \
  --every 6h \
  --acknowledge
```

Creates one plan without starting the foreground scheduler.

```sh
./progrss cadence list pulse.sqlite3
```

Lists local timing plans.

```sh
./progrss cadence pause pulse.sqlite3 PLAN_ID
```

Pauses one plan.

```sh
./progrss cadence resume pulse.sqlite3 PLAN_ID
```

Chooses a new future eligible point and returns the plan to Scheduled.

```sh
./progrss cadence run-due pulse.sqlite3
```

Dispatches currently due plans once through packaged Witness.

```sh
./progrss cadence start pulse.sqlite3
```

Runs the foreground scheduler until the process stops.

```sh
./progrss cadence serve pulse.sqlite3 --open
```

Opens the capability-protected loopback control surface.

## Storage schema

The timing-store schema is:

```text
progrss.cadence-store.v1
```

The SQLite application ID is specific to the timing store.

The database records:

```text
metadata
plans
due slots
scheduler lease
per-site courtesy budget
```

The metadata binds:

```text
Pulse database ID
Node-store ID
Node-store path
creation time
schema and release identity
```

The timing store does not become a new portable ProgRSS format.

The portable library remains:

```text
progrss.private.v1
```

## Plan schema

A persisted plan includes:

```text
plan ID
source ID
source title
source type
source hostname
source identity digest
bound Node-store ID
qualifying receipt ID
qualifying operation ID
qualifying result-library digest
interval
jitter
state
sequence
created time
updated time
next due time
last outcome
last receipt ID
failure count
blocked reason
```

Human wording is retained for display.

Acquisition authority is bound to source identity evidence, not merely the title.

## Source identity

Pulse introduces:

```text
progrss.acquisition-source-identity.v1
```

For a feed it covers:

```text
source ID
source type
canonical feed address
```

For a watched page it covers:

```text
source ID
source type
canonical page address
declarative page-watch recipe
```

It excludes:

```text
title
curator note
folder placement
read state
saved state
retained items
last result
HTTP validators
schedule state
browser permissions
```

A wording edit does not invalidate acquisition eligibility.

A feed-address change does invalidate it.

A watched-section recipe change does invalidate it.

The person performs one new manual Witness check after a consequential acquisition change.

## Eligibility receipt

Pulse accepts:

```text
progrss.node.acquisition-receipt.v1
```

only when the durable Node copy matches the supplied file.

The receipt must identify:

```text
operation
receipt
source
source identity digest
successful outcome
one or more Node site requests
resulting library digest
```

Pulse refuses:

```text
browser-assisted transport
zero-request evidence
receipt missing source identity
receipt not retained in the bound Node store
receipt from another Node store
source no longer present
source currently paused
source currently archived
source address changed
page-watch recipe changed
failed outcome
moved outcome
malformed outcome
refused outcome
repair-needed outcome
throttled outcome as eligibility
```

## Review schema

The review schema is:

```text
progrss.cadence-review.v1
```

It reports:

```text
source title
source type
site hostname
source identity digest
qualifying receipt
qualifying operation
qualifying outcome
qualifying commit time
qualifying result-library digest
qualifying Node request count
interval
jitter
earliest first check
latest first check
initial state
```

It also reports explicit consequences:

```text
network during review: false
network during creation: false
foreground scheduler started: false
portable library changed: false
shared source list changed: false
browser will wake: false
pause means zero Pulse dispatch: true
uses packaged Witness path: true
```

## Timing bounds

Minimum interval:

```text
15 minutes
```

Maximum interval:

```text
30 days
```

Maximum jitter:

```text
one third of the interval
and never more than six hours
```

The first due point is computed from plan creation plus interval plus deterministic bounded jitter.

Resume chooses a new future due point.

It does not run immediately.

## Deterministic jitter

Jitter is derived from:

```text
plan ID
plan sequence
```

The same plan sequence produces the same bounded jitter.

The jitter does not depend on process-random hash state.

The jitter does not alter the reviewed maximum.

The jitter is not used to create hidden sub-minute polling.

## Due-slot identity

Each reviewed opportunity receives:

```text
progrss.pulse-due-slot.v1
```

Its digest covers:

```text
plan ID
source ID
source identity digest
Node-store identity
due time
sequence
```

That digest produces:

```text
stable slot ID
stable Witness operation ID
stable request fingerprint
```

A completed slot can therefore be replayed exactly.

A reused slot identity with different material is refused.

## Prepared dispatch

Before source acquisition Pulse persists:

```text
adapter kind
Witness operation ID
source ID
source identity digest
base-library digest
Witness preview token
Witness preview digest
action
preparation time
```

The preview token is local capability material retained inside the timing database for that due slot.

It is not exported to shared formats.

It is not exposed in the basic GUI.

It is not transferred to the Extension.

## One acquisition path

The default adapter calls:

```python
NodeState.create_acquisition_preview()
NodeState.run_acquisition()
```

Therefore Witness remains responsible for:

```text
public-address resolution
mixed private/public DNS refusal
exact validated-IP connection
Host preservation
TLS hostname verification
same-origin redirects
redirect bound
request timeout
response-byte bound
identity encoding
HTTP validators
304 behavior
feed parsing
page-watch extraction
shape health
stability confirmation
Before / Now evidence
portable-library mutation
acquisition receipt
```

Pulse remains responsible for:

```text
eligibility
timing
jitter
lease
due-slot persistence
prepared-operation persistence
retry
backoff
courtesy budget
result linkage
```

## Advanced external runner

An explicit `--runner` remains available for advanced deployments.

It receives fixed argv values:

```text
--store
--source
--idempotency-key
--json
```

Shell interpretation is not used.

The runner receives no implicit stdin.

Its execution time is bounded.

Its stdout and stderr are bounded.

It must return one JSON object containing a standard acquisition receipt.

The packaged adapter remains the reference and default product path.

## Failure windows

### Before due-slot persistence

No durable Pulse work exists.

No Witness preview exists.

No source request has begun.

The next run may create the due slot.

### After due-slot persistence, before prepared dispatch

The due slot exists as Started.

No Witness preview has been persisted.

No source request has begun through this slot.

Restart prepares the same stable operation identity.

### After prepared dispatch, before Witness durable intent

The in-memory Witness preview may have died with the process.

The Node has no acquisition job and no acquisition receipt for the stable operation identity.

Pulse safely creates a replacement preview while retaining the same due-slot and operation identity.

### After Witness durable intent, before request completion

The Node has a Started acquisition job.

Restart resumes through the normal Witness acquisition operation.

The job attempt count records the resume.

### After Node commit, before Pulse completion

The portable library and acquisition receipt are already committed atomically by the Node.

Pulse still shows a Started due slot.

Restart uses the stable operation ID.

Witness returns the stored acquisition receipt.

No second source request occurs.

No second portable-library mutation occurs.

Pulse then completes the due slot.

### After Pulse completion, before GUI response

The due slot is Completed.

An exact retry returns the stored dispatch result.

Witness is not invoked again.

The site is not contacted again.

## Atomic boundaries

The Node transaction atomically commits:

```text
new portable library
new library digest
new library revision
acquisition receipt
completed Node acquisition job
request replay fingerprint
```

The Pulse transaction atomically commits:

```text
completed due slot
result document
receipt linkage
next due time
failure count
plan state
last outcome
last receipt ID
```

These are two intentionally separate transactional stores.

The stable Witness operation identity connects them safely across a lost response.

## Outcomes

Successful outcomes include:

```text
changed
unchanged
baseline
watch pending
checking again
```

Temporary outcomes include:

```text
temporary failure
throttled
```

Blocking outcomes include:

```text
permanent failure
moved
refused
malformed
needs repair
```

A blocking outcome pauses the timing plan for explicit review.

It does not repeatedly hammer a broken or moved source.

## Retry-After

Pulse accepts:

```text
Retry-After: 120
```

and:

```text
Retry-After: Tue, 20 Oct 2026 14:30:00 GMT
```

A valid value may lengthen the next wait.

It may not shorten the scheduler's safety wait.

Past dates become zero additional delay.

Invalid values are ignored rather than becoming a negative or unbounded wait.

Very distant values are bounded by the maximum backoff.

## Temporary-failure backoff

Temporary failures apply bounded exponential backoff.

The exponent is capped.

The resulting wait is capped.

The minimum schedule interval remains enforced.

A successful result resets the failure count.

## Per-site courtesy window

After one due operation makes a source request, Pulse records a local next-allowed time for the source hostname.

Another due plan for that hostname is deferred.

The courtesy window persists across process restarts.

It is not a cross-machine rate coordinator.

It is not a promise that every origin has identical policy.

It is a local burst-reduction boundary.

## Scheduler lease

One durable lease records:

```text
owner ID
acquired time
expiry time
```

A live owner renews the lease.

A second live owner is refused.

An expired lease may be acquired by a new foreground process.

The lease is local to one timing database.

It does not create remote leadership.

## Foreground-only rule

Pulse starts stopped.

The person starts it explicitly.

The current process owns the loop.

Closing the process stops automatic checks.

Pulse installs no:

```text
systemd service
launchd agent
Windows service
cron entry
startup item
browser service worker
background browser tab
remote scheduler
```

## Loopback server

The server binds only to:

```text
127.0.0.1
```

It does not bind to:

```text
0.0.0.0
::
LAN address
public address
```

The administrator capability begins after:

```text
#token=
```

The page moves it into session storage.

The fragment is not part of the initial HTTP request target.

APIs require:

```text
Bearer capability
exact Host
exact same Origin for writes
```

The server grants no CORS access.

## Basic GUI

The basic surface answers:

```text
Are automatic checks running?
What may this Node check?
Is each plan scheduled or paused?
When is its next eligible check?
What happened last time?
Can I pause it immediately?
```

The basic surface uses human-readable local times.

The exact timestamp remains in the `time` element and advanced evidence.

The default theme is dark.

The light theme remains explicit and persistent.

Fluorescent cyan identifies the primary action.

Magenta identifies consequential review.

Lime identifies a running or healthy state.

Color is not the only state cue.

## Advanced GUI

Advanced evidence may show:

```text
adapter kind
packaged Witness flag
timing database ID
Node-store ID
lease owner
recent due slots
receipt IDs
source identity digest
capability flags
```

Advanced evidence is not the default reading path.

## Accessibility

The UI preserves:

```text
skip link
semantic headings
native buttons
native checkbox
native details/summary
polite status region
visible keyboard focus
44-pixel minimum primary controls
high-zoom reflow
forced-colors treatment
reduced-motion treatment
no hover-only action
```

The psychedelic line treatment disappears or becomes ordinary borders under forced colors.

Animation is disabled under reduced motion.

The orbit is decorative and hidden from the accessibility tree.

## Extension boundary

The Extension still cannot:

```text
create a plan
pause a plan
resume a plan
start Pulse
stop Pulse
dispatch a due plan
read Node acquisition receipts
read source addresses
write through pairing
wake a browser tab for scheduled Capture
```

The Extension remains independently useful without a Node.

The Node remains optional.

## Native acceptance boundary

Automated tests do not prove native browser prompts.

Automated tests do not prove an unfamiliar person's understanding.

Automated accessibility-tree checks do not equal a screen-reader session.

The release must therefore say:

```text
native unmanaged Chromium: not yet run
current Firefox: not yet run
Firefox ESR: not yet run
unfamiliar-human Pulse sessions: not yet run
real screen-reader and Braille sessions: not yet run
voice-control and switch sessions: not yet run
```

unless those sessions are actually performed.

## Rev0067 chain-of-custody evidence

The evidence folder retains:

```text
CLAIMED-CADENCE-RELEASE.json
CLAIMED-RELEASE-NOTES.md
CLAIMED-validation-summary.json
archive-member-check.txt
README.md
```

The report records:

```text
input archive name
input archive SHA-256
launcher import
zero matching CLI/cadence members
executable consequence
```

This prevents a future maintainer from assuming rev0067 was a usable executable baseline merely because its prose was detailed.

## Pulse test lanes

### Cadence/Pulse unit lane

The unit lane covers:

```text
offline review
explicit creation acknowledgement
Capture refusal
old-receipt refusal
pause no dispatch
packaged Witness invocation
ordinary receipt retention
lost response after Node commit
restart replay without second request
completed due-slot replay
HTTP-date Retry-After
single live lease
loopback capability
same-origin write refusal
```

### Witness lane

The acquisition lane covers:

```text
conditional GET
304 unchanged
same-origin redirects
cross-origin move stop
mixed DNS refusal
feed ingestion
page baseline
Before / Now change
shape health
browser capture validation
recipe-change fresh baseline
```

### Node-store lane

The storage lane covers:

```text
exact imported backup retention
portable export
branch operation atomicity
acquisition intent
acquisition replay
interrupted resume
same-key different-request refusal
stale-base refusal
failure injection
legacy store migration
snapshot export
```

### Node HTTP lane

The loopback lane covers:

```text
public front door
administrator capability
Host refusal
Origin refusal
pairing
Exchange
Confluence review
branch operation
Witness acquisition
Capture
revocation
snapshot
```

### CLI core lane

The direct library lane covers:

```text
RSS
Atom
JSON Feed
OPML
private backup audit
search
read state
saved state
folders
page changes
repair
retention
recovery copies
same-source repair
private-copy comparison
```

### Relay/publication lane

The publication lane covers:

```text
source-list validation
canonicalization
signature verification
publication discovery
same-origin redirects
static publication
Edition feed
branch excerpts
Continuity updates
Confluence review
rollback refusal
```

### Extension lane

The Extension lane covers:

```text
manifest and package structure
Chromium background harness
Firefox generated background harness
source-list sharing core
acquisition redirects
vault conflict and failed write
rendered everyday reader
rendered Advanced Workbench
```

## Packaging rules

The sealed archive must:

```text
open directly to BOOTSTRAPROSE.md, CLI/, Extension/
include CLI/cadence/
include no runtime SQLite databases
include no private backup
include no acquisition receipt
include no capability token
include no browser profile
include no Python cache
include no Python bytecode
include no nested release archive
include no symlink
contain unique members
use safe relative paths
preserve executable modes
build deterministically
```

## Clean-extraction rule

Release proof must use:

```text
sealed ZIP
  ↓
new extraction directory
  ↓
restored executable modes
  ↓
file and mode comparison
  ↓
command and test replay from extracted bytes
```

A passing working tree does not prove the archive contains the same executable code.

## Human questions

An unfamiliar person should be able to answer:

1. Is this source active?
2. Does it have a timing plan?
3. Is the foreground scheduler running now?
4. Did reviewing the plan contact the site?
5. Did creating the plan contact the site?
6. Did creating the plan start automatic checks?
7. What happens when the Node process closes?
8. What does Pause guarantee?
9. Why is a signed-in Capture not schedulable?
10. When is the next eligible check?
11. What happened on the last attempt?
12. Where is the durable receipt?
13. Does sharing the route share its timing plan?
14. Does pairing the Extension let it start checks?
15. Can the Node wake the browser?

Wrong answers should change wording and hierarchy.

They should not trigger:

```text
ambient LAN discovery
a mandatory account
a central follower graph
a hidden daemon
silent schedule creation
a recommendation score
engagement ranking
browser credential transfer
```

## Prioritized checklist

### P0 — completed in Pulse

- [x] Audit the sealed rev0067 archive rather than trusting its prose.
- [x] Record the missing-package defect explicitly.
- [x] Retain claimed rev0067 metadata as non-executable evidence.
- [x] Deliver a real `CLI/cadence/` package.
- [x] Make `progrss cadence --help` execute from the working tree.
- [x] Bind one timing database to one Node-store identity.
- [x] Require durable successful public Witness evidence.
- [x] Add acquisition-source identity evidence to Witness receipts.
- [x] Refuse receipts predating source-identity evidence.
- [x] Refuse browser-assisted Capture as schedule eligibility.
- [x] Refuse zero-request evidence.
- [x] Refuse changed feed addresses.
- [x] Refuse changed watched-page recipes.
- [x] Preserve explicit offline review.
- [x] Preserve separate creation acknowledgement.
- [x] Keep scheduler start separate from plan creation.
- [x] Keep plans outside portable backups and source lists.
- [x] Add bounded interval and jitter.
- [x] Add stable due-slot identity.
- [x] Persist prepared Witness operation identity.
- [x] Call packaged Witness directly by default.
- [x] Avoid a second downloader.
- [x] Avoid a second parser.
- [x] Avoid a second acquisition receipt.
- [x] Recover after failure before Witness durable intent.
- [x] Recover after Witness durable intent.
- [x] Recover after Node commit but before Pulse completion.
- [x] Return exact completed-slot replay.
- [x] Prove lost-response recovery without a second site request.
- [x] Add bounded exponential backoff.
- [x] Parse bounded delta-seconds Retry-After.
- [x] Parse bounded HTTP-date Retry-After.
- [x] Add persistent per-site courtesy windows.
- [x] Add one durable scheduler lease.
- [x] Start the scheduler stopped.
- [x] Keep the scheduler foreground-only.
- [x] Keep Pause equal to zero Pulse due dispatch.
- [x] Pause blocking outcomes for review.
- [x] Retain advanced external-runner mode without shell interpretation.
- [x] Deliver a literal-loopback capability-protected GUI.
- [x] Keep exact Host and Origin checks.
- [x] Grant no CORS access.
- [x] Keep dark fluorescent presentation as default.
- [x] Keep light mode available.
- [x] Put human consequences before hashes and leases.
- [x] Show human-readable local next-check time.
- [x] Retain exact timestamps in advanced evidence.
- [x] Preserve summary-only Extension pairing.
- [x] Preserve browser-assisted Capture as deliberate.
- [x] Update the native and human acceptance protocol.
- [x] Update BOOTSTRAPROSE with chain-of-custody correction.

### P0 — release verification still required

- [x] Remove all Python caches and bytecode.
- [x] Run all Pulse unit tests.
- [x] Run all Witness acquisition tests.
- [x] Run all Node-store tests.
- [x] Run all Node HTTP tests.
- [x] Run all direct CLI tests.
- [x] Run Relay/publication tests in independently bounded processes where required.
- [x] Run all command-line cases independently where required.
- [x] Run Extension static tests.
- [x] Run Chromium background harness.
- [x] Run shared-folder core harness.
- [x] Run generated Firefox background harness.
- [x] Run acquisition redirect harness.
- [x] Run vault-conflict harness.
- [x] Run rendered everyday reader.
- [x] Run rendered Advanced Workbench.
- [x] Compile every delivered Python file.
- [x] Parse every delivered JavaScript file.
- [x] Parse every delivered JSON file.
- [x] Parse every delivered POSIX shell file.
- [x] Build the release twice deterministically.
- [x] Compare both archives byte-for-byte.
- [x] Verify ZIP CRC.
- [x] Verify unique archive members.
- [x] Verify safe relative paths.
- [x] Verify no symlink.
- [x] Verify no nested archive.
- [x] Verify no runtime database.
- [x] Verify no private backup or receipt.
- [x] Extract into a clean directory.
- [x] Compare every delivered file byte-for-byte.
- [x] Compare executable modes.
- [x] Execute `progrss cadence --help` from the extraction.
- [x] Execute `progrss doctor` from the extraction.
- [x] Replay principal suites from the extraction.

### P0 — real acceptance

- [ ] Current unmanaged Chromium.
- [ ] Current Firefox.
- [ ] Firefox ESR.
- [ ] Native loopback prompts and policy behavior.
- [ ] Unfamiliar-person Active/Scheduled/Running comprehension.
- [ ] Packet- or server-log verification of Pause.
- [ ] Foreground process close behavior.
- [ ] Restart after a lost response.
- [ ] Backward wall-clock movement.
- [ ] Forward wall-clock jump.
- [ ] Suspend across one due point.
- [ ] Suspend across several due points.
- [ ] Timezone change without UTC change.
- [ ] Keyboard-only session.
- [ ] Screen-reader session.
- [ ] Braille session.
- [ ] Voice-control session.
- [ ] Switch-style session.
- [ ] 200–400% zoom.
- [ ] Forced-colors session.
- [ ] Reduced-motion session.
- [ ] Fatigue and interruption session.
- [ ] Revise wording from observed wrong turns.

### P1 — page-watch quality

- [ ] Explain why a proposed watched section appears stable or fragile.
- [ ] Improve bounded repeated-record proposals.
- [ ] Preserve matched and ignored examples.
- [ ] Test pagination.
- [ ] Test virtualized lists.
- [ ] Test localized pages.
- [ ] Test right-to-left pages.
- [ ] Test consent overlays.
- [ ] Test partial authentication.
- [ ] Keep cross-origin frames outside the default contract.
- [ ] Keep closed shadow roots outside the default contract.
- [ ] Keep arbitrary shared JavaScript outside the normal recipe format.
- [ ] Preserve Node-reproducible, browser-assisted, and browser-only labels.

### P1 — organization and re-finding

- [ ] Test whether a person can find material again after one week.
- [ ] Keep folders as human-curated shareable routes.
- [ ] Add private many-to-many labels.
- [ ] Add explicit saved-query views.
- [ ] Preserve Unfiled as a valid resting state.
- [ ] Suggest duplicate sources without silently collapsing distinct recipes.
- [ ] Suggest stale sources with reversible evidence.
- [ ] Suggest route splits without automatic taxonomy.
- [ ] Avoid engagement ranking.
- [ ] Avoid opaque recommendation models.

### P1 — Source Notes recovery

- [ ] Recover the actual rev0059 archive or independently reimplement it.
- [ ] Keep notes short and plain text.
- [ ] Scope each note to one folder/source relationship.
- [ ] Keep notes outside acquisition identity.
- [ ] Cover notes with publication integrity.
- [ ] Preserve notes in independent branch excerpts.
- [ ] Report note omission from OPML.
- [ ] Include note disagreement in Confluence review.
- [ ] Do not turn notes into comments or reactions.
- [ ] Do not create curator profiles or notification streams.

### P2 — remote Nodes

- [ ] Explicit remote mode separate from loopback.
- [ ] TLS.
- [ ] Durable Node identity.
- [ ] Hostname allowlist.
- [ ] Request-size bounds.
- [ ] Artifact-size bounds.
- [ ] Rate bounds.
- [ ] Expiring invitations.
- [ ] Persistent revocation evidence.
- [ ] Separate public publication routes from private APIs.
- [ ] Manual remote artifact retrieval before continuous synchronization.
- [ ] Reverse-proxy acceptance.
- [ ] Self-hosted deployment documentation.
- [ ] No default public bind.
- [ ] No silent LAN discovery.
- [ ] No UPnP port opening.
- [ ] No “enter an IP address and hope” ordinary flow.

### Lab — WebRTC courier

- [ ] Transfer exactly one already reviewed immutable artifact.
- [ ] Use bounded signed offer metadata.
- [ ] Use bounded signed answer metadata.
- [ ] Make signaling explicit.
- [ ] Make STUN use visible.
- [ ] Make TURN use visible.
- [ ] Compare QR friction.
- [ ] Compare copy/paste friction.
- [ ] Compare ordinary HTTPS friction.
- [ ] Compare relay friction.
- [ ] Compare WebRTC friction.
- [ ] Refuse replay.
- [ ] Refuse identity mismatch.
- [ ] Refuse digest mismatch.
- [ ] Refuse timeout.
- [ ] Refuse partial completion.
- [ ] Discard the session after transfer.
- [ ] Never require WebRTC for normal reading.
- [ ] Never require WebRTC for normal sharing.
- [ ] Never require WebRTC for normal scheduling.

## Research boundary

Pulse follows the HTTP conditional and retry model rather than inventing a scheduler-specific network protocol.

`Retry-After` may be expressed as either an HTTP date or delay seconds.

Pulse supports both in bounded form.

SQLite remains the local transaction mechanism for Node and Pulse stores.

Portable ProgRSS JSON remains the interchange and recovery mechanism.

## Release verification record

The exact final values below are filled only after the deterministic archive is sealed and replayed from clean extraction.

```text
Archive:             ProgRSS-rev0068-2026.10.20-Pulse.zip
Version:             0.68.0
Revision:            rev0068
Codename:            Pulse
SHA-256:             detached .sha256 sidecar (not self-embedded)
Members:             318
Regular files:       281
Directory entries:   37
Uncompressed bytes:  see detached release report
ZIP bytes:           see detached release report
BOOTSTRAP lines:      11256
```

### Final automated evidence

```text
Pulse/Cadence tests:                 9/9 PASS
Witness acquisition tests:          9/9 PASS
Node-store tests:                    9/9 PASS
Node HTTP tests:                     17/17 PASS
Direct CLI library tests:            46/46 PASS
Relay/publication tests:             29/29 PASS in bounded individual process groups
Command-line cases:                  26/26 PASS in bounded individual process groups
Extension static checks:             57/57 PASS
Chromium background harness:         PASS
Shared-folder core harness:          PASS
Firefox generated background:        PASS
Acquisition redirect harness:        PASS
Vault conflict harness:              PASS
Rendered everyday reader:            PASS
Rendered Advanced Workbench:         PASS
Python compilation:                  26/26 PASS
JavaScript syntax:                   62/62 PASS
JSON parsing:                         47/47 PASS
POSIX shell syntax:                  2/2 PASS
Deterministic rebuild:               PASS — two byte-identical candidate builds
Clean-extraction replay:             PASS — principal CLI and Extension suites from clean extraction
```

### Native and human evidence

```text
Installed unmanaged Chromium:        NOT RUN
Current native Firefox:              NOT RUN
Native Firefox ESR:                  NOT RUN
Unfamiliar-human Pulse sessions:     NOT RUN
Real screen-reader sessions:         NOT RUN
Braille sessions:                    NOT RUN
Voice-control sessions:              NOT RUN
Switch sessions:                     NOT RUN
```

Those entries remain not run unless actual sessions occur.

## Decision for the next revision

The next revision should not add remote scheduling.

The next revision should not add a permanent daemon merely because the foreground path now works.

The next coherent work is:

1. execute native and human Pulse acceptance;
2. improve page-watch quality for sites without feeds;
3. improve organization and delayed re-finding;
4. recover or independently reimplement Source Notes;
5. only then decide whether a separately installed service is justified;
6. keep WebRTC as an optional bounded courier experiment.

## End of rev0068 bootstrap continuation
<!-- REV0084-NATIVE-SOURCE-NOTES-AUTHORITY -->
# `/run` authority — rev0084-native-source-notes

This block is the current execution authority. It was reconstructed from the available rev0080 lineage and the rev0083 reconstruction; it does **not** claim recovery of unavailable rev0081 or rev0082 artifacts.

## P0.1 — native Source Notes continuity

### Closed by this candidate

- Treat one optional `reason` as data on one direct folder-to-source member relationship, keyed by `folderId/sourceId`; do not key it by source alone.
- Preserve absent versus present placement reasons through native Python and browser import/restore normalization.
- Permit one source in multiple folders with different reasons.
- Reject conflicting duplicates for the same folder/source placement.
- Keep the relationship field inside the existing collection/member payload so the existing canonicalization and integrity envelope covers it.
- Reject folder-level reasons, non-source-member reasons, non-string values, invalid Unicode scalar values, and values over 280 Unicode code points.
- Keep empty reasons canonically omitted.
- Keep native export, selected-branch export, disclosure, and update comparison placement-scoped.
- Replay the unchanged-import regression in both Python and JavaScript-focused paths before packaging.
- Record static integration evidence separately from behavioral test evidence.

### Still open; do not claim complete

- Exact shipped-path replay through every CLI, Node, Extension, Chromium, and generated-Firefox entry point.
- Unmanaged current Chromium, Firefox Release, and Firefox ESR fieldwork.
- Screen reader, Braille, voice control, switch, high zoom, forced colors, reduced motion, fatigue, and interruption sessions.
- Unfamiliar curator and recipient comprehension, including authorship, safety-claim, publication/contact, branch-preservation, OPML-loss, and conflict-decision questions.
- Privacy-reviewed sender and recipient evidence captured separately.

## P0.2 — deterministic Roadcase

- Build the candidate twice from a clean copied tree.
- Require byte-identical ZIP output, normalized timestamps, stable member ordering, and preserved POSIX executable bits.
- Verify the ZIP manifest directly and after clean extraction.
- Keep generated evidence inside and outside the Roadcase.

## P0.3 — smallest field correction

- Run the fieldwork protocol only after P0.1 shipped-path replay is complete.
- Change wording or control placement only for recurring wrong turns.
- Do not add permissions, pairing, scheduling, private-state, engagement ranking, comments, reactions, profiles, or notifications.

## P1 — delayed re-finding and organization

- Test whether placement reasons improve one-week route re-finding.
- Preserve human-curated, shareable folders and **Unfiled** as a legitimate state.
- Add private labels or saved views only when repeated re-finding evidence requires them.
- Keep reason text out of opaque recommendation and engagement-ranking systems.

## P2 — remote Nodes

- Keep remote mode explicit and separate from loopback.
- Require TLS, persistent Node identity, bounded hosts/requests/artifacts/rates, expiring invitations, and durable revocation evidence.
- Separate public publication routes from private APIs.
- Begin with reviewed immutable-artifact retrieval; no default public bind, silent LAN discovery, or UPnP.

## Lab — WebRTC courier

- Transfer exactly one reviewed immutable artifact and preserve Source Notes through that artifact.
- Make signaling, STUN, and TURN visible.
- Refuse replay, identity mismatch, digest mismatch, timeout, and partial completion; destroy the session after the bounded transfer.
- Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## Next `/run`

1. Bind the focused replay to every named shipped import/update entry point and record an entry-point matrix.
2. Exercise one-sided curator change, one-sided recipient change, identical change, deletion-versus-edit, divergent edit, stale decision, and unresolved conflict through those entry points.
3. Build generated Firefox Release/ESR siblings from the same source and compare native artifact bytes and disclosure evidence.
4. Only then begin unmanaged participant fieldwork.

## Candidate evidence snapshot

- Origin mode: `repaired-existing-worktree`.
- Focused source-note test files discovered: 2.
- Focused direct test successes: 2.
- Python files syntax-checked: 49.
- JavaScript files syntax-checked: 70.
- JSON files parsed: 88.

This candidate closes only the checks backed by its included machine-readable evidence. Static matches are not promoted to behavioral passes.

## rev0084 repair classification

- Runtime helper tests: **PASS** in Python and JavaScript.
- Native Python projection edits found: 0.
- Native JavaScript projection edits found: 0.
- Candidate classification: **helper-and-audit-candidate**.
- A helper-only seam is not a shipped-entry-point pass; the next `/run` must bind and exercise every matrix row.
