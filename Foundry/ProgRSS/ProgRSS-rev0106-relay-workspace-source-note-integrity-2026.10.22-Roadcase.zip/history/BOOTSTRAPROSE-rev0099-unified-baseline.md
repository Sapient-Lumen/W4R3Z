# BOOTSTRAPROSE — unified `/run` authority

**Candidate:** `rev0099-unified-baseline` · **Date:** 2026-10-22 · **Product lineage:** rev0080 / 0.80.0.
This is the current authority. Files under `history/`, earlier release records, and earlier
per-revision audits describe their original snapshots; they do not override this file.
The release gate is open.

## Exact inputs and integration decision

Main parent: `ProgRSS-rev0098-source-notes-publication-disclosure-2026.10.21-Roadcase.zip`
SHA-256: `2e97f0075281fc19b279db85057c87b3582fb5d9ca30021e9d7d3ff10f2d1a44`.

Recovered integration donor: `ProgRSS-rev0091-source-notes-runtime-record-integrity-2026.10.21-Roadcase.zip`
SHA-256: `b05e3aa3e7cbdaf0b67e2fe3b7619f975a0d4971c33142f30759e963345eca95`.

Re-uploaded baseline: `ProgRSS-rev0080-2026.10.20-Roadcase(2).zip`
SHA-256: `181308cabfae43330016a272a64fbdb33038f841d605f4756ec65bedb43b8106`.
It is identical to the original `(1)` upload. Every baseline file was already present
in rev0098. Do not overlay rev0080 over later code.

Two distinct rev0091 candidates existed. This integration carries the delivered
runtime-record-integrity fixes forward into the later folder-undo/product lineage.
The prior rev0090 browser-execution-binding source archive is unavailable; only a failing
postcheck was supplied. Do not treat its prose-only completion claim as implemented code.
Rev0081 and rev0082 remain unavailable and unrecovered.

See `INTEGRATION-AUDIT.md` and `.json` for exact identities, the merge base, inventories,
reproduction, and scope. CLI and Extension product bytes are unchanged from rev0098.

## Unified product commitments

ProgRSS is one portable curation and reading product—not a Source Notes-only application.
The everyday Extension remains primary; Advanced Workbench is secondary. The Extension
works without a Node, and CLI/Node work without a browser. Dark fluorescent presentation
remains the default; explicit persisted light mode, forced colors, and reduced motion
remain supported boundaries, not new conformance claims.

The ordinary Node remains literal-loopback only. Pairing is summary-only, read-only,
revocable, and distinct from Exchange. Exchange is one reviewed expiring handoff, not
synchronization. Its recipient choices remain Follow updates, Add the complete route,
and Take one branch; choosing a door enters a review, not immediate adoption. Exact
existing sources are reused; genuinely new sources begin paused; independent branches
do not inherit parent future-copy continuity. **Unfiled** remains a valid organization state.

Capture, Witness, Pulse, coverage review (Contour/Perimeter/Threshold), held-window review
(Drift/Anchor/Bearing), and Trace remain part of the product. Fieldbook, Debrief, Crossroads,
Dispatch, and the native Roadcase fieldwork tools remain present. Preserve their authority
and privacy boundaries while testing Source Notes across them where relevant.

Source Notes are optional plain-text reasons on individual direct folder/source relationships,
limited to 280 Unicode code points. Different folders may explain the same source differently.
Keep native canonicalization, integrity, explicit branch scope, OPML-loss reporting,
three-way later-copy/Lineage review, no automatic divergent winner, and all review-bound
save/removal/Undo/repair protections. Keep static publication attribution and non-safety wording.
Editing locally publishes nothing, contacts nobody, and creates no schedule.

Private reading/saved state, retained private text, browser authority/cookies, page-observation
evidence, signing keys, and research notes stay local. No permission, account, pairing,
scheduling, notification, recommendation, or remote-service expansion follows from this merge.
Never remove or bypass managed browser policy to manufacture acceptance.

## P0.0 — reconciliation completed in this candidate

- The new rev0080 upload is identical; all 395 baseline paths are retained.
- The separate delivered runtime-record-integrity branch is integrated.
- Nine reproduced false-positive records are refused; the valid synthetic control remains accepted.
- Preserve all 114 CLI and 210 Extension files exactly as delivered in rev0098.
- Keep the 18 behavioral case objects, including every later Workbench/Lineage/publication step.
- Identify artifacts by full revision label and digest; never merge by revision number alone.
- Reuse the existing verifier; this is a recovery merge, not another evidence framework.

## Completed offline replay; deterministic seal requires detached report

The working-tree replay passed 51 runtime-record/comparison tests, 192 CLI tests, 60 Extension
static tests, 19 managed handler harnesses, and the cross-runtime Source Notes contract.
Reproduce both runtime-record and native-artifact comparison suites, the whole CLI suite,
Extension static checks, production-handler harnesses in both package variants, and the
Python/JavaScript contract. Verify source inventory/modes, baseline preservation, and
unchanged product subtrees. Build deterministically; verify the archive and a clean extraction;
replay the focused gate from extraction. Read the detached final report before calling any
build check complete. Keep first failed/interrupted attempts separate from passing reruns.

Use session schema v5, result schema v3, and predicate v3. Generate fresh sessions rather
than relabeling older v4/v2 records. Require valid UTC calendar values, ordered attempt
intervals, in-interval case/event records, closed claim-bearing objects, complete passing
permission projections, known native roles, and unique case-evidence references. Records
remain unsigned and operator supplied, not authenticated browser execution.

## P0.1 — actual whole-product target-host acceptance

Install the exact sealed candidate in unmanaged then-current Chromium Stable, Firefox
Release, and Firefox ESR independently. Capture fresh official channel evidence and actual
browser/OS/profile/install metadata on each host. Run all 18 Source Notes cases with the
retained later steps. Also retain ordinary-reader, loopback pairing, Exchange's three doors,
Capture/Witness/Pulse/Trace, and native fieldwork-tool regression boundaries from rev0080.
Do not confuse the source-delivery Roadcase ZIP with the distinct packet generated by
`CLI/progrss node roadcase`; preserve each artifact's own manifest and identity.

A prepared session is not an attempted run. Managed harnesses, historical installed-browser
evidence, or equal product bytes do not close this gate. Preserve first failures, recovery,
restart behavior, two-view stale writes, native artifacts, static publication, OPML loss,
and permission observations. Temporary Firefox loading and signed-install restart/prompt
findings have different scopes. No platform-specific result silently substitutes for another.

## P0.2 — unfamiliar people, privacy, and real assistive technologies

After target-host browser acceptance, test unfamiliar curators and recipients without
teaching the model first. Cover reason level, one source in two folders, authorship,
safety-claim confusion, publication/contact/scheduling consequences, branch/OPML loss,
repair and later-copy/Lineage decisions, Workbench preservation, and placement Undo.
Compare native and static-page understanding. Keep sender, recipient, and diagnostic
Fieldbooks/scenarios separate; privacy-review evidence before sharing or Debrief comparison.
Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow,
forced-colors, reduced-motion, fatigue, and interruption sessions. Synthetic completion is
not participant evidence. Make only the smallest correction supported by recurring wrong turns.

## P1 — organization evidence

Test one-week delayed route re-finding before private labels or saved views. Keep folders
human-curated/shareable and preserve Unfiled. Do not rank engagement or recommendations
from note wording; do not turn notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

Keep explicit remote mode separate from loopback. Require TLS, persistent identity, bounded
hosts/requests/artifacts/rates, expiring invitations, and durable revocation evidence.
Separate public publication routes from private APIs. Begin with reviewed immutable-artifact
retrieval; no default public bind, silent LAN discovery, or UPnP.

## Lab — WebRTC courier

Transfer exactly one reviewed immutable native artifact. Make signaling/STUN/TURN visible;
refuse replay, identity/digest mismatch, timeout, and partial completion; destroy the session.
Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## Change discipline

Do not invent missing releases or code from earlier narrative claims. Do not regress the
product to an older archive to obtain a missing fix. Further implementation changes require
a reproduced failure or a proven omitted delivered change. Do not add another evidence layer
because target-host access is unavailable. Reprioritize after each real result; keep unfinished
browser, human, privacy, and accessibility work visible.
