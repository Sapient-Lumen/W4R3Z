# BOOTSTRAPROSE — current `/run` authority

**Candidate:** `rev0100-node-branch-source-note-disclosure` · **Date:** 2026-10-22 · **Product lineage:** rev0080 / 0.80.0.
This file is the current authority. Earlier release records and files under `history/` retain their
original scopes; they do not override it. The release gate remains open.

## Parent and change trigger

Immediate parent: `ProgRSS-rev0099-unified-baseline-2026.10.22-Roadcase.zip`  
SHA-256: `a8bf125794861dee8be6dc8aa6f182feaf0ccf2791e818b6cb3a32c663578841`.

The actual target-browser gate could not run because this chat has no originating connected-browser
context. No managed browser, historical Chromium, prepared session, or source-side harness may be
substituted for that acceptance row. The product changed only because a fresh audit reproduced a
concrete shipped-UI omission.

The loopback Node API already returned optional Source Notes for the selected branch: branch choices
included a count, and operation previews included each direct placement route and exact reason. The
shipped Node review screen discarded those fields. A local administrator could therefore commit a
reason-bearing branch without seeing the relationship explanations that would be written. The retained
before-fix rendering reproduction proves the omission.

## P0.0 — repaired in this candidate

- Show the Source Note count in each adoptable branch choice when nonzero.
- Show the exact count in the reviewed operation summary.
- Render each optional reason beside its direct folder/source route before commit.
- Keep one source's different reasons distinct across folders.
- Label the text as the curator's reason for that folder and state that it is not a ProgRSS safety claim.
- Render reason values as literal text, preserve internal line breaks, wrap long content, and apply
  `dir="auto"` to the user-authored value.
- Preserve existing atomic preview/commit, stale-base, idempotency, paused-new-source, rollback,
  zero-listed-site-contact, and native placement-preservation behavior.
- Add no store, permission, network authority, account, pairing right, schedule, notification,
  recommendation, profile, reaction, comment, or messaging feature.
- Keep the fixed Source Notes browser catalog at 18 cases; add this assertion to the existing
  selected-branch preservation work rather than inventing another behavior case. Bind new runtime
  sessions to the rev0100 catalog and result schema; do not relabel rev0099 records.

## Unified product commitments

ProgRSS remains one portable curation and reading product, not a Source Notes-only application. The
ordinary Extension is primary; Advanced Workbench is secondary. The Extension works without a Node,
and CLI/Node work without a browser. Keep the rev0099 reconciliation: the identical rev0080 baseline,
the recovered runtime-record-integrity branch, full artifact identities, and all later Undo, repair,
Workbench, Lineage, and publication fixes.

The ordinary Node remains literal-loopback only. Pairing is summary-only, read-only, revocable, and
distinct from Exchange. Exchange remains one reviewed expiring handoff with Follow updates, Add the
complete route, and Take one branch. Capture, Witness, Pulse, Trace, coverage review, held-window
review, Fieldbook, Debrief, Crossroads, Dispatch, and native Roadcase fieldwork remain product scope.

Source Notes remain optional plain text on one direct folder/source relationship, limited to 280
Unicode code points. Different folders may explain the same source differently. Keep native
canonicalization and integrity, explicit branch scope, OPML-loss reporting, three-way later-copy and
Lineage review, no automatic divergent winner, static-publication attribution, and all reviewed
save/removal/Undo/repair guards. Editing locally publishes nothing, contacts nobody, and creates no
schedule.

Private reading state, browser authority and cookies, retained private text, observation evidence,
signing keys, and research notes stay local. Never remove or bypass managed browser policy to
manufacture acceptance.

## Required offline verification before sealing

Retain the before-fix UI reproduction. Run the focused Node API test and the shipped Node rendering
smoke with placement counts, both exact reasons, literal markup-like text, preserved newlines,
automatic directionality, curator attribution, and non-safety wording. Then rerun:

- the complete CLI test suite;
- the Extension static and production-handler regression set in both package variants;
- the runtime-record/comparison boundary suite;
- the Python/JavaScript Source Notes contract;
- permission-projection and Chromium/generated-Firefox parity checks;
- source inventory, parent-product continuity, deterministic construction, direct archive verification,
  clean-extraction byte/mode comparison, focused replay, and CLI doctor.

The managed rendering smoke is regression evidence only. It does not establish an installed current
browser, human review, privacy comprehension, assistive-technology use, or accessibility conformance.
Read the detached final verification before calling the build complete.

## P0.1 — actual whole-product target-host acceptance

Install the exact sealed candidate independently in unmanaged then-current Chromium Stable, Firefox
Release, and Firefox ESR. Capture fresh official channel evidence and actual browser, OS, profile,
installation-method, and permission observations on each host. Prepare fresh rev0100 session-v5
records from this exact Roadcase; older sessions cannot be relabeled. Run all 18 Source Notes cases with all
retained extended steps, including the Node-owned branch chooser and exact preview:

- reason count visible before selection and in the preview;
- every reason beside the correct direct route;
- one source with different reasons in two folders;
- an absent placement producing no invented reason;
- multiline, bidirectional, and markup-like values rendered safely;
- curator authorship and non-safety wording understood;
- the committed native library retaining the exact reviewed placement values.

Also retain ordinary-reader, loopback pairing, Exchange's three doors, Capture/Witness/Pulse/Trace,
restart behavior, two-view stale writes, whole-placement Undo, repair and Lineage conflicts,
Workbench preservation, complete-route and selected-branch artifacts, static publication, OPML loss,
native-integrity refusal, and permission observations. Preserve first failures, interruptions, retries,
and recovery—not only the final state.

A prepared session is not an attempted run. Managed automation, historical installed-browser records,
or equal package bytes do not close this gate. Firefox temporary-development loading and signed-install
restart or prompt evidence have different scopes. No platform result substitutes for another.

## P0.2 — unfamiliar people, privacy, and real assistive technologies

After the browser triad passes, test unfamiliar curators and recipients without teaching the model
first. Include the Node preview as well as the native artifact and static page. Ask what relationship
each reason belongs to, who wrote it, whether it is a safety claim, what will be written, whether any
site was contacted, and what is lost in OPML. Keep sender, recipient, and diagnostic privacy evidence
separate. Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom and
reflow, forced-colors, reduced-motion, fatigue, and interruption sessions. Make only the smallest
correction supported by recurring independent wrong turns.

## P1 — organization evidence

Test one-week delayed route re-finding before private labels or saved views. Keep folders human-curated
and shareable; preserve Unfiled. Do not use note wording for engagement ranking or opaque
recommendations, and do not expand notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

Keep explicit remote mode separate from loopback. Require TLS, persistent identity, bounded hosts,
requests, artifacts, and rates, expiring invitations, and durable revocation evidence. Separate public
publication routes from private APIs. Begin with reviewed immutable-artifact retrieval; no default
public bind, silent LAN discovery, or UPnP.

## Lab — WebRTC courier

Transfer exactly one reviewed immutable native artifact. Make signaling, STUN, and TURN visible;
refuse replay, identity or digest mismatch, timeout, and partial completion; destroy the bounded
session. Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## Change discipline

Do not invent missing releases or code from narrative claims. Do not regress to an older archive to
obtain a missing fix. Do not add another evidence layer merely because target-host access is
unavailable. Further implementation changes require a reproduced failure or proven omitted delivered
change. Reprioritize after each real result and keep unfinished browser, human, privacy, and
accessibility work visible.
