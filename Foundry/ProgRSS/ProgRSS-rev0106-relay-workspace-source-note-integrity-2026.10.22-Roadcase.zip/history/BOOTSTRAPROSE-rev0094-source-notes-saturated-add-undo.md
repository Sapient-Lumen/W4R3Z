# `/run` authority — rev0094 Source Notes saturated folder-add Undo

This is the sole current checklist. Earlier authorities are historical under `history/` and do not establish current-candidate behavior.

## Candidate and limits

Candidate: **rev0094-source-notes-saturated-add-undo**. Product lineage remains **rev0080 / 0.80.0**. Immediate parent: `ProgRSS-rev0093-source-notes-saturated-concurrency-2026.10.21-Roadcase.zip`; SHA-256 `a5775d6249e3b199f0d1afe8b95626f8d7999c3a024bab81a543c3bf7a92ab8e`. Rev0081 and rev0082 remain unavailable and unrecovered.

**Release gate: NOT SATISFIED.** A reproduced stale folder-add Undo at the folder-version ceiling is corrected in native/managed scope, but no unmanaged then-current Chromium, Firefox Release, Firefox ESR, unfamiliar-person, real assistive-technology, or human permission-prompt session has passed these exact Extension bytes. Do not reuse older installed-browser records as acceptance for changed product bytes. No enterprise policy was changed.

## Completed: saturated folder-add Undo guard

- [x] Reproduced rev0093 accepting an old add-placement Undo after the reviewed direct relationship was removed and recreated while its folder version remained saturated at `10000`.
- [x] Confirmed the stale Undo deleted the replacement relationship and a newly authored reason.
- [x] Returned the committed persisted vault revision from the shipped `addSourceToFolder` handler.
- [x] Carried that revision in the side panel’s existing short-lived Undo state.
- [x] Required the exact revision for folder-add Undo only when the current folder version is `10000`.
- [x] Refused missing, wrong, stale, replacement-placement, and unrelated-intervening-write revisions at the ceiling without mutation.
- [x] Required exactly one current direct placement and refused add-Undo when that placement had acquired a reason.
- [x] Removed only the exact reviewed direct placement rather than filtering every matching member.
- [x] Preserved the less disruptive below-ceiling rule: an unrelated vault write does not invalidate an unchanged placement when the folder version still matches.
- [x] Replayed 28 folder-Undo cases against Chromium source and generated Firefox bytes; shared background and side-panel files remain byte-identical.
- [x] Replayed same-source repair, Source Note saturated save/Undo, native artifact, OPML omission, branch, disclosure, and full CLI/Extension regressions.
- [x] Kept required, optional, host, and optional-host permission projections unchanged.

The persisted revision is a conservative local generation guard at a saturated version boundary. It is not a public identity, account, remote token, authorship credential, or authenticity claim.

## P0.1 — exact corrected candidate in actual browsers

Freeze and use this exact Roadcase. Capture fresh official channel payloads on each target host. Run all 18 fixed cases independently in unmanaged then-current Chromium Stable, Firefox Release, and Firefox ESR.

The existing cases now require these concrete Undo steps:

- `clear-and-guarded-undo`: add one direct placement and prove immediate Undo removes only that still-unchanged placement; separately remove a reason-bearing placement and prove Undo restores the entire relationship and original position.
- `two-view-stale-undo-refused`: at folder version `10000`, review an added direct placement in one view, remove and recreate it in another, add a replacement reason, and prove the first view’s old add-Undo is refused without changing the replacement. Retain the existing saturated Source Note Undo replacement test as a separate assertion.

Retain same-source repair preservation/refusal, repair Undo, two-folder independence, stale save, restart persistence, complete-route disclosure, selected-branch preservation, OPML omission, native integrity mutation refusal, and both later-copy decisions. Preserve first failures, interruptions, retries, recovery, actual installation and permission observations, two live views, same-profile restart, and actual native JSON artifacts.

Firefox temporary loading must not be reported as signed-install permission-prompt or restart evidence. Finalize and independently verify each evidence ZIP against the same immutable Roadcase; comparison reports differences but does not approve release automatically.

Do not create another evidence layer merely because target-host access is unavailable. Make another implementation change only for a reproduced failure.

## P0.2 — unfamiliar people and real assistive technologies

After the browser triad: test unfamiliar curator and recipient comprehension of relationship level, one-source/two-folder differences, authorship, local-only consequences, absence of a safety claim, branch expectations, OPML loss, divergent later-copy decisions, add/remove whole-placement Undo, repair refusal, and stale-placement refusal. Review sender and recipient privacy evidence separately.

Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions. Apply only the smallest correction supported by recurring independent wrong turns. Managed DOM smoke, browser API doubles, digests, and unsigned records are not human or AT evidence.

## P1 — delayed re-finding and organization

Test one-week delayed route re-finding before private labels or saved views. Keep folders human-curated and shareable, Source Notes optional, and **Unfiled** legitimate. Do not use note wording for engagement ranking or opaque recommendation, and do not expand Source Notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

Remote mode remains explicit and separate from loopback: TLS, persistent identity, bounded hosts/requests/artifacts/rates, expiring invitations, durable revocation evidence, and separate public publication/private API routes. Begin with reviewed immutable-artifact retrieval. No default public bind, silent LAN discovery, or UPnP.

## Lab — bounded WebRTC courier

Transfer exactly one reviewed immutable artifact; preserve Source Notes; show signaling/STUN/TURN; refuse replay, identity/digest mismatch, timeout, and partial completion; destroy the session. Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## Reproduction and packaging

Focused: `python3 tools/verify-rev0094-source-notes.py`.
Full regressions: `python3 tools/run-rev0094-regressions.py`.
Prebuild: `python3 tools/prebuild-validate-rev0094.py`.
Build: `python3 tools/build-reconstruction-roadcase.py`.

Prepared sessions, managed browser smoke, native tests, and synthetic fixtures do not close target-host runtime or human fieldwork rows.
