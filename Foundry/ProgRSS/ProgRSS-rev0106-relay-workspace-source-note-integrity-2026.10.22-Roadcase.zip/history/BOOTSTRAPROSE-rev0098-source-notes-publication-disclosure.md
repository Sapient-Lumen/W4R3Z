# `/run` authority — rev0098 Source Notes publication disclosure

Candidate: **rev0098-source-notes-publication-disclosure**. Product lineage remains **rev0080 / 0.80.0**. Immediate parent: `ProgRSS-rev0097-source-notes-lineage-preservation-2026.10.21-Roadcase.zip`; SHA-256 `65643a4899276bdbbc348aacee60a3db2c84a23c70f3c4f32df3ec03188a4336`. Rev0081 and rev0082 remain unavailable and unrecovered.

## Reproduced failure and correction

The rev0097 native ProgRSS JSON preserved direct folder/source reasons, but both shipped ready-to-host HTML generators omitted those reasons from the recipient-facing **What it follows** hierarchy. The same source could therefore carry different valid reasons in two folders while a visitor saw neither. The parent behavior is retained in `evidence/rev0098/reproduction/`.

rev0098 keeps the native data model unchanged and corrects only the generated static recipient surface:

- show each optional reason beside its exact direct folder/source placement;
- keep two reasons for the same source distinct across folders;
- omit the visual block when no reason exists;
- label the text **Curator’s reason for this folder**;
- explain curator authorship and that the text is not a ProgRSS safety claim;
- HTML-escape the value, preserve line breaks, use `dir="auto"`, and reflow at narrow widths;
- report the reason count in HTML, README, and export summary;
- retain the native JSON unchanged as the authoritative portable artifact;
- keep OPML free of Source Notes and explain that omission rather than inventing a private attribute.

Chromium-source and generated-Firefox publication-site bytes must remain identical. No browser permission, persistent store, network behavior, account, identity, pairing, schedule, notification, ranking, profile, reaction, or messaging capability may expand.

## P0.1 — exact candidate in actual browser triad

Run the frozen rev0098 Roadcase independently in unmanaged then-current Chromium Stable, Firefox Release, and Firefox ESR. Use freshly captured official channel evidence on each host. Execute the unchanged fixed 18-case catalog and retain first failures, interruptions, retries, and recovery.

The existing `two-folder-independence` and `complete-route-disclosure` cases now include the ready-to-host package: one source in two folders with different reasons, absent reason omission, markup escaping, multiline and bidirectional text, visible curator/non-safety wording, native JSON preservation, and exact OPML omission. Retain every inherited Lineage, Workbench, repair, stale-removal, saturated-concurrency, Undo, restart, integrity, branch, and permission observation.

Temporary Firefox loading remains development-runtime evidence only. Signed-install restart and installation-time permission conclusions require their own evidence.

## P0.2 — unfamiliar people, privacy, and real assistive technologies

After the browser triad passes, test unfamiliar curators and recipients without teaching the model first. Ask what level each reason belongs to, who wrote it, whether it is a safety claim, and what is lost in OPML. Compare native-file and static-page understanding. Review sender and recipient privacy evidence separately. Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions. Make only the smallest correction supported by recurring independent wrong turns.

## P1 — organization evidence

Measure one-week route re-finding before adding private labels or saved views. Keep folders human-curated and shareable, preserve **Unfiled**, and keep Source Note wording out of engagement ranking and opaque recommendations. Do not expand Source Notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

Keep remote mode explicit and separate from loopback. Require TLS, persistent Node identity, bounded hosts/requests/artifacts/rates, expiring invitations, and durable revocation evidence. Keep public publication routes separate from private APIs. Begin with reviewed immutable-artifact retrieval; no default public bind, silent LAN discovery, or UPnP.

## Lab — WebRTC courier

Transfer exactly one reviewed immutable artifact, make signaling/STUN/TURN visible, refuse replay/identity/digest/timeout/partial-completion failures, and destroy the session after the bounded transfer. Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## Change discipline

Do not add another evidence layer merely because target-host access is unavailable. Further implementation changes require a reproduced failure. Managed harnesses and rendering automation are regression evidence, not installed-browser, participant, privacy-comprehension, or accessibility-conformance evidence.
