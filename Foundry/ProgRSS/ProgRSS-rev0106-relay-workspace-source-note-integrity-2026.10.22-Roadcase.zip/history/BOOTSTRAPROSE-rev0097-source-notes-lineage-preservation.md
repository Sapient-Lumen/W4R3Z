# `/run` authority — rev0097 Source Notes Lineage preservation

This is the sole current checklist. Earlier authorities are historical under `history/` and do not establish current-candidate behavior.

## Candidate and limits

Candidate: **rev0097-source-notes-lineage-preservation**. Product lineage remains **rev0080 / 0.80.0**. Immediate parent: `ProgRSS-rev0096-source-notes-workbench-preservation-2026.10.21-Roadcase.zip`; SHA-256 `ba96be5d2e94b8237e4373bb5fd01ee555094826dd667b9d6252e01312fe6684`. Rev0081 and rev0082 remain unavailable and unrecovered.

**Release gate: NOT SATISFIED.** The rev0096 Lineage recipient path reproducibly published a direct-placement reason and then lost it during remote-to-local ID remapping. Rev0097 corrects that native and managed shipped-Workbench path, but no unmanaged then-current Chromium, Firefox Release, Firefox ESR, unfamiliar-person, real assistive-technology, or human permission-prompt session has passed these exact Extension bytes. Older installed-browser records are historical only. No enterprise policy was changed.

## Completed: Lineage editions preserve placement reasons

- [x] Reproduce rev0096 publishing a reason in the immutable edition, then dropping it in both preview and adoption.
- [x] Preserve canonical reasons while remapping every remote source ID to its stable local ID.
- [x] Preserve separate reasons when one source appears directly in two folders.
- [x] Preserve reasons on locally retained placements when a simultaneous structural conflict keeps local membership.
- [x] Include reason-only changes in the immutable edition digest and publication fingerprint.
- [x] Apply three-way base / recipient / curator comparison to each direct placement.
- [x] Automatically preserve only one-sided or identical reason changes.
- [x] Treat divergent edits, deletion-versus-edit, edit-versus-deletion, and different additions as unresolved.
- [x] Provide placement-scoped **Keep mine** and **Use curator’s** controls in the shipped Lineage review.
- [x] Keep approval disabled until every displayed Source Note conflict has a choice.
- [x] Re-run integrity, identity, three-way comparison, and decision validation at commit.
- [x] Reject invalid, unknown, partial, or stale decisions; no automatic conflict winner.
- [x] Clear uncommitted choices when review closes, is dismissed, is replaced, or succeeds.
- [x] Pass 11 native Lineage cases and 4 shipped-Workbench UI-path cases per Chromium-source and generated-Firefox package.
- [x] Keep shared Lineage, Workbench, HTML, and CSS bytes identical between Chromium source and generated Firefox.
- [x] Observe no network activity in the focused paths.
- [x] Keep required, optional, host, and optional-host permission projections unchanged.

The Workbench harness substitutes a deterministic in-page persistence backend. Native and managed UI replay are regression evidence, not installed-browser, participant, privacy-comprehension, assistive-technology, or accessibility-conformance evidence.

The explicit-decision rule follows a conservative three-way-merge pattern: reconcile one-sided/equal changes, stop on true divergence, and require a reviewed choice. This is a design analogy only; ProgRSS does not use Git's merge engine.

## P0.1 — exact rev0097 candidate in the browser triad

Freeze and use this exact Roadcase. Capture fresh official channel payloads and the actual executable identity on each target host. Run all 18 fixed cases independently in:

1. Unmanaged then-current Chromium Stable.
2. Firefox Release.
3. Firefox ESR.

The `two-folder-independence` and divergent-copy cases now also require:

- Publish a first Lineage edition containing one source in two folders with different reasons.
- Review and adopt it through Courier → Lineage; both reasons must survive remote-to-local ID remapping.
- Publish a curator-only reason change; it must merge when the recipient copy is unchanged.
- Make a recipient-only change while the curator changes another field; the recipient reason must remain.
- Make the same reason change on both sides; it must not create a false conflict.
- Create a true divergent edit; approval must remain disabled until **Keep mine** or **Use curator’s** is chosen.
- Run separate copies for both choices and verify the selected placement only.
- Repeat edit-versus-deletion and deletion-versus-edit.
- Close and reopen review; an uncommitted decision must not persist.
- Change the live copy after preview; the old decision must be rejected as stale.
- Exercise a simultaneous structural conflict where local membership is preserved; the retained local placement must keep its reason.
- Retain the Advanced Workbench collection-edit preservation and same-source repair cases already required by rev0096.

Retain every existing destructive-action and concurrency check: stale initial removal below the ceiling, replacement-placement refusal at folder version `10000`, stale reason save and Undo, stale folder-add Undo, whole-placement removal/Undo, restart persistence, complete-route disclosure, selected-branch preservation, OPML omission, native-integrity mutation refusal, and both native later-copy decisions.

Preserve first failures, interruptions, retries, recovery, two live views, same-profile restart, actual native JSON artifacts, installation method, permission observations, browser build, OS build, profile state, and package/executable digests. Finalize and independently verify each evidence ZIP against the same immutable Roadcase. Triad comparison reports differences but does not approve release automatically.

Firefox temporary loading must not be reported as signed-install permission-prompt or restart evidence. Keep temporary-runtime and packaged/signed-install conclusions separate.

Do not add another evidence layer merely because target-host browser access is unavailable. Make another implementation change only for a reproduced failure.

## P0.2 — unfamiliar people and real assistive technologies

Only after all three exact browser rows pass:

- Ask unfamiliar curators what level the reason belongs to.
- Put one source in two folders and ask why the reasons differ.
- Ask whether editing, Lineage adoption, or a conflict choice published anything, contacted anyone, or created a schedule.
- Ask unfamiliar recipients who wrote the reason and whether it is a ProgRSS safety claim.
- Test first-edition adoption, curator-only and recipient-only changes, and both **Keep mine / Use curator’s** choices without teaching the model first.
- Test Advanced Workbench preservation and deliberate-removal expectations.
- Test same-source repair conflicts and native later-copy conflicts separately from Lineage conflicts.
- Test selected-branch preservation and OPML omission/loss explanations.
- Review privacy evidence separately from sender and recipient perspectives.
- Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions.
- Make only the smallest correction supported by recurring independent wrong turns.

## P1 — sharing and organization

- Test whether reasons improve delayed route re-finding after one week.
- Determine whether folder–source reasons reduce the need for premature private-label or saved-view complexity.
- Keep folders human-curated and shareable.
- Preserve **Unfiled** as a legitimate state.
- Keep Source Note wording out of engagement ranking and opaque recommendation systems.
- Do not expand Source Notes into comments, reactions, profiles, notifications, or social identity.

## P2 — remote Nodes

- Keep remote mode explicit and separate from loopback.
- Require TLS and persistent Node identity.
- Bound hosts, requests, artifacts, and rates.
- Add expiring invitations and durable revocation evidence.
- Keep public publication routes separate from private APIs.
- Begin with reviewed immutable-artifact retrieval.
- No default public bind, silent LAN discovery, or UPnP.

## Lab — WebRTC courier

- Transfer exactly one reviewed immutable artifact.
- Preserve Source Notes through the native artifact.
- Make signaling, STUN, and TURN visible.
- Refuse replay, identity mismatch, digest mismatch, timeout, and partial completion.
- Destroy the session after the bounded transfer.
- Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## Reproduction and packaging

Focused: `python3 tools/verify-rev0097-source-notes.py`.  
Full regressions: `python3 tools/run-rev0097-regressions.py`.  
Prebuild: `python3 tools/prebuild-validate-rev0097.py`.  
Build: `python3 tools/build-reconstruction-roadcase.py`.

Prepared sessions, managed browser smoke, native tests, and synthetic fixtures do not close target-host runtime or human fieldwork rows.
