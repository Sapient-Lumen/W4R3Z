# `/run` authority — rev0096 Source Notes Workbench preservation

This is the sole current checklist. Earlier authorities are historical under `history/` and do not establish current-candidate behavior.

## Candidate and limits

Candidate: **rev0096-source-notes-workbench-preservation**. Product lineage remains **rev0080 / 0.80.0**. Immediate parent: `ProgRSS-rev0095-source-notes-reviewed-removal-2026.10.21-Roadcase.zip`; SHA-256 `d1ff9b25af231829506ba73a2a72cb7633a11ab8130476b5be486c6df5411745`. Rev0081 and rev0082 remain unavailable and unrecovered.

**Release gate: NOT SATISFIED.** A reproduced Advanced Workbench data-loss defect is corrected in managed shipped-UI-path scope, but no unmanaged then-current Chromium, Firefox Release, Firefox ESR, unfamiliar-person, real assistive-technology, or human permission-prompt session has passed these exact Extension bytes. Older installed-browser records are historical only. No enterprise policy was changed.

## Completed: Workbench collection edits preserve Source Notes

- [x] Reproduced the frozen rev0095 Advanced Workbench erasing every direct-placement reason in an edited collection after a title-only save.
- [x] Confirmed an independent folder remained unchanged, localizing the failure to the edited collection projection.
- [x] Preserve canonical reasons for selected direct source placements by **source identity**, not member index.
- [x] Preserve reasons across title, include/exclude, union/intersection/subtract, and base-member ordering edits.
- [x] Treat an unchecked source as deliberate removal of that placement and its reason; leave surviving and independent-folder reasons intact.
- [x] Give a newly selected source no invented reason.
- [x] Canonicalize identical duplicate placements without reason loss.
- [x] Refuse different-reason, absence-versus-reason, invalid, over-limit, and wrong-level prior placement data without mutation or an automatic winner.
- [x] Pass 11 shipped-Workbench UI-path cases against Chromium-source and generated-Firefox packages; shared Workbench product bytes are identical.
- [x] Observe no network requests in the focused harness.
- [x] Keep required, optional, host, and optional-host permission projections unchanged.

The harness replaces only the persistence backend with a deterministic in-page store. It does not establish installed-browser, target-host, human, privacy-comprehension, assistive-technology, or accessibility-conformance evidence.

## P0.1 — exact corrected candidate in actual browsers

Freeze and use this exact Roadcase. Capture fresh official channel payloads on each target host. Run all 18 fixed cases independently in unmanaged then-current Chromium Stable, Firefox Release, and Firefox ESR.

The `two-folder-independence` case now requires:

- Put one source in two folders with different reasons and verify both remain independent.
- Open one reason-bearing folder in **Advanced Workbench** and make title, filter, mode, and member-order edits; selected source placements must keep their reasons by source identity, while the other folder remains unchanged.
- Deliberately uncheck one source and verify only that direct placement and reason are removed.
- Select a new source and verify no reason is invented.
- Present conflicting duplicate, absence-versus-reason, over-limit, and wrong-level prior data; save must refuse without mutation.
- Retain same-source repair preservation, separate-folder independence, divergent same-folder refusal, and repair Undo.

Retain all existing destructive-action and concurrency checks: stale initial removal below the ceiling, replacement-placement refusal at folder version `10000`, stale reason save and Undo, stale folder-add Undo, whole-placement removal/Undo, restart persistence, complete-route disclosure, selected-branch preservation, OPML omission, native-integrity mutation refusal, and both later-copy decisions. Preserve first failures, interruptions, retries, recovery, actual installation and permission observations, two live views, same-profile restart, and actual native JSON artifacts.

Firefox temporary loading must not be reported as signed-install permission-prompt or restart evidence. Finalize and independently verify each evidence ZIP against the same immutable Roadcase; comparison reports differences but does not approve release automatically.

Do not create another evidence layer merely because target-host access is unavailable. Make another implementation change only for a reproduced failure.

## P0.2 — unfamiliar people and real assistive technologies

After the browser triad: test unfamiliar curator and recipient comprehension of relationship level, one-source/two-folder differences, Workbench preservation/removal consequences, authorship, local-only consequences, absence of a safety claim, branch expectations, OPML loss, divergent later-copy decisions, add/remove whole-placement Undo, repair refusal, and stale-action refusal. Review sender and recipient privacy evidence separately.

Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions. Apply only the smallest correction supported by recurring independent wrong turns. Managed UI smoke, browser API doubles, digests, and unsigned records are not human or AT evidence.

## P1 — delayed re-finding and organization

Test one-week delayed route re-finding before private labels or saved views. Keep folders human-curated and shareable, Source Notes optional, and **Unfiled** legitimate. Do not use note wording for engagement ranking or opaque recommendation, and do not expand Source Notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

Remote mode remains explicit and separate from loopback: TLS, persistent identity, bounded hosts/requests/artifacts/rates, expiring invitations, durable revocation evidence, and separate public publication/private API routes. Begin with reviewed immutable-artifact retrieval. No default public bind, silent LAN discovery, or UPnP.

## Lab — bounded WebRTC courier

Transfer exactly one reviewed immutable artifact; preserve Source Notes; show signaling/STUN/TURN; refuse replay, identity/digest mismatch, timeout, and partial completion; destroy the session. Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## Reproduction and packaging

Focused: `python3 tools/verify-rev0096-source-notes.py`.  
Full regressions: `python3 tools/run-rev0096-regressions.py`.  
Prebuild: `python3 tools/prebuild-validate-rev0096.py`.  
Build: `python3 tools/build-reconstruction-roadcase.py`.

Prepared sessions, managed browser smoke, native tests, and synthetic fixtures do not close target-host runtime or human fieldwork rows.
