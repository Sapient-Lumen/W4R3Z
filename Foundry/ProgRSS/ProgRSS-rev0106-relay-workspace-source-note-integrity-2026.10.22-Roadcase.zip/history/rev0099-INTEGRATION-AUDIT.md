# Integration audit — rev0099-unified-baseline

Date: 2026-10-22. Product lineage: rev0080 / 0.80.0. Candidate only.

## What the re-upload establishes

`ProgRSS-rev0080-2026.10.20-Roadcase(2).zip` and the original `(1)` copy are byte-for-byte identical:

```
181308cabfae43330016a272a64fbdb33038f841d605f4756ec65bedb43b8106
```

Both are 6,103,199 bytes. All 395 baseline files already exist in rev0098:
357 are byte-identical, 38 have later changes, and no baseline paths or POSIX modes are missing.
The source tree was not missing the original reader, Node, CLI, Capture/Witness/Pulse,
Exchange, Fieldbook/Debrief, or Roadcase components. Presence alone is not behavioral acceptance.

## Actual integration gap

Two different delivered candidates used rev0091. The main path continued through
`source-notes-folder-undo`; the separately delivered `source-notes-runtime-record-integrity`
changes did not follow it into rev0098. Full archive names and SHA-256 values—not revision
numbers alone—are the identities in `INTEGRATION-AUDIT.json`.

A fresh synthetic replay against rev0098 accepted nine invalid records as passes:
an impossible calendar timestamp, out-of-run case times (before and after), an out-of-run
event, unknown result/case/event claims, empty passing permission projections, and an
invented native-artifact role. The merged code refuses all nine. A valid synthetic control
still passes. These are verifier tests, not evidence that a browser or participant ran.

The implementation, schema, preparer instructions, and missing regression tests were
merged from the delivered integrity branch using their delivered rev0090 common ancestor.
No older product tree or case catalog was copied over the newer one.

## Continuity

All 114 CLI files and 210 Extension files are byte- and mode-identical to rev0098.
All 18 behavioral case objects are unchanged. Later folder Undo, repair, stale-removal,
Workbench, Lineage, and publication-disclosure fixes remain in place. No permissions,
persistent state, runtime network authority, or ordinary product behavior was expanded.

Sessions now use v5 and results/predicates use v3, as in the recovered donor changes.
Prepare new sessions; do not relabel old v4/v2 evidence as new evidence.

## Unavailable material and prior claims

Rev0081 and rev0082 remain unavailable. The earlier conversation also described a
`rev0090-source-notes-browser-execution-binding` archive, but no such source archive is
among the supplied files. Its supplied POSTCHECK is FAIL and lists missing outputs.
That claimed executable-receipt implementation is **not established as delivered** and
is not silently represented as merged. Capture ordinary observed browser identity, but
do not claim receipt tooling, continuous process identity, or authenticated execution.

## Verification scope

Fresh offline regression logs, exact product inventories, merge decisions, and the
before/after reproduction are retained under `evidence/rev0099/`. Final build checks are
external to the immutable archive. Current target browsers, real users, and assistive
technologies remain untested on this candidate. No browser policy was changed.
