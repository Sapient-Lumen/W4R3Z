# `/run` authority — rev0093 Source Notes saturated concurrency

This is the sole current checklist. Earlier authorities are historical under `history/` and do not establish current-candidate behavior.

## Candidate and limits

Candidate: **rev0093-source-notes-saturated-concurrency**. Product lineage remains **rev0080 / 0.80.0**. Immediate parent: `ProgRSS-rev0092-source-notes-repair-conflicts-2026.10.21-Roadcase.zip`; SHA-256 `b22612bdaabf340e791bfc1ec55e7396c4fd0c4ed7606513d8aed3fd2b6e48c2`. Rev0081 and rev0082 remain unavailable and unrecovered.

**Release gate: NOT SATISFIED.** A reproduced stale-placement write at the folder-version ceiling is corrected in native/managed scope, but no unmanaged then-current Chromium, Firefox Release, Firefox ESR, unfamiliar-person, real assistive-technology, or human permission-prompt session has passed these exact Extension bytes. Do not reuse older installed-browser records as acceptance for changed product bytes. No enterprise policy was changed.

## Completed: saturated placement-generation guard

- [x] Reproduced rev0092 accepting an old Source Note editor after its reviewed direct placement was removed, recreated, and given the same reason while folder version remained saturated at `10000`.
- [x] Reproduced the corresponding old Undo applying to that replacement relationship.
- [x] Exposed the persisted vault revision in the side panel's public state without adding a new store or in-memory generation token.
- [x] Required the exact reviewed vault revision for Source Note save and Undo only when the folder version is `10000`.
- [x] Kept existing folder-version and prior-reason guards at every version.
- [x] Returned the committed vault revision with a successful edit so the guarded 12-second Undo is bound to the exact saved state.
- [x] Carried the revision through the shipped side-panel edit and Undo requests.
- [x] Refused missing, wrong, stale, replacement-placement, and unrelated-intervening-write revisions at the ceiling without mutation.
- [x] Preserved the less disruptive rule below the ceiling: an unrelated vault write does not invalidate a placement review when the folder version and reviewed reason still match.
- [x] Replayed the focused corpus against Chromium source and generated Firefox bytes; shared background and side-panel files remain byte-identical.
- [x] Kept required, optional, host, and optional-host permission projections unchanged.

The persisted revision is a conservative generation guard at the version ceiling. It is not a new user-visible identifier, remote token, account concept, or authenticity claim.

## P0.1 — exact corrected candidate in actual browsers

Freeze and use this exact Roadcase. Capture fresh official channel payloads on each target host. Run all 18 fixed cases independently in unmanaged then-current Chromium Stable, Firefox Release, and Firefox ESR.

Cases `two-view-stale-save-refused` and `two-view-stale-undo-refused` now require a ceiling-specific step: set the folder version to `10000`, review a reason, remove and recreate the same direct placement with matching wording, then prove the old save or Undo is refused. Retain the existing same-source repair-conflict, whole-placement removal/Undo, two-folder independence, restart, disclosure, OPML omission, integrity, and later-copy conflict checks.

Retain first failures, interruptions, retries, recovery, actual installation and permission observations, two live views, same-profile restart, and actual complete-route and selected-branch native JSON. Firefox temporary loading must not be reported as signed-install permission-prompt or restart evidence. Finalize and independently verify each evidence ZIP against the same immutable Roadcase; comparison reports differences but does not approve release automatically.

Do not create another evidence layer merely because target-host access is unavailable. Make another implementation change only for a reproduced failure.

## P0.2 — unfamiliar people and real assistive technologies

After the browser triad: test unfamiliar curator and recipient comprehension of relationship level, one-source/two-folder differences, authorship, local-only consequences, absence of a safety claim, branch expectations, OPML loss, divergent later-copy decisions, whole-placement Undo, repair refusal, and stale-placement refusal. Review sender and recipient privacy evidence separately.

Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions. Apply only the smallest correction supported by recurring independent wrong turns. Managed DOM smoke, browser API doubles, digests, and unsigned records are not human or AT evidence.

## P1 — delayed re-finding and organization

Test one-week delayed route re-finding before private labels or saved views. Keep folders human-curated and shareable, Source Notes optional, and **Unfiled** legitimate. Do not use note wording for engagement ranking or opaque recommendation, and do not expand Source Notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

Remote mode remains explicit and separate from loopback: TLS, persistent identity, bounded hosts/requests/artifacts/rates, expiring invitations, durable revocation evidence, and separate public publication/private API routes. Begin with reviewed immutable-artifact retrieval. No default public bind, silent LAN discovery, or UPnP.

## Lab — bounded WebRTC courier

Transfer exactly one reviewed immutable artifact; preserve Source Notes; show signaling/STUN/TURN; refuse replay, identity/digest mismatch, timeout, and partial completion; destroy the session. Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## Reproduction and packaging

Focused: `python3 tools/verify-rev0093-source-notes.py`.
Full regressions: `python3 tools/run-rev0093-regressions.py`.
Prebuild: `python3 tools/prebuild-validate-rev0093.py`.
Build: `python3 tools/build-reconstruction-roadcase.py`.

Prepared sessions, managed browser smoke, native tests, and synthetic fixtures do not close target-host runtime or human fieldwork rows.
