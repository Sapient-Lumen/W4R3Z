# Candidate build state — rev0098

The working candidate passed focused static-publication disclosure replay and the complete offline/native plus managed regression sweep before packaging. Deterministic archive construction, independent third-build comparison, and external evidence-bundle verification are performed after this source tree is frozen. The release gate remains open for exact target-host Chromium, Firefox Release, Firefox ESR, unfamiliar-person, privacy-comprehension, and real assistive-technology evidence.
