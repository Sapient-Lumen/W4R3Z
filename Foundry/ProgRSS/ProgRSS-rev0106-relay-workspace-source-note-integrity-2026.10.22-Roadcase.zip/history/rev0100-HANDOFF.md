# Handoff — rev0100-node-branch-source-note-disclosure

Start with `BOOTSTRAPROSE.md`, the Node disclosure audit, the detached final verification, and the
runtime matrix. The reproduced defect was visual review loss, not native artifact loss: the Node API
already carried exact placement reasons, while the shipped review screen omitted them. Preserve the
narrow UI fix and do not expand pairing or Node authority.

Prepare fresh rev0100 session-v5 records from the exact sealed Roadcase; do not relabel rev0099
sessions. Next: install the exact sealed candidate on actual unmanaged then-current Chromium, Firefox Release,
and Firefox ESR hosts. Run the complete 18-case corpus plus the whole-product boundaries, including
the Node branch chooser/preview count, exact route-bound reasons, literal multiline and bidirectional
text, non-safety wording, and committed native preservation. Then run separate unfamiliar-person,
privacy, and real assistive-technology sessions. Do not substitute prepared or managed sessions.
