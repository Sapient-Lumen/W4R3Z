# `/run` authority — rev0091 runtime-record integrity

This file is the sole current checklist. Earlier authority is preserved in
`history/BOOTSTRAPROSE-through-rev0089.md` and `history/BOOTSTRAPROSE-rev0090.md`;
those files are history, not competing instructions.

## Candidate and release boundary

Candidate: **rev0091-source-notes-runtime-record-integrity**. Product lineage
remains **rev0080 / 0.80.0**. Rev0081 and rev0082 remain unavailable and
unrecovered. Immediate parent: rev0090 Roadcase, SHA-256
`9245f25fcf7dc55d29e012488cfa33edf5abf49c6ac058e44419a6da3f3a4540`.

**Release gate: NOT SATISFIED.** No current unmanaged Chromium, Firefox Release,
Firefox ESR, unfamiliar-person, or real assistive-technology acceptance was run
this turn. The 112 CLI and 202 Extension files are unchanged in bytes and modes.
No permission, policy, pairing, scheduling, network, or private-state capability
was added. Earlier browser evidence retains its original archive and environment
scope; it is not relabeled as rev0091 acceptance.

## Completed in this turn — reproduced verifier repair

- [x] Reproduced the frozen rev0090 verifier accepting nine invalid synthetic
  passing records: impossible calendar time, case/event times outside the declared
  run, arbitrary top/case/event claims, an empty permission projection, and an
  invented native-artifact role.
- [x] Require real Gregorian UTC values in `YYYY-MM-DDTHH:MM:SSZ` form.
- [x] Require start and finish together; require finish not before start even for
  failed runs; require every attempted/blocked case and every event inside the
  declared runtime interval.
- [x] Close claim-bearing result and session objects to their exact supported keys.
  Unknown fields are refused rather than copied into the unsigned statement.
- [x] Restrict native artifact roles to `completeRoute` and `selectedBranch`, and
  restrict declarations to the supported evidence path and optional derived values.
- [x] Require a nonempty, closed four-list permission projection before the
  `permission-state-unchanged` case can pass; reject duplicate permission values.
- [x] Reject duplicate evidence paths within a case.
- [x] Align the published result schema with runtime-result v3 and the closed
  validator. Prepared sessions are v5; the unsigned predicate is v3.
- [x] Preserve all 18 behavioral cases. Chronology and record integrity are
  mandatory validation postconditions, not a nineteenth product-behavior case.
- [x] Add isolated per-test execution so one slow synthetic verifier test cannot
  obscure which boundary failed.

This is a verifier correction supported by a reproduced failure. It is not a new
claim layer created merely because target-host execution is unavailable.

## P0.1 — actual target-host browser triad (next release blocker)

1. Re-read and retain fresh official browser-channel payload bytes on the target
   host. The 2026-10-21 planning reference is Chromium Stable `156.0.8078.47`,
   Firefox Release `158.0.1`, and Firefox ESR `153.5.1esr`; do not hardcode these
   for a later run.
2. Prepare **new rev0091** sessions from the frozen Roadcase. Do not relabel v4/v2
   sessions: rev0091 requires session v5, result v3, and predicate v3.
3. Start a passing attempt within the bound 24-hour channel-capture interval.
4. Run all 18 cases in unmanaged then-current Chromium, retaining the first
   failure, interruption, retry, and recovery—not merely the final state.
5. Record a calendar-valid start/finish interval. Every attempted/blocked case and
   event timestamp must lie inside it. Unknown claim fields are invalid.
6. For the passing permission case, retain complete before/after arrays for
   required, optional, host, and optional-host permissions. Empty projections do
   not establish unchanged state.
7. Retain actual complete-route and selected-branch native JSON. Logs or invented
   artifact roles cannot substitute.
8. Independently repeat Firefox Release and Firefox ESR. Resolve installation and
   restart method before interpreting permission prompts; temporary Firefox
   installation is not signed-install prompt evidence.
9. Finalize, independently verify, and compare all three complete evidence ZIPs
   against the same immutable Roadcase. Comparison reports differences; it does
   not automatically decide release acceptance.

An unavailable run remains blocked/not run. Do not alter enterprise policy or
substitute managed Chromium 144. Do not add more tooling unless another concrete
failure is reproduced.

## P0.2 — unfamiliar people and real assistive technologies

Only after the browser triad passes, test unfamiliar curator and recipient
understanding of relationship level, one source in two folders, authorship,
publication/contact/scheduling consequences, absence of a ProgRSS safety claim,
branch expectations, OPML loss, and both divergent-copy decisions.

Run distinct screen-reader, refreshable-Braille, voice-control, switch-control,
high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption
sessions. Review sender and recipient privacy evidence separately. Make only the
smallest correction supported by recurring independent wrong turns. Automated
DOM smoke and unsigned runtime records are not participant or AT evidence.

## P1 — delayed re-finding and organization

Test one-week delayed route re-finding before adding private labels or saved views.
Keep folders human-curated and shareable, Source Notes optional, and **Unfiled**
legitimate. Keep note wording out of engagement ranking and opaque recommendations;
no comments, reactions, profiles, notifications, or social-activity expansion.

## P2 — remote Nodes

Keep remote mode explicit and separate from loopback. Require TLS, persistent Node
identity, bounded hosts/requests/artifacts/rates, expiring invitations, durable
revocation evidence, and separate public-publication/private-API routes. Begin
with reviewed immutable-artifact retrieval. No default public bind, silent LAN
discovery, or UPnP.

## Lab — bounded WebRTC courier

Transfer one reviewed immutable artifact per session. Preserve Source Notes in the
native artifact; expose signaling/STUN/TURN; refuse replay, identity/digest
mismatch, timeout, and partial completion; destroy the session afterward. Never
require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or
Pulse.

## Verification and continuation

Run `python3 tools/verify-rev0091-source-notes.py` for the focused gate and
`python3 tools/prebuild-validate-rev0091.py` before packaging. The deterministic
builder performs two constructions, archive verification, clean extraction,
byte/mode comparison, focused replay, CLI doctor, prepared-session checks, and a
not-run evidence round trip. External reports seal the final ZIP without a
circular in-archive digest.

The statement remains unsigned: no authenticated operator, browser execution,
network capture, trusted timestamp, human presence, SLSA level, privacy
comprehension, accessibility conformance, or release readiness is inferred.
