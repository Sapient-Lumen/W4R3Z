# rev0106 — Relay workspace Source Note integrity

- Validate private Source Note placements in the shared Relay workspace loader.
- Revalidate derived private state before Relay workspace output.
- Cover all six Relay workspace command paths.
- Preserve valid route-specific reasons; refuse nine malformed forms without output or premature network work.
- Keep the fixed 18-case catalog and every inherited whole-product boundary.
