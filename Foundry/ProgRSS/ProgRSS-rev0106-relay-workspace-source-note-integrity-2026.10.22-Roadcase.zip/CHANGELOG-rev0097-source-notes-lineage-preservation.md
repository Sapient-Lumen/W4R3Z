# Changelog — rev0097 Source Notes Lineage preservation

- Fixed recipient Lineage preview/adoption dropping direct-placement reasons during remote-to-local ID remapping.
- Added placement-level three-way Source Note comparison for Lineage updates.
- Added explicit **Keep mine** / **Use curator’s** Workbench controls with no automatic conflict winner.
- Added stale/partial/unknown decision refusal and commit-time re-planning.
- Preserved reasons on locally retained placements during structural conflicts.
- Added native and shipped-Workbench regression harnesses for Chromium-source and generated Firefox.
- Kept CLI bytes, browser permission projections, and network boundary unchanged.
