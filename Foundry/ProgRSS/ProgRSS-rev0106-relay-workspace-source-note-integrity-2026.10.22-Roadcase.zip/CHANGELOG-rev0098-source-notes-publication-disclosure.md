# Changelog — rev0098 Source Notes publication disclosure

## Corrected

- Ready-to-host CLI and Extension HTML now renders each optional Source Note beside its exact direct folder/source placement.
- The same source can display different curator reasons in different folders without conflation.
- Missing reasons produce no placeholder or invented text.
- Generated HTML escapes reason text, preserves line breaks, applies natural text direction, and reflows at narrow widths.
- Recipient-facing copy identifies curator authorship and states that a reason is not a ProgRSS safety claim.
- Export summaries, page facts, and package README files report the number of curator reasons.
- Native ProgRSS JSON remains authoritative and byte-semantic behavior is unchanged.
- OPML still omits Source Notes; the package README explains the loss rather than adding a private attribute.

## Tests

- Added focused CLI ready-to-host publication tests.
- Added a shared Chromium/generated-Firefox publication-site harness.
- Extended the managed side-panel download smoke and static checks.
- Added the static-publication assertions to the existing 18-case runtime protocol without creating a nineteenth case.

## Scope

No browser permission, persistent store, network authority, account, identity, pairing, schedule, notification, ranking, profile, reaction, or messaging capability was added. Installed current-browser and human fieldwork gates remain open.
