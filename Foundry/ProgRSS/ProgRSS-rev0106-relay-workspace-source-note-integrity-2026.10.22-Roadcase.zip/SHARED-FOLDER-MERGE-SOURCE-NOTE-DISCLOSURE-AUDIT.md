# Shared-folder merge Source Note disclosure audit — rev0103

Parent: `ProgRSS-rev0102-node-merge-source-note-disclosure-2026.10.22-Roadcase.zip`  
SHA-256: `e4fa5d3560a37695fa1cee27c5245134edaeb72eaf417321df6d6ec249dfdabd`

## Reproduced defect

The native shared-folder update preview exposed a placement-scoped Source Note conflict without its canonical folder path. The shipped Extension side panel then rendered the conflict as a generic source card. Two conflicts for the same source in identically titled folders could not be distinguished by route, multiline values lost their review context, user-authored text lacked content-derived direction, and the curator/non-safety boundary was absent.

Retained evidence:

- `evidence/rev0103/before-background-harness.log`
- `evidence/rev0103/before-ui-harness.log`
- Parent product bytes under `evidence/rev0103/parent-*`

## Correction

- Native merge rows and placement descriptors now carry the canonical incoming folder path.
- The shipped side panel shows the full route for every Source Note conflict and reviewed change.
- Last accepted, local, and curator values render literally with preserved line breaks, wrapping, and `dir="auto"`.
- The review identifies curator authorship, states that the wording is not a ProgRSS safety claim, and keeps each placement’s **Keep mine / Use curator’s** decision independent.
- Merge classification, decision validation, commit behavior, permissions, persistence, and network authority are unchanged.

## Focused result

- Native background path: **PASS**
- Chromium-source shipped UI path: **4/4 checks passed**
- Generated-Firefox shipped UI path: **4/4 checks passed**
- Complete inherited regression: **PASS**

This is managed native/UI regression evidence. It is not installed-browser, participant, privacy-comprehension, assistive-technology, or accessibility-conformance evidence.
