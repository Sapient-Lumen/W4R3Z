# Result — rev0091 Source Notes folder-removal undo

**Candidate, not release-ready.** Repaired two reproduced folder-removal undo defects:
the returned source lost its reason, and a source still inherited from a nested
folder wrongly prevented restoring its separate direct placement.

The existing short-lived UI undo now carries the canonical removed member and its
original position; the production background validates and restores both. Reasons
remain optional. Invalid or stale requests make no persisted change. At the folder
version cap, the existing vault revision supplies a conservative extra guard. No
new persistent store, permission, network action, schedule, or account is added.

Verification this turn: 22 focused cases per Chromium-source and generated-Firefox
package; 184 CLI tests across all 11 modules; 60 Extension static tests;
nine managed Node harness invocations; 40 evidence-boundary tests. CLI's
112 files remain byte/mode-identical. Only two logical product files changed,
with the same changes generated into Firefox. The full browser-rendering runner
and installed-browser acceptance were NOT RUN. External reports seal final bytes.

## New highest-priority open defect

Actual same-source-repair preview and commit allow two different reasons to collapse
to the first folder member's reason, regardless of selected survivor. The retained
reproduction shows the second source surviving with the first source's reason.
That path is separate from the previously tested later-copy conflict workflow.
It remains OPEN and moves ahead of current-browser runtime in `BOOTSTRAPROSE.md`.

No current/unmanaged browser, permission-prompt, participant, or real assistive-
technology evidence was obtained. The Browser connector lacked its originating
context. No policy was modified and no binary-acquisition failure is newly claimed.
