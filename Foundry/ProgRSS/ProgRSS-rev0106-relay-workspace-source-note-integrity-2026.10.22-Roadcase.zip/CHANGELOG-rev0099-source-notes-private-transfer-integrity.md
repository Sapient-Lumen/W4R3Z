# Changelog — rev0099 Source Notes private-transfer integrity

- Validate direct-placement Source Notes in CLI private-backup loading and Extension private-transfer preview/restore.
- Preserve valid reasons exactly through transfer preview, restore, export, copy checking, and guarded Undo.
- Refuse malformed, wrong-level, noncanonical, missing-source, and reason-bearing duplicate placements before a vault write.
- Refuse outbound private/recovery export when local Source Note state is malformed.
- Add Source Note counts and curator-written folder-reason disclosure to private-transfer summaries and side-panel review.
- Add focused CLI and Chromium/generated-Firefox regression corpora.
- Keep permissions, network authority, storage model, and the fixed 18-case runtime catalog unchanged.
