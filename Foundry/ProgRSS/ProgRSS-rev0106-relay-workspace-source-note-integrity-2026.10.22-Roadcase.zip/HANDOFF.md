# Handoff — rev0106-relay-workspace-source-note-integrity

## Current authority

`BOOTSTRAPROSE.md` is the `/run` authority. Immediate parent: `ProgRSS-rev0105-node-private-library-source-note-integrity-2026.10.22-Roadcase.zip` (`e34cb801d87dd7e4c8bf26cf72ce25e6356af68d20818140691889a59c19dd6c`).

## Reproduced and corrected

The parent Relay loader accepted malformed direct-placement Source Notes. A shipped `workspace import-bundle` run returned success, wrote a new backup, and retained a 281-code-point reason. rev0106 invokes the shared placement audit in `read_workspace` before all six Relay workspace commands and in `write_workspace` before output. Valid route-specific reasons remain exact; nine malformed forms refuse before output, and malformed explicit publication checking refuses before network work.

## Next exact work

Seal the deterministic Roadcase, then run fresh rev0106 18-case and whole-product sessions on actual unmanaged then-current Chromium, Firefox Release, and Firefox ESR hosts. `two-folder-independence` must include valid and malformed Relay share/publish/import/review/check/update behavior and derived-state output refusal. After the triad passes, perform unfamiliar-person, separate privacy, and real assistive-technology fieldwork.

Do not add another evidence layer merely because target-host access is unavailable. Further product changes require a reproduced failure.
