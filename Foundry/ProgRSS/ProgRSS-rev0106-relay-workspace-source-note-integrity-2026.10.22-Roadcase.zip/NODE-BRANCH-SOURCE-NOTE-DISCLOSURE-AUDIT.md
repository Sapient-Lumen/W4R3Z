# Node branch Source Note disclosure audit — rev0100

Date: 2026-10-22. Candidate only. Product lineage: rev0080 / 0.80.0.

## Reproduced failure

The Node-owned branch-adoption API already exposed optional Source Notes at both review levels:

- each branch option carried `sourceNotes`;
- the exact preview carried `contents.sourceNoteCount`;
- each source row carried direct `placements` with `folderId`, `folderPath`, and optional `reason`;
- commit preserved those placement values in the native library.

The shipped `CLI/node_web/app.js` ignored all of those fields. Its branch chooser showed only source
and folder counts. Its exact preview rebuilt each row from title, type, host, and a flattened folder
list. A local administrator could therefore authorize the atomic write without seeing the curator's
relationship explanations.

A managed rendering reproduction against the immutable rev0099 parent supplied two reasons. The
preview displayed both source names and folder route but neither reason count, either reason, nor the
non-safety boundary. The failing assertion and complete visible review text are retained in
`evidence/rev0100/reproduction-before-fix.log`.

## Correction

The shipped Node review now:

- appends the optional curator-reason count to an adoptable branch choice;
- shows a dedicated curator-reason count in the exact preview;
- reports the count in the expandable source summary;
- renders every direct placement route;
- renders each optional reason beside only that route;
- labels it `Curator’s reason for this folder`;
- explains once that these are curator placement explanations and not ProgRSS safety claims;
- uses DOM text nodes, preserved line breaks, long-word wrapping, and `dir="auto"` on the
  user-authored value.

No reason is synthesized when absent. The implementation does not change the API, native artifact,
commit transaction, Node authority, network behavior, or pairing contract.

## Verification scope

The focused shipped-UI fixture contains two reasons, including a multiline right-to-left and
markup-like value. It asserts exact literal text, no child markup, preserved `white-space: pre-wrap`,
`dir="auto"`, reason count, route placement, attribution, and non-safety wording. The native Node test
continues to assert exact placement reasons before and after atomic commit.

Managed rendering is regression evidence only. It is not unmanaged installed-browser acceptance,
human comprehension, privacy review, assistive-technology fieldwork, or accessibility conformance.
