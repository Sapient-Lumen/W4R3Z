# Runtime operator guide — rev0106

1. Verify the immutable Roadcase digest and extract it with executable modes intact.
2. Capture fresh official browser-channel evidence and the actual target-host browser identity.
3. Prepare a new rev0106 session; do not relabel an older record.
4. Run all 18 cases and every whole-product boundary.
5. For Relay workspace integrity, preserve valid route-specific reasons through all six commands, refuse all nine malformed forms before output, prove malformed explicit publication checking makes no network request, and prove malformed derived state is refused before workspace output.
6. Preserve first failures, interruptions, retries, and recovery.
7. Finalize and independently verify the evidence bundle against the same Roadcase.
8. Keep temporary Firefox runtime evidence separate from permanent signed-install, restart, and installation-time permission conclusions.
