# Node three-way Source Note disclosure audit — rev0102

The rev0101 native merge review identified Source Note conflicts by source and repeated folder title, but not by the full direct folder route. The shipped Node UI independently omitted the route even when supplied correct paths, collapsed multiline values through the generic formatter, and omitted explicit **Keep mine / Use curator’s**, curator attribution, and non-safety wording.

The corrected native row includes `folderPath` both at the top level and in the placement descriptor. The shipped review renders a dedicated Source Note card with the full route, exact literal values, preserved line breaks, wrapping, and `dir="auto"`. Two conflicts for the same source in `Civic route › North › Updates` and `Civic route › South › Updates` are distinguishable.

Focused API and shipped-UI tests passed. The Node remains read-only: no apply endpoint, source request, library write, persistent conflict-choice state, browser permission, or network authority was added.
