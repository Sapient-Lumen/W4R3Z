# Reconstruction provenance — rev0106

Immediate parent: `ProgRSS-rev0105-node-private-library-source-note-integrity-2026.10.22-Roadcase.zip`  
SHA-256: `e34cb801d87dd7e4c8bf26cf72ce25e6356af68d20818140691889a59c19dd6c`  
Bytes: 26881071

Continues the sealed rev0105 unified whole-product tree and corrects a reproduced Relay workspace Source Note validation bypass. The shared-folder share, publish, import, review, explicit publication-check, and update commands now use the same private-placement audit before state use and before derived workspace writes. The current parent already contains the unified Node private-library, private-transfer, Exchange, Node branch and merge, shared-folder merge, publication, Lineage, Workbench collection and backup, repair, concurrency, Undo, native-integrity, and runtime-record work. No missing revision is invented.

Compared with the immutable parent while excluding generated provenance and manifest files: **100 added**, **35 changed**, and **0 deleted** paths. The full path lists are retained in `RECONSTRUCTION_PROVENANCE.json`.

Unavailable artifacts remain explicitly unrecovered: rev0081, rev0082, and the undelivered rev0090 browser-execution-binding source archive.
