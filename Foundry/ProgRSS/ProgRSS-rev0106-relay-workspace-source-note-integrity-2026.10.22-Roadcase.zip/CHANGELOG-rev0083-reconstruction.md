# rev0083 reconstruction change log

This is a reconstruction from the supplied rev0080 Roadcase, not recovery of unavailable rev0081 or rev0082 bytes.

## Added in this session

- A shared Python/JavaScript Source Notes contract with byte-compared fixtures.
- Three-way note continuity for base, recipient (“mine”), and curator copies.
- Explicit unresolved conflicts and placement-scoped `keep_mine` / `use_curator` decisions.
- Relationship-level validation, 280-Unicode-code-point parity, empty-value omission, invalid-Unicode rejection, and a companion JSON Schema.
- Branch-scoped OPML omission evidence without a ProgRSS-only OPML attribute.
- A dependency-free, local-only Source Notes fieldwork harness with sender/recipient evidence separation and conflict-comprehension tasks.
- Static privacy/accessibility checks for the harness and a managed-browser smoke runner that cannot be mistaken for fieldwork.
- Conservative native integration and Chromium/Firefox sibling audits.
- Reconstructed `/run` authority and a dedicated Roadcase Source Notes checklist.
- Deterministic, self-verifying Roadcase tooling with direct ZIP and clean-extraction byte/mode verification.
- Machine-readable provenance, current status, audit reports, and candidate-only release language.

## Deliberately not claimed

- No unavailable revision was recovered.
- Native CLI, Node, Extension, canonicalization, integrity, OPML, route disclosure, branch disclosure, or update call-site behavior is called complete without exact replay evidence.
- Automated browser smoke is not an unmanaged-browser run, Firefox ESR run, accessibility evaluation, privacy review, or participant session.
- No account, permission, pairing, scheduling, discovery, notification, social, recommendation, or remote-service surface was added for Source Notes.

## Next release blockers

1. Bind the reference three-way rule to every native update call site and replay it through CLI, Node, Extension, Chromium, and generated Firefox artifacts.
2. Prove browser permission parity against the matched rev0080 manifests.
3. Run the exact candidate on unmanaged current Chromium, current Firefox Release, and current Firefox ESR.
4. Conduct de-identified unfamiliar-curator, unfamiliar-recipient, assistive-technology, fatigue, and interruption sessions.
5. Make only the smallest correction supported by recurring wrong turns, then replay the affected task and rebuild the Roadcase.
