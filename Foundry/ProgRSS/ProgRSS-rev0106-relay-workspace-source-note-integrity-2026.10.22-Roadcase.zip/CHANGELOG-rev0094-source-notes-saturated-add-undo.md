# Changelog — rev0094-source-notes-saturated-add-undo

- Reproduced rev0093 accepting a stale **add source to folder** Undo after its reviewed direct placement was removed and recreated at saturated folder version `10000`.
- Confirmed the stale Undo could delete the replacement placement and its newly authored reason.
- Returned the committed vault revision from `addSourceToFolder` and carried it in the side panel’s short-lived Undo state.
- Required the exact persisted vault revision for folder-add Undo only when the folder version is `10000`.
- Refused add-Undo when the current direct placement has gained a reason or no longer has one exact matching placement.
- Preserved below-ceiling behavior: unrelated vault writes do not invalidate an unchanged placement when its folder version remains authoritative.
- Expanded the shared folder-Undo corpus from 22 to 28 cases per Chromium-source and generated-Firefox variant.
- Kept CLI product bytes, browser permissions, the 18-case runtime catalog size, and all remote/scheduling/account boundaries unchanged.
- Kept target-host browser, unfamiliar-person, privacy-comprehension, and real assistive-technology gates open.
