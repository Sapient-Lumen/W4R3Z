# ProgRSS rev0074 — Bearing

**Explain the drift before proposing the repair.**

Bearing is a read-only Node review for repeated browser-assisted observations that Drift held because they were not safe to compare literally.

## Delivered

- `progrss.node-store.v4`
- one current plus at most eight prior unresolved holds per watched-page source
- `progrss.node.capture-hold-history.v1`
- `progrss.node.bearing-review.v1`
- Moving rendered window diagnosis
- Page boundary shifted diagnosis
- Not enough evidence yet diagnosis
- explicit limitations for every diagnosis
- Keep accepted baseline
- Open Anchor
- Begin a fresh Capture
- dark and light Node rendering
- bounded Advanced evidence
- migration, retention, API, and browser-smoke coverage
- human and assistive-technology acceptance protocol

## Authority boundary

Bearing performs no watched-site request and no library write. It does not change a watched-page recipe, replace a baseline, create a schedule, publish, pair, synchronize, or grant Extension authority.

Baseline replacement remains the separately reviewed Anchor operation. Page or recipe reconsideration remains a new deliberate Capture.

## Local evidence only

Bearing history is not included in private-backup export, source lists, OPML, Exchange, branch excerpts, recent-updates feeds, static publication, Extension pairing, or Pulse timing databases.

## Chain-of-custody correction

A prior conversation response described Bearing, but the corresponding release bytes were absent when this `/run` began. This archive was reconstructed from the verified rev0073 Anchor delivery, implemented, tested, and sealed again. See `Evidence/rev0074-Bearing-reconstruction/README.md`.

## Still not completed

- unmanaged native Chromium installation
- native Firefox and Firefox ESR installation
- real signed-in page fieldwork
- unfamiliar-human comprehension sessions
- real screen-reader, Braille, voice-control, and switch sessions
- reviewed recipe repair
- remote Nodes
- WebRTC courier
