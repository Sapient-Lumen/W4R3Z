# rev0100 — Node branch Source Note disclosure

- Reproduced that the Node branch-adoption API returned placement reasons while the shipped review UI
  omitted them before commit.
- Added optional reason counts to branch choices and the exact preview.
- Added direct route-bound reason rendering, curator attribution, non-safety wording, literal text,
  preserved line breaks, wrapping, and automatic text direction.
- Added shipped-UI regression coverage and updated Node operation documentation and matrices.
- Added no permission, store, network authority, pairing right, schedule, notification, or remote mode.
- Kept target-browser, participant, privacy, assistive-technology, and conformance gates open.
