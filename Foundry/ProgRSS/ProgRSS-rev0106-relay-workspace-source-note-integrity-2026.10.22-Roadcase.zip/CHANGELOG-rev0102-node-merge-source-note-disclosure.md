# Changelog — rev0102-node-merge-source-note-disclosure

- Added full canonical folder routes to placement-scoped Source Note merge rows.
- Added a dedicated shipped Node Source Note comparison with literal multiline/bidirectional rendering.
- Labeled the three values as Last accepted curator reason, Keep mine, and Use curator’s.
- Added curator attribution and the explicit non-safety boundary.
- Added a focused native/API plus shipped-UI harness covering two identically named folder routes.
- Kept the Node review read-only and retained the fixed 18-case catalog.
