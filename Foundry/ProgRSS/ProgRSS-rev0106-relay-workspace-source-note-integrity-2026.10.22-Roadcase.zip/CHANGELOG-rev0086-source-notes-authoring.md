# Changelog — rev0086 Source Notes placement authoring

## Shipped controls

- Added `CLI/progrss workspace source-note` with mutually exclusive `--reason` and `--clear` actions.
- Added a placement-scoped Add/Edit Reason editor to the Extension source-card folder organizer.
- Added background `set-source-placement-reason` and `undo-source-placement-reason` handlers.
- Added local-only consequence wording before save.
- Added visible guarded undo and stale-save/stale-undo refusal.
- Added CLI documentation for the relationship-level field and new-file-only boundary.

## Contract preservation

- Reused the existing native Source Notes normalizers and 280-code-point rule.
- Preserved empty-value omission and direct-placement ownership.
- Preserved two-folder independence for one source.
- Reused existing vault persistence, native artifact integrity, disclosure, branch, import, update, and OPML omission paths.
- Added no parallel serializer, remote state, account, schedule, notification, pairing authority, or network request.

## Managed regression evidence

- Added CLI tests for add/edit/clear, two-folder independence, 281 refusal, inherited-placement refusal, unchanged refusal, and no overwrite.
- Added background tests for add, clear, stale save, guarded undo, stale undo, and independent placements.
- Added browser tests for visible placement controls, Unicode counting, cancel, clear, undo, interruption-preserved draft/focus, stale refusal, local-only wording, 44px controls, and 320px enlarged-text reflow.
- Added static checks for meaningful names, Escape, forced colors, reduced motion, permission neutrality, and generated-Firefox parity.
- Replayed all 11 CLI modules and the complete Extension runner.

## Deliberate non-expansion and non-claims

- No Node authoring endpoint was added because the Node lacks a corresponding local folder-edit surface.
- No browser permission projection changed.
- No rev0081/rev0082 recovery claim.
- No unmanaged Chromium, Firefox Release, or Firefox ESR runtime claim.
- No accessibility-conformance, assistive-technology, or unfamiliar-participant claim.
