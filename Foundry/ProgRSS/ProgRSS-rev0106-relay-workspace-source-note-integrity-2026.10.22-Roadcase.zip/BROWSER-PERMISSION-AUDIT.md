# Browser permission audit — rev0087

Baseline: `ProgRSS-rev0080-2026.10.20-Roadcase(1).zip` (`181308cabfae43330016a272a64fbdb33038f841d605f4756ec65bedb43b8106`)

Compared fields: `manifest_version`, `version`, required permissions, optional permissions, host permissions, and optional host permissions.

- `Extension/Firefox/manifest.json`: **UNCHANGED**
- `Extension/manifest.json`: **UNCHANGED**
- `Extension/platform/firefox-manifest.json`: **UNCHANGED**

Platform-specific sidebar/background/Gecko keys are reviewed separately; they are not collapsed into a false byte-identical-manifest claim.
