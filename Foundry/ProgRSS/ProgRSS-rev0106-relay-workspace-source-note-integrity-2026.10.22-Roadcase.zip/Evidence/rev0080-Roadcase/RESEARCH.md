# Roadcase research boundary

Reviewed official sources on 2026-10-20:

- Chrome for Developers, “Hello World extension”: `https://developer.chrome.com/docs/extensions/get-started/tutorial/hello-world` — browser-owned Load unpacked flow through `chrome://extensions` and Developer mode.
- Chrome for Developers, “Distribute your extension”: `https://developer.chrome.com/docs/extensions/how-to/distribute` — unpacked extensions are for trusted development/testing code.
- Mozilla Extension Workshop, “Temporary installation in Firefox”: `https://extensionworkshop.com/documentation/develop/temporary-installation-in-firefox/` — temporary installation remains until removal or restart.
- W3C WAI, “Involving Users in Evaluating Web Accessibility”: `https://www.w3.org/WAI/test-evaluate/involving-users/` — real users with disabilities provide evaluation evidence that automated checks cannot replace.
- W3C WAI, “Using Combined Expertise to Evaluate Web Accessibility”: `https://www.w3.org/WAI/test-evaluate/combined-expertise/` — include diverse disabilities, assistive technologies, and experience.

Design conclusions:

- use browser-owned temporary installation rather than an installer or policy bypass;
- verify exact trusted bytes before installation;
- use a fresh profile and synthetic fixtures first;
- keep native browser and human evidence explicitly separate from automated regression evidence;
- include cleanup and report-privacy steps in the packet itself.
