# Roadcase test boundary

Automated evidence can establish:

- deterministic packet construction;
- manifest and digest verification;
- tamper and unexpected-file refusal;
- executable-mode restoration;
- offline synthetic Node initialization;
- local fixture binding;
- delivered CLI and Extension parsing and tests;
- no telemetry or participant identity field in the packet boundary.

Automated evidence cannot establish:

- successful installation on unmanaged current Chromium;
- successful current Firefox or Firefox ESR use;
- browser prompt comprehension;
- unfamiliar-person understanding;
- real screen-reader, Braille, voice-control, or switch usability;
- validity of a real signed-in website scenario.
