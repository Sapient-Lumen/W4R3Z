# rev0068 Pulse validation evidence

This directory records the executable release boundary. The detached release report and SHA-256 sidecar bind the final ZIP itself; this in-archive evidence describes the behavior and tests expected from the delivered tree.

## Chain of custody

The rev0067 input archive matched its detached checksum but contained no `CLI/cadence/` package even though `CLI/progrss` imported `cadence.cli`. The exact observed defect and the claimed rev0067 metadata are retained under `../rev0067-Cadence-archive-defect/`.

rev0068 does not treat the rev0067 Cadence screenshots or prose as executable proof. Pulse reconstructs the package in the delivered tree and tests the delivered command surface.

## Screenshot boundary

The Pulse screenshots distributed beside the release use the exact delivered `CLI/cadence/web/index.html`, `app.css`, and `app.js`. Managed Chromium policy on this host blocked direct loopback navigation. The renderer therefore supplied status documents captured from the actual loopback server through a controlled same-origin `fetch()` interception. The real HTTP capability, `Host`, `Origin`, bearer-authentication, and no-CORS boundary was tested directly. The screenshots are UI evidence, not native installed-browser loopback acceptance.

## Human and native boundary

Unmanaged installed Chromium, current Firefox, Firefox ESR, unfamiliar-person comprehension, and real assistive-technology sessions remain not run. Automated DOM, keyboard, focus, zoom, forced-colors, and rendering checks are regression evidence rather than substitutes for those sessions.
