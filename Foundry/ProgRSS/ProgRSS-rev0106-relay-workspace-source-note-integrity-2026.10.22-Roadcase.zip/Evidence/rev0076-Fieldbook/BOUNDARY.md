# Fieldbook release boundary

Delivered:

- Private self-contained facilitator HTML generated from one read-only Bearing/Trace review.
- Twelve bounded comprehension tasks.
- Four observational outcomes.
- Bounded local notes.
- Explicit review and privacy acknowledgement before local report download.
- Local JSON and Markdown reports.
- Node GUI and CLI generation paths.
- Dark, light, forced-colors, reduced-motion, print, keyboard, and narrow-screen treatment.
- Tests that exclude source identity, address, selector, snapshots, capabilities, and participant identity.

Not delivered or claimed:

- Completed unfamiliar-person fieldwork.
- Completed native installed-browser fieldwork.
- Completed real assistive-technology fieldwork.
- Participant recruitment or consent management.
- Cloud study storage.
- Telemetry or analytics.
- Automatic usability scoring.
- Automatic recipe repair.
- Pinpoint point-to-region selection.
- Remote Node or WebRTC fieldwork transport.
