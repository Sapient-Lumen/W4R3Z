# rev0076 Fieldbook research boundary

Fieldbook exists because automated accessibility and rendering checks cannot establish whether unfamiliar people understand ProgRSS consequences. W3C cognitive-accessibility guidance recommends testing designs with real users, and WAI evaluation guidance distinguishes automated checks from user involvement.

Primary sources consulted on 2026-10-20:

- W3C COGA, “Usability Testing with Real Users”: https://www.w3.org/WAI/standards-guidelines/cognitive-accessibility-guidance/
- W3C WAI, “Involving Users in Evaluating Web Accessibility”: https://www.w3.org/WAI/test-evaluate/involving-users/
- WCAG 2.2, “Status Messages”: https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html
- WCAG 2.2, “Error Prevention (Legal, Financial, Data)”: https://www.w3.org/WAI/WCAG22/Understanding/error-prevention-legal-financial-data.html

Design consequences:

- Use the actual product interface rather than a questionnaire mockup.
- Record observable wrong turns and neutral prompts.
- Do not convert comprehension into an opaque score.
- Keep facilitator notes private and local by default.
- Review notes before export.
- Treat automated completion as regression evidence only.
- Let repeated wrong turns change wording or hierarchy before adding automation.
