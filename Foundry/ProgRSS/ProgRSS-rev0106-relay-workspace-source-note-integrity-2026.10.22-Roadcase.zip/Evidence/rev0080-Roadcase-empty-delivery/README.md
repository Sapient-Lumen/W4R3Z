# Earlier rev0080 empty delivery

The conversation previously linked `ProgRSS-rev0080-2026.10.20-Roadcase.zip`, but the active delivered file was an empty ZIP with no members.

```text
Bytes:     22
SHA-256:   8739c76e681f900923b900c9df0ef75cf421d39cabb54650c4b9ad19b6a76d85
unzip -t:  zipfile is empty
```

The sidecar matched those empty bytes. The failure was completeness, not checksum verification.

The corrected Roadcase release was reconstructed from the valid rev0079 Dispatch archive:

```text
SHA-256: 581d649d0318d19e89ee3caa490888cd6eb34d5e7b911dfd9f3885606f2bfaaf
```
