# rev0074 Bearing test boundary

Automated evidence covers:

- v1, v2, and v3 Node-store migration to v4;
- unchanged portable-library bytes and revision during migration;
- one current plus eight prior unresolved holds;
- pruning of older history;
- moving-window, changed-boundary, and insufficient-evidence diagnoses;
- source-identity and accepted-baseline stale refusal;
- read-only Bearing HTTP behavior;
- bearer, Host, Origin, and no-CORS boundaries;
- navigation to existing Anchor and fresh Capture;
- dark, light, forced-colors, reduced-motion, keyboard, and reflow regression paths;
- unchanged summary-only Extension pairing;
- clean extraction and deterministic packaging.

Automated evidence does not establish:

- native unmanaged Chromium installation;
- current native Firefox or Firefox ESR installation;
- real signed-in site behavior;
- unfamiliar-person comprehension;
- real screen-reader, Braille, voice-control, or switch-device acceptance;
- that the three diagnoses cover every real page structure;
- that a reviewed recipe-repair operation is yet justified.
