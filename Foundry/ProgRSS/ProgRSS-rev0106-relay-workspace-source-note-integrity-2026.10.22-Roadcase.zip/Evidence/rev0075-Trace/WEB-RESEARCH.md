# rev0075 Trace web research

Primary sources consulted on 2026-10-20:

- Playwright, Locators and Best Practices: resilient locators should prioritize user-facing attributes and explicit contracts; CSS tied to implementation detail can break.
- WHATWG HTML Standard, data-* attributes: custom page-supplied data attributes are valid global attributes.
- W3C WAI, Labels or Instructions and Forms Tutorial: controls and consequential choices need sufficient labels, instructions, review, and understandable feedback without excessive clutter.

These sources informed the bounded vocabulary and progressive disclosure. They do not define a general-purpose watched-page repair algorithm.
