# rev0075 Trace research boundary

Research was used to constrain explanation rather than justify automatic repair.

- Playwright locator guidance recommends user-facing attributes and explicit contracts for resilience, and warns that implementation-detail CSS and DOM structure can break. ProgRSS uses this only as an analogy for explaining selector dependencies; it does not claim Playwright conformance or convert extraction recipes into test locators.
- The HTML Standard defines data-* attributes as page-supplied custom data. Trace may describe a selector using data-* as an explicit structural signal, but does not claim the publisher will preserve it.
- W3C form guidance emphasizes clear labels, instructions, review, and understandable consequences. Trace therefore keeps the evidence sequence in normal reading order and exact selectors under Advanced.

No source establishes a universal selector-resilience score. Trace deliberately emits no probability or confidence percentage.
