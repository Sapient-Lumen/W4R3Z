# rev0075 Trace test boundary

Automated evidence covers:

- oldest-to-newest accepted/held ordering;
- pairwise overlap labels;
- page-boundary shift labels;
- conservative recipe-footprint classes;
- exact selector evidence remaining under Advanced;
- zero-network and zero-write response flags;
- Node HTTP and Origin/Host/capability boundaries inherited from Bearing;
- dark, light, narrow, forced-colors, and reduced-motion CSS paths;
- clean-extraction replay.

Not represented as passed:

- unmanaged installed Chromium;
- native current Firefox or Firefox ESR;
- real signed-in sites;
- unfamiliar-human comprehension;
- screen-reader, Braille, voice-control, or switch-device sessions.
