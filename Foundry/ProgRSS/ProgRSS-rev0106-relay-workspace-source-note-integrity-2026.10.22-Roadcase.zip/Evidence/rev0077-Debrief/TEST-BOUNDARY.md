# rev0077 Debrief test boundary

## Automated evidence may establish

- report schema validation
- privacy-field validation
- duplicate removal
- mixed-scenario refusal
- aggregate outcome counts
- review-signal generation
- local raw-note visibility
- raw-note export exclusion
- review and privacy gates
- local JSON and Markdown downloads
- dark and light rendering
- Node endpoint and CLI generation
- no-overwrite behavior
- deterministic packaging
- clean-extraction replay

## Automated evidence may not establish

- that an unfamiliar person understands ProgRSS
- that a facilitator used a truly neutral prompt
- that a local note contains no identifying information
- that the finding is valid user-research analysis
- that the product response is the right design change
- accessibility with a real assistive-technology setup
- native current Chromium, Firefox, or Firefox ESR behavior
- product usability or accessibility acceptance

Synthetic reports are fixture data. They are never represented as human
sessions.
