# rev0077 Debrief research boundary

Retrieved: 2026-10-20

## Why another tool after Fieldbook

Fieldbook records one observed session. The next product decision requires
cross-session analysis: grouping observations, identifying repeated patterns,
and turning those patterns into bounded findings and next actions without
turning participants into scores.

## Sources reviewed

### W3C — Involving Users in Evaluating Web Accessibility

https://www.w3.org/WAI/test-evaluate/involving-users/

Relevant principle: evaluation with people with disabilities finds usability
and accessibility problems that standards-only evaluation does not reveal.
ProgRSS therefore must not represent automated completion of Fieldbook or
Debrief as human acceptance.

### W3C COGA — Usability testing with people with cognitive and learning disabilities

https://www.w3.org/WAI/GL/task-forces/coga/wiki/Usability_Testing

Relevant principle: product teams should include the people for whom the design
is intended, use understandable tasks, and treat observed difficulty as product
evidence rather than participant failure.

### GOV.UK Service Manual — Analyse a research session

https://www.gov.uk/service-manual/user-research/analyse-a-research-session

Relevant principle: analysis moves from observations to grouped themes and
findings. Debrief keeps the observations visible, asks for a product finding,
and makes the product response a separate hypothesis.

### GOV.UK Service Manual — Taking notes during user research

https://www.gov.uk/service-manual/user-research/taking-notes-user-research

Relevant principle: notes support later analysis but require disciplined
handling. Debrief makes raw notes locally reviewable and excludes them from the
exported finding report.

### GOV.UK Service Manual — Managing user research data and participant privacy

https://www.gov.uk/service-manual/user-research/managing-user-research-data-participant-privacy

Relevant principle: collect and retain only what is needed, understand where
research data is stored, and prevent identifying details from spreading into
unnecessary artifacts.

### NIST Privacy Framework

https://www.nist.gov/privacy-framework

Relevant principle: data processing should be proportionate to the purpose.
Debrief requests no participant identity, performs no upload, persists nothing
automatically, and exports no raw facilitator notes.

## Design consequences

- Do not calculate a participant score.
- Do not declare product acceptance from aggregate counts.
- Require compatible scenarios and task sequences.
- Remove exact duplicates rather than counting the same report twice.
- Keep raw notes locally reviewable.
- Export newly written findings and actions, not raw notes.
- Require privacy review before export.
- Preserve an explicit interpretation boundary in the export.
- Keep automated tests labelled as tool verification only.
