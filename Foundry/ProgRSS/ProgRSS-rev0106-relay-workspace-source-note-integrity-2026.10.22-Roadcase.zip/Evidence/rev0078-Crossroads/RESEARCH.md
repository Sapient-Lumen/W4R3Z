# Crossroads research boundary

Sources reviewed online on 2026-10-20:

- GOV.UK Service Manual, “Using moderated usability testing.” It recommends
  clear and neutral task instructions, relevant believable goals, avoiding
  hints that give away the answer, reassuring participants that the service is
  being tested rather than them, and mostly observing and listening.
- Chrome Extensions `permissions` API documentation. It recommends optional
  runtime permissions so people can understand why authority is needed and
  grant only the necessary capabilities.
- Chrome permission-warning guidance. It recommends runtime optional
  permissions because the product can provide context around the requested
  authority.
- W3C WAI introduction. It states that tools alone cannot determine
  accessibility and knowledgeable human evaluation is required.

Crossroads applies these ideas by using goal-based Fieldbook tasks, preserving
the installed Extension as the interface under study, retaining action-scoped
browser authority, and explicitly representing automated completion as tool
verification rather than human acceptance.
