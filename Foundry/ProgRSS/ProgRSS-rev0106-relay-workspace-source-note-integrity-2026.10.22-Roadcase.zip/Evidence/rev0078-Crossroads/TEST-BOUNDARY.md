# Crossroads test boundary

Automated evidence verifies:

- strict active-handoff scenario generation;
- adaptive tasks when Follow or branch choices are absent;
- omission of curator, route, source, URL, folder, Node, exchange, and
  capability identity;
- local-only Fieldbook behavior and review-before-export;
- authenticated Node download and offline CLI generation;
- Debrief scenario isolation;
- dark and light rendering;
- local JSON report export;
- no Node-library or store write;
- no listed-site request or schedule.

Automated evidence does not verify:

- unfamiliar-recipient comprehension;
- native installed Chromium, Firefox, or Firefox ESR behavior;
- real permission prompts on an unmanaged host;
- screen-reader, Braille, voice-control, or switch usability;
- whether the current labels are optimal;
- whether a product wording change is justified.
