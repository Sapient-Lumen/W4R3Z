# Crossroads release boundary

Delivered:

- Exchange recipient Fieldbook scenario.
- Active-handoff Node download.
- Offline CLI generation from one Exchange review.
- Strict omission of curator, route, source, URL, folder, Node, exchange, and
  invitation identity.
- Fifteen adaptive goal-based tasks when all three doors are available.
- Existing Fieldbook review-before-export and local-only privacy boundary.
- Debrief scenario isolation.
- Rendered dark/light regression and local report export.

Not delivered or claimed:

- Completed unfamiliar-recipient sessions.
- Native unmanaged Chromium, Firefox, or Firefox ESR acceptance.
- Screen-reader, Braille, voice-control, or switch acceptance.
- Evidence that the current three-door labels are understood.
- Any new sharing, pairing, import, follow, scheduling, acquisition, or write
  authority.
