# Anchor test and acceptance boundary

## Automated evidence

The release exercises:

- held-Capture persistence and supersession;
- v2-to-v3 Node-store migration without portable-library rewrite;
- offline preview;
- stale library, changed recipe, changed baseline, missing hold, and expired-preview refusal;
- atomic failure injection after snapshot, library, and receipt stages;
- exact idempotent replay;
- same-key/different-content refusal;
- no retained page-change item;
- zero watched-site requests;
- no schedule creation;
- durable before-snapshot export;
- local Node GUI review and receipt;
- Extension explanation that nothing was replaced during Capture;
- Chromium and generated Firefox runtime parity.

## Not established by automated evidence

The release does not claim:

- installed unpacked Chromium acceptance on an unmanaged host;
- native current Firefox or Firefox ESR acceptance;
- signed-in real-site Capture acceptance;
- unfamiliar-human comprehension;
- real screen-reader, Braille, voice-control, switch, fatigue, or interruption acceptance;
- production remote-Node safety;
- one-click rollback semantics;
- automatic synchronization.

## Aggregate-wrapper qualification

Some older test wrappers can retain descendant output handles after their assertions finish. Release evidence therefore uses the constituent Relay/publication and command-line cases in individually bounded processes rather than treating a lingering wrapper as product execution evidence.
