# Anchor research notes

Research date: 2026-10-20

## Explicit review before a consequential change

W3C cognitive-accessibility guidance recommends allowing people to review and confirm information before final submission and explaining the effects and risks of choices. Anchor applies that pattern by showing Accepted now, Held proposal, and the three consequences before enabling the replacement action.

Primary source:
- W3C, Making Content Usable for People with Cognitive and Learning Disabilities, objective on preventing mistakes and review/confirmation.

## Stale-base protection

HTTP `If-Match` is intended for state-changing requests where the current selected representation must still match, including prevention of accidental overwrite/lost-update behavior. Anchor requires a strong quoted digest of the exact reviewed Node library.

Primary source:
- RFC 9110, HTTP Semantics, conditional requests and `If-Match`.

## Atomic local evidence

SQLite documents atomic transactions as committing all changes or none. Anchor stores the before snapshot, replacement library, receipt, replay fingerprint, and hold removal in one transaction. The store uses WAL mode and `synchronous=FULL`; SQLite documents the additional WAL synchronization at commit for that setting.

Primary sources:
- SQLite, Atomic Commit In SQLite.
- SQLite, Write-Ahead Logging.
- SQLite, PRAGMA synchronous.

## Scope conclusion

These sources support the review, stale-base, and transactional design. They do not prove that the wording is understandable to unfamiliar people, nor do they establish native-browser behavior. Those remain explicit fieldwork boundaries.
