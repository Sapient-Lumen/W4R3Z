# Drift research evidence

Primary standards material reviewed for rev0072:

- WAI-ARIA set metadata for incomplete DOM sets (`aria-posinset`, `aria-setsize`).
- WAI feed pattern for infinite/dynamically loaded article sequences.
- WAI infinite-feed example using set position, set size, and busy state.

Design conclusion:

A DOM snapshot can be a viewport into a larger logical set. Missing DOM records therefore cannot automatically be treated as publication removals. ProgRSS uses this only as a reason to compare conservatively; it does not trust ARIA metadata as ground truth.
