# Drift test boundary

Automated evidence covers:

- direct continuity computation
- Node HTTP receipt and replay
- baseline and accepted-provenance preservation
- no mass item creation
- zero Node watched-site requests
- twelve retained browser fixture classes
- dark and light rendered review
- durable held-window result

Not yet executed:

- unmanaged installed Chromium
- native Firefox current and ESR
- signed-in real sites
- unfamiliar-human comprehension
- real screen reader, Braille, voice-control, and switch sessions
