# rev0070 Perimeter research notes

Research date: 2026-10-20

Primary sources reviewed while designing this boundary:

- Chrome Extensions `scripting` API documentation: runtime injection requires the
  scripting permission plus page authority; injection defaults to the main frame,
  can target explicit frame IDs, and supports an isolated execution world.
- W3C Selectors Level 4: selectors operate on document-tree structure and dynamic
  element state; a match is not a durability promise about a publisher's future
  markup.
- MDN Shadow DOM documentation: open shadow roots are available through
  `shadowRoot`; closed roots return null to ordinary page access. Perimeter treats
  closed shadow content as outside its explicit contract.
- W3C WCAG 2.2 Understanding 2.5.7: functionality implemented with dragging needs
  a non-drag single-pointer alternative. Any future point-to-region UI must not be
  drag-only.

The release does not treat these documents as proof that its interface is usable.
Native and unfamiliar-human acceptance remains separate work.
