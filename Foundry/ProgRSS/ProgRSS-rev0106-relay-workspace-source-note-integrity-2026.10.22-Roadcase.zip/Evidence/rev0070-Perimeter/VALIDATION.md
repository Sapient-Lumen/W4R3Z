# rev0070 Perimeter validation record

Working-tree verification completed on 2026-10-20.

## Python

```text
13/13  acquisition and Capture boundary tests
17/17  Node HTTP, pairing, Exchange, merge, operation, Witness, Capture tests
46/46  direct CLI library tests
29/29  publication, integrity, continuity, and merge tests
 9/9   Node-store transaction, migration, interruption, and replay tests
 9/9   Pulse/Cadence timing and dispatch tests
26/26  command-line cases in individually bounded process groups
149     distinct Python test cases
```

## Extension and browser harnesses

```text
58/58  structural and static checks
PASS   Chromium background harness
PASS   shared-folder / Branch / Contents / Signpost / Edition core harness
PASS   generated Firefox background harness
PASS   acquisition and redirect harness
PASS   vault conflict and failed-write harness
PASS   real-browser Perimeter fixture garden: 7 specimens, all six page-boundary kinds
PASS   rendered everyday reader through Capture review, page context, section choice, commit, and receipt
PASS   rendered Advanced Workbench
```

## Delivered-file parsing

```text
26 Python files compiled
64 JavaScript files parsed
52 JSON files parsed
 2 POSIX shell files parsed
```

## Native and human boundary

Not run in this environment:

```text
installed unmanaged Chromium Extension
installed current Firefox
installed Firefox ESR
signed-in real-site Capture
unfamiliar-human comprehension sessions
real screen-reader, Braille, voice-control, or switch sessions
```

Managed Chromium policy blocks unpacked installation and direct loopback browser
navigation on this host. Real loopback HTTP security boundaries and rendered UI
regression paths are separate evidence; they are not native installed-browser
acceptance.

The final release process must add deterministic archive, clean-extraction byte
and mode comparison, and principal-suite replay evidence before sealing.
