# Dispatch research notes

Reviewed 2026-10-20.

## Sender understanding before sharing

W3C cognitive-accessibility guidance warns against designs in which people
share information without understanding the risks and recommends clear,
easy-to-understand consent, warnings, and consequences.

Source: https://www.w3.org/TR/coga-usable/

The UK Office for National Statistics' invitation research found that people
need to understand what they are being asked to do, what will happen, how long
it will take, confidentiality, and what happens next. Its content iterations
also removed nonessential wording without removing information people needed
to make the decision.

Source: https://analysisfunction.civilservice.gov.uk/policy-store/invitations-to-take-part-in-research/

## Interface consequences

WCAG requires focus order that preserves meaning and operability, descriptive
headings and labels, and predictable changes of context. Dispatch therefore
keeps the Fieldbook secondary to the real share review, makes consequences
explicit, and does not turn selection or focus into publication or delivery.

Source: https://www.w3.org/TR/WCAG21/

## Applied design decisions

- Study the existing share review rather than replacing it with a survey.
- Ask about consequences, not protocol vocabulary.
- Keep sender and recipient scenarios separate.
- Exclude route, curator, source, public-address, library, digest, and
  capability identity from the facilitator sheet.
- Treat automated completion as tool verification, not human acceptance.
- Require privacy review before exporting local observations.
