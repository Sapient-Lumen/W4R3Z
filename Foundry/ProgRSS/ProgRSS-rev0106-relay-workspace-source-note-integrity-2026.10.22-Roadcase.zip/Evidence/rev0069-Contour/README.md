# rev0069 Contour validation evidence

This directory describes the executable Contour boundary delivered in this tree. The detached release report and SHA-256 sidecar bind the final ZIP bytes after sealing.

## Implemented boundary

Contour adds bounded human explanations for browser-rendered page-section candidates. It preserves the Capture authority model: one exact active top-frame page, packaged isolated-world code, text-and-link evidence only, zero Node-side watched-site requests, no browser-login transfer, and no schedule creation.

The canonical extractor is `Extension/shared/capture.js`; the Firefox copy is generated from it. New artifacts use `progrss.browser-capture.v2`, while the Node retains strict rolling-upgrade support for legacy v1 without inventing missing assessment evidence.

## Screenshot boundary

The distributed Contour screenshots use the exact shipped side-panel HTML, CSS, JavaScript, and shared extractor with controlled local Node responses. They demonstrate rendered interface behavior, not unmanaged installed-Extension acceptance.

## Chain of custody

`../rev0068-Pulse-bootstrap-gap/` records that rev0068's executable Pulse implementation was delivered, but its distributed `BOOTSTRAPROSE.md` remained headed rev0067 Capture. rev0069 makes the Contour bootstrap the current authority and records the discrepancy rather than rewriting historical archive bytes.

## Native and human boundary

Unmanaged installed Chromium, current Firefox, Firefox ESR, signed-in real-site fieldwork, unfamiliar-person comprehension, and real assistive-technology sessions remain not run. Automated DOM, keyboard, focus, zoom, forced-colors, and rendering checks are regression evidence rather than substitutes for those sessions.
