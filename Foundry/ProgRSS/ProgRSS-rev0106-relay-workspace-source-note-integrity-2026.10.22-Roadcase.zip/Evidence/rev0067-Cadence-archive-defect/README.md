# Delivered rev0067 Cadence archive defect

The sealed archive used as the input to rev0068 had SHA-256:

```text
054488dc94a90f476a7bd24a5f1a3a7e5de3eb344667b5fdd9b7b52a411c0a3c
```

Its launcher contained a `cadence` route importing:

```python
from cadence.cli import main
```

but the archive contained no `CLI/cadence/` package and therefore could not execute `./progrss cadence --help` or any claimed Cadence command.

The claimed release metadata is retained beside this report for chain-of-custody evidence. It is not treated as executable validation.

rev0068 Pulse reconstructs the timing layer as delivered source, adds unit and loopback tests, connects it directly to packaged Witness acquisition, and verifies the final sealed ZIP from a clean extraction.
