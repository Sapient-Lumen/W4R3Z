# ProgRSS rev0067 — Cadence

**Release maxim:** Schedule explicitly. Pause means zero requests.

Cadence adds a Node-local scheduling contract and loopback control surface for sources that the Node has already proved it can reproduce through the public Witness acquisition path. It does not schedule browser-assisted or browser-only captures, does not create schedules during import or sharing, and does not include an ambient background daemon.

## Delivered

- `progrss cadence init|review|create|list|pause|resume|run-due|start|serve`
- Node-local SQLite timing plans, separate from portable `progrss.private.v1` libraries
- Eligibility evidence bound to a successful public Witness receipt
- Explicit timing review and acknowledgement
- 15-minute minimum and 30-day maximum intervals
- Bounded deterministic jitter
- Durable due slots and replay-safe dispatch identifiers
- Foreground, single-lease scheduler session
- Temporary-failure backoff and bounded numeric `Retry-After` support
- Per-origin spacing inside a dispatch pass
- Dark fluorescent loopback GUI with exact Host/Origin checks and bearer capability
- Pause and resume controls that do not mutate the portable library

## Deliberate boundaries

- The scheduler starts stopped.
- Creating a plan performs no DNS or HTTP request.
- Active and scheduled are separate states.
- Paused plans produce no due work.
- Browser-assisted and browser-only sources are not schedulable.
- No plan is created by import, pairing, Exchange, Witness, or Capture.
- The release dispatches through an explicitly configured argv-only Witness-compatible runner; it does not yet wire a second downloader or a permanent operating-system service.
- `Retry-After` HTTP-date parsing, persistent cross-process host budgets, suspend/resume testing, and metered-network policy remain future work.

## Human acceptance questions

1. Can a person explain the difference between active and scheduled?
2. Do they understand that creating a plan made no request?
3. Can they predict the next eligible check time?
4. Do they understand that closing the foreground scheduler stops automatic checks?
5. Can they pause a plan and correctly state that pause means zero requests?
6. Can they identify why a browser-assisted page cannot be scheduled?
7. Can they distinguish a successful unchanged check from a failed attempt?
8. Can they find the durable acquisition receipt for a scheduled attempt?
