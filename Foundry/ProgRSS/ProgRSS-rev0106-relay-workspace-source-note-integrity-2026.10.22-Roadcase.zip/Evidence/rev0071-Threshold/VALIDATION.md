# rev0071 Threshold validation

## Automated working-tree evidence

```text
15/15  acquisition and Capture validation tests
 9/9   Pulse/Cadence timing and dispatch tests
 9/9   Node-store transaction, migration, interruption, and replay tests
17/17  Node HTTP, pairing, Exchange, merge, operation, Witness, and Capture tests
46/46  direct CLI library tests
29/29  Relay, publication, integrity, continuity, and merge tests
26/26  command-line cases in individually bounded processes
151     distinct Python cases

58/58  Extension structural and static checks
PASS   Chromium background harness
PASS   generated Firefox background harness
PASS   Branch / Contents / Signpost / Edition shared-folder core
PASS   acquisition and redirect harness
PASS   vault conflict and failed-write harness
PASS   seven-case Perimeter real-browser fixture garden
PASS   rendered everyday reader through Threshold decision and receipt
PASS   rendered Advanced Workbench
PASS   rendered Node UI

26      Python files compiled
62      JavaScript files parsed
55      JSON files parsed
 2      POSIX shell files parsed
```

The aggregate Relay and command-line wrappers are not used as the sole release
proof because older launcher descendants can retain output handles. Their 29 and
26 constituent cases were executed individually under explicit bounds and all
completed normally.

## Delivered-byte evidence

The final release must also pass:

```text
deterministic two-build comparison
ZIP CRC verification
unique-member verification
safe relative-path verification
symlink refusal
nested-archive absence
runtime-database absence
cache and bytecode absence
source/extraction byte comparison
source/extraction executable-mode comparison
principal-suite replay from the clean extraction
```

## Native and human boundary

The following remain not run and are not implied by automated evidence:

```text
unmanaged installed Chromium
current native Firefox
native Firefox ESR
signed-in real-site Capture
unfamiliar-human Threshold sessions
real screen-reader, Braille, voice-control, and switch sessions
```
