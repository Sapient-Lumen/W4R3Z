# rev0071 Threshold web research

Research was performed before setting the release boundary.

## W3C cognitive and accessible decision guidance

The W3C Cognitive and Learning Disabilities Accessibility Task Force recommends
showing a summary before an important submission and keeping the final action
and cancellation understandable. W3C supplemental guidance also recommends
stating the benefits, risks, and consequences of an option clearly.

Threshold applies that guidance narrowly: a rendered view with visible coverage
limits cannot be committed as a baseline until the person sees the consequence
and makes a separate decision. Recapture remains a visible alternative.

Primary sources consulted:

- W3C, *Making Content Usable for People with Cognitive and Learning
  Disabilities*.
- W3C supplemental guidance, *Clearly State Results and Disadvantages of
  Actions, Options, and Selections*.
- W3C technique G98, review and confirmation before final commitment.

## Scope conclusion

The research supported an explicit coverage decision. It did not support:

- hidden automatic completion of pagination or virtualized content;
- a preselected consent checkbox;
- combining recipe replacement and incomplete-view acceptance into one decision;
- representing a heuristic page-boundary notice as certainty;
- adding a visual picker before observing real proposal failures.
