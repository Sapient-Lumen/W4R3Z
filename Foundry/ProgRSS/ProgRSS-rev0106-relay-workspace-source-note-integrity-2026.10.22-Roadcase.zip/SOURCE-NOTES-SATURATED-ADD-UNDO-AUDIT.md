# Source Notes saturated folder-add Undo audit — rev0094

- Parent accepted stale add Undo and deleted a replacement reason: **YES**
- Chromium-source focused corpus: **PASS** (28 cases)
- Generated-Firefox focused corpus: **PASS** (28 cases)
- Exact-revision ceiling guard and single-placement removal checks: **PASS**

The parent reproduction and candidate checks use production background handlers with browser API doubles. They are not installed-browser, participant, accessibility, or assistive-technology acceptance.

At folder version `10000`, add Undo now requires the exact committed vault revision. Below the ceiling, an unrelated vault write remains nonblocking when the folder version still identifies the unchanged placement.
