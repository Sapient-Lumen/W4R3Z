# Node private-library Source Note integrity audit — rev0105

The sealed rev0104 parent accepted a private backup containing a 281-code-point direct-placement reason through both Node ingress paths. `progrss node init` persisted it in the transactional SQLite library, the store reopened it, `node export` reproduced it, and the read-only Node backup loader accepted it.

rev0105 adds one shared Python audit in `CLI/source_notes_native.py` and delegates the offline CLI, transactional Node store, and read-only Node loader to it. Valid reasons for one source in two folders remain byte-exact, while nine malformed forms refuse before storage or serving:

- over 280 Unicode code points;
- reason on a folder object;
- reason on a nested folder member;
- reason-bearing duplicate placement;
- empty value;
- leading or trailing ASCII whitespace;
- non-string value;
- invalid Unicode scalar value;
- missing source identity.

The Node store applies the audit when importing, verifying, reading, snapshotting, committing acquisition or operation results, replacing a held baseline, and exporting. A digest-consistent malformed SQLite library is refused on reopen. No output SQLite file is created after malformed `node init` input.

The correction adds no network authority, persistent store, browser permission, account, schedule, notification, ranking, profile, reaction, comment, or messaging capability. Exact target-host browser and human/assistive-technology acceptance remain open.
