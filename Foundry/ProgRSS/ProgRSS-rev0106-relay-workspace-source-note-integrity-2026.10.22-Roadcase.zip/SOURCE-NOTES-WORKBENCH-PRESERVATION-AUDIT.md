# Source Notes Workbench preservation audit

Revision: `rev0096-source-notes-workbench-preservation`

## Reproduced parent failure

A title-only save through the shipped Advanced Workbench rebuilt direct source members as `{kind,id}` and erased every Source Note in the edited collection. An independent folder was not changed.

## Candidate result

- Chromium-source Workbench: **11/11** focused cases passed.
- Generated-Firefox Workbench: **11/11** focused cases passed.
- Shared Workbench product bytes are identical.
- Existing selected placements preserve canonical reasons by source identity.
- A deliberate uncheck removes only that placement and its reason.
- A newly selected source receives no invented reason.
- Conflicting duplicate, wrong-level, or invalid prior reason data refuses the save without mutation.
- The harness observed no network requests.

## Scope

This is managed shipped-UI-path regression evidence with a deterministic persistence backend. It is not installed-browser, target-host, participant, privacy-comprehension, assistive-technology, or accessibility-conformance evidence.
