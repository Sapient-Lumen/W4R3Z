# Source Notes runtime matrix — rev0106

| Row | Scope | Status |
|---|---|---:|
| `sealed-rev0105-parent` | sealed rev0105 unified whole-product tree retained | **PASS** |
| `relay-workspace-source-note-integrity` | shared placement audit on all six Relay workspace commands and before derived workspace output; five focused tests and nine malformed forms | **FOCUSED-PASS** |
| `runtime-catalog-binding` | 18 cases; session v5/result v3; fresh rev0106 preparation required | **PASS** |
| `complete-offline-regression` | 209 CLI tests across 17 modules, 61 Extension static tests, 22 managed Node/product harness invocations, inherited managed UI variants, complete Extension runner, and 51 evidence tests | **PASS** |
| `deterministic-seal` |  | **EXTERNAL-POSTBUILD-REPORT-REQUIRED** |
| `unmanaged-current-chromium` |  | **NOT-RUN** |
| `firefox-release` |  | **NOT-RUN** |
| `firefox-esr` |  | **NOT-RUN** |
| `unfamiliar-curators-and-recipients` |  | **NOT-RUN** |
| `separate-sender-recipient-diagnostic-privacy` |  | **NOT-RUN** |
| `real-assistive-technologies` |  | **NOT-RUN** |
