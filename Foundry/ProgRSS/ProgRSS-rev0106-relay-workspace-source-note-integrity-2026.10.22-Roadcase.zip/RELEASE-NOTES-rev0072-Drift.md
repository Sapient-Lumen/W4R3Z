# ProgRSS rev0072 — Drift

**A moving window is not a changed world.**

Drift prevents a later browser-assisted partial rendering from becoming a false mass add/remove alert merely because the page replaced one virtualized DOM window with another.

## Delivered

- New Node-computed `progrss.capture-continuity.v1` evidence.
- Stable-key overlap for repeated cards and bounded token overlap for readable regions.
- A conservative hold when the partial-render boundary changes or overlap falls below 35 percent.
- New `coverage-shift` / **Rendered window held** outcome.
- Accepted baseline and accepted browser-capture provenance remain unchanged on hold.
- Zero generated page-watch items, zero Node watched-site requests, and no schedule.
- Durable receipt fields for action, reason, overlap, and baseline preservation.
- Exact completed replay without a second write or request.
- Human-first Extension explanation before submission and after the result.
- Fixture garden expanded from 7 to 12 real-browser cases.

## Deliberate limit

Rev0072 does not silently replace a permanently obsolete partial baseline. A future typed operation must review and receipt that replacement while preserving the old snapshot as evidence.

## Authority unchanged

Capture remains exact-page, top-frame-only, packaged isolated-world extraction of bounded text and links. It transfers no login state, raw HTML, screenshot, or general browser authority. Pairing remains summary-only and Pulse still refuses browser-assisted scheduling evidence.
