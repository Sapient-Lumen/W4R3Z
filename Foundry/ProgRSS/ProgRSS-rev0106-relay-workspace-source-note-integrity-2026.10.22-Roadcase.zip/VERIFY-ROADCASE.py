#!/usr/bin/env python3
"""Verify a cleanly extracted ProgRSS Roadcase or the ZIP itself."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import zipfile

MANIFEST_NAME = "ROADCASE-MANIFEST.json"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_name(name: str) -> str:
    path = PurePosixPath(name)
    if not name or path.is_absolute() or ".." in path.parts or "" in path.parts:
        raise ValueError(f"unsafe archive path: {name!r}")
    normalized = path.as_posix()
    if normalized != name.rstrip("/"):
        raise ValueError(f"non-canonical archive path: {name!r}")
    return normalized


def load_manifest_bytes(data: bytes) -> dict:
    parsed = json.loads(data.decode("utf-8"))
    if parsed.get("format") != "ProgRSS Roadcase Manifest v1":
        raise ValueError("unsupported Roadcase manifest format")
    files = parsed.get("files")
    if not isinstance(files, list):
        raise ValueError("manifest files must be an array")
    paths = [item.get("path") for item in files]
    if paths != sorted(paths) or len(paths) != len(set(paths)):
        raise ValueError("manifest paths must be unique and sorted")
    for name in paths:
        safe_name(name)
    return parsed


def expected_mode(item: dict) -> int:
    value = item.get("mode")
    if not isinstance(value, str) or not value.startswith("0o"):
        raise ValueError(f"invalid mode for {item.get('path')!r}")
    return int(value, 8)


def verify_tree(root: Path) -> None:
    manifest_path = root / MANIFEST_NAME
    manifest = load_manifest_bytes(manifest_path.read_bytes())
    expected = {item["path"]: item for item in manifest["files"]}
    actual: set[str] = set()
    for path in root.rglob("*"):
        rel = path.relative_to(root).as_posix()
        if path.is_dir() and not path.is_symlink():
            continue
        actual.add(rel)
    wanted = set(expected) | {MANIFEST_NAME}
    missing = sorted(wanted - actual)
    extra = sorted(actual - wanted)
    if missing or extra:
        raise ValueError(f"tree membership mismatch; missing={missing!r}, extra={extra!r}")

    for name, item in expected.items():
        path = root / name
        kind = item.get("kind")
        st = path.lstat()
        mode = stat.S_IMODE(st.st_mode)
        if mode != expected_mode(item):
            raise ValueError(f"mode mismatch for {name}: {oct(mode)}")
        if kind == "file":
            if not stat.S_ISREG(st.st_mode):
                raise ValueError(f"expected regular file: {name}")
            data = path.read_bytes()
        elif kind == "symlink":
            if not stat.S_ISLNK(st.st_mode):
                raise ValueError(f"expected symlink: {name}")
            data = os.readlink(path).encode("utf-8")
        else:
            raise ValueError(f"unknown entry kind for {name}: {kind!r}")
        if len(data) != item.get("bytes") or digest(data) != item.get("sha256"):
            raise ValueError(f"byte digest mismatch for {name}")


def zip_mode(info: zipfile.ZipInfo) -> int:
    return stat.S_IMODE((info.external_attr >> 16) & 0xFFFF)


def zip_kind(info: zipfile.ZipInfo) -> str:
    raw = (info.external_attr >> 16) & 0xFFFF
    return "symlink" if stat.S_ISLNK(raw) else "file"


def verify_archive(archive: Path) -> None:
    with zipfile.ZipFile(archive) as zf:
        infos = zf.infolist()
        names = [info.filename for info in infos]
        if names != sorted(names) or len(names) != len(set(names)):
            raise ValueError("ZIP entries must be unique and sorted")
        for info in infos:
            safe_name(info.filename)
        if MANIFEST_NAME not in names:
            raise ValueError("Roadcase manifest is missing")
        manifest = load_manifest_bytes(zf.read(MANIFEST_NAME))
        expected = {item["path"]: item for item in manifest["files"]}
        files = {info.filename: info for info in infos if not info.is_dir()}
        wanted = set(expected) | {MANIFEST_NAME}
        if set(files) != wanted:
            raise ValueError(
                f"archive membership mismatch; missing={sorted(wanted-set(files))!r}, "
                f"extra={sorted(set(files)-wanted)!r}"
            )
        for name, item in expected.items():
            info = files[name]
            data = zf.read(info)
            if zip_kind(info) != item.get("kind"):
                raise ValueError(f"kind mismatch for {name}")
            if zip_mode(info) != expected_mode(item):
                raise ValueError(f"mode mismatch for {name}")
            if len(data) != item.get("bytes") or digest(data) != item.get("sha256"):
                raise ValueError(f"byte digest mismatch for {name}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--archive", type=Path, help="verify a Roadcase ZIP instead of this extracted tree")
    args = parser.parse_args()
    try:
        if args.archive is not None:
            verify_archive(args.archive.resolve())
            print(f"verified Roadcase archive: {args.archive}")
        else:
            root = Path(__file__).resolve().parent
            verify_tree(root)
            print(f"verified extracted Roadcase: {root}")
    except Exception as exc:
        print(f"Roadcase verification failed: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
