# Changelog — rev0085 Source Notes entry-point matrix

## Native continuity

- Preserved `reason` through shipped Python and browser collection cleaning, translation, import, branch, and disclosure paths.
- Enforced direct-placement ownership, empty omission, Unicode scalar validity, 280-code-point limit, and duplicate-placement rules.
- Added placement-scoped three-way Source Note merge review and exact conflict decisions.
- Added Source Note counts, folder paths, and placement disclosures to native contents reports.
- Added exact OPML omission evidence while keeping reason values out of OPML.
- Added Node branch preview/commit and merge-review coverage.
- Added Extension background export/import/update/undo coverage.
- Added managed side-panel rendering coverage for reason attribution and safety-claim boundaries.
- Added Chromium-source/generated-Firefox fixture parity and digest-tamper refusal.

## Evidence and packaging

- Added `SOURCE-NOTES-ENTRYPOINT-MATRIX.*`.
- Added `BROWSER-PERMISSION-AUDIT.*` and a frozen rev0080 permission baseline.
- Added a clean-extraction focused verifier.
- Restored executable launcher/tool modes carried by the supplied baseline.
- Reprioritized `BOOTSTRAPROSE.md` around the missing shipped authoring control, then actual browser runtime and fieldwork.

## Deliberate non-claims

- No rev0081/rev0082 recovery claim.
- No unmanaged Chromium, Firefox Release, or Firefox ESR runtime claim.
- No accessibility-conformance or unfamiliar-participant claim.
- No new permission, account, schedule, notification, remote Node, or WebRTC dependency.
