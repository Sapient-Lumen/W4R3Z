# ProgRSS rev0069 — Contour

**Version:** 0.69.0
**Date:** 2026-10-20
**Release maxim:** **A selector says where. Evidence says why it may hold.**

Contour improves the mission-critical path for following sites that do not provide a usable feed. Browser-assisted Capture already let a person open one exact rendered page, choose a bounded section, and send text-and-link evidence to a local ProgRSS Node without transferring browser login authority. Contour makes that section choice explainable.

## Chain-of-custody correction

The rev0068 archive contains the executable Pulse implementation and its validation evidence, but its distributed `BOOTSTRAPROSE.md` still begins at rev0067 Capture. Contour records that documentation defect under `Evidence/rev0068-Pulse-bootstrap-gap/` and makes the rev0069 bootstrap the explicit current authority. Historical archive bytes are preserved rather than rewritten.

## Human change

For each available rendered section, the ordinary reader now shows one bounded label:

```text
More likely to stay put
Needs watching
Fragile
```

The selected section then exposes:

```text
Matched now
Ignored example
Why this may hold
What could break
```

The interface states that this is evidence from the page as rendered now, not a promise that the site will preserve its structure.

## Evidence, not certainty

Contour considers bounded signals such as:

- semantic `main`, `article`, landmark-role, microformat, or structured-data boundaries;
- one visible region match;
- repeated-entry count;
- destination links and headings;
- repeated-entry shape consistency;
- hidden matches excluded from the result;
- navigation, form, sidebar, or footer-like clutter;
- generated-looking classes or identifiers;
- extremely small or broad selections.

It does not export a hidden numeric confidence score. The person remains the decision-maker. A fragile section can still be chosen, and a “steadier” section is not treated as guaranteed.

## Shared fixed extractor

The new canonical `Extension/shared/capture.js` is copied byte-for-byte into the generated Firefox package and used by the Chromium service worker.

It:

- executes as packaged Extension code through `scripting.executeScript()`;
- targets frame `0` only;
- runs in the isolated extension world;
- accepts no code from the page, Node, curator, or source list;
- offers at most three candidates;
- emits at most four reasons and four warnings per candidate;
- returns plain JSON-safe values;
- excludes hidden matches;
- carries rendered text direction and extractor revision;
- sends no cookie, credential, browser storage, form value, raw HTML, DOM node, screenshot, or page script.

## Artifact contract

New Extension submissions use:

```text
progrss.browser-capture.v2
```

and add:

```text
page.direction
selection.schema = progrss.capture-selection.v1
selection.candidateId
selection.assessment.schema = progrss.capture-section-assessment.v1
provenance.extractorRevision = contour-v1
```

The Node strictly validates every known field, label, count, bound, and relationship before durable intent. Legacy `progrss.browser-capture.v1` remains accepted during a rolling local upgrade, but the Node does not invent missing assessment evidence.

The durable acquisition receipt retains:

```text
artifact schema
extractor revision
selected candidate ID
section-evidence level
section-evidence summary
```

The hidden ordering rank is neither transferred nor receipted.

## Authority remains unchanged

Contour does not add a browser permission or a scheduler capability.

```text
Capture remains deliberate.
The exact reviewed page must be active.
A changed watched section still needs a separate acknowledgement.
A changed section still creates a fresh baseline.
The Node still makes zero watched-site requests for Capture.
Capture still creates no recurring schedule.
Pulse still requires successful Node-side Witness evidence.
Pairing remains summary-only and read-only.
```

## Tests added

`Extension/tests/capture_quality_smoke.py` runs the shipped extractor in a real Chromium DOM and checks:

- semantic repeated entries;
- hidden-match exclusion;
- generated-selector fragility;
- right-to-left direction;
- bounded reasons and warnings.

Existing rendered-reader smoke now covers the complete Contour review and durable receipt.

## Not claimed

This release does not claim completed:

- unmanaged installed Chromium acceptance;
- current Firefox or Firefox ESR installation acceptance;
- signed-in real-site fieldwork;
- unfamiliar-person comprehension;
- real screen-reader, Braille, voice-control, or switch-device sessions;
- pagination, virtual-list, closed-shadow-root, or cross-origin-frame support;
- automatic selector repair;
- arbitrary shared JavaScript;
- browser-assisted recurring scheduling.

Those remain explicit next work rather than implicit passes.
