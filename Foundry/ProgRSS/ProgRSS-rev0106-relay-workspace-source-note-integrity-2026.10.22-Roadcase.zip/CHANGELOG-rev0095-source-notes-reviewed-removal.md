# rev0095 — Source Notes reviewed folder removal

- Bind destructive direct-placement removal to the displayed folder version and placement reason.
- Require the exact persisted vault revision when the folder version is saturated at `10000`.
- Refuse stale newer-wording, replacement-placement, missing-review, ambiguous-placement, and inherited-only actions without mutation.
- Preserve below-ceiling unrelated-folder continuity.
- Retain complete relationship metadata and original position for guarded Undo.
- Add a 14-case Chromium-source/generated-Firefox production-handler corpus.
- Keep browser permissions, CLI product behavior, and the 18-case runtime catalog count unchanged.
