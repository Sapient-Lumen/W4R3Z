# ProgRSS rev0077 — Debrief

**Release maxim:** Find patterns. Do not score people.

Debrief adds a private, self-contained analysis workspace for several compatible
Fieldbook reports. It is designed for the step after actual sessions: compare
observed outcomes, inspect raw local notes, write bounded product findings, and
export a privacy-reviewed debrief without copying those raw notes.

## Delivered

- `progrss.fieldwork-debrief-kit.v1` self-contained analysis workspace.
- `progrss.fieldwork-debrief.v1` reviewed JSON and Markdown finding report.
- Strict validation of `progrss.fieldwork-report.v1` inputs.
- Exact canonical duplicate removal.
- Refusal of mixed scenarios, releases, and task sequences.
- Per-task counts for independent understanding, neutral-prompt understanding,
  wrong turns, and unobserved tasks.
- Bounded signals for recurring wrong turns, prompt dependence, coverage gaps,
  one-report-only evidence, and no recurring signal yet.
- One explicit product disposition per task.
- Bounded finding and smallest-product-response fields.
- Local visibility of facilitator notes with complete exclusion from export.
- Review-before-export and three separate privacy acknowledgements.
- Node GUI download under **Research and acceptance**.
- Offline `progrss node debrief` generation with optional preloaded reports.
- Dark fluorescent default, light mode, forced-colors, reduced-motion, print,
  keyboard, and narrow-screen treatment.

## Privacy and interpretation boundary

Debrief requests no participant identity and performs no network request,
telemetry, browser-storage persistence, automatic upload, or Node-library
write. It does not calculate a participant score, rank people, infer broad
population usability, or declare that ProgRSS passed acceptance.

Raw facilitator notes remain in the local workspace only. The exported debrief
contains newly written findings, product responses, dispositions, bounded
signals, and aggregate counts—not raw notes.

## Unchanged

- Fieldbook remains the one-session facilitator sidecar.
- Trace and Bearing remain read-only.
- Anchor remains the only held-baseline replacement operation.
- Capture remains a separate deliberate exact-page browser action.
- Pulse remains limited to Node-reproducible Witness evidence.
- Extension pairing remains summary-only and read-only.
- No automatic recipe repair, Pinpoint overlay, remote Node, WebRTC dependency,
  new browser permission, or broader write authority.

## Acceptance boundary

Automated tests load several synthetic Fieldbook reports, verify repeated-wrong-
turn and prompt-dependence signals, review every task, exercise the privacy gate,
and download a local debrief. This verifies the tool and export boundary only.
No unfamiliar-person, native installed-browser, or real assistive-technology
session is represented as completed by this release.
