# Product continuity audit — rev0106

Parent: `ProgRSS-rev0105-node-private-library-source-note-integrity-2026.10.22-Roadcase.zip`  
SHA-256: `e34cb801d87dd7e4c8bf26cf72ce25e6356af68d20818140691889a59c19dd6c`

Compared 331 parent CLI/Extension paths with 332 current paths. Three existing CLI paths changed (including one inherited test fixture updated for the stricter private-workspace contract) and one focused CLI test path was added. No product path was deleted and no executable mode changed. The entire Extension product tree, both browser manifests, and every browser permission projection are byte-identical to rev0105. No persistent store or network authority was added.

## Changed paths

- `CLI/README.md`
- `CLI/relay.py`
- `CLI/tests/test_source_notes_entrypoints.py`

## Added path

- `CLI/tests/test_source_notes_relay_workspace.py`
