# Changelog — rev0088 Source Notes runtime evidence

## Added

- A fixed 18-case exact-package runtime catalog covering package identity, installation and permissions, placement authoring, interruption, stale save/undo, restart persistence, native disclosure/integrity, OPML omission, and separate **Keep mine** / **Use curator’s** divergent-copy runs.
- `tools/source_notes_runtime_evidence.py`, which derives rather than accepts the overall result, binds one session to the immutable Roadcase, selected package, fixture, catalog, template, result, and referenced evidence, and emits a deterministic evidence bundle plus an unsigned in-toto Statement-shaped record.
- Separate preparation, finalization, independent verification, and comparison CLIs.
- An independent verifier that requires the immutable Roadcase again, reruns its native verifier, re-derives the selected browser package and fixture from that archive, and reconstructs the statement from bundle contents.
- A cross-browser report that exposes case, permission, raw-artifact, and optional semantic-projection differences without treating comparison as a runtime pass.
- Machine-readable result schema, attestation boundary, protocol, matrix, audit, and ten focused tamper/classification tests.

## Tightened

- The session ID now binds Roadcase digest, browser family, and preparation configuration, preventing two channels or environments from silently sharing an ID.
- The catalog and template must exactly match the fixed rev0088 forms; coordinated metadata edits are refused.
- The prepared package manifest must match the selected package inside the same Roadcase; coordinated package, manifest, and session tampering is refused.
- `not-run` cases must remain empty. Executed and blocked cases require a timestamp, observation, and referenced evidence.
- A passing result requires the prepared observed identity, exact prepared package, same-profile restart, a fresh-profile assertion when declared, an unmanaged assertion for unmanaged sessions, and a human-observation assertion when human permission observation was declared.
- Missing, symlinked, oversized, changed, and unreferenced evidence is refused.

## Replayed

- All 11 CLI modules.
- All 60 Extension Python tests, Chromium and Firefox Source Notes harnesses, Firefox background harness, acquisition/vault harnesses, and managed side-panel/workbench smoke.
- Native Source Notes contract, placement authoring, branch/disclosure/import/OPML/conflict paths, permission projections, and generated-Firefox shared-file parity.

## Explicitly not established

- Managed current Chromium compatibility.
- Unmanaged current Chromium acceptance.
- Firefox Release or Firefox ESR runtime acceptance.
- Signed-install permission-prompt comprehension.
- Authenticated operator identity or human presence.
- Accessibility conformance, real assistive-technology evidence, or unfamiliar-person comprehension.
- SLSA compliance, signed provenance, or a trusted attestation service.
