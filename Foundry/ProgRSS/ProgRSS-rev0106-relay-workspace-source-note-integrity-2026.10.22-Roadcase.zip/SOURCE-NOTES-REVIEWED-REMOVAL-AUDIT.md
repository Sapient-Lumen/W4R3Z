# Source Notes reviewed folder-removal audit — rev0095

- Parent accepted stale removal after newer wording below the ceiling: **YES**
- Parent accepted stale removal of a replacement placement at the ceiling: **YES**
- Chromium-source focused corpus: **PASS** (14 cases)
- Generated-Firefox focused corpus: **PASS** (14 cases)
- Review binding, exact ceiling revision, one-placement removal, and parity checks: **PASS**

The parent reproduction and candidate checks use production background handlers and side-panel functions with browser API doubles. They are not installed-browser, participant, accessibility, or assistive-technology acceptance.

Removal now requires the displayed folder version and explicit displayed reason. At folder version `10000`, it also requires the exact persisted vault revision. Below the ceiling, an unrelated write to another folder remains nonblocking when the reviewed placement itself is unchanged.
