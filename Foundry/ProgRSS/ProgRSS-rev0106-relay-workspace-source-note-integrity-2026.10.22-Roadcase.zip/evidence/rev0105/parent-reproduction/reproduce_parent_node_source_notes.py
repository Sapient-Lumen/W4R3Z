#!/usr/bin/env python3
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[3]
CLI = ROOT / 'CLI'
if str(CLI) not in sys.path:
    sys.path.insert(0, str(CLI))
from node_store import NodeStore  # noqa: E402
from node_server import _read_backup  # noqa: E402


def main() -> int:
    document = json.loads((CLI / 'fixtures' / 'sample-backup.json').read_text(encoding='utf-8'))
    source_id = document['state']['sources'][0]['id']
    document['state']['collections'] = [{
        'id': 'folder', 'title': 'Folder', 'mode': 'union', 'include': '', 'exclude': '',
        'version': 1, 'author': 'Reproduction',
        'members': [{'kind': 'source', 'id': source_id, 'reason': 'x' * 281}],
    }]
    with tempfile.TemporaryDirectory(prefix='progrss-node-source-note-parent-') as name:
        folder = Path(name)
        backup = folder / 'malformed-private.json'
        store_path = folder / 'library.sqlite3'
        exported = folder / 'exported.json'
        raw = (json.dumps(document, ensure_ascii=True, separators=(',', ':')) + '\n').encode('utf-8')
        backup.write_bytes(raw)
        creation = NodeStore.create_from_backup(backup, store_path, now=1_800_000_000.0)
        store = NodeStore(store_path)
        current = store.read_library()
        export = store.export_current(exported)
        served, served_raw = _read_backup(backup)
        persisted = current.document['state']['collections'][0]['members'][0]['reason']
        served_reason = served['state']['collections'][0]['members'][0]['reason']
        result = {
            'parentRevision': (ROOT / 'REVISION').read_text(encoding='utf-8').strip(),
            'malformedReasonCodePoints': len(persisted),
            'nodeStoreCreateAccepted': True,
            'nodeStoreReadAccepted': True,
            'nodeStoreExportAccepted': True,
            'readOnlyNodeLoaderAccepted': True,
            'importSha256': hashlib.sha256(raw).hexdigest(),
            'storedSha256': current.sha256,
            'exportedSha256': hashlib.sha256(exported.read_bytes()).hexdigest(),
            'servedSha256': hashlib.sha256(served_raw).hexdigest(),
            'exactImportPreserved': current.raw == raw,
            'exactExportPreserved': exported.read_bytes() == raw,
            'servedReasonCodePoints': len(served_reason),
            'creation': creation,
            'export': export,
        }
    out = ROOT / 'evidence' / 'rev0105' / 'parent-reproduction' / 'result.json'
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
