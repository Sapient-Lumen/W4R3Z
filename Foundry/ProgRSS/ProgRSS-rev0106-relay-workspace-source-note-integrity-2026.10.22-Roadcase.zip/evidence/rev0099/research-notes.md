# Primary-source research — 2026-10-22

These references informed the integration method, not project test evidence.

- https://git-scm.com/docs/git-merge-file — three inputs (current/base/other) preserve
  independent changes instead of replacing the current tree with an older tree.
- https://git-scm.com/docs/git-diff — direct path comparison without a repository.
- https://reproducible-builds.org/docs/definition/ — source, environment, and instructions
  define reproducibility scope. Same-environment deterministic ZIP construction is not
  a universal cross-toolchain reproducibility claim.
- https://json-schema.org/understanding-json-schema/reference/object —
  additionalProperties:false rejects unlisted fields. Chronology still needs semantic checks.
- https://www.rfc-editor.org/info/rfc3339/ — Gregorian calendar timestamp semantics;
  a timestamp-shaped regular expression alone is insufficient.

No current browser-channel assertion was made this pass. Frozen channel sources are
historical self-test inputs; refresh on each actual target host.
