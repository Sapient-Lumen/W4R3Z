#!/usr/bin/env python3
"""Replay synthetic invalid records against a selected extracted source tree."""
import copy,importlib.util,json,sys,tempfile
from pathlib import Path
root=Path(sys.argv[1]).resolve(); out=Path(sys.argv[2]).resolve()
sys.path.insert(0,str(root));sys.path.insert(0,str(root/'tools'))
spec=importlib.util.spec_from_file_location('record_fixtures', root/'tests/test_source_notes_runtime_evidence.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
mutations={
 'valid-control':lambda r: None,
 'impossible-calendar-timestamp':lambda r:r['cases'][0].update(recordedUtc='2026-99-99T99:99:99Z'),
 'case-before-run':lambda r:r['cases'][0].update(recordedUtc='2026-10-21T11:59:59Z'),
 'case-after-run':lambda r:r['cases'][0].update(recordedUtc='2026-10-21T12:20:01Z'),
 'event-after-run':lambda r:r['events'][0].update(recordedUtc='2026-10-21T12:20:01Z'),
 'unknown-result-claim':lambda r:r.update(authenticatedBrowser=True),
 'unknown-case-claim':lambda r:r['cases'][0].update(authenticatedBrowser=True),
 'unknown-event-claim':lambda r:r['events'][0].update(authenticatedBrowser=True),
 'empty-permission-projections':lambda r:r['permissionObservation'].update(before={},after={}),
 'invented-native-artifact-role':lambda r:r['nativeArtifacts'].update(invented=copy.deepcopy(r['nativeArtifacts']['completeRoute'])),
}
rows=[]
with tempfile.TemporaryDirectory() as td:
 rc,session=mod.prepare_session(Path(td));path=mod.complete_result(session);original=mod.read_json(path)
 for label,mutate in mutations.items():
  result=copy.deepcopy(original);mutate(result);path.write_bytes(mod.canonical_json_bytes(result))
  try:
   v=mod.finalize_evidence(session_dir=session,roadcase=rc,result_path=path,verifier=root/'VERIFY-ROADCASE.py')
   row={'case':label,'accepted':True,'derivedStatus':v.status}
  except Exception as e:
   row={'case':label,'accepted':False,'error':str(e),'errorType':type(e).__name__}
  rows.append(row);print(json.dumps(row),flush=True)
report={'scope':'Synthetic verifier reproduction, not browser execution','revision':(root/'REVISION').read_text().strip(),'results':rows}
out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
