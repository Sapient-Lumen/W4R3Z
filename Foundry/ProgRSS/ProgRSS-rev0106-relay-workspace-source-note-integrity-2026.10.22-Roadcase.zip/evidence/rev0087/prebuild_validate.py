#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import py_compile
import subprocess
import sys
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[2]
SKIP = {'.git', 'node_modules', '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache'}

def paths(suffix: str):
    return [p for p in ROOT.rglob(f'*{suffix}') if not any(part in SKIP for part in p.relative_to(ROOT).parts)]

counts = {}
for p in paths('.json'):
    json.loads(p.read_text(encoding='utf-8'))
counts['json'] = len(paths('.json'))
print(f"JSON parse: {counts['json']} files")

py_files = paths('.py')
for p in py_files:
    py_compile.compile(str(p), doraise=True)
counts['python'] = len(py_files)
print(f"Python compile: {counts['python']} files")

js_files = paths('.js')
for p in js_files:
    cp = subprocess.run(['node', '--check', str(p)], text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if cp.returncode:
        raise RuntimeError(f'JavaScript syntax failed: {p.relative_to(ROOT)}\n{cp.stdout}')
counts['javascript'] = len(js_files)
print(f"JavaScript syntax: {counts['javascript']} files")

html_files = paths('.html')
for p in html_files:
    BeautifulSoup(p.read_text(encoding='utf-8'), 'html.parser')
counts['html'] = len(html_files)
print(f"HTML parse: {counts['html']} files")

css_files = paths('.css')
for p in css_files:
    text = p.read_text(encoding='utf-8')
    if text.count('{') != text.count('}'):
        raise RuntimeError(f'CSS brace mismatch: {p.relative_to(ROOT)}')
counts['css'] = len(css_files)
print(f"CSS delimiter check: {counts['css']} files")

pairs = [
    ('background.js', 'Firefox/background.js'),
    ('shared/core.js', 'Firefox/shared/core.js'),
    ('shared/shared-folder.js', 'Firefox/shared/shared-folder.js'),
    ('sidepanel/app.js', 'Firefox/sidepanel/app.js'),
    ('sidepanel/app.css', 'Firefox/sidepanel/app.css'),
    ('sidepanel/index.html', 'Firefox/sidepanel/index.html'),
]
for left, right in pairs:
    if (ROOT / 'Extension' / left).read_bytes() != (ROOT / 'Extension' / right).read_bytes():
        raise RuntimeError(f'generated Firefox parity mismatch: {left} != {right}')
print(f"Generated Firefox authoring parity: {len(pairs)} files")

required = {
    'BOOTSTRAPROSE.md': 'BEGIN CURRENT-RUN-AUTHORITY rev0087-source-notes-runtime-kit',
    'CURRENT-STATUS.md': 'Candidate with exact-package tooling and managed non-current Chromium preflight',
    'HANDOFF.md': 'ProgRSS rev0087 Source Notes runtime-kit handoff',
    'REVISION-STATE.json': 'rev0087-source-notes-runtime-kit',
    'SOURCE-NOTES-RUNTIME-PROTOCOL.md': 'Blocked, unavailable, skipped, and timed-out work never becomes a pass',
}
for name, marker in required.items():
    if marker not in (ROOT / name).read_text(encoding='utf-8'):
        raise RuntimeError(f'missing current marker: {name}: {marker}')
print('Generated claim and provenance summaries: PASS')
print('\nFINAL PREBUILD VALIDATION: PASS')
print(json.dumps(dict(sorted(counts.items())), sort_keys=True))
