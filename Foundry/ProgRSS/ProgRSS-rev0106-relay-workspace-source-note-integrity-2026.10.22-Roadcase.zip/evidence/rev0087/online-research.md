# Online research snapshot — 2026-10-21

Primary sources consulted during rev0087:

- Google Chrome for Testing last-known-good channel JSON: `https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json`
  - Timestamp: `2026-10-21T10:20:21.313Z`
  - Stable reference: `156.0.8078.47`
- Mozilla product-details Firefox versions JSON: `https://product-details.mozilla.org/1.0/firefox_versions.json`
  - Firefox Release: `158.0.1`
  - Firefox ESR: `153.5.1esr`
  - Last release date: `2026-10-13`
- Mozilla Extension Workshop temporary-installation guidance: `https://extensionworkshop.com/documentation/develop/temporary-installation-in-firefox/`
  - `about:debugging` temporary installation is suitable for testing but ends on removal/restart and does not fully mimic signed installation, including installation-time permission prompts.
- Chrome Extensions unpacked-install guidance: `https://developer.chrome.com/docs/extensions/get-started/tutorial/hello-world#load-unpacked`
  - Developer Mode plus **Load unpacked** is the documented local install path.

The execution environment exposed Debian Chromium `144.0.7559.96`, no Firefox executable, and an enterprise policy that blocked unpacked extensions. The managed runtime preflight temporarily replaced only the merged top-level Chromium policy file with an empty policy, declared that override in its result, and restored the original policy after each run. This cannot be described as unmanaged or current-channel evidence.
