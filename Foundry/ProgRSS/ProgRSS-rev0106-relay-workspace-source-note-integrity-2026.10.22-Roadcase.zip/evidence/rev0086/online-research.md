# Online research used for rev0086 prioritization

Checked on 2026-10-21. These primary references constrain the managed design and next evidence order; they do not substitute for ProgRSS product tests or human fieldwork.

- Chrome Side Panel API: <https://developer.chrome.com/docs/extensions/reference/api/sidePanel>. The existing side panel is an extension-owned persistent UI surface, so the authoring control stays beside the existing folder organizer rather than creating a new page or permission.
- Chrome Storage API: <https://developer.chrome.com/docs/extensions/reference/api/storage>. `storage.local` is local to each machine. ProgRSS still states consequences explicitly rather than assuming users infer them from platform storage semantics.
- MDN `storage.local`: <https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/storage/local>. Firefox likewise describes local extension storage as machine-local.
- MDN WebExtension permissions: <https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/manifest.json/permissions>. Permission projections remain an explicit release boundary and were compared structurally with rev0080.
- W3C Reflow: <https://www.w3.org/WAI/WCAG21/Understanding/reflow.html>.
- W3C Resize Text: <https://www.w3.org/WAI/WCAG21/Understanding/resize-text.html>.
- W3C Focus Not Obscured: <https://www.w3.org/WAI/WCAG22/Understanding/focus-not-obscured-minimum.html>.
- W3C Target Size (Minimum): <https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html>.

The managed smoke therefore checks narrow reflow, enlarged text, focus continuity, meaningful target names, and conservative 44px controls. These remain regression checks, not accessibility-conformance or assistive-technology evidence.
