#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[2] / 'CLI'
out = Path(__file__).resolve().parent
modules = [
    'tests.test_acquisition',
    'tests.test_cadence',
    'tests.test_cli',
    'tests.test_command_line',
    'tests.test_debrief',
    'tests.test_fieldbook',
    'tests.test_node_server',
    'tests.test_node_store',
    'tests.test_relay',
    'tests.test_roadcase',
    'tests.test_source_notes_entrypoints',
]
results = []
for module in modules:
    started = time.monotonic()
    completed = subprocess.run(
        [sys.executable, '-m', 'unittest', '-v', module],
        cwd=root,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=900,
        check=False,
    )
    seconds = round(time.monotonic() - started, 3)
    log_name = f"cli-{module.split('.')[-1].replace('test_', 'test_', 1)}.log"
    (out / log_name).write_text(completed.stdout, encoding='utf-8')
    state = 'pass' if completed.returncode == 0 else 'fail'
    results.append({'module': module, 'state': state, 'returncode': completed.returncode, 'seconds': seconds, 'log': log_name})
    print(f"{module}: {state} ({seconds}s)")
summary = {'generatedUtc': '2026-10-21T00:00:00Z', 'allPassed': all(row['state'] == 'pass' for row in results), 'results': results}
(out / 'cli-modules-summary.json').write_text(json.dumps(summary, sort_keys=True, indent=2) + '\n', encoding='utf-8')
raise SystemExit(0 if summary['allPassed'] else 1)
