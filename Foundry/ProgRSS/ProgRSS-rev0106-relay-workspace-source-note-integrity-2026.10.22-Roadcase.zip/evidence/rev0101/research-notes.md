# Online research notes — 2026-10-22

Official planning sources were checked this turn:

- Chrome for Testing last-known-good versions JSON reported Stable 156.0.8078.47 with source timestamp 2026-10-21T21:20:27Z.
- Mozilla product-details JSON reported Firefox 158.0.1 and Firefox ESR 153.5.1esr; the published next release date was 2026-10-23.

These values are planning references only. The actual target hosts must capture fresh official channel evidence at execution time.

Sources:
- https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json
- https://product-details.mozilla.org/1.0/firefox_versions.json
