# rev0096 research notes

Captured 2026-10-21 for planning and scope discipline.

- Chrome for Testing official channel endpoint reported Stable `156.0.8078.47` at capture time: https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json
- Mozilla product-details reported Firefox Release `158.0.1` and Firefox ESR `153.5.1esr`: https://product-details.mozilla.org/1.0/firefox_versions.json
- Chrome extension service-worker lifecycle guidance says globals can be lost on shutdown and durable state should be persisted: https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/lifecycle
- Mozilla temporary-extension guidance says a temporary add-on remains only until removal or browser restart and is not the end-user installation path: https://extensionworkshop.com/documentation/develop/temporary-installation-in-firefox/
- Mozilla permission-testing guidance distinguishes temporary development loading from packaged installation-time permission warnings: https://extensionworkshop.com/documentation/develop/test-permission-requests/

These sources guide runtime classification. They do not establish that the exact rev0096 package ran in any current browser.
