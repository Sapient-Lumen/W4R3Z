from pathlib import Path
import asyncio, json, tempfile, shutil, importlib.util
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright
ROOT=Path('/mnt/data/rev0104-work/Extension')
TESTS=ROOT/'tests'
spec=importlib.util.spec_from_file_location('collection_harness', TESTS/'source_notes_workbench_collection_harness.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
async def main():
  seed=mod.blank_state()
  seed['collections'][0]['members'][0]['reason']='x'*281
  async with async_playwright() as p:
    executable=shutil.which('chromium') or shutil.which('chromium-browser') or shutil.which('google-chrome')
    kw={'headless':True,'args':['--no-sandbox']}
    if executable: kw['executable_path']=executable
    browser=await p.chromium.launch(**kw)
    page,errors=await mod.load_workbench(browser,ROOT,seed)
    try:
      async with page.expect_download(timeout=10000) as info:
        await page.evaluate("document.getElementById('docs-backup').click()")
      dl=await info.value
      out=Path('/tmp/parent-invalid-backup.json'); await dl.save_as(str(out))
      doc=json.loads(out.read_text())
      reason=doc['state']['collections'][0]['members'][0]['reason']
      print(json.dumps({'downloaded':True,'reasonCodePoints':len(reason),'filename':dl.suggested_filename,'errors':errors},indent=2))
    finally:
      await page.close(); await browser.close()
asyncio.run(main())
