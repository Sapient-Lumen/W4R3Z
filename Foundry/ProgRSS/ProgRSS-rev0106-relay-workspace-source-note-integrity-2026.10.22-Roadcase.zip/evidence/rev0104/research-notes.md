# rev0104 research notes — 2026-10-22

## Browser planning references

Official channel endpoints observed during this pass:

- Chrome for Testing Stable: `156.0.8078.47`; source timestamp `2026-10-22T09:22:03.922Z`.
- Firefox Release: `158.0.1`.
- Firefox ESR: `153.5.1esr`.

These are planning references only. Each target host must capture fresh official source bytes and its actual browser identity at execution time.

Sources:

- https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json
- https://product-details.mozilla.org/1.0/firefox_versions.json

## Status-message boundary

The Workbench already exposes its toast as `role="status" aria-live="polite"`. W3C’s WCAG 2.2 understanding document explains that status messages reporting success or errors should be programmatically determinable so assistive technologies can announce them without taking focus. The rev0104 managed check verifies only the shipped markup and message content; it is not screen-reader or accessibility-conformance evidence.

Source:

- https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html
