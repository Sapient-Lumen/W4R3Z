# Online research — rev0089

Captured 2026-10-21 for runtime planning and source-byte binding.

- Chrome for Testing `last-known-good-versions.json`: Stable `156.0.8078.47`, revision `1706539`, source timestamp `2026-10-21T10:20:21.313Z`.
- Mozilla product-details `firefox_versions.json`: Release `158.0.1`, ESR `153.5.1esr`, last release date `2026-10-13`.
- Chrome’s supported unpacked-development path remains Developer Mode → Load unpacked.
- Mozilla documents that a temporary add-on ends on restart and does not fully mimic signed installation, including installation-time permission requests.

The raw channel payloads are preserved under `runtime-channel-reference/channel-sources/`; `CHANNEL-SNAPSHOT.json` records their byte digests and the explicit unauthenticated-capture boundary.
