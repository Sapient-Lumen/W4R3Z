# Attempt history

The first inherited focused gate stopped at the execution timeout after its native
CLI/Node/background checks; its evidence-test phase was incomplete. An exploratory
evidence-only run was deliberately bounded to 20 seconds and also timed out.
Neither is counted as a passing whole suite. Their partial logs are retained.
The later completed `regression-status.json` records the full rerun and its scope.

The first streaming shell request was unsupported by the container. No result was
inferred from it. A regular regression process was subsequently run within this turn.
No real browser or enterprise policy was controlled through a replacement tool.

`before-folder-undo-loss.json` was generated against the unmodified verified
rev0090 product code, before the repair. Its script deliberately uses the old UI
request and should be replayed with a rev0090 extraction as its first argument.
`reproduce-source-repair-collision.js` still demonstrates an OPEN defect against
this candidate; it is not a green test or a browser-runtime record.
