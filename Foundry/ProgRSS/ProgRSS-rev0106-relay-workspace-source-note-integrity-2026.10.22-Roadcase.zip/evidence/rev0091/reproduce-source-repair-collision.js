'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const ROOT = path.resolve(process.argv[2] || path.join(__dirname, '../../Extension'));

const storage = new Map();
const extensionStorage = new Map();
let failVaultWrites = false;
let pageExtractContent = 'Library opens Monday at 9.';
let pageExtractErrorCode = '';
let pageRepairVariant = 0;
globalThis.localStorage = {
  getItem(key) { return storage.has(key) ? storage.get(key) : null; },
  setItem(key, value) {
    if (failVaultWrites) {
      const error = Error('quota exceeded while writing the test vault');
      error.name = 'QuotaExceededError';
      throw error;
    }
    storage.set(key, String(value));
  },
  removeItem(key) { storage.delete(key); }
};

const messageListeners = [];
const alarms = [];
globalThis.chrome = {
  storage: {
    local: {
      async get(key) {
        if (key == null) return Object.fromEntries(extensionStorage);
        const keys = Array.isArray(key) ? key : [key];
        return Object.fromEntries(keys.filter(value => extensionStorage.has(value)).map(value => [value, extensionStorage.get(value)]));
      },
      async set(values) { for (const [key, value] of Object.entries(values || {})) extensionStorage.set(key, value); },
      async remove(key) { for (const value of (Array.isArray(key) ? key : [key])) extensionStorage.delete(value); }
    }
  },
  permissions: {
    async contains() { return true; },
    async getAll() { return {permissions: [], origins: ['https://example.test/*']}; }
  },
  runtime: {
    getURL(value) { return `chrome-extension://test/${value}`; },
    getManifest() { return {version: '0.80.0'}; },
    async getContexts() { return []; },
    async sendMessage(message) {
      if (message?.target === 'offscreen') {
        if (message.type === 'parse-feed') {
          return {ok: true, result: {
            title: 'Harness Feed', titleLanguage: 'en-GB', language: 'en-GB', type: 'rss', feedUrl: 'https://example.test/feed.xml', items: [
              {key: 'entry-1', title: 'A new entry', url: 'https://example.test/post/1', summary: 'ملخص الاختبار', body: 'نص الاختبار\n\nفقرة ثانية محفوظة.', bodyIsSummary: false, language: 'AR', titleLanguage: 'EN', summaryLanguage: 'AR', bodyLanguage: 'AR', published: '2026-10-17T12:00:00.000Z'}
            ]
          }};
        }
        if (message.type === 'parse-opml') {
          return {ok: true, result: {
            title: 'Harness subscriptions', feedOutlines: 4, invalidCount: 1, duplicateCount: 1, truncatedCount: 0, folderCount: 2,
            feeds: [
              {title: 'Harness Feed', url: 'https://example.test/feed.xml', folderPaths: [['Reading']]},
              {title: 'Independent Notes', url: 'https://new.test/feed.xml', folderPaths: [['Reading', 'Independent']]},
              {title: 'Other Notes', url: 'https://other.test/atom.xml', folderPaths: [['Reading']]}
            ]
          }};
        }
        if (message.type === 'inspect-resource') return {ok: true, result: {kind: 'feed', url: message.data.url, title: 'Harness Feed', titleLanguage: 'en-GB', language: 'en-GB', feedType: 'rss', feedUrl: 'https://example.test/feed.xml', itemCount: 1, previewCount: 1, previewFullTextCount: 1, previewSummaryCount: 0, previewDatedCount: 1, previewItems: [{title: 'A new entry', url: 'https://example.test/post/1', published: '2026-10-17T12:00:00.000Z', content: 'full-text', language: 'ar', titleLanguage: 'en'}]}};
        if (message.type === 'extract-page') {
          if (pageExtractErrorCode) return {ok: false, error: 'The watched section is missing.', code: pageExtractErrorCode, detail: {field: 'selector'}};
          return {ok: true, result: {mode: 'region', content: pageExtractContent, matchCount: 1, meaningfulCount: 1, contentChars: pageExtractContent.length}};
        }
        if (message.type === 'repair-page-watch') {
          const content = pageRepairVariant ? `${pageExtractContent} changed after review` : pageExtractContent;
          return {ok: true, result: [{
            schema: 'progrss.page-watch.repair.v1', title: 'Watch the page’s main text',
            description: 'Notice meaningful wording changes in the main part of the page.',
            mode: 'region', count: 1, examples: [], preview: content,
            recipe: {mode: 'region', selector: 'main', titleSelector: '', linkSelector: '', threshold: 4, ignoreNumbers: false},
            evidence: {signature: `region:${content}`, matchCount: 1, contentChars: content.length},
            capture: {mode: 'region', content, matchCount: 1, meaningfulCount: 1, contentChars: content.length}
          }]};
        }
      }
      return undefined;
    },
    onMessage: { addListener(listener) { messageListeners.push(listener); } },
    onInstalled: { addListener() {} },
    onStartup: { addListener() {} }
  },
  offscreen: { async createDocument() {} },
  action: {
    async setBadgeBackgroundColor() {}, async setBadgeText() {}, async setTitle() {}
  },
  sidePanel: { async setPanelBehavior() {} },
  alarms: { async create(name, details) { alarms.push({name, details}); }, onAlarm: { addListener() {} } },
  tabs: { async query() { return [{id: 1, url: 'https://example.test/', title: 'Example'}]; } },
  scripting: { async executeScript() { return [{result: {url: 'https://example.test/', title: 'Example', links: []}}]; } }
};

let fetchMode = 'normal';
let publicationPayload = '';
let publicationContentType = 'application/vnd.progrss.shared-folder+json; charset=utf-8';
const fetchCalls = [];
globalThis.fetch = async (url, options) => {
  fetchCalls.push({url: String(url), options});
  if (fetchMode === 'large') {
    return new Response('too large', {status: 200, headers: {'Content-Type': 'application/rss+xml', 'Content-Length': '2000001'}});
  }
  if (fetchMode === 'page') {
    return new Response(`<html><body><main>${pageExtractContent}</main></body></html>`, {
      status: 200, headers: {'Content-Type': 'text/html; charset=utf-8'}
    });
  }
  if (fetchMode === 'publication') {
    return new Response(publicationPayload, {
      status: 200, headers: {'Content-Type': publicationContentType, 'Content-Length': String(Buffer.byteLength(publicationPayload))}
    });
  }
  if (options?.headers?.['If-None-Match'] === '"harness-v1"') {
    return new Response(null, {status: 304, headers: {'ETag': '"harness-v1"', 'Last-Modified': 'Fri, 17 Oct 2026 12:00:00 GMT'}});
  }
  return new Response(
    '<rss><channel><title>Harness Feed</title><item><guid>entry-1</guid><title>A new entry</title></item></channel></rss>',
    {status: 200, headers: {'Content-Type': 'application/rss+xml', 'Content-Length': '120', 'ETag': '"harness-v1"', 'Last-Modified': 'Fri, 17 Oct 2026 12:00:00 GMT'}}
  );
};

globalThis.importScripts = (...files) => {
  for (const file of files) {
    const code = fs.readFileSync(path.join(ROOT, file), 'utf8');
    vm.runInThisContext(code, {filename: file});
  }
};

vm.runInThisContext(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8'), {filename: 'background.js'});
assert.strictEqual(messageListeners.length, 1, 'background message listener registered');
const listener = messageListeners[0];

function setBackupReminderFixture(marker) {
  extensionStorage.set('progrssBackupReminder', marker);
  vm.runInThisContext(`volatileBackupReminder = ${JSON.stringify(marker)};`);
}

function message(type, data = {}) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timeout = setTimeout(() => { if (!settled) reject(new Error(`timeout: ${type}`)); }, 1500);
    const keep = listener({target: 'background', type, data}, {}, response => {
      settled = true;
      clearTimeout(timeout);
      resolve(response);
    });
    assert.strictEqual(keep, true, `${type} keeps response channel open`);
  });
}



(async()=>{
  await message('get-state'); const state=await ProgRSSVault.init();
  state.sources=['first','second'].map(id=>({id,title:id,type:'rss',url:'https://same.example/feed.xml',enabled:false}));
  state.collections=[{id:'reading',title:'Reading',mode:'union',version:1,members:[
    {kind:'source',id:'first',reason:'First distinct reason.'},
    {kind:'source',id:'second',reason:'Second distinct reason.'}
  ]}];
  await ProgRSSVault.save(state);
  const before=structuredClone((await ProgRSSVault.init()).collections[0].members);
  const preview=await message('preview-source-repair',{firstSourceId:'first',secondSourceId:'second'});
  assert(preview.ok,preview.error);
  const commit=await message('repair-same-source',{firstSourceId:'first',secondSourceId:'second',survivorId:'second',reviewedRevision:preview.result.reviewedRevision});
  assert(commit.ok,commit.error);
  const after=(await ProgRSSVault.init()).collections[0].members;
  console.log(JSON.stringify({scope:'synthetic production preview and commit; NOT runtime or participant evidence',status:'OPEN_REPRODUCED',before,
    previewCanRepair:preview.result.canRepair,previewWarnings:preview.result.warnings,chosenSurvivor:'second',after,
    lostReason:!after.some(m=>m.reason==='Second distinct reason.'),
    observation:'Member order, not an explicit placement-reason decision, selected the remaining reason.'},null,2));
})().catch(e=>{console.error(e);process.exitCode=1;});
