# Research — 2026-10-21

Official sources re-read this turn:

- W3C, Understanding SC 3.3.4: https://www.w3.org/WAI/WCAG21/Understanding/error-prevention-legal-financial-data.html
  Reversibility is one option for protecting user-controlled stored data. This
  supports checking that an undo actually restores the removed relationship; it
  does not by itself establish WCAG conformance, timing adequacy, or AT success.
- Mozilla, Temporary installation in Firefox: https://extensionworkshop.com/documentation/develop/temporary-installation-in-firefox/
  Temporary installation ends at restart and differs from signed end-user installs.
  Keep restart/permission-prompt conclusions separate; no policy bypass was attempted.
- Chrome, Load unpacked: https://developer.chrome.com/docs/extensions/get-started/tutorial/hello-world
  Developer Mode/Load unpacked remains the documented local development path.
- Chrome for Testing channel endpoint: https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json
  Web retrieval reports Stable 156.0.8078.47, timestamp 2026-10-21T10:20:21.313Z.
- Mozilla product details: https://product-details.mozilla.org/1.0/firefox_versions.json
  Web retrieval reports Release 158.0.1 and ESR 153.5.1esr.

These are research observations, not authenticated channel captures. Existing
`runtime-channel-reference` bytes and capture times were not refreshed or relabeled.
The target host must capture fresh exact payload bytes before a real run.
