# Primary-source research — 2026-10-21

The following pages were opened using the web research tool this turn. This is a
research record, not an authenticated channel capture or browser execution.
The unchanged `runtime-channel-reference/` remains the historical supplied capture;
it was not re-dated. Capture new exact payload bytes on the target host before a run.

- https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions.json
  Returned Stable 156.0.8078.47; payload timestamp 2026-10-21T10:20:21.313Z.
- https://product-details.mozilla.org/1.0/firefox_versions.json
  Returned Firefox Release 158.0.1 and ESR 153.5.1esr.
- https://extensionworkshop.com/documentation/develop/temporary-installation-in-firefox/
  Temporary add-ons are removed at browser restart and do not reproduce all
  signed-install behavior, including installation-time permission prompts.
- https://github.com/in-toto/attestation/blob/main/spec/v1/statement.md
  Statements bind typed predicates to immutable subjects identified by digest.
  A statement-shaped JSON file is not by itself authenticated evidence.
- https://slsa.dev/spec/v1.2/verifying-artifacts
  Verification checks the artifact digest, provenance, signature, and configured
  trust expectations. ProgRSS's unsigned runtime record does not implement these
  authentication requirements and makes no SLSA claim.

## Change supported by the research and local regression

Compare verified bundles against the original immutable Roadcase, not standalone
JSON statements. Retain unsigned/operator-supplied limits. Derive artifact
comparison hashes from bytes using the shipped native reader; never interpret a
self-entered hash or a missing artifact as evidence of equivalence.
