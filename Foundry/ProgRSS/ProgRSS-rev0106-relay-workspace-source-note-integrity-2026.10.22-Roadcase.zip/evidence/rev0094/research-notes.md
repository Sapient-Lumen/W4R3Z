# Online research notes — 2026-10-21

Official channel references were re-read for target-host planning:

- Chrome for Testing last-known-good channels: `https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json` — Stable 156.0.8078.47 at capture.
- Mozilla product details: `https://product-details.mozilla.org/1.0/firefox_versions.json` — Firefox 158.0.1 and ESR 153.5.1esr at capture.

These values are planning references only. Each actual target-host session must capture fresh official bytes and bind the observed browser version; this source-side pass did not execute an installed current browser.
