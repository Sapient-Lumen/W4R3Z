// Managed production-handler tests with in-memory browser API doubles. Not an installed-browser run.
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const ROOT = path.resolve(__dirname, '..', process.env.PROGRSS_EXTENSION_ROOT || '.');
const FAMILY = process.env.PROGRSS_EXTENSION_ROOT === 'Firefox' ? 'generated-Firefox' : 'Chromium-source';

const storage = new Map();
const extensionStorage = new Map();
let failVaultWrites = false;
let pageExtractContent = 'Library opens Monday at 9.';
let pageExtractErrorCode = '';
let pageRepairVariant = 0;
globalThis.localStorage = {
  getItem(key) { return storage.has(key) ? storage.get(key) : null; },
  setItem(key, value) {
    if (failVaultWrites) {
      const error = Error('quota exceeded while writing the test vault');
      error.name = 'QuotaExceededError';
      throw error;
    }
    storage.set(key, String(value));
  },
  removeItem(key) { storage.delete(key); }
};

const messageListeners = [];
const alarms = [];
globalThis.chrome = {
  storage: {
    local: {
      async get(key) {
        if (key == null) return Object.fromEntries(extensionStorage);
        const keys = Array.isArray(key) ? key : [key];
        return Object.fromEntries(keys.filter(value => extensionStorage.has(value)).map(value => [value, extensionStorage.get(value)]));
      },
      async set(values) { for (const [key, value] of Object.entries(values || {})) extensionStorage.set(key, value); },
      async remove(key) { for (const value of (Array.isArray(key) ? key : [key])) extensionStorage.delete(value); }
    }
  },
  permissions: {
    async contains() { return true; },
    async getAll() { return {permissions: [], origins: ['https://example.test/*']}; }
  },
  runtime: {
    getURL(value) { return `chrome-extension://test/${value}`; },
    getManifest() { return {version: '0.80.0'}; },
    async getContexts() { return []; },
    async sendMessage(message) {
      if (message?.target === 'offscreen') {
        if (message.type === 'parse-feed') {
          return {ok: true, result: {
            title: 'Harness Feed', titleLanguage: 'en-GB', language: 'en-GB', type: 'rss', feedUrl: 'https://example.test/feed.xml', items: [
              {key: 'entry-1', title: 'A new entry', url: 'https://example.test/post/1', summary: 'ملخص الاختبار', body: 'نص الاختبار\n\nفقرة ثانية محفوظة.', bodyIsSummary: false, language: 'AR', titleLanguage: 'EN', summaryLanguage: 'AR', bodyLanguage: 'AR', published: '2026-10-17T12:00:00.000Z'}
            ]
          }};
        }
        if (message.type === 'parse-opml') {
          return {ok: true, result: {
            title: 'Harness subscriptions', feedOutlines: 4, invalidCount: 1, duplicateCount: 1, truncatedCount: 0, folderCount: 2,
            feeds: [
              {title: 'Harness Feed', url: 'https://example.test/feed.xml', folderPaths: [['Reading']]},
              {title: 'Independent Notes', url: 'https://new.test/feed.xml', folderPaths: [['Reading', 'Independent']]},
              {title: 'Other Notes', url: 'https://other.test/atom.xml', folderPaths: [['Reading']]}
            ]
          }};
        }
        if (message.type === 'inspect-resource') return {ok: true, result: {kind: 'feed', url: message.data.url, title: 'Harness Feed', titleLanguage: 'en-GB', language: 'en-GB', feedType: 'rss', feedUrl: 'https://example.test/feed.xml', itemCount: 1, previewCount: 1, previewFullTextCount: 1, previewSummaryCount: 0, previewDatedCount: 1, previewItems: [{title: 'A new entry', url: 'https://example.test/post/1', published: '2026-10-17T12:00:00.000Z', content: 'full-text', language: 'ar', titleLanguage: 'en'}]}};
        if (message.type === 'extract-page') {
          if (pageExtractErrorCode) return {ok: false, error: 'The watched section is missing.', code: pageExtractErrorCode, detail: {field: 'selector'}};
          return {ok: true, result: {mode: 'region', content: pageExtractContent, matchCount: 1, meaningfulCount: 1, contentChars: pageExtractContent.length}};
        }
        if (message.type === 'repair-page-watch') {
          const content = pageRepairVariant ? `${pageExtractContent} changed after review` : pageExtractContent;
          return {ok: true, result: [{
            schema: 'progrss.page-watch.repair.v1', title: 'Watch the page’s main text',
            description: 'Notice meaningful wording changes in the main part of the page.',
            mode: 'region', count: 1, examples: [], preview: content,
            recipe: {mode: 'region', selector: 'main', titleSelector: '', linkSelector: '', threshold: 4, ignoreNumbers: false},
            evidence: {signature: `region:${content}`, matchCount: 1, contentChars: content.length},
            capture: {mode: 'region', content, matchCount: 1, meaningfulCount: 1, contentChars: content.length}
          }]};
        }
      }
      return undefined;
    },
    onMessage: { addListener(listener) { messageListeners.push(listener); } },
    onInstalled: { addListener() {} },
    onStartup: { addListener() {} }
  },
  offscreen: { async createDocument() {} },
  action: {
    async setBadgeBackgroundColor() {}, async setBadgeText() {}, async setTitle() {}
  },
  sidePanel: { async setPanelBehavior() {} },
  alarms: { async create(name, details) { alarms.push({name, details}); }, onAlarm: { addListener() {} } },
  tabs: { async query() { return [{id: 1, url: 'https://example.test/', title: 'Example'}]; } },
  scripting: { async executeScript() { return [{result: {url: 'https://example.test/', title: 'Example', links: []}}]; } }
};

let fetchMode = 'normal';
let publicationPayload = '';
let publicationContentType = 'application/vnd.progrss.shared-folder+json; charset=utf-8';
const fetchCalls = [];
globalThis.fetch = async (url, options) => {
  fetchCalls.push({url: String(url), options});
  if (fetchMode === 'large') {
    return new Response('too large', {status: 200, headers: {'Content-Type': 'application/rss+xml', 'Content-Length': '2000001'}});
  }
  if (fetchMode === 'page') {
    return new Response(`<html><body><main>${pageExtractContent}</main></body></html>`, {
      status: 200, headers: {'Content-Type': 'text/html; charset=utf-8'}
    });
  }
  if (fetchMode === 'publication') {
    return new Response(publicationPayload, {
      status: 200, headers: {'Content-Type': publicationContentType, 'Content-Length': String(Buffer.byteLength(publicationPayload))}
    });
  }
  if (options?.headers?.['If-None-Match'] === '"harness-v1"') {
    return new Response(null, {status: 304, headers: {'ETag': '"harness-v1"', 'Last-Modified': 'Fri, 17 Oct 2026 12:00:00 GMT'}});
  }
  return new Response(
    '<rss><channel><title>Harness Feed</title><item><guid>entry-1</guid><title>A new entry</title></item></channel></rss>',
    {status: 200, headers: {'Content-Type': 'application/rss+xml', 'Content-Length': '120', 'ETag': '"harness-v1"', 'Last-Modified': 'Fri, 17 Oct 2026 12:00:00 GMT'}}
  );
};

globalThis.importScripts = (...files) => {
  for (const file of files) {
    const code = fs.readFileSync(path.join(ROOT, file), 'utf8');
    vm.runInThisContext(code, {filename: file});
  }
};

if (FAMILY === 'generated-Firefox') {
  globalThis.browser = globalThis.chrome;
  browser.runtime.getURL = value => `moz-extension://test/${String(value).replace(/^\//, '')}`;
  browser.sidebarAction = {async open() {}};
  browser.action.onClicked = {addListener() {}};
  delete browser.sidePanel;
  delete browser.offscreen;
}
vm.runInThisContext(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8'), {filename: 'background.js'});
assert.strictEqual(messageListeners.length, 1, 'background message listener registered');
const listener = messageListeners[0];

function setBackupReminderFixture(marker) {
  extensionStorage.set('progrssBackupReminder', marker);
  vm.runInThisContext(`volatileBackupReminder = ${JSON.stringify(marker)};`);
}

function message(type, data = {}) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timeout = setTimeout(() => { if (!settled) reject(new Error(`timeout: ${type}`)); }, 1500);
    const keep = listener({target: 'background', type, data}, {}, response => {
      settled = true;
      clearTimeout(timeout);
      resolve(response);
    });
    assert.strictEqual(keep, true, `${type} keeps response channel open`);
  });
}


const cases = [];
function test(name, fn) { cases.push([name, fn]); }
const snapshot = async () => JSON.stringify(await ProgRSSVault.init());
async function fixture(reason = 'Direct reason.', version = 1) {
  await message('get-state');
  const state = await ProgRSSVault.init();
  const member = {kind: 'source', id: 'one'};
  if (reason !== undefined) member.reason = reason;
  state.sources = ['one', 'two', 'three'].map(id => ({
    id, title: id, type: 'rss', url: `https://notes.example/${id}.xml`, enabled: false
  }));
  state.items = [];
  state.collections = [
    {id: 'parent', title: 'Parent', mode: 'union', version, members: [
      {kind: 'source', id: 'two'}, member, {kind: 'collection', id: 'child'}, {kind: 'source', id: 'three'}
    ]},
    {id: 'child', title: 'Child', mode: 'union', version: 1, members: [
      {kind: 'source', id: 'one', reason: 'Child reason.'}
    ]},
    {id: 'other', title: 'Other', mode: 'union', version: 1, members: [
      {kind: 'source', id: 'one', reason: 'Other reason.'}
    ]}
  ];
  await ProgRSSVault.save(state);
  return ProgRSSVault.init();
}
const folder = (state, id='parent') => state.collections.find(c => c.id === id);
async function remove(collectionId='parent', sourceId='one') {
  const response = await message('remove-source-from-folder', {sourceId, collectionId});
  assert.strictEqual(response.ok, true, response.error);
  assert.strictEqual(response.result.removed, true);
  return response.result;
}
function undoPayload(removed) {
  return {sourceId: removed.sourceId, collectionId: removed.collectionId,
    expectedVersion: removed.folderVersion, expectedRevision: removed.expectedRevision,
    removedMember: removed.removedMember, removedIndex: removed.removedIndex};
}
async function undo(removed) {
  const response = await message('undo-source-folder-remove', undoPayload(removed));
  assert.strictEqual(response.ok, true, response.error);
  assert.strictEqual(response.result.added, true);
  return ProgRSSVault.init();
}
async function refuse(payload, code) {
  const before = await snapshot();
  const response = await message('undo-source-folder-remove', payload);
  assert.strictEqual(response.ok, false, 'invalid or stale undo must be refused');
  assert.strictEqual(response.code, code);
  assert.strictEqual(await snapshot(), before, 'refusal must not alter persisted state');
}

test('direct placement restores reason despite inherited membership', async () => {
  const before = await fixture();
  const removed = await remove();
  assert.strictEqual(removed.removedMember.reason, 'Direct reason.');
  assert.strictEqual(removed.removedIndex, 1);
  assert(removed.membership.inherited.some(row => row.id === 'parent'));
  const after = await undo(removed);
  assert.deepStrictEqual(folder(after).members, folder(before).members);
  assert.deepStrictEqual(folder(after,'child'), folder(before,'child'));
  assert.deepStrictEqual(folder(after,'other'), folder(before,'other'));
});
test('child removal undo preserves independent parent and other reasons', async () => {
  const before = await fixture();
  const after = await undo(await remove('child'));
  assert.deepStrictEqual(folder(after,'child').members, folder(before,'child').members);
  assert.deepStrictEqual(folder(after), folder(before));
  assert.deepStrictEqual(folder(after,'other'), folder(before,'other'));
});
test('first middle and last placement positions round-trip', async () => {
  for (const id of ['two', 'one', 'three']) {
    const before = await fixture();
    const after = await undo(await remove('parent', id));
    assert.deepStrictEqual(folder(after).members, folder(before).members);
  }
});
test('absent reason stays absent', async () => {
  await fixture(null);
  const state = await ProgRSSVault.init(); delete folder(state).members[1].reason;
  await ProgRSSVault.save(state);
  const removed = await remove();
  assert(!Object.hasOwn(removed.removedMember, 'reason'));
  assert(!Object.hasOwn(folder(await undo(removed)).members[1], 'reason'));
});
test('empty reason is canonically omitted', async () => {
  await fixture(' \t\r\n');
  const removed = await remove();
  assert(!Object.hasOwn(removed.removedMember, 'reason'));
  assert(!Object.hasOwn(folder(await undo(removed)).members[1], 'reason'));
});
test('280 astral code points survive undo', async () => {
  const reason = '😀'.repeat(280);
  await fixture(reason);
  assert.strictEqual(folder(await undo(await remove())).members[1].reason, reason);
});
test('plain text and internal line breaks survive verbatim', async () => {
  const reason = '<b>Not markup</b> & "quoted"\nSecond line.';
  await fixture(reason);
  assert.strictEqual(folder(await undo(await remove())).members[1].reason, reason);
});
test('missing removal metadata is refused', async () => {
  await fixture(); const payload = undoPayload(await remove()); delete payload.removedMember;
  await refuse(payload, 'INVALID_FOLDER_UNDO');
});
test('mismatched source or member kind and extra fields are refused', async () => {
  await fixture(); const payload = undoPayload(await remove());
  for (const removedMember of [null, [], {kind:'source',id:'two'},
    {kind:'collection',id:'one'}, {...payload.removedMember, arbitrary:'field'}]) {
    await refuse({...payload, removedMember}, 'INVALID_FOLDER_UNDO');
  }
});
test('missing negative fractional string and out-of-range positions are refused', async () => {
  await fixture(); const payload = undoPayload(await remove());
  for (const removedIndex of [undefined, -1, 0.5, '1', 1000]) {
    await refuse({...payload, removedIndex}, 'INVALID_FOLDER_UNDO');
  }
});
test('overlong invalid-scalar and non-string reasons are refused', async () => {
  await fixture(); const payload = undoPayload(await remove());
  for (const reason of ['😀'.repeat(281), '\ud800', 12, {}]) {
    await refuse({...payload, removedMember: {...payload.removedMember, reason}}, 'INVALID_SOURCE_NOTE');
  }
});
test('same-folder newer edit refuses undo without overwriting it', async () => {
  await fixture(); const removed = await remove();
  const edit = await message('set-source-placement-reason', {sourceId:'two',collectionId:'parent',
    expectedVersion:removed.folderVersion,expectedReason:null,reason:'Newer wording.'});
  assert(edit.ok, edit.error);
  await refuse(undoPayload(removed), 'STALE_FOLDER_UNDO');
});
test('ordinary unrelated-folder edits do not prevent guarded undo', async () => {
  await fixture(); const removed = await remove();
  const edit = await message('set-source-placement-reason', {sourceId:'one',collectionId:'other',
    expectedVersion:1,expectedReason:'Other reason.',reason:'Other updated.'});
  assert(edit.ok, edit.error);
  const after = await undo(removed);
  assert.strictEqual(folder(after).members[1].reason,'Direct reason.');
  assert.strictEqual(folder(after,'other').members[0].reason,'Other updated.');
});
test('replay after successful undo is refused', async () => {
  await fixture(); const removed = await remove(); await undo(removed);
  await refuse(undoPayload(removed), 'STALE_FOLDER_UNDO');
});
test('newly re-added direct reason is not overwritten', async () => {
  await fixture(); const removed = await remove('child');
  const add = await message('add-source-to-folder', {sourceId:'one',collectionId:'child'});
  assert(add.ok && add.result.added);
  const edit = await message('set-source-placement-reason', {sourceId:'one',collectionId:'child',
    expectedVersion:add.result.folderVersion,expectedReason:null,reason:'New reason.'});
  assert(edit.ok, edit.error);
  await refuse(undoPayload(removed), 'STALE_FOLDER_UNDO');
});
test('source removal or archive refuses stale undo', async () => {
  for (const archived of [false, true]) {
    await fixture(); const removed = await remove();
    const state = await ProgRSSVault.init();
    if (archived) state.sources[0].archivedAt = '2026-10-21T00:00:00.000Z';
    else state.sources = state.sources.filter(s => s.id !== 'one');
    await ProgRSSVault.save(state);
    await refuse(undoPayload(removed), 'STALE_FOLDER_UNDO');
  }
});
test('saturated folder version restores only with exact vault revision', async () => {
  await fixture('Direct reason.', 9999); const removed = await remove();
  assert.strictEqual(removed.folderVersion, 10000);
  const payload = undoPayload(removed); delete payload.expectedRevision;
  await refuse(payload, 'STALE_FOLDER_UNDO');
  assert.strictEqual(folder(await undo(removed)).members[1].reason,'Direct reason.');
});
test('saturated version still refuses a subsequent same-folder edit', async () => {
  await fixture('Direct reason.',10000); const removed = await remove();
  const edit = await message('set-source-placement-reason', {sourceId:'two',collectionId:'parent',
    expectedVersion:10000,expectedReason:null,reason:'Newer at cap.'});
  assert(edit.ok, edit.error);
  await refuse(undoPayload(removed), 'STALE_FOLDER_UNDO');
});
test('saturated version conservatively refuses unrelated intervening writes', async () => {
  await fixture('Direct reason.',10000); const removed = await remove();
  const edit = await message('set-source-placement-reason', {sourceId:'one',collectionId:'other',
    expectedVersion:1,expectedReason:'Other reason.',reason:'Other at cap.'});
  assert(edit.ok, edit.error);
  await refuse(undoPayload(removed), 'STALE_FOLDER_UNDO');
});
test('restored native export includes reason under integrity', async () => {
  await fixture(); await undo(await remove());
  const exported = await message('export-shared-folder', {collectionId:'parent',format:'native',curator:'Undo test'});
  assert(exported.ok,exported.error);
  const native = JSON.parse(exported.result.raw);
  const checked = await ProgRSSSharedFolder.validate(native);
  assert.strictEqual(folder(checked.bundle).members.find(m=>m.id==='one').reason,'Direct reason.');
  native.collections.find(c=>c.id==='parent').members.find(m=>m.id==='one').reason='Tampered';
  await assert.rejects(()=>ProgRSSSharedFolder.validate(native), /digest does not match/);
});
test('side-panel removal and undo forward complete ephemeral relationship', async () => {
  await fixture();
  const code = fs.readFileSync(path.join(ROOT,'sidepanel/app.js'),'utf8');
  const start = code.indexOf('  async function removeSourceFromFolder(');
  const end = code.indexOf('  function sourceNotePlacementKey(',start);
  assert(start>=0 && end>start);
  let armed = null; const requests=[];
  const app = {folderUndo:null};
  const ctx = {app, els:{undoFolderChange:{}}, clearTimeout(){},
    text:value=>value, readableList:rows=>rows.join(', '),
    async loadState(){}, renderFolderUndo(){}, setStatus(){},
    armFolderUndo(value){ armed=value;app.folderUndo=value; },
    async request(type,data){ requests.push({type,data});const response=await message(type,data);
      if (!response.ok) throw new Error(response.error);return response.result; }
  };
  vm.createContext(ctx); vm.runInContext(code.slice(start,end),ctx);
  await ctx.removeSourceFromFolder({id:'one',title:'One'},'parent',{textContent:'Remove',disabled:false});
  assert(armed, 'side panel armed undo');
  assert.strictEqual(armed.removedMember.reason,'Direct reason.');
  assert.strictEqual(armed.removedIndex,1);
  assert(Number.isSafeInteger(armed.expectedRevision));
  await ctx.undoFolderChange();
  assert.strictEqual(requests[1].type,'undo-source-folder-remove');
  assert.deepStrictEqual(requests[1].data.removedMember,armed.removedMember);
  assert.strictEqual(requests[1].data.removedIndex,1);
  assert.strictEqual(folder(await ProgRSSVault.init()).members[1].reason,'Direct reason.');
  assert.strictEqual(app.folderUndo,null);
});
test('no network requests are made by the entire undo corpus', async () => {
  assert.strictEqual(fetchCalls.length,0);
});



test('REPRO parent accepts a stale editor after placement replacement at version ceiling', async () => {
  await fixture('Parent reason.', 1);
  let state = await ProgRSSVault.init();
  const target = folder(state, 'other');
  target.version = 10000;
  target.members[0].reason = 'Reviewed reason.';
  await ProgRSSVault.save(state);
  const reviewed = await ProgRSSVault.init();
  const reviewedRevision = reviewed._revision;

  let response = await message('remove-source-from-folder', {sourceId:'one', collectionId:'other'});
  assert(response.ok && response.result.removed, response.error);
  response = await message('add-source-to-folder', {sourceId:'one', collectionId:'other'});
  assert(response.ok && response.result.added, response.error);
  response = await message('set-source-placement-reason', {
    sourceId:'one', collectionId:'other', expectedVersion:10000,
    expectedReason:null, reason:'Reviewed reason.'
  });
  assert(response.ok && response.result.changed, response.error);

  response = await message('set-source-placement-reason', {
    sourceId:'one', collectionId:'other', expectedVersion:10000,
    expectedRevision:reviewedRevision,
    expectedReason:'Reviewed reason.', reason:'Stale editor value.'
  });
  assert.strictEqual(response.ok, true, response.error);
  const after = await ProgRSSVault.init();
  assert.strictEqual(folder(after, 'other').members[0].reason, 'Stale editor value.');
  console.log(JSON.stringify({reproduction:'stale-editor-replacement-at-cap', accepted:true,
    reviewedRevision, committedRevision:after._revision, finalReason:folder(after,'other').members[0].reason}));
});

test('REPRO parent accepts stale undo against a replacement placement at version ceiling', async () => {
  await fixture('Parent reason.', 1);
  let state = await ProgRSSVault.init();
  const target = folder(state, 'other');
  target.version = 10000;
  target.members[0].reason = 'Before edit.';
  await ProgRSSVault.save(state);
  const beforeEdit = await ProgRSSVault.init();

  let response = await message('set-source-placement-reason', {
    sourceId:'one', collectionId:'other', expectedVersion:10000,
    expectedRevision:beforeEdit._revision,
    expectedReason:'Before edit.', reason:'Edited value.'
  });
  assert(response.ok && response.result.changed, response.error);
  const editRevision = (await ProgRSSVault.init())._revision;

  response = await message('remove-source-from-folder', {sourceId:'one', collectionId:'other'});
  assert(response.ok && response.result.removed, response.error);
  response = await message('add-source-to-folder', {sourceId:'one', collectionId:'other'});
  assert(response.ok && response.result.added, response.error);
  response = await message('set-source-placement-reason', {
    sourceId:'one', collectionId:'other', expectedVersion:10000,
    expectedReason:null, reason:'Edited value.'
  });
  assert(response.ok && response.result.changed, response.error);

  response = await message('undo-source-placement-reason', {
    sourceId:'one', collectionId:'other', expectedVersion:10000,
    expectedRevision:editRevision,
    expectedCurrentReason:'Edited value.', previousReason:'Before edit.'
  });
  assert.strictEqual(response.ok, true, response.error);
  const after = await ProgRSSVault.init();
  assert.strictEqual(folder(after, 'other').members[0].reason, 'Before edit.');
  console.log(JSON.stringify({reproduction:'stale-undo-replacement-at-cap', accepted:true,
    editRevision, committedRevision:after._revision, finalReason:folder(after,'other').members[0].reason}));
});

(async () => {
  let failures=0;
  for (const [name, fn] of cases) {
    try { await fn(); console.log(`PASS ${name}`); }
    catch (error) { failures++;console.error(`FAIL ${name}\n${error.stack}`); }
  }
  console.log(JSON.stringify({suite:'source-notes-folder-undo',family:FAMILY,cases:cases.length,
    passed:cases.length-failures,failed:failures,installedBrowserRuntime:false}));
  if(failures)process.exitCode=1;
})().catch(error=>{console.error(error);process.exitCode=1;});
