# Research notes — rev0093

Checked 2026-10-21 against primary project/browser sources.

- Chrome extension service workers may terminate after inactivity, and Chrome explicitly advises persisting state rather than relying on globals. The rev0093 guard therefore comes from the persisted vault revision returned with the public library snapshot, not an in-memory generation token: https://developer.chrome.com/docs/extensions/develop/concepts/service-workers/lifecycle
- Chrome for Testing's official channel payload identified Stable 156.0.8078.47 at the checked snapshot: https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json
- Mozilla product details identified Firefox Release 158.0.1 and Firefox ESR 153.5.1esr at the checked snapshot: https://product-details.mozilla.org/1.0/firefox_versions.json
- Firefox temporary installation ends at restart and does not reproduce every signed-install behavior, including installation-time permission requests: https://extensionworkshop.com/documentation/develop/temporary-installation-in-firefox/

These references inform lifecycle and target-host boundaries. They do not establish that any current browser executed this candidate.
