# rev0095 research notes

Accessed 2026-10-21.

- Chrome for Developers, “The extension service worker lifecycle”: extension service workers are short-lived; state needed across service-worker lifetimes belongs in persistent storage. This supports using the persisted vault revision already exposed by the native state rather than a process-global generation token. It does not itself prove the application-level stale-action guard.
- Chrome for Testing availability: Stable was listed as 156.0.8078.47 when checked. This remains a planning reference only; each target host must capture fresh channel evidence.
- Mozilla product-details `firefox_versions.json`: Firefox Release was 158.0.1 and ESR was 153.5.1esr when checked. These remain planning references only.

Design inference: serializing background mutations prevents simultaneous writes but does not establish that a destructive click still refers to the relationship the person reviewed. The removal request therefore carries the displayed folder version and reason; at the saturated version ceiling it also carries the exact persisted vault revision. Below the ceiling, unrelated writes to other folders remain nonblocking.
