#!/usr/bin/env python3
from __future__ import annotations
import asyncio, importlib.util, json, os, shutil
from pathlib import Path
from playwright.async_api import async_playwright

WORK = Path('/mnt/data/rev0102-work')
PARENT = Path('/mnt/data/rev0102-parent-repro')
OUT = WORK / 'evidence/rev0102'

spec = importlib.util.spec_from_file_location('focused_harness', WORK / 'CLI/tests/source_notes_node_merge_review_harness.py')
mod = importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(mod)
bundle, response, conflicts = mod.build_review(WORK)
payload = mod.minimal_payload(); payload['mergeResponse'] = response
payload_json = json.dumps(payload, ensure_ascii=False)

async def main():
    async with async_playwright() as pw:
        executable = os.environ.get('PROGRSS_CHROMIUM') or shutil.which('chromium') or shutil.which('chromium-browser') or shutil.which('google-chrome')
        opts={'headless':True,'args':['--no-sandbox','--allow-file-access-from-files']}
        if executable: opts['executable_path']=executable
        browser=await pw.chromium.launch(**opts)
        try:
            page=await browser.new_page(viewport={'width':1180,'height':900})
            html=(PARENT/'CLI/node_web/index.html').read_text()
            html=html.replace('<link rel="stylesheet" href="app.css">','').replace('<script src="app.js"></script>','')
            await page.set_content(html,wait_until='domcontentloaded')
            await page.add_style_tag(content=(PARENT/'CLI/node_web/app.css').read_text())
            await page.evaluate(f"""(() => {{
              const payload={payload_json}; const local=new Map(); const session=new Map([['progrss-node-token','focused-token']]);
              Object.defineProperty(window,'localStorage',{{value:{{getItem:k=>local.get(String(k))??null,setItem:(k,v)=>local.set(String(k),String(v)),removeItem:k=>local.delete(String(k))}},configurable:true}});
              Object.defineProperty(window,'sessionStorage',{{value:{{getItem:k=>session.get(String(k))??null,setItem:(k,v)=>session.set(String(k),String(v)),removeItem:k=>session.delete(String(k))}},configurable:true}});
              history.replaceState=()=>{{}};
              globalThis.fetch=async(path,options={{}})=>{{ const route=String(path), method=String(options.method||'GET').toUpperCase(); let body;
                if(route.endsWith('/status')) body=payload.status; else if(route.endsWith('/library')) body=payload.library;
                else if(route.endsWith('/pairings')) body=payload.pairings; else if(route.endsWith('/curation')) body=payload.curation;
                else if(route.endsWith('/exchanges')) body=payload.exchanges; else if(route.endsWith('/operations')) body=payload.operations;
                else if(route.endsWith('/acquisitions')) body=payload.acquisitions; else if(route.endsWith('/merge-reviews')&&method==='POST') body=payload.mergeResponse;
                else body={{error:'unexpected route '+route}}; return new Response(JSON.stringify(body),{{status:body.error?404:200,headers:{{'Content-Type':'application/json'}}}}); }};
            }})()""")
            await page.add_script_tag(content=(PARENT/'CLI/node_web/app.js').read_text())
            await page.wait_for_function("document.querySelector('#status').textContent.includes('Local exported backup ready')")
            await page.locator('[data-view="curate"]').click()
            await page.locator('#merge-file').set_input_files({'name':'later.json','mimeType':'application/json','buffer':json.dumps(bundle,ensure_ascii=False).encode()})
            await page.locator('#review-merge').click(); await page.wait_for_function("document.querySelector('#merge-result').hidden === false")
            text=await page.locator('#merge-result').inner_text()
            observations={
              'sourceNoteClassCards': await page.locator('.merge-entry.source-note').count(),
              'northFullRouteVisible': 'Civic route › North › Updates' in text,
              'southFullRouteVisible': 'Civic route › South › Updates' in text,
              'keepMineLabelVisible': 'Keep mine' in text,
              'useCuratorLabelVisible': 'Use curator’s' in text,
              'curatorBoundaryVisible': 'Curator’s reason for this folder' in text,
              'nonSafetyBoundaryVisible': 'not a ProgRSS safety claim' in text,
              'multilineNorthPreserved': 'North accepted reason.\nSecond accepted line.' in text,
              'apiConflictFolderPaths': sorted(row['folderPath'] for row in conflicts),
            }
            await page.locator('#merge-result').screenshot(path=str(OUT/'parent-node-merge-before-fix.png'))
            (OUT/'parent-node-merge-before-fix.json').write_text(json.dumps(observations,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
            print(json.dumps(observations,ensure_ascii=False,sort_keys=True))
        finally: await browser.close()
asyncio.run(main())
