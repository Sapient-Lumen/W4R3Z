# rev0098 research notes

- OPML 2.0 permits outline attributes but does not define a shared ProgRSS Source Notes meaning. The candidate therefore keeps native JSON authoritative and reports OPML omission rather than inventing a private interoperability contract. Source: https://opml.org/spec2.opml
- W3C internationalization guidance recommends `dir="auto"` for runtime-provided text whose direction is not known in advance. The generated page applies it to each curator reason. Source: https://www.w3.org/International/questions/qa-html-dir.en.html
- Chrome for Testing Stable planning reference on 2026-10-21: 156.0.8078.47. Source: https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json
- Mozilla product-details planning references on 2026-10-21: Firefox Release 158.0.1 and ESR 153.5.1esr. These must be recaptured on actual execution hosts.
- Mozilla temporary add-on loading ends at restart and is not equivalent to signed end-user installation or installation-time permission evidence. Source: https://extensionworkshop.com/documentation/develop/temporary-installation-in-firefox/
