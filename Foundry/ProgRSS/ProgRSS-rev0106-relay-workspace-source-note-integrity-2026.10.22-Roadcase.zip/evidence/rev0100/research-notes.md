# rev0100 research notes

- W3C Internationalization guidance recommends `dir="auto"` when the direction of user-authored text
  is unknown until runtime. The Node preview applies it to the reason value, not the surrounding UI label.
  Source: https://www.w3.org/International/questions/qa-html-dir.en.html
- Mozilla documents temporary extension loading as a development path that ends at restart and differs
  from signed end-user installation. Runtime and installation-prompt conclusions remain separate.
  Source: https://extensionworkshop.com/documentation/develop/temporary-installation-in-firefox/
