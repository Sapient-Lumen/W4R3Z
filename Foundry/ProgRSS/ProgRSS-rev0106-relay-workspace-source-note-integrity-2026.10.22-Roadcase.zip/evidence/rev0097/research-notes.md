# rev0097 research notes

Captured 2026-10-21.

- Git's official merge documentation describes a three-way merge and stops for explicit conflict resolution when both sides cannot be reconciled automatically. ProgRSS uses this only as a conservative design analogy: Source Note divergence remains unresolved until the recipient explicitly selects **Keep mine** or **Use curator’s**. ProgRSS does not use Git's merge engine.
- Chrome's official extension messaging documentation continues to describe ordinary one-time messages as JSON-serializable. The rev0097 decisions therefore remain plain strings in plain objects; the correction does not depend on Map, Set, DOM objects, or opt-in structured-clone messaging.
- Mozilla's WebExtensions documentation continues to document runtime messaging as extension-local messaging. Chromium-source and generated-Firefox product bytes are tested separately and compared where they are intentionally shared.
- Official Chrome for Testing availability reported Stable 156.0.8078.47 at capture. This is a planning reference only; target-host sessions must capture fresh channel evidence.

Sources reviewed:

- https://git-scm.com/docs/git-merge
- https://git-scm.com/docs/merge-strategies
- https://developer.chrome.com/docs/extensions/develop/concepts/messaging
- https://developer.mozilla.org/en-US/docs/Mozilla/Add-ons/WebExtensions/API/runtime/sendMessage
- https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions-with-downloads.json
