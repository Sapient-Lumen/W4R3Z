'use strict';

if (typeof importScripts === 'function') {
  importScripts('shared/core.js', 'shared/shared-folder.js', 'shared/vault.js', 'shared/pulse.js', 'shared/scout.js', 'shared/parser.js', 'shared/capture.js');
}

const C = globalThis.ProgRSSCore;
const F = globalThis.ProgRSSSharedFolder;
const V = globalThis.ProgRSSVault;
const P = globalThis.ProgRSSPulse;
const S = globalThis.ProgRSSScout;
const R = globalThis.ProgRSSParser;
const Q = globalThis.ProgRSSCapture;
const MAX_BODY_BYTES = C.LIMIT.characters;
const OFFSCREEN_PATH = 'offscreen/index.html';
const MAX_BULK_REFRESH = 12;
const MAX_ACTIVE_IMPORT_ORIGINS = 20;
const MAX_REDIRECTS = 5;
const REDIRECT_EVENT_GRACE_MS = 120;
const PRIVATE_BACKUP_SCHEMA = 'progrss.private.v1';
const MAX_PRIVATE_BACKUP_BYTES = 24_000_000;
const MAX_EXCHANGE_FEED_BYTES = 2_000_000;
const TRANSFER_UNDO_MS = 30 * 60 * 1000;
const SOURCE_REPAIR_UNDO_MS = 30 * 60 * 1000;
const RECEIPT_RETIREMENT_UNDO_MS = 30 * 60 * 1000;
const SHARED_FOLDER_UPDATE_UNDO_MS = 30 * 60 * 1000;
const PAGE_WATCH_REPAIR_UNDO_MS = 30 * 60 * 1000;
const MAX_TEXT_CLEANUP_BYTES = 1_500_000;
const MAX_TEXT_CLEANUP_ITEMS = 240;
const STORAGE_INCIDENT_KEY = 'progrssStorageIncident';
const LIBRARY_PRESENCE_KEY = 'progrssLibraryPresence';
const LIBRARY_PRESENCE_SCHEMA = 'progrss.library.presence.v1';
const LIBRARY_RECOVERY_SCHEMA = 'progrss.library.recovery.v1';
const BACKUP_REMINDER_KEY = 'progrssBackupReminder';
const BACKUP_REMINDER_SCHEMA = 'progrss.backup-reminder.v3';
const BACKUP_REMINDER_PREVIOUS_SCHEMA = 'progrss.backup-reminder.v2';
const BACKUP_REMINDER_LEGACY_SCHEMA = 'progrss.backup-reminder.v1';
const BACKUP_FIRST_DELAY_MS = 7 * 24 * 60 * 60 * 1000;
const BACKUP_REPEAT_MS = 30 * 24 * 60 * 60 * 1000;
const BACKUP_RECHECK_MS = 90 * 24 * 60 * 60 * 1000;
const BACKUP_SNOOZE_MS = 30 * 24 * 60 * 60 * 1000;
const MAX_RETIRED_RECEIPTS = 64;
const GRAFT_RECEIPT_SCHEMA = 'progrss.recipe.graft.receipt.v1';
const RETIRED_GRAFT_RECEIPT_SCHEMA = 'progrss.retired.graft-receipt.v1';
const PRIVATE_ARRAY_LIMITS = Object.freeze({
  fixtures: 16, inbox: 24, receipts: 100, subscriptions: 12, publications: 24,
  patchPins: 96, keyRotations: 60, recoveryPolicies: 32, recoveryReceipts: 80,
  charterHistory: 160, charterClaims: 128, gossipCards: 128, witnessPins: 64,
  merklePins: 32, merkleReceipts: 96, proofRequests: 20, proofSightings: 80,
  proofForks: 24, fixturePacks: 12
});
const ADVANCED_REFERENCE_LABELS = Object.freeze({
  fixtures: 'Page repair fixtures', inbox: 'Exchange inbox', receipts: 'Receipts',
  subscriptions: 'Shared subscriptions', publications: 'Publication history',
  patchPins: 'Repair trust pins', keyRotations: 'Key rotation history',
  recoveryPolicies: 'Recovery policies', recoveryReceipts: 'Recovery receipts',
  charterHistory: 'Charter history', charterClaims: 'Charter claims',
  gossipCards: 'Exchange cards', witnessPins: 'Witness pins', merklePins: 'Merkle pins',
  merkleReceipts: 'Merkle receipts', proofRequests: 'Proof requests',
  proofSightings: 'Proof sightings', proofForks: 'Proof forks', fixturePacks: 'Fixture packs',
  snapshots: 'Attached snapshots'
});
const ADVANCED_EVIDENCE_KEYS = new Set(['receipts','publications','keyRotations','recoveryReceipts','charterHistory','merkleReceipts','proofSightings','proofForks','fixturePacks']);
const ADVANCED_TRUST_KEYS = new Set(['patchPins','recoveryPolicies','charterClaims','witnessPins','merklePins']);
const ADVANCED_EXCHANGE_KEYS = new Set(['inbox','subscriptions','gossipCards','proofRequests']);
const MAX_REFERENCE_HITS_PER_RECORD = 24;
const api = globalThis.browser || globalThis.chrome;
if (!api?.runtime) throw new Error('ProgRSS requires a WebExtensions runtime.');
const extensionRoot = api.runtime.getURL('/').replace(/\/+$/, '');
const activeAcquisitions = new Set();
let creatingOffscreen = null;
let mutationQueue = Promise.resolve();
let volatileStorageIncident = null;
let volatileLibraryPresence = null;
let volatileBackupReminder = null;
let libraryRecoveryState = null;
let lifecycleInstallReason = '';

function codedError(message, code = 'FAILED', detail = null) {
  const error = new Error(message);
  error.code = code;
  if (detail) error.detail = detail;
  return error;
}

function messageError(error, code = 'FAILED') {
  const result = {ok: false, error: String(error?.message || error || 'Unknown error').slice(0, 500), code};
  if (error?.detail && typeof error.detail === 'object') result.detail = error.detail;
  return result;
}

function storageFailureReason(error) {
  const explicit = C.text(error?.storageReason, 40).toLowerCase();
  if (['quota', 'io', 'aborted', 'unavailable', 'unknown'].includes(explicit)) return explicit;
  const name = String(error?.name || error?.storageName || '');
  const message = String(error?.message || error || '').toLowerCase();
  if (name === 'QuotaExceededError' || /quota|disk full|storage full|no space|out of space/.test(message)) return 'quota';
  if (name === 'NotReadableError' || name === 'UnknownError' || /\bi\/o\b|input\/output|disk error|write failed/.test(message)) return 'io';
  if (name === 'AbortError' || /transaction.*abort|write aborted/.test(message)) return 'aborted';
  if (name === 'InvalidStateError' || /storage.*unavailable|not available|closed unexpectedly/.test(message)) return 'unavailable';
  return 'unknown';
}

function storageFailureMessage(reason) {
  if (reason === 'quota') return 'Browser storage appears full or at its limit.';
  if (reason === 'io') return 'The browser reported a disk or storage write error.';
  if (reason === 'aborted') return 'The browser stopped the storage transaction before it completed.';
  if (reason === 'unavailable') return 'Browser storage is unavailable.';
  return 'The browser could not complete the storage write.';
}

function storageOperationLabel(kind) {
  const labels = {
    'item': 'Changing read or saved state',
    'mark-all': 'Marking updates read',
    'read-items': 'Marking updates read',
    'unread-items': 'Marking updates unread',
    'source-toggle': 'Changing a source',
    'source-archive': 'Archiving a source',
    'source-rename': 'Renaming a source',
    'source-added': 'Following a source',
    'source-restored': 'Restoring a source',
    'source-refreshed': 'Saving a source check',
    'source-redirect-recovered': 'Saving a source check',
    'source-redirect-changed': 'Saving an address move',
    'source-redirect-accepted': 'Saving an address move',
    'source-redirect-failed': 'Saving an address move problem',
    'source-folder-add': 'Adding a source to a folder',
    'source-folder-remove': 'Removing a source from a folder',
    'source-text-retention': 'Changing offline-reading text',
    'source-text-pruned': 'Clearing older feed text',
    'source-text-prune-undo': 'Restoring older feed text',
    'opml-import': 'Adding subscriptions',
    'shared-folder-import': 'Adding a shared folder',
    'private-backup-restored': 'Moving a library here',
    'private-backup-undo': 'Restoring the previous library',
    'same-source-repair': 'Combining source histories',
    'same-source-repair-undo': 'Restoring source histories',
    'graft-receipt-retired': 'Retiring a Workbench receipt',
    'graft-receipt-retirement-undone': 'Restoring a Workbench receipt',
    'permissions-removed': 'Saving a reconnect state',
    'storage-probe': 'Checking browser storage',
    'library-empty-accepted': 'Starting an empty library',
    'workbench-save': 'Saving Advanced Workbench changes'
  };
  return labels[kind] || 'Saving a ProgRSS change';
}

function validStorageIncident(value) {
  return Boolean(
    value && typeof value === 'object' && !Array.isArray(value) &&
    value.schema === 'progrss.storage.incident.v1' &&
    typeof value.occurredAt === 'string' && Number.isFinite(Date.parse(value.occurredAt)) &&
    ['quota', 'io', 'aborted', 'unavailable', 'unknown'].includes(value.reason)
  );
}

async function readStorageIncident() {
  if (validStorageIncident(volatileStorageIncident)) return {...volatileStorageIncident};
  try {
    const stored = await api.storage?.local?.get?.(STORAGE_INCIDENT_KEY);
    const value = stored?.[STORAGE_INCIDENT_KEY];
    if (validStorageIncident(value)) {
      volatileStorageIncident = value;
      return {...value};
    }
  } catch {}
  return null;
}

async function persistStorageIncident(incident) {
  volatileStorageIncident = incident;
  try { await api.storage?.local?.set?.({[STORAGE_INCIDENT_KEY]: incident}); } catch {}
}

async function clearStorageIncident() {
  volatileStorageIncident = null;
  try { await api.storage?.local?.remove?.(STORAGE_INCIDENT_KEY); } catch {}
}

async function recordStorageIncident(error, detail = {}) {
  let committed = null;
  try { committed = await V.init(); } catch {}
  const reason = storageFailureReason(error);
  const operationKind = C.text(detail.kind || detail.operationKind, 80) || 'save';
  const summary = committed ? transferSummary(committed) : null;
  const incident = {
    schema: 'progrss.storage.incident.v1',
    occurredAt: new Date().toISOString(),
    reason,
    operationKind,
    operation: storageOperationLabel(operationKind),
    message: storageFailureMessage(reason),
    vaultMode: C.text(V.info()?.mode, 40) || 'unknown',
    savedRevision: Number.isSafeInteger(committed?._revision) ? committed._revision : null,
    savedLibrary: summary ? {
      sources: summary.sources,
      items: summary.items,
      unread: summary.unread,
      saved: summary.saved
    } : null
  };
  await persistStorageIncident(incident);
  return incident;
}

async function reportStorageWriteFailure(payload = {}) {
  const error = Error(C.text(payload.message, 240) || 'Advanced Workbench storage write failed.');
  error.name = C.text(payload.name, 80) || 'Error';
  error.storageReason = C.text(payload.reason, 40);
  return recordStorageIncident(error, {kind: 'workbench-save'});
}

async function probeVaultWrite() {
  try {
    await V.probe();
    await clearStorageIncident();
    try { await api.runtime.sendMessage({type: 'progrss:state-changed', detail: {kind: 'storage-write-restored'}}); } catch {}
    return {
      available: true,
      mode: C.text(V.info()?.mode, 40) || 'unknown',
      note: 'A small test write succeeded. Repeat the action that failed; larger writes can still require more room.'
    };
  } catch (error) {
    const incident = await recordStorageIncident(error, {kind: 'storage-probe'});
    throw codedError(`${incident.message} The last saved library remains available.`, 'VAULT_WRITE_FAILED', {incident});
  }
}

function cleanLibrarySummary(value = {}) {
  const result = {};
  for (const key of ['sources', 'activeSources', 'pausedSources', 'archivedSources', 'movedSources', 'pageWatches', 'feeds', 'collections', 'items', 'unread', 'saved', 'snapshots', 'advancedRecords']) {
    const count = Number(value?.[key]);
    result[key] = Number.isSafeInteger(count) && count >= 0 ? Math.min(count, 1_000_000) : 0;
  }
  return result;
}

function validLibraryPresence(value) {
  return Boolean(
    value && typeof value === 'object' && !Array.isArray(value) &&
    value.schema === LIBRARY_PRESENCE_SCHEMA &&
    typeof value.installedAt === 'string' && Number.isFinite(Date.parse(value.installedAt)) &&
    typeof value.hadLibrary === 'boolean' &&
    Number.isSafeInteger(value.lastRevision) && value.lastRevision >= 0 &&
    value.lastLibrary && typeof value.lastLibrary === 'object' && !Array.isArray(value.lastLibrary)
  );
}

async function readLibraryPresence() {
  try {
    const stored = await api.storage?.local?.get?.(LIBRARY_PRESENCE_KEY);
    const value = stored?.[LIBRARY_PRESENCE_KEY];
    if (validLibraryPresence(value)) {
      volatileLibraryPresence = value;
      return {...value, lastLibrary: cleanLibrarySummary(value.lastLibrary)};
    }
  } catch {}
  return validLibraryPresence(volatileLibraryPresence)
    ? {...volatileLibraryPresence, lastLibrary: cleanLibrarySummary(volatileLibraryPresence.lastLibrary)}
    : null;
}

async function persistLibraryPresence(value) {
  const marker = {...value, lastLibrary: cleanLibrarySummary(value.lastLibrary)};
  volatileLibraryPresence = marker;
  try { await api.storage?.local?.set?.({[LIBRARY_PRESENCE_KEY]: marker}); } catch {}
  return marker;
}

function validReminderTime(value) {
  return typeof value === 'string' && Number.isFinite(Date.parse(value));
}

function validReminderRevision(value) {
  return Number.isSafeInteger(value) && value >= 0;
}

function validReminderFingerprint(value) {
  return value === '' || (typeof value === 'string' && /^[0-9a-f]{64}$/.test(value));
}

function newReminderFingerprintKey() {
  const bytes = new Uint8Array(32);
  globalThis.crypto.getRandomValues(bytes);
  return [...bytes].map(value => value.toString(16).padStart(2, '0')).join('');
}

function hexBytes(value) {
  const bytes = new Uint8Array(value.length / 2);
  for (let index = 0; index < bytes.length; index++) bytes[index] = Number.parseInt(value.slice(index * 2, index * 2 + 2), 16);
  return bytes;
}

async function portableBackupFingerprint(state, keyHex) {
  if (!/^[0-9a-f]{64}$/.test(String(keyHex || ''))) throw codedError('Private-copy marker key is unavailable.', 'BACKUP_MARKER_INVALID');
  const key = await globalThis.crypto.subtle.importKey(
    'raw', hexBytes(keyHex), {name: 'HMAC', hash: 'SHA-256'}, false, ['sign']
  );
  const bytes = new TextEncoder().encode(stableJson(portableVaultComparisonValue(state)));
  const signature = await globalThis.crypto.subtle.sign('HMAC', key, bytes);
  return [...new Uint8Array(signature)].map(value => value.toString(16).padStart(2, '0')).join('');
}

function validBackupReminder(value) {
  return Boolean(
    value && typeof value === 'object' && !Array.isArray(value) &&
    value.schema === BACKUP_REMINDER_SCHEMA &&
    typeof value.disabled === 'boolean' &&
    /^[0-9a-f]{64}$/.test(String(value.fingerprintKey || '')) &&
    (!value.firstMeaningfulAt || validReminderTime(value.firstMeaningfulAt)) &&
    (!value.lastPreparedAt || validReminderTime(value.lastPreparedAt)) &&
    (!value.lastCheckedAt || validReminderTime(value.lastCheckedAt)) &&
    (!value.lastSeenAt || validReminderTime(value.lastSeenAt)) &&
    (!value.missingSince || validReminderTime(value.missingSince)) &&
    (!value.snoozedUntil || validReminderTime(value.snoozedUntil)) &&
    validReminderRevision(value.lastPreparedRevision) &&
    validReminderRevision(value.lastCheckedRevision) &&
    validReminderFingerprint(value.lastPreparedFingerprint) &&
    validReminderFingerprint(value.lastCheckedFingerprint)
  );
}

function validPreviousBackupReminder(value) {
  return Boolean(
    value && typeof value === 'object' && !Array.isArray(value) &&
    value.schema === BACKUP_REMINDER_PREVIOUS_SCHEMA &&
    typeof value.disabled === 'boolean' &&
    (!value.firstMeaningfulAt || validReminderTime(value.firstMeaningfulAt)) &&
    (!value.lastPreparedAt || validReminderTime(value.lastPreparedAt)) &&
    (!value.lastCheckedAt || validReminderTime(value.lastCheckedAt)) &&
    (!value.snoozedUntil || validReminderTime(value.snoozedUntil)) &&
    validReminderRevision(value.lastPreparedRevision) &&
    validReminderRevision(value.lastCheckedRevision)
  );
}

function validLegacyBackupReminder(value) {
  return Boolean(
    value && typeof value === 'object' && !Array.isArray(value) &&
    value.schema === BACKUP_REMINDER_LEGACY_SCHEMA &&
    typeof value.disabled === 'boolean' &&
    (!value.firstMeaningfulAt || validReminderTime(value.firstMeaningfulAt)) &&
    (!value.lastCopyAt || validReminderTime(value.lastCopyAt)) &&
    (!value.snoozedUntil || validReminderTime(value.snoozedUntil)) &&
    validReminderRevision(value.lastCopyRevision)
  );
}

function newBackupReminder() {
  return {
    schema: BACKUP_REMINDER_SCHEMA,
    fingerprintKey: newReminderFingerprintKey(),
    firstMeaningfulAt: '',
    lastPreparedAt: '',
    lastPreparedRevision: 0,
    lastPreparedFingerprint: '',
    lastCheckedAt: '',
    lastCheckedRevision: 0,
    lastCheckedFingerprint: '',
    lastSeenAt: '',
    missingSince: '',
    snoozedUntil: '',
    disabled: false,
    updatedAt: new Date().toISOString()
  };
}

function migrateBackupReminder(value) {
  if (validBackupReminder(value)) return {...value};
  if (validPreviousBackupReminder(value)) {
    const marker = newBackupReminder();
    marker.firstMeaningfulAt = value.firstMeaningfulAt || '';
    marker.lastPreparedAt = value.lastPreparedAt || '';
    marker.lastPreparedRevision = value.lastPreparedRevision || 0;
    marker.lastCheckedAt = value.lastCheckedAt || '';
    marker.lastCheckedRevision = value.lastCheckedRevision || 0;
    marker.lastSeenAt = value.lastCheckedAt || '';
    marker.disabled = Boolean(value.disabled);
    marker.snoozedUntil = value.snoozedUntil || '';
    return marker;
  }
  if (!validLegacyBackupReminder(value)) return null;
  const marker = newBackupReminder();
  marker.firstMeaningfulAt = value.firstMeaningfulAt || '';
  marker.lastPreparedAt = value.lastCopyAt || '';
  marker.lastPreparedRevision = value.lastCopyRevision || 0;
  marker.disabled = Boolean(value.disabled);
  marker.snoozedUntil = value.snoozedUntil || '';
  // The oldest marker could only observe that a download was initiated. Preserve
  // its quiet 30-day interval after upgrading, but do not relabel it as a checked file.
  if (marker.lastPreparedAt && !marker.snoozedUntil) {
    const prepared = Date.parse(marker.lastPreparedAt);
    if (Number.isFinite(prepared)) marker.snoozedUntil = new Date(prepared + BACKUP_REPEAT_MS).toISOString();
  }
  return marker;
}

async function readBackupReminder() {
  const volatile = migrateBackupReminder(volatileBackupReminder);
  if (volatile) {
    if (volatileBackupReminder?.schema !== BACKUP_REMINDER_SCHEMA) {
      volatileBackupReminder = volatile;
      try { await api.storage?.local?.set?.({[BACKUP_REMINDER_KEY]: volatile}); } catch {}
    }
    return {...volatile};
  }
  try {
    const stored = await api.storage?.local?.get?.(BACKUP_REMINDER_KEY);
    const value = stored?.[BACKUP_REMINDER_KEY];
    const marker = migrateBackupReminder(value);
    if (marker) {
      volatileBackupReminder = marker;
      if (value?.schema !== BACKUP_REMINDER_SCHEMA) {
        try { await api.storage?.local?.set?.({[BACKUP_REMINDER_KEY]: marker}); } catch {}
      }
      return {...marker};
    }
  } catch {}
  return null;
}

async function persistBackupReminder(value) {
  const marker = validBackupReminder(value) ? {...value} : newBackupReminder();
  marker.updatedAt = new Date().toISOString();
  volatileBackupReminder = marker;
  try { await api.storage?.local?.set?.({[BACKUP_REMINDER_KEY]: marker}); } catch {}
  return marker;
}

function backupReminderState(marker, state) {
  const summary = cleanLibrarySummary(transferSummary(state));
  const meaningful = hasTransferContent(summary);
  const now = Date.now();
  const currentRevision = Number.isSafeInteger(state?._revision) ? state._revision : 0;
  const lastPreparedRevision = validReminderRevision(marker?.lastPreparedRevision) ? marker.lastPreparedRevision : 0;
  const lastCheckedRevision = validReminderRevision(marker?.lastCheckedRevision) ? marker.lastCheckedRevision : 0;
  const firstAt = Date.parse(marker?.firstMeaningfulAt || '') || 0;
  const lastPreparedAt = Date.parse(marker?.lastPreparedAt || '') || 0;
  const lastCheckedAt = Date.parse(marker?.lastCheckedAt || '') || 0;
  const lastSeenAt = Date.parse(marker?.lastSeenAt || marker?.lastCheckedAt || '') || 0;
  const missingSince = Date.parse(marker?.missingSince || '') || 0;
  const snoozedUntil = Date.parse(marker?.snoozedUntil || '') || 0;
  const pendingCheck = Boolean(meaningful && lastPreparedAt && (
    !lastSeenAt || lastPreparedAt > lastSeenAt ||
    Boolean(marker?.lastPreparedFingerprint && marker.lastPreparedFingerprint !== marker.lastCheckedFingerprint)
  ));
  const checkedCopyMissing = Boolean(meaningful && lastCheckedAt && missingSince);
  const changedSinceChecked = Boolean(meaningful && (!lastCheckedAt || currentRevision > lastCheckedRevision));
  const routineDueAt = lastCheckedAt
    ? lastCheckedAt + BACKUP_REPEAT_MS
    : firstAt ? firstAt + BACKUP_FIRST_DELAY_MS : 0;
  const recheckDueAt = meaningful && lastCheckedAt && !changedSinceChecked && !checkedCopyMissing
    ? (lastSeenAt || lastCheckedAt) + BACKUP_RECHECK_MS : 0;
  const dueAtMs = pendingCheck ? lastPreparedAt
    : checkedCopyMissing ? missingSince
    : changedSinceChecked ? routineDueAt
    : recheckDueAt;
  const reasonExists = pendingCheck || checkedCopyMissing || changedSinceChecked || Boolean(recheckDueAt);
  const due = Boolean(
    meaningful && !marker?.disabled && reasonExists && dueAtMs &&
    now >= dueAtMs && (!snoozedUntil || now >= snoozedUntil)
  );
  let status = 'empty';
  if (meaningful && marker?.disabled) status = 'disabled';
  else if (meaningful && pendingCheck) status = 'prepared-not-checked';
  else if (meaningful && checkedCopyMissing) status = 'copy-missing';
  else if (meaningful && !lastCheckedAt) status = 'no-checked-copy';
  else if (meaningful && changedSinceChecked) status = 'changed';
  else if (meaningful && recheckDueAt && now >= recheckDueAt) status = 'recheck';
  else if (meaningful) status = 'current';
  return {
    schema: BACKUP_REMINDER_SCHEMA,
    visible: libraryRecoveryState?.state !== 'missing' && due,
    meaningful,
    status,
    disabled: Boolean(marker?.disabled),
    pendingCheck,
    checkedCopyMissing,
    changedSinceChecked,
    recheckDue: Boolean(recheckDueAt && now >= recheckDueAt),
    firstMeaningfulAt: validReminderTime(marker?.firstMeaningfulAt) ? marker.firstMeaningfulAt : '',
    lastPreparedAt: validReminderTime(marker?.lastPreparedAt) ? marker.lastPreparedAt : '',
    lastPreparedRevision,
    lastCheckedAt: validReminderTime(marker?.lastCheckedAt) ? marker.lastCheckedAt : '',
    lastCheckedRevision,
    lastSeenAt: validReminderTime(marker?.lastSeenAt) ? marker.lastSeenAt : '',
    missingSince: validReminderTime(marker?.missingSince) ? marker.missingSince : '',
    snoozedUntil: validReminderTime(marker?.snoozedUntil) ? marker.snoozedUntil : '',
    dueAt: dueAtMs ? new Date(dueAtMs).toISOString() : '',
    currentRevision,
    reminderDays: Math.round(BACKUP_REPEAT_MS / 86400000),
    recheckDays: Math.round(BACKUP_RECHECK_MS / 86400000),
    network: false,
    writesVault: false
  };
}

async function reconcileBackupReminder(state) {
  let marker = await readBackupReminder();
  if (!marker) marker = newBackupReminder();
  if (libraryRecoveryState?.state === 'missing') return backupReminderState(marker, state);
  const meaningful = hasTransferContent(cleanLibrarySummary(transferSummary(state)));
  const before = JSON.stringify(marker);
  if (meaningful) {
    if (!validReminderTime(marker.firstMeaningfulAt)) marker.firstMeaningfulAt = new Date().toISOString();
  } else {
    marker.firstMeaningfulAt = '';
    marker.lastPreparedAt = '';
    marker.lastPreparedRevision = 0;
    marker.lastPreparedFingerprint = '';
    marker.lastCheckedAt = '';
    marker.lastCheckedRevision = 0;
    marker.lastCheckedFingerprint = '';
    marker.lastSeenAt = '';
    marker.missingSince = '';
    marker.snoozedUntil = '';
  }
  if (before !== JSON.stringify(marker)) marker = await persistBackupReminder(marker);
  return backupReminderState(marker, state);
}

async function notePreparedCopy(state) {
  let marker = await readBackupReminder();
  if (!marker) marker = newBackupReminder();
  const now = new Date().toISOString();
  if (hasTransferContent(cleanLibrarySummary(transferSummary(state))) && !validReminderTime(marker.firstMeaningfulAt)) {
    marker.firstMeaningfulAt = now;
  }
  marker.lastPreparedAt = now;
  marker.lastPreparedRevision = Number.isSafeInteger(state?._revision) ? state._revision : 0;
  marker.lastPreparedFingerprint = await portableBackupFingerprint(state, marker.fingerprintKey);
  marker.snoozedUntil = '';
  marker = await persistBackupReminder(marker);
  return backupReminderState(marker, state);
}

async function noteCheckedCopy(state, fingerprint, revision = null) {
  let marker = await readBackupReminder();
  if (!marker) marker = newBackupReminder();
  const now = new Date().toISOString();
  const checkedRevision = validReminderRevision(revision) ? revision : (Number.isSafeInteger(state?._revision) ? state._revision : 0);
  const checkedFingerprint = validReminderFingerprint(fingerprint) && fingerprint
    ? fingerprint : await portableBackupFingerprint(state, marker.fingerprintKey);
  if (hasTransferContent(cleanLibrarySummary(transferSummary(state))) && !validReminderTime(marker.firstMeaningfulAt)) {
    marker.firstMeaningfulAt = now;
  }
  marker.lastCheckedAt = now;
  marker.lastCheckedRevision = checkedRevision;
  marker.lastCheckedFingerprint = checkedFingerprint;
  marker.lastSeenAt = now;
  marker.missingSince = '';
  marker.snoozedUntil = '';
  marker = await persistBackupReminder(marker);
  return backupReminderState(marker, state);
}

async function noteKnownCopySeen(state, relationship, fingerprint) {
  let marker = await readBackupReminder();
  if (!marker) marker = newBackupReminder();
  const now = new Date().toISOString();
  if (relationship === 'last-prepared') {
    marker.lastCheckedAt = now;
    marker.lastCheckedRevision = marker.lastPreparedRevision;
    marker.lastCheckedFingerprint = fingerprint;
  } else if (relationship !== 'last-checked') {
    throw codedError('That file is not the recorded private copy.', 'BACKUP_COPY_NOT_RECOGNIZED');
  }
  marker.lastSeenAt = now;
  marker.missingSince = '';
  marker.snoozedUntil = '';
  marker = await persistBackupReminder(marker);
  return backupReminderState(marker, state);
}

async function markBackupCopyMissing() {
  const state = await loadState();
  assertLibraryWritable('backup-reminder');
  let marker = await readBackupReminder();
  if (!marker) marker = newBackupReminder();
  if (!validReminderTime(marker.lastCheckedAt)) throw codedError('No checked private copy is recorded yet.', 'NO_CHECKED_COPY');
  marker.missingSince = new Date().toISOString();
  marker.snoozedUntil = '';
  marker = await persistBackupReminder(marker);
  return backupReminderState(marker, state);
}

async function setBackupReminderChoice(choice) {
  const state = await loadState();
  assertLibraryWritable('backup-reminder');
  let marker = await readBackupReminder();
  if (!marker) marker = newBackupReminder();
  if (choice === 'snooze') {
    marker.disabled = false;
    marker.snoozedUntil = new Date(Date.now() + BACKUP_SNOOZE_MS).toISOString();
  } else if (choice === 'disable') {
    marker.disabled = true;
    marker.snoozedUntil = '';
  } else if (choice === 'enable') {
    marker.disabled = false;
    marker.snoozedUntil = '';
  } else {
    throw codedError('Choose a supported private-copy reminder action.', 'INVALID_REMINDER_CHOICE');
  }
  marker = await persistBackupReminder(marker);
  return backupReminderState(marker, state);
}

function normalizedInstallReason(value) {
  const reason = C.text(value, 40).toLowerCase();
  return ['install', 'update', 'chrome_update', 'browser_update', 'shared_module_update'].includes(reason) ? reason : 'unknown';
}

function newLibraryPresence({reason = lifecycleInstallReason || 'unknown'} = {}) {
  const now = new Date().toISOString();
  const version = String(api.runtime.getManifest?.()?.version || '0.80.0');
  return {
    schema: LIBRARY_PRESENCE_SCHEMA,
    installedAt: now,
    installReason: normalizedInstallReason(reason),
    firstVersion: version,
    lastVersion: version,
    lastSeenAt: now,
    lastCommittedAt: '',
    lastRevision: 0,
    hadLibrary: false,
    lastLibrary: cleanLibrarySummary(),
    recovery: null
  };
}

async function noteExtensionLifecycle(details = {}) {
  lifecycleInstallReason = normalizedInstallReason(details.reason);
  const current = await readLibraryPresence();
  const marker = current || newLibraryPresence({reason: lifecycleInstallReason});
  marker.lastVersion = String(api.runtime.getManifest?.()?.version || '0.80.0');
  marker.lastLifecycleReason = lifecycleInstallReason;
  marker.lastLifecycleAt = new Date().toISOString();
  await persistLibraryPresence(marker);
}

function libraryRecoveryFromMarker(marker, state = null) {
  if (!marker?.recovery || marker.recovery.state !== 'missing') return {
    schema: LIBRARY_RECOVERY_SCHEMA,
    state: marker?.hadLibrary ? 'present' : (marker?.installReason === 'install' ? 'fresh' : 'empty')
  };
  return {
    schema: LIBRARY_RECOVERY_SCHEMA,
    state: 'missing',
    reason: C.text(marker.recovery.reason, 60) || 'vault-missing',
    detectedAt: C.text(marker.recovery.detectedAt, 80),
    lastCommittedAt: C.text(marker.lastCommittedAt, 80),
    lastRevision: Number.isSafeInteger(marker.lastRevision) ? marker.lastRevision : 0,
    currentRevision: Number.isSafeInteger(state?._revision) ? state._revision : Number(marker.recovery.currentRevision) || 0,
    lastKnown: cleanLibrarySummary(marker.lastLibrary),
    canRestoreFile: true,
    canUseEmptyLibrary: true,
    network: false
  };
}

function libraryLossReason(marker, state, summary, info) {
  if (!marker?.hadLibrary || hasTransferContent(summary)) return '';
  if (info?.mode !== 'indexeddb' && info?.mode !== 'localStorage') return '';
  if (info?.initialRecordValid === false || info?.recordValid === false) return 'vault-unreadable';
  if (info?.openedWithoutRecord || info?.initialRecordExists === false) return 'vault-missing';
  if (Number.isSafeInteger(marker.lastRevision) && marker.lastRevision > Number(state?._revision || 0)) return 'vault-reset';
  if (Number.isSafeInteger(marker.lastRevision) && marker.lastRevision === Number(state?._revision || 0) && hasTransferContent(marker.lastLibrary)) return 'vault-emptied';
  return '';
}

async function reconcileLibraryPresence(state) {
  let marker = await readLibraryPresence();
  if (!marker) marker = newLibraryPresence();
  const summary = cleanLibrarySummary(transferSummary(state));
  const hasContent = hasTransferContent(summary);
  const info = V.info() || {};
  const now = new Date().toISOString();

  if (hasContent) {
    const changed = !marker.hadLibrary || marker.lastRevision !== state._revision || marker.recovery || JSON.stringify(cleanLibrarySummary(marker.lastLibrary)) !== JSON.stringify(summary);
    marker.hadLibrary = true;
    marker.lastRevision = Number.isSafeInteger(state._revision) ? state._revision : marker.lastRevision;
    marker.lastLibrary = summary;
    marker.lastSeenAt = now;
    marker.lastVersion = String(api.runtime.getManifest?.()?.version || '0.80.0');
    marker.recovery = null;
    if (changed) await persistLibraryPresence(marker);
    libraryRecoveryState = libraryRecoveryFromMarker(marker, state);
    return libraryRecoveryState;
  }

  if (marker.recovery?.state === 'missing') {
    libraryRecoveryState = libraryRecoveryFromMarker(marker, state);
    return libraryRecoveryState;
  }

  const reason = libraryLossReason(marker, state, summary, info);
  if (reason) {
    marker.recovery = {
      state: 'missing',
      reason,
      detectedAt: now,
      currentRevision: Number.isSafeInteger(state?._revision) ? state._revision : 0
    };
    marker.lastSeenAt = now;
    await persistLibraryPresence(marker);
    libraryRecoveryState = libraryRecoveryFromMarker(marker, state);
    return libraryRecoveryState;
  }

  const changed = marker.hadLibrary || marker.lastRevision !== state._revision || marker.recovery || JSON.stringify(cleanLibrarySummary(marker.lastLibrary)) !== JSON.stringify(summary);
  marker.hadLibrary = false;
  marker.lastRevision = Number.isSafeInteger(state._revision) ? state._revision : marker.lastRevision;
  marker.lastLibrary = summary;
  marker.lastSeenAt = now;
  marker.lastVersion = String(api.runtime.getManifest?.()?.version || '0.80.0');
  marker.recovery = null;
  if (changed) await persistLibraryPresence(marker);
  libraryRecoveryState = libraryRecoveryFromMarker(marker, state);
  return libraryRecoveryState;
}

async function noteCommittedLibrary(state) {
  const current = await readLibraryPresence();
  const marker = current || newLibraryPresence();
  const summary = cleanLibrarySummary(transferSummary(state));
  const now = new Date().toISOString();
  marker.hadLibrary = hasTransferContent(summary);
  marker.lastLibrary = summary;
  marker.lastRevision = Number.isSafeInteger(state?._revision) ? state._revision : 0;
  marker.lastCommittedAt = now;
  marker.lastSeenAt = now;
  marker.lastVersion = String(api.runtime.getManifest?.()?.version || '0.80.0');
  marker.recovery = null;
  await persistLibraryPresence(marker);
  libraryRecoveryState = libraryRecoveryFromMarker(marker, state);
  await reconcileBackupReminder(state);
  return libraryRecoveryState;
}

function assertLibraryWritable(kind = '') {
  if (libraryRecoveryState?.state !== 'missing') return;
  if (['private-backup-restored', 'library-empty-accepted'].includes(kind)) return;
  throw codedError(
    'This browser remembers an earlier ProgRSS library, but its local vault is empty or unreadable. Restore a private file or choose Use empty library before saving new work.',
    'LIBRARY_RECOVERY_REQUIRED',
    {libraryRecovery: libraryRecoveryState}
  );
}

async function acceptEmptyLibrary() {
  return queueMutation(async () => {
    const state = await loadState();
    if (libraryRecoveryState?.state !== 'missing') return {accepted: false, summary: transferSummary(state), libraryRecovery: libraryRecoveryState};
    if (hasTransferContent(transferSummary(state))) throw codedError('The local vault is no longer empty. Reload before choosing a new start.', 'LIBRARY_RECOVERY_STALE');
    await saveAndBroadcast(state, {kind: 'library-empty-accepted'});
    return {accepted: true, summary: transferSummary(state), libraryRecovery: libraryRecoveryState};
  });
}

async function assertWorkbenchWritable() {
  await loadState();
  assertLibraryWritable('workbench-save');
  return {allowed: true};
}

async function noteWorkbenchCommit() {
  const state = await V.init();
  await reconcileLibraryPresence(state);
  assertLibraryWritable('workbench-save');
  await noteCommittedLibrary(state);
  await clearStorageIncident();
  await updateBadge(state);
  try { await api.runtime.sendMessage({type: 'progrss:state-changed', detail: {kind: 'workbench-save'}}); } catch {}
  return {recorded: true, revision: state._revision};
}

function isOwnExtensionInitiator(value) {
  if (!value || value === 'null') return true;
  const candidate = String(value).replace(/\/+$/, '');
  return candidate === extensionRoot || candidate.startsWith(`${extensionRoot}/`);
}

function originPattern(raw) {
  const url = new URL(C.safeUrl(raw));
  return `${url.origin}/*`;
}

async function hasOriginPermission(raw) {
  return api.permissions.contains({origins: [originPattern(raw)]});
}

function permissionPatternCoversOrigin(pattern, origin) {
  if (pattern === '<all_urls>') return true;
  try {
    const parsed = new URL(String(pattern).replace(/\*+$/, ''));
    return parsed.origin === origin;
  } catch {
    const escaped = String(pattern).replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*');
    return new RegExp(`^${escaped}$`).test(`${origin}/*`);
  }
}

function registerAcquisition(url, controller) {
  const entry = {origin: new URL(url).origin, controller, reason: ''};
  activeAcquisitions.add(entry);
  return entry;
}

function unregisterAcquisition(entry) {
  activeAcquisitions.delete(entry);
}

function redirectDetail(from, to, status, chain = []) {
  const source = new URL(C.safeUrl(from));
  const destination = new URL(C.safeUrl(to, from));
  return {
    from: source.href,
    to: destination.href,
    status: Number(status) || 0,
    sourceOrigin: source.origin,
    destinationOrigin: destination.origin,
    sourceHost: source.host.replace(/^www\./, ''),
    destinationHost: destination.host.replace(/^www\./, ''),
    chain: Array.isArray(chain) ? chain.slice(0, MAX_REDIRECTS) : []
  };
}

function redirectSignal(detail) {
  return codedError('The address redirected.', 'REDIRECT', detail);
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function canParseInBackground() {
  return Boolean(R?.handle && typeof globalThis.DOMParser === 'function');
}

async function ensureOffscreen() {
  if (!api.offscreen?.createDocument) return false;
  const documentUrl = api.runtime.getURL(OFFSCREEN_PATH);
  if (api.runtime.getContexts) {
    const contexts = await api.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
      documentUrls: [documentUrl]
    });
    if (contexts.length) return true;
  }
  if (creatingOffscreen) { await creatingOffscreen; return true; }
  creatingOffscreen = api.offscreen.createDocument({
    url: OFFSCREEN_PATH,
    reasons: ['DOM_PARSER'],
    justification: 'Parse RSS, Atom, JSON Feed and watched-page snapshots without opening a visible tab.'
  }).finally(() => { creatingOffscreen = null; });
  await creatingOffscreen;
  return true;
}

async function parserCall(type, data) {
  if (canParseInBackground()) return R.handle(type, data || {});
  if (!(await ensureOffscreen())) {
    throw codedError('This browser cannot provide ProgRSS with a safe document parser.', 'PARSER_UNAVAILABLE');
  }
  const response = await api.runtime.sendMessage({target: 'offscreen', type, data});
  if (!response?.ok) throw codedError(response?.error || 'The parser did not respond.', response?.code || 'FAILED', response?.detail || null);
  return response.result;
}

function validEtag(value) {
  return typeof value === 'string' && value.length <= 200 && /^(?:W\/)?"[\x21\x23-\x7e]{0,190}"$/.test(value);
}

function validHttpDate(value) {
  return typeof value === 'string' && value.length <= 80 && /^[A-Za-z]{3}, [0-9]{2} [A-Za-z]{3} [0-9]{4} [0-9]{2}:[0-9]{2}:[0-9]{2} GMT$/.test(value);
}

function conditionalHeaders(validators = {}, accept = 'application/vnd.progrss.shared-folder+json, application/rss+xml, application/atom+xml, application/feed+json, application/json, text/xml, text/html;q=0.9, */*;q=0.2') {
  const headers = {Accept: String(accept || '*/*').slice(0, 500)};
  if (validEtag(validators.etag)) headers['If-None-Match'] = validators.etag;
  if (validHttpDate(validators.lastModified)) headers['If-Modified-Since'] = validators.lastModified;
  return headers;
}

function updatedHttpCache(response, previous = {}) {
  const keepPrevious = [304, 429, 503].includes(response.status);
  return {
    etag: validEtag(response.etag) ? response.etag : (keepPrevious && validEtag(previous.etag) ? previous.etag : ''),
    lastModified: validHttpDate(response.lastModified) ? response.lastModified : (keepPrevious && validHttpDate(previous.lastModified) ? previous.lastModified : '')
  };
}

function charsetFromContentType(contentType) {
  const match = String(contentType || '').match(/(?:^|;)\s*charset\s*=\s*(?:"([^"]+)"|'([^']+)'|([^;\s]+))/i);
  return (match?.[1] || match?.[2] || match?.[3] || '').trim().toLowerCase();
}

function charsetFromXmlPrefix(bytes) {
  if (bytes.length >= 4) {
    if (bytes[0] === 0x00 && bytes[1] === 0x3c && bytes[2] === 0x00 && bytes[3] === 0x3f) return 'utf-16be';
    if (bytes[0] === 0x3c && bytes[1] === 0x00 && bytes[2] === 0x3f && bytes[3] === 0x00) return 'utf-16le';
  }
  const prefix = Array.from(bytes.slice(0, 512), value => String.fromCharCode(value)).join('');
  const match = prefix.match(/^\s*<\?xml[^>]*\bencoding\s*=\s*["']\s*([^"']+)\s*["']/i);
  return (match?.[1] || '').trim().toLowerCase();
}

function normalizeCharset(label) {
  const clean = String(label || '').trim().toLowerCase().replace(/_/g, '-');
  const aliases = new Map([
    ['', 'utf-8'], ['utf8', 'utf-8'], ['utf-8', 'utf-8'], ['unicode-1-1-utf-8', 'utf-8'],
    ['ascii', 'utf-8'], ['us-ascii', 'utf-8'],
    ['utf-16', 'utf-16le'], ['utf-16le', 'utf-16le'], ['utf-16be', 'utf-16be'],
    ['latin1', 'windows-1252'], ['latin-1', 'windows-1252'], ['iso-8859-1', 'windows-1252'],
    ['windows-1252', 'windows-1252'], ['cp1252', 'windows-1252']
  ]);
  return aliases.get(clean) || '';
}

function decodeResource(bytes, contentType = '') {
  let label = '';
  if (bytes.length >= 3 && bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) label = 'utf-8';
  else if (bytes.length >= 2 && bytes[0] === 0xff && bytes[1] === 0xfe) label = 'utf-16le';
  else if (bytes.length >= 2 && bytes[0] === 0xfe && bytes[1] === 0xff) label = 'utf-16be';
  else label = charsetFromContentType(contentType) || charsetFromXmlPrefix(bytes) || 'utf-8';
  const encoding = normalizeCharset(label);
  if (!encoding) throw codedError(`The site uses an unsupported text encoding (${String(label).slice(0, 80)}).`, 'UNSUPPORTED_ENCODING');
  try {
    return {text: new TextDecoder(encoding, {fatal: true}).decode(bytes), encoding};
  } catch {
    throw codedError(`The response is not valid ${encoding.toUpperCase()} text.`, 'INVALID_ENCODING');
  }
}

async function readLimitedBytes(response, acquisition, maxBytes = MAX_BODY_BYTES) {
  const limit = Number.isSafeInteger(maxBytes) && maxBytes > 0 ? Math.min(MAX_BODY_BYTES, maxBytes) : MAX_BODY_BYTES;
  const limitLabel = limit === MAX_BODY_BYTES ? '2 MB' : `${Math.round(limit / 1000)} KB`;
  const declared = Number(response.headers.get('Content-Length') || 0);
  if (Number.isFinite(declared) && declared > limit) throw codedError(`The response is larger than the ${limitLabel} safety limit.`, 'BODY_TOO_LARGE');
  if (!response.body?.getReader) {
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (bytes.byteLength > limit) throw codedError(`The response is larger than the ${limitLabel} safety limit.`, 'BODY_TOO_LARGE');
    return bytes;
  }
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  while (true) {
    if (acquisition.reason === 'permission-removed') throw codedError('Site access was removed while ProgRSS was reading this address.', 'PERMISSION_REMOVED');
    const {done, value} = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > limit) {
      await reader.cancel();
      throw codedError(`The response is larger than the ${limitLabel} safety limit.`, 'BODY_TOO_LARGE');
    }
    chunks.push(value);
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
  return bytes;
}

async function fetchOne(url, validators, controller, accept) {
  let captured = null;
  let resolveRedirect;
  const redirectSeen = new Promise(resolve => { resolveRedirect = resolve; });
  const capture = (details, explicitTarget = '') => {
    if (captured) return;
    let observed;
    try { observed = C.safeUrl(details.url); } catch { return; }
    if (observed !== url) return;
    if (!isOwnExtensionInitiator(details.initiator)) return;
    let target = explicitTarget;
    if (!target && Array.isArray(details.responseHeaders)) {
      const location = details.responseHeaders.find(header => String(header?.name || '').toLowerCase() === 'location');
      target = location?.value || '';
    }
    if (!target) return;
    try {
      captured = redirectDetail(url, target, details.statusCode);
      resolveRedirect(captured);
    } catch {}
  };
  const beforeRedirect = details => capture(details, details.redirectUrl);
  const headersReceived = details => {
    if (Number(details.statusCode) >= 300 && Number(details.statusCode) < 400) capture(details);
  };
  const filter = {urls: [originPattern(url)], types: ['xmlhttprequest', 'other']};
  const redirectEvent = api.webRequest?.onBeforeRedirect;
  const headersEvent = api.webRequest?.onHeadersReceived;
  if (redirectEvent?.addListener) redirectEvent.addListener(beforeRedirect, filter);
  if (headersEvent?.addListener) headersEvent.addListener(headersReceived, filter, ['responseHeaders']);
  try {
    return await fetch(url, {
      method: 'GET',
      credentials: 'omit',
      redirect: 'error',
      referrerPolicy: 'no-referrer',
      cache: 'no-store',
      signal: controller.signal,
      headers: conditionalHeaders(validators, accept)
    });
  } catch (error) {
    const hasObserver = Boolean(redirectEvent?.addListener || headersEvent?.addListener);
    const hint = captured || (hasObserver ? await Promise.race([redirectSeen, wait(REDIRECT_EVENT_GRACE_MS).then(() => null)]) : null);
    if (hint) throw redirectSignal(hint);
    throw error;
  } finally {
    try { redirectEvent?.removeListener?.(beforeRedirect); } catch {}
    try { headersEvent?.removeListener?.(headersReceived); } catch {}
  }
}

async function fetchResource(rawUrl, validators = {}, options = {}) {
  const requestedUrl = C.safeUrl(rawUrl);
  const maxBytes = Number.isSafeInteger(options.maxBytes) && options.maxBytes > 0 ? Math.min(MAX_BODY_BYTES, options.maxBytes) : MAX_BODY_BYTES;
  const accept = C.text(options.accept, 500) || undefined;
  if (!(await hasOriginPermission(requestedUrl))) {
    throw codedError('Site access is needed before ProgRSS can read this address.', 'PERMISSION_REQUIRED');
  }
  const controller = new AbortController();
  const acquisition = registerAcquisition(requestedUrl, controller);
  const timer = setTimeout(() => {
    acquisition.reason = 'timeout';
    controller.abort();
  }, 20_000);
  const chain = [];
  const visited = new Set([requestedUrl]);
  let url = requestedUrl;
  try {
    for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
      let response;
      try {
        response = await fetchOne(url, validators, controller, accept);
      } catch (error) {
        if (error?.code !== 'REDIRECT') throw error;
        const hopRow = {from: url, to: C.safeUrl(error.detail?.to, url), status: Number(error.detail?.status) || 0};
        const detail = redirectDetail(url, hopRow.to, hopRow.status, [...chain, hopRow]);
        if (detail.destinationOrigin !== detail.sourceOrigin) {
          throw codedError(`This address moved from ${detail.sourceHost} to ${detail.destinationHost}. Review the move before ProgRSS contacts the new site.`, 'CROSS_ORIGIN_REDIRECT', detail);
        }
        if (visited.has(detail.to)) throw codedError('The site redirected in a loop.', 'REDIRECT_LOOP', detail);
        if (chain.length >= MAX_REDIRECTS) throw codedError(`The site redirected more than ${MAX_REDIRECTS} times.`, 'TOO_MANY_REDIRECTS', detail);
        chain.push(hopRow);
        visited.add(detail.to);
        url = detail.to;
        continue;
      }
      const meta = {
        requestedUrl,
        url: response.url || url,
        status: response.status,
        contentType: response.headers.get('Content-Type') || '',
        cacheControl: response.headers.get('Cache-Control') || '',
        retryAfter: response.headers.get('Retry-After') || '',
        linkHeader: response.headers.get('Link') || '',
        etag: response.headers.get('ETag') || '',
        lastModified: response.headers.get('Last-Modified') || '',
        redirects: chain.slice()
      };
      if (response.status === 304 || response.status === 429 || response.status === 503) return {...meta, body: '', encoding: ''};
      if (!response.ok) throw codedError(`HTTP ${response.status}`, 'HTTP_ERROR', {status: response.status, url: meta.url});
      const bytes = await readLimitedBytes(response, acquisition, maxBytes);
      const decoded = decodeResource(bytes, meta.contentType);
      return {...meta, body: decoded.text, encoding: decoded.encoding};
    }
    throw codedError(`The site redirected more than ${MAX_REDIRECTS} times.`, 'TOO_MANY_REDIRECTS');
  } catch (error) {
    if (acquisition.reason === 'permission-removed') throw codedError('Site access was removed while ProgRSS was reading this address.', 'PERMISSION_REMOVED');
    if (error?.name === 'AbortError' || acquisition.reason === 'timeout') throw codedError('The site did not respond within 20 seconds.', 'TIMEOUT');
    throw error;
  } finally {
    clearTimeout(timer);
    unregisterAcquisition(acquisition);
  }
}

function portableVaultState(state) {
  const result = {...state};
  result.sources = Array.isArray(state.sources) ? state.sources.map(source => {
    const portable = source && typeof source === 'object' && !Array.isArray(source) ? {...source} : source;
    if (portable && typeof portable === 'object') delete portable.watchStability;
    return portable;
  }) : [];
  delete result._revision;
  delete result.transferUndo;
  delete result.sourceRepairUndo;
  delete result.receiptRetirementUndo;
  delete result.sharedFolderUpdateUndo;
  delete result.pageWatchRepairUndo;
  return result;
}

function stableJson(value) {
  if (value === null || typeof value === 'boolean' || typeof value === 'string' || typeof value === 'number') {
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) return `[${value.map(row => row === undefined ? 'null' : stableJson(row)).join(',')}]`;
  if (value && typeof value === 'object') {
    const rows = [];
    for (const key of Object.keys(value).sort()) {
      if (value[key] === undefined) continue;
      rows.push(`${JSON.stringify(key)}:${stableJson(value[key])}`);
    }
    return `{${rows.join(',')}}`;
  }
  return 'null';
}

function portableVaultComparisonValue(state) {
  // JSON round-tripping gives the comparison the same omission/null behavior as
  // the private transfer file itself before object keys are sorted.
  return JSON.parse(JSON.stringify(portableVaultState(state)));
}

function privateCopyChangedAreas(first, second) {
  const labels = {
    sources: 'sources', collections: 'folders', items: 'updates', snapshots: 'page-watch snapshots',
    retiredReceipts: 'retired evidence'
  };
  const keys = ['sources', 'collections', 'items', 'snapshots', ...Object.keys(PRIVATE_ARRAY_LIMITS), 'retiredReceipts'];
  return keys.filter(key => stableJson(first?.[key] ?? (key === 'snapshots' ? {} : [])) !== stableJson(second?.[key] ?? (key === 'snapshots' ? {} : [])))
    .map(key => labels[key] || 'Advanced Workbench records')
    .filter((label, index, rows) => rows.indexOf(label) === index);
}

function privateArrayCount(state) {
  const active = Object.keys(PRIVATE_ARRAY_LIMITS).reduce((total, key) => total + (Array.isArray(state[key]) ? state[key].length : 0), 0);
  return active + (Array.isArray(state.retiredReceipts) ? state.retiredReceipts.length : 0);
}

function privateSourceNoteAudit(state, knownSourceIds = null) {
  const errors = [];
  const sourceIds = knownSourceIds || new Set(
    (Array.isArray(state?.sources) ? state.sources : [])
      .filter(source => source && typeof source === 'object' && !Array.isArray(source))
      .map(source => C.text(source.id, 300))
      .filter(Boolean)
  );
  let count = 0;
  for (const [collectionIndex, collection] of (Array.isArray(state?.collections) ? state.collections : []).entries()) {
    if (!collection || typeof collection !== 'object' || Array.isArray(collection)) continue;
    const folderId = C.text(collection.id, 300) || String(collectionIndex + 1);
    if (Object.hasOwn(collection, 'reason')) {
      errors.push(`Collection ${folderId} carries a Source Note on the folder instead of one direct source placement.`);
    }
    const seen = new Map();
    for (const [memberIndex, member] of (Array.isArray(collection.members) ? collection.members : []).entries()) {
      if (!member || typeof member !== 'object' || Array.isArray(member)) continue;
      const kind = member.kind;
      const memberId = C.text(member.id, 300);
      const hasReason = Object.hasOwn(member, 'reason');
      const key = memberId ? `${String(kind || '')}:${memberId}` : '';
      if (key) {
        const previousHadReason = seen.get(key);
        if (previousHadReason !== undefined && (previousHadReason || hasReason)) {
          errors.push(`Collection ${folderId} repeats placement ${kind}:${memberId}; a reason-bearing direct relationship must appear exactly once.`);
        }
        seen.set(key, Boolean(previousHadReason || hasReason));
      }
      if (!hasReason) continue;
      if (kind !== 'source') {
        errors.push(`Collection ${folderId} member ${memberIndex + 1} carries a Source Note on something other than a direct source placement.`);
        continue;
      }
      if (!memberId) {
        errors.push(`Collection ${folderId} member ${memberIndex + 1} has a Source Note but no source identity.`);
        continue;
      }
      if (!sourceIds.has(memberId)) {
        errors.push(`Collection ${folderId} gives missing source ${memberId} a Source Note.`);
        continue;
      }
      let normalized;
      try { normalized = C.normalizeSourceNoteReason(member.reason); }
      catch (error) {
        errors.push(`Collection ${folderId} placement source:${memberId} has an invalid Source Note: ${error.message || error}.`);
        continue;
      }
      if (normalized === undefined) {
        errors.push(`Collection ${folderId} placement source:${memberId} has an empty Source Note; omit the field instead.`);
        continue;
      }
      if (member.reason !== normalized) {
        errors.push(`Collection ${folderId} placement source:${memberId} has a noncanonical Source Note; remove leading or trailing ASCII whitespace.`);
        continue;
      }
      count += 1;
    }
  }
  return {count, errors};
}

function transferSummary(state) {
  const sources = Array.isArray(state.sources) ? state.sources.filter(row => row && typeof row === 'object') : [];
  const items = Array.isArray(state.items) ? state.items.filter(row => row && typeof row === 'object') : [];
  const active = sources.filter(source => source.enabled && !source.archivedAt);
  const sourceNotes = privateSourceNoteAudit(state, new Set(sources.map(source => C.text(source.id, 300)).filter(Boolean))).count;
  return {
    sources: sources.length,
    activeSources: active.length,
    pausedSources: sources.filter(source => !source.enabled && !source.archivedAt).length,
    archivedSources: sources.filter(source => source.archivedAt).length,
    movedSources: active.filter(source => source.pendingRedirect).length,
    pageWatches: sources.filter(source => source.type === 'page').length,
    feeds: sources.filter(source => source.type === 'rss').length,
    collections: Array.isArray(state.collections) ? state.collections.length : 0,
    sourceNotes,
    items: items.length,
    unread: items.filter(item => !item.readAt).length,
    saved: items.filter(item => item.starred).length,
    snapshots: state.snapshots && typeof state.snapshots === 'object' && !Array.isArray(state.snapshots) ? Object.keys(state.snapshots).length : 0,
    advancedRecords: privateArrayCount(state)
  };
}

function hasTransferContent(summary) {
  return ['sources', 'collections', 'items', 'snapshots', 'advancedRecords'].some(key => Number(summary?.[key]) > 0);
}

function validTransferUndo(undo, now = Date.now()) {
  return Boolean(
    undo && typeof undo === 'object' && !Array.isArray(undo) &&
    undo.schema === 'progrss.transfer.undo.v1' &&
    undo.previousState && typeof undo.previousState === 'object' && !Array.isArray(undo.previousState) &&
    Number.isFinite(Date.parse(undo.expiresAt || '')) && Date.parse(undo.expiresAt) > now
  );
}

function transferUndoInfo(state) {
  const undo = state.transferUndo;
  if (!validTransferUndo(undo)) return {undoAvailable: false};
  return {
    undoAvailable: true,
    createdAt: String(undo.createdAt || ''),
    expiresAt: String(undo.expiresAt || ''),
    previous: undo.previousSummary && typeof undo.previousSummary === 'object' ? undo.previousSummary : transferSummary(undo.previousState)
  };
}

function byteLength(raw) {
  return new TextEncoder().encode(String(raw || '')).byteLength;
}

function validPageChange(change) {
  if (!change || typeof change !== 'object' || Array.isArray(change) || change.schema !== C.PAGE_CHANGE_SCHEMA) return false;
  const allowed = new Set(['schema', 'kind', 'mode', 'summary', 'before', 'after', 'removed', 'added', 'removedWords', 'addedWords', 'delta', 'threshold', 'ignoreNumbers']);
  if (Object.keys(change).some(key => !allowed.has(key))) return false;
  if (!['entry-added', 'entry-changed', 'entry-removed', 'text-changed'].includes(change.kind)) return false;
  if (!['cards', 'region'].includes(change.mode)) return false;
  for (const [key, limit] of [['summary', 500], ['before', 1200], ['after', 1200], ['removed', 1000], ['added', 1000]]) {
    if (change[key] !== undefined && (typeof change[key] !== 'string' || change[key].length > limit)) return false;
  }
  for (const [key, maximum] of [['removedWords', 20_000], ['addedWords', 20_000], ['delta', 1_000_000], ['threshold', 120_000]]) {
    if (change[key] !== undefined && (!Number.isFinite(Number(change[key])) || Number(change[key]) < 0 || Number(change[key]) > maximum)) return false;
  }
  if (change.ignoreNumbers !== undefined && typeof change.ignoreNumbers !== 'boolean') return false;
  return ['summary', 'before', 'after', 'removed', 'added'].some(key => typeof change[key] === 'string' && change[key].trim());
}

function transferAudit(state) {
  const errors = [];
  const warnings = [];
  const sourceIds = new Set();
  const itemIds = new Set();
  const collectionIds = new Set();
  for (const [index, source] of (state.sources || []).entries()) {
    if (!source || typeof source !== 'object' || Array.isArray(source)) { errors.push(`Source ${index + 1} is not a record.`); continue; }
    const id = C.text(source.id, 300);
    if (!id) errors.push(`Source ${index + 1} has no identity.`);
    else if (sourceIds.has(id)) errors.push(`Two sources use the identity ${id}.`);
    else sourceIds.add(id);
    try { C.safeUrl(source.url); } catch { errors.push(`Source ${id || index + 1} has an unsafe or unreadable address.`); }
    if (!['rss', 'page'].includes(source.type)) warnings.push(`Source ${id || index + 1} has an unfamiliar type.`);
    if (source.textRetention !== undefined && source.textRetention !== 'summary') errors.push(`Source ${id || index + 1} has an invalid offline-text choice.`);
  }
  for (const [index, collection] of (state.collections || []).entries()) {
    if (!collection || typeof collection !== 'object' || Array.isArray(collection)) { errors.push(`Collection ${index + 1} is not a record.`); continue; }
    const id = C.text(collection.id, 300);
    if (!id) errors.push(`Collection ${index + 1} has no identity.`);
    else if (collectionIds.has(id)) errors.push(`Two collections use the identity ${id}.`);
    else collectionIds.add(id);
    if (collection.sharedFolderOrigin !== undefined) {
      try { F.normalizeOrigin(collection.sharedFolderOrigin, true); }
      catch { errors.push(`Collection ${id || index + 1} has an invalid shared-folder origin record.`); }
    }
  }
  const sourceNoteAudit = privateSourceNoteAudit(state, sourceIds);
  errors.push(...sourceNoteAudit.errors);
  for (const [index, item] of (state.items || []).entries()) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) { errors.push(`Update ${index + 1} is not a record.`); continue; }
    const id = C.text(item.id, 700);
    if (!id) errors.push(`Update ${index + 1} has no identity.`);
    else if (itemIds.has(id)) errors.push(`Two updates use the identity ${id}.`);
    else itemIds.add(id);
    const sourceId = C.text(item.sourceId, 300);
    if (!sourceId || !sourceIds.has(sourceId)) warnings.push(`Update ${id || index + 1} refers to a source that is not present.`);
    if (item.body !== undefined && (typeof item.body !== 'string' || item.body.length > C.LIMIT.body)) errors.push(`Update ${id || index + 1} has invalid or oversized feed text.`);
    if (item.bodyIsSummary !== undefined && typeof item.bodyIsSummary !== 'boolean') errors.push(`Update ${id || index + 1} has an invalid feed-text kind.`);
    if (item.bodyOmitted !== undefined && typeof item.bodyOmitted !== 'boolean') errors.push(`Update ${id || index + 1} has an invalid offline-text marker.`);
    if (item.change !== undefined && !validPageChange(item.change)) errors.push(`Update ${id || index + 1} has an invalid page-change explanation.`);
  }
  return {state: errors.length ? 'invalid' : (warnings.length ? 'needs-review' : 'valid'), errors: errors.slice(0, 30), warnings: warnings.slice(0, 30)};
}

async function parsePrivateBackup(raw) {
  if (typeof raw !== 'string' || !raw.trim()) throw codedError('Choose a ProgRSS private transfer file.', 'INVALID_BACKUP');
  if (byteLength(raw) > MAX_PRIVATE_BACKUP_BYTES) throw codedError('That file is larger than the 24 MB transfer limit.', 'BACKUP_TOO_LARGE');
  let document;
  try { document = JSON.parse(raw); } catch { throw codedError('That file is not readable JSON.', 'INVALID_BACKUP'); }
  if (!document || typeof document !== 'object' || Array.isArray(document) || document.schema !== PRIVATE_BACKUP_SCHEMA || !document.state || typeof document.state !== 'object' || Array.isArray(document.state)) {
    throw codedError('That is not a ProgRSS private transfer file.', 'INVALID_BACKUP');
  }
  const incoming = document.state;
  if (![2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17].includes(incoming.version)) throw codedError('This ProgRSS vault version is not supported.', 'UNSUPPORTED_BACKUP');
  for (const [key, limit] of [['sources', C.LIMIT.source], ['collections', C.LIMIT.collection], ['items', C.LIMIT.items]]) {
    if (!Array.isArray(incoming[key])) throw codedError(`The transfer file is missing its ${key} list.`, 'INVALID_BACKUP');
    if (incoming[key].length > limit) throw codedError(`The transfer file contains too many ${key}.`, 'INVALID_BACKUP');
  }
  if (incoming.snapshots != null && (typeof incoming.snapshots !== 'object' || Array.isArray(incoming.snapshots))) throw codedError('The transfer file has an invalid snapshot record.', 'INVALID_BACKUP');
  if (Object.keys(incoming.snapshots || {}).length > C.LIMIT.source) throw codedError('The transfer file contains too many page-watch snapshots.', 'INVALID_BACKUP');
  for (const [key, limit] of Object.entries(PRIVATE_ARRAY_LIMITS)) {
    if (incoming[key] == null) continue;
    if (!Array.isArray(incoming[key])) throw codedError(`The transfer file has an invalid ${key} record.`, 'INVALID_BACKUP');
    if (incoming[key].length > limit) throw codedError(`The transfer file contains too many ${key} records.`, 'INVALID_BACKUP');
  }
  if (incoming.retiredReceipts != null && !Array.isArray(incoming.retiredReceipts)) throw codedError('The transfer file has an invalid retired receipt archive.', 'INVALID_BACKUP');
  if ((incoming.retiredReceipts || []).length > MAX_RETIRED_RECEIPTS) throw codedError('The transfer file contains too many retired receipts.', 'INVALID_BACKUP');
  const retiredDigests = new Set();
  for (const [index, envelope] of (incoming.retiredReceipts || []).entries()) {
    const valid = envelope && typeof envelope === 'object' && !Array.isArray(envelope) &&
      envelope.schema === RETIRED_GRAFT_RECEIPT_SCHEMA && C.text(envelope.id, 220) &&
      /^[0-9a-f]{64}$/.test(C.text(envelope.originalDigest, 64)) &&
      envelope.originalReceipt && typeof envelope.originalReceipt === 'object' && !Array.isArray(envelope.originalReceipt) &&
      envelope.originalReceipt.schema === GRAFT_RECEIPT_SCHEMA;
    if (!valid) throw codedError(`Retired receipt ${index + 1} is not a supported preserved graft receipt.`, 'INVALID_BACKUP');
    const digest = await canonicalDigest(envelope.originalReceipt);
    if (digest !== envelope.originalDigest) throw codedError(`Retired receipt ${index + 1} no longer matches its preserved digest.`, 'INVALID_BACKUP');
    if (retiredDigests.has(digest)) throw codedError('The transfer file repeats the same retired receipt evidence.', 'INVALID_BACKUP');
    retiredDigests.add(digest);
  }
  const audit = transferAudit(incoming);
  if (audit.errors.length) throw codedError(audit.errors[0], 'INVALID_BACKUP', {audit});
  const state = V.normalize(incoming);
  state.transferUndo = null;
  state.sourceRepairUndo = null;
  state.receiptRetirementUndo = null;
  state.sharedFolderUpdateUndo = null;
  state.pageWatchRepairUndo = null;
  for (const source of state.sources || []) if (source && typeof source === 'object') delete source.watchStability;
  return {document, state, audit};
}

async function currentOriginPatterns() {
  try {
    const current = await api.permissions.getAll();
    return Array.isArray(current?.origins) ? current.origins.filter(value => typeof value === 'string').slice(0, 500) : [];
  } catch {
    return [];
  }
}

function originIsGranted(origin, patterns) {
  return patterns.some(pattern => permissionPatternCoversOrigin(pattern, origin));
}

async function transferPermissionPlan(state) {
  const patterns = await currentOriginPatterns();
  const active = (state.sources || []).filter(source => source?.enabled && !source.archivedAt);
  const originRows = new Map();
  let reconnectSources = 0;
  let movedSources = 0;
  for (const source of active) {
    let origin;
    try { origin = new URL(C.safeUrl(source.url)).origin; } catch { continue; }
    const granted = originIsGranted(origin, patterns);
    if (!originRows.has(origin)) originRows.set(origin, {origin, granted, sourceCount: 0, reconnectSourceCount: 0, movedSourceCount: 0});
    const row = originRows.get(origin);
    row.sourceCount += 1;
    if (source.pendingRedirect) {
      movedSources += 1;
      row.movedSourceCount += 1;
    } else {
      row.reconnectSourceCount += 1;
      if (!granted) reconnectSources += 1;
    }
  }
  const rows = [...originRows.values()].sort((a, b) => a.origin.localeCompare(b.origin));
  return {
    activeOrigins: rows.length,
    alreadyAllowedOrigins: rows.filter(row => row.granted).length,
    reconnectOrigins: rows.filter(row => !row.granted && row.reconnectSourceCount > 0).length,
    reconnectSources,
    movedSources,
    origins: rows.map(row => ({...row}))
  };
}

async function applyDestinationPermissions(state) {
  const patterns = await currentOriginPatterns();
  for (const source of state.sources || []) {
    if (!source || typeof source !== 'object') continue;
    if (!source.enabled || source.archivedAt) {
      delete source.permissionMissing;
      delete source.permissionMissingReason;
      continue;
    }
    let granted = false;
    try { granted = originIsGranted(new URL(C.safeUrl(source.url)).origin, patterns); } catch {}
    if (granted) {
      delete source.permissionMissing;
      delete source.permissionMissingReason;
      if (source.lastOutcome === 'permission') {
        source.lastOutcome = source.lastSuccessfulAt ? 'ready' : '';
        source.lastError = '';
      }
    } else {
      source.permissionMissing = true;
      source.permissionMissingReason = 'transfer';
    }
  }
}

async function exportPrivateBackup({recovery = false} = {}) {
  const state = await loadState();
  assertLibraryWritable('export-private-backup');
  const manifest = api.runtime.getManifest?.() || {};
  const portableState = portableVaultState(state);
  const sourceNoteAudit = privateSourceNoteAudit(portableState);
  if (sourceNoteAudit.errors.length) {
    throw codedError(`This library has an invalid Source Note and cannot be exported: ${sourceNoteAudit.errors[0]}`, 'INVALID_SOURCE_NOTE_STATE', {audit: sourceNoteAudit});
  }
  const document = {
    schema: PRIVATE_BACKUP_SCHEMA,
    exportedAt: new Date().toISOString(),
    purpose: recovery ? 'recovery-copy' : 'library-transfer',
    producer: {name: 'ProgRSS', version: String(manifest.version || '0.80.0'), revision: 'rev0080'},
    state: portableState
  };
  const raw = JSON.stringify(document, null, 2);
  if (byteLength(raw) > MAX_PRIVATE_BACKUP_BYTES) throw codedError('This library is larger than the 24 MB transfer limit.', 'BACKUP_TOO_LARGE');
  let backupReminder = null;
  try { backupReminder = await notePreparedCopy(state); } catch {}
  const day = document.exportedAt.slice(0, 10);
  return {
    fileName: recovery ? `ProgRSS-recovery-${day}.json` : `ProgRSS-library-${day}.json`,
    raw,
    purpose: document.purpose,
    summary: transferSummary(state),
    bytes: byteLength(raw),
    backupReminder
  };
}

async function checkPrivateBackup(raw) {
  const parsed = await parsePrivateBackup(raw);
  const current = await loadState();
  const currentPortable = portableVaultComparisonValue(current);
  const filePortable = portableVaultComparisonValue(parsed.state);
  const samePortableLibrary = stableJson(currentPortable) === stableJson(filePortable);
  const currentSummary = transferSummary(current);
  const fileSummary = transferSummary(parsed.state);
  const countDeltas = {};
  for (const key of ['sources', 'collections', 'sourceNotes', 'items', 'unread', 'saved', 'snapshots', 'advancedRecords']) {
    countDeltas[key] = (Number(currentSummary[key]) || 0) - (Number(fileSummary[key]) || 0);
  }
  await reconcileBackupReminder(current);
  const marker = await readBackupReminder() || newBackupReminder();
  const fileFingerprint = await portableBackupFingerprint(parsed.state, marker.fingerprintKey);
  const matchesCheckedCopy = Boolean(marker.lastCheckedFingerprint && fileFingerprint === marker.lastCheckedFingerprint);
  const matchesPreparedCopy = Boolean(marker.lastPreparedFingerprint && fileFingerprint === marker.lastPreparedFingerprint);
  let state = 'different';
  let relationship = 'different';
  let knownRevision = 0;
  let backupReminder = backupReminderState(marker, current);
  if (samePortableLibrary) {
    state = 'current';
    relationship = 'current';
    knownRevision = Number.isSafeInteger(current._revision) ? current._revision : 0;
    try { backupReminder = await noteCheckedCopy(current, fileFingerprint, knownRevision); } catch {}
  } else if (matchesCheckedCopy) {
    state = 'previous';
    relationship = 'last-checked';
    knownRevision = marker.lastCheckedRevision;
    try { backupReminder = await noteKnownCopySeen(current, relationship, fileFingerprint); } catch {}
  } else if (matchesPreparedCopy) {
    state = 'previous';
    relationship = 'last-prepared';
    knownRevision = marker.lastPreparedRevision;
    try { backupReminder = await noteKnownCopySeen(current, relationship, fileFingerprint); } catch {}
  }
  return {
    schema: 'progrss.private-copy-check.v2',
    state,
    relationship,
    knownCopy: state !== 'different',
    knownRevision,
    samePortableLibrary,
    fileNamePurpose: C.text(parsed.document.purpose, 80),
    exportedAt: validReminderTime(parsed.document.exportedAt) ? parsed.document.exportedAt : '',
    producer: parsed.document.producer && typeof parsed.document.producer === 'object' && !Array.isArray(parsed.document.producer)
      ? parsed.document.producer : null,
    file: fileSummary,
    current: currentSummary,
    countDeltas,
    changedAreas: samePortableLibrary ? [] : privateCopyChangedAreas(filePortable, currentPortable),
    backupReminder,
    network: false,
    writesVault: false,
    writesMarker: state !== 'different'
  };
}

async function previewPrivateBackup(raw) {
  const parsed = await parsePrivateBackup(raw);
  const current = await loadState();
  const permissions = await transferPermissionPlan(parsed.state);
  return {
    canRestore: true,
    exportedAt: typeof parsed.document.exportedAt === 'string' ? parsed.document.exportedAt : '',
    producer: parsed.document.producer && typeof parsed.document.producer === 'object' ? parsed.document.producer : null,
    incoming: transferSummary(parsed.state),
    current: transferSummary(current),
    permissions,
    warnings: parsed.audit.warnings,
    willKeepUndo: hasTransferContent(transferSummary(current)),
    undoMinutes: Math.round(TRANSFER_UNDO_MS / 60000),
    reviewedRevision: current._revision
  };
}

async function restorePrivateBackup(raw, reviewedRevision) {
  return queueMutation(async () => {
    const parsed = await parsePrivateBackup(raw);
    const current = await loadState();
    if (!Number.isSafeInteger(reviewedRevision) || reviewedRevision !== current._revision) {
      throw codedError('ProgRSS changed while this replacement was being reviewed. Review the updated library summary before moving it.', 'TRANSFER_REVIEW_STALE');
    }
    const previousState = portableVaultState(current);
    const previousSummary = transferSummary(current);
    const incoming = parsed.state;
    await applyDestinationPermissions(incoming);
    const stamp = new Date();
    incoming._revision = current._revision;
    incoming.transferUndo = hasTransferContent(previousSummary) ? {
      schema: 'progrss.transfer.undo.v1',
      createdAt: stamp.toISOString(),
      expiresAt: new Date(stamp.getTime() + TRANSFER_UNDO_MS).toISOString(),
      previousState,
      previousSummary
    } : null;
    const permissions = await transferPermissionPlan(incoming);
    await saveAndBroadcast(incoming, {kind: 'private-backup-restored'});
    try { await noteCheckedCopy(incoming); } catch {}
    return {
      summary: transferSummary(incoming), permissions,
      undoAvailable: Boolean(incoming.transferUndo),
      undoUntil: incoming.transferUndo?.expiresAt || ''
    };
  });
}

async function undoPrivateBackupRestore() {
  return queueMutation(async () => {
    const current = await loadState();
    const undo = current.transferUndo;
    if (!validTransferUndo(undo)) throw codedError('The library-move undo has expired.', 'TRANSFER_UNDO_EXPIRED');
    const previous = V.normalize(undo.previousState);
    previous._revision = current._revision;
    previous.transferUndo = null;
    await applyDestinationPermissions(previous);
    const permissions = await transferPermissionPlan(previous);
    await saveAndBroadcast(previous, {kind: 'private-backup-undo'});
    return {summary: transferSummary(previous), permissions};
  });
}

async function clearExpiredTransferUndo() {
  return queueMutation(async () => {
    const state = await loadState();
    if (!state.transferUndo || validTransferUndo(state.transferUndo)) return false;
    state.transferUndo = null;
    await saveAndBroadcast(state, {kind: 'private-backup-undo-expired'});
    return true;
  });
}

async function publicState(state) {
  return {
    schemaVersion: state.version,
    revision: Number.isSafeInteger(state._revision) ? state._revision : 0,
    sources: (state.sources || []).map(source => ({...source})),
    collections: (state.collections || []).map(collection => ({...collection})),
    items: (state.items || []).map(item => ({...item})),
    vault: V.info(),
    storageIncident: await readStorageIncident(),
    libraryRecovery: libraryRecoveryState || await reconcileLibraryPresence(state),
    backupReminder: await reconcileBackupReminder(state),
    transfer: transferUndoInfo(state),
    sourceRepair: sourceRepairUndoInfo(state),
    receiptRetirement: receiptRetirementUndoInfo(state),
    sharedFolderUpdate: sharedFolderUpdateUndoInfo(state),
    pageWatchRepair: pageWatchRepairUndoInfo(state)
  };
}

async function loadState() {
  const state = await V.init();
  await reconcileLibraryPresence(state);
  return state;
}

function queueMutation(task) {
  const run = mutationQueue.catch(() => {}).then(task);
  mutationQueue = run.catch(() => {});
  return run;
}

async function saveAndBroadcast(state, detail = {}) {
  assertLibraryWritable(detail.kind);
  try {
    const committed = await V.save(state);
    if (committed === false) throw Error('Browser storage did not commit the change.');
  } catch (error) {
    if (error?.code === 'STALE_VAULT' || error?.code === 'LIBRARY_RECOVERY_REQUIRED') throw error;
    const incident = await recordStorageIncident(error, detail);
    throw codedError(`${incident.message} The attempted change was not saved; your last saved library remains available.`, 'VAULT_WRITE_FAILED', {incident});
  }
  await noteCommittedLibrary(state);
  await clearStorageIncident();
  await updateBadge(state);
  try { await api.runtime.sendMessage({type: 'progrss:state-changed', detail}); } catch {}
}

async function updateBadge(state) {
  if (libraryRecoveryState?.state === 'missing') {
    await api.action.setBadgeBackgroundColor({color: '#8a5a16'});
    await api.action.setBadgeText({text: '!'});
    await api.action.setTitle({title: 'ProgRSS · local library recovery needed'});
    return;
  }
  const unread = (state.items || []).reduce((count, item) => count + (item.readAt ? 0 : 1), 0);
  await api.action.setBadgeBackgroundColor({color: '#2f6f5e'});
  await api.action.setBadgeText({text: unread ? (unread > 99 ? '99+' : String(unread)) : ''});
  await api.action.setTitle({title: unread ? `ProgRSS · ${unread} unread` : 'ProgRSS · caught up'});
}

function sameOriginFeedUrl(raw, base) {
  if (!raw) return '';
  try {
    const candidate = C.safeUrl(raw, base);
    const reference = C.safeUrl(base);
    return new URL(candidate).origin === new URL(reference).origin ? candidate : '';
  } catch {
    return '';
  }
}

function sourceAddressAliases(source) {
  const values = [
    source?.url,
    source?.declaredFeedUrl,
    ...(Array.isArray(source?.previousUrls) ? source.previousUrls : []),
    ...(Array.isArray(source?.aliasUrls) ? source.aliasUrls : [])
  ];
  const aliases = new Set();
  for (const raw of values) {
    try { aliases.add(C.safeUrl(raw)); } catch {}
  }
  return aliases;
}

function existingSourceForAddresses(state, type, addresses = []) {
  const candidates = [];
  for (const raw of addresses) {
    try {
      const url = C.safeUrl(raw?.url || raw);
      if (!candidates.some(row => row.url === url)) candidates.push({url, match: raw?.match || 'address'});
    } catch {}
  }
  for (const source of state.sources || []) {
    if (source?.type !== type) continue;
    const aliases = sourceAddressAliases(source);
    const candidate = candidates.find(row => aliases.has(row.url));
    if (!candidate) continue;
    return {
      source,
      match: candidate.match,
      summary: {
        id: source.id,
        title: C.text(source.title, 180) || 'Untitled source',
        url: source.url,
        enabled: Boolean(source.enabled),
        archived: Boolean(source.archivedAt),
        match: candidate.match
      }
    };
  }
  return null;
}

function annotateCandidates(state, candidates = []) {
  return candidates.map(candidate => {
    const match = existingSourceForAddresses(state, 'rss', [{url: candidate.url || candidate.href, match: 'advertised-address'}]);
    return match ? {...candidate, existingSource: match.summary} : candidate;
  });
}

async function inspectUrl(url) {
  const response = await fetchResource(url);
  if ([429, 503].includes(response.status)) throw new Error(`The site asked ProgRSS to slow down (HTTP ${response.status}).`);
  const effectiveUrl = response.url || url;
  const rawBody = String(response.body || '');
  let jsonDocument = null;
  if (/^\s*\{/.test(rawBody)) {
    try { jsonDocument = JSON.parse(rawBody); }
    catch (error) {
      if (/"schema"\s*:\s*"progrss\.bundle\.v[123]"/.test(rawBody.slice(0, 8192))) {
        throw codedError('That shared folder is not readable JSON.', 'INVALID_SHARED_FOLDER');
      }
    }
  }
  if (jsonDocument && [F.LEGACY_SCHEMA, F.SCHEMA, F.LOCATED_SCHEMA].includes(jsonDocument.schema)) {
    if (response.encoding !== 'utf-8') throw codedError('ProgRSS shared folders must be UTF-8 JSON.', 'INVALID_SHARED_FOLDER');
    const preview = await previewSharedFolder(rawBody);
    return {
      kind: 'shared-folder',
      requestedUrl: response.requestedUrl || url,
      url: effectiveUrl,
      title: C.text(preview.title, 180) || 'Shared folder',
      raw: rawBody,
      preview: {...preview, network: true, writes: false},
      remote: {
        requestedUrl: C.text(response.requestedUrl || url, 2048),
        finalUrl: C.text(effectiveUrl, 2048),
        status: Number(response.status) || 0,
        contentType: C.text(response.contentType, 200),
        redirects: Array.isArray(response.redirects) ? response.redirects.map(row => ({
          from: C.text(row.from, 2048), to: C.text(row.to, 2048), status: Number(row.status) || 0
        })) : [],
        credentials: 'omitted',
        automatic: false,
        directAddress: true
      }
    };
  }
  const inspected = await parserCall('inspect-resource', {
    body: response.body,
    url: effectiveUrl,
    linkHeader: response.linkHeader,
    contentType: response.contentType
  });
  const inspectedUrl = inspected?.url || effectiveUrl;
  const declaredFeedUrl = inspected?.kind === 'feed' ? sameOriginFeedUrl(inspected.feedUrl, inspectedUrl) : '';
  const state = await loadState();
  const addresses = [
    {url: response.requestedUrl || url, match: 'requested-address'},
    {url: inspectedUrl, match: 'resolved-address'},
    ...(declaredFeedUrl ? [{url: declaredFeedUrl, match: 'declared-self'}] : [])
  ];
  const existing = inspected?.kind === 'feed' ? existingSourceForAddresses(state, 'rss', addresses) : null;
  const candidates = inspected?.kind === 'html' ? annotateCandidates(state, inspected.candidates || []) : inspected?.candidates;
  const publicationChoices = inspected?.kind === 'html'
    ? S.publicationChoices(candidates || [], inspected.sharedFolders || [], inspectedUrl)
    : null;
  return {
    ...inspected,
    requestedUrl: response.requestedUrl,
    url: inspectedUrl,
    feedUrl: declaredFeedUrl,
    existingSource: existing?.summary || null,
    candidates,
    publicationChoices,
    redirects: response.redirects || [],
    encoding: response.encoding || ''
  };
}


async function previewFeedText(raw, url, contentType = 'application/feed+json') {
  const body = String(raw == null ? '' : raw);
  const encoded = new TextEncoder().encode(body);
  if (!body || encoded.byteLength > MAX_EXCHANGE_FEED_BYTES) {
    throw codedError('That recent-updates artifact is empty or larger than the 2 MB review limit.', 'INVALID_EXCHANGE_FEED');
  }
  const publicUrl = C.safeUrl(url);
  const inspected = await parserCall('inspect-resource', {
    body,
    url: publicUrl,
    linkHeader: '',
    contentType: C.text(contentType, 200) || 'application/feed+json'
  });
  if (inspected?.kind !== 'feed') {
    throw codedError('That handoff artifact did not contain a readable feed.', 'INVALID_EXCHANGE_FEED');
  }
  const inspectedUrl = inspected.url || publicUrl;
  const declaredFeedUrl = sameOriginFeedUrl(inspected.feedUrl, inspectedUrl);
  const state = await loadState();
  const existing = existingSourceForAddresses(state, 'rss', [
    {url: publicUrl, match: 'handoff-public-address'},
    {url: inspectedUrl, match: 'resolved-address'},
    ...(declaredFeedUrl ? [{url: declaredFeedUrl, match: 'declared-self'}] : [])
  ]);
  return {
    ...inspected,
    requestedUrl: publicUrl,
    url: inspectedUrl,
    feedUrl: declaredFeedUrl,
    existingSource: existing?.summary || null,
    redirects: [],
    encoding: 'utf-8',
    network: false,
    writes: false,
    handoffPreview: true
  };
}

async function addSource(input) {
  const url = C.safeUrl(input.url);
  if (!(await hasOriginPermission(url))) {
    throw codedError('Site access is needed before ProgRSS can follow this address.', 'PERMISSION_REQUIRED');
  }
  return queueMutation(async () => {
    const state = await loadState();
    const type = input.type === 'page' ? 'page' : 'rss';
    const declaredFeedUrl = type === 'rss' ? sameOriginFeedUrl(input.feedUrl, url) : '';
    const match = existingSourceForAddresses(state, type, [
      {url, match: 'address'},
      ...(declaredFeedUrl ? [{url: declaredFeedUrl, match: 'declared-self'}] : [])
    ]);
    const existing = match?.source || null;
    if (existing && !existing.archivedAt) {
      return {source: existing, restored: false, alreadyFollowing: true, match: match.match};
    }
    if (existing) {
      existing.enabled = true;
      existing.archivedAt = '';
      if (input.title) existing.title = C.text(input.title, 130);
      if (type === 'rss') {
        const language = C.languageTag(input.language), titleLanguage = C.languageTag(input.titleLanguage) || language;
        if (language) existing.language = language; else delete existing.language;
        if (titleLanguage) existing.titleLanguage = titleLanguage; else delete existing.titleLanguage;
      }
      if (type === 'rss' && declaredFeedUrl) existing.declaredFeedUrl = declaredFeedUrl;
      if (type === 'rss') {
        try {
          const oldUrl = C.safeUrl(existing.url);
          if (oldUrl !== url && new URL(oldUrl).origin === new URL(url).origin) {
            rememberPreviousUrl(existing, oldUrl);
            existing.url = url;
            existing.httpCache = {};
          }
        } catch {
          // A malformed historical address remains visible for repair; it never
          // turns a reviewed restore into an unhandled background failure.
        }
      }
      await saveAndBroadcast(state, {kind: 'source-restored', sourceId: existing.id});
      return {source: existing, restored: true, alreadyFollowing: false, match: match.match};
    }
    if ((state.sources || []).length >= C.LIMIT.source) throw new Error('The source limit is 200. Archive or remove a source in the Workbench first.');
    const recipe = C.cleanRecipe({
      id: C.uid(type === 'page' ? 'page' : 'feed'),
      title: input.title || (type === 'page' ? new URL(url).hostname : 'New feed'),
      type,
      url,
      mode: input.mode === 'cards' ? 'cards' : 'region',
      selector: input.selector || '',
      titleSelector: input.titleSelector || '',
      linkSelector: input.linkSelector || '',
      include: '',
      exclude: '',
      threshold: type === 'page' ? 24 : 1,
      ignoreNumbers: false,
      author: 'local extension',
      version: 1
    });
    const source = {...recipe, enabled: true, origin: 'extension', createdAt: new Date().toISOString(), lastScan: '', lastError: '', lastSuccessfulAt: '', lastNewAt: '', lastProblemAt: '', lastProblem: ''};
    if (type === 'rss') {
      const language = C.languageTag(input.language), titleLanguage = C.languageTag(input.titleLanguage) || language;
      if (language) source.language = language;
      if (titleLanguage) source.titleLanguage = titleLanguage;
    }
    if (declaredFeedUrl) source.declaredFeedUrl = declaredFeedUrl;
    state.sources.push(source);
    await saveAndBroadcast(state, {kind: 'source-added', sourceId: source.id});
    return {source, restored: false};
  });
}


function canonicalRssSources(state) {
  const result = new Map();
  for (const source of state.sources || []) {
    if (source?.type !== 'rss') continue;
    for (const url of sourceAddressAliases(source)) result.set(url, source);
  }
  return result;
}

function opmlFolderKeys(feeds) {
  const keys = new Set();
  for (const feed of feeds) {
    for (const rawPath of Array.isArray(feed.folderPaths) ? feed.folderPaths : []) {
      const path = rawPath.map(part => C.text(part, 130)).filter(Boolean).slice(0, 12);
      for (let index = 1; index <= path.length; index++) keys.add(JSON.stringify(path.slice(0, index)));
    }
  }
  return keys;
}

function planOpml(parsed, state) {
  const existing = canonicalRssSources(state);
  const newFeeds = [];
  let existingCount = 0;
  for (const feed of parsed.feeds || []) {
    const url = C.safeUrl(feed.url);
    if (existing.has(url)) existingCount++;
    else newFeeds.push({...feed, url});
  }
  const folderKeys = opmlFolderKeys(newFeeds);
  const origins = [...new Set(newFeeds.map(feed => new URL(feed.url).origin))].sort();
  const sourceRoom = Math.max(0, C.LIMIT.source - (state.sources || []).length);
  const collectionRoom = Math.max(0, C.LIMIT.collection - (state.collections || []).length);
  let reason = '';
  if (parsed.truncatedCount) reason = 'This OPML file contains more than 500 unique feeds. Split it into smaller files before importing.';
  else if (!newFeeds.length) reason = 'Every valid feed in this file is already in ProgRSS.';
  else if (newFeeds.length > sourceRoom) reason = `ProgRSS has room for ${sourceRoom} more source${sourceRoom === 1 ? '' : 's'}, but this file would add ${newFeeds.length}.`;
  else if (folderKeys.size > collectionRoom) reason = `ProgRSS has room for ${collectionRoom} more folder${collectionRoom === 1 ? '' : 's'}, but this file would add ${folderKeys.size}.`;
  return {
    newFeeds,
    folderKeys,
    origins,
    preview: {
      schema: 'progrss.opml.preview.v1',
      title: C.text(parsed.title, 180) || 'Imported subscriptions',
      feedOutlines: Number(parsed.feedOutlines) || 0,
      uniqueFeeds: Array.isArray(parsed.feeds) ? parsed.feeds.length : 0,
      newCount: newFeeds.length,
      existingCount,
      duplicateInFileCount: Number(parsed.duplicateCount) || 0,
      invalidCount: Number(parsed.invalidCount) || 0,
      truncatedCount: Number(parsed.truncatedCount) || 0,
      folderCount: folderKeys.size,
      originCount: origins.length,
      origins,
      canImport: !reason,
      reason,
      sample: newFeeds.slice(0, 8).map(feed => ({title: C.text(feed.title, 130) || new URL(feed.url).hostname, url: feed.url})),
      network: false
    }
  };
}

async function previewOpml(raw) {
  const parsed = await parserCall('parse-opml', {body: raw});
  return planOpml(parsed, await loadState()).preview;
}

function addMember(collection, member) {
  if (!collection.members.some(row => row.kind === member.kind && row.id === member.id)) collection.members.push(member);
}

function buildOpmlCollections(feeds, sourceByUrl, stamp) {
  const nodes = new Map();
  const nodeFor = path => {
    const key = JSON.stringify(path);
    let node = nodes.get(key);
    if (!node) {
      node = {
        id: C.uid('collection'), title: path[path.length - 1], mode: 'union', include: '', exclude: '', version: 1,
        author: 'OPML import', members: [], origin: 'opml-import', createdAt: stamp
      };
      nodes.set(key, node);
      if (path.length > 1) addMember(nodeFor(path.slice(0, -1)), {kind: 'collection', id: node.id});
    }
    return node;
  };
  for (const feed of feeds) {
    const source = sourceByUrl.get(C.safeUrl(feed.url));
    if (!source) continue;
    for (const rawPath of Array.isArray(feed.folderPaths) ? feed.folderPaths : []) {
      const path = rawPath.map(part => C.text(part, 130)).filter(Boolean).slice(0, 12);
      if (path.length) addMember(nodeFor(path), {kind: 'source', id: source.id});
    }
  }
  return [...nodes.values()];
}

async function importOpml(raw, {paused = true} = {}) {
  const parsed = await parserCall('parse-opml', {body: raw});
  return queueMutation(async () => {
    const state = await loadState();
    const plan = planOpml(parsed, state);
    if (!plan.preview.canImport) throw new Error(plan.preview.reason);
    if (!paused) {
      if (plan.origins.length > MAX_ACTIVE_IMPORT_ORIGINS) {
        throw new Error(`Active OPML import is limited to ${MAX_ACTIVE_IMPORT_ORIGINS} distinct sites. Add this file paused, then resume sources as needed.`);
      }
      const origins = plan.origins.map(origin => `${origin}/*`);
      if (origins.length && !(await api.permissions.contains({origins}))) {
        const error = new Error('Site access was not granted for every imported feed. Import paused instead, or try again.');
        error.code = 'PERMISSION_REQUIRED';
        throw error;
      }
    }
    const stamp = new Date().toISOString();
    const sourceByUrl = new Map();
    const sourceIds = [];
    for (const feed of plan.newFeeds) {
      const recipe = C.cleanRecipe({
        id: C.uid('feed'), title: feed.title || new URL(feed.url).hostname, type: 'rss', url: feed.url,
        mode: 'region', selector: '', titleSelector: '', linkSelector: '', include: '', exclude: '',
        threshold: 1, ignoreNumbers: false, author: 'OPML import', version: 1
      });
      const source = {
        ...recipe, enabled: !paused, archivedAt: '', origin: 'opml-import', createdAt: stamp, importedAt: stamp,
        lastScan: '', lastError: '', lastSuccessfulAt: '', lastNewAt: '', lastProblemAt: '', lastProblem: ''
      };
      state.sources.push(source);
      sourceByUrl.set(source.url, source);
      sourceIds.push(source.id);
    }
    const collections = buildOpmlCollections(plan.newFeeds, sourceByUrl, stamp);
    state.collections.push(...collections);
    await saveAndBroadcast(state, {kind: 'opml-import', added: sourceIds.length, paused: Boolean(paused)});
    return {
      added: sourceIds.length,
      paused: Boolean(paused),
      foldersAdded: collections.length,
      existingSkipped: plan.preview.existingCount,
      duplicateInFileCount: plan.preview.duplicateInFileCount,
      invalidCount: plan.preview.invalidCount,
      sourceIds
    };
  });
}

function durableProblem(source, message, outcome, stamp) {
  source.lastOutcome = outcome;
  source.lastError = String(message || '').slice(0, 300);
  source.lastProblemAt = stamp;
  source.lastProblem = source.lastError;
}

function rememberPreviousUrl(source, oldUrl) {
  const values = Array.isArray(source.previousUrls) ? source.previousUrls.filter(value => typeof value === 'string') : [];
  if (oldUrl && !values.includes(oldUrl)) values.push(oldUrl);
  source.previousUrls = values.slice(-4);
}

function adoptReviewedAddress(source, finalUrl, stamp, status) {
  const oldUrl = C.safeUrl(source.url);
  const nextUrl = C.safeUrl(finalUrl);
  if (oldUrl !== nextUrl) {
    rememberPreviousUrl(source, oldUrl);
    source.url = nextUrl;
    source.movedAt = stamp;
    delete source.watchStability;
    source.redirectHistory = [
      ...(Array.isArray(source.redirectHistory) ? source.redirectHistory : []),
      {from: oldUrl, to: nextUrl, status: Number(status) || 0, acceptedAt: stamp, kind: 'cross-origin'}
    ].slice(-6);
  }
  delete source.pendingRedirect;
}

function applySuccessfulMove(source, response, stamp, acceptedMove = null) {
  const finalUrl = C.safeUrl(response.url || source.url);
  source.lastResolvedUrl = finalUrl;
  source.lastRedirects = Array.isArray(response.redirects) ? response.redirects.slice(0, MAX_REDIRECTS) : [];
  if (acceptedMove) {
    adoptReviewedAddress(source, finalUrl, stamp, acceptedMove.status);
    return;
  }
  const chain = Array.isArray(response.redirects) ? response.redirects : [];
  const permanent = chain.length && chain.every(row => [301, 308].includes(Number(row.status)));
  if (permanent && finalUrl !== source.url && new URL(finalUrl).origin === new URL(source.url).origin) {
    const oldUrl = source.url;
    rememberPreviousUrl(source, oldUrl);
    source.url = finalUrl;
    source.movedAt = stamp;
    delete source.watchStability;
    source.redirectHistory = [
      ...(Array.isArray(source.redirectHistory) ? source.redirectHistory : []),
      {from: oldUrl, to: finalUrl, status: Number(chain.at(-1)?.status) || 0, acceptedAt: stamp, kind: 'same-origin'}
    ].slice(-6);
  }
  delete source.pendingRedirect;
}

async function applySourceResponse(state, source, response, now, {acceptedMove = null} = {}) {
  const stamp = new Date(now).toISOString();
  const previousHttpCache = source.httpCache && typeof source.httpCache === 'object' ? {...source.httpCache} : {};
  const nextHttpCache = updatedHttpCache(response, previousHttpCache);
  source.lastScan = stamp;
  source.lastHttpStatus = response.status;
  source.checkCount = (Number(source.checkCount) || 0) + 1;
  delete source.permissionMissing;
  delete source.permissionMissingReason;

  if (response.status === 304) {
    source.httpCache = nextHttpCache;
    applySuccessfulMove(source, response, stamp, acceptedMove);
    source.lastItems = 0;
    source.lastOutcome = 'unchanged';
    source.lastError = '';
    source.lastSuccessfulAt = stamp;
    if (source.type === 'page' && source.watchStability) {
      delete source.watchStability;
      source.watchHealth = {
        schema: C.PAGE_WATCH_HEALTH_SCHEMA, status: 'steady', reason: 'returned-to-steady', checkedAt: stamp,
        message: 'The page returned to its usual shape. The held result was discarded without creating an alert.', metrics: {}
      };
    }
    source.pulse = P.advance(source.pulse, 'quiet', now, response);
    return {source, added: 0, baseline: false, outcome: 'unchanged', notModified: true};
  }
  if ([429, 503].includes(response.status)) {
    source.httpCache = nextHttpCache;
    source.lastItems = 0;
    durableProblem(source, `The site asked ProgRSS to slow down (HTTP ${response.status}).`, 'throttled', stamp);
    source.pulse = P.advance(source.pulse, 'throttled', now, response);
    return {source, added: 0, outcome: 'throttled'};
  }

  let result;
  if (source.type === 'rss') {
    const parsed = await parserCall('parse-feed', {body: response.body, url: response.url || source.url});
    const declaredFeedUrl = sameOriginFeedUrl(parsed.feedUrl, response.url || source.url);
    if (declaredFeedUrl) source.declaredFeedUrl = declaredFeedUrl;
    const language = C.languageTag(parsed.language), titleLanguage = C.languageTag(parsed.titleLanguage) || language;
    if (language) source.language = language; else delete source.language;
    if (titleLanguage) source.titleLanguage = titleLanguage; else delete source.titleLanguage;
    const added = C.ingestFeed(state, source, parsed);
    result = {added, baseline: false, feedType: parsed.type, title: parsed.title, titleLanguage, language, feedUrl: declaredFeedUrl};
    if ((!source.title || source.title === 'New feed') && parsed.title) source.title = parsed.title;
    source.httpCache = nextHttpCache;
  } else {
    const effectiveSource = {...source, url: response.url || source.url};
    const capture = await parserCall('extract-page', {body: response.body, source: effectiveSource});
    const previousSnapshot = state.snapshots && typeof state.snapshots === 'object' ? state.snapshots[source.id] : null;
    const health = C.pageWatchCaptureHealth(previousSnapshot, capture, source);
    if (health.status === 'attention') {
      throw codedError(health.message, 'PAGE_WATCH_STRUCTURE_CHANGED', {health});
    }
    const stability = C.pageWatchStabilityDecision(source.watchStability, health, source);
    if (stability.action === 'repair') {
      throw codedError(stability.health.message, 'PAGE_WATCH_UNSTABLE', {health: stability.health});
    }
    if (stability.action === 'hold') {
      applySuccessfulMove(source, response, stamp, acceptedMove);
      source.watchStability = stability.stability;
      source.watchHealth = stability.health;
      source.httpCache = previousHttpCache;
      source.lastItems = 0;
      source.lastOutcome = 'watch-pending';
      source.lastError = '';
      source.lastSuccessfulAt = stamp;
      source.pulse = P.advance(source.pulse, 'quiet', now, response);
      return {source, added: 0, baseline: false, held: true, outcome: 'watch-pending', stability: source.watchStability};
    }
    result = C.ingestPage(state, source, capture);
    source.watchHealth = stability.health;
    delete source.watchStability;
    delete source.watchRepair;
    source.httpCache = nextHttpCache;
  }
  applySuccessfulMove(source, response, stamp, acceptedMove);
  source.lastItems = result.added || 0;
  source.lastOutcome = result.baseline ? 'baseline' : (result.added ? 'changed' : 'unchanged');
  source.lastError = '';
  source.lastSuccessfulAt = stamp;
  if (result.added) source.lastNewAt = stamp;
  source.pulse = P.advance(source.pulse, result.added ? 'changed' : 'quiet', now, response);
  return {source, ...result, outcome: source.lastOutcome};
}

function pendingMove(source, detail, stamp) {
  return {
    from: C.safeUrl(source.url),
    redirectFrom: C.safeUrl(detail.from || source.url),
    to: C.safeUrl(detail.to, detail.from || source.url),
    status: Number(detail.status) || 0,
    sourceOrigin: new URL(source.url).origin,
    destinationOrigin: new URL(detail.to).origin,
    sourceHost: new URL(source.url).host.replace(/^www\./, ''),
    destinationHost: new URL(detail.to).host.replace(/^www\./, ''),
    chain: Array.isArray(detail.chain) ? detail.chain.slice(0, MAX_REDIRECTS) : [],
    observedAt: stamp
  };
}

const PAGE_WATCH_REPAIR_CODES = new Set(['PAGE_SELECTOR_INVALID','PAGE_SELECTOR_NO_MATCH','PAGE_WATCH_STRUCTURE_CHANGED','PAGE_WATCH_UNSTABLE']);
function pageWatchRepairMessage(code){
  if(code==='PAGE_SELECTOR_INVALID')return 'The saved watch rule is no longer valid. Choose what to watch on this page again.';
  if(code==='PAGE_SELECTOR_NO_MATCH')return 'ProgRSS can no longer find the watched section. Choose what to watch on this page again.';
  if(code==='PAGE_WATCH_UNSTABLE')return 'The watched page changed shape differently across several checks. Choose what to watch again before ProgRSS creates unreliable alerts.';
  return 'The watched part of this page changed shape. ProgRSS stopped before turning that layout change into misleading alerts.';
}
function markPageWatchRepair(source,error,stamp){
  const code=PAGE_WATCH_REPAIR_CODES.has(error?.code)?error.code:'PAGE_WATCH_STRUCTURE_CHANGED';
  const reason=code==='PAGE_SELECTOR_INVALID'?'invalid-selector':code==='PAGE_SELECTOR_NO_MATCH'?'no-match':code==='PAGE_WATCH_UNSTABLE'?'unstable-shape':'structure-changed';
  const message=pageWatchRepairMessage(code);
  delete source.watchStability;
  source.watchRepair={schema:'progrss.page-watch.repair.v1',reason,noticedAt:stamp,message};
  if(error?.detail?.health&&typeof error.detail.health==='object')source.watchHealth=error.detail.health;
  durableProblem(source,message,'watch-repair',stamp);
  source.pulse={...P.advance(source.pulse,'error',Date.parse(stamp)||Date.now()),needsReview:true};
}

async function refreshSourceById(sourceId, {manual = false, silent = false} = {}) {
  return queueMutation(async () => {
    const state = await loadState();
    const source = (state.sources || []).find(item => item.id === sourceId);
    if (!source) throw new Error('Source not found.');
    if (!source.enabled) throw new Error('This source is paused.');
    if (source.type === 'page' && source.watchRepair) {
      const error = codedError('This page watch is waiting for you to choose what to watch now.', 'PAGE_WATCH_REPAIR_REQUIRED', {watchRepair: source.watchRepair});
      if (!manual || silent) return {source, skipped: true, reason: 'watch-repair', outcome: 'watch-repair', error: error.message};
      throw error;
    }
    const now = Date.now();
    const stamp = new Date(now).toISOString();
    if (!(await hasOriginPermission(source.url))) {
      source.permissionMissing = true;
      source.permissionMissingReason = 'missing';
      durableProblem(source, 'Site access was removed. Reconnect this source before checking it again.', 'permission', stamp);
      source.pulse = P.advance(source.pulse, 'error', now);
      await saveAndBroadcast(state, {kind: 'source-refreshed', sourceId, outcome: 'permission'});
      const error = codedError('Site access is needed. Reconnect this source first.', 'PERMISSION_REQUIRED');
      if (!manual || silent) return {source, skipped: true, reason: 'permission', outcome: 'permission', error: error.message};
      throw error;
    }
    try {
      const response = await fetchResource(source.url, source.httpCache || {});
      const result = await applySourceResponse(state, source, response, now);
      await saveAndBroadcast(state, {kind: 'source-refreshed', sourceId, outcome: result.outcome, added: result.added || 0});
      return result;
    } catch (error) {
      if (error?.code === 'CROSS_ORIGIN_REDIRECT') {
        source.pendingRedirect = pendingMove(source, error.detail || {}, stamp);
        durableProblem(source, `This source moved to ${source.pendingRedirect.destinationHost}. Review the move before ProgRSS contacts the new site.`, 'moved', stamp);
        source.pulse = {...P.advance(source.pulse, 'error', now), needsReview: true};
      } else if (['PERMISSION_REQUIRED', 'PERMISSION_REMOVED'].includes(error?.code)) {
        source.permissionMissing = true;
        source.permissionMissingReason = error?.code === 'PERMISSION_REMOVED' ? 'removed' : 'missing';
        durableProblem(source, 'Site access was removed. Reconnect this source before checking it again.', 'permission', stamp);
        source.pulse = P.advance(source.pulse, 'error', now);
      } else if (source.type === 'page' && PAGE_WATCH_REPAIR_CODES.has(error?.code)) {
        markPageWatchRepair(source, error, stamp);
      } else {
        durableProblem(source, String(error?.message || error), 'error', stamp);
        source.pulse = P.advance(source.pulse, 'error', now);
      }
      await saveAndBroadcast(state, {kind: 'source-refreshed', sourceId, outcome: source.lastOutcome});
      if (silent) return {source, added: 0, outcome: source.lastOutcome, error: source.lastError, code: error?.code || 'FAILED', detail: error?.detail || null};
      throw error;
    }
  });
}

async function acceptSourceRedirect(input = {}) {
  return queueMutation(async () => {
    const state = await loadState();
    const source = (state.sources || []).find(item => item.id === input.sourceId);
    if (!source) throw new Error('Source not found.');
    const pending = source.pendingRedirect;
    if (!pending) throw codedError('This source no longer has a move waiting for review.', 'STALE_REDIRECT');
    const expectedFrom = C.safeUrl(input.from);
    const expectedTo = C.safeUrl(input.to);
    if (C.safeUrl(pending.from) !== expectedFrom || C.safeUrl(pending.to) !== expectedTo || C.safeUrl(source.url) !== expectedFrom) {
      throw codedError('The source move changed. Review the latest address before continuing.', 'STALE_REDIRECT');
    }
    if (!(await hasOriginPermission(expectedFrom)) || !(await hasOriginPermission(expectedTo))) {
      throw codedError('Site access is needed for both the old and new site before ProgRSS can verify this move.', 'PERMISSION_REQUIRED');
    }

    const now = Date.now();
    const stamp = new Date(now).toISOString();
    let observed;
    let recoveredResponse = null;
    try {
      recoveredResponse = await fetchResource(expectedFrom, source.httpCache || {});
    } catch (error) {
      if (error?.code !== 'CROSS_ORIGIN_REDIRECT') throw error;
      observed = error.detail;
    }
    if (recoveredResponse) {
      delete source.pendingRedirect;
      const result = await applySourceResponse(state, source, recoveredResponse, now);
      await saveAndBroadcast(state, {kind: 'source-redirect-recovered', sourceId: source.id, outcome: result.outcome});
      return {...result, recovered: true, moved: false};
    }
    if (!observed || C.safeUrl(observed.to) !== expectedTo) {
      if (observed?.to) source.pendingRedirect = pendingMove(source, observed, stamp);
      await saveAndBroadcast(state, {kind: 'source-redirect-changed', sourceId: source.id});
      throw codedError('The destination changed while you were reviewing it. Nothing moved; review the new address.', 'REDIRECT_CHANGED', observed || null);
    }

    try {
      // Validators belong to the old origin and must never be disclosed to a new one.
      const response = await fetchResource(expectedTo, {});
      if (response.status === 304) {
        throw codedError('The new site did not send a feed, so the move is still waiting for review.', 'REDIRECT_DESTINATION_UNVERIFIED', {status: response.status});
      }
      if ([429, 503].includes(response.status)) {
        throw codedError(`The new site asked ProgRSS to try later (HTTP ${response.status}). The move has not been accepted.`, 'REDIRECT_DESTINATION_UNAVAILABLE', {status: response.status, retryAfter: response.retryAfter || ''});
      }
      source.httpCache = {};
      const result = await applySourceResponse(state, source, response, now, {acceptedMove: {status: observed.status}});
      source.enabled = true;
      await saveAndBroadcast(state, {kind: 'source-redirect-accepted', sourceId: source.id, from: expectedFrom, to: source.url, outcome: result.outcome});
      return {...result, recovered: false, moved: true, from: expectedFrom, to: source.url};
    } catch (error) {
      if (error?.code === 'CROSS_ORIGIN_REDIRECT') {
        // The reader already approved and contacted expectedTo. Record that
        // reviewed crossing before asking about the next origin, otherwise a
        // two-crossing chain could never advance beyond its first hop.
        adoptReviewedAddress(source, expectedTo, stamp, observed.status);
        source.httpCache = {};
        source.lastScan = stamp;
        source.lastHttpStatus = Number(error.detail?.status) || 0;
        source.lastResolvedUrl = C.safeUrl(error.detail?.from || expectedTo);
        source.lastRedirects = Array.isArray(error.detail?.chain) ? error.detail.chain.slice(0, MAX_REDIRECTS) : [];
        source.pendingRedirect = pendingMove(source, error.detail || {}, stamp);
        durableProblem(source, `This source moved again to ${source.pendingRedirect.destinationHost}. Review the next move before ProgRSS contacts it.`, 'moved', stamp);
        source.pulse = {...P.advance(source.pulse, 'error', now), needsReview: true};
      } else if (error?.code === 'REDIRECT_DESTINATION_UNAVAILABLE') {
        source.lastScan = stamp;
        source.lastHttpStatus = Number(error.detail?.status) || 0;
        source.checkCount = (Number(source.checkCount) || 0) + 1;
        durableProblem(source, String(error.message), 'throttled', stamp);
        source.pulse = P.advance(source.pulse, 'throttled', now, {retryAfter: error.detail?.retryAfter || ''});
      } else {
        source.lastScan = stamp;
        source.lastHttpStatus = Number(error.detail?.status) || 0;
        durableProblem(source, String(error?.message || error), error?.code === 'PERMISSION_REMOVED' ? 'permission' : 'error', stamp);
        source.pulse = P.advance(source.pulse, 'error', now);
        if (error?.code === 'PERMISSION_REMOVED') {
          source.permissionMissing = true;
          source.permissionMissingReason = 'removed';
        }
      }
      await saveAndBroadcast(state, {kind: 'source-redirect-failed', sourceId: source.id, outcome: source.lastOutcome});
      throw error;
    }
  });
}

async function refreshSourcesById(sourceIds) {
  const ids = [...new Set(Array.isArray(sourceIds) ? sourceIds.filter(id => typeof id === 'string') : [])].slice(0, MAX_BULK_REFRESH);
  const results = [];
  for (const sourceId of ids) results.push(await refreshSourceById(sourceId, {manual: false, silent: true}));
  return {checked: results.length, results};
}

async function refreshMany({dueOnly = false, silent = false} = {}) {
  const state = await loadState();
  const eligible = (state.sources || []).filter(source => source.enabled && !source.pendingRedirect && !source.permissionMissing && !(source.type === 'page' && source.watchRepair));
  let sources;
  if (dueOnly) sources = P.schedule(eligible, Date.now(), 12).due;
  else sources = eligible.filter(source => !source.pulse?.needsReview).slice(0, 20);
  const results = [];
  for (const source of sources) {
    results.push(await refreshSourceById(source.id, {manual: false, silent: true}));
  }
  return {checked: results.length, results};
}

async function sha256Text(value){
  const bytes=new TextEncoder().encode(String(value||''));
  const digest=await globalThis.crypto.subtle.digest('SHA-256',bytes);
  return [...new Uint8Array(digest)].map(byte=>byte.toString(16).padStart(2,'0')).join('');
}
async function pageWatchRepairPlan(state,source,response){
  const effectiveSource={...source,url:response.url||source.url};
  const raw=await parserCall('repair-page-watch',{body:response.body,source:effectiveSource});
  if(!Array.isArray(raw)||!raw.length)throw codedError('ProgRSS could not find a clear section to offer. Open the page or use selector controls in Advanced Workbench.','PAGE_WATCH_REPAIR_NO_PROPOSALS');
  const snapshot=state.snapshots&&typeof state.snapshots==='object'?state.snapshots[source.id]:null;
  const proposals=[];
  for(const proposal of raw.slice(0,6)){
    const token=await sha256Text(stableJson({
      sourceId:source.id,sourceVersion:Number(source.version)||1,revision:Number(state._revision)||0,
      finalUrl:C.text(response.url||source.url,2048),snapshotAt:C.text(snapshot?.capturedAt,80),
      recipe:proposal.recipe,evidence:proposal.evidence
    }));
    proposals.push({
      ...proposal,
      token,
      public:{
        token,title:C.text(proposal.title,160),description:C.text(proposal.description,300),mode:proposal.mode==='cards'?'cards':'region',
        count:Math.max(0,Number(proposal.count)||0),examples:Array.isArray(proposal.examples)?proposal.examples.map(value=>C.text(value,160)).filter(Boolean).slice(0,4):[],
        preview:C.text(proposal.preview,360)
      }
    });
  }
  return proposals;
}
async function previewPageWatchRepair(input={}){
  const state=await loadState();
  const source=(state.sources||[]).find(row=>row.id===C.text(input.sourceId,300));
  if(!source||source.type!=='page')throw codedError('That page watch is no longer available.','PAGE_WATCH_REPAIR_NOT_FOUND');
  if(!(await hasOriginPermission(source.url)))throw codedError('Site access is needed before ProgRSS can inspect this page for repair.','PERMISSION_REQUIRED');
  const response=await fetchResource(source.url,{});
  if([429,503].includes(response.status))throw codedError(`The site asked ProgRSS to try later (HTTP ${response.status}).`,'PAGE_WATCH_REPAIR_UNAVAILABLE',{status:response.status});
  const proposals=await pageWatchRepairPlan(state,source,response);
  return {
    schema:'progrss.page-watch.repair-review.v1',reviewedRevision:state._revision,
    source:{id:source.id,title:C.text(source.title,180),url:C.safeUrl(source.url),reason:C.text(source.watchRepair?.reason,60)},
    proposals:proposals.map(row=>row.public),
    warnings:[
      ...(state.transferUndo||state.sourceRepairUndo||state.receiptRetirementUndo||state.sharedFolderUpdateUndo||state.pageWatchRepairUndo?['Completing this repair replaces any earlier timed undo with one page-watch repair undo.']:[])
    ],
    preserves:['Earlier page-change alerts','Read and saved state','Folder placement','Source activity history'],
    network:true,writes:false,automatic:false
  };
}
function validPageWatchRepairUndo(undo,revision,now=Date.now()){
  return Boolean(undo&&typeof undo==='object'&&!Array.isArray(undo)&&undo.schema==='progrss.page-watch.repair.undo.v1'&&
    undo.previousState&&typeof undo.previousState==='object'&&!Array.isArray(undo.previousState)&&
    Number.isSafeInteger(undo.expectedRevision)&&undo.expectedRevision===revision&&
    Number.isFinite(Date.parse(undo.expiresAt||''))&&Date.parse(undo.expiresAt)>now);
}
function pageWatchRepairUndoInfo(state){
  const undo=state.pageWatchRepairUndo;
  if(!validPageWatchRepairUndo(undo,state._revision))return {undoAvailable:false};
  return {undoAvailable:true,createdAt:C.text(undo.createdAt,80),expiresAt:C.text(undo.expiresAt,80),sourceId:C.text(undo.sourceId,300),sourceTitle:C.text(undo.sourceTitle,180)};
}
async function repairPageWatch(input={}){
  return queueMutation(async()=>{
    const state=await loadState();
    if(!Number.isSafeInteger(input.reviewedRevision)||input.reviewedRevision!==state._revision){
      throw codedError('ProgRSS changed while this repair was being reviewed. Inspect the page again before choosing a section.','PAGE_WATCH_REPAIR_STALE');
    }
    const source=(state.sources||[]).find(row=>row.id===C.text(input.sourceId,300));
    if(!source||source.type!=='page')throw codedError('That page watch is no longer available.','PAGE_WATCH_REPAIR_NOT_FOUND');
    if(!(await hasOriginPermission(source.url)))throw codedError('Site access is needed before ProgRSS can finish this repair.','PERMISSION_REQUIRED');
    const response=await fetchResource(source.url,{});
    const proposals=await pageWatchRepairPlan(state,source,response);
    const chosen=proposals.find(row=>row.token===C.text(input.proposalToken,100));
    if(!chosen)throw codedError('The page changed after review. Nothing was repaired; inspect the current page again.','PAGE_WATCH_REPAIR_STALE');
    const previousState=jsonClone(state);delete previousState._revision;
    for(const key of ['transferUndo','sourceRepairUndo','receiptRetirementUndo','sharedFolderUpdateUndo','pageWatchRepairUndo'])previousState[key]=null;
    for(const key of ['transferUndo','sourceRepairUndo','receiptRetirementUndo','sharedFolderUpdateUndo','pageWatchRepairUndo'])state[key]=null;
    const stamp=new Date().toISOString();
    const recipe=chosen.recipe||{};
    source.mode=recipe.mode==='cards'?'cards':'region';
    source.selector=C.text(recipe.selector,350);
    source.titleSelector=C.text(recipe.titleSelector,200);
    source.linkSelector=C.text(recipe.linkSelector,200);
    source.threshold=Math.min(10000,Math.max(0,Math.floor(Number(recipe.threshold)||1)));
    source.ignoreNumbers=Boolean(recipe.ignoreNumbers);
    source.version=Math.min(10000,Math.max(1,Math.floor(Number(source.version)||1)+1));
    if(!state.snapshots||typeof state.snapshots!=='object'||Array.isArray(state.snapshots))state.snapshots={};
    delete state.snapshots[source.id];
    C.ingestPage(state,source,chosen.capture);
    source.watchHealth=C.pageWatchCaptureHealth(null,chosen.capture,source);
    delete source.watchStability;
    delete source.watchRepair;
    if(source.pulse)delete source.pulse.needsReview;
    source.lastScan=stamp;source.lastSuccessfulAt=stamp;source.lastItems=0;source.lastOutcome='baseline';source.lastError='';
    source.lastHttpStatus=Number(response.status)||0;source.checkCount=(Number(source.checkCount)||0)+1;source.httpCache=updatedHttpCache(response,{});
    source.pulse=P.advance(source.pulse,'quiet',Date.now(),response);
    applySuccessfulMove(source,response,stamp);
    const created=new Date();
    state.pageWatchRepairUndo={schema:'progrss.page-watch.repair.undo.v1',createdAt:created.toISOString(),expiresAt:new Date(created.getTime()+PAGE_WATCH_REPAIR_UNDO_MS).toISOString(),expectedRevision:state._revision+1,sourceId:source.id,sourceTitle:C.text(source.title,180),previousState};
    await saveAndBroadcast(state,{kind:'page-watch-repair',sourceId:source.id});
    return {sourceId:source.id,title:C.text(source.title,180),mode:source.mode,baseline:true,added:0,undoAvailable:true,undoUntil:state.pageWatchRepairUndo.expiresAt};
  });
}
async function undoPageWatchRepair(){
  return queueMutation(async()=>{
    const current=await loadState(),undo=current.pageWatchRepairUndo;
    if(!undo||!Number.isFinite(Date.parse(undo.expiresAt||''))||Date.parse(undo.expiresAt)<=Date.now())throw codedError('The page-watch repair undo has expired.','PAGE_WATCH_REPAIR_UNDO_EXPIRED');
    if(!validPageWatchRepairUndo(undo,current._revision))throw codedError('ProgRSS changed after this repair. Undo was stopped so newer reading and organization would not be overwritten.','PAGE_WATCH_REPAIR_UNDO_STALE');
    const previous=V.normalize(undo.previousState);previous._revision=current._revision;previous.pageWatchRepairUndo=null;
    await applyDestinationPermissions(previous);
    await saveAndBroadcast(previous,{kind:'page-watch-repair-undo'});
    return {sourceId:C.text(undo.sourceId,300),sourceTitle:C.text(undo.sourceTitle,180)};
  });
}
async function clearExpiredPageWatchRepairUndo(){
  return queueMutation(async()=>{
    const state=await loadState();
    if(!state.pageWatchRepairUndo||validPageWatchRepairUndo(state.pageWatchRepairUndo,state._revision))return false;
    state.pageWatchRepairUndo=null;
    await saveAndBroadcast(state,{kind:'page-watch-repair-undo-expired'});
    return true;
  });
}

async function discoverActiveTab() {
  const [tab] = await api.tabs.query({active: true, currentWindow: true});
  if (!tab?.id || !tab.url || !/^https?:/i.test(tab.url)) throw new Error('Open ProgRSS from its toolbar button on a normal public page, or paste the address instead.');
  const [{result}] = await api.scripting.executeScript({
    target: {tabId: tab.id},
    func: () => {
      const tidy = (value, limit = 260) => String(value || '').replace(/\s+/g, ' ').trim().slice(0, limit);
      const recommendations = [];
      const probes = ['main article', 'article', 'main .post', 'main .entry', '.h-entry', '.post', '.entry', '.news-item', 'main li'];
      for (const selector of probes) {
        const nodes = Array.from(document.querySelectorAll(selector));
        if (nodes.length >= 2 && nodes.length <= 200) {
          const examples = nodes.slice(0, 4).map(node => tidy(node.querySelector('h1,h2,h3,h4')?.textContent || node.textContent, 120)).filter(Boolean);
          recommendations.push({kind: 'page', mode: 'cards', selector, titleSelector: 'h1,h2,h3,h4', linkSelector: 'a[href]', title: 'Watch repeated entries', count: nodes.length, examples});
        }
        if (recommendations.length === 3) break;
      }
      const main = document.querySelector('main') || document.body;
      recommendations.push({kind: 'page', mode: 'region', selector: document.querySelector('main') ? 'main' : '', title: 'Watch the primary text region', preview: tidy(main?.textContent, 260)});
      return {
        url: location.href,
        title: document.title || location.hostname,
        links: Array.from(document.querySelectorAll('link[rel~="alternate"][href]')).slice(0, 40).map(link => ({
          href: link.href || link.getAttribute('href') || '',
          rel: link.getAttribute('rel') || '',
          type: link.getAttribute('type') || '',
          title: link.getAttribute('title') || ''
        })),
        recommendations
      };
    }
  });
  const state = await loadState();
  const candidates = annotateCandidates(state, S.chooseCandidates(result.links, result.url));
  const sharedFolders = S.chooseSharedFolders(result.links, result.url);
  const publicationChoices = S.publicationChoices(candidates, sharedFolders, result.url);
  return {
    page: {url: C.safeUrl(result.url), title: C.text(result.title, 160)},
    candidates,
    sharedFolders,
    publicationChoices,
    recommendations: Array.isArray(result.recommendations) ? result.recommendations.slice(0, 4) : []
  };
}


async function captureRenderedPage(payload = {}) {
  const expectedUrl = C.safeUrl(payload.expectedUrl);
  const sourceId = C.text(payload.sourceId, 300);
  const savedRecipe = payload.recipe && typeof payload.recipe === 'object' && !Array.isArray(payload.recipe) ? payload.recipe : {};
  const extensionVersion = C.text(api.runtime.getManifest()?.version, 40) || 'unknown';
  if (!Q?.extract) throw codedError('The bounded rendered-page extractor is unavailable.', 'CAPTURE_EXTRACTOR_UNAVAILABLE');
  const [tab] = await api.tabs.query({active: true, currentWindow: true});
  if (!tab?.id || !tab.url || !/^https?:/i.test(tab.url)) throw codedError('Open the exact watched page in the active tab before capturing it.', 'CAPTURE_PAGE_REQUIRED');
  const normalizeUrl = raw => {
    const url = new URL(String(raw || ''));
    url.hash = '';
    return url.href;
  };
  if (normalizeUrl(tab.url) !== normalizeUrl(expectedUrl)) {
    throw codedError('The active tab is not the exact watched-page address in this request.', 'CAPTURE_PAGE_MISMATCH');
  }
  const [{result}] = await api.scripting.executeScript({
    target: {tabId: tab.id, frameIds: [0]},
    args: [expectedUrl, sourceId, savedRecipe, extensionVersion],
    func: Q.extract,
  });
  if (!result || result.schema !== 'progrss.browser-capture-candidates.v3' || !Array.isArray(result.candidates)) {
    throw codedError('The rendered page did not return bounded capture candidates.', 'CAPTURE_RESULT_INVALID');
  }
  return result;
}

function basicFolderRows(state) {
  const sourceIds = new Set((state.sources || []).map(row => C.text(row?.id, 300)).filter(Boolean));
  const simple = new Map();
  for (const row of state.collections || []) {
    if (!row || typeof row !== 'object' || Array.isArray(row)) continue;
    const id = C.text(row.id, 300);
    const title = C.text(row.title, 180);
    const mode = C.text(row.mode || 'union', 30).toLowerCase();
    if (!id || !title || mode !== 'union' || C.text(row.include, 500) || C.text(row.exclude, 500) || !Array.isArray(row.members)) continue;
    simple.set(id, row);
  }
  const children = new Map([...simple.keys()].map(id => [id, []]));
  const direct = new Map([...simple.keys()].map(id => [id, new Set()]));
  const referenced = new Set();
  for (const [id, row] of simple) {
    for (const member of row.members.slice(0, 500)) {
      const memberId = C.text(member?.id, 300);
      if (member?.kind === 'source' && sourceIds.has(memberId)) direct.get(id).add(memberId);
      else if (member?.kind === 'collection' && simple.has(memberId)) {
        children.get(id).push(memberId);
        referenced.add(memberId);
      }
    }
  }
  const paths = new Map([...simple.keys()].map(id => [id, []]));
  function walk(id, path = [], stack = []) {
    if (stack.includes(id) || stack.length >= 24) return;
    const here = [...path, C.text(simple.get(id).title, 180)];
    const known = paths.get(id);
    if (known.length < 12 && !known.some(candidate => candidate.join('\u0000') === here.join('\u0000'))) known.push(here);
    for (const childId of children.get(id)) walk(childId, here, [...stack, id]);
  }
  [...simple.keys()]
    .filter(id => !referenced.has(id))
    .sort((a, b) => C.text(simple.get(a).title, 180).localeCompare(C.text(simple.get(b).title, 180)))
    .forEach(id => walk(id));
  const visible = new Set([...paths].filter(([, values]) => values.length).map(([id]) => id));
  function closure(id, stack = []) {
    if (stack.includes(id) || stack.length >= 24) return new Set();
    const result = new Set(direct.get(id));
    for (const childId of children.get(id)) {
      if (!visible.has(childId)) continue;
      for (const sourceId of closure(childId, [...stack, id])) result.add(sourceId);
    }
    return result;
  }
  return [...visible].map(id => {
    const path = [...paths.get(id)].sort((a, b) => a.length - b.length || a.join(' › ').localeCompare(b.join(' › ')))[0];
    return {
      id,
      path: path.join(' › '),
      collection: simple.get(id),
      directSourceIds: new Set(direct.get(id)),
      sourceIds: closure(id)
    };
  }).sort((a, b) => a.path.localeCompare(b.path));
}

function folderMembership(rows, sourceId) {
  return {
    direct: rows.filter(row => row.directSourceIds.has(sourceId)).map(row => ({id: row.id, path: row.path})),
    inherited: rows.filter(row => row.sourceIds.has(sourceId) && !row.directSourceIds.has(sourceId)).map(row => ({id: row.id, path: row.path}))
  };
}

function safeFilePart(value, fallback = 'shared-folder') {
  const cleaned = C.text(value, 120).replace(/[\\/:*?"<>|]+/g, '-').replace(/\s+/g, '-').replace(/^-+|-+$/g, '');
  return cleaned || fallback;
}

function simpleFolderSubset(state, collectionId) {
  const rows = basicFolderRows(state);
  const selected = rows.find(row => row.id === C.text(collectionId, 300));
  if (!selected) throw codedError('Choose an existing simple folder before sharing it.', 'FOLDER_NOT_AVAILABLE');
  const visible = new Map(rows.map(row => [row.id, row]));
  const collectionIds = new Set();
  const sourceIds = new Set();
  function collect(id, stack = []) {
    if (collectionIds.has(id) || stack.includes(id) || stack.length >= 24) return;
    const row = visible.get(id);
    if (!row) return;
    collectionIds.add(id);
    for (const member of row.collection.members || []) {
      const memberId = C.text(member?.id, 300);
      if (member?.kind === 'source' && row.directSourceIds.has(memberId)) sourceIds.add(memberId);
      else if (member?.kind === 'collection' && visible.has(memberId)) collect(memberId, [...stack, id]);
    }
  }
  collect(selected.id);
  const sources = (state.sources || []).filter(source => sourceIds.has(C.text(source?.id, 300)) && !source.archivedAt);
  const liveSourceIds = new Set(sources.map(source => C.text(source.id, 300)));
  const collections = (state.collections || []).filter(collection => collectionIds.has(C.text(collection?.id, 300))).map(collection => ({
    ...collection,
    members: (collection.members || []).filter(member => {
      const memberId = C.text(member?.id, 300);
      return member?.kind === 'source' ? liveSourceIds.has(memberId) : member?.kind === 'collection' && collectionIds.has(memberId);
    })
  }));
  if (sources.length > 100 || collections.length > 100) {
    throw codedError('A shared folder can contain at most 100 sources and 100 nested folders. Split this folder before sharing it.', 'SHARED_FOLDER_TOO_LARGE');
  }
  return {selected, rows, sourceIds: liveSourceIds, collectionIds, sources, collections};
}

async function sharedFolderExport(collectionId, format = 'bundle', options = {}, prepared = null) {
  const state = prepared?.state || await loadState();
  assertLibraryWritable('export-shared-folder');
  const subset = prepared?.subset || simpleFolderSubset(state, collectionId);
  const day = new Date().toISOString().slice(0, 10);
  const filePart = safeFilePart(subset.selected.path || subset.selected.collection.title);
  const curator = C.text(options?.curator, 80);
  const note = C.text(options?.note, 280);
  const updateUrl = C.text(options?.updateUrl, 2048);
  const sign = Boolean(options?.sign);
  const sourceNotePlacements = subset.collections.flatMap(collection => (collection.members || [])
    .filter(member => member.kind === 'source' && C.normalizeSourceNoteReason(member.reason) !== undefined)
    .map(member => ({folderId: collection.id, sourceId: member.id})));
  const summary = {
    title: subset.selected.path,
    sources: subset.sources.length,
    feeds: subset.sources.filter(source => source.type === 'rss').length,
    pageWatches: subset.sources.filter(source => source.type === 'page').length,
    folders: subset.collections.length,
    curator,
    updateUrl,
    signed: false,
    sourceNotesIncluded: format !== 'opml',
    sourceNoteCount: sourceNotePlacements.length
  };
  if (format === 'opml') {
    const byId = new Map(subset.collections.map(collection => [C.text(collection.id, 300), collection]));
    const sourceById = new Map(subset.sources.map(source => [C.text(source.id, 300), source]));
    const escape = value => String(value || '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const render = (id, stack = []) => {
      if (stack.includes(id) || stack.length >= 24) return '';
      const collection = byId.get(id);
      if (!collection) return '';
      const children = [];
      for (const member of collection.members || []) {
        const memberId = C.text(member?.id, 300);
        if (member?.kind === 'source') {
          const source = sourceById.get(memberId);
          if (source?.type === 'rss') children.push(`<outline type="rss" text="${escape(source.title)}" xmlUrl="${escape(source.url)}"/>`);
        } else if (member?.kind === 'collection' && byId.has(memberId)) {
          children.push(render(memberId, [...stack, id]));
        }
      }
      return `<outline text="${escape(collection.title)}">${children.join('')}</outline>`;
    };
    const owner = curator ? `<ownerName>${escape(curator)}</ownerName>` : '';
    const raw = `<?xml version="1.0" encoding="UTF-8"?><opml version="2.0"><head><title>${escape(subset.selected.path)}</title><dateCreated>${escape(new Date().toUTCString())}</dateCreated>${owner}</head><body>${render(subset.selected.id)}</body></opml>`;
    return {fileName: `ProgRSS-${filePart}-${day}.opml`, raw, mime: 'text/x-opml', summary: {...summary, sourceNotesIncluded: false, omittedSourceNoteCount: sourceNotePlacements.length, omittedSourceNotePlacements: sourceNotePlacements, omittedPageWatches: summary.pageWatches, signatureOmitted: sign, updateUrlOmitted: Boolean(updateUrl)}};
  }
  const legacy = C.exportBundle({sources: subset.sources, collections: subset.collections}, subset.selected.id);
  legacy.title = subset.selected.path;
  const existingOrigin = F.normalizeOrigin(subset.selected.collection?.sharedFolderOrigin, false);
  const publicationId = existingOrigin && /^[A-Za-z0-9_-]{1,100}$/.test(String(existingOrigin.publicationId || ''))
    ? String(existingOrigin.publicationId)
    : subset.selected.id;
  let bundle = await F.create(C.validateBundle(legacy), {
    publicationId,
    curator,
    note,
    updateUrl,
    ...(options?.exportedAt ? {exportedAt: options.exportedAt} : {})
  });
  if (sign) bundle = await F.sign(bundle);
  const checked = await F.validate(bundle);
  const raw = JSON.stringify(checked.document, null, 2);
  if (byteLength(raw) > C.LIMIT.bundle) throw codedError('This shared folder is larger than the 650 KB bundle limit.', 'SHARED_FOLDER_TOO_LARGE');
  const identity = checked.document.integrity.signature || null;
  return {
    fileName: `ProgRSS-${filePart}-${day}.json`,
    raw,
    mime: 'application/json',
    summary: {
      ...summary,
      signed: Boolean(identity),
      signatureState: identity ? 'verified' : 'unsigned',
      keyId: identity?.keyId || '',
      fingerprint: identity ? F.compactFingerprint(identity.keyId) : '',
      publicationId,
      updateUrl: C.text(checked.provenance?.updateUrl || checked.document?.distribution?.updateUrl, 2048),
      digest: checked.document.integrity.digest
    }
  };
}

async function folderEditionExport(collectionId, options = {}, prepared = null) {
  const state = prepared?.state || await loadState();
  assertLibraryWritable('export-folder-edition');
  const subset = prepared?.subset || simpleFolderSubset(state, collectionId);
  const day = new Date().toISOString().slice(0, 10);
  const filePart = safeFilePart(subset.selected.path || subset.selected.collection.title, 'recent-updates');
  const selectedItems = (state.items || []).filter(item => subset.sourceIds.has(C.text(item?.sourceId, 300)));
  const editionState = {
    sources: subset.sources,
    collections: subset.collections,
    items: selectedItems
  };
  const result = C.makeFolderEdition(editionState, subset.selected.id, {
    title: subset.selected.path,
    curator: C.text(options?.curator, 80),
    note: C.text(options?.note, 280),
    limit: Math.max(1, Math.min(100, Math.floor(Number(options?.limit) || 100))),
    generatedAt: options?.generatedAt || new Date().toISOString()
  });
  const raw = JSON.stringify(result.document, null, 2);
  if (byteLength(raw) > C.LIMIT.edition) {
    throw codedError('This recent-updates feed is larger than the 250 KB public-feed limit.', 'FOLDER_EDITION_TOO_LARGE');
  }
  return {
    fileName: `ProgRSS-${filePart}-${day}-updates.json`,
    raw,
    mime: 'application/feed+json',
    summary: result.summary
  };
}

async function publicationSiteExport(collectionId, options = {}) {
  const state = await loadState();
  assertLibraryWritable('export-publication-site');
  const subset = simpleFolderSubset(state, collectionId);
  const exportedAt = new Date().toISOString();
  const prepared = {state, subset};
  const bundle = await sharedFolderExport(collectionId, 'bundle', {...options, exportedAt}, prepared);
  const includeUpdates = Boolean(options?.includeUpdates);
  const edition = includeUpdates
    ? await folderEditionExport(collectionId, {...options, generatedAt: exportedAt}, prepared)
    : null;
  return {
    bundle,
    edition,
    summary: {
      includeUpdates,
      updates: edition?.summary?.items || 0,
      reviewedRevision: Number(state._revision) || 0,
      network: false,
      writes: false
    }
  };
}

function sharedFolderPageRecipeKey(source) {
  if (source?.type !== 'page') return '';
  const recipe = C.cleanRecipe(source);
  return stableJson({type: recipe.type, url: recipe.url, mode: recipe.mode, selector: recipe.selector, titleSelector: recipe.titleSelector, linkSelector: recipe.linkSelector, include: recipe.include, exclude: recipe.exclude, threshold: recipe.threshold, ignoreNumbers: recipe.ignoreNumbers});
}

async function parseSharedFolder(raw) {
  if (typeof raw !== 'string' || byteLength(raw) > C.LIMIT.bundle) throw codedError('That shared folder is larger than 650 KB.', 'INVALID_SHARED_FOLDER');
  let document;
  try { document = JSON.parse(raw); } catch { throw codedError('That shared folder is not readable JSON.', 'INVALID_SHARED_FOLDER'); }
  let checked;
  try { checked = await F.validate(document); } catch (error) { throw codedError(error.message, 'INVALID_SHARED_FOLDER'); }
  const bundle = checked.bundle;
  if (!bundle.collections.length) throw codedError('That file does not contain a folder.', 'INVALID_SHARED_FOLDER');
  for (const collection of bundle.collections) {
    if (collection.mode !== 'union' || collection.include || collection.exclude) {
      throw codedError('This file contains an advanced collection. Add it through the Advanced Workbench instead.', 'ADVANCED_SHARED_FOLDER');
    }
  }
  const referenced = new Set(bundle.collections.flatMap(collection => collection.members.filter(member => member.kind === 'collection').map(member => member.id)));
  const roots = bundle.collections.filter(collection => !referenced.has(collection.id));
  const rootId = bundle.root || (roots.length === 1 ? roots[0].id : '');
  if (!rootId || !bundle.collections.some(collection => collection.id === rootId)) throw codedError('This shared folder does not identify one clear top-level folder.', 'INVALID_SHARED_FOLDER');
  const reachableCollections = new Set();
  const reachableSources = new Set();
  const byCollection = new Map(bundle.collections.map(collection => [collection.id, collection]));
  function walk(id) {
    if (reachableCollections.has(id)) return;
    const collection = byCollection.get(id);
    if (!collection) throw codedError('The shared folder contains a missing nested folder.', 'INVALID_SHARED_FOLDER');
    reachableCollections.add(id);
    for (const member of collection.members) {
      if (member.kind === 'source') reachableSources.add(member.id);
      else walk(member.id);
    }
  }
  walk(rootId);
  if (reachableCollections.size !== bundle.collections.length || reachableSources.size !== bundle.sources.length) {
    throw codedError('The shared folder contains unrelated extra records. Nothing was added.', 'INVALID_SHARED_FOLDER');
  }
  const provenance = {...checked.provenance};
  if (!provenance.publicationId) provenance.publicationId = rootId;
  return {
    ...bundle,
    root: rootId,
    title: bundle.title || byCollection.get(rootId)?.title || 'Shared folder',
    documentSchema: checked.document.schema,
    provenance
  };
}

function sharedFolderSelection(fullBundle, selectedFolderId = '') {
  const fullContents = F.contents(fullBundle);
  const availableSections = fullContents.folders
    .filter(folder => !folder.isRoot && Number(folder.branchSources) > 0)
    .map(folder => ({
      id: folder.id,
      title: folder.title,
      path: folder.path,
      sourceCount: Number(folder.branchSources) || 0,
      feedCount: Number(folder.branchFeeds) || 0,
      pageWatchCount: Number(folder.branchPageWatches) || 0,
      folderCount: Number(folder.branchFolders) || 0
    }));
  const requested = C.text(selectedFolderId, 300);
  if (!requested || requested === fullBundle.root) {
    return {bundle: fullBundle, fullContents, availableSections, independentExcerpt: false, selectedFolder: null};
  }
  const selectedFolder = fullContents.folders.find(folder => folder.id === requested);
  if (!selectedFolder) throw codedError('That folder section is no longer present in this source list.', 'SHARED_FOLDER_SECTION_NOT_FOUND');
  if (!Number(selectedFolder.branchSources)) throw codedError('That folder section does not contain a source to add.', 'SHARED_FOLDER_SECTION_EMPTY');
  let excerpt;
  try { excerpt = F.branch(fullBundle, requested); }
  catch (error) { throw codedError(error.message, 'SHARED_FOLDER_SECTION_INVALID'); }
  return {
    bundle: {
      ...excerpt,
      documentSchema: fullBundle.documentSchema,
      provenance: {...(fullBundle.provenance || {})}
    },
    fullContents,
    availableSections,
    independentExcerpt: true,
    selectedFolder
  };
}

async function sharedFolderPlan(raw, state, selectedFolderId = '') {
  const fullBundle = await parseSharedFolder(raw);
  const selection = sharedFolderSelection(fullBundle, selectedFolderId);
  const bundle = selection.bundle;
  const independentExcerpt = selection.independentExcerpt;
  const existingIds = new Set([...(state.sources || []), ...(state.collections || [])].map(row => C.text(row?.id, 300)).filter(Boolean));
  const idMap = new Map();
  const sourceMap = [];
  const collectionMap = [];
  const reused = [];
  const incomingSources = [];
  const currentPageRecipes = new Map();
  const plannedRss = new Map();
  const plannedPages = new Map();
  const contentsStates = new Map();
  let duplicateInFileSources = 0;
  for (const source of state.sources || []) {
    if (source?.archivedAt || source?.type !== 'page') continue;
    try { currentPageRecipes.set(sharedFolderPageRecipeKey(source), source); } catch {}
  }
  for (const source of bundle.sources) {
    let existing = null;
    const recipeKey = source.type === 'page' ? sharedFolderPageRecipeKey(source) : source.url;
    if (source.type === 'rss') {
      for (const candidate of state.sources || []) {
        if (candidate?.archivedAt || candidate?.type !== 'rss') continue;
        if (sourceAddressAliases(candidate).has(source.url)) { existing = candidate; break; }
      }
    } else {
      existing = currentPageRecipes.get(recipeKey) || null;
    }
    if (existing) {
      idMap.set(source.id, existing.id);
      sourceMap.push({remoteId: source.id, localId: existing.id, created: false});
      reused.push({incomingId: source.id, sourceId: existing.id, title: C.text(existing.title, 180), type: existing.type});
      contentsStates.set(source.id, 'already-here');
      continue;
    }
    const planned = source.type === 'rss' ? plannedRss.get(recipeKey) : plannedPages.get(recipeKey);
    if (planned) {
      idMap.set(source.id, planned.id);
      sourceMap.push({remoteId: source.id, localId: planned.id, created: false});
      duplicateInFileSources++;
      contentsStates.set(source.id, 'same-incoming-source');
      continue;
    }
    let id = source.id;
    while (existingIds.has(id)) id = C.uid('shared');
    existingIds.add(id);
    idMap.set(source.id, id);
    const prepared = {...source, id, enabled: false, lastScan: '', lastError: '', lastSuccessfulAt: '', lastNewAt: '', lastProblemAt: '', lastProblem: '', createdAt: new Date().toISOString(), origin: independentExcerpt ? 'shared-folder-section' : 'shared-folder'};
    incomingSources.push(prepared);
    sourceMap.push({remoteId: source.id, localId: id, created: true});
    contentsStates.set(source.id, 'new-paused');
    if (source.type === 'rss') plannedRss.set(recipeKey, prepared);
    else plannedPages.set(recipeKey, prepared);
  }
  for (const collection of bundle.collections) {
    let id = collection.id;
    while (existingIds.has(id)) id = C.uid('folder');
    existingIds.add(id);
    idMap.set(collection.id, id);
    collectionMap.push({remoteId: collection.id, localId: id});
  }
  const importedAt = new Date().toISOString();
  const baseline = independentExcerpt ? null : F.createBaseline(bundle, sourceMap, collectionMap);
  const origin = independentExcerpt ? null : F.createOrigin(bundle.provenance || {}, importedAt, baseline);
  const incomingCollections = bundle.collections.map(collection => {
    const members = sharedFolderUniqueMembers(collection.members.map(member => ({
      kind: member.kind,
      id: idMap.get(member.id),
      ...(member.kind === 'source' && member.reason !== undefined ? {reason: member.reason} : {})
    })).filter(member => member.id));
    const added = {...collection, id: idMap.get(collection.id), members};
    if (collection.id === bundle.root && origin) added.sharedFolderOrigin = origin;
    return added;
  });
  const rootId = idMap.get(bundle.root);
  const sourceRoom = Math.max(0, C.LIMIT.source - (state.sources || []).length);
  const collectionRoom = Math.max(0, C.LIMIT.collection - (state.collections || []).length);
  let reason = '';
  if (incomingSources.length > sourceRoom) reason = `ProgRSS has room for ${sourceRoom} more source${sourceRoom === 1 ? '' : 's'}, but this folder would add ${incomingSources.length}.`;
  else if (incomingCollections.length > collectionRoom) reason = `ProgRSS has room for ${collectionRoom} more folder${collectionRoom === 1 ? '' : 's'}, but this file would add ${incomingCollections.length}.`;
  const origins = [...new Set(incomingSources.map(source => new URL(source.url).origin))].sort();
  const provenance = bundle.provenance || {};
  const contents = F.contents(bundle, contentsStates);
  return {
    bundle,
    sources: incomingSources,
    collections: incomingCollections,
    rootId,
    reviewedRevision: Number(state._revision) || 0,
    preview: {
      schema: 'progrss.shared-folder.preview.v3',
      mode: 'new',
      documentSchema: bundle.documentSchema || F.LEGACY_SCHEMA,
      title: C.text(bundle.title, 180),
      sourceCount: bundle.sources.length,
      feedCount: bundle.sources.filter(source => source.type === 'rss').length,
      pageWatchCount: bundle.sources.filter(source => source.type === 'page').length,
      newSources: incomingSources.length,
      reusedSources: reused.length,
      duplicateInFileSources,
      newFeeds: incomingSources.filter(source => source.type === 'rss').length,
      newPageWatches: incomingSources.filter(source => source.type === 'page').length,
      folders: incomingCollections.length,
      origins: origins.length,
      canImport: !reason,
      reason,
      reviewedRevision: Number(state._revision) || 0,
      startsPaused: true,
      network: false,
      writes: false,
      selectionMode: independentExcerpt ? 'section' : 'all',
      independentExcerpt,
      updateLinked: !independentExcerpt,
      selectedFolderId: independentExcerpt ? C.text(selection.selectedFolder?.id, 300) : '',
      selectedFolderPath: independentExcerpt ? C.text(selection.selectedFolder?.path, 1000) : '',
      parentTitle: independentExcerpt ? C.text(fullBundle.title, 180) : '',
      parentPublicationId: independentExcerpt ? C.text(provenance.publicationId, 100) : '',
      fullSourceCount: selection.fullContents.sourceCount,
      fullFolderCount: selection.fullContents.folderCount,
      availableSections: selection.availableSections,
      publicationId: independentExcerpt ? '' : C.text(provenance.publicationId, 100),
      curator: C.text(provenance.curator, 80),
      note: C.text(provenance.note, 280),
      issuedAt: C.text(provenance.issuedAt, 60),
      digest: C.text(provenance.digest, 80),
      signatureState: ['verified', 'unsigned', 'legacy'].includes(provenance.signatureState) ? provenance.signatureState : 'legacy',
      algorithm: C.text(provenance.algorithm, 40),
      keyId: C.text(provenance.keyId, 100),
      fingerprint: provenance.keyId ? F.compactFingerprint(provenance.keyId) : '',
      updateUrl: independentExcerpt ? '' : C.text(provenance.updateUrl, 2048),
      manualUpdateCheck: !independentExcerpt && Boolean(provenance.updateUrl),
      contents
    }
  };
}
function sharedFolderPortableSource(source, remoteId) {
  try { return C.cleanRecipe({...source, id: remoteId}); }
  catch { return null; }
}

function sharedFolderSourceAcquisitionKey(source) {
  const clean = C.cleanRecipe(source);
  return stableJson({
    type: clean.type, url: clean.url, mode: clean.mode, selector: clean.selector,
    titleSelector: clean.titleSelector, linkSelector: clean.linkSelector,
    include: clean.include, exclude: clean.exclude, threshold: clean.threshold,
    ignoreNumbers: clean.ignoreNumbers
  });
}

function sharedFolderMemberKey(member) {
  return member && ['source', 'collection'].includes(member.kind) && member.id ? `${member.kind}:${member.id}` : '';
}

function sharedFolderUniqueMembers(rows) {
  const seen = new Map(), result = [];
  for (const member of rows || []) {
    const key = sharedFolderMemberKey(member);
    if (!key) continue;
    if (member.kind !== 'source' && Object.prototype.hasOwnProperty.call(member, 'reason')) throw Error('Only a direct source placement may carry a Source Note');
    const projected = {kind: member.kind, id: member.id};
    if (member.kind === 'source' && Object.prototype.hasOwnProperty.call(member, 'reason')) {
      const reason = C.normalizeSourceNoteReason(member.reason);
      if (reason !== undefined) projected.reason = reason;
    }
    const previous = seen.get(key);
    if (previous) {
      if (stableJson(previous) !== stableJson(projected)) throw Error('Conflicting Source Notes for the same direct placement');
      continue;
    }
    seen.set(key, projected);
    result.push(projected);
  }
  return result;
}

function sharedFolderTranslateMembers(collection, sourceMap, collectionMap) {
  return sharedFolderUniqueMembers((collection?.members || []).map(member => ({
    kind: member.kind,
    id: member.kind === 'source' ? sourceMap.get(member.id) : collectionMap.get(member.id),
    ...(member.kind === 'source' && member.reason !== undefined ? {reason: member.reason} : {})
  })).filter(member => member.id));
}

function sharedFolderCollectionMeaning(collection, members = null) {
  return {
    title: C.text(collection?.title, 130) || 'Untitled collection',
    mode: collection?.mode === 'union' ? 'union' : C.text(collection?.mode, 40),
    include: C.text(collection?.include, 280),
    exclude: C.text(collection?.exclude, 280),
    author: C.text(collection?.author, 80) || 'anonymous',
    members: sharedFolderUniqueMembers(members || collection?.members || [])
  };
}

function sharedFolderUpdateContents(bundle, baseline, sourceStates, folderStates) {
  const report = F.contents(bundle, sourceStates, folderStates);
  if (!baseline) return report;
  const prior = F.contents({
    schema: F.LEGACY_SCHEMA, exportedAt: '', root: baseline.root, title: baseline.title,
    sources: baseline.sources, collections: baseline.collections
  });
  const incomingSources = new Set(bundle.sources.map(source => source.id));
  const incomingFolders = new Set(bundle.collections.map(folder => folder.id));
  const removedSources = prior.sources
    .filter(source => !incomingSources.has(source.id))
    .map(source => ({...source, state: 'removed-from-list'}));
  const removedFolders = prior.folders
    .filter(folder => !incomingFolders.has(folder.id))
    .map(folder => ({...folder, state: 'removed-from-list'}));
  report.sources.push(...removedSources);
  report.folders.push(...removedFolders);
  report.removedSourceCount = removedSources.length;
  report.removedFolderCount = removedFolders.length;
  return report;
}

function sharedFolderTrustContinuity(origin, provenance) {
  const previous = origin?.signatureState || 'legacy';
  const next = provenance?.signatureState || 'legacy';
  if (previous === 'verified' && next === 'verified') {
    const same = origin.algorithm === provenance.algorithm && origin.keyId === provenance.keyId;
    return {
      state: same ? 'same-key' : 'key-change',
      requiresAcknowledgement: !same,
      message: same
        ? 'The same signing key signed this copy.'
        : 'This copy uses a different signing key. The signature is valid, but ProgRSS cannot know why the key changed.'
    };
  }
  if (previous === 'verified' && next !== 'verified') {
    return {
      state: 'signed-to-unsigned',
      requiresAcknowledgement: true,
      message: 'The local copy was signed, but this copy is not. Updating would accept a loss of signer continuity.'
    };
  }
  if (previous !== 'verified' && next === 'verified') {
    return {state: 'newly-signed', requiresAcknowledgement: false, message: 'This copy adds a valid signature where the earlier local copy had none.'};
  }
  if (previous === 'legacy' || next === 'legacy') {
    return {state: 'legacy', requiresAcknowledgement: false, message: 'At least one copy uses the older format without signature continuity.'};
  }
  return {state: 'unsigned', requiresAcknowledgement: false, message: 'Both copies are unsigned; their checked content digests still distinguish exact contents.'};
}

function sharedFolderFindExistingSource(state, recipe, plannedByRecipe) {
  const key = sharedFolderSourceAcquisitionKey(recipe);
  if (plannedByRecipe.has(key)) return plannedByRecipe.get(key);
  for (const source of state.sources || []) {
    if (!source || source.archivedAt || source.type !== recipe.type) continue;
    try {
      if (recipe.type === 'rss') {
        if (sourceAddressAliases(source).has(recipe.url)) return source;
      } else if (sharedFolderPageRecipeKey(source) === sharedFolderPageRecipeKey(recipe)) {
        return source;
      }
    } catch {}
  }
  return null;
}

function sharedFolderPublicationMatches(state, publicationId) {
  return (state.collections || []).flatMap(collection => {
    const origin = F.normalizeOrigin(collection?.sharedFolderOrigin, false);
    return origin?.publicationId === publicationId ? [{collection, origin}] : [];
  });
}

function sharedFolderMergeHost(value) {
  try { return new URL(String(value || '')).hostname.toLowerCase(); }
  catch { return ''; }
}

async function sharedFolderRecipeEvidence(source) {
  if (!source || typeof source !== 'object' || Array.isArray(source)) return {present: false};
  const clean = C.cleanRecipe(source);
  const payload = {
    type: clean.type,
    host: sharedFolderMergeHost(clean.url),
    mode: clean.mode,
    selectorPresent: Boolean(clean.selector),
    titleSelectorPresent: Boolean(clean.titleSelector),
    linkSelectorPresent: Boolean(clean.linkSelector),
    includePresent: Boolean(clean.include),
    excludePresent: Boolean(clean.exclude),
    threshold: clean.threshold,
    ignoreNumbers: clean.ignoreNumbers
  };
  return {present: true, ...payload, fingerprint: await canonicalDigest(payload)};
}

function sharedFolderThreeWay(baseline, local, incoming) {
  if (stableJson(local) === stableJson(baseline) && stableJson(incoming) === stableJson(baseline)) return 'unchanged';
  if (stableJson(local) === stableJson(baseline) && stableJson(incoming) !== stableJson(baseline)) return 'curatorOnly';
  if (stableJson(incoming) === stableJson(baseline) && stableJson(local) !== stableJson(baseline)) return 'recipientOnly';
  if (stableJson(local) === stableJson(incoming)) return 'agreed';
  return 'conflicts';
}

async function sharedFolderUpdatePlan(raw, state, targetRootId = '') {
  const bundle = await parseSharedFolder(raw);
  const publicationId = C.text(bundle.provenance?.publicationId, 100) || bundle.root;
  const allMatches = sharedFolderPublicationMatches(state, publicationId);
  const requested = C.text(targetRootId, 300);
  const matches = requested ? allMatches.filter(row => row.collection.id === requested) : allMatches;
  if (!allMatches.length) return null;
  const reviewedRevision = Number(state._revision) || 0;
  const basePreview = {
    schema: 'progrss.shared-folder-update.preview.v2',
    mode: 'update', publicationId, title: C.text(bundle.title, 180),
    sourceCount: bundle.sources.length,
    feedCount: bundle.sources.filter(source => source.type === 'rss').length,
    pageWatchCount: bundle.sources.filter(source => source.type === 'page').length,
    folders: bundle.collections.length,
    curator: C.text(bundle.provenance?.curator, 80), note: C.text(bundle.provenance?.note, 280),
    issuedAt: C.text(bundle.provenance?.issuedAt, 60), digest: C.text(bundle.provenance?.digest, 80),
    signatureState: bundle.provenance?.signatureState || 'legacy',
    algorithm: C.text(bundle.provenance?.algorithm, 40), keyId: C.text(bundle.provenance?.keyId, 100),
    fingerprint: bundle.provenance?.keyId ? F.compactFingerprint(bundle.provenance.keyId) : '',
    updateUrl: C.text(bundle.provenance?.updateUrl, 2048),
    manualUpdateCheck: Boolean(bundle.provenance?.updateUrl),
    localCopies: allMatches.map(row => ({rootId: row.collection.id, title: C.text(row.collection.title, 180), originSchema: row.origin.schema})),
    reviewedRevision, network: false, writes: false, canImportSeparately: true,
    contents: F.contents(bundle)
  };
  if (!requested && allMatches.length > 1) {
    return {preview: {...basePreview, mode: 'ambiguous', canUpdate: false, reason: 'More than one local folder has this publication identity. Keep the local versions or import this copy separately; ProgRSS will not guess which folder to replace.'}};
  }
  if (requested && !matches.length) {
    return {preview: {...basePreview, mode: 'not-found', canUpdate: false, reason: 'The selected local publication copy is no longer available.'}};
  }
  if (matches.length !== 1) {
    return {preview: {...basePreview, mode: 'not-found', canUpdate: false, reason: 'The selected local publication copy is no longer available.'}};
  }
  const target = matches[0].collection;
  const origin = matches[0].origin;
  const preview = {...basePreview, targetRootId: target.id, localTitle: C.text(target.title, 180), previous: {
    curator: origin.curator, note: origin.note, issuedAt: origin.issuedAt, digest: origin.digest,
    signatureState: origin.signatureState, algorithm: origin.algorithm || '', keyId: origin.keyId || '',
    fingerprint: origin.keyId ? F.compactFingerprint(origin.keyId) : '', updateUrl: C.text(origin.updateUrl, 2048)
  }};
  const trust = sharedFolderTrustContinuity(origin, bundle.provenance || {});
  preview.trust = trust;
  preview.requiresTrustAcknowledgement = trust.requiresAcknowledgement;
  if (!origin.baseline) {
    return {preview: {...preview, mode: 'older-local-copy', canUpdate: false, reason: 'This folder was imported before ProgRSS stored a safe update baseline. Its local edits cannot be distinguished from the shared copy, so it will not be overwritten.'}};
  }
  const baseline = origin.baseline;
  if (baseline.root !== bundle.root) {
    return {preview: {...preview, mode: 'root-changed', canUpdate: false, reason: 'This copy changes the publication’s top-level folder identity. Import it separately so the existing folder is not replaced by guesswork.'}};
  }
  const previousTime = Date.parse(origin.issuedAt || '');
  const incomingTime = Date.parse(bundle.provenance?.issuedAt || '');
  if (Number.isFinite(previousTime) && Number.isFinite(incomingTime) && incomingTime < previousTime) {
    return {preview: {...preview, mode: 'older-copy', canUpdate: false, reason: 'This copy was issued before the copy already imported here. ProgRSS will not roll a publication backward.'}};
  }
  if (Number.isFinite(previousTime) && Number.isFinite(incomingTime) && incomingTime === previousTime && origin.digest && bundle.provenance?.digest && origin.digest !== bundle.provenance.digest) {
    return {preview: {...preview, mode: 'conflicting-copy', canUpdate: false, reason: 'This copy has the same issue time as the local publication but different contents. Import it separately while the conflict is investigated.'}};
  }

  const oldSourceByRemote = new Map(baseline.sources.map(source => [source.id, source]));
  const oldCollectionByRemote = new Map(baseline.collections.map(collection => [collection.id, collection]));
  const oldSourceRows = new Map(baseline.sourceMap.map(row => [row.remoteId, row]));
  const oldCollectionRows = new Map(baseline.collectionMap.map(row => [row.remoteId, row]));
  const stateSourceById = new Map((state.sources || []).map(source => [C.text(source?.id, 300), source]));
  const stateCollectionById = new Map((state.collections || []).map(collection => [C.text(collection?.id, 300), collection]));
  const oldSourceLocal = new Map(baseline.sourceMap.map(row => [row.remoteId, row.localId]));
  const oldCollectionLocal = new Map(baseline.collectionMap.map(row => [row.remoteId, row.localId]));
  if (oldCollectionLocal.get(baseline.root) !== target.id) {
    return {preview: {...preview, mode: 'mapping-changed', canUpdate: false, reason: 'The stored publication map no longer points to this top-level folder. Import this copy separately rather than risking the wrong local folder.'}};
  }
  for (const row of baseline.collectionMap) {
    const local = stateCollectionById.get(row.localId);
    if (!local) {
      return {preview: {...preview, mode: 'local-folder-missing', canUpdate: false, reason: 'A folder from the imported publication was removed locally. ProgRSS will not recreate or replace that deliberate deletion automatically.'}};
    }
    if (local.mode !== 'union' || C.text(local.include, 280) || C.text(local.exclude, 280)) {
      return {preview: {...preview, mode: 'advanced-local-fork', canUpdate: false, reason: 'A folder in this publication now uses Advanced Workbench rules. Import the new copy separately so those rules are not flattened.'}};
    }
  }

  const mergeGroups = {
    curatorOnly: [], recipientOnly: [], agreed: [], conflicts: [],
    additions: [], removals: [], recipeChanges: []
  };
  const mergeCounts = Object.fromEntries(Object.keys(mergeGroups).map(key => [key, 0]));
  const mergeOmitted = Object.fromEntries(Object.keys(mergeGroups).map(key => [key, 0]));
  const conflictOperations = {};
  const recordMerge = (group, entry, limit = group === 'conflicts' ? 400 : 80) => {
    mergeCounts[group]++;
    if (mergeGroups[group].length < limit) mergeGroups[group].push({...entry});
    else mergeOmitted[group]++;
  };
  const fieldChange = ({kind, remoteId, localId, label, field, fieldLabel, baselineValue, localValue, incomingValue, allowConflictChoice = true, ownerNote = '', forceLocalOwnership = false}) => {
    let classification = sharedFolderThreeWay(baselineValue, localValue, incomingValue);
    if (classification === 'unchanged') return classification;
    const id = `${kind}:${remoteId}:${field}`;
    const entry = {
      id, kind, label: C.text(label, 180) || (kind === 'source' ? 'Untitled source' : 'Untitled folder'),
      field, fieldLabel, baseline: baselineValue, local: localValue, incoming: incomingValue,
      ownerNote: C.text(ownerNote, 240)
    };
    if (forceLocalOwnership && classification !== 'agreed') {
      classification = 'recipientOnly';
      Object.assign(entry, {
        default: 'keep-local',
        summary: `The curator changed ${fieldLabel.toLowerCase()}, but this pre-existing local source keeps its own value.`,
        policy: 'pre-existing-local-source'
      });
      recordMerge(classification, entry);
      return classification;
    }
    if (classification === 'curatorOnly') {
      Object.assign(entry, {default: 'use-curator', summary: `Curator changed ${fieldLabel.toLowerCase()} from “${baselineValue}” to “${incomingValue}”.`});
    } else if (classification === 'recipientOnly') {
      Object.assign(entry, {default: 'keep-local', summary: `You changed ${fieldLabel.toLowerCase()} from “${baselineValue}” to “${localValue}”; the curator did not change it.`});
    } else if (classification === 'agreed') {
      Object.assign(entry, {default: 'already-agrees', summary: `You and the curator both changed ${fieldLabel.toLowerCase()} to “${localValue}”.`});
    } else if (allowConflictChoice) {
      Object.assign(entry, {default: 'decision-required', summary: `You and the curator changed ${fieldLabel.toLowerCase()} differently.`, choices: ['keep-local', 'use-curator']});
      conflictOperations[id] = {kind, localId, field, curatorValue: incomingValue};
    } else {
      classification = 'recipientOnly';
      Object.assign(entry, {
        default: 'keep-local',
        summary: `The curator changed ${fieldLabel.toLowerCase()}, but this pre-existing local source keeps its own value.`,
        policy: 'pre-existing-local-source'
      });
    }
    recordMerge(classification, entry);
    return classification;
  };
  const recordMembership = ({folderId, folderLabel, memberKey, memberLabel, baselinePresent, localPresent, incomingPresent}) => {
    let classification = sharedFolderThreeWay(baselinePresent, localPresent, incomingPresent);
    if (classification === 'unchanged') return;
    const [kind, memberId] = memberKey.split(':', 2);
    const incomingVerb = incomingPresent ? 'included' : 'removed';
    const localVerb = localPresent ? 'included' : 'removed';
    const entry = {
      id: `folder:${folderId}:member:${kind}:${memberId}`,
      kind: 'folder-membership', label: C.text(folderLabel, 180) || 'Untitled folder',
      field: 'members', fieldLabel: 'Folder placement',
      memberKind: kind.includes('source') ? 'source' : 'folder',
      memberLabel: C.text(memberLabel, 180) || (kind.includes('source') ? 'Untitled source' : 'Untitled folder'),
      baseline: baselinePresent, local: localPresent, incoming: incomingPresent
    };
    if (classification === 'curatorOnly') Object.assign(entry, {default: 'use-curator', summary: `Curator ${incomingVerb} ${entry.memberLabel} in ${entry.label}.`});
    else if (classification === 'recipientOnly') Object.assign(entry, {default: 'keep-local', summary: `You ${localVerb} ${entry.memberLabel} in ${entry.label}; that local placement stays.`});
    else if (classification === 'agreed') Object.assign(entry, {default: 'already-agrees', summary: `You and the curator both ${localVerb} ${entry.memberLabel} in ${entry.label}.`});
    else {
      classification = 'recipientOnly';
      Object.assign(entry, {default: 'keep-local', summary: `Folder placement for ${entry.memberLabel} differs; the local placement stays.`});
    }
    recordMerge(classification, entry);
  };
  const recordSourceNote = ({folderRemoteId, folderLocalId, folderLabel, sourceRemoteId, sourceLocalId, sourceLabel, baselineValue, localValue, incomingValue}) => {
    const classification = sharedFolderThreeWay(baselineValue, localValue, incomingValue);
    if (classification === 'unchanged') return classification;
    const id = `placement:${folderRemoteId}:source:${sourceRemoteId}:reason`;
    const entry = {
      id, kind: 'source-note', label: C.text(sourceLabel, 180) || 'Untitled source',
      folderLabel: C.text(folderLabel, 180) || 'Untitled folder', field: 'reason',
      fieldLabel: 'Reason for this source in this folder',
      baseline: baselineValue ?? null, local: localValue ?? null, incoming: incomingValue ?? null,
      placement: {folderId: folderRemoteId, sourceId: sourceRemoteId}
    };
    if (classification === 'curatorOnly') Object.assign(entry, {default: 'use-curator', summary: 'The curator changed the reason on this direct folder-to-source placement.'});
    else if (classification === 'recipientOnly') Object.assign(entry, {default: 'keep-local', summary: 'You changed the reason on this placement; the curator did not, so yours stays.'});
    else if (classification === 'agreed') Object.assign(entry, {default: 'already-agrees', summary: 'You and the curator made the same change to this placement reason.'});
    else {
      Object.assign(entry, {default: 'decision-required', summary: 'You and the curator changed this placement reason differently.', choices: ['keep-local', 'use-curator']});
      conflictOperations[id] = {kind: 'placement-reason', localId: folderLocalId, sourceId: sourceLocalId, field: 'reason', curatorValue: incomingValue ?? null};
    }
    recordMerge(classification, entry);
    return classification;
  };

  if ((origin.curator || '') !== (bundle.provenance?.curator || '')) {
    recordMerge('curatorOnly', {
      id: 'publication:curator', kind: 'publication', label: preview.title,
      field: 'curator', fieldLabel: 'Curator name', baseline: origin.curator || '', local: origin.curator || '', incoming: bundle.provenance?.curator || '',
      default: 'use-curator', summary: 'Curator wording changed in this copy.'
    });
  }
  if ((origin.note || '') !== (bundle.provenance?.note || '')) {
    recordMerge('curatorOnly', {
      id: 'publication:note', kind: 'publication', label: preview.title,
      field: 'note', fieldLabel: 'Curator note', baseline: origin.note || '', local: origin.note || '', incoming: bundle.provenance?.note || '',
      default: 'use-curator', summary: 'The curator changed the route explanation.'
    });
  }
  if (C.text(origin.updateUrl, 2048) !== C.text(bundle.provenance?.updateUrl, 2048)) {
    recordMerge('curatorOnly', {
      id: 'publication:update-url', kind: 'publication', label: preview.title,
      field: 'updateUrl', fieldLabel: 'Future-copy address',
      baseline: sharedFolderMergeHost(origin.updateUrl), local: sharedFolderMergeHost(origin.updateUrl), incoming: sharedFolderMergeHost(bundle.provenance?.updateUrl),
      default: 'use-curator', summary: 'The curator changed where later copies can be checked; ProgRSS will use it only after an explicit check.'
    });
  }

  const existingIds = new Set([...(state.sources || []), ...(state.collections || [])].map(row => C.text(row?.id, 300)).filter(Boolean));
  const plannedByRecipe = new Map();
  const nextSourceLocal = new Map();
  const nextSourceRows = [];
  const sourceAdds = [];
  const sourcePatches = [];
  const updateSourceStates = new Map();
  let sourceRecipesChanged = 0;
  let sourceMetadataChanged = 0;
  let changedRecipeNewSources = 0;
  let sourcesAdded = 0;
  let localSourceOverrides = 0;
  let reusedLocalSources = 0;
  let reusedSourceLabelsPreserved = 0;
  for (const incoming of bundle.sources) {
    const prior = oldSourceByRemote.get(incoming.id);
    const priorRow = oldSourceRows.get(incoming.id);
    if (prior && priorRow && sharedFolderSourceAcquisitionKey(prior) === sharedFolderSourceAcquisitionKey(incoming)) {
      const local = stateSourceById.get(priorRow.localId);
      nextSourceLocal.set(incoming.id, priorRow.localId);
      nextSourceRows.push({remoteId: incoming.id, localId: priorRow.localId, created: Boolean(priorRow.created)});
      if (!local) {
        return {preview: {...preview, mode: 'local-source-missing', canUpdate: false, reason: 'A source from the imported publication is no longer present locally. ProgRSS will not recreate that deletion automatically.'}};
      }
      const metadataChanged = stableJson(prior) !== stableJson(incoming);
      if (metadataChanged) {
        sourceMetadataChanged++;
        updateSourceStates.set(incoming.id, 'details-changed');
      } else updateSourceStates.set(incoming.id, 'unchanged');
      const localPortable = sharedFolderPortableSource(local, incoming.id);
      if (!localPortable) {
        return {preview: {...preview, mode: 'local-source-invalid', canUpdate: false, reason: 'A local source in this publication can no longer be compared safely. Import this copy separately.'}};
      }
      const unchangedLocally = stableJson(localPortable) === stableJson(prior);
      if (!unchangedLocally) localSourceOverrides++;
      if (priorRow.created) {
        const titleClass = fieldChange({
          kind: 'source', remoteId: incoming.id, localId: priorRow.localId, label: localPortable.title,
          field: 'title', fieldLabel: 'Source name', baselineValue: prior.title, localValue: localPortable.title, incomingValue: incoming.title
        });
        const authorClass = fieldChange({
          kind: 'source', remoteId: incoming.id, localId: priorRow.localId, label: localPortable.title,
          field: 'author', fieldLabel: 'Source attribution', baselineValue: prior.author, localValue: localPortable.author, incomingValue: incoming.author
        });
        const changes = {};
        if (titleClass === 'curatorOnly') changes.title = incoming.title;
        if (authorClass === 'curatorOnly') changes.author = incoming.author;
        if (localPortable.version === prior.version && incoming.version !== prior.version) changes.version = incoming.version;
        if (Object.keys(changes).length) sourcePatches.push({localId: priorRow.localId, changes});
      } else {
        const before = mergeCounts.recipientOnly;
        fieldChange({
          kind: 'source', remoteId: incoming.id, localId: priorRow.localId, label: localPortable.title,
          field: 'title', fieldLabel: 'Source name', baselineValue: prior.title, localValue: localPortable.title, incomingValue: incoming.title,
          allowConflictChoice: false, forceLocalOwnership: true,
          ownerNote: 'This source existed before the publication was added, so its local label remains local.'
        });
        fieldChange({
          kind: 'source', remoteId: incoming.id, localId: priorRow.localId, label: localPortable.title,
          field: 'author', fieldLabel: 'Source attribution', baselineValue: prior.author, localValue: localPortable.author, incomingValue: incoming.author,
          allowConflictChoice: false, forceLocalOwnership: true,
          ownerNote: 'This source existed before the publication was added, so its local attribution remains local.'
        });
        if (mergeCounts.recipientOnly > before && metadataChanged) reusedSourceLabelsPreserved++;
      }
      if (sharedFolderSourceAcquisitionKey(localPortable) !== sharedFolderSourceAcquisitionKey(prior)) {
        recordMerge('recipientOnly', {
          id: `source:${incoming.id}:local-recipe`, kind: 'source', label: localPortable.title,
          field: 'recipe', fieldLabel: 'How this source is checked',
          baseline: await sharedFolderRecipeEvidence(prior), local: await sharedFolderRecipeEvidence(localPortable), incoming: await sharedFolderRecipeEvidence(incoming),
          default: 'keep-local', summary: 'You changed how this source is checked; the curator did not change that recipe, so your local recipe stays.'
        });
      }
      continue;
    }

    if (prior) sourceRecipesChanged++;
    else sourcesAdded++;
    const priorLocal = priorRow ? stateSourceById.get(priorRow.localId) : null;
    let recipeEntry = null;
    if (prior) {
      const oldHost = sharedFolderMergeHost(prior.url);
      const newHost = sharedFolderMergeHost(incoming.url);
      const priorLocalPortable = priorLocal ? sharedFolderPortableSource(priorLocal, incoming.id) : null;
      const localRecipeChanged = Boolean(priorLocalPortable && sharedFolderSourceAcquisitionKey(priorLocalPortable) !== sharedFolderSourceAcquisitionKey(prior));
      recipeEntry = {
        id: `source:${incoming.id}:recipe`, kind: 'source', label: incoming.title,
        field: 'recipe', fieldLabel: 'How this source is checked',
        baseline: await sharedFolderRecipeEvidence(prior),
        local: priorLocalPortable ? await sharedFolderRecipeEvidence(priorLocalPortable) : {present: false},
        incoming: await sharedFolderRecipeEvidence(incoming),
        oldHost, newHost, localRecipeChanged, default: 'new-paused',
        summary: `Curator changed how ${incoming.title} is checked${oldHost || newHost ? ` from ${oldHost} to ${newHost}` : ''}. The new recipe starts paused; earlier source history stays local.`
      };
    }
    let local = sharedFolderFindExistingSource(state, incoming, plannedByRecipe);
    let created = false;
    if (!local) {
      let id = incoming.id;
      while (existingIds.has(id)) id = C.uid('shared');
      existingIds.add(id);
      local = {...incoming, id, enabled: false, lastScan: '', lastError: '', lastSuccessfulAt: '', lastNewAt: '', lastProblemAt: '', lastProblem: '', createdAt: new Date().toISOString(), origin: 'shared-folder-update'};
      sourceAdds.push(local);
      plannedByRecipe.set(sharedFolderSourceAcquisitionKey(incoming), local);
      created = true;
      if (prior) changedRecipeNewSources++;
    } else reusedLocalSources++;
    if (prior) {
      recipeEntry.default = created ? 'new-paused' : 'reuse-existing';
      recipeEntry.reusesExisting = !created;
      recordMerge('recipeChanges', recipeEntry);
      updateSourceStates.set(incoming.id, created ? 'recipe-changed-new-paused' : 'recipe-changed-reuses-existing');
    } else {
      recordMerge('additions', {
        id: `source:${incoming.id}:added`, kind: 'source', label: incoming.title,
        field: 'source', fieldLabel: 'Source', incoming: {type: incoming.type, host: sharedFolderMergeHost(incoming.url)},
        default: created ? 'add-paused' : 'reuse-existing',
        summary: `Curator added ${incoming.title}. ${created ? 'It will start paused.' : 'An exact source already here will be reused.'}`
      });
      updateSourceStates.set(incoming.id, created ? 'added-new-paused' : 'added-reuses-existing');
    }
    nextSourceLocal.set(incoming.id, local.id);
    nextSourceRows.push({remoteId: incoming.id, localId: local.id, created});
  }
  const incomingSourceIds = new Set(bundle.sources.map(source => source.id));
  const removedSourceRows = baseline.sources.filter(source => !incomingSourceIds.has(source.id));
  const sourcesRemoved = removedSourceRows.length;
  for (const removed of removedSourceRows) {
    const mapping = oldSourceRows.get(removed.id);
    const local = mapping ? stateSourceById.get(mapping.localId) : null;
    recordMerge('removals', {
      id: `source:${removed.id}:removed`, kind: 'source', label: C.text(local?.title || removed.title, 180) || 'Untitled source',
      field: 'source', fieldLabel: 'Source', baseline: {host: sharedFolderMergeHost(removed.url), type: removed.type},
      local: {present: Boolean(local)}, incoming: {present: false}, default: 'detach-history',
      summary: 'Curator removed this source from the route. Its retained updates and local source record will not be deleted.'
    });
  }

  const nextCollectionLocal = new Map();
  const nextCollectionRows = [];
  const collectionAdds = [];
  const updateFolderStates = new Map();
  for (const incoming of bundle.collections) {
    const priorRow = oldCollectionRows.get(incoming.id);
    let localId = priorRow?.localId || incoming.id;
    while (!priorRow && existingIds.has(localId)) localId = C.uid('folder');
    existingIds.add(localId);
    nextCollectionLocal.set(incoming.id, localId);
    nextCollectionRows.push({remoteId: incoming.id, localId});
  }

  const sourceRemoteByLocal = new Map([...oldSourceLocal.entries()].map(([remoteId, localId]) => [localId, remoteId]));
  for (const row of nextSourceRows) sourceRemoteByLocal.set(row.localId, row.remoteId);
  const collectionRemoteByLocal = new Map([...oldCollectionLocal.entries()].map(([remoteId, localId]) => [localId, remoteId]));
  for (const row of nextCollectionRows) collectionRemoteByLocal.set(row.localId, row.remoteId);
  const incomingSourceById = new Map(bundle.sources.map(row => [row.id, row]));
  const incomingCollectionById = new Map(bundle.collections.map(row => [row.id, row]));
  const semanticLocalMember = member => {
    if (member?.kind === 'source') return sourceRemoteByLocal.has(member.id) ? `source:${sourceRemoteByLocal.get(member.id)}` : `local-source:${member.id}`;
    if (member?.kind === 'collection') return collectionRemoteByLocal.has(member.id) ? `collection:${collectionRemoteByLocal.get(member.id)}` : `local-collection:${member.id}`;
    return '';
  };
  const semanticMemberLabel = key => {
    const colon = key.indexOf(':');
    const kind = colon === -1 ? '' : key.slice(0, colon);
    const id = colon === -1 ? '' : key.slice(colon + 1);
    if (kind === 'source') return C.text((incomingSourceById.get(id) || oldSourceByRemote.get(id))?.title, 180) || 'Untitled source';
    if (kind === 'collection') return C.text((incomingCollectionById.get(id) || oldCollectionByRemote.get(id))?.title, 180) || 'Untitled folder';
    if (kind === 'local-source') return C.text(stateSourceById.get(id)?.title, 180) || 'Local source';
    if (kind === 'local-collection') return C.text(stateCollectionById.get(id)?.title, 180) || 'Local folder';
    return 'Unknown entry';
  };

  const collectionUpdates = [];
  const collectionDeleteIds = [];
  let foldersAdded = 0;
  let foldersChanged = 0;
  let hierarchyChanges = 0;
  let sourceNotesChanged = 0;
  let localFolderOverrides = 0;
  let detachedLocalFolders = 0;
  const incomingCollectionIds = new Set(bundle.collections.map(collection => collection.id));
  for (const incoming of bundle.collections) {
    const prior = oldCollectionByRemote.get(incoming.id);
    const localId = nextCollectionLocal.get(incoming.id);
    const incomingMembers = sharedFolderTranslateMembers(incoming, nextSourceLocal, nextCollectionLocal);
    if (!prior) {
      foldersAdded++;
      updateFolderStates.set(incoming.id, 'added');
      collectionAdds.push({...incoming, id: localId, members: incomingMembers});
      recordMerge('additions', {
        id: `folder:${incoming.id}:added`, kind: 'folder', label: incoming.title,
        field: 'folder', fieldLabel: 'Folder', incoming: {members: (incoming.members || []).length},
        default: 'add-folder', summary: `Curator added the folder ${incoming.title}.`
      });
      continue;
    }
    const current = stateCollectionById.get(localId);
    const baselineMembers = sharedFolderTranslateMembers(prior, oldSourceLocal, oldCollectionLocal);
    const currentMeaning = sharedFolderCollectionMeaning(current);
    const baselineMeaning = sharedFolderCollectionMeaning(prior, baselineMembers);
    const incomingMeaning = sharedFolderCollectionMeaning(incoming, incomingMembers);
    fieldChange({
      kind: 'folder', remoteId: incoming.id, localId, label: currentMeaning.title,
      field: 'title', fieldLabel: 'Folder name', baselineValue: baselineMeaning.title, localValue: currentMeaning.title, incomingValue: incomingMeaning.title
    });
    fieldChange({
      kind: 'folder', remoteId: incoming.id, localId, label: currentMeaning.title,
      field: 'author', fieldLabel: 'Folder attribution', baselineValue: baselineMeaning.author, localValue: currentMeaning.author, incomingValue: incomingMeaning.author
    });
    const baselineSemantic = new Set((prior.members || []).map(sharedFolderMemberKey));
    const incomingSemantic = new Set((incoming.members || []).map(sharedFolderMemberKey));
    const localSemantic = new Set(sharedFolderUniqueMembers(current?.members || []).map(semanticLocalMember).filter(Boolean));
    for (const memberKey of [...new Set([...baselineSemantic, ...localSemantic, ...incomingSemantic])].sort()) {
      recordMembership({
        folderId: incoming.id, folderLabel: currentMeaning.title, memberKey, memberLabel: semanticMemberLabel(memberKey),
        baselinePresent: baselineSemantic.has(memberKey), localPresent: localSemantic.has(memberKey), incomingPresent: incomingSemantic.has(memberKey)
      });
    }
    const localEdited = stableJson(currentMeaning) !== stableJson(baselineMeaning);
    if (localEdited) localFolderOverrides++;
    if (stableJson(sharedFolderCollectionMeaning(prior)) !== stableJson(sharedFolderCollectionMeaning(incoming))) {
      foldersChanged++;
      updateFolderStates.set(incoming.id, 'changed');
    } else updateFolderStates.set(incoming.id, 'unchanged');
    const baselineKeys = new Set(baselineMembers.map(sharedFolderMemberKey));
    const incomingKeys = new Set(incomingMembers.map(sharedFolderMemberKey));
    const removed = new Set([...baselineKeys].filter(key => !incomingKeys.has(key)));
    const added = incomingMembers.filter(member => !baselineKeys.has(sharedFolderMemberKey(member)));
    const currentMembers = sharedFolderUniqueMembers(current?.members || []);
    const finalMembers = currentMembers.filter(member => !removed.has(sharedFolderMemberKey(member)));
    const present = new Set(finalMembers.map(sharedFolderMemberKey));
    for (const member of added) {
      const key = sharedFolderMemberKey(member);
      if (!present.has(key)) { finalMembers.push(member); present.add(key); }
    }
    const baselineReasons = new Map((prior.members || []).filter(member => member.kind === 'source').map(member => [sharedFolderMemberKey(member), C.normalizeSourceNoteReason(member.reason)]));
    const incomingReasons = new Map((incoming.members || []).filter(member => member.kind === 'source').map(member => [sharedFolderMemberKey(member), C.normalizeSourceNoteReason(member.reason)]));
    const localReasons = new Map();
    for (const member of sharedFolderUniqueMembers(current?.members || [])) {
      const semanticKey = semanticLocalMember(member);
      if (semanticKey.startsWith('source:')) localReasons.set(semanticKey, C.normalizeSourceNoteReason(member.reason));
    }
    const finalByKey = new Map(finalMembers.map(member => [sharedFolderMemberKey(member), member]));
    for (const semanticKey of [...localSemantic].filter(key => incomingSemantic.has(key)).sort()) {
      if (!semanticKey.startsWith('source:')) continue;
      const sourceRemoteId = semanticKey.slice('source:'.length);
      const sourceLocalId = nextSourceLocal.get(sourceRemoteId);
      const finalMember = finalByKey.get(`source:${sourceLocalId}`);
      if (!sourceLocalId || !finalMember) continue;
      const baselineReason = baselineReasons.get(semanticKey);
      const localReason = localReasons.get(semanticKey);
      const incomingReason = incomingReasons.get(semanticKey);
      const classification = recordSourceNote({
        folderRemoteId: incoming.id, folderLocalId: localId, folderLabel: currentMeaning.title,
        sourceRemoteId, sourceLocalId, sourceLabel: semanticMemberLabel(semanticKey),
        baselineValue: baselineReason, localValue: localReason, incomingValue: incomingReason
      });
      if (classification !== 'unchanged') sourceNotesChanged++;
      const selectedReason = classification === 'curatorOnly' ? incomingReason : localReason;
      if (selectedReason === undefined) delete finalMember.reason;
      else finalMember.reason = selectedReason;
    }
    const beforeHierarchy = new Set(baselineMembers.filter(member => member.kind === 'collection').map(sharedFolderMemberKey));
    const afterHierarchy = new Set(incomingMembers.filter(member => member.kind === 'collection').map(sharedFolderMemberKey));
    hierarchyChanges += [...new Set([...beforeHierarchy, ...afterHierarchy])].filter(key => beforeHierarchy.has(key) !== afterHierarchy.has(key)).length;
    const final = {...current,
      title: currentMeaning.title === baselineMeaning.title ? incomingMeaning.title : currentMeaning.title,
      author: currentMeaning.author === baselineMeaning.author ? incomingMeaning.author : currentMeaning.author,
      mode: 'union', include: '', exclude: '', members: finalMembers
    };
    if (stableJson(sharedFolderCollectionMeaning(final)) !== stableJson(currentMeaning)) {
      final.version = Math.min(10000, Math.max(Number(current?.version) || 1, Number(incoming.version) || 1) + 1);
    }
    collectionUpdates.push(final);
  }
  const removedCollections = [];
  for (const prior of baseline.collections) {
    if (incomingCollectionIds.has(prior.id) || prior.id === baseline.root) continue;
    const localId = oldCollectionLocal.get(prior.id);
    const current = stateCollectionById.get(localId);
    if (!current) continue;
    const baselineMembers = sharedFolderTranslateMembers(prior, oldSourceLocal, oldCollectionLocal);
    const locallyChanged = stableJson(sharedFolderCollectionMeaning(current)) !== stableJson(sharedFolderCollectionMeaning(prior, baselineMembers));
    removedCollections.push({localId, current, locallyChanged});
    recordMerge('removals', {
      id: `folder:${prior.id}:removed`, kind: 'folder', label: C.text(current.title || prior.title, 180) || 'Untitled folder',
      field: 'folder', fieldLabel: 'Folder', baseline: {present: true}, local: {present: true, changed: locallyChanged}, incoming: {present: false},
      default: locallyChanged ? 'keep-local-folder' : 'remove-folder',
      summary: locallyChanged
        ? 'Curator removed this folder, but your local changes keep it as a detached local folder.'
        : 'Curator removed this unchanged folder from the route.'
    });
  }
  const removedLocalIds = new Set(removedCollections.map(row => row.localId));
  const finalCollectionById = new Map((state.collections || []).map(collection => [collection.id, collection]));
  for (const collection of collectionUpdates) finalCollectionById.set(collection.id, collection);
  for (const collection of collectionAdds) finalCollectionById.set(collection.id, collection);
  const keepRemoved = new Set(removedCollections.filter(row => row.locallyChanged).map(row => row.localId));
  for (const collection of finalCollectionById.values()) {
    if (removedLocalIds.has(collection.id)) continue;
    for (const member of collection.members || []) {
      if (member.kind === 'collection' && removedLocalIds.has(member.id)) keepRemoved.add(member.id);
    }
  }
  let grew = true;
  while (grew) {
    grew = false;
    for (const localId of [...keepRemoved]) {
      const collection = finalCollectionById.get(localId);
      for (const member of collection?.members || []) {
        if (member.kind === 'collection' && removedLocalIds.has(member.id) && !keepRemoved.has(member.id)) {
          keepRemoved.add(member.id);
          grew = true;
        }
      }
    }
  }
  for (const row of removedCollections) {
    if (keepRemoved.has(row.localId)) detachedLocalFolders++;
    else collectionDeleteIds.push(row.localId);
  }
  const foldersRemoved = baseline.collections.filter(collection => !incomingCollectionIds.has(collection.id)).length;
  const rootUpdate = collectionUpdates.find(collection => collection.id === target.id) || collectionAdds.find(collection => collection.id === target.id);
  if (!rootUpdate) {
    return {preview: {...preview, mode: 'root-missing', canUpdate: false, reason: 'The new copy no longer contains the publication’s top-level folder.'}};
  }
  const newBaseline = F.createBaseline(bundle, nextSourceRows, nextCollectionRows);
  rootUpdate.sharedFolderOrigin = F.createOrigin(bundle.provenance || {}, new Date().toISOString(), newBaseline, origin);
  const attributionChanged = origin.curator !== (bundle.provenance?.curator || '') || origin.note !== (bundle.provenance?.note || '');
  const signerChanged = ['key-change', 'signed-to-unsigned', 'newly-signed'].includes(trust.state);
  const updateAddressChanged = C.text(origin.updateUrl, 2048) !== C.text(bundle.provenance?.updateUrl, 2048);
  const digestChanged = Boolean(origin.digest && bundle.provenance?.digest && origin.digest !== bundle.provenance.digest);
  const semanticChanged = Boolean(digestChanged || sourcesAdded || sourcesRemoved || sourceRecipesChanged || sourceMetadataChanged || foldersAdded || foldersRemoved || foldersChanged || attributionChanged || signerChanged || updateAddressChanged);
  const sourceRoom = Math.max(0, C.LIMIT.source - (state.sources || []).length);
  const collectionRoom = Math.max(0, C.LIMIT.collection - ((state.collections || []).length - collectionDeleteIds.length));
  let reason = '';
  if (sourceAdds.length > sourceRoom) reason = `ProgRSS has room for ${sourceRoom} more source${sourceRoom === 1 ? '' : 's'}, but this update needs ${sourceAdds.length}.`;
  else if (collectionAdds.length > collectionRoom) reason = `ProgRSS has room for ${collectionRoom} more folder${collectionRoom === 1 ? '' : 's'}, but this update needs ${collectionAdds.length}.`;
  const alreadyCurrent = !semanticChanged && origin.digest && origin.digest === bundle.provenance?.digest;
  const mergeReview = {
    schema: 'progrss.shared-folder-merge-review.v1',
    counts: {...mergeCounts},
    ...mergeGroups,
    omitted: Object.fromEntries(Object.entries(mergeOmitted).filter(([, value]) => value)),
    requiresDecisions: Boolean(mergeCounts.conflicts),
    decisionIds: Object.keys(conflictOperations).sort(),
    recipeAcknowledgementRequired: Boolean(mergeCounts.recipeChanges),
    network: false, writes: false
  };
  const updatePreview = {
    ...preview,
    mode: alreadyCurrent ? 'current' : 'update',
    canUpdate: !reason && !alreadyCurrent,
    reason: alreadyCurrent ? 'This local folder already matches this shared copy.' : reason,
    alreadyCurrent,
    changes: {
      sourcesAdded, sourcesRemoved, sourceRecipesChanged, sourceMetadataChanged, newLocalSources: sourceAdds.length,
      reusedLocalSources, reusedSourceLabelsPreserved, foldersAdded, foldersRemoved, foldersChanged, hierarchyChanges, sourceNotesChanged,
      attributionChanged, signerChanged, updateAddressChanged
    },
    mergeReview,
    requiresConflictChoices: Boolean(mergeCounts.conflicts),
    requiresRecipeAcknowledgement: Boolean(mergeCounts.recipeChanges),
    localEdits: {
      sourceOverrides: localSourceOverrides, folderOverrides: localFolderOverrides,
      detachedFolders: detachedLocalFolders,
      present: Boolean(localSourceOverrides || localFolderOverrides || detachedLocalFolders)
    },
    preservation: {
      readingHistory: true, readAndSavedState: true, sourceActivity: true, browserPermissions: true,
      removedSourceHistoriesRetained: sourcesRemoved,
      changedRecipesStartPaused: changedRecipeNewSources,
      localEditsKept: true
    },
    undoMinutes: Math.round(SHARED_FOLDER_UPDATE_UNDO_MS / 60000),
    warnings: [
      ...(state.transferUndo || state.sourceRepairUndo || state.receiptRetirementUndo || state.sharedFolderUpdateUndo || state.pageWatchRepairUndo ? ['Completing this update replaces any earlier timed undo with one update undo.'] : []),
      ...(sourceRecipesChanged ? ['Changed acquisition recipes become paused sources; the earlier source histories remain in the library.'] : []),
      ...(sourcesRemoved ? ['Sources removed from the publication are detached from unchanged publication folders, but their retained updates are not deleted.'] : [])
    ],
    contents: sharedFolderUpdateContents(bundle, baseline, updateSourceStates, updateFolderStates)
  };
  return {
    preview: updatePreview, bundle, targetRootId: target.id,
    sourceAdds, sourcePatches, collectionAdds, collectionUpdates, collectionDeleteIds,
    conflictOperations
  };
}

async function checkSharedFolderUpdate(collectionId) {
  const state = await loadState();
  const id = C.text(collectionId, 300);
  const collection = (state.collections || []).find(row => C.text(row?.id, 300) === id);
  if (!collection) throw codedError('That shared folder is no longer available.', 'SHARED_FOLDER_NOT_FOUND');
  const origin = F.normalizeOrigin(collection.sharedFolderOrigin, false);
  const updateUrl = C.text(origin?.updateUrl, 2048);
  if (!updateUrl) throw codedError('This shared folder does not carry a future-copy address.', 'SHARED_FOLDER_UPDATE_URL_MISSING');
  const response = await fetchResource(updateUrl, {}, {
    maxBytes: C.LIMIT.bundle,
    accept: 'application/vnd.progrss.shared-folder+json, application/json;q=0.9, text/plain;q=0.2, */*;q=0.1'
  });
  if (response.status === 304) throw codedError('The publication server returned no document to review.', 'SHARED_FOLDER_UPDATE_EMPTY');
  const plan = await sharedFolderUpdatePlan(response.body, state, id);
  if (!plan) throw codedError('The address returned a different publication. Nothing was changed.', 'SHARED_FOLDER_PUBLICATION_MISMATCH');
  if (plan.preview.publicationId !== origin.publicationId) {
    throw codedError('The address returned a different publication identity. Nothing was changed.', 'SHARED_FOLDER_PUBLICATION_MISMATCH');
  }
  return {
    raw: response.body,
    preview: {...plan.preview, network: true, writes: false},
    remote: {
      requestedUrl: updateUrl,
      finalUrl: C.text(response.url || updateUrl, 2048),
      status: Number(response.status) || 0,
      contentType: C.text(response.contentType, 200),
      redirects: Array.isArray(response.redirects) ? response.redirects.map(row => ({from: C.text(row.from, 2048), to: C.text(row.to, 2048), status: Number(row.status) || 0})) : [],
      credentials: 'omitted',
      automatic: false
    }
  };
}

async function reviewSharedFolderUrl(input = {}) {
  const pageUrl = C.safeUrl(input.pageUrl);
  const bundleUrl = C.safeUrl(input.url);
  if (new URL(pageUrl).origin !== new URL(bundleUrl).origin) {
    throw codedError('A webpage may advertise a shared folder only on the same site. Nothing was contacted.', 'SHARED_FOLDER_DISCOVERY_CROSS_ORIGIN');
  }
  const response = await fetchResource(bundleUrl, {}, {
    maxBytes: C.LIMIT.bundle,
    accept: `${S.SHARED_FOLDER_MIME}, application/json;q=0.9, text/plain;q=0.2, */*;q=0.1`
  });
  if ([429, 503].includes(response.status)) {
    throw codedError(`The site asked ProgRSS to slow down (HTTP ${response.status}).`, 'SHARED_FOLDER_DISCOVERY_THROTTLED', {status: response.status});
  }
  if (response.status === 304 || !response.body) {
    throw codedError('The advertised address returned no shared-folder document to review.', 'SHARED_FOLDER_DISCOVERY_EMPTY');
  }
  const preview = await previewSharedFolder(response.body);
  return {
    raw: response.body,
    preview: {...preview, network: true, writes: false},
    remote: {
      sourcePageUrl: pageUrl,
      requestedUrl: bundleUrl,
      finalUrl: C.text(response.url || bundleUrl, 2048),
      status: Number(response.status) || 0,
      contentType: C.text(response.contentType, 200),
      redirects: Array.isArray(response.redirects) ? response.redirects.map(row => ({
        from: C.text(row.from, 2048), to: C.text(row.to, 2048), status: Number(row.status) || 0
      })) : [],
      credentials: 'omitted',
      automatic: false
    }
  };
}

async function previewSharedFolder(raw, targetRootId = '', selectedFolderId = '') {
  const state = await loadState();
  if (C.text(selectedFolderId, 300)) return (await sharedFolderPlan(raw, state, selectedFolderId)).preview;
  const update = await sharedFolderUpdatePlan(raw, state, targetRootId);
  if (!update) return (await sharedFolderPlan(raw, state)).preview;
  const separate = (await sharedFolderPlan(raw, state)).preview;
  return {...update.preview, separate: {
    canImport: separate.canImport, reason: separate.reason, newSources: separate.newSources,
    reusedSources: separate.reusedSources, folders: separate.folders, startsPaused: true
  }};
}

async function importSharedFolder(raw, reviewedRevision, selectedFolderId = '') {
  return queueMutation(async () => {
    const state = await loadState();
    if ((Number(state._revision) || 0) !== Number(reviewedRevision)) throw codedError('ProgRSS changed while you were reviewing. Check the shared folder again before adding it.', 'SHARED_FOLDER_REVIEW_STALE');
    const plan = await sharedFolderPlan(raw, state, selectedFolderId);
    if (!plan.preview.canImport) throw codedError(plan.preview.reason || 'This shared folder cannot be added.', 'SHARED_FOLDER_IMPORT_BLOCKED');
    state.sources.push(...plan.sources);
    state.collections.push(...plan.collections);
    await saveAndBroadcast(state, {kind: 'shared-folder-import', rootId: plan.rootId});
    return {...plan.preview, rootId: plan.rootId, importedSources: plan.sources.length, importedFolders: plan.collections.length};
  });
}

function validSharedFolderUpdateUndo(undo, revision, now = Date.now()) {
  return Boolean(
    undo && typeof undo === 'object' && !Array.isArray(undo) &&
    undo.schema === 'progrss.shared-folder.update.undo.v1' &&
    undo.previousState && typeof undo.previousState === 'object' && !Array.isArray(undo.previousState) &&
    Number.isSafeInteger(undo.expectedRevision) && undo.expectedRevision === revision &&
    Number.isFinite(Date.parse(undo.expiresAt || '')) && Date.parse(undo.expiresAt) > now
  );
}

function sharedFolderUpdateUndoInfo(state) {
  const undo = state.sharedFolderUpdateUndo;
  if (!validSharedFolderUpdateUndo(undo, state._revision)) return {undoAvailable: false};
  return {
    undoAvailable: true,
    createdAt: C.text(undo.createdAt, 80),
    expiresAt: C.text(undo.expiresAt, 80),
    rootId: C.text(undo.summary?.rootId, 300),
    title: C.text(undo.summary?.title, 180),
    changes: undo.summary?.changes && typeof undo.summary.changes === 'object' ? {...undo.summary.changes} : {}
  };
}

async function updateSharedFolder(raw, payload = {}) {
  return queueMutation(async () => {
    const state = await loadState();
    if (!Number.isSafeInteger(payload.reviewedRevision) || payload.reviewedRevision !== state._revision) {
      throw codedError('ProgRSS changed while this update was being reviewed. Review the shared copy again before updating.', 'SHARED_FOLDER_UPDATE_STALE');
    }
    const plan = await sharedFolderUpdatePlan(raw, state, payload.targetRootId);
    if (!plan) throw codedError('No local copy of this publication is available to update.', 'SHARED_FOLDER_UPDATE_NOT_FOUND');
    if (!plan.preview.canUpdate) throw codedError(plan.preview.reason || 'This shared folder cannot be updated safely.', 'SHARED_FOLDER_UPDATE_BLOCKED');
    if (plan.preview.requiresTrustAcknowledgement && payload.acknowledgeTrustChange !== true) {
      throw codedError('Review and acknowledge the signing-key change before updating.', 'SHARED_FOLDER_TRUST_ACKNOWLEDGEMENT');
    }
    const conflictChoices = payload.conflictChoices && typeof payload.conflictChoices === 'object' && !Array.isArray(payload.conflictChoices)
      ? payload.conflictChoices : {};
    for (const conflictId of Object.keys(conflictChoices)) {
      if (!Object.prototype.hasOwnProperty.call(plan.conflictOperations || {}, conflictId)) {
        throw codedError('A conflict choice is stale or does not belong to this reviewed copy. Review the shared copy again.', 'SHARED_FOLDER_CONFLICT_STALE');
      }
    }
    for (const conflictId of Object.keys(plan.conflictOperations || {})) {
      if (!['keep-local', 'use-curator'].includes(conflictChoices[conflictId])) {
        throw codedError('Choose whether to keep your wording or use the curator’s wording for every conflict before updating.', 'SHARED_FOLDER_CONFLICT_DECISION');
      }
    }
    if (plan.preview.requiresRecipeAcknowledgement && payload.acknowledgeRecipeChanges !== true) {
      throw codedError('Review and acknowledge every change to how a source is checked before updating.', 'SHARED_FOLDER_RECIPE_ACKNOWLEDGEMENT');
    }
    const previousState = jsonClone(state);
    delete previousState._revision;
    previousState.transferUndo = null;
    previousState.sourceRepairUndo = null;
    previousState.receiptRetirementUndo = null;
    previousState.sharedFolderUpdateUndo = null;
    previousState.pageWatchRepairUndo = null;
    state.transferUndo = null;
    state.sourceRepairUndo = null;
    state.receiptRetirementUndo = null;
    state.sharedFolderUpdateUndo = null;
    state.pageWatchRepairUndo = null;
    state.sources.push(...plan.sourceAdds.map(jsonClone));
    for (const patch of plan.sourcePatches) {
      const source = state.sources.find(row => row.id === patch.localId);
      if (!source) throw codedError('A source changed while the shared update was being applied.', 'SHARED_FOLDER_UPDATE_STALE');
      for (const [field, value] of Object.entries(patch.changes || {})) {
        if (field === 'title') source.title = C.text(value, 130) || source.title;
        else if (field === 'author') source.author = C.text(value, 80) || source.author || 'anonymous';
        else if (field === 'version') source.version = Math.min(10000, Math.max(1, Math.round(Number(value) || 1)));
      }
    }
    const conflictSourceVersions = new Set();
    for (const [conflictId, operation] of Object.entries(plan.conflictOperations || {})) {
      if (conflictChoices[conflictId] !== 'use-curator' || operation.kind !== 'source') continue;
      const source = state.sources.find(row => row.id === operation.localId);
      if (!source) throw codedError('A conflicted source changed while the shared update was being applied.', 'SHARED_FOLDER_UPDATE_STALE');
      if (operation.field === 'title') source.title = C.text(operation.curatorValue, 130) || source.title;
      else if (operation.field === 'author') source.author = C.text(operation.curatorValue, 80) || 'anonymous';
      else throw codedError('That reviewed source conflict is no longer supported.', 'SHARED_FOLDER_UPDATE_STALE');
      conflictSourceVersions.add(source.id);
    }
    for (const id of conflictSourceVersions) {
      const source = state.sources.find(row => row.id === id);
      if (source) source.version = Math.min(10000, Math.max(1, Number(source.version) || 1) + 1);
    }
    const deleted = new Set(plan.collectionDeleteIds);
    const updates = new Map(plan.collectionUpdates.map(collection => [collection.id, collection]));
    const conflictFolderVersions = new Set();
    for (const [conflictId, operation] of Object.entries(plan.conflictOperations || {})) {
      if (conflictChoices[conflictId] !== 'use-curator' || !['folder', 'placement-reason'].includes(operation.kind)) continue;
      const collection = updates.get(operation.localId);
      if (!collection) throw codedError('A conflicted folder changed while the shared update was being applied.', 'SHARED_FOLDER_UPDATE_STALE');
      if (operation.kind === 'folder') {
        if (operation.field === 'title') collection.title = C.text(operation.curatorValue, 130) || collection.title;
        else if (operation.field === 'author') collection.author = C.text(operation.curatorValue, 80) || 'anonymous';
        else throw codedError('That reviewed folder conflict is no longer supported.', 'SHARED_FOLDER_UPDATE_STALE');
      } else {
        const member = (collection.members || []).find(row => row.kind === 'source' && row.id === operation.sourceId);
        if (!member) throw codedError('A conflicted Source Note placement changed while the shared update was being applied.', 'SHARED_FOLDER_UPDATE_STALE');
        const reason = C.normalizeSourceNoteReason(operation.curatorValue);
        if (reason === undefined) delete member.reason;
        else member.reason = reason;
      }
      conflictFolderVersions.add(collection.id);
    }
    for (const id of conflictFolderVersions) {
      const collection = updates.get(id);
      if (collection) collection.version = Math.min(10000, Math.max(1, Number(collection.version) || 1) + 1);
    }
    state.collections = state.collections.filter(collection => !deleted.has(collection.id)).map(collection => {
      const updated = updates.get(collection.id);
      return updated ? jsonClone(updated) : collection;
    });
    state.collections.push(...plan.collectionAdds.map(jsonClone));
    const createdAt = new Date();
    state.sharedFolderUpdateUndo = {
      schema: 'progrss.shared-folder.update.undo.v1',
      createdAt: createdAt.toISOString(),
      expiresAt: new Date(createdAt.getTime() + SHARED_FOLDER_UPDATE_UNDO_MS).toISOString(),
      expectedRevision: state._revision + 1,
      previousState,
      summary: {rootId: plan.targetRootId, title: plan.preview.localTitle || plan.preview.title, changes: plan.preview.changes}
    };
    await saveAndBroadcast(state, {kind: 'shared-folder-update', rootId: plan.targetRootId});
    return {
      ...plan.preview,
      updated: true,
      conflictChoices: Object.fromEntries(Object.keys(plan.conflictOperations || {}).map(id => [id, conflictChoices[id]])),
      recipeChangesAcknowledged: Boolean(plan.preview.requiresRecipeAcknowledgement),
      undoAvailable: true,
      undoUntil: state.sharedFolderUpdateUndo.expiresAt
    };
  });
}

async function undoSharedFolderUpdate() {
  return queueMutation(async () => {
    const current = await loadState();
    const undo = current.sharedFolderUpdateUndo;
    if (!undo || !Number.isFinite(Date.parse(undo.expiresAt || '')) || Date.parse(undo.expiresAt) <= Date.now()) {
      throw codedError('The shared-folder update undo has expired.', 'SHARED_FOLDER_UPDATE_UNDO_EXPIRED');
    }
    if (!validSharedFolderUpdateUndo(undo, current._revision)) {
      throw codedError('ProgRSS changed after this update. Undo was stopped so newer reading and organization would not be overwritten.', 'SHARED_FOLDER_UPDATE_UNDO_STALE');
    }
    const previous = V.normalize(undo.previousState);
    previous._revision = current._revision;
    previous.sharedFolderUpdateUndo = null;
    await applyDestinationPermissions(previous);
    await saveAndBroadcast(previous, {kind: 'shared-folder-update-undo', rootId: undo.summary?.rootId || ''});
    return {restored: true, rootId: C.text(undo.summary?.rootId, 300), title: C.text(undo.summary?.title, 180)};
  });
}

async function clearExpiredSharedFolderUpdateUndo() {
  return queueMutation(async () => {
    const state = await loadState();
    if (!state.sharedFolderUpdateUndo || validSharedFolderUpdateUndo(state.sharedFolderUpdateUndo, state._revision)) return false;
    state.sharedFolderUpdateUndo = null;
    await saveAndBroadcast(state, {kind: 'shared-folder-update-undo-expired'});
    return true;
  });
}
async function getSharingIdentity() {
  try { return F.publicIdentity(await F.getIdentity()); }
  catch (error) { throw codedError(error.message, 'SIGNING_IDENTITY_FAILED'); }
}

async function createSharingIdentity() {
  try { return await F.createIdentity(); }
  catch (error) { throw codedError(error.message, 'SIGNING_IDENTITY_FAILED'); }
}

async function addSourceToFolder(payload = {}) {
  return queueMutation(async () => {
    const state = await loadState();
    const sourceId = C.text(payload.sourceId, 300);
    const collectionId = C.text(payload.collectionId, 300);
    const source = (state.sources || []).find(row => C.text(row?.id, 300) === sourceId && !row.archivedAt);
    if (!source) throw codedError('That source is no longer available.', 'SOURCE_NOT_FOUND');
    const rows = basicFolderRows(state);
    const folder = rows.find(row => row.id === collectionId);
    if (!folder) throw codedError('That folder is no longer a simple folder. Nothing changed.', 'FOLDER_NOT_AVAILABLE');
    const before = folderMembership(rows, sourceId);
    if (folder.directSourceIds.has(sourceId)) {
      return {added: false, reason: 'direct', sourceId, collectionId, folderPath: folder.path, membership: before};
    }
    if (folder.sourceIds.has(sourceId)) {
      return {added: false, reason: 'inherited', sourceId, collectionId, folderPath: folder.path, membership: before};
    }
    if (folder.collection.members.length >= 150) throw codedError('That folder already contains the maximum of 150 direct entries.', 'FOLDER_FULL');
    folder.collection.members.push({kind: 'source', id: sourceId});
    folder.collection.version = Math.min(10000, Math.max(1, Math.round(Number(folder.collection.version) || 1)) + 1);
    await saveAndBroadcast(state, {kind: 'source-folder-add', sourceId, collectionId});
    const afterRows = basicFolderRows(state);
    return {
      added: true,
      sourceId,
      collectionId,
      folderPath: afterRows.find(row => row.id === collectionId)?.path || folder.path,
      folderVersion: folder.collection.version,
      expectedRevision: state._revision,
      membership: folderMembership(afterRows, sourceId)
    };
  });
}

async function removeSourceFromFolder(payload = {}) {
  return queueMutation(async () => {
    const state = await loadState();
    const sourceId = C.text(payload.sourceId, 300);
    const collectionId = C.text(payload.collectionId, 300);
    const source = (state.sources || []).find(row => C.text(row?.id, 300) === sourceId && !row.archivedAt);
    if (!source) throw codedError('That source is no longer available.', 'SOURCE_NOT_FOUND');
    const rows = basicFolderRows(state);
    const folder = rows.find(row => row.id === collectionId);
    if (!folder) throw codedError('That folder is no longer a simple folder. Nothing changed.', 'FOLDER_NOT_AVAILABLE');

    // Removing a placement is destructive, so bind the action to the exact
    // folder state and wording the side panel displayed. A serialized mutation
    // queue cannot by itself prove that an older view still represents intent.
    const expectedVersion = Math.round(Number(payload.expectedVersion) || 0);
    if (!expectedVersion || !Object.prototype.hasOwnProperty.call(payload, 'expectedReason')) {
      throw codedError('The reviewed folder relationship was not supplied. Nothing changed.', 'INVALID_FOLDER_REMOVE_REVIEW');
    }
    const currentVersion = Math.max(1, Math.round(Number(folder.collection.version) || 1));
    if (expectedVersion !== currentVersion) {
      throw codedError('That folder changed in another view. Its newer relationship was kept.', 'STALE_FOLDER_REMOVE');
    }
    // Folder versions saturate at 10000. At that ceiling, an exact persisted
    // vault revision is required to distinguish the reviewed relationship from
    // a removed-and-recreated replacement with the same wording.
    if (currentVersion === 10000 && (!Number.isSafeInteger(payload.expectedRevision) ||
        payload.expectedRevision !== state._revision)) {
      throw codedError('ProgRSS changed after this folder relationship was reviewed. Its newer relationship was kept.', 'STALE_FOLDER_REMOVE');
    }
    let placement;
    try {
      placement = directSourcePlacement(folder, sourceId);
    } catch {
      throw codedError('That direct folder relationship changed in another view. Its newer organization was kept.', 'STALE_FOLDER_REMOVE');
    }
    const currentReason = Object.prototype.hasOwnProperty.call(placement, 'reason')
      ? sourceNoteReasonOrError(placement.reason)
      : undefined;
    const expectedReason = sourceNoteReasonOrError(payload.expectedReason);
    if (currentReason !== expectedReason) {
      throw codedError('That folder relationship received newer wording in another view. It was kept.', 'STALE_FOLDER_REMOVE');
    }

    const before = folderMembership(rows, sourceId);
    // Keep the direct relationship, including its optional reason and position,
    // in the existing short-lived UI undo. No persistent undo store is added.
    const removedIndex = folder.collection.members.indexOf(placement);
    const removedMember = {kind: 'source', id: sourceId};
    if (currentReason !== undefined) removedMember.reason = currentReason;
    folder.collection.members.splice(removedIndex, 1);
    folder.collection.version = Math.min(10000, currentVersion + 1);
    await saveAndBroadcast(state, {kind: 'source-folder-remove', sourceId, collectionId});
    const afterRows = basicFolderRows(state);
    return {
      removed: true,
      sourceId,
      collectionId,
      folderPath: afterRows.find(row => row.id === collectionId)?.path || folder.path,
      folderVersion: folder.collection.version,
      expectedRevision: state._revision,
      removedMember,
      removedIndex,
      membership: folderMembership(afterRows, sourceId)
    };
  });
}


function sourceNoteReasonOrError(value) {
  try {
    return C.normalizeSourceNoteReason(value);
  } catch (error) {
    const message = error instanceof RangeError
      ? 'Keep this reason to 280 Unicode characters or fewer.'
      : 'This reason contains text ProgRSS cannot save.';
    throw codedError(message, 'INVALID_SOURCE_NOTE', {cause: String(error?.message || error)});
  }
}

function directSourcePlacement(folder, sourceId) {
  const matches = (folder?.collection?.members || []).filter(member => (
    member?.kind === 'source' && C.text(member.id, 300) === sourceId
  ));
  if (matches.length !== 1) {
    throw codedError(
      matches.length
        ? 'That folder contains an ambiguous direct placement. Nothing changed.'
        : 'That source is no longer directly in this folder. Nothing changed.',
      'SOURCE_NOTE_PLACEMENT_NOT_AVAILABLE'
    );
  }
  return matches[0];
}

async function setSourcePlacementReason(payload = {}) {
  return queueMutation(async () => {
    const state = await loadState();
    const sourceId = C.text(payload.sourceId, 300);
    const collectionId = C.text(payload.collectionId, 300);
    const source = (state.sources || []).find(row => C.text(row?.id, 300) === sourceId && !row.archivedAt);
    if (!source) throw codedError('That source is no longer available. Nothing changed.', 'SOURCE_NOT_FOUND');
    const folder = basicFolderRows(state).find(row => row.id === collectionId);
    if (!folder) throw codedError('That folder is no longer a simple folder. Nothing changed.', 'FOLDER_NOT_AVAILABLE');
    const placement = directSourcePlacement(folder, sourceId);
    const currentVersion = Math.max(1, Math.round(Number(folder.collection.version) || 1));
    const expectedVersion = Math.round(Number(payload.expectedVersion) || 0);
    if (!expectedVersion || expectedVersion !== currentVersion) {
      throw codedError('That folder changed in another view. Its newer reason was kept.', 'STALE_SOURCE_NOTE');
    }
    // Folder versions saturate at 10000. At that ceiling, version plus reason
    // cannot distinguish the reviewed placement from a removed-and-recreated
    // relationship with the same wording, so require the exact vault revision.
    if (currentVersion === 10000 && (!Number.isSafeInteger(payload.expectedRevision) ||
        payload.expectedRevision !== state._revision)) {
      throw codedError('ProgRSS changed after this reason was reviewed. Its newer folder relationship was kept.', 'STALE_SOURCE_NOTE');
    }
    if (!Object.prototype.hasOwnProperty.call(payload, 'expectedReason')) {
      throw codedError('The earlier reason was not supplied, so ProgRSS refused the edit.', 'INVALID_SOURCE_NOTE_REVIEW');
    }
    const currentReason = Object.prototype.hasOwnProperty.call(placement, 'reason')
      ? sourceNoteReasonOrError(placement.reason)
      : undefined;
    const expectedReason = sourceNoteReasonOrError(payload.expectedReason);
    if (currentReason !== expectedReason) {
      throw codedError('That reason changed in another view. Its newer wording was kept.', 'STALE_SOURCE_NOTE');
    }
    const nextReason = sourceNoteReasonOrError(payload.reason);
    if (nextReason === currentReason) {
      return {
        changed: false, sourceId, collectionId, folderPath: folder.path,
        folderVersion: currentVersion,
        expectedRevision: state._revision,
        previousReason: currentReason ?? null,
        reason: currentReason ?? null,
        cleared: currentReason === undefined
      };
    }
    if (nextReason === undefined) delete placement.reason;
    else placement.reason = nextReason;
    folder.collection.version = Math.min(10000, currentVersion + 1);
    await saveAndBroadcast(state, {
      kind: nextReason === undefined ? 'source-note-clear' : 'source-note-set',
      sourceId,
      collectionId
    });
    return {
      changed: true, sourceId, collectionId, folderPath: folder.path,
      folderVersion: folder.collection.version,
      expectedRevision: state._revision,
      previousReason: currentReason ?? null,
      reason: nextReason ?? null,
      cleared: nextReason === undefined
    };
  });
}

async function undoSourcePlacementReason(payload = {}) {
  return queueMutation(async () => {
    const state = await loadState();
    const sourceId = C.text(payload.sourceId, 300);
    const collectionId = C.text(payload.collectionId, 300);
    const folder = basicFolderRows(state).find(row => row.id === collectionId);
    if (!folder) throw codedError('That folder changed before undo could finish.', 'STALE_SOURCE_NOTE_UNDO');
    const placement = directSourcePlacement(folder, sourceId);
    const currentVersion = Math.max(1, Math.round(Number(folder.collection.version) || 1));
    const expectedVersion = Math.round(Number(payload.expectedVersion) || 0);
    if (!expectedVersion || expectedVersion !== currentVersion) {
      throw codedError('That folder changed after this edit. Undo was stopped so newer wording would not be overwritten.', 'STALE_SOURCE_NOTE_UNDO');
    }
    if (currentVersion === 10000 && (!Number.isSafeInteger(payload.expectedRevision) ||
        payload.expectedRevision !== state._revision)) {
      throw codedError('ProgRSS changed after this edit. Undo was stopped so a newer folder relationship would not be overwritten.', 'STALE_SOURCE_NOTE_UNDO');
    }
    if (!Object.prototype.hasOwnProperty.call(payload, 'expectedCurrentReason') ||
        !Object.prototype.hasOwnProperty.call(payload, 'previousReason')) {
      throw codedError('The Source Note undo is incomplete.', 'INVALID_SOURCE_NOTE_UNDO');
    }
    const currentReason = Object.prototype.hasOwnProperty.call(placement, 'reason')
      ? sourceNoteReasonOrError(placement.reason)
      : undefined;
    const expectedCurrentReason = sourceNoteReasonOrError(payload.expectedCurrentReason);
    if (currentReason !== expectedCurrentReason) {
      throw codedError('That reason changed after this edit. Undo was stopped so the newer wording would be kept.', 'STALE_SOURCE_NOTE_UNDO');
    }
    const previousReason = sourceNoteReasonOrError(payload.previousReason);
    if (previousReason === undefined) delete placement.reason;
    else placement.reason = previousReason;
    folder.collection.version = Math.min(10000, currentVersion + 1);
    await saveAndBroadcast(state, {kind: 'source-note-undo', sourceId, collectionId});
    return {
      restored: true, sourceId, collectionId, folderPath: folder.path,
      folderVersion: folder.collection.version,
      reason: previousReason ?? null
    };
  });
}

function sourceTextCleanupCandidates(state, sourceId) {
  const candidates = (state.items || [])
    .filter(item => C.text(item?.sourceId, 300) === sourceId && item.readAt && !item.starred && item.body && !item.bodyIsSummary)
    .sort((a, b) => (Date.parse(a.observedAt || a.published || '') || 0) - (Date.parse(b.observedAt || b.published || '') || 0));
  const selected = [];
  let bytes = 0;
  for (const item of candidates) {
    if (selected.length >= MAX_TEXT_CLEANUP_ITEMS) break;
    const itemBytes = byteLength(item.body);
    if (selected.length && bytes + itemBytes > MAX_TEXT_CLEANUP_BYTES) break;
    selected.push(item);
    bytes += itemBytes;
  }
  return {candidates, selected, bytes};
}

async function setSourceTextRetention(payload = {}) {
  return queueMutation(async () => {
    const state = await loadState();
    const sourceId = C.text(payload.sourceId, 300);
    const source = (state.sources || []).find(row => C.text(row?.id, 300) === sourceId && !row.archivedAt);
    if (!source || source.type !== 'rss') throw codedError('That feed is no longer available.', 'SOURCE_NOT_FOUND');
    const mode = String(payload.mode || '').toLowerCase();
    if (!['full', 'summary'].includes(mode)) throw codedError('Choose full feed text or summaries only.', 'INVALID_TEXT_RETENTION');
    if (mode === 'summary') source.textRetention = 'summary';
    else delete source.textRetention;
    await saveAndBroadcast(state, {kind: 'source-text-retention', sourceId, mode});
    const plan = sourceTextCleanupCandidates(state, sourceId);
    return {
      sourceId,
      mode,
      cleanupEligible: plan.candidates.length,
      cleanupBatch: plan.selected.length,
      cleanupBytes: plan.bytes
    };
  });
}

async function pruneSourceText(payload = {}) {
  return queueMutation(async () => {
    const state = await loadState();
    const sourceId = C.text(payload.sourceId, 300);
    const source = (state.sources || []).find(row => C.text(row?.id, 300) === sourceId && !row.archivedAt);
    if (!source || source.type !== 'rss') throw codedError('That feed is no longer available.', 'SOURCE_NOT_FOUND');
    if (source.textRetention !== 'summary') throw codedError('Choose summaries only before removing older full text, so a later check does not immediately store it again.', 'TEXT_RETENTION_FULL');
    const plan = sourceTextCleanupCandidates(state, sourceId);
    if (!plan.selected.length) return {sourceId, changed: [], bytes: 0, remaining: 0, remainingBytes: 0, expectedRevision: state._revision};
    const changed = plan.selected.map(item => ({
      id: C.text(item.id, 700),
      body: C.bodyText(item.body, C.LIMIT.body),
      bodyIsSummary: Boolean(item.bodyIsSummary),
      bodyLanguage: C.languageTag(item.bodyLanguage),
      bodyOmitted: Boolean(item.bodyOmitted)
    }));
    for (const item of plan.selected) {
      item.body = C.text(item.summary || '', 1200);
      item.bodyIsSummary = true;
      item.bodyOmitted = true;
      const language = C.languageTag(item.summaryLanguage || item.language || source.language);
      if (language) item.bodyLanguage = language; else delete item.bodyLanguage;
    }
    await saveAndBroadcast(state, {kind: 'source-text-pruned', sourceId, count: changed.length});
    const remainingPlan = sourceTextCleanupCandidates(state, sourceId);
    return {
      sourceId,
      changed,
      bytes: plan.bytes,
      remaining: remainingPlan.candidates.length,
      remainingBytes: remainingPlan.candidates.reduce((total, item) => total + byteLength(item.body), 0),
      expectedRevision: state._revision
    };
  });
}

async function undoSourceTextPrune(payload = {}) {
  return queueMutation(async () => {
    const state = await loadState();
    const expectedRevision = Math.round(Number(payload.expectedRevision) || 0);
    if (!expectedRevision || state._revision !== expectedRevision) {
      throw codedError('ProgRSS changed after this cleanup. Undo was stopped so newer reading and source changes would not be overwritten.', 'STALE_TEXT_CLEANUP_UNDO');
    }
    const sourceId = C.text(payload.sourceId, 300);
    const source = (state.sources || []).find(row => C.text(row?.id, 300) === sourceId && !row.archivedAt);
    if (!source || source.type !== 'rss') throw codedError('That feed changed before undo could finish.', 'STALE_TEXT_CLEANUP_UNDO');
    const rows = Array.isArray(payload.items) ? payload.items.slice(0, MAX_TEXT_CLEANUP_ITEMS) : [];
    if (!rows.length || rows.length !== (payload.items || []).length) throw codedError('The cleanup undo is incomplete.', 'INVALID_TEXT_CLEANUP_UNDO');
    let bytes = 0;
    const restored = [];
    for (const row of rows) {
      if (!row || typeof row !== 'object' || Array.isArray(row)) throw codedError('The cleanup undo is invalid.', 'INVALID_TEXT_CLEANUP_UNDO');
      const id = C.text(row.id, 700);
      const body = C.bodyText(row.body, C.LIMIT.body);
      bytes += byteLength(body);
      if (bytes > MAX_TEXT_CLEANUP_BYTES + C.LIMIT.body * 4) throw codedError('The cleanup undo is too large.', 'INVALID_TEXT_CLEANUP_UNDO');
      const item = (state.items || []).find(candidate => C.text(candidate?.id, 700) === id && C.text(candidate?.sourceId, 300) === sourceId);
      if (!item || !item.bodyOmitted || !item.bodyIsSummary || C.text(item.body || '', 1200) !== C.text(item.summary || '', 1200)) {
        throw codedError('One of those updates changed after cleanup. Its newer state was kept.', 'STALE_TEXT_CLEANUP_UNDO');
      }
      restored.push({item, row, body});
    }
    for (const {item, row, body} of restored) {
      item.body = body;
      item.bodyIsSummary = Boolean(row.bodyIsSummary);
      if (row.bodyOmitted) item.bodyOmitted = true; else delete item.bodyOmitted;
      const language = C.languageTag(row.bodyLanguage);
      if (language) item.bodyLanguage = language; else delete item.bodyLanguage;
    }
    await saveAndBroadcast(state, {kind: 'source-text-prune-undo', sourceId, count: restored.length});
    return {sourceId, restored: restored.length};
  });
}

async function undoSourceFolderAdd(payload = {}) {
  return queueMutation(async () => {
    const state = await loadState();
    const sourceId = C.text(payload.sourceId, 300);
    const collectionId = C.text(payload.collectionId, 300);
    const rows = basicFolderRows(state);
    const folder = rows.find(row => row.id === collectionId);
    if (!folder) throw codedError('That folder changed before undo could finish.', 'STALE_FOLDER_UNDO');
    const expectedVersion = Math.round(Number(payload.expectedVersion) || 0);
    const currentVersion = Math.max(1, Math.round(Number(folder.collection.version) || 1));
    if (!expectedVersion || currentVersion !== expectedVersion) throw codedError('That folder changed in another view. Its newer organization was kept.', 'STALE_FOLDER_UNDO');
    // Folder versions saturate at 10000. At that ceiling, an old add undo
    // must not remove a replacement placement (or a placement that gained a
    // Source Note) merely because the capped version still matches.
    if (currentVersion === 10000 && (!Number.isSafeInteger(payload.expectedRevision) ||
        payload.expectedRevision !== state._revision)) {
      throw codedError('ProgRSS changed after this folder placement was added. Its newer organization was kept.', 'STALE_FOLDER_UNDO');
    }
    const placements = folder.collection.members
      .map((member, index) => ({member, index}))
      .filter(row => row.member?.kind === 'source' && C.text(row.member.id, 300) === sourceId);
    if (placements.length !== 1 || Object.prototype.hasOwnProperty.call(placements[0].member, 'reason')) {
      throw codedError('That folder placement changed after it was added. Its newer organization was kept.', 'STALE_FOLDER_UNDO');
    }
    folder.collection.members.splice(placements[0].index, 1);
    folder.collection.version = Math.min(10000, currentVersion + 1);
    await saveAndBroadcast(state, {kind: 'source-folder-remove', sourceId, collectionId});
    return {removed: true, sourceId, collectionId, folderPath: folder.path, membership: folderMembership(basicFolderRows(state), sourceId)};
  });
}

async function undoSourceFolderRemove(payload = {}) {
  return queueMutation(async () => {
    const state = await loadState();
    const sourceId = C.text(payload.sourceId, 300);
    const collectionId = C.text(payload.collectionId, 300);
    const source = (state.sources || []).find(row => C.text(row?.id, 300) === sourceId && !row.archivedAt);
    if (!source) throw codedError('That source changed before undo could finish.', 'STALE_FOLDER_UNDO');
    const rows = basicFolderRows(state);
    const folder = rows.find(row => row.id === collectionId);
    if (!folder) throw codedError('That folder changed before undo could finish.', 'STALE_FOLDER_UNDO');
    const expectedVersion = Math.round(Number(payload.expectedVersion) || 0);
    const currentVersion = Math.max(1, Math.round(Number(folder.collection.version) || 1));
    if (!expectedVersion || currentVersion !== expectedVersion) throw codedError('That folder changed in another view. Its newer organization was kept.', 'STALE_FOLDER_UNDO');
    // Folder versions saturate at 10000; at that limit only an exact vault
    // revision can prove there has been no intervening change.
    if (currentVersion === 10000 && (!Number.isSafeInteger(payload.expectedRevision) ||
        payload.expectedRevision !== state._revision)) {
      throw codedError('ProgRSS changed after this removal. Its newer organization was kept.', 'STALE_FOLDER_UNDO');
    }
    // Inherited membership is not a replacement for the removed direct reason.
    if (folder.directSourceIds.has(sourceId)) throw codedError('That source’s folder relationship changed in another view. Its newer organization was kept.', 'STALE_FOLDER_UNDO');
    if (folder.collection.members.length >= 150) throw codedError('That folder changed and is now full. Its newer organization was kept.', 'STALE_FOLDER_UNDO');
    const removed = payload.removedMember;
    const index = payload.removedIndex;
    if (!removed || typeof removed !== 'object' || Array.isArray(removed) ||
        removed.kind !== 'source' || removed.id !== sourceId ||
        Object.keys(removed).some(key => !['kind', 'id', 'reason'].includes(key)) ||
        !Number.isSafeInteger(index) || index < 0 || index > folder.collection.members.length) {
      throw codedError('The removed folder relationship is incomplete. Nothing changed.', 'INVALID_FOLDER_UNDO');
    }
    const restoredMember = {kind: 'source', id: sourceId};
    const reason = sourceNoteReasonOrError(removed.reason);
    if (reason !== undefined) restoredMember.reason = reason;
    folder.collection.members.splice(index, 0, restoredMember);
    folder.collection.version = Math.min(10000, currentVersion + 1);
    await saveAndBroadcast(state, {kind: 'source-folder-add', sourceId, collectionId});
    return {added: true, sourceId, collectionId, folderPath: folder.path, membership: folderMembership(basicFolderRows(state), sourceId)};
  });
}

function jsonClone(value) {
  return JSON.parse(JSON.stringify(value));
}

function canonicalJsonString(value) {
  for (let index = 0; index < value.length; index++) {
    const code = value.charCodeAt(index);
    if (code >= 0xD800 && code <= 0xDBFF) {
      const next = value.charCodeAt(index + 1);
      if (!(next >= 0xDC00 && next <= 0xDFFF)) {
        throw codedError('The receipt contains invalid Unicode and cannot receive a portable digest.', 'RECEIPT_NOT_CANONICAL');
      }
      index++;
    } else if (code >= 0xDC00 && code <= 0xDFFF) {
      throw codedError('The receipt contains invalid Unicode and cannot receive a portable digest.', 'RECEIPT_NOT_CANONICAL');
    }
  }
  return JSON.stringify(value);
}

function canonicalJson(value) {
  if (value === null || typeof value === 'boolean') return JSON.stringify(value);
  if (typeof value === 'string') return canonicalJsonString(value);
  if (typeof value === 'number') {
    if (!Number.isSafeInteger(value)) throw codedError('This release retires only receipts whose numeric fields are portable safe integers.', 'RECEIPT_NOT_CANONICAL');
    return String(value);
  }
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  if (value && typeof value === 'object') {
    return `{${Object.keys(value).sort().map(key => `${canonicalJsonString(key)}:${canonicalJson(value[key])}`).join(',')}}`;
  }
  throw codedError('The receipt contains a value that cannot be represented as portable JSON.', 'RECEIPT_NOT_CANONICAL');
}

async function canonicalDigest(value) {
  const bytes = new TextEncoder().encode(canonicalJson(value));
  const digest = await globalThis.crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(digest)].map(value => value.toString(16).padStart(2, '0')).join('');
}

function sourceRepairReferenceTargets(state, pairSources) {
  const sourceTitles = new Map(pairSources.map(source => [C.text(source.id, 300), C.text(source.title, 180) || 'Untitled source']));
  const targets = new Map();
  for (const source of pairSources) {
    const sourceId = C.text(source.id, 300);
    targets.set(sourceId, {kind: 'source', targetId: sourceId, sourceId, sourceTitle: sourceTitles.get(sourceId), label: 'Source history'});
  }
  const affectedItems = pairSources.flatMap(source => sourceItems(state, C.text(source.id, 300)));
  for (const item of affectedItems) {
    const targetId = C.text(item?.id, 700);
    if (!targetId) continue;
    const sourceId = C.text(item?.sourceId, 300);
    targets.set(targetId, {
      kind: 'update', targetId, sourceId,
      sourceTitle: sourceTitles.get(sourceId) || 'Source history',
      label: C.text(item?.title, 180) || 'Retained update'
    });
  }
  return {sourceTitles, targets};
}

function graftReceiptRetirementMetadata(key, record, result) {
  const schema = C.text(record?.schema, 180);
  if (key !== 'receipts' || schema !== GRAFT_RECEIPT_SCHEMA) return null;
  if (result?.count < 1) return null;
  return {
    eligible: true,
    action: 'retire-graft-receipt',
    label: 'Review retirement',
    explanation: 'ProgRSS can preserve this exact graft receipt in a retired-evidence archive without changing what it recorded.'
  };
}

function sourceAliasRows(source) {
  const rows = [];
  const seen = new Set();
  const add = (raw, kind) => {
    try {
      const url = C.safeUrl(raw);
      if (seen.has(url)) return;
      seen.add(url);
      rows.push({url, kind});
    } catch {}
  };
  add(source?.url, 'current');
  add(source?.declaredFeedUrl, 'declared');
  for (const value of Array.isArray(source?.previousUrls) ? source.previousUrls : []) add(value, 'previous');
  for (const value of Array.isArray(source?.aliasUrls) ? source.aliasUrls : []) add(value, 'repair');
  return rows;
}

function sharedSourceAddresses(left, right) {
  const rightAliases = new Set(sourceAliasRows(right).map(row => row.url));
  return sourceAliasRows(left).filter(row => rightAliases.has(row.url)).map(row => row.url);
}

function sourceRepairPair(state, firstId, secondId) {
  const first = (state.sources || []).find(row => C.text(row?.id, 300) === C.text(firstId, 300));
  const second = (state.sources || []).find(row => C.text(row?.id, 300) === C.text(secondId, 300));
  if (!first || !second || first === second) throw codedError('Choose two different sources that are still in this library.', 'SOURCE_REPAIR_NOT_FOUND');
  if (first.type !== 'rss' || second.type !== 'rss') throw codedError('Same-source repair is limited to feeds. Page watches keep separate histories.', 'SOURCE_REPAIR_TYPE');
  if (first.archivedAt || second.archivedAt) throw codedError('Restore archived sources before combining their histories.', 'SOURCE_REPAIR_ARCHIVED');
  const sharedAddresses = sharedSourceAddresses(first, second);
  if (!sharedAddresses.length) throw codedError('These sources no longer share a reviewed address. Nothing was combined.', 'SOURCE_REPAIR_NO_EVIDENCE');
  return {first, second, sharedAddresses};
}

function advancedReferenceReason(key) {
  if (key === 'fixtures' || key === 'snapshots') return 'This material preserves exact before-and-after evidence. Rewriting an identity could change what the evidence proves.';
  if (ADVANCED_EVIDENCE_KEYS.has(key)) return 'This record describes past evidence or a completed operation. Rewriting it would make the record describe something that did not happen.';
  if (ADVANCED_TRUST_KEYS.has(key)) return 'This record binds trust to an exact local identity. ProgRSS cannot transfer that trust to another history automatically.';
  if (ADVANCED_EXCHANGE_KEYS.has(key)) return 'This record may contain a proposal, subscription, or request. ProgRSS cannot decide whether its reference should be retargeted or discarded.';
  return 'ProgRSS has no meaning-preserving rewrite rule for this record type.';
}

function advancedRecordDescriptor(record, key, index) {
  const row = record && typeof record === 'object' && !Array.isArray(record) ? record : {};
  const idKeys = ['id','receiptId','publicationId','pinId','requestId','sightingId','forkId','packId','policyId','claimId','keyId','digest','hash','fingerprint'];
  const titleKeys = ['title','name','label','subject','note','summary'];
  const recordId = idKeys.map(name => C.text(row[name], 220)).find(Boolean) || `${key}:${index + 1}`;
  const schema = C.text(row.schema, 180);
  const title = titleKeys.map(name => C.text(row[name], 180)).find(Boolean) || schema || `${ADVANCED_REFERENCE_LABELS[key] || 'Advanced record'} ${index + 1}`;
  return {index, recordId, title, schema};
}

function exactStringReferenceDetails(value, targets, budget, path = '$', result = {count: 0, sourceCount: 0, updateCount: 0, hits: []}) {
  if (budget.nodes++ > 25_000) { budget.exceeded = true; return result; }
  if (typeof value === 'string') {
    const target = targets.get(value);
    if (!target) return result;
    result.count++;
    if (target.kind === 'source') result.sourceCount++;
    if (target.kind === 'update') result.updateCount++;
    if (result.hits.length < MAX_REFERENCE_HITS_PER_RECORD) result.hits.push({...target, path});
    return result;
  }
  if (!value || typeof value !== 'object') return result;
  if (Array.isArray(value)) {
    for (let index = 0; index < value.length && !budget.exceeded; index++) {
      exactStringReferenceDetails(value[index], targets, budget, `${path}[${index}]`, result);
    }
  } else {
    for (const [key, row] of Object.entries(value)) {
      if (budget.exceeded) break;
      exactStringReferenceDetails(row, targets, budget, `${path}[${JSON.stringify(key)}]`, result);
    }
  }
  return result;
}

function summarizedReferenceTargets(hits) {
  const grouped = new Map();
  for (const hit of hits) {
    if (!grouped.has(hit.targetId)) grouped.set(hit.targetId, {
      kind: hit.kind,
      targetId: hit.targetId,
      sourceId: hit.sourceId,
      sourceTitle: hit.sourceTitle,
      label: hit.label,
      referenceCount: 0,
      paths: []
    });
    const row = grouped.get(hit.targetId);
    row.referenceCount++;
    if (row.paths.length < 6 && !row.paths.includes(hit.path)) row.paths.push(hit.path);
  }
  return [...grouped.values()];
}

function sourceReferenceReport(state, first, second) {
  const pairSources = [first, second];
  const {sourceTitles, targets} = sourceRepairReferenceTargets(state, pairSources);

  const groups = [];
  let blockingRecords = 0;
  let exactReferences = 0;
  let sourceHistoryReferences = 0;
  let retainedUpdateReferences = 0;
  let scanExceeded = false;
  for (const key of Object.keys(PRIVATE_ARRAY_LIMITS)) {
    const rows = Array.isArray(state[key]) ? state[key] : [];
    const budget = {nodes: 0, exceeded: false};
    const records = [];
    let groupReferences = 0;
    for (let index = 0; index < rows.length && !budget.exceeded; index++) {
      const result = exactStringReferenceDetails(rows[index], targets, budget);
      if (!result.count) continue;
      const descriptor = advancedRecordDescriptor(rows[index], key, index);
      const references = summarizedReferenceTargets(result.hits);
      const capturedReferences = references.reduce((total, row) => total + row.referenceCount, 0);
      const sourceCount = result.sourceCount;
      const updateCount = result.updateCount;
      records.push({
        ...descriptor,
        referenceCount: result.count,
        sourceReferenceCount: sourceCount,
        updateReferenceCount: updateCount,
        references,
        pathsTruncated: result.count > capturedReferences,
        retirement: graftReceiptRetirementMetadata(key, rows[index], result)
      });
      groupReferences += result.count;
      sourceHistoryReferences += sourceCount;
      retainedUpdateReferences += updateCount;
    }
    if (!records.length && !budget.exceeded) continue;
    blockingRecords += records.length;
    exactReferences += groupReferences;
    scanExceeded = scanExceeded || budget.exceeded;
    groups.push({
      key,
      label: ADVANCED_REFERENCE_LABELS[key] || key,
      reason: advancedReferenceReason(key),
      recordCount: records.length,
      referenceCount: groupReferences,
      scanExceeded: budget.exceeded,
      records
    });
  }

  const snapshots = state.snapshots && typeof state.snapshots === 'object' && !Array.isArray(state.snapshots) ? state.snapshots : {};
  const snapshotRecords = pairSources.flatMap(source => {
    const sourceId = C.text(source.id, 300);
    if (!snapshots[sourceId]) return [];
    return [{
      index: 0,
      recordId: sourceId,
      title: `${sourceTitles.get(sourceId)} snapshot`,
      schema: '',
      referenceCount: 1,
      sourceReferenceCount: 1,
      updateReferenceCount: 0,
      references: [{kind: 'source', targetId: sourceId, sourceId, sourceTitle: sourceTitles.get(sourceId), label: 'Source history', referenceCount: 1, paths: [`$[${JSON.stringify(sourceId)}]`]}],
      pathsTruncated: false
    }];
  });
  if (snapshotRecords.length) {
    blockingRecords += snapshotRecords.length;
    exactReferences += snapshotRecords.length;
    sourceHistoryReferences += snapshotRecords.length;
    groups.push({
      key: 'snapshots',
      label: ADVANCED_REFERENCE_LABELS.snapshots,
      reason: advancedReferenceReason('snapshots'),
      recordCount: snapshotRecords.length,
      referenceCount: snapshotRecords.length,
      scanExceeded: false,
      records: snapshotRecords
    });
  }

  const retiredEvidence = [];
  let retiredReferences = 0;
  for (const [index, envelope] of (Array.isArray(state.retiredReceipts) ? state.retiredReceipts : []).entries()) {
    if (!envelope || envelope.schema !== RETIRED_GRAFT_RECEIPT_SCHEMA || !envelope.originalReceipt) continue;
    const budget = {nodes: 0, exceeded: false};
    const result = exactStringReferenceDetails(envelope.originalReceipt, targets, budget);
    if (!result.count) continue;
    retiredReferences += result.count;
    retiredEvidence.push({
      index,
      retirementId: C.text(envelope.id, 220),
      retiredAt: isoTime(envelope.retiredAt),
      originalDigest: C.text(envelope.originalDigest, 64),
      originalRecordId: C.text(envelope.originalRecordId, 220),
      originalTitle: C.text(envelope.originalTitle, 180) || GRAFT_RECEIPT_SCHEMA,
      referenceCount: result.count,
      references: summarizedReferenceTargets(result.hits),
      pathsTruncated: result.count > result.hits.length,
      scanExceeded: budget.exceeded
    });
  }

  return {
    schema: 'progrss.source-reference-report.v1',
    reviewedRevision: state._revision,
    sources: pairSources.map(source => ({id: C.text(source.id, 300), title: C.text(source.title, 180) || 'Untitled source', url: C.text(source.url, 2048)})),
    summary: {
      blockingGroups: groups.length,
      blockingRecords,
      exactReferences,
      sourceHistoryReferences,
      retainedUpdateReferences,
      retiredRecords: retiredEvidence.length,
      retiredReferences,
      scanExceeded
    },
    groups,
    retiredEvidence,
    retirementUndo: receiptRetirementUndoInfo(state),
    network: false,
    writes: false,
    browserProfileRead: false,
    note: 'This report does not rewrite or transfer trust. An eligible graft receipt may be moved intact into retired evidence only after a separate review.'
  };
}

function sourceRepairPlacementPlan(state, firstId, secondId) {
  const sourceIds = [C.text(firstId, 300), C.text(secondId, 300)];
  const sourceIdSet = new Set(sourceIds);
  const paths = new Map();
  try {
    for (const row of basicFolderRows(state)) paths.set(row.id, row.path);
  } catch {}
  const collections = [];
  const conflicts = [];
  for (const collection of state.collections || []) {
    if (!collection || !Array.isArray(collection.members)) continue;
    const placements = collection.members
      .map((member, index) => ({member, index}))
      .filter(row => row.member?.kind === 'source' && sourceIdSet.has(C.text(row.member.id, 300)));
    if (!placements.length) continue;
    const normalized = [];
    for (const row of placements) {
      try {
        normalized.push({
          sourceId: C.text(row.member.id, 300),
          index: row.index,
          reason: Object.hasOwn(row.member, 'reason') ? C.normalizeSourceNoteReason(row.member.reason) : undefined
        });
      } catch (error) {
        conflicts.push({
          kind: 'invalid-reason',
          folderId: C.text(collection.id, 300),
          folderTitle: C.text(collection.title, 180) || 'Untitled folder',
          folderPath: paths.get(collection.id) || C.text(collection.title, 180) || C.text(collection.id, 300),
          sourceId: C.text(row.member.id, 300),
          message: C.text(error?.message, 300) || 'The placement reason is invalid.'
        });
      }
    }
    if (conflicts.some(row => row.folderId === C.text(collection.id, 300) && row.kind === 'invalid-reason')) continue;
    const reasons = [...new Set(normalized.map(row => row.reason).filter(reason => reason !== undefined))];
    if (reasons.length > 1) {
      const first = normalized.find(row => row.sourceId === sourceIds[0]);
      const second = normalized.find(row => row.sourceId === sourceIds[1]);
      conflicts.push({
        kind: 'divergent-reasons',
        folderId: C.text(collection.id, 300),
        folderTitle: C.text(collection.title, 180) || 'Untitled folder',
        folderPath: paths.get(collection.id) || C.text(collection.title, 180) || C.text(collection.id, 300),
        firstSourceId: sourceIds[0],
        secondSourceId: sourceIds[1],
        firstReason: first?.reason ?? null,
        secondReason: second?.reason ?? null
      });
      continue;
    }
    collections.push({
      folderId: C.text(collection.id, 300),
      firstIndex: placements[0].index,
      placementCount: placements.length,
      mergedReason: reasons[0]
    });
  }
  return {collections, conflicts};
}

function sourceRepairReasonConflictMessage(conflicts) {
  const count = conflicts.length;
  const paths = conflicts.slice(0, 3).map(row => row.folderPath || row.folderTitle || row.folderId).filter(Boolean);
  const where = paths.length ? ` in ${paths.join(', ')}${count > paths.length ? ', and more' : ''}` : '';
  return `${count} direct folder placement${count === 1 ? '' : 's'}${where} ${count === 1 ? 'has' : 'have'} incompatible Source Notes. Edit or clear one reason before combining these histories; ProgRSS will not choose a reason automatically.`;
}

function sourceRepairBlockers(state, first, second) {
  const referenceReport = sourceReferenceReport(state, first, second);
  const placementPlan = sourceRepairPlacementPlan(state, first.id, second.id);
  const blockers = [];
  const advancedReferences = referenceReport.groups
    .filter(group => Object.hasOwn(PRIVATE_ARRAY_LIMITS, group.key) && group.referenceCount)
    .map(group => ({key: group.key, count: group.referenceCount}));
  if (placementPlan.conflicts.length) blockers.push(sourceRepairReasonConflictMessage(placementPlan.conflicts));
  if (advancedReferences.length) {
    blockers.push('Advanced Workbench records refer to one of these source histories. Open References to these histories to see each blocking record before deciding what to keep or remove.');
  }
  if (referenceReport.summary.scanExceeded) blockers.push('Some Advanced Workbench records are too large to audit safely. The references report identifies the affected record groups.');
  if (referenceReport.groups.some(group => group.key === 'snapshots')) blockers.push('A page-watch snapshot is attached to one of these feed identities. Review it in the Advanced Workbench first.');
  return {
    blockers,
    advancedReferences,
    scanExceeded: referenceReport.summary.scanExceeded,
    referenceReport,
    placementConflicts: placementPlan.conflicts,
    placementPlan
  };
}

function isoTime(raw) {
  const stamp = Date.parse(raw || '');
  return Number.isFinite(stamp) ? new Date(stamp).toISOString() : '';
}

function newestIso(...values) {
  return values.map(isoTime).filter(Boolean).sort().at(-1) || '';
}

function oldestIso(...values) {
  return values.map(isoTime).filter(Boolean).sort()[0] || '';
}

function sourceItems(state, sourceId) {
  return (state.items || []).filter(item => C.text(item?.sourceId, 300) === sourceId);
}

function sourceItemStats(state, sourceId) {
  const items = sourceItems(state, sourceId);
  return {
    items: items.length,
    unread: items.filter(item => !item.readAt).length,
    saved: items.filter(item => item.starred).length,
    newestAt: newestIso(...items.map(item => item.observedAt || item.published))
  };
}

function itemRepairTail(item, sourceIds) {
  let value = C.text(item?.entryKey || item?.id, 700);
  for (const sourceId of sourceIds) {
    const prefix = `${sourceId}|`;
    if (value.startsWith(prefix)) {
      value = value.slice(prefix.length);
      break;
    }
  }
  if (!item?.entryKey && Number.isFinite(Number(item?.feedRevision))) value = value.replace(/\|edit:\d+$/, '');
  return value.slice(0, 500) || `legacy:${C.text(item?.id, 300)}`;
}

function itemRepairFingerprint(item) {
  return JSON.stringify([
    C.text(item?.title, 240),
    C.text(item?.summary, 1200),
    C.bodyText(item?.body || item?.summary || '', C.LIMIT.body),
    Boolean(item?.bodyIsSummary) || !item?.body,
    Boolean(item?.bodyOmitted),
    C.text(item?.url, 2048),
    isoTime(item?.published)
  ]);
}

function itemRepairTime(item) {
  return Date.parse(item?.observedAt || item?.published || '') || 0;
}

function mergeSourceItems(state, survivorId, otherId) {
  const sourceIds = [survivorId, otherId];
  const affected = [];
  const untouched = [];
  for (const item of state.items || []) {
    if (sourceIds.includes(C.text(item?.sourceId, 300))) affected.push(item);
    else untouched.push(item);
  }
  const groups = new Map();
  for (const item of affected) {
    const tail = itemRepairTail(item, sourceIds);
    if (!groups.has(tail)) groups.set(tail, []);
    groups.get(tail).push(item);
  }
  const merged = [];
  let exactRepeatsCollapsed = 0;
  for (const [tail, rows] of groups) {
    const byContent = new Map();
    for (const row of rows) {
      const fingerprint = itemRepairFingerprint(row);
      if (!byContent.has(fingerprint)) byContent.set(fingerprint, []);
      byContent.get(fingerprint).push(row);
    }
    exactRepeatsCollapsed += rows.length - byContent.size;
    const events = [];
    for (const matches of byContent.values()) {
      const ordered = [...matches].sort((a, b) => itemRepairTime(a) - itemRepairTime(b) || C.text(a.id, 700).localeCompare(C.text(b.id, 700)));
      const preferred = {...ordered.at(-1)};
      const firstObserved = oldestIso(...matches.map(item => item.observedAt || item.published));
      if (firstObserved) preferred.observedAt = firstObserved;
      preferred.readAt = matches.some(item => !item.readAt) ? '' : oldestIso(...matches.map(item => item.readAt));
      preferred.starred = matches.some(item => Boolean(item.starred));
      events.push(preferred);
    }
    events.sort((a, b) => itemRepairTime(a) - itemRepairTime(b) || Number(a.feedRevision || 0) - Number(b.feedRevision || 0) || C.text(a.id, 700).localeCompare(C.text(b.id, 700)));
    const entryKey = `${survivorId}|${tail}`;
    events.forEach((event, index) => {
      const row = {...event};
      row.sourceId = survivorId;
      row.entryKey = entryKey;
      row.feedRevision = index;
      row.id = index ? `${entryKey}|edit:${index}` : entryKey;
      row.kind = index ? 'changed' : 'new';
      merged.push(row);
    });
  }
  const items = [...untouched, ...merged]
    .sort((a, b) => itemRepairTime(b) - itemRepairTime(a) || C.text(b.id, 700).localeCompare(C.text(a.id, 700)))
    .slice(0, C.LIMIT.items);
  const survivorItems = items.filter(item => C.text(item?.sourceId, 300) === survivorId);
  return {
    items,
    beforeCount: affected.length,
    afterCount: survivorItems.length,
    exactRepeatsCollapsed,
    identityCount: groups.size,
    unread: survivorItems.filter(item => !item.readAt).length,
    saved: survivorItems.filter(item => item.starred).length
  };
}

function remapCollectionSource(state, otherId, survivorId, placementPlan = sourceRepairPlacementPlan(state, survivorId, otherId)) {
  if (placementPlan.conflicts.length) throw codedError(sourceRepairReasonConflictMessage(placementPlan.conflicts), 'SOURCE_REPAIR_REASON_CONFLICT', {placementConflicts: placementPlan.conflicts});
  const planByFolder = new Map(placementPlan.collections.map(row => [row.folderId, row]));
  let changedCollections = 0;
  for (const collection of state.collections || []) {
    if (!collection || !Array.isArray(collection.members)) continue;
    const folderPlan = planByFolder.get(C.text(collection.id, 300));
    let changed = false;
    let pairWritten = false;
    const seen = new Set();
    const members = [];
    for (const member of collection.members) {
      if (!member || typeof member !== 'object') continue;
      const pairMember = member.kind === 'source' && [survivorId, otherId].includes(C.text(member.id, 300));
      let next;
      if (pairMember && folderPlan) {
        if (pairWritten) { changed = true; continue; }
        pairWritten = true;
        next = {...member, id: survivorId};
        delete next.reason;
        if (folderPlan.mergedReason !== undefined) next.reason = folderPlan.mergedReason;
      } else {
        next = member.kind === 'source' && C.text(member.id, 300) === otherId ? {...member, id: survivorId} : {...member};
      }
      if (JSON.stringify(next) !== JSON.stringify(member)) changed = true;
      const key = `${C.text(next.kind, 30)}:${C.text(next.id, 300)}`;
      if (seen.has(key)) { changed = true; continue; }
      seen.add(key);
      members.push(next);
    }
    if (!changed) continue;
    collection.members = members;
    collection.version = Math.min(10000, Math.max(1, Math.round(Number(collection.version) || 1)) + 1);
    changedCollections++;
  }
  return changedCollections;
}

function mergeSourceAliasEvidence(survivor, other) {
  const occupied = new Set();
  for (const raw of [survivor.url, survivor.declaredFeedUrl, ...(Array.isArray(survivor.previousUrls) ? survivor.previousUrls : [])]) {
    try { occupied.add(C.safeUrl(raw)); } catch {}
  }
  const aliases = [];
  const seen = new Set(occupied);
  for (const row of [...sourceAliasRows(survivor), ...sourceAliasRows(other)]) {
    if (seen.has(row.url)) continue;
    seen.add(row.url);
    aliases.push(row.url);
  }
  survivor.aliasUrls = aliases.slice(0, 12);
  if (!survivor.aliasUrls.length) delete survivor.aliasUrls;
}

function applySourceRepair(state, survivorId, otherId, stamp = new Date().toISOString()) {
  const survivor = (state.sources || []).find(row => C.text(row?.id, 300) === survivorId);
  const other = (state.sources || []).find(row => C.text(row?.id, 300) === otherId);
  if (!survivor || !other) throw codedError('One of these sources changed before the repair could finish.', 'SOURCE_REPAIR_STALE');
  const placementPlan = sourceRepairPlacementPlan(state, survivorId, otherId);
  if (placementPlan.conflicts.length) throw codedError(sourceRepairReasonConflictMessage(placementPlan.conflicts), 'SOURCE_REPAIR_REASON_CONFLICT', {placementConflicts: placementPlan.conflicts});
  const sharedAddresses = sharedSourceAddresses(survivor, other);
  const itemMerge = mergeSourceItems(state, survivorId, otherId);
  state.items = itemMerge.items;
  const changedCollections = remapCollectionSource(state, otherId, survivorId, placementPlan);
  mergeSourceAliasEvidence(survivor, other);
  survivor.createdAt = oldestIso(survivor.createdAt, other.createdAt) || survivor.createdAt || other.createdAt || stamp;
  survivor.lastSuccessfulAt = newestIso(survivor.lastSuccessfulAt, other.lastSuccessfulAt);
  survivor.lastNewAt = newestIso(survivor.lastNewAt, other.lastNewAt);
  const latestProblem = [survivor, other]
    .filter(source => isoTime(source.lastProblemAt || source.lastScan))
    .sort((a, b) => Date.parse(a.lastProblemAt || a.lastScan || '') - Date.parse(b.lastProblemAt || b.lastScan || ''))
    .at(-1);
  if (latestProblem) {
    survivor.lastProblemAt = isoTime(latestProblem.lastProblemAt || latestProblem.lastScan);
    survivor.lastProblem = C.text(latestProblem.lastProblem || latestProblem.lastError, 500);
  }
  survivor.checkCount = Math.max(0, Number(survivor.checkCount) || 0) + Math.max(0, Number(other.checkCount) || 0);
  const history = [survivor, other]
    .flatMap(source => Array.isArray(source.repairHistory) ? source.repairHistory : [])
    .filter(row => row && typeof row === 'object' && !Array.isArray(row))
    .map(row => ({...row}));
  history.push({
    at: stamp,
    sourceId: C.text(other.id, 300),
    title: C.text(other.title, 180),
    url: C.text(other.url, 2048),
    sharedAddresses: sharedAddresses.slice(0, 6)
  });
  survivor.repairHistory = history.slice(-8);
  state.sources = (state.sources || []).filter(row => row !== other);
  return {
    survivorId,
    survivorTitle: C.text(survivor.title, 180) || 'Source',
    removedSourceId: otherId,
    removedSourceTitle: C.text(other.title, 180) || 'Source',
    itemMerge,
    changedCollections
  };
}

function repairSourceStatus(source, permissionGranted) {
  if (source.pendingRedirect) return 'Moved';
  if (!source.enabled) return 'Paused';
  if (!permissionGranted || source.permissionMissing) return 'Reconnect';
  if (source.lastError) return 'Needs attention';
  return 'Following';
}

async function sourceRepairSourceSummary(state, source, folderRows) {
  let permissionGranted = false;
  try { permissionGranted = await hasOriginPermission(source.url); } catch {}
  const membership = folderMembership(folderRows, source.id);
  const cache = source.httpCache && typeof source.httpCache === 'object' ? source.httpCache : {};
  return {
    id: source.id,
    title: C.text(source.title, 180) || 'Untitled source',
    url: C.text(source.url, 2048),
    status: repairSourceStatus(source, permissionGranted),
    enabled: Boolean(source.enabled),
    permissionGranted,
    pendingMove: Boolean(source.pendingRedirect),
    items: sourceItemStats(state, source.id),
    folders: membership,
    activity: {
      successfulAt: isoTime(source.lastSuccessfulAt),
      newAt: isoTime(source.lastNewAt),
      problemAt: isoTime(source.lastProblemAt || (source.lastError ? source.lastScan : '')),
      problem: C.text(source.lastProblem || source.lastError, 500)
    },
    validators: {etag: Boolean(cache.etag), lastModified: Boolean(cache.lastModified)},
    nextAt: isoTime(source.pulse?.nextAt),
    aliasCount: sourceAddressAliases(source).size
  };
}

function hypotheticalRepairSummary(state, survivorId, otherId) {
  const projected = jsonClone(state);
  const result = applySourceRepair(projected, survivorId, otherId, '');
  const rows = basicFolderRows(projected);
  const membership = folderMembership(rows, survivorId);
  return {
    survivorId,
    retainedItems: result.itemMerge.afterCount,
    exactRepeatsCollapsed: result.itemMerge.exactRepeatsCollapsed,
    identities: result.itemMerge.identityCount,
    unread: result.itemMerge.unread,
    saved: result.itemMerge.saved,
    directFolders: membership.direct,
    inheritedFolders: membership.inherited,
    collectionsUpdated: result.changedCollections
  };
}

async function previewSourceRepair(payload = {}) {
  const state = await loadState();
  const pair = sourceRepairPair(state, payload.firstSourceId, payload.secondSourceId);
  const blocked = sourceRepairBlockers(state, pair.first, pair.second);
  const folderRows = basicFolderRows(state);
  const sources = await Promise.all([
    sourceRepairSourceSummary(state, pair.first, folderRows),
    sourceRepairSourceSummary(state, pair.second, folderRows)
  ]);
  const warnings = [];
  if (sources.some(source => source.pendingMove)) warnings.push('One source has an address move waiting for review. The selected survivor keeps that move; the other move is not adopted.');
  if (sources.some(source => source.status === 'Reconnect')) warnings.push('One source does not currently have site access. Combining histories does not grant or transfer permission.');
  if (sources.some(source => source.validators.etag || source.validators.lastModified)) warnings.push('Only the selected survivor keeps its cached HTTP validators. Validators from the other address are discarded.');
  if (validSourceRepairUndo(state.sourceRepairUndo, state._revision)) warnings.push('Another source repair can still be undone. Completing this repair replaces that earlier undo with the new one.');
  if (validReceiptRetirementUndo(state.receiptRetirementUndo, state._revision)) warnings.push('Combining these histories ends the separate receipt-retirement undo. The retired receipt itself remains preserved.');
  return {
    schema: 'progrss.source-repair.preview.v1',
    canRepair: blocked.blockers.length === 0,
    reviewedRevision: state._revision,
    sharedAddresses: pair.sharedAddresses,
    sources,
    outcomes: blocked.placementConflicts.length ? [] : [
      hypotheticalRepairSummary(state, pair.first.id, pair.second.id),
      hypotheticalRepairSummary(state, pair.second.id, pair.first.id)
    ],
    blockers: blocked.blockers,
    placementConflicts: blocked.placementConflicts,
    advancedReferences: blocked.advancedReferences,
    referenceReport: blocked.referenceReport,
    scanExceeded: blocked.scanExceeded,
    warnings,
    undoMinutes: Math.round(SOURCE_REPAIR_UNDO_MS / 60000)
  };
}

async function sourceRepairReferences(payload = {}) {
  const state = await loadState();
  const pair = sourceRepairPair(state, payload.firstSourceId, payload.secondSourceId);
  const report = sourceReferenceReport(state, pair.first, pair.second);
  report.sharedAddresses = pair.sharedAddresses;
  report.canRepair = report.summary.blockingRecords === 0 && !report.summary.scanExceeded;
  return report;
}

function validReceiptRetirementUndo(undo, revision, now = Date.now()) {
  return Boolean(
    undo && typeof undo === 'object' && !Array.isArray(undo) &&
    undo.schema === 'progrss.receipt.retirement.undo.v1' &&
    undo.receipt && typeof undo.receipt === 'object' && !Array.isArray(undo.receipt) &&
    undo.receipt.schema === GRAFT_RECEIPT_SCHEMA &&
    Number.isSafeInteger(undo.expectedRevision) && undo.expectedRevision === revision &&
    Number.isInteger(undo.originalIndex) && undo.originalIndex >= 0 &&
    C.text(undo.retirementId, 220) &&
    Number.isFinite(Date.parse(undo.expiresAt || '')) && Date.parse(undo.expiresAt) > now
  );
}

function receiptRetirementUndoInfo(state) {
  const undo = state.receiptRetirementUndo;
  if (!validReceiptRetirementUndo(undo, state._revision)) return {undoAvailable: false};
  return {
    undoAvailable: true,
    createdAt: C.text(undo.createdAt, 80),
    expiresAt: C.text(undo.expiresAt, 80),
    retirementId: C.text(undo.retirementId, 220),
    receiptTitle: C.text(undo.summary?.receiptTitle, 180),
    receiptId: C.text(undo.summary?.receiptId, 220)
  };
}

function graftReceiptForRetirement(state, pair, payload = {}) {
  const recordIndex = Number(payload.recordIndex);
  if (!Number.isInteger(recordIndex) || recordIndex < 0) throw codedError('Choose the exact graft receipt from the references report.', 'RECEIPT_NOT_FOUND');
  const receipt = Array.isArray(state.receipts) ? state.receipts[recordIndex] : null;
  if (!receipt || typeof receipt !== 'object' || Array.isArray(receipt)) throw codedError('That receipt is no longer in the active Workbench history.', 'RECEIPT_NOT_FOUND');
  const descriptor = advancedRecordDescriptor(receipt, 'receipts', recordIndex);
  if (payload.recordId && C.text(payload.recordId, 220) !== descriptor.recordId) throw codedError('That receipt changed while the report was open.', 'RECEIPT_REVIEW_STALE');
  if (descriptor.schema !== GRAFT_RECEIPT_SCHEMA) throw codedError('Only progrss.recipe.graft.receipt.v1 can be retired by this release.', 'RECEIPT_SCHEMA_BLOCKED');
  const {targets} = sourceRepairReferenceTargets(state, [pair.first, pair.second]);
  const budget = {nodes: 0, exceeded: false};
  const result = exactStringReferenceDetails(receipt, targets, budget);
  if (budget.exceeded) throw codedError('This receipt is too large to audit safely. It remains blocked.', 'RECEIPT_SCAN_EXCEEDED');
  if (!result.count) throw codedError('That receipt no longer refers to either reviewed history.', 'RECEIPT_NO_REFERENCE');
  return {
    receipt,
    recordIndex,
    descriptor,
    result,
    references: summarizedReferenceTargets(result.hits)
  };
}

async function previewGraftReceiptRetirement(payload = {}) {
  const state = await loadState();
  const pair = sourceRepairPair(state, payload.firstSourceId, payload.secondSourceId);
  const selected = graftReceiptForRetirement(state, pair, payload);
  const digest = await canonicalDigest(selected.receipt);
  const retiredReceipts = Array.isArray(state.retiredReceipts) ? state.retiredReceipts : [];
  if (retiredReceipts.length >= MAX_RETIRED_RECEIPTS) throw codedError('The retired receipt archive is full. Export a private backup before making more archival changes.', 'RETIRED_RECEIPTS_FULL');
  if (retiredReceipts.some(row => row?.originalDigest === digest)) throw codedError('An identical graft receipt is already preserved in retired evidence.', 'RECEIPT_ALREADY_RETIRED');
  const warnings = [];
  if (validReceiptRetirementUndo(state.receiptRetirementUndo, state._revision)) warnings.push('Another receipt retirement can still be undone. Retiring this receipt replaces that earlier undo.');
  return {
    schema: 'progrss.graft-receipt.retirement.preview.v1',
    canRetire: true,
    reviewedRevision: state._revision,
    sources: [pair.first, pair.second].map(source => ({id: C.text(source.id, 300), title: C.text(source.title, 180) || 'Untitled source', url: C.text(source.url, 2048)})),
    sharedAddresses: pair.sharedAddresses,
    receipt: {
      ...selected.descriptor,
      digest,
      referenceCount: selected.result.count,
      sourceReferenceCount: selected.result.sourceCount,
      updateReferenceCount: selected.result.updateCount,
      references: selected.references
    },
    effects: [
      'The exact receipt is removed from active Workbench receipts.',
      'An unchanged copy, its canonical SHA-256 digest, and its retirement time are preserved in the private library.',
      'No source, retained update, permission, validator, schedule, or trust binding is changed.',
      'The same-source repair is still a separate review and does not run automatically.'
    ],
    warnings,
    retiredReceiptCount: retiredReceipts.length,
    retiredReceiptLimit: MAX_RETIRED_RECEIPTS,
    undoMinutes: Math.round(RECEIPT_RETIREMENT_UNDO_MS / 60000),
    network: false,
    permissionRequest: false
  };
}

async function retireGraftReceipt(payload = {}) {
  return queueMutation(async () => {
    const state = await loadState();
    if (!Number.isSafeInteger(payload.reviewedRevision) || payload.reviewedRevision !== state._revision) {
      throw codedError('ProgRSS changed while this retirement was being reviewed. Refresh the report and review the exact receipt again.', 'RECEIPT_REVIEW_STALE');
    }
    const pair = sourceRepairPair(state, payload.firstSourceId, payload.secondSourceId);
    const selected = graftReceiptForRetirement(state, pair, payload);
    const digest = await canonicalDigest(selected.receipt);
    if (C.text(payload.expectedDigest, 64) !== digest) throw codedError('That receipt changed while the retirement was being reviewed.', 'RECEIPT_REVIEW_STALE');
    if (!Array.isArray(state.retiredReceipts)) state.retiredReceipts = [];
    if (state.retiredReceipts.length >= MAX_RETIRED_RECEIPTS) throw codedError('The retired receipt archive is full. No record was changed.', 'RETIRED_RECEIPTS_FULL');
    if (state.retiredReceipts.some(row => row?.originalDigest === digest)) throw codedError('An identical graft receipt is already preserved in retired evidence.', 'RECEIPT_ALREADY_RETIRED');
    const retiredAt = new Date();
    const retirementId = `retired-graft-${digest.slice(0, 16)}-${retiredAt.getTime().toString(36)}`;
    const receiptCopy = jsonClone(selected.receipt);
    const envelope = {
      schema: RETIRED_GRAFT_RECEIPT_SCHEMA,
      id: retirementId,
      retiredAt: retiredAt.toISOString(),
      invalidatedAt: retiredAt.toISOString(),
      reason: 'local-source-history-repair',
      originalSchema: GRAFT_RECEIPT_SCHEMA,
      originalRecordId: selected.descriptor.recordId,
      originalTitle: selected.descriptor.title,
      originalDigest: digest,
      sourcePair: [pair.first, pair.second].map(source => ({id: C.text(source.id, 300), title: C.text(source.title, 180) || 'Untitled source'})),
      sharedAddresses: pair.sharedAddresses.slice(0, 12),
      originalReceipt: receiptCopy
    };
    state.receipts.splice(selected.recordIndex, 1);
    state.retiredReceipts.push(envelope);
    state.receiptRetirementUndo = {
      schema: 'progrss.receipt.retirement.undo.v1',
      createdAt: retiredAt.toISOString(),
      expiresAt: new Date(retiredAt.getTime() + RECEIPT_RETIREMENT_UNDO_MS).toISOString(),
      expectedRevision: state._revision + 1,
      retirementId,
      originalIndex: selected.recordIndex,
      receipt: receiptCopy,
      summary: {receiptId: selected.descriptor.recordId, receiptTitle: selected.descriptor.title, digest}
    };
    await saveAndBroadcast(state, {kind: 'graft-receipt-retired', retirementId, recordId: selected.descriptor.recordId});
    return {
      retirementId,
      receiptId: selected.descriptor.recordId,
      receiptTitle: selected.descriptor.title,
      digest,
      retiredAt: envelope.retiredAt,
      undoAvailable: true,
      undoUntil: state.receiptRetirementUndo.expiresAt,
      activeReceipts: state.receipts.length,
      retiredReceipts: state.retiredReceipts.length
    };
  });
}

async function undoGraftReceiptRetirement() {
  return queueMutation(async () => {
    const state = await loadState();
    const undo = state.receiptRetirementUndo;
    if (!validReceiptRetirementUndo(undo, state._revision)) throw codedError('The receipt-retirement undo has expired or newer work has been saved.', 'RECEIPT_UNDO_STALE');
    const retiredIndex = (state.retiredReceipts || []).findIndex(row => row?.id === undo.retirementId);
    if (retiredIndex < 0) throw codedError('The retired receipt changed before undo could finish.', 'RECEIPT_UNDO_STALE');
    const envelope = state.retiredReceipts[retiredIndex];
    const digest = await canonicalDigest(undo.receipt);
    if (digest !== envelope.originalDigest) throw codedError('The preserved receipt no longer matches the reviewed evidence.', 'RECEIPT_UNDO_STALE');
    state.retiredReceipts.splice(retiredIndex, 1);
    const insertAt = Math.min(Math.max(0, undo.originalIndex), state.receipts.length);
    state.receipts.splice(insertAt, 0, jsonClone(undo.receipt));
    state.receiptRetirementUndo = null;
    await saveAndBroadcast(state, {kind: 'graft-receipt-retirement-undone', receiptId: undo.summary?.receiptId || ''});
    return {restored: true, receiptId: C.text(undo.summary?.receiptId, 220), receiptTitle: C.text(undo.summary?.receiptTitle, 180)};
  });
}

async function clearExpiredReceiptRetirementUndo() {
  return queueMutation(async () => {
    const state = await loadState();
    if (!state.receiptRetirementUndo || validReceiptRetirementUndo(state.receiptRetirementUndo, state._revision)) return false;
    state.receiptRetirementUndo = null;
    await saveAndBroadcast(state, {kind: 'graft-receipt-retirement-undo-expired'});
    return true;
  });
}

function validSourceRepairUndo(undo, revision, now = Date.now()) {
  return Boolean(
    undo && typeof undo === 'object' && !Array.isArray(undo) &&
    undo.schema === 'progrss.source.repair.undo.v1' &&
    undo.previousState && typeof undo.previousState === 'object' && !Array.isArray(undo.previousState) &&
    Number.isSafeInteger(undo.expectedRevision) && undo.expectedRevision === revision &&
    Number.isFinite(Date.parse(undo.expiresAt || '')) && Date.parse(undo.expiresAt) > now
  );
}

function sourceRepairUndoInfo(state) {
  const undo = state.sourceRepairUndo;
  if (!validSourceRepairUndo(undo, state._revision)) return {undoAvailable: false};
  return {
    undoAvailable: true,
    createdAt: C.text(undo.createdAt, 80),
    expiresAt: C.text(undo.expiresAt, 80),
    survivorId: C.text(undo.summary?.survivorId, 300),
    survivorTitle: C.text(undo.summary?.survivorTitle, 180),
    otherTitle: C.text(undo.summary?.removedSourceTitle, 180)
  };
}

async function repairSameSource(payload = {}) {
  return queueMutation(async () => {
    const state = await loadState();
    if (!Number.isSafeInteger(payload.reviewedRevision) || payload.reviewedRevision !== state._revision) {
      throw codedError('ProgRSS changed while this repair was being reviewed. Review the updated histories before combining them.', 'SOURCE_REPAIR_STALE');
    }
    const pair = sourceRepairPair(state, payload.firstSourceId, payload.secondSourceId);
    const blocked = sourceRepairBlockers(state, pair.first, pair.second);
    if (blocked.placementConflicts.length) {
      throw codedError(sourceRepairReasonConflictMessage(blocked.placementConflicts), 'SOURCE_REPAIR_REASON_CONFLICT', {placementConflicts: blocked.placementConflicts});
    }
    if (blocked.blockers.length) throw codedError(blocked.blockers[0], 'SOURCE_REPAIR_BLOCKED', {blockers: blocked.blockers});
    const survivorId = C.text(payload.survivorId, 300);
    if (![pair.first.id, pair.second.id].includes(survivorId)) throw codedError('Choose which reviewed source should remain.', 'SOURCE_REPAIR_CHOICE');
    const otherId = survivorId === pair.first.id ? pair.second.id : pair.first.id;
    const survivor = survivorId === pair.first.id ? pair.first : pair.second;
    let permissionGranted = false;
    try { permissionGranted = await hasOriginPermission(survivor.url); } catch {}
    state.receiptRetirementUndo = null;
    const previousState = jsonClone(state);
    delete previousState._revision;
    delete previousState.sourceRepairUndo;
    const result = applySourceRepair(state, survivorId, otherId, new Date().toISOString());
    const currentSurvivor = (state.sources || []).find(row => row.id === survivorId);
    if (currentSurvivor?.enabled && !currentSurvivor.pendingRedirect) {
      if (permissionGranted) {
        delete currentSurvivor.permissionMissing;
        delete currentSurvivor.permissionMissingReason;
        if (currentSurvivor.lastOutcome === 'permission') {
          currentSurvivor.lastOutcome = currentSurvivor.lastSuccessfulAt ? 'ready' : '';
          currentSurvivor.lastError = '';
        }
      } else {
        currentSurvivor.permissionMissing = true;
        currentSurvivor.permissionMissingReason = 'repair';
      }
    }
    const createdAt = new Date();
    state.sourceRepairUndo = {
      schema: 'progrss.source.repair.undo.v1',
      createdAt: createdAt.toISOString(),
      expiresAt: new Date(createdAt.getTime() + SOURCE_REPAIR_UNDO_MS).toISOString(),
      expectedRevision: state._revision + 1,
      previousState,
      summary: result
    };
    await saveAndBroadcast(state, {kind: 'same-source-repair', survivorId, otherId});
    return {
      ...result,
      permissionGranted,
      undoAvailable: true,
      undoUntil: state.sourceRepairUndo.expiresAt
    };
  });
}

async function undoSourceRepair() {
  return queueMutation(async () => {
    const current = await loadState();
    const undo = current.sourceRepairUndo;
    if (!undo || !Number.isFinite(Date.parse(undo.expiresAt || '')) || Date.parse(undo.expiresAt) <= Date.now()) {
      throw codedError('The same-source repair undo has expired.', 'SOURCE_REPAIR_UNDO_EXPIRED');
    }
    if (!validSourceRepairUndo(undo, current._revision)) {
      throw codedError('ProgRSS changed after this repair. Undo was stopped so newer reading and organization would not be overwritten.', 'SOURCE_REPAIR_UNDO_STALE');
    }
    const previous = V.normalize(undo.previousState);
    previous._revision = current._revision;
    previous.sourceRepairUndo = null;
    await applyDestinationPermissions(previous);
    await saveAndBroadcast(previous, {kind: 'same-source-repair-undo'});
    return {restoredSources: 2};
  });
}

async function clearExpiredSourceRepairUndo() {
  return queueMutation(async () => {
    const state = await loadState();
    if (!state.sourceRepairUndo || validSourceRepairUndo(state.sourceRepairUndo, state._revision)) return false;
    state.sourceRepairUndo = null;
    await saveAndBroadcast(state, {kind: 'same-source-repair-undo-expired'});
    return true;
  });
}

async function mutateSimple(kind, payload = {}) {
  return queueMutation(async () => {
    const state = await loadState();
    let result = {};
    if (kind === 'item') {
      const item = (state.items || []).find(row => row.id === payload.itemId);
      if (!item) throw new Error('Item not found.');
      if (payload.read !== undefined) item.readAt = payload.read ? (item.readAt || new Date().toISOString()) : '';
      if (payload.starred !== undefined) item.starred = Boolean(payload.starred);
      result = {item};
    } else if (kind === 'mark-all') {
      const changed = [];
      const stamp = new Date().toISOString();
      for (const item of state.items || []) {
        if (!item.readAt && (!payload.sourceId || item.sourceId === payload.sourceId)) {
          item.readAt = stamp;
          changed.push(item.id);
        }
      }
      result = {changed, stamp};
    } else if (kind === 'read-items') {
      const ids = new Set(Array.isArray(payload.ids) ? payload.ids.slice(0, C.LIMIT.items) : []);
      const changed = [];
      const stamp = new Date().toISOString();
      for (const item of state.items || []) {
        if (ids.has(item.id) && !item.readAt) { item.readAt = stamp; changed.push(item.id); }
      }
      result = {changed, stamp};
    } else if (kind === 'unread-items') {
      const ids = new Set(Array.isArray(payload.ids) ? payload.ids.slice(0, C.LIMIT.items) : []);
      for (const item of state.items || []) if (ids.has(item.id)) item.readAt = '';
      result = {changed: ids.size};
    } else if (kind === 'source-toggle') {
      const source = (state.sources || []).find(row => row.id === payload.sourceId);
      if (!source) throw new Error('Source not found.');
      const enabling = Boolean(payload.enabled);
      if (enabling && !(await hasOriginPermission(source.url))) {
        throw codedError('Site access is needed before this source can resume.', 'PERMISSION_REQUIRED');
      }
      source.enabled = enabling;
      if (enabling && source.permissionMissing) {
        delete source.permissionMissing;
        delete source.permissionMissingReason;
        if (source.lastOutcome === 'permission') {
          source.lastError = '';
          source.lastOutcome = 'ready';
        }
      }
      result = {source};
    } else if (kind === 'source-archive') {
      const source = (state.sources || []).find(row => row.id === payload.sourceId);
      if (!source) throw new Error('Source not found.');
      source.enabled = false;
      source.archivedAt = new Date().toISOString();
      result = {source};
    } else if (kind === 'source-rename') {
      const source = (state.sources || []).find(row => row.id === payload.sourceId);
      if (!source) throw new Error('Source not found.');
      source.title = C.text(payload.title, 130) || source.title;
      result = {source};
    } else {
      throw new Error('Unknown state change.');
    }
    await saveAndBroadcast(state, {kind});
    return result;
  });
}

function removedOriginPatterns(removed) {
  return Array.isArray(removed?.origins) ? removed.origins.filter(value => typeof value === 'string').slice(0, 200) : [];
}

function handlePermissionRemoval(removed) {
  const patterns = removedOriginPatterns(removed);
  if (!patterns.length) return;
  for (const acquisition of activeAcquisitions) {
    if (patterns.some(pattern => permissionPatternCoversOrigin(pattern, acquisition.origin))) {
      acquisition.reason = 'permission-removed';
      acquisition.controller.abort();
    }
  }
  queueMutation(async () => {
    const state = await loadState();
    const stamp = new Date().toISOString();
    let changed = false;
    for (const source of state.sources || []) {
      if (!source?.enabled || source.archivedAt) continue;
      let origin;
      try { origin = new URL(C.safeUrl(source.url)).origin; } catch { continue; }
      if (!patterns.some(pattern => permissionPatternCoversOrigin(pattern, origin))) continue;
      if (source.permissionMissing && source.lastOutcome === 'permission') continue;
      source.permissionMissing = true;
      source.permissionMissingReason = 'removed';
      durableProblem(source, 'Site access was removed. Reconnect this source before checking it again.', 'permission', stamp);
      source.pulse = P.advance(source.pulse, 'error', Date.parse(stamp));
      changed = true;
    }
    if (changed) await saveAndBroadcast(state, {kind: 'permissions-removed', origins: patterns.length});
  }).catch(() => {});
}

api.permissions.onRemoved?.addListener(handlePermissionRemoval);

async function configureReaderSurface() {
  if (api.sidePanel?.setPanelBehavior) {
    try { await api.sidePanel.setPanelBehavior({openPanelOnActionClick: true}); } catch {}
  }
}

if (api.action?.onClicked && api.sidebarAction?.open) {
  api.action.onClicked.addListener(() => {
    // Firefox requires sidebarAction.open() to remain inside a user-action handler.
    Promise.resolve(api.sidebarAction.open()).catch(() => {});
  });
}

api.runtime.onInstalled.addListener(async details => {
  await configureReaderSurface();
  await noteExtensionLifecycle(details || {});
  await api.alarms.create('progrss-refresh', {periodInMinutes: 15});
  try { await updateBadge(await loadState()); } catch {}
});

api.runtime.onStartup.addListener(async () => {
  await configureReaderSurface();
  try { await updateBadge(await loadState()); } catch {}
});

api.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'progrss-refresh') {
    clearExpiredTransferUndo().catch(() => {});
    clearExpiredSourceRepairUndo().catch(() => {});
    clearExpiredReceiptRetirementUndo().catch(() => {});
    clearExpiredSharedFolderUpdateUndo().catch(() => {});
    clearExpiredPageWatchRepairUndo().catch(() => {});
    refreshMany({dueOnly: true, silent: true}).catch(() => {});
  }
});

api.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.target !== 'background') return false;
  (async () => {
    switch (message.type) {
      case 'get-state': return {ok: true, result: await publicState(await loadState())};
      case 'fetch-resource': return {ok: true, result: await fetchResource(message.data.url, message.data.validators || {})};
      case 'inspect-url': return {ok: true, result: await inspectUrl(message.data.url)};
      case 'preview-feed-text': return {ok: true, result: await previewFeedText(message.data.raw, message.data.url, message.data.contentType)};
      case 'export-private-backup': return {ok: true, result: await exportPrivateBackup({recovery: Boolean(message.data?.recovery)})};
      case 'check-private-backup': return {ok: true, result: await checkPrivateBackup(message.data.raw)};
      case 'snooze-backup-reminder': return {ok: true, result: await setBackupReminderChoice('snooze')};
      case 'disable-backup-reminder': return {ok: true, result: await setBackupReminderChoice('disable')};
      case 'enable-backup-reminder': return {ok: true, result: await setBackupReminderChoice('enable')};
      case 'mark-backup-copy-missing': return {ok: true, result: await markBackupCopyMissing()};
      case 'probe-vault-write': return {ok: true, result: await probeVaultWrite()};
      case 'accept-empty-library': return {ok: true, result: await acceptEmptyLibrary()};
      case 'assert-workbench-writable': return {ok: true, result: await assertWorkbenchWritable()};
      case 'note-workbench-commit': return {ok: true, result: await noteWorkbenchCommit()};
      case 'report-storage-write-failure': return {ok: true, result: await reportStorageWriteFailure(message.data)};
      case 'clear-storage-incident': await clearStorageIncident(); return {ok: true, result: {cleared: true}};
      case 'preview-private-backup': return {ok: true, result: await previewPrivateBackup(message.data.raw)};
      case 'restore-private-backup': return {ok: true, result: await restorePrivateBackup(message.data.raw, message.data.reviewedRevision)};
      case 'undo-private-backup-restore': return {ok: true, result: await undoPrivateBackupRestore()};
      case 'preview-opml': return {ok: true, result: await previewOpml(message.data.raw)};
      case 'import-opml': return {ok: true, result: await importOpml(message.data.raw, {paused: message.data.paused !== false})};
      case 'get-sharing-identity': return {ok: true, result: await getSharingIdentity()};
      case 'create-sharing-identity': return {ok: true, result: await createSharingIdentity()};
      case 'export-shared-folder': return {ok: true, result: await sharedFolderExport(message.data.collectionId, message.data.format || 'bundle', message.data.options || {})};
      case 'export-folder-edition': return {ok: true, result: await folderEditionExport(message.data.collectionId, message.data.options || {})};
      case 'export-publication-site': return {ok: true, result: await publicationSiteExport(message.data.collectionId, message.data.options || {})};
      case 'preview-shared-folder': return {ok: true, result: await previewSharedFolder(message.data.raw, message.data.targetRootId || '', message.data.selectedFolderId || '')};
      case 'review-shared-folder-url': return {ok: true, result: await reviewSharedFolderUrl(message.data || {})};
      case 'check-shared-folder-update': return {ok: true, result: await checkSharedFolderUpdate(message.data.collectionId)};
      case 'import-shared-folder': return {ok: true, result: await importSharedFolder(message.data.raw, message.data.reviewedRevision, message.data.selectedFolderId || '')};
      case 'update-shared-folder': return {ok: true, result: await updateSharedFolder(message.data.raw, message.data)};
      case 'undo-shared-folder-update': return {ok: true, result: await undoSharedFolderUpdate()};
      case 'add-source': return {ok: true, result: await addSource(message.data)};
      case 'refresh-source': return {ok: true, result: await refreshSourceById(message.data.sourceId, {manual: true})};
      case 'preview-page-watch-repair': return {ok: true, result: await previewPageWatchRepair(message.data)};
      case 'repair-page-watch': return {ok: true, result: await repairPageWatch(message.data)};
      case 'undo-page-watch-repair': return {ok: true, result: await undoPageWatchRepair()};
      case 'accept-source-redirect': return {ok: true, result: await acceptSourceRedirect(message.data)};
      case 'refresh-all': return {ok: true, result: await refreshMany({dueOnly: false})};
      case 'refresh-sources': return {ok: true, result: await refreshSourcesById(message.data.sourceIds)};
      case 'discover-active': return {ok: true, result: await discoverActiveTab()};
      case 'capture-rendered-page': return {ok: true, result: await captureRenderedPage(message.data || {})};
      case 'set-item': return {ok: true, result: await mutateSimple('item', message.data)};
      case 'mark-all-read': return {ok: true, result: await mutateSimple('mark-all', message.data)};
      case 'mark-items-read': return {ok: true, result: await mutateSimple('read-items', message.data)};
      case 'mark-items-unread': return {ok: true, result: await mutateSimple('unread-items', message.data)};
      case 'toggle-source': return {ok: true, result: await mutateSimple('source-toggle', message.data)};
      case 'archive-source': return {ok: true, result: await mutateSimple('source-archive', message.data)};
      case 'rename-source': return {ok: true, result: await mutateSimple('source-rename', message.data)};
      case 'add-source-to-folder': return {ok: true, result: await addSourceToFolder(message.data)};
      case 'remove-source-from-folder': return {ok: true, result: await removeSourceFromFolder(message.data)};
      case 'set-source-placement-reason': return {ok: true, result: await setSourcePlacementReason(message.data)};
      case 'undo-source-placement-reason': return {ok: true, result: await undoSourcePlacementReason(message.data)};
      case 'undo-source-folder-add': return {ok: true, result: await undoSourceFolderAdd(message.data)};
      case 'undo-source-folder-remove': return {ok: true, result: await undoSourceFolderRemove(message.data)};
      case 'set-source-text-retention': return {ok: true, result: await setSourceTextRetention(message.data)};
      case 'prune-source-text': return {ok: true, result: await pruneSourceText(message.data)};
      case 'undo-source-text-prune': return {ok: true, result: await undoSourceTextPrune(message.data)};
      case 'preview-source-repair': return {ok: true, result: await previewSourceRepair(message.data)};
      case 'source-repair-references': return {ok: true, result: await sourceRepairReferences(message.data)};
      case 'preview-graft-receipt-retirement': return {ok: true, result: await previewGraftReceiptRetirement(message.data)};
      case 'retire-graft-receipt': return {ok: true, result: await retireGraftReceipt(message.data)};
      case 'undo-graft-receipt-retirement': return {ok: true, result: await undoGraftReceiptRetirement()};
      case 'repair-same-source': return {ok: true, result: await repairSameSource(message.data)};
      case 'undo-source-repair': return {ok: true, result: await undoSourceRepair()};
      case 'update-badge': await updateBadge(await loadState()); return {ok: true, result: {}};
      default: return messageError('Unknown request.', 'UNKNOWN_REQUEST');
    }
  })().then(sendResponse).catch(error => sendResponse(messageError(error, error?.code || 'FAILED')));
  return true;
});
