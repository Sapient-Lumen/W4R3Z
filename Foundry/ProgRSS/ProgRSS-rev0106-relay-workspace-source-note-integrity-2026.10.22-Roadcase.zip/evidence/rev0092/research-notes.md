# rev0092 research notes — conflict refusal and browser boundaries

Research checked online on 2026-10-21. These references informed the narrow safety rule and the remaining runtime scope; they do not substitute for ProgRSS tests or participant evidence.

## Unresolved conflicts should stop rather than silently choose

Git's current merge documentation states that a merge stops when a conflict cannot be resolved automatically, after which the operator can abort or continue following resolution. ProgRSS is not Git, but this is a useful mature-system precedent for the same narrow principle: automatic reconciliation is appropriate only when the value is unambiguous; otherwise preserve the pre-operation state and require an explicit change.

- https://git-scm.com/docs/git-merge
- https://git-scm.com/docs/git-mergetool

The ProgRSS-specific rule is stricter and placement-scoped: one-sided or identical Source Notes merge; different nonempty notes for the same direct folder placement block preview and commit. No generic merge UI, comments, profiles, or automatic winner were added.

## Atomic local mutation remains the product boundary

The Indexed Database specification describes transactions as atomic sets of data access and mutation operations. ProgRSS continues to use the existing vault mutation path and now validates the placement-reconciliation plan before item, source, or folder mutation. The managed harness additionally deep-compares state before and after a refused repair.

- https://www.w3.org/TR/IndexedDB/

This source does not prove the Extension's runtime behavior; the production-function tests and later installed-browser sessions are the relevant evidence.

## Firefox runtime and signed-install evidence remain separate

Mozilla's Extension Workshop says a temporarily installed add-on remains only until removal or Firefox restart, and distinguishes that development path from signed end-user installation. Its self-distribution guidance describes signed file installation. Therefore temporary-runtime results must not be promoted into signed-install permission-prompt or same-install restart conclusions.

- https://extensionworkshop.com/documentation/develop/temporary-installation-in-firefox/
- https://extensionworkshop.com/documentation/publish/install-self-distributed/

## Scope retained

No current-browser version string was copied into a pass. No enterprise policy was modified. No target-host browser, unfamiliar participant, or real assistive technology was available in this source-side pass.
