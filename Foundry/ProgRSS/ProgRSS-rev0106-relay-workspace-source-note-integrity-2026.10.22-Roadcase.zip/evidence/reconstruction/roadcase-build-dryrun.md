# Roadcase build report

- Revision: `rev0083-reconstructed-from-rev0080`
- Output: `ProgRSS-rev0083-reconstructed-from-rev0080-2026.10.21-Roadcase.DRYRUN.zip`
- SHA-256: `5ef4867800b735ee20b1ec2b6a71e1fc03ebe4b88de50ecfeaf2f1324279dd73`
- Bytes: 6162240
- Manifested source entries: 419
- First/second build byte comparison: PASS
- ZIP manifest byte/mode verification: PASS
- Clean extraction byte/mode verification: PASS

## Archive verifier

```text
verified Roadcase archive: /tmp/progrss-roadcase-build-1y9lcy62/first.zip
```

## Extracted-tree verifier

```text
verified extracted Roadcase: /tmp/progrss-roadcase-build-1y9lcy62/clean-extraction
```
