# Reconstruction evidence snapshot

This directory freezes pre-package audit and check outputs for the exact working tree immediately before the final deterministic Roadcase build.

Interpretation rules:

- `PASS` in the reference contract or syntax checks is limited to that named check.
- “Candidate evidence found” in the integration audit is a static search result, not proof that the shipped call site behaves correctly.
- Browser smoke is managed automation in the build environment, not an unmanaged current-browser run, Firefox ESR evidence, assistive-technology evidence, privacy review, or participant fieldwork.
- Missing dependencies were not installed. An unavailable native replay remains not established.
- Absolute build-environment paths in raw logs are diagnostic only; artifact identity comes from the Roadcase manifest and SHA-256.
- No participant evidence is included in this reconstruction snapshot.
