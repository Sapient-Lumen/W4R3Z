# Source Notes integration audit

**Classification:** Conservative static audit. Candidate evidence paths require dynamic replay; missing strings do not prove missing behavior.

Native project files scanned (contract, harness, and authority docs excluded): 303

- **relationshipField:** not-established
- **limit280:** candidate-evidence-found — `CHANGELOG-rev0083-reconstruction.md`, `Extension/background.js`, `CLI/node_server.py`, `CLI/progrss.py`, `CLI/relay.py`, `CLI/exchange.py`, `CLI/node_web/index.html`, `Extension/Firefox/background.js`
- **pythonValidation:** candidate-evidence-found — `CLI/progrss.py`
- **javascriptValidation:** candidate-evidence-found — `Extension/background.js`, `CLI/debrief.py`, `CLI/node_web/app.js`, `Extension/Firefox/background.js`, `Extension/sidepanel/app.js`, `Extension/workbench/scripts/progrss-app.js`, `Extension/Firefox/sidepanel/app.js`, `Extension/Firefox/workbench/scripts/progrss-app.js`
- **nativeCanonicalization:** candidate-evidence-found — `ROADCASE-SOURCE-NOTES-CHECKLIST.md`, `RELEASE-NOTES-rev0069-Contour.md`, `CHANGELOG-rev0083-reconstruction.md`, `RELEASE-NOTES-rev0077-Debrief.md`, `Extension/background.js`, `tools/audit-source-notes-integration.py`, `CLI/node_server.py`, `CLI/fieldbook.py`
- **integrityCoverage:** candidate-evidence-found — `ROADCASE-SOURCE-NOTES-CHECKLIST.md`, `RELEASE-NOTES-rev0069-Contour.md`, `THRESHOLD-RELEASE.json`, `CONTOUR-RELEASE.json`, `CHANGELOG-rev0083-reconstruction.md`, `RELEASE-NOTES-rev0077-Debrief.md`, `PERIMETER-RELEASE.json`, `Extension/project.json`
- **nodeAuthoring:** candidate-evidence-found — `RELEASE-NOTES-rev0072-Drift.md`, `RELEASE-NOTES-rev0078-Crossroads.md`, `RELEASE-NOTES-rev0069-Contour.md`, `THRESHOLD-RELEASE.json`, `CHANGELOG-rev0083-reconstruction.md`, `RELEASE-NOTES-rev0077-Debrief.md`, `Extension/project.json`, `Extension/background.js`
- **completeRouteDisclosure:** candidate-evidence-found — `RELEASE-NOTES-rev0078-Crossroads.md`, `CHANGELOG-rev0083-reconstruction.md`, `Extension/project.json`, `Extension/background.js`, `tools/audit-source-notes-integration.py`, `CLI/node_server.py`, `CLI/fieldbook.py`, `CLI/README.md`
- **branchDisclosure:** candidate-evidence-found — `ROADCASE-SOURCE-NOTES-CHECKLIST.md`, `RELEASE-NOTES-rev0078-Crossroads.md`, `CHANGELOG-rev0083-reconstruction.md`, `Extension/project.json`, `Extension/background.js`, `tools/audit-reconstruction.py`, `tools/audit-source-notes-integration.py`, `CLI/node_server.py`
- **opmlOmission:** candidate-evidence-found — `Extension/background.js`, `tools/audit-source-notes-integration.py`, `CLI/README.md`, `CLI/project.json`, `CLI/progrss.py`, `CLI/relay.py`, `CLI/tests/test_cli.py`, `CLI/tests/test_command_line.py`
- **threeWayComparison:** candidate-evidence-found — `CHANGELOG-rev0083-reconstruction.md`, `Extension/README.md`, `Extension/project.json`, `Extension/background.js`, `tools/audit-reconstruction.py`, `tools/audit-source-notes-integration.py`, `CLI/node_server.py`, `CLI/fieldbook.py`
- **explicitConflictChoice:** candidate-evidence-found — `ROADCASE-SOURCE-NOTES-CHECKLIST.md`, `CHANGELOG-rev0083-reconstruction.md`, `Extension/README.md`, `tools/audit-reconstruction.py`, `tools/audit-browser-siblings.py`, `tools/audit-source-notes-integration.py`, `Extension/sidepanel/app.js`, `Extension/tests/test_static.py`
- **firefoxSibling:** candidate-evidence-found — `RELEASE-NOTES-rev0080-Roadcase.md`, `ROADCASE-SOURCE-NOTES-CHECKLIST.md`, `CURRENT-STATUS.md`, `DEBRIEF-RELEASE.json`, `BEARING-RELEASE.json`, `RELEASE-NOTES-rev0073-Anchor.md`, `FIELDBOOK-RELEASE.json`, `RELEASE-NOTES-rev0074-Bearing.md`

## Browser manifest permission comparison

- `Extension/Firefox/manifest.json`: unchanged
- `Extension/manifest.json`: unchanged
