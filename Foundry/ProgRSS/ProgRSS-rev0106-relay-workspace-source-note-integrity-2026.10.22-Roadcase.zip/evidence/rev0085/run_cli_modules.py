#!/usr/bin/env python3
from __future__ import annotations
import json, os, subprocess, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

root = Path('/mnt/data/rev0085-work/CLI')
out = root.parent / 'evidence' / 'rev0085'
modules = [
    'tests.test_acquisition', 'tests.test_cadence', 'tests.test_cli',
    'tests.test_command_line', 'tests.test_debrief', 'tests.test_fieldbook',
    'tests.test_node_server', 'tests.test_node_store', 'tests.test_relay',
    'tests.test_roadcase', 'tests.test_source_notes_entrypoints',
]

def run(mod: str) -> dict:
    start = time.monotonic()
    log = out / f"cli-{mod.rsplit('.',1)[-1]}.log"
    with log.open('wb') as fh:
        try:
            cp = subprocess.run(
                ['python3','-m','unittest','-v',mod], cwd=root,
                stdout=fh, stderr=subprocess.STDOUT, timeout=1800,
                env={**os.environ, 'PYTHONUNBUFFERED':'1'},
            )
            rc = cp.returncode
            state = 'pass' if rc == 0 else 'fail'
        except subprocess.TimeoutExpired:
            rc = 124
            state = 'timeout'
            fh.write(b'\nMODULE_TIMEOUT_SECONDS=1800\n')
        except Exception as exc:
            rc = 125
            state = 'runner-error'
            fh.write((f'\nRUNNER_ERROR={exc!r}\n').encode())
    return {'module':mod,'state':state,'returncode':rc,'seconds':round(time.monotonic()-start,3),'log':log.name}

results=[]
with ThreadPoolExecutor(max_workers=3) as pool:
    futs=[pool.submit(run,m) for m in modules]
    for fut in as_completed(futs):
        result=fut.result(); results.append(result)
        (out/'cli-modules-progress.json').write_text(json.dumps(sorted(results,key=lambda r:r['module']),indent=2)+'\n')
summary={'generatedAtEpoch':time.time(),'results':sorted(results,key=lambda r:r['module'])}
summary['allPassed']=all(r['state']=='pass' for r in results)
(out/'cli-modules-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
