#!/usr/bin/env python3
"""Human-scale shared-folder commands for ProgRSS.

This module is deliberately dependency-free. It treats a workspace backup as an
opaque JSON envelope, finds the portable state inside it, and preserves that
envelope when writing a derived backup.
"""
from __future__ import annotations

import argparse
import copy
import datetime as _dt
import hashlib
import html
import io
import json
import os
import re
import sys
import tempfile
import zipfile
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable, Mapping, MutableMapping, Sequence
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlsplit, urlunsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener

try:
    from .source_notes_native import (
        SourceNoteError,
        normalize_reason,
        preserve_reason,
        validate_private_source_note_placements,
    )
except ImportError:  # Direct CLI execution from this directory.
    from source_notes_native import (
        SourceNoteError,
        normalize_reason,
        preserve_reason,
        validate_private_source_note_placements,
    )

LEGACY_BUNDLE_SCHEMA = "progrss.bundle.v1"
BUNDLE_SCHEMA = "progrss.bundle.v2"
LOCATED_BUNDLE_SCHEMA = "progrss.bundle.v3"
PUBLICATION_SCHEMA = "progrss.shared-folder.publication.v1"
INTEGRITY_SCHEMA = "progrss.shared-folder.integrity.v1"
SIGNATURE_SCHEMA = "progrss.shared-folder.signature.v1"
DISTRIBUTION_SCHEMA = "progrss.shared-folder.distribution.v1"
LEGACY_ORIGIN_SCHEMA = "progrss.shared-folder.origin.v1"
ORIGIN_SCHEMA = "progrss.shared-folder.origin.v2"
LOCATED_ORIGIN_SCHEMA = "progrss.shared-folder.origin.v3"
BASELINE_SCHEMA = "progrss.shared-folder.baseline.v1"
CONTENTS_SCHEMA = "progrss.shared-folder.contents.v2"
MERGE_REVIEW_SCHEMA = "progrss.shared-folder-merge-review.v1"
DIGEST_DOMAIN = "ProgRSS/shared-folder-content/v1"
SIGNATURE_DOMAIN = "ProgRSS/shared-folder-signature/v1"
LOCATED_DIGEST_DOMAIN = "ProgRSS/shared-folder-content/v2"
LOCATED_SIGNATURE_DOMAIN = "ProgRSS/shared-folder-signature/v2"
SIGNATURE_ALGORITHMS = {"Ed25519", "ECDSA-P256-SHA256"}
MAX_BUNDLE_BYTES = 650_000
MAX_SITE_BYTES = 2_500_000
MAX_PUBLICATION_PAGE_BYTES = 650_000
BUNDLE_MEDIA_TYPE = "application/vnd.progrss.shared-folder+json"
FOLDER_EDITION_SCHEMA = "progrss.folder-edition.v1"
JSON_FEED_VERSION = "https://jsonfeed.org/version/1.1"
FEED_MEDIA_TYPE = "application/feed+json"
EDITION_FILE = "recent-updates.json"
MAX_EDITION_BYTES = 250_000
MAX_EDITION_ITEMS = 100
MAX_SOURCES = 100
MAX_COLLECTIONS = 100
MAX_WORKSPACE_SOURCES = 200
MAX_WORKSPACE_COLLECTIONS = 200
MAX_MERGE_REVIEW_ROWS = 80
_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,100}$")

class RelayError(ValueError):
    """A concise, user-facing command error."""


def _text(value: Any, limit: int) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()[:limit]


def _safe_url(value: Any) -> str:
    raw = _text(value, 4096)
    try:
        parsed = urlsplit(raw)
    except ValueError as exc:
        raise RelayError("A source address in the file is not a valid URL.") from exc
    if parsed.scheme not in {"http", "https"} or not parsed.netloc or parsed.username or parsed.password:
        raise RelayError("Shared folders may contain only public http or https source addresses.")
    host = (parsed.hostname or "").lower()
    if not host:
        raise RelayError("A source address in the file has no host name.")
    try:
        port = parsed.port
    except ValueError as exc:
        raise RelayError("A source address in the file has an invalid port.") from exc
    netloc = host
    if port and not ((parsed.scheme == "http" and port == 80) or (parsed.scheme == "https" and port == 443)):
        netloc = f"{host}:{port}"
    return urlunsplit((parsed.scheme.lower(), netloc, parsed.path or "/", parsed.query, ""))


def _clean_id(value: Any) -> str:
    candidate = str(value or "")
    if not _ID_RE.fullmatch(candidate):
        raise RelayError("A shared-folder record has an invalid identifier.")
    return candidate


def _bounded_int(value: Any, default: int, minimum: int = 0, maximum: int = 10_000) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError, OverflowError):
        number = default
    return max(minimum, min(maximum, number))


def _clean_source(raw: Mapping[str, Any]) -> dict[str, Any]:
    """Normalize the public recipe fields used by the Extension bundle schema."""
    if not isinstance(raw, Mapping):
        raise RelayError("A shared-folder source is malformed.")
    source_type = raw.get("type")
    if source_type not in {"rss", "page"}:
        raise RelayError("A shared folder contains an unsupported source type.")
    default_threshold = 24 if source_type == "page" else 1
    return {
        "id": _clean_id(raw.get("id")),
        "title": _text(raw.get("title"), 130) or "Untitled source",
        "type": source_type,
        "url": _safe_url(raw.get("url")),
        "mode": "cards" if raw.get("mode") == "cards" else "region",
        "selector": _text(raw.get("selector"), 350),
        "titleSelector": _text(raw.get("titleSelector"), 200),
        "linkSelector": _text(raw.get("linkSelector"), 200),
        "include": _text(raw.get("include"), 280),
        "exclude": _text(raw.get("exclude"), 280),
        "threshold": _bounded_int(raw.get("threshold"), default_threshold),
        "ignoreNumbers": bool(raw.get("ignoreNumbers", False)),
        "version": _bounded_int(raw.get("version"), 1, 1, 10_000),
        "author": _text(raw.get("author"), 80) or "anonymous",
    }


def _clean_collection(raw: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, Mapping):
        raise RelayError("A shared-folder collection is malformed.")
    if "reason" in raw:
        raise RelayError("A Source Note belongs to one direct folder-to-source placement, not to a folder.")
    raw_members = raw.get("members") or []
    if not isinstance(raw_members, list) or len(raw_members) > 150:
        raise RelayError("A shared-folder collection may contain at most 150 direct entries.")
    members: list[dict[str, Any]] = []
    seen: dict[tuple[str, str], dict[str, Any]] = {}
    for member in raw_members:
        if not isinstance(member, Mapping) or member.get("kind") not in {"source", "collection"}:
            raise RelayError("A shared folder contains an invalid member reference.")
        pair = (str(member["kind"]), _clean_id(member.get("id")))
        if pair[0] != "source" and "reason" in member:
            raise RelayError("Only a direct source placement may carry a Source Note.")
        try:
            projected = preserve_reason(member, {"kind": pair[0], "id": pair[1]}) if pair[0] == "source" else {"kind": pair[0], "id": pair[1]}
        except SourceNoteError as exc:
            raise RelayError(str(exc)) from exc
        previous = seen.get(pair)
        if previous is not None:
            if previous != projected:
                raise RelayError("A shared folder contains conflicting Source Notes for the same direct placement.")
            continue
        seen[pair] = projected
        members.append(projected)
    return {
        "id": _clean_id(raw.get("id")),
        "title": _text(raw.get("title"), 130) or "Untitled folder",
        "mode": raw.get("mode") if raw.get("mode") in {"union", "intersection", "subtract"} else "union",
        "include": _text(raw.get("include"), 280),
        "exclude": _text(raw.get("exclude"), 280),
        "version": _bounded_int(raw.get("version"), 1, 1, 10_000),
        "author": _text(raw.get("author"), 80) or "anonymous",
        "members": members,
    }


def _validate_legacy_bundle(document: Any, *, raw_size: int | None = None) -> dict[str, Any]:
    if raw_size is not None and raw_size > MAX_BUNDLE_BYTES:
        raise RelayError("That shared folder is larger than the 650 KB safety limit.")
    if not isinstance(document, Mapping) or document.get("schema") != LEGACY_BUNDLE_SCHEMA:
        raise RelayError("That file is not a ProgRSS shared folder.")
    raw_sources = document.get("sources")
    raw_collections = document.get("collections")
    if not isinstance(raw_sources, list) or not isinstance(raw_collections, list):
        raise RelayError("That shared folder is missing its source or folder list.")
    if len(raw_sources) > MAX_SOURCES or len(raw_collections) > MAX_COLLECTIONS:
        raise RelayError("A shared folder can contain at most 100 sources and 100 folders.")
    sources = [_clean_source(row) for row in raw_sources]
    collections = [_clean_collection(row) for row in raw_collections]
    ids: set[str] = set()
    for row in [*sources, *collections]:
        if row["id"] in ids:
            raise RelayError("A shared folder contains a duplicate identifier.")
        ids.add(row["id"])
    source_ids = {row["id"] for row in sources}
    collection_ids = {row["id"] for row in collections}
    for collection in collections:
        for member in collection["members"]:
            expected = source_ids if member["kind"] == "source" else collection_ids
            if member["id"] not in expected:
                raise RelayError("A shared folder contains an unresolved reference.")
    by_collection = {row["id"]: row for row in collections}
    visiting: set[str] = set()
    visited: set[str] = set()
    def visit(collection_id: str) -> None:
        if collection_id in visiting:
            raise RelayError("A shared folder contains a folder cycle.")
        if collection_id in visited:
            return
        visiting.add(collection_id)
        for member in by_collection[collection_id]["members"]:
            if member["kind"] == "collection":
                visit(member["id"])
        visiting.remove(collection_id)
        visited.add(collection_id)
    for collection_id in by_collection:
        visit(collection_id)
    root = str(document.get("root") or "")
    if root and root not in collection_ids:
        raise RelayError("The shared folder names a top-level folder that is not included.")
    result: dict[str, Any] = {
        "schema": LEGACY_BUNDLE_SCHEMA,
        "exportedAt": _text(document.get("exportedAt"), 60),
        "sources": sources,
        "collections": collections,
    }
    if root:
        result["root"] = root
    title = _text(document.get("title"), 180)
    if title:
        result["title"] = title
    return result



def _plain(value: Any) -> bool:
    return isinstance(value, Mapping)


def _exact_keys(value: Any, required: Sequence[str], optional: Sequence[str] = ()) -> bool:
    if not isinstance(value, Mapping):
        return False
    keys = set(value)
    return set(required).issubset(keys) and keys.issubset(set(required) | set(optional))


def _canonical_string(value: str) -> str:
    if any(0xD800 <= ord(character) <= 0xDFFF for character in value):
        raise RelayError("Shared-folder text contains invalid Unicode.")
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def canonical_json(value: Any) -> str:
    """Canonicalize the safe JSON subset shared with the Extension.

    Object keys are ordered by UTF-16 code units so Python and JavaScript emit
    byte-identical data. Only JSON scalar values and portable safe integers are
    accepted; arrays retain order.
    """
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int):
        if abs(value) > 9_007_199_254_740_991:
            raise RelayError("Shared folders use only portable safe-integer numbers.")
        return str(value)
    if isinstance(value, float):
        if not value.is_integer() or abs(value) > 9_007_199_254_740_991:
            raise RelayError("Shared folders use only portable safe-integer numbers.")
        return str(int(value))
    if isinstance(value, str):
        return _canonical_string(value)
    if isinstance(value, list):
        return "[" + ",".join(canonical_json(row) for row in value) + "]"
    if isinstance(value, Mapping):
        if not all(isinstance(key, str) for key in value):
            raise RelayError("Shared-folder object keys must be strings.")
        # Reject lone surrogates before Python's UTF-16 encoder sees them so
        # malformed JSON produces the same bounded user-facing error as a
        # malformed value rather than leaking a UnicodeEncodeError traceback.
        for key in value:
            _canonical_string(key)
        keys = sorted(value, key=lambda key: key.encode("utf-16-be"))
        return "{" + ",".join(
            f"{_canonical_string(key)}:{canonical_json(value[key])}" for key in keys
        ) + "}"
    raise RelayError("Shared-folder data contains a value that is not portable JSON.")


def _sha256_hex(value: Any) -> str:
    payload = value if isinstance(value, (bytes, bytearray)) else canonical_json(value).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _base64url_encode(value: bytes) -> str:
    import base64
    return base64.urlsafe_b64encode(value).decode("ascii").rstrip("=")


def _base64url_decode(value: Any, expected_length: int) -> bytes:
    import base64
    raw = str(value or "")
    if not re.fullmatch(r"[A-Za-z0-9_-]+", raw) or len(raw) > 180:
        raise RelayError("The shared-folder signing key or signature is malformed.")
    try:
        decoded = base64.urlsafe_b64decode(raw + "=" * ((4 - len(raw) % 4) % 4))
    except (ValueError, TypeError) as exc:
        raise RelayError("The shared-folder signing key or signature is malformed.") from exc
    if len(decoded) != expected_length or _base64url_encode(decoded) != raw:
        raise RelayError("The shared-folder signing key or signature has the wrong length.")
    return decoded


def _clean_iso_time(value: Any, label: str) -> str:
    raw = _text(value, 60)
    try:
        parsed = _dt.datetime.fromisoformat(raw.replace("Z", "+00:00"))
        normalized = parsed.astimezone(_dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    except (ValueError, OverflowError) as exc:
        raise RelayError(f"{label} must be an exact ISO timestamp.") from exc
    if normalized != raw:
        raise RelayError(f"{label} must be an exact ISO timestamp.")
    return raw


def _public_key_size(algorithm: str) -> int:
    return 32 if algorithm == "Ed25519" else 65


def _key_id(algorithm: str, public_key: str) -> str:
    if algorithm not in SIGNATURE_ALGORITHMS:
        raise RelayError("The shared folder uses an unsupported signing algorithm.")
    raw = _base64url_decode(public_key, _public_key_size(algorithm))
    if algorithm == "ECDSA-P256-SHA256" and raw[0] != 4:
        raise RelayError("The shared folder contains a malformed P-256 public key.")
    return f"{algorithm.lower()}:{hashlib.sha256(raw).hexdigest()}"


def _bundle_semantic_payload(document: Mapping[str, Any]) -> dict[str, Any]:
    publication = document["publication"]
    located = document.get("schema") == LOCATED_BUNDLE_SCHEMA
    return {
        "domain": LOCATED_DIGEST_DOMAIN if located else DIGEST_DOMAIN,
        "schema": LOCATED_BUNDLE_SCHEMA if located else BUNDLE_SCHEMA,
        "root": document["root"],
        "title": document["title"],
        "publication": {
            "schema": PUBLICATION_SCHEMA,
            "id": publication["id"],
            "curator": publication["curator"],
            "note": publication["note"],
        },
        **({"distribution": dict(document["distribution"])} if located else {}),
        "sources": document["sources"],
        "collections": document["collections"],
    }


def bundle_content_digest(document: Mapping[str, Any]) -> str:
    return "sha256:" + _sha256_hex(_bundle_semantic_payload(document))


def _unsigned_bundle_document(document: Mapping[str, Any]) -> dict[str, Any]:
    located = document.get("schema") == LOCATED_BUNDLE_SCHEMA
    return {
        "schema": LOCATED_BUNDLE_SCHEMA if located else BUNDLE_SCHEMA,
        "exportedAt": document["exportedAt"],
        "root": document["root"],
        "title": document["title"],
        "publication": dict(document["publication"]),
        **({"distribution": dict(document["distribution"])} if located else {}),
        "integrity": {"schema": INTEGRITY_SCHEMA, "digest": document["integrity"]["digest"]},
        "sources": document["sources"],
        "collections": document["collections"],
    }


def _signature_message(document: Mapping[str, Any]) -> bytes:
    domain = LOCATED_SIGNATURE_DOMAIN if document.get("schema") == LOCATED_BUNDLE_SCHEMA else SIGNATURE_DOMAIN
    return canonical_json({"domain": domain, "document": _unsigned_bundle_document(document)}).encode("utf-8")


# Minimal, strict standard-library verification for the two algorithms emitted
# by the Extension. These routines verify only; the CLI never creates or stores
# a private signing key.
_ED_P = 2**255 - 19
_ED_L = 2**252 + 27742317777372353535851937790883648493
_ED_D = (-121665 * pow(121666, _ED_P - 2, _ED_P)) % _ED_P
_ED_I = pow(2, (_ED_P - 1) // 4, _ED_P)
_ED_ID = (0, 1)


def _ed_xrecover(y: int) -> int:
    xx = (y * y - 1) * pow(_ED_D * y * y + 1, _ED_P - 2, _ED_P) % _ED_P
    x = pow(xx, (_ED_P + 3) // 8, _ED_P)
    if (x * x - xx) % _ED_P:
        x = x * _ED_I % _ED_P
    if (x * x - xx) % _ED_P:
        raise RelayError("The shared folder contains an invalid Ed25519 point.")
    return x


def _ed_decode(data: bytes) -> tuple[int, int]:
    if len(data) != 32:
        raise RelayError("The shared folder contains an invalid Ed25519 point.")
    value = int.from_bytes(data, "little")
    sign = value >> 255
    y = value & ((1 << 255) - 1)
    if y >= _ED_P:
        raise RelayError("The shared folder contains a noncanonical Ed25519 point.")
    x = _ed_xrecover(y)
    # RFC 8032 point decoding rejects the otherwise ambiguous encoding with
    # x = 0 and the sign bit set. Accepting it would create a second byte
    # representation for the same point.
    if x == 0 and sign:
        raise RelayError("The shared folder contains a noncanonical Ed25519 point.")
    if (x & 1) != sign:
        x = _ED_P - x
    if (-x * x + y * y - 1 - _ED_D * x * x * y * y) % _ED_P:
        raise RelayError("The shared folder contains an invalid Ed25519 point.")
    return x, y


def _ed_add(first: tuple[int, int], second: tuple[int, int]) -> tuple[int, int]:
    x1, y1 = first
    x2, y2 = second
    product = _ED_D * x1 * x2 * y1 * y2 % _ED_P
    x3 = (x1 * y2 + y1 * x2) * pow(1 + product, _ED_P - 2, _ED_P) % _ED_P
    y3 = (y1 * y2 + x1 * x2) * pow(1 - product, _ED_P - 2, _ED_P) % _ED_P
    return x3, y3


def _ed_mul(point: tuple[int, int], scalar: int) -> tuple[int, int]:
    result = _ED_ID
    addend = point
    while scalar:
        if scalar & 1:
            result = _ed_add(result, addend)
        addend = _ed_add(addend, addend)
        scalar >>= 1
    return result


_ED_BY = 4 * pow(5, _ED_P - 2, _ED_P) % _ED_P
_ED_BX = _ed_xrecover(_ED_BY)
if _ED_BX & 1:
    _ED_BX = _ED_P - _ED_BX
_ED_B = (_ED_BX, _ED_BY)


def _verify_ed25519(public_key: bytes, signature: bytes, message: bytes) -> bool:
    if len(signature) != 64:
        return False
    r_bytes, s_bytes = signature[:32], signature[32:]
    scalar = int.from_bytes(s_bytes, "little")
    if scalar >= _ED_L:
        return False
    try:
        public = _ed_decode(public_key)
        r_point = _ed_decode(r_bytes)
    except RelayError:
        return False
    # Require both points in the prime-order subgroup and reject the identity.
    if public == _ED_ID or _ed_mul(public, _ED_L) != _ED_ID:
        return False
    if _ed_mul(r_point, _ED_L) != _ED_ID:
        return False
    challenge = int.from_bytes(hashlib.sha512(r_bytes + public_key + message).digest(), "little") % _ED_L
    return _ed_mul(_ED_B, scalar) == _ed_add(r_point, _ed_mul(public, challenge))


_P256_P = 0xFFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF
_P256_A = (_P256_P - 3) % _P256_P
_P256_B = 0x5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B
_P256_N = 0xFFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551
_P256_G = (
    0x6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296,
    0x4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5,
)


def _p256_add(first: tuple[int, int] | None, second: tuple[int, int] | None) -> tuple[int, int] | None:
    if first is None:
        return second
    if second is None:
        return first
    x1, y1 = first
    x2, y2 = second
    if x1 == x2 and (y1 + y2) % _P256_P == 0:
        return None
    if first == second:
        if y1 == 0:
            return None
        slope = (3 * x1 * x1 + _P256_A) * pow(2 * y1, _P256_P - 2, _P256_P) % _P256_P
    else:
        slope = (y2 - y1) * pow((x2 - x1) % _P256_P, _P256_P - 2, _P256_P) % _P256_P
    x3 = (slope * slope - x1 - x2) % _P256_P
    y3 = (slope * (x1 - x3) - y1) % _P256_P
    return x3, y3


def _p256_mul(point: tuple[int, int] | None, scalar: int) -> tuple[int, int] | None:
    result = None
    addend = point
    while scalar:
        if scalar & 1:
            result = _p256_add(result, addend)
        addend = _p256_add(addend, addend)
        scalar >>= 1
    return result


def _p256_decode(public_key: bytes) -> tuple[int, int]:
    if len(public_key) != 65 or public_key[0] != 4:
        raise RelayError("The shared folder contains a malformed P-256 public key.")
    x = int.from_bytes(public_key[1:33], "big")
    y = int.from_bytes(public_key[33:], "big")
    if x >= _P256_P or y >= _P256_P or (y * y - (x * x * x + _P256_A * x + _P256_B)) % _P256_P:
        raise RelayError("The shared folder contains an invalid P-256 public key.")
    point = (x, y)
    if _p256_mul(point, _P256_N) is not None:
        raise RelayError("The shared folder contains an invalid P-256 public key.")
    return point


def _verify_p256(public_key: bytes, signature: bytes, message: bytes) -> bool:
    if len(signature) != 64:
        return False
    r = int.from_bytes(signature[:32], "big")
    s = int.from_bytes(signature[32:], "big")
    if not (1 <= r < _P256_N and 1 <= s < _P256_N):
        return False
    try:
        point = _p256_decode(public_key)
    except RelayError:
        return False
    digest = int.from_bytes(hashlib.sha256(message).digest(), "big")
    inverse = pow(s, -1, _P256_N)
    result = _p256_add(
        _p256_mul(_P256_G, digest * inverse % _P256_N),
        _p256_mul(point, r * inverse % _P256_N),
    )
    return result is not None and result[0] % _P256_N == r


def verify_bundle_signature(document: Mapping[str, Any]) -> bool:
    signature = document.get("integrity", {}).get("signature")
    if not isinstance(signature, Mapping):
        return False
    algorithm = str(signature["algorithm"])
    public_key = _base64url_decode(signature["publicKey"], _public_key_size(algorithm))
    signed = _base64url_decode(signature["value"], 64)
    message = _signature_message(document)
    if algorithm == "Ed25519":
        return _verify_ed25519(public_key, signed, message)
    if algorithm == "ECDSA-P256-SHA256":
        return _verify_p256(public_key, signed, message)
    return False


def _validate_signature(raw: Any) -> dict[str, str]:
    if not _exact_keys(raw, ("schema", "algorithm", "publicKey", "keyId", "value")) or raw.get("schema") != SIGNATURE_SCHEMA:
        raise RelayError("The shared folder has invalid signature metadata.")
    algorithm = str(raw.get("algorithm") or "")
    if algorithm not in SIGNATURE_ALGORITHMS:
        raise RelayError("The shared folder uses an unsupported signing algorithm.")
    public_key = str(raw.get("publicKey") or "")
    value = str(raw.get("value") or "")
    _base64url_decode(public_key, _public_key_size(algorithm))
    _base64url_decode(value, 64)
    fingerprint = str(raw.get("keyId") or "")
    if not re.fullmatch(re.escape(algorithm.lower()) + r":[a-f0-9]{64}", fingerprint):
        raise RelayError("The shared-folder signer fingerprint is malformed.")
    if _key_id(algorithm, public_key) != fingerprint:
        raise RelayError("The shared-folder signer fingerprint does not match its public key.")
    return {
        "schema": SIGNATURE_SCHEMA,
        "algorithm": algorithm,
        "publicKey": public_key,
        "keyId": fingerprint,
        "value": value,
    }


def _clean_distribution(raw: Any) -> dict[str, str]:
    if not _exact_keys(raw, ("schema", "updateUrl")) or raw.get("schema") != DISTRIBUTION_SCHEMA:
        raise RelayError("The shared folder has invalid future-copy metadata.")
    update_url = _safe_url(raw.get("updateUrl"))
    normalized = {"schema": DISTRIBUTION_SCHEMA, "updateUrl": update_url}
    if canonical_json(normalized) != canonical_json(raw):
        raise RelayError("The shared-folder future-copy metadata is not canonical.")
    return normalized


def _validate_attributed_bundle(
    document: Mapping[str, Any], schema: str, *, raw_size: int | None = None,
) -> dict[str, Any]:
    if raw_size is not None and raw_size > MAX_BUNDLE_BYTES:
        raise RelayError("That shared folder is larger than the 650 KB safety limit.")
    located = schema == LOCATED_BUNDLE_SCHEMA
    required = ["schema", "exportedAt", "root", "title", "publication", "integrity", "sources", "collections"]
    if located:
        required.insert(5, "distribution")
    if not _exact_keys(document, required) or document.get("schema") != schema:
        label = "located" if located else "attributed"
        raise RelayError(f"That file is not a supported {label} ProgRSS shared folder.")
    base = _validate_legacy_bundle({
        "schema": LEGACY_BUNDLE_SCHEMA,
        "exportedAt": document.get("exportedAt"),
        "root": document.get("root"),
        "title": document.get("title"),
        "sources": document.get("sources"),
        "collections": document.get("collections"),
    })
    if not base.get("root"):
        raise RelayError("The shared folder does not identify one top-level folder.")
    base["title"] = _text(document.get("title"), 130)
    expected_base = {
        "exportedAt": _text(document.get("exportedAt"), 60),
        "root": base["root"],
        "title": base.get("title", ""),
        "sources": base["sources"],
        "collections": base["collections"],
    }
    actual_base = {key: document.get(key) for key in expected_base}
    if canonical_json(expected_base) != canonical_json(actual_base):
        raise RelayError("The shared folder contains unexpected or noncanonical recipe fields.")
    exported_at = _clean_iso_time(document.get("exportedAt"), "The shared-folder export time")
    publication = document.get("publication")
    if not _exact_keys(publication, ("schema", "id", "curator", "note", "issuedAt")) or publication.get("schema") != PUBLICATION_SCHEMA:
        raise RelayError("The shared folder has invalid attribution metadata.")
    publication_id = str(publication.get("id") or "")
    if not _ID_RE.fullmatch(publication_id):
        raise RelayError("The shared folder has an invalid publication identity.")
    normalized_publication = {
        "schema": PUBLICATION_SCHEMA,
        "id": publication_id,
        "curator": _text(publication.get("curator"), 80),
        "note": _text(publication.get("note"), 280),
        "issuedAt": _clean_iso_time(publication.get("issuedAt"), "The shared-folder issue time"),
    }
    if normalized_publication["issuedAt"] != exported_at or canonical_json(normalized_publication) != canonical_json(publication):
        raise RelayError("The shared-folder attribution metadata is not canonical.")
    distribution = _clean_distribution(document.get("distribution")) if located else None
    integrity = document.get("integrity")
    if not _exact_keys(integrity, ("schema", "digest"), ("signature",)) or integrity.get("schema") != INTEGRITY_SCHEMA:
        raise RelayError("The shared folder has invalid integrity metadata.")
    digest = str(integrity.get("digest") or "")
    if not re.fullmatch(r"sha256:[a-f0-9]{64}", digest):
        raise RelayError("The shared-folder content digest is malformed.")
    signature = _validate_signature(integrity["signature"]) if "signature" in integrity else None
    normalized = {
        "schema": schema,
        "exportedAt": exported_at,
        "root": base["root"],
        "title": base.get("title", ""),
        "publication": normalized_publication,
        **({"distribution": distribution} if located else {}),
        "integrity": {"schema": INTEGRITY_SCHEMA, "digest": digest, **({"signature": signature} if signature else {})},
        "sources": base["sources"],
        "collections": base["collections"],
    }
    if bundle_content_digest(normalized) != digest:
        raise RelayError("The shared-folder content digest does not match. Nothing was changed.")
    if signature and not verify_bundle_signature(normalized):
        raise RelayError("The shared-folder signature is invalid. Nothing was changed.")
    return normalized


def _validate_v2_bundle(document: Mapping[str, Any], *, raw_size: int | None = None) -> dict[str, Any]:
    return _validate_attributed_bundle(document, BUNDLE_SCHEMA, raw_size=raw_size)


def _validate_v3_bundle(document: Mapping[str, Any], *, raw_size: int | None = None) -> dict[str, Any]:
    return _validate_attributed_bundle(document, LOCATED_BUNDLE_SCHEMA, raw_size=raw_size)

def validate_bundle(document: Any, *, raw_size: int | None = None) -> dict[str, Any]:
    if not isinstance(document, Mapping):
        raise RelayError("That file is not a ProgRSS shared folder.")
    schema = document.get("schema")
    if schema == LEGACY_BUNDLE_SCHEMA:
        return _validate_legacy_bundle(document, raw_size=raw_size)
    if schema == BUNDLE_SCHEMA:
        return _validate_v2_bundle(document, raw_size=raw_size)
    if schema == LOCATED_BUNDLE_SCHEMA:
        return _validate_v3_bundle(document, raw_size=raw_size)
    raise RelayError("That file is not a supported ProgRSS shared folder.")


def bundle_provenance(bundle: Mapping[str, Any]) -> dict[str, Any]:
    if bundle.get("schema") in {BUNDLE_SCHEMA, LOCATED_BUNDLE_SCHEMA}:
        located = bundle.get("schema") == LOCATED_BUNDLE_SCHEMA
        publication = bundle["publication"]
        signature = bundle["integrity"].get("signature")
        return {
            "schema": LOCATED_ORIGIN_SCHEMA if located else ORIGIN_SCHEMA,
            "publicationId": publication["id"],
            "curator": publication["curator"],
            "note": publication["note"],
            "issuedAt": publication["issuedAt"],
            "digest": bundle["integrity"]["digest"],
            "signatureState": "verified" if signature else "unsigned",
            **({"updateUrl": bundle["distribution"]["updateUrl"]} if located else {}),
            **({"algorithm": signature["algorithm"], "keyId": signature["keyId"]} if signature else {}),
        }
    return {
        "schema": ORIGIN_SCHEMA,
        "publicationId": str(bundle.get("root") or ""),
        "curator": "",
        "note": "",
        "issuedAt": str(bundle.get("exportedAt") or ""),
        "digest": "",
        "signatureState": "legacy",
    }


def _normalize_baseline(raw: Any, *, strict: bool = False) -> dict[str, Any] | None:
    try:
        required = ("schema", "root", "title", "sources", "collections", "sourceMap", "collectionMap")
        if not _exact_keys(raw, required) or raw.get("schema") != BASELINE_SCHEMA:
            raise RelayError("The shared-folder update baseline has unexpected fields.")
        base = _connected_bundle(_validate_legacy_bundle({
            "schema": LEGACY_BUNDLE_SCHEMA,
            "exportedAt": "",
            "root": raw.get("root"),
            "title": raw.get("title"),
            "sources": raw.get("sources"),
            "collections": raw.get("collections"),
        }))
        source_ids = {row["id"] for row in base["sources"]}
        collection_ids = {row["id"] for row in base["collections"]}
        raw_source_map = raw.get("sourceMap")
        raw_collection_map = raw.get("collectionMap")
        if not isinstance(raw_source_map, list) or len(raw_source_map) != len(source_ids):
            raise RelayError("The shared-folder update baseline has an incomplete source map.")
        if not isinstance(raw_collection_map, list) or len(raw_collection_map) != len(collection_ids):
            raise RelayError("The shared-folder update baseline has an incomplete folder map.")
        source_map: list[dict[str, Any]] = []
        source_remote: set[str] = set()
        for row in raw_source_map:
            if not _exact_keys(row, ("remoteId", "localId", "created")):
                raise RelayError("The shared-folder source map is malformed.")
            remote_id = str(row.get("remoteId") or "")
            local_id = str(row.get("localId") or "")
            if remote_id not in source_ids or remote_id in source_remote or not _ID_RE.fullmatch(local_id) or not isinstance(row.get("created"), bool):
                raise RelayError("The shared-folder source map is invalid.")
            source_remote.add(remote_id)
            source_map.append({"remoteId": remote_id, "localId": local_id, "created": bool(row["created"])})
        collection_map: list[dict[str, str]] = []
        collection_remote: set[str] = set()
        collection_local: set[str] = set()
        for row in raw_collection_map:
            if not _exact_keys(row, ("remoteId", "localId")):
                raise RelayError("The shared-folder folder map is malformed.")
            remote_id = str(row.get("remoteId") or "")
            local_id = str(row.get("localId") or "")
            if remote_id not in collection_ids or remote_id in collection_remote or local_id in collection_local or not _ID_RE.fullmatch(local_id):
                raise RelayError("The shared-folder folder map is invalid.")
            collection_remote.add(remote_id)
            collection_local.add(local_id)
            collection_map.append({"remoteId": remote_id, "localId": local_id})
        normalized = {
            "schema": BASELINE_SCHEMA,
            "root": base["root"],
            "title": base.get("title", ""),
            "sources": base["sources"],
            "collections": base["collections"],
            "sourceMap": source_map,
            "collectionMap": collection_map,
        }
        if canonical_json(normalized) != canonical_json(raw):
            raise RelayError("The shared-folder update baseline is not canonical.")
        return normalized
    except RelayError:
        if strict:
            raise
        return None


def _make_baseline(
    bundle: Mapping[str, Any], source_map: Sequence[Mapping[str, Any]], collection_map: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    base = _connected_bundle(_validate_legacy_bundle({
        "schema": LEGACY_BUNDLE_SCHEMA,
        "exportedAt": bundle.get("exportedAt", ""),
        "root": bundle.get("root"),
        "title": bundle.get("title", ""),
        "sources": bundle.get("sources"),
        "collections": bundle.get("collections"),
    }))
    normalized = _normalize_baseline({
        "schema": BASELINE_SCHEMA,
        "root": base["root"],
        "title": base.get("title", ""),
        "sources": base["sources"],
        "collections": base["collections"],
        "sourceMap": [dict(row) for row in source_map],
        "collectionMap": [dict(row) for row in collection_map],
    }, strict=True)
    assert normalized is not None
    return normalized


def _normalize_origin_v1(raw: Mapping[str, Any]) -> dict[str, Any]:
    required = ("schema", "publicationId", "curator", "note", "issuedAt", "importedAt", "digest", "signatureState")
    if not _exact_keys(raw, required, ("algorithm", "keyId")) or raw.get("schema") != LEGACY_ORIGIN_SCHEMA:
        raise RelayError("The shared-folder origin record has unexpected fields.")
    publication_id = str(raw.get("publicationId") or "")
    if not _ID_RE.fullmatch(publication_id):
        raise RelayError("The shared-folder origin has an invalid publication identity.")
    state = str(raw.get("signatureState") or "")
    if state not in {"verified", "unsigned", "legacy"}:
        raise RelayError("The shared-folder origin has an invalid signature state.")
    issued_at = _text(raw.get("issuedAt"), 60)
    if issued_at:
        issued_at = _clean_iso_time(issued_at, "The shared-folder issue time")
    normalized: dict[str, Any] = {
        "schema": LEGACY_ORIGIN_SCHEMA,
        "publicationId": publication_id,
        "curator": _text(raw.get("curator"), 80),
        "note": _text(raw.get("note"), 280),
        "issuedAt": issued_at,
        "importedAt": _clean_iso_time(raw.get("importedAt"), "The shared-folder import time"),
        "digest": str(raw.get("digest") or ""),
        "signatureState": state,
    }
    _validate_origin_integrity(raw, normalized)
    if canonical_json(normalized) != canonical_json(raw):
        raise RelayError("The shared-folder origin is not canonical.")
    return normalized


def _validate_origin_integrity(raw: Mapping[str, Any], normalized: MutableMapping[str, Any]) -> None:
    state = str(normalized["signatureState"])
    if state == "legacy":
        if normalized["digest"] or "algorithm" in raw or "keyId" in raw:
            raise RelayError("A legacy shared-folder origin cannot claim verified integrity.")
    elif not re.fullmatch(r"sha256:[a-f0-9]{64}", str(normalized["digest"])):
        raise RelayError("The shared-folder origin has an invalid content digest.")
    if state == "verified":
        algorithm = str(raw.get("algorithm") or "")
        fingerprint = str(raw.get("keyId") or "")
        if algorithm not in SIGNATURE_ALGORITHMS or not re.fullmatch(re.escape(algorithm.lower()) + r":[a-f0-9]{64}", fingerprint):
            raise RelayError("The shared-folder origin has invalid signer evidence.")
        normalized["algorithm"] = algorithm
        normalized["keyId"] = fingerprint
    elif "algorithm" in raw or "keyId" in raw:
        raise RelayError("An unsigned shared-folder origin cannot claim a verified signing key.")


def _normalize_origin_v2(raw: Mapping[str, Any]) -> dict[str, Any]:
    required = ("schema", "publicationId", "curator", "note", "issuedAt", "importedAt", "updatedAt", "digest", "signatureState", "baseline")
    if not _exact_keys(raw, required, ("algorithm", "keyId")) or raw.get("schema") != ORIGIN_SCHEMA:
        raise RelayError("The shared-folder continuity record has unexpected fields.")
    publication_id = str(raw.get("publicationId") or "")
    if not _ID_RE.fullmatch(publication_id):
        raise RelayError("The shared-folder continuity record has an invalid publication identity.")
    state = str(raw.get("signatureState") or "")
    if state not in {"verified", "unsigned", "legacy"}:
        raise RelayError("The shared-folder continuity record has an invalid signature state.")
    issued_at = _text(raw.get("issuedAt"), 60)
    if issued_at:
        issued_at = _clean_iso_time(issued_at, "The shared-folder issue time")
    baseline = _normalize_baseline(raw.get("baseline"), strict=True)
    assert baseline is not None
    normalized: dict[str, Any] = {
        "schema": ORIGIN_SCHEMA,
        "publicationId": publication_id,
        "curator": _text(raw.get("curator"), 80),
        "note": _text(raw.get("note"), 280),
        "issuedAt": issued_at,
        "importedAt": _clean_iso_time(raw.get("importedAt"), "The shared-folder first import time"),
        "updatedAt": _clean_iso_time(raw.get("updatedAt"), "The shared-folder last update time"),
        "digest": str(raw.get("digest") or ""),
        "signatureState": state,
        "baseline": baseline,
    }
    _validate_origin_integrity(raw, normalized)
    if canonical_json(normalized) != canonical_json(raw):
        raise RelayError("The shared-folder continuity record is not canonical.")
    return normalized


def _normalize_origin_v3(raw: Mapping[str, Any]) -> dict[str, Any]:
    required = ("schema", "publicationId", "curator", "note", "issuedAt", "importedAt", "updatedAt", "digest", "signatureState", "baseline", "updateUrl")
    if not _exact_keys(raw, required, ("algorithm", "keyId")) or raw.get("schema") != LOCATED_ORIGIN_SCHEMA:
        raise RelayError("The shared-folder located continuity record has unexpected fields.")
    as_v2 = dict(raw)
    as_v2["schema"] = ORIGIN_SCHEMA
    as_v2.pop("updateUrl", None)
    base = _normalize_origin_v2(as_v2)
    normalized = {**base, "schema": LOCATED_ORIGIN_SCHEMA, "updateUrl": _safe_url(raw.get("updateUrl"))}
    if canonical_json(normalized) != canonical_json(raw):
        raise RelayError("The shared-folder located continuity record is not canonical.")
    return normalized


def _normalize_origin(raw: Any, *, strict: bool = False) -> dict[str, Any] | None:
    try:
        if not isinstance(raw, Mapping):
            raise RelayError("The shared-folder origin record is missing.")
        if raw.get("schema") == LOCATED_ORIGIN_SCHEMA:
            return _normalize_origin_v3(raw)
        if raw.get("schema") == ORIGIN_SCHEMA:
            return _normalize_origin_v2(raw)
        if raw.get("schema") == LEGACY_ORIGIN_SCHEMA:
            return _normalize_origin_v1(raw)
        raise RelayError("The shared-folder origin record uses an unsupported schema.")
    except RelayError:
        if strict:
            raise
        return None


def _make_origin(
    provenance: Mapping[str, Any], applied_at: str, baseline: Mapping[str, Any], previous: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    prior = _normalize_origin(previous)
    state = str(provenance.get("signatureState") or "legacy")
    if state not in {"verified", "unsigned", "legacy"}:
        state = "legacy"
    timestamp = _clean_iso_time(applied_at, "The shared-folder update time")
    update_url = _text(provenance.get("updateUrl"), 4096)
    origin: dict[str, Any] = {
        "schema": LOCATED_ORIGIN_SCHEMA if update_url else ORIGIN_SCHEMA,
        "publicationId": _text(provenance.get("publicationId"), 100),
        "curator": _text(provenance.get("curator"), 80),
        "note": _text(provenance.get("note"), 280),
        "issuedAt": _text(provenance.get("issuedAt"), 60),
        "importedAt": str(prior.get("importedAt")) if prior else timestamp,
        "updatedAt": timestamp,
        "digest": _text(provenance.get("digest"), 80),
        "signatureState": state,
        "baseline": dict(baseline),
        **({"updateUrl": _safe_url(update_url)} if update_url else {}),
    }
    if state == "verified":
        origin["algorithm"] = _text(provenance.get("algorithm"), 40)
        origin["keyId"] = _text(provenance.get("keyId"), 100)
    normalized = _normalize_origin(origin, strict=True)
    assert normalized is not None
    return normalized

def read_bundle(path: Path) -> dict[str, Any]:
    raw = path.read_bytes()
    if len(raw) > MAX_BUNDLE_BYTES:
        raise RelayError("That shared folder is larger than the 650 KB safety limit.")
    try:
        document = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RelayError("That shared folder is not readable JSON.") from exc
    bundle = validate_bundle(document, raw_size=len(raw))
    return _connected_bundle(bundle)


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req: Any, fp: Any, code: int, msg: str, headers: Any, newurl: str) -> None:
        return None


def _url_origin(value: str) -> tuple[str, str, int]:
    parsed = urlsplit(_safe_url(value))
    default_port = 443 if parsed.scheme == "https" else 80
    return parsed.scheme, (parsed.hostname or "").lower(), parsed.port or default_port


class _PublicationLinkParser(HTMLParser):
    """Collect bounded publication metadata and static-page safety evidence."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.base_href = ""
        self.links: list[dict[str, str]] = []
        self.csp: list[str] = []
        self.unsafe: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        name = tag.lower()
        values = {str(key).lower(): str(value or "") for key, value in attrs}
        if any(key.startswith("on") and value for key, value in values.items()):
            self.unsafe.append(f"inline event handler on <{name}>")
        if name == "meta" and values.get("http-equiv", "").strip().lower() == "content-security-policy":
            if values.get("content") and len(self.csp) < 4:
                self.csp.append(values["content"][:4096])
            return
        if name in {"script", "img", "iframe", "frame", "object", "embed", "video", "audio", "source", "track", "form"}:
            if len(self.unsafe) < 32:
                self.unsafe.append(f"<{name}>")
        for key in ("href", "src", "action"):
            if values.get(key, "").strip().lower().startswith("javascript:") and len(self.unsafe) < 32:
                self.unsafe.append(f"javascript URL on <{name}>")
        if name == "base" and not self.base_href and values.get("href"):
            self.base_href = values["href"][:4096]
            return
        if name != "link":
            return
        rel = {part.lower() for part in values.get("rel", "").split()}
        media_type = values.get("type", "").split(";", 1)[0].strip().lower()
        href = values.get("href", "")
        if "stylesheet" in rel or rel.intersection({"preload", "prefetch", "modulepreload", "icon"}):
            if href and len(self.unsafe) < 32:
                self.unsafe.append(f"resource-loading <link rel={' '.join(sorted(rel))}>")
            return
        if len(self.links) >= 40 or "alternate" not in rel or media_type not in {BUNDLE_MEDIA_TYPE, FEED_MEDIA_TYPE} or not href:
            return
        self.links.append({
            "href": href[:4096],
            "title": _text(values.get("title"), 120),
            "type": media_type,
        })


def _publication_page_evidence(body: str, page_remote: Mapping[str, Any]) -> tuple[_PublicationLinkParser, list[dict[str, str]], list[dict[str, str]]]:
    parser = _PublicationLinkParser()
    try:
        parser.feed(body)
        parser.close()
    except Exception as exc:
        raise RelayError("The webpage could not be parsed safely for publication discovery.") from exc
    final_page = str(page_remote["finalUrl"])
    base = final_page
    if parser.base_href:
        try:
            proposed = _safe_url(urljoin(final_page, parser.base_href))
            if _url_origin(proposed) == _url_origin(final_page):
                base = proposed
        except RelayError:
            pass
    grouped: dict[str, list[dict[str, str]]] = {BUNDLE_MEDIA_TYPE: [], FEED_MEDIA_TYPE: []}
    seen: set[tuple[str, str]] = set()
    for link in parser.links:
        try:
            candidate = _safe_url(urljoin(base, link["href"]))
        except RelayError:
            continue
        media_type = str(link.get("type") or "")
        key = (media_type, candidate)
        if media_type not in grouped or _url_origin(candidate) != _url_origin(final_page) or key in seen:
            continue
        seen.add(key)
        grouped[media_type].append({"url": candidate, "title": link.get("title", ""), "mediaType": media_type})
    return parser, grouped[BUNDLE_MEDIA_TYPE], grouped[FEED_MEDIA_TYPE]


def _fetch_publication_page(page_url: str) -> tuple[str, dict[str, Any]]:
    """Fetch one explicitly requested HTML page with the publication redirect policy."""
    requested = _safe_url(page_url)
    current = requested
    redirects: list[dict[str, Any]] = []
    opener = build_opener(ProxyHandler({}), _NoRedirect())
    headers = {
        "Accept": "text/html, application/xhtml+xml;q=0.9, text/plain;q=0.2, */*;q=0.1",
        "User-Agent": "ProgRSS-CLI/0.58 manual-publication-discovery",
        "Cache-Control": "no-cache",
    }
    for _ in range(6):
        request = Request(current, headers=headers, method="GET")
        try:
            response = opener.open(request, timeout=20)
        except HTTPError as exc:
            if exc.code in {301, 302, 303, 307, 308}:
                location = exc.headers.get("Location", "") if exc.headers else ""
                if not location:
                    raise RelayError(f"The webpage returned HTTP {exc.code} without a destination.") from exc
                destination = _safe_url(urljoin(current, location))
                if _url_origin(destination) != _url_origin(current):
                    raise RelayError(f"The webpage moved to another site: {destination}. Nothing there was contacted; review that address separately.") from exc
                redirects.append({"from": current, "to": destination, "status": exc.code})
                if len(redirects) > 5:
                    raise RelayError("The webpage redirected too many times.") from exc
                current = destination
                continue
            raise RelayError(f"The webpage returned HTTP {exc.code}. Nothing was saved or applied.") from exc
        except URLError as exc:
            reason = _text(getattr(exc, "reason", exc), 180)
            raise RelayError(f"The webpage could not be reached: {reason}") from exc
        except TimeoutError as exc:
            raise RelayError("The webpage check exceeded the 20-second limit.") from exc
        with response:
            status = int(getattr(response, "status", response.getcode()) or 0)
            if not 200 <= status < 300 or status == 204:
                raise RelayError(f"The webpage returned HTTP {status} without a reviewable document.")
            length = response.headers.get("Content-Length", "")
            try:
                if length and int(length) > MAX_PUBLICATION_PAGE_BYTES:
                    raise RelayError("The webpage is larger than the 650 KB discovery limit.")
            except ValueError:
                pass
            raw = response.read(MAX_PUBLICATION_PAGE_BYTES + 1)
            if len(raw) > MAX_PUBLICATION_PAGE_BYTES:
                raise RelayError("The webpage is larger than the 650 KB discovery limit.")
            try:
                body = raw.decode("utf-8-sig")
            except UnicodeDecodeError as exc:
                raise RelayError("The webpage is not readable UTF-8 HTML.") from exc
            remote = {
                "requestedUrl": requested,
                "finalUrl": current,
                "status": status,
                "contentType": _text(response.headers.get("Content-Type", ""), 200),
                "redirects": redirects,
                "credentials": "omitted",
                "automatic": False,
                "networkRequests": len(redirects) + 1,
            }
            return body, remote
    raise RelayError("The webpage redirected too many times.")


def discover_publication_from_page(page_url: str) -> tuple[dict[str, Any], dict[str, Any]]:
    """Discover and verify one same-origin ProgRSS bundle advertised by an HTML page."""
    body, page_remote = _fetch_publication_page(page_url)
    _, candidates, _ = _publication_page_evidence(body, page_remote)
    if not candidates:
        raise RelayError(f"That webpage does not advertise a same-site ProgRSS shared folder using {BUNDLE_MEDIA_TYPE}.")
    if len(candidates) != 1:
        raise RelayError(f"That webpage advertises {len(candidates)} different ProgRSS shared folders. Choose a direct .json address instead of guessing.")
    bundle, bundle_remote = fetch_publication(candidates[0]["url"])
    provenance = bundle_provenance(bundle)
    result = {
        "schema": "progrss.publication-page-review.v1",
        "page": page_remote,
        "advertisement": {
            "mediaType": BUNDLE_MEDIA_TYPE,
            "title": candidates[0].get("title", ""),
            "url": candidates[0]["url"],
            "sameOrigin": True,
        },
        "bundle": bundle_remote,
        "publication": {
            "schema": bundle.get("schema", ""),
            "title": bundle.get("title", ""),
            "publicationId": provenance.get("publicationId", ""),
            "curator": provenance.get("curator", ""),
            "signatureState": provenance.get("signatureState", "unsigned"),
            "fingerprint": provenance.get("fingerprint", ""),
            "updateUrl": provenance.get("updateUrl", ""),
            "feeds": sum(1 for row in bundle["sources"] if row.get("type") == "rss"),
            "pageWatches": sum(1 for row in bundle["sources"] if row.get("type") == "page"),
            "folders": len(bundle["collections"]),
        },
        "networkRequests": int(page_remote["networkRequests"]) + int(bundle_remote["networkRequests"]),
        "automatic": False,
        "applied": False,
    }
    return bundle, result


def fetch_publication(update_url: str) -> tuple[dict[str, Any], dict[str, Any]]:
    """Fetch one explicitly requested shared-folder copy without following authority across origins."""
    requested = _safe_url(update_url)
    current = requested
    redirects: list[dict[str, Any]] = []
    opener = build_opener(ProxyHandler({}), _NoRedirect())
    headers = {
        "Accept": "application/vnd.progrss.shared-folder+json, application/json;q=0.9, text/plain;q=0.2, */*;q=0.1",
        "User-Agent": "ProgRSS-CLI/0.58 manual-publication-check",
        "Cache-Control": "no-cache",
    }
    for _ in range(6):
        request = Request(current, headers=headers, method="GET")
        try:
            response = opener.open(request, timeout=20)
        except HTTPError as exc:
            if exc.code in {301, 302, 303, 307, 308}:
                location = exc.headers.get("Location", "") if exc.headers else ""
                if not location:
                    raise RelayError(f"The publication address returned HTTP {exc.code} without a destination.") from exc
                destination = _safe_url(urljoin(current, location))
                if _url_origin(destination) != _url_origin(current):
                    raise RelayError(f"The publication moved to another site: {destination}. Nothing there was contacted; review that address separately.") from exc
                redirects.append({"from": current, "to": destination, "status": exc.code})
                if len(redirects) > 5:
                    raise RelayError("The publication address redirected too many times.") from exc
                current = destination
                continue
            raise RelayError(f"The publication address returned HTTP {exc.code}. Nothing was saved or applied.") from exc
        except URLError as exc:
            reason = _text(getattr(exc, "reason", exc), 180)
            raise RelayError(f"The publication address could not be reached: {reason}") from exc
        except TimeoutError as exc:
            raise RelayError("The publication check exceeded the 20-second limit.") from exc
        with response:
            status = int(getattr(response, "status", response.getcode()) or 0)
            if not 200 <= status < 300 or status == 204:
                raise RelayError(f"The publication address returned HTTP {status} without a reviewable document.")
            length = response.headers.get("Content-Length", "")
            try:
                if length and int(length) > MAX_BUNDLE_BYTES:
                    raise RelayError("The publication is larger than the 650 KB safety limit.")
            except ValueError:
                pass
            raw = response.read(MAX_BUNDLE_BYTES + 1)
            if len(raw) > MAX_BUNDLE_BYTES:
                raise RelayError("The publication is larger than the 650 KB safety limit.")
            try:
                document = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise RelayError("The publication address did not return readable UTF-8 JSON.") from exc
            bundle = _connected_bundle(validate_bundle(document, raw_size=len(raw)))
            remote = {
                "requestedUrl": requested,
                "finalUrl": current,
                "status": status,
                "contentType": _text(response.headers.get("Content-Type", ""), 200),
                "redirects": redirects,
                "credentials": "omitted",
                "automatic": False,
                "networkRequests": len(redirects) + 1,
            }
            return bundle, remote
    raise RelayError("The publication address redirected too many times.")


def _fetch_public_json(
    url: str,
    *,
    label: str,
    accept: str,
    byte_limit: int,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Fetch one explicit UTF-8 JSON resource with the same-origin redirect boundary."""
    requested = _safe_url(url)
    current = requested
    redirects: list[dict[str, Any]] = []
    opener = build_opener(ProxyHandler({}), _NoRedirect())
    headers = {
        "Accept": accept,
        "User-Agent": "ProgRSS-CLI/0.58 manual-publication-audit",
        "Cache-Control": "no-cache",
    }
    for _ in range(6):
        request = Request(current, headers=headers, method="GET")
        try:
            response = opener.open(request, timeout=20)
        except HTTPError as exc:
            if exc.code in {301, 302, 303, 307, 308}:
                location = exc.headers.get("Location", "") if exc.headers else ""
                if not location:
                    raise RelayError(f"The {label} returned HTTP {exc.code} without a destination.") from exc
                destination = _safe_url(urljoin(current, location))
                if _url_origin(destination) != _url_origin(current):
                    raise RelayError(f"The {label} moved to another site: {destination}. Nothing there was contacted.") from exc
                redirects.append({"from": current, "to": destination, "status": exc.code})
                if len(redirects) > 5:
                    raise RelayError(f"The {label} redirected too many times.") from exc
                current = destination
                continue
            raise RelayError(f"The {label} returned HTTP {exc.code}.") from exc
        except URLError as exc:
            reason = _text(getattr(exc, "reason", exc), 180)
            raise RelayError(f"The {label} could not be reached: {reason}") from exc
        except TimeoutError as exc:
            raise RelayError(f"The {label} check exceeded the 20-second limit.") from exc
        with response:
            status = int(getattr(response, "status", response.getcode()) or 0)
            if not 200 <= status < 300 or status == 204:
                raise RelayError(f"The {label} returned HTTP {status} without a reviewable document.")
            length = response.headers.get("Content-Length", "")
            try:
                if length and int(length) > byte_limit:
                    raise RelayError(f"The {label} is larger than its {byte_limit:,}-byte safety limit.")
            except ValueError:
                pass
            raw = response.read(byte_limit + 1)
            if len(raw) > byte_limit:
                raise RelayError(f"The {label} is larger than its {byte_limit:,}-byte safety limit.")
            try:
                document = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise RelayError(f"The {label} did not return readable UTF-8 JSON.") from exc
            if not isinstance(document, dict):
                raise RelayError(f"The {label} did not return a JSON object.")
            return document, {
                "requestedUrl": requested,
                "finalUrl": current,
                "status": status,
                "contentType": _text(response.headers.get("Content-Type", ""), 200),
                "redirects": redirects,
                "credentials": "omitted",
                "automatic": False,
                "networkRequests": len(redirects) + 1,
                "bytes": len(raw),
            }
    raise RelayError(f"The {label} redirected too many times.")


def _connected_bundle(bundle: dict[str, Any]) -> dict[str, Any]:
    if not bundle["collections"]:
        raise RelayError("That file does not contain a folder.")
    for collection in bundle["collections"]:
        if collection["mode"] != "union" or collection["include"] or collection["exclude"]:
            raise RelayError("This file contains an advanced collection. Use the Advanced Workbench for that recipe.")
    referenced = {
        member["id"]
        for collection in bundle["collections"]
        for member in collection["members"]
        if member["kind"] == "collection"
    }
    roots = [row["id"] for row in bundle["collections"] if row["id"] not in referenced]
    root = bundle.get("root") or (roots[0] if len(roots) == 1 else "")
    if not root:
        raise RelayError("This file does not identify one clear top-level folder.")
    collections = {row["id"]: row for row in bundle["collections"]}
    reached_collections: set[str] = set()
    reached_sources: set[str] = set()
    def walk(collection_id: str) -> None:
        if collection_id in reached_collections:
            return
        reached_collections.add(collection_id)
        for member in collections[collection_id]["members"]:
            if member["kind"] == "source":
                reached_sources.add(member["id"])
            else:
                walk(member["id"])
    walk(root)
    if len(reached_collections) != len(collections) or len(reached_sources) != len(bundle["sources"]):
        raise RelayError("This file contains unrelated extra records. Nothing was changed.")
    bundle["root"] = root
    bundle["title"] = bundle.get("title") or collections[root]["title"]
    return bundle


@dataclass(frozen=True)
class StateLocation:
    path: tuple[Any, ...]
    state: MutableMapping[str, Any]


def _locate_state(document: Any) -> StateLocation:
    found: list[StateLocation] = []
    def walk(value: Any, path: tuple[Any, ...], depth: int) -> None:
        if depth > 8:
            return
        if isinstance(value, MutableMapping):
            if isinstance(value.get("sources"), list) and isinstance(value.get("collections"), list):
                found.append(StateLocation(path, value))
            for key, child in value.items():
                if isinstance(child, (dict, list)):
                    walk(child, (*path, key), depth + 1)
        elif isinstance(value, list):
            for index, child in enumerate(value):
                if isinstance(child, (dict, list)):
                    walk(child, (*path, index), depth + 1)
    walk(document, (), 0)
    if not found:
        raise RelayError("That JSON file does not contain a ProgRSS workspace state.")
    found.sort(key=lambda item: (len(item.path), -len(item.state.get("sources") or [])))
    return found[0]


def read_workspace(path: Path) -> tuple[Any, StateLocation]:
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RelayError(f"Could not read workspace backup: {exc}") from exc
    location = _locate_state(document)
    try:
        validate_private_source_note_placements(location.state)
    except SourceNoteError as exc:
        raise RelayError(f"That workspace has invalid Source Notes: {exc}") from exc
    return document, location


def _replace_at_path(document: Any, path: Sequence[Any], value: Any) -> Any:
    if not path:
        return value
    cursor = document
    for part in path[:-1]:
        cursor = cursor[part]
    cursor[path[-1]] = value
    return document


def _canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _refresh_envelope_metadata(document: Any, state: Mapping[str, Any]) -> None:
    """Refresh recognizable timestamps and transparent SHA-256 metadata."""
    now = _dt.datetime.now(_dt.timezone.utc).isoformat().replace("+00:00", "Z")

    def contains_state(value: Any, depth: int = 0) -> bool:
        if depth > 7:
            return False
        if isinstance(value, Mapping):
            if isinstance(value.get("sources"), list) and isinstance(value.get("collections"), list):
                return True
            return any(contains_state(child, depth + 1) for child in value.values() if isinstance(child, (dict, list)))
        if isinstance(value, list):
            return any(contains_state(child, depth + 1) for child in value if isinstance(child, (dict, list)))
        return False

    def digest_target(mapping: Mapping[str, Any]) -> Any:
        for key in ("payload", "state", "data", "content", "backup"):
            candidate = mapping.get(key)
            if contains_state(candidate):
                return candidate
        return state

    def set_digest(mapping: MutableMapping[str, Any], key: str, digest: str) -> None:
        value = mapping.get(key)
        if not isinstance(value, str):
            return
        prefix = "sha256:" if value.lower().startswith("sha256:") else ""
        mapping[key] = prefix + digest

    def walk(value: Any, depth: int = 0) -> None:
        if depth > 8 or not isinstance(value, MutableMapping) or not contains_state(value):
            return
        target = digest_target(value)
        digest = hashlib.sha256(_canonical_bytes(target)).hexdigest()
        for key in ("exportedAt", "createdAt", "updatedAt"):
            if key in value and isinstance(value[key], str):
                value[key] = now
        for key in ("sha256", "digest", "checksum", "hash"):
            set_digest(value, key, digest)
        integrity = value.get("integrity")
        if isinstance(integrity, str):
            prefix = "sha256:" if integrity.lower().startswith("sha256:") else ""
            value["integrity"] = prefix + digest
        elif isinstance(integrity, MutableMapping):
            for key in ("sha256", "digest", "checksum", "hash", "value"):
                set_digest(integrity, key, digest)
        for child in value.values():
            if isinstance(child, MutableMapping):
                walk(child, depth + 1)

    if isinstance(document, MutableMapping):
        walk(document)


def _fsync_directory(path: Path) -> None:
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
    try:
        fd = os.open(path, flags)
    except OSError:
        return
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        os.close(fd)


def _write_new_bytes(path: Path, data: bytes) -> Path:
    """Durably create one output without ever replacing an existing path."""
    destination = path.expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        raise RelayError("The output file already exists. Choose another path; ProgRSS never overwrites files.")
    fd, temp_name = tempfile.mkstemp(prefix=f".{destination.name}.", suffix=".tmp", dir=destination.parent)
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.link(temp, destination)
        except FileExistsError as exc:
            raise RelayError("The output file already exists. Choose another path; ProgRSS never overwrites files.") from exc
        except OSError:
            flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
            try:
                output_fd = os.open(destination, flags, 0o600)
            except FileExistsError as exc:
                raise RelayError("The output file already exists. Choose another path; ProgRSS never overwrites files.") from exc
            try:
                with os.fdopen(output_fd, "wb") as handle:
                    handle.write(data)
                    handle.flush()
                    os.fsync(handle.fileno())
            except Exception:
                try:
                    destination.unlink()
                except OSError:
                    pass
                raise
    finally:
        try:
            temp.unlink()
        except OSError:
            pass
    _fsync_directory(destination.parent)
    return destination


def write_workspace(document: Any, location: StateLocation, state: Mapping[str, Any], output: Path) -> None:
    try:
        validate_private_source_note_placements(state)
    except SourceNoteError as exc:
        raise RelayError(f"Relay refused to write invalid Source Notes: {exc}") from exc
    copied = copy.deepcopy(document)
    copied = _replace_at_path(copied, location.path, copy.deepcopy(state))
    _refresh_envelope_metadata(copied, state)
    payload = (json.dumps(copied, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    _write_new_bytes(output, payload)

def _simple_folders(state: Mapping[str, Any]) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
    sources = {str(row.get("id")): row for row in state.get("sources") or [] if isinstance(row, Mapping) and row.get("id")}
    all_collections = {str(row.get("id")): row for row in state.get("collections") or [] if isinstance(row, Mapping) and row.get("id")}
    simple = {
        key: row for key, row in all_collections.items()
        if row.get("mode", "union") == "union" and not _text(row.get("include"), 500) and not _text(row.get("exclude"), 500)
    }
    referenced = {
        str(member.get("id"))
        for row in simple.values()
        for member in row.get("members") or []
        if isinstance(member, Mapping) and member.get("kind") == "collection" and str(member.get("id")) in simple
    }
    roots = [key for key in simple if key not in referenced]
    rows: list[dict[str, Any]] = []
    def walk(collection_id: str, parent_path: str, stack: tuple[str, ...]) -> None:
        if collection_id in stack or len(stack) >= 24:
            return
        collection = simple[collection_id]
        title = _text(collection.get("title"), 180) or "Untitled folder"
        path = f"{parent_path} › {title}" if parent_path else title
        rows.append({"id": collection_id, "title": title, "path": path, "collection": collection})
        for member in collection.get("members") or []:
            if isinstance(member, Mapping) and member.get("kind") == "collection" and str(member.get("id")) in simple:
                walk(str(member.get("id")), path, (*stack, collection_id))
    for root in roots:
        walk(root, "", ())
    for collection_id in simple:
        if not any(row["id"] == collection_id for row in rows):
            walk(collection_id, "", ())
    return rows, sources


def _resolve_folder(state: Mapping[str, Any], selector: str) -> dict[str, Any]:
    rows, _ = _simple_folders(state)
    exact_id = [row for row in rows if row["id"] == selector]
    if exact_id:
        return exact_id[0]
    folded = selector.casefold()
    exact_path = [row for row in rows if row["path"].casefold() == folded]
    if len(exact_path) == 1:
        return exact_path[0]
    exact_title = [row for row in rows if row["title"].casefold() == folded]
    if len(exact_title) == 1:
        return exact_title[0]
    if len(exact_title) > 1:
        paths = ", ".join(row["path"] for row in exact_title[:5])
        raise RelayError(f"More than one folder is named {selector!r}. Use its ID or full path: {paths}")
    available = ", ".join(row["path"] for row in rows[:8]) or "none"
    raise RelayError(f"No simple folder matches {selector!r}. Available folders: {available}")


def _subset(state: Mapping[str, Any], selector: str) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
    root = _resolve_folder(state, selector)
    rows, source_map = _simple_folders(state)
    collection_map = {row["id"]: row["collection"] for row in rows}
    collection_ids: set[str] = set()
    source_ids: set[str] = set()
    def collect(collection_id: str) -> None:
        if collection_id in collection_ids:
            return
        collection_ids.add(collection_id)
        for member in collection_map[collection_id].get("members") or []:
            if not isinstance(member, Mapping):
                continue
            member_id = str(member.get("id") or "")
            if member.get("kind") == "source" and member_id in source_map:
                source = source_map[member_id]
                if not source.get("archivedAt"):
                    source_ids.add(member_id)
            elif member.get("kind") == "collection" and member_id in collection_map:
                collect(member_id)
    collect(root["id"])
    raw_sources = [source_map[source_id] for source_id in source_map if source_id in source_ids]
    sources = [_clean_source(row) for row in raw_sources]
    live_source_ids = {row["id"] for row in sources}
    collections: list[dict[str, Any]] = []
    for collection_id in collection_map:
        if collection_id not in collection_ids:
            continue
        cleaned = _clean_collection(collection_map[collection_id])
        cleaned["members"] = [
            member for member in cleaned["members"]
            if (member["kind"] == "source" and member["id"] in live_source_ids)
            or (member["kind"] == "collection" and member["id"] in collection_ids)
        ]
        collections.append(cleaned)
    if len(sources) > MAX_SOURCES or len(collections) > MAX_COLLECTIONS:
        raise RelayError("That folder is too large to share as one file. Split it into smaller folders first.")
    return root, sources, collections


def make_bundle(
    state: Mapping[str, Any], selector: str, *, curator: str = "", note: str = "",
    update_url: str | None = None, exported_at: str | None = None,
) -> dict[str, Any]:
    root, sources, collections = _subset(state, selector)
    timestamp = exported_at or _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    timestamp = _clean_iso_time(timestamp, "The shared-folder export time")
    existing_origin = _normalize_origin(root["collection"].get("sharedFolderOrigin"))
    publication_id = existing_origin["publicationId"] if existing_origin else root["id"]
    chosen_update_url = (str(existing_origin.get("updateUrl") or "") if existing_origin else "") if update_url is None else str(update_url or "")
    chosen_update_url = _safe_url(chosen_update_url) if chosen_update_url else ""
    schema = LOCATED_BUNDLE_SCHEMA if chosen_update_url else BUNDLE_SCHEMA
    document: dict[str, Any] = {
        "schema": schema,
        "exportedAt": timestamp,
        "root": root["id"],
        "title": _text(root["path"], 130),
        "publication": {
            "schema": PUBLICATION_SCHEMA,
            "id": publication_id,
            "curator": _text(curator, 80),
            "note": _text(note, 280),
            "issuedAt": timestamp,
        },
        **({"distribution": {"schema": DISTRIBUTION_SCHEMA, "updateUrl": chosen_update_url}} if chosen_update_url else {}),
        "integrity": {"schema": INTEGRITY_SCHEMA, "digest": ""},
        "sources": sources,
        "collections": collections,
    }
    document["integrity"]["digest"] = bundle_content_digest(document)
    return validate_bundle(document)

def _opml(bundle: Mapping[str, Any], *, created_at: str | None = None) -> bytes:
    sources = {row["id"]: row for row in bundle["sources"]}
    collections = {row["id"]: row for row in bundle["collections"]}
    def esc(value: Any) -> str:
        return html.escape(str(value or ""), quote=True)
    def render(collection_id: str, stack: tuple[str, ...]) -> str:
        if collection_id in stack or len(stack) >= 24:
            return ""
        collection = collections[collection_id]
        children: list[str] = []
        for member in collection["members"]:
            if member["kind"] == "source":
                source = sources[member["id"]]
                if source["type"] == "rss":
                    children.append(f'<outline type="rss" text="{esc(source["title"])}" xmlUrl="{esc(source["url"])}"/>')
            else:
                children.append(render(member["id"], (*stack, collection_id)))
        return f'<outline text="{esc(collection["title"])}">{"".join(children)}</outline>'
    if created_at:
        try:
            created_dt = _dt.datetime.fromisoformat(str(created_at).replace("Z", "+00:00"))
            created = created_dt.astimezone(_dt.timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
        except (ValueError, TypeError):
            created = _dt.datetime(1980, 1, 1, tzinfo=_dt.timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
    else:
        created = _dt.datetime.now(_dt.timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")
    body = render(str(bundle["root"]), ())
    provenance = bundle_provenance(bundle)
    owner = f'<ownerName>{esc(provenance.get("curator"))}</ownerName>' if provenance.get("curator") else ""
    text = f'<?xml version="1.0" encoding="UTF-8"?>\n<opml version="2.0"><head><title>{esc(bundle.get("title"))}</title><dateCreated>{created}</dateCreated>{owner}</head><body>{body}</body></opml>\n'
    return text.encode("utf-8")



def _site_file_name(update_url: str) -> str:
    parsed = urlsplit(_safe_url(update_url))
    if parsed.query or parsed.fragment:
        raise RelayError("A ready-to-host package needs a direct .json address without a query or fragment.")
    raw_name = parsed.path.rsplit("/", 1)[-1]
    try:
        from urllib.parse import unquote
        name = unquote(raw_name)
    except Exception as exc:  # pragma: no cover - urllib is deterministic
        raise RelayError("The hosted ProgRSS address has an unreadable file name.") from exc
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,118}\.json", name or "", flags=re.IGNORECASE):
        raise RelayError("End the hosted ProgRSS address with a simple .json file name, such as latest.json.")
    if name in {"index.html", "subscriptions.opml", EDITION_FILE, "README.txt"}:
        raise RelayError("Choose a different .json file name for the hosted ProgRSS copy.")
    return name


def _site_source_kind(source: Mapping[str, Any]) -> str:
    if source.get("type") == "rss" or source.get("kind") == "feed":
        return "feed"
    if source.get("type") == "page" or source.get("kind") == "page":
        return "page"
    return "source"


def _site_counts(bundle: Mapping[str, Any]) -> dict[str, int]:
    return {
        "feeds": sum(1 for row in bundle["sources"] if _site_source_kind(row) == "feed"),
        "pageWatches": sum(1 for row in bundle["sources"] if _site_source_kind(row) == "page"),
        "folders": len(bundle["collections"]),
        "sourceNotes": sum(
            1
            for collection in bundle["collections"]
            for member in collection.get("members") or []
            if member.get("kind") == "source" and normalize_reason(member.get("reason")) is not None
        ),
    }


def _site_tree_html(bundle: Mapping[str, Any]) -> str:
    sources = {str(row["id"]): row for row in bundle["sources"]}
    collections = {str(row["id"]): row for row in bundle["collections"]}

    def render(collection_id: str, stack: tuple[str, ...] = ()) -> str:
        if collection_id not in collections or collection_id in stack or len(stack) >= 24:
            return ""
        collection = collections[collection_id]
        items: list[str] = []
        for member in collection.get("members") or []:
            member_id = str(member.get("id") or "")
            if member.get("kind") == "source" and member_id in sources:
                source = sources[member_id]
                kind = _site_source_kind(source)
                label = "Feed" if kind == "feed" else "Watched page" if kind == "page" else "Source"
                title = _text(source.get("title"), 130) or "Untitled source"
                url = str(source.get("url") or "")
                host = urlsplit(url).netloc
                reason = normalize_reason(member.get("reason")) if "reason" in member else None
                reason_node = (
                    '<p class="source-note"><strong>Curator’s reason for this folder:</strong> '
                    f'<span dir="auto">{html.escape(reason)}</span></p>'
                    if reason is not None else ""
                )
                items.append(
                    f'<li class="source"><span class="kind">{html.escape(label)}</span>'
                    f'<a href="{html.escape(url, quote=True)}" rel="noreferrer">{html.escape(title)}</a>'
                    + (f'<span class="host">{html.escape(host)}</span>' if host else "")
                    + reason_node
                    + "</li>"
                )
            elif member.get("kind") == "collection" and member_id in collections:
                child = collections[member_id]
                nested = render(member_id, (*stack, collection_id))
                if nested:
                    child_title = html.escape(_text(child.get("title"), 130) or "Untitled folder")
                    items.append(f'<li class="folder"><strong>{child_title}</strong>{nested}</li>')
        return f'<ul>{"".join(items)}</ul>'

    return render(str(bundle["root"]))


def _site_language_tag(value: Any) -> str:
    raw = str(value or "").strip()
    if not raw or len(raw) > 100 or re.search(r"[\x00-\x20\x7f]", raw):
        return ""
    if not re.fullmatch(r"[A-Za-z]{1,8}(?:-[A-Za-z0-9]{1,8})*", raw):
        return ""
    return raw.lower()


def _site_iso_time(value: Any, label: str) -> str:
    raw = _text(value, 60)
    if not raw:
        raise RelayError(f"{label} has no valid time.")
    try:
        parsed = _dt.datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except (ValueError, TypeError) as exc:
        raise RelayError(f"{label} has no valid time.") from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=_dt.timezone.utc)
    return parsed.astimezone(_dt.timezone.utc).isoformat().replace("+00:00", "Z")


def _site_strict_int(value: Any, minimum: int, maximum: int, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= maximum:
        raise RelayError(f"{label} is outside its supported bounds.")
    return value


def _site_edition(bundle: Mapping[str, Any], edition: Mapping[str, Any] | None) -> dict[str, Any] | None:
    """Validate and sanitize one summary-only folder Edition for a static site."""
    if edition is None:
        return None
    if not isinstance(edition, Mapping) or edition.get("version") != JSON_FEED_VERSION:
        raise RelayError("The recent-updates file is not a supported JSON Feed 1.1 document.")
    allowed_top = {
        "version", "title", "description", "user_comment", "home_page_url",
        "feed_url", "authors", "language", "items", "_progrss",
    }
    if any(str(key) not in allowed_top for key in edition):
        raise RelayError("The recent-updates feed contains material ProgRSS did not prepare for a public folder edition.")
    metadata = edition.get("_progrss")
    allowed_metadata = {
        "schema", "generatedAt", "folder", "folderSourceCount", "representedSourceCount",
        "itemCount", "omittedByLimit", "included", "excluded",
    }
    if (
        not isinstance(metadata, Mapping)
        or any(str(key) not in allowed_metadata for key in metadata)
        or metadata.get("schema") != FOLDER_EDITION_SCHEMA
    ):
        raise RelayError("The recent-updates feed is missing or extends its bounded ProgRSS folder-edition marker.")
    folder = _text(metadata.get("folder"), 180)
    bundle_title = _text(bundle.get("title"), 180)
    if not folder or folder != bundle_title:
        raise RelayError("The recent-updates feed belongs to a different folder.")
    raw_items = edition.get("items")
    if not isinstance(raw_items, list) or len(raw_items) > MAX_EDITION_ITEMS:
        raise RelayError("The recent-updates feed may contain at most 100 items.")
    generated_at = _site_iso_time(metadata.get("generatedAt"), "The recent-updates feed")
    included = metadata.get("included")
    excluded = metadata.get("excluded")
    required_included = ("titles", "shortSummaries", "links", "dates", "languages", "sourceLabels")
    required_exclusions = (
        "fullRetainedText", "readingState", "savedState", "pageWatchEvidence",
        "snapshots", "browserAuthority", "privateKeys",
    )
    if (
        not isinstance(included, Mapping)
        or set(map(str, included)) != set(required_included)
        or any(included.get(key) is not True for key in required_included)
    ):
        raise RelayError("The recent-updates feed does not confirm its bounded public fields.")
    if (
        not isinstance(excluded, Mapping)
        or set(map(str, excluded)) != set(required_exclusions)
        or any(excluded.get(key) is not True for key in required_exclusions)
    ):
        raise RelayError("The recent-updates feed does not confirm the required private-data exclusions.")
    folder_source_count = _site_strict_int(metadata.get("folderSourceCount"), 0, 200, "The folder source count")
    represented_source_count = _site_strict_int(metadata.get("representedSourceCount"), 0, 200, "The represented source count")
    item_count = _site_strict_int(metadata.get("itemCount"), 0, MAX_EDITION_ITEMS, "The recent-update item count")
    omitted_by_limit = _site_strict_int(metadata.get("omittedByLimit"), 0, 100_000, "The omitted-item count")
    if item_count != len(raw_items) or represented_source_count > folder_source_count:
        raise RelayError("The recent-updates feed has inconsistent public counts.")

    provenance = bundle_provenance(bundle)
    curator = _text(provenance.get("curator"), 80)
    authors: list[dict[str, str]] | None = None
    if edition.get("authors") is not None:
        raw_authors = edition.get("authors")
        if (
            not isinstance(raw_authors, list)
            or len(raw_authors) != 1
            or not isinstance(raw_authors[0], Mapping)
            or set(map(str, raw_authors[0])) != {"name"}
        ):
            raise RelayError("The recent-updates feed has an invalid curator label.")
        author_name = _text(raw_authors[0].get("name"), 80)
        if not author_name or author_name != curator:
            raise RelayError("The recent-updates feed attribution does not match the shared folder.")
        authors = [{"name": author_name}]
    elif curator:
        raise RelayError("The recent-updates feed attribution does not match the shared folder.")

    allowed_item = {"id", "title", "content_text", "summary", "url", "date_published", "language", "_progrss"}
    allowed_extension = {"sourceCount", "sources", "changeKind"}
    allowed_change_kinds = {"entry-added", "entry-changed", "entry-removed", "text-changed"}
    items: list[dict[str, Any]] = []
    for index, raw_item in enumerate(raw_items, 1):
        if not isinstance(raw_item, Mapping) or any(str(key) not in allowed_item for key in raw_item):
            raise RelayError(f"Recent update {index} contains unsupported material.")
        public_id = _text(raw_item.get("id"), 2_048)
        title = _text(raw_item.get("title"), 240) or "Untitled update"
        content = _text(raw_item.get("content_text"), 800)
        summary = _text(raw_item.get("summary"), 800)
        if not public_id or not content:
            raise RelayError(f"Recent update {index} is missing its public identifier or summary text.")
        if not (
            re.fullmatch(r"urn:progrss:edition:[0-9a-f]{16}", public_id)
            or public_id.startswith("http://")
            or public_id.startswith("https://")
        ):
            raise RelayError(f"Recent update {index} has an unsupported public identifier.")
        if public_id.startswith(("http://", "https://")):
            public_id = _safe_url(public_id)

        extension = raw_item.get("_progrss")
        if not isinstance(extension, Mapping) or any(str(key) not in allowed_extension for key in extension):
            raise RelayError(f"Recent update {index} is missing its bounded source evidence.")
        raw_sources = extension.get("sources")
        if not isinstance(raw_sources, list) or len(raw_sources) > 8:
            raise RelayError(f"Recent update {index} names too many source witnesses.")
        sources: list[dict[str, str]] = []
        for source in raw_sources:
            if (
                not isinstance(source, Mapping)
                or set(map(str, source)) != {"title", "type"}
                or source.get("type") not in {"feed", "page"}
            ):
                raise RelayError(f"Recent update {index} has malformed source evidence.")
            source_title = _text(source.get("title"), 130) or "Untitled source"
            sources.append({"title": source_title, "type": str(source.get("type"))})
        source_count = _site_strict_int(extension.get("sourceCount"), 1, 200, f"Recent update {index} source count")
        if source_count < len(sources):
            raise RelayError(f"Recent update {index} has inconsistent source evidence.")
        change_kind = _text(extension.get("changeKind"), 40)
        if change_kind and change_kind not in allowed_change_kinds:
            raise RelayError(f"Recent update {index} has an unsupported page-change kind.")
        item: dict[str, Any] = {
            "id": public_id,
            "title": title,
            "content_text": content,
            "_progrss": {
                "sourceCount": source_count,
                "sources": sources,
                **({"changeKind": change_kind} if change_kind else {}),
            },
        }
        if summary:
            item["summary"] = summary
        raw_url = raw_item.get("url")
        if raw_url:
            item["url"] = _safe_url(raw_url)
        if raw_item.get("date_published"):
            item["date_published"] = _site_iso_time(raw_item.get("date_published"), f"Recent update {index}")
        if raw_item.get("language"):
            language = _site_language_tag(raw_item.get("language"))
            if not language:
                raise RelayError(f"Recent update {index} has an invalid language tag.")
            item["language"] = language
        items.append(item)

    update_url = str(bundle["distribution"]["updateUrl"])
    feed_url = urljoin(update_url, EDITION_FILE)
    home_page_url = urljoin(update_url, "index.html")
    document: dict[str, Any] = {
        "version": JSON_FEED_VERSION,
        "title": _text(edition.get("title"), 240) or f"{folder} · recent updates",
        "description": _text(edition.get("description"), 280) or f"Recent updates selected from {folder}.",
        "user_comment": _text(edition.get("user_comment"), 500) or "Prepared manually from a local ProgRSS folder.",
        "home_page_url": home_page_url,
        "feed_url": feed_url,
        **({"authors": authors} if authors else {}),
        "items": items,
        "_progrss": {
            "schema": FOLDER_EDITION_SCHEMA,
            "generatedAt": generated_at,
            "folder": folder,
            "folderSourceCount": folder_source_count,
            "representedSourceCount": represented_source_count,
            "itemCount": item_count,
            "omittedByLimit": omitted_by_limit,
            "included": {
                "titles": True,
                "shortSummaries": True,
                "links": True,
                "dates": True,
                "languages": True,
                "sourceLabels": True,
            },
            "excluded": {key: True for key in required_exclusions},
        },
    }
    if edition.get("language"):
        language = _site_language_tag(edition.get("language"))
        if not language:
            raise RelayError("The recent-updates feed has an invalid top-level language tag.")
        document["language"] = language
    payload = (json.dumps(document, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    if len(payload) > MAX_EDITION_BYTES:
        raise RelayError("The normalized recent-updates feed is larger than the 250 KB safety limit.")
    return document


def check_publication_page(page_url: str, *, require_updates: bool = False) -> dict[str, Any]:
    """Audit one deployed static publication page and its advertised artifacts."""
    body, page_remote = _fetch_publication_page(page_url)
    parser, bundle_links, feed_links = _publication_page_evidence(body, page_remote)
    if parser.unsafe:
        details = ", ".join(parser.unsafe[:4])
        raise RelayError(f"The publication page loads or contains active material ({details}).")
    csp_ok = any(re.search(r"(?:^|;)\s*default-src\s+'none'(?:\s*;|\s|$)", value, flags=re.IGNORECASE) for value in parser.csp)
    if not csp_ok:
        raise RelayError("The publication page does not declare a Content Security Policy with default-src 'none'.")
    if len(bundle_links) != 1:
        if not bundle_links:
            raise RelayError(f"The publication page does not advertise one same-site source list using {BUNDLE_MEDIA_TYPE}.")
        raise RelayError(f"The publication page advertises {len(bundle_links)} source lists; the deployed choice is ambiguous.")
    if len(feed_links) > 1:
        raise RelayError(f"The publication page advertises {len(feed_links)} recent-update feeds; the deployed choice is ambiguous.")
    if require_updates and not feed_links:
        raise RelayError("The publication page has no advertised recent-updates feed, but --require-updates was requested.")

    bundle, bundle_remote = fetch_publication(bundle_links[0]["url"])
    if bundle.get("schema") != LOCATED_BUNDLE_SCHEMA:
        raise RelayError("A deployed publication page must advertise a located ProgRSS source list with a future-copy address.")
    configured_update = _safe_url(str(bundle.get("distribution", {}).get("updateUrl") or ""))
    if configured_update != str(bundle_remote["finalUrl"]) or configured_update != bundle_links[0]["url"]:
        raise RelayError("The source list’s configured future-copy address does not match the file advertised and served by this page.")

    final_page = str(page_remote["finalUrl"])
    parsed_page = urlsplit(final_page)
    page_document_url = _safe_url(urljoin(final_page, "index.html")) if parsed_page.path.endswith("/") else _safe_url(final_page)
    edition_report: dict[str, Any] | None = None
    edition_remote: dict[str, Any] | None = None
    if feed_links:
        edition_source, edition_remote = _fetch_public_json(
            feed_links[0]["url"],
            label="recent-updates feed",
            accept="application/feed+json, application/json;q=0.9, text/plain;q=0.2, */*;q=0.1",
            byte_limit=MAX_EDITION_BYTES,
        )
        raw_feed_url = _safe_url(str(edition_source.get("feed_url") or ""))
        raw_home_url = _safe_url(str(edition_source.get("home_page_url") or ""))
        if raw_feed_url != str(edition_remote["finalUrl"]) or raw_feed_url != feed_links[0]["url"]:
            raise RelayError("The recent-updates feed_url does not match the file advertised and served by this page.")
        if raw_home_url not in {final_page, page_document_url}:
            raise RelayError("The recent-updates home_page_url does not point back to this publication page.")
        normalized = _site_edition(bundle, edition_source)
        if normalized is None:  # defensive; _site_edition raises for malformed input
            raise RelayError("The recent-updates feed could not be validated.")
        meta = normalized["_progrss"]
        edition_report = {
            "schema": FOLDER_EDITION_SCHEMA,
            "title": normalized.get("title", ""),
            "folder": meta.get("folder", ""),
            "generatedAt": meta.get("generatedAt", ""),
            "items": len(normalized.get("items", [])),
            "omittedByLimit": meta.get("omittedByLimit", 0),
            "folderSources": meta.get("folderSourceCount", 0),
            "representedSources": meta.get("representedSourceCount", 0),
            "feedUrl": raw_feed_url,
            "homePageUrl": raw_home_url,
            "summaryOnly": True,
        }

    provenance = bundle_provenance(bundle)
    counts = _site_counts(bundle)
    expected_types = {
        "page": str(page_remote.get("contentType") or "").split(";", 1)[0].strip().lower() in {"text/html", "application/xhtml+xml", "text/plain", ""},
        "sourceList": str(bundle_remote.get("contentType") or "").split(";", 1)[0].strip().lower() in {BUNDLE_MEDIA_TYPE, "application/json", "text/plain", ""},
        "recentUpdates": edition_remote is None or str(edition_remote.get("contentType") or "").split(";", 1)[0].strip().lower() in {FEED_MEDIA_TYPE, "application/json", "text/plain", ""},
    }
    warnings = [f"Unexpected {name} Content-Type" for name, valid in expected_types.items() if not valid]
    return {
        "schema": "progrss.publication-deployment-check.v1",
        "valid": True,
        "page": page_remote,
        "staticPage": {
            "contentSecurityPolicy": parser.csp,
            "defaultSrcNone": True,
            "activeOrRemoteResourceElements": 0,
            "sourceListAdvertisements": len(bundle_links),
            "recentUpdatesAdvertisements": len(feed_links),
        },
        "sourceList": {
            "advertisement": bundle_links[0],
            "remote": bundle_remote,
            "schema": bundle.get("schema", ""),
            "title": bundle.get("title", ""),
            "publicationId": provenance.get("publicationId", ""),
            "curator": provenance.get("curator", ""),
            "signatureState": provenance.get("signatureState", "unsigned"),
            "fingerprint": provenance.get("fingerprint", ""),
            "updateUrl": configured_update,
            **counts,
        },
        "recentUpdates": ({"advertisement": feed_links[0], "remote": edition_remote, **edition_report} if edition_report and edition_remote else None),
        "contentTypesExpected": expected_types,
        "warnings": warnings,
        "networkRequests": int(page_remote.get("networkRequests") or 0) + int(bundle_remote.get("networkRequests") or 0) + int((edition_remote or {}).get("networkRequests") or 0),
        "credentials": "omitted",
        "automatic": False,
        "writes": False,
        "applied": False,
    }


def _site_recent_updates_html(edition: Mapping[str, Any] | None) -> str:
    if not edition or not edition.get("items"):
        return ""
    labels = {
        "entry-added": "New entry",
        "entry-changed": "Changed entry",
        "entry-removed": "Removed entry",
        "text-changed": "Page text changed",
    }
    rendered: list[str] = []
    for item in list(edition["items"])[:10]:
        language = _site_language_tag(item.get("language"))
        lang_attr = f' lang="{html.escape(language, quote=True)}"' if language else ""
        title = html.escape(_text(item.get("title"), 240) or "Untitled update")
        raw_url = _text(item.get("url"), 2_048)
        if raw_url:
            title_node = f'<a href="{html.escape(raw_url, quote=True)}" rel="noreferrer"{lang_attr} dir="auto">{title}</a>'
        else:
            title_node = f'<span{lang_attr} dir="auto">{title}</span>'
        summary = _text(item.get("summary") or item.get("content_text"), 800)
        evidence = item.get("_progrss") if isinstance(item.get("_progrss"), Mapping) else {}
        source_labels = [
            _text(source.get("title"), 130)
            for source in evidence.get("sources", [])
            if isinstance(source, Mapping) and _text(source.get("title"), 130)
        ][:8]
        date_label = ""
        if item.get("date_published"):
            try:
                stamp = _dt.datetime.fromisoformat(str(item["date_published"]).replace("Z", "+00:00"))
                date_label = f"{stamp.strftime('%b')} {stamp.day}, {stamp.year}"
            except (ValueError, TypeError):
                date_label = ""
        change_label = labels.get(_text(evidence.get("changeKind"), 40), "")
        metadata = " · ".join(html.escape(value) for value in [date_label, *source_labels, change_label] if value)
        rendered.append(
            f'<li class="update"><h3>{title_node}</h3>'
            + (f'<p{lang_attr} dir="auto">{html.escape(summary)}</p>' if summary else "")
            + (f'<p class="fine">{metadata}</p>' if metadata else "")
            + "</li>"
        )
    remaining = max(0, len(edition["items"]) - len(rendered))
    tail = f'<p class="fine">The feed contains {remaining} more recent update{"" if remaining == 1 else "s"}.</p>' if remaining else ""
    return f'<ol class="updates">{"".join(rendered)}</ol>{tail}'


def _site_index_html(
    bundle: Mapping[str, Any],
    update_file: str,
    include_opml: bool,
    edition: Mapping[str, Any] | None = None,
) -> bytes:
    counts = _site_counts(bundle)
    provenance = bundle_provenance(bundle)
    title = _text(bundle.get("title"), 180) or "Shared sources"
    curator = _text(provenance.get("curator"), 80)
    note = _text(provenance.get("note"), 280)
    try:
        issued_dt = _dt.datetime.fromisoformat(str(bundle.get("exportedAt") or "").replace("Z", "+00:00")).astimezone(_dt.timezone.utc)
        issued = f"{issued_dt.strftime('%B')} {issued_dt.day}, {issued_dt.year}"
    except (ValueError, TypeError):
        issued = ""
    tree = _site_tree_html(bundle)
    opml_action = '<a class="action secondary" href="subscriptions.opml" download>Get feeds for another reader</a>' if include_opml else ""
    intro = f'<p class="lede note">{html.escape(note)}</p>' if note else '<p class="lede">A portable collection of feeds and watched webpages.</p>'
    signed = provenance.get("signatureState") == "verified"
    signature_note = (
        "This ProgRSS copy includes a signature that recipients can verify against its included public key. "
        "A valid signature does not prove the curator’s real-world identity or that every listed site is safe."
        if signed else
        "This ProgRSS copy is unsigned. Its content digest detects accidental or malicious changes but does not establish a curator’s identity."
    )
    curator_suffix = f" · {html.escape(curator)}" if curator else ""
    issued_suffix = f" {html.escape(issued)}" if issued else ""
    edition_link = (
        f'\n<link rel="alternate" type="{FEED_MEDIA_TYPE}" href="{EDITION_FILE}" title="{html.escape(title)} recent updates">'
        if edition else ""
    )
    edition_action = f'<a class="action" href="{EDITION_FILE}" download>Get recent updates feed</a>' if edition else ""
    edition_fact = f'<span class="fact">{len(edition["items"])} recent update{"" if len(edition["items"]) == 1 else "s"}</span>' if edition else ""
    source_note_fact = (
        f'<span class="fact">{counts["sourceNotes"]} curator reason{"" if counts["sourceNotes"] == 1 else "s"}</span>'
        if counts["sourceNotes"] else ""
    )
    source_note_explainer = (
        '<p class="fine source-note-explainer">Curator reasons explain why a source appears in a particular folder. '
        'They are written by the person who prepared this source list and are not a ProgRSS safety claim.</p>'
        if counts["sourceNotes"] else ""
    )
    recent_updates = _site_recent_updates_html(edition)
    recent_section = (
        f'<section aria-labelledby="updates-heading"><h2 id="updates-heading">Recent updates</h2>'
        '<p class="fine">This is a manual snapshot. It changes only when the curator prepares and uploads a new package.</p>'
        f'{recent_updates}</section>'
        if edition else ""
    )
    follow_choice = (
        '<article class="choice"><p class="choice-number">01</p><h3>Follow updates</h3>'
        '<p>Add one ordinary summary feed. The underlying feeds, watched pages, and folders stay out of your library.</p>'
        f'<div class="actions">{edition_action}</div></article>'
        if edition else ""
    )
    route_number = "02" if edition else "01"
    branch_number = "03" if edition else "02"
    choice_section = (
        '<section aria-labelledby="choose-heading"><h2 id="choose-heading">Choose what you want</h2>'
        '<p>Each choice has a different consequence. Nothing is added merely by opening this page.</p>'
        '<div class="choice-grid">'
        f'{follow_choice}'
        f'<article class="choice featured"><p class="choice-number">{route_number}</p><h3>Add the complete route</h3>'
        '<p>Review every shared feed, watched-page recipe, and folder. Existing sources are reused; new sources start paused.</p>'
        f'<div class="actions"><a class="action" href="{html.escape(update_file, quote=True)}" download>Get complete route</a></div></article>'
        f'<article class="choice"><p class="choice-number">{branch_number}</p><h3>Take one branch</h3>'
        '<p>Open the same checked source list, then choose one folder section in ProgRSS. The result becomes an independent local route and will not silently track future parent copies.</p>'
        f'<div class="actions"><a class="action secondary" href="{html.escape(update_file, quote=True)}" download>Get route and choose a branch</a></div></article>'
        '</div>'
        f'<p class="fine">Already using ProgRSS? Choose Add → Use this page while this page is open, or paste the direct JSON address into Add. ProgRSS reviews the result before adding anything.</p>'
        f'<div class="other-reader"><h3>Using another feed reader?</h3><div class="actions">{opml_action}</div><p class="fine">OPML carries feeds and hierarchy only. It does not carry watched-page recipes, Source Notes on direct placements, or ProgRSS branch semantics.</p></div>'
        '<p class="fine">The ProgRSS file does not include anyone’s reading history, saved items, page snapshots, browser permissions, or private signing key.</p>'
        '</section>'
    )
    page = f'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'; object-src 'none'; frame-src 'none'; img-src 'none'">
<link rel="alternate" type="{BUNDLE_MEDIA_TYPE}" href="{html.escape(update_file, quote=True)}" title="{html.escape(title)} source list for ProgRSS">{edition_link}
<title>{html.escape(title)} · shared sources</title>
<style>
:root{{color-scheme:light dark;font:18px/1.55 system-ui,sans-serif}}body{{max-width:58rem;margin:auto;padding:clamp(1rem,4vw,3rem)}}main{{display:grid;gap:1.4rem}}h1,h2,h3{{line-height:1.15}}p{{max-width:68ch}}.lede{{font-size:1.1rem}}.facts{{display:flex;flex-wrap:wrap;gap:.65rem}}.fact,.kind{{border:1px solid currentColor;border-radius:999px;padding:.18rem .65rem}}.actions{{display:flex;flex-wrap:wrap;gap:.75rem}}.action{{display:inline-block;border:2px solid currentColor;border-radius:.6rem;padding:.75rem 1rem;font-weight:700}}.secondary{{font-weight:600}}.choice-grid{{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:1rem}}.choice{{border:1px solid currentColor;border-radius:1rem;padding:1rem;display:flex;flex-direction:column}}.choice.featured{{border-width:2px}}.choice-number{{font:700 .78rem/1 system-ui,sans-serif;letter-spacing:.14em;margin:0 0 .7rem}}.choice h3{{margin:.1rem 0 .45rem}}.choice .actions{{margin-top:auto;padding-top:.5rem}}.other-reader{{border-top:1px solid currentColor;margin-top:1.25rem;padding-top:.8rem}}ul{{padding-left:1.35rem}}li{{margin:.55rem 0}}.source{{display:grid;grid-template-columns:max-content minmax(0,1fr);gap:.2rem .65rem;align-items:start}}.source .host{{grid-column:2;opacity:.72;font-size:.9rem;overflow-wrap:anywhere}}.source-note{{grid-column:2;margin:.15rem 0 0;white-space:pre-wrap;overflow-wrap:anywhere}}.source-note strong{{font-weight:700}}.source-note-explainer{{margin-top:.35rem}}.folder>strong{{display:block;margin-top:1rem}}.updates{{display:grid;gap:1rem;padding:0;list-style:none}}.update{{border-top:1px solid currentColor;padding-top:1rem}}.update:first-child{{border-top:0;padding-top:0}}.update h3{{margin:.1rem 0 .35rem;font-size:1.05rem}}.update p{{margin:.35rem 0}}.note{{border-left:.3rem solid currentColor;padding-left:1rem}}.fine{{font-size:.9rem;opacity:.78}}a{{color:inherit;text-underline-offset:.18em}}a:focus-visible{{outline:.2rem solid currentColor;outline-offset:.2rem}}@media(max-width:48rem){{.choice-grid{{grid-template-columns:1fr}}}}@media(max-width:32rem){{.actions{{display:grid}}.action{{text-align:center}}.source{{grid-template-columns:1fr}}.source .host,.source-note{{grid-column:1}}}}
</style>
</head>
<body>
<main>
<header>
<p class="fine">ProgRSS source list{curator_suffix}</p>
<h1>{html.escape(title)}</h1>
{intro}
<div class="facts"><span class="fact">{counts['feeds']} feed{'s' if counts['feeds'] != 1 else ''}</span><span class="fact">{counts['pageWatches']} watched page{'s' if counts['pageWatches'] != 1 else ''}</span><span class="fact">{counts['folders']} folder{'s' if counts['folders'] != 1 else ''}</span>{source_note_fact}{edition_fact}</div>
</header>
{choice_section}
{recent_section}
<section aria-labelledby="sources-heading">
<h2 id="sources-heading">What it follows</h2>
{source_note_explainer}
{tree or '<p>No public sources were included.</p>'}
</section>
<footer>
<p>{html.escape(signature_note)}</p>
<p class="fine">Prepared{issued_suffix}. This page has no scripts, trackers, remote images, or automatic update checks. It contacts a listed site only when a visitor chooses one of its links.</p>
</footer>
</main>
</body>
</html>
'''
    return page.encode("utf-8")


def _site_readme(
    bundle: Mapping[str, Any],
    update_file: str,
    include_opml: bool,
    edition: Mapping[str, Any] | None = None,
) -> bytes:
    counts = _site_counts(bundle)
    opml_line = "  subscriptions.opml  Feed-and-hierarchy import for other readers; page watches, Source Notes, and ProgRSS branch semantics are omitted.\n" if include_opml else ""
    edition_line = f"  {EDITION_FILE}  Summary-only JSON Feed of {len(edition['items'])} recent update(s).\n" if edition else ""
    edition_note = (
        f"The index page also advertises {EDITION_FILE} as a standard JSON Feed and\n"
        "shows a small readable selection. It is a manual snapshot, not an account or a\n"
        "live publishing service. Prepare and upload a new package when the folder changes.\n\n"
        if edition else ""
    )
    edition_privacy = " The recent-updates feed also excludes full retained text and page-watch Before/Now evidence." if edition else ""
    source_note_note = (
        f"The HTML page and ProgRSS JSON show {counts['sourceNotes']} curator-written folder reason"
        f"{'' if counts['sourceNotes'] == 1 else 's'}. Each reason belongs to one direct folder/source placement and is not a ProgRSS safety claim.\n"
        if counts["sourceNotes"] else ""
    )
    readme = f'''ProgRSS ready-to-host source list
=====================================

Upload these files together to the public website named in the source list:

  {update_file}       The ProgRSS source list used by manual update checks.
  index.html      A script-free page for people.
{opml_line}{edition_line}  README.txt      These instructions.

Configured public address:
  {bundle["distribution"]["updateUrl"]}

The uploaded JSON file must remain at that exact address. Recipients choose when
to check it. ProgRSS does not poll it, apply updates automatically, or create a
notification stream.

The index page advertises the JSON file as a ProgRSS source list. A visitor
can open the page beside ProgRSS and choose Add → Use this page to review the
route. Discovery does not add anything or schedule a future check.

The page distinguishes the recipient consequences in ordinary language:
  Follow updates       One summary feed only, when included.
  Add complete route   All reviewed sources and folder routes.
  Take one branch      One reviewed folder section as an independent local route.
The complete-route and branch choices use the same checked ProgRSS source list;
the recipient chooses the branch during review.

{edition_note}{"Following recent updates adds one summary feed; it does not add the underlying\nfeeds, watched pages, or folders.\n\n" if edition else ""}Contents: {counts["feeds"]} feed(s), {counts["pageWatches"]} page watch(es), {counts["folders"]} folder(s), {counts["sourceNotes"]} curator reason(s).

{source_note_note}OPML carries feeds and hierarchy only; it omits watched-page recipes, curator reasons, and ProgRSS branch semantics.

The shared files do not contain reading history, saved items, page snapshots,
browser permissions, or private signing keys.{edition_privacy}
The HTML page has no scripts, trackers, remote images, frames, or embedded media.
'''
    return readme.encode("utf-8")


def publication_site_files(
    bundle: Mapping[str, Any],
    edition: Mapping[str, Any] | None = None,
) -> dict[str, bytes]:
    checked = validate_bundle(bundle)
    if checked.get("schema") != LOCATED_BUNDLE_SCHEMA:
        raise RelayError("A ready-to-host website needs a shared folder with a future-copy address.")
    normalized_edition = _site_edition(checked, edition)
    update_file = _site_file_name(str(checked["distribution"]["updateUrl"]))
    counts = _site_counts(checked)
    include_opml = counts["feeds"] > 0
    files: dict[str, bytes] = {
        "index.html": _site_index_html(checked, update_file, include_opml, normalized_edition),
        update_file: (json.dumps(checked, ensure_ascii=False, indent=2) + "\n").encode("utf-8"),
        "README.txt": _site_readme(checked, update_file, include_opml, normalized_edition),
    }
    if include_opml:
        files["subscriptions.opml"] = _opml(checked, created_at=str(checked.get("exportedAt") or ""))
    if normalized_edition:
        files[EDITION_FILE] = (json.dumps(normalized_edition, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    return files


def build_publication_site(
    bundle: Mapping[str, Any],
    edition: Mapping[str, Any] | None = None,
) -> tuple[bytes, dict[str, Any]]:
    checked = validate_bundle(bundle)
    normalized_edition = _site_edition(checked, edition)
    files = publication_site_files(checked, normalized_edition)
    try:
        stamp = _dt.datetime.fromisoformat(str(checked.get("exportedAt") or "").replace("Z", "+00:00")).astimezone(_dt.timezone.utc)
    except (ValueError, TypeError):
        stamp = _dt.datetime(1980, 1, 1, tzinfo=_dt.timezone.utc)
    date_time = (max(1980, min(2107, stamp.year)), stamp.month, stamp.day, stamp.hour, stamp.minute, stamp.second)
    update_file = _site_file_name(str(checked["distribution"]["updateUrl"]))
    ordered_names = ["index.html", update_file, "subscriptions.opml", EDITION_FILE, "README.txt"]
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_STORED, strict_timestamps=True) as archive:
        for name in ordered_names:
            if name not in files:
                continue
            info = zipfile.ZipInfo(name, date_time=date_time)
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_STORED
            archive.writestr(info, files[name])
    payload = buffer.getvalue()
    if len(payload) > MAX_SITE_BYTES:
        raise RelayError("The ready-to-host website is larger than the 2.5 MB safety limit.")
    with zipfile.ZipFile(io.BytesIO(payload), "r") as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or any(name.startswith("/") or ".." in Path(name).parts or "\\" in name for name in names):
            raise RelayError("The ready-to-host website contains an unsafe file path.")
        if set(names) != set(files):
            raise RelayError("The ready-to-host website did not preserve every expected file.")
        for name, expected in files.items():
            if archive.read(name) != expected:
                raise RelayError("The ready-to-host website failed its local read-back check.")
    provenance = bundle_provenance(checked)
    counts = _site_counts(checked)
    summary = {
        "schema": "progrss.publication-site.v1",
        "title": checked.get("title", ""),
        "curator": provenance.get("curator", ""),
        "updateUrl": provenance.get("updateUrl", ""),
        "updateFile": update_file,
        **counts,
        "signatureState": provenance.get("signatureState", "unsigned"),
        "fingerprint": provenance.get("fingerprint", ""),
        "files": names,
        "bytes": len(payload),
        "scripts": 0,
        "trackers": 0,
        "automaticChecks": False,
        "discoverableFromPage": True,
        "advertisedMediaType": BUNDLE_MEDIA_TYPE,
        "recentUpdatesIncluded": bool(normalized_edition),
        "updates": len(normalized_edition["items"]) if normalized_edition else 0,
        "updatesFile": EDITION_FILE if normalized_edition else "",
        "feedUrl": normalized_edition.get("feed_url", "") if normalized_edition else "",
        "advertisedFeedMediaType": FEED_MEDIA_TYPE if normalized_edition else "",
        "networkRequests": 0,
    }
    return payload, summary


def _page_key(source: Mapping[str, Any]) -> tuple[Any, ...]:
    return (
        source.get("url"), source.get("mode", "region"), source.get("selector", ""),
        source.get("titleSelector", ""), source.get("linkSelector", ""),
        source.get("include", ""), source.get("exclude", ""),
        int(source.get("threshold") if source.get("threshold") is not None else 24), bool(source.get("ignoreNumbers", False)),
    )


def _unique_id(preferred: str, occupied: set[str], seed: str, prefix: str) -> str:
    candidate = preferred if _ID_RE.fullmatch(preferred or "") else ""
    if candidate and candidate not in occupied:
        occupied.add(candidate)
        return candidate
    stem = f"{prefix}_{hashlib.sha256(seed.encode('utf-8')).hexdigest()[:16]}"
    candidate = stem
    counter = 2
    while candidate in occupied:
        candidate = f"{stem}_{counter}"
        counter += 1
    occupied.add(candidate)
    return candidate


def _source_aliases(source: Mapping[str, Any]) -> set[str]:
    values: list[Any] = [source.get("url"), source.get("declaredFeedUrl")]
    for key in ("previousUrls", "aliasUrls"):
        raw = source.get(key)
        if isinstance(raw, list):
            values.extend(raw)
    aliases: set[str] = set()
    for value in values:
        try:
            aliases.add(_safe_url(value))
        except RelayError:
            continue
    return aliases


def _source_acquisition_key(source: Mapping[str, Any]) -> tuple[Any, ...]:
    clean = _clean_source(source)
    return (
        clean["type"], clean["url"], clean["mode"], clean["selector"],
        clean["titleSelector"], clean["linkSelector"], clean["include"],
        clean["exclude"], clean["threshold"], clean["ignoreNumbers"],
    )


def _portable_source(source: Mapping[str, Any], remote_id: str) -> dict[str, Any]:
    prepared = dict(source)
    prepared["id"] = remote_id
    return _clean_source(prepared)


def _member_key(member: Mapping[str, Any]) -> tuple[str, str]:
    return str(member.get("kind") or ""), str(member.get("id") or "")


def _unique_members(rows: Iterable[Mapping[str, Any]]) -> list[dict[str, Any]]:
    seen: dict[tuple[str, str], dict[str, Any]] = {}
    result: list[dict[str, Any]] = []
    for row in rows:
        pair = _member_key(row)
        if pair[0] not in {"source", "collection"} or not pair[1]:
            continue
        if pair[0] != "source" and "reason" in row:
            raise RelayError("Only a direct source placement may carry a Source Note.")
        try:
            projected = preserve_reason(row, {"kind": pair[0], "id": pair[1]}) if pair[0] == "source" else {"kind": pair[0], "id": pair[1]}
        except SourceNoteError as exc:
            raise RelayError(str(exc)) from exc
        previous = seen.get(pair)
        if previous is not None:
            if previous != projected:
                raise RelayError("A folder contains conflicting Source Notes for the same direct placement.")
            continue
        seen[pair] = projected
        result.append(projected)
    return result


def _translate_members(
    collection: Mapping[str, Any], source_map: Mapping[str, str], collection_map: Mapping[str, str],
) -> list[dict[str, Any]]:
    translated: list[dict[str, Any]] = []
    for member in collection.get("members") or []:
        if not isinstance(member, Mapping):
            continue
        local_id = source_map.get(str(member.get("id") or "")) if member.get("kind") == "source" else collection_map.get(str(member.get("id") or ""))
        if local_id:
            projected = {"kind": str(member.get("kind")), "id": local_id}
            if member.get("kind") == "source":
                projected = preserve_reason(member, projected)
            translated.append(projected)
    return _unique_members(translated)


def _collection_meaning(collection: Mapping[str, Any], members: Sequence[Mapping[str, Any]] | None = None) -> dict[str, Any]:
    return {
        "title": _text(collection.get("title"), 130) or "Untitled folder",
        "mode": str(collection.get("mode") or "union"),
        "include": _text(collection.get("include"), 280),
        "exclude": _text(collection.get("exclude"), 280),
        "author": _text(collection.get("author"), 80) or "anonymous",
        "members": _unique_members(members if members is not None else (collection.get("members") or [])),
    }


def _merge_host(value: Any) -> str:
    try:
        return (urlsplit(str(value or "")).hostname or "").lower()
    except ValueError:
        return ""


def _recipe_evidence(source: Mapping[str, Any] | None) -> dict[str, Any]:
    if not isinstance(source, Mapping):
        return {"present": False}
    clean = _clean_source(source)
    payload = {
        "type": clean["type"],
        "host": _merge_host(clean["url"]),
        "mode": clean["mode"],
        "selectorPresent": bool(clean["selector"]),
        "titleSelectorPresent": bool(clean["titleSelector"]),
        "linkSelectorPresent": bool(clean["linkSelector"]),
        "includePresent": bool(clean["include"]),
        "excludePresent": bool(clean["exclude"]),
        "threshold": clean["threshold"],
        "ignoreNumbers": clean["ignoreNumbers"],
    }
    return {
        "present": True,
        **payload,
        "fingerprint": hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest(),
    }


def _three_way_classification(baseline: Any, local: Any, incoming: Any) -> str:
    """Classify one semantic value against the accepted baseline.

    The names deliberately describe people rather than storage locations. A
    converged value means the curator and recipient independently reached the
    same value, so the baseline can advance without a conflict decision.
    """
    if local == baseline and incoming == baseline:
        return "unchanged"
    if local == baseline and incoming != baseline:
        return "curatorOnly"
    if incoming == baseline and local != baseline:
        return "recipientOnly"
    if local == incoming:
        return "agreed"
    return "conflicts"


def _trust_continuity(origin: Mapping[str, Any], provenance: Mapping[str, Any]) -> dict[str, Any]:
    previous = str(origin.get("signatureState") or "legacy")
    incoming = str(provenance.get("signatureState") or "legacy")
    if previous == "verified" and incoming == "verified":
        same = origin.get("algorithm") == provenance.get("algorithm") and origin.get("keyId") == provenance.get("keyId")
        return {
            "state": "same-key" if same else "key-change",
            "requiresAcknowledgement": not same,
            "message": "The same signing key signed this copy." if same else "This copy uses a different signing key. Its signature is valid, but ProgRSS cannot know why the key changed.",
        }
    if previous == "verified" and incoming != "verified":
        return {
            "state": "signed-to-unsigned", "requiresAcknowledgement": True,
            "message": "The local copy was signed, but this copy is not. Updating would accept a loss of signer continuity.",
        }
    if previous != "verified" and incoming == "verified":
        return {"state": "newly-signed", "requiresAcknowledgement": False, "message": "This copy adds a valid signature where the earlier local copy had none."}
    if previous == "legacy" or incoming == "legacy":
        return {"state": "legacy", "requiresAcknowledgement": False, "message": "At least one copy uses the older format without signature continuity."}
    return {"state": "unsigned", "requiresAcknowledgement": False, "message": "Both copies are unsigned; their checked content digests still distinguish exact contents."}


def _publication_matches(state: Mapping[str, Any], publication_id: str) -> list[dict[str, Any]]:
    matches: list[dict[str, Any]] = []
    for collection in state.get("collections") or []:
        if not isinstance(collection, Mapping):
            continue
        origin = _normalize_origin(collection.get("sharedFolderOrigin"))
        if origin and origin.get("publicationId") == publication_id:
            matches.append({"collection": collection, "origin": origin})
    return matches


def _choose_publication_match(matches: Sequence[Mapping[str, Any]], selector: str = "") -> Mapping[str, Any] | None:
    if not selector:
        return matches[0] if len(matches) == 1 else None
    exact_id = [row for row in matches if str(row["collection"].get("id")) == selector]
    if len(exact_id) == 1:
        return exact_id[0]
    folded = selector.casefold()
    exact_title = [row for row in matches if _text(row["collection"].get("title"), 180).casefold() == folded]
    if len(exact_title) == 1:
        return exact_title[0]
    return None


def _find_existing_source(
    sources: Sequence[Mapping[str, Any]], recipe: Mapping[str, Any], planned: Mapping[tuple[Any, ...], Mapping[str, Any]],
) -> Mapping[str, Any] | None:
    key = _source_acquisition_key(recipe)
    if key in planned:
        return planned[key]
    for source in sources:
        if source.get("archivedAt") or source.get("type") != recipe.get("type"):
            continue
        try:
            if recipe.get("type") == "rss" and recipe.get("url") in _source_aliases(source):
                return source
            if recipe.get("type") == "page" and _page_key(source) == _page_key(recipe):
                return source
        except (RelayError, TypeError, ValueError):
            continue
    return None


def import_bundle(
    state: Mapping[str, Any], bundle: Mapping[str, Any], folder_selector: str = "",
    *, now: str = "",
) -> tuple[dict[str, Any], dict[str, Any]]:
    full_bundle = _connected_bundle(validate_bundle(copy.deepcopy(dict(bundle))))
    bundle, selection = select_bundle_section(full_bundle, folder_selector)
    independent_excerpt = bool(selection["independentExcerpt"])
    updated = copy.deepcopy(dict(state))
    current_sources = updated.setdefault("sources", [])
    current_collections = updated.setdefault("collections", [])
    if not isinstance(current_sources, list) or not isinstance(current_collections, list):
        raise RelayError("The workspace source or folder list is malformed.")
    occupied = {str(row.get("id")) for row in [*current_sources, *current_collections] if isinstance(row, Mapping) and row.get("id")}
    rss_by_url: dict[str, Mapping[str, Any]] = {}
    for row in current_sources:
        if not isinstance(row, Mapping) or row.get("type") != "rss" or row.get("archivedAt"):
            continue
        for address in _source_aliases(row):
            rss_by_url.setdefault(address, row)
    page_by_key = {
        _page_key(row): row
        for row in current_sources
        if isinstance(row, Mapping) and row.get("type") == "page" and not row.get("archivedAt")
    }
    id_map: dict[str, str] = {}
    source_map: list[dict[str, Any]] = []
    collection_map: list[dict[str, str]] = []
    new_sources: list[dict[str, Any]] = []
    reused = 0
    duplicate_in_file = 0
    planned_rss: dict[str, Mapping[str, Any]] = {}
    planned_pages: dict[tuple[Any, ...], Mapping[str, Any]] = {}
    now = str(now or _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"))
    provenance = bundle_provenance(full_bundle)
    if not provenance.get("publicationId"):
        provenance["publicationId"] = str(bundle.get("root") or "")
    for source in bundle["sources"]:
        if source["type"] == "rss":
            key: str | tuple[Any, ...] = source["url"]
            existing = rss_by_url.get(str(key))
            planned_source = planned_rss.get(str(key))
        else:
            key = _page_key(source)
            existing = page_by_key.get(key)
            planned_source = planned_pages.get(key)
        if existing is not None:
            local_id = str(existing["id"])
            id_map[source["id"]] = local_id
            source_map.append({"remoteId": source["id"], "localId": local_id, "created": False})
            reused += 1
            continue
        if planned_source is not None:
            local_id = str(planned_source["id"])
            id_map[source["id"]] = local_id
            source_map.append({"remoteId": source["id"], "localId": local_id, "created": False})
            duplicate_in_file += 1
            continue
        new_id = _unique_id(source["id"], occupied, canonical_json(source), "shared")
        id_map[source["id"]] = new_id
        source_map.append({"remoteId": source["id"], "localId": new_id, "created": True})
        added = copy.deepcopy(source)
        added.update(
            id=new_id, enabled=False, createdAt=now,
            origin="shared-folder-section" if independent_excerpt else "shared-folder",
            lastScan="", lastError="", lastSuccessfulAt="", lastNewAt="", lastProblemAt="", lastProblem="",
        )
        new_sources.append(added)
        if source["type"] == "rss":
            planned_rss[str(key)] = added
        else:
            planned_pages[key] = added
    for collection in bundle["collections"]:
        local_id = _unique_id(collection["id"], occupied, canonical_json(collection), "folder")
        id_map[collection["id"]] = local_id
        collection_map.append({"remoteId": collection["id"], "localId": local_id})
    if len(current_sources) + len(new_sources) > MAX_WORKSPACE_SOURCES:
        room = max(0, MAX_WORKSPACE_SOURCES - len(current_sources))
        raise RelayError(f"The workspace has room for {room} more source(s), but this folder would add {len(new_sources)}.")
    if len(current_collections) + len(bundle["collections"]) > MAX_WORKSPACE_COLLECTIONS:
        room = max(0, MAX_WORKSPACE_COLLECTIONS - len(current_collections))
        raise RelayError(f"The workspace has room for {room} more folder(s), but this file would add {len(bundle['collections'])}.")
    baseline = None if independent_excerpt else _make_baseline(bundle, source_map, collection_map)
    origin = None if independent_excerpt else _make_origin(provenance, now, baseline)
    new_collections: list[dict[str, Any]] = []
    for collection in bundle["collections"]:
        members = _unique_members(
            preserve_reason(member, {"kind": member["kind"], "id": id_map[member["id"]]})
            if member["kind"] == "source" else {"kind": member["kind"], "id": id_map[member["id"]]}
            for member in collection["members"]
        )
        added = copy.deepcopy(collection)
        added["id"] = id_map[collection["id"]]
        added["members"] = members
        if collection["id"] == bundle["root"] and origin is not None:
            added["sharedFolderOrigin"] = origin
        new_collections.append(added)
    current_sources.extend(new_sources)
    current_collections.extend(new_collections)
    if isinstance(updated.get("_revision"), int):
        updated["_revision"] += 1
    updated["sharedFolderUpdateUndo"] = None
    summary = {
        "title": bundle.get("title") or "Shared folder", "rootId": id_map[str(bundle["root"])],
        "newSources": len(new_sources), "reusedSources": reused, "duplicateInFileSources": duplicate_in_file,
        "folders": len(new_collections), "pageWatches": sum(1 for row in bundle["sources"] if row["type"] == "page"),
        "feeds": sum(1 for row in bundle["sources"] if row["type"] == "rss"),
        "sourceNoteCount": sum(
            1 for collection in bundle["collections"] for member in collection.get("members", [])
            if member.get("kind") == "source" and normalize_reason(member.get("reason")) is not None
        ),
        "selectionMode": selection["selectionMode"],
        "selectedFolderId": selection["selectedFolderId"],
        "selectedFolderPath": selection["selectedFolderPath"],
        "independentExcerpt": independent_excerpt,
        "updateLinked": not independent_excerpt,
        "parentTitle": selection["parentTitle"],
        "fullSourceCount": selection["fullSourceCount"],
        "fullFolderCount": selection["fullFolderCount"],
        "curator": provenance.get("curator", ""), "signatureState": provenance.get("signatureState", "legacy"),
        "keyId": provenance.get("keyId", ""),
        "publicationId": "" if independent_excerpt else provenance.get("publicationId", ""),
        "parentPublicationId": provenance.get("publicationId", "") if independent_excerpt else "",
        "digest": provenance.get("digest", ""),
        "originSchema": "" if origin is None else origin.get("schema", ORIGIN_SCHEMA),
        "updateUrl": "" if independent_excerpt else provenance.get("updateUrl", ""),
        "manualUpdateCheck": False if independent_excerpt else bool(provenance.get("updateUrl")),
    }
    return updated, summary


def _plan_bundle_update(
    state: Mapping[str, Any], bundle: Mapping[str, Any], target_selector: str = "",
) -> dict[str, Any]:
    publication_id = str(bundle_provenance(bundle).get("publicationId") or bundle["root"])
    matches = _publication_matches(state, publication_id)
    base_preview: dict[str, Any] = {
        "schema": "progrss.workspace.shared-folder-update.v1", "mode": "update",
        "publicationId": publication_id, "title": bundle.get("title") or "Shared folder",
        "sources": len(bundle["sources"]), "feeds": sum(1 for row in bundle["sources"] if row["type"] == "rss"),
        "pageWatches": sum(1 for row in bundle["sources"] if row["type"] == "page"), "folders": len(bundle["collections"]),
        "localCopies": [{"rootId": str(row["collection"].get("id")), "title": _text(row["collection"].get("title"), 180), "originSchema": row["origin"]["schema"]} for row in matches],
        "networkRequests": 0, "writes": False,
    }
    if not matches:
        return {"preview": {**base_preview, "mode": "not-imported", "canUpdate": False, "reason": "No imported local copy of this publication was found. Use import-bundle to add it separately."}}
    selected = _choose_publication_match(matches, target_selector)
    if selected is None:
        reason = "More than one local folder has this publication identity. Choose one with --folder, keep the local copies, or import this copy separately." if len(matches) > 1 else "The selected local publication folder was not found."
        return {"preview": {**base_preview, "mode": "ambiguous" if len(matches) > 1 else "not-found", "canUpdate": False, "reason": reason}}
    target = selected["collection"]
    origin = selected["origin"]
    provenance = bundle_provenance(bundle)
    trust = _trust_continuity(origin, provenance)
    preview: dict[str, Any] = {
        **base_preview, "targetRootId": str(target.get("id")), "localTitle": _text(target.get("title"), 180),
        "curator": provenance.get("curator", ""), "note": provenance.get("note", ""),
        "issuedAt": provenance.get("issuedAt", ""), "digest": provenance.get("digest", ""),
        "signatureState": provenance.get("signatureState", "legacy"), "algorithm": provenance.get("algorithm", ""),
        "keyId": provenance.get("keyId", ""), "fingerprint": _compact_fingerprint(str(provenance.get("keyId", ""))),
        "updateUrl": provenance.get("updateUrl", ""), "manualUpdateCheck": bool(provenance.get("updateUrl")),
        "previous": {
            "curator": origin.get("curator", ""), "note": origin.get("note", ""), "issuedAt": origin.get("issuedAt", ""),
            "digest": origin.get("digest", ""), "signatureState": origin.get("signatureState", "legacy"),
            "algorithm": origin.get("algorithm", ""), "keyId": origin.get("keyId", ""),
            "fingerprint": _compact_fingerprint(str(origin.get("keyId", ""))),
            "updateUrl": origin.get("updateUrl", ""),
        },
        "trust": trust, "requiresTrustAcknowledgement": bool(trust["requiresAcknowledgement"]),
    }
    if not origin.get("baseline"):
        return {"preview": {**preview, "mode": "older-local-copy", "canUpdate": False, "reason": "This folder was imported before ProgRSS stored a safe update baseline. Import the new copy separately rather than overwriting local edits."}}
    baseline = origin["baseline"]
    if baseline["root"] != bundle["root"]:
        return {"preview": {**preview, "mode": "root-changed", "canUpdate": False, "reason": "This copy changes the publication’s top-level folder identity. Import it separately."}}
    try:
        prior_time = _dt.datetime.fromisoformat(str(origin.get("issuedAt") or "").replace("Z", "+00:00"))
        incoming_time = _dt.datetime.fromisoformat(str(provenance.get("issuedAt") or "").replace("Z", "+00:00"))
    except ValueError:
        prior_time = incoming_time = None
    if prior_time and incoming_time and incoming_time < prior_time:
        return {"preview": {**preview, "mode": "older-copy", "canUpdate": False, "reason": "This copy was issued before the copy already imported here. ProgRSS will not roll a publication backward."}}
    if prior_time and incoming_time and incoming_time == prior_time and origin.get("digest") and provenance.get("digest") and origin["digest"] != provenance["digest"]:
        return {"preview": {**preview, "mode": "conflicting-copy", "canUpdate": False, "reason": "This copy has the same issue time as the local publication but different contents. Import it separately while the conflict is investigated."}}

    old_sources = {row["id"]: row for row in baseline["sources"]}
    old_collections = {row["id"]: row for row in baseline["collections"]}
    old_source_rows = {row["remoteId"]: row for row in baseline["sourceMap"]}
    old_collection_rows = {row["remoteId"]: row for row in baseline["collectionMap"]}
    current_sources = [row for row in state.get("sources") or [] if isinstance(row, Mapping)]
    current_collections = [row for row in state.get("collections") or [] if isinstance(row, Mapping)]
    source_by_id = {str(row.get("id")): row for row in current_sources}
    collection_by_id = {str(row.get("id")): row for row in current_collections}
    old_source_local = {row["remoteId"]: row["localId"] for row in baseline["sourceMap"]}
    old_collection_local = {row["remoteId"]: row["localId"] for row in baseline["collectionMap"]}
    incoming_folder_paths = {
        str(row.get("id") or ""): str(row.get("path") or "")
        for row in bundle_contents(bundle).get("folders", [])
        if isinstance(row, Mapping)
    }
    if old_collection_local.get(baseline["root"]) != str(target.get("id")):
        return {"preview": {**preview, "mode": "mapping-changed", "canUpdate": False, "reason": "The stored publication map no longer points to this local top-level folder."}}
    for row in baseline["collectionMap"]:
        local = collection_by_id.get(row["localId"])
        if local is None:
            return {"preview": {**preview, "mode": "local-folder-missing", "canUpdate": False, "reason": "A folder from the imported publication was removed locally. ProgRSS will not recreate that deliberate deletion automatically."}}
        if str(local.get("mode") or "union") != "union" or _text(local.get("include"), 280) or _text(local.get("exclude"), 280):
            return {"preview": {**preview, "mode": "advanced-local-fork", "canUpdate": False, "reason": "A folder in this publication now uses Advanced Workbench rules. Import the new copy separately."}}

    merge_groups: dict[str, list[dict[str, Any]]] = {
        "curatorOnly": [], "recipientOnly": [], "agreed": [], "conflicts": [],
        "additions": [], "removals": [], "recipeChanges": [],
    }
    merge_counts = {key: 0 for key in merge_groups}
    merge_omitted = {key: 0 for key in merge_groups}
    conflict_operations: dict[str, dict[str, Any]] = {}

    def record_merge(group: str, entry: Mapping[str, Any], *, limit: int | None = None) -> None:
        merge_counts[group] += 1
        row_limit = 400 if group == "conflicts" else (MAX_MERGE_REVIEW_ROWS if limit is None else limit)
        if len(merge_groups[group]) < row_limit:
            merge_groups[group].append(dict(entry))
        else:
            merge_omitted[group] += 1

    def field_change(
        *, kind: str, remote_id: str, local_id: str, label: str, field: str,
        field_label: str, baseline_value: Any, local_value: Any, incoming_value: Any,
        allow_conflict_choice: bool = True, owner_note: str = "",
        force_local_ownership: bool = False,
    ) -> str:
        classification = _three_way_classification(baseline_value, local_value, incoming_value)
        if classification == "unchanged":
            return classification
        change_id = f"{kind}:{remote_id}:{field}"
        entry = {
            "id": change_id,
            "kind": kind,
            "label": _text(label, 180) or ("Untitled source" if kind == "source" else "Untitled folder"),
            "field": field,
            "fieldLabel": field_label,
            "baseline": baseline_value,
            "local": local_value,
            "incoming": incoming_value,
            "ownerNote": _text(owner_note, 240),
        }
        if force_local_ownership and classification != "agreed":
            classification = "recipientOnly"
            entry.update({
                "default": "keep-local",
                "summary": f"The curator changed {field_label.lower()}, but this pre-existing local source keeps its own value.",
                "policy": "pre-existing-local-source",
            })
            record_merge(classification, entry)
            return classification
        if classification == "curatorOnly":
            entry.update({
                "default": "use-curator",
                "summary": f"Curator changed {field_label.lower()} from “{baseline_value}” to “{incoming_value}”.",
            })
        elif classification == "recipientOnly":
            entry.update({
                "default": "keep-local",
                "summary": f"You changed {field_label.lower()} from “{baseline_value}” to “{local_value}”; the curator did not change it.",
            })
        elif classification == "agreed":
            entry.update({
                "default": "already-agrees",
                "summary": f"You and the curator both changed {field_label.lower()} to “{local_value}”.",
            })
        else:
            if allow_conflict_choice:
                entry.update({
                    "default": "decision-required",
                    "summary": f"You and the curator changed {field_label.lower()} differently.",
                    "choices": ["keep-local", "use-curator"],
                })
                conflict_operations[change_id] = {
                    "kind": kind, "localId": local_id, "field": field,
                    "curatorValue": incoming_value,
                }
            else:
                classification = "recipientOnly"
                entry.update({
                    "default": "keep-local",
                    "summary": f"The curator changed {field_label.lower()}, but this pre-existing local source keeps its own value.",
                    "policy": "pre-existing-local-source",
                })
        record_merge(classification, entry)
        return classification

    def record_membership(
        *, folder_id: str, folder_label: str, member_key: tuple[str, str], member_label: str,
        baseline_present: bool, local_present: bool, incoming_present: bool,
    ) -> None:
        classification = _three_way_classification(baseline_present, local_present, incoming_present)
        if classification == "unchanged":
            return
        action = "included" if incoming_present else "removed"
        local_action = "included" if local_present else "removed"
        kind, member_id = member_key
        entry = {
            "id": f"folder:{folder_id}:member:{kind}:{member_id}",
            "kind": "folder-membership",
            "label": _text(folder_label, 180) or "Untitled folder",
            "field": "members",
            "fieldLabel": "Folder placement",
            "memberKind": "source" if "source" in kind else "folder",
            "memberLabel": _text(member_label, 180) or ("Untitled source" if kind == "source" else "Untitled folder"),
            "baseline": baseline_present,
            "local": local_present,
            "incoming": incoming_present,
        }
        if classification == "curatorOnly":
            entry.update({"default": "use-curator", "summary": f"Curator {action} {entry['memberLabel']} in {entry['label']}."})
        elif classification == "recipientOnly":
            entry.update({"default": "keep-local", "summary": f"You {local_action} {entry['memberLabel']} in {entry['label']}; that local placement stays."})
        elif classification == "agreed":
            entry.update({"default": "already-agrees", "summary": f"You and the curator both {local_action} {entry['memberLabel']} in {entry['label']}."})
        else:
            # Membership is boolean, so a genuine divergent value cannot occur
            # against one baseline. Keep the defensive branch explicit.
            entry.update({"default": "keep-local", "summary": f"Folder placement for {entry['memberLabel']} differs; the local placement stays."})
            classification = "recipientOnly"
        record_merge(classification, entry)

    def record_source_note(
        *, folder_remote_id: str, folder_local_id: str, folder_label: str,
        source_remote_id: str, source_local_id: str, source_label: str,
        baseline_value: str | None, local_value: str | None, incoming_value: str | None,
    ) -> str:
        classification = _three_way_classification(baseline_value, local_value, incoming_value)
        if classification == "unchanged":
            return classification
        change_id = f"placement:{folder_remote_id}:source:{source_remote_id}:reason"
        folder_path = incoming_folder_paths.get(folder_remote_id) or _text(folder_label, 180) or folder_remote_id
        entry = {
            "id": change_id,
            "kind": "source-note",
            "label": _text(source_label, 180) or "Untitled source",
            "folderLabel": _text(folder_label, 180) or "Untitled folder",
            "folderPath": folder_path,
            "field": "reason",
            "fieldLabel": "Reason for this source in this folder",
            "baseline": baseline_value,
            "local": local_value,
            "incoming": incoming_value,
            "placement": {
                "folderId": folder_remote_id,
                "sourceId": source_remote_id,
                "folderPath": folder_path,
            },
        }
        if classification == "curatorOnly":
            entry.update({
                "default": "use-curator",
                "summary": "The curator changed the reason on this direct folder-to-source placement.",
            })
        elif classification == "recipientOnly":
            entry.update({
                "default": "keep-local",
                "summary": "You changed the reason on this placement; the curator did not, so yours stays.",
            })
        elif classification == "agreed":
            entry.update({
                "default": "already-agrees",
                "summary": "You and the curator made the same change to this placement reason.",
            })
        else:
            entry.update({
                "default": "decision-required",
                "summary": "You and the curator changed this placement reason differently.",
                "choices": ["keep-local", "use-curator"],
            })
            conflict_operations[change_id] = {
                "kind": "placement-reason",
                "localId": folder_local_id,
                "sourceId": source_local_id,
                "field": "reason",
                "curatorValue": incoming_value,
            }
        record_merge(classification, entry)
        return classification

    if origin.get("curator", "") != provenance.get("curator", ""):
        record_merge("curatorOnly", {
            "id": "publication:curator", "kind": "publication", "label": preview["title"],
            "field": "curator", "fieldLabel": "Curator name", "baseline": origin.get("curator", ""),
            "local": origin.get("curator", ""), "incoming": provenance.get("curator", ""),
            "default": "use-curator", "summary": "Curator wording changed in this copy.",
        })
    if origin.get("note", "") != provenance.get("note", ""):
        record_merge("curatorOnly", {
            "id": "publication:note", "kind": "publication", "label": preview["title"],
            "field": "note", "fieldLabel": "Curator note", "baseline": origin.get("note", ""),
            "local": origin.get("note", ""), "incoming": provenance.get("note", ""),
            "default": "use-curator", "summary": "The curator changed the route explanation.",
        })
    if str(origin.get("updateUrl") or "") != str(provenance.get("updateUrl") or ""):
        record_merge("curatorOnly", {
            "id": "publication:update-url", "kind": "publication", "label": preview["title"],
            "field": "updateUrl", "fieldLabel": "Future-copy address",
            "baseline": _merge_host(origin.get("updateUrl")), "local": _merge_host(origin.get("updateUrl")),
            "incoming": _merge_host(provenance.get("updateUrl")), "default": "use-curator",
            "summary": "The curator changed where later copies can be checked; ProgRSS will use it only after an explicit check.",
        })

    occupied = {str(row.get("id")) for row in [*current_sources, *current_collections] if row.get("id")}
    planned: dict[tuple[Any, ...], Mapping[str, Any]] = {}
    next_source_local: dict[str, str] = {}
    next_source_rows: list[dict[str, Any]] = []
    source_adds: list[dict[str, Any]] = []
    source_patches: list[dict[str, Any]] = []
    source_recipes_changed = source_metadata_changed = changed_recipe_new_sources = sources_added = 0
    local_source_overrides = reused_local_sources = reused_source_labels_preserved = 0
    now = _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    for incoming in bundle["sources"]:
        prior = old_sources.get(incoming["id"])
        prior_row = old_source_rows.get(incoming["id"])
        if prior and prior_row and _source_acquisition_key(prior) == _source_acquisition_key(incoming):
            local = source_by_id.get(prior_row["localId"])
            if local is None:
                return {"preview": {**preview, "mode": "local-source-missing", "canUpdate": False, "reason": "A source from the imported publication is no longer present locally. ProgRSS will not recreate that deletion automatically."}}
            local_portable = _portable_source(local, incoming["id"])
            next_source_local[incoming["id"]] = prior_row["localId"]
            next_source_rows.append({"remoteId": incoming["id"], "localId": prior_row["localId"], "created": bool(prior_row["created"])})
            metadata_changed = canonical_json(prior) != canonical_json(incoming)
            if metadata_changed:
                source_metadata_changed += 1
            unchanged_locally = canonical_json(local_portable) == canonical_json(prior)
            if not unchanged_locally:
                local_source_overrides += 1
            if prior_row["created"]:
                title_class = field_change(
                    kind="source", remote_id=incoming["id"], local_id=prior_row["localId"],
                    label=local_portable["title"], field="title", field_label="Source name",
                    baseline_value=prior["title"], local_value=local_portable["title"], incoming_value=incoming["title"],
                )
                author_class = field_change(
                    kind="source", remote_id=incoming["id"], local_id=prior_row["localId"],
                    label=local_portable["title"], field="author", field_label="Source attribution",
                    baseline_value=prior["author"], local_value=local_portable["author"], incoming_value=incoming["author"],
                )
                changes: dict[str, Any] = {}
                if title_class == "curatorOnly":
                    changes["title"] = incoming["title"]
                if author_class == "curatorOnly":
                    changes["author"] = incoming["author"]
                if local_portable["version"] == prior["version"] and incoming["version"] != prior["version"]:
                    changes["version"] = incoming["version"]
                if changes:
                    source_patches.append({"localId": prior_row["localId"], "changes": changes})
            else:
                before = merge_counts["recipientOnly"]
                field_change(
                    kind="source", remote_id=incoming["id"], local_id=prior_row["localId"],
                    label=local_portable["title"], field="title", field_label="Source name",
                    baseline_value=prior["title"], local_value=local_portable["title"], incoming_value=incoming["title"],
                    allow_conflict_choice=False, force_local_ownership=True,
                    owner_note="This source existed before the publication was added, so its local label remains local.",
                )
                field_change(
                    kind="source", remote_id=incoming["id"], local_id=prior_row["localId"],
                    label=local_portable["title"], field="author", field_label="Source attribution",
                    baseline_value=prior["author"], local_value=local_portable["author"], incoming_value=incoming["author"],
                    allow_conflict_choice=False, force_local_ownership=True,
                    owner_note="This source existed before the publication was added, so its local attribution remains local.",
                )
                if merge_counts["recipientOnly"] > before and metadata_changed:
                    reused_source_labels_preserved += 1

            if _source_acquisition_key(local_portable) != _source_acquisition_key(prior):
                record_merge("recipientOnly", {
                    "id": f"source:{incoming['id']}:local-recipe", "kind": "source", "label": local_portable["title"],
                    "field": "recipe", "fieldLabel": "How this source is checked",
                    "baseline": _recipe_evidence(prior), "local": _recipe_evidence(local_portable),
                    "incoming": _recipe_evidence(incoming), "default": "keep-local",
                    "summary": "You changed how this source is checked; the curator did not change that recipe, so your local recipe stays.",
                })
            continue
        if prior:
            source_recipes_changed += 1
        else:
            sources_added += 1
        prior_local = source_by_id.get(prior_row["localId"]) if prior_row else None
        recipe_entry: dict[str, Any] | None = None
        if prior:
            old_host = _merge_host(prior.get("url"))
            new_host = _merge_host(incoming.get("url"))
            local_recipe_changed = bool(prior_local and _source_acquisition_key(_portable_source(prior_local, incoming["id"])) != _source_acquisition_key(prior))
            recipe_entry = {
                "id": f"source:{incoming['id']}:recipe", "kind": "source", "label": incoming["title"],
                "field": "recipe", "fieldLabel": "How this source is checked",
                "baseline": _recipe_evidence(prior),
                "local": _recipe_evidence(_portable_source(prior_local, incoming["id"])) if prior_local else {"present": False},
                "incoming": _recipe_evidence(incoming),
                "oldHost": old_host, "newHost": new_host, "localRecipeChanged": local_recipe_changed,
                "default": "new-paused",
                "summary": f"Curator changed how {incoming['title']} is checked{f' from {old_host} to {new_host}' if old_host or new_host else ''}. The new recipe starts paused; earlier source history stays local.",
            }
        local = _find_existing_source(current_sources, incoming, planned)
        created = False
        if local is None:
            local_id = _unique_id(incoming["id"], occupied, canonical_json(incoming), "shared")
            local = copy.deepcopy(incoming)
            local.update(
                id=local_id, enabled=False, createdAt=now, origin="shared-folder-update",
                lastScan="", lastError="", lastSuccessfulAt="", lastNewAt="", lastProblemAt="", lastProblem="",
            )
            source_adds.append(local)
            planned[_source_acquisition_key(incoming)] = local
            created = True
            if prior:
                changed_recipe_new_sources += 1
        else:
            local_id = str(local["id"])
            reused_local_sources += 1
        if prior:
            assert recipe_entry is not None
            recipe_entry["default"] = "new-paused" if created else "reuse-existing"
            recipe_entry["reusesExisting"] = not created
            record_merge("recipeChanges", recipe_entry)
        else:
            record_merge("additions", {
                "id": f"source:{incoming['id']}:added", "kind": "source", "label": incoming["title"],
                "field": "source", "fieldLabel": "Source", "incoming": {
                    "type": incoming["type"], "host": _merge_host(incoming["url"]),
                },
                "default": "add-paused" if created else "reuse-existing",
                "summary": f"Curator added {incoming['title']}. " + ("It will start paused." if created else "An exact source already here will be reused."),
            })
        next_source_local[incoming["id"]] = local_id
        next_source_rows.append({"remoteId": incoming["id"], "localId": local_id, "created": created})
    incoming_source_ids = {row["id"] for row in bundle["sources"]}
    removed_source_rows = [row for row in baseline["sources"] if row["id"] not in incoming_source_ids]
    sources_removed = len(removed_source_rows)
    for removed in removed_source_rows:
        mapping = old_source_rows.get(removed["id"])
        local = source_by_id.get(mapping["localId"]) if mapping else None
        record_merge("removals", {
            "id": f"source:{removed['id']}:removed", "kind": "source",
            "label": _text(local.get("title") if local else removed.get("title"), 180) or "Untitled source",
            "field": "source", "fieldLabel": "Source", "baseline": {"host": _merge_host(removed.get("url")), "type": removed.get("type")},
            "local": {"present": bool(local)}, "incoming": {"present": False},
            "default": "detach-history",
            "summary": "Curator removed this source from the route. Its retained updates and local source record will not be deleted.",
        })

    next_collection_local: dict[str, str] = {}
    next_collection_rows: list[dict[str, str]] = []
    collection_adds: list[dict[str, Any]] = []
    for incoming in bundle["collections"]:
        prior_row = old_collection_rows.get(incoming["id"])
        if prior_row:
            local_id = prior_row["localId"]
        else:
            local_id = _unique_id(incoming["id"], occupied, canonical_json(incoming), "folder")
        next_collection_local[incoming["id"]] = local_id
        next_collection_rows.append({"remoteId": incoming["id"], "localId": local_id})

    source_remote_by_local = {local_id: remote_id for remote_id, local_id in old_source_local.items()}
    source_remote_by_local.update({row["localId"]: row["remoteId"] for row in next_source_rows})
    collection_remote_by_local = {local_id: remote_id for remote_id, local_id in old_collection_local.items()}
    collection_remote_by_local.update({row["localId"]: row["remoteId"] for row in next_collection_rows})
    incoming_source_by_id = {row["id"]: row for row in bundle["sources"]}
    incoming_collection_by_id = {row["id"]: row for row in bundle["collections"]}

    def semantic_local_member(member: Mapping[str, Any]) -> tuple[str, str]:
        kind = str(member.get("kind") or "")
        local_id = str(member.get("id") or "")
        if kind == "source":
            remote_id = source_remote_by_local.get(local_id)
            return ("source", remote_id) if remote_id else ("local-source", local_id)
        if kind == "collection":
            remote_id = collection_remote_by_local.get(local_id)
            return ("collection", remote_id) if remote_id else ("local-collection", local_id)
        return ("", "")

    def semantic_member_label(member_key: tuple[str, str]) -> str:
        kind, identity = member_key
        if kind == "source":
            row = incoming_source_by_id.get(identity) or old_sources.get(identity)
            return _text(row.get("title") if row else "", 180) or "Untitled source"
        if kind == "collection":
            row = incoming_collection_by_id.get(identity) or old_collections.get(identity)
            return _text(row.get("title") if row else "", 180) or "Untitled folder"
        if kind == "local-source":
            return _text(source_by_id.get(identity, {}).get("title"), 180) or "Local source"
        if kind == "local-collection":
            return _text(collection_by_id.get(identity, {}).get("title"), 180) or "Local folder"
        return "Unknown entry"

    collection_updates: list[dict[str, Any]] = []
    collection_delete_ids: list[str] = []
    folders_added = folders_changed = hierarchy_changes = local_folder_overrides = detached_local_folders = 0
    source_notes_changed = 0
    incoming_collection_ids = {row["id"] for row in bundle["collections"]}
    for incoming in bundle["collections"]:
        prior = old_collections.get(incoming["id"])
        local_id = next_collection_local[incoming["id"]]
        incoming_members = _translate_members(incoming, next_source_local, next_collection_local)
        if prior is None:
            folders_added += 1
            added = copy.deepcopy(incoming)
            added["id"] = local_id
            added["members"] = incoming_members
            collection_adds.append(added)
            record_merge("additions", {
                "id": f"folder:{incoming['id']}:added", "kind": "folder", "label": incoming["title"],
                "field": "folder", "fieldLabel": "Folder", "incoming": {"members": len(incoming.get("members") or [])},
                "default": "add-folder", "summary": f"Curator added the folder {incoming['title']}.",
            })
            continue
        current = collection_by_id[local_id]
        baseline_members = _translate_members(prior, old_source_local, old_collection_local)
        current_meaning = _collection_meaning(current)
        baseline_meaning = _collection_meaning(prior, baseline_members)
        incoming_meaning = _collection_meaning(incoming, incoming_members)
        field_change(
            kind="folder", remote_id=incoming["id"], local_id=local_id,
            label=current_meaning["title"], field="title", field_label="Folder name",
            baseline_value=baseline_meaning["title"], local_value=current_meaning["title"], incoming_value=incoming_meaning["title"],
        )
        field_change(
            kind="folder", remote_id=incoming["id"], local_id=local_id,
            label=current_meaning["title"], field="author", field_label="Folder attribution",
            baseline_value=baseline_meaning["author"], local_value=current_meaning["author"], incoming_value=incoming_meaning["author"],
        )

        baseline_semantic = {_member_key(member) for member in prior.get("members") or []}
        incoming_semantic = {_member_key(member) for member in incoming.get("members") or []}
        local_semantic = {
            semantic_local_member(member)
            for member in _unique_members(current.get("members") or [])
        }
        local_semantic.discard(("", ""))
        for member_key in sorted(baseline_semantic | local_semantic | incoming_semantic):
            record_membership(
                folder_id=incoming["id"], folder_label=current_meaning["title"],
                member_key=member_key, member_label=semantic_member_label(member_key),
                baseline_present=member_key in baseline_semantic,
                local_present=member_key in local_semantic,
                incoming_present=member_key in incoming_semantic,
            )
        local_edited = canonical_json(current_meaning) != canonical_json(baseline_meaning)
        if local_edited:
            local_folder_overrides += 1
        if canonical_json(_collection_meaning(prior)) != canonical_json(_collection_meaning(incoming)):
            folders_changed += 1
        baseline_keys = {_member_key(member) for member in baseline_members}
        incoming_keys = {_member_key(member) for member in incoming_members}
        removed = baseline_keys - incoming_keys
        added_members = [member for member in incoming_members if _member_key(member) not in baseline_keys]
        final_members = [member for member in _unique_members(current.get("members") or []) if _member_key(member) not in removed]
        present = {_member_key(member) for member in final_members}
        for member in added_members:
            key = _member_key(member)
            if key not in present:
                final_members.append(dict(member))
                present.add(key)

        baseline_reasons = {
            _member_key(member): normalize_reason(member.get("reason"))
            for member in prior.get("members") or []
            if isinstance(member, Mapping) and member.get("kind") == "source"
        }
        incoming_reasons = {
            _member_key(member): normalize_reason(member.get("reason"))
            for member in incoming.get("members") or []
            if isinstance(member, Mapping) and member.get("kind") == "source"
        }
        local_reasons: dict[tuple[str, str], str | None] = {}
        for member in _unique_members(current.get("members") or []):
            semantic_key = semantic_local_member(member)
            if semantic_key[0] == "source":
                local_reasons[semantic_key] = normalize_reason(member.get("reason"))
        final_by_key = {_member_key(member): member for member in final_members}
        for semantic_key in sorted(local_semantic & incoming_semantic):
            if semantic_key[0] != "source":
                continue
            source_remote_id = semantic_key[1]
            source_local_id = next_source_local.get(source_remote_id, "")
            final_member = final_by_key.get(("source", source_local_id))
            if not source_local_id or final_member is None:
                continue
            baseline_reason = baseline_reasons.get(semantic_key)
            local_reason = local_reasons.get(semantic_key)
            incoming_reason = incoming_reasons.get(semantic_key)
            classification = record_source_note(
                folder_remote_id=incoming["id"], folder_local_id=local_id,
                folder_label=current_meaning["title"],
                source_remote_id=source_remote_id, source_local_id=source_local_id,
                source_label=semantic_member_label(semantic_key),
                baseline_value=baseline_reason, local_value=local_reason, incoming_value=incoming_reason,
            )
            if classification != "unchanged":
                source_notes_changed += 1
            selected_reason = incoming_reason if classification == "curatorOnly" else local_reason
            if classification == "agreed":
                selected_reason = local_reason
            if selected_reason is None:
                final_member.pop("reason", None)
            else:
                final_member["reason"] = selected_reason
        before_hierarchy = {_member_key(member) for member in baseline_members if member["kind"] == "collection"}
        after_hierarchy = {_member_key(member) for member in incoming_members if member["kind"] == "collection"}
        hierarchy_changes += len(before_hierarchy ^ after_hierarchy)
        final = copy.deepcopy(dict(current))
        final.update(
            title=incoming_meaning["title"] if current_meaning["title"] == baseline_meaning["title"] else current_meaning["title"],
            author=incoming_meaning["author"] if current_meaning["author"] == baseline_meaning["author"] else current_meaning["author"],
            mode="union", include="", exclude="", members=final_members,
        )
        if canonical_json(_collection_meaning(final)) != canonical_json(current_meaning):
            final["version"] = min(10_000, max(int(current.get("version") or 1), int(incoming.get("version") or 1)) + 1)
        collection_updates.append(final)
    removed_collections: list[dict[str, Any]] = []
    for prior in baseline["collections"]:
        if prior["id"] in incoming_collection_ids or prior["id"] == baseline["root"]:
            continue
        local_id = old_collection_local[prior["id"]]
        current = collection_by_id.get(local_id)
        if current is None:
            continue
        baseline_members = _translate_members(prior, old_source_local, old_collection_local)
        locally_changed = canonical_json(_collection_meaning(current)) != canonical_json(_collection_meaning(prior, baseline_members))
        removed_collections.append({"localId": local_id, "current": current, "locallyChanged": locally_changed})
        record_merge("removals", {
            "id": f"folder:{prior['id']}:removed", "kind": "folder",
            "label": _text(current.get("title"), 180) or _text(prior.get("title"), 180) or "Untitled folder",
            "field": "folder", "fieldLabel": "Folder", "baseline": {"present": True},
            "local": {"present": True, "changed": locally_changed}, "incoming": {"present": False},
            "default": "keep-local-folder" if locally_changed else "remove-folder",
            "summary": (
                "Curator removed this folder, but your local changes keep it as a detached local folder."
                if locally_changed else
                "Curator removed this unchanged folder from the route."
            ),
        })
    removed_local_ids = {row["localId"] for row in removed_collections}
    final_collection_by_id = {str(collection.get("id")): collection for collection in current_collections}
    final_collection_by_id.update({str(collection.get("id")): collection for collection in collection_updates})
    final_collection_by_id.update({str(collection.get("id")): collection for collection in collection_adds})
    keep_removed = {row["localId"] for row in removed_collections if row["locallyChanged"]}
    for local_id, collection in final_collection_by_id.items():
        if local_id in removed_local_ids:
            continue
        for member in collection.get("members") or []:
            if isinstance(member, Mapping) and member.get("kind") == "collection" and str(member.get("id")) in removed_local_ids:
                keep_removed.add(str(member.get("id")))
    grew = True
    while grew:
        grew = False
        for local_id in list(keep_removed):
            collection = final_collection_by_id.get(local_id) or {}
            for member in collection.get("members") or []:
                child = str(member.get("id")) if isinstance(member, Mapping) and member.get("kind") == "collection" else ""
                if child in removed_local_ids and child not in keep_removed:
                    keep_removed.add(child)
                    grew = True
    for row in removed_collections:
        if row["localId"] in keep_removed:
            detached_local_folders += 1
        else:
            collection_delete_ids.append(row["localId"])
    folders_removed = sum(1 for row in baseline["collections"] if row["id"] not in incoming_collection_ids)
    root_update = next((row for row in collection_updates if str(row.get("id")) == str(target.get("id"))), None)
    if root_update is None:
        root_update = next((row for row in collection_adds if str(row.get("id")) == str(target.get("id"))), None)
    if root_update is None:
        return {"preview": {**preview, "mode": "root-missing", "canUpdate": False, "reason": "The new copy no longer contains the publication’s top-level folder."}}
    baseline_next = _make_baseline(bundle, next_source_rows, next_collection_rows)
    root_update["sharedFolderOrigin"] = _make_origin(provenance, now, baseline_next, origin)
    attribution_changed = origin.get("curator", "") != provenance.get("curator", "") or origin.get("note", "") != provenance.get("note", "")
    signer_changed = trust["state"] in {"key-change", "signed-to-unsigned", "newly-signed"}
    update_address_changed = str(origin.get("updateUrl") or "") != str(provenance.get("updateUrl") or "")
    digest_changed = bool(origin.get("digest") and provenance.get("digest") and origin.get("digest") != provenance.get("digest"))
    semantic_changed = any((digest_changed, sources_added, sources_removed, source_recipes_changed, source_metadata_changed, folders_added, folders_removed, folders_changed, attribution_changed, signer_changed, update_address_changed))
    source_room = max(0, MAX_WORKSPACE_SOURCES - len(current_sources))
    folder_room = max(0, MAX_WORKSPACE_COLLECTIONS - (len(current_collections) - len(collection_delete_ids)))
    reason = ""
    if len(source_adds) > source_room:
        reason = f"The workspace has room for {source_room} more source(s), but this update needs {len(source_adds)}."
    elif len(collection_adds) > folder_room:
        reason = f"The workspace has room for {folder_room} more folder(s), but this update needs {len(collection_adds)}."
    already_current = not semantic_changed and bool(origin.get("digest")) and origin.get("digest") == provenance.get("digest")
    changes = {
        "sourcesAdded": sources_added, "sourcesRemoved": sources_removed,
        "sourceRecipesChanged": source_recipes_changed, "sourceMetadataChanged": source_metadata_changed,
        "newLocalSources": len(source_adds), "reusedLocalSources": reused_local_sources,
        "reusedSourceLabelsPreserved": reused_source_labels_preserved,
        "foldersAdded": folders_added, "foldersRemoved": folders_removed, "foldersChanged": folders_changed,
        "hierarchyChanges": hierarchy_changes, "sourceNotesChanged": source_notes_changed,
        "attributionChanged": attribution_changed, "signerChanged": signer_changed,
        "updateAddressChanged": update_address_changed,
    }
    merge_review = {
        "schema": MERGE_REVIEW_SCHEMA,
        "counts": dict(merge_counts),
        **merge_groups,
        "omitted": {key: value for key, value in merge_omitted.items() if value},
        "requiresDecisions": bool(merge_counts["conflicts"]),
        "decisionIds": sorted(conflict_operations),
        "recipeAcknowledgementRequired": bool(merge_counts["recipeChanges"]),
        "network": False,
        "writes": False,
    }
    update_preview = {
        **preview, "mode": "current" if already_current else "update", "canUpdate": not reason and not already_current,
        "reason": "This local folder already matches this shared copy." if already_current else reason,
        "alreadyCurrent": already_current, "changes": changes,
        "mergeReview": merge_review,
        "requiresConflictChoices": bool(merge_counts["conflicts"]),
        "requiresRecipeAcknowledgement": bool(merge_counts["recipeChanges"]),
        "localEdits": {
            "sourceOverrides": local_source_overrides, "folderOverrides": local_folder_overrides,
            "detachedFolders": detached_local_folders,
            "present": bool(local_source_overrides or local_folder_overrides or detached_local_folders),
        },
        "preservation": {
            "readingHistory": True, "readAndSavedState": True, "sourceActivity": True,
            "removedSourceHistoriesRetained": sources_removed, "changedRecipesStartPaused": changed_recipe_new_sources,
            "localEditsKept": True,
        },
        "warnings": [
            *(["Changed acquisition recipes become paused sources; earlier source histories remain in the backup."] if source_recipes_changed else []),
            *(["Sources removed from the publication are detached from unchanged publication folders; retained updates are not deleted."] if sources_removed else []),
        ],
    }
    return {
        "preview": update_preview, "targetRootId": str(target.get("id")), "sourceAdds": source_adds,
        "sourcePatches": source_patches, "collectionAdds": collection_adds,
        "collectionUpdates": collection_updates, "collectionDeleteIds": collection_delete_ids,
        "conflictOperations": conflict_operations,
    }


def review_bundle_update(state: Mapping[str, Any], bundle: Mapping[str, Any], target_selector: str = "") -> dict[str, Any]:
    return _plan_bundle_update(state, bundle, target_selector)["preview"]


def update_bundle(
    state: Mapping[str, Any], bundle: Mapping[str, Any], target_selector: str = "", *,
    accept_trust_change: bool = False,
    conflict_policy: str = "",
    conflict_decisions: Mapping[str, str] | None = None,
    acknowledge_recipe_change: bool = False,
) -> tuple[dict[str, Any], dict[str, Any]]:
    plan = _plan_bundle_update(state, bundle, target_selector)
    preview = plan["preview"]
    if not preview.get("canUpdate"):
        raise RelayError(str(preview.get("reason") or "This shared folder cannot be updated safely."))
    if preview.get("requiresTrustAcknowledgement") and not accept_trust_change:
        raise RelayError("The signing-key continuity changed. Re-run with --accept-trust-change only after reviewing that change.")
    conflicts = plan.get("conflictOperations") or {}
    decisions = dict(conflict_decisions or {})
    unknown_decisions = sorted(set(decisions) - set(conflicts))
    if unknown_decisions:
        raise RelayError(f"A conflict decision is stale or unknown: {unknown_decisions[0]}")
    resolved_choices: dict[str, str] = {}
    for conflict_id in sorted(conflicts):
        choice = decisions.get(conflict_id) or conflict_policy
        if choice not in {"keep-local", "use-curator"}:
            raise RelayError(
                "This update has divergent local and curator changes. Give every conflict an explicit "
                "--conflict ID=keep-local or --conflict ID=use-curator decision after reviewing it; "
                "the legacy --resolve-conflicts choice remains available only as an explicit bulk decision."
            )
        resolved_choices[conflict_id] = choice
    if preview.get("requiresRecipeAcknowledgement") and not acknowledge_recipe_change:
        raise RelayError("This update changes how one or more sources are checked. Re-run with --accept-recipe-changes after reviewing the old and new hosts and paused-source consequence.")
    updated = copy.deepcopy(dict(state))
    sources = updated.setdefault("sources", [])
    collections = updated.setdefault("collections", [])
    sources.extend(copy.deepcopy(plan["sourceAdds"]))
    source_by_id = {str(row.get("id")): row for row in sources if isinstance(row, MutableMapping)}
    for patch in plan["sourcePatches"]:
        source = source_by_id.get(patch["localId"])
        if source is None:
            raise RelayError("A source changed while the update was being applied.")
        for key, value in (patch.get("changes") or {}).items():
            if key in {"title", "author", "version"}:
                source[key] = value
    changed_conflict_sources: set[str] = set()
    for conflict_id, operation in conflicts.items():
        if resolved_choices.get(conflict_id) != "use-curator" or operation.get("kind") != "source":
            continue
        local_id = str(operation.get("localId") or "")
        source = source_by_id.get(local_id)
        if source is None:
            raise RelayError("A conflicted source changed while the update was being applied.")
        field = str(operation.get("field") or "")
        if field not in {"title", "author"}:
            raise RelayError("The reviewed source conflict is no longer supported.")
        source[field] = operation.get("curatorValue")
        changed_conflict_sources.add(local_id)
    for local_id in changed_conflict_sources:
        source = source_by_id[local_id]
        source["version"] = min(10_000, max(1, int(source.get("version") or 1)) + 1)
    delete_ids = set(plan["collectionDeleteIds"])
    updates = {str(row.get("id")): copy.deepcopy(row) for row in plan["collectionUpdates"]}
    changed_conflict_folders: set[str] = set()
    for conflict_id, operation in conflicts.items():
        if resolved_choices.get(conflict_id) != "use-curator":
            continue
        kind = str(operation.get("kind") or "")
        if kind not in {"folder", "placement-reason"}:
            continue
        local_id = str(operation.get("localId") or "")
        collection = updates.get(local_id)
        if collection is None:
            raise RelayError("A conflicted folder changed while the update was being applied.")
        if kind == "folder":
            field = str(operation.get("field") or "")
            if field not in {"title", "author"}:
                raise RelayError("The reviewed folder conflict is no longer supported.")
            collection[field] = operation.get("curatorValue")
        else:
            source_id = str(operation.get("sourceId") or "")
            member = next((row for row in collection.get("members") or [] if row.get("kind") == "source" and str(row.get("id")) == source_id), None)
            if member is None:
                raise RelayError("A conflicted Source Note placement changed while the update was being applied.")
            curator_value = normalize_reason(operation.get("curatorValue"))
            if curator_value is None:
                member.pop("reason", None)
            else:
                member["reason"] = curator_value
        changed_conflict_folders.add(local_id)
    for local_id in changed_conflict_folders:
        collection = updates[local_id]
        collection["version"] = min(10_000, max(1, int(collection.get("version") or 1)) + 1)
    collections[:] = [updates.get(str(row.get("id")), row) for row in collections if str(row.get("id")) not in delete_ids]
    collections.extend(copy.deepcopy(plan["collectionAdds"]))
    for key in ("transferUndo", "sourceRepairUndo", "receiptRetirementUndo", "sharedFolderUpdateUndo"):
        if key in updated:
            updated[key] = None
    if isinstance(updated.get("_revision"), int):
        updated["_revision"] += 1
    summary = {
        **preview, "updated": True, "outputStateRevision": updated.get("_revision"),
        "conflictPolicy": conflict_policy or "per-conflict" if resolved_choices else "none-needed",
        "conflictDecisions": resolved_choices,
        "recipeChangesAcknowledged": bool(preview.get("requiresRecipeAcknowledgement")),
        "networkRequests": 0, "writes": True,
    }
    return updated, summary

def _json_print(value: Mapping[str, Any]) -> None:
    print(json.dumps(value, ensure_ascii=False, sort_keys=True))


def _compact_fingerprint(value: str) -> str:
    raw = str(value or "")
    if ":" not in raw:
        return raw
    algorithm, digest = raw.split(":", 1)
    return f"{algorithm}:{digest[:12]}…{digest[-8:]}"


def _bundle_summary(bundle: Mapping[str, Any]) -> dict[str, Any]:
    provenance = bundle_provenance(bundle)
    return {
        "schema": bundle.get("schema"),
        "title": bundle.get("title") or "Shared folder",
        "root": bundle["root"],
        "feeds": sum(1 for row in bundle["sources"] if row["type"] == "rss"),
        "pageWatches": sum(1 for row in bundle["sources"] if row["type"] == "page"),
        "folders": len(bundle["collections"]),
        "sources": len(bundle["sources"]),
        "publicationId": provenance.get("publicationId", ""),
        "curator": provenance.get("curator", ""),
        "note": provenance.get("note", ""),
        "issuedAt": provenance.get("issuedAt", ""),
        "digest": provenance.get("digest", ""),
        "signatureState": provenance.get("signatureState", "legacy"),
        "algorithm": provenance.get("algorithm", ""),
        "keyId": provenance.get("keyId", ""),
        "fingerprint": _compact_fingerprint(str(provenance.get("keyId", ""))),
        "updateUrl": provenance.get("updateUrl", ""),
        "manualUpdateCheck": bool(provenance.get("updateUrl")),
        "startsPausedOnImport": True,
        "networkRequests": 0,
        "writes": False,
    }


def bundle_contents(
    bundle: Mapping[str, Any],
    source_states: Mapping[str, str] | None = None,
    folder_states: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    """Describe one checked shared folder without exposing acquisition internals."""
    base = _connected_bundle(validate_bundle(copy.deepcopy(dict(bundle))))
    source_by_id = {row["id"]: row for row in base["sources"]}
    folder_by_id = {row["id"]: row for row in base["collections"]}
    root_id = str(base["root"])
    root = folder_by_id.get(root_id)
    if root is None:
        raise RelayError("The shared folder has no top-level folder to describe.")

    source_state = dict(source_states or {})
    folder_state = dict(folder_states or {})
    paths: dict[str, list[str]] = {root_id: [str(root["title"])]}
    folder_order: list[str] = []
    seen_folders: set[str] = set()
    queue: list[str] = [root_id]
    while queue:
        folder_id = queue.pop(0)
        if folder_id in seen_folders:
            continue
        seen_folders.add(folder_id)
        folder_order.append(folder_id)
        folder = folder_by_id[folder_id]
        parent_path = paths[folder_id]
        for member in folder.get("members", []):
            if member.get("kind") != "collection":
                continue
            child_id = str(member.get("id") or "")
            child = folder_by_id.get(child_id)
            if child is None or child_id in paths:
                continue
            paths[child_id] = [*parent_path, str(child["title"])]
            queue.append(child_id)

    # Connected validation above normally makes this fallback unreachable. It
    # keeps the report deterministic if a future supported graph has another
    # valid entry route.
    for folder in base["collections"]:
        folder_id = str(folder["id"])
        if folder_id not in paths:
            paths[folder_id] = [str(folder["title"])]
            folder_order.append(folder_id)

    source_folders: dict[str, list[str]] = {source_id: [] for source_id in source_by_id}
    source_placements: dict[str, list[dict[str, Any]]] = {source_id: [] for source_id in source_by_id}
    source_order: list[str] = []
    seen_sources: set[str] = set()
    for folder_id in folder_order:
        folder = folder_by_id[folder_id]
        route = " › ".join(paths[folder_id])
        for member in folder.get("members", []):
            if member.get("kind") != "source":
                continue
            source_id = str(member.get("id") or "")
            if source_id not in source_by_id:
                continue
            routes = source_folders[source_id]
            if route not in routes:
                routes.append(route)
            placement: dict[str, Any] = {"folderId": folder_id, "folderPath": route}
            reason = normalize_reason(member.get("reason"))
            if reason is not None:
                placement["reason"] = reason
            source_placements[source_id].append(placement)
            if source_id not in seen_sources:
                seen_sources.add(source_id)
                source_order.append(source_id)
    for source in base["sources"]:
        source_id = str(source["id"])
        if source_id not in seen_sources:
            source_order.append(source_id)

    folders: list[dict[str, Any]] = []
    branch_cache: dict[str, tuple[set[str], set[str]]] = {}

    def branch_counts(folder_id: str) -> tuple[set[str], set[str]]:
        if folder_id in branch_cache:
            collections, sources = branch_cache[folder_id]
            return set(collections), set(sources)
        collection_ids = {folder_id}
        source_ids: set[str] = set()
        for member in folder_by_id[folder_id].get("members", []):
            member_id = str(member.get("id") or "")
            if member.get("kind") == "source":
                source_ids.add(member_id)
            else:
                child_collections, child_sources = branch_counts(member_id)
                collection_ids.update(child_collections)
                source_ids.update(child_sources)
        branch_cache[folder_id] = (set(collection_ids), set(source_ids))
        return collection_ids, source_ids

    for folder_id in folder_order:
        folder = folder_by_id[folder_id]
        route_parts = paths[folder_id]
        branch_collection_ids, branch_source_ids = branch_counts(folder_id)
        branch_sources = [source_by_id[source_id] for source_id in branch_source_ids if source_id in source_by_id]
        folders.append({
            "id": folder_id,
            "title": str(folder["title"]),
            "path": " › ".join(route_parts),
            "depth": max(0, len(route_parts) - 1),
            "isRoot": folder_id == root_id,
            "directSources": sum(1 for member in folder.get("members", []) if member.get("kind") == "source"),
            "directSourceNotes": sum(
                1 for member in folder.get("members", [])
                if member.get("kind") == "source" and normalize_reason(member.get("reason")) is not None
            ),
            "directFolders": sum(1 for member in folder.get("members", []) if member.get("kind") == "collection"),
            "branchSources": len(branch_sources),
            "branchFeeds": sum(1 for source in branch_sources if source["type"] == "rss"),
            "branchPageWatches": sum(1 for source in branch_sources if source["type"] == "page"),
            "branchFolders": len(branch_collection_ids),
            "branchSourceNotes": sum(
                1
                for branch_folder_id in branch_collection_ids
                for member in folder_by_id[branch_folder_id].get("members", [])
                if member.get("kind") == "source" and normalize_reason(member.get("reason")) is not None
            ),
            "state": _text(folder_state.get(folder_id), 40) or "listed",
        })

    sources: list[dict[str, Any]] = []
    for source_id in source_order:
        source = source_by_id[source_id]
        routes = source_folders[source_id]
        placements = source_placements[source_id]
        host = urlsplit(str(source["url"])).netloc
        sources.append({
            "id": source_id,
            "title": str(source["title"]),
            "type": str(source["type"]),
            "host": host,
            "folderCount": len(routes),
            "folders": routes[:8],
            "foldersOmitted": max(0, len(routes) - 8),
            "placements": placements,
            "sourceNoteCount": sum(1 for placement in placements if placement.get("reason") is not None),
            "state": _text(source_state.get(source_id), 40) or "listed",
        })

    return {
        "schema": CONTENTS_SCHEMA,
        "title": str(base.get("title") or root["title"] or "Shared folder"),
        "root": root_id,
        "sourceCount": len(sources),
        "feedCount": sum(1 for row in sources if row["type"] == "rss"),
        "pageWatchCount": sum(1 for row in sources if row["type"] == "page"),
        "folderCount": len(folders),
        "sourceNoteCount": sum(int(row["sourceNoteCount"]) for row in sources),
        "maxDepth": max((int(row["depth"]) for row in folders), default=0),
        "sources": sources,
        "folders": folders,
        "network": False,
        "writes": False,
    }


def select_bundle_section(
    bundle: Mapping[str, Any], selector: str = "",
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Select one simple folder branch as an independent local excerpt."""
    base = _connected_bundle(validate_bundle(copy.deepcopy(dict(bundle))))
    report = bundle_contents(base)
    requested = str(selector or "").strip()
    selected: Mapping[str, Any] | None = None
    if requested:
        selected = next((row for row in report["folders"] if row["id"] == requested), None)
        if selected is None:
            folded = requested.casefold()
            path_matches = [row for row in report["folders"] if str(row["path"]).casefold() == folded]
            if len(path_matches) == 1:
                selected = path_matches[0]
            elif len(path_matches) > 1:
                choices = ", ".join(str(row["id"]) for row in path_matches[:8])
                raise RelayError(f"That folder path is ambiguous. Choose an exact folder ID: {choices}")
            else:
                title_matches = [row for row in report["folders"] if str(row["title"]).casefold() == folded]
                if len(title_matches) == 1:
                    selected = title_matches[0]
                elif len(title_matches) > 1:
                    choices = ", ".join(f"{row['path']} [{row['id']}]" for row in title_matches[:8])
                    raise RelayError(f"That folder title is ambiguous. Choose a full path or ID: {choices}")
                else:
                    raise RelayError("That folder section is not present in this source list.")

    if selected is None or bool(selected.get("isRoot")):
        return base, {
            "selectionMode": "all",
            "selectedFolderId": "",
            "selectedFolderPath": "",
            "independentExcerpt": False,
            "parentTitle": "",
            "fullSourceCount": report["sourceCount"],
            "fullFolderCount": report["folderCount"],
        }
    if not int(selected.get("branchSources") or 0):
        raise RelayError("That folder section does not contain a source to add.")

    folder_by_id = {row["id"]: row for row in base["collections"]}
    collection_ids: set[str] = set()
    source_ids: set[str] = set()

    def walk(folder_id: str) -> None:
        if folder_id in collection_ids:
            return
        collection_ids.add(folder_id)
        for member in folder_by_id[folder_id]["members"]:
            if member["kind"] == "source":
                source_ids.add(member["id"])
            else:
                walk(member["id"])

    selected_id = str(selected["id"])
    walk(selected_id)
    excerpt = _connected_bundle(_validate_legacy_bundle({
        "schema": LEGACY_BUNDLE_SCHEMA,
        "exportedAt": base.get("exportedAt", ""),
        "root": selected_id,
        "title": selected["title"],
        "sources": [copy.deepcopy(row) for row in base["sources"] if row["id"] in source_ids],
        "collections": [copy.deepcopy(row) for row in base["collections"] if row["id"] in collection_ids],
    }))
    return excerpt, {
        "selectionMode": "section",
        "selectedFolderId": selected_id,
        "selectedFolderPath": str(selected["path"]),
        "independentExcerpt": True,
        "parentTitle": str(base.get("title") or "Shared folder"),
        "fullSourceCount": report["sourceCount"],
        "fullFolderCount": report["folderCount"],
    }


def _command_bundle_contents(argv: Sequence[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="progrss bundle contents",
        description="List the sources, sites, and folder routes in a checked ProgRSS source list; no network or writes.",
    )
    parser.add_argument("file", type=Path)
    parser.add_argument("--limit", type=int, default=20, choices=range(1, 101), metavar="1..100", help="maximum source and folder rows shown in human output")
    parser.add_argument("--json", action="store_true", help="emit the complete machine-readable contents report")
    args = parser.parse_args(list(argv))
    report = bundle_contents(read_bundle(args.file))
    if args.json:
        _json_print(report)
        return 0

    print(report["title"])
    print(f"  {report['sourceCount']} source(s) · {report['feedCount']} feed(s) · {report['pageWatchCount']} watched page(s) · {report['folderCount']} folder(s)")
    print("Folders")
    for row in report["folders"][: args.limit]:
        print(f"  {row['path']} — {row['branchSources']} source(s) · {row['branchFolders']} folder(s) in this section")
    if report["folderCount"] > args.limit:
        print(f"  … {report['folderCount'] - args.limit} more folder route(s)")
    print("Sources")
    for row in report["sources"][: args.limit]:
        kind = "Watched page" if row["type"] == "page" else "Feed"
        host = f" · {row['host']}" if row.get("host") else ""
        print(f"  {row['title']} — {kind}{host}")
        routes = list(row.get("folders") or [])
        if routes:
            suffix = f" · {row['foldersOmitted']} more route(s)" if row.get("foldersOmitted") else ""
            print(f"    In {' · '.join(routes)}{suffix}")
    if report["sourceCount"] > args.limit:
        print(f"  … {report['sourceCount'] - args.limit} more source(s)")
    print("Offline · no writes · no listed site contacted")
    return 0


def _command_bundle_inspect(argv: Sequence[str]) -> int:
    parser = argparse.ArgumentParser(prog="progrss bundle inspect", description="Review and verify a ProgRSS shared folder without changing a workspace.")
    parser.add_argument("file", type=Path)
    parser.add_argument("--json", action="store_true", help="print a machine-readable one-line summary")
    args = parser.parse_args(list(argv))
    bundle = read_bundle(args.file)
    summary = _bundle_summary(bundle)
    if args.json:
        _json_print(summary)
    else:
        print(summary["title"])
        print(f"  {summary['feeds']} feed(s), {summary['pageWatches']} page watch(es), {summary['folders']} folder(s)")
        if summary["signatureState"] == "verified":
            name = f" · shown as {summary['curator']}" if summary["curator"] else ""
            print(f"  Signature verified · {summary['fingerprint']}{name}")
            print("  Meaning: these exact shared-folder contents were signed by the same key; the name and sources are not independently authenticated.")
        elif summary["signatureState"] == "unsigned":
            name = f" · shown as {summary['curator']}" if summary["curator"] else ""
            print(f"  Unsigned attributed folder{name}")
        else:
            print("  Legacy Relay folder · no attribution or signature record")
        if summary["note"]:
            print(f"  Note: {summary['note']}")
        if summary.get("updateUrl"):
            print(f"  Newer copies: {summary['updateUrl']}")
            print("  Check policy: manual only; the file does not schedule polling or automatic updates.")
        print("  Import policy: matching sources are reused; new sources start paused.")
    return 0


def _command_bundle_verify(argv: Sequence[str]) -> int:
    parser = argparse.ArgumentParser(prog="progrss bundle verify", description="Verify one shared-folder digest and optional signature; no network or writes.")
    parser.add_argument("file", type=Path)
    parser.add_argument("--require-signature", action="store_true", help="exit 3 when the folder is valid but unsigned or legacy")
    parser.add_argument("--json", action="store_true", help="print a machine-readable one-line summary")
    args = parser.parse_args(list(argv))
    bundle = read_bundle(args.file)
    summary = _bundle_summary(bundle)
    signature_ok = summary["signatureState"] == "verified"
    result = {
        **summary,
        "valid": True,
        "signatureRequired": bool(args.require_signature),
        "requirementMet": signature_ok or not args.require_signature,
    }
    if args.json:
        _json_print(result)
    else:
        print(f"Valid shared folder: {summary['title']}")
        if signature_ok:
            print(f"  Signature verified · {summary['fingerprint']}")
        elif summary["signatureState"] == "unsigned":
            print("  Content digest verified · no signature supplied")
        else:
            print("  Legacy folder validated · this format has no content digest or signature")
        print("  Offline · no writes")
    return 0 if result["requirementMet"] else 3

def _command_share_folder(argv: Sequence[str]) -> int:
    parser = argparse.ArgumentParser(prog="progrss workspace share-folder", description="Export one simple folder without reading history or observations.")
    parser.add_argument("backup", type=Path, help="ProgRSS workspace backup or portable state JSON")
    parser.add_argument("folder", help="folder ID, unique title, or full folder path")
    parser.add_argument("--output", "-o", required=True, type=Path)
    parser.add_argument("--format", choices=("bundle", "opml"), default="bundle")
    parser.add_argument("--curator", default="", help="optional name or group shown in the shared file")
    parser.add_argument("--note", default="", help="optional short curation note, at most 280 characters")
    location_group = parser.add_mutually_exclusive_group()
    location_group.add_argument("--update-url", default=None, help="optional public http(s) address for a later copy; checked only on explicit request")
    location_group.add_argument("--without-update-url", dest="update_url", action="store_const", const="", help="remove a previously inherited future-copy address")
    parser.add_argument("--json", action="store_true", help="print a machine-readable summary")
    args = parser.parse_args(list(argv))
    if args.output.resolve() == args.backup.resolve():
        raise RelayError("Choose a different output path so the workspace input remains untouched.")
    if args.output.exists():
        raise RelayError("The output file already exists. Choose another path; Relay never overwrites files.")
    _, location = read_workspace(args.backup)
    bundle = make_bundle(location.state, args.folder, curator=args.curator, note=args.note, update_url=args.update_url)
    if args.format == "opml":
        payload = _opml(bundle)
        omitted = sum(1 for row in bundle["sources"] if row["type"] == "page")
    else:
        payload = (json.dumps(bundle, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
        omitted = 0
    if len(payload) > MAX_BUNDLE_BYTES and args.format == "bundle":
        raise RelayError("That shared folder is larger than the 650 KB safety limit.")
    _write_new_bytes(args.output, payload)
    source_note_placements = [
        {"folderId": collection["id"], "sourceId": member["id"]}
        for collection in bundle["collections"]
        for member in collection.get("members", [])
        if member.get("kind") == "source" and normalize_reason(member.get("reason")) is not None
    ]
    summary = {
        "output": str(args.output), "format": args.format, "title": bundle.get("title"),
        "feeds": sum(1 for row in bundle["sources"] if row["type"] == "rss"),
        "pageWatches": sum(1 for row in bundle["sources"] if row["type"] == "page"),
        "folders": len(bundle["collections"]), "omittedPageWatches": omitted,
        "schema": bundle.get("schema"), "curator": bundle_provenance(bundle).get("curator", ""),
        "signatureState": bundle_provenance(bundle).get("signatureState", "unsigned"),
        "digest": bundle_provenance(bundle).get("digest", ""),
        "updateUrl": bundle_provenance(bundle).get("updateUrl", ""),
        "manualUpdateCheck": bool(bundle_provenance(bundle).get("updateUrl")),
        "sourceNotesIncluded": args.format == "bundle",
        "sourceNoteCount": len(source_note_placements),
        "omittedSourceNoteCount": len(source_note_placements) if args.format == "opml" else 0,
        "omittedSourceNotePlacements": source_note_placements if args.format == "opml" else [],
    }
    if args.json:
        _json_print(summary)
    else:
        print(f"Wrote {args.output}")
        print(f"  {summary['feeds']} feed(s), {summary['pageWatches']} page watch(es), {summary['folders']} folder(s)")
        if args.format == "bundle":
            print(f"  Attributed to {summary['curator']} · unsigned" if summary["curator"] else "  Unsigned ProgRSS shared folder")
            if summary.get("updateUrl"):
                print(f"  Later-copy address: {summary['updateUrl']} · manual checks only")
        if args.format == "opml" and summary.get("updateUrl"):
            print("  OPML left out the ProgRSS later-copy address.")
        if args.format == "opml" and summary["omittedSourceNoteCount"]:
            print(f"  OPML left out {summary['omittedSourceNoteCount']} Source Note(s); use --format bundle to preserve placement reasons.")
        if omitted:
            print(f"  OPML left out {omitted} page watch(es); use --format bundle to preserve them.")
    return 0


def _command_bundle_site(argv: Sequence[str]) -> int:
    parser = argparse.ArgumentParser(prog="progrss bundle site", description="Package one located shared folder as a script-free static website ZIP.")
    parser.add_argument("file", type=Path, help="progrss.bundle.v3 shared-folder JSON")
    parser.add_argument("--edition", type=Path, help="optional summary-only progrss.folder-edition.v1 JSON Feed")
    parser.add_argument("--output", "-o", required=True, type=Path)
    parser.add_argument("--json", action="store_true", help="print a machine-readable summary")
    args = parser.parse_args(list(argv))
    if args.output.resolve() == args.file.resolve():
        raise RelayError("Choose a different output path so the shared-folder input remains untouched.")
    if args.output.exists():
        raise RelayError("The output file already exists. Choose another path; ProgRSS never overwrites files.")
    bundle = read_bundle(args.file)
    edition = None
    if args.edition:
        try:
            raw_edition = args.edition.read_bytes()
        except OSError as exc:
            raise RelayError(f"Could not read recent-updates feed: {exc}") from exc
        if len(raw_edition) > MAX_EDITION_BYTES:
            raise RelayError("The recent-updates feed is larger than the 250 KB safety limit.")
        try:
            edition = json.loads(raw_edition.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise RelayError("The recent-updates feed is not readable UTF-8 JSON.") from exc
    payload, summary = build_publication_site(bundle, edition)
    _write_new_bytes(args.output, payload)
    result = {**summary, "output": str(args.output)}
    if args.json:
        _json_print(result)
    else:
        print(f"Wrote {args.output}")
        print(f"  {summary['feeds']} feed(s), {summary['pageWatches']} page watch(es), {summary['folders']} folder(s)")
        print(f"  {len(summary['files'])} static file(s) · no scripts, trackers, network requests, or automatic checks")
        if summary["recentUpdatesIncluded"]:
            print(f"  {summary['updates']} recent update(s) · summary-only JSON Feed")
        print(f"  Hosted ProgRSS address: {summary['updateUrl']}")
    return 0


def _command_bundle_fetch(argv: Sequence[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="progrss bundle fetch",
        description="EXPLICIT NETWORK: fetch and verify one direct ProgRSS shared-folder address; never import or apply it.",
    )
    parser.add_argument("url", help="direct public http(s) address of a ProgRSS shared-folder JSON document")
    parser.add_argument("--output", "-o", type=Path, help="optional new file for the verified shared folder; never overwritten")
    parser.add_argument("--json", action="store_true", help="print the complete retrieval and verification report")
    args = parser.parse_args(list(argv))
    if args.output and args.output.exists():
        raise RelayError("The output file already exists. Choose another path; ProgRSS never overwrites files.")
    bundle, remote = fetch_publication(args.url)
    saved_to = ""
    if args.output:
        payload = (json.dumps(bundle, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
        if len(payload) > MAX_BUNDLE_BYTES:
            raise RelayError("The normalized shared folder is larger than the 650 KB safety limit.")
        _write_new_bytes(args.output, payload)
        saved_to = str(args.output)
    summary = _bundle_summary(bundle)
    publication = {
        key: summary[key]
        for key in (
            "schema", "title", "publicationId", "curator", "note", "issuedAt", "digest",
            "signatureState", "algorithm", "keyId", "fingerprint", "updateUrl",
            "feeds", "pageWatches", "folders", "sources", "startsPausedOnImport",
        )
    }
    report = {
        "schema": "progrss.publication-address-review.v1",
        "remote": remote,
        "publication": publication,
        "networkRequests": int(remote.get("networkRequests") or 0),
        "automatic": False,
        "applied": False,
        "savedTo": saved_to,
        "writes": bool(saved_to),
    }
    if args.json:
        _json_print(report)
        return 0
    print(f"Verified shared folder: {publication['title'] or 'Untitled shared folder'}")
    print(f"  Direct address: {remote['finalUrl']}")
    print(f"  {publication['feeds']} feed(s), {publication['pageWatches']} page watch(es), {publication['folders']} folder(s)")
    if publication["signatureState"] == "verified":
        label = f" · shown as {publication['curator']}" if publication["curator"] else ""
        print(f"  Signature verified · {publication['fingerprint']}{label}")
    elif publication["signatureState"] == "unsigned":
        label = f" · shown as {publication['curator']}" if publication["curator"] else ""
        print(f"  Content digest verified · unsigned{label}")
    else:
        print("  Legacy shared folder validated")
    print(f"  {report['networkRequests']} bounded request(s) · no credentials · no automatic schedule")
    if saved_to:
        print(f"  Saved verified copy: {saved_to}")
    else:
        print("  Nothing was saved, imported, or applied; use --output to keep the verified copy.")
    return 0


def _command_bundle_from_page(argv: Sequence[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="progrss bundle from-page",
        description="EXPLICIT NETWORK: discover and verify one same-site ProgRSS shared folder advertised by a webpage; never import or apply it.",
    )
    parser.add_argument("url", help="public http(s) webpage that advertises a ProgRSS shared folder")
    parser.add_argument("--output", "-o", type=Path, help="optional new file for the verified shared folder; never overwritten")
    parser.add_argument("--json", action="store_true", help="print the complete discovery and verification report")
    args = parser.parse_args(list(argv))
    bundle, result = discover_publication_from_page(args.url)
    saved_to = ""
    if args.output:
        if args.output.exists():
            raise RelayError("The output file already exists. Choose another path; ProgRSS never overwrites files.")
        payload = (json.dumps(bundle, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
        if len(payload) > MAX_BUNDLE_BYTES:
            raise RelayError("The normalized shared folder is larger than the 650 KB safety limit.")
        _write_new_bytes(args.output, payload)
        saved_to = str(args.output)
    report = {**result, "savedTo": saved_to, "writes": bool(saved_to)}
    if args.json:
        _json_print(report)
        return 0
    publication = report["publication"]
    print(f"Found shared folder: {publication['title'] or 'Untitled shared folder'}")
    print(f"  Advertised by {report['page']['finalUrl']}")
    print(f"  {publication['feeds']} feed(s), {publication['pageWatches']} page watch(es), {publication['folders']} folder(s)")
    if publication["signatureState"] == "verified":
        label = f" · shown as {publication['curator']}" if publication["curator"] else ""
        print(f"  Signature verified · {publication['fingerprint']}{label}")
    elif publication["signatureState"] == "unsigned":
        label = f" · shown as {publication['curator']}" if publication["curator"] else ""
        print(f"  Content digest verified · unsigned{label}")
    else:
        print("  Legacy shared folder validated")
    print(f"  {report['networkRequests']} bounded request(s) · no credentials · no automatic schedule")
    if saved_to:
        print(f"  Saved verified copy: {saved_to}")
    else:
        print("  Nothing was saved, imported, or applied; use --output to keep the verified copy.")
    return 0


def _command_bundle_check_page(argv: Sequence[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="progrss bundle check-page",
        description="EXPLICIT NETWORK: audit one deployed static publication page, its ProgRSS source list, and its optional recent-updates feed; no writes.",
    )
    parser.add_argument("url", help="public http(s) publication page")
    parser.add_argument("--require-updates", action="store_true", help="fail when the page does not advertise a valid recent-updates feed")
    parser.add_argument("--json", action="store_true", help="print the complete deployment audit")
    args = parser.parse_args(list(argv))
    report = check_publication_page(args.url, require_updates=bool(args.require_updates))
    if args.json:
        _json_print(report)
        return 0
    source_list = report["sourceList"]
    print(f"Valid publication page: {source_list['title'] or 'Untitled source list'}")
    print(f"  Source list: {source_list['feeds']} feed(s), {source_list['pageWatches']} watched page(s), {source_list['folders']} folder(s)")
    if report.get("recentUpdates"):
        updates = report["recentUpdates"]
        print(f"  Recent updates: {updates['items']} item(s) · summary-only JSON Feed")
    else:
        print("  Recent updates: not advertised")
    print("  Static page: default-src 'none' · no scripts, remote resources, frames, or forms")
    if report.get("warnings"):
        for warning in report["warnings"]:
            print(f"  Warning: {warning}")
    print(f"  {report['networkRequests']} bounded request(s) · no credentials · no writes · no automatic schedule")
    return 0


def _command_publish_folder(argv: Sequence[str]) -> int:
    parser = argparse.ArgumentParser(prog="progrss workspace publish-folder", description="Export one simple folder as an unsigned ready-to-host website ZIP.")
    parser.add_argument("backup", type=Path)
    parser.add_argument("folder", help="folder ID, unique title, or full folder path")
    parser.add_argument("--update-url", required=True, help="public http(s) address ending in the hosted .json file name")
    parser.add_argument("--output", "-o", required=True, type=Path)
    parser.add_argument("--curator", default="", help="optional name or group shown in the shared files")
    parser.add_argument("--note", default="", help="optional short curation note, at most 280 characters")
    parser.add_argument("--edition", type=Path, help="optional summary-only progrss.folder-edition.v1 JSON Feed")
    parser.add_argument("--json", action="store_true", help="print a machine-readable summary")
    args = parser.parse_args(list(argv))
    if args.output.resolve() == args.backup.resolve():
        raise RelayError("Choose a different output path so the workspace input remains untouched.")
    if args.output.exists():
        raise RelayError("The output file already exists. Choose another path; ProgRSS never overwrites files.")
    _site_file_name(args.update_url)
    _, location = read_workspace(args.backup)
    bundle = make_bundle(location.state, args.folder, curator=args.curator, note=args.note, update_url=args.update_url)
    edition = None
    if args.edition:
        try:
            raw_edition = args.edition.read_bytes()
        except OSError as exc:
            raise RelayError(f"Could not read recent-updates feed: {exc}") from exc
        if len(raw_edition) > MAX_EDITION_BYTES:
            raise RelayError("The recent-updates feed is larger than the 250 KB safety limit.")
        try:
            edition = json.loads(raw_edition.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise RelayError("The recent-updates feed is not readable UTF-8 JSON.") from exc
    payload, summary = build_publication_site(bundle, edition)
    _write_new_bytes(args.output, payload)
    result = {**summary, "output": str(args.output), "source": str(args.backup), "unsigned": True}
    if args.json:
        _json_print(result)
    else:
        print(f"Wrote {args.output}")
        print(f"  {summary['feeds']} feed(s), {summary['pageWatches']} page watch(es), {summary['folders']} folder(s)")
        print("  Unsigned ProgRSS copy · script-free static page · feed-only OPML when available")
        if summary["recentUpdatesIncluded"]:
            print(f"  {summary['updates']} recent update(s) · summary-only JSON Feed")
        print(f"  Upload together so {summary['updateFile']} remains at {summary['updateUrl']}")
        print("  Offline · input untouched · output written once")
    return 0


def _command_import_bundle(argv: Sequence[str]) -> int:
    parser = argparse.ArgumentParser(prog="progrss workspace import-bundle", description="Add a reviewed shared folder to a new workspace backup.")
    parser.add_argument("backup", type=Path)
    parser.add_argument("bundle", type=Path)
    parser.add_argument("--output", "-o", required=True, type=Path)
    parser.add_argument("--folder", default="", help="optional folder section ID, unique title, or full path; imported as an independent local excerpt")
    parser.add_argument("--json", action="store_true", help="print a machine-readable summary")
    args = parser.parse_args(list(argv))
    if args.output.resolve() == args.backup.resolve():
        raise RelayError("Choose a different output path so the original backup remains untouched.")
    if args.output.exists():
        raise RelayError("The output file already exists. Choose another path; Relay never overwrites files.")
    document, location = read_workspace(args.backup)
    bundle = read_bundle(args.bundle)
    updated, summary = import_bundle(location.state, bundle, args.folder)
    write_workspace(document, location, updated, args.output)
    summary = {**summary, "output": str(args.output), "newSourcesStartPaused": True, "networkRequests": 0}
    if args.json:
        _json_print(summary)
    else:
        print(f"Wrote {args.output}")
        print(f"  Added {summary['folders']} folder(s); {summary['newSources']} new source(s) paused; {summary['reusedSources']} source(s) reused.")
        if summary["independentExcerpt"]:
            print(f"  Selected section: {summary['selectedFolderPath']}")
            print("  Independent local excerpt · no parent-publication update link retained")
        print("  No sites were contacted and no browser permissions were transferred.")
    return 0



def _command_review_bundle(argv: Sequence[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="progrss workspace review-bundle",
        description="Compare an imported publication with a later shared-folder file; no network or writes.",
    )
    parser.add_argument("backup", type=Path)
    parser.add_argument("bundle", type=Path)
    parser.add_argument("--folder", default="", help="local publication root ID or unique title when more than one copy exists")
    parser.add_argument("--json", action="store_true", help="print the complete deterministic review as JSON")
    args = parser.parse_args(list(argv))
    _, location = read_workspace(args.backup)
    bundle = read_bundle(args.bundle)
    review = review_bundle_update(location.state, bundle, args.folder)
    if args.json:
        _json_print(review)
        return 0
    print(f"Shared-folder update review · {review.get('localTitle') or review.get('title') or 'Shared folder'}")
    print(f"  Publication: {review.get('publicationId') or 'unknown'}")
    trust = review.get("trust") or {}
    print(f"  Signer continuity: {trust.get('state') or 'not available'}")
    if trust.get("message"):
        print(f"    {trust['message']}")
    changes = review.get("changes") or {}
    if changes:
        print("  Incoming changes:")
        print(f"    sources added {changes.get('sourcesAdded', 0)} · removed from list {changes.get('sourcesRemoved', 0)} · recipes changed {changes.get('sourceRecipesChanged', 0)} · labels changed {changes.get('sourceMetadataChanged', 0)}")
        print(f"    folders added {changes.get('foldersAdded', 0)} · removed {changes.get('foldersRemoved', 0)} · changed {changes.get('foldersChanged', 0)}")
    merge = review.get("mergeReview") or {}
    counts = merge.get("counts") or {}
    if counts:
        print("  Three-way merge review:")
        print(
            "    curator only {curator} · yours only {recipient} · both agreed {agreed} · decisions needed {conflicts}".format(
                curator=counts.get("curatorOnly", 0),
                recipient=counts.get("recipientOnly", 0),
                agreed=counts.get("agreed", 0),
                conflicts=counts.get("conflicts", 0),
            )
        )
        print(
            "    added {added} · removed {removed} · recipe changes {recipes}".format(
                added=counts.get("additions", 0),
                removed=counts.get("removals", 0),
                recipes=counts.get("recipeChanges", 0),
            )
        )
        for group, heading in (
            ("conflicts", "Decisions needed"),
            ("recipeChanges", "How sources are checked"),
            ("curatorOnly", "Changed only by curator"),
            ("recipientOnly", "Changed only here"),
            ("agreed", "Same change on both sides"),
            ("additions", "Added by curator"),
            ("removals", "Removed by curator"),
        ):
            rows = merge.get(group) or []
            if not rows:
                continue
            print(f"  {heading}:")
            for row in rows[:12]:
                print(f"    • {row.get('summary') or row.get('label') or 'Reviewed change'}")
            omitted = int((merge.get("omitted") or {}).get(group) or 0) + max(0, len(rows) - 12)
            if omitted:
                print(f"    … {omitted} more shown by --json")
    local = review.get("localEdits") or {}
    if local.get("present"):
        print(f"  Local edits kept: {local.get('sourceOverrides', 0)} source override(s), {local.get('folderOverrides', 0)} folder edit(s), {local.get('detachedFolders', 0)} detached local folder(s)")
    if review.get("canUpdate"):
        print("  Available decisions:")
        print("    Update from this copy  → workspace update-bundle")
        print("    Keep my local version  → make no change")
        print("    Import as a separate folder → workspace import-bundle")
        if review.get("requiresTrustAcknowledgement"):
            print("  Updating requires --accept-trust-change after reviewing the signer change.")
        if review.get("requiresConflictChoices"):
            print("  Updating requires --resolve-conflicts keep-local or --resolve-conflicts use-curator.")
        if review.get("requiresRecipeAcknowledgement"):
            print("  Updating requires --accept-recipe-changes after reviewing the changed hosts and paused-source consequence.")
    else:
        print(f"  Update unavailable: {review.get('reason') or 'This copy cannot be applied safely.'}")
        print("  The local version remains unchanged; import-bundle can add this file separately.")
    print("  Offline · no writes")
    return 0


def _command_check_publication(argv: Sequence[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="progrss workspace check-publication",
        description="Fetch one explicitly configured shared-folder copy, verify it, and review it without applying changes.",
    )
    parser.add_argument("backup", type=Path)
    parser.add_argument("folder", help="imported publication folder ID, unique title, or full folder path")
    parser.add_argument("--output", "-o", type=Path, help="optional new file for the verified fetched copy; never overwritten")
    parser.add_argument("--json", action="store_true", help="print the complete network and update review as JSON")
    args = parser.parse_args(list(argv))
    _, location = read_workspace(args.backup)
    selected = _resolve_folder(location.state, args.folder)
    origin = _normalize_origin(selected["collection"].get("sharedFolderOrigin"), strict=True)
    assert origin is not None
    update_url = str(origin.get("updateUrl") or "")
    if not update_url:
        raise RelayError("That imported shared folder has no future-copy address. Choose a local shared-folder file instead.")
    bundle, remote = fetch_publication(update_url)
    provenance = bundle_provenance(bundle)
    if provenance.get("publicationId") != origin.get("publicationId"):
        raise RelayError("The address returned a different publication identity. Nothing was saved or applied.")
    review = review_bundle_update(location.state, bundle, selected["id"])
    saved_to = ""
    if args.output:
        if args.output.resolve() == args.backup.resolve():
            raise RelayError("Choose a different output path so the workspace input remains untouched.")
        if args.output.exists():
            raise RelayError("The output file already exists. Choose another path; ProgRSS never overwrites files.")
        payload = (json.dumps(bundle, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
        if len(payload) > MAX_BUNDLE_BYTES:
            raise RelayError("The normalized publication is larger than the 650 KB safety limit.")
        _write_new_bytes(args.output, payload)
        saved_to = str(args.output)
    result = {
        "schema": "progrss.workspace.publication-check.v1",
        "folderId": selected["id"],
        "localTitle": selected["title"],
        "publicationId": origin["publicationId"],
        "remote": remote,
        "review": review,
        "savedTo": saved_to,
        "writes": bool(saved_to),
        "applied": False,
        "automatic": False,
    }
    if args.json:
        _json_print(result)
        return 0
    print(f"Checked on request · {selected['path']}")
    print(f"  {remote['networkRequests']} network request(s) · no credentials · no automatic schedule")
    if remote["redirects"]:
        print(f"  Followed {len(remote['redirects'])} same-site redirect(s); no cross-site destination was contacted.")
    trust = review.get("trust") or {}
    print(f"  Signer continuity: {trust.get('state') or 'not available'}")
    changes = review.get("changes") or {}
    changed = sum(int(changes.get(key) or 0) for key in (
        "sourcesAdded", "sourcesRemoved", "sourceRecipesChanged", "sourceMetadataChanged",
        "foldersAdded", "foldersRemoved", "foldersChanged", "updateAddressChanged",
    ))
    if review.get("alreadyCurrent"):
        print("  The local folder already matches this copy.")
    elif review.get("canUpdate"):
        print(f"  A reviewable newer copy was found · {changed} change(s).")
        print("  Nothing was applied. Use workspace update-bundle with the saved file after review.")
    else:
        print(f"  Not applicable in place: {review.get('reason') or 'the review did not authorize an update.'}")
    if saved_to:
        print(f"  Saved verified copy: {saved_to}")
    else:
        print("  The fetched file was not kept; use --output to save a verified copy.")
    return 0


def _command_update_bundle(argv: Sequence[str]) -> int:
    parser = argparse.ArgumentParser(
        prog="progrss workspace update-bundle",
        description="Apply one reviewed shared-folder update to a new workspace backup; no network.",
    )
    parser.add_argument("backup", type=Path)
    parser.add_argument("bundle", type=Path)
    parser.add_argument("--folder", default="", help="local publication root ID or unique title when more than one copy exists")
    parser.add_argument("--accept-trust-change", action="store_true", help="accept a valid changed signing key or signed-to-unsigned downgrade after review")
    parser.add_argument(
        "--resolve-conflicts", choices=("keep-local", "use-curator"), default="",
        help="legacy bulk choice for every reviewed conflict; prefer one --conflict ID=CHOICE per conflict",
    )
    parser.add_argument(
        "--conflict", action="append", default=[], metavar="ID=CHOICE",
        help="resolve one reviewed conflict with keep-local or use-curator; repeat for each decision ID",
    )
    parser.add_argument(
        "--accept-recipe-changes", action="store_true",
        help="accept reviewed acquisition-recipe changes; newly created recipes remain paused and prior histories remain local",
    )
    parser.add_argument("--output", "-o", required=True, type=Path)
    parser.add_argument("--json", action="store_true", help="print a machine-readable summary")
    args = parser.parse_args(list(argv))
    if args.output.resolve() == args.backup.resolve():
        raise RelayError("Choose a different output path so the original backup remains untouched.")
    if args.output.exists():
        raise RelayError("The output file already exists. Choose another path; ProgRSS never overwrites files.")
    document, location = read_workspace(args.backup)
    bundle = read_bundle(args.bundle)
    conflict_decisions: dict[str, str] = {}
    for raw_decision in args.conflict:
        conflict_id, separator, choice = str(raw_decision).rpartition("=")
        if not separator or not conflict_id or choice not in {"keep-local", "use-curator"}:
            raise RelayError("Each --conflict value must be ID=keep-local or ID=use-curator.")
        if conflict_id in conflict_decisions and conflict_decisions[conflict_id] != choice:
            raise RelayError(f"Conflicting decisions were supplied for {conflict_id}.")
        conflict_decisions[conflict_id] = choice
    updated, summary = update_bundle(
        location.state, bundle, args.folder,
        accept_trust_change=bool(args.accept_trust_change),
        conflict_policy=str(args.resolve_conflicts or ""),
        conflict_decisions=conflict_decisions,
        acknowledge_recipe_change=bool(args.accept_recipe_changes),
    )
    write_workspace(document, location, updated, args.output)
    result = {**summary, "output": str(args.output), "newSourcesStartPaused": True}
    if args.json:
        _json_print(result)
    else:
        print(f"Wrote {args.output}")
        changes = summary.get("changes") or {}
        changed = sum(int(changes.get(key) or 0) for key in (
            "sourcesAdded", "sourcesRemoved", "sourceRecipesChanged", "sourceMetadataChanged",
            "foldersAdded", "foldersRemoved", "foldersChanged",
        ))
        print(f"  Updated {summary.get('localTitle') or summary.get('title') or 'shared folder'} · {changed} reviewed change(s)")
        print("  Local reading history, read and saved state, source activity, and unrelated organization were kept.")
        if summary.get("requiresTrustAcknowledgement"):
            print(f"  Accepted signer continuity state: {(summary.get('trust') or {}).get('state', 'changed')}")
        if summary.get("requiresConflictChoices"):
            print(f"  Divergent wording resolved: {summary.get('conflictPolicy')}")
        if summary.get("requiresRecipeAcknowledgement"):
            print("  Reviewed acquisition-recipe changes accepted; any new recipe remains paused.")
        print("  Offline · input untouched · output written once")
    return 0

def run_relay_cli(argv: Sequence[str] | None = None) -> int | None:
    args = list(sys.argv[1:] if argv is None else argv)
    command: tuple[str, ...] | None = None
    rest: list[str] = []
    if len(args) >= 2 and args[:2] == ["bundle", "inspect"]:
        command, rest = ("bundle", "inspect"), args[2:]
    elif len(args) >= 2 and args[:2] == ["bundle", "contents"]:
        command, rest = ("bundle", "contents"), args[2:]
    elif len(args) >= 2 and args[:2] == ["bundle", "verify"]:
        command, rest = ("bundle", "verify"), args[2:]
    elif len(args) >= 2 and args[:2] == ["bundle", "site"]:
        command, rest = ("bundle", "site"), args[2:]
    elif len(args) >= 2 and args[:2] == ["bundle", "fetch"]:
        command, rest = ("bundle", "fetch"), args[2:]
    elif len(args) >= 2 and args[:2] == ["bundle", "from-page"]:
        command, rest = ("bundle", "from-page"), args[2:]
    elif len(args) >= 2 and args[:2] == ["bundle", "check-page"]:
        command, rest = ("bundle", "check-page"), args[2:]
    elif len(args) >= 2 and args[:2] == ["workspace", "share-folder"]:
        command, rest = ("workspace", "share-folder"), args[2:]
    elif len(args) >= 2 and args[:2] == ["workspace", "publish-folder"]:
        command, rest = ("workspace", "publish-folder"), args[2:]
    elif len(args) >= 2 and args[:2] == ["workspace", "import-bundle"]:
        command, rest = ("workspace", "import-bundle"), args[2:]
    elif len(args) >= 2 and args[:2] == ["workspace", "review-bundle"]:
        command, rest = ("workspace", "review-bundle"), args[2:]
    elif len(args) >= 2 and args[:2] == ["workspace", "check-publication"]:
        command, rest = ("workspace", "check-publication"), args[2:]
    elif len(args) >= 2 and args[:2] == ["workspace", "update-bundle"]:
        command, rest = ("workspace", "update-bundle"), args[2:]
    elif args == ["bundle"]:
        print("usage: progrss bundle {inspect,contents,verify,site,fetch,from-page,check-page} ...", file=sys.stderr)
        return 2
    if command is None:
        return None
    try:
        if command == ("bundle", "inspect"):
            return _command_bundle_inspect(rest)
        if command == ("bundle", "contents"):
            return _command_bundle_contents(rest)
        if command == ("bundle", "verify"):
            return _command_bundle_verify(rest)
        if command == ("bundle", "site"):
            return _command_bundle_site(rest)
        if command == ("bundle", "fetch"):
            return _command_bundle_fetch(rest)
        if command == ("bundle", "from-page"):
            return _command_bundle_from_page(rest)
        if command == ("bundle", "check-page"):
            return _command_bundle_check_page(rest)
        if command == ("workspace", "share-folder"):
            return _command_share_folder(rest)
        if command == ("workspace", "publish-folder"):
            return _command_publish_folder(rest)
        if command == ("workspace", "import-bundle"):
            return _command_import_bundle(rest)
        if command == ("workspace", "review-bundle"):
            return _command_review_bundle(rest)
        if command == ("workspace", "check-publication"):
            return _command_check_publication(rest)
        return _command_update_bundle(rest)
    except RelayError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


__all__ = [
    "LEGACY_BUNDLE_SCHEMA", "BUNDLE_SCHEMA", "LOCATED_BUNDLE_SCHEMA", "PUBLICATION_SCHEMA",
    "INTEGRITY_SCHEMA", "SIGNATURE_SCHEMA", "DISTRIBUTION_SCHEMA", "LEGACY_ORIGIN_SCHEMA", "ORIGIN_SCHEMA", "LOCATED_ORIGIN_SCHEMA", "BASELINE_SCHEMA", "CONTENTS_SCHEMA",
    "MAX_BUNDLE_BYTES", "MAX_SITE_BYTES", "MAX_PUBLICATION_PAGE_BYTES", "BUNDLE_MEDIA_TYPE", "RelayError", "canonical_json",
    "bundle_content_digest", "verify_bundle_signature", "bundle_provenance", "bundle_contents", "select_bundle_section",
    "validate_bundle", "read_bundle", "fetch_publication", "discover_publication_from_page", "check_publication_page", "make_bundle", "publication_site_files", "build_publication_site", "import_bundle", "review_bundle_update", "update_bundle",
    "run_relay_cli",
]
