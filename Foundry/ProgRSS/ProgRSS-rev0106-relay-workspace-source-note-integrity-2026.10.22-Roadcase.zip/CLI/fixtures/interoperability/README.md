# ProgRSS Interoperability Garden

A small, deterministic feed corpus for replaying parser behavior without contacting public servers or exposing a reader’s subscriptions.

The thirty-two specimens are synthetic and standards-derived. They cover RSS 2.0, RSS 1.0/RDF, Atom 1.0, JSON Feed 1.x, relative links, common text encodings, namespace extensions, identity fallbacks, publication dates, duplicate revisions, standards-declared feed addresses, summary/full-text distinctions, JSON Feed language inheritance, Atom `xml:lang`, RSS language metadata, difficult whitespace, resource-shaped markup exclusion, malformed documents, and DTD/entity refusal.

Run the Python implementation with:

```text
progrss feed corpus
```

The browser acceptance lane replays the byte-identical Extension copy through the independent JavaScript parser. The corpus is evidence for these bounded cases, not a claim that every feed on the public web is compatible.

Primary format references: RSS 2.0, the RSS Content module, RFC 4287 (Atom), JSON Feed 1.1, and the HTML feed-autodiscovery rules.

Rev0033 added three distinct summary/full-text specimens. Rev0034 adds JSON Feed language inheritance, Atom `xml:lang` inheritance and field overrides, RSS channel/item language metadata, Persian/Arabic/Hebrew text, and difficult whitespace. Language values are normalized when declared; missing or invalid values remain absent rather than being guessed.
