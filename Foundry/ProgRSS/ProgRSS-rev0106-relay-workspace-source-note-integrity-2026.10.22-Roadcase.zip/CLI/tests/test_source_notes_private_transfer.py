from __future__ import annotations

import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve()
CLI_DIR = HERE.parents[1]
if str(CLI_DIR) not in sys.path:
    sys.path.insert(0, str(CLI_DIR))

import progrss


class SourceNotesPrivateTransferTests(unittest.TestCase):
    def wrapper(self) -> dict:
        return {
            "schema": progrss.BACKUP_SCHEMA,
            "exportedAt": "2026-10-21T12:00:00Z",
            "producer": {"name": "ProgRSS", "version": "0.80.0", "revision": "rev0080"},
            "state": {
                "version": 17,
                "sources": [
                    {"id": "shared", "title": "Shared source", "type": "rss", "url": "https://example.test/feed.xml", "enabled": False, "archivedAt": ""},
                    {"id": "plain", "title": "Plain source", "type": "rss", "url": "https://plain.test/feed.xml", "enabled": False, "archivedAt": ""},
                ],
                "collections": [
                    {"id": "alpha", "title": "Alpha", "mode": "union", "version": 1, "members": [
                        {"kind": "source", "id": "shared", "reason": "Alpha reason.\nSecond line."},
                        {"kind": "source", "id": "plain"},
                    ]},
                    {"id": "beta", "title": "Beta", "mode": "union", "version": 1, "members": [
                        {"kind": "source", "id": "shared", "reason": "سبب بيتا."},
                    ]},
                ],
                "items": [],
                "snapshots": {},
                "retiredReceipts": [],
            },
        }

    @staticmethod
    def reason_member(document: dict, folder_id: str = "alpha", index: int = 0) -> dict:
        folder = next(row for row in document["state"]["collections"] if row["id"] == folder_id)
        return folder["members"][index]

    def write(self, folder: Path, document: dict, name: str = "private.json") -> Path:
        path = folder / name
        path.write_text(json.dumps(document, ensure_ascii=True), encoding="utf-8")
        return path

    def test_valid_reasons_round_trip_and_transfer_audit_counts_them(self) -> None:
        document = self.wrapper()
        with tempfile.TemporaryDirectory() as temp_name:
            path = self.write(Path(temp_name), document)
            wrapper, state = progrss.load_backup(path)
            self.assertEqual(wrapper["schema"], progrss.BACKUP_SCHEMA)
            self.assertEqual(progrss.source_note_placement_count(state), 2)
            self.assertEqual(state["collections"][0]["members"][0]["reason"], "Alpha reason.\nSecond line.")
            self.assertEqual(state["collections"][1]["members"][0]["reason"], "سبب بيتا.")
            self.assertNotIn("reason", state["collections"][0]["members"][1])

            report = progrss.transfer_audit_report(wrapper, state)
            self.assertEqual(report["moves"]["sourceNotes"], 2)
            self.assertIn("curator-written folder reasons", report["privacy"]["categories"])
            self.assertFalse(report["network"])
            self.assertFalse(report["writes"])

            completed = subprocess.run(
                [str(CLI_DIR / "progrss"), "workspace", "transfer-audit", str(path), "--json"],
                cwd=CLI_DIR, text=True, capture_output=True,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            cli_report = json.loads(completed.stdout)
            self.assertEqual(cli_report["moves"]["sourceNotes"], 2)
            self.assertIn("curator-written folder reasons", cli_report["privacy"]["categories"])

    def invalid_documents(self) -> list[tuple[str, dict, str]]:
        rows: list[tuple[str, dict, str]] = []

        over_limit = self.wrapper()
        self.reason_member(over_limit)["reason"] = "😀" * 281
        rows.append(("over-limit", over_limit, "280"))

        wrong_level = self.wrapper()
        wrong_level["state"]["collections"][0]["members"].append({"kind": "collection", "id": "beta", "reason": "Wrong level"})
        rows.append(("wrong-level", wrong_level, "direct source placement"))

        folder_reason = self.wrapper()
        folder_reason["state"]["collections"][0]["reason"] = "Wrong level"
        rows.append(("folder-reason", folder_reason, "on the folder"))

        duplicate = self.wrapper()
        duplicate["state"]["collections"][0]["members"].insert(1, {"kind": "source", "id": "shared", "reason": "Alpha reason.\nSecond line."})
        rows.append(("duplicate", duplicate, "appear exactly once"))

        whitespace = self.wrapper()
        self.reason_member(whitespace)["reason"] = " \t\n "
        rows.append(("whitespace-only", whitespace, "empty Source Note"))

        edge_whitespace = self.wrapper()
        self.reason_member(edge_whitespace)["reason"] = "  Alpha reason.  "
        rows.append(("edge-whitespace", edge_whitespace, "noncanonical Source Note"))

        non_string = self.wrapper()
        self.reason_member(non_string)["reason"] = 42
        rows.append(("non-string", non_string, "must be a string"))

        invalid_unicode = self.wrapper()
        self.reason_member(invalid_unicode)["reason"] = "bad\ud800value"
        rows.append(("invalid-unicode", invalid_unicode, "Unicode scalar"))

        missing_source = self.wrapper()
        self.reason_member(missing_source)["id"] = "not-present"
        rows.append(("missing-source", missing_source, "missing source"))
        return rows

    def test_malformed_reason_placements_fail_before_cli_use(self) -> None:
        for name, document, pattern in self.invalid_documents():
            with self.subTest(name=name), tempfile.TemporaryDirectory() as temp_name:
                path = self.write(Path(temp_name), document, f"{name}.json")
                with self.assertRaisesRegex(progrss.ProgRSSError, pattern):
                    progrss.load_backup(path)

                completed = subprocess.run(
                    [str(CLI_DIR / "progrss"), "workspace", "folders", str(path), "--json"],
                    cwd=CLI_DIR, text=True, capture_output=True,
                )
                self.assertEqual(completed.returncode, 2, (name, completed.stdout, completed.stderr))
                self.assertEqual(completed.stdout, "")
                self.assertRegex(completed.stderr, pattern)

    def test_reasonless_legacy_duplicate_remains_outside_this_narrow_repair(self) -> None:
        document = self.wrapper()
        document["state"]["collections"][0]["members"].extend([
            {"kind": "source", "id": "plain"},
        ])
        # Private-transfer integrity is intentionally scoped to Source Notes.
        # Existing reasonless legacy duplicate behavior is not silently changed.
        progrss.validate_state(document["state"])
        self.assertEqual(progrss.source_note_placement_count(document["state"]), 2)

    def test_exported_valid_state_is_not_normalized_or_rewritten_by_validation(self) -> None:
        document = self.wrapper()
        before = copy.deepcopy(document["state"])
        progrss.validate_state(document["state"])
        self.assertEqual(document["state"], before)


if __name__ == "__main__":
    unittest.main()
