from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
BIN = ROOT / "progrss"
FIX = ROOT / "fixtures"


class QuietHandler(BaseHTTPRequestHandler):
    routes: dict[str, tuple[int, dict[str, str], bytes]] = {}
    hits: list[str] = []

    def do_GET(self) -> None:  # noqa: N802
        type(self).hits.append(self.path)
        status, headers, body = type(self).routes.get(self.path, (404, {"Content-Type": "text/plain"}, b"missing"))
        self.send_response(status)
        for name, value in headers.items():
            self.send_header(name, value)
        self.end_headers()
        if body:
            self.wfile.write(body)

    def log_message(self, _format: str, *_args: object) -> None:
        return


def start_server(handler: type[QuietHandler]) -> tuple[ThreadingHTTPServer, threading.Thread]:
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    return server, thread


class CommandLineTests(unittest.TestCase):
    def run_cli(self, *args: str) -> subprocess.CompletedProcess[str]:
        return subprocess.run([str(BIN), *args], text=True, capture_output=True, check=False, timeout=30)

    def test_version(self) -> None:
        result = self.run_cli("--version")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("0.80.0", result.stdout)


    def test_node_serve_is_visible_and_describes_its_boundary(self) -> None:
        result = self.run_cli("node", "serve", "--help")
        self.assertEqual(result.returncode, 0, result.stderr)
        help_text = result.stdout.lower()
        self.assertIn("loopback", help_text)
        self.assertIn("node-owned library", help_text)
        self.assertIn("reviewed branch-adoption operation", help_text)
        self.assertIn("off source checks", help_text)
        self.assertIn("no feed or webpage fetch", help_text)
        self.assertIn("scheduler is created", help_text)

    def test_node_fieldbook_help_is_private_local_and_new_file_only(self) -> None:
        result = self.run_cli("node", "fieldbook", "--help")
        self.assertEqual(result.returncode, 0, result.stderr)
        help_text = result.stdout.lower()
        self.assertIn("facilitator", help_text)
        self.assertIn("no network", help_text)
        self.assertIn("participant identity", help_text)
        self.assertIn("output", help_text)

    def test_node_exchange_fieldbook_is_private_adapts_to_choices_and_refuses_overwrite(self) -> None:
        help_result = self.run_cli("node", "exchange-fieldbook", "--help")
        self.assertEqual(help_result.returncode, 0, help_result.stderr)
        help_text = help_result.stdout.lower()
        self.assertIn("facilitator sidecar", help_text)
        self.assertIn("no network", help_text)
        self.assertIn("curator names", help_text)
        self.assertIn("output", help_text)

        with tempfile.TemporaryDirectory() as temp:
            review_path = Path(temp) / "exchange-review.json"
            output = Path(temp) / "exchange-fieldbook.html"
            review = {
                "schema": "progrss.node.exchange.v1",
                "state": "review",
                "exchangeId": "SECRET-EXCHANGE-ID",
                "createdAt": "2026-10-20T20:00:00Z",
                "expiresAt": "2026-10-20T20:30:00Z",
                "generatedAt": "2026-10-20T19:59:00Z",
                "title": "SECRET ROUTE TITLE",
                "curator": "SECRET CURATOR",
                "note": "SECRET NOTE",
                "library": {"file": "private.json", "sha256": "a" * 64},
                "folder": {"id": "secret-folder", "path": "SECRET FOLDER PATH"},
                "counts": {"sources": 3, "feeds": 2, "pageWatches": 1, "folders": 2, "recentUpdates": 3},
                "contents": {
                    "sources": [{"title": "SECRET SOURCE", "host": "secret.example"}],
                    "folders": [{"path": "SECRET FOLDER PATH"}],
                    "sourcesOmitted": 0,
                    "foldersOmitted": 0,
                },
                "choices": {
                    "followUpdates": {"available": True, "feedUrl": "https://secret.example/recent-updates.json", "reason": ""},
                    "addRoute": {"available": True},
                    "takeBranch": {"available": True, "branches": [{"id": "secret-branch", "path": "SECRET BRANCH", "sources": 1, "feeds": 1, "pageWatches": 0}]},
                },
                "public": {
                    "sourceListUrl": "https://secret.example/source-list.json",
                    "pageUrl": "https://secret.example/",
                    "feedUrl": "https://secret.example/recent-updates.json",
                },
                "privacy": {"included": ["source recipes"], "excluded": ["read and unread state"]},
                "artifacts": {},
                "previewDigest": "b" * 64,
                "node": {
                    "origin": "http://127.0.0.1:8080",
                    "version": "0.80.0",
                    "revision": "rev0080",
                    "instanceFingerprint": "SECRET-FINGERPRINT",
                    "identityPersistence": "until-node-stops",
                },
                "scope": "one-expiring-reviewed-artifact-handoff",
                "automatic": False,
                "revocable": True,
            }
            review_path.write_text(json.dumps(review), encoding="utf-8")
            result = self.run_cli(
                "node", "exchange-fieldbook", str(review_path),
                "--output", str(output), "--json",
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            document = json.loads(result.stdout)
            self.assertEqual(document["schema"], "progrss.fieldwork-kit.v1")
            self.assertEqual(document["scenario"], "exchange-three-doors")
            self.assertEqual(document["tasks"], 15)
            self.assertFalse(document["network"])
            self.assertFalse(document["libraryWrites"])
            self.assertFalse(document["storeWrites"])
            text = output.read_text(encoding="utf-8")
            self.assertIn("Observe the choice, not the person.", text)
            self.assertIn("Follow updates", text)
            self.assertIn("Add the complete route", text)
            self.assertIn("Take one branch", text)
            for secret in (
                "SECRET-EXCHANGE-ID", "SECRET ROUTE TITLE", "SECRET CURATOR",
                "SECRET NOTE", "secret.example", "SECRET FOLDER PATH",
                "SECRET SOURCE", "SECRET-FINGERPRINT", "127.0.0.1",
            ):
                self.assertNotIn(secret, text)
            repeated = self.run_cli(
                "node", "exchange-fieldbook", str(review_path), "--output", str(output),
            )
            self.assertEqual(repeated.returncode, 2)
            self.assertIn("output already exists", repeated.stderr)

    def test_node_exchange_sender_fieldbook_is_private_and_refuses_overwrite(self) -> None:
        help_result = self.run_cli("node", "exchange-sender-fieldbook", "--help")
        self.assertEqual(help_result.returncode, 0, help_result.stderr)
        help_text = help_result.stdout.lower()
        self.assertIn("sender-study", help_text)
        self.assertIn("no network", help_text)
        self.assertIn("preview-capability", help_text)
        self.assertIn("output", help_text)

        with tempfile.TemporaryDirectory() as temp:
            preview_path = Path(temp) / "exchange-preview.json"
            output = Path(temp) / "exchange-sender-fieldbook.html"
            preview = {
                "schema": "progrss.node.exchange-preview.v1",
                "state": "preview",
                "previewToken": "SECRET-PREVIEW-TOKEN",
                "previewDigest": "a" * 64,
                "expiresAt": "2026-10-20T20:10:00Z",
                "expiresInSeconds": 600,
                "generatedAt": "2026-10-20T20:00:00Z",
                "title": "SECRET ROUTE TITLE",
                "curator": "SECRET CURATOR",
                "note": "SECRET NOTE",
                "library": {"file": "private.json", "sha256": "b" * 64},
                "folder": {"id": "secret-folder", "path": "SECRET FOLDER PATH"},
                "counts": {"sources": 3, "feeds": 2, "pageWatches": 1, "folders": 2, "recentUpdates": 3},
                "contents": {
                    "sources": [{"title": "SECRET SOURCE", "host": "secret.example"}],
                    "folders": [{"path": "SECRET FOLDER PATH"}],
                    "sourcesOmitted": 0,
                    "foldersOmitted": 0,
                },
                "choices": {
                    "followUpdates": {"available": True, "feedUrl": "https://secret.example/recent-updates.json", "reason": ""},
                    "addRoute": {"available": True},
                    "takeBranch": {"available": True, "branches": [{"id": "secret-branch", "path": "SECRET BRANCH", "sources": 1, "feeds": 1, "pageWatches": 0}]},
                },
                "public": {
                    "sourceListUrl": "https://secret.example/source-list.json",
                    "pageUrl": "https://secret.example/",
                    "feedUrl": "https://secret.example/recent-updates.json",
                },
                "privacy": {
                    "included": ["source recipes", "simple folder routes", "curator wording", "bounded recent-update summaries when selected"],
                    "excluded": [
                        "read and unread state", "saved state", "full retained article text",
                        "page-watch snapshots and comparison evidence", "browser permissions and cookies",
                        "private signing keys",
                    ],
                },
                "artifacts": {
                    "sourceList": {"available": True, "name": "secret-source-list.json", "sha256": "c" * 64},
                    "recentUpdates": {"available": True, "name": "recent-updates.json", "sha256": "d" * 64},
                    "site": {"available": True, "name": "secret-site.zip", "sha256": "e" * 64},
                },
                "network": False,
                "writes": False,
                "automatic": False,
            }
            preview_path.write_text(json.dumps(preview), encoding="utf-8")
            result = self.run_cli(
                "node", "exchange-sender-fieldbook", str(preview_path),
                "--output", str(output), "--json",
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            document = json.loads(result.stdout)
            self.assertEqual(document["schema"], "progrss.fieldwork-kit.v1")
            self.assertEqual(document["scenario"], "exchange-sender-review")
            self.assertEqual(document["tasks"], 16)
            self.assertFalse(document["network"])
            self.assertFalse(document["libraryWrites"])
            text = output.read_text(encoding="utf-8")
            self.assertIn("Know what leaves before you send the link.", text)
            self.assertIn("Explain what stays private", text)
            self.assertIn("Create 30-minute handoff", text)
            for secret in (
                "SECRET-PREVIEW-TOKEN", "SECRET ROUTE TITLE", "SECRET CURATOR",
                "SECRET NOTE", "secret.example", "SECRET FOLDER PATH", "SECRET SOURCE",
                "private.json", "secret-source-list.json", "secret-site.zip",
                "a" * 64, "b" * 64, "c" * 64, "d" * 64, "e" * 64,
            ):
                self.assertNotIn(secret, text)
            repeated = self.run_cli(
                "node", "exchange-sender-fieldbook", str(preview_path), "--output", str(output),
            )
            self.assertEqual(repeated.returncode, 2)
            self.assertIn("output already exists", repeated.stderr)

    def test_node_debrief_help_is_local_private_and_does_not_score_people(self) -> None:
        result = self.run_cli("node", "debrief", "--help")
        self.assertEqual(result.returncode, 0, result.stderr)
        help_text = result.stdout.lower()
        self.assertIn("local-only", help_text)
        self.assertIn("raw facilitator notes", help_text)
        self.assertIn("fieldbook", help_text)
        self.assertIn("output", help_text)

    def test_node_debrief_preloads_valid_reports_deduplicates_and_refuses_overwrite(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            report_path = Path(temp) / "report.json"
            output = Path(temp) / "debrief.html"
            report = {
                "schema": "progrss.fieldwork-report.v1",
                "scenario": "trace-bearing-anchor",
                "scenarioDigest": "a" * 64,
                "release": {"version": "0.76.0", "revision": "rev0076", "codename": "Fieldbook"},
                "generatedFromKitAt": "2026-10-20T20:00:00Z",
                "completedAt": "2026-10-20T20:10:00Z",
                "outcomes": {"independent": 1, "neutral-prompt": 0, "wrong-turn": 0, "not-observed": 0},
                "tasks": [{"id": "accepted-baseline", "title": "Find the accepted baseline", "outcome": "independent", "notes": ""}],
                "facilitatorBoundary": {"testedProductNotParticipant": True, "avoidedSensitiveNotes": True, "exactReleaseOpen": True},
                "privacy": {"participantIdentityRecorded": False, "automaticPersistence": False, "telemetry": False, "network": False},
            }
            report_path.write_text(json.dumps(report), encoding="utf-8")
            result = self.run_cli(
                "node", "debrief", str(report_path), str(report_path),
                "--output", str(output), "--json",
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            document = json.loads(result.stdout)
            self.assertEqual(document["schema"], "progrss.fieldwork-debrief-kit.v1")
            self.assertEqual(document["preloadedReports"], 1)
            self.assertEqual(document["duplicatesRemoved"], 1)
            self.assertFalse(document["participantScore"])
            self.assertFalse(document["rawNotesExported"])
            self.assertIn("Find patterns. Do not score people.", output.read_text(encoding="utf-8"))
            repeated = self.run_cli(
                "node", "debrief", str(report_path), "--output", str(output),
            )
            self.assertEqual(repeated.returncode, 2)
            self.assertIn("output already exists", repeated.stderr)

    def test_node_owned_library_init_export_receipts_and_no_overwrite(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            store = Path(temp) / "library.sqlite3"
            exported = Path(temp) / "exported.json"

            created = self.run_cli(
                "node", "init", str(FIX / "sample-backup.json"),
                "--output", str(store), "--json",
            )
            self.assertEqual(created.returncode, 0, created.stderr)
            created_doc = json.loads(created.stdout)
            self.assertEqual(created_doc["schema"], "progrss.node-store.v4")
            self.assertEqual(created_doc["state"], "created")
            self.assertTrue(created_doc["import"]["preserved"])
            self.assertEqual(created_doc["library"]["revision"], 1)
            self.assertFalse(created_doc["network"])
            self.assertTrue(created_doc["writes"])
            self.assertTrue(store.is_file())

            receipts = self.run_cli("node", "receipts", str(store), "--json")
            self.assertEqual(receipts.returncode, 0, receipts.stderr)
            receipts_doc = json.loads(receipts.stdout)
            self.assertEqual(receipts_doc["schema"], "progrss.node.operation-result.v1")
            self.assertEqual(receipts_doc["operations"], [])
            self.assertFalse(receipts_doc["network"])
            self.assertFalse(receipts_doc["writes"])

            acquisitions = self.run_cli("node", "acquisitions", str(store), "--json")
            self.assertEqual(acquisitions.returncode, 0, acquisitions.stderr)
            acquisitions_doc = json.loads(acquisitions.stdout)
            self.assertEqual(acquisitions_doc["schema"], "progrss.node.acquisition-result.v1")
            self.assertEqual(acquisitions_doc["receipts"], [])
            self.assertEqual(acquisitions_doc["jobs"], [])
            self.assertFalse(acquisitions_doc["network"])
            self.assertFalse(acquisitions_doc["writes"])

            result = self.run_cli(
                "node", "export", str(store), "--output", str(exported), "--json",
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            exported_doc = json.loads(result.stdout)
            self.assertEqual(exported_doc["state"], "exported")
            self.assertEqual(exported_doc["revision"], 1)
            self.assertEqual(exported.read_bytes(), (FIX / "sample-backup.json").read_bytes())

            repeat = self.run_cli(
                "node", "export", str(store), "--output", str(exported), "--json",
            )
            self.assertEqual(repeat.returncode, 2)
            self.assertIn("already exists", repeat.stderr)

            duplicate_store = self.run_cli(
                "node", "init", str(FIX / "sample-backup.json"),
                "--output", str(store), "--json",
            )
            self.assertEqual(duplicate_store.returncode, 2)
            self.assertIn("already exists", duplicate_store.stderr)

    def test_bundle_contents_is_visible_in_help(self) -> None:
        result = self.run_cli("bundle", "--help")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("contents", result.stdout)
        self.assertIn("source names, sites, and folder routes", result.stdout)


    def test_workspace_access_plan_is_offline_and_hides_sites_by_default(self) -> None:
        hidden = self.run_cli("workspace", "access-plan", str(FIX / "sample-backup.json"))
        self.assertEqual(hidden.returncode, 0, hidden.stderr)
        self.assertIn("Site-access plan", hidden.stdout)
        self.assertIn("Current browser grants are unknown", hidden.stdout)
        self.assertIn("Sites hidden by default", hidden.stdout)
        self.assertNotIn("https://existing.test", hidden.stdout)
        self.assertIn("Scheduled checks never prompt", hidden.stdout)

        shown = self.run_cli(
            "workspace", "access-plan", str(FIX / "sample-backup.json"),
            "--source", "Existing Feed", "--origins", "--json",
        )
        self.assertEqual(shown.returncode, 0, shown.stderr)
        report = json.loads(shown.stdout)
        self.assertEqual(report["schema"], "progrss.workspace.access-plan.v1")
        self.assertEqual(report["sourceCount"], 1)
        self.assertEqual(report["sources"][0]["origins"], ["https://existing.test"])
        self.assertFalse(report["network"])
        self.assertFalse(report["writes"])
        self.assertFalse(report["browserProfileRead"])
        self.assertFalse(report["permissionsRead"])

    def test_workspace_recovery_copy_is_private_offline_and_no_overwrite(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "recovery.json"
            result = self.run_cli(
                "workspace", "recovery-copy", str(FIX / "sample-backup.json"),
                "--output", str(output),
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("private recovery copy", result.stdout)
            self.assertIn("re-opened", result.stdout)
            self.assertIn("Readable and matching now", result.stdout)
            self.assertIn("offline", result.stdout)
            self.assertIn("new-file-only", result.stdout)
            document = json.loads(output.read_text())
            self.assertEqual(document["purpose"], "recovery-copy")
            self.assertEqual(document["producer"]["version"], "0.80.0")
            self.assertEqual(document["producer"]["revision"], "rev0080")
            self.assertNotIn("_revision", document["state"])

            repeat = self.run_cli(
                "workspace", "recovery-copy", str(FIX / "sample-backup.json"),
                "--output", str(output),
            )
            self.assertEqual(repeat.returncode, 2)
            self.assertIn("already exists", repeat.stderr)

    def test_workspace_page_watch_stability_assessment_is_offline_and_read_only(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            backup = Path(temp) / "watch.json"
            first = Path(temp) / "first.html"
            second = Path(temp) / "second.html"
            document = json.loads((FIX / "sample-backup.json").read_text())
            document["state"]["sources"].append({
                "id": "steady-watch", "type": "page", "title": "Steady page",
                "url": "https://example.test/steady", "enabled": True,
                "mode": "region", "selector": "main", "version": 2,
            })
            document["state"]["snapshots"]["steady-watch"] = {
                "mode": "region", "text": " ".join(["baseline"] * 90),
                "capturedAt": "2026-10-18T00:00:00Z",
            }
            backup.write_text(json.dumps(document))
            first.write_text("<main>" + " ".join(["changed"] * 18) + "</main>")
            second.write_text("<main>" + " ".join(["changed"] * 20) + "</main>")
            before = backup.read_bytes()

            held = self.run_cli(
                "workspace", "assess-page-watch", str(backup), "steady-watch", str(first), "--json",
            )
            self.assertEqual(held.returncode, 0, held.stderr)
            held_report = json.loads(held.stdout)
            self.assertEqual(held_report["result"], "hold")
            self.assertEqual(held_report["pageAlertsWritten"], 0)
            self.assertFalse(held_report["writes"])

            confirmed = self.run_cli(
                "workspace", "assess-page-watch", str(backup), "steady-watch", str(first),
                "--confirm-html", str(second), "--json",
            )
            self.assertEqual(confirmed.returncode, 0, confirmed.stderr)
            confirmed_report = json.loads(confirmed.stdout)
            self.assertEqual(confirmed_report["result"], "confirmed-new-shape")
            self.assertEqual(backup.read_bytes(), before)

    def test_workspace_page_watch_repair_review_and_apply(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            backup = Path(temp) / "watch.json"
            specimen = Path(temp) / "watch.html"
            output = Path(temp) / "repaired.json"
            document = json.loads((FIX / "sample-backup.json").read_text())
            document["state"]["sources"].append({
                "id": "page-watch", "type": "page", "title": "Town notices",
                "url": "https://example.test/notices", "enabled": True, "mode": "cards",
                "selector": ".gone", "titleSelector": "h2", "linkSelector": "a[href]", "threshold": 4,
                "watchRepair": {"schema": "progrss.page-watch.repair.v1", "reason": "no-match", "noticedAt": "2026-10-19T00:00:00Z", "message": "Missing"},
            })
            backup.write_text(json.dumps(document))
            specimen.write_text("<main><article><h2>One</h2></article><article><h2>Two</h2></article></main>")
            review = self.run_cli("workspace", "review-page-watch", str(backup), "page-watch", str(specimen), "--json")
            self.assertEqual(review.returncode, 0, review.stderr)
            report = json.loads(review.stdout)
            self.assertEqual(report["schema"], "progrss.page-watch.repair-review.v1")
            self.assertFalse(report["network"])
            proposal = report["proposals"][0]["id"]
            repaired = self.run_cli(
                "workspace", "repair-page-watch", str(backup), "page-watch", str(specimen),
                "--proposal", proposal, "--output", str(output),
            )
            self.assertEqual(repaired.returncode, 0, repaired.stderr)
            self.assertIn("Fresh baseline", repaired.stdout)
            result = json.loads(output.read_text())
            source = next(row for row in result["state"]["sources"] if row["id"] == "page-watch")
            self.assertNotIn("watchRepair", source)
            self.assertEqual(source["lastOutcome"], "baseline")
            repeat = self.run_cli(
                "workspace", "repair-page-watch", str(backup), "page-watch", str(specimen),
                "--proposal", proposal, "--output", str(output),
            )
            self.assertEqual(repeat.returncode, 2)
            self.assertIn("already exists", repeat.stderr)

    def test_workspace_compare_copies_is_offline_read_only_and_private_by_default(self) -> None:
        same = self.run_cli(
            "workspace", "compare-copies", str(FIX / "sample-backup.json"),
            str(FIX / "sample-backup.json"), "--json",
        )
        self.assertEqual(same.returncode, 0, same.stderr)
        same_doc = json.loads(same.stdout)
        self.assertEqual(same_doc["schema"], "progrss.workspace.copy-comparison.v1")
        self.assertEqual(same_doc["state"], "same")
        self.assertTrue(same_doc["samePortableLibrary"])
        self.assertFalse(same_doc["network"])
        self.assertFalse(same_doc["writes"])

        with tempfile.TemporaryDirectory() as temp:
            changed_path = Path(temp) / "changed.json"
            changed = json.loads((FIX / "sample-backup.json").read_text())
            changed["exportedAt"] = "2026-10-18T12:01:00Z"
            changed["state"]["items"].append({
                "id": "feed-existing|later", "sourceId": "feed-existing",
                "title": "Later update", "url": "https://example.test/later",
                "summary": "A later retained update", "observedAt": "2026-10-18T12:00:00Z",
                "readAt": "", "starred": False,
            })
            changed_path.write_text(json.dumps(changed))
            result = self.run_cli(
                "workspace", "compare-copies", str(FIX / "sample-backup.json"),
                str(changed_path),
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("Same portable library: no", result.stdout)
            self.assertIn("Updates: +1", result.stdout)
            self.assertIn("offline", result.stdout)
            self.assertIn("no writes", result.stdout)
            self.assertNotIn("https://example.test/feed.xml", result.stdout)
            self.assertNotIn("Existing Feed", result.stdout)

            required = self.run_cli(
                "workspace", "compare-copies", str(FIX / "sample-backup.json"),
                str(changed_path), "--require-match",
            )
            self.assertEqual(required.returncode, 3, required.stderr)
            self.assertIn("Required match: no", required.stdout)

            required_json = self.run_cli(
                "workspace", "compare-copies", str(FIX / "sample-backup.json"),
                str(changed_path), "--require-match", "--json",
            )
            self.assertEqual(required_json.returncode, 3, required_json.stderr)
            self.assertEqual(json.loads(required_json.stdout)["state"], "different")

    def test_feed_corpus_command_is_offline_and_complete(self) -> None:
        result = self.run_cli("feed", "corpus", "--json")
        self.assertEqual(result.returncode, 0, result.stderr)
        doc = json.loads(result.stdout)
        self.assertEqual((doc["passed"], doc["total"], doc["failed"]), (32, 32, 0))
        self.assertFalse(doc["network"])
        self.assertFalse(doc["writes"])

    def test_feed_json_output(self) -> None:
        result = self.run_cli("feed", "inspect", str(FIX / "sample-rss.xml"), "--url", "https://example.test/feed.xml", "--json")
        self.assertEqual(result.returncode, 0, result.stderr)
        doc = json.loads(result.stdout)
        self.assertEqual(doc["itemCount"], 2)
        self.assertFalse(doc["network"])

        self_link = self.run_cli(
            "feed", "inspect", str(FIX / "interoperability" / "rss-atom-self.xml"),
            "--url", "https://rss-self.example/alternate.xml", "--json",
        )
        self.assertEqual(self_link.returncode, 0, self_link.stderr)
        self.assertEqual(json.loads(self_link.stdout)["feedUrl"], "https://rss-self.example/feeds/primary.xml")

    def test_feed_preview_is_compact_offline_and_body_free(self) -> None:
        result = self.run_cli(
            "feed", "preview", str(FIX / "sample-rss.xml"),
            "--url", "https://example.test/feed.xml", "--limit", "1", "--json",
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        doc = json.loads(result.stdout)
        self.assertEqual(doc["schema"], "progrss.feed.preview.v1")
        self.assertEqual(doc["itemCount"], 2)
        self.assertEqual(doc["exampleCount"], 1)
        self.assertFalse(doc["network"])
        self.assertFalse(doc["writes"])
        self.assertEqual(set(doc["examples"][0]), {"title", "url", "published", "content", "language", "titleLanguage"})
        self.assertNotIn("body", doc["examples"][0])
        self.assertNotIn("summary", doc["examples"][0])

        text_result = self.run_cli(
            "feed", "preview", str(FIX / "sample-rss.xml"),
            "--url", "https://example.test/feed.xml", "--limit", "2",
        )
        self.assertEqual(text_result.returncode, 0, text_result.stderr)
        self.assertIn("2 shown · offline", text_result.stdout)
        self.assertIn("Nothing followed · no writes", text_result.stdout)

    def test_feed_fetch_follows_only_same_site_redirects(self) -> None:
        feed = b'<?xml version="1.0"?><rss version="2.0"><channel><title>Redirected</title><item><guid>x</guid><title>One</title></item></channel></rss>'
        class Destination(QuietHandler):
            routes = {"/feed.xml": (200, {"Content-Type": "application/rss+xml", "Content-Length": str(len(feed))}, feed)}
            hits = []
        destination, destination_thread = start_server(Destination)
        class Origin(QuietHandler):
            routes = {}
            hits = []
        origin, origin_thread = start_server(Origin)
        try:
            origin_url = f"http://127.0.0.1:{origin.server_port}"
            destination_url = f"http://127.0.0.1:{destination.server_port}"
            Origin.routes = {
                "/same": (301, {"Location": "/feed.xml"}, b""),
                "/feed.xml": (200, {"Content-Type": "application/rss+xml", "Content-Length": str(len(feed))}, feed),
                "/cross": (302, {"Location": destination_url + "/feed.xml"}, b""),
                "/loop-a": (302, {"Location": "/loop-b"}, b""),
                "/loop-b": (302, {"Location": "/loop-a"}, b""),
            }
            with tempfile.TemporaryDirectory() as temp:
                same_output = Path(temp) / "same.xml"
                same = self.run_cli("feed", "fetch", origin_url + "/same", "--output", str(same_output))
                self.assertEqual(same.returncode, 0, same.stderr)
                self.assertEqual(same_output.read_bytes(), feed)
                self.assertIn("followed 1 same-site redirect", same.stdout)
                self.assertIn(origin_url + "/feed.xml", same.stdout)

                cross_output = Path(temp) / "cross.xml"
                cross = self.run_cli("feed", "fetch", origin_url + "/cross", "--output", str(cross_output))
                self.assertEqual(cross.returncode, 2)
                self.assertFalse(cross_output.exists())
                self.assertIn("stopped before contacting the new site", cross.stderr)
                self.assertIn(destination_url + "/feed.xml", cross.stderr)
                self.assertEqual(Destination.hits, [], "cross-site destination must not be contacted")

                loop_output = Path(temp) / "loop.xml"
                loop = self.run_cli("feed", "fetch", origin_url + "/loop-a", "--output", str(loop_output))
                self.assertEqual(loop.returncode, 2)
                self.assertFalse(loop_output.exists())
                self.assertIn("redirect loop", loop.stderr)
        finally:
            origin.shutdown(); destination.shutdown()
            origin.server_close(); destination.server_close()
            origin_thread.join(timeout=2); destination_thread.join(timeout=2)

    def test_workspace_read_is_plain_text_offline_and_body_searchable(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            backup = Path(temp) / "reading.json"
            document = json.loads((FIX / "sample-backup.json").read_text())
            item = document["state"]["items"][1]
            item["body"] = "A useful note about climate adaptation.\n\nThe resilience cabinet map is in the full feed text."
            item["bodyIsSummary"] = False
            item["language"] = "ar"
            item["titleLanguage"] = "en"
            item["bodyLanguage"] = "ar"
            document["state"]["version"] = 16
            backup.write_text(json.dumps(document))

            read = self.run_cli("workspace", "read", str(backup), item["id"], "--json")
            self.assertEqual(read.returncode, 0, read.stderr)
            report = json.loads(read.stdout)
            self.assertEqual(report["schema"], "progrss.workspace.reading.v1")
            self.assertIn("resilience cabinet map", report["body"])
            self.assertFalse(report["bodyIsSummary"])
            self.assertEqual(report["language"], "ar")
            self.assertEqual(report["titleLanguage"], "en")
            self.assertEqual(report["bodyLanguage"], "ar")
            self.assertFalse(report["network"])
            self.assertFalse(report["writes"])

            human = self.run_cli("workspace", "read", str(backup), "Unread and saved")
            self.assertEqual(human.returncode, 0, human.stderr)
            self.assertIn("Feed-supplied text", human.stdout)
            self.assertIn("resilience cabinet map", human.stdout)

            query = self.run_cli("workspace", "query", str(backup), "--contains", "cabinet map", "--json")
            self.assertEqual(query.returncode, 0, query.stderr)
            query_doc = json.loads(query.stdout)
            self.assertEqual(query_doc["count"], 1)
            self.assertIn("resilience cabinet map", query_doc["items"][0]["body"])
            self.assertEqual(query_doc["items"][0]["language"], "ar")
            self.assertEqual(query_doc["items"][0]["titleLanguage"], "en")
            self.assertEqual(query_doc["items"][0]["bodyLanguage"], "ar")

    def test_workspace_page_changes_are_explained_offline(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            backup = Path(temp) / "page-changes.json"
            document = json.loads((FIX / "sample-backup.json").read_text())
            document["state"]["items"].append({
                "id": "page-weather|change", "sourceId": "page-weather",
                "title": "Town noticeboard changed", "url": "https://weather.test/",
                "summary": "Changed Monday to Tuesday", "observedAt": "2026-10-18T18:00:00Z",
                "readAt": "", "starred": False,
                "change": {
                    "schema": "progrss.page-change.v1", "kind": "text-changed", "mode": "region",
                    "summary": "Changed Monday to Tuesday",
                    "before": "Library opens Monday at 9.", "after": "Library opens Tuesday at 10.",
                    "removed": "Monday at 9", "added": "Tuesday at 10",
                    "removedWords": 3, "addedWords": 3, "delta": 13,
                    "threshold": 4, "ignoreNumbers": False,
                },
            })
            backup.write_text(json.dumps(document))

            result = self.run_cli("workspace", "page-changes", str(backup), "--unread-only", "--json")
            self.assertEqual(result.returncode, 0, result.stderr)
            report = json.loads(result.stdout)
            self.assertEqual(report["schema"], "progrss.workspace.page-changes.v1")
            self.assertEqual(report["count"], 1)
            self.assertEqual(report["changes"][0]["change"]["after"], "Library opens Tuesday at 10.")
            self.assertFalse(report["network"])
            self.assertFalse(report["writes"])

            human = self.run_cli("workspace", "read", str(backup), "page-weather|change")
            self.assertEqual(human.returncode, 0, human.stderr)
            self.assertIn("Before\nLibrary opens Monday at 9.", human.stdout)
            self.assertIn("Now\nLibrary opens Tuesday at 10.", human.stdout)
            self.assertIn("Offline · no writes", human.stdout)

            query = self.run_cli("workspace", "query", str(backup), "--contains", "Tuesday at 10", "--json")
            self.assertEqual(query.returncode, 0, query.stderr)
            self.assertEqual(json.loads(query.stdout)["items"][0]["pageChange"]["kind"], "text-changed")

    def test_workspace_query(self) -> None:
        result = self.run_cli("workspace", "query", str(FIX / "sample-backup.json"), "--unread-only", "--json")
        self.assertEqual(result.returncode, 0, result.stderr)
        doc = json.loads(result.stdout)
        self.assertEqual(doc["count"], 1)
        self.assertEqual(doc["items"][0]["title"], "Unread and saved")


    def test_workspace_folders_and_folder_scope(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "folders.json"
            document = json.loads((FIX / "sample-backup.json").read_text())
            document["state"]["sources"].append({
                "id": "feed-unfiled", "title": "Unfiled Notes", "type": "rss",
                "url": "https://unfiled.test/feed.xml", "enabled": True, "archivedAt": "",
            })
            document["state"]["collections"] = [
                {"id": "reading", "title": "Reading", "mode": "union", "members": [
                    {"kind": "source", "id": "feed-existing"}, {"kind": "collection", "id": "later"}
                ]},
                {"id": "later", "title": "Later", "mode": "union", "members": [
                    {"kind": "source", "id": "page-weather"}
                ]},
            ]
            source.write_text(json.dumps(document))
            folders = self.run_cli("workspace", "folders", str(source), "--json")
            self.assertEqual(folders.returncode, 0, folders.stderr)
            report = json.loads(folders.stdout)
            self.assertEqual([row["path"] for row in report["folders"]], ["Reading", "Reading › Later", "Unfiled"])
            self.assertFalse(report["network"])
            query = self.run_cli("workspace", "query", str(source), "--folder", "Reading", "--json")
            self.assertEqual(query.returncode, 0, query.stderr)
            queried = json.loads(query.stdout)
            self.assertEqual(queried["folder"]["label"], "Reading")
            self.assertEqual(queried["count"], 2)
            sources = self.run_cli("workspace", "sources", str(source), "--folder", "Reading › Later", "--json")
            self.assertEqual(sources.returncode, 0, sources.stderr)
            scoped = json.loads(sources.stdout)
            self.assertEqual(scoped["count"], 1)
            self.assertEqual(scoped["sources"][0]["id"], "page-weather")

            placed = Path(temp) / "placed.json"
            placement = self.run_cli(
                "workspace", "place-source", str(source), "feed-unfiled", "Reading › Later",
                "--output", str(placed),
            )
            self.assertEqual(placement.returncode, 0, placement.stderr)
            self.assertIn("also appears in Reading", placement.stdout)
            placed_doc = json.loads(placed.read_text())
            later = next(row for row in placed_doc["state"]["collections"] if row["id"] == "later")
            self.assertIn({"kind": "source", "id": "feed-unfiled"}, later["members"])
            self.assertNotIn("_revision", placed_doc["state"])
            self.assertNotIn("transferUndo", placed_doc["state"])
            repeat = self.run_cli(
                "workspace", "place-source", str(placed), "feed-unfiled", "later",
                "--output", str(Path(temp) / "repeat.json"),
            )
            self.assertEqual(repeat.returncode, 2)
            self.assertIn("already directly", repeat.stderr)

            removed = Path(temp) / "removed.json"
            removal = self.run_cli(
                "workspace", "remove-from-folder", str(placed), "feed-unfiled", "Reading › Later",
                "--output", str(removed),
            )
            self.assertEqual(removal.returncode, 0, removal.stderr)
            self.assertIn("Removed Unfiled Notes from Reading › Later", removal.stdout)
            removed_doc = json.loads(removed.read_text())
            later = next(row for row in removed_doc["state"]["collections"] if row["id"] == "later")
            self.assertNotIn({"kind": "source", "id": "feed-unfiled"}, later["members"])
            self.assertNotIn("_revision", removed_doc["state"])
            self.assertNotIn("transferUndo", removed_doc["state"])

            inherited_only = self.run_cli(
                "workspace", "remove-from-folder", str(placed), "feed-unfiled", "Reading",
                "--output", str(Path(temp) / "inherited-only.json"),
            )
            self.assertEqual(inherited_only.returncode, 2)
            self.assertIn("only through a nested folder", inherited_only.stderr)

    def test_workspace_source_note_edits_one_direct_placement_offline(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "source-notes.json"
            document = json.loads((FIX / "sample-backup.json").read_text())
            document["state"]["collections"] = [
                {"id": "reading", "title": "Reading", "mode": "union", "version": 3, "members": [
                    {"kind": "source", "id": "feed-existing", "reason": "Broad reading context."},
                    {"kind": "collection", "id": "practical"},
                ]},
                {"id": "practical", "title": "Practical", "mode": "union", "version": 4, "members": [
                    {"kind": "source", "id": "feed-existing", "reason": "Earlier practical reason."},
                ]},
            ]
            source.write_text(json.dumps(document))

            edited = Path(temp) / "edited.json"
            result = self.run_cli(
                "workspace", "source-note", str(source), "feed-existing", "Reading › Practical",
                "--reason", "  Repair instructions for this route. 🧰  ", "--output", str(edited),
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("local only", result.stdout)
            self.assertIn("Nothing was published, contacted, scheduled", result.stdout)
            edited_doc = json.loads(edited.read_text())
            reading = next(row for row in edited_doc["state"]["collections"] if row["id"] == "reading")
            practical = next(row for row in edited_doc["state"]["collections"] if row["id"] == "practical")
            self.assertEqual(reading["members"][0]["reason"], "Broad reading context.")
            self.assertEqual(practical["members"][0]["reason"], "Repair instructions for this route. 🧰")
            self.assertEqual(reading["version"], 3)
            self.assertEqual(practical["version"], 5)
            self.assertNotIn("_revision", edited_doc["state"])
            self.assertNotIn("transferUndo", edited_doc["state"])

            cleared = Path(temp) / "cleared.json"
            clear = self.run_cli(
                "workspace", "source-note", str(edited), "feed-existing", "practical",
                "--clear", "--output", str(cleared),
            )
            self.assertEqual(clear.returncode, 0, clear.stderr)
            cleared_doc = json.loads(cleared.read_text())
            practical = next(row for row in cleared_doc["state"]["collections"] if row["id"] == "practical")
            self.assertNotIn("reason", practical["members"][0])
            self.assertEqual(practical["version"], 6)

            unchanged = self.run_cli(
                "workspace", "source-note", str(cleared), "feed-existing", "practical",
                "--reason", "   ", "--output", str(Path(temp) / "unchanged.json"),
            )
            self.assertEqual(unchanged.returncode, 2)
            self.assertIn("already unchanged", unchanged.stderr)

            too_long = self.run_cli(
                "workspace", "source-note", str(cleared), "feed-existing", "practical",
                "--reason", "x" * 281, "--output", str(Path(temp) / "too-long.json"),
            )
            self.assertEqual(too_long.returncode, 2)
            self.assertIn("280 Unicode code points", too_long.stderr)

            inherited_doc = json.loads(source.read_text())
            inherited_doc["state"]["collections"][0]["members"] = [{"kind": "collection", "id": "practical"}]
            inherited = Path(temp) / "inherited.json"
            inherited.write_text(json.dumps(inherited_doc))
            inherited_result = self.run_cli(
                "workspace", "source-note", str(inherited), "feed-existing", "Reading",
                "--reason", "Wrong level", "--output", str(Path(temp) / "inherited-output.json"),
            )
            self.assertEqual(inherited_result.returncode, 2)
            self.assertIn("only through a nested folder", inherited_result.stderr)

            overwrite = self.run_cli(
                "workspace", "source-note", str(source), "feed-existing", "practical",
                "--reason", "Another reason", "--output", str(edited),
            )
            self.assertEqual(overwrite.returncode, 2)
            self.assertIn("already exists", overwrite.stderr)

    def test_workspace_duplicate_source_audit_and_explicit_combine(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "duplicates.json"
            output = Path(temp) / "combined.json"
            document = json.loads((FIX / "sample-backup.json").read_text())
            document["state"]["version"] = 13
            original = document["state"]["sources"][0]
            original["declaredFeedUrl"] = original["url"]
            original["httpCache"] = {"etag": '"keep-me"'}
            original["pulse"] = {"nextAt": "2026-10-20T12:00:00Z"}
            document["state"]["sources"].append({
                "id": "feed-copy", "title": "Existing Feed copy", "type": "rss",
                "url": "https://existing.test/alternate.xml",
                "declaredFeedUrl": original["url"], "enabled": False, "archivedAt": "",
                "httpCache": {"lastModified": "Fri, 17 Oct 2026 10:00:00 GMT"},
            })
            repeated = dict(document["state"]["items"][1])
            repeated.update({
                "id": "feed-copy|old-1", "entryKey": "feed-copy|old-1", "sourceId": "feed-copy",
                "readAt": "2026-10-18T11:00:00Z", "starred": False,
            })
            document["state"]["items"].append(repeated)
            document["state"]["collections"] = [{
                "id": "reading", "title": "Reading", "mode": "union", "version": 1,
                "members": [{"kind": "source", "id": "feed-existing"}, {"kind": "source", "id": "feed-copy"}],
            }]
            document["state"]["_revision"] = 9
            document["state"]["transferUndo"] = {"schema": "progrss.transfer.undo.v1"}
            document["state"]["sourceRepairUndo"] = {"schema": "progrss.source.repair.undo.v1"}
            source.write_text(json.dumps(document))

            audit = self.run_cli("workspace", "duplicate-sources", str(source), "--json")
            self.assertEqual(audit.returncode, 0, audit.stderr)
            report = json.loads(audit.stdout)
            self.assertEqual(report["candidatePairs"], 1)
            self.assertTrue(report["pairs"][0]["canCombine"])
            self.assertEqual(report["pairs"][0]["sharedAddresses"], ["https://existing.test/feed.xml"])
            self.assertFalse(report["network"])
            self.assertFalse(report["writes"])
            self.assertFalse(report["browserProfileRead"])

            combined = self.run_cli(
                "workspace", "combine-sources", str(source), "feed-existing", "feed-copy",
                "--keep", "feed-existing", "--output", str(output),
            )
            self.assertEqual(combined.returncode, 0, combined.stderr)
            self.assertIn("Kept the selected source's current address", combined.stdout)
            result = json.loads(output.read_text())
            self.assertEqual(result["state"]["version"], 17)
            self.assertFalse(any(row.get("id") == "feed-copy" for row in result["state"]["sources"]))
            survivor = next(row for row in result["state"]["sources"] if row.get("id") == "feed-existing")
            self.assertEqual(survivor["httpCache"], {"etag": '"keep-me"'})
            self.assertIn("https://existing.test/alternate.xml", survivor["aliasUrls"])
            self.assertEqual(result["state"]["collections"][0]["members"], [{"kind": "source", "id": "feed-existing"}])
            self.assertNotIn("_revision", result["state"])
            self.assertNotIn("transferUndo", result["state"])
            self.assertNotIn("sourceRepairUndo", result["state"])

            repeat = self.run_cli(
                "workspace", "combine-sources", str(source), "feed-existing", "feed-copy",
                "--keep", "feed-existing", "--output", str(output),
            )
            self.assertEqual(repeat.returncode, 2)
            self.assertIn("already exists", repeat.stderr)

    def test_workspace_source_references_is_read_only_and_names_records(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "references.json"
            document = json.loads((FIX / "sample-backup.json").read_text())
            original = document["state"]["sources"][0]
            document["state"]["sources"].append({
                "id": "feed-copy", "title": "Existing Feed copy", "type": "rss",
                "url": "https://existing.test/alternate.xml",
                "declaredFeedUrl": original["url"], "enabled": False, "archivedAt": "",
            })
            document["state"]["receipts"] = [{
                "id": "graft-receipt", "schema": "progrss.recipe.graft.receipt.v1",
                "title": "Reviewed garden graft", "sourceId": "feed-copy",
                "evidence": {"itemId": document["state"]["items"][0]["id"]},
            }]
            source.write_text(json.dumps(document))
            before = source.read_bytes()

            audit = self.run_cli(
                "workspace", "source-references", str(source), "feed-existing", "feed-copy", "--json",
            )
            self.assertEqual(audit.returncode, 0, audit.stderr)
            report = json.loads(audit.stdout)
            self.assertEqual(report["schema"], "progrss.source-reference-report.v1")
            self.assertEqual(report["summary"]["blockingRecords"], 1)
            self.assertEqual(report["summary"]["exactReferences"], 2)
            self.assertEqual(report["groups"][0]["records"][0]["title"], "Reviewed garden graft")
            self.assertFalse(report["network"])
            self.assertFalse(report["writes"])
            self.assertFalse(report["browserProfileRead"])

            human = self.run_cli(
                "workspace", "source-references", str(source), "feed-existing", "feed-copy", "--paths",
            )
            self.assertEqual(human.returncode, 0, human.stderr)
            self.assertIn("References to Existing Feed and Existing Feed copy", human.stdout)
            self.assertIn("Reviewed garden graft", human.stdout)
            self.assertIn('$["sourceId"]', human.stdout)
            self.assertIn("offline · no writes · no browser-profile read", human.stdout)
            self.assertEqual(source.read_bytes(), before)

            retired = Path(temp) / "retired.json"
            retirement = self.run_cli(
                "workspace", "retire-graft-receipt", str(source), "feed-existing", "feed-copy",
                "graft-receipt", "--output", str(retired),
            )
            self.assertEqual(retirement.returncode, 0, retirement.stderr)
            self.assertIn("without rewriting it", retirement.stdout)
            self.assertIn("offline · new-file-only", retirement.stdout)
            self.assertEqual(source.read_bytes(), before, "the source backup remains unchanged")
            retired_doc = json.loads(retired.read_text())
            self.assertEqual(retired_doc["state"]["version"], 17)
            self.assertEqual(retired_doc["state"]["receipts"], [])
            self.assertEqual(len(retired_doc["state"]["retiredReceipts"]), 1)
            envelope = retired_doc["state"]["retiredReceipts"][0]
            self.assertEqual(envelope["originalReceipt"], document["state"]["receipts"][0])
            self.assertRegex(envelope["originalDigest"], r"^[0-9a-f]{64}$")
            self.assertNotIn("receiptRetirementUndo", retired_doc["state"])

            integrity = self.run_cli("workspace", "retired-receipts", str(retired), "--json")
            self.assertEqual(integrity.returncode, 0, integrity.stderr)
            integrity_doc = json.loads(integrity.stdout)
            self.assertEqual(integrity_doc["retiredReceipts"], 1)
            self.assertEqual(integrity_doc["receipts"][0]["integrity"], "matches")
            self.assertFalse(integrity_doc["network"])
            self.assertFalse(integrity_doc["writes"])

            after = self.run_cli(
                "workspace", "source-references", str(retired), "feed-existing", "feed-copy", "--json",
            )
            self.assertEqual(after.returncode, 0, after.stderr)
            after_report = json.loads(after.stdout)
            self.assertEqual(after_report["summary"]["blockingRecords"], 0)
            self.assertEqual(after_report["summary"]["retiredRecords"], 1)

            combined = Path(temp) / "combined-after-retirement.json"
            combine = self.run_cli(
                "workspace", "combine-sources", str(retired), "feed-existing", "feed-copy",
                "--keep", "feed-existing", "--output", str(combined),
            )
            self.assertEqual(combine.returncode, 0, combine.stderr)
            combined_doc = json.loads(combined.read_text())
            self.assertEqual(len(combined_doc["state"]["retiredReceipts"]), 1)
            self.assertFalse(any(row.get("id") == "feed-copy" for row in combined_doc["state"]["sources"]))

            repeat = self.run_cli(
                "workspace", "retire-graft-receipt", str(source), "feed-existing", "feed-copy",
                "graft-receipt", "--output", str(retired),
            )
            self.assertEqual(repeat.returncode, 2)
            self.assertIn("already exists", repeat.stderr)

    def test_workspace_text_storage_and_retention_commands(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "storage.json"
            trimmed = Path(temp) / "trimmed.json"
            document = json.loads((FIX / "sample-backup.json").read_text())
            document["state"]["version"] = 16
            document["state"]["items"][0].update({
                "body": "Read full text that can be cleared.", "bodyIsSummary": False, "starred": False,
            })
            document["state"]["items"][1].update({
                "body": "Unread saved full text that stays.", "bodyIsSummary": False,
            })
            source.write_text(json.dumps(document))

            audit = self.run_cli("workspace", "text-storage", str(source), "--json")
            self.assertEqual(audit.returncode, 0, audit.stderr)
            report = json.loads(audit.stdout)
            self.assertEqual(report["schema"], "progrss.workspace.text-storage.v1")
            self.assertEqual(report["fullTextItems"], 2)
            self.assertEqual(report["cleanupEligibleItems"], 1)
            self.assertFalse(report["network"])
            self.assertFalse(report["writes"])
            self.assertFalse(report["browserProfileRead"])

            change = self.run_cli(
                "workspace", "set-text-retention", str(source), "Existing Feed", "summary",
                "--trim-read", "--output", str(trimmed),
            )
            self.assertEqual(change.returncode, 0, change.stderr)
            self.assertIn("trimmed 1 read, unsaved update", change.stdout)
            self.assertIn("input backup remains the rollback copy", change.stdout)
            result = json.loads(trimmed.read_text())
            self.assertEqual(result["state"]["version"], 17)
            feed = next(row for row in result["state"]["sources"] if row["id"] == "feed-existing")
            self.assertEqual(feed["textRetention"], "summary")
            items = {row["title"]: row for row in result["state"]["items"]}
            self.assertTrue(items["Already read"]["bodyOmitted"])
            self.assertEqual(items["Already read"]["body"], items["Already read"]["summary"])
            self.assertEqual(items["Unread and saved"]["body"], "Unread saved full text that stays.")

            repeat = self.run_cli(
                "workspace", "set-text-retention", str(source), "Existing Feed", "summary",
                "--trim-read", "--output", str(trimmed),
            )
            self.assertEqual(repeat.returncode, 2)
            self.assertIn("already exists", repeat.stderr)

    def test_workspace_sources_json(self) -> None:
        result = self.run_cli("workspace", "sources", str(FIX / "sample-backup.json"), "--json")
        self.assertEqual(result.returncode, 0, result.stderr)
        doc = json.loads(result.stdout)
        self.assertEqual(doc["schema"], "progrss.workspace.sources.v1")
        self.assertEqual(doc["count"], 2)
        self.assertFalse(doc["network"])

    def test_workspace_transfer_audit_hides_origins_until_requested(self) -> None:
        hidden = self.run_cli("workspace", "transfer-audit", str(FIX / "sample-backup.json"), "--json")
        self.assertEqual(hidden.returncode, 0, hidden.stderr)
        doc = json.loads(hidden.stdout)
        self.assertEqual(doc["schema"], "progrss.workspace.transfer-audit.v1")
        self.assertEqual(doc["destination"]["upToReconnectSources"], 1)
        self.assertFalse(doc["destination"]["originsIncluded"])
        self.assertEqual(doc["destination"]["origins"], [])
        self.assertFalse(doc["network"])
        self.assertFalse(doc["writes"])

        shown = self.run_cli("workspace", "transfer-audit", str(FIX / "sample-backup.json"), "--origins")
        self.assertEqual(shown.returncode, 0, shown.stderr)
        self.assertIn("https://existing.test", shown.stdout)
        self.assertIn("offline · no writes", shown.stdout)

    def test_workspace_import_opml_command(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "imported.json"
            result = self.run_cli(
                "workspace", "import-opml", str(FIX / "sample-backup.json"),
                str(FIX / "sample-subscriptions.opml"), "--output", str(output),
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(output.is_file())
            self.assertIn("No network access", result.stdout)
            doc = json.loads(output.read_text())
            self.assertEqual(len([row for row in doc["state"]["sources"] if row.get("origin") == "cli-opml-import"]), 2)

    def test_workspace_edition_is_summary_only_offline_and_no_overwrite(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            backup = root / "library.json"
            output = root / "edition.json"
            document = json.loads((FIX / "sample-backup.json").read_text())
            document["state"]["collections"] = [{
                "id": "reading",
                "title": "Reading",
                "mode": "union",
                "members": [
                    {"kind": "source", "id": "feed-existing"},
                    {"kind": "source", "id": "page-weather"},
                ],
            }]
            document["state"]["items"][1]["body"] = "Private full text that must not leave the library."
            document["state"]["items"][1]["language"] = "en"
            document["state"]["items"].append({
                "id": "page-weather|change-1",
                "entryKey": "page-weather|change-1",
                "sourceId": "page-weather",
                "title": "Town notice changed",
                "summary": "The meeting time changed.",
                "url": "https://town.test/notices",
                "published": "2026-10-18T12:00:00Z",
                "observedAt": "2026-10-18T12:01:00Z",
                "kind": "changed",
                "readAt": "",
                "starred": True,
                "change": {
                    "kind": "text-changed",
                    "summary": "The meeting time changed.",
                    "before": "Monday at 9",
                    "after": "Tuesday at 10",
                },
            })
            backup.write_text(json.dumps(document), encoding="utf-8")

            result = self.run_cli(
                "workspace", "edition", str(backup), "Reading",
                "--curator", "Neighborhood desk",
                "--note", "A small public edition.",
                "--limit", "2",
                "--output", str(output),
                "--json",
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            report = json.loads(result.stdout)
            self.assertEqual(report["schema"], "progrss.folder-edition.result.v1")
            self.assertEqual(report["items"], 2)
            self.assertFalse(report["network"] )
            self.assertTrue(report["writes"] )
            self.assertTrue(report["newFileOnly"] )

            feed = json.loads(output.read_text())
            self.assertEqual(feed["version"], "https://jsonfeed.org/version/1.1")
            self.assertEqual(feed["_progrss"]["schema"], "progrss.folder-edition.v1")
            self.assertEqual(feed["authors"], [{"name": "Neighborhood desk"}])
            self.assertEqual(feed["description"], "A small public edition.")
            raw = output.read_text()
            self.assertNotIn("Private full text", raw)
            self.assertNotIn("Monday at 9", raw)
            self.assertNotIn("Tuesday at 10", raw)
            self.assertNotIn('"readAt"', raw)
            self.assertNotIn('"starred"', raw)
            self.assertTrue(feed["_progrss"]["excluded"]["fullRetainedText"] )
            self.assertTrue(feed["_progrss"]["excluded"]["readingState"] )
            self.assertTrue(feed["_progrss"]["excluded"]["pageWatchEvidence"] )

            repeat = self.run_cli(
                "workspace", "edition", str(backup), "Reading",
                "--output", str(output),
            )
            self.assertEqual(repeat.returncode, 2)
            self.assertIn("already exists", repeat.stderr)

    def test_publication_site_commands_are_offline_script_free_and_no_overwrite(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            backup = root / "library.json"
            site = root / "published.zip"
            rebuilt = root / "rebuilt.zip"
            bundle_file = root / "latest.json"
            document = {
                "schema": "progrss.private.v1",
                "exportedAt": "2026-10-18T20:00:00Z",
                "state": {
                    "version": 17,
                    "sources": [
                        {"id": "feed", "type": "rss", "title": "Garden feed", "url": "https://example.test/feed.xml", "enabled": True},
                        {"id": "watch", "type": "page", "title": "Workshop page", "url": "https://example.test/workshops", "enabled": True, "mode": "region", "selector": "main", "threshold": 24},
                    ],
                    "collections": [
                        {"id": "shared", "title": "Neighborhood reading", "mode": "union", "members": [
                            {"kind": "source", "id": "feed", "reason": "Useful for Saturday garden hours."}, {"kind": "source", "id": "watch"},
                        ]}
                    ],
                    "items": [
                        {
                            "id": "feed-item-1",
                            "sourceId": "feed",
                            "title": "Garden hours",
                            "summary": "Open Saturday morning.",
                            "body": "Private retained body that must not be published.",
                            "url": "https://example.test/posts/garden-hours",
                            "published": "2026-10-19T04:00:00Z",
                            "observedAt": "2026-10-19T04:05:00Z",
                            "readAt": "2026-10-19T05:00:00Z",
                            "starred": True,
                        }
                    ],
                },
            }
            backup.write_text(json.dumps(document), encoding="utf-8")
            result = self.run_cli(
                "workspace", "publish-folder", str(backup), "Neighborhood reading",
                "--update-url", "https://example.test/shared/latest.json",
                "--curator", "Neighborhood desk", "--note", "A practical list.",
                "--include-updates", "--update-limit", "20",
                "--output", str(site), "--json",
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            report = json.loads(result.stdout)
            self.assertEqual(report["schema"], "progrss.publication-site.v1")
            self.assertEqual(report["updateFile"], "latest.json")
            self.assertFalse(report["automaticChecks"])
            self.assertEqual(report["networkRequests"], 0)
            self.assertTrue(report["recentUpdatesIncluded"])
            self.assertEqual(report["updates"], 1)
            self.assertEqual(report["sourceNotes"], 1)
            edition_file = root / "recent-updates.json"
            with zipfile.ZipFile(site, "r") as archive:
                self.assertEqual(set(archive.namelist()), {"index.html", "latest.json", "subscriptions.opml", "recent-updates.json", "README.txt"})
                page = archive.read("index.html").decode("utf-8")
                self.assertNotIn("<script", page.lower())
                self.assertIn("no scripts, trackers, remote images, or automatic update checks", page.lower())
                self.assertIn("Curator’s reason for this folder:", page)
                self.assertIn("Useful for Saturday garden hours.", page)
                self.assertIn("not a ProgRSS safety claim", page)
                self.assertNotIn("https://example.test/workshops", archive.read("subscriptions.opml").decode("utf-8"))
                self.assertNotIn("Useful for Saturday garden hours.", archive.read("subscriptions.opml").decode("utf-8"))
                recent = json.loads(archive.read("recent-updates.json"))
                self.assertEqual(recent["feed_url"], "https://example.test/shared/recent-updates.json")
                self.assertEqual(recent["home_page_url"], "https://example.test/shared/index.html")
                self.assertEqual(recent["items"][0]["content_text"], "Open Saturday morning.")
                recent_raw = json.dumps(recent)
                self.assertNotIn("Private retained body", recent_raw)
                self.assertNotIn("readAt", recent_raw)
                self.assertNotIn("starred", recent_raw)
                self.assertIn('<link rel="alternate" type="application/feed+json" href="recent-updates.json"', page)
                bundle_file.write_bytes(archive.read("latest.json"))
                edition_file.write_bytes(archive.read("recent-updates.json"))

            contents_result = self.run_cli("bundle", "contents", str(bundle_file), "--json")
            self.assertEqual(contents_result.returncode, 0, contents_result.stderr)
            contents = json.loads(contents_result.stdout)
            self.assertEqual(contents["schema"], "progrss.shared-folder.contents.v2")
            self.assertEqual(contents["title"], "Neighborhood reading")
            self.assertEqual(contents["feedCount"], 1)
            self.assertEqual(contents["pageWatchCount"], 1)
            self.assertEqual({row["host"] for row in contents["sources"]}, {"example.test"})
            self.assertEqual({row["type"] for row in contents["sources"]}, {"rss", "page"})
            self.assertFalse(contents["network"] )
            self.assertFalse(contents["writes"] )

            contents_human = self.run_cli("bundle", "contents", str(bundle_file), "--limit", "1")
            self.assertEqual(contents_human.returncode, 0, contents_human.stderr)
            self.assertIn("Neighborhood reading", contents_human.stdout)
            self.assertIn("no listed site contacted", contents_human.stdout)
            self.assertIn("more source", contents_human.stdout)

            rebuilt_result = self.run_cli(
                "bundle", "site", str(bundle_file), "--edition", str(edition_file), "--output", str(rebuilt), "--json",
            )
            self.assertEqual(rebuilt_result.returncode, 0, rebuilt_result.stderr)
            rebuilt_report = json.loads(rebuilt_result.stdout)
            self.assertTrue(rebuilt_report["recentUpdatesIncluded"])
            self.assertEqual(rebuilt_report["updates"], 1)
            self.assertTrue(rebuilt.is_file())
            repeat = self.run_cli(
                "bundle", "site", str(bundle_file), "--output", str(rebuilt),
            )
            self.assertEqual(repeat.returncode, 2)
            self.assertIn("never overwrites", repeat.stderr)

    def test_no_overwrite_from_command(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "feeds.opml"
            first = self.run_cli("workspace", "opml", str(FIX / "sample-backup.json"), "--output", str(output))
            second = self.run_cli("workspace", "opml", str(FIX / "sample-backup.json"), "--output", str(output))
            self.assertEqual(first.returncode, 0, first.stderr)
            self.assertEqual(second.returncode, 2)
            self.assertIn("already exists", second.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
