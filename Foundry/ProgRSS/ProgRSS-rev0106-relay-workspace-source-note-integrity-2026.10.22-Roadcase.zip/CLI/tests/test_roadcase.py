from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).resolve().parents[1]
RELEASE_ROOT = ROOT.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from roadcase import (  # noqa: E402
    ROADCASE_MANIFEST_SCHEMA,
    ROADCASE_SCHEMA,
    build_roadcase_packet,
    verify_roadcase_directory,
)


class RoadcaseTests(unittest.TestCase):
    def build(self, output: Path) -> dict[str, object]:
        return build_roadcase_packet(
            RELEASE_ROOT,
            output,
            version="0.80.0",
            revision="rev0080",
            codename="Roadcase",
        )

    def test_two_builds_are_byte_identical_and_bounded(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            first = root / "first.zip"
            second = root / "second.zip"
            report = self.build(first)
            self.build(second)
            self.assertEqual(first.read_bytes(), second.read_bytes())
            self.assertEqual(report["schema"], ROADCASE_SCHEMA)
            self.assertFalse(report["network"])
            self.assertFalse(report["telemetry"])
            self.assertFalse(report["nativeSessionsPerformed"])
            self.assertFalse(report["humanSessionsPerformed"])
            self.assertGreater(report["manifestFiles"], 250)
            self.assertGreater(first.stat().st_size, 1_000_000)
            with zipfile.ZipFile(first) as archive:
                names = archive.namelist()
                self.assertEqual(len(names), len(set(names)))
                self.assertIn("MANIFEST.json", names)
                self.assertIn("START.html", names)
                self.assertIn("release/Extension/manifest.json", names)
                self.assertIn("release/Extension/Firefox/manifest.json", names)
                self.assertIn("release/CLI/progrss.py", names)
                self.assertIn("fixtures/roadcase-private-library.json", names)
                self.assertIn("fixtures/web/virtual-window.html", names)
                self.assertIn("scripts/verify.py", names)
                manifest = json.loads(archive.read("MANIFEST.json"))
                self.assertEqual(manifest["schema"], ROADCASE_MANIFEST_SCHEMA)
                self.assertNotIn("MANIFEST.json", {row["path"] for row in manifest["files"]})

    def test_clean_extraction_verifies_and_modes_can_be_restored(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            packet = root / "roadcase.zip"
            self.build(packet)
            extracted = root / "extracted"
            with zipfile.ZipFile(packet) as archive:
                archive.extractall(extracted)
            result = verify_roadcase_directory(extracted, restore_modes=True)
            self.assertTrue(result["ok"], result["errors"])
            self.assertFalse(result["network"])
            self.assertTrue(os.access(extracted / "scripts" / "verify.py", os.X_OK))
            self.assertTrue(os.access(extracted / "release" / "CLI" / "progrss", os.X_OK))
            prepared = subprocess.run(
                [sys.executable, "scripts/prepare.py"], cwd=extracted,
                text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30,
            )
            self.assertEqual(prepared.returncode, 0, prepared.stderr)
            self.assertTrue((extracted / "work" / "roadcase.sqlite3").is_file())
            after_work = verify_roadcase_directory(extracted)
            self.assertTrue(after_work["ok"], after_work["errors"])

    def test_tamper_and_unexpected_immutable_file_are_refused(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            packet = root / "roadcase.zip"
            self.build(packet)
            extracted = root / "extracted"
            with zipfile.ZipFile(packet) as archive:
                archive.extractall(extracted)
            verify_roadcase_directory(extracted, restore_modes=True)
            target = extracted / "README.md"
            target.write_text(target.read_text() + "tamper\n", encoding="utf-8")
            tampered = verify_roadcase_directory(extracted)
            self.assertFalse(tampered["ok"])
            self.assertTrue(any("digest mismatch: README.md" in row for row in tampered["errors"]))
            # Restore from a clean extraction, then add an unexpected immutable file.
            shutil.rmtree(extracted)
            with zipfile.ZipFile(packet) as archive:
                archive.extractall(extracted)
            verify_roadcase_directory(extracted, restore_modes=True)
            (extracted / "unexpected.txt").write_text("unexpected", encoding="utf-8")
            unexpected = verify_roadcase_directory(extracted)
            self.assertFalse(unexpected["ok"])
            self.assertIn("unexpected immutable file: unexpected.txt", unexpected["errors"])

    def test_packet_contains_no_participant_or_remote_research_service(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            packet = Path(temp) / "roadcase.zip"
            self.build(packet)
            with zipfile.ZipFile(packet) as archive:
                start = archive.read("START.html").decode("utf-8")
                boundary = json.loads(archive.read("ROADCASE.json"))
                backup = json.loads(archive.read("fixtures/roadcase-private-library.json"))
            self.assertIn("no participant account", start.lower())
            self.assertIn("no telemetry", start.lower())
            self.assertFalse(boundary["authority"]["nativeSessionsPerformed"])
            self.assertFalse(boundary["authority"]["humanSessionsPerformed"])
            self.assertFalse(boundary["authority"]["telemetry"])
            self.assertTrue(all("example.test" in row["url"] or row["url"].startswith("http://127.0.0.1:") for row in backup["state"]["sources"]))

    def test_cli_command_is_new_file_only(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "Roadcase.zip"
            command = [
                sys.executable, str(ROOT / "progrss.py"), "node", "roadcase",
                "--release-root", str(RELEASE_ROOT), "--output", str(output), "--json",
            ]
            first = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
            self.assertEqual(first.returncode, 0, first.stderr)
            report = json.loads(first.stdout)
            self.assertEqual(report["schema"], ROADCASE_SCHEMA)
            second = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
            self.assertEqual(second.returncode, 2)
            self.assertIn("already exists", second.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
