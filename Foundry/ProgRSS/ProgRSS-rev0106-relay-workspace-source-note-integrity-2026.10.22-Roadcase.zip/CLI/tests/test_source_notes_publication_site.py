import io
import json
import sys
import unittest
import zipfile
from pathlib import Path

CLI_DIR = Path(__file__).resolve().parents[1]
if str(CLI_DIR) not in sys.path:
    sys.path.insert(0, str(CLI_DIR))

import relay


class SourceNotesPublicationSiteTests(unittest.TestCase):
    def state(self):
        return {
            "sources": [
                {"id": "shared", "type": "rss", "title": "Same source", "url": "https://example.com/feed", "enabled": True},
                {"id": "plain", "type": "rss", "title": "No reason", "url": "https://plain.example/feed", "enabled": True},
            ],
            "collections": [
                {"id": "root", "title": "Shared reasons", "mode": "union", "members": [
                    {"kind": "collection", "id": "alpha"},
                    {"kind": "collection", "id": "beta"},
                ]},
                {"id": "alpha", "title": "Folder Alpha", "mode": "union", "members": [
                    {"kind": "source", "id": "shared", "reason": "Reason Alpha <safe>.\nSecond line & more."},
                    {"kind": "source", "id": "plain"},
                ]},
                {"id": "beta", "title": "Folder Beta", "mode": "union", "members": [
                    {"kind": "source", "id": "shared", "reason": "Reason Beta."},
                ]},
            ],
            "items": [],
            "snapshots": {},
        }

    def build(self):
        bundle = relay.make_bundle(
            self.state(),
            "root",
            curator="Neighborhood <desk>",
            note="A public route with placement reasons.",
            update_url="https://example.com/shared/latest.json",
            exported_at="2026-10-21T12:00:00.000Z",
        )
        return bundle, relay.build_publication_site(bundle)

    def test_ready_to_host_page_discloses_each_direct_placement_reason(self):
        bundle, (payload, summary) = self.build()
        self.assertEqual(summary["sourceNotes"], 2)
        self.assertEqual(summary["feeds"], 2)
        self.assertEqual(summary["folders"], 3)
        with zipfile.ZipFile(io.BytesIO(payload), "r") as archive:
            page = archive.read("index.html").decode("utf-8")
            native = json.loads(archive.read("latest.json"))
            opml = archive.read("subscriptions.opml").decode("utf-8")
            readme = archive.read("README.txt").decode("utf-8")

        self.assertEqual(native, bundle)
        self.assertEqual(page.count("Curator’s reason for this folder:"), 2)
        self.assertEqual(page.count("Same source"), 2)
        self.assertIn("Reason Alpha &lt;safe&gt;.\nSecond line &amp; more.", page)
        self.assertIn("Reason Beta.", page)
        self.assertNotIn("Reason Alpha <safe>", page)
        self.assertIn("not a ProgRSS safety claim", page)
        self.assertIn("2 curator reasons", page)
        self.assertIn('dir="auto"', page)
        self.assertIn("white-space:pre-wrap", page)
        self.assertNotIn("Reason Alpha", opml)
        self.assertNotIn("Reason Beta", opml)
        self.assertIn("2 curator-written folder reasons", readme)
        self.assertIn("OPML carries feeds and hierarchy only", readme)
        self.assertNotIn("<script", page.lower())

    def test_site_construction_is_deterministic_for_reason_bearing_bundle(self):
        _, first = self.build()
        _, second = self.build()
        self.assertEqual(first[0], second[0])
        self.assertEqual(first[1], second[1])

    def test_wrong_level_and_invalid_reasons_remain_refused_before_publication(self):
        wrong_level = self.state()
        wrong_level["collections"][0]["members"][0]["reason"] = "Wrong level"
        with self.assertRaisesRegex(relay.RelayError, "direct source placement"):
            relay.make_bundle(wrong_level, "root", update_url="https://example.com/shared/latest.json")

        over_limit = self.state()
        over_limit["collections"][1]["members"][0]["reason"] = "x" * 281
        with self.assertRaisesRegex(relay.RelayError, "280"):
            relay.make_bundle(over_limit, "root", update_url="https://example.com/shared/latest.json")


if __name__ == "__main__":
    unittest.main()
