from __future__ import annotations

import copy
from datetime import datetime, timezone
import json
from pathlib import Path
import threading
import tempfile
import unittest
from unittest.mock import patch
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
FIX = ROOT / "fixtures"

import sys
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import relay  # noqa: E402
from acquisition import BROWSER_CAPTURE_SCHEMA, FetchResult  # noqa: E402
from node_store import NodeStore  # noqa: E402

from node_server import (  # noqa: E402
    CAPABILITIES_SCHEMA,
    CAPTURE_SCHEMA,
    EXCHANGE_SCHEMA,
    EXCHANGE_TTL_SECONDS,
    LIBRARY_SCHEMA,
    MERGE_REVIEW_NODE_SCHEMA,
    PAIRING_SCHEMA,
    PAIRING_TTL_SECONDS,
    STATUS_SCHEMA,
    NodeHandler,
    NodeHTTPServer,
    NodeState,
    PairingError,
    _bearing_diagnosis,
    _bearing_trace,
    _selector_footprint,
    _library_snapshot,
)


def operation_source_list() -> dict[str, object]:
    state = {
        "sources": [
            {"id": "feed-civic", "type": "rss", "title": "Civic dispatch", "author": "Field desk", "url": "https://civic.example/feed.xml", "enabled": True},
            {"id": "page-works", "type": "page", "title": "Public works board", "author": "Field desk", "url": "https://works.example/projects", "mode": "cards", "selector": "article", "titleSelector": "h2", "linkSelector": "a", "enabled": True},
        ],
        "collections": [
            {"id": "root-new", "title": "Civic field notes", "mode": "union", "members": [{"kind": "collection", "id": "branch-new"}]},
            {"id": "branch-new", "title": "Street and council", "mode": "union", "members": [
                {"kind": "source", "id": "feed-civic", "reason": "Primary council reporting for this branch."},
                {"kind": "source", "id": "page-works", "reason": "Direct project-board changes for this branch."},
            ]},
        ],
        "items": [],
    }
    return relay.make_bundle(state, "Civic field notes", curator="Field desk", exported_at="2026-10-19T23:00:00.000Z")


def rendered_capture(*, selector: str = "", content: str = "Library closes at six.") -> dict[str, object]:
    return {
        "schema": BROWSER_CAPTURE_SCHEMA,
        "capturedAt": datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
        "page": {"url": "https://town.test/notices", "title": "Town noticeboard", "language": "en", "direction": "ltr"},
        "source": {"id": "page-weather", "url": "https://town.test/notices"},
        "recipe": {
            "mode": "region", "selector": selector, "titleSelector": "",
            "linkSelector": "", "threshold": 1, "ignoreNumbers": False,
        },
        "capture": {"mode": "region", "matchCount": 1, "content": content, "cards": []},
        "examples": {"matched": [content], "ignored": "Navigation and footer"},
        "context": {
            "schema": "progrss.capture-page-context.v1",
            "notices": [
                {
                    "kind": "continuation", "tone": "boundary",
                    "summary": "This page appears to continue elsewhere. Capture includes only this rendered page.",
                },
                {
                    "kind": "frames", "tone": "boundary",
                    "summary": "Content inside 1 embedded frame is outside this top-frame capture.",
                },
            ],
            "signals": {
                "continuationLinks": 1, "paginationLandmarks": 1, "continuationControls": 0,
                "partialSetSignals": 0, "virtualMarkers": 0, "scrollWindows": 0,
                "modalLayers": 0, "embeddedFrames": 1, "openShadowRoots": 0, "busyRegions": 0,
            },
        },
        "selection": {
            "schema": "progrss.capture-selection.v1", "candidateId": "main",
            "assessment": {
                "schema": "progrss.capture-section-assessment.v1", "level": "steadier",
                "summary": "More likely to stay put, based on the structure visible now.",
                "reasons": ["The selector matches one visible region."], "warnings": [],
                "signals": {
                    "selectorKind": "semantic", "semanticBoundary": True, "uniqueMatch": True,
                    "visibleMatches": 1, "hiddenMatches": 0, "repeatedEntries": 0,
                    "linkedEntries": 0, "titledEntries": 0, "consistentEntries": 0,
                    "clutterElements": 0, "textCharacters": len(content),
                },
            },
        },
        "coverage": {
            "schema": "progrss.capture-coverage-review.v1",
            "decision": "use-current-rendering",
            "acknowledgedNoticeKinds": ["continuation", "frames"],
        },
        "provenance": {
            "kind": "rendered-browser-dom", "topFrameOnly": True,
            "isolatedWorld": True, "arbitrarySharedCode": False,
            "extensionVersion": "0.80.0", "extractorRevision": "perimeter-v1",
        },
    }


def rendered_card_capture(keys: list[str], *, partial: bool = True) -> dict[str, object]:
    cards = [
        {
            "key": key,
            "title": f"Notice {key.upper()}",
            "url": f"https://town.test/notices/{key}",
            "summary": f"Notice {key.upper()} remains visible in this rendered window.",
        }
        for key in keys
    ]
    notices = ([{
        "kind": "partial-render", "tone": "caution",
        "summary": "This list may render only part of its items at once. Capture includes only entries currently present in the page DOM.",
    }] if partial else [])
    signals = {
        "continuationLinks": 0, "paginationLandmarks": 0, "continuationControls": 0,
        "partialSetSignals": 1 if partial else 0, "virtualMarkers": 1 if partial else 0,
        "scrollWindows": 1 if partial else 0, "modalLayers": 0, "embeddedFrames": 0,
        "openShadowRoots": 0, "busyRegions": 0,
    }
    return {
        "schema": BROWSER_CAPTURE_SCHEMA,
        "capturedAt": datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
        "page": {"url": "https://town.test/notices", "title": "Town noticeboard", "language": "en", "direction": "ltr"},
        "source": {"id": "page-weather", "url": "https://town.test/notices"},
        "recipe": {
            "mode": "cards", "selector": "main article", "titleSelector": "h2",
            "linkSelector": "a[href]", "threshold": 1, "ignoreNumbers": False,
        },
        "capture": {"mode": "cards", "matchCount": len(cards), "content": "", "cards": cards},
        "examples": {"matched": [row["summary"] for row in cards[:3]], "ignored": "Navigation and footer"},
        "context": {"schema": "progrss.capture-page-context.v1", "notices": notices, "signals": signals},
        "selection": {
            "schema": "progrss.capture-selection.v1", "candidateId": "repeated",
            "assessment": {
                "schema": "progrss.capture-section-assessment.v1", "level": "steadier",
                "summary": "More likely to stay put, based on the structure visible now.",
                "reasons": ["Most entries have their own destination link."], "warnings": [],
                "signals": {
                    "selectorKind": "semantic", "semanticBoundary": True, "uniqueMatch": False,
                    "visibleMatches": len(cards), "hiddenMatches": 0, "repeatedEntries": len(cards),
                    "linkedEntries": len(cards), "titledEntries": len(cards), "consistentEntries": len(cards),
                    "clutterElements": 0, "textCharacters": sum(len(row["summary"]) for row in cards),
                },
            },
        },
        "coverage": {
            "schema": "progrss.capture-coverage-review.v1",
            "decision": "use-current-rendering" if partial else "no-limiting-boundary-observed",
            "acknowledgedNoticeKinds": ["partial-render"] if partial else [],
        },
        "provenance": {
            "kind": "rendered-browser-dom", "topFrameOnly": True,
            "isolatedWorld": True, "arbitrarySharedCode": False,
            "extensionVersion": "0.80.0", "extractorRevision": "perimeter-v1",
        },
    }



class NodeServerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.backup = FIX / "sample-backup.json"
        self.node = NodeState(backup=self.backup, token="test-capability")
        self.server = NodeHTTPServer(("127.0.0.1", 0), NodeHandler, self.node)
        self.origin = f"http://127.0.0.1:{self.server.server_address[1]}"
        self.extension_origin = "chrome-extension://abcdefghijklmnopabcdefghijklmnop"
        self.other_extension_origin = "chrome-extension://ponmlkjihgfedcbaponmlkjihgfedcba"
        self.node.origin = self.origin
        self.node.httpd = self.server
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self) -> None:
        self.server.shutdown()
        self.server.server_close()
        self.thread.join(timeout=3)

    def request(
        self,
        path: str,
        *,
        method: str = "GET",
        token: str | None = None,
        origin: str | None = None,
        host: str | None = None,
        body: bytes | None = None,
        json_body: dict[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> tuple[int, dict[str, str], bytes]:
        headers: dict[str, str] = dict(extra_headers or {})
        if token is not None:
            headers["Authorization"] = f"Bearer {token}"
        if origin is not None:
            headers["Origin"] = origin
        if host is not None:
            headers["Host"] = host
        if json_body is not None:
            body = json.dumps(json_body, separators=(",", ":")).encode("utf-8")
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(self.origin + path, data=body, method=method, headers=headers)
        try:
            response = urllib.request.urlopen(request, timeout=5)
        except urllib.error.HTTPError as exc:
            return exc.code, dict(exc.headers.items()), exc.read()
        with response:
            return response.status, dict(response.headers.items()), response.read()

    @staticmethod
    def json_document(body: bytes) -> dict[str, object]:
        value = json.loads(body)
        if not isinstance(value, dict):
            raise AssertionError("expected JSON object")
        return value

    def create_http_invitation(self) -> tuple[str, dict[str, object]]:
        status, headers, body = self.request(
            "/api/v1/pairing-invitations",
            method="POST",
            token=self.node.token,
            origin=self.origin,
            json_body={},
        )
        self.assertEqual(status, 201)
        self.assertNotIn("Access-Control-Allow-Origin", headers)
        document = self.json_document(body)
        invitation_url = str(document["url"])
        parsed = urllib.parse.urlsplit(invitation_url)
        self.assertEqual(f"{parsed.scheme}://{parsed.netloc}", self.origin)
        token = urllib.parse.parse_qs(parsed.fragment)["pair"][0]
        return token, document

    def accept_http_invitation(self, token: str, *, reviewed: bool = False) -> tuple[str, dict[str, object]]:
        if not reviewed:
            status, _headers, _body = self.request(
                "/api/v1/pairing-review",
                token=token,
                origin=self.extension_origin,
            )
            self.assertEqual(status, 200)
        status, headers, body = self.request(
            "/api/v1/pairings",
            method="POST",
            token=token,
            origin=self.extension_origin,
            json_body={"clientName": "ProgRSS Extension", "clientVersion": "0.80.0"},
        )
        self.assertEqual(status, 201)
        self.assertNotIn("Access-Control-Allow-Origin", headers)
        document = self.json_document(body)
        return str(document.pop("token")), document

    def test_snapshot_is_bounded_read_only_and_does_not_mutate_backup(self) -> None:
        before = self.backup.read_bytes()
        snapshot, stats = _library_snapshot(self.backup)
        self.assertEqual(snapshot["schema"], LIBRARY_SCHEMA)
        self.assertTrue(snapshot["readOnly"])
        self.assertEqual(snapshot["library"]["file"], "sample-backup.json")
        self.assertEqual(len(snapshot["library"]["sha256"]), 64)
        self.assertEqual(stats["sources"], 2)
        self.assertEqual(stats["items"], 2)
        self.assertEqual(self.backup.read_bytes(), before)

    def test_static_front_door_is_public_but_api_requires_capability(self) -> None:
        status, headers, body = self.request("/")
        self.assertEqual(status, 200)
        self.assertIn(b"ProgRSS Node", body)
        self.assertIn("default-src 'none'", headers["Content-Security-Policy"])
        self.assertEqual(headers["Cross-Origin-Resource-Policy"], "same-origin")
        self.assertNotIn("Access-Control-Allow-Origin", headers)

        status, _headers, body = self.request("/api/v1/status")
        self.assertEqual(status, 401)
        self.assertEqual(self.json_document(body)["error"], "node capability required")

        status, _headers, _body = self.request("/api/v1/status", token="wrong")
        self.assertEqual(status, 401)

    def test_authenticated_status_advertises_only_delivered_capabilities(self) -> None:
        status, _headers, body = self.request("/api/v1/status", token=self.node.token)
        self.assertEqual(status, 200)
        document = self.json_document(body)
        self.assertEqual(document["schema"], STATUS_SCHEMA)
        self.assertEqual(document["scope"], "loopback-exported-backup")
        self.assertEqual(document["library"]["mode"], "exported-backup")
        capabilities = document["capabilities"]
        self.assertTrue(capabilities["readLibrary"])
        self.assertTrue(capabilities["pairExtension"])
        self.assertTrue(capabilities["reviewLaterCopy"])
        self.assertFalse(capabilities["writeLibrary"])
        self.assertFalse(capabilities["fetchSources"])
        self.assertFalse(capabilities["webrtcCourier"])
        pairing_capabilities = document["pairingCapabilities"]
        self.assertEqual(pairing_capabilities["schema"], CAPABILITIES_SCHEMA)
        self.assertTrue(pairing_capabilities["readLibrarySummary"])
        self.assertFalse(pairing_capabilities["readItems"])
        self.assertFalse(pairing_capabilities["readSourceAddresses"])
        self.assertFalse(pairing_capabilities["writeLibrary"])

    def test_library_endpoint_returns_explicit_copy_only(self) -> None:
        before = self.backup.read_bytes()
        status, headers, body = self.request("/api/v1/library", token=self.node.token)
        self.assertEqual(status, 200)
        document = self.json_document(body)
        self.assertEqual(document["schema"], LIBRARY_SCHEMA)
        self.assertEqual(document["stats"]["sources"], 2)
        self.assertEqual(len(document["sources"]), 2)
        self.assertEqual(len(document["items"]), 2)
        self.assertEqual(headers["ETag"], f'"{document["library"]["sha256"]}"')
        self.assertEqual(self.backup.read_bytes(), before)

    def test_pairing_review_accept_origin_binding_and_extension_revocation(self) -> None:
        before = self.backup.read_bytes()
        invitation_token, invitation = self.create_http_invitation()
        self.assertEqual(invitation["schema"], PAIRING_SCHEMA)
        self.assertEqual(invitation["state"], "invitation")
        self.assertEqual(invitation["expiresInSeconds"], PAIRING_TTL_SECONDS)
        self.assertTrue(invitation["automatic"] is False)
        self.assertEqual(invitation["node"]["identityPersistence"], "until-node-stops")

        status, headers, body = self.request(
            "/api/v1/pairing-review",
            token=invitation_token,
            origin=self.extension_origin,
        )
        self.assertEqual(status, 200)
        self.assertNotIn("Access-Control-Allow-Origin", headers)
        review = self.json_document(body)
        self.assertEqual(review["schema"], PAIRING_SCHEMA)
        self.assertEqual(review["state"], "review")
        self.assertEqual(review["library"]["stats"]["sources"], 2)
        self.assertEqual(len(review["library"]["sha256"]), 64)
        self.assertTrue(review["capabilities"]["readLibrarySummary"])
        self.assertFalse(review["capabilities"]["readItems"])
        self.assertFalse(review["capabilities"]["writeLibrary"])
        self.assertFalse(review["capabilities"]["fetchSources"])

        pair_token, paired = self.accept_http_invitation(invitation_token, reviewed=True)
        self.assertEqual(paired["state"], "paired")
        self.assertNotIn("token", paired)
        self.assertEqual(paired["pairing"]["origin"], self.extension_origin)

        status, _headers, body = self.request(
            "/api/v1/pairing-review",
            token=invitation_token,
            origin=self.extension_origin,
        )
        self.assertEqual(status, 401)
        self.assertIn("already used", str(self.json_document(body)["error"]))

        status, _headers, body = self.request(
            "/api/v1/pairing",
            token=pair_token,
            origin=self.extension_origin,
        )
        self.assertEqual(status, 200)
        self.assertEqual(self.json_document(body)["state"], "paired")

        status, _headers, body = self.request(
            "/api/v1/pairing",
            token=pair_token,
            origin=self.other_extension_origin,
        )
        self.assertEqual(status, 403)
        self.assertIn("another extension Origin", str(self.json_document(body)["error"]))

        status, _headers, body = self.request("/api/v1/pairings", token=self.node.token)
        self.assertEqual(status, 200)
        pairings = self.json_document(body)["pairings"]
        self.assertEqual(len(pairings), 1)
        self.assertNotIn("token", pairings[0])
        self.assertNotIn("token_key", pairings[0])

        status, _headers, body = self.request(
            "/api/v1/pairing/revoke",
            method="POST",
            token=pair_token,
            origin=self.extension_origin,
            json_body={},
        )
        self.assertEqual(status, 200)
        self.assertEqual(self.json_document(body)["state"], "revoked")

        status, _headers, _body = self.request(
            "/api/v1/pairing",
            token=pair_token,
            origin=self.extension_origin,
        )
        self.assertEqual(status, 401)
        self.assertEqual(self.backup.read_bytes(), before)

    def test_admin_can_revoke_without_receiving_pairing_secret(self) -> None:
        invitation_token, _invitation = self.create_http_invitation()
        _pair_token, paired = self.accept_http_invitation(invitation_token)
        pair_id = str(paired["pairing"]["pairId"])

        status, _headers, body = self.request(
            "/api/v1/pairings/revoke",
            method="POST",
            token=self.node.token,
            origin=self.origin,
            json_body={"pairId": pair_id},
        )
        self.assertEqual(status, 200)
        self.assertEqual(self.json_document(body)["pairId"], pair_id)
        self.assertEqual(self.node.list_pairings(), [])

    def test_pairing_invitation_expires_and_is_one_use_in_memory(self) -> None:
        token, invitation = self.node.create_invitation(now=1_000.0)
        self.assertEqual(invitation["expiresAt"], "1970-01-01T00:26:40Z")
        with self.assertRaisesRegex(PairingError, "expired") as expired:
            self.node.review_invitation(token, origin=self.extension_origin, now=1_000.0 + PAIRING_TTL_SECONDS)
        self.assertEqual(expired.exception.status, 410)

        token, _invitation = self.node.create_invitation(now=2_000.0)
        self.node.review_invitation(token, origin=self.extension_origin, now=2_000.5)
        with self.assertRaisesRegex(PairingError, "another extension Origin") as other_review:
            self.node.review_invitation(token, origin=self.other_extension_origin, now=2_000.75)
        self.assertEqual(other_review.exception.status, 403)
        pair_token, _paired = self.node.accept_invitation(
            token,
            origin=self.extension_origin,
            client_name="ProgRSS Extension",
            client_version="0.80.0",
            now=2_001.0,
        )
        self.assertTrue(pair_token)
        with self.assertRaisesRegex(PairingError, "already used"):
            self.node.accept_invitation(
                token,
                origin=self.extension_origin,
                client_name="ProgRSS Extension",
                client_version="0.80.0",
                now=2_002.0,
            )


    def test_pairing_refuses_a_library_changed_after_review(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            backup = Path(directory) / "library.json"
            backup.write_bytes(self.backup.read_bytes())
            node = NodeState(backup=backup, token="master", origin=self.origin)
            token, _invitation = node.create_invitation(now=3_000.0)
            review = node.review_invitation(token, origin=self.extension_origin, now=3_001.0)
            reviewed_digest = str(review["library"]["sha256"])
            backup.write_bytes(backup.read_bytes() + b"\n")
            with self.assertRaisesRegex(PairingError, "changed after review") as changed:
                node.accept_invitation(
                    token,
                    origin=self.extension_origin,
                    client_name="ProgRSS Extension",
                    client_version="0.80.0",
                    now=3_002.0,
                )
            self.assertEqual(changed.exception.status, 409)
            refreshed = node.review_invitation(token, origin=self.extension_origin, now=3_003.0)
            self.assertNotEqual(refreshed["library"]["sha256"], reviewed_digest)
            _pair_token, paired = node.accept_invitation(
                token,
                origin=self.extension_origin,
                client_name="ProgRSS Extension",
                client_version="0.80.0",
                now=3_004.0,
            )
            self.assertEqual(
                paired["pairing"]["reviewedLibrarySha256"],
                paired["library"]["sha256"],
            )

    def test_foreign_origin_and_wrong_host_are_refused(self) -> None:
        status, _headers, body = self.request(
            "/api/v1/status",
            token=self.node.token,
            origin="https://hostile.example",
        )
        self.assertEqual(status, 403)
        self.assertEqual(self.json_document(body)["error"], "foreign Origin refused")

        status, _headers, body = self.request(
            "/api/v1/status",
            token=self.node.token,
            host="localhost.invalid",
        )
        self.assertEqual(status, 403)
        self.assertEqual(self.json_document(body)["error"], "unexpected Host header")

    def test_pairing_routes_require_a_browser_extension_origin(self) -> None:
        token, _document = self.create_http_invitation()
        for origin in (None, self.origin, "https://hostile.example", "null"):
            status, _headers, body = self.request(
                "/api/v1/pairing-review",
                token=token,
                origin=origin,
            )
            self.assertEqual(status, 403)
            self.assertEqual(self.json_document(body)["error"], "a browser-extension Origin is required")

    def test_post_requires_same_origin_and_capability(self) -> None:
        status, _headers, body = self.request(
            "/api/v1/stop",
            method="POST",
            token=self.node.token,
            body=b"{}",
        )
        self.assertEqual(status, 403)
        self.assertEqual(self.json_document(body)["error"], "same-origin POST required")

        status, _headers, body = self.request(
            "/api/v1/stop",
            method="POST",
            token="wrong",
            origin=self.origin,
            body=b"{}",
        )
        self.assertEqual(status, 401)
        self.assertEqual(self.json_document(body)["error"], "node capability required")

    def test_node_owned_manual_acquisition_is_reviewed_receipted_and_replay_safe(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store_path = Path(directory) / "library.sqlite3"
            NodeStore.create_from_backup(self.backup, store_path, now=10_000.0)
            store = NodeStore(store_path)
            self.node.backup = store_path
            self.node.store = store

            status, _headers, body = self.request("/api/v1/status", token=self.node.token)
            self.assertEqual(status, 200)
            status_document = self.json_document(body)
            self.assertTrue(status_document["capabilities"]["fetchSources"])
            self.assertTrue(status_document["capabilities"]["manualAcquisition"])
            self.assertFalse(status_document["capabilities"]["scheduledAcquisition"])
            self.assertFalse(status_document["pairingCapabilities"]["fetchSources"])

            status, _headers, body = self.request(
                "/api/v1/acquisition-previews", method="POST", token=self.node.token,
                origin=self.origin, json_body={"sourceId": "feed-existing"},
            )
            self.assertEqual(status, 201)
            preview = self.json_document(body)
            self.assertEqual(preview["schema"], "progrss.node.acquisition-preview.v1")
            self.assertEqual(preview["source"]["action"], "check-now")
            self.assertFalse(preview["consequences"]["automaticScheduleCreated"])
            self.assertFalse(preview["network"])
            self.assertFalse(preview["writes"])

            feed = (FIX / "sample-rss.xml").read_bytes()
            fetched = FetchResult(
                requested_url="https://existing.test/feed.xml",
                final_url="https://existing.test/feed.xml",
                status=200, body=feed,
                headers={"contentType": "application/rss+xml", "etag": '"http-v1"'},
                redirects=(), resolved_addresses=("93.184.216.34",),
                started_at="2026-10-20T00:00:00.000Z",
                completed_at="2026-10-20T00:00:00.100Z",
                duration_ms=100, request_count=1,
            )
            request_body = {
                "operationType": "check-source-once",
                "sourceId": "feed-existing",
                "action": "check-now",
                "previewToken": preview["previewToken"],
                "previewDigest": preview["previewDigest"],
            }
            headers = {
                "If-Match": f'"{preview["library"]["sha256"]}"',
                "Idempotency-Key": "node-acq-http-00000001",
            }
            with patch("node_server.fetch_public_resource", return_value=fetched) as network:
                status, response_headers, body = self.request(
                    "/api/v1/acquisitions", method="POST", token=self.node.token,
                    origin=self.origin, json_body=request_body, extra_headers=headers,
                )
            self.assertEqual(status, 201)
            network.assert_called_once()
            committed = self.json_document(body)
            self.assertEqual(committed["schema"], "progrss.node.acquisition-result.v1")
            self.assertEqual(committed["state"], "committed")
            self.assertTrue(committed["network"])
            self.assertTrue(committed["writes"])
            receipt = committed["receipt"]
            self.assertEqual(receipt["schema"], "progrss.node.acquisition-receipt.v1")
            self.assertEqual(receipt["sourceId"], "feed-existing")
            self.assertEqual(receipt["resultRevision"], 2)
            self.assertEqual(receipt["effects"]["networkRequests"], 1)
            self.assertFalse(receipt["effects"]["automaticScheduleCreated"])
            self.assertGreater(receipt["summary"]["itemsAdded"], 0)
            self.assertEqual(response_headers["Idempotency-Replayed"], "false")

            with patch("node_server.fetch_public_resource", side_effect=AssertionError("replay fetched again")) as no_network:
                status, response_headers, body = self.request(
                    "/api/v1/acquisitions", method="POST", token=self.node.token,
                    origin=self.origin, json_body=request_body, extra_headers=headers,
                )
            self.assertEqual(status, 200)
            no_network.assert_not_called()
            replay = self.json_document(body)
            self.assertTrue(replay["replayed"])
            self.assertFalse(replay["writes"])
            self.assertEqual(replay["receipt"]["receiptId"], receipt["receiptId"])
            self.assertEqual(response_headers["Idempotency-Replayed"], "true")
            self.assertEqual(store.read_library().revision, 2)

            status, _headers, body = self.request("/api/v1/acquisitions", token=self.node.token)
            self.assertEqual(status, 200)
            listing = self.json_document(body)
            self.assertEqual(len(listing["receipts"]), 1)
            self.assertEqual(listing["jobs"][0]["state"], "completed")
            self.assertFalse(listing["automaticSchedule"])

    def test_browser_capture_is_origin_bound_zero_network_atomic_and_replay_safe(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store_path = Path(directory) / "library.sqlite3"
            NodeStore.create_from_backup(self.backup, store_path, now=10_000.0)
            store = NodeStore(store_path)
            self.node.backup = store_path
            self.node.store = store

            status, _headers, body = self.request("/api/v1/status", token=self.node.token)
            self.assertEqual(status, 200)
            status_document = self.json_document(body)
            self.assertTrue(status_document["capabilities"]["browserAssistedCapture"])
            self.assertFalse(status_document["pairingCapabilities"]["browserAssistedCapture"])

            status, _headers, body = self.request(
                "/api/v1/capture-invitations", method="POST", token=self.node.token,
                origin=self.origin, json_body={"sourceId": "page-weather"},
            )
            self.assertEqual(status, 201)
            invitation = self.json_document(body)
            self.assertEqual(invitation["schema"], CAPTURE_SCHEMA)
            self.assertEqual(invitation["action"], "enable-and-capture")
            self.assertFalse(invitation["network"])
            self.assertFalse(invitation["writes"])
            self.assertEqual(invitation["limits"]["networkRequestsByNode"], 0)
            token = urllib.parse.parse_qs(urllib.parse.urlsplit(str(invitation["url"])).fragment)["capture"][0]

            status, _headers, body = self.request(
                "/api/v1/capture-review", token=token, origin=self.extension_origin,
            )
            self.assertEqual(status, 200)
            review = self.json_document(body)
            self.assertEqual(review["state"], "review")
            self.assertTrue(review["consequences"]["browserMayAlreadyBeSignedIn"])
            self.assertFalse(review["consequences"]["cookiesTransferredToNode"])
            self.assertFalse(review["consequences"]["rawHtmlTransferred"])

            status, _headers, body = self.request(
                "/api/v1/capture-review", token=token, origin=self.other_extension_origin,
            )
            self.assertEqual(status, 403)
            self.assertIn("another extension Origin", str(self.json_document(body)["error"]))

            request_body = {
                "operationType": "capture-rendered-page-once",
                "sourceId": "page-weather",
                "action": "enable-and-capture",
                "previewDigest": review["previewDigest"],
                "recipeChangeAcknowledged": False,
                "artifact": rendered_capture(),
            }
            request_headers = {
                "If-Match": f'"{review["library"]["sha256"]}"',
                "Idempotency-Key": "node-capture-http-00000001",
            }
            with patch("node_server.fetch_public_resource", side_effect=AssertionError("Capture must not fetch the watched page")) as no_network:
                status, response_headers, body = self.request(
                    "/api/v1/captures", method="POST", token=token,
                    origin=self.extension_origin, json_body=request_body, extra_headers=request_headers,
                )
            no_network.assert_not_called()
            self.assertEqual(status, 201)
            committed = self.json_document(body)
            self.assertEqual(committed["captureSchema"], CAPTURE_SCHEMA)
            self.assertEqual(committed["receipt"]["request"]["artifactSchema"], BROWSER_CAPTURE_SCHEMA)
            self.assertEqual(committed["receipt"]["request"]["selectionLevel"], "steadier")
            self.assertEqual(committed["receipt"]["request"]["selectionCandidateId"], "main")
            self.assertEqual(committed["receipt"]["request"]["pageContextSchema"], "progrss.capture-page-context.v1")
            self.assertEqual(committed["receipt"]["request"]["pageContextKinds"], ["continuation", "frames"])
            self.assertTrue(committed["receipt"]["request"]["possibleContinuation"])
            self.assertEqual(committed["receipt"]["request"]["embeddedFrames"], 1)
            self.assertEqual(committed["receipt"]["request"]["coverageReviewSchema"], "progrss.capture-coverage-review.v1")
            self.assertEqual(committed["receipt"]["request"]["coverageDecision"], "use-current-rendering")
            self.assertEqual(committed["receipt"]["request"]["acknowledgedBoundaryKinds"], ["continuation", "frames"])
            self.assertTrue(committed["receipt"]["request"]["partialViewAcknowledged"])
            self.assertEqual(committed["receipt"]["request"]["continuitySchema"], "progrss.capture-continuity.v1")
            self.assertEqual(committed["receipt"]["request"]["continuityAction"], "accept")
            self.assertFalse(committed["receipt"]["request"]["baselinePreserved"])
            self.assertFalse(committed["network"])
            self.assertTrue(committed["writes"])
            self.assertEqual(response_headers["Idempotency-Replayed"], "false")
            receipt = committed["receipt"]
            self.assertEqual(receipt["sourceId"], "page-weather")
            self.assertEqual(receipt["resultRevision"], 2)
            self.assertEqual(receipt["effects"]["networkRequests"], 0)
            self.assertFalse(receipt["effects"]["automaticScheduleCreated"])
            self.assertEqual(receipt["summary"]["itemsAdded"], 0)
            self.assertTrue(receipt["summary"]["baseline"])
            self.assertEqual(receipt["request"]["transport"], "extension-rendered-dom")
            self.assertFalse(receipt["request"]["browserCookiesTransferred"])

            with patch("node_server.fetch_public_resource", side_effect=AssertionError("replay must not fetch")) as no_network:
                status, response_headers, body = self.request(
                    "/api/v1/captures", method="POST", token=token,
                    origin=self.extension_origin, json_body=request_body, extra_headers=request_headers,
                )
            no_network.assert_not_called()
            self.assertEqual(status, 200)
            replay = self.json_document(body)
            self.assertTrue(replay["replayed"])
            self.assertFalse(replay["writes"])
            self.assertEqual(replay["receipt"]["receiptId"], receipt["receiptId"])
            self.assertEqual(response_headers["Idempotency-Replayed"], "true")
            self.assertEqual(store.read_library().revision, 2)

            status, _headers, _body = self.request(
                "/api/v1/capture-review", token=token, origin=self.extension_origin,
            )
            self.assertEqual(status, 410)

            # A proposed watched-section change remains reviewable but cannot
            # create durable work until its separate consequence is acknowledged.
            status, _headers, body = self.request(
                "/api/v1/capture-invitations", method="POST", token=self.node.token,
                origin=self.origin, json_body={"sourceId": "page-weather"},
            )
            self.assertEqual(status, 201)
            changed_invitation = self.json_document(body)
            changed_token = urllib.parse.parse_qs(urllib.parse.urlsplit(str(changed_invitation["url"])).fragment)["capture"][0]
            status, _headers, body = self.request(
                "/api/v1/capture-review", token=changed_token, origin=self.extension_origin,
            )
            self.assertEqual(status, 200)
            changed_review = self.json_document(body)
            changed_body = {
                "operationType": "capture-rendered-page-once",
                "sourceId": "page-weather", "action": "capture-now",
                "previewDigest": changed_review["previewDigest"],
                "recipeChangeAcknowledged": False,
                "artifact": rendered_capture(selector="main .notices", content="A new selected notice region."),
            }
            changed_headers = {
                "If-Match": f'"{changed_review["library"]["sha256"]}"',
                "Idempotency-Key": "node-capture-http-00000002",
            }
            status, _headers, body = self.request(
                "/api/v1/captures", method="POST", token=changed_token,
                origin=self.extension_origin, json_body=changed_body, extra_headers=changed_headers,
            )
            self.assertEqual(status, 409)
            self.assertIn("explicit acknowledgement", str(self.json_document(body)["error"]))
            self.assertIsNone(store.find_acquisition_job("node-capture-http-00000002"))

            changed_body["recipeChangeAcknowledged"] = True
            status, _headers, body = self.request(
                "/api/v1/captures", method="POST", token=changed_token,
                origin=self.extension_origin, json_body=changed_body, extra_headers=changed_headers,
            )
            self.assertEqual(status, 201)
            changed_commit = self.json_document(body)
            self.assertTrue(changed_commit["receipt"]["summary"]["recipeChanged"])
            self.assertEqual(changed_commit["receipt"]["summary"]["itemsAdded"], 0)
            self.assertEqual(changed_commit["receipt"]["resultRevision"], 3)
            self.assertEqual(store.read_library().revision, 3)

    def test_trace_and_recipe_footprint_remain_bounded_and_read_only(self) -> None:
        accepted = {"mode": "cards", "entries": [{"key": "a"}, {"key": "b"}], "capturedAt": "2026-10-20T04:00:00Z"}
        first = {
            "heldAt": "2026-10-20T04:10:00Z",
            "proposedSnapshot": {"mode": "cards", "entries": [{"key": "c"}, {"key": "d"}], "capturedAt": "2026-10-20T04:10:00Z"},
            "proposedProvenance": {"pageContextKinds": ["partial-render"], "assessmentLevel": "watchful", "assessmentSummary": "Usable, but one or more page details may shift."},
            "continuity": {"overlapPercent": 0, "reason": "partial-render-window-shift"},
        }
        second = {
            "heldAt": "2026-10-20T04:20:00Z",
            "proposedSnapshot": {"mode": "cards", "entries": [{"key": "e"}, {"key": "f"}], "capturedAt": "2026-10-20T04:20:00Z"},
            "proposedProvenance": {"pageContextKinds": ["partial-render"], "assessmentLevel": "watchful", "assessmentSummary": "Usable, but one or more page details may shift."},
            "continuity": {"overlapPercent": 0, "reason": "partial-render-window-shift"},
        }
        trace = _bearing_trace(accepted, {"pageContextKinds": ["partial-render"]}, second, [first])
        self.assertEqual(trace["schema"], "progrss.node.bearing-trace.v1")
        self.assertEqual([row["ordinal"] for row in trace["observations"]], [1, 2])
        self.assertEqual(trace["observations"][1]["relationshipToPrevious"]["kind"], "different-window")
        self.assertFalse(trace["network"])
        self.assertFalse(trace["writes"])

        footprint = _selector_footprint(
            {"mode": "cards", "selector": ".css-84ab91f2:nth-child(2)", "titleSelector": "h2", "linkSelector": ""},
            second, {"recommendedRoute": "capture"},
        )
        self.assertEqual(footprint["kind"], "implementation-detail")
        self.assertTrue(footprint["warnings"])
        self.assertEqual(footprint["recommendedRoute"], "capture")
        self.assertFalse(footprint["network"])
        self.assertFalse(footprint["writes"])

    def test_partial_render_window_shift_is_receipted_without_mass_change(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store_path = Path(directory) / "library.sqlite3"
            NodeStore.create_from_backup(self.backup, store_path, now=10_000.0)
            store = NodeStore(store_path)
            self.node.backup = store_path
            self.node.store = store

            def invite_review() -> tuple[str, dict[str, object]]:
                status, _headers, body = self.request(
                    "/api/v1/capture-invitations", method="POST", token=self.node.token,
                    origin=self.origin, json_body={"sourceId": "page-weather"},
                )
                self.assertEqual(status, 201)
                invitation = self.json_document(body)
                token = urllib.parse.parse_qs(urllib.parse.urlsplit(str(invitation["url"])).fragment)["capture"][0]
                status, _headers, body = self.request(
                    "/api/v1/capture-review", token=token, origin=self.extension_origin,
                )
                self.assertEqual(status, 200)
                return token, self.json_document(body)

            token, review = invite_review()
            first_body = {
                "operationType": "capture-rendered-page-once", "sourceId": "page-weather",
                "action": "enable-and-capture", "previewDigest": review["previewDigest"],
                "recipeChangeAcknowledged": True,
                "artifact": rendered_card_capture(["a", "b", "c"]),
            }
            first_headers = {
                "If-Match": f'"{review["library"]["sha256"]}"',
                "Idempotency-Key": "node-drift-http-00000001",
            }
            status, _headers, body = self.request(
                "/api/v1/captures", method="POST", token=token,
                origin=self.extension_origin, json_body=first_body, extra_headers=first_headers,
            )
            self.assertEqual(status, 201)
            first = self.json_document(body)
            self.assertEqual(first["receipt"]["outcome"], "baseline")
            self.assertEqual(first["receipt"]["resultRevision"], 2)
            snapshot_before = copy.deepcopy(store.read_library().document["state"]["snapshots"]["page-weather"])

            token, review = invite_review()
            shifted_body = {
                "operationType": "capture-rendered-page-once", "sourceId": "page-weather",
                "action": "capture-now", "previewDigest": review["previewDigest"],
                "recipeChangeAcknowledged": False,
                "artifact": rendered_card_capture(["d", "e", "f"]),
            }
            shifted_headers = {
                "If-Match": f'"{review["library"]["sha256"]}"',
                "Idempotency-Key": "node-drift-http-00000002",
            }
            with patch("node_server.fetch_public_resource", side_effect=AssertionError("Drift Capture must not fetch")) as no_network:
                status, response_headers, body = self.request(
                    "/api/v1/captures", method="POST", token=token,
                    origin=self.extension_origin, json_body=shifted_body, extra_headers=shifted_headers,
                )
            no_network.assert_not_called()
            self.assertEqual(status, 201)
            shifted = self.json_document(body)
            receipt = shifted["receipt"]
            self.assertEqual(receipt["outcome"], "coverage-shift")
            self.assertTrue(receipt["summary"]["baselinePreserved"])
            self.assertEqual(receipt["summary"]["itemsAdded"], 0)
            self.assertEqual(receipt["request"]["continuitySchema"], "progrss.capture-continuity.v1")
            self.assertEqual(receipt["request"]["continuityAction"], "hold")
            self.assertEqual(receipt["request"]["continuityReason"], "partial-render-window-shift")
            self.assertEqual(receipt["request"]["continuityOverlapPercent"], 0)
            self.assertTrue(receipt["request"]["baselinePreserved"])
            self.assertEqual(receipt["effects"]["networkRequests"], 0)
            self.assertFalse(receipt["effects"]["automaticScheduleCreated"])
            self.assertEqual(response_headers["Idempotency-Replayed"], "false")
            after = store.read_library()
            self.assertEqual(after.revision, 3)
            self.assertEqual(after.document["state"]["snapshots"]["page-weather"], snapshot_before)
            self.assertFalse(any(row.get("sourceId") == "page-weather" for row in after.document["state"].get("items", [])))

            with patch("node_server.fetch_public_resource", side_effect=AssertionError("Drift replay must not fetch")) as no_network:
                status, response_headers, body = self.request(
                    "/api/v1/captures", method="POST", token=token,
                    origin=self.extension_origin, json_body=shifted_body, extra_headers=shifted_headers,
                )
            no_network.assert_not_called()
            self.assertEqual(status, 200)
            replay = self.json_document(body)
            self.assertTrue(replay["replayed"])
            self.assertEqual(replay["receipt"]["receiptId"], receipt["receiptId"])
            self.assertEqual(response_headers["Idempotency-Replayed"], "true")
            self.assertEqual(store.read_library().revision, 3)

            held = store.capture_hold("page-weather")
            self.assertIsNotNone(held)
            self.assertEqual(held["captureReceiptId"], receipt["receiptId"])
            self.assertEqual([row["key"] for row in held["proposedSnapshot"]["entries"]], ["d", "e", "f"])

            # A second disjoint partial window moves the first unresolved hold into
            # bounded local history. Bearing explains the repeated pattern without
            # contacting the watched site or changing the accepted baseline.
            token, review = invite_review()
            second_body = {
                "operationType": "capture-rendered-page-once", "sourceId": "page-weather",
                "action": "capture-now", "previewDigest": review["previewDigest"],
                "recipeChangeAcknowledged": False,
                "artifact": rendered_card_capture(["g", "h", "i"]),
            }
            second_headers = {
                "If-Match": f'"{review["library"]["sha256"]}"',
                "Idempotency-Key": "node-drift-http-00000003",
            }
            with patch("node_server.fetch_public_resource", side_effect=AssertionError("second Drift Capture must not fetch")) as no_network:
                status, _headers, body = self.request(
                    "/api/v1/captures", method="POST", token=token,
                    origin=self.extension_origin, json_body=second_body, extra_headers=second_headers,
                )
            no_network.assert_not_called()
            self.assertEqual(status, 201)
            second = self.json_document(body)
            self.assertEqual(second["receipt"]["outcome"], "coverage-shift")
            self.assertEqual(second["receipt"]["resultRevision"], 4)
            self.assertEqual(len(store.capture_hold_history("page-weather")), 1)
            self.assertEqual(store.capture_hold_history("page-weather")[0]["captureReceiptId"], receipt["receiptId"])
            self.assertEqual([row["key"] for row in store.capture_hold("page-weather")["proposedSnapshot"]["entries"]], ["g", "h", "i"])

            with patch("node_server.fetch_public_resource", side_effect=AssertionError("Bearing review must not fetch")) as no_network:
                status, _headers, body = self.request(
                    "/api/v1/bearing-reviews", method="POST", token=self.node.token,
                    origin=self.origin, json_body={"sourceId": "page-weather"},
                )
            no_network.assert_not_called()
            self.assertEqual(status, 200)
            bearing = self.json_document(body)
            self.assertEqual(bearing["schema"], "progrss.node.bearing-review.v2")
            self.assertEqual(bearing["diagnosis"]["kind"], "moving-rendered-window")
            self.assertEqual(bearing["trace"]["schema"], "progrss.node.bearing-trace.v1")
            self.assertEqual(bearing["trace"]["accepted"]["units"], 3)
            self.assertEqual(len(bearing["trace"]["observations"]), 2)
            self.assertFalse(bearing["trace"]["observations"][0]["current"])
            self.assertTrue(bearing["trace"]["observations"][-1]["current"])
            self.assertEqual(bearing["trace"]["observations"][-1]["relationshipToPrevious"]["kind"], "different-window")
            self.assertEqual(bearing["recipeFootprint"]["schema"], "progrss.node.recipe-footprint.v1")
            self.assertEqual(bearing["recipeFootprint"]["kind"], "semantic-boundary")
            self.assertEqual(bearing["diagnosis"]["observationsReviewed"], 2)
            self.assertEqual(bearing["history"]["priorObservationsRetained"], 1)
            self.assertFalse(bearing["network"])
            self.assertFalse(bearing["writes"])
            self.assertEqual(store.read_library().document["state"]["snapshots"]["page-weather"], snapshot_before)

            before_fieldbook = store.read_library()
            status, fieldbook_headers, fieldbook_body = self.request(
                "/api/v1/fieldwork-kits", method="POST", token=self.node.token,
                origin=self.origin, json_body={"sourceId": "page-weather"},
            )
            self.assertEqual(status, 200)
            self.assertEqual(fieldbook_headers["X-ProgRSS-Schema"], "progrss.fieldwork-kit.v1")
            self.assertIn("attachment;", fieldbook_headers["Content-Disposition"])
            self.assertIn("ProgRSS-Fieldbook-rev0080", fieldbook_headers["Content-Disposition"])
            fieldbook_text = fieldbook_body.decode("utf-8")
            self.assertIn("Test the wording, not the person.", fieldbook_text)
            self.assertIn("No telemetry", fieldbook_text)
            self.assertNotIn("https://town.test/notices", fieldbook_text)
            self.assertNotIn("Town noticeboard", fieldbook_text)
            self.assertNotIn("main .notices", fieldbook_text)
            self.assertNotIn("fetch(", fieldbook_text)
            self.assertEqual(store.read_library().revision, before_fieldbook.revision)
            self.assertEqual(store.read_library().raw, before_fieldbook.raw)

            status, debrief_headers, debrief_body = self.request(
                "/api/v1/debrief-kits", method="POST", token=self.node.token,
                origin=self.origin, json_body={},
            )
            self.assertEqual(status, 200)
            self.assertEqual(debrief_headers["X-ProgRSS-Schema"], "progrss.fieldwork-debrief-kit.v1")
            self.assertIn("attachment;", debrief_headers["Content-Disposition"])
            self.assertIn("ProgRSS-Debrief-rev0080", debrief_headers["Content-Disposition"])
            debrief_text = debrief_body.decode("utf-8")
            self.assertIn("Find patterns. Do not score people.", debrief_text)
            self.assertIn("raw notes excluded from export", debrief_text.lower())
            self.assertIn("connect-src 'none'", debrief_text)
            self.assertNotIn("fetch(", debrief_text)
            self.assertNotIn("localStorage", debrief_text)
            self.assertEqual(store.read_library().revision, before_fieldbook.revision)
            self.assertEqual(store.read_library().raw, before_fieldbook.raw)

            status, _headers, body = self.request(
                "/api/v1/debrief-kits", method="POST", token=self.node.token,
                origin=self.origin, json_body={"unexpected": True},
            )
            self.assertEqual(status, 400)
            self.assertIn("accepts no request fields", self.json_document(body)["error"])

            status, _headers, body = self.request(
                "/api/v1/fieldwork-kits", method="POST", origin=self.origin,
                json_body={"sourceId": "page-weather"},
            )
            self.assertEqual(status, 401)
            self.assertIn("capability", str(self.json_document(body)["error"]))

            # A new NodeState can recover the held observation from durable store evidence.
            self.node.baseline_previews.clear()
            status, _headers, body = self.request(
                "/api/v1/baseline-previews", method="POST", token=self.node.token,
                origin=self.origin, json_body={"sourceId": "page-weather"},
            )
            self.assertEqual(status, 201)
            preview = self.json_document(body)
            self.assertEqual(preview["schema"], "progrss.node.baseline-preview.v1")
            self.assertEqual(preview["operationType"], "replace-held-page-baseline")
            self.assertEqual(preview["continuity"]["overlapPercent"], 0)
            self.assertEqual(preview["source"]["accepted"]["units"], 3)
            self.assertEqual(preview["source"]["proposed"]["units"], 3)
            self.assertFalse(preview["writes"])
            self.assertFalse(preview["network"])

            replacement_body = {
                "operationType": "replace-held-page-baseline",
                "previewToken": preview["previewToken"],
                "previewDigest": preview["previewDigest"],
            }
            replacement_headers = {
                "If-Match": f'"{preview["library"]["sha256"]}"',
                "Idempotency-Key": "anchor-http-000000000001",
            }
            with patch("node_server.fetch_public_resource", side_effect=AssertionError("Anchor must not fetch")) as no_network:
                status, response_headers, body = self.request(
                    "/api/v1/operations", method="POST", token=self.node.token,
                    origin=self.origin, json_body=replacement_body, extra_headers=replacement_headers,
                )
            no_network.assert_not_called()
            self.assertEqual(status, 201)
            replacement = self.json_document(body)
            replacement_receipt = replacement["receipt"]
            self.assertEqual(replacement_receipt["operationType"], "replace-held-page-baseline")
            self.assertEqual(replacement_receipt["resultRevision"], 5)
            self.assertEqual(replacement_receipt["summary"]["historicalChangeAlertsCreated"], 0)
            self.assertEqual(replacement_receipt["effects"]["networkRequests"], 0)
            self.assertTrue(replacement_receipt["effects"]["earlierLibrarySnapshotRetained"])
            self.assertEqual(response_headers["Idempotency-Replayed"], "false")
            accepted = store.read_library()
            self.assertEqual([row["key"] for row in accepted.document["state"]["snapshots"]["page-weather"]["entries"]], ["g", "h", "i"])
            self.assertFalse(any(row.get("sourceId") == "page-weather" for row in accepted.document["state"].get("items", [])))
            self.assertIsNone(store.capture_hold("page-weather"))
            self.assertEqual(store.capture_hold_history("page-weather"), [])
            snapshot_raw, snapshot_digest, snapshot_operation = store.read_snapshot(replacement_receipt["rollbackEvidence"]["snapshotId"])
            self.assertEqual(snapshot_digest, preview["library"]["sha256"])
            self.assertEqual(snapshot_operation, replacement_receipt["operationId"])
            snapshot_doc = json.loads(snapshot_raw)
            self.assertEqual(snapshot_doc["state"]["snapshots"]["page-weather"], snapshot_before)

            with patch("node_server.fetch_public_resource", side_effect=AssertionError("Anchor replay must not fetch")) as no_network:
                status, response_headers, body = self.request(
                    "/api/v1/operations", method="POST", token=self.node.token,
                    origin=self.origin, json_body=replacement_body, extra_headers=replacement_headers,
                )
            no_network.assert_not_called()
            self.assertEqual(status, 200)
            replacement_replay = self.json_document(body)
            self.assertTrue(replacement_replay["replayed"])
            self.assertEqual(replacement_replay["receipt"]["receiptId"], replacement_receipt["receiptId"])
            self.assertEqual(response_headers["Idempotency-Replayed"], "true")
            self.assertEqual(store.read_library().revision, 5)

    def test_bearing_diagnosis_distinguishes_insufficient_and_boundary_shift(self) -> None:
        snapshot = {
            "mode": "cards", "keys": ["a", "b", "c"],
            "entries": [{"key": key, "title": key, "summary": "", "url": f"https://town.test/{key}"} for key in ("a", "b", "c")],
        }
        current = {
            "sourceIdentitySha256": "a" * 64, "acceptedSnapshotSha256": "b" * 64,
            "proposedSnapshot": snapshot,
            "proposedProvenance": {"pageContextKinds": ["partial-render"]},
            "continuity": {"reason": "partial-render-window-shift", "boundaryChanged": False},
        }
        diagnosis, comparisons = _bearing_diagnosis(current, [])
        self.assertEqual(diagnosis["kind"], "insufficient-evidence")
        self.assertEqual(comparisons, [])

        previous = copy.deepcopy(current)
        previous["captureOperationId"] = "bearing-prior-0000000001"
        previous["captureReceiptId"] = "sha256:" + "c" * 64
        previous["heldAt"] = "2026-10-20T05:00:00.000Z"
        previous["proposedProvenance"]["pageContextKinds"] = ["partial-render", "overlay"]
        diagnosis, comparisons = _bearing_diagnosis(current, [previous])
        self.assertEqual(diagnosis["kind"], "page-boundary-shifted")
        self.assertEqual(diagnosis["recommendedRoute"], "capture")
        self.assertEqual(len(comparisons), 1)

    def test_node_owned_branch_operation_is_reviewed_atomic_idempotent_and_snapshot_backed(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            store_path = Path(directory) / "library.sqlite3"
            NodeStore.create_from_backup(self.backup, store_path, now=10_000.0)
            store = NodeStore(store_path)
            self.node.backup = store_path
            self.node.store = store
            source_list = operation_source_list()

            status, _headers, body = self.request("/api/v1/status", token=self.node.token)
            self.assertEqual(status, 200)
            status_document = self.json_document(body)
            self.assertEqual(status_document["scope"], "loopback-node-owned")
            self.assertEqual(status_document["library"]["mode"], "node-owned")
            self.assertTrue(status_document["capabilities"]["writeLibrary"])
            self.assertTrue(status_document["capabilities"]["adoptReviewedBranch"])
            self.assertFalse(status_document["pairingCapabilities"]["writeLibrary"])

            status, _headers, body = self.request(
                "/api/v1/branch-options", method="POST", token=self.node.token,
                origin=self.origin, json_body={"bundle": source_list},
            )
            self.assertEqual(status, 200)
            options = self.json_document(body)
            self.assertEqual(options["schema"], "progrss.node.branch-options.v1")
            self.assertTrue(options["canCommit"])
            self.assertEqual(len(options["branches"]), 1)
            self.assertEqual(options["branches"][0]["path"], "Civic field notes › Street and council")
            self.assertEqual(options["branches"][0]["sourceNotes"], 2)

            def preview() -> dict[str, object]:
                response_status, _response_headers, response_body = self.request(
                    "/api/v1/operation-previews", method="POST", token=self.node.token,
                    origin=self.origin,
                    json_body={"bundle": source_list, "folder": "branch-new"},
                )
                self.assertEqual(response_status, 201)
                value = self.json_document(response_body)
                self.assertEqual(value["schema"], "progrss.node.operation-preview.v1")
                self.assertEqual(value["summary"]["newSources"], 2)
                self.assertEqual(value["summary"]["pageWatches"], 1)
                self.assertEqual(value["summary"]["sourceNoteCount"], 2)
                self.assertEqual(value["contents"]["sourceNoteCount"], 2)
                reasons = {
                    placement["reason"]
                    for source in value["contents"]["sources"]
                    for placement in source["placements"]
                    if placement.get("reason")
                }
                self.assertEqual(reasons, {
                    "Primary council reporting for this branch.",
                    "Direct project-board changes for this branch.",
                })
                self.assertTrue(value["consequences"]["newSourcesPaused"])
                self.assertTrue(value["consequences"]["rollbackSnapshotCreated"])
                self.assertFalse(value["network"])
                self.assertFalse(value["writes"])
                return value

            first = preview()
            stale = preview()
            operation_body = {
                "operationType": "adopt-source-list-branch",
                "previewToken": first["previewToken"],
                "previewDigest": first["previewDigest"],
            }
            quoted_base = f'"{first["library"]["sha256"]}"'

            status, _headers, body = self.request(
                "/api/v1/operations", method="POST", token=self.node.token,
                origin=self.origin, json_body=operation_body,
                extra_headers={"Idempotency-Key": "node-op-http-00000001"},
            )
            self.assertEqual(status, 428)
            self.assertIn("If-Match is required", str(self.json_document(body)["error"]))

            status, _headers, body = self.request(
                "/api/v1/operations", method="POST", token=self.node.token,
                origin=self.origin, json_body=operation_body,
                extra_headers={"If-Match": quoted_base},
            )
            self.assertEqual(status, 400)
            self.assertIn("Idempotency-Key is required", str(self.json_document(body)["error"]))

            status, _headers, body = self.request(
                "/api/v1/operations", method="POST", token=self.node.token,
                origin=self.origin, json_body=operation_body,
                extra_headers={
                    "If-Match": f'"{"0" * 64}"',
                    "Idempotency-Key": "node-op-http-00000002",
                },
            )
            self.assertEqual(status, 412)
            self.assertIn("reviewed base library", str(self.json_document(body)["error"]))

            status, headers, body = self.request(
                "/api/v1/operations", method="POST", token=self.node.token,
                origin=self.origin, json_body=operation_body,
                extra_headers={
                    "If-Match": quoted_base,
                    "Idempotency-Key": "node-op-http-00000001",
                },
            )
            self.assertEqual(status, 201)
            self.assertEqual(headers["Idempotency-Replayed"], "false")
            committed = self.json_document(body)
            self.assertEqual(committed["state"], "committed")
            self.assertTrue(committed["writes"])
            receipt = committed["receipt"]
            self.assertEqual(receipt["schema"], "progrss.node.operation-receipt.v1")
            self.assertEqual(receipt["resultRevision"], 2)
            self.assertEqual(receipt["summary"]["newSources"], 2)
            self.assertEqual(receipt["effects"]["networkRequests"], 0)
            self.assertTrue(receipt["effects"]["newSourcesPaused"])
            self.assertEqual(headers["ETag"], f'"{receipt["resultLibrarySha256"]}"')

            status, headers, body = self.request(
                "/api/v1/operations", method="POST", token=self.node.token,
                origin=self.origin, json_body=operation_body,
                extra_headers={
                    "If-Match": quoted_base,
                    "Idempotency-Key": "node-op-http-00000001",
                },
            )
            self.assertEqual(status, 200)
            self.assertEqual(headers["Idempotency-Replayed"], "true")
            replayed = self.json_document(body)
            self.assertEqual(replayed["state"], "replayed")
            self.assertTrue(replayed["replayed"])
            self.assertFalse(replayed["writes"])
            self.assertEqual(replayed["receipt"]["receiptId"], receipt["receiptId"])

            changed_body = dict(operation_body)
            changed_body["previewDigest"] = "f" * 64
            status, _headers, body = self.request(
                "/api/v1/operations", method="POST", token=self.node.token,
                origin=self.origin, json_body=changed_body,
                extra_headers={
                    "If-Match": quoted_base,
                    "Idempotency-Key": "node-op-http-00000001",
                },
            )
            self.assertEqual(status, 409)
            self.assertIn("already used for different reviewed content", str(self.json_document(body)["error"]))

            stale_body = {
                "operationType": "adopt-source-list-branch",
                "previewToken": stale["previewToken"],
                "previewDigest": stale["previewDigest"],
            }
            status, _headers, body = self.request(
                "/api/v1/operations", method="POST", token=self.node.token,
                origin=self.origin, json_body=stale_body,
                extra_headers={
                    "If-Match": f'"{stale["library"]["sha256"]}"',
                    "Idempotency-Key": "node-op-http-00000003",
                },
            )
            self.assertEqual(status, 412)
            self.assertIn("changed after review", str(self.json_document(body)["error"]))

            status, _headers, body = self.request("/api/v1/operations", token=self.node.token)
            self.assertEqual(status, 200)
            operations = self.json_document(body)
            self.assertEqual(len(operations["operations"]), 1)
            self.assertEqual(operations["operations"][0]["receiptId"], receipt["receiptId"])

            snapshot_id = str(receipt["rollbackEvidence"]["snapshotId"])
            status, headers, snapshot_bytes = self.request(
                f"/api/v1/operation-snapshot?id={urllib.parse.quote(snapshot_id)}",
                token=self.node.token,
            )
            self.assertEqual(status, 200)
            self.assertEqual(headers["X-ProgRSS-Snapshot-Id"], snapshot_id)
            self.assertEqual(snapshot_bytes, self.backup.read_bytes())

            status, _headers, body = self.request("/api/v1/library", token=self.node.token)
            self.assertEqual(status, 200)
            library = self.json_document(body)
            self.assertEqual(library["library"]["revision"], 2)
            self.assertEqual(library["stats"]["sources"], 4)
            new_sources = [row for row in library["sources"] if row["host"] in {"civic.example", "works.example"}]
            self.assertEqual(len(new_sources), 2)
            self.assertTrue(all(not row["enabled"] for row in new_sources))
            committed_document, _raw, _revision, _updated_at = self.node.current_document()
            adopted = next(
                row for row in committed_document["state"]["collections"]
                if row.get("title") == "Street and council"
            )
            self.assertEqual(
                {member.get("reason") for member in adopted["members"] if member.get("kind") == "source"},
                {
                    "Primary council reporting for this branch.",
                    "Direct project-board changes for this branch.",
                },
            )

    def test_merge_review_is_three_way_read_only_and_requires_admin_origin(self) -> None:
        initial_state = {
            "sources": [
                {"id": "wording", "type": "rss", "title": "Accepted name", "author": "Desk", "url": "https://wording.example/feed", "enabled": True},
                {"id": "recipe", "type": "rss", "title": "Route alerts", "author": "Desk", "url": "https://old.example/feed", "enabled": True},
            ],
            "collections": [{"id": "route", "title": "Civic route", "mode": "union", "members": [
                {"kind": "source", "id": "wording", "reason": "Baseline reason for this route."},
                {"kind": "source", "id": "recipe"},
            ]}],
            "items": [],
        }
        initial = relay.make_bundle(
            initial_state, "Civic route", curator="Neighborhood desk",
            update_url="https://publish.example/civic/source-list.json",
            exported_at="2026-10-18T20:00:00.000Z",
        )
        imported, _summary = relay.import_bundle({"sources": [], "collections": [], "items": []}, initial)
        next(row for row in imported["sources"] if row["id"] == "wording")["title"] = "My local name"
        imported_root = next(row for row in imported["collections"] if row.get("sharedFolderOrigin"))
        next(member for member in imported_root["members"] if member.get("kind") == "source" and member.get("id") == "wording")["reason"] = "My route reason."
        later_state = copy.deepcopy(initial_state)
        next(row for row in later_state["sources"] if row["id"] == "wording")["title"] = "Curator's later name"
        next(row for row in later_state["sources"] if row["id"] == "recipe")["url"] = "https://new.example/feed"
        next(member for member in later_state["collections"][0]["members"] if member.get("id") == "wording")["reason"] = "Curator's route reason."
        later = relay.make_bundle(
            later_state, "Civic route", curator="Neighborhood desk",
            update_url="https://publish.example/civic/source-list.json",
            exported_at="2026-10-19T20:00:00.000Z",
        )
        with tempfile.TemporaryDirectory() as directory:
            backup = Path(directory) / "imported-library.json"
            backup.write_text(json.dumps({
                "schema": "progrss.private.v1",
                "exportedAt": "2026-10-19T21:00:00.000Z",
                "state": imported,
            }), encoding="utf-8")
            before = backup.read_bytes()
            self.node.backup = backup

            status, _headers, body = self.request(
                "/api/v1/merge-reviews", method="POST", token=self.node.token,
                origin=self.origin, json_body={"bundle": later},
            )
            self.assertEqual(status, 200)
            document = self.json_document(body)
            self.assertEqual(document["schema"], MERGE_REVIEW_NODE_SCHEMA)
            self.assertEqual(document["state"], "review")
            self.assertTrue(document["readOnly"])
            self.assertFalse(document["network"])
            self.assertFalse(document["writes"])
            merge = document["review"]["mergeReview"]
            self.assertEqual(merge["schema"], relay.MERGE_REVIEW_SCHEMA)
            self.assertGreaterEqual(merge["counts"]["conflicts"], 2)
            self.assertEqual(merge["counts"]["recipeChanges"], 1)
            conflict_ids = {row["id"] for row in merge["conflicts"]}
            self.assertIn("placement:route:source:wording:reason", conflict_ids)
            source_note_conflict = next(row for row in merge["conflicts"] if row["id"] == "placement:route:source:wording:reason")
            self.assertEqual(source_note_conflict["kind"], "source-note")
            self.assertEqual(source_note_conflict["folderLabel"], "Civic route")
            self.assertEqual(source_note_conflict["folderPath"], "Civic route")
            self.assertEqual(source_note_conflict["placement"]["folderPath"], "Civic route")
            self.assertEqual(source_note_conflict["baseline"], "Baseline reason for this route.")
            self.assertEqual(source_note_conflict["local"], "My route reason.")
            self.assertEqual(source_note_conflict["incoming"], "Curator's route reason.")
            self.assertTrue(document["review"]["requiresConflictChoices"])
            self.assertTrue(document["review"]["requiresRecipeAcknowledgement"])
            self.assertEqual(backup.read_bytes(), before)

            status, _headers, body = self.request(
                "/api/v1/merge-reviews", method="POST", token=self.node.token,
                origin="https://hostile.example", json_body={"bundle": later},
            )
            self.assertEqual(status, 403)
            self.assertEqual(self.json_document(body)["error"], "same-origin POST required")

    def test_exchange_preview_handoff_artifacts_origin_binding_and_revocation(self) -> None:
        self.node.backup = FIX / "exchange-backup.json"
        before = self.node.backup.read_bytes()

        status, _headers, body = self.request("/api/v1/curation", token=self.node.token)
        self.assertEqual(status, 200)
        curation = self.json_document(body)
        self.assertEqual(curation["schema"], EXCHANGE_SCHEMA)
        self.assertEqual(curation["state"], "curation")
        self.assertEqual(len(curation["folders"]), 2)
        self.assertEqual(curation["folders"][0]["sourceCount"], 3)

        status, _headers, body = self.request(
            "/api/v1/exchange-previews",
            method="POST",
            token=self.node.token,
            origin=self.origin,
            json_body={
                "folder": "folder-neighborhood",
                "curator": "Alex Rivera",
                "note": "Local decisions and notices.",
                "publicUpdateUrl": "https://example.org/neighborhood/source-list.json",
                "includeRecentUpdates": True,
            },
        )
        self.assertEqual(status, 201)
        preview = self.json_document(body)
        self.assertEqual(preview["schema"], "progrss.node.exchange-preview.v1")
        self.assertEqual(preview["state"], "preview")
        self.assertEqual(preview["counts"]["sources"], 3)
        self.assertEqual(preview["counts"]["recentUpdates"], 3)
        self.assertEqual(preview["counts"]["sourceNotes"], 3)
        council = next(row for row in preview["contents"]["sources"] if row["id"] == "feed-council")
        self.assertEqual(council["sourceNoteCount"], 2)
        self.assertEqual(
            [row.get("reason") for row in council["placements"]],
            ["Broad agenda overview.", "سبب لاجتماعات المجلس المحلية."],
        )
        self.assertEqual(preview["choices"]["takeBranch"]["branches"][0]["sourceNotes"], 1)
        self.assertTrue(preview["choices"]["followUpdates"]["available"])
        self.assertTrue(preview["choices"]["takeBranch"]["available"])
        self.assertEqual(preview["privacy"]["excluded"][0], "read and unread state")

        with patch("node_server.fetch_public_resource", side_effect=AssertionError("sender Fieldbook must not fetch")) as no_network:
            status, sender_headers, sender_body = self.request(
                "/api/v1/exchange-sender-fieldwork-kits", method="POST", token=self.node.token,
                origin=self.origin, json_body={"previewToken": preview["previewToken"]},
            )
        no_network.assert_not_called()
        self.assertEqual(status, 200)
        self.assertEqual(sender_headers["X-ProgRSS-Schema"], "progrss.fieldwork-kit.v1")
        self.assertIn("Exchange-Sender", sender_headers["Content-Disposition"])
        sender_fieldbook = sender_body.decode("utf-8")
        self.assertIn("Know what leaves before you send the link.", sender_fieldbook)
        self.assertIn("Explain what stays private", sender_fieldbook)
        self.assertIn("Create 30-minute handoff", sender_fieldbook)
        for secret in (
            "Alex Rivera",
            "Local decisions and notices.",
            "example.org",
            "folder-neighborhood",
            preview["previewToken"],
            preview["previewDigest"],
            preview["library"]["sha256"],
        ):
            self.assertNotIn(secret, sender_fieldbook)
        self.assertEqual(self.node.backup.read_bytes(), before)

        status, _headers, body = self.request(
            "/api/v1/exchange-sender-fieldwork-kits", method="POST", token=self.node.token,
            origin=self.origin, json_body={"previewToken": preview["previewToken"], "unexpected": True},
        )
        self.assertEqual(status, 400)
        self.assertIn("exactly previewToken", self.json_document(body)["error"])

        status, _headers, body = self.request(
            "/api/v1/exchanges",
            method="POST",
            token=self.node.token,
            origin=self.origin,
            json_body={
                "previewToken": preview["previewToken"],
                "previewDigest": preview["previewDigest"],
                "librarySha256": preview["library"]["sha256"],
            },
        )
        self.assertEqual(status, 201)
        created = self.json_document(body)
        self.assertEqual(created["schema"], EXCHANGE_SCHEMA)
        self.assertEqual(created["state"], "created")
        self.assertEqual(created["expiresInSeconds"], EXCHANGE_TTL_SECONDS)
        exchange_id = str(created["exchangeId"])
        exchange_token = urllib.parse.parse_qs(urllib.parse.urlsplit(str(created["url"])).fragment)["exchange"][0]

        with patch("node_server.fetch_public_resource", side_effect=AssertionError("Exchange Fieldbook must not fetch")) as no_network:
            status, fieldbook_headers, fieldbook_body = self.request(
                "/api/v1/exchange-fieldwork-kits", method="POST", token=self.node.token,
                origin=self.origin, json_body={"exchangeId": exchange_id},
            )
        no_network.assert_not_called()
        self.assertEqual(status, 200)
        self.assertEqual(fieldbook_headers["X-ProgRSS-Schema"], "progrss.fieldwork-kit.v1")
        self.assertIn("attachment;", fieldbook_headers["Content-Disposition"])
        self.assertIn("Exchange", fieldbook_headers["Content-Disposition"])
        exchange_fieldbook = fieldbook_body.decode("utf-8")
        self.assertIn("Observe the choice, not the person.", exchange_fieldbook)
        self.assertIn("Follow updates", exchange_fieldbook)
        self.assertIn("Add the complete route", exchange_fieldbook)
        self.assertIn("Take one branch", exchange_fieldbook)
        for secret in (
            "Alex Rivera",
            "Local decisions and notices.",
            "example.org",
            "folder-neighborhood",
            exchange_id,
            exchange_token,
        ):
            self.assertNotIn(secret, exchange_fieldbook)
        self.assertEqual(self.node.backup.read_bytes(), before)

        status, _headers, body = self.request(
            "/api/v1/exchange-fieldwork-kits", method="POST", token=self.node.token,
            origin=self.origin, json_body={"exchangeId": exchange_id, "unexpected": True},
        )
        self.assertEqual(status, 400)
        self.assertIn("exactly exchangeId", self.json_document(body)["error"])

        status, headers, body = self.request(
            "/api/v1/exchange-review", token=exchange_token, origin=self.extension_origin
        )
        self.assertEqual(status, 200)
        self.assertNotIn("Access-Control-Allow-Origin", headers)
        review = self.json_document(body)
        self.assertEqual(review["state"], "review")
        self.assertEqual(review["node"]["origin"], self.origin)
        self.assertEqual(review["public"]["feedUrl"], "https://example.org/neighborhood/recent-updates.json")

        status, _headers, body = self.request(
            "/api/v1/exchange-review", token=exchange_token, origin=self.other_extension_origin
        )
        self.assertEqual(status, 403)
        self.assertIn("another extension Origin", str(self.json_document(body)["error"]))

        for route, expected_type, expected_name in (
            ("/api/v1/exchange/source-list", "application/vnd.progrss.shared-folder+json", "source-list.json"),
            ("/api/v1/exchange/recent-updates", "application/feed+json", "recent-updates.json"),
        ):
            status, headers, artifact = self.request(route, token=exchange_token, origin=self.extension_origin)
            self.assertEqual(status, 200)
            self.assertEqual(headers["Content-Type"], expected_type)
            self.assertIn(expected_name, headers["Content-Disposition"])
            self.assertGreater(len(artifact), 200)

        status, _headers, site = self.request(
            f"/api/v1/exchange-artifact?id={exchange_id}&kind=site",
            token=self.node.token,
        )
        self.assertEqual(status, 200)
        self.assertTrue(site.startswith(b"PK"))

        status, _headers, body = self.request("/api/v1/exchanges", token=self.node.token)
        self.assertEqual(status, 200)
        exchanges = self.json_document(body)["exchanges"]
        self.assertEqual(len(exchanges), 1)
        self.assertTrue(exchanges[0]["reviewed"])
        self.assertNotIn("token", exchanges[0])

        status, _headers, body = self.request(
            "/api/v1/exchanges/revoke",
            method="POST",
            token=self.node.token,
            origin=self.origin,
            json_body={"exchangeId": exchange_id},
        )
        self.assertEqual(status, 200)
        self.assertEqual(self.json_document(body)["state"], "revoked")
        status, _headers, _body = self.request(
            "/api/v1/exchange-review", token=exchange_token, origin=self.extension_origin
        )
        self.assertEqual(status, 401)
        self.assertEqual(self.node.backup.read_bytes(), before)

    def test_exchange_refuses_stale_library_and_private_handoff_has_no_durable_feed(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            backup = Path(directory) / "library.json"
            backup.write_bytes((FIX / "exchange-backup.json").read_bytes())
            node = NodeState(backup=backup, token="master", origin=self.origin)
            token, preview = node.create_exchange_preview(
                folder="folder-neighborhood",
                curator="Alex",
                note="Local route",
                public_update_url="",
                include_recent_updates=True,
                now=4_000.0,
            )
            self.assertFalse(preview["choices"]["followUpdates"]["available"])
            self.assertTrue(preview["choices"]["addRoute"]["available"])
            self.assertTrue(preview["choices"]["takeBranch"]["available"])
            backup.write_bytes(backup.read_bytes() + b"\n")
            with self.assertRaisesRegex(PairingError, "changed after exchange review") as stale:
                node.create_exchange(
                    token,
                    preview_digest=str(preview["previewDigest"]),
                    library_sha256=str(preview["library"]["sha256"]),
                    now=4_001.0,
                )
            self.assertEqual(stale.exception.status, 409)



if __name__ == "__main__":
    unittest.main()
