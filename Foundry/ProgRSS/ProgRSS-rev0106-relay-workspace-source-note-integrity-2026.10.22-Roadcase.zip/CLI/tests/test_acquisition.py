from __future__ import annotations

import copy
from io import BytesIO
import json
from pathlib import Path
import socket
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
FIX = ROOT / "fixtures"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from acquisition import (  # noqa: E402
    AcquisitionError,
    BROWSER_CAPTURE_CONTOUR_SCHEMA,
    BROWSER_CAPTURE_CONTINUITY_SCHEMA,
    BROWSER_CAPTURE_LEGACY_SCHEMA,
    BROWSER_CAPTURE_PREVIOUS_SCHEMA,
    BROWSER_CAPTURE_SCHEMA,
    FetchResult,
    apply_browser_capture,
    apply_fetch,
    fetch_public_resource,
    resolve_public_addresses,
    source_preview,
    validate_browser_capture,
)


PUBLIC_ADDR = "93.184.216.34"


def resolver_for(address: str):
    def resolve(host: str, port: int, family: int, socktype: int):
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (address, port))]
    return resolve


class FakeResponse:
    def __init__(self, status: int, body: bytes = b"", headers: dict[str, str] | None = None):
        self.status = status
        self._body = BytesIO(body)
        self._headers = {key.lower(): value for key, value in (headers or {}).items()}

    def getheader(self, name: str):
        return self._headers.get(name.lower())

    def read(self, amount: int = -1) -> bytes:
        return self._body.read(amount)


class FakeConnection:
    def __init__(self, response: FakeResponse, calls: list[dict[str, object]]):
        self.response = response
        self.calls = calls
        self.closed = False

    def request(self, method: str, target: str, *, headers: dict[str, str]):
        self.calls.append({"method": method, "target": target, "headers": dict(headers)})

    def getresponse(self) -> FakeResponse:
        return self.response

    def close(self) -> None:
        self.closed = True


def capture_assessment(*, level: str = "steadier") -> dict[str, object]:
    return {
        "schema": "progrss.capture-section-assessment.v1",
        "level": level,
        "summary": "More likely to stay put, based on the structure visible now." if level == "steadier" else "Fragile: weak or noisy structure may require repair.",
        "reasons": ["The selector matches one visible region."],
        "warnings": [] if level == "steadier" else ["The selector depends mostly on generic structure."],
        "signals": {
            "selectorKind": "semantic" if level == "steadier" else "generic",
            "semanticBoundary": level == "steadier",
            "uniqueMatch": True,
            "visibleMatches": 1,
            "hiddenMatches": 0,
            "repeatedEntries": 0,
            "linkedEntries": 0,
            "titledEntries": 0,
            "consistentEntries": 0,
            "clutterElements": 0,
            "textCharacters": 23,
        },
    }


def capture_context() -> dict[str, object]:
    return {
        "schema": "progrss.capture-page-context.v1",
        "notices": [
            {"kind": "continuation", "tone": "boundary", "summary": "This page appears to continue elsewhere. Capture includes only this rendered page."},
            {"kind": "frames", "tone": "boundary", "summary": "Content inside one embedded frame is outside this top-frame capture."},
        ],
        "signals": {
            "continuationLinks": 1, "paginationLandmarks": 1, "continuationControls": 0,
            "partialSetSignals": 0, "virtualMarkers": 0, "scrollWindows": 0,
            "modalLayers": 0, "embeddedFrames": 1, "openShadowRoots": 0, "busyRegions": 0,
        },
    }


def capture_coverage() -> dict[str, object]:
    return {
        "schema": "progrss.capture-coverage-review.v1",
        "decision": "use-current-rendering",
        "acknowledgedNoticeKinds": ["continuation", "frames"],
    }


def browser_capture(*, content: str = "Library closes at six.", selector: str = "", captured_at: str = "2026-10-20T00:00:00.000Z", legacy: bool = False, contour: bool = False, previous: bool = False) -> dict[str, object]:
    schema = BROWSER_CAPTURE_LEGACY_SCHEMA if legacy else (BROWSER_CAPTURE_CONTOUR_SCHEMA if contour else (BROWSER_CAPTURE_PREVIOUS_SCHEMA if previous else BROWSER_CAPTURE_SCHEMA))
    artifact: dict[str, object] = {
        "schema": schema,
        "capturedAt": captured_at,
        "page": {"url": "https://town.test/notices", "title": "Town noticeboard", "language": "en"},
        "source": {"id": "page-weather", "url": "https://town.test/notices"},
        "recipe": {
            "mode": "region", "selector": selector, "titleSelector": "",
            "linkSelector": "", "threshold": 1, "ignoreNumbers": False,
        },
        "capture": {"mode": "region", "matchCount": 1, "content": content, "cards": []},
        "examples": {"matched": [content], "ignored": "Navigation and footer"},
        "provenance": {
            "kind": "rendered-browser-dom", "topFrameOnly": True,
            "isolatedWorld": True, "arbitrarySharedCode": False,
            "extensionVersion": "0.80.0",
        },
    }
    if not legacy:
        artifact["page"]["direction"] = "ltr"
        artifact["selection"] = {"schema": "progrss.capture-selection.v1", "candidateId": "main", "assessment": capture_assessment()}
        artifact["provenance"]["extractorRevision"] = "contour-v1" if contour else "perimeter-v1"
    if schema in {BROWSER_CAPTURE_SCHEMA, BROWSER_CAPTURE_PREVIOUS_SCHEMA}:
        artifact["context"] = capture_context()
    if schema == BROWSER_CAPTURE_SCHEMA:
        artifact["coverage"] = capture_coverage()
    return artifact



def browser_card_capture(keys: list[str], *, partial: bool = True, captured_at: str = "2026-10-20T00:00:00.000Z") -> dict[str, object]:
    cards = [
        {
            "key": key,
            "title": f"Notice {key.upper()}",
            "url": f"https://town.test/notices/{key}",
            "summary": f"Notice {key.upper()} remains visible in this rendered window.",
        }
        for key in keys
    ]
    notices = ([{
        "kind": "partial-render", "tone": "caution",
        "summary": "This list may render only part of its items at once. Capture includes only entries currently present in the page DOM.",
    }] if partial else [])
    signals = {
        "continuationLinks": 0, "paginationLandmarks": 0, "continuationControls": 0,
        "partialSetSignals": 1 if partial else 0, "virtualMarkers": 1 if partial else 0,
        "scrollWindows": 1 if partial else 0, "modalLayers": 0, "embeddedFrames": 0,
        "openShadowRoots": 0, "busyRegions": 0,
    }
    return {
        "schema": BROWSER_CAPTURE_SCHEMA,
        "capturedAt": captured_at,
        "page": {"url": "https://town.test/notices", "title": "Town noticeboard", "language": "en", "direction": "ltr"},
        "source": {"id": "page-weather", "url": "https://town.test/notices"},
        "recipe": {
            "mode": "cards", "selector": "main article", "titleSelector": "h2",
            "linkSelector": "a[href]", "threshold": 1, "ignoreNumbers": False,
        },
        "capture": {"mode": "cards", "matchCount": len(cards), "content": "", "cards": cards},
        "examples": {"matched": [row["summary"] for row in cards[:3]], "ignored": "Navigation and footer"},
        "context": {"schema": "progrss.capture-page-context.v1", "notices": notices, "signals": signals},
        "selection": {
            "schema": "progrss.capture-selection.v1", "candidateId": "repeated",
            "assessment": {
                "schema": "progrss.capture-section-assessment.v1", "level": "steadier",
                "summary": "More likely to stay put, based on the structure visible now.",
                "reasons": ["Most entries have their own destination link."], "warnings": [],
                "signals": {
                    "selectorKind": "semantic", "semanticBoundary": True, "uniqueMatch": False,
                    "visibleMatches": len(cards), "hiddenMatches": 0, "repeatedEntries": len(cards),
                    "linkedEntries": len(cards), "titledEntries": len(cards), "consistentEntries": len(cards),
                    "clutterElements": 0, "textCharacters": sum(len(row["summary"]) for row in cards),
                },
            },
        },
        "coverage": {
            "schema": "progrss.capture-coverage-review.v1",
            "decision": "use-current-rendering" if partial else "no-limiting-boundary-observed",
            "acknowledgedNoticeKinds": ["partial-render"] if partial else [],
        },
        "provenance": {
            "kind": "rendered-browser-dom", "topFrameOnly": True, "isolatedWorld": True,
            "arbitrarySharedCode": False, "extensionVersion": "0.80.0", "extractorRevision": "perimeter-v1",
        },
    }



class AcquisitionTests(unittest.TestCase):
    def backup(self) -> dict[str, object]:
        return json.loads((FIX / "sample-backup.json").read_text())

    def test_resolver_refuses_any_non_public_answer(self) -> None:
        with self.assertRaisesRegex(AcquisitionError, "non-public") as refused:
            resolve_public_addresses("example.test", 443, resolver=resolver_for("127.0.0.1"))
        self.assertEqual(refused.exception.code, "non-public-destination")
        self.assertEqual(refused.exception.outcome, "refused")

    def test_conditional_get_uses_exact_host_and_records_not_modified(self) -> None:
        source = {
            "id": "feed",
            "type": "rss",
            "url": "https://feeds.example.test/news.xml?view=full#ignored",
            "httpCache": {
                "etag": 'W/"abc"',
                "lastModified": "Mon, 19 Oct 2026 20:00:00 GMT",
            },
        }
        calls: list[dict[str, object]] = []
        responses = [FakeResponse(304, headers={"ETag": 'W/"abc"'})]

        def factory(parsed, chosen, timeout):
            self.assertEqual(chosen, PUBLIC_ADDR)
            self.assertEqual(parsed.hostname, "feeds.example.test")
            self.assertEqual(timeout, 20.0)
            return FakeConnection(responses.pop(0), calls)

        result = fetch_public_resource(
            source,
            now=1_792_449_000.0,
            resolver=resolver_for(PUBLIC_ADDR),
            connection_factory=factory,
        )
        self.assertEqual(result.status, 304)
        self.assertEqual(result.body, b"")
        self.assertEqual(result.request_count, 1)
        self.assertEqual(result.final_url, "https://feeds.example.test/news.xml?view=full")
        self.assertEqual(calls[0]["method"], "GET")
        self.assertEqual(calls[0]["target"], "/news.xml?view=full")
        headers = calls[0]["headers"]
        self.assertEqual(headers["Host"], "feeds.example.test")
        self.assertEqual(headers["If-None-Match"], 'W/"abc"')
        self.assertEqual(headers["If-Modified-Since"], "Mon, 19 Oct 2026 20:00:00 GMT")
        self.assertEqual(headers["Accept-Encoding"], "identity")

    def test_cross_origin_redirect_stops_before_second_site(self) -> None:
        source = {"id": "feed", "type": "rss", "url": "https://one.example.test/feed"}
        calls: list[dict[str, object]] = []
        response = FakeResponse(302, headers={"Location": "https://two.example.test/feed"})
        factory_calls: list[str] = []

        def factory(parsed, chosen, timeout):
            factory_calls.append(str(parsed.hostname))
            return FakeConnection(response, calls)

        with self.assertRaisesRegex(AcquisitionError, "stopped before contacting") as moved:
            fetch_public_resource(
                source,
                now=1_792_449_000.0,
                resolver=resolver_for(PUBLIC_ADDR),
                connection_factory=factory,
            )
        self.assertEqual(moved.exception.code, "cross-origin-redirect")
        self.assertEqual(moved.exception.outcome, "moved")
        self.assertEqual(moved.exception.detail["requestCount"], 1)
        self.assertEqual(factory_calls, ["one.example.test"])
        self.assertEqual(len(calls), 1)

    def test_feed_application_adds_items_and_preserves_receipt_facts(self) -> None:
        document = self.backup()
        feed = (FIX / "sample-rss.xml").read_bytes()
        fetched = FetchResult(
            requested_url="https://existing.test/feed.xml",
            final_url="https://existing.test/feed.xml",
            status=200,
            body=feed,
            headers={"contentType": "application/rss+xml", "etag": '"v2"'},
            redirects=(),
            resolved_addresses=(PUBLIC_ADDR,),
            started_at="2026-10-20T00:00:00.000Z",
            completed_at="2026-10-20T00:00:00.100Z",
            duration_ms=100,
            request_count=1,
        )
        applied = apply_fetch(
            document, "feed-existing", fetched,
            stamp="2026-10-20T00:00:00.100Z", enable=False,
        )
        source = next(row for row in applied.document["state"]["sources"] if row["id"] == "feed-existing")
        self.assertEqual(source["lastOutcome"], "changed")
        self.assertEqual(source["httpCache"]["etag"], '"v2"')
        self.assertGreater(applied.summary["itemsAdded"], 0)
        self.assertEqual(applied.outcome, "changed")
        self.assertEqual(applied.evidence["httpStatus"], 200)

    def test_page_watch_creates_baseline_then_before_now_change(self) -> None:
        document = self.backup()
        first = FetchResult(
            requested_url="https://town.test/notices",
            final_url="https://town.test/notices",
            status=200,
            body=b"<html><body><main><h1>Notices</h1><p>Library closes at six.</p></main></body></html>",
            headers={"contentType": "text/html"}, redirects=(), resolved_addresses=(PUBLIC_ADDR,),
            started_at="2026-10-20T00:00:00.000Z", completed_at="2026-10-20T00:00:00.100Z",
            duration_ms=100, request_count=1,
        )
        baseline = apply_fetch(
            document, "page-weather", first,
            stamp="2026-10-20T00:00:00.100Z", enable=True,
        )
        self.assertEqual(baseline.outcome, "baseline")
        self.assertTrue(baseline.summary["enabledNow"])
        self.assertEqual(baseline.summary["itemsAdded"], 0)
        self.assertIn("page-weather", baseline.document["state"]["snapshots"])

        second = FetchResult(
            requested_url="https://town.test/notices",
            final_url="https://town.test/notices",
            status=200,
            body=b"<html><body><main><h1>Notices</h1><p>Library closes at eight tonight.</p></main></body></html>",
            headers={"contentType": "text/html"}, redirects=(), resolved_addresses=(PUBLIC_ADDR,),
            started_at="2026-10-20T01:00:00.000Z", completed_at="2026-10-20T01:00:00.100Z",
            duration_ms=100, request_count=1,
        )
        changed = apply_fetch(
            baseline.document, "page-weather", second,
            stamp="2026-10-20T01:00:00.100Z", enable=False,
        )
        self.assertEqual(changed.outcome, "changed")
        self.assertEqual(changed.summary["itemsAdded"], 1)
        item = changed.document["state"]["items"][0]
        self.assertEqual(item["sourceId"], "page-weather")
        self.assertEqual(item["change"]["schema"], "progrss.page-change.v1")
        self.assertIn("Changed", item["change"]["summary"])
        self.assertTrue(item["change"]["before"])
        self.assertTrue(item["change"]["after"])

    def test_browser_capture_is_json_safe_exact_and_creates_baseline_without_network(self) -> None:
        document = self.backup()
        artifact = browser_capture()
        normalized = validate_browser_capture(
            artifact, source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0,
        )
        self.assertEqual(normalized["schema"], BROWSER_CAPTURE_SCHEMA)
        self.assertEqual(normalized["selection"]["assessment"]["level"], "steadier")
        self.assertEqual(normalized["context"]["schema"], "progrss.capture-page-context.v1")
        self.assertEqual([row["kind"] for row in normalized["context"]["notices"]], ["continuation", "frames"])
        self.assertEqual(normalized["coverage"]["schema"], "progrss.capture-coverage-review.v1")
        self.assertEqual(normalized["coverage"]["decision"], "use-current-rendering")
        self.assertEqual(normalized["coverage"]["acknowledgedNoticeKinds"], ["continuation", "frames"])
        self.assertNotIn("html", normalized)
        self.assertNotIn("cookies", normalized)
        applied = apply_browser_capture(
            document, "page-weather", normalized,
            stamp="2026-10-20T00:00:00.100Z", enable=True, now=1_792_454_400.0,
        )
        self.assertEqual(applied.outcome, "baseline")
        self.assertEqual(applied.summary["itemsAdded"], 0)
        self.assertTrue(applied.summary["enabledNow"])
        self.assertEqual(applied.evidence["capture"]["provenance"]["kind"], "rendered-browser-dom")
        source = next(row for row in applied.document["state"]["sources"] if row["id"] == "page-weather")
        self.assertTrue(source["enabled"])
        self.assertEqual(source["browserCapture"]["schema"], "progrss.browser-capture-provenance.v1")
        self.assertEqual(source["browserCapture"]["pageUrl"], "https://town.test/notices")
        self.assertEqual(source["browserCapture"]["assessmentLevel"], "steadier")
        self.assertTrue(source["browserCapture"]["possibleContinuation"])
        self.assertEqual(source["browserCapture"]["embeddedFrames"], 1)
        self.assertEqual(source["browserCapture"]["coverageDecision"], "use-current-rendering")
        self.assertEqual(source["browserCapture"]["acknowledgedBoundaryKinds"], ["continuation", "frames"])
        self.assertTrue(source["browserCapture"]["partialViewAcknowledged"])
        self.assertEqual(applied.evidence["capture"]["selection"]["candidateId"], "main")
        self.assertEqual(applied.evidence["capture"]["coverage"]["decision"], "use-current-rendering")
        self.assertIn("page-weather", applied.document["state"]["snapshots"])

    def test_browser_capture_rejects_stale_mismatched_and_unsupported_fields(self) -> None:
        stale = browser_capture(captured_at="2026-10-19T23:00:00.000Z")
        with self.assertRaisesRegex(AcquisitionError, "stale"):
            validate_browser_capture(stale, source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0)
        wrong = browser_capture()
        wrong["page"]["url"] = "https://other.test/notices"
        with self.assertRaisesRegex(AcquisitionError, "does not match"):
            validate_browser_capture(wrong, source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0)
        extra = browser_capture()
        extra["cookies"] = "secret"
        with self.assertRaisesRegex(AcquisitionError, "unsupported fields"):
            validate_browser_capture(extra, source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0)
        malformed_threshold = browser_capture()
        malformed_threshold["recipe"]["threshold"] = "four"
        with self.assertRaisesRegex(AcquisitionError, "threshold must be an integer"):
            validate_browser_capture(malformed_threshold, source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0)
        object_text = browser_capture()
        object_text["capture"]["content"] = {"private": "not text"}
        with self.assertRaisesRegex(AcquisitionError, "text and a card list"):
            validate_browser_capture(object_text, source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0)

    def test_browser_capture_accepts_legacy_v1_without_inventing_assessment(self) -> None:
        normalized = validate_browser_capture(
            browser_capture(legacy=True), source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0,
        )
        self.assertEqual(normalized["schema"], BROWSER_CAPTURE_LEGACY_SCHEMA)
        self.assertNotIn("selection", normalized)

    def test_browser_capture_accepts_contour_v2_without_inventing_page_context(self) -> None:
        normalized = validate_browser_capture(
            browser_capture(contour=True), source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0,
        )
        self.assertEqual(normalized["schema"], BROWSER_CAPTURE_CONTOUR_SCHEMA)
        self.assertIn("selection", normalized)
        self.assertNotIn("context", normalized)
        self.assertNotIn("coverage", normalized)

    def test_browser_capture_accepts_perimeter_v3_without_inventing_coverage_review(self) -> None:
        normalized = validate_browser_capture(
            browser_capture(previous=True), source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0,
        )
        self.assertEqual(normalized["schema"], BROWSER_CAPTURE_PREVIOUS_SCHEMA)
        self.assertIn("selection", normalized)
        self.assertIn("context", normalized)
        self.assertNotIn("coverage", normalized)

    def test_browser_capture_rejects_inconsistent_page_context(self) -> None:
        missing_notice = browser_capture()
        missing_notice["context"]["notices"] = []
        with self.assertRaisesRegex(AcquisitionError, "notices do not match"):
            validate_browser_capture(missing_notice, source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0)
        wrong_tone = browser_capture()
        wrong_tone["context"]["notices"][0]["tone"] = "included"
        with self.assertRaisesRegex(AcquisitionError, "unsupported or duplicated"):
            validate_browser_capture(wrong_tone, source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0)
        extra_signal = browser_capture()
        extra_signal["context"]["signals"]["secretScore"] = 91
        with self.assertRaisesRegex(AcquisitionError, "unsupported fields"):
            validate_browser_capture(extra_signal, source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0)

    def test_browser_capture_requires_exact_coverage_review_for_limiting_boundaries(self) -> None:
        missing = browser_capture()
        missing.pop("coverage")
        with self.assertRaisesRegex(AcquisitionError, "coverage review"):
            validate_browser_capture(missing, source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0)

        partial = browser_capture()
        partial["coverage"]["acknowledgedNoticeKinds"] = ["continuation"]
        with self.assertRaisesRegex(AcquisitionError, "every visible limiting boundary"):
            validate_browser_capture(partial, source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0)

        wrong_decision = browser_capture()
        wrong_decision["coverage"] = {
            "schema": "progrss.capture-coverage-review.v1",
            "decision": "no-limiting-boundary-observed",
            "acknowledgedNoticeKinds": [],
        }
        with self.assertRaisesRegex(AcquisitionError, "every visible limiting boundary"):
            validate_browser_capture(wrong_decision, source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0)

        no_limits = browser_capture()
        no_limits["context"]["notices"] = []
        no_limits["context"]["signals"] = {key: 0 for key in no_limits["context"]["signals"]}
        no_limits["coverage"] = {
            "schema": "progrss.capture-coverage-review.v1",
            "decision": "no-limiting-boundary-observed",
            "acknowledgedNoticeKinds": [],
        }
        normalized = validate_browser_capture(no_limits, source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0)
        self.assertEqual(normalized["coverage"]["decision"], "no-limiting-boundary-observed")

    def test_browser_capture_rejects_unbounded_or_inconsistent_section_assessment(self) -> None:
        bad_level = browser_capture()
        bad_level["selection"]["assessment"]["level"] = "certain"
        with self.assertRaisesRegex(AcquisitionError, "unsupported level"):
            validate_browser_capture(bad_level, source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0)
        inconsistent = browser_capture()
        inconsistent["selection"]["assessment"]["signals"]["repeatedEntries"] = 1
        inconsistent["selection"]["assessment"]["signals"]["linkedEntries"] = 2
        with self.assertRaisesRegex(AcquisitionError, "exceeds"):
            validate_browser_capture(inconsistent, source_id="page-weather", source_url="https://town.test/notices", now=1_792_454_400.0)

    def test_browser_capture_recipe_change_starts_a_fresh_baseline(self) -> None:
        document = self.backup()
        document["state"]["snapshots"]["page-weather"] = {
            "mode": "region", "content": "Old baseline", "matchCount": 1,
        }
        artifact = browser_capture(content="A newly selected notices region.", selector="main .notices")
        applied = apply_browser_capture(
            document, "page-weather", artifact,
            stamp="2026-10-20T00:00:00.100Z", enable=True, now=1_792_454_400.0,
        )
        self.assertEqual(applied.outcome, "baseline")
        self.assertTrue(applied.summary["recipeChanged"])
        self.assertEqual(applied.summary["itemsAdded"], 0)
        source = next(row for row in applied.document["state"]["sources"] if row["id"] == "page-weather")
        self.assertEqual(source["selector"], "main .notices")
        self.assertEqual(source["recipeVersion"], 1)
        self.assertEqual(applied.document["state"]["snapshots"]["page-weather"]["text"], "A newly selected notices region.")


    def test_partial_render_window_shift_preserves_baseline_and_creates_no_mass_alert(self) -> None:
        document = self.backup()
        baseline = apply_browser_capture(
            document, "page-weather", browser_card_capture(["a", "b", "c"]),
            stamp="2026-10-20T00:00:00.100Z", enable=True, now=1_792_454_400.0,
        )
        self.assertEqual(baseline.outcome, "baseline")
        snapshot_before = copy.deepcopy(baseline.document["state"]["snapshots"]["page-weather"])
        source_before = next(row for row in baseline.document["state"]["sources"] if row["id"] == "page-weather")
        accepted_capture_digest = source_before["browserCapture"]["artifactSha256"]

        shifted = apply_browser_capture(
            baseline.document, "page-weather", browser_card_capture(["d", "e", "f"]),
            stamp="2026-10-20T00:01:00.100Z", enable=False, now=1_792_454_400.0,
        )
        self.assertEqual(shifted.outcome, "coverage-shift")
        self.assertTrue(shifted.summary["baselinePreserved"])
        self.assertEqual(shifted.summary["itemsAdded"], 0)
        self.assertEqual(shifted.document["state"]["snapshots"]["page-weather"], snapshot_before)
        self.assertEqual(shifted.evidence["continuity"]["schema"], BROWSER_CAPTURE_CONTINUITY_SCHEMA)
        self.assertEqual(shifted.evidence["continuity"]["action"], "hold")
        self.assertEqual(shifted.evidence["continuity"]["reason"], "partial-render-window-shift")
        self.assertEqual(shifted.evidence["continuity"]["overlapPercent"], 0)
        source_after = next(row for row in shifted.document["state"]["sources"] if row["id"] == "page-weather")
        self.assertEqual(source_after["lastOutcome"], "coverage-shift")
        self.assertEqual(source_after["browserCapture"]["artifactSha256"], accepted_capture_digest)
        self.assertFalse(any(row.get("sourceId") == "page-weather" for row in shifted.document["state"].get("items", [])))

        overlapping = apply_browser_capture(
            shifted.document, "page-weather", browser_card_capture(["a", "b", "d"]),
            stamp="2026-10-20T00:02:00.100Z", enable=False, now=1_792_454_400.0,
        )
        self.assertEqual(overlapping.evidence["continuity"]["action"], "accept")
        self.assertEqual(overlapping.evidence["continuity"]["overlapPercent"], 67)
        self.assertEqual(overlapping.outcome, "changed")
        self.assertGreater(overlapping.summary["itemsAdded"], 0)

    def test_partial_render_boundary_change_is_held_even_when_entries_overlap(self) -> None:
        document = self.backup()
        baseline = apply_browser_capture(
            document, "page-weather", browser_card_capture(["a", "b", "c"], partial=False),
            stamp="2026-10-20T00:00:00.100Z", enable=True, now=1_792_454_400.0,
        )
        changed_boundary = apply_browser_capture(
            baseline.document, "page-weather", browser_card_capture(["a", "b", "c"], partial=True),
            stamp="2026-10-20T00:01:00.100Z", enable=False, now=1_792_454_400.0,
        )
        self.assertEqual(changed_boundary.outcome, "coverage-shift")
        self.assertEqual(changed_boundary.evidence["continuity"]["reason"], "partial-render-boundary-changed")
        self.assertTrue(changed_boundary.evidence["continuity"]["boundaryChanged"])
        self.assertEqual(changed_boundary.evidence["continuity"]["overlapPercent"], 100)

    def test_preview_explains_paused_page_recipe_without_network(self) -> None:
        preview = source_preview(self.backup(), "page-weather")
        self.assertTrue(preview["paused"])
        self.assertEqual(preview["action"], "enable-and-check")
        self.assertEqual(preview["actionLabel"], "Enable and check once")
        self.assertEqual(preview["type"], "page")
        self.assertEqual(preview["site"], "town.test")
        self.assertEqual(preview["pageRecipe"]["mode"], "region")


if __name__ == "__main__":
    unittest.main()
