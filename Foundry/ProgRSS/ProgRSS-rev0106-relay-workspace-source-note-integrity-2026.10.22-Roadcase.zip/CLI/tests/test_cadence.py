from __future__ import annotations

import copy
from email.utils import format_datetime
import json
from pathlib import Path
import sys
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from datetime import datetime, timezone
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
FIX = ROOT / "fixtures"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from acquisition import FetchResult  # noqa: E402
from cadence.common import CadenceBusy, CadenceError, parse_retry_after  # noqa: E402
from cadence.server import PulseHTTPServer, PulseHandler  # noqa: E402
from cadence.service import CadenceService  # noqa: E402
from cadence.store import CadenceStore  # noqa: E402
from node_server import NodeState  # noqa: E402
from node_store import NodeStore  # noqa: E402


class PulseTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)
        self.node_path = self.directory / "node.sqlite3"
        self.cadence_path = self.directory / "cadence.sqlite3"
        NodeStore.create_from_backup(FIX / "sample-backup.json", self.node_path, now=1_000.0)
        self.node_store = NodeStore(self.node_path)
        self.receipt = self._manual_witness(now=2_000.0)
        self.receipt_path = self.directory / "witness-receipt.json"
        self.receipt_path.write_text(json.dumps(self.receipt, ensure_ascii=False), encoding="utf-8")
        CadenceStore.create(
            self.cadence_path,
            node_store_id=self.node_store.store_id,
            node_store_path=self.node_path,
            now=2_050.0,
        )
        self.service = CadenceService(self.cadence_path, origin_gap_seconds=0)

    def tearDown(self) -> None:
        try:
            self.service.stop_loop()
        except Exception:
            pass
        self.temp.cleanup()

    def _manual_witness(self, *, now: float) -> dict[str, object]:
        node = NodeState(backup=self.node_path, token="master", store=self.node_store)
        token, preview = node.create_acquisition_preview("feed-existing", now=now)
        fetched = FetchResult(
            requested_url="https://existing.test/feed.xml",
            final_url="https://existing.test/feed.xml",
            status=200,
            body=(FIX / "sample-rss.xml").read_bytes(),
            headers={"contentType": "application/rss+xml", "etag": '"pulse-v1"'},
            redirects=(),
            resolved_addresses=("93.184.216.34",),
            started_at="2026-10-20T00:00:00.000Z",
            completed_at="2026-10-20T00:00:00.100Z",
            duration_ms=100,
            request_count=1,
        )
        with patch("node_server.fetch_public_resource", return_value=fetched):
            receipt, replayed = node.run_acquisition(
                operation_id="pulse-eligibility-000001",
                base_sha256=str(preview["library"]["sha256"]),
                preview_token=token,
                preview_digest=str(preview["previewDigest"]),
                source_id="feed-existing",
                action="check-now",
                now=now,
            )
        self.assertFalse(replayed)
        self.assertRegex(str(receipt["request"]["sourceIdentitySha256"]), r"^[0-9a-f]{64}$")
        return receipt

    def _create_plan(self, *, now: float = 3_000.0, start_paused: bool = False) -> dict[str, object]:
        result = self.service.create_plan(
            self.receipt_path,
            interval_seconds=900,
            jitter_seconds=0,
            start_paused=start_paused,
            acknowledge=True,
            now=now,
        )
        return result["plan"]

    @staticmethod
    def _not_modified(now: float = 4_000.0) -> FetchResult:
        stamp = datetime.fromtimestamp(now, timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
        return FetchResult(
            requested_url="https://existing.test/feed.xml",
            final_url="https://existing.test/feed.xml",
            status=304,
            body=b"",
            headers={"contentType": "application/rss+xml", "etag": '"pulse-v1"'},
            redirects=(),
            resolved_addresses=("93.184.216.34",),
            started_at=stamp,
            completed_at=stamp,
            duration_ms=20,
            request_count=1,
        )

    def test_review_and_create_are_offline_and_explicit(self) -> None:
        review = self.service.review_plan(
            self.receipt_path, interval_seconds=900, jitter_seconds=0, now=3_000.0,
        )
        self.assertEqual(review["schema"], "progrss.cadence-review.v1")
        self.assertFalse(review["network"])
        self.assertFalse(review["writes"])
        self.assertTrue(review["consequences"]["usesPackagedWitnessPath"])
        self.assertTrue(review["consequences"]["pauseMeansZeroCadenceRequests"])
        with self.assertRaisesRegex(CadenceError, "acknowledgement"):
            self.service.create_plan(
                self.receipt_path, interval_seconds=900, jitter_seconds=0,
                acknowledge=False, now=3_000.0,
            )
        plan = self._create_plan(now=3_000.0)
        self.assertEqual(plan["state"], "scheduled")
        self.assertEqual(plan["nextDueAt"], "1970-01-01T01:05:00.000Z")
        self.assertEqual(self.node_store.read_library().revision, 2)

    def test_capture_or_old_identity_evidence_is_refused(self) -> None:
        capture = copy.deepcopy(self.receipt)
        capture["effects"]["networkRequests"] = 0
        capture["request"]["transport"] = "extension-rendered-dom"
        path = self.directory / "capture.json"
        path.write_text(json.dumps(capture), encoding="utf-8")
        with self.assertRaisesRegex(CadenceError, "zero-request|browser-assisted"):
            self.service.review_plan(path, interval_seconds=900, now=3_000.0)

        old = copy.deepcopy(self.receipt)
        old["request"].pop("sourceIdentitySha256", None)
        old_path = self.directory / "old.json"
        old_path.write_text(json.dumps(old), encoding="utf-8")
        with self.assertRaisesRegex(CadenceError, "predates Pulse"):
            self.service.review_plan(old_path, interval_seconds=900, now=3_000.0)

    def test_pause_means_no_due_dispatch_and_no_fetch(self) -> None:
        plan = self._create_plan(now=3_000.0)
        self.service.pause(str(plan["planId"]), now=3_100.0)
        with patch("node_server.fetch_public_resource", side_effect=AssertionError("paused plan fetched")) as network:
            result = self.service.run_due(now=4_000.0)
        network.assert_not_called()
        self.assertEqual(result["duePlans"], 0)
        self.assertEqual(result["networkRequests"], 0)

    def test_packaged_adapter_uses_witness_and_retains_one_receipt(self) -> None:
        plan = self._create_plan(now=3_000.0)
        with patch("node_server.fetch_public_resource", return_value=self._not_modified()) as network:
            result = self.service.dispatch_plan(str(plan["planId"]), now=3_901.0)
        network.assert_called_once()
        self.assertEqual(result["schema"], "progrss.cadence-dispatch-result.v1")
        self.assertEqual(result["outcome"], "unchanged")
        self.assertEqual(result["networkRequests"], 1)
        self.assertEqual(result["receipt"]["schema"], "progrss.node.acquisition-receipt.v1")
        self.assertEqual(self.node_store.read_library().revision, 3)
        receipts = self.node_store.list_acquisition_receipts()
        self.assertEqual(len(receipts), 2)
        self.assertEqual(receipts[0]["receiptId"], result["receiptId"])

    def test_lost_response_after_node_commit_replays_without_second_request(self) -> None:
        plan = self._create_plan(now=3_000.0)
        with patch("node_server.fetch_public_resource", return_value=self._not_modified()) as network:
            with self.assertRaisesRegex(RuntimeError, "after Node acquisition commit"):
                self.service.dispatch_plan(str(plan["planId"]), now=3_901.0, fail_after_node_commit=True)
        network.assert_called_once()
        self.assertEqual(self.node_store.read_library().revision, 3)
        slot = self.service.store.recent_slots(1)[0]
        self.assertEqual(slot["state"], "started")

        restarted = CadenceService(self.cadence_path, origin_gap_seconds=0)
        with patch("node_server.fetch_public_resource", side_effect=AssertionError("exact retry fetched again")) as no_network:
            result = restarted.dispatch_plan(str(plan["planId"]), now=3_902.0)
        no_network.assert_not_called()
        self.assertTrue(result["nodeReceiptReplayed"])
        self.assertTrue(result["replayed"])
        self.assertEqual(restarted.store.recent_slots(1)[0]["state"], "completed")
        self.assertEqual(self.node_store.read_library().revision, 3)

    def test_completed_due_slot_returns_stored_result(self) -> None:
        plan = self._create_plan(now=3_000.0)
        with patch("node_server.fetch_public_resource", return_value=self._not_modified()):
            first = self.service.dispatch_plan(str(plan["planId"]), now=3_901.0)
        slot = self.service.store.recent_slots(1)[0]
        self.assertEqual(slot["state"], "completed")
        # Directly starting the same stable slot demonstrates durable exact replay.
        replay = self.service.store.start_slot(
            slot_id=slot["slotId"], plan_id=slot["planId"], due_at=slot["dueAt"],
            request_sha256=slot["requestSha256"], now=4_000.0,
        )
        self.assertTrue(replay.replayed)
        self.assertEqual(replay.slot["result"]["receiptId"], first["receiptId"])

    def test_http_date_retry_after_is_bounded_and_supported(self) -> None:
        now = datetime(2026, 10, 20, 12, 0, tzinfo=timezone.utc).timestamp()
        future = format_datetime(datetime(2026, 10, 20, 14, 30, tzinfo=timezone.utc), usegmt=True)
        parsed = parse_retry_after(future, now=now)
        self.assertIsNotNone(parsed)
        assert parsed is not None
        self.assertEqual(parsed.kind, "http-date")
        self.assertEqual(parsed.seconds, 9_000)
        past = format_datetime(datetime(2026, 10, 19, 14, 30, tzinfo=timezone.utc), usegmt=True)
        self.assertEqual(parse_retry_after(past, now=now).seconds, 0)  # type: ignore[union-attr]

    def test_single_live_lease_refuses_second_owner(self) -> None:
        store = self.service.store
        store.acquire_lease("owner-one", now=4_000.0, seconds=45)
        with self.assertRaises(CadenceBusy):
            store.acquire_lease("owner-two", now=4_001.0, seconds=45)
        store.acquire_lease("owner-two", now=4_046.0, seconds=45)
        self.assertEqual(store.lease_status(now=4_047.0)["ownerId"], "owner-two")  # type: ignore[index]

    def test_loopback_server_requires_capability_and_same_origin(self) -> None:
        token = "pulse-admin-token"
        server = PulseHTTPServer(
            ("127.0.0.1", 0), PulseHandler,
            service=self.service, token=token, review_config=None,
        )
        server.origin = f"http://127.0.0.1:{server.server_address[1]}"
        server.review_document = None
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with self.assertRaises(urllib.error.HTTPError) as denied:
                urllib.request.urlopen(server.origin + "/api/v1/status", timeout=3)
            self.assertEqual(denied.exception.code, 401)
            request = urllib.request.Request(
                server.origin + "/api/v1/status",
                headers={"Authorization": f"Bearer {token}"},
            )
            with urllib.request.urlopen(request, timeout=3) as response:
                document = json.load(response)
            self.assertTrue(document["adapter"]["packagedWitness"])
            foreign = urllib.request.Request(
                server.origin + "/api/v1/run-due", data=b"{}", method="POST",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Origin": "https://foreign.example",
                    "Content-Type": "application/json",
                },
            )
            with self.assertRaises(urllib.error.HTTPError) as refused:
                urllib.request.urlopen(foreign, timeout=3)
            self.assertEqual(refused.exception.code, 403)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=3)


if __name__ == "__main__":
    unittest.main()
