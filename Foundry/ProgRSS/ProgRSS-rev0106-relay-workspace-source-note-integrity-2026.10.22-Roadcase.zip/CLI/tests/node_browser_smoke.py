#!/usr/bin/env python3
"""Rendered browser smoke lane for the ProgRSS Node web UI.

The actual loopback HTTP boundary is covered by test_node_server.py. This lane renders
exact shipped HTML/CSS/JS from a local file and supplies same-origin API responses in
process because the release host's managed Chromium policy blocks direct HTTP navigation.
"""
from __future__ import annotations

import asyncio
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
import tempfile
import urllib.parse

from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import relay  # noqa: E402
from fieldbook import (  # noqa: E402
    build_exchange_fieldwork_scenario,
    build_exchange_sender_fieldwork_scenario,
    build_trace_fieldwork_scenario,
    render_fieldbook_html,
)
from debrief import build_debrief_workspace, render_debrief_html  # noqa: E402

from node_store import NodeStore  # noqa: E402
from node_server import (  # noqa: E402
    EXCHANGE_TTL_SECONDS,
    PAIRING_TTL_SECONDS,
    REVISION,
    VERSION,
    NodeState,
    _library_snapshot,
    _read_backup,
    _simple_folder_rows,
)

ARTIFACTS = Path(os.environ.get("PROGRSS_NODE_ARTIFACTS", "/tmp/progrss-rev0080-node"))
ARTIFACTS.mkdir(parents=True, exist_ok=True)
TOKEN = "rendered-node-capability"
ORIGIN = "http://127.0.0.1:43161"


def exchange_payloads() -> tuple[dict[str, object], ...]:
    backup = ROOT / "fixtures" / "exchange-backup.json"
    node = NodeState(backup=backup, token=TOKEN, origin=ORIGIN)
    now = time.time()
    preview_token, preview = node.create_exchange_preview(
        folder="folder-neighborhood",
        curator="Neighborhood readers",
        note="A practical route for local meetings and useful notices.",
        public_update_url="https://exchange.example.test/neighborhood/progrss-source-list.json",
        include_recent_updates=True,
        now=now,
    )
    exchange_token, created = node.create_exchange(
        preview_token,
        preview_digest=str(preview["previewDigest"]),
        library_sha256=str(preview["library"]["sha256"]),
        now=now + 10,
    )
    created = copy.deepcopy(created)
    created["url"] = f"{ORIGIN}/#exchange={urllib.parse.quote(exchange_token, safe='')}"
    created["expiresInSeconds"] = EXCHANGE_TTL_SECONDS
    grant = node.exchange_by_id(str(created["exchangeId"]))
    summary = node.exchange_summary(grant)

    document, raw = _read_backup(backup)
    folders = [row for row in _simple_folder_rows(document["state"]) if int(row.get("sourceCount") or 0) > 0]
    curation = {
        "schema": "progrss.node.exchange.v1",
        "state": "curation",
        "library": {"file": backup.name, "sha256": hashlib.sha256(raw).hexdigest()},
        "folders": folders,
        "readOnly": True,
        "network": False,
        "writes": False,
    }
    library, stats = _library_snapshot(backup)
    status = {
        "schema": "progrss.node.status.v1",
        "version": VERSION,
        "revision": REVISION,
        "scope": "loopback-read-only",
        "library": library["library"]["file"],
        "stats": stats,
        "capabilities": {
            "readLibrary": True,
            "writeLibrary": False,
            "fetchSources": False,
            "publish": False,
            "prepareExchange": True,
            "preparePublicationPackage": True,
            "pairExtension": True,
            "nodeToNode": False,
            "webrtcCourier": False,
        },
        "instanceFingerprint": node.fingerprint,
        "pairingCapabilities": {
            "schema": "progrss.node.capabilities.v1",
            "readLibrarySummary": True,
            "readItems": False,
            "readSourceAddresses": False,
            "writeLibrary": False,
            "fetchSources": False,
            "publish": False,
            "merge": False,
            "nodeToNode": False,
            "webrtcCourier": False,
        },
        "activePairings": 1,
        "activeExchanges": 0,
    }
    pairing_token, invitation = node.create_invitation(now=now)
    invitation = copy.deepcopy(invitation)
    invitation["url"] = f"{ORIGIN}/#pair={urllib.parse.quote(pairing_token, safe='')}"
    invitation["expiresInSeconds"] = PAIRING_TTL_SECONDS
    pairings = [{
        "pairId": "0123456789abcdefabcd",
        "origin": "chrome-extension://smoke-extension",
        "clientName": "ProgRSS Extension",
        "clientVersion": VERSION,
        "createdAt": "2026-10-19T22:00:00Z",
        "lastSeenAt": "2026-10-19T22:05:00Z",
        "reviewedLibrarySha256": library["library"]["sha256"],
    }]
    return status, library, curation, preview, created, summary, invitation, pairings


def merge_payloads() -> tuple[dict[str, object], dict[str, object]]:
    sources = [
        {"id": "conflict", "type": "rss", "title": "Council notices", "author": "Desk", "url": "https://council.example/feed", "enabled": True},
        {"id": "recipe", "type": "rss", "title": "Transit alerts", "author": "Desk", "url": "https://old-transit.example/feed", "enabled": True},
        {"id": "curator", "type": "rss", "title": "Library events", "author": "Desk", "url": "https://library.example/feed", "enabled": True},
        {"id": "local", "type": "rss", "title": "Repair calendar", "author": "Desk", "url": "https://repair.example/feed", "enabled": True},
        {"id": "agreed", "type": "rss", "title": "Garden log", "author": "Desk", "url": "https://garden.example/feed", "enabled": True},
        {"id": "removed", "type": "rss", "title": "Old bulletin", "author": "Desk", "url": "https://old-bulletin.example/feed", "enabled": True},
    ]
    initial_state = {
        "sources": sources,
        "collections": [{"id": "route", "title": "Neighborhood signal", "mode": "union", "members": [{"kind": "source", "id": row["id"]} for row in sources]}],
        "items": [],
    }
    initial = relay.make_bundle(
        initial_state, "Neighborhood signal", curator="Neighborhood readers",
        note="Sources for practical local decisions.",
        update_url="https://publish.example/neighborhood/source-list.json",
        exported_at="2026-10-18T20:00:00.000Z",
    )
    imported, _ = relay.import_bundle({"sources": [], "collections": [], "items": []}, initial)
    by_id = {row["id"]: row for row in imported["sources"]}
    by_id["conflict"]["title"] = "My council tracker"
    by_id["local"]["title"] = "My repair dates"
    by_id["agreed"]["title"] = "Community garden log"

    later_state = copy.deepcopy(initial_state)
    later_by_id = {row["id"]: row for row in later_state["sources"]}
    later_by_id["conflict"]["title"] = "Official council tracker"
    later_by_id["recipe"]["url"] = "https://new-transit.example/alerts.xml"
    later_by_id["curator"]["title"] = "Library and learning events"
    later_by_id["agreed"]["title"] = "Community garden log"
    later_state["sources"] = [row for row in later_state["sources"] if row["id"] != "removed"]
    later_state["sources"].append({"id": "added", "type": "page", "title": "Road closure board", "author": "Desk", "url": "https://roads.example/closures", "mode": "cards", "selector": "article", "titleSelector": "h2", "linkSelector": "a", "enabled": True})
    later_state["collections"][0]["members"] = [{"kind": "source", "id": row["id"]} for row in later_state["sources"]]
    later = relay.make_bundle(
        later_state, "Neighborhood signal", curator="Neighborhood readers",
        note="Sources for practical local decisions and closures.",
        update_url="https://publish.example/neighborhood/source-list.json",
        exported_at="2026-10-19T20:00:00.000Z",
    )
    review = relay.review_bundle_update(imported, later)
    response = {
        "schema": "progrss.node.merge-review.v1", "state": "review",
        "library": {"file": "imported-neighborhood.json", "sha256": "7" * 64},
        "review": review, "readOnly": True, "network": False, "writes": False,
    }
    return later, response


def operation_payloads() -> dict[str, object]:
    source_state = {
        "sources": [
            {"id": "feed-civic", "type": "rss", "title": "Civic dispatch", "author": "Field desk", "url": "https://civic.example/feed.xml", "enabled": True},
            {"id": "page-works", "type": "page", "title": "Public works board", "author": "Field desk", "url": "https://works.example/projects", "mode": "cards", "selector": "article", "titleSelector": "h2", "linkSelector": "a", "enabled": True},
        ],
        "collections": [
            {"id": "root-new", "title": "Civic field notes", "mode": "union", "members": [{"kind": "collection", "id": "branch-new"}]},
            {"id": "branch-new", "title": "Street and council", "mode": "union", "members": [
                {"kind": "source", "id": "feed-civic", "reason": "Primary council reporting for this branch."},
                {"kind": "source", "id": "page-works", "reason": "Direct project-board changes.\nمتابعة المجلس <not markup>"},
            ]},
        ],
        "items": [],
    }
    source_list = relay.make_bundle(
        source_state, "Civic field notes", curator="Field desk",
        note="Useful public records for street and council decisions.",
        exported_at="2026-10-19T23:00:00.000Z",
    )
    with tempfile.TemporaryDirectory(prefix="progrss-node-smoke-") as directory:
        store_path = Path(directory) / "nightstand.sqlite3"
        NodeStore.create_from_backup(ROOT / "fixtures" / "exchange-backup.json", store_path, now=1792449000.0)
        store = NodeStore(store_path)
        node = NodeState(backup=store_path, token=TOKEN, store=store, origin=ORIGIN)
        before_library, before_stats = node.snapshot()
        before_document, before_raw, before_revision, before_updated = node.current_document()
        before_curation = {
            "schema": "progrss.node.exchange.v1", "state": "curation",
            "library": {"file": store_path.name, "mode": "node-owned", "sha256": hashlib.sha256(before_raw).hexdigest(), "revision": before_revision, "updatedAt": before_updated},
            "folders": [row for row in _simple_folder_rows(before_document["state"]) if int(row.get("sourceCount") or 0) > 0],
            "readOnly": True, "operationAvailable": True, "network": False, "writes": False,
        }
        capture_token, capture_invitation = node.create_capture_invitation("page-notices", now=1792449040.0)
        capture_invitation = copy.deepcopy(capture_invitation)
        capture_invitation.pop("token", None)
        capture_invitation["url"] = f"{ORIGIN}/#capture={urllib.parse.quote(capture_token, safe='')}"
        capture_invitation["expiresInSeconds"] = 10 * 60
        options = node.branch_options(source_list)
        preview_token, operation_preview = node.create_branch_operation_preview(source_list, folder="branch-new", now=1792449060.0)
        receipt, replayed = node.commit_branch_operation(
            operation_id="op-smoke-0123456789abcdef",
            base_sha256=str(operation_preview["library"]["sha256"]),
            preview_token=preview_token,
            preview_digest=str(operation_preview["previewDigest"]),
            now=1792449120.0,
        )
        assert not replayed
        after_library, after_stats = node.snapshot()
        after_document, after_raw, after_revision, after_updated = node.current_document()
        after_curation = {
            "schema": "progrss.node.exchange.v1", "state": "curation",
            "library": {"file": store_path.name, "mode": "node-owned", "sha256": hashlib.sha256(after_raw).hexdigest(), "revision": after_revision, "updatedAt": after_updated},
            "folders": [row for row in _simple_folder_rows(after_document["state"]) if int(row.get("sourceCount") or 0) > 0],
            "readOnly": True, "operationAvailable": True, "network": False, "writes": False,
        }
        def status_for(library: dict[str, object], stats: dict[str, object], count: int) -> dict[str, object]:
            return {
                "schema": "progrss.node.status.v1", "version": VERSION, "revision": REVISION,
                "scope": "loopback-node-owned", "library": library["library"],
                "instanceFingerprint": node.fingerprint, "stats": stats,
                "capabilities": {
                    "readLibrary": True, "writeLibrary": True, "adoptReviewedBranch": True,
                    "durableOperationReceipts": True, "rollbackSnapshots": True,
                    "fetchSources": True, "manualAcquisition": True, "browserAssistedCapture": True, "reviewHeldWindows": True, "replaceHeldBaseline": True, "scheduledAcquisition": False,
                    "publish": False, "prepareExchange": True,
                    "preparePublicationPackage": True, "reviewLaterCopy": True,
                    "pairExtension": True, "nodeToNode": False, "webrtcCourier": False,
                },
                "pairingCapabilities": {"schema": "progrss.node.capabilities.v1", "readLibrarySummary": True, "readItems": False, "readSourceAddresses": False, "writeLibrary": False, "fetchSources": False, "browserAssistedCapture": False, "publish": False, "merge": False, "nodeToNode": False, "webrtcCourier": False},
                "activePairings": 1, "activeExchanges": 0, "operationReceipts": count,
                "acquisitionReceipts": 0, "interruptedAcquisitions": 0,
            }
        operation_result = {
            "schema": "progrss.node.operation-result.v1", "state": "committed", "replayed": False,
            "receipt": receipt, "library": after_library["library"], "network": False, "writes": True,
        }
        witness_library = copy.deepcopy(before_library)
        for source in witness_library.get("sources", []):
            if source.get("id") == "page-notices":
                source["enabled"] = True
                source["lastOutcome"] = "baseline"
                source["lastCheckedAt"] = "2026-10-20T04:50:00Z"
                source["lastSuccessfulAt"] = "2026-10-20T04:50:00Z"
                source["lastItems"] = 0
        witness_library["library"] = {**witness_library["library"], "revision": 2, "sha256": "b" * 64, "updatedAt": "2026-10-20T04:50:00Z"}
        witness_status = status_for(witness_library, before_stats, 0)
        witness_status["library"] = witness_library["library"]
        witness_status["acquisitionReceipts"] = 1
        acquisition_preview = {
            "schema": "progrss.node.acquisition-preview.v1", "state": "review",
            "operationType": "check-source-once", "previewToken": "witness-preview-token",
            "previewDigest": "a" * 64, "expiresAt": "2026-10-20T05:00:00Z",
            "library": {"file": store_path.name, "mode": "node-owned", "sha256": before_library["library"]["sha256"], "revision": 1},
            "source": {"sourceId": "page-notices", "title": "Town notices", "type": "page", "site": "town.example", "url": "https://town.example/notices", "enabled": False, "action": "enable-and-check", "validators": {}, "pageRecipe": {"mode": "cards", "selector": ".notice", "titleSelector": "h2", "linkSelector": "a", "threshold": 1}},
            "limits": {"method": "GET", "timeoutSeconds": 20, "responseBytes": 2000000, "sameOriginRedirects": 5},
            "consequences": {"browserCookiesSent": False, "browserCredentialsSent": False, "pageJavaScriptExecuted": False, "automaticScheduleCreated": False},
            "network": False, "writes": False,
        }
        acquisition_receipt = {
            "schema": "progrss.node.acquisition-receipt.v1", "receiptId": "sha256:" + "c" * 64,
            "operationId": "acq-smoke-0123456789abcdef", "operationType": "check-source-once", "sourceId": "page-notices",
            "outcome": "baseline", "committedAt": "2026-10-20T04:50:00Z", "attemptCount": 1,
            "baseLibrarySha256": before_library["library"]["sha256"], "previewDigest": "a" * 64,
            "resultLibrarySha256": "b" * 64, "resultRevision": 2,
            "request": {"sourceTitle": "Town notices", "sourceHost": "town.example", "sourceType": "page", "action": "enable-and-check"},
            "summary": {"itemsAdded": 0, "message": "Baseline saved. Future meaningful changes can now produce Before/Now evidence."},
            "effects": {"networkRequests": 1, "sourceEnabled": True, "automaticScheduleCreated": False},
            "evidence": {"fetch": {"httpStatus": 200, "redirects": [], "resolvedAddresses": ["203.0.113.19"], "bytes": 2841}},
        }
        acquisition_result = {"schema": "progrss.node.acquisition-result.v1", "state": "committed", "replayed": False, "receipt": acquisition_receipt, "library": witness_library["library"], "network": True, "writes": True}
        acquisitions_before = {"schema": "progrss.node.acquisition-result.v1", "state": "admin-list", "receipts": [], "jobs": [], "network": False, "writes": False}
        acquisitions_after = {"schema": "progrss.node.acquisition-result.v1", "state": "admin-list", "receipts": [acquisition_receipt], "jobs": [], "network": False, "writes": False}

        # A later browser Capture held a disjoint partial window. The Node UI receives
        # the same bounded documents as the real HTTP path, while API behavior itself
        # is covered by test_node_server.py.
        held_library = copy.deepcopy(witness_library)
        for source in held_library.get("sources", []):
            if source.get("id") == "page-notices":
                source["lastOutcome"] = "coverage-shift"
                source["lastCheckedAt"] = "2026-10-20T05:05:00Z"
                source["heldBaselineAvailable"] = True
                source["heldBaselineAt"] = "2026-10-20T05:05:00Z"
                source["heldBaselineOverlapPercent"] = 0
                source["heldObservationCount"] = 2
        held_library["library"] = {**held_library["library"], "revision": 3, "sha256": "d" * 64, "updatedAt": "2026-10-20T05:05:00Z"}
        held_status = status_for(held_library, before_stats, 0)
        held_status["library"] = held_library["library"]
        held_status["acquisitionReceipts"] = 2
        baseline_preview = {
            "schema": "progrss.node.baseline-preview.v1", "state": "review",
            "operationType": "replace-held-page-baseline", "previewId": "anchor-preview-smoke",
            "previewToken": "anchor-preview-token", "previewDigest": "e" * 64,
            "expiresAt": "2026-10-20T05:15:00Z",
            "library": {"sha256": held_library["library"]["sha256"], "revision": 3},
            "source": {
                "sourceId": "page-notices", "sourceTitle": "Town notices", "sourceHost": "town.example",
                "heldOperationId": "capture-smoke-held-0001", "heldReceiptId": "sha256:" + "f" * 64,
                "url": "https://town.example/notices", "heldAt": "2026-10-20T05:05:00Z",
                "accepted": {"mode": "cards", "units": 3, "unitLabel": "records", "capturedAt": "2026-10-20T04:50:00Z", "sha256": "1" * 64},
                "proposed": {"mode": "cards", "units": 3, "unitLabel": "records", "capturedAt": "2026-10-20T05:05:00Z", "sha256": "2" * 64},
            },
            "continuity": {
                "reason": "partial-render-window-shift",
                "message": "This partial rendering shares too little stable content with the accepted baseline to justify an ordinary add-or-remove comparison.",
                "overlapPercent": 0, "previousUnits": 3, "currentUnits": 3, "sharedUnits": 0,
                "previousBoundaryKinds": ["partial-render"], "currentBoundaryKinds": ["partial-render"],
            },
            "consequences": {
                "acceptedBaselineReplaced": True, "earlierCompleteLibrarySnapshotRetained": True,
                "historicalChangeAlertCreated": False, "recipeChanged": False,
                "sourceEnabledChanged": False, "networkRequests": 0, "automaticScheduleCreated": False,
            },
            "network": False, "writes": False,
        }
        bearing_review = {
            "schema": "progrss.node.bearing-review.v2", "state": "review",
            "library": {
                "file": store_path.name, "mode": "node-owned",
                "storeSchema": "progrss.node-store.v4",
                "sha256": held_library["library"]["sha256"], "revision": 3,
            },
            "source": {
                "id": "page-notices", "title": "Town notices", "host": "town.example",
                "url": "https://town.example/notices",
                "accepted": {"mode": "cards", "units": 3, "unitLabel": "records", "capturedAt": "2026-10-20T04:50:00Z", "sha256": "1" * 64},
                "currentHeld": {"mode": "cards", "units": 3, "unitLabel": "records", "capturedAt": "2026-10-20T05:05:00Z", "sha256": "2" * 64},
                "heldAt": "2026-10-20T05:05:00Z",
                "heldOperationId": "capture-smoke-held-0001",
                "heldReceiptId": "sha256:" + "f" * 64,
            },
            "history": {
                "schema": "progrss.node.capture-hold-history.v1",
                "currentObservation": 1, "priorObservationsRetained": 1,
                "maximumPriorObservations": 8,
            },
            "diagnosis": {
                "kind": "moving-rendered-window",
                "title": "Moving rendered window",
                "summary": "Several similarly sized partial observations expose substantially different records. The browser may be showing different windows into one larger collection.",
                "cannotProve": "This does not prove that records were removed, added, or that the publisher intended a new collection.",
                "recommendedRoute": "anchor",
                "observationsReviewed": 2, "compatiblePriorObservations": 1,
                "boundaryKinds": ["partial-render"], "lowOverlapComparisons": 1,
            },
            "trace": {
                "schema": "progrss.node.bearing-trace.v1",
                "accepted": {"mode": "cards", "units": 3, "unitLabel": "visible records", "capturedAt": "2026-10-20T04:50:00Z", "sha256": "1" * 64},
                "observations": [
                    {
                        "ordinal": 1, "current": False, "heldAt": "2026-10-20T05:02:00Z",
                        "snapshot": {"mode": "cards", "units": 3, "unitLabel": "visible records", "capturedAt": "2026-10-20T05:02:00Z", "sha256": "3" * 64},
                        "relationshipToPrevious": {"kind": "different-window", "title": "Different window", "summary": "A similarly sized observation exposes substantially different stable units."},
                        "overlapToPreviousPercent": 0, "sharedUnitsWithPrevious": 0, "enoughEvidence": True, "similarSize": True,
                        "overlapToAcceptedPercent": 0, "continuityReason": "partial-render-window-shift",
                        "boundaryKinds": ["partial-render"], "assessmentLevel": "watchful", "assessmentSummary": "Usable, but one or more page details may shift.",
                    },
                    {
                        "ordinal": 2, "current": True, "heldAt": "2026-10-20T05:05:00Z",
                        "snapshot": {"mode": "cards", "units": 3, "unitLabel": "visible records", "capturedAt": "2026-10-20T05:05:00Z", "sha256": "2" * 64},
                        "relationshipToPrevious": {"kind": "different-window", "title": "Different window", "summary": "A similarly sized observation exposes substantially different stable units."},
                        "overlapToPreviousPercent": 0, "sharedUnitsWithPrevious": 0, "enoughEvidence": True, "similarSize": True,
                        "overlapToAcceptedPercent": 0, "continuityReason": "partial-render-window-shift",
                        "boundaryKinds": ["partial-render"], "assessmentLevel": "watchful", "assessmentSummary": "Usable, but one or more page details may shift.",
                    },
                ],
                "oldestFirst": True, "maximumPriorObservations": 8, "network": False, "writes": False,
            },
            "recipeFootprint": {
                "schema": "progrss.node.recipe-footprint.v1", "kind": "semantic-boundary", "label": "Semantic boundary",
                "summary": "The saved recipe uses an understandable declarative boundary, but the publisher can still change it.",
                "mode": "cards",
                "reasons": ["The selector uses semantic elements such as main, article, section, or list records.", "Repeated records include an explicit title selector."],
                "warnings": [], "lastCaptureAssessmentLevel": "watchful",
                "lastCaptureAssessmentSummary": "Usable, but one or more page details may shift.",
                "recommendedRoute": "anchor",
                "routeExplanation": "The current diagnosis points to Anchor because the page may be exposing another window of the same collection.",
                "network": False, "writes": False,
                "advanced": {"selector": "main article", "titleSelector": "h2", "linkSelector": "a[href]", "positionalSelector": False, "generatedLookingToken": False, "combinatorCount": 0},
            },
            "routes": {
                "keepAcceptedBaseline": True, "anchorReviewAvailable": True,
                "freshCaptureAvailable": True, "automaticRepairAvailable": False,
            },
            "advanced": {
                "sourceIdentitySha256": "a" * 64,
                "acceptedSnapshotSha256": "1" * 64,
                "observations": [
                    {"heldAt": "2026-10-20T05:02:00Z", "proposedUnits": 3, "boundaryKinds": ["partial-render"], "overlapPercent": 0},
                    {"heldAt": "2026-10-20T05:05:00Z", "proposedUnits": 3, "boundaryKinds": ["partial-render"], "overlapPercent": 0},
                ],
                "comparisons": [
                    {"earlierHeldAt": "2026-10-20T05:02:00Z", "laterHeldAt": "2026-10-20T05:05:00Z", "overlapPercent": 0, "similarSize": True},
                ],
                "recipe": {"selector": "main article", "titleSelector": "h2", "linkSelector": "a[href]"},
            },
            "network": False, "writes": False,
        }

        baseline_library = copy.deepcopy(held_library)
        for source in baseline_library.get("sources", []):
            if source.get("id") == "page-notices":
                source["lastOutcome"] = "baseline-replaced"
                source["heldBaselineAvailable"] = False
                source.pop("heldBaselineAt", None)
                source.pop("heldBaselineOverlapPercent", None)
        baseline_library["library"] = {**baseline_library["library"], "revision": 4, "sha256": "3" * 64, "updatedAt": "2026-10-20T05:06:00Z"}
        baseline_receipt = {
            "schema": "progrss.node.operation-receipt.v1", "receiptId": "sha256:" + "4" * 64,
            "operationId": "anchor-smoke-0123456789ab", "operationType": "replace-held-page-baseline",
            "actor": "local-admin", "committedAt": "2026-10-20T05:06:00Z",
            "baseLibrarySha256": held_library["library"]["sha256"], "previewDigest": baseline_preview["previewDigest"],
            "resultLibrarySha256": baseline_library["library"]["sha256"], "resultRevision": 4,
            "summary": {"baselineReplaced": True, "itemsAdded": 0, "historicalChangeAlertsCreated": 0, "previousMode": "cards", "acceptedMode": "cards", "previousUnits": 3, "acceptedUnits": 3, "overlapPercent": 0, "message": "The held rendered window became the accepted baseline without creating a historical change alert."},
            "selection": {"sourceId": "page-notices", "sourceTitle": "Town notices", "sourceHost": "town.example", "heldOperationId": "capture-smoke-held-0001", "heldReceiptId": "sha256:" + "f" * 64},
            "evidence": {"schema": "progrss.capture-baseline-replacement.v1", "heldOperationId": "capture-smoke-held-0001", "heldReceiptId": "sha256:" + "f" * 64, "previousSnapshotSha256": "1" * 64, "acceptedSnapshotSha256": "2" * 64, "continuity": baseline_preview["continuity"], "networkRequests": 0, "automaticScheduleCreated": False},
            "effects": {"networkRequests": 0, "watchedSiteContacted": False, "historicalChangeAlertsCreated": 0, "acceptedBaselineReplaced": True, "earlierLibrarySnapshotRetained": True, "automaticScheduleCreated": False, "browserAuthorityImported": False},
            "rollbackEvidence": {"snapshotId": "anchor-before-smoke-0123456789ab", "librarySha256": held_library["library"]["sha256"], "automaticRollback": False},
        }
        baseline_result = {"schema": "progrss.node.operation-result.v1", "state": "committed", "replayed": False, "receipt": baseline_receipt, "library": baseline_library["library"], "network": False, "writes": True}
        fieldbook_scenario = build_trace_fieldwork_scenario(
            bearing_review, version=VERSION, revision=REVISION, codename="Roadcase", generated_at="2026-10-20T05:07:00Z",
        )
        fieldbook_html = render_fieldbook_html(fieldbook_scenario).decode("utf-8")
        debrief_workspace = build_debrief_workspace(
            [], version=VERSION, revision=REVISION, codename="Roadcase", generated_at="2026-10-20T05:08:00Z",
        )
        debrief_html = render_debrief_html(debrief_workspace).decode("utf-8")
        baseline_status = status_for(baseline_library, before_stats, 1)
        baseline_status["library"] = baseline_library["library"]
        baseline_status["acquisitionReceipts"] = 2
        return {
            "sourceList": source_list, "options": options, "preview": operation_preview,
            "result": operation_result, "receipt": receipt,
            "beforeStatus": status_for(before_library, before_stats, 0),
            "beforeLibrary": before_library, "beforeCuration": before_curation,
            "afterStatus": status_for(after_library, after_stats, 1),
            "afterLibrary": after_library, "afterCuration": after_curation,
            "acquisitionPreview": acquisition_preview, "acquisitionResult": acquisition_result,
            "captureInvitation": capture_invitation,
            "witnessStatus": witness_status, "witnessLibrary": witness_library,
            "acquisitionsBefore": acquisitions_before, "acquisitionsAfter": acquisitions_after,
            "operationsBefore": {"schema": "progrss.node.operation-result.v1", "state": "admin-list", "nodeOwned": True, "operations": [], "network": False, "writes": False},
            "operationsAfterBaseline": {"schema": "progrss.node.operation-result.v1", "state": "admin-list", "nodeOwned": True, "operations": [baseline_receipt], "network": False, "writes": False},
            "operationsAfter": {"schema": "progrss.node.operation-result.v1", "state": "admin-list", "nodeOwned": True, "operations": [receipt, baseline_receipt], "network": False, "writes": False},
            "heldStatus": held_status, "heldLibrary": held_library,
            "bearingReview": bearing_review, "fieldbookHtml": fieldbook_html, "debriefHtml": debrief_html,
            "baselinePreview": baseline_preview, "baselineResult": baseline_result,
            "baselineStatus": baseline_status, "baselineLibrary": baseline_library,
        }


async def main() -> int:
    _status, _library, _curation, preview, created, exchange_summary, invitation, pairings = exchange_payloads()
    exchange_sender_fieldbook_scenario = build_exchange_sender_fieldwork_scenario(
        preview, version=VERSION, revision=REVISION, codename="Roadcase", generated_at="2026-10-20T05:08:30Z",
    )
    exchange_sender_fieldbook_html = render_fieldbook_html(exchange_sender_fieldbook_scenario).decode("utf-8")
    exchange_fieldbook_scenario = build_exchange_fieldwork_scenario(
        created, version=VERSION, revision=REVISION, codename="Roadcase", generated_at="2026-10-20T05:09:00Z",
    )
    exchange_fieldbook_html = render_fieldbook_html(exchange_fieldbook_scenario).decode("utf-8")
    merge_bundle, merge_response = merge_payloads()
    operation = operation_payloads()
    status = operation["beforeStatus"]
    library = operation["beforeLibrary"]
    curation = operation["beforeCuration"]
    errors: list[str] = []

    async with async_playwright() as playwright:
        executable = os.environ.get("PROGRSS_CHROMIUM") or shutil.which("chromium") or shutil.which("chromium-browser") or shutil.which("google-chrome")
        launch = {"headless": True, "args": ["--no-sandbox", "--allow-file-access-from-files"]}
        if executable:
            launch["executable_path"] = executable
        browser = await playwright.chromium.launch(**launch)
        try:
            page = await browser.new_page(viewport={"width": 1180, "height": 900}, device_scale_factor=1)
            page.on("console", lambda message: errors.append(f"console:{message.type}:{message.text}") if message.type == "error" else None)
            page.on("pageerror", lambda error: errors.append(f"page:{error}"))
            html = (ROOT / "node_web" / "index.html").read_text()
            html = html.replace('<link rel="stylesheet" href="app.css">', '').replace('<script src="app.js"></script>', '')
            await page.set_content(html, wait_until="domcontentloaded")
            await page.add_style_tag(content=(ROOT / "node_web" / "app.css").read_text())
            payload = json.dumps({
                "token": TOKEN,
                "status": status,
                "library": library,
                "curation": curation,
                "preview": preview,
                "created": created,
                "exchangeSummary": exchange_summary,
                "exchangeSenderFieldbookHtml": exchange_sender_fieldbook_html,
                "exchangeFieldbookHtml": exchange_fieldbook_html,
                "pairings": pairings,
                "invitation": invitation,
                "mergeResponse": merge_response,
                "operation": operation,
            }, ensure_ascii=False)
            await page.evaluate(f"""
                (() => {{
                  const payload = {payload};
                  const local = new Map();
                  const session = new Map();
                  Object.defineProperty(window, 'localStorage', {{value: {{
                    getItem: key => local.has(String(key)) ? local.get(String(key)) : null,
                    setItem: (key, value) => local.set(String(key), String(value)),
                    removeItem: key => local.delete(String(key))
                  }}, configurable: true}});
                  Object.defineProperty(window, 'sessionStorage', {{value: {{
                    getItem: key => session.has(String(key)) ? session.get(String(key)) : null,
                    setItem: (key, value) => session.set(String(key), String(value)),
                    removeItem: key => session.delete(String(key))
                  }}, configurable: true}});
                  globalThis.__nodeAuth = [];
                  globalThis.__nodeRequests = [];
                  globalThis.__historyTargets = [];
                  globalThis.__sharedData = null;
                  history.replaceState = (_state, _title, target) => globalThis.__historyTargets.push(String(target));
                  Object.defineProperty(navigator, 'share', {{value: async data => {{ globalThis.__sharedData = structuredClone(data); }}, configurable: true}});
                  Object.defineProperty(navigator, 'canShare', {{value: data => Boolean(data?.url), configurable: true}});
                  Object.defineProperty(navigator, 'clipboard', {{value: {{writeText: async value => {{ globalThis.__copied = String(value); }}}}, configurable: true}});
                  let pairings = structuredClone(payload.pairings);
                  let exchanges = [];
                  let operationCommitted = false;
                  let acquisitionCommitted = false;
                  let baselineCommitted = false;
                  globalThis.fetch = async (path, options = {{}}) => {{
                    const method = String(options?.method || 'GET').toUpperCase();
                    const route = String(path);
                    globalThis.__nodeAuth.push(options?.headers?.Authorization || '');
                    globalThis.__nodeRequests.push({{route, method, body: String(options?.body || '')}});
                    let body;
                    let responseStatus = 200;
                    if (route.endsWith('/status')) body = operationCommitted ? payload.operation.afterStatus : baselineCommitted ? payload.operation.baselineStatus : acquisitionCommitted ? payload.operation.heldStatus : payload.operation.beforeStatus;
                    else if (route.endsWith('/library')) body = operationCommitted ? payload.operation.afterLibrary : baselineCommitted ? payload.operation.baselineLibrary : acquisitionCommitted ? payload.operation.heldLibrary : payload.operation.beforeLibrary;
                    else if (route.endsWith('/curation')) body = operationCommitted ? payload.operation.afterCuration : payload.operation.beforeCuration;
                    else if (route.endsWith('/branch-options') && method === 'POST') body = payload.operation.options;
                    else if (route.endsWith('/operation-previews') && method === 'POST') {{body = payload.operation.preview; responseStatus = 201;}}
                    else if (route.endsWith('/bearing-reviews') && method === 'POST') {{body = payload.operation.bearingReview; responseStatus = 200;}}
                    else if (route.endsWith('/fieldwork-kits') && method === 'POST') {{body = payload.operation.fieldbookHtml; responseStatus = 200;}}
                    else if (route.endsWith('/exchange-sender-fieldwork-kits') && method === 'POST') {{body = payload.exchangeSenderFieldbookHtml; responseStatus = 200;}}
                    else if (route.endsWith('/exchange-fieldwork-kits') && method === 'POST') {{body = payload.exchangeFieldbookHtml; responseStatus = 200;}}
                    else if (route.endsWith('/debrief-kits') && method === 'POST') {{body = payload.operation.debriefHtml; responseStatus = 200;}}
                    else if (route.endsWith('/baseline-previews') && method === 'POST') {{body = payload.operation.baselinePreview; responseStatus = 201;}}
                    else if (route.endsWith('/operations') && method === 'POST') {{
                      const operationType = JSON.parse(options.body || '{{}}').operationType || '';
                      if (operationType === 'replace-held-page-baseline') {{baselineCommitted = true; body = payload.operation.baselineResult;}}
                      else {{operationCommitted = true; body = payload.operation.result;}}
                      responseStatus = 201;
                    }}
                    else if (route.endsWith('/operations')) body = operationCommitted ? payload.operation.operationsAfter : baselineCommitted ? payload.operation.operationsAfterBaseline : payload.operation.operationsBefore;
                    else if (route.endsWith('/capture-invitations') && method === 'POST') {{body = payload.operation.captureInvitation; responseStatus = 201;}}
                    else if (route.endsWith('/acquisition-previews') && method === 'POST') {{body = payload.operation.acquisitionPreview; responseStatus = 201;}}
                    else if (route.endsWith('/acquisitions') && method === 'POST') {{acquisitionCommitted = true; body = payload.operation.acquisitionResult; responseStatus = 201;}}
                    else if (route.endsWith('/acquisitions')) body = acquisitionCommitted ? payload.operation.acquisitionsAfter : payload.operation.acquisitionsBefore;
                    else if (route.includes('/operation-snapshot')) body = {{snapshot:true}};
                    else if (route.endsWith('/merge-reviews') && method === 'POST') body = payload.mergeResponse;
                    else if (route.endsWith('/exchange-previews') && method === 'POST') {{body = payload.preview; responseStatus = 201;}}
                    else if (route.endsWith('/exchanges') && method === 'POST') {{exchanges = [structuredClone(payload.exchangeSummary)]; body = payload.created; responseStatus = 201;}}
                    else if (route.endsWith('/exchanges/revoke') && method === 'POST') {{
                      const exchangeId = JSON.parse(options.body || '{{}}').exchangeId || '';
                      exchanges = exchanges.filter(row => row.exchangeId !== exchangeId);
                      body = {{schema:'progrss.node.exchange.v1', state:'revoked', exchangeId}};
                    }}
                    else if (route.endsWith('/exchanges')) body = {{schema:'progrss.node.exchange.v1', state:'admin-list', exchanges:structuredClone(exchanges)}};
                    else if (route.endsWith('/pairing-invitations') && method === 'POST') {{body = payload.invitation; responseStatus = 201;}}
                    else if (route.endsWith('/pairings/revoke') && method === 'POST') {{
                      const pairId = JSON.parse(options.body || '{{}}').pairId || '';
                      pairings = pairings.filter(row => row.pairId !== pairId);
                      body = {{schema:'progrss.node.pairing.v1', state:'revoked', pairId}};
                    }}
                    else if (route.endsWith('/pairings')) body = {{schema:'progrss.node.pairing.v1', state:'admin-list', pairings:structuredClone(pairings)}};
                    else if (route.endsWith('/stop')) body = {{stopping:true}};
                    else {{body = {{error:'not found'}}; responseStatus = 404;}}
                    return {{
                      ok: responseStatus < 400,
                      status: responseStatus,
                      json: async () => structuredClone(body),
                      headers: {{get: name => {{
                        const key = String(name).toLowerCase();
                        if (key === 'content-disposition') {{
                          if (route.endsWith('/exchange-sender-fieldwork-kits')) return `attachment; filename="ProgRSS-Fieldbook-${{payload.created.node?.revision || 'rev0080'}}-Exchange-Sender-smoke.html"`;
                          if (route.endsWith('/exchange-fieldwork-kits')) return `attachment; filename="ProgRSS-Fieldbook-${{payload.created.node?.revision || 'rev0080'}}-Exchange-smoke.html"`;
                          if (route.endsWith('/fieldwork-kits')) return `attachment; filename="ProgRSS-Fieldbook-${{payload.created.node?.revision || 'rev0080'}}-smoke.html"`;
                          if (route.endsWith('/debrief-kits')) return `attachment; filename="ProgRSS-Debrief-${{payload.created.node?.revision || 'rev0080'}}-smoke.html"`;
                          return 'attachment; filename="progrss-before-op-smoke.json"';
                        }}
                        if (key === 'content-type') return (route.endsWith('/fieldwork-kits') || route.endsWith('/exchange-fieldwork-kits') || route.endsWith('/exchange-sender-fieldwork-kits') || route.endsWith('/debrief-kits')) ? 'text/html; charset=utf-8' : 'application/json';
                        return '';
                      }}}},
                      blob: async () => new Blob([typeof body === 'string' ? body : JSON.stringify(body || {{}})]),
                      arrayBuffer: async () => new TextEncoder().encode(typeof body === 'string' ? body : JSON.stringify(body || {{}})).buffer,
                    }};
                  }};
                  location.hash = `token=${{payload.token}}`;
                }})();
            """)
            await page.add_script_tag(content=(ROOT / "node_web" / "app.js").read_text())
            await page.wait_for_function("document.querySelector('#status')?.classList.contains('good')")
            assert await page.evaluate("sessionStorage.getItem('progrss-node-token')") == TOKEN
            history_targets = await page.evaluate("globalThis.__historyTargets")
            assert history_targets and all('token=' not in target for target in history_targets), history_targets
            assert await page.evaluate("globalThis.__nodeAuth") == [f"Bearer {TOKEN}"] * 7
            assert await page.evaluate("document.documentElement.dataset.theme") == "dark"
            assert "Node-owned library ready" in await page.locator("#status").inner_text()
            assert await page.locator("#stat-sources").inner_text() == "3"
            assert await page.locator("#stat-unread").inner_text() == "2"
            assert await page.locator(".item-card").count() == 2
            await page.screenshot(path=str(ARTIFACTS / "progrss-node-dark.png"), full_page=True)

            await page.locator("#theme-toggle").click()
            assert await page.evaluate("document.documentElement.dataset.theme") == "light"
            await page.screenshot(path=str(ARTIFACTS / "progrss-node-light.png"), full_page=True)
            await page.locator("#theme-toggle").click()

            await page.locator('[data-view="sources"]').click()
            assert await page.locator("#view-sources").is_visible()
            assert await page.locator(".source-card").count() == 3
            assert "Manual acquisition available" in await page.locator("#witness-mode").inner_text()
            await page.locator('.source-capture-button[data-source-id="page-notices"]').click()
            await page.wait_for_function("document.querySelector('#capture-request').hidden === false")
            capture_text = await page.locator("#capture-request").inner_text()
            for phrase in ("Open this watched page in the Extension", "Town notices", "Browser keeps the login", "Text and links only", "One durable result", "No schedule is created"):
                assert phrase.lower() in capture_text.lower(), (phrase, capture_text)
            assert (await page.locator("#capture-url").input_value()).startswith(f"{ORIGIN}/#capture=")
            await page.locator("#copy-capture").click()
            assert (await page.evaluate("globalThis.__copied")).startswith(f"{ORIGIN}/#capture=")
            await page.evaluate("document.querySelector('#capture-request').scrollIntoView({block:'start'}); window.scrollBy(0,-170)")
            await page.screenshot(path=str(ARTIFACTS / "progrss-node-capture-request.png"), full_page=False)
            await page.evaluate("""() => {
              for (const node of document.querySelectorAll('.topbar, .tabs')) {
                node.dataset.captureVisibility = node.style.visibility;
                node.style.visibility = 'hidden';
              }
            }""")
            try:
                await page.locator("#capture-request").screenshot(path=str(ARTIFACTS / "progrss-node-capture-request-card.png"))
            finally:
                await page.evaluate("""() => {
                  for (const node of document.querySelectorAll('.topbar, .tabs')) {
                    node.style.visibility = node.dataset.captureVisibility || '';
                    delete node.dataset.captureVisibility;
                  }
                }""")
            await page.locator("#close-capture").click()
            await page.locator('.source-check-button[data-source-id="page-notices"]').click()
            await page.wait_for_function("document.querySelector('#witness-review').hidden === false")
            witness_review = await page.locator("#witness-review").inner_text()
            for phrase in ("Review this check", "Town notices", "Paused now", "One public GET", "another site stops before that site is contacted", "No recurring schedule"):
                assert phrase.lower() in witness_review.lower(), (phrase, witness_review)
            assert await page.locator("#commit-witness").is_disabled()
            await page.evaluate("document.querySelector('#witness-review').scrollIntoView({block:'start'}); window.scrollBy(0,-18)")
            await page.screenshot(path=str(ARTIFACTS / "progrss-node-witness-review.png"), full_page=False)
            await page.locator("#witness-review").screenshot(path=str(ARTIFACTS / "progrss-node-witness-review-card.png"))
            await page.locator("#witness-confirm").check()
            assert await page.locator("#commit-witness").is_enabled()
            await page.locator("#commit-witness").click()
            await page.wait_for_function("document.querySelector('#witness-result').hidden === false")
            witness_result = await page.locator("#witness-result").inner_text()
            for phrase in ("Check completed", "Baseline saved", "1", "HTTP requests", "Acquisition receipt"):
                assert phrase.lower() in witness_result.lower(), (phrase, witness_result)
            assert await page.locator("#witness-history-count").inner_text() == "1"
            await page.evaluate("document.querySelector('#witness-result').scrollIntoView({block:'start'}); window.scrollBy(0,-18)")
            await page.screenshot(path=str(ARTIFACTS / "progrss-node-witness-receipt.png"), full_page=False)
            await page.locator("#witness-result").screenshot(path=str(ARTIFACTS / "progrss-node-witness-receipt-card.png"))

            assert await page.locator('.bearing-source-button[data-source-id="page-notices"]').is_visible()
            source_card_text = await page.locator('.source-card:has(.bearing-source-button[data-source-id="page-notices"])').inner_text()
            assert "2 unresolved held observations" in source_card_text
            await page.locator('.bearing-source-button[data-source-id="page-notices"]').click()
            await page.wait_for_function("document.querySelector('#bearing-review').hidden === false")
            bearing_text = await page.locator("#bearing-review").inner_text()
            for phrase in (
                "Understand held windows", "Moving rendered window", "No repair applied",
                "Observation trail", "Accepted baseline", "Held observation 2", "Different window",
                "Current watched-section footprint", "Semantic boundary",
                "Zero site requests", "Open Anchor", "Begin a fresh Capture", "This does not prove",
            ):
                assert phrase.lower() in bearing_text.lower(), (phrase, bearing_text)
            assert "main article" not in bearing_text.lower(), bearing_text
            await page.evaluate("document.querySelector('#bearing-review').scrollIntoView({block:'start'}); window.scrollBy(0,-18)")
            await page.screenshot(path=str(ARTIFACTS / "progrss-node-trace-review.png"), full_page=False)
            await page.evaluate("document.querySelector('.topbar').style.display='none'; document.querySelector('.tabs').style.display='none'")
            await page.locator("#bearing-review").screenshot(path=str(ARTIFACTS / "progrss-node-trace-review-card.png"))
            await page.locator("#bearing-review details.witness-evidence summary").click()
            advanced_trace_text = await page.locator("#bearing-review-facts").inner_text()
            for phrase in ("Trace schema", "Saved selector", "main article", "Title selector", "Link selector"):
                assert phrase.lower() in advanced_trace_text.lower(), (phrase, advanced_trace_text)
            await page.locator("#bearing-review").screenshot(path=str(ARTIFACTS / "progrss-node-trace-advanced-card.png"))
            await page.locator("#bearing-review details.witness-evidence summary").click()
            await page.locator("#bearing-review details.fieldbook-tools summary").click()
            fieldbook_copy = await page.locator("#bearing-review .fieldbook-tools").inner_text()
            for phrase in ("Test the wording with the actual interface", "no participant identity", "no source address or selector", "saves nothing automatically"):
                assert phrase.lower() in fieldbook_copy.lower(), (phrase, fieldbook_copy)
            async with page.expect_download() as download_info:
                await page.locator("#bearing-fieldbook").click()
            fieldbook_download = await download_info.value
            assert fieldbook_download.suggested_filename.startswith("ProgRSS-Fieldbook-rev0080")
            fieldbook_path = ARTIFACTS / "ProgRSS-Fieldbook-rev0080-smoke.html"
            await fieldbook_download.save_as(str(fieldbook_path))
            fieldbook_text = fieldbook_path.read_text()
            assert "no telemetry" in fieldbook_text.lower()
            assert "town.example" not in fieldbook_text.lower()
            async with page.expect_download() as debrief_download_info:
                await page.locator("#bearing-debrief").click()
            debrief_download = await debrief_download_info.value
            assert debrief_download.suggested_filename.startswith("ProgRSS-Debrief-rev0080")
            debrief_path = ARTIFACTS / "ProgRSS-Debrief-rev0080-smoke.html"
            await debrief_download.save_as(str(debrief_path))
            debrief_text = debrief_path.read_text()
            assert "find patterns. do not score people." in debrief_text.lower()
            assert "raw notes excluded from export" in debrief_text.lower()
            assert "fetch(" not in debrief_text
            await page.locator("#bearing-review").screenshot(path=str(ARTIFACTS / "progrss-node-fieldbook-control-card.png"))
            await page.evaluate("document.querySelector('.topbar').style.display=''; document.querySelector('.tabs').style.display=''")
            await page.locator("#theme-toggle").click()
            assert await page.evaluate("document.documentElement.dataset.theme") == "light"
            await page.locator("#bearing-review").screenshot(path=str(ARTIFACTS / "progrss-node-trace-review-light-card.png"))
            await page.locator("#theme-toggle").click()
            await page.locator("#open-bearing-anchor").click()
            await page.wait_for_function("document.querySelector('#baseline-review').hidden === false")
            baseline_review_text = await page.locator("#baseline-review").inner_text()
            for phrase in (
                "Review a replacement baseline", "Accepted now", "Held proposal", "0% stable overlap",
                "No past alert invented", "Earlier library retained", "Zero site requests",
                "Use this held rendering as the new baseline",
            ):
                assert phrase.lower() in baseline_review_text.lower(), (phrase, baseline_review_text)
            assert await page.locator("#commit-baseline").is_disabled()
            await page.evaluate("document.querySelector('#baseline-review').scrollIntoView({block:'start'}); window.scrollBy(0,-18)")
            await page.screenshot(path=str(ARTIFACTS / "progrss-node-anchor-review.png"), full_page=False)
            await page.evaluate("document.querySelector('.topbar').style.display='none'; document.querySelector('.tabs').style.display='none'")
            await page.locator("#baseline-review").screenshot(path=str(ARTIFACTS / "progrss-node-anchor-review-card.png"))
            await page.evaluate("document.querySelector('.topbar').style.display=''; document.querySelector('.tabs').style.display=''")
            await page.locator("#baseline-confirm").check()
            assert await page.locator("#commit-baseline").is_enabled()
            await page.locator("#commit-baseline").click()
            await page.wait_for_function("document.querySelector('#baseline-result').hidden === false")
            baseline_result_text = await page.locator("#baseline-result").inner_text()
            for phrase in ("Baseline replaced", "New baseline units", "Past alerts created", "Before snapshot"):
                assert phrase.lower() in baseline_result_text.lower(), (phrase, baseline_result_text)
            assert await page.locator("#operation-history-count").inner_text() == "1"
            await page.evaluate("document.querySelector('#baseline-result').scrollIntoView({block:'start'}); window.scrollBy(0,-18)")
            await page.screenshot(path=str(ARTIFACTS / "progrss-node-anchor-receipt.png"), full_page=False)
            await page.evaluate("document.querySelector('.topbar').style.display='none'; document.querySelector('.tabs').style.display='none'")
            await page.locator("#baseline-result").screenshot(path=str(ARTIFACTS / "progrss-node-anchor-receipt-card.png"))
            await page.evaluate("document.querySelector('.topbar').style.display=''; document.querySelector('.tabs').style.display=''")
            await page.locator("#download-baseline-snapshot").click()
            assert "before the baseline replacement" in (await page.locator("#status").inner_text()).lower()

            await page.locator('[data-view="curate"]').click()
            assert await page.locator("#view-curate").is_visible()
            curate_text = await page.locator("#view-curate").inner_text()
            assert "Adopt, share, and compare a route." in curate_text
            assert "Adopt one branch into this Node" in curate_text
            assert "Compare a later copy before anything changes" in curate_text
            assert "Connect my browser Extension to this Node" in curate_text

            await page.locator("#operation-file").set_input_files({
                "name": "civic-field-notes.json",
                "mimeType": "application/vnd.progrss.shared-folder+json",
                "buffer": json.dumps(operation["sourceList"], ensure_ascii=False).encode("utf-8"),
            })
            await page.wait_for_function("document.querySelector('#operation-branch')?.disabled === false")
            assert await page.locator("#operation-branch").input_value() == "branch-new"
            assert "2 curator reasons" in await page.locator("#operation-branch option:checked").inner_text()
            assert "Civic field notes" in await page.locator("#operation-source-list-note").inner_text()
            await page.locator("#review-operation").click()
            await page.wait_for_function("document.querySelector('#operation-review').hidden === false")
            operation_text = await page.locator("#operation-review").inner_text()
            for phrase in (
                "What this one write will do",
                "Civic field notes › Street and council",
                "New · paused",
                "Civic dispatch",
                "Public works board",
                "2 curator reasons",
                "Primary council reporting for this branch.",
                "Direct project-board changes.",
                "متابعة المجلس <not markup>",
                "not a ProgRSS safety claim",
                "New · starts paused",
                "Node writes once",
                "Rollback evidence stays available",
            ):
                assert phrase.lower() in operation_text.lower(), (phrase, operation_text)
            reasons = page.locator(".operation-placement-reason-text")
            assert await reasons.count() == 2
            assert await reasons.nth(0).get_attribute("dir") == "auto"
            assert await reasons.nth(1).get_attribute("dir") == "auto"
            assert await reasons.nth(0).inner_text() == "Primary council reporting for this branch."
            assert await reasons.nth(1).inner_text() == "Direct project-board changes.\nمتابعة المجلس <not markup>"
            assert await reasons.nth(1).locator("*").count() == 0
            assert await reasons.nth(1).evaluate("node => getComputedStyle(node).whiteSpace") == "pre-wrap"
            await page.evaluate("document.querySelector('#operation-review').scrollIntoView({block:'start'}); window.scrollBy(0,-18)")
            await page.screenshot(path=str(ARTIFACTS / "progrss-node-operation-review.png"), full_page=False)
            await page.locator("#operation-review").screenshot(path=str(ARTIFACTS / "progrss-node-operation-review-card.png"))
            await page.locator("#operation-confirm").check()
            assert await page.locator("#commit-operation").is_enabled()
            await page.locator("#commit-operation").click()
            await page.wait_for_function("document.querySelector('#operation-result').hidden === false")
            receipt_text = await page.locator("#operation-result").inner_text()
            for phrase in ("Branch adopted", "Revision 2", "2 new sources", "Receipt", "Before snapshot"):
                assert phrase.lower() in receipt_text.lower(), (phrase, receipt_text)
            assert await page.locator("#stat-sources").inner_text() == "5"
            assert await page.locator("#operation-history-count").inner_text() == "2"
            await page.evaluate("document.querySelector('#operation-result').scrollIntoView({block:'start'}); window.scrollBy(0,-18)")
            await page.screenshot(path=str(ARTIFACTS / "progrss-node-operation-receipt.png"), full_page=False)
            await page.locator("#operation-result").screenshot(path=str(ARTIFACTS / "progrss-node-operation-receipt-card.png"))
            await page.locator("#download-operation-snapshot").click()
            assert "exact portable library" in (await page.locator("#status").inner_text()).lower()

            await page.locator("#merge-file").set_input_files({
                "name": "neighborhood-later-copy.json",
                "mimeType": "application/vnd.progrss.shared-folder+json",
                "buffer": json.dumps(merge_bundle, ensure_ascii=False).encode("utf-8"),
            })
            await page.locator("#review-merge").click()
            await page.wait_for_function("document.querySelector('#merge-result').hidden === false")
            merge_text = await page.locator("#merge-result").inner_text()
            for phrase in (
                "What changed, and who changed it?",
                "Need a choice",
                "Both sides changed the same wording differently",
                "My council tracker",
                "Official council tracker",
                "The curator changed how a source is checked",
                "old-transit.example",
                "new-transit.example",
                "Review only",
            ):
                assert phrase.lower() in merge_text.lower(), (phrase, merge_text)
            assert "no library change" in (await page.locator("#status").inner_text()).lower()
            await page.evaluate("document.querySelector('#merge-result').scrollIntoView({block:'start'}); window.scrollBy(0,-18)")
            await page.screenshot(path=str(ARTIFACTS / "progrss-node-merge-review.png"), full_page=False)
            await page.locator("#merge-result").screenshot(path=str(ARTIFACTS / "progrss-node-merge-review-card.png"))
            await page.locator("#clear-merge").click()
            await page.locator("#exchange-folder").select_option("folder-neighborhood")
            await page.locator("#exchange-curator").fill("Neighborhood readers")
            await page.locator("#exchange-note").fill("A practical route for local meetings and useful notices.")
            await page.locator("#exchange-public-url").fill("https://exchange.example.test/neighborhood/progrss-source-list.json")
            await page.locator("#preview-exchange").click()
            await page.wait_for_function("document.querySelector('#exchange-review').hidden === false")
            review_text = await page.locator("#exchange-review").inner_text()
            for phrase in (
                "One handoff, three honest choices",
                "Follow updates",
                "Add the complete route",
                "Take one branch",
                "3 sources",
                "nothing has been published, sent, or changed",
                "Read/unread state",
                "private keys",
            ):
                assert phrase.lower() in review_text.lower(), (phrase, review_text)
            await page.locator(".exchange-contents summary").click()
            expanded = await page.locator("#exchange-review").inner_text()
            for phrase in (
                "Community bulletin", "Council agenda", "Town notices", "Neighborhood signal › Public meetings",
                "3 curator reasons", "Curator’s reason for this folder", "Broad neighborhood context.",
                "<literal & reviewed>", "Broad agenda overview.", "سبب لاجتماعات المجلس المحلية.",
                "not a ProgRSS safety claim",
            ):
                assert phrase in expanded, (phrase, expanded)
            await page.evaluate("document.querySelector('#exchange-review').scrollIntoView({block:'start'}); window.scrollBy(0,-18)")
            await page.screenshot(path=str(ARTIFACTS / "progrss-node-exchange-review.png"), full_page=False)
            await page.locator("#exchange-review").screenshot(path=str(ARTIFACTS / "progrss-node-exchange-review-card.png"))

            await page.locator("#exchange-review details.exchange-sender-fieldbook-tools summary").click()
            sender_research_text = await page.locator("#exchange-review .exchange-sender-fieldbook-tools").inner_text()
            for phrase in (
                "Research this sender review", "Observe what the sender thinks will leave",
                "what is included", "what stays private", "not been published",
            ):
                assert phrase.lower() in sender_research_text.lower(), (phrase, sender_research_text)
            await page.locator("#exchange-review").screenshot(path=str(ARTIFACTS / "progrss-node-dispatch-fieldbook-control-card.png"))
            async with page.expect_download() as sender_fieldbook_download_info:
                await page.locator("#exchange-sender-fieldbook").click()
            sender_fieldbook_download = await sender_fieldbook_download_info.value
            assert sender_fieldbook_download.suggested_filename.startswith(f"ProgRSS-Fieldbook-{REVISION}-Exchange-Sender")
            sender_fieldbook_path = ARTIFACTS / f"ProgRSS-Fieldbook-{REVISION}-Exchange-Sender-smoke.html"
            await sender_fieldbook_download.save_as(str(sender_fieldbook_path))
            sender_fieldbook_text = sender_fieldbook_path.read_text(encoding="utf-8")
            for phrase in (
                "Know what leaves before you send the link.", "Explain what stays private",
                "Create 30-minute handoff", "Explain the public source-list address",
            ):
                assert phrase in sender_fieldbook_text
            for secret in (
                "Neighborhood readers", "A practical route for local meetings", "exchange.example.test",
                "folder-neighborhood", str(preview["previewToken"]), str(preview["previewDigest"]),
                str(preview["library"]["sha256"]),
            ):
                assert secret not in sender_fieldbook_text

            dispatch_page = await browser.new_page(viewport={"width": 1180, "height": 900}, device_scale_factor=1)
            dispatch_errors: list[str] = []
            dispatch_page.on("console", lambda message: dispatch_errors.append(f"console:{message.type}:{message.text}") if message.type == "error" else None)
            dispatch_page.on("pageerror", lambda error: dispatch_errors.append(f"page:{error}"))
            await dispatch_page.set_content(sender_fieldbook_text, wait_until="domcontentloaded")
            assert await dispatch_page.locator("h1").inner_text() == "Know what leaves before you send the link."
            assert await dispatch_page.locator("fieldset").count() == 16
            await dispatch_page.screenshot(path=str(ARTIFACTS / "progrss-dispatch-fieldbook-dark.png"), full_page=True)
            await dispatch_page.evaluate("window.scrollTo(0, 0)")
            await dispatch_page.locator(".hero").screenshot(path=str(ARTIFACTS / "progrss-dispatch-fieldbook-hero-card.png"))
            await dispatch_page.locator("#task-excluded-private-state").screenshot(path=str(ARTIFACTS / "progrss-dispatch-private-state-task-card.png"))
            dispatch_setup = dispatch_page.locator("[data-setup]")
            for index in range(await dispatch_setup.count()):
                await dispatch_setup.nth(index).check()
            dispatch_independent = dispatch_page.locator('input[type="radio"][value="independent"]')
            for index in range(await dispatch_independent.count()):
                await dispatch_independent.nth(index).check()
            await dispatch_page.locator("#review").click()
            await dispatch_page.wait_for_function("document.querySelector('#review-panel').hidden === false")
            assert "16" in await dispatch_page.locator("#summary-grid").inner_text()
            assert await dispatch_page.locator("#download-json").is_disabled()
            await dispatch_page.locator("#privacy-confirm").check()
            assert await dispatch_page.locator("#download-json").is_enabled()
            await dispatch_page.screenshot(path=str(ARTIFACTS / "progrss-dispatch-fieldbook-review.png"), full_page=True)
            await dispatch_page.evaluate("document.querySelector('header').style.display='none'")
            await dispatch_page.locator("#review-panel").screenshot(path=str(ARTIFACTS / "progrss-dispatch-fieldbook-review-card.png"))
            await dispatch_page.evaluate("document.querySelector('header').style.display=''")
            async with dispatch_page.expect_download() as dispatch_report_download_info:
                await dispatch_page.locator("#download-json").click()
            dispatch_report_download = await dispatch_report_download_info.value
            dispatch_report_path = ARTIFACTS / "ProgRSS-Dispatch-Fieldbook-report-smoke.json"
            await dispatch_report_download.save_as(str(dispatch_report_path))
            dispatch_report = json.loads(dispatch_report_path.read_text(encoding="utf-8"))
            assert dispatch_report["scenario"] == "exchange-sender-review"
            assert len(dispatch_report["tasks"]) == 16
            assert dispatch_report["privacy"]["participantIdentityRecorded"] is False
            for secret in ("Neighborhood readers", "exchange.example.test", "folder-neighborhood", str(preview["previewToken"])):
                assert secret not in dispatch_report_path.read_text(encoding="utf-8")
            await dispatch_page.locator("#theme").click()
            assert await dispatch_page.evaluate("document.documentElement.dataset.theme") == "light"
            await dispatch_page.evaluate("window.scrollTo(0, 0)")
            await dispatch_page.locator(".hero").screenshot(path=str(ARTIFACTS / "progrss-dispatch-fieldbook-hero-light-card.png"))
            assert not dispatch_errors, dispatch_errors
            await dispatch_page.close()

            await page.locator("#create-exchange").click()
            await page.wait_for_function("document.querySelector('#exchange-ready').hidden === false")
            handoff = await page.locator("#exchange-url").input_value()
            assert handoff.startswith(f"{ORIGIN}/#exchange=")
            assert "Thirty-minute handoff created" in await page.locator("#status").inner_text()
            assert await page.locator("#exchange-list .pairing-card").count() == 1
            assert await page.locator("#share-public-page").is_visible()
            await page.locator("#share-public-page").click()
            shared = await page.evaluate("globalThis.__sharedData")
            assert shared["url"] == "https://exchange.example.test/neighborhood/"
            assert "three" not in shared["text"].lower() or "branch" in shared["text"].lower()
            await page.locator("#copy-exchange").click()
            assert await page.evaluate("globalThis.__copied") == handoff
            await page.evaluate("document.querySelector('#exchange-ready').scrollIntoView({block:'start'}); window.scrollBy(0,-18)")
            await page.screenshot(path=str(ARTIFACTS / "progrss-node-exchange-ready.png"), full_page=False)
            await page.locator("#exchange-ready").screenshot(path=str(ARTIFACTS / "progrss-node-exchange-ready-card.png"))

            await page.locator("#exchange-ready details.exchange-fieldbook-tools summary").click()
            exchange_research_text = await page.locator("#exchange-ready .exchange-fieldbook-tools").inner_text()
            for phrase in (
                "Research this recipient choice", "Observe the three-door handoff",
                "Follow updates", "Add the complete route", "Take one branch",
                "without exposing curator names", "invitation capability",
            ):
                assert phrase.lower() in exchange_research_text.lower(), (phrase, exchange_research_text)
            await page.locator("#exchange-ready").screenshot(path=str(ARTIFACTS / "progrss-node-crossroads-fieldbook-control-card.png"))
            await page.locator("#exchange-ready .exchange-fieldbook-tools").screenshot(path=str(ARTIFACTS / "progrss-node-crossroads-fieldbook-tool-card.png"))
            async with page.expect_download() as exchange_fieldbook_download_info:
                await page.locator("#exchange-fieldbook").click()
            exchange_fieldbook_download = await exchange_fieldbook_download_info.value
            assert exchange_fieldbook_download.suggested_filename.startswith(f"ProgRSS-Fieldbook-{REVISION}-Exchange")
            exchange_fieldbook_path = ARTIFACTS / f"ProgRSS-Fieldbook-{REVISION}-Exchange-smoke.html"
            await exchange_fieldbook_download.save_as(str(exchange_fieldbook_path))
            exchange_fieldbook_text = exchange_fieldbook_path.read_text(encoding="utf-8")
            for phrase in ("Observe the choice, not the person.", "Follow updates", "Add the complete route", "Take one branch"):
                assert phrase in exchange_fieldbook_text
            for secret in (
                "Neighborhood readers", "A practical route for local meetings", "exchange.example.test",
                "folder-neighborhood", str(created["exchangeId"]), handoff,
            ):
                assert secret not in exchange_fieldbook_text

            crossroads_page = await browser.new_page(viewport={"width": 1180, "height": 900}, device_scale_factor=1)
            crossroads_errors: list[str] = []
            crossroads_page.on("console", lambda message: crossroads_errors.append(f"console:{message.type}:{message.text}") if message.type == "error" else None)
            crossroads_page.on("pageerror", lambda error: crossroads_errors.append(f"page:{error}"))
            await crossroads_page.set_content(exchange_fieldbook_text, wait_until="domcontentloaded")
            assert await crossroads_page.locator("h1").inner_text() == "Observe the choice, not the person."
            assert await crossroads_page.locator("fieldset").count() == 15
            await crossroads_page.screenshot(path=str(ARTIFACTS / "progrss-crossroads-fieldbook-dark.png"), full_page=True)
            await crossroads_page.evaluate("window.scrollTo(0, 0)")
            await crossroads_page.locator(".hero").screenshot(path=str(ARTIFACTS / "progrss-crossroads-fieldbook-hero-card.png"))
            await crossroads_page.locator("#task-follow-updates").screenshot(path=str(ARTIFACTS / "progrss-crossroads-follow-task-card.png"))
            setup_boxes = crossroads_page.locator("[data-setup]")
            for index in range(await setup_boxes.count()):
                await setup_boxes.nth(index).check()
            independent = crossroads_page.locator('input[type="radio"][value="independent"]')
            for index in range(await independent.count()):
                await independent.nth(index).check()
            await crossroads_page.locator("#review").click()
            await crossroads_page.wait_for_function("document.querySelector('#review-panel').hidden === false")
            assert "15" in await crossroads_page.locator("#summary-grid").inner_text()
            assert await crossroads_page.locator("#download-json").is_disabled()
            await crossroads_page.locator("#privacy-confirm").check()
            assert await crossroads_page.locator("#download-json").is_enabled()
            await crossroads_page.screenshot(path=str(ARTIFACTS / "progrss-crossroads-fieldbook-review.png"), full_page=True)
            await crossroads_page.evaluate("document.querySelector('header').style.display='none'")
            await crossroads_page.locator("#review-panel").screenshot(path=str(ARTIFACTS / "progrss-crossroads-fieldbook-review-card.png"))
            await crossroads_page.evaluate("document.querySelector('header').style.display=''")
            async with crossroads_page.expect_download() as crossroads_report_download_info:
                await crossroads_page.locator("#download-json").click()
            crossroads_report_download = await crossroads_report_download_info.value
            crossroads_report_path = ARTIFACTS / "ProgRSS-Crossroads-Fieldbook-report-smoke.json"
            await crossroads_report_download.save_as(str(crossroads_report_path))
            crossroads_report = json.loads(crossroads_report_path.read_text(encoding="utf-8"))
            assert crossroads_report["scenario"] == "exchange-three-doors"
            assert len(crossroads_report["tasks"]) == 15
            assert crossroads_report["privacy"]["participantIdentityRecorded"] is False
            for secret in ("Neighborhood readers", "exchange.example.test", "folder-neighborhood", str(created["exchangeId"])):
                assert secret not in crossroads_report_path.read_text(encoding="utf-8")
            await crossroads_page.locator("#theme").click()
            assert await crossroads_page.evaluate("document.documentElement.dataset.theme") == "light"
            await crossroads_page.evaluate("window.scrollTo(0, 0)")
            await crossroads_page.locator(".hero").screenshot(path=str(ARTIFACTS / "progrss-crossroads-fieldbook-hero-light-card.png"))
            assert not crossroads_errors, crossroads_errors
            await crossroads_page.close()

            # Pairing remains an optional, separate disclosure.
            await page.locator("details.pairing-disclosure summary").click()
            assert await page.locator(".pairing-card").count() >= 1
            await page.locator("#create-pairing").click()
            await page.wait_for_function("document.querySelector('#pairing-invitation').hidden === false")
            invitation_value = await page.locator("#pairing-url").input_value()
            assert invitation_value.startswith(f"{ORIGIN}/#pair=")
            assert "no library data was sent" in await page.locator("#status").inner_text()
            await page.locator(".pairing-panel").screenshot(path=str(ARTIFACTS / "progrss-node-pairing-secondary.png"))

            await page.locator("details.advanced summary").click()
            facts = await page.locator("#node-facts").inner_text()
            assert "Loopback only · Node-owned one-writer library" in facts
            assert "Expiring artifact handoff" in facts
            assert "Local file · three-way · review only" in facts
            assert "Reviewed branch adoption" in facts
            assert "Acquisition receipts" in facts
            assert "Static publication" in facts
            assert "Network fetching" in facts and "Manual reviewed checks only" in facts

            field_page = await browser.new_page(viewport={"width": 1180, "height": 900}, device_scale_factor=1)
            field_errors: list[str] = []
            field_page.on("console", lambda message: field_errors.append(f"console:{message.type}:{message.text}") if message.type == "error" else None)
            field_page.on("pageerror", lambda error: field_errors.append(f"page:{error}"))
            await field_page.set_content(fieldbook_path.read_text(encoding="utf-8"), wait_until="domcontentloaded")
            assert await field_page.locator("h1").inner_text() == "Test the wording, not the person."
            assert await field_page.locator("fieldset").count() == 12
            await field_page.screenshot(path=str(ARTIFACTS / "progrss-fieldbook-dark.png"), full_page=True)
            setup_boxes = field_page.locator("[data-setup]")
            for index in range(await setup_boxes.count()):
                await setup_boxes.nth(index).check()
            independent = field_page.locator('input[type="radio"][value="independent"]')
            for index in range(await independent.count()):
                await independent.nth(index).check()
            await field_page.locator("#review").click()
            await field_page.wait_for_function("document.querySelector('#review-panel').hidden === false")
            assert "12" in await field_page.locator("#summary-grid").inner_text()
            assert await field_page.locator("#download-json").is_disabled()
            await field_page.locator("#privacy-confirm").check()
            assert await field_page.locator("#download-json").is_enabled()
            await field_page.screenshot(path=str(ARTIFACTS / "progrss-fieldbook-review.png"), full_page=True)
            async with field_page.expect_download() as report_download:
                await field_page.locator("#download-json").click()
            report = await report_download.value
            report_path = ARTIFACTS / "ProgRSS-Fieldbook-report-smoke.json"
            await report.save_as(str(report_path))
            report_doc = json.loads(report_path.read_text(encoding="utf-8"))
            assert report_doc["schema"] == "progrss.fieldwork-report.v1"
            assert len(report_doc["tasks"]) == 12
            assert report_doc["privacy"]["participantIdentityRecorded"] is False
            assert report_doc["facilitatorBoundary"]["avoidedSensitiveNotes"] is True
            report_text = report_path.read_text(encoding="utf-8")
            for secret in ("town.example", "Town notices", "main article", "source-page"):
                assert secret not in report_text
            await field_page.locator("#theme").click()
            assert await field_page.evaluate("document.documentElement.dataset.theme") == "light"
            await field_page.screenshot(path=str(ARTIFACTS / "progrss-fieldbook-light.png"), full_page=True)
            assert not field_errors, field_errors
            await field_page.close()

            # Debrief compares compatible local reports without scoring people or exporting raw notes.
            report_two = copy.deepcopy(report_doc)
            report_two["completedAt"] = "2026-10-20T05:20:00Z"
            report_two["tasks"][1]["outcome"] = "wrong-turn"
            report_two["tasks"][1]["notes"] = "PRIVATE-NOTE-DO-NOT-EXPORT"
            report_two["tasks"][3]["outcome"] = "wrong-turn"
            report_two["outcomes"] = {"independent": 10, "neutral-prompt": 0, "wrong-turn": 2, "not-observed": 0}
            report_three = copy.deepcopy(report_two)
            report_three["completedAt"] = "2026-10-20T05:30:00Z"
            report_three["tasks"][4]["outcome"] = "neutral-prompt"
            report_three["outcomes"] = {"independent": 9, "neutral-prompt": 1, "wrong-turn": 2, "not-observed": 0}
            report_two_path = ARTIFACTS / "ProgRSS-Fieldbook-report-smoke-2.json"
            report_three_path = ARTIFACTS / "ProgRSS-Fieldbook-report-smoke-3.json"
            report_two_path.write_text(json.dumps(report_two, ensure_ascii=False, indent=2) + "\n")
            report_three_path.write_text(json.dumps(report_three, ensure_ascii=False, indent=2) + "\n")

            debrief_page = await browser.new_page(viewport={"width": 1180, "height": 900}, device_scale_factor=1)
            debrief_errors: list[str] = []
            debrief_page.on("console", lambda message: debrief_errors.append(f"console:{message.type}:{message.text}") if message.type == "error" else None)
            debrief_page.on("pageerror", lambda error: debrief_errors.append(f"page:{error}"))
            await debrief_page.set_content(debrief_path.read_text(encoding="utf-8"), wait_until="domcontentloaded")
            assert await debrief_page.locator("h1").inner_text() == "Find patterns. Do not score people."
            await debrief_page.locator("#reports").set_input_files([str(report_path), str(report_two_path), str(report_three_path)])
            await debrief_page.locator("#load").click()
            await debrief_page.locator("#analysis").wait_for(state="visible")
            analysis_text = await debrief_page.locator("#analysis").inner_text()
            assert "3 local reports" in analysis_text
            assert "Recurring wrong turn to review" in analysis_text
            assert "Raw facilitator notes" not in analysis_text
            await debrief_page.screenshot(path=str(ARTIFACTS / "progrss-debrief-dark.png"), full_page=True)
            await debrief_page.evaluate("window.scrollTo(0, 0)")
            await debrief_page.locator(".hero").screenshot(path=str(ARTIFACTS / "progrss-debrief-overview-card.png"))
            await debrief_page.locator("#analysis > .card").screenshot(path=str(ARTIFACTS / "progrss-debrief-summary-card.png"))
            await debrief_page.locator("#tasks .task").nth(1).screenshot(path=str(ARTIFACTS / "progrss-debrief-wrong-turn-card.png"))
            dispositions = debrief_page.locator('select[id^="disposition-"]')
            for index in range(await dispositions.count()):
                await dispositions.nth(index).select_option("not-reviewed")
            await debrief_page.locator("#disposition-different-window").select_option("product-change")
            await debrief_page.locator("#finding-different-window").fill("Two observed sessions interpreted Different window as deletion.")
            await debrief_page.locator("#action-different-window").fill("Test wording that says records may simply be outside this rendered window.")
            await debrief_page.locator("#review").click()
            await debrief_page.locator("#review-panel").wait_for(state="visible")
            assert await debrief_page.locator("#download-json").is_disabled()
            for selector in ("#privacy-text", "#privacy-scope", "#privacy-notes"):
                await debrief_page.locator(selector).check()
            assert await debrief_page.locator("#download-json").is_enabled()
            await debrief_page.screenshot(path=str(ARTIFACTS / "progrss-debrief-review.png"), full_page=True)
            await debrief_page.locator("header").evaluate("el => el.style.position = 'static'")
            await debrief_page.locator("#review-panel").screenshot(path=str(ARTIFACTS / "progrss-debrief-review-card.png"))
            await debrief_page.locator("header").evaluate("el => el.style.position = ''")
            async with debrief_page.expect_download() as debrief_report_download:
                await debrief_page.locator("#download-json").click()
            debrief_report = await debrief_report_download.value
            debrief_report_path = ARTIFACTS / "ProgRSS-Debrief-report-smoke.json"
            await debrief_report.save_as(str(debrief_report_path))
            debrief_doc = json.loads(debrief_report_path.read_text(encoding="utf-8"))
            assert debrief_doc["schema"] == "progrss.fieldwork-debrief.v1"
            assert debrief_doc["reportCount"] == 3
            assert debrief_doc["privacy"]["rawNotesExported"] is False
            assert "PRIVATE-NOTE-DO-NOT-EXPORT" not in debrief_report_path.read_text(encoding="utf-8")
            await debrief_page.locator("#theme").click()
            assert await debrief_page.evaluate("document.documentElement.dataset.theme") == "light"
            await debrief_page.screenshot(path=str(ARTIFACTS / "progrss-debrief-light.png"), full_page=True)
            await debrief_page.evaluate("window.scrollTo(0, 0)")
            await debrief_page.locator(".hero").screenshot(path=str(ARTIFACTS / "progrss-debrief-overview-light-card.png"))
            assert not debrief_errors, debrief_errors
            await debrief_page.close()
        finally:
            await browser.close()

    if errors:
        print("\n".join(errors), file=sys.stderr)
        return 1
    print("PASS rendered Node UI: capability fragment staging, bearer API calls, dark/light themes, Today/Sources/Curate paths, offline acquisition review, explicit paused-source enablement, bounded one-use browser-capture request, durable acquisition receipt, read-only Bearing diagnosis with Trace observation trail and recipe footprint, private no-telemetry Fieldbook generation plus reviewed local JSON report, local multi-report Debrief with raw-note exclusion and no participant score, privacy-minimized Dispatch sender Fieldbook plus Crossroads recipient Fieldbook, reviewed held-window baseline replacement, atomic Anchor receipt and before-snapshot evidence, reviewed Node-owned branch adoption, read-only three-way later-copy review, reviewed three-door exchange creation, expiring handoff, feature-detected Web Share, and summary-only pairing")
    print("SKIP native HTTP loopback Chromium navigation: managed host policy returned ERR_BLOCKED_BY_ADMINISTRATOR")
    print(f"Artifacts: {ARTIFACTS}")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
