#!/usr/bin/env python3
"""Focused shipped Node merge-review replay for placement-scoped Source Notes."""
from __future__ import annotations

import argparse
import asyncio
import copy
import json
import os
from pathlib import Path
import shutil
import sys

from playwright.async_api import async_playwright


def build_review(root: Path) -> tuple[dict[str, object], dict[str, object], list[dict[str, object]]]:
    cli = root / "CLI"
    if str(cli) not in sys.path:
        sys.path.insert(0, str(cli))
    import relay  # type: ignore

    source = {
        "id": "shared", "type": "rss", "title": "Civic bulletin", "author": "Desk",
        "url": "https://civic.example/feed.xml", "enabled": True,
    }
    initial_state = {
        "sources": [source],
        "collections": [
            {"id": "root", "title": "Civic route", "mode": "union", "members": [
                {"kind": "collection", "id": "north"}, {"kind": "collection", "id": "south"},
            ]},
            {"id": "north", "title": "North", "mode": "union", "members": [{"kind": "collection", "id": "north-updates"}]},
            {"id": "north-updates", "title": "Updates", "mode": "union", "members": [{
                "kind": "source", "id": "shared", "reason": "North accepted reason.\nSecond accepted line."
            }]},
            {"id": "south", "title": "South", "mode": "union", "members": [{"kind": "collection", "id": "south-updates"}]},
            {"id": "south-updates", "title": "Updates", "mode": "union", "members": [{
                "kind": "source", "id": "shared", "reason": "South accepted reason."
            }]},
        ],
        "items": [],
    }
    initial = relay.make_bundle(
        initial_state, "Civic route", curator="Neighborhood desk",
        update_url="https://publish.example/civic/source-list.json",
        exported_at="2026-10-20T20:00:00.000Z",
    )
    imported, _ = relay.import_bundle({"sources": [], "collections": [], "items": []}, initial)
    by_title = {}
    for collection in imported["collections"]:
        by_title.setdefault(collection["title"], []).append(collection)
    updates = by_title["Updates"]
    assert len(updates) == 2
    # Imported IDs are remapped, so use the retained baseline map to locate each remote folder.
    imported_root = next(row for row in imported["collections"] if row.get("sharedFolderOrigin"))
    baseline = imported_root["sharedFolderOrigin"]["baseline"]
    collection_map = {row["remoteId"]: row["localId"] for row in baseline["collectionMap"]}
    imported_by_id = {row["id"]: row for row in imported["collections"]}
    north_member = imported_by_id[collection_map["north-updates"]]["members"][0]
    south_member = imported_by_id[collection_map["south-updates"]]["members"][0]
    north_member["reason"] = "My north reason.\nسبب محلي <not markup>"
    south_member["reason"] = "My south reason."

    later_state = copy.deepcopy(initial_state)
    later_by_id = {row["id"]: row for row in later_state["collections"]}
    later_by_id["north-updates"]["members"][0]["reason"] = "Curator north reason.\n<b>literal markup</b>"
    later_by_id["south-updates"]["members"][0]["reason"] = "Curator south reason."
    later = relay.make_bundle(
        later_state, "Civic route", curator="Neighborhood desk",
        update_url="https://publish.example/civic/source-list.json",
        exported_at="2026-10-21T20:00:00.000Z",
    )
    review = relay.review_bundle_update(imported, later)
    conflicts = [row for row in review["mergeReview"]["conflicts"] if row.get("kind") == "source-note"]
    assert len(conflicts) == 2, conflicts
    paths = {row.get("folderPath") for row in conflicts}
    assert paths == {"Civic route › North › Updates", "Civic route › South › Updates"}, conflicts
    response = {
        "schema": "progrss.node.merge-review.v1", "state": "review",
        "library": {"file": "imported-civic.json", "sha256": "7" * 64},
        "review": review, "readOnly": True, "network": False, "writes": False,
    }
    return later, response, conflicts


def minimal_payload() -> dict[str, object]:
    return {
        "status": {
            "schema": "progrss.node.status.v1", "version": "0.80.0", "revision": "rev0080",
            "scope": "loopback-read-only", "library": "imported-civic.json",
            "stats": {"sources": 1, "pageWatches": 0, "unread": 0},
            "capabilities": {"readLibrary": True, "writeLibrary": False, "fetchSources": False, "publish": False,
                "prepareExchange": True, "preparePublicationPackage": True, "pairExtension": True,
                "nodeToNode": False, "webrtcCourier": False},
            "pairingCapabilities": {"schema": "progrss.node.capabilities.v1", "readLibrarySummary": True,
                "readItems": False, "readSourceAddresses": False, "writeLibrary": False, "fetchSources": False,
                "publish": False, "merge": False, "nodeToNode": False, "webrtcCourier": False},
            "instanceFingerprint": "focused-merge-review", "activePairings": 0, "activeExchanges": 0,
        },
        "library": {
            "schema": "progrss.node.library.v1", "library": {"file": "imported-civic.json", "mode": "exported-backup"},
            "stats": {"sources": 1, "pageWatches": 0, "unread": 0}, "items": [], "sources": [],
        },
        "pairings": {"schema": "progrss.node.pairings.v1", "pairings": []},
        "curation": {"schema": "progrss.node.exchange.v1", "state": "curation", "folders": [], "readOnly": True, "operationAvailable": False, "network": False, "writes": False},
        "exchanges": {"schema": "progrss.node.exchanges.v1", "exchanges": []},
        "operations": {"schema": "progrss.node.operation-result.v1", "state": "admin-list", "nodeOwned": False, "operations": [], "network": False, "writes": False},
        "acquisitions": {"schema": "progrss.node.acquisition-result.v1", "receipts": [], "jobs": []},
    }


async def render(root: Path, bundle: dict[str, object], response: dict[str, object], artifacts: Path) -> None:
    artifacts.mkdir(parents=True, exist_ok=True)
    payload = minimal_payload()
    payload["mergeResponse"] = response
    payload_json = json.dumps(payload, ensure_ascii=False)
    async with async_playwright() as playwright:
        executable = os.environ.get("PROGRSS_CHROMIUM") or shutil.which("chromium") or shutil.which("chromium-browser") or shutil.which("google-chrome")
        launch: dict[str, object] = {"headless": True, "args": ["--no-sandbox", "--allow-file-access-from-files"]}
        if executable:
            launch["executable_path"] = executable
        browser = await playwright.chromium.launch(**launch)
        try:
            page = await browser.new_page(viewport={"width": 1180, "height": 900}, device_scale_factor=1)
            errors: list[str] = []
            page.on("console", lambda message: errors.append(f"console:{message.type}:{message.text}") if message.type == "error" else None)
            page.on("pageerror", lambda error: errors.append(f"page:{error}"))
            html = (root / "CLI/node_web/index.html").read_text(encoding="utf-8")
            html = html.replace('<link rel="stylesheet" href="app.css">', '').replace('<script src="app.js"></script>', '')
            await page.set_content(html, wait_until="domcontentloaded")
            await page.add_style_tag(content=(root / "CLI/node_web/app.css").read_text(encoding="utf-8"))
            await page.evaluate(f"""
                (() => {{
                  const payload = {payload_json};
                  const local = new Map(); const session = new Map([['progrss-node-token','focused-token']]);
                  Object.defineProperty(window, 'localStorage', {{value: {{getItem:k=>local.get(String(k))??null,setItem:(k,v)=>local.set(String(k),String(v)),removeItem:k=>local.delete(String(k))}}, configurable:true}});
                  Object.defineProperty(window, 'sessionStorage', {{value: {{getItem:k=>session.get(String(k))??null,setItem:(k,v)=>session.set(String(k),String(v)),removeItem:k=>session.delete(String(k))}}, configurable:true}});
                  history.replaceState = () => {{}};
                  globalThis.fetch = async (path, options={{}}) => {{
                    const route=String(path), method=String(options.method||'GET').toUpperCase();
                    let body;
                    if(route.endsWith('/status')) body=payload.status;
                    else if(route.endsWith('/library')) body=payload.library;
                    else if(route.endsWith('/pairings')) body=payload.pairings;
                    else if(route.endsWith('/curation')) body=payload.curation;
                    else if(route.endsWith('/exchanges')) body=payload.exchanges;
                    else if(route.endsWith('/operations')) body=payload.operations;
                    else if(route.endsWith('/acquisitions')) body=payload.acquisitions;
                    else if(route.endsWith('/merge-reviews') && method==='POST') body=payload.mergeResponse;
                    else body={{error:'unexpected route '+route}};
                    return new Response(JSON.stringify(body), {{status: body.error?404:200, headers:{{'Content-Type':'application/json'}}}});
                  }};
                }})()
            """)
            await page.add_script_tag(content=(root / "CLI/node_web/app.js").read_text(encoding="utf-8"))
            await page.wait_for_function("document.querySelector('#status').textContent.includes('Local exported backup ready')")
            await page.locator('[data-view="curate"]').click()
            await page.locator('#merge-file').set_input_files({
                "name": "civic-later-copy.json", "mimeType": "application/vnd.progrss.shared-folder+json",
                "buffer": json.dumps(bundle, ensure_ascii=False).encode("utf-8"),
            })
            await page.locator('#review-merge').click()
            await page.wait_for_function("document.querySelector('#merge-result').hidden === false")
            cards = page.locator('.merge-entry.source-note')
            assert await cards.count() == 2, await page.locator('#merge-result').inner_text()
            card_texts = [await cards.nth(i).inner_text() for i in range(2)]
            assert any('Civic route › North › Updates' in text for text in card_texts), card_texts
            assert any('Civic route › South › Updates' in text for text in card_texts), card_texts
            values = page.locator('.merge-source-note-value')
            assert await values.count() == 6
            exact = [await values.nth(i).inner_text() for i in range(6)]
            expected = {
                'North accepted reason.\nSecond accepted line.', 'My north reason.\nسبب محلي <not markup>',
                'Curator north reason.\n<b>literal markup</b>', 'South accepted reason.',
                'My south reason.', 'Curator south reason.',
            }
            assert set(exact) == expected, exact
            for i in range(await values.count()):
                assert await values.nth(i).get_attribute('dir') == 'auto'
                assert await values.nth(i).evaluate("node => getComputedStyle(node).whiteSpace") == 'pre-wrap'
            north_local = values.filter(has_text='سبب محلي').first
            curator_markup = values.filter(has_text='<b>literal markup</b>').first
            assert await north_local.locator('*').count() == 0
            assert await curator_markup.locator('*').count() == 0
            text = await page.locator('#merge-result').inner_text()
            for phrase in ('Curator’s reason for this folder', 'not a ProgRSS safety claim', 'Keep mine', 'Use curator’s'):
                assert phrase.lower() in text.lower(), (phrase, text)
            await page.locator('#merge-result').screenshot(path=str(artifacts / 'node-merge-source-notes.png'))
            assert not errors, errors
        finally:
            await browser.close()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--artifacts', type=Path, required=True)
    args = parser.parse_args()
    bundle, response, conflicts = build_review(args.root)
    asyncio.run(render(args.root, bundle, response, args.artifacts))
    print(json.dumps({
        'status':'pass','sourceNoteConflicts':len(conflicts),
        'folderPaths':sorted(row['folderPath'] for row in conflicts),
        'network':False,'writes':False,
    }, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
