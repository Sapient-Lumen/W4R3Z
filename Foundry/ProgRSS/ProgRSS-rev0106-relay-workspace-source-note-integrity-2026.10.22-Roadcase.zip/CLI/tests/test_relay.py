import io
import json
import datetime as dt
import threading
import zipfile
import subprocess
import sys
import tempfile
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve()
CLI_DIR = HERE.parents[1]
ROOT = HERE.parents[2]
sys.path.insert(0, str(CLI_DIR))

import relay


class RelayBundleTests(unittest.TestCase):
    def setUp(self):
        self.state = {
            "schemaVersion": 17,
            "sources": [
                {"id": "feed_one", "type": "rss", "title": "Feed one", "url": "https://example.com/feed", "enabled": True, "privateNote": "never export"},
                {"id": "watch_one", "type": "page", "title": "Watch one", "url": "https://example.net/news", "enabled": True, "mode": "cards", "selector": "article", "titleSelector": "h2", "linkSelector": "a", "threshold": 24},
                {"id": "other", "type": "rss", "title": "Other", "url": "https://outside.example/feed", "enabled": True},
            ],
            "collections": [
                {"id": "root_folder", "title": "Shared", "mode": "union", "members": [{"kind": "source", "id": "feed_one"}, {"kind": "collection", "id": "child_folder"}]},
                {"id": "child_folder", "title": "Watchlist", "mode": "union", "members": [{"kind": "source", "id": "watch_one"}]},
                {"id": "other_folder", "title": "Private", "mode": "union", "members": [{"kind": "source", "id": "other"}]},
            ],
            "items": [{"id": "private-item", "read": True, "saved": True}],
            "snapshots": {"watch_one": "private page text"},
        }

    def test_make_bundle_is_connected_and_private_state_free(self):
        bundle = relay.make_bundle(self.state, "Shared")
        self.assertEqual(bundle["schema"], relay.BUNDLE_SCHEMA)
        self.assertEqual(bundle["root"], "root_folder")
        self.assertEqual(bundle["title"], "Shared")
        self.assertEqual(bundle["publication"]["id"], "root_folder")
        self.assertEqual(bundle["integrity"]["digest"], relay.bundle_content_digest(bundle))
        self.assertNotIn("signature", bundle["integrity"])
        self.assertEqual({row["id"] for row in bundle["sources"]}, {"feed_one", "watch_one"})
        encoded = json.dumps(bundle)
        self.assertNotIn("private-item", encoded)
        self.assertNotIn("private page text", encoded)
        self.assertNotIn("privateNote", encoded)

    def test_bundle_contents_names_sites_types_and_folder_routes_without_network(self):
        bundle = relay.make_bundle(self.state, "Shared")
        report = relay.bundle_contents(
            bundle,
            {"feed_one": "already-here", "watch_one": "new-paused"},
            {"root_folder": "unchanged", "child_folder": "added"},
        )
        self.assertEqual(report["schema"], relay.CONTENTS_SCHEMA)
        self.assertEqual(report["title"], "Shared")
        self.assertEqual(report["sourceCount"], 2)
        self.assertEqual(report["feedCount"], 1)
        self.assertEqual(report["pageWatchCount"], 1)
        self.assertEqual(report["folderCount"], 2)
        self.assertEqual(report["maxDepth"], 1)
        self.assertFalse(report["network"] )
        self.assertFalse(report["writes"] )
        self.assertEqual([row["path"] for row in report["folders"]], ["Shared", "Shared › Watchlist"] )
        self.assertTrue(report["folders"][0]["isRoot"])
        self.assertEqual(report["folders"][0]["branchSources"], 2)
        self.assertEqual(report["folders"][0]["branchFolders"], 2)
        self.assertEqual(report["folders"][1]["branchSources"], 1)
        self.assertEqual(report["folders"][1]["branchPageWatches"], 1)
        by_id = {row["id"]: row for row in report["sources"]}
        self.assertEqual(by_id["feed_one"]["host"], "example.com")
        self.assertEqual(by_id["feed_one"]["type"], "rss")
        self.assertEqual(by_id["feed_one"]["folders"], ["Shared"] )
        self.assertEqual(by_id["feed_one"]["state"], "already-here")
        self.assertEqual(by_id["watch_one"]["host"], "example.net")
        self.assertEqual(by_id["watch_one"]["type"], "page")
        self.assertEqual(by_id["watch_one"]["folders"], ["Shared › Watchlist"] )
        self.assertEqual(by_id["watch_one"]["state"], "new-paused")

    def test_import_one_folder_section_is_an_independent_local_excerpt(self):
        bundle = relay.make_bundle(
            self.state,
            "Shared",
            curator="Neighborhood desk",
            update_url="https://example.com/publications/shared.json",
            exported_at="2026-10-19T12:00:00.000Z",
        )
        selected, selection = relay.select_bundle_section(bundle, "Shared › Watchlist")
        self.assertEqual(selection["selectionMode"], "section")
        self.assertTrue(selection["independentExcerpt"])
        self.assertEqual(selected["root"], "child_folder")
        self.assertEqual([row["id"] for row in selected["sources"]], ["watch_one"])
        self.assertEqual([row["id"] for row in selected["collections"]], ["child_folder"])

        imported, summary = relay.import_bundle(
            {"sources": [], "collections": [], "items": []}, bundle, "Watchlist",
        )
        self.assertTrue(summary["independentExcerpt"])
        self.assertFalse(summary["updateLinked"])
        self.assertEqual(summary["selectedFolderPath"], "Shared › Watchlist")
        self.assertEqual(summary["publicationId"], "")
        self.assertEqual(summary["parentPublicationId"], bundle["publication"]["id"])
        self.assertEqual(summary["updateUrl"], "")
        self.assertFalse(summary["manualUpdateCheck"])
        self.assertEqual(len(imported["sources"]), 1)
        self.assertEqual(imported["sources"][0]["origin"], "shared-folder-section")
        self.assertEqual(len(imported["collections"]), 1)
        self.assertNotIn("sharedFolderOrigin", imported["collections"][0])

    def test_section_selection_refuses_empty_and_ambiguous_branches(self):
        state = {
            "sources": [
                {"id": "shared_source", "type": "rss", "title": "Shared source", "url": "https://branch.test/feed"},
            ],
            "collections": [
                {"id": "branch_root", "title": "Root", "mode": "union", "members": [
                    {"kind": "collection", "id": "same_a"},
                    {"kind": "collection", "id": "same_b"},
                    {"kind": "collection", "id": "empty_branch"},
                ]},
                {"id": "same_a", "title": "Same", "mode": "union", "members": [{"kind": "source", "id": "shared_source"}]},
                {"id": "same_b", "title": "Same", "mode": "union", "members": [{"kind": "source", "id": "shared_source"}]},
                {"id": "empty_branch", "title": "Empty", "mode": "union", "members": []},
            ],
            "items": [],
        }
        bundle = relay.make_bundle(
            state, "branch_root", curator="Branch desk",
            update_url="https://branch.test/publication.json",
            exported_at="2026-10-19T12:00:00.000Z",
        )
        with self.assertRaisesRegex(relay.RelayError, "folder title is ambiguous"):
            relay.select_bundle_section(bundle, "Same")
        with self.assertRaisesRegex(relay.RelayError, "folder path is ambiguous"):
            relay.select_bundle_section(bundle, "Root › Same")
        with self.assertRaisesRegex(relay.RelayError, "does not contain a source"):
            relay.select_bundle_section(bundle, "empty_branch")

        exact, selection = relay.select_bundle_section(bundle, "same_a")
        self.assertTrue(selection["independentExcerpt"])
        self.assertEqual(exact["root"], "same_a")
        self.assertEqual(len(exact["sources"]), 1)

        complete, complete_selection = relay.select_bundle_section(bundle, "branch_root")
        self.assertFalse(complete_selection["independentExcerpt"])
        self.assertEqual(complete["schema"], relay.LOCATED_BUNDLE_SCHEMA)
        imported, summary = relay.import_bundle({"sources": [], "collections": [], "items": []}, bundle, "branch_root")
        self.assertFalse(summary["independentExcerpt"])
        self.assertTrue(summary["updateLinked"])
        root = next(row for row in imported["collections"] if row["id"] == summary["rootId"])
        self.assertEqual(root["sharedFolderOrigin"]["schema"], relay.LOCATED_ORIGIN_SCHEMA)

    def test_located_bundle_binds_manual_update_address(self):
        bundle = relay.make_bundle(
            self.state, "Shared", update_url="https://example.com/publications/shared.json",
            exported_at="2026-10-18T20:00:00.000Z",
        )
        self.assertEqual(bundle["schema"], relay.LOCATED_BUNDLE_SCHEMA)
        self.assertEqual(bundle["distribution"], {
            "schema": relay.DISTRIBUTION_SCHEMA,
            "updateUrl": "https://example.com/publications/shared.json",
        })
        checked = relay.validate_bundle(bundle)
        self.assertEqual(relay.bundle_provenance(checked)["updateUrl"], "https://example.com/publications/shared.json")
        tampered = json.loads(json.dumps(bundle))
        tampered["distribution"]["updateUrl"] = "https://example.com/publications/other.json"
        with self.assertRaises(relay.RelayError):
            relay.validate_bundle(tampered)
        imported, summary = relay.import_bundle({"sources": [], "collections": [], "items": []}, bundle)
        root = next(row for row in imported["collections"] if row["id"] == summary["rootId"])
        self.assertEqual(root["sharedFolderOrigin"]["schema"], relay.LOCATED_ORIGIN_SCHEMA)
        self.assertEqual(root["sharedFolderOrigin"]["updateUrl"], "https://example.com/publications/shared.json")

    def test_ready_to_host_site_is_script_free_bounded_and_readable(self):
        bundle = relay.make_bundle(
            self.state,
            "Shared",
            curator="Neighborhood <desk>",
            note="Feeds and watched pages for the repair café.",
            update_url="https://example.com/publications/latest.json",
            exported_at="2026-10-18T20:00:00.000Z",
        )
        payload, summary = relay.build_publication_site(bundle)
        self.assertEqual(summary["schema"], "progrss.publication-site.v1")
        self.assertEqual(summary["updateFile"], "latest.json")
        self.assertEqual(summary["feeds"], 1)
        self.assertEqual(summary["pageWatches"], 1)
        self.assertEqual(summary["scripts"], 0)
        self.assertEqual(summary["trackers"], 0)
        self.assertFalse(summary["automaticChecks"])
        self.assertTrue(summary["discoverableFromPage"])
        self.assertEqual(summary["advertisedMediaType"], relay.BUNDLE_MEDIA_TYPE)
        with zipfile.ZipFile(io.BytesIO(payload), "r") as archive:
            self.assertEqual(
                set(archive.namelist()),
                {"index.html", "latest.json", "subscriptions.opml", "README.txt"},
            )
            index = archive.read("index.html").decode("utf-8")
            self.assertIn("Neighborhood &lt;desk&gt;", index)
            self.assertNotIn("<script", index.lower())
            for marker in ("<iframe", "<img", "<object", "<embed"):
                self.assertNotIn(marker, index.lower())
            self.assertIn("no scripts, trackers, remote images, or automatic update checks", index.lower())
            self.assertIn(
                '<link rel="alternate" type="application/vnd.progrss.shared-folder+json" href="latest.json" title="Shared source list for ProgRSS">',
                index,
            )
            self.assertIn("Add → Use this page", index)
            self.assertIn("paste the direct JSON address into Add", index)
            self.assertIn("Choose what you want", index)
            self.assertIn("Add the complete route", index)
            self.assertIn("Take one branch", index)
            self.assertNotIn("Follow updates", index)
            hosted = json.loads(archive.read("latest.json"))
            self.assertEqual(hosted["schema"], relay.LOCATED_BUNDLE_SCHEMA)
            self.assertEqual(hosted["integrity"]["digest"], bundle["integrity"]["digest"])
            opml = archive.read("subscriptions.opml").decode("utf-8")
            self.assertIn('xmlUrl="https://example.com/feed"', opml)
            self.assertNotIn("https://example.net/news", opml)
            readme = archive.read("README.txt").decode("utf-8")
            self.assertIn("does not poll", readme)
            self.assertIn("latest.json", readme)
            self.assertIn("advertises the JSON file as a ProgRSS source list", readme)
        query_bundle = relay.make_bundle(
            self.state,
            "Shared",
            update_url="https://example.com/latest.json?edition=2",
        )
        with self.assertRaises(relay.RelayError):
            relay.build_publication_site(query_bundle)

    def test_ready_to_host_site_can_include_a_matching_summary_only_edition(self):
        bundle = relay.make_bundle(
            self.state,
            "Shared",
            curator="Neighborhood desk",
            note="A practical list.",
            update_url="https://example.com/publications/latest.json",
            exported_at="2026-10-19T05:00:00.000Z",
        )
        edition = {
            "version": relay.JSON_FEED_VERSION,
            "title": "Shared · recent updates",
            "description": "A practical list.",
            "authors": [{"name": "Neighborhood desk"}],
            "items": [{
                "id": "https://example.com/posts/garden",
                "title": "Garden <opens>",
                "content_text": "Saturday morning.",
                "summary": "Saturday morning.",
                "url": "https://example.com/posts/garden",
                "date_published": "2026-10-19T04:00:00Z",
                "language": "en",
                "_progrss": {
                    "sourceCount": 1,
                    "sources": [{"title": "Feed one", "type": "feed"}],
                },
            }],
            "_progrss": {
                "schema": relay.FOLDER_EDITION_SCHEMA,
                "generatedAt": "2026-10-19T05:00:00Z",
                "folder": "Shared",
                "folderSourceCount": 2,
                "representedSourceCount": 1,
                "itemCount": 1,
                "omittedByLimit": 0,
                "included": {"titles": True, "shortSummaries": True, "links": True, "dates": True, "languages": True, "sourceLabels": True},
                "excluded": {
                    "fullRetainedText": True,
                    "readingState": True,
                    "savedState": True,
                    "pageWatchEvidence": True,
                    "snapshots": True,
                    "browserAuthority": True,
                    "privateKeys": True,
                },
            },
        }
        payload, summary = relay.build_publication_site(bundle, edition)
        self.assertTrue(summary["recentUpdatesIncluded"])
        self.assertEqual(summary["updates"], 1)
        self.assertEqual(summary["updatesFile"], relay.EDITION_FILE)
        self.assertEqual(summary["advertisedFeedMediaType"], relay.FEED_MEDIA_TYPE)
        with zipfile.ZipFile(io.BytesIO(payload), "r") as archive:
            self.assertEqual(
                set(archive.namelist()),
                {"index.html", "latest.json", "subscriptions.opml", relay.EDITION_FILE, "README.txt"},
            )
            page = archive.read("index.html").decode("utf-8")
            self.assertIn('<link rel="alternate" type="application/feed+json" href="recent-updates.json"', page)
            self.assertIn("Follow updates", page)
            self.assertIn("underlying feeds, watched pages, and folders stay out of your library", page)
            self.assertIn("Add the complete route", page)
            self.assertIn("Take one branch", page)
            self.assertIn("independent local route", page)
            self.assertIn("Recent updates", page)
            self.assertIn("Garden &lt;opens&gt;", page)
            self.assertIn("manual snapshot", page)
            hosted = json.loads(archive.read(relay.EDITION_FILE))
            self.assertEqual(hosted["feed_url"], "https://example.com/publications/recent-updates.json")
            self.assertEqual(hosted["home_page_url"], "https://example.com/publications/index.html")
            self.assertNotIn("content_html", json.dumps(hosted))
            self.assertIn("Summary-only JSON Feed", archive.read("README.txt").decode("utf-8"))

        wrong = json.loads(json.dumps(edition))
        wrong["_progrss"]["folder"] = "Other"
        with self.assertRaisesRegex(relay.RelayError, "different folder"):
            relay.build_publication_site(bundle, wrong)
        unsupported = json.loads(json.dumps(edition))
        unsupported["items"][0]["content_html"] = "<script>alert(1)</script>"
        with self.assertRaisesRegex(relay.RelayError, "unsupported material"):
            relay.build_publication_site(bundle, unsupported)

        inconsistent = json.loads(json.dumps(edition))
        inconsistent["_progrss"]["itemCount"] = 2
        with self.assertRaisesRegex(relay.RelayError, "inconsistent public counts"):
            relay.build_publication_site(bundle, inconsistent)
        malformed_witness = json.loads(json.dumps(edition))
        malformed_witness["items"][0]["_progrss"]["sources"][0]["type"] = "mystery"
        with self.assertRaisesRegex(relay.RelayError, "malformed source evidence"):
            relay.build_publication_site(bundle, malformed_witness)
        unattributed = json.loads(json.dumps(edition))
        del unattributed["authors"]
        with self.assertRaisesRegex(relay.RelayError, "attribution does not match"):
            relay.build_publication_site(bundle, unattributed)

    def test_deployed_publication_audit_checks_both_named_choices_and_static_boundary(self):
        class Handler(BaseHTTPRequestHandler):
            files: dict[str, bytes] = {}
            hits: dict[str, int] = {}

            def do_GET(self):
                path = self.path.split("?", 1)[0].lstrip("/") or "index.html"
                payload = type(self).files.get(path)
                if payload is None:
                    self.send_error(404)
                    return
                type(self).hits[path] = type(self).hits.get(path, 0) + 1
                self.send_response(200)
                media = {
                    "index.html": "text/html; charset=utf-8",
                    "latest.json": relay.BUNDLE_MEDIA_TYPE,
                    relay.EDITION_FILE: relay.FEED_MEDIA_TYPE,
                }.get(path, "application/octet-stream")
                self.send_header("Content-Type", media)
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

            def log_message(self, *_args):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            origin = f"http://127.0.0.1:{server.server_port}"
            bundle = relay.make_bundle(
                self.state, "Shared", curator="Neighborhood desk",
                update_url=f"{origin}/latest.json", exported_at="2026-10-19T06:00:00.000Z",
            )
            edition = {
                "version": relay.JSON_FEED_VERSION,
                "title": "Shared · recent updates",
                "description": "A small public reading snapshot.",
                "authors": [{"name": "Neighborhood desk"}],
                "items": [{
                    "id": "https://example.com/posts/garden",
                    "title": "Garden opens",
                    "content_text": "Saturday morning.",
                    "summary": "Saturday morning.",
                    "url": "https://example.com/posts/garden",
                    "date_published": "2026-10-19T05:00:00Z",
                    "_progrss": {"sourceCount": 1, "sources": [{"title": "Feed one", "type": "feed"}]},
                }],
                "_progrss": {
                    "schema": relay.FOLDER_EDITION_SCHEMA,
                    "generatedAt": "2026-10-19T06:00:00Z",
                    "folder": "Shared",
                    "folderSourceCount": 2,
                    "representedSourceCount": 1,
                    "itemCount": 1,
                    "omittedByLimit": 0,
                    "included": {"titles": True, "shortSummaries": True, "links": True, "dates": True, "languages": True, "sourceLabels": True},
                    "excluded": {"fullRetainedText": True, "readingState": True, "savedState": True, "pageWatchEvidence": True, "snapshots": True, "browserAuthority": True, "privateKeys": True},
                },
            }
            Handler.files = relay.publication_site_files(bundle, edition)
            report = relay.check_publication_page(f"{origin}/index.html", require_updates=True)
            self.assertEqual(report["schema"], "progrss.publication-deployment-check.v1")
            self.assertTrue(report["valid"])
            self.assertEqual(report["networkRequests"], 3)
            self.assertEqual(report["sourceList"]["updateUrl"], f"{origin}/latest.json")
            self.assertEqual(report["recentUpdates"]["feedUrl"], f"{origin}/{relay.EDITION_FILE}")
            self.assertEqual(report["recentUpdates"]["items"], 1)
            self.assertTrue(report["staticPage"]["defaultSrcNone"])
            self.assertEqual(report["staticPage"]["activeOrRemoteResourceElements"], 0)
            self.assertFalse(report["writes"])
            self.assertFalse(report["automatic"])

            completed = subprocess.run([
                sys.executable, str(CLI_DIR / "progrss.py"), "bundle", "check-page",
                f"{origin}/index.html", "--require-updates", "--json",
            ], cwd=ROOT, text=True, capture_output=True, check=False)
            self.assertEqual(completed.returncode, 0, completed.stderr)
            command_report = json.loads(completed.stdout)
            self.assertEqual(command_report["sourceList"]["title"], "Shared")
            self.assertEqual(command_report["recentUpdates"]["schema"], relay.FOLDER_EDITION_SCHEMA)

            safe_page = Handler.files["index.html"]
            Handler.files["index.html"] = safe_page.replace(b"</head>", b"<script>bad()</script></head>")
            with self.assertRaisesRegex(relay.RelayError, "active material"):
                relay.check_publication_page(f"{origin}/index.html", require_updates=True)
            Handler.files["index.html"] = relay.publication_site_files(bundle)["index.html"]
            with self.assertRaisesRegex(relay.RelayError, "--require-updates"):
                relay.check_publication_page(f"{origin}/index.html", require_updates=True)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)

    def test_direct_address_fetches_verifies_and_optionally_saves_publication(self):
        class Handler(BaseHTTPRequestHandler):
            bundle = b""
            hits = 0

            def do_GET(self):
                if self.path != "/community.json":
                    self.send_error(404)
                    return
                type(self).hits += 1
                payload = type(self).bundle
                self.send_response(200)
                # A generic type is accepted only because the complete native
                # schema, graph and integrity record are validated afterward.
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

            def log_message(self, *_args):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            origin = f"http://127.0.0.1:{server.server_port}"
            bundle = relay.make_bundle(
                self.state, "Shared", update_url=f"{origin}/community.json",
                exported_at="2026-10-18T20:00:00.000Z",
            )
            Handler.bundle = (json.dumps(bundle, ensure_ascii=False) + "\n").encode("utf-8")
            found, remote = relay.fetch_publication(f"{origin}/community.json")
            self.assertEqual(found["integrity"]["digest"], bundle["integrity"]["digest"])
            self.assertEqual(remote["contentType"], "text/plain; charset=utf-8")
            self.assertEqual(remote["credentials"], "omitted")
            self.assertFalse(remote["automatic"])
            with tempfile.TemporaryDirectory() as directory:
                output = Path(directory) / "community.json"
                completed = subprocess.run([
                    sys.executable, str(CLI_DIR / "progrss.py"), "bundle", "fetch",
                    f"{origin}/community.json", "--output", str(output), "--json",
                ], cwd=ROOT, text=True, capture_output=True, check=False)
                self.assertEqual(completed.returncode, 0, completed.stderr)
                report = json.loads(completed.stdout)
                self.assertEqual(report["schema"], "progrss.publication-address-review.v1")
                self.assertEqual(report["savedTo"], str(output))
                self.assertFalse(report["automatic"])
                self.assertFalse(report["applied"])
                self.assertEqual(report["networkRequests"], 1)
                self.assertEqual(relay.read_bundle(output)["integrity"]["digest"], bundle["integrity"]["digest"])
                repeat = subprocess.run([
                    sys.executable, str(CLI_DIR / "progrss.py"), "bundle", "fetch",
                    f"{origin}/community.json", "--output", str(output),
                ], cwd=ROOT, text=True, capture_output=True, check=False)
                self.assertEqual(repeat.returncode, 2)
                self.assertIn("never overwrites", repeat.stderr)
            self.assertEqual(Handler.hits, 2)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)

    def test_page_discovers_one_same_origin_advertised_publication(self):
        class Handler(BaseHTTPRequestHandler):
            page = b""
            bundle = b""
            page_hits = 0
            bundle_hits = 0

            def do_GET(self):
                if self.path == "/index.html":
                    type(self).page_hits += 1
                    payload = type(self).page
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html; charset=utf-8")
                elif self.path == "/latest.json":
                    type(self).bundle_hits += 1
                    payload = type(self).bundle
                    self.send_response(200)
                    self.send_header("Content-Type", relay.BUNDLE_MEDIA_TYPE)
                else:
                    self.send_error(404)
                    return
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

            def log_message(self, *_args):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            origin = f"http://127.0.0.1:{server.server_port}"
            bundle = relay.make_bundle(
                self.state, "Shared", update_url=f"{origin}/latest.json",
                exported_at="2026-10-18T20:00:00.000Z",
            )
            files = relay.publication_site_files(bundle)
            Handler.page = files["index.html"]
            Handler.bundle = files["latest.json"]
            found, report = relay.discover_publication_from_page(f"{origin}/index.html")
            self.assertEqual(found["integrity"]["digest"], bundle["integrity"]["digest"])
            self.assertEqual(report["advertisement"]["mediaType"], relay.BUNDLE_MEDIA_TYPE)
            self.assertTrue(report["advertisement"]["sameOrigin"])
            self.assertFalse(report["automatic"])
            self.assertFalse(report["applied"])
            self.assertEqual(report["networkRequests"], 2)
            with tempfile.TemporaryDirectory() as directory:
                output = Path(directory) / "community.json"
                completed = subprocess.run([
                    sys.executable, str(CLI_DIR / "progrss.py"), "bundle", "from-page",
                    f"{origin}/index.html", "--output", str(output), "--json",
                ], cwd=ROOT, text=True, capture_output=True, check=False)
                self.assertEqual(completed.returncode, 0, completed.stderr)
                command_report = json.loads(completed.stdout)
                self.assertEqual(command_report["schema"], "progrss.publication-page-review.v1")
                self.assertEqual(command_report["savedTo"], str(output))
                self.assertFalse(command_report["applied"])
                self.assertEqual(relay.read_bundle(output)["integrity"]["digest"], bundle["integrity"]["digest"])
                overwrite = subprocess.run([
                    sys.executable, str(CLI_DIR / "progrss.py"), "bundle", "from-page",
                    f"{origin}/index.html", "--output", str(output),
                ], cwd=ROOT, text=True, capture_output=True, check=False)
                self.assertEqual(overwrite.returncode, 2)
                self.assertIn("never overwrites", overwrite.stderr)
            self.assertEqual(Handler.page_hits, 3)
            self.assertEqual(Handler.bundle_hits, 3)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)

    def test_page_discovery_refuses_cross_origin_advertisement_before_contact(self):
        class Destination(BaseHTTPRequestHandler):
            hits = 0

            def do_GET(self):
                type(self).hits += 1
                self.send_response(200)
                self.end_headers()

            def log_message(self, *_args):
                pass

        destination = ThreadingHTTPServer(("127.0.0.1", 0), Destination)
        destination_thread = threading.Thread(target=destination.serve_forever, daemon=True)
        destination_thread.start()

        class Source(BaseHTTPRequestHandler):
            def do_GET(self):
                target = f"http://127.0.0.1:{destination.server_port}/shared.json"
                body = (
                    '<!doctype html><html><head><link rel="alternate" '
                    f'type="{relay.BUNDLE_MEDIA_TYPE}" href="{target}"></head></html>'
                ).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *_args):
                pass

        source = ThreadingHTTPServer(("127.0.0.1", 0), Source)
        source_thread = threading.Thread(target=source.serve_forever, daemon=True)
        source_thread.start()
        try:
            with self.assertRaisesRegex(relay.RelayError, "same-site ProgRSS shared folder"):
                relay.discover_publication_from_page(f"http://127.0.0.1:{source.server_port}/")
            self.assertEqual(Destination.hits, 0)
        finally:
            source.shutdown()
            source.server_close()
            source_thread.join(timeout=2)
            destination.shutdown()
            destination.server_close()
            destination_thread.join(timeout=2)


    def test_explicit_publication_check_follows_same_origin_only_and_never_applies(self):
        class Handler(BaseHTTPRequestHandler):
            payload = b""
            publication_hits = 0
            def do_GET(self):
                if self.path == "/start":
                    self.send_response(302)
                    self.send_header("Location", "/publication.json")
                    self.end_headers()
                    return
                if self.path == "/publication.json":
                    type(self).publication_hits += 1
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json; charset=utf-8")
                    self.send_header("Content-Length", str(len(type(self).payload)))
                    self.end_headers()
                    self.wfile.write(type(self).payload)
                    return
                self.send_error(404)
            def log_message(self, *_args):
                pass

        server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            update_url = f"http://127.0.0.1:{server.server_port}/start"
            initial = relay.make_bundle(
                self.state, "Shared", update_url=update_url,
                exported_at="2026-10-18T20:00:00.000Z",
            )
            imported, summary = relay.import_bundle({"sources": [], "collections": [], "items": []}, initial)
            later_state = json.loads(json.dumps(self.state))
            later_state["sources"].append({"id": "later", "type": "rss", "title": "Later", "url": "https://later.example/feed"})
            later_state["collections"][0]["members"].append({"kind": "source", "id": "later"})
            later = relay.make_bundle(
                later_state, "Shared", update_url=update_url,
                exported_at="2026-10-19T20:00:00.000Z",
            )
            Handler.payload = (json.dumps(later) + "\n").encode("utf-8")
            with tempfile.TemporaryDirectory() as directory:
                temp = Path(directory)
                workspace = temp / "workspace.json"
                fetched = temp / "fetched.json"
                workspace.write_text(json.dumps({"schema": "test-envelope", "payload": imported}), encoding="utf-8")
                before = workspace.read_bytes()
                result = subprocess.run([
                    sys.executable, str(CLI_DIR / "progrss.py"), "workspace", "check-publication",
                    str(workspace), summary["rootId"], "--output", str(fetched), "--json",
                ], cwd=ROOT, text=True, capture_output=True, check=False)
                self.assertEqual(result.returncode, 0, result.stderr)
                report = json.loads(result.stdout)
                self.assertFalse(report["automatic"])
                self.assertFalse(report["applied"])
                self.assertTrue(report["review"]["canUpdate"])
                self.assertEqual(report["remote"]["networkRequests"], 2)
                self.assertEqual(len(report["remote"]["redirects"]), 1)
                self.assertEqual(workspace.read_bytes(), before)
                self.assertEqual(relay.read_bundle(fetched)["integrity"]["digest"], later["integrity"]["digest"])
                self.assertEqual(Handler.publication_hits, 1)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=2)

    def test_publication_check_stops_before_cross_origin_redirect(self):
        class Destination(BaseHTTPRequestHandler):
            hits = 0
            def do_GET(self):
                type(self).hits += 1
                self.send_response(200)
                self.end_headers()
            def log_message(self, *_args):
                pass
        destination = ThreadingHTTPServer(("127.0.0.1", 0), Destination)
        destination_thread = threading.Thread(target=destination.serve_forever, daemon=True)
        destination_thread.start()
        target = f"http://127.0.0.1:{destination.server_port}/publication.json"
        class Redirect(BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(302)
                self.send_header("Location", target)
                self.end_headers()
            def log_message(self, *_args):
                pass
        source = ThreadingHTTPServer(("127.0.0.1", 0), Redirect)
        source_thread = threading.Thread(target=source.serve_forever, daemon=True)
        source_thread.start()
        try:
            with self.assertRaisesRegex(relay.RelayError, "Nothing there was contacted"):
                relay.fetch_publication(f"http://127.0.0.1:{source.server_port}/start")
            self.assertEqual(Destination.hits, 0)
        finally:
            source.shutdown(); source.server_close(); source_thread.join(timeout=2)
            destination.shutdown(); destination.server_close(); destination_thread.join(timeout=2)

    def test_import_reuses_feed_and_pauses_new_page_watch(self):
        bundle = relay.make_bundle(self.state, "Shared")
        destination = {
            "sources": [{"id": "already", "type": "rss", "title": "Already", "url": "https://example.com/feed", "enabled": True}],
            "collections": [],
            "items": [{"id": "keep"}],
        }
        updated, summary = relay.import_bundle(destination, relay._connected_bundle(bundle))
        self.assertEqual(summary["reusedSources"], 1)
        self.assertEqual(summary["newSources"], 1)
        new_watch = next(row for row in updated["sources"] if row["type"] == "page")
        self.assertFalse(new_watch["enabled"])
        self.assertEqual(new_watch["origin"], "shared-folder")
        self.assertEqual(updated["items"], [{"id": "keep"}])
        root = next(row for row in updated["collections"] if row["id"] == summary["rootId"])
        self.assertIn({"kind": "source", "id": "already"}, root["members"])
        self.assertEqual(root["sharedFolderOrigin"]["schema"], relay.ORIGIN_SCHEMA)
        self.assertEqual(root["sharedFolderOrigin"]["signatureState"], "unsigned")
        self.assertEqual(root["sharedFolderOrigin"]["publicationId"], "root_folder")

    def test_reviewed_update_preserves_local_state_and_refuses_rollback(self):
        initial = relay.make_bundle(
            self.state, "Shared", curator="Garden desk", note="First edition.",
            exported_at="2026-10-18T20:00:00.000Z",
        )
        imported, imported_summary = relay.import_bundle({"sources": [], "collections": [], "items": [{"id": "keep", "readAt": ""}]}, initial)
        root = next(row for row in imported["collections"] if row["id"] == imported_summary["rootId"])
        root["title"] = "My local route"
        watch = next(row for row in imported["sources"] if row["type"] == "page")
        watch["title"] = "My local watch label"
        watch["enabled"] = True
        imported["items"].append({"id": f"{watch['id']}|notice", "sourceId": watch["id"], "savedAt": "2026-10-18T21:00:00Z"})

        next_state = json.loads(json.dumps(self.state))
        feed = next(row for row in next_state["sources"] if row["id"] == "feed_one")
        feed["url"] = "https://example.com/feed-v2"
        feed["title"] = "Feed one, new route"
        next_state["sources"].append({"id": "added", "type": "rss", "title": "Added", "url": "https://added.example/feed", "enabled": True})
        next_state["collections"].append({"id": "added_folder", "title": "New route", "mode": "union", "members": [{"kind": "source", "id": "added"}]})
        next_state["collections"][0]["members"].append({"kind": "collection", "id": "added_folder"})
        later = relay.make_bundle(
            next_state, "root_folder", curator="Garden desk", note="Second edition.",
            exported_at="2026-10-19T20:00:00.000Z",
        )
        review = relay.review_bundle_update(imported, later)
        self.assertTrue(review["canUpdate"])
        self.assertEqual(review["changes"]["sourceRecipesChanged"], 1)
        self.assertEqual(review["changes"]["sourcesAdded"], 1)
        self.assertEqual(review["changes"]["foldersAdded"], 1)
        self.assertGreaterEqual(review["localEdits"]["folderOverrides"], 1)
        self.assertGreaterEqual(review["localEdits"]["sourceOverrides"], 1)
        self.assertTrue(review["requiresRecipeAcknowledgement"])
        self.assertEqual(review["mergeReview"]["counts"]["recipeChanges"], 1)
        with self.assertRaisesRegex(relay.RelayError, "accept-recipe-changes"):
            relay.update_bundle(imported, later)
        updated, summary = relay.update_bundle(imported, later, acknowledge_recipe_change=True)
        self.assertTrue(summary["updated"])
        updated_root = next(row for row in updated["collections"] if row["id"] == imported_summary["rootId"])
        self.assertEqual(updated_root["title"], "My local route")
        self.assertEqual(updated_root["sharedFolderOrigin"]["schema"], relay.ORIGIN_SCHEMA)
        self.assertEqual(updated_root["sharedFolderOrigin"]["baseline"]["schema"], relay.BASELINE_SCHEMA)
        updated_watch = next(row for row in updated["sources"] if row["id"] == watch["id"])
        self.assertEqual(updated_watch["title"], "My local watch label")
        self.assertTrue(updated_watch["enabled"])
        self.assertIn({"id": f"{watch['id']}|notice", "sourceId": watch["id"], "savedAt": "2026-10-18T21:00:00Z"}, updated["items"])
        self.assertFalse(next(row for row in updated["sources"] if row.get("url") == "https://example.com/feed-v2")["enabled"])
        self.assertFalse(next(row for row in updated["sources"] if row.get("url") == "https://added.example/feed")["enabled"])
        self.assertTrue(relay.review_bundle_update(updated, later)["alreadyCurrent"])
        rollback = relay.review_bundle_update(updated, initial)
        self.assertFalse(rollback["canUpdate"])
        self.assertEqual(rollback["mode"], "older-copy")

    def test_merge_review_separates_curator_local_and_divergent_wording(self):
        initial = relay.make_bundle(
            self.state, "Shared", curator="Garden desk", note="First edition.",
            exported_at="2026-10-18T20:00:00.000Z",
        )
        imported, imported_summary = relay.import_bundle(
            {"sources": [], "collections": [], "items": []}, initial,
        )
        root = next(row for row in imported["collections"] if row["id"] == imported_summary["rootId"])
        baseline = root["sharedFolderOrigin"]["baseline"]
        source_map = {row["remoteId"]: row["localId"] for row in baseline["sourceMap"]}
        collection_map = {row["remoteId"]: row["localId"] for row in baseline["collectionMap"]}
        local_feed = next(row for row in imported["sources"] if row["id"] == source_map["feed_one"])
        local_child = next(row for row in imported["collections"] if row["id"] == collection_map["child_folder"])
        local_feed["title"] = "My feed wording"
        root["title"] = "My route wording"
        local_child["author"] = "Both editors"

        later_state = json.loads(json.dumps(self.state))
        next_feed = next(row for row in later_state["sources"] if row["id"] == "feed_one")
        next_feed["title"] = "Curator feed wording"
        next_watch = next(row for row in later_state["sources"] if row["id"] == "watch_one")
        next_watch["author"] = "Curator only"
        next_root = next(row for row in later_state["collections"] if row["id"] == "root_folder")
        next_root["title"] = "Curator route wording"
        next_child = next(row for row in later_state["collections"] if row["id"] == "child_folder")
        next_child["author"] = "Both editors"
        later = relay.make_bundle(
            later_state, "root_folder", curator="Garden desk", note="Second edition.",
            exported_at="2026-10-19T20:00:00.000Z",
        )

        review = relay.review_bundle_update(imported, later)
        merge = review["mergeReview"]
        self.assertEqual(merge["schema"], relay.MERGE_REVIEW_SCHEMA)
        self.assertGreaterEqual(merge["counts"]["conflicts"], 2)
        self.assertGreaterEqual(merge["counts"]["curatorOnly"], 1)
        self.assertGreaterEqual(merge["counts"]["agreed"], 1)
        self.assertTrue(review["requiresConflictChoices"])
        self.assertFalse(review["requiresRecipeAcknowledgement"])
        conflict_ids = {row["id"] for row in merge["conflicts"]}
        self.assertIn("source:feed_one:title", conflict_ids)
        self.assertIn("folder:root_folder:title", conflict_ids)

        with self.assertRaisesRegex(relay.RelayError, "resolve-conflicts"):
            relay.update_bundle(imported, later)

        kept, kept_summary = relay.update_bundle(imported, later, conflict_policy="keep-local")
        self.assertEqual(kept_summary["conflictPolicy"], "keep-local")
        kept_feed = next(row for row in kept["sources"] if row["id"] == source_map["feed_one"])
        kept_root = next(row for row in kept["collections"] if row["id"] == imported_summary["rootId"])
        kept_watch = next(row for row in kept["sources"] if row["id"] == source_map["watch_one"])
        self.assertEqual(kept_feed["title"], "My feed wording")
        self.assertEqual(kept_root["title"], "My route wording")
        self.assertEqual(kept_watch["author"], "Curator only")

        curator, curator_summary = relay.update_bundle(imported, later, conflict_policy="use-curator")
        self.assertEqual(curator_summary["conflictPolicy"], "use-curator")
        curator_feed = next(row for row in curator["sources"] if row["id"] == source_map["feed_one"])
        curator_root = next(row for row in curator["collections"] if row["id"] == imported_summary["rootId"])
        self.assertEqual(curator_feed["title"], "Curator feed wording")
        self.assertEqual(curator_root["title"], "Curator route wording")

    def test_removed_folder_stays_when_a_surviving_publication_folder_locally_references_it(self):
        initial_state = json.loads(json.dumps(self.state))
        initial_state["collections"].append({
            "id": "sibling_folder", "title": "Sibling", "mode": "union",
            "members": [{"kind": "source", "id": "feed_one"}],
        })
        initial_state["collections"][0]["members"].append({"kind": "collection", "id": "sibling_folder"})
        initial = relay.make_bundle(initial_state, "Shared", exported_at="2026-10-18T20:00:00.000Z")
        imported, summary = relay.import_bundle({"sources": [], "collections": [], "items": []}, initial)
        root = next(row for row in imported["collections"] if row["id"] == summary["rootId"])
        baseline = root["sharedFolderOrigin"]["baseline"]
        collection_map = {row["remoteId"]: row["localId"] for row in baseline["collectionMap"]}
        local_child = collection_map["child_folder"]
        local_sibling = collection_map["sibling_folder"]
        sibling = next(row for row in imported["collections"] if row["id"] == local_sibling)
        sibling["members"].append({"kind": "collection", "id": local_child})

        later_state = json.loads(json.dumps(initial_state))
        later_state["collections"] = [row for row in later_state["collections"] if row["id"] != "child_folder"]
        later_state["collections"][0]["members"] = [
            member for member in later_state["collections"][0]["members"]
            if not (member["kind"] == "collection" and member["id"] == "child_folder")
        ]
        later = relay.make_bundle(later_state, "Shared", exported_at="2026-10-19T20:00:00.000Z")
        review = relay.review_bundle_update(imported, later)
        self.assertTrue(review["canUpdate"])
        self.assertEqual(review["localEdits"]["detachedFolders"], 1)
        updated, _ = relay.update_bundle(imported, later)
        self.assertTrue(any(row["id"] == local_child for row in updated["collections"]))
        updated_sibling = next(row for row in updated["collections"] if row["id"] == local_sibling)
        self.assertIn({"kind": "collection", "id": local_child}, updated_sibling["members"])

    def test_signing_key_change_requires_explicit_cli_acceptance(self):
        fixtures = CLI_DIR / "fixtures" / "shared-folder"
        first = relay.read_bundle(fixtures / "ed25519.json")
        second = relay.read_bundle(fixtures / "p256.json")
        imported, _ = relay.import_bundle({"sources": [], "collections": [], "items": []}, first)
        review = relay.review_bundle_update(imported, second)
        self.assertEqual(review["trust"]["state"], "key-change")
        self.assertTrue(review["requiresTrustAcknowledgement"])
        with self.assertRaises(relay.RelayError):
            relay.update_bundle(imported, second)
        updated, summary = relay.update_bundle(imported, second, accept_trust_change=True)
        self.assertTrue(summary["updated"])
        root = next(row for row in updated["collections"] if row.get("sharedFolderOrigin"))
        self.assertEqual(root["sharedFolderOrigin"]["algorithm"], "ECDSA-P256-SHA256")

    def test_signed_to_unsigned_update_requires_explicit_acceptance(self):
        fixture = relay.read_bundle(CLI_DIR / "fixtures" / "shared-folder" / "ed25519.json")
        imported, _ = relay.import_bundle({"sources": [], "collections": [], "items": []}, fixture)
        unsigned = json.loads(json.dumps(fixture))
        unsigned["integrity"].pop("signature")
        unsigned = relay.validate_bundle(unsigned)
        review = relay.review_bundle_update(imported, unsigned)
        self.assertEqual(review["trust"]["state"], "signed-to-unsigned")
        self.assertTrue(review["requiresTrustAcknowledgement"])
        with self.assertRaises(relay.RelayError):
            relay.update_bundle(imported, unsigned)
        updated, _ = relay.update_bundle(imported, unsigned, accept_trust_change=True)
        root = next(row for row in updated["collections"] if row.get("sharedFolderOrigin"))
        self.assertEqual(root["sharedFolderOrigin"]["signatureState"], "unsigned")

    def test_origin_v1_is_reviewable_but_not_overwritten_without_a_baseline(self):
        initial = relay.make_bundle(self.state, "Shared", exported_at="2026-10-18T20:00:00.000Z")
        imported, summary = relay.import_bundle({"sources": [], "collections": [], "items": []}, initial)
        root = next(row for row in imported["collections"] if row["id"] == summary["rootId"])
        origin = root["sharedFolderOrigin"]
        root["sharedFolderOrigin"] = {
            "schema": relay.LEGACY_ORIGIN_SCHEMA,
            "publicationId": origin["publicationId"], "curator": origin["curator"], "note": origin["note"],
            "issuedAt": origin["issuedAt"], "importedAt": origin["importedAt"], "digest": origin["digest"],
            "signatureState": origin["signatureState"],
        }
        later_state = json.loads(json.dumps(self.state))
        later_state["sources"][0]["title"] = "A later title"
        later = relay.make_bundle(later_state, "Shared", exported_at="2026-10-19T20:00:00.000Z")
        review = relay.review_bundle_update(imported, later)
        self.assertFalse(review["canUpdate"])
        self.assertEqual(review["mode"], "older-local-copy")

    def test_disconnected_extra_records_are_rejected(self):
        bundle = relay.make_bundle(self.state, "Shared")
        bundle["sources"].append({"id": "extra", "type": "rss", "title": "Extra", "url": "https://extra.example/feed", "enabled": True})
        with self.assertRaises(relay.RelayError):
            relay._connected_bundle(relay.validate_bundle(bundle))

    def test_alias_reuse_and_duplicate_recipes_collapse(self):
        bundle = relay.validate_bundle({
            "schema": relay.LEGACY_BUNDLE_SCHEMA,
            "root": "shared_root",
            "title": "Shared",
            "sources": [
                {"id": "alias", "title": "Alias", "type": "rss", "url": "https://alias.example/feed.xml"},
                {"id": "fresh", "title": "Fresh", "type": "rss", "url": "https://fresh.example/feed.xml"},
                {"id": "fresh_copy", "title": "Fresh copy", "type": "rss", "url": "https://fresh.example/feed.xml"},
            ],
            "collections": [{
                "id": "shared_root", "title": "Shared", "mode": "union",
                "members": [
                    {"kind": "source", "id": "alias"},
                    {"kind": "source", "id": "fresh"},
                    {"kind": "source", "id": "fresh_copy"},
                ],
            }],
        })
        destination = {
            "sources": [{
                "id": "already", "type": "rss", "title": "Already",
                "url": "https://canonical.example/feed.xml",
                "declaredFeedUrl": "https://alias.example/feed.xml",
                "enabled": True,
            }],
            "collections": [],
            "items": [],
        }
        updated, summary = relay.import_bundle(destination, relay._connected_bundle(bundle))
        self.assertEqual(summary["reusedSources"], 1)
        self.assertEqual(summary["duplicateInFileSources"], 1)
        self.assertEqual(summary["newSources"], 1)
        fresh = [row for row in updated["sources"] if row.get("url") == "https://fresh.example/feed.xml"]
        self.assertEqual(len(fresh), 1)
        self.assertFalse(fresh[0]["enabled"])
        imported_root = next(row for row in updated["collections"] if row["id"] == summary["rootId"])
        self.assertEqual(len(imported_root["members"]), 2)

    def test_capacity_and_disconnected_bundle_are_refused(self):
        destination = {
            "sources": [
                {"id": f"s{index}", "title": f"Source {index}", "type": "rss", "url": f"https://example{index}.test/feed.xml"}
                for index in range(relay.MAX_WORKSPACE_SOURCES)
            ],
            "collections": [],
            "items": [],
        }
        bundle = relay.validate_bundle({
            "schema": relay.LEGACY_BUNDLE_SCHEMA,
            "root": "root",
            "sources": [{"id": "new", "title": "New", "type": "rss", "url": "https://new.test/feed.xml"}],
            "collections": [{"id": "root", "title": "Root", "mode": "union", "members": [{"kind": "source", "id": "new"}]}],
        })
        with self.assertRaises(relay.RelayError):
            relay.import_bundle(destination, relay._connected_bundle(bundle))

        disconnected = relay.validate_bundle({
            "schema": relay.LEGACY_BUNDLE_SCHEMA,
            "root": "root",
            "sources": [
                {"id": "one", "title": "One", "type": "rss", "url": "https://one.test/feed.xml"},
                {"id": "two", "title": "Two", "type": "rss", "url": "https://two.test/feed.xml"},
            ],
            "collections": [
                {"id": "root", "title": "Root", "mode": "union", "members": [{"kind": "source", "id": "one"}]},
                {"id": "extra", "title": "Extra", "mode": "union", "members": [{"kind": "source", "id": "two"}]},
            ],
        })
        with self.assertRaises(relay.RelayError):
            relay._connected_bundle(disconnected)

    def test_archived_sources_are_not_shared(self):
        state = json.loads(json.dumps(self.state))
        state["sources"].append({
            "id": "archived", "title": "Archived", "type": "rss",
            "url": "https://archived.test/feed.xml", "archivedAt": "2026-10-01T00:00:00Z",
        })
        state["collections"][0]["members"].append({"kind": "source", "id": "archived"})
        bundle = relay.make_bundle(state, "Shared")
        self.assertNotIn("archived", {row["id"] for row in bundle["sources"]})
        root = next(row for row in bundle["collections"] if row["id"] == bundle["root"])
        self.assertNotIn("archived", {member["id"] for member in root["members"]})

    def test_help_lists_relay_commands(self):
        main_help = subprocess.run([str(CLI_DIR / "progrss"), "--help"], cwd=CLI_DIR, text=True, capture_output=True, check=True).stdout
        workspace_help = subprocess.run([str(CLI_DIR / "progrss"), "workspace", "--help"], cwd=CLI_DIR, text=True, capture_output=True, check=True).stdout
        bundle_help = subprocess.run([str(CLI_DIR / "progrss"), "bundle", "--help"], cwd=CLI_DIR, text=True, capture_output=True, check=True).stdout
        self.assertIn("bundle", main_help)
        self.assertIn("share-folder", workspace_help)
        self.assertIn("publish-folder", workspace_help)
        self.assertIn("import-bundle", workspace_help)
        self.assertIn("review-bundle", workspace_help)
        self.assertIn("check-publication", workspace_help)
        self.assertIn("update-bundle", workspace_help)
        self.assertIn("page-changes", workspace_help)
        self.assertIn("edition", workspace_help)
        self.assertIn("inspect", bundle_help)
        self.assertIn("verify", bundle_help)
        self.assertIn("site", bundle_help)
        self.assertIn("fetch", bundle_help)
        self.assertIn("from-page", bundle_help)
        self.assertIn("check-page", bundle_help)

    def test_canonical_json_refuses_lone_surrogates_in_keys_and_values(self):
        for value in ({"safe": "\ud800"}, {"\ud800": "safe"}):
            with self.assertRaises(relay.RelayError):
                relay.canonical_json(value)

    def test_ed25519_rfc8032_vector_and_noncanonical_point(self):
        # RFC 8032, section 7.1, test vector 1 (empty message).
        public_key = bytes.fromhex("d75a980182b10ab7d54bfed3c964073a0ee172f3daa62325af021a68f707511a")
        signature = bytes.fromhex(
            "e5564300c360ac729086e2cc806e828a84877f1eb8e5d974d873e06522490155"
            "5fb8821590a33bacc61e39701cf9b46bd25bf5f0595bbe24655141438e7a100b"
        )
        self.assertTrue(relay._verify_ed25519(public_key, signature, b""))
        with self.assertRaises(relay.RelayError):
            relay._ed_decode(bytes([1]) + bytes(30) + bytes([0x80]))

    def test_signed_browser_fixtures_verify_and_tampering_is_refused(self):
        fixture_dir = CLI_DIR / "fixtures" / "shared-folder"
        for name, algorithm in (("ed25519.json", "Ed25519"), ("p256.json", "ECDSA-P256-SHA256")):
            bundle = relay.read_bundle(fixture_dir / name)
            provenance = relay.bundle_provenance(bundle)
            self.assertEqual(provenance["signatureState"], "verified")
            self.assertEqual(provenance["algorithm"], algorithm)
            self.assertTrue(relay.verify_bundle_signature(bundle))
        signed = json.loads((fixture_dir / "ed25519.json").read_text(encoding="utf-8"))
        signed["sources"][0]["title"] += " changed"
        with self.assertRaises(relay.RelayError):
            relay.validate_bundle(signed)

    def test_cli_share_inspect_and_import_round_trip(self):
        with tempfile.TemporaryDirectory() as directory:
            temp = Path(directory)
            workspace = temp / "workspace.json"
            bundle_path = temp / "shared.json"
            imported = temp / "imported.json"
            workspace.write_text(json.dumps({"schema": "test-envelope", "payload": self.state}), encoding="utf-8")
            command = [sys.executable, str(CLI_DIR / "progrss.py"), "workspace", "share-folder", str(workspace), "Shared", "--output", str(bundle_path), "--curator", "Neighborhood desk", "--note", "Sources selected for the weekly bulletin.", "--json"]
            result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(bundle_path.exists())
            inspected = subprocess.run([sys.executable, str(CLI_DIR / "progrss.py"), "bundle", "inspect", str(bundle_path), "--json"], cwd=ROOT, text=True, capture_output=True, check=False)
            self.assertEqual(inspected.returncode, 0, inspected.stderr)
            inspected_summary = json.loads(inspected.stdout)
            self.assertEqual(inspected_summary["pageWatches"], 1)
            self.assertEqual(inspected_summary["schema"], relay.BUNDLE_SCHEMA)
            self.assertEqual(inspected_summary["curator"], "Neighborhood desk")
            self.assertEqual(inspected_summary["signatureState"], "unsigned")
            verified = subprocess.run([sys.executable, str(CLI_DIR / "progrss.py"), "bundle", "verify", str(bundle_path), "--json"], cwd=ROOT, text=True, capture_output=True, check=False)
            self.assertEqual(verified.returncode, 0, verified.stderr)
            self.assertTrue(json.loads(verified.stdout)["valid"])
            required = subprocess.run([sys.executable, str(CLI_DIR / "progrss.py"), "bundle", "verify", str(bundle_path), "--require-signature"], cwd=ROOT, text=True, capture_output=True, check=False)
            self.assertEqual(required.returncode, 3, required.stderr)
            site_bundle = temp / "site-source.json"
            site_zip = temp / "site.zip"
            site_source = relay.make_bundle(
                self.state,
                "Shared",
                curator="Neighborhood desk",
                note="Sources selected for the weekly bulletin.",
                update_url="https://example.com/reading/latest.json",
                exported_at="2026-10-18T20:00:00.000Z",
            )
            site_bundle.write_text(json.dumps(site_source), encoding="utf-8")
            site_result = subprocess.run(
                [sys.executable, str(CLI_DIR / "progrss.py"), "bundle", "site", str(site_bundle), "--output", str(site_zip), "--json"],
                cwd=ROOT, text=True, capture_output=True, check=False,
            )
            self.assertEqual(site_result.returncode, 0, site_result.stderr)
            self.assertEqual(json.loads(site_result.stdout)["schema"], "progrss.publication-site.v1")
            with zipfile.ZipFile(site_zip, "r") as archive:
                self.assertIn("latest.json", archive.namelist())
                self.assertNotIn("<script", archive.read("index.html").decode("utf-8").lower())

            published_zip = temp / "published.zip"
            publish_result = subprocess.run(
                [
                    sys.executable, str(CLI_DIR / "progrss.py"), "workspace", "publish-folder",
                    str(workspace), "Shared", "--update-url", "https://example.com/reading/latest.json",
                    "--curator", "Neighborhood desk", "--note", "Sources selected for the weekly bulletin.",
                    "--output", str(published_zip), "--json",
                ],
                cwd=ROOT, text=True, capture_output=True, check=False,
            )
            self.assertEqual(publish_result.returncode, 0, publish_result.stderr)
            self.assertTrue(json.loads(publish_result.stdout)["unsigned"])
            self.assertTrue(published_zip.exists())
            overwrite_site = subprocess.run(
                [sys.executable, str(CLI_DIR / "progrss.py"), "bundle", "site", str(site_bundle), "--output", str(site_zip)],
                cwd=ROOT, text=True, capture_output=True, check=False,
            )
            self.assertEqual(overwrite_site.returncode, 2)
            self.assertIn("never overwrites", overwrite_site.stderr)
            destination = temp / "destination.json"
            destination.write_text(json.dumps({"schema": "test-envelope", "createdAt": "2000-01-01T00:00:00Z", "payload": {"sources": [], "collections": [], "items": [{"id": "keep", "createdAt": "1999-01-01T00:00:00Z"}]}}), encoding="utf-8")
            imported_result = subprocess.run([sys.executable, str(CLI_DIR / "progrss.py"), "workspace", "import-bundle", str(destination), str(bundle_path), "--output", str(imported), "--json"], cwd=ROOT, text=True, capture_output=True, check=False)
            self.assertEqual(imported_result.returncode, 0, imported_result.stderr)
            imported_doc = json.loads(imported.read_text(encoding="utf-8"))
            self.assertTrue(imported_doc["payload"]["collections"])
            self.assertTrue(all(not source["enabled"] for source in imported_doc["payload"]["sources"]))
            self.assertEqual(imported_doc["payload"]["items"][0]["createdAt"], "1999-01-01T00:00:00Z")

            section_imported = temp / "section-imported.json"
            section_result = subprocess.run(
                [
                    sys.executable, str(CLI_DIR / "progrss.py"), "workspace", "import-bundle",
                    str(destination), str(bundle_path), "--folder", "Watchlist",
                    "--output", str(section_imported), "--json",
                ],
                cwd=ROOT, text=True, capture_output=True, check=False,
            )
            self.assertEqual(section_result.returncode, 0, section_result.stderr)
            section_summary = json.loads(section_result.stdout)
            self.assertTrue(section_summary["independentExcerpt"])
            self.assertFalse(section_summary["updateLinked"])
            self.assertEqual(section_summary["selectedFolderPath"], "Shared › Watchlist")
            section_doc = json.loads(section_imported.read_text(encoding="utf-8"))
            self.assertEqual(len(section_doc["payload"]["sources"]), 1)
            self.assertEqual(section_doc["payload"]["sources"][0]["type"], "page")
            self.assertEqual(section_doc["payload"]["sources"][0]["origin"], "shared-folder-section")
            self.assertEqual(len(section_doc["payload"]["collections"]), 1)
            self.assertNotIn("sharedFolderOrigin", section_doc["payload"]["collections"][0])

            later_state = json.loads(json.dumps(self.state))
            later_state["sources"].append({"id": "later", "type": "rss", "title": "Later", "url": "https://later.example/feed", "enabled": True})
            later_state["collections"][0]["members"].append({"kind": "source", "id": "later"})
            first_stamp = dt.datetime.fromisoformat(
                json.loads(bundle_path.read_text(encoding="utf-8"))["exportedAt"].replace("Z", "+00:00")
            )
            later_stamp = (first_stamp + dt.timedelta(seconds=1)).isoformat(timespec="milliseconds").replace("+00:00", "Z")
            later_bundle = relay.make_bundle(
                later_state,
                "Shared",
                curator="Neighborhood desk",
                note="Second edition.",
                exported_at=later_stamp,
            )
            later_path = temp / "later.json"
            later_path.write_text(json.dumps(later_bundle), encoding="utf-8")
            review_result = subprocess.run([sys.executable, str(CLI_DIR / "progrss.py"), "workspace", "review-bundle", str(imported), str(later_path), "--json"], cwd=ROOT, text=True, capture_output=True, check=False)
            self.assertEqual(review_result.returncode, 0, review_result.stderr)
            self.assertTrue(json.loads(review_result.stdout)["canUpdate"])
            updated_path = temp / "updated.json"
            update_result = subprocess.run([sys.executable, str(CLI_DIR / "progrss.py"), "workspace", "update-bundle", str(imported), str(later_path), "--output", str(updated_path), "--json"], cwd=ROOT, text=True, capture_output=True, check=False)
            self.assertEqual(update_result.returncode, 0, update_result.stderr)
            self.assertTrue(updated_path.exists())
            self.assertTrue(json.loads(update_result.stdout)["updated"])

            original = bundle_path.read_bytes()
            overwrite = subprocess.run(command, cwd=ROOT, text=True, capture_output=True, check=False)
            self.assertNotEqual(overwrite.returncode, 0)
            self.assertIn("never overwrites", overwrite.stderr)
            self.assertEqual(bundle_path.read_bytes(), original)


if __name__ == "__main__":
    unittest.main()
