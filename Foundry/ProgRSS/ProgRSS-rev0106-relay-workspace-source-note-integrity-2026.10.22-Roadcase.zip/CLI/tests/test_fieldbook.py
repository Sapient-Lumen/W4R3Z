from __future__ import annotations

import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fieldbook import (  # noqa: E402
    EXCHANGE_FIELDWORK_SCENARIO,
    EXCHANGE_SENDER_FIELDWORK_SCENARIO,
    FIELDWORK_KIT_SCHEMA,
    FIELDWORK_REPORT_SCHEMA,
    build_exchange_fieldwork_scenario,
    build_exchange_sender_fieldwork_scenario,
    build_trace_fieldwork_scenario,
    render_fieldbook_html,
)


class FieldbookTests(unittest.TestCase):
    def review(self) -> dict[str, object]:
        return {
            "schema": "progrss.node.bearing-review.v2",
            "state": "review",
            "library": {"file": "private-library.sqlite3", "sha256": "a" * 64},
            "source": {
                "id": "secret-source-id",
                "title": "Private medical portal",
                "host": "private.example.test",
                "accepted": {"units": 3},
                "currentHeld": {"units": 3},
            },
            "diagnosis": {
                "kind": "moving-rendered-window",
                "title": "Moving rendered window",
                "summary": "Secret diagnosis detail should not be copied.",
                "cannotProve": "Secret limitation should not be copied.",
            },
            "trace": {
                "schema": "progrss.node.bearing-trace.v1",
                "accepted": {"mode": "cards", "units": 3},
                "observations": [
                    {
                        "ordinal": 1,
                        "current": False,
                        "relationshipToPrevious": {"kind": "different-window", "title": "Different window"},
                        "boundaryKinds": ["partial-render"],
                    },
                    {
                        "ordinal": 2,
                        "current": True,
                        "relationshipToPrevious": {"kind": "partial-overlap", "title": "Some overlap"},
                        "boundaryKinds": ["partial-render", "frames"],
                    },
                ],
            },
            "recipeFootprint": {
                "schema": "progrss.node.recipe-footprint.v1",
                "kind": "semantic-boundary",
                "label": "Semantic boundary",
                "advanced": {"selector": "main article.secret", "titleSelector": "h2", "linkSelector": "a"},
            },
            "advanced": {"sourceIdentitySha256": "b" * 64},
            "network": False,
            "writes": False,
        }

    def exchange_review(self) -> dict[str, object]:
        return {
            "schema": "progrss.node.exchange.v1",
            "state": "review",
            "exchangeId": "secret-exchange-id",
            "title": "Private neighborhood route",
            "curator": "Private curator",
            "note": "Private route note",
            "expiresAt": "2026-10-20T20:30:00Z",
            "scope": "one-expiring-reviewed-artifact-handoff",
            "automatic": False,
            "revocable": True,
            "counts": {"sources": 3, "feeds": 2, "pageWatches": 1, "folders": 2, "recentUpdates": 4},
            "choices": {
                "followUpdates": {"available": True, "feedUrl": "https://private.example/updates.json"},
                "addRoute": {"available": True},
                "takeBranch": {
                    "available": True,
                    "branches": [{"id": "secret-folder", "path": "Private route › Meetings", "sources": 2}],
                },
            },
            "contents": {
                "sources": [{"title": "Secret source", "host": "private.example", "url": "https://private.example/feed"}],
            },
            "public": {"sourceListUrl": "https://private.example/source-list.json"},
            "node": {"origin": "http://127.0.0.1:6789", "instanceFingerprint": "secret-fingerprint"},
        }

    def exchange_preview(self) -> dict[str, object]:
        return {
            "schema": "progrss.node.exchange-preview.v1",
            "state": "preview",
            "previewToken": "secret-preview-token",
            "previewDigest": "a" * 64,
            "expiresAt": "2026-10-20T20:10:00Z",
            "title": "Private neighborhood route",
            "curator": "Private curator",
            "note": "Private route note",
            "library": {"file": "private-library.sqlite3", "sha256": "b" * 64},
            "folder": {"id": "secret-folder-root", "path": "Private route"},
            "counts": {"sources": 3, "feeds": 2, "pageWatches": 1, "folders": 2, "recentUpdates": 4},
            "choices": {
                "followUpdates": {"available": True, "feedUrl": "https://private.example/updates.json"},
                "addRoute": {"available": True},
                "takeBranch": {
                    "available": True,
                    "branches": [{"id": "secret-folder", "path": "Private route › Meetings", "sources": 2}],
                },
            },
            "contents": {
                "sources": [{"title": "Secret source", "host": "private.example", "folders": ["Private route"]}],
                "folders": [{"id": "secret-folder", "path": "Private route › Meetings"}],
            },
            "public": {
                "sourceListUrl": "https://private.example/source-list.json",
                "pageUrl": "https://private.example/",
                "feedUrl": "https://private.example/recent-updates.json",
            },
            "privacy": {
                "included": ["source recipes", "simple folder routes", "curator wording", "bounded recent-update summaries when selected"],
                "excluded": [
                    "read and unread state", "saved state", "full retained article text",
                    "page-watch snapshots and comparison evidence", "browser permissions and cookies",
                    "private signing keys",
                ],
            },
            "artifacts": {
                "sourceList": {"available": True, "name": "secret-source-list.json", "sha256": "c" * 64},
                "recentUpdates": {"available": True, "name": "recent-updates.json", "sha256": "d" * 64},
                "site": {"available": True, "name": "secret-site.zip", "sha256": "e" * 64},
            },
            "network": False,
            "writes": False,
            "automatic": False,
        }

    def test_scenario_is_bounded_and_excludes_source_identity(self) -> None:
        scenario = build_trace_fieldwork_scenario(
            self.review(),
            version="0.80.0",
            revision="rev0080",
            codename="Fieldbook",
            generated_at="2026-10-20T20:00:00Z",
        )
        self.assertEqual(scenario["schema"], FIELDWORK_KIT_SCHEMA)
        self.assertEqual(scenario["scenario"], "trace-bearing-anchor")
        self.assertEqual(len(scenario["tasks"]), 12)
        self.assertEqual(len(scenario["scenarioDigest"]), 64)
        self.assertFalse(scenario["privacy"]["participantIdentityRequested"])
        self.assertFalse(scenario["privacy"]["sourceAddressIncluded"])
        serialized = json.dumps(scenario, ensure_ascii=False)
        for secret in (
            "secret-source-id",
            "Private medical portal",
            "private.example.test",
            "main article.secret",
            "Secret diagnosis detail",
            "Secret limitation",
            "private-library.sqlite3",
            "b" * 64,
        ):
            self.assertNotIn(secret, serialized)

    def test_html_is_self_contained_local_only_and_reviewable(self) -> None:
        scenario = build_trace_fieldwork_scenario(
            self.review(),
            version="0.80.0",
            revision="rev0080",
            codename="Fieldbook",
            generated_at="2026-10-20T20:00:00Z",
        )
        raw = render_fieldbook_html(scenario)
        text = raw.decode("utf-8")
        self.assertIn("Test the wording, not the person.", text)
        self.assertIn(FIELDWORK_KIT_SCHEMA, text)
        self.assertIn(FIELDWORK_REPORT_SCHEMA, text)
        self.assertIn("connect-src 'none'", text)
        self.assertIn("form-action 'none'", text)
        self.assertIn("No telemetry", text)
        self.assertIn("No identity field", text)
        self.assertIn("No automatic saving", text)
        self.assertIn("Download JSON report", text)
        self.assertIn("Download Markdown report", text)
        self.assertIn("Understood independently", text)
        self.assertIn("Wrong turn or unsafe interpretation", text)
        self.assertNotIn("https://", text)
        self.assertNotIn("http://", text)
        self.assertNotIn("fetch(", text)
        self.assertNotIn("XMLHttpRequest", text)
        self.assertNotIn("WebSocket", text)
        self.assertNotIn("sendBeacon", text)
        self.assertNotIn("localStorage", text)
        self.assertNotIn("sessionStorage", text)
        self.assertNotIn("indexedDB", text)
        self.assertNotIn("serviceWorker", text)
        self.assertNotIn("<form", text.lower())
        self.assertNotIn("Private medical portal", text)
        self.assertNotIn("main article.secret", text)

    def test_exchange_scenario_uses_actual_choices_and_omits_route_identity(self) -> None:
        scenario = build_exchange_fieldwork_scenario(
            self.exchange_review(),
            version="0.80.0",
            revision="rev0080",
            codename="Roadcase",
            generated_at="2026-10-20T21:00:00Z",
        )
        self.assertEqual(scenario["schema"], FIELDWORK_KIT_SCHEMA)
        self.assertEqual(scenario["scenario"], EXCHANGE_FIELDWORK_SCENARIO)
        self.assertEqual(len(scenario["tasks"]), 15)
        self.assertEqual(scenario["context"]["choices"]["branchChoices"], 1)
        self.assertFalse(scenario["privacy"]["capabilityIncluded"])
        serialized = json.dumps(scenario, ensure_ascii=False)
        for secret in (
            "secret-exchange-id",
            "Private neighborhood route",
            "Private curator",
            "Private route note",
            "private.example",
            "Private route › Meetings",
            "secret-folder",
            "secret-fingerprint",
            "127.0.0.1",
        ):
            self.assertNotIn(secret, serialized)
        text = render_fieldbook_html(scenario).decode("utf-8")
        self.assertIn("Observe the choice, not the person.", text)
        self.assertIn("Follow updates", text)
        self.assertIn("Add the complete route", text)
        self.assertIn("Take one branch", text)
        self.assertIn("connect-src 'none'", text)
        self.assertNotIn("Private neighborhood route", text)
        self.assertNotIn("private.example", text)
        self.assertNotIn("secret-exchange-id", text)

    def test_exchange_scenario_adapts_when_follow_or_branch_is_unavailable(self) -> None:
        review = self.exchange_review()
        review["choices"]["followUpdates"] = {"available": False, "reason": "No durable feed"}  # type: ignore[index]
        review["choices"]["takeBranch"] = {"available": False, "branches": []}  # type: ignore[index]
        scenario = build_exchange_fieldwork_scenario(
            review,
            version="0.80.0",
            revision="rev0080",
            codename="Roadcase",
            generated_at="2026-10-20T21:00:00Z",
        )
        task_ids = {row["id"] for row in scenario["tasks"]}
        self.assertNotIn("follow-updates", task_ids)
        self.assertNotIn("choose-follow", task_ids)
        self.assertNotIn("take-branch", task_ids)
        self.assertNotIn("choose-branch", task_ids)
        self.assertIn("add-route", task_ids)

    def test_exchange_sender_scenario_explains_outbound_boundary_without_identity(self) -> None:
        scenario = build_exchange_sender_fieldwork_scenario(
            self.exchange_preview(),
            version="0.80.0",
            revision="rev0080",
            codename="Roadcase",
            generated_at="2026-10-20T22:00:00Z",
        )
        self.assertEqual(scenario["schema"], FIELDWORK_KIT_SCHEMA)
        self.assertEqual(scenario["scenario"], EXCHANGE_SENDER_FIELDWORK_SCENARIO)
        self.assertEqual(len(scenario["tasks"]), 16)
        self.assertTrue(scenario["context"]["public"]["durableFeedAvailable"])
        self.assertFalse(scenario["privacy"]["capabilityIncluded"])
        self.assertFalse(scenario["privacy"]["publicAddressIncluded"])
        serialized = json.dumps(scenario, ensure_ascii=False)
        for secret in (
            "secret-preview-token", "Private neighborhood route", "Private curator",
            "Private route note", "private.example", "Private route › Meetings",
            "secret-folder", "private-library.sqlite3", "secret-source-list.json",
            "secret-site.zip", "a" * 64, "b" * 64, "c" * 64, "d" * 64, "e" * 64,
        ):
            self.assertNotIn(secret, serialized)
        text = render_fieldbook_html(scenario).decode("utf-8")
        self.assertIn("Know what leaves before you send the link.", text)
        self.assertIn("Explain what stays private", text)
        self.assertIn("Create 30-minute handoff", text)
        self.assertIn("connect-src 'none'", text)
        self.assertNotIn("Private neighborhood route", text)
        self.assertNotIn("private.example", text)

    def test_exchange_sender_scenario_adapts_to_private_handoff(self) -> None:
        preview = self.exchange_preview()
        preview["choices"]["followUpdates"] = {"available": False, "reason": "No durable feed"}  # type: ignore[index]
        preview["choices"]["takeBranch"] = {"available": False, "branches": []}  # type: ignore[index]
        preview["public"] = {"sourceListUrl": "", "pageUrl": "", "feedUrl": ""}
        preview["artifacts"]["site"] = {"available": False}  # type: ignore[index]
        scenario = build_exchange_sender_fieldwork_scenario(
            preview,
            version="0.80.0",
            revision="rev0080",
            codename="Roadcase",
            generated_at="2026-10-20T22:00:00Z",
        )
        task_ids = {row["id"] for row in scenario["tasks"]}
        self.assertIn("follow-unavailable", task_ids)
        self.assertNotIn("durable-follow", task_ids)
        self.assertNotIn("branch-consequence", task_ids)
        self.assertIn("public-address-unavailable", task_ids)
        self.assertNotIn("public-address", task_ids)
        self.assertIn("static-package-unavailable", task_ids)
        self.assertNotIn("static-package", task_ids)
        self.assertFalse(scenario["context"]["artifacts"]["staticSite"])


if __name__ == "__main__":
    unittest.main()
