#!/usr/bin/env python3
"""Rendered smoke lane for the extracted ProgRSS Roadcase packet."""
from __future__ import annotations

import asyncio
import os
from pathlib import Path
import sys

from playwright.async_api import async_playwright

PACKET = Path(os.environ.get("PROGRSS_ROADCASE_DIR", "/tmp/progrss-roadcase-rev0080-clean")).resolve()
ARTIFACTS = Path(os.environ.get("PROGRSS_ROADCASE_ARTIFACTS", "/tmp/progrss-roadcase-rev0080-screens")).resolve()
ARTIFACTS.mkdir(parents=True, exist_ok=True)


async def main() -> int:
    start = PACKET / "START.html"
    if not start.is_file():
        print(f"Roadcase START.html not found: {start}", file=sys.stderr)
        return 2
    async with async_playwright() as pw:
        browser = await pw.chromium.launch(headless=True, executable_path="/usr/bin/chromium", args=["--disable-gpu", "--no-sandbox"])
        page = await browser.new_page(viewport={"width": 1440, "height": 980}, device_scale_factor=1)
        await page.set_content(start.read_text(encoding="utf-8"), wait_until="load")
        assert await page.locator("h1").inner_text() == "Roadcase"
        text = await page.locator("body").inner_text()
        for expected in (
            "Verify before use",
            "Use a fresh browser profile",
            "Prepare the synthetic Node",
            "Run one scenario",
            "Clean up",
            "What this packet cannot prove",
            "no telemetry",
        ):
            assert expected.lower() in text.lower(), expected
        assert await page.locator("html").get_attribute("data-theme") == "dark"
        await page.screenshot(path=str(ARTIFACTS / "roadcase-start-dark.png"), full_page=True)
        await page.locator("#theme").click()
        assert await page.locator("html").get_attribute("data-theme") == "light"
        await page.screenshot(path=str(ARTIFACTS / "roadcase-start-light.png"), full_page=True)
        # Narrow reflow and keyboard focus remain usable.
        await page.set_viewport_size({"width": 390, "height": 844})
        await page.locator("#theme").focus()
        focused = await page.evaluate("document.activeElement && document.activeElement.id")
        assert focused == "theme"
        overflow = await page.evaluate("document.documentElement.scrollWidth <= document.documentElement.clientWidth + 1")
        assert overflow
        await page.screenshot(path=str(ARTIFACTS / "roadcase-start-narrow.png"), full_page=True)
        await browser.close()
    print(f"PASS rendered Roadcase: dark/light themes, exact-release guidance, no-claim boundary, keyboard focus, and narrow reflow")
    print(f"Artifacts: {ARTIFACTS}")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
