from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import unittest
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from exchange import prepare_exchange  # noqa: E402


FIXTURE = ROOT / "fixtures" / "exchange-backup.json"


class ExchangeSourceNoteDisclosureTests(unittest.TestCase):
    def prepare(self, state: dict | None = None):
        raw = FIXTURE.read_bytes()
        document = json.loads(raw)
        return prepare_exchange(
            state or document["state"],
            "folder-neighborhood",
            library_file=FIXTURE.name,
            library_sha256=hashlib.sha256(raw).hexdigest(),
            curator="Neighborhood readers",
            note="A practical route for local meetings and useful notices.",
            public_update_url="https://exchange.example.test/neighborhood/progrss-source-list.json",
            include_recent_updates=True,
            generated_at="2026-10-18T23:30:00.000Z",
        )

    def test_preview_discloses_exact_route_bound_reasons(self) -> None:
        prepared = self.prepare()
        preview = prepared.preview
        self.assertEqual(preview["counts"]["sourceNotes"], 3)
        self.assertFalse(preview["network"])
        self.assertFalse(preview["writes"])
        self.assertIn(
            "curator-written reasons on direct folder/source placements",
            preview["privacy"]["included"],
        )
        council = next(row for row in preview["contents"]["sources"] if row["id"] == "feed-council")
        self.assertEqual(council["sourceNoteCount"], 2)
        self.assertEqual(
            council["placements"],
            [
                {
                    "folderId": "folder-neighborhood",
                    "folderPath": "Neighborhood signal",
                    "reason": "Broad agenda overview.",
                },
                {
                    "folderId": "folder-meetings",
                    "folderPath": "Neighborhood signal › Public meetings",
                    "reason": "سبب لاجتماعات المجلس المحلية.",
                },
            ],
        )
        notices = next(row for row in preview["contents"]["sources"] if row["id"] == "page-notices")
        self.assertEqual(notices["sourceNoteCount"], 0)
        self.assertNotIn("reason", notices["placements"][0])
        branch = preview["choices"]["takeBranch"]["branches"][0]
        self.assertEqual(branch["sourceNotes"], 1)

    def test_source_list_keeps_both_reasons_for_one_source(self) -> None:
        prepared = self.prepare()
        bundle = json.loads(prepared.source_list)
        collections = {row["id"]: row for row in bundle["collections"]}
        root_member = next(
            row for row in collections["folder-neighborhood"]["members"]
            if row.get("kind") == "source" and row.get("id") == "feed-council"
        )
        child_member = next(
            row for row in collections["folder-meetings"]["members"]
            if row.get("kind") == "source" and row.get("id") == "feed-council"
        )
        self.assertEqual(root_member["reason"], "Broad agenda overview.")
        self.assertEqual(child_member["reason"], "سبب لاجتماعات المجلس المحلية.")
        notices = next(
            row for row in collections["folder-meetings"]["members"]
            if row.get("kind") == "source" and row.get("id") == "page-notices"
        )
        self.assertNotIn("reason", notices)

    def test_reason_change_changes_preview_digest_without_new_authority(self) -> None:
        document = json.loads(FIXTURE.read_text())
        first = self.prepare(document["state"])
        changed = copy.deepcopy(document["state"])
        changed["collections"][0]["members"][0]["reason"] = "A different reviewed reason."
        second = self.prepare(changed)
        self.assertNotEqual(first.preview["previewDigest"], second.preview["previewDigest"])
        self.assertEqual(first.preview["choices"].keys(), second.preview["choices"].keys())
        self.assertFalse(second.preview["automatic"])
        self.assertFalse(second.preview["network"])
        self.assertFalse(second.preview["writes"])


if __name__ == "__main__":
    unittest.main()
