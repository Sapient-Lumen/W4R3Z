from __future__ import annotations

import contextlib
import copy
import io
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve()
CLI_DIR = HERE.parents[1]
sys.path.insert(0, str(CLI_DIR))

import relay


class SourceNotesEntrypointTests(unittest.TestCase):
    def source(self) -> dict:
        return {
            "id": "source_one",
            "type": "rss",
            "title": "Source one",
            "url": "https://notes.example/feed.xml",
            "enabled": True,
        }

    def route_state(self) -> dict:
        return {
            "schemaVersion": 17,
            "sources": [self.source()],
            "collections": [
                {
                    "id": "route_root",
                    "title": "Route",
                    "mode": "union",
                    "members": [
                        {"kind": "source", "id": "source_one", "reason": "  Root reason.\n"},
                        {"kind": "collection", "id": "route_child"},
                    ],
                },
                {
                    "id": "route_child",
                    "title": "Child",
                    "mode": "union",
                    "members": [
                        {"kind": "source", "id": "source_one", "reason": "Child reason."},
                    ],
                },
            ],
            "items": [],
        }

    def update_state(self) -> dict:
        reasons = {
            "route_root": "Conflict base",
            "recipient_only": "Recipient base",
            "curator_only": "Curator base",
            "agreed": "Agreed base",
            "delete_edit": "Delete/edit base",
            "edit_delete": "Edit/delete base",
        }
        folders = []
        child_refs = []
        for folder_id, reason in reasons.items():
            folders.append({
                "id": folder_id,
                "title": folder_id.replace("_", " ").title(),
                "mode": "union",
                "members": [{"kind": "source", "id": "source_one", "reason": reason}],
            })
            if folder_id != "route_root":
                child_refs.append({"kind": "collection", "id": folder_id})
        folders[0]["members"].extend(child_refs)
        return {"schemaVersion": 17, "sources": [self.source()], "collections": folders, "items": []}

    @staticmethod
    def local_collection(imported: dict, baseline: dict, remote_id: str) -> dict:
        local_id = next(row["localId"] for row in baseline["collectionMap"] if row["remoteId"] == remote_id)
        return next(row for row in imported["collections"] if row["id"] == local_id)

    @staticmethod
    def set_reason(collection: dict, source_id: str, reason: str | None) -> None:
        member = next(row for row in collection["members"] if row["kind"] == "source" and row["id"] == source_id)
        if reason is None:
            member.pop("reason", None)
        else:
            member["reason"] = reason

    def test_schema_canonicalization_and_duplicate_rules(self):
        state = self.route_state()
        bundle = relay.make_bundle(state, "route_root", exported_at="2026-10-21T01:00:00.000Z")
        root = next(row for row in bundle["collections"] if row["id"] == "route_root")
        self.assertEqual(root["members"][0]["reason"], "Root reason.")
        self.assertEqual(relay.normalize_reason("😀" * 280), "😀" * 280)
        with self.assertRaisesRegex(relay.SourceNoteError, "280"):
            relay.normalize_reason("😀" * 281)
        with self.assertRaisesRegex(relay.SourceNoteError, "Unicode scalar"):
            relay.normalize_reason("\ud800")

        empty = copy.deepcopy(state)
        empty["collections"][0]["members"][0]["reason"] = " \t\n"
        empty_bundle = relay.make_bundle(empty, "route_root", exported_at="2026-10-21T01:00:00.000Z")
        empty_root = next(row for row in empty_bundle["collections"] if row["id"] == "route_root")
        self.assertNotIn("reason", empty_root["members"][0])

        duplicate = copy.deepcopy(state)
        duplicate["collections"][0]["members"].insert(1, {
            "kind": "source", "id": "source_one", "reason": "Root reason."
        })
        duplicate_bundle = relay.make_bundle(duplicate, "route_root", exported_at="2026-10-21T01:00:00.000Z")
        duplicate_root = next(row for row in duplicate_bundle["collections"] if row["id"] == "route_root")
        self.assertEqual(sum(1 for row in duplicate_root["members"] if row["kind"] == "source"), 1)

        conflicting = copy.deepcopy(state)
        conflicting["collections"][0]["members"].insert(1, {
            "kind": "source", "id": "source_one", "reason": "Another reason."
        })
        with self.assertRaisesRegex(relay.RelayError, "conflicting Source Notes"):
            relay.make_bundle(conflicting, "route_root", exported_at="2026-10-21T01:00:00.000Z")

        non_source = copy.deepcopy(state)
        non_source["collections"][0]["members"][1]["reason"] = "Not allowed"
        with self.assertRaisesRegex(relay.RelayError, "direct source placement"):
            relay.make_bundle(non_source, "route_root", exported_at="2026-10-21T01:00:00.000Z")

        folder_reason = copy.deepcopy(state)
        folder_reason["collections"][0]["reason"] = "Not allowed"
        with self.assertRaisesRegex(relay.RelayError, "not to a folder"):
            relay.make_bundle(folder_reason, "route_root", exported_at="2026-10-21T01:00:00.000Z")

    def test_export_contents_branch_import_and_opml_omission(self):
        state = self.route_state()
        bundle = relay.make_bundle(
            state, "route_root", curator="Route desk",
            exported_at="2026-10-21T01:00:00.000Z",
        )
        report = relay.bundle_contents(bundle)
        self.assertEqual(report["sourceNoteCount"], 2)
        source = report["sources"][0]
        self.assertEqual(source["sourceNoteCount"], 2)
        self.assertEqual(
            [(row["folderId"], row.get("reason")) for row in source["placements"]],
            [("route_root", "Root reason."), ("route_child", "Child reason.")],
        )
        by_folder = {row["id"]: row for row in report["folders"]}
        self.assertEqual(by_folder["route_root"]["directSourceNotes"], 1)
        self.assertEqual(by_folder["route_child"]["directSourceNotes"], 1)

        branch, selection = relay.select_bundle_section(bundle, "route_child")
        self.assertTrue(selection["independentExcerpt"])
        self.assertEqual(branch["root"], "route_child")
        self.assertEqual(branch["collections"][0]["members"][0]["reason"], "Child reason.")
        self.assertNotIn("Root reason.", json.dumps(branch, ensure_ascii=False))

        imported, summary = relay.import_bundle({"sources": [], "collections": [], "items": []}, bundle, "route_child")
        self.assertTrue(summary["independentExcerpt"])
        imported_root = next(row for row in imported["collections"] if row["id"] == summary["rootId"])
        self.assertEqual(imported_root["members"][0]["reason"], "Child reason.")

        opml = relay._opml(bundle, created_at="2026-10-21T01:00:00.000Z").decode("utf-8")
        self.assertNotIn("Root reason.", opml)
        self.assertNotIn("Child reason.", opml)
        self.assertNotIn("reason=", opml)

        with tempfile.TemporaryDirectory() as temp_name:
            temp = Path(temp_name)
            workspace = temp / "workspace.json"
            output = temp / "route.opml"
            workspace_state = copy.deepcopy(state)
            workspace_state["collections"][0]["members"][0]["reason"] = "Root reason."
            workspace.write_text(json.dumps(workspace_state), encoding="utf-8")
            completed = subprocess.run(
                [str(CLI_DIR / "progrss"), "workspace", "share-folder", str(workspace), "route_root",
                 "--format", "opml", "--output", str(output), "--json"],
                cwd=CLI_DIR, text=True, capture_output=True, check=True,
            )
            summary = json.loads(completed.stdout)
            self.assertFalse(summary["sourceNotesIncluded"])
            self.assertEqual(summary["omittedSourceNoteCount"], 2)
            self.assertEqual(summary["omittedSourceNotePlacements"], [
                {"folderId": "route_root", "sourceId": "source_one"},
                {"folderId": "route_child", "sourceId": "source_one"},
            ])
            self.assertNotIn("reason", output.read_text(encoding="utf-8"))

    def test_three_way_update_requires_placement_scoped_decisions(self):
        initial_state = self.update_state()
        initial = relay.make_bundle(initial_state, "route_root", exported_at="2026-10-21T01:00:00.000Z")
        imported, summary = relay.import_bundle({"sources": [], "collections": [], "items": []}, initial)
        root = next(row for row in imported["collections"] if row["id"] == summary["rootId"])
        baseline = root["sharedFolderOrigin"]["baseline"]
        local_source_id = next(row["localId"] for row in baseline["sourceMap"] if row["remoteId"] == "source_one")

        self.set_reason(self.local_collection(imported, baseline, "route_root"), local_source_id, "Mine")
        self.set_reason(self.local_collection(imported, baseline, "recipient_only"), local_source_id, "Recipient changed")
        self.set_reason(self.local_collection(imported, baseline, "agreed"), local_source_id, "Same change")
        self.set_reason(self.local_collection(imported, baseline, "delete_edit"), local_source_id, None)
        self.set_reason(self.local_collection(imported, baseline, "edit_delete"), local_source_id, "Mine before deletion")

        later_state = copy.deepcopy(initial_state)
        by_id = {row["id"]: row for row in later_state["collections"]}
        by_id["route_root"]["members"][0]["reason"] = "Curator"
        by_id["curator_only"]["members"][0]["reason"] = "Curator changed"
        by_id["agreed"]["members"][0]["reason"] = "Same change"
        by_id["delete_edit"]["members"][0]["reason"] = "Curator after local deletion"
        by_id["edit_delete"]["members"][0].pop("reason")
        later = relay.make_bundle(later_state, "route_root", exported_at="2026-10-21T02:00:00.000Z")

        review = relay.review_bundle_update(imported, later)
        conflicts = {row["id"]: row for row in review["mergeReview"]["conflicts"]}
        expected = {
            "placement:route_root:source:source_one:reason",
            "placement:delete_edit:source:source_one:reason",
            "placement:edit_delete:source:source_one:reason",
        }
        self.assertEqual(set(conflicts), expected)
        self.assertTrue(review["requiresConflictChoices"])
        self.assertGreaterEqual(review["mergeReview"]["counts"]["recipientOnly"], 1)
        self.assertGreaterEqual(review["mergeReview"]["counts"]["curatorOnly"], 1)
        self.assertGreaterEqual(review["mergeReview"]["counts"]["agreed"], 1)

        with self.assertRaisesRegex(relay.RelayError, "--conflict"):
            relay.update_bundle(imported, later)
        with self.assertRaisesRegex(relay.RelayError, "stale or unknown"):
            relay.update_bundle(imported, later, conflict_decisions={"placement:stale:source:source_one:reason": "keep-local"})
        with self.assertRaisesRegex(relay.RelayError, "--conflict"):
            relay.update_bundle(imported, later, conflict_decisions={next(iter(expected)): "keep-local"})
        with self.assertRaisesRegex(relay.RelayError, "--conflict"):
            relay.update_bundle(imported, later, conflict_decisions={key: "invalid" for key in expected})

        decisions = {
            "placement:route_root:source:source_one:reason": "keep-local",
            "placement:delete_edit:source:source_one:reason": "use-curator",
            "placement:edit_delete:source:source_one:reason": "use-curator",
        }
        updated, applied = relay.update_bundle(imported, later, conflict_decisions=decisions)
        self.assertEqual(applied["conflictPolicy"], "per-conflict")
        self.assertEqual(applied["conflictDecisions"], decisions)
        updated_root = next(row for row in updated["collections"] if row["id"] == summary["rootId"])
        next_baseline = updated_root["sharedFolderOrigin"]["baseline"]
        self.assertEqual(self.local_collection(updated, next_baseline, "route_root")["members"][0]["reason"], "Mine")
        self.assertEqual(self.local_collection(updated, next_baseline, "recipient_only")["members"][0]["reason"], "Recipient changed")
        self.assertEqual(self.local_collection(updated, next_baseline, "curator_only")["members"][0]["reason"], "Curator changed")
        self.assertEqual(self.local_collection(updated, next_baseline, "agreed")["members"][0]["reason"], "Same change")
        self.assertEqual(self.local_collection(updated, next_baseline, "delete_edit")["members"][0]["reason"], "Curator after local deletion")
        self.assertNotIn("reason", self.local_collection(updated, next_baseline, "edit_delete")["members"][0])

        subsequent_state = copy.deepcopy(later_state)
        subsequent_state["sources"][0]["title"] = "Source one, later edition"
        subsequent = relay.make_bundle(
            subsequent_state, "route_root", exported_at="2026-10-21T03:00:00.000Z"
        )
        with self.assertRaisesRegex(relay.RelayError, "stale or unknown"):
            relay.update_bundle(updated, subsequent, conflict_decisions=decisions)


if __name__ == "__main__":
    unittest.main()
