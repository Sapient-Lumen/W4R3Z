from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest

CLI_DIR = Path(__file__).resolve().parents[1]
FIXTURES = CLI_DIR / "fixtures"
if str(CLI_DIR) not in sys.path:
    sys.path.insert(0, str(CLI_DIR))

import progrss  # noqa: E402
from node_server import NodeError, _read_backup  # noqa: E402
from node_store import NodeStore, NodeStoreError  # noqa: E402


class NodePrivateLibrarySourceNoteTests(unittest.TestCase):
    def valid_document(self) -> dict:
        document = json.loads((FIXTURES / "sample-backup.json").read_text(encoding="utf-8"))
        shared = document["state"]["sources"][0]["id"]
        plain = document["state"]["sources"][1]["id"]
        document["state"]["collections"] = [
            {
                "id": "alpha", "title": "Alpha", "mode": "union", "include": "", "exclude": "",
                "version": 1, "author": "Curator", "members": [
                    {"kind": "source", "id": shared, "reason": "Alpha reason.\nSecond line."},
                    {"kind": "source", "id": plain},
                    {"kind": "collection", "id": "child"},
                ],
            },
            {
                "id": "child", "title": "Child", "mode": "union", "include": "", "exclude": "",
                "version": 1, "author": "Curator", "members": [
                    {"kind": "source", "id": shared, "reason": "سبب مختلف للمجلد."},
                ],
            },
        ]
        return document

    @staticmethod
    def write(folder: Path, document: dict, name: str = "private.json") -> Path:
        path = folder / name
        path.write_text(json.dumps(document, ensure_ascii=True, separators=(",", ":")) + "\n", encoding="utf-8")
        return path

    def malformed_documents(self) -> list[tuple[str, dict]]:
        rows: list[tuple[str, dict]] = []

        over_limit = self.valid_document()
        over_limit["state"]["collections"][0]["members"][0]["reason"] = "x" * 281
        rows.append(("over-limit", over_limit))

        folder_level = self.valid_document()
        folder_level["state"]["collections"][0]["reason"] = "Wrong level"
        rows.append(("folder-level", folder_level))

        member_level = self.valid_document()
        member_level["state"]["collections"][0]["members"][2]["reason"] = "Wrong member"
        rows.append(("folder-member", member_level))

        duplicate = self.valid_document()
        duplicate["state"]["collections"][0]["members"].insert(
            1, copy.deepcopy(duplicate["state"]["collections"][0]["members"][0])
        )
        rows.append(("reason-bearing-duplicate", duplicate))

        empty = self.valid_document()
        empty["state"]["collections"][0]["members"][0]["reason"] = ""
        rows.append(("empty", empty))

        edge_whitespace = self.valid_document()
        edge_whitespace["state"]["collections"][0]["members"][0]["reason"] = " Alpha reason. "
        rows.append(("edge-whitespace", edge_whitespace))

        non_string = self.valid_document()
        non_string["state"]["collections"][0]["members"][0]["reason"] = 17
        rows.append(("non-string", non_string))

        invalid_unicode = self.valid_document()
        invalid_unicode["state"]["collections"][0]["members"][0]["reason"] = "\ud800"
        rows.append(("invalid-unicode", invalid_unicode))

        missing_source = self.valid_document()
        missing_source["state"]["collections"][0]["members"][0]["id"] = "missing-source"
        rows.append(("missing-source", missing_source))
        return rows

    def test_valid_two_folder_reasons_round_trip_through_both_node_ingress_paths(self) -> None:
        document = self.valid_document()
        with tempfile.TemporaryDirectory() as temp_name:
            folder = Path(temp_name)
            backup = self.write(folder, document)
            store_path = folder / "library.sqlite3"
            exported = folder / "exported.json"
            raw = backup.read_bytes()

            creation = NodeStore.create_from_backup(backup, store_path, now=1_800_000_000.0)
            current = NodeStore(store_path).read_library()
            NodeStore(store_path).export_current(exported)
            served, served_raw = _read_backup(backup)

            self.assertEqual(current.raw, raw)
            self.assertEqual(exported.read_bytes(), raw)
            self.assertEqual(served_raw, raw)
            self.assertEqual(creation["import"]["sha256"], hashlib.sha256(raw).hexdigest())
            self.assertEqual(
                current.document["state"]["collections"][0]["members"][0]["reason"],
                "Alpha reason.\nSecond line.",
            )
            self.assertEqual(
                served["state"]["collections"][1]["members"][0]["reason"],
                "سبب مختلف للمجلد.",
            )
            self.assertNotIn("reason", current.document["state"]["collections"][0]["members"][1])

    def test_both_node_ingress_paths_refuse_all_malformed_source_note_forms_before_storage(self) -> None:
        with tempfile.TemporaryDirectory() as temp_name:
            folder = Path(temp_name)
            for index, (label, document) in enumerate(self.malformed_documents()):
                with self.subTest(label=label):
                    backup = self.write(folder, document, f"{index}-{label}.json")
                    store_path = folder / f"{index}-{label}.sqlite3"
                    with self.assertRaisesRegex(NodeStoreError, "invalid Source Notes"):
                        NodeStore.create_from_backup(backup, store_path, now=1_800_000_000.0)
                    self.assertFalse(store_path.exists(), label)
                    with self.assertRaisesRegex(NodeError, "invalid Source Notes"):
                        _read_backup(backup)
                    with self.assertRaises(progrss.ProgRSSError):
                        progrss.load_backup(backup)

    def test_node_store_refuses_a_digest_consistent_malformed_library_on_reopen(self) -> None:
        document = self.valid_document()
        with tempfile.TemporaryDirectory() as temp_name:
            folder = Path(temp_name)
            backup = self.write(folder, document)
            store_path = folder / "library.sqlite3"
            NodeStore.create_from_backup(backup, store_path, now=1_800_000_000.0)

            malformed = copy.deepcopy(document)
            malformed["state"]["collections"][0]["members"][0]["reason"] = "x" * 281
            raw = (json.dumps(malformed, ensure_ascii=True, separators=(",", ":")) + "\n").encode("utf-8")
            digest = hashlib.sha256(raw).hexdigest()
            connection = sqlite3.connect(store_path)
            try:
                connection.execute(
                    "UPDATE library SET document_json=?, sha256=? WHERE singleton=1",
                    (raw, digest),
                )
                connection.commit()
            finally:
                connection.close()

            with self.assertRaisesRegex(NodeStoreError, "stored Node library has invalid Source Notes"):
                NodeStore(store_path)

    def test_shipped_node_init_refuses_malformed_input_before_creating_output(self) -> None:
        document = self.valid_document()
        document["state"]["collections"][0]["members"][0]["reason"] = "x" * 281
        with tempfile.TemporaryDirectory() as temp_name:
            folder = Path(temp_name)
            backup = self.write(folder, document)
            store_path = folder / "library.sqlite3"
            completed = subprocess.run(
                [sys.executable, str(CLI_DIR / "progrss.py"), "node", "init", str(backup), "--output", str(store_path), "--json"],
                cwd=CLI_DIR, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False,
            )
            self.assertEqual(completed.returncode, 2)
            self.assertIn("invalid Source Notes", completed.stderr)
            self.assertFalse(store_path.exists())

    def test_shared_native_audit_reports_the_exact_valid_reason_count(self) -> None:
        document = self.valid_document()
        self.assertEqual(progrss.validate_private_source_note_placements(document["state"]), 2)


if __name__ == "__main__":
    unittest.main()
