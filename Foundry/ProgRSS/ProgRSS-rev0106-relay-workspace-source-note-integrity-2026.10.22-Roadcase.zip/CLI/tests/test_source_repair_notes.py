from __future__ import annotations

import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve()
CLI_DIR = HERE.parents[1]
sys.path.insert(0, str(CLI_DIR))

import progrss


class SourceRepairNoteTests(unittest.TestCase):
    def state(self, members: list[dict], extra_collections: list[dict] | None = None) -> dict:
        return {
            "version": 17,
            "sources": [
                {"id": "first", "title": "First history", "type": "rss", "url": "https://same.example/feed.xml", "enabled": False, "archivedAt": ""},
                {"id": "second", "title": "Second history", "type": "rss", "url": "https://same.example/feed.xml", "enabled": False, "archivedAt": ""},
            ],
            "items": [],
            "collections": [
                {"id": "reading", "title": "Reading", "mode": "union", "version": 1, "members": copy.deepcopy(members)},
                *(copy.deepcopy(extra_collections) if extra_collections else []),
            ],
            "snapshots": {},
            "receipts": [],
            "retiredReceipts": [],
        }

    @staticmethod
    def placement(source_id: str, reason: str | None = None, *, present: bool = True) -> dict:
        row = {"kind": "source", "id": source_id}
        if present:
            row["reason"] = reason
        return row

    def test_divergent_reason_refuses_before_mutation_for_both_orders_and_survivors(self) -> None:
        for order in (("first", "second"), ("second", "first")):
            for survivor in ("first", "second"):
                reasons = {"first": "First distinct reason.", "second": "Second distinct reason."}
                state = self.state([self.placement(source_id, reasons[source_id]) for source_id in order])
                before = copy.deepcopy(state)
                first, second = state["sources"]
                blocked = progrss.source_repair_blockers(state, first, second)
                self.assertTrue(blocked["blockers"])
                self.assertEqual(blocked["placementConflicts"][0]["kind"], "divergent-reasons")
                self.assertIn("will not choose a reason automatically", blocked["blockers"][0])
                with self.assertRaisesRegex(progrss.ProgRSSError, "will not choose a reason automatically"):
                    progrss.apply_source_repair(state, survivor, "second" if survivor == "first" else "first")
                self.assertEqual(state, before)

    def test_unambiguous_reason_is_preserved_independent_of_order_and_survivor(self) -> None:
        for order in (("first", "second"), ("second", "first")):
            for survivor in ("first", "second"):
                rows = {
                    "first": self.placement("first", "Only meaningful reason."),
                    "second": self.placement("second", present=False),
                }
                state = self.state([rows[source_id] for source_id in order])
                first, second = state["sources"]
                self.assertEqual(progrss.source_repair_blockers(state, first, second)["blockers"], [])
                progrss.apply_source_repair(state, survivor, "second" if survivor == "first" else "first", "2026-10-21T12:00:00Z")
                self.assertEqual(state["collections"][0]["members"], [
                    {"kind": "source", "id": survivor, "reason": "Only meaningful reason."}
                ])

    def test_identical_absent_and_separate_folder_reasons(self) -> None:
        state = self.state([
            self.placement("first", "Same reason."),
            self.placement("second", "Same reason."),
        ])
        progrss.apply_source_repair(state, "second", "first", "2026-10-21T12:00:00Z")
        self.assertEqual(state["collections"][0]["members"], [
            {"kind": "source", "id": "second", "reason": "Same reason."}
        ])

        state = self.state([
            self.placement("first", present=False),
            self.placement("second", present=False),
        ])
        progrss.apply_source_repair(state, "first", "second", "2026-10-21T12:00:00Z")
        self.assertEqual(state["collections"][0]["members"], [{"kind": "source", "id": "first"}])

        state = self.state(
            [self.placement("first", "Reason for Reading.")],
            [{"id": "archive", "title": "Archive", "mode": "union", "version": 1,
              "members": [self.placement("second", "Reason for Archive.")]}],
        )
        progrss.apply_source_repair(state, "second", "first", "2026-10-21T12:00:00Z")
        self.assertEqual(state["collections"][0]["members"], [
            {"kind": "source", "id": "second", "reason": "Reason for Reading."}
        ])
        self.assertEqual(state["collections"][1]["members"], [
            {"kind": "source", "id": "second", "reason": "Reason for Archive."}
        ])

    def test_malformed_reason_is_a_blocking_placement_conflict(self) -> None:
        state = self.state([
            self.placement("first", "\ud800"),
            self.placement("second", present=False),
        ])
        plan = progrss.source_repair_placement_plan(state, "first", "second")
        self.assertEqual(plan["conflicts"][0]["kind"], "invalid-reason")
        self.assertIn("Unicode scalar", plan["conflicts"][0]["message"])

    def test_cli_reports_conflict_refuses_output_and_preserves_one_sided_reason(self) -> None:
        fixture = json.loads((CLI_DIR / "fixtures" / "sample-backup.json").read_text(encoding="utf-8"))
        fixture["state"]["sources"].append({
            "id": "feed-copy", "title": "Existing Feed copy", "type": "rss",
            "url": "https://existing.test/alternate.xml", "declaredFeedUrl": "https://existing.test/feed.xml",
            "enabled": False, "archivedAt": "",
        })
        fixture["state"]["collections"] = [{
            "id": "reading", "title": "Reading", "mode": "union", "version": 1,
            "members": [
                {"kind": "source", "id": "feed-existing", "reason": "First distinct reason."},
                {"kind": "source", "id": "feed-copy", "reason": "Second distinct reason."},
            ],
        }]
        with tempfile.TemporaryDirectory() as temp_name:
            temp = Path(temp_name)
            source = temp / "private.json"
            blocked_output = temp / "blocked.json"
            source.write_text(json.dumps(fixture), encoding="utf-8")
            audit = subprocess.run(
                [str(CLI_DIR / "progrss"), "workspace", "duplicate-sources", str(source), "--json"],
                cwd=CLI_DIR, text=True, capture_output=True,
            )
            self.assertEqual(audit.returncode, 0, audit.stderr)
            report = json.loads(audit.stdout)
            self.assertFalse(report["pairs"][0]["canCombine"])
            self.assertEqual(report["pairs"][0]["placementConflicts"][0]["kind"], "divergent-reasons")
            refused = subprocess.run(
                [str(CLI_DIR / "progrss"), "workspace", "combine-sources", str(source),
                 "feed-existing", "feed-copy", "--keep", "feed-copy", "--output", str(blocked_output)],
                cwd=CLI_DIR, text=True, capture_output=True,
            )
            self.assertEqual(refused.returncode, 2)
            self.assertIn("will not choose a reason automatically", refused.stderr)
            self.assertFalse(blocked_output.exists())

            fixture["state"]["collections"][0]["members"][1].pop("reason")
            source.write_text(json.dumps(fixture), encoding="utf-8")
            output = temp / "combined.json"
            accepted = subprocess.run(
                [str(CLI_DIR / "progrss"), "workspace", "combine-sources", str(source),
                 "feed-existing", "feed-copy", "--keep", "feed-copy", "--output", str(output)],
                cwd=CLI_DIR, text=True, capture_output=True,
            )
            self.assertEqual(accepted.returncode, 0, accepted.stderr)
            result = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(result["state"]["collections"][0]["members"], [
                {"kind": "source", "id": "feed-copy", "reason": "First distinct reason."}
            ])


if __name__ == "__main__":
    unittest.main()
