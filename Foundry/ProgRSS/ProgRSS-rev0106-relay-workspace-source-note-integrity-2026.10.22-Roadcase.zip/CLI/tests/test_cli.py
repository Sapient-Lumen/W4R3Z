from __future__ import annotations

import argparse
import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("progrss_cli", ROOT / "progrss.py")
assert SPEC and SPEC.loader
cli = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(cli)
FIXTURES = ROOT / "fixtures"


class FeedTests(unittest.TestCase):
    def test_rss_parse(self) -> None:
        parsed = cli.parse_feed((FIXTURES / "sample-rss.xml").read_bytes(), "https://example.test/feed.xml")
        self.assertEqual(parsed["type"], "rss")
        self.assertEqual(parsed["title"], "Garden Notes")
        self.assertEqual(len(parsed["items"]), 2)
        self.assertEqual(parsed["items"][1]["url"], "https://example.test/posts/autumn-planting")
        self.assertEqual(parsed["items"][0]["summary"], "Neighbors can borrow seeds.")

    def test_atom_parse(self) -> None:
        parsed = cli.parse_feed((FIXTURES / "sample-atom.xml").read_bytes(), "https://example.test/workshop/feed.atom")
        self.assertEqual(parsed["type"], "atom")
        self.assertEqual(parsed["items"][0]["url"], "https://example.test/workshop/repair-cafe")
        self.assertEqual(parsed["items"][0]["key"], "tag:example.test,2026:repair-cafe")

    def test_json_feed_parse(self) -> None:
        parsed = cli.parse_feed((FIXTURES / "sample-json-feed.json").read_bytes(), "https://example.test/library/feed.json")
        self.assertEqual(parsed["type"], "json")
        self.assertEqual(parsed["items"][0]["key"], "dispatch-7")

    def test_compact_feed_preview_excludes_retained_text(self) -> None:
        parsed = cli.parse_feed(
            (FIXTURES / "interoperability" / "json-full-content.json").read_bytes(),
            "https://json-full.example/feed.json",
        )
        report = cli.compact_feed_preview(parsed, "https://json-full.example/feed.json", 3)
        self.assertEqual(report["schema"], "progrss.feed.preview.v1")
        self.assertEqual(report["exampleCount"], 1)
        self.assertEqual(report["fullTextCount"], 1)
        self.assertEqual(report["examples"][0]["content"], "full-text")
        self.assertEqual(set(report["examples"][0]), {"title", "url", "published", "content", "language", "titleLanguage"})
        self.assertNotIn("body", report["examples"][0])
        self.assertNotIn("summary", report["examples"][0])
        self.assertFalse(report["network"])
        self.assertFalse(report["writes"])

    def test_folder_edition_preview_names_one_summary_feed(self) -> None:
        edition = {
            "version": cli.JSON_FEED_VERSION,
            "title": "Neighborhood recent updates",
            "items": [{
                "id": "https://example.test/posts/one",
                "title": "One update",
                "content_text": "A bounded public summary.",
                "summary": "A bounded public summary.",
                "url": "https://example.test/posts/one",
                "_progrss": {"sourceCount": 1, "sources": [{"title": "Town desk", "type": "feed"}]},
            }],
            "_progrss": {
                "schema": cli.FOLDER_EDITION_SCHEMA,
                "generatedAt": "2026-10-19T16:00:00Z",
                "folder": "Neighborhood",
                "folderSourceCount": 1,
                "representedSourceCount": 1,
                "itemCount": 1,
                "omittedByLimit": 0,
                "included": {
                    "titles": True, "shortSummaries": True, "links": True,
                    "dates": True, "languages": True, "sourceLabels": True,
                },
                "excluded": {
                    "fullRetainedText": True, "readingState": True, "savedState": True,
                    "pageWatchEvidence": True, "snapshots": True,
                    "browserAuthority": True, "privateKeys": True,
                },
            },
        }
        parsed = cli.parse_feed(json.dumps(edition).encode("utf-8"), "https://example.test/recent-updates.json")
        report = cli.compact_feed_preview(parsed, "https://example.test/recent-updates.json", 3)
        self.assertEqual(report["edition"]["schema"], cli.FOLDER_EDITION_SCHEMA)
        self.assertEqual(report["edition"]["folder"], "Neighborhood")
        self.assertEqual(report["edition"]["itemCount"], 1)
        self.assertNotIn("summary", report["examples"][0])
        self.assertNotIn("body", report["examples"][0])

    def test_dtd_refused(self) -> None:
        raw = b'<!DOCTYPE rss [<!ENTITY x "boom">]><rss><channel><title>&x;</title></channel></rss>'
        with self.assertRaisesRegex(cli.ProgRSSError, "DTD"):
            cli.parse_feed(raw, "https://example.test/feed.xml")

    def test_duplicate_json_key_refused(self) -> None:
        raw = b'{"version":"https://jsonfeed.org/version/1.1","title":"a","title":"b","items":[]}'
        with self.assertRaisesRegex(cli.ProgRSSError, "duplicate JSON key"):
            cli.parse_feed(raw, "https://example.test/feed.json")

    def test_credential_url_refused(self) -> None:
        with self.assertRaisesRegex(cli.ProgRSSError, "credential"):
            cli.safe_http_url("https://user:secret@example.test/feed")

    def test_opml_parse_nested_deduped_and_bounded(self) -> None:
        parsed = cli.parse_opml((FIXTURES / "sample-subscriptions.opml").read_bytes())
        self.assertEqual(parsed["title"], "Sample subscriptions")
        self.assertEqual([row["url"] for row in parsed["feeds"]], [
            "https://existing.test/feed.xml",
            "https://garden.test/feed.xml",
            "https://workshop.test/atom.xml",
        ])
        self.assertEqual(parsed["feedOutlines"], 6)
        self.assertEqual(parsed["duplicateCount"], 1)
        self.assertEqual(parsed["invalidCount"], 2)
        self.assertEqual(parsed["folderCount"], 3)
        garden = parsed["feeds"][1]
        self.assertEqual(garden["folderPaths"], [["Independent"], ["News"]])

    def test_opml_dtd_refused(self) -> None:
        raw = b'<!DOCTYPE opml [<!ENTITY x "boom">]><opml version="2.0"><body><outline text="&x;"/></body></opml>'
        with self.assertRaisesRegex(cli.ProgRSSError, "DTD"):
            cli.parse_opml(raw)

    def test_local_interoperability_corpus(self) -> None:
        report = cli.run_corpus(FIXTURES / "interoperability")
        self.assertEqual(report["schema"], "progrss.feed.corpus.result.v1")
        self.assertEqual(report["total"], 32)
        self.assertEqual(report["passed"], 32)
        self.assertEqual(report["failed"], 0)
        self.assertFalse(report["network"])
        self.assertFalse(report["writes"])
        rdf = next(row for row in report["cases"] if row["id"] == "rss1-rdf")
        self.assertEqual(rdf["actual"]["title"], "RDF Chronicle")
        atom = next(row for row in report["cases"] if row["id"] == "atom-relative-base")
        self.assertEqual(atom["actual"]["firstUrl"], "https://atom.example/base/journal/posts/one")
        self_link = next(row for row in report["cases"] if row["id"] == "atom-self-link")
        self.assertEqual(self_link["actual"]["feedUrl"], "https://atom-self.example/feeds/daily.atom")
        for identity in ("json-full-content", "atom-full-content", "rss-content-encoded"):
            full = next(row for row in report["cases"] if row["id"] == identity)
            self.assertFalse(full["actual"]["firstBodyIsSummary"])
            self.assertNotIn("steal-me", full["actual"]["firstBody"])
            self.assertNotIn("remote-only", full["actual"]["firstBody"])
        json_language = next(row for row in report["cases"] if row["id"] == "json-language")
        self.assertEqual(json_language["actual"]["language"], "ar")
        self.assertEqual(json_language["actual"]["firstLanguage"], "fa")
        atom_language = next(row for row in report["cases"] if row["id"] == "atom-language")
        self.assertEqual(atom_language["actual"]["firstTitleLanguage"], "en")
        self.assertEqual(atom_language["actual"]["firstBodyLanguage"], "ar")
        rss_language = next(row for row in report["cases"] if row["id"] == "rss-language")
        self.assertEqual(rss_language["actual"]["language"], "fa-ir")
        self.assertEqual(rss_language["actual"]["firstSummaryLanguage"], "ar")
        whitespace = next(row for row in report["cases"] if row["id"] == "json-whitespace")
        self.assertEqual(whitespace["actual"]["firstBody"], "First line with spaces.\n\nSecond paragraph.\nThird line.")

    def test_language_only_enrichment_does_not_create_a_new_event(self) -> None:
        state = {"items": [{
            "id": "source|entry", "entryKey": "source|entry", "feedRevision": 0,
            "sourceId": "source", "title": "A note", "url": "https://example.test/note",
            "summary": "Same text", "body": "Same text", "bodyIsSummary": True,
            "published": "", "observedAt": "2026-10-18T00:00:00Z", "kind": "new",
        }]}
        parsed = {"items": [{
            "key": "entry", "title": "A note", "url": "https://example.test/note",
            "summary": "Same text", "body": "Same text", "bodyIsSummary": True,
            "language": "AR", "titleLanguage": "EN", "summaryLanguage": "AR", "bodyLanguage": "AR",
            "published": "",
        }]}
        events = cli.ingest_feed(state, {"id": "source"}, parsed)
        self.assertEqual(events, 0)
        self.assertEqual(len(state["items"]), 1)
        self.assertEqual(state["items"][0]["language"], "ar")
        self.assertEqual(state["items"][0]["titleLanguage"], "en")

    def test_summary_retention_omits_and_later_enriches_without_event(self) -> None:
        parsed = {"items": [{
            "key": "entry", "title": "A note", "url": "https://example.test/note",
            "summary": "Short summary", "body": "Longer full text supplied by the feed.",
            "bodyIsSummary": False, "language": "EN", "summaryLanguage": "EN", "bodyLanguage": "EN",
            "published": "",
        }]}
        state = {"items": []}
        events = cli.ingest_feed(state, {"id": "source", "textRetention": "summary"}, parsed)
        self.assertEqual(events, 1)
        self.assertEqual(state["items"][0]["body"], "Short summary")
        self.assertTrue(state["items"][0]["bodyIsSummary"])
        self.assertTrue(state["items"][0]["bodyOmitted"])
        events = cli.ingest_feed(state, {"id": "source"}, parsed)
        self.assertEqual(events, 0)
        self.assertEqual(state["items"][0]["body"], "Longer full text supplied by the feed.")
        self.assertFalse(state["items"][0]["bodyIsSummary"])
        self.assertNotIn("bodyOmitted", state["items"][0])

    def test_declared_feed_url_is_trusted_only_on_the_fetched_origin(self) -> None:
        self.assertEqual(
            cli.same_origin_feed_url("/primary.xml", "https://example.test/alternate.xml"),
            "https://example.test/primary.xml",
        )
        self.assertEqual(
            cli.same_origin_feed_url("https://other.test/feed.xml", "https://example.test/alternate.xml"),
            "",
        )


class WorkspaceTests(unittest.TestCase):
    def load(self):
        return cli.load_backup(FIXTURES / "sample-backup.json")

    def test_backup_audit_and_counts(self) -> None:
        _wrapper, state = self.load()
        report = cli.state_audit(state)
        self.assertEqual(report["state"], "valid")
        self.assertEqual(report["counts"], {"sources": 2, "collections": 0, "items": 2})
        self.assertEqual(len(cli.vault_content_digest(state)), 64)

    def test_site_access_plan_is_offline_private_and_status_specific(self) -> None:
        state = {
            "version": 17,
            "sources": [
                {"id": "following", "title": "Following", "type": "rss", "url": "https://one.test/feed", "enabled": True},
                {"id": "paused", "title": "Paused", "type": "rss", "url": "https://two.test/feed", "enabled": False},
                {"id": "moved", "title": "Moved", "type": "rss", "url": "https://old.test/feed", "enabled": True,
                 "pendingRedirect": {"from": "https://old.test/feed", "to": "https://new.test/feed"}},
                {"id": "reconnect", "title": "Reconnect", "type": "rss", "url": "https://reconnect.test/feed", "enabled": True,
                 "permissionMissing": True},
                {"id": "repair", "title": "Repair", "type": "page", "url": "https://repair.test/", "enabled": True,
                 "watchRepair": {"reason": "no-match", "message": "Missing"}},
                {"id": "steady", "title": "Steady", "type": "page", "url": "https://steady.test/", "enabled": True,
                 "watchStability": {"reason": "text-size-shift", "message": "Held", "observations": 1}},
                {"id": "archived", "title": "Archived", "type": "rss", "url": "https://archive.test/feed", "enabled": False,
                 "archivedAt": "2026-10-19T00:00:00Z"},
            ],
            "collections": [], "items": [], "snapshots": {},
        }
        report = cli.workspace_access_plan(state)
        self.assertEqual(report["schema"], "progrss.workspace.access-plan.v1")
        self.assertEqual(report["sourceCount"], 7)
        self.assertEqual(report["distinctSiteCount"], 8)
        self.assertEqual(report["summary"]["scheduledCheckEligible"], 2)
        self.assertFalse(report["originsIncluded"])
        self.assertFalse(report["network"])
        self.assertFalse(report["writes"])
        self.assertFalse(report["browserProfileRead"])
        self.assertFalse(report["permissionsRead"])
        self.assertTrue(all("origins" not in row for row in report["sources"]))
        by_id = {row["id"]: row for row in report["sources"]}
        self.assertEqual(by_id["steady"]["visibleControl"], "Check again")
        self.assertIn("no alert", by_id["steady"]["notGrantedResult"].lower())
        self.assertEqual(by_id["moved"]["siteCount"], 2)
        self.assertIn("destination is not contacted", by_id["moved"]["notGrantedResult"])
        self.assertEqual(by_id["reconnect"]["nextAction"], "Reconnect and check in the Extension")
        self.assertEqual(by_id["archived"]["siteAccessDecision"], "none-while-archived")

        revealed = cli.workspace_access_plan(state, "moved", show_origins=True)
        self.assertEqual(revealed["sourceCount"], 1)
        self.assertEqual(revealed["sources"][0]["origins"], ["https://old.test", "https://new.test"])
        self.assertTrue(revealed["originsIncluded"])

    def test_page_watch_repair_review_and_new_file_transaction(self) -> None:
        html_specimen = b"""<!doctype html><html><body><main><h1>Notices</h1>
        <article><h2><a href='/one'>First notice</a></h2><p>Alpha details</p></article>
        <article><h2><a href='/two'>Second notice</a></h2><p>Beta details</p></article>
        <article><h2><a href='/three'>Third notice</a></h2><p>Gamma details</p></article>
        </main></body></html>"""
        with tempfile.TemporaryDirectory() as temp_dir:
            backup_path = Path(temp_dir) / "watch.json"
            html_path = Path(temp_dir) / "watch.html"
            output_path = Path(temp_dir) / "repaired.json"
            document = json.loads((FIXTURES / "sample-backup.json").read_text())
            document["state"]["sources"].append({
                "id": "page-watch", "type": "page", "title": "Town notices",
                "url": "https://example.test/notices", "enabled": True,
                "mode": "cards", "selector": ".old-list", "titleSelector": "h2", "linkSelector": "a[href]",
                "threshold": 4, "ignoreNumbers": False, "version": 1,
                "watchRepair": {"schema": "progrss.page-watch.repair.v1", "reason": "no-match", "noticedAt": "2026-10-19T00:00:00Z", "message": "Missing"},
                "lastError": "Missing",
            })
            document["state"]["items"].append({
                "id": "old-page-alert", "sourceId": "page-watch", "title": "Earlier alert",
                "summary": "Old page evidence", "observedAt": "2026-10-18T00:00:00Z",
            })
            document["state"]["snapshots"]["page-watch"] = {
                "mode": "cards", "keys": ["old"],
                "entries": [{"key": "old", "title": "Old", "summary": "Old", "url": ""}],
                "capturedAt": "2026-10-18T00:00:00Z",
            }
            document["state"]["pageWatchRepairUndo"] = {"expiresAt": "2099-01-01T00:00:00Z"}
            backup_path.write_text(json.dumps(document), encoding="utf-8")
            html_path.write_bytes(html_specimen)

            _wrapper, state = cli.load_backup(backup_path)
            source = cli.resolve_source_for_storage(state, "page-watch")
            proposals = cli.page_watch_repair_proposals(html_specimen, source)
            self.assertEqual([row["mode"] for row in proposals], ["cards", "region"])
            self.assertEqual(proposals[0]["count"], 3)
            self.assertEqual(proposals[0]["examples"], ["First notice", "Second notice", "Third notice"])
            self.assertEqual(len({row["id"] for row in proposals}), len(proposals))

            report = cli.page_watch_repair_report(state, source, html_specimen)
            self.assertEqual(report["schema"], "progrss.page-watch.repair-review.v1")
            self.assertFalse(report["network"])
            self.assertFalse(report["writes"])

            args = argparse.Namespace(
                backup=str(backup_path), source="page-watch", html=str(html_path),
                proposal=proposals[0]["id"], output=str(output_path),
            )
            self.assertEqual(cli.cmd_workspace_repair_page_watch(args), 0)
            repaired = json.loads(output_path.read_text())
            repaired_source = next(row for row in repaired["state"]["sources"] if row["id"] == "page-watch")
            self.assertEqual(repaired_source["selector"], "main article")
            self.assertEqual(repaired_source["lastOutcome"], "baseline")
            self.assertNotIn("watchRepair", repaired_source)
            self.assertEqual(repaired_source["watchHealth"]["reason"], "baseline")
            self.assertTrue(any(row["id"] == "old-page-alert" for row in repaired["state"]["items"]))
            self.assertEqual(len([row for row in repaired["state"]["items"] if row.get("sourceId") == "page-watch"]), 1)
            self.assertEqual(len(repaired["state"]["snapshots"]["page-watch"]["entries"]), 3)
            self.assertNotIn("pageWatchRepairUndo", repaired["state"])
            with self.assertRaisesRegex(cli.ProgRSSError, "already exists"):
                cli.cmd_workspace_repair_page_watch(args)

    def test_page_watch_stability_assessment_holds_confirms_and_stays_read_only(self) -> None:
        baseline = " ".join(["baseline"] * 90)
        first_html = ("<main>" + " ".join(["changed"] * 18) + "</main>").encode()
        second_html = ("<main>" + " ".join(["changed"] * 20) + "</main>").encode()
        returned_html = ("<main>" + " ".join(["baseline"] * 88) + "</main>").encode()
        _wrapper, state = self.load()
        source = {
            "id": "steady-watch", "type": "page", "title": "Steady page",
            "url": "https://example.test/steady", "enabled": True,
            "mode": "region", "selector": "main", "version": 4,
        }
        state["sources"].append(source)
        state["snapshots"]["steady-watch"] = {
            "mode": "region", "text": baseline, "capturedAt": "2026-10-18T00:00:00Z",
        }
        before = json.dumps(state, ensure_ascii=False, sort_keys=True)

        held = cli.page_watch_assessment_report(state, source, first_html)
        self.assertEqual(held["schema"], "progrss.page-watch.assessment.v1")
        self.assertEqual(held["result"], "hold")
        self.assertEqual(held["observations"][0]["decision"]["action"], "hold")
        self.assertEqual(held["pageAlertsWritten"], 0)
        self.assertFalse(held["snapshotChanged"])

        confirmed = cli.page_watch_assessment_report(state, source, first_html, second_html)
        self.assertEqual(confirmed["result"], "confirmed-new-shape")
        self.assertEqual([row["decision"]["action"] for row in confirmed["observations"]], ["hold", "accept"])
        self.assertEqual(confirmed["observations"][-1]["decision"]["health"]["reason"], "confirmed-shape-change")

        recovered = cli.page_watch_assessment_report(state, source, first_html, returned_html)
        self.assertEqual(recovered["result"], "returned-to-steady")
        self.assertEqual(recovered["observations"][-1]["decision"]["health"]["reason"], "returned-to-steady")
        self.assertEqual(json.dumps(state, ensure_ascii=False, sort_keys=True), before)

        source["watchStability"] = {
            "schema": "progrss.page-watch.stability.v1", "status": "pending",
            "reason": "text-size-shift", "recipeVersion": 4, "observations": 1,
        }
        portable = cli.portable_state(copy.deepcopy(state))
        portable_source = next(row for row in portable["sources"] if row["id"] == "steady-watch")
        self.assertNotIn("watchStability", portable_source)

        first_pending = cli.page_watch_stability_decision(None, {
            "schema": cli.PAGE_WATCH_HEALTH_SCHEMA, "status": "changed-shape",
            "reason": "text-size-shift", "checkedAt": "2026-10-19T01:00:00Z",
            "message": "first", "metrics": {"previousCharacters": 500, "currentCharacters": 100, "matchCount": 1},
        }, source)
        mixed_pending = cli.page_watch_stability_decision(first_pending["stability"], {
            "schema": cli.PAGE_WATCH_HEALTH_SCHEMA, "status": "changed-shape",
            "reason": "entry-count-shift", "checkedAt": "2026-10-19T01:05:00Z",
            "message": "second", "metrics": {"previousEntries": 10, "currentEntries": 25, "matchCount": 25},
        }, source)
        self.assertEqual(mixed_pending["action"], "hold")
        self.assertEqual(mixed_pending["stability"]["observations"], 2)
        alternating_third = cli.page_watch_stability_decision(mixed_pending["stability"], {
            "schema": cli.PAGE_WATCH_HEALTH_SCHEMA, "status": "changed-shape",
            "reason": "text-size-shift", "checkedAt": "2026-10-19T01:10:00Z",
            "message": "third", "metrics": {"previousCharacters": 500, "currentCharacters": 120, "matchCount": 1},
        }, source)
        self.assertEqual(alternating_third["action"], "repair")

    def test_recovery_copy_is_validated_private_and_new_file_only(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            source_path = Path(temp_dir) / "source.json"
            output_path = Path(temp_dir) / "recovery.json"
            document = json.loads((FIXTURES / "sample-backup.json").read_text())
            document["state"]["_revision"] = 42
            document["state"]["transferUndo"] = {"expiresAt": "2099-01-01T00:00:00Z"}
            document["state"]["sourceRepairUndo"] = {"expiresAt": "2099-01-01T00:00:00Z"}
            document["state"]["receiptRetirementUndo"] = {"expiresAt": "2099-01-01T00:00:00Z"}
            source_path.write_text(json.dumps(document))

            _wrapper, state = cli.load_backup(source_path)
            report = cli.recovery_copy_report(state)
            self.assertEqual(report["schema"], "progrss.workspace.recovery-copy.v1")
            self.assertEqual(report["counts"]["sources"], 2)
            self.assertEqual(report["audit"]["state"], "valid")
            self.assertTrue(report["privatePlaintext"])
            self.assertFalse(report["network"])
            self.assertFalse(report["browserProfileRead"])

            args = argparse.Namespace(backup=str(source_path), output=str(output_path))
            self.assertEqual(cli.cmd_workspace_recovery_copy(args), 0)
            result = json.loads(output_path.read_text())
            self.assertEqual(result["schema"], "progrss.private.v1")
            self.assertEqual(result["purpose"], "recovery-copy")
            self.assertEqual(result["producer"], {"name": "ProgRSS", "version": "0.80.0", "revision": "rev0080"})
            self.assertEqual(result["state"]["version"], 17)
            for key in ("_revision", "transferUndo", "sourceRepairUndo", "receiptRetirementUndo", "pageWatchRepairUndo"):
                self.assertNotIn(key, result["state"])
            with self.assertRaisesRegex(cli.ProgRSSError, "already exists"):
                cli.cmd_workspace_recovery_copy(args)

            invalid_path = Path(temp_dir) / "invalid.json"
            invalid_output = Path(temp_dir) / "invalid-recovery.json"
            invalid = json.loads((FIXTURES / "sample-backup.json").read_text())
            invalid["state"]["sources"].append(dict(invalid["state"]["sources"][0]))
            invalid_path.write_text(json.dumps(invalid))
            with self.assertRaisesRegex(cli.ProgRSSError, "backup audit failed"):
                cli.cmd_workspace_recovery_copy(argparse.Namespace(backup=str(invalid_path), output=str(invalid_output)))
            self.assertFalse(invalid_output.exists())

            corrupt_output = Path(temp_dir) / "corrupt-recovery.json"
            real_write_new = cli.write_new

            def corrupt_after_write(path: Path, data: bytes) -> None:
                real_write_new(path, data)
                Path(path).write_text("{}", encoding="utf-8")

            with mock.patch.object(cli, "write_new", side_effect=corrupt_after_write):
                with self.assertRaisesRegex(cli.ProgRSSError, "failed its local read-back check"):
                    cli.cmd_workspace_recovery_copy(
                        argparse.Namespace(backup=str(source_path), output=str(corrupt_output))
                    )
            self.assertFalse(corrupt_output.exists(), "a failed read-back check removes the misleading output")

    def test_compare_private_copies_is_read_only_and_does_not_expose_addresses(self) -> None:
        first_wrapper, first_state = self.load()
        same = cli.compare_private_copies_report(first_wrapper, first_state, first_wrapper, first_state)
        self.assertEqual(same["schema"], "progrss.workspace.copy-comparison.v1")
        self.assertEqual(same["state"], "same")
        self.assertTrue(same["samePortableLibrary"])
        self.assertFalse(same["network"])
        self.assertFalse(same["writes"])
        self.assertFalse(same["browserProfileRead"])

        second_wrapper = json.loads(json.dumps(first_wrapper))
        second_state = second_wrapper["state"]
        second_state["sources"][0]["title"] = "Renamed locally"
        second_state["items"].append({
            "id": "feed-existing|later", "sourceId": "feed-existing",
            "title": "Later update", "url": "https://example.test/later",
            "summary": "A later retained update", "observedAt": "2026-10-18T12:00:00Z",
            "readAt": "", "starred": False,
        })
        second_wrapper["exportedAt"] = "2026-10-18T12:01:00Z"
        different = cli.compare_private_copies_report(first_wrapper, first_state, second_wrapper, second_state)
        self.assertEqual(different["state"], "different")
        self.assertFalse(different["samePortableLibrary"])
        self.assertEqual(different["changes"]["sources"]["changed"], 1)
        self.assertEqual(different["changes"]["items"]["added"], 1)
        self.assertEqual(different["countDeltas"]["items"], 1)
        encoded = json.dumps(different)
        self.assertNotIn("https://example.test/feed.xml", encoded)
        self.assertNotIn("Existing Feed", encoded)

    def test_text_storage_report_and_new_file_retention_transaction(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            source_path = Path(temp_dir) / "source.json"
            trimmed_path = Path(temp_dir) / "trimmed.json"
            full_path = Path(temp_dir) / "full.json"
            document = json.loads((FIXTURES / "sample-backup.json").read_text())
            document["state"]["items"][0].update({
                "body": "Long full text for a read item.", "bodyIsSummary": False, "starred": False,
            })
            document["state"]["items"][1].update({
                "body": "Saved full text that must remain.", "bodyIsSummary": False,
            })
            source_path.write_text(json.dumps(document))
            _wrapper, state = cli.load_backup(source_path)
            report = cli.workspace_text_storage_report(state)
            self.assertEqual(report["schema"], "progrss.workspace.text-storage.v1")
            self.assertEqual(report["fullTextItems"], 2)
            self.assertEqual(report["cleanupEligibleItems"], 1)
            self.assertGreater(report["cleanupEligibleBytes"], 0)
            self.assertFalse(report["network"])
            self.assertFalse(report["writes"])

            args = argparse.Namespace(
                backup=str(source_path), source="Existing Feed", mode="summary",
                trim_read=True, output=str(trimmed_path),
            )
            self.assertEqual(cli.cmd_workspace_set_text_retention(args), 0)
            trimmed = json.loads(trimmed_path.read_text())
            self.assertEqual(trimmed["state"]["version"], 17)
            source = next(row for row in trimmed["state"]["sources"] if row["id"] == "feed-existing")
            self.assertEqual(source["textRetention"], "summary")
            items = {row["title"]: row for row in trimmed["state"]["items"]}
            self.assertEqual(items["Already read"]["body"], items["Already read"]["summary"])
            self.assertTrue(items["Already read"]["bodyIsSummary"])
            self.assertTrue(items["Already read"]["bodyOmitted"])
            self.assertEqual(items["Unread and saved"]["body"], "Saved full text that must remain.")
            self.assertNotIn("bodyOmitted", items["Unread and saved"])

            restore = argparse.Namespace(
                backup=str(trimmed_path), source="feed-existing", mode="full",
                trim_read=False, output=str(full_path),
            )
            self.assertEqual(cli.cmd_workspace_set_text_retention(restore), 0)
            full = json.loads(full_path.read_text())
            restored_source = next(row for row in full["state"]["sources"] if row["id"] == "feed-existing")
            self.assertNotIn("textRetention", restored_source)
            with self.assertRaisesRegex(cli.ProgRSSError, "already exists"):
                cli.cmd_workspace_set_text_retention(restore)

    def test_transfer_audit_explains_private_content_and_reconnect_upper_bound(self) -> None:
        wrapper, state = self.load()
        state["fixtures"] = [{"id": "advanced-fixture"}]
        report = cli.transfer_audit_report(wrapper, state, include_origins=False)
        self.assertEqual(report["schema"], "progrss.workspace.transfer-audit.v1")
        self.assertEqual(report["moves"]["sources"], 2)
        self.assertEqual(report["moves"]["advancedRecords"], 1)
        self.assertEqual(report["destination"]["upToReconnectSources"], 1)
        self.assertEqual(report["destination"]["upToReconnectOrigins"], 1)
        self.assertFalse(report["destination"]["originsIncluded"])
        self.assertEqual(report["destination"]["origins"], [])
        self.assertTrue(report["privacy"]["keepFilePrivate"])
        self.assertFalse(report["network"])
        self.assertFalse(report["writes"])
        detailed = cli.transfer_audit_report(wrapper, state, include_origins=True)
        self.assertEqual(detailed["destination"]["origins"], [{"origin": "https://existing.test", "sourceCount": 1}])

    def test_transfer_audit_keeps_moved_sources_out_of_reconnect_upper_bound(self) -> None:
        wrapper, state = self.load()
        source = state["sources"][0]
        source["pendingRedirect"] = {"from": source["url"], "to": "https://new.test/feed.xml"}
        report = cli.transfer_audit_report(wrapper, state, include_origins=True)
        self.assertEqual(report["destination"]["movedSourcesStillNeedingReview"], 1)
        self.assertEqual(report["destination"]["upToReconnectSources"], 0)
        self.assertEqual(report["destination"]["upToReconnectOrigins"], 0)

    def test_portable_state_strips_revision_and_local_undo_records(self) -> None:
        state = {
            "version": 13, "sources": [], "collections": [], "items": [], "snapshots": {},
            "_revision": 7,
            "transferUndo": {"schema": "progrss.transfer.undo.v1"},
            "sourceRepairUndo": {"schema": "progrss.source.repair.undo.v1"},
            "receiptRetirementUndo": {"schema": "progrss.receipt.retirement.undo.v1"},
        }
        portable = cli.portable_state(state)
        self.assertNotIn("_revision", portable)
        self.assertNotIn("transferUndo", portable)
        self.assertNotIn("sourceRepairUndo", portable)
        self.assertNotIn("receiptRetirementUndo", portable)
        self.assertEqual(portable["version"], 17)

    def test_backup_rejects_oversized_advanced_records(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            document = json.loads((FIXTURES / "sample-backup.json").read_text())
            document["state"]["fixtures"] = [{"id": f"fixture-{index}"} for index in range(17)]
            path = Path(temp_dir) / "oversized-advanced.json"
            path.write_text(json.dumps(document))
            with self.assertRaisesRegex(cli.ProgRSSError, "too many fixtures"):
                cli.load_backup(path)

    def test_query_unread_contains(self) -> None:
        _wrapper, state = self.load()
        args = argparse.Namespace(source="", contains="climate", unread_only=True, starred_only=False)
        rows = cli.matching_items(state, args)
        self.assertEqual([row["title"] for row in rows], ["Unread and saved"])

    def test_query_contains_source_title(self) -> None:
        _wrapper, state = self.load()
        args = argparse.Namespace(source="", contains="existing feed", unread_only=False, starred_only=False)
        rows = cli.matching_items(state, args)
        self.assertEqual({row["title"] for row in rows}, {"Already read", "Unread and saved"})

    def test_page_change_is_audited_searchable_and_readable(self) -> None:
        wrapper, state = self.load()
        change = {
            "schema": cli.PAGE_CHANGE_SCHEMA,
            "kind": "text-changed",
            "mode": "region",
            "summary": "Changed Monday to Tuesday",
            "before": "Library opens Monday at 9.",
            "after": "Library opens Tuesday at 10.",
            "removed": "Monday at 9",
            "added": "Tuesday at 10",
            "removedWords": 3,
            "addedWords": 3,
            "delta": 13,
            "threshold": 4,
            "ignoreNumbers": False,
        }
        state["items"].append({
            "id": "page-weather|change", "sourceId": "page-weather",
            "title": "Town noticeboard changed", "url": "https://weather.test/",
            "summary": change["summary"], "observedAt": "2026-10-18T18:00:00Z",
            "readAt": "", "starred": False, "change": change,
        })
        self.assertEqual(cli.state_audit(state)["state"], "valid")
        args = argparse.Namespace(source="", contains="tuesday", folder="", unread_only=True, starred_only=False)
        self.assertEqual([row["id"] for row in cli.matching_items(state, args)], ["page-weather|change"])

        with tempfile.TemporaryDirectory() as temp_dir:
            path = Path(temp_dir) / "page-change.json"
            wrapper["state"] = state
            path.write_text(json.dumps(wrapper), encoding="utf-8")
            read_output = io.StringIO()
            with contextlib.redirect_stdout(read_output):
                cli.cmd_workspace_read(argparse.Namespace(backup=str(path), item="page-weather|change", json=False))
            rendered = read_output.getvalue()
            self.assertIn("Before\nLibrary opens Monday at 9.", rendered)
            self.assertIn("Now\nLibrary opens Tuesday at 10.", rendered)
            self.assertIn("Offline · no writes", rendered)

            report_output = io.StringIO()
            with contextlib.redirect_stdout(report_output):
                cli.cmd_workspace_page_changes(argparse.Namespace(backup=str(path), source="town", unread_only=True, limit=20, json=True))
            report = json.loads(report_output.getvalue())
            self.assertEqual(report["schema"], "progrss.workspace.page-changes.v1")
            self.assertEqual(report["count"], 1)
            self.assertEqual(report["changes"][0]["change"]["before"], "Library opens Monday at 9.")
            self.assertFalse(report["network"])
            self.assertFalse(report["writes"])

    def test_invalid_page_change_is_rejected_by_audit(self) -> None:
        _wrapper, state = self.load()
        state["items"][0]["change"] = {"schema": cli.PAGE_CHANGE_SCHEMA, "kind": "mystery", "mode": "region"}
        report = cli.state_audit(state)
        self.assertEqual(report["state"], "invalid")
        self.assertTrue(any("page-change" in message for message in report["errors"]))

        state["items"][0]["change"] = {
            "schema": cli.PAGE_CHANGE_SCHEMA, "kind": "text-changed", "mode": "region",
            "before": "x" * 1_201, "after": "Changed text",
        }
        report = cli.state_audit(state)
        self.assertEqual(report["state"], "invalid")
        self.assertTrue(any("page-change" in message for message in report["errors"]))

        state["items"][0]["change"] = {
            "schema": cli.PAGE_CHANGE_SCHEMA, "kind": "text-changed", "mode": "region",
            "summary": "   ", "diagnostics": {"rawDom": "not portable"},
        }
        report = cli.state_audit(state)
        self.assertEqual(report["state"], "invalid")
        self.assertTrue(any("page-change" in message for message in report["errors"]))


    def test_simple_folder_model_and_folder_scoped_query(self) -> None:
        _wrapper, state = self.load()
        state["collections"] = [
            {"id": "reading", "title": "Reading", "mode": "union", "members": [
                {"kind": "source", "id": "feed-existing"}, {"kind": "collection", "id": "practical"},
            ]},
            {"id": "practical", "title": "Practical", "mode": "union", "members": [
                {"kind": "source", "id": "page-weather"},
            ]},
            {"id": "advanced", "title": "Filtered", "mode": "union", "include": "important", "members": []},
        ]
        report = cli.folder_rows(state)
        self.assertEqual([row["path"] for row in report["rows"]], ["Reading", "Reading › Practical"])
        self.assertEqual(report["rows"][0]["sourceCount"], 2)
        self.assertEqual(report["rows"][0]["unreadCount"], 1)
        self.assertEqual(report["rows"][1]["sourceCount"], 1)
        self.assertEqual(report["omittedCollections"], 1)
        args = argparse.Namespace(source="", contains="", unread_only=False, starred_only=False, folder="Reading")
        rows = cli.matching_items(state, args)
        self.assertEqual({row["title"] for row in rows}, {"Already read", "Unread and saved"})
        args.folder = "Reading › Practical"
        self.assertEqual(cli.matching_items(state, args), [])
        folder_id, folder_label, source_ids = cli.resolve_folder_scope(state, "practical")
        self.assertEqual((folder_id, folder_label), ("practical", "Reading › Practical"))
        self.assertEqual(source_ids, {"page-weather"})
        source = cli.resolve_source_for_placement(state, "Existing Feed")
        self.assertEqual(source["id"], "feed-existing")
        source["declaredFeedUrl"] = "https://existing.test/primary.xml"
        source["previousUrls"] = ["https://existing.test/old.xml"]
        self.assertEqual(cli.resolve_source_for_placement(state, "https://existing.test/primary.xml")["id"], "feed-existing")
        self.assertEqual(cli.resolve_source_for_placement(state, "https://existing.test/old.xml")["id"], "feed-existing")
        target = cli.resolve_simple_folder_for_placement(state, "Reading › Practical")
        self.assertEqual(target["id"], "practical")

    def test_folder_edition_is_summary_only_deduplicated_and_offline(self) -> None:
        state = {
            "version": 17,
            "sources": [
                {"id": "feed-a", "title": "First desk", "type": "rss", "url": "https://first.test/feed", "enabled": True},
                {"id": "feed-b", "title": "Second desk", "type": "rss", "url": "https://second.test/feed", "enabled": True},
                {"id": "watch-a", "title": "Town page", "type": "page", "url": "https://town.test/notices", "enabled": True},
                {"id": "archived", "title": "Archived", "type": "rss", "url": "https://archived.test/feed", "enabled": False, "archivedAt": "2026-10-18T00:00:00Z"},
            ],
            "collections": [{
                "id": "reading", "title": "Reading", "mode": "union", "members": [
                    {"kind": "source", "id": "feed-a"},
                    {"kind": "source", "id": "feed-b"},
                    {"kind": "source", "id": "watch-a"},
                    {"kind": "source", "id": "archived"},
                ],
            }],
            "items": [
                {"id": "a-1", "sourceId": "feed-a", "title": "Garden opens", "url": "https://news.test/garden", "summary": "Saturday morning.", "body": "PRIVATE FULL TEXT A", "readAt": "2026-10-19T01:30:00Z", "starred": True, "observedAt": "2026-10-19T01:00:00Z"},
                {"id": "b-1", "sourceId": "feed-b", "title": "Garden opens today", "url": "https://news.test/garden", "summary": "Saturday at nine.", "body": "PRIVATE FULL TEXT B", "observedAt": "2026-10-19T02:00:00Z"},
                {"id": "page-1", "sourceId": "watch-a", "title": "Town notice changed", "url": "https://town.test/notices", "summary": "Meeting time changed.", "kind": "changed", "observedAt": "2026-10-19T03:00:00Z", "change": {"schema": cli.PAGE_CHANGE_SCHEMA, "kind": "text-changed", "mode": "region", "summary": "Meeting time changed.", "before": "PRIVATE BEFORE", "after": "PRIVATE AFTER"}},
                {"id": "archived-1", "sourceId": "archived", "title": "Old item", "url": "https://archived.test/old", "summary": "Must not appear.", "observedAt": "2026-10-19T04:00:00Z"},
            ],
        }
        document, report = cli.folder_edition_document(
            state,
            "Reading",
            curator="Neighborhood desk",
            note="A weekly selection.",
            generated_at="2026-10-19T05:00:00Z",
        )
        self.assertEqual(document["version"], cli.JSON_FEED_VERSION)
        self.assertEqual(document["_progrss"]["schema"], cli.FOLDER_EDITION_SCHEMA)
        parsed = cli.parse_feed(json.dumps(document).encode("utf-8"), "https://publisher.test/edition.json")
        self.assertEqual(parsed["type"], "json")
        self.assertEqual(len(parsed["items"]), 2)
        self.assertEqual(document["authors"], [{"name": "Neighborhood desk"}])
        self.assertEqual(len(document["items"]), 2)
        garden = next(row for row in document["items"] if row.get("url") == "https://news.test/garden")
        self.assertEqual(garden["_progrss"]["sourceCount"], 2)
        self.assertEqual({row["title"] for row in garden["_progrss"]["sources"]}, {"First desk", "Second desk"})
        changed = next(row for row in document["items"] if row["_progrss"].get("changeKind") == "text-changed")
        self.assertEqual(changed["content_text"], "Meeting time changed.")
        self.assertRegex(changed["id"], r"^urn:progrss:edition:[a-f0-9]{16}$")
        self.assertNotIn("watch", changed["id"])
        self.assertEqual(garden["id"], "https://news.test/garden")
        encoded = json.dumps(document, ensure_ascii=False)
        for secret in ("PRIVATE FULL TEXT A", "PRIVATE FULL TEXT B", "PRIVATE BEFORE", "PRIVATE AFTER", "readAt", "starred", "Must not appear"):
            self.assertNotIn(secret, encoded)
        self.assertEqual(report["schema"], cli.FOLDER_EDITION_RESULT_SCHEMA)
        self.assertEqual(report["items"], 2)
        self.assertEqual(report["sources"], 3)
        self.assertFalse(report["fullTextIncluded"])
        self.assertFalse(report["readingStateIncluded"])
        self.assertFalse(report["pageWatchEvidenceIncluded"])
        self.assertFalse(report["network"])
        self.assertFalse(report["writes"])

        limited, limited_report = cli.folder_edition_document(state, "Reading", limit=1)
        self.assertEqual(len(limited["items"]), 1)
        self.assertEqual(limited_report["omittedByLimit"], 1)
        with self.assertRaisesRegex(cli.ProgRSSError, "simple folder"):
            cli.folder_edition_document(state, "all")


    def test_graft_receipt_canonical_digest_and_retired_reference_report(self) -> None:
        _wrapper, state = self.load()
        original = state["sources"][0]
        original["declaredFeedUrl"] = original["url"]
        duplicate = {
            "id": "feed-copy", "title": "Existing Feed copy", "type": "rss",
            "url": "https://existing.test/alternate.xml",
            "declaredFeedUrl": original["url"], "enabled": False, "archivedAt": "",
        }
        state["sources"].append(duplicate)
        receipt = {
            "id": "advanced-repair-reference",
            "schema": "progrss.recipe.graft.receipt.v1",
            "title": "Reviewed garden graft",
            "sourceId": "feed-copy",
            "evidence": {"companionItemId": "feed-copy|entry-2", "retainedItemId": "source|entry-1"},
        }
        self.assertEqual(
            cli.canonical_receipt_digest(receipt),
            "6b35b7ec8eeb263a957dd6d37e6cd32c41962b147b51a55b9b7e04b4fce5c25f",
        )
        with self.assertRaisesRegex(cli.ProgRSSError, "invalid Unicode"):
            cli.canonical_receipt_digest({"schema": "progrss.recipe.graft.receipt.v1", "bad": "\ud800"})
        state["receipts"] = [receipt]
        report = cli.source_reference_report(state, original, duplicate)
        record = report["groups"][0]["records"][0]
        self.assertTrue(record["retirement"]["eligible"])
        self.assertEqual(report["summary"]["blockingRecords"], 1)

        digest = cli.canonical_receipt_digest(receipt)
        state["receipts"] = []
        state["retiredReceipts"] = [{
            "schema": "progrss.retired.graft-receipt.v1",
            "id": "retired-graft-test",
            "retiredAt": "2026-10-18T12:00:00Z",
            "invalidatedAt": "2026-10-18T12:00:00Z",
            "reason": "local-source-history-repair",
            "originalSchema": "progrss.recipe.graft.receipt.v1",
            "originalRecordId": receipt["id"],
            "originalTitle": receipt["title"],
            "originalDigest": digest,
            "sourcePair": [{"id": original["id"], "title": original["title"]}, {"id": duplicate["id"], "title": duplicate["title"]}],
            "sharedAddresses": [original["url"]],
            "originalReceipt": receipt,
        }]
        retired_report = cli.source_reference_report(state, original, duplicate)
        self.assertEqual(retired_report["summary"]["blockingRecords"], 0)
        self.assertEqual(retired_report["summary"]["retiredRecords"], 1)
        self.assertEqual(retired_report["retiredEvidence"][0]["originalDigest"], digest)

    def test_same_source_repair_merges_history_without_pooling_operational_authority(self) -> None:
        _wrapper, state = self.load()
        state["version"] = 13
        original = state["sources"][0]
        original["declaredFeedUrl"] = "https://existing.test/feed.xml"
        original["httpCache"] = {"etag": '"original"'}
        original["pulse"] = {"nextAt": "2026-10-20T12:00:00Z"}
        original["lastSuccessfulAt"] = "2026-10-18T10:00:00Z"
        duplicate = {
            "id": "feed-copy", "title": "Existing Feed copy", "type": "rss",
            "url": "https://existing.test/alternate.xml",
            "declaredFeedUrl": "https://existing.test/feed.xml",
            "enabled": False, "archivedAt": "", "createdAt": "2026-10-14T00:00:00Z",
            "lastSuccessfulAt": "2026-10-17T10:00:00Z",
            "lastProblemAt": "2026-10-17T09:00:00Z", "lastProblem": "Earlier timeout",
            "checkCount": 4,
            "httpCache": {"lastModified": "Fri, 17 Oct 2026 10:00:00 GMT"},
            "pulse": {"nextAt": "2026-10-21T12:00:00Z"},
        }
        state["sources"].append(duplicate)
        repeated = dict(state["items"][1])
        repeated.update({
            "id": "feed-copy|old-1", "entryKey": "feed-copy|old-1", "sourceId": "feed-copy",
            "readAt": "2026-10-18T11:00:00Z", "starred": False,
        })
        unique = {
            "id": "feed-copy|copy-only", "entryKey": "feed-copy|copy-only", "feedRevision": 0,
            "sourceId": "feed-copy", "title": "Copy-only event", "url": "https://existing.test/copy-only",
            "summary": "Only in the copy", "published": "2026-10-18T08:00:00Z",
            "observedAt": "2026-10-18T08:01:00Z", "kind": "new", "readAt": "", "starred": False,
        }
        state["items"].extend([repeated, unique])
        state["collections"] = [{
            "id": "reading", "title": "Reading", "mode": "union", "version": 1,
            "members": [{"kind": "source", "id": original["id"]}, {"kind": "source", "id": duplicate["id"]}],
        }]

        pairs = cli.source_repair_candidate_pairs(state)
        self.assertEqual(len(pairs), 1)
        self.assertEqual(pairs[0][2], ["https://existing.test/feed.xml"])
        self.assertEqual(cli.source_repair_blockers(state, original, duplicate)["blockers"], [])

        result = cli.apply_source_repair(state, original["id"], duplicate["id"], "2026-10-18T12:00:00Z")
        self.assertEqual(result["itemMerge"]["exactRepeatsCollapsed"], 1)
        self.assertEqual(result["itemMerge"]["afterCount"], 3)
        self.assertEqual(result["changedCollections"], 1)
        self.assertEqual(len(state["sources"]), 2)
        survivor = next(row for row in state["sources"] if row["id"] == original["id"])
        self.assertEqual(survivor["url"], "https://existing.test/feed.xml")
        self.assertEqual(survivor["httpCache"], {"etag": '"original"'})
        self.assertEqual(survivor["pulse"], {"nextAt": "2026-10-20T12:00:00Z"})
        self.assertIn("https://existing.test/alternate.xml", survivor["aliasUrls"])
        self.assertEqual(survivor["repairHistory"][-1]["sourceId"], "feed-copy")
        merged_repeat = next(row for row in state["items"] if row.get("sourceId") == original["id"] and row.get("url") == "https://existing.test/1")
        self.assertEqual(merged_repeat["readAt"], "")
        self.assertTrue(merged_repeat["starred"])
        self.assertEqual(state["collections"][0]["members"], [{"kind": "source", "id": original["id"]}])

    def test_same_source_repair_blocks_advanced_source_or_item_references(self) -> None:
        _wrapper, state = self.load()
        original = state["sources"][0]
        duplicate = {
            "id": "feed-copy", "title": "Existing Feed copy", "type": "rss",
            "url": "https://existing.test/alternate.xml",
            "declaredFeedUrl": original["url"], "enabled": True, "archivedAt": "",
        }
        state["sources"].append(duplicate)
        state["receipts"] = [{
            "id": "graft-receipt", "schema": "progrss.recipe.graft.receipt.v1",
            "title": "Reviewed garden graft", "source": duplicate["id"],
            "evidence": {"item": state["items"][0]["id"]},
        }]
        blocked = cli.source_repair_blockers(state, original, duplicate)
        self.assertTrue(blocked["blockers"])
        self.assertEqual(blocked["advancedReferences"], [{"kind": "receipts", "count": 2}])
        report = blocked["referenceReport"]
        self.assertEqual(report["schema"], "progrss.source-reference-report.v1")
        self.assertEqual(report["summary"]["blockingRecords"], 1)
        self.assertEqual(report["summary"]["sourceHistoryReferences"], 1)
        self.assertEqual(report["summary"]["retainedUpdateReferences"], 1)
        self.assertFalse(report["network"])
        self.assertFalse(report["writes"])
        self.assertFalse(report["browserProfileRead"])
        receipt = report["groups"][0]["records"][0]
        self.assertEqual(receipt["title"], "Reviewed garden graft")
        self.assertEqual(receipt["schema"], "progrss.recipe.graft.receipt.v1")
        self.assertIn('$["source"]', [path for row in receipt["references"] for path in row["paths"]])

    def test_opml_only_active_rss(self) -> None:
        _wrapper, state = self.load()
        opml = cli.opml_bytes(state).decode()
        self.assertIn("Existing Feed", opml)
        self.assertIn("https://existing.test/feed.xml", opml)
        self.assertNotIn("Town noticeboard", opml)

    def test_mark_all_read_new_file_and_no_overwrite(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            source = Path(temp_dir) / "with-internal-revision.json"
            source_doc = json.loads((FIXTURES / "sample-backup.json").read_text())
            source_doc["state"]["_revision"] = 42
            source_doc["state"]["transferUndo"] = {"schema": "progrss.transfer.undo.v1"}
            source.write_text(json.dumps(source_doc))
            output = Path(temp_dir) / "marked.json"
            args = argparse.Namespace(backup=str(source), output=str(output))
            self.assertEqual(cli.cmd_workspace_mark_all_read(args), 0)
            doc = json.loads(output.read_text())
            self.assertTrue(all(item.get("readAt") for item in doc["state"]["items"]))
            self.assertNotIn("_revision", doc["state"])
            self.assertNotIn("transferUndo", doc["state"])
            with self.assertRaisesRegex(cli.ProgRSSError, "already exists"):
                cli.cmd_workspace_mark_all_read(args)

    def test_offline_ingest_creates_source_and_events(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            output = Path(temp_dir) / "ingested.json"
            args = argparse.Namespace(
                backup=str(FIXTURES / "sample-backup.json"),
                feed=str(FIXTURES / "sample-rss.xml"),
                url="https://example.test/feed.xml",
                title="",
                output=str(output),
            )
            self.assertEqual(cli.cmd_workspace_ingest(args), 0)
            doc = json.loads(output.read_text())
            new_sources = [row for row in doc["state"]["sources"] if row["url"] == "https://example.test/feed.xml"]
            self.assertEqual(len(new_sources), 1)
            source = new_sources[0]
            self.assertEqual(source["title"], "Garden Notes")
            new_items = [row for row in doc["state"]["items"] if row["sourceId"] == source["id"]]
            self.assertEqual(len(new_items), 2)
            self.assertTrue(all(row["entryKey"].startswith(source["id"] + "|") for row in new_items))

    def test_ingest_declared_same_origin_address_updates_existing_source_without_duplicate(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            source_path = Path(temp_dir) / "source.json"
            output = Path(temp_dir) / "ingested.json"
            document = json.loads((FIXTURES / "sample-backup.json").read_text())
            existing = document["state"]["sources"][0]
            existing["url"] = "https://atom-self.example/feeds/daily.atom"
            existing["title"] = "Existing Atom source"
            source_path.write_text(json.dumps(document))
            args = argparse.Namespace(
                backup=str(source_path),
                feed=str(FIXTURES / "interoperability" / "atom-self-link.xml"),
                url="https://atom-self.example/alternate.atom",
                title="",
                output=str(output),
            )
            self.assertEqual(cli.cmd_workspace_ingest(args), 0)
            result = json.loads(output.read_text())
            self.assertEqual(len(result["state"]["sources"]), len(document["state"]["sources"]))
            updated = next(row for row in result["state"]["sources"] if row["id"] == existing["id"])
            self.assertEqual(updated["url"], "https://atom-self.example/alternate.atom")
            self.assertEqual(updated["declaredFeedUrl"], "https://atom-self.example/feeds/daily.atom")
            self.assertIn("https://atom-self.example/feeds/daily.atom", updated["previousUrls"])

    def test_ingest_same_feed_is_idempotent(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            first = Path(temp_dir) / "first.json"
            second = Path(temp_dir) / "second.json"
            base = argparse.Namespace(
                backup=str(FIXTURES / "sample-backup.json"), feed=str(FIXTURES / "sample-rss.xml"),
                url="https://example.test/feed.xml", title="", output=str(first)
            )
            cli.cmd_workspace_ingest(base)
            again = argparse.Namespace(backup=str(first), feed=str(FIXTURES / "sample-rss.xml"), url=base.url, title="", output=str(second))
            cli.cmd_workspace_ingest(again)
            doc = json.loads(second.read_text())
            source = next(row for row in doc["state"]["sources"] if row["url"] == base.url)
            self.assertEqual(source["lastItems"], 0)
            self.assertEqual(len([row for row in doc["state"]["items"] if row["sourceId"] == source["id"]]), 2)

    def test_source_activity_uses_readable_landmarks(self) -> None:
        _wrapper, state = self.load()
        state["sources"][0]["lastSuccessfulAt"] = "2026-10-17T11:00:00Z"
        state["sources"][0]["lastProblemAt"] = "2026-10-16T09:00:00Z"
        state["sources"][0]["lastProblem"] = "Temporary HTTP 503"
        rows = cli.source_activity_rows(state)
        existing = next(row for row in rows if row["id"] == "feed-existing")
        self.assertEqual(existing["status"], "following")
        self.assertEqual(existing["lastSuccessfulAt"], "2026-10-17T11:00:00Z")
        self.assertEqual(existing["lastNewAt"], "2026-10-17T12:01:00Z")
        self.assertEqual(existing["lastProblem"], "Temporary HTTP 503")
        page = next(row for row in rows if row["id"] == "page-weather")
        self.assertEqual(page["status"], "paused")

    def test_source_activity_distinguishes_move_and_reconnect(self) -> None:
        _wrapper, state = self.load()
        moved = state["sources"][0]
        moved["pendingRedirect"] = {
            "from": moved["url"],
            "to": "https://new.example.test/feed.xml",
            "observedAt": "2026-10-18T03:00:00Z",
        }
        moved["lastError"] = "This source moved."
        reconnect = state["sources"][1]
        reconnect["enabled"] = True
        reconnect["permissionMissing"] = True
        reconnect["lastError"] = "Site access was removed."
        rows = cli.source_activity_rows(state)
        self.assertEqual(rows[0]["status"], "moved")
        self.assertEqual(rows[0]["move"]["to"], "https://new.example.test/feed.xml")
        self.assertEqual(rows[1]["status"], "reconnect")

    def test_source_activity_names_page_watch_repair(self) -> None:
        _wrapper, state = self.load()
        page = next(row for row in state["sources"] if row["id"] == "page-weather")
        page["enabled"] = True
        page["lastError"] = "ProgRSS can no longer find the watched section."
        page["watchRepair"] = {
            "schema": "progrss.page-watch.repair.v1",
            "reason": "no-match",
            "noticedAt": "2026-10-19T01:00:00Z",
            "message": "ProgRSS can no longer find the watched section.",
        }
        rows = cli.source_activity_rows(state)
        repaired = next(row for row in rows if row["id"] == "page-weather")
        self.assertEqual(repaired["status"], "watch-repair")
        self.assertEqual(repaired["watchRepair"]["reason"], "no-match")
        self.assertIn("watched section", repaired["watchRepair"]["message"])

    def test_source_activity_keeps_pending_watch_in_following_flow(self) -> None:
        _wrapper, state = self.load()
        page = next(row for row in state["sources"] if row["id"] == "page-weather")
        page["enabled"] = True
        page["watchStability"] = {
            "schema": "progrss.page-watch.stability.v1", "status": "pending",
            "reason": "text-size-shift", "recipeVersion": 1, "observations": 1,
            "lastSeenAt": "2026-10-19T02:00:00Z",
            "message": "This page looked unusually different once.",
        }
        rows = cli.source_activity_rows(state)
        pending = next(row for row in rows if row["id"] == "page-weather")
        self.assertEqual(pending["status"], "checking-again")
        self.assertEqual(pending["watchStability"]["observations"], 1)
        self.assertIn("unusually different", pending["watchStability"]["message"])

    def test_import_opml_paused_preserves_nested_folders(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            source = Path(temp_dir) / "with-internal-revision.json"
            source_doc = json.loads((FIXTURES / "sample-backup.json").read_text())
            source_doc["state"]["_revision"] = 19
            source.write_text(json.dumps(source_doc))
            output = Path(temp_dir) / "imported.json"
            args = argparse.Namespace(
                backup=str(source), opml=str(FIXTURES / "sample-subscriptions.opml"),
                output=str(output), active=False,
            )
            self.assertEqual(cli.cmd_workspace_import_opml(args), 0)
            doc = json.loads(output.read_text())
            self.assertNotIn("_revision", doc["state"])
            imported = [row for row in doc["state"]["sources"] if row.get("origin") == "cli-opml-import"]
            self.assertEqual(len(imported), 2)
            self.assertTrue(all(row["enabled"] is False for row in imported))
            self.assertEqual({row["title"] for row in imported}, {"Garden Notes", "Workshop Notes"})
            collections = {row["title"]: row for row in doc["state"]["collections"]}
            self.assertEqual(set(collections), {"Independent", "Deep", "News"})
            deep_id = collections["Deep"]["id"]
            self.assertIn({"kind": "collection", "id": deep_id}, collections["Independent"]["members"])
            garden_id = next(row["id"] for row in imported if row["title"] == "Garden Notes")
            self.assertIn({"kind": "source", "id": garden_id}, collections["Independent"]["members"])
            self.assertIn({"kind": "source", "id": garden_id}, collections["News"]["members"])
            with self.assertRaisesRegex(cli.ProgRSSError, "already exists"):
                cli.cmd_workspace_import_opml(args)

    def test_import_opml_active_is_still_offline(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            output = Path(temp_dir) / "active.json"
            args = argparse.Namespace(
                backup=str(FIXTURES / "sample-backup.json"), opml=str(FIXTURES / "sample-subscriptions.opml"),
                output=str(output), active=True,
            )
            self.assertEqual(cli.cmd_workspace_import_opml(args), 0)
            doc = json.loads(output.read_text())
            imported = [row for row in doc["state"]["sources"] if row.get("origin") == "cli-opml-import"]
            self.assertTrue(imported and all(row["enabled"] is True for row in imported))
            self.assertTrue(all(not row.get("lastScan") for row in imported))

    def test_json_feed_export_filter(self) -> None:
        _wrapper, state = self.load()
        state["sources"][0]["language"] = "AR"
        state["items"][1]["language"] = "AR"
        exported = json.loads(cli.json_feed_bytes(state, unread_only=True, starred_only=False))
        self.assertEqual(exported["title"], "ProgRSS unread")
        self.assertEqual([row["title"] for row in exported["items"]], ["Unread and saved"])
        self.assertEqual(exported["items"][0]["language"], "ar")
        self.assertEqual(exported["language"], "ar")

        # A top-level language must not imply a language for an item whose feed did not declare one.
        state["sources"][0].pop("language", None)
        state["items"][0].pop("language", None)
        mixed = json.loads(cli.json_feed_bytes(state, unread_only=False, starred_only=False))
        self.assertNotIn("language", mixed)


if __name__ == "__main__":
    unittest.main(verbosity=2)
