from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
FIX = ROOT / "fixtures"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import relay  # noqa: E402
from acquisition import acquisition_source_identity  # noqa: E402
from node_server import NodeState, PairingError  # noqa: E402
from node_store import NodeStore, NodeStoreConflict, NodeStoreError, STORE_SCHEMA  # noqa: E402


def source_list() -> dict[str, object]:
    state = {
        "sources": [
            {"id": "feed-civic", "type": "rss", "title": "Civic dispatch", "author": "Field desk", "url": "https://civic.example/feed.xml", "enabled": True},
            {"id": "page-works", "type": "page", "title": "Public works board", "author": "Field desk", "url": "https://works.example/projects", "mode": "cards", "selector": "article", "titleSelector": "h2", "linkSelector": "a", "enabled": True},
        ],
        "collections": [
            {"id": "root-new", "title": "Civic field notes", "mode": "union", "members": [{"kind": "collection", "id": "branch-new"}]},
            {"id": "branch-new", "title": "Street and council", "mode": "union", "members": [{"kind": "source", "id": "feed-civic"}, {"kind": "source", "id": "page-works"}]},
        ],
        "items": [],
    }
    return relay.make_bundle(
        state, "Civic field notes", curator="Field desk",
        note="Useful public records.", exported_at="2026-10-19T23:00:00.000Z",
    )


class NodeStoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)
        self.store_path = self.directory / "library.sqlite3"
        self.creation = NodeStore.create_from_backup(
            FIX / "sample-backup.json", self.store_path, now=1_792_449_000.0,
        )
        self.store = NodeStore(self.store_path)

    def tearDown(self) -> None:
        self.temp.cleanup()

    def test_create_preserves_exact_import_and_exports_current_bytes(self) -> None:
        original = (FIX / "sample-backup.json").read_bytes()
        self.assertEqual(self.creation["schema"], STORE_SCHEMA)
        self.assertTrue(self.creation["import"]["preserved"])
        current = self.store.read_library()
        self.assertEqual(current.raw, original)
        self.assertEqual(current.sha256, hashlib.sha256(original).hexdigest())
        self.assertEqual(current.revision, 1)
        connection = sqlite3.connect(self.store_path)
        try:
            stored = connection.execute("SELECT source_bytes FROM imports").fetchone()[0]
        finally:
            connection.close()
        self.assertEqual(bytes(stored), original)
        output = self.directory / "export.json"
        evidence = self.store.export_current(output)
        self.assertEqual(output.read_bytes(), original)
        self.assertEqual(evidence["sha256"], current.sha256)
        with self.assertRaisesRegex(NodeStoreError, "already exists"):
            self.store.export_current(output)

    def test_reviewed_branch_commit_is_atomic_receipted_and_replay_safe(self) -> None:
        node = NodeState(backup=self.store_path, token="master", store=self.store)
        token, preview = node.create_branch_operation_preview(source_list(), folder="branch-new", now=1_792_449_060.0)
        base = self.store.read_library()
        receipt, replayed = node.commit_branch_operation(
            operation_id="op-test-0123456789abcdef",
            base_sha256=str(preview["library"]["sha256"]),
            preview_token=token,
            preview_digest=str(preview["previewDigest"]),
            now=1_792_449_120.0,
        )
        self.assertFalse(replayed)
        self.assertEqual(receipt["resultRevision"], 2)
        self.assertEqual(receipt["summary"]["newSources"], 2)
        self.assertTrue(receipt["effects"]["newSourcesPaused"])
        current = self.store.read_library()
        self.assertEqual(current.revision, 2)
        self.assertEqual(current.sha256, receipt["resultLibrarySha256"])
        new_sources = [row for row in current.document["state"]["sources"] if row.get("url", "").startswith(("https://civic.example/", "https://works.example/"))]
        self.assertEqual(len(new_sources), 2)
        self.assertTrue(all(row.get("enabled") is False for row in new_sources))
        snapshot_id = receipt["rollbackEvidence"]["snapshotId"]
        snapshot_raw, snapshot_digest, operation_id = self.store.read_snapshot(snapshot_id)
        self.assertEqual(snapshot_raw, base.raw)
        self.assertEqual(snapshot_digest, base.sha256)
        self.assertEqual(operation_id, receipt["operationId"])

        replay, replayed = node.commit_branch_operation(
            operation_id="op-test-0123456789abcdef",
            base_sha256=str(preview["library"]["sha256"]),
            preview_token=token,
            preview_digest=str(preview["previewDigest"]),
            now=1_792_449_180.0,
        )
        self.assertTrue(replayed)
        self.assertEqual(replay["receiptId"], receipt["receiptId"])
        self.assertEqual(self.store.read_library().revision, 2)
        self.assertEqual(len(self.store.list_receipts()), 1)

    def test_same_operation_key_with_different_request_is_refused(self) -> None:
        node = NodeState(backup=self.store_path, token="master", store=self.store)
        token, preview = node.create_branch_operation_preview(source_list(), folder="branch-new", now=1_792_449_060.0)
        node.commit_branch_operation(
            operation_id="op-test-aaaaaaaaaaaaaaaa",
            base_sha256=str(preview["library"]["sha256"]),
            preview_token=token,
            preview_digest=str(preview["previewDigest"]),
            now=1_792_449_120.0,
        )
        with self.assertRaisesRegex(PairingError, "already used for different") as changed:
            node.commit_branch_operation(
                operation_id="op-test-aaaaaaaaaaaaaaaa",
                base_sha256=str(preview["library"]["sha256"]),
                preview_token=token + "changed",
                preview_digest=str(preview["previewDigest"]),
                now=1_792_449_180.0,
            )
        self.assertEqual(changed.exception.status, 409)
        self.assertEqual(self.store.read_library().revision, 2)

    def test_stale_base_is_a_precondition_failure(self) -> None:
        node = NodeState(backup=self.store_path, token="master", store=self.store)
        token_a, preview_a = node.create_branch_operation_preview(source_list(), folder="branch-new", now=1_792_449_060.0)
        token_b, preview_b = node.create_branch_operation_preview(source_list(), folder="branch-new", now=1_792_449_061.0)
        node.commit_branch_operation(
            operation_id="op-test-first-1234567890",
            base_sha256=str(preview_a["library"]["sha256"]), preview_token=token_a,
            preview_digest=str(preview_a["previewDigest"]), now=1_792_449_120.0,
        )
        with self.assertRaisesRegex(PairingError, "changed after review") as stale:
            node.commit_branch_operation(
                operation_id="op-test-stale-1234567890",
                base_sha256=str(preview_b["library"]["sha256"]), preview_token=token_b,
                preview_digest=str(preview_b["previewDigest"]), now=1_792_449_180.0,
            )
        self.assertEqual(stale.exception.status, 412)
        self.assertEqual(self.store.read_library().revision, 2)

    def test_injected_failures_roll_back_library_snapshot_and_receipt_together(self) -> None:
        bundle = source_list()
        initial = self.store.read_library()
        updated_state, summary = relay.import_bundle(initial.document["state"], bundle, "branch-new", now="2026-10-19T23:01:00.000Z")
        result_document = copy.deepcopy(initial.document)
        result_document["exportedAt"] = "2026-10-19T23:01:00.000Z"
        result_document["state"] = updated_state
        for index, failure in enumerate(("after-snapshot", "after-library", "after-receipt"), start=1):
            operation_id = f"op-failure-{index:02d}-1234567890"
            with self.assertRaisesRegex(NodeStoreError, "injected failure"):
                self.store.commit_operation(
                    operation_id=operation_id,
                    operation_type="adopt-source-list-branch",
                    actor="local-admin",
                    request_sha256=hashlib.sha256(f"request-{index}".encode()).hexdigest(),
                    base_sha256=initial.sha256,
                    preview_sha256=hashlib.sha256(f"preview-{index}".encode()).hexdigest(),
                    result_document=result_document,
                    summary=summary,
                    source_list_sha256=hashlib.sha256(f"bundle-{index}".encode()).hexdigest(),
                    selected_folder={"folderId": "branch-new", "folderPath": "Civic field notes › Street and council"},
                    now=1_792_449_120.0 + index,
                    fail_at=failure,
                )
            current = self.store.read_library()
            self.assertEqual(current.sha256, initial.sha256)
            self.assertEqual(current.revision, 1)
            self.assertIsNone(self.store.find_receipt(operation_id))
            connection = sqlite3.connect(self.store_path)
            try:
                self.assertEqual(connection.execute("SELECT COUNT(*) FROM operation_snapshots WHERE operation_id=?", (operation_id,)).fetchone()[0], 0)
            finally:
                connection.close()

    def test_acquisition_intent_commit_and_exact_replay_are_durable(self) -> None:
        initial = self.store.read_library()
        result_document = copy.deepcopy(initial.document)
        result_document["exportedAt"] = "2026-10-20T00:00:00.100Z"
        source = next(row for row in result_document["state"]["sources"] if row["id"] == "feed-existing")
        source["lastOutcome"] = "unchanged"
        source["lastScan"] = "2026-10-20T00:00:00.100Z"
        source["checkCount"] = 1
        operation_id = "acq-test-0123456789abcdef"
        request_sha = hashlib.sha256(b"acquisition-request").hexdigest()
        preview_sha = hashlib.sha256(b"acquisition-preview").hexdigest()

        started = self.store.begin_acquisition(
            operation_id=operation_id,
            request_sha256=request_sha,
            source_id="feed-existing",
            base_sha256=initial.sha256,
            preview_sha256=preview_sha,
            now=1_792_449_000.0,
        )
        self.assertFalse(started.replayed)
        self.assertFalse(started.resumed)
        self.assertEqual(started.attempt, 1)
        committed = self.store.commit_acquisition(
            operation_id=operation_id,
            request_sha256=request_sha,
            source_id="feed-existing",
            base_sha256=initial.sha256,
            preview_sha256=preview_sha,
            result_document=result_document,
            outcome="unchanged",
            summary={"itemsAdded": 0, "baseline": False},
            evidence={"httpStatus": 304},
            request={"method": "GET", "networkRequests": 1},
            now=1_792_449_001.0,
        )
        self.assertFalse(committed.replayed)
        self.assertEqual(committed.receipt["resultRevision"], 2)
        self.assertEqual(committed.receipt["effects"]["networkRequests"], 1)
        self.assertEqual(self.store.read_library().revision, 2)
        self.assertEqual(len(self.store.list_acquisition_receipts()), 1)
        self.assertEqual(self.store.list_acquisition_jobs()[0]["state"], "completed")

        replay_start = self.store.begin_acquisition(
            operation_id=operation_id,
            request_sha256=request_sha,
            source_id="feed-existing",
            base_sha256=initial.sha256,
            preview_sha256=preview_sha,
            now=1_792_449_010.0,
        )
        self.assertTrue(replay_start.replayed)
        self.assertEqual(replay_start.receipt["receiptId"], committed.receipt["receiptId"])
        self.assertEqual(self.store.read_library().revision, 2)

    def test_interrupted_acquisition_can_resume_and_failure_rolls_back(self) -> None:
        initial = self.store.read_library()
        result_document = copy.deepcopy(initial.document)
        result_document["exportedAt"] = "2026-10-20T00:00:00.100Z"
        source = next(row for row in result_document["state"]["sources"] if row["id"] == "feed-existing")
        source["lastOutcome"] = "changed"
        source["checkCount"] = 1
        request_sha = hashlib.sha256(b"resume-request").hexdigest()
        preview_sha = hashlib.sha256(b"resume-preview").hexdigest()
        operation_id = "acq-resume-0123456789abcd"
        self.store.begin_acquisition(
            operation_id=operation_id, request_sha256=request_sha,
            source_id="feed-existing", base_sha256=initial.sha256,
            preview_sha256=preview_sha, now=1_792_449_000.0,
        )
        with self.assertRaisesRegex(NodeStoreError, "injected acquisition failure"):
            self.store.commit_acquisition(
                operation_id=operation_id, request_sha256=request_sha,
                source_id="feed-existing", base_sha256=initial.sha256,
                preview_sha256=preview_sha, result_document=result_document,
                outcome="changed", summary={"itemsAdded": 1}, evidence={"httpStatus": 200},
                request={"method": "GET", "networkRequests": 1},
                now=1_792_449_001.0, fail_at="after-receipt",
            )
        self.assertEqual(self.store.read_library().sha256, initial.sha256)
        self.assertIsNone(self.store.find_acquisition_receipt(operation_id))
        job = self.store.find_acquisition_job(operation_id)
        self.assertEqual(job["state"], "started")
        resumed = self.store.begin_acquisition(
            operation_id=operation_id, request_sha256=request_sha,
            source_id="feed-existing", base_sha256=initial.sha256,
            preview_sha256=preview_sha, now=1_792_449_010.0,
        )
        self.assertTrue(resumed.resumed)
        self.assertEqual(resumed.attempt, 2)
        committed = self.store.commit_acquisition(
            operation_id=operation_id, request_sha256=request_sha,
            source_id="feed-existing", base_sha256=initial.sha256,
            preview_sha256=preview_sha, result_document=result_document,
            outcome="changed", summary={"itemsAdded": 1}, evidence={"httpStatus": 200},
            request={"method": "GET", "networkRequests": 1},
            now=1_792_449_011.0,
        )
        self.assertEqual(committed.receipt["attemptCount"], 2)
        self.assertEqual(self.store.read_library().revision, 2)

    def test_baseline_replacement_failures_roll_back_and_exact_retry_is_safe(self) -> None:
        initial = self.store.read_library()
        accepted_snapshot = {
            "mode": "cards", "keys": ["a", "b", "c"],
            "entries": [
                {"key": key, "title": f"Notice {key.upper()}", "summary": "Accepted", "url": f"https://town.test/notices/{key}"}
                for key in ("a", "b", "c")
            ],
            "capturedAt": "2026-10-20T05:00:00.000Z",
        }
        baseline_document = copy.deepcopy(initial.document)
        baseline_document["exportedAt"] = "2026-10-20T05:00:00.000Z"
        baseline_document["state"].setdefault("snapshots", {})["page-weather"] = accepted_snapshot
        baseline_source = next(row for row in baseline_document["state"]["sources"] if row["id"] == "page-weather")
        baseline_source["enabled"] = True
        baseline_source["lastOutcome"] = "baseline"
        base_request = hashlib.sha256(b"anchor-baseline-request").hexdigest()
        base_preview = hashlib.sha256(b"anchor-baseline-preview").hexdigest()
        self.store.begin_acquisition(
            operation_id="acq-anchor-baseline-000001", request_sha256=base_request,
            source_id="page-weather", base_sha256=initial.sha256,
            preview_sha256=base_preview, now=1_792_449_000.0,
        )
        self.store.commit_acquisition(
            operation_id="acq-anchor-baseline-000001", request_sha256=base_request,
            source_id="page-weather", base_sha256=initial.sha256,
            preview_sha256=base_preview, result_document=baseline_document,
            outcome="baseline", summary={"itemsAdded": 0}, evidence={},
            request={"networkRequests": 0}, now=1_792_449_001.0,
        )

        baseline = self.store.read_library()
        proposed_snapshot = {
            "mode": "cards", "keys": ["d", "e", "f"],
            "entries": [
                {"key": key, "title": f"Notice {key.upper()}", "summary": "Held", "url": f"https://town.test/notices/{key}"}
                for key in ("d", "e", "f")
            ],
            "capturedAt": "2026-10-20T05:05:00.000Z",
        }
        canonical = lambda value: json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        held_document = copy.deepcopy(baseline.document)
        held_document["exportedAt"] = "2026-10-20T05:05:00.000Z"
        held_source = next(row for row in held_document["state"]["sources"] if row["id"] == "page-weather")
        held_source["lastOutcome"] = "coverage-shift"
        source_identity, _material = acquisition_source_identity(held_source)
        continuity = {
            "schema": "progrss.capture-continuity.v1", "action": "hold",
            "reason": "partial-render-window-shift", "message": "Different partial window.",
            "baselinePreserved": True, "overlapPercent": 0,
            "previousUnits": 3, "currentUnits": 3, "sharedUnits": 0,
            "previousBoundaryKinds": ["partial-render"], "currentBoundaryKinds": ["partial-render"],
        }
        held_capture = {
            "sourceIdentitySha256": source_identity,
            "artifactSha256": hashlib.sha256(b"held-artifact").hexdigest(),
            "acceptedSnapshotSha256": hashlib.sha256(canonical(accepted_snapshot)).hexdigest(),
            "proposedSnapshotSha256": hashlib.sha256(canonical(proposed_snapshot)).hexdigest(),
            "proposedSnapshot": proposed_snapshot,
            "proposedProvenance": {"schema": "progrss.browser-capture-provenance.v1", "capturedAt": "2026-10-20T05:05:00.000Z", "possiblePartialRendering": True},
            "continuity": continuity,
        }
        hold_request = hashlib.sha256(b"anchor-hold-request").hexdigest()
        hold_preview = hashlib.sha256(b"anchor-hold-preview").hexdigest()
        self.store.begin_acquisition(
            operation_id="acq-anchor-hold-00000001", request_sha256=hold_request,
            source_id="page-weather", base_sha256=baseline.sha256,
            preview_sha256=hold_preview, now=1_792_449_010.0,
        )
        held_commit = self.store.commit_acquisition(
            operation_id="acq-anchor-hold-00000001", request_sha256=hold_request,
            source_id="page-weather", base_sha256=baseline.sha256,
            preview_sha256=hold_preview, result_document=held_document,
            outcome="coverage-shift", summary={"itemsAdded": 0, "baselinePreserved": True},
            evidence={"continuity": continuity}, request={"networkRequests": 0},
            held_capture=held_capture, now=1_792_449_011.0,
        )
        held = self.store.read_library()
        self.assertEqual(held.revision, 3)
        self.assertIsNotNone(self.store.capture_hold("page-weather"))

        node = NodeState(backup=self.store_path, token="master", store=self.store)
        token, response = node.create_baseline_replacement_preview("page-weather", now=1_792_449_020.0)
        preview = next(iter(node.baseline_previews.values()))
        for index, failure in enumerate(("after-snapshot", "after-library", "after-receipt"), start=1):
            operation_id = f"anchor-failure-{index:02d}-1234567890"
            with self.assertRaisesRegex(NodeStoreError, "injected baseline replacement failure"):
                self.store.commit_baseline_replacement(
                    operation_id=operation_id, actor="local-admin",
                    request_sha256=hashlib.sha256(f"anchor-request-{index}".encode()).hexdigest(),
                    base_sha256=preview.base_sha256, preview_sha256=preview.preview_sha256,
                    source_id=preview.source_id, held_operation_id=preview.held_operation_id,
                    held_receipt_id=preview.held_receipt_id, result_document=preview.result_document,
                    summary=preview.summary, evidence=preview.evidence, selection=preview.selection,
                    now=1_792_449_021.0 + index, fail_at=failure,
                )
            self.assertEqual(self.store.read_library().sha256, held.sha256)
            self.assertEqual(self.store.read_library().revision, 3)
            self.assertIsNotNone(self.store.capture_hold("page-weather"))
            self.assertIsNone(self.store.find_receipt(operation_id))
            connection = sqlite3.connect(self.store_path)
            try:
                self.assertEqual(connection.execute("SELECT COUNT(*) FROM operation_snapshots WHERE operation_id=?", (operation_id,)).fetchone()[0], 0)
            finally:
                connection.close()

        receipt, replayed = node.commit_baseline_replacement(
            operation_id="anchor-success-1234567890", base_sha256=response["library"]["sha256"],
            preview_token=token, preview_digest=response["previewDigest"], now=1_792_449_030.0,
        )
        self.assertFalse(replayed)
        self.assertEqual(receipt["operationType"], "replace-held-page-baseline")
        self.assertEqual(receipt["effects"]["historicalChangeAlertsCreated"], 0)
        self.assertTrue(receipt["effects"]["earlierLibrarySnapshotRetained"])
        self.assertIsNone(self.store.capture_hold("page-weather"))
        accepted = self.store.read_library()
        self.assertEqual(accepted.revision, 4)
        self.assertEqual(accepted.document["state"]["snapshots"]["page-weather"]["keys"], ["d", "e", "f"])
        replay, replayed = node.commit_baseline_replacement(
            operation_id="anchor-success-1234567890", base_sha256=response["library"]["sha256"],
            preview_token=token, preview_digest=response["previewDigest"], now=1_792_449_031.0,
        )
        self.assertTrue(replayed)
        self.assertEqual(replay["receiptId"], receipt["receiptId"])
        self.assertEqual(self.store.read_library().revision, 4)

    def test_rev0064_store_migrates_without_rewriting_library_bytes(self) -> None:
        before = self.store.read_library()
        connection = sqlite3.connect(self.store_path, isolation_level=None)
        try:
            connection.execute("DROP TABLE acquisition_receipts")
            connection.execute("DROP TABLE acquisition_jobs")
            connection.execute("UPDATE metadata SET value='progrss.node-store.v1' WHERE key='schema'")
            connection.execute("PRAGMA user_version=1")
        finally:
            connection.close()
        migrated = NodeStore(self.store_path)
        self.assertTrue(migrated.migrated)
        after = migrated.read_library()
        self.assertEqual(after.raw, before.raw)
        self.assertEqual(after.sha256, before.sha256)
        connection = sqlite3.connect(self.store_path)
        try:
            self.assertEqual(connection.execute("PRAGMA user_version").fetchone()[0], 4)
            self.assertEqual(connection.execute("SELECT value FROM metadata WHERE key='schema'").fetchone()[0], STORE_SCHEMA)
            tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        finally:
            connection.close()
        self.assertIn("acquisition_jobs", tables)
        self.assertIn("acquisition_receipts", tables)
        self.assertIn("capture_holds", tables)
        self.assertIn("capture_hold_history", tables)

    def test_rev0065_store_migrates_to_capture_holds_without_rewriting_library(self) -> None:
        before = self.store.read_library()
        connection = sqlite3.connect(self.store_path, isolation_level=None)
        try:
            connection.execute("DROP TABLE capture_holds")
            connection.execute("UPDATE metadata SET value='progrss.node-store.v2' WHERE key='schema'")
            connection.execute("PRAGMA user_version=2")
        finally:
            connection.close()
        migrated = NodeStore(self.store_path)
        self.assertTrue(migrated.migrated)
        after = migrated.read_library()
        self.assertEqual(after.raw, before.raw)
        self.assertEqual(after.sha256, before.sha256)
        self.assertEqual(after.revision, before.revision)
        connection = sqlite3.connect(self.store_path)
        try:
            self.assertEqual(connection.execute("PRAGMA user_version").fetchone()[0], 4)
            self.assertEqual(connection.execute("SELECT value FROM metadata WHERE key='schema'").fetchone()[0], STORE_SCHEMA)
            self.assertIsNotNone(connection.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='capture_holds'").fetchone())
            self.assertIsNotNone(connection.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='capture_hold_history'").fetchone())
        finally:
            connection.close()

    def test_rev0073_store_migrates_to_bounded_hold_history_without_rewriting_library(self) -> None:
        before = self.store.read_library()
        connection = sqlite3.connect(self.store_path, isolation_level=None)
        try:
            connection.execute("DROP TABLE capture_hold_history")
            connection.execute("UPDATE metadata SET value='progrss.node-store.v3' WHERE key='schema'")
            connection.execute("PRAGMA user_version=3")
        finally:
            connection.close()
        migrated = NodeStore(self.store_path)
        self.assertTrue(migrated.migrated)
        after = migrated.read_library()
        self.assertEqual(after.raw, before.raw)
        self.assertEqual(after.sha256, before.sha256)
        self.assertEqual(after.revision, before.revision)
        connection = sqlite3.connect(self.store_path)
        try:
            self.assertEqual(connection.execute("PRAGMA user_version").fetchone()[0], 4)
            self.assertEqual(connection.execute("SELECT value FROM metadata WHERE key='schema'").fetchone()[0], STORE_SCHEMA)
            self.assertIsNotNone(connection.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='capture_hold_history'").fetchone())
        finally:
            connection.close()

    def test_repeated_holds_keep_current_plus_eight_prior_and_bearing_is_read_only(self) -> None:
        initial = self.store.read_library()
        accepted_snapshot = {
            "mode": "cards", "keys": ["a", "b", "c"],
            "entries": [{"key": key, "title": f"Notice {key}", "summary": "Accepted", "url": f"https://town.test/{key}"} for key in ("a", "b", "c")],
            "capturedAt": "2026-10-20T05:00:00.000Z",
        }
        baseline_doc = copy.deepcopy(initial.document)
        baseline_doc["state"].setdefault("snapshots", {})["page-weather"] = accepted_snapshot
        source = next(row for row in baseline_doc["state"]["sources"] if row["id"] == "page-weather")
        source["enabled"] = True
        request_sha = hashlib.sha256(b"bearing-baseline-request").hexdigest()
        preview_sha = hashlib.sha256(b"bearing-baseline-preview").hexdigest()
        self.store.begin_acquisition(operation_id="bearing-baseline-000001", request_sha256=request_sha, source_id="page-weather", base_sha256=initial.sha256, preview_sha256=preview_sha, now=1_792_449_000.0)
        self.store.commit_acquisition(operation_id="bearing-baseline-000001", request_sha256=request_sha, source_id="page-weather", base_sha256=initial.sha256, preview_sha256=preview_sha, result_document=baseline_doc, outcome="baseline", summary={"itemsAdded": 0}, evidence={}, request={"networkRequests": 0}, now=1_792_449_001.0)

        canonical = lambda value: json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        for index in range(10):
            base = self.store.read_library()
            proposal_keys = [f"{index}-{suffix}" for suffix in ("x", "y", "z")]
            proposal = {
                "mode": "cards", "keys": proposal_keys,
                "entries": [{"key": key, "title": key, "summary": "Held", "url": f"https://town.test/{key}"} for key in proposal_keys],
                "capturedAt": f"2026-10-20T05:{10 + index:02d}:00.000Z",
            }
            result = copy.deepcopy(base.document)
            row = next(item for item in result["state"]["sources"] if item["id"] == "page-weather")
            row["lastOutcome"] = "coverage-shift"
            identity, _material = acquisition_source_identity(row)
            continuity = {
                "schema": "progrss.capture-continuity.v1", "action": "hold",
                "reason": "partial-render-window-shift", "message": "Different partial window.",
                "baselinePreserved": True, "overlapPercent": 0,
                "previousUnits": 3, "currentUnits": 3, "sharedUnits": 0,
                "previousBoundaryKinds": ["partial-render"], "currentBoundaryKinds": ["partial-render"],
                "boundaryChanged": False,
            }
            held_capture = {
                "sourceIdentitySha256": identity,
                "artifactSha256": hashlib.sha256(f"bearing-artifact-{index}".encode()).hexdigest(),
                "acceptedSnapshotSha256": hashlib.sha256(canonical(accepted_snapshot)).hexdigest(),
                "proposedSnapshotSha256": hashlib.sha256(canonical(proposal)).hexdigest(),
                "proposedSnapshot": proposal,
                "proposedProvenance": {
                    "schema": "progrss.browser-capture-provenance.v1",
                    "capturedAt": proposal["capturedAt"], "possiblePartialRendering": True,
                    "pageContextKinds": ["partial-render"],
                },
                "continuity": continuity,
            }
            operation_id = f"bearing-hold-{index:02d}-1234567890"
            request = hashlib.sha256(f"bearing-request-{index}".encode()).hexdigest()
            preview = hashlib.sha256(f"bearing-preview-{index}".encode()).hexdigest()
            self.store.begin_acquisition(operation_id=operation_id, request_sha256=request, source_id="page-weather", base_sha256=base.sha256, preview_sha256=preview, now=1_792_449_010.0 + index)
            self.store.commit_acquisition(operation_id=operation_id, request_sha256=request, source_id="page-weather", base_sha256=base.sha256, preview_sha256=preview, result_document=result, outcome="coverage-shift", summary={"itemsAdded": 0, "baselinePreserved": True}, evidence={"continuity": continuity}, request={"networkRequests": 0}, held_capture=held_capture, now=1_792_449_010.5 + index)

        current = self.store.capture_hold("page-weather")
        history = self.store.capture_hold_history("page-weather")
        self.assertEqual(current["captureOperationId"], "bearing-hold-09-1234567890")
        self.assertEqual(len(history), 8)
        self.assertEqual(history[0]["captureOperationId"], "bearing-hold-08-1234567890")
        self.assertEqual(history[-1]["captureOperationId"], "bearing-hold-01-1234567890")
        node = NodeState(backup=self.store_path, token="master", store=self.store)
        before = self.store.read_library()
        review = node.bearing_review("page-weather")
        after = self.store.read_library()
        self.assertEqual(review["schema"], "progrss.node.bearing-review.v2")
        self.assertEqual(review["diagnosis"]["kind"], "moving-rendered-window")
        self.assertEqual(review["history"]["priorObservationsRetained"], 8)
        self.assertEqual(review["trace"]["schema"], "progrss.node.bearing-trace.v1")
        self.assertEqual(len(review["trace"]["observations"]), 9)
        self.assertEqual(review["trace"]["observations"][0]["ordinal"], 1)
        self.assertTrue(review["trace"]["observations"][-1]["current"])
        self.assertEqual(review["recipeFootprint"]["schema"], "progrss.node.recipe-footprint.v1")
        self.assertFalse(review["network"])
        self.assertFalse(review["writes"])
        self.assertEqual(after.sha256, before.sha256)
        self.assertEqual(after.revision, before.revision)

    def test_store_refuses_non_store_and_snapshot_export_never_overwrites(self) -> None:
        with self.assertRaisesRegex(NodeStoreError, "not a ProgRSS Node-owned library"):
            NodeStore(FIX / "sample-backup.json")
        node = NodeState(backup=self.store_path, token="master", store=self.store)
        token, preview = node.create_branch_operation_preview(source_list(), folder="branch-new", now=1_792_449_060.0)
        receipt, _ = node.commit_branch_operation(
            operation_id="op-snapshot-1234567890ab",
            base_sha256=str(preview["library"]["sha256"]), preview_token=token,
            preview_digest=str(preview["previewDigest"]), now=1_792_449_120.0,
        )
        snapshot_id = receipt["rollbackEvidence"]["snapshotId"]
        output = self.directory / "before.json"
        evidence = self.store.export_snapshot(snapshot_id, output)
        self.assertEqual(evidence["operationId"], receipt["operationId"])
        self.assertEqual(output.read_bytes(), (FIX / "sample-backup.json").read_bytes())
        with self.assertRaisesRegex(NodeStoreError, "already exists"):
            self.store.export_snapshot(snapshot_id, output)


if __name__ == "__main__":
    unittest.main()
