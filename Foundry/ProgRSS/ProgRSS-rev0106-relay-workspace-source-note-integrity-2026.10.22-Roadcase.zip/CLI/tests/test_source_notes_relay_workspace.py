from __future__ import annotations

import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve()
CLI_DIR = HERE.parents[1]
if str(CLI_DIR) not in sys.path:
    sys.path.insert(0, str(CLI_DIR))

import relay


class SourceNotesRelayWorkspaceTests(unittest.TestCase):
    def wrapper(self) -> dict:
        return {
            "schema": "progrss.backup.v1",
            "exportedAt": "2026-10-22T12:00:00Z",
            "producer": {"name": "ProgRSS", "version": "0.80.0", "revision": "rev0080"},
            "state": {
                "version": 17,
                "sources": [
                    {"id": "shared", "title": "Shared source", "type": "rss", "url": "https://example.test/feed.xml", "enabled": False},
                    {"id": "plain", "title": "Plain source", "type": "rss", "url": "https://plain.test/feed.xml", "enabled": False},
                ],
                "collections": [
                    {"id": "alpha", "title": "Alpha", "mode": "union", "version": 1, "members": [
                        {"kind": "source", "id": "shared", "reason": "Alpha reason.\nSecond line."},
                        {"kind": "source", "id": "plain"},
                    ]},
                    {"id": "beta", "title": "Beta", "mode": "union", "version": 1, "members": [
                        {"kind": "source", "id": "shared", "reason": "سبب بيتا."},
                    ]},
                ],
                "items": [],
                "snapshots": {},
                "retiredReceipts": [],
            },
        }

    def incoming_state(self) -> dict:
        return {
            "version": 17,
            "sources": [
                {"id": "incoming", "title": "Incoming source", "type": "rss", "url": "https://incoming.test/feed.xml", "enabled": False},
            ],
            "collections": [
                {"id": "incoming-folder", "title": "Incoming", "mode": "union", "version": 1, "members": [
                    {"kind": "source", "id": "incoming", "reason": "Incoming curator reason."},
                ]},
            ],
            "items": [],
            "snapshots": {},
            "retiredReceipts": [],
        }

    @staticmethod
    def reason_member(document: dict, folder_id: str = "alpha", index: int = 0) -> dict:
        folder = next(row for row in document["state"]["collections"] if row["id"] == folder_id)
        return folder["members"][index]

    @staticmethod
    def write(folder: Path, document: dict, name: str) -> Path:
        path = folder / name
        path.write_text(json.dumps(document, ensure_ascii=True), encoding="utf-8")
        return path

    def write_bundle(self, folder: Path) -> Path:
        bundle = relay.make_bundle(
            self.incoming_state(),
            "incoming-folder",
            curator="Incoming curator",
            exported_at="2026-10-22T12:00:00.000Z",
        )
        path = folder / "incoming.json"
        path.write_text(json.dumps(bundle, ensure_ascii=False), encoding="utf-8")
        return path

    def invalid_documents(self) -> list[tuple[str, dict, str]]:
        rows: list[tuple[str, dict, str]] = []

        over_limit = self.wrapper()
        self.reason_member(over_limit)["reason"] = "😀" * 281
        rows.append(("over-limit", over_limit, "280"))

        wrong_level = self.wrapper()
        wrong_level["state"]["collections"][0]["members"].append({"kind": "collection", "id": "beta", "reason": "Wrong level"})
        rows.append(("wrong-level", wrong_level, "direct source placement"))

        folder_reason = self.wrapper()
        folder_reason["state"]["collections"][0]["reason"] = "Wrong level"
        rows.append(("folder-reason", folder_reason, "on the folder"))

        duplicate = self.wrapper()
        duplicate["state"]["collections"][0]["members"].insert(1, {"kind": "source", "id": "shared", "reason": "Alpha reason.\nSecond line."})
        rows.append(("duplicate", duplicate, "appear exactly once"))

        whitespace = self.wrapper()
        self.reason_member(whitespace)["reason"] = " \t\n "
        rows.append(("whitespace-only", whitespace, "empty Source Note"))

        edge_whitespace = self.wrapper()
        self.reason_member(edge_whitespace)["reason"] = "  Alpha reason.  "
        rows.append(("edge-whitespace", edge_whitespace, "noncanonical Source Note"))

        non_string = self.wrapper()
        self.reason_member(non_string)["reason"] = 42
        rows.append(("non-string", non_string, "must be a string"))

        invalid_unicode = self.wrapper()
        self.reason_member(invalid_unicode)["reason"] = "bad\ud800value"
        rows.append(("invalid-unicode", invalid_unicode, "Unicode scalar"))

        missing_source = self.wrapper()
        self.reason_member(missing_source)["id"] = "not-present"
        rows.append(("missing-source", missing_source, "missing source"))
        return rows

    def test_valid_workspace_is_not_mutated_and_share_folder_preserves_route_reasons(self) -> None:
        document = self.wrapper()
        expected = copy.deepcopy(document)
        with tempfile.TemporaryDirectory() as temp_name:
            folder = Path(temp_name)
            backup = self.write(folder, document, "private.json")
            read_document, location = relay.read_workspace(backup)
            self.assertEqual(read_document, expected)
            self.assertEqual(location.state, expected["state"])

            output = folder / "alpha.json"
            completed = subprocess.run(
                [str(CLI_DIR / "progrss"), "workspace", "share-folder", str(backup), "alpha", "--output", str(output), "--json"],
                cwd=CLI_DIR, text=True, capture_output=True,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            summary = json.loads(completed.stdout)
            self.assertEqual(summary["sourceNoteCount"], 1)
            bundle = json.loads(output.read_text(encoding="utf-8"))
            reasons = [
                member.get("reason")
                for collection in bundle["collections"]
                for member in collection.get("members", [])
                if member.get("kind") == "source" and "reason" in member
            ]
            self.assertEqual(reasons, ["Alpha reason.\nSecond line."])
            self.assertEqual(json.loads(backup.read_text(encoding="utf-8")), expected)

    def test_valid_import_preserves_existing_and_incoming_reasons_exactly(self) -> None:
        with tempfile.TemporaryDirectory() as temp_name:
            folder = Path(temp_name)
            backup = self.write(folder, self.wrapper(), "private.json")
            bundle = self.write_bundle(folder)
            output = folder / "updated.json"
            completed = subprocess.run(
                [str(CLI_DIR / "progrss"), "workspace", "import-bundle", str(backup), str(bundle), "--output", str(output), "--json"],
                cwd=CLI_DIR, text=True, capture_output=True,
            )
            self.assertEqual(completed.returncode, 0, completed.stderr)
            updated = json.loads(output.read_text(encoding="utf-8"))["state"]
            reasons = sorted(
                member["reason"]
                for collection in updated["collections"]
                for member in collection.get("members", [])
                if member.get("kind") == "source" and "reason" in member
            )
            self.assertEqual(reasons, sorted(["Alpha reason.\nSecond line.", "سبب بيتا.", "Incoming curator reason."]))

    def test_all_malformed_forms_are_refused_before_import_output(self) -> None:
        for name, document, pattern in self.invalid_documents():
            with self.subTest(name=name), tempfile.TemporaryDirectory() as temp_name:
                folder = Path(temp_name)
                backup = self.write(folder, document, f"{name}.json")
                bundle = self.write_bundle(folder)
                output = folder / "updated.json"
                with self.assertRaisesRegex(relay.RelayError, pattern):
                    relay.read_workspace(backup)
                completed = subprocess.run(
                    [str(CLI_DIR / "progrss"), "workspace", "import-bundle", str(backup), str(bundle), "--output", str(output), "--json"],
                    cwd=CLI_DIR, text=True, capture_output=True,
                )
                self.assertEqual(completed.returncode, 2, (name, completed.stdout, completed.stderr))
                self.assertEqual(completed.stdout, "")
                self.assertRegex(completed.stderr, pattern)
                self.assertFalse(output.exists())

    def test_every_relay_workspace_command_hits_the_validated_loader_before_side_effects(self) -> None:
        document = self.wrapper()
        self.reason_member(document)["reason"] = "X" * 281
        with tempfile.TemporaryDirectory() as temp_name:
            folder = Path(temp_name)
            backup = self.write(folder, document, "malformed.json")
            bundle = self.write_bundle(folder)
            commands = [
                ["workspace", "share-folder", str(backup), "alpha", "--output", str(folder / "share.json"), "--json"],
                ["workspace", "publish-folder", str(backup), "alpha", "--update-url", "https://example.test/latest.json", "--output", str(folder / "site.zip"), "--json"],
                ["workspace", "import-bundle", str(backup), str(bundle), "--output", str(folder / "imported.json"), "--json"],
                ["workspace", "review-bundle", str(backup), str(bundle), "--json"],
                ["workspace", "check-publication", str(backup), "alpha", "--json"],
                ["workspace", "update-bundle", str(backup), str(bundle), "--output", str(folder / "updated.json"), "--json"],
            ]
            for args in commands:
                with self.subTest(command=" ".join(args[:2])):
                    completed = subprocess.run(
                        [str(CLI_DIR / "progrss"), *args], cwd=CLI_DIR, text=True, capture_output=True,
                    )
                    self.assertEqual(completed.returncode, 2, (args, completed.stdout, completed.stderr))
                    self.assertEqual(completed.stdout, "")
                    self.assertIn("invalid Source Notes", completed.stderr)
                    self.assertIn("280", completed.stderr)
            self.assertFalse((folder / "share.json").exists())
            self.assertFalse((folder / "site.zip").exists())
            self.assertFalse((folder / "imported.json").exists())
            self.assertFalse((folder / "updated.json").exists())

    def test_write_workspace_refuses_malformed_derived_state_before_output(self) -> None:
        document = self.wrapper()
        with tempfile.TemporaryDirectory() as temp_name:
            folder = Path(temp_name)
            backup = self.write(folder, document, "private.json")
            read_document, location = relay.read_workspace(backup)
            malformed_state = copy.deepcopy(location.state)
            malformed_state["collections"][0]["members"][0]["reason"] = "X" * 281
            output = folder / "should-not-exist.json"
            with self.assertRaisesRegex(relay.RelayError, "refused to write invalid Source Notes"):
                relay.write_workspace(read_document, location, malformed_state, output)
            self.assertFalse(output.exists())



if __name__ == "__main__":
    unittest.main()
