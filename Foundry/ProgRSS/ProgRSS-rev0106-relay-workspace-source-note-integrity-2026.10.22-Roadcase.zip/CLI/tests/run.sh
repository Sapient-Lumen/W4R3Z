#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$HERE/.."
python -m unittest discover -s tests -v
python -m py_compile progrss.py
./progrss doctor
