from __future__ import annotations

import copy
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from debrief import (  # noqa: E402
    DEBRIEF_KIT_SCHEMA,
    DEBRIEF_REPORT_SCHEMA,
    DebriefError,
    build_debrief_workspace,
    render_debrief_html,
    validate_fieldwork_report,
)


class DebriefTests(unittest.TestCase):
    def report(self, *, wrong_turn: bool = False, suffix: str = "") -> dict[str, object]:
        tasks = []
        outcomes = {"independent": 0, "neutral-prompt": 0, "wrong-turn": 0, "not-observed": 0}
        for index in range(1, 13):
            outcome = "wrong-turn" if wrong_turn and index in {2, 4} else "independent"
            outcomes[outcome] += 1
            tasks.append({
                "id": f"task-{index}",
                "title": f"Task {index}",
                "outcome": outcome,
                "notes": f"Observed note {index}{suffix}" if index <= 2 else "",
            })
        return {
            "schema": "progrss.fieldwork-report.v1",
            "scenario": "trace-bearing-anchor",
            "scenarioDigest": "a" * 64,
            "release": {"version": "0.76.0", "revision": "rev0076", "codename": "Fieldbook"},
            "generatedFromKitAt": "2026-10-20T20:00:00Z",
            "completedAt": f"2026-10-20T20:0{suffix or '0'}:00Z",
            "outcomes": outcomes,
            "tasks": tasks,
            "facilitatorBoundary": {
                "testedProductNotParticipant": True,
                "avoidedSensitiveNotes": True,
                "exactReleaseOpen": True,
            },
            "privacy": {
                "participantIdentityRecorded": False,
                "automaticPersistence": False,
                "telemetry": False,
                "network": False,
            },
        }

    def test_report_validation_is_strict_and_privacy_bounded(self) -> None:
        report = validate_fieldwork_report(self.report())
        self.assertEqual(report["schema"], "progrss.fieldwork-report.v1")
        self.assertEqual(len(report["tasks"]), 12)
        self.assertFalse(report["privacy"]["participantIdentityRecorded"])

        unknown = self.report()
        unknown["participantName"] = "Do not copy"
        with self.assertRaisesRegex(DebriefError, "unknown field participantName"):
            validate_fieldwork_report(unknown)

        inconsistent = self.report()
        inconsistent["outcomes"]["independent"] = 0
        with self.assertRaisesRegex(DebriefError, "totals do not match"):
            validate_fieldwork_report(inconsistent)

        unsafe = self.report()
        unsafe["privacy"]["participantIdentityRecorded"] = True
        with self.assertRaisesRegex(DebriefError, "privacy boundary"):
            validate_fieldwork_report(unsafe)

    def test_workspace_deduplicates_and_refuses_mixed_scenarios(self) -> None:
        first = self.report(suffix="1")
        second = self.report(wrong_turn=True, suffix="2")
        workspace = build_debrief_workspace(
            [first, copy.deepcopy(first), second],
            version="0.80.0",
            revision="rev0080",
            codename="Roadcase",
            generated_at="2026-10-20T21:00:00Z",
        )
        self.assertEqual(workspace["schema"], DEBRIEF_KIT_SCHEMA)
        self.assertEqual(len(workspace["preloadedReports"]), 2)
        self.assertEqual(workspace["duplicatesRemoved"], 1)
        self.assertFalse(workspace["privacy"]["rawNotesExported"])

        mixed = self.report(suffix="3")
        mixed["scenarioDigest"] = "b" * 64
        with self.assertRaisesRegex(DebriefError, "different Fieldbook scenario"):
            build_debrief_workspace(
                [first, mixed], version="0.80.0", revision="rev0080", codename="Roadcase",
                generated_at="2026-10-20T21:00:00Z",
            )

    def test_html_is_self_contained_local_only_and_exports_no_raw_notes(self) -> None:
        workspace = build_debrief_workspace(
            [self.report(suffix="1"), self.report(wrong_turn=True, suffix="2")],
            version="0.80.0",
            revision="rev0080",
            codename="Roadcase",
            generated_at="2026-10-20T21:00:00Z",
        )
        raw = render_debrief_html(workspace)
        text = raw.decode("utf-8")
        self.assertIn("Find patterns. Do not score people.", text)
        self.assertIn(DEBRIEF_KIT_SCHEMA, text)
        self.assertIn(DEBRIEF_REPORT_SCHEMA, text)
        self.assertIn("Recurring wrong turn to review", text)
        self.assertIn("raw facilitator notes are not included", text.lower())
        self.assertIn("Download JSON debrief", text)
        self.assertIn("connect-src 'none'", text)
        self.assertIn("rawNotesExported:false", text)
        self.assertNotIn("https://", text)
        self.assertNotIn("http://", text)
        self.assertNotIn("fetch(", text)
        self.assertNotIn("XMLHttpRequest", text)
        self.assertNotIn("WebSocket", text)
        self.assertNotIn("sendBeacon", text)
        self.assertNotIn("localStorage", text)
        self.assertNotIn("sessionStorage", text)
        self.assertNotIn("indexedDB", text)
        self.assertNotIn("serviceWorker", text)
        self.assertNotIn("participantName", text)

    def test_blank_workspace_is_valid_for_browser_local_import(self) -> None:
        workspace = build_debrief_workspace(
            [], version="0.80.0", revision="rev0080", codename="Roadcase",
            generated_at="2026-10-20T21:00:00Z",
        )
        self.assertEqual(workspace["preloadedReports"], [])
        self.assertEqual(workspace["debriefSchema"], DEBRIEF_REPORT_SCHEMA)
        self.assertGreater(len(render_debrief_html(workspace)), 20_000)


if __name__ == "__main__":
    unittest.main()
