# ProgRSS Bearing — explain repeated held page windows before repair

Bearing is the rev0074 read-only diagnostic boundary for watched pages whose browser-assisted observations were held by Drift.

The sequence is:

```text
Capture one rendered page
  ↓
Drift holds an unsafe partial-window comparison
  ↓
Repeat deliberate observations, when needed
  ↓
Bearing explains the bounded pattern without changing anything
  ↓
Keep the accepted baseline, open Anchor, or begin a fresh Capture
```

Bearing is not a selector editor, automatic repair engine, baseline writer, page fetcher, scheduler, or paired-Extension capability.

## Why this review exists

One held rendering establishes only that two partial observations were not safe to compare literally. Repeated observations may provide more useful evidence:

- similarly sized partial windows may expose substantially different records;
- pagination, overlays, loading state, frames, or partial-render boundaries may change;
- the observations may still be too few or too inconsistent to explain.

Bearing turns those cases into bounded, ordinary-language diagnoses without claiming certainty.

## Store schema and bounded history

The local Node store advances to:

```text
progrss.node-store.v4
```

The existing `capture_holds` table continues to hold the current unresolved observation for one watched-page source. The new `capture_hold_history` table retains at most eight prior unresolved observations for that same source.

Each retained row contains only bounded Node-local evidence needed for review:

```text
source ID and source-identity digest
Capture operation and receipt IDs
hold time and library digest
accepted and proposed snapshot digests
bounded proposed snapshot
bounded Capture provenance
Node-computed continuity evidence
```

A new hold moves the previous current hold into history and prunes older entries beyond the fixed limit. A later accepted observation or an Anchor replacement clears the current hold and its prior unresolved history.

The history does not travel through:

```text
progrss.private.v1 export
source lists
OPML
Exchange
branch excerpts
static publication
recent-updates feeds
Extension pairing
Pulse timing databases
```

Migration from v1, v2, or v3 adds the local evidence table in one transaction. It does not rewrite the portable library bytes or increment the portable-library revision merely because the store schema changed.

## Read-only API

The local administrator requests:

```http
POST /api/v1/bearing-reviews
Authorization: Bearer NODE_ADMIN_CAPABILITY
Origin: http://127.0.0.1:PORT
Content-Type: application/json

{"sourceId":"SOURCE_ID"}
```

The response schema is:

```text
progrss.node.bearing-review.v2
```

The endpoint performs:

```json
{
  "network": false,
  "writes": false
}
```

Before producing a review, the Node verifies that:

- the selected library is Node-owned;
- the source exists and is a watched page;
- a current unresolved hold exists;
- the source acquisition identity still matches the hold;
- the accepted baseline still matches the baseline referenced by the hold;
- retained snapshots and digests remain valid.

## Diagnoses

### Moving rendered window

Bearing may report this when compatible partial observations have similar bounded sizes and their held-to-held stable overlap remains below the project’s conservative 35-percent policy.

It means:

> Several similarly sized partial observations expose substantially different records. The browser may be showing different windows into one larger collection.

It does not prove that records were preserved, removed, added, or that the publisher intended one logical collection.

The suggested route is Anchor when the current held rendering is the deliberate future comparison point.

### Page boundary shifted

Bearing reports this when compatible observations expose different page-boundary evidence, such as changes in:

```text
partial rendering
continuation or pagination
visible overlays
loading state
frame exclusions
```

It does not prove that a selector is wrong or that records changed. The suggested route is a fresh Capture so the person can reconsider the current rendered page and watched section.

### Not enough evidence yet

Bearing reports this when there are too few compatible observations, insufficient comparison material, or no coherent bounded pattern.

The suggested route is to keep the accepted baseline. Another deliberate Capture may later add evidence.

## No confidence score

Bearing exposes the evidence it actually has:

```text
number of observations reviewed
compatible prior observations
boundary kinds
bounded overlap comparisons
accepted and proposed snapshot summaries
operation and receipt references under Advanced
```

It does not turn those values into a percentage that purports to measure truth, page completeness, publisher intent, or repair confidence.

## Three exits

### Keep accepted baseline

This closes the review. It performs no write and no site request.

### Open Anchor

This enters the existing `replace-held-page-baseline` preview. Opening Anchor is still read-only. Replacement remains unavailable until the separate Anchor acknowledgement, stale-base checks, preview digest, idempotency key, and typed commit all succeed.

### Begin a fresh Capture

This creates a new one-use browser-assisted request for the exact watched page. It does not perform Capture automatically, read the page in the background, or import browser credentials.

## Extension and pairing boundary

The paired Extension receives no Bearing history, held snapshots, source addresses, administrator capability, or repair endpoint.

Pairing remains:

```text
readLibrarySummary = true
readItems = false
readSourceAddresses = false
writeLibrary = false
fetchSources = false
publish = false
merge = false
nodeToNode = false
webrtcCourier = false
```

The Extension can still conduct a separate deliberate Capture when given one short-lived Capture invitation.

## Human acceptance questions

An unfamiliar administrator should be able to explain:

1. Did opening Bearing change the baseline? No.
2. Did Bearing contact the watched site? No.
3. Is “Moving rendered window” a proven fact? No; it is a bounded explanation of observed evidence.
4. Does **Open Anchor** immediately replace anything? No.
5. Does **Begin a fresh Capture** automatically inspect the browser page? No.
6. Can the paired Extension perform the repair? No.
7. What should happen when the boundary itself changed? Review the rendered page again through Capture.
8. What should happen when the current held rendering is intentionally the new comparison point? Review it through Anchor.

Confusion should change the interface wording or hierarchy. It should not lead to silent selector replacement, generic JSON Patch, arbitrary shared JavaScript, automatic browser control, or ambient synchronization.

## Trace evidence

rev0075 adds one `progrss.node.bearing-trace.v1` oldest-to-newest observation trail and one `progrss.node.recipe-footprint.v1` explanation. Both remain read-only. Exact selectors and hashes remain Advanced evidence; Anchor and fresh Capture remain separate decisions.
