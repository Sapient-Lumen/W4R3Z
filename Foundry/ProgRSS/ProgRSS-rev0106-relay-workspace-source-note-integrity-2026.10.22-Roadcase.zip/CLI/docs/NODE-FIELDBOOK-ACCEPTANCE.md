# ProgRSS Fieldbook acceptance protocol

This protocol evaluates the Fieldbook sidecar and the actual Trace/Bearing/Anchor interface. It does not evaluate the participant.

## Before the session

1. Use an unmanaged supported browser when testing installed Extension behavior.
2. Open the exact rev0076 Node interface in one window.
3. Download the Fieldbook for that exact Trace review.
4. Open the Fieldbook in another window or print a blank sheet.
5. Do not enter a participant name, email address, account identifier, or sensitive page content.
6. Explain that wrong turns are evidence about ProgRSS wording and hierarchy.
7. Do not coach the participant through the answer before recording the initial response.

## Core tasks

Run all twelve tasks in the generated sheet. For every task, record one outcome:

```text
Understood independently
Understood after a neutral prompt
Wrong turn or unsafe interpretation
Not observed
```

Record observable behavior. Prefer:

```text
“Participant opened Advanced after asking where exact evidence lives.”
```

over:

```text
“Participant is confused.”
```

## Required comprehension checks

Ask the participant to explain, in their own words:

- Which point future comparisons currently use.
- Which observation is waiting for a later decision.
- Whether the trail is complete publisher history.
- Whether **Different window** proves deletion.
- Whether overlap is a confidence score.
- Whether a semantic selector is guaranteed permanent.
- Whether Keep contacts the site or changes the library.
- Whether Open Anchor immediately performs a write.
- Whether fresh Capture has already contacted the page.
- Whether a paired Extension can replace the baseline.
- Where exact selector and receipt evidence live.
- Whether simply opening Trace made a request or write.

## Assistive-technology and alternative-input sessions

Repeat the critical path under the conditions actually claimed by the release:

```text
keyboard only
screen reader
Braille display when available
voice control
switch-style sequential navigation
200–400 percent zoom
forced colors or high contrast
reduced motion
fatigue and interruption
```

Confirm that:

- Task legends are announced in order.
- Radio groups expose one coherent label per task.
- The notes field has a programmatic label and length information.
- Progress and review errors are announced without stealing focus unnecessarily.
- The facilitator can reach the privacy acknowledgement and both download controls.
- Dark, light, and forced-colors modes preserve readable boundaries.
- Printing hides interactive-only controls and keeps task prompts and outcomes legible.

## Privacy review

Before downloading a report:

1. Read every note.
2. Remove names, credentials, health or financial information, private article text, and unnecessary quoted page content.
3. Confirm that the report contains no participant identity field.
4. Confirm that the scenario contains no source address or selector.
5. Acknowledge the privacy check.
6. Save the report only to the intended local location.

## Failure conditions

Treat any of the following as a product finding rather than a participant failure:

```text
Different window is interpreted as confirmed deletion
Semantic boundary is interpreted as permanent
Open Anchor is interpreted as an immediate write
fresh Capture is interpreted as an automatic site request
Keep is interpreted as a refresh or mutation
paired Extension is interpreted as administrator authority
exact evidence cannot be found when requested
Fieldbook is mistaken for the product interface
notes are believed to upload automatically
```

Change wording, hierarchy, or interaction in response to repeated wrong turns before adding automatic repair.

## What this protocol cannot establish

A completed checklist cannot establish broad usability, accessibility, safety, or comprehension for all people. Document participant context and test conditions outside ProgRSS only where consent and study policy allow. Do not put those details into the generated Fieldbook report by default.
