# ProgRSS Threshold — explicit rendered-view coverage decisions

Threshold is the rev0071 boundary for browser-assisted Capture.

Perimeter already separated:

```text
section stability
page completeness
```

Threshold adds the missing human decision. When the rendered page reports any
limiting boundary, the Extension cannot submit the artifact until the person
chooses either:

```text
Capture the page again first
Use this rendered view as the baseline
```

The choice is not a generic warning dismissal. It is serialized as one strict
review object and validated again by the Node.

## Limiting boundary kinds

These page-context kinds require explicit review:

```text
continuation
partial-render
overlay
loading
frames
```

`open-shadow` remains informational because the open roots counted by the
extractor were included in the bounded query-root walk. Closed shadow content
remains outside the contract, as already explained by Perimeter.

## Artifact contract

New submissions use:

```text
progrss.browser-capture.v4
```

They retain:

```text
progrss.capture-page-context.v1
progrss.capture-selection.v1
progrss.capture-section-assessment.v1
```

and add:

```text
progrss.capture-coverage-review.v1
```

The exact object is:

```json
{
  "schema": "progrss.capture-coverage-review.v1",
  "decision": "use-current-rendering",
  "acknowledgedNoticeKinds": [
    "continuation",
    "partial-render",
    "overlay",
    "frames"
  ]
}
```

When there are no limiting notices, the only valid form is:

```json
{
  "schema": "progrss.capture-coverage-review.v1",
  "decision": "no-limiting-boundary-observed",
  "acknowledgedNoticeKinds": []
}
```

That phrase does not claim the page is complete. It records only that this
bounded rendering exposed no limiting notice recognized by this release.

## Exact validation

The Node recomputes the limiting kinds from the strict page-context object.
It refuses the artifact when:

```text
the coverage object is absent from v4
an acknowledged kind is absent from page context
a visible limiting kind is omitted
kinds are duplicated or reordered
the no-limiting decision is used while a limiting notice exists
the use-current-rendering decision is used without a limiting notice
an unknown field, decision, or kind appears
```

A v4 artifact therefore cannot say merely “the person accepted something.” It
must name exactly the visible limits being accepted.

## Human interface

The ordinary review order is:

```text
page coverage boundaries
rendered-section choices
matched and ignored examples
section-stability evidence
coverage decision, when required
recipe-change decision, when required
one final send action
```

The final action stays disabled until every required decision is explicit.
Recapturing clears the coverage acknowledgement because it creates a new page
observation.

The copy states that ProgRSS will not:

```text
follow pagination
scroll a virtual list
click or dismiss controls
wait for loading
read frame contents
```

## Durable evidence

The Node receipt retains:

```text
coverageReviewSchema
coverageDecision
acknowledgedBoundaryKinds
partialViewAcknowledged
```

The portable source also retains those bounded facts in its local
`browserCapture` provenance. They remain outside:

```text
source identity
recipe identity
duplicate detection
publication identity
Pulse scheduling eligibility
pairing authority
```

A browser-assisted capture remains ineligible for Pulse, regardless of whether
its current rendered view was explicitly accepted.

## Rolling upgrade

The Node reads:

```text
v4  page context + explicit coverage review
v3  page context, no invented coverage review
v2  section assessment, no invented page context or coverage review
v1  original bounded artifact, no invented later evidence
```

Older artifacts are not rewritten to imply that a person acknowledged a choice
that their Extension never presented.

## Authority and privacy

Threshold changes no browser or Node authority.

```text
exact active reviewed page only
top frame only
isolated extension world
fixed packaged extractor
bounded JSON-safe text and links
zero Node watched-site requests
no schedule
no cookie, credential, storage, raw HTML, form value, screenshot, or script transfer
summary-only Extension pairing
```

## Acceptance questions

Ask an unfamiliar participant:

1. What might be missing from this rendered view?
2. Did ProgRSS follow the next page or scroll the list?
3. What happens if you choose Capture the page again first?
4. What exactly does Use this rendered view as the baseline accept?
5. Does the decision create a schedule?
6. Does the Node receive the browser login?
7. Why is the watched-section checkbox separate?
8. After recapture, should the earlier coverage choice still count?

Observed wrong answers should change wording or hierarchy. They should not be
answered by hidden scrolling, automatic clicks, background tabs, cookie
transfer, or arbitrary page-supplied code.
