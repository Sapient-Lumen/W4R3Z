# ProgRSS Perimeter — rendered-page coverage evidence

Perimeter extends browser-assisted Capture with a second, separate question:

```text
Section stability
  Is the selected section structurally understandable in this rendering?

Page completeness
  What may lie outside the rendered evidence ProgRSS can observe now?
```

A selector can identify a region while the page still continues to another page,
virtualizes most rows, hides useful content behind an overlay, renders inside an
embedded frame, or has not finished loading. Perimeter reports those boundaries
before the person submits a Capture artifact.

## Human interface

The Extension shows **What this browser view may leave outside** before the
rendered-section choices. At most six bounded notices can appear:

| Notice | Ordinary consequence |
| --- | --- |
| Page continues | Another page, next link, pager, or load-more control was observed. Only this rendering is captured. |
| Partial rendering | The DOM may contain only part of a declared or scroll-windowed list. |
| Visible overlay | A modal or consent layer may conceal useful content. |
| Still loading | A rendered region still reports a busy state. |
| Frames excluded | Embedded frame contents remain outside top-frame Capture. |
| Open shadow inspected | Bounded open shadow roots were inspected; closed shadow content remains outside. |

Each notice is labelled **Outside capture**, **Check first**, or **Included**.
These labels describe page coverage. They do not raise or lower the independent
**More likely to stay put / Needs watching / Fragile** section label.

When a page appears incomplete, the ordinary recovery is explicit:

```text
scroll or load more
  → dismiss an overlay when appropriate
  → wait for loading to finish
  → Capture the page again
```

ProgRSS does not click controls or continue pagination automatically.

## Extractor boundary

The fixed packaged extractor remains:

```text
top-frame only
isolated extension world
exact reviewed active page
at most three section candidates
at most six page-context notices
plain JSON-safe output
```

It traverses open shadow roots only within explicit element, query-root, and
result bounds. It does not pierce closed shadow roots. It does not inspect
cross-origin frame documents. Frame elements can be counted as an exclusion
boundary, but their contents are not captured.

The extractor does not transfer:

```text
cookies or credentials
browser storage
form values
raw HTML or DOM nodes
screenshots
page scripts
Extension or Node capabilities
```

## Artifact schemas

New candidate observations use:

```text
progrss.browser-capture-candidates.v3
```

New submitted artifacts use:

```text
progrss.browser-capture.v3
```

The additional field is:

```text
context.schema = progrss.capture-page-context.v1
```

`context.notices` is a bounded list whose kinds and tones are fixed. Its
`signals` object contains bounded integer counts for:

```text
continuationLinks
paginationLandmarks
continuationControls
partialSetSignals
virtualMarkers
scrollWindows
modalLayers
embeddedFrames
openShadowRoots
busyRegions
```

The Node requires notices and signals to agree. Unknown fields, unknown kinds,
duplicate kinds, unsupported tones, inconsistent presence, negative values, and
out-of-range counts are refused.

The provenance revision is:

```text
perimeter-v1
```

Rolling local upgrades remain supported:

```text
v3  page context + section assessment
v2  section assessment only
v1  original bounded Capture artifact
```

The Node does not invent page-context or section evidence absent from an older
artifact.

## Receipt evidence

A successful v3 Capture receipt retains:

```text
page-context schema
notice kinds
possible continuation
possible partial rendering
modal-layer count
embedded-frame count
open-shadow-root count
busy-region count
```

The receipt still leads with human consequences: baseline or change, items
added, zero Node-side watched-site requests, resulting library revision, and no
schedule.

Page-context evidence is not acquisition identity. It does not make a Capture
receipt eligible for Pulse scheduling and does not alter duplicate-source or
recipe identity.

## Fixture garden

The delivered browser fixtures cover:

```text
semantic repeated entries with hidden duplicates
pagination and continuation links
virtualized or partially declared lists
visible overlays
embedded frames plus open shadow roots
busy/loading regions
right-to-left direction
```

The fixtures are regression evidence. They are not a substitute for native
signed-in pages, unfamiliar humans, or assistive-technology sessions.

## Non-goals

Perimeter does not add:

```text
automatic pagination
infinite-scroll driving
frame traversal
closed-shadow access
headless browsing
arbitrary shared JavaScript
direct point-to-region selection
scheduler authority
background browser control
```

Direct point-to-region selection remains a possible later boundary only if
fieldwork demonstrates that the current bounded candidates cannot express what
people need.
