# ProgRSS Node Debrief contract

Debrief is a private, local-only workspace for comparing several already exported ProgRSS Fieldbook reports. It helps a facilitator identify repeated observed wrong turns, prompt dependence, and coverage gaps without scoring participants or declaring that ProgRSS passed.

```text
Version:       0.80.0
Revision:      rev0080
Codename:      Debrief
Workspace:     progrss.fieldwork-debrief-kit.v1
Input report:  progrss.fieldwork-report.v1
Output:        progrss.fieldwork-debrief.v1
```

## Product boundary

Debrief is research infrastructure, not the participant-facing product. The actual Extension and Node interfaces remain the subject of the sessions. Debrief only reads local JSON reports that a facilitator previously exported from Fieldbook.

Debrief performs no:

```text
network request
telemetry
participant lookup
Node-library read or write
browser-profile read
permission-store read
automatic persistence
participant score
product pass/fail calculation
automatic wording or recipe change
```

## Generate a workspace

From the authenticated Node GUI, expand **Research and acceptance** and choose **Download debrief workspace**.

From the CLI, generate a blank workspace:

```sh
./progrss node debrief \
  --output ProgRSS-Debrief.html
```

Or strictly validate and preload compatible reports:

```sh
./progrss node debrief \
  report-1.json report-2.json report-3.json \
  --output ProgRSS-Debrief.html
```

Machine-readable generation evidence:

```sh
./progrss node debrief \
  report-1.json report-2.json \
  --output ProgRSS-Debrief.html \
  --json
```

Output is new-file-only and never overwrites an existing path.

## Input validation

Each report must contain exactly the known `progrss.fieldwork-report.v1` fields. Unknown top-level, task, release, privacy, or facilitator-boundary fields are refused rather than silently copied into the workspace.

Reports must agree on:

```text
scenario
scenario digest
release
ordered task IDs
task titles
outcome vocabulary
```

Outcome totals must exactly match the task outcomes. The original Fieldbook privacy boundary must still say:

```text
participantIdentityRecorded: false
automaticPersistence: false
telemetry: false
network: false
```

Exact canonical duplicates are ignored. Debrief accepts at most 40 reports, at most 256,000 bytes per report, and at most 4,000,000 selected bytes in one workspace.

## Local analysis

The workspace aggregates four observations per task:

```text
Understood independently
Understood after a neutral prompt
Wrong turn or unsafe interpretation
Not observed
```

It may surface bounded review signals:

```text
One report only
Recurring wrong turn to review
Prompt-dependent understanding to review
Coverage gap
No recurring signal yet
```

Those are routing aids, not statistical claims. They describe only the loaded reports and do not establish prevalence among all users.

The facilitator selects one disposition per task:

```text
Product change to try
More sessions needed
No product change yet
Not reviewed
```

The facilitator may write one bounded finding and one bounded product response. Each is limited to 500 characters.

## Notes boundary

Raw Fieldbook notes are visible only inside the current local page so the facilitator can understand the observations. They are deliberately omitted from both JSON and Markdown debrief exports.

Debrief does not claim that automatic text screening can reliably identify every sensitive detail. Before export, the facilitator must explicitly confirm that newly written findings and actions contain no names, contact details, sensitive page content, or other identifying information.

## Output contract

The reviewed export uses:

```text
progrss.fieldwork-debrief.v1
```

It contains:

```text
scenario and exact scenario digest
release
local creation time
number of loaded reports
aggregate task outcomes
bounded review signals
facilitator-selected disposition
newly written finding
newly written product response
interpretation boundary
privacy boundary
```

It does not contain:

```text
raw facilitator notes
participant identity
source address
saved selector
Capture artifact
snapshot content
Node capability
browser capability
operation or receipt ID
participant score
product pass percentage
```

## Browser-local behavior

The standalone page uses a strict Content Security Policy with `connect-src 'none'`. It uses no `fetch`, WebSocket, EventSource, WebRTC, service worker, remote image, remote font, remote stylesheet, `localStorage`, `sessionStorage`, or IndexedDB.

Reports and draft findings live only in the current page. Leaving with unsaved work triggers the ordinary browser leave-page warning. The page offers dark, light, forced-colors, reduced-motion, narrow-screen, keyboard, print, and status-message treatment.

## Node API

The authenticated local administrator endpoint is:

```text
POST /api/v1/debrief-kits
```

The request body must be an empty JSON object. It returns one blank self-contained HTML workspace with:

```text
X-ProgRSS-Schema: progrss.fieldwork-debrief-kit.v1
Content-Disposition: attachment; filename="ProgRSS-Debrief-rev0080.html"
```

It remains behind the existing literal-loopback, bearer-capability, exact `Host`, exact `Origin`, and no-CORS boundary.

## Authority remains unchanged

Debrief adds no Extension permission and no paired-Extension authority. A paired Extension cannot generate or upload reports, open administrator evidence, invoke Anchor, start Pulse, or mutate a Node library.

Fieldbook, Debrief, Trace, and Bearing remain read-only. Anchor remains the only typed writer at this held-window boundary.

## Interpretation boundary

A repeated wrong turn in two or more local reports is evidence worth reviewing. It is not proof that every person will make that error. A lack of wrong turns in a small set of sessions is not proof that the interface is usable or accessible.

The purpose of Debrief is to make the next product hypothesis explicit and reviewable—not to turn qualitative research into an engagement score.
