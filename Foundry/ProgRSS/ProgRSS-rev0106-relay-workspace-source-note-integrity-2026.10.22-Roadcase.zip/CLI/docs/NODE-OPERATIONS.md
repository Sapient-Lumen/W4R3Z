# ProgRSS Node reviewed operations

Receipt delivered the first Node-owned library and one narrow branch-adoption writer. Witness added a separate reviewed public acquisition contract. Capture retains both and adds one bounded rendered-page evidence contract. Neither is a general-purpose REST API, continuous synchronization, or an Extension pairing capability.

## Library boundary

Create a Node-owned library from one explicit `progrss.private.v1` backup:

```sh
progrss node init PRIVATE-BACKUP.json --output LIBRARY.sqlite3
```

The command:

- validates the complete bounded private backup;
- applies the shared direct-placement Source Notes audit before any SQLite file is created;
- refuses symlinks and existing output paths;
- preserves the exact imported backup bytes inside the store;
- initializes one current portable library revision;
- performs no DNS lookup, feed fetch, webpage fetch, browser-profile read, or permission inspection.

The canonical portable representation remains `progrss.private.v1`. SQLite is the Node's local single-writer transaction boundary, not a publication or exchange format.

The same Source Notes audit runs whenever a Node-owned library is opened, read, mutated, snapshotted, or exported, and before `progrss node serve BACKUP.json` serves a read-only backup. Valid route-specific reasons remain exact. Over-limit, wrong-level, duplicate, empty, noncanonical, non-string, invalid-Unicode, or missing-source reason placements are refused rather than stored, served, or silently repaired.

## Delivered operation

`adopt-source-list-branch` remains the only operation that changes source/folder membership. Witness separately permits `check-source-once` to retain one reviewed acquisition result. Its complete network, retry, receipt, and migration contract is documented in `NODE-ACQUISITION.md`. Browser-assisted rendered-page evidence is separately documented in `NODE-CAPTURE.md`.

The local administrator:

1. chooses one native ProgRSS source-list file;
2. chooses one populated nested simple-folder branch;
3. reviews its exact source names, hostnames, direct folder placements, optional curator reasons, folder closure, existing-source reuse, and paused additions;
4. acknowledges that the Node will write once, that no listed site will be contacted, and that a pre-operation snapshot will be retained;
5. commits the exact reviewed preview.

Complete-route adoption, later-copy application, arbitrary source edits, generic JSON Patch, filesystem writes, remote writes, and recurring scheduling remain unavailable. A feed or declarative page watch may now be checked only through the separate reviewed `check-source-once` contract; it cannot be smuggled through this branch operation.

The branch chooser reports the number of optional curator reasons in each adoptable branch. The exact preview places each reason beside the direct folder/source relationship it describes and identifies it as curator routing context, not a ProgRSS safety claim. A source can therefore show different reasons in different folders. Reason text is rendered as literal text, retains line breaks, and uses content-derived directionality. The operation preserves the same placement values in the committed native library; the preview does not contact any listed site.

## HTTP preconditions

The administrator operation endpoint accepts only a same-origin bearer-authenticated request to the loopback Node. A commit requires:

```text
operationType = adopt-source-list-branch
If-Match = one strong quoted SHA-256 of the reviewed base library
Idempotency-Key = 16–200 URL-safe characters
previewToken = one unexpired in-memory review capability
previewDigest = the exact reviewed preview digest
```

The preview is short-lived. The Node refuses a missing or weak precondition, an expired preview, a changed preview digest, an unsupported operation type, or a library that changed after review.

## Atomic commit and durable evidence

One SQLite transaction records:

```text
pre-operation private-backup snapshot
new complete private-backup document
new library digest and revision
operation receipt
request fingerprint used for replay checking
```

The receipt schema is `progrss.node.operation-receipt.v1`. It names:

- the operation and actor;
- commit time;
- reviewed base, preview, source-list, and resulting-library digests;
- resulting revision;
- selected branch;
- import summary;
- zero-network and paused-new-source effects;
- the pre-operation snapshot ID and digest.

A failure before commit, after snapshot insertion, after library replacement, or after receipt insertion rolls the whole transaction back. There is no state in which the new library exists without its receipt, or a receipt claims a library change that did not commit.

## Retry behavior

An exact retry with the same idempotency key and the same reviewed request returns the stored receipt with `replayed: true` and performs no additional write.

Reusing that key for different reviewed content is refused. A retry remains answerable after the in-memory preview has been consumed or the Node process has restarted because the request fingerprint and receipt are durable.

The header name follows the semantics under discussion in the IETF HTTPAPI `Idempotency-Key` Internet-Draft. That document is an expired draft, not a finished RFC. ProgRSS therefore documents and tests its exact local contract rather than claiming standards conformance.

## Recovery and export

List operation evidence:

```sh
progrss node receipts LIBRARY.sqlite3
```

Export the current portable library:

```sh
progrss node export LIBRARY.sqlite3 --output CURRENT.json
```

Export one pre-operation snapshot:

```sh
progrss node snapshot LIBRARY.sqlite3 SNAPSHOT_ID --output BEFORE.json
```

All exports are new-file-only. A snapshot is rollback evidence, not an automatic rollback control. A person may inspect it, compare it, or deliberately initialize another Node-owned library from it.

## Pairing boundary

A paired Extension may see that the selected library mode is `node-owned`, plus the selected filename, digest, revision-neutral bounded counts, and process-lifetime Node session fingerprint. Its capability contract remains:

```text
readLibrarySummary = true
readItems = false
readSourceAddresses = false
writeLibrary = false
fetchSources = false
publish = false
merge = false
nodeToNode = false
webrtcCourier = false
```

The first writer is intentionally not reachable through the pairing token. There is no automatic reconnect, background operation submission, or synchronization.

## Next operations

No second writer should be added merely because the transaction substrate exists. A future operation needs its own human preview, consequences, stale-base rules, replay semantics, durable receipt, recovery evidence, and unfamiliar-person acceptance task.

The leading next product boundary is durable acquisition rather than more mutation types: scheduled public feed retrieval and bounded page-watch execution in the Node, with explicit handoff to the Extension for authenticated or browser-rendered views.

## Anchor operation — replace one held page baseline

`replace-held-page-baseline` is the second typed Node write operation. It consumes one persisted Drift hold for one watched-page source after an offline review. The commit requires the exact base-library digest, exact preview digest, and one idempotency key. It atomically writes the new portable library, a complete before snapshot, a durable receipt, and the replay fingerprint while removing the consumed hold.

It changes only the future comparison baseline. It creates no historical page-change item, performs no network request, changes no recipe or source activity, creates no schedule, and remains unavailable to summary-only Extension pairing. See `NODE-ANCHOR.md`.

