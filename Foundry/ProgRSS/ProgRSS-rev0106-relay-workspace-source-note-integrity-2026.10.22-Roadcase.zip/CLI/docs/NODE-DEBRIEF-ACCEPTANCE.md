# ProgRSS Debrief acceptance protocol

This protocol evaluates the local Debrief workspace. It does not evaluate, rank, or certify participants.

## Setup

1. Use the exact rev0080 archive.
2. Conduct actual Fieldbook sessions separately with the real ProgRSS interface.
3. Export each reviewed `progrss.fieldwork-report.v1` JSON file locally.
4. Generate or download one rev0080 Debrief workspace.
5. Keep the workspace offline.
6. Use reports from the same exact scenario and task sequence.

## Import boundary

Confirm that the facilitator can:

- Choose multiple reports using the ordinary file picker.
- Understand that the files remain in the current page.
- Recognize that exact duplicates are ignored.
- Recognize why a mismatched scenario is refused.
- Recognize why an unknown participant field is refused.
- Clear the workspace without leaving stored browser data.

## Interpretation tasks

Ask the facilitator to explain:

- What a report count describes.
- Why the count is not a participant score.
- What **Recurring wrong turn to review** means.
- Why two wrong turns do not prove universal prevalence.
- What **Prompt-dependent understanding to review** means.
- What **Coverage gap** means.
- Why **No recurring signal yet** is not a product pass.
- Why **Product change to try** is a hypothesis.
- Why **More sessions needed** can be the appropriate result.
- Why **Not reviewed** is different from **No product change yet**.

## Notes and privacy

Confirm that:

- Raw notes are available locally under disclosure.
- Raw notes are absent from the JSON and Markdown debrief exports.
- No participant identity field is offered.
- Newly written findings can still accidentally contain identifying information.
- Export remains disabled until all three privacy and interpretation checks are acknowledged.
- No report or debrief is uploaded automatically.

## Accessibility

Run at least:

- Keyboard-only import, task review, and export.
- Current screen reader.
- Braille display when available.
- Voice-control operation.
- Switch-style sequential operation.
- 200%, 300%, and 400% zoom.
- Forced colors.
- Reduced motion.
- Narrow viewport.
- Fatigue and interruption conditions.

Observe whether the four count boxes, signals, dispositions, note disclosures, and review panel remain understandable without relying on color or spatial proximity alone.

## Failure cases

Exercise:

- Invalid JSON.
- Oversized report.
- Unknown top-level field.
- Mismatched scenario digest.
- Mismatched task order.
- Inconsistent outcome totals.
- Privacy boundary set to true for participant identity, telemetry, persistence, or network.
- More than 40 reports.
- Duplicate reports.
- Leaving before export.
- Clearing without export.
- Exporting after raw notes contain a deliberately obvious non-sensitive test marker; verify the marker is absent.

## Evidence classification

Automated tests may establish:

```text
strict schema validation
local-only browser behavior
raw-note exclusion
review gating
dark/light/forced-colors rendering
keyboard structure
JSON and Markdown export shape
```

They do not establish:

```text
human comprehension
research quality
participant diversity
broad accessibility
product usability
product safety
```

Record actual session findings separately and review them for privacy before circulation.
