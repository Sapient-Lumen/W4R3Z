# Pulse native and human acceptance protocol

This protocol is packaged work, not completed release evidence. Record exact operating system, Python, browser, assistive technology, network, Node-store, and Pulse versions for every session.

## A. Delivered archive and command surface

1. Extract the sealed release into a new directory.
2. Confirm `CLI/cadence/cli.py`, `service.py`, `store.py`, `server.py`, and `web/` are physically present.
3. Run `./progrss cadence --help` from the extracted bytes.
4. Run `./progrss doctor` and confirm the Cadence/Pulse package is checked.
5. Confirm no runtime database, private backup, receipt, token, browser profile, or cache was included in the archive.

## B. Initialization and offline review

1. Initialize a Node-owned library from a reviewed private backup.
2. Complete one manual public Witness check for an active feed.
3. Export the durable acquisition receipt.
4. Initialize a Pulse database bound to that Node store.
5. Review a six-hour timing plan while packet capture or a local test server records requests.
6. Confirm review performs no DNS lookup and no site request.
7. Create the plan with acknowledgement.
8. Confirm creation changes only the Pulse database.
9. Confirm the scheduler remains stopped.
10. Confirm importing, Exchange, pairing, Capture, and branch adoption created no plan.

## C. Eligibility boundaries

Attempt to create plans from:

```text
a successful public feed Witness receipt
a successful public page-watch Witness receipt
a browser-assisted Capture receipt
a zero-request baseline artifact
a failed or malformed Witness receipt
a receipt whose source address changed afterward
a receipt whose watched-page recipe changed afterward
a receipt from another Node store
a paused source
an archived source
```

Only the first two should qualify, and only while the current source identity still matches.

## D. Foreground behavior

1. Open `progrss cadence serve` without starting the session.
2. Confirm no due request occurs.
3. Start the session explicitly.
4. Confirm only due, scheduled, active, eligible plans dispatch.
5. Close the foreground process.
6. Confirm automatic dispatch stops.
7. Restart the process.
8. Confirm durable next-due state and lease recovery.
9. Attempt to start a second live owner and confirm it is refused.

## E. Pause means zero requests

1. Make a plan due.
2. Pause the timing plan.
3. Run one dispatch pass and one foreground session.
4. Confirm zero DNS lookups and zero HTTP requests for that plan.
5. Resume the plan.
6. Confirm resume selects a future due point and makes no immediate request.
7. Separately pause the source while leaving its timing plan scheduled.
8. Confirm dispatch blocks before DNS and pauses the plan for review.

## F. One fetcher and one receipt

1. Dispatch a due feed plan through the packaged adapter.
2. Confirm the resulting receipt is a normal `progrss.node.acquisition-receipt.v1` retained by the Node store.
3. Confirm the request obeys the normal Witness destination, redirect, validator, size, and timeout rules.
4. Dispatch a due page-watch plan and confirm the normal baseline/stability/Before-Now path is used.
5. Inspect the code path or instrumentation and confirm no second Pulse HTTP downloader is invoked.

## G. Crash and lost-response matrix

Run each case in an isolated copy:

```text
before due-slot persistence
after due-slot persistence, before preview
after preview persistence, before Witness durable intent
after Witness durable intent, before request completion
after Node library and receipt commit, before Pulse completion
after Pulse completion, before GUI response
```

For every case record:

```text
site request count
Node library revision
Node acquisition receipt count
Pulse due-slot state
Pulse completed result count
what an exact retry returns
```

The critical lost-response case is: after the Node commits its receipt, restart Pulse and retry the same due slot. The stored Witness receipt must return without a second site request or second library mutation.

## H. Retry, backoff, and server instructions

1. Return a temporary failure with numeric `Retry-After`.
2. Return a temporary failure with HTTP-date `Retry-After`.
3. Return invalid, past, and unreasonably distant values.
4. Confirm valid bounded delays may lengthen, but never shorten, the safety wait.
5. Confirm temporary failures back off exponentially within the documented cap.
6. Confirm blocking outcomes pause the plan and require review.
7. Make two plans for one hostname due together and confirm the second is deferred by the persistent courtesy window.

## I. Clock and suspend behavior

On an unmanaged test host or virtual machine:

1. Move the wall clock backward.
2. Move it forward by less than one interval.
3. Move it forward across several intervals.
4. Suspend before a due point and resume after it.
5. Change local timezone without changing UTC.
6. Restart after each case.
7. Confirm Pulse does not create a catch-up request storm.
8. Confirm the displayed next-check time remains understandable.

## J. Local web security

1. Confirm literal loopback binding.
2. Confirm a request without bearer capability cannot read the API.
3. Confirm a wrong `Host` is refused.
4. Confirm a foreign `Origin` is refused.
5. Confirm no CORS grant is present.
6. Confirm the fragment capability is absent from the initial HTTP request.
7. Confirm shutdown, start, stop, pause, resume, and run-due require same-origin authenticated actions.
8. Confirm plan and receipt internals remain behind Advanced evidence.

## K. Unfamiliar-human comprehension

Without coaching, ask participants:

1. What is the difference between **Active**, **Scheduled**, and **Running**?
2. Did reviewing this plan contact the site?
3. Did creating it start automatic checks?
4. What happens when the Node process closes?
5. What does **Pause** guarantee?
6. Why can this signed-in browser capture not be scheduled?
7. When is the next check expected?
8. What happened during the last attempt?
9. Where is the durable evidence?
10. Does sharing this route transfer its schedule?

Record wrong turns and revise language or hierarchy before expanding scheduler scope.

## L. Accessibility

Run:

```text
keyboard-only
screen reader
Braille display
voice control
switch-style input
200–400% zoom
forced colors
reduced motion
high contrast
fatigue and interruption
```

Critical actions must not rely on fluorescent color, pointer precision, hover, animation, or remembering protocol vocabulary. Status changes should be announced without stealing focus.

## M. Deliberate non-tests

Do not represent any of the following as delivered merely because a local timing plan works:

```text
permanent daemon
remote Node scheduling
LAN discovery
browser wake-up
cookie transfer
browser-assisted recurring checks
continuous synchronization
metered-network intelligence
cross-machine rate coordination
```
