# ProgRSS Node pairing contract — rev0061 Handshake

Status: implemented experimental contract for loopback, read-only summary pairing.

This document describes only the behavior delivered by ProgRSS 0.61.0. It is not a promise that later writable or remote protocols will preserve every field unchanged.

## Purpose

The pairing contract lets a ProgRSS Extension answer four bounded questions about a ProgRSS Node that the same person started:

1. Which loopback Node session answered?
2. Which explicitly selected private-backup file is that Node reading?
3. What are the bounded counts and portable SHA-256 digest of that file?
4. Is the summary-only grant still active?

It does not synchronize libraries.

## Schemas

```text
progrss.node.ready.v1
progrss.node.status.v1
progrss.node.library.v1
progrss.node.capabilities.v1
progrss.node.pairing.v1
```

`progrss.node.library.v1` is available only to the Node's master browser capability. A paired Extension does not receive it.

## Actors and capabilities

### Node administrator page

Opened through the master capability URL printed by `progrss node serve`:

```text
http://127.0.0.1:PORT/#token=MASTER-CAPABILITY
```

The fragment is staged in the page's session storage and removed from the visible address. The administrator page can read the full bounded copy exposed by `/api/v1/library`, create pairing invitations, list pairings, revoke a pairing by public `pairId`, and stop the Node.

### Pairing invitation

Created only by an authenticated, same-origin POST from the administrator page:

```text
POST /api/v1/pairing-invitations
```

The response includes:

```text
schema: progrss.node.pairing.v1
state: invitation
url: http://127.0.0.1:PORT/#pair=INVITATION-CAPABILITY
expiresAt
expiresInSeconds: 600
node session fingerprint
selected library filename, digest, byte count, and bounded statistics
summary-only capability declaration
```

The invitation token is stored only as a SHA-256-derived lookup key in Node memory. It is not logged. It is valid for ten minutes and is removed when accepted or after expiration cleanup.

### Paired Extension

The Extension requests optional host access to:

```text
http://127.0.0.1/*
```

only from the visible Review action. A WebExtension match pattern is host-scoped rather than TCP-port-scoped, so the human review must still display and validate the exact origin and port carried by the invitation.

The Extension parses the invitation strictly:

```text
scheme is http
hostname is exactly 127.0.0.1
an explicit nonzero port is present
path is exactly /
there is no query, username, or password
fragment contains exactly one pair token
pair token uses the bounded base64url alphabet and length
```

It does not scan localhost, enumerate ports, use mDNS, or probe the LAN.

## Review and origin binding

The Extension reviews an invitation with:

```text
GET /api/v1/pairing-review
Origin: chrome-extension://EXTENSION-ID
Authorization: Bearer INVITATION-CAPABILITY
```

Firefox uses its `moz-extension://…` Origin.

The Node accepts only a syntactically valid browser-extension Origin. The first successful review binds the invitation to that exact Origin. A different extension Origin cannot subsequently review or accept that invitation.

Review returns no bearer grant. It returns only the bounded `progrss.node.pairing.v1` review document. The invitation remains unconsumed so the same Extension can choose Pair or Cancel after seeing the consequences.

## Acceptance

The reviewing Extension accepts with:

```text
POST /api/v1/pairings
Origin: SAME-EXTENSION-ORIGIN
Authorization: Bearer INVITATION-CAPABILITY
Content-Type: application/json

{"clientName":"ProgRSS Extension","clientVersion":"0.61.0"}
```

The Node requires the same Origin that performed review. It also recomputes the selected backup's portable SHA-256 and refuses acceptance with HTTP 409 when the file differs from the exact copy shown during review. The invitation remains available for a fresh review after that refusal. Only an unchanged review may consume the invitation, create a random bearer grant, store only its derived lookup key, and return the bearer once in the response.

The grant is:

```text
bound to the exact extension Origin
stored only in Node memory
valid only while that Node process runs
bound to the SHA-256 of the exact library copy accepted during review
revocable by either participant
not accepted by the administrator-only library API
not a cookie
not sent through a URL
```

## Delivered capability set

```json
{
  "schema": "progrss.node.capabilities.v1",
  "readLibrarySummary": true,
  "readItems": false,
  "readSourceAddresses": false,
  "writeLibrary": false,
  "fetchSources": false,
  "publish": false,
  "merge": false,
  "nodeToNode": false,
  "webrtcCourier": false
}
```

`readLibrarySummary` means the pairing document may contain:

```text
selected filename
portable file SHA-256
file byte count
source count
active-source count
page-watch count
simple-folder count
retained-item count
unread count
saved count
```

It does not include source addresses, item titles, item URLs, item text, folder names, page-watch selectors, browser permission state, private signing keys, or reading-history details beyond the aggregate counts.

## Check and revoke

Check:

```text
GET /api/v1/pairing
Origin: BOUND-EXTENSION-ORIGIN
Authorization: Bearer PAIRING-CAPABILITY
```

Extension-side revoke:

```text
POST /api/v1/pairing/revoke
Origin: BOUND-EXTENSION-ORIGIN
Authorization: Bearer PAIRING-CAPABILITY
```

Administrator-side list and revoke:

```text
GET  /api/v1/pairings
POST /api/v1/pairings/revoke
```

The administrator list contains the public `pairId`, Origin, client label/version, creation time, last-seen time, and the SHA-256 accepted during review. It never contains the pairing bearer or its stored lookup key.

A later Check returns both the current selected-file digest and `pairing.reviewedLibrarySha256`. The Extension labels a mismatch as **Paired · file changed**, displays both digests in advanced evidence, and states that nothing was synchronized. A changed file does not silently widen the grant or rewrite Extension state.

When ProgRSS newly added loopback host permission for this pairing, the Extension attempts to remove that exact permission on failed review, Cancel, Unpair, and local Forget. It does not remove authority that was already present before the pairing action.

Local Forget is deliberately different from Unpair. It exists for an unreachable Node and warns that the still-running Node may retain a stale grant until it is revoked from the Node UI or the process stops.

## Node session fingerprint

The Node creates a random 32-byte process secret and exposes:

```text
sha256( "ProgRSS/node-instance/v1" || NUL || process-secret )
```

as `instanceFingerprint`.

This value supports continuity checks within one running process. It is not signed, not stable across restarts, not tied to a machine account, and not evidence of a real-world identity. The invitation capability authenticates access to the current Node session; the displayed fingerprint lets the Extension detect a changed session between review and later checks.

## HTTP boundary

The Node:

```text
binds only to 127.0.0.1
requires the exact Host header for its selected port
refuses ordinary foreign web Origins
accepts pairing routes only from browser-extension Origins
sends no Access-Control-Allow-Origin header
requires bearer authorization
uses no cookie or ambient browser credential
sets no-referrer and no-store headers
serves no remote asset
logs no request target or header
```

The automated HTTP suite exercises Host, Origin, authorization, expiration, first-review binding, one-use acceptance, pairing-token Origin binding, administrator revocation, Extension revocation, capability limits, and byte-for-byte non-mutation of the selected backup.

Native browser behavior remains a separate acceptance boundary because extension permission prompts, extension Origin behavior, loopback access policy, and cross-origin fetch rules are browser-owned.

## Explicitly absent

Handshake does not define:

```text
item or source-address retrieval by a paired Extension
Extension-to-Node library mutation
Node-to-Extension item synchronization
conflict resolution
one-writer operation receipts
remote or LAN binding
TLS identity
long-lived device identity
account discovery
background reconnect or polling
public sharing invitation
source-list merge
WebRTC signaling or data channels
```

Those features require separate schemas and human consequence review. They must not be inferred from `progrss.node.pairing.v1`.
