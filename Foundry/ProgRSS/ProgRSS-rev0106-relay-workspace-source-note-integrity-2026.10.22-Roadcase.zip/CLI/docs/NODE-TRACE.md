# ProgRSS Node Trace contract

Trace is the read-only evidence layer inside the Bearing review. It exists to let a person inspect the sequence behind one held-window diagnosis before choosing Keep, Anchor, or fresh Capture.

## Schemas

```text
progrss.node.bearing-review.v2
progrss.node.bearing-trace.v1
progrss.node.recipe-footprint.v1
```

The Node store remains `progrss.node-store.v4`. Trace requires no migration and writes no portable or Node-local state.

## Observation trail

The trail begins with the accepted comparison baseline and then orders the retained held observations from oldest to newest. Each held observation contains:

```text
ordinal
current
heldAt
bounded snapshot summary
relationshipToPrevious
overlapToPreviousPercent
sharedUnitsWithPrevious
enoughEvidence
similarSize
overlapToAcceptedPercent
continuityReason
page-boundary kinds
last Capture assessment label and summary
```

The bounded relationship vocabulary is:

```text
Accepted
Boundary changed
Not enough evidence
Different window
Some overlap
Substantial overlap
```

These labels explain Node-computed evidence. They are not probabilities, publisher-intent claims, or repair authority.

## Recipe footprint

The footprint describes what the currently saved declarative section selector appears to depend on:

```text
Primary readable region
Semantic boundary
Explicit structural signal
Class or ID selector
Implementation-detail selector
Plain structural selector
```

The classifier can note bounded signals such as:

```text
semantic elements
role, itemprop, microformat, or data-* attributes
positional pseudo-classes
generated-looking class or ID tokens
deep combinator paths
explicit title and link selectors
last accepted Capture assessment
```

This is an explanation, not a selector standard or durability guarantee. A publisher may change any markup. Exact selectors remain under Advanced evidence.

## Authority

Reviewing Trace performs:

```json
{
  "network": false,
  "writes": false
}
```

Trace cannot:

```text
replace a baseline
rewrite a recipe
contact the watched site
contact the browser
create a schedule
publish or share evidence
grant paired-Extension authority
```

Anchor and fresh Capture remain separate later reviews.

## Portability and privacy

Trace and recipe-footprint evidence stay in the administrator response. They do not enter:

```text
progrss.private.v1 export
source lists
OPML
Exchange handoffs
branch excerpts
recent-updates feeds
pairing summaries
Pulse timing databases
```

The response contains no browser cookie, credential, raw HTML, DOM, screenshot, form value, page script, open-tab list, or browser capability.
