# Threshold coverage-decision acceptance — rev0071

Use one fixture with continuation, partial rendering, an overlay, and excluded frame content.

1. Confirm the final send action is disabled.
2. Confirm **Capture the page again first** is available without committing anything.
3. Check **Use this rendered view as the baseline** and confirm the send action remains disabled when a changed watched section also needs acknowledgement.
4. Acknowledge the changed watched section and confirm the send action becomes available.
5. Recapture and confirm the coverage acknowledgement is cleared.
6. Complete the operation and inspect the durable receipt for `coverageDecision`, exact `acknowledgedBoundaryKinds`, and `partialViewAcknowledged`.
7. Submit a v4 artifact with one kind omitted and confirm the Node refuses it before durable intent.
8. Submit v3, v2, and v1 fixtures and confirm the Node reads them without inventing coverage acknowledgement.
9. Ask the participant whether ProgRSS followed pagination, scrolled, dismissed the overlay, waited for loading, read frame contents, received their login, or created a schedule.
10. Record every wrong answer and change wording or hierarchy before adding automation.

---

# ProgRSS Capture human and assistive-technology protocol

This protocol is executable work, not evidence that the sessions have occurred.

## Participants and environments

Run with people who did not build ProgRSS and have not learned its vocabulary. Include current Chromium, current Firefox, Firefox ESR, keyboard-only use, a real screen reader, Braille where available, voice control, switch-style operation, 200–400% zoom, forced colors, reduced motion, and one interruption/fatigue session.

Use a test watched page that has:

- a clear primary region;
- repeated entries;
- navigation/footer text that should be ignored;
- a signed-in variant whose useful content differs from the public response;
- no sensitive real account data.

## Task 1 — understand the Node request

Ask the administrator to create a browser request for one paused watched page.

Observe whether the participant can explain:

- which page is involved;
- that no page content has been read yet;
- that the request expires;
- that the Node will not receive cookies or credentials;
- that one successful capture can enable the paused source;
- that no recurring schedule will be created.

## Task 2 — open the exact page

Give the participant the request but leave a different tab active.

Observe whether they:

- understand that the exact watched-page address must be active;
- recover from the wrong-page message;
- avoid searching for a hidden background browser;
- understand why a different path or query is refused.

## Task 3 — choose what counts as an update

Ask the participant to capture the rendered page and select the useful region.

Observe whether they can distinguish:

- the saved watched section;
- repeated visible entries;
- primary readable text;
- matched evidence;
- ignored navigation/footer evidence.

Ask them to say what will be sent. Record whether they incorrectly expect raw HTML, a screenshot, cookies, the whole tab, or all page links.

### Contour evidence

For each candidate, ask the participant to explain:

- what **More likely to stay put**, **Needs watching**, or **Fragile** means;
- one item under **Why this may hold**;
- one item under **What could break**;
- why the explanation is evidence from this rendering rather than a guarantee;
- whether a hidden match was excluded;
- whether a generated-looking selector should make them more cautious.

Record whether they treat the label as a probability, assume the first option is automatically correct, or cannot connect the explanation to the matched and ignored examples.

### Perimeter page coverage

Use fixtures containing pagination, a partial or virtualized list, a visible consent layer, a busy region, one embedded frame, and one open shadow root. Ask the participant to explain:

- why **What this browser view may leave outside** is separate from the section-stability label;
- which evidence is outside Capture and which open-shadow evidence was included;
- whether another page, hidden virtualized records, or frame contents are automatically captured;
- when they would scroll, load more, dismiss an overlay, wait, and capture again;
- why a page with no notice is not thereby proved complete.

Record any belief that ProgRSS clicked pagination controls, inspected a frame, pierced closed shadow content, or guaranteed completeness.

## Task 4 — changed watched section

Have the participant select a proposal different from the saved recipe.

Observe whether they understand:

- that the watched section itself will change;
- that a fresh baseline will be saved;
- that no old-versus-new alert should be invented;
- that the action remains one capture rather than a schedule.

The commit control must remain unavailable until the separate acknowledgement is made.

## Task 5 — interpret the result

Commit a first capture.

Ask the participant to explain:

- `Baseline saved`;
- `0 items added`;
- `0 Node site requests`;
- the new library revision;
- `No schedule created`.

A baseline must not be mistaken for a new article or a failed check.

## Task 6 — retry after a lost response

Simulate a committed operation whose first response is lost. Ask the participant to retry.

Observe whether the interface communicates:

- the original receipt was recovered;
- no second browser capture was required;
- no second library write occurred;
- the idempotency key was not a general undo token.

## Task 7 — cancellation and permission cleanup

Cancel during each stage:

1. after Node review but before page capture;
2. after page extraction but before sending;
3. after result review.

Verify that newly granted loopback and page permissions are removed, previously held permissions are preserved, and no Node library write occurs before the final commit.

## Task 8 — accessibility and reflow

At each supported size and assistive technology, verify:

- one clear heading for the current step;
- status messages are announced without stealing focus;
- candidate radio controls have complete labels and descriptions;
- matched and ignored examples are reachable in logical order;
- no horizontal scrolling at 320 CSS pixels except within intentionally scrollable code evidence;
- visible focus survives rerendering;
- forced colors remove decorative neon shadows but preserve boundaries;
- target sizes and spacing remain operable;
- the dark default and optional light mode both retain readable contrast.

## Wrong turns that require product changes

Change wording or hierarchy—not merely documentation—when participants:

- think invitation review already read the page;
- think the Node receives their login session;
- think `active` means `scheduled`;
- choose the broadest region because it appears recommended;
- treat `More likely to stay put` as a promise or hidden confidence score;
- confuse section stability with page completeness;
- believe pagination, virtualized rows, frames, or closed shadow content were automatically captured;
- cannot explain one reason or warning in their own words;
- cannot tell matched from ignored evidence;
- think a fresh baseline is a detected change;
- expect a screenshot or visual diff;
- believe a paired Extension has ambient capture authority;
- cannot find Cancel or permission cleanup;
- cannot explain why the exact address is required.

Do not respond to confusion by adding automatic tab control, silent selector choice, cookie transfer, arbitrary shared JavaScript, a central account, or an engagement-driven recommendation layer.

## Drift — partial rendered-window continuity

1. Establish one accepted partial list baseline.
2. Capture a disjoint later DOM window from the same virtualized set.
3. Confirm the result says **Rendered window held**.
4. Ask the participant whether the earlier entries were removed from the site.
5. Confirm that ProgRSS says only that the renderings were not safely comparable.
6. Confirm there is no mass add/remove alert and the earlier baseline remains.
7. Open Advanced evidence and locate the overlap percentage.
8. Capture a later window with substantial stable overlap and confirm ordinary comparison resumes.
9. Ask how they would intentionally replace an obsolete baseline; record the wrong turns because rev0072 does not yet provide that operation.

## Anchor — reviewed replacement of one held window

1. Produce a Drift **Rendered window held** result for one partial watched page.
2. Restart the Node and confirm the held review is still available.
3. From Sources, activate **Understand held windows**, then choose **Open Anchor** without interpreting that navigation as a write.
4. Ask the participant to identify **Accepted now** and **Held proposal**.
5. Ask what **No past alert invented**, **Earlier library retained**, and **Zero site requests** mean.
6. Confirm **Replace baseline once** is unavailable until **Use this held rendering as the new baseline** is checked.
7. Cancel once and confirm the accepted baseline remains unchanged.
8. Commit once and confirm the result says **Baseline replaced**.
9. Confirm no page-change item was created, no watched-site request occurred, and no schedule was created.
10. Download the before snapshot and ask whether it is evidence or an automatic undo control. The intended answer is evidence.
11. Simulate a lost response and repeat the exact request. Confirm the original receipt returns without a second write.
12. Try the same idempotency key with changed reviewed content and confirm refusal.
13. Change the accepted baseline or watched-page recipe after review and confirm stale review refusal.
14. Ask whether a paired Extension could have performed the replacement. The intended answer is no.
15. Repeat with keyboard, screen reader, Braille, voice control, switch-style navigation, high zoom, forced colors, reduced motion, fatigue, and interruption.

Treat confusion among *held*, *accepted*, *replace*, *history*, *snapshot*, and *undo* as a product-language defect. Do not respond by adding hidden replacement, last-write-wins, or generic write authority.


## Bearing — understand repeated held windows before repair

1. Produce at least two unresolved held partial observations for one watched page.
2. Open **Understand held windows** from Sources.
3. Ask whether the review changed the accepted baseline. The intended answer is no.
4. Ask whether **Moving rendered window** is certainty. The intended answer is no; it is a bounded explanation of the retained evidence.
5. Open Advanced evidence and locate the observation count, boundary kinds, and held-to-held overlap.
6. Choose **Keep accepted baseline** and verify zero writes and zero watched-site requests.
7. Reopen the review and choose **Open Anchor**. Confirm the separate Anchor acknowledgement remains unchecked and no write has occurred.
8. Reopen again and choose **Begin a fresh Capture**. Confirm only a short-lived exact-page invitation is created.
9. Repeat with a page-boundary-shift diagnosis and verify fresh Capture is the recommended route.
10. Repeat with one held observation and verify the result is **Not enough evidence yet**.
11. Run the same tasks with keyboard, screen reader, Braille, voice control, switch-style operation, high zoom, forced colors, reduced motion, fatigue, and interruption.

Treat any belief that Bearing automatically repaired, contacted, scheduled, or synchronized the source as a product-language defect.
