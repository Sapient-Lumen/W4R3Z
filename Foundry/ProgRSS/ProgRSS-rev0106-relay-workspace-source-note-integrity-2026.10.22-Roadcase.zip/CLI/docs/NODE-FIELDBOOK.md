# ProgRSS Node Fieldbook contract

Fieldbook is a private facilitator sidecar for testing the wording and hierarchy of the actual ProgRSS Node interface. It is generated from one current read-only Bearing/Trace review. It is not a product simulation, participant database, telemetry system, or automatic usability score.

## Release boundary

```text
Version:       0.76.0
Revision:      rev0076
Codename:      Fieldbook
Kit schema:    progrss.fieldwork-kit.v1
Report schema: progrss.fieldwork-report.v1
Scenario:      trace-bearing-anchor
```

The Node store remains `progrss.node-store.v4`. Fieldbook introduces no migration and performs no portable-library or fieldwork-evidence write. Opening an older supported store through the CLI may still complete the existing Node-store migration before the read-only review; that migration does not rewrite the portable library.

## Creation paths

Local GUI:

```text
Curate
  → Compare repeated held observations
  → Research and acceptance
  → Download fieldwork sheet
```

CLI:

```sh
./progrss node fieldbook STORE SOURCE_ID \
  --output ProgRSS-Fieldbook.html
```

Machine-readable command evidence is available with `--json`. The output file is new-file-only.

## Required source review

Fieldbook accepts exactly one:

```text
progrss.node.bearing-review.v2
```

The review must report:

```json
{
  "network": false,
  "writes": false
}
```

The generated scenario uses only bounded non-identifying context:

```text
release version, revision, and codename
diagnosis kind and short title
number of retained observations
bounded relationship labels and boundary kinds
recipe-footprint kind and short label
```

It deliberately excludes:

```text
source ID, title, hostname, and address
saved selector, title selector, and link selector
library filename and digest
snapshot text and record keys
Capture artifact bodies
operation and receipt identifiers
browser and Node capabilities
participant identity
```

## Twelve comprehension tasks

The rev0076 scenario asks a facilitator to observe whether a participant can:

1. Find the accepted baseline.
2. Find the current held observation.
3. Explain that the trail is bounded local observation evidence, not complete publisher history.
4. Explain **Different window** without inferring mass deletion or addition.
5. Explain overlap without treating it as probability or confidence.
6. Explain what the saved-recipe footprint does and does not promise.
7. Explain **Keep accepted baseline**.
8. Explain that **Open Anchor** begins another review rather than immediately writing.
9. Explain that **Begin a fresh Capture** still requires a deliberate browser action.
10. Explain the limits of summary-only Extension pairing.
11. Find exact evidence only when asked.
12. State the network and write effects of opening Trace.

Each task can be coded as:

```text
Understood independently
Understood after a neutral prompt
Wrong turn or unsafe interpretation
Not observed
```

The facilitator can add at most 600 characters of notes per task. Notes are intended to paraphrase observable behavior, not copy sensitive page content.

## Privacy and persistence

The generated HTML:

```text
contains no external resource
uses a Content Security Policy with connect-src 'none'
contains no form submission target
calls no fetch, XMLHttpRequest, WebSocket, or sendBeacon API
uses no localStorage, sessionStorage, IndexedDB, or service worker
requests no participant name, email address, or demographic profile
keeps task state only in page memory
saves nothing until a facilitator explicitly downloads a local report
```

Before export, the facilitator must review the local report and acknowledge that notes were checked for personal or sensitive information.

The report downloads locally as JSON or Markdown. ProgRSS does not upload it.

## Human-study boundary

Generating a Fieldbook is not human acceptance. Filling every task with **Understood independently** in an automated browser is only a rendered-interface regression check.

A real session still requires:

```text
an unfamiliar participant
the actual ProgRSS interface open separately
neutral facilitation
observed behavior rather than inferred intent
consent and privacy handling appropriate to the study
native browser and assistive-technology conditions when claimed
changes to wording or hierarchy based on observed wrong turns
```

Fieldbook does not calculate a usability score or decide that the product passed.

## Authority and network effects

Creating or using a Fieldbook does not:

```text
contact the watched site
contact the browser
replace a baseline
change a watched-page recipe
create a page-change item
start Capture
start Pulse
create a schedule
publish or share library data
grant paired-Extension write authority
```

The authenticated Node endpoint is:

```text
POST /api/v1/fieldwork-kits
```

It remains behind the existing administrator bearer, exact `Host`, same-`Origin`, and no-CORS boundaries.

## Compatibility

Fieldbook is additive. It does not change:

```text
progrss.node.bearing-review.v2
progrss.node.bearing-trace.v1
progrss.node.recipe-footprint.v1
progrss.node-store.v4
progrss.browser-capture.v4
replace-held-page-baseline
```

The paired Extension remains summary-only and read-only.
