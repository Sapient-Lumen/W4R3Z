# ProgRSS Witness human acceptance protocol

This is an execution protocol, not a claim that sessions have occurred.

## Participants

Recruit people who have not learned ProgRSS terminology. Include, where available:

- a person who regularly uses a screen reader;
- a keyboard-only participant;
- a voice-control participant;
- a switch-style or reduced-dexterity participant;
- a participant working at 200–400% zoom;
- a participant using forced colors or a personalized color scheme;
- a participant completing the task while interrupted or fatigued.

Do not teach the terms `acquisition`, `validator`, `receipt`, `baseline`, or `page-watch recipe` before the task.

## Test library

Use a disposable Node-owned library containing:

1. one active feed with a valid prior ETag;
2. one active feed whose response contains no new items;
3. one paused feed;
4. one paused page watch with no prior snapshot;
5. one page watch whose structure has changed enough to be held;
6. one source that redirects to another origin;
7. one source whose hostname resolves to a non-public address in the controlled test network;
8. one malformed feed response;
9. one source that returns 429 or 503.

Never run the non-public-address scenario against a real private service. Use a controlled resolver and server.

## Task 1 — review without contact

Prompt:

> Find Town notices. Learn what ProgRSS would do if you checked it, but do not contact the site.

Observe whether the participant:

- finds **Sources** without opening Advanced;
- chooses **Review enable and check**;
- understands that review itself is offline;
- identifies the hostname to be contacted;
- identifies that the source is currently paused;
- identifies that enabling and checking are one reviewed action;
- identifies that no recurring schedule will be created;
- can cancel and explain whether any site was contacted.

Ask afterward:

- “Did ProgRSS contact the site?”
- “Will ProgRSS check it again tomorrow?”
- “Is the source still paused?”

A wrong answer changes wording or hierarchy before adding another feature.

## Task 2 — baseline versus update

Prompt:

> Check Town notices once. Tell us whether ProgRSS found a news update.

The controlled page should be healthy but have no prior snapshot.

Observe whether the participant:

- notices and completes the explicit enable acknowledgement;
- understands **Baseline saved** as preparation for later comparison, not a newly published item;
- can identify that one HTTP request occurred;
- can identify that no recurring schedule was created;
- can find the source’s new active state;
- can find the recent-check receipt without opening raw JSON.

Ask:

- “Did the page publish something new?”
- “What did ProgRSS save?”
- “Will it run again automatically?”

## Task 3 — no new material versus failed check

Run two checks: one valid 304/unchanged feed and one timeout or 503.

Prompt:

> Which site was checked successfully but had nothing new? Which check failed?

Observe whether the participant distinguishes:

```text
No new material
Temporary problem
Site asked us to slow down
```

Do not accept “both had no updates” as comprehension. The interface must not erase the difference between a successful unchanged result and missing evidence.

## Task 4 — movement to another site

Prompt:

> Check this source. It has moved. Explain what ProgRSS did.

Observe whether the participant understands:

- the original site was contacted;
- the new site was not contacted;
- the source address was not silently changed;
- a later explicit review is required before following movement.

## Task 5 — non-public destination refusal

Prompt:

> Review and run this controlled check. Explain whether ProgRSS connected to the destination.

Observe whether the participant understands **Request refused safely** and that zero HTTP requests occurred. Advanced evidence may show the refusal reason, but the ordinary message must be sufficient.

## Task 6 — page shape held

Prompt:

> This watched page looks structurally unusual. Explain whether ProgRSS created an update.

Observe whether the participant understands:

- the current observation was retained as evidence;
- no misleading update was emitted;
- another stable observation or repair is needed;
- this differs from “nothing changed.”

## Task 7 — lost response and safe retry

The test harness commits the check but drops the browser response.

Prompt:

> The result disappeared. Press the same action again and explain what happened.

Observe whether the participant sees:

```text
Safe replay · no second request
```

Verify through server evidence that no second HTTP request or library write occurred.

## Task 8 — interruption before receipt

The test harness records a started intent and terminates the Node before network completion.

After restart, ask the participant to find whether the check is complete. Observe whether the interface or offline `node acquisitions` evidence makes the interrupted state visible. Rev0065 does not yet expose interrupted jobs in the ordinary GUI; record whether this omission causes unsafe assumptions.

## Accessibility observations

Record, do not merely infer:

- focus order from source action to review heading and result heading;
- status-message announcement without forced focus movement;
- whether checkbox and commit-button purpose are spoken clearly;
- whether long hostnames and receipt IDs remain understandable at zoom;
- whether neon decoration disappears or remains harmless in forced colors;
- whether touch targets remain usable;
- whether result categories remain distinguishable without relying on color;
- whether the participant can return to the source list after cancellation or completion;
- whether interruption causes accidental duplicate activation.

## Success criteria

A participant should be able to explain, in their own words:

1. review did not contact a site;
2. a confirmed check contacts one reviewed public source under bounds;
3. enabling a paused source is separate from creating a schedule;
4. baseline is not a new update;
5. unchanged is not failure;
6. a cross-site move stops before the new site;
7. a durable receipt is evidence, not proof that source content is true;
8. a safe replay does not repeat a completed request.

These tasks must be run before adding automatic scheduling to the basic Node interface.
