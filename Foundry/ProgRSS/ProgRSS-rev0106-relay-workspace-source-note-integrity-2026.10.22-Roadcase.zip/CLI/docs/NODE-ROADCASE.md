# ProgRSS Roadcase

Roadcase is a separate deterministic native-fieldwork packet. It is not a new Node authority mode.

```sh
./progrss node roadcase \
  --output ProgRSS-Roadcase-rev0080.zip \
  --json
```

The builder copies the exact current Chromium and Firefox trees plus the exact CLI and Node runtime. It adds local-only instructions, synthetic fixtures, verification, preparation, and cleanup helpers.

## Verification

After extraction:

```sh
python3 scripts/verify.py --restore-modes
python3 scripts/preflight.py
```

The verifier checks every immutable manifested member and rejects missing, changed, or unexpected immutable files. The mutable `work/` directory and ordinary platform metadata files are excluded. Python caches produced by local execution are ignored.

## Native installation

Chromium uses its browser-owned **Load unpacked** flow. Firefox uses its browser-owned temporary add-on flow. Roadcase does not disable or bypass managed policy.

## Synthetic fixture

```sh
python3 scripts/prepare.py
python3 release/CLI/progrss.py node serve work/roadcase.sqlite3 --port 43161
python3 scripts/serve_fixture.py
```

Preparation creates a Node-owned store from a synthetic private library without contacting its example feed or page addresses. The page fixture binds to literal `127.0.0.1:43162` and contains no remote resources.

## Cleanup

```sh
python3 scripts/cleanup.py
```

The cleanup helper removes only the packet's mutable `work/` directory after confirmation. The facilitator separately removes the temporary browser extension and closes the dedicated browser profile.

## Claims

Roadcase verifies fieldwork mechanics and delivered bytes. It does not prove that a native installation succeeded, that an unfamiliar person understood the interface, or that an assistive-technology user encountered no barrier.
