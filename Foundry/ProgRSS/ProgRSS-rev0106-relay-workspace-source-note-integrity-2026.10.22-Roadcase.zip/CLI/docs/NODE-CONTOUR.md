# ProgRSS Contour section evidence — rev0069

Contour explains why one rendered-page section may be more or less likely to remain useful as a watched page. It does not promise that a selector is stable, estimate a probability, or choose silently for the person.

The ordinary question remains:

> **What part of this page counts as an update?**

Contour adds two bounded follow-up questions:

```text
Why might this section hold?
What could break it?
```

## Product boundary

Contour belongs to browser-assisted Capture. It does not change Witness or Pulse authority.

```text
Node-reproducible page
  Witness may retrieve it; Pulse may schedule it after successful evidence.

Browser-assisted page
  The person opens the page and reviews one rendered observation.
  The Node receives bounded text, links, recipe evidence, and Contour evidence.

Browser-only page
  The person must deliberately open it again for another observation.
  Contour does not create unattended browser automation.
```

A successful Contour assessment is never schedule evidence. Only a successful Node-side Witness receipt can establish Node reproducibility.

## Fixed extractor

The canonical implementation is `Extension/shared/capture.js`. Chromium and Firefox receive the same generated file. The background runtime passes its `extract` function to `scripting.executeScript()` for frame `0` only.

The extractor:

- runs as packaged Extension code in the isolated extension world;
- accepts no executable code from the page, Node, curator, or source list;
- examines only the active top-level document at the exact reviewed address;
- emits plain JSON-safe data;
- offers at most three candidates;
- emits at most four reasons and four warnings per candidate;
- excludes hidden matches from the selected evidence;
- transfers no raw HTML, DOM node, screenshot, cookie, credential, storage, or form value.

## Candidate classes

The extractor may offer:

1. **Saved watched section** — the existing declarative recipe.
2. **Repeated entries on this page** — one ranked bounded repeated structure.
3. **Primary readable text** — one main/article/readable region.

A fourth candidate is never created. Duplicate recipes collapse. A proposal with no readable result remains visibly non-viable rather than becoming a silent fallback.

## Evidence model

Each candidate includes:

```text
progrss.capture-section-assessment.v1
```

The assessment has one of three human labels:

```text
steadier
  More likely to stay put, based on the structure visible now.

watchful
  Usable, but one or more page details may shift.

fragile
  Weak or noisy structure may require repair.
```

These are ordinal presentation labels, not statistical confidence. The underlying rank is used only to order bounded proposals and is not exported in the artifact.

### Positive evidence

Possible reasons include:

- a semantic `main`, `article`, landmark role, microformat entry, or structured item boundary;
- exactly one visible region match;
- a bounded repeated set;
- destination links on most repeated entries;
- headings or titles on most repeated entries;
- broadly consistent entry shape;
- no navigation, form, sidebar, or footer landmark inside the selected area;
- reuse of the already saved section.

### Warnings

Possible warnings include:

- generated-looking classes or identifiers;
- generic structural dependence;
- multiple visible region matches;
- hidden matches that were excluded;
- navigation, form, sidebar, or footer-like structure inside the selection;
- very little readable text;
- an extremely broad region;
- few stable entry links or headings;
- widely varying repeated-entry shapes;
- zero readable matches.

The evidence describes one current rendering. A site owner can change markup at any time. Shadow DOM, cross-origin frames, virtualized off-screen records, and content not currently rendered are outside this contract.

## Signals

Advanced evidence is strictly bounded:

```text
selectorKind       semantic | named | generic
semanticBoundary   true | false
uniqueMatch        true | false
visibleMatches     0..100000
hiddenMatches      0..100000
repeatedEntries    0..200
linkedEntries      0..200
titledEntries     0..200
consistentEntries  0..200
clutterElements    0..999
textCharacters     0..120000
```

`linkedEntries`, `titledEntries`, and `consistentEntries` may not exceed `repeatedEntries`. The Node refuses unknown fields, unsupported labels, inconsistent counts, and oversized text.

## Candidate response

The Extension background returns:

```text
progrss.browser-capture-candidates.v2
```

It includes:

```text
capturedAt
page.url
page.title
page.language
page.direction
source.id
source.url
candidates[]
provenance.extractorRevision = contour-v1
```

Right-to-left direction is carried as evidence for the review surface and retained capture provenance.

## Submitted artifact

The reviewed Extension submission is:

```text
progrss.browser-capture.v2
```

It adds to the v1 text-and-link boundary:

```text
page.direction
selection.schema = progrss.capture-selection.v1
selection.candidateId
selection.assessment
provenance.extractorRevision
```

The Node validates the complete assessment before durable intent. It stores the selected candidate ID, level, summary, and extractor revision in the acquisition receipt. It stores no hidden rank.

Legacy `progrss.browser-capture.v1` artifacts remain accepted during a rolling local upgrade. The Node does not invent missing assessment evidence for them.

## Recipe consequence

Contour evidence is not acquisition identity. It does not make two otherwise different recipes equal, and it does not make one selector authoritative.

When the selected candidate changes the declarative recipe, the existing separate acknowledgement remains mandatory:

> **Use this new watched section**

The old comparison snapshot is cleared and the observation becomes a fresh baseline. Existing retained items remain local. No old-versus-new alert is fabricated.

## Review hierarchy

The ordinary interface presents:

1. candidate label and current match count;
2. `More likely to stay put`, `Needs watching`, or `Fragile`;
3. matched and ignored examples;
4. **Why this may hold**;
5. **What could break**;
6. the explicit caveat that this is evidence, not a promise;
7. advanced numeric signals only inside a disclosure.

A fragile candidate is not disabled merely because a site has poor markup. The person may still choose it after seeing the consequence. ProgRSS must not transform weak evidence into a fake recommendation or silently broaden the selected region.

## Security and privacy invariants

Contour does not add a manifest permission. It does not change:

```text
exact active-page requirement
visible optional host-permission request
frame 0 only
isolated-world execution
no page-supplied code
no cookie or credential transfer
no raw HTML or screenshots
300 KB canonical artifact limit
15-minute capture age limit
strong library precondition
idempotent Node commit
zero Node-side watched-site requests
no recurring schedule
summary-only Node pairing
```

## Acceptance boundary

Automated browser-DOM fixtures cover semantic repeated entries, hidden-match exclusion, volatile generated selectors, bounded evidence, and right-to-left direction. They are regression evidence, not human comprehension evidence.

Native and unfamiliar-person sessions must determine whether people:

- treat `More likely to stay put` as a reasoned hint rather than a guarantee;
- understand why hidden matches were excluded;
- can identify the matched and ignored specimens;
- recognize that a generic or generated selector may need repair;
- avoid choosing the broadest section merely because it is available;
- understand that selecting a different section creates a fresh baseline;
- can operate the evidence at high zoom, forced colors, keyboard-only, screen-reader, voice-control, and switch-style settings.

Observed confusion must change the wording or hierarchy. It must not trigger silent selector selection, hidden browser automation, arbitrary shared JavaScript, or a machine-learning confidence score presented as truth.
