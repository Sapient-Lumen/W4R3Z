# ProgRSS Bearing human and assistive-technology protocol

This is executable acceptance work. Its presence does not mean the sessions occurred.

## Required fixtures

Use one watched page for each condition:

1. two or more similarly sized, low-overlap virtualized windows;
2. page-boundary evidence that changes between observations;
3. only one held observation;
4. a later held proposal suitable for deliberate Anchor replacement;
5. a page whose watched section should instead be reconsidered through Capture.

Use non-sensitive test accounts for signed-in variants.

## Task 1 — find the review

Ask an unfamiliar administrator to open **Sources** and identify a watched page with unresolved held observations.

Observe whether they understand:

- the source still uses the accepted baseline;
- the number describes unresolved local observations, not unread articles;
- opening the review will not contact the site.

## Task 2 — interpret moving-window evidence

Open a review diagnosed as **Moving rendered window**.

Ask:

- Is this a fact or an evidence-based explanation?
- Does it prove records were removed?
- Does it prove the page is unchanged?
- How many observations were reviewed?
- Where are the raw overlap details?

The intended answers are: explanation, no, no, the displayed bounded count, and Advanced evidence.

## Task 3 — interpret a changed boundary

Open a **Page boundary shifted** review.

Ask the participant to identify which page boundary changed and why fresh Capture is the preferred route.

Record whether they expect ProgRSS to follow pagination, dismiss overlays, wait indefinitely, inspect frames, or repair a selector automatically.

## Task 4 — insufficient evidence

Open a review with one held observation.

Ask why ProgRSS does not recommend a repair. Confirm **Keep accepted baseline** closes the review without a write or network request.

## Task 5 — separate the routes

Ask the participant to explain:

```text
Keep accepted baseline
Open Anchor
Begin a fresh Capture
```

Opening Anchor must not be mistaken for a completed write. Beginning fresh Capture must not be mistaken for an immediate page read.

## Task 6 — Anchor handoff

Choose **Open Anchor** and confirm the existing Anchor review appears. Confirm its acknowledgement remains unchecked and the commit action disabled.

Cancel once and verify the library and held evidence remain unchanged.

## Task 7 — fresh Capture handoff

Choose **Begin a fresh Capture** and confirm a short-lived exact-page invitation appears. Do not open the browser page. Confirm no Capture artifact and no library write exist.

## Task 8 — accessibility and reflow

Repeat the review using:

- keyboard only;
- a real screen reader;
- Braille where available;
- voice control;
- switch-style sequential operation;
- 200–400 percent zoom;
- forced colors;
- reduced motion;
- fatigue and interruption conditions.

Verify:

- the diagnosis heading receives understandable focus after review;
- the status message announces completion without unexpectedly moving context;
- the three routes have distinct accessible names;
- Advanced evidence is discoverable but not required for the ordinary decision;
- no horizontal scrolling is required at 320 CSS pixels except within intentionally scrollable code evidence;
- dark and light modes retain readable boundaries.

## Wrong turns that require product changes

Change wording or hierarchy when people:

- think Bearing changed the baseline;
- treat a diagnosis as certainty or a probability;
- think Keep contacts the site;
- think Open Anchor immediately writes;
- think fresh Capture runs automatically;
- think the paired Extension has repair authority;
- cannot tell page-boundary change from moving-window evidence;
- cannot find the limitations of the diagnosis.

Do not respond by adding hidden repairs, automatic browser control, arbitrary shared JavaScript, generic write APIs, or engagement-driven ranking.


## Trace — observation-trail comprehension

1. Open a watched page with at least two unresolved held observations.
2. Open Bearing and read the Trace trail without expanding Advanced.
3. Identify the accepted baseline, oldest held observation, and current hold.
4. Explain what `Different window` does and does not prove.
5. Explain what the recipe-footprint label describes.
6. Confirm that opening Trace made no site request and changed no library data.
7. Confirm that exact selectors are available only under Advanced and that the paired Extension receives no repair authority.
8. Repeat with keyboard-only, enlarged text, forced colors, reduced motion, and available assistive technology.

Record whether the participant mistakes the trail for a timeline of confirmed publisher changes, treats the footprint label as a durability guarantee, or believes Open Anchor is an immediate write.

## Fieldbook — facilitator-sidecar comprehension

1. Open the actual Bearing/Trace review in one window.
2. Expand **Research and acceptance** and download the Fieldbook.
3. Confirm that the sheet contains no source address, selector, snapshot text, operation identifier, participant identity field, or remote resource.
4. Complete the three research-boundary checks.
5. Run the twelve tasks without coaching the participant through the expected answer.
6. Use **Understood after a neutral prompt** only after recording the initial response.
7. Use **Wrong turn or unsafe interpretation** when the participant infers deletion, permanence, immediate write, site contact, scheduling, or paired-Extension administrator authority.
8. Confirm that incomplete tasks block review and that privacy review blocks report download.
9. Confirm that clearing without saving removes the in-memory task state.
10. Confirm that generating and using the sheet changed neither the library nor the Bearing review and made no network request.

Automated completion of these controls is a rendering regression test, not completed human acceptance.
