# ProgRSS Drift — conservative continuity for partial rendered pages

Drift is the rev0072 boundary for browser-assisted page watches whose accepted and incoming observations may represent different windows into a larger rendered set.

## Problem

A virtualized or partially rendered list can replace the records currently present in the DOM as a person scrolls or as the site recycles nodes. A literal set diff between two windows can make every old record look removed and every new record look added even though the underlying collection did not undergo that mass change.

Perimeter and Threshold already make the partial-render boundary visible and require an explicit coverage decision. Drift addresses the later comparison.

## Contract

The Node computes:

```text
progrss.capture-continuity.v1
```

from:

```text
last accepted page-watch snapshot
last accepted browser-capture page-context provenance
new validated browser-capture artifact
```

The browser does not supply the decision or an opaque confidence score.

For repeated cards, continuity uses stable capture keys. For one readable region, it uses a bounded case-folded token set. The evidence records:

```text
previous and current boundary kinds
whether either observation reported partial rendering
previous, current, and shared comparison units
overlap percentage
whether the partial-render boundary changed
accept or hold
human reason
whether the baseline was preserved
```

## Hold rule

The Node holds the observation when either:

```text
the accepted and incoming partial-render boundary differs
```

or:

```text
both observations have enough comparison evidence
and stable overlap is below 35 percent
and either accepted observation reported partial rendering
```

A hold produces:

```text
outcome: coverage-shift
human label: Rendered window held
items added: 0
baseline preserved: true
```

It updates durable check and receipt evidence but does not replace the accepted snapshot or accepted browser-capture provenance.

A partial observation with sufficient overlap continues through the existing page-watch health, stability, and Before/Now comparison path.

## Deliberate conservatism

Drift may hold a genuine large turnover in a very small partial list. That is preferable to inventing a mass alert from a moving viewport. Rev0072 does not silently replace the baseline after repeated holds.

A future typed operation must provide an explicit reviewed way to replace an obsolete partial baseline while preserving the former snapshot and reason.

## Authority

Drift changes no authority:

```text
one exact reviewed active page
top-frame packaged isolated-world extraction
bounded JSON-safe text and links
zero Node watched-site requests
no cookie, credential, storage, raw HTML, or screenshot transfer
no schedule
no paired-Extension write capability
```

Pulse still requires successful Node-side Witness evidence and cannot schedule a browser-assisted Capture receipt.

## Research basis

ARIA set metadata exists specifically for cases where only part of a set is present in the DOM, and the WAI feed pattern treats infinitely scrolling feeds as dynamic structures whose articles may be loaded and renumbered. Drift treats those signals as evidence that DOM absence may mean viewport movement rather than publication removal; it does not interpret ARIA metadata as a guarantee of correctness.
