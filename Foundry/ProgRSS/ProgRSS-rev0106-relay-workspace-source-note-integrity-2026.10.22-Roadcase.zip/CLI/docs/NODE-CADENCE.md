# ProgRSS Pulse and Cadence contract — rev0068

**One clock. One fetcher. One receipt.**

Pulse is the executable scheduling layer for a Node-owned ProgRSS library. The timing model is still called **Cadence** in command names and schemas. Pulse connects that timing model directly to the packaged Witness acquisition path.

## Human model

ProgRSS presents three independent states:

```text
Active
  This source may be checked by a reviewed acquisition operation.

Scheduled
  This Node has a separate local timing plan for the source.

Running
  This foreground Pulse process is currently dispatching due plans.
```

An active source is not automatically scheduled. A scheduled source does not run while the foreground session is stopped. Importing, pairing, sharing, Witness, or Capture does not create a schedule.

## Storage boundary

A Pulse database is one local SQLite file with schema:

```text
progrss.cadence-store.v1
```

It stores:

```text
one binding to one Node-store identity
reviewed timing plans
durable due slots
prepared acquisition identity
completed dispatch evidence
scheduler lease
persistent per-site courtesy times
```

It does not store or replace the portable ProgRSS library. The Node-owned library remains exportable as `progrss.private.v1` JSON. Timing plans do not travel through private backups, source lists, OPML, Exchange, branch adoption, or Extension pairing.

## Initialize

```sh
./progrss cadence init pulse.sqlite3 \
  --store reading-room.sqlite3
```

Initialization is offline. It verifies that the selected file is a valid ProgRSS Node store and records its durable store identity. It does not inspect the network or create plans.

## Eligibility

A plan requires one durable `progrss.node.acquisition-receipt.v1` from the bound Node store.

The receipt must show:

```text
one successful Node-reproducible Witness outcome
at least one Node site request
no browser-assisted transport
one source identity digest
an operation and receipt retained in the Node store
```

The current source must still:

```text
exist in the bound Node library
be active rather than paused or archived
use HTTP or HTTPS
match the receipt's acquisition identity
```

The source identity includes:

```text
source ID
feed or page-watch type
canonical feed/page address
declarative page-watch recipe, for a watched page
```

It excludes:

```text
human title and wording
read and saved state
retained items
HTTP validators
last-check evidence
timing plans
browser authority
```

Changing a feed address or watched-page recipe invalidates old schedule eligibility. The administrator performs one new manual Witness check before creating a new plan.

Capture receipts are deliberately ineligible. A browser-assisted observation can prove what a deliberate browser session saw, but it does not prove that the Node can reproduce that page unattended.

## Review and creation

```sh
./progrss cadence review \
  pulse.sqlite3 witness-receipt.json \
  --every 6h \
  --jitter 10m
```

Review is offline and read-only. It reports:

```text
source title, type, and hostname
qualifying Witness receipt
interval and bounded jitter
earliest and latest first-check time
initial Scheduled or Paused state
zero network during review and creation
no foreground session start
```

Create the reviewed plan separately:

```sh
./progrss cadence create \
  pulse.sqlite3 witness-receipt.json \
  --every 6h \
  --jitter 10m \
  --acknowledge
```

Creation writes only the timing database. It does not mutate the portable library, contact the source, or start Pulse.

Intervals are bounded from fifteen minutes through thirty days. Jitter is bounded to one third of the interval and six hours.

## Pause and resume

```sh
./progrss cadence pause pulse.sqlite3 PLAN_ID
./progrss cadence resume pulse.sqlite3 PLAN_ID
```

A paused timing plan produces no due dispatch. A paused or archived source also blocks dispatch even when its timing plan was not separately paused.

Resume chooses a new future due point. It does not immediately contact the source.

## Packaged Witness adapter

The default path creates a normal Witness acquisition preview and calls the normal Witness acquisition operation:

```text
NodeState.create_acquisition_preview()
NodeState.run_acquisition()
```

Consequently one implementation owns:

```text
DNS and public-address validation
same-origin redirect enforcement
HTTP validators and 304 handling
time and response-size bounds
feed parsing
page-watch extraction and stability
portable-library mutation
acquisition receipts
```

Pulse owns only:

```text
timing
eligibility
jitter
due-slot identity
lease ownership
prepared-operation persistence
retry and backoff
per-site courtesy windows
dispatch replay
```

An advanced `--runner` option remains for explicit custom deployments. It passes fixed argv values without shell interpretation and expects one bounded JSON result containing a standard acquisition receipt. The packaged adapter is the default and reference product path.

## Due slots and replay

Every eligible opportunity receives a stable due-slot identity from:

```text
plan ID
source ID
source identity digest
Node-store identity
reviewed due point
plan sequence
```

Pulse persists the slot before acquisition. It then persists the exact prepared Witness operation identity before any source request.

### Failure before Witness durable intent

No source request could have begun. On restart Pulse safely creates a replacement in-memory preview while retaining the same due-slot and Witness operation identity.

### Failure after Witness durable intent but before completion

The stored Witness job resumes through the normal Node acquisition path.

### Failure after Node commit but before Pulse completion

The Node already contains the acquisition receipt. Restarting and retrying the same due slot returns that receipt through the same operation identity. No second source request or library mutation is performed.

### Completed timing slot

An exact retry returns the stored Pulse dispatch result with `replayed: true` and does not invoke Witness again.

A reused slot identity with different material is refused.

## Backoff and Retry-After

Successful checks use the reviewed plan interval plus deterministic bounded jitter.

Temporary failures use bounded exponential backoff. Pulse accepts both forms of `Retry-After`:

```text
delta-seconds
HTTP-date
```

A valid server delay may lengthen the next wait; it cannot shorten the scheduler's safety delay. Invalid, past, or extremely distant values do not produce negative or unbounded waits.

Blocking outcomes such as moved, malformed, refused, repair-needed, or permanent failure pause the plan for explicit review.

## Per-site courtesy window

After a dispatched operation makes a source request, Pulse records a short persistent courtesy time for that hostname. Another plan for the same hostname is deferred rather than immediately dispatched.

This is not yet a complete cross-machine rate policy. It is one local, persistent protection against simultaneous due plans creating an avoidable burst.

## Foreground scheduler

```sh
./progrss cadence run-due pulse.sqlite3
./progrss cadence start pulse.sqlite3
```

`run-due` dispatches currently due plans once.

`start` acquires one durable lease and runs until the foreground process stops. Pulse installs no operating-system daemon, startup item, cron job, hidden browser page, or remote scheduler. Closing the process stops automatic dispatch.

A second live owner is refused while the lease remains valid.

## Loopback control surface

```sh
./progrss cadence serve pulse.sqlite3 --open
```

The server:

```text
binds only to literal 127.0.0.1
places its administrator capability after the URL fragment
moves that capability into session storage
requires bearer authentication for APIs
checks exact Host and Origin
grants no CORS access
starts the scheduler stopped
```

The basic surface shows:

```text
Running or stopped
Scheduled or paused
next eligible check
last result
Pause / Resume
Start / Stop foreground checks
Review another timing plan
```

Plan IDs, source-identity hashes, due-slot fingerprints, leases, and receipt internals remain under advanced evidence.

## Extension boundary

The paired Extension remains summary-only. It cannot create a timing plan, start Pulse, dispatch a check, inspect receipts, or acquire Node write authority.

Capture remains deliberate and unscheduled. Pulse never wakes a browser, opens a tab, transfers cookies, or converts one signed-in observation into unattended authority.

## Not delivered

Pulse does not provide:

```text
permanent background service
remote scheduling
LAN discovery
browser-assisted scheduling
continuous synchronization
schedule transfer through shared formats
metered-network policy
global cross-process concurrency beyond one scheduler lease
cross-machine request budgets
```

## Acceptance boundary

Automated tests establish implementation behavior. They do not establish that unfamiliar people understand Active, Scheduled, Running, Pause, or Next check. Execute `CADENCE-ACCEPTANCE.md` before representing the scheduler as human-validated.
