# ProgRSS browser-assisted capture — rev0072 Drift

Drift preserves the accepted baseline when a later partial rendering appears to be a different virtual window. The Node computes `progrss.capture-continuity.v1` before ordinary diffing; low overlap or a changed partial-render boundary produces **Rendered window held** rather than a mass add/remove alert.

See `NODE-DRIFT.md` for the exact comparison and hold contract. Threshold, Perimeter, Contour, and the original Capture authority boundaries remain in force.

---

# ProgRSS browser-assisted capture — rev0071 Threshold

Threshold keeps the rev0070 Perimeter extractor and adds one strict review before a rendered view with visible coverage limits can become the baseline.

Current submissions use:

```text
progrss.browser-capture.v4
progrss.capture-page-context.v1
progrss.capture-coverage-review.v1
progrss.capture-selection.v1
progrss.capture-section-assessment.v1
```

The limiting page-context kinds are continuation, partial-render, overlay, loading, and frames. The Extension offers **Capture the page again first** and requires **Use this rendered view as the baseline** before submission. The Node validates that the acknowledged list exactly equals the visible limiting list.

A changed watched-section recipe remains a separate decision. Recapture clears the coverage acknowledgement. The Node still makes zero watched-site requests, creates no schedule, and receives no browser credentials.

See `NODE-THRESHOLD.md` for the exact object and rolling-upgrade behavior.

---

# ProgRSS browser-assisted capture — rev0070 Perimeter

Capture lets the local ProgRSS Extension provide one bounded rendered-page observation to one Node-owned watched-page source. It is for pages that the Node cannot independently reproduce because useful content appears only after browser rendering, consent, or a deliberate signed-in session.

Capture is **not** cookie transfer, remote browsing, headless automation, arbitrary script execution, scheduling, pairing authority, or continuous synchronization.

## Human flow

The local Node administrator starts from **Sources**:

```text
Use signed-in browser
  → create a ten-minute one-use browser request
  → copy the exact request into ProgRSS Extension
```

The Extension then performs:

```text
Review the exact Node, watched page, and expiry
  → open the exact watched-page address in the active tab
  → Capture this open page
  → choose what part counts as an update
  → review matched and ignored examples
  → send one bounded capture
  → read one durable result
```

No page content is read during invitation review. The Extension requests page authority only inside **Capture this open page**.

## Three reproduction classes

Capture makes the acquisition boundary visible rather than pretending every page can be checked the same way:

```text
Node-reproducible
  Public or otherwise independently retrievable content.
  Witness can check it directly with bounded public HTTP.

Browser-assisted
  The Extension can render and extract the reviewed page now.
  The Node receives bounded text and links, not browser authority.

Browser-only
  The page can be observed only while a person deliberately opens it.
  No recurring Node schedule is implied or created.
```

A future scheduler may use only Node-reproducible recipes unless another explicit browser-presence contract is designed. Capture does not silently convert a signed-in page into an unattended Node job.

## Invitation contract

The Node administrator creates a request with:

```http
POST /api/v1/capture-invitations
Authorization: Bearer NODE-ADMIN-CAPABILITY
Origin: http://127.0.0.1:PORT
Content-Type: application/json

{"sourceId":"EXISTING-WATCHED-PAGE-ID"}
```

The source must already exist in the Node-owned library and must be a non-archived watched page. The Node does not accept an arbitrary page URL in this request.

The response schema is:

```text
progrss.node.capture.v1
```

It binds:

- one exact watched-page source ID and address;
- the current declarative page-watch recipe;
- the current Node-owned library digest and revision;
- one action: `capture-now` or `enable-and-capture`;
- a ten-minute in-memory capability;
- one exact preview digest;
- a 300 KB artifact limit;
- top-frame-only, isolated-world, fixed-code provenance;
- zero Node-side site requests;
- no recurring schedule.

The invitation URL is:

```text
http://127.0.0.1:PORT/#capture=CAPABILITY
```

The capability is after `#`, so it is not included in the initial HTTP request. The Extension explicitly submits it as a bearer credential only to the reviewed loopback Node.

## Origin binding

The first valid Extension Origin that reviews the invitation binds it:

```http
GET /api/v1/capture-review
Authorization: Bearer CAPTURE-CAPABILITY
Origin: chrome-extension://…
```

or:

```text
moz-extension://…
```

A different Extension Origin cannot take over the same request. The invitation is process-memory-only, expires after ten minutes, and is consumed by a successful commit.

Capture does not scan localhost, probe ports, discover LAN peers, or reuse a summary-only pairing token.

## Browser extraction boundary

The Extension requires the exact reviewed watched-page address to be active in the current window. URL fragments are ignored for exact-address comparison; scheme, host, port, path, and query must otherwise match.

The shipped Extension injects one fixed function through the browser scripting API into frame `0`. It does not execute code received from a source list, Node, curator, or webpage. The fixed function produces at most three JSON-safe candidates and one bounded page-context report:

1. the already saved declarative recipe;
2. one bounded repeated-entry proposal, when a recognizable repeated structure exists;
3. the primary rendered text region.

Each candidate contains only:

```text
declarative recipe
bounded text or repeated-entry title/link/summary rows
match count
up to three matched examples
one ignored navigation/footer/aside example
bounded why-this-may-hold and what-could-break evidence
page title, language, direction, and exact address
capture time
fixed-code and extractor-revision provenance
```

Before the section choices, Perimeter separately reports page-coverage boundaries through `progrss.capture-page-context.v1`. It can identify apparent continuation, partial or virtualized rendering, overlays, busy/loading state, embedded frames outside the top-frame contract, and bounded open shadow roots that were inspected. These notices do not alter the independent section-stability label. See `NODE-PERIMETER.md`.

It does not contain:

```text
cookies
credentials
authorization headers
browser storage
raw HTML
DOM nodes
page scripts
form values
screenshots
images
stylesheets
subresource bodies
extension capabilities
Node administrator capability
```

The payload deliberately remains JSON-safe so Chromium JSON serialization and Firefox structured-clone behavior converge on the same restricted data model.

## Human section choice

The Extension asks:

> What part of this page counts as an update?

It shows each viable candidate with:

- a plain-language label;
- the current match count;
- `More likely to stay put`, `Needs watching`, or `Fragile`;
- a matched example;
- an ignored example;
- **Why this may hold** and **What could break**;
- whether it reuses or changes the saved recipe.

The label is bounded evidence from one rendering, not a probability or promise. See `NODE-CONTOUR.md` for section evidence and `NODE-PERIMETER.md` for page-coverage evidence.

If the selected candidate changes the declarative recipe, the person must separately acknowledge:

> Use this new watched section

A changed recipe clears the old comparison snapshot and saves a fresh baseline. ProgRSS does not compare a newly selected region against the old region and invent a historical change.

## Artifact schema

The submitted artifact is:

```text
progrss.browser-capture.v3
```

Its exact top-level fields are:

```text
schema
capturedAt
page
source
recipe
capture
examples
context
selection
provenance
```

`context` contains one strict `progrss.capture-page-context.v1`. `selection` contains `progrss.capture-selection.v1`, the reviewed candidate ID, and one strict `progrss.capture-section-assessment.v1`. The page carries rendered text direction and provenance carries `extractorRevision = perimeter-v1`. Version 2 and legacy v1 artifacts remain accepted during a rolling local upgrade; the Node does not invent missing page-context or section evidence for them.

Unknown fields are refused. The Node validates:

- capture time no more than fifteen minutes old and no more than two minutes in the future;
- exact source ID and watched-page address;
- HTTP(S)-only page and card links;
- supported region or repeated-card recipe;
- at most 200 repeated entries;
- bounded titles, summaries, examples, selector strings, and text;
- at most 300,000 canonical JSON bytes;
- top-frame, isolated-world, fixed-code provenance;
- identified Extension version and extractor revision;
- strict bounded page-context evidence whose notices and signals agree;
- strict bounded section evidence with internally consistent counts;
- explicit acknowledgement when the recipe differs.

The Node never interprets the artifact as HTML or code.

## Commit contract

The Extension commits through:

```http
POST /api/v1/captures
Authorization: Bearer CAPTURE-CAPABILITY
Origin: chrome-extension://…
If-Match: "REVIEWED-LIBRARY-SHA256"
Idempotency-Key: RANDOM-URL-SAFE-VALUE
Content-Type: application/json
```

The body contains:

```text
operationType = capture-rendered-page-once
sourceId
 action = capture-now | enable-and-capture
previewDigest
recipeChangeAcknowledged
artifact
```

The Node validates the exact artifact and acknowledgements before creating durable intent. Capture performs no Node-side source request after authorization, so a malformed, stale, mismatched, oversized, or unacknowledged artifact leaves no resumable job.

Once validated, the Node records durable intent and atomically commits:

```text
new complete portable progrss.private.v1 library
new library digest and revision
progrss.node.acquisition-receipt.v1
completed acquisition-job state
idempotency request fingerprint
```

The acquisition receipt includes a browser-capture evidence record naming:

```text
transport = extension-rendered-dom
artifact schema and SHA-256
capture time and page title
recipe SHA-256 and whether it changed
matched and ignored examples
Extension version and extractor revision
selected candidate and bounded section-evidence summary
zero Node network requests
no transferred cookie, credential, browser storage, raw HTML, or screenshot
no recurring schedule
```

## Baseline and change behavior

Capture reuses the same page-watch health, stability, baseline, Before/Now, and repair logic as Witness.

A healthy first capture produces:

```text
baseline
```

and creates no article.

A later healthy capture may produce:

```text
unchanged
changed
watch-pending
needs-repair
```

A changed recipe always starts with a fresh baseline. Repeated-entry keys and bounded text are handled by the same portable page-watch representation used by Node-reproducible checks.

## Paused sources

A paused watched page creates an `enable-and-capture` request. The Extension states that the source becomes active if the one capture commits. Rev0066 still creates no recurring schedule, so active does not mean unattended polling.

## Safe retry

The request fingerprint includes:

```text
Extension Origin
capture capability digest
base-library digest
preview digest
source and action
artifact SHA-256
recipe-change acknowledgement
```

An exact retry after a lost response returns the original receipt with `replayed: true`. It performs no second capture and no second library write.

Reusing a committed idempotency key with a different artifact or acknowledgement is refused.

## Permission cleanup

The Extension may request:

```text
http://127.0.0.1/*
```

for the visible Node review and the exact watched-page origin for **Capture this open page**. When ProgRSS newly obtained those permissions for this flow, it attempts to release them after cancellation, completion, or leaving the Add surface. Previously held authority is not removed.

The manifest gains no cookie, web-navigation, debugger, native-messaging, or broad permanent host permission.

## Pairing boundary

Summary-only Node pairing remains unchanged:

```text
browserAssistedCapture: false
writeLibrary: false
fetchSources: false
readSourceAddresses: false
```

A paired Extension cannot create capture invitations, read watched-page addresses, submit captures, inspect receipts, or trigger acquisition. The capture invitation is a separate one-purpose capability created by the local Node administrator.

## Not delivered

Rev0066 does not deliver:

- arbitrary DOM selector editing in the ordinary interface;
- shared JavaScript extractors;
- transfer of browser cookies or credentials;
- automatic browser launch or tab control;
- unattended capture from a signed-in session;
- recurring scheduling;
- complete Node/Extension library synchronization;
- remote Node capture;
- LAN discovery;
- WebRTC capture transport;
- automatic repair acceptance;
- screenshots or visual-diff ingestion.

The next release should run Capture with unfamiliar people and real assistive technology, then add scheduling only for Node-reproducible sources if the distinction among **review**, **capture**, **baseline**, **active**, and **scheduled** remains understandable.

## Anchor — a deliberate way out of a held window

When Drift holds a partial rendered window, Capture itself leaves the accepted baseline unchanged. The Node may persist that bounded held evidence and later offer a separate local-administrator review. Anchor compares **Accepted now** with **Held proposal**, requires an unselected acknowledgement, and applies `replace-held-page-baseline` only under the exact reviewed library and preview digests.

The operation makes zero watched-site requests, changes no recipe or source activity, creates no schedule, and invents no historical page-change item. A complete pre-operation portable-library snapshot and durable receipt are committed atomically. Summary-only Extension pairing cannot invoke it. See `NODE-ANCHOR.md`.

