# ProgRSS Node later-copy merge review — rev0063 Confluence

This document describes the **read-only** later-copy review delivered by ProgRSS 0.63.0. It compares one incoming native ProgRSS source list with the last accepted curator baseline and the current local library. It is not a synchronization protocol, does not apply a change, and does not grant a remote party access to the selected private library.

## The three inputs

A useful later-copy review needs three distinct values:

1. **Baseline** — the exact curator value accepted with the previous publication copy.
2. **Local** — the current recipient value, which may contain deliberate local edits.
3. **Incoming** — the value in the newly supplied curator copy.

A two-copy comparison cannot reliably distinguish a curator change from a recipient change. Confluence therefore computes `progrss.shared-folder-merge-review.v1` from all three copies.

## Human classifications

The ordinary review groups changes by consequence:

| Group | Meaning | Default consequence |
|---|---|---|
| Curator only | Incoming changed; local still matches baseline | Use curator change |
| Yours only | Local changed; incoming still matches baseline | Keep local change |
| Both agree | Local and incoming made the same change | Keep shared result |
| Need a choice | Local and incoming both changed differently | No default; choose explicitly |
| Added | Curator added a source, folder, or membership | New sources start paused |
| Removed | Curator removed something from the publication | Preserve local history |
| Recipe changes | Curator changed how a source is acquired | Separate acknowledgement; new recipe paused |

Raw IDs, digests, baseline values, local values, incoming values, and recipe fingerprints remain bounded and available as advanced evidence. They do not lead the ordinary review.

## Node endpoint

The loopback Node exposes one administrator-only endpoint:

```text
POST /api/v1/merge-reviews
Authorization: Bearer <node-administrator-capability>
Content-Type: application/json
Origin: http://127.0.0.1:<exact-port>
```

Request:

```json
{
  "bundle": {"schema": "progrss.bundle.v3"},
  "folder": "optional local root ID or unambiguous route"
}
```

Response:

```json
{
  "schema": "progrss.node.merge-review.v1",
  "state": "review",
  "library": {
    "file": "selected-backup.json",
    "sha256": "…"
  },
  "review": {
    "schema": "progrss.shared-folder-update.preview.v2",
    "mergeReview": {
      "schema": "progrss.shared-folder-merge-review.v1"
    }
  },
  "readOnly": true,
  "network": false,
  "writes": false
}
```

The endpoint:

- Reads only the already selected `progrss.private.v1` backup and the explicitly uploaded source-list document.
- Performs no DNS lookup or source request.
- Mutates no file or in-memory library.
- Exposes no apply endpoint.
- Is protected by the existing exact-Host, same-Origin, no-CORS, administrator-capability boundary.
- Refuses malformed, oversized, unrelated, rollback, or ambiguous publication copies.

## Placement-scoped Source Note review

A Source Note belongs to one direct folder-to-source relationship, not to the source globally. The Node review therefore identifies each Source Note change by the full canonical folder route as well as the source label. Two folders with the same visible title remain distinguishable, and one source may carry different reasons in different folders.

For each Source Note comparison, the shipped review uses these labels:

- **Last accepted curator reason** — the placement value in the accepted baseline.
- **Keep mine** — the placement value in the current local library.
- **Use curator’s** — the placement value in the incoming curator copy.

Multiline reason text is rendered literally with preserved line breaks, wrapping, and content-derived text direction. Markup-like text is never interpreted as HTML. The review also states that the text is the curator’s reason for that folder relationship and is not a ProgRSS safety claim.

The Node remains read-only. It shows the consequences and the values that an Extension or offline CLI decision would select, but it does not apply either choice.

## Recipe changes are not wording conflicts

A changed title and a changed feed URL do not have the same consequence. A recipe change can redirect future acquisition to another host or select a different page region. Confluence therefore reports old and new recipe evidence separately and requires a separate acknowledgement before the offline CLI can apply it.

A reviewed recipe change never silently rewrites the old local source. ProgRSS creates or reuses the reviewed incoming recipe, keeps it paused when newly created, and retains the earlier source and history locally.

## Extension application

The Extension can apply an already reviewed later copy, but only after:

- Every true wording conflict receives one `keep-local` or `use-curator` choice.
- Every recipe change receives a separate acknowledgement.
- Any signing-key discontinuity receives the existing separate trust acknowledgement.
- The local vault revision still matches the reviewed revision.

No radio choice is preselected. The transaction remains guarded, local, and undoable.

## CLI review and application

Review only:

```sh
./progrss workspace review-bundle \
  private-backup.json later-source-list.json
```

Machine-readable review:

```sh
./progrss workspace review-bundle \
  private-backup.json later-source-list.json \
  --json
```

Applying still writes one new backup and never overwrites the input:

```sh
./progrss workspace update-bundle \
  private-backup.json later-source-list.json \
  --resolve-conflicts keep-local \
  --accept-recipe-changes \
  --output reviewed-result.json
```

The CLI conflict policy applies to all unresolved wording conflicts in that invocation. The Extension presents each conflict separately. Both implementations refuse a missing decision, stale review, unacknowledged recipe change, and unacknowledged trust discontinuity.

## What remains out of scope

Confluence does not add:

- A writable Node REST API.
- Last-write-wins, server-wins, or curator-wins synchronization.
- Continuous polling or automatic publication application.
- Remote Node discovery.
- LAN binding, TLS termination, reverse-proxy trust, or public administration.
- WebRTC synchronization.

The next writable boundary must be one narrow `progrss.node.operation.v1` operation with an exact reviewed base digest, preview digest, random idempotency key, short expiry, atomic commit, durable receipt, and safe replay behavior.
