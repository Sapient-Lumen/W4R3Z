# ProgRSS Node Crossroads

Crossroads is a private facilitator sidecar for the actual Exchange recipient
screen. It studies one exact active `progrss.node.exchange.v1` handoff while the
recipient uses the installed ProgRSS Extension in another window.

## Product boundary

The three recipient doors remain:

```text
Follow updates
  Review one durable recent-updates feed.
  Do not add the underlying source graph.

Add the complete route
  Review every included feed, watched-page recipe, and simple folder.
  Reuse exact existing sources; new sources begin paused.

Take one branch
  Review one populated nested folder as an independent local excerpt.
  Do not claim parent future-copy continuity or a separate subset signature.
```

Selecting a door retrieves the corresponding bounded artifact for review. It
does not by itself follow, import, contact listed sites, create a schedule, pair
the Extension, or write either library.

## Generation

The authenticated Node administrator can download a Fieldbook from an active
handoff. The endpoint is:

```text
POST /api/v1/exchange-fieldwork-kits
{ "exchangeId": "…" }
```

The body must contain exactly `exchangeId`. The active handoff must still exist
and not have expired or been revoked.

Offline generation is also available:

```sh
./progrss node exchange-fieldbook exchange-review.json \
  --output ProgRSS-Exchange-Fieldbook.html
```

The input must be one strict `progrss.node.exchange.v1` review document with a
manual, revocable, bounded artifact scope.

## Privacy minimization

The scenario digest and task set may include only bounded consequence facts:

```text
choice availability
branch-choice count
source, feed, watched-page, folder, and recent-update counts
whether the handoff expires and is revocable
release metadata
```

The generated Fieldbook excludes:

```text
curator name
route title or note
source names and hostnames
source and publication URLs
folder IDs and paths
exchange ID and invitation capability
Node origin and fingerprint
library filename and digest
participant identity
```

The sheet has a `default-src 'none'` content-security policy, no network API,
no browser storage, no service worker, no telemetry, and no automatic
persistence. Notes remain in page memory until a facilitator deliberately
exports a local report.

## Tasks

When all three doors are available, the sheet contains fifteen goal-based tasks
covering:

```text
invitation versus pairing
finding the available doors
preview versus commit
Follow updates consequence and goal choice
complete-route consequence and goal choice
branch consequence and goal choice
existing-source reuse and paused additions
listed-site network effects
private-state exclusion
expiry and revocation
advanced evidence on demand
the complete handoff boundary
```

Tasks adapt when Follow updates or branch adoption is unavailable. Reports from
those different task sets receive different scenario digests and cannot be
combined by Debrief.

## Authority

Crossroads adds no Extension permission, Node write endpoint, sharing
capability, schedule, acquisition request, or pairing authority. It reads one
existing handoff and produces one local HTML artifact.

## Human acceptance

Automated tests verify generation, omission of identity and capability
material, review gating, local report export, and dark/light rendering. They do
not establish that unfamiliar recipients understand the three choices.

Use `NODE-CROSSROADS-ACCEPTANCE.md` for native sessions.
