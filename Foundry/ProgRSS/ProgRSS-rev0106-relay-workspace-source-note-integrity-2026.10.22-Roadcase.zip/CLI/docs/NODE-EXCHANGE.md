# ProgRSS Node Exchange contract — rev0062 Exchange

**One handoff. Three honest choices.**

This document describes the read-only artifact handoff delivered by ProgRSS 0.62.0. It is not a writable synchronization protocol and does not grant access to the selected private library.

## 1. Human purpose

A sender chooses one existing simple folder and prepares one bounded route. A recipient sees consequences before formats:

1. **Follow updates** — preview and follow one ordinary public recent-updates feed. The underlying sources and folders are not added.
2. **Add the complete route** — review and adopt the complete native ProgRSS source list. Exact existing sources are reused; new sources begin paused.
3. **Take one branch** — review one populated nested folder section as an independent local excerpt. It receives no parent future-copy relationship.

The choices may not all be available. Complete-route adoption is always available for a valid preparation. Branch adoption requires at least one populated nested simple-folder branch. Durable following requires both a recent-updates artifact and a public publication address.

## 2. Pairing is not Exchange

`progrss.node.pairing.v1` identifies a running local Node session and exposes a selected-library digest plus bounded counts. It remains summary-only.

`progrss.node.exchange.v1` is a separate, expiring capability for already prepared immutable artifacts. It does not require pairing. Pairing does not create, list, read, or accept Exchange artifacts, and an Exchange invitation does not create a persistent Node relationship.

## 3. Sender preparation

The administrator calls `POST /api/v1/exchange-previews` with the Node master capability and same-origin Node UI Origin:

```json
{
  "folder": "Neighborhood reading",
  "curator": "Neighborhood desk",
  "note": "A small route for public meetings and notices.",
  "publicUpdateUrl": "https://example.org/reading/progrss-source-list.json",
  "includeRecentUpdates": true
}
```

Preparation:

- Reads the explicit `progrss.private.v1` backup selected when the Node started.
- Deep-copies the portable state before transformation.
- Performs no DNS lookup or network request.
- Writes no file and does not mutate the selected backup.
- Produces a native source list.
- Optionally produces a matching recent-updates JSON Feed.
- Produces a script-free static publication ZIP only when a public source-list URL is supplied.
- Computes SHA-256 over the exact bytes of every available artifact.
- Computes a canonical preview digest over the reviewed metadata.

The preview lasts ten minutes and includes bounded source and folder contents, available branches, counts, privacy exclusions, artifact media types, filenames, sizes, SHA-256 values, public addresses, `network:false`, `writes:false`, and `automatic:false`.

## 4. Commit to a handoff

The administrator calls `POST /api/v1/exchanges` with:

```json
{
  "previewToken": "…",
  "previewDigest": "…",
  "librarySha256": "…"
}
```

The Node refuses when:

- The preview expired or was already used.
- The preview digest differs from the reviewed value.
- The submitted library digest differs from the reviewed value.
- The selected backup changed after review.

A successful commit consumes the preview and creates a thirty-minute in-memory grant. The invitation is:

```text
http://127.0.0.1:PORT/#exchange=CAPABILITY
```

The capability is stored by a derived lookup key rather than as plaintext in the Node’s grant table. It disappears on expiry, revocation, or Node stop.

## 5. Browser review

The Extension accepts only:

- `http` scheme.
- Literal host `127.0.0.1`.
- An explicit valid port.
- Root path `/`.
- No username or password.
- No query.
- Exactly one fragment key named `exchange`.

The browser-owned optional host permission is requested only from the visible review action. The Extension then calls:

```text
GET /api/v1/exchange-review
Authorization: Bearer CAPABILITY
Origin: chrome-extension://… or moz-extension://…
```

The first valid review binds the grant to that exact Extension Origin. A different Extension Origin is refused. The response identifies the exact Node origin, process-lifetime session fingerprint, release version and revision, expiry, reviewed library digest, scope, choices, bounded contents, privacy exclusions, and artifact metadata.

The session fingerprint is evidence only that the same Node process answered. It is not a signed permanent device identity or a person identity.

### Source Note disclosure before handoff use

The native source-list artifact may carry one optional curator-written reason on one direct folder/source placement. The same source may therefore have different reasons in different folders. Before the sender creates the invitation, the Node review shows the exact reason count and every reason beside the folder route it describes. Before the recipient chooses **Follow updates**, **Add the complete route**, or **Take one branch**, the Extension review shows the same count and route-bound values. A branch option includes its own reason count.

Reason text is rendered literally, preserves internal line breaks, and uses content-derived directionality. An absent reason produces no invented note. Both reviews state that a reason is curator context for one folder placement, not a ProgRSS safety claim. Review performs no listed-source request and grants no additional authority. The native artifact, not the review copy, remains the integrity-bearing transfer object.

## 6. Artifact retrieval

The bound Extension may retrieve only named artifacts from fixed endpoints:

```text
GET /api/v1/exchange/source-list
GET /api/v1/exchange/recent-updates
```

Each request requires the same bearer capability and exact bound Extension Origin. The Node sends no CORS wildcard and exposes no arbitrary pathname or library endpoint through the grant.

The Extension:

- Retrieves an artifact only after its matching visible choice.
- Enforces the reviewed byte bound.
- Computes SHA-256 over the returned bytes.
- Refuses a digest mismatch.
- Parses through the existing native source-list or feed validator.
- Performs no mutation until the person completes the separate existing review.

The static-site ZIP is downloadable by the authenticated Node administrator, not by the recipient capability.

## 7. Follow updates and public durability

A recent-updates artifact inside a loopback invitation is temporary evidence. It is not itself a durable feed URL. Therefore `choices.followUpdates.available` is true only when:

- A recent-updates Edition was prepared; and
- The sender supplied a valid public source-list URL from which the publication page and `recent-updates.json` URL are derived.

The Extension previews the checked artifact first. A later Follow action requests browser authority for the public feed origin and creates one ordinary feed source using that public URL. It never follows the expiring Node endpoint.

Following updates does not add the source list’s feeds, watched-page recipes, or folders.

## 8. Static publication

The generated static page is script-free and exposes the same three consequences in ordinary language. It advertises the native source list and optional JSON Feed through typed alternate links. The page has no tracker, remote image, frame, form, service worker, or automatic update check, and its Content Security Policy begins with `default-src 'none'`.

The native source list is the rich ProgRSS path. OPML remains the feed-only interoperability fallback. The recent-updates feed remains an ordinary summary feed.

## 9. Web Share boundary

The Node UI may offer the operating-system share sheet only when:

- A public publication page exists.
- `navigator.share` exists.
- `navigator.canShare`, when available, accepts the share data.
- The person activates the visible share control.

Copy remains the fallback. A successful Web Share promise means the browser handed data to a chosen share target; ProgRSS does not treat it as proof that a recipient received, opened, or accepted the route. Web Share is a UI enhancement, not part of the Exchange protocol.

## 10. Privacy boundary

Prepared artifacts may include source recipes, simple folder routes, curator wording, and bounded recent-update summaries. They exclude:

- Read and unread state.
- Saved state.
- Full retained article text.
- Page-watch snapshots and comparison evidence.
- Browser permissions and cookies.
- Private signing keys.

The Exchange grant also excludes arbitrary private-library reads, administrator APIs, writes, source fetching, merge commits, Node-to-Node control, and WebRTC.

## 11. Revocation and expiry

The administrator can list public handoff facts and revoke by `exchangeId` without revealing the bearer capability. Expired and revoked grants refuse review and artifact retrieval. The invitation is only a courier: already adopted local sources remain usable after expiry or revocation.

## 12. Refused implications

Exchange does not mean:

- The sender and recipient are paired.
- The recipient follows future copies of an independent branch.
- The sender can see recipient reading behavior.
- The recipient can write to the sender’s Node.
- A copied invitation is a permanent public URL.
- A verified artifact is safe or true merely because its bytes match.
- Web Share, a QR code, or WebRTC establishes identity.
- A successful handoff creates continuous synchronization.

## 13. Next protocol boundary

Later-copy merge review should distinguish curator-only changes, recipient-only changes, divergent edits, additions, removals, and consequential acquisition-recipe changes.

Any future write must use a one-writer reviewed operation carrying at least:

```text
operation schema
reviewed base-library digest
exact preview digest
random idempotency key
short expiry
atomic commit
stale-review refusal
durable receipt
safe replay returning the prior receipt
```

A generic JSON Patch endpoint, arbitrary filesystem access, and implied bidirectional synchronization remain out of scope.

## Crossroads recipient fieldwork

Rev0078 can generate a privacy-minimized Fieldbook from one active handoff.
The sheet studies the actual recipient Extension screen while omitting curator
and route identity, source names and URLs, folder paths, exchange identifiers,
and invitation capabilities. It performs no network request or library write.
See `NODE-CROSSROADS.md` and `NODE-CROSSROADS-ACCEPTANCE.md`.

## Dispatch sender fieldwork

Before creating a handoff, the authenticated administrator may generate a
private `exchange-sender-review` Fieldbook from the exact active
`progrss.node.exchange-preview.v1` preview:

```text
POST /api/v1/exchange-sender-fieldwork-kits
{ "previewToken": "…" }
```

The Fieldbook studies whether an unfamiliar sender understands what the
reviewed artifacts contain, what remains private, which recipient doors are
available, and what publication, expiry, revocation, Origin binding, network,
scheduling, and recipient-library boundaries apply.

Generation does not consume the preview or create a handoff. The sheet omits
route, curator, source, folder, public-address, library, artifact-digest, and
capability identity. See `NODE-DISPATCH.md` and
`NODE-DISPATCH-ACCEPTANCE.md`.
