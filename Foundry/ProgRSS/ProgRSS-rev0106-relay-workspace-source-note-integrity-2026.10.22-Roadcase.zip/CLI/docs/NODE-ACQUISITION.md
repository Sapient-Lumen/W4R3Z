# ProgRSS Node acquisition — rev0065 Witness

Witness adds one explicit, reviewed source check to a Node-owned library. It does **not** add a scheduler, automatic polling, browser-cookie transfer, or a general HTTP proxy.

## Human boundary

The ordinary Node flow is:

```text
Sources
  → Review check
  → review the site, limits, and consequences offline
  → Check once now
  → read the outcome and durable receipt
```

For a paused source the action is instead:

```text
Review enable and check
  → acknowledge that the source will become active
  → Enable and check once
```

Becoming active does not create a recurring schedule in rev0065.

Review performs no DNS lookup, socket connection, HTTP request, or library write. A committed check performs at most one request plus up to five same-origin redirect requests, then atomically records the resulting portable library and acquisition receipt.

## Delivered scope

Witness can check one existing:

- RSS, Atom, or JSON Feed source;
- declarative static-HTML page watch in region or repeated-card mode.

It cannot:

- create a new source;
- discover or follow a feed;
- execute page JavaScript;
- use browser cookies, login state, client certificates, or browser permissions;
- use environment proxy settings;
- cross to a different origin after a redirect;
- schedule a later check;
- accept a write from a paired Extension;
- fetch arbitrary administrator-supplied URLs outside an existing reviewed source.

## Preview contract

`POST /api/v1/acquisition-previews`

Administrator authorization and exact same-origin are required. The body contains one existing `sourceId`.

The response schema is:

```text
progrss.node.acquisition-preview.v1
```

It binds:

- one Node-owned library digest and revision;
- one source ID;
- the source's current paused/active consequence;
- one action: `check-now` or `enable-and-check`;
- a ten-minute in-memory preview capability;
- an exact preview digest;
- request limits and explicit non-effects.

The preview reports the complete source URL only inside advanced administrator evidence. The ordinary surface leads with the source title, source type, hostname, current state, and declarative page-watch meaning.

## Commit contract

`POST /api/v1/acquisitions`

Required request elements:

```text
operationType = check-source-once
If-Match = strong quoted SHA-256 of the reviewed library
Idempotency-Key = random URL-safe value, 16–200 characters
previewToken = the live reviewed preview capability
previewDigest = the exact reviewed preview digest
sourceId = the reviewed source
 action = check-now | enable-and-check
```

For a first attempt, the live preview must still exist and match the source state. Before DNS, the Node writes a durable `started` acquisition job with the request fingerprint. This is the evidence that a process interruption occurred after authorization but before a receipt.

The Node then rechecks the library digest, performs the bounded request, applies the result to a copy of the portable library, and commits all of the following in one SQLite transaction:

```text
new complete progrss.private.v1 library bytes
new library digest and revision
progrss.node.acquisition-receipt.v1
completed acquisition-job state
idempotency request fingerprint
```

A committed exact retry returns the original receipt and performs no second request or write. Reusing the same idempotency key with different reviewed content is refused. A durable interrupted exact request may be resumed after process restart; the safe GET can happen again because no completed receipt exists.

## Request boundary

The production fetcher:

- accepts only `http` and `https` source URLs already present in the library;
- resolves the hostname once for each same-origin hop;
- rejects the entire answer set when any returned address is non-public;
- connects to one exact validated address rather than resolving again inside the socket layer;
- preserves the original hostname for the HTTP `Host` header and TLS SNI/certificate validation;
- sends `GET`, `Accept-Encoding: identity`, `Connection: close`, and no credentials;
- ignores environment proxy configuration;
- permits at most five redirects whose scheme, host, and effective port remain identical;
- stops before contacting a cross-origin redirect target;
- uses a 20-second request timeout;
- retains at most 2,000,000 response bytes;
- refuses compressed responses instead of expanding an unbounded body;
- never retains server-supplied error-page bodies;
- sends valid saved `ETag` and `Last-Modified` validators when available.

The exact resolved addresses, redirect chain, HTTP status, duration, and request count are retained as administrator-only receipt evidence. They are not included in a shared source list.

## Feed outcomes

For a valid feed response, ProgRSS reuses the existing bounded feed parser and ingestion semantics. A receipt can report:

```text
changed             one or more new items retained
unchanged           valid feed, no new item
malformed           response could not be parsed safely
throttled           HTTP 429 or 503
permanent-failure   a stable client-side HTTP refusal such as 404 or 410
temporary-failure   timeout, DNS/TLS/network problem, or retryable HTTP status
moved               cross-origin redirect observed; new site not contacted
refused             destination rejected before connection
```

HTTP 304 means unchanged and retains the previous validators. Feed-supplied items remain bounded by the existing item and text-storage rules.

## Page-watch outcomes

A page watch uses the existing declarative recipe and static HTML parser. No JavaScript is executed.

The first healthy observation creates a baseline and reports `baseline`; it does not fabricate a change alert. Later observations can report:

```text
changed         meaningful Before/Now evidence retained
unchanged       current captured content matches the baseline
watch-pending   an unusual structural shape is held for confirmation
needs-repair    extraction no longer produces reliable evidence
malformed       static HTML or extraction could not be handled safely
```

For repeated-card mode, ProgRSS compares stable card keys and bounded titles/summaries. For region mode, it retains bounded text and creates a human change summary. Structure-health and two-observation stability logic remain in force, so a template collapse does not immediately become a misleading news item.

## Paused sources

A paused source produces an `enable-and-check` preview. Commit requires an additional visible acknowledgement. The source becomes enabled even when the resulting bounded request is refused or fails, because the person explicitly authorized the state transition as part of the reviewed operation. Enabling alone creates no timing plan. Pulse scheduling remains a separate local review and requires its own successful Node-reproducible Witness evidence.

## Durable evidence

The receipt schema is:

```text
progrss.node.acquisition-receipt.v1
```

It records:

- operation and receipt IDs;
- source ID, title, type, and hostname;
- reviewed action;
- base and resulting library digests;
- resulting revision;
- outcome and human summary;
- item count;
- network request count;
- whether the source was enabled;
- conditional-validator availability;
- bounded fetch evidence;
- attempt count and whether the operation resumed;
- an explicit `automaticScheduleCreated: false` effect.

List evidence offline:

```sh
./progrss node acquisitions reading-room.sqlite3
./progrss node acquisitions reading-room.sqlite3 --json
```

This command makes no network request and does not change portable library content. Opening a legacy v1 store can perform the one-time internal v1→v2 store-schema migration described below; JSON reports `storeMigrated` and `writes` accurately.

## Store migration

Opening a rev0064 `progrss.node-store.v1` database upgrades only the SQLite schema to `progrss.node-store.v2`. The current portable library bytes, digest, revision, original import bytes, branch-operation receipts, and snapshots are not rewritten. The migration creates the acquisition job and receipt tables inside one explicit transaction and updates SQLite `user_version` to 2.

## Pairing boundary

Summary-only Extension pairing still reports:

```text
fetchSources: false
writeLibrary: false
```

The paired Extension cannot create a preview, initiate a check, read source addresses, read acquisition receipts, or enable a source. Only the local Node administrator capability can use the Witness endpoints.

## Not yet delivered

The following remain future work:

- periodic scheduling and global request budgets;
- per-source cadence controls;
- browser-assisted checks for signed-in or client-rendered pages;
- headless JavaScript execution;
- authenticated public sites;
- conditional schedule backoff;
- automatic repair proposal generation in the Node GUI;
- remote Node acquisition;
- Extension-to-Node write operations;
- continuous synchronization.

The next release should not add a scheduler until unfamiliar people can distinguish **review**, **check once**, **enable**, **baseline**, **no new material**, **failed check**, and **needs repair**.
