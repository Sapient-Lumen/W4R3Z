# ProgRSS Anchor — reviewed replacement of one held partial-page baseline

Anchor is the rev0073 boundary for a browser-assisted watched page whose later rendered observation was deliberately held by Drift because it was not safely comparable with the accepted partial baseline.

The operation is intentionally narrow:

```text
one existing watched-page source
one persisted held rendered observation
one offline review
one local-administrator acknowledgement
one atomic baseline replacement
zero watched-site requests
zero historical change alerts
zero schedules
```

It is not a generic snapshot writer, JSON Patch endpoint, Capture retry, merge operation, or paired-Extension capability.

## Why this operation exists

A virtualized or partially rendered page can later show a different window into the same logical collection. Drift preserves the earlier baseline rather than converting that uncertain comparison into a mass addition/removal alert. Sometimes the newly held rendering is nevertheless the comparison point the administrator intentionally wants to use going forward.

Anchor makes that consequence visible:

```text
Accepted now
  The baseline future observations currently compare against.

Held proposal
  The later rendered observation Drift refused to compare literally.

Replace baseline once
  Move the future comparison point to the held proposal.
  Keep the complete pre-operation library as recovery evidence.
  Create no historical change item.
```

## Durable held evidence

`progrss.node-store.v3` introduced one `capture_holds` row per watched-page source. The current `progrss.node-store.v4` keeps that current hold plus bounded prior unresolved evidence for Bearing. Anchor still operates on the exact current hold and clears its prior unresolved history after a successful replacement. The current hold contains bounded Node-local evidence required to review the later operation:

```text
source ID and exact acquisition identity digest
held Capture operation and receipt IDs
accepted and proposed snapshot digests
proposed bounded snapshot
proposed browser-Capture provenance
Node-computed continuity evidence
library digest at the hold
hold time
```

A later non-held accepted acquisition for the same source clears the obsolete hold. A held observation does not travel through private backups, source lists, OPML, Exchange, pairing, or publication artifacts.

## Offline preview

The local administrator requests:

```http
POST /api/v1/baseline-previews
Authorization: Bearer NODE_ADMIN_CAPABILITY
Origin: http://127.0.0.1:PORT
Content-Type: application/json

{"sourceId":"SOURCE_ID"}
```

The preview performs no DNS lookup, watched-site request, browser request, or library write. It checks that:

- the Node owns a writable transactional library;
- the held source still exists and remains a watched page;
- its exact declarative acquisition identity has not changed;
- the accepted baseline still matches the baseline that existed when the observation was held;
- the stored continuity action is `hold` and says the accepted baseline was preserved;
- the held operation and receipt still identify the persisted evidence.

The response schema is:

```text
progrss.node.baseline-preview.v1
```

It includes bounded accepted/proposed summaries, overlap evidence, the exact reviewed base-library digest, a ten-minute preview capability, and these explicit consequences:

```text
acceptedBaselineReplaced = true
earlierCompleteLibrarySnapshotRetained = true
historicalChangeAlertCreated = false
recipeChanged = false
sourceEnabledChanged = false
networkRequests = 0
automaticScheduleCreated = false
```

## Commit contract

The typed operation is:

```text
replace-held-page-baseline
```

The commit requires:

```text
If-Match
  Strong quoted SHA-256 of the exact reviewed Node library.

Idempotency-Key
  Random URL-safe operation identity, 16–200 characters.

previewToken
  Short-lived capability for the exact offline preview.

previewDigest
  Digest of the exact reviewed source, held evidence, accepted baseline,
  proposed baseline, and resulting library.
```

The Node refuses:

- a missing, weak, or stale `If-Match` condition;
- an expired or unknown preview;
- a changed preview digest;
- a changed source recipe or accepted baseline;
- a superseded or missing hold;
- a hold from another source;
- an idempotency key previously used for different reviewed content;
- a non-Node-owned read-only backup.

An exact completed retry returns the original durable receipt with `replayed: true`. It performs no second mutation and no watched-site request.

## Atomic result and recovery evidence

One SQLite transaction records:

```text
complete pre-operation progrss.private.v1 snapshot
new complete portable library
new library digest and revision
operation receipt
request replay fingerprint
removal of the consumed held observation
```

Failure injection after snapshot insertion, library replacement, or receipt insertion rolls back the whole transaction.

The result applies `progrss.capture-baseline-replacement.v1` evidence to the local watched-page source and:

- replaces only the accepted comparison snapshot;
- installs the held browser-Capture provenance;
- clears obsolete continuity, stability, and repair transient state;
- records `lastOutcome = baseline-replaced`;
- creates no retained page-change item;
- changes no feed or watched-page recipe;
- changes no source enabled/paused state;
- makes no network request;
- creates no schedule;
- preserves unrelated items, read state, saved state, folders, labels, and sources.

The complete earlier library is downloadable through its retained before-snapshot ID. That snapshot is recovery evidence, not an automatic undo button.

## Extension boundary

The Extension reports after a Drift hold that the local Node has a separate review and that nothing has been replaced yet. It does not receive the Node administrator capability, held snapshot, source address, or operation endpoint through pairing.

Summary-only pairing remains:

```text
readLibrarySummary = true
readItems = false
readSourceAddresses = false
writeLibrary = false
fetchSources = false
publish = false
merge = false
nodeToNode = false
webrtcCourier = false
```

Anchor is therefore a local Node-administrator operation, not ambient synchronization.

## Human acceptance questions

An unfamiliar administrator should be able to explain:

1. Which rendering is accepted now?
2. Which rendering is merely held?
3. What changes after **Replace baseline once**?
4. Will ProgRSS invent an old add/remove alert? No.
5. Will ProgRSS contact the watched site? No.
6. Will it create a recurring schedule? No.
7. Is the earlier library erased? No; a complete before snapshot remains.
8. Is the snapshot an automatic undo control? No.
9. Can the paired Extension perform this write? No.
10. What happens after a lost response? An exact retry returns the original receipt.

Confusion on those questions is a wording or hierarchy defect. It is not justification for hidden baseline replacement, last-write-wins, generic JSON Patch, browser credential transfer, or automatic synchronization.
