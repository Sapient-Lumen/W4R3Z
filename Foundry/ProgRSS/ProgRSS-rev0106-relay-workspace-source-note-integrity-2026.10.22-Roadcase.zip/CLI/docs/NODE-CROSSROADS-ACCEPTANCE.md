# Crossroads recipient acceptance protocol

Use the exact sealed ProgRSS rev0080 package. The participant should not have
learned ProgRSS's source-list terminology beforehand.

## Setup

1. Prepare an Exchange handoff where all three recipient choices are available.
2. Open the exact invitation in the installed Extension.
3. Keep the Node's Crossroads Fieldbook in a separate facilitator window.
4. Explain that the product—not the participant—is being tested.
5. Use neutral, goal-based tasks. Do not name the expected door in the task.
6. Record an outcome before using a neutral prompt.
7. Do not record names, contact details, credentials, or sensitive page content.

## Core tasks

Ask the participant to:

1. Explain what access the invitation grants.
2. Find the available choices.
3. Explain whether selecting a choice immediately follows or imports anything.
4. Read a curator's future summary updates without adding underlying sources.
5. Adopt the complete curated source graph.
6. Adopt one nested section independently.
7. Explain what happens to exact existing sources and genuinely new sources.
8. Explain whether review contacts every listed site.
9. Explain whether read state, saved state, retained private text, cookies, or
   private keys travel with the handoff.
10. Explain expiry and revocation.
11. Find exact contents and integrity evidence only when asked.
12. State what happened merely by opening and reviewing the invitation.

## Wrong turns to observe

```text
Follow updates interpreted as adding every underlying source
Add route interpreted as one summary feed
Take branch interpreted as continuing parent synchronization
selecting a door interpreted as immediate mutation
new sources expected to fetch immediately
review believed to contact every listed site
invitation confused with permanent Node pairing
revocation expected to erase already adopted local material
private reading history or browser login expected to travel
hashes treated as proof that sources are safe or truthful
```

## Assistive-technology coverage

Run the same goals with:

```text
keyboard-only operation
screen reader
Braille display when available
voice control
switch-style sequential navigation
200–400% zoom
forced colors
reduced motion
fatigue and interruption conditions
```

## Evidence handling

Complete the Fieldbook privacy review before export. Compare only reports with
the same scenario digest, release, and task sequence. Debrief counts describe
loaded reports only; they are not participant scores or population estimates.

## Exit criterion

A product wording or hierarchy change should be proposed only after a wrong
turn recurs across compatible sessions or a clear accessibility barrier is
observed. Retest the same goals after the smallest change.
