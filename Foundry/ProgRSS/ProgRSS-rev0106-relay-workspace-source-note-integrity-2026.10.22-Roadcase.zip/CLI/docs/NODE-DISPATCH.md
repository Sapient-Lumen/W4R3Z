# ProgRSS Node Dispatch

Dispatch is the private sender-side research companion to Exchange. It studies
one exact `progrss.node.exchange-preview.v1` review before an expiring handoff
is created.

## Product boundary

The ordinary sender flow remains:

```text
Choose one curated folder
  ↓
Prepare source-list, optional recent-updates, and optional static-site artifacts
  ↓
Review exact contents and privacy exclusions
  ↓
Create one expiring recipient handoff
```

Dispatch adds a facilitator sheet beside the review. It does not add a sharing
step, upload, publication host, recipient account, synchronization channel, or
write endpoint.

## Generation

Authenticated Node route:

```text
POST /api/v1/exchange-sender-fieldwork-kits
{ "previewToken": "…" }
```

The body must contain exactly `previewToken`. The token must name an active,
unexpired in-memory Exchange preview. Generating the sheet does not consume or
extend that preview and does not create a handoff.

Offline parity:

```sh
./progrss node exchange-sender-fieldbook exchange-preview.json \
  --output ProgRSS-Exchange-Sender-Fieldbook.html
```

The CLI accepts one strict `progrss.node.exchange-preview.v1` document, writes
one new self-contained HTML file, and refuses overwrite.

## Scenario

```text
exchange-sender-review
```

The all-capabilities case contains sixteen tasks covering:

```text
review versus send or publish
included curation material
excluded private state
available recipient doors
Follow updates and its durable public feed
complete-route reuse and paused additions
independent-branch consequences
public source-list and page addresses
static package download versus hosting
thirty-minute handoff scope
first-review Extension-Origin binding
expiry
revocation
zero listed-site requests and zero schedule
recipient-library invisibility
advanced contents and integrity evidence
```

Tasks adapt when Follow updates, branch adoption, a public page, or a static
package is unavailable. Different task sets receive different scenario
digests and cannot be combined by Debrief.

## Privacy minimization

The scenario digest may include only bounded consequence shape:

```text
choice availability
branch-choice count
source, feed, page-watch, folder, and recent-update counts
artifact availability
whether durable public addresses are configured
privacy-category counts
whether the preview expires
release metadata
```

The generated Fieldbook excludes:

```text
route title and curator wording
curator identity
source names, hostnames, and addresses
folder IDs and paths
public source-list, feed, and page addresses
library filename and digest
artifact filenames and digests
preview token
Node origin and fingerprint
participant identity
```

Its content-security policy begins with `default-src 'none'`. It contains no
network API, remote resource, browser-storage persistence, service worker,
telemetry, or automatic upload. Notes remain in page memory until the
facilitator deliberately exports a privacy-reviewed local report.

## Authority

Generating or using Dispatch performs:

```json
{
  "network": false,
  "libraryWrites": false,
  "storeWrites": false,
  "telemetry": false,
  "automaticPersistence": false
}
```

It does not publish, upload, create or revoke a handoff, contact listed sites,
create a schedule, pair an Extension, follow a feed, import a route, or inspect
a recipient library.

## Relationship to Crossroads

Dispatch studies the sender's understanding before a handoff exists.
Crossroads studies the recipient's understanding after an active handoff
exists. They use different scenario identifiers and task sequences. Debrief
must refuse combining them.

## Human acceptance

Automated tests verify strict generation, secret omission, review gating, local
report export, dark/light rendering, and read-only effects. They do not prove
that unfamiliar senders understand the boundary.

Use `NODE-DISPATCH-ACCEPTANCE.md` for native sessions.
