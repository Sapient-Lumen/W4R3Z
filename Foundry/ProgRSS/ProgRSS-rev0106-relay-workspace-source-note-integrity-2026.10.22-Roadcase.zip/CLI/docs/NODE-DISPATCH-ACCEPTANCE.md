# Dispatch sender acceptance protocol

Use the exact sealed ProgRSS rev0080 archive. The participant should not have
learned ProgRSS publication or Exchange terminology beforehand.

## Setup

1. Prepare an Exchange preview with a complete route, durable updates feed,
   one or more populated branches, and an optional static publication package.
2. Keep the actual Node share review open for the participant.
3. Keep the separate Dispatch Fieldbook in a facilitator window.
4. Explain that the product—not the participant—is being tested.
5. Ask goal-based questions without naming the expected control or answer.
6. Record an outcome before using a neutral prompt.
7. Do not record names, contact details, credentials, private reading content,
   source addresses, or other sensitive material.

## Core tasks

Ask the participant to:

1. Explain whether reviewing the share already sent or published anything.
2. Identify what kinds of curation can be included.
3. Identify what private state stays out.
4. Find the recipient choices the share can offer.
5. Explain what a recipient ultimately follows through Follow updates.
6. Explain complete-route reuse and paused additions.
7. Explain why a taken branch is independent from the parent publication.
8. Explain what configuring a public source-list or feed address does.
9. Explain whether downloading a static package hosts it automatically.
10. Explain what the thirty-minute handoff capability grants.
11. Explain first-review Extension-Origin binding.
12. Explain expiry.
13. Explain revocation, including what it cannot erase after local adoption.
14. Explain whether review contacted listed sites or created a schedule.
15. Explain whether the sender can inspect a recipient library.
16. Find detailed contents and digest evidence only when requested.

## Wrong turns to observe

```text
review mistaken for publication or delivery
static package mistaken for automatic hosting
public address mistaken for an upload
preview capability mistaken for recipient administrator access
Follow updates mistaken for the temporary Node invitation
complete route mistaken for immediate source fetching
branch mistaken for continuing parent synchronization
private read or saved state expected to travel
browser cookies, permissions, or signing keys expected to travel
expiry expected to undo already adopted local material
revocation expected to erase recipient data
sender expected to see recipient reading history
listed sources expected to be contacted during review
```

## Assistive-technology coverage

Run the same goals with:

```text
keyboard-only operation
screen reader
Braille display when available
voice control
switch-style sequential navigation
200–400% zoom
forced colors
reduced motion
fatigue and interruption conditions
```

## Evidence handling

Complete the Fieldbook privacy review before export. Compare only reports with
the same scenario digest, release, and task sequence. Debrief counts describe
loaded reports only; they are not participant scores or population estimates.

## Exit criterion

Propose a wording or hierarchy change only after a wrong turn recurs across
compatible sessions or a clear accessibility barrier is observed. Retest the
same sender goals after the smallest change.
