# Roadcase native-fieldwork acceptance

Record browser, version, operating system, assistive technology, exact release digest, scenario, start time, end time, and cleanup result without recording participant identity in ProgRSS artifacts.

## Required sequence

1. Verify the packet before installation.
2. Use a fresh browser profile on an unmanaged test machine.
3. Confirm the exact ProgRSS version.
4. Prepare the synthetic Node offline.
5. Run one planned scenario with its Fieldbook in a separate facilitator window.
6. Use neutral prompts only after an independent attempt.
7. Privacy-review the report before export.
8. Remove the temporary extension and clean the packet work directory.
9. Keep Dispatch, Crossroads, and Trace/Bearing/Anchor reports separate.

## Explicit non-evidence

Automated browser completion, screenshot generation, static checks, and packet verification are not unfamiliar-human or assistive-technology acceptance.
