#!/usr/bin/env python3
"""ProgRSS 0.80.0 — local, bounded tools, and the loopback ProgRSS Node.

Everything is offline except commands that explicitly say fetch, from-page, check-page, or check-publication, plus one source check visibly confirmed inside a running Node.
Outputs are new-file-only. Existing files are never replaced.
"""

from __future__ import annotations

import argparse
import copy
import datetime as dt
import hashlib
import html
from html.parser import HTMLParser
import json
import math
import os
from pathlib import Path
import re
import ssl
import subprocess
import sys

from pathlib import Path as _RelayPath
_RELAY_DIR = str(_RelayPath(__file__).resolve().parent)
if _RELAY_DIR not in sys.path:
    sys.path.insert(0, _RELAY_DIR)
from relay import run_relay_cli
from source_notes_native import (
    SourceNoteError,
    normalize_reason as normalize_source_note_reason,
    validate_private_source_note_placements as audit_private_source_note_placements,
)
import tempfile
from typing import Any, Iterable, NoReturn
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

VERSION = "0.80.0"
REVISION = "rev0080"
CODENAME = "Roadcase"
BACKUP_SCHEMA = "progrss.private.v1"
PAGE_CHANGE_SCHEMA = "progrss.page-change.v1"
PAGE_WATCH_REPAIR_REVIEW_SCHEMA = "progrss.page-watch.repair-review.v1"
PAGE_WATCH_REPAIR_SCHEMA = "progrss.page-watch.repair.v1"
PAGE_WATCH_HEALTH_SCHEMA = "progrss.page-watch.health.v1"
PAGE_WATCH_STABILITY_SCHEMA = "progrss.page-watch.stability.v1"
PAGE_WATCH_ASSESSMENT_SCHEMA = "progrss.page-watch.assessment.v1"
ACCESS_PLAN_SCHEMA = "progrss.workspace.access-plan.v1"
FOLDER_EDITION_SCHEMA = "progrss.folder-edition.v1"
FOLDER_EDITION_RESULT_SCHEMA = "progrss.folder-edition.result.v1"
MAX_FOLDER_EDITION_ITEMS = 100
MAX_FOLDER_EDITION_BYTES = 250_000
PAGE_CHANGE_KINDS = frozenset({"entry-added", "entry-changed", "entry-removed", "text-changed"})
PAGE_CHANGE_MODES = frozenset({"cards", "region"})
JSON_FEED_VERSION = "https://jsonfeed.org/version/1.1"
MAX_FEED_BYTES = 2_000_000
MAX_REDIRECTS = 5
MAX_OPML_BYTES = 2_000_000
MAX_OPML_FEEDS = 500
MAX_OPML_OUTLINES = 1_000
MAX_BACKUP_BYTES = 24_000_000
MAX_ITEMS = 1_200
MAX_ITEM_BODY_CHARS = 12_000
MAX_SOURCES = 200
MAX_COLLECTIONS = 200
MAX_RETIRED_RECEIPTS = 64
GRAFT_RECEIPT_SCHEMA = "progrss.recipe.graft.receipt.v1"
RETIRED_GRAFT_RECEIPT_SCHEMA = "progrss.retired.graft-receipt.v1"
ADVANCED_STATE_LIMITS = {
    "fixtures": 16, "inbox": 24, "receipts": 100, "subscriptions": 12, "publications": 24,
    "patchPins": 96, "keyRotations": 60, "recoveryPolicies": 32, "recoveryReceipts": 80,
    "charterHistory": 160, "charterClaims": 128, "gossipCards": 128, "witnessPins": 64,
    "merklePins": 32, "merkleReceipts": 96, "proofRequests": 20, "proofSightings": 80,
    "proofForks": 24, "fixturePacks": 12,
}
ADVANCED_STATE_KEYS = tuple(ADVANCED_STATE_LIMITS)
ADVANCED_REFERENCE_LABELS = {
    "fixtures": "Page repair fixtures", "inbox": "Exchange inbox", "receipts": "Receipts",
    "subscriptions": "Shared subscriptions", "publications": "Publication history",
    "patchPins": "Repair trust pins", "keyRotations": "Key rotation history",
    "recoveryPolicies": "Recovery policies", "recoveryReceipts": "Recovery receipts",
    "charterHistory": "Charter history", "charterClaims": "Charter claims",
    "gossipCards": "Exchange cards", "witnessPins": "Witness pins", "merklePins": "Merkle pins",
    "merkleReceipts": "Merkle receipts", "proofRequests": "Proof requests",
    "proofSightings": "Proof sightings", "proofForks": "Proof forks", "fixturePacks": "Fixture packs",
    "snapshots": "Attached snapshots",
}
ADVANCED_EVIDENCE_KEYS = frozenset({"receipts", "publications", "keyRotations", "recoveryReceipts", "charterHistory", "merkleReceipts", "proofSightings", "proofForks", "fixturePacks"})
ADVANCED_TRUST_KEYS = frozenset({"patchPins", "recoveryPolicies", "charterClaims", "witnessPins", "merklePins"})
ADVANCED_EXCHANGE_KEYS = frozenset({"inbox", "subscriptions", "gossipCards", "proofRequests"})
MAX_REFERENCE_HITS_PER_RECORD = 24
ROOT = Path(__file__).resolve().parent
LEGACY = ROOT / "legacy" / "ProgRSS-rev0021.html"
CORPUS_SCHEMA = "progrss.feed.corpus.v1"
DEFAULT_CORPUS = ROOT / "fixtures" / "interoperability"
MAX_CORPUS_CASES = 64


class ProgRSSError(Exception):
    """An expected, human-readable command failure."""


def url_origin(raw: str) -> tuple[str, str, int]:
    """Return the browser-style origin tuple used by the Extension policy."""
    parsed = urllib.parse.urlsplit(safe_http_url(raw))
    try:
        port = parsed.port
    except ValueError as exc:
        raise ProgRSSError("URL contains an invalid port") from exc
    if port is None:
        port = 443 if parsed.scheme == "https" else 80
    return parsed.scheme, str(parsed.hostname or "").lower().rstrip("."), port


def same_origin_feed_url(raw: Any, base: str) -> str:
    """Return a declared feed URL only when it stays on the fetched origin."""
    if not raw:
        return ""
    try:
        candidate = safe_http_url(raw, base)
        reference = safe_http_url(base)
        return candidate if url_origin(candidate) == url_origin(reference) else ""
    except ProgRSSError:
        return ""


def source_address_aliases(source: dict[str, Any]) -> set[str]:
    aliases: set[str] = set()
    values = [source.get("url"), source.get("declaredFeedUrl")]
    if isinstance(source.get("previousUrls"), list):
        values.extend(source["previousUrls"])
    if isinstance(source.get("aliasUrls"), list):
        values.extend(source["aliasUrls"])
    for value in values:
        try:
            aliases.add(safe_http_url(value))
        except ProgRSSError:
            continue
    return aliases


class SameOriginRedirects(urllib.request.HTTPRedirectHandler):
    """Follow a bounded same-origin chain and stop before a new origin.

    `redirect_request` is called before urllib opens the redirect target. Raising
    here therefore reports a cross-origin move without contacting that site.
    """

    def __init__(self, initial_url: str) -> None:
        super().__init__()
        clean = safe_http_url(initial_url)
        self.visited = {clean}
        self.chain: list[dict[str, Any]] = []

    def redirect_request(self, req, fp, code, msg, headers, newurl):  # type: ignore[no-untyped-def]
        current = safe_http_url(req.full_url)
        target = safe_http_url(newurl, current)
        current_origin = url_origin(current)
        target_origin = url_origin(target)
        if target_origin != current_origin:
            before = urllib.parse.urlsplit(current).netloc
            after = urllib.parse.urlsplit(target).netloc
            raise ProgRSSError(
                f"address moved from {before} to {after}; ProgRSS stopped before contacting the new site. "
                f"Review the destination, then rerun `progrss feed fetch {target}` explicitly"
            )
        if target in self.visited:
            raise ProgRSSError("same-site redirect loop refused")
        if len(self.chain) >= MAX_REDIRECTS:
            raise ProgRSSError(f"more than {MAX_REDIRECTS} same-site redirects refused")
        self.chain.append({"from": current, "to": target, "status": int(code)})
        self.visited.add(target)
        redirected = super().redirect_request(req, fp, code, msg, headers, target)
        if redirected is None:
            raise ProgRSSError(f"HTTP {code} redirect could not be followed safely")
        # No authority-bearing request headers are needed by this command.
        redirected.remove_header("Authorization")
        redirected.remove_header("Cookie")
        return redirected


def fail(message: str, *, code: int = 2) -> NoReturn:
    print(f"progrss: {message}", file=sys.stderr)
    raise SystemExit(code)


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def clean_text(value: Any, limit: int = 1_200) -> str:
    return re.sub(r"\s+", " ", str(value if value is not None else "")).strip()[:limit]


def language_tag(value: Any) -> str:
    raw = str(value if value is not None else "").strip()
    if not raw or len(raw) > 100 or re.search(r"[\x00-\x20\x7f]", raw):
        return ""
    if not re.fullmatch(r"[A-Za-z]{1,8}(?:-[A-Za-z0-9]{1,8})*", raw):
        return ""
    return raw.lower()


XML_LANG = "{http://www.w3.org/XML/1998/namespace}lang"


def xml_language(element: ET.Element | None, inherited: str = "") -> str:
    if element is None:
        return language_tag(inherited)
    if XML_LANG in element.attrib:
        return language_tag(element.attrib.get(XML_LANG))
    return language_tag(inherited)


def body_text(value: Any, limit: int = MAX_ITEM_BODY_CHARS) -> str:
    raw = str(value if value is not None else "").replace("\r\n", "\n").replace("\r", "\n").replace("\xa0", " ")
    lines = [re.sub(r"[\t ]+", " ", line).strip() for line in raw.split("\n")]
    return re.sub(r"\n{3,}", "\n\n", "\n".join(lines)).strip()[:limit]


_READING_BLOCKS = {
    "address", "article", "aside", "blockquote", "dd", "div", "dl", "dt", "figcaption", "figure",
    "footer", "h1", "h2", "h3", "h4", "h5", "h6", "header", "hr", "li", "main", "nav",
    "ol", "p", "pre", "section", "table", "tbody", "td", "tfoot", "th", "thead", "tr", "ul",
}
_READING_PARAGRAPHS = {
    "address", "blockquote", "dd", "dt", "figcaption", "h1", "h2", "h3", "h4", "h5", "h6",
    "hr", "li", "p", "pre", "tr",
}


class _ReadingHTMLParser(HTMLParser):
    def __init__(self, limit: int) -> None:
        super().__init__(convert_charrefs=True)
        self.limit = limit * 2
        self.parts: list[str] = []
        self.length = 0
        self.ignored = 0

    def _add(self, value: str) -> None:
        if self.length >= self.limit or not value:
            return
        self.parts.append(value)
        self.length += len(value)

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        name = tag.lower()
        if name in {"script", "style", "template", "iframe", "object", "svg", "video", "audio"}:
            self.ignored += 1
            return
        if self.ignored:
            return
        if name == "br":
            self._add("\n")
        elif name in _READING_BLOCKS:
            self._add("\n")
            if name == "li":
                self._add("• ")

    def handle_endtag(self, tag: str) -> None:
        name = tag.lower()
        if name in {"script", "style", "template", "iframe", "object", "svg", "video", "audio"}:
            if self.ignored:
                self.ignored -= 1
            return
        if not self.ignored and name in _READING_BLOCKS:
            self._add("\n\n" if name in _READING_PARAGRAPHS else "\n")

    def handle_data(self, data: str) -> None:
        if not self.ignored:
            self._add(data)


def strip_html(value: Any, limit: int = 1_200) -> str:
    parser = _ReadingHTMLParser(limit)
    try:
        parser.feed(str(value if value is not None else ""))
        parser.close()
        return body_text("".join(parser.parts), limit)
    except (ValueError, TypeError):
        raw = re.sub(r"<[^>]*>", " ", str(value if value is not None else ""))
        return body_text(html.unescape(raw), limit)




class _WatchNode:
    __slots__ = ("tag", "attrs", "parent", "children", "parts")

    def __init__(self, tag: str, attrs: dict[str, str], parent: "_WatchNode | None" = None) -> None:
        self.tag = tag
        self.attrs = attrs
        self.parent = parent
        self.children: list[_WatchNode] = []
        self.parts: list[str] = []


class _WatchHTMLParser(HTMLParser):
    _void = frozenset({"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"})
    _ignored = frozenset({"script", "style", "template", "iframe", "object", "svg", "video", "audio"})

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.root = _WatchNode("document", {})
        self.stack: list[_WatchNode] = [self.root]
        self.ignored_depth = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        name = tag.lower()
        if self.ignored_depth or name in self._ignored:
            self.ignored_depth += 1
            return
        node = _WatchNode(name, {str(key).lower(): str(value or "") for key, value in attrs}, self.stack[-1])
        self.stack[-1].children.append(node)
        if name == "br":
            node.parts.append("\n")
        if name not in self._void:
            self.stack.append(node)

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)
        if self.stack[-1].tag == tag.lower() and tag.lower() not in self._void:
            self.stack.pop()

    def handle_endtag(self, tag: str) -> None:
        name = tag.lower()
        if self.ignored_depth:
            self.ignored_depth -= 1
            return
        for index in range(len(self.stack) - 1, 0, -1):
            if self.stack[index].tag == name:
                del self.stack[index:]
                break

    def handle_data(self, data: str) -> None:
        if not self.ignored_depth and data:
            self.stack[-1].parts.append(data)


def _watch_text(node: _WatchNode, limit: int = 120_000) -> str:
    chunks: list[str] = []
    length = 0

    def walk(current: _WatchNode) -> None:
        nonlocal length
        if length >= limit:
            return
        if current.tag in _READING_BLOCKS and chunks:
            chunks.append("\n")
            length += 1
        for part in current.parts:
            if length >= limit:
                break
            chunks.append(part[: max(0, limit - length)])
            length += min(len(part), max(0, limit - length))
        for child in current.children:
            walk(child)
        if current.tag in _READING_BLOCKS:
            chunks.append("\n")
            length += 1

    walk(node)
    return body_text("".join(chunks), limit)


def _watch_descendants(node: _WatchNode) -> list[_WatchNode]:
    rows: list[_WatchNode] = []
    stack = list(reversed(node.children))
    while stack:
        current = stack.pop()
        rows.append(current)
        stack.extend(reversed(current.children))
    return rows


def _watch_match_simple(node: _WatchNode, token: str) -> bool:
    token = token.strip()
    if not token:
        return False
    if token.startswith("."):
        return token[1:] in node.attrs.get("class", "").split()
    if token.startswith("#"):
        return node.attrs.get("id") == token[1:]
    match = re.fullmatch(r"([A-Za-z][\w-]*)?\[([\w-]+)(?:=[\"']?([^\]\\\"']+)[\"']?)?\]", token)
    if match:
        tag, name, expected = match.groups()
        if tag and node.tag != tag.lower():
            return False
        actual = node.attrs.get(name.lower())
        return actual is not None and (expected is None or actual == expected)
    return node.tag == token.lower()


def _watch_matches_selector(node: _WatchNode, selector: str) -> bool:
    tokens = [part for part in selector.strip().split() if part]
    if not tokens or not _watch_match_simple(node, tokens[-1]):
        return False
    ancestor = node.parent
    for token in reversed(tokens[:-1]):
        while ancestor is not None and not _watch_match_simple(ancestor, token):
            ancestor = ancestor.parent
        if ancestor is None:
            return False
        ancestor = ancestor.parent
    return True


def _watch_select(root: _WatchNode, selector: str) -> list[_WatchNode]:
    if not selector:
        body = next((node for node in _watch_descendants(root) if node.tag == "body"), None)
        return [body] if body else [root]
    selectors = [part.strip() for part in selector.split(",") if part.strip()]
    result: list[_WatchNode] = []
    seen: set[int] = set()
    for node in _watch_descendants(root):
        if any(_watch_matches_selector(node, item) for item in selectors) and id(node) not in seen:
            result.append(node)
            seen.add(id(node))
    return result


def _watch_first(node: _WatchNode, selector: str) -> _WatchNode | None:
    return next((row for row in _watch_descendants(node) if any(_watch_matches_selector(row, item.strip()) for item in selector.split(",") if item.strip())), None)


def _parse_watch_html(raw: bytes) -> _WatchNode:
    if len(raw) > MAX_FEED_BYTES:
        raise ProgRSSError("HTML specimen exceeds the 2,000,000-byte safety limit")
    try:
        text_value = raw.decode("utf-8-sig", errors="strict")
    except UnicodeDecodeError as exc:
        raise ProgRSSError("HTML specimen must be UTF-8") from exc
    parser = _WatchHTMLParser()
    try:
        parser.feed(text_value)
        parser.close()
    except (ValueError, TypeError) as exc:
        raise ProgRSSError(f"could not parse HTML specimen: {exc}") from exc
    return parser.root


def _watch_capture(root: _WatchNode, source: dict[str, Any], recipe: dict[str, Any]) -> dict[str, Any]:
    mode = "cards" if recipe.get("mode") == "cards" else "region"
    selector = clean_text(recipe.get("selector"), 350)
    nodes = _watch_select(root, selector)
    if not nodes:
        raise ProgRSSError("candidate matched no readable page section")
    if mode == "cards":
        cards: list[dict[str, Any]] = []
        collisions: dict[str, int] = {}
        for index, node in enumerate(nodes[:200]):
            raw_text = clean_text(_watch_text(node, 1_000), 1_000)
            if not raw_text:
                continue
            title_node = _watch_first(node, clean_text(recipe.get("titleSelector"), 200) or "h1,h2,h3,h4")
            link_node = _watch_first(node, clean_text(recipe.get("linkSelector"), 200) or "a[href]")
            title = clean_text(_watch_text(title_node, 240) if title_node else raw_text, 240) or f"Item {index + 1}"
            url = ""
            href = link_node.attrs.get("href", "") if link_node else ""
            if href:
                try:
                    url = safe_http_url(href, clean_text(source.get("url"), 2_048))
                except ProgRSSError:
                    url = ""
            stem = re.sub(r"\s+", " ", title).strip().casefold()
            occurrence = collisions.get(stem, 0)
            collisions[stem] = occurrence + 1
            cards.append({"key": url or f"title:{stem}#{occurrence}", "title": title, "summary": raw_text, "url": url})
        if len(cards) < 2:
            raise ProgRSSError("candidate does not contain at least two readable repeated entries")
        return {"mode": "cards", "cards": cards, "matchCount": len(nodes), "contentChars": sum(len(row["summary"]) for row in cards)}
    content = body_text("\n".join(_watch_text(node, 120_000) for node in nodes), 120_000)
    if not content:
        raise ProgRSSError("candidate contains no readable text")
    return {"mode": "region", "content": content, "matchCount": len(nodes), "contentChars": len(content)}


def _page_watch_text_length(raw: Any) -> int:
    return len(re.sub(r"\s+", " ", str(raw or "")).strip())


def page_watch_capture_health(
    previous: dict[str, Any] | None, capture: dict[str, Any], *, checked_at: str | None = None
) -> dict[str, Any]:
    """Classify a page capture without turning one unusual shape into an alert."""
    checked_at = best_date(checked_at) or utc_now()
    previous = previous if isinstance(previous, dict) else {}
    if capture.get("mode") == "cards":
        cards = capture.get("cards") if isinstance(capture.get("cards"), list) else []
        current = len(cards)
        entries = previous.get("entries") if isinstance(previous.get("entries"), list) else None
        keys = previous.get("keys") if isinstance(previous.get("keys"), list) else []
        prior = len(entries) if entries is not None else len(keys)
        metrics = {
            "previousEntries": prior,
            "currentEntries": current,
            "matchCount": max(0, int(capture.get("matchCount") or current)),
        }
        if prior >= 4 and current <= 1:
            return {
                "schema": PAGE_WATCH_HEALTH_SCHEMA, "status": "attention", "reason": "structure-changed",
                "checkedAt": checked_at,
                "message": "The repeated list collapsed to one or no readable entry, so ProgRSS stopped before treating the rest as removed.",
                "metrics": metrics,
            }
        if prior >= 4 and (current < math.ceil(prior * 0.4) or current > prior * 3):
            return {
                "schema": PAGE_WATCH_HEALTH_SCHEMA, "status": "changed-shape", "reason": "entry-count-shift",
                "checkedAt": checked_at,
                "message": "The page's repeated list changed shape, but ProgRSS is still finding readable entries.",
                "metrics": metrics,
            }
        return {
            "schema": PAGE_WATCH_HEALTH_SCHEMA, "status": "steady", "reason": "matched" if prior else "baseline",
            "checkedAt": checked_at,
            "message": "The watched repeated list still matches." if prior else "The watched repeated list has a baseline.",
            "metrics": metrics,
        }

    current = _page_watch_text_length(capture.get("content"))
    prior = _page_watch_text_length(previous.get("text"))
    metrics = {
        "previousCharacters": prior,
        "currentCharacters": current,
        "matchCount": max(0, int(capture.get("matchCount") or 0)),
    }
    if prior >= 800 and current < 80:
        return {
            "schema": PAGE_WATCH_HEALTH_SCHEMA, "status": "attention", "reason": "structure-changed",
            "checkedAt": checked_at,
            "message": "The watched text collapsed to a very small fragment, so ProgRSS stopped before treating the rest as removed.",
            "metrics": metrics,
        }
    if prior >= 400 and (current < math.ceil(prior * 0.25) or current > prior * 4):
        return {
            "schema": PAGE_WATCH_HEALTH_SCHEMA, "status": "changed-shape", "reason": "text-size-shift",
            "checkedAt": checked_at,
            "message": "The watched text changed size sharply, but ProgRSS is still finding the configured section.",
            "metrics": metrics,
        }
    return {
        "schema": PAGE_WATCH_HEALTH_SCHEMA, "status": "steady", "reason": "matched" if prior else "baseline",
        "checkedAt": checked_at,
        "message": "The watched text still matches." if prior else "The watched text has a baseline.",
        "metrics": metrics,
    }


def page_watch_stability_decision(
    previous: dict[str, Any] | None, health: dict[str, Any], source: dict[str, Any]
) -> dict[str, Any]:
    """Mirror the Extension's bounded temporal confirmation decision."""
    stamp = best_date(health.get("checkedAt")) or utc_now()
    reason = clean_text(health.get("reason"), 80)
    changed = health.get("status") == "changed-shape" and reason in {"entry-count-shift", "text-size-shift"}
    try:
        recipe_version = max(1, min(10_000, int(source.get("version") or 1)))
    except (TypeError, ValueError):
        recipe_version = 1
    try:
        prior_recipe_version = int(previous.get("recipeVersion") or 0) if isinstance(previous, dict) else 0
    except (TypeError, ValueError):
        prior_recipe_version = 0
    prior = previous if (
        isinstance(previous, dict)
        and previous.get("schema") == PAGE_WATCH_STABILITY_SCHEMA
        and previous.get("status") == "pending"
        and prior_recipe_version == recipe_version
    ) else None
    if not changed:
        if prior:
            result_health = copy.deepcopy(health)
            result_health.update({
                "status": "steady", "reason": "returned-to-steady",
                "message": "The page returned to its usual shape. The held result was discarded without creating an alert.",
            })
            return {"action": "accept", "clear": True, "recovered": True, "health": result_health}
        return {"action": "accept", "clear": True, "recovered": False, "health": copy.deepcopy(health)}

    metrics: dict[str, int] = {}
    for key in ("previousEntries", "currentEntries", "previousCharacters", "currentCharacters", "matchCount"):
        try:
            value = int(health.get("metrics", {}).get(key))
        except (TypeError, ValueError):
            continue
        if value >= 0:
            metrics[key] = min(2_000_000, value)
    current_key = "currentEntries" if reason == "entry-count-shift" else "currentCharacters"
    current = int(metrics.get(current_key, 0))
    prior_metrics = prior.get("metrics", {}) if prior else {}
    try:
        prior_current = int(prior_metrics.get(current_key) or 0)
    except (TypeError, ValueError):
        prior_current = 0
    current_matches = int(metrics.get("matchCount", 0))
    try:
        prior_matches = max(0, int(prior_metrics.get("matchCount") or 0))
    except (TypeError, ValueError):
        prior_matches = 0
    ratio = current / prior_current if prior_current > 0 and current > 0 else 0
    if reason == "entry-count-shift":
        size_compatible = (
            prior_current > 0 and current > 0
            and abs(current - prior_current) <= max(2, math.ceil(max(current, prior_current) * 0.3))
        )
    else:
        size_compatible = 0.7 <= ratio <= 1.43
    matches_compatible = (
        not prior_matches or not current_matches
        or abs(current_matches - prior_matches) <= max(2, math.ceil(max(current_matches, prior_matches) * 0.3))
    )
    if prior and prior.get("reason") == reason and size_compatible and matches_compatible:
        result_health = copy.deepcopy(health)
        result_health.update({
            "status": "steady", "reason": "confirmed-shape-change",
            "message": "The page showed the same new shape twice, so ProgRSS accepted it as a real change.",
        })
        return {"action": "accept", "clear": True, "confirmed": True, "health": result_health}

    observations = min(3, max(1, int(prior.get("observations") or 1)) + 1) if prior else 1
    if observations >= 3:
        result_health = copy.deepcopy(health)
        result_health.update({
            "status": "attention", "reason": "unstable-shape",
            "message": "The page changed shape differently across three checks. ProgRSS stopped before creating unreliable alerts.",
        })
        return {"action": "repair", "clear": True, "stability": None, "health": result_health}

    message = (
        "This page looked unusually different once. ProgRSS held that result until the next check."
        if observations == 1 else
        "The page looked unusually different again, but not in the same way. ProgRSS is holding the result until one more check."
    )
    stability = {
        "schema": PAGE_WATCH_STABILITY_SCHEMA, "status": "pending", "reason": reason,
        "recipeVersion": recipe_version,
        "firstSeenAt": (best_date(prior.get("firstSeenAt")) or stamp) if prior else stamp,
        "lastSeenAt": stamp, "observations": observations, "metrics": metrics, "message": message,
    }
    result_health = copy.deepcopy(health)
    result_health["message"] = message
    return {"action": "hold", "clear": False, "stability": stability, "health": result_health}


def _page_watch_assessment_observation(
    state: dict[str, Any], source: dict[str, Any], raw: bytes, pending: dict[str, Any] | None
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    source_id = clean_text(source.get("id"), 300)
    snapshots = state.get("snapshots") if isinstance(state.get("snapshots"), dict) else {}
    previous = snapshots.get(source_id) if isinstance(snapshots.get(source_id), dict) else {}
    recipe = {
        "mode": "cards" if source.get("mode") == "cards" else "region",
        "selector": clean_text(source.get("selector"), 350),
        "titleSelector": clean_text(source.get("titleSelector"), 200),
        "linkSelector": clean_text(source.get("linkSelector"), 200),
    }
    try:
        capture = _watch_capture(_parse_watch_html(raw), source, recipe)
    except ProgRSSError as exc:
        health = {
            "schema": PAGE_WATCH_HEALTH_SCHEMA, "status": "attention", "reason": "structure-changed",
            "checkedAt": utc_now(), "message": str(exc), "metrics": {},
        }
        decision = {"action": "repair", "clear": True, "stability": None, "health": health}
        return {
            "health": health, "decision": decision, "capture": None,
            "message": "The saved watch no longer yields a trustworthy readable section.",
        }, None
    health = page_watch_capture_health(previous, capture)
    if health.get("status") == "attention":
        decision = {"action": "repair", "clear": True, "stability": None, "health": health}
    else:
        decision = page_watch_stability_decision(pending, health, source)
    return {
        "health": health,
        "decision": decision,
        "capture": {
            "mode": capture.get("mode"),
            "matchCount": int(capture.get("matchCount") or 0),
            "entryCount": len(capture.get("cards", [])) if capture.get("mode") == "cards" else 0,
            "characterCount": int(capture.get("contentChars") or 0),
        },
        "message": clean_text(decision.get("health", {}).get("message"), 500),
    }, decision.get("stability") if decision.get("action") == "hold" else None


def page_watch_assessment_report(
    state: dict[str, Any], source: dict[str, Any], raw: bytes, confirm_raw: bytes | None = None
) -> dict[str, Any]:
    if source.get("type") != "page":
        raise ProgRSSError("selected source is not a page watch")
    source_id = clean_text(source.get("id"), 300)
    snapshots = state.get("snapshots") if isinstance(state.get("snapshots"), dict) else {}
    baseline = snapshots.get(source_id) if isinstance(snapshots.get(source_id), dict) else None
    observations: list[dict[str, Any]] = []
    first, pending = _page_watch_assessment_observation(state, source, raw, None)
    observations.append(first)
    if confirm_raw is not None:
        second, pending = _page_watch_assessment_observation(state, source, confirm_raw, pending)
        observations.append(second)
    final = observations[-1]["decision"]
    final_health = final.get("health") if isinstance(final.get("health"), dict) else {}
    if final.get("action") == "repair":
        result = "repair"
    elif final.get("action") == "hold":
        result = "hold"
    elif final.get("confirmed"):
        result = "confirmed-new-shape"
    elif final.get("recovered"):
        result = "returned-to-steady"
    else:
        result = "steady"
    return {
        "schema": PAGE_WATCH_ASSESSMENT_SCHEMA,
        "source": {
            "id": source_id,
            "title": clean_text(source.get("title"), 180) or "Untitled page watch",
            "url": clean_text(source.get("url"), 2_048),
            "mode": "cards" if source.get("mode") == "cards" else "region",
        },
        "baselinePresent": baseline is not None,
        "observations": observations,
        "result": result,
        "nextAction": {
            "steady": "No reliability action is needed.",
            "hold": "Check once more before treating the unusual shape as a page change.",
            "confirmed-new-shape": "The repeated new shape is stable enough for the live Extension to compare against the saved baseline.",
            "returned-to-steady": "Discard the held unusual result; it did not repeat.",
            "repair": "Review a selector-free page-watch repair before creating more page-change alerts.",
        }[result],
        "message": clean_text(final_health.get("message"), 500),
        "network": False,
        "writes": False,
        "pageAlertsWritten": 0,
        "snapshotChanged": False,
        "browserProfileRead": False,
    }


def page_watch_repair_proposals(raw: bytes, source: dict[str, Any]) -> list[dict[str, Any]]:
    if source.get("type") != "page":
        raise ProgRSSError("selected source is not a page watch")
    root = _parse_watch_html(raw)
    candidates = [
        ("cards", "main article"), ("cards", "article"), ("cards", "main .post"),
        ("cards", "main .entry"), ("cards", ".h-entry"), ("cards", ".post"),
        ("cards", ".entry"), ("cards", ".news-item"), ("cards", "main li"),
        ("region", "main"), ("region", '[role="main"]'), ("region", ""),
    ]
    seen: set[str] = set()
    proposals: list[dict[str, Any]] = []
    card_count = 0
    for mode, selector in candidates:
        if mode == "cards" and card_count >= 4:
            continue
        recipe = {
            "mode": mode,
            "selector": selector,
            "titleSelector": "h1,h2,h3,h4" if mode == "cards" else "",
            "linkSelector": "a[href]" if mode == "cards" else "",
            "threshold": max(1, min(10_000, int(source.get("threshold") or 1))),
            "ignoreNumbers": bool(source.get("ignoreNumbers")),
        }
        try:
            capture = _watch_capture(root, source, recipe)
        except ProgRSSError:
            continue
        if mode == "cards":
            signature = "cards:" + "\u0002".join(
                "\u0001".join((row["key"], row["title"], row["summary"][:320], row["url"]))
                for row in capture["cards"][:40]
            )
        else:
            signature = "region:" + re.sub(r"\s+", " ", capture["content"]).strip()[:8_000]
        if not signature or signature in seen:
            continue
        seen.add(signature)
        evidence = {"signature": signature, "matchCount": capture["matchCount"], "contentChars": capture["contentChars"]}
        proposal_id = hashlib.sha256(json.dumps({"recipe": recipe, "evidence": evidence}, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()[:16]
        proposals.append({
            "id": proposal_id,
            "mode": mode,
            "title": "Watch repeated entries" if mode == "cards" else ("Watch the page’s main text" if selector else "Watch the page’s readable text"),
            "description": "Notice when an entry is added, removed, or reworded." if mode == "cards" else "Notice meaningful wording changes in this part of the page.",
            "count": len(capture.get("cards", [])) if mode == "cards" else 1,
            "examples": [clean_text(row.get("title") or row.get("summary"), 160) for row in capture.get("cards", [])[:4]],
            "preview": clean_text(capture.get("content"), 360) if mode == "region" else "",
            "recipe": recipe,
            "capture": capture,
        })
        if mode == "cards":
            card_count += 1
        if len(proposals) >= 6:
            break
    if not proposals:
        raise ProgRSSError("no clear readable page section was found in the HTML specimen")
    return proposals

def element_reading_text(element: ET.Element | None, limit: int = MAX_ITEM_BODY_CHARS) -> str:
    if element is None or element.attrib.get("src"):
        return ""
    content_type = clean_text(element.attrib.get("type") or "text", 60).lower()
    if content_type == "html":
        return strip_html("".join(element.itertext()), limit)
    if content_type != "xhtml":
        return body_text("".join(element.itertext()), limit)
    parts: list[str] = []
    length = 0
    def add(value: str) -> None:
        nonlocal length
        if length < limit * 2 and value:
            parts.append(value)
            length += len(value)
    def walk(node: ET.Element) -> None:
        name = local_name(node.tag)
        if name in {"script", "style", "template", "iframe", "object", "svg", "video", "audio", "img", "picture", "source", "track", "link", "embed", "base"}:
            return
        block = name in _READING_BLOCKS
        if block:
            add("\n\n" if name in _READING_PARAGRAPHS else "\n")
            if name == "li":
                add("• ")
        if node.text:
            add(node.text)
        for child_node in list(node):
            walk(child_node)
            if child_node.tail:
                add(child_node.tail)
        if block:
            add("\n\n" if name in _READING_PARAGRAPHS else "\n")
    walk(element)
    return body_text("".join(parts), limit)


def safe_http_url(raw: Any, base: str | None = None) -> str:
    value = clean_text(raw, 2_048)
    if not value or any(ord(ch) < 32 or ord(ch) == 127 for ch in value):
        raise ProgRSSError("a valid HTTP(S) URL is required")
    if base:
        value = urllib.parse.urljoin(base, value)
    parsed = urllib.parse.urlsplit(value)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        raise ProgRSSError("only HTTP(S) links are supported")
    if parsed.username is not None or parsed.password is not None:
        raise ProgRSSError("credential-bearing URLs are not supported")
    # Match the Extension: strip fragments while retaining path/query.
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path or "/", parsed.query, ""))


def strict_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ProgRSSError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def load_json_bytes(data: bytes, label: str) -> Any:
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise ProgRSSError(f"{label} is not UTF-8 JSON") from exc
    try:
        return json.loads(text, object_pairs_hook=strict_pairs)
    except ProgRSSError:
        raise
    except json.JSONDecodeError as exc:
        raise ProgRSSError(f"invalid JSON in {label}: line {exc.lineno}, column {exc.colno}") from exc


def read_limited(path: Path, limit: int, label: str) -> bytes:
    try:
        size = path.stat().st_size
    except OSError as exc:
        raise ProgRSSError(f"cannot read {label}: {exc}") from exc
    if size > limit:
        raise ProgRSSError(f"{label} is larger than the {limit:,}-byte limit")
    try:
        return path.read_bytes()
    except OSError as exc:
        raise ProgRSSError(f"cannot read {label}: {exc}") from exc


def fsync_directory(path: Path) -> None:
    """Best-effort directory sync after creating a new artifact."""
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
    try:
        fd = os.open(path, flags)
    except OSError:
        return
    try:
        os.fsync(fd)
    except OSError:
        pass
    finally:
        os.close(fd)


def write_new(path: Path, data: bytes) -> None:
    """Commit bytes without replacing an existing path.

    The temporary file is fully written and fsynced first. A hard link performs
    the no-overwrite commit on normal local filesystems. The exclusive-create
    fallback still refuses replacement where hard links are unavailable.
    """
    path = path.expanduser().resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise ProgRSSError(f"output already exists: {path}")
    fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    temp = Path(temp_name)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.link(temp, path)
        except FileExistsError as exc:
            raise ProgRSSError(f"output already exists: {path}") from exc
        except OSError:
            # Portable fallback. The final write remains exclusive and bounded.
            flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
            try:
                out_fd = os.open(path, flags, 0o600)
            except FileExistsError as exc:
                raise ProgRSSError(f"output already exists: {path}") from exc
            try:
                with os.fdopen(out_fd, "wb") as handle:
                    handle.write(data)
                    handle.flush()
                    os.fsync(handle.fileno())
            except Exception:
                try:
                    path.unlink()
                except OSError:
                    pass
                raise
    finally:
        try:
            temp.unlink()
        except OSError:
            pass
    fsync_directory(path.parent)


def json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=False) + "\n").encode("utf-8")


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1].lower()


def namespace_uri(tag: str) -> str:
    return tag[1:].split("}", 1)[0] if tag.startswith("{") and "}" in tag else ""


def children_named(element: ET.Element | None, name: str) -> list[ET.Element]:
    if element is None:
        return []
    wanted = name.lower()
    candidates = [node for node in list(element) if local_name(node.tag) == wanted]
    parent_namespace = namespace_uri(element.tag)
    preferred = [node for node in candidates if namespace_uri(node.tag) == parent_namespace]
    return preferred or candidates


def child(element: ET.Element | None, name: str) -> ET.Element | None:
    values = children_named(element, name)
    return values[0] if values else None


def child_text(element: ET.Element | None, name: str) -> str:
    found = child(element, name)
    return clean_text("".join(found.itertext()) if found is not None else "", 10_000)


def best_date(value: Any) -> str:
    text = clean_text(value, 200)
    if not text:
        return ""
    # Email/RFC 2822 dates are common in RSS.
    try:
        from email.utils import parsedate_to_datetime
        parsed = parsedate_to_datetime(text)
        if parsed is not None:
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=dt.timezone.utc)
            return parsed.astimezone(dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    except (TypeError, ValueError, OverflowError):
        pass
    try:
        parsed = dt.datetime.fromisoformat(text.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=dt.timezone.utc)
        return parsed.astimezone(dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
    except (ValueError, OverflowError):
        return ""


def folder_edition_info(doc: dict[str, Any]) -> dict[str, Any] | None:
    if doc.get("version") != JSON_FEED_VERSION:
        return None
    meta = doc.get("_progrss")
    allowed = {"schema", "generatedAt", "folder", "folderSourceCount", "representedSourceCount", "itemCount", "omittedByLimit", "included", "excluded"}
    if not isinstance(meta, dict) or set(map(str, meta)) - allowed or meta.get("schema") != FOLDER_EDITION_SCHEMA:
        return None
    included = meta.get("included")
    excluded = meta.get("excluded")
    included_keys = {"titles", "shortSummaries", "links", "dates", "languages", "sourceLabels"}
    excluded_keys = {"fullRetainedText", "readingState", "savedState", "pageWatchEvidence", "snapshots", "browserAuthority", "privateKeys"}
    if not isinstance(included, dict) or any(included.get(key) is not True for key in included_keys):
        return None
    if not isinstance(excluded, dict) or any(excluded.get(key) is not True for key in excluded_keys):
        return None
    fields = ("folderSourceCount", "representedSourceCount", "itemCount", "omittedByLimit")
    if any(isinstance(meta.get(key), bool) or not isinstance(meta.get(key), int) or meta.get(key) < 0 for key in fields):
        return None
    if meta["itemCount"] > MAX_FOLDER_EDITION_ITEMS or meta["folderSourceCount"] > 200 or meta["representedSourceCount"] > meta["folderSourceCount"]:
        return None
    if meta["itemCount"] != len(doc.get("items") or []):
        return None
    folder = clean_text(meta.get("folder"), 180)
    generated = best_date(meta.get("generatedAt"))
    if not folder or not generated:
        return None
    curator = ""
    authors = doc.get("authors")
    if isinstance(authors, list) and authors and isinstance(authors[0], dict):
        curator = clean_text(authors[0].get("name"), 80)
    return {
        "schema": FOLDER_EDITION_SCHEMA,
        "folder": folder,
        "curator": curator,
        "generatedAt": generated,
        "itemCount": meta["itemCount"],
        "omittedByLimit": meta["omittedByLimit"],
        "folderSourceCount": meta["folderSourceCount"],
        "representedSourceCount": meta["representedSourceCount"],
        "manualSnapshot": True,
    }


def parse_json_feed(raw: bytes, origin: str) -> dict[str, Any]:
    doc = load_json_bytes(raw, "feed")
    if not isinstance(doc, dict) or not isinstance(doc.get("items"), list):
        raise ProgRSSError("not a JSON Feed document")
    version = doc.get("version")
    if not isinstance(version, str) or not re.fullmatch(r"https?://(?:www\.)?jsonfeed\.org/version/1(?:\.1)?/?", version):
        raise ProgRSSError("only JSON Feed 1.x is supported")
    feed_url = ""
    if doc.get("feed_url"):
        try:
            feed_url = safe_http_url(doc["feed_url"], origin)
        except ProgRSSError:
            feed_url = ""
    language = language_tag(doc.get("language"))
    edition = folder_edition_info(doc)
    items: list[dict[str, Any]] = []
    for index, entry in enumerate(doc["items"][:250]):
        if not isinstance(entry, dict):
            continue
        identity = clean_text(entry.get("id"), 400)
        if not identity:
            continue
        link = ""
        if entry.get("url"):
            try:
                link = safe_http_url(entry["url"], origin)
            except ProgRSSError:
                link = ""
        body = body_text(entry.get("content_text"), MAX_ITEM_BODY_CHARS) if entry.get("content_text") else strip_html(entry.get("content_html"), MAX_ITEM_BODY_CHARS)
        summary = strip_html(entry.get("summary"), 1_200) if entry.get("summary") else clean_text(body, 1_200)
        item_language = language_tag(entry.get("language")) or language
        items.append({
            "key": identity,
            "title": clean_text(entry.get("title") or summary or body or "Untitled update", 240),
            "summary": summary,
            "body": body,
            "bodyIsSummary": False,
            "language": item_language,
            "titleLanguage": item_language,
            "summaryLanguage": item_language,
            "bodyLanguage": item_language,
            "published": best_date(entry.get("date_published") or entry.get("date_modified")),
            "url": link,
            "index": str(index),
        })
    return {"title": clean_text(doc.get("title") or origin, 180), "titleLanguage": language, "language": language, "type": "json", "feedUrl": feed_url, "edition": edition, "items": items}


def parse_xml_feed(raw: bytes, origin: str) -> dict[str, Any]:
    if b"<!DOCTYPE" in raw.upper() or b"<!ENTITY" in raw.upper():
        raise ProgRSSError("feeds with DTD or entity declarations are refused")
    try:
        root = ET.fromstring(raw)
    except ET.ParseError as exc:
        raise ProgRSSError(f"invalid XML feed: {exc}") from exc
    kind = local_name(root.tag)
    if kind == "feed":
        entries = children_named(root, "entry")[:250]
        root_base = root.attrib.get("{http://www.w3.org/XML/1998/namespace}base", "")
        try:
            root_base = safe_http_url(root_base, origin) if root_base else origin
        except ProgRSSError:
            root_base = origin
        feed_url = ""
        for link_el in children_named(root, "link"):
            if clean_text(link_el.attrib.get("rel"), 50).lower() != "self":
                continue
            href = link_el.attrib.get("href")
            if href:
                try:
                    feed_url = safe_http_url(href, root_base)
                except ProgRSSError:
                    feed_url = ""
            break
        language = xml_language(root)
        title_element = child(root, "title")
        title_language = xml_language(title_element, language)
        items: list[dict[str, Any]] = []
        for index, entry in enumerate(entries):
            link = ""
            for link_el in children_named(entry, "link"):
                rel = clean_text(link_el.attrib.get("rel"), 50)
                if rel and rel != "alternate":
                    continue
                href = link_el.attrib.get("href")
                if href:
                    entry_base = entry.attrib.get("{http://www.w3.org/XML/1998/namespace}base", "")
                    try:
                        base = safe_http_url(entry_base, root_base) if entry_base else root_base
                    except ProgRSSError:
                        base = root_base
                    try:
                        link = safe_http_url(href, base)
                    except ProgRSSError:
                        link = ""
                break
            identity = child_text(entry, "id") or link or f"entry-{index}"
            title_element = child(entry, "title")
            summary_element = child(entry, "summary")
            content_element = child(entry, "content")
            full = element_reading_text(content_element, MAX_ITEM_BODY_CHARS)
            summary = element_reading_text(summary_element, 1_200) if summary_element is not None else clean_text(full, 1_200)
            body = full or summary
            item_language = xml_language(entry, language)
            items.append({
                "key": identity,
                "title": clean_text("".join(title_element.itertext()) if title_element is not None else "Untitled update", 240),
                "summary": summary,
                "body": body,
                "bodyIsSummary": not bool(full),
                "language": item_language,
                "titleLanguage": xml_language(title_element, item_language),
                "summaryLanguage": xml_language(summary_element, item_language),
                "bodyLanguage": xml_language(content_element, xml_language(summary_element, item_language)),
                "published": best_date(child_text(entry, "published") or child_text(entry, "updated")),
                "url": link,
                "index": str(index),
            })
        feed_title = "".join(child(root, "title").itertext()) if child(root, "title") is not None else origin
        return {"title": clean_text(feed_title, 180), "titleLanguage": title_language, "language": language, "type": "atom", "feedUrl": feed_url, "items": items}

    if kind == "rss":
        channel = child(root, "channel")
        candidates = children_named(channel, "item")[:250]
    elif kind == "rdf":
        channel = child(root, "channel")
        if channel is None:
            channel = root
        candidates = children_named(root, "item")[:250]
    else:
        raise ProgRSSError("not RSS, Atom, or JSON Feed")

    atom_namespace = "http://www.w3.org/2005/Atom"
    feed_url = ""
    if channel is not None:
        for link_el in list(channel):
            if local_name(link_el.tag) != "link" or namespace_uri(link_el.tag) != atom_namespace:
                continue
            if clean_text(link_el.attrib.get("rel"), 50).lower() != "self":
                continue
            href = link_el.attrib.get("href")
            if href:
                try:
                    feed_url = safe_http_url(href, origin)
                except ProgRSSError:
                    feed_url = ""
            break

    channel_title = child(channel, "title")
    channel_xml_language = xml_language(channel)
    language = language_tag(child_text(channel, "language")) or channel_xml_language
    title_language = xml_language(channel_title, channel_xml_language or language)
    items: list[dict[str, Any]] = []
    for index, entry in enumerate(candidates):
        guid_element = child(entry, "guid")
        guid = clean_text("".join(guid_element.itertext()) if guid_element is not None else "", 10_000)
        href = child_text(entry, "link")
        link = ""
        if href:
            try:
                link = safe_http_url(href, origin)
            except ProgRSSError:
                link = ""
        is_permalink = bool(guid) and clean_text(attribute_ci(guid_element, "isPermaLink") if guid_element is not None else "", 30).lower() != "false"
        if not link and is_permalink:
            try:
                link = safe_http_url(guid, origin)
            except ProgRSSError:
                link = ""
        identity = guid or link or f"item-{index}"
        title_element = child(entry, "title")
        description_element = child(entry, "description")
        description = "".join(description_element.itertext()) if description_element is not None else ""
        encoded_element = next((node for node in list(entry) if local_name(node.tag) == "encoded"), None)
        encoded = "".join(encoded_element.itertext()) if encoded_element is not None else ""
        full = strip_html(encoded, MAX_ITEM_BODY_CHARS)
        summary = strip_html(description, 1_200) if description else clean_text(full, 1_200)
        body = full or strip_html(description, MAX_ITEM_BODY_CHARS)
        item_language = xml_language(entry, channel_xml_language or language)
        items.append({
            "key": identity,
            "title": clean_text("".join(title_element.itertext()) if title_element is not None else "Untitled update", 240),
            "summary": summary,
            "body": body,
            "bodyIsSummary": not bool(full),
            "language": item_language,
            "titleLanguage": xml_language(title_element, item_language),
            "summaryLanguage": xml_language(description_element, item_language),
            "bodyLanguage": xml_language(encoded_element, xml_language(description_element, item_language)),
            "published": best_date(child_text(entry, "pubDate") or child_text(entry, "date")),
            "url": link,
            "index": str(index),
        })
    feed_title = "".join(channel_title.itertext()) if channel_title is not None else origin
    return {"title": clean_text(feed_title, 180), "titleLanguage": title_language, "language": language, "type": "rss", "feedUrl": feed_url, "items": items}


def parse_feed(raw: bytes, origin: str) -> dict[str, Any]:
    if len(raw) > MAX_FEED_BYTES:
        raise ProgRSSError("feed exceeds the 2,000,000-byte safety limit")
    origin = safe_http_url(origin)
    stripped = raw.lstrip()
    if stripped.startswith(b"{"):
        return parse_json_feed(raw, origin)
    return parse_xml_feed(raw, origin)



def attribute_ci(element: ET.Element, name: str) -> str:
    wanted = name.lower()
    for key, value in element.attrib.items():
        local = key.rsplit("}", 1)[-1].lower()
        if local == wanted:
            return str(value)
    return ""


def parse_opml(raw: bytes) -> dict[str, Any]:
    """Parse a bounded OPML subscription list without fetching anything."""
    if len(raw) > MAX_OPML_BYTES:
        raise ProgRSSError("OPML exceeds the 2,000,000-byte safety limit")
    if re.search(br"<!\s*(?:DOCTYPE|ENTITY)\b", raw, flags=re.IGNORECASE):
        raise ProgRSSError("OPML with DTD or entity declarations is refused")
    try:
        root = ET.fromstring(raw)
    except ET.ParseError as exc:
        raise ProgRSSError(f"invalid OPML XML: {exc}") from exc
    if local_name(root.tag).lower() != "opml":
        raise ProgRSSError("not an OPML document")
    head = child(root, "head")
    body = child(root, "body")
    if body is None:
        raise ProgRSSError("OPML body is missing")

    feeds: dict[str, dict[str, Any]] = {}
    folder_keys: set[tuple[str, ...]] = set()
    feed_outlines = 0
    invalid_count = 0
    duplicate_count = 0
    outline_count = 0
    truncated_count = 0

    def add_folder_path(entry: dict[str, Any], path: tuple[str, ...]) -> None:
        if not path:
            return
        paths = entry.setdefault("folderPaths", [])
        as_list = list(path)
        if as_list not in paths:
            paths.append(as_list)
        for index in range(1, len(path) + 1):
            folder_keys.add(path[:index])

    def walk(parent: ET.Element, path: tuple[str, ...] = ()) -> None:
        nonlocal feed_outlines, invalid_count, duplicate_count, outline_count, truncated_count
        for node in children_named(parent, "outline"):
            outline_count += 1
            if outline_count > MAX_OPML_OUTLINES:
                raise ProgRSSError(f"OPML contains more than {MAX_OPML_OUTLINES:,} outlines")
            label = clean_text(attribute_ci(node, "title") or attribute_ci(node, "text"), 130)
            xml_url = attribute_ci(node, "xmlUrl")
            nested = children_named(node, "outline")
            if xml_url:
                feed_outlines += 1
                try:
                    url = safe_http_url(xml_url)
                except ProgRSSError:
                    invalid_count += 1
                else:
                    existing = feeds.get(url)
                    if existing is not None:
                        duplicate_count += 1
                        add_folder_path(existing, path)
                    elif len(feeds) >= MAX_OPML_FEEDS:
                        truncated_count += 1
                    else:
                        entry = {"title": label or "Imported feed", "url": url, "folderPaths": []}
                        add_folder_path(entry, path)
                        feeds[url] = entry
                if nested:
                    walk(node, (*path, label) if label else path)
            else:
                next_path = (*path, label) if label else path
                if label and nested:
                    folder_keys.add(next_path)
                if nested:
                    walk(node, next_path)

    walk(body)
    return {
        "title": clean_text(child_text(head, "title") if head is not None else "", 180) or "Imported subscriptions",
        "feeds": list(feeds.values()),
        "feedOutlines": feed_outlines,
        "invalidCount": invalid_count,
        "duplicateCount": duplicate_count,
        "truncatedCount": truncated_count,
        "folderCount": len(folder_keys),
    }

def load_backup(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    doc = load_json_bytes(read_limited(path, MAX_BACKUP_BYTES, "backup"), str(path))
    if isinstance(doc, dict) and doc.get("schema") == BACKUP_SCHEMA and isinstance(doc.get("state"), dict):
        wrapper = doc
        state = doc["state"]
    elif isinstance(doc, dict) and isinstance(doc.get("sources"), list) and isinstance(doc.get("items"), list):
        state = doc
        wrapper = {"schema": BACKUP_SCHEMA, "exportedAt": "", "state": state}
    else:
        raise ProgRSSError("not a ProgRSS private backup or bare state")
    validate_state(state)
    return wrapper, state


def source_note_placement_count(state: dict[str, Any]) -> int:
    """Count canonical direct-placement reasons in a validated private state."""
    count = 0
    for collection in state.get("collections", []):
        if not isinstance(collection, dict) or not isinstance(collection.get("members"), list):
            continue
        for member in collection["members"]:
            if not isinstance(member, dict) or member.get("kind") != "source" or "reason" not in member:
                continue
            try:
                reason = normalize_source_note_reason(member.get("reason"))
            except SourceNoteError:
                continue
            if reason is not None:
                count += 1
    return count


def validate_private_source_note_placements(state: dict[str, Any]) -> int:
    """Apply the shared fail-closed private-library Source Notes audit."""
    try:
        return audit_private_source_note_placements(state)
    except SourceNoteError as exc:
        raise ProgRSSError(str(exc)) from exc


def validate_state(state: dict[str, Any]) -> None:
    version = state.get("version")
    if version not in range(2, 18):
        raise ProgRSSError(f"unsupported vault version: {version!r}")
    for key, limit in (("sources", MAX_SOURCES), ("collections", MAX_COLLECTIONS), ("items", MAX_ITEMS)):
        if not isinstance(state.get(key), list):
            raise ProgRSSError(f"backup field {key!r} must be an array")
        if len(state[key]) > limit:
            raise ProgRSSError(f"backup has too many {key}: {len(state[key])} > {limit}")
    if not isinstance(state.get("snapshots", {}), dict):
        raise ProgRSSError("backup snapshots must be an object")
    if len(state.get("snapshots", {})) > MAX_SOURCES:
        raise ProgRSSError(f"backup has too many page-watch snapshots: {len(state['snapshots'])} > {MAX_SOURCES}")
    for key, limit in ADVANCED_STATE_LIMITS.items():
        value = state.get(key, [])
        if not isinstance(value, list):
            raise ProgRSSError(f"backup field {key!r} must be an array")
        if len(value) > limit:
            raise ProgRSSError(f"backup has too many {key}: {len(value)} > {limit}")
    validate_private_source_note_placements(state)
    retired = state.get("retiredReceipts", [])
    if not isinstance(retired, list):
        raise ProgRSSError("backup field 'retiredReceipts' must be an array")
    if len(retired) > MAX_RETIRED_RECEIPTS:
        raise ProgRSSError(f"backup has too many retired receipts: {len(retired)} > {MAX_RETIRED_RECEIPTS}")
    for index, envelope in enumerate(retired):
        if not isinstance(envelope, dict) or envelope.get("schema") != RETIRED_GRAFT_RECEIPT_SCHEMA:
            raise ProgRSSError(f"retiredReceipts[{index}] is not a supported retired graft receipt")
        if not isinstance(envelope.get("originalReceipt"), dict) or envelope["originalReceipt"].get("schema") != GRAFT_RECEIPT_SCHEMA:
            raise ProgRSSError(f"retiredReceipts[{index}] does not preserve an exact graft receipt")
        if not re.fullmatch(r"[0-9a-f]{64}", clean_text(envelope.get("originalDigest"), 64)):
            raise ProgRSSError(f"retiredReceipts[{index}] has an invalid canonical digest")


def source_map(state: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {str(row.get("id")): row for row in state["sources"] if isinstance(row, dict) and row.get("id")}


def valid_page_change(raw: Any) -> bool:
    if not isinstance(raw, dict) or raw.get("schema") != PAGE_CHANGE_SCHEMA:
        return False
    allowed = {
        "schema", "kind", "mode", "summary", "before", "after", "removed", "added",
        "removedWords", "addedWords", "delta", "threshold", "ignoreNumbers",
    }
    if any(key not in allowed for key in raw):
        return False
    if raw.get("kind") not in PAGE_CHANGE_KINDS or raw.get("mode") not in PAGE_CHANGE_MODES:
        return False
    for name, maximum in (("summary", 500), ("before", 1_200), ("after", 1_200), ("removed", 1_000), ("added", 1_000)):
        if name in raw and (not isinstance(raw[name], str) or len(raw[name]) > maximum):
            return False
    for name, maximum in (("removedWords", 20_000), ("addedWords", 20_000), ("delta", 1_000_000), ("threshold", 120_000)):
        if name not in raw:
            continue
        value = raw[name]
        if isinstance(value, bool):
            return False
        try:
            number = float(value)
        except (TypeError, ValueError):
            return False
        if not math.isfinite(number) or number < 0 or number > maximum or not number.is_integer():
            return False
    if "ignoreNumbers" in raw and not isinstance(raw["ignoreNumbers"], bool):
        return False
    return any(isinstance(raw.get(key), str) and raw.get(key).strip() for key in ("summary", "before", "after", "removed", "added"))


def normalized_page_change(raw: Any) -> dict[str, Any] | None:
    if not valid_page_change(raw):
        return None

    def count(name: str) -> int:
        return int(float(raw.get(name, 0)))

    return {
        "schema": PAGE_CHANGE_SCHEMA,
        "kind": raw["kind"],
        "mode": raw["mode"],
        "summary": clean_text(raw.get("summary"), 500),
        "before": clean_text(raw.get("before"), 1_200),
        "after": clean_text(raw.get("after"), 1_200),
        "removed": clean_text(raw.get("removed"), 1_000),
        "added": clean_text(raw.get("added"), 1_000),
        "removedWords": count("removedWords"),
        "addedWords": count("addedWords"),
        "delta": count("delta"),
        "threshold": count("threshold"),
        "ignoreNumbers": raw.get("ignoreNumbers", False),
    }


def page_change_reason(change: dict[str, Any] | None) -> str:
    if not change:
        return "This older page-watch alert does not contain a before-and-after explanation."
    if change["kind"] == "entry-added":
        return "A new entry appeared in the repeated list this watch follows."
    if change["kind"] == "entry-removed":
        return "An entry that appeared in the repeated list was no longer present."
    added = int(change.get("addedWords", 0))
    removed = int(change.get("removedWords", 0))
    if not added and not removed:
        return (
            "Punctuation or symbols changed in an entry already in the watched list."
            if change["kind"] == "entry-changed"
            else "Punctuation or symbols changed in the watched main text."
        )
    if added and removed:
        amount = f"{added} word{'s' if added != 1 else ''} added and {removed} word{'s' if removed != 1 else ''} removed"
    elif added:
        amount = f"{added} word{'s' if added != 1 else ''} added"
    else:
        amount = f"{removed} word{'s' if removed != 1 else ''} removed"
    if change["kind"] == "entry-changed":
        return f"The wording of an entry already in the watched list changed: {amount}."
    return f"The watched main text changed: {amount}."


def page_change_policy(change: dict[str, Any] | None) -> str:
    if not change:
        return ""
    parts: list[str] = []
    threshold = int(change.get("threshold", 0))
    if threshold > 1:
        parts.append(f"Changes smaller than {threshold} characters are ignored.")
    parts.append("Changes made only to numbers are ignored." if change.get("ignoreNumbers") else "Number changes are included.")
    return " ".join(parts)


def state_audit(state: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    source_ids: set[str] = set()
    item_ids: set[str] = set()
    collection_ids: set[str] = set()

    for index, source in enumerate(state["sources"]):
        if not isinstance(source, dict):
            errors.append(f"sources[{index}] is not an object")
            continue
        identity = clean_text(source.get("id"), 300)
        if not identity:
            errors.append(f"sources[{index}] has no id")
        elif identity in source_ids:
            errors.append(f"duplicate source id: {identity}")
        else:
            source_ids.add(identity)
        try:
            safe_http_url(source.get("url"))
        except ProgRSSError as exc:
            errors.append(f"source {identity or index}: {exc}")
        if source.get("type") not in {"rss", "page"}:
            warnings.append(f"source {identity or index}: unfamiliar type {source.get('type')!r}")
        if source.get("textRetention") not in (None, "summary"):
            errors.append(f"source {identity or index}: textRetention must be 'summary' when present")

    for index, collection in enumerate(state["collections"]):
        if not isinstance(collection, dict):
            errors.append(f"collections[{index}] is not an object")
            continue
        identity = clean_text(collection.get("id"), 300)
        if not identity:
            errors.append(f"collections[{index}] has no id")
        elif identity in collection_ids:
            errors.append(f"duplicate collection id: {identity}")
        else:
            collection_ids.add(identity)

    for index, item in enumerate(state["items"]):
        if not isinstance(item, dict):
            errors.append(f"items[{index}] is not an object")
            continue
        identity = clean_text(item.get("id"), 700)
        if not identity:
            errors.append(f"items[{index}] has no id")
        elif identity in item_ids:
            errors.append(f"duplicate item id: {identity}")
        else:
            item_ids.add(identity)
        sid = clean_text(item.get("sourceId"), 300)
        if not sid or sid not in source_ids:
            warnings.append(f"item {identity or index}: source {sid or '(missing)'} is not present")
        if not isinstance(item.get("body", ""), str) or len(item.get("body", "")) > MAX_ITEM_BODY_CHARS:
            errors.append(f"item {identity or index}: body must be text no longer than {MAX_ITEM_BODY_CHARS:,} characters")
        if item.get("bodyIsSummary") not in (None, True, False):
            errors.append(f"item {identity or index}: bodyIsSummary must be a boolean")
        if item.get("bodyOmitted") not in (None, True, False):
            errors.append(f"item {identity or index}: bodyOmitted must be a boolean")
        if item.get("change") is not None and not valid_page_change(item.get("change")):
            errors.append(f"item {identity or index}: change must be a bounded {PAGE_CHANGE_SCHEMA} record")
        if item.get("url"):
            try:
                safe_http_url(item["url"])
            except ProgRSSError as exc:
                warnings.append(f"item {identity or index}: {exc}")

    return {
        "state": "invalid" if errors else ("needs-review" if warnings else "valid"),
        "errors": errors,
        "warnings": warnings,
        "counts": {"sources": len(source_ids), "collections": len(collection_ids), "items": len(item_ids)},
    }


def item_sort_key(item: dict[str, Any]) -> tuple[str, str]:
    return (clean_text(item.get("published") or item.get("observedAt"), 100), clean_text(item.get("id"), 700))



def simple_folder_model(state: dict[str, Any]) -> dict[str, Any]:
    """Return a bounded, human folder view over plain union collections.

    Advanced filters and non-union operators deliberately remain Workbench-only.
    Collections in a rootless cycle are omitted rather than presented as a tidy
    hierarchy that the evidence does not support.
    """
    source_ids = {
        clean_text(row.get("id"), 300)
        for row in state.get("sources", [])
        if isinstance(row, dict) and clean_text(row.get("id"), 300)
    }
    simple: dict[str, dict[str, Any]] = {}
    collection_count = sum(1 for row in state.get("collections", []) if isinstance(row, dict) and clean_text(row.get("id"), 300))
    for row in state.get("collections", []):
        if not isinstance(row, dict):
            continue
        identity = clean_text(row.get("id"), 300)
        title = clean_text(row.get("title"), 180)
        mode = clean_text(row.get("mode") or "union", 30).lower()
        if not identity or not title or mode != "union":
            continue
        if clean_text(row.get("include"), 500) or clean_text(row.get("exclude"), 500):
            continue
        if not isinstance(row.get("members", []), list):
            continue
        simple[identity] = row

    children: dict[str, list[str]] = {identity: [] for identity in simple}
    direct_sources: dict[str, set[str]] = {identity: set() for identity in simple}
    referenced: set[str] = set()
    for identity, row in simple.items():
        for member in row.get("members", [])[:500]:
            if not isinstance(member, dict):
                continue
            member_id = clean_text(member.get("id"), 300)
            if member.get("kind") == "source" and member_id in source_ids:
                direct_sources[identity].add(member_id)
            elif member.get("kind") == "collection" and member_id in simple:
                children[identity].append(member_id)
                referenced.add(member_id)

    discovered: dict[str, list[tuple[str, ...]]] = {identity: [] for identity in simple}
    cycle_edges: set[tuple[str, str]] = set()

    def walk(identity: str, path: tuple[str, ...], stack: tuple[str, ...]) -> None:
        if identity in stack:
            cycle_edges.add((stack[-1], identity))
            return
        title = clean_text(simple[identity].get("title"), 180)
        here = (*path, title)
        if here not in discovered[identity] and len(discovered[identity]) < 12:
            discovered[identity].append(here)
        if len(stack) >= 24:
            return
        for child_id in children[identity]:
            walk(child_id, here, (*stack, identity))

    roots = sorted((identity for identity in simple if identity not in referenced), key=lambda key: clean_text(simple[key].get("title"), 180).casefold())
    for identity in roots:
        walk(identity, (), ())

    visible = {identity for identity, paths in discovered.items() if paths}

    def closure(identity: str, stack: tuple[str, ...] = ()) -> set[str]:
        if identity in stack or len(stack) >= 24:
            return set()
        result = set(direct_sources[identity])
        for child_id in children[identity]:
            if child_id in visible:
                result.update(closure(child_id, (*stack, identity)))
        return result

    rows: list[dict[str, Any]] = []
    for identity in visible:
        path = min(discovered[identity], key=lambda value: (len(value), tuple(part.casefold() for part in value)))
        rows.append({
            "id": identity,
            "title": clean_text(simple[identity].get("title"), 180),
            "path": " › ".join(path),
            "sourceIds": closure(identity),
            "directSourceIds": set(direct_sources[identity]),
            "childFolderCount": sum(1 for child_id in children[identity] if child_id in visible),
        })
    rows.sort(key=lambda row: (row["path"].casefold(), row["id"]))
    filed = set().union(*(row["sourceIds"] for row in rows)) if rows else set()
    return {
        "rows": rows,
        "unfiledSourceIds": source_ids - filed,
        "omittedCollections": max(0, collection_count - len(visible)),
        "cycleEdges": len(cycle_edges),
    }


def resolve_folder_scope(state: dict[str, Any], raw: Any) -> tuple[str, str, set[str] | None]:
    value = clean_text(raw, 300)
    if not value or value.casefold() == "all":
        return "all", "All", None
    model = simple_folder_model(state)
    if value.casefold() == "unfiled":
        return "unfiled", "Unfiled", set(model["unfiledSourceIds"])
    folded = value.casefold()
    exact = [row for row in model["rows"] if row["id"].casefold() == folded or row["path"].casefold() == folded]
    if not exact:
        exact = [row for row in model["rows"] if row["title"].casefold() == folded]
    if len(exact) > 1:
        options = ", ".join(row["path"] for row in exact[:8])
        raise ProgRSSError(f"folder name is ambiguous; use an id or full path: {options}")
    if not exact:
        raise ProgRSSError(f"folder not found: {value}")
    row = exact[0]
    return row["id"], row["path"], set(row["sourceIds"])


def folder_rows(state: dict[str, Any]) -> dict[str, Any]:
    model = simple_folder_model(state)
    sources = source_map(state)
    unread_by_source: dict[str, int] = {}
    for item in state.get("items", []):
        if isinstance(item, dict) and not item.get("readAt"):
            source_id = clean_text(item.get("sourceId"), 300)
            unread_by_source[source_id] = unread_by_source.get(source_id, 0) + 1

    def describe(identity: str, title: str, path: str, source_set: set[str], direct_set: set[str]) -> dict[str, Any]:
        existing = [sources[sid] for sid in sorted(source_set) if sid in sources]
        return {
            "id": identity,
            "title": title,
            "path": path,
            "sourceCount": len(existing),
            "directSourceCount": len([sid for sid in direct_set if sid in sources]),
            "activeSourceCount": sum(1 for row in existing if row.get("enabled") and not row.get("archivedAt")),
            "unreadCount": sum(unread_by_source.get(clean_text(row.get("id"), 300), 0) for row in existing),
        }

    rows = [describe(row["id"], row["title"], row["path"], row["sourceIds"], row["directSourceIds"]) for row in model["rows"]]
    unfiled = set(model["unfiledSourceIds"])
    return {
        "rows": rows,
        "unfiled": describe("unfiled", "Unfiled", "Unfiled", unfiled, unfiled),
        "omittedCollections": model["omittedCollections"],
        "cycleEdges": model["cycleEdges"],
    }


def matching_items(state: dict[str, Any], args: argparse.Namespace) -> list[dict[str, Any]]:
    sources = source_map(state)
    source_term = clean_text(getattr(args, "source", ""), 300).lower()
    contains = clean_text(getattr(args, "contains", ""), 300).lower()
    _folder_id, _folder_label, folder_sources = resolve_folder_scope(state, getattr(args, "folder", ""))
    output: list[dict[str, Any]] = []
    for item in sorted((row for row in state["items"] if isinstance(row, dict)), key=item_sort_key, reverse=True):
        source_id = str(item.get("sourceId"))
        source = sources.get(source_id, {})
        if folder_sources is not None and source_id not in folder_sources:
            continue
        if getattr(args, "unread_only", False) and item.get("readAt"):
            continue
        if getattr(args, "starred_only", False) and not item.get("starred"):
            continue
        if source_term:
            hay = f"{source.get('id', '')} {source.get('title', '')} {source.get('url', '')}".lower()
            if source_term not in hay:
                continue
        if contains:
            change = normalized_page_change(item.get("change"))
            hay = (
                f"{source.get('title', '')} {item.get('title', '')} {item.get('summary', '')} {item.get('body', '')} "
                f"{change.get('before', '') if change else ''} {change.get('after', '') if change else ''} "
                f"{change.get('removed', '') if change else ''} {change.get('added', '') if change else ''}"
            ).lower()
            if contains not in hay:
                continue
        output.append(item)
    return output



def source_activity_rows(state: dict[str, Any]) -> list[dict[str, Any]]:
    folder_model = simple_folder_model(state)
    direct_folders: dict[str, list[str]] = {}
    for folder in folder_model["rows"]:
        for source_id in folder["directSourceIds"]:
            direct_folders.setdefault(source_id, []).append(folder["path"])
    newest_by_source: dict[str, str] = {}
    newest_stamp: dict[str, float] = {}
    for item in state["items"]:
        if not isinstance(item, dict):
            continue
        source_id = clean_text(item.get("sourceId"), 300)
        raw = clean_text(item.get("observedAt") or item.get("published"), 100)
        parsed = best_date(raw)
        if not source_id or not parsed:
            continue
        try:
            stamp = dt.datetime.fromisoformat(parsed.replace("Z", "+00:00")).timestamp()
        except ValueError:
            continue
        if stamp > newest_stamp.get(source_id, float("-inf")):
            newest_stamp[source_id] = stamp
            newest_by_source[source_id] = parsed

    rows: list[dict[str, Any]] = []
    for source in state["sources"]:
        if not isinstance(source, dict):
            continue
        source_id = clean_text(source.get("id"), 300)
        archived = bool(source.get("archivedAt"))
        enabled = bool(source.get("enabled")) and not archived
        last_error = clean_text(source.get("lastError"), 500)
        pending = source.get("pendingRedirect") if isinstance(source.get("pendingRedirect"), dict) else None
        permission_missing = bool(source.get("permissionMissing"))
        watch_stability = source.get("watchStability") if isinstance(source.get("watchStability"), dict) else None
        try:
            watch_stability_observations = max(1, min(2, int(watch_stability.get("observations") or 1))) if watch_stability else 0
        except (TypeError, ValueError):
            watch_stability_observations = 1 if watch_stability else 0
        if archived:
            status = "archived"
        elif not enabled:
            status = "paused"
        elif pending:
            status = "moved"
        elif permission_missing:
            status = "reconnect"
        elif isinstance(source.get("watchRepair"), dict):
            status = "watch-repair"
        elif watch_stability:
            status = "checking-again"
        elif last_error:
            status = "needs-attention"
        else:
            status = "following"
        last_scan = best_date(source.get("lastScan"))
        outcome = clean_text(source.get("lastOutcome"), 80)
        last_success = best_date(source.get("lastSuccessfulAt"))
        if not last_success and last_scan and outcome not in {"error", "throttled"}:
            last_success = last_scan
        last_new = best_date(source.get("lastNewAt")) or newest_by_source.get(source_id, "")
        last_problem_at = best_date(source.get("lastProblemAt"))
        if not last_problem_at and last_error:
            last_problem_at = last_scan
        last_problem = clean_text(source.get("lastProblem") or last_error, 500)
        rows.append({
            "id": source_id,
            "title": clean_text(source.get("title"), 180) or "Untitled source",
            "type": clean_text(source.get("type"), 30),
            "url": clean_text(source.get("url"), 2_048),
            "status": status,
            "lastSuccessfulAt": last_success,
            "lastNewAt": last_new,
            "lastProblemAt": last_problem_at,
            "lastProblem": last_problem,
            "lastOutcome": outcome,
            "watchRepair": {
                "reason": clean_text(source.get("watchRepair", {}).get("reason"), 60),
                "message": clean_text(source.get("watchRepair", {}).get("message"), 500),
                "noticedAt": best_date(source.get("watchRepair", {}).get("noticedAt")),
            } if isinstance(source.get("watchRepair"), dict) else None,
            "watchStability": {
                "reason": clean_text(watch_stability.get("reason"), 60),
                "message": clean_text(watch_stability.get("message"), 500),
                "observations": watch_stability_observations,
                "lastSeenAt": best_date(watch_stability.get("lastSeenAt")),
            } if watch_stability else None,
            "move": {
                "from": clean_text(pending.get("from"), 2_048),
                "to": clean_text(pending.get("to"), 2_048),
                "observedAt": best_date(pending.get("observedAt")),
            } if pending else None,
            "previousUrls": [clean_text(value, 2_048) for value in source.get("previousUrls", []) if isinstance(value, str)][:4],
            "folders": sorted(direct_folders.get(source_id, []), key=str.casefold)[:12],
        })
    attention = {"moved": 0, "reconnect": 1, "watch-repair": 2, "needs-attention": 3, "checking-again": 4, "following": 4, "paused": 5, "archived": 6}
    rows.sort(key=lambda row: (attention.get(row["status"], 9), row["title"].lower(), row["id"]))
    return rows


def access_plan_origin(raw: Any) -> str:
    """Return one display-safe HTTP(S) origin without a path or credentials."""
    scheme, host, port = url_origin(clean_text(raw, 2_048))
    shown_host = f"[{host}]" if ":" in host and not host.startswith("[") else host
    default_port = 443 if scheme == "https" else 80
    suffix = "" if port == default_port else f":{port}"
    return f"{scheme}://{shown_host}{suffix}"


def workspace_access_plan(state: dict[str, Any], source_selector: str = "", *, show_origins: bool = False) -> dict[str, Any]:
    """Describe visible Extension actions that may need site access.

    This intentionally does not infer live browser grants from a portable backup.
    Scheduled checks never manufacture permission prompts; a missing grant becomes
    a visible Reconnect decision in the Extension.
    """
    rows = source_activity_rows(state)
    selected_source = None
    if clean_text(source_selector, 2_048):
        selected_source = resolve_source_for_storage(state, source_selector)
        selected_id = clean_text(selected_source.get("id"), 300)
        rows = [row for row in rows if row["id"] == selected_id]

    source_by_id = {
        clean_text(row.get("id"), 300): row
        for row in state.get("sources", [])
        if isinstance(row, dict)
    }
    action_rules = {
        "following": {
            "nextAction": "Refresh in the Extension",
            "visibleControl": "Refresh",
            "scheduledCheckEligible": True,
            "notGrantedResult": "The source is not checked and its library state stays unchanged.",
        },
        "checking-again": {
            "nextAction": "Check again in the Extension",
            "visibleControl": "Check again",
            "scheduledCheckEligible": True,
            "notGrantedResult": "The held page result keeps waiting; no alert or source change is created.",
        },
        "needs-attention": {
            "nextAction": "Refresh in the Extension",
            "visibleControl": "Refresh",
            "scheduledCheckEligible": True,
            "notGrantedResult": "The source is not checked and its earlier problem remains unchanged.",
        },
        "paused": {
            "nextAction": "Resume in the Extension",
            "visibleControl": "Resume",
            "scheduledCheckEligible": False,
            "notGrantedResult": "The source stays paused.",
        },
        "reconnect": {
            "nextAction": "Reconnect and check in the Extension",
            "visibleControl": "Reconnect and check now",
            "scheduledCheckEligible": False,
            "notGrantedResult": "The source still needs reconnecting.",
        },
        "moved": {
            "nextAction": "Review the address move in the Extension",
            "visibleControl": "Follow at the new site",
            "scheduledCheckEligible": False,
            "notGrantedResult": "The current address is kept and the destination is not contacted.",
        },
        "watch-repair": {
            "nextAction": "Find what to watch now in the Extension",
            "visibleControl": "Find what to watch now",
            "scheduledCheckEligible": False,
            "notGrantedResult": "The current watch rule and earlier alerts are kept.",
        },
        "archived": {
            "nextAction": "No site-access action while archived",
            "visibleControl": "",
            "scheduledCheckEligible": False,
            "notGrantedResult": "Nothing changes while the source remains archived.",
        },
    }

    plans: list[dict[str, Any]] = []
    all_origins: set[str] = set()
    for row in rows:
        source = source_by_id.get(row["id"], {})
        rule = action_rules.get(row["status"], action_rules["following"])
        raw_addresses: list[str] = []
        if clean_text(source.get("url"), 2_048):
            raw_addresses.append(clean_text(source.get("url"), 2_048))
        pending = source.get("pendingRedirect") if isinstance(source.get("pendingRedirect"), dict) else None
        if pending:
            for key in ("from", "to"):
                value = clean_text(pending.get(key), 2_048)
                if value:
                    raw_addresses.append(value)
        origins: list[str] = []
        for raw in raw_addresses:
            try:
                origin = access_plan_origin(raw)
            except ProgRSSError:
                continue
            if origin not in origins:
                origins.append(origin)
                all_origins.add(origin)
        plan = {
            "id": row["id"],
            "title": row["title"],
            "type": row["type"],
            "status": row["status"],
            "nextAction": rule["nextAction"],
            "visibleControl": rule["visibleControl"],
            "scheduledCheckEligible": rule["scheduledCheckEligible"],
            "siteAccessDecision": "visible-action-only" if rule["visibleControl"] else "none-while-archived",
            "currentBrowserGrant": "unknown",
            "notGrantedResult": rule["notGrantedResult"],
            "siteCount": len(origins),
        }
        if show_origins:
            plan["origins"] = origins
        plans.append(plan)

    counts = {key: sum(1 for row in plans if row["status"] == key) for key in action_rules}
    return {
        "schema": ACCESS_PLAN_SCHEMA,
        "sourceCount": len(plans),
        "distinctSiteCount": len(all_origins),
        "summary": {
            "following": counts["following"],
            "checkingAgain": counts["checking-again"],
            "needsAttention": counts["needs-attention"],
            "paused": counts["paused"],
            "reconnect": counts["reconnect"],
            "moved": counts["moved"],
            "watchRepair": counts["watch-repair"],
            "archived": counts["archived"],
            "scheduledCheckEligible": sum(1 for row in plans if row["scheduledCheckEligible"]),
        },
        "sources": plans,
        "originsIncluded": bool(show_origins),
        "browserPermissionState": "unknown",
        "network": False,
        "writes": False,
        "browserProfileRead": False,
        "permissionsRead": False,
        "note": "Scheduled checks never open a site-access prompt. The Extension asks only from the named visible action and leaves the pending task unchanged when access is not granted.",
    }


def page_watch_repair_report(state: dict[str, Any], source: dict[str, Any], raw: bytes) -> dict[str, Any]:
    proposals = page_watch_repair_proposals(raw, source)
    return {
        "schema": PAGE_WATCH_REPAIR_REVIEW_SCHEMA,
        "source": {
            "id": clean_text(source.get("id"), 300),
            "title": clean_text(source.get("title"), 180) or "Untitled page watch",
            "url": clean_text(source.get("url"), 2_048),
            "reason": clean_text((source.get("watchRepair") or {}).get("reason"), 60) if isinstance(source.get("watchRepair"), dict) else "",
        },
        "proposals": [
            {
                "id": row["id"], "mode": row["mode"], "title": row["title"],
                "description": row["description"], "count": row["count"],
                "examples": row["examples"], "preview": row["preview"],
                "recipe": copy.deepcopy(row["recipe"]),
            }
            for row in proposals
        ],
        "preserves": ["Earlier page-change alerts", "Read and saved state", "Folder placement", "Source activity history"],
        "network": False,
        "writes": False,
        "browserProfileRead": False,
    }


def cmd_workspace_assess_page_watch(args: argparse.Namespace) -> int:
    _wrapper, state = load_backup(Path(args.backup))
    source = resolve_source_for_storage(state, args.source)
    if source.get("type") != "page":
        raise ProgRSSError("selected source is not a page watch")
    raw = read_limited(Path(args.html), MAX_FEED_BYTES, "HTML specimen")
    confirm_raw = read_limited(Path(args.confirm_html), MAX_FEED_BYTES, "confirmation HTML specimen") if args.confirm_html else None
    report = page_watch_assessment_report(state, source, raw, confirm_raw)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(f"Page-watch reliability check · {report['source']['title']}")
        print("Local HTML specimen · no network · no writes")
        for index, observation in enumerate(report["observations"], 1):
            decision = observation["decision"]
            health = observation["health"]
            print(f"{index}. {health.get('status', 'unknown')} · {health.get('reason', 'unknown')}")
            print(f"   {decision.get('health', {}).get('message') or observation.get('message') or 'No message.'}")
        print(f"Result: {report['result']}")
        print(report["nextAction"])
        print("No page alerts written · no snapshot changed")
    return 0


def cmd_workspace_review_page_watch(args: argparse.Namespace) -> int:
    _wrapper, state = load_backup(Path(args.backup))
    source = resolve_source_for_storage(state, args.source)
    if source.get("type") != "page":
        raise ProgRSSError("selected source is not a page watch")
    raw = read_limited(Path(args.html), MAX_FEED_BYTES, "HTML specimen")
    report = page_watch_repair_report(state, source, raw)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(f"Page-watch repair review · {report['source']['title']}")
        print("Local HTML specimen · no network · no writes")
        for index, proposal in enumerate(report["proposals"], 1):
            print(f"{index}. {proposal['title']} [{proposal['id']}]")
            print(f"   {proposal['description']}")
            if proposal["mode"] == "cards":
                print(f"   {proposal['count']} readable entries")
                for example in proposal["examples"][:4]:
                    print(f"   - {example}")
            elif proposal["preview"]:
                print(f"   {proposal['preview']}")
        print("Nothing changed. Repair creates a fresh baseline and keeps earlier alerts.")
    return 0


def cmd_workspace_repair_page_watch(args: argparse.Namespace) -> int:
    wrapper, state = load_backup(Path(args.backup))
    source = resolve_source_for_storage(state, args.source)
    if source.get("type") != "page":
        raise ProgRSSError("selected source is not a page watch")
    raw = read_limited(Path(args.html), MAX_FEED_BYTES, "HTML specimen")
    proposals = page_watch_repair_proposals(raw, source)
    selected = next((row for row in proposals if row["id"] == clean_text(args.proposal, 100)), None)
    if selected is None:
        available = ", ".join(row["id"] for row in proposals)
        raise ProgRSSError(f"proposal not found in this specimen; available proposal ids: {available}")

    result = copy.deepcopy(wrapper)
    result_state = copy.deepcopy(state)
    source_id = clean_text(source.get("id"), 300)
    target = next((row for row in result_state["sources"] if isinstance(row, dict) and clean_text(row.get("id"), 300) == source_id), None)
    if target is None:
        raise ProgRSSError("page watch disappeared from the copied backup")
    recipe = selected["recipe"]
    target["mode"] = recipe["mode"]
    target["selector"] = recipe["selector"]
    target["titleSelector"] = recipe["titleSelector"]
    target["linkSelector"] = recipe["linkSelector"]
    target["threshold"] = recipe["threshold"]
    target["ignoreNumbers"] = recipe["ignoreNumbers"]
    target["version"] = max(1, min(10_000, int(target.get("version") or 1) + 1))
    target.pop("watchRepair", None)
    target.pop("watchStability", None)
    stamp = utc_now()
    target["watchHealth"] = {
        "schema": PAGE_WATCH_HEALTH_SCHEMA,
        "status": "steady",
        "reason": "baseline",
        "checkedAt": stamp,
        "message": "The repaired watch has a fresh baseline from the supplied local specimen.",
        "metrics": {
            "currentEntries": len(selected["capture"].get("cards", [])) if selected["mode"] == "cards" else 0,
            "currentCharacters": len(selected["capture"].get("content", "")) if selected["mode"] == "region" else 0,
            "matchCount": int(selected["capture"].get("matchCount") or 0),
        },
    }
    target["lastScan"] = stamp
    target["lastSuccessfulAt"] = stamp
    target["lastItems"] = 0
    target["lastOutcome"] = "baseline"
    target["lastError"] = ""
    pulse = target.get("pulse") if isinstance(target.get("pulse"), dict) else {}
    pulse.pop("needsReview", None)
    target["pulse"] = pulse

    snapshots = result_state.get("snapshots") if isinstance(result_state.get("snapshots"), dict) else {}
    capture = selected["capture"]
    if selected["mode"] == "cards":
        entries = [
            {"key": row["key"], "title": row["title"], "summary": row["summary"], "url": row["url"]}
            for row in capture["cards"][:200]
        ]
        snapshots[source_id] = {"mode": "cards", "keys": [row["key"] for row in entries], "entries": entries, "capturedAt": stamp}
    else:
        snapshots[source_id] = {"mode": "region", "text": capture["content"][:120_000], "capturedAt": stamp}
    result_state["snapshots"] = snapshots

    before_items = len(result_state.get("items", []))
    result["schema"] = BACKUP_SCHEMA
    result["exportedAt"] = stamp
    result["state"] = portable_state(result_state)
    if len(result["state"].get("items", [])) != before_items:
        raise ProgRSSError("internal refusal: repair changed retained page alerts")
    write_new(Path(args.output), json_bytes(result))
    print(f"Repaired {clean_text(target.get('title'), 180) or 'page watch'} from local HTML proposal {selected['id']}")
    print("Fresh baseline · 0 synthetic change alerts · earlier history preserved")
    print(f"Wrote {args.output} · offline · new-file-only")
    return 0


def cmd_workspace_sources(args: argparse.Namespace) -> int:
    _wrapper, state = load_backup(Path(args.backup))
    rows = source_activity_rows(state)
    folder_id, folder_label, folder_sources = resolve_folder_scope(state, getattr(args, "folder", ""))
    if folder_sources is not None:
        rows = [row for row in rows if row["id"] in folder_sources]
    if args.problems_only:
        rows = [row for row in rows if row["status"] in {"moved", "reconnect", "watch-repair", "needs-attention"}]
    shown = rows[: args.limit]
    if args.json:
        print(json.dumps({
            "schema": "progrss.workspace.sources.v1",
            "count": len(rows),
            "sources": shown,
            "folder": {"id": folder_id, "label": folder_label},
            "network": False,
        }, ensure_ascii=False, indent=2))
    else:
        if folder_id != "all":
            print(f"Folder: {folder_label}")
        print(f"{len(rows)} source{'s' if len(rows) != 1 else ''}")
        for row in shown:
            label = {
                "following": "Following",
                "paused": "Paused",
                "archived": "Archived",
                "watch-repair": "Repair page watch",
                "checking-again": "Checking again",
                "needs-attention": "Needs attention",
                "moved": "Moved — review in the Extension",
                "reconnect": "Reconnect in the Extension",
            }.get(row["status"], row["status"])
            print(f"- {row['title']} — {label}")
            print(f"  {row['url']}")
            if row["folders"]:
                print(f"  Folder: {', '.join(row['folders'])}")
            if row["move"]:
                print(f"  Old address: {row['move']['from'] or row['url']}")
                print(f"  New address: {row['move']['to'] or 'unknown'}")
            if row["watchRepair"]:
                print(f"  Repair reason: {row['watchRepair']['message'] or row['watchRepair']['reason'] or 'The watched section changed.'}")
                print("  Next action: review-page-watch with a local HTML specimen")
            if row["watchStability"]:
                print(f"  Held result: {row['watchStability']['message'] or 'One unusual page shape is waiting for another check.'}")
                print("  No page-change alert was created.")
            print(f"  Successful check: {row['lastSuccessfulAt'] or 'not yet'}")
            print(f"  New update: {row['lastNewAt'] or 'none yet'}")
            if row["lastProblemAt"] or row["lastProblem"]:
                detail = row["lastProblem"] or "problem recorded"
                print(f"  Last problem: {row['lastProblemAt'] or 'time unknown'} · {detail}")
            else:
                print("  Last problem: none recorded")
    return 0


def cmd_workspace_access_plan(args: argparse.Namespace) -> int:
    _wrapper, state = load_backup(Path(args.backup))
    report = workspace_access_plan(state, getattr(args, "source", ""), show_origins=bool(args.origins))
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0

    print(f"Site-access plan · {report['sourceCount']} source{'s' if report['sourceCount'] != 1 else ''} · {report['distinctSiteCount']} site{'s' if report['distinctSiteCount'] != 1 else ''}")
    print("Current browser grants are unknown · no browser-profile read · no network · no writes")
    for row in report["sources"]:
        label = {
            "following": "Following",
            "checking-again": "Checking again",
            "needs-attention": "Needs attention",
            "paused": "Paused",
            "reconnect": "Reconnect",
            "moved": "Moved",
            "watch-repair": "Repair page watch",
            "archived": "Archived",
        }.get(row["status"], row["status"])
        print(f"- {row['title']} — {label}")
        print(f"  Next action: {row['nextAction']}")
        if row["visibleControl"]:
            print(f"  Access decision: only from the visible “{row['visibleControl']}” action")
            print(f"  If not granted: {row['notGrantedResult']}")
        else:
            print("  Access decision: none while archived")
        print(f"  Scheduled check eligible: {'yes' if row['scheduledCheckEligible'] else 'no'}")
        if args.origins:
            shown = row.get("origins") or []
            print(f"  Site{'s' if len(shown) != 1 else ''}: {', '.join(shown) if shown else 'none'}")
    if not args.origins and report["distinctSiteCount"]:
        print("Sites hidden by default · add --origins to show them")
    print("Scheduled checks never prompt · an ungranted request leaves the pending task unchanged")
    return 0


def cmd_workspace_folders(args: argparse.Namespace) -> int:
    _wrapper, state = load_backup(Path(args.backup))
    report = folder_rows(state)
    rows = list(report["rows"])
    if args.include_unfiled or report["unfiled"]["sourceCount"]:
        rows.append(report["unfiled"])
    if args.json:
        print(json.dumps({
            "schema": "progrss.workspace.folders.v1",
            "count": len(rows),
            "folders": rows,
            "omittedAdvancedOrCyclicCollections": report["omittedCollections"],
            "network": False,
            "writes": False,
        }, ensure_ascii=False, indent=2))
    else:
        simple_count = len(report["rows"])
        unfiled_shown = any(row.get("id") == "unfiled" for row in rows)
        suffix = " · Unfiled shown" if unfiled_shown else ""
        print(f"{simple_count} simple folder{'s' if simple_count != 1 else ''}{suffix} · offline · no writes")
        for row in rows:
            print(f"- {row['path']} — {row['sourceCount']} source{'s' if row['sourceCount'] != 1 else ''} · {row['unreadCount']} unread")
        if report["omittedCollections"]:
            print(f"{report['omittedCollections']} advanced or cyclic collection{'s' if report['omittedCollections'] != 1 else ''} remain Workbench-only")
    return 0


def resolve_source_for_placement(state: dict[str, Any], raw: Any) -> dict[str, Any]:
    value = clean_text(raw, 2_048)
    if not value:
        raise ProgRSSError("source id, exact title, or URL is required")
    folded = value.casefold()
    sources = [row for row in state.get("sources", []) if isinstance(row, dict) and not row.get("archivedAt")]
    exact = [row for row in sources if clean_text(row.get("id"), 300).casefold() == folded]
    if not exact:
        try:
            requested_url = safe_http_url(value)
        except ProgRSSError:
            requested_url = ""
        if requested_url:
            exact = [row for row in sources if requested_url in source_address_aliases(row)]
    if not exact:
        exact = [row for row in sources if clean_text(row.get("title"), 180).casefold() == folded]
    if len(exact) > 1:
        choices = ", ".join(clean_text(row.get("id"), 300) for row in exact[:8])
        raise ProgRSSError(f"source title is ambiguous; use an id or URL: {choices}")
    if not exact:
        raise ProgRSSError(f"source not found: {value}")
    return exact[0]


def resolve_source_for_storage(state: dict[str, Any], raw: Any) -> dict[str, Any]:
    """Resolve an RSS source for local text policy, including archived sources.

    The Extension intentionally keeps archived sources out of its everyday list.
    The CLI can still audit or trim their retained text from an explicit backup.
    """
    value = clean_text(raw, 2_048)
    if not value:
        raise ProgRSSError("source id, exact title, or URL is required")
    folded = value.casefold()
    sources = [row for row in state.get("sources", []) if isinstance(row, dict)]
    exact = [row for row in sources if clean_text(row.get("id"), 300).casefold() == folded]
    if not exact:
        try:
            requested_url = safe_http_url(value)
        except ProgRSSError:
            requested_url = ""
        if requested_url:
            exact = [row for row in sources if requested_url in source_address_aliases(row)]
    if not exact:
        exact = [row for row in sources if clean_text(row.get("title"), 180).casefold() == folded]
    if len(exact) > 1:
        choices = ", ".join(clean_text(row.get("id"), 300) for row in exact[:8])
        raise ProgRSSError(f"source title is ambiguous; use an id or URL: {choices}")
    if not exact:
        raise ProgRSSError(f"source not found: {value}")
    return exact[0]


def byte_count(value: Any) -> int:
    return len(str(value if value is not None else "").encode("utf-8"))


def human_bytes(value: Any) -> str:
    size = max(0, int(value or 0))
    if size < 1_000:
        return f"{size} B"
    if size < 1_000_000:
        digits = 1 if size < 10_000 else 0
        return f"{size / 1_000:.{digits}f} KB"
    digits = 1 if size < 10_000_000 else 0
    return f"{size / 1_000_000:.{digits}f} MB"


def workspace_text_storage_report(state: dict[str, Any]) -> dict[str, Any]:
    sources = [row for row in state.get("sources", []) if isinstance(row, dict)]
    items = [row for row in state.get("items", []) if isinstance(row, dict)]
    items_by_source: dict[str, list[dict[str, Any]]] = {}
    for item in items:
        source_id = clean_text(item.get("sourceId"), 300)
        if source_id:
            items_by_source.setdefault(source_id, []).append(item)

    rows: list[dict[str, Any]] = []
    known_ids: set[str] = set()
    totals = {
        "fullTextItems": 0,
        "fullTextBytes": 0,
        "summaryBodyItems": 0,
        "policyOmittedItems": 0,
        "cleanupEligibleItems": 0,
        "cleanupEligibleBytes": 0,
    }
    for source in sources:
        source_id = clean_text(source.get("id"), 300)
        if not source_id or source.get("type") != "rss":
            continue
        known_ids.add(source_id)
        source_items = items_by_source.get(source_id, [])
        full_items = [item for item in source_items if item.get("body") and not item.get("bodyIsSummary")]
        cleanup = [item for item in full_items if item.get("readAt") and not item.get("starred")]
        row = {
            "id": source_id,
            "title": clean_text(source.get("title"), 180) or "Untitled source",
            "url": clean_text(source.get("url"), 2_048),
            "archived": bool(source.get("archivedAt")),
            "enabled": bool(source.get("enabled")),
            "mode": "summary" if source.get("textRetention") == "summary" else "full",
            "fullTextItems": len(full_items),
            "fullTextBytes": sum(byte_count(item.get("body")) for item in full_items),
            "summaryBodyItems": sum(1 for item in source_items if item.get("bodyIsSummary")),
            "policyOmittedItems": sum(1 for item in source_items if item.get("bodyOmitted")),
            "cleanupEligibleItems": len(cleanup),
            "cleanupEligibleBytes": sum(byte_count(item.get("body")) for item in cleanup),
        }
        rows.append(row)
        for key in totals:
            totals[key] += int(row[key])

    orphaned = [
        item for source_id, group in items_by_source.items() if source_id not in known_ids
        for item in group if item.get("body") and not item.get("bodyIsSummary")
    ]
    rows.sort(key=lambda row: (-row["fullTextBytes"], row["title"].casefold(), row["id"]))
    return {
        "schema": "progrss.workspace.text-storage.v1",
        **totals,
        "orphanedFullTextItems": len(orphaned),
        "orphanedFullTextBytes": sum(byte_count(item.get("body")) for item in orphaned),
        "sources": rows,
        "network": False,
        "writes": False,
        "browserProfileRead": False,
        "measurement": "UTF-8 bytes in retained full feed-text strings; excludes titles, summaries, indexes, and browser overhead",
    }


def cmd_workspace_text_storage(args: argparse.Namespace) -> int:
    _wrapper, state = load_backup(Path(args.backup))
    report = workspace_text_storage_report(state)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    print(
        f"{human_bytes(report['fullTextBytes'])} of full feed text across "
        f"{report['fullTextItems']} update{'s' if report['fullTextItems'] != 1 else ''} · offline · no writes"
    )
    print(
        f"{report['policyOmittedItems']} intentionally summary-only update{'s' if report['policyOmittedItems'] != 1 else ''} · "
        f"{human_bytes(report['cleanupEligibleBytes'])} in {report['cleanupEligibleItems']} read, unsaved "
        f"update{'s' if report['cleanupEligibleItems'] != 1 else ''} can be trimmed"
    )
    for row in report["sources"]:
        if not (row["fullTextItems"] or row["policyOmittedItems"] or row["mode"] == "summary"):
            continue
        state_label = "archived" if row["archived"] else ("active" if row["enabled"] else "paused")
        print(
            f"- {row['title']} [{row['id']}] — {row['mode']} · {state_label} · "
            f"{human_bytes(row['fullTextBytes'])} full text / {row['fullTextItems']} updates · "
            f"{human_bytes(row['cleanupEligibleBytes'])} trim eligible"
        )
    if report["orphanedFullTextItems"]:
        print(
            f"{report['orphanedFullTextItems']} orphaned update{'s' if report['orphanedFullTextItems'] != 1 else ''} "
            f"retain {human_bytes(report['orphanedFullTextBytes'])}; no source policy can be applied to them."
        )
    print("Measurement covers retained full-text strings only, not total backup or browser storage.")
    return 0


def cmd_workspace_set_text_retention(args: argparse.Namespace) -> int:
    wrapper, state = load_backup(Path(args.backup))
    source = resolve_source_for_storage(state, args.source)
    if source.get("type") != "rss":
        raise ProgRSSError("offline text choices apply to feeds, not page watches")
    mode = clean_text(args.mode, 20).lower()
    if mode not in {"full", "summary"}:
        raise ProgRSSError("choose full or summary")
    if args.trim_read and mode != "summary":
        raise ProgRSSError("--trim-read requires summary mode; no output was written")

    result = copy.deepcopy(wrapper)
    result_state = copy.deepcopy(state)
    source_id = clean_text(source.get("id"), 300)
    target = next(
        (row for row in result_state.get("sources", []) if isinstance(row, dict) and clean_text(row.get("id"), 300) == source_id),
        None,
    )
    if target is None:
        raise ProgRSSError("source changed while preparing the new backup")
    if mode == "summary":
        target["textRetention"] = "summary"
    else:
        target.pop("textRetention", None)

    trimmed = 0
    trimmed_bytes = 0
    preserved = 0
    if args.trim_read:
        for item in result_state.get("items", []):
            if not isinstance(item, dict) or clean_text(item.get("sourceId"), 300) != source_id:
                continue
            if not item.get("body") or item.get("bodyIsSummary"):
                continue
            if not item.get("readAt") or item.get("starred"):
                preserved += 1
                continue
            trimmed += 1
            trimmed_bytes += byte_count(item.get("body"))
            item["body"] = clean_text(item.get("summary"), 1_200)
            item["bodyIsSummary"] = True
            item["bodyOmitted"] = True
            body_language = language_tag(item.get("summaryLanguage") or item.get("language") or target.get("language"))
            if body_language:
                item["bodyLanguage"] = body_language
            else:
                item.pop("bodyLanguage", None)

    result["schema"] = BACKUP_SCHEMA
    result["exportedAt"] = utc_now()
    result["state"] = portable_state(result_state)
    write_new(Path(args.output), json_bytes(result))
    title = clean_text(target.get("title"), 180) or source_id
    if mode == "summary":
        detail = "future ingestion keeps summaries only"
        if args.trim_read:
            detail += f" · trimmed {trimmed} read, unsaved update{'s' if trimmed != 1 else ''} ({human_bytes(trimmed_bytes)})"
            if preserved:
                detail += f" · kept {preserved} unread or saved full-text update{'s' if preserved != 1 else ''}"
    else:
        detail = "future ingestion keeps full text supplied by the feed"
    print(f"Updated {title}: {detail} · offline · new-file-only")
    print(f"Wrote {args.output}; the input backup remains the rollback copy.")
    return 0


def resolve_simple_folder_for_placement(state: dict[str, Any], raw: Any) -> dict[str, Any]:
    value = clean_text(raw, 300)
    if not value or value.casefold() in {"all", "unfiled"}:
        raise ProgRSSError("choose an existing named simple folder")
    model = simple_folder_model(state)
    folded = value.casefold()
    exact = [row for row in model["rows"] if row["id"].casefold() == folded or row["path"].casefold() == folded]
    if not exact:
        exact = [row for row in model["rows"] if row["title"].casefold() == folded]
    if len(exact) > 1:
        options = ", ".join(row["path"] for row in exact[:8])
        raise ProgRSSError(f"folder name is ambiguous; use an id or full path: {options}")
    if not exact:
        raise ProgRSSError(f"simple folder not found: {value}")
    return exact[0]


def cmd_workspace_place_source(args: argparse.Namespace) -> int:
    wrapper, state = load_backup(Path(args.backup))
    source = resolve_source_for_placement(state, args.source)
    folder = resolve_simple_folder_for_placement(state, args.folder)
    source_id = clean_text(source.get("id"), 300)
    if source_id in folder["directSourceIds"]:
        raise ProgRSSError(f"source is already directly in {folder['path']}; no output was written")
    if source_id in folder["sourceIds"]:
        raise ProgRSSError(f"source already appears in {folder['path']} through a nested folder; no output was written")

    result = copy.deepcopy(wrapper)
    result_state = copy.deepcopy(state)
    target = next((row for row in result_state["collections"] if isinstance(row, dict) and clean_text(row.get("id"), 300) == folder["id"]), None)
    if target is None or not isinstance(target.get("members", []), list):
        raise ProgRSSError("folder changed while preparing the new backup")
    if len(target["members"]) >= 150:
        raise ProgRSSError("folder already contains the maximum of 150 direct entries")
    target["members"].append({"kind": "source", "id": source_id})
    target["version"] = min(10_000, max(1, int(target.get("version") or 1)) + 1)

    after = simple_folder_model(result_state)
    inherited = [row["path"] for row in after["rows"] if source_id in row["sourceIds"] and source_id not in row["directSourceIds"]]
    result["schema"] = BACKUP_SCHEMA
    result["exportedAt"] = utc_now()
    result["state"] = portable_state(result_state)
    write_new(Path(args.output), json_bytes(result))
    title = clean_text(source.get("title"), 180) or source_id
    suffix = f" · also appears in {', '.join(inherited)}" if inherited else ""
    print(f"Placed {title} in {folder['path']}{suffix} · offline · new-file-only")
    return 0


def cmd_workspace_remove_from_folder(args: argparse.Namespace) -> int:
    wrapper, state = load_backup(Path(args.backup))
    source = resolve_source_for_placement(state, args.source)
    folder = resolve_simple_folder_for_placement(state, args.folder)
    source_id = clean_text(source.get("id"), 300)
    if source_id not in folder["directSourceIds"]:
        if source_id in folder["sourceIds"]:
            raise ProgRSSError(
                f"source appears in {folder['path']} only through a nested folder; "
                "remove its direct placement from that nested folder instead"
            )
        raise ProgRSSError(f"source is not directly in {folder['path']}; no output was written")

    result = copy.deepcopy(wrapper)
    result_state = copy.deepcopy(state)
    target = next(
        (
            row for row in result_state["collections"]
            if isinstance(row, dict) and clean_text(row.get("id"), 300) == folder["id"]
        ),
        None,
    )
    if target is None or not isinstance(target.get("members", []), list):
        raise ProgRSSError("folder changed while preparing the new backup")
    before = len(target["members"])
    target["members"] = [
        member for member in target["members"]
        if not (
            isinstance(member, dict)
            and member.get("kind") == "source"
            and clean_text(member.get("id"), 300) == source_id
        )
    ]
    if len(target["members"]) == before:
        raise ProgRSSError("direct folder placement was not found; no output was written")
    target["version"] = min(10_000, max(1, int(target.get("version") or 1)) + 1)

    after = simple_folder_model(result_state)
    inherited = [
        row["path"] for row in after["rows"]
        if source_id in row["sourceIds"] and source_id not in row["directSourceIds"]
    ]
    result["schema"] = BACKUP_SCHEMA
    result["exportedAt"] = utc_now()
    result["state"] = portable_state(result_state)
    write_new(Path(args.output), json_bytes(result))
    title = clean_text(source.get("title"), 180) or source_id
    suffix = f" · still appears in {', '.join(inherited)}" if inherited else ""
    print(f"Removed {title} from {folder['path']}{suffix} · offline · new-file-only")
    return 0



def cmd_workspace_source_note(args: argparse.Namespace) -> int:
    wrapper, state = load_backup(Path(args.backup))
    source = resolve_source_for_placement(state, args.source)
    folder = resolve_simple_folder_for_placement(state, args.folder)
    source_id = clean_text(source.get("id"), 300)
    folder_collection = next(
        (
            row for row in state.get("collections", [])
            if isinstance(row, dict) and clean_text(row.get("id"), 300) == folder["id"]
        ),
        None,
    )
    if folder_collection is None or not isinstance(folder_collection.get("members"), list):
        raise ProgRSSError("folder changed while preparing the new backup")
    placements = [
        member for member in folder_collection["members"]
        if isinstance(member, dict)
        and member.get("kind") == "source"
        and clean_text(member.get("id"), 300) == source_id
    ]
    if len(placements) != 1:
        if not placements and source_id in folder["sourceIds"]:
            raise ProgRSSError(
                f"source appears in {folder['path']} only through a nested folder; "
                "add the reason to its direct placement instead"
            )
        if not placements:
            raise ProgRSSError(f"source is not directly in {folder['path']}; no output was written")
        raise ProgRSSError(f"source has an ambiguous direct placement in {folder['path']}; no output was written")
    try:
        current = normalize_source_note_reason(placements[0].get("reason")) if "reason" in placements[0] else None
        next_reason = None if args.clear else normalize_source_note_reason(args.reason)
    except SourceNoteError as exc:
        raise ProgRSSError(str(exc)) from exc
    if current == next_reason:
        raise ProgRSSError("that placement reason is already unchanged; no output was written")

    result = copy.deepcopy(wrapper)
    result_state = copy.deepcopy(state)
    target = next(
        (
            row for row in result_state["collections"]
            if isinstance(row, dict) and clean_text(row.get("id"), 300) == folder["id"]
        ),
        None,
    )
    if target is None or not isinstance(target.get("members"), list):
        raise ProgRSSError("folder changed while preparing the new backup")
    target_placements = [
        member for member in target["members"]
        if isinstance(member, dict)
        and member.get("kind") == "source"
        and clean_text(member.get("id"), 300) == source_id
    ]
    if len(target_placements) != 1:
        raise ProgRSSError("direct placement changed while preparing the new backup")
    if next_reason is None:
        target_placements[0].pop("reason", None)
    else:
        target_placements[0]["reason"] = next_reason
    target["version"] = min(10_000, max(1, int(target.get("version") or 1)) + 1)

    result["schema"] = BACKUP_SCHEMA
    result["exportedAt"] = utc_now()
    result["state"] = portable_state(result_state)
    write_new(Path(args.output), json_bytes(result))
    title = clean_text(source.get("title"), 180) or source_id
    action = "Cleared" if next_reason is None else ("Added" if current is None else "Updated")
    print(f"{action} the reason for {title} in {folder['path']} · local only · offline · new-file-only")
    print("Nothing was published, contacted, scheduled, or presented as a ProgRSS safety claim.")
    print(f"Wrote {args.output}; the input backup remains the rollback copy.")
    return 0


def repair_iso(value: Any) -> str:
    return best_date(value)


def repair_timestamp(value: Any) -> float:
    normalized = repair_iso(value)
    if not normalized:
        return 0.0
    try:
        return dt.datetime.fromisoformat(normalized.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return 0.0


def source_repair_pair(state: dict[str, Any], first: dict[str, Any], second: dict[str, Any]) -> list[str]:
    if first is second or clean_text(first.get("id"), 300) == clean_text(second.get("id"), 300):
        raise ProgRSSError("choose two different sources")
    if first.get("type") != "rss" or second.get("type") != "rss":
        raise ProgRSSError("same-source repair is limited to feeds; page watches keep separate histories")
    if first.get("archivedAt") or second.get("archivedAt"):
        raise ProgRSSError("restore archived sources before combining their histories")
    shared = sorted(source_address_aliases(first) & source_address_aliases(second))
    if not shared:
        raise ProgRSSError("these sources do not share a reviewed address; no output was written")
    return shared


def advanced_reference_reason(key: str) -> str:
    if key in {"fixtures", "snapshots"}:
        return "This material preserves exact before-and-after evidence. Rewriting an identity could change what the evidence proves."
    if key in ADVANCED_EVIDENCE_KEYS:
        return "This record describes past evidence or a completed operation. Rewriting it would make the record describe something that did not happen."
    if key in ADVANCED_TRUST_KEYS:
        return "This record binds trust to an exact local identity. ProgRSS cannot transfer that trust to another history automatically."
    if key in ADVANCED_EXCHANGE_KEYS:
        return "This record may contain a proposal, subscription, or request. ProgRSS cannot decide whether its reference should be retargeted or discarded."
    return "ProgRSS has no meaning-preserving rewrite rule for this record type."


def advanced_record_descriptor(record: Any, key: str, index: int) -> dict[str, Any]:
    row = record if isinstance(record, dict) else {}
    id_keys = ("id", "receiptId", "publicationId", "pinId", "requestId", "sightingId", "forkId", "packId", "policyId", "claimId", "keyId", "digest", "hash", "fingerprint")
    title_keys = ("title", "name", "label", "subject", "note", "summary")
    record_id = next((clean_text(row.get(name), 220) for name in id_keys if clean_text(row.get(name), 220)), f"{key}:{index + 1}")
    schema = clean_text(row.get("schema"), 180)
    title = next((clean_text(row.get(name), 180) for name in title_keys if clean_text(row.get(name), 180)), "")
    if not title:
        title = schema or f"{ADVANCED_REFERENCE_LABELS.get(key, 'Advanced record')} {index + 1}"
    return {"index": index, "recordId": record_id, "title": title, "schema": schema}


def exact_string_reference_details(
    value: Any,
    targets: dict[str, dict[str, str]],
    budget: dict[str, Any],
    path: str = "$",
    result: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if result is None:
        result = {"count": 0, "sourceCount": 0, "updateCount": 0, "hits": []}
    budget["nodes"] += 1
    if budget["nodes"] > 25_000:
        budget["exceeded"] = True
        return result
    if isinstance(value, str):
        target = targets.get(value)
        if target is None:
            return result
        result["count"] += 1
        if target["kind"] == "source":
            result["sourceCount"] += 1
        elif target["kind"] == "update":
            result["updateCount"] += 1
        if len(result["hits"]) < MAX_REFERENCE_HITS_PER_RECORD:
            result["hits"].append({**target, "path": path})
        return result
    if isinstance(value, list):
        for index, row in enumerate(value):
            if budget["exceeded"]:
                break
            exact_string_reference_details(row, targets, budget, f"{path}[{index}]", result)
    elif isinstance(value, dict):
        for key, row in value.items():
            if budget["exceeded"]:
                break
            child = f"{path}[{json.dumps(str(key), ensure_ascii=True)}]"
            exact_string_reference_details(row, targets, budget, child, result)
    return result


def summarized_reference_targets(hits: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, dict[str, Any]] = {}
    for hit in hits:
        target_id = hit["targetId"]
        if target_id not in grouped:
            grouped[target_id] = {
                "kind": hit["kind"], "targetId": target_id, "sourceId": hit["sourceId"],
                "sourceTitle": hit["sourceTitle"], "label": hit["label"],
                "referenceCount": 0, "paths": [],
            }
        row = grouped[target_id]
        row["referenceCount"] += 1
        if len(row["paths"]) < 6 and hit["path"] not in row["paths"]:
            row["paths"].append(hit["path"])
    return list(grouped.values())


def source_reference_report(
    state: dict[str, Any], first: dict[str, Any], second: dict[str, Any]
) -> dict[str, Any]:
    pair_sources = (first, second)
    source_titles = {
        clean_text(source.get("id"), 300): clean_text(source.get("title"), 180) or "Untitled source"
        for source in pair_sources
    }
    targets: dict[str, dict[str, str]] = {}
    for source in pair_sources:
        source_id = clean_text(source.get("id"), 300)
        targets[source_id] = {
            "kind": "source", "targetId": source_id, "sourceId": source_id,
            "sourceTitle": source_titles[source_id], "label": "Source history",
        }
    affected_ids = set(source_titles)
    for item in state.get("items", []):
        if not isinstance(item, dict):
            continue
        source_id = clean_text(item.get("sourceId"), 300)
        target_id = clean_text(item.get("id"), 700)
        if source_id not in affected_ids or not target_id:
            continue
        targets[target_id] = {
            "kind": "update", "targetId": target_id, "sourceId": source_id,
            "sourceTitle": source_titles.get(source_id, "Source history"),
            "label": clean_text(item.get("title"), 180) or "Retained update",
        }

    groups: list[dict[str, Any]] = []
    blocking_records = 0
    exact_references = 0
    source_references = 0
    update_references = 0
    scan_exceeded = False
    for key in ADVANCED_STATE_KEYS:
        rows = state.get(key) if isinstance(state.get(key), list) else []
        budget = {"nodes": 0, "exceeded": False}
        records: list[dict[str, Any]] = []
        group_references = 0
        for index, record in enumerate(rows):
            if budget["exceeded"]:
                break
            result = exact_string_reference_details(record, targets, budget)
            if not result["count"]:
                continue
            descriptor = advanced_record_descriptor(record, key, index)
            references = summarized_reference_targets(result["hits"])
            captured = sum(row["referenceCount"] for row in references)
            records.append({
                **descriptor,
                "referenceCount": result["count"],
                "sourceReferenceCount": result["sourceCount"],
                "updateReferenceCount": result["updateCount"],
                "references": references,
                "pathsTruncated": result["count"] > captured,
                "retirement": ({
                    "eligible": True,
                    "action": "retire-graft-receipt",
                    "label": "Review retirement",
                    "explanation": "ProgRSS can preserve this exact graft receipt in a retired-evidence archive without changing what it recorded.",
                } if key == "receipts" and descriptor["schema"] == GRAFT_RECEIPT_SCHEMA else None),
            })
            group_references += result["count"]
            source_references += result["sourceCount"]
            update_references += result["updateCount"]
        if not records and not budget["exceeded"]:
            continue
        blocking_records += len(records)
        exact_references += group_references
        scan_exceeded = scan_exceeded or bool(budget["exceeded"])
        groups.append({
            "key": key,
            "label": ADVANCED_REFERENCE_LABELS.get(key, key),
            "reason": advanced_reference_reason(key),
            "recordCount": len(records),
            "referenceCount": group_references,
            "scanExceeded": bool(budget["exceeded"]),
            "records": records,
        })

    snapshots = state.get("snapshots") if isinstance(state.get("snapshots"), dict) else {}
    snapshot_records: list[dict[str, Any]] = []
    for source in pair_sources:
        source_id = clean_text(source.get("id"), 300)
        if source_id not in snapshots:
            continue
        snapshot_records.append({
            "index": 0, "recordId": source_id, "title": f"{source_titles[source_id]} snapshot", "schema": "",
            "referenceCount": 1, "sourceReferenceCount": 1, "updateReferenceCount": 0,
            "references": [{
                "kind": "source", "targetId": source_id, "sourceId": source_id,
                "sourceTitle": source_titles[source_id], "label": "Source history",
                "referenceCount": 1, "paths": [f"$[{json.dumps(source_id)}]"],
            }],
            "pathsTruncated": False,
        })
    if snapshot_records:
        blocking_records += len(snapshot_records)
        exact_references += len(snapshot_records)
        source_references += len(snapshot_records)
        groups.append({
            "key": "snapshots", "label": ADVANCED_REFERENCE_LABELS["snapshots"],
            "reason": advanced_reference_reason("snapshots"), "recordCount": len(snapshot_records),
            "referenceCount": len(snapshot_records), "scanExceeded": False, "records": snapshot_records,
        })

    retired_evidence: list[dict[str, Any]] = []
    retired_references = 0
    for index, envelope in enumerate(state.get("retiredReceipts", [])):
        if not isinstance(envelope, dict) or envelope.get("schema") != RETIRED_GRAFT_RECEIPT_SCHEMA:
            continue
        original = envelope.get("originalReceipt")
        if not isinstance(original, dict):
            continue
        budget = {"nodes": 0, "exceeded": False}
        result = exact_string_reference_details(original, targets, budget)
        if not result["count"]:
            continue
        retired_references += result["count"]
        retired_evidence.append({
            "index": index,
            "retirementId": clean_text(envelope.get("id"), 220),
            "retiredAt": repair_iso(envelope.get("retiredAt")),
            "originalDigest": clean_text(envelope.get("originalDigest"), 64),
            "originalRecordId": clean_text(envelope.get("originalRecordId"), 220),
            "originalTitle": clean_text(envelope.get("originalTitle"), 180) or GRAFT_RECEIPT_SCHEMA,
            "referenceCount": result["count"],
            "references": summarized_reference_targets(result["hits"]),
            "pathsTruncated": result["count"] > len(result["hits"]),
            "scanExceeded": bool(budget["exceeded"]),
        })

    return {
        "schema": "progrss.source-reference-report.v1",
        "reviewedRevision": state.get("_revision") if isinstance(state.get("_revision"), int) else None,
        "sources": [{
            "id": clean_text(source.get("id"), 300),
            "title": clean_text(source.get("title"), 180) or "Untitled source",
            "url": clean_text(source.get("url"), 2_048),
        } for source in pair_sources],
        "summary": {
            "blockingGroups": len(groups), "blockingRecords": blocking_records,
            "exactReferences": exact_references, "sourceHistoryReferences": source_references,
            "retainedUpdateReferences": update_references,
            "retiredRecords": len(retired_evidence), "retiredReferences": retired_references,
            "scanExceeded": scan_exceeded,
        },
        "groups": groups,
        "retiredEvidence": retired_evidence,
        "network": False, "writes": False, "browserProfileRead": False,
        "note": "This report does not rewrite or transfer trust. An eligible graft receipt may be moved intact into retired evidence only by an explicit new-file transaction.",
    }


def source_repair_placement_plan(
    state: dict[str, Any], first_id: str, second_id: str
) -> dict[str, Any]:
    source_ids = (clean_text(first_id, 300), clean_text(second_id, 300))
    source_id_set = set(source_ids)
    try:
        path_by_id = {row["id"]: row["path"] for row in simple_folder_model(state)["rows"]}
    except (KeyError, ProgRSSError, TypeError, ValueError):
        path_by_id = {}
    collections: list[dict[str, Any]] = []
    conflicts: list[dict[str, Any]] = []
    for collection in state.get("collections", []):
        if not isinstance(collection, dict) or not isinstance(collection.get("members"), list):
            continue
        placements = [
            (index, member)
            for index, member in enumerate(collection["members"])
            if isinstance(member, dict)
            and member.get("kind") == "source"
            and clean_text(member.get("id"), 300) in source_id_set
        ]
        if not placements:
            continue
        folder_id = clean_text(collection.get("id"), 300)
        folder_title = clean_text(collection.get("title"), 180) or "Untitled folder"
        folder_path = path_by_id.get(folder_id) or folder_title or folder_id
        normalized: list[dict[str, Any]] = []
        invalid = False
        for index, member in placements:
            try:
                reason = normalize_source_note_reason(member.get("reason")) if "reason" in member else None
            except SourceNoteError as error:
                conflicts.append({
                    "kind": "invalid-reason",
                    "folderId": folder_id,
                    "folderTitle": folder_title,
                    "folderPath": folder_path,
                    "sourceId": clean_text(member.get("id"), 300),
                    "message": clean_text(str(error), 300) or "the placement reason is invalid",
                })
                invalid = True
                continue
            normalized.append({
                "sourceId": clean_text(member.get("id"), 300),
                "index": index,
                "reason": reason,
            })
        if invalid:
            continue
        reasons = list(dict.fromkeys(row["reason"] for row in normalized if row["reason"] is not None))
        if len(reasons) > 1:
            first = next((row for row in normalized if row["sourceId"] == source_ids[0]), None)
            second = next((row for row in normalized if row["sourceId"] == source_ids[1]), None)
            conflicts.append({
                "kind": "divergent-reasons",
                "folderId": folder_id,
                "folderTitle": folder_title,
                "folderPath": folder_path,
                "firstSourceId": source_ids[0],
                "secondSourceId": source_ids[1],
                "firstReason": first["reason"] if first else None,
                "secondReason": second["reason"] if second else None,
            })
            continue
        collections.append({
            "folderId": folder_id,
            "firstIndex": placements[0][0],
            "placementCount": len(placements),
            "mergedReason": reasons[0] if reasons else None,
        })
    return {"collections": collections, "conflicts": conflicts}


def source_repair_reason_conflict_message(conflicts: list[dict[str, Any]]) -> str:
    count = len(conflicts)
    paths = [
        clean_text(row.get("folderPath") or row.get("folderTitle") or row.get("folderId"), 300)
        for row in conflicts[:3]
    ]
    paths = [value for value in paths if value]
    where = f" in {', '.join(paths)}{', and more' if count > len(paths) else ''}" if paths else ""
    noun = "placement" if count == 1 else "placements"
    verb = "has" if count == 1 else "have"
    return (
        f"{count} direct folder {noun}{where} {verb} incompatible Source Notes; "
        "edit or clear one reason before combining these histories because ProgRSS will not choose a reason automatically"
    )


def source_repair_blockers(
    state: dict[str, Any], first: dict[str, Any], second: dict[str, Any]
) -> dict[str, Any]:
    report = source_reference_report(state, first, second)
    placement_plan = source_repair_placement_plan(
        state, clean_text(first.get("id"), 300), clean_text(second.get("id"), 300)
    )
    references = [
        {"kind": group["key"], "count": group["referenceCount"]}
        for group in report["groups"]
        if group["key"] in ADVANCED_STATE_LIMITS and group["referenceCount"]
    ]
    blockers: list[str] = []
    if placement_plan["conflicts"]:
        blockers.append(source_repair_reason_conflict_message(placement_plan["conflicts"]))
    if references:
        blockers.append(
            "Advanced Workbench records refer to one of these source histories; "
            "inspect them with workspace source-references before combining the sources"
        )
    if report["summary"]["scanExceeded"]:
        blockers.append("some Advanced Workbench records are too large to audit safely")
    if any(group["key"] == "snapshots" for group in report["groups"]):
        blockers.append("a page-watch snapshot is attached to one of these feed identities")
    return {
        "blockers": blockers,
        "placementConflicts": placement_plan["conflicts"],
        "placementPlan": placement_plan,
        "advancedReferences": references,
        "scanExceeded": report["summary"]["scanExceeded"],
        "referenceReport": report,
    }


def source_repair_item_stats(state: dict[str, Any], source_id: str) -> dict[str, Any]:
    rows = [
        item for item in state.get("items", [])
        if isinstance(item, dict) and clean_text(item.get("sourceId"), 300) == source_id
    ]
    newest = max(
        (repair_iso(item.get("observedAt") or item.get("published")) for item in rows),
        default="",
    )
    return {
        "items": len(rows),
        "unread": sum(1 for item in rows if not item.get("readAt")),
        "saved": sum(1 for item in rows if item.get("starred")),
        "newestAt": newest,
    }


def source_repair_membership(state: dict[str, Any], source_id: str) -> dict[str, list[dict[str, str]]]:
    model = simple_folder_model(state)
    direct = [
        {"id": row["id"], "path": row["path"]}
        for row in model["rows"] if source_id in row["directSourceIds"]
    ]
    inherited = [
        {"id": row["id"], "path": row["path"]}
        for row in model["rows"] if source_id in row["sourceIds"] and source_id not in row["directSourceIds"]
    ]
    return {"direct": direct, "inherited": inherited}


def source_repair_status(source: dict[str, Any]) -> str:
    if source.get("pendingRedirect"):
        return "moved"
    if not source.get("enabled"):
        return "paused"
    if source.get("permissionMissing"):
        return "reconnect"
    if source.get("lastError"):
        return "needs-attention"
    return "following"


def source_repair_summary(state: dict[str, Any], source: dict[str, Any]) -> dict[str, Any]:
    source_id = clean_text(source.get("id"), 300)
    cache = source.get("httpCache") if isinstance(source.get("httpCache"), dict) else {}
    pulse = source.get("pulse") if isinstance(source.get("pulse"), dict) else {}
    return {
        "id": source_id,
        "title": clean_text(source.get("title"), 180) or "Untitled source",
        "url": clean_text(source.get("url"), 2_048),
        "status": source_repair_status(source),
        "items": source_repair_item_stats(state, source_id),
        "folders": source_repair_membership(state, source_id),
        "activity": {
            "successfulAt": repair_iso(source.get("lastSuccessfulAt")),
            "newAt": repair_iso(source.get("lastNewAt")),
            "problemAt": repair_iso(source.get("lastProblemAt") or (source.get("lastScan") if source.get("lastError") else "")),
            "problem": clean_text(source.get("lastProblem") or source.get("lastError"), 500),
        },
        "nextAt": repair_iso(pulse.get("nextAt")),
        "validators": {
            "etag": bool(cache.get("etag")),
            "lastModified": bool(cache.get("lastModified")),
        },
        "browserSiteAccess": "unknown-without-browser-profile",
        "aliasCount": len(source_address_aliases(source)),
    }


def source_repair_tail(item: dict[str, Any], source_ids: tuple[str, str]) -> str:
    had_entry_key = isinstance(item.get("entryKey"), str) and bool(item.get("entryKey"))
    value = clean_text(item.get("entryKey") or item.get("id"), 700)
    for source_id in source_ids:
        prefix = f"{source_id}|"
        if value.startswith(prefix):
            value = value[len(prefix):]
            break
    if not had_entry_key and isinstance(item.get("feedRevision"), (int, float)):
        value = re.sub(r"\|edit:\d+$", "", value)
    return value[:500] or f"legacy:{clean_text(item.get('id'), 300)}"


def source_repair_fingerprint(item: dict[str, Any]) -> tuple[str, str, str, str, str, bool, bool]:
    return (
        clean_text(item.get("title"), 240),
        clean_text(item.get("summary"), 1_200),
        body_text(item.get("body") or item.get("summary"), MAX_ITEM_BODY_CHARS),
        clean_text(item.get("url"), 2_048),
        repair_iso(item.get("published")),
        bool(item.get("bodyIsSummary")) or not bool(item.get("body")),
        bool(item.get("bodyOmitted")),
    )


def merge_source_items(state: dict[str, Any], survivor_id: str, other_id: str) -> dict[str, Any]:
    source_ids = (survivor_id, other_id)
    affected: list[dict[str, Any]] = []
    untouched: list[dict[str, Any]] = []
    for item in state.get("items", []):
        if not isinstance(item, dict):
            continue
        (affected if clean_text(item.get("sourceId"), 300) in source_ids else untouched).append(item)
    groups: dict[str, list[dict[str, Any]]] = {}
    for item in affected:
        groups.setdefault(source_repair_tail(item, source_ids), []).append(item)
    merged: list[dict[str, Any]] = []
    collapsed = 0
    for tail, rows in groups.items():
        by_content: dict[tuple[str, str, str, str], list[dict[str, Any]]] = {}
        for row in rows:
            by_content.setdefault(source_repair_fingerprint(row), []).append(row)
        collapsed += len(rows) - len(by_content)
        events: list[dict[str, Any]] = []
        for matches in by_content.values():
            ordered = sorted(
                matches,
                key=lambda row: (repair_timestamp(row.get("observedAt") or row.get("published")), clean_text(row.get("id"), 700)),
            )
            preferred = copy.deepcopy(ordered[-1])
            observed = sorted(
                value for value in (repair_iso(row.get("observedAt") or row.get("published")) for row in matches) if value
            )
            if observed:
                preferred["observedAt"] = observed[0]
            if any(not row.get("readAt") for row in matches):
                preferred["readAt"] = ""
            else:
                read_dates = sorted(value for value in (repair_iso(row.get("readAt")) for row in matches) if value)
                preferred["readAt"] = read_dates[0] if read_dates else ""
            preferred["starred"] = any(bool(row.get("starred")) for row in matches)
            events.append(preferred)
        events.sort(
            key=lambda row: (
                repair_timestamp(row.get("observedAt") or row.get("published")),
                int(row.get("feedRevision") or 0),
                clean_text(row.get("id"), 700),
            )
        )
        entry_key = f"{survivor_id}|{tail}"
        for index, event in enumerate(events):
            row = copy.deepcopy(event)
            row["sourceId"] = survivor_id
            row["entryKey"] = entry_key
            row["feedRevision"] = index
            row["id"] = f"{entry_key}|edit:{index}" if index else entry_key
            row["kind"] = "changed" if index else "new"
            merged.append(row)
    items = sorted(
        [*untouched, *merged],
        key=lambda row: (repair_timestamp(row.get("observedAt") or row.get("published")), clean_text(row.get("id"), 700)),
        reverse=True,
    )[:MAX_ITEMS]
    survivor_items = [row for row in items if clean_text(row.get("sourceId"), 300) == survivor_id]
    return {
        "items": items,
        "beforeCount": len(affected),
        "afterCount": len(survivor_items),
        "exactRepeatsCollapsed": collapsed,
        "identityCount": len(groups),
        "unread": sum(1 for row in survivor_items if not row.get("readAt")),
        "saved": sum(1 for row in survivor_items if row.get("starred")),
    }


def remap_collection_source(
    state: dict[str, Any], other_id: str, survivor_id: str,
    placement_plan: dict[str, Any] | None = None,
) -> int:
    placement_plan = placement_plan or source_repair_placement_plan(state, survivor_id, other_id)
    if placement_plan["conflicts"]:
        raise ProgRSSError(source_repair_reason_conflict_message(placement_plan["conflicts"]))
    plan_by_folder = {row["folderId"]: row for row in placement_plan["collections"]}
    changed_count = 0
    for collection in state.get("collections", []):
        if not isinstance(collection, dict) or not isinstance(collection.get("members"), list):
            continue
        folder_plan = plan_by_folder.get(clean_text(collection.get("id"), 300))
        changed = False
        pair_written = False
        seen: set[tuple[str, str]] = set()
        members: list[dict[str, Any]] = []
        for member in collection["members"]:
            if not isinstance(member, dict):
                continue
            member_id = clean_text(member.get("id"), 300)
            pair_member = member.get("kind") == "source" and member_id in {survivor_id, other_id}
            if pair_member and folder_plan:
                if pair_written:
                    changed = True
                    continue
                pair_written = True
                next_member = copy.deepcopy(member)
                next_member["id"] = survivor_id
                next_member.pop("reason", None)
                if folder_plan["mergedReason"] is not None:
                    next_member["reason"] = folder_plan["mergedReason"]
            else:
                next_member = copy.deepcopy(member)
                if next_member.get("kind") == "source" and member_id == other_id:
                    next_member["id"] = survivor_id
            if next_member != member:
                changed = True
            key = (clean_text(next_member.get("kind"), 30), clean_text(next_member.get("id"), 300))
            if key in seen:
                changed = True
                continue
            seen.add(key)
            members.append(next_member)
        if changed:
            collection["members"] = members
            collection["version"] = min(10_000, max(1, int(collection.get("version") or 1)) + 1)
            changed_count += 1
    return changed_count


def merge_source_alias_evidence(survivor: dict[str, Any], other: dict[str, Any]) -> None:
    occupied: set[str] = set()
    previous_values = survivor.get("previousUrls") if isinstance(survivor.get("previousUrls"), list) else []
    for raw in [survivor.get("url"), survivor.get("declaredFeedUrl"), *previous_values]:
        try:
            occupied.add(safe_http_url(raw))
        except ProgRSSError:
            pass
    aliases: list[str] = []
    seen = set(occupied)
    for source in (survivor, other):
        for value in sorted(source_address_aliases(source)):
            if value in seen:
                continue
            seen.add(value)
            aliases.append(value)
    if aliases:
        survivor["aliasUrls"] = aliases[:12]
    else:
        survivor.pop("aliasUrls", None)


def apply_source_repair(
    state: dict[str, Any], survivor_id: str, other_id: str, stamp: str | None = None
) -> dict[str, Any]:
    survivor = next((row for row in state.get("sources", []) if isinstance(row, dict) and clean_text(row.get("id"), 300) == survivor_id), None)
    other = next((row for row in state.get("sources", []) if isinstance(row, dict) and clean_text(row.get("id"), 300) == other_id), None)
    if survivor is None or other is None:
        raise ProgRSSError("one of these sources changed before the repair could finish")
    placement_plan = source_repair_placement_plan(state, survivor_id, other_id)
    if placement_plan["conflicts"]:
        raise ProgRSSError(source_repair_reason_conflict_message(placement_plan["conflicts"]))
    shared = sorted(source_address_aliases(survivor) & source_address_aliases(other))
    stamp = stamp or utc_now()
    item_merge = merge_source_items(state, survivor_id, other_id)
    state["items"] = item_merge.pop("items")
    changed_collections = remap_collection_source(state, other_id, survivor_id, placement_plan)
    merge_source_alias_evidence(survivor, other)
    created = sorted(value for value in (repair_iso(survivor.get("createdAt")), repair_iso(other.get("createdAt"))) if value)
    if created:
        survivor["createdAt"] = created[0]
    for key in ("lastSuccessfulAt", "lastNewAt"):
        values = sorted(value for value in (repair_iso(survivor.get(key)), repair_iso(other.get(key))) if value)
        survivor[key] = values[-1] if values else ""
    problem_candidates = []
    for source in (survivor, other):
        problem_at = repair_iso(source.get("lastProblemAt") or source.get("lastScan"))
        if problem_at:
            problem_candidates.append((problem_at, source))
    if problem_candidates:
        problem_at, source = sorted(problem_candidates, key=lambda row: row[0])[-1]
        survivor["lastProblemAt"] = problem_at
        survivor["lastProblem"] = clean_text(source.get("lastProblem") or source.get("lastError"), 500)
    survivor["checkCount"] = max(0, int(survivor.get("checkCount") or 0)) + max(0, int(other.get("checkCount") or 0))
    history = []
    for source in (survivor, other):
        if isinstance(source.get("repairHistory"), list):
            history.extend(copy.deepcopy(row) for row in source["repairHistory"] if isinstance(row, dict))
    history.append({
        "at": stamp,
        "sourceId": clean_text(other.get("id"), 300),
        "title": clean_text(other.get("title"), 180),
        "url": clean_text(other.get("url"), 2_048),
        "sharedAddresses": shared[:6],
    })
    survivor["repairHistory"] = history[-8:]
    state["sources"] = [row for row in state.get("sources", []) if row is not other]
    state["version"] = 14
    return {
        "survivorId": survivor_id,
        "survivorTitle": clean_text(survivor.get("title"), 180) or "Source",
        "removedSourceId": other_id,
        "removedSourceTitle": clean_text(other.get("title"), 180) or "Source",
        "itemMerge": item_merge,
        "changedCollections": changed_collections,
        "sharedAddresses": shared,
    }


def source_repair_candidate_pairs(state: dict[str, Any]) -> list[tuple[dict[str, Any], dict[str, Any], list[str]]]:
    sources = [
        row for row in state.get("sources", [])
        if isinstance(row, dict) and row.get("type") == "rss" and not row.get("archivedAt")
    ]
    pairs: list[tuple[dict[str, Any], dict[str, Any], list[str]]] = []
    for index, first in enumerate(sources):
        first_aliases = source_address_aliases(first)
        for second in sources[index + 1:]:
            shared = sorted(first_aliases & source_address_aliases(second))
            if shared:
                pairs.append((first, second, shared))
    pairs.sort(key=lambda row: (
        clean_text(row[0].get("title"), 180).casefold(),
        clean_text(row[1].get("title"), 180).casefold(),
        clean_text(row[0].get("id"), 300),
        clean_text(row[1].get("id"), 300),
    ))
    return pairs


def cmd_workspace_duplicate_sources(args: argparse.Namespace) -> int:
    _wrapper, state = load_backup(Path(args.backup))
    pairs = source_repair_candidate_pairs(state)
    rows = []
    for first, second, shared in pairs[: args.limit]:
        blockers = source_repair_blockers(state, first, second)
        rows.append({
            "sharedAddresses": shared,
            "canCombine": not blockers["blockers"],
            "blockers": blockers["blockers"],
            "placementConflicts": blockers["placementConflicts"],
            "advancedReferences": blockers["advancedReferences"],
            "sources": [source_repair_summary(state, first), source_repair_summary(state, second)],
        })
    report = {
        "schema": "progrss.workspace.duplicate-sources.v1",
        "candidatePairs": len(pairs),
        "shownPairs": len(rows),
        "truncated": len(pairs) > len(rows),
        "pairs": rows,
        "network": False,
        "writes": False,
        "browserProfileRead": False,
        "note": "Shared addresses are evidence for review, not publisher authentication.",
    }
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    if not pairs:
        print("No possible same-source pairs found · offline · no writes")
        return 0
    print(f"{len(pairs)} possible same-source pair{'s' if len(pairs) != 1 else ''} · offline · no writes")
    for index, row in enumerate(rows, 1):
        first, second = row["sources"]
        state_word = "ready to review" if row["canCombine"] else "blocked"
        print(f"\n{index}. {first['title']}  +  {second['title']} — {state_word}")
        print(f"   Shared: {', '.join(row['sharedAddresses'])}")
        for source in (first, second):
            items = source["items"]
            validators = source["validators"]
            validator_label = "ETag + Last-Modified" if validators["etag"] and validators["lastModified"] else ("ETag" if validators["etag"] else ("Last-Modified" if validators["lastModified"] else "none"))
            print(
                f"   - {source['id']} · {source['status']} · {items['items']} updates · "
                f"{items['unread']} unread · {items['saved']} saved · validators {validator_label}"
            )
            print(f"     {source['url']}")
        for message in row["blockers"]:
            print(f"   Blocked: {message}")
    if report["truncated"]:
        print(f"\nShowing {len(rows)} of {len(pairs)} pairs; raise --limit to inspect more.")
    print("\nUse workspace combine-sources with an explicit --keep choice to create a new backup.")
    return 0


def cmd_workspace_source_references(args: argparse.Namespace) -> int:
    _wrapper, state = load_backup(Path(args.backup))
    first = resolve_source_for_placement(state, args.first)
    second = resolve_source_for_placement(state, args.second)
    shared = source_repair_pair(state, first, second)
    report = source_reference_report(state, first, second)
    report["sharedAddresses"] = shared
    report["canCombine"] = not report["summary"]["blockingRecords"] and not report["summary"]["scanExceeded"]
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0

    sources = report["sources"]
    summary = report["summary"]
    print(f"References to {sources[0]['title']} and {sources[1]['title']}")
    print(
        f"{summary['blockingRecords']} blocking record{'s' if summary['blockingRecords'] != 1 else ''} · "
        f"{summary['exactReferences']} exact reference{'s' if summary['exactReferences'] != 1 else ''} · "
        "offline · no writes · no browser-profile read"
    )
    print(f"Shared address evidence: {', '.join(shared)}")
    if not report["groups"]:
        print("\nNo blocking Advanced Workbench references remain. Review the pair again before combining it.")
    for group in report["groups"]:
        print(
            f"\n{group['label']} — {group['recordCount']} record{'s' if group['recordCount'] != 1 else ''}, "
            f"{group['referenceCount']} reference{'s' if group['referenceCount'] != 1 else ''}"
        )
        print(f"  Why it blocks: {group['reason']}")
        for record in group["records"]:
            identity = f" · {record['schema']}" if record.get("schema") else ""
            print(f"  - {record['title']} [{record['recordId']}]{identity}")
            for reference in record.get("references", []):
                if reference["kind"] == "update":
                    label = f"Retained update “{reference['label']}” from {reference['sourceTitle']}"
                else:
                    label = f"Source history “{reference['sourceTitle']}”"
                count = reference.get("referenceCount", 0)
                print(f"      {label}{f' · {count} occurrences' if count > 1 else ''}")
                if args.paths:
                    for path in reference.get("paths", []):
                        print(f"        {path}")
            if record.get("pathsTruncated"):
                print("      Additional exact paths omitted from the bounded display.")
            if isinstance(record.get("retirement"), dict) and record["retirement"].get("eligible"):
                print(
                    "      Narrow cleanup available: preserve this exact graft receipt as retired evidence with "
                    "workspace retire-graft-receipt."
                )
        if group.get("scanExceeded"):
            print("  Audit limit reached in this group; the record list may be incomplete.")
    if report.get("retiredEvidence"):
        print(
            f"\nPreserved retired evidence — {summary['retiredRecords']} receipt"
            f"{'s' if summary['retiredRecords'] != 1 else ''}, {summary['retiredReferences']} historical reference"
            f"{'s' if summary['retiredReferences'] != 1 else ''}"
        )
        for record in report["retiredEvidence"]:
            print(f"  - {record['originalTitle']} [{record['retirementId']}] · {record['originalDigest']}")
    print("\nReport only: no record was rewritten, deleted, or granted trust.")
    return 0


def canonical_receipt_string(value: str) -> str:
    if any(0xD800 <= ord(character) <= 0xDFFF for character in value):
        raise ProgRSSError("receipt contains invalid Unicode and cannot receive a portable digest")
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def canonical_receipt_json(value: Any) -> str:
    """Canonicalize the bounded JSON subset shared with the Extension.

    Receipt retirement deliberately accepts only safe-integer numeric fields
    and Unicode scalar strings. That keeps the JavaScript and Python digests
    byte-identical without hiding cross-runtime serialization differences.
    """
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int):
        if abs(value) > 9_007_199_254_740_991:
            raise ProgRSSError("this release retires only receipts whose numeric fields are portable safe integers")
        return str(value)
    if isinstance(value, float):
        if not value.is_integer() or abs(value) > 9_007_199_254_740_991:
            raise ProgRSSError("this release retires only receipts whose numeric fields are portable safe integers")
        return str(int(value))
    if isinstance(value, str):
        return canonical_receipt_string(value)
    if isinstance(value, list):
        return "[" + ",".join(canonical_receipt_json(row) for row in value) + "]"
    if isinstance(value, dict):
        if not all(isinstance(key, str) for key in value):
            raise ProgRSSError("receipt object keys must be strings")
        for key in value:
            canonical_receipt_string(key)
        keys = sorted(value, key=lambda key: key.encode("utf-16-be"))
        return "{" + ",".join(
            f"{canonical_receipt_string(key)}:{canonical_receipt_json(value[key])}"
            for key in keys
        ) + "}"
    raise ProgRSSError("receipt contains a value that cannot be represented as portable JSON")


def canonical_receipt_digest(receipt: dict[str, Any]) -> str:
    return hashlib.sha256(canonical_receipt_json(receipt).encode("utf-8")).hexdigest()


def select_graft_receipt_for_retirement(
    state: dict[str, Any], first: dict[str, Any], second: dict[str, Any], selector: str
) -> dict[str, Any]:
    report = source_reference_report(state, first, second)
    candidates = [
        record
        for group in report["groups"] if group.get("key") == "receipts"
        for record in group.get("records", [])
        if isinstance(record.get("retirement"), dict) and record["retirement"].get("eligible")
    ]
    token = clean_text(selector, 220)
    matches = [record for record in candidates if token in {record.get("recordId"), record.get("title")}]
    if not matches:
        available = ", ".join(f"{row['recordId']} ({row['title']})" for row in candidates[:12]) or "none"
        raise ProgRSSError(f"no eligible blocking graft receipt matches {token!r}; available: {available}")
    if len(matches) > 1:
        raise ProgRSSError("receipt selector is ambiguous; use the exact local receipt id")
    descriptor = matches[0]
    index = descriptor.get("index")
    if not isinstance(index, int) or index < 0 or index >= len(state.get("receipts", [])):
        raise ProgRSSError("the selected receipt changed before retirement could be prepared")
    receipt = state["receipts"][index]
    if not isinstance(receipt, dict) or receipt.get("schema") != GRAFT_RECEIPT_SCHEMA:
        raise ProgRSSError("only progrss.recipe.graft.receipt.v1 can be retired by this release")
    return {"descriptor": descriptor, "index": index, "receipt": receipt, "digest": canonical_receipt_digest(receipt)}


def cmd_workspace_retire_graft_receipt(args: argparse.Namespace) -> int:
    wrapper, state = load_backup(Path(args.backup))
    first = resolve_source_for_placement(state, args.first)
    second = resolve_source_for_placement(state, args.second)
    shared = source_repair_pair(state, first, second)
    selected = select_graft_receipt_for_retirement(state, first, second, args.receipt)
    retired = state.get("retiredReceipts", [])
    if len(retired) >= MAX_RETIRED_RECEIPTS:
        raise ProgRSSError("the retired receipt archive is full; no output was written")
    if any(isinstance(row, dict) and row.get("originalDigest") == selected["digest"] for row in retired):
        raise ProgRSSError("an identical graft receipt is already preserved in retired evidence")

    result = copy.deepcopy(wrapper)
    result_state = copy.deepcopy(state)
    receipt = result_state["receipts"].pop(selected["index"])
    retired_at = utc_now()
    retirement_id = f"retired-graft-{selected['digest'][:24]}"
    result_state.setdefault("retiredReceipts", []).append({
        "schema": RETIRED_GRAFT_RECEIPT_SCHEMA,
        "id": retirement_id,
        "retiredAt": retired_at,
        "invalidatedAt": retired_at,
        "reason": "local-source-history-repair",
        "originalSchema": GRAFT_RECEIPT_SCHEMA,
        "originalRecordId": selected["descriptor"]["recordId"],
        "originalTitle": selected["descriptor"]["title"],
        "originalDigest": selected["digest"],
        "sourcePair": [{
            "id": clean_text(source.get("id"), 300),
            "title": clean_text(source.get("title"), 180) or "Untitled source",
        } for source in (first, second)],
        "sharedAddresses": shared[:12],
        "originalReceipt": receipt,
    })
    result_state["version"] = 14
    result["schema"] = BACKUP_SCHEMA
    result["exportedAt"] = retired_at
    result["state"] = portable_state(result_state)
    write_new(Path(args.output), json_bytes(result))
    print(f"Retired {selected['descriptor']['title']} without rewriting it")
    print(f"Preserved digest: {selected['digest']}")
    print(f"Shared evidence: {', '.join(shared)}")
    print(f"Wrote {args.output} · offline · new-file-only · original input unchanged")
    return 0


def cmd_workspace_retired_receipts(args: argparse.Namespace) -> int:
    _wrapper, state = load_backup(Path(args.backup))
    rows = []
    for envelope in state.get("retiredReceipts", [])[: args.limit]:
        original = envelope.get("originalReceipt") if isinstance(envelope, dict) else None
        computed = canonical_receipt_digest(original) if isinstance(original, dict) else ""
        rows.append({
            "retirementId": clean_text(envelope.get("id"), 220),
            "retiredAt": repair_iso(envelope.get("retiredAt")),
            "originalRecordId": clean_text(envelope.get("originalRecordId"), 220),
            "originalTitle": clean_text(envelope.get("originalTitle"), 180) or GRAFT_RECEIPT_SCHEMA,
            "originalSchema": clean_text(envelope.get("originalSchema"), 180),
            "originalDigest": clean_text(envelope.get("originalDigest"), 64),
            "computedDigest": computed,
            "integrity": "matches" if computed and computed == envelope.get("originalDigest") else "mismatch",
            "reason": clean_text(envelope.get("reason"), 180),
        })
    report = {
        "schema": "progrss.retired-graft-receipts.report.v1",
        "retiredReceipts": len(state.get("retiredReceipts", [])),
        "shownReceipts": len(rows),
        "truncated": len(state.get("retiredReceipts", [])) > len(rows),
        "receipts": rows,
        "network": False,
        "writes": False,
        "browserProfileRead": False,
    }
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    if not rows:
        print("No retired graft receipts · offline · no writes")
        return 0
    print(f"{report['retiredReceipts']} retired graft receipt{'s' if report['retiredReceipts'] != 1 else ''} · offline · no writes")
    for row in rows:
        print(f"- {row['originalTitle']} [{row['originalRecordId']}] · {row['integrity']}")
        print(f"  retired {row['retiredAt']} · {row['originalDigest']}")
    if report["truncated"]:
        print(f"Showing {len(rows)} of {report['retiredReceipts']}; raise --limit to inspect more.")
    return 0


def cmd_workspace_combine_sources(args: argparse.Namespace) -> int:
    wrapper, state = load_backup(Path(args.backup))
    first = resolve_source_for_placement(state, args.first)
    second = resolve_source_for_placement(state, args.second)
    shared = source_repair_pair(state, first, second)
    keep = resolve_source_for_placement(state, args.keep)
    pair_ids = {clean_text(first.get("id"), 300), clean_text(second.get("id"), 300)}
    keep_id = clean_text(keep.get("id"), 300)
    if keep_id not in pair_ids:
        raise ProgRSSError("--keep must select one of the two reviewed sources")
    blockers = source_repair_blockers(state, first, second)
    if blockers["blockers"]:
        raise ProgRSSError(blockers["blockers"][0])
    other_id = next(source_id for source_id in pair_ids if source_id != keep_id)
    result = copy.deepcopy(wrapper)
    result_state = copy.deepcopy(state)
    outcome = apply_source_repair(result_state, keep_id, other_id, utc_now())
    result["schema"] = BACKUP_SCHEMA
    result["exportedAt"] = utc_now()
    result["state"] = portable_state(result_state)
    write_new(Path(args.output), json_bytes(result))
    merged = outcome["itemMerge"]
    print(
        f"Combined {outcome['removedSourceTitle']} into {outcome['survivorTitle']} · "
        f"{merged['afterCount']} retained updates · {merged['exactRepeatsCollapsed']} exact repeats collapsed · "
        f"{outcome['changedCollections']} collections updated"
    )
    print(f"Shared evidence: {', '.join(shared)}")
    print("Kept the selected source's current address, schedule, permission context, and HTTP validators.")
    print(f"Wrote {args.output} · offline · new-file-only")
    return 0


def portable_state(state: dict[str, Any]) -> dict[str, Any]:
    """Remove storage-local coordination fields before writing a backup."""
    state.pop("_revision", None)
    state.pop("transferUndo", None)
    state.pop("sourceRepairUndo", None)
    state.pop("receiptRetirementUndo", None)
    state.pop("sharedFolderUpdateUndo", None)
    state.pop("pageWatchRepairUndo", None)
    for source in state.get("sources", []):
        if isinstance(source, dict):
            source.pop("watchStability", None)
    state["version"] = 17
    return state


def browser_origin(raw: Any) -> str:
    """Return a legible browser origin without leaking a path or query."""
    parsed = urllib.parse.urlsplit(safe_http_url(raw))
    host = str(parsed.hostname or "").lower().rstrip(".")
    if ":" in host and not host.startswith("["):
        host = f"[{host}]"
    try:
        port = parsed.port
    except ValueError as exc:
        raise ProgRSSError("URL contains an invalid port") from exc
    default = 443 if parsed.scheme == "https" else 80
    suffix = f":{port}" if port is not None and port != default else ""
    return f"{parsed.scheme}://{host}{suffix}"


def transfer_audit_report(
    wrapper: dict[str, Any], state: dict[str, Any], *, include_origins: bool = False
) -> dict[str, Any]:
    """Describe a browser-to-browser move without reading a browser profile.

    The CLI cannot know which optional host permissions a destination browser
    already has, so reconnect figures are deliberately upper bounds.
    """
    audit = state_audit(state)
    sources = [row for row in state["sources"] if isinstance(row, dict)]
    items = [row for row in state["items"] if isinstance(row, dict)]
    active = [row for row in sources if row.get("enabled") and not row.get("archivedAt")]
    moved = [row for row in active if isinstance(row.get("pendingRedirect"), dict)]
    reconnect_candidates = [row for row in active if not isinstance(row.get("pendingRedirect"), dict)]
    paused = [row for row in sources if not row.get("enabled") and not row.get("archivedAt")]
    archived = [row for row in sources if row.get("archivedAt")]

    origin_rows: dict[str, dict[str, Any]] = {}
    invalid_active_addresses = 0
    for source in reconnect_candidates:
        try:
            origin = browser_origin(source.get("url"))
        except ProgRSSError:
            invalid_active_addresses += 1
            continue
        row = origin_rows.setdefault(origin, {"origin": origin, "sourceCount": 0})
        row["sourceCount"] += 1

    snapshot_count = len(state.get("snapshots", {})) if isinstance(state.get("snapshots"), dict) else 0
    advanced_by_kind = {
        key: len(state.get(key, [])) if isinstance(state.get(key), list) else 0
        for key in ADVANCED_STATE_KEYS
    }
    retired_receipt_count = len(state.get("retiredReceipts", [])) if isinstance(state.get("retiredReceipts"), list) else 0
    advanced_by_kind["retiredReceipts"] = retired_receipt_count
    advanced_count = sum(advanced_by_kind.values())
    producer = wrapper.get("producer") if isinstance(wrapper.get("producer"), dict) else None
    wrapper_has_local_undo = bool(state.get("transferUndo") or state.get("sourceRepairUndo") or state.get("receiptRetirementUndo") or state.get("sharedFolderUpdateUndo") or state.get("pageWatchRepairUndo"))
    warnings = list(audit["warnings"])
    if wrapper_has_local_undo:
        warnings.append("The file contains a browser-local undo record; ProgRSS ignores it when importing.")
    if invalid_active_addresses:
        warnings.append(
            f"{invalid_active_addresses} active source address"
            f"{'es are' if invalid_active_addresses != 1 else ' is'} invalid and cannot be grouped by site."
        )

    private_categories: list[str] = []
    if sources:
        private_categories.append("source titles and addresses")
    if items:
        private_categories.append("reading history, saved state, and retained update text")
    if snapshot_count:
        private_categories.append("locally retained page-watch snapshots")
    if state["collections"]:
        private_categories.append("collections and folder structure")
    source_note_count = source_note_placement_count(state)
    if source_note_count:
        private_categories.append("curator-written folder reasons")
    if advanced_count:
        private_categories.append("Advanced Workbench records")

    sorted_origins = sorted(origin_rows.values(), key=lambda row: row["origin"])
    report = {
        "schema": "progrss.workspace.transfer-audit.v1",
        "backupSchema": wrapper.get("schema"),
        "exportedAt": clean_text(wrapper.get("exportedAt"), 100),
        "producer": producer,
        "vaultVersion": state.get("version"),
        "moves": {
            "sources": len(sources),
            "feeds": sum(1 for row in sources if row.get("type") == "rss"),
            "pageWatches": sum(1 for row in sources if row.get("type") == "page"),
            "collections": len(state["collections"]),
            "sourceNotes": source_note_count,
            "updates": len(items),
            "unread": sum(1 for row in items if not row.get("readAt")),
            "saved": sum(1 for row in items if row.get("starred")),
            "snapshots": snapshot_count,
            "advancedRecords": advanced_count,
            "advancedByKind": advanced_by_kind,
        },
        "destination": {
            "activeSources": len(active),
            "pausedSources": len(paused),
            "archivedSources": len(archived),
            "movedSourcesStillNeedingReview": len(moved),
            "upToReconnectSources": len(reconnect_candidates),
            "upToReconnectOrigins": len(sorted_origins),
            "permissionKnowledge": "unknown-without-destination-browser",
            "originsIncluded": include_origins,
            "origins": sorted_origins if include_origins else [],
        },
        "privacy": {
            "containsPrivateData": bool(private_categories),
            "categories": private_categories,
            "keepFilePrivate": bool(private_categories),
        },
        "doesNotMove": [
            "browser-granted site access",
            "browser or extension installation identity",
            "temporary browser-local undo copies",
            "one-check page-watch confirmation state",
        ],
        "audit": {
            "state": "invalid" if audit["errors"] else ("needs-review" if warnings else "valid"),
            "errors": audit["errors"],
            "warnings": warnings,
        },
        "network": False,
        "writes": False,
        "browserProfileRead": False,
    }
    return report


def cmd_workspace_transfer_audit(args: argparse.Namespace) -> int:
    wrapper, state = load_backup(Path(args.backup))
    report = transfer_audit_report(wrapper, state, include_origins=args.origins)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 2 if report["audit"]["errors"] else 0

    moves = report["moves"]
    destination = report["destination"]
    audit = report["audit"]
    print("ProgRSS library transfer audit · offline · no writes")
    if report["exportedAt"]:
        print(f"Exported: {report['exportedAt']}")
    if report["producer"]:
        name = clean_text(report["producer"].get("name"), 80) or "ProgRSS"
        version = clean_text(report["producer"].get("version"), 40)
        print(f"Created by: {name}{f' {version}' if version else ''}")
    print(
        f"Moves: {moves['sources']} sources "
        f"({moves['feeds']} feeds, {moves['pageWatches']} page watches), "
        f"{moves['collections']} collections, {moves['sourceNotes']} curator reasons"
    )
    print(
        f"Reading: {moves['updates']} updates · {moves['unread']} unread · "
        f"{moves['saved']} saved · {moves['snapshots']} snapshots"
    )
    print(f"Advanced Workbench: {moves['advancedRecords']} retained records")
    print("\nOn the destination browser:")
    if destination["upToReconnectSources"]:
        print(
            f"- Up to {destination['upToReconnectSources']} active source"
            f"{'s' if destination['upToReconnectSources'] != 1 else ''} across "
            f"{destination['upToReconnectOrigins']} site"
            f"{'s' if destination['upToReconnectOrigins'] != 1 else ''} may show Reconnect. "
            "The destination may already have access to some of them."
        )
    else:
        print("- No ordinary active source needs a destination-site permission check.")
    if destination["movedSourcesStillNeedingReview"]:
        count = destination["movedSourcesStillNeedingReview"]
        print(f"- {count} source move{'s remain' if count != 1 else ' remains'} waiting for human review.")
    if destination["pausedSources"]:
        count = destination["pausedSources"]
        print(f"- {count} paused source{'s stay' if count != 1 else ' stays'} paused and asks only when resumed.")
    if destination["archivedSources"]:
        print(f"- {destination['archivedSources']} archived source{'s stay' if destination['archivedSources'] != 1 else ' stays'} archived.")
    print("- Browser-granted site access, installation identity, and temporary undo copies do not move.")

    if report["privacy"]["categories"]:
        print("\nKeep this file private. It contains:")
        for category in report["privacy"]["categories"]:
            print(f"- {category}")

    if args.origins:
        print("\nActive sites that may need Reconnect:")
        if destination["origins"]:
            for row in destination["origins"]:
                print(f"- {row['origin']} · {row['sourceCount']} source{'s' if row['sourceCount'] != 1 else ''}")
        else:
            print("- none")
    else:
        print("\nUse --origins to show the site list. It is hidden by default for terminal privacy.")

    print(f"\nAudit: {audit['state']} · {len(audit['errors'])} errors · {len(audit['warnings'])} warnings")
    for line in (audit["errors"] + audit["warnings"])[: args.limit]:
        print(f"- {line}")
    return 2 if audit["errors"] else 0


def vault_content_digest(state: dict[str, Any]) -> str:
    # This binds the exact normalized portable private-vault content and list order while
    # excluding browser-local coordination and short-lived rollback/confirmation state.
    # It is a change detector, not a signature, publisher identity, or semantic-equivalence claim.
    projection = copy.deepcopy({
        key: value for key, value in state.items()
        if key not in {"_revision", "transferUndo", "sourceRepairUndo", "receiptRetirementUndo", "sharedFolderUpdateUndo", "pageWatchRepairUndo"}
    })
    for source in projection.get("sources", []):
        if isinstance(source, dict):
            source.pop("watchStability", None)
    encoded = json.dumps(projection, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def cmd_doctor(_args: argparse.Namespace) -> int:
    checks = [
        ("Python", f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}", sys.version_info >= (3, 11)),
        ("Legacy carrier", str(LEGACY), LEGACY.is_file()),
        ("Pulse package", str(ROOT / "cadence" / "cli.py"), (ROOT / "cadence" / "cli.py").is_file()),
        ("SSL", ssl.OPENSSL_VERSION, bool(ssl.OPENSSL_VERSION)),
        ("Default network mode", "offline", True),
        ("Output policy", "new-file-only", True),
    ]
    for label, value, okay in checks:
        print(f"{'OK' if okay else 'FAIL':4}  {label}: {value}")
    print(f"ProgRSS CLI {VERSION}")
    return 0 if all(row[2] for row in checks) else 1


def cmd_feed_inspect(args: argparse.Namespace) -> int:
    raw = read_limited(Path(args.file), MAX_FEED_BYTES, "feed")
    parsed = parse_feed(raw, args.url)
    report = {
        "schema": "progrss.feed.inspection.v1",
        "title": parsed["title"],
        "type": parsed["type"],
        "language": language_tag(parsed.get("language")),
        "titleLanguage": language_tag(parsed.get("titleLanguage")),
        "origin": safe_http_url(args.url),
        "feedUrl": clean_text(parsed.get("feedUrl"), 2_048),
        "itemCount": len(parsed["items"]),
        "items": [{key: item.get(key, "") for key in ("key", "title", "url", "summary", "body", "bodyIsSummary", "language", "titleLanguage", "summaryLanguage", "bodyLanguage", "published")} for item in parsed["items"]],
        "network": False,
    }
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(f"{report['title']}\n{report['type'].upper()} · {report['itemCount']} items · offline")
        for item in report["items"][: args.limit]:
            stamp = item["published"] or "undated"
            print(f"- {item['title']} [{stamp}]")
            if item["url"]:
                print(f"  {item['url']}")
    return 0


def preview_content_kind(item: dict[str, Any]) -> str:
    body = clean_text(item.get("body"), 12_000)
    summary = clean_text(item.get("summary"), 12_000)
    if body and not item.get("bodyIsSummary") and not item.get("bodyOmitted"):
        return "full-text"
    if body or summary:
        return "summary"
    return "title-only"


def compact_feed_preview(parsed: dict[str, Any], origin: str, limit: int) -> dict[str, Any]:
    examples = []
    for item in parsed.get("items", [])[:limit]:
        if not isinstance(item, dict):
            continue
        examples.append({
            "title": clean_text(item.get("title"), 240) or "Untitled update",
            "url": clean_text(item.get("url"), 2_048),
            "published": clean_text(item.get("published"), 80),
            "content": preview_content_kind(item),
            "language": language_tag(item.get("language")),
            "titleLanguage": language_tag(item.get("titleLanguage") or item.get("language")),
        })
    return {
        "schema": "progrss.feed.preview.v1",
        "title": clean_text(parsed.get("title"), 240) or "Untitled feed",
        "type": clean_text(parsed.get("type"), 24),
        "language": language_tag(parsed.get("language")),
        "titleLanguage": language_tag(parsed.get("titleLanguage")),
        "origin": safe_http_url(origin),
        "feedUrl": clean_text(parsed.get("feedUrl"), 2_048),
        "itemCount": len(parsed.get("items", [])),
        "exampleCount": len(examples),
        "fullTextCount": sum(row["content"] == "full-text" for row in examples),
        "summaryCount": sum(row["content"] == "summary" for row in examples),
        "titleOnlyCount": sum(row["content"] == "title-only" for row in examples),
        "examples": examples,
        "edition": parsed.get("edition") if isinstance(parsed.get("edition"), dict) else None,
        "network": False,
        "writes": False,
    }


def cmd_feed_preview(args: argparse.Namespace) -> int:
    raw = read_limited(Path(args.file), MAX_FEED_BYTES, "feed")
    parsed = parse_feed(raw, args.url)
    report = compact_feed_preview(parsed, args.url, args.limit)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    print(report['title'])
    print(f"{report['type'].upper()} · {report['itemCount']} items · {report['exampleCount']} shown · offline")
    if report.get("edition"):
        print(f"Recent updates for source list: {report['edition']['folder']}")
        print("Following this feed would add one summary feed, not its underlying sources.")
    content_labels = {
        "full-text": "fuller feed text",
        "summary": "summary",
        "title-only": "title only",
    }
    for item in report["examples"]:
        stamp = item["published"] or "no date supplied"
        print(f"- {item['title']} [{stamp}] · {content_labels[item['content']]}")
        if item["url"]:
            print(f"  {item['url']}")
    if not report["examples"]:
        print("No items were included in this feed response.")
    print("Nothing followed · no writes")
    return 0


def cmd_feed_fetch(args: argparse.Namespace) -> int:
    url = safe_http_url(args.url)
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/rss+xml, application/atom+xml, application/feed+json, application/json, text/xml;q=0.9, */*;q=0.2",
            "User-Agent": f"ProgRSS/{VERSION} explicit-feed-fetch",
        },
        method="GET",
    )
    redirect_policy = SameOriginRedirects(url)
    opener = urllib.request.build_opener(redirect_policy)
    final_url = url
    try:
        with opener.open(request, timeout=args.timeout) as response:
            final_url = safe_http_url(response.geturl())
            declared = response.headers.get("Content-Length")
            try:
                declared_size = int(declared) if declared is not None else 0
            except (TypeError, ValueError):
                declared_size = 0
            if declared_size > MAX_FEED_BYTES:
                raise ProgRSSError("response is larger than the 2,000,000-byte limit")
            body = response.read(MAX_FEED_BYTES + 1)
            if len(body) > MAX_FEED_BYTES:
                raise ProgRSSError("response is larger than the 2,000,000-byte limit")
    except ProgRSSError:
        raise
    except urllib.error.HTTPError as exc:
        raise ProgRSSError(f"HTTP {exc.code} from {url}") from exc
    except urllib.error.URLError as exc:
        raise ProgRSSError(f"network request failed: {exc.reason}") from exc
    except TimeoutError as exc:
        raise ProgRSSError("network request timed out") from exc
    # Validation happens before the file commit unless explicitly disabled.
    if not args.no_validate:
        parse_feed(body, final_url)
    output = Path(args.output)
    write_new(output, body)
    redirect_note = f"; followed {len(redirect_policy.chain)} same-site redirect{'s' if len(redirect_policy.chain) != 1 else ''}" if redirect_policy.chain else ""
    print(f"Wrote {len(body):,} bytes to {output} (explicit network fetch{redirect_note}; final address {final_url})")
    return 0


def cmd_workspace_inspect(args: argparse.Namespace) -> int:
    wrapper, state = load_backup(Path(args.backup))
    audit = state_audit(state)
    sources = [row for row in state["sources"] if isinstance(row, dict)]
    items = [row for row in state["items"] if isinstance(row, dict)]
    report = {
        "schema": "progrss.workspace.inspection.v1",
        "backupSchema": wrapper.get("schema"),
        "exportedAt": wrapper.get("exportedAt", ""),
        "vaultVersion": state.get("version"),
        "counts": {
            "sources": len(sources),
            "activeSources": sum(1 for row in sources if row.get("enabled") and not row.get("archivedAt")),
            "archivedSources": sum(1 for row in sources if row.get("archivedAt")),
            "collections": len(state["collections"]),
            "items": len(items),
            "unread": sum(1 for row in items if not row.get("readAt")),
            "saved": sum(1 for row in items if row.get("starred")),
        },
        "audit": audit,
        "vaultContentDigest": vault_content_digest(state),
        "network": False,
    }
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        counts = report["counts"]
        print(f"ProgRSS private workspace · vault v{report['vaultVersion']}")
        print(f"{counts['sources']} sources ({counts['activeSources']} active, {counts['archivedSources']} archived)")
        print(f"{counts['items']} updates · {counts['unread']} unread · {counts['saved']} saved")
        print(f"Audit: {audit['state']} · {len(audit['errors'])} errors · {len(audit['warnings'])} warnings")
        print(f"Vault content digest: {report['vaultContentDigest']} (change detector, not identity proof)")
        if audit["errors"] or audit["warnings"]:
            for line in (audit["errors"] + audit["warnings"])[: args.limit]:
                print(f"- {line}")
    return 2 if audit["errors"] else 0


def private_copy_counts(state: dict[str, Any]) -> dict[str, int]:
    sources = [row for row in state.get("sources", []) if isinstance(row, dict)]
    items = [row for row in state.get("items", []) if isinstance(row, dict)]
    return {
        "sources": len(sources),
        "activeSources": sum(1 for row in sources if row.get("enabled") and not row.get("archivedAt")),
        "collections": len([row for row in state.get("collections", []) if isinstance(row, dict)]),
        "items": len(items),
        "unread": sum(1 for row in items if not row.get("readAt")),
        "saved": sum(1 for row in items if row.get("starred")),
        "snapshots": len(state.get("snapshots", {})) if isinstance(state.get("snapshots"), dict) else 0,
        "advancedRecords": sum(len(state.get(key, [])) for key in ADVANCED_STATE_KEYS if isinstance(state.get(key), list))
            + (len(state.get("retiredReceipts", [])) if isinstance(state.get("retiredReceipts"), list) else 0),
    }


def exact_value_digest(value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def keyed_copy_changes(first_rows: Any, second_rows: Any) -> dict[str, int]:
    def keyed(rows: Any) -> dict[str, dict[str, Any]]:
        result: dict[str, dict[str, Any]] = {}
        if not isinstance(rows, list):
            return result
        for row in rows:
            if not isinstance(row, dict):
                continue
            identity = clean_text(row.get("id"), 300)
            if identity:
                result[identity] = row
        return result

    first = keyed(first_rows)
    second = keyed(second_rows)
    shared = set(first) & set(second)
    changed = sum(1 for identity in shared if exact_value_digest(first[identity]) != exact_value_digest(second[identity]))
    return {
        "added": len(set(second) - set(first)),
        "removed": len(set(first) - set(second)),
        "changed": changed,
        "unchanged": len(shared) - changed,
    }


def mapping_copy_changes(first_value: Any, second_value: Any) -> dict[str, int]:
    first = first_value if isinstance(first_value, dict) else {}
    second = second_value if isinstance(second_value, dict) else {}
    shared = set(first) & set(second)
    changed = sum(1 for key in shared if exact_value_digest(first[key]) != exact_value_digest(second[key]))
    return {
        "added": len(set(second) - set(first)),
        "removed": len(set(first) - set(second)),
        "changed": changed,
        "unchanged": len(shared) - changed,
    }


def private_copy_descriptor(wrapper: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    audit = state_audit(state)
    return {
        "exportedAt": clean_text(wrapper.get("exportedAt"), 100),
        "purpose": clean_text(wrapper.get("purpose"), 80),
        "producer": wrapper.get("producer") if isinstance(wrapper.get("producer"), dict) else None,
        "vaultVersion": state.get("version"),
        "counts": private_copy_counts(state),
        "vaultContentDigest": vault_content_digest(state),
        # Copy comparison is intentionally private by default. Exact audit text
        # may contain local IDs derived from feed entry addresses, so only
        # bounded audit state and counts belong in this report.
        "audit": {
            "state": audit["state"],
            "errorCount": len(audit["errors"]),
            "warningCount": len(audit["warnings"]),
        },
    }


def compare_private_copies_report(
    first_wrapper: dict[str, Any], first_state: dict[str, Any],
    second_wrapper: dict[str, Any], second_state: dict[str, Any],
) -> dict[str, Any]:
    first = private_copy_descriptor(first_wrapper, first_state)
    second = private_copy_descriptor(second_wrapper, second_state)
    count_deltas = {
        key: second["counts"][key] - first["counts"][key]
        for key in first["counts"]
    }
    advanced_groups = [*ADVANCED_STATE_KEYS, "retiredReceipts"]
    advanced_changed = [
        key for key in advanced_groups
        if exact_value_digest(first_state.get(key, [])) != exact_value_digest(second_state.get(key, []))
    ]
    same = first["vaultContentDigest"] == second["vaultContentDigest"]
    invalid = bool(first["audit"]["errorCount"] or second["audit"]["errorCount"])
    return {
        "schema": "progrss.workspace.copy-comparison.v1",
        "state": "invalid" if invalid else ("same" if same else "different"),
        "samePortableLibrary": same,
        "first": first,
        "second": second,
        "countDeltas": count_deltas,
        "changes": {
            "sources": keyed_copy_changes(first_state.get("sources"), second_state.get("sources")),
            "collections": keyed_copy_changes(first_state.get("collections"), second_state.get("collections")),
            "items": keyed_copy_changes(first_state.get("items"), second_state.get("items")),
            "snapshots": mapping_copy_changes(first_state.get("snapshots"), second_state.get("snapshots")),
            "advancedChangedGroups": advanced_changed,
        },
        "note": "Export times describe when files were prepared; they do not prove that either file is a complete successor of the other.",
        "network": False,
        "writes": False,
        "browserProfileRead": False,
        "permissions": False,
    }


def cmd_workspace_compare_copies(args: argparse.Namespace) -> int:
    first_wrapper, first_state = load_backup(Path(args.first))
    second_wrapper, second_state = load_backup(Path(args.second))
    report = compare_private_copies_report(first_wrapper, first_state, second_wrapper, second_state)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        if report["state"] == "invalid":
            return 2
        if args.require_match and not report["samePortableLibrary"]:
            return 3
        return 0

    print("ProgRSS private-copy comparison · offline · no writes")
    for label, copy_row in (("First", report["first"]), ("Second", report["second"])):
        counts = copy_row["counts"]
        prepared = f" · prepared {copy_row['exportedAt']}" if copy_row["exportedAt"] else ""
        print(
            f"{label}: {counts['sources']} sources · {counts['items']} updates · "
            f"{counts['unread']} unread · {counts['saved']} saved{prepared}"
        )
        print(f"  {copy_row['vaultContentDigest']}")
    print(f"Same portable library: {'yes' if report['samePortableLibrary'] else 'no'}")
    if not report["samePortableLibrary"]:
        for label, key in (("Sources", "sources"), ("Folders", "collections"), ("Updates", "items"), ("Snapshots", "snapshots")):
            row = report["changes"][key]
            print(f"{label}: +{row['added']} · -{row['removed']} · {row['changed']} changed")
        advanced = report["changes"]["advancedChangedGroups"]
        print(f"Advanced Workbench groups changed: {len(advanced)}")
    print(report["note"] )
    error_count = report["first"]["audit"]["errorCount"] + report["second"]["audit"]["errorCount"]
    if error_count:
        print(f"Audit: invalid · {error_count} error{'s' if error_count != 1 else ''}")
        print("Use workspace inspect on each file for its explicit local audit.")
        return 2
    print("No browser profile, site permission, network, or file was changed.")
    if args.require_match and not report["samePortableLibrary"]:
        print("Required match: no · exiting with status 3")
        return 3
    return 0


def recovery_copy_report(state: dict[str, Any]) -> dict[str, Any]:
    """Describe one validated private recovery copy without reading a browser profile."""
    audit = state_audit(state)
    sources = [row for row in state.get("sources", []) if isinstance(row, dict)]
    items = [row for row in state.get("items", []) if isinstance(row, dict)]
    return {
        "schema": "progrss.workspace.recovery-copy.v1",
        "counts": {
            "sources": len(sources),
            "items": len(items),
            "unread": sum(1 for row in items if not row.get("readAt")),
            "saved": sum(1 for row in items if row.get("starred")),
            "collections": len([row for row in state.get("collections", []) if isinstance(row, dict)]),
        },
        "audit": audit,
        "vaultContentDigest": vault_content_digest(state),
        "privatePlaintext": True,
        "network": False,
        "browserProfileRead": False,
        "permissions": False,
        "inputMutation": False,
        "writes": True,
    }


def cmd_workspace_recovery_copy(args: argparse.Namespace) -> int:
    _wrapper, state = load_backup(Path(args.backup))
    report = recovery_copy_report(state)
    if report["audit"]["errors"]:
        first = report["audit"]["errors"][0]
        raise ProgRSSError(f"backup audit failed; recovery copy was not written: {first}")
    portable = portable_state(copy.deepcopy(state))
    document = {
        "schema": BACKUP_SCHEMA,
        "exportedAt": utc_now(),
        "purpose": "recovery-copy",
        "producer": {"name": "ProgRSS", "version": VERSION, "revision": REVISION},
        "state": portable,
    }
    output = Path(args.output)
    expected_digest = vault_content_digest(portable)
    write_new(output, json_bytes(document))
    try:
        written_wrapper, written_state = load_backup(output)
        if written_wrapper.get("schema") != BACKUP_SCHEMA or written_wrapper.get("purpose") != "recovery-copy":
            raise ProgRSSError("written file is not the expected private recovery copy")
        written_digest = vault_content_digest(written_state)
        if written_digest != expected_digest:
            raise ProgRSSError("written recovery copy does not match the prepared portable library")
    except Exception as exc:
        try:
            output.unlink()
            fsync_directory(output.expanduser().resolve().parent)
        except OSError:
            pass
        if isinstance(exc, ProgRSSError):
            raise ProgRSSError(f"recovery copy failed its local read-back check; output was removed: {exc}") from exc
        raise ProgRSSError(f"recovery copy failed its local read-back check; output was removed: {exc}") from exc
    counts = report["counts"]
    print(
        f"Wrote and re-opened private recovery copy {output} · {counts['sources']} sources · "
        f"{counts['items']} updates · {counts['unread']} unread · {counts['saved']} saved"
    )
    print(f"Vault content digest: {written_digest} (change detector, not identity proof)")
    print("Readable and matching now; future file survival is not guaranteed · plaintext · offline · no browser-profile read · new-file-only")
    return 0


def cmd_workspace_query(args: argparse.Namespace) -> int:
    _wrapper, state = load_backup(Path(args.backup))
    sources = source_map(state)
    items = matching_items(state, args)
    folder_id, folder_label, _folder_sources = resolve_folder_scope(state, getattr(args, "folder", ""))
    if args.json:
        rows = []
        for item in items[: args.limit]:
            source = sources.get(str(item.get("sourceId")), {})
            row = {
                "id": item.get("id", ""),
                "sourceId": item.get("sourceId", ""),
                "sourceTitle": source.get("title", ""),
                "title": item.get("title", ""),
                "url": item.get("url", ""),
                "summary": item.get("summary", ""),
                "body": item.get("body", "") or item.get("summary", ""),
                "bodyIsSummary": bool(item.get("bodyIsSummary")) or not bool(item.get("body")),
                "bodyOmitted": bool(item.get("bodyOmitted")),
                "language": language_tag(item.get("language") or source.get("language")),
                "titleLanguage": language_tag(item.get("titleLanguage") or item.get("language") or source.get("titleLanguage") or source.get("language")),
                "summaryLanguage": language_tag(item.get("summaryLanguage") or item.get("language") or source.get("language")),
                "bodyLanguage": language_tag(item.get("bodyLanguage") or item.get("language") or source.get("language")),
                "published": item.get("published", ""),
                "observedAt": item.get("observedAt", ""),
                "read": bool(item.get("readAt")),
                "saved": bool(item.get("starred")),
            }
            change = normalized_page_change(item.get("change"))
            if change:
                row["pageChange"] = change
            rows.append(row)
        print(json.dumps({"schema": "progrss.workspace.query.v1", "count": len(items), "items": rows, "folder": {"id": folder_id, "label": folder_label}, "network": False}, ensure_ascii=False, indent=2))
    else:
        if folder_id != "all":
            print(f"Folder: {folder_label}")
        print(f"{len(items)} matching update{'s' if len(items) != 1 else ''}")
        for item in items[: args.limit]:
            source = sources.get(str(item.get("sourceId")), {})
            marker = "★ " if item.get("starred") else ""
            print(f"- {marker}{clean_text(item.get('title'), 240) or 'Untitled update'}")
            print(f"  {clean_text(source.get('title'), 130) or 'Unknown source'} · {item.get('published') or item.get('observedAt') or 'undated'}")
            if item.get("url"):
                print(f"  {item['url']}")
    return 0


def resolve_item_for_reading(state: dict[str, Any], raw: Any) -> dict[str, Any]:
    value = clean_text(raw, 2_048)
    if not value:
        raise ProgRSSError("update selector is empty")
    items = [row for row in state.get("items", []) if isinstance(row, dict)]
    exact = [row for row in items if clean_text(row.get("id"), 700) == value]
    if not exact:
        exact = [row for row in items if clean_text(row.get("url"), 2_048) == value]
    if not exact:
        folded = value.casefold()
        exact = [row for row in items if clean_text(row.get("title"), 240).casefold() == folded]
    if len(exact) > 1:
        choices = ", ".join(clean_text(row.get("id"), 90) for row in exact[:6])
        raise ProgRSSError(f"update selector is ambiguous; use an exact item id: {choices}")
    if not exact:
        raise ProgRSSError(f"update not found: {value}")
    return exact[0]


def cmd_workspace_read(args: argparse.Namespace) -> int:
    _wrapper, state = load_backup(Path(args.backup))
    item = resolve_item_for_reading(state, args.item)
    source = source_map(state).get(clean_text(item.get("sourceId"), 300), {})
    change = normalized_page_change(item.get("change"))
    is_page_change = source.get("type") == "page"
    body = body_text(item.get("body") or item.get("summary"), MAX_ITEM_BODY_CHARS)
    excerpt_only = bool(item.get("bodyIsSummary")) or not bool(item.get("body"))
    report = {
        "schema": "progrss.workspace.reading.v1",
        "id": clean_text(item.get("id"), 700),
        "sourceId": clean_text(item.get("sourceId"), 300),
        "sourceTitle": clean_text(source.get("title"), 180) or "Unknown source",
        "title": clean_text(item.get("title"), 240) or "Untitled update",
        "language": language_tag(item.get("language") or source.get("language")),
        "titleLanguage": language_tag(item.get("titleLanguage") or item.get("language") or source.get("titleLanguage") or source.get("language")),
        "summaryLanguage": language_tag(item.get("summaryLanguage") or item.get("language") or source.get("language")),
        "bodyLanguage": language_tag(item.get("bodyLanguage") or item.get("language") or source.get("language")),
        "summary": clean_text(item.get("summary"), 1_200),
        "body": body,
        "bodyIsSummary": excerpt_only,
        "bodyOmitted": bool(item.get("bodyOmitted")),
        "url": clean_text(item.get("url"), 2_048),
        "published": best_date(item.get("published")) or clean_text(item.get("observedAt"), 100),
        "read": bool(item.get("readAt")),
        "saved": bool(item.get("starred")),
        "network": False,
        "writes": False,
    }
    if is_page_change:
        report["kind"] = "page-change"
        report["pageChange"] = change
        report["reason"] = page_change_reason(change)
        report["policy"] = page_change_policy(change)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    elif is_page_change:
        print(report["title"])
        print(f"{report['sourceTitle']} · {report['published'] or 'undated'}")
        print(report["reason"])
        if report["policy"]:
            print(report["policy"])
        if change:
            before = change.get("before") or change.get("removed")
            after = change.get("after") or change.get("added")
            if before:
                print(f"\nBefore\n{before}")
            if after:
                print(f"\nNow\n{after}")
        else:
            print("\nThis alert predates readable page-change context. Open the watched page to inspect its current state.")
        if report["url"]:
            print(f"\nWatched page: {report['url']}")
        print("\nOffline · no writes")
    else:
        print(report["title"])
        print(f"{report['sourceTitle']} · {report['published'] or 'undated'}")
        if report["bodyOmitted"]:
            print("Summary retained by this source’s offline-text choice; open the original address for the full page.")
        elif excerpt_only:
            print("Feed-supplied excerpt; open the original address for the full page.")
        else:
            print("Feed-supplied text; page scripts and remote media were not loaded.")
        print()
        print(body or "This feed did not supply readable text for the update.")
        if report["url"]:
            print(f"\nOriginal: {report['url']}")
        print("\nOffline · no writes")
    return 0


def cmd_workspace_page_changes(args: argparse.Namespace) -> int:
    _wrapper, state = load_backup(Path(args.backup))
    sources = source_map(state)
    source_term = clean_text(getattr(args, "source", ""), 300).casefold()
    rows: list[dict[str, Any]] = []
    for item in sorted((row for row in state.get("items", []) if isinstance(row, dict)), key=item_sort_key, reverse=True):
        source = sources.get(clean_text(item.get("sourceId"), 300), {})
        if source.get("type") != "page":
            continue
        if getattr(args, "unread_only", False) and item.get("readAt"):
            continue
        if source_term:
            hay = f"{source.get('id', '')} {source.get('title', '')} {source.get('url', '')}".casefold()
            if source_term not in hay:
                continue
        change = normalized_page_change(item.get("change"))
        rows.append({
            "id": clean_text(item.get("id"), 700),
            "sourceId": clean_text(item.get("sourceId"), 300),
            "sourceTitle": clean_text(source.get("title"), 180) or "Unknown page watch",
            "title": clean_text(item.get("title"), 240) or "Page changed",
            "url": clean_text(item.get("url") or source.get("url"), 2_048),
            "observedAt": best_date(item.get("observedAt") or item.get("published")),
            "read": bool(item.get("readAt")),
            "saved": bool(item.get("starred")),
            "legacy": change is None,
            "reason": page_change_reason(change),
            "policy": page_change_policy(change),
            "change": change,
        })
    selected = rows[: args.limit]
    report = {
        "schema": "progrss.workspace.page-changes.v1",
        "count": len(rows),
        "shown": len(selected),
        "changes": selected,
        "network": False,
        "writes": False,
        "browserProfileRead": False,
    }
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0
    print(f"{len(rows)} page change{'s' if len(rows) != 1 else ''}")
    if not selected:
        print("No matching page-watch alerts.")
    for row in selected:
        print(f"\n{row['title']}")
        print(f"{row['sourceTitle']} · {row['observedAt'] or 'undated'} · {'read' if row['read'] else 'unread'}")
        print(row["reason"])
        if row["policy"]:
            print(row["policy"])
        change = row["change"]
        if change:
            before = change.get("before") or change.get("removed")
            after = change.get("after") or change.get("added")
            if before:
                print(f"Before: {before}")
            if after:
                print(f"Now: {after}")
        if row["url"]:
            print(f"Page: {row['url']}")
    print("\nOffline · no writes · no browser-profile read")
    return 0


def opml_bytes(state: dict[str, Any]) -> bytes:
    rows = []
    for source in state["sources"]:
        if not isinstance(source, dict) or source.get("type") != "rss" or source.get("archivedAt"):
            continue
        try:
            url = safe_http_url(source.get("url"))
        except ProgRSSError:
            continue
        title = clean_text(source.get("title") or url, 180)
        rows.append((title, url))
    rows.sort(key=lambda row: (row[0].lower(), row[1]))
    body = ["<?xml version=\"1.0\" encoding=\"UTF-8\"?>", "<opml version=\"2.0\">", "  <head><title>ProgRSS feeds</title></head>", "  <body>"]
    for title, url in rows:
        body.append(f"    <outline type=\"rss\" text=\"{html.escape(title, quote=True)}\" title=\"{html.escape(title, quote=True)}\" xmlUrl=\"{html.escape(url, quote=True)}\"/>")
    body.extend(["  </body>", "</opml>", ""])
    return "\n".join(body).encode("utf-8")


def cmd_workspace_opml(args: argparse.Namespace) -> int:
    _wrapper, state = load_backup(Path(args.backup))
    data = opml_bytes(state)
    write_new(Path(args.output), data)
    print(f"Wrote {args.output} · offline · new-file-only")
    return 0


def json_feed_bytes(state: dict[str, Any], unread_only: bool, starred_only: bool) -> bytes:
    sources = source_map(state)
    items = [row for row in state["items"] if isinstance(row, dict)]
    if unread_only:
        items = [row for row in items if not row.get("readAt")]
    if starred_only:
        items = [row for row in items if row.get("starred")]
    items.sort(key=item_sort_key, reverse=True)
    out_items = []
    for item in items[:250]:
        source = sources.get(str(item.get("sourceId")), {})
        row: dict[str, Any] = {
            "id": clean_text(item.get("id"), 700) or hashlib.sha256(json.dumps(item, sort_keys=True).encode()).hexdigest(),
            "title": clean_text(item.get("title"), 240) or "Untitled update",
            "content_text": body_text(item.get("body") or item.get("summary"), MAX_ITEM_BODY_CHARS),
            "_progrss_source": clean_text(source.get("title"), 180),
        }
        item_language = language_tag(item.get("language") or source.get("language"))
        if item_language:
            row["language"] = item_language
        if item.get("summary"):
            row["summary"] = clean_text(item.get("summary"), 1_200)
        if item.get("url"):
            try:
                row["url"] = safe_http_url(item["url"])
            except ProgRSSError:
                pass
        stamp = best_date(item.get("published") or item.get("observedAt"))
        if stamp:
            row["date_published"] = stamp
        out_items.append(row)
    title = "ProgRSS"
    if unread_only:
        title += " unread"
    if starred_only:
        title += " saved"
    declared_languages = [row.get("language") for row in out_items]
    languages = {value for value in declared_languages if value}
    document: dict[str, Any] = {"version": JSON_FEED_VERSION, "title": title, "items": out_items}
    if out_items and all(declared_languages) and len(languages) == 1:
        document["language"] = next(iter(languages))
    return json_bytes(document)


def cmd_workspace_json_feed(args: argparse.Namespace) -> int:
    _wrapper, state = load_backup(Path(args.backup))
    data = json_feed_bytes(state, args.unread_only, args.starred_only)
    write_new(Path(args.output), data)
    print(f"Wrote {args.output} · offline · new-file-only")
    return 0


def _edition_filter_match(item: dict[str, Any], source: dict[str, Any]) -> bool:
    blob = " ".join((
        clean_text(item.get("title"), 1_000),
        clean_text(item.get("summary"), 1_200),
        body_text(item.get("body"), MAX_ITEM_BODY_CHARS),
    )).casefold()

    def terms(value: Any) -> list[str]:
        return [part.strip().casefold() for part in str(value or "").split(",") if part.strip()]

    needed = terms(source.get("include"))
    excluded = terms(source.get("exclude"))
    return (not needed or any(term in blob for term in needed)) and not any(term in blob for term in excluded)


def _edition_token(value: Any) -> str:
    """Return a stable opaque 64-bit token without exposing local source/item IDs."""
    digest = 14_695_981_039_346_656_037
    for byte in str(value or "").encode("utf-8"):
        digest ^= byte
        digest = (digest * 1_099_511_628_211) & ((1 << 64) - 1)
    return f"{digest:016x}"


def _edition_signature(item: dict[str, Any]) -> str:
    source_id = clean_text(item.get("sourceId"), 300)
    item_id = clean_text(item.get("id"), 700)
    if clean_text(item.get("kind"), 40) in {"changed", "removed"}:
        return f"event:{source_id}:{item_id}"
    raw_url = clean_text(item.get("url"), 2_048)
    if raw_url:
        try:
            return f"url:{safe_http_url(raw_url)}"
        except ProgRSSError:
            pass
    return f"local:{source_id}:{item_id}"


def folder_edition_document(
    state: dict[str, Any],
    folder: Any,
    *,
    limit: int = MAX_FOLDER_EDITION_ITEMS,
    curator: Any = "",
    note: Any = "",
    generated_at: str | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Build one public, summary-only JSON Feed from a simple folder."""
    if not isinstance(limit, int) or not 1 <= limit <= MAX_FOLDER_EDITION_ITEMS:
        raise ProgRSSError(f"edition limit must be between 1 and {MAX_FOLDER_EDITION_ITEMS}")
    folder_id, folder_path, scoped_ids = resolve_folder_scope(state, folder)
    if folder_id in {"all", "unfiled"} or scoped_ids is None:
        raise ProgRSSError("choose an existing simple folder for an edition")

    sources = {
        clean_text(source.get("id"), 300): source
        for source in state.get("sources", [])
        if isinstance(source, dict)
        and clean_text(source.get("id"), 300) in scoped_ids
        and not source.get("archivedAt")
    }
    by_key: dict[str, dict[str, Any]] = {}
    for item in state.get("items", []):
        if not isinstance(item, dict):
            continue
        source_id = clean_text(item.get("sourceId"), 300)
        source = sources.get(source_id)
        if source is None or not _edition_filter_match(item, source):
            continue
        key = _edition_signature(item)
        row = by_key.setdefault(key, {"key": key, "item": item, "witnesses": {}})
        current_stamp = best_date(row["item"].get("published") or row["item"].get("observedAt"))
        candidate_stamp = best_date(item.get("published") or item.get("observedAt"))
        if (candidate_stamp, clean_text(item.get("id"), 700)) > (current_stamp, clean_text(row["item"].get("id"), 700)):
            row["item"] = item
        row["witnesses"][source_id] = source

    rows = sorted(
        by_key.values(),
        key=lambda row: (
            best_date(row["item"].get("published") or row["item"].get("observedAt")),
            row["key"],
        ),
        reverse=True,
    )
    selected = rows[:limit]
    represented: set[str] = set()
    out_items: list[dict[str, Any]] = []
    for row in selected:
        item = row["item"]
        source_id = clean_text(item.get("sourceId"), 300)
        source = sources.get(source_id, {})
        witness_sources = []
        for witness_id, witness in sorted(
            row["witnesses"].items(),
            key=lambda pair: (clean_text(pair[1].get("title"), 130).casefold(), pair[0]),
        ):
            represented.add(witness_id)
            if len(witness_sources) < 8:
                witness_sources.append({
                    "title": clean_text(witness.get("title"), 130) or "Untitled source",
                    "type": "page" if witness.get("type") == "page" else "feed",
                })
        summary = clean_text(
            item.get("summary")
            or (item.get("change") or {}).get("summary")
            or item.get("title"),
            800,
        )
        raw_url = clean_text(item.get("url"), 2_048)
        public_url = ""
        if raw_url:
            try:
                public_url = safe_http_url(raw_url)
            except ProgRSSError:
                public_url = ""
        event_local = clean_text(item.get("kind"), 40) in {"changed", "removed"}
        public_id = public_url if public_url and not event_local else f"urn:progrss:edition:{_edition_token(row['key'])}"
        out: dict[str, Any] = {
            "id": public_id,
            "title": clean_text(item.get("title"), 240) or "Untitled update",
            "content_text": summary or clean_text(item.get("title"), 800) or "Untitled update",
            "_progrss": {
                "sourceCount": len(row["witnesses"]) or 1,
                "sources": witness_sources,
            },
        }
        if summary:
            out["summary"] = summary
        if public_url:
            out["url"] = public_url
        stamp = best_date(item.get("published") or item.get("observedAt"))
        if stamp:
            out["date_published"] = stamp
        item_language = language_tag(item.get("language") or source.get("language"))
        if item_language:
            out["language"] = item_language
        change = item.get("change") if isinstance(item.get("change"), dict) else {}
        change_kind = clean_text(change.get("kind"), 40)
        if change_kind:
            out["_progrss"]["changeKind"] = change_kind
        out_items.append(out)

    generated = best_date(generated_at or utc_now()) or utc_now()
    curator_name = clean_text(curator, 80)
    curation_note = clean_text(note, 280)
    document: dict[str, Any] = {
        "version": JSON_FEED_VERSION,
        "title": f"{folder_path} · recent updates",
        "description": curation_note or f"Recent updates selected from {folder_path}.",
        "user_comment": (
            "Prepared manually from a local ProgRSS folder. Full retained feed text, read and saved state, "
            "page-watch comparison evidence, snapshots, browser permissions, and private keys are not included."
        ),
        "items": out_items,
        "_progrss": {
            "schema": FOLDER_EDITION_SCHEMA,
            "generatedAt": generated,
            "folder": folder_path,
            "folderSourceCount": len(sources),
            "representedSourceCount": len(represented),
            "itemCount": len(out_items),
            "omittedByLimit": max(0, len(rows) - len(out_items)),
            "included": {
                "titles": True,
                "shortSummaries": True,
                "links": True,
                "dates": True,
                "languages": True,
                "sourceLabels": True,
            },
            "excluded": {
                "fullRetainedText": True,
                "readingState": True,
                "savedState": True,
                "pageWatchEvidence": True,
                "snapshots": True,
                "browserAuthority": True,
                "privateKeys": True,
            },
        },
    }
    if curator_name:
        document["authors"] = [{"name": curator_name}]
    declared_languages = [item.get("language") for item in out_items]
    unique_languages = {value for value in declared_languages if value}
    if out_items and all(declared_languages) and len(unique_languages) == 1:
        document["language"] = next(iter(unique_languages))
    data = json_bytes(document)
    if len(data) > MAX_FOLDER_EDITION_BYTES:
        raise ProgRSSError("recent-updates feed exceeds the 250,000-byte public-feed limit")
    summary_report = {
        "schema": FOLDER_EDITION_RESULT_SCHEMA,
        "folderId": folder_id,
        "folder": folder_path,
        "items": len(out_items),
        "sources": len(represented),
        "folderSources": len(sources),
        "omittedByLimit": max(0, len(rows) - len(out_items)),
        "bytes": len(data),
        "fullTextIncluded": False,
        "readingStateIncluded": False,
        "savedStateIncluded": False,
        "pageWatchEvidenceIncluded": False,
        "network": False,
        "writes": False,
    }
    return document, summary_report


def cmd_workspace_edition(args: argparse.Namespace) -> int:
    _wrapper, state = load_backup(Path(args.backup))
    document, report = folder_edition_document(
        state,
        args.folder,
        limit=args.limit,
        curator=args.curator,
        note=args.note,
    )
    output = Path(args.output)
    write_new(output, json_bytes(document))
    result = {**report, "output": str(output), "writes": True, "newFileOnly": True}
    if args.json:
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    else:
        omitted = f" · {report['omittedByLimit']} older omitted" if report["omittedByLimit"] else ""
        print(
            f"Wrote {output} · {report['items']} update{'s' if report['items'] != 1 else ''} · "
            f"{report['sources']} source{'s' if report['sources'] != 1 else ''} represented{omitted} · "
            "summary-only public feed · offline · new-file-only"
        )
    return 0


def cmd_workspace_mark_all_read(args: argparse.Namespace) -> int:
    wrapper, state = load_backup(Path(args.backup))
    result = copy.deepcopy(wrapper)
    result_state = copy.deepcopy(state)
    stamp = utc_now()
    changed = 0
    for item in result_state["items"]:
        if isinstance(item, dict) and not item.get("readAt"):
            item["readAt"] = stamp
            changed += 1
    result["schema"] = BACKUP_SCHEMA
    result["exportedAt"] = stamp
    result["state"] = portable_state(result_state)
    write_new(Path(args.output), json_bytes(result))
    print(f"Marked {changed} update{'s' if changed != 1 else ''} read in new backup {args.output}")
    return 0


def stable_source_id(url: str, state_or_ids: dict[str, Any] | set[str]) -> str:
    stem = "feed-" + hashlib.sha256(url.encode("utf-8")).hexdigest()[:16]
    if isinstance(state_or_ids, set):
        existing = state_or_ids
    else:
        existing = {str(row.get("id")) for row in state_or_ids["sources"] if isinstance(row, dict)}
    candidate = stem
    index = 2
    while candidate in existing:
        candidate = f"{stem}-{index}"
        index += 1
    if isinstance(state_or_ids, set):
        existing.add(candidate)
    return candidate


def ingest_feed(
    state: dict[str, Any], source: dict[str, Any], parsed: dict[str, Any], *, observed_at: str | None = None
) -> int:
    now = best_date(observed_at) or utc_now()
    summaries_only = str(source.get("textRetention") or "").lower() == "summary"
    latest: dict[str, dict[str, Any]] = {}
    for old in state["items"]:
        if not isinstance(old, dict) or old.get("sourceId") != source["id"]:
            continue
        key = str(old.get("entryKey") or old.get("id") or "")
        if key and key not in latest:
            latest[key] = old
    incoming: dict[str, dict[str, Any]] = {}
    for entry in parsed["items"][:250]:
        base = f"{source['id']}|{str(entry.get('key') or entry.get('url') or entry.get('title'))[:500]}"
        if base not in incoming:
            incoming[base] = entry
        else:
            before = best_date(incoming[base].get("published"))
            after = best_date(entry.get("published"))
            if after > before:
                incoming[base] = entry
    language_keys = ("language", "titleLanguage", "summaryLanguage", "bodyLanguage")

    def metadata_for(entry: dict[str, Any], body_omitted: bool = False) -> dict[str, str]:
        metadata = {key: value for key in language_keys if (value := language_tag(entry.get(key)))}
        if body_omitted:
            body_language = metadata.get("summaryLanguage") or metadata.get("language")
            if body_language:
                metadata["bodyLanguage"] = body_language
            else:
                metadata.pop("bodyLanguage", None)
        return metadata

    def apply_metadata(target: dict[str, Any], metadata: dict[str, str]) -> None:
        for key in language_keys:
            if metadata.get(key):
                target[key] = metadata[key]
            else:
                target.pop(key, None)

    events = 0
    existing_ids = {str(row.get("id")) for row in state["items"] if isinstance(row, dict)}
    new_rows: list[dict[str, Any]] = []
    for entry_key, entry in incoming.items():
        title = clean_text(entry.get("title"), 240)
        summary = clean_text(entry.get("summary"), 1_200)
        full_body = body_text(entry.get("body") or entry.get("summary"), MAX_ITEM_BODY_CHARS)
        incoming_is_summary = bool(entry.get("bodyIsSummary")) or not bool(entry.get("body"))
        body_omitted = bool(summaries_only and not incoming_is_summary and full_body)
        body = summary if body_omitted else full_body
        body_is_summary = body_omitted or incoming_is_summary
        metadata = metadata_for(entry, body_omitted)
        link = ""
        if entry.get("url"):
            try:
                link = safe_http_url(entry["url"])
            except ProgRSSError:
                pass
        prior = latest.get(entry_key)
        same_frame = bool(prior) and clean_text(prior.get("title"), 240) == title and clean_text(prior.get("summary"), 1_200) == summary and str(prior.get("url") or "") == link
        if same_frame and "body" not in prior:
            prior["body"] = body
            prior["bodyIsSummary"] = body_is_summary
            if body_omitted:
                prior["bodyOmitted"] = True
            else:
                prior.pop("bodyOmitted", None)
            apply_metadata(prior, metadata)
            continue
        if same_frame and prior.get("bodyOmitted") and not body_omitted and not incoming_is_summary and full_body:
            prior["body"] = full_body
            prior["bodyIsSummary"] = False
            prior.pop("bodyOmitted", None)
            apply_metadata(prior, metadata)
            continue
        if same_frame and summaries_only and not prior.get("bodyOmitted") and not bool(prior.get("bodyIsSummary")):
            apply_metadata(prior, metadata_for(entry, False))
            continue
        if same_frame and body_text(prior.get("body") or prior.get("summary"), MAX_ITEM_BODY_CHARS) == body and bool(prior.get("bodyIsSummary")) == body_is_summary:
            if body_omitted:
                prior["bodyOmitted"] = True
            apply_metadata(prior, metadata)
            continue
        revision = max(0, int(prior.get("feedRevision") or 0)) + 1 if prior else 0
        identity = f"{entry_key}|edit:{revision}" if revision else entry_key
        if identity in existing_ids:
            continue
        row = {
            "id": identity,
            "entryKey": entry_key,
            "feedRevision": revision,
            "sourceId": source["id"],
            "title": title,
            "url": link,
            "summary": summary,
            "body": body,
            "bodyIsSummary": body_is_summary,
            "published": best_date(entry.get("published")),
            "observedAt": now,
            "kind": "changed" if prior else "new",
        }
        if body_omitted:
            row["bodyOmitted"] = True
        row.update(metadata)
        new_rows.append(row)
        existing_ids.add(identity)
        events += 1
    state["items"] = (list(reversed(new_rows)) + state["items"])[:MAX_ITEMS]
    return events


def stable_collection_id(path: tuple[str, ...], occupied: set[str]) -> str:
    digest = hashlib.sha256("\x1f".join(path).encode("utf-8")).hexdigest()[:18]
    candidate = f"collection-opml-{digest}"
    suffix = 2
    while candidate in occupied:
        candidate = f"collection-opml-{digest}-{suffix}"
        suffix += 1
    occupied.add(candidate)
    return candidate


def build_opml_collections(
    feeds: list[dict[str, Any]],
    source_by_url: dict[str, dict[str, Any]],
    state: dict[str, Any],
    stamp: str,
) -> list[dict[str, Any]]:
    occupied = {
        clean_text(row.get("id"), 300)
        for group in (state["sources"], state["collections"])
        for row in group
        if isinstance(row, dict) and row.get("id")
    }
    nodes: dict[tuple[str, ...], dict[str, Any]] = {}

    def add_member(collection: dict[str, Any], member: dict[str, str]) -> None:
        if member not in collection["members"]:
            collection["members"].append(member)

    def node_for(path: tuple[str, ...]) -> dict[str, Any]:
        node = nodes.get(path)
        if node is not None:
            return node
        node = {
            "id": stable_collection_id(path, occupied),
            "title": path[-1],
            "mode": "union",
            "include": "",
            "exclude": "",
            "version": 1,
            "author": "OPML import",
            "members": [],
            "origin": "cli-opml-import",
            "createdAt": stamp,
        }
        nodes[path] = node
        if len(path) > 1:
            add_member(node_for(path[:-1]), {"kind": "collection", "id": node["id"]})
        return node

    for feed in feeds:
        source = source_by_url.get(safe_http_url(feed["url"]))
        if source is None:
            continue
        for raw_path in feed.get("folderPaths", []):
            path = tuple(clean_text(part, 130) for part in raw_path if clean_text(part, 130))[:12]
            if path:
                add_member(node_for(path), {"kind": "source", "id": source["id"]})
    return list(nodes.values())


def cmd_workspace_import_opml(args: argparse.Namespace) -> int:
    wrapper, state = load_backup(Path(args.backup))
    raw = read_limited(Path(args.opml), MAX_OPML_BYTES, "OPML file")
    parsed = parse_opml(raw)
    if parsed["truncatedCount"]:
        raise ProgRSSError(
            f"OPML contains more than {MAX_OPML_FEEDS} unique feeds; split it into smaller files before importing"
        )

    existing_urls: set[str] = set()
    for source in state["sources"]:
        if not isinstance(source, dict) or source.get("type") != "rss":
            continue
        existing_urls.update(source_address_aliases(source))
    new_feeds = [feed for feed in parsed["feeds"] if feed["url"] not in existing_urls]
    existing_count = len(parsed["feeds"]) - len(new_feeds)
    if not new_feeds:
        raise ProgRSSError("every valid feed in this OPML file is already in the backup")
    if len(state["sources"]) + len(new_feeds) > MAX_SOURCES:
        room = max(0, MAX_SOURCES - len(state["sources"]))
        raise ProgRSSError(f"backup has room for {room} more sources, but this file would add {len(new_feeds)}")

    folder_paths: set[tuple[str, ...]] = set()
    for feed in new_feeds:
        for raw_path in feed.get("folderPaths", []):
            path = tuple(clean_text(part, 130) for part in raw_path if clean_text(part, 130))[:12]
            for index in range(1, len(path) + 1):
                folder_paths.add(path[:index])
    if len(state["collections"]) + len(folder_paths) > MAX_COLLECTIONS:
        room = max(0, MAX_COLLECTIONS - len(state["collections"]))
        raise ProgRSSError(f"backup has room for {room} more folders, but this file would add {len(folder_paths)}")

    result_wrapper = copy.deepcopy(wrapper)
    result_state = result_wrapper["state"]
    stamp = utc_now()
    occupied = {
        clean_text(source.get("id"), 300)
        for source in result_state["sources"]
        if isinstance(source, dict) and source.get("id")
    }
    source_by_url: dict[str, dict[str, Any]] = {}
    for feed in new_feeds:
        url = safe_http_url(feed["url"])
        source = {
            "id": stable_source_id(url, occupied),
            "title": clean_text(feed.get("title"), 180) or urllib.parse.urlsplit(url).hostname or "Imported feed",
            "type": "rss",
            "url": url,
            "mode": "region",
            "selector": "",
            "titleSelector": "",
            "linkSelector": "",
            "include": "",
            "exclude": "",
            "threshold": 1,
            "ignoreNumbers": False,
            "enabled": bool(args.active),
            "archivedAt": "",
            "version": 1,
            "author": "OPML import",
            "origin": "cli-opml-import",
            "createdAt": stamp,
            "importedAt": stamp,
            "lastScan": "",
            "lastError": "",
            "lastSuccessfulAt": "",
            "lastNewAt": "",
            "lastProblemAt": "",
            "lastProblem": "",
        }
        result_state["sources"].append(source)
        source_by_url[url] = source

    collections = build_opml_collections(new_feeds, source_by_url, result_state, stamp)
    result_state["collections"].extend(collections)
    result_state["updatedAt"] = stamp
    result_wrapper["state"] = portable_state(result_state)
    result_wrapper["exportedAt"] = stamp
    write_new(Path(args.output), json_bytes(result_wrapper))

    skipped = existing_count + parsed["duplicateCount"] + parsed["invalidCount"]
    mode = "active" if args.active else "paused"
    note = "; browser site access is still granted per site" if args.active else ""
    print(
        f"Imported {len(new_feeds)} feed{'s' if len(new_feeds) != 1 else ''} {mode} "
        f"and kept {len(collections)} folder{'s' if len(collections) != 1 else ''}; "
        f"skipped {skipped}. No network access{note}. Wrote {args.output}"
    )
    return 0

def cmd_workspace_ingest(args: argparse.Namespace) -> int:
    wrapper, state = load_backup(Path(args.backup))
    result = copy.deepcopy(wrapper)
    result_state = copy.deepcopy(state)
    url = safe_http_url(args.url)
    raw = read_limited(Path(args.feed), MAX_FEED_BYTES, "feed")
    parsed = parse_feed(raw, url)
    declared_feed_url = same_origin_feed_url(parsed.get("feedUrl"), url)
    incoming_aliases = {url}
    if declared_feed_url:
        incoming_aliases.add(declared_feed_url)
    source = None
    for row in result_state["sources"]:
        if not isinstance(row, dict) or row.get("type") != "rss":
            continue
        if source_address_aliases(row) & incoming_aliases:
            source = row
            break
    created = False
    if source is None:
        if len(result_state["sources"]) >= MAX_SOURCES:
            raise ProgRSSError("source limit reached")
        source = {
            "id": stable_source_id(url, result_state),
            "title": clean_text(args.title or parsed["title"] or urllib.parse.urlsplit(url).hostname, 130),
            "type": "rss",
            "url": url,
            "mode": "region",
            "selector": "",
            "titleSelector": "",
            "linkSelector": "",
            "include": "",
            "exclude": "",
            "threshold": 1,
            "ignoreNumbers": False,
            "author": "local CLI",
            "version": 1,
            "enabled": True,
            "origin": "cli-offline-ingest",
            "createdAt": utc_now(),
            "lastScan": "",
            "lastError": "",
            "lastSuccessfulAt": "",
            "lastNewAt": "",
            "lastProblemAt": "",
            "lastProblem": "",
        }
        result_state["sources"].append(source)
        created = True
    elif source.get("url"):
        try:
            old_url = safe_http_url(source.get("url"))
        except ProgRSSError:
            old_url = ""
        if old_url and old_url != url and url_origin(old_url) == url_origin(url):
            previous = [value for value in source.get("previousUrls", []) if isinstance(value, str)] if isinstance(source.get("previousUrls"), list) else []
            if old_url not in previous:
                previous.append(old_url)
            source["previousUrls"] = previous[-4:]
            source["url"] = url
            source["httpCache"] = {}
    stamp = utc_now()
    source["enabled"] = True
    source["archivedAt"] = ""
    source["lastScan"] = stamp
    source["lastSuccessfulAt"] = stamp
    source["lastError"] = ""
    source["lastOutcome"] = "offline-ingest"
    if declared_feed_url:
        source["declaredFeedUrl"] = declared_feed_url
    parsed_language = language_tag(parsed.get("language"))
    parsed_title_language = language_tag(parsed.get("titleLanguage")) or parsed_language
    if parsed_language:
        source["language"] = parsed_language
    else:
        source.pop("language", None)
    if parsed_title_language:
        source["titleLanguage"] = parsed_title_language
    else:
        source.pop("titleLanguage", None)
    events = ingest_feed(result_state, source, parsed)
    source["lastItems"] = events
    if events:
        source["lastNewAt"] = stamp
    source["checkCount"] = int(source.get("checkCount") or 0) + 1
    if (not source.get("title") or source.get("title") == "New feed") and parsed["title"]:
        source["title"] = parsed["title"]
    result["schema"] = BACKUP_SCHEMA
    result["exportedAt"] = utc_now()
    result["state"] = portable_state(result_state)
    write_new(Path(args.output), json_bytes(result))
    print(f"{'Added source and i' if created else 'I'}ngested {events} event{'s' if events != 1 else ''} into new backup {args.output} · offline")
    return 0



def corpus_case_result(directory: Path, case: dict[str, Any]) -> dict[str, Any]:
    identity = clean_text(case.get("id"), 120) or "unnamed"
    relative = case.get("file")
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute() or ".." in Path(relative).parts:
        return {"id": identity, "passed": False, "reason": "unsafe fixture path"}
    path = directory / relative
    expected = case.get("expected") if isinstance(case.get("expected"), dict) else {}
    try:
        raw = read_limited(path, MAX_FEED_BYTES, "corpus fixture")
        parsed = parse_feed(raw, clean_text(case.get("origin"), 2_048))
        entries = parsed.get("items", [])
        first = entries[0] if entries else {}
        replay_state = {"items": []}
        replay_source = {"id": "corpus-source"}
        ingest_events = ingest_feed(replay_state, replay_source, parsed)
        actual = {
            "ok": True,
            "type": parsed.get("type"),
            "title": parsed.get("title"),
            "feedUrl": parsed.get("feedUrl", ""),
            "language": parsed.get("language", ""),
            "titleLanguage": parsed.get("titleLanguage", ""),
            "itemCount": len(entries),
            "firstTitle": first.get("title", ""),
            "firstUrl": first.get("url", ""),
            "firstSummary": first.get("summary", ""),
            "firstBody": first.get("body", ""),
            "firstBodyIsSummary": bool(first.get("bodyIsSummary")),
            "firstLanguage": first.get("language", ""),
            "firstTitleLanguage": first.get("titleLanguage", ""),
            "firstSummaryLanguage": first.get("summaryLanguage", ""),
            "firstBodyLanguage": first.get("bodyLanguage", ""),
            "firstKey": first.get("key", ""),
            "firstPublished": first.get("published", ""),
            "uniqueKeyCount": len({str(entry.get("key") or "") for entry in entries}),
            "ingestEventCount": ingest_events,
            "ingestedTitle": replay_state["items"][0].get("title", "") if replay_state["items"] else "",
            "ingestedUrl": replay_state["items"][0].get("url", "") if replay_state["items"] else "",
        }
        problems: list[str] = []
        if expected.get("ok") is False:
            problems.append("expected refusal but parsing succeeded")
        for key in ("type", "title", "feedUrl", "language", "titleLanguage", "itemCount", "firstTitle", "firstUrl", "firstBody", "firstBodyIsSummary", "firstLanguage", "firstTitleLanguage", "firstSummaryLanguage", "firstBodyLanguage", "firstKey", "uniqueKeyCount", "ingestEventCount", "ingestedTitle", "ingestedUrl"):
            if key in expected and actual.get(key) != expected.get(key):
                problems.append(f"{key}: expected {expected.get(key)!r}, got {actual.get(key)!r}")
        needle = clean_text(expected.get("firstSummaryIncludes"), 500).casefold()
        if needle and needle not in clean_text(actual.get("firstSummary"), 1_200).casefold():
            problems.append(f"first summary did not contain {expected.get('firstSummaryIncludes')!r}")
        body_needle = clean_text(expected.get("firstBodyIncludes"), 500).casefold()
        if body_needle and body_needle not in body_text(actual.get("firstBody"), MAX_ITEM_BODY_CHARS).casefold():
            problems.append(f"first body did not contain {expected.get('firstBodyIncludes')!r}")
        for excluded in expected.get("firstBodyExcludes", []) if isinstance(expected.get("firstBodyExcludes"), list) else []:
            excluded_text = clean_text(excluded, 500).casefold()
            if excluded_text and excluded_text in body_text(actual.get("firstBody"), MAX_ITEM_BODY_CHARS).casefold():
                problems.append(f"first body unexpectedly contained {excluded!r}")
        published_prefix = clean_text(expected.get("firstPublishedStartsWith"), 100)
        if published_prefix and not str(actual.get("firstPublished") or "").startswith(published_prefix):
            problems.append(f"first published time did not start with {published_prefix!r}: {actual.get('firstPublished')!r}")
        return {"id": identity, "passed": not problems, "reason": "; ".join(problems), "actual": actual}
    except (ProgRSSError, OSError, UnicodeError, json.JSONDecodeError) as exc:
        message = clean_text(exc, 500)
        if expected.get("ok") is False:
            needle = clean_text(expected.get("errorIncludes"), 200).casefold()
            passed = not needle or needle in message.casefold()
            reason = "" if passed else f"refusal did not contain {expected.get('errorIncludes')!r}: {message}"
            return {"id": identity, "passed": passed, "reason": reason, "actual": {"ok": False, "error": message}}
        return {"id": identity, "passed": False, "reason": message, "actual": {"ok": False, "error": message}}


def run_corpus(directory: Path) -> dict[str, Any]:
    manifest_path = directory / "corpus.json"
    manifest = load_json_bytes(read_limited(manifest_path, 1_000_000, "corpus manifest"), str(manifest_path))
    if not isinstance(manifest, dict) or manifest.get("schema") != CORPUS_SCHEMA:
        raise ProgRSSError("not a ProgRSS feed corpus")
    cases = manifest.get("cases")
    if not isinstance(cases, list) or not cases or len(cases) > MAX_CORPUS_CASES:
        raise ProgRSSError(f"corpus must contain 1 to {MAX_CORPUS_CASES} cases")
    results = [corpus_case_result(directory, case) if isinstance(case, dict) else {"id": "unnamed", "passed": False, "reason": "case is not an object"} for case in cases]
    passed = sum(1 for row in results if row.get("passed"))
    return {
        "schema": "progrss.feed.corpus.result.v1",
        "title": clean_text(manifest.get("title"), 180) or "Feed corpus",
        "directory": str(directory),
        "total": len(results),
        "passed": passed,
        "failed": len(results) - passed,
        "cases": results,
        "network": False,
        "writes": False,
    }


def cmd_feed_corpus(args: argparse.Namespace) -> int:
    report = run_corpus(Path(args.directory).resolve())
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print(f"{report['title']}: {report['passed']}/{report['total']} cases passed · offline · no writes")
        for row in report["cases"]:
            marker = "PASS" if row["passed"] else "FAIL"
            detail = f" — {row['reason']}" if row.get("reason") else ""
            print(f"{marker}  {row['id']}{detail}")
    return 0 if report["failed"] == 0 else 2


def cmd_legacy(args: argparse.Namespace) -> int:
    if not LEGACY.is_file():
        raise ProgRSSError(f"legacy carrier is missing: {LEGACY}")
    passthrough = list(args.arguments)
    if passthrough and passthrough[0] == "--":
        passthrough = passthrough[1:]
    completed = subprocess.run(["bash", str(LEGACY), *passthrough], check=False)
    return completed.returncode


def cmd_relay_bundle_inspect(args: argparse.Namespace) -> int:
    argv = ["bundle", "inspect", str(args.file)]
    if args.json:
        argv.append("--json")
    result = run_relay_cli(argv)
    return int(result if result is not None else 1)




def cmd_relay_bundle_contents(args: argparse.Namespace) -> int:
    argv = ["bundle", "contents", str(args.file), "--limit", str(args.limit)]
    if args.json:
        argv.append("--json")
    result = run_relay_cli(argv)
    return int(result if result is not None else 1)


def cmd_relay_bundle_verify(args: argparse.Namespace) -> int:
    argv = ["bundle", "verify", str(args.file)]
    if args.require_signature:
        argv.append("--require-signature")
    if args.json:
        argv.append("--json")
    result = run_relay_cli(argv)
    return int(result if result is not None else 1)


def cmd_relay_bundle_site(args: argparse.Namespace) -> int:
    argv = ["bundle", "site", str(args.file), "--output", str(args.output)]
    if args.edition:
        argv.extend(["--edition", str(args.edition)])
    if args.json:
        argv.append("--json")
    result = run_relay_cli(argv)
    return int(result if result is not None else 1)


def cmd_relay_bundle_fetch(args: argparse.Namespace) -> int:
    argv = ["bundle", "fetch", str(args.url)]
    if args.output:
        argv.extend(["--output", str(args.output)])
    if args.json:
        argv.append("--json")
    result = run_relay_cli(argv)
    return int(result if result is not None else 1)


def cmd_relay_bundle_from_page(args: argparse.Namespace) -> int:
    argv = ["bundle", "from-page", str(args.url)]
    if args.output:
        argv.extend(["--output", str(args.output)])
    if args.json:
        argv.append("--json")
    result = run_relay_cli(argv)
    return int(result if result is not None else 1)


def cmd_relay_bundle_check_page(args: argparse.Namespace) -> int:
    argv = ["bundle", "check-page", str(args.url)]
    if args.require_updates:
        argv.append("--require-updates")
    if args.json:
        argv.append("--json")
    result = run_relay_cli(argv)
    return int(result if result is not None else 1)


def cmd_relay_share_folder(args: argparse.Namespace) -> int:
    argv = [
        "workspace", "share-folder", str(args.backup), str(args.folder),
        "--output", str(args.output), "--format", str(args.format),
    ]
    if args.curator:
        argv.extend(["--curator", str(args.curator)])
    if args.note:
        argv.extend(["--note", str(args.note)])
    if args.update_url is not None:
        argv.extend(["--update-url", str(args.update_url)] if args.update_url else ["--without-update-url"])
    if args.json:
        argv.append("--json")
    result = run_relay_cli(argv)
    return int(result if result is not None else 1)


def cmd_relay_publish_folder(args: argparse.Namespace) -> int:
    argv = [
        "workspace", "publish-folder", str(args.backup), str(args.folder),
        "--update-url", str(args.update_url), "--output", str(args.output),
    ]
    if args.curator:
        argv.extend(["--curator", str(args.curator)])
    if args.note:
        argv.extend(["--note", str(args.note)])
    if args.json:
        argv.append("--json")
    if not args.include_updates:
        result = run_relay_cli(argv)
        return int(result if result is not None else 1)

    _wrapper, state = load_backup(Path(args.backup))
    edition, _report = folder_edition_document(
        state,
        args.folder,
        limit=args.update_limit,
        curator=args.curator,
        note=args.note,
    )
    with tempfile.TemporaryDirectory(prefix="progrss-edition-") as directory:
        edition_path = Path(directory) / "recent-updates.json"
        edition_path.write_bytes(json_bytes(edition))
        argv.extend(["--edition", str(edition_path)])
        result = run_relay_cli(argv)
    return int(result if result is not None else 1)


def cmd_relay_import_bundle(args: argparse.Namespace) -> int:
    argv = [
        "workspace", "import-bundle", str(args.backup), str(args.bundle),
        "--output", str(args.output),
    ]
    if args.folder:
        argv.extend(["--folder", str(args.folder)])
    if args.json:
        argv.append("--json")
    result = run_relay_cli(argv)
    return int(result if result is not None else 1)


def cmd_relay_review_bundle(args: argparse.Namespace) -> int:
    argv = ["workspace", "review-bundle", str(args.backup), str(args.bundle)]
    if args.folder:
        argv.extend(["--folder", str(args.folder)])
    if args.json:
        argv.append("--json")
    result = run_relay_cli(argv)
    return int(result if result is not None else 1)


def cmd_relay_check_publication(args: argparse.Namespace) -> int:
    argv = ["workspace", "check-publication", str(args.backup), str(args.folder)]
    if args.output:
        argv.extend(["--output", str(args.output)])
    if args.json:
        argv.append("--json")
    result = run_relay_cli(argv)
    return int(result if result is not None else 1)


def cmd_relay_update_bundle(args: argparse.Namespace) -> int:
    argv = [
        "workspace", "update-bundle", str(args.backup), str(args.bundle),
        "--output", str(args.output),
    ]
    if args.folder:
        argv.extend(["--folder", str(args.folder)])
    if args.accept_trust_change:
        argv.append("--accept-trust-change")
    if args.json:
        argv.append("--json")
    result = run_relay_cli(argv)
    return int(result if result is not None else 1)


def add_query_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--source", default="", help="source id, title, or URL substring")
    parser.add_argument("--contains", default="", help="case-insensitive source/title/summary substring")
    parser.add_argument("--folder", default="", help="simple folder id, title, full path, or unfiled")
    parser.add_argument("--unread-only", action="store_true", help="include only unread updates")
    parser.add_argument("--starred-only", action="store_true", help="include only saved updates")
    parser.add_argument("--limit", type=int, default=50, choices=range(1, 251), metavar="1..250")
    parser.add_argument("--json", action="store_true", help="emit machine-readable JSON")


def cmd_node_init(args: argparse.Namespace) -> int:
    """Create one transactional Node-owned library from an explicit private backup."""
    try:
        from node_store import NodeStore, NodeStoreError
        result = NodeStore.create_from_backup(args.backup, args.output)
    except NodeStoreError as exc:
        raise ProgRSSError(str(exc)) from exc
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("Created ProgRSS Node-owned library")
        print(f"  File: {args.output}")
        print(f"  Imported: {result['import']['file']} · {result['import']['sha256']}")
        print(f"  Revision: {result['library']['revision']} · {result['library']['sources']} sources")
        print("  Original import bytes preserved inside the store.")
        print("  Network: none")
    return 0


def cmd_node_serve(args: argparse.Namespace) -> int:
    """Serve one explicit exported backup or transactional Node-owned library."""
    try:
        from node_server import NodeError, serve
        return serve(args.library, port=args.port, open_browser=bool(args.open), json_ready=bool(args.json))
    except NodeError as exc:
        raise ProgRSSError(str(exc)) from exc


def cmd_node_export(args: argparse.Namespace) -> int:
    """Export the current portable private backup from a Node-owned library."""
    try:
        from node_store import NodeStore, NodeStoreError
        result = NodeStore(args.store).export_current(args.output)
    except NodeStoreError as exc:
        raise ProgRSSError(str(exc)) from exc
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"Exported revision {result['revision']} to {args.output}")
        print(f"SHA-256: {result['sha256']}")
        print("Network: none")
    return 0


def cmd_node_receipts(args: argparse.Namespace) -> int:
    """List durable reviewed-operation receipts without changing the store."""
    try:
        from node_store import NodeStore, NodeStoreError, OPERATION_RESULT_SCHEMA
        store = NodeStore(args.store)
        receipts = store.list_receipts(limit=args.limit)
    except NodeStoreError as exc:
        raise ProgRSSError(str(exc)) from exc
    result = {
        "schema": OPERATION_RESULT_SCHEMA,
        "state": "receipt-list",
        "store": args.store.name,
        "count": len(receipts),
        "operations": receipts,
        "network": False,
        "libraryWrites": False,
        "storeMigrated": bool(store.migrated),
        "writes": bool(store.migrated),
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif not receipts:
        print("No reviewed Node operations have committed.")
        if store.migrated:
            print("Store schema upgraded to progrss.node-store.v4; portable library bytes were unchanged.")
    else:
        print(f"Reviewed Node operations · {len(receipts)}")
        for receipt in receipts:
            summary = receipt.get("summary") if isinstance(receipt.get("summary"), dict) else {}
            selection = receipt.get("selection") if isinstance(receipt.get("selection"), dict) else {}
            print(
                f"- {receipt.get('committedAt', '')} · {receipt.get('operationType', '')} · "
                f"{selection.get('folderPath', 'selected branch')} · "
                f"{summary.get('newSources', 0)} new / {summary.get('reusedSources', 0)} reused"
            )
            print(f"  Operation: {receipt.get('operationId', '')}")
            print(f"  Result: {receipt.get('resultLibrarySha256', '')}")
            rollback = receipt.get("rollbackEvidence") if isinstance(receipt.get("rollbackEvidence"), dict) else {}
            print(f"  Before snapshot: {rollback.get('snapshotId', '')}")
        if store.migrated:
            print("Store schema upgraded to progrss.node-store.v4; portable library bytes were unchanged.")
    return 0



def cmd_node_acquisitions(args: argparse.Namespace) -> int:
    """List acquisition evidence without network or portable-library changes."""
    try:
        from node_store import NodeStore, NodeStoreError, ACQUISITION_RESULT_SCHEMA
        store = NodeStore(args.store)
        receipts = store.list_acquisition_receipts(limit=args.limit)
        jobs = store.list_acquisition_jobs(limit=args.limit)
    except NodeStoreError as exc:
        raise ProgRSSError(str(exc)) from exc
    result = {
        "schema": ACQUISITION_RESULT_SCHEMA,
        "state": "acquisition-list",
        "store": args.store.name,
        "receiptCount": len(receipts),
        "interruptedCount": sum(1 for row in jobs if row.get("state") == "started"),
        "receipts": receipts,
        "jobs": jobs,
        "network": False,
        "libraryWrites": False,
        "storeMigrated": bool(store.migrated),
        "writes": bool(store.migrated),
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif not receipts and not jobs:
        print("No Node acquisition attempt has been recorded.")
        if store.migrated:
            print("Store schema upgraded to progrss.node-store.v4; portable library bytes were unchanged.")
    else:
        print(f"Node acquisition receipts · {len(receipts)}")
        for receipt in receipts:
            request = receipt.get("request") if isinstance(receipt.get("request"), dict) else {}
            summary = receipt.get("summary") if isinstance(receipt.get("summary"), dict) else {}
            print(
                f"- {receipt.get('committedAt', '')} · {request.get('sourceTitle', receipt.get('sourceId', 'source'))} · "
                f"{receipt.get('outcome', 'unknown')} · {summary.get('itemsAdded', 0)} new"
            )
            print(f"  Operation: {receipt.get('operationId', '')}")
            print(f"  Requests: {(receipt.get('effects') or {}).get('networkRequests', 0)}")
            selection_level = request.get("selectionLevel")
            selection_summary = request.get("selectionSummary")
            if selection_level or selection_summary:
                detail = " · ".join(value for value in (str(selection_level or "section evidence"), str(selection_summary or "")) if value)
                print(f"  Section evidence: {detail}")
            print(f"  Result: {receipt.get('resultLibrarySha256', '')}")
        interrupted = [row for row in jobs if row.get("state") == "started"]
        if interrupted:
            print(f"Interrupted acquisition intents · {len(interrupted)}")
            for row in interrupted:
                print(f"- {row.get('startedAt', '')} · {row.get('operationId', '')} · attempt {row.get('attemptCount', 1)}")
        print("Network: none")
        print("Portable library writes: none")
        if store.migrated:
            print("Internal store-schema migration: completed")
    return 0


def cmd_node_fieldbook(args: argparse.Namespace) -> int:
    """Create one private local facilitator sheet from a read-only Trace review."""
    try:
        from fieldbook import FIELDWORK_KIT_SCHEMA
        from node_server import NodeState
        from node_store import NodeStore, NodeStoreError
        store = NodeStore(args.store)
        node = NodeState(backup=args.store, token="offline-fieldbook", store=store)
        _suggested_name, body, scenario = node.fieldbook(args.source_id)
        write_new(args.output, body)
    except (NodeStoreError, ValueError) as exc:
        raise ProgRSSError(str(exc)) from exc
    result = {
        "schema": FIELDWORK_KIT_SCHEMA,
        "state": "written",
        "file": str(args.output),
        "bytes": len(body),
        "scenario": scenario.get("scenario"),
        "scenarioDigest": scenario.get("scenarioDigest"),
        "tasks": len(scenario.get("tasks", [])),
        "network": False,
        "libraryWrites": False,
        "storeMigrated": bool(store.migrated),
        "storeWrites": bool(store.migrated),
        "automaticPersistence": False,
        "telemetry": False,
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"Wrote private ProgRSS Fieldbook to {args.output}")
        print(f"Scenario: {result['scenario']} · {result['tasks']} tasks · {result['scenarioDigest']}")
        print("Participant identity: not requested")
        print("Telemetry: none")
        print("Network: none")
        print("Node library writes: none")
        if store.migrated:
            print("Internal store-schema migration: completed; portable library bytes unchanged")
    return 0


def cmd_node_exchange_fieldbook(args: argparse.Namespace) -> int:
    """Create one private recipient-study sheet from an Exchange review document."""
    try:
        from fieldbook import (
            FIELDWORK_KIT_SCHEMA, FieldbookError,
            build_exchange_fieldwork_scenario, render_fieldbook_html,
        )
        review = load_json_bytes(
            read_limited(args.review, MAX_FEED_BYTES, "Exchange review"),
            "Exchange review",
        )
        generated_at = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
        scenario = build_exchange_fieldwork_scenario(
            review, version=VERSION, revision=REVISION, codename=CODENAME, generated_at=generated_at,
        )
        body = render_fieldbook_html(scenario)
        write_new(args.output, body)
    except FieldbookError as exc:
        raise ProgRSSError(str(exc)) from exc
    result = {
        "schema": FIELDWORK_KIT_SCHEMA,
        "state": "written",
        "file": str(args.output),
        "bytes": len(body),
        "scenario": scenario.get("scenario"),
        "scenarioDigest": scenario.get("scenarioDigest"),
        "tasks": len(scenario.get("tasks", [])),
        "network": False,
        "libraryWrites": False,
        "storeWrites": False,
        "automaticPersistence": False,
        "telemetry": False,
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"Wrote private ProgRSS Exchange Fieldbook to {args.output}")
        print(f"Scenario: {result['scenario']} · {result['tasks']} tasks · {result['scenarioDigest']}")
        print("Curator and route identity in Fieldbook: excluded")
        print("Invitation capability in Fieldbook: excluded")
        print("Telemetry: none")
        print("Network: none")
        print("Node library writes: none")
    return 0


def cmd_node_exchange_sender_fieldbook(args: argparse.Namespace) -> int:
    """Create one private sender-study sheet from an Exchange preview document."""
    try:
        from fieldbook import (
            FIELDWORK_KIT_SCHEMA, FieldbookError,
            build_exchange_sender_fieldwork_scenario, render_fieldbook_html,
        )
        preview = load_json_bytes(
            read_limited(args.preview, MAX_FEED_BYTES, "Exchange preview"),
            "Exchange preview",
        )
        generated_at = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
        scenario = build_exchange_sender_fieldwork_scenario(
            preview, version=VERSION, revision=REVISION, codename=CODENAME, generated_at=generated_at,
        )
        body = render_fieldbook_html(scenario)
        write_new(args.output, body)
    except FieldbookError as exc:
        raise ProgRSSError(str(exc)) from exc
    result = {
        "schema": FIELDWORK_KIT_SCHEMA,
        "state": "written",
        "file": str(args.output),
        "bytes": len(body),
        "scenario": scenario.get("scenario"),
        "scenarioDigest": scenario.get("scenarioDigest"),
        "tasks": len(scenario.get("tasks", [])),
        "network": False,
        "libraryWrites": False,
        "storeWrites": False,
        "automaticPersistence": False,
        "telemetry": False,
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"Wrote private ProgRSS sender Fieldbook to {args.output}")
        print(f"Scenario: {result['scenario']} · {result['tasks']} tasks · {result['scenarioDigest']}")
        print("Route, curator, source, public-address, and library identity in Fieldbook: excluded")
        print("Preview capability and artifact digests in Fieldbook: excluded")
        print("Telemetry: none")
        print("Network: none")
        print("Node library writes: none")
    return 0


def cmd_node_roadcase(args: argparse.Namespace) -> int:
    """Build one deterministic native-fieldwork Roadcase packet."""
    try:
        from roadcase import RoadcaseError, build_roadcase_packet
        release_root = args.release_root if args.release_root is not None else ROOT.parent
        result = build_roadcase_packet(
            release_root, args.output, version=VERSION, revision=REVISION, codename=CODENAME,
        )
    except RoadcaseError as exc:
        raise ProgRSSError(str(exc)) from exc
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"Wrote ProgRSS Roadcase packet to {args.output}")
        print(f"Release: {VERSION} · {REVISION} · {CODENAME}")
        print(f"Immutable files: {result['manifestFiles']} · {result['immutableBytes']:,} bytes")
        print(f"Packet SHA-256: {result['sha256']}")
        print("Native sessions performed: no")
        print("Human sessions performed: no")
        print("Telemetry: none")
        print("Network during build: none")
    return 0


def cmd_node_debrief(args: argparse.Namespace) -> int:
    """Create one private local workspace for comparing Fieldbook reports."""
    try:
        from debrief import (
            DEBRIEF_KIT_SCHEMA, MAX_DEBRIEF_REPORTS, MAX_DEBRIEF_REPORT_BYTES,
            MAX_DEBRIEF_TOTAL_BYTES, DebriefError, build_debrief_workspace, render_debrief_html,
        )
        if len(args.reports) > MAX_DEBRIEF_REPORTS:
            raise ProgRSSError(f"at most {MAX_DEBRIEF_REPORTS} reports may be preloaded")
        reports: list[Any] = []
        total = 0
        for index, path in enumerate(args.reports, start=1):
            raw = read_limited(path, MAX_DEBRIEF_REPORT_BYTES, f"fieldwork report {index}")
            total += len(raw)
            if total > MAX_DEBRIEF_TOTAL_BYTES:
                raise ProgRSSError(f"fieldwork reports exceed the {MAX_DEBRIEF_TOTAL_BYTES:,}-byte total limit")
            reports.append(load_json_bytes(raw, f"fieldwork report {index}"))
        generated_at = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
        workspace = build_debrief_workspace(
            reports, version=VERSION, revision=REVISION, codename=CODENAME, generated_at=generated_at,
        )
        body = render_debrief_html(workspace)
        write_new(args.output, body)
    except DebriefError as exc:
        raise ProgRSSError(str(exc)) from exc
    result = {
        "schema": DEBRIEF_KIT_SCHEMA,
        "state": "written",
        "file": str(args.output),
        "bytes": len(body),
        "preloadedReports": len(workspace.get("preloadedReports", [])),
        "duplicatesRemoved": int(workspace.get("duplicatesRemoved", 0)),
        "network": False,
        "libraryWrites": False,
        "storeWrites": False,
        "automaticPersistence": False,
        "telemetry": False,
        "participantScore": False,
        "rawNotesExported": False,
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"Wrote private ProgRSS Debrief workspace to {args.output}")
        print(f"Preloaded reports: {result['preloadedReports']} · duplicates removed: {result['duplicatesRemoved']}")
        print("Participant score: none")
        print("Raw facilitator notes in debrief export: none")
        print("Telemetry: none")
        print("Network: none")
        print("Node library writes: none")
    return 0


def cmd_node_snapshot(args: argparse.Namespace) -> int:
    """Export one durable pre-operation rollback snapshot to a new backup."""
    try:
        from node_store import NodeStore, NodeStoreError
        result = NodeStore(args.store).export_snapshot(args.snapshot_id, args.output)
    except NodeStoreError as exc:
        raise ProgRSSError(str(exc)) from exc
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"Exported pre-operation snapshot to {args.output}")
        print(f"Operation: {result['operationId']}")
        print(f"SHA-256: {result['sha256']}")
        print("Network: none")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="progrss",
        description="ProgRSS feed and Extension-backup tools. Network access occurs only in commands explicitly labeled fetch, from-page, check-page, or check-publication, plus a source check visibly confirmed inside a running Node; publication packaging is local.",
    )
    parser.add_argument("--version", action="version", version=f"ProgRSS CLI {VERSION}")
    commands = parser.add_subparsers(dest="command", required=True)

    doctor = commands.add_parser("doctor", help="check the local CLI environment; no network or writes")
    doctor.set_defaults(func=cmd_doctor)

    node = commands.add_parser("node", help="create, serve, inspect, and export a local ProgRSS Node-owned library")
    node_commands = node.add_subparsers(dest="node_command", required=True)

    node_init = node_commands.add_parser(
        "init",
        help="create a transactional Node-owned library from one private backup",
        description="Create a new SQLite-backed ProgRSS Node-owned library. The original private-backup bytes are preserved inside the new store. No network access.",
    )
    node_init.add_argument("backup", type=Path, help="explicit progrss.private.v1 backup")
    node_init.add_argument("--output", "-o", required=True, type=Path, help="new Node-owned .sqlite3 file; never overwritten")
    node_init.add_argument("--json", action="store_true", help="emit machine-readable creation evidence")
    node_init.set_defaults(func=cmd_node_init)

    node_serve = node_commands.add_parser(
        "serve",
        help="serve one exported backup read-only or one Node-owned library with reviewed writes and checks",
        description="Loopback server for one explicit ProgRSS backup or Node-owned library. A Node-owned library permits one reviewed branch-adoption operation and explicit one-off source checks. Starting the Node performs no feed or webpage fetch; no scheduler is created.",
    )
    node_serve.add_argument("library", type=Path, help="explicit progrss.private.v1 backup or ProgRSS Node-owned SQLite library")
    node_serve.add_argument("--port", type=int, default=0, choices=range(0, 65536), metavar="0..65535", help="loopback TCP port; 0 chooses an available port")
    node_serve.add_argument("--open", action="store_true", help="open the capability URL in the default browser")
    node_serve.add_argument("--json", action="store_true", help="print one machine-readable ready record")
    node_serve.set_defaults(func=cmd_node_serve)

    node_export = node_commands.add_parser(
        "export",
        help="export the current portable private backup from a Node-owned library",
    )
    node_export.add_argument("store", type=Path, help="ProgRSS Node-owned SQLite library")
    node_export.add_argument("--output", "-o", required=True, type=Path, help="new private-backup JSON file; never overwritten")
    node_export.add_argument("--json", action="store_true", help="emit machine-readable export evidence")
    node_export.set_defaults(func=cmd_node_export)

    node_receipts = node_commands.add_parser(
        "receipts",
        help="list durable reviewed-operation receipts; no network or library writes",
    )
    node_receipts.add_argument("store", type=Path, help="ProgRSS Node-owned SQLite library")
    node_receipts.add_argument("--limit", type=int, default=50, choices=range(1, 101), metavar="1..100")
    node_receipts.add_argument("--json", action="store_true", help="emit machine-readable receipt evidence")
    node_receipts.set_defaults(func=cmd_node_receipts)

    node_acquisitions = node_commands.add_parser(
        "acquisitions",
        help="list durable acquisition receipts and interrupted intents; no network or library writes",
    )
    node_acquisitions.add_argument("store", type=Path, help="ProgRSS Node-owned SQLite library")
    node_acquisitions.add_argument("--limit", type=int, default=50, choices=range(1, 101), metavar="1..100")
    node_acquisitions.add_argument("--json", action="store_true", help="emit machine-readable acquisition evidence")
    node_acquisitions.set_defaults(func=cmd_node_acquisitions)

    node_fieldbook = node_commands.add_parser(
        "fieldbook",
        help="create a private local Trace/Bearing facilitator sheet; no network or library write",
        description="Generate one self-contained facilitator sidecar from the current read-only Bearing/Trace review. The sheet makes no network request, requests no participant identity, performs no telemetry, and persists nothing automatically. Output is new-file-only.",
    )
    node_fieldbook.add_argument("store", type=Path, help="ProgRSS Node-owned SQLite library")
    node_fieldbook.add_argument("source_id", help="watched-page source ID with an unresolved held rendering")
    node_fieldbook.add_argument("--output", "-o", required=True, type=Path, help="new self-contained Fieldbook HTML file; never overwritten")
    node_fieldbook.add_argument("--json", action="store_true", help="emit machine-readable fieldbook evidence")
    node_fieldbook.set_defaults(func=cmd_node_fieldbook)

    node_exchange_fieldbook = node_commands.add_parser(
        "exchange-fieldbook",
        help="create a private recipient-study sheet from one Exchange review JSON file",
        description="Generate one self-contained local-only facilitator sidecar for an actual progrss.node.exchange.v1 review. Curator names, route titles, hostnames, source addresses, folder paths, exchange identifiers, and invitation capabilities are omitted. No network access. Output is new-file-only.",
    )
    node_exchange_fieldbook.add_argument("review", type=Path, help="one progrss.node.exchange.v1 review JSON file")
    node_exchange_fieldbook.add_argument("--output", "-o", required=True, type=Path, help="new self-contained Exchange Fieldbook HTML file; never overwritten")
    node_exchange_fieldbook.add_argument("--json", action="store_true", help="emit machine-readable fieldbook evidence")
    node_exchange_fieldbook.set_defaults(func=cmd_node_exchange_fieldbook)

    node_exchange_sender_fieldbook = node_commands.add_parser(
        "exchange-sender-fieldbook",
        help="create a private sender-study sheet from one Exchange preview JSON file",
        description="Generate one self-contained local-only sender-study facilitator sidecar for an actual progrss.node.exchange-preview.v1 review. Route, curator, source, folder, public-address, library, artifact-digest, and preview-capability identity are omitted. No network access. Output is new-file-only.",
    )
    node_exchange_sender_fieldbook.add_argument("preview", type=Path, help="one progrss.node.exchange-preview.v1 review JSON file")
    node_exchange_sender_fieldbook.add_argument("--output", "-o", required=True, type=Path, help="new self-contained sender Fieldbook HTML file; never overwritten")
    node_exchange_sender_fieldbook.add_argument("--json", action="store_true", help="emit machine-readable fieldbook evidence")
    node_exchange_sender_fieldbook.set_defaults(func=cmd_node_exchange_sender_fieldbook)

    node_roadcase = node_commands.add_parser(
        "roadcase",
        help="build a deterministic self-verifying native-fieldwork packet",
        description="Build one local Roadcase ZIP containing the exact Chromium and Firefox trees, exact CLI/Node runtime, synthetic fixtures, verification, preparation, and cleanup helpers. Build is offline and output is new-file-only. It does not claim native or human sessions occurred.",
    )
    node_roadcase.add_argument("--output", "-o", required=True, type=Path, help="new Roadcase ZIP; never overwritten")
    node_roadcase.add_argument("--release-root", type=Path, default=None, help=argparse.SUPPRESS)
    node_roadcase.add_argument("--json", action="store_true", help="emit machine-readable packet evidence")
    node_roadcase.set_defaults(func=cmd_node_roadcase)

    node_debrief = node_commands.add_parser(
        "debrief",
        help="create a private local workspace for comparing Fieldbook reports",
        description="Generate one self-contained local-only analysis workspace. Optional Fieldbook JSON reports are strictly validated and preloaded; additional compatible reports can be selected inside the page. Raw facilitator notes remain local and are excluded from the debrief export. Output is new-file-only.",
    )
    node_debrief.add_argument("reports", nargs="*", type=Path, help="optional compatible progrss.fieldwork-report.v1 JSON files to preload")
    node_debrief.add_argument("--output", "-o", required=True, type=Path, help="new self-contained Debrief HTML file; never overwritten")
    node_debrief.add_argument("--json", action="store_true", help="emit machine-readable workspace evidence")
    node_debrief.set_defaults(func=cmd_node_debrief)

    node_snapshot = node_commands.add_parser(
        "snapshot",
        help="export one durable pre-operation rollback snapshot to a new backup",
    )
    node_snapshot.add_argument("store", type=Path, help="ProgRSS Node-owned SQLite library")
    node_snapshot.add_argument("snapshot_id", help="snapshot id from an operation receipt")
    node_snapshot.add_argument("--output", "-o", required=True, type=Path, help="new private-backup JSON file; never overwritten")
    node_snapshot.add_argument("--json", action="store_true", help="emit machine-readable snapshot-export evidence")
    node_snapshot.set_defaults(func=cmd_node_snapshot)

    feed = commands.add_parser("feed", help="inspect local feeds or perform one explicit fetch")
    feed_commands = feed.add_subparsers(dest="feed_command", required=True)
    inspect = feed_commands.add_parser("inspect", help="inspect a local RSS, Atom, or JSON Feed file")
    inspect.add_argument("file")
    inspect.add_argument("--url", required=True, help="base/origin URL used to resolve relative links")
    inspect.add_argument("--limit", type=int, default=20, choices=range(1, 251), metavar="1..250")
    inspect.add_argument("--json", action="store_true")
    inspect.set_defaults(func=cmd_feed_inspect)
    preview = feed_commands.add_parser("preview", help="show a compact item sample from a local feed; no network or writes")
    preview.add_argument("file")
    preview.add_argument("--url", required=True, help="base/origin URL used to resolve relative links")
    preview.add_argument("--limit", type=int, default=3, choices=range(1, 21), metavar="1..20")
    preview.add_argument("--json", action="store_true")
    preview.set_defaults(func=cmd_feed_preview)
    fetch = feed_commands.add_parser("fetch", help="EXPLICIT NETWORK: fetch one feed; same-origin redirects only")
    fetch.add_argument("url")
    fetch.add_argument("--output", required=True)
    fetch.add_argument("--timeout", type=float, default=20.0)
    fetch.add_argument("--no-validate", action="store_true", help="store bounded bytes without feed validation")
    fetch.set_defaults(func=cmd_feed_fetch)
    corpus_parser = feed_commands.add_parser("corpus", help="replay a local bounded feed corpus; no network or writes")
    corpus_parser.add_argument("--directory", default=str(DEFAULT_CORPUS), help="directory containing corpus.json")
    corpus_parser.add_argument("--json", action="store_true")
    corpus_parser.set_defaults(func=cmd_feed_corpus)

    bundle = commands.add_parser("bundle", help="inspect portable shared-folder bundles")
    bundle_commands = bundle.add_subparsers(dest="bundle_command", required=True)
    inspect_bundle = bundle_commands.add_parser("inspect", help="review a shared folder; no network or writes")
    inspect_bundle.add_argument("file", type=Path)
    inspect_bundle.add_argument("--json", action="store_true", help="emit a machine-readable one-line summary")
    inspect_bundle.set_defaults(func=cmd_relay_bundle_inspect)
    contents_bundle = bundle_commands.add_parser(
        "contents",
        help="list source names, sites, and folder routes; no network or writes",
    )
    contents_bundle.add_argument("file", type=Path)
    contents_bundle.add_argument("--limit", type=int, default=20, choices=range(1, 101), metavar="1..100", help="maximum rows shown in human output")
    contents_bundle.add_argument("--json", action="store_true", help="emit the complete machine-readable contents report")
    contents_bundle.set_defaults(func=cmd_relay_bundle_contents)
    verify_bundle = bundle_commands.add_parser("verify", help="verify a shared-folder digest and optional signature; no network or writes")
    verify_bundle.add_argument("file", type=Path)
    verify_bundle.add_argument("--require-signature", action="store_true", help="exit 3 when valid but unsigned or legacy")
    verify_bundle.add_argument("--json", action="store_true", help="emit a machine-readable one-line summary")
    verify_bundle.set_defaults(func=cmd_relay_bundle_verify)
    site_bundle = bundle_commands.add_parser(
        "site",
        help="package a located shared folder as a script-free static website ZIP; no network",
    )
    site_bundle.add_argument("file", type=Path)
    site_bundle.add_argument("--edition", type=Path, help="optional summary-only folder Edition JSON Feed")
    site_bundle.add_argument("--output", "-o", required=True, type=Path)
    site_bundle.add_argument("--json", action="store_true", help="emit a machine-readable one-line summary")
    site_bundle.set_defaults(func=cmd_relay_bundle_site)
    fetch_bundle = bundle_commands.add_parser(
        "fetch",
        help="EXPLICIT NETWORK: fetch and verify one direct shared-folder address",
    )
    fetch_bundle.add_argument("url")
    fetch_bundle.add_argument("--output", "-o", type=Path, help="optional new file for the verified shared folder")
    fetch_bundle.add_argument("--json", action="store_true", help="emit the complete retrieval and verification report")
    fetch_bundle.set_defaults(func=cmd_relay_bundle_fetch)
    from_page = bundle_commands.add_parser(
        "from-page",
        help="EXPLICIT NETWORK: discover and verify a same-site shared folder advertised by a webpage",
    )
    from_page.add_argument("url")
    from_page.add_argument("--output", "-o", type=Path, help="optional new file for the verified shared folder")
    from_page.add_argument("--json", action="store_true", help="emit the complete discovery and verification report")
    from_page.set_defaults(func=cmd_relay_bundle_from_page)
    check_page = bundle_commands.add_parser(
        "check-page",
        help="EXPLICIT NETWORK: audit a deployed static publication page and its advertised files",
    )
    check_page.add_argument("url")
    check_page.add_argument("--require-updates", action="store_true", help="fail when no valid recent-updates feed is advertised")
    check_page.add_argument("--json", action="store_true", help="emit the complete deployment audit")
    check_page.set_defaults(func=cmd_relay_bundle_check_page)

    workspace = commands.add_parser("workspace", help="inspect or transform an Extension private backup")
    work = workspace.add_subparsers(dest="workspace_command", required=True)

    inspect_ws = work.add_parser("inspect", help="summarize and audit a backup; no writes")
    inspect_ws.add_argument("backup")
    inspect_ws.add_argument("--json", action="store_true")
    inspect_ws.add_argument("--limit", type=int, default=30, choices=range(1, 251), metavar="1..250")
    inspect_ws.set_defaults(func=cmd_workspace_inspect)

    recovery_copy = work.add_parser(
        "recovery-copy",
        help="validate one backup and write a private new-file-only recovery copy; no network",
    )
    recovery_copy.add_argument("backup")
    recovery_copy.add_argument("--output", required=True)
    recovery_copy.set_defaults(func=cmd_workspace_recovery_copy)

    compare_copies = work.add_parser(
        "compare-copies",
        help="compare two private copies without exposing source addresses; no writes",
    )
    compare_copies.add_argument("first")
    compare_copies.add_argument("second")
    compare_copies.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    compare_copies.add_argument(
        "--require-match",
        action="store_true",
        help="exit 3 when both files are valid but their portable libraries differ",
    )
    compare_copies.set_defaults(func=cmd_workspace_compare_copies)

    query = work.add_parser("query", help="search reading history without changing it")
    query.add_argument("backup")
    add_query_options(query)
    query.set_defaults(func=cmd_workspace_query)

    read_item = work.add_parser("read", help="show one retained feed update or page change; no writes")
    read_item.add_argument("backup")
    read_item.add_argument("item", help="exact item id, exact title, or exact retained URL")
    read_item.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    read_item.set_defaults(func=cmd_workspace_read)

    page_changes = work.add_parser(
        "page-changes",
        help="explain retained page-watch changes with before/after context; no writes",
    )
    page_changes.add_argument("backup")
    page_changes.add_argument("--source", default="", help="page-watch id, title, or URL substring")
    page_changes.add_argument("--unread-only", action="store_true", help="include only unread page changes")
    page_changes.add_argument("--limit", type=int, default=50, choices=range(1, 251), metavar="1..250")
    page_changes.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    page_changes.set_defaults(func=cmd_workspace_page_changes)

    sources = work.add_parser("sources", help="show human-readable source health and recent activity")
    sources.add_argument("backup")
    sources.add_argument("--problems-only", action="store_true", help="show only active sources that need attention")
    sources.add_argument("--folder", default="", help="simple folder id, title, full path, or unfiled")
    sources.add_argument("--limit", type=int, default=100, choices=range(1, 201), metavar="1..200")
    sources.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    sources.set_defaults(func=cmd_workspace_sources)

    access_plan = work.add_parser(
        "access-plan",
        help="explain visible site-access decisions without reading a browser profile; no network or writes",
    )
    access_plan.add_argument("backup")
    access_plan.add_argument("--source", default="", help="optional source id, exact title, or URL")
    access_plan.add_argument("--origins", action="store_true", help="show site origins; hidden by default")
    access_plan.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    access_plan.set_defaults(func=cmd_workspace_access_plan)

    assess_page_watch = work.add_parser(
        "assess-page-watch",
        help="assess one or two local page-watch captures without creating alerts or changing a snapshot",
    )
    assess_page_watch.add_argument("backup")
    assess_page_watch.add_argument("source", help="page-watch id, exact title, or URL")
    assess_page_watch.add_argument("html", help="first local UTF-8 HTML specimen")
    assess_page_watch.add_argument(
        "--confirm-html",
        help="optional second local specimen representing the next check",
    )
    assess_page_watch.add_argument("--json", action="store_true", help="emit the complete bounded assessment")
    assess_page_watch.set_defaults(func=cmd_workspace_assess_page_watch)

    review_page_watch = work.add_parser(
        "review-page-watch",
        help="review selector-free repair choices from a local HTML specimen; no network or writes",
    )
    review_page_watch.add_argument("backup")
    review_page_watch.add_argument("source", help="page-watch id, exact title, or URL")
    review_page_watch.add_argument("html", help="local UTF-8 HTML specimen")
    review_page_watch.add_argument("--json", action="store_true", help="emit machine-readable repair choices")
    review_page_watch.set_defaults(func=cmd_workspace_review_page_watch)

    repair_page_watch = work.add_parser(
        "repair-page-watch",
        help="apply one reviewed local page-watch proposal to a new backup; no network",
    )
    repair_page_watch.add_argument("backup")
    repair_page_watch.add_argument("source", help="page-watch id, exact title, or URL")
    repair_page_watch.add_argument("html", help="the same local UTF-8 HTML specimen used for review")
    repair_page_watch.add_argument("--proposal", required=True, help="exact proposal id from review-page-watch")
    repair_page_watch.add_argument("--output", required=True)
    repair_page_watch.set_defaults(func=cmd_workspace_repair_page_watch)

    text_storage = work.add_parser(
        "text-storage",
        help="audit retained full feed text in one backup; no browser-profile read or writes",
    )
    text_storage.add_argument("backup")
    text_storage.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    text_storage.set_defaults(func=cmd_workspace_text_storage)

    text_retention = work.add_parser(
        "set-text-retention",
        help="set one feed's future text policy in a new backup; optionally trim read, unsaved full text",
    )
    text_retention.add_argument("backup")
    text_retention.add_argument("source", help="source id, exact title, or known URL; archived feeds are allowed")
    text_retention.add_argument("mode", choices=("full", "summary"))
    text_retention.add_argument("--trim-read", action="store_true", help="with summary mode, replace read and unsaved full text with summaries")
    text_retention.add_argument("--output", required=True)
    text_retention.set_defaults(func=cmd_workspace_set_text_retention)

    folders = work.add_parser("folders", help="show simple folder paths and counts; no writes")
    folders.add_argument("backup")
    folders.add_argument("--include-unfiled", action="store_true", help="show Unfiled even when empty")
    folders.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    folders.set_defaults(func=cmd_workspace_folders)

    place_source = work.add_parser("place-source", help="put one source into an existing simple folder in a new backup; no network")
    place_source.add_argument("backup")
    place_source.add_argument("source", help="source id, exact title, or URL")
    place_source.add_argument("folder", help="simple folder id, exact title, or full path")
    place_source.add_argument("--output", required=True)
    place_source.set_defaults(func=cmd_workspace_place_source)

    remove_source = work.add_parser(
        "remove-from-folder",
        help="remove one direct source placement from an existing simple folder in a new backup; no network",
    )
    remove_source.add_argument("backup")
    remove_source.add_argument("source", help="source id, exact title, or URL")
    remove_source.add_argument("folder", help="simple folder id, exact title, or full path")
    remove_source.add_argument("--output", required=True)
    remove_source.set_defaults(func=cmd_workspace_remove_from_folder)

    source_note = work.add_parser(
        "source-note",
        help="add, edit, or clear one reason on one direct folder/source placement in a new backup; no network",
    )
    source_note.add_argument("backup")
    source_note.add_argument("source", help="source id, exact title, or URL")
    source_note.add_argument("folder", help="simple folder id, exact title, or full path")
    source_note_choice = source_note.add_mutually_exclusive_group(required=True)
    source_note_choice.add_argument("--reason", help="plain-text reason, at most 280 Unicode code points")
    source_note_choice.add_argument("--clear", action="store_true", help="remove the optional reason field from this placement")
    source_note.add_argument("--output", required=True)
    source_note.set_defaults(func=cmd_workspace_source_note)

    duplicate_sources = work.add_parser(
        "duplicate-sources",
        help="review feeds that share address evidence; no writes or browser-profile access",
    )
    duplicate_sources.add_argument("backup")
    duplicate_sources.add_argument("--limit", type=int, default=100, choices=range(1, 501), metavar="1..500")
    duplicate_sources.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    duplicate_sources.set_defaults(func=cmd_workspace_duplicate_sources)

    source_references = work.add_parser(
        "source-references",
        help="name the exact advanced records that block a same-source repair; no writes",
    )
    source_references.add_argument("backup")
    source_references.add_argument("first", help="first source id, exact title, or known URL")
    source_references.add_argument("second", help="second source id, exact title, or known URL")
    source_references.add_argument("--paths", action="store_true", help="show bounded technical object paths in text output")
    source_references.add_argument("--json", action="store_true", help="emit machine-readable JSON with paths")
    source_references.set_defaults(func=cmd_workspace_source_references)

    retire_receipt = work.add_parser(
        "retire-graft-receipt",
        help="preserve one exact blocking graft receipt as retired evidence in a new backup; no network",
    )
    retire_receipt.add_argument("backup")
    retire_receipt.add_argument("first", help="first source id, exact title, or known URL")
    retire_receipt.add_argument("second", help="second source id, exact title, or known URL")
    retire_receipt.add_argument("receipt", help="exact local receipt id or exact receipt title")
    retire_receipt.add_argument("--output", required=True)
    retire_receipt.set_defaults(func=cmd_workspace_retire_graft_receipt)

    retired_receipts = work.add_parser(
        "retired-receipts",
        help="verify and list preserved retired graft receipts; no writes",
    )
    retired_receipts.add_argument("backup")
    retired_receipts.add_argument("--limit", type=int, default=100, choices=range(1, MAX_RETIRED_RECEIPTS + 1), metavar="1..64")
    retired_receipts.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    retired_receipts.set_defaults(func=cmd_workspace_retired_receipts)

    combine_sources = work.add_parser(
        "combine-sources",
        help="combine two reviewed feed histories into a new backup; no network",
    )
    combine_sources.add_argument("backup")
    combine_sources.add_argument("first", help="first source id, exact title, or known URL")
    combine_sources.add_argument("second", help="second source id, exact title, or known URL")
    combine_sources.add_argument("--keep", required=True, help="one of the two source ids, exact titles, or known URLs")
    combine_sources.add_argument("--output", required=True)
    combine_sources.set_defaults(func=cmd_workspace_combine_sources)

    transfer_audit = work.add_parser(
        "transfer-audit",
        help="explain what a private library file moves and what may need reconnecting; no writes",
    )
    transfer_audit.add_argument("backup")
    transfer_audit.add_argument(
        "--origins",
        action="store_true",
        help="show active site origins; hidden by default for terminal privacy",
    )
    transfer_audit.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    transfer_audit.add_argument("--limit", type=int, default=30, choices=range(1, 251), metavar="1..250")
    transfer_audit.set_defaults(func=cmd_workspace_transfer_audit)

    share_folder = work.add_parser(
        "share-folder",
        help="export one simple folder without reading history or observations",
    )
    share_folder.add_argument("backup", type=Path)
    share_folder.add_argument("folder", help="folder ID, unique title, or full folder path")
    share_folder.add_argument("--output", "-o", required=True, type=Path)
    share_folder.add_argument("--format", choices=("bundle", "opml"), default="bundle")
    share_folder.add_argument("--curator", default="", help="optional name or group shown in the shared file")
    share_folder.add_argument("--note", default="", help="optional short curation note, at most 280 characters")
    share_location = share_folder.add_mutually_exclusive_group()
    share_location.add_argument("--update-url", default=None, help="optional public http(s) address for a later copy; checked only on explicit request")
    share_location.add_argument("--without-update-url", dest="update_url", action="store_const", const="", help="remove an inherited future-copy address")
    share_folder.add_argument("--json", action="store_true", help="emit a machine-readable one-line summary")
    share_folder.set_defaults(func=cmd_relay_share_folder)

    publish_folder = work.add_parser(
        "publish-folder",
        help="package one simple folder as a ready-to-host website ZIP; no network",
    )
    publish_folder.add_argument("backup", type=Path)
    publish_folder.add_argument("folder", help="folder ID, unique title, or full folder path")
    publish_folder.add_argument(
        "--update-url",
        required=True,
        help="public http(s) address ending in the hosted .json file name",
    )
    publish_folder.add_argument("--output", "-o", required=True, type=Path)
    publish_folder.add_argument("--curator", default="", help="optional name or group shown in the shared files")
    publish_folder.add_argument("--note", default="", help="optional short curation note, at most 280 characters")
    publish_folder.add_argument("--include-updates", action="store_true", help="include a summary-only recent-updates JSON Feed and readable update list")
    publish_folder.add_argument("--update-limit", type=int, default=100, choices=range(1, MAX_FOLDER_EDITION_ITEMS + 1), metavar="1..100", help="maximum recent updates when --include-updates is used")
    publish_folder.add_argument("--json", action="store_true", help="emit a machine-readable one-line summary")
    publish_folder.set_defaults(func=cmd_relay_publish_folder)

    import_bundle = work.add_parser(
        "import-bundle",
        help="add a reviewed shared folder to a new backup; no network",
    )
    import_bundle.add_argument("backup", type=Path)
    import_bundle.add_argument("bundle", type=Path)
    import_bundle.add_argument("--output", "-o", required=True, type=Path)
    import_bundle.add_argument("--folder", default="", help="optional folder section ID, unique title, or full path; imported as an independent local excerpt")
    import_bundle.add_argument("--json", action="store_true", help="emit a machine-readable one-line summary")
    import_bundle.set_defaults(func=cmd_relay_import_bundle)

    review_bundle = work.add_parser(
        "review-bundle",
        help="compare an imported publication with a later shared-folder file; no writes",
    )
    review_bundle.add_argument("backup", type=Path)
    review_bundle.add_argument("bundle", type=Path)
    review_bundle.add_argument("--folder", default="", help="local publication root ID or unique title")
    review_bundle.add_argument("--json", action="store_true", help="emit the complete deterministic review")
    review_bundle.set_defaults(func=cmd_relay_review_bundle)

    check_publication = work.add_parser(
        "check-publication",
        help="EXPLICIT NETWORK: fetch and review one imported publication's configured later copy; never applies it",
    )
    check_publication.add_argument("backup", type=Path)
    check_publication.add_argument("folder", help="imported publication folder ID, unique title, or full folder path")
    check_publication.add_argument("--output", "-o", type=Path, help="optional new file for the verified fetched copy")
    check_publication.add_argument("--json", action="store_true", help="emit the complete network and update review")
    check_publication.set_defaults(func=cmd_relay_check_publication)

    update_bundle_parser = work.add_parser(
        "update-bundle",
        help="apply a reviewed shared-folder update to a new backup; no network",
    )
    update_bundle_parser.add_argument("backup", type=Path)
    update_bundle_parser.add_argument("bundle", type=Path)
    update_bundle_parser.add_argument("--folder", default="", help="local publication root ID or unique title")
    update_bundle_parser.add_argument("--accept-trust-change", action="store_true", help="accept a reviewed signing-key change or signature downgrade")
    update_bundle_parser.add_argument("--output", "-o", required=True, type=Path)
    update_bundle_parser.add_argument("--json", action="store_true", help="emit a machine-readable summary")
    update_bundle_parser.set_defaults(func=cmd_relay_update_bundle)

    opml = work.add_parser("opml", help="export active RSS sources to a new OPML file")
    opml.add_argument("backup")
    opml.add_argument("--output", required=True)
    opml.set_defaults(func=cmd_workspace_opml)

    import_opml = work.add_parser("import-opml", help="import a local OPML file into a new backup; no network")
    import_opml.add_argument("backup")
    import_opml.add_argument("opml")
    import_opml.add_argument("--output", required=True)
    import_opml.add_argument("--active", action="store_true", help="mark imported feeds active; browser site access is still granted per site")
    import_opml.set_defaults(func=cmd_workspace_import_opml)

    json_feed = work.add_parser("json-feed", help="export updates to a new JSON Feed file")
    json_feed.add_argument("backup")
    json_feed.add_argument("--output", required=True)
    json_feed.add_argument("--unread-only", action="store_true")
    json_feed.add_argument("--starred-only", action="store_true")
    json_feed.set_defaults(func=cmd_workspace_json_feed)

    edition = work.add_parser(
        "edition",
        help="export one simple folder's recent updates as a privacy-bounded JSON Feed; no network",
    )
    edition.add_argument("backup")
    edition.add_argument("folder", help="folder ID, unique title, or full folder path")
    edition.add_argument("--output", "-o", required=True)
    edition.add_argument("--limit", type=int, default=MAX_FOLDER_EDITION_ITEMS, choices=range(1, MAX_FOLDER_EDITION_ITEMS + 1), metavar="1..100")
    edition.add_argument("--curator", default="", help="optional name or group shown as the feed author")
    edition.add_argument("--note", default="", help="optional short curation note, at most 280 characters")
    edition.add_argument("--json", action="store_true", help="emit a machine-readable one-line summary")
    edition.set_defaults(func=cmd_workspace_edition)

    mark = work.add_parser("mark-all-read", help="create a new backup with every update marked read")
    mark.add_argument("backup")
    mark.add_argument("--output", required=True)
    mark.set_defaults(func=cmd_workspace_mark_all_read)

    ingest = work.add_parser("ingest", help="ingest a local feed into a new backup; no network")
    ingest.add_argument("backup")
    ingest.add_argument("feed")
    ingest.add_argument("--url", required=True, help="the feed's canonical/base URL")
    ingest.add_argument("--title", default="", help="title for a newly created source")
    ingest.add_argument("--output", required=True)
    ingest.set_defaults(func=cmd_workspace_ingest)

    legacy = commands.add_parser("legacy", help="run the preserved rev0021 carrier with arguments after --")
    legacy.add_argument("arguments", nargs=argparse.REMAINDER)
    legacy.set_defaults(func=cmd_legacy)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except ProgRSSError as exc:
        fail(str(exc))
    except KeyboardInterrupt:
        fail("interrupted", code=130)
    except BrokenPipeError:
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
