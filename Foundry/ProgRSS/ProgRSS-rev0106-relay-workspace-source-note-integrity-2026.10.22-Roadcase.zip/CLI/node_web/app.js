'use strict';

(() => {
  const state = {
    token: '', library: null, status: null, pairings: [], invitation: null,
    curation: null, exchangePreview: null, exchange: null, exchanges: [], mergeReview: null,
    operationBundle: null, branchOptions: null, operationPreview: null, operationResult: null,
    operations: [], operationId: '',
    acquisitionPreview: null, acquisitionResult: null, acquisitions: [], acquisitionJobs: [], acquisitionId: '',
    bearingReview: null, baselinePreview: null, baselineResult: null, baselineOperationId: '',
    captureInvitation: null,
    view: 'today', filter: 'unread', query: '', busy: new Set()
  };
  const $ = selector => document.querySelector(selector);
  const $$ = selector => Array.from(document.querySelectorAll(selector));

  function text(value, fallback = '') {
    const clean = String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
    return clean || fallback;
  }

  function h(tag, attrs = {}, children = []) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(attrs)) {
      if (value == null || value === false) continue;
      if (key === 'class') node.className = value;
      else if (key === 'text') node.textContent = value;
      else if (key === 'hidden') node.hidden = Boolean(value);
      else if (key === 'disabled') node.disabled = Boolean(value);
      else node.setAttribute(key, String(value));
    }
    for (const child of Array.isArray(children) ? children : [children]) {
      if (child == null) continue;
      node.append(child.nodeType ? child : document.createTextNode(String(child)));
    }
    return node;
  }

  function setStatus(message, kind = '') {
    const node = $('#status');
    node.textContent = message;
    node.className = `status ${kind}`.trim();
  }

  function busy(key, value) {
    if (value) state.busy.add(key); else state.busy.delete(key);
    $('#create-pairing').disabled = state.busy.has('invitation');
    $('#refresh-pairings').disabled = state.busy.has('pairings');
    $('#preview-exchange').disabled = state.busy.has('exchange-preview');
    $('#create-exchange').disabled = state.busy.has('exchange-create');
    $('#exchange-sender-fieldbook').disabled = state.busy.has('exchange-sender-fieldbook') || !state.exchangePreview?.previewToken;
    $('#exchange-fieldbook').disabled = state.busy.has('exchange-fieldbook') || !state.exchange?.exchangeId;
    $('#refresh-exchanges').disabled = state.busy.has('exchanges');
    $('#review-merge').disabled = state.busy.has('merge-review');
    $('#operation-file').disabled = state.busy.has('operation-options');
    $('#operation-branch').disabled = state.busy.has('operation-options') || !state.branchOptions?.branches?.length;
    $('#review-operation').disabled = state.busy.has('operation-preview') || !state.operationBundle || !$('#operation-branch').value;
    $('#commit-operation').disabled = state.busy.has('operation-commit') || !state.operationPreview || !$('#operation-confirm').checked;
    const witnessNeedsConfirm = Boolean(state.acquisitionPreview?.source?.action === 'enable-and-check');
    $('#commit-witness').disabled = state.busy.has('acquisition-commit') || !state.acquisitionPreview || (witnessNeedsConfirm && !$('#witness-confirm').checked);
    $('#commit-baseline').disabled = state.busy.has('baseline-commit') || !state.baselinePreview || !$('#baseline-confirm').checked;
    $('#cancel-baseline').disabled = state.busy.has('baseline-commit');
    $('#bearing-fieldbook').disabled = state.busy.has('fieldbook') || !state.bearingReview;
    $('#bearing-debrief').disabled = state.busy.has('debrief') || !state.bearingReview;
    $$('.source-check-button').forEach(button => { button.disabled = state.busy.has('acquisition-preview') || state.busy.has('acquisition-commit') || state.busy.has('bearing-review') || state.busy.has('baseline-preview') || state.busy.has('baseline-commit'); });
    $$('.source-capture-button').forEach(button => { button.disabled = state.busy.has('capture-invitation') || state.busy.has('bearing-review') || state.busy.has('baseline-preview') || state.busy.has('baseline-commit'); });
    $$('.bearing-source-button').forEach(button => { button.disabled = state.busy.has('bearing-review') || state.busy.has('baseline-preview') || state.busy.has('baseline-commit') || state.busy.has('acquisition-preview') || state.busy.has('acquisition-commit'); });
  }

  function parseCapability() {
    const fragment = new URLSearchParams(location.hash.slice(1));
    const incoming = fragment.get('token') || '';
    if (incoming) {
      sessionStorage.setItem('progrss-node-token', incoming);
      fragment.delete('token');
      const suffix = fragment.toString();
      history.replaceState(null, '', `${location.pathname}${location.search}${suffix ? `#${suffix}` : ''}`);
    }
    return incoming || sessionStorage.getItem('progrss-node-token') || '';
  }

  async function api(path, options = {}) {
    if (!state.token) throw new Error('This page has no node capability. Reopen the exact URL printed by the ProgRSS command.');
    const response = await fetch(path, {
      ...options,
      cache: 'no-store',
      credentials: 'omit',
      headers: {...options.headers, Authorization: `Bearer ${state.token}`},
    });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(body.error || `Node request failed (${response.status})`);
    return body;
  }

  async function apiBlob(path, options = {}) {
    if (!state.token) throw new Error('This page has no node capability. Reopen the exact URL printed by the ProgRSS command.');
    const response = await fetch(path, {
      ...options, cache: 'no-store', credentials: 'omit',
      headers: {...options.headers, Authorization: `Bearer ${state.token}`},
    });
    if (!response.ok) {
      const body = await response.json().catch(() => ({}));
      throw new Error(body.error || `Node request failed (${response.status})`);
    }
    const disposition = response.headers?.get?.('Content-Disposition') || '';
    const match = /filename="?([^";]+)"?/i.exec(disposition);
    const filename = match?.[1] || 'progrss-artifact.bin';
    const buffer = await response.arrayBuffer();
    return {filename, blob: new Blob([buffer], {type: response.headers?.get?.('Content-Type') || 'application/octet-stream'})};
  }

  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url; link.download = filename; document.body.append(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function formatDate(value) {
    if (!value) return 'Time not supplied';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return text(value);
    return new Intl.DateTimeFormat(undefined, {month: 'short', day: 'numeric', year: date.getFullYear() === new Date().getFullYear() ? undefined : 'numeric'}).format(date);
  }

  function formatMoment(value) {
    if (!value) return 'time unavailable';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return text(value);
    return new Intl.DateTimeFormat(undefined, {dateStyle: 'medium', timeStyle: 'short'}).format(date);
  }

  function compactFingerprint(value) {
    const raw = text(value);
    if (raw.length <= 28) return raw;
    return `${raw.slice(0, 18)}…${raw.slice(-10)}`;
  }

  function normalized(value) {
    return text(value).toLocaleLowerCase();
  }

  function visibleItems() {
    const q = normalized(state.query);
    return (state.library?.items || []).filter(item => {
      if (state.filter === 'unread' && item.read) return false;
      if (state.filter === 'saved' && !item.saved) return false;
      if (!q) return true;
      return [item.title, item.sourceTitle, item.summary].some(value => normalized(value).includes(q));
    });
  }

  function renderItems() {
    const list = $('#item-list');
    const rows = visibleItems();
    list.setAttribute('aria-busy', 'false');
    $('#today-summary').textContent = rows.length === 1 ? '1 update in this view.' : `${rows.length} updates in this view.`;
    if (!rows.length) {
      list.replaceChildren(h('div', {class: 'empty'}, [h('strong', {text: state.query ? 'Nothing matches that search' : state.filter === 'unread' ? 'You’re caught up' : 'Nothing here yet'}), h('p', {text: state.query ? 'Try fewer words or another reading filter.' : 'This node is reading the selected private backup without fetching anything new.'})]));
      return;
    }
    list.replaceChildren(...rows.map(item => {
      const title = item.url ? h('a', {href: item.url, target: '_blank', rel: 'noreferrer', text: item.title}) : document.createTextNode(item.title);
      const meta = [h('span', {text: item.sourceTitle}), h('span', {text: '·'}), h('time', {datetime: item.published || item.observedAt, text: formatDate(item.published || item.observedAt)})];
      if (item.saved) meta.push(h('span', {class: 'saved', text: 'Saved'}));
      return h('article', {class: `item-card${item.read ? '' : ' unread'}`}, [h('div', {class: 'item-meta'}, meta), h('h3', {}, title), item.summary ? h('p', {text: item.summary}) : null]);
    }));
  }

  function witnessOutcome(value) {
    const labels = {
      changed: 'New material found', unchanged: 'No new material', baseline: 'Baseline saved',
      'watch-pending': 'Unusual shape held', 'coverage-shift': 'Rendered window held', 'needs-repair': 'Needs repair', malformed: 'Could not read response',
      refused: 'Request refused safely', moved: 'Moved to another site', throttled: 'Site asked us to slow down',
      'temporary-failure': 'Temporary problem', 'permanent-failure': 'Site refused this check', 'baseline-replaced': 'Baseline replaced',
    };
    return labels[text(value)] || (text(value) ? text(value).replaceAll('-', ' ') : 'Not checked yet');
  }

  function renderSources() {
    const list = $('#source-list');
    const sources = state.library?.sources || [];
    const canCheck = nodeOwnsLibrary() && Boolean(state.status?.capabilities?.manualAcquisition);
    const heldCount = sources.filter(row => row.heldBaselineAvailable).length;
    $('#source-summary').textContent = `${sources.length} sources · ${sources.filter(row => row.enabled).length} active · ${sources.filter(row => row.type === 'page').length} watched pages${heldCount ? ` · ${heldCount} held ${heldCount === 1 ? 'window' : 'windows'} to review` : ''}.`;
    if (!sources.length) {
      list.replaceChildren(h('div', {class: 'empty'}, [h('strong', {text: 'No sources in this copy'}), h('p', {text: 'Add or adopt a reviewed route before checking a source.'})]));
      return;
    }
    list.replaceChildren(...sources.map(source => {
      const stateLabel = source.archived ? 'Archived' : source.enabled ? 'Active' : 'Paused';
      const title = source.url ? h('a', {href: source.url, target: '_blank', rel: 'noreferrer', text: source.title}) : document.createTextNode(source.title);
      const details = [];
      if (source.lastOutcome) details.push(`${witnessOutcome(source.lastOutcome)}${source.lastCheckedAt ? ` · ${formatMoment(source.lastCheckedAt)}` : ''}`);
      if (source.lastItems) details.push(`${countPhrase(source.lastItems, 'new item')}`);
      const actions = h('div', {class: 'source-actions'});
      if (canCheck && !source.archived) {
        const check = h('button', {
          class: 'secondary-button source-check-button', type: 'button',
          text: source.enabled ? 'Review check' : 'Review enable and check',
          'data-source-id': source.id,
        });
        check.addEventListener('click', () => reviewWitness(source.id));
        actions.append(check);
        if (source.type === 'page' && state.status?.capabilities?.browserAssistedCapture) {
          const capture = h('button', {
            class: 'quiet-button source-capture-button', type: 'button',
            text: 'Use signed-in browser', 'data-source-id': source.id,
          });
          capture.addEventListener('click', () => createCaptureInvitation(source.id));
          actions.append(capture);
        }
        if (source.heldBaselineAvailable && state.status?.capabilities?.reviewHeldWindows) {
          const count = Math.max(1, Number(source.heldObservationCount || 1));
          const bearing = h('button', {
            class: 'quiet-button bearing-source-button', type: 'button',
            text: count > 1 ? 'Understand held windows' : 'Understand held window', 'data-source-id': source.id,
          });
          bearing.addEventListener('click', () => reviewBearing(source.id));
          actions.append(bearing);
        }
      }
      return h('article', {class: 'source-card witness-source-card'}, [
        h('div', {class: 'source-card-main'}, [
          h('div', {class: 'source-meta'}, [h('span', {text: source.type === 'page' ? 'Watched page' : 'Feed'}), h('span', {text: '·'}), h('span', {text: source.host || 'Address hidden'}), h('span', {class: `source-state ${source.enabled ? 'on' : 'off'}`, text: stateLabel})]),
          h('h3', {}, title),
          details.length ? h('p', {class: 'source-last-check', text: details.join(' · ')}) : null,
          source.heldBaselineAvailable ? h('p', {class: 'held-baseline-note', text: `${Math.max(1, Number(source.heldObservationCount || 1)) === 1 ? 'Held rendered window available' : `${Math.max(1, Number(source.heldObservationCount || 1))} unresolved held observations`}${Number.isFinite(Number(source.heldBaselineOverlapPercent)) ? ` · current ${Number(source.heldBaselineOverlapPercent)}% overlap` : ''}. Earlier baseline is still active.`}) : null,
          source.error ? h('p', {class: 'source-problem', text: source.error}) : null,
        ]),
        actions.childElementCount ? actions : null,
      ]);
    }));
  }

  function renderCaptureInvitation() {
    const invitation = state.captureInvitation;
    const panel = $('#capture-request');
    panel.hidden = !invitation;
    if (!invitation) return;
    const source = invitation.source || {};
    $('#capture-request-expiry').textContent = `Expires ${formatMoment(invitation.expiresAt)}`;
    $('#capture-request-message').textContent = `${text(source.title, 'This watched page')} · ${text(source.site, 'site unavailable')}. Paste this request into the ProgRSS Extension while the exact page is open. The Extension will ask which rendered section counts as an update before anything is sent.`;
    $('#capture-url').value = invitation.url || '';
  }

  async function createCaptureInvitation(sourceId) {
    if (!nodeOwnsLibrary()) return;
    busy('capture-invitation', true);
    try {
      state.captureInvitation = await api('/api/v1/capture-invitations', {
        method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({sourceId}),
      });
      renderCaptureInvitation();
      $('#capture-request-heading').focus();
      setStatus('Browser request created · no page, source site, or browser profile was contacted by the Node', 'good');
    } catch (error) { setStatus(error.message, 'error'); }
    finally { busy('capture-invitation', false); }
  }

  async function copyCaptureInvitation() {
    const value = $('#capture-url').value;
    try { await navigator.clipboard.writeText(value); setStatus('Capture request copied. It expires and works for one reviewed watched page.', 'good'); }
    catch { $('#capture-url').select(); setStatus('Copy was blocked. The request is selected for manual copy.', 'decision'); }
  }

  function closeCaptureInvitation() {
    state.captureInvitation = null;
    renderCaptureInvitation();
    $('.source-capture-button')?.focus?.();
    setStatus('Capture request closed locally. It will expire in Node memory and grants no background access.', '');
  }

  function renderWitnessMode() {
    const available = nodeOwnsLibrary() && Boolean(state.status?.capabilities?.manualAcquisition);
    const mode = $('#witness-mode');
    mode.className = `witness-mode ${available ? 'available' : 'unavailable'}`;
    mode.replaceChildren(
      h('strong', {text: available ? 'Manual acquisition available' : 'Manual acquisition unavailable'}),
      h('p', {text: available
        ? 'Only this local administrator can authorize a check. Paired Extensions remain summary-only. Background scheduling is off.'
        : 'Serve a Node-owned library to review and run one bounded source check. Exported backups remain read-only.'}),
    );
  }

  function renderWitnessPreview() {
    const preview = state.acquisitionPreview;
    const result = state.acquisitionResult;
    $('#witness-review').hidden = !preview || Boolean(result);
    renderWitnessMode();
    if (!preview || result) return;
    const source = preview.source || {};
    const enable = source.action === 'enable-and-check';
    $('#witness-review-expiry').textContent = `Review expires ${formatMoment(preview.expiresAt)}`;
    $('#witness-review-message').textContent = enable
      ? `${text(source.title, 'This source')} is paused. Confirming will enable it and make one bounded request to ${text(source.site, 'its site')}. No recurring schedule is created.`
      : `ProgRSS will make one bounded request to ${text(source.site, 'this site')} and retain an exact result receipt. It will not create a recurring schedule.`;
    const recipe = source.pageRecipe;
    $('#witness-source').replaceChildren(
      h('div', {}, [
        h('strong', {text: text(source.title, 'Untitled source')}),
        h('small', {text: `${source.type === 'page' ? 'Watched page' : 'Feed'} · ${text(source.site, 'host unavailable')} · ${enable ? 'Paused now' : 'Active now'}`}),
        recipe ? h('p', {text: recipe.mode === 'cards'
          ? `Repeated entries from ${text(recipe.selector, 'the readable page')}. Title: ${text(recipe.titleSelector, 'automatic')}. Link: ${text(recipe.linkSelector, 'automatic')}.`
          : `Readable region: ${text(recipe.selector, 'the page body')}. Meaningful-change threshold: ${recipe.threshold || 1}.`}) : null,
      ]),
    );
    const limits = preview.limits || {};
    const consequences = preview.consequences || {};
    const facts = [
      ['Address', source.url || '—'],
      ['Method', limits.method || 'GET'],
      ['Timeout', `${limits.timeoutSeconds || 20} seconds`],
      ['Response limit', `${Number(limits.responseBytes || 0).toLocaleString()} bytes`],
      ['Redirects', `${limits.sameOriginRedirects || 0} same-site maximum; another site stops before contact`],
      ['Conditional request', source.validators?.etag || source.validators?.lastModified ? 'Available from prior validators' : 'No saved validator yet'],
      ['Cookies or credentials', consequences.browserCookiesSent || consequences.browserCredentialsSent ? 'Unexpectedly enabled' : 'None'],
      ['Page JavaScript', consequences.pageJavaScriptExecuted ? 'Enabled' : 'Never executed'],
      ['Automatic schedule', consequences.automaticScheduleCreated ? 'Created' : 'Not created'],
    ];
    $('#witness-preview-facts').replaceChildren(...facts.flatMap(([label, value]) => [h('dt', {text: label}), h('dd', {text: value})]));
    $('#witness-confirm-row').hidden = !enable;
    $('#witness-confirm').checked = false;
    $('#commit-witness').textContent = enable ? 'Enable and check once' : 'Check once now';
    $('#commit-witness').disabled = enable;
  }

  function renderWitnessResult() {
    const result = state.acquisitionResult;
    $('#witness-result').hidden = !result;
    if (!result) return;
    const receipt = result.receipt || {};
    const summary = receipt.summary || {};
    const effects = receipt.effects || {};
    const request = receipt.request || {};
    const fetch = receipt.evidence?.fetch || {};
    $('#witness-result-state').textContent = result.replayed ? 'Safe replay · no second request' : `Revision ${receipt.resultRevision || '—'}`;
    const outcome = witnessOutcome(receipt.outcome);
    const message = text(summary.message);
    $('#witness-result-message').textContent = result.replayed
      ? `The original receipt was returned. ${text(request.sourceTitle, 'This source')} was not checked again.`
      : message || `${outcome}. ${Number(summary.itemsAdded || 0) ? countPhrase(summary.itemsAdded, 'new item') + ' was retained.' : 'No new item was retained.'}`;
    const metrics = [
      [outcome, 'Outcome'],
      [String(Number(summary.itemsAdded || 0)), 'Items added'],
      [String(Number(effects.networkRequests || 0)), 'HTTP requests'],
      [String(receipt.resultRevision || '—'), 'Library revision'],
    ];
    $('#witness-metrics').replaceChildren(...metrics.map(([value, label]) => h('span', {class: 'witness-metric'}, [h('strong', {text: value}), h('small', {text: label})])));
    const rows = [
      ['Operation', receipt.operationId || '—'],
      ['Committed', formatMoment(receipt.committedAt)],
      ['Source', `${text(request.sourceTitle, receipt.sourceId)} · ${text(request.sourceHost, 'host unavailable')}`],
      ['Action', request.action === 'enable-and-check' ? 'Enabled and checked once' : 'Checked once'],
      ['HTTP status', String(fetch.httpStatus || receipt.evidence?.httpStatus || 'No response')],
      ['Redirects', String(Array.isArray(fetch.redirects) ? fetch.redirects.length : 0)],
      ['Attempts', String(receipt.attemptCount || 1)],
      ['Result SHA-256', receipt.resultLibrarySha256 || '—'],
      ['Receipt', receipt.receiptId || '—'],
    ];
    $('#witness-receipt').replaceChildren(...rows.flatMap(([label, value]) => [h('dt', {text: label}), h('dd', {text: value})]));
  }

  function renderWitnessHistory() {
    const rows = Array.isArray(state.acquisitions) ? state.acquisitions : [];
    $('#witness-history-count').textContent = String(rows.length);
    const list = $('#witness-history-list');
    if (!rows.length) {
      list.replaceChildren(h('p', {class: 'field-note', text: nodeOwnsLibrary() ? 'No reviewed source check has committed yet.' : 'Acquisition receipts are available only in a Node-owned library.'}));
      return;
    }
    list.replaceChildren(...rows.map(receipt => {
      const request = receipt.request || {};
      const summary = receipt.summary || {};
      return h('article', {class: 'witness-history-row'}, [
        h('div', {}, [h('strong', {text: text(request.sourceTitle, receipt.sourceId || 'Source check')}), h('small', {text: `${witnessOutcome(receipt.outcome)} · ${formatMoment(receipt.committedAt)} · ${countPhrase(summary.itemsAdded, 'new item')}`})]),
        h('code', {text: compactFingerprint(receipt.receiptId)}),
      ]);
    }));
  }

  async function reviewWitness(sourceId) {
    if (!nodeOwnsLibrary()) return;
    busy('acquisition-preview', true);
    try {
      state.acquisitionPreview = await api('/api/v1/acquisition-previews', {
        method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({sourceId}),
      });
      state.acquisitionResult = null;
      state.acquisitionId = newOperationId().replace(/^op-/, 'acq-');
      renderWitnessPreview();
      renderWitnessResult();
      $('#witness-review-heading').focus();
      setStatus('Source check reviewed · no DNS lookup, site request, or library write yet', 'good');
    } catch (error) { setStatus(error.message, 'error'); }
    finally { busy('acquisition-preview', false); }
  }

  function cancelWitness() {
    state.acquisitionPreview = null;
    state.acquisitionResult = null;
    state.acquisitionId = '';
    $('#witness-confirm').checked = false;
    renderWitnessPreview();
    renderWitnessResult();
    $('.source-check-button')?.focus?.();
    setStatus('Check canceled. No site was contacted and the library was not changed.', '');
  }

  async function refreshAfterWitness() {
    const [status, library, acquisitionList] = await Promise.all([
      api('/api/v1/status'), api('/api/v1/library'), api('/api/v1/acquisitions'),
    ]);
    state.status = status;
    state.library = library;
    state.acquisitions = Array.isArray(acquisitionList.receipts) ? acquisitionList.receipts : [];
    state.acquisitionJobs = Array.isArray(acquisitionList.jobs) ? acquisitionList.jobs : [];
    $('#stat-unread').textContent = library.stats.unread;
    $('#stat-sources').textContent = library.stats.sources;
    $('#stat-watches').textContent = library.stats.pageWatches;
    renderItems(); renderSources(); renderWitnessHistory(); renderWitnessMode(); renderFacts(status);
  }

  async function commitWitness() {
    const preview = state.acquisitionPreview;
    if (!preview) return;
    const enable = preview.source?.action === 'enable-and-check';
    if (enable && !$('#witness-confirm').checked) return;
    if (!state.acquisitionId) state.acquisitionId = newOperationId().replace(/^op-/, 'acq-');
    busy('acquisition-commit', true);
    setStatus(`Checking ${text(preview.source?.site, 'the reviewed site')} once…`, '');
    try {
      state.acquisitionResult = await api('/api/v1/acquisitions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'If-Match': `"${preview.library?.sha256 || ''}"`,
          'Idempotency-Key': state.acquisitionId,
        },
        body: JSON.stringify({
          operationType: 'check-source-once', sourceId: preview.source?.sourceId,
          action: preview.source?.action, previewToken: preview.previewToken,
          previewDigest: preview.previewDigest,
        }),
      });
      await refreshAfterWitness();
      renderWitnessPreview(); renderWitnessResult();
      $('#witness-result-heading').focus();
      setStatus(state.acquisitionResult.replayed
        ? 'Original acquisition receipt recovered · no second request or write occurred'
        : `${witnessOutcome(state.acquisitionResult.receipt?.outcome)} · durable acquisition receipt created · no schedule created`, 'good');
    } catch (error) {
      setStatus(`${error.message} Retrying the same button keeps the same operation key; a completed check will return its original receipt.`, 'error');
    } finally { busy('acquisition-commit', false); }
  }

  function anotherWitness() {
    state.acquisitionPreview = null;
    state.acquisitionResult = null;
    state.acquisitionId = '';
    $('#witness-confirm').checked = false;
    renderWitnessPreview(); renderWitnessResult();
    $('.source-check-button')?.focus?.();
    setStatus('Ready to review another source. Nothing happens until you confirm one check.', '');
  }

  function bearingTraceNode(label, snapshot, relationship, extra = {}) {
    const units = Number(snapshot?.units || 0);
    const boundaries = Array.isArray(extra.boundaryKinds) ? extra.boundaryKinds : [];
    const overlap = extra.overlapToPreviousPercent;
    const meta = [
      `${units} ${text(snapshot?.unitLabel, units === 1 ? 'unit' : 'units')}`,
      extra.heldAt ? formatMoment(extra.heldAt) : formatMoment(snapshot?.capturedAt),
    ];
    if (Number.isFinite(Number(overlap))) meta.push(`${Number(overlap)}% overlap with previous`);
    const children = [
      h('span', {class: 'trace-dot', 'aria-hidden': 'true'}),
      h('div', {class: 'trace-card'}, [
        h('div', {class: 'trace-card-top'}, [
          h('span', {class: `trace-kind ${text(relationship?.kind, 'accepted')}`, text: text(relationship?.title, label)}),
          h('small', {text: extra.current ? 'Current hold' : label}),
        ]),
        h('strong', {text: label}),
        h('p', {text: text(relationship?.summary, 'This is the accepted comparison point.')}),
        h('small', {class: 'trace-meta', text: meta.join(' · ')}),
        boundaries.length ? h('div', {class: 'trace-boundaries', 'aria-label': 'Observed page boundaries'}, boundaries.map(value => h('span', {text: value}))) : null,
      ]),
    ];
    return h('li', {class: `bearing-trace-node ${extra.current ? 'current' : ''}`.trim()}, children);
  }

  function renderBearingTrace(review) {
    const trace = review.trace || {};
    const accepted = trace.accepted || review.source?.accepted || {};
    const observations = Array.isArray(trace.observations) ? trace.observations : [];
    $('#bearing-trace-count').textContent = `${observations.length + 1} points`;
    $('#bearing-trace-message').textContent = observations.length
      ? 'The accepted baseline comes first. Each held observation then shows what overlapped with the previous point and which rendered-page limits were visible.'
      : 'Only the accepted baseline is available.';
    const nodes = [bearingTraceNode('Accepted baseline', accepted, {kind: 'accepted', title: 'Accepted', summary: 'Future comparisons still begin here.'}, {})];
    observations.forEach((row, index) => {
      nodes.push(bearingTraceNode(`Held observation ${index + 1}`, row.snapshot || {}, row.relationshipToPrevious || {}, row));
    });
    $('#bearing-trace-list').replaceChildren(...nodes);

    const footprint = review.recipeFootprint || {};
    $('#recipe-footprint-label').textContent = text(footprint.label, 'Recipe');
    $('#recipe-footprint-mode').textContent = footprint.mode === 'cards' ? 'Repeated entries' : 'Readable region';
    $('#recipe-footprint-summary').textContent = text(footprint.summary, 'ProgRSS could not describe this saved recipe.');
    const reasons = Array.isArray(footprint.reasons) ? footprint.reasons : [];
    const warnings = Array.isArray(footprint.warnings) ? footprint.warnings : [];
    const points = [
      ...reasons.map(value => h('li', {class: 'recipe-reason', text: value})),
      ...warnings.map(value => h('li', {class: 'recipe-warning', text: value})),
    ];
    if (!points.length) points.push(h('li', {text: 'No additional structural signal was recorded.'}));
    $('#recipe-footprint-points').replaceChildren(...points);
    $('#recipe-footprint-route').textContent = text(footprint.routeExplanation, 'Keep the accepted baseline until another reviewed action is chosen.');
  }

  function renderBearingReview() {
    const review = state.bearingReview;
    $('#bearing-review').hidden = !review;
    if (!review) return;
    const diagnosis = review.diagnosis || {};
    const source = review.source || {};
    const history = review.history || {};
    const recommended = text(diagnosis.recommendedRoute, 'keep');
    $('#bearing-review-count').textContent = `${Number(diagnosis.observationsReviewed || 1)} ${Number(diagnosis.observationsReviewed || 1) === 1 ? 'observation' : 'observations'} reviewed`;
    $('#bearing-review-message').textContent = `${text(source.title, 'This watched page')} still uses the accepted baseline. Bearing examined the current held rendering and up to ${Number(history.maximumPriorObservations || 8)} recent unresolved observations without changing the library.`;
    $('#bearing-fieldbook-status').textContent = '';
    $('#bearing-diagnosis-label').textContent = diagnosis.kind === 'moving-rendered-window' ? 'Pattern observed' : diagnosis.kind === 'page-boundary-shifted' ? 'Boundary changed' : 'Review only';
    $('#bearing-diagnosis-title').textContent = text(diagnosis.title, 'Not enough evidence yet');
    $('#bearing-diagnosis-summary').textContent = text(diagnosis.summary, 'The evidence does not form one clear pattern yet.');
    $('#bearing-diagnosis-limit').textContent = text(diagnosis.cannotProve, 'This review does not prove what the publisher intended.');
    const observations = Array.isArray(review.advanced?.observations) ? review.advanced.observations : [];
    const comparisons = Array.isArray(review.advanced?.comparisons) ? review.advanced.comparisons : [];
    const latestComparison = comparisons[0] || {};
    const rows = [
      ['Diagnosis', text(diagnosis.kind, 'insufficient-evidence')],
      ['Current held receipt', source.heldReceiptId || '—'],
      ['Accepted snapshot', source.accepted?.sha256 || review.advanced?.acceptedSnapshotSha256 || '—'],
      ['Current proposal', source.currentHeld?.sha256 || '—'],
      ['Prior unresolved observations', String(Number(history.priorObservationsRetained || 0))],
      ['Compatible prior observations', String(Number(diagnosis.compatiblePriorObservations || 0))],
      ['Low-overlap comparisons', String(Number(diagnosis.lowOverlapComparisons || 0))],
      ['Latest held-to-held overlap', comparisons.length ? `${Number(latestComparison.overlapPercent || 0)}%` : 'Not available'],
      ['Current page boundaries', Array.isArray(diagnosis.boundaryKinds) && diagnosis.boundaryKinds.length ? diagnosis.boundaryKinds.join(', ') : 'None observed'],
      ['Observations retained', `${observations.length} shown · ${Number(history.maximumPriorObservations || 8)} prior maximum`],
      ['Network during review', review.network ? 'Unexpectedly on' : 'None'],
      ['Writes during review', review.writes ? 'Unexpectedly on' : 'None'],
    ];
    const footprint = review.recipeFootprint || {};
    const recipe = review.advanced?.recipe || footprint.advanced || {};
    rows.splice(9, 0,
      ['Trace schema', review.trace?.schema || 'Not available'],
      ['Recipe footprint', text(footprint.kind, 'unknown')],
      ['Saved selector', recipe.selector || '(primary readable region)'],
      ['Title selector', recipe.titleSelector || 'Not set'],
      ['Link selector', recipe.linkSelector || 'Not set']
    );
    $('#bearing-review-facts').replaceChildren(...rows.flatMap(([label, value]) => [h('dt', {text: label}), h('dd', {text: value})]));
    renderBearingTrace(review);
    $('#open-bearing-anchor').dataset.recommended = String(recommended === 'anchor');
    $('#open-bearing-capture').dataset.recommended = String(recommended === 'capture');
    $('#keep-bearing').dataset.recommended = String(recommended === 'keep');
  }

  async function downloadFieldbook() {
    if (!state.bearingReview?.source?.id) return;
    busy('fieldbook', true);
    const message = $('#bearing-fieldbook-status');
    message.textContent = 'Preparing one private local facilitator sheet…';
    try {
      const artifact = await apiBlob('/api/v1/fieldwork-kits', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({sourceId: state.bearingReview.source.id}),
      });
      downloadBlob(artifact.blob, artifact.filename);
      message.textContent = 'Fieldbook downloaded locally · no telemetry · no Node library change';
      setStatus('Private fieldwork sheet downloaded · no source address, selector, telemetry, or automatic saving', 'good');
    } catch (error) {
      message.textContent = '';
      setStatus(error.message, 'error');
    } finally { busy('fieldbook', false); }
  }

  async function downloadDebrief() {
    if (!state.bearingReview) return;
    busy('debrief', true);
    const message = $('#bearing-debrief-status');
    message.textContent = 'Preparing one local analysis workspace…';
    try {
      const artifact = await apiBlob('/api/v1/debrief-kits', {
        method: 'POST', headers: {'Content-Type': 'application/json'}, body: '{}',
      });
      downloadBlob(artifact.blob, artifact.filename);
      message.textContent = 'Debrief workspace downloaded locally · no telemetry · no Node library change';
      setStatus('Private debrief workspace downloaded · raw notes stay local and no participant score is calculated', 'good');
    } catch (error) {
      message.textContent = '';
      setStatus(error.message, 'error');
    } finally { busy('debrief', false); }
  }

  async function reviewBearing(sourceId) {
    if (!nodeOwnsLibrary()) return;
    busy('bearing-review', true);
    try {
      state.bearingReview = await api('/api/v1/bearing-reviews', {
        method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({sourceId}),
      });
      renderBearingReview();
      $('#bearing-review-heading').focus();
      setStatus('Held-window evidence reviewed · no watched-site request and no library change', 'good');
    } catch (error) { setStatus(error.message, 'error'); }
    finally { busy('bearing-review', false); }
  }

  function keepBearing() {
    state.bearingReview = null;
    renderBearingReview();
    $('.bearing-source-button')?.focus?.();
    setStatus('Accepted baseline kept. Bearing made no write and contacted no site.', '');
  }

  async function openAnchorFromBearing() {
    const sourceId = state.bearingReview?.source?.id;
    if (!sourceId) return;
    state.bearingReview = null;
    renderBearingReview();
    await reviewBaseline(sourceId);
  }

  async function openCaptureFromBearing() {
    const sourceId = state.bearingReview?.source?.id;
    if (!sourceId) return;
    state.bearingReview = null;
    renderBearingReview();
    await createCaptureInvitation(sourceId);
  }

  function baselineSnapshotCard(label, snapshot, tone) {
    const mode = snapshot?.mode === 'cards' ? 'Repeated entries' : 'Readable region';
    const units = Number(snapshot?.units || 0);
    return h('article', {class: `baseline-side ${tone}`}, [
      h('span', {class: 'baseline-kicker', text: label}),
      h('strong', {text: `${units} ${text(snapshot?.unitLabel, units === 1 ? 'unit' : 'units')}`}),
      h('p', {text: mode}),
      h('small', {text: `Observed ${formatMoment(snapshot?.capturedAt)}`}),
      h('code', {text: compactFingerprint(snapshot?.sha256)}),
    ]);
  }

  function renderBaselinePreview() {
    const preview = state.baselinePreview;
    const result = state.baselineResult;
    $('#baseline-review').hidden = !preview || Boolean(result);
    if (!preview || result) return;
    const source = preview.source || {};
    const continuity = preview.continuity || {};
    $('#baseline-review-expiry').textContent = `Review expires ${formatMoment(preview.expiresAt)}`;
    $('#baseline-review-message').textContent = `${text(source.sourceTitle, 'This watched page')} held a rendered window with ${Number(continuity.overlapPercent || 0)}% stable overlap. Replacing the baseline changes only the future comparison point; it creates no past add-or-remove alert.`;
    $('#baseline-comparison').replaceChildren(
      baselineSnapshotCard('Accepted now', source.accepted || {}, 'accepted'),
      h('div', {class: 'baseline-arrow', 'aria-hidden': 'true', text: '⟶'}),
      baselineSnapshotCard('Held proposal', source.proposed || {}, 'proposed'),
    );
    const rows = [
      ['Source', `${text(source.sourceTitle, source.sourceId)} · ${text(source.sourceHost, 'host unavailable')}`],
      ['Held observation', source.heldReceiptId || '—'],
      ['Stable overlap', `${Number(continuity.overlapPercent || 0)}% · ${Number(continuity.sharedUnits || 0)} shared unit(s)`],
      ['Hold reason', text(continuity.message, text(continuity.reason, 'Rendered windows were not safely comparable'))],
      ['Earlier boundaries', (continuity.previousBoundaryKinds || []).join(', ') || 'None recorded'],
      ['Held boundaries', (continuity.currentBoundaryKinds || []).join(', ') || 'None recorded'],
      ['Base library SHA-256', preview.library?.sha256 || '—'],
      ['Preview digest', preview.previewDigest || '—'],
      ['Site requests', '0'],
      ['Historical change alerts', '0'],
      ['Automatic schedule', 'None created'],
    ];
    $('#baseline-preview-facts').replaceChildren(...rows.flatMap(([label, value]) => [h('dt', {text: label}), h('dd', {text: value})]));
    $('#baseline-confirm').checked = false;
    $('#commit-baseline').disabled = true;
    $('#baseline-review-heading').focus();
  }

  async function reviewBaseline(sourceId) {
    if (!nodeOwnsLibrary()) return;
    busy('baseline-preview', true);
    try {
      state.baselinePreview = await api('/api/v1/baseline-previews', {
        method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({sourceId}),
      });
      state.baselineResult = null;
      state.baselineOperationId = newOperationId().replace(/^op-/, 'anchor-');
      renderBaselinePreview();
      renderBaselineResult();
      setStatus('Replacement baseline reviewed · no watched-site request and no library change yet', 'good');
    } catch (error) { setStatus(error.message, 'error'); }
    finally { busy('baseline-preview', false); }
  }

  function cancelBaseline() {
    state.baselinePreview = null;
    state.baselineResult = null;
    state.baselineOperationId = '';
    $('#baseline-confirm').checked = false;
    renderBaselinePreview();
    renderBaselineResult();
    $('.bearing-source-button')?.focus?.();
    setStatus('Earlier baseline kept. The held rendering remains available until another observation supersedes it.', '');
  }

  function renderBaselineResult() {
    const result = state.baselineResult;
    $('#baseline-result').hidden = !result;
    if (!result) return;
    const receipt = result.receipt || {};
    const summary = receipt.summary || {};
    const effects = receipt.effects || {};
    const rollback = receipt.rollbackEvidence || {};
    const selection = receipt.selection || {};
    $('#baseline-result-state').textContent = result.replayed ? 'Safe replay · no second write' : `Revision ${receipt.resultRevision || '—'}`;
    $('#baseline-result-message').textContent = result.replayed
      ? `The original durable receipt was returned. ${text(selection.sourceTitle, 'This watched page')} was not replaced twice.`
      : `${text(selection.sourceTitle, 'This watched page')} now compares future observations with the held rendering. The earlier complete library remains in the before snapshot, and no past change alert was created.`;
    const metrics = [
      [String(Number(summary.previousUnits || 0)), 'Earlier units'],
      [String(Number(summary.acceptedUnits || 0)), 'New baseline units'],
      [String(Number(effects.historicalChangeAlertsCreated || 0)), 'Past alerts created'],
      [String(receipt.resultRevision || '—'), 'Library revision'],
    ];
    $('#baseline-metrics').replaceChildren(...metrics.map(([value, label]) => h('span', {class: 'witness-metric'}, [h('strong', {text: value}), h('small', {text: label})])));
    const rows = [
      ['Operation', receipt.operationId || '—'],
      ['Committed', formatMoment(receipt.committedAt)],
      ['Source', `${text(selection.sourceTitle, selection.sourceId)} · ${text(selection.sourceHost, 'host unavailable')}`],
      ['Held receipt', selection.heldReceiptId || receipt.evidence?.heldReceiptId || '—'],
      ['Previous snapshot', receipt.evidence?.previousSnapshotSha256 || '—'],
      ['Accepted snapshot', receipt.evidence?.acceptedSnapshotSha256 || '—'],
      ['Result SHA-256', receipt.resultLibrarySha256 || '—'],
      ['Receipt', receipt.receiptId || '—'],
      ['Before snapshot', rollback.snapshotId || '—'],
      ['Watched-site requests', String(Number(effects.networkRequests || 0))],
    ];
    $('#baseline-receipt').replaceChildren(...rows.flatMap(([label, value]) => [h('dt', {text: label}), h('dd', {text: value})]));
    $('#download-baseline-snapshot').disabled = !rollback.snapshotId;
    $('#baseline-result-heading').focus();
  }

  async function refreshAfterBaseline() {
    const [status, library, operationList, acquisitionList] = await Promise.all([
      api('/api/v1/status'), api('/api/v1/library'), api('/api/v1/operations'), api('/api/v1/acquisitions'),
    ]);
    state.status = status;
    state.library = library;
    state.operations = Array.isArray(operationList.operations) ? operationList.operations : [];
    state.acquisitions = Array.isArray(acquisitionList.receipts) ? acquisitionList.receipts : [];
    state.acquisitionJobs = Array.isArray(acquisitionList.jobs) ? acquisitionList.jobs : [];
    $('#stat-unread').textContent = library.stats.unread;
    $('#stat-sources').textContent = library.stats.sources;
    $('#stat-watches').textContent = library.stats.pageWatches;
    renderItems(); renderSources(); renderWitnessHistory(); renderOperations(); renderFacts(status);
  }

  async function commitBaseline() {
    const preview = state.baselinePreview;
    if (!preview || !$('#baseline-confirm').checked) return;
    if (!state.baselineOperationId) state.baselineOperationId = newOperationId().replace(/^op-/, 'anchor-');
    busy('baseline-commit', true);
    try {
      state.baselineResult = await api('/api/v1/operations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'If-Match': `"${preview.library?.sha256 || ''}"`,
          'Idempotency-Key': state.baselineOperationId,
        },
        body: JSON.stringify({
          operationType: 'replace-held-page-baseline',
          previewToken: preview.previewToken,
          previewDigest: preview.previewDigest,
        }),
      });
      await refreshAfterBaseline();
      renderBaselinePreview();
      renderBaselineResult();
      setStatus(state.baselineResult.replayed
        ? 'Original baseline receipt recovered · the write was not repeated'
        : 'Baseline replaced atomically · no past alert created · before snapshot retained', 'good');
    } catch (error) {
      setStatus(`${error.message} Retrying keeps the same operation key; a completed replacement returns its original receipt.`, 'error');
    } finally { busy('baseline-commit', false); }
  }

  async function downloadBaselineSnapshot() {
    const snapshotId = state.baselineResult?.receipt?.rollbackEvidence?.snapshotId;
    if (!snapshotId) return;
    try {
      const result = await apiBlob(`/api/v1/operation-snapshot?id=${encodeURIComponent(snapshotId)}`);
      const url = URL.createObjectURL(result.blob);
      const link = document.createElement('a'); link.href = url; link.download = result.filename; link.click();
      setTimeout(() => URL.revokeObjectURL(url), 0);
      setStatus(`${result.filename} contains the exact portable library from before the baseline replacement.`, 'good');
    } catch (error) { setStatus(error.message, 'error'); }
  }

  function anotherBaseline() {
    state.baselinePreview = null;
    state.baselineResult = null;
    state.baselineOperationId = '';
    $('#baseline-confirm').checked = false;
    renderBaselinePreview();
    renderBaselineResult();
    $('#sources-heading').focus();
    setStatus('Returned to sources. Future comparisons now use the accepted baseline shown in the receipt.', '');
  }

  function renderFacts(status = state.status || {}) {
    const facts = $('#node-facts');
    const library = status.library || {};
    const nodeOwned = library.mode === 'node-owned' || Boolean(status.capabilities?.writeLibrary);
    const rows = [
      ['Scope', nodeOwned ? 'Loopback only · Node-owned one-writer library' : 'Loopback only · exported backup · read-only'],
      ['Library', text(library.file || library, 'Unknown')],
      ['Library revision', nodeOwned ? String(library.revision || '—') : 'Not applicable'],
      ['Store schema', nodeOwned ? text(library.storeSchema, 'progrss.node-store.v4') : 'Not applicable'],
      ['Store migration at open', nodeOwned ? (library.storeMigratedAtOpen ? 'Yes · portable library bytes unchanged' : 'No') : 'Not applicable'],
      ['Version', `${status.version || '—'} / ${status.revision || '—'}`],
      ['Session fingerprint', status.instanceFingerprint || 'Unavailable'],
      ['Session lifetime', 'This Node process only'],
      ['Extension pairing', 'Expiring invitation · summary only · never a writer'],
      ['Active pairings', String(state.pairings.length)],
      ['Reviewed branch adoption', nodeOwned ? 'Available to this local administrator only' : 'Unavailable until `progrss node init`'],
      ['Reviewed-write receipts', nodeOwned ? String(state.operations.length) : 'Unavailable'],
      ['Acquisition receipts', nodeOwned ? String(state.acquisitions.length) : 'Unavailable'],
      ['Browser-assisted capture', nodeOwned ? 'One expiring watched-page request · no cookie transfer' : 'Unavailable'],
      ['Held-window diagnosis', nodeOwned ? 'Read-only Bearing review · bounded unresolved history · no site request' : 'Unavailable'],
      ['Held baseline replacement', nodeOwned ? 'Reviewed Anchor operation · no site request · earlier library snapshot retained' : 'Unavailable'],
      ['Reviewed exchange', 'Expiring artifact handoff'],
      ['Later-copy review', 'Local file · three-way · review only'],
      ['Active handoffs', String(state.exchanges.length)],
      ['Network fetching', nodeOwned ? 'Manual reviewed checks only · no scheduler' : 'Off'],
      ['Library writes', nodeOwned ? 'Typed branch adoption, acquisition results, and Anchor baseline replacement' : 'Off'],
      ['Static publication', 'Prepared locally · uploaded by the curator'],
    ];
    facts.replaceChildren(...rows.flatMap(([label, value]) => [h('dt', {text: label}), h('dd', {text: value})]));
  }


  function renderInvitation() {
    const panel = $('#pairing-invitation');
    const invitation = state.invitation;
    panel.hidden = !invitation;
    if (!invitation) return;
    $('#pairing-url').value = invitation.url || '';
    $('#pairing-expiry').textContent = `Expires ${formatMoment(invitation.expiresAt)} · Node ${compactFingerprint(invitation.node?.instanceFingerprint)} · one successful pairing only.`;
  }

  function renderPairings() {
    const list = $('#pairing-list');
    if (!state.pairings.length) {
      list.replaceChildren(h('div', {class: 'pairing-empty', text: 'No Extension is paired with this running Node.'}));
      renderFacts();
      return;
    }
    list.replaceChildren(...state.pairings.map(pairing => {
      const revoke = h('button', {class: 'danger-button', type: 'button', text: 'Revoke'});
      revoke.addEventListener('click', () => revokePairing(pairing));
      return h('article', {class: 'pairing-card'}, [
        h('div', {}, [
          h('h4', {text: `${text(pairing.clientName, 'ProgRSS Extension')}${pairing.clientVersion ? ` ${pairing.clientVersion}` : ''}`}),
          h('p', {text: `${pairing.origin} · paired ${formatMoment(pairing.createdAt)} · last checked ${formatMoment(pairing.lastSeenAt)}`}),
        ]),
        revoke,
      ]);
    }));
    renderFacts();
  }

  async function refreshPairings({announce = false} = {}) {
    busy('pairings', true);
    try {
      const result = await api('/api/v1/pairings');
      state.pairings = Array.isArray(result.pairings) ? result.pairings : [];
      renderPairings();
      if (announce) setStatus(`Pairing list refreshed · ${state.pairings.length} active`, 'good');
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      busy('pairings', false);
    }
  }

  async function createInvitation() {
    busy('invitation', true);
    try {
      state.invitation = await api('/api/v1/pairing-invitations', {
        method: 'POST', body: '{}', headers: {'Content-Type': 'application/json'}
      });
      renderInvitation();
      $('#pairing-url').focus();
      $('#pairing-url').select();
      setStatus('Pairing invitation created · expires in 10 minutes · no library data was sent', 'good');
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      busy('invitation', false);
    }
  }

  async function copyInvitation() {
    const input = $('#pairing-url');
    if (!input.value) return;
    try {
      await navigator.clipboard.writeText(input.value);
      setStatus('Pairing invitation copied. Paste it into ProgRSS Extension.', 'good');
    } catch {
      input.focus(); input.select();
      setStatus('The invitation is selected. Copy it with your browser or keyboard.', '');
    }
  }

  async function revokePairing(pairing) {
    if (!confirm(`Revoke ${text(pairing.clientName, 'this Extension')} from this running Node? The Extension library and this backup will not be changed.`)) return;
    busy('pairings', true);
    try {
      await api('/api/v1/pairings/revoke', {
        method: 'POST',
        body: JSON.stringify({pairId: pairing.pairId}),
        headers: {'Content-Type': 'application/json'},
      });
      state.pairings = state.pairings.filter(row => row.pairId !== pairing.pairId);
      renderPairings();
      setStatus('Pairing revoked. Both libraries remain unchanged.', 'good');
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      busy('pairings', false);
    }
  }

  function countPhrase(value, singular, plural = `${singular}s`) {
    const number = Math.max(0, Number(value) || 0);
    return `${number} ${number === 1 ? singular : plural}`;
  }

  function renderCuration() {
    const select = $('#exchange-folder');
    const current = select.value;
    select.replaceChildren(h('option', {value: '', text: 'Choose a folder'}));
    const folders = Array.isArray(state.curation?.folders) ? state.curation.folders : [];
    for (const folder of folders) {
      select.append(h('option', {value: folder.id, text: `${folder.path} · ${countPhrase(folder.sourceCount, 'source')}`}));
    }
    if ([...select.options].some(option => option.value === current)) select.value = current;
    else if (folders.length === 1) select.value = folders[0].id;
  }

  function newOperationId() {
    const value = globalThis.crypto?.randomUUID?.() || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
    return `op-${value}`;
  }

  function nodeOwnsLibrary() {
    return state.status?.library?.mode === 'node-owned' || Boolean(state.status?.capabilities?.writeLibrary);
  }

  function renderOperationMode() {
    const available = nodeOwnsLibrary();
    const mode = $('#operation-mode');
    const form = $('#operation-form');
    if (available) {
      mode.className = 'operation-mode available';
      mode.replaceChildren(
        h('strong', {text: 'Node-owned library · writer available'}),
        h('p', {text: 'Only this local administrator can authorize the first writer. Paired Extensions remain summary-only and cannot call it.'}),
      );
      form.hidden = Boolean(state.operationPreview || state.operationResult);
    } else {
      mode.className = 'operation-mode unavailable';
      mode.replaceChildren(
        h('strong', {text: 'This Node opened an exported backup read-only'}),
        h('p', {}, ['Create a Node-owned library with ', h('code', {text: 'progrss node init BACKUP --output LIBRARY.sqlite3'}), ', then serve that new file. Sharing and merge review below still work now.']),
      );
      form.hidden = true;
    }
  }

  function clearOperationBranchOptions(message = 'Choose a source-list file first') {
    state.branchOptions = null;
    const select = $('#operation-branch');
    select.replaceChildren(h('option', {value: '', text: message}));
    select.disabled = true;
    $('#review-operation').disabled = true;
    $('#operation-source-list-note').textContent = 'Review is offline. The complete route is not writable through this first operation.';
  }

  function renderBranchOptions() {
    const options = state.branchOptions;
    const select = $('#operation-branch');
    select.replaceChildren(h('option', {value: '', text: 'Choose one populated nested branch'}));
    const branches = Array.isArray(options?.branches) ? options.branches : [];
    for (const branch of branches) {
      const sourceNoteCount = Number(branch.sourceNotes) || 0;
      select.append(h('option', {
        value: branch.id,
        text: `${text(branch.path, branch.title)} · ${countPhrase(branch.sources, 'source')} · ${countPhrase(branch.folders, 'folder')}${sourceNoteCount ? ` · ${countPhrase(sourceNoteCount, 'curator reason')}` : ''}`,
      }));
    }
    select.disabled = !branches.length;
    $('#review-operation').disabled = true;
    if (options) {
      const sourceList = options.sourceList || {};
      $('#operation-source-list-note').textContent = branches.length
        ? `${text(sourceList.title, 'Source route')} · ${branches.length} adoptable branch${branches.length === 1 ? '' : 'es'} · ${text(sourceList.signatureState, 'integrity checked')} · no listed site contacted.`
        : `${text(sourceList.title, 'Source route')} has no populated nested branch. The complete route is not writable through this first operation.`;
    }
  }

  async function loadOperationFile() {
    if (!nodeOwnsLibrary()) return;
    const file = $('#operation-file').files?.[0];
    state.operationBundle = null;
    state.operationPreview = null;
    state.operationResult = null;
    state.operationId = '';
    clearOperationBranchOptions(file ? 'Checking source list…' : 'Choose a source-list file first');
    renderOperationPreview();
    renderOperationResult();
    if (!file) return;
    if (file.size > 650000) {
      setStatus('That source-list file is larger than the 650 KB review limit.', 'error');
      clearOperationBranchOptions('Source list is too large');
      return;
    }
    busy('operation-options', true);
    try {
      const raw = await file.text();
      let bundle;
      try { bundle = JSON.parse(raw); } catch { throw new Error('The selected file is not valid UTF-8 JSON.'); }
      if (!bundle || typeof bundle !== 'object' || Array.isArray(bundle)) throw new Error('Choose one ProgRSS source-list JSON object.');
      const result = await api('/api/v1/branch-options', {
        method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({bundle}),
      });
      state.operationBundle = bundle;
      state.branchOptions = result;
      renderBranchOptions();
      if (result.branches?.length === 1) {
        $('#operation-branch').value = result.branches[0].id;
        $('#review-operation').disabled = false;
      }
      setStatus(`${text(result.sourceList?.title, 'Source route')} checked locally · ${countPhrase(result.branches?.length, 'adoptable branch')} · nothing changed`, 'good');
    } catch (error) {
      clearOperationBranchOptions('This file could not be used');
      setStatus(error.message, 'error');
    } finally {
      busy('operation-options', false);
    }
  }

  function operationStateLabel(value) {
    if (value === 'reused') return 'Already in this Node';
    if (value === 'duplicate-in-list') return 'Same source reused in this branch';
    return 'New · starts paused';
  }

  function operationPlacementRows(row) {
    const placements = Array.isArray(row.placements) ? row.placements : [];
    if (placements.length) {
      return h('div', {class: 'operation-placement-list', 'aria-label': 'Direct folder placements'}, placements.map(placement => {
        const reason = typeof placement?.reason === 'string' ? placement.reason : '';
        const children = [
          h('small', {class: 'operation-placement-route', text: `In ${text(placement?.folderPath, 'folder route unavailable')}`}),
        ];
        if (reason) {
          children.push(h('p', {class: 'operation-placement-reason'}, [
            h('strong', {text: 'Curator’s reason for this folder:'}),
            h('span', {class: 'operation-placement-reason-text', dir: 'auto', text: reason}),
          ]));
        }
        return h('div', {class: 'operation-placement'}, children);
      }));
    }
    const folders = Array.isArray(row.folders) ? row.folders.map(folder => text(folder)).filter(Boolean) : [];
    return folders.length ? h('small', {class: 'operation-placement-fallback', text: folders.join(' · ')}) : null;
  }

  function renderOperationPreview() {
    const preview = state.operationPreview;
    const result = state.operationResult;
    $('#operation-review').hidden = !preview || Boolean(result);
    renderOperationMode();
    if (!preview || result) return;
    const summary = preview.summary || {};
    const selection = preview.selection || {};
    $('#operation-review-expiry').textContent = `Preview expires ${formatMoment(preview.expiresAt)}`;
    $('#operation-review-message').textContent = `${text(selection.folderPath, 'Selected branch')} becomes an independent local route in revision ${preview.result?.revision || '—'}. Review contacts no listed site.`;
    const counts = [
      ['New · paused', summary.newSources],
      ['Reused', summary.reusedSources],
      ['Folders', summary.folders],
      ['Feeds', summary.feeds],
      ['Watched pages', summary.pageWatches],
      ['Curator reasons', preview.contents?.sourceNoteCount ?? summary.sourceNoteCount],
    ];
    $('#operation-counts').replaceChildren(...counts.map(([label, value]) => h('span', {class: 'operation-count'}, [h('strong', {text: String(Number(value) || 0)}), h('small', {text: label})])));
    const rows = Array.isArray(preview.contents?.sources) ? preview.contents.sources : [];
    const sourceNoteCount = Number(preview.contents?.sourceNoteCount ?? summary.sourceNoteCount) || 0;
    $('#operation-contents-summary').textContent = `See ${countPhrase(rows.length, 'source')}${sourceNoteCount ? ` and ${countPhrase(sourceNoteCount, 'curator reason')}` : ''} in this branch`;
    const contentChildren = [];
    if (sourceNoteCount) {
      contentChildren.push(h('p', {class: 'operation-note-boundary'}, [
        h('strong', {text: 'About curator reasons: '}),
        'Each explains why a curator placed one source in one folder. It is not a ProgRSS safety claim.',
      ]));
    }
    contentChildren.push(h('div', {class: 'operation-content-list'}, rows.map(row => h('article', {class: `operation-source ${row.state || ''}`}, [
      h('div', {class: 'operation-source-main'}, [
        h('strong', {text: text(row.title, 'Untitled source')}),
        h('small', {class: 'operation-source-kind', text: `${row.type === 'page' ? 'Watched page' : 'Feed'} · ${text(row.host, 'host unavailable')}`}),
        operationPlacementRows(row),
      ]),
      h('span', {text: operationStateLabel(row.state)}),
    ]))));
    $('#operation-contents').replaceChildren(...contentChildren);
    $('#operation-confirm').checked = false;
    $('#commit-operation').disabled = true;
    $('#operation-review-heading').focus();
  }

  async function reviewOperation(event) {
    event?.preventDefault?.();
    if (!state.operationBundle) { setStatus('Choose and check one ProgRSS source-list file.', 'error'); return; }
    const folder = $('#operation-branch').value;
    if (!folder) { setStatus('Choose one populated nested branch.', 'error'); $('#operation-branch').focus(); return; }
    busy('operation-preview', true);
    try {
      state.operationPreview = await api('/api/v1/operation-previews', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({bundle: state.operationBundle, folder}),
      });
      state.operationResult = null;
      state.operationId = newOperationId();
      renderOperationPreview();
      renderOperationResult();
      setStatus('Exact branch adoption reviewed · no listed site contacted · no library change yet', 'good');
    } catch (error) { setStatus(error.message, 'error'); }
    finally { busy('operation-preview', false); }
  }

  function changeOperation() {
    state.operationPreview = null;
    state.operationResult = null;
    state.operationId = '';
    $('#operation-confirm').checked = false;
    renderOperationPreview();
    renderOperationResult();
    $('#operation-form').hidden = !nodeOwnsLibrary();
    $('#operation-branch').focus();
    setStatus('Operation preview cleared. The Node library was not changed.', '');
  }

  function renderOperationResult() {
    const result = state.operationResult;
    $('#operation-result').hidden = !result;
    if (!result) return;
    const receipt = result.receipt || {};
    const summary = receipt.summary || {};
    const rollback = receipt.rollbackEvidence || {};
    $('#operation-result-state').textContent = result.replayed ? 'Safe replay · no second write' : `Revision ${receipt.resultRevision || '—'}`;
    $('#operation-result-message').textContent = result.replayed
      ? `The original durable receipt was returned. ${text(receipt.selection?.folderPath, 'The reviewed branch')} was not adopted twice.`
      : `${text(receipt.selection?.folderPath, 'The reviewed branch')} was adopted. ${countPhrase(summary.newSources, 'new source')} began paused; ${countPhrase(summary.reusedSources, 'existing source')} was reused.`;
    const rows = [
      ['Operation', receipt.operationId || '—'],
      ['Committed', formatMoment(receipt.committedAt)],
      ['Result revision', String(receipt.resultRevision || '—')],
      ['Result SHA-256', receipt.resultLibrarySha256 || '—'],
      ['Receipt', receipt.receiptId || '—'],
      ['Before snapshot', rollback.snapshotId || '—'],
    ];
    $('#operation-receipt').replaceChildren(...rows.flatMap(([label, value]) => [h('dt', {text: label}), h('dd', {text: value})]));
    $('#download-operation-snapshot').disabled = !rollback.snapshotId;
    $('#operation-result-heading').focus();
  }

  function renderOperations() {
    const rows = Array.isArray(state.operations) ? state.operations : [];
    $('#operation-history-count').textContent = String(rows.length);
    const list = $('#operation-history-list');
    if (!rows.length) {
      list.replaceChildren(h('p', {class: 'field-note', text: nodeOwnsLibrary() ? 'No reviewed Node write has committed yet.' : 'Durable receipts are available only in a Node-owned library.'}));
      renderFacts();
      return;
    }
    list.replaceChildren(...rows.map(receipt => {
      const summary = receipt.summary || {};
      const selection = receipt.selection || {};
      const baseline = receipt.operationType === 'replace-held-page-baseline';
      const title = baseline ? text(selection.sourceTitle, 'Replaced watched-page baseline') : text(selection.folderPath, 'Adopted branch');
      const detail = baseline
        ? `${formatMoment(receipt.committedAt)} · revision ${receipt.resultRevision || '—'} · 0 past alerts`
        : `${formatMoment(receipt.committedAt)} · revision ${receipt.resultRevision || '—'} · ${countPhrase(summary.newSources, 'new source')}`;
      return h('article', {class: 'operation-history-row'}, [
        h('div', {}, [h('strong', {text: title}), h('small', {text: detail})]),
        h('code', {text: compactFingerprint(receipt.receiptId)}),
      ]);
    }));
    renderFacts();
  }

  async function refreshAfterOperation() {
    const [status, library, curation, operationList] = await Promise.all([
      api('/api/v1/status'), api('/api/v1/library'), api('/api/v1/curation'), api('/api/v1/operations'),
    ]);
    state.status = status;
    state.library = library;
    state.curation = curation;
    state.operations = Array.isArray(operationList.operations) ? operationList.operations : [];
    $('#stat-unread').textContent = library.stats.unread;
    $('#stat-sources').textContent = library.stats.sources;
    $('#stat-watches').textContent = library.stats.pageWatches;
    renderItems();
    renderSources();
    renderCuration();
    renderOperations();
    renderOperationMode();
  }

  async function commitOperation() {
    const preview = state.operationPreview;
    if (!preview || !$('#operation-confirm').checked) return;
    if (!state.operationId) state.operationId = newOperationId();
    busy('operation-commit', true);
    try {
      state.operationResult = await api('/api/v1/operations', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'If-Match': `"${preview.library?.sha256 || ''}"`,
          'Idempotency-Key': state.operationId,
        },
        body: JSON.stringify({
          operationType: 'adopt-source-list-branch',
          previewToken: preview.previewToken,
          previewDigest: preview.previewDigest,
        }),
      });
      await refreshAfterOperation();
      renderOperationPreview();
      renderOperationResult();
      setStatus(state.operationResult.replayed ? 'Original receipt recovered · the write was not repeated' : 'Branch adopted atomically · durable receipt and before snapshot created', 'good');
    } catch (error) {
      setStatus(`${error.message} The same button will retry with the same operation key; ProgRSS will not intentionally duplicate a committed write.`, 'error');
    } finally { busy('operation-commit', false); }
  }

  async function downloadOperationSnapshot() {
    const snapshotId = state.operationResult?.receipt?.rollbackEvidence?.snapshotId;
    if (!snapshotId) return;
    try {
      const result = await apiBlob(`/api/v1/operation-snapshot?id=${encodeURIComponent(snapshotId)}`);
      const url = URL.createObjectURL(result.blob);
      const link = document.createElement('a'); link.href = url; link.download = result.filename; link.click();
      setTimeout(() => URL.revokeObjectURL(url), 0);
      setStatus(`${result.filename} contains the exact portable library from before this operation.`, 'good');
    } catch (error) { setStatus(error.message, 'error'); }
  }

  function anotherOperation() {
    state.operationBundle = null;
    state.branchOptions = null;
    state.operationPreview = null;
    state.operationResult = null;
    state.operationId = '';
    $('#operation-file').value = '';
    clearOperationBranchOptions();
    renderOperationPreview();
    renderOperationResult();
    renderOperationMode();
    $('#operation-file').focus();
    setStatus('Ready to review another branch. Nothing happens until a new explicit commit.', '');
  }

  function exchangeChoice(title, description, available, unavailableReason = '') {
    return h('article', {class: `exchange-choice ${available ? 'available' : 'unavailable'}`}, [
      h('h5', {text: title}),
      h('p', {text: available ? description : unavailableReason || description}),
      h('span', {class: 'choice-state', text: available ? 'Available' : 'Not in this handoff'}),
    ]);
  }

  function renderExchangePreview() {
    const preview = state.exchangePreview;
    const ready = state.exchange;
    $('#exchange-form').hidden = Boolean(preview || ready);
    $('#exchange-review').hidden = !preview || Boolean(ready);
    if (!preview || ready) return;
    const counts = preview.counts || {};
    $('#exchange-review-expiry').textContent = `Review expires ${formatMoment(preview.expiresAt)}`;
    $('#exchange-review-message').textContent = `${text(preview.title, 'Shared route')} · ${countPhrase(counts.sources, 'source')} · nothing has been published, sent, or changed.`;
    const choices = preview.choices || {};
    $('#exchange-choice-grid').replaceChildren(
      exchangeChoice('Follow updates', 'Adds one durable summary feed. It does not add the underlying sources.', Boolean(choices.followUpdates?.available), text(choices.followUpdates?.reason, 'A public feed address is required.')),
      exchangeChoice('Add the complete route', 'Reviews and adopts every feed, watched page, and folder in this route. New sources start paused.', true),
      exchangeChoice('Take one branch', 'Reviews one nested folder section as an independent local route with no parent update link.', Boolean(choices.takeBranch?.available), 'This route has no populated nested branch.'),
    );
    const countNodes = [
      h('span', {class: 'exchange-count'}, [h('strong', {text: counts.feeds || 0}), 'feeds']),
      h('span', {class: 'exchange-count'}, [h('strong', {text: counts.pageWatches || 0}), 'watched pages']),
      h('span', {class: 'exchange-count'}, [h('strong', {text: counts.folders || 0}), 'folders']),
    ];
    if (Number(counts.sourceNotes) > 0) countNodes.push(
      h('span', {class: 'exchange-count'}, [h('strong', {text: counts.sourceNotes}), `curator reason${Number(counts.sourceNotes) === 1 ? '' : 's'}`]),
    );
    countNodes.push(h('span', {class: 'exchange-count'}, [h('strong', {text: counts.recentUpdates || 0}), 'recent updates']));
    $('#exchange-counts').replaceChildren(...countNodes);
    const rows = Array.isArray(preview.contents?.sources) ? preview.contents.sources : [];
    const sourceNoteCount = Number(counts.sourceNotes) || 0;
    $('#exchange-contents-summary').textContent = sourceNoteCount
      ? `See ${countPhrase(rows.length, 'source')}, ${countPhrase(sourceNoteCount, 'curator reason')}, and folder routes`
      : `See ${countPhrase(rows.length, 'source')} and folder routes`;
    const contentRows = rows.map(row => {
      const placements = Array.isArray(row.placements) ? row.placements : [];
      const details = h('div', {class: 'exchange-content-main'}, [
        h('strong', {text: text(row.title, 'Untitled source')}),
        h('small', {text: `${row.type === 'page' ? 'Watched page' : 'Feed'} · ${text(row.host, 'host unavailable')}`}),
      ]);
      const placementList = h('div', {class: 'exchange-placement-list'});
      if (placements.length) {
        for (const placement of placements) {
          const placementNode = h('div', {class: 'exchange-placement'});
          placementNode.append(h('small', {class: 'exchange-placement-route', text: text(placement.folderPath, 'Folder route unavailable')}));
          if (typeof placement.reason === 'string' && placement.reason) {
            placementNode.append(h('p', {class: 'exchange-source-note'}, [
              h('strong', {text: 'Curator’s reason for this folder'}),
              h('span', {dir: 'auto', text: placement.reason}),
            ]));
          }
          placementList.append(placementNode);
        }
      } else {
        const routes = Array.isArray(row.folders) ? row.folders.filter(Boolean) : [];
        if (routes.length) placementList.append(h('small', {class: 'exchange-placement-route', text: routes.join(' · ')}));
      }
      details.append(placementList);
      return h('div', {class: 'exchange-content-row'}, [details, h('span', {text: 'New recipients start paused'})]);
    });
    const content = h('div', {class: 'exchange-content-list'}, contentRows);
    if (sourceNoteCount) content.append(h('p', {class: 'exchange-source-note-boundary', text: 'Curator reasons explain why a source appears in a particular folder. They are not a ProgRSS safety claim.'}));
    $('#exchange-contents').replaceChildren(content);
    $('#create-exchange').focus();
  }

  function renderExchangeReady() {
    const exchange = state.exchange;
    $('#exchange-ready').hidden = !exchange;
    if (!exchange) return;
    $('#exchange-url').value = exchange.url || '';
    $('#exchange-ready-expiry').textContent = `Expires ${formatMoment(exchange.expiresAt)}`;
    const artifacts = exchange.artifacts || {};
    $('#download-updates').hidden = !artifacts.recentUpdates?.available;
    $('#download-site').hidden = !artifacts.site?.available;
    const publicPage = text(exchange.public?.pageUrl);
    const share = $('#share-public-page');
    share.hidden = !(publicPage && typeof navigator.share === 'function');
    share.dataset.url = publicPage;
    $('#exchange-ready-heading').focus();
  }

  function renderExchanges() {
    const list = $('#exchange-list');
    if (!state.exchanges.length) {
      list.replaceChildren(h('div', {class: 'pairing-empty', text: 'No active handoff. Prepare a route above when you are ready to send one.'}));
      renderFacts();
      return;
    }
    list.replaceChildren(...state.exchanges.map(exchange => {
      const revoke = h('button', {class: 'danger-button', type: 'button', text: 'Revoke'});
      revoke.addEventListener('click', () => revokeExchange(exchange));
      return h('article', {class: 'pairing-card'}, [
        h('div', {}, [
          h('h4', {text: text(exchange.title, 'Shared route')}),
          h('p', {text: `${countPhrase(exchange.counts?.sources, 'source')} · expires ${formatMoment(exchange.expiresAt)} · ${exchange.reviewed ? 'reviewed by one Extension' : 'not yet reviewed'}`}),
        ]), revoke,
      ]);
    }));
    renderFacts();
  }

  async function refreshExchanges({announce = false} = {}) {
    busy('exchanges', true);
    try {
      const result = await api('/api/v1/exchanges');
      state.exchanges = Array.isArray(result.exchanges) ? result.exchanges : [];
      renderExchanges();
      if (announce) setStatus(`Handoff list refreshed · ${state.exchanges.length} active`, 'good');
    } catch (error) { setStatus(error.message, 'error'); }
    finally { busy('exchanges', false); }
  }

  async function previewExchange(event) {
    event?.preventDefault?.();
    const folder = $('#exchange-folder').value;
    if (!folder) { setStatus('Choose one folder to share.', 'error'); $('#exchange-folder').focus(); return; }
    busy('exchange-preview', true);
    try {
      state.exchangePreview = await api('/api/v1/exchange-previews', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          folder,
          curator: $('#exchange-curator').value,
          note: $('#exchange-note').value,
          publicUpdateUrl: $('#exchange-public-url').value.trim(),
          includeRecentUpdates: $('#exchange-updates').checked,
        }),
      });
      state.exchange = null;
      renderExchangePreview();
      renderExchangeReady();
      setStatus('Share reviewed locally · no listed site contacted · no library change', 'good');
    } catch (error) { setStatus(error.message, 'error'); }
    finally { busy('exchange-preview', false); }
  }

  async function createExchange() {
    const preview = state.exchangePreview;
    if (!preview) return;
    busy('exchange-create', true);
    try {
      state.exchange = await api('/api/v1/exchanges', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({previewToken: preview.previewToken, previewDigest: preview.previewDigest, librarySha256: preview.library?.sha256}),
      });
      state.exchangePreview = null;
      renderExchangePreview();
      renderExchangeReady();
      await refreshExchanges();
      $('#exchange-url').focus(); $('#exchange-url').select();
      setStatus('Thirty-minute handoff created. No private reading state was included.', 'good');
    } catch (error) { setStatus(error.message, 'error'); }
    finally { busy('exchange-create', false); }
  }

  function changeExchangeSelection() {
    state.exchangePreview = null;
    state.exchange = null;
    renderExchangePreview(); renderExchangeReady();
    $('#exchange-form').hidden = false;
    $('#exchange-folder').focus();
    setStatus('Share review cleared. Nothing was sent or changed.', '');
  }

  async function copyExchange() {
    const input = $('#exchange-url');
    if (!input.value) return;
    try { await navigator.clipboard.writeText(input.value); setStatus('Handoff copied. Paste it into ProgRSS Extension.', 'good'); }
    catch { input.focus(); input.select(); setStatus('The handoff is selected. Copy it with your browser or keyboard.', ''); }
  }

  async function downloadExchangeArtifact(kind) {
    const exchange = state.exchange;
    if (!exchange?.exchangeId) return;
    try {
      const result = await apiBlob(`/api/v1/exchange-artifact?id=${encodeURIComponent(exchange.exchangeId)}&kind=${encodeURIComponent(kind)}`);
      const url = URL.createObjectURL(result.blob);
      const link = document.createElement('a'); link.href = url; link.download = result.filename; link.click();
      setTimeout(() => URL.revokeObjectURL(url), 0);
      setStatus(`${result.filename} prepared from the reviewed copy. The library was not changed.`, 'good');
    } catch (error) { setStatus(error.message, 'error'); }
  }

  async function downloadExchangeFieldbook() {
    const exchange = state.exchange;
    if (!exchange?.exchangeId) return;
    busy('exchange-fieldbook', true);
    const message = $('#exchange-fieldbook-status');
    message.textContent = 'Preparing one private recipient-study sheet…';
    try {
      const artifact = await apiBlob('/api/v1/exchange-fieldwork-kits', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({exchangeId: exchange.exchangeId}),
      });
      downloadBlob(artifact.blob, artifact.filename);
      message.textContent = 'Recipient Fieldbook downloaded locally · no invitation secret or route identity included';
      setStatus('Private Exchange fieldwork sheet downloaded · the handoff and both libraries were unchanged', 'good');
    } catch (error) {
      message.textContent = '';
      setStatus(error.message, 'error');
    } finally { busy('exchange-fieldbook', false); }
  }

  async function downloadExchangeSenderFieldbook() {
    const preview = state.exchangePreview;
    if (!preview?.previewToken) return;
    busy('exchange-sender-fieldbook', true);
    const message = $('#exchange-sender-fieldbook-status');
    message.textContent = 'Preparing one private sender-study sheet…';
    try {
      const artifact = await apiBlob('/api/v1/exchange-sender-fieldwork-kits', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({previewToken: preview.previewToken}),
      });
      downloadBlob(artifact.blob, artifact.filename);
      message.textContent = 'Sender Fieldbook downloaded locally · no route identity, public address, library digest, or preview secret included';
      setStatus('Private sender fieldwork sheet downloaded · the preview and library were unchanged', 'good');
    } catch (error) {
      message.textContent = '';
      setStatus(error.message, 'error');
    } finally { busy('exchange-sender-fieldbook', false); }
  }

  async function sharePublicPage() {
    const url = $('#share-public-page').dataset.url || '';
    if (!url || typeof navigator.share !== 'function') return;
    const data = {title: text(state.exchange?.title, 'ProgRSS source route'), text: 'Follow updates, add the complete source route, or take one branch.', url};
    try {
      if (typeof navigator.canShare === 'function' && !navigator.canShare(data)) throw new Error('This browser cannot share that public page. Copy the address instead.');
      await navigator.share(data);
      setStatus('The public page was handed to your browser’s share sheet.', 'good');
    } catch (error) {
      if (error?.name !== 'AbortError') setStatus(error.message || 'The public page was not shared.', 'error');
    }
  }

  async function revokeExchange(exchange) {
    if (!confirm(`Revoke the handoff for ${text(exchange.title, 'this route')}? No library will be changed.`)) return;
    try {
      await api('/api/v1/exchanges/revoke', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({exchangeId: exchange.exchangeId})});
      state.exchanges = state.exchanges.filter(row => row.exchangeId !== exchange.exchangeId);
      if (state.exchange?.exchangeId === exchange.exchangeId) changeExchangeSelection();
      renderExchanges();
      setStatus('Handoff revoked. The prepared artifacts are no longer available from this Node.', 'good');
    } catch (error) { setStatus(error.message, 'error'); }
  }

  function mergeValue(value) {
    if (value == null || value === '') return 'Not supplied';
    if (typeof value !== 'object') return text(value, 'Not supplied');
    if (value.present === false) return 'Not present';
    if ('fingerprint' in value || 'host' in value || 'type' in value) {
      const parts = [];
      if (value.type) parts.push(value.type === 'rss' ? 'Feed' : value.type === 'page' ? 'Watched page' : text(value.type));
      if (value.host) parts.push(text(value.host));
      if (value.mode && value.mode !== 'text') parts.push(`mode ${text(value.mode)}`);
      if (value.selectorPresent) parts.push('region selector');
      if (value.linkSelectorPresent) parts.push('link selector');
      if (value.includePresent) parts.push('include filter');
      if (value.excludePresent) parts.push('exclude filter');
      return parts.join(' · ') || 'Recipe present';
    }
    try { return JSON.stringify(value); } catch { return 'Structured value'; }
  }

  function mergeSourceNoteValue(value) {
    const supplied = value != null && value !== '';
    return h('strong', {
      class: `merge-source-note-value${supplied ? '' : ' absent'}`,
      dir: 'auto',
      text: supplied ? String(value) : 'No reason on this placement',
    });
  }

  function mergeComparison(row) {
    const sourceNote = row?.kind === 'source-note';
    const labels = sourceNote
      ? [['Last accepted curator reason', 'baseline'], ['Keep mine', 'local'], ['Use curator’s', 'incoming']]
      : [['Last accepted', 'baseline'], ['Your library', 'local'], ['Curator copy', 'incoming']];
    const grid = h('div', {class: `merge-comparison${sourceNote ? ' source-note' : ''}`});
    for (const [label, key] of labels) {
      grid.append(h('div', {class: `merge-value merge-value-${key}`}, [
        h('span', {text: label}),
        sourceNote ? mergeSourceNoteValue(row?.[key]) : h('strong', {text: mergeValue(row?.[key])}),
      ]));
    }
    return grid;
  }

  function mergeEntry(row, kind = '') {
    const sourceNote = row?.kind === 'source-note';
    const card = h('article', {class: `merge-entry ${kind}${sourceNote ? ' source-note' : ''}`.trim()});
    card.append(h('div', {class: 'merge-entry-heading'}, [
      h('div', {}, [h('span', {class: 'merge-kind', text: text(row?.fieldLabel || row?.kind, 'Reviewed change')}), h('h5', {text: text(row?.label, 'Untitled route item')})]),
      kind === 'conflict' ? h('span', {class: 'merge-decision', text: 'Needs your choice'}) : null,
      kind === 'recipe' ? h('span', {class: 'merge-decision recipe', text: 'Affects fetching'}) : null,
    ]));
    card.append(h('p', {text: text(row?.summary, 'This copy differs from the local route.')}));
    if (sourceNote) {
      const route = text(row?.folderPath || row?.placement?.folderPath || row?.folderLabel || row?.placement?.folderId, 'Folder route unavailable');
      card.append(h('p', {class: 'merge-source-note-route', text: `Folder route: ${route}`}));
      card.append(h('p', {class: 'merge-source-note-boundary', text: 'Curator’s reason for this folder belongs to one direct folder/source placement. It is not a ProgRSS safety claim. Keep mine preserves your library value; Use curator’s adopts the curator copy. This read-only Node review applies neither choice.'}));
    }
    if (kind === 'recipe') {
      const oldHost = text(row?.oldHost || row?.baseline?.host, 'previous host');
      const newHost = text(row?.newHost || row?.incoming?.host, 'new host');
      card.append(h('div', {class: 'merge-route'}, [h('span', {text: oldHost}), h('span', {'aria-hidden': 'true', text: '→'}), h('span', {text: newHost})]));
      card.append(h('p', {class: 'merge-consequence', text: row?.reusesExisting ? 'The matching local source would be reused.' : 'The changed recipe would become a separate paused source; earlier history stays local.'}));
    }
    if (kind === 'conflict' || kind === 'recipe') {
      card.append(mergeComparison(row));
    } else {
      const details = h('details', {class: 'merge-evidence'}, [h('summary', {text: 'See comparison'}), mergeComparison(row)]);
      card.append(details);
    }
    return card;
  }

  function mergeGroup(title, rows, className = '') {
    const details = h('details', {class: `merge-group ${className}`.trim()});
    details.append(h('summary', {}, [h('strong', {text: title}), h('span', {text: String(rows.length)})]));
    const list = h('div', {class: 'merge-group-list'});
    for (const row of rows) list.append(mergeEntry(row));
    details.append(list);
    return details;
  }

  function renderMergeReview() {
    const result = $('#merge-result');
    const form = $('#merge-form');
    const response = state.mergeReview;
    result.hidden = !response;
    form.hidden = Boolean(response);
    if (!response) return;
    const review = response.review || {};
    const merge = review.mergeReview || {};
    const counts = merge.counts || {};
    $('#merge-library').textContent = `${text(response.library?.file, 'selected backup')} · read-only`;
    $('#merge-message').textContent = review.mode === 'current'
      ? `${text(review.localTitle || review.title, 'This route')} already matches the selected copy.`
      : review.canUpdate
        ? `${text(review.localTitle || review.title, 'Imported route')} can be reviewed as a later copy. The Node has not applied anything.`
        : text(review.reason, 'This file cannot be safely treated as a later copy of an imported route.');

    const countRows = [
      ['Curator only', counts.curatorOnly, 'curator'], ['Yours only', counts.recipientOnly, 'local'],
      ['Both agree', counts.agreed, 'agreed'], ['Need a choice', counts.conflicts, 'conflict'],
      ['Added', counts.additions, 'added'], ['Removed', counts.removals, 'removed'],
      ['Recipe changes', counts.recipeChanges, 'recipe'],
    ];
    $('#merge-counts').replaceChildren(...countRows.map(([label, value, kind]) => h('div', {class: `merge-count ${kind}`}, [h('strong', {text: String(Number(value) || 0)}), h('span', {text: label})])));

    const priority = $('#merge-priority');
    priority.replaceChildren();
    const conflicts = Array.isArray(merge.conflicts) ? merge.conflicts : [];
    const recipes = Array.isArray(merge.recipeChanges) ? merge.recipeChanges : [];
    if (conflicts.length) {
      priority.append(h('section', {class: 'merge-priority-section'}, [h('div', {class: 'merge-section-heading'}, [h('span', {class: 'step', text: 'Decide later'}), h('h5', {text: 'Both sides changed the same wording differently'})]), ...conflicts.map(row => mergeEntry(row, 'conflict'))]));
    }
    if (recipes.length) {
      priority.append(h('section', {class: 'merge-priority-section recipe'}, [h('div', {class: 'merge-section-heading'}, [h('span', {class: 'step', text: 'Review carefully'}), h('h5', {text: 'The curator changed how a source is checked'})]), ...recipes.map(row => mergeEntry(row, 'recipe'))]));
    }
    if (!conflicts.length && !recipes.length) {
      priority.append(h('div', {class: 'merge-calm'}, [h('strong', {text: review.mode === 'current' ? 'No differences need review.' : 'No conflict or acquisition change needs a decision.'}), h('p', {text: 'Curator-only and local-only changes are summarized below. Nothing has been written.'})]));
    }

    const secondary = $('#merge-secondary');
    secondary.replaceChildren();
    const groups = [
      ['Changed only by curator', merge.curatorOnly || [], 'curator'],
      ['Changed only in your library', merge.recipientOnly || [], 'local'],
      ['Same change on both sides', merge.agreed || [], 'agreed'],
      ['Added by curator', merge.additions || [], 'added'],
      ['Removed from curator copy', merge.removals || [], 'removed'],
    ];
    for (const [title, rows, kind] of groups) if (Array.isArray(rows) && rows.length) secondary.append(mergeGroup(title, rows, kind));
    const omitted = merge.omitted || {};
    const omittedCount = Object.values(omitted).reduce((sum, value) => sum + (Number(value) || 0), 0);
    if (omittedCount) secondary.append(h('p', {class: 'field-note', text: `${omittedCount} additional bounded review row(s) were omitted from this compact Node view. Use CLI JSON for complete machine-readable evidence.`}));
    $('#merge-result-heading').focus();
  }

  async function reviewMerge(event) {
    event?.preventDefault?.();
    const file = $('#merge-file').files?.[0];
    if (!file) { setStatus('Choose one later ProgRSS source-list file.', 'error'); $('#merge-file').focus(); return; }
    if (file.size > 650000) { setStatus('That source-list file is larger than the 650 KB review limit.', 'error'); return; }
    busy('merge-review', true);
    try {
      const raw = await file.text();
      let bundle;
      try { bundle = JSON.parse(raw); } catch { throw new Error('The selected file is not valid UTF-8 JSON.'); }
      if (!bundle || typeof bundle !== 'object' || Array.isArray(bundle)) throw new Error('Choose one ProgRSS source-list JSON object.');
      state.mergeReview = await api('/api/v1/merge-reviews', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({bundle, folder: $('#merge-folder').value.trim()}),
      });
      renderMergeReview();
      setStatus('Later copy reviewed locally · no listed site contacted · no library change', 'good');
    } catch (error) { setStatus(error.message, 'error'); }
    finally { busy('merge-review', false); }
  }

  function clearMergeReview() {
    state.mergeReview = null;
    $('#merge-file').value = '';
    renderMergeReview();
    $('#merge-file').focus();
    setStatus('Merge review cleared. The backup was never changed.', '');
  }

  function setView(view, focus = false) {
    state.view = ['today', 'sources', 'curate'].includes(view) ? view : 'today';
    $$('.view').forEach(node => { node.hidden = node.id !== `view-${state.view}`; });
    $$('[data-view]').forEach(button => button.setAttribute('aria-current', button.dataset.view === state.view ? 'page' : 'false'));
    history.replaceState(null, '', `#${state.view}`);
    if (focus) $(`#${state.view}-heading`)?.focus?.();
  }

  function applyTheme(theme) {
    const next = theme === 'light' ? 'light' : 'dark';
    document.documentElement.dataset.theme = next;
    localStorage.setItem('progrss-node-theme', next);
    const button = $('#theme-toggle');
    const label = next === 'dark' ? 'Use light theme' : 'Use dark theme';
    button.setAttribute('aria-label', label); button.title = label;
    button.firstElementChild.textContent = next === 'dark' ? '☼' : '☾';
  }

  async function start() {
    applyTheme(localStorage.getItem('progrss-node-theme') || 'dark');
    state.token = parseCapability();
    $$('[data-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.view, true)));
    $$('[data-filter]').forEach(button => button.addEventListener('click', () => {
      state.filter = button.dataset.filter;
      $$('[data-filter]').forEach(row => row.setAttribute('aria-pressed', String(row === button)));
      renderItems();
    }));
    $('#search').addEventListener('input', event => { state.query = event.target.value; renderItems(); });
    $('#theme-toggle').addEventListener('click', () => applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'));
    $('#witness-confirm').addEventListener('change', () => busy('acquisition-confirm', false));
    $('#commit-witness').addEventListener('click', commitWitness);
    $('#cancel-witness').addEventListener('click', cancelWitness);
    $('#another-witness').addEventListener('click', anotherWitness);
    $('#keep-bearing').addEventListener('click', keepBearing);
    $('#bearing-fieldbook').addEventListener('click', downloadFieldbook);
    $('#bearing-debrief').addEventListener('click', downloadDebrief);
    $('#open-bearing-anchor').addEventListener('click', openAnchorFromBearing);
    $('#open-bearing-capture').addEventListener('click', openCaptureFromBearing);
    $('#baseline-confirm').addEventListener('change', () => busy('baseline-confirm', false));
    $('#commit-baseline').addEventListener('click', commitBaseline);
    $('#cancel-baseline').addEventListener('click', cancelBaseline);
    $('#download-baseline-snapshot').addEventListener('click', downloadBaselineSnapshot);
    $('#another-baseline').addEventListener('click', anotherBaseline);
    $('#copy-capture').addEventListener('click', copyCaptureInvitation);
    $('#close-capture').addEventListener('click', closeCaptureInvitation);
    $('#operation-file').addEventListener('change', loadOperationFile);
    $('#operation-branch').addEventListener('change', () => { $('#review-operation').disabled = !$('#operation-branch').value || state.busy.has('operation-preview'); });
    $('#operation-form').addEventListener('submit', reviewOperation);
    $('#operation-confirm').addEventListener('change', () => { $('#commit-operation').disabled = !$('#operation-confirm').checked || state.busy.has('operation-commit'); });
    $('#commit-operation').addEventListener('click', commitOperation);
    $('#change-operation').addEventListener('click', changeOperation);
    $('#download-operation-snapshot').addEventListener('click', downloadOperationSnapshot);
    $('#another-operation').addEventListener('click', anotherOperation);
    $('#merge-form').addEventListener('submit', reviewMerge);
    $('#clear-merge').addEventListener('click', clearMergeReview);
    $('#exchange-form').addEventListener('submit', previewExchange);
    $('#create-exchange').addEventListener('click', createExchange);
    $('#change-exchange').addEventListener('click', changeExchangeSelection);
    $('#copy-exchange').addEventListener('click', copyExchange);
    $('#download-source-list').addEventListener('click', () => downloadExchangeArtifact('source-list'));
    $('#download-updates').addEventListener('click', () => downloadExchangeArtifact('recent-updates'));
    $('#download-site').addEventListener('click', () => downloadExchangeArtifact('site'));
    $('#share-public-page').addEventListener('click', sharePublicPage);
    $('#exchange-sender-fieldbook').addEventListener('click', downloadExchangeSenderFieldbook);
    $('#exchange-fieldbook').addEventListener('click', downloadExchangeFieldbook);
    $('#refresh-exchanges').addEventListener('click', () => refreshExchanges({announce: true}));
    $('#create-pairing').addEventListener('click', createInvitation);
    $('#copy-pairing').addEventListener('click', copyInvitation);
    $('#refresh-pairings').addEventListener('click', () => refreshPairings({announce: true}));
    $('#stop-node').addEventListener('click', async () => {
      if (!confirm('Stop this local ProgRSS Node? No library data will be changed by stopping it.')) return;
      try { await api('/api/v1/stop', {method: 'POST', body: '{}', headers: {'Content-Type': 'application/json'}}); setStatus('Node stopped. Pairings ended; you can close this tab.', 'good'); }
      catch (error) { setStatus(error.message, 'error'); }
    });
    setView(location.hash.slice(1) || 'today');
    try {
      const [status, library, pairingList, curation, exchangeList, operationList, acquisitionList] = await Promise.all([
        api('/api/v1/status'), api('/api/v1/library'), api('/api/v1/pairings'),
        api('/api/v1/curation'), api('/api/v1/exchanges'), api('/api/v1/operations'),
        api('/api/v1/acquisitions'),
      ]);
      state.status = status;
      state.library = library;
      state.pairings = Array.isArray(pairingList.pairings) ? pairingList.pairings : [];
      state.curation = curation;
      state.exchanges = Array.isArray(exchangeList.exchanges) ? exchangeList.exchanges : [];
      state.operations = Array.isArray(operationList.operations) ? operationList.operations : [];
      state.acquisitions = Array.isArray(acquisitionList.receipts) ? acquisitionList.receipts : [];
      state.acquisitionJobs = Array.isArray(acquisitionList.jobs) ? acquisitionList.jobs : [];
      $('#stat-unread').textContent = library.stats.unread;
      $('#stat-sources').textContent = library.stats.sources;
      $('#stat-watches').textContent = library.stats.pageWatches;
      const nodeOwned = library.library?.mode === 'node-owned';
      $('#hero-copy').textContent = nodeOwned
        ? `Node owns ${library.library.file}. Review one source check, ask the Extension for one rendered-page capture, understand repeated held windows, replace one held baseline, or adopt one reviewed branch. Nothing runs on a schedule.`
        : `Reading exported backup ${library.library.file}. Sharing and review are available; create a Node-owned library to enable reviewed writes and source checks.`;
      renderItems(); renderSources(); renderWitnessMode(); renderWitnessPreview(); renderWitnessResult(); renderBaselinePreview(); renderBaselineResult(); renderCaptureInvitation(); renderWitnessHistory(); renderCuration(); renderOperationMode(); renderBranchOptions(); renderOperationPreview(); renderOperationResult(); renderOperations(); renderMergeReview(); renderExchangePreview(); renderExchangeReady(); renderExchanges(); renderPairings(); renderInvitation(); renderFacts(status);
      setStatus(nodeOwned
        ? `Local Node-owned library ready · revision ${library.library.revision} · manual checks, browser capture, Bearing diagnosis, and Anchor review available · scheduler off`
        : `Local exported backup ready · read-only · exchange and later-copy review available · nothing fetched or changed`, 'good');
    } catch (error) {
      $('#item-list').replaceChildren(h('div', {class: 'empty'}, [h('strong', {text: 'This node could not open the library'}), h('p', {text: error.message})]));
      setStatus(error.message, 'error');
      $('#node-pill').textContent = 'Node locked';
    }
  }

  start();
})();
