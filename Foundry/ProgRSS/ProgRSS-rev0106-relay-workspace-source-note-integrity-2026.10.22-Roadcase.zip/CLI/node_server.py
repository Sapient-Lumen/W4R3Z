#!/usr/bin/env python3
"""Loopback-only ProgRSS Node web server.

The Node can open either one explicit read-only ProgRSS private backup or one
transactional Node-owned library. Its writable web surface contains narrowly typed,
reviewed operations: one source-list branch adoption, one explicit source check, one bounded browser-assisted page capture, and one held-baseline replacement. It also exposes read-only held-window diagnosis and private fieldwork-sheet generation.
Pairing remains summary-only and cannot invoke either writer.
The bearer capability travels in the URL fragment, so it is not sent in the initial
HTTP request or written to ordinary server logs.
"""

from __future__ import annotations

import base64
import copy
import dataclasses
import hashlib
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import hmac
import json
import mimetypes
from pathlib import Path
import re
import secrets
import threading
import time
from datetime import datetime, timezone
from typing import Any, Mapping
import urllib.parse
import webbrowser

try:
    from .source_notes_native import SourceNoteError, validate_private_source_note_placements
except ImportError:  # Direct CLI execution from this directory.
    from source_notes_native import SourceNoteError, validate_private_source_note_placements

from acquisition import (
    ACQUISITION_PREVIEW_SCHEMA, ACQUISITION_RESULT_SCHEMA, AcquisitionError,
    BROWSER_CAPTURE_SCHEMA, MAX_BROWSER_CAPTURE_BYTES,
    DEFAULT_TIMEOUT, MAX_REDIRECTS, apply_browser_capture, apply_failure, apply_fetch,
    acquisition_source_identity, browser_capture_provenance, browser_capture_snapshot,
    fetch_public_resource, page_recipe, page_recipe_digest, replace_browser_capture_baseline,
    source_preview, validate_browser_capture,
)
from exchange import EXCHANGE_SCHEMA, ExchangeError, PreparedExchange, prepare_exchange
from fieldbook import (
    FIELDWORK_KIT_SCHEMA, FieldbookError, build_exchange_fieldwork_scenario,
    build_exchange_sender_fieldwork_scenario,
    build_trace_fieldwork_scenario, render_fieldbook_html,
)
from debrief import (
    DEBRIEF_KIT_SCHEMA, DebriefError, build_debrief_workspace, render_debrief_html,
)
from node_store import (
    BASELINE_REPLACEMENT_OPERATION, NodeStore, NodeStoreConflict, NodeStoreError, OPERATION_RESULT_SCHEMA,
    STORE_SCHEMA, is_node_store,
)
from progrss import MAX_FEED_BYTES
from relay import (
    MAX_BUNDLE_BYTES, RelayError, _connected_bundle, _source_acquisition_key,
    bundle_contents, bundle_provenance, canonical_json, import_bundle,
    review_bundle_update, select_bundle_section, validate_bundle,
)

VERSION = "0.80.0"
REVISION = "rev0080"
CODENAME = "Roadcase"
READY_SCHEMA = "progrss.node.ready.v1"
STATUS_SCHEMA = "progrss.node.status.v1"
LIBRARY_SCHEMA = "progrss.node.library.v1"
CAPABILITIES_SCHEMA = "progrss.node.capabilities.v1"
PAIRING_SCHEMA = "progrss.node.pairing.v1"
BACKUP_SCHEMA = "progrss.private.v1"
MAX_BACKUP_BYTES = 24_000_000
MAX_SOURCES = 200
MAX_COLLECTIONS = 200
MAX_ITEMS = 1_200
MAX_REQUEST_BYTES = 8_192
MAX_BUNDLE_REQUEST_BYTES = MAX_BUNDLE_BYTES + 32_768
MAX_MERGE_REVIEW_REQUEST_BYTES = MAX_BUNDLE_REQUEST_BYTES
MERGE_REVIEW_NODE_SCHEMA = "progrss.node.merge-review.v1"
BRANCH_OPTIONS_SCHEMA = "progrss.node.branch-options.v1"
OPERATION_PREVIEW_SCHEMA = "progrss.node.operation-preview.v1"
OPERATION_TYPE_ADOPT_BRANCH = "adopt-source-list-branch"
BASELINE_PREVIEW_SCHEMA = "progrss.node.baseline-preview.v1"
BEARING_REVIEW_SCHEMA = "progrss.node.bearing-review.v2"
BEARING_HISTORY_SCHEMA = "progrss.node.capture-hold-history.v1"
BEARING_TRACE_SCHEMA = "progrss.node.bearing-trace.v1"
RECIPE_FOOTPRINT_SCHEMA = "progrss.node.recipe-footprint.v1"
MAX_BEARING_PRIOR_OBSERVATIONS = 8
BASELINE_TTL_SECONDS = 10 * 60
OPERATION_TTL_SECONDS = 10 * 60
ACQUISITION_TTL_SECONDS = 10 * 60
ACQUISITION_TYPE_CHECK_ONCE = "check-source-once"
CAPTURE_SCHEMA = "progrss.node.capture.v1"
CAPTURE_ARTIFACT_SCHEMA = BROWSER_CAPTURE_SCHEMA
CAPTURE_TYPE_RENDERED_PAGE = "capture-rendered-page-once"
CAPTURE_TTL_SECONDS = 10 * 60
MAX_CAPTURE_REQUEST_BYTES = MAX_BROWSER_CAPTURE_BYTES + 32_768
PAIRING_TTL_SECONDS = 10 * 60
EXCHANGE_PREVIEW_TTL_SECONDS = 10 * 60
EXCHANGE_TTL_SECONDS = 30 * 60
WEB_ROOT = Path(__file__).resolve().parent / "node_web"


class NodeError(Exception):
    """Expected local node failure."""


def _read_backup(path: Path) -> tuple[dict[str, Any], bytes]:
    try:
        raw = path.read_bytes()
    except OSError as exc:
        raise NodeError(f"could not read {path}: {exc}") from exc
    if len(raw) > MAX_BACKUP_BYTES:
        raise NodeError("the private backup is larger than the 24 MB node limit")
    try:
        document = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise NodeError("the selected file is not UTF-8 ProgRSS JSON") from exc
    if not isinstance(document, dict) or document.get("schema") != BACKUP_SCHEMA:
        raise NodeError(f"expected {BACKUP_SCHEMA}")
    state = document.get("state")
    if not isinstance(state, dict):
        raise NodeError("the private backup has no state object")
    for key, limit in (("sources", MAX_SOURCES), ("collections", MAX_COLLECTIONS), ("items", MAX_ITEMS)):
        value = state.get(key, [])
        if not isinstance(value, list):
            raise NodeError(f"state.{key} must be an array")
        if len(value) > limit:
            raise NodeError(f"state.{key} exceeds the node limit of {limit}")
    try:
        validate_private_source_note_placements(state)
    except SourceNoteError as exc:
        raise NodeError(f"the private backup has invalid Source Notes: {exc}") from exc
    return document, raw


def _safe_text(value: Any, limit: int = 2_048) -> str:
    return " ".join(str(value or "").split())[:limit]


def _canonical_sha256(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def _snapshot_summary(value: Mapping[str, Any] | None) -> dict[str, Any]:
    snapshot = value if isinstance(value, Mapping) else {}
    mode = _safe_text(snapshot.get("mode"), 20)
    if mode == "cards":
        rows = snapshot.get("entries") if isinstance(snapshot.get("entries"), list) else snapshot.get("keys") if isinstance(snapshot.get("keys"), list) else []
        units = len(rows)
        label = "visible records"
    else:
        words = str(snapshot.get("text") or "").split()
        units = len(words)
        label = "visible words"
    return {
        "mode": mode or "unknown",
        "units": max(0, int(units)),
        "unitLabel": label,
        "capturedAt": _safe_text(snapshot.get("capturedAt"), 80),
        "sha256": _canonical_sha256(snapshot) if snapshot else "",
    }


def _snapshot_comparison(left: Mapping[str, Any] | None, right: Mapping[str, Any] | None) -> dict[str, Any]:
    """Return bounded overlap evidence between two held observations."""
    left_value = left if isinstance(left, Mapping) else {}
    right_value = right if isinstance(right, Mapping) else {}
    left_mode = _safe_text(left_value.get("mode"), 20)
    right_mode = _safe_text(right_value.get("mode"), 20)
    shared = 0
    left_units = 0
    right_units = 0
    enough = False
    if left_mode == right_mode == "cards":
        def keys(value: Mapping[str, Any]) -> set[str]:
            rows = value.get("entries") if isinstance(value.get("entries"), list) else []
            result = {_safe_text(row.get("key"), 600) for row in rows if isinstance(row, Mapping) and _safe_text(row.get("key"), 600)}
            if not result and isinstance(value.get("keys"), list):
                result = {_safe_text(row, 600) for row in value.get("keys", []) if _safe_text(row, 600)}
            return result
        left_set, right_set = keys(left_value), keys(right_value)
        left_units, right_units = len(left_set), len(right_set)
        shared = len(left_set & right_set)
        enough = min(left_units, right_units) >= 2
    elif left_mode == right_mode == "region":
        def tokens(value: Mapping[str, Any]) -> set[str]:
            return set(re.findall(r"[^\W_]+", str(value.get("text") or "").casefold(), flags=re.UNICODE)[:4_000])
        left_set, right_set = tokens(left_value), tokens(right_value)
        left_units, right_units = len(left_set), len(right_set)
        shared = len(left_set & right_set)
        enough = min(left_units, right_units) >= 8
    denominator = min(left_units, right_units)
    overlap = shared / denominator if denominator else (1.0 if left_units == right_units else 0.0)
    smaller = min(left_units, right_units)
    larger = max(left_units, right_units)
    similar_size = bool(smaller and larger <= max(smaller + 2, round(smaller * 1.5)))
    return {
        "mode": left_mode if left_mode == right_mode else "mixed",
        "leftUnits": min(left_units, 200_000),
        "rightUnits": min(right_units, 200_000),
        "sharedUnits": min(shared, 200_000),
        "overlapPercent": max(0, min(100, round(overlap * 100))),
        "enoughEvidence": enough,
        "similarSize": similar_size,
    }


def _bearing_boundary_kinds(observation: Mapping[str, Any]) -> list[str]:
    provenance = observation.get("proposedProvenance") if isinstance(observation.get("proposedProvenance"), Mapping) else {}
    values = provenance.get("pageContextKinds") if isinstance(provenance.get("pageContextKinds"), list) else []
    if not values:
        continuity = observation.get("continuity") if isinstance(observation.get("continuity"), Mapping) else {}
        values = continuity.get("currentBoundaryKinds") if isinstance(continuity.get("currentBoundaryKinds"), list) else []
    allowed = {"continuation", "partial-render", "overlay", "loading", "frames", "open-shadow"}
    return [value for value in (_safe_text(row, 40) for row in values) if value in allowed][:6]


def _bearing_diagnosis(current: Mapping[str, Any], history: list[dict[str, Any]]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Explain repeated unresolved holds without claiming publisher intent."""
    current_identity = _safe_text(current.get("sourceIdentitySha256"), 64)
    current_baseline = _safe_text(current.get("acceptedSnapshotSha256"), 64)
    compatible = [
        row for row in history
        if hmac.compare_digest(_safe_text(row.get("sourceIdentitySha256"), 64), current_identity)
        and hmac.compare_digest(_safe_text(row.get("acceptedSnapshotSha256"), 64), current_baseline)
    ][:MAX_BEARING_PRIOR_OBSERVATIONS]
    current_boundaries = tuple(_bearing_boundary_kinds(current))
    comparisons: list[dict[str, Any]] = []
    boundary_shift = False
    current_continuity = current.get("continuity") if isinstance(current.get("continuity"), Mapping) else {}
    if current_continuity.get("reason") == "partial-render-boundary-changed" or current_continuity.get("boundaryChanged"):
        boundary_shift = True
    for row in compatible:
        comparison = _snapshot_comparison(current.get("proposedSnapshot"), row.get("proposedSnapshot"))
        comparison.update({
            "priorOperationId": _safe_text(row.get("captureOperationId"), 200),
            "priorReceiptId": _safe_text(row.get("captureReceiptId"), 200),
            "priorHeldAt": _safe_text(row.get("heldAt"), 80),
            "priorBoundaryKinds": _bearing_boundary_kinds(row),
        })
        comparisons.append(comparison)
        if tuple(comparison["priorBoundaryKinds"]) != current_boundaries:
            boundary_shift = True
        prior_continuity = row.get("continuity") if isinstance(row.get("continuity"), Mapping) else {}
        if prior_continuity.get("reason") == "partial-render-boundary-changed" or prior_continuity.get("boundaryChanged"):
            boundary_shift = True

    low_disjoint = [
        row for row in comparisons
        if row.get("enoughEvidence") and row.get("similarSize") and int(row.get("overlapPercent") or 0) < 35
    ]
    if boundary_shift and compatible:
        diagnosis = {
            "kind": "page-boundary-shifted",
            "title": "Page boundary shifted",
            "summary": "Recent held observations do not expose the same page boundary. Pagination, partial rendering, overlays, loading state, or frame exclusions changed between observations.",
            "cannotProve": "This does not prove that the publisher removed or added records, or that any particular selector is wrong.",
            "recommendedRoute": "capture",
            "observationsReviewed": 1 + len(compatible),
        }
    elif low_disjoint:
        diagnosis = {
            "kind": "moving-rendered-window",
            "title": "Moving rendered window",
            "summary": "Several similarly sized partial observations expose substantially different records. The browser may be showing different windows into one larger collection.",
            "cannotProve": "This does not prove that the collection is unchanged, that records still exist off screen, or that the page will keep this structure.",
            "recommendedRoute": "anchor",
            "observationsReviewed": 1 + len(compatible),
        }
    else:
        diagnosis = {
            "kind": "insufficient-evidence",
            "title": "Not enough evidence yet",
            "summary": "ProgRSS has too few compatible held observations, or their signals do not form one clear pattern.",
            "cannotProve": "One held window cannot establish whether the viewport moved, the page boundary changed, or the publisher changed the underlying records.",
            "recommendedRoute": "keep",
            "observationsReviewed": 1 + len(compatible),
        }
    diagnosis["compatiblePriorObservations"] = len(compatible)
    diagnosis["boundaryKinds"] = list(current_boundaries)
    diagnosis["lowOverlapComparisons"] = len(low_disjoint)
    return diagnosis, comparisons


def _bearing_relationship(
    comparison: Mapping[str, Any],
    previous_boundaries: list[str],
    current_boundaries: list[str],
) -> dict[str, str]:
    """Turn pairwise evidence into one bounded human-readable relationship."""
    if tuple(previous_boundaries) != tuple(current_boundaries):
        return {
            "kind": "boundary-shifted",
            "title": "Boundary changed",
            "summary": "The rendered page limits differ from the previous accepted or held observation.",
        }
    if not comparison.get("enoughEvidence"):
        return {
            "kind": "insufficient-evidence",
            "title": "Not enough evidence",
            "summary": "The two observations do not contain enough stable units for a strong comparison.",
        }
    overlap = int(comparison.get("overlapPercent") or 0)
    if comparison.get("similarSize") and overlap < 35:
        return {
            "kind": "different-window",
            "title": "Different window",
            "summary": "A similarly sized observation exposes substantially different stable units.",
        }
    if overlap >= 70:
        return {
            "kind": "substantial-overlap",
            "title": "Substantial overlap",
            "summary": "Most stable units from the smaller observation are still visible.",
        }
    return {
        "kind": "partial-overlap",
        "title": "Some overlap",
        "summary": "The observations share some stable units but do not expose the same rendered window.",
    }


def _bearing_trace(
    accepted: Mapping[str, Any],
    accepted_provenance: Mapping[str, Any] | None,
    current: Mapping[str, Any],
    history: list[dict[str, Any]],
) -> dict[str, Any]:
    """Build an oldest-to-newest, read-only observation trail."""
    chronological = [*reversed(history[:MAX_BEARING_PRIOR_OBSERVATIONS]), current]
    previous_snapshot: Mapping[str, Any] = accepted
    previous_boundaries = [
        _safe_text(row, 40) for row in (
            accepted_provenance.get("pageContextKinds", [])
            if isinstance(accepted_provenance, Mapping) and isinstance(accepted_provenance.get("pageContextKinds"), list)
            else []
        ) if _safe_text(row, 40)
    ][:6]
    rows: list[dict[str, Any]] = []
    for index, observation in enumerate(chronological, start=1):
        proposed = observation.get("proposedSnapshot") if isinstance(observation.get("proposedSnapshot"), Mapping) else {}
        comparison = _snapshot_comparison(proposed, previous_snapshot)
        boundaries = _bearing_boundary_kinds(observation)
        relationship = _bearing_relationship(comparison, previous_boundaries, boundaries)
        continuity = observation.get("continuity") if isinstance(observation.get("continuity"), Mapping) else {}
        provenance = observation.get("proposedProvenance") if isinstance(observation.get("proposedProvenance"), Mapping) else {}
        rows.append({
            "ordinal": index,
            "current": index == len(chronological),
            "heldAt": _safe_text(observation.get("heldAt"), 80),
            "snapshot": _snapshot_summary(proposed),
            "relationshipToPrevious": relationship,
            "overlapToPreviousPercent": int(comparison.get("overlapPercent") or 0),
            "sharedUnitsWithPrevious": int(comparison.get("sharedUnits") or 0),
            "enoughEvidence": bool(comparison.get("enoughEvidence")),
            "similarSize": bool(comparison.get("similarSize")),
            "overlapToAcceptedPercent": int(continuity.get("overlapPercent") or 0),
            "continuityReason": _safe_text(continuity.get("reason"), 80),
            "boundaryKinds": boundaries,
            "assessmentLevel": _safe_text(provenance.get("assessmentLevel"), 40),
            "assessmentSummary": _safe_text(provenance.get("assessmentSummary"), 300),
        })
        previous_snapshot = proposed
        previous_boundaries = boundaries
    return {
        "schema": BEARING_TRACE_SCHEMA,
        "accepted": _snapshot_summary(accepted),
        "observations": rows,
        "oldestFirst": True,
        "maximumPriorObservations": MAX_BEARING_PRIOR_OBSERVATIONS,
        "network": False,
        "writes": False,
    }


def _selector_footprint(source: Mapping[str, Any], current: Mapping[str, Any], diagnosis: Mapping[str, Any]) -> dict[str, Any]:
    """Describe what the saved declarative recipe depends on without changing it."""
    mode = _safe_text(source.get("mode"), 20) or "region"
    selector = _safe_text(source.get("selector"), 350)
    title_selector = _safe_text(source.get("titleSelector"), 200)
    link_selector = _safe_text(source.get("linkSelector"), 200)
    lowered = selector.casefold()
    positional = bool(re.search(r":(?:nth|first|last|only)-(?:child|of-type)|:nth-child|:nth-of-type", lowered))
    generated = bool(re.search(r"(?:^|[.#_-])(?:[a-f0-9]{10,}|[a-z_-]*\d{6,}[a-z0-9_-]*)(?:$|[.#_:\-\[\]])", lowered))
    data_contract = "[data-" in lowered
    role_contract = "[role=" in lowered or "[role~=" in lowered
    structured_contract = "[itemprop=" in lowered or ".h-entry" in lowered
    semantic = bool(re.search(r"(?:^|[\s>+~,])(main|article|section|nav|aside|ul|ol|li|table|tbody|tr)(?=$|[\s>+~.#:\[])", lowered))
    combinators = len(re.findall(r"\s[>+~]\s|[>+~]", selector)) + max(0, len(re.findall(r"\s+", selector.strip())) - 1)
    reasons: list[str] = []
    warnings: list[str] = []
    if not selector and mode == "region":
        kind, label = "primary-readable-region", "Primary readable region"
        reasons.append("The recipe falls back to the page's primary readable region rather than one exact CSS path.")
    elif positional or generated:
        kind, label = "implementation-detail", "Implementation-detail selector"
        if positional:
            warnings.append("The selector depends on a position such as nth-child, which can move when nearby markup changes.")
        if generated:
            warnings.append("The selector contains a generated-looking class or identifier that may be rebuilt by the publisher.")
    elif data_contract or role_contract or structured_contract:
        kind, label = "explicit-structure", "Explicit structural signal"
        if data_contract:
            reasons.append("The selector uses a data-* attribute supplied by the page.")
        if role_contract:
            reasons.append("The selector uses an explicit accessibility role.")
        if structured_contract:
            reasons.append("The selector uses structured-data or microformat markup.")
    elif semantic:
        kind, label = "semantic-boundary", "Semantic boundary"
        reasons.append("The selector uses semantic elements such as main, article, section, or list records.")
    elif selector.startswith((".", "#")):
        kind, label = "class-or-id", "Class or ID selector"
        warnings.append("Class and ID names can be implementation details unless the publisher treats them as a stable contract.")
    else:
        kind, label = "plain-structural", "Plain structural selector"
        reasons.append("The recipe uses a bounded CSS selector without a generated-looking token detected by ProgRSS.")
    if combinators >= 3:
        warnings.append("The selector follows a relatively deep DOM path, so surrounding layout changes may break it.")
    if mode == "cards" and not link_selector:
        warnings.append("Repeated records have no explicit link selector, so stable identity may depend more heavily on wording.")
    if mode == "cards" and title_selector:
        reasons.append("Repeated records include an explicit title selector.")
    provenance = current.get("proposedProvenance") if isinstance(current.get("proposedProvenance"), Mapping) else {}
    assessment_level = _safe_text(provenance.get("assessmentLevel"), 40)
    assessment_summary = _safe_text(provenance.get("assessmentSummary"), 300)
    if assessment_summary:
        reasons.append(assessment_summary)
    route = _safe_text(diagnosis.get("recommendedRoute"), 20) or "keep"
    route_text = {
        "anchor": "The current diagnosis points to Anchor because the page may be exposing another window of the same collection.",
        "capture": "The current diagnosis points to fresh Capture because the page boundary or watched section may need another observation.",
        "keep": "The current diagnosis does not justify changing the recipe or baseline yet.",
    }.get(route, "Keep the accepted baseline until another reviewed action is chosen.")
    summary = (
        "The saved recipe relies on page implementation details and deserves extra scrutiny before reuse."
        if kind == "implementation-detail"
        else "The saved recipe uses an understandable declarative boundary, but the publisher can still change it."
    )
    return {
        "schema": RECIPE_FOOTPRINT_SCHEMA,
        "kind": kind,
        "label": label,
        "summary": summary,
        "mode": mode,
        "reasons": reasons[:4],
        "warnings": warnings[:4],
        "lastCaptureAssessmentLevel": assessment_level,
        "lastCaptureAssessmentSummary": assessment_summary,
        "recommendedRoute": route,
        "routeExplanation": route_text,
        "network": False,
        "writes": False,
        "advanced": {
            "selector": selector,
            "titleSelector": title_selector,
            "linkSelector": link_selector,
            "positionalSelector": positional,
            "generatedLookingToken": generated,
            "combinatorCount": min(combinators, 50),
        },
    }


def _iso_sort_key(item: dict[str, Any]) -> str:
    return _safe_text(item.get("published") or item.get("observedAt") or item.get("createdAt"), 80)


def _host_for_url(value: Any) -> str:
    try:
        return str(urllib.parse.urlsplit(str(value or "")).hostname or "")
    except ValueError:
        return ""


def _simple_folder_rows(state: dict[str, Any]) -> list[dict[str, Any]]:
    collections = {
        str(row.get("id")): row
        for row in state.get("collections", [])
        if isinstance(row, dict) and row.get("id") and row.get("mode", "union") == "union"
        and not any(_safe_text(row.get(key), 500) for key in ("include", "exclude", "filter", "query"))
    }
    child_ids: set[str] = set()
    for row in collections.values():
        for member in row.get("members", []) if isinstance(row.get("members"), list) else []:
            if isinstance(member, dict) and member.get("kind") == "collection" and str(member.get("id")) in collections:
                child_ids.add(str(member.get("id")))

    rows: list[dict[str, Any]] = []
    seen: set[tuple[str, ...]] = set()

    def walk(folder_id: str, path_ids: tuple[str, ...], path_titles: tuple[str, ...]) -> set[str]:
        if folder_id in path_ids:
            return set()
        row = collections[folder_id]
        title = _safe_text(row.get("title"), 120) or "Untitled folder"
        next_ids = (*path_ids, folder_id)
        next_titles = (*path_titles, title)
        if next_ids in seen:
            return set()
        seen.add(next_ids)
        direct: set[str] = set()
        branch: set[str] = set()
        children: list[str] = []
        for member in row.get("members", []) if isinstance(row.get("members"), list) else []:
            if not isinstance(member, dict):
                continue
            kind = member.get("kind")
            member_id = str(member.get("id") or "")
            if kind == "source" and member_id:
                direct.add(member_id)
                branch.add(member_id)
            elif kind == "collection" and member_id in collections:
                children.append(member_id)
        placeholder = {
            "id": folder_id,
            "title": title,
            "path": " › ".join(next_titles),
            "depth": len(next_titles) - 1,
            "directSourceCount": len(direct),
            "sourceCount": 0,
        }
        rows.append(placeholder)
        for child_id in children:
            branch.update(walk(child_id, next_ids, next_titles))
        placeholder["sourceCount"] = len(branch)
        return branch

    roots = [folder_id for folder_id in collections if folder_id not in child_ids]
    for folder_id in sorted(roots, key=lambda value: _safe_text(collections[value].get("title")).casefold()):
        walk(folder_id, (), ())
    return rows


def _library_snapshot_document(
    label: str, document: dict[str, Any], raw: bytes, *,
    node_owned: bool = False, revision: int = 0, updated_at: str = "",
) -> tuple[dict[str, Any], dict[str, Any]]:
    state = document["state"]
    source_rows: list[dict[str, Any]] = []
    source_titles: dict[str, str] = {}
    for row in state.get("sources", []):
        if not isinstance(row, dict):
            continue
        source_id = _safe_text(row.get("id"), 256)
        title = _safe_text(row.get("title"), 300) or _host_for_url(row.get("url")) or "Untitled source"
        source_titles[source_id] = title
        source_rows.append({
            "id": source_id,
            "title": title,
            "type": "page" if row.get("type") == "page" else "feed",
            "url": _safe_text(row.get("url"), 4_096),
            "host": _host_for_url(row.get("url")),
            "enabled": bool(row.get("enabled", True)) and not bool(row.get("archivedAt")),
            "archived": bool(row.get("archivedAt")),
            "createdAt": _safe_text(row.get("createdAt"), 80),
            "lastCheckedAt": _safe_text(row.get("lastScan") or row.get("lastCheckedAt") or row.get("checkedAt"), 80),
            "lastSuccessfulAt": _safe_text(row.get("lastSuccessfulAt"), 80),
            "lastOutcome": _safe_text(row.get("lastOutcome"), 80),
            "lastItems": max(0, int(row.get("lastItems") or 0)),
            "checkCount": max(0, int(row.get("checkCount") or 0)),
            "error": _safe_text(row.get("lastProblem") or row.get("error") or row.get("lastError"), 500),
        })
    source_rows.sort(key=lambda row: (not row["enabled"], row["title"].casefold(), row["id"]))

    item_rows: list[dict[str, Any]] = []
    for row in state.get("items", []):
        if not isinstance(row, dict):
            continue
        source_id = _safe_text(row.get("sourceId"), 256)
        body = str(row.get("body") or "")
        summary = str(row.get("summary") or "")
        item_rows.append({
            "id": _safe_text(row.get("id") or row.get("entryKey"), 512),
            "sourceId": source_id,
            "sourceTitle": source_titles.get(source_id, "Unknown source"),
            "title": _safe_text(row.get("title"), 500) or "Untitled update",
            "url": _safe_text(row.get("url"), 4_096),
            "summary": _safe_text(summary or body, 2_000),
            "published": _safe_text(row.get("published"), 80),
            "observedAt": _safe_text(row.get("observedAt"), 80),
            "read": bool(row.get("readAt") or row.get("read")),
            "saved": bool(row.get("starred") or row.get("saved")),
            "kind": _safe_text(row.get("kind"), 80) or "update",
            "language": _safe_text(row.get("language") or row.get("titleLanguage"), 100),
        })
    item_rows.sort(key=_iso_sort_key, reverse=True)
    folders = _simple_folder_rows(state)
    stats = {
        "sources": len(source_rows),
        "activeSources": sum(1 for row in source_rows if row["enabled"]),
        "pageWatches": sum(1 for row in source_rows if row["type"] == "page"),
        "folders": len(folders),
        "items": len(item_rows),
        "unread": sum(1 for row in item_rows if not row["read"]),
        "saved": sum(1 for row in item_rows if row["saved"]),
    }
    digest = hashlib.sha256(raw).hexdigest()
    library = {
        "file": label,
        "sha256": digest,
        "bytes": len(raw),
        "mode": "node-owned" if node_owned else "exported-backup",
        "revision": int(revision) if node_owned else 0,
        "updatedAt": updated_at if node_owned else (document.get("exportedAt") or ""),
    }
    snapshot = {
        "schema": LIBRARY_SCHEMA,
        "generatedAt": document.get("exportedAt") or "",
        "library": library,
        "stats": stats,
        "folders": folders,
        "sources": source_rows,
        "items": item_rows,
        "readOnly": not node_owned,
        "viewOnly": True,
        "nodeOwned": node_owned,
    }
    return snapshot, stats


def _library_snapshot(path: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    document, raw = _read_backup(path)
    return _library_snapshot_document(path.name, document, raw)


@dataclasses.dataclass(slots=True)
class PairingInvitation:
    token_key: str
    created_at: float
    expires_at: float
    review_origin: str | None = None
    review_library_sha256: str | None = None


@dataclasses.dataclass(slots=True)
class PairingGrant:
    pair_id: str
    token_key: str
    origin: str
    client_name: str
    client_version: str
    created_at: float
    last_seen_at: float
    reviewed_library_sha256: str


@dataclasses.dataclass(slots=True)
class ExchangePreview:
    token_key: str
    created_at: float
    expires_at: float
    library_sha256: str
    prepared: PreparedExchange


@dataclasses.dataclass(slots=True)
class ExchangeGrant:
    exchange_id: str
    token_key: str
    created_at: float
    expires_at: float
    library_sha256: str
    prepared: PreparedExchange
    review_origin: str | None = None


@dataclasses.dataclass(slots=True)
class AcquisitionPreview:
    preview_id: str
    token_key: str
    actor: str
    source_id: str
    action: str
    enable: bool
    created_at: float
    expires_at: float
    base_sha256: str
    preview_sha256: str
    response: dict[str, Any]


@dataclasses.dataclass(slots=True)
class CaptureInvitation:
    token_key: str
    source_id: str
    action: str
    created_at: float
    expires_at: float
    base_sha256: str
    base_revision: int
    recipe_sha256: str
    preview_sha256: str
    source: dict[str, Any]
    review_origin: str | None = None


@dataclasses.dataclass(slots=True)
class BranchOperationPreview:
    preview_id: str
    token_key: str
    actor: str
    created_at: float
    expires_at: float
    base_sha256: str
    preview_sha256: str
    source_list_sha256: str
    result_sha256: str
    result_document: dict[str, Any]
    summary: dict[str, Any]
    selection: dict[str, Any]
    response: dict[str, Any]


@dataclasses.dataclass(slots=True)
class BaselineReplacementPreview:
    preview_id: str
    token_key: str
    actor: str
    source_id: str
    held_operation_id: str
    held_receipt_id: str
    created_at: float
    expires_at: float
    base_sha256: str
    preview_sha256: str
    result_sha256: str
    result_document: dict[str, Any]
    summary: dict[str, Any]
    evidence: dict[str, Any]
    selection: dict[str, Any]
    response: dict[str, Any]


def _new_token() -> str:
    return base64.urlsafe_b64encode(secrets.token_bytes(32)).decode("ascii").rstrip("=")


def _token_key(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8", "strict")).hexdigest()


def _utc_iso(timestamp: float | None = None) -> str:
    instant = datetime.fromtimestamp(timestamp if timestamp is not None else time.time(), tz=timezone.utc)
    return instant.isoformat(timespec="seconds").replace("+00:00", "Z")


def _utc_iso_millis(timestamp: float | None = None) -> str:
    instant = datetime.fromtimestamp(timestamp if timestamp is not None else time.time(), tz=timezone.utc)
    return instant.isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _extension_origin(value: str) -> bool:
    try:
        parsed = urllib.parse.urlsplit(value)
    except ValueError:
        return False
    return (
        parsed.scheme in {"chrome-extension", "moz-extension"}
        and bool(parsed.netloc)
        and not parsed.username
        and not parsed.password
        and not parsed.query
        and not parsed.fragment
        and parsed.path in {"", "/"}
    )


def _pairing_capabilities() -> dict[str, Any]:
    return {
        "schema": CAPABILITIES_SCHEMA,
        "readLibrarySummary": True,
        "readItems": False,
        "readSourceAddresses": False,
        "writeLibrary": False,
        "fetchSources": False,
        "browserAssistedCapture": False,
        "publish": False,
        "merge": False,
        "nodeToNode": False,
        "webrtcCourier": False,
    }


class PairingError(NodeError):
    """Expected pairing failure with an HTTP status."""

    def __init__(self, message: str, status: int = HTTPStatus.UNAUTHORIZED):
        super().__init__(message)
        self.status = int(status)


@dataclasses.dataclass(slots=True)
class NodeState:
    backup: Path
    token: str
    store: NodeStore | None = None
    origin: str = ""
    httpd: "NodeHTTPServer | None" = None
    identity_key: bytes = dataclasses.field(default_factory=lambda: secrets.token_bytes(32))
    invitations: dict[str, PairingInvitation] = dataclasses.field(default_factory=dict)
    pairings: dict[str, PairingGrant] = dataclasses.field(default_factory=dict)
    exchange_previews: dict[str, ExchangePreview] = dataclasses.field(default_factory=dict)
    exchanges: dict[str, ExchangeGrant] = dataclasses.field(default_factory=dict)
    operation_previews: dict[str, BranchOperationPreview] = dataclasses.field(default_factory=dict)
    baseline_previews: dict[str, BaselineReplacementPreview] = dataclasses.field(default_factory=dict)
    acquisition_previews: dict[str, AcquisitionPreview] = dataclasses.field(default_factory=dict)
    capture_invitations: dict[str, CaptureInvitation] = dataclasses.field(default_factory=dict)
    lock: threading.RLock = dataclasses.field(default_factory=threading.RLock)
    writer_lock: threading.Lock = dataclasses.field(default_factory=threading.Lock)

    @property
    def node_owned(self) -> bool:
        return self.store is not None

    @property
    def library_mode(self) -> str:
        return "node-owned" if self.node_owned else "exported-backup"

    def current_document(self) -> tuple[dict[str, Any], bytes, int, str]:
        if self.store is not None:
            try:
                record = self.store.read_library()
            except NodeStoreError as exc:
                raise NodeError(str(exc)) from exc
            return record.document, record.raw, record.revision, record.updated_at
        document, raw = _read_backup(self.backup)
        return document, raw, 0, str(document.get("exportedAt") or "")

    def snapshot(self) -> tuple[dict[str, Any], dict[str, Any]]:
        document, raw, revision, updated_at = self.current_document()
        snapshot, stats = _library_snapshot_document(
            self.backup.name, document, raw, node_owned=self.node_owned,
            revision=revision, updated_at=updated_at,
        )
        if self.store is not None:
            snapshot["library"]["storeSchema"] = STORE_SCHEMA
            snapshot["library"]["storeMigratedAtOpen"] = bool(self.store.migrated)
            try:
                holds = {row["sourceId"]: row for row in self.store.list_capture_holds()}
            except NodeStoreError as exc:
                raise NodeError(str(exc)) from exc
            for source in snapshot.get("sources", []):
                hold = holds.get(source.get("id"))
                source["heldBaselineAvailable"] = bool(hold)
                if hold:
                    source["heldBaselineAt"] = hold.get("heldAt", "")
                    source["heldBaselineOverlapPercent"] = int((hold.get("continuity") or {}).get("overlapPercent") or 0)
                    source["heldObservationCount"] = 1 + len(self.store.capture_hold_history(str(source.get("id") or "")))
        return snapshot, stats

    @property
    def fingerprint(self) -> str:
        digest = hashlib.sha256(b"ProgRSS/node-instance/v1\0" + self.identity_key).hexdigest()
        return f"sha256:{digest}"

    def _purge_expired_locked(self, now: float) -> None:
        for key, invitation in list(self.invitations.items()):
            if invitation.expires_at <= now:
                self.invitations.pop(key, None)
        for key, preview in list(self.exchange_previews.items()):
            if preview.expires_at <= now:
                self.exchange_previews.pop(key, None)
        for exchange_id, grant in list(self.exchanges.items()):
            if grant.expires_at <= now:
                self.exchanges.pop(exchange_id, None)
        for key, preview in list(self.operation_previews.items()):
            if preview.expires_at <= now:
                self.operation_previews.pop(key, None)
        for key, preview in list(self.baseline_previews.items()):
            if preview.expires_at <= now:
                self.baseline_previews.pop(key, None)
        for key, preview in list(self.acquisition_previews.items()):
            if preview.expires_at <= now:
                self.acquisition_previews.pop(key, None)
        for key, invitation in list(self.capture_invitations.items()):
            if invitation.expires_at <= now:
                self.capture_invitations.pop(key, None)

    def create_invitation(self, *, now: float | None = None) -> tuple[str, dict[str, Any]]:
        current = time.time() if now is None else float(now)
        token = _new_token()
        invitation = PairingInvitation(
            token_key=_token_key(token),
            created_at=current,
            expires_at=current + PAIRING_TTL_SECONDS,
        )
        with self.lock:
            self._purge_expired_locked(current)
            self.invitations[invitation.token_key] = invitation
        return token, self.pairing_document(
            state="invitation",
            expires_at=invitation.expires_at,
        )

    def review_invitation(
        self,
        token: str,
        *,
        origin: str,
        now: float | None = None,
    ) -> dict[str, Any]:
        if not _extension_origin(origin):
            raise PairingError("a browser-extension Origin is required", HTTPStatus.FORBIDDEN)
        current = time.time() if now is None else float(now)
        key = _token_key(token)
        with self.lock:
            invitation = self.invitations.get(key)
            if invitation and invitation.expires_at <= current:
                self.invitations.pop(key, None)
                raise PairingError("pairing invitation expired", HTTPStatus.GONE)
            if not invitation:
                raise PairingError("pairing invitation is invalid or already used")
            if invitation.review_origin and invitation.review_origin != origin:
                raise PairingError(
                    "pairing invitation is already being reviewed by another extension Origin",
                    HTTPStatus.FORBIDDEN,
                )
            invitation.review_origin = origin
            expires_at = invitation.expires_at
        snapshot, stats = self.snapshot()
        with self.lock:
            invitation = self.invitations.get(key)
            if not invitation or invitation.review_origin != origin:
                raise PairingError("pairing invitation is invalid or already used")
            if invitation.expires_at <= current:
                self.invitations.pop(key, None)
                raise PairingError("pairing invitation expired", HTTPStatus.GONE)
            invitation.review_library_sha256 = str(snapshot["library"]["sha256"])
        return self.pairing_document(
            state="review",
            expires_at=expires_at,
            snapshot=snapshot,
            stats=stats,
        )

    def accept_invitation(
        self,
        token: str,
        *,
        origin: str,
        client_name: str,
        client_version: str,
        now: float | None = None,
    ) -> tuple[str, dict[str, Any]]:
        if not _extension_origin(origin):
            raise PairingError("a browser-extension Origin is required", HTTPStatus.FORBIDDEN)
        current = time.time() if now is None else float(now)
        key = _token_key(token)
        with self.lock:
            invitation = self.invitations.get(key)
            if invitation and invitation.expires_at <= current:
                self.invitations.pop(key, None)
                raise PairingError("pairing invitation expired", HTTPStatus.GONE)
            if not invitation:
                raise PairingError("pairing invitation is invalid or already used")
            if invitation.review_origin != origin or not invitation.review_library_sha256:
                raise PairingError("pairing invitation must be reviewed by this extension Origin first", HTTPStatus.FORBIDDEN)
            reviewed_digest = invitation.review_library_sha256
        snapshot, stats = self.snapshot()
        current_digest = str(snapshot["library"]["sha256"])
        with self.lock:
            invitation = self.invitations.get(key)
            if invitation and invitation.expires_at <= current:
                self.invitations.pop(key, None)
                raise PairingError("pairing invitation expired", HTTPStatus.GONE)
            if not invitation:
                raise PairingError("pairing invitation is invalid or already used")
            if invitation.review_origin != origin or invitation.review_library_sha256 != reviewed_digest:
                raise PairingError("pairing invitation review changed; review it again", HTTPStatus.CONFLICT)
            if current_digest != reviewed_digest:
                raise PairingError("selected library changed after review; review the invitation again", HTTPStatus.CONFLICT)
            self.invitations.pop(key, None)
            pair_token = _new_token()
            pair_id = secrets.token_hex(10)
            grant = PairingGrant(
                pair_id=pair_id,
                token_key=_token_key(pair_token),
                origin=origin,
                client_name=_safe_text(client_name, 80) or "ProgRSS Extension",
                client_version=_safe_text(client_version, 40),
                created_at=current,
                last_seen_at=current,
                reviewed_library_sha256=reviewed_digest,
            )
            self.pairings[pair_id] = grant
        return pair_token, self.pairing_document(
            state="paired",
            grant=grant,
            snapshot=snapshot,
            stats=stats,
        )

    def pairing_for_token(self, token: str, *, origin: str, now: float | None = None) -> PairingGrant:
        if not _extension_origin(origin):
            raise PairingError("a browser-extension Origin is required", HTTPStatus.FORBIDDEN)
        key = _token_key(token)
        current = time.time() if now is None else float(now)
        with self.lock:
            for grant in self.pairings.values():
                if hmac.compare_digest(grant.token_key, key):
                    if grant.origin != origin:
                        raise PairingError("pairing capability belongs to another extension Origin", HTTPStatus.FORBIDDEN)
                    grant.last_seen_at = current
                    return grant
        raise PairingError("pairing capability is invalid or revoked")

    def revoke_pair_token(self, token: str, *, origin: str) -> PairingGrant:
        grant = self.pairing_for_token(token, origin=origin)
        with self.lock:
            self.pairings.pop(grant.pair_id, None)
        return grant

    def revoke_pair_id(self, pair_id: str) -> PairingGrant:
        with self.lock:
            grant = self.pairings.pop(pair_id, None)
        if not grant:
            raise PairingError("pairing is no longer active", HTTPStatus.NOT_FOUND)
        return grant

    def list_pairings(self) -> list[dict[str, Any]]:
        with self.lock:
            grants = list(self.pairings.values())
        grants.sort(key=lambda grant: grant.created_at)
        return [self.pairing_summary(grant) for grant in grants]

    @staticmethod
    def pairing_summary(grant: PairingGrant) -> dict[str, Any]:
        return {
            "pairId": grant.pair_id,
            "origin": grant.origin,
            "clientName": grant.client_name,
            "clientVersion": grant.client_version,
            "createdAt": _utc_iso(grant.created_at),
            "lastSeenAt": _utc_iso(grant.last_seen_at),
            "reviewedLibrarySha256": grant.reviewed_library_sha256,
        }

    @staticmethod
    def _checked_source_list(raw_bundle: Mapping[str, Any]) -> tuple[dict[str, Any], str]:
        try:
            checked = _connected_bundle(validate_bundle(copy.deepcopy(dict(raw_bundle))))
        except RelayError as exc:
            raise PairingError(str(exc), HTTPStatus.BAD_REQUEST) from exc
        digest = hashlib.sha256(canonical_json(checked).encode("utf-8")).hexdigest()
        return checked, digest

    def branch_options(self, raw_bundle: Mapping[str, Any]) -> dict[str, Any]:
        checked, source_list_sha256 = self._checked_source_list(raw_bundle)
        try:
            contents = bundle_contents(checked)
        except RelayError as exc:
            raise PairingError(str(exc), HTTPStatus.BAD_REQUEST) from exc
        branches = [
            {
                "id": row["id"],
                "title": row["title"],
                "path": row["path"],
                "sources": row["branchSources"],
                "feeds": row["branchFeeds"],
                "pageWatches": row["branchPageWatches"],
                "folders": row["branchFolders"],
                "sourceNotes": row.get("branchSourceNotes", 0),
            }
            for row in contents["folders"]
            if not row.get("isRoot") and int(row.get("branchSources") or 0) > 0
        ]
        provenance = bundle_provenance(checked)
        return {
            "schema": BRANCH_OPTIONS_SCHEMA,
            "state": "options",
            "operationType": OPERATION_TYPE_ADOPT_BRANCH,
            "sourceList": {
                "title": contents["title"],
                "sha256": source_list_sha256,
                "contentDigest": provenance.get("digest", ""),
                "signatureState": provenance.get("signatureState", "legacy"),
                "curator": provenance.get("curator", ""),
            },
            "branches": branches,
            "nodeOwned": self.node_owned,
            "canCommit": self.node_owned and bool(branches),
            "network": False,
            "writes": False,
        }

    def create_branch_operation_preview(
        self, raw_bundle: Mapping[str, Any], *, folder: str, now: float | None = None,
    ) -> tuple[str, dict[str, Any]]:
        if self.store is None:
            raise PairingError(
                "this Node opened an exported backup read-only; create and serve a Node-owned library first",
                HTTPStatus.CONFLICT,
            )
        current = time.time() if now is None else float(now)
        checked, source_list_sha256 = self._checked_source_list(raw_bundle)
        try:
            selected, selection = select_bundle_section(checked, folder)
        except RelayError as exc:
            raise PairingError(str(exc), HTTPStatus.BAD_REQUEST) from exc
        if not selection.get("independentExcerpt"):
            raise PairingError("choose one populated nested branch; complete-route adoption is not writable in this release", HTTPStatus.BAD_REQUEST)

        document, raw, revision, _updated_at = self.current_document()
        base_sha256 = hashlib.sha256(raw).hexdigest()
        generated_at = _utc_iso_millis(current)
        try:
            updated_state, summary = import_bundle(
                document["state"], checked, folder, now=generated_at,
            )
        except RelayError as exc:
            raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
        result_document = copy.deepcopy(document)
        result_document["schema"] = BACKUP_SCHEMA
        result_document["exportedAt"] = generated_at
        result_document["state"] = updated_state
        result_document["producer"] = {
            "name": "ProgRSS Node",
            "version": VERSION,
            "revision": REVISION,
            "operation": OPERATION_TYPE_ADOPT_BRANCH,
        }
        result_raw = (json.dumps(result_document, ensure_ascii=False, indent=2, sort_keys=False) + "\n").encode("utf-8")
        result_sha256 = hashlib.sha256(result_raw).hexdigest()

        selected_contents = bundle_contents(selected)
        current_keys: set[tuple[Any, ...]] = set()
        for row in document["state"].get("sources", []):
            if not isinstance(row, Mapping) or row.get("archivedAt"):
                continue
            try:
                current_keys.add(_source_acquisition_key(row))
            except (RelayError, TypeError, ValueError):
                continue
        planned_keys: set[tuple[Any, ...]] = set()
        selected_sources = {str(row.get("id")): row for row in selected.get("sources", []) if isinstance(row, Mapping)}
        content_rows: list[dict[str, Any]] = []
        for row in selected_contents["sources"]:
            source = selected_sources.get(str(row.get("id")))
            state = "new-paused"
            if source is not None:
                try:
                    key = _source_acquisition_key(source)
                except (RelayError, TypeError, ValueError):
                    key = ("invalid", str(row.get("id")))
                if key in current_keys:
                    state = "reused"
                elif key in planned_keys:
                    state = "duplicate-in-list"
                else:
                    planned_keys.add(key)
            content_rows.append({
                "id": row.get("id", ""),
                "title": row.get("title", "Untitled source"),
                "type": "page" if row.get("type") == "page" else "feed",
                "host": row.get("host", ""),
                "folders": row.get("folders", []),
                "placements": copy.deepcopy(row.get("placements", [])),
                "sourceNoteCount": int(row.get("sourceNoteCount") or 0),
                "state": state,
            })

        selection_evidence = {
            "mode": "branch",
            "folderId": selection.get("selectedFolderId", ""),
            "folderPath": selection.get("selectedFolderPath", ""),
            "parentTitle": selection.get("parentTitle", ""),
            "independentExcerpt": True,
            "updateLinked": False,
        }
        preview_material = {
            "schema": OPERATION_PREVIEW_SCHEMA,
            "operationType": OPERATION_TYPE_ADOPT_BRANCH,
            "actor": "local-admin",
            "baseLibrarySha256": base_sha256,
            "baseRevision": revision,
            "sourceListSha256": source_list_sha256,
            "selection": selection_evidence,
            "resultLibrarySha256": result_sha256,
            "summary": summary,
        }
        preview_sha256 = hashlib.sha256(canonical_json(preview_material).encode("utf-8")).hexdigest()
        token = _new_token()
        preview_id = secrets.token_hex(10)
        expires_at = current + OPERATION_TTL_SECONDS
        response: dict[str, Any] = {
            "schema": OPERATION_PREVIEW_SCHEMA,
            "state": "review",
            "operationType": OPERATION_TYPE_ADOPT_BRANCH,
            "previewId": preview_id,
            "previewDigest": preview_sha256,
            "expiresAt": _utc_iso(expires_at),
            "expiresInSeconds": OPERATION_TTL_SECONDS,
            "library": {
                "file": self.backup.name,
                "mode": "node-owned",
                "sha256": base_sha256,
                "revision": revision,
            },
            "sourceList": {
                "title": selected_contents["title"],
                "sha256": source_list_sha256,
                "contentDigest": bundle_provenance(checked).get("digest", ""),
                "signatureState": bundle_provenance(checked).get("signatureState", "legacy"),
                "curator": bundle_provenance(checked).get("curator", ""),
            },
            "selection": selection_evidence,
            "summary": summary,
            "contents": {
                "sources": content_rows,
                "folders": selected_contents["folders"],
                "sourceNoteCount": selected_contents.get("sourceNoteCount", 0),
            },
            "result": {
                "librarySha256": result_sha256,
                "revision": revision + 1,
            },
            "consequences": {
                "writer": "ProgRSS Node",
                "newSourcesPaused": True,
                "existingExactSourcesReused": True,
                "independentLocalBranch": True,
                "parentUpdateRelationship": False,
                "listedSitesContacted": False,
                "readingStateImported": False,
                "browserAuthorityImported": False,
                "rollbackSnapshotCreated": True,
            },
            "network": False,
            "writes": False,
            "commitAvailable": True,
        }
        preview = BranchOperationPreview(
            preview_id=preview_id,
            token_key=_token_key(token),
            actor="local-admin",
            created_at=current,
            expires_at=expires_at,
            base_sha256=base_sha256,
            preview_sha256=preview_sha256,
            source_list_sha256=source_list_sha256,
            result_sha256=result_sha256,
            result_document=result_document,
            summary=copy.deepcopy(summary),
            selection=selection_evidence,
            response=copy.deepcopy(response),
        )
        with self.lock:
            self._purge_expired_locked(current)
            self.operation_previews[preview.token_key] = preview
        response["previewToken"] = token
        return token, response

    @staticmethod
    def operation_request_digest(*, actor: str, base_sha256: str, preview_token: str, preview_digest: str) -> str:
        material = {
            "schema": "progrss.node.operation-request.v1",
            "operationType": OPERATION_TYPE_ADOPT_BRANCH,
            "actor": actor,
            "baseLibrarySha256": base_sha256,
            "previewTokenSha256": _token_key(preview_token),
            "previewDigest": preview_digest,
        }
        return hashlib.sha256(canonical_json(material).encode("utf-8")).hexdigest()

    def commit_branch_operation(
        self, *, operation_id: str, base_sha256: str, preview_token: str,
        preview_digest: str, now: float | None = None,
    ) -> tuple[dict[str, Any], bool]:
        if self.store is None:
            raise PairingError("this Node does not own a writable library", HTTPStatus.CONFLICT)
        actor = "local-admin"
        request_sha256 = self.operation_request_digest(
            actor=actor, base_sha256=base_sha256, preview_token=preview_token,
            preview_digest=preview_digest,
        )
        try:
            existing = self.store.find_receipt(operation_id)
        except NodeStoreError as exc:
            raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
        if existing is not None:
            stored_request = str(existing.pop("_requestSha256", ""))
            if not hmac.compare_digest(stored_request, request_sha256):
                raise PairingError("that Idempotency-Key was already used for different reviewed content", HTTPStatus.CONFLICT)
            return existing, True

        current = time.time() if now is None else float(now)
        key = _token_key(preview_token)
        with self.lock:
            self._purge_expired_locked(current)
            preview = self.operation_previews.get(key)
        if preview is None:
            raise PairingError("operation preview is invalid or expired", HTTPStatus.GONE)
        if preview.actor != actor:
            raise PairingError("operation preview belongs to another writer", HTTPStatus.FORBIDDEN)
        if not hmac.compare_digest(preview.base_sha256, base_sha256):
            raise PairingError("If-Match does not identify the reviewed base library", HTTPStatus.PRECONDITION_FAILED)
        if not hmac.compare_digest(preview.preview_sha256, preview_digest):
            raise PairingError("operation preview digest does not match", HTTPStatus.CONFLICT)
        try:
            with self.writer_lock:
                result = self.store.commit_operation(
                    operation_id=operation_id,
                    operation_type=OPERATION_TYPE_ADOPT_BRANCH,
                    actor=actor,
                    request_sha256=request_sha256,
                    base_sha256=base_sha256,
                    preview_sha256=preview.preview_sha256,
                    result_document=preview.result_document,
                    summary=preview.summary,
                    source_list_sha256=preview.source_list_sha256,
                    selected_folder=preview.selection,
                    now=current,
                )
        except NodeStoreConflict as exc:
            message = str(exc)
            status = HTTPStatus.PRECONDITION_FAILED if "changed after review" in message else HTTPStatus.CONFLICT
            raise PairingError(message, status) from exc
        except NodeStoreError as exc:
            raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
        with self.lock:
            self.operation_previews.pop(key, None)
        return result.receipt, result.replayed

    def bearing_review(self, source_id: str) -> dict[str, Any]:
        if self.store is None:
            raise PairingError("held-window review requires a Node-owned library", HTTPStatus.CONFLICT)
        document, raw, revision, updated_at = self.current_document()
        state = document.get("state") if isinstance(document.get("state"), dict) else {}
        source = next((row for row in state.get("sources", []) if isinstance(row, dict) and str(row.get("id")) == source_id), None)
        if source is None or source.get("type") != "page":
            raise PairingError("held-window review is available only for an existing watched page", HTTPStatus.NOT_FOUND)
        try:
            hold = self.store.capture_hold(source_id)
            history = self.store.capture_hold_history(source_id, MAX_BEARING_PRIOR_OBSERVATIONS)
        except NodeStoreError as exc:
            raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
        if hold is None:
            raise PairingError("this watched page has no unresolved held rendering", HTTPStatus.NOT_FOUND)
        source_identity_sha256, _material = acquisition_source_identity(source)
        if not hmac.compare_digest(source_identity_sha256, str(hold.get("sourceIdentitySha256") or "")):
            raise PairingError("the watched-page recipe changed after the held observation", HTTPStatus.CONFLICT)
        snapshots = state.get("snapshots") if isinstance(state.get("snapshots"), dict) else {}
        accepted = snapshots.get(source_id) if isinstance(snapshots.get(source_id), dict) else None
        if accepted is None:
            raise PairingError("the watched page no longer has an accepted baseline", HTTPStatus.CONFLICT)
        accepted_sha256 = _canonical_sha256(accepted)
        if not hmac.compare_digest(accepted_sha256, str(hold.get("acceptedSnapshotSha256") or "")):
            raise PairingError("the accepted page baseline changed after the held observation", HTTPStatus.CONFLICT)
        diagnosis, comparisons = _bearing_diagnosis(hold, history)
        accepted_provenance = source.get("browserCapture") if isinstance(source.get("browserCapture"), Mapping) else None
        trace = _bearing_trace(accepted, accepted_provenance, hold, history)
        recipe_footprint = _selector_footprint(source, hold, diagnosis)
        observations = [hold, *history[:MAX_BEARING_PRIOR_OBSERVATIONS]]
        advanced_observations = []
        for index, row in enumerate(observations):
            continuity = row.get("continuity") if isinstance(row.get("continuity"), dict) else {}
            advanced_observations.append({
                "current": index == 0,
                "heldAt": row.get("heldAt", ""),
                "captureOperationId": row.get("captureOperationId", ""),
                "captureReceiptId": row.get("captureReceiptId", ""),
                "proposedSnapshotSha256": row.get("proposedSnapshotSha256", ""),
                "proposed": _snapshot_summary(row.get("proposedSnapshot")),
                "overlapToAcceptedPercent": int(continuity.get("overlapPercent") or 0),
                "reason": _safe_text(continuity.get("reason"), 80),
                "boundaryKinds": _bearing_boundary_kinds(row),
            })
        return {
            "schema": BEARING_REVIEW_SCHEMA,
            "state": "review",
            "library": {
                "file": self.backup.name,
                "mode": self.library_mode,
                "sha256": hashlib.sha256(raw).hexdigest(),
                "revision": revision,
                "updatedAt": updated_at,
                "storeSchema": STORE_SCHEMA,
            },
            "source": {
                "id": source_id,
                "title": _safe_text(source.get("title"), 240) or "Untitled watched page",
                "host": _host_for_url(source.get("url")),
                "accepted": _snapshot_summary(accepted),
                "currentHeld": _snapshot_summary(hold.get("proposedSnapshot")),
                "heldAt": hold.get("heldAt", ""),
                "heldOperationId": hold.get("captureOperationId", ""),
                "heldReceiptId": hold.get("captureReceiptId", ""),
            },
            "history": {
                "schema": BEARING_HISTORY_SCHEMA,
                "currentObservation": 1,
                "priorObservationsRetained": len(history),
                "maximumPriorObservations": MAX_BEARING_PRIOR_OBSERVATIONS,
            },
            "diagnosis": diagnosis,
            "trace": trace,
            "recipeFootprint": recipe_footprint,
            "routes": {
                "keep": {"available": True, "writes": False, "network": False},
                "anchor": {"available": True, "writesOnlyAfterSeparateReview": True, "network": False},
                "capture": {"available": True, "browserActionRequired": True, "network": False},
            },
            "advanced": {
                "observations": advanced_observations,
                "comparisons": comparisons,
                "sourceIdentitySha256": source_identity_sha256,
                "acceptedSnapshotSha256": accepted_sha256,
                "recipe": recipe_footprint.get("advanced", {}),
            },
            "network": False,
            "writes": False,
        }

    def fieldbook(self, source_id: str, *, now: float | None = None) -> tuple[str, bytes, dict[str, Any]]:
        """Build one private, local-only facilitator sheet from a read-only Bearing review."""
        review = self.bearing_review(source_id)
        current = time.time() if now is None else float(now)
        generated_at = datetime.fromtimestamp(current, timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
        try:
            scenario = build_trace_fieldwork_scenario(
                review, version=VERSION, revision=REVISION, codename=CODENAME, generated_at=generated_at,
            )
            body = render_fieldbook_html(scenario)
        except FieldbookError as exc:
            raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
        digest = str(scenario.get("scenarioDigest") or "")
        filename = f"ProgRSS-Fieldbook-{REVISION}-{digest[:12] or 'scenario'}.html"
        return filename, body, scenario

    def exchange_fieldbook(self, exchange_id: str, *, now: float | None = None) -> tuple[str, bytes, dict[str, Any]]:
        """Build one private recipient-study sheet from an active Exchange handoff."""
        grant = self.exchange_by_id(_safe_text(exchange_id, 80))
        current = time.time() if now is None else float(now)
        generated_at = datetime.fromtimestamp(current, timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
        review = self.exchange_document(grant, state="fieldwork")
        try:
            scenario = build_exchange_fieldwork_scenario(
                review, version=VERSION, revision=REVISION, codename=CODENAME, generated_at=generated_at,
            )
            body = render_fieldbook_html(scenario)
        except FieldbookError as exc:
            raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
        digest = str(scenario.get("scenarioDigest") or "")
        filename = f"ProgRSS-Fieldbook-{REVISION}-Exchange-{digest[:12] or 'scenario'}.html"
        return filename, body, scenario

    def exchange_sender_fieldbook(
        self, preview_token: str, *, now: float | None = None,
    ) -> tuple[str, bytes, dict[str, Any]]:
        """Build one private sender-study sheet from an active Exchange preview."""
        current = time.time() if now is None else float(now)
        key = _token_key(_safe_text(preview_token, 160))
        with self.lock:
            self._purge_expired_locked(current)
            preview = self.exchange_previews.get(key)
        if not preview:
            raise PairingError("exchange preview is invalid or expired", HTTPStatus.GONE)
        review = copy.deepcopy(preview.prepared.preview)
        review.update({
            "state": "preview",
            "expiresAt": _utc_iso(preview.expires_at),
            "expiresInSeconds": EXCHANGE_PREVIEW_TTL_SECONDS,
        })
        generated_at = datetime.fromtimestamp(current, timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
        try:
            scenario = build_exchange_sender_fieldwork_scenario(
                review, version=VERSION, revision=REVISION, codename=CODENAME, generated_at=generated_at,
            )
            body = render_fieldbook_html(scenario)
        except FieldbookError as exc:
            raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
        digest = str(scenario.get("scenarioDigest") or "")
        filename = f"ProgRSS-Fieldbook-{REVISION}-Exchange-Sender-{digest[:12] or 'scenario'}.html"
        return filename, body, scenario

    def debrief(self, reports: list[Any] | None = None, *, now: float | None = None) -> tuple[str, bytes, dict[str, Any]]:
        """Build one private, local-only Fieldbook debrief workspace."""
        current = time.time() if now is None else float(now)
        generated_at = datetime.fromtimestamp(current, timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")
        try:
            workspace = build_debrief_workspace(
                reports or [], version=VERSION, revision=REVISION, codename=CODENAME, generated_at=generated_at,
            )
            body = render_debrief_html(workspace)
        except DebriefError as exc:
            raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
        filename = f"ProgRSS-Debrief-{REVISION}.html"
        return filename, body, workspace

    def create_baseline_replacement_preview(
        self, source_id: str, *, now: float | None = None,
    ) -> tuple[str, dict[str, Any]]:
        """Review one held partial rendering without changing the library."""
        if self.store is None:
            raise PairingError("this Node does not own a writable library", HTTPStatus.CONFLICT)
        source_id = _safe_text(source_id, 300)
        try:
            hold = self.store.capture_hold(source_id)
        except NodeStoreError as exc:
            raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
        if hold is None:
            raise PairingError("this watched page has no held rendered window to replace", HTTPStatus.NOT_FOUND)
        current = time.time() if now is None else float(now)
        document, raw, revision, _updated_at = self.current_document()
        base_sha256 = hashlib.sha256(raw).hexdigest()
        source = next((row for row in document.get("state", {}).get("sources", []) if isinstance(row, dict) and str(row.get("id") or "") == source_id), None)
        if source is None or source.get("type") != "page":
            raise PairingError("the held source is no longer an existing watched page", HTTPStatus.CONFLICT)
        source_identity_sha256, _material = acquisition_source_identity(source)
        if not hmac.compare_digest(source_identity_sha256, str(hold.get("sourceIdentitySha256") or "")):
            raise PairingError("the watched-page recipe changed after the rendered window was held", HTTPStatus.CONFLICT)
        snapshots = document.get("state", {}).get("snapshots") if isinstance(document.get("state", {}).get("snapshots"), dict) else {}
        accepted = snapshots.get(source_id) if isinstance(snapshots.get(source_id), dict) else None
        if accepted is None:
            raise PairingError("the watched page no longer has an accepted baseline", HTTPStatus.CONFLICT)
        accepted_sha256 = _canonical_sha256(accepted)
        if not hmac.compare_digest(accepted_sha256, str(hold.get("acceptedSnapshotSha256") or "")):
            raise PairingError("the accepted page baseline changed after the rendered window was held", HTTPStatus.CONFLICT)
        continuity = hold.get("continuity") if isinstance(hold.get("continuity"), dict) else {}
        if continuity.get("action") != "hold" or not continuity.get("baselinePreserved"):
            raise PairingError("the stored rendered observation is not an eligible held window", HTTPStatus.CONFLICT)
        stamp = _utc_iso_millis(current)
        try:
            applied = replace_browser_capture_baseline(
                document, source_id,
                proposed_snapshot=hold["proposedSnapshot"],
                proposed_provenance=hold["proposedProvenance"],
                continuity=continuity, stamp=stamp,
                held_operation_id=str(hold.get("captureOperationId") or ""),
                held_receipt_id=str(hold.get("captureReceiptId") or ""),
            )
        except AcquisitionError as exc:
            raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
        result_raw = (json.dumps(applied.document, ensure_ascii=False, indent=2, sort_keys=False) + "\n").encode("utf-8")
        result_sha256 = hashlib.sha256(result_raw).hexdigest()
        token = _new_token()
        preview_id = secrets.token_hex(12)
        selection = {
            "sourceId": source_id,
            "sourceTitle": _safe_text(source.get("title"), 300) or _host_for_url(source.get("url")) or "Watched page",
            "sourceHost": _host_for_url(source.get("url")),
            "heldOperationId": hold["captureOperationId"],
            "heldReceiptId": hold["captureReceiptId"],
        }
        material = {
            "schema": BASELINE_PREVIEW_SCHEMA,
            "operationType": BASELINE_REPLACEMENT_OPERATION,
            "baseLibrarySha256": base_sha256,
            "sourceId": source_id,
            "sourceIdentitySha256": source_identity_sha256,
            "heldOperationId": hold["captureOperationId"],
            "heldReceiptId": hold["captureReceiptId"],
            "acceptedSnapshotSha256": accepted_sha256,
            "proposedSnapshotSha256": hold["proposedSnapshotSha256"],
            "resultLibrarySha256": result_sha256,
        }
        preview_sha256 = hashlib.sha256(canonical_json(material).encode("utf-8")).hexdigest()
        expires_at = current + BASELINE_TTL_SECONDS
        response = {
            "schema": BASELINE_PREVIEW_SCHEMA,
            "state": "review",
            "operationType": BASELINE_REPLACEMENT_OPERATION,
            "previewId": preview_id,
            "previewDigest": preview_sha256,
            "expiresAt": _utc_iso(expires_at),
            "library": {"sha256": base_sha256, "revision": revision},
            "source": {
                **selection,
                "url": _safe_text(source.get("url"), 4_096),
                "accepted": _snapshot_summary(accepted),
                "proposed": _snapshot_summary(hold["proposedSnapshot"]),
                "heldAt": hold["heldAt"],
            },
            "continuity": {
                "reason": _safe_text(continuity.get("reason"), 100),
                "message": _safe_text(continuity.get("message"), 300),
                "overlapPercent": int(continuity.get("overlapPercent") or 0),
                "previousUnits": int(continuity.get("previousUnits") or 0),
                "currentUnits": int(continuity.get("currentUnits") or 0),
                "sharedUnits": int(continuity.get("sharedUnits") or 0),
                "previousBoundaryKinds": list(continuity.get("previousBoundaryKinds") or [])[:6],
                "currentBoundaryKinds": list(continuity.get("currentBoundaryKinds") or [])[:6],
            },
            "consequences": {
                "acceptedBaselineReplaced": True,
                "earlierCompleteLibrarySnapshotRetained": True,
                "historicalChangeAlertCreated": False,
                "recipeChanged": False,
                "sourceEnabledChanged": False,
                "networkRequests": 0,
                "automaticScheduleCreated": False,
            },
            "network": False,
            "writes": False,
        }
        preview = BaselineReplacementPreview(
            preview_id=preview_id, token_key=_token_key(token), actor="local-admin", source_id=source_id,
            held_operation_id=str(hold["captureOperationId"]), held_receipt_id=str(hold["captureReceiptId"]),
            created_at=current, expires_at=expires_at, base_sha256=base_sha256, preview_sha256=preview_sha256,
            result_sha256=result_sha256, result_document=applied.document, summary=applied.summary,
            evidence=applied.evidence, selection=selection, response=copy.deepcopy(response),
        )
        with self.lock:
            self._purge_expired_locked(current)
            self.baseline_previews[preview.token_key] = preview
        response["previewToken"] = token
        return token, response

    @staticmethod
    def baseline_request_digest(*, actor: str, base_sha256: str, preview_token: str, preview_digest: str) -> str:
        material = {
            "schema": "progrss.node.operation-request.v1",
            "operationType": BASELINE_REPLACEMENT_OPERATION,
            "actor": actor,
            "baseLibrarySha256": base_sha256,
            "previewTokenSha256": _token_key(preview_token),
            "previewDigest": preview_digest,
        }
        return hashlib.sha256(canonical_json(material).encode("utf-8")).hexdigest()

    def commit_baseline_replacement(
        self, *, operation_id: str, base_sha256: str, preview_token: str,
        preview_digest: str, now: float | None = None,
    ) -> tuple[dict[str, Any], bool]:
        if self.store is None:
            raise PairingError("this Node does not own a writable library", HTTPStatus.CONFLICT)
        actor = "local-admin"
        request_sha256 = self.baseline_request_digest(
            actor=actor, base_sha256=base_sha256, preview_token=preview_token, preview_digest=preview_digest,
        )
        try:
            existing = self.store.find_receipt(operation_id)
        except NodeStoreError as exc:
            raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
        if existing is not None:
            stored_request = str(existing.pop("_requestSha256", ""))
            if not hmac.compare_digest(stored_request, request_sha256):
                raise PairingError("that Idempotency-Key was already used for different reviewed content", HTTPStatus.CONFLICT)
            return existing, True
        current = time.time() if now is None else float(now)
        key = _token_key(preview_token)
        with self.lock:
            self._purge_expired_locked(current)
            preview = self.baseline_previews.get(key)
        if preview is None:
            raise PairingError("baseline replacement preview is invalid or expired", HTTPStatus.GONE)
        if preview.actor != actor:
            raise PairingError("baseline replacement preview belongs to another writer", HTTPStatus.FORBIDDEN)
        if not hmac.compare_digest(preview.base_sha256, base_sha256):
            raise PairingError("If-Match does not identify the reviewed base library", HTTPStatus.PRECONDITION_FAILED)
        if not hmac.compare_digest(preview.preview_sha256, preview_digest):
            raise PairingError("baseline replacement preview digest does not match", HTTPStatus.CONFLICT)
        try:
            with self.writer_lock:
                result = self.store.commit_baseline_replacement(
                    operation_id=operation_id, actor=actor, request_sha256=request_sha256,
                    base_sha256=base_sha256, preview_sha256=preview.preview_sha256,
                    source_id=preview.source_id, held_operation_id=preview.held_operation_id,
                    held_receipt_id=preview.held_receipt_id, result_document=preview.result_document,
                    summary=preview.summary, evidence=preview.evidence, selection=preview.selection, now=current,
                )
        except NodeStoreConflict as exc:
            message = str(exc)
            status = HTTPStatus.PRECONDITION_FAILED if "changed after review" in message else HTTPStatus.CONFLICT
            raise PairingError(message, status) from exc
        except NodeStoreError as exc:
            raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
        with self.lock:
            self.baseline_previews.pop(key, None)
        return result.receipt, result.replayed

    def list_operations(self) -> list[dict[str, Any]]:
        if self.store is None:
            return []
        try:
            return self.store.list_receipts()
        except NodeStoreError as exc:
            raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc

    def create_acquisition_preview(
        self, source_id: str, *, now: float | None = None,
    ) -> tuple[str, dict[str, Any]]:
        """Prepare one exact manual feed or page-watch check without networking."""
        if self.store is None:
            raise PairingError(
                "this Node opened an exported backup read-only; create and serve a Node-owned library first",
                HTTPStatus.CONFLICT,
            )
        current = time.time() if now is None else float(now)
        document, raw, revision, _updated_at = self.current_document()
        base_sha256 = hashlib.sha256(raw).hexdigest()
        try:
            source = source_preview(document, _safe_text(source_id, 300))
        except AcquisitionError as exc:
            raise PairingError(str(exc), HTTPStatus.BAD_REQUEST) from exc
        if source.get("archived"):
            raise PairingError("archived sources cannot be checked", HTTPStatus.CONFLICT)
        action = str(source.get("action") or "")
        if action not in {"check-now", "enable-and-check"}:
            raise PairingError("source check action is not available", HTTPStatus.CONFLICT)
        enable = action == "enable-and-check"
        preview_material = {
            "schema": ACQUISITION_PREVIEW_SCHEMA,
            "operationType": ACQUISITION_TYPE_CHECK_ONCE,
            "actor": "local-admin",
            "baseLibrarySha256": base_sha256,
            "baseRevision": revision,
            "source": source,
            "action": action,
            "limits": {
                "method": "GET",
                "timeoutSeconds": int(DEFAULT_TIMEOUT),
                "responseBytes": MAX_FEED_BYTES,
                "sameOriginRedirects": MAX_REDIRECTS,
                "crossOriginRedirect": "stop-before-contact",
            },
        }
        preview_sha256 = hashlib.sha256(canonical_json(preview_material).encode("utf-8")).hexdigest()
        token = _new_token()
        preview_id = secrets.token_hex(10)
        expires_at = current + ACQUISITION_TTL_SECONDS
        response = {
            **copy.deepcopy(preview_material),
            "state": "review",
            "previewId": preview_id,
            "previewDigest": preview_sha256,
            "previewToken": token,
            "expiresAt": _utc_iso(expires_at),
            "expiresInSeconds": ACQUISITION_TTL_SECONDS,
            "library": {
                "file": self.backup.name,
                "mode": "node-owned",
                "sha256": base_sha256,
                "revision": revision,
            },
            "consequences": {
                "networkRequest": "one explicit bounded public GET, plus bounded same-site redirects",
                "enableSource": enable,
                "browserCookiesSent": False,
                "browserCredentialsSent": False,
                "environmentProxyUsed": False,
                "browserProfileRead": False,
                "pageJavaScriptExecuted": False,
                "automaticScheduleCreated": False,
                "resultCommittedAtomically": True,
                "durableReceipt": True,
            },
            "network": False,
            "writes": False,
            "commitAvailable": True,
        }
        preview = AcquisitionPreview(
            preview_id=preview_id,
            token_key=_token_key(token),
            actor="local-admin",
            source_id=str(source["sourceId"]),
            action=action,
            enable=enable,
            created_at=current,
            expires_at=expires_at,
            base_sha256=base_sha256,
            preview_sha256=preview_sha256,
            response=copy.deepcopy(response),
        )
        with self.lock:
            self._purge_expired_locked(current)
            self.acquisition_previews[preview.token_key] = preview
        return token, response

    @staticmethod
    def acquisition_request_digest(
        *, actor: str, base_sha256: str, preview_token: str, preview_digest: str,
        source_id: str, action: str,
    ) -> str:
        material = {
            "schema": "progrss.node.acquisition-request.v1",
            "operationType": ACQUISITION_TYPE_CHECK_ONCE,
            "actor": actor,
            "baseLibrarySha256": base_sha256,
            "previewTokenSha256": _token_key(preview_token),
            "previewDigest": preview_digest,
            "sourceId": source_id,
            "action": action,
        }
        return hashlib.sha256(canonical_json(material).encode("utf-8")).hexdigest()

    def run_acquisition(
        self, *, operation_id: str, base_sha256: str, preview_token: str,
        preview_digest: str, source_id: str, action: str,
        now: float | None = None,
    ) -> tuple[dict[str, Any], bool]:
        """Run one reviewed GET and atomically retain its result and receipt.

        A durable ``started`` job is inserted before any DNS lookup.  An exact retry
        after interruption may repeat the safe GET, while an exact retry after commit
        returns the stored receipt without another request.
        """
        if self.store is None:
            raise PairingError("this Node does not own a writable library", HTTPStatus.CONFLICT)
        actor = "local-admin"
        source_id = _safe_text(source_id, 300)
        action = _safe_text(action, 40)
        if action not in {"check-now", "enable-and-check"}:
            raise PairingError("unsupported or missing acquisition action", HTTPStatus.BAD_REQUEST)
        if not source_id:
            raise PairingError("sourceId is required", HTTPStatus.BAD_REQUEST)
        request_sha256 = self.acquisition_request_digest(
            actor=actor,
            base_sha256=base_sha256,
            preview_token=preview_token,
            preview_digest=preview_digest,
            source_id=source_id,
            action=action,
        )
        try:
            existing = self.store.find_acquisition_receipt(operation_id)
        except NodeStoreError as exc:
            raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
        if existing is not None:
            stored_request = str(existing.pop("_requestSha256", ""))
            if not hmac.compare_digest(stored_request, request_sha256):
                raise PairingError(
                    "that Idempotency-Key was already used for a different acquisition",
                    HTTPStatus.CONFLICT,
                )
            return existing, True

        current = time.time() if now is None else float(now)
        key = _token_key(preview_token)
        with self.writer_lock:
            # A pre-existing durable job permits recovery after a process restart.
            # A brand-new job still requires the live, unexpired preview capability.
            try:
                durable_job = self.store.find_acquisition_job(operation_id)
            except NodeStoreError as exc:
                raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
            if durable_job is None:
                with self.lock:
                    self._purge_expired_locked(current)
                    preview = self.acquisition_previews.get(key)
                if preview is None:
                    raise PairingError("acquisition preview is invalid or expired", HTTPStatus.GONE)
                if preview.actor != actor:
                    raise PairingError("acquisition preview belongs to another writer", HTTPStatus.FORBIDDEN)
                if preview.source_id != source_id or preview.action != action:
                    raise PairingError("acquisition no longer matches the reviewed source or action", HTTPStatus.CONFLICT)
                if not hmac.compare_digest(preview.base_sha256, base_sha256):
                    raise PairingError("If-Match does not identify the reviewed base library", HTTPStatus.PRECONDITION_FAILED)
                if not hmac.compare_digest(preview.preview_sha256, preview_digest):
                    raise PairingError("acquisition preview digest does not match", HTTPStatus.CONFLICT)
            else:
                if not hmac.compare_digest(str(durable_job.get("requestSha256") or ""), request_sha256):
                    raise PairingError(
                        "that Idempotency-Key was already used for a different acquisition",
                        HTTPStatus.CONFLICT,
                    )
                if str(durable_job.get("sourceId") or "") != source_id:
                    raise PairingError("durable acquisition belongs to another source", HTTPStatus.CONFLICT)
                if not hmac.compare_digest(str(durable_job.get("baseLibrarySha256") or ""), base_sha256):
                    raise PairingError("durable acquisition belongs to another library revision", HTTPStatus.CONFLICT)
                if not hmac.compare_digest(str(durable_job.get("previewDigest") or ""), preview_digest):
                    raise PairingError("durable acquisition belongs to another preview", HTTPStatus.CONFLICT)

            try:
                started = self.store.begin_acquisition(
                    operation_id=operation_id,
                    request_sha256=request_sha256,
                    source_id=source_id,
                    base_sha256=base_sha256,
                    preview_sha256=preview_digest,
                    now=current,
                )
            except NodeStoreConflict as exc:
                message = str(exc)
                status = HTTPStatus.PRECONDITION_FAILED if "changed after" in message else HTTPStatus.CONFLICT
                raise PairingError(message, status) from exc
            except NodeStoreError as exc:
                raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
            if started.replayed and started.receipt is not None:
                return started.receipt, True

            document, raw, _revision, _updated_at = self.current_document()
            current_digest = hashlib.sha256(raw).hexdigest()
            if not hmac.compare_digest(current_digest, base_sha256):
                raise PairingError("the Node library changed after acquisition review", HTTPStatus.PRECONDITION_FAILED)
            try:
                preview_now = source_preview(document, source_id)
            except AcquisitionError as exc:
                raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
            enable = action == "enable-and-check"
            # For a new request, the reviewed action must still match the source's
            # paused/active state.  A resumed durable request is already bound by its
            # request fingerprint and base-library digest.
            if durable_job is None and str(preview_now.get("action") or "") != action:
                raise PairingError("source state changed after review", HTTPStatus.PRECONDITION_FAILED)
            source_row = next(
                (row for row in document.get("state", {}).get("sources", [])
                 if isinstance(row, dict) and str(row.get("id") or "") == source_id),
                None,
            )
            if source_row is None:
                raise PairingError("source is no longer present", HTTPStatus.CONFLICT)

            fetched = None
            try:
                fetched = fetch_public_resource(source_row, now=now)
                stamp = fetched.completed_at
                applied = apply_fetch(document, source_id, fetched, stamp=stamp, enable=enable)
                network_requests = fetched.request_count
                request_evidence: dict[str, Any] = {
                    "method": "GET",
                    "requestedHost": _host_for_url(fetched.requested_url),
                    "finalHost": _host_for_url(fetched.final_url),
                    "httpStatus": fetched.status,
                    "networkRequests": network_requests,
                    "redirects": [copy.deepcopy(row) for row in fetched.redirects],
                    "resolvedAddresses": list(fetched.resolved_addresses),
                    "durationMs": fetched.duration_ms,
                    "conditional": copy.deepcopy(preview_now.get("validators") or {}),
                }
                evidence = {**copy.deepcopy(applied.evidence), "fetch": copy.deepcopy(request_evidence)}
            except AcquisitionError as exc:
                stamp = _utc_iso_millis(current + 0.001 if now is not None else None)
                applied = apply_failure(document, source_id, exc, stamp=stamp, enable=enable)
                explicit_count = (exc.detail or {}).get("requestCount") if isinstance(exc.detail, Mapping) else None
                if explicit_count is None:
                    explicit_count = 0 if exc.code in {
                        "invalid-url", "unsupported-source", "dns-failure", "dns-empty", "non-public-destination",
                    } else 1
                network_requests = max(0, min(MAX_REDIRECTS + 1, int(explicit_count or 0)))
                detail = exc.detail if isinstance(exc.detail, Mapping) else {}
                request_evidence = {
                    "method": "GET",
                    "requestedHost": str(preview_now.get("site") or ""),
                    "finalHost": str(detail.get("finalHost") or ""),
                    "httpStatus": exc.status,
                    "networkRequests": network_requests,
                    "errorCode": exc.code,
                    "redirects": copy.deepcopy(list(detail.get("redirects") or []))[:MAX_REDIRECTS],
                    "resolvedAddresses": copy.deepcopy(list(detail.get("resolvedAddresses") or []))[:12],
                    "blockedAddresses": copy.deepcopy(list(detail.get("blockedAddresses") or []))[:6],
                    "conditional": copy.deepcopy(preview_now.get("validators") or {}),
                }
                evidence = {**copy.deepcopy(applied.evidence), "fetch": copy.deepcopy(request_evidence)}

            source_identity_sha256, _source_identity_material = acquisition_source_identity(source_row)
            request_record = {
                "operationType": ACQUISITION_TYPE_CHECK_ONCE,
                "action": action,
                "sourceIdentitySha256": source_identity_sha256,
                "sourceType": preview_now.get("type"),
                "sourceTitle": preview_now.get("title"),
                "sourceHost": preview_now.get("site"),
                "networkRequests": network_requests,
                "timeoutSeconds": int(DEFAULT_TIMEOUT),
                "responseByteLimit": MAX_FEED_BYTES,
                "sameOriginRedirectLimit": MAX_REDIRECTS,
                "crossOriginRedirect": "stop-before-contact",
                "automaticScheduleCreated": False,
                "resumed": bool(started.resumed),
                "attempt": int(started.attempt),
            }
            try:
                committed = self.store.commit_acquisition(
                    operation_id=operation_id,
                    request_sha256=request_sha256,
                    source_id=source_id,
                    base_sha256=base_sha256,
                    preview_sha256=preview_digest,
                    result_document=applied.document,
                    outcome=applied.outcome,
                    summary=applied.summary,
                    evidence=evidence,
                    request=request_record,
                    clear_capture_hold=preview_now.get("type") == "page",
                    now=(current + 0.002 if now is not None else None),
                )
            except NodeStoreConflict as exc:
                message = str(exc)
                status = HTTPStatus.PRECONDITION_FAILED if "changed after" in message else HTTPStatus.CONFLICT
                raise PairingError(message, status) from exc
            except NodeStoreError as exc:
                raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
            with self.lock:
                self.acquisition_previews.pop(key, None)
            return committed.receipt, committed.replayed

    def list_acquisitions(self) -> dict[str, Any]:
        if self.store is None:
            return {"receipts": [], "jobs": []}
        try:
            return {
                "receipts": self.store.list_acquisition_receipts(),
                "jobs": self.store.list_acquisition_jobs(),
            }
        except NodeStoreError as exc:
            raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc

    def operation_snapshot(self, snapshot_id: str) -> tuple[bytes, str, str]:
        if self.store is None:
            raise PairingError("this Node has no durable operation snapshots", HTTPStatus.NOT_FOUND)
        try:
            return self.store.read_snapshot(snapshot_id)
        except NodeStoreError as exc:
            status = HTTPStatus.NOT_FOUND if "not found" in str(exc).lower() else HTTPStatus.CONFLICT
            raise PairingError(str(exc), status) from exc

    def create_capture_invitation(
        self, source_id: str, *, now: float | None = None,
    ) -> tuple[str, dict[str, Any]]:
        """Create one expiring browser-assisted capture request for one page watch."""
        if self.store is None:
            raise PairingError(
                "this Node opened an exported backup read-only; create and serve a Node-owned library first",
                HTTPStatus.CONFLICT,
            )
        current = time.time() if now is None else float(now)
        document, raw, revision, _updated_at = self.current_document()
        base_sha256 = hashlib.sha256(raw).hexdigest()
        try:
            source = source_preview(document, _safe_text(source_id, 300))
        except AcquisitionError as exc:
            raise PairingError(str(exc), HTTPStatus.BAD_REQUEST) from exc
        if source.get("type") != "page":
            raise PairingError("browser-assisted capture is available only for an existing watched page", HTTPStatus.CONFLICT)
        if source.get("archived"):
            raise PairingError("archived watched pages cannot be captured", HTTPStatus.CONFLICT)
        source_row = next((row for row in document.get("state", {}).get("sources", []) if isinstance(row, dict) and str(row.get("id") or "") == str(source.get("sourceId") or "")), None)
        if source_row is None:
            raise PairingError("watched page is no longer present", HTTPStatus.CONFLICT)
        source["pageRecipe"] = page_recipe(source_row)
        action = "enable-and-capture" if source.get("paused") else "capture-now"
        recipe = source["pageRecipe"]
        recipe_sha256 = page_recipe_digest(recipe)
        preview_material = {
            "schema": CAPTURE_SCHEMA,
            "operationType": CAPTURE_TYPE_RENDERED_PAGE,
            "actor": "browser-extension-invitation",
            "baseLibrarySha256": base_sha256,
            "baseRevision": revision,
            "source": source,
            "action": action,
            "recipeSha256": recipe_sha256,
            "limits": {
                "artifactBytes": MAX_BROWSER_CAPTURE_BYTES,
                "topFrameOnly": True,
                "isolatedWorld": True,
                "arbitrarySharedCode": False,
                "networkRequestsByNode": 0,
            },
        }
        preview_sha256 = hashlib.sha256(canonical_json(preview_material).encode("utf-8")).hexdigest()
        token = _new_token()
        expires_at = current + CAPTURE_TTL_SECONDS
        invitation = CaptureInvitation(
            token_key=_token_key(token), source_id=str(source["sourceId"]), action=action,
            created_at=current, expires_at=expires_at, base_sha256=base_sha256,
            base_revision=revision, recipe_sha256=recipe_sha256,
            preview_sha256=preview_sha256, source=copy.deepcopy(source),
        )
        with self.lock:
            self._purge_expired_locked(current)
            self.capture_invitations[invitation.token_key] = invitation
        response = self.capture_document(invitation, state="invitation")
        response["token"] = token
        return token, response

    def capture_document(self, invitation: CaptureInvitation, *, state: str) -> dict[str, Any]:
        return {
            "schema": CAPTURE_SCHEMA,
            "state": state,
            "operationType": CAPTURE_TYPE_RENDERED_PAGE,
            "captureId": invitation.preview_sha256[:20],
            "createdAt": _utc_iso(invitation.created_at),
            "expiresAt": _utc_iso(invitation.expires_at),
            "previewDigest": invitation.preview_sha256,
            "recipeSha256": invitation.recipe_sha256,
            "source": copy.deepcopy(invitation.source),
            "action": invitation.action,
            "library": {
                "file": self.backup.name,
                "mode": "node-owned",
                "sha256": invitation.base_sha256,
                "revision": invitation.base_revision,
            },
            "node": {
                "origin": self.origin,
                "version": VERSION,
                "revision": REVISION,
                "instanceFingerprint": self.fingerprint,
                "identityPersistence": "until-node-stops",
            },
            "scope": "one-expiring-rendered-page-capture",
            "limits": {
                "artifactBytes": MAX_BROWSER_CAPTURE_BYTES,
                "topFrameOnly": True,
                "isolatedWorld": True,
                "arbitrarySharedCode": False,
                "networkRequestsByNode": 0,
            },
            "consequences": {
                "browserMayAlreadyBeSignedIn": True,
                "cookiesTransferredToNode": False,
                "credentialsTransferredToNode": False,
                "browserStorageTransferredToNode": False,
                "rawHtmlTransferred": False,
                "screenshotTransferred": False,
                "selectedTextAndLinksTransferred": True,
                "automaticScheduleCreated": False,
                "resultCommittedAtomically": True,
                "durableReceipt": True,
            },
            "automatic": False,
            "revocable": True,
            "network": False,
            "writes": False,
        }

    def review_capture_invitation(
        self, token: str, *, origin: str, now: float | None = None,
    ) -> dict[str, Any]:
        if not _extension_origin(origin):
            raise PairingError("a browser-extension Origin is required", HTTPStatus.FORBIDDEN)
        current = time.time() if now is None else float(now)
        key = _token_key(token)
        with self.lock:
            self._purge_expired_locked(current)
            invitation = self.capture_invitations.get(key)
            if invitation is None:
                raise PairingError("capture request is invalid, expired, or already used", HTTPStatus.GONE)
            if invitation.review_origin and invitation.review_origin != origin:
                raise PairingError("capture request is already being reviewed by another extension Origin", HTTPStatus.FORBIDDEN)
            invitation.review_origin = origin
            return self.capture_document(invitation, state="review")

    @staticmethod
    def capture_request_digest(
        *, origin: str, base_sha256: str, token: str, preview_digest: str,
        source_id: str, action: str, artifact_sha256: str,
        recipe_change_acknowledged: bool,
    ) -> str:
        material = {
            "schema": "progrss.node.capture-request.v1",
            "operationType": CAPTURE_TYPE_RENDERED_PAGE,
            "origin": origin,
            "baseLibrarySha256": base_sha256,
            "captureTokenSha256": _token_key(token),
            "previewDigest": preview_digest,
            "sourceId": source_id,
            "action": action,
            "artifactSha256": artifact_sha256,
            "recipeChangeAcknowledged": bool(recipe_change_acknowledged),
        }
        return hashlib.sha256(canonical_json(material).encode("utf-8")).hexdigest()

    def run_browser_capture(
        self, *, origin: str, token: str, operation_id: str, base_sha256: str,
        preview_digest: str, source_id: str, action: str,
        artifact: Mapping[str, Any], recipe_change_acknowledged: bool,
        now: float | None = None,
    ) -> tuple[dict[str, Any], bool]:
        if self.store is None:
            raise PairingError("this Node does not own a writable library", HTTPStatus.CONFLICT)
        if not _extension_origin(origin):
            raise PairingError("a browser-extension Origin is required", HTTPStatus.FORBIDDEN)
        source_id = _safe_text(source_id, 300)
        action = _safe_text(action, 40)
        if action not in {"capture-now", "enable-and-capture"}:
            raise PairingError("unsupported or missing browser-capture action", HTTPStatus.BAD_REQUEST)
        try:
            artifact_sha256 = hashlib.sha256(canonical_json(artifact).encode("utf-8")).hexdigest()
        except (RelayError, TypeError, ValueError) as exc:
            raise PairingError(f"browser capture is not a canonical JSON object: {exc}", HTTPStatus.BAD_REQUEST) from exc
        request_sha256 = self.capture_request_digest(
            origin=origin, base_sha256=base_sha256, token=token,
            preview_digest=preview_digest, source_id=source_id, action=action,
            artifact_sha256=artifact_sha256,
            recipe_change_acknowledged=recipe_change_acknowledged,
        )
        try:
            existing = self.store.find_acquisition_receipt(operation_id)
        except NodeStoreError as exc:
            raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
        if existing is not None:
            stored_request = str(existing.pop("_requestSha256", ""))
            if not hmac.compare_digest(stored_request, request_sha256):
                raise PairingError("that Idempotency-Key was already used for different capture evidence", HTTPStatus.CONFLICT)
            return existing, True

        current = time.time() if now is None else float(now)
        key = _token_key(token)
        with self.writer_lock:
            try:
                durable_job = self.store.find_acquisition_job(operation_id)
            except NodeStoreError as exc:
                raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
            invitation: CaptureInvitation | None = None
            if durable_job is None:
                with self.lock:
                    self._purge_expired_locked(current)
                    invitation = self.capture_invitations.get(key)
                if invitation is None:
                    raise PairingError("capture request is invalid, expired, or already used", HTTPStatus.GONE)
                if invitation.review_origin != origin:
                    raise PairingError("capture request was not reviewed by this Extension Origin", HTTPStatus.FORBIDDEN)
                if invitation.source_id != source_id or invitation.action != action:
                    raise PairingError("capture no longer matches the reviewed source or action", HTTPStatus.CONFLICT)
                if not hmac.compare_digest(invitation.base_sha256, base_sha256):
                    raise PairingError("If-Match does not identify the reviewed base library", HTTPStatus.PRECONDITION_FAILED)
                if not hmac.compare_digest(invitation.preview_sha256, preview_digest):
                    raise PairingError("capture preview digest does not match", HTTPStatus.CONFLICT)
            else:
                if not hmac.compare_digest(str(durable_job.get("requestSha256") or ""), request_sha256):
                    raise PairingError("that Idempotency-Key was already used for different capture evidence", HTTPStatus.CONFLICT)
                if str(durable_job.get("sourceId") or "") != source_id:
                    raise PairingError("durable capture belongs to another source", HTTPStatus.CONFLICT)
                if not hmac.compare_digest(str(durable_job.get("baseLibrarySha256") or ""), base_sha256):
                    raise PairingError("durable capture belongs to another library revision", HTTPStatus.CONFLICT)
                if not hmac.compare_digest(str(durable_job.get("previewDigest") or ""), preview_digest):
                    raise PairingError("durable capture belongs to another review", HTTPStatus.CONFLICT)

            # Validate the exact artifact and all human acknowledgements before
            # creating durable intent.  Unlike Witness, Capture performs no Node
            # network request after intent creation, so malformed or unacknowledged
            # browser evidence should leave no resumable job behind.
            document, raw, _revision, _updated_at = self.current_document()
            current_digest = hashlib.sha256(raw).hexdigest()
            if not hmac.compare_digest(current_digest, base_sha256):
                raise PairingError("the Node library changed after capture review", HTTPStatus.PRECONDITION_FAILED)
            try:
                preview_now = source_preview(document, source_id)
            except AcquisitionError as exc:
                raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
            if preview_now.get("type") != "page":
                raise PairingError("the reviewed source is no longer a watched page", HTTPStatus.CONFLICT)
            expected_action = "enable-and-capture" if preview_now.get("paused") else "capture-now"
            if expected_action != action:
                raise PairingError("source state changed after capture review", HTTPStatus.PRECONDITION_FAILED)
            source_row = next((
                row for row in document.get("state", {}).get("sources", [])
                if isinstance(row, dict) and str(row.get("id") or "") == source_id
            ), None)
            if source_row is None:
                raise PairingError("source is no longer present", HTTPStatus.CONFLICT)
            current_recipe_sha256 = page_recipe_digest(page_recipe(source_row))
            if invitation is not None and not hmac.compare_digest(current_recipe_sha256, invitation.recipe_sha256):
                raise PairingError("the watched-page recipe changed after capture review", HTTPStatus.PRECONDITION_FAILED)
            try:
                normalized = validate_browser_capture(
                    artifact, source_id=source_id, source_url=source_row.get("url"), now=current,
                )
            except AcquisitionError as exc:
                status = HTTPStatus.BAD_REQUEST if exc.outcome in {"refused", "malformed"} else HTTPStatus.CONFLICT
                raise PairingError(str(exc), status) from exc
            incoming_recipe_sha256 = page_recipe_digest(normalized["recipe"])
            recipe_changed = not hmac.compare_digest(current_recipe_sha256, incoming_recipe_sha256)
            if recipe_changed and not recipe_change_acknowledged:
                raise PairingError("changing the watched section requires explicit acknowledgement", HTTPStatus.CONFLICT)

            try:
                started = self.store.begin_acquisition(
                    operation_id=operation_id, request_sha256=request_sha256,
                    source_id=source_id, base_sha256=base_sha256,
                    preview_sha256=preview_digest, now=current,
                )
            except NodeStoreConflict as exc:
                message = str(exc)
                status = HTTPStatus.PRECONDITION_FAILED if "changed after" in message else HTTPStatus.CONFLICT
                raise PairingError(message, status) from exc
            except NodeStoreError as exc:
                raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
            if started.replayed and started.receipt is not None:
                return started.receipt, True

            stamp = _utc_iso_millis(current + 0.001 if now is not None else None)
            try:
                applied = apply_browser_capture(
                    document, source_id, normalized, stamp=stamp,
                    enable=action == "enable-and-capture", now=current,
                )
            except AcquisitionError as exc:
                raise PairingError(str(exc), HTTPStatus.BAD_REQUEST) from exc
            source_identity_sha256, _source_identity_material = acquisition_source_identity(source_row)
            selection = normalized.get("selection") if isinstance(normalized.get("selection"), dict) else None
            assessment = selection.get("assessment") if isinstance(selection, dict) and isinstance(selection.get("assessment"), dict) else None
            context = normalized.get("context") if isinstance(normalized.get("context"), dict) else None
            context_notices = context.get("notices", []) if isinstance(context, dict) and isinstance(context.get("notices"), list) else []
            context_signals = context.get("signals", {}) if isinstance(context, dict) and isinstance(context.get("signals"), dict) else {}
            coverage = normalized.get("coverage") if isinstance(normalized.get("coverage"), dict) else None
            coverage_kinds = coverage.get("acknowledgedNoticeKinds", []) if isinstance(coverage, dict) and isinstance(coverage.get("acknowledgedNoticeKinds"), list) else []
            continuity = applied.evidence.get("continuity") if isinstance(applied.evidence, dict) and isinstance(applied.evidence.get("continuity"), dict) else None
            request_record = {
                "operationType": CAPTURE_TYPE_RENDERED_PAGE,
                "action": action,
                "sourceIdentitySha256": source_identity_sha256,
                "sourceType": "page",
                "sourceTitle": preview_now.get("title"),
                "sourceHost": preview_now.get("site"),
                "networkRequests": 0,
                "transport": "extension-rendered-dom",
                "artifactSchema": normalized.get("schema", CAPTURE_ARTIFACT_SCHEMA),
                "artifactSha256": artifact_sha256,
                "extractorRevision": normalized.get("provenance", {}).get("extractorRevision", ""),
                "selectionCandidateId": selection.get("candidateId", "") if selection else "",
                "selectionLevel": assessment.get("level", "") if assessment else "",
                "selectionSummary": assessment.get("summary", "") if assessment else "",
                "pageContextSchema": context.get("schema", "") if context else "",
                "pageContextKinds": [str(row.get("kind") or "") for row in context_notices if isinstance(row, dict) and row.get("kind")],
                "possibleContinuation": any(isinstance(row, dict) and row.get("kind") == "continuation" for row in context_notices),
                "possiblePartialRendering": any(isinstance(row, dict) and row.get("kind") == "partial-render" for row in context_notices),
                "modalLayers": int(context_signals.get("modalLayers") or 0),
                "embeddedFrames": int(context_signals.get("embeddedFrames") or 0),
                "openShadowRoots": int(context_signals.get("openShadowRoots") or 0),
                "busyRegions": int(context_signals.get("busyRegions") or 0),
                "coverageReviewSchema": coverage.get("schema", "") if coverage else "",
                "coverageDecision": coverage.get("decision", "") if coverage else "",
                "acknowledgedBoundaryKinds": [str(row) for row in coverage_kinds],
                "partialViewAcknowledged": bool(coverage and coverage.get("decision") == "use-current-rendering"),
                "continuitySchema": continuity.get("schema", "") if continuity else "",
                "continuityAction": continuity.get("action", "") if continuity else "",
                "continuityReason": continuity.get("reason", "") if continuity else "",
                "continuityOverlapPercent": int(continuity.get("overlapPercent") or 0) if continuity else 0,
                "baselinePreserved": bool(continuity and continuity.get("baselinePreserved")),
                "recipeChanged": recipe_changed,
                "recipeChangeAcknowledged": bool(recipe_change_acknowledged),
                "topFrameOnly": True,
                "isolatedWorld": True,
                "browserMayAlreadyBeSignedIn": True,
                "browserCookiesTransferred": False,
                "browserCredentialsTransferred": False,
                "browserStorageTransferred": False,
                "rawHtmlTransferred": False,
                "screenshotTransferred": False,
                "automaticScheduleCreated": False,
                "resumed": bool(started.resumed),
                "attempt": int(started.attempt),
            }
            evidence = {**copy.deepcopy(applied.evidence), "browserCapture": copy.deepcopy(request_record)}
            held_capture = None
            if applied.outcome == "coverage-shift":
                accepted_snapshot = document.get("state", {}).get("snapshots", {}).get(source_id) if isinstance(document.get("state", {}).get("snapshots"), dict) else None
                if not isinstance(accepted_snapshot, dict):
                    raise PairingError("the accepted page baseline disappeared before the held observation could be stored", HTTPStatus.CONFLICT)
                proposed_snapshot = browser_capture_snapshot(normalized, stamp=stamp)
                proposed_provenance = browser_capture_provenance(normalized, artifact_sha256=artifact_sha256)
                held_capture = {
                    "sourceIdentitySha256": source_identity_sha256,
                    "artifactSha256": artifact_sha256,
                    "acceptedSnapshotSha256": _canonical_sha256(accepted_snapshot),
                    "proposedSnapshotSha256": _canonical_sha256(proposed_snapshot),
                    "proposedSnapshot": proposed_snapshot,
                    "proposedProvenance": proposed_provenance,
                    "continuity": copy.deepcopy(continuity or {}),
                }
            try:
                committed = self.store.commit_acquisition(
                    operation_id=operation_id, request_sha256=request_sha256,
                    source_id=source_id, base_sha256=base_sha256,
                    preview_sha256=preview_digest, result_document=applied.document,
                    outcome=applied.outcome, summary=applied.summary,
                    evidence=evidence, request=request_record,
                    held_capture=held_capture, clear_capture_hold=applied.outcome != "coverage-shift",
                    now=(current + 0.002 if now is not None else None),
                )
            except NodeStoreConflict as exc:
                message = str(exc)
                status = HTTPStatus.PRECONDITION_FAILED if "changed after" in message else HTTPStatus.CONFLICT
                raise PairingError(message, status) from exc
            except NodeStoreError as exc:
                raise PairingError(str(exc), HTTPStatus.CONFLICT) from exc
            with self.lock:
                self.capture_invitations.pop(key, None)
            return committed.receipt, committed.replayed

    def create_exchange_preview(
        self,
        *,
        folder: str,
        curator: str = "",
        note: str = "",
        public_update_url: str = "",
        include_recent_updates: bool = True,
        now: float | None = None,
    ) -> tuple[str, dict[str, Any]]:
        current = time.time() if now is None else float(now)
        document, raw, _revision, _updated_at = self.current_document()
        library_sha256 = hashlib.sha256(raw).hexdigest()
        try:
            prepared = prepare_exchange(
                document["state"],
                folder,
                library_file=self.backup.name,
                library_sha256=library_sha256,
                curator=curator,
                note=note,
                public_update_url=public_update_url,
                include_recent_updates=include_recent_updates,
                generated_at=_utc_iso_millis(current),
            )
        except ExchangeError as exc:
            raise PairingError(str(exc), HTTPStatus.BAD_REQUEST) from exc
        token = _new_token()
        preview = ExchangePreview(
            token_key=_token_key(token),
            created_at=current,
            expires_at=current + EXCHANGE_PREVIEW_TTL_SECONDS,
            library_sha256=library_sha256,
            prepared=prepared,
        )
        with self.lock:
            self._purge_expired_locked(current)
            self.exchange_previews[preview.token_key] = preview
        result = copy.deepcopy(prepared.preview)
        result.update({
            "state": "preview",
            "previewToken": token,
            "expiresAt": _utc_iso(preview.expires_at),
            "expiresInSeconds": EXCHANGE_PREVIEW_TTL_SECONDS,
        })
        return token, result

    def create_exchange(
        self,
        preview_token: str,
        *,
        preview_digest: str,
        library_sha256: str,
        now: float | None = None,
    ) -> tuple[str, dict[str, Any]]:
        current = time.time() if now is None else float(now)
        key = _token_key(preview_token)
        with self.lock:
            self._purge_expired_locked(current)
            preview = self.exchange_previews.get(key)
        if not preview:
            raise PairingError("exchange preview is invalid or expired", HTTPStatus.GONE)
        if not hmac.compare_digest(str(preview.prepared.preview.get("previewDigest") or ""), preview_digest):
            raise PairingError("exchange preview digest does not match", HTTPStatus.CONFLICT)
        if not hmac.compare_digest(preview.library_sha256, library_sha256):
            raise PairingError("exchange library digest does not match the reviewed copy", HTTPStatus.CONFLICT)
        _document, raw, _revision, _updated_at = self.current_document()
        current_digest = hashlib.sha256(raw).hexdigest()
        if not hmac.compare_digest(current_digest, preview.library_sha256):
            raise PairingError("selected library changed after exchange review; review it again", HTTPStatus.CONFLICT)
        exchange_token = _new_token()
        exchange_id = secrets.token_hex(10)
        grant = ExchangeGrant(
            exchange_id=exchange_id,
            token_key=_token_key(exchange_token),
            created_at=current,
            expires_at=current + EXCHANGE_TTL_SECONDS,
            library_sha256=current_digest,
            prepared=preview.prepared,
        )
        with self.lock:
            current_preview = self.exchange_previews.get(key)
            if current_preview is not preview:
                raise PairingError("exchange preview was already used", HTTPStatus.CONFLICT)
            self.exchange_previews.pop(key, None)
            self.exchanges[exchange_id] = grant
        document = self.exchange_document(grant, state="created")
        return exchange_token, document

    def exchange_for_token(self, token: str, *, origin: str, now: float | None = None) -> ExchangeGrant:
        if not _extension_origin(origin):
            raise PairingError("a browser-extension Origin is required", HTTPStatus.FORBIDDEN)
        current = time.time() if now is None else float(now)
        key = _token_key(token)
        with self.lock:
            self._purge_expired_locked(current)
            for grant in self.exchanges.values():
                if hmac.compare_digest(grant.token_key, key):
                    if grant.review_origin and grant.review_origin != origin:
                        raise PairingError("exchange invitation belongs to another extension Origin", HTTPStatus.FORBIDDEN)
                    grant.review_origin = origin
                    return grant
        raise PairingError("exchange invitation is invalid, expired, or revoked", HTTPStatus.UNAUTHORIZED)

    def exchange_by_id(self, exchange_id: str) -> ExchangeGrant:
        with self.lock:
            self._purge_expired_locked(time.time())
            grant = self.exchanges.get(exchange_id)
        if not grant:
            raise PairingError("exchange is no longer active", HTTPStatus.NOT_FOUND)
        return grant

    def revoke_exchange_id(self, exchange_id: str) -> ExchangeGrant:
        with self.lock:
            grant = self.exchanges.pop(exchange_id, None)
        if not grant:
            raise PairingError("exchange is no longer active", HTTPStatus.NOT_FOUND)
        return grant

    def list_exchanges(self) -> list[dict[str, Any]]:
        with self.lock:
            self._purge_expired_locked(time.time())
            grants = list(self.exchanges.values())
        grants.sort(key=lambda row: row.created_at)
        return [self.exchange_summary(row) for row in grants]

    @staticmethod
    def exchange_summary(grant: ExchangeGrant) -> dict[str, Any]:
        preview = grant.prepared.preview
        return {
            "exchangeId": grant.exchange_id,
            "title": preview.get("title", ""),
            "folder": preview.get("folder", {}),
            "counts": preview.get("counts", {}),
            "choices": preview.get("choices", {}),
            "createdAt": _utc_iso(grant.created_at),
            "expiresAt": _utc_iso(grant.expires_at),
            "reviewed": bool(grant.review_origin),
            "librarySha256": grant.library_sha256,
        }

    def exchange_document(self, grant: ExchangeGrant, *, state: str) -> dict[str, Any]:
        document = copy.deepcopy(grant.prepared.preview)
        document.update({
            "schema": EXCHANGE_SCHEMA,
            "state": state,
            "exchangeId": grant.exchange_id,
            "createdAt": _utc_iso(grant.created_at),
            "expiresAt": _utc_iso(grant.expires_at),
            "node": {
                "origin": self.origin,
                "version": VERSION,
                "revision": REVISION,
                "instanceFingerprint": self.fingerprint,
                "identityPersistence": "until-node-stops",
            },
            "scope": "one-expiring-reviewed-artifact-handoff",
            "automatic": False,
            "revocable": True,
        })
        document.pop("previewToken", None)
        return document

    def exchange_artifact(self, grant: ExchangeGrant, kind: str) -> tuple[str, str, bytes]:
        artifact = grant.prepared.artifacts().get(kind)
        if artifact is None:
            raise PairingError("that exchange artifact is not available", HTTPStatus.NOT_FOUND)
        return artifact

    def pairing_document(
        self,
        *,
        state: str,
        expires_at: float | None = None,
        grant: PairingGrant | None = None,
        snapshot: dict[str, Any] | None = None,
        stats: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        if snapshot is None or stats is None:
            snapshot, stats = self.snapshot()
        document: dict[str, Any] = {
            "schema": PAIRING_SCHEMA,
            "state": state,
            "node": {
                "origin": self.origin,
                "version": VERSION,
                "revision": REVISION,
                "instanceFingerprint": self.fingerprint,
                "identityPersistence": "until-node-stops",
            },
            "library": {
                **snapshot["library"],
                "stats": stats,
            },
            "capabilities": _pairing_capabilities(),
            "scope": "loopback-session-read-only-summary",
            "automatic": False,
            "revocable": True,
        }
        if expires_at is not None:
            document["expiresAt"] = _utc_iso(expires_at)
        if grant is not None:
            document["pairing"] = self.pairing_summary(grant)
        return document


class NodeHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = False

    def __init__(self, address: tuple[str, int], handler: type[BaseHTTPRequestHandler], node: NodeState):
        super().__init__(address, handler)
        self.node = node


class NodeHandler(BaseHTTPRequestHandler):
    server_version = "ProgRSSNode/0.73"
    sys_version = ""

    @property
    def node(self) -> NodeState:
        return self.server.node  # type: ignore[attr-defined]

    def log_message(self, fmt: str, *args: Any) -> None:
        # Avoid putting capability-bearing URLs or request headers in ordinary logs.
        return

    def _security_headers(self, *, content_type: str, cache: str = "no-store") -> None:
        self.send_header("Content-Type", content_type)
        self.send_header("Cache-Control", cache)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Cross-Origin-Resource-Policy", "same-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=(), usb=(), web-share=(self)")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
            "connect-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'",
        )

    def _host_is_exact(self) -> bool:
        return self.headers.get("Host", "") == urllib.parse.urlsplit(self.node.origin).netloc

    def _origin_is_allowed(self) -> bool:
        origin = self.headers.get("Origin")
        return not origin or origin == self.node.origin

    def _extension_origin(self) -> str:
        origin = self.headers.get("Origin", "")
        return origin if _extension_origin(origin) else ""

    def _authorized(self) -> bool:
        value = self.headers.get("Authorization", "")
        prefix = "Bearer "
        return value.startswith(prefix) and hmac.compare_digest(value[len(prefix):], self.node.token)

    def _bearer(self) -> str:
        value = self.headers.get("Authorization", "")
        prefix = "Bearer "
        return value[len(prefix):] if value.startswith(prefix) else ""

    def _send_bytes(
        self, status: int, body: bytes, content_type: str, *, cache: str = "no-store",
        extra_headers: Mapping[str, str] | None = None,
    ) -> None:
        self.send_response(status)
        self._security_headers(content_type=content_type, cache=cache)
        for key, value in (extra_headers or {}).items():
            self.send_header(str(key), str(value))
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _send_json(
        self, status: int, value: Any, *, extra_headers: Mapping[str, str] | None = None,
    ) -> None:
        body = (json.dumps(value, ensure_ascii=False, separators=(",", ":")) + "\n").encode("utf-8")
        self._send_bytes(status, body, "application/json; charset=utf-8", extra_headers=extra_headers)

    def _send_download(
        self, status: int, body: bytes, content_type: str, filename: str, *,
        extra_headers: Mapping[str, str] | None = None,
    ) -> None:
        safe_name = "".join(ch for ch in filename if ch.isalnum() or ch in {"-", "_", "."})[:160] or "progrss-artifact.bin"
        self.send_response(status)
        self._security_headers(content_type=content_type)
        self.send_header("Content-Disposition", f'attachment; filename="{safe_name}"')
        for key, value in (extra_headers or {}).items():
            self.send_header(str(key), str(value))
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _reject(self, status: int, message: str) -> None:
        self._send_json(status, {"error": message, "status": int(status)})

    def _read_json(self, max_bytes: int = MAX_REQUEST_BYTES) -> dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise PairingError("invalid Content-Length", HTTPStatus.BAD_REQUEST) from exc
        if length < 0 or length > max_bytes:
            raise PairingError("request too large", HTTPStatus.REQUEST_ENTITY_TOO_LARGE)
        raw = self.rfile.read(length) if length else b"{}"
        try:
            value = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise PairingError("request body must be a JSON object", HTTPStatus.BAD_REQUEST) from exc
        if not isinstance(value, dict):
            raise PairingError("request body must be a JSON object", HTTPStatus.BAD_REQUEST)
        return value

    def _serve_static(self, relative: str) -> None:
        if relative not in {"index.html", "app.css", "app.js"}:
            self._reject(HTTPStatus.NOT_FOUND, "not found")
            return
        path = WEB_ROOT / relative
        try:
            body = path.read_bytes()
        except OSError:
            self._reject(HTTPStatus.INTERNAL_SERVER_ERROR, "node asset missing")
            return
        content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        if content_type.startswith("text/") or content_type in {"application/javascript"}:
            content_type += "; charset=utf-8"
        self._send_bytes(HTTPStatus.OK, body, content_type, cache="no-cache")

    def _pairing_error(self, exc: PairingError) -> None:
        self._reject(exc.status, str(exc))

    def do_HEAD(self) -> None:  # noqa: N802
        self.do_GET()

    def do_GET(self) -> None:  # noqa: N802
        if not self._host_is_exact():
            self._reject(HTTPStatus.FORBIDDEN, "unexpected Host header")
            return
        path = urllib.parse.urlsplit(self.path).path
        if path in {"/", "/index.html"}:
            if not self._origin_is_allowed():
                self._reject(HTTPStatus.FORBIDDEN, "foreign Origin refused")
                return
            self._serve_static("index.html")
            return
        if path == "/app.css":
            if not self._origin_is_allowed():
                self._reject(HTTPStatus.FORBIDDEN, "foreign Origin refused")
                return
            self._serve_static("app.css")
            return
        if path == "/app.js":
            if not self._origin_is_allowed():
                self._reject(HTTPStatus.FORBIDDEN, "foreign Origin refused")
                return
            self._serve_static("app.js")
            return
        if path == "/favicon.ico":
            self._send_bytes(HTTPStatus.NO_CONTENT, b"", "image/x-icon")
            return
        if path == "/api/v1/pairing-review":
            origin = self._extension_origin()
            if not origin:
                self._reject(HTTPStatus.FORBIDDEN, "a browser-extension Origin is required")
                return
            try:
                document = self.node.review_invitation(self._bearer(), origin=origin)
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_json(HTTPStatus.OK, document)
            return
        if path == "/api/v1/pairing":
            origin = self._extension_origin()
            if not origin:
                self._reject(HTTPStatus.FORBIDDEN, "a browser-extension Origin is required")
                return
            try:
                grant = self.node.pairing_for_token(self._bearer(), origin=origin)
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_json(HTTPStatus.OK, self.node.pairing_document(state="paired", grant=grant))
            return
        if path == "/api/v1/capture-review":
            origin = self._extension_origin()
            if not origin:
                self._reject(HTTPStatus.FORBIDDEN, "a browser-extension Origin is required")
                return
            try:
                document = self.node.review_capture_invitation(self._bearer(), origin=origin)
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_json(HTTPStatus.OK, document)
            return
        if path == "/api/v1/exchange-review":
            origin = self._extension_origin()
            if not origin:
                self._reject(HTTPStatus.FORBIDDEN, "a browser-extension Origin is required")
                return
            try:
                grant = self.node.exchange_for_token(self._bearer(), origin=origin)
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_json(HTTPStatus.OK, self.node.exchange_document(grant, state="review"))
            return
        if path in {
            "/api/v1/exchange/source-list",
            "/api/v1/exchange/recent-updates",
        }:
            origin = self._extension_origin()
            if not origin:
                self._reject(HTTPStatus.FORBIDDEN, "a browser-extension Origin is required")
                return
            kind = "source-list" if path.endswith("source-list") else "recent-updates"
            try:
                grant = self.node.exchange_for_token(self._bearer(), origin=origin)
                filename, content_type, body = self.node.exchange_artifact(grant, kind)
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_download(HTTPStatus.OK, body, content_type, filename)
            return
        if not self._origin_is_allowed():
            self._reject(HTTPStatus.FORBIDDEN, "foreign Origin refused")
            return
        if not path.startswith("/api/"):
            self._reject(HTTPStatus.NOT_FOUND, "not found")
            return
        if not self._authorized():
            self._reject(HTTPStatus.UNAUTHORIZED, "node capability required")
            return
        if path == "/api/v1/status":
            try:
                snapshot, stats = self.node.snapshot()
                operations = self.node.list_operations()
                acquisitions = self.node.list_acquisitions()
            except NodeError as exc:
                self._reject(HTTPStatus.CONFLICT, str(exc))
                return
            node_owned = self.node.node_owned
            self._send_json(HTTPStatus.OK, {
                "schema": STATUS_SCHEMA,
                "version": VERSION,
                "revision": REVISION,
                "scope": "loopback-node-owned" if node_owned else "loopback-exported-backup",
                "library": snapshot["library"],
                "instanceFingerprint": self.node.fingerprint,
                "stats": stats,
                "capabilities": {
                    "readLibrary": True,
                    "writeLibrary": node_owned,
                    "adoptReviewedBranch": node_owned,
                    "durableOperationReceipts": node_owned,
                    "rollbackSnapshots": node_owned,
                    "fetchSources": node_owned,
                    "manualAcquisition": node_owned,
                    "browserAssistedCapture": node_owned,
                    "reviewHeldWindows": node_owned,
                    "replaceHeldBaseline": node_owned,
                    "scheduledAcquisition": False,
                    "publish": False,
                    "prepareExchange": True,
                    "preparePublicationPackage": True,
                    "reviewLaterCopy": True,
                    "pairExtension": True,
                    "nodeToNode": False,
                    "webrtcCourier": False,
                },
                "pairingCapabilities": _pairing_capabilities(),
                "activePairings": len(self.node.list_pairings()),
                "activeExchanges": len(self.node.list_exchanges()),
                "operationReceipts": len(operations),
                "acquisitionReceipts": len(acquisitions.get("receipts", [])),
                "interruptedAcquisitions": sum(1 for row in acquisitions.get("jobs", []) if row.get("state") == "started"),
            })
            return
        if path == "/api/v1/library":
            try:
                snapshot, _stats = self.node.snapshot()
            except NodeError as exc:
                self._reject(HTTPStatus.CONFLICT, str(exc))
                return
            digest = str(snapshot.get("library", {}).get("sha256") or "")
            headers = {"ETag": f'"{digest}"'} if len(digest) == 64 else None
            self._send_json(HTTPStatus.OK, snapshot, extra_headers=headers)
            return
        if path == "/api/v1/pairings":
            self._send_json(HTTPStatus.OK, {
                "schema": PAIRING_SCHEMA,
                "state": "admin-list",
                "pairings": self.node.list_pairings(),
            })
            return
        if path == "/api/v1/curation":
            try:
                document, raw, revision, updated_at = self.node.current_document()
            except NodeError as exc:
                self._reject(HTTPStatus.CONFLICT, str(exc))
                return
            folders = [row for row in _simple_folder_rows(document["state"]) if int(row.get("sourceCount") or 0) > 0]
            self._send_json(HTTPStatus.OK, {
                "schema": EXCHANGE_SCHEMA,
                "state": "curation",
                "library": {
                    "file": self.node.backup.name,
                    "mode": self.node.library_mode,
                    "sha256": hashlib.sha256(raw).hexdigest(),
                    "revision": revision,
                    "updatedAt": updated_at,
                },
                "folders": folders,
                "readOnly": True,
                "operationAvailable": self.node.node_owned,
                "network": False,
                "writes": False,
            })
            return
        if path == "/api/v1/exchanges":
            self._send_json(HTTPStatus.OK, {
                "schema": EXCHANGE_SCHEMA,
                "state": "admin-list",
                "exchanges": self.node.list_exchanges(),
            })
            return
        if path == "/api/v1/operations":
            try:
                operations = self.node.list_operations()
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_json(HTTPStatus.OK, {
                "schema": OPERATION_RESULT_SCHEMA,
                "state": "admin-list",
                "nodeOwned": self.node.node_owned,
                "operations": operations,
                "network": False,
                "writes": False,
            })
            return
        if path == "/api/v1/acquisitions":
            try:
                acquisitions = self.node.list_acquisitions()
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_json(HTTPStatus.OK, {
                "schema": ACQUISITION_RESULT_SCHEMA,
                "state": "admin-list",
                "nodeOwned": self.node.node_owned,
                **acquisitions,
                "automaticSchedule": False,
                "network": False,
                "writes": False,
            })
            return
        if path == "/api/v1/operation-snapshot":
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            snapshot_id = _safe_text((query.get("id") or [""])[0], 100)
            try:
                body, digest, operation_id = self.node.operation_snapshot(snapshot_id)
            except PairingError as exc:
                self._pairing_error(exc)
                return
            filename = f"progrss-before-{operation_id[:36]}.json"
            self._send_download(
                HTTPStatus.OK, body, "application/json; charset=utf-8", filename,
                extra_headers={"ETag": f'"{digest}"', "X-ProgRSS-Snapshot-Id": snapshot_id},
            )
            return
        if path == "/api/v1/exchange-artifact":
            query = urllib.parse.parse_qs(urllib.parse.urlsplit(self.path).query)
            exchange_id = _safe_text((query.get("id") or [""])[0], 80)
            kind = _safe_text((query.get("kind") or [""])[0], 40)
            try:
                grant = self.node.exchange_by_id(exchange_id)
                filename, content_type, body = self.node.exchange_artifact(grant, kind)
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_download(HTTPStatus.OK, body, content_type, filename)
            return
        self._reject(HTTPStatus.NOT_FOUND, "unknown API route")

    def do_POST(self) -> None:  # noqa: N802
        if not self._host_is_exact():
            self._reject(HTTPStatus.FORBIDDEN, "unexpected Host header")
            return
        path = urllib.parse.urlsplit(self.path).path
        if path == "/api/v1/pairings":
            origin = self._extension_origin()
            if not origin:
                self._reject(HTTPStatus.FORBIDDEN, "a browser-extension Origin is required")
                return
            try:
                body = self._read_json()
                pair_token, document = self.node.accept_invitation(
                    self._bearer(),
                    origin=origin,
                    client_name=_safe_text(body.get("clientName"), 80),
                    client_version=_safe_text(body.get("clientVersion"), 40),
                )
            except PairingError as exc:
                self._pairing_error(exc)
                return
            document["token"] = pair_token
            self._send_json(HTTPStatus.CREATED, document)
            return
        if path == "/api/v1/pairing/revoke":
            origin = self._extension_origin()
            if not origin:
                self._reject(HTTPStatus.FORBIDDEN, "a browser-extension Origin is required")
                return
            try:
                if int(self.headers.get("Content-Length", "0") or 0) > MAX_REQUEST_BYTES:
                    raise PairingError("request too large", HTTPStatus.REQUEST_ENTITY_TOO_LARGE)
                if int(self.headers.get("Content-Length", "0") or 0):
                    self.rfile.read(int(self.headers.get("Content-Length", "0")))
                grant = self.node.revoke_pair_token(self._bearer(), origin=origin)
            except (ValueError, PairingError) as exc:
                if isinstance(exc, PairingError):
                    self._pairing_error(exc)
                else:
                    self._reject(HTTPStatus.BAD_REQUEST, "invalid Content-Length")
                return
            self._send_json(HTTPStatus.OK, {"schema": PAIRING_SCHEMA, "state": "revoked", "pairId": grant.pair_id})
            return
        if path == "/api/v1/captures":
            origin = self._extension_origin()
            if not origin:
                self._reject(HTTPStatus.FORBIDDEN, "a browser-extension Origin is required")
                return
            try:
                body = self._read_json(MAX_CAPTURE_REQUEST_BYTES)
            except PairingError as exc:
                self._pairing_error(exc)
                return
            if body.get("operationType") != CAPTURE_TYPE_RENDERED_PAGE:
                self._reject(HTTPStatus.BAD_REQUEST, "unsupported or missing operationType")
                return
            if_match = self.headers.get("If-Match", "")
            if not (len(if_match) == 66 and if_match.startswith('"') and if_match.endswith('"') and all(ch in "0123456789abcdef" for ch in if_match[1:-1])):
                self._reject(HTTPStatus.BAD_REQUEST, "If-Match must contain one strong quoted library SHA-256")
                return
            operation_id = self.headers.get("Idempotency-Key", "")
            if not operation_id:
                self._reject(HTTPStatus.BAD_REQUEST, "Idempotency-Key is required for a browser capture")
                return
            artifact = body.get("artifact")
            if not isinstance(artifact, dict):
                self._reject(HTTPStatus.BAD_REQUEST, "artifact must be one browser-capture object")
                return
            try:
                receipt, replayed = self.node.run_browser_capture(
                    origin=origin, token=self._bearer(), operation_id=operation_id,
                    base_sha256=if_match[1:-1], preview_digest=_safe_text(body.get("previewDigest"), 100),
                    source_id=_safe_text(body.get("sourceId"), 300), action=_safe_text(body.get("action"), 40),
                    artifact=artifact, recipe_change_acknowledged=body.get("recipeChangeAcknowledged") is True,
                )
                snapshot, _stats = self.node.snapshot()
            except PairingError as exc:
                self._pairing_error(exc)
                return
            effects = receipt.get("effects") if isinstance(receipt.get("effects"), dict) else {}
            result = {
                "schema": ACQUISITION_RESULT_SCHEMA,
                "state": "replayed" if replayed else "committed",
                "captureSchema": CAPTURE_SCHEMA,
                "replayed": replayed,
                "receipt": receipt,
                "library": snapshot["library"],
                "network": bool(effects.get("networkRequests")),
                "writes": not replayed,
                "automaticSchedule": False,
            }
            digest = str(receipt.get("resultLibrarySha256") or "")
            headers = {"Idempotency-Replayed": "true" if replayed else "false"}
            if len(digest) == 64:
                headers["ETag"] = f'"{digest}"'
            self._send_json(HTTPStatus.OK if replayed else HTTPStatus.CREATED, result, extra_headers=headers)
            return
        if self.headers.get("Origin") != self.node.origin:
            self._reject(HTTPStatus.FORBIDDEN, "same-origin POST required")
            return
        if not self._authorized():
            self._reject(HTTPStatus.UNAUTHORIZED, "node capability required")
            return
        try:
            large_body_routes = {
                "/api/v1/merge-reviews",
                "/api/v1/branch-options",
                "/api/v1/operation-previews",
            }
            body = self._read_json(MAX_BUNDLE_REQUEST_BYTES if path in large_body_routes else MAX_REQUEST_BYTES)
        except PairingError as exc:
            self._pairing_error(exc)
            return
        if path == "/api/v1/pairing-invitations":
            token, document = self.node.create_invitation()
            document["url"] = f"{self.node.origin}/#pair={urllib.parse.quote(token, safe='')}"
            document["expiresInSeconds"] = PAIRING_TTL_SECONDS
            self._send_json(HTTPStatus.CREATED, document)
            return
        if path == "/api/v1/pairings/revoke":
            try:
                grant = self.node.revoke_pair_id(_safe_text(body.get("pairId"), 80))
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_json(HTTPStatus.OK, {"schema": PAIRING_SCHEMA, "state": "revoked", "pairId": grant.pair_id})
            return
        if path == "/api/v1/branch-options":
            raw_bundle = body.get("bundle")
            if not isinstance(raw_bundle, dict):
                self._reject(HTTPStatus.BAD_REQUEST, "bundle must be one ProgRSS source-list object")
                return
            try:
                document = self.node.branch_options(raw_bundle)
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_json(HTTPStatus.OK, document)
            return
        if path == "/api/v1/capture-invitations":
            try:
                token, document = self.node.create_capture_invitation(_safe_text(body.get("sourceId"), 300))
            except PairingError as exc:
                self._pairing_error(exc)
                return
            document.pop("token", None)
            document["url"] = f"{self.node.origin}/#capture={urllib.parse.quote(token, safe='')}"
            document["expiresInSeconds"] = CAPTURE_TTL_SECONDS
            self._send_json(HTTPStatus.CREATED, document)
            return
        if path == "/api/v1/acquisition-previews":
            try:
                _token, document = self.node.create_acquisition_preview(
                    _safe_text(body.get("sourceId"), 300),
                )
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_json(HTTPStatus.CREATED, document)
            return
        if path == "/api/v1/acquisitions":
            if body.get("operationType") != ACQUISITION_TYPE_CHECK_ONCE:
                self._reject(HTTPStatus.BAD_REQUEST, "unsupported or missing operationType")
                return
            if_match = self.headers.get("If-Match", "")
            if not if_match:
                self._reject(HTTPStatus.PRECONDITION_REQUIRED, "If-Match is required for a Node acquisition")
                return
            if not (
                len(if_match) == 66
                and if_match.startswith('"')
                and if_match.endswith('"')
                and all(ch in "0123456789abcdef" for ch in if_match[1:-1])
            ):
                self._reject(HTTPStatus.BAD_REQUEST, "If-Match must contain one strong quoted library SHA-256")
                return
            operation_id = self.headers.get("Idempotency-Key", "")
            if not operation_id:
                self._reject(HTTPStatus.BAD_REQUEST, "Idempotency-Key is required for a Node acquisition")
                return
            try:
                receipt, replayed = self.node.run_acquisition(
                    operation_id=operation_id,
                    base_sha256=if_match[1:-1],
                    preview_token=_safe_text(body.get("previewToken"), 200),
                    preview_digest=_safe_text(body.get("previewDigest"), 100),
                    source_id=_safe_text(body.get("sourceId"), 300),
                    action=_safe_text(body.get("action"), 40),
                )
                snapshot, _stats = self.node.snapshot()
            except PairingError as exc:
                self._pairing_error(exc)
                return
            effects = receipt.get("effects") if isinstance(receipt.get("effects"), dict) else {}
            result = {
                "schema": ACQUISITION_RESULT_SCHEMA,
                "state": "replayed" if replayed else "committed",
                "replayed": replayed,
                "receipt": receipt,
                "library": snapshot["library"],
                "network": bool(effects.get("networkRequests")),
                "writes": not replayed,
                "automaticSchedule": False,
            }
            result_digest = str(receipt.get("resultLibrarySha256") or "")
            headers = {
                "Idempotency-Replayed": "true" if replayed else "false",
                "Location": f"/api/v1/acquisitions#{urllib.parse.quote(str(receipt.get('operationId') or ''), safe='')}",
            }
            if len(result_digest) == 64:
                headers["ETag"] = f'"{result_digest}"'
            self._send_json(HTTPStatus.OK if replayed else HTTPStatus.CREATED, result, extra_headers=headers)
            return
        if path == "/api/v1/bearing-reviews":
            try:
                document = self.node.bearing_review(_safe_text(body.get("sourceId"), 300))
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_json(HTTPStatus.OK, document)
            return
        if path == "/api/v1/fieldwork-kits":
            try:
                filename, document, scenario = self.node.fieldbook(_safe_text(body.get("sourceId"), 300))
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_download(
                HTTPStatus.OK, document, "text/html; charset=utf-8", filename,
                extra_headers={
                    "X-ProgRSS-Schema": FIELDWORK_KIT_SCHEMA,
                    "X-ProgRSS-Scenario-Digest": str(scenario.get("scenarioDigest") or ""),
                },
            )
            return
        if path == "/api/v1/exchange-fieldwork-kits":
            if set(body) != {"exchangeId"}:
                self._reject(HTTPStatus.BAD_REQUEST, "Exchange fieldwork requires exactly exchangeId")
                return
            try:
                filename, document, scenario = self.node.exchange_fieldbook(_safe_text(body.get("exchangeId"), 80))
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_download(
                HTTPStatus.OK, document, "text/html; charset=utf-8", filename,
                extra_headers={
                    "X-ProgRSS-Schema": FIELDWORK_KIT_SCHEMA,
                    "X-ProgRSS-Scenario-Digest": str(scenario.get("scenarioDigest") or ""),
                },
            )
            return
        if path == "/api/v1/exchange-sender-fieldwork-kits":
            if set(body) != {"previewToken"}:
                self._reject(HTTPStatus.BAD_REQUEST, "sender fieldwork requires exactly previewToken")
                return
            try:
                filename, document, scenario = self.node.exchange_sender_fieldbook(
                    _safe_text(body.get("previewToken"), 160)
                )
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_download(
                HTTPStatus.OK, document, "text/html; charset=utf-8", filename,
                extra_headers={
                    "X-ProgRSS-Schema": FIELDWORK_KIT_SCHEMA,
                    "X-ProgRSS-Scenario-Digest": str(scenario.get("scenarioDigest") or ""),
                },
            )
            return
        if path == "/api/v1/debrief-kits":
            if body:
                self._reject(HTTPStatus.BAD_REQUEST, "debrief workspace generation accepts no request fields")
                return
            try:
                filename, document, workspace = self.node.debrief()
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_download(
                HTTPStatus.OK, document, "text/html; charset=utf-8", filename,
                extra_headers={"X-ProgRSS-Schema": DEBRIEF_KIT_SCHEMA},
            )
            return
        if path == "/api/v1/baseline-previews":
            try:
                _token, document = self.node.create_baseline_replacement_preview(
                    _safe_text(body.get("sourceId"), 300),
                )
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_json(HTTPStatus.CREATED, document)
            return
        if path == "/api/v1/operation-previews":
            raw_bundle = body.get("bundle")
            if not isinstance(raw_bundle, dict):
                self._reject(HTTPStatus.BAD_REQUEST, "bundle must be one ProgRSS source-list object")
                return
            try:
                _token, document = self.node.create_branch_operation_preview(
                    raw_bundle, folder=_safe_text(body.get("folder"), 300),
                )
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_json(HTTPStatus.CREATED, document)
            return
        if path == "/api/v1/operations":
            operation_type = body.get("operationType")
            if operation_type not in {OPERATION_TYPE_ADOPT_BRANCH, BASELINE_REPLACEMENT_OPERATION}:
                self._reject(HTTPStatus.BAD_REQUEST, "unsupported or missing operationType")
                return
            if_match = self.headers.get("If-Match", "")
            if not if_match:
                self._reject(HTTPStatus.PRECONDITION_REQUIRED, "If-Match is required for a Node write")
                return
            if not (
                len(if_match) == 66
                and if_match.startswith('"')
                and if_match.endswith('"')
                and all(ch in "0123456789abcdef" for ch in if_match[1:-1])
            ):
                self._reject(HTTPStatus.BAD_REQUEST, "If-Match must contain one strong quoted library SHA-256")
                return
            operation_id = self.headers.get("Idempotency-Key", "")
            if not operation_id:
                self._reject(HTTPStatus.BAD_REQUEST, "Idempotency-Key is required for a Node write")
                return
            try:
                commit = self.node.commit_branch_operation if operation_type == OPERATION_TYPE_ADOPT_BRANCH else self.node.commit_baseline_replacement
                receipt, replayed = commit(
                    operation_id=operation_id,
                    base_sha256=if_match[1:-1],
                    preview_token=_safe_text(body.get("previewToken"), 200),
                    preview_digest=_safe_text(body.get("previewDigest"), 100),
                )
                snapshot, _stats = self.node.snapshot()
            except PairingError as exc:
                self._pairing_error(exc)
                return
            result = {
                "schema": OPERATION_RESULT_SCHEMA,
                "state": "replayed" if replayed else "committed",
                "replayed": replayed,
                "receipt": receipt,
                "library": snapshot["library"],
                "network": False,
                "writes": not replayed,
            }
            result_digest = str(receipt.get("resultLibrarySha256") or "")
            headers = {
                "Idempotency-Replayed": "true" if replayed else "false",
                "Location": f"/api/v1/operations#{urllib.parse.quote(str(receipt.get('operationId') or ''), safe='')}",
            }
            if len(result_digest) == 64:
                headers["ETag"] = f'"{result_digest}"'
            self._send_json(HTTPStatus.OK if replayed else HTTPStatus.CREATED, result, extra_headers=headers)
            return
        if path == "/api/v1/exchange-previews":
            try:
                _token, document = self.node.create_exchange_preview(
                    folder=_safe_text(body.get("folder"), 300),
                    curator=_safe_text(body.get("curator"), 80),
                    note=_safe_text(body.get("note"), 280),
                    public_update_url=_safe_text(body.get("publicUpdateUrl"), 4096),
                    include_recent_updates=body.get("includeRecentUpdates") is not False,
                )
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_json(HTTPStatus.CREATED, document)
            return
        if path == "/api/v1/merge-reviews":
            raw_bundle = body.get("bundle")
            if not isinstance(raw_bundle, dict):
                self._reject(HTTPStatus.BAD_REQUEST, "bundle must be one ProgRSS source-list object")
                return
            try:
                document, raw, _revision, _updated_at = self.node.current_document()
                checked = _connected_bundle(validate_bundle(copy.deepcopy(raw_bundle)))
                review = review_bundle_update(
                    document["state"], checked, _safe_text(body.get("folder"), 300),
                )
            except NodeError as exc:
                self._reject(HTTPStatus.CONFLICT, str(exc))
                return
            except RelayError as exc:
                self._reject(HTTPStatus.BAD_REQUEST, str(exc))
                return
            self._send_json(HTTPStatus.OK, {
                "schema": MERGE_REVIEW_NODE_SCHEMA,
                "state": "review",
                "library": {"file": self.node.backup.name, "sha256": hashlib.sha256(raw).hexdigest()},
                "review": review,
                "readOnly": True,
                "network": False,
                "writes": False,
            })
            return
        if path == "/api/v1/exchanges":
            try:
                exchange_token, document = self.node.create_exchange(
                    _safe_text(body.get("previewToken"), 100),
                    preview_digest=_safe_text(body.get("previewDigest"), 100),
                    library_sha256=_safe_text(body.get("librarySha256"), 100),
                )
            except PairingError as exc:
                self._pairing_error(exc)
                return
            document["url"] = f"{self.node.origin}/#exchange={urllib.parse.quote(exchange_token, safe='')}"
            document["expiresInSeconds"] = EXCHANGE_TTL_SECONDS
            self._send_json(HTTPStatus.CREATED, document)
            return
        if path == "/api/v1/exchanges/revoke":
            try:
                grant = self.node.revoke_exchange_id(_safe_text(body.get("exchangeId"), 80))
            except PairingError as exc:
                self._pairing_error(exc)
                return
            self._send_json(HTTPStatus.OK, {
                "schema": EXCHANGE_SCHEMA,
                "state": "revoked",
                "exchangeId": grant.exchange_id,
            })
            return
        if path == "/api/v1/stop":
            self._send_json(HTTPStatus.OK, {"stopping": True})
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return
        self._reject(HTTPStatus.NOT_FOUND, "unknown API route")


def serve(library: Path, *, port: int = 0, open_browser: bool = False, json_ready: bool = False) -> int:
    library = library.expanduser().resolve()
    try:
        store = NodeStore(library) if is_node_store(library) else None
    except NodeStoreError as exc:
        raise NodeError(str(exc)) from exc
    if store is not None:
        record = store.read_library()
        snapshot, stats = _library_snapshot_document(
            library.name, record.document, record.raw, node_owned=True,
            revision=record.revision, updated_at=record.updated_at,
        )
        snapshot["library"]["storeSchema"] = STORE_SCHEMA
        snapshot["library"]["storeMigratedAtOpen"] = bool(store.migrated)
    else:
        snapshot, stats = _library_snapshot(library)
    token = _new_token()
    node = NodeState(backup=library, token=token, store=store)
    httpd = NodeHTTPServer(("127.0.0.1", int(port)), NodeHandler, node)
    actual_port = int(httpd.server_address[1])
    node.origin = f"http://127.0.0.1:{actual_port}"
    node.httpd = httpd
    capability_url = f"{node.origin}/#token={urllib.parse.quote(token, safe='')}"
    node_owned = node.node_owned
    ready = {
        "schema": READY_SCHEMA,
        "version": VERSION,
        "revision": REVISION,
        "origin": node.origin,
        "url": capability_url,
        "scope": "loopback-node-owned" if node_owned else "loopback-exported-backup",
        "instanceFingerprint": node.fingerprint,
        "library": snapshot["library"],
        "stats": stats,
        "capabilities": {
            "readLibrary": True,
            "pairExtension": True,
            "prepareExchange": True,
            "preparePublicationPackage": True,
            "writeLibrary": node_owned,
            "adoptReviewedBranch": node_owned,
            "durableOperationReceipts": node_owned,
            "rollbackSnapshots": node_owned,
            "fetchSources": node_owned,
            "manualAcquisition": node_owned,
            "browserAssistedCapture": node_owned,
            "scheduledAcquisition": False,
            "publish": False,
        },
    }
    if json_ready:
        print(json.dumps(ready, ensure_ascii=False, separators=(",", ":")), flush=True)
    else:
        mode = "Node-owned transactional library" if node_owned else "exported backup · read-only"
        print(f"ProgRSS Node · {mode}", flush=True)
        print(f"Open: {capability_url}", flush=True)
        print(f"Node fingerprint: {node.fingerprint}", flush=True)
        print(f"Library: {library.name} · {stats['sources']} sources · {stats['unread']} unread", flush=True)
        if node_owned:
            print("Reviewed branch adoption, one-off source checks, bounded browser capture, read-only Bearing diagnosis, and held-baseline replacement are available with durable receipts.", flush=True)
            if store is not None and store.migrated:
                print("Store schema upgraded to progrss.node-store.v4; portable library bytes were unchanged.", flush=True)
        else:
            print("Create a Node-owned library with `progrss node init` to enable the reviewed writer.", flush=True)
        print("Extension pairing remains summary-only. Starting the Node fetches no feeds or webpages.", flush=True)
    if open_browser:
        webbrowser.open(capability_url, new=1)
    try:
        httpd.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
    return 0


__all__ = [
    "BRANCH_OPTIONS_SCHEMA",
    "CAPABILITIES_SCHEMA",
    "CAPTURE_SCHEMA",
    "CAPTURE_TTL_SECONDS",
    "CAPTURE_TYPE_RENDERED_PAGE",
    "EXCHANGE_SCHEMA",
    "EXCHANGE_PREVIEW_TTL_SECONDS",
    "EXCHANGE_TTL_SECONDS",
    "LIBRARY_SCHEMA",
    "OPERATION_PREVIEW_SCHEMA",
    "OPERATION_TTL_SECONDS",
    "OPERATION_TYPE_ADOPT_BRANCH",
    "PAIRING_SCHEMA",
    "PAIRING_TTL_SECONDS",
    "READY_SCHEMA",
    "REVISION",
    "STATUS_SCHEMA",
    "VERSION",
    "NodeError",
    "NodeHandler",
    "NodeHTTPServer",
    "NodeState",
    "PairingError",
    "serve",
]
