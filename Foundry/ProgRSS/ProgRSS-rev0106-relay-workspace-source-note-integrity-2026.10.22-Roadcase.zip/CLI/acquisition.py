#!/usr/bin/env python3
"""Bounded public acquisition for the local ProgRSS Node.

This module is deliberately narrower than a general HTTP client.  It performs one
explicitly reviewed GET for one existing feed or declarative page watch, refuses
non-public destinations, connects to the exact validated IP address, follows only
bounded same-origin redirects, retains HTTP validators, and returns a portable
library mutation plus bounded receipt evidence.

It never reads browser profiles, cookies, credentials, proxy configuration, or
browser permission stores.  It never executes page JavaScript.
"""

from __future__ import annotations

import copy
import dataclasses
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
import hashlib
import http.client
import ipaddress
import json
import math
import re
import socket
import ssl
import time
from typing import Any, Callable, Iterable, Mapping, Sequence
import urllib.parse

from progrss import (
    MAX_FEED_BYTES,
    MAX_ITEMS,
    PAGE_CHANGE_SCHEMA,
    PAGE_WATCH_HEALTH_SCHEMA,
    ProgRSSError,
    _parse_watch_html,
    _watch_capture,
    best_date,
    body_text,
    clean_text,
    ingest_feed,
    language_tag,
    page_watch_capture_health,
    page_watch_stability_decision,
    parse_feed,
    safe_http_url,
    same_origin_feed_url,
)

VERSION = "0.80.0"
ACQUISITION_PREVIEW_SCHEMA = "progrss.node.acquisition-preview.v1"
ACQUISITION_RECEIPT_SCHEMA = "progrss.node.acquisition-receipt.v1"
ACQUISITION_RESULT_SCHEMA = "progrss.node.acquisition-result.v1"
ACQUISITION_JOB_SCHEMA = "progrss.node.acquisition-job.v1"
BROWSER_CAPTURE_SCHEMA = "progrss.browser-capture.v4"
BROWSER_CAPTURE_PREVIOUS_SCHEMA = "progrss.browser-capture.v3"
BROWSER_CAPTURE_CONTOUR_SCHEMA = "progrss.browser-capture.v2"
BROWSER_CAPTURE_LEGACY_SCHEMA = "progrss.browser-capture.v1"
BROWSER_CAPTURE_SELECTION_SCHEMA = "progrss.capture-selection.v1"
BROWSER_CAPTURE_ASSESSMENT_SCHEMA = "progrss.capture-section-assessment.v1"
BROWSER_CAPTURE_CONTEXT_SCHEMA = "progrss.capture-page-context.v1"
BROWSER_CAPTURE_COVERAGE_SCHEMA = "progrss.capture-coverage-review.v1"
BROWSER_CAPTURE_PROVENANCE_SCHEMA = "progrss.browser-capture-provenance.v1"
BROWSER_CAPTURE_CONTINUITY_SCHEMA = "progrss.capture-continuity.v1"
BROWSER_CAPTURE_BASELINE_REPLACEMENT_SCHEMA = "progrss.capture-baseline-replacement.v1"
MAX_BROWSER_CAPTURE_BYTES = 300_000
MAX_BROWSER_CAPTURE_CARDS = 200
MAX_BROWSER_CAPTURE_TEXT = 120_000
MAX_REDIRECTS = 5
DEFAULT_TIMEOUT = 20.0
MAX_HEADER_VALUE = 1_024
MAX_RESOLVED_ADDRESSES = 12
_REDIRECT_STATUSES = frozenset({301, 302, 303, 307, 308})
_TEMPORARY_STATUSES = frozenset({408, 425, 429, 500, 502, 503, 504})
_PERMANENT_STATUSES = frozenset({400, 401, 403, 404, 405, 406, 410, 411, 413, 414, 415, 422, 451})


class AcquisitionError(Exception):
    """Expected acquisition failure with a stable outcome code."""

    def __init__(
        self,
        message: str,
        *,
        code: str = "acquisition-failed",
        outcome: str = "temporary-failure",
        status: int = 0,
        detail: Mapping[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = clean_text(code, 80) or "acquisition-failed"
        self.outcome = clean_text(outcome, 80) or "temporary-failure"
        self.status = max(0, min(999, int(status or 0)))
        self.detail = copy.deepcopy(dict(detail or {}))


@dataclasses.dataclass(frozen=True, slots=True)
class FetchResult:
    requested_url: str
    final_url: str
    status: int
    body: bytes
    headers: dict[str, str]
    redirects: tuple[dict[str, Any], ...]
    resolved_addresses: tuple[str, ...]
    started_at: str
    completed_at: str
    duration_ms: int
    request_count: int


@dataclasses.dataclass(frozen=True, slots=True)
class AcquisitionApplication:
    document: dict[str, Any]
    outcome: str
    summary: dict[str, Any]
    evidence: dict[str, Any]


def _iso(timestamp: float | None = None) -> str:
    value = time.time() if timestamp is None else float(timestamp)
    return datetime.fromtimestamp(value, tz=timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _safe_url(raw: Any, base: str | None = None) -> str:
    try:
        return safe_http_url(raw, base)
    except ProgRSSError as exc:
        raise AcquisitionError(str(exc), code="invalid-url", outcome="refused") from exc


def _origin(url: str) -> tuple[str, str, int]:
    parsed = urllib.parse.urlsplit(_safe_url(url))
    try:
        port = parsed.port
    except ValueError as exc:
        raise AcquisitionError("URL contains an invalid port", code="invalid-url", outcome="refused") from exc
    if port is None:
        port = 443 if parsed.scheme == "https" else 80
    return parsed.scheme, str(parsed.hostname or "").lower().rstrip("."), port


def _host_header(parsed: urllib.parse.SplitResult) -> str:
    host = str(parsed.hostname or "")
    if ":" in host and not host.startswith("["):
        host = f"[{host}]"
    port = parsed.port
    default = 443 if parsed.scheme == "https" else 80
    return host if port in (None, default) else f"{host}:{port}"


def _request_target(parsed: urllib.parse.SplitResult) -> str:
    return urllib.parse.urlunsplit(("", "", parsed.path or "/", parsed.query, ""))


def _clean_header(value: Any, limit: int = MAX_HEADER_VALUE) -> str:
    text = str(value or "").strip()
    if not text or any(ord(ch) < 32 and ch not in "\t" for ch in text):
        return ""
    return text[:limit]


def _valid_etag(value: Any) -> str:
    text = _clean_header(value, 512)
    if not text or "\r" in text or "\n" in text:
        return ""
    # Entity tags are quoted strings, optionally weak.  Keep validation strict
    # enough to avoid header injection without attempting to canonicalize them.
    return text if re.fullmatch(r'(?:W/)?"[^"\r\n]{0,480}"', text) else ""


def _valid_http_date(value: Any) -> str:
    text = _clean_header(value, 128)
    if not text:
        return ""
    try:
        parsed = parsedate_to_datetime(text)
    except (TypeError, ValueError, OverflowError):
        return ""
    return text if parsed is not None else ""


def _is_public_ip(value: str) -> bool:
    try:
        address = ipaddress.ip_address(value)
    except ValueError:
        return False
    # is_global excludes private, loopback, link-local, multicast, unspecified,
    # documentation, benchmark, carrier-grade NAT, and other special ranges.
    return bool(address.is_global)


def resolve_public_addresses(
    host: str,
    port: int,
    *,
    resolver: Callable[..., Sequence[tuple[Any, ...]]] = socket.getaddrinfo,
) -> tuple[str, ...]:
    """Resolve once, reject every non-public answer, and return exact IPs.

    Rejecting a mixed public/private answer is intentionally conservative.  It
    prevents a hostname from becoming a lottery between a public site and a local
    service, and the exact chosen address is used for the connection below.
    """
    try:
        rows = resolver(host, port, socket.AF_UNSPEC, socket.SOCK_STREAM)
    except socket.gaierror as exc:
        raise AcquisitionError(
            f"could not resolve {host}", code="dns-failure", outcome="temporary-failure",
            detail={"host": host},
        ) from exc
    addresses: list[str] = []
    for row in rows:
        try:
            candidate = str(row[4][0])
            canonical = str(ipaddress.ip_address(candidate))
        except (IndexError, TypeError, ValueError):
            continue
        if canonical not in addresses:
            addresses.append(canonical)
        if len(addresses) >= MAX_RESOLVED_ADDRESSES:
            break
    if not addresses:
        raise AcquisitionError(
            f"{host} did not resolve to a usable address", code="dns-empty", outcome="temporary-failure",
            detail={"host": host},
        )
    blocked = [address for address in addresses if not _is_public_ip(address)]
    if blocked:
        raise AcquisitionError(
            "ProgRSS refused a non-public destination before connecting",
            code="non-public-destination",
            outcome="refused",
            detail={"host": host, "blockedAddresses": blocked[:6]},
        )
    return tuple(addresses)


class _PinnedHTTPConnection(http.client.HTTPConnection):
    def __init__(self, host: str, port: int, *, connect_ip: str, timeout: float) -> None:
        super().__init__(host=host, port=port, timeout=timeout)
        self._connect_ip = connect_ip

    def connect(self) -> None:  # pragma: no cover - exercised through fetch tests
        self.sock = socket.create_connection((self._connect_ip, self.port), self.timeout)
        if self._tunnel_host:
            self._tunnel()


class _PinnedHTTPSConnection(http.client.HTTPSConnection):
    def __init__(
        self,
        host: str,
        port: int,
        *,
        connect_ip: str,
        timeout: float,
        context: ssl.SSLContext,
    ) -> None:
        super().__init__(host=host, port=port, timeout=timeout, context=context)
        self._connect_ip = connect_ip

    def connect(self) -> None:  # pragma: no cover - exercised through fetch tests
        raw = socket.create_connection((self._connect_ip, self.port), self.timeout)
        try:
            self.sock = self._context.wrap_socket(raw, server_hostname=self.host)
        except Exception:
            raw.close()
            raise


def _open_connection(
    parsed: urllib.parse.SplitResult,
    connect_ip: str,
    timeout: float,
    *,
    context: ssl.SSLContext | None = None,
) -> http.client.HTTPConnection:
    port = parsed.port or (443 if parsed.scheme == "https" else 80)
    host = str(parsed.hostname or "")
    if parsed.scheme == "https":
        return _PinnedHTTPSConnection(
            host, port, connect_ip=connect_ip, timeout=timeout,
            context=context or ssl.create_default_context(),
        )
    return _PinnedHTTPConnection(host, port, connect_ip=connect_ip, timeout=timeout)


def _selected_headers(response: http.client.HTTPResponse) -> dict[str, str]:
    result: dict[str, str] = {}
    for incoming, outgoing, limit in (
        ("Content-Type", "contentType", 256),
        ("Content-Length", "contentLength", 64),
        ("Content-Encoding", "contentEncoding", 80),
        ("Cache-Control", "cacheControl", 512),
        ("Date", "date", 128),
        ("ETag", "etag", 512),
        ("Last-Modified", "lastModified", 128),
        ("Retry-After", "retryAfter", 128),
        ("Location", "location", 2_048),
    ):
        value = _clean_header(response.getheader(incoming), limit)
        if value:
            result[outgoing] = value
    return result


def fetch_public_resource(
    source: Mapping[str, Any],
    *,
    timeout: float = DEFAULT_TIMEOUT,
    max_bytes: int = MAX_FEED_BYTES,
    now: float | None = None,
    resolver: Callable[..., Sequence[tuple[Any, ...]]] = socket.getaddrinfo,
    connection_factory: Callable[[urllib.parse.SplitResult, str, float], http.client.HTTPConnection] | None = None,
) -> FetchResult:
    """Fetch one feed or static page with no ambient authority.

    ``connection_factory`` is a deterministic test seam.  Production callers use
    the pinned-IP connections above.
    """
    requested = _safe_url(source.get("url"))
    if source.get("type") not in {"rss", "page"}:
        raise AcquisitionError("only feed and page-watch sources can be checked", code="unsupported-source", outcome="refused")
    timeout = max(1.0, min(float(timeout), 60.0))
    max_bytes = max(1, min(int(max_bytes), MAX_FEED_BYTES))
    started_clock = time.time() if now is None else float(now)
    started_at = _iso(started_clock)
    url = requested
    redirects: list[dict[str, Any]] = []
    visited = {url}
    all_addresses: list[str] = []
    request_count = 0
    previous_cache = source.get("httpCache") if isinstance(source.get("httpCache"), dict) else {}
    accept = (
        "application/rss+xml, application/atom+xml, application/feed+json, "
        "application/json, text/xml;q=0.9, */*;q=0.2"
        if source.get("type") == "rss" else
        "text/html, application/xhtml+xml;q=0.9, */*;q=0.1"
    )

    for _hop in range(MAX_REDIRECTS + 1):
        parsed = urllib.parse.urlsplit(url)
        scheme, host, port = _origin(url)
        addresses = resolve_public_addresses(host, port, resolver=resolver)
        for address in addresses:
            if address not in all_addresses:
                all_addresses.append(address)
        chosen = addresses[0]
        connection = (
            connection_factory(parsed, chosen, timeout)
            if connection_factory is not None else
            _open_connection(parsed, chosen, timeout)
        )
        headers = {
            "Accept": accept,
            "Accept-Encoding": "identity",
            "Cache-Control": "no-cache",
            "Connection": "close",
            "Host": _host_header(parsed),
            "Pragma": "no-cache",
            "User-Agent": f"ProgRSS/{VERSION} Node-Witness",
        }
        etag = _valid_etag(previous_cache.get("etag"))
        last_modified = _valid_http_date(previous_cache.get("lastModified"))
        if etag:
            headers["If-None-Match"] = etag
        if last_modified:
            headers["If-Modified-Since"] = last_modified
        try:
            request_count += 1
            connection.request("GET", _request_target(parsed), headers=headers)
            response = connection.getresponse()
            status = int(response.status)
            selected = _selected_headers(response)
            if status in _REDIRECT_STATUSES:
                location = selected.get("location", "")
                if not location:
                    raise AcquisitionError(
                        f"HTTP {status} redirect had no usable Location header",
                        code="redirect-without-location", outcome="temporary-failure", status=status,
                    )
                target = _safe_url(location, url)
                row = {"from": url, "to": target, "status": status}
                if _origin(target) != (scheme, host, port):
                    raise AcquisitionError(
                        f"This address moved from {host} to {urllib.parse.urlsplit(target).hostname or 'another site'}. ProgRSS stopped before contacting the new site.",
                        code="cross-origin-redirect", outcome="moved", status=status,
                        detail={"redirect": row, "redirects": [*redirects, row], "requestCount": request_count},
                    )
                if target in visited:
                    raise AcquisitionError(
                        "same-site redirect loop refused", code="redirect-loop", outcome="temporary-failure", status=status,
                        detail={"redirect": row, "redirects": [*redirects, row], "requestCount": request_count},
                    )
                if len(redirects) >= MAX_REDIRECTS:
                    raise AcquisitionError(
                        f"more than {MAX_REDIRECTS} same-site redirects refused",
                        code="too-many-redirects", outcome="temporary-failure", status=status,
                        detail={"redirect": row, "redirects": [*redirects, row], "requestCount": request_count},
                    )
                redirects.append(row)
                visited.add(target)
                url = target
                continue

            encoding = selected.get("contentEncoding", "").lower()
            if encoding and encoding != "identity":
                raise AcquisitionError(
                    f"compressed response encoding {encoding!r} is not accepted by the bounded Node fetcher",
                    code="content-encoding-refused", outcome="malformed", status=status,
                )
            body = b""
            if status == 200:
                declared = selected.get("contentLength", "")
                if declared:
                    try:
                        if int(declared) > max_bytes:
                            raise AcquisitionError(
                                f"response is larger than the {max_bytes:,}-byte limit",
                                code="body-too-large", outcome="malformed", status=status,
                            )
                    except ValueError:
                        pass
                body = response.read(max_bytes + 1)
                if len(body) > max_bytes:
                    raise AcquisitionError(
                        f"response is larger than the {max_bytes:,}-byte limit",
                        code="body-too-large", outcome="malformed", status=status,
                    )
            else:
                # Do not retain server-supplied error pages.  Drain only a tiny
                # amount so the connection can close cleanly.
                response.read(4_096)
            completed_clock = time.time() if now is None else started_clock + 0.001
            return FetchResult(
                requested_url=requested,
                final_url=url,
                status=status,
                body=body,
                headers=selected,
                redirects=tuple(redirects),
                resolved_addresses=tuple(all_addresses[:MAX_RESOLVED_ADDRESSES]),
                started_at=started_at,
                completed_at=_iso(completed_clock),
                duration_ms=max(0, int(round((completed_clock - started_clock) * 1_000))),
                request_count=request_count,
            )
        except AcquisitionError:
            raise
        except (socket.timeout, TimeoutError) as exc:
            raise AcquisitionError(
                "the site did not respond within the bounded timeout",
                code="timeout", outcome="temporary-failure",
                detail={"url": url, "requestCount": request_count},
            ) from exc
        except ssl.SSLError as exc:
            raise AcquisitionError(
                "TLS validation failed for this site",
                code="tls-failure", outcome="temporary-failure",
                detail={"url": url, "requestCount": request_count},
            ) from exc
        except (OSError, http.client.HTTPException) as exc:
            raise AcquisitionError(
                f"network request failed: {clean_text(exc, 240)}",
                code="network-failure", outcome="temporary-failure",
                detail={"url": url, "requestCount": request_count},
            ) from exc
        finally:
            try:
                connection.close()
            except Exception:
                pass
    raise AcquisitionError(
        f"more than {MAX_REDIRECTS} same-site redirects refused",
        code="too-many-redirects", outcome="temporary-failure",
    )


def _next_cache(headers: Mapping[str, Any], previous: Mapping[str, Any], status: int) -> dict[str, str]:
    keep_previous = status in {304, 429, 503}
    etag = _valid_etag(headers.get("etag")) or (_valid_etag(previous.get("etag")) if keep_previous else "")
    modified = _valid_http_date(headers.get("lastModified")) or (_valid_http_date(previous.get("lastModified")) if keep_previous else "")
    return {"etag": etag, "lastModified": modified}


def _source(state: Mapping[str, Any], source_id: str) -> dict[str, Any]:
    for row in state.get("sources", []):
        if isinstance(row, dict) and clean_text(row.get("id"), 300) == source_id:
            return row
    raise AcquisitionError("source is no longer present", code="source-not-found", outcome="refused")


def _stable_item_id(*parts: str) -> str:
    raw = "\0".join(parts).encode("utf-8")
    return "witness-" + hashlib.sha256(raw).hexdigest()[:28]


def _normalize_page_text(raw: Any, ignore_numbers: bool = False) -> str:
    value = re.sub(r"\s+", " ", str(raw or "")).strip()
    return re.sub(r"\d+(?:[.,]\d+)*", "#", value) if ignore_numbers else value


def _page_tokens(raw: Any, ignore_numbers: bool = False) -> tuple[str, list[dict[str, Any]]]:
    source = _normalize_page_text(raw, False)
    pattern = re.compile(r"\d+(?:[.,]\d+)*|[^\W_]+(?:['’\-][^\W_]+)*|[^\s]", re.UNICODE)
    rows: list[dict[str, Any]] = []
    for match in pattern.finditer(source):
        token = match.group(0)
        number = bool(re.fullmatch(r"\d+(?:[.,]\d+)*", token))
        rows.append({
            "raw": token,
            "value": "#" if ignore_numbers and number else token,
            "start": match.start(),
            "end": match.end(),
            "word": bool(re.match(r"[^\W_]", token, re.UNICODE)),
        })
    return source, rows


def _snippet(source: str, start: int, end: int, limit: int = 760) -> str:
    if not source:
        return ""
    left = max(0, start - 180)
    right = min(len(source), max(end, start) + 180)
    value = source[left:right].strip()
    if left:
        value = "…" + value
    if right < len(source):
        value += "…"
    return value[:limit]


def _quote(raw: str, limit: int = 150) -> str:
    value = clean_text(raw, limit)
    return f"“{value}”" if value else ""


def _change_summary(removed: str, added: str, removed_words: int, added_words: int) -> str:
    before = _quote(removed)
    after = _quote(added)
    if not removed and added:
        return f"Added {after}" if after else f"Added {added_words} word{'s' if added_words != 1 else ''}."
    if removed and not added:
        return f"Removed {before}" if before else f"Removed {removed_words} word{'s' if removed_words != 1 else ''}."
    if before and after and len(before) + len(after) <= 270:
        return f"Changed {before} to {after}"
    if not added_words and not removed_words:
        return "Punctuation or symbols changed."
    return f"{added_words} word{'s were' if added_words != 1 else ' was'} added and {removed_words} word{'s were' if removed_words != 1 else ' was'} removed."


def _diff_text(before: Any, after: Any, threshold: int = 1, ignore_numbers: bool = False) -> dict[str, Any]:
    left_source, left = _page_tokens(before, ignore_numbers)
    right_source, right = _page_tokens(after, ignore_numbers)
    if _normalize_page_text(before, ignore_numbers) == _normalize_page_text(after, ignore_numbers):
        return {"changed": False, "meaningful": False, "delta": 0, "added": "", "removed": "", "addedWords": 0, "removedWords": 0, "beforeSnippet": "", "afterSnippet": "", "summary": ""}
    front = 0
    while front < len(left) and front < len(right) and left[front]["value"] == right[front]["value"]:
        front += 1
    back = 0
    while back < len(left) - front and back < len(right) - front and left[-back - 1]["value"] == right[-back - 1]["value"]:
        back += 1
    left_last = len(left) - back - 1
    right_last = len(right) - back - 1
    left_start = int(left[front]["start"]) if front < len(left) else len(left_source)
    left_end = int(left[left_last]["end"]) if left_last >= front else left_start
    right_start = int(right[front]["start"]) if front < len(right) else len(right_source)
    right_end = int(right[right_last]["end"]) if right_last >= front else right_start
    removed = left_source[left_start:left_end].strip()
    added = right_source[right_start:right_end].strip()
    removed_words = sum(1 for row in left[front:len(left) - back] if row["word"])
    added_words = sum(1 for row in right[front:len(right) - back] if row["word"])
    delta = max(len(removed), len(added))
    minimum = max(0, int(threshold or 0))
    return {
        "changed": True,
        "meaningful": delta >= minimum,
        "delta": delta,
        "added": added[:1_000],
        "removed": removed[:1_000],
        "addedWords": added_words,
        "removedWords": removed_words,
        "beforeSnippet": _snippet(left_source, left_start, left_end),
        "afterSnippet": _snippet(right_source, right_start, right_end),
        "summary": _change_summary(removed, added, removed_words, added_words),
    }


def _common_change(source: Mapping[str, Any], kind: str, difference: Mapping[str, Any], before: str = "", after: str = "") -> dict[str, Any]:
    return {
        "schema": PAGE_CHANGE_SCHEMA,
        "kind": kind,
        "mode": "cards" if source.get("mode") == "cards" else "region",
        "summary": clean_text(difference.get("summary"), 500),
        "before": clean_text(before or difference.get("beforeSnippet"), 1_200),
        "after": clean_text(after or difference.get("afterSnippet"), 1_200),
        "removed": clean_text(difference.get("removed"), 1_000),
        "added": clean_text(difference.get("added"), 1_000),
        "removedWords": max(0, int(difference.get("removedWords") or 0)),
        "addedWords": max(0, int(difference.get("addedWords") or 0)),
        "delta": max(0, int(difference.get("delta") or 0)),
        "threshold": max(1, int(source.get("threshold") or 1)),
        "ignoreNumbers": bool(source.get("ignoreNumbers")),
    }


def _compare_cards(before: Iterable[Mapping[str, Any]], after: Iterable[Mapping[str, Any]], *, threshold: int, ignore_numbers: bool) -> dict[str, Any]:
    old = {str(row.get("key")): dict(row) for row in before if row.get("key")}
    new = {str(row.get("key")): dict(row) for row in after if row.get("key")}
    added: list[dict[str, Any]] = []
    removed: list[dict[str, Any]] = []
    changed: list[dict[str, Any]] = []
    for key, card in new.items():
        prior = old.get(key)
        if prior is None:
            added.append(card)
            continue
        difference = _diff_text(
            f"{prior.get('title', '')} {prior.get('summary', '')}",
            f"{card.get('title', '')} {card.get('summary', '')}",
            threshold,
            ignore_numbers,
        )
        if difference["meaningful"]:
            changed.append({"before": prior, "after": card, "difference": difference})
    for key, card in old.items():
        if key not in new:
            removed.append(card)
    return {"added": added, "removed": removed, "changed": changed, "unchanged": len(new) - len(added) - len(changed)}


def _ingest_page(state: dict[str, Any], source: dict[str, Any], capture: Mapping[str, Any], stamp: str) -> dict[str, Any]:
    state.setdefault("snapshots", {})
    snapshots = state["snapshots"]
    previous = snapshots.get(source["id"]) if isinstance(snapshots.get(source["id"]), dict) else None
    events: list[dict[str, Any]] = []
    threshold = max(1, int(source.get("threshold") or 1))
    ignore_numbers = bool(source.get("ignoreNumbers"))
    if capture.get("mode") == "cards":
        next_cards = [
            {"key": str(row.get("key") or ""), "title": clean_text(row.get("title"), 240), "summary": clean_text(row.get("summary"), 1_000), "url": clean_text(row.get("url"), 2_048)}
            for row in list(capture.get("cards") or [])[:200]
            if isinstance(row, Mapping) and row.get("key")
        ]
        has_history = bool(previous and isinstance(previous.get("entries"), list))
        old_cards = list(previous.get("entries") or []) if previous else []
        if previous and not has_history:
            old_cards = [{"key": key, "title": "", "summary": "", "url": ""} for key in list(previous.get("keys") or [])]
        delta = _compare_cards(old_cards, next_cards, threshold=threshold, ignore_numbers=ignore_numbers) if previous else {"added": [], "removed": [], "changed": [], "unchanged": 0}
        if previous and not has_history and delta["changed"]:
            delta["unchanged"] += len(delta["changed"])
            delta["changed"] = []
        for index, card in enumerate(delta["added"]):
            after = clean_text(f"{card.get('title', '')}. {card.get('summary', '')}", 1_200)
            change = _common_change(source, "entry-added", {
                "summary": "A new entry appeared in the watched list.", "afterSnippet": after,
                "added": after, "addedWords": sum(1 for row in _page_tokens(after)[1] if row["word"]), "delta": len(after),
            }, "", after)
            events.append({
                "id": _stable_item_id(source["id"], stamp, "added", str(card.get("key")), str(index)),
                "sourceId": source["id"], "title": clean_text(card.get("title"), 240) or "New page entry",
                "url": clean_text(card.get("url"), 2_048) or clean_text(source.get("url"), 2_048),
                "summary": clean_text(card.get("summary"), 1_200), "published": "", "observedAt": stamp,
                "kind": "new", "change": change,
            })
        for index, row in enumerate(delta["changed"]):
            before = clean_text(f"{row['before'].get('title', '')}. {row['before'].get('summary', '')}", 1_200)
            after = clean_text(f"{row['after'].get('title', '')}. {row['after'].get('summary', '')}", 1_200)
            change = _common_change(source, "entry-changed", row["difference"], before, after)
            events.append({
                "id": _stable_item_id(source["id"], stamp, "changed", str(row["after"].get("key")), str(index)),
                "sourceId": source["id"], "title": (clean_text(row["after"].get("title"), 220) or "Page entry") + " changed",
                "url": clean_text(row["after"].get("url"), 2_048) or clean_text(source.get("url"), 2_048),
                "summary": clean_text(row["difference"].get("summary"), 1_200) or "The wording in this watched entry changed.",
                "published": "", "observedAt": stamp, "kind": "changed", "change": change,
            })
        for index, card in enumerate(delta["removed"]):
            before = clean_text(f"{card.get('title', '')}. {card.get('summary', '')}", 1_200)
            change = _common_change(source, "entry-removed", {
                "summary": "An entry no longer appeared in the watched list.", "beforeSnippet": before,
                "removed": before, "removedWords": sum(1 for row in _page_tokens(before)[1] if row["word"]), "delta": len(before),
            }, before, "")
            events.append({
                "id": _stable_item_id(source["id"], stamp, "removed", str(card.get("key")), str(index)),
                "sourceId": source["id"], "title": (clean_text(card.get("title"), 220) or "Page entry") + " removed",
                "url": clean_text(card.get("url"), 2_048) or clean_text(source.get("url"), 2_048),
                "summary": "This entry no longer appeared in the watched list.", "published": "", "observedAt": stamp,
                "kind": "removed", "change": change,
            })
        snapshots[source["id"]] = {"mode": "cards", "keys": [row["key"] for row in next_cards], "entries": next_cards, "capturedAt": stamp}
        existing = {str(row.get("id")) for row in state.get("items", []) if isinstance(row, dict)}
        state["items"] = ([row for row in reversed(events) if row["id"] not in existing] + list(state.get("items", [])))[:MAX_ITEMS]
        return {"added": len(events), "baseline": previous is None, "delta": {"added": len(delta["added"]), "changed": len(delta["changed"]), "removed": len(delta["removed"]), "unchanged": int(delta["unchanged"])}}

    content = body_text(capture.get("content"), 120_000)
    difference = _diff_text(previous.get("text", "") if previous else "", content, threshold, ignore_numbers)
    if previous and difference["meaningful"]:
        event = {
            "id": _stable_item_id(source["id"], stamp, "text-changed", difference.get("summary", "")),
            "sourceId": source["id"], "title": (clean_text(source.get("title"), 220) or "Watched page") + " changed",
            "url": clean_text(source.get("url"), 2_048),
            "summary": clean_text(difference.get("summary"), 1_200) or "The watched main text changed.",
            "published": "", "observedAt": stamp, "kind": "changed",
            "change": _common_change(source, "text-changed", difference),
        }
        existing = {str(row.get("id")) for row in state.get("items", []) if isinstance(row, dict)}
        if event["id"] not in existing:
            state["items"] = [event, *list(state.get("items", []))][:MAX_ITEMS]
    snapshots[source["id"]] = {"mode": "region", "text": content, "capturedAt": stamp}
    return {"added": 1 if previous and difference["meaningful"] else 0, "baseline": previous is None, "delta": difference}


def _problem(source: dict[str, Any], message: str, outcome: str, stamp: str, status: int = 0) -> None:
    source["lastScan"] = stamp
    source["lastOutcome"] = outcome
    source["lastError"] = clean_text(message, 300)
    source["lastProblemAt"] = stamp
    source["lastProblem"] = source["lastError"]
    source["lastItems"] = 0
    source["lastHttpStatus"] = max(0, int(status or 0))
    source["checkCount"] = max(0, int(source.get("checkCount") or 0)) + 1


def _success_base(source: dict[str, Any], result: FetchResult, stamp: str) -> None:
    source["lastScan"] = stamp
    source["lastHttpStatus"] = result.status
    source["checkCount"] = max(0, int(source.get("checkCount") or 0)) + 1
    source["lastResolvedUrl"] = result.final_url
    source["lastRedirects"] = [copy.deepcopy(row) for row in result.redirects]
    source.pop("permissionMissing", None)
    source.pop("permissionMissingReason", None)


def apply_failure(
    document: Mapping[str, Any],
    source_id: str,
    error: AcquisitionError,
    *,
    stamp: str,
    enable: bool,
) -> AcquisitionApplication:
    result = copy.deepcopy(dict(document))
    state = result["state"]
    source = _source(state, source_id)
    if enable:
        source["enabled"] = True
    _problem(source, str(error), error.outcome, stamp, error.status)
    if error.code == "cross-origin-redirect":
        redirect = error.detail.get("redirect") if isinstance(error.detail, dict) else None
        if isinstance(redirect, dict):
            source["pendingRedirect"] = {
                "from": clean_text(redirect.get("from"), 2_048),
                "to": clean_text(redirect.get("to"), 2_048),
                "status": int(redirect.get("status") or 0),
                "observedAt": stamp,
            }
    result["exportedAt"] = stamp
    return AcquisitionApplication(
        document=result,
        outcome=error.outcome,
        summary={"itemsAdded": 0, "baseline": False, "enabledNow": bool(enable), "message": str(error)},
        evidence={"code": error.code, "status": error.status, "detail": copy.deepcopy(error.detail)},
    )


def apply_fetch(
    document: Mapping[str, Any],
    source_id: str,
    fetched: FetchResult,
    *,
    stamp: str,
    enable: bool,
) -> AcquisitionApplication:
    result = copy.deepcopy(dict(document))
    state = result["state"]
    source = _source(state, source_id)
    if enable:
        source["enabled"] = True
    prior_cache = source.get("httpCache") if isinstance(source.get("httpCache"), dict) else {}
    next_cache = _next_cache(fetched.headers, prior_cache, fetched.status)
    _success_base(source, fetched, stamp)

    if fetched.status == 304:
        source["httpCache"] = next_cache
        source["lastItems"] = 0
        source["lastOutcome"] = "unchanged"
        source["lastError"] = ""
        source["lastSuccessfulAt"] = stamp
        source.pop("pendingRedirect", None)
        if source.get("type") == "page" and source.get("watchStability"):
            source.pop("watchStability", None)
            source["watchHealth"] = {
                "schema": PAGE_WATCH_HEALTH_SCHEMA, "status": "steady", "reason": "returned-to-steady",
                "checkedAt": stamp,
                "message": "The page returned to its usual shape. The held result was discarded without creating an alert.",
                "metrics": {},
            }
        result["exportedAt"] = stamp
        return AcquisitionApplication(result, "unchanged", {"itemsAdded": 0, "baseline": False, "enabledNow": bool(enable), "notModified": True}, {"httpStatus": 304})

    if fetched.status in {429, 503}:
        source["httpCache"] = next_cache
        _problem(source, f"The site asked ProgRSS to slow down (HTTP {fetched.status}).", "throttled", stamp, fetched.status)
        result["exportedAt"] = stamp
        return AcquisitionApplication(result, "throttled", {"itemsAdded": 0, "baseline": False, "enabledNow": bool(enable), "retryAfter": fetched.headers.get("retryAfter", "")}, {"httpStatus": fetched.status})

    if fetched.status != 200:
        outcome = "temporary-failure" if fetched.status in _TEMPORARY_STATUSES or fetched.status >= 500 else "permanent-failure"
        if fetched.status not in _PERMANENT_STATUSES and fetched.status < 500:
            outcome = "temporary-failure"
        _problem(source, f"HTTP {fetched.status} from the selected source.", outcome, stamp, fetched.status)
        result["exportedAt"] = stamp
        return AcquisitionApplication(result, outcome, {"itemsAdded": 0, "baseline": False, "enabledNow": bool(enable), "message": source["lastError"]}, {"httpStatus": fetched.status})

    try:
        if source.get("type") == "rss":
            parsed = parse_feed(fetched.body, fetched.final_url)
            declared = same_origin_feed_url(parsed.get("feedUrl"), fetched.final_url)
            if declared:
                source["declaredFeedUrl"] = declared
            source_language = language_tag(parsed.get("language"))
            title_language = language_tag(parsed.get("titleLanguage")) or source_language
            if source_language:
                source["language"] = source_language
            else:
                source.pop("language", None)
            if title_language:
                source["titleLanguage"] = title_language
            else:
                source.pop("titleLanguage", None)
            added = ingest_feed(state, source, parsed, observed_at=stamp)
            if (not clean_text(source.get("title"), 180) or source.get("title") == "New feed") and parsed.get("title"):
                source["title"] = clean_text(parsed.get("title"), 180)
            source["httpCache"] = next_cache
            source["lastItems"] = added
            source["lastOutcome"] = "changed" if added else "unchanged"
            source["lastError"] = ""
            source["lastSuccessfulAt"] = stamp
            if added:
                source["lastNewAt"] = stamp
            source.pop("pendingRedirect", None)
            result["exportedAt"] = stamp
            return AcquisitionApplication(
                result, source["lastOutcome"],
                {"itemsAdded": added, "baseline": False, "enabledNow": bool(enable), "feedType": parsed.get("type", ""), "feedTitle": clean_text(parsed.get("title"), 180)},
                {"httpStatus": 200, "responseSha256": hashlib.sha256(fetched.body).hexdigest(), "responseBytes": len(fetched.body)},
            )

        effective = {**source, "url": fetched.final_url}
        capture = _watch_capture(_parse_watch_html(fetched.body), effective, {
            "mode": "cards" if source.get("mode") == "cards" else "region",
            "selector": clean_text(source.get("selector"), 350),
            "titleSelector": clean_text(source.get("titleSelector"), 200),
            "linkSelector": clean_text(source.get("linkSelector"), 200),
        })
        previous = state.get("snapshots", {}).get(source_id) if isinstance(state.get("snapshots"), dict) else None
        health = page_watch_capture_health(previous if isinstance(previous, dict) else None, capture, checked_at=stamp)
        if health.get("status") == "attention":
            _problem(source, clean_text(health.get("message"), 300), "needs-repair", stamp, 200)
            source["watchHealth"] = health
            source["httpCache"] = prior_cache
            result["exportedAt"] = stamp
            return AcquisitionApplication(result, "needs-repair", {"itemsAdded": 0, "baseline": False, "enabledNow": bool(enable), "message": health.get("message", "")}, {"httpStatus": 200, "health": health})
        decision = page_watch_stability_decision(source.get("watchStability") if isinstance(source.get("watchStability"), dict) else None, health, source)
        if decision.get("action") == "repair":
            _problem(source, clean_text(decision.get("health", {}).get("message"), 300), "needs-repair", stamp, 200)
            source["watchHealth"] = decision.get("health")
            source.pop("watchStability", None)
            source["httpCache"] = prior_cache
            result["exportedAt"] = stamp
            return AcquisitionApplication(result, "needs-repair", {"itemsAdded": 0, "baseline": False, "enabledNow": bool(enable), "message": source["lastError"]}, {"httpStatus": 200, "health": source.get("watchHealth")})
        if decision.get("action") == "hold":
            source["watchStability"] = copy.deepcopy(decision.get("stability"))
            source["watchHealth"] = copy.deepcopy(decision.get("health"))
            source["httpCache"] = prior_cache
            source["lastItems"] = 0
            source["lastOutcome"] = "watch-pending"
            source["lastError"] = ""
            source["lastSuccessfulAt"] = stamp
            source.pop("pendingRedirect", None)
            result["exportedAt"] = stamp
            return AcquisitionApplication(result, "watch-pending", {"itemsAdded": 0, "baseline": False, "enabledNow": bool(enable), "message": source["watchHealth"].get("message", "")}, {"httpStatus": 200, "health": source["watchHealth"]})
        page_result = _ingest_page(state, source, capture, stamp)
        source["watchHealth"] = copy.deepcopy(decision.get("health"))
        source.pop("watchStability", None)
        source.pop("watchRepair", None)
        source["httpCache"] = next_cache
        source["lastItems"] = int(page_result.get("added") or 0)
        source["lastOutcome"] = "baseline" if page_result.get("baseline") else ("changed" if page_result.get("added") else "unchanged")
        source["lastError"] = ""
        source["lastSuccessfulAt"] = stamp
        if page_result.get("added"):
            source["lastNewAt"] = stamp
        source.pop("pendingRedirect", None)
        result["exportedAt"] = stamp
        return AcquisitionApplication(
            result, source["lastOutcome"],
            {"itemsAdded": int(page_result.get("added") or 0), "baseline": bool(page_result.get("baseline")), "enabledNow": bool(enable), "mode": capture.get("mode"), "matchCount": int(capture.get("matchCount") or 0)},
            {"httpStatus": 200, "responseSha256": hashlib.sha256(fetched.body).hexdigest(), "responseBytes": len(fetched.body), "health": source.get("watchHealth")},
        )
    except ProgRSSError as exc:
        _problem(source, str(exc), "malformed", stamp, fetched.status)
        source["httpCache"] = prior_cache
        result["exportedAt"] = stamp
        return AcquisitionApplication(
            result, "malformed",
            {"itemsAdded": 0, "baseline": False, "enabledNow": bool(enable), "message": str(exc)},
            {"httpStatus": fetched.status, "responseSha256": hashlib.sha256(fetched.body).hexdigest(), "responseBytes": len(fetched.body)},
        )



def _canonical_url_without_fragment(raw: Any) -> str:
    value = _safe_url(raw)
    parsed = urllib.parse.urlsplit(value)
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path or "/", parsed.query, ""))


def _bounded_recipe_threshold(value: Any) -> int:
    try:
        number = int(value if value is not None else 1)
    except (TypeError, ValueError, OverflowError):
        number = 1
    return max(1, min(100_000, number))


def page_recipe(source: Mapping[str, Any]) -> dict[str, Any]:
    """Return the bounded declarative recipe used by Node and Extension capture."""
    return {
        "mode": "cards" if source.get("mode") == "cards" else "region",
        "selector": clean_text(source.get("selector"), 350),
        "titleSelector": clean_text(source.get("titleSelector"), 200),
        "linkSelector": clean_text(source.get("linkSelector"), 200),
        "threshold": _bounded_recipe_threshold(source.get("threshold")),
        "ignoreNumbers": bool(source.get("ignoreNumbers")),
    }


def page_recipe_digest(recipe: Mapping[str, Any]) -> str:
    material = {
        "mode": "cards" if recipe.get("mode") == "cards" else "region",
        "selector": clean_text(recipe.get("selector"), 350),
        "titleSelector": clean_text(recipe.get("titleSelector"), 200),
        "linkSelector": clean_text(recipe.get("linkSelector"), 200),
        "threshold": _bounded_recipe_threshold(recipe.get("threshold")),
        "ignoreNumbers": bool(recipe.get("ignoreNumbers")),
    }
    return hashlib.sha256(json.dumps(material, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def acquisition_source_identity(source: Mapping[str, Any]) -> tuple[str, dict[str, Any]]:
    """Return the acquisition identity used by Witness and Pulse.

    Human wording, read state, validators, schedules, and retained items are
    deliberately excluded.  A feed address or declarative page-watch recipe
    change produces a different identity and requires a new manual Witness check
    before scheduling.
    """
    source_type = str(source.get("type") or "")
    if source_type not in {"rss", "page"}:
        raise AcquisitionError(
            "only feed and declarative page-watch sources have an acquisition identity",
            code="unsupported-source", outcome="refused",
        )
    material: dict[str, Any] = {
        "schema": "progrss.acquisition-source-identity.v1",
        "sourceId": clean_text(source.get("id"), 300),
        "type": source_type,
        "url": _canonical_url_without_fragment(source.get("url")),
    }
    if source_type == "page":
        material["recipe"] = page_recipe(source)
    digest = hashlib.sha256(
        json.dumps(material, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return digest, material


def _strict_keys(value: Mapping[str, Any], allowed: set[str], label: str) -> None:
    extras = set(value) - allowed
    if extras:
        raise AcquisitionError(
            f"{label} contains unsupported fields: {', '.join(sorted(extras)[:5])}",
            code="invalid-browser-capture", outcome="refused",
        )


def _capture_text(value: Any, label: str, limit: int, *, multiline: bool = False) -> str:
    if not isinstance(value, str):
        raise AcquisitionError(f"{label} must be text", code="invalid-browser-capture", outcome="refused")
    return body_text(value, limit) if multiline else clean_text(value, limit)


def _capture_integer(value: Any, label: str, minimum: int, maximum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise AcquisitionError(f"{label} must be an integer", code="invalid-browser-capture", outcome="refused")
    if value < minimum or value > maximum:
        raise AcquisitionError(f"{label} is outside the supported range", code="invalid-browser-capture", outcome="refused")
    return value


def _capture_string_list(value: Any, label: str, *, maximum: int = 4, limit: int = 180) -> list[str]:
    if not isinstance(value, list) or len(value) > maximum or any(not isinstance(row, str) for row in value):
        raise AcquisitionError(f"{label} must be at most {maximum} text values", code="invalid-browser-capture", outcome="refused")
    return [row for row in (_capture_text(row, label, limit, multiline=True) for row in value) if row]


def _capture_bool(value: Any, label: str) -> bool:
    if not isinstance(value, bool):
        raise AcquisitionError(f"{label} must be true or false", code="invalid-browser-capture", outcome="refused")
    return value


def _capture_assessment(value: Any) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise AcquisitionError("capture section assessment must be one object", code="invalid-browser-capture", outcome="refused")
    _strict_keys(value, {"schema", "level", "summary", "reasons", "warnings", "signals"}, "capture section assessment")
    if value.get("schema") != BROWSER_CAPTURE_ASSESSMENT_SCHEMA:
        raise AcquisitionError(f"expected {BROWSER_CAPTURE_ASSESSMENT_SCHEMA}", code="invalid-browser-capture", outcome="refused")
    level = _capture_text(value.get("level"), "capture assessment level", 24)
    if level not in {"steadier", "watchful", "fragile"}:
        raise AcquisitionError("capture assessment has an unsupported level", code="invalid-browser-capture", outcome="refused")
    summary = _capture_text(value.get("summary"), "capture assessment summary", 220, multiline=True)
    reasons = _capture_string_list(value.get("reasons"), "capture assessment reasons")
    warnings = _capture_string_list(value.get("warnings"), "capture assessment warnings")
    signals = value.get("signals")
    if not isinstance(signals, Mapping):
        raise AcquisitionError("capture assessment signals must be one object", code="invalid-browser-capture", outcome="refused")
    _strict_keys(
        signals,
        {
            "selectorKind", "semanticBoundary", "uniqueMatch", "visibleMatches", "hiddenMatches",
            "repeatedEntries", "linkedEntries", "titledEntries", "consistentEntries",
            "clutterElements", "textCharacters",
        },
        "capture assessment signals",
    )
    selector_kind = _capture_text(signals.get("selectorKind"), "capture selector kind", 24)
    if selector_kind not in {"semantic", "named", "generic"}:
        raise AcquisitionError("capture selector kind is unsupported", code="invalid-browser-capture", outcome="refused")
    normalized_signals = {
        "selectorKind": selector_kind,
        "semanticBoundary": _capture_bool(signals.get("semanticBoundary"), "capture semanticBoundary"),
        "uniqueMatch": _capture_bool(signals.get("uniqueMatch"), "capture uniqueMatch"),
        "visibleMatches": _capture_integer(signals.get("visibleMatches"), "capture visible match count", 0, 100_000),
        "hiddenMatches": _capture_integer(signals.get("hiddenMatches"), "capture hidden match count", 0, 100_000),
        "repeatedEntries": _capture_integer(signals.get("repeatedEntries"), "capture repeated-entry count", 0, 200),
        "linkedEntries": _capture_integer(signals.get("linkedEntries"), "capture linked-entry count", 0, 200),
        "titledEntries": _capture_integer(signals.get("titledEntries"), "capture titled-entry count", 0, 200),
        "consistentEntries": _capture_integer(signals.get("consistentEntries"), "capture consistent-entry count", 0, 200),
        "clutterElements": _capture_integer(signals.get("clutterElements"), "capture clutter count", 0, 999),
        "textCharacters": _capture_integer(signals.get("textCharacters"), "capture text-character count", 0, MAX_BROWSER_CAPTURE_TEXT),
    }
    repeated = normalized_signals["repeatedEntries"]
    for key in ("linkedEntries", "titledEntries", "consistentEntries"):
        if normalized_signals[key] > repeated:
            raise AcquisitionError(f"capture {key} exceeds its repeated-entry count", code="invalid-browser-capture", outcome="refused")
    return {
        "schema": BROWSER_CAPTURE_ASSESSMENT_SCHEMA,
        "level": level,
        "summary": summary,
        "reasons": reasons,
        "warnings": warnings,
        "signals": normalized_signals,
    }


def _capture_page_context(value: Any) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise AcquisitionError("capture page context must be one object", code="invalid-browser-capture", outcome="refused")
    _strict_keys(value, {"schema", "notices", "signals"}, "capture page context")
    if value.get("schema") != BROWSER_CAPTURE_CONTEXT_SCHEMA:
        raise AcquisitionError(f"expected {BROWSER_CAPTURE_CONTEXT_SCHEMA}", code="invalid-browser-capture", outcome="refused")
    notices_raw = value.get("notices")
    if not isinstance(notices_raw, list) or len(notices_raw) > 6:
        raise AcquisitionError("capture page context must contain at most six notices", code="invalid-browser-capture", outcome="refused")
    allowed_tones = {
        "continuation": "boundary", "partial-render": "caution", "overlay": "caution",
        "loading": "caution", "frames": "boundary", "open-shadow": "included",
    }
    notices: list[dict[str, str]] = []
    seen_kinds: set[str] = set()
    for index, row in enumerate(notices_raw):
        if not isinstance(row, Mapping):
            raise AcquisitionError("capture page-context notice must be one object", code="invalid-browser-capture", outcome="refused")
        _strict_keys(row, {"kind", "tone", "summary"}, f"capture page-context notice {index + 1}")
        kind = _capture_text(row.get("kind"), "capture page-context kind", 32)
        tone = _capture_text(row.get("tone"), "capture page-context tone", 20)
        summary = _capture_text(row.get("summary"), "capture page-context summary", 180, multiline=True)
        if kind not in allowed_tones or tone != allowed_tones[kind] or not summary or kind in seen_kinds:
            raise AcquisitionError("capture page-context notice is unsupported or duplicated", code="invalid-browser-capture", outcome="refused")
        seen_kinds.add(kind)
        notices.append({"kind": kind, "tone": tone, "summary": summary})

    signals_raw = value.get("signals")
    if not isinstance(signals_raw, Mapping):
        raise AcquisitionError("capture page-context signals must be one object", code="invalid-browser-capture", outcome="refused")
    signal_keys = {
        "continuationLinks", "paginationLandmarks", "continuationControls", "partialSetSignals",
        "virtualMarkers", "scrollWindows", "modalLayers", "embeddedFrames", "openShadowRoots", "busyRegions",
    }
    _strict_keys(signals_raw, signal_keys, "capture page-context signals")
    signals = {
        key: _capture_integer(signals_raw.get(key), f"capture {key}", 0, 32 if key == "openShadowRoots" else 1_000)
        for key in sorted(signal_keys)
    }
    required = {
        "continuation": signals["continuationLinks"] + signals["paginationLandmarks"] + signals["continuationControls"] > 0,
        "partial-render": signals["partialSetSignals"] + signals["virtualMarkers"] + signals["scrollWindows"] > 0,
        "overlay": signals["modalLayers"] > 0,
        "loading": signals["busyRegions"] > 0,
        "frames": signals["embeddedFrames"] > 0,
        "open-shadow": signals["openShadowRoots"] > 0,
    }
    for kind, present in required.items():
        if present != (kind in seen_kinds):
            raise AcquisitionError("capture page-context notices do not match their bounded signals", code="invalid-browser-capture", outcome="refused")
    return {"schema": BROWSER_CAPTURE_CONTEXT_SCHEMA, "notices": notices, "signals": signals}


def _capture_coverage_review(value: Any, context: Mapping[str, Any]) -> dict[str, Any]:
    """Validate the exact human decision about visible page-coverage limits."""
    if not isinstance(value, Mapping):
        raise AcquisitionError("capture coverage review must be one object", code="invalid-browser-capture", outcome="refused")
    _strict_keys(value, {"schema", "decision", "acknowledgedNoticeKinds"}, "capture coverage review")
    if value.get("schema") != BROWSER_CAPTURE_COVERAGE_SCHEMA:
        raise AcquisitionError(f"expected {BROWSER_CAPTURE_COVERAGE_SCHEMA}", code="invalid-browser-capture", outcome="refused")
    decision = _capture_text(value.get("decision"), "capture coverage decision", 80)
    raw_kinds = value.get("acknowledgedNoticeKinds")
    if not isinstance(raw_kinds, list) or len(raw_kinds) > 5 or any(not isinstance(row, str) for row in raw_kinds):
        raise AcquisitionError("capture coverage review has invalid acknowledged notice kinds", code="invalid-browser-capture", outcome="refused")
    kinds = [_capture_text(row, "capture acknowledged boundary kind", 32) for row in raw_kinds]
    if len(set(kinds)) != len(kinds):
        raise AcquisitionError("capture coverage review duplicates a notice kind", code="invalid-browser-capture", outcome="refused")
    limiting = {"continuation", "partial-render", "overlay", "loading", "frames"}
    notices = context.get("notices") if isinstance(context.get("notices"), list) else []
    expected = [str(row.get("kind") or "") for row in notices if isinstance(row, Mapping) and row.get("kind") in limiting]
    if expected:
        if decision != "use-current-rendering" or kinds != expected:
            raise AcquisitionError(
                "capture coverage review must acknowledge every visible limiting boundary",
                code="capture-coverage-unreviewed", outcome="refused",
            )
    elif decision != "no-limiting-boundary-observed" or kinds:
        raise AcquisitionError(
            "capture coverage review claims limits that were not present",
            code="invalid-browser-capture", outcome="refused",
        )
    return {
        "schema": BROWSER_CAPTURE_COVERAGE_SCHEMA,
        "decision": decision,
        "acknowledgedNoticeKinds": kinds,
    }


def validate_browser_capture(
    artifact: Mapping[str, Any],
    *,
    source_id: str,
    source_url: str,
    now: float | None = None,
) -> dict[str, Any]:
    """Validate and normalize one bounded JSON-safe rendered-DOM artifact.

    Version 4 adds one exact human coverage decision when the rendered page
    exposes limiting boundaries. Version 3 retains bounded page-context evidence,
    Version 2 retains the bounded section assessment, and Version 1 remains
    accepted for a rolling Node/Extension upgrade. None of these observations or
    decisions becomes source identity or scheduling authority.
    """
    if not isinstance(artifact, Mapping):
        raise AcquisitionError("browser capture must be one JSON object", code="invalid-browser-capture", outcome="refused")
    schema = artifact.get("schema")
    supported_schemas = {
        BROWSER_CAPTURE_SCHEMA, BROWSER_CAPTURE_PREVIOUS_SCHEMA,
        BROWSER_CAPTURE_CONTOUR_SCHEMA, BROWSER_CAPTURE_LEGACY_SCHEMA,
    }
    if schema not in supported_schemas:
        raise AcquisitionError(
            f"expected one supported ProgRSS browser-capture schema; current is {BROWSER_CAPTURE_SCHEMA}",
            code="invalid-browser-capture", outcome="refused",
        )
    modern = schema != BROWSER_CAPTURE_LEGACY_SCHEMA
    contextual = schema in {BROWSER_CAPTURE_SCHEMA, BROWSER_CAPTURE_PREVIOUS_SCHEMA}
    coverage_reviewed = schema == BROWSER_CAPTURE_SCHEMA
    allowed_top = {"schema", "capturedAt", "page", "source", "recipe", "capture", "examples", "provenance"}
    if modern:
        allowed_top.add("selection")
    if contextual:
        allowed_top.add("context")
    if coverage_reviewed:
        allowed_top.add("coverage")
    _strict_keys(artifact, allowed_top, "browser capture")

    captured_at = _capture_text(artifact.get("capturedAt"), "capture time", 80)
    try:
        instant = datetime.fromisoformat(captured_at.replace("Z", "+00:00"))
        if instant.tzinfo is None:
            raise ValueError
        captured_epoch = instant.timestamp()
    except (TypeError, ValueError, OverflowError) as exc:
        raise AcquisitionError("browser capture has an invalid capture time", code="invalid-browser-capture", outcome="refused") from exc
    current = time.time() if now is None else float(now)
    if captured_epoch < current - 15 * 60 or captured_epoch > current + 2 * 60:
        raise AcquisitionError("browser capture is stale or has an unexpected future time", code="stale-browser-capture", outcome="refused")

    page = artifact.get("page")
    source = artifact.get("source")
    recipe_raw = artifact.get("recipe")
    capture_raw = artifact.get("capture")
    examples_raw = artifact.get("examples")
    provenance = artifact.get("provenance")
    context_raw = artifact.get("context") if contextual else None
    coverage_raw = artifact.get("coverage") if coverage_reviewed else None
    if not all(isinstance(value, Mapping) for value in (page, source, recipe_raw, capture_raw, examples_raw, provenance)):
        raise AcquisitionError("browser capture is missing a required object", code="invalid-browser-capture", outcome="refused")
    _strict_keys(page, {"url", "title", "language", *( {"direction"} if modern else set())}, "capture page")
    _strict_keys(source, {"id", "url"}, "capture source")
    _strict_keys(recipe_raw, {"mode", "selector", "titleSelector", "linkSelector", "threshold", "ignoreNumbers"}, "capture recipe")
    _strict_keys(capture_raw, {"mode", "matchCount", "content", "cards"}, "capture result")
    _strict_keys(examples_raw, {"matched", "ignored"}, "capture examples")
    provenance_keys = {"kind", "topFrameOnly", "isolatedWorld", "arbitrarySharedCode", "extensionVersion"}
    if modern:
        provenance_keys.add("extractorRevision")
    _strict_keys(provenance, provenance_keys, "capture provenance")

    page_url = _canonical_url_without_fragment(_capture_text(page.get("url"), "capture page URL", 2_048))
    page_title = _capture_text(page.get("title"), "capture page title", 300)
    page_language = _capture_text(page.get("language"), "capture page language", 100)
    page_direction = _capture_text(page.get("direction"), "capture page direction", 10) if modern else ""
    if page_direction not in {"", "ltr", "rtl", "auto"}:
        raise AcquisitionError("capture page direction is unsupported", code="invalid-browser-capture", outcome="refused")
    expected_url = _canonical_url_without_fragment(source_url)
    artifact_source_url = _canonical_url_without_fragment(_capture_text(source.get("url"), "capture source URL", 2_048))
    artifact_source_id = _capture_text(source.get("id"), "capture source ID", 300)
    if page_url != expected_url or artifact_source_url != expected_url:
        raise AcquisitionError("browser capture does not match the reviewed watched-page address", code="capture-page-mismatch", outcome="refused")
    if artifact_source_id != source_id:
        raise AcquisitionError("browser capture belongs to another source", code="capture-source-mismatch", outcome="refused")

    recipe_mode = _capture_text(recipe_raw.get("mode"), "capture recipe mode", 20)
    if recipe_mode not in {"cards", "region"}:
        raise AcquisitionError("browser capture recipe has an unsupported mode", code="invalid-browser-capture", outcome="refused")
    if not isinstance(recipe_raw.get("ignoreNumbers"), bool):
        raise AcquisitionError("capture recipe ignoreNumbers must be true or false", code="invalid-browser-capture", outcome="refused")
    recipe = {
        "mode": recipe_mode,
        "selector": _capture_text(recipe_raw.get("selector"), "capture recipe selector", 350),
        "titleSelector": _capture_text(recipe_raw.get("titleSelector"), "capture title selector", 200),
        "linkSelector": _capture_text(recipe_raw.get("linkSelector"), "capture link selector", 200),
        "threshold": _capture_integer(recipe_raw.get("threshold"), "capture recipe threshold", 1, 100_000),
        "ignoreNumbers": recipe_raw.get("ignoreNumbers"),
    }
    mode = recipe["mode"]
    capture_mode = _capture_text(capture_raw.get("mode"), "capture result mode", 20)
    if capture_mode != mode:
        raise AcquisitionError("browser capture mode does not match its reviewed recipe", code="invalid-browser-capture", outcome="refused")
    match_count = _capture_integer(capture_raw.get("matchCount"), "capture match count", 0, 100_000)
    if not isinstance(capture_raw.get("content"), str) or not isinstance(capture_raw.get("cards"), list):
        raise AcquisitionError("capture result must contain text and a card list", code="invalid-browser-capture", outcome="refused")
    capture: dict[str, Any] = {"mode": mode, "matchCount": match_count}
    if mode == "cards":
        cards_raw = capture_raw.get("cards")
        if not isinstance(cards_raw, list) or len(cards_raw) > MAX_BROWSER_CAPTURE_CARDS:
            raise AcquisitionError("browser capture contains too many repeated entries", code="capture-too-large", outcome="refused")
        cards: list[dict[str, Any]] = []
        for index, row in enumerate(cards_raw):
            if not isinstance(row, Mapping):
                raise AcquisitionError("browser capture contains a malformed repeated entry", code="invalid-browser-capture", outcome="refused")
            _strict_keys(row, {"key", "title", "url", "summary"}, f"capture card {index + 1}")
            title = _capture_text(row.get("title"), f"capture card {index + 1} title", 300)
            summary = _capture_text(row.get("summary"), f"capture card {index + 1} summary", 1_200, multiline=True)
            card_url_raw = _capture_text(row.get("url"), f"capture card {index + 1} URL", 2_048)
            card_url = _safe_url(card_url_raw, expected_url) if card_url_raw else ""
            key = _capture_text(row.get("key"), f"capture card {index + 1} key", 600) or card_url or f"card-{index + 1}-{hashlib.sha256((title + chr(0) + summary).encode('utf-8')).hexdigest()[:20]}"
            cards.append({"key": key, "title": title, "url": card_url, "summary": summary})
        capture["cards"] = cards
        capture["content"] = ""
    else:
        content = _capture_text(capture_raw.get("content"), "capture region text", MAX_BROWSER_CAPTURE_TEXT, multiline=True)
        if not content:
            raise AcquisitionError("the selected rendered page region contained no readable text", code="empty-browser-capture", outcome="malformed")
        capture["content"] = content
        capture["cards"] = []

    matched_raw = examples_raw.get("matched")
    ignored_raw = examples_raw.get("ignored")
    if not isinstance(matched_raw, list) or len(matched_raw) > 3 or any(not isinstance(row, str) for row in matched_raw):
        raise AcquisitionError("capture matched examples must be at most three text values", code="invalid-browser-capture", outcome="refused")
    matched = [_capture_text(row, "capture matched example", 500, multiline=True) for row in matched_raw]
    matched = [row for row in matched if row]
    ignored = _capture_text(ignored_raw, "capture ignored example", 500, multiline=True)

    selection: dict[str, Any] | None = None
    if modern:
        selection_raw = artifact.get("selection")
        if not isinstance(selection_raw, Mapping):
            raise AcquisitionError("browser capture is missing reviewed section evidence", code="invalid-browser-capture", outcome="refused")
        _strict_keys(selection_raw, {"schema", "candidateId", "assessment"}, "capture selection")
        if selection_raw.get("schema") != BROWSER_CAPTURE_SELECTION_SCHEMA:
            raise AcquisitionError(f"expected {BROWSER_CAPTURE_SELECTION_SCHEMA}", code="invalid-browser-capture", outcome="refused")
        candidate_id = _capture_text(selection_raw.get("candidateId"), "capture candidate ID", 40)
        if not candidate_id:
            raise AcquisitionError("capture candidate ID is required", code="invalid-browser-capture", outcome="refused")
        selection = {
            "schema": BROWSER_CAPTURE_SELECTION_SCHEMA,
            "candidateId": candidate_id,
            "assessment": _capture_assessment(selection_raw.get("assessment")),
        }

    if provenance.get("kind") != "rendered-browser-dom" or provenance.get("topFrameOnly") is not True or provenance.get("isolatedWorld") is not True or provenance.get("arbitrarySharedCode") is not False:
        raise AcquisitionError("browser capture provenance is not the fixed isolated top-frame boundary", code="invalid-browser-capture", outcome="refused")
    extension_version = _capture_text(provenance.get("extensionVersion"), "capture Extension version", 40)
    if not extension_version:
        raise AcquisitionError("browser capture did not identify its Extension version", code="invalid-browser-capture", outcome="refused")
    extractor_revision = _capture_text(provenance.get("extractorRevision"), "capture extractor revision", 60) if modern else ""
    if modern and not extractor_revision:
        raise AcquisitionError("browser capture did not identify its extractor revision", code="invalid-browser-capture", outcome="refused")

    normalized: dict[str, Any] = {
        "schema": schema,
        "capturedAt": captured_at,
        "page": {"url": page_url, "title": page_title, "language": language_tag(page_language)},
        "source": {"id": source_id, "url": expected_url},
        "recipe": recipe,
        "capture": capture,
        "examples": {"matched": matched, "ignored": ignored},
        "provenance": {
            "kind": "rendered-browser-dom",
            "topFrameOnly": True,
            "isolatedWorld": True,
            "arbitrarySharedCode": False,
            "extensionVersion": extension_version,
        },
    }
    if modern:
        normalized["page"]["direction"] = page_direction
        normalized["selection"] = selection
        normalized["provenance"]["extractorRevision"] = extractor_revision
    if contextual:
        normalized["context"] = _capture_page_context(context_raw)
    if coverage_reviewed:
        normalized["coverage"] = _capture_coverage_review(coverage_raw, normalized["context"])
    encoded = json.dumps(normalized, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    if len(encoded) > MAX_BROWSER_CAPTURE_BYTES:
        raise AcquisitionError("browser capture is larger than the 300 KB limit", code="capture-too-large", outcome="refused")
    return normalized


def _capture_boundary_kinds(value: Mapping[str, Any] | None) -> list[str]:
    if not isinstance(value, Mapping):
        return []
    notices = value.get("notices") if isinstance(value.get("notices"), list) else []
    return [clean_text(row.get("kind"), 40) for row in notices if isinstance(row, Mapping) and clean_text(row.get("kind"), 40)]


def _browser_capture_tokens(value: Any, *, maximum: int = 4_000) -> set[str]:
    text = body_text(value, MAX_BROWSER_CAPTURE_TEXT).casefold()
    tokens = re.findall(r"[^\W_]+", text, flags=re.UNICODE)
    return set(tokens[:maximum])


def browser_capture_continuity(
    previous_snapshot: Mapping[str, Any] | None,
    previous_provenance: Mapping[str, Any] | None,
    normalized: Mapping[str, Any],
) -> dict[str, Any]:
    """Detect a moved partial rendering before it becomes a mass change alert.

    This is Node-computed comparison evidence, not browser-supplied confidence.
    A low-overlap change is held only when either accepted observation reported a
    partial-render boundary. Complete-page captures continue through the normal
    page-watch comparison path.
    """
    previous = previous_snapshot if isinstance(previous_snapshot, Mapping) else None
    current_capture = normalized.get("capture") if isinstance(normalized.get("capture"), Mapping) else {}
    current_context = normalized.get("context") if isinstance(normalized.get("context"), Mapping) else None
    current_kinds = _capture_boundary_kinds(current_context)
    previous_kinds = [
        clean_text(row, 40) for row in (
            previous_provenance.get("pageContextKinds", [])
            if isinstance(previous_provenance, Mapping) and isinstance(previous_provenance.get("pageContextKinds"), list)
            else []
        ) if clean_text(row, 40)
    ]
    current_partial = "partial-render" in current_kinds
    previous_partial = "partial-render" in previous_kinds
    evidence: dict[str, Any] = {
        "schema": BROWSER_CAPTURE_CONTINUITY_SCHEMA,
        "action": "accept",
        "reason": "no-prior-baseline" if not previous else "complete-view-comparison",
        "message": "No earlier baseline required rendered-window continuity review." if not previous else "The rendered observations can use the ordinary page-watch comparison.",
        "mode": clean_text(current_capture.get("mode"), 20),
        "previousBoundaryKinds": previous_kinds[:6],
        "currentBoundaryKinds": current_kinds[:6],
        "previousPartialRendering": previous_partial,
        "currentPartialRendering": current_partial,
        "boundaryChanged": previous_partial != current_partial,
        "previousUnits": 0,
        "currentUnits": 0,
        "sharedUnits": 0,
        "overlapPercent": 100,
        "baselinePreserved": False,
    }
    if not previous:
        return evidence
    if not (previous_partial or current_partial):
        return evidence

    mode = clean_text(current_capture.get("mode"), 20)
    previous_mode = clean_text(previous.get("mode"), 20)
    boundary_changed = previous_partial != current_partial
    overlap = 1.0
    previous_units = current_units = shared_units = 0

    if mode == "cards" and previous_mode == "cards":
        previous_entries = previous.get("entries") if isinstance(previous.get("entries"), list) else []
        previous_keys = {
            clean_text(row.get("key"), 600) for row in previous_entries
            if isinstance(row, Mapping) and clean_text(row.get("key"), 600)
        }
        if not previous_keys and isinstance(previous.get("keys"), list):
            previous_keys = {clean_text(row, 600) for row in previous.get("keys", []) if clean_text(row, 600)}
        current_rows = current_capture.get("cards") if isinstance(current_capture.get("cards"), list) else []
        current_keys = {
            clean_text(row.get("key"), 600) for row in current_rows
            if isinstance(row, Mapping) and clean_text(row.get("key"), 600)
        }
        previous_units = len(previous_keys)
        current_units = len(current_keys)
        shared_units = len(previous_keys & current_keys)
        denominator = min(previous_units, current_units)
        overlap = shared_units / denominator if denominator else (1.0 if previous_units == current_units else 0.0)
    elif mode == "region" and previous_mode == "region":
        previous_tokens = _browser_capture_tokens(previous.get("text", ""))
        current_tokens = _browser_capture_tokens(current_capture.get("content", ""))
        previous_units = len(previous_tokens)
        current_units = len(current_tokens)
        shared_units = len(previous_tokens & current_tokens)
        denominator = min(previous_units, current_units)
        overlap = shared_units / denominator if denominator else (1.0 if previous_units == current_units else 0.0)
    else:
        boundary_changed = True
        overlap = 0.0

    enough_evidence = min(previous_units, current_units) >= (2 if mode == "cards" else 8)
    low_overlap = enough_evidence and overlap < 0.35
    evidence.update({
        "previousUnits": min(previous_units, 200_000),
        "currentUnits": min(current_units, 200_000),
        "sharedUnits": min(shared_units, 200_000),
        "overlapPercent": max(0, min(100, round(overlap * 100))),
        "boundaryChanged": boundary_changed,
    })
    if boundary_changed or low_overlap:
        evidence.update({
            "action": "hold",
            "reason": "partial-render-boundary-changed" if boundary_changed else "partial-render-window-shift",
            "message": (
                "The page's partial-rendering boundary changed since the accepted baseline. ProgRSS kept the earlier baseline and created no change alert."
                if boundary_changed else
                "This partial list appears to show a different rendered window. ProgRSS kept the earlier baseline and created no mass add-or-remove alert."
            ),
            "baselinePreserved": True,
        })
    else:
        evidence.update({
            "reason": "partial-render-overlap",
            "message": "The partial rendering retained enough record overlap for the ordinary page-watch comparison.",
        })
    return evidence


def browser_capture_snapshot(normalized: Mapping[str, Any], *, stamp: str) -> dict[str, Any]:
    """Return the bounded portable snapshot represented by one validated capture."""
    capture = normalized.get("capture") if isinstance(normalized.get("capture"), Mapping) else {}
    if capture.get("mode") == "cards":
        rows = [
            {
                "key": str(row.get("key") or ""),
                "title": clean_text(row.get("title"), 240),
                "summary": clean_text(row.get("summary"), 1_000),
                "url": clean_text(row.get("url"), 2_048),
            }
            for row in list(capture.get("cards") or [])[:MAX_BROWSER_CAPTURE_CARDS]
            if isinstance(row, Mapping) and row.get("key")
        ]
        return {"mode": "cards", "keys": [row["key"] for row in rows], "entries": rows, "capturedAt": stamp}
    return {"mode": "region", "text": body_text(capture.get("content"), MAX_BROWSER_CAPTURE_TEXT), "capturedAt": stamp}


def browser_capture_provenance(normalized: Mapping[str, Any], *, artifact_sha256: str) -> dict[str, Any]:
    """Build the accepted private provenance for one validated browser capture."""
    incoming_recipe = normalized.get("recipe") if isinstance(normalized.get("recipe"), Mapping) else {}
    selection = normalized.get("selection") if isinstance(normalized.get("selection"), Mapping) else None
    assessment = selection.get("assessment") if isinstance(selection, Mapping) and isinstance(selection.get("assessment"), Mapping) else None
    context = normalized.get("context") if isinstance(normalized.get("context"), Mapping) else {}
    notices = context.get("notices") if isinstance(context.get("notices"), list) else []
    signals = context.get("signals") if isinstance(context.get("signals"), Mapping) else {}
    coverage = normalized.get("coverage") if isinstance(normalized.get("coverage"), Mapping) else {}
    provenance = normalized.get("provenance") if isinstance(normalized.get("provenance"), Mapping) else {}
    return {
        "schema": BROWSER_CAPTURE_PROVENANCE_SCHEMA,
        "capturedAt": clean_text(normalized.get("capturedAt"), 80),
        "pageUrl": clean_text((normalized.get("page") or {}).get("url") if isinstance(normalized.get("page"), Mapping) else "", 2_048),
        "pageTitle": clean_text((normalized.get("page") or {}).get("title") if isinstance(normalized.get("page"), Mapping) else "", 500),
        "pageLanguage": clean_text((normalized.get("page") or {}).get("language") if isinstance(normalized.get("page"), Mapping) else "", 100),
        "pageDirection": clean_text((normalized.get("page") or {}).get("direction") if isinstance(normalized.get("page"), Mapping) else "", 8),
        "artifactSchema": clean_text(normalized.get("schema"), 100),
        "artifactSha256": clean_text(artifact_sha256, 64),
        "recipeSha256": page_recipe_digest(incoming_recipe),
        "mode": clean_text(incoming_recipe.get("mode"), 20),
        "topFrameOnly": True,
        "isolatedWorld": True,
        "extensionVersion": clean_text(provenance.get("extensionVersion"), 40),
        "extractorRevision": clean_text(provenance.get("extractorRevision"), 80),
        "candidateId": clean_text(selection.get("candidateId"), 80) if selection else "",
        "assessmentLevel": clean_text(assessment.get("level"), 40) if assessment else "",
        "assessmentSummary": clean_text(assessment.get("summary"), 300) if assessment else "",
        "pageContextSchema": clean_text(context.get("schema"), 100),
        "pageContextKinds": [clean_text(row.get("kind"), 40) for row in notices if isinstance(row, Mapping) and clean_text(row.get("kind"), 40)],
        "possibleContinuation": any(isinstance(row, Mapping) and row.get("kind") == "continuation" for row in notices),
        "possiblePartialRendering": any(isinstance(row, Mapping) and row.get("kind") == "partial-render" for row in notices),
        "modalLayers": int(signals.get("modalLayers") or 0),
        "embeddedFrames": int(signals.get("embeddedFrames") or 0),
        "openShadowRoots": int(signals.get("openShadowRoots") or 0),
        "busyRegions": int(signals.get("busyRegions") or 0),
        "coverageReviewSchema": clean_text(coverage.get("schema"), 100),
        "coverageDecision": clean_text(coverage.get("decision"), 80),
        "acknowledgedBoundaryKinds": [clean_text(row, 40) for row in coverage.get("acknowledgedNoticeKinds", []) if clean_text(row, 40)] if isinstance(coverage.get("acknowledgedNoticeKinds"), list) else [],
        "partialViewAcknowledged": coverage.get("decision") == "use-current-rendering",
    }


def _snapshot_digest(snapshot: Mapping[str, Any]) -> str:
    return hashlib.sha256(json.dumps(snapshot, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def _snapshot_units(snapshot: Mapping[str, Any]) -> int:
    if snapshot.get("mode") == "cards":
        rows = snapshot.get("entries") if isinstance(snapshot.get("entries"), list) else snapshot.get("keys") if isinstance(snapshot.get("keys"), list) else []
        return len(rows)
    return len(_browser_capture_tokens(snapshot.get("text", "")))


def replace_browser_capture_baseline(
    document: Mapping[str, Any],
    source_id: str,
    *,
    proposed_snapshot: Mapping[str, Any],
    proposed_provenance: Mapping[str, Any],
    continuity: Mapping[str, Any],
    stamp: str,
    held_operation_id: str,
    held_receipt_id: str,
) -> AcquisitionApplication:
    """Adopt one previously held rendered observation as a fresh baseline.

    The operation creates no historical page-change item and performs no network
    request.  The caller is responsible for retaining the complete pre-operation
    library as rollback evidence.
    """
    result = copy.deepcopy(dict(document))
    state = result["state"]
    source = _source(state, source_id)
    if source.get("type") != "page":
        raise AcquisitionError("baseline replacement is available only for an existing watched page", code="unsupported-source", outcome="refused")
    snapshots = state.get("snapshots") if isinstance(state.get("snapshots"), dict) else {}
    previous = snapshots.get(source_id) if isinstance(snapshots.get(source_id), dict) else None
    if previous is None:
        raise AcquisitionError("the watched page no longer has an accepted baseline", code="missing-baseline", outcome="refused")
    replacement = copy.deepcopy(dict(proposed_snapshot))
    if replacement.get("mode") not in {"cards", "region"}:
        raise AcquisitionError("the held rendered observation is malformed", code="invalid-held-baseline", outcome="refused")
    snapshots[source_id] = replacement
    state["snapshots"] = snapshots
    source["browserCapture"] = copy.deepcopy(dict(proposed_provenance))
    source.pop("watchContinuity", None)
    source.pop("watchStability", None)
    source.pop("watchRepair", None)
    source["watchHealth"] = {
        "schema": PAGE_WATCH_HEALTH_SCHEMA,
        "status": "steady",
        "reason": "baseline-replaced",
        "checkedAt": stamp,
        "message": "The held rendered window is now the accepted baseline. The earlier complete library remains available through the operation snapshot.",
        "metrics": {
            "previousUnits": _snapshot_units(previous),
            "currentUnits": _snapshot_units(replacement),
            "sharedUnits": int(continuity.get("sharedUnits") or 0),
            "overlapPercent": int(continuity.get("overlapPercent") or 0),
        },
    }
    source["lastOutcome"] = "baseline-replaced"
    source["lastItems"] = 0
    source["lastError"] = ""
    source["baselineReplacedAt"] = stamp
    source["baselineReplacement"] = {
        "schema": BROWSER_CAPTURE_BASELINE_REPLACEMENT_SCHEMA,
        "replacedAt": stamp,
        "heldOperationId": clean_text(held_operation_id, 200),
        "heldReceiptId": clean_text(held_receipt_id, 160),
        "previousSnapshotSha256": _snapshot_digest(previous),
        "acceptedSnapshotSha256": _snapshot_digest(replacement),
        "historicalChangeAlertCreated": False,
    }
    source.pop("lastProblemAt", None)
    source.pop("lastProblem", None)
    result["exportedAt"] = stamp
    summary = {
        "baselineReplaced": True,
        "itemsAdded": 0,
        "historicalChangeAlertsCreated": 0,
        "previousMode": clean_text(previous.get("mode"), 20),
        "acceptedMode": clean_text(replacement.get("mode"), 20),
        "previousUnits": _snapshot_units(previous),
        "acceptedUnits": _snapshot_units(replacement),
        "overlapPercent": int(continuity.get("overlapPercent") or 0),
        "message": "The held rendered window became the accepted baseline without creating a historical change alert.",
    }
    evidence = {
        "schema": BROWSER_CAPTURE_BASELINE_REPLACEMENT_SCHEMA,
        "heldOperationId": clean_text(held_operation_id, 200),
        "heldReceiptId": clean_text(held_receipt_id, 160),
        "previousSnapshotSha256": _snapshot_digest(previous),
        "acceptedSnapshotSha256": _snapshot_digest(replacement),
        "continuity": copy.deepcopy(dict(continuity)),
        "networkRequests": 0,
        "automaticScheduleCreated": False,
    }
    return AcquisitionApplication(result, "baseline-replaced", summary, evidence)


def apply_browser_capture(
    document: Mapping[str, Any],
    source_id: str,
    artifact: Mapping[str, Any],
    *,
    stamp: str,
    enable: bool,
    now: float | None = None,
) -> AcquisitionApplication:
    """Apply one validated rendered-DOM capture without any Node network request."""
    result = copy.deepcopy(dict(document))
    state = result["state"]
    source = _source(state, source_id)
    if source.get("type") != "page":
        raise AcquisitionError("browser capture is available only for an existing watched page", code="unsupported-source", outcome="refused")
    normalized = validate_browser_capture(artifact, source_id=source_id, source_url=source.get("url"), now=now)
    previous_provenance = copy.deepcopy(source.get("browserCapture")) if isinstance(source.get("browserCapture"), dict) else None
    artifact_sha256 = hashlib.sha256(json.dumps(normalized, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
    if enable:
        source["enabled"] = True

    incoming_recipe = normalized["recipe"]
    current_recipe = page_recipe(source)
    recipe_changed = page_recipe_digest(incoming_recipe) != page_recipe_digest(current_recipe)
    if recipe_changed:
        source.update(copy.deepcopy(incoming_recipe))
        if isinstance(state.get("snapshots"), dict):
            state["snapshots"].pop(source_id, None)
        source.pop("watchStability", None)
        source.pop("watchRepair", None)
        source.pop("watchHealth", None)
        source["recipeVersion"] = max(0, int(source.get("recipeVersion") or 0)) + 1

    capture = normalized["capture"]
    previous = state.get("snapshots", {}).get(source_id) if isinstance(state.get("snapshots"), dict) else None
    if recipe_changed:
        previous = None
    continuity = browser_capture_continuity(
        previous if isinstance(previous, dict) else None,
        previous_provenance,
        normalized,
    )
    if not recipe_changed and continuity.get("action") == "hold":
        message = clean_text(continuity.get("message"), 300)
        health = {
            "schema": PAGE_WATCH_HEALTH_SCHEMA,
            "status": "attention",
            "reason": "coverage-window-shift",
            "checkedAt": stamp,
            "message": message,
            "metrics": {
                "previousUnits": int(continuity.get("previousUnits") or 0),
                "currentUnits": int(continuity.get("currentUnits") or 0),
                "sharedUnits": int(continuity.get("sharedUnits") or 0),
                "overlapPercent": int(continuity.get("overlapPercent") or 0),
            },
        }
        source["watchHealth"] = copy.deepcopy(health)
        source["watchContinuity"] = copy.deepcopy(continuity)
        source.pop("watchStability", None)
        source["lastScan"] = stamp
        source["lastItems"] = 0
        source["lastOutcome"] = "coverage-shift"
        source["lastError"] = ""
        source["lastProblemAt"] = stamp
        source["lastProblem"] = message
        source["lastHttpStatus"] = 0
        source["lastSuccessfulAt"] = stamp
        source["checkCount"] = max(0, int(source.get("checkCount") or 0)) + 1
        result["exportedAt"] = stamp
        return AcquisitionApplication(
            result, "coverage-shift",
            {
                "itemsAdded": 0, "baseline": False, "baselinePreserved": True,
                "enabledNow": bool(enable), "recipeChanged": False, "message": message,
            },
            {
                "capture": {
                    "artifactSha256": artifact_sha256,
                    "capturedAt": normalized["capturedAt"],
                    "pageTitle": normalized["page"]["title"],
                    "pageLanguage": normalized["page"]["language"],
                    "recipeSha256": page_recipe_digest(incoming_recipe),
                    "recipeChanged": False,
                    "mode": capture.get("mode"),
                    "matchCount": int(capture.get("matchCount") or 0),
                    "matchedExamples": normalized["examples"]["matched"],
                    "ignoredExample": normalized["examples"]["ignored"],
                    "selection": copy.deepcopy(normalized.get("selection")),
                    "context": copy.deepcopy(normalized.get("context")),
                    "coverage": copy.deepcopy(normalized.get("coverage")),
                    "provenance": normalized["provenance"],
                },
                "health": health,
                "continuity": copy.deepcopy(continuity),
            },
        )
    health = page_watch_capture_health(previous if isinstance(previous, dict) else None, capture, checked_at=stamp)
    if health.get("status") == "attention" and not recipe_changed:
        _problem(source, clean_text(health.get("message"), 300), "needs-repair", stamp, 0)
        source["watchHealth"] = health
        result["exportedAt"] = stamp
        return AcquisitionApplication(
            result, "needs-repair",
            {"itemsAdded": 0, "baseline": False, "enabledNow": bool(enable), "recipeChanged": False, "message": health.get("message", "")},
            {"capture": normalized, "health": health},
        )
    decision = {"action": "accept", "health": health}
    if not recipe_changed:
        decision = page_watch_stability_decision(source.get("watchStability") if isinstance(source.get("watchStability"), dict) else None, health, source)
    if decision.get("action") == "repair":
        _problem(source, clean_text(decision.get("health", {}).get("message"), 300), "needs-repair", stamp, 0)
        source["watchHealth"] = decision.get("health")
        source.pop("watchStability", None)
        result["exportedAt"] = stamp
        return AcquisitionApplication(result, "needs-repair", {"itemsAdded": 0, "baseline": False, "enabledNow": bool(enable), "recipeChanged": False, "message": source["lastError"]}, {"capture": normalized, "health": source.get("watchHealth")})
    if decision.get("action") == "hold":
        source["watchStability"] = copy.deepcopy(decision.get("stability"))
        source["watchHealth"] = copy.deepcopy(decision.get("health"))
        source["lastScan"] = stamp
        source["lastItems"] = 0
        source["lastOutcome"] = "watch-pending"
        source["lastError"] = ""
        source["lastSuccessfulAt"] = stamp
        source["checkCount"] = max(0, int(source.get("checkCount") or 0)) + 1
        result["exportedAt"] = stamp
        return AcquisitionApplication(result, "watch-pending", {"itemsAdded": 0, "baseline": False, "enabledNow": bool(enable), "recipeChanged": False, "message": source["watchHealth"].get("message", "")}, {"capture": normalized, "health": source["watchHealth"]})

    page_result = _ingest_page(state, source, capture, stamp)
    source["lastScan"] = stamp
    source["lastHttpStatus"] = 0
    source["checkCount"] = max(0, int(source.get("checkCount") or 0)) + 1
    source["lastResolvedUrl"] = normalized["page"]["url"]
    source["lastRedirects"] = []
    source["watchHealth"] = copy.deepcopy(decision.get("health"))
    source.pop("watchStability", None)
    source.pop("watchRepair", None)
    source.pop("watchContinuity", None)
    source["lastItems"] = int(page_result.get("added") or 0)
    source["lastOutcome"] = "baseline" if page_result.get("baseline") else ("changed" if page_result.get("added") else "unchanged")
    source["lastError"] = ""
    source["lastSuccessfulAt"] = stamp
    if page_result.get("added"):
        source["lastNewAt"] = stamp
    source.pop("pendingRedirect", None)
    source["browserCapture"] = browser_capture_provenance(normalized, artifact_sha256=artifact_sha256)
    result["exportedAt"] = stamp
    return AcquisitionApplication(
        result,
        source["lastOutcome"],
        {
            "itemsAdded": int(page_result.get("added") or 0),
            "baseline": bool(page_result.get("baseline")),
            "enabledNow": bool(enable),
            "recipeChanged": recipe_changed,
            "mode": capture.get("mode"),
            "matchCount": int(capture.get("matchCount") or 0),
        },
        {
            "capture": {
                "artifactSha256": artifact_sha256,
                "capturedAt": normalized["capturedAt"],
                "pageTitle": normalized["page"]["title"],
                "pageLanguage": normalized["page"]["language"],
                "recipeSha256": page_recipe_digest(incoming_recipe),
                "recipeChanged": recipe_changed,
                "mode": capture.get("mode"),
                "matchCount": int(capture.get("matchCount") or 0),
                "matchedExamples": normalized["examples"]["matched"],
                "ignoredExample": normalized["examples"]["ignored"],
                "selection": copy.deepcopy(normalized.get("selection")),
                "context": copy.deepcopy(normalized.get("context")),
                "coverage": copy.deepcopy(normalized.get("coverage")),
                "provenance": normalized["provenance"],
            },
            "health": source.get("watchHealth"),
            "continuity": copy.deepcopy(continuity),
        },
    )

def source_preview(document: Mapping[str, Any], source_id: str) -> dict[str, Any]:
    state = document.get("state") if isinstance(document.get("state"), dict) else {}
    source = _source(state, source_id)
    url = _safe_url(source.get("url"))
    parsed = urllib.parse.urlsplit(url)
    paused = not bool(source.get("enabled"))
    return {
        "sourceId": source_id,
        "title": clean_text(source.get("title"), 180) or ("Untitled feed" if source.get("type") == "rss" else "Untitled page watch"),
        "type": source.get("type"),
        "site": str(parsed.hostname or "").lower(),
        "url": url,
        "paused": paused,
        "archived": bool(source.get("archivedAt")),
        "action": "enable-and-check" if paused else "check-now",
        "actionLabel": "Enable and check once" if paused else "Check once now",
        "lastOutcome": clean_text(source.get("lastOutcome"), 80),
        "lastSuccessfulAt": best_date(source.get("lastSuccessfulAt")),
        "lastProblem": clean_text(source.get("lastProblem") or source.get("lastError"), 300),
        "validators": {
            "etag": bool(_valid_etag((source.get("httpCache") or {}).get("etag") if isinstance(source.get("httpCache"), dict) else "")),
            "lastModified": bool(_valid_http_date((source.get("httpCache") or {}).get("lastModified") if isinstance(source.get("httpCache"), dict) else "")),
        },
        "pageRecipe": ({**page_recipe(source), "selector": page_recipe(source)["selector"] or "Readable page body"} if source.get("type") == "page" else None),
    }


__all__ = [
    "ACQUISITION_JOB_SCHEMA",
    "ACQUISITION_PREVIEW_SCHEMA",
    "ACQUISITION_RECEIPT_SCHEMA",
    "ACQUISITION_RESULT_SCHEMA",
    "AcquisitionApplication",
    "AcquisitionError",
    "BROWSER_CAPTURE_ASSESSMENT_SCHEMA",
    "BROWSER_CAPTURE_CONTOUR_SCHEMA",
    "BROWSER_CAPTURE_CONTINUITY_SCHEMA",
    "BROWSER_CAPTURE_COVERAGE_SCHEMA",
    "BROWSER_CAPTURE_LEGACY_SCHEMA",
    "BROWSER_CAPTURE_PROVENANCE_SCHEMA",
    "BROWSER_CAPTURE_SCHEMA",
    "BROWSER_CAPTURE_SELECTION_SCHEMA",
    "MAX_BROWSER_CAPTURE_BYTES",
    "FetchResult",
    "acquisition_source_identity",
    "apply_browser_capture",
    "browser_capture_continuity",
    "browser_capture_provenance",
    "browser_capture_snapshot",
    "apply_failure",
    "apply_fetch",
    "fetch_public_resource",
    "page_recipe",
    "page_recipe_digest",
    "resolve_public_addresses",
    "source_preview",
    "replace_browser_capture_baseline",
    "validate_browser_capture",
]
