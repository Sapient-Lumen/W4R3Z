#!/usr/bin/env python3
"""Private, self-contained ProgRSS fieldwork sheets.

A fieldbook is a facilitator sidecar for testing the *actual* ProgRSS interface.
It contains no source address, selector, snapshot text, browser capability, or
participant identity by default. It performs no network request and persists
nothing until the facilitator explicitly downloads a local report.
"""

from __future__ import annotations

import hashlib
import html
import json
import re
from typing import Any, Mapping

FIELDWORK_KIT_SCHEMA = "progrss.fieldwork-kit.v1"
FIELDWORK_REPORT_SCHEMA = "progrss.fieldwork-report.v1"
FIELDWORK_SCENARIO = "trace-bearing-anchor"
EXCHANGE_FIELDWORK_SCENARIO = "exchange-three-doors"
EXCHANGE_SENDER_FIELDWORK_SCENARIO = "exchange-sender-review"
MAX_FIELDWORK_TASKS = 20
MAX_FIELDWORK_NOTE_CHARS = 600


class FieldbookError(ValueError):
    """Expected fieldbook-generation failure."""


def _text(value: Any, limit: int = 600) -> str:
    return re.sub(r"\s+", " ", str(value if value is not None else "")).strip()[:limit]


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _digest(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def _task(
    task_id: str,
    title: str,
    prompt: str,
    success: str,
    wrong_turns: list[str],
) -> dict[str, Any]:
    return {
        "id": task_id,
        "title": title,
        "prompt": prompt,
        "successSignal": success,
        "wrongTurns": [_text(row, 240) for row in wrong_turns[:4]],
    }


def build_trace_fieldwork_scenario(
    review: Mapping[str, Any],
    *,
    version: str,
    revision: str,
    codename: str,
    generated_at: str,
) -> dict[str, Any]:
    """Build one bounded, privacy-minimized Trace/Bearing/Anchor study scenario."""
    if review.get("schema") != "progrss.node.bearing-review.v2":
        raise FieldbookError("fieldwork requires one progrss.node.bearing-review.v2 document")
    if review.get("network") is not False or review.get("writes") is not False:
        raise FieldbookError("fieldwork requires a read-only zero-network Bearing review")

    diagnosis = review.get("diagnosis") if isinstance(review.get("diagnosis"), Mapping) else {}
    trace = review.get("trace") if isinstance(review.get("trace"), Mapping) else {}
    footprint = review.get("recipeFootprint") if isinstance(review.get("recipeFootprint"), Mapping) else {}
    observations = trace.get("observations") if isinstance(trace.get("observations"), list) else []
    relationships: list[dict[str, Any]] = []
    for row in observations[:9]:
        if not isinstance(row, Mapping):
            continue
        relationship = row.get("relationshipToPrevious") if isinstance(row.get("relationshipToPrevious"), Mapping) else {}
        relationships.append({
            "ordinal": max(1, int(row.get("ordinal") or len(relationships) + 1)),
            "current": bool(row.get("current")),
            "relationship": _text(relationship.get("title"), 80) or "Not enough evidence",
            "relationshipKind": _text(relationship.get("kind"), 60) or "insufficient-evidence",
            "boundaryKinds": [
                _text(value, 40) for value in (row.get("boundaryKinds") if isinstance(row.get("boundaryKinds"), list) else [])[:6]
                if _text(value, 40)
            ],
        })

    scenario_core = {
        "scenario": FIELDWORK_SCENARIO,
        "release": {"version": _text(version, 40), "revision": _text(revision, 40), "codename": _text(codename, 60)},
        "diagnosis": {
            "kind": _text(diagnosis.get("kind"), 80),
            "title": _text(diagnosis.get("title"), 120),
        },
        "trace": {
            "acceptedPresent": isinstance(trace.get("accepted"), Mapping),
            "observationCount": len(relationships),
            "relationships": relationships,
        },
        "recipeFootprint": {
            "kind": _text(footprint.get("kind"), 80),
            "label": _text(footprint.get("label"), 120),
        },
    }
    scenario_digest = _digest(scenario_core)

    tasks = [
        _task(
            "accepted-baseline",
            "Find the accepted baseline",
            "Ask the participant to identify where future comparisons still begin.",
            "They identify Accepted baseline without treating it as complete, permanent, or publisher-certified.",
            ["Chooses the newest hold", "Says the baseline is guaranteed complete", "Cannot find the accepted point"],
        ),
        _task(
            "current-hold",
            "Find the current hold",
            "Ask which observation is waiting for a later decision.",
            "They identify Current hold and distinguish it from the accepted baseline.",
            ["Calls it the new baseline", "Calls it an applied repair", "Selects an earlier held observation"],
        ),
        _task(
            "observation-not-history",
            "Explain what the trail represents",
            "Ask whether the trail is confirmed history of everything on the publisher's site.",
            "They say it is a bounded sequence of local browser and Node observations, not complete publisher history.",
            ["Treats it as a complete remote audit log", "Assumes absent records were deleted", "Assumes the site was continuously monitored"],
        ),
        _task(
            "different-window",
            "Explain Different window",
            "Ask what Different window means for old and newly visible records.",
            "They say the partial renderings were too disjoint for a literal mass add-or-remove conclusion.",
            ["Says every old record was deleted", "Says every visible record is definitely new", "Treats the label as certainty"],
        ),
        _task(
            "overlap",
            "Explain overlap",
            "Ask what an overlap percentage describes.",
            "They describe shared stable units between two bounded observations, not probability or confidence.",
            ["Calls it confidence", "Calls it page completeness", "Calls it a probability of correctness"],
        ),
        _task(
            "recipe-footprint",
            "Explain the recipe footprint",
            "Ask what the footprint label says—and what it does not promise.",
            "They say it describes what the saved declarative selector depends on, not how long it will remain valid.",
            ["Treats Semantic boundary as permanent", "Treats Implementation-detail selector as already broken", "Calls the label a reliability score"],
        ),
        _task(
            "keep",
            "Explain Keep accepted baseline",
            "Ask what happens after choosing Keep accepted baseline.",
            "They say the review closes with no site request, browser request, or library write.",
            ["Expects a site check", "Expects the hold to become accepted", "Expects the hold history to be erased"],
        ),
        _task(
            "anchor",
            "Explain Open Anchor",
            "Ask whether Open Anchor immediately changes the library.",
            "They say it opens another review and still requires a separate acknowledgement before one typed write.",
            ["Says the baseline changes immediately", "Misses the separate acknowledgement", "Assumes automatic rollback"],
        ),
        _task(
            "fresh-capture",
            "Explain Begin a fresh Capture",
            "Ask what happens before the browser action.",
            "They say the Node creates a short-lived request; the exact page still must be opened and deliberately captured.",
            ["Says the Node already contacted the site", "Says ProgRSS searches open tabs", "Expects a recurring browser schedule"],
        ),
        _task(
            "pairing-authority",
            "Explain paired Extension authority",
            "Ask whether a summary-only paired Extension can perform Bearing repair or Anchor writes.",
            "They say pairing does not grant held-window evidence or write authority.",
            ["Believes pairing grants administrator access", "Believes the Extension can replace the baseline", "Believes pairing exposes snapshots"],
        ),
        _task(
            "advanced-evidence",
            "Find exact evidence only when asked",
            "Ask the participant to find the exact selector and evidence details.",
            "They open Advanced held-window evidence without needing those details for the ordinary decision.",
            ["Cannot find Advanced evidence", "Assumes hidden details do not exist", "Feels forced to read hashes before choosing an exit"],
        ),
        _task(
            "network-and-write",
            "State the review effects",
            "Ask whether opening Trace made a watched-site request or changed the library.",
            "They say the review itself has zero network effect and zero writes.",
            ["Believes Trace refreshed the site", "Believes the review accepted the hold", "Believes a Pulse schedule was created"],
        ),
    ]
    if len(tasks) > MAX_FIELDWORK_TASKS:
        raise FieldbookError("fieldwork task limit exceeded")

    return {
        "schema": FIELDWORK_KIT_SCHEMA,
        "scenario": FIELDWORK_SCENARIO,
        "scenarioDigest": scenario_digest,
        "generatedAt": _text(generated_at, 80),
        "release": scenario_core["release"],
        "presentation": {
            "eyebrow": "Private facilitator sidecar",
            "heading": "Test the wording, not the person.",
            "intro": (
                "This fieldbook accompanies the actual ProgRSS Trace, Bearing, and Anchor interface "
                "in another window. It is not a product simulation. Record observable wrong turns, "
                "neutral prompts, and independent understanding without coaching the participant."
            ),
            "scenarioLabel": "Trace / Bearing / Anchor fieldwork",
        },
        "context": {
            "diagnosis": scenario_core["diagnosis"],
            "observationCount": scenario_core["trace"]["observationCount"],
            "recipeFootprint": scenario_core["recipeFootprint"],
        },
        "tasks": tasks,
        "outcomes": [
            {"value": "independent", "label": "Understood independently"},
            {"value": "neutral-prompt", "label": "Understood after a neutral prompt"},
            {"value": "wrong-turn", "label": "Wrong turn or unsafe interpretation"},
            {"value": "not-observed", "label": "Not observed"},
        ],
        "privacy": {
            "participantIdentityRequested": False,
            "sourceTitleIncluded": False,
            "sourceAddressIncluded": False,
            "selectorIncluded": False,
            "snapshotContentIncluded": False,
            "capabilityIncluded": False,
            "automaticPersistence": False,
            "network": False,
            "telemetry": False,
            "noteLimit": MAX_FIELDWORK_NOTE_CHARS,
        },
        "effects": {"network": False, "libraryWrites": False, "storeWrites": False},
    }


def build_exchange_fieldwork_scenario(
    review: Mapping[str, Any],
    *,
    version: str,
    revision: str,
    codename: str,
    generated_at: str,
) -> dict[str, Any]:
    """Build one bounded recipient study for an actual Exchange handoff.

    The scenario deliberately omits curator names, route titles, hostnames,
    source names, folder paths, URLs, exchange identifiers, and capability
    material. The participant uses the actual Extension invitation in another
    window; the facilitator records comprehension here.
    """
    if review.get("schema") != "progrss.node.exchange.v1":
        raise FieldbookError("Exchange fieldwork requires one progrss.node.exchange.v1 document")
    if review.get("automatic") is not False or review.get("revocable") is not True:
        raise FieldbookError("Exchange fieldwork requires a manual, revocable handoff")
    if _text(review.get("scope"), 100) != "one-expiring-reviewed-artifact-handoff":
        raise FieldbookError("Exchange fieldwork requires one bounded artifact handoff")

    choices = review.get("choices") if isinstance(review.get("choices"), Mapping) else {}
    follow = choices.get("followUpdates") if isinstance(choices.get("followUpdates"), Mapping) else {}
    route = choices.get("addRoute") if isinstance(choices.get("addRoute"), Mapping) else {}
    branch = choices.get("takeBranch") if isinstance(choices.get("takeBranch"), Mapping) else {}
    follow_available = bool(follow.get("available"))
    route_available = bool(route.get("available", True))
    branch_available = bool(branch.get("available"))
    branch_rows = branch.get("branches") if isinstance(branch.get("branches"), list) else []
    counts = review.get("counts") if isinstance(review.get("counts"), Mapping) else {}
    if not route_available:
        raise FieldbookError("Exchange fieldwork requires the complete-route choice")

    release = {
        "version": _text(version, 40),
        "revision": _text(revision, 40),
        "codename": _text(codename, 60),
    }
    scenario_core = {
        "scenario": EXCHANGE_FIELDWORK_SCENARIO,
        "release": release,
        "choices": {
            "followUpdates": follow_available,
            "addRoute": route_available,
            "takeBranch": branch_available,
            "branchChoices": min(30, len(branch_rows)),
        },
        "counts": {
            "sources": max(0, int(counts.get("sources") or 0)),
            "feeds": max(0, int(counts.get("feeds") or 0)),
            "pageWatches": max(0, int(counts.get("pageWatches") or 0)),
            "folders": max(0, int(counts.get("folders") or 0)),
            "recentUpdates": max(0, int(counts.get("recentUpdates") or 0)),
        },
        "handoff": {
            "expiring": bool(review.get("expiresAt")),
            "revocable": True,
            "automatic": False,
        },
    }
    scenario_digest = _digest(scenario_core)

    tasks: list[dict[str, Any]] = [
        _task(
            "invitation-not-pairing",
            "Explain what the invitation grants",
            "Ask whether opening this invitation pairs the whole Extension to the sender's Node or grants administrator access.",
            "They say it is one expiring, revocable artifact handoff—not general pairing, synchronization, or Node administration.",
            ["Calls it permanent pairing", "Expects the sender to see their library", "Assumes administrator access"],
        ),
        _task(
            "find-choices",
            "Find the available choices",
            "Ask the participant to identify the distinct things they can do with this handoff.",
            "They identify each available consequence without treating the cards as file-format choices.",
            ["Looks for one generic Add button", "Treats every card as the same import", "Cannot tell which choices are unavailable"],
        ),
        _task(
            "preview-not-commit",
            "Explain what choosing a door does first",
            "Ask whether selecting one choice immediately follows or imports anything.",
            "They say the selected artifact is retrieved and reviewed first; a later explicit action performs Follow or Add.",
            ["Believes one click commits", "Confuses preview with follow", "Believes review contacts every listed site"],
        ),
    ]

    if follow_available:
        tasks.extend([
            _task(
                "follow-updates",
                "Explain Follow updates",
                "Ask what will be added after the later Follow decision.",
                "They say one durable summary feed is added, not the underlying feeds, watched pages, folders, or Node relationship.",
                ["Expects every underlying source", "Treats the temporary invitation as the followed feed", "Expects Node pairing"],
            ),
            _task(
                "choose-follow",
                "Choose updates without adopting the route",
                "Give this goal: read the curator's future summary updates without adding all underlying sources. Ask which door fits.",
                "They choose Follow updates and can explain why the complete route is unnecessary.",
                ["Chooses complete route", "Chooses branch", "Looks for a fourth subscription option"],
            ),
        ])

    tasks.extend([
        _task(
            "add-route",
            "Explain Add the complete route",
            "Ask what the complete-route path reviews and may later add.",
            "They say it reviews all included feeds, watched-page recipes, and folders; exact existing sources are reused and new sources begin paused.",
            ["Calls it one summary feed", "Expects every source to start fetching immediately", "Assumes private reading state arrives"],
        ),
        _task(
            "choose-route",
            "Choose the complete curated source graph",
            "Give this goal: adopt the curator's complete set of underlying sources and retain the publication relationship. Ask which door fits.",
            "They choose Add the complete route rather than Follow updates or the independent branch path.",
            ["Chooses Follow updates", "Chooses branch while expecting parent continuity", "Assumes the invitation itself imported everything"],
        ),
    ])

    if branch_available:
        tasks.extend([
            _task(
                "take-branch",
                "Explain Take one branch",
                "Ask what happens to the selected folder section after adoption.",
                "They say it becomes an independent local route containing the selected folder closure, without the parent's future-copy relationship or a counterfeit subset signature.",
                ["Expects future parent copies to rewrite it", "Treats it as separately signed", "Expects source-by-source picking"],
            ),
            _task(
                "choose-branch",
                "Choose one independent section",
                "Give this goal: adopt only one useful nested section and keep it independent from the parent publication. Ask which door fits.",
                "They choose Take one branch and distinguish it from both the summary feed and complete route.",
                ["Chooses complete route", "Chooses Follow updates", "Expects continuing parent synchronization"],
            ),
        ])

    tasks.extend([
        _task(
            "paused-and-reused",
            "Explain reused and paused sources",
            "Ask what happens when an exact source already exists and what happens to a genuinely new source.",
            "They say exact sources are reused and new sources begin paused until separately enabled.",
            ["Expects duplicates", "Expects immediate fetching", "Believes paused means deleted"],
        ),
        _task(
            "no-listed-site-contact",
            "Explain review network effects",
            "Ask whether reviewing the handoff contacts the feeds and watched pages listed inside it.",
            "They say review retrieves only the chosen handoff artifact and does not contact its listed sources.",
            ["Believes every listed site was checked", "Believes the browser granted all site permissions", "Believes a schedule was created"],
        ),
        _task(
            "private-state",
            "Explain what does not travel",
            "Ask whether read state, saved state, retained private article text, page observations, browser cookies, or signing keys arrive with the route.",
            "They say those remain private and are excluded from the handoff.",
            ["Expects reading history", "Expects browser login or cookies", "Expects private retained text"],
        ),
        _task(
            "expiry-and-revocation",
            "Explain expiry and revocation",
            "Ask whether the invitation remains a permanent access path after the handoff expires or the sender revokes it.",
            "They say the invitation is temporary and revocable; already adopted local material remains local.",
            ["Calls the invitation permanent", "Expects revocation to erase the recipient's local library", "Assumes future synchronization"],
        ),
        _task(
            "advanced-evidence",
            "Find exact evidence only when asked",
            "Ask the participant to inspect source names, hostnames, routes, counts, and integrity details without making them prerequisite vocabulary for choosing a door.",
            "They can find bounded evidence when requested while still deciding from ordinary consequences.",
            ["Cannot find contents", "Feels required to interpret hashes first", "Treats hostname review as proof that the source is safe"],
        ),
        _task(
            "state-the-boundary",
            "State the complete handoff boundary",
            "Ask what the handoff did merely by being opened and reviewed.",
            "They say it created no automatic follow, import, listed-site fetch, schedule, pairing, or library write.",
            ["Believes something was already added", "Believes automatic sync started", "Believes the sender gained recipient access"],
        ),
    ])

    if len(tasks) > MAX_FIELDWORK_TASKS:
        raise FieldbookError("fieldwork task limit exceeded")

    return {
        "schema": FIELDWORK_KIT_SCHEMA,
        "scenario": EXCHANGE_FIELDWORK_SCENARIO,
        "scenarioDigest": scenario_digest,
        "generatedAt": _text(generated_at, 80),
        "release": release,
        "presentation": {
            "eyebrow": "Private recipient-study sidecar",
            "heading": "Observe the choice, not the person.",
            "intro": (
                "This fieldbook accompanies the actual ProgRSS Extension handoff in another window. "
                "It is not a mockup. Ask goal-based questions, observe which door the participant "
                "chooses, and use neutral prompts only after an independent attempt."
            ),
            "scenarioLabel": "Exchange recipient fieldwork",
        },
        "context": scenario_core,
        "tasks": tasks,
        "outcomes": [
            {"value": "independent", "label": "Understood independently"},
            {"value": "neutral-prompt", "label": "Understood after a neutral prompt"},
            {"value": "wrong-turn", "label": "Wrong turn or unsafe interpretation"},
            {"value": "not-observed", "label": "Not observed"},
        ],
        "privacy": {
            "participantIdentityRequested": False,
            "sourceTitleIncluded": False,
            "sourceAddressIncluded": False,
            "selectorIncluded": False,
            "snapshotContentIncluded": False,
            "capabilityIncluded": False,
            "curatorIdentityIncluded": False,
            "folderPathIncluded": False,
            "automaticPersistence": False,
            "network": False,
            "telemetry": False,
            "noteLimit": MAX_FIELDWORK_NOTE_CHARS,
        },
        "effects": {"network": False, "libraryWrites": False, "storeWrites": False},
    }


def build_exchange_sender_fieldwork_scenario(
    preview: Mapping[str, Any],
    *,
    version: str,
    revision: str,
    codename: str,
    generated_at: str,
) -> dict[str, Any]:
    """Build one bounded sender study for the actual Exchange review.

    The scenario is derived from a live ``progrss.node.exchange-preview.v1``
    document but deliberately excludes route identity, curator identity, source
    identity, folder paths, public addresses, library details, artifact digests,
    and the preview capability. The sender uses the real Node review in another
    window while the facilitator records comprehension here.
    """
    if preview.get("schema") != "progrss.node.exchange-preview.v1":
        raise FieldbookError("sender fieldwork requires one progrss.node.exchange-preview.v1 document")
    if _text(preview.get("state"), 40) != "preview":
        raise FieldbookError("sender fieldwork requires one active Exchange preview")
    if preview.get("network") is not False or preview.get("writes") is not False or preview.get("automatic") is not False:
        raise FieldbookError("sender fieldwork requires an offline, read-only, non-automatic preview")

    choices = preview.get("choices") if isinstance(preview.get("choices"), Mapping) else {}
    follow = choices.get("followUpdates") if isinstance(choices.get("followUpdates"), Mapping) else {}
    route = choices.get("addRoute") if isinstance(choices.get("addRoute"), Mapping) else {}
    branch = choices.get("takeBranch") if isinstance(choices.get("takeBranch"), Mapping) else {}
    follow_available = bool(follow.get("available"))
    route_available = bool(route.get("available", True))
    branch_available = bool(branch.get("available"))
    branch_rows = branch.get("branches") if isinstance(branch.get("branches"), list) else []
    if not route_available:
        raise FieldbookError("sender fieldwork requires the complete-route choice")

    counts = preview.get("counts") if isinstance(preview.get("counts"), Mapping) else {}
    artifacts = preview.get("artifacts") if isinstance(preview.get("artifacts"), Mapping) else {}
    source_artifact = artifacts.get("sourceList") if isinstance(artifacts.get("sourceList"), Mapping) else {}
    updates_artifact = artifacts.get("recentUpdates") if isinstance(artifacts.get("recentUpdates"), Mapping) else {}
    site_artifact = artifacts.get("site") if isinstance(artifacts.get("site"), Mapping) else {}
    public = preview.get("public") if isinstance(preview.get("public"), Mapping) else {}
    privacy = preview.get("privacy") if isinstance(preview.get("privacy"), Mapping) else {}
    included = privacy.get("included") if isinstance(privacy.get("included"), list) else []
    excluded = privacy.get("excluded") if isinstance(privacy.get("excluded"), list) else []
    expected_exclusions = {
        "read and unread state",
        "saved state",
        "full retained article text",
        "page-watch snapshots and comparison evidence",
        "browser permissions and cookies",
        "private signing keys",
    }
    if not expected_exclusions.issubset({_text(value, 120) for value in excluded}):
        raise FieldbookError("sender fieldwork requires the complete Exchange privacy exclusion set")

    release = {
        "version": _text(version, 40),
        "revision": _text(revision, 40),
        "codename": _text(codename, 60),
    }
    scenario_core = {
        "scenario": EXCHANGE_SENDER_FIELDWORK_SCENARIO,
        "release": release,
        "choices": {
            "followUpdates": follow_available,
            "addRoute": route_available,
            "takeBranch": branch_available,
            "branchChoices": min(30, len(branch_rows)),
        },
        "counts": {
            "sources": max(0, int(counts.get("sources") or 0)),
            "feeds": max(0, int(counts.get("feeds") or 0)),
            "pageWatches": max(0, int(counts.get("pageWatches") or 0)),
            "folders": max(0, int(counts.get("folders") or 0)),
            "recentUpdates": max(0, int(counts.get("recentUpdates") or 0)),
        },
        "artifacts": {
            "sourceList": bool(source_artifact.get("available", True)),
            "recentUpdates": bool(updates_artifact.get("available")),
            "staticSite": bool(site_artifact.get("available")),
        },
        "public": {
            "sourceListAddressConfigured": bool(_text(public.get("sourceListUrl"), 4096)),
            "publicPageAvailable": bool(_text(public.get("pageUrl"), 4096)),
            "durableFeedAvailable": bool(_text(public.get("feedUrl"), 4096)),
        },
        "privacy": {
            "includedCategories": min(8, len([value for value in included if _text(value, 120)])),
            "excludedCategories": min(12, len([value for value in excluded if _text(value, 120)])),
        },
        "handoff": {
            "previewExpiring": bool(preview.get("expiresAt")),
            "automatic": False,
        },
    }
    scenario_digest = _digest(scenario_core)

    tasks: list[dict[str, Any]] = [
        _task(
            "review-not-send",
            "Explain what Review this share did",
            "Ask whether reviewing this share already published, sent, followed, imported, or changed anything.",
            "They say the Node prepared bounded artifacts locally for review; nothing was published, sent, followed, imported, or changed.",
            ["Says the route is already public", "Says the recipient has already received it", "Says the library was changed"],
        ),
        _task(
            "included-material",
            "Explain what the route can include",
            "Ask what kinds of material the reviewed source-list artifact can carry.",
            "They identify source recipes, simple folder routes, curator wording, and bounded recent-update summaries when selected.",
            ["Says only feed URLs travel", "Expects arbitrary executable code", "Cannot distinguish curation from private reading state"],
        ),
        _task(
            "excluded-private-state",
            "Explain what stays private",
            "Ask whether read state, saved state, retained private text, page-watch evidence, browser cookies, permissions, or private signing keys will be shared.",
            "They say all of those remain excluded from the reviewed artifacts and handoff.",
            ["Expects reading history to travel", "Expects browser login or cookies to travel", "Expects private retained text to travel"],
        ),
        _task(
            "recipient-doors",
            "Find the recipient choices",
            "Ask the sender to identify the distinct recipient consequences that this reviewed handoff can offer.",
            "They identify every available door and understand that unavailable doors are honestly omitted rather than simulated.",
            ["Treats all doors as the same import", "Looks for one generic share action", "Assumes an unavailable choice will appear later"],
        ),
    ]

    if follow_available:
        tasks.append(_task(
            "durable-follow",
            "Explain Follow updates from the sender side",
            "Ask what address the recipient ultimately follows and what is not added.",
            "They say the recipient later follows one durable public summary feed, not the expiring Node invitation or underlying source graph.",
            ["Treats the invitation as the feed", "Expects all underlying sources", "Expects permanent Node pairing"],
        ))
    else:
        tasks.append(_task(
            "follow-unavailable",
            "Explain why Follow updates is unavailable",
            "Ask why the reviewed handoff cannot honestly offer a durable Follow updates choice.",
            "They identify the missing durable public feed or recent-updates artifact rather than expecting the temporary Node invitation to become a subscription.",
            ["Expects the expiring invitation to be followed", "Assumes the option is merely hidden", "Expects the Node to publish automatically"],
        ))

    tasks.extend([
        _task(
            "complete-route-consequence",
            "Explain the complete-route consequence",
            "Ask what a recipient may later review and adopt through Add the complete route.",
            "They say all included feeds, watched-page recipes, and folders are reviewed; exact existing sources are reused and genuinely new sources begin paused.",
            ["Calls it one summary feed", "Expects every source to fetch immediately", "Expects duplicates for exact existing sources"],
        ),
    ])

    if branch_available:
        tasks.append(_task(
            "branch-consequence",
            "Explain the branch consequence",
            "Ask what the recipient gets through Take one branch and what relationship is not retained.",
            "They say the selected folder closure becomes an independent local route without the parent publication's future-copy continuity or a counterfeit subset signature.",
            ["Expects continuing parent synchronization", "Treats the excerpt as separately signed", "Expects source-by-source picking"],
        ))

    if scenario_core["public"]["sourceListAddressConfigured"]:
        tasks.append(_task(
            "public-address",
            "Explain the public source-list address",
            "Ask what entering a public source-list address does during preparation.",
            "They say it declares the final address they control and enables durable publication artifacts; the Node does not upload anything there.",
            ["Says the Node uploads automatically", "Treats it as the private invitation", "Assumes any address is verified as controlled"],
        ))
    else:
        tasks.append(_task(
            "public-address-unavailable",
            "Explain what is missing without a public source-list address",
            "Ask whether preparing the private handoff also publishes a durable public source list.",
            "They say no durable public source-list address is configured and the Node will not invent, upload, or host one automatically.",
            ["Expects automatic hosting", "Treats the private invitation as the public source list", "Assumes an address will appear later"],
        ))

    if scenario_core["artifacts"]["staticSite"]:
        tasks.append(_task(
            "static-package",
            "Explain the static publication package",
            "Ask what downloading the ready-to-host package does.",
            "They say it downloads local script-free publication files for deliberate hosting; it does not publish, pair, or change the library.",
            ["Says the package is already hosted", "Expects a background upload", "Thinks downloading it changes recipient access"],
        ))
    else:
        tasks.append(_task(
            "static-package-unavailable",
            "Explain why no static publication package is available",
            "Ask whether the private handoff also created a ready-to-host public site package.",
            "They say this preview has no static publication package and the Node will not generate or host one silently.",
            ["Assumes a package was created", "Expects a background upload", "Treats the invitation as a hosted publication"],
        ))

    tasks.extend([
        _task(
            "create-handoff",
            "Explain Create 30-minute handoff",
            "Ask what becomes available after creating the handoff.",
            "They say one expiring, revocable artifact invitation is created; it is not public hosting, Node administration, pairing, or synchronization.",
            ["Calls it permanent publication", "Calls it administrator access", "Expects continuous synchronization"],
        ),
        _task(
            "recipient-binding",
            "Explain who can review the invitation",
            "Ask what happens when the first compatible Extension reviews the invitation.",
            "They say the invitation becomes bound to that exact Extension Origin for its remaining lifetime rather than becoming a public bearer page.",
            ["Expects arbitrary websites to use it", "Calls it a sender login", "Assumes every browser can reuse it after review"],
        ),
        _task(
            "expiry-revocation",
            "Explain expiry and revocation",
            "Ask what expiry or revocation can and cannot do.",
            "They say it stops future invitation retrieval; it does not erase artifacts already downloaded or material a recipient already adopted locally.",
            ["Expects remote erasure", "Calls revocation a library rollback", "Assumes adopted material stays synchronized"],
        ),
        _task(
            "network-and-schedule",
            "Explain network and scheduling effects",
            "Ask whether preparation or handoff creation contacts listed feeds and pages or creates recurring checks.",
            "They say neither step contacts the listed sources or creates a schedule.",
            ["Believes every listed site was checked", "Expects browser permissions to transfer", "Expects Pulse to start"],
        ),
        _task(
            "recipient-privacy",
            "Explain what the sender can learn about the recipient",
            "Ask whether the invitation lets the sender inspect the recipient's library, reading state, or browser session.",
            "They say it grants no recipient-library visibility, reading-history access, browser session access, or administrator relationship.",
            ["Expects recipient analytics", "Expects library access", "Expects browser-session visibility"],
        ),
        _task(
            "advanced-evidence",
            "Find exact contents and artifact evidence only when asked",
            "Ask the sender to find bounded source and folder contents plus artifact sizes and digests without making those details prerequisite vocabulary.",
            "They can inspect exact evidence when requested while still deciding from ordinary consequences and privacy boundaries.",
            ["Cannot find the evidence", "Feels required to interpret hashes before sharing", "Treats a digest as proof that every source is safe"],
        ),
        _task(
            "state-sender-boundary",
            "State the complete sender boundary",
            "Ask what has happened merely by preparing and reviewing the share.",
            "They say no upload, public posting, recipient delivery, source request, schedule, pairing, synchronization, or library write has occurred.",
            ["Says the link was already sent", "Says the route is already public", "Says the recipient now has access"],
        ),
    ])

    if len(tasks) > MAX_FIELDWORK_TASKS:
        raise FieldbookError("fieldwork task limit exceeded")

    return {
        "schema": FIELDWORK_KIT_SCHEMA,
        "scenario": EXCHANGE_SENDER_FIELDWORK_SCENARIO,
        "scenarioDigest": scenario_digest,
        "generatedAt": _text(generated_at, 80),
        "release": release,
        "presentation": {
            "eyebrow": "Private sender-study sidecar",
            "heading": "Know what leaves before you send the link.",
            "intro": (
                "This fieldbook accompanies the actual ProgRSS Node share review in another window. "
                "It is not a product simulation. Ask the sender to explain what will travel, what stays "
                "private, what the recipient can do, and what has not happened yet."
            ),
            "scenarioLabel": "Exchange sender fieldwork",
        },
        "context": scenario_core,
        "tasks": tasks,
        "outcomes": [
            {"value": "independent", "label": "Understood independently"},
            {"value": "neutral-prompt", "label": "Understood after a neutral prompt"},
            {"value": "wrong-turn", "label": "Wrong turn or unsafe interpretation"},
            {"value": "not-observed", "label": "Not observed"},
        ],
        "privacy": {
            "participantIdentityRequested": False,
            "sourceTitleIncluded": False,
            "sourceAddressIncluded": False,
            "selectorIncluded": False,
            "snapshotContentIncluded": False,
            "capabilityIncluded": False,
            "curatorIdentityIncluded": False,
            "routeTitleIncluded": False,
            "folderPathIncluded": False,
            "publicAddressIncluded": False,
            "libraryIdentityIncluded": False,
            "artifactDigestIncluded": False,
            "automaticPersistence": False,
            "network": False,
            "telemetry": False,
            "noteLimit": MAX_FIELDWORK_NOTE_CHARS,
        },
        "effects": {"network": False, "libraryWrites": False, "storeWrites": False},
    }


def _json_for_script(value: Any) -> str:
    # Prevent closing the application/json script element or injecting markup.
    return _canonical(value).replace("<", "\\u003c").replace("&", "\\u0026")


def render_fieldbook_html(scenario: Mapping[str, Any]) -> bytes:
    """Render one standalone, local-only facilitator fieldbook."""
    if scenario.get("schema") != FIELDWORK_KIT_SCHEMA:
        raise FieldbookError(f"expected {FIELDWORK_KIT_SCHEMA}")
    tasks = scenario.get("tasks")
    if not isinstance(tasks, list) or not tasks or len(tasks) > MAX_FIELDWORK_TASKS:
        raise FieldbookError("fieldwork scenario has an invalid task list")
    release = scenario.get("release") if isinstance(scenario.get("release"), Mapping) else {}
    version = html.escape(_text(release.get("version"), 40))
    revision = html.escape(_text(release.get("revision"), 40))
    codename = html.escape(_text(release.get("codename"), 60))
    digest = html.escape(_text(scenario.get("scenarioDigest"), 80))
    presentation = scenario.get("presentation") if isinstance(scenario.get("presentation"), Mapping) else {}
    eyebrow = html.escape(_text(presentation.get("eyebrow"), 100) or "Private facilitator sidecar")
    heading = html.escape(_text(presentation.get("heading"), 180) or "Test the wording, not the person.")
    intro = html.escape(_text(presentation.get("intro"), 700) or (
        "This fieldbook accompanies the actual ProgRSS interface in another window. "
        "It is not a product simulation. Record observable wrong turns, neutral prompts, "
        "and independent understanding without coaching the participant."
    ))
    scenario_label = html.escape(_text(presentation.get("scenarioLabel"), 160) or "ProgRSS fieldwork")
    scenario_json = _json_for_script(scenario)
    report_schema = FIELDWORK_REPORT_SCHEMA
    note_limit = MAX_FIELDWORK_NOTE_CHARS

    document = f'''<!doctype html>
<html lang="en" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="dark light">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src 'none'; font-src 'none'; connect-src 'none'; media-src 'none'; object-src 'none'; frame-src 'none'; form-action 'none'; base-uri 'none'">
<title>ProgRSS Fieldbook · {revision} {codename}</title>
<style>
:root{{--bg:#06070a;--panel:#0d1016;--raised:#151a23;--ink:#f4f7ff;--muted:#a8b0c0;--line:#2b3242;--cyan:#3ffcff;--pink:#ff49d9;--lime:#c8ff4a;--amber:#ffd166;--danger:#ff7b95;--shadow:0 20px 60px #0008;color-scheme:dark}}
:root[data-theme="light"]{{--bg:#f6f8fb;--panel:#fff;--raised:#f0f4f8;--ink:#111722;--muted:#596274;--line:#cbd3df;--cyan:#00767b;--pink:#a50078;--lime:#4e7000;--amber:#855900;--danger:#a31135;--shadow:0 18px 50px #1f2c401f;color-scheme:light}}
*{{box-sizing:border-box}}html{{background:var(--bg);color:var(--ink);font:16px/1.55 system-ui,-apple-system,Segoe UI,sans-serif}}body{{margin:0;background:radial-gradient(circle at 15% 0,color-mix(in srgb,var(--cyan) 8%,transparent),transparent 34%),radial-gradient(circle at 90% 16%,color-mix(in srgb,var(--pink) 7%,transparent),transparent 30%),var(--bg)}}button,input,textarea{{font:inherit}}button{{min-height:44px;border:1px solid var(--line);border-radius:12px;background:var(--raised);color:var(--ink);padding:.72rem 1rem;font-weight:750;cursor:pointer}}button:hover{{border-color:var(--cyan)}}button:focus-visible,input:focus-visible,textarea:focus-visible,summary:focus-visible{{outline:3px solid var(--cyan);outline-offset:3px}}button.primary{{background:linear-gradient(135deg,color-mix(in srgb,var(--cyan) 75%,#081014),color-mix(in srgb,var(--pink) 58%,#120914));border-color:color-mix(in srgb,var(--cyan) 65%,var(--line));color:#fff;box-shadow:0 0 24px color-mix(in srgb,var(--cyan) 20%,transparent)}}button.danger{{border-color:color-mix(in srgb,var(--danger) 50%,var(--line));color:var(--danger)}}button[disabled]{{opacity:.48;cursor:not-allowed}}a{{color:var(--cyan)}}header{{position:sticky;top:0;z-index:4;border-bottom:1px solid var(--line);background:color-mix(in srgb,var(--bg) 90%,transparent);backdrop-filter:blur(16px)}}.bar{{max-width:1120px;margin:auto;padding:14px 22px;display:flex;align-items:center;justify-content:space-between;gap:18px}}.brand{{display:flex;align-items:center;gap:12px}}.mark{{width:22px;height:22px;transform:rotate(45deg);border:2px solid var(--cyan);box-shadow:0 0 18px color-mix(in srgb,var(--cyan) 60%,transparent),inset 0 0 12px color-mix(in srgb,var(--pink) 45%,transparent)}}.brand strong{{letter-spacing:.03em}}.brand small{{display:block;color:var(--muted)}}main{{max-width:1120px;margin:auto;padding:34px 22px 80px}}.hero{{display:grid;grid-template-columns:minmax(0,1.4fr) minmax(260px,.6fr);gap:18px;align-items:stretch}}.card{{border:1px solid var(--line);border-radius:18px;background:linear-gradient(145deg,color-mix(in srgb,var(--cyan) 3%,var(--panel)),color-mix(in srgb,var(--pink) 3%,var(--panel)));box-shadow:var(--shadow);padding:22px}}.eyebrow{{margin:0 0 8px;color:var(--cyan);font-size:.72rem;font-weight:900;letter-spacing:.12em;text-transform:uppercase}}h1{{margin:.1rem 0 .7rem;font-size:clamp(2rem,5vw,4rem);line-height:1.02}}h2{{margin:0 0 .55rem;font-size:1.35rem}}h3{{margin:.1rem 0 .5rem;font-size:1.05rem}}p{{max-width:76ch}}.muted{{color:var(--muted)}}.boundary{{display:grid;gap:10px}}.boundary article{{padding:13px;border:1px solid var(--line);border-radius:13px;background:var(--raised)}}.boundary strong{{display:block;color:var(--lime)}}.boundary p{{margin:4px 0 0;color:var(--muted);font-size:.88rem}}.setup{{margin-top:18px}}.check{{display:flex;gap:10px;align-items:flex-start;margin:10px 0;padding:11px;border:1px solid var(--line);border-radius:12px;background:var(--raised)}}.check input{{margin-top:.3rem;inline-size:1.2rem;block-size:1.2rem;accent-color:var(--cyan)}}.check span{{display:block}}.check small{{display:block;color:var(--muted)}}.progress-shell{{margin:24px 0 18px;padding:14px 16px;border:1px solid var(--line);border-radius:14px;background:var(--panel)}}.progress-row{{display:flex;justify-content:space-between;gap:14px}}progress{{width:100%;height:10px;margin-top:9px;accent-color:var(--cyan)}}.tasks{{display:grid;gap:14px}}fieldset{{min-width:0;margin:0;border:1px solid var(--line);border-radius:16px;background:var(--panel);padding:18px}}fieldset.complete{{border-color:color-mix(in srgb,var(--lime) 46%,var(--line));box-shadow:inset 3px 0 0 var(--lime)}}legend{{padding:0 .45rem;color:var(--ink);font-weight:850}}.task-number{{color:var(--pink);font-size:.72rem;letter-spacing:.08em;text-transform:uppercase}}.prompt{{margin:.3rem 0 .8rem;color:var(--muted)}}.outcomes{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}}.outcome{{display:flex;gap:9px;align-items:flex-start;padding:10px;border:1px solid var(--line);border-radius:11px;background:var(--raised)}}.outcome:has(input:checked){{border-color:var(--cyan);box-shadow:inset 0 0 0 1px var(--cyan)}}.outcome input{{margin-top:.25rem;accent-color:var(--cyan)}}label.note{{display:block;margin-top:12px;font-weight:700}}textarea{{display:block;width:100%;min-height:78px;margin-top:6px;resize:vertical;border:1px solid var(--line);border-radius:11px;background:var(--raised);color:var(--ink);padding:10px}}.note-help{{display:flex;justify-content:space-between;gap:12px;color:var(--muted);font-size:.76rem}}details{{margin-top:10px}}summary{{cursor:pointer;color:var(--cyan);font-weight:750}}.cue{{margin:9px 0 0;padding:11px;border-left:2px solid var(--lime);background:color-mix(in srgb,var(--lime) 4%,transparent)}}.wrong{{margin:8px 0 0;color:var(--muted)}}.actions{{display:flex;flex-wrap:wrap;gap:10px;margin-top:22px}}.review{{margin-top:24px}}.summary-grid{{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}}.metric{{padding:13px;border:1px solid var(--line);border-radius:13px;background:var(--raised)}}.metric strong{{display:block;font-size:1.45rem;color:var(--cyan)}}.metric span{{color:var(--muted);font-size:.78rem}}.review-list{{display:grid;gap:8px;margin:15px 0;padding:0;list-style:none}}.review-list li{{padding:11px;border:1px solid var(--line);border-radius:12px;background:var(--raised)}}.review-list small{{display:block;color:var(--muted)}}.privacy-review{{margin-top:15px;padding:14px;border:1px solid color-mix(in srgb,var(--amber) 50%,var(--line));border-radius:13px;background:color-mix(in srgb,var(--amber) 5%,var(--panel))}}.status{{min-height:1.7rem;margin-top:12px;color:var(--muted)}}.status.good{{color:var(--lime)}}.status.error{{color:var(--danger)}}code{{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;color:var(--cyan);overflow-wrap:anywhere}}footer{{max-width:1120px;margin:auto;padding:0 22px 50px;color:var(--muted);font-size:.8rem}}[hidden]{{display:none!important}}
@media(max-width:800px){{.hero{{grid-template-columns:1fr}}.outcomes,.summary-grid{{grid-template-columns:1fr}}.bar{{align-items:flex-start}}}}
@media(prefers-reduced-motion:reduce){{*,*::before,*::after{{scroll-behavior:auto!important;animation:none!important;transition:none!important}}}}
@media(forced-colors:active){{.card,fieldset,.outcome,.metric,.review-list li,.check,.boundary article{{border:1px solid CanvasText}}.mark{{box-shadow:none}}button.primary{{background:ButtonFace;color:ButtonText}}}}
@media print{{header,.screen-only,.actions,.status{{display:none!important}}body{{background:#fff;color:#000}}main{{max-width:none;padding:0}}.card,fieldset,.metric,.review-list li{{box-shadow:none;border:1px solid #777;background:#fff}}details{{display:block}}details>*{{display:block!important}}}}
</style>
</head>
<body>
<header><div class="bar"><div class="brand"><span class="mark" aria-hidden="true"></span><div><strong>ProgRSS Fieldbook</strong><small>{version} · {revision} · {codename}</small></div></div><button id="theme" type="button" aria-label="Use light theme">☼ Theme</button></div></header>
<main>
<section class="hero">
  <article class="card"><p class="eyebrow">{eyebrow}</p><h1>{heading}</h1><p>{intro}</p><p class="muted">Scenario <code>{digest[:16]}</code> · {scenario_label}.</p></article>
  <aside class="card boundary" aria-label="Fieldbook boundaries">
    <article><strong>No telemetry</strong><p>This file makes no network request and submits nothing.</p></article>
    <article><strong>No identity field</strong><p>A participant name, email address, or demographic profile is not requested.</p></article>
    <article><strong>No automatic saving</strong><p>Notes remain in memory until you explicitly download a local report.</p></article>
  </aside>
</section>
<section class="card setup" aria-labelledby="setup-heading">
  <p class="eyebrow">Before the session</p><h2 id="setup-heading">Establish the research boundary</h2>
  <label class="check"><input type="checkbox" data-setup="product"><span><strong>We are testing ProgRSS, not the participant.</strong><small>Wrong turns are evidence about wording and hierarchy.</small></span></label>
  <label class="check"><input type="checkbox" data-setup="privacy"><span><strong>I will avoid names and sensitive page content in notes.</strong><small>Paraphrase behavior; do not copy credentials, private article text, or health and financial information.</small></span></label>
  <label class="check"><input type="checkbox" data-setup="release"><span><strong>The exact release under study is open separately.</strong><small>This fieldbook must not replace interaction with the actual Node and, when applicable, the installed Extension.</small></span></label>
</section>
<section class="progress-shell" aria-labelledby="progress-heading"><div class="progress-row"><strong id="progress-heading">Session progress</strong><span id="progress-count">0 of 0 tasks coded</span></div><progress id="progress" max="1" value="0">0%</progress><div class="status" id="status" role="status" aria-live="polite"></div></section>
<section class="tasks" id="tasks" aria-label="Fieldwork tasks"></section>
<div class="actions screen-only"><button class="primary" id="review" type="button">Review local report</button><button id="print" type="button">Print blank or completed sheet</button><button class="danger" id="clear" type="button">Clear without saving</button></div>
<section class="card review" id="review-panel" aria-labelledby="review-heading" hidden>
  <p class="eyebrow">Review before export</p><h2 id="review-heading" tabindex="-1">What this local report contains</h2>
  <div class="summary-grid" id="summary-grid"></div>
  <ul class="review-list" id="review-list"></ul>
  <label class="check privacy-review"><input id="privacy-confirm" type="checkbox"><span><strong>I reviewed the notes for personal or sensitive information.</strong><small>The report is a local file. ProgRSS does not upload it.</small></span></label>
  <div class="actions"><button class="primary" id="download-json" type="button" disabled>Download JSON report</button><button id="download-md" type="button" disabled>Download Markdown report</button><button id="back" type="button">Return to tasks</button></div>
</section>
<script id="scenario" type="application/json">{scenario_json}</script>
<script>
'use strict';
(() => {{
  const scenario = JSON.parse(document.getElementById('scenario').textContent);
  const tasksRoot = document.getElementById('tasks');
  const status = document.getElementById('status');
  const progress = document.getElementById('progress');
  const progressCount = document.getElementById('progress-count');
  const reviewPanel = document.getElementById('review-panel');
  const noteLimit = {note_limit};
  let reviewed = false;
  let exported = false;
  const clean = value => String(value == null ? '' : value).replace(/\\s+/g, ' ').trim();
  const node = (tag, attrs = {{}}, children = []) => {{
    const el = document.createElement(tag);
    Object.entries(attrs).forEach(([key, value]) => {{
      if (value == null || value === false) return;
      if (key === 'text') el.textContent = value;
      else if (key === 'class') el.className = value;
      else el.setAttribute(key, String(value));
    }});
    (Array.isArray(children) ? children : [children]).forEach(child => child != null && el.append(child.nodeType ? child : document.createTextNode(String(child))));
    return el;
  }};
  function taskState(task) {{
    const outcome = document.querySelector(`input[name="outcome-${{task.id}}"]:checked`)?.value || '';
    const notes = document.getElementById(`notes-${{task.id}}`).value.trim().slice(0, noteLimit);
    return {{id: task.id, title: task.title, outcome, notes}};
  }}
  function allStates() {{ return scenario.tasks.map(taskState); }}
  function updateProgress(announce = false) {{
    const states = allStates();
    const completed = states.filter(row => row.outcome).length;
    progress.max = states.length; progress.value = completed;
    progress.textContent = `${{Math.round(completed / states.length * 100)}}%`;
    progressCount.textContent = `${{completed}} of ${{states.length}} tasks coded`;
    scenario.tasks.forEach(task => document.getElementById(`task-${{task.id}}`).classList.toggle('complete', Boolean(taskState(task).outcome)));
    reviewed = false; exported = false; reviewPanel.hidden = true;
    if (announce) status.textContent = completed === states.length ? 'All tasks have an outcome. Review the report before downloading.' : 'Outcome recorded locally.';
  }}
  function renderTasks() {{
    tasksRoot.replaceChildren(...scenario.tasks.map((task, index) => {{
      const fieldset = node('fieldset', {{id: `task-${{task.id}}`}});
      fieldset.append(node('legend', {{}}, [node('span', {{class:'task-number', text:`Task ${{index + 1}}`}}), document.createTextNode(` · ${{task.title}}`)]));
      fieldset.append(node('p', {{class:'prompt', text:task.prompt}}));
      const outcomes = node('div', {{class:'outcomes'}});
      scenario.outcomes.forEach(outcome => {{
        const input = node('input', {{type:'radio', name:`outcome-${{task.id}}`, value:outcome.value, id:`${{task.id}}-${{outcome.value}}`}});
        input.addEventListener('change', () => updateProgress(true));
        outcomes.append(node('label', {{class:'outcome', for:input.id}}, [input, node('span', {{text:outcome.label}})]));
      }});
      fieldset.append(outcomes);
      const textarea = node('textarea', {{id:`notes-${{task.id}}`, maxlength:String(noteLimit), 'aria-describedby':`help-${{task.id}}`}});
      const count = node('span', {{text:`0/${{noteLimit}}`}});
      textarea.addEventListener('input', () => {{ count.textContent = `${{textarea.value.length}}/${{noteLimit}}`; reviewed = false; exported = false; reviewPanel.hidden = true; }});
      fieldset.append(node('label', {{class:'note', for:textarea.id}}, ['Observed behavior or neutral prompt', textarea]));
      fieldset.append(node('div', {{class:'note-help', id:`help-${{task.id}}`}}, [node('span', {{text:'Avoid names and sensitive content.'}}), count]));
      const detail = node('details');
      detail.append(node('summary', {{text:'Facilitator cue — open after the participant responds'}}));
      detail.append(node('p', {{class:'cue', text:task.successSignal}}));
      if (task.wrongTurns?.length) detail.append(node('p', {{class:'wrong', text:`Watch for: ${{task.wrongTurns.join(' · ')}}`}}));
      fieldset.append(detail);
      return fieldset;
    }}));
    updateProgress(false);
  }}
  function summarize(states) {{
    const counts = Object.fromEntries(scenario.outcomes.map(row => [row.value, 0]));
    states.forEach(row => {{ if (row.outcome in counts) counts[row.outcome] += 1; }});
    return counts;
  }}
  function review() {{
    const setup = [...document.querySelectorAll('[data-setup]')];
    if (setup.some(row => !row.checked)) {{ status.textContent = 'Complete the three research-boundary checks before reviewing the report.'; status.className = 'status error'; setup.find(row => !row.checked)?.focus(); return; }}
    const states = allStates();
    if (states.some(row => !row.outcome)) {{ status.textContent = 'Give every task an outcome. Use Not observed when a task was not run.'; status.className = 'status error'; document.querySelector('fieldset:not(.complete) input')?.focus(); return; }}
    const counts = summarize(states);
    const grid = document.getElementById('summary-grid');
    grid.replaceChildren(...scenario.outcomes.map(outcome => node('article', {{class:'metric'}}, [node('strong', {{text:String(counts[outcome.value])}}), node('span', {{text:outcome.label}})])));
    const list = document.getElementById('review-list');
    list.replaceChildren(...states.map((row, index) => node('li', {{}}, [node('strong', {{text:`${{index + 1}}. ${{row.title}} — ${{scenario.outcomes.find(o => o.value === row.outcome)?.label || row.outcome}}`}}), row.notes ? node('small', {{text:row.notes}}) : node('small', {{text:'No note recorded.'}})])));
    document.getElementById('privacy-confirm').checked = false;
    document.getElementById('download-json').disabled = true;
    document.getElementById('download-md').disabled = true;
    reviewPanel.hidden = false; reviewed = true;
    reviewPanel.scrollIntoView({{block:'start'}}); document.getElementById('review-heading').focus();
    status.textContent = 'Report assembled in memory. Review notes and confirm privacy before downloading.'; status.className = 'status good';
  }}
  function report() {{
    const states = allStates();
    return {{
      schema: '{report_schema}', scenario: scenario.scenario, scenarioDigest: scenario.scenarioDigest,
      release: scenario.release, generatedFromKitAt: scenario.generatedAt,
      completedAt: new Date().toISOString(), outcomes: summarize(states), tasks: states,
      facilitatorBoundary: {{testedProductNotParticipant:true, avoidedSensitiveNotes:true, exactReleaseOpen:true}},
      privacy: {{participantIdentityRecorded:false, automaticPersistence:false, telemetry:false, network:false}},
    }};
  }}
  function download(filename, type, content) {{
    const url = URL.createObjectURL(new Blob([content], {{type}}));
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = filename; document.body.append(anchor); anchor.click(); anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000); exported = true;
    status.textContent = `${{filename}} downloaded locally. ProgRSS uploaded nothing.`; status.className = 'status good';
  }}
  function markdown(data) {{
    const lines = [`# ProgRSS fieldwork report`, ``, `- Schema: ${{data.schema}}`, `- Release: ${{data.release.version}} / ${{data.release.revision}} / ${{data.release.codename}}`, `- Scenario: ${{data.scenario}}`, `- Scenario digest: ${{data.scenarioDigest}}`, `- Completed: ${{data.completedAt}}`, ``, `## Outcome counts`];
    scenario.outcomes.forEach(outcome => lines.push(`- ${{outcome.label}}: ${{data.outcomes[outcome.value] || 0}}`));
    lines.push('', '## Tasks');
    data.tasks.forEach((row, index) => {{ lines.push('', `### ${{index + 1}}. ${{row.title}}`, `- Outcome: ${{scenario.outcomes.find(o => o.value === row.outcome)?.label || row.outcome}}`, `- Notes: ${{row.notes || 'None recorded.'}}`); }});
    lines.push('', '## Privacy boundary', '- No participant identity field was present.', '- No automatic persistence or telemetry was used.', '- Review notes before sharing this local file.');
    return lines.join('\\n') + '\\n';
  }}
  document.getElementById('theme').addEventListener('click', event => {{
    const light = document.documentElement.dataset.theme !== 'light'; document.documentElement.dataset.theme = light ? 'light' : 'dark';
    event.currentTarget.textContent = light ? '☾ Theme' : '☼ Theme'; event.currentTarget.setAttribute('aria-label', light ? 'Use dark theme' : 'Use light theme');
  }});
  document.getElementById('review').addEventListener('click', review);
  document.getElementById('print').addEventListener('click', () => window.print());
  document.getElementById('back').addEventListener('click', () => {{ reviewPanel.hidden = true; document.getElementById('review').focus(); }});
  document.getElementById('privacy-confirm').addEventListener('change', event => {{
    document.getElementById('download-json').disabled = !event.target.checked;
    document.getElementById('download-md').disabled = !event.target.checked;
  }});
  document.getElementById('download-json').addEventListener('click', () => {{ const data = report(); download(`progrss-fieldwork-${{scenario.scenarioDigest.slice(0,12)}}.json`, 'application/json', JSON.stringify(data, null, 2) + '\\n'); }});
  document.getElementById('download-md').addEventListener('click', () => {{ const data = report(); download(`progrss-fieldwork-${{scenario.scenarioDigest.slice(0,12)}}.md`, 'text/markdown;charset=utf-8', markdown(data)); }});
  document.getElementById('clear').addEventListener('click', () => {{
    if (!confirm('Clear every outcome and note without saving?')) return;
    document.querySelectorAll('input[type=radio],input[data-setup],#privacy-confirm').forEach(row => {{ row.checked = false; }});
    document.querySelectorAll('textarea').forEach(row => {{ row.value = ''; }});
    reviewPanel.hidden = true; status.textContent = 'Session cleared. Nothing was saved or uploaded.'; status.className = 'status'; reviewed = false; exported = false; renderTasks();
  }});
  window.addEventListener('beforeunload', event => {{
    if (exported) return;
    const hasWork = allStates().some(row => row.outcome || row.notes) || [...document.querySelectorAll('[data-setup]')].some(row => row.checked);
    if (hasWork) {{ event.preventDefault(); event.returnValue = ''; }}
  }});
  renderTasks();
}})();
</script>
</main>
<footer><p>Private local facilitator sidecar · no telemetry · no automatic persistence · no participant identity field · scenario <code>{digest}</code></p></footer>
</body>
</html>
'''
    return document.encode("utf-8")
