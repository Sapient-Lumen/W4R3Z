#!/usr/bin/env python3
"""Read-only ProgRSS exchange artifact preparation.

This module turns one explicit folder in a private ProgRSS backup state into a
bounded source-list handoff. It never mutates the supplied state and performs no
network access. A durable recent-updates choice is offered only when the curator
supplies the public source-list URL used by the existing static publisher.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass
import hashlib
import json
from pathlib import PurePosixPath
from typing import Any, Mapping
from urllib.parse import urlsplit, urlunsplit

from relay import (
    BUNDLE_MEDIA_TYPE,
    EDITION_FILE,
    FEED_MEDIA_TYPE,
    RelayError,
    build_publication_site,
    bundle_contents,
    make_bundle,
    publication_site_files,
)

EXCHANGE_SCHEMA = "progrss.node.exchange.v1"
EXCHANGE_PREVIEW_SCHEMA = "progrss.node.exchange-preview.v1"
MAX_EXCHANGE_NOTE = 280
MAX_EXCHANGE_CURATOR = 80
MAX_EXCHANGE_SOURCES_SHOWN = 40
MAX_EXCHANGE_FOLDERS_SHOWN = 30


class ExchangeError(Exception):
    """Expected local exchange preparation failure."""


@dataclass(slots=True)
class PreparedExchange:
    preview: dict[str, Any]
    source_list: bytes
    source_list_name: str
    recent_updates: bytes | None
    recent_updates_name: str
    site_zip: bytes | None
    site_zip_name: str

    def artifacts(self) -> dict[str, tuple[str, str, bytes]]:
        rows = {
            "source-list": (self.source_list_name, BUNDLE_MEDIA_TYPE, self.source_list),
        }
        if self.recent_updates is not None:
            rows["recent-updates"] = (self.recent_updates_name, FEED_MEDIA_TYPE, self.recent_updates)
        if self.site_zip is not None:
            rows["site"] = (self.site_zip_name, "application/zip", self.site_zip)
        return rows


def _clean_text(value: Any, limit: int) -> str:
    return " ".join(str(value or "").split())[:limit]


def _json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _public_addresses(update_url: str) -> tuple[str, str, str]:
    """Return source-list URL, publication page URL, and recent-updates URL."""
    parsed = urlsplit(update_url)
    path = PurePosixPath(parsed.path or "/")
    parent = str(path.parent)
    if not parent.endswith("/"):
        parent += "/"
    page_url = urlunsplit((parsed.scheme, parsed.netloc, parent, "", ""))
    feed_url = urlunsplit((parsed.scheme, parsed.netloc, parent + EDITION_FILE, "", ""))
    return update_url, page_url, feed_url


def _folder_edition(
    state: dict[str, Any],
    selector: str,
    *,
    curator: str,
    note: str,
    generated_at: str,
) -> tuple[dict[str, Any], dict[str, Any]]:
    # Import lazily so node_server can remain importable from the ProgRSS CLI
    # without creating an import cycle at module initialization time.
    from progrss import ProgRSSError, folder_edition_document

    try:
        return folder_edition_document(
            state,
            selector,
            curator=curator,
            note=note,
            generated_at=generated_at,
        )
    except ProgRSSError as exc:
        raise ExchangeError(str(exc)) from exc


def prepare_exchange(
    state: Mapping[str, Any],
    selector: str,
    *,
    library_file: str,
    library_sha256: str,
    curator: str = "",
    note: str = "",
    public_update_url: str = "",
    include_recent_updates: bool = True,
    generated_at: str,
) -> PreparedExchange:
    """Prepare one immutable source-list handoff from a private state copy.

    The function performs no network access and does not mutate ``state``.
    ``public_update_url`` is optional. Without it, the handoff still supports
    complete-route and branch adoption, but cannot honestly offer a durable feed
    to follow or a ready-to-host publication package.
    """
    curator = _clean_text(curator, MAX_EXCHANGE_CURATOR)
    note = _clean_text(note, MAX_EXCHANGE_NOTE)
    update_url = _clean_text(public_update_url, 4096)
    working = copy.deepcopy(dict(state))
    try:
        bundle = make_bundle(
            working,
            selector,
            curator=curator,
            note=note,
            update_url=update_url,
            exported_at=generated_at,
        )
        contents = bundle_contents(bundle)
    except RelayError as exc:
        raise ExchangeError(str(exc)) from exc

    source_list = _json_bytes(bundle)
    source_list_name = "progrss-source-list.json"
    edition_document: dict[str, Any] | None = None
    edition_report: dict[str, Any] | None = None
    if include_recent_updates:
        edition_document, edition_report = _folder_edition(
            working,
            selector,
            curator=curator,
            note=note,
            generated_at=generated_at,
        )

    recent_updates: bytes | None = _json_bytes(edition_document) if edition_document else None
    site_zip: bytes | None = None
    site_summary: dict[str, Any] | None = None
    page_url = ""
    feed_url = ""
    if update_url:
        _source_url, page_url, feed_url = _public_addresses(update_url)
        try:
            files = publication_site_files(bundle, edition_document)
            site_zip, site_summary = build_publication_site(bundle, edition_document)
        except RelayError as exc:
            raise ExchangeError(str(exc)) from exc
        source_candidates = [
            (name, data)
            for name, data in files.items()
            if name.endswith(".json") and name != EDITION_FILE
        ]
        if len(source_candidates) != 1:
            raise ExchangeError("the publication package did not contain exactly one source-list JSON file")
        source_list_name, source_list = source_candidates[0]
        recent_updates = files.get(EDITION_FILE)

    artifacts: dict[str, Any] = {
        "sourceList": {
            "available": True,
            "name": source_list_name,
            "bytes": len(source_list),
            "sha256": _sha256(source_list),
            "mediaType": BUNDLE_MEDIA_TYPE,
        },
        "recentUpdates": {
            "available": recent_updates is not None,
            "name": EDITION_FILE if recent_updates is not None else "",
            "bytes": len(recent_updates or b""),
            "sha256": _sha256(recent_updates) if recent_updates is not None else "",
            "mediaType": FEED_MEDIA_TYPE if recent_updates is not None else "",
        },
        "site": {
            "available": site_zip is not None,
            "name": "progrss-publication-site.zip" if site_zip is not None else "",
            "bytes": len(site_zip or b""),
            "sha256": _sha256(site_zip) if site_zip is not None else "",
            "mediaType": "application/zip" if site_zip is not None else "",
        },
    }

    sources = list(contents.get("sources") or [])[:MAX_EXCHANGE_SOURCES_SHOWN]
    folders = list(contents.get("folders") or [])[:MAX_EXCHANGE_FOLDERS_SHOWN]
    branch_choices = [
        row for row in folders
        if not row.get("isRoot") and int(row.get("branchSources") or 0) > 0
    ]
    follow_available = bool(update_url and recent_updates and edition_report and int(edition_report.get("items") or 0) >= 0)
    preview: dict[str, Any] = {
        "schema": EXCHANGE_PREVIEW_SCHEMA,
        "state": "preview",
        "generatedAt": generated_at,
        "library": {
            "file": library_file,
            "sha256": library_sha256,
        },
        "title": _clean_text(contents.get("title"), 180) or "Shared source route",
        "curator": curator,
        "note": note,
        "folder": {
            "id": _clean_text(contents.get("root"), 300),
            "path": _clean_text(contents.get("title"), 300),
        },
        "counts": {
            "sources": int(contents.get("sourceCount") or 0),
            "feeds": int(contents.get("feedCount") or 0),
            "pageWatches": int(contents.get("pageWatchCount") or 0),
            "folders": int(contents.get("folderCount") or 0),
            "sourceNotes": int(contents.get("sourceNoteCount") or 0),
            "recentUpdates": int((edition_report or {}).get("items") or 0),
        },
        "contents": {
            "sources": sources,
            "folders": folders,
            "sourcesOmitted": max(0, int(contents.get("sourceCount") or 0) - len(sources)),
            "foldersOmitted": max(0, int(contents.get("folderCount") or 0) - len(folders)),
        },
        "choices": {
            "followUpdates": {
                "available": follow_available,
                "feedUrl": feed_url if follow_available else "",
                "reason": "" if follow_available else (
                    "Add the public source-list address to make recent updates a durable feed."
                    if recent_updates is not None else
                    "This folder has no recent-updates artifact."
                ),
            },
            "addRoute": {"available": True},
            "takeBranch": {
                "available": bool(branch_choices),
                "branches": [
                    {
                        "id": _clean_text(row.get("id"), 300),
                        "path": _clean_text(row.get("path"), 300),
                        "sources": int(row.get("branchSources") or 0),
                        "feeds": int(row.get("branchFeeds") or 0),
                        "pageWatches": int(row.get("branchPageWatches") or 0),
                        "sourceNotes": int(row.get("branchSourceNotes") or 0),
                    }
                    for row in branch_choices
                ],
            },
        },
        "public": {
            "sourceListUrl": update_url,
            "pageUrl": page_url,
            "feedUrl": feed_url if follow_available else "",
        },
        "privacy": {
            "included": [
                "source recipes",
                "simple folder routes",
                "curator-written reasons on direct folder/source placements",
                "curator wording",
                "bounded recent-update summaries when selected",
            ],
            "excluded": [
                "read and unread state",
                "saved state",
                "full retained article text",
                "page-watch snapshots and comparison evidence",
                "browser permissions and cookies",
                "private signing keys",
            ],
        },
        "artifacts": artifacts,
        "siteSummary": site_summary,
        "network": False,
        "writes": False,
        "automatic": False,
    }
    digest_payload = copy.deepcopy(preview)
    digest_payload.pop("previewDigest", None)
    preview["previewDigest"] = _sha256(
        json.dumps(digest_payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    )
    return PreparedExchange(
        preview=preview,
        source_list=source_list,
        source_list_name=source_list_name,
        recent_updates=recent_updates,
        recent_updates_name=EDITION_FILE if recent_updates is not None else "",
        site_zip=site_zip,
        site_zip_name="progrss-publication-site.zip" if site_zip is not None else "",
    )
