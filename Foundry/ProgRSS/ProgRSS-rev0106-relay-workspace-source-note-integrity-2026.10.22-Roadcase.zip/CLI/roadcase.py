#!/usr/bin/env python3
"""Build and verify the deterministic ProgRSS native-fieldwork Roadcase packet.

The Roadcase is a separate local packet. It contains trusted release bytes,
synthetic fixtures, browser-install instructions, verification, preparation,
and cleanup helpers. It performs no network request while it is built or
verified and stores no participant identity.
"""
from __future__ import annotations

import hashlib
import html
import json
import os
from pathlib import Path
import shutil
import stat
import tempfile
from typing import Any, Iterable
import zipfile

ROADCASE_SCHEMA = "progrss.roadcase.v1"
ROADCASE_MANIFEST_SCHEMA = "progrss.roadcase.manifest.v1"
ROADCASE_VERIFY_SCHEMA = "progrss.roadcase.verify.v1"
ROADCASE_DATE = "2026-10-20"
ROADCASE_GENERATED_AT = "2026-10-20T23:50:00Z"
ROADCASE_ZIP_TIME = (2026, 10, 20, 23, 50, 0)
MAX_PACKET_FILES = 2_000
MAX_PACKET_BYTES = 80_000_000
ALLOWED_MUTABLE_PREFIXES = ("work/",)
IGNORED_RUNTIME_NAMES = {".DS_Store", "Thumbs.db", "desktop.ini"}


class RoadcaseError(ValueError):
    """Expected, human-readable Roadcase failure."""


def _sha256_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def _display_json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def _safe_member_name(name: str) -> str:
    normalized = name.replace("\\", "/").lstrip("/")
    parts = normalized.split("/")
    if not normalized or normalized.endswith("/") or any(part in {"", ".", ".."} for part in parts):
        raise RoadcaseError(f"unsafe Roadcase member path: {name}")
    return normalized


def _file_mode(path: Path, relative: str) -> int:
    mode = stat.S_IMODE(path.stat().st_mode)
    if mode & 0o111:
        return 0o755
    if relative.startswith("scripts/") and path.suffix in {".py", ".sh"}:
        return 0o755
    if relative.endswith(("/progrss", "/progrss-core")):
        return 0o755
    return 0o644


def _copy_tree(source: Path, destination: Path, *, excluded_names: set[str] | None = None) -> None:
    excluded_names = excluded_names or set()
    if not source.is_dir():
        raise RoadcaseError(f"required release directory is missing: {source}")
    for path in sorted(source.rglob("*"), key=lambda row: row.as_posix()):
        rel = path.relative_to(source)
        if any(part in excluded_names for part in rel.parts):
            continue
        if path.is_symlink():
            raise RoadcaseError(f"symlinks are not permitted in Roadcase input: {path}")
        target = destination / rel
        if path.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        elif path.is_file():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
            os.chmod(target, _file_mode(path, rel.as_posix()))


def _synthetic_backup(release: dict[str, str]) -> dict[str, Any]:
    """Return a synthetic private library used only for local fieldwork."""
    return {
        "schema": "progrss.private.v1",
        "exportedAt": ROADCASE_GENERATED_AT,
        "state": {
            "version": 17,
            "sources": [
                {
                    "id": "feed-community",
                    "title": "Synthetic community bulletin",
                    "type": "rss",
                    "url": "https://community.example.test/feed.json",
                    "enabled": False,
                    "archivedAt": "",
                    "createdAt": "2026-10-20T20:00:00Z",
                    "mode": "region",
                    "selector": "",
                    "titleSelector": "",
                    "linkSelector": "",
                    "include": "",
                    "exclude": "",
                    "threshold": 1,
                    "ignoreNumbers": False,
                    "version": 1,
                    "author": "Roadcase fixture",
                },
                {
                    "id": "feed-council",
                    "title": "Synthetic council agenda",
                    "type": "rss",
                    "url": "https://council.example.test/agenda.xml",
                    "enabled": False,
                    "archivedAt": "",
                    "createdAt": "2026-10-20T20:01:00Z",
                    "mode": "region",
                    "selector": "",
                    "titleSelector": "",
                    "linkSelector": "",
                    "include": "",
                    "exclude": "",
                    "threshold": 1,
                    "ignoreNumbers": False,
                    "version": 1,
                    "author": "Roadcase fixture",
                },
                {
                    "id": "page-virtual-window",
                    "title": "Synthetic virtualized notices",
                    "type": "page",
                    "url": "http://127.0.0.1:43162/virtual-window.html",
                    "enabled": False,
                    "archivedAt": "",
                    "createdAt": "2026-10-20T20:02:00Z",
                    "mode": "cards",
                    "selector": ".notice",
                    "titleSelector": "h2",
                    "linkSelector": "a",
                    "include": "",
                    "exclude": "",
                    "threshold": 1,
                    "ignoreNumbers": True,
                    "version": 1,
                    "author": "Roadcase fixture",
                },
            ],
            "collections": [
                {
                    "id": "folder-roadcase",
                    "title": "Roadcase local signal",
                    "mode": "union",
                    "include": "",
                    "exclude": "",
                    "version": 1,
                    "author": "Roadcase fixture",
                    "members": [
                        {"kind": "source", "id": "feed-community"},
                        {"kind": "collection", "id": "folder-meetings"},
                    ],
                },
                {
                    "id": "folder-meetings",
                    "title": "Meetings and notices",
                    "mode": "union",
                    "include": "",
                    "exclude": "",
                    "version": 1,
                    "author": "Roadcase fixture",
                    "members": [
                        {"kind": "source", "id": "feed-council"},
                        {"kind": "source", "id": "page-virtual-window"},
                    ],
                },
            ],
            "items": [
                {
                    "id": "feed-community|roadcase-1",
                    "entryKey": "feed-community|roadcase-1",
                    "feedRevision": 0,
                    "sourceId": "feed-community",
                    "title": "Synthetic cooling-room hours",
                    "url": "https://community.example.test/roadcase/cooling",
                    "summary": "A synthetic retained item for local fieldwork.",
                    "published": "2026-10-20T18:00:00Z",
                    "observedAt": "2026-10-20T18:05:00Z",
                    "kind": "new",
                    "readAt": "",
                    "starred": False,
                    "language": "en",
                },
                {
                    "id": "feed-council|roadcase-1",
                    "entryKey": "feed-council|roadcase-1",
                    "feedRevision": 0,
                    "sourceId": "feed-council",
                    "title": "Synthetic transit agenda",
                    "url": "https://council.example.test/roadcase/transit",
                    "summary": "A second synthetic retained item.",
                    "published": "2026-10-20T17:00:00Z",
                    "observedAt": "2026-10-20T17:05:00Z",
                    "kind": "new",
                    "readAt": "",
                    "starred": True,
                    "language": "en",
                },
            ],
            "snapshots": {},
            "fixtures": [], "inbox": [], "receipts": [], "subscriptions": [],
            "publications": [], "patchPins": [], "keyRotations": [],
            "recoveryPolicies": [], "recoveryReceipts": [], "charterHistory": [],
            "charterClaims": [], "gossipCards": [], "witnessPins": [],
            "merklePins": [], "merkleReceipts": [], "proofRequests": [],
            "proofSightings": [], "proofForks": [], "fixturePacks": [],
        },
        "producer": {"name": "ProgRSS Roadcase", **release},
    }


def _virtual_window_html() -> bytes:
    document = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ProgRSS Roadcase · synthetic virtual window</title>
<style>
:root{color-scheme:dark;background:#07080b;color:#f6f7ff;font:17px/1.55 system-ui,sans-serif}
body{max-width:940px;margin:auto;padding:32px}header{border-block:1px solid #33f5ff;padding:22px 0;margin-bottom:24px}
h1{font-size:clamp(2rem,7vw,4.8rem);line-height:.9;margin:.15em 0;background:linear-gradient(90deg,#33f5ff,#ff4fd8,#d9ff56);-webkit-background-clip:text;color:transparent}
button{font:inherit;color:inherit;background:#10131b;border:1px solid #33f5ff;border-radius:999px;padding:.7rem 1rem;margin:.25rem;cursor:pointer}button:focus{outline:3px solid #d9ff56;outline-offset:3px}
#window{display:grid;gap:14px;margin-top:24px}.notice{padding:18px;border:1px solid #3a4050;border-left:4px solid #ff4fd8;background:#0d1016;border-radius:12px}.notice h2{margin:.1rem 0}.notice a{color:#33f5ff}.meta{color:#b8c0d0}.warning{border:1px solid #d9ff56;padding:14px;border-radius:10px;background:#151807}
@media(prefers-reduced-motion:no-preference){.notice{animation:in .25s ease both}@keyframes in{from{opacity:.1;transform:translateY(6px)}}}
</style>
</head>
<body>
<header><p class="meta">Local synthetic fixture · no remote resources</p><h1>A moving rendered window</h1><p>This page deliberately recycles one four-card DOM window. It exists only to test Capture, Drift, Bearing, Trace, and Anchor language.</p></header>
<div class="warning" role="note">The logical collection has 500 records, but only four are rendered at a time. Switching windows does not mean the earlier records were deleted.</div>
<nav aria-label="Synthetic window controls">
<button id="first" type="button">Show records 41–44</button>
<button id="later" type="button">Show records 145–148</button>
</nav>
<p id="status" role="status" aria-live="polite">Showing records 41–44 of 500.</p>
<main id="window" role="feed" aria-busy="false" aria-setsize="500"></main>
<script>
(() => {
 const root=document.getElementById('window'),status=document.getElementById('status');
 function show(start){root.setAttribute('aria-busy','true');root.replaceChildren();
  for(let n=start;n<start+4;n++){const article=document.createElement('article');article.className='notice';article.setAttribute('aria-posinset',String(n));article.setAttribute('aria-setsize','500');article.innerHTML=`<h2>Roadcase notice ${n}</h2><p>Synthetic rendered record ${n}. No personal or remote data.</p><a href="/records/${n}">Open synthetic record ${n}</a>`;root.append(article)}
  root.setAttribute('aria-busy','false');status.textContent=`Showing records ${start}–${start+3} of 500.`;}
 document.getElementById('first').addEventListener('click',()=>show(41));
 document.getElementById('later').addEventListener('click',()=>show(145));show(41);
})();
</script>
</body></html>'''
    return document.encode("utf-8")


def _start_html(release: dict[str, str]) -> bytes:
    version = html.escape(release["version"])
    revision = html.escape(release["revision"])
    codename = html.escape(release["codename"])
    doc = f'''<!doctype html>
<html lang="en" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src 'self' data:; connect-src 'none'; form-action 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'">
<title>ProgRSS Roadcase · native fieldwork packet</title>
<style>
:root{{--bg:#07080b;--panel:#0d1017;--text:#f5f7ff;--muted:#aeb8ca;--line:#30394a;--cyan:#35f2ff;--pink:#ff55d9;--lime:#d9ff57;--danger:#ff8c9f;color-scheme:dark}}
:root[data-theme="light"]{{--bg:#f7f8fb;--panel:#fff;--text:#111521;--muted:#566071;--line:#cdd4df;--cyan:#006d78;--pink:#a30c77;--lime:#486900;color-scheme:light}}
*{{box-sizing:border-box}}body{{margin:0;background:radial-gradient(circle at 92% 2%,color-mix(in srgb,var(--pink) 16%,transparent),transparent 25%),var(--bg);color:var(--text);font:16px/1.55 system-ui,sans-serif}}main{{width:min(1120px,calc(100% - 32px));margin:auto;padding:30px 0 70px}}header{{padding:28px 0 34px;border-bottom:1px solid var(--cyan)}}.kicker{{color:var(--cyan);font-weight:800;letter-spacing:.13em;text-transform:uppercase}}h1{{font-size:clamp(3rem,9vw,7.4rem);line-height:.82;letter-spacing:-.065em;margin:.18em 0;background:linear-gradient(90deg,var(--cyan),var(--pink) 54%,var(--lime));-webkit-background-clip:text;color:transparent}}h2{{font-size:clamp(1.5rem,3vw,2.35rem);margin:.2em 0}}p{{max-width:76ch}}button,.button{{font:inherit;color:var(--text);background:var(--panel);border:1px solid var(--cyan);border-radius:999px;padding:.66rem 1rem;cursor:pointer;text-decoration:none}}button:focus,.button:focus{{outline:3px solid var(--lime);outline-offset:3px}}.top{{display:flex;justify-content:space-between;gap:16px;align-items:start}}.stamp{{border:1px solid var(--line);border-radius:999px;padding:.4rem .75rem;color:var(--muted)}}.grid{{display:grid;grid-template-columns:repeat(12,1fr);gap:18px;margin:28px 0}}.card{{grid-column:span 6;background:linear-gradient(145deg,color-mix(in srgb,var(--panel) 94%,var(--cyan)),var(--panel));border:1px solid var(--line);border-radius:18px;padding:22px;position:relative;overflow:hidden}}.card::before{{content:"";position:absolute;inset:0 auto auto 0;width:100%;height:2px;background:linear-gradient(90deg,var(--cyan),var(--pink),transparent)}}.wide{{grid-column:1/-1}}.number{{font:800 2rem/1 ui-monospace,monospace;color:var(--pink)}}code{{font:14px ui-monospace,monospace;color:var(--lime);word-break:break-word}}pre{{white-space:pre-wrap;background:#0003;padding:14px;border:1px solid var(--line);border-radius:12px}}ul{{padding-left:1.25rem}}.truth{{border-left:4px solid var(--lime)}}.warning{{border-left:4px solid var(--danger)}}.status{{display:flex;gap:12px;align-items:center;color:var(--muted)}}.dot{{width:10px;height:10px;border-radius:50%;background:var(--lime);box-shadow:0 0 16px var(--lime)}}footer{{border-top:1px solid var(--line);margin-top:34px;padding-top:20px;color:var(--muted)}}
@media(max-width:760px){{.card{{grid-column:1/-1}}.top{{display:block}}.stamp{{display:inline-block;margin-top:12px}}}}
@media(forced-colors:active){{h1{{background:none;color:CanvasText}}.card::before{{display:none}}button,.button,.card{{border:1px solid CanvasText}}}}
@media(prefers-reduced-motion:reduce){{*{{scroll-behavior:auto!important;animation:none!important;transition:none!important}}}}
</style>
</head>
<body><main>
<header><div class="top"><div><div class="kicker">ProgRSS native fieldwork packet</div><h1>Roadcase</h1><p>Bring the exact build. Verify it there. Leave no mystery behind.</p></div><div><span class="stamp">{version} · {revision} · {codename}</span><button id="theme" type="button">☼ Light</button></div></div><div class="status"><span class="dot" aria-hidden="true"></span><span>Local-only packet · synthetic fixtures · no telemetry · no participant account</span></div></header>
<section class="grid" aria-label="Roadcase steps">
<article class="card wide truth"><span class="number">0</span><h2>Verify before use</h2><p>Open a terminal in this folder and run:</p><pre><code>python3 scripts/verify.py --restore-modes
python3 scripts/preflight.py</code></pre><p>Do not install the Extension or start the Node when verification fails.</p></article>
<article class="card"><span class="number">1</span><h2>Use a fresh browser profile</h2><p>Follow <code>INSTALL-CHROMIUM.md</code> or <code>INSTALL-FIREFOX.md</code>. Use the exact directory inside <code>release/Extension/</code>. Do not copy a personal profile into the session.</p></article>
<article class="card"><span class="number">2</span><h2>Prepare the synthetic Node</h2><pre><code>python3 scripts/prepare.py
python3 release/CLI/progrss.py node serve work/roadcase.sqlite3 --port 43161</code></pre><p>Preparation is offline. The synthetic feed addresses are not contacted.</p></article>
<article class="card"><span class="number">3</span><h2>Start the local page fixture</h2><pre><code>python3 scripts/serve_fixture.py</code></pre><p>Open <code>http://127.0.0.1:43162/virtual-window.html</code>. It deliberately exposes two disjoint rendered windows.</p></article>
<article class="card"><span class="number">4</span><h2>Run one scenario</h2><ul><li><strong>Dispatch:</strong> sender reviews what may leave before creating a handoff.</li><li><strong>Crossroads:</strong> recipient distinguishes Follow updates, Add route, and Take branch.</li><li><strong>Trace / Bearing / Anchor:</strong> administrator interprets held partial observations and baseline replacement.</li></ul></article>
<article class="card"><span class="number">5</span><h2>Record observations privately</h2><p>Keep the actual ProgRSS interface and Fieldbook in separate windows. Use neutral prompts only after an independent attempt. Test the interface—not the participant.</p></article>
<article class="card"><span class="number">6</span><h2>Review before export</h2><p>Remove names, contact details, credentials, and sensitive page content. Debrief only compatible privacy-reviewed reports. Raw facilitator notes remain out of the Debrief export.</p></article>
<article class="card warning"><span class="number">7</span><h2>Clean up</h2><pre><code>python3 scripts/cleanup.py</code></pre><p>Remove the temporary Extension, stop the local processes, close the dedicated profile, and retain only deliberately reviewed reports.</p></article>
<article class="card wide"><h2>What this packet cannot prove</h2><p>Automated checks can verify bytes, schemas, browser mechanics, and privacy boundaries. They cannot prove that unfamiliar people understood the interface or that assistive-technology users encountered no barriers. Record those sessions as performed only when they actually occur.</p></article>
</section>
<footer><p>Roadcase uses browser-owned temporary installation mechanisms. It does not disable managed policy, install a daemon, open the LAN, upload reports, or grant ProgRSS remote access.</p></footer>
</main><script>(()=>{{const b=document.getElementById('theme');b.addEventListener('click',()=>{{const light=document.documentElement.dataset.theme!=='light';document.documentElement.dataset.theme=light?'light':'dark';b.textContent=light?'☾ Dark':'☼ Light';}})}})();</script></body></html>'''
    return doc.encode("utf-8")


def _readme(release: dict[str, str]) -> bytes:
    text = f"""# ProgRSS Roadcase {release['revision']} — {release['codename']}

This packet is a local, synthetic native-fieldwork environment for ProgRSS {release['version']}.

Start with `START.html` and run:

```sh
python3 scripts/verify.py --restore-modes
python3 scripts/preflight.py
```

The packet performs no telemetry and includes no participant account. Its synthetic fixture addresses under `example.test` are not contacted by preparation. Browser-assisted Capture can use the literal-loopback fixture only after a visible user action.

The packet does not prove that native or human sessions occurred. Record those separately only after the sessions actually happen.
"""
    return text.encode("utf-8")


def _install_chromium() -> bytes:
    return b"""# Chromium temporary installation\n\n1. Use an unmanaged test machine and a fresh browser profile.\n2. Run `python3 scripts/verify.py --restore-modes`.\n3. Open `chrome://extensions`.\n4. Enable Developer mode for this test session.\n5. Choose **Load unpacked** and select `release/Extension`.\n6. Confirm the displayed version matches `release/VERSION`.\n7. Run only the planned scenario.\n8. Remove the unpacked Extension after the session and close the dedicated profile.\n\nDo not remove or bypass managed browser policy. Do not use a personal browser profile.\n"""


def _install_firefox() -> bytes:
    return b"""# Firefox temporary installation\n\n1. Use a fresh Firefox test profile.\n2. Run `python3 scripts/verify.py --restore-modes`.\n3. Open `about:debugging`.\n4. Choose **This Firefox** then **Load Temporary Add-on**.\n5. Select `release/Extension/Firefox/manifest.json`.\n6. Confirm the displayed version matches `release/VERSION`.\n7. Run only the planned scenario.\n8. Remove the temporary add-on or restart Firefox after the session and close the dedicated profile.\n\nTemporary installation is browser-owned. Roadcase does not install a persistent add-on or change Firefox policy.\n"""


def _session_checklist() -> bytes:
    return b"""# Native fieldwork checklist\n\n## Before\n- Verify the packet.\n- Use a fresh browser profile.\n- Confirm the exact version and browser.\n- Choose one scenario and its Fieldbook.\n- Use synthetic fixtures first.\n- Explain that the product, not the participant, is being tested.\n\n## During\n- Keep Fieldbook in a separate facilitator window.\n- Observe an independent attempt before a neutral prompt.\n- Record wrong turns instead of coaching them away.\n- Record no participant name, email, account, credential, or sensitive page content.\n- Do not interpret automated completion as comprehension.\n\n## After\n- Privacy-review the report before export.\n- Keep Dispatch, Crossroads, and Trace/Bearing/Anchor reports separate.\n- Stop both local servers.\n- Remove the temporary Extension.\n- Close the dedicated profile.\n- Run `python3 scripts/cleanup.py`.\n- Retain only deliberately reviewed reports.\n"""


def _cleanup_doc() -> bytes:
    return b"""# Cleanup\n\n1. Stop the ProgRSS Node and fixture server with Ctrl+C.\n2. Remove the unpacked Chromium Extension or restart/remove the temporary Firefox add-on.\n3. Close the dedicated browser profile.\n4. Move deliberately reviewed reports out of `work/` when they should be retained.\n5. Run `python3 scripts/cleanup.py`.\n6. Run `python3 scripts/verify.py` again. Mutable `work/` contents are excluded from immutable packet verification.\n\nThe cleanup script removes only the Roadcase `work/` directory after an explicit confirmation or `--yes`.\n"""


def _verify_script() -> bytes:
    return b'''#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os, stat, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
MANIFEST=ROOT/'MANIFEST.json'
IGNORED={'.DS_Store','Thumbs.db','desktop.ini'}
MUTABLE=('work/',)
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
 return h.hexdigest()
def main():
 ap=argparse.ArgumentParser(description='Verify immutable ProgRSS Roadcase members.')
 ap.add_argument('--restore-modes',action='store_true')
 ap.add_argument('--json',action='store_true')
 a=ap.parse_args(); errors=[]; restored=[]
 try: m=json.loads(MANIFEST.read_text(encoding='utf-8'))
 except Exception as e: print(f'Roadcase verification failed: {e}',file=sys.stderr); return 2
 expected={row['path']:row for row in m.get('files',[])}
 for name,row in expected.items():
  p=ROOT/name
  if not p.is_file(): errors.append(f'missing: {name}'); continue
  if sha(p)!=row['sha256']: errors.append(f'digest mismatch: {name}')
  mode=int(row['mode'],8)
  if os.name!='nt' and stat.S_IMODE(p.stat().st_mode)!=mode:
   if a.restore_modes:
    os.chmod(p,mode); restored.append(name)
   else: errors.append(f'mode mismatch: {name}; rerun with --restore-modes')
 actual=[]
 for p in ROOT.rglob('*'):
  if not p.is_file(): continue
  rel=p.relative_to(ROOT).as_posix()
  if rel=='MANIFEST.json' or rel.startswith(MUTABLE) or p.name in IGNORED or '__pycache__' in p.parts or p.suffix=='.pyc': continue
  actual.append(rel)
 for rel in sorted(set(actual)-set(expected)): errors.append(f'unexpected immutable file: {rel}')
 result={'schema':'progrss.roadcase.verify.v1','release':m.get('release'), 'files':len(expected),'restoredModes':restored,'ok':not errors,'errors':errors,'network':False,'writes':bool(restored)}
 if a.json: print(json.dumps(result,indent=2,sort_keys=True))
 else:
  print('ProgRSS Roadcase verification')
  print(f"  Release: {m.get('release',{}).get('version','')} / {m.get('release',{}).get('revision','')}")
  print(f'  Immutable files checked: {len(expected)}')
  if restored: print(f'  Executable modes restored: {len(restored)}')
  if errors:
   print('  RESULT: FAIL')
   for e in errors: print('  - '+e)
  else: print('  RESULT: PASS')
  print('  Network: none')
 return 0 if not errors else 2
if __name__=='__main__': raise SystemExit(main())
'''


def _preflight_script() -> bytes:
    return b'''#!/usr/bin/env python3
from __future__ import annotations
import json, shutil, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def run(*argv):
 p=subprocess.run(argv,cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 return {'argv':list(argv),'returncode':p.returncode,'stdout':p.stdout[-4000:],'stderr':p.stderr[-4000:]}
def main():
 checks=[]
 checks.append(run(sys.executable,'scripts/verify.py'))
 checks.append(run(sys.executable,'release/CLI/progrss.py','--version'))
 checks.append(run(sys.executable,'release/CLI/progrss.py','doctor'))
 browsers={name:shutil.which(name) for name in ('chromium','google-chrome','firefox','firefox-esr')}
 ok=all(row['returncode']==0 for row in checks)
 print('ProgRSS Roadcase preflight')
 for row in checks: print(f"  {'PASS' if row['returncode']==0 else 'FAIL'} {' '.join(row['argv'][1:])}")
 print('  Browsers discovered: '+', '.join(f"{k}={v or 'not found'}" for k,v in browsers.items()))
 print('  Native installation and human sessions: not run')
 print('  Network: none')
 return 0 if ok else 2
if __name__=='__main__': raise SystemExit(main())
'''


def _prepare_script() -> bytes:
    return b'''#!/usr/bin/env python3
from __future__ import annotations
import subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
work=ROOT/'work'; work.mkdir(exist_ok=True)
store=work/'roadcase.sqlite3'
if store.exists():
 print(f'Roadcase Node already exists: {store}')
 raise SystemExit(0)
cmd=[sys.executable,str(ROOT/'release/CLI/progrss.py'),'node','init',str(ROOT/'fixtures/roadcase-private-library.json'),'--output',str(store),'--json']
result=subprocess.run(cmd,cwd=ROOT,text=True)
if result.returncode: raise SystemExit(result.returncode)
print('Prepared synthetic Node-owned library.')
print('No feed or watched page was contacted.')
print('Next: python3 release/CLI/progrss.py node serve work/roadcase.sqlite3 --port 43161')
'''


def _serve_fixture_script() -> bytes:
    return b'''#!/usr/bin/env python3
from __future__ import annotations
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os
ROOT=Path(__file__).resolve().parents[1]
os.chdir(ROOT/'fixtures/web')
server=ThreadingHTTPServer(('127.0.0.1',43162),SimpleHTTPRequestHandler)
print('Synthetic page fixture: http://127.0.0.1:43162/virtual-window.html')
print('Loopback only. Press Ctrl+C to stop.')
try: server.serve_forever()
except KeyboardInterrupt: pass
finally: server.server_close()
'''


def _cleanup_script() -> bytes:
    return b'''#!/usr/bin/env python3
from __future__ import annotations
import argparse, shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser(description='Remove only the mutable ProgRSS Roadcase work directory.')
ap.add_argument('--yes',action='store_true',help='skip interactive confirmation')
a=ap.parse_args(); work=ROOT/'work'
if not work.exists(): print('Roadcase work directory is already absent.'); raise SystemExit(0)
if not a.yes:
 answer=input(f'Remove {work} and every unexported draft inside it? [y/N] ').strip().lower()
 if answer not in {'y','yes'}: print('Cleanup cancelled.'); raise SystemExit(1)
shutil.rmtree(work)
print('Removed Roadcase work directory. Immutable packet files were not changed.')
'''


def _packet_member_sources(release_root: Path) -> Iterable[tuple[Path, str]]:
    top_files = [
        "VERSION", "REVISION", "CODENAME", "BOOTSTRAPROSE.md",
        "ROADCASE-RELEASE.json", "RELEASE-NOTES-rev0080-Roadcase.md",
        "DISPATCH-RELEASE.json", "CROSSROADS-RELEASE.json", "DEBRIEF-RELEASE.json",
        "FIELDBOOK-RELEASE.json", "TRACE-RELEASE.json", "BEARING-RELEASE.json", "ANCHOR-RELEASE.json",
    ]
    for name in top_files:
        path = release_root / name
        if path.is_file():
            yield path, f"release/{name}"
    for top in ("CLI", "Extension"):
        source = release_root / top
        if not source.is_dir():
            raise RoadcaseError(f"release is missing {top}/")
        for path in sorted(source.rglob("*"), key=lambda row: row.as_posix()):
            if not path.is_file():
                continue
            if path.is_symlink() or "__pycache__" in path.parts or path.suffix == ".pyc":
                continue
            rel = path.relative_to(release_root).as_posix()
            yield path, f"release/{rel}"


def _write_manifest(staging: Path, release: dict[str, str]) -> dict[str, Any]:
    files: list[dict[str, Any]] = []
    total = 0
    for path in sorted(staging.rglob("*"), key=lambda row: row.as_posix()):
        if not path.is_file() or path.name == "MANIFEST.json" or path.relative_to(staging).as_posix().startswith("work/"):
            continue
        rel = _safe_member_name(path.relative_to(staging).as_posix())
        raw = path.read_bytes(); total += len(raw)
        files.append({"path": rel, "bytes": len(raw), "sha256": _sha256_bytes(raw), "mode": f"{_file_mode(path, rel):04o}"})
    if len(files) > MAX_PACKET_FILES or total > MAX_PACKET_BYTES:
        raise RoadcaseError("Roadcase packet exceeds its bounded file or byte budget")
    manifest = {
        "schema": ROADCASE_MANIFEST_SCHEMA,
        "release": release,
        "generatedAt": ROADCASE_GENERATED_AT,
        "files": files,
        "fileCount": len(files),
        "immutableBytes": total,
        "mutablePrefixes": list(ALLOWED_MUTABLE_PREFIXES),
        "network": False,
        "telemetry": False,
        "participantIdentityRequested": False,
    }
    (staging / "MANIFEST.json").write_bytes(_display_json_bytes(manifest))
    return manifest


def _zip_directory(staging: Path, output: Path) -> dict[str, Any]:
    if output.exists():
        raise RoadcaseError(f"output already exists: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(staging.rglob("*"), key=lambda row: row.relative_to(staging).as_posix()):
            if not path.is_file():
                continue
            rel = _safe_member_name(path.relative_to(staging).as_posix())
            info = zipfile.ZipInfo(rel, date_time=ROADCASE_ZIP_TIME)
            mode = _file_mode(path, rel)
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | mode) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    raw = output.read_bytes()
    return {"file": str(output), "bytes": len(raw), "sha256": _sha256_bytes(raw)}


def verify_roadcase_directory(root: Path, *, restore_modes: bool = False) -> dict[str, Any]:
    root = root.expanduser().resolve()
    manifest_path = root / "MANIFEST.json"
    if not manifest_path.is_file():
        raise RoadcaseError("Roadcase MANIFEST.json is missing")
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RoadcaseError(f"Roadcase manifest is unreadable: {exc}") from exc
    if not isinstance(manifest, dict) or manifest.get("schema") != ROADCASE_MANIFEST_SCHEMA:
        raise RoadcaseError("Roadcase manifest schema is unsupported")
    rows = manifest.get("files")
    if not isinstance(rows, list) or len(rows) > MAX_PACKET_FILES:
        raise RoadcaseError("Roadcase manifest file list is malformed")
    expected: dict[str, dict[str, Any]] = {}
    errors: list[str] = []
    restored: list[str] = []
    for row in rows:
        if not isinstance(row, dict) or set(row) != {"path", "bytes", "sha256", "mode"}:
            raise RoadcaseError("Roadcase manifest contains a malformed file row")
        rel = _safe_member_name(str(row["path"]))
        if rel in expected:
            raise RoadcaseError(f"Roadcase manifest duplicates {rel}")
        expected[rel] = row
        path = root / rel
        if not path.is_file():
            errors.append(f"missing: {rel}")
            continue
        raw = path.read_bytes()
        if len(raw) != int(row["bytes"]):
            errors.append(f"byte count mismatch: {rel}")
        if _sha256_bytes(raw) != str(row["sha256"]):
            errors.append(f"digest mismatch: {rel}")
        try:
            mode = int(str(row["mode"]), 8)
        except ValueError as exc:
            raise RoadcaseError(f"Roadcase manifest mode is invalid for {rel}") from exc
        if os.name != "nt" and stat.S_IMODE(path.stat().st_mode) != mode:
            if restore_modes:
                os.chmod(path, mode); restored.append(rel)
            else:
                errors.append(f"mode mismatch: {rel}")
    actual: set[str] = set()
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(root).as_posix()
        if rel == "MANIFEST.json" or rel.startswith(ALLOWED_MUTABLE_PREFIXES) or path.name in IGNORED_RUNTIME_NAMES or "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        actual.add(rel)
    for rel in sorted(actual - set(expected)):
        errors.append(f"unexpected immutable file: {rel}")
    return {
        "schema": ROADCASE_VERIFY_SCHEMA,
        "release": manifest.get("release"),
        "files": len(expected),
        "restoredModes": restored,
        "ok": not errors,
        "errors": errors,
        "network": False,
        "writes": bool(restored),
    }


def build_roadcase_packet(
    release_root: Path,
    output: Path,
    *,
    version: str,
    revision: str,
    codename: str,
) -> dict[str, Any]:
    release_root = release_root.expanduser().resolve()
    output = output.expanduser().resolve()
    if not release_root.is_dir():
        raise RoadcaseError(f"release root does not exist: {release_root}")
    if output.exists():
        raise RoadcaseError(f"output already exists: {output}")
    release = {"version": version, "revision": revision, "codename": codename}
    with tempfile.TemporaryDirectory(prefix="progrss-roadcase-") as directory:
        staging = Path(directory) / f"ProgRSS-Roadcase-{revision}"
        staging.mkdir(parents=True)
        # Exact product bytes.
        for source, rel in _packet_member_sources(release_root):
            target = staging / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, target)
            os.chmod(target, _file_mode(source, rel))
        # Human and helper material.
        files: dict[str, bytes] = {
            "START.html": _start_html(release),
            "README.md": _readme(release),
            "INSTALL-CHROMIUM.md": _install_chromium(),
            "INSTALL-FIREFOX.md": _install_firefox(),
            "SESSION-CHECKLIST.md": _session_checklist(),
            "CLEANUP.md": _cleanup_doc(),
            "scripts/verify.py": _verify_script(),
            "scripts/preflight.py": _preflight_script(),
            "scripts/prepare.py": _prepare_script(),
            "scripts/serve_fixture.py": _serve_fixture_script(),
            "scripts/cleanup.py": _cleanup_script(),
            "fixtures/roadcase-private-library.json": _display_json_bytes(_synthetic_backup(release)),
            "fixtures/web/virtual-window.html": _virtual_window_html(),
        }
        boundary = {
            "schema": ROADCASE_SCHEMA,
            "release": release,
            "generatedAt": ROADCASE_GENERATED_AT,
            "authority": {
                "networkDuringBuild": False,
                "networkDuringVerification": False,
                "telemetry": False,
                "participantIdentityRequested": False,
                "automaticPersistence": False,
                "nativeSessionsPerformed": False,
                "humanSessionsPerformed": False,
            },
            "ports": {"node": 43161, "syntheticPage": 43162, "bind": "127.0.0.1"},
            "scenarios": ["exchange-sender-review", "exchange-three-doors", "trace-bearing-anchor"],
            "mutablePrefixes": list(ALLOWED_MUTABLE_PREFIXES),
        }
        files["ROADCASE.json"] = _display_json_bytes(boundary)
        for rel, raw in files.items():
            target = staging / _safe_member_name(rel)
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
            os.chmod(target, 0o755 if rel.startswith("scripts/") else 0o644)
        (staging / "work").mkdir()
        manifest = _write_manifest(staging, release)
        verification = verify_roadcase_directory(staging)
        if not verification["ok"]:
            raise RoadcaseError("new Roadcase staging directory failed verification: " + "; ".join(verification["errors"]))
        zipped = _zip_directory(staging, output)
    return {
        "schema": ROADCASE_SCHEMA,
        "state": "written",
        "release": release,
        "file": str(output),
        "bytes": zipped["bytes"],
        "sha256": zipped["sha256"],
        "manifestFiles": manifest["fileCount"],
        "immutableBytes": manifest["immutableBytes"],
        "network": False,
        "telemetry": False,
        "participantIdentityRequested": False,
        "nativeSessionsPerformed": False,
        "humanSessionsPerformed": False,
        "newFileOnly": True,
    }
