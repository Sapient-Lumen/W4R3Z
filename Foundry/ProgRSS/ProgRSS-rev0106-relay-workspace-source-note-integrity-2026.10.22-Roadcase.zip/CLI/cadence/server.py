from __future__ import annotations

import copy
import hashlib
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
from pathlib import Path
import secrets
import threading
import urllib.parse
import webbrowser
from typing import Any

from . import CODENAME, REVISION, VERSION
from .common import CadenceError, READY_SCHEMA, canonical_bytes, release_identity
from .service import CadenceService

WEB_ROOT = Path(__file__).resolve().parent / "web"
MAX_REQUEST_BYTES = 16_384


class PulseHTTPServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(
        self,
        address: tuple[str, int],
        handler: type[BaseHTTPRequestHandler],
        *,
        service: CadenceService,
        token: str,
        review_config: dict[str, Any] | None,
    ):
        super().__init__(address, handler)
        self.service = service
        self.token = token
        self.origin = ""
        self.review_config = review_config
        self.review_document: dict[str, Any] | None = None
        self.shutdown_lock = threading.Lock()


class PulseHandler(BaseHTTPRequestHandler):
    server: PulseHTTPServer
    protocol_version = "HTTP/1.1"

    def log_message(self, _format: str, *_args: Any) -> None:
        return

    def _host_ok(self) -> bool:
        expected = urllib.parse.urlsplit(self.server.origin).netloc
        return self.headers.get("Host", "") == expected

    def _origin_ok(self) -> bool:
        origin = self.headers.get("Origin")
        return origin is None or origin == self.server.origin

    def _security_headers(self, *, content_type: str, length: int) -> dict[str, str]:
        return {
            "Content-Type": content_type,
            "Content-Length": str(length),
            "Cache-Control": "no-store",
            "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'",
            "Referrer-Policy": "no-referrer",
            "X-Content-Type-Options": "nosniff",
            "X-Frame-Options": "DENY",
            "Cross-Origin-Resource-Policy": "same-origin",
            "Cross-Origin-Opener-Policy": "same-origin",
            "Permissions-Policy": "camera=(), microphone=(), geolocation=(), payment=(), usb=(), serial=(), bluetooth=()",
        }

    def _send(self, status: int, body: bytes, content_type: str, extra: dict[str, str] | None = None) -> None:
        self.send_response(int(status))
        headers = self._security_headers(content_type=content_type, length=len(body))
        if extra:
            headers.update(extra)
        for key, value in headers.items():
            self.send_header(key, value)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def _json(self, status: int, value: Any, extra: dict[str, str] | None = None) -> None:
        self._send(status, canonical_bytes(value), "application/json; charset=utf-8", extra)

    def _error(self, status: int, message: str) -> None:
        self._json(status, {"schema": "progrss.cadence-http-error.v1", "error": str(message)[:600]})

    def _bearer(self) -> str:
        value = self.headers.get("Authorization", "")
        return value[7:] if value.startswith("Bearer ") else ""

    def _authorized(self) -> bool:
        return secrets.compare_digest(self._bearer(), self.server.token)

    def _read_json(self) -> dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise CadenceError("invalid Content-Length") from exc
        if length < 0 or length > MAX_REQUEST_BYTES:
            raise CadenceError("request body is too large")
        raw = self.rfile.read(length)
        if not raw:
            return {}
        try:
            value = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise CadenceError("request body is not valid UTF-8 JSON") from exc
        if not isinstance(value, dict):
            raise CadenceError("request body must be one JSON object")
        return value

    def _static(self, path: str) -> None:
        name = "index.html" if path in {"/", "/index.html"} else path.lstrip("/")
        if name not in {"index.html", "app.css", "app.js"}:
            self._error(HTTPStatus.NOT_FOUND, "not found")
            return
        target = WEB_ROOT / name
        try:
            body = target.read_bytes()
        except OSError:
            self._error(HTTPStatus.NOT_FOUND, "not found")
            return
        media = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if media.startswith("text/") or media in {"application/javascript"}:
            media += "; charset=utf-8"
        self._send(HTTPStatus.OK, body, media)

    def _status_document(self) -> dict[str, Any]:
        document = self.server.service.status()
        review = self.server.review_document
        return {
            **document,
            "origin": self.server.origin,
            "reviewAvailable": review is not None,
            "review": copy.deepcopy(review),
        }

    def do_HEAD(self) -> None:
        if not self._host_ok():
            self._error(HTTPStatus.BAD_REQUEST, "unexpected Host header")
            return
        parsed = urllib.parse.urlsplit(self.path)
        if parsed.path.startswith("/api/"):
            self._error(HTTPStatus.METHOD_NOT_ALLOWED, "HEAD is not available for API routes")
            return
        self._static(parsed.path)

    def do_GET(self) -> None:
        if not self._host_ok():
            self._error(HTTPStatus.BAD_REQUEST, "unexpected Host header")
            return
        if not self._origin_ok():
            self._error(HTTPStatus.FORBIDDEN, "foreign Origin refused")
            return
        path = urllib.parse.urlsplit(self.path).path
        if not path.startswith("/api/"):
            self._static(path)
            return
        if not self._authorized():
            self._error(HTTPStatus.UNAUTHORIZED, "Pulse capability required")
            return
        if path == "/api/v1/status":
            self._json(HTTPStatus.OK, self._status_document())
            return
        if path == "/api/v1/plans":
            self._json(HTTPStatus.OK, self.server.service.store.list_document())
            return
        if path == "/api/v1/slots":
            self._json(HTTPStatus.OK, {"schema": "progrss.cadence-slots.v1", "slots": self.server.service.store.recent_slots(50)})
            return
        if path == "/api/v1/review":
            if self.server.review_document is None:
                self._error(HTTPStatus.NOT_FOUND, "no Witness receipt was supplied for GUI review")
                return
            self._json(HTTPStatus.OK, self.server.review_document)
            return
        self._error(HTTPStatus.NOT_FOUND, "unknown API route")

    def do_POST(self) -> None:
        if not self._host_ok():
            self._error(HTTPStatus.BAD_REQUEST, "unexpected Host header")
            return
        if self.headers.get("Origin") != self.server.origin:
            self._error(HTTPStatus.FORBIDDEN, "exact same-origin request required")
            return
        if not self._authorized():
            self._error(HTTPStatus.UNAUTHORIZED, "Pulse capability required")
            return
        path = urllib.parse.urlsplit(self.path).path
        try:
            body = self._read_json()
            if path == "/api/v1/plans":
                config = self.server.review_config
                review = self.server.review_document
                if config is None or review is None:
                    raise CadenceError("no reviewed Witness receipt is available in this server session")
                if body.get("acknowledge") is not True:
                    raise CadenceError("creating a recurring timing plan requires acknowledgement")
                if str(body.get("reviewDigest") or "") != str(review.get("reviewDigest") or ""):
                    raise CadenceError("the timing review changed; review it again")
                result = self.server.service.create_plan(
                    config["receipt"],
                    interval_seconds=config["interval"],
                    jitter_seconds=config["jitter"],
                    start_paused=config["startPaused"],
                    acknowledge=True,
                )
                self.server.review_document = None
                self._json(HTTPStatus.CREATED, result, {"Location": "/api/v1/plans"})
                return
            if path == "/api/v1/run-due":
                self._json(HTTPStatus.OK, self.server.service.run_due(limit=20))
                return
            if path == "/api/v1/scheduler/start":
                self._json(HTTPStatus.OK, {"schema": "progrss.cadence-scheduler.v1", "scheduler": self.server.service.start_loop()})
                return
            if path == "/api/v1/scheduler/stop":
                self._json(HTTPStatus.OK, {"schema": "progrss.cadence-scheduler.v1", "scheduler": self.server.service.stop_loop()})
                return
            if path.startswith("/api/v1/plans/"):
                pieces = path.split("/")
                if len(pieces) != 6 or pieces[5] not in {"pause", "resume"}:
                    self._error(HTTPStatus.NOT_FOUND, "unknown plan action")
                    return
                plan_id = urllib.parse.unquote(pieces[4])
                result = self.server.service.pause(plan_id) if pieces[5] == "pause" else self.server.service.resume(plan_id)
                self._json(HTTPStatus.OK, result)
                return
            if path == "/api/v1/shutdown":
                self.server.service.stop_loop()
                self._json(HTTPStatus.OK, {"schema": "progrss.cadence-shutdown.v1", "state": "stopping"})
                with self.server.shutdown_lock:
                    threading.Thread(target=self.server.shutdown, daemon=True).start()
                return
            self._error(HTTPStatus.NOT_FOUND, "unknown API route")
        except CadenceError as exc:
            self._error(HTTPStatus.CONFLICT, str(exc))
        except Exception as exc:
            self._error(HTTPStatus.INTERNAL_SERVER_ERROR, f"Pulse could not complete the action: {exc}")


def serve(
    database: Path,
    *,
    node_store: Path | None = None,
    runner: Path | None = None,
    port: int = 0,
    open_browser: bool = False,
    json_ready: bool = False,
    receipt: Path | None = None,
    interval: int = 6 * 3600,
    jitter: int | None = None,
    start_paused: bool = False,
    origin_gap: int = 10,
) -> int:
    service = CadenceService(database, node_store_path=node_store, runner=runner, origin_gap_seconds=origin_gap)
    review_config = None
    review_document = None
    if receipt is not None:
        review_config = {
            "receipt": Path(receipt).expanduser().resolve(),
            "interval": int(interval),
            "jitter": jitter,
            "startPaused": bool(start_paused),
        }
        review_document = service.review_plan(
            review_config["receipt"],
            interval_seconds=review_config["interval"],
            jitter_seconds=review_config["jitter"],
            start_paused=review_config["startPaused"],
        )
    token = secrets.token_urlsafe(32)
    httpd = PulseHTTPServer(
        ("127.0.0.1", int(port)),
        PulseHandler,
        service=service,
        token=token,
        review_config=review_config,
    )
    actual_port = int(httpd.server_address[1])
    httpd.origin = f"http://127.0.0.1:{actual_port}"
    httpd.review_document = review_document
    capability_url = f"{httpd.origin}/#token={urllib.parse.quote(token, safe='')}"
    ready = {
        "schema": READY_SCHEMA,
        **release_identity(),
        "origin": httpd.origin,
        "url": capability_url,
        "scope": "loopback-cadence-control",
        "database": service.status()["database"],
        "adapter": service.status()["adapter"],
        "scheduler": service.scheduler_status(),
        "reviewAvailable": review_document is not None,
        "capabilities": service.status()["capabilities"],
    }
    if json_ready:
        print(json.dumps(ready, ensure_ascii=False, separators=(",", ":")), flush=True)
    else:
        print(f"ProgRSS Pulse {VERSION} · {CODENAME}", flush=True)
        print(f"Open: {capability_url}", flush=True)
        print(f"Timing database: {service.store.path.name}", flush=True)
        print(f"Node library: {service.node_store_path.name}", flush=True)
        print("Scheduler: stopped · opening the page contacts no source", flush=True)
        print("Adapter: packaged Witness" if service.status()["adapter"]["packagedWitness"] else "Adapter: explicit external runner", flush=True)
    if open_browser:
        webbrowser.open(capability_url, new=1)
    try:
        httpd.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        service.stop_loop()
        httpd.server_close()
    return 0


__all__ = ["PulseHTTPServer", "PulseHandler", "serve"]
