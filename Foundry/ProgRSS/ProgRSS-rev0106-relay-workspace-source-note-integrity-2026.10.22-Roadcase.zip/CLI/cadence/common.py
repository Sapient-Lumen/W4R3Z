from __future__ import annotations

import datetime as _dt
import email.utils
import hashlib
import json
import math
import re
import secrets
import time
from dataclasses import dataclass
from typing import Any, Mapping

from . import CODENAME, REVISION, VERSION

STORE_SCHEMA = "progrss.cadence-store.v1"
REVIEW_SCHEMA = "progrss.cadence-review.v1"
PLAN_SCHEMA = "progrss.cadence-plan.v1"
LIST_SCHEMA = "progrss.cadence-list.v1"
SLOT_SCHEMA = "progrss.cadence-slot.v1"
DISPATCH_SCHEMA = "progrss.cadence-dispatch-result.v1"
STATUS_SCHEMA = "progrss.cadence-status.v1"
READY_SCHEMA = "progrss.cadence-ready.v1"

MIN_INTERVAL_SECONDS = 15 * 60
MAX_INTERVAL_SECONDS = 30 * 24 * 60 * 60
MAX_JITTER_SECONDS = 6 * 60 * 60
MAX_BACKOFF_SECONDS = 30 * 24 * 60 * 60
DEFAULT_LEASE_SECONDS = 45
DEFAULT_POLL_SECONDS = 2.0
DEFAULT_ORIGIN_GAP_SECONDS = 10
MAX_RESULT_BYTES = 1024 * 1024

SUCCESS_OUTCOMES = frozenset({"changed", "unchanged", "baseline", "watch-pending", "checking-again"})
TEMPORARY_OUTCOMES = frozenset({"temporary-failure", "throttled"})
BLOCKING_OUTCOMES = frozenset({"permanent-failure", "moved", "refused", "malformed", "needs-repair"})

_DURATION_RE = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*([smhdw]?)\s*$", re.I)
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
_ID_RE = re.compile(r"^[A-Za-z0-9._~-]{8,200}$")


class CadenceError(Exception):
    """Expected user-facing Cadence or Pulse failure."""


class CadenceConflict(CadenceError):
    """A reviewed state or idempotency boundary no longer matches."""


class CadenceBusy(CadenceError):
    """Another live scheduler owns the timing database."""


@dataclass(frozen=True, slots=True)
class RetryAfter:
    raw: str
    seconds: int
    kind: str


def iso_utc(timestamp: float | None = None, *, milliseconds: bool = True) -> str:
    value = time.time() if timestamp is None else float(timestamp)
    moment = _dt.datetime.fromtimestamp(value, tz=_dt.timezone.utc)
    if milliseconds:
        return moment.isoformat(timespec="milliseconds").replace("+00:00", "Z")
    return moment.isoformat(timespec="seconds").replace("+00:00", "Z")


def parse_iso(value: Any, *, label: str = "timestamp") -> float:
    text = str(value or "").strip()
    if not text:
        raise CadenceError(f"{label} is required")
    try:
        parsed = _dt.datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as exc:
        raise CadenceError(f"invalid {label}") from exc
    if parsed.tzinfo is None:
        raise CadenceError(f"{label} must include a timezone")
    return parsed.timestamp()


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha256_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def sha256_json(value: Any) -> str:
    return sha256_bytes(canonical_bytes(value))


def bounded_text(value: Any, limit: int = 300) -> str:
    text = " ".join(str(value or "").replace("\x00", " ").split())
    return text[: max(0, int(limit))]


def parse_duration(value: Any, *, minimum: int = 1, maximum: int = MAX_INTERVAL_SECONDS, label: str = "duration") -> int:
    text = str(value or "").strip().lower()
    match = _DURATION_RE.fullmatch(text)
    if not match:
        raise CadenceError(f"{label} must look like 15m, 6h, 2d, or a number of seconds")
    amount = float(match.group(1))
    unit = match.group(2) or "s"
    multiplier = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}[unit]
    seconds = int(math.ceil(amount * multiplier))
    if seconds < minimum or seconds > maximum:
        raise CadenceError(f"{label} must be between {format_duration(minimum)} and {format_duration(maximum)}")
    return seconds


def format_duration(seconds: int | float) -> str:
    seconds = max(0, int(seconds))
    if seconds % 86400 == 0 and seconds >= 86400:
        days = seconds // 86400
        return f"{days} day" + ("s" if days != 1 else "")
    if seconds % 3600 == 0 and seconds >= 3600:
        hours = seconds // 3600
        return f"{hours} hour" + ("s" if hours != 1 else "")
    if seconds % 60 == 0 and seconds >= 60:
        minutes = seconds // 60
        return f"{minutes} minute" + ("s" if minutes != 1 else "")
    return f"{seconds} second" + ("s" if seconds != 1 else "")


def validate_digest(value: Any, *, label: str = "digest") -> str:
    text = str(value or "").strip().lower()
    if not _SHA256_RE.fullmatch(text):
        raise CadenceError(f"invalid {label}")
    return text


def validate_identifier(value: Any, *, label: str = "identifier") -> str:
    text = str(value or "").strip()
    if not _ID_RE.fullmatch(text):
        raise CadenceError(f"invalid {label}")
    return text


def deterministic_jitter(plan_id: str, sequence: int, maximum: int) -> int:
    maximum = max(0, int(maximum))
    if maximum == 0:
        return 0
    digest = hashlib.sha256(f"ProgRSS/Pulse/jitter/v1\0{plan_id}\0{int(sequence)}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big") % (maximum + 1)


def parse_retry_after(value: Any, *, now: float | None = None, maximum: int = MAX_BACKOFF_SECONDS) -> RetryAfter | None:
    """Parse bounded delta-seconds or HTTP-date Retry-After.

    Invalid, past, or unreasonably distant values do not become negative waits or
    unbounded scheduler authority.  A valid value is clamped to ``maximum``.
    """
    raw = str(value or "").strip()
    if not raw:
        return None
    current = time.time() if now is None else float(now)
    if raw.isdigit():
        seconds = int(raw)
        return RetryAfter(raw=raw[:128], seconds=max(0, min(seconds, int(maximum))), kind="delay-seconds")
    try:
        parsed = email.utils.parsedate_to_datetime(raw)
    except (TypeError, ValueError, OverflowError):
        return None
    if parsed is None:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=_dt.timezone.utc)
    seconds = max(0, int(math.ceil(parsed.timestamp() - current)))
    return RetryAfter(raw=raw[:128], seconds=min(seconds, int(maximum)), kind="http-date")


def next_wait_seconds(outcome: str, *, interval: int, failures: int, retry_after: RetryAfter | None) -> int:
    if outcome in SUCCESS_OUTCOMES:
        base = interval
    elif outcome in TEMPORARY_OUTCOMES:
        base = min(MAX_BACKOFF_SECONDS, interval * (2 ** max(1, min(int(failures), 6))))
    else:
        base = interval
    if retry_after is not None:
        base = max(base, retry_after.seconds)
    return max(MIN_INTERVAL_SECONDS, min(int(base), MAX_BACKOFF_SECONDS))


def random_id(prefix: str, *, bytes_count: int = 18) -> str:
    return f"{prefix}{secrets.token_urlsafe(bytes_count)}"


def release_identity() -> dict[str, str]:
    return {"version": VERSION, "revision": REVISION, "codename": CODENAME}


def json_object(value: Any, *, label: str = "JSON object") -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise CadenceError(f"{label} must be an object")
    return dict(value)
