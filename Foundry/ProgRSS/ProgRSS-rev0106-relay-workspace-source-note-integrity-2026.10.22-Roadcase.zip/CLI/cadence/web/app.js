(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const state = {token:'', status:null, busy:false};

  function takeToken(){
    const hash = new URLSearchParams(location.hash.slice(1));
    const incoming = hash.get('token');
    if(incoming){ sessionStorage.setItem('progrss.pulse.token', incoming); history.replaceState(null,'',location.pathname+location.search); }
    state.token = sessionStorage.getItem('progrss.pulse.token') || '';
  }
  function esc(value){ return String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function duration(seconds){
    const s=Number(seconds)||0;
    if(s%86400===0&&s>=86400)return `${s/86400} day${s===86400?'':'s'}`;
    if(s%3600===0&&s>=3600)return `${s/3600} hour${s===3600?'':'s'}`;
    if(s%60===0&&s>=60)return `${s/60} minute${s===60?'':'s'}`;
    return `${s} seconds`;
  }
  function humanize(value){ const text=String(value||'').replaceAll('-',' '); return text ? text[0].toUpperCase()+text.slice(1) : 'Not recorded'; }
  function dateTime(value){
    const parsed=new Date(String(value||''));
    if(Number.isNaN(parsed.getTime()))return String(value||'Not scheduled');
    return new Intl.DateTimeFormat(undefined,{year:'numeric',month:'short',day:'numeric',hour:'numeric',minute:'2-digit',timeZoneName:'short'}).format(parsed);
  }
  async function api(path, options={}){
    const headers = new Headers(options.headers||{});
    headers.set('Authorization',`Bearer ${state.token}`);
    if(options.body&&!headers.has('Content-Type'))headers.set('Content-Type','application/json');
    const response=await fetch(path,{...options,headers,credentials:'omit',cache:'no-store'});
    const data=await response.json().catch(()=>({error:`HTTP ${response.status}`}));
    if(!response.ok)throw new Error(data.error||`HTTP ${response.status}`);
    return data;
  }
  function setMessage(message,error=false){ const box=$('status'); box.textContent=message||''; box.style.color=error?'var(--danger)':'var(--cyan)'; }
  function setBusy(value){ state.busy=!!value; for(const id of ['start','stop','run-once','create-plan']) $(id).disabled = state.busy || ($(id).dataset.baseDisabled==='true'); }

  function renderReview(review){
    const section=$('review-section');
    if(!review){ section.hidden=true; return; }
    section.hidden=false;
    const source=review.source||{}, timing=review.timing||{}, eligibility=review.eligibility||{};
    $('review-body').innerHTML=`
      <div class="review-grid">
        <div class="fact"><span>Source</span><b>${esc(source.title)}</b><small>${esc(source.site)}</small></div>
        <div class="fact"><span>Timing</span><b>Every ${esc(timing.intervalLabel)}</b><small>${esc(timing.initialState)}</small></div>
        <div class="fact"><span>Qualifying check</span><b>${esc(humanize(eligibility.outcome))}</b><small>${esc(eligibility.nodeSiteRequests)} Node request${Number(eligibility.nodeSiteRequests)===1?'':'s'}</small></div>
      </div>
      <ul class="consequence-list">
        <li>Review and creation contact no source.</li>
        <li>The first eligible check falls between <time datetime="${esc(timing.earliestFirstCheckAt)}">${esc(dateTime(timing.earliestFirstCheckAt))}</time> and <time datetime="${esc(timing.latestFirstCheckAt)}">${esc(dateTime(timing.latestFirstCheckAt))}</time>.</li>
        <li>Creating this plan does not start the foreground scheduler.</li>
        <li>Pause means zero requests through Cadence.</li>
        <li>Browser-assisted and browser-only captures remain unscheduled.</li>
      </ul>`;
    $('ack').checked=false;
    $('create-plan').disabled=true;
    $('create-plan').dataset.baseDisabled='true';
  }

  function renderPlans(plans){
    $('plan-count').textContent=String(plans.length);
    $('empty').hidden=plans.length>0;
    const root=$('plans'); root.textContent='';
    for(const plan of plans){
      const card=document.createElement('article'); card.className='plan-card';
      const next=plan.nextDueAt||'Not scheduled';
      const last=plan.lastOutcome?humanize(plan.lastOutcome):'Not checked by Cadence yet';
      card.innerHTML=`<div><h3>${esc(plan.sourceTitle)}</h3><p>${esc(plan.sourceHost)} · ${esc(plan.sourceType==='rss'?'Feed':'Watched page')}</p><div class="plan-meta"><span class="mini-chip">${esc(plan.state)}</span><span class="mini-chip">every ${esc(duration(plan.intervalSeconds))}</span><span class="mini-chip">last: ${esc(last)}</span></div><p>Next eligible: <b><time datetime="${esc(next)}">${esc(dateTime(next))}</time></b></p>${plan.blockedReason?`<p>${esc(plan.blockedReason)}</p>`:''}</div><div class="plan-actions"></div>`;
      const button=document.createElement('button'); button.className='button '+(plan.state==='scheduled'?'quiet':'secondary'); button.type='button'; button.textContent=plan.state==='scheduled'?'Pause':'Resume';
      button.addEventListener('click',()=>planAction(plan.planId,plan.state==='scheduled'?'pause':'resume'));
      card.querySelector('.plan-actions').append(button); root.append(card);
    }
  }

  function render(document){
    state.status=document;
    const running=!!document.scheduler?.running;
    $('running-word').textContent=running?'running':'stopped';
    $('session-state').textContent=running?'Running':'Stopped';
    $('session-state').className='state '+(running?'running':'stopped');
    $('session-explainer').textContent=running?'This foreground process is dispatching only due, scheduled, reproducible plans. Closing it stops automatic checks.':'Opening this page made no source request. Closing this Node process stops automatic checks.';
    $('start').disabled=running; $('start').dataset.baseDisabled=running?'true':'false';
    $('stop').disabled=!running; $('stop').dataset.baseDisabled=!running?'true':'false';
    $('run-once').disabled=running; $('run-once').dataset.baseDisabled=running?'true':'false';
    renderReview(document.reviewAvailable?document.review:null);
    renderPlans(document.plans||[]);
    $('adapter').textContent=document.adapter?.packagedWitness?'Packaged Witness':'External runner';
    $('database').textContent=document.database?.file||'—';
    $('library').textContent=document.database?.nodeStoreFile||'—';
    $('slots').textContent=String((document.recentSlots||[]).length);
    $('evidence').textContent=JSON.stringify({database:document.database,adapter:document.adapter,scheduler:document.scheduler,capabilities:document.capabilities,recentSlots:document.recentSlots},null,2);
  }

  async function refresh(){
    try{ render(await api('/api/v1/status')); }
    catch(error){ setMessage(error.message,true); }
  }
  async function action(path,message){
    if(state.busy)return; setBusy(true); setMessage(message);
    try{ await api(path,{method:'POST',body:'{}'}); await refresh(); setMessage('Done.'); }
    catch(error){ setMessage(error.message,true); }
    finally{ setBusy(false); }
  }
  async function planAction(id,verb){ await action(`/api/v1/plans/${encodeURIComponent(id)}/${verb}`,verb==='pause'?'Pausing…':'Rescheduling…'); }

  $('start').addEventListener('click',()=>action('/api/v1/scheduler/start','Starting the foreground scheduler…'));
  $('stop').addEventListener('click',()=>action('/api/v1/scheduler/stop','Stopping…'));
  $('run-once').addEventListener('click',()=>action('/api/v1/run-due','Checking currently due plans…'));
  $('ack').addEventListener('change',()=>{ $('create-plan').disabled=!$('ack').checked||state.busy; $('create-plan').dataset.baseDisabled=$('ack').checked?'false':'true'; });
  $('create-plan').addEventListener('click',async()=>{
    if(!$('ack').checked||!state.status?.review)return; setBusy(true); setMessage('Creating the local timing plan…');
    try{ await api('/api/v1/plans',{method:'POST',body:JSON.stringify({acknowledge:true,reviewDigest:state.status.review.reviewDigest})}); await refresh(); setMessage('Timing plan created. No source was contacted and the scheduler remains stopped.'); }
    catch(error){ setMessage(error.message,true); } finally{setBusy(false);}
  });

  const themeKey='progrss.pulse.theme';
  function setTheme(theme){ document.documentElement.dataset.theme=theme; localStorage.setItem(themeKey,theme); $('theme').textContent=theme==='light'?'◐':'☼'; $('theme').setAttribute('aria-label',theme==='light'?'Use dark theme':'Use light theme'); }
  $('theme').addEventListener('click',()=>setTheme(document.documentElement.dataset.theme==='light'?'dark':'light'));
  setTheme(localStorage.getItem(themeKey)==='light'?'light':'dark');
  takeToken();
  if(!state.token){setMessage('The Pulse capability is missing. Reopen the exact URL printed by the CLI.',true);return;}
  refresh();
})();
