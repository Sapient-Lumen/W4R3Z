from __future__ import annotations

import json
import os
import secrets
import sqlite3
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from .common import (
    CadenceBusy,
    CadenceConflict,
    CadenceError,
    LIST_SCHEMA,
    PLAN_SCHEMA,
    SLOT_SCHEMA,
    STORE_SCHEMA,
    canonical_bytes,
    iso_utc,
    parse_iso,
    random_id,
    sha256_bytes,
)

APPLICATION_ID = 0x50525343  # PRSC
USER_VERSION = 1


@dataclass(frozen=True, slots=True)
class SlotStart:
    slot: dict[str, Any]
    replayed: bool
    resumed: bool


class CadenceStore:
    """Node-local timing plans, durable due slots, leases, and host budgets."""

    def __init__(self, path: Path):
        self.path = Path(path).expanduser().resolve()
        if not self.path.is_file() or self.path.is_symlink():
            raise CadenceError("the Cadence database must be one regular local file")
        self._verify()

    @classmethod
    def create(cls, path: Path, *, node_store_id: str, node_store_path: Path, now: float | None = None) -> dict[str, Any]:
        output = Path(path).expanduser().resolve()
        if output.exists():
            raise CadenceError("Cadence database already exists; existing files are never overwritten")
        output.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix=f".{output.name}.", suffix=".tmp", dir=output.parent)
        os.close(fd)
        temp = Path(temp_name)
        created_at = iso_utc(now)
        database_id = random_id("cad_")
        try:
            connection = sqlite3.connect(temp, timeout=5.0, isolation_level=None)
            try:
                connection.execute(f"PRAGMA application_id={APPLICATION_ID}")
                connection.execute(f"PRAGMA user_version={USER_VERSION}")
                connection.execute("PRAGMA journal_mode=WAL")
                connection.execute("PRAGMA synchronous=FULL")
                connection.executescript(
                    """
                    BEGIN IMMEDIATE;
                    CREATE TABLE metadata (
                        key TEXT PRIMARY KEY,
                        value TEXT NOT NULL
                    );
                    CREATE TABLE plans (
                        plan_id TEXT PRIMARY KEY,
                        source_id TEXT NOT NULL UNIQUE,
                        source_title TEXT NOT NULL,
                        source_type TEXT NOT NULL,
                        source_host TEXT NOT NULL,
                        source_identity_sha256 TEXT NOT NULL,
                        node_store_id TEXT NOT NULL,
                        eligibility_receipt_id TEXT NOT NULL,
                        eligibility_operation_id TEXT NOT NULL,
                        eligibility_result_sha256 TEXT NOT NULL,
                        interval_seconds INTEGER NOT NULL,
                        jitter_seconds INTEGER NOT NULL,
                        state TEXT NOT NULL CHECK(state IN ('scheduled','paused')),
                        sequence INTEGER NOT NULL DEFAULT 0,
                        failure_count INTEGER NOT NULL DEFAULT 0,
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL,
                        next_due_at TEXT NOT NULL,
                        last_due_at TEXT,
                        last_outcome TEXT,
                        last_receipt_id TEXT,
                        last_result_json BLOB,
                        blocked_reason TEXT NOT NULL DEFAULT ''
                    );
                    CREATE INDEX plans_next_due ON plans(state, next_due_at);
                    CREATE TABLE due_slots (
                        slot_id TEXT PRIMARY KEY,
                        plan_id TEXT NOT NULL REFERENCES plans(plan_id),
                        due_at TEXT NOT NULL,
                        request_sha256 TEXT NOT NULL,
                        state TEXT NOT NULL CHECK(state IN ('preparing','started','completed')),
                        attempt_count INTEGER NOT NULL DEFAULT 0,
                        prepared_json BLOB,
                        result_json BLOB,
                        created_at TEXT NOT NULL,
                        started_at TEXT,
                        completed_at TEXT,
                        last_error TEXT NOT NULL DEFAULT ''
                    );
                    CREATE INDEX due_slots_plan ON due_slots(plan_id, due_at DESC);
                    CREATE TABLE lease (
                        singleton INTEGER PRIMARY KEY CHECK(singleton=1),
                        owner_id TEXT NOT NULL,
                        acquired_at TEXT NOT NULL,
                        heartbeat_at TEXT NOT NULL,
                        expires_at TEXT NOT NULL
                    );
                    CREATE TABLE origin_budgets (
                        origin TEXT PRIMARY KEY,
                        next_allowed_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL
                    );
                    COMMIT;
                    """
                )
                connection.execute("BEGIN IMMEDIATE")
                connection.executemany(
                    "INSERT INTO metadata(key,value) VALUES (?,?)",
                    (
                        ("schema", STORE_SCHEMA),
                        ("databaseId", database_id),
                        ("createdAt", created_at),
                        ("nodeStoreId", str(node_store_id)),
                        ("nodeStorePath", str(Path(node_store_path).expanduser().resolve())),
                    ),
                )
                connection.execute("COMMIT")
                check = connection.execute("PRAGMA quick_check").fetchone()
                if not check or check[0] != "ok":
                    raise CadenceError("Cadence database failed SQLite quick_check")
            finally:
                connection.close()
            os.chmod(temp, 0o600)
            os.replace(temp, output)
            try:
                directory_fd = os.open(output.parent, os.O_RDONLY)
                try:
                    os.fsync(directory_fd)
                finally:
                    os.close(directory_fd)
            except OSError:
                pass
        except Exception:
            try:
                temp.unlink()
            except OSError:
                pass
            raise
        store = cls(output)
        return {
            "schema": STORE_SCHEMA,
            "state": "created",
            "file": output.name,
            "databaseId": store.database_id,
            "nodeStoreId": store.node_store_id,
            "nodeStorePath": str(store.node_store_path),
            "createdAt": created_at,
            "network": False,
            "writes": True,
        }

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=5.0, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA busy_timeout=5000")
        return connection

    def _verify(self) -> None:
        try:
            connection = self._connect()
            try:
                app_id = int(connection.execute("PRAGMA application_id").fetchone()[0])
                version = int(connection.execute("PRAGMA user_version").fetchone()[0])
                if app_id != APPLICATION_ID or version != USER_VERSION:
                    raise CadenceError("the SQLite file is not a supported ProgRSS Cadence database")
                metadata = {str(row[0]): str(row[1]) for row in connection.execute("SELECT key,value FROM metadata")}
                if metadata.get("schema") != STORE_SCHEMA or not metadata.get("databaseId") or not metadata.get("nodeStoreId"):
                    raise CadenceError("the Cadence database metadata is incomplete")
                check = connection.execute("PRAGMA quick_check").fetchone()
                if not check or check[0] != "ok":
                    raise CadenceError("the Cadence database failed SQLite quick_check")
            finally:
                connection.close()
        except sqlite3.Error as exc:
            raise CadenceError(f"could not open Cadence database: {exc}") from exc

    def metadata(self) -> dict[str, str]:
        connection = self._connect()
        try:
            return {str(row[0]): str(row[1]) for row in connection.execute("SELECT key,value FROM metadata ORDER BY key")}
        finally:
            connection.close()

    @property
    def database_id(self) -> str:
        return self.metadata()["databaseId"]

    @property
    def node_store_id(self) -> str:
        return self.metadata()["nodeStoreId"]

    @property
    def node_store_path(self) -> Path:
        return Path(self.metadata()["nodeStorePath"]).expanduser().resolve()

    @staticmethod
    def _decode_json(raw: Any) -> dict[str, Any] | None:
        if raw is None:
            return None
        try:
            value = json.loads(bytes(raw).decode("utf-8"))
        except (TypeError, UnicodeDecodeError, json.JSONDecodeError):
            return None
        return value if isinstance(value, dict) else None

    @classmethod
    def _plan_from_row(cls, row: sqlite3.Row) -> dict[str, Any]:
        return {
            "schema": PLAN_SCHEMA,
            "planId": str(row["plan_id"]),
            "sourceId": str(row["source_id"]),
            "sourceTitle": str(row["source_title"]),
            "sourceType": str(row["source_type"]),
            "sourceHost": str(row["source_host"]),
            "sourceIdentitySha256": str(row["source_identity_sha256"]),
            "nodeStoreId": str(row["node_store_id"]),
            "eligibilityReceiptId": str(row["eligibility_receipt_id"]),
            "eligibilityOperationId": str(row["eligibility_operation_id"]),
            "eligibilityResultLibrarySha256": str(row["eligibility_result_sha256"]),
            "intervalSeconds": int(row["interval_seconds"]),
            "jitterSeconds": int(row["jitter_seconds"]),
            "state": str(row["state"]),
            "sequence": int(row["sequence"]),
            "failureCount": int(row["failure_count"]),
            "createdAt": str(row["created_at"]),
            "updatedAt": str(row["updated_at"]),
            "nextDueAt": str(row["next_due_at"]),
            "lastDueAt": str(row["last_due_at"] or ""),
            "lastOutcome": str(row["last_outcome"] or ""),
            "lastReceiptId": str(row["last_receipt_id"] or ""),
            "lastResult": cls._decode_json(row["last_result_json"]),
            "blockedReason": str(row["blocked_reason"] or ""),
        }

    @classmethod
    def _slot_from_row(cls, row: sqlite3.Row) -> dict[str, Any]:
        return {
            "schema": SLOT_SCHEMA,
            "slotId": str(row["slot_id"]),
            "planId": str(row["plan_id"]),
            "dueAt": str(row["due_at"]),
            "requestSha256": str(row["request_sha256"]),
            "state": str(row["state"]),
            "attemptCount": int(row["attempt_count"]),
            "prepared": cls._decode_json(row["prepared_json"]),
            "result": cls._decode_json(row["result_json"]),
            "createdAt": str(row["created_at"]),
            "startedAt": str(row["started_at"] or ""),
            "completedAt": str(row["completed_at"] or ""),
            "lastError": str(row["last_error"] or ""),
        }

    def add_plan(self, plan: Mapping[str, Any]) -> dict[str, Any]:
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """INSERT INTO plans(
                    plan_id,source_id,source_title,source_type,source_host,source_identity_sha256,
                    node_store_id,eligibility_receipt_id,eligibility_operation_id,eligibility_result_sha256,
                    interval_seconds,jitter_seconds,state,sequence,failure_count,created_at,updated_at,
                    next_due_at,last_due_at,last_outcome,last_receipt_id,last_result_json,blocked_reason
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,0,0,?,?,?,NULL,NULL,NULL,NULL,'')""",
                (
                    plan["planId"], plan["sourceId"], plan["sourceTitle"], plan["sourceType"], plan["sourceHost"],
                    plan["sourceIdentitySha256"], plan["nodeStoreId"], plan["eligibilityReceiptId"],
                    plan["eligibilityOperationId"], plan["eligibilityResultLibrarySha256"], int(plan["intervalSeconds"]),
                    int(plan["jitterSeconds"]), plan["state"], plan["createdAt"], plan["updatedAt"], plan["nextDueAt"],
                ),
            )
            connection.execute("COMMIT")
        except sqlite3.IntegrityError as exc:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            if "source_id" in str(exc).lower() or "unique" in str(exc).lower():
                raise CadenceConflict("this source already has a Cadence plan") from exc
            raise CadenceError(f"could not create timing plan: {exc}") from exc
        except sqlite3.Error as exc:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise CadenceError(f"could not create timing plan: {exc}") from exc
        finally:
            connection.close()
        return self.get_plan(str(plan["planId"]))

    def get_plan(self, plan_id: str) -> dict[str, Any]:
        connection = self._connect()
        try:
            row = connection.execute("SELECT * FROM plans WHERE plan_id=?", (plan_id,)).fetchone()
            if row is None:
                raise CadenceError("timing plan was not found")
            return self._plan_from_row(row)
        finally:
            connection.close()

    def list_plans(self) -> list[dict[str, Any]]:
        connection = self._connect()
        try:
            rows = connection.execute("SELECT * FROM plans ORDER BY source_title COLLATE NOCASE, plan_id").fetchall()
            return [self._plan_from_row(row) for row in rows]
        finally:
            connection.close()

    def list_document(self) -> dict[str, Any]:
        plans = self.list_plans()
        return {
            "schema": LIST_SCHEMA,
            "databaseId": self.database_id,
            "nodeStoreId": self.node_store_id,
            "plans": plans,
            "counts": {
                "total": len(plans),
                "scheduled": sum(1 for row in plans if row["state"] == "scheduled"),
                "paused": sum(1 for row in plans if row["state"] == "paused"),
            },
            "network": False,
            "writes": False,
        }

    def set_plan_state(self, plan_id: str, state: str, *, now: float, next_due_at: str | None = None, reason: str = "") -> dict[str, Any]:
        if state not in {"scheduled", "paused"}:
            raise CadenceError("timing-plan state must be scheduled or paused")
        updated_at = iso_utc(now)
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT * FROM plans WHERE plan_id=?", (plan_id,)).fetchone()
            if row is None:
                connection.execute("ROLLBACK")
                raise CadenceError("timing plan was not found")
            due = next_due_at or str(row["next_due_at"])
            connection.execute(
                "UPDATE plans SET state=?, updated_at=?, next_due_at=?, blocked_reason=? WHERE plan_id=?",
                (state, updated_at, due, reason[:300], plan_id),
            )
            connection.execute("COMMIT")
        except CadenceError:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise
        except sqlite3.Error as exc:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise CadenceError(f"could not update timing plan: {exc}") from exc
        finally:
            connection.close()
        return self.get_plan(plan_id)

    def due_plans(self, *, now: float, limit: int = 20) -> list[dict[str, Any]]:
        stamp = iso_utc(now)
        connection = self._connect()
        try:
            rows = connection.execute(
                "SELECT * FROM plans WHERE state='scheduled' AND next_due_at<=? ORDER BY next_due_at, plan_id LIMIT ?",
                (stamp, max(1, min(int(limit), 100))),
            ).fetchall()
            return [self._plan_from_row(row) for row in rows]
        finally:
            connection.close()

    def latest_slot_for_plan(self, plan_id: str) -> dict[str, Any] | None:
        connection = self._connect()
        try:
            row = connection.execute("SELECT * FROM due_slots WHERE plan_id=? ORDER BY due_at DESC LIMIT 1", (plan_id,)).fetchone()
            return self._slot_from_row(row) if row else None
        finally:
            connection.close()

    def start_slot(self, *, slot_id: str, plan_id: str, due_at: str, request_sha256: str, now: float) -> SlotStart:
        created_at = iso_utc(now)
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT * FROM due_slots WHERE slot_id=?", (slot_id,)).fetchone()
            if row is not None:
                slot = self._slot_from_row(row)
                if not secrets.compare_digest(slot["requestSha256"], request_sha256):
                    connection.execute("ROLLBACK")
                    raise CadenceConflict("that due-slot identity was already used for different content")
                connection.execute("ROLLBACK")
                return SlotStart(slot=slot, replayed=slot["state"] == "completed", resumed=slot["state"] != "completed")
            connection.execute(
                "INSERT INTO due_slots(slot_id,plan_id,due_at,request_sha256,state,attempt_count,created_at) VALUES (?,?,?,?, 'preparing',0,?)",
                (slot_id, plan_id, due_at, request_sha256, created_at),
            )
            connection.execute("COMMIT")
            return SlotStart(slot=self.get_slot(slot_id), replayed=False, resumed=False)
        except (CadenceConflict, CadenceError):
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise
        except sqlite3.Error as exc:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise CadenceError(f"could not persist due slot: {exc}") from exc
        finally:
            connection.close()

    def get_slot(self, slot_id: str) -> dict[str, Any]:
        connection = self._connect()
        try:
            row = connection.execute("SELECT * FROM due_slots WHERE slot_id=?", (slot_id,)).fetchone()
            if row is None:
                raise CadenceError("due slot was not found")
            return self._slot_from_row(row)
        finally:
            connection.close()

    def set_slot_prepared(self, slot_id: str, prepared: Mapping[str, Any], *, now: float) -> dict[str, Any]:
        raw = canonical_bytes(dict(prepared))
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT state,attempt_count FROM due_slots WHERE slot_id=?", (slot_id,)).fetchone()
            if row is None:
                connection.execute("ROLLBACK")
                raise CadenceError("due slot was not found")
            if str(row["state"]) == "completed":
                connection.execute("ROLLBACK")
                return self.get_slot(slot_id)
            connection.execute(
                "UPDATE due_slots SET state='started', prepared_json=?, attempt_count=?, started_at=?, last_error='' WHERE slot_id=?",
                (sqlite3.Binary(raw), int(row["attempt_count"]) + 1, iso_utc(now), slot_id),
            )
            connection.execute("COMMIT")
            return self.get_slot(slot_id)
        except CadenceError:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise
        except sqlite3.Error as exc:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise CadenceError(f"could not persist prepared dispatch: {exc}") from exc
        finally:
            connection.close()

    def mark_slot_error(self, slot_id: str, message: str) -> None:
        connection = self._connect()
        try:
            connection.execute("UPDATE due_slots SET last_error=? WHERE slot_id=? AND state!='completed'", (str(message)[:500], slot_id))
        finally:
            connection.close()

    def complete_slot(
        self,
        *,
        slot_id: str,
        result: Mapping[str, Any],
        outcome: str,
        receipt_id: str,
        plan_state: str,
        next_due_at: str,
        failure_count: int,
        blocked_reason: str,
        now: float,
    ) -> dict[str, Any]:
        result_raw = canonical_bytes(dict(result))
        completed_at = iso_utc(now)
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            slot = connection.execute("SELECT * FROM due_slots WHERE slot_id=?", (slot_id,)).fetchone()
            if slot is None:
                connection.execute("ROLLBACK")
                raise CadenceError("due slot was not found")
            if str(slot["state"]) == "completed":
                connection.execute("ROLLBACK")
                existing = self.get_slot(slot_id)
                return existing["result"] or dict(result)
            connection.execute(
                "UPDATE due_slots SET state='completed', result_json=?, completed_at=?, last_error='' WHERE slot_id=?",
                (sqlite3.Binary(result_raw), completed_at, slot_id),
            )
            connection.execute(
                """UPDATE plans SET state=?, sequence=sequence+1, failure_count=?, updated_at=?, next_due_at=?,
                   last_due_at=?, last_outcome=?, last_receipt_id=?, last_result_json=?, blocked_reason=? WHERE plan_id=?""",
                (
                    plan_state, max(0, int(failure_count)), completed_at, next_due_at, str(slot["due_at"]),
                    str(outcome)[:80], str(receipt_id)[:160], sqlite3.Binary(result_raw), str(blocked_reason)[:300], str(slot["plan_id"]),
                ),
            )
            connection.execute("COMMIT")
            return dict(result)
        except CadenceError:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise
        except sqlite3.Error as exc:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise CadenceError(f"could not complete due slot atomically: {exc}") from exc
        finally:
            connection.close()

    def recent_slots(self, limit: int = 50) -> list[dict[str, Any]]:
        connection = self._connect()
        try:
            rows = connection.execute("SELECT * FROM due_slots ORDER BY created_at DESC LIMIT ?", (max(1, min(int(limit), 100)),)).fetchall()
            return [self._slot_from_row(row) for row in rows]
        finally:
            connection.close()

    def acquire_lease(self, owner_id: str, *, now: float, seconds: int) -> dict[str, Any]:
        acquired_at = iso_utc(now)
        expires_at = iso_utc(now + max(5, int(seconds)))
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT owner_id,expires_at FROM lease WHERE singleton=1").fetchone()
            if row is not None and str(row["owner_id"]) != owner_id and parse_iso(row["expires_at"]) > now:
                connection.execute("ROLLBACK")
                raise CadenceBusy("another live Cadence scheduler owns this timing database")
            connection.execute(
                "INSERT INTO lease(singleton,owner_id,acquired_at,heartbeat_at,expires_at) VALUES (1,?,?,?,?) "
                "ON CONFLICT(singleton) DO UPDATE SET owner_id=excluded.owner_id, acquired_at=excluded.acquired_at, heartbeat_at=excluded.heartbeat_at, expires_at=excluded.expires_at",
                (owner_id, acquired_at, acquired_at, expires_at),
            )
            connection.execute("COMMIT")
            return {"ownerId": owner_id, "acquiredAt": acquired_at, "expiresAt": expires_at}
        except CadenceBusy:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise
        except sqlite3.Error as exc:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise CadenceError(f"could not acquire scheduler lease: {exc}") from exc
        finally:
            connection.close()

    def renew_lease(self, owner_id: str, *, now: float, seconds: int) -> dict[str, Any]:
        heartbeat = iso_utc(now)
        expires = iso_utc(now + max(5, int(seconds)))
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute("SELECT owner_id,acquired_at FROM lease WHERE singleton=1").fetchone()
            if row is None or str(row["owner_id"]) != owner_id:
                connection.execute("ROLLBACK")
                raise CadenceBusy("scheduler lease is no longer owned by this process")
            connection.execute("UPDATE lease SET heartbeat_at=?,expires_at=? WHERE singleton=1", (heartbeat, expires))
            connection.execute("COMMIT")
            return {"ownerId": owner_id, "acquiredAt": str(row["acquired_at"]), "heartbeatAt": heartbeat, "expiresAt": expires}
        except CadenceBusy:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise
        except sqlite3.Error as exc:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise CadenceError(f"could not renew scheduler lease: {exc}") from exc
        finally:
            connection.close()

    def release_lease(self, owner_id: str) -> None:
        connection = self._connect()
        try:
            connection.execute("DELETE FROM lease WHERE singleton=1 AND owner_id=?", (owner_id,))
        finally:
            connection.close()

    def lease_status(self, *, now: float | None = None) -> dict[str, Any] | None:
        connection = self._connect()
        try:
            row = connection.execute("SELECT * FROM lease WHERE singleton=1").fetchone()
            if row is None:
                return None
            current = parse_iso(iso_utc() if now is None else iso_utc(now))
            expires = parse_iso(row["expires_at"])
            return {
                "ownerId": str(row["owner_id"]),
                "acquiredAt": str(row["acquired_at"]),
                "heartbeatAt": str(row["heartbeat_at"]),
                "expiresAt": str(row["expires_at"]),
                "live": expires > current,
            }
        finally:
            connection.close()

    def origin_next_allowed(self, origin: str) -> float | None:
        connection = self._connect()
        try:
            row = connection.execute("SELECT next_allowed_at FROM origin_budgets WHERE origin=?", (origin,)).fetchone()
            return parse_iso(row[0]) if row else None
        finally:
            connection.close()

    def set_origin_next_allowed(self, origin: str, *, timestamp: float, now: float) -> None:
        connection = self._connect()
        try:
            connection.execute(
                "INSERT INTO origin_budgets(origin,next_allowed_at,updated_at) VALUES (?,?,?) "
                "ON CONFLICT(origin) DO UPDATE SET next_allowed_at=excluded.next_allowed_at,updated_at=excluded.updated_at",
                (origin, iso_utc(timestamp), iso_utc(now)),
            )
        finally:
            connection.close()

    def defer_plan(self, plan_id: str, *, next_due_at: float, reason: str, now: float) -> dict[str, Any]:
        connection = self._connect()
        try:
            connection.execute(
                "UPDATE plans SET next_due_at=?,updated_at=?,blocked_reason=? WHERE plan_id=?",
                (iso_utc(next_due_at), iso_utc(now), str(reason)[:300], plan_id),
            )
        finally:
            connection.close()
        return self.get_plan(plan_id)


__all__ = ["CadenceStore", "SlotStart", "APPLICATION_ID", "USER_VERSION"]
