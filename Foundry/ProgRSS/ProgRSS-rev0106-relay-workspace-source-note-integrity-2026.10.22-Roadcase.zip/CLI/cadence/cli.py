from __future__ import annotations

import argparse
import json
import signal
import sys
import time
from pathlib import Path
from typing import Any

from node_store import NodeStore, NodeStoreError

from . import CODENAME, REVISION, VERSION
from .common import (
    CadenceError,
    MAX_INTERVAL_SECONDS,
    MAX_JITTER_SECONDS,
    MIN_INTERVAL_SECONDS,
    format_duration,
    parse_duration,
)
from .service import CadenceService
from .store import CadenceStore


def _emit(value: dict[str, Any], *, as_json: bool, human: str | None = None) -> None:
    if as_json:
        print(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
    elif human is not None:
        print(human)
    else:
        print(json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True))


def _duration(value: str) -> int:
    try:
        return parse_duration(value, minimum=MIN_INTERVAL_SECONDS, maximum=MAX_INTERVAL_SECONDS, label="schedule interval")
    except CadenceError as exc:
        raise argparse.ArgumentTypeError(str(exc)) from exc


def _jitter(value: str) -> int:
    try:
        return parse_duration(value, minimum=0, maximum=MAX_JITTER_SECONDS, label="jitter")
    except CadenceError as exc:
        # parse_duration does not accept literal zero through its range guard.
        if str(value).strip() in {"0", "0s", "0m", "0h"}:
            return 0
        raise argparse.ArgumentTypeError(str(exc)) from exc


def _service(args: argparse.Namespace) -> CadenceService:
    return CadenceService(
        args.database,
        node_store_path=getattr(args, "node_store", None),
        runner=getattr(args, "runner", None),
        origin_gap_seconds=getattr(args, "origin_gap", 10),
    )


def cmd_init(args: argparse.Namespace) -> int:
    try:
        node = NodeStore(args.node_store)
    except NodeStoreError as exc:
        raise CadenceError(str(exc)) from exc
    result = CadenceStore.create(
        args.database,
        node_store_id=node.store_id,
        node_store_path=args.node_store,
    )
    _emit(
        result,
        as_json=args.json,
        human=(
            f"Created Cadence database: {args.database}\n"
            f"Bound Node store: {args.node_store.name}\n"
            "No source was contacted. No scheduler session was started."
        ),
    )
    return 0


def cmd_review(args: argparse.Namespace) -> int:
    result = _service(args).review_plan(
        args.receipt,
        interval_seconds=args.every,
        jitter_seconds=args.jitter,
        start_paused=args.start_paused,
    )
    source = result["source"]
    timing = result["timing"]
    _emit(
        result,
        as_json=args.json,
        human=(
            f"Review schedule for {source['title']} ({source['site']})\n"
            f"Every: {timing['intervalLabel']}\n"
            f"First eligible check: {timing['earliestFirstCheckAt']} to {timing['latestFirstCheckAt']}\n"
            f"Starts: {timing['initialState']}\n"
            "Review and creation contact no site and do not start the foreground scheduler."
        ),
    )
    return 0


def cmd_create(args: argparse.Namespace) -> int:
    result = _service(args).create_plan(
        args.receipt,
        interval_seconds=args.every,
        jitter_seconds=args.jitter,
        start_paused=args.start_paused,
        acknowledge=args.acknowledge,
    )
    plan = result["plan"]
    _emit(
        result,
        as_json=args.json,
        human=(
            f"Created timing plan {plan['planId']}\n"
            f"Source: {plan['sourceTitle']} · {plan['sourceHost']}\n"
            f"State: {plan['state']}\n"
            f"Next eligible check: {plan['nextDueAt']}\n"
            "No source was contacted. The foreground scheduler is still stopped."
        ),
    )
    return 0


def cmd_list(args: argparse.Namespace) -> int:
    document = _service(args).store.list_document()
    if args.json:
        _emit(document, as_json=True)
        return 0
    plans = document["plans"]
    print(f"ProgRSS Pulse · {len(plans)} timing plan{'s' if len(plans) != 1 else ''}")
    if not plans:
        print("No timing plans. Importing or sharing never creates one automatically.")
        return 0
    for plan in plans:
        outcome = plan.get("lastOutcome") or "not run"
        print(
            f"- {plan['sourceTitle']} · {plan['sourceHost']}\n"
            f"  {plan['state']} · every {format_duration(plan['intervalSeconds'])} · next {plan['nextDueAt']} · last {outcome}\n"
            f"  {plan['planId']}"
        )
    return 0


def cmd_pause(args: argparse.Namespace) -> int:
    result = _service(args).pause(args.plan_id)
    _emit(result, as_json=args.json, human="Paused. Cadence will dispatch zero requests for this plan until it is resumed.")
    return 0


def cmd_resume(args: argparse.Namespace) -> int:
    result = _service(args).resume(args.plan_id)
    plan = result["plan"]
    _emit(result, as_json=args.json, human=f"Scheduled again. Next eligible check: {plan['nextDueAt']}")
    return 0


def cmd_run_due(args: argparse.Namespace) -> int:
    result = _service(args).run_due(limit=args.limit)
    _emit(
        result,
        as_json=args.json,
        human=(
            f"Reviewed {result['duePlans']} due plan{'s' if result['duePlans'] != 1 else ''}.\n"
            f"Node site requests: {result['networkRequests']}\n"
            "Every completed attempt retains its ordinary Witness acquisition receipt."
        ),
    )
    return 0


def cmd_start(args: argparse.Namespace) -> int:
    service = _service(args)
    status = service.start_loop(poll_seconds=args.poll_seconds)
    if args.json:
        _emit({"schema": "progrss.cadence-start.v1", "scheduler": status}, as_json=True)
    else:
        print("ProgRSS Pulse foreground scheduler started.")
        print("Closing this process stops automatic dispatch. No operating-system service was installed.")
        print("Press Ctrl-C to stop.")
    interrupted = False
    try:
        while service.scheduler_status()["running"]:
            time.sleep(0.25)
    except KeyboardInterrupt:
        interrupted = True
    finally:
        stopped = service.stop_loop()
    if not args.json:
        print("ProgRSS Pulse foreground scheduler stopped.")
        if stopped.get("lastError"):
            print(f"Last scheduler error: {stopped['lastError']}", file=sys.stderr)
    return 130 if interrupted else (1 if stopped.get("lastError") else 0)


def cmd_serve(args: argparse.Namespace) -> int:
    from .server import serve

    return serve(
        args.database,
        node_store=args.node_store,
        runner=args.runner,
        port=args.port,
        open_browser=args.open,
        json_ready=args.json,
        receipt=args.receipt,
        interval=args.every,
        jitter=args.jitter,
        start_paused=args.start_paused,
        origin_gap=args.origin_gap,
    )


def add_service_options(parser: argparse.ArgumentParser, *, include_runner: bool = True) -> None:
    parser.add_argument("database", type=Path, help="ProgRSS Cadence SQLite database")
    parser.add_argument("--node-store", type=Path, help="override the bound Node store path; store identity must still match")
    if include_runner:
        parser.add_argument("--runner", type=Path, help="advanced executable Witness-compatible runner; packaged Witness is the default")
        parser.add_argument("--origin-gap", type=int, default=10, choices=range(0, 3601), metavar="0..3600", help="persistent minimum seconds between same-site dispatches")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="progrss cadence",
        description="Explicit Node-local timing plans using the packaged Witness acquisition path.",
    )
    parser.add_argument("--version", action="version", version=f"ProgRSS Cadence {VERSION} ({REVISION} · {CODENAME})")
    commands = parser.add_subparsers(dest="command", required=True)

    init = commands.add_parser("init", help="create a new Node-local timing database")
    init.add_argument("database", type=Path)
    init.add_argument("--node-store", required=True, type=Path, help="existing ProgRSS Node-owned SQLite library")
    init.add_argument("--json", action="store_true")
    init.set_defaults(func=cmd_init)

    for name, function, help_text in (
        ("review", cmd_review, "review one timing plan without networking"),
        ("create", cmd_create, "create one explicitly acknowledged timing plan"),
    ):
        sub = commands.add_parser(name, help=help_text)
        add_service_options(sub, include_runner=True)
        sub.add_argument("receipt", type=Path, help="successful public Witness acquisition receipt JSON")
        sub.add_argument("--every", required=True, type=_duration, metavar="DURATION")
        sub.add_argument("--jitter", type=_jitter, metavar="DURATION")
        sub.add_argument("--start-paused", action="store_true")
        if name == "create":
            sub.add_argument("--acknowledge", action="store_true", help="acknowledge creation of this local recurring timing plan")
        sub.add_argument("--json", action="store_true")
        sub.set_defaults(func=function)

    listing = commands.add_parser("list", help="list local timing plans")
    add_service_options(listing)
    listing.add_argument("--json", action="store_true")
    listing.set_defaults(func=cmd_list)

    for name, function in (("pause", cmd_pause), ("resume", cmd_resume)):
        sub = commands.add_parser(name, help=f"{name} one timing plan")
        add_service_options(sub)
        sub.add_argument("plan_id")
        sub.add_argument("--json", action="store_true")
        sub.set_defaults(func=function)

    due = commands.add_parser("run-due", help="dispatch currently due plans once")
    add_service_options(due)
    due.add_argument("--limit", type=int, default=20, choices=range(1, 101), metavar="1..100")
    due.add_argument("--json", action="store_true")
    due.set_defaults(func=cmd_run_due)

    start = commands.add_parser("start", help="run the foreground scheduler until this process stops")
    add_service_options(start)
    start.add_argument("--poll-seconds", type=float, default=2.0)
    start.add_argument("--json", action="store_true")
    start.set_defaults(func=cmd_start)

    serve_parser = commands.add_parser("serve", help="open the capability-protected Pulse control surface")
    add_service_options(serve_parser)
    serve_parser.add_argument("--port", type=int, default=0, choices=range(0, 65536), metavar="0..65535")
    serve_parser.add_argument("--open", action="store_true")
    serve_parser.add_argument("--json", action="store_true")
    serve_parser.add_argument("--receipt", type=Path, help="optional successful Witness receipt to review in the GUI")
    serve_parser.add_argument("--every", type=_duration, default=6 * 3600, metavar="DURATION")
    serve_parser.add_argument("--jitter", type=_jitter, metavar="DURATION")
    serve_parser.add_argument("--start-paused", action="store_true")
    serve_parser.set_defaults(func=cmd_serve)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except (CadenceError, NodeStoreError) as exc:
        if getattr(args, "json", False):
            print(json.dumps({"schema": "progrss.cadence-error.v1", "error": str(exc)}, ensure_ascii=False, separators=(",", ":")))
        else:
            print(f"progrss cadence: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
