from __future__ import annotations

import copy
import json
import os
import secrets
import subprocess
import threading
import time
import urllib.parse
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

from acquisition import acquisition_source_identity
from node_server import NodeState, PairingError
from node_store import NodeStore, NodeStoreError

from .common import (
    BLOCKING_OUTCOMES,
    CadenceBusy,
    CadenceConflict,
    CadenceError,
    DEFAULT_LEASE_SECONDS,
    DEFAULT_ORIGIN_GAP_SECONDS,
    DISPATCH_SCHEMA,
    MAX_INTERVAL_SECONDS,
    MAX_JITTER_SECONDS,
    MAX_RESULT_BYTES,
    MIN_INTERVAL_SECONDS,
    REVIEW_SCHEMA,
    SUCCESS_OUTCOMES,
    TEMPORARY_OUTCOMES,
    bounded_text,
    canonical_bytes,
    deterministic_jitter,
    format_duration,
    iso_utc,
    next_wait_seconds,
    parse_iso,
    parse_retry_after,
    random_id,
    release_identity,
    sha256_bytes,
    sha256_json,
)
from .store import CadenceStore


@dataclass(slots=True)
class PreparedDispatch:
    payload: dict[str, Any]
    node: NodeState | None


@dataclass(slots=True)
class SchedulerControl:
    running: bool = False
    owner_id: str = ""
    thread: threading.Thread | None = None
    stop_event: threading.Event | None = None
    last_error: str = ""
    last_run_at: str = ""


def _read_json_file(path: Path, *, maximum: int = MAX_RESULT_BYTES) -> dict[str, Any]:
    file_path = Path(path).expanduser().resolve()
    if not file_path.is_file() or file_path.is_symlink():
        raise CadenceError("the selected receipt must be one regular local JSON file")
    raw = file_path.read_bytes()
    if len(raw) > maximum:
        raise CadenceError("the selected receipt is too large")
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise CadenceError("the selected receipt is not valid UTF-8 JSON") from exc
    if not isinstance(value, dict):
        raise CadenceError("the selected receipt must contain one JSON object")
    return value


def source_identity(source: Mapping[str, Any]) -> tuple[str, dict[str, Any]]:
    try:
        return acquisition_source_identity(source)
    except Exception as exc:
        raise CadenceError(str(exc)) from exc


def _source_from_document(document: Mapping[str, Any], source_id: str) -> dict[str, Any]:
    state = document.get("state") if isinstance(document.get("state"), Mapping) else {}
    sources = state.get("sources") if isinstance(state.get("sources"), list) else []
    for row in sources:
        if isinstance(row, Mapping) and str(row.get("id") or "") == source_id:
            return copy.deepcopy(dict(row))
    raise CadenceError("the scheduled source is no longer present in the Node library")


def _receipt_request_identity(receipt: Mapping[str, Any]) -> str:
    request = receipt.get("request") if isinstance(receipt.get("request"), Mapping) else {}
    return str(request.get("sourceIdentitySha256") or "")


def _receipt_retry_after(receipt: Mapping[str, Any]) -> str:
    summary = receipt.get("summary") if isinstance(receipt.get("summary"), Mapping) else {}
    if summary.get("retryAfter"):
        return str(summary.get("retryAfter"))
    evidence = receipt.get("evidence") if isinstance(receipt.get("evidence"), Mapping) else {}
    fetch = evidence.get("fetch") if isinstance(evidence.get("fetch"), Mapping) else {}
    return str(fetch.get("retryAfter") or "")


class DirectWitnessAdapter:
    """Invoke the packaged Witness path without introducing another downloader."""

    kind = "packaged-witness"

    def __init__(self, node_store_path: Path, *, expected_store_id: str):
        self.path = Path(node_store_path).expanduser().resolve()
        self.expected_store_id = str(expected_store_id)

    def _store(self) -> NodeStore:
        try:
            store = NodeStore(self.path)
        except NodeStoreError as exc:
            raise CadenceError(str(exc)) from exc
        if store.store_id != self.expected_store_id:
            raise CadenceConflict("the selected Node library is not the store reviewed by this Cadence database")
        return store

    def current_source(self, source_id: str) -> tuple[NodeStore, dict[str, Any], str]:
        store = self._store()
        record = store.read_library()
        source = _source_from_document(record.document, source_id)
        digest, _material = source_identity(source)
        return store, source, digest

    def prepare(self, plan: Mapping[str, Any], *, operation_id: str, now: float) -> PreparedDispatch:
        store, source, identity = self.current_source(str(plan["sourceId"]))
        if identity != str(plan["sourceIdentitySha256"]):
            raise CadenceConflict("the source address or watched-page recipe changed after schedule review")
        if bool(source.get("archivedAt")):
            raise CadenceConflict("the source is archived; Cadence will not contact it")
        if not bool(source.get("enabled")):
            raise CadenceConflict("the source is paused; Cadence pause therefore means zero requests")
        node = NodeState(backup=self.path, token=secrets.token_urlsafe(24), store=store)
        try:
            preview_token, preview = node.create_acquisition_preview(str(plan["sourceId"]), now=now)
        except PairingError as exc:
            raise CadenceError(str(exc)) from exc
        if str(preview.get("action") or "") != "check-now":
            raise CadenceConflict("scheduled acquisition cannot enable a paused source")
        payload = {
            "schema": "progrss.pulse-prepared-dispatch.v1",
            "adapter": self.kind,
            "operationId": operation_id,
            "sourceId": str(plan["sourceId"]),
            "sourceIdentitySha256": identity,
            "baseLibrarySha256": str(preview["library"]["sha256"]),
            "previewToken": preview_token,
            "previewDigest": str(preview["previewDigest"]),
            "action": "check-now",
            "preparedAt": iso_utc(now),
        }
        return PreparedDispatch(payload=payload, node=node)

    def prepare_for_resume(self, plan: Mapping[str, Any], prepared: Mapping[str, Any], *, now: float) -> PreparedDispatch:
        operation_id = str(prepared.get("operationId") or "")
        if not operation_id:
            return self.prepare(plan, operation_id=random_id("pulse_"), now=now)
        store = self._store()
        receipt = store.find_acquisition_receipt(operation_id)
        job = store.find_acquisition_job(operation_id)
        if receipt is None and job is None:
            # No durable Witness intent exists, so no site request can have begun.
            # The in-memory preview died with the old process; safely prepare a new
            # one while retaining the same due-slot operation identity.
            return self.prepare(plan, operation_id=operation_id, now=now)
        node = NodeState(backup=self.path, token=secrets.token_urlsafe(24), store=store)
        return PreparedDispatch(payload=dict(prepared), node=node)

    def execute(self, prepared: PreparedDispatch, *, now: float) -> tuple[dict[str, Any], bool]:
        payload = prepared.payload
        try:
            return prepared.node.run_acquisition(
                operation_id=str(payload["operationId"]),
                base_sha256=str(payload["baseLibrarySha256"]),
                preview_token=str(payload["previewToken"]),
                preview_digest=str(payload["previewDigest"]),
                source_id=str(payload["sourceId"]),
                action=str(payload["action"]),
                now=now,
            )
        except PairingError as exc:
            raise CadenceError(str(exc)) from exc


class ExternalRunnerAdapter:
    """Advanced argv-only fallback retained for deployments with custom wrappers."""

    kind = "external-runner"

    def __init__(self, executable: Path, node_store_path: Path, *, timeout: int = 120):
        self.executable = Path(executable).expanduser().resolve()
        self.node_store_path = Path(node_store_path).expanduser().resolve()
        self.timeout = max(5, min(int(timeout), 600))
        if not self.executable.is_file() or self.executable.is_symlink() or not os.access(self.executable, os.X_OK):
            raise CadenceError("the configured runner must be one executable regular local file")

    def prepare(self, plan: Mapping[str, Any], *, operation_id: str, now: float) -> PreparedDispatch:
        payload = {
            "schema": "progrss.pulse-prepared-dispatch.v1",
            "adapter": self.kind,
            "operationId": operation_id,
            "sourceId": str(plan["sourceId"]),
            "sourceIdentitySha256": str(plan["sourceIdentitySha256"]),
            "preparedAt": iso_utc(now),
        }
        # The NodeState slot is unused for an external adapter; a tiny sentinel is
        # deliberately avoided.  This adapter is executed through ``execute_raw``.
        return PreparedDispatch(payload=payload, node=None)

    def prepare_for_resume(self, plan: Mapping[str, Any], prepared: Mapping[str, Any], *, now: float) -> PreparedDispatch:
        return PreparedDispatch(payload=dict(prepared), node=None)

    def execute(self, prepared: PreparedDispatch, *, now: float) -> tuple[dict[str, Any], bool]:
        payload = prepared.payload
        command = [
            str(self.executable),
            "--store", str(self.node_store_path),
            "--source", str(payload["sourceId"]),
            "--idempotency-key", str(payload["operationId"]),
            "--json",
        ]
        try:
            completed = subprocess.run(
                command,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=self.timeout,
                check=False,
                env={"PATH": os.environ.get("PATH", "")},
            )
        except subprocess.TimeoutExpired as exc:
            raise CadenceError("the configured acquisition runner exceeded its deadline") from exc
        if len(completed.stdout) > MAX_RESULT_BYTES or len(completed.stderr) > MAX_RESULT_BYTES:
            raise CadenceError("the configured acquisition runner produced too much output")
        if completed.returncode != 0:
            message = completed.stderr.decode("utf-8", "replace").strip()[:500]
            raise CadenceError(message or f"the configured acquisition runner exited {completed.returncode}")
        try:
            value = json.loads(completed.stdout.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise CadenceError("the configured acquisition runner did not return one JSON object") from exc
        if not isinstance(value, dict) or not isinstance(value.get("receipt"), dict):
            raise CadenceError("the configured acquisition runner returned no acquisition receipt")
        return dict(value["receipt"]), bool(value.get("replayed"))


class CadenceService:
    def __init__(
        self,
        timing_path: Path,
        *,
        node_store_path: Path | None = None,
        runner: Path | None = None,
        origin_gap_seconds: int = DEFAULT_ORIGIN_GAP_SECONDS,
    ):
        self.store = CadenceStore(timing_path)
        bound = self.store.node_store_path
        selected = Path(node_store_path).expanduser().resolve() if node_store_path else bound
        if runner is not None:
            self.adapter: Any = ExternalRunnerAdapter(runner, selected)
        else:
            self.adapter = DirectWitnessAdapter(selected, expected_store_id=self.store.node_store_id)
        self.node_store_path = selected
        self.origin_gap_seconds = max(0, min(int(origin_gap_seconds), 3600))
        self.control = SchedulerControl()
        self._control_lock = threading.RLock()

    def _node_store(self) -> NodeStore:
        try:
            node = NodeStore(self.node_store_path)
        except NodeStoreError as exc:
            raise CadenceError(str(exc)) from exc
        if node.store_id != self.store.node_store_id:
            raise CadenceConflict("the selected Node library does not match this Cadence database")
        return node

    def _validate_current_plan_source(self, plan: Mapping[str, Any]) -> dict[str, Any]:
        """Recheck local source authority before either adapter can dispatch.

        The packaged adapter performs the same check while preparing its exact
        Witness preview.  Keeping the check at the service boundary also prevents
        the advanced external-runner path from contacting a source that was paused,
        archived, removed, or materially changed after the timing plan was reviewed.
        This method performs no DNS lookup and no network request.
        """
        record = self._node_store().read_library()
        source = _source_from_document(record.document, str(plan["sourceId"]))
        identity, _material = source_identity(source)
        if identity != str(plan["sourceIdentitySha256"]):
            raise CadenceConflict("the source address or watched-page recipe changed after schedule review")
        if bool(source.get("archivedAt")):
            raise CadenceConflict("the source is archived; Cadence will not contact it")
        if not bool(source.get("enabled")):
            raise CadenceConflict("the source is paused; Cadence pause therefore means zero requests")
        return source

    def _validate_receipt(self, receipt: Mapping[str, Any]) -> tuple[dict[str, Any], dict[str, Any], str, dict[str, Any]]:
        if receipt.get("schema") != "progrss.node.acquisition-receipt.v1":
            raise CadenceError("Cadence requires one progrss.node.acquisition-receipt.v1 Witness receipt")
        operation_id = bounded_text(receipt.get("operationId"), 200)
        receipt_id = bounded_text(receipt.get("receiptId"), 200)
        source_id = bounded_text(receipt.get("sourceId"), 300)
        if not operation_id or not receipt_id or not source_id:
            raise CadenceError("the Witness receipt is missing its operation, receipt, or source identity")
        effects = receipt.get("effects") if isinstance(receipt.get("effects"), Mapping) else {}
        request = receipt.get("request") if isinstance(receipt.get("request"), Mapping) else {}
        outcome = bounded_text(receipt.get("outcome"), 80)
        if int(effects.get("networkRequests") or 0) < 1:
            raise CadenceError("browser-assisted and zero-request receipts cannot make a source schedulable")
        if str(request.get("transport") or "") == "extension-rendered-dom":
            raise CadenceError("browser-assisted Capture evidence cannot be scheduled")
        if outcome not in SUCCESS_OUTCOMES:
            raise CadenceError("Cadence requires a successful Node-reproducible Witness result")
        receipt_identity = _receipt_request_identity(receipt)
        if not receipt_identity:
            raise CadenceError("the Witness receipt predates Pulse source-identity evidence; run one new manual check first")

        node = self._node_store()
        stored = node.find_acquisition_receipt(operation_id)
        if stored is None:
            raise CadenceError("the selected Witness receipt is not present in the bound Node library")
        stored.pop("_requestSha256", None)
        if str(stored.get("receiptId") or "") != receipt_id or sha256_json(stored) != sha256_json(dict(receipt)):
            raise CadenceConflict("the selected Witness receipt does not match the durable Node receipt")
        record = node.read_library()
        source = _source_from_document(record.document, source_id)
        if not bool(source.get("enabled")):
            raise CadenceError("the source is paused; enable and manually check it before scheduling")
        identity, material = source_identity(source)
        if receipt_identity != identity:
            raise CadenceConflict("the source address or watched-page recipe changed after the qualifying Witness check")
        return dict(receipt), source, identity, material

    def review_plan(
        self,
        receipt_path: Path,
        *,
        interval_seconds: int,
        jitter_seconds: int | None = None,
        start_paused: bool = False,
        now: float | None = None,
    ) -> dict[str, Any]:
        current = time.time() if now is None else float(now)
        if interval_seconds < MIN_INTERVAL_SECONDS or interval_seconds > MAX_INTERVAL_SECONDS:
            raise CadenceError("schedule interval is outside the supported range")
        max_jitter = min(MAX_JITTER_SECONDS, interval_seconds // 3)
        jitter = min(max_jitter, max(0, int(jitter_seconds if jitter_seconds is not None else min(900, interval_seconds // 10))))
        receipt = _read_json_file(receipt_path)
        receipt, source, identity, material = self._validate_receipt(receipt)
        source_host = urllib.parse.urlsplit(material["url"]).hostname or ""
        earliest = current + interval_seconds
        latest = earliest + jitter
        review_material = {
            "schema": REVIEW_SCHEMA,
            "nodeStoreId": self.store.node_store_id,
            "source": {
                "id": str(source.get("id") or ""),
                "title": bounded_text(source.get("title"), 180) or "Untitled source",
                "type": str(source.get("type") or ""),
                "site": source_host,
                "identitySha256": identity,
            },
            "eligibility": {
                "receiptId": str(receipt["receiptId"]),
                "operationId": str(receipt["operationId"]),
                "outcome": str(receipt["outcome"]),
                "committedAt": str(receipt.get("committedAt") or ""),
                "resultLibrarySha256": str(receipt.get("resultLibrarySha256") or ""),
                "nodeSiteRequests": int((receipt.get("effects") or {}).get("networkRequests") or 0),
                "browserAssisted": False,
            },
            "timing": {
                "intervalSeconds": interval_seconds,
                "intervalLabel": format_duration(interval_seconds),
                "jitterSeconds": jitter,
                "earliestFirstCheckAt": iso_utc(earliest),
                "latestFirstCheckAt": iso_utc(latest),
                "initialState": "paused" if start_paused else "scheduled",
            },
            "consequences": {
                "networkDuringReview": False,
                "networkDuringCreation": False,
                "foregroundSchedulerStarted": False,
                "portableLibraryChanged": False,
                "sharedSourceListChanged": False,
                "browserWillWake": False,
                "pauseMeansZeroCadenceRequests": True,
                "usesPackagedWitnessPath": not isinstance(self.adapter, ExternalRunnerAdapter),
            },
        }
        return {
            **review_material,
            "state": "review",
            "reviewDigest": sha256_json(review_material),
            "receiptFile": Path(receipt_path).name,
            "network": False,
            "writes": False,
        }

    def create_plan(
        self,
        receipt_path: Path,
        *,
        interval_seconds: int,
        jitter_seconds: int | None = None,
        start_paused: bool = False,
        acknowledge: bool = False,
        now: float | None = None,
    ) -> dict[str, Any]:
        if not acknowledge:
            raise CadenceError("creating a timing plan requires the explicit acknowledgement flag")
        current = time.time() if now is None else float(now)
        review = self.review_plan(
            receipt_path,
            interval_seconds=interval_seconds,
            jitter_seconds=jitter_seconds,
            start_paused=start_paused,
            now=current,
        )
        plan_id = random_id("plan_")
        sequence = 0
        jitter = deterministic_jitter(plan_id, sequence, int(review["timing"]["jitterSeconds"]))
        next_due = current + int(review["timing"]["intervalSeconds"]) + jitter
        plan = {
            "planId": plan_id,
            "sourceId": review["source"]["id"],
            "sourceTitle": review["source"]["title"],
            "sourceType": review["source"]["type"],
            "sourceHost": review["source"]["site"],
            "sourceIdentitySha256": review["source"]["identitySha256"],
            "nodeStoreId": self.store.node_store_id,
            "eligibilityReceiptId": review["eligibility"]["receiptId"],
            "eligibilityOperationId": review["eligibility"]["operationId"],
            "eligibilityResultLibrarySha256": review["eligibility"]["resultLibrarySha256"],
            "intervalSeconds": int(review["timing"]["intervalSeconds"]),
            "jitterSeconds": int(review["timing"]["jitterSeconds"]),
            "state": str(review["timing"]["initialState"]),
            "createdAt": iso_utc(current),
            "updatedAt": iso_utc(current),
            "nextDueAt": iso_utc(next_due),
        }
        created = self.store.add_plan(plan)
        return {
            "schema": "progrss.cadence-create-result.v1",
            "state": "created",
            "plan": created,
            "reviewDigest": review["reviewDigest"],
            "network": False,
            "writes": True,
            "schedulerStarted": False,
        }

    def pause(self, plan_id: str, *, now: float | None = None) -> dict[str, Any]:
        current = time.time() if now is None else float(now)
        plan = self.store.set_plan_state(plan_id, "paused", now=current, reason="Paused by the local administrator.")
        return {"schema": "progrss.cadence-state-result.v1", "state": "paused", "plan": plan, "network": False, "writes": True}

    def resume(self, plan_id: str, *, now: float | None = None) -> dict[str, Any]:
        current = time.time() if now is None else float(now)
        plan = self.store.get_plan(plan_id)
        jitter = deterministic_jitter(plan_id, int(plan["sequence"]) + 1, int(plan["jitterSeconds"]))
        next_due = current + int(plan["intervalSeconds"]) + jitter
        updated = self.store.set_plan_state(plan_id, "scheduled", now=current, next_due_at=iso_utc(next_due), reason="")
        return {"schema": "progrss.cadence-state-result.v1", "state": "scheduled", "plan": updated, "network": False, "writes": True}

    @staticmethod
    def _slot_material(plan: Mapping[str, Any]) -> tuple[str, str, str]:
        due_at = str(plan["nextDueAt"])
        material = {
            "schema": "progrss.pulse-due-slot.v1",
            "planId": str(plan["planId"]),
            "sourceId": str(plan["sourceId"]),
            "sourceIdentitySha256": str(plan["sourceIdentitySha256"]),
            "nodeStoreId": str(plan["nodeStoreId"]),
            "dueAt": due_at,
            "sequence": int(plan["sequence"]),
        }
        digest = sha256_json(material)
        return f"slot_{digest}", f"pulse_{digest}", digest

    def _blocked_result(self, plan: Mapping[str, Any], slot_id: str, reason: str, *, now: float) -> dict[str, Any]:
        return {
            "schema": DISPATCH_SCHEMA,
            **release_identity(),
            "state": "blocked",
            "slotId": slot_id,
            "planId": plan["planId"],
            "sourceId": plan["sourceId"],
            "outcome": "source-paused" if "paused" in reason.lower() else "review-required",
            "message": reason,
            "receipt": None,
            "replayed": False,
            "networkRequests": 0,
            "completedAt": iso_utc(now),
        }

    def dispatch_plan(
        self,
        plan_id: str,
        *,
        now: float | None = None,
        fail_after_node_commit: bool = False,
    ) -> dict[str, Any]:
        current = time.time() if now is None else float(now)
        plan = self.store.get_plan(plan_id)
        if plan["state"] != "scheduled":
            return {
                "schema": DISPATCH_SCHEMA,
                **release_identity(),
                "state": "skipped",
                "planId": plan_id,
                "sourceId": plan["sourceId"],
                "outcome": "plan-paused",
                "message": "The timing plan is paused. Cadence made no request.",
                "receipt": None,
                "replayed": False,
                "networkRequests": 0,
                "completedAt": iso_utc(current),
            }
        if parse_iso(plan["nextDueAt"]) > current:
            return {
                "schema": DISPATCH_SCHEMA,
                **release_identity(),
                "state": "not-due",
                "planId": plan_id,
                "sourceId": plan["sourceId"],
                "outcome": "not-due",
                "message": "The next reviewed timing point has not arrived.",
                "receipt": None,
                "replayed": False,
                "networkRequests": 0,
                "completedAt": iso_utc(current),
            }

        host = str(plan["sourceHost"])
        budget = self.store.origin_next_allowed(host)
        if budget is not None and budget > current:
            self.store.defer_plan(plan_id, next_due_at=budget, reason="Deferred by the persistent per-site request budget.", now=current)
            return {
                "schema": DISPATCH_SCHEMA,
                **release_identity(),
                "state": "deferred",
                "planId": plan_id,
                "sourceId": plan["sourceId"],
                "outcome": "host-budget",
                "message": "Another check for this site used the current courtesy window.",
                "nextDueAt": iso_utc(budget),
                "receipt": None,
                "replayed": False,
                "networkRequests": 0,
                "completedAt": iso_utc(current),
            }

        slot_id, operation_id, request_digest = self._slot_material(plan)
        started = self.store.start_slot(
            slot_id=slot_id,
            plan_id=plan_id,
            due_at=str(plan["nextDueAt"]),
            request_sha256=request_digest,
            now=current,
        )
        if started.replayed:
            result = copy.deepcopy(started.slot.get("result") or {})
            result["replayed"] = True
            result["state"] = "replayed"
            return result

        prepared_payload = started.slot.get("prepared")
        try:
            # Recheck the current local source before either the packaged adapter or
            # the advanced external adapter can perform work.  This closes the
            # authority gap between plan review and dispatch without contacting the
            # source.
            self._validate_current_plan_source(plan)
            if isinstance(prepared_payload, Mapping):
                prepared = self.adapter.prepare_for_resume(plan, prepared_payload, now=current)
            else:
                prepared = self.adapter.prepare(plan, operation_id=operation_id, now=current)
            persisted = self.store.set_slot_prepared(slot_id, prepared.payload, now=current)
            # If a dead process had persisted an in-memory preview before Witness
            # inserted durable intent, prepare_for_resume produced a replacement.
            prepared.payload = dict(persisted.get("prepared") or prepared.payload)
            receipt, node_replayed = self.adapter.execute(prepared, now=current)
            if fail_after_node_commit:
                raise RuntimeError("injected Pulse failure after Node acquisition commit")
        except CadenceConflict as exc:
            result = self._blocked_result(plan, slot_id, str(exc), now=current)
            next_due = current + int(plan["intervalSeconds"])
            return self.store.complete_slot(
                slot_id=slot_id,
                result=result,
                outcome=result["outcome"],
                receipt_id="",
                plan_state="paused",
                next_due_at=iso_utc(next_due),
                failure_count=int(plan["failureCount"]),
                blocked_reason=str(exc),
                now=current,
            )
        except Exception as exc:
            self.store.mark_slot_error(slot_id, str(exc))
            raise

        outcome = bounded_text(receipt.get("outcome"), 80) or "unknown"
        effects = receipt.get("effects") if isinstance(receipt.get("effects"), Mapping) else {}
        network_requests = max(0, int(effects.get("networkRequests") or 0))
        if network_requests:
            self.store.set_origin_next_allowed(host, timestamp=current + self.origin_gap_seconds, now=current)
        retry_after = parse_retry_after(_receipt_retry_after(receipt), now=current)
        prior_failures = int(plan["failureCount"])
        failures = 0 if outcome in SUCCESS_OUTCOMES else prior_failures + 1
        wait = next_wait_seconds(outcome, interval=int(plan["intervalSeconds"]), failures=failures, retry_after=retry_after)
        next_sequence = int(plan["sequence"]) + 1
        jitter = deterministic_jitter(plan_id, next_sequence, int(plan["jitterSeconds"]))
        next_due = current + wait + jitter
        plan_state = "paused" if outcome in BLOCKING_OUTCOMES else "scheduled"
        blocked_reason = ""
        if plan_state == "paused":
            blocked_reason = f"Automatic checks paused after {outcome.replace('-', ' ')}. Review the source before resuming."
        result = {
            "schema": DISPATCH_SCHEMA,
            **release_identity(),
            "state": "completed",
            "slotId": slot_id,
            "planId": plan_id,
            "sourceId": plan["sourceId"],
            "sourceTitle": plan["sourceTitle"],
            "outcome": outcome,
            "receiptId": str(receipt.get("receiptId") or ""),
            "receipt": copy.deepcopy(dict(receipt)),
            "replayed": bool(node_replayed or started.resumed),
            "nodeReceiptReplayed": bool(node_replayed),
            "networkRequests": network_requests,
            "retryAfter": None if retry_after is None else {
                "raw": retry_after.raw,
                "seconds": retry_after.seconds,
                "kind": retry_after.kind,
            },
            "nextDueAt": iso_utc(next_due),
            "planState": plan_state,
            "completedAt": iso_utc(current),
        }
        return self.store.complete_slot(
            slot_id=slot_id,
            result=result,
            outcome=outcome,
            receipt_id=str(receipt.get("receiptId") or ""),
            plan_state=plan_state,
            next_due_at=iso_utc(next_due),
            failure_count=failures,
            blocked_reason=blocked_reason,
            now=current,
        )

    def run_due(
        self,
        *,
        now: float | None = None,
        limit: int = 20,
        owner_id: str | None = None,
        keep_lease: bool = False,
    ) -> dict[str, Any]:
        current = time.time() if now is None else float(now)
        owner = owner_id or random_id("run_")
        acquired_here = owner_id is None
        if acquired_here:
            self.store.acquire_lease(owner, now=current, seconds=DEFAULT_LEASE_SECONDS)
        results: list[dict[str, Any]] = []
        try:
            due = self.store.due_plans(now=current, limit=limit)
            for plan in due:
                results.append(self.dispatch_plan(str(plan["planId"]), now=current))
                current = max(current, time.time() if now is None else current + 0.001)
            return {
                "schema": "progrss.cadence-run-result.v1",
                **release_identity(),
                "state": "completed",
                "ownerId": owner,
                "duePlans": len(due),
                "results": results,
                "networkRequests": sum(int(row.get("networkRequests") or 0) for row in results),
                "writes": bool(results),
                "completedAt": iso_utc(current),
            }
        finally:
            if acquired_here and not keep_lease:
                self.store.release_lease(owner)

    def start_loop(self, *, poll_seconds: float = 2.0) -> dict[str, Any]:
        with self._control_lock:
            if self.control.running:
                return self.scheduler_status()
            owner = random_id("loop_")
            now = time.time()
            self.store.acquire_lease(owner, now=now, seconds=DEFAULT_LEASE_SECONDS)
            stop = threading.Event()
            self.control = SchedulerControl(running=True, owner_id=owner, stop_event=stop)

            def run() -> None:
                try:
                    while not stop.is_set():
                        wall = time.time()
                        self.store.renew_lease(owner, now=wall, seconds=DEFAULT_LEASE_SECONDS)
                        result = self.run_due(now=wall, limit=20, owner_id=owner, keep_lease=True)
                        with self._control_lock:
                            self.control.last_run_at = str(result.get("completedAt") or iso_utc(wall))
                            self.control.last_error = ""
                        stop.wait(max(0.25, min(float(poll_seconds), 60.0)))
                except Exception as exc:  # surfaced through status; no silent daemon
                    with self._control_lock:
                        self.control.last_error = str(exc)[:500]
                finally:
                    self.store.release_lease(owner)
                    with self._control_lock:
                        self.control.running = False

            thread = threading.Thread(target=run, name="ProgRSS-Pulse", daemon=True)
            self.control.thread = thread
            thread.start()
            return self.scheduler_status()

    def stop_loop(self) -> dict[str, Any]:
        with self._control_lock:
            stop = self.control.stop_event
            thread = self.control.thread
            if stop is not None:
                stop.set()
        if thread is not None:
            thread.join(timeout=5.0)
        return self.scheduler_status()

    def scheduler_status(self) -> dict[str, Any]:
        with self._control_lock:
            return {
                "running": bool(self.control.running),
                "ownerId": self.control.owner_id,
                "lastRunAt": self.control.last_run_at,
                "lastError": self.control.last_error,
                "foregroundOnly": True,
            }

    def status(self) -> dict[str, Any]:
        plans = self.store.list_document()
        return {
            "schema": "progrss.cadence-status.v1",
            **release_identity(),
            "database": {
                "file": self.store.path.name,
                "databaseId": self.store.database_id,
                "nodeStoreId": self.store.node_store_id,
                "nodeStoreFile": self.node_store_path.name,
            },
            "adapter": {
                "kind": getattr(self.adapter, "kind", "unknown"),
                "packagedWitness": isinstance(self.adapter, DirectWitnessAdapter),
                "secondDownloader": False,
            },
            "scheduler": self.scheduler_status(),
            "counts": plans["counts"],
            "plans": plans["plans"],
            "recentSlots": self.store.recent_slots(20),
            "lease": self.store.lease_status(),
            "capabilities": {
                "reviewPlans": True,
                "createPlans": True,
                "pauseResume": True,
                "runDueOnce": True,
                "foregroundScheduler": True,
                "packagedWitnessAdapter": isinstance(self.adapter, DirectWitnessAdapter),
                "browserAssistedScheduling": False,
                "permanentBackgroundService": False,
                "remoteScheduling": False,
            },
        }


__all__ = [
    "CadenceService",
    "DirectWitnessAdapter",
    "ExternalRunnerAdapter",
    "PreparedDispatch",
    "SchedulerControl",
    "source_identity",
]
