"""ProgRSS Pulse scheduling package.

Cadence timing and Pulse dispatch remain Node-local.  Portable ProgRSS JSON never
contains these plans, leases, due slots, or administrator capabilities.
"""

VERSION = "0.80.0"
REVISION = "rev0080"
CODENAME = "Pulse"

__all__ = ["VERSION", "REVISION", "CODENAME"]
