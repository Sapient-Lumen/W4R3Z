#!/usr/bin/env python3
"""Private, self-contained ProgRSS Fieldbook debrief workspaces.

A debrief compares several already exported ``progrss.fieldwork-report.v1``
files. Reports remain in the local page, raw facilitator notes are never copied
into the debrief export, and the tool does not score participants or declare
that the product passed. It performs no network request and persists nothing
until the facilitator explicitly downloads a reviewed local debrief.
"""

from __future__ import annotations

import hashlib
import html
import json
import re
from typing import Any, Mapping, Sequence

from fieldbook import FIELDWORK_REPORT_SCHEMA, MAX_FIELDWORK_NOTE_CHARS, MAX_FIELDWORK_TASKS

DEBRIEF_KIT_SCHEMA = "progrss.fieldwork-debrief-kit.v1"
DEBRIEF_REPORT_SCHEMA = "progrss.fieldwork-debrief.v1"
MAX_DEBRIEF_REPORTS = 40
MAX_DEBRIEF_REPORT_BYTES = 256_000
MAX_DEBRIEF_TOTAL_BYTES = 4_000_000
MAX_DEBRIEF_FINDING_CHARS = 500
MAX_DEBRIEF_ACTION_CHARS = 500

OUTCOME_VALUES = ("independent", "neutral-prompt", "wrong-turn", "not-observed")
OUTCOME_LABELS = {
    "independent": "Understood independently",
    "neutral-prompt": "Understood after a neutral prompt",
    "wrong-turn": "Wrong turn or unsafe interpretation",
    "not-observed": "Not observed",
}
DISPOSITIONS = (
    ("product-change", "Product change to try"),
    ("more-evidence", "More sessions needed"),
    ("no-change-yet", "No product change yet"),
    ("not-reviewed", "Not reviewed"),
)


class DebriefError(ValueError):
    """Expected report-validation or debrief-generation failure."""


def _text(value: Any, limit: int = 600) -> str:
    return re.sub(r"\s+", " ", str(value if value is not None else "")).strip()[:limit]


def _canonical(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _digest(value: Any) -> str:
    return hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def _expect_object(value: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise DebriefError(f"{label} must be one JSON object")
    return value


def _expect_exact_keys(value: Mapping[str, Any], expected: set[str], label: str) -> None:
    keys = set(value)
    missing = sorted(expected - keys)
    unknown = sorted(keys - expected)
    if missing:
        raise DebriefError(f"{label} is missing {', '.join(missing)}")
    if unknown:
        raise DebriefError(f"{label} contains unknown field {unknown[0]}")


def _bounded_string(value: Any, label: str, limit: int, *, allow_empty: bool = False) -> str:
    if not isinstance(value, str):
        raise DebriefError(f"{label} must be text")
    normalized = re.sub(r"\s+", " ", value).strip()
    if not allow_empty and not normalized:
        raise DebriefError(f"{label} must not be empty")
    if len(normalized) > limit:
        raise DebriefError(f"{label} exceeds {limit} characters")
    return normalized


def validate_fieldwork_report(value: Any) -> dict[str, Any]:
    """Strictly validate and normalize one Fieldbook report.

    Exact-key validation is intentional: a report carrying an unexpected
    participant field or source detail is refused rather than silently copied
    into the analysis workspace.
    """
    report = _expect_object(value, "fieldwork report")
    _expect_exact_keys(
        report,
        {
            "schema", "scenario", "scenarioDigest", "release",
            "generatedFromKitAt", "completedAt", "outcomes", "tasks",
            "facilitatorBoundary", "privacy",
        },
        "fieldwork report",
    )
    if report.get("schema") != FIELDWORK_REPORT_SCHEMA:
        raise DebriefError(f"expected {FIELDWORK_REPORT_SCHEMA}")
    scenario = _bounded_string(report.get("scenario"), "scenario", 80)
    scenario_digest = _bounded_string(report.get("scenarioDigest"), "scenarioDigest", 64)
    if not re.fullmatch(r"[0-9a-f]{64}", scenario_digest):
        raise DebriefError("scenarioDigest must be one lowercase SHA-256")

    release = _expect_object(report.get("release"), "release")
    _expect_exact_keys(release, {"version", "revision", "codename"}, "release")
    normalized_release = {
        "version": _bounded_string(release.get("version"), "release.version", 40),
        "revision": _bounded_string(release.get("revision"), "release.revision", 40),
        "codename": _bounded_string(release.get("codename"), "release.codename", 60),
    }
    generated_from = _bounded_string(report.get("generatedFromKitAt"), "generatedFromKitAt", 80)
    completed_at = _bounded_string(report.get("completedAt"), "completedAt", 80)

    outcomes = _expect_object(report.get("outcomes"), "outcomes")
    _expect_exact_keys(outcomes, set(OUTCOME_VALUES), "outcomes")
    normalized_outcomes: dict[str, int] = {}
    for outcome in OUTCOME_VALUES:
        count = outcomes.get(outcome)
        if isinstance(count, bool) or not isinstance(count, int) or count < 0 or count > MAX_FIELDWORK_TASKS:
            raise DebriefError(f"outcomes.{outcome} must be a bounded non-negative integer")
        normalized_outcomes[outcome] = count

    tasks = report.get("tasks")
    if not isinstance(tasks, list) or not tasks or len(tasks) > MAX_FIELDWORK_TASKS:
        raise DebriefError("tasks must contain one bounded task list")
    normalized_tasks: list[dict[str, str]] = []
    seen_ids: set[str] = set()
    computed = {key: 0 for key in OUTCOME_VALUES}
    for index, row in enumerate(tasks, start=1):
        task = _expect_object(row, f"task {index}")
        _expect_exact_keys(task, {"id", "title", "outcome", "notes"}, f"task {index}")
        task_id = _bounded_string(task.get("id"), f"task {index}.id", 80)
        if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,79}", task_id):
            raise DebriefError(f"task {index}.id is invalid")
        if task_id in seen_ids:
            raise DebriefError(f"duplicate task id {task_id}")
        seen_ids.add(task_id)
        title = _bounded_string(task.get("title"), f"task {index}.title", 160)
        outcome = _bounded_string(task.get("outcome"), f"task {index}.outcome", 40)
        if outcome not in OUTCOME_VALUES:
            raise DebriefError(f"task {index}.outcome is unsupported")
        notes = _bounded_string(
            task.get("notes"), f"task {index}.notes", MAX_FIELDWORK_NOTE_CHARS, allow_empty=True,
        )
        computed[outcome] += 1
        normalized_tasks.append({"id": task_id, "title": title, "outcome": outcome, "notes": notes})
    if normalized_outcomes != computed:
        raise DebriefError("outcome totals do not match the task outcomes")

    boundary = _expect_object(report.get("facilitatorBoundary"), "facilitatorBoundary")
    _expect_exact_keys(boundary, {"testedProductNotParticipant", "avoidedSensitiveNotes", "exactReleaseOpen"}, "facilitatorBoundary")
    if any(boundary.get(key) is not True for key in boundary):
        raise DebriefError("facilitatorBoundary must confirm all three research boundaries")

    privacy = _expect_object(report.get("privacy"), "privacy")
    _expect_exact_keys(privacy, {"participantIdentityRecorded", "automaticPersistence", "telemetry", "network"}, "privacy")
    if any(privacy.get(key) is not False for key in privacy):
        raise DebriefError("fieldwork report privacy boundary is not compatible with local debrief")

    return {
        "schema": FIELDWORK_REPORT_SCHEMA,
        "scenario": scenario,
        "scenarioDigest": scenario_digest,
        "release": normalized_release,
        "generatedFromKitAt": generated_from,
        "completedAt": completed_at,
        "outcomes": normalized_outcomes,
        "tasks": normalized_tasks,
        "facilitatorBoundary": {
            "testedProductNotParticipant": True,
            "avoidedSensitiveNotes": True,
            "exactReleaseOpen": True,
        },
        "privacy": {
            "participantIdentityRecorded": False,
            "automaticPersistence": False,
            "telemetry": False,
            "network": False,
        },
    }


def _task_signature(report: Mapping[str, Any]) -> list[tuple[str, str]]:
    return [(str(row["id"]), str(row["title"])) for row in report["tasks"]]


def build_debrief_workspace(
    reports: Sequence[Any],
    *,
    version: str,
    revision: str,
    codename: str,
    generated_at: str,
) -> dict[str, Any]:
    """Build a bounded local-only debrief workspace.

    Duplicate reports are removed by canonical digest. When reports are
    preloaded they must describe the same exact Fieldbook scenario and task
    sequence. A blank workspace remains valid for browser-local import.
    """
    if len(reports) > MAX_DEBRIEF_REPORTS:
        raise DebriefError(f"at most {MAX_DEBRIEF_REPORTS} reports may be preloaded")
    normalized: list[dict[str, Any]] = []
    seen: set[str] = set()
    duplicates = 0
    baseline_digest = ""
    baseline_scenario = ""
    baseline_release: dict[str, str] | None = None
    baseline_tasks: list[tuple[str, str]] | None = None
    for index, value in enumerate(reports, start=1):
        report = validate_fieldwork_report(value)
        digest = _digest(report)
        if digest in seen:
            duplicates += 1
            continue
        seen.add(digest)
        if not normalized:
            baseline_digest = report["scenarioDigest"]
            baseline_scenario = report["scenario"]
            baseline_release = dict(report["release"])
            baseline_tasks = _task_signature(report)
        else:
            if report["scenarioDigest"] != baseline_digest or report["scenario"] != baseline_scenario:
                raise DebriefError(f"report {index} belongs to a different Fieldbook scenario")
            if report["release"] != baseline_release:
                raise DebriefError(f"report {index} names a different product release")
            if _task_signature(report) != baseline_tasks:
                raise DebriefError(f"report {index} uses a different task sequence")
        normalized.append(report)
    return {
        "schema": DEBRIEF_KIT_SCHEMA,
        "generatedAt": _bounded_string(generated_at, "generatedAt", 80),
        "release": {
            "version": _bounded_string(version, "version", 40),
            "revision": _bounded_string(revision, "revision", 40),
            "codename": _bounded_string(codename, "codename", 60),
        },
        "reportSchema": FIELDWORK_REPORT_SCHEMA,
        "debriefSchema": DEBRIEF_REPORT_SCHEMA,
        "limits": {
            "reports": MAX_DEBRIEF_REPORTS,
            "reportBytes": MAX_DEBRIEF_REPORT_BYTES,
            "totalBytes": MAX_DEBRIEF_TOTAL_BYTES,
            "findingCharacters": MAX_DEBRIEF_FINDING_CHARS,
            "actionCharacters": MAX_DEBRIEF_ACTION_CHARS,
            "taskNotesCharacters": MAX_FIELDWORK_NOTE_CHARS,
        },
        "outcomes": [{"value": key, "label": OUTCOME_LABELS[key]} for key in OUTCOME_VALUES],
        "dispositions": [{"value": value, "label": label} for value, label in DISPOSITIONS],
        "preloadedReports": normalized,
        "duplicatesRemoved": duplicates,
        "privacy": {
            "participantIdentityRequested": False,
            "rawNotesExported": False,
            "automaticPersistence": False,
            "network": False,
            "telemetry": False,
        },
        "effects": {"network": False, "libraryWrites": False, "storeWrites": False},
    }


def _json_for_script(value: Any) -> str:
    return _canonical(value).replace("<", "\\u003c").replace("&", "\\u0026")


def render_debrief_html(workspace: Mapping[str, Any]) -> bytes:
    """Render one self-contained browser-local Fieldbook debrief workspace."""
    if workspace.get("schema") != DEBRIEF_KIT_SCHEMA:
        raise DebriefError(f"expected {DEBRIEF_KIT_SCHEMA}")
    release = workspace.get("release") if isinstance(workspace.get("release"), Mapping) else {}
    version = html.escape(_text(release.get("version"), 40))
    revision = html.escape(_text(release.get("revision"), 40))
    codename = html.escape(_text(release.get("codename"), 60))
    workspace_json = _json_for_script(workspace)
    document = r'''<!doctype html>
<html lang="en" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="dark light">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; img-src 'none'; font-src 'none'; connect-src 'none'; media-src 'none'; object-src 'none'; frame-src 'none'; form-action 'none'; base-uri 'none'">
<title>ProgRSS Debrief · __REVISION__ __CODENAME__</title>
<style>
:root{--bg:#06070a;--panel:#0d1016;--raised:#151a23;--ink:#f4f7ff;--muted:#a8b0c0;--line:#2b3242;--cyan:#3ffcff;--pink:#ff49d9;--lime:#c8ff4a;--amber:#ffd166;--danger:#ff7b95;--shadow:0 20px 60px #0008;color-scheme:dark}
:root[data-theme="light"]{--bg:#f6f8fb;--panel:#fff;--raised:#f0f4f8;--ink:#111722;--muted:#596274;--line:#cbd3df;--cyan:#00767b;--pink:#a50078;--lime:#4e7000;--amber:#855900;--danger:#a31135;--shadow:0 18px 50px #1f2c401f;color-scheme:light}
*{box-sizing:border-box}html{background:var(--bg);color:var(--ink);font:16px/1.55 system-ui,-apple-system,Segoe UI,sans-serif}body{margin:0;background:radial-gradient(circle at 15% 0,color-mix(in srgb,var(--cyan) 8%,transparent),transparent 34%),radial-gradient(circle at 90% 16%,color-mix(in srgb,var(--pink) 7%,transparent),transparent 30%),var(--bg)}button,input,textarea,select{font:inherit}button,select,input[type=file]{min-height:44px;border:1px solid var(--line);border-radius:12px;background:var(--raised);color:var(--ink);padding:.72rem 1rem;font-weight:750}button{cursor:pointer}button:hover{border-color:var(--cyan)}button:focus-visible,input:focus-visible,textarea:focus-visible,select:focus-visible,summary:focus-visible{outline:3px solid var(--cyan);outline-offset:3px}button.primary{background:linear-gradient(135deg,color-mix(in srgb,var(--cyan) 75%,#081014),color-mix(in srgb,var(--pink) 58%,#120914));border-color:color-mix(in srgb,var(--cyan) 65%,var(--line));color:#fff;box-shadow:0 0 24px color-mix(in srgb,var(--cyan) 20%,transparent)}button.danger{border-color:color-mix(in srgb,var(--danger) 50%,var(--line));color:var(--danger)}button[disabled]{opacity:.48;cursor:not-allowed}header{position:sticky;top:0;z-index:4;border-bottom:1px solid var(--line);background:color-mix(in srgb,var(--bg) 90%,transparent);backdrop-filter:blur(16px)}.bar{max-width:1180px;margin:auto;padding:14px 22px;display:flex;align-items:center;justify-content:space-between;gap:18px}.brand{display:flex;align-items:center;gap:12px}.mark{width:22px;height:22px;transform:rotate(45deg);border:2px solid var(--cyan);box-shadow:0 0 18px color-mix(in srgb,var(--cyan) 60%,transparent),inset 0 0 12px color-mix(in srgb,var(--pink) 45%,transparent)}.brand strong{letter-spacing:.03em}.brand small{display:block;color:var(--muted)}main{max-width:1180px;margin:auto;padding:34px 22px 80px}.hero{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(280px,.65fr);gap:18px}.card{border:1px solid var(--line);border-radius:18px;background:linear-gradient(145deg,color-mix(in srgb,var(--cyan) 3%,var(--panel)),color-mix(in srgb,var(--pink) 3%,var(--panel)));box-shadow:var(--shadow);padding:22px}.eyebrow{margin:0 0 8px;color:var(--cyan);font-size:.72rem;font-weight:900;letter-spacing:.12em;text-transform:uppercase}h1{margin:.1rem 0 .7rem;font-size:clamp(2rem,5vw,4rem);line-height:1.02}h2{margin:0 0 .55rem;font-size:1.35rem}h3{margin:.1rem 0 .5rem;font-size:1.05rem}p{max-width:78ch}.muted{color:var(--muted)}.boundary{display:grid;gap:10px}.boundary article{padding:13px;border:1px solid var(--line);border-radius:13px;background:var(--raised)}.boundary strong{display:block;color:var(--lime)}.boundary p{margin:4px 0 0;color:var(--muted);font-size:.88rem}.import{margin-top:18px}.file-row{display:flex;flex-wrap:wrap;gap:10px;align-items:center}.file-row input{flex:1;min-width:260px}.status{min-height:1.7rem;margin-top:12px;color:var(--muted)}.status.good{color:var(--lime)}.status.error{color:var(--danger)}.metrics{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px;margin-top:18px}.metric{padding:13px;border:1px solid var(--line);border-radius:13px;background:var(--raised)}.metric strong{display:block;font-size:1.45rem;color:var(--cyan)}.metric span{color:var(--muted);font-size:.78rem}.analysis{margin-top:22px}.tasks{display:grid;gap:14px}.task{border:1px solid var(--line);border-radius:16px;background:var(--panel);padding:18px}.task.reviewed{border-color:color-mix(in srgb,var(--lime) 46%,var(--line));box-shadow:inset 3px 0 0 var(--lime)}.task-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.task-number{color:var(--pink);font-size:.72rem;letter-spacing:.08em;text-transform:uppercase}.signal-row{display:flex;flex-wrap:wrap;gap:7px;margin:10px 0}.signal{border:1px solid var(--line);border-radius:999px;padding:4px 9px;color:var(--muted);font-size:.78rem}.signal.alert{border-color:color-mix(in srgb,var(--danger) 55%,var(--line));color:var(--danger)}.signal.prompt{border-color:color-mix(in srgb,var(--amber) 55%,var(--line));color:var(--amber)}.signal.coverage{border-color:color-mix(in srgb,var(--pink) 55%,var(--line));color:var(--pink)}.counts{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}.count{padding:10px;border:1px solid var(--line);border-radius:11px;background:var(--raised)}.count strong{display:block;color:var(--cyan);font-size:1.2rem}.count span{font-size:.75rem;color:var(--muted)}details{margin-top:10px}summary{cursor:pointer;color:var(--cyan);font-weight:750}.notes{display:grid;gap:8px;margin:10px 0 0;padding:0;list-style:none}.notes li{padding:10px;border-left:2px solid var(--pink);background:color-mix(in srgb,var(--pink) 4%,var(--raised));overflow-wrap:anywhere}.notes small{display:block;color:var(--muted)}.decision-grid{display:grid;grid-template-columns:minmax(220px,.5fr) minmax(0,1fr) minmax(0,1fr);gap:10px;margin-top:14px}.decision-grid label{display:block;font-weight:750}.decision-grid select,.decision-grid textarea{display:block;width:100%;margin-top:6px;border:1px solid var(--line);border-radius:11px;background:var(--raised);color:var(--ink);padding:10px}.decision-grid textarea{min-height:96px;resize:vertical}.help{display:flex;justify-content:space-between;gap:10px;color:var(--muted);font-size:.76rem}.actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:22px}.review{margin-top:24px}.review-list{display:grid;gap:9px;margin:14px 0;padding:0;list-style:none}.review-list li{padding:12px;border:1px solid var(--line);border-radius:12px;background:var(--raised)}.review-list small{display:block;color:var(--muted)}.privacy-review{margin-top:15px;padding:14px;border:1px solid color-mix(in srgb,var(--amber) 50%,var(--line));border-radius:13px;background:color-mix(in srgb,var(--amber) 5%,var(--panel))}.check{display:flex;gap:10px;align-items:flex-start;margin:10px 0}.check input{margin-top:.3rem;inline-size:1.2rem;block-size:1.2rem;accent-color:var(--cyan)}code{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;color:var(--cyan);overflow-wrap:anywhere}footer{max-width:1180px;margin:auto;padding:0 22px 50px;color:var(--muted);font-size:.8rem}[hidden]{display:none!important}
@media(max-width:850px){.hero{grid-template-columns:1fr}.metrics{grid-template-columns:repeat(2,minmax(0,1fr))}.decision-grid{grid-template-columns:1fr}.counts{grid-template-columns:repeat(2,minmax(0,1fr))}.bar{align-items:flex-start}}
@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important;transition:none!important;animation:none!important}}
@media(forced-colors:active){.mark,.card,.task{box-shadow:none}.primary{background:ButtonFace!important;color:ButtonText!important}}
@media print{header,.import,.actions,.privacy-review,footer{display:none!important}body{background:#fff;color:#000}.card,.task,.metric,.count{box-shadow:none;border-color:#777}}
</style>
</head>
<body>
<header><div class="bar"><div class="brand"><span class="mark" aria-hidden="true"></span><div><strong>ProgRSS Debrief</strong><small>__VERSION__ · __REVISION__ · __CODENAME__</small></div></div><button id="theme" type="button" aria-label="Use light theme">☼ Theme</button></div></header>
<main>
<section class="hero">
  <article class="card"><p class="eyebrow">Local fieldwork analysis</p><h1>Find patterns. Do not score people.</h1><p>Compare several private Fieldbook reports from the same scenario. Counts describe these observed sessions only. They do not establish broad usability, rank participants, or decide that ProgRSS passed.</p></article>
  <aside class="card boundary" aria-label="Debrief boundaries">
    <article><strong>Reports stay here</strong><p>Selected JSON files are read into this page. Nothing is uploaded or saved automatically.</p></article>
    <article><strong>Notes stay out of export</strong><p>Raw facilitator notes may be reviewed locally, but the debrief export contains only newly written findings and actions.</p></article>
    <article><strong>No participant score</strong><p>ProgRSS counts task outcomes and surfaces review signals. It never calculates a participant grade or product pass rate.</p></article>
  </aside>
</section>
<section class="card import" aria-labelledby="import-heading">
  <p class="eyebrow">1 · Bring local evidence together</p><h2 id="import-heading">Load Fieldbook JSON reports</h2>
  <p class="muted">Use reports from one exact Fieldbook scenario. Exact duplicates are ignored. A report with unknown fields, mismatched tasks, or an incompatible privacy boundary is refused.</p>
  <div class="file-row"><input id="reports" type="file" accept="application/json,.json" multiple><button id="load" class="primary" type="button">Load selected reports</button><button id="clear" class="danger" type="button">Clear workspace</button></div>
  <p id="status" class="status" role="status" aria-live="polite"></p>
</section>
<section id="analysis" class="analysis" hidden>
  <section class="card" aria-labelledby="summary-heading"><p class="eyebrow">2 · Review observed patterns</p><h2 id="summary-heading" tabindex="-1">Session evidence</h2><p id="scenario-line" class="muted"></p><div id="metrics" class="metrics"></div></section>
  <div id="tasks" class="tasks" aria-label="Task evidence"></div>
  <div class="actions"><button id="review" class="primary" type="button">Review debrief</button><button id="print" type="button">Print current view</button></div>
</section>
<section id="review-panel" class="card review" aria-labelledby="review-heading" hidden>
  <p class="eyebrow">3 · Review before export</p><h2 id="review-heading" tabindex="-1">Product findings, not participant judgments</h2>
  <p>Check every disposition and newly written finding. Raw Fieldbook notes are deliberately excluded from the export.</p>
  <div id="review-metrics" class="metrics"></div><ul id="review-list" class="review-list"></ul>
  <div class="privacy-review">
    <strong>Required privacy and interpretation review</strong>
    <label class="check"><input id="privacy-text" type="checkbox"><span>I reviewed findings and actions for names, contact details, sensitive page content, and other identifying material.</span></label>
    <label class="check"><input id="privacy-scope" type="checkbox"><span>I understand these counts describe the loaded reports, not all users or all accessibility needs.</span></label>
    <label class="check"><input id="privacy-notes" type="checkbox"><span>I understand raw facilitator notes are not included in the debrief export.</span></label>
  </div>
  <div class="actions"><button id="download-json" class="primary" type="button" disabled>Download JSON debrief</button><button id="download-md" type="button" disabled>Download Markdown debrief</button><button id="back" type="button">Back to analysis</button></div>
</section>
<script id="workspace" type="application/json">__WORKSPACE_JSON__</script>
<script>
(() => {
  'use strict';
  const workspace = JSON.parse(document.getElementById('workspace').textContent);
  const reportSchema = workspace.reportSchema;
  const debriefSchema = workspace.debriefSchema;
  const limits = workspace.limits;
  const outcomeValues = workspace.outcomes.map(row => row.value);
  const outcomeLabels = Object.fromEntries(workspace.outcomes.map(row => [row.value, row.label]));
  const dispositionLabels = Object.fromEntries(workspace.dispositions.map(row => [row.value, row.label]));
  const state = {reports:[], keys:new Set(), scenario:null, edited:false, exported:false};
  const $ = selector => document.querySelector(selector);
  const clean = value => String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  const node = (tag, attrs = {}, children = []) => {
    const el = document.createElement(tag);
    Object.entries(attrs).forEach(([key, value]) => {
      if (value == null || value === false) return;
      if (key === 'text') el.textContent = value;
      else if (key === 'class') el.className = value;
      else if (key === 'htmlFor') el.htmlFor = value;
      else el.setAttribute(key, String(value));
    });
    (Array.isArray(children) ? children : [children]).forEach(child => child != null && el.append(child.nodeType ? child : document.createTextNode(String(child))));
    return el;
  };
  const exactKeys = (value, expected, label) => {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(`${label} must be one JSON object.`);
    const keys = Object.keys(value).sort(), target = [...expected].sort();
    const unknown = keys.find(key => !expected.includes(key));
    const missing = target.find(key => !(key in value));
    if (missing) throw new Error(`${label} is missing ${missing}.`);
    if (unknown) throw new Error(`${label} contains unknown field ${unknown}.`);
  };
  const boundedText = (value, label, max, allowEmpty = false) => {
    if (typeof value !== 'string') throw new Error(`${label} must be text.`);
    const text = clean(value);
    if (!allowEmpty && !text) throw new Error(`${label} must not be empty.`);
    if (text.length > max) throw new Error(`${label} exceeds ${max} characters.`);
    return text;
  };
  const canonical = value => {
    if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
    if (value && typeof value === 'object') return '{' + Object.keys(value).sort().map(key => JSON.stringify(key) + ':' + canonical(value[key])).join(',') + '}';
    return JSON.stringify(value);
  };
  function validateReport(value) {
    exactKeys(value, ['schema','scenario','scenarioDigest','release','generatedFromKitAt','completedAt','outcomes','tasks','facilitatorBoundary','privacy'], 'Fieldbook report');
    if (value.schema !== reportSchema) throw new Error(`Expected ${reportSchema}.`);
    const scenario = boundedText(value.scenario, 'scenario', 80);
    const scenarioDigest = boundedText(value.scenarioDigest, 'scenarioDigest', 64);
    if (!/^[0-9a-f]{64}$/.test(scenarioDigest)) throw new Error('scenarioDigest must be one lowercase SHA-256.');
    exactKeys(value.release, ['version','revision','codename'], 'release');
    const release = {version:boundedText(value.release.version,'release.version',40), revision:boundedText(value.release.revision,'release.revision',40), codename:boundedText(value.release.codename,'release.codename',60)};
    const generatedFromKitAt = boundedText(value.generatedFromKitAt, 'generatedFromKitAt', 80);
    const completedAt = boundedText(value.completedAt, 'completedAt', 80);
    exactKeys(value.outcomes, outcomeValues, 'outcomes');
    const outcomes = {};
    outcomeValues.forEach(key => { const count = value.outcomes[key]; if (!Number.isInteger(count) || count < 0 || count > 20) throw new Error(`outcomes.${key} is invalid.`); outcomes[key] = count; });
    if (!Array.isArray(value.tasks) || !value.tasks.length || value.tasks.length > 20) throw new Error('tasks must contain one bounded task list.');
    const seen = new Set(), computed = Object.fromEntries(outcomeValues.map(key => [key,0]));
    const tasks = value.tasks.map((row, index) => {
      exactKeys(row, ['id','title','outcome','notes'], `task ${index + 1}`);
      const id = boundedText(row.id, `task ${index + 1}.id`, 80);
      if (!/^[a-z0-9][a-z0-9-]{0,79}$/.test(id) || seen.has(id)) throw new Error(`task ${index + 1}.id is invalid or duplicated.`); seen.add(id);
      const title = boundedText(row.title, `task ${index + 1}.title`, 160);
      const outcome = boundedText(row.outcome, `task ${index + 1}.outcome`, 40);
      if (!outcomeValues.includes(outcome)) throw new Error(`task ${index + 1}.outcome is unsupported.`);
      const notes = boundedText(row.notes, `task ${index + 1}.notes`, limits.taskNotesCharacters, true);
      computed[outcome] += 1; return {id,title,outcome,notes};
    });
    if (outcomeValues.some(key => outcomes[key] !== computed[key])) throw new Error('Outcome totals do not match task outcomes.');
    exactKeys(value.facilitatorBoundary, ['testedProductNotParticipant','avoidedSensitiveNotes','exactReleaseOpen'], 'facilitatorBoundary');
    if (Object.values(value.facilitatorBoundary).some(flag => flag !== true)) throw new Error('The report does not confirm all research boundaries.');
    exactKeys(value.privacy, ['participantIdentityRecorded','automaticPersistence','telemetry','network'], 'privacy');
    if (Object.values(value.privacy).some(flag => flag !== false)) throw new Error('The report privacy boundary is incompatible with local debrief.');
    return {schema:reportSchema,scenario,scenarioDigest,release,generatedFromKitAt,completedAt,outcomes,tasks,facilitatorBoundary:{testedProductNotParticipant:true,avoidedSensitiveNotes:true,exactReleaseOpen:true},privacy:{participantIdentityRecorded:false,automaticPersistence:false,telemetry:false,network:false}};
  }
  function taskSignature(report) { return report.tasks.map(row => `${row.id}\u0000${row.title}`).join('\u0001'); }
  function compatible(report) {
    if (!state.scenario) return;
    if (report.scenario !== state.scenario.scenario || report.scenarioDigest !== state.scenario.scenarioDigest) throw new Error('That report belongs to a different Fieldbook scenario.');
    if (canonical(report.release) !== canonical(state.scenario.release)) throw new Error('That report names a different product release.');
    if (taskSignature(report) !== state.scenario.taskSignature) throw new Error('That report uses a different task sequence.');
  }
  function addReport(value) {
    const report = validateReport(value); compatible(report);
    const key = canonical(report);
    if (state.keys.has(key)) return false;
    if (state.reports.length >= limits.reports) throw new Error(`At most ${limits.reports} reports may be loaded.`);
    if (!state.scenario) state.scenario = {scenario:report.scenario,scenarioDigest:report.scenarioDigest,release:report.release,taskSignature:taskSignature(report)};
    state.keys.add(key); state.reports.push(report); return true;
  }
  function aggregate() {
    const first = state.reports[0];
    const tasks = first.tasks.map(task => ({id:task.id,title:task.title,counts:Object.fromEntries(outcomeValues.map(key => [key,0])),notes:[]}));
    const totals = Object.fromEntries(outcomeValues.map(key => [key,0]));
    state.reports.forEach((report, reportIndex) => report.tasks.forEach((task, taskIndex) => {
      tasks[taskIndex].counts[task.outcome] += 1; totals[task.outcome] += 1;
      if (task.notes) tasks[taskIndex].notes.push({report:reportIndex + 1,text:task.notes});
    }));
    return {tasks,totals};
  }
  function signals(counts) {
    const list = [];
    if (state.reports.length < 2) list.push({kind:'coverage',label:'One report only'});
    if (counts['wrong-turn'] >= 2) list.push({kind:'alert',label:'Recurring wrong turn to review'});
    if (counts['neutral-prompt'] >= 2) list.push({kind:'prompt',label:'Prompt-dependent understanding to review'});
    if (counts['not-observed'] >= Math.ceil(state.reports.length / 2)) list.push({kind:'coverage',label:'Coverage gap'});
    if (!list.length) list.push({kind:'',label:'No recurring signal yet'});
    return list;
  }
  function countCard(value, label) { return node('article',{class:'count'},[node('strong',{text:String(value)}),node('span',{text:label})]); }
  function decisionState(task) {
    return {id:task.id,title:task.title,counts:task.counts,signals:signals(task.counts).map(row => row.label),disposition:$(`#disposition-${task.id}`).value,finding:clean($(`#finding-${task.id}`).value).slice(0,limits.findingCharacters),productResponse:clean($(`#action-${task.id}`).value).slice(0,limits.actionCharacters)};
  }
  function render() {
    const section = $('#analysis');
    if (!state.reports.length) { section.hidden = true; $('#review-panel').hidden = true; return; }
    const data = aggregate(); section.hidden = false;
    $('#scenario-line').textContent = `${state.reports.length} local report${state.reports.length === 1 ? '' : 's'} · ${state.scenario.release.version} / ${state.scenario.release.revision} / ${state.scenario.release.codename} · scenario ${state.scenario.scenarioDigest.slice(0,12)}`;
    const metrics = [
      [state.reports.length,'Reports loaded'],[data.totals['wrong-turn'],'Wrong-turn observations'],[data.totals['neutral-prompt'],'Neutral-prompt observations'],[data.totals['independent'],'Independent observations'],[data.totals['not-observed'],'Not observed'],
    ];
    $('#metrics').replaceChildren(...metrics.map(([value,label]) => node('article',{class:'metric'},[node('strong',{text:String(value)}),node('span',{text:label})])));
    $('#tasks').replaceChildren(...data.tasks.map((task,index) => {
      const card = node('article',{class:'task',id:`task-${task.id}`});
      card.append(node('div',{class:'task-head'},[node('div',{},[node('span',{class:'task-number',text:`Task ${index + 1}`}),node('h3',{text:task.title})]),node('span',{class:'muted',text:`${state.reports.length} report${state.reports.length === 1 ? '' : 's'}`})]));
      card.append(node('div',{class:'signal-row'},signals(task.counts).map(row => node('span',{class:`signal ${row.kind}`,text:row.label}))));
      card.append(node('div',{class:'counts'},outcomeValues.map(key => countCard(task.counts[key], outcomeLabels[key]))));
      const notes = node('details'); notes.append(node('summary',{text:`Review local notes (${task.notes.length}) — excluded from export`}));
      const list = node('ul',{class:'notes'});
      if (task.notes.length) task.notes.forEach(row => list.append(node('li',{},[node('small',{text:`Local report ${row.report}`}),document.createTextNode(row.text)])));
      else list.append(node('li',{text:'No facilitator note was recorded for this task.'}));
      notes.append(list); card.append(notes);
      const grid = node('div',{class:'decision-grid'});
      const select = node('select',{id:`disposition-${task.id}`}); select.append(node('option',{value:'',text:'Choose one…'})); workspace.dispositions.forEach(row => select.append(node('option',{value:row.value,text:row.label})));
      select.addEventListener('change',changed);
      grid.append(node('label',{htmlFor:select.id},['Debrief disposition',select]));
      const finding = node('textarea',{id:`finding-${task.id}`,maxlength:String(limits.findingCharacters)}); finding.addEventListener('input',changed);
      grid.append(node('label',{htmlFor:finding.id},['Finding grounded in these reports',finding,node('span',{class:'help'},[node('span',{text:'Do not copy identifying or sensitive details.'}),node('span',{id:`finding-count-${task.id}`,text:`0/${limits.findingCharacters}`})]) ]));
      const action = node('textarea',{id:`action-${task.id}`,maxlength:String(limits.actionCharacters)}); action.addEventListener('input',changed);
      grid.append(node('label',{htmlFor:action.id},['Smallest product response to try',action,node('span',{class:'help'},[node('span',{text:'A hypothesis, not an automatic change.'}),node('span',{id:`action-count-${task.id}`,text:`0/${limits.actionCharacters}`})]) ]));
      card.append(grid); return card;
    }));
    $('#analysis').scrollIntoView({block:'start'}); $('#summary-heading').focus();
  }
  function changed(event) {
    state.edited = true; state.exported = false; $('#review-panel').hidden = true;
    const target = event.target; if (target.tagName === 'TEXTAREA') { const prefix = target.id.startsWith('finding-') ? 'finding-count-' : 'action-count-'; const id = target.id.replace(/^finding-|^action-/,''); $(`#${prefix}${id}`).textContent = `${target.value.length}/${target.maxLength}`; }
    const card = target.closest('.task'); if (card) card.classList.toggle('reviewed', Boolean(card.querySelector('select')?.value));
  }
  async function loadSelected() {
    const files = [...$('#reports').files];
    if (!files.length) { show('Choose one or more Fieldbook JSON reports.', 'error'); $('#reports').focus(); return; }
    const total = files.reduce((sum,file) => sum + file.size,0);
    if (total > limits.totalBytes) { show(`Selected files exceed the ${limits.totalBytes} byte total limit.`, 'error'); return; }
    let added = 0, duplicate = 0;
    try {
      for (const file of files) {
        if (file.size > limits.reportBytes) throw new Error(`${file.name} exceeds the ${limits.reportBytes} byte report limit.`);
        let value; try { value = JSON.parse(await file.text()); } catch { throw new Error(`${file.name} is not valid UTF-8 JSON.`); }
        if (addReport(value)) added += 1; else duplicate += 1;
      }
      render(); show(`${added} report${added === 1 ? '' : 's'} loaded${duplicate ? ` · ${duplicate} exact duplicate${duplicate === 1 ? '' : 's'} ignored` : ''}. Nothing was uploaded.`, 'good');
    } catch (error) { show(error.message, 'error'); }
    $('#reports').value = '';
  }
  function show(message, kind='') { const status = $('#status'); status.textContent = message; status.className = `status ${kind}`; }
  function review() {
    const data = aggregate(); const decisions = data.tasks.map(decisionState);
    const missing = decisions.find(row => !row.disposition);
    if (missing) { show(`Choose a debrief disposition for ${missing.title}.`, 'error'); $(`#disposition-${missing.id}`).focus(); return; }
    const summary = Object.fromEntries(workspace.dispositions.map(row => [row.value,0])); decisions.forEach(row => summary[row.disposition] += 1);
    $('#review-metrics').replaceChildren(...workspace.dispositions.map(row => node('article',{class:'metric'},[node('strong',{text:String(summary[row.value])}),node('span',{text:row.label})])));
    $('#review-list').replaceChildren(...decisions.map(row => node('li',{},[node('strong',{text:`${row.title} — ${dispositionLabels[row.disposition]}`}),node('small',{text:row.finding || 'No finding written.'}),node('small',{text:row.productResponse ? `Response: ${row.productResponse}` : 'No product response written.'})])));
    ['#privacy-text','#privacy-scope','#privacy-notes'].forEach(selector => { $(selector).checked = false; }); toggleDownloads();
    $('#review-panel').hidden = false; $('#review-panel').scrollIntoView({block:'start'}); $('#review-heading').focus();
    show('Debrief assembled in memory. Review product findings and confirm the privacy boundary before downloading.', 'good');
  }
  function toggleDownloads() { const ready = ['#privacy-text','#privacy-scope','#privacy-notes'].every(selector => $(selector).checked); $('#download-json').disabled = !ready; $('#download-md').disabled = !ready; }
  function debrief() {
    const data = aggregate(); const decisions = data.tasks.map(decisionState);
    return {schema:debriefSchema,scenario:state.scenario.scenario,scenarioDigest:state.scenario.scenarioDigest,release:state.scenario.release,createdAt:new Date().toISOString(),reportCount:state.reports.length,outcomeTotals:data.totals,tasks:decisions,interpretationBoundary:{countsDescribeLoadedReportsOnly:true,noParticipantScore:true,noProductPassClaim:true},privacy:{participantIdentityRecorded:false,rawNotesExported:false,automaticPersistence:false,telemetry:false,network:false}};
  }
  function markdown(data) {
    const lines = ['# ProgRSS fieldwork debrief','',`- Schema: ${data.schema}`,`- Release: ${data.release.version} / ${data.release.revision} / ${data.release.codename}`,`- Scenario: ${data.scenario}`,`- Scenario digest: ${data.scenarioDigest}`,`- Reports: ${data.reportCount}`,`- Created: ${data.createdAt}`,'','## Outcome totals'];
    outcomeValues.forEach(key => lines.push(`- ${outcomeLabels[key]}: ${data.outcomeTotals[key] || 0}`));
    lines.push('','## Product review'); data.tasks.forEach((row,index) => { lines.push('',`### ${index + 1}. ${row.title}`,`- Disposition: ${dispositionLabels[row.disposition]}`,`- Signals: ${row.signals.join('; ')}`,`- Finding: ${row.finding || 'None written.'}`,`- Product response: ${row.productResponse || 'None written.'}`); });
    lines.push('','## Interpretation and privacy boundary','- Counts describe only the loaded reports.','- No participant score or product pass claim was calculated.','- Raw facilitator notes were not exported.','- No participant identity field, telemetry, network request, or automatic persistence was used.'); return lines.join('\n') + '\n';
  }
  function download(filename,type,content) { const url = URL.createObjectURL(new Blob([content],{type})); const anchor = document.createElement('a'); anchor.href=url; anchor.download=filename; document.body.append(anchor); anchor.click(); anchor.remove(); setTimeout(() => URL.revokeObjectURL(url),1000); state.exported=true; show(`${filename} downloaded locally. ProgRSS uploaded nothing.`, 'good'); }
  function clearAll() {
    if ((state.reports.length || state.edited) && !confirm('Clear every loaded report and debrief note without saving?')) return;
    state.reports=[]; state.keys.clear(); state.scenario=null; state.edited=false; state.exported=false; $('#tasks').replaceChildren(); $('#analysis').hidden=true; $('#review-panel').hidden=true; $('#reports').value=''; show('Workspace cleared. Nothing was uploaded or saved.', '');
  }
  $('#theme').addEventListener('click', event => { const light = document.documentElement.dataset.theme !== 'light'; document.documentElement.dataset.theme = light ? 'light' : 'dark'; event.currentTarget.textContent = light ? '☾ Theme' : '☼ Theme'; event.currentTarget.setAttribute('aria-label', light ? 'Use dark theme' : 'Use light theme'); });
  $('#load').addEventListener('click', loadSelected); $('#clear').addEventListener('click', clearAll); $('#review').addEventListener('click', review); $('#print').addEventListener('click', () => window.print()); $('#back').addEventListener('click', () => { $('#review-panel').hidden=true; $('#review').focus(); });
  ['#privacy-text','#privacy-scope','#privacy-notes'].forEach(selector => $(selector).addEventListener('change', toggleDownloads));
  $('#download-json').addEventListener('click', () => { const data=debrief(); download(`progrss-debrief-${data.scenarioDigest.slice(0,12)}.json`,'application/json',JSON.stringify(data,null,2)+'\n'); });
  $('#download-md').addEventListener('click', () => { const data=debrief(); download(`progrss-debrief-${data.scenarioDigest.slice(0,12)}.md`,'text/markdown;charset=utf-8',markdown(data)); });
  window.addEventListener('beforeunload', event => { if (state.exported) return; if (state.reports.length || state.edited) { event.preventDefault(); event.returnValue=''; } });
  try { (workspace.preloadedReports || []).forEach(addReport); if (state.reports.length) { render(); show(`${state.reports.length} preloaded local report${state.reports.length === 1 ? '' : 's'} ready · ${workspace.duplicatesRemoved || 0} duplicate${workspace.duplicatesRemoved === 1 ? '' : 's'} removed.`, 'good'); } } catch (error) { show(error.message, 'error'); }
})();
</script>
</main>
<footer><p>Local Fieldbook analysis · no telemetry · no automatic persistence · no participant score · raw notes excluded from export · <code>__KIT_SCHEMA__</code></p></footer>
</body>
</html>
'''
    document = (
        document.replace("__WORKSPACE_JSON__", workspace_json)
        .replace("__VERSION__", version)
        .replace("__REVISION__", revision)
        .replace("__CODENAME__", codename)
        .replace("__KIT_SCHEMA__", DEBRIEF_KIT_SCHEMA)
    )
    return document.encode("utf-8")
