#!/usr/bin/env python3
"""Transactional ProgRSS Node-owned library storage.

This module deliberately stores one complete ``progrss.private.v1`` document as the
canonical portable library representation. SQLite supplies the single-writer,
atomic-commit, durable-receipt, and rollback-evidence boundary. The Node web API
exposes only narrowly typed operations; this module is not a generic object store.
"""

from __future__ import annotations

import copy
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import sqlite3
import tempfile
import time
from typing import Any, Mapping

try:
    from .source_notes_native import SourceNoteError, validate_private_source_note_placements
except ImportError:  # Direct CLI execution from this directory.
    from source_notes_native import SourceNoteError, validate_private_source_note_placements

STORE_SCHEMA = "progrss.node-store.v4"
PREVIOUS_STORE_SCHEMA = "progrss.node-store.v3"
V2_STORE_SCHEMA = "progrss.node-store.v2"
LEGACY_STORE_SCHEMA = "progrss.node-store.v1"
STORE_USER_VERSION = 4
STORE_APPLICATION_ID = 0x50525353  # ASCII-ish "PRSS"
BACKUP_SCHEMA = "progrss.private.v1"
OPERATION_SCHEMA = "progrss.node.operation.v1"
OPERATION_RECEIPT_SCHEMA = "progrss.node.operation-receipt.v1"
OPERATION_RESULT_SCHEMA = "progrss.node.operation-result.v1"
ACQUISITION_JOB_SCHEMA = "progrss.node.acquisition-job.v1"
ACQUISITION_RECEIPT_SCHEMA = "progrss.node.acquisition-receipt.v1"
ACQUISITION_RESULT_SCHEMA = "progrss.node.acquisition-result.v1"
CAPTURE_HOLD_SCHEMA = "progrss.node.capture-hold.v1"
CAPTURE_HOLD_HISTORY_SCHEMA = "progrss.node.capture-hold-history.v1"
MAX_CAPTURE_HOLD_HISTORY = 8
BASELINE_REPLACEMENT_OPERATION = "replace-held-page-baseline"
MAX_BACKUP_BYTES = 24_000_000
MAX_RECEIPT_ROWS = 500
_SQLITE_HEADER = b"SQLite format 3\x00"
_OPERATION_ID = re.compile(r"[A-Za-z0-9._~-]{16,200}")
_SHA256 = re.compile(r"[0-9a-f]{64}")


class NodeStoreError(Exception):
    """Expected Node-owned-library failure."""


class NodeStoreConflict(NodeStoreError):
    """The requested write conflicts with current durable state."""


@dataclass(frozen=True, slots=True)
class LibraryRecord:
    document: dict[str, Any]
    raw: bytes
    sha256: str
    revision: int
    updated_at: str


@dataclass(frozen=True, slots=True)
class CommitResult:
    receipt: dict[str, Any]
    replayed: bool


@dataclass(frozen=True, slots=True)
class AcquisitionStart:
    receipt: dict[str, Any] | None
    replayed: bool
    attempt: int
    resumed: bool


def _iso(timestamp: float | None = None, *, milliseconds: bool = True) -> str:
    instant = datetime.fromtimestamp(time.time() if timestamp is None else float(timestamp), tz=timezone.utc)
    timespec = "milliseconds" if milliseconds else "seconds"
    return instant.isoformat(timespec=timespec).replace("+00:00", "Z")


def _json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=False) + "\n").encode("utf-8")


def _canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _fsync_directory(path: Path) -> None:
    flags = os.O_RDONLY | getattr(os, "O_DIRECTORY", 0)
    try:
        descriptor = os.open(path, flags)
    except OSError:
        return
    try:
        os.fsync(descriptor)
    except OSError:
        pass
    finally:
        os.close(descriptor)


def _strict_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise NodeStoreError(f"duplicate JSON key in private backup: {key}")
        result[key] = value
    return result


def _validate_backup_bytes(raw: bytes, label: str = "private backup") -> dict[str, Any]:
    if len(raw) > MAX_BACKUP_BYTES:
        raise NodeStoreError(f"{label} is larger than the 24 MB Node limit")
    try:
        document = json.loads(raw.decode("utf-8-sig"), object_pairs_hook=_strict_pairs)
    except UnicodeDecodeError as exc:
        raise NodeStoreError(f"{label} is not UTF-8 JSON") from exc
    except json.JSONDecodeError as exc:
        raise NodeStoreError(f"{label} is invalid JSON at line {exc.lineno}, column {exc.colno}") from exc
    if not isinstance(document, dict) or document.get("schema") != BACKUP_SCHEMA:
        raise NodeStoreError(f"expected {BACKUP_SCHEMA}")
    state = document.get("state")
    if not isinstance(state, dict):
        raise NodeStoreError("the private backup has no state object")
    for key, limit in (("sources", 200), ("collections", 200), ("items", 1_200)):
        rows = state.get(key, [])
        if not isinstance(rows, list):
            raise NodeStoreError(f"state.{key} must be an array")
        if len(rows) > limit:
            raise NodeStoreError(f"state.{key} exceeds the Node limit of {limit}")
    try:
        validate_private_source_note_placements(state)
    except SourceNoteError as exc:
        raise NodeStoreError(f"{label} has invalid Source Notes: {exc}") from exc
    return document


def is_node_store(path: Path) -> bool:
    """Return True only when *path* begins with the SQLite file signature."""
    try:
        with path.expanduser().open("rb") as handle:
            return handle.read(len(_SQLITE_HEADER)) == _SQLITE_HEADER
    except OSError:
        return False


class NodeStore:
    """One Node-owned portable library plus durable operation evidence."""

    def __init__(self, path: Path):
        self.path = path.expanduser().resolve()
        if not self.path.is_file() or self.path.is_symlink():
            raise NodeStoreError("the Node-owned library must be one regular local file")
        if not is_node_store(self.path):
            raise NodeStoreError("the selected file is not a ProgRSS Node-owned library")
        self.migrated = self._upgrade_if_needed()
        self._verify_store()

    @classmethod
    def create_from_backup(
        cls,
        backup: Path,
        output: Path,
        *,
        now: float | None = None,
    ) -> dict[str, Any]:
        backup = backup.expanduser().resolve()
        output = output.expanduser().resolve()
        if output.exists():
            raise NodeStoreError(f"output already exists: {output}")
        if not backup.is_file() or backup.is_symlink():
            raise NodeStoreError("the import source must be one regular private-backup file")
        try:
            raw = backup.read_bytes()
        except OSError as exc:
            raise NodeStoreError(f"could not read {backup}: {exc}") from exc
        document = _validate_backup_bytes(raw)
        digest = _sha256(raw)
        created_at = _iso(now)
        store_id = secrets.token_hex(16)
        output.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix=f".{output.name}.", suffix=".sqlite3.tmp", dir=output.parent)
        os.close(fd)
        temp = Path(temp_name)
        try:
            connection = sqlite3.connect(temp, timeout=5.0, isolation_level=None)
            try:
                connection.execute("PRAGMA journal_mode=WAL")
                connection.execute("PRAGMA synchronous=FULL")
                connection.execute("PRAGMA foreign_keys=ON")
                connection.execute(f"PRAGMA application_id={STORE_APPLICATION_ID}")
                connection.execute(f"PRAGMA user_version={STORE_USER_VERSION}")
                connection.executescript(
                    """
                    BEGIN IMMEDIATE;
                    CREATE TABLE metadata (
                        key TEXT PRIMARY KEY,
                        value TEXT NOT NULL
                    ) WITHOUT ROWID;
                    CREATE TABLE library (
                        singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
                        document_json BLOB NOT NULL,
                        sha256 TEXT NOT NULL CHECK (length(sha256) = 64),
                        revision INTEGER NOT NULL CHECK (revision >= 1),
                        updated_at TEXT NOT NULL
                    );
                    CREATE TABLE imports (
                        import_id TEXT PRIMARY KEY,
                        imported_at TEXT NOT NULL,
                        source_file TEXT NOT NULL,
                        source_sha256 TEXT NOT NULL CHECK (length(source_sha256) = 64),
                        source_bytes BLOB NOT NULL
                    ) WITHOUT ROWID;
                    CREATE TABLE operation_snapshots (
                        snapshot_id TEXT PRIMARY KEY,
                        operation_id TEXT UNIQUE NOT NULL,
                        created_at TEXT NOT NULL,
                        library_sha256 TEXT NOT NULL CHECK (length(library_sha256) = 64),
                        document_json BLOB NOT NULL
                    ) WITHOUT ROWID;
                    CREATE TABLE operation_receipts (
                        operation_id TEXT PRIMARY KEY,
                        operation_type TEXT NOT NULL,
                        actor TEXT NOT NULL,
                        request_sha256 TEXT NOT NULL CHECK (length(request_sha256) = 64),
                        base_sha256 TEXT NOT NULL CHECK (length(base_sha256) = 64),
                        preview_sha256 TEXT NOT NULL CHECK (length(preview_sha256) = 64),
                        result_sha256 TEXT NOT NULL CHECK (length(result_sha256) = 64),
                        committed_at TEXT NOT NULL,
                        receipt_json BLOB NOT NULL
                    ) WITHOUT ROWID;
                    CREATE INDEX receipt_committed_at ON operation_receipts(committed_at DESC);
                    CREATE TABLE acquisition_jobs (
                        operation_id TEXT PRIMARY KEY,
                        request_sha256 TEXT NOT NULL CHECK (length(request_sha256) = 64),
                        source_id TEXT NOT NULL,
                        base_sha256 TEXT NOT NULL CHECK (length(base_sha256) = 64),
                        preview_sha256 TEXT NOT NULL CHECK (length(preview_sha256) = 64),
                        state TEXT NOT NULL CHECK (state IN ('started', 'completed')),
                        attempt_count INTEGER NOT NULL CHECK (attempt_count >= 1),
                        started_at TEXT NOT NULL,
                        completed_at TEXT,
                        receipt_id TEXT
                    ) WITHOUT ROWID;
                    CREATE INDEX acquisition_job_started_at ON acquisition_jobs(started_at DESC);
                    CREATE TABLE acquisition_receipts (
                        operation_id TEXT PRIMARY KEY,
                        source_id TEXT NOT NULL,
                        request_sha256 TEXT NOT NULL CHECK (length(request_sha256) = 64),
                        base_sha256 TEXT NOT NULL CHECK (length(base_sha256) = 64),
                        result_sha256 TEXT NOT NULL CHECK (length(result_sha256) = 64),
                        outcome TEXT NOT NULL,
                        committed_at TEXT NOT NULL,
                        receipt_json BLOB NOT NULL,
                        FOREIGN KEY(operation_id) REFERENCES acquisition_jobs(operation_id)
                    ) WITHOUT ROWID;
                    CREATE INDEX acquisition_receipt_committed_at ON acquisition_receipts(committed_at DESC);
                    CREATE TABLE capture_holds (
                        source_id TEXT PRIMARY KEY,
                        capture_operation_id TEXT UNIQUE NOT NULL,
                        capture_receipt_id TEXT NOT NULL,
                        held_at TEXT NOT NULL,
                        held_library_sha256 TEXT NOT NULL CHECK (length(held_library_sha256) = 64),
                        source_identity_sha256 TEXT NOT NULL CHECK (length(source_identity_sha256) = 64),
                        artifact_sha256 TEXT NOT NULL CHECK (length(artifact_sha256) = 64),
                        accepted_snapshot_sha256 TEXT NOT NULL CHECK (length(accepted_snapshot_sha256) = 64),
                        proposed_snapshot_sha256 TEXT NOT NULL CHECK (length(proposed_snapshot_sha256) = 64),
                        proposed_snapshot_json BLOB NOT NULL,
                        proposed_provenance_json BLOB NOT NULL,
                        continuity_json BLOB NOT NULL,
                        FOREIGN KEY(capture_operation_id) REFERENCES acquisition_receipts(operation_id)
                    ) WITHOUT ROWID;
                    CREATE INDEX capture_hold_held_at ON capture_holds(held_at DESC);
                    CREATE TABLE capture_hold_history (
                        capture_operation_id TEXT PRIMARY KEY,
                        source_id TEXT NOT NULL,
                        capture_receipt_id TEXT NOT NULL,
                        held_at TEXT NOT NULL,
                        held_library_sha256 TEXT NOT NULL CHECK (length(held_library_sha256) = 64),
                        source_identity_sha256 TEXT NOT NULL CHECK (length(source_identity_sha256) = 64),
                        artifact_sha256 TEXT NOT NULL CHECK (length(artifact_sha256) = 64),
                        accepted_snapshot_sha256 TEXT NOT NULL CHECK (length(accepted_snapshot_sha256) = 64),
                        proposed_snapshot_sha256 TEXT NOT NULL CHECK (length(proposed_snapshot_sha256) = 64),
                        proposed_snapshot_json BLOB NOT NULL,
                        proposed_provenance_json BLOB NOT NULL,
                        continuity_json BLOB NOT NULL,
                        FOREIGN KEY(capture_operation_id) REFERENCES acquisition_receipts(operation_id)
                    ) WITHOUT ROWID;
                    CREATE INDEX capture_hold_history_source_at ON capture_hold_history(source_id, held_at DESC);
                    COMMIT;
                    """
                )
                connection.execute("BEGIN IMMEDIATE")
                connection.executemany(
                    "INSERT INTO metadata(key, value) VALUES (?, ?)",
                    (
                        ("schema", STORE_SCHEMA),
                        ("storeId", store_id),
                        ("createdAt", created_at),
                        ("importSource", backup.name),
                        ("importSha256", digest),
                    ),
                )
                connection.execute(
                    "INSERT INTO library(singleton, document_json, sha256, revision, updated_at) VALUES (1, ?, ?, 1, ?)",
                    (sqlite3.Binary(raw), digest, created_at),
                )
                connection.execute(
                    "INSERT INTO imports(import_id, imported_at, source_file, source_sha256, source_bytes) VALUES (?, ?, ?, ?, ?)",
                    (f"import-{store_id}", created_at, backup.name, digest, sqlite3.Binary(raw)),
                )
                connection.execute("COMMIT")
                connection.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                check = connection.execute("PRAGMA integrity_check").fetchone()
                if not check or check[0] != "ok":
                    raise NodeStoreError("SQLite integrity check failed while creating the Node-owned library")
            finally:
                connection.close()
            try:
                os.link(temp, output)
            except FileExistsError as exc:
                raise NodeStoreError(f"output already exists: {output}") from exc
            except OSError:
                # Exclusive-copy fallback for filesystems without hard-link support.
                flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
                try:
                    out_fd = os.open(output, flags, 0o600)
                except FileExistsError as exc:
                    raise NodeStoreError(f"output already exists: {output}") from exc
                try:
                    with os.fdopen(out_fd, "wb") as target, temp.open("rb") as source:
                        while True:
                            block = source.read(1024 * 1024)
                            if not block:
                                break
                            target.write(block)
                        target.flush()
                        os.fsync(target.fileno())
                except Exception:
                    try:
                        output.unlink()
                    except OSError:
                        pass
                    raise
            _fsync_directory(output.parent)
        finally:
            try:
                temp.unlink()
            except OSError:
                pass
            for suffix in ("-wal", "-shm"):
                try:
                    Path(str(temp) + suffix).unlink()
                except OSError:
                    pass
        store = cls(output)
        current = store.read_library()
        return {
            "schema": STORE_SCHEMA,
            "state": "created",
            "file": output.name,
            "storeId": store.store_id,
            "createdAt": created_at,
            "import": {
                "file": backup.name,
                "sha256": digest,
                "bytes": len(raw),
                "preserved": True,
            },
            "library": {
                "sha256": current.sha256,
                "revision": current.revision,
                "bytes": len(current.raw),
                "sources": len(document["state"].get("sources", [])),
                "collections": len(document["state"].get("collections", [])),
                "items": len(document["state"].get("items", [])),
            },
            "network": False,
            "writes": True,
        }

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=5.0, isolation_level=None)
        try:
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA foreign_keys=ON")
            connection.execute("PRAGMA busy_timeout=5000")
            connection.execute("PRAGMA synchronous=FULL")
            return connection
        except Exception:
            connection.close()
            raise

    def _upgrade_if_needed(self) -> bool:
        """Upgrade older Node stores without rewriting portable library bytes.

        v1 lacked acquisition evidence. v2 added Witness/Capture jobs and receipts.
        v3 added one current pending Capture-hold record per watched page. v4 adds
        a bounded unresolved-history table so Bearing can explain repeated held
        windows without placing browser observations in the portable library.
        """
        try:
            connection = self._connect()
        except sqlite3.Error as exc:
            raise NodeStoreError(f"could not open Node-owned library: {exc}") from exc
        try:
            app_id = int(connection.execute("PRAGMA application_id").fetchone()[0])
            version = int(connection.execute("PRAGMA user_version").fetchone()[0])
            if app_id != STORE_APPLICATION_ID:
                raise NodeStoreError("the SQLite file is not a supported ProgRSS Node-owned library")
            if version == STORE_USER_VERSION:
                return False
            if version not in {1, 2, 3}:
                raise NodeStoreError("the SQLite file is not a supported ProgRSS Node-owned library")
            rows = dict(connection.execute("SELECT key, value FROM metadata"))
            expected_schema = {1: LEGACY_STORE_SCHEMA, 2: V2_STORE_SCHEMA, 3: PREVIOUS_STORE_SCHEMA}[version]
            if rows.get("schema") != expected_schema or not rows.get("storeId"):
                raise NodeStoreError("the older Node-owned library metadata is incomplete")
            connection.execute("BEGIN IMMEDIATE")
            if version == 1:
                for statement in (
                    """CREATE TABLE acquisition_jobs (
                        operation_id TEXT PRIMARY KEY,
                        request_sha256 TEXT NOT NULL CHECK (length(request_sha256) = 64),
                        source_id TEXT NOT NULL,
                        base_sha256 TEXT NOT NULL CHECK (length(base_sha256) = 64),
                        preview_sha256 TEXT NOT NULL CHECK (length(preview_sha256) = 64),
                        state TEXT NOT NULL CHECK (state IN ('started', 'completed')),
                        attempt_count INTEGER NOT NULL CHECK (attempt_count >= 1),
                        started_at TEXT NOT NULL,
                        completed_at TEXT,
                        receipt_id TEXT
                    ) WITHOUT ROWID""",
                    "CREATE INDEX acquisition_job_started_at ON acquisition_jobs(started_at DESC)",
                    """CREATE TABLE acquisition_receipts (
                        operation_id TEXT PRIMARY KEY,
                        source_id TEXT NOT NULL,
                        request_sha256 TEXT NOT NULL CHECK (length(request_sha256) = 64),
                        base_sha256 TEXT NOT NULL CHECK (length(base_sha256) = 64),
                        result_sha256 TEXT NOT NULL CHECK (length(result_sha256) = 64),
                        outcome TEXT NOT NULL,
                        committed_at TEXT NOT NULL,
                        receipt_json BLOB NOT NULL,
                        FOREIGN KEY(operation_id) REFERENCES acquisition_jobs(operation_id)
                    ) WITHOUT ROWID""",
                    "CREATE INDEX acquisition_receipt_committed_at ON acquisition_receipts(committed_at DESC)",
                ):
                    connection.execute(statement)
            connection.execute(
                """CREATE TABLE IF NOT EXISTS capture_holds (
                    source_id TEXT PRIMARY KEY,
                    capture_operation_id TEXT UNIQUE NOT NULL,
                    capture_receipt_id TEXT NOT NULL,
                    held_at TEXT NOT NULL,
                    held_library_sha256 TEXT NOT NULL CHECK (length(held_library_sha256) = 64),
                    source_identity_sha256 TEXT NOT NULL CHECK (length(source_identity_sha256) = 64),
                    artifact_sha256 TEXT NOT NULL CHECK (length(artifact_sha256) = 64),
                    accepted_snapshot_sha256 TEXT NOT NULL CHECK (length(accepted_snapshot_sha256) = 64),
                    proposed_snapshot_sha256 TEXT NOT NULL CHECK (length(proposed_snapshot_sha256) = 64),
                    proposed_snapshot_json BLOB NOT NULL,
                    proposed_provenance_json BLOB NOT NULL,
                    continuity_json BLOB NOT NULL,
                    FOREIGN KEY(capture_operation_id) REFERENCES acquisition_receipts(operation_id)
                ) WITHOUT ROWID"""
            )
            connection.execute("CREATE INDEX IF NOT EXISTS capture_hold_held_at ON capture_holds(held_at DESC)")
            connection.execute(
                """CREATE TABLE IF NOT EXISTS capture_hold_history (
                    capture_operation_id TEXT PRIMARY KEY,
                    source_id TEXT NOT NULL,
                    capture_receipt_id TEXT NOT NULL,
                    held_at TEXT NOT NULL,
                    held_library_sha256 TEXT NOT NULL CHECK (length(held_library_sha256) = 64),
                    source_identity_sha256 TEXT NOT NULL CHECK (length(source_identity_sha256) = 64),
                    artifact_sha256 TEXT NOT NULL CHECK (length(artifact_sha256) = 64),
                    accepted_snapshot_sha256 TEXT NOT NULL CHECK (length(accepted_snapshot_sha256) = 64),
                    proposed_snapshot_sha256 TEXT NOT NULL CHECK (length(proposed_snapshot_sha256) = 64),
                    proposed_snapshot_json BLOB NOT NULL,
                    proposed_provenance_json BLOB NOT NULL,
                    continuity_json BLOB NOT NULL,
                    FOREIGN KEY(capture_operation_id) REFERENCES acquisition_receipts(operation_id)
                ) WITHOUT ROWID"""
            )
            connection.execute("CREATE INDEX IF NOT EXISTS capture_hold_history_source_at ON capture_hold_history(source_id, held_at DESC)")
            connection.execute("UPDATE metadata SET value=? WHERE key='schema'", (STORE_SCHEMA,))
            connection.execute(f"PRAGMA user_version={STORE_USER_VERSION}")
            connection.execute("COMMIT")
            connection.execute("PRAGMA wal_checkpoint(TRUNCATE)")
            return True
        except NodeStoreError:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise
        except sqlite3.Error as exc:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise NodeStoreError(f"could not upgrade Node-owned library: {exc}") from exc
        finally:
            connection.close()

    def _verify_store(self) -> None:
        try:
            connection = self._connect()
        except sqlite3.Error as exc:
            raise NodeStoreError(f"could not open Node-owned library: {exc}") from exc
        try:
            app_id = int(connection.execute("PRAGMA application_id").fetchone()[0])
            version = int(connection.execute("PRAGMA user_version").fetchone()[0])
            if app_id != STORE_APPLICATION_ID or version != STORE_USER_VERSION:
                raise NodeStoreError("the SQLite file is not a supported ProgRSS Node-owned library")
            rows = dict(connection.execute("SELECT key, value FROM metadata"))
            if rows.get("schema") != STORE_SCHEMA or not rows.get("storeId"):
                raise NodeStoreError("the Node-owned library metadata is incomplete")
            check = connection.execute("PRAGMA quick_check").fetchone()
            if not check or check[0] != "ok":
                raise NodeStoreError("the Node-owned library failed SQLite quick_check")
            record = connection.execute(
                "SELECT document_json, sha256, revision, updated_at FROM library WHERE singleton=1"
            ).fetchone()
            if record is None:
                raise NodeStoreError("the Node-owned library has no current library record")
            raw = bytes(record["document_json"])
            if _sha256(raw) != record["sha256"]:
                raise NodeStoreError("the Node-owned library digest does not match its stored bytes")
            _validate_backup_bytes(raw, "stored Node library")
        except sqlite3.Error as exc:
            raise NodeStoreError(f"invalid Node-owned library database: {exc}") from exc
        finally:
            connection.close()

    @property
    def store_id(self) -> str:
        connection = self._connect()
        try:
            row = connection.execute("SELECT value FROM metadata WHERE key='storeId'").fetchone()
            if row is None:
                raise NodeStoreError("the Node-owned library has no store identity")
            return str(row[0])
        finally:
            connection.close()

    def read_library(self) -> LibraryRecord:
        connection = self._connect()
        try:
            row = connection.execute(
                "SELECT document_json, sha256, revision, updated_at FROM library WHERE singleton=1"
            ).fetchone()
            if row is None:
                raise NodeStoreError("the Node-owned library has no current document")
            raw = bytes(row["document_json"])
            digest = str(row["sha256"])
            if _sha256(raw) != digest:
                raise NodeStoreError("the Node-owned library digest does not match its stored bytes")
            document = _validate_backup_bytes(raw, "stored Node library")
            return LibraryRecord(document=document, raw=raw, sha256=digest, revision=int(row["revision"]), updated_at=str(row["updated_at"]))
        except sqlite3.Error as exc:
            raise NodeStoreError(f"could not read Node-owned library: {exc}") from exc
        finally:
            connection.close()

    def metadata(self) -> dict[str, str]:
        connection = self._connect()
        try:
            return {str(row[0]): str(row[1]) for row in connection.execute("SELECT key, value FROM metadata ORDER BY key")}
        finally:
            connection.close()

    def find_receipt(self, operation_id: str) -> dict[str, Any] | None:
        connection = self._connect()
        try:
            row = connection.execute(
                "SELECT request_sha256, receipt_json FROM operation_receipts WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            if row is None:
                return None
            try:
                receipt = json.loads(bytes(row["receipt_json"]).decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise NodeStoreError("a stored operation receipt is unreadable") from exc
            if not isinstance(receipt, dict):
                raise NodeStoreError("a stored operation receipt is malformed")
            receipt["_requestSha256"] = str(row["request_sha256"])
            return receipt
        finally:
            connection.close()

    def list_receipts(self, limit: int = 50) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 100))
        connection = self._connect()
        try:
            rows = connection.execute(
                "SELECT receipt_json FROM operation_receipts ORDER BY committed_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
            receipts: list[dict[str, Any]] = []
            for row in rows:
                value = json.loads(bytes(row[0]).decode("utf-8"))
                if isinstance(value, dict):
                    receipts.append(value)
            return receipts
        except (sqlite3.Error, UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise NodeStoreError(f"could not read operation receipts: {exc}") from exc
        finally:
            connection.close()

    @staticmethod
    def _capture_hold_document(row: sqlite3.Row) -> dict[str, Any]:
        try:
            snapshot = json.loads(bytes(row["proposed_snapshot_json"]).decode("utf-8"))
            provenance = json.loads(bytes(row["proposed_provenance_json"]).decode("utf-8"))
            continuity = json.loads(bytes(row["continuity_json"]).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise NodeStoreError("a stored held Capture observation is unreadable") from exc
        if not isinstance(snapshot, dict) or not isinstance(provenance, dict) or not isinstance(continuity, dict):
            raise NodeStoreError("a stored held Capture observation is malformed")
        snapshot_sha256 = _sha256(_canonical_bytes(snapshot))
        if not secrets.compare_digest(snapshot_sha256, str(row["proposed_snapshot_sha256"])):
            raise NodeStoreError("a stored held Capture snapshot failed its digest check")
        return {
            "schema": CAPTURE_HOLD_SCHEMA,
            "sourceId": str(row["source_id"]),
            "captureOperationId": str(row["capture_operation_id"]),
            "captureReceiptId": str(row["capture_receipt_id"]),
            "heldAt": str(row["held_at"]),
            "heldLibrarySha256": str(row["held_library_sha256"]),
            "sourceIdentitySha256": str(row["source_identity_sha256"]),
            "artifactSha256": str(row["artifact_sha256"]),
            "acceptedSnapshotSha256": str(row["accepted_snapshot_sha256"]),
            "proposedSnapshotSha256": str(row["proposed_snapshot_sha256"]),
            "proposedSnapshot": snapshot,
            "proposedProvenance": provenance,
            "continuity": continuity,
        }

    def capture_hold(self, source_id: str) -> dict[str, Any] | None:
        connection = self._connect()
        try:
            row = connection.execute(
                "SELECT source_id, capture_operation_id, capture_receipt_id, held_at, held_library_sha256, "
                "source_identity_sha256, artifact_sha256, accepted_snapshot_sha256, proposed_snapshot_sha256, "
                "proposed_snapshot_json, proposed_provenance_json, continuity_json "
                "FROM capture_holds WHERE source_id=?",
                (str(source_id),),
            ).fetchone()
            return None if row is None else self._capture_hold_document(row)
        except sqlite3.Error as exc:
            raise NodeStoreError(f"could not read held Capture evidence: {exc}") from exc
        finally:
            connection.close()

    def capture_hold_history(self, source_id: str, limit: int = MAX_CAPTURE_HOLD_HISTORY) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), MAX_CAPTURE_HOLD_HISTORY))
        connection = self._connect()
        try:
            rows = connection.execute(
                "SELECT source_id, capture_operation_id, capture_receipt_id, held_at, held_library_sha256, "
                "source_identity_sha256, artifact_sha256, accepted_snapshot_sha256, proposed_snapshot_sha256, "
                "proposed_snapshot_json, proposed_provenance_json, continuity_json "
                "FROM capture_hold_history WHERE source_id=? ORDER BY held_at DESC, capture_operation_id DESC LIMIT ?",
                (str(source_id), limit),
            ).fetchall()
            return [self._capture_hold_document(row) for row in rows]
        except sqlite3.Error as exc:
            raise NodeStoreError(f"could not read held Capture history: {exc}") from exc
        finally:
            connection.close()

    def list_capture_holds(self, limit: int = 200) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 200))
        connection = self._connect()
        try:
            source_ids = [str(row[0]) for row in connection.execute(
                "SELECT source_id FROM capture_holds ORDER BY held_at DESC LIMIT ?", (limit,),
            )]
        finally:
            connection.close()
        result: list[dict[str, Any]] = []
        for source_id in source_ids:
            value = self.capture_hold(source_id)
            if value is not None:
                result.append(value)
        return result

    def read_snapshot(self, snapshot_id: str) -> tuple[bytes, str, str]:
        connection = self._connect()
        try:
            row = connection.execute(
                "SELECT document_json, library_sha256, operation_id FROM operation_snapshots WHERE snapshot_id=?",
                (snapshot_id,),
            ).fetchone()
            if row is None:
                raise NodeStoreError("operation snapshot was not found")
            raw = bytes(row["document_json"])
            digest = str(row["library_sha256"])
            if _sha256(raw) != digest:
                raise NodeStoreError("operation snapshot digest mismatch")
            _validate_backup_bytes(raw, "operation snapshot")
            return raw, digest, str(row["operation_id"])
        finally:
            connection.close()

    def export_current(self, output: Path) -> dict[str, Any]:
        output = output.expanduser().resolve()
        if output.exists():
            raise NodeStoreError(f"output already exists: {output}")
        record = self.read_library()
        output.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_name = tempfile.mkstemp(prefix=f".{output.name}.", suffix=".tmp", dir=output.parent)
        temp = Path(temp_name)
        try:
            with os.fdopen(fd, "wb") as handle:
                handle.write(record.raw)
                handle.flush()
                os.fsync(handle.fileno())
            try:
                os.link(temp, output)
            except FileExistsError as exc:
                raise NodeStoreError(f"output already exists: {output}") from exc
            except OSError:
                flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
                try:
                    out_fd = os.open(output, flags, 0o600)
                except FileExistsError as exc:
                    raise NodeStoreError(f"output already exists: {output}") from exc
                try:
                    with os.fdopen(out_fd, "wb") as handle:
                        handle.write(record.raw)
                        handle.flush()
                        os.fsync(handle.fileno())
                except Exception:
                    try:
                        output.unlink()
                    except OSError:
                        pass
                    raise
        finally:
            try:
                temp.unlink()
            except OSError:
                pass
        _fsync_directory(output.parent)
        written = output.read_bytes()
        if _sha256(written) != record.sha256:
            try:
                output.unlink()
            except OSError:
                pass
            raise NodeStoreError("exported backup failed digest read-back")
        return {
            "schema": STORE_SCHEMA,
            "state": "exported",
            "store": self.path.name,
            "output": output.name,
            "sha256": record.sha256,
            "bytes": len(record.raw),
            "revision": record.revision,
            "network": False,
            "writes": True,
        }

    def export_snapshot(self, snapshot_id: str, output: Path) -> dict[str, Any]:
        output = output.expanduser().resolve()
        if output.exists():
            raise NodeStoreError(f"output already exists: {output}")
        raw, digest, operation_id = self.read_snapshot(snapshot_id)
        output.parent.mkdir(parents=True, exist_ok=True)
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        try:
            descriptor = os.open(output, flags, 0o600)
        except FileExistsError as exc:
            raise NodeStoreError(f"output already exists: {output}") from exc
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(raw)
                handle.flush()
                os.fsync(handle.fileno())
        except Exception:
            try:
                output.unlink()
            except OSError:
                pass
            raise
        _fsync_directory(output.parent)
        if _sha256(output.read_bytes()) != digest:
            try:
                output.unlink()
            except OSError:
                pass
            raise NodeStoreError("exported operation snapshot failed digest read-back")
        return {
            "schema": STORE_SCHEMA,
            "state": "snapshot-exported",
            "snapshotId": snapshot_id,
            "operationId": operation_id,
            "output": output.name,
            "sha256": digest,
            "bytes": len(raw),
            "network": False,
            "writes": True,
        }

    def find_acquisition_receipt(self, operation_id: str) -> dict[str, Any] | None:
        connection = self._connect()
        try:
            row = connection.execute(
                "SELECT request_sha256, receipt_json FROM acquisition_receipts WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            if row is None:
                return None
            try:
                receipt = json.loads(bytes(row["receipt_json"]).decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise NodeStoreError("a stored acquisition receipt is unreadable") from exc
            if not isinstance(receipt, dict):
                raise NodeStoreError("a stored acquisition receipt is malformed")
            receipt["_requestSha256"] = str(row["request_sha256"])
            return receipt
        finally:
            connection.close()

    def find_acquisition_job(self, operation_id: str) -> dict[str, Any] | None:
        connection = self._connect()
        try:
            row = connection.execute(
                "SELECT operation_id, request_sha256, source_id, base_sha256, preview_sha256, state, "
                "attempt_count, started_at, completed_at, receipt_id FROM acquisition_jobs WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            if row is None:
                return None
            return {
                "schema": ACQUISITION_JOB_SCHEMA,
                "operationId": str(row["operation_id"]),
                "requestSha256": str(row["request_sha256"]),
                "sourceId": str(row["source_id"]),
                "baseLibrarySha256": str(row["base_sha256"]),
                "previewDigest": str(row["preview_sha256"]),
                "state": str(row["state"]),
                "attemptCount": int(row["attempt_count"]),
                "startedAt": str(row["started_at"]),
                "completedAt": str(row["completed_at"] or ""),
                "receiptId": str(row["receipt_id"] or ""),
            }
        except sqlite3.Error as exc:
            raise NodeStoreError(f"could not read acquisition job: {exc}") from exc
        finally:
            connection.close()

    def list_acquisition_receipts(self, limit: int = 50) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 100))
        connection = self._connect()
        try:
            rows = connection.execute(
                "SELECT receipt_json FROM acquisition_receipts ORDER BY committed_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
            result: list[dict[str, Any]] = []
            for row in rows:
                value = json.loads(bytes(row[0]).decode("utf-8"))
                if isinstance(value, dict):
                    result.append(value)
            return result
        except (sqlite3.Error, UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise NodeStoreError(f"could not read acquisition receipts: {exc}") from exc
        finally:
            connection.close()

    def list_acquisition_jobs(self, limit: int = 50) -> list[dict[str, Any]]:
        limit = max(1, min(int(limit), 100))
        connection = self._connect()
        try:
            rows = connection.execute(
                "SELECT operation_id, source_id, state, attempt_count, started_at, completed_at, receipt_id "
                "FROM acquisition_jobs ORDER BY started_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
            return [
                {
                    "schema": ACQUISITION_JOB_SCHEMA,
                    "operationId": str(row["operation_id"]),
                    "sourceId": str(row["source_id"]),
                    "state": str(row["state"]),
                    "attemptCount": int(row["attempt_count"]),
                    "startedAt": str(row["started_at"]),
                    "completedAt": str(row["completed_at"] or ""),
                    "receiptId": str(row["receipt_id"] or ""),
                }
                for row in rows
            ]
        except sqlite3.Error as exc:
            raise NodeStoreError(f"could not read acquisition jobs: {exc}") from exc
        finally:
            connection.close()

    def begin_acquisition(
        self,
        *,
        operation_id: str,
        request_sha256: str,
        source_id: str,
        base_sha256: str,
        preview_sha256: str,
        now: float | None = None,
    ) -> AcquisitionStart:
        """Persist an acquisition intent before any network request.

        An exact completed retry returns its durable receipt.  An interrupted exact
        retry increments the attempt count and may repeat the safe GET; it cannot
        silently target a different source or reviewed consequence set.
        """
        if not _OPERATION_ID.fullmatch(operation_id):
            raise NodeStoreError("Idempotency-Key must be 16–200 URL-safe characters")
        for label, value in (("request digest", request_sha256), ("base digest", base_sha256), ("preview digest", preview_sha256)):
            if not _SHA256.fullmatch(str(value)):
                raise NodeStoreError(f"invalid {label}")
        source_id = str(source_id or "")[:300]
        if not source_id:
            raise NodeStoreError("acquisition source id is required")
        started_at = _iso(now)
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            receipt_row = connection.execute(
                "SELECT request_sha256, receipt_json FROM acquisition_receipts WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            if receipt_row is not None:
                if not secrets.compare_digest(str(receipt_row["request_sha256"]), request_sha256):
                    connection.execute("ROLLBACK")
                    raise NodeStoreConflict("that Idempotency-Key was already used for a different acquisition")
                receipt = json.loads(bytes(receipt_row["receipt_json"]).decode("utf-8"))
                connection.execute("ROLLBACK")
                if not isinstance(receipt, dict):
                    raise NodeStoreError("stored acquisition receipt is malformed")
                return AcquisitionStart(receipt=receipt, replayed=True, attempt=0, resumed=False)

            job = connection.execute(
                "SELECT request_sha256, source_id, base_sha256, preview_sha256, state, attempt_count "
                "FROM acquisition_jobs WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            if job is not None:
                if not secrets.compare_digest(str(job["request_sha256"]), request_sha256):
                    connection.execute("ROLLBACK")
                    raise NodeStoreConflict("that Idempotency-Key was already used for a different acquisition")
                if str(job["source_id"]) != source_id or str(job["base_sha256"]) != base_sha256 or str(job["preview_sha256"]) != preview_sha256:
                    connection.execute("ROLLBACK")
                    raise NodeStoreConflict("that Idempotency-Key no longer matches the reviewed acquisition")
                if str(job["state"]) != "started":
                    connection.execute("ROLLBACK")
                    raise NodeStoreError("completed acquisition job has no readable receipt")
                current = connection.execute("SELECT sha256 FROM library WHERE singleton=1").fetchone()
                if current is None or not secrets.compare_digest(str(current["sha256"]), base_sha256):
                    connection.execute("ROLLBACK")
                    raise NodeStoreConflict("the Node library changed after acquisition review")
                attempt = int(job["attempt_count"]) + 1
                connection.execute(
                    "UPDATE acquisition_jobs SET attempt_count=?, started_at=? WHERE operation_id=?",
                    (attempt, started_at, operation_id),
                )
                connection.execute("COMMIT")
                return AcquisitionStart(receipt=None, replayed=False, attempt=attempt, resumed=True)

            current = connection.execute("SELECT sha256 FROM library WHERE singleton=1").fetchone()
            if current is None:
                connection.execute("ROLLBACK")
                raise NodeStoreError("the Node-owned library has no current document")
            if not secrets.compare_digest(str(current["sha256"]), base_sha256):
                connection.execute("ROLLBACK")
                raise NodeStoreConflict("the Node library changed after acquisition review")
            connection.execute(
                "INSERT INTO acquisition_jobs(operation_id, request_sha256, source_id, base_sha256, preview_sha256, state, attempt_count, started_at) "
                "VALUES (?, ?, ?, ?, ?, 'started', 1, ?)",
                (operation_id, request_sha256, source_id, base_sha256, preview_sha256, started_at),
            )
            connection.execute("COMMIT")
            return AcquisitionStart(receipt=None, replayed=False, attempt=1, resumed=False)
        except (NodeStoreConflict, NodeStoreError):
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise
        except (sqlite3.Error, UnicodeDecodeError, json.JSONDecodeError) as exc:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise NodeStoreError(f"could not begin acquisition safely: {exc}") from exc
        finally:
            connection.close()

    def commit_acquisition(
        self,
        *,
        operation_id: str,
        request_sha256: str,
        source_id: str,
        base_sha256: str,
        preview_sha256: str,
        result_document: Mapping[str, Any],
        outcome: str,
        summary: Mapping[str, Any],
        evidence: Mapping[str, Any],
        request: Mapping[str, Any],
        held_capture: Mapping[str, Any] | None = None,
        clear_capture_hold: bool = False,
        now: float | None = None,
        fail_at: str = "",
    ) -> CommitResult:
        if not _OPERATION_ID.fullmatch(operation_id):
            raise NodeStoreError("invalid acquisition operation id")
        for label, value in (("request digest", request_sha256), ("base digest", base_sha256), ("preview digest", preview_sha256)):
            if not _SHA256.fullmatch(str(value)):
                raise NodeStoreError(f"invalid {label}")
        result_copy = copy.deepcopy(dict(result_document))
        result_raw = _json_bytes(result_copy)
        _validate_backup_bytes(result_raw, "acquisition result")
        result_sha256 = _sha256(result_raw)
        committed_at = _iso(now)
        held_record: dict[str, Any] | None = None
        if held_capture is not None:
            held_record = copy.deepcopy(dict(held_capture))
            required = {
                "sourceIdentitySha256", "artifactSha256", "acceptedSnapshotSha256",
                "proposedSnapshotSha256", "proposedSnapshot", "proposedProvenance", "continuity",
            }
            if set(held_record) != required:
                raise NodeStoreError("held Capture evidence has unexpected fields")
            for label in ("sourceIdentitySha256", "artifactSha256", "acceptedSnapshotSha256", "proposedSnapshotSha256"):
                if not _SHA256.fullmatch(str(held_record.get(label) or "")):
                    raise NodeStoreError(f"held Capture evidence has an invalid {label}")
            if not isinstance(held_record.get("proposedSnapshot"), dict) or not isinstance(held_record.get("proposedProvenance"), dict) or not isinstance(held_record.get("continuity"), dict):
                raise NodeStoreError("held Capture evidence is malformed")
            if not secrets.compare_digest(
                _sha256(_canonical_bytes(held_record["proposedSnapshot"])),
                str(held_record["proposedSnapshotSha256"]),
            ):
                raise NodeStoreError("held Capture snapshot digest does not match its content")
        if fail_at == "before-begin":
            raise NodeStoreError("injected acquisition failure before commit")
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute(
                "SELECT request_sha256, receipt_json FROM acquisition_receipts WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            if existing is not None:
                if not secrets.compare_digest(str(existing["request_sha256"]), request_sha256):
                    connection.execute("ROLLBACK")
                    raise NodeStoreConflict("that Idempotency-Key was already used for a different acquisition")
                receipt = json.loads(bytes(existing["receipt_json"]).decode("utf-8"))
                connection.execute("ROLLBACK")
                if not isinstance(receipt, dict):
                    raise NodeStoreError("stored acquisition receipt is malformed")
                return CommitResult(receipt=receipt, replayed=True)

            job = connection.execute(
                "SELECT request_sha256, source_id, base_sha256, preview_sha256, state, attempt_count, started_at "
                "FROM acquisition_jobs WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            if job is None or str(job["state"]) != "started":
                connection.execute("ROLLBACK")
                raise NodeStoreConflict("acquisition must begin from its reviewed intent before commit")
            if not secrets.compare_digest(str(job["request_sha256"]), request_sha256):
                connection.execute("ROLLBACK")
                raise NodeStoreConflict("acquisition request no longer matches its durable intent")
            if str(job["source_id"]) != source_id or str(job["base_sha256"]) != base_sha256 or str(job["preview_sha256"]) != preview_sha256:
                connection.execute("ROLLBACK")
                raise NodeStoreConflict("acquisition no longer matches the reviewed source or preview")
            current = connection.execute("SELECT sha256, revision FROM library WHERE singleton=1").fetchone()
            if current is None:
                connection.execute("ROLLBACK")
                raise NodeStoreError("the Node-owned library has no current document")
            if not secrets.compare_digest(str(current["sha256"]), base_sha256):
                connection.execute("ROLLBACK")
                raise NodeStoreConflict("the Node library changed after acquisition review")
            next_revision = int(current["revision"]) + 1
            connection.execute(
                "UPDATE library SET document_json=?, sha256=?, revision=?, updated_at=? WHERE singleton=1",
                (sqlite3.Binary(result_raw), result_sha256, next_revision, committed_at),
            )
            if fail_at == "after-library":
                raise NodeStoreError("injected acquisition failure after library write")

            receipt_core = {
                "schema": ACQUISITION_RECEIPT_SCHEMA,
                "operationId": operation_id,
                "sourceId": source_id,
                "committedAt": committed_at,
                "baseLibrarySha256": base_sha256,
                "previewDigest": preview_sha256,
                "resultLibrarySha256": result_sha256,
                "resultRevision": next_revision,
                "outcome": str(outcome or "unknown")[:80],
                "attemptCount": int(job["attempt_count"]),
                "startedAt": str(job["started_at"]),
                "summary": copy.deepcopy(dict(summary)),
                "evidence": copy.deepcopy(dict(evidence)),
                "request": copy.deepcopy(dict(request)),
                "effects": {
                    "networkRequests": max(0, min(6, int(request.get("networkRequests", 1) or 0))),
                    "browserCookiesSent": False,
                    "browserCredentialsSent": False,
                    "browserProfileRead": False,
                    "arbitraryScriptExecuted": False,
                    "automaticScheduleCreated": False,
                },
            }
            receipt_id = hashlib.sha256(b"ProgRSS/acquisition-receipt/v1\0" + _canonical_bytes(receipt_core)).hexdigest()
            receipt = {**receipt_core, "receiptId": f"sha256:{receipt_id}"}
            receipt_raw = _json_bytes(receipt)
            connection.execute(
                "INSERT INTO acquisition_receipts(operation_id, source_id, request_sha256, base_sha256, result_sha256, outcome, committed_at, receipt_json) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (operation_id, source_id, request_sha256, base_sha256, result_sha256, receipt_core["outcome"], committed_at, sqlite3.Binary(receipt_raw)),
            )
            connection.execute(
                "UPDATE acquisition_jobs SET state='completed', completed_at=?, receipt_id=? WHERE operation_id=?",
                (committed_at, receipt["receiptId"], operation_id),
            )
            if held_record is not None:
                # Move the previous unresolved current hold into bounded local history
                # before replacing it. The current hold remains separately addressable
                # for Anchor; Bearing receives at most eight prior unresolved holds.
                connection.execute(
                    "INSERT OR IGNORE INTO capture_hold_history(capture_operation_id, source_id, capture_receipt_id, held_at, held_library_sha256, "
                    "source_identity_sha256, artifact_sha256, accepted_snapshot_sha256, proposed_snapshot_sha256, proposed_snapshot_json, "
                    "proposed_provenance_json, continuity_json) "
                    "SELECT capture_operation_id, source_id, capture_receipt_id, held_at, held_library_sha256, source_identity_sha256, "
                    "artifact_sha256, accepted_snapshot_sha256, proposed_snapshot_sha256, proposed_snapshot_json, proposed_provenance_json, "
                    "continuity_json FROM capture_holds WHERE source_id=?",
                    (source_id,),
                )
                connection.execute(
                    "DELETE FROM capture_hold_history WHERE source_id=? AND capture_operation_id NOT IN ("
                    "SELECT capture_operation_id FROM capture_hold_history WHERE source_id=? "
                    "ORDER BY held_at DESC, capture_operation_id DESC LIMIT ?)",
                    (source_id, source_id, MAX_CAPTURE_HOLD_HISTORY),
                )
                connection.execute(
                    "INSERT INTO capture_holds(source_id, capture_operation_id, capture_receipt_id, held_at, held_library_sha256, "
                    "source_identity_sha256, artifact_sha256, accepted_snapshot_sha256, proposed_snapshot_sha256, "
                    "proposed_snapshot_json, proposed_provenance_json, continuity_json) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) "
                    "ON CONFLICT(source_id) DO UPDATE SET capture_operation_id=excluded.capture_operation_id, "
                    "capture_receipt_id=excluded.capture_receipt_id, held_at=excluded.held_at, held_library_sha256=excluded.held_library_sha256, "
                    "source_identity_sha256=excluded.source_identity_sha256, artifact_sha256=excluded.artifact_sha256, "
                    "accepted_snapshot_sha256=excluded.accepted_snapshot_sha256, proposed_snapshot_sha256=excluded.proposed_snapshot_sha256, "
                    "proposed_snapshot_json=excluded.proposed_snapshot_json, proposed_provenance_json=excluded.proposed_provenance_json, "
                    "continuity_json=excluded.continuity_json",
                    (
                        source_id, operation_id, receipt["receiptId"], committed_at, result_sha256,
                        held_record["sourceIdentitySha256"], held_record["artifactSha256"], held_record["acceptedSnapshotSha256"],
                        held_record["proposedSnapshotSha256"], sqlite3.Binary(_canonical_bytes(held_record["proposedSnapshot"])),
                        sqlite3.Binary(_canonical_bytes(held_record["proposedProvenance"])),
                        sqlite3.Binary(_canonical_bytes(held_record["continuity"])),
                    ),
                )
            elif clear_capture_hold:
                connection.execute("DELETE FROM capture_holds WHERE source_id=?", (source_id,))
                connection.execute("DELETE FROM capture_hold_history WHERE source_id=?", (source_id,))
            if fail_at == "after-receipt":
                raise NodeStoreError("injected acquisition failure after receipt")
            connection.execute("COMMIT")
            return CommitResult(receipt=receipt, replayed=False)
        except (NodeStoreConflict, NodeStoreError):
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise
        except (sqlite3.Error, UnicodeDecodeError, json.JSONDecodeError) as exc:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise NodeStoreError(f"acquisition could not commit atomically: {exc}") from exc
        finally:
            connection.close()

    def commit_baseline_replacement(
        self,
        *,
        operation_id: str,
        actor: str,
        request_sha256: str,
        base_sha256: str,
        preview_sha256: str,
        source_id: str,
        held_operation_id: str,
        held_receipt_id: str,
        result_document: Mapping[str, Any],
        summary: Mapping[str, Any],
        evidence: Mapping[str, Any],
        selection: Mapping[str, Any],
        now: float | None = None,
        fail_at: str = "",
    ) -> CommitResult:
        """Atomically accept one held rendered observation as the new baseline."""
        if not _OPERATION_ID.fullmatch(operation_id):
            raise NodeStoreError("Idempotency-Key must be 16–200 URL-safe characters")
        for label, value in (("request digest", request_sha256), ("base digest", base_sha256), ("preview digest", preview_sha256)):
            if not _SHA256.fullmatch(str(value)):
                raise NodeStoreError(f"invalid {label}")
        result_copy = copy.deepcopy(dict(result_document))
        result_raw = _json_bytes(result_copy)
        _validate_backup_bytes(result_raw, "baseline replacement result")
        result_sha256 = _sha256(result_raw)
        committed_at = _iso(now)
        if fail_at == "before-begin":
            raise NodeStoreError("injected baseline replacement failure before transaction")
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute(
                "SELECT request_sha256, receipt_json FROM operation_receipts WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            if existing is not None:
                if not secrets.compare_digest(str(existing["request_sha256"]), request_sha256):
                    connection.execute("ROLLBACK")
                    raise NodeStoreConflict("that Idempotency-Key was already used for different reviewed content")
                receipt = json.loads(bytes(existing["receipt_json"]).decode("utf-8"))
                connection.execute("ROLLBACK")
                if not isinstance(receipt, dict):
                    raise NodeStoreError("stored operation receipt is malformed")
                return CommitResult(receipt=receipt, replayed=True)
            current = connection.execute(
                "SELECT document_json, sha256, revision FROM library WHERE singleton=1"
            ).fetchone()
            if current is None:
                connection.execute("ROLLBACK")
                raise NodeStoreError("the Node-owned library has no current document")
            current_sha256 = str(current["sha256"])
            if not secrets.compare_digest(current_sha256, base_sha256):
                connection.execute("ROLLBACK")
                raise NodeStoreConflict("the Node library changed after review; review the held baseline again")
            hold = connection.execute(
                "SELECT capture_operation_id, capture_receipt_id FROM capture_holds WHERE source_id=?",
                (source_id,),
            ).fetchone()
            if hold is None:
                connection.execute("ROLLBACK")
                raise NodeStoreConflict("the held rendered observation is no longer available")
            if str(hold["capture_operation_id"]) != held_operation_id or str(hold["capture_receipt_id"]) != held_receipt_id:
                connection.execute("ROLLBACK")
                raise NodeStoreConflict("the held rendered observation changed after review")
            prior_raw = bytes(current["document_json"])
            if _sha256(prior_raw) != current_sha256:
                connection.execute("ROLLBACK")
                raise NodeStoreError("the current Node library failed its stored digest check")
            snapshot_id = hashlib.sha256(
                f"ProgRSS/snapshot/v1\0{operation_id}\0{base_sha256}".encode("utf-8")
            ).hexdigest()[:32]
            connection.execute(
                "INSERT INTO operation_snapshots(snapshot_id, operation_id, created_at, library_sha256, document_json) VALUES (?, ?, ?, ?, ?)",
                (snapshot_id, operation_id, committed_at, base_sha256, sqlite3.Binary(prior_raw)),
            )
            if fail_at == "after-snapshot":
                raise NodeStoreError("injected baseline replacement failure after snapshot")
            next_revision = int(current["revision"]) + 1
            connection.execute(
                "UPDATE library SET document_json=?, sha256=?, revision=?, updated_at=? WHERE singleton=1",
                (sqlite3.Binary(result_raw), result_sha256, next_revision, committed_at),
            )
            if fail_at == "after-library":
                raise NodeStoreError("injected baseline replacement failure after library write")
            receipt_core = {
                "schema": OPERATION_RECEIPT_SCHEMA,
                "operationId": operation_id,
                "operationType": BASELINE_REPLACEMENT_OPERATION,
                "actor": actor,
                "committedAt": committed_at,
                "baseLibrarySha256": base_sha256,
                "previewDigest": preview_sha256,
                "resultLibrarySha256": result_sha256,
                "resultRevision": next_revision,
                "summary": copy.deepcopy(dict(summary)),
                "selection": copy.deepcopy(dict(selection)),
                "evidence": copy.deepcopy(dict(evidence)),
                "effects": {
                    "networkRequests": 0,
                    "watchedSiteContacted": False,
                    "historicalChangeAlertsCreated": 0,
                    "acceptedBaselineReplaced": True,
                    "earlierLibrarySnapshotRetained": True,
                    "automaticScheduleCreated": False,
                    "browserAuthorityImported": False,
                },
                "rollbackEvidence": {
                    "snapshotId": snapshot_id,
                    "librarySha256": base_sha256,
                    "automaticRollback": False,
                },
            }
            receipt_id = hashlib.sha256(b"ProgRSS/operation-receipt/v1\0" + _canonical_bytes(receipt_core)).hexdigest()
            receipt = {**receipt_core, "receiptId": f"sha256:{receipt_id}"}
            connection.execute(
                "INSERT INTO operation_receipts(operation_id, operation_type, actor, request_sha256, base_sha256, preview_sha256, result_sha256, committed_at, receipt_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (operation_id, BASELINE_REPLACEMENT_OPERATION, actor, request_sha256, base_sha256, preview_sha256, result_sha256, committed_at, sqlite3.Binary(_json_bytes(receipt))),
            )
            connection.execute("DELETE FROM capture_holds WHERE source_id=?", (source_id,))
            connection.execute("DELETE FROM capture_hold_history WHERE source_id=?", (source_id,))
            if fail_at == "after-receipt":
                raise NodeStoreError("injected baseline replacement failure after receipt")
            connection.execute("COMMIT")
            return CommitResult(receipt=receipt, replayed=False)
        except (NodeStoreConflict, NodeStoreError):
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise
        except (sqlite3.Error, UnicodeDecodeError, json.JSONDecodeError) as exc:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise NodeStoreError(f"baseline replacement could not commit atomically: {exc}") from exc
        finally:
            connection.close()

    def commit_operation(
        self,
        *,
        operation_id: str,
        operation_type: str,
        actor: str,
        request_sha256: str,
        base_sha256: str,
        preview_sha256: str,
        result_document: Mapping[str, Any],
        summary: Mapping[str, Any],
        source_list_sha256: str,
        selected_folder: Mapping[str, Any],
        now: float | None = None,
        fail_at: str = "",
    ) -> CommitResult:
        """Atomically replace the canonical document and append evidence.

        ``fail_at`` exists solely for deterministic crash/rollback tests. Public
        callers do not expose it.
        """
        if not _OPERATION_ID.fullmatch(operation_id):
            raise NodeStoreError("Idempotency-Key must be 16–200 URL-safe characters")
        for label, value in (
            ("request digest", request_sha256),
            ("base digest", base_sha256),
            ("preview digest", preview_sha256),
            ("source-list digest", source_list_sha256),
        ):
            if not _SHA256.fullmatch(str(value)):
                raise NodeStoreError(f"invalid {label}")
        if operation_type != "adopt-source-list-branch":
            raise NodeStoreError("unsupported Node operation type")
        result_copy = copy.deepcopy(dict(result_document))
        result_raw = _json_bytes(result_copy)
        _validate_backup_bytes(result_raw, "operation result")
        result_sha256 = _sha256(result_raw)
        committed_at = _iso(now)
        if fail_at == "before-begin":
            raise NodeStoreError("injected failure before transaction")

        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute(
                "SELECT request_sha256, receipt_json FROM operation_receipts WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            if existing is not None:
                if not secrets.compare_digest(str(existing["request_sha256"]), request_sha256):
                    connection.execute("ROLLBACK")
                    raise NodeStoreConflict("that Idempotency-Key was already used for different reviewed content")
                receipt = json.loads(bytes(existing["receipt_json"]).decode("utf-8"))
                connection.execute("ROLLBACK")
                if not isinstance(receipt, dict):
                    raise NodeStoreError("stored operation receipt is malformed")
                return CommitResult(receipt=receipt, replayed=True)

            current = connection.execute(
                "SELECT document_json, sha256, revision FROM library WHERE singleton=1"
            ).fetchone()
            if current is None:
                connection.execute("ROLLBACK")
                raise NodeStoreError("the Node-owned library has no current document")
            current_sha256 = str(current["sha256"])
            if not secrets.compare_digest(current_sha256, base_sha256):
                connection.execute("ROLLBACK")
                raise NodeStoreConflict("the Node library changed after review; review the branch again")
            prior_raw = bytes(current["document_json"])
            if _sha256(prior_raw) != current_sha256:
                connection.execute("ROLLBACK")
                raise NodeStoreError("the current Node library failed its stored digest check")

            snapshot_id = hashlib.sha256(
                f"ProgRSS/snapshot/v1\0{operation_id}\0{base_sha256}".encode("utf-8")
            ).hexdigest()[:32]
            connection.execute(
                "INSERT INTO operation_snapshots(snapshot_id, operation_id, created_at, library_sha256, document_json) VALUES (?, ?, ?, ?, ?)",
                (snapshot_id, operation_id, committed_at, base_sha256, sqlite3.Binary(prior_raw)),
            )
            if fail_at == "after-snapshot":
                raise NodeStoreError("injected failure after snapshot")

            next_revision = int(current["revision"]) + 1
            connection.execute(
                "UPDATE library SET document_json=?, sha256=?, revision=?, updated_at=? WHERE singleton=1",
                (sqlite3.Binary(result_raw), result_sha256, next_revision, committed_at),
            )
            if fail_at == "after-library":
                raise NodeStoreError("injected failure after library write")

            receipt_core = {
                "schema": OPERATION_RECEIPT_SCHEMA,
                "operationId": operation_id,
                "operationType": operation_type,
                "actor": actor,
                "committedAt": committed_at,
                "baseLibrarySha256": base_sha256,
                "previewDigest": preview_sha256,
                "sourceListSha256": source_list_sha256,
                "resultLibrarySha256": result_sha256,
                "resultRevision": next_revision,
                "summary": copy.deepcopy(dict(summary)),
                "selection": copy.deepcopy(dict(selected_folder)),
                "effects": {
                    "newSourcesPaused": True,
                    "networkRequests": 0,
                    "listedSitesContacted": False,
                    "readingStateImported": False,
                    "browserAuthorityImported": False,
                },
                "rollbackEvidence": {
                    "snapshotId": snapshot_id,
                    "librarySha256": base_sha256,
                    "automaticRollback": False,
                },
            }
            receipt_id = hashlib.sha256(
                b"ProgRSS/operation-receipt/v1\0" + _canonical_bytes(receipt_core)
            ).hexdigest()
            receipt = {**receipt_core, "receiptId": f"sha256:{receipt_id}"}
            receipt_raw = _json_bytes(receipt)
            connection.execute(
                "INSERT INTO operation_receipts(operation_id, operation_type, actor, request_sha256, base_sha256, preview_sha256, result_sha256, committed_at, receipt_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    operation_id,
                    operation_type,
                    actor,
                    request_sha256,
                    base_sha256,
                    preview_sha256,
                    result_sha256,
                    committed_at,
                    sqlite3.Binary(receipt_raw),
                ),
            )
            if fail_at == "after-receipt":
                raise NodeStoreError("injected failure after receipt")
            connection.execute("COMMIT")
            return CommitResult(receipt=receipt, replayed=False)
        except NodeStoreConflict:
            raise
        except NodeStoreError:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise
        except (sqlite3.Error, UnicodeDecodeError, json.JSONDecodeError) as exc:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise NodeStoreError(f"Node operation could not commit atomically: {exc}") from exc
        finally:
            connection.close()


__all__ = [
    "ACQUISITION_JOB_SCHEMA",
    "ACQUISITION_RECEIPT_SCHEMA",
    "ACQUISITION_RESULT_SCHEMA",
    "AcquisitionStart",
    "BACKUP_SCHEMA",
    "BASELINE_REPLACEMENT_OPERATION",
    "CAPTURE_HOLD_SCHEMA",
    "CommitResult",
    "LibraryRecord",
    "MAX_BACKUP_BYTES",
    "NodeStore",
    "NodeStoreConflict",
    "NodeStoreError",
    "OPERATION_RECEIPT_SCHEMA",
    "OPERATION_RESULT_SCHEMA",
    "OPERATION_SCHEMA",
    "STORE_SCHEMA",
    "is_node_store",
]
