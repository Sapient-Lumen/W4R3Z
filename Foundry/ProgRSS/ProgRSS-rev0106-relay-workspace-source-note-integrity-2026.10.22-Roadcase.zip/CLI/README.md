# ProgRSS CLI / Node 0.80.0 — Roadcase

Roadcase adds a deterministic self-verifying native-fieldwork packet around the exact CLI, Node, Chromium, Firefox, synthetic fixtures, Fieldbook, Debrief, and cleanup boundary. It performs no network request while building or verifying the packet and does not claim that native or human sessions occurred.

The current candidate unifies two delivered Source Notes lines on the rev0100 whole-product tree. Private-library transfer now validates every direct placement reason before preview, restore, copy checking, recovery export, or ordinary export; valid two-folder reasons round-trip exactly and malformed values fail before mutation. Exchange sender and recipient reviews now disclose the exact curator-reason count and render each reason beside its direct folder route before one of the three recipient choices is used. The existing branch-operation preview retains its own route-bound disclosure. Values are literal multiline, direction-aware text and are identified as curator context rather than ProgRSS safety claims. No listed source is contacted by these review paths, and the existing authority, atomic-write, paused-new-source, rollback, and permission boundaries are unchanged.
The current candidate also closes the Node private-library Source Notes validation gap. `progrss node init` and read-only `progrss node serve BACKUP.json` now use the same fail-closed direct-placement audit as ordinary private transfer. Valid reasons for one source in different folders remain byte-exact; malformed reason placement is refused before SQLite creation, serving, operation commit, snapshot use, or export.
The current candidate also closes the Relay workspace loader gap. `workspace share-folder`, `publish-folder`, `import-bundle`, `review-bundle`, `check-publication`, and `update-bundle` now invoke that same audit before using private state. Valid route-specific reasons remain exact; malformed state is refused before output, and explicit publication checking is refused before any network request.

Dispatch adds a private sender-side Fieldbook for the exact Exchange preview
that appears before an expiring recipient handoff is created. The facilitator
can observe whether an unfamiliar sender understands what will be included,
what stays private, which recipient choices are available, what a public
address or static package does, and what expiry or revocation can and cannot
do.

From the authenticated Node, prepare one share and expand **Research this
sender review**. Offline generation from a captured strict
`progrss.node.exchange-preview.v1` document is also available:

```sh
./progrss node exchange-sender-fieldbook exchange-preview.json \
  --output ProgRSS-Exchange-Sender-Fieldbook.html
```

The Fieldbook omits route and curator identity, source identity, folder paths,
public addresses, library identity, artifact digests, and the preview
capability. It makes no network request, performs no Node-library or store
write, requests no participant identity, uses no telemetry, and saves nothing
automatically.

The existing Crossroads recipient Fieldbook remains separate. Debrief refuses
mixed scenario digests, releases, and task sequences, so sender reports cannot
be blended with recipient or Trace/Bearing/Anchor reports.

Detailed contract: `docs/NODE-DISPATCH.md`.  
Facilitator protocol: `docs/NODE-DISPATCH-ACCEPTANCE.md`.

---

# ProgRSS CLI / Node 0.77.0 — Debrief

**Find patterns. Do not score people.**

Debrief is the private, local-only analysis companion to Fieldbook. It compares
several compatible `progrss.fieldwork-report.v1` files, counts the four observed
outcomes for each task, and surfaces bounded review signals such as **Recurring
wrong turn to review**, **Prompt-dependent understanding to review**, and
**Coverage gap**.

It does not assign participant scores, rank people, claim that the product
passed, or convert a single report into a general finding. Raw facilitator
notes remain visible only inside the local workspace and are excluded from the
exported `progrss.fieldwork-debrief.v1` JSON or Markdown finding report.

Create a blank browser-local workspace from the authenticated Node GUI under
**Research and acceptance**, or preload compatible reports offline:

```sh
./progrss node debrief \
  session-01.json session-02.json session-03.json \
  --output ProgRSS-Debrief.html
```

The workspace strictly validates report schemas, ignores exact duplicate
reports, refuses mixed scenarios, requires one reviewed disposition per task,
and requires a separate privacy review before export. It requests no
participant identity, makes no network request, uses no browser storage, saves
nothing automatically, and performs no Node-library write.

Fieldbook remains available through `progrss node fieldbook`. Fieldbook records
one session; Debrief compares several completed reports. Neither tool changes
Bearing, Trace, Anchor, Capture, Pulse, pairing, or sharing authority.

Detailed contract: `docs/NODE-DEBRIEF.md`.  
Facilitator protocol: `docs/NODE-DEBRIEF-ACCEPTANCE.md`.
---

# ProgRSS CLI / Node 0.75.0 — Trace

**Show the observations, not just the diagnosis.**

Trace extends Bearing's read-only review with an oldest-to-newest `progrss.node.bearing-trace.v1` trail and a bounded `progrss.node.recipe-footprint.v1` explanation. It changes no library data, contacts no site, and leaves Anchor and fresh Capture as separate decisions.

Detailed contract: `docs/NODE-TRACE.md`.

---

# ProgRSS CLI / Node 0.74.0 — Bearing

**Explain the drift before proposing the repair.**

Bearing adds a read-only Node review for repeated Drift-held browser observations. The Node keeps one current hold plus at most eight prior unresolved observations for the same watched page, then explains one bounded pattern: **Moving rendered window**, **Page boundary shifted**, or **Not enough evidence yet**.

The review makes zero watched-site requests and performs no library write. It offers three separate routes: keep the accepted baseline, open the existing Anchor review, or begin a fresh browser-assisted Capture. It never silently rewrites a selector, replaces a baseline, creates a schedule, or grants paired-Extension write authority.

Detailed contract: `docs/NODE-BEARING.md`.
Human protocol: `docs/NODE-BEARING-ACCEPTANCE.md`.

---

# ProgRSS CLI / Node 0.73.0 — Anchor

Anchor adds one reviewed local Node operation for replacing a held partial rendered-page baseline. The accepted and proposed windows are compared before a write; the earlier complete library is retained as a recovery snapshot; no watched site is contacted and no historical change alert is invented. The typed operation is local-administrator-only, stale-base checked, exactly replayable, and not exposed through summary-only Extension pairing.

Detailed contract: `docs/NODE-ANCHOR.md`.

Drift adds Node-computed continuity evidence for browser-assisted watched pages whose reviewed context reports partial rendering. Before ordinary page-watch comparison, the Node compares the accepted baseline with the new rendered window.

When a partial rendering loses most stable record overlap—or when the partial-render boundary itself changes—the Node records `progrss.capture-continuity.v1`, keeps the earlier baseline, adds no mass add/remove item, and returns **Rendered window held**. A later observation with sufficient overlap may proceed through the existing page-watch comparison.

This changes no authority. Capture remains one exact reviewed active page, bounded text-and-link evidence, zero Node watched-site requests, no browser credentials, and no schedule. The browser still decides what to send; the Node decides conservatively whether two partial renderings are comparable.

Detailed contract: `docs/NODE-DRIFT.md`.

---

# ProgRSS CLI / Node 0.70.0 — Perimeter

**Show the edges before saving the center.**

Perimeter extends browser-assisted Capture with strict page-coverage evidence. A selected region can look structurally stable while the browser view is incomplete because the page continues, virtualizes records, is obscured by a modal, remains busy, embeds content in a frame, or uses shadow DOM. The Node now validates and receipts those boundaries separately from section stability.

New artifacts use:

```text
progrss.browser-capture.v3
progrss.capture-page-context.v1
perimeter-v1
```

The context contains at most six fixed notice kinds plus bounded integer signals. Notices and signals must agree exactly. The Node refuses unknown fields, duplicate kinds, unsupported tones, inconsistent counts, stale or mismatched artifacts, and unacknowledged recipe changes. It continues to read v2 and v1 during a rolling local upgrade without inventing missing evidence.

Perimeter changes no authority: the Node still receives bounded rendered text and links rather than browser credentials, makes zero watched-site requests for Capture, and creates no schedule. Pulse still requires successful Node-side Witness evidence.

Detailed contracts:

```text
docs/NODE-CAPTURE.md
docs/NODE-PERIMETER.md
docs/NODE-CONTOUR.md
docs/NODE-CAPTURE-ACCEPTANCE.md
```

---

# Previous release documentation: ProgRSS CLI / Node 0.69.0 — Contour

**A selector says where. Evidence says why it may hold.**

Contour advances the browser-assisted path for sites whose useful content must be observed in a deliberately opened browser session. New `progrss.browser-capture.v2` artifacts preserve one strict, bounded section assessment alongside the existing text-and-link evidence.

The Node validates and receipts:

```text
selected candidate ID
steadier / watchful / fragile label
bounded explanation
bounded reasons and warnings
semantic, uniqueness, visibility, repetition, link, title,
shape-consistency, clutter, and text-size signals
extractor revision and rendered text direction
```

The assessment is evidence from one rendering—not acquisition identity, probability, or a promise. It does not grant scheduler eligibility. Pulse still requires a successful Node-side Witness receipt for the exact current source identity.

The Node refuses unknown assessment fields, unsupported labels, inconsistent counts, oversized artifacts, stale captures, source mismatch, and unacknowledged recipe change. Legacy v1 captures remain accepted for rolling upgrades without synthetic assessment data.

Use the existing Capture flow:

```text
Node Sources → Use signed-in browser
Extension Add → Review browser request
Capture this open page
Review matched, ignored, why-it-may-hold, and what-could-break evidence
Send one reviewed capture
```

Detailed contracts:

```text
docs/NODE-CAPTURE.md
docs/NODE-CONTOUR.md
docs/NODE-CAPTURE-ACCEPTANCE.md
```

## Next boundary

Run native and unfamiliar-human acceptance, then improve page-watch proposals for pagination, virtualized lists, localization, consent overlays, and direct point-to-region selection. Do not convert browser-assisted evidence into unattended scheduling or arbitrary shared JavaScript.

---

# Previous release documentation: ProgRSS CLI / Node 0.68.0 — Pulse

**One clock. One fetcher. One receipt.**

Pulse makes the recovered Cadence timing layer executable and connects it directly to the packaged Witness acquisition path. A recurring timing plan no longer requires a separate runner merely to perform a normal ProgRSS check.

The ordinary sequence is:

```text
Check one public source manually through Witness
  ↓
Review its local timing plan offline
  ↓
Acknowledge and create the plan
  ↓
Start the foreground Pulse session
  ↓
The existing Witness path performs due checks
  ↓
One acquisition receipt remains the source of truth
```

Create a Node-owned library, complete one successful manual Witness check, and export its receipt. Then:

```sh
./progrss cadence init pulse.sqlite3 \
  --store reading-room.sqlite3

./progrss cadence review \
  pulse.sqlite3 witness-receipt.json \
  --every 6h

./progrss cadence create \
  pulse.sqlite3 witness-receipt.json \
  --every 6h \
  --acknowledge

./progrss cadence serve pulse.sqlite3 --open
```

The timing database is bound to one exact Node-store identity. A plan is eligible only when a durable, successful, Node-reproducible Witness receipt matches the source's current address and declarative page-watch recipe. Browser-assisted Capture receipts, zero-request receipts, paused sources, stale recipes, and unsuccessful checks are refused.

Pulse reuses `NodeState.create_acquisition_preview()` and `NodeState.run_acquisition()`. Destination validation, redirects, HTTP validators, response limits, feed parsing, page-watch comparison, library mutation, and acquisition receipts remain in one implementation. An advanced argv-only runner remains available for deliberate custom deployments, but it is no longer the default product path.

Timing plans remain Node-local. They are not copied through private backups, source lists, OPML, Exchange, pairing, or branch adoption. Creating a plan performs no DNS lookup or HTTP request and does not start the scheduler. The foreground session starts stopped; closing it stops automatic dispatch. Pause produces no Pulse dispatch.

Pulse persists due-slot identity before acquisition. If the Node commits the Witness receipt and the Pulse response is lost, retrying after restart reuses the same Witness operation identity and returns the durable receipt rather than contacting the site twice. Completed timing slots likewise replay their stored result.

`Retry-After` now accepts bounded delta-seconds and HTTP dates. Temporary failures use bounded exponential backoff. A persistent per-site courtesy window prevents two due plans from immediately contacting the same host. Blocking outcomes pause the affected plan for review.

The complete contract and native/human protocol are in:

```text
docs/NODE-CADENCE.md
docs/CADENCE-ACCEPTANCE.md
docs/NODE-ACQUISITION.md
```

The Extension remains the independent everyday reader. Its Node pairing is still summary-only; it cannot create plans, start Pulse, trigger checks, read receipts, or acquire write authority.

## Next boundary

Run Pulse on unmanaged Chromium, current Firefox and Firefox ESR, then observe unfamiliar people explaining **Active**, **Scheduled**, **Running**, **Paused**, and **Next check**. The next code increment should improve page-watch quality and organization before remote scheduling, a permanent daemon, or continuous synchronization.
---

# Previous release documentation: ProgRSS CLI / Node 0.64.0 — Receipt

**Review once. Commit once. Replay safely.**

Receipt introduced the Node-owned transactional library and one narrow local-administrator write: adopt one already reviewed source-list branch. The operation is stale-base guarded, exact-preview bound, idempotent, atomic, receipted, and backed by a complete pre-operation portable snapshot. Exact existing recipes are reused, newly created sources begin paused, and no listed site is contacted during review or commit.

The shipped Node review shows the selected branch's direct folder placements and every optional curator reason before commit. Each reason stays attached to its exact folder/source relationship, is rendered as literal user-authored text with preserved line breaks and automatic text direction, and is labeled as curator context rather than a ProgRSS safety claim.

The paired Extension remains summary-only. SQLite remains a local transaction mechanism; `progrss.private.v1` JSON remains the portable library format. Generic JSON Patch, arbitrary filesystem writes, continuous synchronization, and remote mutation remain unavailable.

---

# Previous release documentation: ProgRSS CLI / Node 0.63.0 — Confluence

**Compare three copies. Ask only where they truly disagree.**

Confluence makes later-copy review explicit. The CLI and loopback Node compare the last accepted curator baseline, the recipient's current local copy, and one incoming native source list. The result separates curator-only changes, recipient-only changes, matching edits, true conflicts, additions, removals, and acquisition-recipe changes.

```sh
./progrss workspace review-bundle \
  private-backup.json later-source-list.json
```

The review is offline and read-only. It contacts no listed source, mutates no input, and makes no choice for a true conflict. Acquisition-recipe changes are shown separately because changing a feed URL or page-watch selector changes future network behavior, not merely wording.

The Node exposes the same comparison through **Curate → Compare a later copy**. That endpoint remains administrator-only, same-origin, loopback-only, and review-only. It has no apply route.

Applying through the CLI remains a separate new-file-only operation:

```sh
./progrss workspace update-bundle \
  private-backup.json later-source-list.json \
  --resolve-conflicts keep-local \
  --accept-recipe-changes \
  --output reviewed-result.json
```

The original backup remains the rollback copy. New or changed acquisition recipes start paused, removed sources keep their local history, recipient-only wording stays local, and signer discontinuities still require the existing separate trust acknowledgement.

The complete review and endpoint contract is documented in `docs/NODE-MERGE-REVIEW.md`. Exchange and summary-only pairing remain available and unchanged.

## Next boundary

The Node still does not own or write a live library. The next writable increment must be one narrowly typed, idempotent operation with a reviewed base digest, exact preview digest, short expiry, atomic commit, durable receipt, safe replay, and stale-base refusal. A generic writable REST surface and continuous synchronization remain out of scope.

---

# Previous release documentation: ProgRSS CLI / Node 0.62.0 — Exchange

**One handoff. Three honest choices.**

Exchange turns the loopback Node into a read-only sender for one reviewed source route. It keeps the rev0061 summary-only Extension pairing intact and adds a separate, expiring artifact handoff. Pairing never becomes sharing authority, and sharing never becomes synchronization.

```sh
./progrss node serve fixtures/sample-backup.json --open
```

Open **Curate**, choose one existing simple folder, add optional curator wording, and review the exact output. The Node can prepare:

```text
a native ProgRSS source list
a matching recent-updates JSON Feed when requested
a script-free static publication package when a public source-list URL is supplied
```

Preparation reads the explicitly selected backup, performs no network request, and leaves the file byte-identical. A ten-minute preview is committed into a thirty-minute handoff only after the reviewed library digest and preview digest still match.

## One recipient handoff, three consequences

The invitation is carried after `#exchange=` in an exact literal `http://127.0.0.1:PORT/` URL. The first ProgRSS Extension Origin that reviews it owns that invitation until expiry or revocation. The Extension then presents only the choices the prepared artifacts can honestly support:

```text
Follow updates
  Preview and follow one ordinary public recent-updates feed.
  This does not add the underlying sources or folders.

Add the complete route
  Review the checked native source list, then adopt its full route.
  New sources begin paused and exact existing sources are reused.

Take one branch
  Review one populated nested folder section as an independent local excerpt.
  It does not claim future-copy continuity with the parent publication.
```

A loopback-only recent-updates artifact is useful for review, but it is not a durable subscription. **Follow updates** is therefore available only when the sender supplies the public source-list URL from which the publication page and feed URL can be derived. Copying a private invitation does not silently publish the Node or create a permanent feed.

## Sender review and private-state exclusions

Before creating the handoff, the Node shows source and folder counts, bounded source names and hostnames, available branches, artifact media types, byte sizes and SHA-256 digests, and the exact private state excluded from sharing:

```text
read and unread state
saved state
full retained article text
page-watch snapshots and comparison evidence
browser permissions and cookies
private signing keys
```

The handoff grants access only to the prepared immutable artifacts. It does not expose `/api/v1/library`, the master Node capability, arbitrary files, source fetching, writes, merge operations, Node-to-Node control, or WebRTC.

## Web Share is enhancement, not protocol

When a public publication page exists and the browser exposes a usable Web Share API, the Node UI can invoke the operating-system share sheet from the visible action. Copy remains the universal fallback. Web Share availability, share targets, and policy vary by browser and context; Exchange never treats it as delivery confirmation or as a replacement for the artifact protocol.

## Pairing remains separate

The existing **Create pairing invitation** control remains under a secondary disclosure. Pairing exposes only the running Node session marker, selected-library digest, bounded counts, and explicit capability refusals. An Exchange handoff can be used without pairing, and pairing does not make any route shareable.

The complete endpoint and capability contract is documented in `docs/NODE-EXCHANGE.md`. The earlier read-only pairing contract remains in `docs/NODE-PAIRING.md`.

## Next boundary

The next coherent work is a visible three-way later-copy merge review and, in parallel, a one-writer operation contract with a reviewed base digest, exact preview digest, idempotency key, short expiry, atomic commit, and durable receipt. Exchange does not ship a generic writable REST API or continuous synchronization.

---

# Previous release documentation: ProgRSS CLI 0.58.0 — Branch

The ProgRSS CLI is a Python 3.11+ standard-library tool for explicit feeds, page-watch history, portable source lists, deployed publication audits, and private Extension backups. **Branch** can adopt one nested folder section from a verified ProgRSS source list as an independent local excerpt.

The CLI remains offline unless a command explicitly says `feed fetch`, `bundle fetch`, `bundle from-page`, `bundle check-page`, or `workspace check-publication`. Artifact-producing commands use synchronized temporary files, exclusive no-overwrite commits, and local read-back checks.

The CLI does not inherit browser site permissions, run a localhost bridge, or require the Extension.

## Import one source-list section

The complete source list remains the default:

```text
./progrss workspace import-bundle \
  private-backup.json shared-folder.json \
  --output library-with-list.json
```

Select one existing folder branch with an exact ID, full path, or unambiguous title:

```text
./progrss workspace import-bundle \
  private-backup.json shared-folder.json \
  --folder "Neighborhood reading › Public meetings" \
  --output library-with-section.json
```

The selected branch contains the chosen folder, all of its simple descendants, and only sources referenced by that branch. Exact local recipes are reused and newly created sources begin paused. Empty sections, ambiguous titles, malformed graphs, and advanced collection algebra are refused.

A selected branch is an **independent local excerpt**. It does not retain the parent publication identity, future-copy address, or automatic update relationship. The parent document’s digest and optional signature validate the parent document; they are not represented as a separate signature over the derived excerpt.

The transaction performs no DNS lookup, network request, browser-profile read, or permission operation. It leaves both inputs untouched, writes one new backup, and refuses overwrite.

## List a source list’s actual contents

```text
./progrss bundle contents shared-folder.json

./progrss bundle contents shared-folder.json \
  --limit 40

./progrss bundle contents shared-folder.json --json
```

The command validates the complete supported source-list document, then reports folder routes and each source’s title, host, feed/page type, and direct folder placement. `progrss.shared-folder.contents.v2` additionally reports how many sources, feeds, watched pages, and descendant folders each branch contains.

Human output is bounded by `--limit`; JSON output contains the complete report within the source-list format’s existing bounds. The command performs no DNS lookup, network request, browser-profile read, permission-store read, input mutation, or output write. `bundle inspect` remains the compact integrity summary; `bundle contents` answers what the list actually carries.

## Audit a deployed publication page

```text
./progrss bundle check-page https://example.org/reading/

./progrss bundle check-page https://example.org/reading/ \
  --require-updates \
  --json
```

The audit fetches only the explicitly supplied page and its same-origin advertised ProgRSS artifacts. It verifies the page's restrictive Content Security Policy, refuses active or remote page material, validates the connected v3 source list and configured update address, and validates a matching summary-only Edition when advertised.

`--require-updates` turns absence of the recent-updates feed into a deployment failure. Without it, an intentional source-list-only site remains valid.

The command writes nothing, imports nothing, follows nothing, applies nothing, schedules nothing, sends no credentials, ignores environment proxy inheritance, and stops before a cross-origin redirect destination is contacted.

## Export one folder as a recent-updates feed

```text
./progrss workspace edition \
  private-backup.json "Neighborhood reading" \
  --output neighborhood-updates.json

./progrss workspace edition \
  private-backup.json "Neighborhood reading" \
  --curator "Neighborhood desk" \
  --note "A small public selection." \
  --limit 40 \
  --output neighborhood-updates.json \
  --json
```

The command accepts an exact folder ID, full path, or unambiguous title. It refuses `all`, `unfiled`, advanced collection algebra, and ambiguous folder names.

The JSON Feed includes bounded titles, short summaries, links, dates, declared language, source labels, and page-change kind. Ordinary items sharing the same public URL collapse into one entry with a source-witness count. Full bodies, read and saved state, page-watch comparison passages, snapshots, browser authority, and private keys are excluded.

The export:

```text
performs no DNS lookup
performs no network request
reads no browser profile
grants no permission
leaves the input unchanged
writes one new file
refuses overwrite
```

It is a manual edition, not an automatically maintained endpoint or publication account.

## Explain site-access decisions without contacting a site

```text
./progrss workspace access-plan private-backup.json

./progrss workspace access-plan private-backup.json \
  --source "Community board"

./progrss workspace access-plan private-backup.json \
  --origins --json
```

The report names the visible Extension action for each source and explains the unchanged result when access is not granted. Current browser grants are always reported as unknown. The command performs no DNS lookup, network request, browser-profile read, permission read, or write. Site origins are hidden unless `--origins` is supplied.

## Assess a page watch without changing it

```text
./progrss workspace assess-page-watch \
  library.json "Community board" current-page.html

./progrss workspace assess-page-watch \
  library.json "Community board" unusual-page.html \
  --confirm-html next-page.html \
  --json
```

`assess-page-watch` applies the saved page-watch recipe to one explicit local UTF-8 HTML specimen and compares its bounded shape with the saved snapshot. A second specimen can represent the next check.

The report distinguishes:

```text
steady
hold
confirmed-new-shape
returned-to-steady
repair
```

It creates no page-change item, changes no saved snapshot, performs no DNS lookup or HTTP request, reads no browser profile, and writes no file. Human output ends with:

```text
No page alerts written · no snapshot changed
```

The assessment is evidence, not an authorization token. The live Extension recomputes page content and vault state on every real check.

## Review and repair a broken page watch offline

```text
./progrss workspace review-page-watch \
  library.json "Town notices" current-page.html

./progrss workspace repair-page-watch \
  library.json "Town notices" current-page.html \
  --proposal PROPOSAL_ID \
  --output repaired-library.json
```

The review identifies a bounded set of repeated-entry or main-text choices and shows representative text without contacting the watched site. Repair recomputes the proposals from the exact input files, requires one exact proposal identifier, updates only the selected recipe, stores a fresh baseline, creates no synthetic page-change item, writes one new backup, and refuses overwrite.

## Publish a curated folder as an ordinary static website

Prepare the source-list site only:

```text
./progrss workspace publish-folder library.json "Neighborhood reading" \
  --update-url https://example.org/reading/latest.json \
  --curator "Neighborhood desk" \
  --note "A small practical reading list." \
  --output neighborhood-reading.zip
```

Include a summary-only recent-updates feed and readable update section:

```text
./progrss workspace publish-folder library.json "Neighborhood reading" \
  --update-url https://example.org/reading/latest.json \
  --include-updates \
  --update-limit 40 \
  --output neighborhood-reading.zip
```

Package an already prepared or browser-signed located folder together with an explicit Edition file:

```text
./progrss bundle site signed-shared-folder.json \
  --edition neighborhood-updates.json \
  --output neighborhood-reading.zip
```

`workspace publish-folder` creates an unsigned `progrss.bundle.v3` from one existing simple folder. With `--include-updates`, it also derives a summary-only `progrss.folder-edition.v1` JSON Feed from that same explicit backup. `bundle site` accepts an already prepared v3 file, including a browser-signed one, and optionally accepts an independently prepared Edition file.

The complete package may contain:

```text
index.html             script-free page for people
latest.json            native ProgRSS folder at the configured public name
subscriptions.opml     feed-only import when feeds are present
recent-updates.json    summary-only JSON Feed when selected
README.txt             literal upload instructions
```

The page advertises the native folder and optional JSON Feed through typed `rel=alternate` links. It shows at most ten recent updates, while the feed may contain at most 100 items and 250,000 UTF-8 bytes. The feed receives hosted `home_page_url` and `feed_url` values derived from the native folder’s configured address.

The Edition must name the same folder as the native bundle, use compatible curator attribution, contain only the bounded public fields ProgRSS generates, and confirm all required private-data exclusions. Unknown fields such as `content_html`, unsafe identifiers, malformed source witnesses, invalid dates or languages, or a mismatched folder stop the package.

The configured address must be credential-free HTTP(S), end in a simple `.json` filename, and contain no query string or fragment. The HTML has a restrictive Content Security Policy, no JavaScript, trackers, remote images, frames, embedded media, forms, or automatic checks. It loads no item page merely to display the update list.

Both commands perform no DNS lookup, HTTP request, browser-profile read, permission operation, input mutation, or output overwrite. The ZIP is bounded, written as a new file, reopened, path-audited, and byte-compared member by member before success is reported. It remains a manual package: ProgRSS neither uploads nor regenerates it.

## Verify a shared folder from its direct address

```text
./progrss bundle fetch https://example.org/reading/latest.json

./progrss bundle fetch https://example.org/reading/latest.json \
  --output reading-folder.json

./progrss bundle fetch https://example.org/reading/latest.json --json
```

`bundle fetch` makes one explicit, bounded network retrieval of the address supplied by the operator. It verifies a supported `progrss.bundle.v1`, `v2`, or `v3` document, its connected simple-folder graph, its semantic digest where present, and its optional Ed25519 or P-256 signature. A `.json` suffix or friendly `Content-Type` is not enough; an otherwise generic response is accepted only after the complete native document validates.

The command sends no URL credentials, cookies, or environment proxy authority, uses a twenty-second deadline and 650 KB limit, follows at most five same-origin redirects, and stops before a cross-origin destination is contacted. It reports `automatic: false` and `applied: false`.

Without `--output`, it writes nothing. With `--output`, it saves the normalized verified document through the synchronized new-file-only, no-overwrite transaction. It never imports the folder, edits a private library, reads a browser profile, grants browser permission, or schedules another check.

## Discover a shared folder from its publication page

```text
./progrss bundle from-page https://example.org/reading/

./progrss bundle from-page https://example.org/reading/ \
  --output reading-folder.json

./progrss bundle from-page https://example.org/reading/ --json
```

The command retrieves one bounded UTF-8 HTML page and recognizes only an exact same-origin advertisement such as:

```html
<link rel="alternate"
      type="application/vnd.progrss.shared-folder+json"
      href="latest.json">
```

It then fetches and fully validates the native ProgRSS document. The report includes the page address, advertised address, final same-origin addresses, redirect counts, publication identity, curator label, source and folder counts, digest state, and signature state. It always reports that the result was not imported or applied.

The command uses no URL credentials, no environment proxy inheritance, no cookies, a twenty-second deadline, a 650 KB limit for each response, and at most five same-origin redirects. A cross-origin advertisement or redirect stops before the destination is contacted. Zero candidates, multiple candidates, generic JSON links, malformed UTF-8, invalid bundles, and unsafe graphs are refused.

Without `--output`, the command writes nothing. With `--output`, it saves the exact verified native document to one new path and refuses overwrite. It never reads a browser profile, grants permission, mutates a private library, imports the folder, or schedules a future check.

`bundle fetch` is the direct-address form. The page-discovery command remains deliberately different from `workspace check-publication`: `bundle from-page` locates an initial portable folder from a public page, while `workspace check-publication` checks the configured later copy of a publication already imported into a private library.

## Inspect and read local feeds

```text
./progrss feed preview downloaded-feed.xml \
  --url https://example.org/feed.xml

./progrss feed preview downloaded-feed.xml \
  --url https://example.org/feed.xml --limit 5 --json

./progrss feed inspect downloaded-feed.xml \
  --url https://example.org/feed.xml

./progrss feed inspect downloaded-feed.xml \
  --url https://example.org/feed.xml --json

./progrss feed corpus
./progrss feed corpus --json
./progrss feed corpus --directory another-corpus
```

`feed preview` parses one already-downloaded RSS, Atom, or JSON Feed and emits `progrss.feed.preview.v1`. It includes the feed title and type, total item count, and up to twenty compact examples containing only title, item URL, supplied publication time, declared language, and `full-text`, `summary`, or `title-only` availability. Summary and body strings are deliberately absent. The command reports `network: false` and `writes: false`; human output ends with **Nothing followed · no writes**.

`feed inspect` is the deeper local parser view. It reports summaries and bounded full text separately when the format supplies them. Markup is converted to plain text; scripts, frames, remote images, and other resource-shaped elements are not retained.

The packaged Interoperability Garden contains 32 byte-identical cases in the Extension and CLI trees. It includes RSS 2.0, RSS 1.0/RDF, Atom, JSON Feed, namespaces, nested `xml:base`, self addresses, identities, revisions, encodings, full-content fields, JSON Feed language inheritance, Atom `xml:lang`, RSS language metadata, difficult whitespace, resource-shaped markup exclusion, malformed documents, and DTD/entity refusal.

## Read one retained update or page change

```text
./progrss workspace read private-backup.json ITEM
./progrss workspace read private-backup.json ITEM --json
```

`ITEM` may be an exact item ID, exact title, or exact retained URL. Ambiguous titles or URLs are refused.

For a feed item, the command prints the bounded feed-supplied plain text stored in the backup. For a page-watch event, it prints why ProgRSS noticed the change plus bounded **Before** and **Now** context. It performs no DNS lookup, network request, write, browser-profile read, or permission operation.

Retained bodies are capped at 12,000 characters, matching the Extension. The JSON form distinguishes `bodyIsSummary` and reports retained feed/item language fields so callers can tell whether the feed supplied fuller text, only an excerpt, and any explicit language metadata. Missing language is left missing; the CLI does not guess or translate it.

## Explain page-watch history

```text
./progrss workspace page-changes private-backup.json
./progrss workspace page-changes private-backup.json --unread-only
./progrss workspace page-changes private-backup.json --source "Library hours" --json
```

The report includes the page-watch source, event title and time, reason, policy, and normalized `progrss.page-change.v1` record. New events may carry bounded before/after context, exact added/removed fragments, word counts, threshold, and number-change policy. Older events without that record remain visible and are labeled as legacy rather than invented into a false diff.

The command is offline, read-only, and browser-profile independent.

## Search and source activity

```text
./progrss workspace query private-backup.json --contains greenhouse
./progrss workspace query private-backup.json --unread-only --json
./progrss workspace sources private-backup.json
./progrss workspace sources private-backup.json --problems-only --json
```

Search matches source names, titles, summaries, retained feed body text, and page-change before/after evidence. Source activity uses the same human vocabulary as the reader, including **Moved** and **Reconnect**.

## Inspect a private library

```text
./progrss workspace inspect private-backup.json
./progrss workspace transfer-audit private-backup.json
./progrss workspace transfer-audit private-backup.json --origins --json
```

`transfer-audit` explains what moves, reports the number of curator-written folder reasons, and gives an upper bound on sources and sites that may require Reconnect. Origin names are hidden by default. Before any workspace command uses a private file, Source Notes must be canonical direct folder/source placements: valid Unicode scalar strings of at most 280 code points, with no wrong-level, empty, edge-whitespace, missing-source, or reason-bearing duplicate placement. The ordinary workspace commands and the Relay share/publish/import/review/check/update commands all use the same audit. The CLI refuses malformed files before output or explicit publication-network work rather than trimming, deduplicating, relocating, or choosing a reason silently.

## Make a validated recovery copy

```text
./progrss workspace recovery-copy private-backup.json \
  --output ProgRSS-recovery.json
```

The command validates the explicit input—including every optional direct-placement Source Note—refuses a library with audit errors, strips browser-local revision and timed-undo fields, labels the result `purpose: recovery-copy`, and writes one new private plaintext file. After committing the new path, it re-opens and validates that file and compares the portable-vault digest. A failed local read-back removes the misleading output. The successful message therefore says the copy is readable and matching **now**, not that future filesystem survival is guaranteed.

It reports source, update, unread, and saved counts plus a content digest that is a change detector—not an identity proof.

Browser-local missing-library detection and reminder timing are intentionally not CLI commands. The CLI does not inspect a browser profile, extension-local markers, browser permissions, or download history. Its honest recovery boundary is an explicit private file supplied by the operator.

It performs no DNS lookup, network request, browser-profile read, or permission operation. It never mutates the input and never overwrites an existing output. The unchanged input remains the rollback copy.

## Compare two private copies

```text
./progrss workspace compare-copies older.json newer.json
./progrss workspace compare-copies older.json newer.json --json
./progrss workspace compare-copies older.json newer.json --require-match
```

The command validates both explicit `progrss.private.v1` files, computes the same portable-vault digest for each, and reports count changes plus added, removed, changed, and unchanged sources, folders, updates, and snapshots. Advanced Workbench changes are reported by group count. Human output deliberately omits followed addresses and titles.

An export timestamp says when a file was prepared. It does not prove that one file is a complete successor of the other, that the later-named file contains every change, or that either file came from a trusted person. `compare-copies` is an offline change detector, not a merge, authenticity check, or restore operation. It performs no network request, browser-profile read, permission operation, or write. By default a valid difference still exits successfully so the command can be used for reporting. `--require-match` exits with status 3 when both files are valid but differ; invalid input remains status 2.

## Simple folder parity

```text
./progrss workspace folders private-backup.json
./progrss workspace folders private-backup.json --include-unfiled --json

./progrss workspace query private-backup.json \
  --folder "Reading › Practical" --unread-only

./progrss workspace place-source private-backup.json \
  "Garden Notes" "Reading › Practical" \
  --output organized.json

./progrss workspace remove-from-folder organized.json \
  "Garden Notes" "Reading › Practical" \
  --output corrected.json

./progrss workspace source-note organized.json \
  "Garden Notes" "Reading › Practical" \
  --reason "Hands-on repair references for this route." \
  --output noted.json

./progrss workspace source-note noted.json \
  "Garden Notes" "Reading › Practical" \
  --clear --output reason-cleared.json
```

Only existing plain-union folders are accepted. Advanced, filtered, subtractive, intersecting, ambiguous, or cyclic structures are refused rather than flattened.

A Source Note is optional plain text on one direct folder/source relationship, not on the source globally. The command trims only ASCII edge whitespace, omits an empty value, and enforces the shared 280-Unicode-code-point limit. It performs no network request, publishes nothing, contacts nobody, creates no schedule, and makes no ProgRSS safety claim. It writes a new backup only; the input remains the rollback copy.

## OPML, JSON Feed, read state, and offline ingestion

```text
./progrss workspace import-opml private-backup.json subscriptions.opml \
  --output migrated.json

./progrss workspace opml private-backup.json \
  --output subscriptions.opml

./progrss workspace json-feed private-backup.json \
  --unread-only --output unread.json

./progrss workspace mark-all-read private-backup.json \
  --output read.json

./progrss workspace ingest private-backup.json downloaded-feed.xml \
  --url https://example.org/feed.xml \
  --output updated.json
```

OPML import is local and preserves simple nested folders. It imports paused unless `--active` is explicitly supplied; the CLI still cannot grant browser permission or fetch the imported sites.

Offline ingestion uses the same append-only revision model as the Extension. It can enrich an otherwise identical old item with newly available full text or valid language metadata without manufacturing a new unread event. A real body change remains a separate retained revision.

JSON Feed export uses retained body text as `content_text`, keeps the shorter summary separately, and carries a valid item `language` plus a shared top-level language when all exported items agree.

## Audit and choose retained feed text

```text
./progrss workspace text-storage library.json
./progrss workspace text-storage library.json --json

./progrss workspace set-text-retention library.json SOURCE summary \
  --output summaries.json

./progrss workspace set-text-retention library.json SOURCE summary \
  --trim-read --output summaries-trimmed.json

./progrss workspace set-text-retention library.json SOURCE full \
  --output full-text-again.json
```

`workspace text-storage` is a read-only local audit. It counts the exact UTF-8 bytes occupied by retained full body strings, distinguishes summary bodies and intentional omissions, reports the read-and-unsaved cleanup candidates, and includes archived sources. It does not estimate filesystem allocation, browser indexes, quota, or eviction behavior.

`workspace set-text-retention` changes one explicit RSS/Atom/JSON Feed source in a new backup. `summary` affects later Extension checks. `full` removes the non-default policy so later checks may retain fuller feed text again. `--trim-read` is accepted only with `summary`; it removes fuller text only from already-read, unsaved items belonging to that source. Unread and saved items remain intact.

These commands perform no DNS lookup, network request, browser-profile read, or permission operation. They never modify the input or overwrite an existing output. The unchanged input backup is the CLI rollback boundary.

## Duplicate histories and exact blockers

```text
./progrss workspace duplicate-sources private-backup.json

./progrss workspace source-references private-backup.json \
  FIRST SECOND --paths

./progrss workspace combine-sources private-backup.json \
  FIRST SECOND --keep FIRST \
  --output combined.json
```

Candidates require exact reviewed address evidence. The audit does not use title similarity, item resemblance, domains, or confidence scores.

Combination keeps the chosen survivor’s current address, schedule, pending move, and validators. Exact repeated content collapses with conservative read/saved-state union; non-identical body revisions remain separate. Unknown Advanced Workbench references block the transaction.

Direct folder placements are reconciled by folder, not by member order. A reason on only one history is preserved; identical reasons collapse to that value; two absent reasons remain absent; and separate folders keep separate reasons. Two different nonempty reasons on the same folder placement block preview and commit until a person edits or clears one reason. ProgRSS does not choose a winner automatically, and a refused repair leaves the input state unchanged.

## Retired graft-receipt evidence

```text
./progrss workspace retire-graft-receipt private-backup.json \
  FIRST SECOND RECEIPT_ID \
  --output retired.json

./progrss workspace retired-receipts retired.json --json
```

Only exact `progrss.recipe.graft.receipt.v1` records qualify. The original receipt is preserved unchanged inside a digest-bound retired-evidence envelope. The operation does not retarget trust, rewrite history, combine sources, contact a site, or modify the input.

## Explicit network commands

```text
./progrss feed fetch https://example.org/feed.xml \
  --output downloaded-feed.xml

./progrss workspace check-publication library.json "Research › Climate"

./progrss workspace check-publication library.json "Research › Climate" \
  --output climate-checked.json --json
```

`feed fetch` follows only bounded same-origin redirects. It stops before contacting a cross-origin destination and prints the proposed address for explicit review. It validates the received document before committing unless `--no-validate` is deliberately supplied.

`workspace check-publication` reads the imported folder’s signed or digested future-copy address, performs one explicit fetch, verifies the returned native shared folder, requires the same stable publication identity, and computes the normal three-way update review. It uses a 20-second deadline, a 650 KB body limit, no proxy credentials, and at most five same-origin redirects. A cross-origin redirect stops before the destination is contacted.

The command never applies the update. Without `--output`, the fetched bytes are discarded after review. With `--output`, the normalized verified copy is committed as one new file and never overwrites. Applying consequences remains the separate offline `workspace update-bundle` command.

## Browser-neutral backup language

Chromium and Firefox export the same `progrss.private.v1` language. Portable data includes sources, retained updates, reading state, folders, page-watch evidence, Advanced Workbench records, and retired evidence.

Browser-local authority and coordination do not travel:

```text
_revision
transferUndo
sourceRepairUndo
receiptRetirementUndo
host permissions
activeTab authority
extension signing identity
```

## Preserved rev0021 carrier

The supplied one-file carrier remains byte-for-byte at:

```text
legacy/ProgRSS-rev0021.html
```

It is preserved as provenance and a runnable legacy artifact, not represented as the absent Extension/CLI source tree described by an older handoff.

## Test

```text
bash tests/run.sh
./progrss doctor
```

The suite covers the 32-case feed corpus, body extraction and refusal boundaries, bounded page-change audit, `workspace page-changes`, `workspace read`, body/change-aware search, offline ingestion and enrichment, folders, migration, transfer audit, source repair, exact blocker reports, retired evidence, redirects, no-overwrite behavior, and command-line errors.

## Shared folders

```sh
# Discover and verify the native folder advertised by a public page
python3 progrss.py bundle from-page https://example.org/climate/ \
  --output climate.json --json

# Inspect or verify without changing a workspace
python3 progrss.py bundle inspect shared-folder.json --json
python3 progrss.py bundle verify shared-folder.json --require-signature

# Package an existing located folder as a ready-to-host static ZIP
python3 progrss.py bundle site shared-folder.json \
  --output shared-folder-site.zip

# Add an explicit summary-only Edition to that package
python3 progrss.py bundle site shared-folder.json \
  --edition recent-updates.json \
  --output shared-folder-with-updates.zip

A ready-to-host package shows each optional curator-written Source Note beside the exact folder/source relationship it describes. The same source may therefore have different displayed reasons in different folders. The HTML escapes the text, preserves line breaks, and lets the browser choose natural text direction. The native ProgRSS JSON preserves those placement values and remains the interoperable authority; OPML deliberately omits them and the README explains that loss. A curator reason is attribution and routing context, not a ProgRSS safety claim.

# Export and package a selected simple folder in one transaction
python3 progrss.py workspace publish-folder backup.json "Research › Climate" \
  --update-url https://example.org/climate/latest.json \
  --include-updates --update-limit 50 \
  --output climate-site.zip

# Export a selected simple folder; accepts ID, unique title, or full path
python3 progrss.py workspace share-folder backup.json "Research › Climate" \
  --output climate.json --format bundle --json

# Include one public future-copy address; recipients still check manually
python3 progrss.py workspace share-folder backup.json "Research › Climate" \
  --update-url https://example.org/climate.json \
  --output climate-located.json --format bundle --json

# Exchange feeds with other readers; page watches are counted as omitted
python3 progrss.py workspace share-folder backup.json "Research › Climate" \
  --output climate.opml --format opml

# Initial import into a new backup
python3 progrss.py workspace import-bundle backup.json climate.json \
  --output backup-with-climate.json --json

# Fetch and review the configured copy; no apply, optional verified output
python3 progrss.py workspace check-publication \
  backup-with-climate.json "Research › Climate" \
  --output climate-later.json

# Review any local later copy of the same publication; no write
python3 progrss.py workspace review-bundle \
  backup-with-climate.json climate-later.json

# Apply the reviewed consequences to one new backup
python3 progrss.py workspace update-bundle \
  backup-with-climate.json climate-later.json \
  --output backup-with-climate-update.json
```

Native bundles are reviewed as connected, acyclic simple-folder graphs. Initial import reuses matching feeds and exact page-watch recipes; new sources start paused. `progrss.bundle.v3` adds one `progrss.shared-folder.distribution.v1` future-copy address to the checked digest and optional signature. Older v1 and v2 files remain readable. OPML omits the address because it cannot preserve ProgRSS distribution, page-watch, or signature semantics.

A later copy is matched by stable publication identity and compared with the stored `progrss.shared-folder.baseline.v1`. The review distinguishes recipe, hierarchy, attribution, and signer changes while reporting local edits that will be preserved. Older copies, same-time content conflicts, missing mapped records, ambiguous local copies, and Advanced Workbench folder rules are refused rather than guessed through.

A changed signing key or signed-to-unsigned transition requires `--accept-trust-change` on `update-bundle`. That flag acknowledges only the observed continuity break; it does not authenticate a person or make the listed sites safe.

Changed acquisition recipes become separate paused sources. Removed publication sources keep their retained histories. Locally edited or still-referenced removed folders detach and survive. The command recomputes the review from the exact inputs, writes one new destination, never overwrites, and performs no network, DNS, browser-profile, or permission operation.
