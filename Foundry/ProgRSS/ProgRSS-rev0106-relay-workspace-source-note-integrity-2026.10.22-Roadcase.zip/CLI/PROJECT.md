## rev0080 — Roadcase

Roadcase packages the exact delivered browser and Node trees with synthetic fixtures, deterministic verification, preparation, native-install instructions, and cleanup. It adds no product authority and makes no native or human acceptance claim.
**Know what leaves before you send the link.**

Dispatch generates one private `exchange-sender-review` Fieldbook from the
exact `progrss.node.exchange-preview.v1` document that the local administrator
reviews before creating an Exchange handoff. It studies whether an unfamiliar
sender understands artifact contents, privacy exclusions, recipient doors,
public-address and static-package boundaries, expiry, revocation, Origin
binding, and the absence of listed-site requests, schedules, uploads, or
recipient-library access.

The sender Fieldbook is local-only, no-network, no-write, no-telemetry,
new-file-only through the CLI, and identity-minimized. It omits route and
curator identity, source identity, folder paths, public addresses, library
identity, artifact digests, and preview capability material.

Crossroads remains the separate recipient-side scenario. Debrief refuses mixed
scenario digests, releases, or task sequences.

Current authority remains narrow:

- the Node administrator reviews one exact share preview;
- creating a Fieldbook neither creates nor consumes the handoff;
- no listed source is contacted;
- no library or Node store is changed;
- pairing remains summary-only and read-only;
- no automatic publication, upload, schedule, or synchronization is implied.

See `docs/NODE-DISPATCH.md` and `docs/NODE-DISPATCH-ACCEPTANCE.md`.
