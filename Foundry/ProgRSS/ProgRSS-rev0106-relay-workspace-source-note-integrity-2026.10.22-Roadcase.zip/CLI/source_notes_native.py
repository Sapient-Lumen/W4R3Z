"""Native Source Notes placement helpers.

A reason belongs to one direct folder/source member relationship. The helpers
preserve absence, omit an empty string, validate Unicode scalar values, and use
Unicode code points for the 280-character bound. Full private-library audits are
shared by the offline CLI and both loopback Node ingress paths so malformed
placement data is refused before storage, serving, or export.
"""
from __future__ import annotations

from typing import Any, Mapping

SOURCE_NOTE_PLACEMENT_KEY = ("folderId", "sourceId")
MAX_SOURCE_NOTE_CODE_POINTS = 280
_ASCII_EDGE_WHITESPACE = " \t\r\n\f\v"


class SourceNoteError(ValueError):
    """Raised when direct-placement Source Note data violates the contract."""


def normalize_reason(value: Any) -> str | None:
    if value is None:
        return None
    if type(value) is not str:
        raise SourceNoteError("placement reason must be a string")
    reason = value.strip(_ASCII_EDGE_WHITESPACE)
    if not reason:
        return None
    if any(0xD800 <= ord(character) <= 0xDFFF for character in reason):
        raise SourceNoteError("placement reason contains an invalid Unicode scalar value")
    if len(reason) > MAX_SOURCE_NOTE_CODE_POINTS:
        raise SourceNoteError("placement reason exceeds 280 Unicode code points")
    return reason


def preserve_reason(source_member: Mapping[str, Any], projected_member: dict[str, Any]) -> dict[str, Any]:
    out = dict(projected_member)
    if "reason" in source_member:
        reason = normalize_reason(source_member.get("reason"))
        if reason is not None:
            out["reason"] = reason
        else:
            out.pop("reason", None)
    return out


def placement_key(folder_id: str, source_id: str) -> tuple[str, str]:
    if not isinstance(folder_id, str) or not folder_id:
        raise SourceNoteError("folderId must be a non-empty string")
    if not isinstance(source_id, str) or not source_id:
        raise SourceNoteError("sourceId must be a non-empty string")
    return (folder_id, source_id)


def _compact_text(value: Any, limit: int = 300) -> str:
    """Match the bounded identity display used by the private-library CLI."""
    return " ".join(str(value if value is not None else "").split())[:limit]


def validate_private_source_note_placements(state: Mapping[str, Any]) -> int:
    """Validate every Source Note in one private-library state.

    The function does not mutate or canonicalize the supplied state. Empty or
    edge-whitespace values are therefore refused rather than silently rewritten.
    Duplicate reason-bearing direct placements are refused even when their text
    matches because one relationship must have one canonical representation.
    The return value is the number of valid curator-written placement reasons.
    """
    if not isinstance(state, Mapping):
        raise SourceNoteError("private backup state must be an object")

    raw_sources = state.get("sources", [])
    raw_collections = state.get("collections", [])
    if not isinstance(raw_sources, list):
        raise SourceNoteError("private backup state.sources must be an array")
    if not isinstance(raw_collections, list):
        raise SourceNoteError("private backup state.collections must be an array")

    source_ids = {
        _compact_text(source.get("id"))
        for source in raw_sources
        if isinstance(source, Mapping) and _compact_text(source.get("id"))
    }
    count = 0
    for collection_index, collection in enumerate(raw_collections):
        if not isinstance(collection, Mapping):
            continue
        folder_id = _compact_text(collection.get("id")) or str(collection_index + 1)
        if "reason" in collection:
            raise SourceNoteError(
                f"collection {folder_id} carries a Source Note on the folder; "
                "put it on one direct source placement instead"
            )
        members = collection.get("members")
        if not isinstance(members, list):
            continue
        seen: dict[tuple[str, str], bool] = {}
        for member_index, member in enumerate(members):
            if not isinstance(member, Mapping):
                continue
            kind = member.get("kind")
            member_id = _compact_text(member.get("id"))
            has_reason = "reason" in member
            key = (str(kind or ""), member_id)
            previous_had_reason = seen.get(key, False) if member_id else False
            if member_id:
                if key in seen and (previous_had_reason or has_reason):
                    raise SourceNoteError(
                        f"collection {folder_id} repeats placement {kind}:{member_id}; "
                        "a reason-bearing direct relationship must appear exactly once"
                    )
                seen[key] = previous_had_reason or has_reason
            if not has_reason:
                continue
            if kind != "source":
                raise SourceNoteError(
                    f"collection {folder_id} member {member_index + 1} carries a Source Note "
                    "on something other than a direct source placement"
                )
            if not member_id:
                raise SourceNoteError(
                    f"collection {folder_id} member {member_index + 1} has a Source Note "
                    "but no source identity"
                )
            if member_id not in source_ids:
                raise SourceNoteError(
                    f"collection {folder_id} gives missing source {member_id} a Source Note"
                )
            try:
                normalized = normalize_reason(member.get("reason"))
            except SourceNoteError as exc:
                raise SourceNoteError(
                    f"collection {folder_id} placement source:{member_id} has an invalid Source Note: {exc}"
                ) from exc
            if normalized is None:
                raise SourceNoteError(
                    f"collection {folder_id} placement source:{member_id} has an empty Source Note; "
                    "omit the field instead"
                )
            if member.get("reason") != normalized:
                raise SourceNoteError(
                    f"collection {folder_id} placement source:{member_id} has a noncanonical Source Note; "
                    "remove leading or trailing ASCII whitespace"
                )
            count += 1
    return count
