# ProgRSS rev0068 — Pulse

**Release maxim:** One clock. One fetcher. One receipt.

Pulse repairs the rev0067 Cadence delivery defect and supplies the executable Node-local timing layer that the prior archive described but did not contain. It then removes Cadence's normal external-runner dependency by invoking the packaged Witness acquisition path directly.

## Delivered

- Real `CLI/cadence/` package with `init`, `review`, `create`, `list`, `pause`, `resume`, `run-due`, `start`, and `serve`
- Timing database bound to one durable Node-store identity
- Eligibility from one durable successful public Witness receipt
- Acquisition-source identity covering feed/page address and declarative page-watch recipe
- Refusal of browser-assisted Capture and zero-request evidence
- Explicit offline timing review and acknowledgement
- 15-minute minimum, 30-day maximum, and bounded deterministic jitter
- Foreground scheduler that starts stopped
- Durable single-owner lease
- Stable due slots and prepared Witness operation identity
- Packaged in-process Witness adapter; no second downloader
- Restart-safe resume and exact completed replay
- Lost-response recovery after Node commit without a second site request
- Bounded exponential backoff
- Bounded delta-seconds and HTTP-date `Retry-After`
- Persistent per-site courtesy window
- Blocking outcomes pause the plan for review
- Capability-protected literal-loopback dark/light GUI
- Human-readable local times with exact UTC evidence retained under Advanced
- Updated native, human, interruption, and accessibility protocol
- Chain-of-custody report for the rev0067 archive defect

## Deliberate boundaries

- Timing plans remain Node-local and are not portable library or source-list state.
- Import, pairing, Exchange, Branch, Witness, and Capture create no schedule.
- Pause means no Pulse due dispatch.
- The foreground process must remain running; no operating-system service is installed.
- Browser-assisted and browser-only pages remain deliberate captures.
- The paired Extension receives no schedule or acquisition authority.
- The external argv-only runner remains an advanced alternative, not the default.
- Remote scheduling, continuous synchronization, LAN discovery, browser wake-up, and cookie transfer remain unavailable.

## Chain-of-custody correction

The input rev0067 archive's launcher imported `cadence.cli`, but the archive contained no `CLI/cadence/` package. Its Cadence command surface therefore could not execute from the delivered bytes. The claimed rev0067 metadata is retained under `Evidence/rev0067-Cadence-archive-defect/` and is not treated as executable proof.

## Next boundary

Run Pulse with unfamiliar people and real assistive technology on unmanaged Chromium, current Firefox, and Firefox ESR. Improve page-watch quality and organization before introducing remote scheduling, a permanent daemon, or another broad write surface.
