# rev0105 — Node private-library Source Note integrity

- Reproduced the rev0104 Node gap: a private backup containing a 281-code-point direct-placement reason was accepted by `node init`, persisted in the SQLite library, reopened, re-exported, and accepted by the read-only Node loader.
- Added one shared Python private-library Source Notes audit in `CLI/source_notes_native.py`.
- Made the offline CLI, transactional Node store, and read-only Node backup loader use that same audit.
- Refuse over-limit, wrong-level, folder-member, reason-bearing duplicate, empty, edge-whitespace, non-string, invalid-Unicode, and missing-source forms before storage or serving.
- Revalidate stored Node libraries and every operation/acquisition/snapshot result at existing `_validate_backup_bytes` boundaries.
- Preserve valid two-folder reasons and explicit absence byte-for-byte through Node import, read, export, and read-only serving.
- Add no browser permission, network authority, persistent store, account, schedule, notification, ranking, profile, reaction, comment, or messaging capability.
- Keep the runtime catalog at 18 cases by extending `two-folder-independence`.
