# Source Notes publication-disclosure audit — rev0098

- Parent: `ProgRSS-rev0097-source-notes-lineage-preservation-2026.10.21-Roadcase.zip`
- Parent SHA-256: `65643a4899276bdbbc348aacee60a3db2c84a23c70f3c4f32df3ec03188a4336`
- Parent CLI and Extension native JSON preserved two placement reasons while the generated recipient HTML omitted both: **REPRODUCED**.
- CLI focused publication tests: **4 passed** (three dedicated tests plus the shipped command-path test).
- Shared browser-module corpus: **12 checks per package variant**, Chromium source and generated Firefox.
- Same source / two folders: distinct reasons remain attached to the correct routes.
- Missing reason: no invented visual note.
- Generated text: HTML-escaped, multiline-preserving, `dir=auto`, narrow-width reflow.
- Meaning: curator authorship is named and the note is explicitly not a ProgRSS safety claim.
- Native JSON: unchanged and authoritative.
- OPML: still omits Source Notes; README explains the loss.
- Chromium/Firefox shared publication module bytes: **IDENTICAL**.

These are native and managed regression results, not installed-browser, participant, privacy-comprehension, assistive-technology, or accessibility-conformance evidence.
