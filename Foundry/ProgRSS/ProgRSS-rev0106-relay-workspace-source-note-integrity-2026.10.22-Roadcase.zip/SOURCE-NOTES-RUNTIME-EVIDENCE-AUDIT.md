# Runtime-evidence binding audit — rev0106

- The fixed catalog remains 18 behavioral cases.
- Session schema v5 and result/predicate v3 remain in force.
- `two-folder-independence` now includes valid and malformed Relay workspace share, publish, import, review, explicit publication-check, update, and output-boundary behavior.
- Fresh rev0106 sessions are required; older records must not be relabeled.
- This revision adds no new evidence layer and makes no installed-browser, human, privacy, assistive-technology, or accessibility-conformance claim.
