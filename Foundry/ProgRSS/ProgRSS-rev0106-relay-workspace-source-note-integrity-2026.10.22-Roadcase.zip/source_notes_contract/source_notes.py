"""Reference contract for ProgRSS direct folder-to-source notes.

The module is intentionally independent of transport and UI code.  A note belongs
only to one direct folder-to-source placement.  Later-copy reconciliation is a
three-way comparison: base, recipient ("mine"), and curator.  No divergent
change is selected automatically.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

MAX_NOTE_CODEPOINTS = 280
_ASCII_EDGE_WHITESPACE = " \t\r\n\f\v"
_KEEP_MINE = "keep_mine"
_USE_CURATOR = "use_curator"
_VALID_DECISIONS = frozenset({_KEEP_MINE, _USE_CURATOR})
_MISSING = object()


class SourceNoteError(ValueError):
    """Raised when source-note input violates the native contract."""


def canonicalize_note(value: Any) -> str | None:
    """Validate and canonicalize one optional plain-text reason.

    ``None`` and strings containing only ASCII edge whitespace canonicalize to
    absence.  Character limits are counted as Unicode code points, matching
    JavaScript's ``Array.from(text).length``.  UTF-8 encoding is checked so lone
    surrogate code points cannot enter a native artifact.
    """
    if value is None:
        return None
    if type(value) is not str:  # bool and string subclasses are not accepted.
        raise SourceNoteError("source note must be a string or null")
    note = value.strip(_ASCII_EDGE_WHITESPACE)
    if not note:
        return None
    try:
        note.encode("utf-8", "strict")
    except UnicodeEncodeError as exc:
        raise SourceNoteError("source note must contain valid Unicode scalar values") from exc
    if len(note) > MAX_NOTE_CODEPOINTS:
        raise SourceNoteError(
            f"source note exceeds {MAX_NOTE_CODEPOINTS} Unicode code points"
        )
    return note


def canonicalize_direct_placement(placement: Mapping[str, Any]) -> dict[str, Any]:
    """Return a canonical copy and enforce relationship-level note ownership.

    The helper recognizes a placement as a source when ``kind == 'source'``.
    Non-source members may not carry ``note``.  Empty notes are omitted rather
    than serialized as empty strings or null.
    """
    if not isinstance(placement, Mapping):
        raise SourceNoteError("placement must be an object")
    result = dict(placement)
    if result.get("kind") != "source":
        if "note" in result:
            raise SourceNoteError("only a direct source placement may carry a note")
        return result
    if "note" in result:
        note = canonicalize_note(result["note"])
        if note is None:
            result.pop("note", None)
        else:
            result["note"] = note
    return result


def canonicalize_note_map(values: Mapping[str, Any] | None) -> dict[str, str | None]:
    """Canonicalize a placement-keyed note map used by three-way comparison."""
    if values is None:
        return {}
    if not isinstance(values, Mapping):
        raise SourceNoteError("note map must be an object")
    result: dict[str, str | None] = {}
    for key, value in values.items():
        if type(key) is not str or not key:
            raise SourceNoteError("every placement key must be a non-empty string")
        result[key] = canonicalize_note(value)
    return result


@dataclass(frozen=True)
class NoteConflict:
    placement: str
    base: str | None
    mine: str | None
    curator: str | None

    def as_dict(self) -> dict[str, str | None]:
        return {
            "placement": self.placement,
            "base": self.base,
            "mine": self.mine,
            "curator": self.curator,
        }


@dataclass(frozen=True)
class MergeResult:
    merged: dict[str, str]
    conflicts: tuple[NoteConflict, ...]
    complete: bool

    def as_dict(self) -> dict[str, Any]:
        return {
            "merged": dict(self.merged),
            "conflicts": [item.as_dict() for item in self.conflicts],
            "complete": self.complete,
        }


def _note_at(values: Mapping[str, str | None], key: str) -> str | None:
    # A missing key and an explicit null are the same canonical absence.
    value = values.get(key, _MISSING)
    return None if value is _MISSING else value


def merge_note_maps(
    base: Mapping[str, Any] | None,
    mine: Mapping[str, Any] | None,
    curator: Mapping[str, Any] | None,
    decisions: Mapping[str, str] | None = None,
) -> MergeResult:
    """Three-way merge direct-placement notes without an automatic winner.

    One-sided changes and identical two-sided changes are preserved.  A true
    divergence is returned as a conflict until its placement has an explicit
    ``keep_mine`` or ``use_curator`` decision.  Unresolved conflicting values
    are not put into ``merged``; callers must require ``complete`` before
    replacing a native artifact.
    """
    b = canonicalize_note_map(base)
    m = canonicalize_note_map(mine)
    c = canonicalize_note_map(curator)
    if decisions is None:
        d: Mapping[str, str] = {}
    elif not isinstance(decisions, Mapping):
        raise SourceNoteError("decisions must be an object")
    else:
        d = decisions

    unknown_decisions = set(d).difference(set(b) | set(m) | set(c))
    if unknown_decisions:
        raise SourceNoteError(
            "decision refers to an unknown placement: " + sorted(unknown_decisions)[0]
        )

    merged: dict[str, str] = {}
    conflicts: list[NoteConflict] = []
    used_decisions: set[str] = set()

    for key in sorted(set(b) | set(m) | set(c)):
        bv, mv, cv = _note_at(b, key), _note_at(m, key), _note_at(c, key)
        selected: str | None
        if mv == cv:
            selected = mv
        elif mv == bv:
            selected = cv
        elif cv == bv:
            selected = mv
        else:
            decision = d.get(key)
            if decision is None:
                conflicts.append(NoteConflict(key, bv, mv, cv))
                continue
            if decision not in _VALID_DECISIONS:
                raise SourceNoteError(
                    f"decision for {key!r} must be '{_KEEP_MINE}' or '{_USE_CURATOR}'"
                )
            used_decisions.add(key)
            selected = mv if decision == _KEEP_MINE else cv
        if selected is not None:
            merged[key] = selected

    stale_decisions = set(d).difference(used_decisions)
    if stale_decisions:
        raise SourceNoteError(
            "decision is stale because its placement is not divergent: "
            + sorted(stale_decisions)[0]
        )

    return MergeResult(merged, tuple(conflicts), not conflicts)


def opml_omission_report(
    notes: Mapping[str, Any] | None,
    included_placements: set[str] | None = None,
) -> dict[str, Any]:
    """Describe note data intentionally omitted by an OPML export.

    OPML output remains free of a ProgRSS-only note attribute.  The report is
    separate evidence for the sender and names only placements in the selected
    export branch when ``included_placements`` is supplied.
    """
    canonical = canonicalize_note_map(notes)
    keys = sorted(
        key
        for key, value in canonical.items()
        if value is not None and (included_placements is None or key in included_placements)
    )
    return {
        "format": "OPML",
        "sourceNotesIncluded": False,
        "omittedSourceNoteCount": len(keys),
        "omittedPlacements": keys,
    }
