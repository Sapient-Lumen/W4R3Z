from __future__ import annotations
import json
import pathlib
import sys
HERE = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from source_notes import canonicalize_note, merge_note_maps  # noqa: E402
fixtures = json.loads((HERE / "fixtures.json").read_text(encoding="utf-8"))
result = {
    "canonicalCases": [canonicalize_note(item["input"]) for item in fixtures["canonicalCases"]],
    "mergeCases": [
        merge_note_maps(item["base"], item["mine"], item["curator"], item["decisions"]).as_dict()
        for item in fixtures["mergeCases"]
    ],
}
print(json.dumps(result, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
