import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { canonicalizeNote, mergeNoteMaps } from "./source-notes.mjs";
const here = path.dirname(fileURLToPath(import.meta.url));
const fixtures = JSON.parse(fs.readFileSync(path.join(here, "fixtures.json"), "utf8"));
const result = {
  canonicalCases: fixtures.canonicalCases.map((item) => canonicalizeNote(item.input)),
  mergeCases: fixtures.mergeCases.map((item) =>
    mergeNoteMaps(item.base, item.mine, item.curator, item.decisions),
  ),
};
function canonicalJson(value) {
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (value !== null && typeof value === "object") {
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalJson(value[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}
console.log(canonicalJson(result));
