/** Reference contract for direct folder-to-source notes. */
export const MAX_NOTE_CODEPOINTS = 280;
const ASCII_EDGE_WHITESPACE = /^[ \t\r\n\f\v]+|[ \t\r\n\f\v]+$/g;
const VALID_DECISIONS = new Set(["keep_mine", "use_curator"]);

export class SourceNoteError extends Error {
  constructor(message) {
    super(message);
    this.name = "SourceNoteError";
  }
}

export function canonicalizeNote(value) {
  if (value === null || value === undefined) return null;
  if (typeof value !== "string") {
    throw new SourceNoteError("source note must be a string or null");
  }
  const note = value.replace(ASCII_EDGE_WHITESPACE, "");
  if (note.length === 0) return null;
  for (const character of note) {
    const point = character.codePointAt(0);
    if (point >= 0xd800 && point <= 0xdfff) {
      throw new SourceNoteError("source note must contain valid Unicode scalar values");
    }
  }
  if (Array.from(note).length > MAX_NOTE_CODEPOINTS) {
    throw new SourceNoteError(
      `source note exceeds ${MAX_NOTE_CODEPOINTS} Unicode code points`,
    );
  }
  return note;
}

export function canonicalizeDirectPlacement(placement) {
  if (placement === null || typeof placement !== "object" || Array.isArray(placement)) {
    throw new SourceNoteError("placement must be an object");
  }
  const result = { ...placement };
  if (result.kind !== "source") {
    if (Object.prototype.hasOwnProperty.call(result, "note")) {
      throw new SourceNoteError("only a direct source placement may carry a note");
    }
    return result;
  }
  if (Object.prototype.hasOwnProperty.call(result, "note")) {
    const note = canonicalizeNote(result.note);
    if (note === null) delete result.note;
    else result.note = note;
  }
  return result;
}

export function canonicalizeNoteMap(values) {
  if (values === null || values === undefined) return {};
  if (typeof values !== "object" || Array.isArray(values)) {
    throw new SourceNoteError("note map must be an object");
  }
  const result = {};
  for (const [key, value] of Object.entries(values)) {
    if (key.length === 0) {
      throw new SourceNoteError("every placement key must be a non-empty string");
    }
    result[key] = canonicalizeNote(value);
  }
  return result;
}

function noteAt(values, key) {
  return Object.prototype.hasOwnProperty.call(values, key) ? values[key] : null;
}

export function mergeNoteMaps(base, mine, curator, decisions = {}) {
  const b = canonicalizeNoteMap(base);
  const m = canonicalizeNoteMap(mine);
  const c = canonicalizeNoteMap(curator);
  if (decisions === null || typeof decisions !== "object" || Array.isArray(decisions)) {
    throw new SourceNoteError("decisions must be an object");
  }
  const keys = Array.from(new Set([...Object.keys(b), ...Object.keys(m), ...Object.keys(c)])).sort();
  for (const key of Object.keys(decisions)) {
    if (!keys.includes(key)) {
      throw new SourceNoteError(`decision refers to an unknown placement: ${key}`);
    }
  }

  const merged = {};
  const conflicts = [];
  const usedDecisions = new Set();
  for (const key of keys) {
    const bv = noteAt(b, key);
    const mv = noteAt(m, key);
    const cv = noteAt(c, key);
    let selected;
    if (mv === cv) selected = mv;
    else if (mv === bv) selected = cv;
    else if (cv === bv) selected = mv;
    else {
      const decision = decisions[key];
      if (decision === undefined) {
        conflicts.push({ placement: key, base: bv, mine: mv, curator: cv });
        continue;
      }
      if (!VALID_DECISIONS.has(decision)) {
        throw new SourceNoteError(
          `decision for ${JSON.stringify(key)} must be 'keep_mine' or 'use_curator'`,
        );
      }
      usedDecisions.add(key);
      selected = decision === "keep_mine" ? mv : cv;
    }
    if (selected !== null) merged[key] = selected;
  }

  for (const key of Object.keys(decisions)) {
    if (!usedDecisions.has(key)) {
      throw new SourceNoteError(
        `decision is stale because its placement is not divergent: ${key}`,
      );
    }
  }
  return { merged, conflicts, complete: conflicts.length === 0 };
}

export function opmlOmissionReport(notes, includedPlacements = null) {
  const canonical = canonicalizeNoteMap(notes);
  const included = includedPlacements === null ? null : new Set(includedPlacements);
  const keys = Object.keys(canonical)
    .filter((key) => canonical[key] !== null && (included === null || included.has(key)))
    .sort();
  return {
    format: "OPML",
    sourceNotesIncluded: false,
    omittedSourceNoteCount: keys.length,
    omittedPlacements: keys,
  };
}
