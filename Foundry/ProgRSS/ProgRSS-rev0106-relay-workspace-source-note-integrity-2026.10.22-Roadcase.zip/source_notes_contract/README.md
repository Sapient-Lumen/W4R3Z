# Source Notes update-continuity contract

This directory is the transport-neutral reference contract for one optional reason on one direct folder-to-source placement. It adds no permission, account, scheduling, pairing, discovery, notification, or network behavior.

`direct-placement.schema.json` records the relationship-level shape and 280-character bound. `fixtures.json` is shared by Python and JavaScript. `../tools/verify-source-notes-contract.sh` runs both suites and requires their canonical fixture output to be byte-identical.

## Three-way rule

For every direct placement, compare the previously received base, the recipient's current copy (`mine`), and the curator's later copy.

- Equal current values are retained.
- A curator-only change is retained.
- A recipient-only change is retained.
- Different changes from the same base remain unresolved.
- An unresolved value enters the merged artifact only after the recipient explicitly chooses **Keep mine** or **Use curator's**.

A missing value and an empty canonical value both mean “no reason.” Deletion versus an unchanged value is one-sided and safe; deletion versus a different edit is a conflict.

## OPML

No ProgRSS-specific Source Notes attribute is written into OPML. `opml_omission_report` produces separate, branch-scoped omission evidence instead.
