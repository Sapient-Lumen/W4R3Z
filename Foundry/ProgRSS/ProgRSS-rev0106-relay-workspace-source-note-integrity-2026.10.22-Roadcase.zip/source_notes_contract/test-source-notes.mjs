import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  SourceNoteError,
  canonicalizeDirectPlacement,
  canonicalizeNote,
  mergeNoteMaps,
  opmlOmissionReport,
} from "./source-notes.mjs";

const here = path.dirname(fileURLToPath(import.meta.url));
const fixtures = JSON.parse(fs.readFileSync(path.join(here, "fixtures.json"), "utf8"));

for (const item of fixtures.canonicalCases) {
  assert.deepEqual(canonicalizeNote(item.input), item.expected, item.name);
}
assert.equal(canonicalizeNote("🛰".repeat(280)), "🛰".repeat(280));
assert.throws(() => canonicalizeNote("🛰".repeat(281)), SourceNoteError);
assert.throws(() => canonicalizeNote(7), SourceNoteError);
assert.throws(() => canonicalizeNote("\ud800"), SourceNoteError);

assert.deepEqual(
  canonicalizeDirectPlacement({ kind: "source", id: "s", note: " why " }),
  { kind: "source", id: "s", note: "why" },
);
assert.deepEqual(
  canonicalizeDirectPlacement({ kind: "source", id: "s", note: "  " }),
  { kind: "source", id: "s" },
);
assert.throws(
  () => canonicalizeDirectPlacement({ kind: "folder", note: "wrong level" }),
  SourceNoteError,
);

for (const item of fixtures.mergeCases) {
  assert.deepEqual(
    mergeNoteMaps(item.base, item.mine, item.curator, item.decisions),
    item.expected,
    item.name,
  );
}
assert.throws(() => mergeNoteMaps({}, {}, {}, { missing: "keep_mine" }), SourceNoteError);
assert.throws(
  () => mergeNoteMaps({ p: "a" }, { p: "b" }, { p: "c" }, { p: "later" }),
  SourceNoteError,
);
assert.throws(
  () => mergeNoteMaps({ p: "a" }, { p: "a" }, { p: "b" }, { p: "use_curator" }),
  SourceNoteError,
);
assert.deepEqual(
  opmlOmissionReport(
    { "a/source": "A", "b/source": "B", empty: "  " },
    new Set(["b/source"]),
  ),
  {
    format: "OPML",
    sourceNotesIncluded: false,
    omittedSourceNoteCount: 1,
    omittedPlacements: ["b/source"],
  },
);
console.log(`source-notes JS contract: ${fixtures.mergeCases.length} merge fixtures passed`);
