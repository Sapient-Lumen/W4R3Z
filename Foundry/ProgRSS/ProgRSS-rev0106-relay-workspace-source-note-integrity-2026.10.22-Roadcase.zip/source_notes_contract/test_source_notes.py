from __future__ import annotations

import json
import pathlib
import sys
import unittest

HERE = pathlib.Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from source_notes import (  # noqa: E402
    SourceNoteError,
    canonicalize_direct_placement,
    canonicalize_note,
    merge_note_maps,
    opml_omission_report,
)


class SourceNotesContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.fixtures = json.loads((HERE / "fixtures.json").read_text(encoding="utf-8"))

    def test_schema_is_valid_json_and_expresses_the_limit(self) -> None:
        schema = json.loads((HERE / "direct-placement.schema.json").read_text(encoding="utf-8"))
        self.assertEqual(schema["properties"]["note"]["maxLength"], 280)
        self.assertEqual(schema["allOf"][0]["then"]["properties"]["kind"]["const"], "source")

    def test_fixture_canonicalization(self) -> None:
        for case in self.fixtures["canonicalCases"]:
            with self.subTest(case=case["name"]):
                self.assertEqual(canonicalize_note(case["input"]), case["expected"])

    def test_unicode_limit_counts_code_points(self) -> None:
        self.assertEqual(canonicalize_note("🛰" * 280), "🛰" * 280)
        with self.assertRaises(SourceNoteError):
            canonicalize_note("🛰" * 281)

    def test_invalid_type_and_surrogate_rejected(self) -> None:
        with self.assertRaises(SourceNoteError):
            canonicalize_note(7)
        with self.assertRaises(SourceNoteError):
            canonicalize_note("\ud800")

    def test_note_only_on_direct_source(self) -> None:
        self.assertEqual(
            canonicalize_direct_placement({"kind": "source", "id": "s", "note": " why "}),
            {"kind": "source", "id": "s", "note": "why"},
        )
        self.assertEqual(
            canonicalize_direct_placement({"kind": "source", "id": "s", "note": "  "}),
            {"kind": "source", "id": "s"},
        )
        with self.assertRaises(SourceNoteError):
            canonicalize_direct_placement({"kind": "folder", "note": "wrong level"})

    def test_merge_fixtures(self) -> None:
        for case in self.fixtures["mergeCases"]:
            with self.subTest(case=case["name"]):
                actual = merge_note_maps(
                    case["base"], case["mine"], case["curator"], case["decisions"]
                ).as_dict()
                self.assertEqual(actual, case["expected"])

    def test_stale_or_invalid_decision_rejected(self) -> None:
        with self.assertRaises(SourceNoteError):
            merge_note_maps({}, {}, {}, {"missing": "keep_mine"})
        with self.assertRaises(SourceNoteError):
            merge_note_maps({"p": "a"}, {"p": "b"}, {"p": "c"}, {"p": "later"})
        with self.assertRaises(SourceNoteError):
            merge_note_maps({"p": "a"}, {"p": "a"}, {"p": "b"}, {"p": "use_curator"})

    def test_opml_omission_report_is_branch_scoped(self) -> None:
        self.assertEqual(
            opml_omission_report(
                {"a/source": "A", "b/source": "B", "empty": "  "}, {"b/source"}
            ),
            {
                "format": "OPML",
                "sourceNotesIncluded": False,
                "omittedSourceNoteCount": 1,
                "omittedPlacements": ["b/source"],
            },
        )


if __name__ == "__main__":
    unittest.main()
