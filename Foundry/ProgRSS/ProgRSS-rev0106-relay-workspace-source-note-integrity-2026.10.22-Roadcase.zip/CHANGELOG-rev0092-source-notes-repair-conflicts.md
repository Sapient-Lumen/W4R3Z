# Changelog — rev0092 Source Notes repair conflicts

## Fixed

- Same-source history repair no longer chooses a direct placement reason by member order.
- One-sided and identical reasons are preserved deterministically; absence remains absence.
- Different nonempty reasons on the same direct folder placement block preview and commit with no automatic winner and no vault mutation.
- Separate-folder reasons remain independent.
- Commit revalidates the placement plan and stale reviewed revisions still refuse.
- The CLI combine path now applies the same placement rule.
- The side panel distinguishes a Source Notes decision from Advanced Workbench reference blockers.

## Evidence scope

The focused Chromium-source and generated-Firefox harnesses and the offline CLI suite exercise the production functions with browser API doubles or native files. Browser rendering smoke is managed automation. Installed then-current browsers, human permission prompts, unfamiliar participants, and real assistive technologies remain untested for this candidate.
