# ProgRSS rev0078 — Crossroads

**Observe the choice, not the person.**

Crossroads adds a second private Fieldbook scenario for the actual Exchange
recipient handoff. A facilitator can now study whether an unfamiliar recipient
distinguishes:

```text
Follow updates
Add the complete route
Take one branch
```

The sheet is generated from one exact active handoff and adapts when Follow or
branch adoption is unavailable. When all three doors are present it contains
fifteen goal-based tasks covering invitation scope, preview versus commit, the
three consequences, reused and paused sources, network effects, private-state
exclusion, expiry, revocation, and advanced evidence.

## Privacy boundary

The generated Fieldbook omits curator names, route titles and notes, source
names and hostnames, URLs, folder IDs and paths, library identity, Node origin
and fingerprint, Exchange ID, and invitation capability. It requests no
participant identity, performs no network request, uses no telemetry or browser
storage, saves nothing automatically, and performs no Node-library or store
write.

## Product boundary

Crossroads changes no sharing authority. Selecting a recipient door still
retrieves one bounded artifact for review before any later Follow or Add
decision. Review contacts none of the listed sources and creates no schedule.
Pairing remains separate, summary-only, read-only, and revocable.

## Interfaces

The authenticated Node exposes the Fieldbook under an active handoff's
**Research this recipient choice** disclosure. Offline parity is available as:

```sh
./progrss node exchange-fieldbook exchange-review.json \
  --output ProgRSS-Exchange-Fieldbook.html
```

Debrief continues to refuse mixed scenarios, releases, and task sequences.
Crossroads reports therefore cannot be combined with Trace/Bearing/Anchor
reports or with a differently shaped handoff.

## Verification

The release adds strict Fieldbook unit tests, active-handoff HTTP tests, CLI
new-file-only and privacy tests, complete rendered dark/light Fieldbook
interaction, local report export, and clean-delivery replay. Automated
completion verifies the research tool—not human comprehension.

Native unmanaged Chromium, Firefox, Firefox ESR, unfamiliar-recipient, and real
assistive-technology sessions remain explicitly not run.
