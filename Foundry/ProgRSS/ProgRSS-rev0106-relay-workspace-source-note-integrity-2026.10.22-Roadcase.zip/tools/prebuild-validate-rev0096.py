#!/usr/bin/env python3
"""Syntax, parity, provenance, and honest open-gate checks for rev0096."""
from __future__ import annotations

import ast
import importlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
old = importlib.import_module("prebuild-validate-rev0089")
REVISION = "rev0096-source-notes-workbench-preservation"
PARENT_SHA = "d1ff9b25af231829506ba73a2a72cb7633a11ab8130476b5be486c6df5411745"


def main() -> None:
    counts: dict[str, int] = {}
    for path in old.files(".json"):
        json.loads(path.read_text())
    counts["json"] = len(old.files(".json"))
    for path in old.files(".py"):
        ast.parse(path.read_text(), filename=str(path))
    counts["python"] = len(old.files(".py"))
    javascript = old.files(".js") + old.files(".mjs")
    for path in javascript:
        subprocess.run(["node", "--check", str(path)], check=True, capture_output=True, timeout=30)
    counts["javascript"] = len(javascript)
    for path in old.files(".html"):
        parser = old.Parser(convert_charrefs=True)
        parser.feed(path.read_text())
        parser.close()
    counts["html"] = len(old.files(".html"))
    for path in old.files(".css"):
        old.validate_css(path)
    counts["css"] = len(old.files(".css"))

    inherited = importlib.import_module("verify-rev0086-source-notes")
    inherited.verify_permissions()
    inherited.verify_generated_firefox()
    from source_notes_runtime_evidence import REVISION as runtime_revision, case_catalog

    state = json.loads((ROOT / "REVISION-STATE.json").read_text())
    provenance = json.loads((ROOT / "RECONSTRUCTION_PROVENANCE.json").read_text())
    assert state["revision"] == runtime_revision == provenance["reconstructionRevision"] == REVISION
    assert provenance["immediateParentSha256"] == PARENT_SHA
    assert not state["releaseGateClosed"]
    assert state["claims"]["productChanged"] and not state["claims"]["cliChanged"] and state["claims"]["extensionChanged"]
    assert not state["claims"]["permissionsExpanded"]
    for name in (
        "installedBrowserRuntimeThisTurn",
        "unmanagedChromiumRuntime",
        "firefoxReleaseRuntime",
        "firefoxEsrRuntime",
        "humanPermissionPromptObservation",
        "assistiveTechnologyFieldwork",
        "unfamiliarParticipantFieldwork",
        "policyModified",
    ):
        assert state["claims"][name] is False, name
    assert json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text()) == case_catalog()
    assert len(case_catalog()["cases"]) == 18
    assert (ROOT / "BOOTSTRAPROSE.md").read_text().startswith("# `/run` authority — rev0096")
    reproduction = json.loads((ROOT / "evidence/rev0096/parent-workbench-source-note-loss.json").read_text())
    assert reproduction["parentErasedAllReasonsInEditedCollection"] is True
    audit = json.loads((ROOT / "SOURCE-NOTES-WORKBENCH-PRESERVATION-AUDIT.json").read_text())
    assert audit["pass"] and audit["candidate"]["chromiumCases"] == 11 and audit["candidate"]["firefoxCases"] == 11
    matrix = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-MATRIX.json").read_text())
    assert matrix["revision"] == REVISION and not matrix["releaseGateClosed"]
    assert any(row["id"] == "workbench-collection-edit-preservation" and row["status"] == "pass" for row in matrix["rows"])
    entry = json.loads((ROOT / "SOURCE-NOTES-ENTRYPOINT-MATRIX.json").read_text())
    assert entry["revision"] == REVISION
    assert any(row["id"] == "workbench-collection-edit-preservation" and row["status"] == "pass" for row in entry["rows"])
    assert (ROOT / "Extension/workbench/scripts/progrss-app.js").read_bytes() == (ROOT / "Extension/Firefox/workbench/scripts/progrss-app.js").read_bytes()
    assert (ROOT / "Extension/background.js").read_bytes() == (ROOT / "Extension/Firefox/background.js").read_bytes()
    assert (ROOT / "Extension/sidepanel/app.js").read_bytes() == (ROOT / "Extension/Firefox/sidepanel/app.js").read_bytes()
    print(json.dumps({"pass": True, "revision": REVISION, "syntaxCounts": counts, "releaseGateClosed": False}, sort_keys=True))


if __name__ == "__main__":
    main()
