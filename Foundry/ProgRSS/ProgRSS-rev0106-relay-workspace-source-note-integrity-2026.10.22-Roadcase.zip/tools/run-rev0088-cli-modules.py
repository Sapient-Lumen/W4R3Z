#!/usr/bin/env python3
"""Run each shipped CLI test module independently for rev0088 evidence."""
from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "CLI"
OUT = ROOT / "evidence" / "rev0088"
MODULES = (
    "tests.test_acquisition",
    "tests.test_cadence",
    "tests.test_cli",
    "tests.test_command_line",
    "tests.test_debrief",
    "tests.test_fieldbook",
    "tests.test_node_server",
    "tests.test_node_store",
    "tests.test_relay",
    "tests.test_roadcase",
    "tests.test_source_notes_entrypoints",
)


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, object]] = []
    for module in MODULES:
        log_name = "cli-" + module.removeprefix("tests.").replace(".", "_") + ".log"
        started = time.monotonic()
        try:
            result = subprocess.run(
                [sys.executable, "-m", "unittest", "-v", module],
                cwd=CLI,
                text=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                timeout=600,
                check=False,
            )
            output = result.stdout
            returncode = result.returncode
        except subprocess.TimeoutExpired as error:
            output = (error.stdout or "") + "\nTIMEOUT\n"
            returncode = 124
        seconds = round(time.monotonic() - started, 3)
        (OUT / log_name).write_text(output, encoding="utf-8")
        row = {
            "module": module,
            "log": log_name,
            "returncode": returncode,
            "seconds": seconds,
            "state": "pass" if returncode == 0 else "fail",
        }
        rows.append(row)
        print(json.dumps(row, sort_keys=True), flush=True)
        if returncode != 0:
            break
    summary = {
        "schema": "progrss.test-module-summary.v1",
        "revision": "rev0088-source-notes-runtime-evidence",
        "generatedUtc": "2026-10-21T00:00:00Z",
        "allPassed": len(rows) == len(MODULES) and all(row["returncode"] == 0 for row in rows),
        "results": rows,
    }
    (OUT / "cli-modules-summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    return 0 if summary["allPassed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
