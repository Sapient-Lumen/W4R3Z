#!/usr/bin/env python3
"""Focused rev0094 native/managed gate; not target-host runtime acceptance."""
from __future__ import annotations
import importlib, json, os, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0094-source-notes-saturated-add-undo"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"


def run(label: str, command: list[str], extra: dict[str, str] | None = None) -> None:
    print(f"\n== {label} ==", flush=True)
    completed = subprocess.run(
        command, cwd=ROOT, env=dict(os.environ, **(extra or {})), text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=420,
    )
    print(completed.stdout.rstrip(), flush=True)
    if completed.returncode:
        raise RuntimeError(f"{label}: exit {completed.returncode}")


def main() -> None:
    run("cross-runtime Source Notes contract", ["sh", "tools/verify-source-notes-contract.sh"])
    run("native placement, CLI authoring, and repair semantics", [
        sys.executable, "-m", "unittest", "-v",
        "CLI.tests.test_source_notes_entrypoints", "CLI.tests.test_source_repair_notes",
        "CLI.tests.test_command_line.CommandLineTests.test_workspace_source_note_edits_one_direct_placement_offline",
    ])
    run("Node reviewed branch and merge", [
        sys.executable, "-m", "unittest", "-v",
        "CLI.tests.test_node_server.NodeServerTests.test_node_owned_branch_operation_is_reviewed_atomic_idempotent_and_snapshot_backed",
        "CLI.tests.test_node_server.NodeServerTests.test_merge_review_is_three_way_read_only_and_requires_admin_origin",
    ])
    for family in ("", "Firefox"):
        env = {"PROGRSS_EXTENSION_ROOT": family} if family else {}
        label = family or "Chromium-source"
        for harness in (
            "source_notes_saturated_concurrency_harness.js",
            "source_notes_folder_undo_harness.js",
            "source_notes_source_repair_harness.js",
            "source_notes_entrypoints_harness.js",
        ):
            run(f"{label} {harness}", ["node", f"Extension/tests/{harness}"], env)
    run("production background continuity", ["node", "Extension/tests/background_harness.js"])
    run("saturated folder-add Undo audit", [sys.executable, "tools/audit-source-notes-saturated-add-undo.py"])

    sys.path.insert(0, str(ROOT / "tools"))
    inherited = importlib.import_module("verify-rev0086-source-notes")
    inherited.verify_permissions()
    inherited.verify_generated_firefox()
    from source_notes_runtime_evidence import REVISION as runtime_revision, case_catalog

    assert runtime_revision == REVISION
    assert json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text()) == case_catalog()
    assert len(case_catalog()["cases"]) == 18
    undo_case = next(row for row in case_catalog()["cases"] if row["id"] == "two-view-stale-undo-refused")
    assert "folder-add undo" in undo_case["description"].lower()
    state = json.loads((ROOT / "REVISION-STATE.json").read_text())
    assert state["revision"] == REVISION and not state["releaseGateClosed"]
    assert not state["claims"]["installedBrowserRuntimeThisTurn"]
    repro = json.loads((ROOT / "evidence/rev0094/saturated-add-undo-reproduction.json").read_text())
    assert repro["parentAcceptedStaleAddUndo"] is True
    assert repro["parentDeletedReplacementReason"] is True
    assert repro["candidateRefusedStaleAddUndo"] is True
    assert repro["candidatePreservedReplacementReason"] is True
    audit = json.loads((ROOT / "SOURCE-NOTES-SATURATED-ADD-UNDO-AUDIT.json").read_text())
    assert audit["pass"] is True and audit["candidate"]["chromiumCases"] == 28 and audit["candidate"]["firefoxCases"] == 28
    assert (ROOT / "Extension/background.js").read_bytes() == (ROOT / "Extension/Firefox/background.js").read_bytes()
    assert (ROOT / "Extension/sidepanel/app.js").read_bytes() == (ROOT / "Extension/Firefox/sidepanel/app.js").read_bytes()
    print("\nPASS focused saturated folder-add Undo gate.")
    print("Installed browsers, unmanaged current channels, participants and real AT: NOT RUN.")


if __name__ == "__main__":
    try:
        main()
    except (AssertionError, RuntimeError, OSError, subprocess.SubprocessError) as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)
