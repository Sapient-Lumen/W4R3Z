#!/usr/bin/env python3
"""Offline integration replay; does not execute an installed browser or recruit people."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REVISION = 'rev0099-unified-baseline'
sys.dont_write_bytecode = True
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'


def run(label: str, command: list[str], timeout: int = 600) -> None:
    print(f'\n== {label} ==', flush=True)
    result = subprocess.run(command, cwd=ROOT, env=dict(os.environ), text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
    print(result.stdout.rstrip(), flush=True)
    if result.returncode:
        raise RuntimeError(f'{label} failed with exit {result.returncode}')


def main() -> None:
    sys.path.insert(0, str(ROOT / 'tools'))
    from source_notes_runtime_evidence import case_catalog, SESSION_SCHEMA, RESULT_SCHEMA
    audit = json.loads((ROOT / 'INTEGRATION-AUDIT.json').read_text())
    assert audit['revision'] == REVISION
    assert audit['baselineReuploadByteIdentical'] is True
    assert not audit['rev0080ToRev0098']['missingBaselineFiles']
    assert (ROOT / 'REVISION').read_text().strip() == REVISION
    expected = audit['productContinuity']['files']
    expected_paths = {row['path'] for row in expected}
    actual_paths = {p.relative_to(ROOT).as_posix() for name in ('CLI', 'Extension')
                    for p in (ROOT / name).rglob('*') if p.is_file()}
    assert actual_paths == expected_paths, 'product file inventory changed'
    for row in expected:
        path = ROOT / row['path']
        assert not path.is_symlink(), row['path']
        assert len(path.read_bytes()) == row['bytes'], row['path']
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256'], row['path']
        assert oct(stat.S_IMODE(path.stat().st_mode)) == row['mode'], row['path']
    catalog = case_catalog()
    earlier = json.loads((ROOT / 'history/rev0098-SOURCE-NOTES-RUNTIME-CASES.json').read_text())
    assert catalog['cases'] == earlier['cases'] and len(catalog['cases']) == 18
    assert json.loads((ROOT / 'SOURCE-NOTES-RUNTIME-CASES.json').read_text()) == catalog
    assert SESSION_SCHEMA.endswith('.v5') and RESULT_SCHEMA.endswith('.v3')
    state = json.loads((ROOT / 'REVISION-STATE.json').read_text())
    assert state['revision'] == REVISION and state['releaseGateClosed'] is False
    print(f'PASS exact product continuity: {len(expected)} files; 18 case objects retained.')
    run('runtime-record and verified-comparison suites', [sys.executable, '-m', 'unittest', '-v',
        'tests.test_source_notes_runtime_evidence', 'tests.test_verified_runtime_comparison'])
    run('cross-runtime Source Notes contract', ['sh', 'tools/verify-source-notes-contract.sh'])
    print('\nPASS unified offline integration gate. Installed-browser and human gates remain open.')


if __name__ == '__main__':
    try:
        main()
    except (AssertionError, RuntimeError, OSError, subprocess.SubprocessError) as exc:
        print(f'Integration verification failed: {exc}', file=sys.stderr)
        raise SystemExit(1)
