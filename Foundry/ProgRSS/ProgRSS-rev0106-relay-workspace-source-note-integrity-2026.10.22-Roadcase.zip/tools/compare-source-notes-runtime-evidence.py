#!/usr/bin/env python3
"""Compare verified Source Notes bundles, never standalone attestations."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import zipfile

from source_notes_runtime_evidence import EvidenceError, canonical_json_bytes, compare_evidence_bundles


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("bundles", nargs="+", type=Path, help="Finalized evidence ZIPs; JSON attestations are refused")
    parser.add_argument("--roadcase", type=Path, required=True, help="The same immutable Roadcase used by every session")
    parser.add_argument("--require-browser-triad", action="store_true", help="Require exactly Chromium Stable, Firefox Release, and Firefox ESR")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        root = Path(__file__).resolve().parents[1]
        report = compare_evidence_bundles(args.bundles, roadcase=args.roadcase,
                                         verifier=root / "VERIFY-ROADCASE.py",
                                         require_browser_triad=args.require_browser_triad)
        if args.output:
            output = args.output.resolve()
            # Never overwrite an input while writing a comparison.
            if output in {path.resolve() for path in [args.roadcase, *args.bundles]}:
                raise EvidenceError("comparison output must not overwrite an input")
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(canonical_json_bytes(report))
        print(json.dumps(report, ensure_ascii=False, sort_keys=True))
        return 0
    except (EvidenceError, OSError, ValueError, zipfile.BadZipFile) as error:
        print(f"runtime evidence comparison failed: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
