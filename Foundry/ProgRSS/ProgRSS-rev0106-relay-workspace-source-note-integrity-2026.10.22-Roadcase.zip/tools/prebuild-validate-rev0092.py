#!/usr/bin/env python3
"""Syntax, generated parity, permission, provenance, and honest open-gate checks."""
from __future__ import annotations
import ast, importlib, json, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
old=importlib.import_module('prebuild-validate-rev0089')
REVISION='rev0092-source-notes-repair-conflicts'
PARENT_SHA='2a58435db0de8b63026ebad577901cea49674b373b3888e0afe13f63a8b7e57e'
def main():
    counts={}
    for path in old.files('.json'): json.loads(path.read_text())
    counts['json']=len(old.files('.json'))
    for path in old.files('.py'): ast.parse(path.read_text(),filename=str(path))
    counts['python']=len(old.files('.py'))
    js=old.files('.js')+old.files('.mjs')
    for path in js: subprocess.run(['node','--check',str(path)],check=True,capture_output=True,timeout=30)
    counts['javascript']=len(js)
    for path in old.files('.html'):
        parser=old.Parser(convert_charrefs=True); parser.feed(path.read_text()); parser.close()
    counts['html']=len(old.files('.html'))
    for path in old.files('.css'): old.validate_css(path)
    counts['css']=len(old.files('.css'))
    inherited=importlib.import_module('verify-rev0086-source-notes')
    inherited.verify_permissions(); inherited.verify_generated_firefox()
    from source_notes_runtime_evidence import REVISION as runtime_revision,case_catalog
    state=json.loads((ROOT/'REVISION-STATE.json').read_text())
    provenance=json.loads((ROOT/'RECONSTRUCTION_PROVENANCE.json').read_text())
    assert state['revision']==runtime_revision==provenance['reconstructionRevision']==REVISION
    assert provenance['immediateParentSha256']==PARENT_SHA
    assert not state['releaseGateClosed']
    assert state['claims']['productChanged'] and state['claims']['cliChanged']
    assert not state['claims']['permissionsExpanded']
    for name in ('installedBrowserRuntimeThisTurn','unmanagedChromiumRuntime','firefoxReleaseRuntime','firefoxEsrRuntime','humanPermissionPromptObservation','assistiveTechnologyFieldwork','unfamiliarParticipantFieldwork','policyModified'):
        assert state['claims'][name] is False,name
    assert json.loads((ROOT/'SOURCE-NOTES-RUNTIME-CASES.json').read_text())==case_catalog()
    assert len(case_catalog()['cases'])==18
    assert (ROOT/'BOOTSTRAPROSE.md').read_text().startswith('# `/run` authority — rev0092')
    closed=json.loads((ROOT/'evidence/rev0092/source-repair-closed-reproduction.json').read_text())
    assert closed['status']=='CLOSED_REFUSED_NO_MUTATION' and closed['stateUnchanged']
    assert (ROOT/'Extension/background.js').read_bytes()==(ROOT/'Extension/Firefox/background.js').read_bytes()
    assert (ROOT/'Extension/sidepanel/app.js').read_bytes()==(ROOT/'Extension/Firefox/sidepanel/app.js').read_bytes()
    print(json.dumps({'pass':True,'revision':REVISION,'syntaxCounts':counts,'releaseGateClosed':False},sort_keys=True))
if __name__=='__main__': main()
