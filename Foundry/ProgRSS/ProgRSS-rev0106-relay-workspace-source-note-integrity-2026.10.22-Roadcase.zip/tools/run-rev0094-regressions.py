#!/usr/bin/env python3
"""Run rev0094 offline/native and managed browser-API regressions.

This driver records managed regression evidence. It never classifies the result as
installed-browser, target-host, participant, or assistive-technology acceptance.
"""
from __future__ import annotations
import json, os, re, subprocess, sys, time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'evidence'/'rev0094'
OUT.mkdir(parents=True,exist_ok=True)
ENV=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
rows=[]
modules=['test_acquisition','test_cadence','test_cli','test_command_line','test_debrief','test_fieldbook','test_node_server','test_node_store','test_relay','test_roadcase','test_source_notes_entrypoints','test_source_repair_notes']
commands=[('cli-'+m,[sys.executable,'-m','unittest','-v','CLI.tests.'+m],ROOT,{}) for m in modules]
commands += [('extension-static',[sys.executable,'-m','unittest','discover','-s','tests','-p','test_*.py','-v'],ROOT/'Extension',{})]
for name in ['background_harness','relay_core_harness','source_notes_entrypoints_harness','firefox_background_harness','acquisition_harness','vault_conflict_harness','source_notes_folder_undo_harness','source_notes_source_repair_harness','source_notes_saturated_concurrency_harness']:
    commands.append((name,['node','Extension/tests/'+name+'.js'],ROOT,{}))
for name in ['source_notes_entrypoints_harness','source_notes_folder_undo_harness','source_notes_source_repair_harness','source_notes_saturated_concurrency_harness']:
    commands.append((name+'-firefox',['node','Extension/tests/'+name+'.js'],ROOT,{'PROGRSS_EXTENSION_ROOT':'Firefox'}))
commands += [
    ('browser_smoke',[sys.executable,'Extension/tests/browser_smoke.py'],ROOT,{}),
    ('extension-complete',['sh','tests/run.sh'],ROOT/'Extension',{}),
    ('contract',['sh','tools/verify-source-notes-contract.sh'],ROOT,{}),
    ('evidence-boundary',[sys.executable,'-m','unittest','-v','tests.test_source_notes_runtime_evidence','tests.test_verified_runtime_comparison'],ROOT,{}),
]
for label,cmd,cwd,extra in commands:
    started=time.monotonic(); log=OUT/(label+'.log')
    with log.open('w',encoding='utf-8') as handle:
        try:
            cp=subprocess.run(cmd,cwd=cwd,env=dict(ENV,**extra),stdout=handle,stderr=subprocess.STDOUT,timeout=900)
            code=cp.returncode
        except subprocess.TimeoutExpired:
            code=124; handle.write('\nTIMEOUT (not a pass)\n')
    text=log.read_text(encoding='utf-8',errors='replace')
    matches=re.findall(r'Ran (\d+) tests?',text)
    row={'label':label,'command':cmd,'returncode':code,'seconds':round(time.monotonic()-started,3),'tests':int(matches[-1]) if matches else None,'log':log.name}
    rows.append(row); print(json.dumps(row,ensure_ascii=False),flush=True)
    (OUT/'regression-status.json').write_text(json.dumps({'complete':False,'rows':rows},ensure_ascii=False,sort_keys=True,indent=2)+'\n')
summary={
    'complete':True,
    'allPassed':all(r['returncode']==0 for r in rows),
    'rows':rows,
    'browserAutomationExecuted':True,
    'browserAutomationScope':'managed rendering/interaction smoke; not installed-browser acceptance',
    'installedBrowserRuntimeExecuted':False,
}
(OUT/'regression-status.json').write_text(json.dumps(summary,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
if not summary['allPassed']:
    raise SystemExit(1)
