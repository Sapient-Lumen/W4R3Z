#!/usr/bin/env python3
"""Produce conservative static evidence; strings never count as behavioral proof."""
from __future__ import annotations
import json
from pathlib import Path
import re
import sys

ROOT=Path(__file__).resolve().parents[1]
BASE_WRAPPER=Path('/mnt/data/progrss_rev80_work')
boots=list(BASE_WRAPPER.rglob('BOOTSTRAPROSE.md'))
BASE=boots[0].parent if boots else BASE_WRAPPER
OUT=Path('/mnt/data/progrss-logs'); OUT.mkdir(parents=True,exist_ok=True)
EXCLUDE={'source_notes_contract','fieldwork','.git','node_modules','__pycache__'}
EXT={'.py','.js','.mjs','.cjs','.html','.json','.md','.sh','.css'}

def sources(root):
    for p in root.rglob('*'):
        if not p.is_file() or p.suffix.lower() not in EXT or p.stat().st_size>3_000_000: continue
        rel=p.relative_to(root)
        if any(part in EXCLUDE for part in rel.parts): continue
        if p.name in {'BOOTSTRAPROSE.md','RECONSTRUCTION_PROVENANCE.md','RECONSTRUCTION_PROVENANCE.json'}: continue
        try: text=p.read_text(encoding='utf-8',errors='replace')
        except OSError: continue
        yield rel.as_posix(),text

files=list(sources(ROOT))
checks={
 'relationshipField': [r'\bsource\s*note',r'\bsource_note',r'["\']note["\']'],
 'limit280': [r'\b280\b'],
 'pythonValidation': [r'def\s+[^\n]*(?:note|reason)',r'python'],
 'javascriptValidation': [r'function\s+[^\n]*(?:note|reason)|(?:note|reason)\s*=>',r'javascript|\.js'],
 'nativeCanonicalization': [r'canonical',r'note|reason'],
 'integrityCoverage': [r'digest|sha-?256|sign|integrity',r'note|reason'],
 'nodeAuthoring': [r'node',r'note|reason',r'input|textarea|author'],
 'completeRouteDisclosure': [r'complete|full|route',r'recipient|disclos',r'note|reason'],
 'branchDisclosure': [r'branch',r'recipient|disclos|report',r'note|reason'],
 'opmlOmission': [r'opml',r'omitt|not included|excluded',r'note|reason'],
 'threeWayComparison': [r'three[- ]way|\bbase\b',r'curator',r'mine|recipient'],
 'explicitConflictChoice': [r'keep mine|keep_mine',r'use curator|use_curator'],
 'firefoxSibling': [r'firefox|gecko',r'manifest|extension'],
}

def match_group(text,patterns): return all(re.search(pattern,text,re.I|re.S) for pattern in patterns)
result={}
for name,patterns in checks.items():
    paths=[path for path,text in files if match_group(text,patterns)]
    result[name]={'status':'candidate-evidence-found' if paths else 'not-established','paths':paths[:50]}

# Browser manifest permission delta: exact structured comparison where paths align.
def manifests(root):
    out={}
    for p in root.rglob('manifest.json'):
        if any(part in {'.git','node_modules','__pycache__'} for part in p.relative_to(root).parts): continue
        try: data=json.loads(p.read_text(encoding='utf-8'))
        except Exception: continue
        rel=p.relative_to(root).as_posix()
        out[rel]={key:data.get(key,[]) for key in ('permissions','optional_permissions','host_permissions','optional_host_permissions')}
    return out
wm=manifests(ROOT); bm=manifests(BASE)
manifest_comparisons=[]
for rel,current in sorted(wm.items()):
    baseline=bm.get(rel)
    manifest_comparisons.append({'path':rel,'baselineFound':baseline is not None,'unchanged':baseline==current if baseline is not None else None,'baseline':baseline,'current':current})

report={
 'classification':'Conservative static audit. Candidate evidence paths require dynamic replay; missing strings do not prove missing behavior.',
 'root':str(ROOT),
 'baseline':str(BASE),
 'nativeFilesScanned':len(files),
 'checks':result,
 'browserManifestPermissionComparisons':manifest_comparisons,
}
(OUT/'source-notes-integration-audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
with (OUT/'source-notes-integration-audit.md').open('w',encoding='utf-8') as f:
    f.write('# Source Notes integration audit\n\n')
    f.write(f"**Classification:** {report['classification']}\n\n")
    f.write(f"Native project files scanned (contract, harness, and authority docs excluded): {len(files)}\n\n")
    for name,item in result.items():
        f.write(f"- **{name}:** {item['status']}")
        if item['paths']: f.write(' — '+', '.join(f'`{p}`' for p in item['paths'][:8]))
        f.write('\n')
    f.write('\n## Browser manifest permission comparison\n\n')
    if not manifest_comparisons: f.write('No parseable browser manifest was found.\n')
    for item in manifest_comparisons:
        if not item['baselineFound']: state='no same-path baseline; manual mapping required'
        else: state='unchanged' if item['unchanged'] else 'CHANGED—review required'
        f.write(f"- `{item['path']}`: {state}\n")
print(json.dumps({'nativeFilesScanned':len(files),'candidateChecks':sum(x['status']=='candidate-evidence-found' for x in result.values()),'totalChecks':len(result)}))
