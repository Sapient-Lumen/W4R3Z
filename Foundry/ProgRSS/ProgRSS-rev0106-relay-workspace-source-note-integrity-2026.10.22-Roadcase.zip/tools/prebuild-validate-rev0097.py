#!/usr/bin/env python3
"""Syntax, parity, provenance, and honest open-gate checks for rev0097."""
from __future__ import annotations

import ast
import importlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
old = importlib.import_module("prebuild-validate-rev0089")
REVISION = "rev0097-source-notes-lineage-preservation"
PARENT_SHA = "ba96be5d2e94b8237e4373bb5fd01ee555094826dd667b9d6252e01312fe6684"


def main() -> None:
    counts: dict[str, int] = {}
    for path in old.files(".json"):
        json.loads(path.read_text())
    counts["json"] = len(old.files(".json"))
    for path in old.files(".py"):
        ast.parse(path.read_text(), filename=str(path))
    counts["python"] = len(old.files(".py"))
    javascript = old.files(".js") + old.files(".mjs")
    for path in javascript:
        subprocess.run(["node", "--check", str(path)], check=True, capture_output=True, timeout=30)
    counts["javascript"] = len(javascript)
    for path in old.files(".html"):
        parser = old.Parser(convert_charrefs=True)
        parser.feed(path.read_text())
        parser.close()
    counts["html"] = len(old.files(".html"))
    for path in old.files(".css"):
        old.validate_css(path)
    counts["css"] = len(old.files(".css"))

    inherited = importlib.import_module("verify-rev0086-source-notes")
    inherited.verify_permissions()
    inherited.verify_generated_firefox()
    from source_notes_runtime_evidence import REVISION as runtime_revision, case_catalog

    state = json.loads((ROOT / "REVISION-STATE.json").read_text())
    provenance = json.loads((ROOT / "RECONSTRUCTION_PROVENANCE.json").read_text())
    assert state["revision"] == runtime_revision == provenance["reconstructionRevision"] == REVISION
    assert provenance["immediateParentSha256"] == PARENT_SHA
    assert not state["releaseGateClosed"]
    assert state["claims"]["productChanged"] and not state["claims"]["cliChanged"] and state["claims"]["extensionChanged"]
    assert not state["claims"]["permissionsExpanded"]
    for name in (
        "installedBrowserRuntimeThisTurn",
        "unmanagedChromiumRuntime",
        "firefoxReleaseRuntime",
        "firefoxEsrRuntime",
        "humanPermissionPromptObservation",
        "assistiveTechnologyFieldwork",
        "unfamiliarParticipantFieldwork",
        "policyModified",
    ):
        assert state["claims"][name] is False, name
    assert json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text()) == case_catalog()
    assert len(case_catalog()["cases"]) == 18
    assert (ROOT / "BOOTSTRAPROSE.md").read_text().startswith("# `/run` authority — rev0097")
    reproduction = json.loads((ROOT / "evidence/rev0097/parent-lineage-source-note-loss.json").read_text())
    assert reproduction["parentPreviewDroppedReason"] is True
    assert reproduction["parentAppliedDroppedReason"] is True
    audit = json.loads((ROOT / "SOURCE-NOTES-LINEAGE-PRESERVATION-AUDIT.json").read_text())
    assert audit["pass"]
    assert audit["candidate"]["nativeChromiumCases"] == audit["candidate"]["nativeFirefoxCases"] == 11
    assert audit["candidate"]["workbenchChromiumCases"] == audit["candidate"]["workbenchFirefoxCases"] == 4
    matrix = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-MATRIX.json").read_text())
    assert matrix["revision"] == REVISION and not matrix["releaseGateClosed"]
    assert any(row["id"] == "lineage-edition-preservation-and-conflicts" and row["status"] == "pass" for row in matrix["rows"])
    entry = json.loads((ROOT / "SOURCE-NOTES-ENTRYPOINT-MATRIX.json").read_text())
    assert entry["revision"] == REVISION
    assert any(row["id"] == "lineage-edition-placement-preservation" and row["status"] == "pass" for row in entry["rows"])
    assert any(row["id"] == "lineage-source-note-three-way-conflict" and row["status"] == "pass" for row in entry["rows"])
    for relative in (
        "workbench/scripts/progrss-lineage.js",
        "workbench/scripts/progrss-app.js",
        "workbench/index.html",
        "workbench/styles/workbench-1.css",
    ):
        assert (ROOT / "Extension" / relative).read_bytes() == (ROOT / "Extension" / "Firefox" / relative).read_bytes(), relative
    assert (ROOT / "Extension/background.js").read_bytes() == (ROOT / "Extension/Firefox/background.js").read_bytes()
    assert (ROOT / "Extension/sidepanel/app.js").read_bytes() == (ROOT / "Extension/Firefox/sidepanel/app.js").read_bytes()
    print(json.dumps({"pass": True, "revision": REVISION, "syntaxCounts": counts, "releaseGateClosed": False}, sort_keys=True))


if __name__ == "__main__":
    main()
