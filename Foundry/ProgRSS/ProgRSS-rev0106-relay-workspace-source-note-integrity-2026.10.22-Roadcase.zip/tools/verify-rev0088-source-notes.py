#!/usr/bin/env python3
"""Replay the bounded rev0088 Source Notes runtime-evidence gate.

This focused gate replays the Source Notes contract, shipped placement paths,
new evidence boundary, and static claim limits. The complete CLI and Extension
suites are separate frozen evidence and prebuild gates. Nothing here claims a
current or unmanaged browser, Firefox runtime, human permission observation,
accessibility conformance, assistive technology, or participant fieldwork.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
from typing import Sequence

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0088-source-notes-runtime-evidence"


def run(name: str, command: Sequence[str], *, timeout: int = 420, env: dict[str, str] | None = None) -> None:
    print(f"\n== {name} ==")
    completed = subprocess.run(
        list(command),
        cwd=ROOT,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        check=False,
    )
    if completed.stdout:
        print(completed.stdout.rstrip())
    if completed.returncode:
        raise RuntimeError(f"{name} failed with exit status {completed.returncode}")


def verify_inherited_boundaries() -> None:
    sys.path.insert(0, str(ROOT / "tools"))
    import importlib

    inherited = importlib.import_module("verify-rev0086-source-notes")
    inherited.verify_permissions()
    inherited.verify_generated_firefox()
    inherited.verify_authoring_surface_markers()


def verify_frozen_suite_evidence() -> None:
    cli = json.loads((ROOT / "evidence" / "rev0088" / "cli-modules-summary.json").read_text(encoding="utf-8"))
    if cli.get("allPassed") is not True or len(cli.get("results", [])) != 11:
        raise RuntimeError("frozen rev0088 CLI module evidence is incomplete")
    if any(row.get("returncode") != 0 for row in cli["results"]):
        raise RuntimeError("a frozen rev0088 CLI module failed")

    extension_log = (ROOT / "evidence" / "rev0088" / "extension-tests.log").read_text(encoding="utf-8")
    required = (
        "Ran 60 tests",
        "PASS background harness",
        "PASS Source Notes browser entrypoint harness (Chromium source)",
        "PASS Source Notes browser entrypoint harness (Firefox)",
        "PASS Firefox background harness",
        "PASS side panel:",
        "PASS workbench:",
    )
    missing = [marker for marker in required if marker not in extension_log]
    if missing:
        raise RuntimeError("frozen rev0088 Extension evidence is incomplete: " + ", ".join(missing))
    print("frozen full-suite evidence: 11 CLI modules and complete Extension runner PASS")


def verify_catalog_and_claim_boundary() -> None:
    sys.path.insert(0, str(ROOT / "tools"))
    from source_notes_runtime_evidence import canonical_json_bytes, case_catalog, sha256_bytes  # type: ignore

    catalog_path = ROOT / "SOURCE-NOTES-RUNTIME-CASES.json"
    catalog = json.loads(catalog_path.read_text(encoding="utf-8"))
    assert catalog == case_catalog()
    assert len(catalog["cases"]) == 18
    ids = [row["id"] for row in catalog["cases"]]
    assert len(ids) == len(set(ids))
    assert "divergent-later-copy-keep-mine" in ids
    assert "divergent-later-copy-use-curator" in ids

    audit = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.json").read_text(encoding="utf-8"))
    matrix = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-MATRIX.json").read_text(encoding="utf-8"))
    acquisition = json.loads((ROOT / "evidence" / "rev0088" / "current-browser-acquisition.json").read_text(encoding="utf-8"))
    assert audit["pass"] is True and audit["releaseGateClosed"] is False
    assert matrix["releaseGateClosed"] is False
    statuses = {row["id"]: row["status"] for row in matrix["rows"]}
    assert statuses["runtime-evidence-finalizer-and-verifier"] == "pass"
    assert statuses["current-chromium-managed-acquisition"] == "blocked"
    for identifier in (
        "exact-final-roadcase-managed-preflight",
        "unmanaged-current-chromium",
        "firefox-release",
        "firefox-esr",
        "unfamiliar-person-and-assistive-technology-fieldwork",
    ):
        assert statuses[identifier] == "not-run", (identifier, statuses[identifier])
    assert acquisition["substitutionMade"] is False
    assert all(value is False for value in acquisition["claims"].values())

    common = (ROOT / "tools" / "source_notes_runtime_evidence.py").read_text(encoding="utf-8")
    for marker in (
        '"unmanagedBrowserAcceptance": False',
        '"currentStableAcceptance": False',
        '"humanPermissionPromptObservationAccepted": False',
        '"accessibilityConformance": False',
        '"assistiveTechnologyEvidence": False',
        '"unfamiliarPersonComprehension": False',
        '"unsigned": True',
        '"comparisonClosesRuntimeRow": False',
        "verify_package_against_roadcase",
        "must exactly match the fixed rev0088 catalog",
        "not-run case must have no timestamp, observation, or evidence",
    ):
        assert marker in common, marker
    print(f"fixed case catalog: 18 cases, sha256={sha256_bytes(canonical_json_bytes(catalog))}")
    print("runtime-evidence claim boundary: fail-closed and release gate remains open")


def main() -> int:
    try:
        run("cross-runtime reference contract", ["sh", "tools/verify-source-notes-contract.sh"])
        run(
            "Python shipped-entrypoint corpus",
            [sys.executable, "-m", "unittest", "-v", "CLI.tests.test_source_notes_entrypoints"],
        )
        run(
            "CLI shipped placement-authoring command",
            [
                sys.executable,
                "-m",
                "unittest",
                "-v",
                "CLI.tests.test_command_line.CommandLineTests.test_workspace_source_note_edits_one_direct_placement_offline",
            ],
            timeout=300,
        )
        run(
            "Node branch and merge-review paths",
            [
                sys.executable,
                "-m",
                "unittest",
                "-v",
                "CLI.tests.test_node_server.NodeServerTests.test_node_owned_branch_operation_is_reviewed_atomic_idempotent_and_snapshot_backed",
                "CLI.tests.test_node_server.NodeServerTests.test_merge_review_is_three_way_read_only_and_requires_admin_origin",
            ],
        )
        run("Chromium-source browser core", ["node", "Extension/tests/source_notes_entrypoints_harness.js"])
        firefox_env = dict(os.environ)
        firefox_env["PROGRSS_EXTENSION_ROOT"] = "Firefox"
        run(
            "generated-Firefox browser core",
            ["node", "Extension/tests/source_notes_entrypoints_harness.js"],
            env=firefox_env,
        )
        run("Extension background continuity and guarded authoring", ["node", "Extension/tests/background_harness.js"])
        run(
            "Extension authoring and runtime static boundaries",
            [
                sys.executable,
                "-m",
                "unittest",
                "-v",
                "Extension.tests.test_static.JavaScriptTests.test_source_note_authoring_is_placement_scoped_local_and_stale_safe",
                "Extension.tests.test_static.JavaScriptTests.test_source_note_installed_runtime_lane_is_real_view_fail_closed_evidence",
            ],
        )
        run("runtime-evidence unit corpus", [sys.executable, "-m", "unittest", "-v", "tests.test_source_notes_runtime_evidence"])
        run("runtime-evidence audit", [sys.executable, "tools/audit-source-notes-runtime-evidence.py"])
        run("runtime session preparer CLI", [sys.executable, "tools/prepare-source-notes-runtime-session.py", "--help"])
        run("runtime session finalizer CLI", [sys.executable, "tools/finalize-source-notes-runtime-session.py", "--help"])
        run("runtime evidence verifier CLI", [sys.executable, "tools/verify-source-notes-runtime-evidence.py", "--help"])
        run("runtime evidence comparison CLI", [sys.executable, "tools/compare-source-notes-runtime-evidence.py", "--help"])
        verify_inherited_boundaries()
        verify_frozen_suite_evidence()
        verify_catalog_and_claim_boundary()
    except Exception as error:
        print(f"rev0088 Source Notes verification failed: {error}", file=sys.stderr)
        return 1
    print(f"\n{REVISION} gate: PASS")
    print("classification: exact-package runtime evidence boundary with inherited managed non-current preflight; current/unmanaged browsers, Firefox, human permission prompts, real assistive technology, and participant fieldwork not run")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
