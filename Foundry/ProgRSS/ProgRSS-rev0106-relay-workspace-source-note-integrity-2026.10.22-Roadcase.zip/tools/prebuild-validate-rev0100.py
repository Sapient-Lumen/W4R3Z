#!/usr/bin/env python3
"""Fail-closed prebuild validation for rev0100."""
from __future__ import annotations

import json
import os
from pathlib import Path
import py_compile
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0100-node-branch-source-note-disclosure"


def main() -> int:
    assert (ROOT / "REVISION").read_text(encoding="utf-8").strip() == REVISION
    state = json.loads((ROOT / "REVISION-STATE.json").read_text(encoding="utf-8"))
    assert state["revision"] == REVISION and state["releaseGateClosed"] is False
    cases = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text(encoding="utf-8"))
    assert cases["revision"] == REVISION and len(cases["cases"]) == 18
    assert len({row["id"] for row in cases["cases"]}) == 18
    sys.path.insert(0, str(ROOT / "tools"))
    from source_notes_runtime_evidence import REVISION as EVIDENCE_REVISION, case_catalog
    assert EVIDENCE_REVISION == REVISION
    assert case_catalog() == cases
    result_schema = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-RESULT.schema.json").read_text(encoding="utf-8"))
    assert result_schema["properties"]["revision"]["const"] == REVISION
    audit = json.loads((ROOT / "NODE-BRANCH-SOURCE-NOTE-DISCLOSURE-AUDIT.json").read_text(encoding="utf-8"))
    assert audit["revision"] == REVISION and audit["reproduction"]["status"] == "pass"
    continuity = json.loads((ROOT / "PRODUCT-CONTINUITY-AUDIT.json").read_text(encoding="utf-8"))
    assert continuity["revision"] == REVISION and continuity["status"] == "pass"
    assert continuity["extensionChanged"] == [] and continuity["counts"]["changed"] == 5
    status = json.loads((ROOT / "evidence/rev0100/regression-status.json").read_text(encoding="utf-8"))
    assert status["complete"] is True and status["allPassed"] is True
    assert any(row["label"] == "node-browser-smoke" and row["returncode"] == 0 for row in status["rows"])
    for relative in (
        "CLI/node_web/app.js", "CLI/node_web/app.css", "CLI/tests/node_browser_smoke.py",
        "tools/run-rev0100-regressions.py", "tools/verify-rev0100-node-disclosure.py",
        "tools/audit-rev0100-product-continuity.py", "tools/build-rev0100-roadcase.py",
    ):
        assert (ROOT / relative).is_file(), relative
    for path in ROOT.rglob("*.json"):
        if "node_modules" not in path.parts:
            json.loads(path.read_text(encoding="utf-8"))
    for relative in (
        "CLI/tests/node_browser_smoke.py", "tools/run-rev0100-regressions.py",
        "tools/verify-rev0100-node-disclosure.py", "tools/audit-rev0100-product-continuity.py",
        "tools/build-rev0100-roadcase.py",
    ):
        py_compile.compile(str(ROOT / relative), doraise=True)
    subprocess.run(["node", "--check", str(ROOT / "CLI/node_web/app.js")], check=True)
    assert not list(ROOT.rglob("rev0100_node_branch_reason_reproduction_tmp.py"))
    assert not [p for p in ROOT.rglob("*.pyc") if "__pycache__" not in p.parts]
    print("PASS rev0100 prebuild validation: revision, audits, complete regressions, 18-case catalog, JSON, Python, and Node syntax.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AssertionError, OSError, ValueError, subprocess.SubprocessError) as exc:
        print(f"rev0100 prebuild validation failed: {exc}", file=sys.stderr)
        raise SystemExit(1)
