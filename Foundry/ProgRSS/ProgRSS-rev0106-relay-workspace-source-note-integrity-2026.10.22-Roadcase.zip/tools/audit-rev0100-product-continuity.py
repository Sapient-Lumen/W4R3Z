#!/usr/bin/env python3
"""Compare rev0100 CLI/Extension product paths with immutable rev0099 parent."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PARENT_NAME = "ProgRSS-rev0099-unified-baseline-2026.10.22-Roadcase.zip"
PARENT_SHA256 = "a8bf125794861dee8be6dc8aa6f182feaf0ccf2791e818b6cb3a32c663578841"
REVISION = "rev0100-node-branch-source-note-disclosure"
EXPECTED_CHANGED = {
    "CLI/README.md",
    "CLI/docs/NODE-OPERATIONS.md",
    "CLI/node_web/app.css",
    "CLI/node_web/app.js",
    "CLI/tests/node_browser_smoke.py",
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--parent", type=Path, required=True)
    parser.add_argument("--json", type=Path, default=ROOT / "PRODUCT-CONTINUITY-AUDIT.json")
    parser.add_argument("--markdown", type=Path, default=ROOT / "PRODUCT-CONTINUITY-AUDIT.md")
    args = parser.parse_args()
    parent = args.parent.resolve()
    raw = parent.read_bytes()
    if digest(raw) != PARENT_SHA256 or parent.name != PARENT_NAME:
        raise SystemExit("parent archive identity mismatch")
    with zipfile.ZipFile(parent) as archive:
        infos = {i.filename: i for i in archive.infolist() if not i.is_dir() and i.filename.startswith(("CLI/", "Extension/"))}
        if len(infos) != len(set(infos)):
            raise SystemExit("duplicate parent product member")
        parent_rows = {}
        for name, info in infos.items():
            pure = PurePosixPath(name)
            if pure.is_absolute() or ".." in pure.parts:
                raise SystemExit(f"unsafe parent member: {name}")
            data = archive.read(info)
            parent_rows[name] = {
                "bytes": len(data),
                "sha256": digest(data),
                "mode": oct(stat.S_IMODE((info.external_attr >> 16) & 0xFFFF)),
            }
    current_paths = {
        p.relative_to(ROOT).as_posix(): p
        for base in (ROOT / "CLI", ROOT / "Extension")
        for p in base.rglob("*") if p.is_file() and not p.is_symlink() and p.suffix != ".pyc" and "__pycache__" not in p.parts
    }
    added = sorted(set(current_paths) - set(parent_rows))
    deleted = sorted(set(parent_rows) - set(current_paths))
    changed = []
    unchanged = 0
    mode_changed = []
    for name in sorted(set(current_paths) & set(parent_rows)):
        path = current_paths[name]
        data = path.read_bytes()
        current_mode = oct(stat.S_IMODE(path.stat().st_mode))
        before = parent_rows[name]
        if current_mode != before["mode"]:
            mode_changed.append(name)
        if digest(data) != before["sha256"] or len(data) != before["bytes"]:
            changed.append(name)
        else:
            unchanged += 1
    if added or deleted or mode_changed or set(changed) != EXPECTED_CHANGED:
        raise SystemExit(json.dumps({"added": added, "deleted": deleted, "modeChanged": mode_changed, "changed": changed}, indent=2))
    extension_changed = [name for name in changed if name.startswith("Extension/")]
    report = {
        "schema": "progrss.product-continuity-audit.v1",
        "revision": REVISION,
        "parent": {"name": PARENT_NAME, "sha256": PARENT_SHA256, "bytes": len(raw)},
        "counts": {
            "parentProductFiles": len(parent_rows),
            "currentProductFiles": len(current_paths),
            "unchanged": unchanged,
            "changed": len(changed),
            "added": len(added),
            "deleted": len(deleted),
            "modeChanged": len(mode_changed),
        },
        "changed": changed,
        "extensionChanged": extension_changed,
        "permissionsExpanded": False,
        "newPersistentStore": False,
        "newNetworkAuthority": False,
        "status": "pass",
    }
    args.json.write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    args.markdown.write_text(
        "# Product continuity audit — rev0100\n\n"
        f"Parent: `{PARENT_NAME}`  \nSHA-256: `{PARENT_SHA256}`\n\n"
        f"Compared {len(parent_rows)} parent CLI/Extension files with {len(current_paths)} current files. "
        f"Exactly {len(changed)} paths changed; no path was added, deleted, or mode-changed. "
        "All Extension files remain byte- and mode-identical to rev0099.\n\n"
        "Changed paths:\n\n" + "\n".join(f"- `{name}`" for name in changed) +
        "\n\nThe change is limited to the Node review UI, its managed rendering fixture, and Node documentation. "
        "No browser permission, persistent store, or network authority was added.\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
