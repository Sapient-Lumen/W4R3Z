#!/usr/bin/env python3
"""Fail-closed prebuild validation for rev0102."""
from __future__ import annotations

import json
from pathlib import Path
import py_compile
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0102-node-merge-source-note-disclosure"


def main() -> int:
    assert (ROOT / "REVISION").read_text(encoding="utf-8").strip() == REVISION
    state = json.loads((ROOT / "REVISION-STATE.json").read_text(encoding="utf-8"))
    assert state["revision"] == REVISION and state["releaseGateClosed"] is False
    cases = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text(encoding="utf-8"))
    assert cases["revision"] == REVISION and len(cases["cases"]) == 18
    assert len({row["id"] for row in cases["cases"]}) == 18
    keep = next(row for row in cases["cases"] if row["id"] == "divergent-later-copy-keep-mine")
    curator = next(row for row in cases["cases"] if row["id"] == "divergent-later-copy-use-curator")
    assert "Node review" in keep["description"] and "Node review" in curator["description"]

    sys.path.insert(0, str(ROOT / "tools"))
    from source_notes_runtime_evidence import REVISION as EVIDENCE_REVISION, case_catalog
    assert EVIDENCE_REVISION == REVISION and case_catalog() == cases
    result_schema = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-RESULT.schema.json").read_text(encoding="utf-8"))
    assert result_schema["properties"]["revision"]["const"] == REVISION

    audit = json.loads((ROOT / "NODE-MERGE-SOURCE-NOTE-DISCLOSURE-AUDIT.json").read_text(encoding="utf-8"))
    continuity = json.loads((ROOT / "PRODUCT-CONTINUITY-AUDIT.json").read_text(encoding="utf-8"))
    integration = json.loads((ROOT / "INTEGRATION-AUDIT.json").read_text(encoding="utf-8"))
    assert audit["revision"] == REVISION and audit["status"] == "focused-pass"
    assert audit["correction"]["canonicalFolderPath"] is True
    assert audit["correction"]["readOnly"] is True and audit["correction"]["network"] is False
    assert continuity["revision"] == REVISION and continuity["status"] == "pass"
    assert continuity["permissionsExpanded"] is False and continuity["newNetworkAuthority"] is False
    assert integration["revision"] == REVISION and integration["status"] == "pass"

    status = json.loads((ROOT / "evidence/rev0102/regression-status.json").read_text(encoding="utf-8"))
    assert status["complete"] is True and status["allPassed"] is True
    labels = {row["label"]: row for row in status["rows"]}
    required = {
        "cli-test_node_server", "node-browser-smoke", "node-merge-source-notes",
        "extension-browser-smoke", "extension-complete", "evidence-boundary", "contract",
        "cli-test_exchange_source_notes", "cli-test_source_notes_private_transfer",
    }
    assert required <= set(labels)
    assert all(labels[label]["returncode"] == 0 for label in required)
    assert status["managedNodeHarnessInvocations"] == 22

    relay = (ROOT / "CLI/relay.py").read_text(encoding="utf-8")
    app = (ROOT / "CLI/node_web/app.js").read_text(encoding="utf-8")
    css = (ROOT / "CLI/node_web/app.css").read_text(encoding="utf-8")
    for phrase in ('"folderPath": folder_path', 'incoming_folder_paths'):
        assert phrase in relay
    for phrase in ("merge-source-note-value", "Curator’s reason for this folder", "Keep mine", "Use curator’s", "not a ProgRSS safety claim"):
        assert phrase in app
    assert "white-space:pre-wrap" in css

    for relative in (
        "tools/run-rev0102-regressions.py", "tools/verify-rev0102-node-merge-disclosure.py",
        "tools/audit-rev0102-product-continuity.py", "tools/update-rev0102-provenance.py",
        "tools/write-rev0102-authority.py", "tools/build-rev0102-roadcase.py",
        "CLI/tests/source_notes_node_merge_review_harness.py",
    ):
        path = ROOT / relative
        assert path.is_file(), relative
        py_compile.compile(str(path), doraise=True)
    for path in ROOT.rglob("*.json"):
        if "node_modules" not in path.parts:
            json.loads(path.read_text(encoding="utf-8"))
    subprocess.run(["node", "--check", str(ROOT / "CLI/node_web/app.js")], check=True)
    assert not [p for p in ROOT.rglob("*.pyc") if "__pycache__" not in p.parts]
    print("PASS rev0102 prebuild validation: full-route Node merge disclosure, complete regressions, 18-case binding, JSON, Python, and Node syntax.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AssertionError, OSError, ValueError, subprocess.SubprocessError) as exc:
        print(f"rev0102 prebuild validation failed: {exc}", file=sys.stderr)
        raise SystemExit(1)
