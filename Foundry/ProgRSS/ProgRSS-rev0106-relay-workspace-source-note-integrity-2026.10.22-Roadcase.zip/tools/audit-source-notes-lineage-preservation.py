#!/usr/bin/env python3
"""Audit the reproduced rev0096 Lineage loss and rev0097 correction."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence" / "rev0097"
REVISION = "rev0097-source-notes-lineage-preservation"
JSON_OUT = ROOT / "SOURCE-NOTES-LINEAGE-PRESERVATION-AUDIT.json"
MD_OUT = ROOT / "SOURCE-NOTES-LINEAGE-PRESERVATION-AUDIT.md"


def parse_json_log(path: Path, pass_line: str) -> dict:
    text = path.read_text(encoding="utf-8")
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end < start:
        raise AssertionError(f"no JSON object in {path}")
    row = json.loads(text[start : end + 1])
    assert pass_line in text, path
    assert row["count"] == len(row["passed"]), row
    return row


def main() -> None:
    reproduction = json.loads((EVIDENCE / "parent-lineage-source-note-loss.json").read_text(encoding="utf-8"))
    assert reproduction["schema"] == "progrss.source-notes.lineage-loss-reproduction.v1"
    assert reproduction["candidateRevision"] == REVISION
    assert reproduction["parentArchiveSha256"] == "ba96be5d2e94b8237e4373bb5fd01ee555094826dd667b9d6252e01312fe6684"
    assert reproduction["parentPublishedReason"] is True
    assert reproduction["parentPreviewDroppedReason"] is True
    assert reproduction["parentAppliedDroppedReason"] is True
    assert reproduction["networkActivity"] is False
    assert reproduction["installedBrowserRuntime"] is False

    native_chromium = parse_json_log(EVIDENCE / "lineage-native-chromium.log", "PASS Source Notes Lineage preservation: 11 cases")
    native_firefox = parse_json_log(EVIDENCE / "lineage-native-firefox.log", "PASS Source Notes Lineage preservation: 11 cases")
    ui_chromium = parse_json_log(EVIDENCE / "lineage-ui-chromium.log", "PASS Workbench Lineage Source Notes: 4 cases")
    ui_firefox = parse_json_log(EVIDENCE / "lineage-ui-firefox.log", "PASS Workbench Lineage Source Notes: 4 cases")
    assert native_chromium["passed"] == native_firefox["passed"]
    assert ui_chromium["passed"] == ui_firefox["passed"]

    shared = [
        "workbench/scripts/progrss-lineage.js",
        "workbench/scripts/progrss-app.js",
        "workbench/index.html",
        "workbench/styles/workbench-1.css",
    ]
    for relative in shared:
        assert (ROOT / "Extension" / relative).read_bytes() == (ROOT / "Extension" / "Firefox" / relative).read_bytes(), relative

    lineage = (ROOT / "Extension/workbench/scripts/progrss-lineage.js").read_text(encoding="utf-8")
    app = (ROOT / "Extension/workbench/scripts/progrss-app.js").read_text(encoding="utf-8")
    html = (ROOT / "Extension/workbench/index.html").read_text(encoding="utf-8")
    for needle in (
        "projected.reason=member.reason",
        "SOURCE_NOTE_CHOICES",
        "sourceNoteConflicts",
        "unresolvedSourceNoteConflicts",
        "Source Note decision is stale",
        "if(!incomingMember)return {...member}",
        "if(selected===null)delete projected.reason",
    ):
        assert needle in lineage, needle
    for needle in (
        "pendingLineageChoices",
        "Keep mine",
        "Use curator’s",
        "Choose Keep mine or Use curator’s",
        "renderLineageSourceNoteConflicts",
    ):
        assert needle in app, needle
    assert 'id="lineage-source-note-conflicts"' in html

    result = {
        "schema": "progrss.source-notes.lineage-preservation-audit.v1",
        "revision": REVISION,
        "pass": True,
        "parent": {
            "archive": reproduction["parentArchive"],
            "sha256": reproduction["parentArchiveSha256"],
            "publishedReason": reproduction["publishedReason"],
            "previewDroppedReason": True,
            "adoptionDroppedReason": True,
        },
        "candidate": {
            "nativeChromiumCases": native_chromium["count"],
            "nativeFirefoxCases": native_firefox["count"],
            "workbenchChromiumCases": ui_chromium["count"],
            "workbenchFirefoxCases": ui_firefox["count"],
            "sharedProductBytesIdentical": True,
            "firstEditionPreservesReasons": True,
            "oneSidedAndIdenticalChangesMerge": True,
            "divergenceHasNoAutomaticWinner": True,
            "deletionVersusEditRequiresChoice": True,
            "staleDecisionsRefused": True,
            "structuralConflictPreservesRetainedLocalReasons": True,
            "networkActivity": False,
        },
        "scope": {
            "nativeEvidence": "pure shipped Lineage module replay",
            "uiEvidence": "managed shipped Workbench UI path with deterministic in-page persistence backend",
            "installedBrowserRuntime": False,
            "humanComprehension": False,
            "accessibilityConformance": False,
        },
    }
    JSON_OUT.write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    MD_OUT.write_text(
        "# Source Notes Lineage preservation audit\n\n"
        f"Revision: `{REVISION}`\n\n"
        "## Reproduced parent failure\n\n"
        "The rev0096 publisher included the direct-placement reason in the immutable edition, but Lineage ID remapping rebuilt members as `{kind,id}`. Preview and adoption therefore dropped the reason.\n\n"
        "## Candidate result\n\n"
        "- Native Chromium-source Lineage: **11/11** focused cases passed.\n"
        "- Native generated-Firefox Lineage: **11/11** focused cases passed.\n"
        "- Shipped Workbench review path: **4/4** cases passed in each package.\n"
        "- First-edition adoption preserves every direct-placement reason.\n"
        "- One-sided and identical later changes merge without a false conflict.\n"
        "- Divergent edits, edit-versus-deletion, and different additions have no automatic winner.\n"
        "- **Keep mine** and **Use curator’s** are placement-scoped, explicit, and rechecked at commit.\n"
        "- Unknown, invalid, and stale decisions are refused.\n"
        "- A locally retained placement keeps its reason when a simultaneous structural conflict preserves local membership.\n"
        "- The focused paths made no network request.\n\n"
        "## Scope\n\n"
        "This is native-module and managed shipped-UI-path regression evidence. It is not installed-browser, target-host, participant, privacy-comprehension, assistive-technology, or accessibility-conformance evidence.\n",
        encoding="utf-8",
    )
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
