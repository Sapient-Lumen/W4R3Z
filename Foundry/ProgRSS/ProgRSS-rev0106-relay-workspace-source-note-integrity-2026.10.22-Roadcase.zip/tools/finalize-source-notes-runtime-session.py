#!/usr/bin/env python3
"""Finalize one prepared Source Notes runtime session into verified evidence."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from source_notes_runtime_evidence import (
    EvidenceError,
    canonical_json_bytes,
    finalize_evidence,
    verify_evidence_bundle,
    write_evidence_bundle,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--session-dir", type=Path, required=True)
    parser.add_argument("--roadcase", type=Path, required=True)
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--attestation", type=Path, required=True)
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--summary", type=Path)
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[1]
    verifier = root / "VERIFY-ROADCASE.py"
    try:
        finalized = finalize_evidence(
            session_dir=args.session_dir,
            roadcase=args.roadcase,
            result_path=args.result,
            verifier=verifier,
        )
        attestation = args.attestation.resolve()
        attestation.parent.mkdir(parents=True, exist_ok=True)
        attestation.write_bytes(finalized.attestation_bytes)
        bundle_meta = write_evidence_bundle(
            session_dir=args.session_dir.resolve(),
            result_path=args.result.resolve(),
            finalized=finalized,
            output=args.bundle,
        )
        verification = verify_evidence_bundle(
            args.bundle.resolve(),
            roadcase=args.roadcase.resolve(),
            verifier=verifier,
        )
        summary = {
            "schema": "progrss.source-notes.runtime-finalization.v1",
            "status": finalized.status,
            "pass": finalized.status == "pass",
            "attestation": str(attestation),
            "attestationSha256": bundle_meta["attestationSha256"],
            "evidenceManifestSha256": bundle_meta["evidenceManifestSha256"],
            "bundle": str(args.bundle.resolve()),
            "bundleBytes": bundle_meta["bytes"],
            "bundleSha256": bundle_meta["sha256"],
            "bundleVerified": verification["pass"],
            "verificationScope": verification["verificationScope"],
            "roadcaseReverified": verification["roadcaseReverified"],
            "packageReverifiedFromRoadcase": verification["packageReverifiedFromRoadcase"],
        }
        if args.summary:
            summary_path = args.summary.resolve()
            summary_path.parent.mkdir(parents=True, exist_ok=True)
            summary_path.write_bytes(canonical_json_bytes(summary))
        print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
        return 0
    except (EvidenceError, OSError, ValueError) as error:
        print(f"runtime evidence finalization failed: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
