#!/usr/bin/env python3
"""Write the rev0106 current authority and release-gate documents."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0106-relay-workspace-source-note-integrity"
PARENT = "ProgRSS-rev0105-node-private-library-source-note-integrity-2026.10.22-Roadcase.zip"
PARENT_SHA = "e34cb801d87dd7e4c8bf26cf72ce25e6356af68d20818140691889a59c19dd6c"
PARENT_BYTES = 26881071
DATE = "2026-10-22"


def write(name: str, text: str) -> None:
    (ROOT / name).write_text(text.rstrip() + "\n", encoding="utf-8")


def dump(name: str, value: object) -> None:
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")


def main() -> int:
    status = json.loads((ROOT / "evidence/rev0106/regression-status.json").read_text(encoding="utf-8"))
    if not status.get("complete") or not status.get("allPassed"):
        raise SystemExit("complete passing rev0106 regression status is required")
    continuity = json.loads((ROOT / "PRODUCT-CONTINUITY-AUDIT.json").read_text(encoding="utf-8"))
    focused = json.loads((ROOT / "SOURCE-NOTES-RELAY-WORKSPACE-INTEGRITY-AUDIT.json").read_text(encoding="utf-8"))
    cli_rows = [row for row in status["rows"] if str(row.get("label", "")).startswith("cli-")]
    cli_tests = sum(int(row.get("tests") or 0) for row in cli_rows)
    cli_modules = len(cli_rows)
    extension_static = next(int(row.get("tests") or 0) for row in status["rows"] if row["label"] == "extension-static")
    evidence_tests = next(int(row.get("tests") or 0) for row in status["rows"] if row["label"] == "evidence-boundary")

    bootstrap = f"""# BOOTSTRAPROSE — current `/run` authority

Revision: **{REVISION}**  
Date: **{DATE}**  
Product lineage: **rev0080 / 0.80.0**  
Release gate: **OPEN**

This authority supersedes earlier `/run` prose. It continues the sealed rev0105 unified tree and does not represent rev0081, rev0082, or the undelivered browser-execution-binding source archive as recovered.

- Immediate parent: `{PARENT}` · `{PARENT_SHA}`
- The whole-product Reader, CLI, loopback Node, Exchange, Capture/Witness/Pulse/Trace, Workbench, Lineage, publication, transfer, repair, conflict, concurrency, Undo, native-integrity, and runtime-record boundaries remain present.
- Managed tests and deterministic archives do not substitute for target-host browsers, unfamiliar people, privacy review, or real assistive technologies.

## P0.0 — completed in this candidate

- Reproduced that the sealed parent accepted a private workspace containing a 281-code-point direct-placement reason through the shipped Relay `workspace import-bundle` path, returned success, wrote a new backup, and retained the malformed reason.
- Applied the shared Python direct-placement audit in `CLI/relay.py::read_workspace` before every Relay workspace command uses private state.
- Re-audited derived state in `write_workspace` immediately before a new private backup is written.
- Covered `share-folder`, `publish-folder`, `import-bundle`, `review-bundle`, `check-publication`, and `update-bundle` through the shipped CLI.
- Preserved valid two-folder reasons, multiline/Unicode text, explicit absence, and incoming bundle reasons without rewriting.
- Refused over-limit, wrong-level, folder-level, reason-bearing duplicate, empty, edge-whitespace, non-string, invalid-Unicode, and missing-source forms before output; explicit publication checking refuses before its network step.
- Added no network authority, persistent store, browser permission, account, schedule, notification, ranking, profile, reaction, comment, or messaging capability.
- Kept the fixed runtime catalog at 18 cases by extending `two-folder-independence`.

## P0.1 — exact package on the actual browser triad

Run fresh rev0106 session-v5 records from the sealed candidate in unmanaged then-current Chromium Stable, Firefox Release, and Firefox ESR. Capture fresh official channel evidence on each host. Do not relabel earlier sessions.

Run all 18 cases and every inherited whole-product boundary. In `two-folder-independence`, explicitly prove:

- One source has different reasons in two direct folders and a third placement has no reason.
- Valid private state passes Relay share, ready-to-host publication, import, offline review, explicit publication checking, and reviewed update without reason rewriting.
- Imported output preserves both existing and incoming route-specific reasons.
- Every malformed Source Note form is refused by all six Relay workspace command paths before output; malformed `check-publication` state causes no network request.
- A malformed derived state is refused immediately before private-workspace output.

Retain every inherited Reader, Node private-library/branch/merge, Exchange, private-transfer, Capture, Witness, Pulse, Trace, Workbench collection/backup, Lineage, repair, conflict, stale-write, saturated-concurrency, whole-placement Undo, publication, OPML, integrity, restart, and permission-observation check. Preserve first failures, interruptions, retries, and recovery.

Firefox temporary loading remains development-runtime evidence and must not be interpreted as signed-install or restart acceptance.

## P0.2 — unfamiliar people, privacy, and real assistive technologies

Only after the exact browser triad passes:

- Ask unfamiliar people what a Relay share, publication, import, review, explicit update check, and update will read, write, or contact.
- Ask which direct folder relationship each reason belongs to, who wrote it, and whether it is a ProgRSS safety claim.
- Ask whether share, review, import, update, or refusal published anything, contacted a listed source, or created a schedule.
- Compare sender, recipient, and diagnostic privacy evidence separately.
- Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions.
- Make only the smallest correction supported by recurring independent wrong turns.

## P1 — sharing and organization

- Test one-week delayed route re-finding before adding private labels or saved-view complexity.
- Keep folders human-curated and shareable; preserve **Unfiled** as legitimate.
- Keep Source Note wording out of engagement ranking and opaque recommendation systems.
- Do not expand Source Notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

- Keep remote mode explicit and separate from loopback.
- Require TLS, persistent Node identity, bounded hosts/requests/artifacts/rates, expiring invitations, and durable revocation evidence.
- Keep public publication routes separate from private APIs.
- No default public bind, silent LAN discovery, or UPnP.

## Lab — WebRTC courier

- Transfer exactly one reviewed immutable artifact; preserve Source Notes through it.
- Make signaling, STUN, and TURN visible; refuse replay, identity/digest mismatch, timeout, and partial completion.
- Destroy the bounded session afterward.
- Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## Stop conditions

- Do not add another evidence layer merely because target-host access is unavailable.
- Do not claim installed-browser, human, privacy, assistive-technology, or accessibility acceptance from managed automation.
- Make another product change only for a reproduced failure.
"""
    write("BOOTSTRAPROSE.md", bootstrap)

    summary = f"""# Result summary — rev0106 Relay workspace Source Note integrity

The sealed rev0105 parent accepted a 281-code-point direct-placement reason through the shipped Relay workspace import path and wrote it into a new backup. rev0106 validates private placement reasons in the shared Relay workspace loader and revalidates derived state before output. All six Relay workspace commands now fail closed on malformed private state while valid two-folder and incoming reasons remain exact.

Focused replay passed five test methods, nine malformed forms, and six shipped command paths. The complete inherited regression passed **{cli_tests} CLI tests across {cli_modules} modules**, **{extension_static} Extension static tests**, **{status.get('managedNodeHarnessInvocations', 0)} managed Node/product harness invocations**, the complete Extension runner and managed UI variants, and **{evidence_tests} runtime-record/comparison tests**. The fixed runtime catalog remains 18 cases.

Exact target-host browser, unfamiliar-person, privacy, and assistive-technology acceptance remain open.
"""
    write("RESULT-SUMMARY.md", summary)
    write("CURRENT-STATUS.md", summary)

    write("HANDOFF.md", f"""# Handoff — {REVISION}

## Current authority

`BOOTSTRAPROSE.md` is the `/run` authority. Immediate parent: `{PARENT}` (`{PARENT_SHA}`).

## Reproduced and corrected

The parent Relay loader accepted malformed direct-placement Source Notes. A shipped `workspace import-bundle` run returned success, wrote a new backup, and retained a 281-code-point reason. rev0106 invokes the shared placement audit in `read_workspace` before all six Relay workspace commands and in `write_workspace` before output. Valid route-specific reasons remain exact; nine malformed forms refuse before output, and malformed explicit publication checking refuses before network work.

## Next exact work

Seal the deterministic Roadcase, then run fresh rev0106 18-case and whole-product sessions on actual unmanaged then-current Chromium, Firefox Release, and Firefox ESR hosts. `two-folder-independence` must include valid and malformed Relay share/publish/import/review/check/update behavior and derived-state output refusal. After the triad passes, perform unfamiliar-person, separate privacy, and real assistive-technology fieldwork.

Do not add another evidence layer merely because target-host access is unavailable. Further product changes require a reproduced failure.
""")

    state = {
        "schema": "progrss.revision-state.v1",
        "revision": REVISION,
        "date": DATE,
        "productLineage": {"revision": "rev0080", "version": "0.80.0"},
        "parent": {"name": PARENT, "sha256": PARENT_SHA, "bytes": PARENT_BYTES},
        "classification": "reproduced Relay workspace Source Note validation bypass correction; exact target-host acceptance open",
        "releaseGateClosed": False,
        "nextP0": "Seal the deterministic candidate, then run fresh rev0106 18-case and whole-product sessions on actual unmanaged then-current Chromium, Firefox Release, and Firefox ESR hosts, including valid and malformed Relay workspace command behavior; then separate human, privacy, and assistive-technology fieldwork.",
        "checks": {
            "behaviorCatalog": {"revision": REVISION, "cases": 18, "freshSessionPreparationRequired": True, "status": "pass"},
            "relayWorkspaceIntegrity": {**focused["focusedTests"], "status": "focused-pass"},
            "offlineRegressions": {
                "cliModules": cli_modules,
                "cliTests": cli_tests,
                "extensionStaticTests": extension_static,
                "managedNodeHarnessInvocations": status.get("managedNodeHarnessInvocations", 0),
                "runtimeRecordAndComparisonTests": evidence_tests,
                "runtimeEvidenceRevisionBinding": REVISION,
                "status": "pass",
            },
            "productContinuity": {**continuity["counts"], "permissionsExpanded": False, "status": "pass"},
            "deterministicBuild": {"status": "requires-detached-post-build-report"},
        },
        "claims": {
            "productChanged": True,
            "cliChanged": True,
            "extensionChanged": False,
            "permissionsExpanded": False,
            "newPersistentStore": False,
            "newNetworkAuthority": False,
            "installedBrowserRuntimeThisTurn": False,
            "unmanagedChromiumRuntime": False,
            "firefoxReleaseRuntime": False,
            "firefoxEsrRuntime": False,
            "humanPermissionPromptObservation": False,
            "unfamiliarParticipantFieldwork": False,
            "privacyComprehensionFieldwork": False,
            "assistiveTechnologyFieldwork": False,
            "accessibilityConformance": False,
            "policyModified": False,
            "rev0081OrRev0082Recovered": False,
            "browserRenderingThisTurn": False,
        },
    }
    dump("REVISION-STATE.json", state)

    rows = [
        {"id": "sealed-rev0105-parent", "scope": "sealed rev0105 unified whole-product tree retained", "status": "pass"},
        {"id": "relay-workspace-source-note-integrity", "scope": "shared placement audit on all six Relay workspace commands and before derived workspace output; five focused tests and nine malformed forms", "status": "focused-pass"},
        {"id": "runtime-catalog-binding", "scope": "18 cases; session v5/result v3; fresh rev0106 preparation required", "status": "pass"},
        {"id": "complete-offline-regression", "scope": f"{cli_tests} CLI tests across {cli_modules} modules, {extension_static} Extension static tests, {status.get('managedNodeHarnessInvocations', 0)} managed Node/product harness invocations, inherited managed UI variants, complete Extension runner, and {evidence_tests} evidence tests", "status": "pass"},
        {"id": "deterministic-seal", "status": "external-postbuild-report-required"},
        {"id": "unmanaged-current-chromium", "status": "not-run"},
        {"id": "firefox-release", "status": "not-run"},
        {"id": "firefox-esr", "status": "not-run"},
        {"id": "unfamiliar-curators-and-recipients", "status": "not-run"},
        {"id": "separate-sender-recipient-diagnostic-privacy", "status": "not-run"},
        {"id": "real-assistive-technologies", "status": "not-run"},
    ]
    matrix = {
        "revision": REVISION,
        "releaseGateClosed": False,
        "inheritedEvidence": "Earlier records retain their original identities and scopes; exact rev0106 product bytes require fresh target-host sessions.",
        "rows": rows,
    }
    dump("RUNTIME-MATRIX.json", matrix)
    dump("SOURCE-NOTES-RUNTIME-MATRIX.json", matrix)
    matrix_md = "# Runtime and release matrix — rev0106\n\n| Row | Scope | Status |\n|---|---|---:|\n" + "\n".join(
        f"| `{row['id']}` | {row.get('scope', '')} | **{row['status'].upper()}** |" for row in rows
    ) + "\n"
    write("RUNTIME-MATRIX.md", matrix_md)
    write("SOURCE-NOTES-RUNTIME-MATRIX.md", matrix_md.replace("# Runtime and release matrix", "# Source Notes runtime matrix", 1))

    checklist = """# Source Notes checklist — rev0106

- [x] Direct-placement reason contract shared by Python and JavaScript.
- [x] Native artifacts, branch selection, OPML omission, Lineage, Workbench, Exchange, publication, repair, conflicts, and Undo retained.
- [x] Private transfer, Workbench private backup, and Node private-library paths fail closed.
- [x] Relay share, publish, import, review, explicit publication check, update, and derived workspace output fail closed.
- [ ] Exact package in unmanaged then-current Chromium Stable.
- [ ] Exact generated sibling in Firefox Release.
- [ ] Exact generated sibling in Firefox ESR.
- [ ] Unfamiliar-person, separate privacy, and real assistive-technology fieldwork.
"""
    write("SOURCE-NOTES-CHECKLIST.md", checklist)
    write("ROADCASE-SOURCE-NOTES-CHECKLIST.md", checklist.replace("Source Notes checklist", "Roadcase Source Notes checklist", 1))

    entry = json.loads((ROOT / "SOURCE-NOTES-ENTRYPOINT-MATRIX.json").read_text(encoding="utf-8"))
    entry["revision"] = REVISION
    entry["classification"] = "all implementation rows pass in native/managed scope; exact browser and fieldwork gates remain open"
    entry["releaseGateClosed"] = False
    entry["rows"] = [row for row in entry["rows"] if row.get("id") != "cli-relay-workspace-source-note-integrity"]
    entry["rows"].append({
        "id": "cli-relay-workspace-source-note-integrity",
        "surface": "CLI Relay workspace commands",
        "behavior": "Apply the shared direct-placement Source Notes audit before share, publish, import, review, explicit publication checking, or update and again before derived workspace output; preserve valid route-specific reasons exactly; refuse nine malformed forms before output or explicit network work.",
        "status": "pass",
        "limitation": "Offline/native process replay; target-host browser and human comprehension remain open.",
        "evidenceType": "shipped-cli-process-and-native-unit-replay",
        "command": "python3 -m unittest -v CLI.tests.test_source_notes_relay_workspace",
        "paths": ["CLI/relay.py", "CLI/source_notes_native.py", "CLI/tests/test_source_notes_relay_workspace.py"],
        "evidence": ["evidence/rev0106/parent-reproduction/result.json", "evidence/rev0106/fixed-replay/result.json", "evidence/rev0106/regressions/cli-test_source_notes_relay_workspace.log"],
    })
    counts = {"pass": 0, "open": 0, "notRun": 0}
    for row in entry["rows"]:
        value = str(row.get("status", "")).lower()
        if value == "pass": counts["pass"] += 1
        elif value in {"not-run", "not run"}: counts["notRun"] += 1
        elif value in {"open", "not-established"}: counts["open"] += 1
    entry["summary"] = counts
    dump("SOURCE-NOTES-ENTRYPOINT-MATRIX.json", entry)
    entry_md = "# Source Notes shipped-entrypoint matrix — rev0106\n\nClassification: all implementation rows pass in native/managed scope; exact browser and fieldwork gates remain open.\n\n| Surface | Behavior | Status | Limitation |\n|---|---|---:|---|\n"
    for row in entry["rows"]:
        status_text = str(row["status"]).upper()
        entry_md += f"| {row['surface']} | {row['behavior']} | **{status_text}** | {row['limitation']} |\n"
    write("SOURCE-NOTES-ENTRYPOINT-MATRIX.md", entry_md)

    write("SOURCE-NOTES-RUNTIME-PROTOCOL.md", """# Source Notes runtime protocol — rev0106

Use the immutable rev0106 Roadcase to prepare fresh session-v5 records on each actual target host. Run the fixed 18-case catalog without relabeling earlier evidence. In `two-folder-independence`, include valid and malformed Relay share, publish, import, review, explicit publication-check, update, and output-boundary behavior. Preserve first failures, retries, interruptions, and recovery. Finalize and independently verify each complete evidence bundle against the same Roadcase.
""")
    write("RUNTIME-OPERATOR-GUIDE.md", """# Runtime operator guide — rev0106

1. Verify the immutable Roadcase digest and extract it with executable modes intact.
2. Capture fresh official browser-channel evidence and the actual target-host browser identity.
3. Prepare a new rev0106 session; do not relabel an older record.
4. Run all 18 cases and every whole-product boundary.
5. For Relay workspace integrity, preserve valid route-specific reasons through all six commands, refuse all nine malformed forms before output, prove malformed explicit publication checking makes no network request, and prove malformed derived state is refused before workspace output.
6. Preserve first failures, interruptions, retries, and recovery.
7. Finalize and independently verify the evidence bundle against the same Roadcase.
8. Keep temporary Firefox runtime evidence separate from permanent signed-install, restart, and installation-time permission conclusions.
""")
    write("SOURCE-NOTES-RUNTIME-ATTESTATION.md", """# Runtime attestation boundary — rev0106

Runtime records remain unsigned consistency records bound to the immutable Roadcase, prepared session, fixed 18-case catalog, package bytes, native artifacts, and retained evidence. They do not authenticate the operator, browser-download server, wall clock, human presence, unmanaged state, permission-prompt comprehension, accessibility conformance, or participant understanding. Fresh rev0106 records are required; earlier records retain their original identities and scopes.
""")

    runtime_audit = {
        "schema": "progrss.source-notes.runtime-evidence-audit.v1",
        "revision": REVISION,
        "status": "pass",
        "caseCount": 18,
        "sessionSchema": "v5",
        "resultPredicate": "v3",
        "freshPreparationRequired": True,
        "olderRecordsMayBeRelabeled": False,
        "catalogExtension": "two-folder-independence now includes all six Relay workspace commands and derived workspace output validation",
    }
    dump("SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.json", runtime_audit)
    write("SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.md", """# Runtime-evidence binding audit — rev0106

- The fixed catalog remains 18 behavioral cases.
- Session schema v5 and result/predicate v3 remain in force.
- `two-folder-independence` now includes valid and malformed Relay workspace share, publish, import, review, explicit publication-check, update, and output-boundary behavior.
- Fresh rev0106 sessions are required; older records must not be relabeled.
- This revision adds no new evidence layer and makes no installed-browser, human, privacy, assistive-technology, or accessibility-conformance claim.
""")

    integration = {
        "schema": "progrss.integration-audit.v1",
        "revision": REVISION,
        "status": "pass",
        "parent": {"name": PARENT, "sha256": PARENT_SHA, "bytes": PARENT_BYTES},
        "productContinuity": continuity["counts"],
        "reproducedFailure": "Relay workspace import accepted and rewrote a private backup retaining a 281-code-point direct-placement reason",
        "correction": "shared read_workspace and write_workspace direct-placement audit",
        "runtimeCatalogCases": 18,
        "missingArtifactsStillUnrecovered": ["rev0081", "rev0082", "rev0090-source-notes-browser-execution-binding"],
        "releaseGateClosed": False,
    }
    dump("INTEGRATION-AUDIT.json", integration)
    write("INTEGRATION-AUDIT.md", f"""# Integration audit — rev0106

Immediate parent: `{PARENT}` (`{PARENT_SHA}`).

The complete rev0105 whole-product tree is retained. Product differences are limited to `CLI/relay.py`, `CLI/README.md`, one inherited process fixture updated to canonical private-workspace input, and the added focused Relay workspace test module. The complete Extension tree and browser permission projections are unchanged.

The parent’s Relay workspace import accepted and rewrote a private backup while retaining a 281-code-point placement reason. The corrected shared loader audits all six Relay workspace command paths, and the output boundary audits derived state before writing a new backup. Valid route-specific reasons remain exact; nine malformed forms fail closed.

The fixed runtime catalog remains 18 cases. Rev0081, rev0082, and the undelivered rev0090 browser-execution-binding source archive remain explicitly unrecovered. The release gate remains open for exact target-host browsers and subsequent human/privacy/assistive-technology fieldwork.
""")

    write("CHANGELOG-rev0106-relay-workspace-source-note-integrity.md", """# rev0106 — Relay workspace Source Note integrity

- Validate private Source Note placements in the shared Relay workspace loader.
- Revalidate derived private state before Relay workspace output.
- Cover all six Relay workspace command paths.
- Preserve valid route-specific reasons; refuse nine malformed forms without output or premature network work.
- Keep the fixed 18-case catalog and every inherited whole-product boundary.
""")

    write("BUILD-REPORT.md", f"""# Pre-seal build status — rev0106

- Revision binding: PASS
- Focused Relay workspace replay: PASS
- Product continuity against rev0105: PASS
- Complete regression: PASS ({cli_tests} CLI tests across {cli_modules} modules; {extension_static} Extension static tests; {evidence_tests} runtime-record/comparison tests)
- Deterministic Roadcase construction: PENDING detached build
- Exact target-host browser triad: NOT RUN
- Participant, privacy, and real assistive-technology fieldwork: NOT RUN
""")
    print(json.dumps({"revision": REVISION, "cliTests": cli_tests, "cliModules": cli_modules, "extensionStatic": extension_static, "evidenceTests": evidence_tests}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
