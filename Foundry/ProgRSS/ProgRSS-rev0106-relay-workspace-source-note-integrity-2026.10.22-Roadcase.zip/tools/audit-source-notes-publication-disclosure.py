#!/usr/bin/env python3
"""Audit rev0098 ready-to-host placement-reason disclosure."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0098-source-notes-publication-disclosure"
PARENT = "ProgRSS-rev0097-source-notes-lineage-preservation-2026.10.21-Roadcase.zip"
PARENT_SHA = "65643a4899276bdbbc348aacee60a3db2c84a23c70f3c4f32df3ec03188a4336"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    reproduction = json.loads((ROOT / "evidence/rev0098/parent-publication-source-note-omission.json").read_text())
    assert reproduction["reproduced"] is True
    assert reproduction["cli"]["nativeReasonA"] and reproduction["cli"]["nativeReasonB"]
    assert not reproduction["cli"]["pageReasonA"] and not reproduction["cli"]["pageReasonB"]
    assert reproduction["extension"]["nativeReasonA"] and reproduction["extension"]["nativeReasonB"]
    assert not reproduction["extension"]["pageReasonA"] and not reproduction["extension"]["pageReasonB"]

    cli = (ROOT / "CLI/relay.py").read_text()
    chromium = ROOT / "Extension/shared/publication-site.js"
    firefox = ROOT / "Extension/Firefox/shared/publication-site.js"
    assert chromium.read_bytes() == firefox.read_bytes()
    site = chromium.read_text()
    for text in (
        "Curator’s reason for this folder:",
        "not a ProgRSS safety claim",
        "sourceNotes",
        "white-space:pre-wrap",
        'dir="auto"',
    ):
        assert text in site, text
        assert text in cli, text
    for text in ("escapeHtml(reason)", "sourceNoteReason(member)"):
        assert text in site, text
    assert "html.escape(reason)" in cli

    audit = {
        "schema": "progrss.source-notes-publication-disclosure-audit.v1",
        "revision": REVISION,
        "parent": {"archive": PARENT, "sha256": PARENT_SHA},
        "pass": True,
        "reproduction": {
            "cliNativeReasonsPreserved": True,
            "cliHtmlReasonsOmitted": True,
            "extensionNativeReasonsPreserved": True,
            "extensionHtmlReasonsOmitted": True,
            "opmlOmissionExpected": True,
        },
        "candidate": {
            "cliFocusedTests": 4,
            "browserPackageVariants": 2,
            "casesPerVariant": 12,
            "sameSourceDifferentFolderReasons": True,
            "absentReasonOmitted": True,
            "htmlEscaped": True,
            "multilinePreserved": True,
            "directionAuto": True,
            "curatorAttribution": True,
            "nonSafetyClaimDisclosure": True,
            "nativeJsonPreserved": True,
            "opmlStillOmitsReasons": True,
            "chromiumFirefoxSharedBytesEqual": True,
            "publicationModuleSha256": digest(chromium),
        },
        "nonclaims": [
            "installed-browser acceptance",
            "unmanaged current-browser acceptance",
            "participant comprehension",
            "privacy comprehension",
            "assistive-technology acceptance",
            "accessibility conformance",
        ],
    }
    (ROOT / "SOURCE-NOTES-PUBLICATION-DISCLOSURE-AUDIT.json").write_text(
        json.dumps(audit, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
    )
    (ROOT / "SOURCE-NOTES-PUBLICATION-DISCLOSURE-AUDIT.md").write_text(
        f"""# Source Notes publication-disclosure audit — rev0098

- Parent: `{PARENT}`
- Parent SHA-256: `{PARENT_SHA}`
- Parent CLI and Extension native JSON preserved two placement reasons while the generated recipient HTML omitted both: **REPRODUCED**.
- CLI focused publication tests: **4 passed** (three dedicated tests plus the shipped command-path test).
- Shared browser-module corpus: **12 checks per package variant**, Chromium source and generated Firefox.
- Same source / two folders: distinct reasons remain attached to the correct routes.
- Missing reason: no invented visual note.
- Generated text: HTML-escaped, multiline-preserving, `dir=auto`, narrow-width reflow.
- Meaning: curator authorship is named and the note is explicitly not a ProgRSS safety claim.
- Native JSON: unchanged and authoritative.
- OPML: still omits Source Notes; README explains the loss.
- Chromium/Firefox shared publication module bytes: **IDENTICAL**.

These are native and managed regression results, not installed-browser, participant, privacy-comprehension, assistive-technology, or accessibility-conformance evidence.
"""
    )
    print(json.dumps(audit, sort_keys=True))


if __name__ == "__main__":
    main()
