#!/usr/bin/env python3
"""Prebuild validation for rev0106."""
from __future__ import annotations

import json
import py_compile
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0106-relay-workspace-source-note-integrity"
PARENT = "ProgRSS-rev0105-node-private-library-source-note-integrity-2026.10.22-Roadcase.zip"
PARENT_SHA = "e34cb801d87dd7e4c8bf26cf72ce25e6356af68d20818140691889a59c19dd6c"
EXPECTED_LINEAGE = (
    "Continues the sealed rev0105 unified whole-product tree and corrects a reproduced Relay workspace "
    "Source Note validation bypass. The shared-folder share, publish, import, review, explicit publication-check, "
    "and update commands now use the same private-placement audit before state use and before derived workspace writes. "
    "The current parent already contains the unified Node private-library, private-transfer, Exchange, Node branch and "
    "merge, shared-folder merge, publication, Lineage, Workbench collection and backup, repair, concurrency, Undo, "
    "native-integrity, and runtime-record work. No missing revision is invented."
)


def main() -> int:
    assert (ROOT / "REVISION").read_text(encoding="utf-8").strip() == REVISION
    state = json.loads((ROOT / "REVISION-STATE.json").read_text(encoding="utf-8"))
    assert state["revision"] == REVISION and state["releaseGateClosed"] is False
    assert state["claims"]["cliChanged"] is True and state["claims"]["extensionChanged"] is False

    cases = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text(encoding="utf-8"))
    assert cases["revision"] == REVISION and len(cases["cases"]) == 18 and len({item["id"] for item in cases["cases"]}) == 18
    two = next(item for item in cases["cases"] if item["id"] == "two-folder-independence")
    assert "Relay workspace commands apply the same audit" in two["description"]
    assert "explicit publication checks" in two["description"]

    sys.path.insert(0, str(ROOT / "tools"))
    from source_notes_runtime_evidence import REVISION as EVIDENCE_REVISION, case_catalog
    assert EVIDENCE_REVISION == REVISION and case_catalog() == cases
    schema = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-RESULT.schema.json").read_text(encoding="utf-8"))
    assert schema["properties"]["revision"]["const"] == REVISION

    audit = json.loads((ROOT / "SOURCE-NOTES-RELAY-WORKSPACE-INTEGRITY-AUDIT.json").read_text(encoding="utf-8"))
    continuity = json.loads((ROOT / "PRODUCT-CONTINUITY-AUDIT.json").read_text(encoding="utf-8"))
    integration = json.loads((ROOT / "INTEGRATION-AUDIT.json").read_text(encoding="utf-8"))
    assert audit["revision"] == REVISION and audit["status"] == "focused-pass"
    assert audit["reproduction"]["defectReproduced"] is True and audit["reproduction"]["malformedReasonCodePoints"] == 281
    assert audit["correction"]["sharedBoundary"] == "CLI/relay.py::read_workspace"
    assert audit["correction"]["validateBeforeWorkspaceWrite"] is True
    assert audit["correction"]["networkAuthorityAdded"] is False
    assert continuity["revision"] == REVISION and continuity["status"] == "pass"
    assert continuity["cliChanged"] is True and continuity["extensionChanged"] is False
    assert continuity["permissionsExpanded"] is False and continuity["newNetworkAuthority"] is False
    assert integration["revision"] == REVISION and integration["status"] == "pass"

    provenance = json.loads((ROOT / "RECONSTRUCTION_PROVENANCE.json").read_text(encoding="utf-8"))
    assert provenance["reconstructionRevision"] == REVISION
    assert provenance["immediateParentArchive"] == PARENT and provenance["immediateParentSha256"] == PARENT_SHA
    assert provenance["lineageClaim"] == EXPECTED_LINEAGE

    status = json.loads((ROOT / "evidence/rev0106/regression-status.json").read_text(encoding="utf-8"))
    assert status["complete"] and status["allPassed"]
    labels = {row["label"]: row for row in status["rows"]}
    required = {
        "cli-test_source_notes_relay_workspace",
        "cli-test_relay",
        "cli-test_source_notes_node_private_library",
        "cli-test_source_notes_private_transfer",
        "extension-static",
        "extension-browser-smoke",
        "extension-complete",
        "evidence-boundary",
        "contract",
        "workbench-private-backup-chromium",
        "workbench-private-backup-firefox",
    }
    assert required <= set(labels) and all(labels[label]["returncode"] == 0 for label in required)
    assert sum(int(row.get("tests") or 0) for row in status["rows"] if row["label"].startswith("cli-")) >= 209
    assert status["managedNodeHarnessInvocations"] == 22

    relay = (ROOT / "CLI/relay.py").read_text(encoding="utf-8")
    assert "validate_private_source_note_placements(location.state)" in relay
    assert "Relay refused to write invalid Source Notes" in relay
    assert relay.count("read_workspace(args.backup)") == 6

    focused = subprocess.run(
        [sys.executable, str(ROOT / "tools/verify-rev0106-relay-workspace-integrity.py")],
        cwd=ROOT, check=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=1800,
    )
    assert "PASS rev0106 focused replay" in focused.stdout

    for rel in (
        "tools/run-rev0106-regressions.py",
        "tools/verify-rev0106-relay-workspace-integrity.py",
        "tools/audit-rev0106-product-continuity.py",
        "tools/update-rev0106-provenance.py",
        "tools/write-rev0106-authority.py",
        "tools/prebuild-validate-rev0106.py",
        "tools/build-rev0106-roadcase.py",
        "CLI/tests/test_source_notes_relay_workspace.py",
    ):
        path = ROOT / rel
        assert path.is_file(), rel
        py_compile.compile(str(path), doraise=True)

    for path in ROOT.rglob("*.json"):
        if "node_modules" not in path.parts:
            json.loads(path.read_text(encoding="utf-8"))
    for rel in ("Extension/shared/core.js", "Extension/background.js", "Extension/workbench/scripts/progrss-app.js"):
        subprocess.run(["node", "--check", str(ROOT / rel)], check=True)
    assert not [path for path in ROOT.rglob("*.pyc") if "__pycache__" not in path.parts]
    print("PASS rev0106 prebuild validation: Relay workspace ingress/egress placement audit, complete regressions, 18-case binding, provenance, JSON, Python, and Node syntax.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
