#!/usr/bin/env python3
"""Focused rev0098 native/managed gate; not target-host runtime acceptance."""
from __future__ import annotations

import importlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0098-source-notes-publication-disclosure"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"


def run(label: str, command: list[str], *, extra: dict[str, str] | None = None, timeout: int = 180) -> None:
    print(f"\n== {label} ==", flush=True)
    completed = subprocess.run(command, cwd=ROOT, env=dict(os.environ, **(extra or {})), text=True,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
    print(completed.stdout.rstrip(), flush=True)
    if completed.returncode:
        raise RuntimeError(f"{label}: exit {completed.returncode}")


def main() -> None:
    run("cross-runtime Source Notes contract", ["sh", "tools/verify-source-notes-contract.sh"])
    run("native placement and publication disclosure", [
        sys.executable, "-m", "unittest", "-v",
        "CLI.tests.test_source_notes_entrypoints",
        "CLI.tests.test_source_notes_publication_site",
        "CLI.tests.test_command_line.CommandLineTests.test_publication_site_commands_are_offline_script_free_and_no_overwrite",
    ])
    run("Chromium shared publication module", ["node", "Extension/tests/source_notes_publication_site_harness.js"])
    run("generated Firefox shared publication module", ["node", "Extension/tests/source_notes_publication_site_harness.js"], extra={"PROGRSS_EXTENSION_ROOT": "Firefox"})
    run("Chromium native entrypoint continuity", ["node", "Extension/tests/source_notes_entrypoints_harness.js"])
    run("Firefox native entrypoint continuity", ["node", "Extension/tests/source_notes_entrypoints_harness.js"], extra={"PROGRSS_EXTENSION_ROOT": "Firefox"})
    run("production background continuity", ["node", "Extension/tests/background_harness.js"])
    run("publication disclosure audit", [sys.executable, "tools/audit-source-notes-publication-disclosure.py"])

    sys.path.insert(0, str(ROOT / "tools"))
    inherited = importlib.import_module("verify-rev0086-source-notes")
    inherited.verify_permissions()
    inherited.verify_generated_firefox()
    from source_notes_runtime_evidence import REVISION as runtime_revision, case_catalog

    assert runtime_revision == REVISION
    assert json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text()) == case_catalog()
    assert len(case_catalog()["cases"]) == 18
    state = json.loads((ROOT / "REVISION-STATE.json").read_text())
    assert state["revision"] == REVISION and not state["releaseGateClosed"]
    assert not state["claims"]["installedBrowserRuntimeThisTurn"]
    reproduction = json.loads((ROOT / "evidence/rev0098/parent-publication-source-note-omission.json").read_text())
    assert reproduction["reproduced"] is True
    audit = json.loads((ROOT / "SOURCE-NOTES-PUBLICATION-DISCLOSURE-AUDIT.json").read_text())
    assert audit["pass"] is True
    assert audit["candidate"]["cliFocusedTests"] == 4
    assert audit["candidate"]["browserPackageVariants"] == 2
    assert audit["candidate"]["casesPerVariant"] == 12
    assert (ROOT / "Extension/shared/publication-site.js").read_bytes() == (ROOT / "Extension/Firefox/shared/publication-site.js").read_bytes()
    two_folder = next(row for row in case_catalog()["cases"] if row["id"] == "two-folder-independence")
    complete = next(row for row in case_catalog()["cases"] if row["id"] == "complete-route-disclosure")
    assert "ready-to-host HTML" in two_folder["description"]
    assert "ready-to-host HTML" in complete["description"]
    print("\nPASS focused ready-to-host placement-reason disclosure gate.")
    print("Installed browsers, unmanaged current channels, participants and real AT: NOT RUN.")


if __name__ == "__main__":
    try:
        main()
    except (AssertionError, RuntimeError, OSError, subprocess.SubprocessError) as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)
