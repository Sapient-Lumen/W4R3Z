#!/usr/bin/env python3
"""Focused rev0096 native/managed gate; not target-host runtime acceptance."""
from __future__ import annotations

import importlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0096-source-notes-workbench-preservation"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"


def run(label: str, command: list[str], *, cwd: Path = ROOT, extra: dict[str, str] | None = None, timeout: int = 900) -> None:
    print(f"\n== {label} ==", flush=True)
    completed = subprocess.run(
        command,
        cwd=cwd,
        env=dict(os.environ, **(extra or {})),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
    )
    print(completed.stdout.rstrip(), flush=True)
    if completed.returncode:
        raise RuntimeError(f"{label}: exit {completed.returncode}")


def main() -> None:
    run("cross-runtime Source Notes contract", ["sh", "tools/verify-source-notes-contract.sh"])
    run(
        "native placement, CLI authoring, and repair semantics",
        [
            sys.executable,
            "-m",
            "unittest",
            "-v",
            "CLI.tests.test_source_notes_entrypoints",
            "CLI.tests.test_source_repair_notes",
            "CLI.tests.test_command_line.CommandLineTests.test_workspace_source_note_edits_one_direct_placement_offline",
        ],
    )
    run(
        "Node reviewed branch and merge",
        [
            sys.executable,
            "-m",
            "unittest",
            "-v",
            "CLI.tests.test_node_server.NodeServerTests.test_node_owned_branch_operation_is_reviewed_atomic_idempotent_and_snapshot_backed",
            "CLI.tests.test_node_server.NodeServerTests.test_merge_review_is_three_way_read_only_and_requires_admin_origin",
        ],
    )
    for family in ("", "Firefox"):
        env = {"PROGRSS_EXTENSION_ROOT": family} if family else {}
        label = family or "Chromium-source"
        for harness in (
            "source_notes_folder_remove_harness.js",
            "source_notes_saturated_concurrency_harness.js",
            "source_notes_folder_undo_harness.js",
            "source_notes_source_repair_harness.js",
            "source_notes_entrypoints_harness.js",
        ):
            run(f"{label} {harness}", ["node", f"Extension/tests/{harness}"], extra=env)
        root = ROOT / "Extension" / family if family else ROOT / "Extension"
        run(
            f"{label} Advanced Workbench placement preservation",
            [
                sys.executable,
                "Extension/tests/source_notes_workbench_collection_harness.py",
                "--root",
                str(root),
                "--artifacts",
                str(ROOT / "evidence" / "rev0096" / f"focused-{label.lower()}"),
            ],
        )
    run("production background continuity", ["node", "Extension/tests/background_harness.js"])
    run("Workbench preservation audit", [sys.executable, "tools/audit-source-notes-workbench-preservation.py"])

    sys.path.insert(0, str(ROOT / "tools"))
    inherited = importlib.import_module("verify-rev0086-source-notes")
    inherited.verify_permissions()
    inherited.verify_generated_firefox()
    from source_notes_runtime_evidence import REVISION as runtime_revision, case_catalog

    assert runtime_revision == REVISION
    assert json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text()) == case_catalog()
    assert len(case_catalog()["cases"]) == 18
    two_folder = next(row for row in case_catalog()["cases"] if row["id"] == "two-folder-independence")
    assert "Advanced Workbench" in two_folder["description"]
    assert "newly selected sources" in two_folder["description"]
    state = json.loads((ROOT / "REVISION-STATE.json").read_text())
    assert state["revision"] == REVISION and not state["releaseGateClosed"]
    assert not state["claims"]["installedBrowserRuntimeThisTurn"]
    reproduction = json.loads((ROOT / "evidence/rev0096/parent-workbench-source-note-loss.json").read_text())
    assert reproduction["parentErasedAllReasonsInEditedCollection"] is True
    audit = json.loads((ROOT / "SOURCE-NOTES-WORKBENCH-PRESERVATION-AUDIT.json").read_text())
    assert audit["pass"] is True
    assert audit["candidate"]["chromiumCases"] == 11
    assert audit["candidate"]["firefoxCases"] == 11
    assert (ROOT / "Extension/workbench/scripts/progrss-app.js").read_bytes() == (
        ROOT / "Extension/Firefox/workbench/scripts/progrss-app.js"
    ).read_bytes()
    print("\nPASS focused Workbench placement-reason preservation gate.")
    print("Installed browsers, unmanaged current channels, participants and real AT: NOT RUN.")


if __name__ == "__main__":
    try:
        main()
    except (AssertionError, RuntimeError, OSError, subprocess.SubprocessError) as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)
