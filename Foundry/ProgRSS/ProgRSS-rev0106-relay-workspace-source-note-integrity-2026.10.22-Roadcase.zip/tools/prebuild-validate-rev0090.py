#!/usr/bin/env python3
"""Static checks and explicit claim-scope checks for the rev0090 candidate."""
from __future__ import annotations
import ast
import importlib
import json
from pathlib import Path
import stat
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
old = importlib.import_module("prebuild-validate-rev0089")


def main():
    counts = {}
    for path in old.files(".json"):
        json.loads(path.read_text())
    counts["json"] = len(old.files(".json"))
    for path in old.files(".py"):
        ast.parse(path.read_text(), filename=str(path))
    counts["python"] = len(old.files(".py"))
    js = old.files(".js") + old.files(".mjs")
    for path in js:
        subprocess.run(["node", "--check", str(path)], check=True, cwd=ROOT, timeout=30,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    counts["javascript"] = len(js)
    for path in old.files(".html"):
        parser = old.Parser(convert_charrefs=True)
        parser.feed(path.read_text()); parser.close()
    counts["html"] = len(old.files(".html"))
    for path in old.files(".css"):
        old.validate_css(path)
    counts["css"] = len(old.files(".css"))
    inherited = importlib.import_module("verify-rev0086-source-notes")
    inherited.verify_permissions(); inherited.verify_generated_firefox()
    from source_notes_runtime_evidence import REVISION, case_catalog
    assert json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text()) == case_catalog()
    state = json.loads((ROOT / "REVISION-STATE.json").read_text())
    audit = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.json").read_text())
    matrix = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-MATRIX.json").read_text())
    provenance = json.loads((ROOT / "RECONSTRUCTION_PROVENANCE.json").read_text())
    assert state["revision"] == REVISION == provenance["reconstructionRevision"]
    assert provenance["immediateParentSha256"] == "65df45a95bfa9d917a0053f4d81d1a4d317119945e3139746359eeb6269b58fd"
    assert audit["pass"] and audit["unitTests"] == 40 and not audit["releaseGateClosed"]
    assert not matrix["releaseGateClosed"] and matrix["summary"] == {"pass": 3, "blocked": 1, "notRun": 5, "notEstablished": 0}
    for name, value in state["claims"].items():
        if name not in {"verifiedBundleComparison", "nativeArtifactHashesDerivedFromBytes", "missingEvidenceNeverEquality", "browserChannelPayloadBinding", "channelVersionDerivedFromBoundBytes", "channelSnapshotFreshnessRequiredForPass"}:
            assert value is False, f"unsupported claim: {name}"
    assert (ROOT / "BOOTSTRAPROSE.md").read_text().startswith("# `/run` authority — rev0090")
    assert (ROOT / "history/BOOTSTRAPROSE-through-rev0089.md").is_file()
    for name in ("build-reconstruction-roadcase.py", "verify-rev0090-source-notes.py", "prebuild-validate-rev0090.py",
                 "compare-source-notes-runtime-evidence.py", "runtime_native_artifacts.py", "run-rev0090-cli-modules.py"):
        assert stat.S_IMODE((ROOT / "tools" / name).stat().st_mode) & 0o111, name
    print(json.dumps({"pass": True, "revision": REVISION, "syntaxCounts": counts,
                      "permissionProjectionUnchanged": True, "releaseGateClosed": False}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
