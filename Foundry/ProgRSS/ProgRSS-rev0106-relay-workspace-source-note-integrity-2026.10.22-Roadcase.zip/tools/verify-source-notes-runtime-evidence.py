#!/usr/bin/env python3
"""Verify a finalized Source Notes runtime evidence bundle."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from source_notes_runtime_evidence import EvidenceError, canonical_json_bytes, verify_evidence_bundle


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bundle", type=Path, required=True)
    parser.add_argument("--roadcase", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        root = Path(__file__).resolve().parents[1]
        result = verify_evidence_bundle(
            args.bundle,
            roadcase=args.roadcase,
            verifier=root / "VERIFY-ROADCASE.py",
        )
        if args.output:
            output = args.output.resolve()
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_bytes(canonical_json_bytes(result))
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        return 0
    except (EvidenceError, OSError, ValueError) as error:
        print(f"runtime evidence verification failed: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
