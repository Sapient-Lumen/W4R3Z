#!/usr/bin/env python3
"""Build and independently replay the deterministic rev0106 Roadcase."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[1]
FIXED_TIME = (2026, 10, 22, 0, 0, 0)
MANIFEST_NAME = "ROADCASE-MANIFEST.json"
REVISION = "rev0106-relay-workspace-source-note-integrity"
DEFAULT_NAME = "ProgRSS-rev0106-relay-workspace-source-note-integrity-2026.10.22-Roadcase.zip"
DEFAULT_REPORT = "ProgRSS-rev0106-relay-workspace-source-note-integrity-2026.10.22-BUILD-REPORT.md"
SKIP_DIRS = {".git", "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"}
SKIP_NAMES = {MANIFEST_NAME, ".DS_Store"}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_mode(path: Path) -> int:
    mode = stat.S_IMODE(path.lstat().st_mode)
    if path.is_symlink():
        return 0o777
    return 0o755 if mode & 0o111 else 0o644


def safe_relative_link(path: Path) -> str:
    target = os.readlink(path)
    target_path = PurePosixPath(target)
    if target_path.is_absolute():
        raise ValueError(f"absolute symlink is not allowed: {path}")
    resolved = (path.parent / target).resolve(strict=False)
    try:
        resolved.relative_to(ROOT.resolve())
    except ValueError as exc:
        raise ValueError(f"symlink escapes Roadcase root: {path} -> {target}") from exc
    return target


def include_path(path: Path) -> bool:
    rel = path.relative_to(ROOT)
    if any(part in SKIP_DIRS for part in rel.parts):
        return False
    if path.name in SKIP_NAMES or path.suffix == ".pyc":
        return False
    if path.name.endswith(".zip") or path.name.endswith(".sha256"):
        return False
    return path.is_file() or path.is_symlink()


def collect_entries() -> tuple[list[dict[str, object]], dict[str, bytes]]:
    entries: list[dict[str, object]] = []
    payloads: dict[str, bytes] = {}
    for path in sorted(ROOT.rglob("*"), key=lambda value: value.relative_to(ROOT).as_posix()):
        if not include_path(path):
            continue
        name = path.relative_to(ROOT).as_posix()
        if path.is_symlink():
            data = safe_relative_link(path).encode("utf-8")
            kind = "symlink"
        else:
            data = path.read_bytes()
            kind = "file"
        mode = canonical_mode(path)
        payloads[name] = data
        entries.append({"path": name, "kind": kind, "mode": oct(mode), "bytes": len(data), "sha256": sha256_bytes(data)})
    return entries, payloads


def manifest_bytes(entries: list[dict[str, object]]) -> bytes:
    provenance = json.loads((ROOT / "RECONSTRUCTION_PROVENANCE.json").read_text(encoding="utf-8"))
    manifest = {
        "format": "ProgRSS Roadcase Manifest v1",
        "revision": REVISION,
        "builtUtc": "2026-10-22T00:00:00Z",
        "productLineage": {"revision": "rev0080", "version": "0.80.0"},
        "sourceArchive": provenance.get("rootBaselineArchive"),
        "sourceArchiveSha256": provenance.get("rootBaselineSha256"),
        "immediateParentArchive": provenance.get("immediateParentArchive"),
        "immediateParentSha256": provenance.get("immediateParentSha256"),
        "integrationDonor": provenance.get("integrationDonor"),
        "mergeBase": provenance.get("mergeBase"),
        "files": entries,
    }
    return (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def directory_names(file_names: set[str]) -> list[str]:
    directories: set[str] = set()
    for name in file_names:
        parent = PurePosixPath(name).parent
        while parent != PurePosixPath("."):
            directories.add(parent.as_posix() + "/")
            parent = parent.parent
    return sorted(directories)


def make_info(name: str, mode: int, kind: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, FIXED_TIME)
    info.create_system = 3
    info.compress_type = zipfile.ZIP_DEFLATED
    info.flag_bits |= 0x800
    if kind == "dir":
        info.external_attr = ((stat.S_IFDIR | mode) << 16) | 0x10
    elif kind == "symlink":
        info.external_attr = (stat.S_IFLNK | mode) << 16
    else:
        info.external_attr = (stat.S_IFREG | mode) << 16
    return info


def build_zip(destination: Path) -> dict[str, object]:
    entries, payloads = collect_entries()
    payloads[MANIFEST_NAME] = manifest_bytes(entries)
    entry_by_name = {str(item["path"]): item for item in entries}
    names = set(payloads)
    all_names = sorted(set(directory_names(names)) | names)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, strict_timestamps=True) as archive:
        archive.comment = b""
        for name in all_names:
            if name.endswith("/"):
                archive.writestr(make_info(name, 0o755, "dir"), b"", compress_type=zipfile.ZIP_STORED)
                continue
            if name == MANIFEST_NAME:
                mode, kind = 0o644, "file"
            else:
                item = entry_by_name[name]
                mode, kind = int(str(item["mode"]), 8), str(item["kind"])
            archive.writestr(make_info(name, mode, kind), payloads[name], compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return {"entries": len(entries), "archiveBytes": destination.stat().st_size, "archiveSha256": sha256_file(destination)}


def safe_extract(archive_path: Path, destination: Path) -> None:
    with zipfile.ZipFile(archive_path) as archive:
        seen: set[str] = set()
        for info in archive.infolist():
            if info.filename in seen:
                raise ValueError(f"duplicate member: {info.filename}")
            seen.add(info.filename)
            name = info.filename.rstrip("/")
            parts = PurePosixPath(name).parts
            if not name or PurePosixPath(name).is_absolute() or ".." in parts:
                raise ValueError(f"unsafe member: {info.filename!r}")
            target = destination.joinpath(*parts)
            raw_mode = (info.external_attr >> 16) & 0xFFFF
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                os.chmod(target, stat.S_IMODE(raw_mode) or 0o755)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            data = archive.read(info)
            if stat.S_ISLNK(raw_mode):
                link = data.decode("utf-8")
                link_path = PurePosixPath(link)
                if link_path.is_absolute() or ".." in link_path.parts:
                    raise ValueError(f"unsafe symlink target: {info.filename!r}")
                target.symlink_to(link)
            else:
                target.write_bytes(data)
                os.chmod(target, stat.S_IMODE(raw_mode))


def compare_source_to_extraction(entries: list[dict[str, object]], extraction: Path) -> int:
    for item in entries:
        source = ROOT / str(item["path"])
        extracted = extraction / str(item["path"])
        if item["kind"] == "symlink":
            source_data = os.readlink(source).encode("utf-8")
            extracted_data = os.readlink(extracted).encode("utf-8")
        else:
            source_data = source.read_bytes()
            extracted_data = extracted.read_bytes()
        if source_data != extracted_data:
            raise RuntimeError(f"clean extraction byte mismatch: {item['path']}")
        if canonical_mode(source) != stat.S_IMODE(extracted.lstat().st_mode):
            raise RuntimeError(f"clean extraction mode mismatch: {item['path']}")
    return len(entries)


def run(command: list[str], cwd: Path, timeout: int = 1800) -> str:
    completed = subprocess.run(command, cwd=cwd, env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"), text=True,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=True, timeout=timeout)
    return completed.stdout


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("/mnt/data") / DEFAULT_NAME)
    parser.add_argument("--report", type=Path, default=Path("/mnt/data") / DEFAULT_REPORT)
    args = parser.parse_args()
    output = args.output.resolve()
    report = args.report.resolve()
    entries, _ = collect_entries()
    regression = json.loads((ROOT / "evidence/rev0106/regression-status.json").read_text(encoding="utf-8"))
    if not regression.get("complete") or not regression.get("allPassed"):
        raise RuntimeError("complete passing rev0106 regressions are required before build")
    with tempfile.TemporaryDirectory(prefix="progrss-rev0106-build-") as temporary_name:
        temporary = Path(temporary_name)
        first = temporary / "first.zip"
        second = temporary / "second.zip"
        first_meta = build_zip(first)
        second_meta = build_zip(second)
        if first.read_bytes() != second.read_bytes() or first_meta != second_meta:
            raise RuntimeError("two independent deterministic builds differ")
        archive_verification = run([sys.executable, str(ROOT / "VERIFY-ROADCASE.py"), "--archive", str(first)], ROOT)
        extraction = temporary / "clean-extraction"
        extraction.mkdir()
        safe_extract(first, extraction)
        tree_verification = run([sys.executable, str(extraction / "VERIFY-ROADCASE.py")], extraction)
        compared = compare_source_to_extraction(entries, extraction)
        focused_replay = run([sys.executable, str(extraction / "tools/verify-rev0106-relay-workspace-integrity.py")], extraction)
        doctor = run([str(extraction / "CLI/progrss"), "doctor"], extraction / "CLI")
        shutil.copyfile(first, output)
        os.chmod(output, 0o644)
    digest = sha256_file(output)
    sha_path = output.with_suffix(output.suffix + ".sha256")
    sha_path.write_text(f"{digest}  {output.name}\n", encoding="utf-8")
    os.chmod(sha_path, 0o644)
    cli_tests = sum(int(row.get("tests") or 0) for row in regression["rows"] if str(row.get("label", "")).startswith("cli-"))
    body = f"""# Roadcase build report — rev0106

- Candidate: `{REVISION}`
- Product lineage: `rev0080` / `0.80.0`
- Output: `{output.name}`
- SHA-256: `{digest}`
- Bytes: {output.stat().st_size}
- Manifested source entries: {first_meta['entries']}
- First/second build byte comparison: PASS
- Direct ZIP manifest byte/mode verification: PASS
- Clean extraction manifest byte/mode verification: PASS
- Source-to-clean-extraction byte/mode comparison: PASS ({compared} entries)
- Focused Relay workspace ingress/egress Source Note audit, all six Relay commands, valid route-specific preservation, and private-transfer parity replay from clean extraction: PASS
- Complete prebuild regression status: PASS ({cli_tests} CLI tests plus managed Node/Extension/UI and evidence-boundary rows)
- Clean-extraction CLI doctor: PASS
- Exact final-Roadcase target-browser triad: NOT RUN
- Human permission-prompt, participant, privacy, and assistive-technology fieldwork: NOT RUN
- No enterprise browser policy changed

## Archive verifier

```text
{archive_verification.strip()}
```

## Extracted-tree verifier

```text
{tree_verification.strip()}
```

## Focused replay from clean extraction

```text
{focused_replay.strip()}
```

## CLI doctor from clean extraction

```text
{doctor.strip()}
```
"""
    report.write_text(body, encoding="utf-8")
    print(body)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
