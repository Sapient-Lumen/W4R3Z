#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REV='rev0102-node-merge-source-note-disclosure'
PARENT='ProgRSS-rev0101-unified-exchange-transfer-disclosure-2026.10.22-Roadcase.zip'
PARENT_SHA='5025ea9b20f0a09ea84bd364ccae884b6fc448ea995dd6413d4bdd5e24c55195'

def write(name:str,text:str)->None:
    (ROOT/name).write_text(text.rstrip()+"\n",encoding='utf-8')

def dump(name:str,obj:object)->None:
    (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding='utf-8')

write('BOOTSTRAPROSE.md',f'''# BOOTSTRAPROSE — current `/run` authority

**Candidate:** `{REV}` · **Date:** 2026-10-22 · **Product lineage:** rev0080 / 0.80.0.

## Authority and lineage

This tree continues the sealed rev0101 unified candidate and corrects one reproduced loopback Node review defect. It does not represent rev0081, rev0082, or the undelivered browser-execution-binding source archive as recovered.

- Immediate parent: `{PARENT}` · `{PARENT_SHA}`
- The parent’s private-transfer integration, Exchange disclosure, Node branch disclosure, publication, Lineage, Workbench, repair, concurrency, Undo, native-integrity, and runtime-record corrections remain present.
- The release gate remains open. Managed tests and deterministic archives do not substitute for actual target-host browsers, unfamiliar people, privacy review, or real assistive technologies.

## P0.0 — completed in this candidate

- Reproduce the native three-way review omission: placement conflicts exposed only a repeated folder title, not the full direct folder route.
- Reproduce the shipped Node UI omission independently: even when supplied correct paths, it did not display them, collapsed Source Note line breaks, used generic comparison labels, and omitted curator/non-safety wording.
- Add the canonical incoming folder path to every Source Note merge row and placement descriptor.
- Distinguish one source in two identically named folders by full route.
- Render last accepted, local, and curator placement reasons literally with preserved line breaks, wrapping, and `dir="auto"`.
- Label the values **Last accepted curator reason**, **Keep mine**, and **Use curator’s**.
- State that the text is the curator’s reason for one direct folder/source placement and is not a ProgRSS safety claim.
- Keep the Node review read-only: no apply endpoint, source request, library write, persistent choice store, permission expansion, or new network authority.
- Keep the fixed runtime catalog at exactly 18 cases; extend the two existing divergent-copy cases rather than adding a nineteenth.

## P0.1 — exact package on the actual browser triad

Run fresh records from the sealed rev0102 Roadcase in:

1. Unmanaged then-current Chromium Stable.
2. Firefox Release.
3. Firefox ESR.

Capture fresh official channel evidence on each host. Do not relabel rev0101 or earlier sessions.

Run all 18 cases and the whole-product boundaries. In addition to every inherited Reader, Node, Exchange, private-transfer, Capture, Witness, Pulse, Trace, Workbench, Lineage, repair, conflict, stale-write, saturated-concurrency, Undo, publication, OPML, integrity, restart, and permission check, explicitly prove:

- Create two divergent Source Note conflicts for the same source in two different folders that share the same visible title.
- The Node three-way review shows the full canonical route for both placements before any separate apply surface is used.
- Last accepted, **Keep mine**, and **Use curator’s** values remain exact and placement-scoped.
- Multiline, bidirectional, and markup-like reason text is literal, wraps at narrow widths, and receives content-derived direction.
- Curator attribution and the non-safety boundary are visible.
- Closing or replacing the review does not retain an uncommitted choice.
- Review remains read-only and contacts no listed source.

Preserve first failures, interruptions, retries, and recovery—not only the eventual result. Firefox temporary loading remains development-runtime evidence and must not be interpreted as signed-install or restart acceptance.

## P0.2 — unfamiliar people, privacy, and real assistive technologies

Only after the exact browser triad passes:

- Ask unfamiliar recipients which direct folder relationship each conflicting reason belongs to.
- Ask what **Keep mine** and **Use curator’s** would do and whether the Node already applied either choice.
- Ask who wrote the reason and whether it is a safety claim.
- Compare sender, recipient, and diagnostic privacy evidence separately.
- Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions.
- Make only the smallest correction supported by recurring independent wrong turns.

## P1 — sharing and organization

- Test one-week delayed route re-finding before adding private labels or saved-view complexity.
- Keep folders human-curated and shareable; preserve **Unfiled** as legitimate.
- Keep Source Note wording out of engagement ranking and opaque recommendation systems.
- Do not expand Source Notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

- Keep remote mode explicit and separate from loopback.
- Require TLS, persistent Node identity, bounded hosts/requests/artifacts/rates, expiring invitations, and durable revocation evidence.
- Keep public publication routes separate from private APIs.
- No default public bind, silent LAN discovery, or UPnP.

## Lab — WebRTC courier

- Transfer exactly one reviewed immutable artifact.
- Preserve Source Notes through the native artifact.
- Make signaling, STUN, and TURN visible.
- Refuse replay, identity mismatch, digest mismatch, timeout, and partial completion.
- Destroy the session after the bounded transfer.
- Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## Change discipline

Do not add another evidence framework merely because target-host access is unavailable. Further product changes require a reproduced failure. Keep every nonclaim explicit.
''')

write('CURRENT-STATUS.md',f'''# Current status — {REV}

A verified correction candidate under test. It continues the unified rev0101 tree and fixes a reproduced omission in the loopback Node’s read-only three-way Source Note review: full folder routes, exact multiline/bidirectional values, explicit conflict labels, curator attribution, and the non-safety boundary are now visible. The release gate remains open for actual Chromium, Firefox Release, Firefox ESR, unfamiliar-person, privacy, and assistive-technology work. See `BOOTSTRAPROSE.md`.
''')

write('RESULT-SUMMARY.md',f'''# Result summary — rev0102 Node merge Source Note disclosure

The native later-copy review already carried placement-scoped Source Note conflicts, but it exposed only a folder title. The shipped Node UI then rendered the conflict through a generic comparison control that omitted the folder route, collapsed line breaks, lacked content-derived direction, and did not explain **Keep mine / Use curator’s** or the curator/non-safety boundary.

rev0102 adds the canonical incoming folder route to each Source Note merge row and renders a dedicated read-only placement comparison. One source can now have distinguishable conflicts in two identically named folders. Exact multiline, bidirectional, and markup-like values remain literal. No apply endpoint, network request, write authority, store, or permission was added.

The fixed runtime catalog remains 18 cases and is bound to rev0102. Complete regression and deterministic-build results are recorded by the detached final verification; target-host browser and human gates remain open.
''')

write('HANDOFF.md',f'''# Handoff — {REV}

Start with `BOOTSTRAPROSE.md`, `NODE-MERGE-SOURCE-NOTE-DISCLOSURE-AUDIT.md`, `PRODUCT-CONTINUITY-AUDIT.md`, the detached final verification, and the runtime matrix.

Preserve the full placement route in both the native merge row and the shipped Node UI. Do not fall back to a repeated folder title when the canonical route is available. Preserve exact reason text; do not route it through the whitespace-collapsing generic comparison formatter. The Node remains read-only and must not acquire an apply endpoint or persistent conflict-choice state.

Prepare fresh rev0102 session-v5 records from the exact sealed Roadcase; do not relabel earlier sessions. Next: run the complete 18-case and whole-product corpus on actual unmanaged then-current Chromium, Firefox Release, and Firefox ESR hosts, including two same-source conflicts in identically named folders. Then run separate unfamiliar-person, privacy, and real assistive-technology sessions. Do not substitute managed or preparation-only evidence.
''')

write('CHANGELOG-rev0102-node-merge-source-note-disclosure.md',f'''# Changelog — {REV}

- Added full canonical folder routes to placement-scoped Source Note merge rows.
- Added a dedicated shipped Node Source Note comparison with literal multiline/bidirectional rendering.
- Labeled the three values as Last accepted curator reason, Keep mine, and Use curator’s.
- Added curator attribution and the explicit non-safety boundary.
- Added a focused native/API plus shipped-UI harness covering two identically named folder routes.
- Kept the Node review read-only and retained the fixed 18-case catalog.
''')

node_audit={
 'schema':'progrss.source-notes.node-merge-disclosure-audit.v1','revision':REV,'status':'focused-pass',
 'parent':{'name':PARENT,'sha256':PARENT_SHA,'bytes':14541365},
 'reproduction':{
   'nativeFolderPathMissingBeforeFix':True,'repeatedFolderLabelsIndistinguishable':True,
   'shippedUiIgnoredFolderPathBeforeFix':True,'multilineCollapsedBeforeFix':True,
   'keepMineUseCuratorLabelsMissingBeforeFix':True,'curatorBoundaryMissingBeforeFix':True,
   'nonSafetyBoundaryMissingBeforeFix':True,
   'evidence':['evidence/rev0102/reproduction-parent-api.log','evidence/rev0102/parent-node-merge-before-fix.json','evidence/rev0102/parent-node-merge-before-fix.png']
 },
 'correction':{
   'canonicalFolderPath':True,'sameTitleRoutesDistinguished':True,'literalText':True,
   'multilinePreserved':True,'automaticDirection':True,'keepMineLabel':True,'useCuratorLabel':True,
   'curatorAttribution':True,'nonSafetyBoundary':True,'readOnly':True,'network':False,'writes':False
 },
 'focusedTests':{'apiUnit':'pass','shippedNodeUi':'pass','sourceNoteConflicts':2},
 'permissionsExpanded':False,'newPersistentStore':False,'newNetworkAuthority':False
}
dump('NODE-MERGE-SOURCE-NOTE-DISCLOSURE-AUDIT.json',node_audit)
write('NODE-MERGE-SOURCE-NOTE-DISCLOSURE-AUDIT.md',f'''# Node three-way Source Note disclosure audit — rev0102

The rev0101 native merge review identified Source Note conflicts by source and repeated folder title, but not by the full direct folder route. The shipped Node UI independently omitted the route even when supplied correct paths, collapsed multiline values through the generic formatter, and omitted explicit **Keep mine / Use curator’s**, curator attribution, and non-safety wording.

The corrected native row includes `folderPath` both at the top level and in the placement descriptor. The shipped review renders a dedicated Source Note card with the full route, exact literal values, preserved line breaks, wrapping, and `dir="auto"`. Two conflicts for the same source in `Civic route › North › Updates` and `Civic route › South › Updates` are distinguishable.

Focused API and shipped-UI tests passed. The Node remains read-only: no apply endpoint, source request, library write, persistent conflict-choice state, browser permission, or network authority was added.
''')

# Current integration summary while preserving inherited audit detail elsewhere.
dump('INTEGRATION-AUDIT.json',{
 'schema':'progrss.integration-audit.v1','revision':REV,'status':'pass',
 'parent':{'name':PARENT,'sha256':PARENT_SHA,'bytes':14541365},
 'inherited':{'rev0101UnifiedExchangePrivateTransfer':True,'rev0100NodeBranchDisclosure':True},
 'currentCorrection':'loopback Node three-way placement-route and exact Source Note disclosure',
 'missingArtifacts':['rev0081','rev0082','rev0090-source-notes-browser-execution-binding'],
 'releaseGateClosed':False
})
write('INTEGRATION-AUDIT.md',f'''# Integration audit — rev0102

rev0102 continues the sealed rev0101 unified tree byte-for-byte except for the focused loopback Node merge-review correction and its tests/docs. The parent’s private-transfer, Exchange, Node branch, publication, Lineage, Workbench, repair, concurrency, Undo, native-integrity, and evidence-validation work remains present. Rev0081, rev0082, and the undelivered browser-execution-binding source archive remain unavailable and are not represented as recovered.
''')

rows=[
 {'id':'unified-rev0101-parent','status':'pass','scope':'sealed rev0101 whole-product tree retained'},
 {'id':'node-merge-native-folder-route','status':'focused-pass','scope':'canonical full route in placement-scoped Source Note rows'},
 {'id':'node-merge-shipped-review','status':'focused-pass','scope':'managed shipped Node UI with exact values, route, direction, and boundaries'},
 {'id':'runtime-catalog-binding','status':'pass','scope':'18 cases; session v5/result v3; fresh rev0102 preparation required'},
 {'id':'complete-offline-regression','status':'pending'},
 {'id':'deterministic-seal','status':'external-postbuild-report-required'},
 {'id':'unmanaged-current-chromium','status':'not-run'},
 {'id':'firefox-release','status':'not-run'},
 {'id':'firefox-esr','status':'not-run'},
 {'id':'unfamiliar-curators-and-recipients','status':'not-run'},
 {'id':'separate-sender-recipient-diagnostic-privacy','status':'not-run'},
 {'id':'real-assistive-technologies','status':'not-run'},
]
dump('SOURCE-NOTES-RUNTIME-MATRIX.json',{'revision':REV,'releaseGateClosed':False,'inheritedEvidence':'Earlier records retain their original identities and scopes; exact rev0102 product bytes require fresh target-host sessions.','rows':rows})
write('SOURCE-NOTES-RUNTIME-MATRIX.md','# Source Notes runtime and release matrix — rev0102\n\n| Row | Status | Scope |\n|---|---|---|\n'+'\n'.join(f"| `{r['id']}` | **{r['status'].upper()}** | {r.get('scope','')} |" for r in rows)+'\n\nThe release gate remains open. Focused managed evidence does not close installed-browser or fieldwork rows.')

write('SOURCE-NOTES-RUNTIME-PROTOCOL.md',f'''# Source Notes runtime protocol — rev0102

The fixed catalog contains exactly 18 behavioral cases and is bound to `{REV}`. Sessions use `progrss.source-notes.runtime-session.v5`; results and predicates use v3. Older records retain their identities and may not be relabeled.

Before execution, verify the immutable Roadcase, selected browser package, fixture, official channel-source bytes, profile state, installation method, and permission-observation mode. Record one valid UTC interval containing every attempted case and event. Preserve first failures, interruptions, retries, recovery, actual native artifacts, and complete permission projections.

The two existing divergent-later-copy cases now include the read-only Node review. Create two conflicts for one source in identically named folders, verify the full routes, exact multiline/bidirectional values, Last accepted/Keep mine/Use curator’s labels, curator attribution, non-safety wording, read-only state, and zero listed-source contact. These additions do not create a nineteenth case.

Temporary Firefox loading is development-runtime evidence; restart and signed-install permission conclusions require an installation method that can actually exercise them.
''')

write('RUNTIME-OPERATOR-GUIDE.md',f'''# Runtime operator guide — rev0102

1. Use the sealed rev0102 Roadcase and record its SHA-256 before extraction.
2. Capture fresh official Stable/Release/ESR channel evidence on the execution host.
3. Prepare a new session-v5 record. Do not edit an older session’s revision.
4. Use a fresh unmanaged profile and record installation method and visible permissions.
5. Run all 18 cases, preserving first failures and recovery.
6. For the later-copy conflict cases, create two placement-reason conflicts for one source in two folders sharing the title `Updates` under distinct parent routes.
7. In the Node review, verify both full routes, exact three-way values, preserved line breaks, `dir="auto"`, literal markup-like text, **Keep mine / Use curator’s**, curator attribution, non-safety wording, no retained uncommitted choice, no write, and no listed-source contact.
8. Retain all inherited private-transfer, Exchange, branch, publication, Workbench, Lineage, repair, Undo, stale-write, integrity, OPML, restart, and permission evidence.
9. Finalize and independently verify each evidence ZIP against the same immutable Roadcase.
10. Compare Chromium Stable, Firefox Release, and Firefox ESR without treating platform differences as automatic failure or automatic acceptance.
''')

write('SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.md',f'''# Runtime-evidence audit — rev0102

- Fixed catalog: 18 cases.
- Revision binding: `{REV}`.
- Session schema: v5.
- Result/predicate: v3.
- Unknown claim-bearing fields refused.
- Valid UTC chronology required for attempted work.
- Complete permission projections required for a passing unchanged-permission case.
- Native artifact roles limited to complete route and selected branch.
- Full evidence ZIPs, not standalone statements, are comparison inputs.
- Fresh rev0102 preparation required; older records cannot be relabeled.

The two divergent-later-copy descriptions now include the Node’s full-route, exact-value, read-only Source Note review without increasing the case count. The complete regression result is populated after the full sweep.
''')
dump('SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.json',{
 'schema':'progrss.source-notes.runtime-evidence-audit.v1','revision':REV,'status':'pending-full-sweep',
 'cases':18,'sessionSchema':'v5','resultSchema':'v3','freshPreparationRequired':True,
 'changedCaseIds':['divergent-later-copy-keep-mine','divergent-later-copy-use-curator'],
 'standaloneStatementsAccepted':False,'unknownClaimFieldsAccepted':False,'targetBrowserAcceptance':False
})

write('SOURCE-NOTES-RUNTIME-ATTESTATION.md',f'''# Runtime attestation boundary — rev0102

Runtime evidence is unsigned consistency evidence. It binds result records, referenced evidence, package bytes, fixture bytes, and native artifacts to one prepared session and Roadcase. It does not authenticate the operator, wall clock, browser download service, human presence, unmanaged state, permission comprehension, accessibility, or participant understanding. Release acceptance still requires direct review of the target-host records and separate fieldwork.
''')

write('ROADCASE-SOURCE-NOTES-CHECKLIST.md',f'''# Roadcase Source Notes checklist — rev0102

## Native and local continuity

- [x] One optional reason per direct folder/source placement.
- [x] 280-code-point limit and Python/JavaScript parity.
- [x] Canonicalization, native integrity, disclosure, branch, OPML omission, three-way conflict, repair, Workbench, Lineage, publication, private transfer, stale-write, saturated-concurrency, and whole-placement Undo coverage.
- [x] Node branch and Exchange reviews disclose route-bound reasons.
- [x] Node three-way review distinguishes same-source conflicts by full canonical folder route and shows exact Last accepted / Keep mine / Use curator’s values.
- [x] Literal multiline/bidirectional rendering, curator attribution, and non-safety wording.
- [x] No automatic conflict winner.
- [x] No permission, pairing, schedule, notification, profile, remote-state, store, or network-authority expansion.

## Release blockers

- [ ] Exact sealed bytes on unmanaged then-current Chromium Stable.
- [ ] Exact sealed bytes on Firefox Release.
- [ ] Exact sealed bytes on Firefox ESR.
- [ ] Human-visible installation and permission observations.
- [ ] Unfamiliar sender, curator, and recipient comprehension.
- [ ] Separate sender, recipient, and diagnostic privacy review.
- [ ] Screen reader, Braille, voice, switch, high zoom/reflow, forced colors, reduced motion, fatigue, and interruption sessions.

Make only the smallest correction supported by a reproduced failure or recurring independent wrong turns.
''')

print(REV)
