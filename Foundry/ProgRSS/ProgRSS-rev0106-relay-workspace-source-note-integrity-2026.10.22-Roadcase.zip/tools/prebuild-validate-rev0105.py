#!/usr/bin/env python3
"""Prebuild validation for rev0105."""
from __future__ import annotations

import json
import py_compile
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0105-node-private-library-source-note-integrity"
PARENT = "ProgRSS-rev0104-workbench-private-backup-integrity-2026.10.22-Roadcase.zip"
PARENT_SHA = "35865a96e584408ddafbf84025de901c0ee2f0e2c93dbb30e02e4c6e3fc22d3f"
EXPECTED_LINEAGE = (
    "Continues the sealed rev0104 unified tree and corrects a reproduced loopback Node private-library "
    "Source Note validation bypass across transactional library ingestion and read-only backup serving. "
    "The current parent already contains the unified private-transfer, Exchange, Node branch and merge, "
    "shared-folder merge, publication, Lineage, Workbench collection and backup, repair, concurrency, "
    "Undo, native-integrity, and runtime-record work. No missing revision is invented."
)


def main() -> int:
    assert (ROOT / "REVISION").read_text(encoding="utf-8").strip() == REVISION
    state = json.loads((ROOT / "REVISION-STATE.json").read_text(encoding="utf-8"))
    assert state["revision"] == REVISION and state["releaseGateClosed"] is False
    assert state["claims"]["cliChanged"] is True and state["claims"]["extensionChanged"] is False

    cases = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text(encoding="utf-8"))
    assert cases["revision"] == REVISION and len(cases["cases"]) == 18 and len({item["id"] for item in cases["cases"]}) == 18
    two = next(item for item in cases["cases"] if item["id"] == "two-folder-independence")
    assert "loopback Node applies the same audit" in two["description"]
    assert "read-only `node serve BACKUP`" in two["description"]

    sys.path.insert(0, str(ROOT / "tools"))
    from source_notes_runtime_evidence import REVISION as EVIDENCE_REVISION, case_catalog

    assert EVIDENCE_REVISION == REVISION and case_catalog() == cases
    schema = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-RESULT.schema.json").read_text(encoding="utf-8"))
    assert schema["properties"]["revision"]["const"] == REVISION

    audit = json.loads((ROOT / "SOURCE-NOTES-NODE-PRIVATE-LIBRARY-INTEGRITY-AUDIT.json").read_text(encoding="utf-8"))
    continuity = json.loads((ROOT / "PRODUCT-CONTINUITY-AUDIT.json").read_text(encoding="utf-8"))
    integration = json.loads((ROOT / "INTEGRATION-AUDIT.json").read_text(encoding="utf-8"))
    assert audit["revision"] == REVISION and audit["status"] == "focused-pass"
    assert audit["reproduction"]["nodeStoreCreateAccepted"] is True
    assert audit["reproduction"]["readOnlyNodeLoaderAccepted"] is True
    assert audit["correction"]["sharedPythonAudit"] == "CLI/source_notes_native.py::validate_private_source_note_placements"
    assert audit["correction"]["validateBeforeSqliteCreation"] is True
    assert audit["correction"]["network"] is False
    assert continuity["revision"] == REVISION and continuity["status"] == "pass"
    assert continuity["cliChanged"] is True and continuity["extensionChanged"] is False
    assert continuity["permissionsExpanded"] is False and continuity["newNetworkAuthority"] is False
    assert integration["revision"] == REVISION and integration["status"] == "pass"

    provenance = json.loads((ROOT / "RECONSTRUCTION_PROVENANCE.json").read_text(encoding="utf-8"))
    assert provenance["reconstructionRevision"] == REVISION
    assert provenance["immediateParentArchive"] == PARENT and provenance["immediateParentSha256"] == PARENT_SHA
    assert provenance["lineageClaim"] == EXPECTED_LINEAGE

    status = json.loads((ROOT / "evidence/rev0105/regression-status.json").read_text(encoding="utf-8"))
    assert status["complete"] and status["allPassed"]
    labels = {row["label"]: row for row in status["rows"]}
    required = {
        "cli-test_source_notes_node_private_library",
        "cli-test_source_notes_private_transfer",
        "cli-test_node_store",
        "cli-test_node_server",
        "extension-static",
        "extension-browser-smoke",
        "extension-complete",
        "evidence-boundary",
        "contract",
        "workbench-private-backup-chromium",
        "workbench-private-backup-firefox",
    }
    assert required <= set(labels) and all(labels[label]["returncode"] == 0 for label in required)
    assert sum(int(row.get("tests") or 0) for row in status["rows"] if row["label"].startswith("cli-")) >= 204
    assert status["managedNodeHarnessInvocations"] == 22

    source_notes = (ROOT / "CLI/source_notes_native.py").read_text(encoding="utf-8")
    store = (ROOT / "CLI/node_store.py").read_text(encoding="utf-8")
    server = (ROOT / "CLI/node_server.py").read_text(encoding="utf-8")
    progrss = (ROOT / "CLI/progrss.py").read_text(encoding="utf-8")
    assert "def validate_private_source_note_placements" in source_notes
    assert "validate_private_source_note_placements(state)" in store
    assert "validate_private_source_note_placements(state)" in server
    assert "audit_private_source_note_placements" in progrss
    assert "invalid Source Notes" in store and "invalid Source Notes" in server

    focused = subprocess.run(
        [sys.executable, str(ROOT / "tools/verify-rev0105-node-private-library-integrity.py")],
        cwd=ROOT,
        check=True,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=1200,
    )
    assert "PASS" in focused.stdout

    for rel in (
        "tools/run-rev0105-regressions.py",
        "tools/verify-rev0105-node-private-library-integrity.py",
        "tools/audit-rev0105-product-continuity.py",
        "tools/update-rev0105-provenance.py",
        "tools/write-rev0105-authority.py",
        "tools/prebuild-validate-rev0105.py",
        "tools/build-rev0105-roadcase.py",
        "CLI/tests/test_source_notes_node_private_library.py",
    ):
        path = ROOT / rel
        assert path.is_file(), rel
        py_compile.compile(str(path), doraise=True)

    for path in ROOT.rglob("*.json"):
        if "node_modules" not in path.parts:
            json.loads(path.read_text(encoding="utf-8"))
    for rel in ("Extension/shared/core.js", "Extension/background.js", "Extension/workbench/scripts/progrss-app.js"):
        subprocess.run(["node", "--check", str(ROOT / rel)], check=True)
    assert not [path for path in ROOT.rglob("*.pyc") if "__pycache__" not in path.parts]
    print("PASS rev0105 prebuild validation: shared Python placement audit, Node private-library integrity, complete regressions, 18-case binding, JSON, Python, and Node syntax.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
