#!/usr/bin/env python3
"""Generate rev0100 reconstruction provenance against immutable rev0099 parent."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0100-node-branch-source-note-disclosure"
PARENT_NAME = "ProgRSS-rev0099-unified-baseline-2026.10.22-Roadcase.zip"
PARENT_SHA = "a8bf125794861dee8be6dc8aa6f182feaf0ccf2791e818b6cb3a32c663578841"
EXCLUDED = {"RECONSTRUCTION_PROVENANCE.json", "RECONSTRUCTION_PROVENANCE.md", "ROADCASE-MANIFEST.json", ".DS_Store"}
SKIP_DIRS = {".git", "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def current_rows() -> dict[str, dict[str, object]]:
    rows = {}
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.is_symlink():
            continue
        rel = path.relative_to(ROOT)
        if any(part in SKIP_DIRS for part in rel.parts) or path.name in EXCLUDED or path.suffix == ".pyc" or path.name.endswith((".zip", ".sha256")):
            continue
        data = path.read_bytes()
        rows[rel.as_posix()] = {"bytes": len(data), "sha256": sha(data), "mode": oct(0o755 if stat.S_IMODE(path.stat().st_mode) & 0o111 else 0o644)}
    return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--parent", type=Path, required=True)
    args = parser.parse_args()
    parent_raw = args.parent.read_bytes()
    if args.parent.name != PARENT_NAME or sha(parent_raw) != PARENT_SHA:
        raise SystemExit("parent identity mismatch")
    parent_rows = {}
    with zipfile.ZipFile(args.parent) as zf:
        for info in zf.infolist():
            if info.is_dir() or info.filename in EXCLUDED or info.filename.endswith((".zip", ".sha256")):
                continue
            pure = PurePosixPath(info.filename)
            if pure.is_absolute() or ".." in pure.parts:
                raise SystemExit(f"unsafe parent member: {info.filename}")
            data = zf.read(info)
            parent_rows[info.filename] = {"bytes": len(data), "sha256": sha(data), "mode": oct(0o755 if stat.S_IMODE((info.external_attr >> 16) & 0xFFFF) & 0o111 else 0o644)}
    current = current_rows()
    added = sorted(set(current) - set(parent_rows))
    deleted = sorted(set(parent_rows) - set(current))
    changed = sorted(name for name in set(current) & set(parent_rows) if current[name] != parent_rows[name])
    if deleted:
        raise SystemExit(f"unexpected deleted parent paths: {deleted[:10]}")
    report = {
        "schema": "progrss.reconstruction-provenance.v2",
        "generatedUtc": "2026-10-22T00:00:00Z",
        "reconstructionRevision": REVISION,
        "productLineage": {"revision": "rev0080", "version": "0.80.0"},
        "rootBaselineArchive": "ProgRSS-rev0080-2026.10.20-Roadcase(2).zip",
        "rootBaselineSha256": "181308cabfae43330016a272a64fbdb33038f841d605f4756ec65bedb43b8106",
        "immediateParentArchive": PARENT_NAME,
        "immediateParentSha256": PARENT_SHA,
        "integrationDonor": {
            "name": "ProgRSS-rev0091-source-notes-runtime-record-integrity-2026.10.21-Roadcase.zip",
            "sha256": "b05e3aa3e7cbdaf0b67e2fe3b7619f975a0d4971c33142f30759e963345eca95",
            "bytes": 6870213
        },
        "mergeBase": {
            "name": "ProgRSS-rev0090-verified-runtime-comparison-2026.10.21-Roadcase.zip",
            "sha256": "9245f25fcf7dc55d29e012488cfa33edf5abf49c6ac058e44419a6da3f3a4540",
            "bytes": 6799600
        },
        "lineageClaim": "Narrow reproduced Node branch-review disclosure correction on the unified rev0099 baseline; no older product tree overlaid and no missing revision invented.",
        "missingArtifacts": ["rev0081", "rev0082", "rev0090-source-notes-browser-execution-binding"],
        "inventoryExclusions": sorted(EXCLUDED),
        "added": added,
        "changed": changed,
        "deleted": deleted,
        "differenceCounts": {"added": len(added), "changed": len(changed), "deleted": len(deleted)}
    }
    (ROOT / "RECONSTRUCTION_PROVENANCE.json").write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (ROOT / "RECONSTRUCTION_PROVENANCE.md").write_text(
        "# Reconstruction provenance — rev0100\n\n"
        f"Immediate parent: `{PARENT_NAME}`  \nSHA-256: `{PARENT_SHA}`\n\n"
        "This is a narrow correction on the unified rev0099 tree. The reproduced shipped Node review "
        "omitted API-provided placement reasons before commit. No older archive was overlaid and no "
        "missing revision was invented.\n\n"
        f"- Added paths: {len(added)}\n- Changed paths or modes: {len(changed)}\n- Deleted paths: {len(deleted)}\n\n"
        "The exact path lists are in `RECONSTRUCTION_PROVENANCE.json`. Rev0081, rev0082, and the claimed "
        "browser-execution-binding source archive remain unavailable.\n",
        encoding="utf-8",
    )
    print(json.dumps(report["differenceCounts"], sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
