#!/usr/bin/env python3
"""Compare rev0101 CLI/Extension product paths with immutable rev0100 parent."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0101-unified-exchange-transfer-disclosure"
PARENT_NAME = "ProgRSS-rev0100-node-branch-source-note-disclosure-2026.10.22-Roadcase.zip"
PARENT_SHA256 = "447ae46551ee3d28f2e42d11ad65792e0a82c4d01b4d3bd6f601ba9a6b787c0c"
EXPECTED_CHANGED = {
    "CLI/README.md",
    "CLI/docs/NODE-EXCHANGE.md",
    "CLI/exchange.py",
    "CLI/fixtures/exchange-backup.json",
    "CLI/node_web/app.css",
    "CLI/node_web/app.js",
    "CLI/progrss.py",
    "CLI/tests/node_browser_smoke.py",
    "CLI/tests/test_node_server.py",
    "Extension/Firefox/README.md",
    "Extension/Firefox/background.js",
    "Extension/Firefox/fixtures/exchange-preview.json",
    "Extension/Firefox/fixtures/exchange-recent-updates.json",
    "Extension/Firefox/fixtures/exchange-source-list.json",
    "Extension/Firefox/sidepanel/app.css",
    "Extension/Firefox/sidepanel/app.js",
    "Extension/README.md",
    "Extension/background.js",
    "Extension/fixtures/exchange-preview.json",
    "Extension/fixtures/exchange-recent-updates.json",
    "Extension/fixtures/exchange-source-list.json",
    "Extension/sidepanel/app.css",
    "Extension/sidepanel/app.js",
    "Extension/tests/background_harness.js",
    "Extension/tests/browser_smoke.py",
    "Extension/tests/run.sh",
    "Extension/tests/test_static.py",
}
EXPECTED_ADDED = {
    "CLI/tests/test_exchange_source_notes.py",
    "CLI/tests/test_source_notes_private_transfer.py",
    "Extension/tests/source_notes_private_transfer_harness.js",
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--parent", type=Path, required=True)
    parser.add_argument("--json", type=Path, default=ROOT / "PRODUCT-CONTINUITY-AUDIT.json")
    parser.add_argument("--markdown", type=Path, default=ROOT / "PRODUCT-CONTINUITY-AUDIT.md")
    args = parser.parse_args()
    parent = args.parent.resolve()
    raw = parent.read_bytes()
    if parent.name != PARENT_NAME or digest(raw) != PARENT_SHA256:
        raise SystemExit("parent archive identity mismatch")
    parent_rows: dict[str, dict[str, object]] = {}
    with zipfile.ZipFile(parent) as archive:
        seen: set[str] = set()
        for info in archive.infolist():
            if info.filename in seen:
                raise SystemExit(f"duplicate parent member: {info.filename}")
            seen.add(info.filename)
            if info.is_dir() or not info.filename.startswith(("CLI/", "Extension/")):
                continue
            pure = PurePosixPath(info.filename)
            if pure.is_absolute() or ".." in pure.parts:
                raise SystemExit(f"unsafe parent member: {info.filename}")
            data = archive.read(info)
            parent_rows[info.filename] = {
                "bytes": len(data),
                "sha256": digest(data),
                "mode": oct(stat.S_IMODE((info.external_attr >> 16) & 0xFFFF)),
            }
    current_paths = {
        p.relative_to(ROOT).as_posix(): p
        for base in (ROOT / "CLI", ROOT / "Extension")
        for p in base.rglob("*")
        if p.is_file() and not p.is_symlink() and p.suffix != ".pyc" and "__pycache__" not in p.parts
    }
    added = sorted(set(current_paths) - set(parent_rows))
    deleted = sorted(set(parent_rows) - set(current_paths))
    changed: list[str] = []
    unchanged = 0
    mode_changed: list[str] = []
    for name in sorted(set(current_paths) & set(parent_rows)):
        path = current_paths[name]
        data = path.read_bytes()
        current_mode = oct(stat.S_IMODE(path.stat().st_mode))
        before = parent_rows[name]
        if current_mode != before["mode"]:
            mode_changed.append(name)
        if digest(data) != before["sha256"] or len(data) != before["bytes"]:
            changed.append(name)
        else:
            unchanged += 1
    if set(changed) != EXPECTED_CHANGED or set(added) != EXPECTED_ADDED or deleted or mode_changed:
        raise SystemExit(json.dumps({
            "expectedChanged": sorted(EXPECTED_CHANGED), "actualChanged": changed,
            "expectedAdded": sorted(EXPECTED_ADDED), "actualAdded": added,
            "deleted": deleted, "modeChanged": mode_changed,
        }, indent=2))
    # Manifest permission bytes must remain exactly equal to the parent.
    permission_paths = ["Extension/manifest.json", "Extension/Firefox/manifest.json"]
    for name in permission_paths:
        if digest(current_paths[name].read_bytes()) != parent_rows[name]["sha256"]:
            raise SystemExit(f"browser manifest changed: {name}")
    report = {
        "schema": "progrss.product-continuity-audit.v1",
        "revision": REVISION,
        "parent": {"name": PARENT_NAME, "sha256": PARENT_SHA256, "bytes": len(raw)},
        "counts": {
            "parentProductFiles": len(parent_rows), "currentProductFiles": len(current_paths),
            "unchanged": unchanged, "changed": len(changed), "added": len(added),
            "deleted": len(deleted), "modeChanged": len(mode_changed),
        },
        "changed": changed,
        "added": added,
        "deleted": deleted,
        "modeChanged": mode_changed,
        "integration": {
            "privateTransferDonor": "ProgRSS-rev0099-source-notes-private-transfer-integrity-2026.10.21-Roadcase.zip",
            "mergeBase": "ProgRSS-rev0098-source-notes-publication-disclosure-2026.10.21-Roadcase.zip",
            "exchangeDisclosureAddedOnParent": True,
        },
        "permissionsExpanded": False,
        "newPersistentStore": False,
        "newNetworkAuthority": False,
        "status": "pass",
    }
    args.json.write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    args.markdown.write_text(
        "# Product continuity audit — rev0101\n\n"
        f"Parent: `{PARENT_NAME}`  \nSHA-256: `{PARENT_SHA256}`\n\n"
        f"Compared {len(parent_rows)} parent CLI/Extension files with {len(current_paths)} current files. "
        f"Exactly {len(changed)} existing paths changed and {len(added)} focused test paths were added; "
        "no path was deleted or mode-changed. Browser manifest bytes are unchanged.\n\n"
        "The change set combines two reviewed deltas: the delivered private-transfer integrity branch "
        "merged through its rev0098 base, and a reproduced Exchange sender/recipient disclosure correction "
        "on the rev0100 parent. No persistent store, browser permission, or network authority was added.\n\n"
        "## Changed paths\n\n" + "\n".join(f"- `{name}`" for name in changed) +
        "\n\n## Added focused tests\n\n" + "\n".join(f"- `{name}`" for name in added) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
