#!/usr/bin/env python3
"""Compare rev0096 product bytes and permissions with the immutable rev0095 parent."""
from __future__ import annotations

import hashlib
import json
import stat
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PARENT = Path("/mnt/data/ProgRSS-rev0095-source-notes-reviewed-removal-2026.10.21-Roadcase.zip")
REVISION = "rev0096-source-notes-workbench-preservation"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parent_rows() -> dict[str, tuple[str, int]]:
    out: dict[str, tuple[str, int]] = {}
    with zipfile.ZipFile(PARENT) as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            raw_mode = (info.external_attr >> 16) & 0xFFFF
            out[info.filename] = (digest(archive.read(info)), stat.S_IMODE(raw_mode))
    return out


def current_rows() -> dict[str, tuple[str, int]]:
    out: dict[str, tuple[str, int]] = {}
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.is_symlink():
            continue
        out[path.relative_to(ROOT).as_posix()] = (digest(path.read_bytes()), stat.S_IMODE(path.stat().st_mode))
    return out


def projection(data: dict) -> dict:
    return {
        "permissions": data.get("permissions", []),
        "optional_permissions": data.get("optional_permissions", []),
        "host_permissions": data.get("host_permissions", []),
        "optional_host_permissions": data.get("optional_host_permissions", []),
    }


def main() -> None:
    before = parent_rows()
    after = current_rows()
    result: dict = {
        "schema": "progrss.product-continuity-audit.v1",
        "revision": REVISION,
        "parent": {"archive": PARENT.name, "sha256": digest(PARENT.read_bytes())},
        "pass": True,
    }
    for prefix, key in (("CLI/", "cli"), ("Extension/", "extension")):
        names = sorted({name for name in before if name.startswith(prefix)} | {name for name in after if name.startswith(prefix)})
        added = [name for name in names if name not in before]
        deleted = [name for name in names if name not in after]
        changed = [name for name in names if before.get(name) != after.get(name)]
        result[key] = {
            "pathsCompared": len(names),
            "added": added,
            "deleted": deleted,
            "changed": changed,
        }
    assert result["cli"]["added"] == result["cli"]["deleted"] == result["cli"]["changed"] == []
    expected_extension = {
        "Extension/README.md",
        "Extension/Firefox/README.md",
        "Extension/workbench/scripts/progrss-app.js",
        "Extension/Firefox/workbench/scripts/progrss-app.js",
        "Extension/tests/source_notes_workbench_collection_harness.py",
    }
    assert set(result["extension"]["changed"]) == expected_extension
    assert result["extension"]["added"] == ["Extension/tests/source_notes_workbench_collection_harness.py"]
    assert result["extension"]["deleted"] == []
    assert (ROOT / "Extension/workbench/scripts/progrss-app.js").read_bytes() == (
        ROOT / "Extension/Firefox/workbench/scripts/progrss-app.js"
    ).read_bytes()

    with zipfile.ZipFile(PARENT) as archive:
        parent_chromium = projection(json.loads(archive.read("Extension/manifest.json")))
        parent_firefox = projection(json.loads(archive.read("Extension/Firefox/manifest.json")))
    current_chromium = projection(json.loads((ROOT / "Extension/manifest.json").read_text()))
    current_firefox = projection(json.loads((ROOT / "Extension/Firefox/manifest.json").read_text()))
    assert current_chromium == parent_chromium
    assert current_firefox == parent_firefox
    result["permissions"] = {
        "chromiumProjectionUnchanged": True,
        "firefoxProjectionUnchanged": True,
        "expanded": False,
    }
    out_json = ROOT / "PRODUCT-CONTINUITY-AUDIT.json"
    out_md = ROOT / "PRODUCT-CONTINUITY-AUDIT.md"
    out_json.write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n")
    out_md.write_text(
        "# Product continuity audit — rev0096\n\n"
        f"- Parent: `{PARENT.name}`\n"
        f"- Parent SHA-256: `{result['parent']['sha256']}`\n"
        f"- CLI paths compared: **{result['cli']['pathsCompared']}**; byte/mode changes: **0**.\n"
        f"- Extension paths compared: **{result['extension']['pathsCompared']}**.\n"
        "- Product-byte changes are limited to the Chromium and generated-Firefox Advanced Workbench collection editor.\n"
        "- Extension documentation changed, and one focused managed UI-path harness was added.\n"
        "- Chromium/Firefox shared Workbench product bytes are identical.\n"
        "- Required, optional, host, and optional-host permission projections are unchanged in both browser packages.\n"
        "- No CLI product path changed.\n",
        encoding="utf-8",
    )
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
