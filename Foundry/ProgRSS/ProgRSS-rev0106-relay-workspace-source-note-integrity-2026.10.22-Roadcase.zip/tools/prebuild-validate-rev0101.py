#!/usr/bin/env python3
"""Fail-closed prebuild validation for rev0101."""
from __future__ import annotations

import json
from pathlib import Path
import py_compile
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0101-unified-exchange-transfer-disclosure"


def main() -> int:
    assert (ROOT / "REVISION").read_text(encoding="utf-8").strip() == REVISION
    state = json.loads((ROOT / "REVISION-STATE.json").read_text(encoding="utf-8"))
    assert state["revision"] == REVISION and state["releaseGateClosed"] is False
    cases = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text(encoding="utf-8"))
    assert cases["revision"] == REVISION and len(cases["cases"]) == 18
    assert len({row["id"] for row in cases["cases"]}) == 18
    sys.path.insert(0, str(ROOT / "tools"))
    from source_notes_runtime_evidence import REVISION as EVIDENCE_REVISION, case_catalog
    assert EVIDENCE_REVISION == REVISION and case_catalog() == cases
    result_schema = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-RESULT.schema.json").read_text(encoding="utf-8"))
    assert result_schema["properties"]["revision"]["const"] == REVISION

    integration = json.loads((ROOT / "INTEGRATION-AUDIT.json").read_text(encoding="utf-8"))
    exchange = json.loads((ROOT / "EXCHANGE-SOURCE-NOTE-DISCLOSURE-AUDIT.json").read_text(encoding="utf-8"))
    continuity = json.loads((ROOT / "PRODUCT-CONTINUITY-AUDIT.json").read_text(encoding="utf-8"))
    assert integration["revision"] == REVISION and integration["status"] in {"focused-pass", "pass"}
    assert exchange["revision"] == REVISION and exchange["status"] in {"focused-pass", "pass"}
    assert continuity["revision"] == REVISION and continuity["status"] == "pass"
    assert continuity["permissionsExpanded"] is False

    status = json.loads((ROOT / "evidence/rev0101/regression-status.json").read_text(encoding="utf-8"))
    assert status["complete"] is True and status["allPassed"] is True
    labels = {row["label"]: row for row in status["rows"]}
    required = {
        "cli-test_exchange_source_notes", "cli-test_source_notes_private_transfer",
        "node-browser-smoke", "extension-browser-smoke", "extension-complete",
        "source_notes_private_transfer_harness", "source_notes_private_transfer_harness-firefox",
        "evidence-boundary", "contract",
    }
    assert required <= set(labels)
    assert all(labels[label]["returncode"] == 0 for label in required)
    assert status["managedNodeHarnessInvocations"] == 21

    # Exact shared Firefox parity for modified product bytes.
    for relative in ("background.js", "sidepanel/app.js", "sidepanel/app.css"):
        assert (ROOT / "Extension" / relative).read_bytes() == (ROOT / "Extension" / "Firefox" / relative).read_bytes()
    for relative in ("exchange-preview.json", "exchange-source-list.json", "exchange-recent-updates.json"):
        assert (ROOT / "Extension" / "fixtures" / relative).read_bytes() == (ROOT / "Extension" / "Firefox" / "fixtures" / relative).read_bytes()

    preview = json.loads((ROOT / "Extension/fixtures/exchange-preview.json").read_text(encoding="utf-8"))
    assert preview["counts"]["sourceNotes"] == 3
    assert preview["choices"]["takeBranch"]["branches"][0]["sourceNotes"] == 1

    for relative in (
        "tools/run-rev0101-regressions.py", "tools/verify-rev0101-unified-disclosure.py",
        "tools/audit-rev0101-product-continuity.py", "tools/update-rev0101-provenance.py",
        "tools/build-rev0101-roadcase.py", "CLI/tests/test_exchange_source_notes.py",
        "CLI/tests/test_source_notes_private_transfer.py",
    ):
        assert (ROOT / relative).is_file(), relative
        if relative.endswith(".py"):
            py_compile.compile(str(ROOT / relative), doraise=True)
    for path in ROOT.rglob("*.json"):
        if "node_modules" not in path.parts:
            json.loads(path.read_text(encoding="utf-8"))
    for relative in ("CLI/node_web/app.js", "Extension/background.js", "Extension/sidepanel/app.js"):
        subprocess.run(["node", "--check", str(ROOT / relative)], check=True)
    assert not [p for p in ROOT.rglob("*.pyc") if "__pycache__" not in p.parts]
    print("PASS rev0101 prebuild validation: lineage integration, audits, complete regressions, 18-case binding, JSON, Python, Node syntax, and Firefox parity.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AssertionError, OSError, ValueError, subprocess.SubprocessError) as exc:
        print(f"rev0101 prebuild validation failed: {exc}", file=sys.stderr)
        raise SystemExit(1)
