#!/usr/bin/env python3
from __future__ import annotations
import hashlib, json, os, pathlib, re, stat, subprocess, sys, time
ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = pathlib.Path(os.environ.get('PROGRSS_AUDIT_OUT','/mnt/data/progrss-logs'))
OUT.mkdir(parents=True,exist_ok=True)
TEXT_EXT={'.py','.js','.mjs','.cjs','.json','.md','.html','.css','.sh','.toml','.yaml','.yml','.txt'}
SKIP_PARTS={'.git','node_modules','vendor','dist','build','__pycache__'}
terms=['source note','source_note','keep mine','use curator','three-way','opml','recipient','branch']
rows=[]
for p in ROOT.rglob('*'):
    if not p.is_file() or any(part in SKIP_PARTS for part in p.parts): continue
    if p.suffix.lower() not in TEXT_EXT or p.stat().st_size>3_000_000: continue
    try: text=p.read_text(encoding='utf-8',errors='replace')
    except OSError: continue
    low=text.lower()
    counts={term:low.count(term) for term in terms}
    if any(counts.values()):
        rows.append({'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'counts':counts})
rows.sort(key=lambda r:(-sum(r['counts'].values()),r['path']))

executables=[]
for p in ROOT.rglob('*'):
    if p.is_file() and not any(part in SKIP_PARTS for part in p.parts):
        mode=stat.S_IMODE(p.stat().st_mode)
        if mode & 0o111:
            executables.append({'path':str(p.relative_to(ROOT)),'mode':oct(mode)})

report={
 'root':str(ROOT),
 'generatedUtc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
 'sourceNoteRelatedFiles':rows,
 'executables':executables,
 'counts':{
   'relatedFiles':len(rows),
   **{term:sum(r['counts'][term] for r in rows) for term in terms}
 }
}
(OUT/'feature-state.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
with (OUT/'feature-state.md').open('w',encoding='utf-8') as f:
    f.write('# Reconstruction feature-state audit\n\n')
    f.write(f"Root: `{ROOT}`  \nGenerated: `{report['generatedUtc']}`\n\n")
    f.write('## Counts\n\n')
    for key,value in report['counts'].items(): f.write(f'- {key}: {value}\n')
    f.write('\n## Files with relevant terms\n\n')
    for row in rows:
        detail=', '.join(f"{k}={v}" for k,v in row['counts'].items() if v)
        f.write(f"- `{row['path']}` ({detail})\n")
    f.write('\n## Executable files\n\n')
    for item in executables: f.write(f"- `{item['path']}` mode `{item['mode']}`\n")
