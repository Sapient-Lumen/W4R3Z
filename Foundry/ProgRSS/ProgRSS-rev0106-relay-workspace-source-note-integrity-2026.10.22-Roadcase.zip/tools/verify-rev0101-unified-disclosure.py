#!/usr/bin/env python3
"""Focused rev0101 replay from a source tree or clean extraction."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0101-unified-exchange-transfer-disclosure"
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")


def run(label: str, command: list[str], timeout: int = 1800, extra: dict[str, str] | None = None) -> str:
    result = subprocess.run(
        command,
        cwd=ROOT,
        env=dict(ENV, **(extra or {})),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
    )
    print(f"\n== {label} ==\n{result.stdout.rstrip()}")
    if result.returncode:
        raise RuntimeError(f"{label} failed with exit {result.returncode}")
    return result.stdout


def main() -> int:
    assert (ROOT / "REVISION").read_text(encoding="utf-8").strip() == REVISION
    cases = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text(encoding="utf-8"))
    assert cases["revision"] == REVISION and len(cases["cases"]) == 18
    complete = next(row for row in cases["cases"] if row["id"] == "complete-route-disclosure")
    two_folder = next(row for row in cases["cases"] if row["id"] == "two-folder-independence")
    selected = next(row for row in cases["cases"] if row["id"] == "selected-branch-preservation")
    assert "Exchange handoff" in complete["description"]
    assert "private library transfer" in two_folder["description"]
    assert "Exchange branch choice" in selected["description"]

    node_app = (ROOT / "CLI/node_web/app.js").read_text(encoding="utf-8")
    sidepanel = (ROOT / "Extension/sidepanel/app.js").read_text(encoding="utf-8")
    firefox_sidepanel = (ROOT / "Extension/Firefox/sidepanel/app.js").read_text(encoding="utf-8")
    background = (ROOT / "Extension/background.js").read_text(encoding="utf-8")
    firefox_background = (ROOT / "Extension/Firefox/background.js").read_text(encoding="utf-8")
    cli = (ROOT / "CLI/progrss.py").read_text(encoding="utf-8")
    for content in (node_app, sidepanel):
        for phrase in ("Curator’s reason for this folder", "not a ProgRSS safety claim", "sourceNotes"):
            assert phrase in content, phrase
    assert sidepanel == firefox_sidepanel
    assert background == firefox_background
    for phrase in ("privateSourceNoteAudit", "INVALID_SOURCE_NOTE_STATE", "sourceNotes"):
        assert phrase in background, phrase
    for phrase in ("validate_private_source_note_placements", "source_note_placement_count"):
        assert phrase in cli, phrase

    preview = json.loads((ROOT / "Extension/fixtures/exchange-preview.json").read_text(encoding="utf-8"))
    assert preview["counts"]["sourceNotes"] == 3
    assert preview["choices"]["takeBranch"]["branches"][0]["sourceNotes"] == 1
    council = next(row for row in preview["contents"]["sources"] if row["id"] == "feed-council")
    assert [p.get("reason") for p in council["placements"]] == [
        "Broad agenda overview.", "سبب لاجتماعات المجلس المحلية."
    ]

    run("Exchange disclosure unit contract", [sys.executable, "-m", "unittest", "-v", "CLI.tests.test_exchange_source_notes"])
    run("private-transfer CLI contract", [sys.executable, "-m", "unittest", "-v", "CLI.tests.test_source_notes_private_transfer"])
    run("Node branch and Exchange rendering", [sys.executable, "CLI/tests/node_browser_smoke.py"])
    run("Extension recipient rendering", [sys.executable, "Extension/tests/browser_smoke.py"])
    run("private-transfer Chromium harness", ["node", "Extension/tests/source_notes_private_transfer_harness.js"])
    run("private-transfer Firefox harness", ["node", "Extension/tests/source_notes_private_transfer_harness.js"], extra={"PROGRSS_EXTENSION_ROOT": "Firefox"})
    print("\nPASS rev0101 focused unified Exchange/private-transfer Source Note replay.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AssertionError, OSError, RuntimeError, subprocess.SubprocessError, ValueError) as exc:
        print(f"rev0101 verification failed: {exc}", file=sys.stderr)
        raise SystemExit(1)
