#!/usr/bin/env python3
"""Best-effort automated smoke; never counts as unmanaged-browser fieldwork."""
from __future__ import annotations
import contextlib
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import threading
import time

ROOT=Path(__file__).resolve().parents[1]
SITE=ROOT/'fieldwork'/'source-notes'
OUT=Path(os.environ.get('PROGRSS_AUDIT_OUT','/mnt/data/progrss-logs'))
OUT.mkdir(parents=True,exist_ok=True)

class Quiet(SimpleHTTPRequestHandler):
    def log_message(self, *args): pass

@contextlib.contextmanager
def server():
    handler=lambda *args,**kwargs: Quiet(*args,directory=str(SITE),**kwargs)
    httpd=ThreadingHTTPServer(('127.0.0.1',0),handler)
    thread=threading.Thread(target=httpd.serve_forever,daemon=True); thread.start()
    try: yield f'http://127.0.0.1:{httpd.server_port}/index.html'
    finally: httpd.shutdown(); thread.join(timeout=5); httpd.server_close()

def find(names):
    for name in names:
        path=shutil.which(name)
        if path: return path
    return None

def run(cmd,timeout=60,env=None):
    p=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout,env=env)
    return {'command':cmd,'returncode':p.returncode,'output':p.stdout[-8000:]}

results={'classification':'automated managed-environment smoke only; not participant evidence and not an unmanaged current-browser run','browsers':[]}
with server() as url:
    chromium=find(['google-chrome','google-chrome-stable','chromium','chromium-browser'])
    if chromium:
        with tempfile.TemporaryDirectory(prefix='progrss-chromium-') as profile:
            version=run([chromium,'--version'],20)
            smoke=run([chromium,'--headless=new','--no-sandbox','--disable-gpu','--disable-background-networking','--disable-component-update','--disable-default-apps','--disable-extensions','--no-first-run',f'--user-data-dir={profile}','--dump-dom',url],90)
            smoke['domEvidence']={
                'title': '<title>ProgRSS Source Notes fieldwork</title>' in smoke['output'],
                'scriptRan': 'Strong day-to-day service alerts for this route.' in smoke['output'] and 'No report yet.' in smoke['output'],
            }
            smoke['pass']=smoke['returncode']==0 and all(smoke['domEvidence'].values())
            results['browsers'].append({'family':'Chromium','path':chromium,'version':version,'smoke':smoke})
    firefox=find(['firefox','firefox-esr'])
    if firefox:
        with tempfile.TemporaryDirectory(prefix='progrss-firefox-') as temp:
            shot=Path(temp)/'shot.png'; profile=Path(temp)/'profile'; profile.mkdir()
            version=run([firefox,'--version'],20)
            env=dict(os.environ); env['MOZ_DISABLE_NONLOCAL_CONNECTIONS']='1'
            smoke=run([firefox,'--headless','-profile',str(profile),'--screenshot',str(shot),url],90,env)
            smoke['screenshotBytes']=shot.stat().st_size if shot.exists() else 0
            smoke['pass']=smoke['returncode']==0 and smoke['screenshotBytes']>0
            if shot.exists(): shutil.copy2(shot,OUT/'fieldwork-firefox-smoke.png')
            results['browsers'].append({'family':'Firefox','path':firefox,'version':version,'smoke':smoke})
results['overallPass']=bool(results['browsers']) and all(x['smoke']['pass'] for x in results['browsers'])
(OUT/'fieldwork-browser-smoke.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
with (OUT/'fieldwork-browser-smoke.md').open('w',encoding='utf-8') as f:
    f.write('# Fieldwork harness browser smoke\n\n')
    f.write(f"**Classification:** {results['classification']}\n\n")
    if not results['browsers']: f.write('No supported browser executable was available.\n')
    for item in results['browsers']:
        version=item['version']['output'].strip().splitlines()[-1] if item['version']['output'].strip() else '(unknown version)'
        f.write(f"- {item['family']}: {'PASS' if item['smoke']['pass'] else 'FAIL'} — `{version}`\n")
    f.write(f"\nOverall automated smoke: {'PASS' if results['overallPass'] else 'NOT ESTABLISHED'}\n")
print(json.dumps({'overallPass':results['overallPass'],'browserCount':len(results['browsers'])}))
