#!/usr/bin/env python3
"""Replay the bounded rev0087 Source Notes runtime-kit gate.

This gate verifies the shipped Source Notes contract and authoring controls,
then checks the exact-package session kit and the honestly bounded managed
non-current Chromium evidence. It does not execute or claim current/unmanaged
Chromium, Firefox Release/ESR, human, or assistive-technology fieldwork.
"""
from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys
from typing import Sequence

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0087-source-notes-runtime-kit"


def run(name: str, command: Sequence[str], *, timeout: int = 900) -> None:
    print(f"\n== {name} ==")
    completed = subprocess.run(
        list(command),
        cwd=ROOT,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        check=False,
    )
    if completed.stdout:
        print(completed.stdout.rstrip())
    if completed.returncode:
        raise RuntimeError(f"{name} failed with exit status {completed.returncode}")


def verify_claim_boundary() -> None:
    runtime = json.loads((ROOT / "evidence" / "rev0087" / "available-chromium-worktree-runtime.json").read_text(encoding="utf-8"))
    snapshot = json.loads((ROOT / "BROWSER-CHANNEL-SNAPSHOT.json").read_text(encoding="utf-8"))
    matrix = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-MATRIX.json").read_text(encoding="utf-8"))
    audit = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-AUDIT.json").read_text(encoding="utf-8"))
    assert runtime["pass"] is True
    assert runtime["environment"]["policyOverrideDeclared"] is True
    assert "roadcase" not in runtime["package"], "worktree evidence must not claim final Roadcase identity"
    for key in (
        "unmanagedBrowserAcceptance",
        "currentStableAcceptance",
        "humanPermissionPromptObservation",
        "accessibilityConformance",
        "assistiveTechnologyEvidence",
        "unfamiliarPersonComprehension",
    ):
        assert runtime["claimBoundary"][key] is False, key
    assert snapshot["channelReferences"]["chromiumStable"]["version"] == "156.0.8078.47"
    assert snapshot["channelReferences"]["firefoxRelease"]["version"] == "158.0.1"
    assert snapshot["channelReferences"]["firefoxEsr"]["version"] == "153.5.1esr"
    assert audit["pass"] is True and audit["releaseGateClosed"] is False
    statuses = {row["id"]: row["status"] for row in matrix["rows"]}
    assert statuses["available-chromium-managed-worktree-preflight"] == "pass"
    for row_id in (
        "exact-final-roadcase-managed-preflight",
        "unmanaged-current-chromium",
        "firefox-release",
        "firefox-esr",
        "unfamiliar-person-and-assistive-technology-fieldwork",
    ):
        assert statuses[row_id] == "not-run", (row_id, statuses[row_id])
    assert matrix["releaseGateClosed"] is False
    print("runtime-kit claim boundary: honest and release gate remains open")


def verify_runtime_sources() -> None:
    harness = (ROOT / "Extension" / "tests" / "source_notes_installed_acceptance.py").read_text(encoding="utf-8")
    preparer = (ROOT / "tools" / "prepare-source-notes-runtime-session.py").read_text(encoding="utf-8")
    protocol = (ROOT / "SOURCE-NOTES-RUNTIME-PROTOCOL.md").read_text(encoding="utf-8")
    required_harness = (
        "Extensions.loadUnpacked",
        "archiveMatchesExtractedExtension",
        "open two real extension views",
        "undo-source-placement-reason",
        "STALE_SOURCE_NOTE_UNDO",
        "divergentLaterCopyPlacementDecision",
        '"unmanagedBrowserAcceptance": False',
        '"currentStableAcceptance": False',
    )
    missing = [marker for marker in required_harness if marker not in harness]
    if missing:
        raise RuntimeError("runtime harness marker(s) missing: " + ", ".join(missing))
    if "test-source-note-" in harness:
        raise RuntimeError("runtime harness uses a Source Notes test-only hook")
    required_preparer = ("verify_roadcase", "unsafe archive member", "preparedOnly", "PACKAGE-MANIFEST.json")
    missing = [marker for marker in required_preparer if marker not in preparer]
    if missing:
        raise RuntimeError("session preparer marker(s) missing: " + ", ".join(missing))
    if "Blocked, unavailable, skipped, and timed-out work never becomes a pass" not in protocol:
        raise RuntimeError("protocol fail-closed result language missing")
    print("runtime harness and exact-Roadcase session preparer: present and fail-closed")


def main() -> int:
    try:
        run("rev0086 contract and shipped-authoring continuity", [sys.executable, "tools/verify-rev0086-source-notes.py"], timeout=1200)
        run(
            "runtime-lane static boundary",
            [
                sys.executable,
                "-m",
                "unittest",
                "-v",
                "Extension.tests.test_static.JavaScriptTests.test_source_note_installed_runtime_lane_is_real_view_fail_closed_evidence",
            ],
        )
        run("runtime-kit audit", [sys.executable, "tools/audit-source-notes-runtime-kit.py"])
        run("runtime session preparer CLI", [sys.executable, "tools/prepare-source-notes-runtime-session.py", "--help"])
        verify_runtime_sources()
        verify_claim_boundary()
    except Exception as exc:
        print(f"rev0087 Source Notes verification failed: {exc}", file=sys.stderr)
        return 1
    print(f"\n{REVISION} gate: PASS")
    print("classification: managed non-current runtime preflight and exact-package kit; current/unmanaged browsers, Firefox, human permission prompts, real assistive technology, and participant fieldwork not run")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
