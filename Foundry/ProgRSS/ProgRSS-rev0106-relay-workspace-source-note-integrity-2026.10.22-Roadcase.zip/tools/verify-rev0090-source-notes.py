#!/usr/bin/env python3
"""Bounded native/managed regression gate; no real-browser acceptance claim."""
from __future__ import annotations

import importlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0090-verified-runtime-comparison"


def run(label, command, *, env=None):
    print(f"\n== {label} ==", flush=True)
    result = subprocess.run(command, cwd=ROOT, env=env, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=420, check=False)
    print(result.stdout.rstrip(), flush=True)
    if result.returncode:
        raise RuntimeError(f"{label} failed: {result.returncode}")


def main():
    os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
    run("cross-runtime Source Notes contract", ["sh", "tools/verify-source-notes-contract.sh"])
    run("native placement and shipped CLI authoring", [sys.executable, "-m", "unittest", "-v",
        "CLI.tests.test_source_notes_entrypoints",
        "CLI.tests.test_command_line.CommandLineTests.test_workspace_source_note_edits_one_direct_placement_offline"])
    run("Node reviewed branch and merge paths", [sys.executable, "-m", "unittest", "-v",
        "CLI.tests.test_node_server.NodeServerTests.test_node_owned_branch_operation_is_reviewed_atomic_idempotent_and_snapshot_backed",
        "CLI.tests.test_node_server.NodeServerTests.test_merge_review_is_three_way_read_only_and_requires_admin_origin"])
    run("Chromium-source managed core", ["node", "Extension/tests/source_notes_entrypoints_harness.js"])
    run("generated-Firefox managed core", ["node", "Extension/tests/source_notes_entrypoints_harness.js"],
        env=dict(os.environ, PROGRSS_EXTENSION_ROOT="Firefox"))
    run("Extension background continuity", ["node", "Extension/tests/background_harness.js"])
    run("native evidence and verified comparison regressions", [sys.executable, "-m", "unittest", "-v",
        "tests.test_source_notes_runtime_evidence", "tests.test_verified_runtime_comparison"])
    for tool in ("browser_channel_evidence.py", "prepare-source-notes-runtime-session.py",
                 "finalize-source-notes-runtime-session.py", "verify-source-notes-runtime-evidence.py",
                 "compare-source-notes-runtime-evidence.py"):
        run(tool, [sys.executable, "tools/" + tool, "--help"])
    sys.path.insert(0, str(ROOT / "tools"))
    inherited = importlib.import_module("verify-rev0086-source-notes")
    inherited.verify_permissions()
    inherited.verify_generated_firefox()
    inherited.verify_authoring_surface_markers()
    from source_notes_runtime_evidence import case_catalog, SESSION_SCHEMA, RESULT_SCHEMA
    assert json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text()) == case_catalog()
    assert len(case_catalog()["cases"]) == 18
    assert SESSION_SCHEMA.endswith(".v4") and RESULT_SCHEMA.endswith(".v2")
    cli = json.loads((ROOT / "evidence/rev0090/cli-modules-summary.json").read_text())
    assert cli["allPassed"] and len(cli["results"]) == 11 and all(row["returncode"] == 0 for row in cli["results"])
    assert json.loads((ROOT / "evidence/rev0090/extension-exit.json").read_text())["returncode"] == 0
    continuity = json.loads((ROOT / "evidence/rev0090/product-byte-continuity.json").read_text())
    assert continuity["allUnchanged"]
    print(f"\n{REVISION} focused gate: PASS")
    print("Scope: native, managed regression, and synthetic evidence-boundary replay only.")
    print("Current/unmanaged browser triad, human permission prompts, participants and real assistive technologies: NOT RUN.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AssertionError, RuntimeError, OSError, subprocess.SubprocessError) as error:
        print(f"rev0090 focused gate failed: {error}", file=sys.stderr)
        raise SystemExit(1)
