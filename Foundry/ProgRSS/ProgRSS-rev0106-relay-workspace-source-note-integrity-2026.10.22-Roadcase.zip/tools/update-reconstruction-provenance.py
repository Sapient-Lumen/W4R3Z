#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import zipfile

ROOT = Path(__file__).resolve().parents[1]
PARENT = Path('/mnt/data/ProgRSS-rev0098-source-notes-publication-disclosure-2026.10.21-Roadcase.zip')
BASELINE = Path('/mnt/data/ProgRSS-rev0080-2026.10.20-Roadcase(2).zip')
SKIP_NAMES = {'ROADCASE-MANIFEST.json', 'RECONSTRUCTION_PROVENANCE.json', 'RECONSTRUCTION_PROVENANCE.md', '.DS_Store'}
SKIP_PARTS = {'.git', 'node_modules', '__pycache__', '.pytest_cache', '.mypy_cache', '.ruff_cache'}


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def include(name: str) -> bool:
    path = PurePosixPath(name)
    if not name or name.endswith('/') or path.name in SKIP_NAMES:
        return False
    if any(part in SKIP_PARTS for part in path.parts):
        return False
    if path.suffix == '.pyc' or path.name.endswith('.zip') or path.name.endswith('.sha256'):
        return False
    return True


def parent_tree() -> dict[str, dict]:
    out: dict[str, dict] = {}
    with zipfile.ZipFile(PARENT) as archive:
        for info in archive.infolist():
            if info.is_dir():
                continue
            name = info.filename.rstrip('/')
            if not include(name):
                continue
            raw_mode = (info.external_attr >> 16) & 0xFFFF
            data = archive.read(info)
            out[name] = {
                'kind': 'symlink' if stat.S_ISLNK(raw_mode) else 'file',
                'mode': oct(stat.S_IMODE(raw_mode)),
                'bytes': len(data),
                'sha256': sha_bytes(data),
            }
    return out


def current_tree() -> dict[str, dict]:
    out: dict[str, dict] = {}
    for path in ROOT.rglob('*'):
        relative = path.relative_to(ROOT).as_posix()
        if not include(relative) or (not path.is_file() and not path.is_symlink()):
            continue
        if path.is_symlink():
            data = os.readlink(path).encode('utf-8')
            kind = 'symlink'
            mode = stat.S_IMODE(path.lstat().st_mode)
        else:
            data = path.read_bytes()
            kind = 'file'
            mode = stat.S_IMODE(path.stat().st_mode)
        out[relative] = {'kind': kind, 'mode': oct(mode), 'bytes': len(data), 'sha256': sha_bytes(data)}
    return out


def main() -> int:
    before = parent_tree()
    after = current_tree()
    added = sorted(set(after) - set(before))
    deleted = sorted(set(before) - set(after))
    changed = sorted(name for name in set(before) & set(after) if before[name] != after[name])
    provenance = {
        'schema': 'progrss.reconstruction-provenance.v2',
        'reconstructionRevision': 'rev0099-unified-baseline',
        'generatedUtc': '2026-10-22T00:00:00Z',
        'productLineage': {'revision': 'rev0080', 'version': '0.80.0'},
        'immediateParentArchive': PARENT.name,
        'immediateParentSha256': sha_file(PARENT),
        'rootBaselineArchive': BASELINE.name,
        'rootBaselineSha256': sha_file(BASELINE),
        'missingArtifacts': ['rev0081', 'rev0082', 'rev0090-source-notes-browser-execution-binding'],
        'integrationDonor': json.loads((ROOT / 'INTEGRATION-AUDIT.json').read_text())['artifacts']['integrationDonor'],
        'mergeBase': json.loads((ROOT / 'INTEGRATION-AUDIT.json').read_text())['artifacts']['mergeBase'],
        'lineageClaim': 'Unified delivered rev0098 product lineage with the supplied rev0091 runtime-record-integrity sibling via rev0090 comparison ancestor. Reuploaded rev0080 is byte-identical to the original baseline; rev0081/rev0082 and claimed browser-execution-binding source remain unrecovered.',
        'inventoryExclusions': sorted(SKIP_NAMES),
        'differenceCounts': {'added': len(added), 'changed': len(changed), 'deleted': len(deleted)},
        'added': added,
        'changed': changed,
        'deleted': deleted,
    }
    (ROOT / 'RECONSTRUCTION_PROVENANCE.json').write_text(json.dumps(provenance, ensure_ascii=False, sort_keys=True, indent=2) + '\n', encoding='utf-8')
    (ROOT / 'RECONSTRUCTION_PROVENANCE.md').write_text(
        '# Reconstruction provenance — rev0099\n\n'
        f"- Candidate: `rev0099-unified-baseline`\n"
        f"- Immediate parent: `{PARENT.name}`\n"
        f"- Immediate parent SHA-256: `{provenance['immediateParentSha256']}`\n"
        f"- Root supplied baseline: `{BASELINE.name}`\n"
        f"- Root baseline SHA-256: `{provenance['rootBaselineSha256']}`\n"
        '- Unavailable inputs: rev0081 and rev0082\n'
        f"- Lineage statement: {provenance['lineageClaim']}\n\n"
        '## Difference inventory versus rev0098 parent\n\n'
        f"- Added paths: {len(added)}\n"
        f"- Changed paths or modes: {len(changed)}\n"
        f"- Deleted paths: {len(deleted)}\n\n"
        'The machine-readable path lists are in `RECONSTRUCTION_PROVENANCE.json`. '
        'Self-referential provenance outputs and the generated Roadcase manifest are excluded from this comparison. '
        'The final manifest inside the Roadcase ZIP is the authority for release bytes and executable modes.\n',
        encoding='utf-8',
    )
    print(json.dumps(provenance['differenceCounts'], sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
