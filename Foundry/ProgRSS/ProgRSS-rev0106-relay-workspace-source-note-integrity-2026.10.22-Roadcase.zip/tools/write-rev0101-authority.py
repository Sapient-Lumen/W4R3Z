#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REV='rev0101-unified-exchange-transfer-disclosure'
PARENT={"name":"ProgRSS-rev0100-node-branch-source-note-disclosure-2026.10.22-Roadcase.zip","sha256":"447ae46551ee3d28f2e42d11ad65792e0a82c4d01b4d3bd6f601ba9a6b787c0c","bytes":13482494}
DONOR={"name":"ProgRSS-rev0099-source-notes-private-transfer-integrity-2026.10.21-Roadcase.zip","sha256":"c959810ff94479ba0ae2e6cf41bb7293a7abd1b70c827b01196c3b23d34630e8","bytes":13121255}
BASE={"name":"ProgRSS-rev0098-source-notes-publication-disclosure-2026.10.21-Roadcase.zip","sha256":"2e97f0075281fc19b279db85057c87b3582fb5d9ca30021e9d7d3ff10f2d1a44","bytes":12093270}

def write(name:str,text:str):
    (ROOT/name).write_text(text.rstrip()+"\n",encoding='utf-8')

def dump(name:str,obj):
    (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding='utf-8')

(ROOT/'REVISION').write_text(REV+'\n',encoding='utf-8')

write('BOOTSTRAPROSE.md',f'''# BOOTSTRAPROSE — current `/run` authority

**Candidate:** `{REV}` · **Date:** 2026-10-22 · **Product lineage:** rev0080 / 0.80.0.

## Authority and lineage

This tree continues the sealed rev0100 whole-product candidate. It also integrates the separately delivered private-transfer integrity delta by three-way merge through its rev0098 publication-disclosure base. No missing revision is represented as recovered.

- Immediate parent: `{PARENT['name']}` · `{PARENT['sha256']}`
- Integration donor: `{DONOR['name']}` · `{DONOR['sha256']}`
- Donor merge base: `{BASE['name']}` · `{BASE['sha256']}`
- Still unavailable: rev0081, rev0082, and the undelivered browser-execution-binding source archive.

The release gate is open. Managed tests, prepared sessions, and deterministic archives do not substitute for actual target-host browsers, unfamiliar people, privacy review, or real assistive technologies.

## P0.0 — completed in this candidate

- Preserve the unified rev0100 Node branch-review disclosure and runtime-record integrity work.
- Restore the delivered private-library transfer integrity delta without rolling back later product files.
- Validate direct-placement reasons before private transfer preview, restore, copy checking, guarded Undo, recovery export, and ordinary export.
- Preserve valid route-specific reasons exactly, including one source with different reasons in two folders.
- Refuse malformed, wrong-level, empty, edge-whitespace, invalid-Unicode, missing-source, and reason-bearing duplicate placements before mutation or outbound export.
- Reproduce and correct Exchange review omission on both shipped surfaces.
- Show the exact curator-reason count in the Node sender review and Extension recipient three-door review.
- Show each reason beside the direct folder route it describes; keep absent reasons absent.
- Show branch-specific reason counts before selected-branch review.
- Render user text literally, preserve internal line breaks, use content-derived direction, attribute it to the curator, and state that it is not a ProgRSS safety claim.
- Keep Exchange review read-only: no listed-source request, no library write, no pairing expansion, and no new browser permission.
- Keep the fixed behavioral acceptance catalog at exactly 18 cases and bind fresh session-v5/result-v3 evidence to this revision.

## P0.1 — exact package on the actual browser triad

Run fresh records from the sealed rev0101 Roadcase in:

1. Unmanaged then-current Chromium Stable.
2. Firefox Release.
3. Firefox ESR.

Capture fresh official channel evidence on each host. Do not relabel rev0100 or earlier sessions.

Run all 18 cases and the whole-product boundaries. In addition to every inherited reader, Node, Exchange, Capture, Witness, Pulse, Trace, Workbench, Lineage, repair, conflict, stale-write, saturated-concurrency, Undo, publication, OPML, integrity, restart, and permission check, explicitly prove:

- **Private transfer:** preview counts curator-written folder reasons; restore, export, copy checking, and guarded Undo preserve two route-specific reasons exactly; all malformed forms refuse before mutation; malformed local state refuses outbound export; no network or permission request occurs.
- **Exchange sender review:** exact total, each direct folder route, literal multiline/markup-like and bidirectional values, absent-reason omission, curator attribution, and non-safety wording are visible before invitation creation.
- **Exchange recipient review:** the same evidence is visible before the three choices; branch choices include their own reason counts; no listed source is contacted during review.
- **Node branch operation:** its separate chooser and exact reviewed write retain route-bound reasons and zero-listed-site-contact behavior.

Preserve first failures, interruptions, retries, and recovery—not only the eventual result. Firefox temporary loading remains development-runtime evidence and must not be interpreted as signed-install or restart acceptance.

## P0.2 — unfamiliar people, privacy, and real assistive technologies

Only after the exact browser triad passes:

- Ask unfamiliar senders and recipients what moves in a private file and an Exchange handoff.
- Ask what relationship each reason belongs to, who wrote it, and whether it is a safety claim.
- Ask whether preview, transfer, adoption, conflict choice, or Undo published anything, contacted anyone, or created a schedule.
- Compare sender, recipient, and diagnostic privacy evidence separately.
- Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions.
- Make only the smallest correction supported by recurring independent wrong turns.

## P1 — sharing and organization

- Test one-week delayed route re-finding before adding private labels or saved-view complexity.
- Keep folders human-curated and shareable; preserve **Unfiled** as legitimate.
- Keep Source Note wording out of engagement ranking and opaque recommendation systems.
- Do not expand Source Notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

- Keep remote mode explicit and separate from loopback.
- Require TLS, persistent Node identity, bounded hosts/requests/artifacts/rates, expiring invitations, and durable revocation evidence.
- Keep public publication routes separate from private APIs.
- No default public bind, silent LAN discovery, or UPnP.

## Lab — WebRTC courier

- Transfer exactly one reviewed immutable artifact.
- Preserve Source Notes through the native artifact.
- Make signaling, STUN, and TURN visible.
- Refuse replay, identity mismatch, digest mismatch, timeout, and partial completion.
- Destroy the session after the bounded transfer.
- Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## Change discipline

Do not add another evidence framework merely because target-host access is unavailable. Further product changes require a reproduced failure. Keep every nonclaim explicit.
''')

write('CURRENT-STATUS.md',f'''# Current status — {REV}

A verified integration candidate under test. It continues rev0100, restores the delivered private-transfer integrity delta by three-way merge, and corrects a reproduced Exchange sender/recipient review omission. The release gate remains open for actual Chromium, Firefox Release, Firefox ESR, unfamiliar-person, privacy, and assistive-technology work. See `BOOTSTRAPROSE.md`.
''')

write('RESULT-SUMMARY.md',f'''# Result summary — rev0101 unified Exchange/private-transfer disclosure

The sealed rev0100 tree did not contain the separately delivered private-transfer integrity delta. That delta has now been integrated through its rev0098 merge base without replacing later product files. Private backup preview, restore, copy checking, Undo, recovery export, and ordinary export apply the direct-placement Source Notes contract.

A separate reproduced defect was corrected in Exchange. The native handoff already carried placement reasons, but the Node sender review and Extension recipient review discarded them. Both shipped reviews now show the exact reason count, each direct folder route, literal direction-aware text, curator attribution, and the non-safety boundary. Branch choices show their reason count before selected-branch review.

The fixed runtime catalog remains 18 cases and is bound to rev0101. Complete regression and deterministic-build results are recorded by the detached final verification; target-host browser and human gates remain open.
''')

write('HANDOFF.md',f'''# Handoff — {REV}

Start with `BOOTSTRAPROSE.md`, `INTEGRATION-AUDIT.md`, `EXCHANGE-SOURCE-NOTE-DISCLOSURE-AUDIT.md`, `PRODUCT-CONTINUITY-AUDIT.md`, the detached final verification, and the runtime matrix.

Preserve both corrections: the private-transfer placement validator and the Exchange sender/recipient disclosure. The former is a full-vault fail-closed boundary; the latter is a read-only review correction. Neither authorizes pairing, source fetching, background synchronization, or a new permission.

Prepare fresh rev0101 session-v5 records from the exact sealed Roadcase; do not relabel earlier sessions. Next: run the complete 18-case and whole-product corpus on actual unmanaged then-current Chromium, Firefox Release, and Firefox ESR hosts, including valid/malformed private transfer and both Exchange review surfaces. Then run separate unfamiliar-person, privacy, and real assistive-technology sessions. Do not substitute managed or preparation-only evidence.
''')

write('CHANGELOG-rev0101-unified-exchange-transfer-disclosure.md',f'''# Changelog — {REV}

- Integrated the delivered rev0099 private-transfer Source Notes integrity delta through its rev0098 merge base.
- Added fail-closed private-library validation before preview, restore, copy checking, Undo, and export.
- Added exact Source Note counts to private transfer review and CLI audit output.
- Corrected Node Exchange sender review to disclose exact route-bound Source Notes.
- Corrected Extension Exchange recipient review and branch choices to disclose exact counts and reasons.
- Added literal multiline, direction-aware rendering, curator attribution, and explicit non-safety wording.
- Added focused CLI, Node-rendering, Extension-rendering, Chromium, and generated-Firefox regressions.
- Kept the runtime acceptance catalog at 18 cases and advanced its binding to rev0101.
- Added no browser permission, persistent store, network authority, account, schedule, notification, ranking, profile, reaction, comment, or message feature.
''')

state={
 "schema":"progrss.revision-state.v1","revision":REV,"date":"2026-10-22",
 "productLineage":{"revision":"rev0080","version":"0.80.0"},
 "parent":PARENT,"integrationDonor":DONOR,"mergeBase":BASE,
 "classification":"unified delivered private-transfer integrity plus reproduced Exchange review disclosure correction; exact target-host acceptance open",
 "releaseGateClosed":False,
 "checks":{
   "privateTransferIntegration":{"status":"focused-pass","cliTests":4,"browserPackageVariants":2,"checksPerVariant":16},
   "exchangeDisclosure":{"status":"focused-pass","cliTests":3,"senderRendering":"pass","recipientRendering":"pass"},
   "behaviorCatalog":{"status":"pass","cases":18,"revision":REV,"freshSessionPreparationRequired":True},
   "offlineRegressions":{"status":"pending-full-sweep"},
   "productContinuity":{"status":"pending-audit"},
   "deterministicBuild":{"status":"requires-detached-post-build-report"}
 },
 "claims":{
   "productChanged":True,"cliChanged":True,"extensionChanged":True,
   "browserRenderingThisTurn":True,"browserRenderingScope":"managed Node and Extension regression smoke only",
   "installedBrowserRuntimeThisTurn":False,"unmanagedChromiumRuntime":False,"firefoxReleaseRuntime":False,"firefoxEsrRuntime":False,
   "humanPermissionPromptObservation":False,"unfamiliarParticipantFieldwork":False,"privacyComprehensionFieldwork":False,
   "assistiveTechnologyFieldwork":False,"accessibilityConformance":False,"permissionsExpanded":False,
   "newPersistentStore":False,"newNetworkAuthority":False,"policyModified":False,"rev0081OrRev0082Recovered":False
 },
 "nextP0":"Seal the deterministic candidate, then run fresh rev0101 18-case and whole-product sessions on actual unmanaged then-current Chromium, Firefox Release, and Firefox ESR hosts, including valid/malformed private transfer and both Exchange Source Note reviews; then separate human, privacy, and assistive-technology fieldwork."
}
dump('REVISION-STATE.json',state)

integration={
 "schema":"progrss.integration-audit.v2","revision":REV,"status":"focused-pass",
 "immediateParent":PARENT,"donor":DONOR,"mergeBase":BASE,
 "method":"three-way file merge for the delivered private-transfer product delta, followed by current-tree Exchange disclosure correction",
 "donorProductDelta":{"changedPaths":11,"addedPaths":2,"conflicts":0},
 "retainedParentWork":["runtime-record integrity","Node branch Source Note disclosure","unified rev0080 whole-product baseline"],
 "focusedResults":{"privateTransferCliTests":4,"privateTransferBrowserVariants":2,"exchangeCliTests":3,"senderReviewRendering":True,"recipientReviewRendering":True},
 "nonclaims":{"missingRevisionsRecovered":False,"targetBrowserAcceptance":False,"humanAcceptance":False}
}
dump('INTEGRATION-AUDIT.json',integration)
write('INTEGRATION-AUDIT.md',f'''# Integration audit — rev0101

Immediate parent: `{PARENT['name']}` (`{PARENT['sha256']}`)  
Delivered donor: `{DONOR['name']}` (`{DONOR['sha256']}`)  
Donor merge base: `{BASE['name']}` (`{BASE['sha256']}`)

The donor’s product delta comprised eleven changed CLI/Extension paths and two focused test additions relative to rev0098. Each changed file was merged with rev0100 as the current side and rev0098 as the common base. The merge produced no textual conflicts, retained later rev0100 code, and passed the donor’s four CLI tests plus both 16-check browser-package harnesses.

The same candidate also corrects the separately reproduced Exchange review omission. This is not a recovery claim for rev0081, rev0082, or the undelivered browser-execution-binding archive. Target-host and human gates remain open.
''')

exchange={
 "schema":"progrss.source-notes.exchange-disclosure-audit.v1","revision":REV,"status":"focused-pass",
 "parent":PARENT,
 "reproduction":{
   "apiRetainedReasons":True,"previewCountMissingBeforeFix":True,"branchCountMissingBeforeFix":True,
   "nodeSenderUiOmittedReasonsBeforeFix":True,"extensionRecipientUiOmittedReasonsBeforeFix":True,
   "evidence":["evidence/rev0101/reproduction-api-before-fix.log","evidence/rev0101/node-browser-before-fix.log","evidence/rev0101/extension-browser-before-fix.log"]
 },
 "correction":{
   "previewSourceNoteCount":True,"branchSourceNoteCount":True,"senderReviewRouteBoundReasons":True,
   "recipientReviewRouteBoundReasons":True,"absentReasonOmitted":True,"literalText":True,"multilinePreserved":True,
   "automaticDirection":True,"curatorAttribution":True,"nonSafetyBoundary":True,"network":False,"writes":False
 },
 "focusedTests":{"cli":3,"nodeRendering":"pass","extensionRendering":"pass"},
 "permissionsExpanded":False,"newPersistentStore":False,"newNetworkAuthority":False
}
dump('EXCHANGE-SOURCE-NOTE-DISCLOSURE-AUDIT.json',exchange)
write('EXCHANGE-SOURCE-NOTE-DISCLOSURE-AUDIT.md',f'''# Exchange Source Note disclosure audit — rev0101

The source-list artifact already retained route-bound reasons, but the sender’s Node review and recipient’s Extension review omitted them. The before-fix logs preserve the failure. The corrected preview exposes the exact total and branch totals; both shipped reviews render each reason beside its direct folder route, omit absent values, preserve literal line breaks, use content-derived direction, identify the curator, and state that the text is not a ProgRSS safety claim.

Focused result: three CLI contract tests, the shipped Node rendering smoke, and the shipped Extension rendering smoke passed. Review remains read-only: `network:false`, `writes:false`, no new permission, no new store, and no pairing or synchronization authority.
''')

# Runtime matrix.
rows=[
 {"id":"unified-rev0100-parent","status":"pass","scope":"rev0100 whole-product tree retained"},
 {"id":"private-transfer-donor-integration","status":"focused-pass","scope":"four CLI tests and two 16-check browser-package variants"},
 {"id":"exchange-api-disclosure","status":"focused-pass","scope":"exact total, branch count, placements, digest sensitivity, no network/write authority"},
 {"id":"exchange-node-sender-review","status":"focused-pass","scope":"managed shipped Node rendering"},
 {"id":"exchange-extension-recipient-review","status":"focused-pass","scope":"managed shipped Extension rendering"},
 {"id":"runtime-catalog-binding","status":"pass","scope":"18 cases; session v5/result v3; fresh rev0101 preparation required"},
 {"id":"complete-offline-regression","status":"pending"},
 {"id":"deterministic-seal","status":"external-postbuild-report-required"},
 {"id":"unmanaged-current-chromium","status":"not-run"},
 {"id":"firefox-release","status":"not-run"},
 {"id":"firefox-esr","status":"not-run"},
 {"id":"unfamiliar-curators-and-recipients","status":"not-run"},
 {"id":"separate-sender-recipient-diagnostic-privacy","status":"not-run"},
 {"id":"real-assistive-technologies","status":"not-run"},
]
dump('SOURCE-NOTES-RUNTIME-MATRIX.json',{"revision":REV,"releaseGateClosed":False,"inheritedEvidence":"Earlier records retain their original identities and scopes; exact rev0101 product bytes require fresh target-host sessions.","rows":rows})
write('SOURCE-NOTES-RUNTIME-MATRIX.md','# Source Notes runtime and release matrix — rev0101\n\n| Row | Status | Scope |\n|---|---|---|\n'+'\n'.join(f"| `{r['id']}` | **{r['status'].upper()}** | {r.get('scope','')} |" for r in rows)+'\n\nThe release gate remains open. Focused managed evidence does not close installed-browser or fieldwork rows.')

write('SOURCE-NOTES-RUNTIME-PROTOCOL.md',f'''# Source Notes runtime protocol — rev0101

The fixed catalog contains exactly 18 behavioral cases and is bound to `{REV}`. Sessions use `progrss.source-notes.runtime-session.v5`; results and predicates use v3. Older records retain their identities and may not be relabeled.

Before execution, verify the immutable Roadcase, selected browser package, fixture, official channel-source bytes, profile state, installation method, and permission-observation mode. Record one valid UTC interval containing every attempted case and event. Preserve first failures, interruptions, retries, recovery, actual native artifacts, and complete permission projections.

The `two-folder-independence` case includes private transfer preview/restore/export/copy-check/Undo plus malformed-file refusal. `complete-route-disclosure` includes ready-to-host publication and both Exchange reviews. `selected-branch-preservation` includes the Node branch operation and Exchange branch reason count. These additions do not create a nineteenth case.

Temporary Firefox loading is development-runtime evidence; restart and signed-install permission conclusions require an installation method that can actually exercise them.
''')

write('RUNTIME-OPERATOR-GUIDE.md',f'''# Runtime operator guide — rev0101

1. Use the sealed rev0101 Roadcase; record its SHA-256 before extraction.
2. Capture fresh official Stable/Release/ESR channel evidence on the execution host.
3. Prepare a new session-v5 record. Do not edit an older session’s revision.
4. Use a fresh unmanaged profile and record installation method and visible permissions.
5. Run all 18 cases, preserving first failures and recovery.
6. For private transfer, test exact two-folder reasons, absent reason, nine malformed forms, outbound malformed state, copy checking, and guarded Undo with no network.
7. For Exchange, inspect the Node sender review before handoff creation and the Extension recipient review before choosing a door. Verify total and branch counts, route-bound reasons, literal multiline/markup-like and bidirectional values, absent-reason omission, curator attribution, and non-safety wording. Confirm no listed source is contacted.
8. Retain complete-route and selected-branch native JSON, OPML omission evidence, permission projections, screenshots or recordings needed by the case, and interruption chronology.
9. Finalize and independently verify each evidence ZIP against the same immutable Roadcase.
10. Compare Chromium Stable, Firefox Release, and Firefox ESR without treating platform differences as automatic failure or automatic acceptance.
''')

write('SOURCE-NOTES-RUNTIME-ATTESTATION.md',f'''# Runtime attestation boundary — rev0101

Runtime evidence is unsigned consistency evidence. It binds result records, referenced evidence, package bytes, fixture bytes, and native artifacts to one prepared session and Roadcase. It does not authenticate the operator, wall clock, browser download service, human presence, unmanaged state, permission comprehension, accessibility, or participant understanding. Release acceptance still requires direct review of the target-host records and separate fieldwork.
''')

write('SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.md',f'''# Runtime-evidence audit — rev0101

- Fixed catalog: 18 cases.
- Revision binding: `{REV}`.
- Session schema: v5.
- Result/predicate: v3.
- Unknown claim-bearing fields refused.
- Valid UTC chronology required for attempted work.
- Complete permission projections required for a passing unchanged-permission case.
- Native artifact roles limited to complete route and selected branch.
- Full evidence ZIPs, not standalone statements, are comparison inputs.
- Fresh rev0101 preparation required; older records cannot be relabeled.

The behavioral descriptions now include integrated private-transfer integrity and Exchange sender/recipient disclosure without increasing the case count. The complete regression result is populated after the full sweep.
''')
dump('SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.json',{
 "schema":"progrss.source-notes.runtime-evidence-audit.v1","revision":REV,"status":"pending-full-sweep",
 "cases":18,"sessionSchema":"v5","resultSchema":"v3","freshPreparationRequired":True,
 "changedCaseIds":["two-folder-independence","complete-route-disclosure","selected-branch-preservation"],
 "standaloneStatementsAccepted":False,"unknownClaimFieldsAccepted":False,"targetBrowserAcceptance":False
})

write('ROADCASE-SOURCE-NOTES-CHECKLIST.md',f'''# Roadcase Source Notes checklist — rev0101

## Native and local continuity

- [x] One optional reason per direct folder/source placement.
- [x] 280-code-point limit and Python/JavaScript parity.
- [x] Canonicalization, native integrity, disclosure, branch, OPML omission, three-way conflict, repair, Workbench, Lineage, publication, stale-write, saturated-concurrency, and whole-placement Undo coverage.
- [x] Node branch chooser and exact preview disclose route-bound reasons.
- [x] Private transfer validates and preserves route-bound reasons before use or export.
- [x] Exchange sender and recipient reviews disclose exact counts and route-bound reasons.
- [x] No automatic conflict winner.
- [x] No permission, pairing, schedule, notification, profile, or remote-state expansion.

## Release blockers

- [ ] Exact sealed bytes on unmanaged then-current Chromium Stable.
- [ ] Exact sealed bytes on Firefox Release.
- [ ] Exact sealed bytes on Firefox ESR.
- [ ] Human-visible installation and permission observations.
- [ ] Unfamiliar sender, curator, and recipient comprehension.
- [ ] Separate sender, recipient, and diagnostic privacy review.
- [ ] Screen reader, Braille, voice, switch, high zoom/reflow, forced colors, reduced motion, fatigue, and interruption sessions.

Make only the smallest correction supported by a reproduced failure or recurring independent wrong turns.
''')

print(REV)
