#!/usr/bin/env python3
"""Replay the bounded rev0085 Source Notes shipped-entrypoint gate.

This is deterministic local evidence. It is not unmanaged-browser, assistive-
technology, or unfamiliar-participant fieldwork.
"""
from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys
from typing import Sequence

ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / "fixtures" / "source-notes" / "rev0080-extension-permissions.json"
PERMISSION_FIELDS = (
    "manifest_version",
    "version",
    "permissions",
    "optional_permissions",
    "host_permissions",
    "optional_host_permissions",
)


def run(name: str, command: Sequence[str], *, env: dict[str, str] | None = None, timeout: int = 180) -> None:
    print(f"\n== {name} ==")
    completed = subprocess.run(
        list(command),
        cwd=ROOT,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        check=False,
    )
    if completed.stdout:
        print(completed.stdout.rstrip())
    if completed.returncode:
        raise RuntimeError(f"{name} failed with exit status {completed.returncode}")


def current_permission_projection(path: Path) -> dict:
    document = json.loads(path.read_text(encoding="utf-8"))
    return {key: document[key] for key in PERMISSION_FIELDS if key in document}


def verify_permissions() -> None:
    baseline = json.loads(BASELINE.read_text(encoding="utf-8"))
    mismatches: list[str] = []
    for relative, expected in baseline["manifests"].items():
        actual = current_permission_projection(ROOT / relative)
        if actual != expected:
            mismatches.append(relative)
    if mismatches:
        raise RuntimeError(f"rev0080 permission projection changed: {', '.join(mismatches)}")
    print("rev0080 manifest permission projections: unchanged")


def verify_generated_firefox() -> None:
    pairs = (
        ("background.js", "Firefox/background.js"),
        ("shared/core.js", "Firefox/shared/core.js"),
        ("shared/shared-folder.js", "Firefox/shared/shared-folder.js"),
        ("sidepanel/app.js", "Firefox/sidepanel/app.js"),
        ("sidepanel/app.css", "Firefox/sidepanel/app.css"),
    )
    changed = [f"{left} != {right}" for left, right in pairs if (ROOT / "Extension" / left).read_bytes() != (ROOT / "Extension" / right).read_bytes()]
    if changed:
        raise RuntimeError("generated Firefox sibling drift: " + "; ".join(changed))
    print("generated Firefox Source Notes paths: byte-identical to shared sources")


def main() -> int:
    try:
        run("cross-runtime reference contract", ["sh", "tools/verify-source-notes-contract.sh"])
        run(
            "Python shipped-entrypoint corpus",
            [sys.executable, "-m", "unittest", "-v", "CLI.tests.test_source_notes_entrypoints"],
        )
        run(
            "Node branch and merge-review paths",
            [
                sys.executable,
                "-m",
                "unittest",
                "-v",
                "CLI.tests.test_node_server.NodeServerTests.test_node_owned_branch_operation_is_reviewed_atomic_idempotent_and_snapshot_backed",
                "CLI.tests.test_node_server.NodeServerTests.test_merge_review_is_three_way_read_only_and_requires_admin_origin",
            ],
            timeout=300,
        )
        run(
            "Chromium-source browser core",
            ["node", "Extension/tests/source_notes_entrypoints_harness.js"],
        )
        firefox_env = dict(__import__("os").environ)
        firefox_env["PROGRSS_EXTENSION_ROOT"] = "Firefox"
        run(
            "generated-Firefox browser core",
            ["node", "Extension/tests/source_notes_entrypoints_harness.js"],
            env=firefox_env,
        )
        run(
            "Extension background export/import/update/OPML",
            ["node", "Extension/tests/background_harness.js"],
            timeout=300,
        )
        verify_permissions()
        verify_generated_firefox()
    except Exception as exc:
        print(f"rev0085 Source Notes verification failed: {exc}", file=sys.stderr)
        return 1
    print("\nrev0085 Source Notes shipped-entrypoint gate: PASS")
    print("classification: managed local replay; unmanaged browsers and human fieldwork not run")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
