#!/usr/bin/env python3
"""Generate rev0105 provenance against immutable rev0103 parent."""
from __future__ import annotations
import argparse, hashlib, json, stat, zipfile
from pathlib import Path, PurePosixPath

ROOT=Path(__file__).resolve().parents[1]
REVISION="rev0105-node-private-library-source-note-integrity"
PARENT_NAME="ProgRSS-rev0104-workbench-private-backup-integrity-2026.10.22-Roadcase.zip"
PARENT_SHA="35865a96e584408ddafbf84025de901c0ee2f0e2c93dbb30e02e4c6e3fc22d3f"
PARENT_BYTES=24498307
EXCLUDED={"RECONSTRUCTION_PROVENANCE.json","RECONSTRUCTION_PROVENANCE.md","ROADCASE-MANIFEST.json",".DS_Store"}
SKIP_DIRS={".git","node_modules","__pycache__",".pytest_cache",".mypy_cache",".ruff_cache"}

def sha(data:bytes)->str:return hashlib.sha256(data).hexdigest()
def mode_of(mode:int)->str:return oct(0o755 if stat.S_IMODE(mode)&0o111 else 0o644)

def current_rows()->dict[str,dict[str,object]]:
 rows={}
 for path in ROOT.rglob('*'):
  if not path.is_file() or path.is_symlink():continue
  rel=path.relative_to(ROOT)
  if any(part in SKIP_DIRS for part in rel.parts) or path.name in EXCLUDED or path.suffix=='.pyc' or path.name.endswith(('.zip','.sha256')):continue
  data=path.read_bytes();rows[rel.as_posix()]={'bytes':len(data),'sha256':sha(data),'mode':mode_of(path.stat().st_mode)}
 return rows

def main()->int:
 p=argparse.ArgumentParser();p.add_argument('--parent',type=Path,required=True);a=p.parse_args();raw=a.parent.read_bytes()
 if a.parent.name!=PARENT_NAME or len(raw)!=PARENT_BYTES or sha(raw)!=PARENT_SHA:raise SystemExit('parent identity mismatch')
 parent={}
 with zipfile.ZipFile(a.parent) as z:
  seen=set()
  for i in z.infolist():
   if i.filename in seen:raise SystemExit(f'duplicate parent member: {i.filename}')
   seen.add(i.filename)
   if i.is_dir() or i.filename in EXCLUDED or i.filename.endswith(('.zip','.sha256')):continue
   pure=PurePosixPath(i.filename)
   if pure.is_absolute() or '..' in pure.parts:raise SystemExit(f'unsafe parent member: {i.filename}')
   data=z.read(i);parent[i.filename]={'bytes':len(data),'sha256':sha(data),'mode':mode_of((i.external_attr>>16)&0xffff)}
 current=current_rows();added=sorted(set(current)-set(parent));deleted=sorted(set(parent)-set(current));changed=sorted(n for n in set(current)&set(parent) if current[n]!=parent[n])
 if deleted:raise SystemExit(f'unexpected deleted parent paths: {deleted[:20]}')
 claim=('Continues the sealed rev0104 unified tree and corrects a reproduced loopback Node private-library '
        'Source Note validation bypass across transactional library ingestion and read-only backup serving. '
        'The current parent already contains the unified private-transfer, Exchange, Node branch and merge, '
        'shared-folder merge, publication, Lineage, Workbench collection and backup, repair, concurrency, '
        'Undo, native-integrity, and runtime-record work. No missing revision is invented.')
 report={'schema':'progrss.reconstruction-provenance.v2','generatedUtc':'2026-10-22T00:00:00Z','reconstructionRevision':REVISION,'productLineage':{'revision':'rev0080','version':'0.80.0'},'rootBaselineArchive':'ProgRSS-rev0080-2026.10.20-Roadcase(2).zip','rootBaselineSha256':'181308cabfae43330016a272a64fbdb33038f841d605f4756ec65bedb43b8106','immediateParentArchive':PARENT_NAME,'immediateParentSha256':PARENT_SHA,'immediateParentBytes':PARENT_BYTES,'integrationDonor':None,'mergeBase':None,'lineageClaim':claim,'missingArtifacts':['rev0081','rev0082','rev0090-source-notes-browser-execution-binding'],'inventoryExclusions':sorted(EXCLUDED),'added':added,'changed':changed,'deleted':deleted,'differenceCounts':{'added':len(added),'changed':len(changed),'deleted':len(deleted)}}
 (ROOT/'RECONSTRUCTION_PROVENANCE.json').write_text(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
 (ROOT/'RECONSTRUCTION_PROVENANCE.md').write_text('# Reconstruction provenance — rev0105\n\n'+f'Immediate parent: `{PARENT_NAME}`  \nSHA-256: `{PARENT_SHA}`\n\n'+claim+'\n\n'+f'- Added paths: {len(added)}\n- Changed paths or modes: {len(changed)}\n- Deleted paths: {len(deleted)}\n\nThe exact path lists are in `RECONSTRUCTION_PROVENANCE.json`. Rev0081, rev0082, and the undelivered browser-execution-binding source archive remain unavailable.\n',encoding='utf-8')
 print(json.dumps(report['differenceCounts'],sort_keys=True));return 0
if __name__=='__main__':raise SystemExit(main())
