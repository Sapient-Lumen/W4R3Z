#!/usr/bin/env python3
"""Freeze the bounded rev0087 Source Notes runtime-kit audit.

A pass means the kit is present, fail-closed, and the available managed
non-current Chromium preflight passed with honest claim flags. It does not
close current/unmanaged Chromium, Firefox, permission-prompt, participant, or
assistive-technology gates.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence" / "rev0087"
REVISION = "rev0087-source-notes-runtime-kit"
EXPECTED_CHECKS = {
    "cancelAndEscapeNoWrite",
    "clearAndGuardedUndo",
    "completeRouteDisclosure",
    "consequenceDisclosure",
    "divergentLaterCopyPlacementDecision",
    "nativeIntegrityRefusesReasonMutation",
    "opmlOmissionEvidence",
    "ordinaryInterruptionPreservesDraftAndFocus",
    "permissionStateUnchanged",
    "realTwoViewStaleSaveRefused",
    "realTwoViewStaleUndoRefused",
    "restartPersistence",
    "selectedBranchPreservation",
    "twoFolderIndependence",
    "unicodeBoundary",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def row(identifier: str, surface: str, status: str, evidence: list[str], limitation: str) -> dict[str, Any]:
    return {
        "id": identifier,
        "surface": surface,
        "status": status,
        "evidence": evidence,
        "limitation": limitation,
    }


def main() -> int:
    runtime_path = EVIDENCE / "available-chromium-worktree-runtime.json"
    runtime = json.loads(runtime_path.read_text(encoding="utf-8"))
    snapshot = json.loads((ROOT / "BROWSER-CHANNEL-SNAPSHOT.json").read_text(encoding="utf-8"))
    harness_path = ROOT / "Extension" / "tests" / "source_notes_installed_acceptance.py"
    harness = harness_path.read_text(encoding="utf-8")
    preparer_path = ROOT / "tools" / "prepare-source-notes-runtime-session.py"
    preparer = preparer_path.read_text(encoding="utf-8")
    protocol_path = ROOT / "SOURCE-NOTES-RUNTIME-PROTOCOL.md"

    current_stable = snapshot["channelReferences"]["chromiumStable"]["version"]
    available = runtime["environment"]["browserCommandVersion"]
    checks = {
        "runtimeEvidencePass": runtime.get("pass") is True,
        "allFifteenScenarioChecksPass": EXPECTED_CHECKS == {key for key, value in runtime.get("checks", {}).items() if value},
        "managedClassification": runtime.get("claimBoundary", {}).get("classification") == "managed-exact-archive-runtime-preflight",
        "unmanagedClaimFalse": runtime.get("claimBoundary", {}).get("unmanagedBrowserAcceptance") is False,
        "currentStableClaimFalse": runtime.get("claimBoundary", {}).get("currentStableAcceptance") is False,
        "permissionPromptClaimFalse": runtime.get("claimBoundary", {}).get("humanPermissionPromptObservation") is False,
        "humanAndAtClaimsFalse": all(
            runtime.get("claimBoundary", {}).get(key) is False
            for key in ("accessibilityConformance", "assistiveTechnologyEvidence", "unfamiliarPersonComprehension")
        ),
        "policyOverrideDeclared": runtime.get("environment", {}).get("policyOverrideDeclared") is True,
        "availableBrowserRecordedNonCurrent": "144.0.7559.96" in available and not available.startswith(current_stable),
        "worktreeRunNotMislabelledFinalArchive": "roadcase" not in runtime.get("package", {}),
        "noSourceNoteTestHooks": "test-source-note-" not in harness,
        "twoRealViews": "open two real extension views" in harness and "page_a" in harness and "page_b" in harness,
        "productionStaleUndoRequest": "undo-source-placement-reason" in harness and "STALE_SOURCE_NOTE_UNDO" in harness,
        "archiveIdentityCheckImplemented": "archiveMatchesExtractedExtension" in harness,
        "preparerFailClosed": all(marker in preparer for marker in (
            "verify_roadcase", "unsafe archive member", "preparedOnly", '"runtimeExecuted": False', "PACKAGE-MANIFEST.json"
        )),
        "protocolPresent": protocol_path.is_file() and "Blocked, unavailable, skipped, and timed-out work never becomes a pass" in protocol_path.read_text(encoding="utf-8"),
    }
    passed = all(checks.values())

    matrix_rows = [
        row(
            "exact-roadcase-session-kit",
            "Roadcase verifier, package preparer, protocol, and Chromium acceptance harness",
            "pass" if checks["preparerFailClosed"] and checks["archiveIdentityCheckImplemented"] and checks["protocolPresent"] else "not-established",
            ["tools/prepare-source-notes-runtime-session.py", "SOURCE-NOTES-RUNTIME-PROTOCOL.md", "Extension/tests/source_notes_installed_acceptance.py"],
            "Preparation and automation do not execute an unmanaged browser or a human session.",
        ),
        row(
            "available-chromium-managed-worktree-preflight",
            "Debian Chromium 144 under headed virtual display",
            "pass" if runtime.get("pass") is True else "not-established",
            ["evidence/rev0087/available-chromium-worktree-runtime.json", "evidence/rev0087/available-chromium-worktree-runtime.log", "evidence/rev0087/runtime-worktree-artifacts/"],
            f"Managed, policy-declared, worktree-bound and non-current. Current Stable reference is {current_stable}; exact final Roadcase identity is not claimed by this row.",
        ),
        row(
            "exact-final-roadcase-managed-preflight",
            "Available Chromium against a clean extraction of the immutable final rev0087 Roadcase",
            "not-run",
            [],
            "This can be sealed only after the immutable Roadcase is built; keep the result external to avoid self-reference.",
        ),
        row(
            "unmanaged-current-chromium",
            f"Unmanaged current Chromium Stable ({current_stable} reference)",
            "not-run",
            [],
            "Chromium 144 managed automation cannot close this row.",
        ),
        row(
            "firefox-release",
            f"Firefox Release {snapshot['channelReferences']['firefoxRelease']['version']}",
            "not-run",
            [],
            "No Firefox binary was available. Generated-file parity is not runtime evidence.",
        ),
        row(
            "firefox-esr",
            f"Firefox ESR {snapshot['channelReferences']['firefoxEsr']['version']}",
            "not-run",
            [],
            "No Firefox ESR binary was available. Generated-file parity is not runtime evidence.",
        ),
        row(
            "unfamiliar-person-and-assistive-technology-fieldwork",
            "Unfamiliar curators/recipients and real assistive technologies",
            "not-run",
            [],
            "No automation may close this row.",
        ),
    ]
    matrix = {
        "schema": "progrss.source-notes.runtime-matrix.v1",
        "revision": REVISION,
        "productLineage": {"revision": "rev0080", "version": "0.80.0"},
        "classification": "candidate-managed-noncurrent-runtime-preflight",
        "releaseGateClosed": False,
        "summary": {
            "pass": sum(item["status"] == "pass" for item in matrix_rows),
            "notRun": sum(item["status"] == "not-run" for item in matrix_rows),
            "notEstablished": sum(item["status"] == "not-established" for item in matrix_rows),
        },
        "rows": matrix_rows,
    }
    (ROOT / "SOURCE-NOTES-RUNTIME-MATRIX.json").write_text(
        json.dumps(matrix, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    with (ROOT / "SOURCE-NOTES-RUNTIME-MATRIX.md").open("w", encoding="utf-8") as handle:
        handle.write("# Source Notes runtime matrix — rev0087\n\n")
        handle.write("The two passes below are preparation and managed non-current preflight only. The release gate remains open.\n\n")
        handle.write("| Surface | Status | Evidence | Limitation |\n|---|---:|---|---|\n")
        for item in matrix_rows:
            evidence = ", ".join(f"`{value}`" for value in item["evidence"]) or "—"
            handle.write(f"| {item['surface']} | **{item['status']}** | {evidence} | {item['limitation'].replace('|', '\\|')} |\n")
        handle.write("\n## Release-blocking order\n\n")
        handle.write("1. Seal the exact final Roadcase in the available browser as external managed evidence.\n")
        handle.write("2. Run the same immutable package in unmanaged current Chromium Stable.\n")
        handle.write("3. Run the generated sibling in current Firefox Release and Firefox ESR.\n")
        handle.write("4. Only then begin unfamiliar-person and real assistive-technology fieldwork.\n")

    audit = {
        "schema": "progrss.source-notes.runtime-kit-audit.v1",
        "revision": REVISION,
        "classification": "candidate-managed-noncurrent-runtime-preflight",
        "pass": passed,
        "releaseGateClosed": False,
        "checks": checks,
        "browserReferences": snapshot["channelReferences"],
        "availablePreflight": {
            "browser": available,
            "pass": runtime.get("pass"),
            "policyOverrideDeclared": runtime.get("environment", {}).get("policyOverrideDeclared"),
            "worktreeBound": "roadcase" not in runtime.get("package", {}),
            "scenarioChecks": sorted(runtime.get("checks", {})),
            "extensionSubtreeSha256": runtime.get("package", {}).get("extensionSubtreeSha256"),
            "fixtureSha256": runtime.get("package", {}).get("fixtureSha256"),
        },
        "explicitNonClaims": [
            "exact final Roadcase runtime (inside this self-contained candidate)",
            "unmanaged current Chromium runtime",
            "Firefox Release runtime",
            "Firefox ESR runtime",
            "human signed-install permission-prompt observation",
            "accessibility conformance",
            "real assistive-technology evidence",
            "unfamiliar-person comprehension",
        ],
        "fileDigests": {
            "Extension/tests/source_notes_installed_acceptance.py": sha256(harness_path),
            "tools/prepare-source-notes-runtime-session.py": sha256(preparer_path),
            "SOURCE-NOTES-RUNTIME-PROTOCOL.md": sha256(protocol_path),
            "BROWSER-CHANNEL-SNAPSHOT.json": sha256(ROOT / "BROWSER-CHANNEL-SNAPSHOT.json"),
            "evidence/rev0087/available-chromium-worktree-runtime.json": sha256(runtime_path),
        },
    }
    (ROOT / "SOURCE-NOTES-RUNTIME-AUDIT.json").write_text(
        json.dumps(audit, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    lines = [
        "# Source Notes runtime-kit audit — rev0087",
        "",
        f"**Result:** {'PASS' if passed else 'NOT ESTABLISHED'} for the kit and managed non-current worktree preflight.",
        "",
        "The available run used Debian Chromium 144, a fresh persistent profile, a headed virtual display, Playwright/CDP, and an explicitly declared temporary policy override. All 15 focused scenarios passed. This is useful implementation evidence, but it is neither current Stable nor unmanaged and it is not bound to the final immutable Roadcase.",
        "",
        "## What the kit adds",
        "",
        "- A real installed-extension Chromium scenario using two live extension views, shipped background requests, real IndexedDB, profile restart, native export/import/update, digest refusal, and screenshots.",
        "- An exact-Roadcase session preparer that verifies the archive and extracts only the selected Chromium or Firefox package while recording package and fixture identity.",
        "- A fail-closed checklist and result vocabulary that keep prepared, blocked, skipped, managed, temporary-install, and human evidence separate.",
        "- An online channel snapshot that prevents Chromium 144 from being mislabeled as the current Stable reference of 156.0.8078.47.",
        "",
        "## Still release-blocking",
        "",
        "Exact final-Roadcase seal, unmanaged current Chromium, Firefox Release, Firefox ESR, human permission-prompt observation where applicable, unfamiliar-person comprehension, and real assistive-technology sessions remain open.",
        "",
    ]
    (ROOT / "SOURCE-NOTES-RUNTIME-AUDIT.md").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({"pass": passed, "checks": checks, "runtimeMatrix": matrix["summary"]}, sort_keys=True))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
