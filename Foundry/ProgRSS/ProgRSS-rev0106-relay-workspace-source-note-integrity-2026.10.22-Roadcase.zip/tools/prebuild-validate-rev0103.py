#!/usr/bin/env python3
"""Fail-closed prebuild validation for rev0103."""
from __future__ import annotations
import json, py_compile, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REVISION='rev0103-shared-folder-merge-source-note-disclosure'

def main()->int:
 assert (ROOT/'REVISION').read_text(encoding='utf-8').strip()==REVISION
 state=json.loads((ROOT/'REVISION-STATE.json').read_text(encoding='utf-8'))
 assert state['revision']==REVISION and state['releaseGateClosed'] is False
 cases=json.loads((ROOT/'SOURCE-NOTES-RUNTIME-CASES.json').read_text(encoding='utf-8'))
 assert cases['revision']==REVISION and len(cases['cases'])==18 and len({x['id'] for x in cases['cases']})==18
 keep=next(x for x in cases['cases'] if x['id']=='divergent-later-copy-keep-mine')
 curator=next(x for x in cases['cases'] if x['id']=='divergent-later-copy-use-curator')
 assert 'Extension shared-folder update review' in keep['description'] and 'Extension shared-folder update review' in curator['description']
 sys.path.insert(0,str(ROOT/'tools'))
 from source_notes_runtime_evidence import REVISION as EVIDENCE_REVISION, case_catalog
 assert EVIDENCE_REVISION==REVISION and case_catalog()==cases
 schema=json.loads((ROOT/'SOURCE-NOTES-RUNTIME-RESULT.schema.json').read_text(encoding='utf-8'))
 assert schema['properties']['revision']['const']==REVISION
 audit=json.loads((ROOT/'SHARED-FOLDER-MERGE-SOURCE-NOTE-DISCLOSURE-AUDIT.json').read_text(encoding='utf-8'))
 continuity=json.loads((ROOT/'PRODUCT-CONTINUITY-AUDIT.json').read_text(encoding='utf-8'))
 integration=json.loads((ROOT/'INTEGRATION-AUDIT.json').read_text(encoding='utf-8'))
 assert audit['revision']==REVISION and audit['status']=='focused-pass'
 assert audit['correction']['canonicalFolderPath'] and audit['correction']['sameTitleRoutesDistinguished']
 assert audit['correction']['network'] is False and audit['correction']['writesChanged'] is False
 assert continuity['revision']==REVISION and continuity['status']=='pass'
 assert continuity['permissionsExpanded'] is False and continuity['newNetworkAuthority'] is False
 assert integration['revision']==REVISION and integration['status']=='pass'
 provenance=json.loads((ROOT/'RECONSTRUCTION_PROVENANCE.json').read_text(encoding='utf-8'))
 expected_lineage=(
  'Continues the sealed rev0102 unified tree and corrects a reproduced Extension shared-folder '
  'three-way Source Note route and disclosure omission. The current parent already contains the '
  'delivered private-transfer, Exchange, Node branch, and Node merge disclosure work. '
  'No missing revision is invented.'
 )
 assert provenance['reconstructionRevision']==REVISION
 assert provenance['immediateParentArchive']=='ProgRSS-rev0102-node-merge-source-note-disclosure-2026.10.22-Roadcase.zip'
 assert provenance['lineageClaim']==expected_lineage
 status=json.loads((ROOT/'evidence/rev0103/regression-status.json').read_text(encoding='utf-8'))
 assert status['complete'] and status['allPassed']
 labels={x['label']:x for x in status['rows']}
 required={'cli-test_node_server','node-browser-smoke','node-merge-source-notes','extension-browser-smoke','extension-complete','evidence-boundary','contract','shared-folder-merge-review-chromium','shared-folder-merge-review-firefox','background_harness'}
 assert required<=set(labels) and all(labels[x]['returncode']==0 for x in required)
 assert status['managedNodeHarnessInvocations']==22
 assert status['managedSharedFolderMergeUiPathVariants']==2
 background=(ROOT/'Extension/background.js').read_text(encoding='utf-8')
 app=(ROOT/'Extension/sidepanel/app.js').read_text(encoding='utf-8')
 css=(ROOT/'Extension/sidepanel/app.css').read_text(encoding='utf-8')
 assert background==(ROOT/'Extension/Firefox/background.js').read_text(encoding='utf-8')
 assert app==(ROOT/'Extension/Firefox/sidepanel/app.js').read_text(encoding='utf-8')
 assert css==(ROOT/'Extension/Firefox/sidepanel/app.css').read_text(encoding='utf-8')
 for phrase in ('incomingFolderPathById','folderPath: C.text(folderPath'):
  assert phrase in background
 for phrase in ('sharedFolderSourceNoteRoute','Curator’s reason for this folder','not a ProgRSS safety claim','Last accepted curator reason','Your reason','Curator’s reason'):
  assert phrase in app
 for phrase in ('.merge-source-note-route','.merge-source-note-value','white-space: pre-wrap','unicode-bidi: plaintext'):
  assert phrase in css
 for rel in (
  'tools/run-rev0103-regressions.py','tools/verify-rev0103-shared-folder-merge-disclosure.py',
  'tools/audit-rev0103-product-continuity.py','tools/update-rev0103-provenance.py',
  'tools/write-rev0103-authority.py','tools/build-rev0103-roadcase.py',
  'Extension/tests/source_notes_shared_folder_merge_review_harness.py',
 ):
  path=ROOT/rel; assert path.is_file(), rel; py_compile.compile(str(path),doraise=True)
 for path in ROOT.rglob('*.json'):
  if 'node_modules' not in path.parts: json.loads(path.read_text(encoding='utf-8'))
 subprocess.run(['node','--check',str(ROOT/'Extension/background.js')],check=True)
 subprocess.run(['node','--check',str(ROOT/'Extension/sidepanel/app.js')],check=True)
 assert not [p for p in ROOT.rglob('*.pyc') if '__pycache__' not in p.parts]
 print('PASS rev0103 prebuild validation: route-scoped shared-folder merge disclosure, complete regressions, 18-case binding, JSON, Python, and Node syntax.')
 return 0
if __name__=='__main__': raise SystemExit(main())
