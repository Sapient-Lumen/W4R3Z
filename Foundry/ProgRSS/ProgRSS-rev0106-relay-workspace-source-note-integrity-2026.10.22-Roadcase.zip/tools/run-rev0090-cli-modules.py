#!/usr/bin/env python3
"""Run each shipped CLI test module independently for rev0090 evidence."""
from __future__ import annotations
import json
from pathlib import Path
import subprocess
import sys
import time
ROOT = Path(__file__).resolve().parents[1]
CLI = ROOT / "CLI"
OUT = ROOT / "evidence" / "rev0090"
MODULES = (
    "tests.test_acquisition", "tests.test_cadence", "tests.test_cli",
    "tests.test_command_line", "tests.test_debrief", "tests.test_fieldbook",
    "tests.test_node_server", "tests.test_node_store", "tests.test_relay",
    "tests.test_roadcase", "tests.test_source_notes_entrypoints",
)
def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    rows=[]
    for module in MODULES:
        log_name="cli-"+module.removeprefix("tests.").replace(".","_")+".log"
        started=time.monotonic()
        try:
            result=subprocess.run([sys.executable,"-m","unittest","-v",module],cwd=CLI,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=600,check=False)
            output=result.stdout; returncode=result.returncode
        except subprocess.TimeoutExpired as error:
            output=(error.stdout or "")+"\nTIMEOUT\n"; returncode=124
        row={"module":module,"log":log_name,"returncode":returncode,"seconds":round(time.monotonic()-started,3),"state":"pass" if returncode==0 else "fail"}
        (OUT/log_name).write_text(output,encoding="utf-8")
        rows.append(row); print(json.dumps(row,sort_keys=True),flush=True)
        if returncode: break
    summary={"schema":"progrss.test-module-summary.v1","revision":"rev0090-verified-runtime-comparison","generatedUtc":"2026-10-21T00:00:00Z","allPassed":len(rows)==len(MODULES) and all(r["returncode"]==0 for r in rows),"results":rows}
    (OUT/"cli-modules-summary.json").write_text(json.dumps(summary,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")
    return 0 if summary["allPassed"] else 1
if __name__ == "__main__": raise SystemExit(main())
