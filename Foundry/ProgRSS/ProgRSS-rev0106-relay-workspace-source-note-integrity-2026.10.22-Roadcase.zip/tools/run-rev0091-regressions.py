#!/usr/bin/env python3
"""Run offline/native and mocked-API regressions; no installed-browser evidence."""
import subprocess, json, os, sys, time, re
from pathlib import Path
root=Path(__file__).resolve().parents[1];out=root/'evidence'/'rev0091';out.mkdir(parents=True,exist_ok=True);env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
rows=[]
modules=['test_acquisition','test_cadence','test_cli','test_command_line','test_debrief','test_fieldbook','test_node_server','test_node_store','test_relay','test_roadcase','test_source_notes_entrypoints']
commands=[('cli-'+m,[sys.executable,'-m','unittest','-v','CLI.tests.'+m],root,{}) for m in modules]
commands += [('extension-static',[sys.executable,'-m','unittest','discover','-s','tests','-p','test_*.py','-v'],root/'Extension',{})]
for name in ['background_harness','relay_core_harness','source_notes_entrypoints_harness','firefox_background_harness','acquisition_harness','vault_conflict_harness','source_notes_folder_undo_harness']:
 commands.append((name,['node','Extension/tests/'+name+'.js'],root,{}))
for name in ['source_notes_entrypoints_harness','source_notes_folder_undo_harness']:
 commands.append((name+'-firefox',['node','Extension/tests/'+name+'.js'],root,{'PROGRSS_EXTENSION_ROOT':'Firefox'}))
commands += [('contract',['sh','tools/verify-source-notes-contract.sh'],root,{}),('evidence-boundary',[sys.executable,'-m','unittest','-v','tests.test_source_notes_runtime_evidence','tests.test_verified_runtime_comparison'],root,{})]
for label,cmd,cwd,extra in commands:
 started=time.monotonic();log=out/(label+'.log')
 with log.open('w') as f:
  try:
   cp=subprocess.run(cmd,cwd=cwd,env=dict(env,**extra),stdout=f,stderr=subprocess.STDOUT,timeout=600)
   code=cp.returncode
  except subprocess.TimeoutExpired:
   code=124;f.write('\nTIMEOUT (not a pass)\n')
 text=log.read_text();matches=re.findall(r'Ran (\d+) tests?',text)
 row={'label':label,'command':cmd,'returncode':code,'seconds':round(time.monotonic()-started,3),'tests':int(matches[-1]) if matches else None,'log':log.name}
 rows.append(row); print(json.dumps(row),flush=True)
 (out/'regression-status.json').write_text(json.dumps({'complete':False,'rows':rows},indent=2)+'\n')
(out/'regression-status.json').write_text(json.dumps({'complete':True,'allPassed':all(r['returncode']==0 for r in rows),'rows':rows,'browserAutomationExecuted':False},indent=2)+'\n')
