#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
CONTRACT="$ROOT/source_notes_contract"
PYTHON_BIN=${PYTHON:-python3}
NODE_BIN=${NODE:-node}

"$PYTHON_BIN" "$CONTRACT/test_source_notes.py"
"$NODE_BIN" "$CONTRACT/test-source-notes.mjs"
TMPDIR_BASE=${TMPDIR:-/tmp}
PY_OUT=$(mktemp "$TMPDIR_BASE/progrss-source-notes-python.XXXXXX")
JS_OUT=$(mktemp "$TMPDIR_BASE/progrss-source-notes-js.XXXXXX")
trap 'rm -f "$PY_OUT" "$JS_OUT"' EXIT HUP INT TERM
"$PYTHON_BIN" "$CONTRACT/emit-python-results.py" > "$PY_OUT"
"$NODE_BIN" "$CONTRACT/emit-js-results.mjs" > "$JS_OUT"
cmp "$PY_OUT" "$JS_OUT"
printf '%s\n' 'source-notes Python/JavaScript parity: byte-identical fixture output'
