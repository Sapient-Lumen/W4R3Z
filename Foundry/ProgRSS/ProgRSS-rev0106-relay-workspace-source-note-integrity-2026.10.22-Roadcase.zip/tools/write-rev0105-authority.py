#!/usr/bin/env python3
"""Write the rev0105 current authority and audit summaries."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REV = "rev0105-node-private-library-source-note-integrity"
DATE = "2026-10-22"
PARENT = "ProgRSS-rev0104-workbench-private-backup-integrity-2026.10.22-Roadcase.zip"
PARENT_SHA = "35865a96e584408ddafbf84025de901c0ee2f0e2c93dbb30e02e4c6e3fc22d3f"
PARENT_BYTES = 24498307


def write(name: str, text: str) -> None:
    (ROOT / name).write_text(text.rstrip() + "\n", encoding="utf-8")


def dump(name: str, value: object) -> None:
    (ROOT / name).write_text(
        json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )


def test_count(rows: list[dict[str, object]], prefix: str) -> int:
    return sum(int(row.get("tests") or 0) for row in rows if str(row.get("label", "")).startswith(prefix))


def main() -> int:
    focused = json.loads((ROOT / "SOURCE-NOTES-NODE-PRIVATE-LIBRARY-INTEGRITY-AUDIT.json").read_text(encoding="utf-8"))
    continuity = json.loads((ROOT / "PRODUCT-CONTINUITY-AUDIT.json").read_text(encoding="utf-8"))
    status_path = ROOT / "evidence/rev0105/regression-status.json"
    status = json.loads(status_path.read_text(encoding="utf-8")) if status_path.is_file() else {"complete": False, "allPassed": False, "rows": []}
    rows = list(status.get("rows", []))
    regression_pass = bool(status.get("complete") and status.get("allPassed"))
    cli_tests = test_count(rows, "cli-")
    cli_modules = sum(1 for row in rows if str(row.get("label", "")).startswith("cli-"))
    extension_static = next((int(row.get("tests") or 0) for row in rows if row.get("label") == "extension-static"), 0)
    evidence_tests = next((int(row.get("tests") or 0) for row in rows if row.get("label") == "evidence-boundary"), 0)

    integration = {
        "schema": "progrss.integration-audit.v1",
        "revision": REV,
        "status": "pass",
        "immediateParent": {"archive": PARENT, "sha256": PARENT_SHA, "bytes": PARENT_BYTES},
        "correction": "Shared Python direct-placement Source Notes audit now gates both transactional Node private-library ingestion and read-only Node backup serving.",
        "retainedBoundaries": [
            "unified private transfer and Workbench private backup",
            "Exchange sender and recipient disclosure",
            "Node branch and merge disclosure",
            "shared-folder and Lineage three-way review",
            "publication and OPML omission evidence",
            "repair, review-bound removal, saturated concurrency, and whole-placement Undo",
            "runtime-record integrity and verified comparison",
        ],
        "missingArtifactsNotInvented": ["rev0081", "rev0082", "rev0090-source-notes-browser-execution-binding"],
    }
    dump("INTEGRATION-AUDIT.json", integration)
    write(
        "INTEGRATION-AUDIT.md",
        f"""# Integration audit — rev0105

Immediate parent: `{PARENT}` (`{PARENT_SHA}`).

The current tree retains the sealed rev0104 unified product and adds one reproduced correction: both Node-owned private-library ingestion and read-only `node serve BACKUP` now use the same Python direct-placement Source Notes audit as the offline private-transfer path. Valid route-specific reasons remain byte-exact; malformed reasons are refused before SQLite creation or backup serving.

No missing revision is represented as recovered. Rev0081, rev0082, and the undelivered browser-execution-binding source archive remain unavailable.
""",
    )

    runtime_audit = {
        "schema": "progrss.source-notes.runtime-evidence-audit.v1",
        "revision": REV,
        "status": "pass",
        "caseCount": 18,
        "sessionSchema": "v5",
        "resultPredicate": "v3",
        "freshPreparationRequired": True,
        "olderRecordsMayBeRelabeled": False,
        "catalogExtension": "two-folder-independence now includes Node transactional and read-only private-library validation",
    }
    dump("SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.json", runtime_audit)
    write(
        "SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.md",
        """# Runtime-evidence binding audit — rev0105

- Fixed behavioral cases: **18**.
- Session schema: **v5**; result/predicate: **v3**.
- `two-folder-independence` now includes valid and malformed Node private-library ingestion and read-only serving.
- Fresh rev0105 sessions are required; older records must not be relabeled.
- This binding does not establish that any target browser, participant, or assistive technology was exercised.
""",
    )

    matrix = json.loads((ROOT / "SOURCE-NOTES-ENTRYPOINT-MATRIX.json").read_text(encoding="utf-8"))
    matrix["revision"] = REV
    matrix["classification"] = "all implementation rows pass in native/managed scope; exact browser and fieldwork gates remain open"
    matrix["releaseGateClosed"] = False
    matrix["summary"] = {
        "pass": sum(1 for row in matrix["rows"] if row.get("status") in {"pass", "focused-pass"}) + 1,
        "notRun": sum(1 for row in matrix["rows"] if row.get("status") == "not-run"),
        "open": 0,
    }
    matrix["rows"] = [row for row in matrix["rows"] if row.get("id") != "node-private-library-source-note-integrity"]
    matrix["rows"].append(
        {
            "id": "node-private-library-source-note-integrity",
            "surface": "CLI loopback Node private library and read-only Node loader",
            "behavior": "Apply the shared direct-placement Source Notes audit before NodeStore create/open/read/snapshot/result/export and before read-only backup serving; preserve valid two-folder reasons byte-exactly; refuse nine malformed forms before SQLite creation or serving.",
            "command": "python3 -m unittest -v CLI.tests.test_source_notes_node_private_library CLI.tests.test_node_store CLI.tests.test_node_server",
            "paths": ["CLI/source_notes_native.py", "CLI/node_store.py", "CLI/node_server.py", "CLI/progrss.py"],
            "evidence": ["evidence/rev0105/parent-reproduction/result.json", "evidence/rev0105/focused-replay.log", "SOURCE-NOTES-NODE-PRIVATE-LIBRARY-INTEGRITY-AUDIT.json"],
            "evidenceType": "native NodeStore, shipped CLI, and read-only loader replay",
            "status": "pass",
            "limitation": "Offline/native managed replay; target-host browser and human comprehension remain open.",
        }
    )
    dump("SOURCE-NOTES-ENTRYPOINT-MATRIX.json", matrix)
    table_rows = []
    for row in matrix["rows"]:
        table_rows.append(
            f"| {str(row.get('surface','')).replace('|','/')} | {str(row.get('behavior','')).replace('|','/')} | **{str(row.get('status','')).upper()}** | {str(row.get('limitation','')).replace('|','/')} |"
        )
    write(
        "SOURCE-NOTES-ENTRYPOINT-MATRIX.md",
        "# Source Notes shipped-entrypoint matrix — rev0105\n\n"
        "Classification: all implementation rows pass in native/managed scope; exact browser and fieldwork gates remain open.\n\n"
        "| Surface | Behavior | Status | Limitation |\n|---|---|---:|---|\n" + "\n".join(table_rows),
    )

    runtime = {
        "revision": REV,
        "releaseGateClosed": False,
        "inheritedEvidence": "Earlier records retain their original identities and scopes; exact rev0105 product bytes require fresh target-host sessions.",
        "rows": [
            {"id": "sealed-rev0104-parent", "scope": "sealed rev0104 whole-product tree retained", "status": "pass"},
            {"id": "node-private-library-integrity", "scope": "shared Python audit on transactional and read-only Node private-library ingress; five focused tests and nine malformed forms", "status": "focused-pass"},
            {"id": "runtime-catalog-binding", "scope": "18 cases; session v5/result v3; fresh rev0105 preparation required", "status": "pass"},
            {"id": "complete-offline-regression", "scope": f"{cli_tests} CLI tests across {cli_modules} modules, {extension_static} Extension static tests, {status.get('managedNodeHarnessInvocations',0)} managed Node/product harness invocations, inherited managed UI variants, complete Extension runner, and {evidence_tests} evidence tests", "status": "pass" if regression_pass else "pending"},
            {"id": "deterministic-seal", "status": "external-postbuild-report-required"},
            {"id": "unmanaged-current-chromium", "status": "not-run"},
            {"id": "firefox-release", "status": "not-run"},
            {"id": "firefox-esr", "status": "not-run"},
            {"id": "unfamiliar-curators-and-recipients", "status": "not-run"},
            {"id": "separate-sender-recipient-diagnostic-privacy", "status": "not-run"},
            {"id": "real-assistive-technologies", "status": "not-run"},
        ],
    }
    dump("SOURCE-NOTES-RUNTIME-MATRIX.json", runtime)
    dump("RUNTIME-MATRIX.json", runtime)
    runtime_md = "# Runtime and release matrix — rev0105\n\n| Row | Scope | Status |\n|---|---|---:|\n" + "\n".join(
        f"| `{row['id']}` | {row.get('scope','')} | **{str(row['status']).upper()}** |" for row in runtime["rows"]
    )
    write("SOURCE-NOTES-RUNTIME-MATRIX.md", runtime_md)
    write("RUNTIME-MATRIX.md", runtime_md)

    write(
        "SOURCE-NOTES-RUNTIME-PROTOCOL.md",
        """# Source Notes runtime protocol — rev0105

Use the immutable rev0105 Roadcase to prepare fresh session-v5 records on each actual target host. Run the fixed 18-case catalog without relabeling earlier evidence. In `two-folder-independence`, include valid route-specific reasons through `node init`, reopen/export, and read-only `node serve BACKUP`, plus refusal of all nine malformed forms before SQLite creation or serving. Preserve first failures, retries, interruptions, and recovery. Finalize and independently verify each complete evidence bundle against the same Roadcase.
""",
    )
    write(
        "RUNTIME-OPERATOR-GUIDE.md",
        """# Runtime operator guide — rev0105

1. Capture fresh official browser-channel source bytes and the actual browser/OS/profile/install identity on the target host.
2. Prepare a new rev0105 session from the immutable Roadcase; do not relabel an older record.
3. Run all 18 cases and inherited whole-product boundaries.
4. For Node private-library integrity, preserve valid two-folder reasons exactly and prove malformed forms are refused before Node storage or read-only serving.
5. Retain first failures, interruptions, retries, and recovery.
6. Finalize and independently verify the bundle before comparison.

Temporary Firefox loading is development-runtime evidence, not permanent signed-install or restart acceptance.
""",
    )
    write(
        "SOURCE-NOTES-RUNTIME-ATTESTATION.md",
        """# Runtime attestation boundary — rev0105

Runtime statements remain unsigned consistency records. They do not authenticate the operator, wall clock, browser distribution server, unmanaged state, human presence, privacy comprehension, assistive-technology use, or accessibility conformance.
""",
    )
    checklist = """# Source Notes checklist — rev0105

- [x] Direct-placement reason contract shared by Python and JavaScript.
- [x] Native artifacts, branch selection, OPML omission, Lineage, Workbench, Exchange, publication, repair, conflicts, and Undo retained.
- [x] Private transfer and Workbench private backup fail closed.
- [x] Node transactional private-library ingress and read-only backup serving fail closed.
- [ ] Exact package in unmanaged then-current Chromium Stable.
- [ ] Exact generated sibling in Firefox Release.
- [ ] Exact generated sibling in Firefox ESR.
- [ ] Unfamiliar-person, separate privacy, and real assistive-technology fieldwork.
"""
    write("ROADCASE-SOURCE-NOTES-CHECKLIST.md", checklist)
    write("SOURCE-NOTES-CHECKLIST.md", checklist)

    bootstrap = f"""# BOOTSTRAPROSE — current `/run` authority

Revision: **{REV}**  
Date: **{DATE}**  
Product lineage: **rev0080 / 0.80.0**  
Release gate: **OPEN**

This authority supersedes earlier `/run` prose. It continues the sealed rev0104 unified tree and does not represent rev0081, rev0082, or the undelivered browser-execution-binding source archive as recovered.

- Immediate parent: `{PARENT}` · `{PARENT_SHA}`
- The whole-product Reader, CLI, loopback Node, Exchange, Capture/Witness/Pulse/Trace, Workbench, Lineage, publication, transfer, repair, conflict, concurrency, Undo, native-integrity, and runtime-record boundaries remain present.
- Managed tests and deterministic archives do not substitute for target-host browsers, unfamiliar people, privacy review, or real assistive technologies.

## P0.0 — completed in this candidate

- Reproduced that the sealed parent accepted, persisted, reopened, and re-exported a 281-code-point direct-placement reason through `NodeStore`; the read-only `node serve BACKUP` loader accepted it too.
- Added one shared Python placement audit in `CLI/source_notes_native.py` and delegated the offline transfer validator to it.
- Applied the audit before transactional Node create/open/read/snapshot/result/export boundaries and before read-only backup serving.
- Preserved valid two-folder reasons, multiline/Unicode text, explicit absence, and exact imported/exported bytes.
- Refused over-limit, wrong-level, folder-member, duplicate, empty, edge-whitespace, non-string, invalid-Unicode, and missing-source forms before SQLite creation or serving.
- Revalidated digest-consistent stored libraries on reopen/read so a recomputed outer digest cannot bless malformed placement data.
- Added no network request, persistent store, browser permission, account, schedule, notification, ranking, profile, reaction, comment, or messaging capability.
- Kept the fixed runtime catalog at 18 cases by extending `two-folder-independence`.

## P0.1 — exact package on the actual browser triad

Run fresh rev0105 session-v5 records from the sealed candidate in unmanaged then-current Chromium Stable, Firefox Release, and Firefox ESR. Capture fresh official channel evidence on each host. Do not relabel earlier sessions.

Run all 18 cases and every inherited whole-product boundary. In `two-folder-independence`, explicitly prove:

- One source has different reasons in two direct folders and a third placement has no reason.
- Valid native bytes pass `node init`, reopen/read, exact export, and read-only `node serve BACKUP` without text rewriting.
- Every malformed Source Note form is refused before a SQLite library or served backup is created.
- Refusal causes no network or permission request and leaves no partial library.

Retain every inherited Reader, Node branch/merge, Exchange, private-transfer, Capture, Witness, Pulse, Trace, Workbench collection/backup, Lineage, repair, conflict, stale-write, saturated-concurrency, whole-placement Undo, publication, OPML, integrity, restart, and permission-observation check. Preserve first failures, interruptions, retries, and recovery.

Firefox temporary loading remains development-runtime evidence and must not be interpreted as signed-install or restart acceptance.

## P0.2 — unfamiliar people, privacy, and real assistive technologies

Only after the exact browser triad passes:

- Ask unfamiliar people what a Node import or served private backup contains and which folder relationship each reason belongs to.
- Ask who wrote the reason, whether it is a safety claim, and whether import, serving, review, or Undo published anything, contacted anyone, or created a schedule.
- Compare sender, recipient, and diagnostic privacy evidence separately.
- Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions.
- Make only the smallest correction supported by recurring independent wrong turns.

## P1 — sharing and organization

- Test one-week delayed route re-finding before adding private labels or saved-view complexity.
- Keep folders human-curated and shareable; preserve **Unfiled** as legitimate.
- Keep Source Note wording out of engagement ranking and opaque recommendation systems.
- Do not expand Source Notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

- Keep remote mode explicit and separate from loopback.
- Require TLS, persistent Node identity, bounded hosts/requests/artifacts/rates, expiring invitations, and durable revocation evidence.
- Keep public publication routes separate from private APIs.
- No default public bind, silent LAN discovery, or UPnP.

## Lab — WebRTC courier

- Transfer exactly one reviewed immutable artifact; preserve Source Notes through it.
- Make signaling, STUN, and TURN visible; refuse replay, identity/digest mismatch, timeout, and partial completion.
- Destroy the bounded session afterward.
- Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## Stop conditions

- Do not add another evidence layer merely because target-host access is unavailable.
- Do not claim installed-browser, human, privacy, assistive-technology, or accessibility acceptance from managed automation.
- Make another product change only for a reproduced failure.
"""
    write("BOOTSTRAPROSE.md", bootstrap)

    summary = f"""# Result summary — rev0105 Node private-library Source Note integrity

The sealed rev0104 parent accepted malformed placement reasons through both NodeStore-backed private libraries and the read-only Node backup loader. rev0105 shares the Python direct-placement audit across offline transfer, Node storage, reopen/read, snapshots/results/export, and read-only serving. Valid two-folder reasons remain byte-exact; nine malformed forms refuse before SQLite creation or serving.

Focused native replay passed. Complete inherited regression is **{'PASS' if regression_pass else 'PENDING'}**. The fixed runtime catalog remains 18 cases. Exact target-host browser, unfamiliar-person, privacy, and assistive-technology acceptance remain open.
"""
    write("RESULT-SUMMARY.md", summary)
    write("CURRENT-STATUS.md", summary)
    write(
        "HANDOFF.md",
        f"""# Handoff — {REV}

## Current authority

`BOOTSTRAPROSE.md` is the `/run` authority. Immediate parent: `{PARENT}` (`{PARENT_SHA}`).

## Reproduced and corrected

The parent NodeStore and read-only Node loader accepted a 281-code-point direct-placement reason. rev0105 uses the shared Python audit before transactional storage/open/read/snapshot/result/export and before read-only serving. Valid route-specific reasons remain exact; nine malformed forms refuse before storage or serving.

## Next exact work

Seal the deterministic Roadcase, then run fresh rev0105 18-case and whole-product sessions on actual unmanaged then-current Chromium, Firefox Release, and Firefox ESR hosts. The `two-folder-independence` case must include valid and malformed Node private-library ingestion and read-only serving. After the triad passes, perform unfamiliar-person, separate privacy, and real assistive-technology fieldwork.

Do not add another evidence layer merely because target-host access is unavailable. Further product changes require a reproduced failure.
""",
    )

    state = {
        "schema": "progrss.revision-state.v1",
        "revision": REV,
        "date": DATE,
        "productLineage": {"revision": "rev0080", "version": "0.80.0"},
        "parent": {"name": PARENT, "sha256": PARENT_SHA, "bytes": PARENT_BYTES},
        "classification": "reproduced Node private-library Source Note validation bypass correction; exact target-host acceptance open",
        "releaseGateClosed": False,
        "nextP0": "Seal the deterministic candidate, then run fresh rev0105 18-case and whole-product sessions on actual unmanaged then-current Chromium, Firefox Release, and Firefox ESR hosts, including valid and malformed Node private-library ingestion and read-only serving; then separate human, privacy, and assistive-technology fieldwork.",
        "checks": {
            "behaviorCatalog": {"revision": REV, "cases": 18, "freshSessionPreparationRequired": True, "status": "pass"},
            "nodePrivateLibrary": {**focused["focusedTests"], "status": "focused-pass"},
            "offlineRegressions": {
                "cliModules": cli_modules,
                "cliTests": cli_tests,
                "extensionStaticTests": extension_static,
                "managedNodeHarnessInvocations": status.get("managedNodeHarnessInvocations", 0),
                "runtimeRecordAndComparisonTests": evidence_tests,
                "runtimeEvidenceRevisionBinding": REV,
                "status": "pass" if regression_pass else "pending",
            },
            "productContinuity": {**continuity["counts"], "permissionsExpanded": False, "status": "pass"},
            "deterministicBuild": {"status": "requires-detached-post-build-report"},
        },
        "claims": {
            "productChanged": True,
            "cliChanged": True,
            "extensionChanged": False,
            "permissionsExpanded": False,
            "newPersistentStore": False,
            "newNetworkAuthority": False,
            "installedBrowserRuntimeThisTurn": False,
            "unmanagedChromiumRuntime": False,
            "firefoxReleaseRuntime": False,
            "firefoxEsrRuntime": False,
            "humanPermissionPromptObservation": False,
            "unfamiliarParticipantFieldwork": False,
            "privacyComprehensionFieldwork": False,
            "assistiveTechnologyFieldwork": False,
            "accessibilityConformance": False,
            "policyModified": False,
            "rev0081OrRev0082Recovered": False,
            "browserRenderingThisTurn": False,
        },
    }
    dump("REVISION-STATE.json", state)
    write(
        "BUILD-REPORT.md",
        f"""# Pre-seal build status — rev0105

- Revision binding: PASS
- Focused Node private-library replay: PASS
- Product continuity against rev0104: PASS
- Complete regression: {'PASS' if regression_pass else 'PENDING'}
- Deterministic Roadcase seal: pending external build
- Exact target-host browser triad: NOT RUN
- Human, privacy, and real assistive-technology fieldwork: NOT RUN
""",
    )
    print(json.dumps({"revision": REV, "regressionPass": regression_pass, "cliModules": cli_modules, "cliTests": cli_tests, "extensionStaticTests": extension_static, "evidenceTests": evidence_tests}, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
