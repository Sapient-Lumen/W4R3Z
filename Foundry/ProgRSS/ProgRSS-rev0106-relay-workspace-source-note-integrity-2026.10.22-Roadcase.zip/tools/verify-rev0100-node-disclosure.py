#!/usr/bin/env python3
"""Focused rev0100 replay from a source tree or clean extraction."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0100-node-branch-source-note-disclosure"
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")


def run(label: str, command: list[str], timeout: int = 1800) -> str:
    result = subprocess.run(command, cwd=ROOT, env=ENV, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=timeout)
    print(f"\n== {label} ==\n{result.stdout.rstrip()}")
    if result.returncode:
        raise RuntimeError(f"{label} failed with exit {result.returncode}")
    return result.stdout


def main() -> int:
    assert (ROOT / "REVISION").read_text(encoding="utf-8").strip() == REVISION
    cases = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text(encoding="utf-8"))
    assert cases["revision"] == REVISION and len(cases["cases"]) == 18
    selected = next(row for row in cases["cases"] if row["id"] == "selected-branch-preservation")
    assert "shipped branch chooser" in selected["description"]
    app = (ROOT / "CLI/node_web/app.js").read_text(encoding="utf-8")
    css = (ROOT / "CLI/node_web/app.css").read_text(encoding="utf-8")
    for phrase in ("curator reason", "Curator’s reason for this folder:", "not a ProgRSS safety claim", "dir: 'auto'"):
        assert phrase in app, phrase
    for phrase in ("white-space:pre-wrap", "overflow-wrap:anywhere", "operation-placement-reason-text"):
        assert phrase in css, phrase
    run("Node branch API placement contract", [sys.executable, "-m", "unittest", "-v",
        "CLI.tests.test_node_server.NodeServerTests.test_node_owned_branch_operation_is_reviewed_atomic_idempotent_and_snapshot_backed"])
    run("shipped Node rendering smoke", [sys.executable, "CLI/tests/node_browser_smoke.py"])
    print("\nPASS rev0100 focused Node branch Source Note disclosure replay.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AssertionError, OSError, RuntimeError, subprocess.SubprocessError) as exc:
        print(f"rev0100 verification failed: {exc}", file=sys.stderr)
        raise SystemExit(1)
