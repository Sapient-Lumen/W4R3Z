#!/usr/bin/env python3
"""Focused rev0104 replay from a source tree or clean extraction."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0104-workbench-private-backup-integrity"
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")


def run(label: str, command: list[str], timeout: int = 1800, extra: dict[str, str] | None = None) -> str:
    result = subprocess.run(
        command, cwd=ROOT, env=dict(ENV, **(extra or {})), text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout,
    )
    print(f"\n== {label} ==\n{result.stdout.rstrip()}")
    if result.returncode:
        raise RuntimeError(f"{label} failed with exit {result.returncode}")
    return result.stdout


def main() -> int:
    assert (ROOT / "REVISION").read_text(encoding="utf-8").strip() == REVISION
    cases = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text(encoding="utf-8"))
    assert cases["revision"] == REVISION and len(cases["cases"]) == 18
    two_folder = next(row for row in cases["cases"] if row["id"] == "two-folder-independence")
    assert "Advanced Workbench Private backup" in two_folder["description"]
    assert "refused before download" in two_folder["description"]

    core = (ROOT / "Extension/shared/core.js").read_text(encoding="utf-8")
    background = (ROOT / "Extension/background.js").read_text(encoding="utf-8")
    app = (ROOT / "Extension/workbench/scripts/progrss-app.js").read_text(encoding="utf-8")
    assert core == (ROOT / "Extension/Firefox/shared/core.js").read_text(encoding="utf-8")
    assert background == (ROOT / "Extension/Firefox/background.js").read_text(encoding="utf-8")
    assert app == (ROOT / "Extension/Firefox/workbench/scripts/progrss-app.js").read_text(encoding="utf-8")
    for phrase in (
        "function auditSourceNotes(state,knownSourceIds=null)",
        "normalizeSourceNoteReason(member.reason)",
        "auditSourceNotes,",
    ):
        assert phrase in core, phrase
    assert "return C.auditSourceNotes(state, knownSourceIds);" in background
    for phrase in (
        "const sourceNoteAudit=C.auditSourceNotes(portableState);",
        "Private backup not created:",
        "curator-written folder reason",
    ):
        assert phrase in app, phrase
    html = (ROOT / "Extension/workbench/index.html").read_text(encoding="utf-8")
    assert 'id="toast" role="status" aria-live="polite"' in html

    audit = json.loads((ROOT / "SOURCE-NOTES-WORKBENCH-PRIVATE-BACKUP-INTEGRITY-AUDIT.json").read_text(encoding="utf-8"))
    assert audit["revision"] == REVISION and audit["status"] == "focused-pass"
    assert audit["focusedTests"]["browserPackageVariants"] == 2
    assert audit["focusedTests"]["checksPerVariant"] == 10
    assert audit["correction"]["downloadBeforeValidation"] is False
    assert audit["correction"]["network"] is False

    artifacts = ROOT / "evidence" / "rev0104" / "focused-replay"
    artifacts.mkdir(parents=True, exist_ok=True)
    run("Workbench private backup Chromium package", [
        sys.executable, "Extension/tests/source_notes_workbench_private_backup_harness.py",
        "--root", str(ROOT / "Extension"), "--artifacts", str(artifacts / "chromium"),
    ])
    run("Workbench private backup Firefox package", [
        sys.executable, "Extension/tests/source_notes_workbench_private_backup_harness.py",
        "--root", str(ROOT / "Extension/Firefox"), "--artifacts", str(artifacts / "firefox"),
    ])
    run("everyday private transfer Chromium", ["node", "Extension/tests/source_notes_private_transfer_harness.js"])
    run("everyday private transfer Firefox", ["node", "Extension/tests/source_notes_private_transfer_harness.js"], extra={"PROGRSS_EXTENSION_ROOT": "Firefox"})
    run("Workbench collection preservation Chromium", [
        sys.executable, "Extension/tests/source_notes_workbench_collection_harness.py",
        "--root", str(ROOT / "Extension"), "--artifacts", str(artifacts / "collection-chromium"),
    ])
    run("Workbench collection preservation Firefox", [
        sys.executable, "Extension/tests/source_notes_workbench_collection_harness.py",
        "--root", str(ROOT / "Extension/Firefox"), "--artifacts", str(artifacts / "collection-firefox"),
    ])
    run("CLI private-transfer contract", [sys.executable, "-m", "unittest", "-v", "CLI.tests.test_source_notes_private_transfer"])
    print("PASS rev0104 focused replay: shared Source Note audit, Workbench private backup, everyday transfer, and collection preservation.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
