#!/usr/bin/env python3
"""Focused rev0106 replay from a source tree or clean extraction."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0106-relay-workspace-source-note-integrity"
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")


def run(label: str, command: list[str], timeout: int = 1800) -> str:
    result = subprocess.run(
        command, cwd=ROOT, env=ENV, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout,
    )
    print(f"\n== {label} ==\n{result.stdout.rstrip()}")
    if result.returncode:
        raise RuntimeError(f"{label} failed with exit {result.returncode}")
    return result.stdout


def main() -> int:
    assert (ROOT / "REVISION").read_text(encoding="utf-8").strip() == REVISION
    cases = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text(encoding="utf-8"))
    assert cases["revision"] == REVISION and len(cases["cases"]) == 18
    two_folder = next(row for row in cases["cases"] if row["id"] == "two-folder-independence")
    assert "Relay workspace commands apply the same audit" in two_folder["description"]
    assert "explicit publication checks" in two_folder["description"]

    relay = (ROOT / "CLI/relay.py").read_text(encoding="utf-8")
    assert "validate_private_source_note_placements" in relay
    assert "That workspace has invalid Source Notes" in relay
    assert relay.count("read_workspace(args.backup)") == 6

    parent = json.loads((ROOT / "evidence/rev0106/parent-reproduction/result.json").read_text(encoding="utf-8"))
    assert parent["parentRevision"] == "rev0105-node-private-library-source-note-integrity"
    assert parent["defectReproduced"] is True
    assert parent["malformedReasonCodePoints"] == 281
    assert parent["returncode"] == 0 and parent["outputWritten"] is True

    fixed = json.loads((ROOT / "evidence/rev0106/fixed-replay/result.json").read_text(encoding="utf-8"))
    assert fixed["revision"] == REVISION
    assert fixed["returncode"] == 2 and fixed["refusedBeforeOutput"] is True

    audit = json.loads((ROOT / "SOURCE-NOTES-RELAY-WORKSPACE-INTEGRITY-AUDIT.json").read_text(encoding="utf-8"))
    assert audit["revision"] == REVISION and audit["status"] == "focused-pass"
    assert audit["focusedTests"]["malformedForms"] == 9
    assert audit["focusedTests"]["workspaceCommands"] == 6
    assert audit["correction"]["networkAuthorityAdded"] is False

    run("Relay workspace Source Notes", [
        sys.executable, "-m", "unittest", "-v", "CLI.tests.test_source_notes_relay_workspace",
    ])
    run("Relay regression", [sys.executable, "-m", "unittest", "-v", "CLI.tests.test_relay"])
    run("Private-transfer parity", [
        sys.executable, "-m", "unittest", "-v", "CLI.tests.test_source_notes_private_transfer",
    ])
    print("PASS rev0106 focused replay: shared Relay workspace loader, nine malformed forms, six command paths, valid route-specific reasons, and private-transfer parity.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
