#!/usr/bin/env python3
"""Offline, fail-closed browser-channel evidence for ProgRSS runtime sessions.

The tool consumes previously captured official JSON payloads. It does not fetch
from the network and does not authenticate the transport or operator. It binds
one exact payload set, its capture time, and the channel versions derived from
those payloads so a later runtime bundle cannot silently substitute an
operator-entered version string.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
from typing import Any, Mapping

CHANNEL_SNAPSHOT_SCHEMA = "progrss.browser-channel-evidence.v1"
CHANNEL_SNAPSHOT_NAME = "CHANNEL-SNAPSHOT.json"
CHANNEL_SOURCE_DIR = "channel-sources"
CHROME_SOURCE_NAME = f"{CHANNEL_SOURCE_DIR}/chrome-for-testing.json"
FIREFOX_SOURCE_NAME = f"{CHANNEL_SOURCE_DIR}/firefox-versions.json"
CHROME_SOURCE_URL = "https://googlechromelabs.github.io/chrome-for-testing/last-known-good-versions.json"
FIREFOX_SOURCE_URL = "https://product-details.mozilla.org/1.0/firefox_versions.json"
MAX_CHANNEL_SNAPSHOT_AGE_SECONDS = 24 * 60 * 60
UTC_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


class ChannelEvidenceError(ValueError):
    """Raised when channel evidence is missing, stale in structure, or inconsistent."""


def canonical_json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parse_utc(value: str, label: str = "UTC timestamp") -> datetime:
    if not isinstance(value, str) or not UTC_RE.fullmatch(value):
        raise ChannelEvidenceError(f"{label} must use YYYY-MM-DDTHH:MM:SSZ")
    try:
        return datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    except ValueError as error:
        raise ChannelEvidenceError(f"{label} is not a valid UTC calendar timestamp: {value}") from error


def _json_object(data: bytes, label: str) -> dict[str, Any]:
    try:
        value = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise ChannelEvidenceError(f"{label} is not valid UTF-8 JSON: {error}") from error
    if not isinstance(value, dict):
        raise ChannelEvidenceError(f"{label} must contain a JSON object")
    return value


def _source_row(path: str, url: str, data: bytes) -> dict[str, Any]:
    return {
        "path": path,
        "url": url,
        "bytes": len(data),
        "sha256": sha256_bytes(data),
    }


def build_snapshot(chrome_bytes: bytes, firefox_bytes: bytes, captured_utc: str) -> dict[str, Any]:
    parse_utc(captured_utc, "capturedUtc")
    chrome = _json_object(chrome_bytes, "Chrome for Testing source")
    firefox = _json_object(firefox_bytes, "Firefox versions source")

    timestamp = chrome.get("timestamp")
    channels = chrome.get("channels")
    stable = channels.get("Stable") if isinstance(channels, Mapping) else None
    if not isinstance(timestamp, str) or not isinstance(stable, Mapping):
        raise ChannelEvidenceError("Chrome source is missing timestamp or channels.Stable")
    stable_version = stable.get("version")
    stable_revision = stable.get("revision")
    if stable.get("channel") != "Stable" or not isinstance(stable_version, str) or not stable_version:
        raise ChannelEvidenceError("Chrome source has an invalid Stable channel record")
    if not isinstance(stable_revision, str) or not stable_revision:
        raise ChannelEvidenceError("Chrome source has no Stable revision")

    release = firefox.get("LATEST_FIREFOX_VERSION")
    esr = firefox.get("FIREFOX_ESR")
    last_release = firefox.get("LAST_RELEASE_DATE")
    if not all(isinstance(value, str) and value for value in (release, esr, last_release)):
        raise ChannelEvidenceError("Firefox source is missing release, ESR, or last-release values")

    sources = {
        "chromeForTesting": _source_row(CHROME_SOURCE_NAME, CHROME_SOURCE_URL, chrome_bytes),
        "firefoxVersions": _source_row(FIREFOX_SOURCE_NAME, FIREFOX_SOURCE_URL, firefox_bytes),
    }
    return {
        "schema": CHANNEL_SNAPSHOT_SCHEMA,
        "capturedUtc": captured_utc,
        "maxAgeSeconds": MAX_CHANNEL_SNAPSHOT_AGE_SECONDS,
        "sources": sources,
        "channels": {
            "chromium": {
                "stable": {
                    "version": stable_version,
                    "revision": stable_revision,
                    "source": "chromeForTesting",
                    "sourceTimestampUtc": timestamp,
                }
            },
            "firefox": {
                "release": {
                    "version": release,
                    "source": "firefoxVersions",
                    "sourceLastReleaseDate": last_release,
                },
                "esr": {
                    "version": esr,
                    "source": "firefoxVersions",
                    "sourceLastReleaseDate": last_release,
                },
            },
        },
        "claimBoundary": {
            "authenticatedNetworkFetch": False,
            "sourceSignatureVerified": False,
            "operatorSuppliedCapture": True,
        },
    }


def validate_snapshot_payloads(snapshot_bytes: bytes, payloads: Mapping[str, bytes]) -> dict[str, Any]:
    snapshot = _json_object(snapshot_bytes, CHANNEL_SNAPSHOT_NAME)
    if set(payloads) != {CHROME_SOURCE_NAME, FIREFOX_SOURCE_NAME}:
        raise ChannelEvidenceError("channel-source inventory must contain exactly the Chrome and Firefox source payloads")
    captured = snapshot.get("capturedUtc")
    if not isinstance(captured, str):
        raise ChannelEvidenceError("channel snapshot capturedUtc is missing")
    expected = build_snapshot(payloads[CHROME_SOURCE_NAME], payloads[FIREFOX_SOURCE_NAME], captured)
    if snapshot != expected:
        raise ChannelEvidenceError("CHANNEL-SNAPSHOT.json does not match its official-source payload bytes")
    return snapshot


def expected_version(snapshot: Mapping[str, Any], family: str, channel: str) -> str:
    mapping = {
        ("chromium", "stable"): ("chromium", "stable"),
        ("firefox", "release"): ("firefox", "release"),
        ("firefox", "esr"): ("firefox", "esr"),
    }
    key = mapping.get((family, channel))
    if key is None:
        raise ChannelEvidenceError(f"unsupported browser/channel pair: {family}/{channel}")
    try:
        version = snapshot["channels"][key[0]][key[1]]["version"]
    except (KeyError, TypeError) as error:
        raise ChannelEvidenceError(f"channel snapshot has no {family}/{channel} version") from error
    if not isinstance(version, str) or not version:
        raise ChannelEvidenceError(f"channel snapshot has an invalid {family}/{channel} version")
    return version


def load_channel_evidence_dir(directory: Path) -> tuple[dict[str, Any], dict[str, bytes]]:
    directory = directory.resolve()
    if not directory.is_dir() or directory.is_symlink():
        raise ChannelEvidenceError(f"channel evidence directory is missing or unsafe: {directory}")
    expected_paths = {CHANNEL_SNAPSHOT_NAME, CHROME_SOURCE_NAME, FIREFOX_SOURCE_NAME}
    actual_paths: set[str] = set()
    for path in sorted(directory.rglob("*"), key=lambda value: value.relative_to(directory).as_posix()):
        if path.is_symlink():
            raise ChannelEvidenceError(f"channel evidence contains a symlink: {path.relative_to(directory).as_posix()}")
        if path.is_file():
            actual_paths.add(path.relative_to(directory).as_posix())
    if actual_paths != expected_paths:
        raise ChannelEvidenceError(
            f"channel evidence inventory mismatch; missing={sorted(expected_paths-actual_paths)}; extra={sorted(actual_paths-expected_paths)}"
        )
    snapshot_bytes = (directory / CHANNEL_SNAPSHOT_NAME).read_bytes()
    payloads = {
        CHROME_SOURCE_NAME: (directory / CHROME_SOURCE_NAME).read_bytes(),
        FIREFOX_SOURCE_NAME: (directory / FIREFOX_SOURCE_NAME).read_bytes(),
    }
    snapshot = validate_snapshot_payloads(snapshot_bytes, payloads)
    return snapshot, {CHANNEL_SNAPSHOT_NAME: snapshot_bytes, **payloads}


def session_record(snapshot: Mapping[str, Any], payloads: Mapping[str, bytes]) -> dict[str, Any]:
    snapshot_bytes = payloads[CHANNEL_SNAPSHOT_NAME]
    sources = snapshot.get("sources")
    if not isinstance(sources, Mapping):
        raise ChannelEvidenceError("channel snapshot sources are missing")
    return {
        "schema": CHANNEL_SNAPSHOT_SCHEMA,
        "snapshotPath": CHANNEL_SNAPSHOT_NAME,
        "snapshotBytes": len(snapshot_bytes),
        "snapshotSha256": sha256_bytes(snapshot_bytes),
        "capturedUtc": snapshot["capturedUtc"],
        "maxAgeSeconds": snapshot["maxAgeSeconds"],
        "sources": [dict(sources[name]) for name in sorted(sources)],
    }


def copy_channel_evidence(payloads: Mapping[str, bytes], destination: Path) -> None:
    for relative, data in payloads.items():
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--chrome-json", type=Path, required=True)
    parser.add_argument("--firefox-json", type=Path, required=True)
    parser.add_argument("--captured-utc", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists():
        if output.is_symlink() or not output.is_dir():
            parser.error(f"output path is not a real directory: {output}")
        if any(output.iterdir()):
            parser.error(f"output directory is not empty: {output}")
    output.mkdir(parents=True, exist_ok=True)
    try:
        chrome = args.chrome_json.read_bytes()
        firefox = args.firefox_json.read_bytes()
        snapshot = build_snapshot(chrome, firefox, args.captured_utc)
        payloads = {
            CHANNEL_SNAPSHOT_NAME: canonical_json_bytes(snapshot),
            CHROME_SOURCE_NAME: chrome,
            FIREFOX_SOURCE_NAME: firefox,
        }
        copy_channel_evidence(payloads, output)
        validated, validated_payloads = load_channel_evidence_dir(output)
    except (OSError, ChannelEvidenceError) as error:
        parser.error(str(error))
    print(json.dumps({
        "schema": validated["schema"],
        "capturedUtc": validated["capturedUtc"],
        "snapshotSha256": sha256_bytes(validated_payloads[CHANNEL_SNAPSHOT_NAME]),
        "chromiumStable": expected_version(validated, "chromium", "stable"),
        "firefoxRelease": expected_version(validated, "firefox", "release"),
        "firefoxEsr": expected_version(validated, "firefox", "esr"),
        "output": str(output),
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
