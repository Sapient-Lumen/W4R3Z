#!/usr/bin/env python3
"""Audit rev0094 stale destructive folder removal and rev0095 review-bound refusal."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0095-source-notes-reviewed-removal"
PARENT = "ProgRSS-rev0094-source-notes-saturated-add-undo-2026.10.21-Roadcase.zip"
PARENT_SHA = "175317ab2003577ac91c90f6befe7f34aad58b85f8cefd3567f95b123a350782"
EVIDENCE = ROOT / "evidence" / "rev0095"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parent_log = (EVIDENCE / "parent-stale-folder-remove-reproduction.log").read_text(encoding="utf-8", errors="replace")
    chromium_log = (EVIDENCE / "reviewed-removal-chromium.log").read_text(encoding="utf-8", errors="replace")
    firefox_log = (EVIDENCE / "reviewed-removal-firefox.log").read_text(encoding="utf-8", errors="replace")
    background = (ROOT / "Extension" / "background.js").read_text(encoding="utf-8")
    sidepanel = (ROOT / "Extension" / "sidepanel" / "app.js").read_text(encoding="utf-8")
    tests = (ROOT / "Extension" / "tests" / "source_notes_folder_remove_harness.js").read_text(encoding="utf-8")

    parent_below = "REPRODUCED stale visible reason removal deletes newer wording below ceiling" in parent_log
    parent_saturated = "REPRODUCED stale saturated removal deletes replacement placement" in parent_log
    required = [
        "exact reviewed removal preserves complete relationship and position",
        "missing reviewed version or reason is refused",
        "newer reason below the ceiling is preserved from a stale remove",
        "saturated exact review succeeds only with exact persisted revision",
        "saturated stale review cannot delete a removed-and-restored replacement",
        "below-ceiling unrelated vault write does not invalidate reviewed removal",
        "saturated unrelated vault write conservatively invalidates reviewed removal",
        "ambiguous duplicate placement is refused without mutation",
        "side panel forwards the displayed version revision and reason",
        "the reviewed-removal corpus makes no network requests",
    ]
    chromium_pass = all(f"PASS {name}" in chromium_log for name in required) and '"cases":14,"passed":14,"failed":0' in chromium_log
    firefox_pass = all(f"PASS {name}" in firefox_log for name in required) and '"cases":14,"passed":14,"failed":0' in firefox_log
    code_checks = {
        "reviewVersionRequired": "INVALID_FOLDER_REMOVE_REVIEW" in background and "payload.expectedVersion" in background,
        "reviewReasonRequired": "hasOwnProperty.call(payload, 'expectedReason')" in background,
        "ceilingRevisionRequired": "currentVersion === 10000" in background and "payload.expectedRevision !== state._revision" in background,
        "singleDirectPlacementRequired": "placement = directSourcePlacement(folder, sourceId);" in background,
        "reasonDriftRefused": "currentReason !== expectedReason" in background and "STALE_FOLDER_REMOVE" in background,
        "singlePlacementRemoved": "folder.collection.members.splice(removedIndex, 1);" in background,
        "completeMemberReturned": "removedMember," in background and "removedIndex," in background,
        "sidePanelSendsVersion": "expectedVersion: Math.max(1, Math.round(Number(folder.collection.version) || 1))" in sidepanel,
        "sidePanelSendsRevision": "expectedRevision: Number.isSafeInteger(app.state?.revision) ? app.state.revision : 0" in sidepanel,
        "sidePanelSendsReason": "expectedReason: Object.prototype.hasOwnProperty.call(member, 'reason')" in sidepanel,
        "explicitNoNetworkCase": "the reviewed-removal corpus makes no network requests" in tests,
        "browserSiblingBackgroundParity": (ROOT / "Extension" / "background.js").read_bytes() == (ROOT / "Extension" / "Firefox" / "background.js").read_bytes(),
        "browserSiblingSidePanelParity": (ROOT / "Extension" / "sidepanel" / "app.js").read_bytes() == (ROOT / "Extension" / "Firefox" / "sidepanel" / "app.js").read_bytes(),
    }
    passed = parent_below and parent_saturated and chromium_pass and firefox_pass and all(code_checks.values())
    reproduction = {
        "schema": "progrss.source-notes.reviewed-folder-removal-reproduction.v1",
        "revision": REVISION,
        "parentArchive": PARENT,
        "parentArchiveSha256": PARENT_SHA,
        "folderVersionCeiling": 10000,
        "parentAcceptedStaleBelowCeilingRemoval": parent_below,
        "parentDeletedNewerReason": parent_below,
        "parentAcceptedStaleSaturatedRemoval": parent_saturated,
        "parentDeletedReplacementPlacement": parent_saturated,
        "candidateRequiresReviewedVersionAndReason": chromium_pass and firefox_pass,
        "candidateRequiresExactRevisionAtVersionCeiling": chromium_pass and firefox_pass,
        "candidateRefusesWithoutMutation": chromium_pass and firefox_pass,
        "candidatePreservesNewerOrReplacementPlacement": chromium_pass and firefox_pass,
        "belowCeilingUnrelatedWritesRemainNonblocking": chromium_pass and firefox_pass,
        "variants": ["Chromium-source", "generated-Firefox"],
        "installedBrowserRuntime": False,
        "networkActivity": False,
        "pass": passed,
    }
    (EVIDENCE / "stale-folder-remove-reproduction.json").write_text(
        json.dumps(reproduction, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8"
    )
    audit = {
        "schema": "progrss.source-notes.reviewed-folder-removal-audit.v1",
        "revision": REVISION,
        "parent": {
            "archive": PARENT,
            "sha256": PARENT_SHA,
            "acceptedStaleBelowCeilingRemoval": parent_below,
            "acceptedStaleSaturatedRemoval": parent_saturated,
        },
        "candidate": {
            "chromiumCases": 14,
            "firefoxCases": 14,
            "chromiumPass": chromium_pass,
            "firefoxPass": firefox_pass,
            "backgroundSha256": sha(ROOT / "Extension" / "background.js"),
            "sidePanelSha256": sha(ROOT / "Extension" / "sidepanel" / "app.js"),
        },
        "checks": code_checks,
        "claims": {
            "releaseGateClosed": False,
            "installedBrowserRuntime": False,
            "unmanagedCurrentBrowser": False,
            "participantOrAssistiveTechnologyEvidence": False,
        },
        "pass": passed,
    }
    (ROOT / "SOURCE-NOTES-REVIEWED-REMOVAL-AUDIT.json").write_text(
        json.dumps(audit, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8"
    )
    lines = [
        "# Source Notes reviewed folder-removal audit — rev0095", "",
        f"- Parent accepted stale removal after newer wording below the ceiling: **{'YES' if parent_below else 'NO'}**",
        f"- Parent accepted stale removal of a replacement placement at the ceiling: **{'YES' if parent_saturated else 'NO'}**",
        f"- Chromium-source focused corpus: **{'PASS' if chromium_pass else 'FAIL'}** (14 cases)",
        f"- Generated-Firefox focused corpus: **{'PASS' if firefox_pass else 'FAIL'}** (14 cases)",
        f"- Review binding, exact ceiling revision, one-placement removal, and parity checks: **{'PASS' if all(code_checks.values()) else 'FAIL'}**", "",
        "The parent reproduction and candidate checks use production background handlers and side-panel functions with browser API doubles. They are not installed-browser, participant, accessibility, or assistive-technology acceptance.", "",
        "Removal now requires the displayed folder version and explicit displayed reason. At folder version `10000`, it also requires the exact persisted vault revision. Below the ceiling, an unrelated write to another folder remains nonblocking when the reviewed placement itself is unchanged.",
    ]
    (ROOT / "SOURCE-NOTES-REVIEWED-REMOVAL-AUDIT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"pass": passed, "parentBelow": parent_below, "parentSaturated": parent_saturated, "chromium": chromium_pass, "firefox": firefox_pass}, sort_keys=True))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
