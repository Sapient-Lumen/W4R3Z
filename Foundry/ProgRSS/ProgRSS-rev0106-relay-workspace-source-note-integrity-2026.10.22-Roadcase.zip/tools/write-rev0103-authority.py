#!/usr/bin/env python3
"""Write rev0103 current authority, audits, matrices, and handoff."""
from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REV = "rev0103-shared-folder-merge-source-note-disclosure"
PARENT = "ProgRSS-rev0102-node-merge-source-note-disclosure-2026.10.22-Roadcase.zip"
PARENT_SHA = "e4fa5d3560a37695fa1cee27c5245134edaeb72eaf417321df6d6ec249dfdabd"
PARENT_BYTES = 16068384


def write(name: str, text: str) -> None:
    (ROOT / name).write_text(text.rstrip() + "\n", encoding="utf-8")


def dump(name: str, obj: object) -> None:
    (ROOT / name).write_text(json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")


status_path = ROOT / "evidence/rev0103/regression-status.json"
status = json.loads(status_path.read_text(encoding="utf-8")) if status_path.exists() else {"complete": False, "allPassed": False, "rows": []}
rows_by_label = {str(row.get("label")): row for row in status.get("rows", [])}
cli_tests = sum(int(row.get("tests") or 0) for row in status.get("rows", []) if str(row.get("label", "")).startswith("cli-"))
extension_static = int(rows_by_label.get("extension-static", {}).get("tests") or 0)
evidence_tests = int(rows_by_label.get("evidence-boundary", {}).get("tests") or 0)
regression_pass = bool(status.get("complete") and status.get("allPassed"))

focused_audit = {
    "schema": "progrss.source-notes.shared-folder-merge-disclosure-audit.v1",
    "revision": REV,
    "parent": {"name": PARENT, "sha256": PARENT_SHA, "bytes": PARENT_BYTES},
    "status": "focused-pass",
    "reproduction": {
        "nativeFolderPathMissingBeforeFix": True,
        "sameSourceSameTitleConflictsIndistinguishable": True,
        "multilineContextCollapsedBeforeFix": True,
        "automaticDirectionMissingBeforeFix": True,
        "curatorBoundaryMissingBeforeFix": True,
        "evidence": [
            "evidence/rev0103/before-background-harness.log",
            "evidence/rev0103/before-ui-harness.log",
            "evidence/rev0103/parent-background.js",
            "evidence/rev0103/parent-sidepanel-app.js",
            "evidence/rev0103/parent-sidepanel-app.css",
        ],
    },
    "correction": {
        "canonicalFolderPath": True,
        "sameTitleRoutesDistinguished": True,
        "literalText": True,
        "multilinePreserved": True,
        "automaticDirection": True,
        "curatorAttribution": True,
        "nonSafetyBoundary": True,
        "keepMineLabel": True,
        "useCuratorLabel": True,
        "independentPlacementChoices": True,
        "mergeSemanticsChanged": False,
        "writesChanged": False,
        "network": False,
    },
    "focusedTests": {
        "nativeBackground": "pass",
        "chromiumPackageUi": {"status": "pass", "checks": 4},
        "firefoxPackageUi": {"status": "pass", "checks": 4},
        "sourceNoteConflicts": 2,
    },
    "completeRegression": {
        "status": "pass" if regression_pass else "pending",
        "cliTests": cli_tests,
        "extensionStaticTests": extension_static,
        "runtimeRecordAndComparisonTests": evidence_tests,
        "managedNodeHarnessInvocations": status.get("managedNodeHarnessInvocations"),
        "managedWorkbenchUiPathVariants": status.get("managedWorkbenchUiPathVariants"),
        "managedSharedFolderMergeUiPathVariants": status.get("managedSharedFolderMergeUiPathVariants"),
    },
    "permissionsExpanded": False,
    "newPersistentStore": False,
    "newNetworkAuthority": False,
}
dump("SHARED-FOLDER-MERGE-SOURCE-NOTE-DISCLOSURE-AUDIT.json", focused_audit)
write("SHARED-FOLDER-MERGE-SOURCE-NOTE-DISCLOSURE-AUDIT.md", f'''# Shared-folder merge Source Note disclosure audit — rev0103

Parent: `{PARENT}`  
SHA-256: `{PARENT_SHA}`

## Reproduced defect

The native shared-folder update preview exposed a placement-scoped Source Note conflict without its canonical folder path. The shipped Extension side panel then rendered the conflict as a generic source card. Two conflicts for the same source in identically titled folders could not be distinguished by route, multiline values lost their review context, user-authored text lacked content-derived direction, and the curator/non-safety boundary was absent.

Retained evidence:

- `evidence/rev0103/before-background-harness.log`
- `evidence/rev0103/before-ui-harness.log`
- Parent product bytes under `evidence/rev0103/parent-*`

## Correction

- Native merge rows and placement descriptors now carry the canonical incoming folder path.
- The shipped side panel shows the full route for every Source Note conflict and reviewed change.
- Last accepted, local, and curator values render literally with preserved line breaks, wrapping, and `dir="auto"`.
- The review identifies curator authorship, states that the wording is not a ProgRSS safety claim, and keeps each placement’s **Keep mine / Use curator’s** decision independent.
- Merge classification, decision validation, commit behavior, permissions, persistence, and network authority are unchanged.

## Focused result

- Native background path: **PASS**
- Chromium-source shipped UI path: **4/4 checks passed**
- Generated-Firefox shipped UI path: **4/4 checks passed**
- Complete inherited regression: **{'PASS' if regression_pass else 'PENDING'}**

This is managed native/UI regression evidence. It is not installed-browser, participant, privacy-comprehension, assistive-technology, or accessibility-conformance evidence.
''')

integration = {
    "schema": "progrss.integration-audit.v1",
    "revision": REV,
    "status": "pass",
    "parent": {"name": PARENT, "sha256": PARENT_SHA, "bytes": PARENT_BYTES},
    "currentCorrection": "Extension shared-folder three-way placement-route and exact Source Note disclosure",
    "inherited": {
        "rev0100NodeBranchDisclosure": True,
        "rev0101UnifiedExchangePrivateTransfer": True,
        "rev0102NodeMergeDisclosure": True,
    },
    "missingArtifacts": ["rev0081", "rev0082", "rev0090-source-notes-browser-execution-binding"],
    "releaseGateClosed": False,
}
dump("INTEGRATION-AUDIT.json", integration)
write("INTEGRATION-AUDIT.md", f'''# Integration audit — rev0103

Immediate parent: `{PARENT}`  
SHA-256: `{PARENT_SHA}`

This candidate continues the sealed rev0102 unified tree. It retains the delivered private-transfer integration, Exchange sender/recipient disclosure, Node branch disclosure, Node merge disclosure, publication, Lineage, Workbench, repair, concurrency, whole-placement Undo, native-integrity, and runtime-record corrections.

The only current product correction is the Extension shared-folder three-way Source Note review: canonical folder routes and exact placement values are now visible before the existing explicit conflict decisions are applied.

Rev0081, rev0082, and the undelivered browser-execution-binding source archive remain unavailable and are not represented as recovered. The release gate remains open.
''')

runtime_audit = {
    "schema": "progrss.source-notes.runtime-evidence-audit.v1",
    "revision": REV,
    "status": "pass" if regression_pass else "pending",
    "cases": 18,
    "changedCaseIds": ["divergent-later-copy-keep-mine", "divergent-later-copy-use-curator"],
    "sessionSchema": "v5",
    "resultSchema": "v3",
    "freshPreparationRequired": True,
    "runtimeRecordAndComparisonTests": evidence_tests,
    "standaloneStatementsAccepted": False,
    "unknownClaimFieldsAccepted": False,
    "targetBrowserAcceptance": False,
}
dump("SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.json", runtime_audit)
write("SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.md", f'''# Runtime-evidence binding audit — rev0103

- Fixed catalog: **18 cases**
- Changed case descriptions: `divergent-later-copy-keep-mine`, `divergent-later-copy-use-curator`
- Session schema: v5
- Result/predicate schema: v3
- Fresh rev0103 preparation required: **yes**
- Runtime-record and verified-comparison tests: **{evidence_tests}**
- Installed current-browser acceptance established: **no**

The existing divergent-copy cases now include the Extension shared-folder update review. No nineteenth behavioral case was created. Earlier records retain their original revision and must not be relabeled.
''')

matrix = json.loads((ROOT / "SOURCE-NOTES-ENTRYPOINT-MATRIX.json").read_text(encoding="utf-8"))
matrix["revision"] = REV
matrix["classification"] = "all shipped implementation rows pass in native/managed scope, including full-route Extension shared-folder merge review; exact browser and fieldwork gates remain open"
matrix["rows"] = [row for row in matrix["rows"] if row.get("id") != "extension-shared-folder-merge-review"]
new_row = {
    "id": "extension-shared-folder-merge-review",
    "surface": "Extension shared-folder update review",
    "behavior": "Expose every placement-scoped Source Note divergence with its full canonical folder route, literal multiline and bidirectional values, curator attribution, non-safety wording, and an independent explicit decision.",
    "command": "node Extension/tests/background_harness.js && python3 Extension/tests/source_notes_shared_folder_merge_review_harness.py --extension Extension && python3 Extension/tests/source_notes_shared_folder_merge_review_harness.py --extension Extension/Firefox",
    "paths": [
        "Extension/background.js", "Extension/sidepanel/app.js", "Extension/sidepanel/app.css",
        "Extension/Firefox/background.js", "Extension/Firefox/sidepanel/app.js", "Extension/Firefox/sidepanel/app.css",
        "Extension/tests/background_harness.js", "Extension/tests/source_notes_shared_folder_merge_review_harness.py",
    ],
    "evidence": [
        "evidence/rev0103/before-background-harness.log",
        "evidence/rev0103/before-ui-harness.log",
        "evidence/rev0103/regressions/background_harness.log",
        "evidence/rev0103/regressions/shared-folder-merge-review-chromium.log",
        "evidence/rev0103/regressions/shared-folder-merge-review-firefox.log",
    ],
    "evidenceType": "native-background plus managed shipped-side-panel replay",
    "limitation": "Managed native/UI scope only; not installed-browser or participant acceptance.",
    "status": "pass",
}
# Place it after the general recipient disclosure row.
insert_at = next((i + 1 for i, row in enumerate(matrix["rows"]) if row.get("id") == "extension-recipient-disclosure"), len(matrix["rows"]))
matrix["rows"].insert(insert_at, new_row)
dump("SOURCE-NOTES-ENTRYPOINT-MATRIX.json", matrix)
counts = Counter(str(row.get("status")) for row in matrix["rows"])
lines = [
    "# Source Notes shipped-entrypoint matrix — rev0103", "",
    f"**Status:** {counts.get('pass', 0)} PASS · {counts.get('inherited', 0)} INHERITED · {counts.get('not-run', 0)} NOT RUN", "",
    "| Surface | Behavior | Status | Limitation |", "|---|---|---:|---|",
]
for row in matrix["rows"]:
    lines.append(f"| {row.get('surface','')} | {row.get('behavior','').replace('|','/')} | **{str(row.get('status','')).upper()}** | {row.get('limitation','').replace('|','/')} |")
write("SOURCE-NOTES-ENTRYPOINT-MATRIX.md", "\n".join(lines))

runtime_rows = [
    {"id": "unified-rev0102-parent", "scope": "sealed rev0102 whole-product tree retained", "status": "pass"},
    {"id": "extension-shared-folder-native-route", "scope": "canonical folder path in placement-scoped Source Note merge rows", "status": "focused-pass"},
    {"id": "extension-shared-folder-shipped-review", "scope": "managed Chromium-source and generated-Firefox side-panel review with exact values, route, direction, and boundaries", "status": "focused-pass"},
    {"id": "runtime-catalog-binding", "scope": "18 cases; session v5/result v3; fresh rev0103 preparation required", "status": "pass"},
    {"id": "complete-offline-regression", "scope": f"{cli_tests} CLI tests, {extension_static} Extension static tests, {status.get('managedNodeHarnessInvocations',0)} managed Node/product harness invocations, {status.get('managedWorkbenchUiPathVariants',0)} Workbench/Lineage variants, {status.get('managedSharedFolderMergeUiPathVariants',0)} shared-folder merge UI variants, complete Extension runner, {evidence_tests} evidence tests", "status": "pass" if regression_pass else "pending"},
    {"id": "deterministic-seal", "status": "external-postbuild-report-required"},
    {"id": "unmanaged-current-chromium", "status": "not-run"},
    {"id": "firefox-release", "status": "not-run"},
    {"id": "firefox-esr", "status": "not-run"},
    {"id": "unfamiliar-curators-and-recipients", "status": "not-run"},
    {"id": "separate-sender-recipient-diagnostic-privacy", "status": "not-run"},
    {"id": "real-assistive-technologies", "status": "not-run"},
]
runtime_matrix = {"revision": REV, "releaseGateClosed": False, "inheritedEvidence": "Earlier records retain their original identities and scopes; exact rev0103 product bytes require fresh target-host sessions.", "rows": runtime_rows}
dump("SOURCE-NOTES-RUNTIME-MATRIX.json", runtime_matrix)
write("SOURCE-NOTES-RUNTIME-MATRIX.md", "# Source Notes runtime and release matrix — rev0103\n\n" + "\n".join(f"- **{row['id']}** — {row['status']}" + (f": {row['scope']}" if row.get('scope') else "") for row in runtime_rows))
# Keep legacy filenames aligned with the same current matrix.
dump("RUNTIME-MATRIX.json", runtime_matrix)
write("RUNTIME-MATRIX.md", (ROOT / "SOURCE-NOTES-RUNTIME-MATRIX.md").read_text(encoding="utf-8"))

write("ROADCASE-SOURCE-NOTES-CHECKLIST.md", '''# Roadcase Source Notes checklist — rev0103

## Native contract

- [x] One optional reason per direct folder/source placement.
- [x] Plain text, valid Unicode scalar values, maximum 280 code points.
- [x] Canonical omission of empty values and rejection of invalid or conflicting duplicate placements.
- [x] Native canonicalization, integrity, complete-route, selected-branch, OPML-omission, private-transfer, publication, Lineage, Workbench, repair, and Exchange coverage.

## Three-way reviews

- [x] No automatic winner for genuine divergence.
- [x] Placement-scoped **Keep mine / Use curator’s** decisions.
- [x] Node review shows full routes and exact values.
- [x] Extension shared-folder update review shows full canonical routes, literal multiline/directional values, curator attribution, and the non-safety boundary.

## Release gates

- [ ] Unmanaged then-current Chromium Stable on the exact sealed candidate.
- [ ] Firefox Release on the exact sealed generated sibling.
- [ ] Firefox ESR on the exact sealed generated sibling.
- [ ] Unfamiliar curator and recipient sessions.
- [ ] Separate sender, recipient, and diagnostic privacy review.
- [ ] Real screen-reader, Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions.
''')

write("BOOTSTRAPROSE.md", f'''# BOOTSTRAPROSE — current `/run` authority

**Candidate:** `{REV}` · **Date:** 2026-10-22 · **Product lineage:** rev0080 / 0.80.0.

## Authority and lineage

This tree continues the sealed rev0102 unified candidate and corrects one reproduced Extension recipient-review defect. It does not represent rev0081, rev0082, or the undelivered browser-execution-binding source archive as recovered.

- Immediate parent: `{PARENT}` · `{PARENT_SHA}`
- The parent’s unified private-transfer, Exchange, Node branch, Node merge, publication, Lineage, Workbench, repair, concurrency, Undo, native-integrity, and runtime-record corrections remain present.
- The release gate remains open. Managed tests and deterministic archives do not substitute for actual target-host browsers, unfamiliar people, privacy review, or real assistive technologies.

## P0.0 — completed in this candidate

- Reproduce the native omission: a shared-folder Source Note conflict lacked its canonical folder path.
- Reproduce the shipped side-panel omission: two conflicts for the same source in identically titled folders were indistinguishable by route.
- Add the canonical folder path to every Source Note merge row and placement descriptor.
- Display full routes, exact last-accepted/local/curator values, preserved line breaks, wrapping, and content-derived direction.
- Show curator attribution and state that the reason is not a ProgRSS safety claim.
- Keep every placement decision independent and preserve the existing no-automatic-winner merge semantics.
- Keep Chromium-source and generated-Firefox product bytes aligned.
- Add no permission, persistent store, network authority, account, schedule, notification, ranking, profile, reaction, comment, or messaging capability.
- Keep the fixed runtime catalog at exactly 18 cases by extending the existing divergent-copy cases.

## P0.1 — exact package on the actual browser triad

Run fresh rev0103 session-v5 records from the sealed candidate in:

1. Unmanaged then-current Chromium Stable.
2. Firefox Release.
3. Firefox ESR.

Capture fresh official channel evidence on each host. Do not relabel rev0102 or earlier sessions.

Run all 18 cases and every inherited whole-product boundary. In the divergent-copy work, explicitly prove:

- Create two Source Note conflicts for the same source in two different folders sharing the same visible title.
- The Extension shared-folder update review shows the full canonical route for both placements.
- Last accepted, **Keep mine**, and **Use curator’s** values remain exact, literal, multiline, and placement-scoped.
- Bidirectional and markup-like text renders as text, wraps at narrow widths, and receives content-derived direction.
- Curator attribution and the non-safety boundary are visible.
- Each placement keeps an independent decision and approval remains unavailable until every conflict is resolved.
- Closing, replacing, or staling the review does not retain or apply an uncommitted choice.
- Preview and review remain local and contact no listed source.

Retain every inherited Reader, Node, Exchange, private-transfer, Capture, Witness, Pulse, Trace, Workbench, Lineage, repair, conflict, stale-write, saturated-concurrency, whole-placement Undo, publication, OPML, integrity, restart, and permission-observation check. Preserve first failures, interruptions, retries, and recovery—not only the eventual result.

Firefox temporary loading remains development-runtime evidence and must not be interpreted as signed-install or restart acceptance.

## P0.2 — unfamiliar people, privacy, and real assistive technologies

Only after the exact browser triad passes:

- Ask unfamiliar recipients which direct folder relationship each conflicting reason belongs to.
- Ask what **Keep mine** and **Use curator’s** would do and whether either choice has already been applied.
- Ask who wrote the reason and whether it is a safety claim.
- Compare sender, recipient, and diagnostic privacy evidence separately.
- Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions.
- Make only the smallest correction supported by recurring independent wrong turns.

## P1 — sharing and organization

- Test one-week delayed route re-finding before adding private labels or saved-view complexity.
- Keep folders human-curated and shareable; preserve **Unfiled** as legitimate.
- Keep Source Note wording out of engagement ranking and opaque recommendation systems.
- Do not expand Source Notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

- Keep remote mode explicit and separate from loopback.
- Require TLS, persistent Node identity, bounded hosts/requests/artifacts/rates, expiring invitations, and durable revocation evidence.
- Keep public publication routes separate from private APIs.
- No default public bind, silent LAN discovery, or UPnP.

## Lab — WebRTC courier

- Transfer exactly one reviewed immutable artifact.
- Preserve Source Notes through that native artifact.
- Make signaling, STUN, and TURN visible.
- Refuse replay, identity mismatch, digest mismatch, timeout, and partial completion.
- Destroy the bounded session afterward.
- Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## Stop conditions

- Do not add another evidence layer merely because target-host access is unavailable.
- Do not claim installed-browser, human, privacy, assistive-technology, or accessibility acceptance from managed automation.
- Make another product change only for a reproduced failure.
''')

write("HANDOFF.md", f'''# Handoff — {REV}

## Current candidate

This candidate fixes one reproduced Extension shared-folder update review defect. Native Source Note conflict rows now carry canonical folder paths; the shipped Chromium and generated-Firefox side panels show full routes, exact literal multiline/directional values, curator attribution, the non-safety boundary, and independent placement decisions.

Immediate parent: `{PARENT}`  
SHA-256: `{PARENT_SHA}`

## Verification state

- Focused native/background replay: PASS
- Chromium-source shipped UI replay: PASS
- Generated-Firefox shipped UI replay: PASS
- Complete inherited regression: **{'PASS' if regression_pass else 'PENDING'}**
- Fixed runtime catalog: 18 cases, freshly bound to rev0103
- Installed current-browser triad: NOT RUN
- Human/privacy/assistive-technology fieldwork: NOT RUN

## Next exact action

Prepare fresh rev0103 sessions on actual target hosts. Run unmanaged current Chromium first, then Firefox Release and Firefox ESR. In both divergent-copy cases, include two same-source conflicts in identically titled folders and retain the full route/value/decision evidence. Do not relabel earlier records.
''')

write("RESULT-SUMMARY.md", f'''# Result summary — rev0103 shared-folder merge Source Note disclosure

The parent product accepted placement-scoped Source Note conflict decisions but its Extension shared-folder update review omitted canonical folder routes and used generic value rendering. rev0103 adds route-bound, literal, multiline, direction-aware disclosure with curator attribution and a visible non-safety boundary. Merge semantics and write behavior are unchanged.

Focused Chromium-source and generated-Firefox UI replays passed. Complete inherited regressions: **{'PASS' if regression_pass else 'PENDING'}**. Exact target-host browsers and human/assistive-technology fieldwork remain open.
''')

write("RUNTIME-OPERATOR-GUIDE.md", f'''# Runtime operator guide — rev0103

Use only the exact sealed `{REV}` Roadcase and prepare fresh session-v5 records on the execution host. Capture fresh official browser-channel evidence, the actual browser version, OS build, profile state, and installation method.

Run all 18 fixed cases. For the shared-folder update review:

1. Put one source in two direct folders that share the visible title **Updates**, under distinct parent routes.
2. Create divergent placement reasons in both routes.
3. Verify both full routes are visible before choosing.
4. Verify exact last-accepted, local, and curator values, including multiline, markup-like, and bidirectional text.
5. Choose **Keep mine** for one placement and **Use curator’s** for the other.
6. Verify approval remains disabled until both choices are present.
7. Close/reopen and separately stale the review; prove uncommitted choices are not retained or applied.
8. Verify preview/review makes no listed-source request.

Record first failures, interruption, retries, and recovery. Firefox temporary loading is not signed-install or restart acceptance.
''')

write("SOURCE-NOTES-RUNTIME-PROTOCOL.md", f'''# Source Notes runtime protocol — rev0103

- Revision: `{REV}`
- Fixed cases: 18
- Session schema: v5
- Result/predicate schema: v3
- Fresh preparation required: yes

A pass requires every fixed case to pass with referenced evidence and valid chronology. The two divergent-copy cases include both the read-only Node review and the Extension shared-folder update review. The Extension evidence must show two same-source conflicts in identically titled folders, full canonical routes, exact three-way values, independent decisions, and no automatic winner.

Earlier revision records retain their original scope and must not be relabeled. Managed automation is regression evidence only.
''')

state = json.loads((ROOT / "REVISION-STATE.json").read_text(encoding="utf-8"))
state["checks"]["offlineRegressions"] = {
    "status": "pass" if regression_pass else "pending",
    "cliModules": len([label for label in rows_by_label if label.startswith("cli-")]),
    "cliTests": cli_tests,
    "extensionStaticTests": extension_static,
    "managedNodeHarnessInvocations": status.get("managedNodeHarnessInvocations"),
    "managedWorkbenchUiPathVariants": status.get("managedWorkbenchUiPathVariants"),
    "managedSharedFolderMergeUiPathVariants": status.get("managedSharedFolderMergeUiPathVariants"),
    "runtimeRecordAndComparisonTests": evidence_tests,
    "runtimeEvidenceRevisionBinding": REV,
}
continuity_path = ROOT / "PRODUCT-CONTINUITY-AUDIT.json"
if continuity_path.exists():
    continuity = json.loads(continuity_path.read_text(encoding="utf-8"))
    state["checks"]["productContinuity"] = {"status": continuity.get("status"), **continuity.get("counts", {}), "permissionsExpanded": continuity.get("permissionsExpanded")}
state["checks"]["deterministicBuild"] = {"status": "requires-detached-post-build-report"}
dump("REVISION-STATE.json", state)

print(json.dumps({"revision": REV, "regressionPass": regression_pass, "cliTests": cli_tests, "extensionStaticTests": extension_static, "evidenceTests": evidence_tests, "entrypointCounts": dict(counts)}, ensure_ascii=False, sort_keys=True, indent=2))
