#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, json, os, re, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
EXCLUDED={'.git','node_modules','__pycache__','.pytest_cache','dist','build'}
CODE_SUFFIXES={'.py','.js','.mjs','.cjs'}

def files():
    for base,dirs,names in os.walk(ROOT):
        dirs[:]=[d for d in dirs if d not in EXCLUDED]
        bp=Path(base)
        for n in names:
            p=bp/n
            if p.suffix.lower() in CODE_SUFFIXES:
                yield p

def text(p):
    try:return p.read_text(encoding='utf-8')
    except:return ''

def rel(p):return p.relative_to(ROOT).as_posix()
def is_support(p):
    r=rel(p).lower()
    return any(x in r for x in ('/test','tests/','fixture','reference','fieldwork','evidence')) or Path(r).name.startswith('test_') or '.test.' in r

def nearby_import_reason(t):
    low=t.lower()
    for m in re.finditer(r'\b(import|restore|deserialize|receive|copy|clone|normalize)\w*\b',low):
        a=max(0,m.start()-1200); b=min(len(low),m.end()+5000)
        chunk=low[a:b]
        if 'reason' in chunk and ('member' in chunk or 'placement' in chunk):
            return True
    return False

rows=[]
for p in files():
    t=text(p); low=t.lower()
    if 'reason' in low and ('member' in low or 'placement' in low):
        rows.append({'path':rel(p),'support':is_support(p),'import_reason':nearby_import_reason(t),'python':p.suffix=='.py','browser':p.suffix in {'.js','.mjs','.cjs'}})

native=[r for r in rows if not r['support']]
py=[r for r in native if r['python']]
js=[r for r in native if r['browser']]
imports=[r for r in native if r['import_reason']]
fixture=ROOT/'fixtures'/'source-notes'/'native-placement-replay.json'
fx=json.loads(fixture.read_text(encoding='utf-8'))
case_ids={c['id'] for c in fx['cases']}
required_cases={'same-source-two-folders','same-placement-conflicting-duplicate','unchanged-import-preserves-presence','empty-reason-omitted','folder-level-reason','unicode-code-point-limit','unicode-code-point-over-limit'}
errors=[]
if not py: errors.append('no native Python placement/reason path found')
if not js: errors.append('no native JavaScript placement/reason path found')
if not imports: errors.append('no native import/restore/normalization path mentioning placement reason found')
if not required_cases.issubset(case_ids): errors.append('focused replay fixture is incomplete')
# Relationship-key evidence: native code must mention both a folder/collection id and a source id near reason handling.
relationship=[]
for r in native:
    t=text(ROOT/r['path']).lower()
    if 'reason' in t and re.search(r'(folder|collection)[_a-z]*id',t) and re.search(r'source[_a-z]*id',t):
        relationship.append(r['path'])
if not relationship: errors.append('no native folder/source relationship-key evidence found')
# Reject obvious folder-level schema expansion: a reason property adjacent to a folder object definition without member context.
# This is conservative and reports candidates rather than auto-failing ambiguous prose/tests.
folder_level_candidates=[]
for r in native:
    t=text(ROOT/r['path'])
    for m in re.finditer(r'\breason\b',t,re.I):
        chunk=t[max(0,m.start()-500):m.end()+500]
        if re.search(r'folder\s*[:=]|collection\s*[:=]',chunk,re.I) and not re.search(r'member|placement',chunk,re.I):
            folder_level_candidates.append({'path':r['path'],'offset':m.start()})
report={
 'ok':not errors,
 'errors':errors,
 'native_paths':native,
 'python_paths':[r['path'] for r in py],
 'javascript_paths':[r['path'] for r in js],
 'import_paths':[r['path'] for r in imports],
 'relationship_key_paths':relationship,
 'folder_level_candidates':folder_level_candidates,
 'fixture_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),
 'fixture_cases':sorted(case_ids),
}
out=ROOT/'NATIVE-SOURCE-NOTES-AUDIT.json'
out.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print(json.dumps(report,indent=2,sort_keys=True))
sys.exit(0 if report['ok'] else 1)
