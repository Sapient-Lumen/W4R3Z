#!/usr/bin/env python3
"""Audit rev0104 CLI/Extension product continuity against sealed rev0103."""
from __future__ import annotations
import argparse, hashlib, json, stat, zipfile
from pathlib import Path, PurePosixPath

ROOT=Path(__file__).resolve().parents[1]
REVISION="rev0104-workbench-private-backup-integrity"
PARENT_NAME="ProgRSS-rev0103-shared-folder-merge-source-note-disclosure-2026.10.22-Roadcase.zip"
PARENT_SHA256="68c7b7606f94107dac942d232cef7338f8d8da2dcb1d95b9c88fb7a60fd42fa7"
PARENT_BYTES=19998568
EXPECTED_CHANGED={
 "Extension/README.md", "Extension/Firefox/README.md",
 "Extension/shared/core.js", "Extension/Firefox/shared/core.js",
 "Extension/background.js", "Extension/Firefox/background.js",
 "Extension/workbench/scripts/progrss-app.js", "Extension/Firefox/workbench/scripts/progrss-app.js",
 "Extension/tests/run.sh", "Extension/tests/test_static.py",
}
EXPECTED_ADDED={"Extension/tests/source_notes_workbench_private_backup_harness.py"}

def digest(data:bytes)->str: return hashlib.sha256(data).hexdigest()

def main()->int:
 p=argparse.ArgumentParser(); p.add_argument('--parent',type=Path,required=True); p.add_argument('--json',type=Path,default=ROOT/'PRODUCT-CONTINUITY-AUDIT.json'); p.add_argument('--markdown',type=Path,default=ROOT/'PRODUCT-CONTINUITY-AUDIT.md'); a=p.parse_args()
 raw=a.parent.read_bytes()
 if a.parent.name!=PARENT_NAME or len(raw)!=PARENT_BYTES or digest(raw)!=PARENT_SHA256: raise SystemExit('parent identity mismatch')
 parent={}
 with zipfile.ZipFile(a.parent) as z:
  seen=set()
  for i in z.infolist():
   if i.filename in seen: raise SystemExit(f'duplicate parent member: {i.filename}')
   seen.add(i.filename)
   if i.is_dir() or not (i.filename.startswith('CLI/') or i.filename.startswith('Extension/')): continue
   pure=PurePosixPath(i.filename)
   if pure.is_absolute() or '..' in pure.parts: raise SystemExit(f'unsafe parent member: {i.filename}')
   data=z.read(i); parent[i.filename]={'bytes':len(data),'sha256':digest(data),'mode':oct(stat.S_IMODE((i.external_attr>>16)&0xffff))}
 current={q.relative_to(ROOT).as_posix():q for base in (ROOT/'CLI',ROOT/'Extension') for q in base.rglob('*') if q.is_file() and not q.is_symlink() and q.suffix!='.pyc' and '__pycache__' not in q.parts}
 added=sorted(set(current)-set(parent)); deleted=sorted(set(parent)-set(current)); changed=[]; mode_changed=[]; unchanged=0
 for name in sorted(set(current)&set(parent)):
  q=current[name]; data=q.read_bytes(); mode=oct(stat.S_IMODE(q.stat().st_mode)); prior=parent[name]
  if mode!=prior['mode']: mode_changed.append(name)
  if len(data)!=prior['bytes'] or digest(data)!=prior['sha256']: changed.append(name)
  else: unchanged+=1
 if set(changed)!=EXPECTED_CHANGED or set(added)!=EXPECTED_ADDED or deleted or mode_changed:
  raise SystemExit(json.dumps({'expectedChanged':sorted(EXPECTED_CHANGED),'actualChanged':changed,'expectedAdded':sorted(EXPECTED_ADDED),'actualAdded':added,'deleted':deleted,'modeChanged':mode_changed},ensure_ascii=False,indent=2))
 cli_changed=[x for x in changed+added if x.startswith('CLI/')]
 if cli_changed: raise SystemExit(f'unexpected CLI product changes: {cli_changed}')
 for name in ('Extension/manifest.json','Extension/Firefox/manifest.json'):
  if digest(current[name].read_bytes())!=parent[name]['sha256']: raise SystemExit(f'browser manifest changed: {name}')
 report={'schema':'progrss.product-continuity-audit.v1','revision':REVISION,'parent':{'name':PARENT_NAME,'sha256':PARENT_SHA256,'bytes':len(raw)},'counts':{'parentProductFiles':len(parent),'currentProductFiles':len(current),'unchanged':unchanged,'changed':len(changed),'added':len(added),'deleted':len(deleted),'modeChanged':len(mode_changed)},'changed':changed,'added':added,'deleted':deleted,'modeChanged':mode_changed,'cliChanged':False,'permissionsExpanded':False,'newPersistentStore':False,'newNetworkAuthority':False,'status':'pass'}
 a.json.write_text(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
 a.markdown.write_text('# Product continuity audit — rev0104\n\n'+f'Parent: `{PARENT_NAME}`  \nSHA-256: `{PARENT_SHA256}`\n\n'+f'Compared {len(parent)} parent CLI/Extension paths with {len(current)} current paths. {len(changed)} existing paths changed, {len(added)} focused test path was added, no path was deleted, and no executable mode changed. All CLI product files are byte-identical to the parent. Browser manifests and permission projections are unchanged; no persistent store or network authority was added.\n\n## Changed paths\n\n'+'\n'.join(f'- `{x}`' for x in changed)+'\n\n## Added path\n\n'+'\n'.join(f'- `{x}`' for x in added)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)); return 0
if __name__=='__main__': raise SystemExit(main())
