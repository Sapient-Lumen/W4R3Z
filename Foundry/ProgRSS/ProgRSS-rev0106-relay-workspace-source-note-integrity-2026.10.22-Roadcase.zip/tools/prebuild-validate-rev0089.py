#!/usr/bin/env python3
"""Static and claim-boundary validation before the rev0089 Roadcase build."""
from __future__ import annotations
import ast, importlib, json, re, stat, subprocess, sys
from html.parser import HTMLParser
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SKIP_PARTS={".git","node_modules","__pycache__",".pytest_cache",".mypy_cache",".ruff_cache"}
def files(suffix:str)->list[Path]:
    return [p for p in sorted(ROOT.rglob(f"*{suffix}")) if p.is_file() and not any(part in SKIP_PARTS for part in p.relative_to(ROOT).parts)]
class Parser(HTMLParser): pass
def validate_css(path:Path)->None:
    text=path.read_text(); text=re.sub(r"/\*.*?\*/","",text,flags=re.S); text=re.sub(r"'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\"","",text)
    pairs={"{":"}","(":")","[":"]"}; closing={v:k for k,v in pairs.items()}; stack=[]
    for ch in text:
        if ch in pairs: stack.append(ch)
        elif ch in closing:
            if not stack or stack.pop()!=closing[ch]: raise ValueError(f"CSS delimiter mismatch: {path}")
    if stack: raise ValueError(f"CSS unclosed delimiter: {path}")
def main()->int:
    counts={}
    for p in files('.json'): json.loads(p.read_text())
    counts['json']=len(files('.json'))
    py=files('.py')
    for p in py: ast.parse(p.read_text(),filename=str(p))
    counts['python']=len(py)
    js=files('.js')+files('.mjs')
    for p in js:
        r=subprocess.run(['node','--check',str(p)],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30,check=False)
        if r.returncode: raise RuntimeError(f"JavaScript syntax failed: {p}\n{r.stdout}")
    counts['javascript']=len(js)
    html=files('.html')
    for p in html:
        parser=Parser(convert_charrefs=True); parser.feed(p.read_text()); parser.close()
    counts['html']=len(html)
    css=files('.css')
    for p in css: validate_css(p)
    counts['css']=len(css)
    sys.path.insert(0,str(ROOT/'tools'))
    inherited=importlib.import_module('verify-rev0086-source-notes')
    inherited.verify_permissions(); inherited.verify_generated_firefox(); inherited.verify_authoring_surface_markers()
    channel=importlib.import_module('browser_channel_evidence')
    snapshot,payloads=channel.load_channel_evidence_dir(ROOT/'runtime-channel-reference')
    expected={('chromium','stable'):'156.0.8078.47',('firefox','release'):'158.0.1',('firefox','esr'):'153.5.1esr'}
    for pair,version in expected.items():
        if channel.expected_version(snapshot,*pair)!=version: raise RuntimeError(f"channel version mismatch: {pair}")
    if len(payloads)!=3: raise RuntimeError('channel evidence payload inventory mismatch')
    critical=[
      'CLI/progrss','CLI/progrss-core','tools/build-reconstruction-roadcase.py','tools/browser_channel_evidence.py',
      'tools/prepare-source-notes-runtime-session.py','tools/finalize-source-notes-runtime-session.py',
      'tools/verify-source-notes-runtime-evidence.py','tools/compare-source-notes-runtime-evidence.py',
      'tools/verify-rev0089-source-notes.py','tools/run-rev0089-cli-modules.py','tools/prebuild-validate-rev0089.py',
    ]
    for rel in critical:
        p=ROOT/rel
        if not p.is_file() or not (stat.S_IMODE(p.stat().st_mode)&0o111): raise RuntimeError(f"critical executable mode missing: {rel}")
    state=json.loads((ROOT/'REVISION-STATE.json').read_text()); audit=json.loads((ROOT/'SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.json').read_text()); matrix=json.loads((ROOT/'SOURCE-NOTES-RUNTIME-MATRIX.json').read_text()); provenance=json.loads((ROOT/'RECONSTRUCTION_PROVENANCE.json').read_text()); bootstrap=(ROOT/'BOOTSTRAPROSE.md').read_text()
    if state.get('revision')!='rev0089-source-notes-channel-binding': raise RuntimeError('REVISION-STATE revision mismatch')
    if audit.get('pass') is not True or audit.get('releaseGateClosed') is not False: raise RuntimeError('runtime evidence audit boundary is not green/open')
    if matrix.get('releaseGateClosed') is not False or matrix.get('summary')!={'pass':4,'blocked':1,'notRun':5,'notEstablished':0}: raise RuntimeError('runtime matrix boundary is invalid')
    if provenance.get('reconstructionRevision')!='rev0089-source-notes-channel-binding': raise RuntimeError('provenance revision mismatch')
    if provenance.get('immediateParentSha256')!='0289c62a5d04e9338b1505bf724abea23e122fc6a7f6c50327503314dd637e5a': raise RuntimeError('provenance parent digest mismatch')
    if not bootstrap.startswith('<!-- BEGIN CURRENT-RUN-AUTHORITY rev0089-channel-binding -->'): raise RuntimeError('BOOTSTRAPROSE current authority is not rev0089')
    claims=state['claims']
    if claims.get('browserChannelPayloadBinding') is not True or claims.get('channelVersionDerivedFromBoundBytes') is not True or claims.get('channelSnapshotFreshnessRequiredForPass') is not True: raise RuntimeError('rev0089 channel claims missing')
    for key in ('authenticatedChannelFetch','trustedTimestamp','managedCurrentChromiumRuntime','unmanagedChromiumRuntime','firefoxReleaseRuntime','firefoxEsrRuntime','humanPermissionPromptObservation','accessibilityConformance','assistiveTechnologyFieldwork','unfamiliarParticipantFieldwork','slsaCompliance'):
        if claims.get(key) is not False: raise RuntimeError(f"unsupported claim promoted: {key}")
    print(f"JSON parse: {counts['json']} files"); print(f"Python syntax: {counts['python']} files"); print(f"JavaScript syntax: {counts['javascript']} files"); print(f"HTML parse: {counts['html']} files"); print(f"CSS delimiter check: {counts['css']} files")
    print('Generated Firefox authoring parity: PASS'); print('Channel source/version binding: PASS'); print('Critical executable modes: PASS'); print('Current authority, provenance, matrix, audit, and non-claims: PASS'); print('\nFINAL PREBUILD VALIDATION: PASS'); print(json.dumps(counts,sort_keys=True)); return 0
if __name__=='__main__': raise SystemExit(main())
