#!/usr/bin/env python3
"""Audit rev0106 CLI/Extension product continuity against sealed rev0105."""
from __future__ import annotations
import argparse, hashlib, json, stat, zipfile
from pathlib import Path, PurePosixPath
ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0106-relay-workspace-source-note-integrity"
PARENT_NAME = "ProgRSS-rev0105-node-private-library-source-note-integrity-2026.10.22-Roadcase.zip"
PARENT_SHA256 = "e34cb801d87dd7e4c8bf26cf72ce25e6356af68d20818140691889a59c19dd6c"
PARENT_BYTES = 26881071
EXPECTED_CHANGED = {"CLI/README.md", "CLI/relay.py", "CLI/tests/test_source_notes_entrypoints.py"}
EXPECTED_ADDED = {"CLI/tests/test_source_notes_relay_workspace.py"}
def digest(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def main() -> int:
    parser=argparse.ArgumentParser(); parser.add_argument('--parent',type=Path,required=True); parser.add_argument('--json',type=Path,default=ROOT/'PRODUCT-CONTINUITY-AUDIT.json'); parser.add_argument('--markdown',type=Path,default=ROOT/'PRODUCT-CONTINUITY-AUDIT.md'); args=parser.parse_args()
    raw=args.parent.read_bytes()
    if args.parent.name != PARENT_NAME or len(raw)!=PARENT_BYTES or digest(raw)!=PARENT_SHA256: raise SystemExit('parent identity mismatch')
    parent={}
    with zipfile.ZipFile(args.parent) as archive:
        seen=set()
        for info in archive.infolist():
            if info.filename in seen: raise SystemExit(f'duplicate parent member: {info.filename}')
            seen.add(info.filename)
            if info.is_dir() or not (info.filename.startswith('CLI/') or info.filename.startswith('Extension/')): continue
            pure=PurePosixPath(info.filename)
            if pure.is_absolute() or '..' in pure.parts: raise SystemExit(f'unsafe parent member: {info.filename}')
            data=archive.read(info); parent[info.filename]={'bytes':len(data),'sha256':digest(data),'mode':oct(stat.S_IMODE((info.external_attr>>16)&0xFFFF))}
    current={path.relative_to(ROOT).as_posix():path for base in (ROOT/'CLI',ROOT/'Extension') for path in base.rglob('*') if path.is_file() and not path.is_symlink() and path.suffix!='.pyc' and '__pycache__' not in path.parts}
    added=sorted(set(current)-set(parent)); deleted=sorted(set(parent)-set(current)); changed=[]; mode_changed=[]; unchanged=0
    for name in sorted(set(current)&set(parent)):
        path=current[name]; data=path.read_bytes(); mode=oct(stat.S_IMODE(path.stat().st_mode)); prior=parent[name]
        if mode!=prior['mode']: mode_changed.append(name)
        if len(data)!=prior['bytes'] or digest(data)!=prior['sha256']: changed.append(name)
        else: unchanged+=1
    if set(changed)!=EXPECTED_CHANGED or set(added)!=EXPECTED_ADDED or deleted or mode_changed:
        raise SystemExit(json.dumps({'expectedChanged':sorted(EXPECTED_CHANGED),'actualChanged':changed,'expectedAdded':sorted(EXPECTED_ADDED),'actualAdded':added,'deleted':deleted,'modeChanged':mode_changed},ensure_ascii=False,indent=2))
    for name in ('Extension/manifest.json','Extension/Firefox/manifest.json'):
        if digest(current[name].read_bytes())!=parent[name]['sha256']: raise SystemExit(f'browser manifest changed: {name}')
    report={'schema':'progrss.product-continuity-audit.v1','revision':REVISION,'parent':{'name':PARENT_NAME,'sha256':PARENT_SHA256,'bytes':len(raw)},'counts':{'parentProductFiles':len(parent),'currentProductFiles':len(current),'unchanged':unchanged,'changed':len(changed),'added':len(added),'deleted':len(deleted),'modeChanged':len(mode_changed)},'changed':changed,'added':added,'deleted':deleted,'modeChanged':mode_changed,'cliChanged':True,'extensionChanged':False,'permissionsExpanded':False,'newPersistentStore':False,'newNetworkAuthority':False,'status':'pass'}
    args.json.write_text(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    args.markdown.write_text('# Product continuity audit — rev0106\n\n'+f'Parent: `{PARENT_NAME}`  \nSHA-256: `{PARENT_SHA256}`\n\n'+f'Compared {len(parent)} parent CLI/Extension paths with {len(current)} current paths. Three existing CLI paths changed (including one inherited test fixture updated for the stricter private-workspace contract) and one focused CLI test path was added. No product path was deleted and no executable mode changed. The entire Extension product tree, both browser manifests, and every browser permission projection are byte-identical to rev0105. No persistent store or network authority was added.\n\n## Changed paths\n\n'+'\n'.join(f'- `{n}`' for n in changed)+'\n\n## Added path\n\n'+'\n'.join(f'- `{n}`' for n in added)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)); return 0
if __name__=='__main__': raise SystemExit(main())
