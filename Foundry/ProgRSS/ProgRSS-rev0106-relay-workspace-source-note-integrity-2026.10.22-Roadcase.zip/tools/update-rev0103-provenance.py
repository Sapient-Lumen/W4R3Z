#!/usr/bin/env python3
"""Generate rev0103 provenance against immutable rev0102 parent."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0103-shared-folder-merge-source-note-disclosure"
PARENT_NAME = "ProgRSS-rev0102-node-merge-source-note-disclosure-2026.10.22-Roadcase.zip"
PARENT_SHA = "e4fa5d3560a37695fa1cee27c5245134edaeb72eaf417321df6d6ec249dfdabd"
PRIVATE_DONOR = {
    "name": "ProgRSS-rev0099-source-notes-private-transfer-integrity-2026.10.21-Roadcase.zip",
    "sha256": "c959810ff94479ba0ae2e6cf41bb7293a7abd1b70c827b01196c3b23d34630e8",
    "bytes": 13121255,
}
PRIVATE_BASE = {
    "name": "ProgRSS-rev0098-source-notes-publication-disclosure-2026.10.21-Roadcase.zip",
    "sha256": "2e97f0075281fc19b279db85057c87b3582fb5d9ca30021e9d7d3ff10f2d1a44",
    "bytes": 12093270,
}
EXCLUDED = {"RECONSTRUCTION_PROVENANCE.json", "RECONSTRUCTION_PROVENANCE.md", "ROADCASE-MANIFEST.json", ".DS_Store"}
SKIP_DIRS = {".git", "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def current_rows() -> dict[str, dict[str, object]]:
    rows = {}
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.is_symlink():
            continue
        rel = path.relative_to(ROOT)
        if any(part in SKIP_DIRS for part in rel.parts) or path.name in EXCLUDED or path.suffix == ".pyc" or path.name.endswith((".zip", ".sha256")):
            continue
        data = path.read_bytes()
        rows[rel.as_posix()] = {
            "bytes": len(data), "sha256": sha(data),
            "mode": oct(0o755 if stat.S_IMODE(path.stat().st_mode) & 0o111 else 0o644),
        }
    return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--parent", type=Path, required=True)
    args = parser.parse_args()
    parent_raw = args.parent.read_bytes()
    if args.parent.name != PARENT_NAME or sha(parent_raw) != PARENT_SHA:
        raise SystemExit("parent identity mismatch")
    parent_rows = {}
    with zipfile.ZipFile(args.parent) as zf:
        seen: set[str] = set()
        for info in zf.infolist():
            if info.filename in seen:
                raise SystemExit(f"duplicate parent member: {info.filename}")
            seen.add(info.filename)
            if info.is_dir() or info.filename in EXCLUDED or info.filename.endswith((".zip", ".sha256")):
                continue
            pure = PurePosixPath(info.filename)
            if pure.is_absolute() or ".." in pure.parts:
                raise SystemExit(f"unsafe parent member: {info.filename}")
            data = zf.read(info)
            parent_rows[info.filename] = {
                "bytes": len(data), "sha256": sha(data),
                "mode": oct(0o755 if stat.S_IMODE((info.external_attr >> 16) & 0xFFFF) & 0o111 else 0o644),
            }
    current = current_rows()
    added = sorted(set(current) - set(parent_rows))
    deleted = sorted(set(parent_rows) - set(current))
    changed = sorted(name for name in set(current) & set(parent_rows) if current[name] != parent_rows[name])
    if deleted:
        raise SystemExit(f"unexpected deleted parent paths: {deleted[:10]}")
    report = {
        "schema": "progrss.reconstruction-provenance.v2",
        "generatedUtc": "2026-10-22T00:00:00Z",
        "reconstructionRevision": REVISION,
        "productLineage": {"revision": "rev0080", "version": "0.80.0"},
        "rootBaselineArchive": "ProgRSS-rev0080-2026.10.20-Roadcase(2).zip",
        "rootBaselineSha256": "181308cabfae43330016a272a64fbdb33038f841d605f4756ec65bedb43b8106",
        "immediateParentArchive": PARENT_NAME,
        "immediateParentSha256": PARENT_SHA,
        "integrationDonor": PRIVATE_DONOR,
        "mergeBase": PRIVATE_BASE,
        "lineageClaim": (
            "Continues the sealed rev0102 unified tree and corrects a reproduced Extension shared-folder "
            "three-way Source Note route and disclosure omission. The current parent already contains the "
            "delivered private-transfer, Exchange, Node branch, and Node merge disclosure work. "
            "No missing revision is invented."
        ),
        "missingArtifacts": ["rev0081", "rev0082", "rev0090-source-notes-browser-execution-binding"],
        "inventoryExclusions": sorted(EXCLUDED),
        "added": added,
        "changed": changed,
        "deleted": deleted,
        "differenceCounts": {"added": len(added), "changed": len(changed), "deleted": len(deleted)},
    }
    (ROOT / "RECONSTRUCTION_PROVENANCE.json").write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8"
    )
    (ROOT / "RECONSTRUCTION_PROVENANCE.md").write_text(
        "# Reconstruction provenance — rev0103\n\n"
        f"Immediate parent: `{PARENT_NAME}`  \nSHA-256: `{PARENT_SHA}`\n\n"
        "This candidate continues the sealed rev0102 unified tree and corrects a reproduced Extension shared-folder "
        "three-way Source Note review omission. It does not overlay an older product tree or undo the parent’s "
        "private-transfer, Exchange, branch, Lineage, Workbench, publication, or concurrency corrections.\n\n"
        f"- Added paths: {len(added)}\n- Changed paths or modes: {len(changed)}\n- Deleted paths: {len(deleted)}\n\n"
        "The exact path lists and donor identities are in `RECONSTRUCTION_PROVENANCE.json`. Rev0081, "
        "rev0082, and the undelivered browser-execution-binding source archive remain unavailable.\n",
        encoding="utf-8",
    )
    print(json.dumps(report["differenceCounts"], sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
