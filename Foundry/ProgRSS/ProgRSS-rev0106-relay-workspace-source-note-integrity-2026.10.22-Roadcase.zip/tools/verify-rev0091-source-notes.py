#!/usr/bin/env python3
"""Focused native/managed gate; never a target-host runtime acceptance claim."""
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]
REVISION='rev0091-source-notes-folder-undo'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
def run(label, command, extra=None):
    print('\n== '+label+' ==',flush=True)
    cp=subprocess.run(command,cwd=ROOT,env=dict(os.environ,**(extra or {})),text=True,
                      stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240)
    print(cp.stdout.rstrip(),flush=True)
    if cp.returncode: raise RuntimeError(f'{label}: exit {cp.returncode}')
def main():
    run('cross-runtime contract',['sh','tools/verify-source-notes-contract.sh'])
    run('native placement and CLI authoring',[sys.executable,'-m','unittest','-v',
        'CLI.tests.test_source_notes_entrypoints',
        'CLI.tests.test_command_line.CommandLineTests.test_workspace_source_note_edits_one_direct_placement_offline'])
    run('Node reviewed branch and merge',[sys.executable,'-m','unittest','-v',
        'CLI.tests.test_node_server.NodeServerTests.test_node_owned_branch_operation_is_reviewed_atomic_idempotent_and_snapshot_backed',
        'CLI.tests.test_node_server.NodeServerTests.test_merge_review_is_three_way_read_only_and_requires_admin_origin'])
    for family in ('','Firefox'):
        env={'PROGRSS_EXTENSION_ROOT':family} if family else {}
        for harness in ('source_notes_folder_undo_harness.js','source_notes_entrypoints_harness.js'):
            run((family or 'Chromium-source')+' '+harness,['node','Extension/tests/'+harness],env)
    run('production background continuity',['node','Extension/tests/background_harness.js'])
    sys.path.insert(0,str(ROOT/'tools'))
    inherited=importlib.import_module('verify-rev0086-source-notes')
    inherited.verify_permissions();inherited.verify_generated_firefox()
    from source_notes_runtime_evidence import case_catalog,REVISION as runtime_revision
    assert runtime_revision==REVISION
    assert json.loads((ROOT/'SOURCE-NOTES-RUNTIME-CASES.json').read_text())==case_catalog()
    assert len(case_catalog()['cases'])==18
    state=json.loads((ROOT/'REVISION-STATE.json').read_text())
    assert state['revision']==REVISION and not state['releaseGateClosed']
    assert not state['claims']['installedBrowserRuntimeThisTurn']
    known=json.loads((ROOT/'evidence/rev0091/source-repair-open-reproduction.json').read_text())
    assert known['status']=='OPEN_REPRODUCED' and known['lostReason']
    print('\nPASS focused folder-undo gate. Same-source repair collision remains OPEN.')
    print('Installed browsers, unmanaged current channels, participants and real AT: NOT RUN.')
if __name__=='__main__':
    try:main()
    except (AssertionError,RuntimeError,OSError,subprocess.SubprocessError) as exc:
        print(str(exc),file=sys.stderr);sys.exit(1)
