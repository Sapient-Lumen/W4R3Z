#!/usr/bin/env python3
"""Freeze the bounded rev0087 Source Notes authoring-control audit."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence" / "rev0087"
BASELINE = ROOT / "fixtures" / "source-notes" / "rev0080-extension-permissions.json"
REVISION = "rev0087-source-notes-runtime-kit"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def contains(relative: str, marker: str) -> bool:
    path = ROOT / relative
    return path.is_file() and marker in path.read_text(encoding="utf-8", errors="replace")


def log_has(name: str, marker: str) -> bool:
    path = EVIDENCE / name
    return path.is_file() and marker in path.read_text(encoding="utf-8", errors="replace")


def main() -> int:
    baseline = json.loads(BASELINE.read_text(encoding="utf-8"))
    permission_unchanged = True
    for relative, expected in baseline["manifests"].items():
        document = json.loads((ROOT / relative).read_text(encoding="utf-8"))
        actual = {key: document[key] for key in baseline["fields"] if key in document}
        permission_unchanged = permission_unchanged and actual == expected
    checks = {
        "focusedGate": log_has("focused-authoring-verification.log", "rev0087-source-notes-runtime-kit gate: PASS"),
        "cliCommandTest": log_has("cli-test_command_line.log", "test_workspace_source_note_edits_one_direct_placement_offline") and log_has("cli-test_command_line.log", "OK"),
        "extensionRunner": log_has("extension-tests.log", "EXTENSION_TESTS_RC=0"),
        "managedBrowserSmoke": log_has("extension-browser-smoke-source-notes.log", "PASS side panel: placement-scoped Source Notes"),
        "placementScopedUi": contains("Extension/sidepanel/app.js", "sourceNotePlacementKey"),
        "localBoundaryCopy": contains("Extension/sidepanel/app.js", "publishes nothing, contacts nobody, creates no schedule"),
        "staleWriteGuard": contains("Extension/background.js", "STALE_SOURCE_NOTE"),
        "staleUndoGuard": contains("Extension/background.js", "STALE_SOURCE_NOTE_UNDO"),
        "cliNewFileOnly": contains("CLI/progrss.py", "local only · offline · new-file-only"),
        "nodeAuthoringNotAdded": not contains("CLI/node_server.py", "source-note"),
        "permissionProjectionUnchanged": permission_unchanged,
    }
    passed = all(checks.values())
    audit = {
        "schema": "progrss.source-notes.authoring-audit.v1",
        "revision": REVISION,
        "productLineage": {"revision": "rev0080", "version": "0.80.0"},
        "classification": "candidate-managed-noncurrent-runtime-preflight",
        "pass": passed,
        "checks": checks,
        "relationshipKey": "folderId/sourceId",
        "normalization": {
            "plainText": True,
            "emptyValueOmitted": True,
            "unicodeScalarValidation": True,
            "maxUnicodeCodePoints": 280,
        },
        "cli": {
            "command": "CLI/progrss workspace source-note BACKUP SOURCE FOLDER (--reason TEXT | --clear) --output NEW_BACKUP",
            "surface": "existing offline private-backup folder-edit boundary",
            "writesNewFileOnly": True,
            "overwritesInput": False,
            "network": False,
            "timedUndo": False,
            "rollback": "unchanged input backup",
            "evidence": ["CLI/progrss.py", "CLI/tests/test_command_line.py", "evidence/rev0087/cli-test_command_line.log"],
        },
        "extension": {
            "surface": "existing source-card folder organizer in the side panel",
            "mutationOwner": "Extension background queue and native vault save/broadcast path",
            "staleGuard": ["expected folder version", "expected prior placement reason"],
            "undo": "12-second UI affordance with background version/current-reason guard",
            "managedCoverage": [
                "add",
                "edit",
                "clear",
                "cancel",
                "unchanged save",
                "281-code-point refusal",
                "two-folder independence",
                "ordinary interruption preserves draft and focus",
                "concurrent change refuses stale save",
                "guarded undo",
                "keyboard Escape",
                "320 CSS-pixel reflow smoke",
                "forced-colors static boundary",
                "reduced-motion static boundary",
                "44 CSS-pixel authoring controls",
            ],
            "evidence": [
                "Extension/background.js",
                "Extension/sidepanel/app.js",
                "Extension/sidepanel/app.css",
                "Extension/tests/background_harness.js",
                "Extension/tests/browser_smoke.py",
                "Extension/tests/test_static.py",
            ],
        },
        "node": {
            "authoringControlAdded": False,
            "reason": "The loopback Node exposes reviewed branch/import and merge-review boundaries, not a corresponding local folder-edit surface. Nominal authoring parity would expand authority.",
        },
        "permissions": {
            "audit": "BROWSER-PERMISSION-AUDIT.json",
            "unchangedFromRev0080": permission_unchanged,
            "newRequiredPermissions": [],
            "newOptionalPermissions": [],
            "newHostPermissions": [],
            "newOptionalHostPermissions": [],
        },
        "explicitNonClaims": [
            "unmanaged Chromium runtime",
            "Firefox Release runtime",
            "Firefox ESR runtime",
            "accessibility conformance",
            "real screen-reader, Braille, voice-control, or switch-control evidence",
            "unfamiliar-curator or recipient comprehension",
        ],
        "fileDigests": {
            relative: sha256(ROOT / relative)
            for relative in (
                "CLI/progrss.py",
                "CLI/tests/test_command_line.py",
                "Extension/background.js",
                "Extension/sidepanel/app.js",
                "Extension/sidepanel/app.css",
                "Extension/sidepanel/index.html",
                "Extension/tests/background_harness.js",
                "Extension/tests/browser_smoke.py",
                "Extension/tests/test_static.py",
            )
        },
    }
    (ROOT / "SOURCE-NOTES-AUTHORING-AUDIT.json").write_text(
        json.dumps(audit, ensure_ascii=False, sort_keys=True, indent=2) + "\n",
        encoding="utf-8",
    )
    lines = [
        "# Source Notes authoring audit — rev0087",
        "",
        f"**Result:** {'PASS' if passed else 'NOT ESTABLISHED'} for managed local replay.",
        "",
        "A pass here establishes the shipped CLI and Extension controls and their managed regression evidence. It does not establish unmanaged browser behavior, accessibility conformance, assistive-technology use, or participant comprehension.",
        "",
        "## Shipped controls",
        "",
        "- **CLI:** `workspace source-note` edits or clears one direct placement in a new private backup. The input file remains the rollback copy; no network request is made.",
        "- **Extension:** the existing source-card folder organizer exposes Add/Edit Reason beside each direct placement. Save and undo are guarded by the exact folder version and prior/current reason.",
        "- **Node:** no authoring endpoint was added. The loopback Node remains at reviewed branch/import and merge-review boundaries because it has no corresponding local folder-edit surface.",
        "",
        "## Managed acceptance covered",
        "",
        "Add, edit, clear, cancel, empty omission, 280/281 code-point boundaries, two-folder independence, ordinary-interruption draft preservation, stale-save refusal, guarded undo, keyboard Escape, focus restoration, 44px controls, 320px reflow smoke, forced-colors styling, and reduced-motion styling.",
        "",
        "## Consequence disclosure",
        "",
        "The editor states before save that the change stays in the local ProgRSS library, publishes nothing, contacts nobody, creates no schedule, and is not a ProgRSS safety claim.",
        "",
        "## Permission boundary",
        "",
        f"Required, optional, host, and optional-host permission projections are **{'UNCHANGED' if permission_unchanged else 'CHANGED'}** from the supplied rev0080 baseline.",
        "",
        "## Still unclaimed",
        "",
        "Unmanaged current Chromium, Firefox Release, Firefox ESR, unfamiliar-person comprehension, and real assistive-technology sessions remain P0 fieldwork gates.",
        "",
    ]
    (ROOT / "SOURCE-NOTES-AUTHORING-AUDIT.md").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({"pass": passed, "checks": checks}, sort_keys=True))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
