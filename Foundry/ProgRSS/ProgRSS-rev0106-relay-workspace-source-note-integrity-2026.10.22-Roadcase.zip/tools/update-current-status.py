#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
LOGS=Path('/mnt/data/progrss-logs')
def load(name):
    p=LOGS/name
    return json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
checks=load('reconstruction-checks.json')
integration=load('source-notes-integration-audit.json')
siblings=load('browser-sibling-audit.json')
smoke=load('fieldwork-browser-smoke.json')
found=[]; missing=[]
for name,item in integration.get('checks',{}).items():
    (found if item.get('status')=='candidate-evidence-found' else missing).append(name)
lines=['# Current reconstruction status','',
'Generated from the machine-readable audit outputs. “Candidate evidence” is a static search result and is not a behavioral pass.','',
'## Automated gates','',
f"- Mandatory reconstruction checks: {'PASS' if checks.get('mandatoryPass') else 'NOT ESTABLISHED'}",
f"- Existing native replay attempted: {'yes' if checks.get('nativeReplayAttempted') else 'no'}",
f"- Existing native replay: {'PASS' if checks.get('nativeReplayPass') else 'NOT ESTABLISHED'}",
f"- Native files scanned by integration audit: {integration.get('nativeFilesScanned','unknown')}",
f"- Static integration categories with candidate evidence: {len(found)} of {len(found)+len(missing)}",
f"- Extension manifests found: {len(siblings.get('manifests',[]))}",
f"- Closest Chromium/Firefox pairs formed: {len(siblings.get('pairs',[]))}",
f"- Managed browser smoke overall: {'PASS' if smoke.get('overallPass') else 'NOT ESTABLISHED'}",
f"- Managed browser executables exercised: {len(smoke.get('browsers',[]))}",'',
'## Static integration categories','']
for name in sorted(found): lines.append(f'- Candidate evidence found: `{name}`')
for name in sorted(missing): lines.append(f'- Not established: `{name}`')
lines += ['', '## Classification','',
'This is a candidate reconstruction. Native CLI/Node/Extension behavior, current unmanaged Chromium, current Firefox Release and ESR, assistive-technology use, and unfamiliar-participant comprehension remain release gates unless their exact evidence is added.','']
(ROOT/'CURRENT-STATUS.md').write_text('\n'.join(lines),encoding='utf-8')
print(json.dumps({'candidateEvidence':len(found),'notEstablished':len(missing)}))
