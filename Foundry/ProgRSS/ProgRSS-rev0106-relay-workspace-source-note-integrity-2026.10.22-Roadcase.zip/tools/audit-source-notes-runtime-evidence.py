#!/usr/bin/env python3
"""Report the rev0090 evidence boundary without promoting synthetic/runtime scope."""
from __future__ import annotations
import json
from pathlib import Path
import re
from source_notes_runtime_evidence import REVISION, canonical_json_bytes, case_catalog

ROOT = Path(__file__).resolve().parents[1]


def main():
    evidence = ROOT / "evidence/rev0090"
    log = (evidence / "runtime-evidence-tests.log").read_text()
    match = re.search(r"Ran (\d+) tests", log)
    tests = int(match[1]) if match else 0
    cli = json.loads((evidence / "cli-modules-summary.json").read_text())
    extension = json.loads((evidence / "extension-exit.json").read_text())
    continuity = json.loads((evidence / "product-byte-continuity.json").read_text())
    checks = {
        "evidenceBoundaryTests": tests >= 40 and log.rstrip().endswith("OK"),
        "fullCliModules": cli["allPassed"] and len(cli["results"]) == 11,
        "completeExtensionRunner": extension["returncode"] == 0,
        "productSubtreesUnchanged": continuity["allUnchanged"],
        "fixedEighteenCases": len(case_catalog()["cases"]) == 18,
    }
    audit = {"schema": "progrss.source-notes.runtime-evidence-audit.v2", "revision": REVISION,
             "checks": checks, "unitTests": tests, "pass": all(checks.values()),
             "releaseGateClosed": False, "runtimeCasesExecutedThisTurn": False,
             "classification": "native-and-managed-regressions-plus-synthetic-evidence-boundary-tests",
             "limitations": ["unsigned operator evidence", "no current browser execution", "no human or real AT fieldwork"]}
    (ROOT / "SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.json").write_bytes(canonical_json_bytes(audit))
    (ROOT / "SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.md").write_text(
        "# Runtime evidence audit — rev0090\n\n" +
        "\n".join(f"- {name}: {'PASS' if passed else 'FAIL'}" for name, passed in checks.items()) +
        f"\n\n{tests} synthetic evidence-boundary tests. No browser acceptance row was closed.\n"
        "Evidence paths: `evidence/rev0090/`. Runtime records remain unsigned and operator supplied.\n")
    print(json.dumps(audit, sort_keys=True))
    return 0 if audit["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
