#!/usr/bin/env python3
"""Compare rev0102 CLI/Extension product paths with immutable rev0101 parent."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0102-node-merge-source-note-disclosure"
PARENT_NAME = "ProgRSS-rev0101-unified-exchange-transfer-disclosure-2026.10.22-Roadcase.zip"
PARENT_SHA256 = "5025ea9b20f0a09ea84bd364ccae884b6fc448ea995dd6413d4bdd5e24c55195"
EXPECTED_CHANGED = {
    "CLI/docs/NODE-MERGE-REVIEW.md",
    "CLI/node_web/app.css",
    "CLI/node_web/app.js",
    "CLI/relay.py",
    "CLI/tests/test_node_server.py",
}
EXPECTED_ADDED = {"CLI/tests/source_notes_node_merge_review_harness.py"}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--parent", type=Path, required=True)
    parser.add_argument("--json", type=Path, default=ROOT / "PRODUCT-CONTINUITY-AUDIT.json")
    parser.add_argument("--markdown", type=Path, default=ROOT / "PRODUCT-CONTINUITY-AUDIT.md")
    args = parser.parse_args()
    raw = args.parent.read_bytes()
    if args.parent.name != PARENT_NAME or digest(raw) != PARENT_SHA256:
        raise SystemExit("parent identity mismatch")
    parent_rows: dict[str, dict[str, object]] = {}
    with zipfile.ZipFile(args.parent) as archive:
        seen: set[str] = set()
        for info in archive.infolist():
            if info.filename in seen:
                raise SystemExit(f"duplicate parent member: {info.filename}")
            seen.add(info.filename)
            if info.is_dir() or not (info.filename.startswith("CLI/") or info.filename.startswith("Extension/")):
                continue
            pure = PurePosixPath(info.filename)
            if pure.is_absolute() or ".." in pure.parts:
                raise SystemExit(f"unsafe parent member: {info.filename}")
            data = archive.read(info)
            parent_rows[info.filename] = {
                "bytes": len(data),
                "sha256": digest(data),
                "mode": oct(stat.S_IMODE((info.external_attr >> 16) & 0xFFFF)),
            }
    current_paths = {
        p.relative_to(ROOT).as_posix(): p
        for base in (ROOT / "CLI", ROOT / "Extension")
        for p in base.rglob("*")
        if p.is_file() and not p.is_symlink() and p.suffix != ".pyc" and "__pycache__" not in p.parts
    }
    added = sorted(set(current_paths) - set(parent_rows))
    deleted = sorted(set(parent_rows) - set(current_paths))
    changed: list[str] = []
    mode_changed: list[str] = []
    unchanged = 0
    for name in sorted(set(current_paths) & set(parent_rows)):
        path = current_paths[name]
        data = path.read_bytes()
        mode = oct(stat.S_IMODE(path.stat().st_mode))
        prior = parent_rows[name]
        if mode != prior["mode"]:
            mode_changed.append(name)
        if len(data) != prior["bytes"] or digest(data) != prior["sha256"]:
            changed.append(name)
        else:
            unchanged += 1
    if set(changed) != EXPECTED_CHANGED or set(added) != EXPECTED_ADDED or deleted or mode_changed:
        raise SystemExit(json.dumps({
            "expectedChanged": sorted(EXPECTED_CHANGED), "actualChanged": changed,
            "expectedAdded": sorted(EXPECTED_ADDED), "actualAdded": added,
            "deleted": deleted, "modeChanged": mode_changed,
        }, ensure_ascii=False, indent=2))
    for name in ("Extension/manifest.json", "Extension/Firefox/manifest.json"):
        if digest(current_paths[name].read_bytes()) != parent_rows[name]["sha256"]:
            raise SystemExit(f"browser manifest changed: {name}")
    report = {
        "schema": "progrss.product-continuity-audit.v1",
        "revision": REVISION,
        "parent": {"name": PARENT_NAME, "sha256": PARENT_SHA256, "bytes": len(raw)},
        "counts": {
            "parentProductFiles": len(parent_rows), "currentProductFiles": len(current_paths),
            "unchanged": unchanged, "changed": len(changed), "added": len(added),
            "deleted": len(deleted), "modeChanged": len(mode_changed),
        },
        "changed": changed, "added": added, "deleted": deleted, "modeChanged": mode_changed,
        "permissionsExpanded": False, "newPersistentStore": False, "newNetworkAuthority": False,
        "status": "pass",
    }
    args.json.write_text(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    args.markdown.write_text(
        "# Product continuity audit — rev0102\n\n"
        f"Parent: `{PARENT_NAME}`  \nSHA-256: `{PARENT_SHA256}`\n\n"
        f"Compared {len(parent_rows)} parent CLI/Extension files with {len(current_paths)} current files. "
        f"Exactly {len(changed)} existing paths changed and {len(added)} focused test path was added; "
        "no path was deleted or mode-changed. Browser manifest bytes are unchanged.\n\n"
        "The product correction is confined to the loopback Node three-way review API and rendering path. "
        "It adds full folder-route disclosure and literal placement-reason comparison without a write endpoint, "
        "persistent store, browser permission, or network authority.\n\n"
        "## Changed paths\n\n" + "\n".join(f"- `{name}`" for name in changed) +
        "\n\n## Added focused test\n\n" + "\n".join(f"- `{name}`" for name in added) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
