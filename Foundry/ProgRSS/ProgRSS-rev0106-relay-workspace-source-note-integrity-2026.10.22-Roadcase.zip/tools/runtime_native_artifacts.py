#!/usr/bin/env python3
"""Derive runtime comparison data from the shipped native shared-folder reader.

No browser execution is inferred. Legacy independent excerpts have no embedded
integrity claim; their comparison hash uses the native canonical JSON function
with an explicit, separate domain. Attributed artifacts must pass native digest
(and signature, when present) validation before their existing content digest is
used. IDs, ordering, attribution, recipes, and placement reasons are not erased.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from CLI import relay  # noqa: E402 -- the shipped implementation, not a copy

LEGACY_PROJECTION = "progrss.runtime-native-excerpt-projection.v1"
ATTRIBUTED_PROJECTION = "progrss.native-shared-folder-content-digest.v1"


class NativeArtifactError(ValueError):
    """A claimed native artifact is invalid or not the declared bytes."""


def _unique_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise NativeArtifactError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def _nonfinite(value: str) -> None:
    raise NativeArtifactError(f"non-finite JSON number: {value}")


def derive_native_artifact(data: bytes, *, name: str, evidence_path: str) -> dict[str, Any]:
    """Validate a native artifact and return only byte-derived comparison data."""
    if len(data) > relay.MAX_BUNDLE_BYTES:
        raise NativeArtifactError("native artifact exceeds the shipped 650 KB limit")
    try:
        document = json.loads(data.decode("utf-8"), object_pairs_hook=_unique_pairs,
                              parse_constant=_nonfinite)
        native = relay.validate_bundle(document, raw_size=len(data))
        if name == "completeRoute" and native["schema"] == relay.LEGACY_BUNDLE_SCHEMA:
            raise NativeArtifactError("completeRoute requires attributed native integrity")
        if native["schema"] == relay.LEGACY_BUNDLE_SCHEMA:
            if relay.canonical_json(native) != relay.canonical_json(document):
                raise NativeArtifactError("legacy excerpt is not a canonical shipped export")
            # Independent branch selection intentionally produces a legacy excerpt.
            projection = {key: native[key] for key in ("schema", "root", "title", "sources", "collections")}
            semantic = hashlib.sha256((LEGACY_PROJECTION + "\n" + relay.canonical_json(projection)).encode("utf-8")).hexdigest()
            projection_schema = LEGACY_PROJECTION
            integrity = "absent-legacy-excerpt"
            native_digest = None
        else:
            native_digest = relay.bundle_content_digest(native)
            semantic = native_digest.removeprefix("sha256:")
            projection_schema = ATTRIBUTED_PROJECTION
            integrity = "verified-by-native-reader"
    except (UnicodeError, json.JSONDecodeError, relay.RelayError, ValueError, TypeError, KeyError) as error:
        raise NativeArtifactError(f"{name}: invalid native artifact: {error}") from error
    return {
        "evidencePath": evidence_path,
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "nativeSchema": native["schema"],
        "nativeIntegrity": integrity,
        "nativeContentDigest": native_digest,
        "semanticProjectionSchema": projection_schema,
        "semanticProjectionSha256": semantic,
        "derivedFromEvidenceBytes": True,
    }
