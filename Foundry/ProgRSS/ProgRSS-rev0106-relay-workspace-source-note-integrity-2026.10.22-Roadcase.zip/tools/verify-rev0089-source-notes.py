#!/usr/bin/env python3
"""Replay the bounded rev0089 Source Notes channel-evidence gate.

This focused gate replays the Source Notes contract, shipped placement paths,
exact-package evidence, browser-channel source-byte/version/freshness binding,
and conservative claim limits. It does not claim a current or unmanaged
browser, Firefox runtime, authenticated fetch/operator, human permission
observation, accessibility conformance, assistive technology, or fieldwork.
"""
from __future__ import annotations
import json, os, subprocess, sys
from pathlib import Path
from typing import Sequence
ROOT=Path(__file__).resolve().parents[1]
REVISION="rev0089-source-notes-channel-binding"
def run(name:str, command:Sequence[str], *, timeout:int=420, env:dict[str,str]|None=None)->None:
    print(f"\n== {name} ==")
    completed=subprocess.run(list(command),cwd=ROOT,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout,check=False)
    if completed.stdout: print(completed.stdout.rstrip())
    if completed.returncode: raise RuntimeError(f"{name} failed with exit status {completed.returncode}")
def verify_inherited_boundaries()->None:
    import importlib
    sys.path.insert(0,str(ROOT/"tools"))
    inherited=importlib.import_module("verify-rev0086-source-notes")
    inherited.verify_permissions(); inherited.verify_generated_firefox(); inherited.verify_authoring_surface_markers()
def verify_full_suite_evidence()->None:
    cli=json.loads((ROOT/"evidence/rev0089/cli-modules-summary.json").read_text())
    if cli.get("allPassed") is not True or len(cli.get("results",[]))!=11 or any(r.get("returncode")!=0 for r in cli["results"]):
        raise RuntimeError("rev0089 CLI module evidence is incomplete")
    extension_log=(ROOT/"evidence/rev0089/extension-tests.log").read_text()
    required=("Ran 60 tests","PASS background harness","PASS Source Notes browser entrypoint harness (Chromium source)","PASS Source Notes browser entrypoint harness (Firefox)","PASS Firefox background harness","PASS side panel:","PASS workbench:")
    missing=[m for m in required if m not in extension_log]
    if missing: raise RuntimeError("rev0089 Extension evidence is incomplete: "+", ".join(missing))
    print("full-suite evidence: 11 CLI modules and complete Extension runner PASS")
def verify_catalog_channel_and_claim_boundary()->None:
    sys.path.insert(0,str(ROOT/"tools"))
    from source_notes_runtime_evidence import canonical_json_bytes, case_catalog, sha256_bytes
    from browser_channel_evidence import expected_version, load_channel_evidence_dir
    catalog=json.loads((ROOT/"SOURCE-NOTES-RUNTIME-CASES.json").read_text())
    assert catalog==case_catalog() and len(catalog["cases"])==18
    ids=[r["id"] for r in catalog["cases"]]
    assert len(ids)==len(set(ids)) and "divergent-later-copy-keep-mine" in ids and "divergent-later-copy-use-curator" in ids
    snapshot,payloads=load_channel_evidence_dir(ROOT/"runtime-channel-reference")
    assert expected_version(snapshot,"chromium","stable")=="156.0.8078.47"
    assert expected_version(snapshot,"firefox","release")=="158.0.1"
    assert expected_version(snapshot,"firefox","esr")=="153.5.1esr"
    audit=json.loads((ROOT/"SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.json").read_text())
    matrix=json.loads((ROOT/"SOURCE-NOTES-RUNTIME-MATRIX.json").read_text())
    acquisition=json.loads((ROOT/"evidence/rev0089/current-browser-acquisition.json").read_text())
    assert audit["pass"] is True and audit["releaseGateClosed"] is False
    assert matrix["releaseGateClosed"] is False and matrix["summary"]=={"pass":4,"blocked":1,"notRun":5,"notEstablished":0}
    statuses={r["id"]:r["status"] for r in matrix["rows"]}
    assert statuses["runtime-channel-version-and-freshness-binding"]=="pass"
    assert statuses["runtime-evidence-finalizer-and-verifier"]=="pass"
    assert statuses["current-chromium-managed-acquisition"]=="blocked"
    for identifier in ("exact-final-roadcase-managed-preflight","unmanaged-current-chromium","firefox-release","firefox-esr","unfamiliar-person-and-assistive-technology-fieldwork"):
        assert statuses[identifier]=="not-run",(identifier,statuses[identifier])
    assert acquisition["substitutionMade"] is False and all(v is False for v in acquisition["claims"].values())
    common=(ROOT/"tools/source_notes_runtime_evidence.py").read_text()
    for marker in ('"unmanagedBrowserAcceptance": False','"currentStableAcceptance": False','"humanPermissionPromptObservationAccepted": False','"accessibilityConformance": False','"assistiveTechnologyEvidence": False','"unfamiliarPersonComprehension": False','"unsigned": True','"comparisonClosesRuntimeRow": False','verify_package_against_roadcase','verify_channel_evidence_payloads','channel snapshot is stale at runtime start','channel snapshot capturedUtc must not be later','must exactly match the fixed rev0089 catalog','not-run case must have no timestamp, observation, or evidence'):
        assert marker in common,marker
    print(f"fixed case catalog: 18 cases, sha256={sha256_bytes(canonical_json_bytes(catalog))}")
    print(f"channel source payloads: {len(payloads)-1}; capture={snapshot['capturedUtc']}; maxAge={snapshot['maxAgeSeconds']}s")
    print("runtime evidence claim boundary: fail-closed and release gate remains open")
def main()->int:
    try:
        run("cross-runtime reference contract",["sh","tools/verify-source-notes-contract.sh"])
        run("Python shipped-entrypoint corpus",[sys.executable,"-m","unittest","-v","CLI.tests.test_source_notes_entrypoints"])
        run("CLI shipped placement-authoring command",[sys.executable,"-m","unittest","-v","CLI.tests.test_command_line.CommandLineTests.test_workspace_source_note_edits_one_direct_placement_offline"],timeout=300)
        run("Node branch and merge-review paths",[sys.executable,"-m","unittest","-v","CLI.tests.test_node_server.NodeServerTests.test_node_owned_branch_operation_is_reviewed_atomic_idempotent_and_snapshot_backed","CLI.tests.test_node_server.NodeServerTests.test_merge_review_is_three_way_read_only_and_requires_admin_origin"])
        run("Chromium-source browser core",["node","Extension/tests/source_notes_entrypoints_harness.js"])
        ff=dict(os.environ); ff["PROGRSS_EXTENSION_ROOT"]="Firefox"
        run("generated-Firefox browser core",["node","Extension/tests/source_notes_entrypoints_harness.js"],env=ff)
        run("Extension background continuity and guarded authoring",["node","Extension/tests/background_harness.js"])
        run("Extension authoring and runtime static boundaries",[sys.executable,"-m","unittest","-v","Extension.tests.test_static.JavaScriptTests.test_source_note_authoring_is_placement_scoped_local_and_stale_safe","Extension.tests.test_static.JavaScriptTests.test_source_note_installed_runtime_lane_is_real_view_fail_closed_evidence"])
        run("runtime-evidence unit corpus",[sys.executable,"-m","unittest","-v","tests.test_source_notes_runtime_evidence"])
        run("runtime-evidence audit",[sys.executable,"tools/audit-source-notes-runtime-evidence.py"])
        for label,tool in (("channel evidence CLI","tools/browser_channel_evidence.py"),("runtime session preparer CLI","tools/prepare-source-notes-runtime-session.py"),("runtime session finalizer CLI","tools/finalize-source-notes-runtime-session.py"),("runtime evidence verifier CLI","tools/verify-source-notes-runtime-evidence.py"),("runtime comparison CLI","tools/compare-source-notes-runtime-evidence.py")):
            run(label,[sys.executable,tool,"--help"])
        verify_inherited_boundaries(); verify_full_suite_evidence(); verify_catalog_channel_and_claim_boundary()
    except Exception as error:
        print(f"rev0089 Source Notes verification failed: {error}",file=sys.stderr); return 1
    print(f"\n{REVISION} gate: PASS")
    print("classification: channel-source-byte/version/freshness-bound exact-package evidence with inherited managed non-current preflight; current/unmanaged browsers, Firefox, authenticated acquisition, human prompts, assistive technology, and fieldwork not run")
    return 0
if __name__=="__main__": raise SystemExit(main())
