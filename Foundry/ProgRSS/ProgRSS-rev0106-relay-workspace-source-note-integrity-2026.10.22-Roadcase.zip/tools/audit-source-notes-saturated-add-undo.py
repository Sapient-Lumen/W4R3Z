#!/usr/bin/env python3
"""Audit the reproduced rev0093 saturated folder-add Undo defect and rev0094 refusal."""
from __future__ import annotations
import hashlib, json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0094-source-notes-saturated-add-undo"
PARENT = "ProgRSS-rev0093-source-notes-saturated-concurrency-2026.10.21-Roadcase.zip"
PARENT_SHA = "a5775d6249e3b199f0d1afe8b95626f8d7999c3a024bab81a543c3bf7a92ab8e"
EVIDENCE = ROOT / "evidence" / "rev0094"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    parent_log = (EVIDENCE / "parent-reproduction.log").read_text(encoding="utf-8", errors="replace")
    chromium_log = (EVIDENCE / "folder-undo-chromium.log").read_text(encoding="utf-8", errors="replace")
    firefox_log = (EVIDENCE / "folder-undo-firefox.log").read_text(encoding="utf-8", errors="replace")
    background = (ROOT / "Extension" / "background.js").read_text(encoding="utf-8")
    sidepanel = (ROOT / "Extension" / "sidepanel" / "app.js").read_text(encoding="utf-8")
    tests = (ROOT / "Extension" / "tests" / "source_notes_folder_undo_harness.js").read_text(encoding="utf-8")

    parent_accepted = "REPRODUCED: rev0093 stale saturated add-undo removed replacement placement and its reason" in parent_log
    required_test_names = [
        "saturated add undo succeeds only with exact committed vault revision",
        "saturated stale add undo cannot delete replacement placement or its reason",
        "saturated stale add undo cannot delete an indistinguishable replacement placement",
        "saturated add undo conservatively refuses an unrelated intervening write",
        "below-ceiling unrelated writes do not prevent add undo",
        "side-panel add and undo carry the committed revision",
    ]
    chromium_pass = all(f"PASS {name}" in chromium_log for name in required_test_names) and '"cases":28,"passed":28,"failed":0' in chromium_log
    firefox_pass = all(f"PASS {name}" in firefox_log for name in required_test_names) and '"cases":28,"passed":28,"failed":0' in firefox_log
    code_checks = {
        "addReturnsCommittedRevision": "expectedRevision: state._revision" in background,
        "ceilingUndoRequiresExactRevision": "ProgRSS changed after this folder placement was added" in background,
        "undoRemovesOneExactPlacement": "folder.collection.members.splice(placements[0].index, 1);" in background,
        "reasonBearingReplacementRefused": "Object.prototype.hasOwnProperty.call(placements[0].member, 'reason')" in background,
        "sidePanelStoresRevision": "expectedRevision: result.expectedRevision" in sidepanel,
        "sidePanelForwardsRevision": "expectedRevision: undo.expectedRevision" in sidepanel,
        "explicitNoNetworkCase": "no network requests are made by the entire undo corpus" in tests,
        "browserSiblingBackgroundParity": (ROOT / "Extension" / "background.js").read_bytes() == (ROOT / "Extension" / "Firefox" / "background.js").read_bytes(),
        "browserSiblingSidePanelParity": (ROOT / "Extension" / "sidepanel" / "app.js").read_bytes() == (ROOT / "Extension" / "Firefox" / "sidepanel" / "app.js").read_bytes(),
    }
    passed = parent_accepted and chromium_pass and firefox_pass and all(code_checks.values())
    reproduction = {
        "schema": "progrss.source-notes.saturated-add-undo-reproduction.v1",
        "revision": REVISION,
        "parentArchive": PARENT,
        "parentArchiveSha256": PARENT_SHA,
        "folderVersionCeiling": 10000,
        "parentAcceptedStaleAddUndo": parent_accepted,
        "parentDeletedReplacementPlacement": parent_accepted,
        "parentDeletedReplacementReason": parent_accepted,
        "candidateRefusedStaleAddUndo": chromium_pass and firefox_pass,
        "candidatePreservedReplacementPlacement": chromium_pass and firefox_pass,
        "candidatePreservedReplacementReason": chromium_pass and firefox_pass,
        "belowCeilingBehaviorPreserved": chromium_pass and firefox_pass,
        "variants": ["Chromium-source", "generated-Firefox"],
        "installedBrowserRuntime": False,
        "networkActivity": False,
        "pass": passed,
    }
    (EVIDENCE / "saturated-add-undo-reproduction.json").write_text(json.dumps(reproduction, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    audit = {
        "schema": "progrss.source-notes.saturated-add-undo-audit.v1",
        "revision": REVISION,
        "parent": {"archive": PARENT, "sha256": PARENT_SHA, "acceptedStaleUndo": parent_accepted},
        "candidate": {
            "chromiumCases": 28,
            "firefoxCases": 28,
            "chromiumPass": chromium_pass,
            "firefoxPass": firefox_pass,
            "backgroundSha256": sha(ROOT / "Extension" / "background.js"),
            "sidePanelSha256": sha(ROOT / "Extension" / "sidepanel" / "app.js"),
        },
        "checks": code_checks,
        "claims": {
            "releaseGateClosed": False,
            "installedBrowserRuntime": False,
            "unmanagedCurrentBrowser": False,
            "participantOrAssistiveTechnologyEvidence": False,
        },
        "pass": passed,
    }
    (ROOT / "SOURCE-NOTES-SATURATED-ADD-UNDO-AUDIT.json").write_text(json.dumps(audit, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    lines = [
        "# Source Notes saturated folder-add Undo audit — rev0094", "",
        f"- Parent accepted stale add Undo and deleted a replacement reason: **{'YES' if parent_accepted else 'NO'}**",
        f"- Chromium-source focused corpus: **{'PASS' if chromium_pass else 'FAIL'}** (28 cases)",
        f"- Generated-Firefox focused corpus: **{'PASS' if firefox_pass else 'FAIL'}** (28 cases)",
        f"- Exact-revision ceiling guard and single-placement removal checks: **{'PASS' if all(code_checks.values()) else 'FAIL'}**", "",
        "The parent reproduction and candidate checks use production background handlers with browser API doubles. They are not installed-browser, participant, accessibility, or assistive-technology acceptance.",
        "",
        "At folder version `10000`, add Undo now requires the exact committed vault revision. Below the ceiling, an unrelated vault write remains nonblocking when the folder version still identifies the unchanged placement.",
    ]
    (ROOT / "SOURCE-NOTES-SATURATED-ADD-UNDO-AUDIT.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"pass": passed, "parentAccepted": parent_accepted, "chromium": chromium_pass, "firefox": firefox_pass}, sort_keys=True))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
