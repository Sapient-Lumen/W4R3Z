#!/usr/bin/env python3
"""Conservative static comparison of extension roots; no browser run is inferred."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess

ROOT=Path(__file__).resolve().parents[1]
OUT=Path('/mnt/data/progrss-logs'); OUT.mkdir(parents=True,exist_ok=True)
SKIP={'.git','node_modules','__pycache__','.pytest_cache'}

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def manifests():
    out=[]
    for p in ROOT.rglob('manifest.json'):
        rel=p.relative_to(ROOT)
        if any(part in SKIP for part in rel.parts): continue
        try: data=json.loads(p.read_text(encoding='utf-8'))
        except Exception: continue
        browser='firefox' if ('browser_specific_settings' in data or 'applications' in data and isinstance(data.get('applications'),dict) and 'gecko' in data['applications']) else 'chromium-or-generic'
        perms={key:sorted(data.get(key,[])) if isinstance(data.get(key,[]),list) else data.get(key) for key in ('permissions','optional_permissions','host_permissions','optional_host_permissions')}
        out.append({'path':p,'root':p.parent,'relative':rel.as_posix(),'browser':browser,'manifest':data,'permissions':perms})
    return out

def inventory(root):
    out={}
    for p in root.rglob('*'):
        if not p.is_file() or p.name=='manifest.json' or any(part in SKIP for part in p.relative_to(root).parts): continue
        out[p.relative_to(root).as_posix()]={'sha256':digest(p),'bytes':p.stat().st_size}
    return out

items=manifests()
for item in items: item['inventory']=inventory(item['root'])
pairs=[]
chromes=[x for x in items if x['browser']=='chromium-or-generic']
firefoxes=[x for x in items if x['browser']=='firefox']
for ff in firefoxes:
    best=None
    for ch in chromes:
        a=set(ff['inventory']); b=set(ch['inventory']); union=a|b
        similarity=len(a&b)/len(union) if union else 1.0
        candidate=(similarity,ch)
        if best is None or candidate[0]>best[0]: best=candidate
    if best:
        sim,ch=best
        common=sorted(set(ch['inventory'])&set(ff['inventory']))
        changed=[name for name in common if ch['inventory'][name]['sha256']!=ff['inventory'][name]['sha256']]
        only_ch=sorted(set(ch['inventory'])-set(ff['inventory']))
        only_ff=sorted(set(ff['inventory'])-set(ch['inventory']))
        source_note_ch=[]; source_note_ff=[]
        for name in common:
            for side,dest in ((ch,source_note_ch),(ff,source_note_ff)):
                p=side['root']/name
                if p.suffix.lower() in {'.js','.mjs','.cjs','.html','.json','.css'} and p.stat().st_size<2_000_000:
                    text=p.read_text(encoding='utf-8',errors='ignore').lower()
                    if 'source note' in text or 'keep mine' in text or 'use curator' in text: dest.append(name)
        pairs.append({
            'chromium':ch['relative'],'firefox':ff['relative'],'inventorySimilarity':sim,
            'commonFiles':len(common),'byteIdenticalCommonFiles':len(common)-len(changed),
            'changedCommonFiles':changed,'chromiumOnly':only_ch,'firefoxOnly':only_ff,
            'permissionsEqual':ch['permissions']==ff['permissions'],
            'chromiumPermissions':ch['permissions'],'firefoxPermissions':ff['permissions'],
            'sourceNoteFilesChromium':sorted(set(source_note_ch)),'sourceNoteFilesFirefox':sorted(set(source_note_ff)),
            'sourceNoteFileSetsEqual':sorted(set(source_note_ch))==sorted(set(source_note_ff)),
        })

report={
 'classification':'Static inventory comparison only. It does not establish generated provenance, runtime parity, current-browser compatibility, or accessibility.',
 'manifests':[{'path':x['relative'],'browser':x['browser'],'permissions':x['permissions'],'files':len(x['inventory'])} for x in items],
 'pairs':pairs,
}
(OUT/'browser-sibling-audit.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
with (OUT/'browser-sibling-audit.md').open('w',encoding='utf-8') as f:
    f.write('# Browser sibling audit\n\n')
    f.write(f"**Classification:** {report['classification']}\n\n")
    if not items: f.write('No parseable extension manifests were found.\n')
    for item in report['manifests']:
        f.write(f"- `{item['path']}` — {item['browser']}, {item['files']} non-manifest files\n")
    f.write('\n## Closest Chromium/Firefox pairs\n\n')
    if not pairs: f.write('No Chromium/Firefox pair could be formed.\n')
    for pair in pairs:
        f.write(f"### `{pair['chromium']}` ↔ `{pair['firefox']}`\n\n")
        f.write(f"- Inventory similarity: {pair['inventorySimilarity']:.3f}\n")
        f.write(f"- Common files: {pair['commonFiles']}\n")
        f.write(f"- Byte-identical common files: {pair['byteIdenticalCommonFiles']}\n")
        f.write(f"- Permission arrays equal: {pair['permissionsEqual']}\n")
        f.write(f"- Source Notes candidate file sets equal: {pair['sourceNoteFileSetsEqual']}\n")
        if pair['changedCommonFiles']: f.write('- Changed common files: '+', '.join(f'`{x}`' for x in pair['changedCommonFiles'])+'\n')
        if pair['chromiumOnly']: f.write('- Chromium-only: '+', '.join(f'`{x}`' for x in pair['chromiumOnly'])+'\n')
        if pair['firefoxOnly']: f.write('- Firefox-only: '+', '.join(f'`{x}`' for x in pair['firefoxOnly'])+'\n')
print(json.dumps({'manifestCount':len(items),'pairCount':len(pairs)}))
