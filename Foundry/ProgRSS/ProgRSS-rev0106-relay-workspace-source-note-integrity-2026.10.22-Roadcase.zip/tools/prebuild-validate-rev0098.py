#!/usr/bin/env python3
"""Syntax, parity, provenance, and honest open-gate checks for rev0098."""
from __future__ import annotations

import ast
import importlib
import json
import stat
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
old = importlib.import_module("prebuild-validate-rev0089")
REVISION = "rev0098-source-notes-publication-disclosure"
PARENT_SHA = "65643a4899276bdbbc348aacee60a3db2c84a23c70f3c4f32df3ec03188a4336"


def main() -> None:
    counts: dict[str, int] = {}
    for path in old.files(".json"):
        json.loads(path.read_text())
    counts["json"] = len(old.files(".json"))
    for path in old.files(".py"):
        ast.parse(path.read_text(), filename=str(path))
    counts["python"] = len(old.files(".py"))
    javascript = old.files(".js") + old.files(".mjs")
    for path in javascript:
        subprocess.run(["node", "--check", str(path)], check=True, capture_output=True, timeout=30)
    counts["javascript"] = len(javascript)
    for path in old.files(".html"):
        parser = old.Parser(convert_charrefs=True)
        parser.feed(path.read_text())
        parser.close()
    counts["html"] = len(old.files(".html"))
    for path in old.files(".css"):
        old.validate_css(path)
    counts["css"] = len(old.files(".css"))

    inherited = importlib.import_module("verify-rev0086-source-notes")
    inherited.verify_permissions()
    inherited.verify_generated_firefox()
    from source_notes_runtime_evidence import REVISION as runtime_revision, case_catalog

    state = json.loads((ROOT / "REVISION-STATE.json").read_text())
    provenance = json.loads((ROOT / "RECONSTRUCTION_PROVENANCE.json").read_text())
    audit = json.loads((ROOT / "SOURCE-NOTES-PUBLICATION-DISCLOSURE-AUDIT.json").read_text())
    continuity = json.loads((ROOT / "PRODUCT-CONTINUITY-AUDIT.json").read_text())
    entry = json.loads((ROOT / "SOURCE-NOTES-ENTRYPOINT-MATRIX.json").read_text())
    matrix = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-MATRIX.json").read_text())
    reproduction = json.loads((ROOT / "evidence/rev0098/parent-publication-source-note-omission.json").read_text())

    assert state["revision"] == runtime_revision == provenance["reconstructionRevision"] == REVISION
    assert provenance["immediateParentSha256"] == PARENT_SHA
    assert not state["releaseGateClosed"]
    assert state["claims"]["productChanged"]
    assert state["claims"]["cliChanged"] and state["claims"]["extensionChanged"]
    assert not state["claims"]["permissionsExpanded"]
    for name in (
        "installedBrowserRuntimeThisTurn", "unmanagedChromiumRuntime", "firefoxReleaseRuntime",
        "firefoxEsrRuntime", "humanPermissionPromptObservation", "assistiveTechnologyFieldwork",
        "unfamiliarParticipantFieldwork", "policyModified", "accessibilityConformance",
    ):
        assert state["claims"][name] is False, name
    assert json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text()) == case_catalog()
    assert len(case_catalog()["cases"]) == 18
    assert (ROOT / "BOOTSTRAPROSE.md").read_text().startswith("# `/run` authority — rev0098")
    assert reproduction["reproduced"] is True
    assert audit["pass"] is True and audit["candidate"]["casesPerVariant"] == 12
    assert continuity["pass"] is True and continuity["permissions"]["expanded"] is False
    assert entry["revision"] == REVISION
    assert entry["summary"] == {"inherited": 1, "not-run": 4, "pass": 24}
    assert any(row["id"] == "ready-to-host-publication-reason-disclosure" and row["status"] == "pass" for row in entry["rows"])
    assert matrix["revision"] == REVISION and not matrix["releaseGateClosed"]
    assert matrix["summary"] == {"not-run": 5, "pass": 11}
    assert any(row["id"] == "ready-to-host-publication-reason-disclosure" and row["status"] == "pass" for row in matrix["rows"])

    chromium = ROOT / "Extension/shared/publication-site.js"
    firefox = ROOT / "Extension/Firefox/shared/publication-site.js"
    assert chromium.read_bytes() == firefox.read_bytes()
    for marker in ("Curator’s reason for this folder:", "not a ProgRSS safety claim", "sourceNotes", "white-space:pre-wrap", 'dir="auto"'):
        assert marker in chromium.read_text(), marker
        assert marker in (ROOT / "CLI/relay.py").read_text(), marker

    critical = (
        "CLI/progrss", "CLI/progrss-core", "tools/build-reconstruction-roadcase.py",
        "tools/verify-rev0098-source-notes.py", "tools/run-rev0098-regressions.py",
        "tools/prebuild-validate-rev0098.py", "tools/audit-source-notes-publication-disclosure.py",
        "tools/audit-rev0098-product-continuity.py", "tools/update-reconstruction-provenance.py",
    )
    for relative in critical:
        path = ROOT / relative
        assert path.is_file() and stat.S_IMODE(path.stat().st_mode) & 0o111, relative

    print(json.dumps({"pass": True, "revision": REVISION, "syntaxCounts": counts, "releaseGateClosed": False}, sort_keys=True))


if __name__ == "__main__":
    main()
