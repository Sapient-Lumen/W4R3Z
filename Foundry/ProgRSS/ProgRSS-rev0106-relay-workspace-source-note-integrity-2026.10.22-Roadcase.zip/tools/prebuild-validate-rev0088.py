#!/usr/bin/env python3
"""Static and claim-boundary validation before the rev0088 Roadcase build."""
from __future__ import annotations

import ast
from html.parser import HTMLParser
import importlib
import json
from pathlib import Path
import re
import stat
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SKIP_PARTS = {".git", "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"}


def files(suffix: str) -> list[Path]:
    return [
        path for path in sorted(ROOT.rglob(f"*{suffix}"))
        if path.is_file() and not any(part in SKIP_PARTS for part in path.relative_to(ROOT).parts)
    ]


class Parser(HTMLParser):
    pass


def validate_css(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    text = re.sub(r"'(?:\\.|[^'\\])*'|\"(?:\\.|[^\"\\])*\"", "", text)
    pairs = {"{": "}", "(": ")", "[": "]"}
    closing = {value: key for key, value in pairs.items()}
    stack: list[str] = []
    for char in text:
        if char in pairs:
            stack.append(char)
        elif char in closing:
            if not stack or stack.pop() != closing[char]:
                raise ValueError(f"CSS delimiter mismatch: {path}")
    if stack:
        raise ValueError(f"CSS unclosed delimiter: {path}")


def main() -> int:
    counts: dict[str, int] = {}
    for path in files(".json"):
        json.loads(path.read_text(encoding="utf-8"))
    counts["json"] = len(files(".json"))

    py_files = files(".py")
    for path in py_files:
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    counts["python"] = len(py_files)

    js_files = files(".js") + files(".mjs")
    for path in js_files:
        completed = subprocess.run(
            ["node", "--check", str(path)],
            cwd=ROOT,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=30,
            check=False,
        )
        if completed.returncode:
            raise RuntimeError(f"JavaScript syntax failed: {path}\n{completed.stdout}")
    counts["javascript"] = len(js_files)

    html_files = files(".html")
    for path in html_files:
        parser = Parser(convert_charrefs=True)
        parser.feed(path.read_text(encoding="utf-8"))
        parser.close()
    counts["html"] = len(html_files)

    css_files = files(".css")
    for path in css_files:
        validate_css(path)
    counts["css"] = len(css_files)

    sys.path.insert(0, str(ROOT / "tools"))
    inherited = importlib.import_module("verify-rev0086-source-notes")
    inherited.verify_permissions()
    inherited.verify_generated_firefox()
    inherited.verify_authoring_surface_markers()

    critical_executables = [
        "CLI/progrss",
        "CLI/progrss-core",
        "tools/build-reconstruction-roadcase.py",
        "tools/prepare-source-notes-runtime-session.py",
        "tools/finalize-source-notes-runtime-session.py",
        "tools/verify-source-notes-runtime-evidence.py",
        "tools/compare-source-notes-runtime-evidence.py",
        "tools/verify-rev0088-source-notes.py",
        "tools/run-rev0088-cli-modules.py",
        "tools/prebuild-validate-rev0088.py",
    ]
    for relative in critical_executables:
        path = ROOT / relative
        if not path.is_file() or not (stat.S_IMODE(path.stat().st_mode) & 0o111):
            raise RuntimeError(f"critical executable mode missing: {relative}")

    state = json.loads((ROOT / "REVISION-STATE.json").read_text(encoding="utf-8"))
    audit = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.json").read_text(encoding="utf-8"))
    matrix = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-MATRIX.json").read_text(encoding="utf-8"))
    provenance = json.loads((ROOT / "RECONSTRUCTION_PROVENANCE.json").read_text(encoding="utf-8"))
    bootstrap = (ROOT / "BOOTSTRAPROSE.md").read_text(encoding="utf-8")
    if state.get("revision") != "rev0088-source-notes-runtime-evidence":
        raise RuntimeError("REVISION-STATE revision mismatch")
    if audit.get("pass") is not True or audit.get("releaseGateClosed") is not False:
        raise RuntimeError("runtime evidence audit boundary is not green/open")
    if matrix.get("releaseGateClosed") is not False or matrix.get("summary", {}).get("blocked") != 1:
        raise RuntimeError("runtime matrix boundary is invalid")
    if provenance.get("reconstructionRevision") != "rev0088-source-notes-runtime-evidence":
        raise RuntimeError("provenance revision mismatch")
    if provenance.get("immediateParentSha256") != "3c0e6047b3a8004f294fb1d80cbb3f722e473d8cf75231cef9f12929c0251133":
        raise RuntimeError("provenance parent digest mismatch")
    if not bootstrap.startswith("<!-- BEGIN CURRENT-RUN-AUTHORITY rev0088-runtime-evidence -->"):
        raise RuntimeError("BOOTSTRAPROSE current authority is not rev0088")
    if state["claims"].get("managedCurrentChromiumRuntime") is not False:
        raise RuntimeError("current managed Chromium claim was promoted")
    for key in (
        "unmanagedChromiumRuntime", "firefoxReleaseRuntime", "firefoxEsrRuntime",
        "humanPermissionPromptObservation", "accessibilityConformance",
        "assistiveTechnologyFieldwork", "unfamiliarParticipantFieldwork", "slsaCompliance",
    ):
        if state["claims"].get(key) is not False:
            raise RuntimeError(f"unsupported claim promoted: {key}")

    print(f"JSON parse: {counts['json']} files")
    print(f"Python syntax: {counts['python']} files")
    print(f"JavaScript syntax: {counts['javascript']} files")
    print(f"HTML parse: {counts['html']} files")
    print(f"CSS delimiter check: {counts['css']} files")
    print("Generated Firefox authoring parity: PASS")
    print("Critical executable modes: PASS")
    print("Current authority, provenance, matrix, audit, and non-claims: PASS")
    print("\nFINAL PREBUILD VALIDATION: PASS")
    print(json.dumps(counts, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
