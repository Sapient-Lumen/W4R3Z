#!/usr/bin/env python3
"""Write rev0104 current authority, audits, matrices, and handoff."""
from __future__ import annotations
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REV="rev0104-workbench-private-backup-integrity"
PARENT="ProgRSS-rev0103-shared-folder-merge-source-note-disclosure-2026.10.22-Roadcase.zip"
PARENT_SHA="68c7b7606f94107dac942d232cef7338f8d8da2dcb1d95b9c88fb7a60fd42fa7"
PARENT_BYTES=19998568
DATE="2026-10-22"

def write(name:str,text:str)->None: (ROOT/name).write_text(text.rstrip()+"\n",encoding="utf-8")
def dump(name:str,obj:object)->None: (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf-8")

status_path=ROOT/'evidence/rev0104/regression-status.json'
status=json.loads(status_path.read_text(encoding='utf-8')) if status_path.exists() else {'complete':False,'allPassed':False,'rows':[]}
rows={str(r.get('label')):r for r in status.get('rows',[])}
cli_tests=sum(int(r.get('tests') or 0) for r in status.get('rows',[]) if str(r.get('label','')).startswith('cli-'))
ext_static=int(rows.get('extension-static',{}).get('tests') or 0)
evidence_tests=int(rows.get('evidence-boundary',{}).get('tests') or 0)
regression_pass=bool(status.get('complete') and status.get('allPassed'))
continuity=json.loads((ROOT/'PRODUCT-CONTINUITY-AUDIT.json').read_text(encoding='utf-8'))

focused={
 'schema':'progrss.source-notes.workbench-private-backup-integrity-audit.v1','revision':REV,
 'parent':{'name':PARENT,'sha256':PARENT_SHA,'bytes':PARENT_BYTES},'status':'focused-pass',
 'reproduction':{
  'path':'Advanced Workbench > Private backup','parentDownloadedMalformedBackup':True,
  'reasonCodePoints':281,'expectedMaximum':280,
  'evidence':['evidence/rev0104/parent-reproduction/result.json','evidence/rev0104/parent-reproduction/parent-invalid-private-backup.json','evidence/rev0104/parent-reproduction/reproduce-parent-workbench-private-backup.py']},
 'correction':{
  'sharedAuditHelper':True,'everydayTransferDelegatesToSharedHelper':True,'workbenchCurrentInMemoryStatePreserved':True,
  'downloadBeforeValidation':False,'validReasonsPreservedExactly':True,'absentReasonRemainsAbsent':True,
  'malformedFormsRefused':9,'vaultWrite':False,'network':False,'permissionsExpanded':False,'newPersistentStore':False},
 'focusedTests':{'browserPackageVariants':2,'checksPerVariant':10,'validChecksPerVariant':1,'invalidFormsPerVariant':9,'status':'pass'},
 'completeRegression':{'status':'pass' if regression_pass else 'pending','cliTests':cli_tests,'extensionStaticTests':ext_static,'runtimeRecordAndComparisonTests':evidence_tests,'managedNodeHarnessInvocations':status.get('managedNodeHarnessInvocations'),'managedWorkbenchUiPathVariants':status.get('managedWorkbenchUiPathVariants'),'managedWorkbenchPrivateBackupUiPathVariants':status.get('managedWorkbenchPrivateBackupUiPathVariants'),'managedSharedFolderMergeUiPathVariants':status.get('managedSharedFolderMergeUiPathVariants')}
}
dump('SOURCE-NOTES-WORKBENCH-PRIVATE-BACKUP-INTEGRITY-AUDIT.json',focused)
write('SOURCE-NOTES-WORKBENCH-PRIVATE-BACKUP-INTEGRITY-AUDIT.md',f'''# Advanced Workbench private-backup Source Note integrity audit — rev0104

Parent: `{PARENT}`  
SHA-256: `{PARENT_SHA}`

## Reproduced defect

The shipped Advanced Workbench’s **Private backup** control serialized its current in-memory library directly and did not call the unified private-transfer Source Note validator. The retained parent reproduction downloaded a private backup containing a direct-placement reason with **281 Unicode code points**, although the contract permits at most 280.

## Correction

- One shared `auditSourceNotes` helper now owns the fail-closed direct-placement audit in the Extension core.
- The everyday background private-transfer path delegates to that helper.
- Advanced Workbench audits its current in-memory state before creating a download, so unsaved Workbench state is preserved without introducing a background-state race.
- Valid route-specific multiline and Unicode reasons remain exact; absent reasons remain absent.
- Over-limit, wrong-level, folder-member, duplicate, empty, edge-whitespace, non-string, invalid-Unicode, and missing-source forms are refused before download.
- Refusal performs no vault write, network request, permission request, or automatic normalization.

## Focused result

- Chromium-source package: **10/10 checks passed**
- Generated-Firefox package: **10/10 checks passed**
- Complete inherited regression: **{'PASS' if regression_pass else 'PENDING'}**

The Workbench’s existing toast is a programmatic status region. Managed verification of that markup is not a screen-reader or accessibility-conformance claim.
''')

integration={'schema':'progrss.integration-audit.v1','revision':REV,'status':'pass','parent':{'name':PARENT,'sha256':PARENT_SHA,'bytes':PARENT_BYTES},'currentCorrection':'Advanced Workbench private-backup Source Note validation through the shared Extension audit','inherited':{'rev0103SharedFolderMergeDisclosure':True,'rev0102NodeMergeDisclosure':True,'rev0101UnifiedExchangePrivateTransfer':True,'rev0100NodeBranchDisclosure':True},'missingArtifacts':['rev0081','rev0082','rev0090-source-notes-browser-execution-binding'],'releaseGateClosed':False}
dump('INTEGRATION-AUDIT.json',integration)
write('INTEGRATION-AUDIT.md',f'''# Integration audit — rev0104

Immediate parent: `{PARENT}`  
SHA-256: `{PARENT_SHA}`

This candidate continues the sealed rev0103 unified tree and corrects one reproduced Advanced Workbench private-backup validation bypass. It retains the parent’s private-transfer, Exchange, Node branch, Node merge, shared-folder merge, publication, Lineage, Workbench collection, repair, concurrency, whole-placement Undo, native-integrity, and runtime-record corrections.

No older product tree was overlaid. Rev0081, rev0082, and the undelivered browser-execution-binding source archive remain unavailable and are not represented as recovered. The release gate remains open.
''')

runtime_audit={'schema':'progrss.source-notes.runtime-evidence-audit.v1','revision':REV,'status':'pass' if regression_pass else 'pending','cases':18,'changedCaseIds':['two-folder-independence'],'sessionSchema':'v5','resultSchema':'v3','freshPreparationRequired':True,'runtimeRecordAndComparisonTests':evidence_tests,'standaloneStatementsAccepted':False,'unknownClaimFieldsAccepted':False,'targetBrowserAcceptance':False}
dump('SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.json',runtime_audit)
write('SOURCE-NOTES-RUNTIME-EVIDENCE-AUDIT.md',f'''# Runtime-evidence binding audit — rev0104

- Fixed catalog: **18 cases**
- Changed case description: `two-folder-independence`
- Session schema: v5
- Result/predicate schema: v3
- Fresh rev0104 preparation required: **yes**
- Runtime-record and verified-comparison tests: **{evidence_tests}**
- Installed current-browser acceptance established: **no**

The existing two-folder case now includes Advanced Workbench Private backup preservation and malformed-state refusal. No nineteenth behavioral case was created. Earlier records retain their original revision and must not be relabeled.
''')

matrix=json.loads((ROOT/'SOURCE-NOTES-ENTRYPOINT-MATRIX.json').read_text(encoding='utf-8'))
matrix['revision']=REV
matrix['classification']='all shipped implementation rows pass in native/managed scope, including fail-closed Advanced Workbench private backup; exact browser and fieldwork gates remain open'
matrix['rows']=[r for r in matrix['rows'] if r.get('id')!='workbench-private-backup-integrity']
matrix['rows'].append({
 'id':'workbench-private-backup-integrity','surface':'Extension Advanced Workbench Private backup',
 'behavior':'Audit the current in-memory library with the shared direct-placement Source Notes contract before download; preserve valid route-specific reasons and absence exactly; refuse malformed local state without download, write, network, or silent rewriting.',
 'command':'python3 Extension/tests/source_notes_workbench_private_backup_harness.py --root Extension && python3 Extension/tests/source_notes_workbench_private_backup_harness.py --root Extension/Firefox',
 'paths':['Extension/shared/core.js','Extension/background.js','Extension/workbench/scripts/progrss-app.js','Extension/Firefox/shared/core.js','Extension/Firefox/background.js','Extension/Firefox/workbench/scripts/progrss-app.js','Extension/tests/source_notes_workbench_private_backup_harness.py'],
 'evidence':['evidence/rev0104/parent-reproduction/result.json','evidence/rev0104/focused-summary.json','evidence/rev0104/regressions/workbench-private-backup-chromium.log','evidence/rev0104/regressions/workbench-private-backup-firefox.log'],
 'evidenceType':'shipped-ui-path-managed-replay','limitation':'Managed in-page vault and browser automation; not installed-browser, participant, privacy, or assistive-technology acceptance.','status':'pass'})
dump('SOURCE-NOTES-ENTRYPOINT-MATRIX.json',matrix)
write('SOURCE-NOTES-ENTRYPOINT-MATRIX.md','# Source Notes shipped-entrypoint matrix — rev0104\n\nClassification: all implementation rows pass in native/managed scope; exact browser and fieldwork gates remain open.\n\n| Surface | Behavior | Status | Limitation |\n|---|---|---|---|\n'+'\n'.join(f"| {r.get('surface','')} | {r.get('behavior','').replace('|','/')} | **{str(r.get('status','')).upper()}** | {r.get('limitation','').replace('|','/')} |" for r in matrix['rows']))

runtime_rows=[
 {'id':'sealed-rev0103-parent','scope':'sealed rev0103 whole-product tree retained','status':'pass'},
 {'id':'shared-source-note-audit','scope':'one Extension core audit shared by everyday private transfer and Workbench backup','status':'focused-pass'},
 {'id':'workbench-private-backup','scope':'managed Chromium-source and generated-Firefox shipped Workbench path; 10 checks per variant','status':'focused-pass'},
 {'id':'runtime-catalog-binding','scope':'18 cases; session v5/result v3; fresh rev0104 preparation required','status':'pass'},
 {'id':'complete-offline-regression','scope':f"{cli_tests} CLI tests, {ext_static} Extension static tests, {status.get('managedNodeHarnessInvocations',0)} managed Node/product harness invocations, {status.get('managedWorkbenchUiPathVariants',0)} Workbench/Lineage variants, {status.get('managedWorkbenchPrivateBackupUiPathVariants',0)} Workbench private-backup variants, {status.get('managedSharedFolderMergeUiPathVariants',0)} shared-folder merge variants, complete Extension runner, {evidence_tests} evidence tests",'status':'pass' if regression_pass else 'pending'},
 {'id':'deterministic-seal','status':'external-postbuild-report-required'},
 {'id':'unmanaged-current-chromium','status':'not-run'}, {'id':'firefox-release','status':'not-run'}, {'id':'firefox-esr','status':'not-run'},
 {'id':'unfamiliar-curators-and-recipients','status':'not-run'}, {'id':'separate-sender-recipient-diagnostic-privacy','status':'not-run'}, {'id':'real-assistive-technologies','status':'not-run'}]
runtime={'revision':REV,'releaseGateClosed':False,'inheritedEvidence':'Earlier records retain their original identities and scopes; exact rev0104 product bytes require fresh target-host sessions.','rows':runtime_rows}
dump('SOURCE-NOTES-RUNTIME-MATRIX.json',runtime); dump('RUNTIME-MATRIX.json',runtime)
runtime_md='# Runtime and release matrix — rev0104\n\n| Row | Scope | Status |\n|---|---|---|\n'+'\n'.join(f"| `{r['id']}` | {r.get('scope','')} | **{r['status'].upper()}** |" for r in runtime_rows)+'\n\nThe release gate remains open. Managed automation and deterministic packaging do not establish current-browser, human, privacy, assistive-technology, or accessibility acceptance.\n'
write('SOURCE-NOTES-RUNTIME-MATRIX.md',runtime_md); write('RUNTIME-MATRIX.md',runtime_md)

write('SOURCE-NOTES-RUNTIME-PROTOCOL.md',f'''# Source Notes runtime protocol — rev0104

- Revision: `{REV}`
- Fixed behavior catalog: 18 cases
- Session schema: v5
- Result/predicate schema: v3
- Prepare a fresh session on each target host from the exact immutable Roadcase.
- Preserve first failures, interruptions, retries, and recovery; do not record only the final successful state.
- `two-folder-independence` includes the Advanced Workbench **Private backup** path: valid route-specific reasons and absence round-trip exactly, and malformed local Source Note state is refused before download without a write or network request.
- Earlier revision records must not be relabeled.
- Finalized evidence remains unsigned consistency evidence, not authenticated operator, human-presence, unmanaged-environment, accessibility, or comprehension proof.
''')
write('RUNTIME-OPERATOR-GUIDE.md',f'''# Runtime operator guide — rev0104

Use only the exact sealed `{REV}` Roadcase and prepare fresh session-v5 records on the execution host. Capture fresh official browser-channel evidence, actual browser version, operating-system build, profile state, and installation method.

Run all 18 cases. In `two-folder-independence`, create a valid Workbench private backup from the current in-memory library and confirm two route-specific reasons plus one absence remain exact. Then exercise all nine malformed forms and confirm each is refused before download with no vault write, network request, or permission request. Retain every inherited Reader, Node, Exchange, private-transfer, Workbench, Lineage, repair, conflict, Undo, publication, OPML, integrity, restart, and permission-observation step.

Record first failures, interruptions, retries, and recovery. Firefox temporary loading must remain separately classified from signed-install and restart conclusions.
''')
write('SOURCE-NOTES-RUNTIME-ATTESTATION.md',f'''# Runtime attestation boundary — rev0104

Runtime evidence is unsigned consistency evidence. It binds result records, referenced evidence, package bytes, fixture bytes, and native artifacts to one prepared session and Roadcase. It does not authenticate the operator, wall clock, browser download service, human presence, unmanaged state, permission comprehension, accessibility, or participant understanding. Release acceptance still requires direct review of target-host records and separate fieldwork.
''')

write('ROADCASE-SOURCE-NOTES-CHECKLIST.md',f'''# Source Notes checklist — rev0104

## Native and shipped paths

- [x] One optional reason per direct folder/source placement; 280-code-point limit and Unicode-scalar validation.
- [x] Python/JavaScript validation parity; native canonicalization and integrity.
- [x] CLI, Node, Extension, publication, Lineage, Workbench collection, Exchange, private-transfer, repair, branch, conflict, OPML, and Undo coverage.
- [x] Advanced Workbench Private backup uses the shared fail-closed audit before download.
- [x] Valid route-specific reasons and absence are preserved exactly.
- [x] Nine malformed local forms refuse without download, write, network, permission, or silent normalization.

## Release gates still open

- [ ] Exact immutable package in unmanaged then-current Chromium Stable.
- [ ] Exact generated sibling in Firefox Release and Firefox ESR.
- [ ] Unfamiliar curator and recipient comprehension.
- [ ] Separate sender, recipient, and diagnostic privacy review.
- [ ] Screen reader, refreshable Braille, voice control, switch control, high zoom/reflow, forced colors, reduced motion, fatigue, and interruption sessions.
''')

bootstrap=f'''# BOOTSTRAPROSE — current `/run` authority

**Candidate:** `{REV}` · **Date:** {DATE} · **Product lineage:** rev0080 / 0.80.0.

## Authority and lineage

This tree continues the sealed rev0103 unified candidate and corrects one reproduced Advanced Workbench private-backup validation bypass. It does not represent rev0081, rev0082, or the undelivered browser-execution-binding source archive as recovered.

- Immediate parent: `{PARENT}` · `{PARENT_SHA}`
- The parent’s unified private-transfer, Exchange, Node branch/merge, shared-folder merge, publication, Lineage, Workbench collection, repair, concurrency, Undo, native-integrity, and runtime-record corrections remain present.
- The release gate remains open. Managed tests and deterministic archives do not substitute for target-host browsers, unfamiliar people, privacy review, or real assistive technologies.

## P0.0 — completed in this candidate

- Reproduce the shipped failure: Advanced Workbench downloaded a private backup containing a 281-code-point direct-placement reason.
- Add one shared Extension Source Note audit and delegate the everyday private-transfer path to it.
- Audit Workbench’s current in-memory library before download, preserving unsaved Workbench state without a background-state race.
- Preserve valid two-folder reasons, multiline/Unicode text, and explicit absence exactly.
- Refuse over-limit, wrong-level, folder-member, duplicate, empty, edge-whitespace, non-string, invalid-Unicode, and missing-source forms before download.
- Perform no vault write, network request, permission request, or silent repair on refusal.
- Keep Chromium-source and generated-Firefox product bytes aligned.
- Add no permission, persistent store, network authority, account, schedule, notification, ranking, profile, reaction, comment, or messaging capability.
- Keep the fixed runtime catalog at 18 cases by extending `two-folder-independence`.

## P0.1 — exact package on the actual browser triad

Run fresh rev0104 session-v5 records from the sealed candidate in unmanaged then-current Chromium Stable, Firefox Release, and Firefox ESR. Capture fresh official channel evidence on each host. Do not relabel earlier sessions.

Run all 18 cases and every inherited whole-product boundary. In `two-folder-independence`, explicitly prove:

- One source has different reasons in two direct folders and a third placement has no reason.
- Advanced Workbench’s Private backup preserves those exact values from the current in-memory library.
- The success status reports the exact curator-written folder-reason count.
- Every malformed local Source Note form is refused before download.
- Refusal causes no vault write, network request, permission request, silent normalization, or partial file.

Retain every inherited Reader, Node, Exchange, private-transfer, Capture, Witness, Pulse, Trace, Workbench collection, Lineage, repair, conflict, stale-write, saturated-concurrency, whole-placement Undo, publication, OPML, integrity, restart, and permission-observation check. Preserve first failures, interruptions, retries, and recovery.

Firefox temporary loading remains development-runtime evidence and must not be interpreted as signed-install or restart acceptance.

## P0.2 — unfamiliar people, privacy, and real assistive technologies

Only after the exact browser triad passes:

- Ask unfamiliar people what a Workbench private backup contains and whether refusal created any file.
- Ask which folder relationship each reason belongs to, who wrote it, and whether it is a safety claim.
- Ask whether backup, restore, preview, or Undo published anything, contacted anyone, or created a schedule.
- Compare sender, recipient, and diagnostic privacy evidence separately.
- Run distinct screen-reader, refreshable-Braille, voice-control, switch-control, high-zoom/reflow, forced-colors, reduced-motion, fatigue, and interruption sessions.
- Make only the smallest correction supported by recurring independent wrong turns.

## P1 — sharing and organization

- Test one-week delayed route re-finding before adding private labels or saved-view complexity.
- Keep folders human-curated and shareable; preserve **Unfiled** as legitimate.
- Keep Source Note wording out of engagement ranking and opaque recommendation systems.
- Do not expand Source Notes into comments, reactions, profiles, or notifications.

## P2 — remote Nodes

- Keep remote mode explicit and separate from loopback.
- Require TLS, persistent Node identity, bounded hosts/requests/artifacts/rates, expiring invitations, and durable revocation evidence.
- Keep public publication routes separate from private APIs.
- No default public bind, silent LAN discovery, or UPnP.

## Lab — WebRTC courier

- Transfer exactly one reviewed immutable artifact; preserve Source Notes through it.
- Make signaling, STUN, and TURN visible; refuse replay, identity/digest mismatch, timeout, and partial completion.
- Destroy the bounded session afterward.
- Never require WebRTC for ordinary reading, sharing, Source Notes, Capture, Witness, or Pulse.

## Stop conditions

- Do not add another evidence layer merely because target-host access is unavailable.
- Do not claim installed-browser, human, privacy, assistive-technology, or accessibility acceptance from managed automation.
- Make another product change only for a reproduced failure.
'''
write('BOOTSTRAPROSE.md',bootstrap)

summary=f'''# Result summary — rev0104 Workbench private-backup integrity

The sealed rev0103 parent exported malformed Source Notes from Advanced Workbench’s Private backup without the unified transfer audit. rev0104 shares one fail-closed Extension audit between the everyday transfer path and Workbench backup, preserves valid current in-memory state exactly, and refuses nine malformed forms before download without writing or networking.

Focused managed replay passed 10 checks in each Chromium-source and generated-Firefox package. Complete inherited regression is **{'PASS' if regression_pass else 'PENDING'}**. The fixed runtime catalog remains 18 cases. Exact target-host browser, unfamiliar-person, privacy, and assistive-technology acceptance remain open.
'''
write('RESULT-SUMMARY.md',summary)
write('CURRENT-STATUS.md',summary)
write('HANDOFF.md',f'''# Handoff — {REV}

## Current authority

`BOOTSTRAPROSE.md` is the `/run` authority. Immediate parent: `{PARENT}` (`{PARENT_SHA}`).

## Reproduced and corrected

The parent Advanced Workbench Private backup exported a 281-code-point placement reason. rev0104 uses one shared Extension audit for everyday private transfer and Workbench backup. The Workbench validates its current in-memory state before download; valid two-folder reasons and absence remain exact, while nine malformed forms refuse without download, write, network, permission, or silent repair.

## Next exact work

Seal the deterministic Roadcase, then run fresh rev0104 18-case and whole-product sessions on actual unmanaged then-current Chromium, Firefox Release, and Firefox ESR hosts. The `two-folder-independence` case must include valid and malformed Workbench Private backup steps. After the triad passes, perform unfamiliar-person, separate privacy, and real assistive-technology fieldwork.

Do not add another evidence layer merely because target-host access is unavailable. Further product changes require a reproduced failure.
''')

state={'schema':'progrss.revision-state.v1','revision':REV,'date':DATE,'productLineage':{'revision':'rev0080','version':'0.80.0'},'parent':{'name':PARENT,'sha256':PARENT_SHA,'bytes':PARENT_BYTES},'classification':'reproduced Advanced Workbench private-backup Source Note validation bypass correction; exact target-host acceptance open','releaseGateClosed':False,'nextP0':'Seal the deterministic candidate, then run fresh rev0104 18-case and whole-product sessions on actual unmanaged then-current Chromium, Firefox Release, and Firefox ESR hosts, including valid and malformed Advanced Workbench Private backup; then separate human, privacy, and assistive-technology fieldwork.','checks':{'behaviorCatalog':{'revision':REV,'cases':18,'freshSessionPreparationRequired':True,'status':'pass'},'workbenchPrivateBackup':{'browserPackageVariants':2,'checksPerVariant':10,'malformedFormsPerVariant':9,'status':'focused-pass'},'offlineRegressions':{'cliModules':15,'cliTests':cli_tests,'extensionStaticTests':ext_static,'managedNodeHarnessInvocations':status.get('managedNodeHarnessInvocations',0),'managedWorkbenchUiPathVariants':status.get('managedWorkbenchUiPathVariants',0),'managedWorkbenchPrivateBackupUiPathVariants':status.get('managedWorkbenchPrivateBackupUiPathVariants',0),'managedSharedFolderMergeUiPathVariants':status.get('managedSharedFolderMergeUiPathVariants',0),'runtimeRecordAndComparisonTests':evidence_tests,'runtimeEvidenceRevisionBinding':REV,'status':'pass' if regression_pass else 'pending'},'productContinuity':{**continuity['counts'],'permissionsExpanded':False,'status':'pass'},'deterministicBuild':{'status':'requires-detached-post-build-report'}},'claims':{'productChanged':True,'cliChanged':False,'extensionChanged':True,'permissionsExpanded':False,'newPersistentStore':False,'newNetworkAuthority':False,'installedBrowserRuntimeThisTurn':False,'unmanagedChromiumRuntime':False,'firefoxReleaseRuntime':False,'firefoxEsrRuntime':False,'humanPermissionPromptObservation':False,'unfamiliarParticipantFieldwork':False,'privacyComprehensionFieldwork':False,'assistiveTechnologyFieldwork':False,'accessibilityConformance':False,'policyModified':False,'rev0081OrRev0082Recovered':False,'browserRenderingThisTurn':True,'browserRenderingScope':'managed shipped Advanced Workbench and inherited managed regression smoke only'}}
dump('REVISION-STATE.json',state)
write('BUILD-REPORT.md',f'''# Pre-seal build status — rev0104

- Revision binding: PASS
- Focused Workbench private-backup replay: PASS (2 package variants × 10 checks)
- Product continuity against rev0103: PASS
- Complete regression: {'PASS' if regression_pass else 'PENDING'}
- Deterministic Roadcase seal: pending external build
- Exact target-host browser triad: NOT RUN
- Human, privacy, and real assistive-technology fieldwork: NOT RUN
''')
print(json.dumps({'revision':REV,'regressionPass':regression_pass,'cliTests':cli_tests,'extensionStaticTests':ext_static,'evidenceTests':evidence_tests},sort_keys=True))
