#!/usr/bin/env python3
"""Fail-closed Source Notes runtime evidence helpers for rev0101.

The module binds a runtime result to one prepared session, immutable Roadcase,
selected browser package, fixture, and explicit evidence files.  It emits an
unsigned in-toto Statement-shaped record.  The record is not a signature,
identity proof, SLSA level, accessibility result, or participant-comprehension
claim.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tempfile
from typing import Any, Iterable, Mapping
import zipfile

from runtime_native_artifacts import NativeArtifactError, derive_native_artifact

from browser_channel_evidence import (
    CHANNEL_SNAPSHOT_NAME,
    CHANNEL_SNAPSHOT_SCHEMA,
    CHROME_SOURCE_NAME,
    FIREFOX_SOURCE_NAME,
    MAX_CHANNEL_SNAPSHOT_AGE_SECONDS,
    ChannelEvidenceError,
    expected_version as channel_expected_version,
    parse_utc as parse_channel_utc,
    session_record as channel_session_record,
    validate_snapshot_payloads,
)

REVISION = "rev0106-relay-workspace-source-note-integrity"
SESSION_SCHEMA = "progrss.source-notes.runtime-session.v5"
CASE_CATALOG_SCHEMA = "progrss.source-notes.runtime-cases.v1"
RESULT_SCHEMA = "progrss.source-notes.runtime-result.v3"
EVIDENCE_MANIFEST_SCHEMA = "progrss.source-notes.runtime-evidence-manifest.v1"
PREDICATE_TYPE = "urn:progrss:predicate:source-notes-runtime:v3"
IN_TOTO_STATEMENT_TYPE = "https://in-toto.io/Statement/v1"
FIXED_ZIP_TIME = (2026, 10, 22, 0, 0, 0)
MAX_EVIDENCE_FILE_BYTES = 128 * 1024 * 1024
MAX_EVIDENCE_TOTAL_BYTES = 512 * 1024 * 1024
MAX_BUNDLE_MEMBERS = 4096
MAX_METADATA_FILE_BYTES = 2 * 1024 * 1024
MAX_BUNDLE_TOTAL_BYTES = MAX_EVIDENCE_TOTAL_BYTES + 32 * 1024 * 1024
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
UTC_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")
ALLOWED_STATUSES = {"pass", "fail", "blocked", "not-run"}

SESSION_KEYS = frozenset({
    "schema", "revision", "sessionId", "status", "preparedOnly", "roadcase", "package",
    "fixture", "browser", "environment", "channelEvidence", "caseCatalogSha256",
    "resultTemplateSha256", "claimBoundary",
})
ROADCASE_KEYS = frozenset({"name", "bytes", "sha256", "manifestRevision"})
PACKAGE_KEYS = frozenset({"family", "directory", "files", "subtreeSha256", "manifestSha256"})
FIXTURE_KEYS = frozenset({"path", "bytes", "sha256"})
BROWSER_KEYS = frozenset({"family", "channel", "version", "installMethod"})
ENVIRONMENT_KEYS = frozenset({"class", "profileState", "permissionObservation", "osBuild", "operatorNote"})
CHANNEL_EVIDENCE_KEYS = frozenset({
    "schema", "snapshotPath", "snapshotBytes", "snapshotSha256", "capturedUtc",
    "maxAgeSeconds", "sources",
})
CHANNEL_SOURCE_KEYS = frozenset({"path", "url", "bytes", "sha256"})
RESULT_KEYS = frozenset({
    "schema", "revision", "sessionId", "status", "startedUtc", "finishedUtc",
    "browserObserved", "operatorObservation", "permissionObservation", "operatorAssertions",
    "cases", "nativeArtifacts", "events",
})
BROWSER_OBSERVED_KEYS = frozenset({
    "version", "channel", "osBuild", "profileState", "installMethod", "enterprisePolicy",
})
OPERATOR_OBSERVATION_KEYS = frozenset({"mode", "completed", "statementAccepted", "note"})
PERMISSION_OBSERVATION_KEYS = frozenset({"mode", "installPrompt", "before", "after", "notes"})
PERMISSION_PROJECTION_KEYS = frozenset({
    "permissions", "optional_permissions", "host_permissions", "optional_host_permissions",
})
OPERATOR_ASSERTION_KEYS = frozenset({
    "exactPreparedPackageUsed", "freshProfileAtStart", "sameProfileRestarted",
    "unmanagedEnvironment", "currentChannelAtExecution", "humanPermissionObservation",
})
CASE_RESULT_KEYS = frozenset({"id", "status", "recordedUtc", "observed", "evidence"})
EVENT_REQUIRED_KEYS = frozenset({"kind", "recordedUtc", "message"})
EVENT_OPTIONAL_KEYS = frozenset({"evidencePath"})
NATIVE_ARTIFACT_NAMES = frozenset({"completeRoute", "selectedBranch"})
NATIVE_ARTIFACT_KEYS = frozenset({"evidencePath", "bytes", "sha256", "semanticProjectionSha256"})


class EvidenceError(ValueError):
    """Raised when a runtime evidence boundary is violated."""


@dataclass(frozen=True)
class FinalizedEvidence:
    status: str
    evidence_rows: list[dict[str, Any]]
    manifest: dict[str, Any]
    manifest_bytes: bytes
    attestation: dict[str, Any]
    attestation_bytes: bytes


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_json_bytes(value: Any, *, pretty: bool = True) -> bytes:
    if pretty:
        text = json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n"
    else:
        text = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
    return text.encode("utf-8")


def decode_json_object(data: bytes, label: str) -> dict[str, Any]:
    def unique_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for key, value in pairs:
            if key in out:
                raise EvidenceError(f"{label}: duplicate JSON key: {key}")
            out[key] = value
        return out

    def reject_constant(value: str) -> None:
        raise EvidenceError(f"{label}: non-finite JSON number: {value}")

    try:
        value = json.loads(data.decode("utf-8"), object_pairs_hook=unique_pairs, parse_constant=reject_constant)
    except (UnicodeError, json.JSONDecodeError, RecursionError) as error:
        raise EvidenceError(f"{label}: invalid UTF-8 JSON: {error}") from error
    if not isinstance(value, dict):
        raise EvidenceError(f"{label}: expected a JSON object")
    return value


def read_json(path: Path) -> dict[str, Any]:
    try:
        return decode_json_object(path.read_bytes(), str(path))
    except OSError as error:
        raise EvidenceError(f"cannot read JSON from {path}: {error}") from error


def require_text(value: Any, label: str, *, max_length: int = 4000, allow_empty: bool = False) -> str:
    if not isinstance(value, str):
        raise EvidenceError(f"{label} must be a string")
    if not allow_empty and not value.strip():
        raise EvidenceError(f"{label} must not be empty")
    if len(value) > max_length:
        raise EvidenceError(f"{label} exceeds {max_length} characters")
    return value


def require_exact_keys(value: Mapping[str, Any], expected: frozenset[str], label: str) -> None:
    actual = set(value)
    missing = sorted(expected - actual)
    extra = sorted(actual - expected)
    if missing or extra:
        raise EvidenceError(f"{label} keys are invalid; missing={missing}; extra={extra}")


def require_utc(value: Any, label: str, *, allow_empty: bool = False) -> str:
    text = require_text(value, label, max_length=20, allow_empty=allow_empty)
    if not text and allow_empty:
        return text
    if not UTC_RE.fullmatch(text):
        raise EvidenceError(f"{label} must use YYYY-MM-DDTHH:MM:SSZ")
    try:
        parse_channel_utc(text, label)
    except (ChannelEvidenceError, ValueError) as error:
        raise EvidenceError(str(error)) from error
    return text


def utc_value(value: str, label: str):
    try:
        return parse_channel_utc(value, label)
    except (ChannelEvidenceError, ValueError) as error:
        raise EvidenceError(str(error)) from error


def validate_permission_projection(value: Any, label: str) -> None:
    if not isinstance(value, Mapping):
        raise EvidenceError(f"{label} must be an object")
    if not value:
        return
    require_exact_keys(value, PERMISSION_PROJECTION_KEYS, label)
    for key in sorted(PERMISSION_PROJECTION_KEYS):
        items = value.get(key)
        if not isinstance(items, list):
            raise EvidenceError(f"{label}.{key} must be a list")
        seen: set[str] = set()
        for index, item in enumerate(items):
            text = require_text(item, f"{label}.{key}[{index}]", max_length=2000)
            if text in seen:
                raise EvidenceError(f"{label}.{key} contains a duplicate value: {text}")
            seen.add(text)


def safe_relative_path(value: Any, label: str) -> str:
    text = require_text(value, label, max_length=512)
    path = PurePosixPath(text)
    if path.is_absolute() or ".." in path.parts or text.startswith("./") or "\\" in text:
        raise EvidenceError(f"{label} must be a normalized relative POSIX path")
    normalized = path.as_posix()
    if normalized != text or normalized in {"", "."}:
        raise EvidenceError(f"{label} must be a normalized relative POSIX path")
    return normalized


def canonical_mode(path: Path) -> int:
    mode = stat.S_IMODE(path.lstat().st_mode)
    return 0o755 if mode & 0o111 else 0o644


def canonical_archive_mode(raw_mode: int) -> int:
    return 0o755 if stat.S_IMODE(raw_mode) & 0o111 else 0o644


def session_configuration_digest(
    browser: Mapping[str, Any],
    environment: Mapping[str, Any],
    channel_evidence: Mapping[str, Any],
) -> str:
    payload = {
        "browser": dict(browser),
        "environment": dict(environment),
        "channelEvidence": dict(channel_evidence),
    }
    return sha256_bytes(canonical_json_bytes(payload, pretty=False))


def expected_session_id(session: Mapping[str, Any]) -> str:
    roadcase = session.get("roadcase", {})
    package = session.get("package", {})
    browser = session.get("browser", {})
    environment = session.get("environment", {})
    channel_evidence = session.get("channelEvidence", {})
    roadcase_digest = str(roadcase.get("sha256", ""))
    family = str(package.get("family", ""))
    config_digest = session_configuration_digest(browser, environment, channel_evidence)
    return f"{REVISION}-{family}-{roadcase_digest[:12]}-{config_digest[:12]}"


def _roadcase_package_relative(name: str, family: str) -> str | None:
    prefix = "Extension/Firefox/" if family == "firefox" else "Extension/"
    if not name.startswith(prefix):
        return None
    relative = name[len(prefix):]
    if not relative or relative.endswith("/"):
        return None
    path = PurePosixPath(relative)
    if path.is_absolute() or ".." in path.parts:
        raise EvidenceError(f"unsafe Roadcase package member: {name}")
    if path.name == ".DS_Store" or path.suffix == ".pyc" or "__pycache__" in path.parts:
        return None
    return path.as_posix()


def roadcase_package_inventory(roadcase: Path, family: str) -> list[dict[str, Any]]:
    if family not in {"chromium", "firefox"}:
        raise EvidenceError(f"unsupported runtime package family: {family!r}")
    rows: list[dict[str, Any]] = []
    with zipfile.ZipFile(roadcase) as archive:
        for info in sorted(archive.infolist(), key=lambda value: value.filename):
            if info.is_dir():
                continue
            relative = _roadcase_package_relative(info.filename, family)
            if relative is None:
                continue
            raw_mode = (info.external_attr >> 16) & 0xFFFF
            if stat.S_ISLNK(raw_mode):
                raise EvidenceError(f"Roadcase runtime package contains a symlink: {info.filename}")
            data = archive.read(info)
            rows.append({
                "path": relative,
                "mode": oct(canonical_archive_mode(raw_mode)),
                "bytes": len(data),
                "sha256": sha256_bytes(data),
            })
    if not rows or not any(row["path"] == "manifest.json" for row in rows):
        raise EvidenceError(f"Roadcase contains no {family} runtime manifest")
    return rows


def case_catalog() -> dict[str, Any]:
    cases = [
        ("package-identity", "Verify Roadcase, package, manifest, and fixture identity before installation."),
        ("install-and-permission-observation", "Record installation method, policy state, and every displayed permission consequence or its documented absence."),
        ("cancel-and-escape-no-write", "Cancel and Escape leave the reviewed placement unchanged."),
        ("consequence-disclosure", "The editor states that the change is local, publishes nothing, contacts nobody, creates no schedule, and makes no safety claim."),
        ("two-folder-independence", "One source keeps different reasons on two direct folder placements. Advanced Workbench edits preserve selected placement reasons by source identity, leave independent folders unchanged, give newly selected sources no invented reason, and refuse conflicting or invalid prior placements without mutation. Publishing and adopting the first Lineage edition preserves every direct-placement reason; one-sided and identical later edition changes merge without a false conflict. Same-source repair preserves one-sided or identical reasons, keeps separate folders independent, and refuses different nonempty reasons on one folder without an automatic winner. The ready-to-host HTML page shows each selected placement reason beside the correct folder route, including two different reasons for the same source, while the native JSON remains authoritative and OPML still omits reasons. A private library transfer preview, restore, export, copy-check, and guarded Undo preserve the same two reasons exactly; malformed, wrong-level, duplicate, empty, noncanonical, missing-source, and invalid-Unicode reason placements are refused before any write. The Advanced Workbench Private backup control applies the same audit to its current in-memory library: a valid backup preserves both route-specific reasons and an absent reason exactly, while malformed local Source Note state is refused before download without a vault write or network request. The loopback Node applies the same audit before both transactional `node init` storage and read-only `node serve BACKUP` use: valid route-specific reasons remain byte-exact, while every malformed form is refused before a SQLite library is created or a backup is served. The Relay workspace commands apply the same audit before share, publish, import, review, explicit publication checks, or updates: valid route-specific reasons remain exact, while malformed private state is refused before output or any explicit network request."),
        ("clear-and-guarded-undo", "Clear removes the field and guarded undo restores only the reviewed value. Removing a direct folder placement and undoing it restores its reason and original position; adding a direct placement and undoing it removes only that unchanged placement. Newer changes refuse either undo."),
        ("unicode-boundary", "280 Unicode code points save and 281 are refused."),
        ("ordinary-interruption-preserves-draft-and-focus", "An ordinary library update preserves the draft and expected focus without an unintended write."),
        ("two-view-stale-save-refused", "A stale save from a second live view is refused while newer wording remains; at the folder-version ceiling, a removed-and-recreated placement with the same reason is still treated as stale."),
        ("two-view-stale-undo-refused", "A stale initial folder-removal action, guarded Source Note undo, and folder-add undo are refused after newer work. At the folder-version ceiling, none can act on a removed-and-recreated placement even when its wording matches."),
        ("permission-state-unchanged", "Required, optional, host, and optional-host permission state is unchanged across the scenario."),
        ("restart-persistence", "The same profile preserves independent placement reasons after a real browser restart."),
        ("complete-route-disclosure", "The complete native route preserves every reason-bearing placement and native integrity evidence. Its ready-to-host HTML recipient page discloses each direct placement reason with curator authorship, non-safety-claim wording, safe escaping, natural text direction, and no invented reason when absent. Before one Exchange handoff is created or used, the shipped Node sender review and Extension recipient three-door review disclose the exact curator-reason count and each reason beside its direct folder route, while stating that the wording is not a ProgRSS safety claim."),
        ("selected-branch-preservation", 'The selected branch preserves in-branch reasons and omits out-of-branch reasons. Before the Node-owned branch write, the shipped branch chooser reports the optional reason count and the exact preview shows every reason beside its direct folder route, with curator attribution, non-safety wording, literal multiline or markup-like text, and automatic text direction. The Exchange branch choice reports its reason count before opening the ordinary selected-branch review. The committed native library retains the reviewed placement values.'),
        ("opml-omission-evidence", "OPML contains no Source Note value/private attribute and reports exact omitted placements."),
        ("native-integrity-refuses-reason-mutation", "Changing a reason after digest creation causes native integrity refusal."),
        ("divergent-later-copy-keep-mine", "A divergent Lineage edition reason and a divergent later copy each remain unresolved until Keep mine is selected for the displayed placement. The read-only Node review distinguishes same-source conflicts by the full direct folder route, preserves literal multiline and bidirectional reason text, states the curator/non-safety boundary, and labels the local value Keep mine. The Extension shared-folder update review also distinguishes same-source conflicts by the full canonical folder route, preserves literal multiline and bidirectional reason text, states the curator/non-safety boundary, and keeps each placement choice independent."),
        ("divergent-later-copy-use-curator", "A separate divergent Lineage edition reason and later-copy conflict each remain unresolved until Use curator’s is selected for the displayed placement. A separate Node review shows the same placement-scoped evidence and labels the incoming value Use curator’s without applying either choice. A separate Extension shared-folder update review shows the same route-scoped evidence and incoming Use curator’s value without applying either decision until every conflict is resolved."),
    ]
    return {
        "schema": CASE_CATALOG_SCHEMA,
        "revision": REVISION,
        "cases": [
            {
                "id": case_id,
                "required": True,
                "description": description,
                "allowedStatuses": sorted(ALLOWED_STATUSES),
            }
            for case_id, description in cases
        ],
    }


def result_template(session: Mapping[str, Any], catalog: Mapping[str, Any] | None = None) -> dict[str, Any]:
    catalog = catalog or case_catalog()
    return {
        "schema": RESULT_SCHEMA,
        "revision": REVISION,
        "sessionId": session.get("sessionId", ""),
        "status": "not-run",
        "startedUtc": "",
        "finishedUtc": "",
        "browserObserved": {
            "version": "",
            "channel": session.get("browser", {}).get("channel", ""),
            "osBuild": session.get("environment", {}).get("osBuild", ""),
            "profileState": session.get("environment", {}).get("profileState", ""),
            "installMethod": session.get("browser", {}).get("installMethod", ""),
            "enterprisePolicy": "unknown",
        },
        "operatorObservation": {
            "mode": "automated" if session.get("environment", {}).get("class") == "managed" else "human",
            "completed": False,
            "statementAccepted": False,
            "note": "",
        },
        "permissionObservation": {
            "mode": session.get("environment", {}).get("permissionObservation", "none"),
            "installPrompt": "not-observed",
            "before": {},
            "after": {},
            "notes": "",
        },
        "operatorAssertions": {
            "exactPreparedPackageUsed": False,
            "freshProfileAtStart": False,
            "sameProfileRestarted": False,
            "unmanagedEnvironment": False,
            "currentChannelAtExecution": False,
            "humanPermissionObservation": False,
        },
        "cases": [
            {
                "id": row["id"],
                "status": "not-run",
                "recordedUtc": "",
                "observed": "",
                "evidence": [],
            }
            for row in catalog.get("cases", [])
        ],
        "nativeArtifacts": {},
        "events": [],
    }


def validate_session(session: Mapping[str, Any]) -> None:
    require_exact_keys(session, SESSION_KEYS, "SESSION.json")
    if session.get("schema") != SESSION_SCHEMA:
        raise EvidenceError(f"SESSION.json schema must be {SESSION_SCHEMA}")
    if session.get("revision") != REVISION:
        raise EvidenceError(f"SESSION.json revision must be {REVISION}")
    require_text(session.get("sessionId"), "SESSION.json sessionId", max_length=240)
    if session.get("status") != "prepared" or session.get("preparedOnly") is not True:
        raise EvidenceError("SESSION.json must remain a prepared-only session")
    roadcase = session.get("roadcase")
    package = session.get("package")
    fixture = session.get("fixture")
    browser = session.get("browser")
    environment = session.get("environment")
    channel_evidence = session.get("channelEvidence")
    if not all(isinstance(row, Mapping) for row in (roadcase, package, fixture, browser, environment, channel_evidence)):
        raise EvidenceError(
            "SESSION.json must contain roadcase, package, fixture, browser, environment, and channelEvidence objects"
        )
    require_exact_keys(roadcase, ROADCASE_KEYS, "SESSION.json roadcase")
    require_exact_keys(package, PACKAGE_KEYS, "SESSION.json package")
    require_exact_keys(fixture, FIXTURE_KEYS, "SESSION.json fixture")
    require_exact_keys(browser, BROWSER_KEYS, "SESSION.json browser")
    require_exact_keys(environment, ENVIRONMENT_KEYS, "SESSION.json environment")
    require_exact_keys(channel_evidence, CHANNEL_EVIDENCE_KEYS, "SESSION.json channelEvidence")

    roadcase_name = require_text(roadcase.get("name"), "SESSION.json roadcase.name", max_length=240)
    if PurePosixPath(roadcase_name).name != roadcase_name or not roadcase_name.endswith(".zip"):
        raise EvidenceError("SESSION.json roadcase.name must be a ZIP basename")
    if type(roadcase.get("bytes")) is not int or roadcase.get("bytes") <= 0:
        raise EvidenceError("SESSION.json roadcase.bytes must be a positive integer")
    if not isinstance(roadcase.get("sha256"), str) or not SHA256_RE.fullmatch(roadcase["sha256"]):
        raise EvidenceError("SESSION.json roadcase digest is invalid")
    if roadcase.get("manifestRevision") != REVISION:
        raise EvidenceError("SESSION.json roadcase.manifestRevision is invalid")

    if package.get("family") not in {"chromium", "firefox"}:
        raise EvidenceError("SESSION.json package.family is invalid")
    safe_relative_path(package.get("directory"), "SESSION.json package.directory")
    if type(package.get("files")) is not int or package.get("files") <= 0:
        raise EvidenceError("SESSION.json package.files must be a positive integer")
    for key in ("subtreeSha256", "manifestSha256"):
        if not isinstance(package.get(key), str) or not SHA256_RE.fullmatch(package[key]):
            raise EvidenceError(f"SESSION.json package.{key} is invalid")

    safe_relative_path(fixture.get("path"), "SESSION.json fixture.path")
    if type(fixture.get("bytes")) is not int or fixture.get("bytes") <= 0:
        raise EvidenceError("SESSION.json fixture.bytes must be a positive integer")
    if not isinstance(fixture.get("sha256"), str) or not SHA256_RE.fullmatch(fixture["sha256"]):
        raise EvidenceError("SESSION.json fixture digest is invalid")

    if browser.get("family") != package.get("family"):
        raise EvidenceError("SESSION.json browser family must match package family")
    for key in ("channel", "version", "installMethod"):
        require_text(browser.get(key), f"SESSION.json browser.{key}", max_length=1000)

    if channel_evidence.get("schema") != CHANNEL_SNAPSHOT_SCHEMA:
        raise EvidenceError("SESSION.json channelEvidence.schema is invalid")
    if channel_evidence.get("snapshotPath") != CHANNEL_SNAPSHOT_NAME:
        raise EvidenceError("SESSION.json channelEvidence.snapshotPath is invalid")
    if type(channel_evidence.get("snapshotBytes")) is not int or channel_evidence.get("snapshotBytes") <= 0:
        raise EvidenceError("SESSION.json channelEvidence.snapshotBytes must be positive")
    if not isinstance(channel_evidence.get("snapshotSha256"), str) or not SHA256_RE.fullmatch(
        channel_evidence["snapshotSha256"]
    ):
        raise EvidenceError("SESSION.json channelEvidence.snapshotSha256 is invalid")
    require_utc(channel_evidence.get("capturedUtc"), "SESSION.json channelEvidence.capturedUtc")
    if channel_evidence.get("maxAgeSeconds") != MAX_CHANNEL_SNAPSHOT_AGE_SECONDS:
        raise EvidenceError("SESSION.json channelEvidence.maxAgeSeconds is invalid")
    sources = channel_evidence.get("sources")
    if not isinstance(sources, list) or len(sources) != 2:
        raise EvidenceError("SESSION.json channelEvidence.sources must contain two source rows")
    expected_source_paths = {CHROME_SOURCE_NAME, FIREFOX_SOURCE_NAME}
    observed_source_paths: set[str] = set()
    for index, row in enumerate(sources):
        if not isinstance(row, Mapping):
            raise EvidenceError(f"SESSION.json channelEvidence.sources[{index}] must be an object")
        require_exact_keys(row, CHANNEL_SOURCE_KEYS, f"SESSION.json channelEvidence.sources[{index}]")
        path = safe_relative_path(row.get("path"), f"SESSION.json channelEvidence.sources[{index}].path")
        observed_source_paths.add(path)
        require_text(row.get("url"), f"SESSION.json channelEvidence.sources[{index}].url", max_length=1000)
        if type(row.get("bytes")) is not int or row.get("bytes") <= 0:
            raise EvidenceError(f"SESSION.json channelEvidence.sources[{index}].bytes must be positive")
        if not isinstance(row.get("sha256"), str) or not SHA256_RE.fullmatch(row["sha256"]):
            raise EvidenceError(f"SESSION.json channelEvidence.sources[{index}].sha256 is invalid")
    if observed_source_paths != expected_source_paths:
        raise EvidenceError("SESSION.json channelEvidence source paths are invalid")

    if environment.get("class") not in {"managed", "unmanaged"}:
        raise EvidenceError("SESSION.json environment.class is invalid")
    if environment.get("profileState") not in {"fresh", "existing", "both"}:
        raise EvidenceError("SESSION.json environment.profileState is invalid")
    if environment.get("permissionObservation") not in {"none", "automated", "human"}:
        raise EvidenceError("SESSION.json environment.permissionObservation is invalid")
    require_text(environment.get("osBuild"), "SESSION.json environment.osBuild", max_length=1000)
    require_text(environment.get("operatorNote", ""), "SESSION.json environment.operatorNote", max_length=4000, allow_empty=True)

    for key in ("caseCatalogSha256", "resultTemplateSha256"):
        if not isinstance(session.get(key), str) or not SHA256_RE.fullmatch(session[key]):
            raise EvidenceError(f"SESSION.json {key} is invalid")
    if session.get("sessionId") != expected_session_id(session):
        raise EvidenceError("SESSION.json sessionId does not match its Roadcase and preparation configuration")

    expected_boundary = {
        "runtimeExecuted": False,
        "runtimePass": False,
        "unmanagedBrowserAcceptance": False,
        "currentStableAcceptance": False,
        "humanPermissionPromptObservation": False,
        "accessibilityConformance": False,
        "assistiveTechnologyEvidence": False,
        "unfamiliarPersonComprehension": False,
        "unsignedOperatorEvidence": True,
    }
    if session.get("claimBoundary") != expected_boundary:
        raise EvidenceError("SESSION.json prepared claim boundary changed")

def validate_catalog(catalog: Mapping[str, Any]) -> list[str]:
    if catalog != case_catalog():
        raise EvidenceError("CASE-CATALOG.json must exactly match the fixed rev0106 catalog")
    if catalog.get("schema") != CASE_CATALOG_SCHEMA or catalog.get("revision") != REVISION:
        raise EvidenceError("CASE-CATALOG.json schema or revision is invalid")
    rows = catalog.get("cases")
    if not isinstance(rows, list) or not rows:
        raise EvidenceError("CASE-CATALOG.json cases must be a non-empty list")
    identifiers: list[str] = []
    for index, row in enumerate(rows):
        if not isinstance(row, Mapping):
            raise EvidenceError(f"CASE-CATALOG.json case {index} must be an object")
        case_id = require_text(row.get("id"), f"CASE-CATALOG.json case {index} id", max_length=120)
        if case_id in identifiers:
            raise EvidenceError(f"duplicate case id: {case_id}")
        if row.get("required") is not True:
            raise EvidenceError(f"runtime case must remain required: {case_id}")
        require_text(row.get("description"), f"CASE-CATALOG.json case {case_id} description")
        identifiers.append(case_id)
    return identifiers


def verify_package_tree(session_dir: Path, session: Mapping[str, Any], package_manifest: Mapping[str, Any]) -> None:
    package = session["package"]
    package_dir = session_dir / safe_relative_path(package["directory"], "SESSION.json package.directory")
    try:
        package_dir.resolve().relative_to(session_dir.resolve())
    except ValueError as error:
        raise EvidenceError("package directory escapes the prepared session") from error
    if package_dir.is_symlink() or not package_dir.is_dir():
        raise EvidenceError("prepared package directory is missing or is a symlink")
    if package_manifest.get("schema") != "progrss.runtime-package-manifest.v1":
        raise EvidenceError("PACKAGE-MANIFEST.json schema is invalid")
    if package_manifest.get("family") != package.get("family"):
        raise EvidenceError("PACKAGE-MANIFEST.json family does not match SESSION.json")
    rows = package_manifest.get("files")
    if not isinstance(rows, list) or not rows:
        raise EvidenceError("PACKAGE-MANIFEST.json files must be a non-empty list")
    expected: dict[str, Mapping[str, Any]] = {}
    for row in rows:
        if not isinstance(row, Mapping):
            raise EvidenceError("PACKAGE-MANIFEST.json file rows must be objects")
        relative = safe_relative_path(row.get("path"), "PACKAGE-MANIFEST.json file path")
        if relative in expected:
            raise EvidenceError(f"duplicate package manifest path: {relative}")
        digest = row.get("sha256")
        if not isinstance(digest, str) or not SHA256_RE.fullmatch(digest):
            raise EvidenceError(f"invalid package digest: {relative}")
        expected[relative] = row

    actual_paths: list[str] = []
    for path in sorted(package_dir.rglob("*"), key=lambda value: value.relative_to(package_dir).as_posix()):
        if path.is_symlink():
            raise EvidenceError(f"prepared package contains a symlink: {path.relative_to(package_dir).as_posix()}")
        if path.is_file():
            relative = path.relative_to(package_dir).as_posix()
            actual_paths.append(relative)
            row = expected.get(relative)
            if row is None:
                raise EvidenceError(f"unexpected prepared-package file: {relative}")
            if path.stat().st_size != row.get("bytes") or sha256_file(path) != row.get("sha256"):
                raise EvidenceError(f"prepared-package byte mismatch: {relative}")
            if os.name != "nt" and int(str(row.get("mode")), 8) != canonical_mode(path):
                raise EvidenceError(f"prepared-package mode mismatch: {relative}")
    if actual_paths != sorted(expected):
        missing = sorted(set(expected) - set(actual_paths))
        raise EvidenceError(f"prepared-package inventory mismatch; missing={missing}")

    manifest_digest = package_manifest.get("subtreeSha256")
    canonical_rows = sorted((dict(row) for row in rows), key=lambda row: row["path"])
    calculated = sha256_bytes(canonical_json_bytes(canonical_rows, pretty=False))
    if manifest_digest != calculated or package.get("subtreeSha256") != calculated:
        raise EvidenceError("prepared-package subtree digest mismatch")
    if package.get("files") != len(rows):
        raise EvidenceError("SESSION.json package file count mismatch")
    manifest_row = expected.get("manifest.json")
    if not manifest_row or package.get("manifestSha256") != manifest_row.get("sha256"):
        raise EvidenceError("prepared browser manifest digest mismatch")


def verify_roadcase(roadcase: Path, session: Mapping[str, Any], verifier: Path) -> str:
    roadcase = roadcase.resolve()
    if not roadcase.is_file() or roadcase.is_symlink():
        raise EvidenceError(f"Roadcase is missing or unsafe: {roadcase}")
    expected = session["roadcase"]
    if roadcase.name != expected.get("name"):
        raise EvidenceError("Roadcase filename does not match SESSION.json")
    if roadcase.stat().st_size != expected.get("bytes") or sha256_file(roadcase) != expected.get("sha256"):
        raise EvidenceError("Roadcase bytes do not match SESSION.json")
    completed = subprocess.run(
        [sys.executable, str(verifier), "--archive", str(roadcase)],
        cwd=verifier.parent,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=180,
        check=False,
    )
    if completed.returncode:
        raise EvidenceError(f"Roadcase verifier failed ({completed.returncode}):\n{completed.stdout}")
    return completed.stdout.strip()


def verify_package_against_roadcase(
    roadcase: Path,
    session: Mapping[str, Any],
    package_manifest: Mapping[str, Any],
) -> None:
    family = str(session["package"]["family"])
    archive_rows = roadcase_package_inventory(roadcase, family)
    manifest_rows = package_manifest.get("files")
    if not isinstance(manifest_rows, list):
        raise EvidenceError("PACKAGE-MANIFEST.json files must be a list")
    normalized_manifest_rows = sorted((dict(row) for row in manifest_rows), key=lambda row: row.get("path", ""))
    if archive_rows != normalized_manifest_rows:
        raise EvidenceError("prepared package manifest does not match the selected package inside the Roadcase")
    archive_digest = sha256_bytes(canonical_json_bytes(archive_rows, pretty=False))
    if archive_digest != session["package"]["subtreeSha256"] or archive_digest != package_manifest.get("subtreeSha256"):
        raise EvidenceError("Roadcase package subtree digest does not match the prepared session")
    manifest_row = next((row for row in archive_rows if row["path"] == "manifest.json"), None)
    if manifest_row is None or manifest_row["sha256"] != session["package"]["manifestSha256"]:
        raise EvidenceError("Roadcase browser manifest digest does not match the prepared session")
    fixture_path = safe_relative_path(session["fixture"]["path"], "SESSION.json fixture.path")
    with zipfile.ZipFile(roadcase) as archive:
        try:
            fixture = archive.read(fixture_path)
        except KeyError as error:
            raise EvidenceError(f"Roadcase is missing prepared fixture: {fixture_path}") from error
    if len(fixture) != session["fixture"]["bytes"] or sha256_bytes(fixture) != session["fixture"]["sha256"]:
        raise EvidenceError("Roadcase fixture does not match the prepared session")


CHANNEL_BUNDLE_NAMES = (CHANNEL_SNAPSHOT_NAME, CHROME_SOURCE_NAME, FIREFOX_SOURCE_NAME)


def verify_channel_evidence_payloads(
    session: Mapping[str, Any],
    payloads: Mapping[str, bytes],
) -> dict[str, Any]:
    missing = [name for name in CHANNEL_BUNDLE_NAMES if name not in payloads]
    if missing:
        raise EvidenceError(f"channel evidence is missing required payloads: {missing}")
    selected = {name: payloads[name] for name in CHANNEL_BUNDLE_NAMES}
    try:
        snapshot = validate_snapshot_payloads(
            selected[CHANNEL_SNAPSHOT_NAME],
            {
                CHROME_SOURCE_NAME: selected[CHROME_SOURCE_NAME],
                FIREFOX_SOURCE_NAME: selected[FIREFOX_SOURCE_NAME],
            },
        )
        expected_record = channel_session_record(snapshot, selected)
        expected = channel_expected_version(
            snapshot,
            str(session["browser"]["family"]),
            str(session["browser"]["channel"]),
        )
    except ChannelEvidenceError as error:
        raise EvidenceError(f"channel evidence is invalid: {error}") from error
    if dict(session.get("channelEvidence", {})) != expected_record:
        raise EvidenceError("SESSION.json channelEvidence does not match CHANNEL-SNAPSHOT.json and its source payloads")
    if session["browser"]["version"] != expected:
        raise EvidenceError(
            "SESSION.json browser.version does not match the bound official channel snapshot "
            f"({session['browser']['family']}/{session['browser']['channel']} expects {expected})"
        )
    return snapshot


def verify_channel_evidence_tree(session_dir: Path, session: Mapping[str, Any]) -> dict[str, Any]:
    payloads: dict[str, bytes] = {}
    for name in CHANNEL_BUNDLE_NAMES:
        path = session_dir / name
        if not path.is_file() or path.is_symlink():
            raise EvidenceError(f"prepared session is missing required channel-evidence file: {name}")
        payloads[name] = path.read_bytes()
    return verify_channel_evidence_payloads(session, payloads)


def verify_channel_snapshot_freshness(session: Mapping[str, Any], result: Mapping[str, Any]) -> None:
    try:
        captured = parse_channel_utc(str(session["channelEvidence"]["capturedUtc"]), "channel snapshot capturedUtc")
        started = parse_channel_utc(str(result.get("startedUtc", "")), "RESULT.json startedUtc")
        finished = parse_channel_utc(str(result.get("finishedUtc", "")), "RESULT.json finishedUtc")
    except ChannelEvidenceError as error:
        raise EvidenceError(str(error)) from error
    if finished < started:
        raise EvidenceError("RESULT.json finishedUtc must not precede startedUtc")
    if captured > started:
        raise EvidenceError("channel snapshot capturedUtc must not be later than RESULT.json startedUtc")
    age_seconds = int((started - captured).total_seconds())
    max_age = session["channelEvidence"]["maxAgeSeconds"]
    if age_seconds > max_age:
        raise EvidenceError(
            f"channel snapshot is stale at runtime start ({age_seconds}s exceeds {max_age}s); prepare a fresh session"
        )


def _evidence_references(result: Mapping[str, Any]) -> set[str]:
    references: set[str] = set()
    for case in result.get("cases", []):
        if isinstance(case, Mapping):
            for value in case.get("evidence", []):
                references.add(safe_relative_path(value, f"case {case.get('id')} evidence path"))
    native = result.get("nativeArtifacts", {})
    if isinstance(native, Mapping):
        for name, row in native.items():
            if not isinstance(row, Mapping):
                raise EvidenceError(f"nativeArtifacts.{name} must be an object")
            path = row.get("evidencePath")
            if path:
                references.add(safe_relative_path(path, f"nativeArtifacts.{name}.evidencePath"))
    events = result.get("events", [])
    if not isinstance(events, list):
        raise EvidenceError("events must be a list")
    for index, event in enumerate(events):
        if not isinstance(event, Mapping):
            raise EvidenceError(f"event {index} must be an object")
        path = event.get("evidencePath")
        if path:
            references.add(safe_relative_path(path, f"event {index} evidencePath"))
    return references


def validate_result_structure(
    session: Mapping[str, Any],
    catalog: Mapping[str, Any],
    result: Mapping[str, Any],
) -> str:
    require_exact_keys(result, RESULT_KEYS, "RESULT.json")
    if result.get("schema") != RESULT_SCHEMA or result.get("revision") != REVISION:
        raise EvidenceError("RESULT.json schema or revision is invalid")
    if result.get("sessionId") != session.get("sessionId"):
        raise EvidenceError("RESULT.json sessionId does not match SESSION.json")
    case_ids = validate_catalog(catalog)
    rows = result.get("cases")
    if not isinstance(rows, list) or [row.get("id") if isinstance(row, Mapping) else None for row in rows] != case_ids:
        raise EvidenceError("RESULT.json cases must exactly match CASE-CATALOG.json order")

    started_text = require_text(result.get("startedUtc"), "RESULT.json startedUtc", max_length=20, allow_empty=True)
    finished_text = require_text(result.get("finishedUtc"), "RESULT.json finishedUtc", max_length=20, allow_empty=True)

    browser = result.get("browserObserved")
    if not isinstance(browser, Mapping):
        raise EvidenceError("browserObserved must be an object")
    require_exact_keys(browser, BROWSER_OBSERVED_KEYS, "browserObserved")
    for key in sorted(BROWSER_OBSERVED_KEYS):
        require_text(browser.get(key), f"browserObserved.{key}", max_length=1000, allow_empty=True)

    observation = result.get("operatorObservation")
    if not isinstance(observation, Mapping):
        raise EvidenceError("operatorObservation must be an object")
    require_exact_keys(observation, OPERATOR_OBSERVATION_KEYS, "operatorObservation")
    if observation.get("mode") not in {"automated", "human"}:
        raise EvidenceError("operatorObservation.mode must be automated or human")
    if type(observation.get("completed")) is not bool or type(observation.get("statementAccepted")) is not bool:
        raise EvidenceError("operatorObservation completed and statementAccepted must be booleans")
    require_text(observation.get("note"), "operatorObservation.note", max_length=4000, allow_empty=True)

    permissions = result.get("permissionObservation")
    if not isinstance(permissions, Mapping):
        raise EvidenceError("permissionObservation must be an object")
    require_exact_keys(permissions, PERMISSION_OBSERVATION_KEYS, "permissionObservation")
    expected_permission_mode = session.get("environment", {}).get("permissionObservation")
    if permissions.get("mode") != expected_permission_mode:
        raise EvidenceError("permissionObservation.mode must match SESSION.json")
    if permissions.get("installPrompt") not in {"observed", "none", "not-applicable", "not-observed"}:
        raise EvidenceError("permissionObservation.installPrompt is invalid")
    before = permissions.get("before")
    after = permissions.get("after")
    validate_permission_projection(before, "permissionObservation.before")
    validate_permission_projection(after, "permissionObservation.after")
    require_text(permissions.get("notes"), "permissionObservation.notes", max_length=4000, allow_empty=True)

    assertions = result.get("operatorAssertions")
    if not isinstance(assertions, Mapping):
        raise EvidenceError("operatorAssertions must be an object")
    require_exact_keys(assertions, OPERATOR_ASSERTION_KEYS, "operatorAssertions")
    if not all(type(value) is bool for value in assertions.values()):
        raise EvidenceError("operatorAssertions values must be booleans")

    statuses: list[str] = []
    case_times: list[tuple[str, Any]] = []
    for row in rows:
        case_id = row["id"]
        require_exact_keys(row, CASE_RESULT_KEYS, f"case {case_id}")
        status_value = row.get("status")
        if status_value not in ALLOWED_STATUSES:
            raise EvidenceError(f"invalid status for {case_id}: {status_value!r}")
        statuses.append(status_value)
        observed = row.get("observed")
        evidence = row.get("evidence")
        if not isinstance(evidence, list):
            raise EvidenceError(f"case evidence must be a list: {case_id}")
        if len(evidence) != len(set(evidence)):
            raise EvidenceError(f"case evidence contains duplicate paths: {case_id}")
        if status_value == "not-run":
            if row.get("recordedUtc") != "" or observed != "" or evidence:
                raise EvidenceError(f"not-run case must have no timestamp, observation, or evidence: {case_id}")
        else:
            recorded = require_utc(row.get("recordedUtc"), f"case {case_id} recordedUtc")
            case_times.append((case_id, utc_value(recorded, f"case {case_id} recordedUtc")))
            require_text(observed, f"case {case_id} observed", max_length=4000)
            if not evidence:
                raise EvidenceError(f"executed or blocked case requires evidence: {case_id}")
        for value in evidence:
            path = safe_relative_path(value, f"case {case_id} evidence path")
            if not path.startswith("evidence/"):
                raise EvidenceError(f"case evidence must be under evidence/: {path}")

    if all(value == "pass" for value in statuses):
        derived = "pass"
    elif any(value == "fail" for value in statuses):
        derived = "fail"
    elif any(value == "blocked" for value in statuses):
        derived = "blocked"
    else:
        derived = "not-run"
    if result.get("status") != derived:
        raise EvidenceError(f"RESULT.json status must be derived as {derived}")

    any_attempted = any(value != "not-run" for value in statuses)
    any_executed = any(value in {"pass", "fail"} for value in statuses)
    if bool(started_text) != bool(finished_text):
        raise EvidenceError("RESULT.json startedUtc and finishedUtc must both be empty or both be present")
    interval = None
    if started_text:
        require_utc(started_text, "RESULT.json startedUtc")
        require_utc(finished_text, "RESULT.json finishedUtc")
        started = utc_value(started_text, "RESULT.json startedUtc")
        finished = utc_value(finished_text, "RESULT.json finishedUtc")
        if finished < started:
            raise EvidenceError("RESULT.json finishedUtc must not precede startedUtc")
        interval = (started, finished)
    elif any_attempted:
        raise EvidenceError("attempted results require startedUtc and finishedUtc")

    if any_executed:
        for key in sorted(BROWSER_OBSERVED_KEYS):
            require_text(browser.get(key), f"browserObserved.{key}", max_length=1000)
        if result.get("status") == "pass":
            expected_browser = session["browser"]
            expected_environment = session["environment"]
            expected_values = {
                "version": expected_browser["version"],
                "channel": expected_browser["channel"],
                "osBuild": expected_environment["osBuild"],
                "profileState": expected_environment["profileState"],
                "installMethod": expected_browser["installMethod"],
            }
            mismatches = [key for key, value in expected_values.items() if browser.get(key) != value]
            if mismatches:
                raise EvidenceError("passing result observed identity differs from prepared session: " + ", ".join(mismatches))
            verify_channel_snapshot_freshness(session, result)
        if observation.get("completed") is not True or observation.get("statementAccepted") is not True:
            raise EvidenceError("executed results require completed and accepted operatorObservation")

    permission_case = next(row for row in rows if row["id"] == "permission-state-unchanged")
    if permission_case["status"] == "pass":
        if not before or not after:
            raise EvidenceError("permission-state-unchanged requires complete before and after projections")
        if dict(before) != dict(after):
            raise EvidenceError("permission-state-unchanged cannot pass when before and after differ")

    if assertions["unmanagedEnvironment"] and session.get("environment", {}).get("class") != "unmanaged":
        raise EvidenceError("unmanagedEnvironment assertion conflicts with SESSION.json")
    if assertions["humanPermissionObservation"] and expected_permission_mode != "human":
        raise EvidenceError("humanPermissionObservation assertion conflicts with SESSION.json")
    if derived == "pass":
        required_true = ["exactPreparedPackageUsed", "sameProfileRestarted", "currentChannelAtExecution"]
        if session["environment"]["profileState"] in {"fresh", "both"}:
            required_true.append("freshProfileAtStart")
        if session["environment"]["class"] == "unmanaged":
            required_true.append("unmanagedEnvironment")
        if expected_permission_mode == "human":
            required_true.append("humanPermissionObservation")
        for key in required_true:
            if assertions[key] is not True:
                raise EvidenceError(f"passing result requires operatorAssertions.{key}=true")

    native = result.get("nativeArtifacts")
    if not isinstance(native, Mapping):
        raise EvidenceError("nativeArtifacts must be an object")
    unknown_artifacts = sorted(set(native) - NATIVE_ARTIFACT_NAMES)
    if unknown_artifacts:
        raise EvidenceError(f"nativeArtifacts contains unknown roles: {unknown_artifacts}")
    for name, row in native.items():
        if not isinstance(name, str) or not name or not isinstance(row, Mapping):
            raise EvidenceError("nativeArtifacts entries must be named objects")
        extra = sorted(set(row) - NATIVE_ARTIFACT_KEYS)
        if "evidencePath" not in row or extra:
            raise EvidenceError(f"nativeArtifacts.{name} keys are invalid; extra={extra}")
        evidence_path = safe_relative_path(row.get("evidencePath"), f"nativeArtifacts.{name}.evidencePath")
        if not evidence_path.startswith("evidence/"):
            raise EvidenceError(f"native artifact evidence must be under evidence/: {evidence_path}")
        digest = row.get("sha256")
        if digest is not None and (not isinstance(digest, str) or not SHA256_RE.fullmatch(digest)):
            raise EvidenceError(f"nativeArtifacts.{name}.sha256 is invalid")
        byte_count = row.get("bytes")
        if byte_count is not None and (type(byte_count) is not int or byte_count < 0):
            raise EvidenceError(f"nativeArtifacts.{name}.bytes is invalid")
        semantic = row.get("semanticProjectionSha256")
        if semantic is not None and (not isinstance(semantic, str) or not SHA256_RE.fullmatch(semantic)):
            raise EvidenceError(f"nativeArtifacts.{name}.semanticProjectionSha256 is invalid")

    events = result.get("events")
    if not isinstance(events, list):
        raise EvidenceError("events must be a list")
    event_times: list[tuple[int, Any]] = []
    for index, event in enumerate(events):
        if not isinstance(event, Mapping):
            raise EvidenceError(f"event {index} must be an object")
        actual_keys = set(event)
        if not EVENT_REQUIRED_KEYS.issubset(actual_keys) or actual_keys - EVENT_REQUIRED_KEYS - EVENT_OPTIONAL_KEYS:
            raise EvidenceError(f"event {index} keys are invalid")
        if event.get("kind") not in {"failure", "retry", "interruption", "recovery", "observation"}:
            raise EvidenceError(f"event {index} kind is invalid")
        recorded = require_utc(event.get("recordedUtc"), f"event {index} recordedUtc")
        event_times.append((index, utc_value(recorded, f"event {index} recordedUtc")))
        require_text(event.get("message"), f"event {index} message", max_length=4000)
        if event.get("evidencePath"):
            path = safe_relative_path(event.get("evidencePath"), f"event {index} evidencePath")
            if not path.startswith("evidence/"):
                raise EvidenceError(f"event evidence must be under evidence/: {path}")

    if event_times and not any_attempted:
        raise EvidenceError("events require at least one attempted case")
    if event_times and interval is None:
        raise EvidenceError("events require startedUtc and finishedUtc")

    if interval is not None:
        started, finished = interval
        for case_id, recorded in case_times:
            if recorded < started or recorded > finished:
                raise EvidenceError(f"case {case_id} recordedUtc must fall within RESULT.json runtime interval")
        for index, recorded in event_times:
            if recorded < started or recorded > finished:
                raise EvidenceError(f"event {index} recordedUtc must fall within RESULT.json runtime interval")
    return derived

def validate_evidence_payloads(
    result: Mapping[str, Any], payloads: Mapping[str, bytes],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """The same checks apply to local finalization and independent ZIP replay."""
    references = _evidence_references(result)
    actual = {name for name in payloads if name.startswith("evidence/")}
    if actual != references:
        raise EvidenceError(
            f"evidence inventory mismatch; missing={sorted(references-actual)}; "
            f"unreferenced={sorted(actual-references)}"
        )
    rows: list[dict[str, Any]] = []
    total = 0
    for name in sorted(actual):
        data = payloads[name]
        if len(data) > MAX_EVIDENCE_FILE_BYTES:
            raise EvidenceError(f"evidence file exceeds {MAX_EVIDENCE_FILE_BYTES} bytes: {name}")
        total += len(data)
        if total > MAX_EVIDENCE_TOTAL_BYTES:
            raise EvidenceError(f"evidence total exceeds {MAX_EVIDENCE_TOTAL_BYTES} bytes")
        rows.append({"path": name, "bytes": len(data), "sha256": sha256_bytes(data)})
    native = result.get("nativeArtifacts", {})
    case_status = {row["id"]: row["status"] for row in result.get("cases", [])}
    required = {"complete-route-disclosure": "completeRoute", "selected-branch-preservation": "selectedBranch"}
    for case_id, artifact_name in required.items():
        if case_status.get(case_id) == "pass" and artifact_name not in native:
            raise EvidenceError(f"passing {case_id} requires nativeArtifacts.{artifact_name}")
    verified_native: dict[str, Any] = {}
    for name, artifact in native.items():
        path = artifact["evidencePath"]
        try:
            derived = derive_native_artifact(payloads[path], name=name, evidence_path=path)
        except NativeArtifactError as error:
            raise EvidenceError(str(error)) from error
        for key in ("bytes", "sha256", "semanticProjectionSha256"):
            if artifact.get(key) not in {None, ""} and artifact[key] != derived[key]:
                raise EvidenceError(f"nativeArtifacts.{name}.{key} does not match evidence bytes")
        verified_native[name] = derived
    return rows, verified_native


def collect_evidence_payloads(session_dir: Path) -> dict[str, bytes]:
    evidence_root = session_dir / "evidence"
    payloads: dict[str, bytes] = {}
    if not evidence_root.exists() and not evidence_root.is_symlink():
        return payloads
    if evidence_root.is_symlink() or not evidence_root.is_dir():
        raise EvidenceError("evidence/ must be a real directory")
    total = 0
    for path in sorted(evidence_root.rglob("*")):
        name = path.relative_to(session_dir).as_posix()
        mode = path.lstat().st_mode
        if stat.S_ISDIR(mode):
            continue
        if not stat.S_ISREG(mode):
            raise EvidenceError(f"evidence contains a symlink or non-regular file: {name}")
        size = path.stat().st_size
        if size > MAX_EVIDENCE_FILE_BYTES:
            raise EvidenceError(f"evidence file exceeds {MAX_EVIDENCE_FILE_BYTES} bytes: {name}")
        total += size
        if total > MAX_EVIDENCE_TOTAL_BYTES:
            raise EvidenceError(f"evidence total exceeds {MAX_EVIDENCE_TOTAL_BYTES} bytes")
        if len(payloads) >= MAX_BUNDLE_MEMBERS:
            raise EvidenceError("too many evidence files")
        payloads[name] = path.read_bytes()
    return payloads


def base_bundle_inputs(session_dir: Path, result_path: Path) -> dict[str, bytes]:
    names = [
        "SESSION.json",
        "PACKAGE-MANIFEST.json",
        "CASE-CATALOG.json",
        "RESULT-TEMPLATE.json",
        "CHECKLIST.md",
        "FINALIZE.md",
        "ROADCASE-VERIFY.log",
        CHANNEL_SNAPSHOT_NAME,
        CHROME_SOURCE_NAME,
        FIREFOX_SOURCE_NAME,
    ]
    payloads: dict[str, bytes] = {}
    for name in names:
        path = session_dir / name
        if not path.is_file() or path.is_symlink():
            raise EvidenceError(f"prepared session is missing required regular file: {name}")
        payloads[name] = path.read_bytes()
    payloads["RESULT.json"] = result_path.read_bytes()
    return payloads


def build_evidence_manifest(
    session: Mapping[str, Any],
    payloads: Mapping[str, bytes],
    evidence_rows: Iterable[Mapping[str, Any]],
) -> tuple[dict[str, Any], bytes]:
    rows = [
        {"path": name, "bytes": len(data), "sha256": sha256_bytes(data)}
        for name, data in sorted(payloads.items())
    ]
    expected_evidence = {row["path"] for row in evidence_rows}
    if expected_evidence != {row["path"] for row in rows if row["path"].startswith("evidence/")}:
        raise EvidenceError("evidence rows and bundle payloads disagree")
    rows.sort(key=lambda row: row["path"])
    manifest = {
        "schema": EVIDENCE_MANIFEST_SCHEMA,
        "revision": REVISION,
        "sessionId": session["sessionId"],
        "files": rows,
    }
    return manifest, canonical_json_bytes(manifest)


def build_attestation(
    session: Mapping[str, Any],
    catalog: Mapping[str, Any],
    result: Mapping[str, Any],
    status: str,
    evidence_rows: list[dict[str, Any]],
    evidence_manifest_sha256: str,
    native_artifacts: Mapping[str, Any],
) -> tuple[dict[str, Any], bytes]:
    claims = {
        "runtimeExecuted": any(row["status"] in {"pass", "fail"} for row in result["cases"]),
        "runtimePass": status == "pass",
        "exactRoadcaseBound": True,
        "packageIdentityVerified": True,
        "channelSnapshotBound": True,
        "preparedChannelVersionMatched": True,
        "observedChannelVersionMatched": status == "pass",
        "channelSnapshotFreshAtRuntimeStart": status == "pass",
        "evidenceInventoryVerified": True,
        "nativeArtifactComparisonDerivedFromBytes": True,
        "unmanagedBrowserAcceptance": False,
        "currentStableAcceptance": False,
        "humanPermissionPromptObservationAccepted": False,
        "accessibilityConformance": False,
        "assistiveTechnologyEvidence": False,
        "unfamiliarPersonComprehension": False,
    }
    statement = {
        "_type": IN_TOTO_STATEMENT_TYPE,
        "subject": [
            {"name": session["roadcase"]["name"], "digest": {"sha256": session["roadcase"]["sha256"]}},
            {"name": f"runtime-package/{session['package']['family']}", "digest": {"sha256": session["package"]["subtreeSha256"]}},
            {"name": session["fixture"]["path"], "digest": {"sha256": session["fixture"]["sha256"]}},
            {"name": CHANNEL_SNAPSHOT_NAME, "digest": {"sha256": session["channelEvidence"]["snapshotSha256"]}},
            *[
                {"name": row["path"], "digest": {"sha256": row["sha256"]}}
                for row in session["channelEvidence"]["sources"]
            ],
        ],
        "predicateType": PREDICATE_TYPE,
        "predicate": {
            "schema": "progrss.source-notes.runtime-attestation-predicate.v3",
            "revision": REVISION,
            "sessionId": session["sessionId"],
            "result": status,
            "configuration": {
                "browserExpected": session["browser"],
                "environmentExpected": session["environment"],
                "channelEvidence": session["channelEvidence"],
                "caseCatalogSha256": sha256_bytes(canonical_json_bytes(catalog)),
            },
            "observed": {
                "startedUtc": result.get("startedUtc", ""),
                "finishedUtc": result.get("finishedUtc", ""),
                "browser": result.get("browserObserved", {}),
                "permissionObservation": result.get("permissionObservation", {}),
                "operatorObservation": result.get("operatorObservation", {}),
                "operatorAssertions": result.get("operatorAssertions", {}),
            },
            "cases": result["cases"],
            "nativeArtifacts": dict(native_artifacts),
            "events": result.get("events", []),
            "evidence": {
                "manifestSha256": evidence_manifest_sha256,
                "files": evidence_rows,
            },
            "claims": claims,
            "verificationBoundary": {
                "unsigned": True,
                "operatorAssertionsAuthenticated": False,
                "channelCurrencyAuthenticated": False,
                "channelSourceTransportAuthenticated": False,
                "channelSnapshotFreshnessVerified": status == "pass",
                "humanPresenceAuthenticated": False,
                "note": "The verifier binds exact official-source payload bytes, channel versions, and snapshot freshness, but does not authenticate the network fetch, operator, human presence, unmanaged environment, accessibility, or comprehension.",
            },
        },
    }
    return statement, canonical_json_bytes(statement)


def finalize_evidence(
    *,
    session_dir: Path,
    roadcase: Path,
    result_path: Path,
    verifier: Path,
) -> FinalizedEvidence:
    session_dir = session_dir.resolve()
    result_path = result_path.resolve()
    if not session_dir.is_dir() or session_dir.is_symlink():
        raise EvidenceError("session directory is missing or unsafe")
    try:
        result_path.relative_to(session_dir)
    except ValueError:
        pass
    session = read_json(session_dir / "SESSION.json")
    catalog = read_json(session_dir / "CASE-CATALOG.json")
    package_manifest = read_json(session_dir / "PACKAGE-MANIFEST.json")
    result = read_json(result_path)
    validate_session(session)
    case_ids = validate_catalog(catalog)
    if session.get("caseCatalogSha256") != sha256_bytes(canonical_json_bytes(catalog)):
        raise EvidenceError("CASE-CATALOG.json digest does not match SESSION.json")
    template_path = session_dir / "RESULT-TEMPLATE.json"
    expected_template = result_template(session, catalog)
    if (
        not template_path.is_file()
        or sha256_file(template_path) != session.get("resultTemplateSha256")
        or read_json(template_path) != expected_template
    ):
        raise EvidenceError("RESULT-TEMPLATE.json does not match the fixed prepared template")
    if [row["id"] for row in catalog["cases"]] != case_ids:
        raise EvidenceError("CASE-CATALOG.json order changed unexpectedly")
    verify_package_tree(session_dir, session, package_manifest)
    verify_channel_evidence_tree(session_dir, session)
    verify_roadcase(roadcase, session, verifier)
    verify_package_against_roadcase(roadcase.resolve(), session, package_manifest)
    status = validate_result_structure(session, catalog, result)
    payloads = base_bundle_inputs(session_dir, result_path)
    payloads.update(collect_evidence_payloads(session_dir))
    evidence_rows, native_artifacts = validate_evidence_payloads(result, payloads)
    manifest, manifest_bytes = build_evidence_manifest(session, payloads, evidence_rows)
    attestation, attestation_bytes = build_attestation(
        session,
        catalog,
        result,
        status,
        evidence_rows,
        sha256_bytes(manifest_bytes),
        native_artifacts,
    )
    return FinalizedEvidence(status, evidence_rows, manifest, manifest_bytes, attestation, attestation_bytes)


def _zip_info(name: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, FIXED_ZIP_TIME)
    info.create_system = 3
    info.compress_type = zipfile.ZIP_DEFLATED
    info.flag_bits |= 0x800
    info.external_attr = (stat.S_IFREG | 0o644) << 16
    return info


def write_evidence_bundle(
    *,
    session_dir: Path,
    result_path: Path,
    finalized: FinalizedEvidence,
    output: Path,
) -> dict[str, Any]:
    session = read_json(session_dir / "SESSION.json")
    payloads = base_bundle_inputs(session_dir, result_path)
    for row in finalized.evidence_rows:
        payloads[row["path"]] = (session_dir / row["path"]).read_bytes()
    expected = {row["path"]: row for row in finalized.manifest["files"]}
    if set(payloads) != set(expected) or any(
        len(data) != expected[name]["bytes"] or sha256_bytes(data) != expected[name]["sha256"]
        for name, data in payloads.items()
    ):
        raise EvidenceError("session inputs changed after finalization; finalize again")
    payloads["EVIDENCE-MANIFEST.json"] = finalized.manifest_bytes
    payloads["ATTESTATION.json"] = finalized.attestation_bytes
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, strict_timestamps=True) as archive:
        archive.comment = b""
        for name in sorted(payloads):
            safe_relative_path(name, "bundle entry")
            archive.writestr(_zip_info(name), payloads[name], compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return {
        "schema": "progrss.source-notes.runtime-evidence-bundle.v1",
        "sessionId": session["sessionId"],
        "status": finalized.status,
        "path": str(output),
        "bytes": output.stat().st_size,
        "sha256": sha256_file(output),
        "attestationSha256": sha256_bytes(finalized.attestation_bytes),
        "evidenceManifestSha256": sha256_bytes(finalized.manifest_bytes),
    }


def _safe_bundle_name(name: str) -> str:
    normalized = safe_relative_path(name, "bundle member")
    if normalized.endswith("/"):
        raise EvidenceError(f"directory entries are not allowed in evidence bundles: {name}")
    return normalized


def _verify_evidence_bundle_data(bundle: Path, *, roadcase: Path, verifier: Path) -> tuple[dict[str, Any], dict[str, bytes]]:
    if bundle.is_symlink():
        raise EvidenceError("evidence bundle is a symlink")
    bundle = bundle.resolve()
    if not bundle.is_file():
        raise EvidenceError("evidence bundle is missing or unsafe")
    with zipfile.ZipFile(bundle) as archive:
        members: dict[str, bytes] = {}
        infos = archive.infolist()
        if len(infos) > MAX_BUNDLE_MEMBERS:
            raise EvidenceError("too many evidence-bundle members")
        # Bound every member and the total before decompressing any member.
        total = 0
        for info in infos:
            limit = MAX_EVIDENCE_FILE_BYTES if info.filename.startswith("evidence/") else MAX_METADATA_FILE_BYTES
            if info.file_size > limit:
                raise EvidenceError(f"evidence-bundle member exceeds {limit} bytes: {info.filename}")
            total += info.file_size
            if total > MAX_BUNDLE_TOTAL_BYTES:
                raise EvidenceError("evidence-bundle expanded size exceeds limit")
        for info in infos:
            name = _safe_bundle_name(info.filename)
            raw_mode = (info.external_attr >> 16) & 0xFFFF
            if info.is_dir() or stat.S_IFMT(raw_mode) not in {0, stat.S_IFREG}:
                raise EvidenceError(f"unsafe evidence-bundle member: {info.filename}")
            if name in members:
                raise EvidenceError(f"duplicate evidence-bundle member: {name}")
            members[name] = archive.read(info)
    required_names = {
        "SESSION.json", "PACKAGE-MANIFEST.json", "CASE-CATALOG.json", "RESULT-TEMPLATE.json",
        "CHECKLIST.md", "FINALIZE.md", "ROADCASE-VERIFY.log", "RESULT.json",
        CHANNEL_SNAPSHOT_NAME, CHROME_SOURCE_NAME, FIREFOX_SOURCE_NAME,
        "EVIDENCE-MANIFEST.json", "ATTESTATION.json",
    }
    for required in sorted(required_names):
        if required not in members:
            raise EvidenceError(f"evidence bundle is missing {required}")
    unexpected = set(members) - required_names - {name for name in members if name.startswith("evidence/")}
    if unexpected:
        raise EvidenceError(f"unexpected top-level evidence-bundle members: {sorted(unexpected)}")
    manifest = decode_json_object(members["EVIDENCE-MANIFEST.json"], "EVIDENCE-MANIFEST.json")
    attestation = decode_json_object(members["ATTESTATION.json"], "ATTESTATION.json")
    session = decode_json_object(members["SESSION.json"], "SESSION.json")
    package_manifest = decode_json_object(members["PACKAGE-MANIFEST.json"], "PACKAGE-MANIFEST.json")
    catalog = decode_json_object(members["CASE-CATALOG.json"], "CASE-CATALOG.json")
    result = decode_json_object(members["RESULT.json"], "RESULT.json")
    validate_session(session)
    verify_channel_evidence_payloads(session, members)
    validate_catalog(catalog)
    if sha256_bytes(members["CASE-CATALOG.json"]) != session.get("caseCatalogSha256"):
        raise EvidenceError("bundled CASE-CATALOG.json digest does not match SESSION.json")
    if (
        sha256_bytes(members["RESULT-TEMPLATE.json"]) != session.get("resultTemplateSha256")
        or decode_json_object(members["RESULT-TEMPLATE.json"], "RESULT-TEMPLATE.json") != result_template(session, catalog)
    ):
        raise EvidenceError("bundled RESULT-TEMPLATE.json does not match the fixed prepared template")
    verify_roadcase(roadcase.resolve(), session, verifier.resolve())
    verify_package_against_roadcase(roadcase.resolve(), session, package_manifest)
    status = validate_result_structure(session, catalog, result)
    if manifest.get("schema") != EVIDENCE_MANIFEST_SCHEMA or manifest.get("sessionId") != session.get("sessionId") or manifest.get("revision") != REVISION:
        raise EvidenceError("evidence manifest identity is invalid")
    rows = manifest.get("files")
    if not isinstance(rows, list):
        raise EvidenceError("evidence manifest files must be a list")
    expected_names = {"EVIDENCE-MANIFEST.json", "ATTESTATION.json"}
    evidence_rows: list[dict[str, Any]] = []
    listed_names: list[str] = []
    for row in rows:
        if not isinstance(row, Mapping):
            raise EvidenceError("evidence manifest rows must be objects")
        name = safe_relative_path(row.get("path"), "evidence manifest path")
        if name in expected_names:
            raise EvidenceError(f"duplicate or reserved evidence-manifest entry: {name}")
        listed_names.append(name)
        expected_names.add(name)
        data = members.get(name)
        if data is None or len(data) != row.get("bytes") or sha256_bytes(data) != row.get("sha256"):
            raise EvidenceError(f"evidence-bundle byte mismatch: {name}")
        if name.startswith("evidence/"):
            evidence_rows.append(dict(row))
    if set(members) != expected_names:
        raise EvidenceError(f"unexpected evidence-bundle members: {sorted(set(members) - expected_names)}")
    if listed_names != sorted(listed_names):
        raise EvidenceError("evidence-manifest entries must be sorted")
    checked_rows, native_artifacts = validate_evidence_payloads(result, members)
    if evidence_rows != checked_rows:
        raise EvidenceError("evidence manifest does not match the referenced evidence inventory")
    manifest_bytes = canonical_json_bytes(manifest)
    if members["EVIDENCE-MANIFEST.json"] != manifest_bytes:
        raise EvidenceError("evidence manifest must be canonical")
    rebuilt, rebuilt_bytes = build_attestation(
        session,
        catalog,
        result,
        status,
        sorted(evidence_rows, key=lambda row: row["path"]),
        sha256_bytes(manifest_bytes),
        native_artifacts,
    )
    if attestation != rebuilt or members["ATTESTATION.json"] != rebuilt_bytes:
        raise EvidenceError("ATTESTATION.json does not match the verified bundle inputs")
    return {
        "schema": "progrss.source-notes.runtime-evidence-verification.v3",
        "sessionId": session["sessionId"],
        "status": status,
        "bundle": bundle.name,
        "bytes": bundle.stat().st_size,
        "sha256": sha256_file(bundle),
        "attestationSha256": sha256_bytes(rebuilt_bytes),
        "evidenceManifestSha256": sha256_bytes(manifest_bytes),
        "files": len(members),
        "roadcaseReverified": True,
        "packageReverifiedFromRoadcase": True,
        "fixtureReverifiedFromRoadcase": True,
        "channelEvidenceReverified": True,
        "channelSnapshotFreshnessVerified": status == "pass",
        "verificationScope": "bundle-plus-roadcase-plus-native-artifacts",
        "nativeArtifactsReverified": True,
        "pass": True,
    }, members


def verify_evidence_bundle(bundle: Path, *, roadcase: Path, verifier: Path) -> dict[str, Any]:
    report, _ = _verify_evidence_bundle_data(bundle, roadcase=roadcase, verifier=verifier)
    return report


def compare_attestations(paths: list[Path]) -> dict[str, Any]:
    """Refuse the old trust-on-name API rather than silently weaken verification."""
    raise EvidenceError("standalone attestations are not verified comparison inputs; use evidence bundles and --roadcase")


def compare_evidence_bundles(
    paths: list[Path], *, roadcase: Path, verifier: Path, require_browser_triad: bool = False,
) -> dict[str, Any]:
    if len(paths) < 2:
        raise EvidenceError("comparison requires at least two evidence bundles")
    rows: list[dict[str, Any]] = []
    digests: set[str] = set()
    session_ids: set[str] = set()
    for path in paths:
        verification, members = _verify_evidence_bundle_data(path, roadcase=roadcase, verifier=verifier)
        session = decode_json_object(members["SESSION.json"], "SESSION.json")
        statement = decode_json_object(members["ATTESTATION.json"], "ATTESTATION.json")
        predicate = statement["predicate"]
        identity = session["sessionId"]
        if verification["sha256"] in digests or identity in session_ids:
            raise EvidenceError("duplicate bundle or session identity would collapse comparison rows")
        digests.add(verification["sha256"])
        session_ids.add(identity)
        rows.append({
            "sessionId": identity,
            "bundle": path.name,
            "bundleSha256": verification["sha256"],
            "attestationSha256": verification["attestationSha256"],
            "result": predicate["result"],
            "roadcaseSha256": session["roadcase"]["sha256"],
            "family": session["browser"]["family"],
            "channel": session["browser"]["channel"],
            "browserExpected": session["browser"],
            "browserObserved": predicate["observed"]["browser"],
            "environment": session["environment"],
            "packageSha256": session["package"]["subtreeSha256"],
            "fixtureSha256": session["fixture"]["sha256"],
            "channelSnapshotSha256": session["channelEvidence"]["snapshotSha256"],
            "cases": {case["id"]: case["status"] for case in predicate["cases"]},
            "nativeArtifacts": predicate["nativeArtifacts"],
            "permissionObservation": predicate["observed"]["permissionObservation"],
            "verification": verification,
        })
    expected_triad = {("chromium", "stable"), ("firefox", "release"), ("firefox", "esr")}
    actual_triad = {(row["family"], row["channel"]) for row in rows}
    triad_present = len(rows) == 3 and actual_triad == expected_triad
    if require_browser_triad and not triad_present:
        raise EvidenceError("browser triad requires exactly one Chromium Stable, Firefox Release, and Firefox ESR bundle")
    cases = sorted(set.union(*(set(row["cases"]) for row in rows)))
    case_comparison = {name: {row["sessionId"]: row["cases"].get(name) for row in rows} for name in cases}
    artifact_names = {"completeRoute", "selectedBranch"} | set.union(*(set(row["nativeArtifacts"]) for row in rows))
    artifacts: dict[str, Any] = {}
    for name in sorted(artifact_names):
        present = {row["sessionId"]: row["nativeArtifacts"].get(name) for row in rows}
        missing = [identity for identity, value in present.items() if value is None]
        semantic = {identity: value["semanticProjectionSha256"] if value else None for identity, value in present.items()}
        raw = {identity: value["sha256"] if value else None for identity, value in present.items()}
        methods = {identity: value["semanticProjectionSchema"] if value else None for identity, value in present.items()}
        comparable = not missing and len(set(methods.values())) == 1
        artifacts[name] = {
            "missingSessions": missing,
            "comparisonState": "missing-evidence" if missing else "comparable" if comparable else "different-projection-schemas",
            "semanticProjection": semantic,
            "semanticProjectionSchema": methods,
            "semanticProjectionEqual": len(set(semantic.values())) == 1 if comparable else None,
            "rawSha256": raw,
            "rawSha256Equal": len(set(raw.values())) == 1 if not missing else None,
            "derivedFromEvidenceBytes": True,
        }
    return {
        "schema": "progrss.source-notes.runtime-comparison.v3",
        "revision": REVISION,
        "inputsVerifiedAgainstRoadcase": True,
        "sameRoadcase": len({row["roadcaseSha256"] for row in rows}) == 1,
        "sameFixture": len({row["fixtureSha256"] for row in rows}) == 1,
        "sameChannelSnapshot": len({row["channelSnapshotSha256"] for row in rows}) == 1,
        "browserTriadPresent": triad_present,
        "allCaseResultsPass": all(row["result"] == "pass" for row in rows),
        "sessions": rows,
        "caseComparison": case_comparison,
        "nativeArtifactComparison": artifacts,
        "interpretation": {
            "rawDifferenceIsFailure": False,
            "semanticProjectionDifferenceNeedsReview": True,
            "permissionDifferencesNeedPlatformExplanation": True,
            "missingEvidenceIsEquality": False,
            "comparisonClosesRuntimeRow": False,
            "operatorAssertionsAuthenticated": False,
            "browserExecutionAuthenticated": False,
            "currentUnmanagedAcceptance": False,
        },
    }
