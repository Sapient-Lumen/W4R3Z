#!/usr/bin/env python3
"""Run rev0097 offline/native and managed browser-API/UI regressions."""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "evidence" / "rev0097"
OUT.mkdir(parents=True, exist_ok=True)
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
rows: list[dict] = []
modules = [
    "test_acquisition", "test_cadence", "test_cli", "test_command_line",
    "test_debrief", "test_fieldbook", "test_node_server", "test_node_store",
    "test_relay", "test_roadcase", "test_source_notes_entrypoints", "test_source_repair_notes",
]
commands: list[tuple[str, list[str], Path, dict[str, str], int]] = [
    ("cli-" + module, [sys.executable, "-m", "unittest", "-v", "CLI.tests." + module], ROOT, {}, 1200)
    for module in modules
]
commands.append(("extension-static", [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py", "-v"], ROOT / "Extension", {}, 1200))
for name in (
    "background_harness", "relay_core_harness", "source_notes_entrypoints_harness",
    "firefox_background_harness", "acquisition_harness", "vault_conflict_harness",
    "source_notes_folder_undo_harness", "source_notes_source_repair_harness",
    "source_notes_saturated_concurrency_harness", "source_notes_folder_remove_harness",
    "source_notes_lineage_harness",
):
    commands.append((name, ["node", "Extension/tests/" + name + ".js"], ROOT, {}, 900))
for name in (
    "source_notes_entrypoints_harness", "source_notes_folder_undo_harness",
    "source_notes_source_repair_harness", "source_notes_saturated_concurrency_harness",
    "source_notes_folder_remove_harness", "source_notes_lineage_harness",
):
    commands.append((name + "-firefox", ["node", "Extension/tests/" + name + ".js"], ROOT, {"PROGRSS_EXTENSION_ROOT": "Firefox"}, 900))
for family, root in (("chromium", ROOT / "Extension"), ("firefox", ROOT / "Extension" / "Firefox")):
    commands.append((
        "workbench-preservation-" + family,
        [sys.executable, "Extension/tests/source_notes_workbench_collection_harness.py", "--root", str(root), "--artifacts", str(OUT / ("workbench-artifacts-" + family))],
        ROOT, {}, 900,
    ))
    commands.append((
        "lineage-workbench-" + family,
        [sys.executable, "Extension/tests/source_notes_lineage_workbench_harness.py", "--root", str(root), "--artifacts", str(OUT / ("lineage-artifacts-" + family))],
        ROOT, {}, 900,
    ))
commands += [
    ("browser_smoke", [sys.executable, "Extension/tests/browser_smoke.py"], ROOT, {}, 1200),
    ("extension-complete", ["sh", "tests/run.sh"], ROOT / "Extension", {}, 1800),
    ("contract", ["sh", "tools/verify-source-notes-contract.sh"], ROOT, {}, 900),
    ("evidence-boundary", [sys.executable, "-m", "unittest", "-v", "tests.test_source_notes_runtime_evidence", "tests.test_verified_runtime_comparison"], ROOT, {}, 1200),
]

for label, command, cwd, extra, timeout in commands:
    started = time.monotonic()
    log = OUT / (label + ".log")
    with log.open("w", encoding="utf-8") as handle:
        try:
            completed = subprocess.run(command, cwd=cwd, env=dict(ENV, **extra), stdout=handle, stderr=subprocess.STDOUT, timeout=timeout)
            code = completed.returncode
        except subprocess.TimeoutExpired:
            code = 124
            handle.write("\nTIMEOUT (not a pass)\n")
    text = log.read_text(encoding="utf-8", errors="replace")
    matches = re.findall(r"Ran (\d+) tests?", text)
    row = {"label": label, "command": command, "returncode": code, "seconds": round(time.monotonic() - started, 3), "tests": int(matches[-1]) if matches else None, "log": log.name}
    rows.append(row)
    print(json.dumps(row, ensure_ascii=False), flush=True)
    (OUT / "regression-status.json").write_text(json.dumps({"complete": False, "rows": rows}, ensure_ascii=False, sort_keys=True, indent=2) + "\n")

summary = {
    "complete": True,
    "allPassed": all(row["returncode"] == 0 for row in rows),
    "rows": rows,
    "managedNodeHarnessInvocations": 17,
    "managedWorkbenchUiPathVariants": 4,
    "browserAutomationExecuted": True,
    "browserAutomationScope": "managed rendering/interaction and shipped Workbench UI-path smoke; not installed-browser acceptance",
    "installedBrowserRuntimeExecuted": False,
}
(OUT / "regression-status.json").write_text(json.dumps(summary, ensure_ascii=False, sort_keys=True, indent=2) + "\n")
if not summary["allPassed"]:
    raise SystemExit(1)
