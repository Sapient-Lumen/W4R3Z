#!/usr/bin/env python3
"""Generate rev0106 reconstruction provenance against immutable rev0105."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import stat
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0106-relay-workspace-source-note-integrity"
PARENT_NAME = "ProgRSS-rev0105-node-private-library-source-note-integrity-2026.10.22-Roadcase.zip"
PARENT_SHA = "e34cb801d87dd7e4c8bf26cf72ce25e6356af68d20818140691889a59c19dd6c"
PARENT_BYTES = 26881071
EXCLUDED_NAMES = {"RECONSTRUCTION_PROVENANCE.json", "RECONSTRUCTION_PROVENANCE.md", "ROADCASE-MANIFEST.json", ".DS_Store"}
EXCLUDED_PARTS = {".git", "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"}
LINEAGE = (
    "Continues the sealed rev0105 unified whole-product tree and corrects a reproduced Relay workspace "
    "Source Note validation bypass. The shared-folder share, publish, import, review, explicit publication-check, "
    "and update commands now use the same private-placement audit before state use and before derived workspace writes. "
    "The current parent already contains the unified Node private-library, private-transfer, Exchange, Node branch and "
    "merge, shared-folder merge, publication, Lineage, Workbench collection and backup, repair, concurrency, Undo, "
    "native-integrity, and runtime-record work. No missing revision is invented."
)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def current_inventory() -> dict[str, tuple[bytes, int, str]]:
    rows: dict[str, tuple[bytes, int, str]] = {}
    for path in sorted(ROOT.rglob("*")):
        rel = path.relative_to(ROOT)
        if any(part in EXCLUDED_PARTS for part in rel.parts) or path.name in EXCLUDED_NAMES or path.suffix == ".pyc":
            continue
        if path.name.endswith(".zip") or path.name.endswith(".sha256"):
            continue
        if path.is_symlink():
            data = os.readlink(path).encode("utf-8")
            mode = 0o777
            kind = "symlink"
        elif path.is_file():
            data = path.read_bytes()
            mode = 0o755 if stat.S_IMODE(path.stat().st_mode) & 0o111 else 0o644
            kind = "file"
        else:
            continue
        rows[rel.as_posix()] = (data, mode, kind)
    return rows


def parent_inventory(path: Path) -> dict[str, tuple[bytes, int, str]]:
    rows: dict[str, tuple[bytes, int, str]] = {}
    with zipfile.ZipFile(path) as archive:
        seen: set[str] = set()
        for info in archive.infolist():
            if info.filename in seen:
                raise SystemExit(f"duplicate parent member: {info.filename}")
            seen.add(info.filename)
            name = info.filename.rstrip("/")
            if not name or info.is_dir() or PurePosixPath(name).name in EXCLUDED_NAMES:
                continue
            pure = PurePosixPath(name)
            if pure.is_absolute() or ".." in pure.parts:
                raise SystemExit(f"unsafe parent member: {info.filename}")
            raw_mode = (info.external_attr >> 16) & 0xFFFF
            kind = "symlink" if stat.S_ISLNK(raw_mode) else "file"
            mode = 0o777 if kind == "symlink" else (0o755 if stat.S_IMODE(raw_mode) & 0o111 else 0o644)
            rows[name] = (archive.read(info), mode, kind)
    return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--parent", type=Path, required=True)
    args = parser.parse_args()
    raw = args.parent.read_bytes()
    if args.parent.name != PARENT_NAME or len(raw) != PARENT_BYTES or sha(raw) != PARENT_SHA:
        raise SystemExit("parent identity mismatch")
    prior = parent_inventory(args.parent)
    current = current_inventory()
    added = sorted(set(current) - set(prior))
    deleted = sorted(set(prior) - set(current))
    changed = sorted(
        name for name in set(current) & set(prior)
        if current[name][0] != prior[name][0] or current[name][1:] != prior[name][1:]
    )
    report = {
        "schema": "progrss.reconstruction-provenance.v2",
        "reconstructionRevision": REVISION,
        "generatedUtc": "2026-10-22T00:00:00Z",
        "productLineage": {"revision": "rev0080", "version": "0.80.0"},
        "rootBaselineArchive": "ProgRSS-rev0080-2026.10.20-Roadcase(2).zip",
        "rootBaselineSha256": "181308cabfae43330016a272a64fbdb33038f841d605f4756ec65bedb43b8106",
        "immediateParentArchive": PARENT_NAME,
        "immediateParentSha256": PARENT_SHA,
        "immediateParentBytes": PARENT_BYTES,
        "integrationDonor": None,
        "mergeBase": None,
        "lineageClaim": LINEAGE,
        "missingArtifacts": ["rev0081", "rev0082", "rev0090-source-notes-browser-execution-binding"],
        "inventoryExclusions": sorted(EXCLUDED_NAMES),
        "differenceCounts": {"added": len(added), "changed": len(changed), "deleted": len(deleted)},
        "added": added,
        "changed": changed,
        "deleted": deleted,
    }
    (ROOT / "RECONSTRUCTION_PROVENANCE.json").write_text(
        json.dumps(report, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8"
    )
    (ROOT / "RECONSTRUCTION_PROVENANCE.md").write_text(
        "# Reconstruction provenance — rev0106\n\n"
        f"Immediate parent: `{PARENT_NAME}`  \nSHA-256: `{PARENT_SHA}`  \nBytes: {PARENT_BYTES}\n\n"
        f"{LINEAGE}\n\n"
        f"Compared with the immutable parent while excluding generated provenance and manifest files: "
        f"**{len(added)} added**, **{len(changed)} changed**, and **{len(deleted)} deleted** paths. "
        "The full path lists are retained in `RECONSTRUCTION_PROVENANCE.json`.\n\n"
        "Unavailable artifacts remain explicitly unrecovered: rev0081, rev0082, and the undelivered "
        "rev0090 browser-execution-binding source archive.\n",
        encoding="utf-8",
    )
    print(json.dumps(report["differenceCounts"], sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
