#!/usr/bin/env python3
"""Compare rev0098 product bytes and permissions with immutable rev0097 parent."""
from __future__ import annotations

import hashlib
import json
import stat
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PARENT = Path("/mnt/data/ProgRSS-rev0097-source-notes-lineage-preservation-2026.10.21-Roadcase.zip")
REVISION = "rev0098-source-notes-publication-disclosure"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parent_rows() -> dict[str, tuple[str, int]]:
    out = {}
    with zipfile.ZipFile(PARENT) as archive:
        for info in archive.infolist():
            if not info.is_dir():
                out[info.filename] = (digest(archive.read(info)), stat.S_IMODE((info.external_attr >> 16) & 0xFFFF))
    return out


def current_rows() -> dict[str, tuple[str, int]]:
    out = {}
    for path in ROOT.rglob("*"):
        if path.is_file() and not path.is_symlink() and "__pycache__" not in path.parts and path.suffix != ".pyc":
            out[path.relative_to(ROOT).as_posix()] = (digest(path.read_bytes()), stat.S_IMODE(path.stat().st_mode))
    return out


def projection(data: dict) -> dict:
    return {key: data.get(key, []) for key in ("permissions", "optional_permissions", "host_permissions", "optional_host_permissions")}


def main() -> None:
    before, after = parent_rows(), current_rows()
    result = {
        "schema": "progrss.product-continuity-audit.v1",
        "revision": REVISION,
        "parent": {"archive": PARENT.name, "sha256": digest(PARENT.read_bytes())},
        "pass": True,
    }
    for prefix, key in (("CLI/", "cli"), ("Extension/", "extension")):
        names = sorted({name for name in before if name.startswith(prefix)} | {name for name in after if name.startswith(prefix)})
        result[key] = {
            "pathsCompared": len(names),
            "added": [name for name in names if name not in before],
            "deleted": [name for name in names if name not in after],
            "changed": [name for name in names if name in before and name in after and before[name] != after[name]],
        }
    assert set(result["cli"]["added"]) == {"CLI/tests/test_source_notes_publication_site.py"}
    assert set(result["cli"]["changed"]) == {"CLI/README.md", "CLI/relay.py", "CLI/tests/test_command_line.py"}
    assert result["cli"]["deleted"] == []
    assert set(result["extension"]["added"]) == {"Extension/tests/source_notes_publication_site_harness.js"}
    assert set(result["extension"]["changed"]) == {
        "Extension/README.md",
        "Extension/Firefox/README.md",
        "Extension/shared/publication-site.js",
        "Extension/Firefox/shared/publication-site.js",
        "Extension/tests/browser_smoke.py",
        "Extension/tests/firefox_manual_acceptance.md",
        "Extension/tests/run.sh",
        "Extension/tests/test_static.py",
    }
    assert result["extension"]["deleted"] == []
    assert (ROOT / "Extension/shared/publication-site.js").read_bytes() == (ROOT / "Extension/Firefox/shared/publication-site.js").read_bytes()
    with zipfile.ZipFile(PARENT) as archive:
        parent_chromium = projection(json.loads(archive.read("Extension/manifest.json")))
        parent_firefox = projection(json.loads(archive.read("Extension/Firefox/manifest.json")))
    current_chromium = projection(json.loads((ROOT / "Extension/manifest.json").read_text()))
    current_firefox = projection(json.loads((ROOT / "Extension/Firefox/manifest.json").read_text()))
    assert current_chromium == parent_chromium
    assert current_firefox == parent_firefox
    result["permissions"] = {"chromiumProjectionUnchanged": True, "firefoxProjectionUnchanged": True, "expanded": False}
    (ROOT / "PRODUCT-CONTINUITY-AUDIT.json").write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n")
    (ROOT / "PRODUCT-CONTINUITY-AUDIT.md").write_text(
        "# Product continuity audit — rev0098\n\n"
        f"- Parent: `{PARENT.name}`\n"
        f"- Parent SHA-256: `{result['parent']['sha256']}`\n"
        f"- CLI paths compared: **{result['cli']['pathsCompared']}**; one focused test added; product changes limited to the existing static-publication generator and documentation.\n"
        f"- Extension paths compared: **{result['extension']['pathsCompared']}**; one focused harness added; product changes limited to the shared static-publication module and generated-Firefox parity.\n"
        "- Required, optional, host, and optional-host permission projections are unchanged in both packages.\n"
        "- No new store, network authority, account, identity, pairing, schedule, notification, ranking, profile, reaction, or messaging path was added.\n"
    )
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
