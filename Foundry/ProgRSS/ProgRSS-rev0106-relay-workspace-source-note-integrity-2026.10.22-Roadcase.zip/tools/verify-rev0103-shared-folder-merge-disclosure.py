#!/usr/bin/env python3
"""Focused rev0103 replay from a source tree or clean extraction."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0103-shared-folder-merge-source-note-disclosure"
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")


def run(label: str, command: list[str], timeout: int = 1800, extra: dict[str, str] | None = None) -> str:
    result = subprocess.run(
        command, cwd=ROOT, env=dict(ENV, **(extra or {})), text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout,
    )
    print(f"\n== {label} ==\n{result.stdout.rstrip()}")
    if result.returncode:
        raise RuntimeError(f"{label} failed with exit {result.returncode}")
    return result.stdout


def main() -> int:
    assert (ROOT / "REVISION").read_text(encoding="utf-8").strip() == REVISION
    cases = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text(encoding="utf-8"))
    assert cases["revision"] == REVISION and len(cases["cases"]) == 18
    keep = next(row for row in cases["cases"] if row["id"] == "divergent-later-copy-keep-mine")
    curator = next(row for row in cases["cases"] if row["id"] == "divergent-later-copy-use-curator")
    assert "Extension shared-folder update review" in keep["description"]
    assert "Extension shared-folder update review" in curator["description"]

    background = (ROOT / "Extension/background.js").read_text(encoding="utf-8")
    sidepanel = (ROOT / "Extension/sidepanel/app.js").read_text(encoding="utf-8")
    css = (ROOT / "Extension/sidepanel/app.css").read_text(encoding="utf-8")
    assert background == (ROOT / "Extension/Firefox/background.js").read_text(encoding="utf-8")
    assert sidepanel == (ROOT / "Extension/Firefox/sidepanel/app.js").read_text(encoding="utf-8")
    assert css == (ROOT / "Extension/Firefox/sidepanel/app.css").read_text(encoding="utf-8")
    for phrase in ("incomingFolderPathById", "folderPath: C.text(folderPath", "placement: {"):
        assert phrase in background, phrase
    for phrase in (
        "sharedFolderSourceNoteRoute", "sharedFolderSourceNoteValue",
        "Curator’s reason for this folder", "not a ProgRSS safety claim",
        "Last accepted curator reason", "Your reason", "Curator’s reason",
    ):
        assert phrase in sidepanel, phrase
    for phrase in (".merge-source-note-route", ".merge-source-note-boundary", ".merge-source-note-value", "white-space: pre-wrap", "unicode-bidi: plaintext"):
        assert phrase in css, phrase

    run("shared-folder native background contract", ["node", "Extension/tests/background_harness.js"])
    run("shared-folder review Chromium package", [sys.executable, "Extension/tests/source_notes_shared_folder_merge_review_harness.py", "--extension", str(ROOT / "Extension"), "--artifacts", str(ROOT / "evidence/rev0103/focused-shared-folder-chromium")])
    run("shared-folder review Firefox package", [sys.executable, "Extension/tests/source_notes_shared_folder_merge_review_harness.py", "--extension", str(ROOT / "Extension/Firefox"), "--artifacts", str(ROOT / "evidence/rev0103/focused-shared-folder-firefox")])
    run("inherited Node merge disclosure", [sys.executable, "CLI/tests/source_notes_node_merge_review_harness.py", "--root", str(ROOT), "--artifacts", str(ROOT / "evidence/rev0103/focused-node-merge")])
    run("inherited Exchange disclosure", [sys.executable, "-m", "unittest", "-v", "CLI.tests.test_exchange_source_notes"])
    run("inherited private-transfer contract", [sys.executable, "-m", "unittest", "-v", "CLI.tests.test_source_notes_private_transfer"])
    print("\nPASS rev0103 focused shared-folder merge, Node merge, Exchange, and private-transfer Source Note replay.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (AssertionError, OSError, RuntimeError, subprocess.SubprocessError, ValueError) as exc:
        print(f"rev0103 verification failed: {exc}", file=sys.stderr)
        raise SystemExit(1)
