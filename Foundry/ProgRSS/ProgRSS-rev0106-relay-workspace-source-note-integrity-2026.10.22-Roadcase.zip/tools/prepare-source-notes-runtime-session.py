#!/usr/bin/env python3
"""Prepare a fail-closed exact-Roadcase Source Notes runtime session.

The command verifies the Roadcase, extracts only the selected shipped browser
package, records package/fixture/channel identity, and writes a case catalog,
result template, operator checklist, and finalization instructions. It does not
execute a browser and never marks a runtime row passed.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import sys
import zipfile
from typing import Any

from browser_channel_evidence import (
    ChannelEvidenceError,
    copy_channel_evidence,
    expected_version as channel_expected_version,
    load_channel_evidence_dir,
    session_record as channel_session_record,
)

from source_notes_runtime_evidence import (
    REVISION,
    SESSION_SCHEMA,
    canonical_json_bytes,
    case_catalog,
    expected_session_id,
    result_template,
    sha256_bytes,
    sha256_file,
)

SKIP_NAMES = {".DS_Store"}


def canonical_mode(raw_mode: int) -> int:
    return 0o755 if stat.S_IMODE(raw_mode) & 0o111 else 0o644


def validate_member(name: str) -> PurePosixPath:
    path = PurePosixPath(name)
    if not name or path.is_absolute() or ".." in path.parts:
        raise ValueError(f"unsafe archive member: {name!r}")
    return path


def package_prefix(family: str) -> str:
    return "Extension/Firefox/" if family == "firefox" else "Extension/"


def package_relative(name: str, family: str) -> str | None:
    prefix = package_prefix(family)
    if not name.startswith(prefix):
        return None
    relative = name[len(prefix):]
    if not relative or relative.endswith("/"):
        return None
    path = validate_member(relative)
    if path.name in SKIP_NAMES or path.suffix == ".pyc" or "__pycache__" in path.parts:
        return None
    return path.as_posix()


def archive_package_inventory(archive: zipfile.ZipFile, family: str) -> tuple[list[dict[str, Any]], dict[str, bytes]]:
    rows: list[dict[str, Any]] = []
    payloads: dict[str, bytes] = {}
    for info in sorted(archive.infolist(), key=lambda row: row.filename):
        if info.is_dir():
            continue
        validate_member(info.filename)
        relative = package_relative(info.filename, family)
        if relative is None:
            continue
        raw_mode = (info.external_attr >> 16) & 0xFFFF
        if stat.S_ISLNK(raw_mode):
            raise ValueError(f"runtime package contains a symlink: {info.filename}")
        data = archive.read(info)
        row = {
            "path": relative,
            "mode": oct(canonical_mode(raw_mode)),
            "bytes": len(data),
            "sha256": sha256_bytes(data),
        }
        rows.append(row)
        payloads[relative] = data
    if not rows or not any(row["path"] == "manifest.json" for row in rows):
        raise ValueError(f"no {family} manifest found in Roadcase")
    return rows, payloads


def inventory_digest(rows: list[dict[str, Any]]) -> str:
    return sha256_bytes(canonical_json_bytes(rows, pretty=False))


def verify_roadcase(roadcase: Path, verifier: Path) -> str:
    completed = subprocess.run(
        [sys.executable, str(verifier), "--archive", str(roadcase)],
        cwd=verifier.parent,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=180,
        check=False,
    )
    if completed.returncode:
        raise RuntimeError(f"Roadcase verification failed ({completed.returncode}):\n{completed.stdout}")
    return completed.stdout.strip()


def write_package(destination: Path, rows: list[dict[str, Any]], payloads: dict[str, bytes]) -> None:
    for row in rows:
        target = destination / PurePosixPath(row["path"])
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(payloads[row["path"]])
        os.chmod(target, int(row["mode"], 8))


def checklist(session: dict[str, Any], catalog: dict[str, Any]) -> str:
    family = session["browser"]["family"]
    package = session["package"]["directory"]
    install = session["browser"]["installMethod"]
    case_lines = "\n".join(
        f"- [ ] `{row['id']}` — {row['description']}"
        for row in catalog["cases"]
    )
    return f"""# Source Notes exact-package runtime checklist

Session: `{session['sessionId']}`  
Roadcase SHA-256: `{session['roadcase']['sha256']}`  
Package subtree SHA-256: `{session['package']['subtreeSha256']}`  
Fixture SHA-256: `{session['fixture']['sha256']}`  
Case-catalog SHA-256: `{session['caseCatalogSha256']}`  
Browser: `{family}` / `{session['browser']['channel']}` / `{session['browser']['version']}`  
Channel snapshot SHA-256: `{session['channelEvidence']['snapshotSha256']}`  
Channel snapshot captured UTC: `{session['channelEvidence']['capturedUtc']}`  
Maximum snapshot age at runtime start: `{session['channelEvidence']['maxAgeSeconds']}` seconds  
Environment class: `{session['environment']['class']}`  
Profile state: `{session['environment']['profileState']}`  
Install method: `{install}`  
Package directory: `{package}`

Do not edit the extracted package. A byte or inventory mismatch invalidates the session. Record first failure, retry, interruption, and recovery events rather than only the final state.

## Required cases

{case_lines}

## Result discipline

1. Copy `RESULT-TEMPLATE.json` to a new result file; do not overwrite the template or add custom fields.
2. Keep every case in catalog order. Use only `pass`, `fail`, `blocked`, or `not-run`.
3. Use real `YYYY-MM-DDTHH:MM:SSZ` UTC calendar values. Supply both run endpoints, keep finish at or after start, and put every attempted/blocked case and event inside that interval.
4. Give every executed or blocked case an observation and at least one unique file path under `evidence/`. A `not-run` case has no timestamp, observation, or evidence.
5. Reference every file under `evidence/`; unreferenced files are refused to reduce accidental disclosure.
6. Record observed browser/OS/profile/install identity. A passing unchanged-permission case requires complete before/after arrays for required, optional, host, and optional-host permissions; empty projections do not establish unchanged state.
7. A pass requires `currentChannelAtExecution=true`, and runtime start must be within 24 hours of the bound snapshot capture.
8. Save complete-route and selected-branch native JSON under `evidence/` and declare only `nativeArtifacts.completeRoute` and `nativeArtifacts.selectedBranch`. Native validation and semantic hashes are derived from bytes, never asserted.
9. Set operator assertions only for facts actually observed. The finalizer records them but does not authenticate them.
10. Finalize and independently verify the bundle with the commands in `FINALIZE.md`.

A prepared session is not a runtime pass. The bundle binds exact official-source payload bytes, expected channel versions, and snapshot age, but it does not authenticate the network fetch, human presence, an unmanaged machine, permission-prompt comprehension, accessibility, assistive-technology use, or unfamiliar-person comprehension.
"""


def finalize_instructions() -> str:
    return """# Finalize and verify this runtime session

After the session, keep the immutable Roadcase beside this directory and create a v3 completed result from `RESULT-TEMPLATE.json`. The finalizer refuses unknown fields, invalid/out-of-interval timestamps, incomplete passing permission projections, and unknown native-artifact roles.

```sh
python3 tools/finalize-source-notes-runtime-session.py \\
  --session-dir SESSION_DIRECTORY \\
  --roadcase FROZEN-ROADCASE.zip \\
  --result SESSION_DIRECTORY/RESULT-completed.json \\
  --attestation SESSION-ATTESTATION.json \\
  --bundle SESSION-EVIDENCE.zip \\
  --summary SESSION-FINALIZATION.json

python3 tools/verify-source-notes-runtime-evidence.py \\
  --bundle SESSION-EVIDENCE.zip \\
  --roadcase FROZEN-ROADCASE.zip \\
  --output SESSION-EVIDENCE-VERIFICATION.json
```

For cross-browser review, reverify and compare the complete evidence bundles:

```sh
python3 tools/compare-source-notes-runtime-evidence.py \\
  CHROMIUM-EVIDENCE.zip FIREFOX-RELEASE-EVIDENCE.zip FIREFOX-ESR-EVIDENCE.zip \\
  --roadcase FROZEN-ROADCASE.zip --require-browser-triad \\
  --output RUNTIME-COMPARISON.json
```

The statement is unsigned. It deliberately leaves unmanaged/current/human/accessibility/comprehension acceptance false for separate review.
"""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--roadcase", type=Path, required=True)
    parser.add_argument("--browser-family", choices=("chromium", "firefox"), required=True)
    parser.add_argument("--channel", choices=("stable", "release", "esr"), required=True)
    parser.add_argument("--browser-version", required=True)
    parser.add_argument("--channel-evidence-dir", type=Path, required=True)
    parser.add_argument("--os-build", required=True)
    parser.add_argument("--environment-class", choices=("managed", "unmanaged"), required=True)
    parser.add_argument("--profile-state", choices=("fresh", "existing", "both"), required=True)
    parser.add_argument("--install-method", required=True)
    parser.add_argument("--permission-observation", choices=("none", "automated", "human"), default="none")
    parser.add_argument("--operator-note", default="")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    roadcase = args.roadcase.resolve()
    if not roadcase.is_file():
        parser.error(f"Roadcase not found: {roadcase}")
    try:
        channel_snapshot, channel_payloads = load_channel_evidence_dir(args.channel_evidence_dir)
        expected_version = channel_expected_version(channel_snapshot, args.browser_family, args.channel)
    except (OSError, ChannelEvidenceError) as error:
        parser.error(str(error))
    if args.browser_version != expected_version:
        parser.error(
            f"browser version {args.browser_version!r} does not match bound "
            f"{args.browser_family}/{args.channel} channel version {expected_version!r}"
        )
    output = args.output.resolve()
    if output.exists() and any(output.iterdir()):
        parser.error(f"Output directory is not empty: {output}")
    output.mkdir(parents=True, exist_ok=True)

    root = Path(__file__).resolve().parents[1]
    verifier = root / "VERIFY-ROADCASE.py"
    verification_output = verify_roadcase(roadcase, verifier)

    with zipfile.ZipFile(roadcase) as archive:
        manifest_info = archive.getinfo("ROADCASE-MANIFEST.json")
        roadcase_manifest = json.loads(archive.read(manifest_info))
        rows, payloads = archive_package_inventory(archive, args.browser_family)
        fixture_name = "fixtures/source-notes/native-placement-replay.json"
        fixture = archive.read(fixture_name)

    package_dir = output / "package" / ("Firefox" if args.browser_family == "firefox" else "Extension")
    write_package(package_dir, rows, payloads)
    copy_channel_evidence(channel_payloads, output)
    package_manifest = {
        "schema": "progrss.runtime-package-manifest.v1",
        "family": args.browser_family,
        "files": rows,
        "subtreeSha256": inventory_digest(rows),
    }
    (output / "PACKAGE-MANIFEST.json").write_bytes(canonical_json_bytes(package_manifest))
    (output / "ROADCASE-VERIFY.log").write_text(verification_output + "\n", encoding="utf-8")

    session: dict[str, Any] = {
        "schema": SESSION_SCHEMA,
        "revision": REVISION,
        "sessionId": "",
        "status": "prepared",
        "preparedOnly": True,
        "roadcase": {
            "name": roadcase.name,
            "bytes": roadcase.stat().st_size,
            "sha256": sha256_file(roadcase),
            "manifestRevision": roadcase_manifest.get("revision"),
        },
        "package": {
            "family": args.browser_family,
            "directory": package_dir.relative_to(output).as_posix(),
            "files": len(rows),
            "subtreeSha256": package_manifest["subtreeSha256"],
            "manifestSha256": next(row["sha256"] for row in rows if row["path"] == "manifest.json"),
        },
        "fixture": {
            "path": fixture_name,
            "bytes": len(fixture),
            "sha256": sha256_bytes(fixture),
        },
        "browser": {
            "family": args.browser_family,
            "channel": args.channel,
            "version": args.browser_version,
            "installMethod": args.install_method,
        },
        "environment": {
            "class": args.environment_class,
            "profileState": args.profile_state,
            "osBuild": args.os_build,
            "permissionObservation": args.permission_observation,
            "operatorNote": args.operator_note,
        },
        "channelEvidence": channel_session_record(channel_snapshot, channel_payloads),
        "claimBoundary": {
            "runtimeExecuted": False,
            "runtimePass": False,
            "unmanagedBrowserAcceptance": False,
            "currentStableAcceptance": False,
            "humanPermissionPromptObservation": False,
            "accessibilityConformance": False,
            "assistiveTechnologyEvidence": False,
            "unfamiliarPersonComprehension": False,
            "unsignedOperatorEvidence": True,
        },
    }
    session["sessionId"] = expected_session_id(session)
    catalog = case_catalog()
    catalog_bytes = canonical_json_bytes(catalog)
    session["caseCatalogSha256"] = sha256_bytes(catalog_bytes)
    template = result_template(session, catalog)
    template_bytes = canonical_json_bytes(template)
    session["resultTemplateSha256"] = sha256_bytes(template_bytes)

    (output / "SESSION.json").write_bytes(canonical_json_bytes(session))
    (output / "CASE-CATALOG.json").write_bytes(catalog_bytes)
    (output / "RESULT-TEMPLATE.json").write_bytes(template_bytes)
    (output / "CHECKLIST.md").write_text(checklist(session, catalog), encoding="utf-8")
    (output / "FINALIZE.md").write_text(finalize_instructions(), encoding="utf-8")
    (output / "evidence").mkdir(exist_ok=True)
    print(json.dumps({
        "status": "prepared",
        "session": str(output / "SESSION.json"),
        "package": str(package_dir),
        "roadcaseSha256": session["roadcase"]["sha256"],
        "packageSha256": session["package"]["subtreeSha256"],
        "channelSnapshotSha256": session["channelEvidence"]["snapshotSha256"],
        "channelCapturedUtc": session["channelEvidence"]["capturedUtc"],
        "caseCatalogSha256": session["caseCatalogSha256"],
        "resultTemplateSha256": session["resultTemplateSha256"],
        "cases": len(catalog["cases"]),
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
