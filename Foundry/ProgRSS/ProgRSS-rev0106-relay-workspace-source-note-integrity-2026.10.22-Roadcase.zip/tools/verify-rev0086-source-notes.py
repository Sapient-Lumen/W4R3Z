#!/usr/bin/env python3
"""Replay the bounded rev0086 Source Notes authoring gate.

This is deterministic managed local evidence. It is not unmanaged-browser,
assistive-technology, accessibility-conformance, or unfamiliar-participant
fieldwork.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
from typing import Sequence

ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / "fixtures" / "source-notes" / "rev0080-extension-permissions.json"
PERMISSION_FIELDS = (
    "manifest_version",
    "version",
    "permissions",
    "optional_permissions",
    "host_permissions",
    "optional_host_permissions",
)


def run(name: str, command: Sequence[str], *, env: dict[str, str] | None = None, timeout: int = 360) -> None:
    print(f"\n== {name} ==")
    completed = subprocess.run(
        list(command),
        cwd=ROOT,
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=timeout,
        check=False,
    )
    if completed.stdout:
        print(completed.stdout.rstrip())
    if completed.returncode:
        raise RuntimeError(f"{name} failed with exit status {completed.returncode}")


def current_permission_projection(path: Path) -> dict:
    document = json.loads(path.read_text(encoding="utf-8"))
    return {key: document[key] for key in PERMISSION_FIELDS if key in document}


def verify_permissions() -> None:
    baseline = json.loads(BASELINE.read_text(encoding="utf-8"))
    mismatches: list[str] = []
    for relative, expected in baseline["manifests"].items():
        actual = current_permission_projection(ROOT / relative)
        if actual != expected:
            mismatches.append(relative)
    if mismatches:
        raise RuntimeError(f"rev0080 permission projection changed: {', '.join(mismatches)}")
    print("rev0080 manifest permission projections: unchanged")


def verify_generated_firefox() -> None:
    pairs = (
        ("background.js", "Firefox/background.js"),
        ("shared/core.js", "Firefox/shared/core.js"),
        ("shared/shared-folder.js", "Firefox/shared/shared-folder.js"),
        ("sidepanel/app.js", "Firefox/sidepanel/app.js"),
        ("sidepanel/app.css", "Firefox/sidepanel/app.css"),
        ("sidepanel/index.html", "Firefox/sidepanel/index.html"),
    )
    changed = [
        f"{left} != {right}"
        for left, right in pairs
        if (ROOT / "Extension" / left).read_bytes() != (ROOT / "Extension" / right).read_bytes()
    ]
    if changed:
        raise RuntimeError("generated Firefox sibling drift: " + "; ".join(changed))
    print("generated Firefox Source Notes authoring paths: byte-identical to shared sources")


def verify_authoring_surface_markers() -> None:
    panel = (ROOT / "Extension" / "sidepanel" / "app.js").read_text(encoding="utf-8")
    background = (ROOT / "Extension" / "background.js").read_text(encoding="utf-8")
    cli = (ROOT / "CLI" / "progrss.py").read_text(encoding="utf-8")
    required = {
        "Extension side panel placement editor": (panel, "set-source-placement-reason"),
        "Extension side panel local-only disclosure": (panel, "publishes nothing, contacts nobody, creates no schedule"),
        "Extension background stale guard": (background, "STALE_SOURCE_NOTE"),
        "Extension background guarded undo": (background, "STALE_SOURCE_NOTE_UNDO"),
        "CLI placement command": (cli, "cmd_workspace_source_note"),
        "CLI no-consequence disclosure": (cli, "Nothing was published, contacted, scheduled"),
    }
    missing = [name for name, (text, marker) in required.items() if marker not in text]
    if missing:
        raise RuntimeError("missing shipped authoring surface marker(s): " + ", ".join(missing))
    print("shipped CLI and Extension placement-authoring markers: present")


def main() -> int:
    try:
        run("cross-runtime reference contract", ["sh", "tools/verify-source-notes-contract.sh"])
        run(
            "Python shipped-entrypoint corpus",
            [sys.executable, "-m", "unittest", "-v", "CLI.tests.test_source_notes_entrypoints"],
        )
        run(
            "CLI shipped placement-authoring command",
            [
                sys.executable,
                "-m",
                "unittest",
                "-v",
                "CLI.tests.test_command_line.CommandLineTests.test_workspace_source_note_edits_one_direct_placement_offline",
            ],
            timeout=240,
        )
        run(
            "Node branch and merge-review paths",
            [
                sys.executable,
                "-m",
                "unittest",
                "-v",
                "CLI.tests.test_node_server.NodeServerTests.test_node_owned_branch_operation_is_reviewed_atomic_idempotent_and_snapshot_backed",
                "CLI.tests.test_node_server.NodeServerTests.test_merge_review_is_three_way_read_only_and_requires_admin_origin",
            ],
            timeout=360,
        )
        run("Chromium-source browser core", ["node", "Extension/tests/source_notes_entrypoints_harness.js"])
        firefox_env = dict(os.environ)
        firefox_env["PROGRSS_EXTENSION_ROOT"] = "Firefox"
        run(
            "generated-Firefox browser core",
            ["node", "Extension/tests/source_notes_entrypoints_harness.js"],
            env=firefox_env,
        )
        run(
            "Extension background continuity and guarded authoring",
            ["node", "Extension/tests/background_harness.js"],
            timeout=360,
        )
        run(
            "Extension placement-authoring static boundary",
            [
                sys.executable,
                "-m",
                "unittest",
                "-v",
                "Extension.tests.test_static.JavaScriptTests.test_source_note_authoring_is_placement_scoped_local_and_stale_safe",
            ],
        )
        run(
            "Managed side-panel authoring and accessibility regression smoke",
            [sys.executable, "Extension/tests/browser_smoke.py"],
            timeout=600,
        )
        verify_permissions()
        verify_generated_firefox()
        verify_authoring_surface_markers()
    except Exception as exc:
        print(f"rev0086 Source Notes verification failed: {exc}", file=sys.stderr)
        return 1
    print("\nrev0086 Source Notes authoring gate: PASS")
    print("classification: managed local replay; unmanaged browsers, real assistive technology, and human fieldwork not run")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
