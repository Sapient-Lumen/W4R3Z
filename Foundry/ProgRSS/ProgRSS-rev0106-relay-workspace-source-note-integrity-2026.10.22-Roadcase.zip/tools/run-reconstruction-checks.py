#!/usr/bin/env python3
"""Run deterministic local checks without installing or downloading dependencies."""
from __future__ import annotations
import json
import os
from pathlib import Path
import py_compile
import shutil
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
OUT=Path('/mnt/data/progrss-logs'); OUT.mkdir(parents=True,exist_ok=True)
SKIP={'.git','node_modules','__pycache__','.pytest_cache','.mypy_cache','.ruff_cache'}
results=[]

def record(name,classification,command=None,returncode=0,output='',details=None):
    item={'name':name,'classification':classification,'returncode':returncode,'pass':returncode==0,'command':command,'output':output[-12000:]}
    if details is not None: item['details']=details
    results.append(item); return item

def run(name,cmd,cwd=ROOT,classification='mandatory',timeout=180,env=None):
    try:
        p=subprocess.run(cmd,cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=timeout,env=env)
        return record(name,classification,cmd,p.returncode,p.stdout)
    except subprocess.TimeoutExpired as exc:
        return record(name,classification,cmd,124,(exc.stdout or '')+'\nTIMEOUT')
    except FileNotFoundError as exc:
        return record(name,classification,cmd,127,str(exc))

def files_with(suffixes):
    for p in ROOT.rglob('*'):
        if not p.is_file() or any(part in SKIP for part in p.relative_to(ROOT).parts): continue
        if p.suffix.lower() in suffixes: yield p

run('source-notes cross-runtime contract',[str(ROOT/'tools'/'verify-source-notes-contract.sh')])
run('fieldwork harness static checks',[sys.executable,str(ROOT/'tools'/'verify-fieldwork-harness.py')])

# Compile every first-party Python file without writing pyc files into the tree.
py_fail=[]; py_count=0
for p in files_with({'.py'}):
    py_count+=1
    try: compile(p.read_bytes(),str(p),'exec')
    except Exception as exc: py_fail.append(f'{p.relative_to(ROOT)}: {exc}')
record('first-party Python syntax','mandatory',details={'files':py_count,'failures':py_fail},returncode=1 if py_fail else 0,output='\n'.join(py_fail))

# Parse every first-party JSON file.
json_fail=[]; json_count=0
for p in files_with({'.json'}):
    json_count+=1
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as exc: json_fail.append(f'{p.relative_to(ROOT)}: {exc}')
record('first-party JSON parse','mandatory',details={'files':json_count,'failures':json_fail},returncode=1 if json_fail else 0,output='\n'.join(json_fail))

# Node syntax checks are independent and avoid executing project code.
node=shutil.which('node'); js_files=[p for p in files_with({'.js','.mjs','.cjs'}) if p.stat().st_size<5_000_000 and not p.name.endswith('.min.js')]
js_fail=[]
if node:
    for p in js_files:
        proc=subprocess.run([node,'--check',str(p)],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        if proc.returncode: js_fail.append(f'{p.relative_to(ROOT)}\n{proc.stdout}')
    record('first-party JavaScript syntax','mandatory',returncode=1 if js_fail else 0,output='\n'.join(js_fail),details={'files':len(js_files),'failures':len(js_fail)})
else:
    record('first-party JavaScript syntax','mandatory',returncode=127,output='node is unavailable',details={'files':len(js_files)})

# POSIX shell parse checks.
sh=shutil.which('sh'); sh_files=list(files_with({'.sh'})); sh_fail=[]
if sh:
    for p in sh_files:
        proc=subprocess.run([sh,'-n',str(p)],cwd=ROOT,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        if proc.returncode: sh_fail.append(f'{p.relative_to(ROOT)}\n{proc.stdout}')
    record('first-party shell syntax','mandatory',returncode=1 if sh_fail else 0,output='\n'.join(sh_fail),details={'files':len(sh_files),'failures':len(sh_fail)})

# Existing Python tests: run only when test files outside the new contract exist and pytest is installed.
external_pytests=[p for p in ROOT.rglob('test*.py') if p.is_file() and 'source_notes_contract' not in p.parts and not any(part in SKIP for part in p.relative_to(ROOT).parts)]
if external_pytests:
    check=subprocess.run([sys.executable,'-c','import pytest'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if check.returncode==0:
        env=dict(os.environ); env.update({'CI':'1','NO_COLOR':'1','PIP_NO_INDEX':'1','HTTP_PROXY':'http://127.0.0.1:9','HTTPS_PROXY':'http://127.0.0.1:9','NO_PROXY':'127.0.0.1,localhost'})
        run('existing Python test suite',[sys.executable,'-m','pytest','-q'],classification='native-replay',timeout=300,env=env)
    else:
        record('existing Python test suite','native-replay-unavailable',returncode=0,output='pytest is not installed; no dependency installation attempted',details={'testFiles':[str(p.relative_to(ROOT)) for p in external_pytests]})
else:
    record('existing Python test suite','native-replay-not-present',returncode=0,output='no external test*.py files detected')

# Existing npm tests only when dependencies are already present. Never npm install.
for package in ROOT.rglob('package.json'):
    if any(part in SKIP for part in package.relative_to(ROOT).parts): continue
    try: data=json.loads(package.read_text(encoding='utf-8'))
    except Exception: continue
    if not isinstance(data.get('scripts'),dict) or 'test' not in data['scripts']: continue
    cwd=package.parent; npm=shutil.which('npm')
    name=f"npm test: {cwd.relative_to(ROOT) or Path('.')}"
    if npm and (cwd/'node_modules').is_dir():
        env=dict(os.environ); env.update({'CI':'1','NO_COLOR':'1','npm_config_offline':'true','npm_config_audit':'false','npm_config_fund':'false','HTTP_PROXY':'http://127.0.0.1:9','HTTPS_PROXY':'http://127.0.0.1:9','NO_PROXY':'127.0.0.1,localhost'})
        run(name,[npm,'test','--silent'],cwd=cwd,classification='native-replay',timeout=300,env=env)
    else:
        record(name,'native-replay-unavailable',returncode=0,output='npm or pre-existing node_modules unavailable; no dependency installation attempted')

mandatory_ok=all(item['pass'] for item in results if item['classification']=='mandatory')
native_attempts=[item for item in results if item['classification']=='native-replay']
native_ok=bool(native_attempts) and all(item['pass'] for item in native_attempts)
summary={
 'generatedUtc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
 'mandatoryPass':mandatory_ok,
 'nativeReplayAttempted':bool(native_attempts),
 'nativeReplayPass':native_ok,
 'releaseClassification':'candidate-only until native CLI/Node/Extension/browser replay and human fieldwork are separately evidenced',
 'results':results,
}
(OUT/'reconstruction-checks.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
with (OUT/'reconstruction-checks.md').open('w',encoding='utf-8') as f:
    f.write('# Reconstruction checks\n\n')
    f.write(f"- Mandatory reconstruction checks: {'PASS' if mandatory_ok else 'FAIL'}\n")
    f.write(f"- Existing native replay attempted: {'yes' if native_attempts else 'no'}\n")
    f.write(f"- Existing native replay result: {'PASS' if native_ok else 'not established'}\n")
    f.write(f"- Classification: {summary['releaseClassification']}\n\n")
    for item in results:
        f.write(f"## {'PASS' if item['pass'] else 'FAIL'} — {item['name']}\n\n")
        f.write(f"Classification: `{item['classification']}`\n\n")
        if item['command']: f.write('Command: `'+ ' '.join(str(x) for x in item['command']) +'`\n\n')
        if item['output'].strip(): f.write('```text\n'+item['output'].strip()+'\n```\n\n')
print(json.dumps({'mandatoryPass':mandatory_ok,'nativeReplayAttempted':bool(native_attempts),'nativeReplayPass':native_ok}))
raise SystemExit(0 if mandatory_ok else 1)
