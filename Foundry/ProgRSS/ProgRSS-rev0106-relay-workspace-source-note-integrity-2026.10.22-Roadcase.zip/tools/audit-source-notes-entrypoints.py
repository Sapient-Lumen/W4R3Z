#!/usr/bin/env python3
"""Freeze the rev0087 Source Notes shipped-entrypoint and permission matrices."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = ROOT / "evidence" / "rev0087"
BASELINE = ROOT / "fixtures" / "source-notes" / "rev0080-extension-permissions.json"
MATRIX_SCHEMA = "progrss.source-notes.entrypoint-matrix.v1"
AUDIT_SCHEMA = "progrss.source-notes.permission-audit.v1"
REVISION = "rev0087-source-notes-runtime-kit"
CLASSIFICATION = "candidate-managed-noncurrent-runtime-preflight"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def has(path: str, marker: str) -> bool:
    target = ROOT / path
    return target.is_file() and marker in target.read_text(encoding="utf-8", errors="replace")


def row(identifier: str, surface: str, behavior: str, status: str, evidence_type: str,
        command: str, paths: list[str], evidence: list[str], limitation: str = "") -> dict[str, Any]:
    return {
        "id": identifier,
        "surface": surface,
        "behavior": behavior,
        "status": status,
        "evidenceType": evidence_type,
        "command": command,
        "paths": paths,
        "evidence": evidence,
        "limitation": limitation,
    }


def main() -> int:
    cli_summary = json.loads((EVIDENCE / "cli-modules-summary.json").read_text(encoding="utf-8"))
    full_cli = bool(cli_summary.get("allPassed"))
    focused = has("evidence/rev0087/focused-authoring-verification.log", "rev0087-source-notes-runtime-kit gate: PASS")
    extension = has("evidence/rev0087/extension-tests.log", "EXTENSION_TESTS_RC=0")
    browser_reason = has("evidence/rev0087/extension-browser-smoke-source-notes.log", "PASS side panel: placement-scoped Source Notes")
    authoring_audit = has("SOURCE-NOTES-AUTHORING-AUDIT.json", '"pass": true')
    runtime_audit = has("SOURCE-NOTES-RUNTIME-AUDIT.json", '"pass": true')
    pass_status = "pass" if focused else "not-established"
    focus_log = ["evidence/rev0087/focused-authoring-verification.log"]

    rows = [
        row("python-placement-contract", "CLI Python", "Validate and canonicalize one optional reason on one direct folder/source placement; reject folder ownership, invalid Unicode, over-limit values, and conflicting duplicates.", pass_status, "native-unit-replay", "python3 -m unittest -v CLI.tests.test_source_notes_entrypoints", ["CLI/relay.py", "CLI/source_notes_native.py", "CLI/tests/test_source_notes_entrypoints.py"], focus_log),
        row("python-export-contents", "CLI Python", "Export native bundles and disclose every reason-bearing placement with its folder path.", pass_status, "native-unit-replay", "python3 -m unittest -v CLI.tests.test_source_notes_entrypoints", ["CLI/relay.py"], focus_log),
        row("python-branch-import", "CLI Python", "Keep selected-branch reasons, omit out-of-branch reasons, remap identities, and preserve duplicate-source placements independently.", pass_status, "native-unit-replay", "python3 -m unittest -v CLI.tests.test_source_notes_entrypoints", ["CLI/relay.py"], focus_log),
        row("cli-opml-process", "CLI executable", "Emit OPML without Source Note values and report exact omitted placement keys from the shipped command process.", "pass" if focused and full_cli else "not-established", "shipped-process-replay", "CLI/progrss workspace share-folder … --format opml --json", ["CLI/progrss", "CLI/relay.py", "CLI/tests/test_source_notes_entrypoints.py"], [*focus_log, "evidence/rev0087/cli-modules-summary.json"]),
        row("python-three-way-update", "CLI Python", "Compare base, recipient, and curator reasons per placement; auto-preserve only one-sided/equal changes; require exact per-conflict decisions; reject stale, partial, unknown, or invalid choices.", pass_status, "native-unit-replay", "python3 -m unittest -v CLI.tests.test_source_notes_entrypoints", ["CLI/relay.py"], focus_log),
        row("node-branch-preview-commit", "Loopback Node", "Disclose Source Notes in branch options and preview, then preserve exact reasons in reviewed atomic branch adoption.", pass_status, "native-node-replay", "python3 -m unittest -v CLI.tests.test_node_server.NodeServerTests.test_node_owned_branch_operation_is_reviewed_atomic_idempotent_and_snapshot_backed", ["CLI/node_server.py", "CLI/tests/test_node_server.py"], focus_log),
        row("node-merge-review", "Loopback Node", "Expose placement-scoped Source Note divergence in the read-only three-way merge review.", pass_status, "native-node-replay", "python3 -m unittest -v CLI.tests.test_node_server.NodeServerTests.test_merge_review_is_three_way_read_only_and_requires_admin_origin", ["CLI/node_server.py", "CLI/tests/test_node_server.py"], focus_log),
        row("chromium-shared-core", "Chromium source package", "Run schema, canonicalization, artifact digest coverage, complete disclosure, branch selection, import remapping, and OPML omission through the shipped shared modules.", pass_status, "managed-node-harness", "node Extension/tests/source_notes_entrypoints_harness.js", ["Extension/shared/core.js", "Extension/shared/shared-folder.js", "Extension/tests/source_notes_entrypoints_harness.js"], focus_log, "Node-managed module replay, not an installed unmanaged Chromium run."),
        row("extension-background", "Extension background", "Preserve reasons through real background export/import/update handlers; author and clear one exact placement with version/prior-value guards; refuse stale saves and stale undo; report OPML omission.", pass_status, "managed-background-harness", "node Extension/tests/background_harness.js", ["Extension/background.js", "Extension/tests/background_harness.js"], focus_log, "Browser APIs are simulated by the existing harness."),
        row("extension-recipient-disclosure", "Extension side panel", "Show the curator-authored placement reason, its folder route, author attribution, and the explicit non-safety-claim explanation.", "pass" if browser_reason else "not-established", "managed-browser-smoke", "python3 Extension/tests/browser_smoke.py", ["Extension/sidepanel/app.js", "Extension/tests/browser_smoke.py"], ["evidence/rev0087/extension-browser-smoke-source-notes.log"], "Managed automation is rendering evidence, not unfamiliar-participant comprehension or assistive-technology evidence."),
        row("firefox-generated-core", "Generated Firefox sibling", "Replay the same shared Source Notes corpus and digest-tamper refusal against the generated sibling bytes.", pass_status, "managed-node-harness", "PROGRSS_EXTENSION_ROOT=Firefox node Extension/tests/source_notes_entrypoints_harness.js", ["Extension/Firefox/shared/core.js", "Extension/Firefox/shared/shared-folder.js"], focus_log, "Generated-sibling module replay, not Firefox Release or ESR runtime evidence."),
        row("firefox-generated-background", "Generated Firefox sibling", "Retain the generated Firefox background authoring handlers, side-panel bytes, and complete Extension regression suite.", "pass" if extension else "not-established", "managed-harness-regression", "sh Extension/tests/run.sh", ["Extension/Firefox/background.js", "Extension/Firefox/sidepanel/app.js", "Extension/tests/firefox_background_harness.js"], ["evidence/rev0087/extension-tests.log"], "No Firefox Release or ESR binary was exercised by this row."),
        row("browser-permission-boundary", "Chromium and Firefox manifests", "Keep required, optional, host, and optional-host permission projections identical to the supplied rev0080 manifests.", pass_status, "structured-baseline-comparison", "python3 tools/verify-rev0087-source-notes.py", ["Extension/manifest.json", "Extension/platform/firefox-manifest.json", "Extension/Firefox/manifest.json", "fixtures/source-notes/rev0080-extension-permissions.json"], ["BROWSER-PERMISSION-AUDIT.json", *focus_log]),
        row("cli-source-note-authoring", "CLI user control", "Add, edit, or clear one optional reason on one named direct placement through the shipped offline command, writing a new backup and preserving the input rollback copy.", "pass" if focused and full_cli and authoring_audit else "not-established", "shipped-process-and-regression", "CLI/progrss workspace source-note … (--reason TEXT | --clear) --output NEW_BACKUP", ["CLI/progrss.py", "CLI/README.md", "CLI/tests/test_command_line.py"], ["SOURCE-NOTES-AUTHORING-AUDIT.json", "evidence/rev0087/cli-test_command_line.log", *focus_log], "The CLI is file-oriented; its rollback is the unchanged input rather than a timed in-process undo."),
        row("extension-source-note-authoring", "Extension side-panel user control", "Add, edit, clear, cancel, and undo a reason beside one chosen direct placement; keep a draft through ordinary interruption; refuse stale save/undo; preserve two-folder independence; expose local-only consequence text and keyboard/reflow/forced-colors/reduced-motion regression checks.", "pass" if focused and extension and browser_reason and authoring_audit else "not-established", "managed-browser-and-background-replay", "sh Extension/tests/run.sh", ["Extension/background.js", "Extension/sidepanel/app.js", "Extension/sidepanel/app.css", "Extension/sidepanel/index.html", "Extension/tests/background_harness.js", "Extension/tests/browser_smoke.py", "Extension/tests/test_static.py"], ["SOURCE-NOTES-AUTHORING-AUDIT.json", "evidence/rev0087/extension-tests.log", "evidence/rev0087/extension-browser-smoke-source-notes.log"], "The loopback Node receives no authoring endpoint because it has no corresponding local folder-edit surface. Managed checks are not accessibility conformance or real assistive-technology evidence."),
        row("available-chromium-managed-runtime-preflight", "Available Debian Chromium", "Run the real installed extension in two live views with a fresh persistent profile, restart, native artifacts, stale-save/undo refusal, integrity refusal, and divergent-copy resolution.", "pass" if runtime_audit else "not-established", "managed-noncurrent-runtime-preflight", "python3 Extension/tests/source_notes_installed_acceptance.py …", ["Extension/tests/source_notes_installed_acceptance.py", "SOURCE-NOTES-RUNTIME-AUDIT.json"], ["SOURCE-NOTES-RUNTIME-AUDIT.json", "evidence/rev0087/available-chromium-worktree-runtime.json", "evidence/rev0087/available-chromium-worktree-runtime.log"], "Chromium 144, headed virtual display, policy-declared automation, and worktree-bound package identity. This is not current, unmanaged, human permission-prompt, Firefox, or final-Roadcase evidence."),
        row("unmanaged-chromium-runtime", "Chromium Stable", "Install and run the exact packaged candidate in an unmanaged current Chromium profile.", "not-run", "fieldwork-gate", "not run", [], [], "Managed non-current preflight cannot substitute for this run."),
        row("firefox-release-runtime", "Firefox Release", "Install and run the exact generated sibling in current Firefox Release.", "not-run", "fieldwork-gate", "not run", [], [], "Generated-file parity is not runtime evidence."),
        row("firefox-esr-runtime", "Firefox ESR", "Install and run the exact generated sibling in current Firefox ESR.", "not-run", "fieldwork-gate", "not run", [], [], "Generated-file parity is not runtime evidence."),
        row("assistive-and-participant-fieldwork", "Unfamiliar participants and assistive technology", "Observe curator and recipient comprehension, privacy expectations, and use with screen reader, Braille, voice, switch, high zoom, forced colors, reduced motion, fatigue, and interruption.", "not-run", "fieldwork-gate", "not run", [], [], "No automated result may close this row."),
    ]

    baseline = json.loads(BASELINE.read_text(encoding="utf-8"))
    permission_rows = []
    for relative, expected in baseline["manifests"].items():
        current_doc = json.loads((ROOT / relative).read_text(encoding="utf-8"))
        actual = {key: current_doc[key] for key in baseline["fields"] if key in current_doc}
        permission_rows.append({
            "path": relative,
            "unchanged": actual == expected,
            "baseline": expected,
            "current": actual,
            "currentSha256": sha256(ROOT / relative),
        })
    permission_audit = {
        "schema": AUDIT_SCHEMA,
        "revision": REVISION,
        "baselineArchive": baseline["sourceArchive"],
        "baselineArchiveSha256": baseline["sourceArchiveSha256"],
        "comparisonFields": baseline["fields"],
        "allUnchanged": all(item["unchanged"] for item in permission_rows),
        "manifests": permission_rows,
        "interpretation": "Structured permission projection only. Platform-specific manifest keys remain separate and are not treated as permission deltas.",
    }
    (ROOT / "BROWSER-PERMISSION-AUDIT.json").write_text(json.dumps(permission_audit, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    with (ROOT / "BROWSER-PERMISSION-AUDIT.md").open("w", encoding="utf-8") as handle:
        handle.write("# Browser permission audit — rev0087\n\n")
        handle.write(f"Baseline: `{baseline['sourceArchive']}` (`{baseline['sourceArchiveSha256']}`)\n\n")
        handle.write("Compared fields: `manifest_version`, `version`, required permissions, optional permissions, host permissions, and optional host permissions.\n\n")
        for item in permission_rows:
            handle.write(f"- `{item['path']}`: **{'UNCHANGED' if item['unchanged'] else 'CHANGED'}**\n")
        handle.write("\nPlatform-specific sidebar/background/Gecko keys are reviewed separately; they are not collapsed into a false byte-identical-manifest claim.\n")

    matrix = {
        "schema": MATRIX_SCHEMA,
        "revision": REVISION,
        "productLineage": {"revision": "rev0080", "version": "0.80.0"},
        "classification": CLASSIFICATION,
        "summary": {
            "pass": sum(item["status"] == "pass" for item in rows),
            "open": sum(item["status"] == "open" for item in rows),
            "notRun": sum(item["status"] == "not-run" for item in rows),
            "notEstablished": sum(item["status"] == "not-established" for item in rows),
            "fullCliRegression": full_cli,
            "fullExtensionRegression": extension,
            "permissionProjectionUnchanged": permission_audit["allUnchanged"],
        },
        "rows": rows,
    }
    (ROOT / "SOURCE-NOTES-ENTRYPOINT-MATRIX.json").write_text(json.dumps(matrix, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    with (ROOT / "SOURCE-NOTES-ENTRYPOINT-MATRIX.md").open("w", encoding="utf-8") as handle:
        handle.write("# Source Notes shipped-entrypoint matrix — rev0087\n\n")
        handle.write("A pass means the named managed local replay succeeded for this exact candidate. It does not imply an unmanaged browser, human-comprehension, accessibility-conformance, or assistive-technology pass.\n\n")
        handle.write("| Surface | Behavior | Status | Evidence | Limitation |\n|---|---|---:|---|---|\n")
        for item in rows:
            evidence_text = ", ".join(f"`{value}`" for value in item["evidence"]) or "—"
            limitation = item["limitation"].replace("|", "\\|") or "—"
            behavior = item["behavior"].replace("|", "\\|")
            handle.write(f"| {item['surface']} | {behavior} | **{item['status']}** | {evidence_text} | {limitation} |\n")
        handle.write("\n## Next release-blocking rows\n\n")
        handle.write("First seal the immutable final Roadcase as external managed evidence; then run it in unmanaged current Chromium Stable, current Firefox Release, and current Firefox ESR. Then conduct unfamiliar-curator/recipient and real assistive-technology fieldwork. Do not convert generated-file parity or managed automation into runtime or human evidence.\n")
    print(json.dumps(matrix["summary"], sort_keys=True))
    return 0 if focused and full_cli and extension and browser_reason and authoring_audit and runtime_audit and permission_audit["allUnchanged"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
