#!/usr/bin/env python3
"""Audit the rev0096 Advanced Workbench placement-reason preservation fix."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0096-source-notes-workbench-preservation"
EVIDENCE = ROOT / "evidence" / "rev0096"
JSON_OUT = ROOT / "SOURCE-NOTES-WORKBENCH-PRESERVATION-AUDIT.json"
MD_OUT = ROOT / "SOURCE-NOTES-WORKBENCH-PRESERVATION-AUDIT.md"


def parse_harness_log(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end < start:
        raise AssertionError(f"missing JSON result in {path}")
    row = json.loads(text[start : end + 1])
    assert row["count"] == 11, row
    assert len(row["passed"]) == 11, row
    assert "PASS Workbench Source Notes collection preservation: 11 cases" in text
    return row


def main() -> None:
    reproduction = json.loads((EVIDENCE / "parent-workbench-source-note-loss.json").read_text(encoding="utf-8"))
    assert reproduction["schema"] == "progrss.source-notes.workbench-collection-loss-reproduction.v1"
    assert reproduction["candidateRevision"] == REVISION
    assert reproduction["parentArchiveSha256"] == "d1ff9b25af231829506ba73a2a72cb7633a11ab8130476b5be486c6df5411745"
    assert reproduction["parentErasedAllReasonsInEditedCollection"] is True
    assert reproduction["parentPreservedIndependentFolderReason"] is True
    assert reproduction["networkActivity"] is False
    assert reproduction["installedBrowserRuntime"] is False

    chromium = parse_harness_log(EVIDENCE / "workbench-preservation-chromium.log")
    firefox = parse_harness_log(EVIDENCE / "workbench-preservation-firefox.log")
    assert chromium["passed"] == firefox["passed"]

    chromium_app = ROOT / "Extension" / "workbench" / "scripts" / "progrss-app.js"
    firefox_app = ROOT / "Extension" / "Firefox" / "workbench" / "scripts" / "progrss-app.js"
    source = chromium_app.read_text(encoding="utf-8")
    assert chromium_app.read_bytes() == firefox_app.read_bytes()
    for needle in (
        "const prior=old?C.cleanCollection(old):null",
        "const priorSources=new Map",
        "previous&&Object.prototype.hasOwnProperty.call(previous,'reason')",
        "member.reason=previous.reason",
        "const clean=C.cleanCollection(candidate)",
    ):
        assert needle in source, needle

    harness = (ROOT / "Extension" / "tests" / "source_notes_workbench_collection_harness.py").read_text(encoding="utf-8")
    for needle in (
        "title-only edit preserves selected placement reasons and independent folders",
        'passed.append(f"{label} conflict refuses without mutation")',
        "for label, duplicate in",
        "new placement receives no automatic reason",
        "not await page.evaluate(\"globalThis.__nodeFetchRequests.length\")",
    ):
        assert needle in harness, needle

    result = {
        "schema": "progrss.source-notes.workbench-preservation-audit.v1",
        "revision": REVISION,
        "pass": True,
        "parent": {
            "archive": reproduction["parentArchive"],
            "sha256": reproduction["parentArchiveSha256"],
            "titleOnlyEditErasedAllReasonsInEditedCollection": True,
            "independentFolderReasonSurvived": True,
        },
        "candidate": {
            "chromiumCases": chromium["count"],
            "firefoxCases": firefox["count"],
            "sharedWorkbenchBytesIdentical": True,
            "preservesSelectedSourceReasonsByIdentity": True,
            "newPlacementsReceiveNoInventedReason": True,
            "deliberateRemovalRemovesOnlyThatPlacement": True,
            "conflictingOrInvalidPriorPlacementsRefuseWithoutMutation": True,
            "networkActivity": False,
        },
        "scope": {
            "evidenceType": "managed shipped Advanced Workbench UI path with deterministic in-page persistence backend",
            "installedBrowserRuntime": False,
            "humanComprehension": False,
            "accessibilityConformance": False,
        },
    }
    JSON_OUT.write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    MD_OUT.write_text(
        "# Source Notes Workbench preservation audit\n\n"
        f"Revision: `{REVISION}`\n\n"
        "## Reproduced parent failure\n\n"
        "A title-only save through the shipped Advanced Workbench rebuilt direct source members as `{kind,id}` and erased every Source Note in the edited collection. An independent folder was not changed.\n\n"
        "## Candidate result\n\n"
        "- Chromium-source Workbench: **11/11** focused cases passed.\n"
        "- Generated-Firefox Workbench: **11/11** focused cases passed.\n"
        "- Shared Workbench product bytes are identical.\n"
        "- Existing selected placements preserve canonical reasons by source identity.\n"
        "- A deliberate uncheck removes only that placement and its reason.\n"
        "- A newly selected source receives no invented reason.\n"
        "- Conflicting duplicate, wrong-level, or invalid prior reason data refuses the save without mutation.\n"
        "- The harness observed no network requests.\n\n"
        "## Scope\n\n"
        "This is managed shipped-UI-path regression evidence with a deterministic persistence backend. It is not installed-browser, target-host, participant, privacy-comprehension, assistive-technology, or accessibility-conformance evidence.\n",
        encoding="utf-8",
    )
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
