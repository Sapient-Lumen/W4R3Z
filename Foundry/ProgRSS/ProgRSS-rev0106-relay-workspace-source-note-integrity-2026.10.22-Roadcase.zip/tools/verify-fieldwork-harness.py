#!/usr/bin/env python3
from __future__ import annotations
import json
from html.parser import HTMLParser
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
HERE = ROOT / "fieldwork" / "source-notes"

class AuditParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids=set(); self.labels=[]; self.dialogs=0; self.statuses=0; self.csp=""
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if 'id' in a:
            if a['id'] in self.ids: raise AssertionError(f"duplicate id: {a['id']}")
            self.ids.add(a['id'])
        if tag=='label': self.labels.append(a.get('for'))
        if tag=='dialog': self.dialogs+=1
        if a.get('role')=='status': self.statuses+=1
        if tag=='meta' and a.get('http-equiv','').lower()=='content-security-policy': self.csp=a.get('content','')

html=(HERE/'index.html').read_text(encoding='utf-8')
js=(HERE/'app.js').read_text(encoding='utf-8')
css=(HERE/'styles.css').read_text(encoding='utf-8')
parser=AuditParser(); parser.feed(html)
assert parser.dialogs==1
assert parser.statuses>=3
for directive in ["default-src 'none'", "connect-src 'none'", "object-src 'none'", "base-uri 'none'", "form-action 'none'"]:
    assert directive in parser.csp, directive
for forbidden in ['localStorage','sessionStorage','indexedDB','fetch(','XMLHttpRequest','WebSocket','EventSource','navigator.sendBeacon','serviceWorker.register']:
    assert forbidden not in js, forbidden
assert 'innerHTML' not in js
assert 'prefers-reduced-motion' in css
assert 'forced-colors: active' in css
assert ':focus-visible' in css
json.loads((HERE/'EVIDENCE-SCHEMA.json').read_text(encoding='utf-8'))
completed=subprocess.run(['node','--check',str(HERE/'app.js')],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
if completed.returncode:
    print(completed.stdout,file=sys.stderr); raise SystemExit(completed.returncode)
print('fieldwork harness static privacy/accessibility checks: PASS')
