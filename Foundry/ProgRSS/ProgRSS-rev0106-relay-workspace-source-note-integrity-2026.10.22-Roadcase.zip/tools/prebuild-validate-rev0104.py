#!/usr/bin/env python3
"""Prebuild validation for rev0104."""
from __future__ import annotations
import json, py_compile, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
REVISION='rev0104-workbench-private-backup-integrity'
PARENT='ProgRSS-rev0103-shared-folder-merge-source-note-disclosure-2026.10.22-Roadcase.zip'
PARENT_SHA='68c7b7606f94107dac942d232cef7338f8d8da2dcb1d95b9c88fb7a60fd42fa7'

def main()->int:
 assert (ROOT/'REVISION').read_text(encoding='utf-8').strip()==REVISION
 state=json.loads((ROOT/'REVISION-STATE.json').read_text(encoding='utf-8'))
 assert state['revision']==REVISION and state['releaseGateClosed'] is False
 cases=json.loads((ROOT/'SOURCE-NOTES-RUNTIME-CASES.json').read_text(encoding='utf-8'))
 assert cases['revision']==REVISION and len(cases['cases'])==18 and len({x['id'] for x in cases['cases']})==18
 two=next(x for x in cases['cases'] if x['id']=='two-folder-independence')
 assert 'Advanced Workbench Private backup' in two['description'] and 'refused before download' in two['description']
 sys.path.insert(0,str(ROOT/'tools'))
 from source_notes_runtime_evidence import REVISION as EVIDENCE_REVISION, case_catalog
 assert EVIDENCE_REVISION==REVISION and case_catalog()==cases
 schema=json.loads((ROOT/'SOURCE-NOTES-RUNTIME-RESULT.schema.json').read_text(encoding='utf-8'))
 assert schema['properties']['revision']['const']==REVISION
 audit=json.loads((ROOT/'SOURCE-NOTES-WORKBENCH-PRIVATE-BACKUP-INTEGRITY-AUDIT.json').read_text(encoding='utf-8'))
 continuity=json.loads((ROOT/'PRODUCT-CONTINUITY-AUDIT.json').read_text(encoding='utf-8'))
 integration=json.loads((ROOT/'INTEGRATION-AUDIT.json').read_text(encoding='utf-8'))
 assert audit['revision']==REVISION and audit['status']=='focused-pass'
 assert audit['correction']['sharedAuditHelper'] and audit['correction']['downloadBeforeValidation'] is False
 assert audit['correction']['network'] is False and audit['correction']['vaultWrite'] is False
 assert continuity['revision']==REVISION and continuity['status']=='pass' and continuity['cliChanged'] is False
 assert continuity['permissionsExpanded'] is False and continuity['newNetworkAuthority'] is False
 assert integration['revision']==REVISION and integration['status']=='pass'
 provenance=json.loads((ROOT/'RECONSTRUCTION_PROVENANCE.json').read_text(encoding='utf-8'))
 expected=('Continues the sealed rev0103 unified tree and corrects a reproduced Advanced Workbench '
  'private-backup Source Note validation bypass. The current parent already contains the unified '
  'private-transfer, Exchange, Node branch and merge, shared-folder merge, publication, Lineage, '
  'Workbench collection, repair, concurrency, Undo, native-integrity, and runtime-record work. '
  'No missing revision is invented.')
 assert provenance['reconstructionRevision']==REVISION
 assert provenance['immediateParentArchive']==PARENT and provenance['immediateParentSha256']==PARENT_SHA
 assert provenance['lineageClaim']==expected
 status=json.loads((ROOT/'evidence/rev0104/regression-status.json').read_text(encoding='utf-8'))
 assert status['complete'] and status['allPassed']
 labels={x['label']:x for x in status['rows']}
 required={'cli-test_source_notes_private_transfer','extension-static','extension-browser-smoke','extension-complete','evidence-boundary','contract','workbench-private-backup-chromium','workbench-private-backup-firefox','source_notes_private_transfer_harness','source_notes_private_transfer_harness-firefox','workbench-preservation-chromium','workbench-preservation-firefox'}
 assert required<=set(labels) and all(labels[x]['returncode']==0 for x in required)
 assert status['managedNodeHarnessInvocations']==22
 assert status['managedWorkbenchUiPathVariants']==4
 assert status['managedWorkbenchPrivateBackupUiPathVariants']==2
 assert status['managedSharedFolderMergeUiPathVariants']==2
 core=(ROOT/'Extension/shared/core.js').read_text(encoding='utf-8')
 background=(ROOT/'Extension/background.js').read_text(encoding='utf-8')
 app=(ROOT/'Extension/workbench/scripts/progrss-app.js').read_text(encoding='utf-8')
 assert core==(ROOT/'Extension/Firefox/shared/core.js').read_text(encoding='utf-8')
 assert background==(ROOT/'Extension/Firefox/background.js').read_text(encoding='utf-8')
 assert app==(ROOT/'Extension/Firefox/workbench/scripts/progrss-app.js').read_text(encoding='utf-8')
 assert 'function auditSourceNotes(state,knownSourceIds=null)' in core and 'auditSourceNotes,' in core
 assert 'return C.auditSourceNotes(state, knownSourceIds);' in background
 assert 'const sourceNoteAudit=C.auditSourceNotes(portableState);' in app
 assert 'Private backup not created:' in app and 'curator-written folder reason' in app
 assert 'id="toast" role="status" aria-live="polite"' in (ROOT/'Extension/workbench/index.html').read_text(encoding='utf-8')
 for rel in (
  'tools/run-rev0104-regressions.py','tools/verify-rev0104-workbench-private-backup-integrity.py',
  'tools/audit-rev0104-product-continuity.py','tools/update-rev0104-provenance.py',
  'tools/write-rev0104-authority.py','tools/prebuild-validate-rev0104.py','tools/build-rev0104-roadcase.py',
  'Extension/tests/source_notes_workbench_private_backup_harness.py',
 ):
  path=ROOT/rel; assert path.is_file(), rel; py_compile.compile(str(path),doraise=True)
 for path in ROOT.rglob('*.json'):
  if 'node_modules' not in path.parts: json.loads(path.read_text(encoding='utf-8'))
 for rel in ('Extension/shared/core.js','Extension/background.js','Extension/workbench/scripts/progrss-app.js'):
  subprocess.run(['node','--check',str(ROOT/rel)],check=True)
 assert not [p for p in ROOT.rglob('*.pyc') if '__pycache__' not in p.parts]
 print('PASS rev0104 prebuild validation: shared audit, Workbench private-backup integrity, complete regressions, 18-case binding, JSON, Python, and Node syntax.')
 return 0
if __name__=='__main__':raise SystemExit(main())
