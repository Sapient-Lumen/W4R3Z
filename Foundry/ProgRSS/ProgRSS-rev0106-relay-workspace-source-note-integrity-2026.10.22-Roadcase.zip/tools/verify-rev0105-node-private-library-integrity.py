#!/usr/bin/env python3
"""Focused rev0105 replay from a source tree or clean extraction."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
REVISION = "rev0105-node-private-library-source-note-integrity"
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")


def run(label: str, command: list[str], timeout: int = 1800) -> str:
    result = subprocess.run(
        command, cwd=ROOT, env=ENV, text=True,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout,
    )
    print(f"\n== {label} ==\n{result.stdout.rstrip()}")
    if result.returncode:
        raise RuntimeError(f"{label} failed with exit {result.returncode}")
    return result.stdout


def main() -> int:
    assert (ROOT / "REVISION").read_text(encoding="utf-8").strip() == REVISION
    cases = json.loads((ROOT / "SOURCE-NOTES-RUNTIME-CASES.json").read_text(encoding="utf-8"))
    assert cases["revision"] == REVISION and len(cases["cases"]) == 18
    two_folder = next(row for row in cases["cases"] if row["id"] == "two-folder-independence")
    assert "transactional `node init` storage" in two_folder["description"]
    assert "read-only `node serve BACKUP`" in two_folder["description"]

    native = (ROOT / "CLI/source_notes_native.py").read_text(encoding="utf-8")
    cli = (ROOT / "CLI/progrss.py").read_text(encoding="utf-8")
    store = (ROOT / "CLI/node_store.py").read_text(encoding="utf-8")
    server = (ROOT / "CLI/node_server.py").read_text(encoding="utf-8")
    assert "def validate_private_source_note_placements(state: Mapping[str, Any]) -> int:" in native
    assert "validate_private_source_note_placements as audit_private_source_note_placements" in cli
    assert "validate_private_source_note_placements(state)" in store
    assert "validate_private_source_note_placements(state)" in server
    assert store.count("_validate_backup_bytes(") == 8  # definition plus seven ingress/mutation/read boundaries

    parent = json.loads((ROOT / "evidence/rev0105/parent-reproduction/result.json").read_text(encoding="utf-8"))
    assert parent["parentRevision"] == "rev0104-workbench-private-backup-integrity"
    assert parent["malformedReasonCodePoints"] == 281
    for key in (
        "nodeStoreCreateAccepted", "nodeStoreReadAccepted", "nodeStoreExportAccepted",
        "readOnlyNodeLoaderAccepted", "exactImportPreserved", "exactExportPreserved",
    ):
        assert parent[key] is True, key

    audit = json.loads((ROOT / "SOURCE-NOTES-NODE-PRIVATE-LIBRARY-INTEGRITY-AUDIT.json").read_text(encoding="utf-8"))
    assert audit["revision"] == REVISION and audit["status"] == "focused-pass"
    assert audit["focusedTests"]["malformedForms"] == 9
    assert audit["correction"]["validateBeforeSqliteCreation"] is True
    assert audit["correction"]["network"] is False

    artifacts = ROOT / "evidence/rev0105/focused-replay"
    artifacts.mkdir(parents=True, exist_ok=True)
    run("Node private-library Source Notes", [
        sys.executable, "-m", "unittest", "-v", "CLI.tests.test_source_notes_node_private_library",
    ])
    run("Everyday private-transfer parity", [
        sys.executable, "-m", "unittest", "-v", "CLI.tests.test_source_notes_private_transfer",
    ])
    run("Node store regression", [sys.executable, "-m", "unittest", "-v", "CLI.tests.test_node_store"])
    run("Node server regression", [sys.executable, "-m", "unittest", "-v", "CLI.tests.test_node_server"])
    print("PASS rev0105 focused replay: shared Python audit, Node-owned library, read-only Node backup, and private-transfer parity.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
