# Source Notes Lineage preservation audit

Revision: `rev0097-source-notes-lineage-preservation`

## Reproduced parent failure

The rev0096 publisher included the direct-placement reason in the immutable edition, but Lineage ID remapping rebuilt members as `{kind,id}`. Preview and adoption therefore dropped the reason.

## Candidate result

- Native Chromium-source Lineage: **11/11** focused cases passed.
- Native generated-Firefox Lineage: **11/11** focused cases passed.
- Shipped Workbench review path: **4/4** cases passed in each package.
- First-edition adoption preserves every direct-placement reason.
- One-sided and identical later changes merge without a false conflict.
- Divergent edits, edit-versus-deletion, and different additions have no automatic winner.
- **Keep mine** and **Use curator’s** are placement-scoped, explicit, and rechecked at commit.
- Unknown, invalid, and stale decisions are refused.
- A locally retained placement keeps its reason when a simultaneous structural conflict preserves local membership.
- The focused paths made no network request.

## Scope

This is native-module and managed shipped-UI-path regression evidence. It is not installed-browser, target-host, participant, privacy-comprehension, assistive-technology, or accessibility-conformance evidence.
