# Changelog — rev0087 Source Notes runtime kit

## Added

- `Extension/tests/source_notes_installed_acceptance.py`: real installed Chromium runtime lane with two extension views, persistent profile restart, production request paths, native artifact checks, screenshots, exact-Roadcase inventory comparison, and explicit claim boundaries.
- `tools/prepare-source-notes-runtime-session.py`: safe immutable-Roadcase verifier/extractor for Chromium and Firefox runtime sessions.
- `SOURCE-NOTES-RUNTIME-PROTOCOL.md`: exact-package procedure, required scenario, install-path limitations, and fail-closed result vocabulary.
- `BROWSER-CHANNEL-SNAPSHOT.*`: official 2026-10-21 channel references and available-environment comparison.
- `SOURCE-NOTES-RUNTIME-AUDIT.*` and `SOURCE-NOTES-RUNTIME-MATRIX.*`: machine/human-readable separation of managed preflight from release-blocking runtime and fieldwork rows.
- Managed Chromium runtime screenshots and structured evidence under `evidence/rev0087/`.

## Changed

- Reprioritized `BOOTSTRAPROSE.md` around an external exact-final-Roadcase seal, then unmanaged current Chromium, Firefox Release, Firefox ESR, and only then human/assistive-technology fieldwork.
- Extended the focused verifier, entry-point matrix, deterministic builder, provenance updater, and static Extension suite for the runtime kit.
- Kept product revision/version at `rev0080` / `0.80.0`; rev0087 is a reconstruction-candidate label, not a recovered missing release.

## Not changed

- Source Notes schema, semantics, 280-code-point limit, native serializer/integrity path, conflict policy, OPML omission policy, authoring UI, browser permissions, Node authority, remote mode, and WebRTC boundaries.
