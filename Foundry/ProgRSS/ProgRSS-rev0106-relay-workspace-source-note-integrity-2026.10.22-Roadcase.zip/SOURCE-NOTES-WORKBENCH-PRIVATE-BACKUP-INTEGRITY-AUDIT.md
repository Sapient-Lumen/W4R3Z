# Advanced Workbench private-backup Source Note integrity audit — rev0104

Parent: `ProgRSS-rev0103-shared-folder-merge-source-note-disclosure-2026.10.22-Roadcase.zip`  
SHA-256: `68c7b7606f94107dac942d232cef7338f8d8da2dcb1d95b9c88fb7a60fd42fa7`

## Reproduced defect

The shipped Advanced Workbench’s **Private backup** control serialized its current in-memory library directly and did not call the unified private-transfer Source Note validator. The retained parent reproduction downloaded a private backup containing a direct-placement reason with **281 Unicode code points**, although the contract permits at most 280.

## Correction

- One shared `auditSourceNotes` helper now owns the fail-closed direct-placement audit in the Extension core.
- The everyday background private-transfer path delegates to that helper.
- Advanced Workbench audits its current in-memory state before creating a download, so unsaved Workbench state is preserved without introducing a background-state race.
- Valid route-specific multiline and Unicode reasons remain exact; absent reasons remain absent.
- Over-limit, wrong-level, folder-member, duplicate, empty, edge-whitespace, non-string, invalid-Unicode, and missing-source forms are refused before download.
- Refusal performs no vault write, network request, permission request, or automatic normalization.

## Focused result

- Chromium-source package: **10/10 checks passed**
- Generated-Firefox package: **10/10 checks passed**
- Complete inherited regression: **PASS**

The Workbench’s existing toast is a programmatic status region. Managed verification of that markup is not a screen-reader or accessibility-conformance claim.
