# Source Notes runtime protocol — rev0106

Use the immutable rev0106 Roadcase to prepare fresh session-v5 records on each actual target host. Run the fixed 18-case catalog without relabeling earlier evidence. In `two-folder-independence`, include valid and malformed Relay share, publish, import, review, explicit publication-check, update, and output-boundary behavior. Preserve first failures, retries, interruptions, and recovery. Finalize and independently verify each complete evidence bundle against the same Roadcase.
