# ProgRSS rev0079 — Dispatch

**Know what leaves before you send the link.**

Dispatch adds a private sender-side Fieldbook for the exact Exchange preview
shown before an expiring handoff is created. It observes whether an unfamiliar
sender understands artifact contents, privacy exclusions, recipient doors,
public-address and static-package boundaries, expiry, revocation, Origin
binding, zero listed-site requests, and the absence of recipient-library
access.

## Privacy boundary

The Fieldbook omits route and curator identity, source identity, folder paths,
public addresses, library identity, artifact filenames and digests, Node
identity, and preview-capability material. It requests no participant identity,
uses no telemetry or automatic persistence, and makes no network request.

## Product boundary

Dispatch changes no Exchange protocol or authority. Preparing or downloading
the sheet does not publish, upload, create a handoff, contact a listed source,
create a schedule, pair an Extension, follow a feed, import a route, or change
either library.

The existing Crossroads recipient Fieldbook remains separate. Debrief refuses
mixed sender, recipient, and Trace/Bearing/Anchor scenario reports.

## Interfaces

Node GUI:

```text
Curate → prepare one share → Research this sender review
```

Offline CLI:

```sh
./progrss node exchange-sender-fieldbook exchange-preview.json \
  --output ProgRSS-Exchange-Sender-Fieldbook.html
```

## Verification boundary

Automated tests verify strict preview validation, identity and capability
omission, new-file-only CLI behavior, authenticated Node download, all task
states, privacy-gated local report export, dark/light rendering, deterministic
packaging, and clean-extraction replay. They verify the tool—not unfamiliar-
sender comprehension.
