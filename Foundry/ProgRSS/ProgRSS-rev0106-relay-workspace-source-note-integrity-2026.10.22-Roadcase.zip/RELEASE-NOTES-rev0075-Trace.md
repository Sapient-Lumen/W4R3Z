# ProgRSS rev0075 — Trace

**Release maxim:** **Show the observations, not just the diagnosis.**

Trace extends Bearing's read-only held-window review with two bounded evidence objects:

```text
progrss.node.bearing-trace.v1
progrss.node.recipe-footprint.v1
```

The Node now shows the accepted baseline followed by retained held observations from oldest to newest. Each held point explains its overlap with the previous point, visible page-boundary kinds, and a bounded relationship such as **Different window**, **Boundary changed**, **Some overlap**, or **Substantial overlap**.

The saved watched-section recipe receives a conservative footprint label such as **Semantic boundary**, **Explicit structural signal**, **Class or ID selector**, or **Implementation-detail selector**. The label explains dependencies; it is not a confidence score or durability promise.

Trace remains zero-network and zero-write. It does not replace a baseline, rewrite a recipe, contact the browser or watched site, create a schedule, or grant paired-Extension repair authority. Exact selectors, hashes, and operation identifiers remain under Advanced evidence. Anchor and fresh Capture remain separate later reviews.

The fluorescent dark interface remains the default, with a persistent light option, narrow vertical trail reflow, forced-colors treatment, and reduced-motion behavior.

Native installed-browser, unfamiliar-human, and real assistive-technology sessions remain unexecuted acceptance work.
