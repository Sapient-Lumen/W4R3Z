# Changelog — rev0103 shared-folder merge Source Note disclosure

- Reproduced two placement-scoped Source Note conflicts for the same source in identically titled folders appearing indistinguishable in the shipped Extension update review.
- Added the canonical folder path to native shared-folder Source Note merge rows and placement descriptors.
- Displayed full routes, curator attribution, and the non-safety boundary in the shipped side panel.
- Preserved literal multiline, markup-like, and bidirectional reason text with `dir="auto"`, `white-space: pre-wrap`, and placement-specific conflict decisions.
- Kept merge classification and write semantics unchanged; no new permission, persistent store, or network authority.
- Kept the fixed runtime catalog at 18 cases by extending the existing divergent-copy cases.
