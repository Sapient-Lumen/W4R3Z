# ProgRSS rev0073 — Anchor

**Release maxim:** **Move the baseline. Keep the history.**

Anchor adds one explicit way out of a Drift-held browser rendering.

Drift conservatively keeps the accepted partial-page baseline when a later browser rendering appears to be a different virtualized window. Anchor lets the local Node administrator review that held rendering and deliberately make it the future comparison point without rewriting the past.

## Human flow

```text
Sources
  → Held rendered window available
  → Review held window
  → Compare Accepted now with Held proposal
  → Acknowledge Use this held rendering as the new baseline
  → Replace baseline once
  → Durable receipt and downloadable before snapshot
```

The review leads with three consequences:

- **No past alert invented** — the held rendering becomes the comparison point, but ProgRSS creates no historical add-or-remove item.
- **Earlier library retained** — the complete pre-operation private library remains as a recovery snapshot.
- **Zero site requests** — review and commit are local; they contact no watched site and create no schedule.

Neither the acknowledgement nor the commit is preselected or automatic.

## Typed operation

The operation is:

```text
replace-held-page-baseline
```

It requires:

- one existing watched-page source;
- one persisted eligible Drift hold;
- the exact reviewed base-library SHA-256 through strong `If-Match`;
- the exact ten-minute preview digest and capability;
- one random idempotency key;
- local Node-administrator authority.

It refuses stale libraries, changed recipes, changed accepted baselines, superseded holds, expired previews, changed preview content, and idempotency-key reuse with different content.

An exact retry returns the original receipt and performs no second write.

## Atomic evidence

One SQLite transaction records:

- the complete pre-operation `progrss.private.v1` library;
- the new complete portable library;
- the resulting digest and revision;
- the operation receipt;
- the replay fingerprint;
- removal of the consumed held observation.

Failure injection after snapshot insertion, library replacement, or receipt insertion rolls the complete operation back.

## Node-store migration

The local store advances to:

```text
progrss.node-store.v3
```

The migration adds bounded Node-local held-Capture evidence. It does not rewrite the current portable library bytes, digest, revision, original import, earlier receipts, or earlier snapshots.

## Extension boundary

The Extension now explains after a Drift hold that the local Node has a separate baseline review and that nothing was replaced during Capture.

It still cannot:

- read the held snapshot through pairing;
- submit the replacement operation;
- read source addresses or retained items;
- trigger Node acquisition;
- create a schedule;
- synchronize the libraries.

Pairing remains summary-only and read-only.

## Authority and privacy

Anchor performs no:

```text
DNS lookup
watched-site request
browser request
cookie or credential transfer
recipe change
source activation change
historical page-change creation
schedule creation
remote Node operation
WebRTC transfer
```

The earlier snapshot is recovery evidence, not an automatic undo control.

## Verification boundary

The deterministic release is verified through Python, JavaScript, browser-rendering, archive-integrity, and clean-extraction lanes. Native installed Chromium, current Firefox, Firefox ESR, signed-in real-site use, unfamiliar-human sessions, and real assistive-technology sessions remain explicitly not run.

## Next boundary

Run Anchor with unfamiliar administrators and native browsers. The next technical work should connect repeated held windows to explicit repair and expand the virtualized-page fixture garden before adding broader write authority, remote Nodes, or direct point-to-region selection.
