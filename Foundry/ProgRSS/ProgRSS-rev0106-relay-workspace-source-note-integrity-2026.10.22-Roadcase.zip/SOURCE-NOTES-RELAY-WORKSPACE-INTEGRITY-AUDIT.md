# Source Notes Relay workspace integrity audit — rev0106

## Reproduced defect

The sealed rev0105 Relay loader accepted a private workspace containing a 281-code-point direct-placement reason. The shipped `workspace import-bundle` command returned success, wrote a new backup, and retained the malformed reason. The before-fix input, output, stdout, and machine-readable reproduction are retained under `evidence/rev0106/parent-reproduction/`.

## Correction

`CLI/relay.py::read_workspace` now delegates to the shared `validate_private_source_note_placements` audit immediately after locating the private state. All six Relay workspace commands therefore validate before using the state:

- `share-folder`
- `publish-folder`
- `import-bundle`
- `review-bundle`
- `check-publication`
- `update-bundle`

The correction preserves valid route-specific reasons exactly and refuses over-limit, wrong-level, folder-level, reason-bearing duplicate, empty, edge-whitespace, non-string, invalid-Unicode, and missing-source forms. Refusal occurs before output; the explicit publication-check command refuses before its network step. Derived workspace state is re-audited immediately before a new backup is written.

## Scope

Only `CLI/relay.py`, CLI documentation, and one focused test module changed in the product tree. The complete Extension tree and browser permission projections are unchanged. No new persistent store, network authority, automatic conflict winner, account, schedule, notification, profile, reaction, comment, or messaging capability was added.

## Focused result

- Five focused test methods passed.
- Nine malformed forms were refused.
- All six Relay workspace command paths were exercised through the shipped CLI.
- Valid two-folder reasons and incoming bundle reasons remained exact.
- The fixed replay returned exit status 2 and wrote no output.

This is native/managed regression evidence, not target-host browser, participant, privacy-comprehension, assistive-technology, or accessibility-conformance evidence.
