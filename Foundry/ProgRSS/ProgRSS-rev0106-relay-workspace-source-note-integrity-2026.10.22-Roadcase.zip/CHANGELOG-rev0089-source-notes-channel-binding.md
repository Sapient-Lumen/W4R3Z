# Changelog — rev0089 Source Notes channel binding

## Added

- `tools/browser_channel_evidence.py`, an offline exact-byte wrapper for captured Chrome for Testing and Mozilla product-details JSON payloads.
- A fixed 24-hour maximum snapshot age for a passing runtime, strict time ordering, and exact browser-version derivation for Chromium Stable, Firefox Release, and Firefox ESR.
- Channel snapshot and source payloads as prepared-session files, deterministic evidence-bundle members, statement subjects, and independently reverified inputs.
- Fifteen focused evidence-boundary tests, including wrong version, false current assertion, stale snapshot, future snapshot, source tampering, coordinated package tampering, status inflation, and deterministic round trip.

## Tightened

- `--channel-evidence-dir` is required; operator-entered browser versions that do not match the bound source bytes are refused.
- A pass now requires `currentChannelAtExecution=true` and a snapshot age of at most 86,400 seconds at runtime start.
- The session identifier includes the channel-evidence record.
- The verifier refuses missing, extra, symlinked, changed, stale, or temporally impossible channel evidence.

## Preserved

- The exact 18-case Source Notes runtime catalog and all rev0088 package/result/evidence boundaries.
- The rev0086 placement-scoped Source Notes implementation and rev0087 managed Chromium 144 preflight.
- No browser permissions, network permissions, accounts, pairing, scheduling, ranking, comments, profiles, notifications, or remote private-state capabilities were added.

## Explicitly not established

- Authenticity of the channel-source fetch, trusted time, or source signatures.
- Exact-final rev0089 browser runtime inside the self-contained archive.
- Managed or unmanaged current Chromium runtime.
- Firefox Release or Firefox ESR runtime.
- Human permission-prompt comprehension, accessibility conformance, real assistive-technology evidence, or unfamiliar-person comprehension.
