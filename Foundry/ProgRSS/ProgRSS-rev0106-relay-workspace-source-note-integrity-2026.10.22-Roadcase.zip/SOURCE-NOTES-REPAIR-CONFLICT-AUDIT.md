# Source Notes repair-conflict audit — reverified in rev0093

The repair rule introduced in rev0092 remains green in rev0093. Same-source repair preserves absent, one-sided, or identical reasons per folder; keeps distinct folders independent; and refuses different nonempty reasons in the same folder before mutation without choosing a winner.

The current sweep reran 14 scenarios against Chromium-source and generated-Firefox production functions plus five CLI tests, stale-review refusal, exact repair Undo, and managed rendering of the dedicated blocker. This remains managed/native evidence, not installed-browser or participant evidence.
