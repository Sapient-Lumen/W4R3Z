#!/usr/bin/env python3
"""Create the directly loadable Firefox package from shared ProgRSS sources."""
from __future__ import annotations

import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / "Firefox"
COPY_DIRS = ("fixtures", "icons", "shared", "sidepanel", "workbench")
COPY_FILES = ("background.js",)


def main() -> None:
    if DEST.exists():
        shutil.rmtree(DEST)
    DEST.mkdir(parents=True)
    for name in COPY_DIRS:
        shutil.copytree(ROOT / name, DEST / name)
    for name in COPY_FILES:
        shutil.copy2(ROOT / name, DEST / name)
    shutil.copy2(ROOT / "platform" / "firefox-manifest.json", DEST / "manifest.json")
    shutil.copy2(ROOT / "platform" / "FIREFOX-README.md", DEST / "README.md")
    manifest = json.loads((DEST / "manifest.json").read_text(encoding="utf-8"))
    root_project = json.loads((ROOT / "project.json").read_text(encoding="utf-8"))
    project = {
        "project": "ProgRSS Extension for Firefox",
        "version": manifest["version"],
        "revision": root_project["revision"],
        "codename": root_project["codename"],
        "platform": "Firefox desktop Manifest V3",
        "entrypoints": {
            "manifest": "manifest.json",
            "everydayReader": manifest["sidebar_action"]["default_panel"],
            "advancedWorkbench": manifest["options_ui"]["page"],
            "backgroundScripts": manifest["background"]["scripts"],
        },
        "networkDefault": "none until an optional per-origin permission is granted",
        "storage": "local IndexedDB with revision-guarded writes",
        "dataCollection": "none",
        "accountRequired": False,
        "telemetry": False,
        "generatedAt": root_project["generatedAt"],
    }
    (DEST / "project.json").write_text(json.dumps(project, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
