(() => {
  'use strict';
  const api = globalThis.browser || globalThis.chrome;
  const instanceId = globalThis.crypto?.randomUUID?.() || Math.random().toString(36).slice(2);
  globalThis.ProgRSSWorkbenchInstanceId = instanceId;
  const open = document.getElementById('open-reader');
  const reload = document.getElementById('reload-workbench');
  const reportSection = document.getElementById('source-reference-report');
  const reportHeading = document.getElementById('source-reference-heading');
  const reportIntro = document.getElementById('source-reference-intro');
  const reportStatus = document.getElementById('source-reference-status');
  const reportContent = document.getElementById('source-reference-content');
  const reportRefresh = document.getElementById('source-reference-refresh');
  const reportClose = document.getElementById('source-reference-close');
  const reportParams = new URLSearchParams(location.search);
  const repairFirst = reportParams.get('repairFirst') || '';
  const repairSecond = reportParams.get('repairSecond') || '';
  let activeRepairFirst = repairFirst;
  let activeRepairSecond = repairSecond;
  let activeReport = null;

  function el(tag, attrs = {}, children = []) {
    const node = document.createElement(tag);
    for (const [name, value] of Object.entries(attrs)) {
      if (value == null || value === false) continue;
      if (name === 'class') node.className = String(value);
      else if (name === 'text') node.textContent = String(value);
      else if (name === 'hidden') node.hidden = Boolean(value);
      else if (name === 'checked') node.checked = Boolean(value);
      else if (name === 'disabled') node.disabled = Boolean(value);
      else node.setAttribute(name, String(value));
    }
    for (const child of Array.isArray(children) ? children : [children]) {
      if (child == null) continue;
      node.append(child.nodeType ? child : document.createTextNode(String(child)));
    }
    return node;
  }

  async function background(type, data = {}) {
    const response = await api.runtime.sendMessage({target: 'background', type, data});
    if (!response?.ok) {
      const error = new Error(response?.error || 'ProgRSS could not complete that action.');
      error.code = response?.code || 'FAILED';
      error.detail = response?.detail || null;
      throw error;
    }
    return response.result || {};
  }

  function revealReload() {
    if (!reload) return;
    reload.hidden = false;
    reload.title = 'The shared ProgRSS vault changed in another view. Reload before editing.';
  }

  function readerFallback(error) {
    if (!open) return;
    open.textContent = 'Use the ProgRSS toolbar button';
    if (error) open.title = String(error?.message || error);
  }

  function referenceLabel(reference) {
    if (reference.kind === 'update') return `Retained update “${reference.label || 'Untitled update'}” from ${reference.sourceTitle || 'a source history'}`;
    return `Source history “${reference.sourceTitle || reference.targetId || 'Untitled source'}”`;
  }

  function referenceList(references = []) {
    const list = el('ul', {class: 'source-reference-targets'});
    for (const reference of references) {
      const suffix = reference.referenceCount > 1 ? ` · ${reference.referenceCount} occurrences` : '';
      list.append(el('li', {text: `${referenceLabel(reference)}${suffix}`}));
    }
    return list;
  }

  function technicalPaths(record) {
    const paths = (record.references || []).flatMap(reference => (reference.paths || []).map(path => ({path, label: referenceLabel(reference)})));
    if (!paths.length && !record.pathsTruncated) return null;
    const technical = el('details', {class: 'source-reference-tech'});
    technical.append(el('summary', {text: 'Technical paths'}));
    for (const row of paths) technical.append(el('code', {text: `${row.path} → ${row.label}`}));
    if (record.pathsTruncated) technical.append(el('p', {text: 'Additional exact paths were omitted from this bounded display.'}));
    return technical;
  }

  function retirementAcknowledgementId(record) {
    return `retire-${String(record.recordId || record.index).replace(/[^a-z0-9_-]+/gi, '-').slice(0, 60)}-${record.index}`;
  }

  async function openRetirementReview(record, host, trigger) {
    const existing = host.querySelector('.receipt-retirement-review');
    if (existing) {
      existing.remove();
      trigger.textContent = 'Review retirement';
      return;
    }
    trigger.disabled = true;
    trigger.textContent = 'Preparing review…';
    try {
      const preview = await background('preview-graft-receipt-retirement', {
        firstSourceId: activeRepairFirst,
        secondSourceId: activeRepairSecond,
        recordIndex: record.index,
        recordId: record.recordId
      });
      const review = el('section', {class: 'receipt-retirement-review', 'aria-label': 'Graft receipt retirement review'});
      review.append(el('h5', {text: 'Retire this graft receipt?'}));
      review.append(el('p', {text: 'The receipt will stop acting as active Workbench evidence. ProgRSS will preserve its exact JSON object, canonical SHA-256 digest, and retirement time in the private library.'}));
      const effectList = el('ul', {class: 'receipt-retirement-effects'});
      for (const effect of preview.effects || []) effectList.append(el('li', {text: effect}));
      review.append(effectList);
      review.append(el('p', {class: 'receipt-retirement-digest'}, [
        el('strong', {text: 'Canonical receipt digest'}),
        el('code', {text: preview.receipt?.digest || ''})
      ]));
      for (const warning of preview.warnings || []) review.append(el('p', {class: 'receipt-retirement-warning', text: warning}));
      const acknowledgementId = retirementAcknowledgementId(record);
      const acknowledge = el('input', {type: 'checkbox', id: acknowledgementId});
      const acknowledgeLabel = el('label', {for: acknowledgementId, text: 'I understand that this receipt will leave active Workbench history but remain preserved as retired evidence.'});
      const check = el('div', {class: 'receipt-retirement-check'}, [acknowledge, acknowledgeLabel]);
      review.append(check);
      const status = el('div', {class: 'receipt-retirement-status', role: 'status', 'aria-live': 'polite', text: `No network or permission request. Undo remains available for ${preview.undoMinutes || 30} minutes unless newer work is saved.`});
      review.append(status);
      const retire = el('button', {class: 'btn danger sm', type: 'button', disabled: true, text: 'Retire receipt'});
      const cancel = el('button', {class: 'btn ghost sm', type: 'button', text: 'Keep active'});
      const actions = el('div', {class: 'receipt-retirement-actions'}, [retire, cancel]);
      review.append(actions);
      acknowledge.addEventListener('change', () => { retire.disabled = !acknowledge.checked; });
      cancel.addEventListener('click', () => {
        review.remove();
        trigger.textContent = 'Review retirement';
        trigger.focus();
      });
      retire.addEventListener('click', async () => {
        retire.disabled = true;
        cancel.disabled = true;
        status.textContent = 'Preserving the exact receipt and updating the local vault…';
        try {
          const result = await background('retire-graft-receipt', {
            firstSourceId: activeRepairFirst,
            secondSourceId: activeRepairSecond,
            recordIndex: record.index,
            recordId: record.recordId,
            reviewedRevision: preview.reviewedRevision,
            expectedDigest: preview.receipt?.digest || ''
          });
          reportStatus.textContent = `Retired “${result.receiptTitle || record.title}” without rewriting it. Refreshing the exact references…`;
          await loadReferenceReport();
        } catch (error) {
          status.textContent = `Retirement stopped: ${String(error?.message || error)}`;
          cancel.disabled = false;
          retire.disabled = !acknowledge.checked;
        }
      });
      host.append(review);
      acknowledge.focus();
      trigger.textContent = 'Close retirement review';
    } catch (error) {
      reportStatus.textContent = `Retirement review unavailable: ${String(error?.message || error)}`;
      trigger.textContent = 'Review retirement';
    } finally {
      trigger.disabled = false;
    }
  }

  function referenceRecord(record) {
    const card = el('article', {class: 'source-reference-record'});
    card.append(el('h4', {text: record.title || record.recordId || 'Advanced record'}));
    const identity = [record.schema ? `Schema ${record.schema}` : '', record.recordId ? `Local ID ${record.recordId}` : ''].filter(Boolean).join(' · ');
    if (identity) card.append(el('p', {text: identity}));
    card.append(el('p', {text: `${record.referenceCount || 0} exact reference${record.referenceCount === 1 ? '' : 's'} found in this record.`}));
    const list = referenceList(record.references || []);
    if (list.childElementCount) card.append(list);
    const technical = technicalPaths(record);
    if (technical) card.append(technical);
    if (record.retirement?.eligible) {
      card.append(el('p', {class: 'source-reference-retirable', text: record.retirement.explanation || 'This exact receipt has a narrow, evidence-preserving retirement path.'}));
      const review = el('button', {class: 'btn ghost sm', type: 'button', text: record.retirement.label || 'Review retirement'});
      review.addEventListener('click', () => openRetirementReview(record, card, review));
      card.append(review);
    }
    return card;
  }

  function retiredEvidenceCard(record) {
    const card = el('article', {class: 'source-reference-record retired-evidence-record'});
    card.append(el('h4', {text: record.originalTitle || record.originalRecordId || 'Retired graft receipt'}));
    const when = record.retiredAt ? new Date(record.retiredAt).toLocaleString() : 'unknown time';
    card.append(el('p', {text: `Retired ${when}. The original receipt remains unchanged and no longer acts as active Workbench evidence.`}));
    if (record.originalDigest) card.append(el('code', {class: 'retired-evidence-digest', text: record.originalDigest}));
    const list = referenceList(record.references || []);
    if (list.childElementCount) card.append(list);
    return card;
  }

  function renderUndo(undo) {
    if (!undo?.undoAvailable) return null;
    const box = el('section', {class: 'receipt-retirement-undo'});
    box.append(el('strong', {text: 'Receipt retirement can still be undone'}));
    box.append(el('p', {text: `“${undo.receiptTitle || undo.receiptId || 'Graft receipt'}” can return to active Workbench history until ${new Date(undo.expiresAt).toLocaleTimeString()}, unless newer work is saved.`}));
    const button = el('button', {class: 'btn ghost sm', type: 'button', text: 'Undo receipt retirement'});
    const status = el('span', {class: 'mini', role: 'status', 'aria-live': 'polite'});
    button.addEventListener('click', async () => {
      button.disabled = true;
      status.textContent = 'Restoring the exact receipt…';
      try {
        await background('undo-graft-receipt-retirement');
        reportStatus.textContent = 'The exact graft receipt is active again. Refreshing the report…';
        await loadReferenceReport();
      } catch (error) {
        status.textContent = `Undo stopped: ${String(error?.message || error)}`;
        button.disabled = false;
      }
    });
    box.append(el('div', {class: 'receipt-retirement-actions'}, [button, status]));
    return box;
  }

  function renderReferenceReport(report) {
    activeReport = report;
    reportContent.replaceChildren();
    const sources = Array.isArray(report.sources) ? report.sources : [];
    const summary = report.summary || {};
    reportIntro.textContent = sources.length === 2
      ? `${sources[0].title} and ${sources[1].title} share reviewed address evidence. This report names the local records that still depend on either history.`
      : 'This report names the local records that still depend on either source history.';

    const pair = el('div', {class: 'source-reference-pair'});
    for (const source of sources) {
      const card = el('div', {class: 'source-reference-source'});
      card.append(el('strong', {text: source.title || 'Untitled source'}));
      card.append(el('code', {text: source.url || source.id || ''}));
      pair.append(card);
    }
    reportContent.append(pair);

    const stats = el('div', {class: 'source-reference-summary'});
    for (const [value, label] of [
      [summary.blockingRecords || 0, 'blocking records'],
      [summary.exactReferences || 0, 'active references'],
      [summary.blockingGroups || 0, 'Workbench areas']
    ]) {
      stats.append(el('div', {class: 'source-reference-stat'}, [el('strong', {text: value}), el('span', {text: label})]));
    }
    reportContent.append(stats);

    const undo = renderUndo(report.retirementUndo);
    if (undo) reportContent.append(undo);

    const groups = Array.isArray(report.groups) ? report.groups : [];
    if (!groups.length && !summary.scanExceeded) {
      reportContent.append(el('div', {class: 'source-reference-note', text: 'No blocking Advanced Workbench references remain. Return to the everyday reader and review the pair again; this report did not combine or change the histories.'}));
    }
    for (const [index, group] of groups.entries()) {
      const details = el('details', {class: 'source-reference-group'});
      if (index === 0) details.open = true;
      details.append(el('summary', {text: `${group.label || group.key} · ${group.recordCount || 0} record${group.recordCount === 1 ? '' : 's'} · ${group.referenceCount || 0} reference${group.referenceCount === 1 ? '' : 's'}`}));
      details.append(el('p', {class: 'source-reference-reason', text: `Why this blocks the repair: ${group.reason || 'ProgRSS has no meaning-preserving automatic rewrite for this record type.'}`}));
      const records = el('div', {class: 'source-reference-records'});
      for (const record of group.records || []) records.append(referenceRecord(record));
      if (group.scanExceeded) records.append(el('div', {class: 'source-reference-note', text: 'This group exceeded the bounded audit. ProgRSS stopped rather than claiming that the list is complete.'}));
      details.append(records);
      reportContent.append(details);
    }

    const retired = Array.isArray(report.retiredEvidence) ? report.retiredEvidence : [];
    if (retired.length) {
      const details = el('details', {class: 'source-reference-group retired-evidence-group'});
      details.append(el('summary', {text: `Preserved retired evidence · ${retired.length} receipt${retired.length === 1 ? '' : 's'} · ${summary.retiredReferences || 0} historical reference${summary.retiredReferences === 1 ? '' : 's'}`}));
      details.append(el('p', {class: 'source-reference-reason', text: 'These exact receipts remain portable historical evidence. They no longer participate in active Workbench operations and do not block the local same-source repair.'}));
      const records = el('div', {class: 'source-reference-records'});
      for (const record of retired) records.append(retiredEvidenceCard(record));
      details.append(records);
      reportContent.append(details);
    }

    reportContent.append(el('p', {class: 'source-reference-note', text: report.note || 'This report does not rewrite or transfer trust.'}));
    reportStatus.textContent = summary.scanExceeded
      ? 'Report ready, but at least one record group exceeded the bounded audit.'
      : `Report ready: ${summary.blockingRecords || 0} blocking record${summary.blockingRecords === 1 ? '' : 's'} found${retired.length ? `; ${retired.length} retired receipt${retired.length === 1 ? '' : 's'} preserved` : ''}.`;
  }

  async function loadReferenceReport(firstSourceId = activeRepairFirst, secondSourceId = activeRepairSecond) {
    if (!reportSection || !firstSourceId || !secondSourceId) return;
    activeRepairFirst = firstSourceId;
    activeRepairSecond = secondSourceId;
    reportSection.hidden = false;
    reportRefresh.disabled = true;
    reportStatus.textContent = 'Reading exact local references…';
    reportContent.replaceChildren();
    try {
      const result = await background('source-repair-references', {firstSourceId, secondSourceId});
      renderReferenceReport(result);
      requestAnimationFrame(() => reportHeading?.focus());
    } catch (error) {
      activeReport = null;
      reportStatus.textContent = `Report unavailable: ${String(error?.message || error)}`;
      reportContent.append(el('p', {class: 'source-reference-note', text: 'The histories may have changed, been archived, or stopped sharing address evidence. Return to the everyday reader and start a fresh review.'}));
    } finally {
      reportRefresh.disabled = false;
    }
  }

  open?.addEventListener('click', () => {
    try {
      if (api?.sidePanel?.open && Number.isInteger(api.windows?.WINDOW_ID_CURRENT)) {
        api.sidePanel.open({windowId: api.windows.WINDOW_ID_CURRENT}).catch(readerFallback);
        return;
      }
      if (api?.sidebarAction?.open) {
        Promise.resolve(api.sidebarAction.open()).catch(readerFallback);
        return;
      }
      readerFallback();
    } catch (error) {
      readerFallback(error);
    }
  });
  reload?.addEventListener('click', () => location.reload());
  reportRefresh?.addEventListener('click', () => loadReferenceReport());
  reportClose?.addEventListener('click', () => {
    reportSection.hidden = true;
    history.replaceState(null, '', location.pathname);
  });
  if (api?.runtime?.onMessage) {
    api.runtime.onMessage.addListener(message => {
      if (message?.type === 'progrss:state-changed' && message?.detail?.instanceId !== instanceId) revealReload();
    });
  }
  globalThis.ProgRSSRevealReload = revealReload;
  globalThis.ProgRSSOpenSourceReferenceReport = loadReferenceReport;
  globalThis.ProgRSSActiveSourceReferenceReport = () => activeReport;
  loadReferenceReport();
})();
