/* ProgRSS rev0008 — proof-carrying discovery.
 * A discovery proof is a small, unsigned replay instruction, NOT evidence
 * that its author actually visited the page. No HTML is exported by default.
 * Evaluate only in a local inert parser; never run webpage or peer code.
 */
(function(root){
'use strict';
const C=root.ProgRSSCore,S=root.ProgRSSScout,Q=root.ProgRSSCourier;
const SCHEMA='progrss.discovery.v1', MAX_BYTES=12_000;
const MIME=new Set(['application/rss+xml','application/atom+xml','application/feed+json','application/json']);
const exact=(v,keys)=>v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).sort().join('|')===keys.slice().sort().join('|');
const stamp=x=>typeof x==='string'&&x.length<=42&&Number.isFinite(Date.parse(x));
function cleanSite(url){let u=C.safeUrl(url);if(u!==url)throw Error('Discovery URL must be normalized');return u;}
function digestFor(p){const claim={schema:SCHEMA,siteUrl:p.siteUrl,candidate:p.candidate,witness:p.witness};return 'sha256:'+Q.sha256(Q.canonical(claim));}
function validateProof(input){
  if(!exact(input,['schema','siteUrl','observedAt','candidate','witness','digest'])||input.schema!==SCHEMA||JSON.stringify(input).length>MAX_BYTES)
    throw Error('Invalid or oversized discovery proof');
  const p=input;cleanSite(p.siteUrl);
  if(!stamp(p.observedAt)||typeof p.digest!=='string'||!/^sha256:[0-9a-f]{64}$/.test(p.digest))throw Error('Invalid discovery timestamp or checksum');
  const c=p.candidate,w=p.witness;
  if(!c||!['feed','page'].includes(c.kind)||!w||typeof w.method!=='string')throw Error('Invalid discovery subject or witness');
  if(c.kind==='feed'){
    if(!exact(c,['kind','url','title','format'])||!['RSS','Atom','JSON Feed','JSON (verify feed)','RSS feed','ATOM feed'].includes(c.format))throw Error('Invalid feed proof candidate');
    cleanSite(c.url);
    if(typeof c.title!=='string'||!c.title||c.title!==C.text(c.title,120))throw Error('Invalid feed proof title');
    if(w.method==='parsed-feed'){
      if(!exact(w,['method','format','itemCount'])||c.url!==p.siteUrl||w.format!==c.format||!Number.isSafeInteger(w.itemCount)||w.itemCount<0||w.itemCount>250)
        throw Error('Invalid direct-feed witness');
    }else if(w.method==='html-link'||w.method==='http-link'){
      if(!exact(w,['method','rel','type','href','baseUrl'])||typeof w.rel!=='string'||w.rel.length>120||!S.relIsAlternate(w.rel)||typeof w.type!=='string'||!MIME.has(S.mimeOf(w.type))||typeof w.href!=='string'||w.href.length>2048||!w.href||typeof w.baseUrl!=='string')
        throw Error('Invalid advertised-link witness');
      cleanSite(w.baseUrl);
      if(w.method==='http-link'&&w.baseUrl!==p.siteUrl)throw Error('HTTP Link header base must be the response URL');
      if(C.safeUrl(w.href,w.baseUrl)!==c.url)throw Error('Feed witness does not resolve to candidate URL');
      const format={'application/rss+xml':'RSS','application/atom+xml':'Atom','application/feed+json':'JSON Feed','application/json':'JSON (verify feed)'}[S.mimeOf(w.type)];
      if(format!==c.format)throw Error('Feed witness MIME differs from candidate format');
    }else throw Error('Unsupported feed witness');
  }else{
    if(!exact(c,['kind','url','title','mode','selector','titleSelector','linkSelector'])||c.url!==p.siteUrl||!['region','cards'].includes(c.mode)||typeof c.title!=='string'||!c.title||c.title!==C.text(c.title,120))throw Error('Invalid page watcher candidate');
    if(!exact(w,['method','matchCount'])||w.method!=='css-selector'||!Number.isSafeInteger(w.matchCount)||w.matchCount<1||w.matchCount>200)throw Error('Invalid page witness');
    for(const key of ['selector','titleSelector','linkSelector'])if(typeof c[key]!=='string'||c[key].length>300)throw Error('Invalid CSS selector');
    C.cleanRecipe({id:'discovery-probe',type:'page',url:c.url,title:c.title,mode:c.mode,selector:c.selector,titleSelector:c.titleSelector,linkSelector:c.linkSelector});
  }
  if(digestFor(p)!==p.digest)throw Error('Discovery checksum mismatch');
  return p;
}
function makeProof(report,candidate,at=new Date().toISOString()){
  if(!report||!candidate||typeof candidate!=='object')throw Error('Choose a Scout discovery first');
  const siteUrl=C.safeUrl(report.siteUrl);
  let c,w;
  if(candidate.kind==='feed'){
    const url=C.safeUrl(candidate.url,siteUrl);
    const format=candidate.format==='RSS'?'RSS':candidate.format==='Atom'?'Atom':candidate.format;
    c={kind:'feed',url,title:C.text(candidate.title||url,120),format};
    if(candidate.origin==='body')w={method:'parsed-feed',format,itemCount:Number(report.count)||0};
    else{
      const e=candidate.evidence||{};
      w={method:candidate.origin==='http-header'?'http-link':'html-link',rel:String(e.rel||''),type:String(e.type||''),href:String(e.href||''),baseUrl:C.safeUrl(e.baseUrl||siteUrl)};
    }
  }else if(candidate.kind==='page'){
    c={kind:'page',url:siteUrl,title:C.text(candidate.title||'Watched webpage',120),mode:candidate.mode||'region',selector:String(candidate.selector||''),titleSelector:String(candidate.titleSelector||''),linkSelector:String(candidate.linkSelector||'')};
    w={method:'css-selector',matchCount:candidate.mode==='cards'?Number(candidate.count)||0:1};
  }else throw Error('Unsupported discovery type');
  const p={schema:SCHEMA,siteUrl,observedAt:at,candidate:c,witness:w,digest:''};p.digest=digestFor(p);
  return validateProof(p);
}
function evaluateProof(input,html,opts={}){
  const p=validateProof(input);
  if(typeof html!=='string'||!html.trim()||html.length>C.LIMIT.characters)throw Error('Provide an offline page/feed snapshot (up to 2M characters)');
  if(p.candidate.kind==='feed'){
    let report;
    try{report=S.scanMarkup(html,p.siteUrl,{linkHeader:opts.linkHeader||''});}catch(e){return {pass:false,status:'unreadable',detail:e.message};}
    if(p.witness.method==='parsed-feed'){
      const pass=report.kind==='direct-feed'&&report.candidates.some(x=>x.url===p.candidate.url && x.format===p.candidate.format);
      return {pass,status:pass?'confirmed':'missing',detail:pass?'Direct feed parsed again':'Document does not parse as this feed format'};
    }
    const match=report.candidates.find(x=>x.url===p.candidate.url&&x.format===p.candidate.format&&x.origin===(p.witness.method==='http-link'?'http-header':'html-head')&&x.evidence?.href===p.witness.href&&x.evidence?.rel===p.witness.rel&&x.evidence?.type===p.witness.type&&x.evidence?.baseUrl===p.witness.baseUrl);
    return {pass:Boolean(match),status:match?'confirmed':'missing',detail:match?'Exact advertised link replayed':'Original feed advertisement not found in this snapshot'};
  }
  try{
    const c=p.candidate;
    const captured=C.extractPage(html,{type:'page',url:c.url,mode:c.mode,selector:c.selector,titleSelector:c.titleSelector,linkSelector:c.linkSelector});
    const count=c.mode==='cards'?captured.cards.length:1;
    const drift=count!==p.witness.matchCount;
    return {pass:true,status:drift?'drift':'confirmed',observedCount:count,expectedCount:p.witness.matchCount,
      detail:drift?'Selector works but matching item count changed; review before adoption':'Selector still extracts a nonempty region'};
  }catch(e){return {pass:false,status:'missing',detail:'Page selector no longer extracts content: '+e.message};}
}
function toPausedLens(input,id){const p=validateProof(input),c=p.candidate;
  const source=C.cleanRecipe({id:id||C.uid('lens'),type:c.kind==='page'?'page':'rss',url:c.url,title:c.title,
    mode:c.kind==='page'?c.mode:'region',selector:c.kind==='page'?c.selector:'',
    titleSelector:c.kind==='page'?c.titleSelector:'',linkSelector:c.kind==='page'?c.linkSelector:'',threshold:24,author:'local'});
  return {...source,enabled:false,origin:'discovery-proof',lastScan:'',lastError:'',lastOutcome:'waiting'};
}
root.ProgRSSProof=Object.freeze({SCHEMA,MAX_BYTES,makeProof,validateProof,evaluateProof,toPausedLens,digestFor});
})(globalThis);
