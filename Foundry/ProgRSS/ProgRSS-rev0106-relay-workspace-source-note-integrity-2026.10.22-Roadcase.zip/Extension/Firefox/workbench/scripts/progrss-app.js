/* ProgRSS rev0020: Feed Commons / Chain Doctor; all prior Merkle and peer features retained. */
(() => {
'use strict';
const api=globalThis.browser||globalThis.chrome, C = globalThis.ProgRSSCore, Q = globalThis.ProgRSSCourier, S=globalThis.ProgRSSScout, P=globalThis.ProgRSSPulse, D=globalThis.ProgRSSProof, F=globalThis.ProgRSSForge, L=globalThis.ProgRSSLineage, T=globalThis.ProgRSSTrust, G=globalThis.ProgRSSSignedPatch, R=globalThis.ProgRSSRotation, H=globalThis.ProgRSSRecovery, J=globalThis.ProgRSSLedger, W=globalThis.ProgRSSGossip, M=globalThis.ProgRSSMerkle, E=globalThis.ProgRSSProofExchange, A=globalThis.ProgRSSCommons, X=globalThis.ProgRSSChainDoctor, B=globalThis.ProgRSSArena, Y=globalThis.ProgRSSFixtureGarden, $=id=>document.getElementById(id);
const AUTO='progrss.rev0003.autocheck', V=globalThis.ProgRSSVault;
function h(tag, attrs={}, children=[]) {
  const el=document.createElement(tag);
  for (const [key,value] of Object.entries(attrs)){
    if(key==='class')el.className=value;
    else if(key==='text')el.textContent=String(value);
    else if(key==='onclick')el.addEventListener('click',value);
    else if(key==='title')el.title=value;
    else if(key==='checked')el.checked=Boolean(value);
    else if(key==='value')el.value=value;
    else if(key==='disabled')el.disabled=Boolean(value);
    else el.setAttribute(key,String(value));
  }
  for(const child of children) el.append(child instanceof Node ? child : document.createTextNode(String(child)));
  return el;
}
const emptyState=()=>({version:17,sources:[],collections:[],items:[],snapshots:{},fixtures:[],inbox:[],receipts:[],retiredReceipts:[],subscriptions:[],publications:[],patchPins:[],keyRotations:[],recoveryPolicies:[],recoveryReceipts:[],charterHistory:[],charterClaims:[],gossipCards:[],witnessPins:[],merklePins:[],merkleReceipts:[],proofRequests:[],proofSightings:[],proofForks:[],fixturePacks:[],transferUndo:null,sourceRepairUndo:null,receiptRetirementUndo:null});
let trustReviewToken=0,pendingSignedEdition=null,trustVerified=null;
let state=emptyState(), currentView='home', activeCollection='all', bridge=false, autoTimer=null, busy=false, toastTimer;
let lastClinicAnalysis=null;
function persist(){
  let committed=false;
  Promise.resolve().then(async()=>{
    const gate=await api.runtime.sendMessage({target:'background',type:'assert-workbench-writable'});
    if(!gate?.ok){const err=Error(gate?.error||'ProgRSS could not verify the local library.');err.code=gate?.code||'FAILED';throw err;}
    await V.save(state);committed=true;
    const noted=await api.runtime.sendMessage({target:'background',type:'note-workbench-commit'});
    if(!noted?.ok){const err=Error(noted?.error||'The change was saved, but its recovery marker could not be updated.');err.code=noted?.code||'FAILED';throw err;}
  }).catch(err=>{
    if(err?.code==='STALE_VAULT'){
      globalThis.ProgRSSRevealReload?.();
      notify('Library changed in another ProgRSS view. Reload this Workbench before making more edits.',true);
      return;
    }
    if(err?.code==='LIBRARY_RECOVERY_REQUIRED'){
      globalThis.ProgRSSRevealReload?.();
      notify('This browser remembers an earlier library, but its local vault is empty or unreadable. Open the everyday reader to restore a private file or choose an empty library.',true);
      return;
    }
    if(committed){
      notify('The Workbench change was saved, but ProgRSS could not update its small recovery marker. Open the everyday reader and make a private recovery copy.',true);
      return;
    }
    try{api?.runtime?.sendMessage({target:'background',type:'report-storage-write-failure',data:{name:String(err?.storageName||err?.name||'Error'),reason:String(err?.storageReason||''),message:String(err?.message||err)}}).catch(()=>{})}catch{}
    notify('ProgRSS could not save that Workbench change. Your last saved library remains available. Open the everyday reader to save a recovery copy and check storage.',true);
  });
}
function renderVault(){const info=V.info();$('vault-status').textContent='Local vault: '+info.mode+ (info.mode==='memory'?' · BACKUP REQUIRED':'');$('vault-dot').classList.toggle('online',info.mode==='indexeddb');$('vault-dot').title=info.warning||'Local-only storage';}
function notify(message,error=false){const t=$('toast');t.textContent=message;t.classList.toggle('error',error);t.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.hidden=true,6500)}
function save(){persist();render()}
function action(label,fn,kind='ghost'){return h('button',{class:'btn sm '+kind, type:'button',text:label,onclick:fn})}
function originTitle(item){return state.sources.find(s=>s.id===item.sourceId)?.title||'Unknown source'}
function relative(iso){const d=Date.parse(iso);if(!d)return 'undated';const sec=Math.max(0,Math.round((Date.now()-d)/1000));return sec<60?'just now':sec<3600?Math.floor(sec/60)+'m ago':sec<86400?Math.floor(sec/3600)+'h ago':new Date(d).toLocaleDateString();}
function updateSelector(){const select=$('collection-choice'),keep=activeCollection;select.replaceChildren(h('option',{value:'all',text:'Every lens'}));state.collections.forEach(c=>select.append(h('option',{value:c.id,text:c.title})));if(keep!=='all'&&!state.collections.some(c=>c.id===keep))activeCollection='all';select.value=activeCollection;}
function renderHome(){
  $('stat-sources').textContent=state.sources.filter(s=>s.enabled).length;
  $('stat-collections').textContent=state.collections.length;
  $('stat-items').textContent=state.items.length;
  updateSelector();
  const list=$('feed-list'), search=$('search-items').value.trim().toLocaleLowerCase();
  const all=C.composeEvidence(state,activeCollection),filtered=all.filter(r=>!search||((r.item.title||'')+' '+(r.item.summary||'')+' '+originTitle(r.item)).toLocaleLowerCase().includes(search));
  renderTraceChoices();
  if(!filtered.length){list.replaceChildren(h('div',{class:'empty'},[
    h('span',{class:'symbol',text:'✳'}),h('h3',{text:all.length?'Nothing matches this search.':'Your observations will appear here.'}),
    h('p',{text:state.sources.length?'Use Check or Paste on a Lens to capture updates. Collection filters may also exclude all items.':'Start with a Lens or try the offline sample to experience feed composition.'}),
    action(state.sources.length?'View Lenses':'Make a Lens',()=>state.sources.length?go('sources'):openLens(),'primary')
  ]));return;}
  list.replaceChildren(...filtered.slice(0,150).map(({item,witnesses})=>{
    let safeLink='';try{if(item.url)safeLink=C.safeUrl(item.url)}catch{}
    const title= h('h3',{},[safeLink ? h('a',{href:safeLink,target:'_blank',rel:'noopener noreferrer',text:item.title}) : h('span',{text:item.title})]);
    return h('article',{class:'feed-item'},[
      h('span',{class:'feed-bullet '+(item.kind==='removed'?'removed':item.kind==='changed'?'changed':'')}),
      h('div',{class:'feed-inner'},[
        h('div',{class:'feed-top'},[h('span',{class:'feed-origin',text:originTitle(item)}),h('span',{class:'feed-date',text:relative(item.observedAt)})]),title,h('p',{text:item.summary||'No summary. Open the original source to read more.'}),...(['changed','removed'].includes(item.kind)?[h('span',{class:'feed-tag '+(item.kind==='removed'?'removed':''),text:item.kind==='removed'?'CARD REMOVED':'CHANGE DETECTED'})]:[]),
        h('div',{class:'witness-tools'},[h('span',{class:'mini',text:'WITNESSES '+new Set(witnesses.map(w=>w.sourceId)).size+' source(s)'}),action('Why here? ↗',()=>openTrace(item.id))])
      ])
    ]);
  }));
}
function traceText(result){
  if(!result.included)return 'NOT INCLUDED\n'+result.reason+'\n\nRule: '+(result.mode||activeCollection)+
    (Number.isInteger(result.matchedMembers)?' · matching members '+result.matchedMembers+'/'+result.totalMembers:'');
  return 'INCLUDED · '+result.mode.toUpperCase()+'\n'+result.reason+'\nIndependent originating source IDs: '+result.independentSources+
    '\n\nEVIDENCE PATHS\n'+(result.witnesses||[]).map((w,i)=>(i+1)+'. '+w.path.map(p=>(p.kind==='collection'?'⌗ ':'◉ ')+p.title+' (v'+p.version+')').join(' → ')).join('\n');
}
function openTrace(itemId){const item=state.items.find(i=>i.id===itemId);$('trace-dialog-title').textContent=item?.title||'Explain signal';$('trace-dialog-result').textContent=traceText(C.explainItem(state,itemId,activeCollection));show('trace-dialog');}
function renderTraceChoices(){const select=$('trace-choose'),old=select.value;select.replaceChildren(h('option',{value:'',text:'Choose an observation'}));
  for(const item of state.items.slice(0,350))select.append(h('option',{value:item.id,text:originTitle(item)+' · '+item.title.slice(0,85)}));
  if(state.items.some(i=>i.id===old))select.value=old;
}
function traceSelected(){const id=$('trace-choose').value;if(!id){$('trace-output').textContent='Choose any local observation, including one excluded from this collection.';return;}
  $('trace-output').textContent=traceText(C.explainItem(state,id,activeCollection));}
function renderSources(){const list=$('source-list');if(!state.sources.length){list.replaceChildren(h('div',{class:'empty content-panel'},[h('span',{class:'symbol',text:'◉'}),h('h3',{text:'No lenses yet.'}),h('p',{text:'Every independent observation begins with one page or one feed.'}),action('Create your first Lens',()=>openLens(),'primary')]));return;}
  list.replaceChildren(...state.sources.map(s=>h('article',{class:'row-card'},[
    h('div',{},[h('h3',{},[h('span',{class:'small-tag '+(s.enabled?'':'paused'),text:s.enabled?'LIVE':'PAUSED'}),h('span',{text:s.title})]),
      h('p',{class:'mono',text:s.url}),h('p',{text:(s.type==='rss'?'RSS / Atom / JSON Feed':s.mode==='cards'?'Page · repeated cards':'Page · text region')+' · rev '+(s.version||1)+(s.selector?' · selector '+s.selector:'')}),
      ...(s.lastError?[h('p',{style:'color:var(--red)',text:'Last error: '+s.lastError})]:[]),h('span',{class:'mini',text:'LAST CHECK '+(s.lastScan?relative(s.lastScan):'never')}),h('p',{class:'pulse-health'+(s.lastError?' problem':''),text:s.lastError?'CHECK NEEDS ATTENTION':s.lastOutcome==='throttled'?'HTTP '+(s.lastHttpStatus||429)+' · THROTTLED':s.lastOutcome==='unchanged'?'HTTP 304 · UNCHANGED / ZERO BODY':s.lastOutcome==='scanned'?'HTTP '+(s.lastHttpStatus||200)+' · '+(s.lastItems||0)+' NEW OR EDITED EVENTS':'WAITING FOR FIRST CHECK'}),
      h('p',{class:'pulse-forecast',text:P.format(s.pulse)}),
    ]),
    h('div',{class:'row-actions'},[
      action('↻ Check',()=>checkSource(s,{manual:true,requestAccess:true})),action('↥ Paste',()=>openPaste(s)),...(s.type==='page'?[action('♢ Clinic',()=>{go('clinic');clinicSelect(s.id)})]:[]),action('Edit',()=>openLens(s)),
      action(s.enabled?'Pause':'Enable',()=>{if(!s.enabled&&!confirm('Enable future checks for '+s.title+'? Your browser will contact '+s.url+' only when you manually check or enable an open-tab schedule.'))return;s.enabled=!s.enabled;save()}),
      action('×',()=>{if(!confirm('Delete Lens and its saved observations?'))return;state.sources=state.sources.filter(x=>x.id!==s.id);state.items=state.items.filter(x=>x.sourceId!==s.id);delete state.snapshots[s.id];state.collections.forEach(c=>c.members=c.members.filter(m=>!(m.kind==='source'&&m.id===s.id)));save()},'danger')
    ])
  ])));
}
function renderCollections(){const list=$('collection-list');if(!state.collections.length){list.replaceChildren(h('div',{class:'empty content-panel'},[h('span',{class:'symbol',text:'⌗'}),h('h3',{text:'No collections yet.'}),h('p',{text:'Collections are composable feeds. A collection can watch other collections.'}),action('Weave a collection',()=>openCollection(),'primary')]));return;}
  list.replaceChildren(...state.collections.map(c=>h('article',{class:'row-card'},[
    h('div',{},[h('h3',{},[h('span',{class:'small-tag',text:'GRAPH'}),h('span',{text:c.title})]),h('p',{text:c.members.length+' members · '+C.compose(state,c.id).length+' matching observations · '+(c.mode||'union').toUpperCase()+' · rev '+(c.version||1)}),h('p',{class:'mono',text:'include: '+(c.include||'everything')+' / exclude: '+(c.exclude||'nothing')})]),
    h('div',{class:'row-actions'},[
      action('View feed',()=>{activeCollection=c.id;go('home')}),action('Edit',()=>openCollection(c)),action('Share',()=>{activeCollection=c.id;downloadRecipes()}),
      action('×',()=>{if(!confirm('Delete collection '+c.title+'? Its sources remain.'))return;state.collections=state.collections.filter(x=>x.id!==c.id);state.collections.forEach(group=>group.members=group.members.filter(m=>!(m.kind==='collection'&&m.id===c.id)));save()},'danger')
    ])
  ])));
}
function renderCommons(){
  const rows=A.crossings(state),edits=A.edits(state);
  $('nav-commons').textContent=rows.length;
  $('commons-status').textContent=rows.length+' shared permalinks · '+edits.length+' retained feed edits';
  if(!rows.length)$('commons-list').replaceChildren(h('p',{class:'section-note',text:'No two Lenses point to the same permalink yet. Try the offline demo or import your own feeds.'}));
  else $('commons-list').replaceChildren(...rows.map(row=>h('article',{class:'row-card'},[
    h('div',{},[h('h3',{text:row.title}),h('p',{class:'mono',text:row.url}),h('p',{class:'mini',text:row.sourceCount+' different Lenses · '+row.hostCount+' distinct SOURCE hosts · '+(row.classification==='cross-host'?'Cross-host overlap (not proof of independent reporting)':'All Lenses hosted on the same domain')}),
      h('p',{class:'mini',text:row.sources.map(x=>x.sourceName+' ['+x.sourceHost+']').join(' · ')})]),
    h('div',{class:'row-actions'},[action('Draft intersection',()=>draftCommonsCollection(row),'primary')])
  ])));
  if(!edits.length)$('commons-edits').replaceChildren(h('p',{class:'section-note',text:'No modified stable feed entries observed yet. A feed entry must first be seen with an ID and later fetched with changed title, summary or permalink.'}));
  else $('commons-edits').replaceChildren(...edits.map(e=>h('article',{class:'row-card'},[
    h('div',{},[h('h3',{text:e.title}),h('p',{class:'mini',text:e.sourceName+' · entry edit #'+e.revision+' · '+relative(e.observedAt)}),h('p',{class:'mono',text:e.url||'(no permalink)'})]),
    h('div',{class:'row-actions'},[action('View observation',()=>{activeCollection='all';go('home');openTrace(e.id);})])
  ])));
}
function draftCommonsCollection(row){try{
  const draft=A.intersectionDraft(state,row);
  go('collections');openCollection();$('collection-name').value=draft.title;$('collection-mode').value='intersection';
  const wanted=new Set(draft.members.map(m=>m.kind+':'+m.id));
  for(const input of $('collection-members').querySelectorAll('input[type="checkbox"]'))input.checked=wanted.has(input.value);
  refreshCollectionBase();notify('INTERSECTION DRAFT ONLY · review matching source IDs, filters and save explicitly.');
}catch(e){notify('Commons draft blocked: '+e.message,true)}}
function commonsDemo(){
  if(!confirm('Load the existing fictional, offline two-feed demo? It will add example Lenses and observations to this local vault.'))return;
  loadDemo();go('commons');
}

function renderPulsePanel(){
  const counters=P.schedule(state.sources,Date.now(),99);
  $('pulse-summary').textContent='ADAPTIVE PULSE · '+counters.due.length+' due now · '+counters.later.length+' waiting · '+counters.held.length+' held for review. Each auto sweep contacts at most one Lens per host. Offline here means no network checks occur.';
}
function render(){
  renderPulsePanel();
  $('nav-items').textContent=state.items.length;$('nav-sources').textContent=state.sources.length;$('nav-collections').textContent=state.collections.length;
  $('nav-fixtures').textContent=state.fixtures.length;$('nav-courier').textContent=(state.inbox||[]).filter(x=>x.status==='pending').length;$('nav-lineage').textContent=(state.subscriptions||[]).length;if(currentView==='lineage')renderLineage();if(currentView==='recovery'){renderRecovery();renderLedger();renderGossip();renderExchange();}if(currentView==='peers')renderInbox();if(currentView==='home')renderHome();if(currentView==='sources')renderSources();if(currentView==='collections')renderCollections();if(currentView==='commons')renderCommons();if(currentView==='clinic'){renderClinicCases();renderGardenShelf();}
}
const viewNames={home:'TIMELINE',sources:'SOURCES',scout:'FIND FEEDS',collections:'COLLECTIONS',commons:'COMPARE FEEDS',lineage:'SHARED RECIPES',recovery:'TRUST RECOVERY',clinic:'PAGE REPAIR LAB',peers:'EXCHANGE',docs:'ABOUT & BACKUP'};
function go(page){currentView=page;Object.keys(viewNames).forEach(name=>$('view-'+name).hidden=page!==name);document.querySelectorAll('[data-view]').forEach(b=>{if(b.dataset.view===page)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current')});$('crumb-view').textContent=viewNames[page];if(page==='docs')$('doc-render').textContent=$('progrss-docs').textContent.trim();if(page==='peers')renderImportPreview();if(page==='clinic')clinicSelect($('clinic-source').value);render();}
function show(id){$(id).showModal()}
function close(id){$(id).close()}
function openLens(s=null){const f=$('lens-form');f.reset();$('lens-id').value=s?.id||'';$('lens-name').value=s?.title||'';$('lens-url').value=s?.url||'';$('lens-type').value=s?.type||'rss';$('lens-mode').value=s?.mode||'region';$('lens-selector').value=s?.selector||'';$('lens-title-selector').value=s?.titleSelector||'';$('lens-link-selector').value=s?.linkSelector||'';$('lens-include').value=s?.include||'';$('lens-exclude').value=s?.exclude||'';$('lens-threshold').value=s?.threshold??24;$('lens-ignore-numbers').checked=Boolean(s?.ignoreNumbers);$('lens-title').textContent=s?'Revise Lens':'Make a Lens';toggleLensFields();show('lens-dialog');}
function toggleLensFields(){let page=$('lens-type').value==='page';document.querySelectorAll('.page-only').forEach(el=>el.hidden=!page);document.querySelectorAll('.card-only').forEach(el=>el.hidden=!page||$('lens-mode').value!=='cards');}
function saveLens(e){e.preventDefault();let id=$('lens-id').value;const old=state.sources.find(s=>s.id===id);if(!id)id=C.uid('lens');let s;
  try {s=C.cleanRecipe({id,title:$('lens-name').value,type:$('lens-type').value,url:$('lens-url').value,mode:$('lens-mode').value,selector:$('lens-selector').value,titleSelector:$('lens-title-selector').value,linkSelector:$('lens-link-selector').value,threshold:$('lens-threshold').value,ignoreNumbers:$('lens-ignore-numbers').checked,include:$('lens-include').value,exclude:$('lens-exclude').value,author:old?.author||'local',version:old?(old.version||1)+1:1});}catch(error){return notify(error.message,true)}
  if(!old&&state.sources.length>=C.LIMIT.source)return notify('The lens limit is 200',true);
  if(old){Object.assign(old,s);old.lastError='';delete old.pulse;delete old.httpCache;delete state.snapshots[id];notify('Recipe revised. Its page baseline and polling plan were reset.')}else state.sources.push({...s,enabled:true,lastScan:'',lastError:'',origin:'local'});
  close('lens-dialog');save();go('sources');
}
function openCollection(col=null){$('collection-form').reset();$('collection-id').value=col?.id||'';$('collection-name').value=col?.title||'';$('collection-include').value=col?.include||'';$('collection-exclude').value=col?.exclude||'';$('collection-mode').value=col?.mode||'union';$('collection-title').textContent=col?'Revise collection':'Weave a collection';
  let members=$('collection-members');members.replaceChildren();const chosen=new Set((col?.members||[]).map(m=>m.kind+':'+m.id));const candidates=[...state.sources.map(s=>({kind:'source',id:s.id,title:s.title})),...state.collections.filter(c=>c.id!==col?.id).map(c=>({kind:'collection',id:c.id,title:c.title}))];
  for (const m of candidates){const check=h('input',{type:'checkbox',value:m.kind+':'+m.id,checked:chosen.has(m.kind+':'+m.id)});check.addEventListener('change',refreshCollectionBase);members.append(h('label',{},[check,h('span',{text:(m.kind==='collection'?'⌗ ':'◉ ')+m.title})]));}
  if(!candidates.length)members.append(h('p',{class:'section-note',text:'Add at least one Lens first.'}));refreshCollectionBase();if(col?.members?.length)$('collection-base').value=col.members[0].kind+':'+col.members[0].id;show('collection-dialog');}
function refreshCollectionBase(){
  const mode=$('collection-mode').value,field=$('collection-base-field');field.hidden=mode!=='subtract';
  const select=$('collection-base'),old=select.value;select.replaceChildren(h('option',{value:'',text:'Select the base member'}));
  for(const input of $('collection-members').querySelectorAll('input:checked')){const label=input.closest('label');select.append(h('option',{value:input.value,text:label?.textContent||input.value}));}
  if([...select.options].some(o=>o.value===old))select.value=old;else if(select.options.length>1)select.selectedIndex=1;
}
function saveCollection(e){e.preventDefault();const old=state.collections.find(c=>c.id===$('collection-id').value);const id=old?.id||C.uid('group');let memberIds=Array.from($('collection-members').querySelectorAll('input:checked')).map(x=>x.value);
  const mode=$('collection-mode').value;if(['intersection','subtract'].includes(mode)&&memberIds.length<2)return notify('Intersection/subtraction requires at least two members.',true);
  if(mode==='subtract'){const base=$('collection-base').value;if(!memberIds.includes(base))return notify('Select an included base member.',true);memberIds=[base,...memberIds.filter(v=>v!==base)];}
  try{
    // Editing a collection must not reconstruct direct source placements as only
    // {kind,id}. Preserve each selected source's canonical placement reason by
    // source ID; removals deliberately remove that placement and its reason.
    // Cleaning the old collection first also refuses ambiguous/conflicting
    // duplicate placements instead of choosing an automatic winner.
    const prior=old?C.cleanCollection(old):null;
    const priorSources=new Map((prior?.members||[]).filter(member=>member.kind==='source').map(member=>[member.id,member]));
    const members=memberIds.map(v=>{const [kind,...rest]=v.split(':'),member={kind,id:rest.join(':')};const previous=kind==='source'?priorSources.get(member.id):null;if(previous&&Object.prototype.hasOwnProperty.call(previous,'reason'))member.reason=previous.reason;return member});
    const candidate={id,title:$('collection-name').value,mode,include:$('collection-include').value,exclude:$('collection-exclude').value,author:old?.author||'local',version:old?(old.version||1)+1:1,members};
    const clean=C.cleanCollection(candidate);if(old)state.collections=state.collections.map(c=>c.id===id?clean:c);else{if(state.collections.length>=C.LIMIT.collection)throw Error('Collection limit reached');state.collections.push(clean)};
    C.exportBundle(state,'all');
  }catch(error){if(old)state.collections=state.collections.map(c=>c.id===id?old:c);else state.collections=state.collections.filter(c=>c.id!==id);return notify('Cannot save collection: '+error.message,true)}
  close('collection-dialog');save();go('collections');}
function openPaste(s){$('paste-form').reset();$('paste-source-id').value=s.id;$('paste-title').textContent='Capture: '+s.title;show('paste-dialog');}
function processContent(s,body){let added=0;
  if(s.type==='rss'){
    const parsed=C.parseFeed(body,s.url);added=C.ingestFeed(state,s,parsed);
    s.lastScan=new Date().toISOString();s.lastError='';notify('Parsed '+parsed.type.toUpperCase()+' · '+added+' new or edited entries');
  }else{
    const captured=C.extractPage(body,s),r=C.ingestPage(state,s,captured);added=r.added;
    s.lastScan=new Date().toISOString();s.lastError='';notify(r.baseline?'Baseline captured. Future changes can now be detected.':added+' new observations ('+captured.mode+')');
  }
  save();return added;
}
$('paste-form').addEventListener('submit',async e=>{e.preventDefault();const s=state.sources.find(x=>x.id===$('paste-source-id').value);if(!s)return;
  try {let value=$('paste-raw').value;if($('paste-file').files.length)value=await $('paste-file').files[0].text();if(!value.trim())throw Error('Paste content or select a file');processContent(s,value);close('paste-dialog');}catch(error){notify('Snapshot: '+error.message,true)}
});
async function detectBridge(){if(location.protocol!=='http:'||location.hostname!=='127.0.0.1'){setBridge(false);return}try{const r=await fetch('/api/status',{credentials:'omit',cache:'no-store'});let x=await r.json();setBridge(Boolean(r.ok&&x.project==='ProgRSS'&&x.broker))}catch{setBridge(false)}}
function setBridge(ok){bridge=ok;$('bridge-dot').classList.toggle('online',Boolean(api?.runtime?.id)||ok);$('bridge-status').textContent=api?.runtime?.id?'Extension fetch · access only to chosen sites':(ok?'Local CLI fetch bridge connected':'Webpage-only · CORS applies')}
async function requestOriginAccess(url){
  if(!api?.permissions)return true;
  try{
    const target=C.safeUrl(url),origin=new URL(target).origin+'/*';
    // request() must be reached directly from the button/form gesture. Do not
    // put an asynchronous permission check or network round trip before this call.
    const granted=await api.permissions.request({origins:[origin]});
    if(!granted)notify('Site access was not granted. ProgRSS did not fetch this address.',true);
    return granted;
  }catch(error){notify('Site access could not be requested: '+String(error?.message||error),true);return false;}
}
async function requestRemote(url,validators={}){
  const target=C.safeUrl(url);
  if(api?.runtime?.id){
    const response=await api.runtime.sendMessage({target:'background',type:'fetch-resource',data:{url:target,validators}});
    if(!response?.ok){const error=Error(response?.error||'Extension fetch failed');error.code=response?.code||'FAILED';throw error;}
    return response.result;
  }
  const headers={Accept:'application/rss+xml,application/atom+xml,application/feed+json,application/json,text/html,text/xml'};
  if(bridge){
    const params=new URLSearchParams({url:target});
    if(validators.etag)params.set('etag',validators.etag);
    if(validators.lastModified)params.set('last_modified',validators.lastModified);
    const r=await fetch('/api/fetch?'+params.toString(),{headers:{'X-ProgRSS-Client':'1'},credentials:'omit',cache:'no-store'});
    let json=await r.json();if(!r.ok)throw Error(json.error||'Local bridge fetch failed');
    return json;
  }
  const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),13000);
  try {
    // Standalone carrier fallback only. The Extension path above uses the
    // service worker's streamed 2 MB bound and credential-free fetch policy.
    const r=await fetch(target,{mode:'cors',redirect:'error',credentials:'omit',headers,signal:controller.signal,cache:'no-cache'});
    if(r.status===304)return {url:target,status:304,notModified:true,body:'',etag:r.headers.get('ETag')||'',lastModified:r.headers.get('Last-Modified')||'',linkHeader:r.headers.get('Link')||'',cacheControl:r.headers.get('Cache-Control')||''};
    if(r.status===429||r.status===503)return {url:target,status:r.status,notModified:false,body:'',cacheControl:r.headers.get('Cache-Control')||'',retryAfter:r.headers.get('Retry-After')||''};
    if(!r.ok)throw Error('HTTP '+r.status);
    const raw=await r.text();if(raw.length>C.LIMIT.characters)throw Error('Resource too large');
    return {url:target,status:r.status,notModified:false,body:raw,etag:r.headers.get('ETag')||'',lastModified:r.headers.get('Last-Modified')||'',linkHeader:r.headers.get('Link')||'',cacheControl:r.headers.get('Cache-Control')||''};
  }catch(error){throw Error('Site fetch failed: '+error.message+'. You can still inspect a saved snapshot offline.');}
  finally{clearTimeout(timeout)}
}
function cleanHttpCache(response,previous={},notModified=false){
  // These are local, non-shareable source-health hints, not trust signals.
  const validTag=x=>typeof x==='string'&&x.length<=200&&/^(?:W\/)?"[\x21\x23-\x7e]{0,190}"$/.test(x);
  const validDate=x=>typeof x==='string'&&x.length<=80&&/^[A-Za-z]{3}, [0-9]{2} [A-Za-z]{3} [0-9]{4} [0-9]{2}:[0-9]{2}:[0-9]{2} GMT$/.test(x);
  const etag=validTag(response.etag)?response.etag:(notModified?previous.etag||'':'');
  const lastModified=validDate(response.lastModified)?response.lastModified:(notModified?previous.lastModified||'':'');
  return {etag,lastModified};
}
async function checkSource(s,{manual=false,requestAccess=false}={}){
  if(!s.enabled)return notify('This Lens is paused. Enable it explicitly before fetching.',true);
  if(manual&&s.pulse?.needsReview&&!confirm('The server asked for a very long delay. Override the automatic hold and check '+s.title+' now?'))return;
  if(requestAccess&&!await requestOriginAccess(s.url))return;
  try{
    notify('Checking '+s.title+'…');const response=await requestRemote(s.url,bridge?(s.httpCache||{}):{});
    const now=Date.now(),status=response.status||200;
    s.lastScan=new Date(now).toISOString();s.lastHttpStatus=status;s.checkCount=(Number(s.checkCount)||0)+1;
    if(status===429||status===503){
      s.lastItems=0;s.lastOutcome='throttled';s.lastError='Upstream HTTP '+status+(response.retryAfter?' · Retry-After supplied':'');
      s.pulse=P.advance(s.pulse,'throttled',now,response);save();
      return notify('Paced by HTTP '+status+' · '+P.format(s.pulse),true);
    }
    s.httpCache=cleanHttpCache(response,s.httpCache||{},Boolean(response.notModified||status===304));
    s.lastError='';
    if(response.notModified||status===304){
      s.lastOutcome='unchanged';s.lastItems=0;s.pulse=P.advance(s.pulse,'quiet',now,response);save();
      return notify('HTTP 304 · next check planned in '+s.pulse.intervalMinutes+' minutes');
    }
    const count=processContent(s,response.body);
    s.lastOutcome='scanned';s.lastItems=count;
    s.pulse=P.advance(s.pulse,count>0?'changed':'quiet',now,response);
    save();
  }catch(error){
    if(error?.code==='PERMISSION_REQUIRED')return notify('Site access is not granted. Use Check on this Lens to review the request.',true);
    s.lastError=String(error.message).slice(0,300);s.lastOutcome='error';s.pulse=P.advance(s.pulse,'error',Date.now());
    save();notify('Check failed; '+P.format(s.pulse)+' · '+s.lastError,true);
  }
}
async function refreshAll(){
  if(busy)return;
  const sources=state.sources.filter(s=>s.enabled&&!s.pulse?.needsReview);
  if(!sources.length)return notify('No eligible enabled lenses. Enable a Lens or review a server-imposed hold.');
  busy=true;$('refresh-all').disabled=true;$('refresh-due').disabled=true;
  try{for(const s of sources){await checkSource(s,{manual:true});if(document.hidden)break;}}
  finally{busy=false;$('refresh-all').disabled=false;$('refresh-due').disabled=false;}
}
async function refreshDue(){
  if(busy)return;
  const plan=P.schedule(state.sources);
  if(!plan.due.length)return notify('Nothing due now · '+plan.later.length+' waiting · '+plan.held.length+' held.');
  busy=true;$('refresh-all').disabled=true;$('refresh-due').disabled=true;
  try{for(const s of plan.due){if(document.hidden)break;await checkSource(s);}}
  finally{busy=false;$('refresh-all').disabled=false;$('refresh-due').disabled=false;}
}
function applySchedule(){
  clearInterval(autoTimer);
  const v=Number($('auto-interval').value)||0;
  try{localStorage.setItem(AUTO,String(v))}catch{}
  // An open-tab timer only probes for due Lenses; Pulse decides whether a fetch is deserved.
  if(v>0)autoTimer=setInterval(()=>{if(!document.hidden&&!busy)refreshDue()},v*60*1000);
}
function download(name,data,mime){const a=h('a');const url=URL.createObjectURL(new Blob([data],{type:mime||'application/octet-stream'}));a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000)}
function downloadRecipes(){try{const data=C.exportBundle(state,activeCollection);download('ProgRSS-recipes-'+new Date().toISOString().slice(0,10)+'.json',JSON.stringify(data,null,2),'application/json');notify('Exported only public recipe definitions; no observations.')}catch(error){notify(error.message,true)}}
function exportJSONFeed(){const doc=C.makeJSONFeed(state,activeCollection);download('ProgRSS-timeline.json',JSON.stringify(doc,null,2),'application/feed+json')}
function exportBackup(){
  try{
    const portableState={...state,sources:(state.sources||[]).map(source=>{const portable={...source};delete portable.watchStability;return portable;})};
    delete portableState._revision;delete portableState.transferUndo;delete portableState.sourceRepairUndo;delete portableState.receiptRetirementUndo;delete portableState.sharedFolderUpdateUndo;delete portableState.pageWatchRepairUndo;
    const sourceNoteAudit=C.auditSourceNotes(portableState);
    if(sourceNoteAudit.errors.length)throw Error('This library has an invalid Source Note and cannot be exported: '+sourceNoteAudit.errors[0]);
    const data={schema:'progrss.private.v1',exportedAt:new Date().toISOString(),state:portableState};
    download('ProgRSS-private-backup.json',JSON.stringify(data,null,2),'application/json');
    notify('Private observations included, with '+sourceNoteAudit.count+' curator-written folder reason'+(sourceNoteAudit.count===1?'':'s')+'. Keep this file to yourself.');
  }catch(error){notify('Private backup not created: '+String(error?.message||error),true)}
}
let pending=null, pendingPatchCourierId=null;
function previewImport(bundle){try{let plan=C.importPreview(bundle,state);if(plan.sources.length+state.sources.length>C.LIMIT.source || plan.collections.length+state.collections.length>C.LIMIT.collection)throw Error('Import would exceed library limits');pending={plan,bundle,parcelId:null};renderImportPreview();go('peers');notify('Review incoming recipes before adding them.')}catch(error){notify('Import rejected: '+error.message,true)}}
function renderImportPreview(){const slot=$('import-preview');if(!pending){slot.className='empty';slot.replaceChildren(h('span',{class:'symbol',text:'↧'}),h('h3',{text:'No incoming recipes yet.'}),h('p',{text:'A received bundle appears here for manual review. Imported watchers will start paused.'}));return;}
  const {plan}=pending;slot.className='';slot.replaceChildren(h('div',{style:'padding:20px'},[
    h('h3',{text:plan.sources.length+' source recipes / '+plan.collections.length+' collections waiting'}),h('p',{class:'section-note',text:'Review these URL destinations. Nothing has been fetched, run, or saved. New sources will be paused.'}),
    h('div',{class:'stack'},plan.sources.slice(0,35).map(s=>h('div',{class:'row-card'},[h('div',{},[h('strong',{text:s.title}),h('p',{class:'mono',text:s.url}),h('p',{text:s.type+(s.selector?' · '+s.selector:'')})])]))),
    h('div',{class:'row-actions',style:'margin-top:18px;justify-content:flex-start'},[
      action('Import paused recipes',()=>{try{
        let fresh=plan;
        if(pending.parcelId){
          const entry=state.inbox.find(x=>x.id===pending.parcelId);
          if(!entry||entry.status!=='pending')throw Error('Courier item is already resolved');
          fresh=C.importPreview(Q.validateCapsule(entry.capsule).payload,state);
        }
        if(fresh.sources.length+state.sources.length>C.LIMIT.source||fresh.collections.length+state.collections.length>C.LIMIT.collection)throw Error('Library limit reached since review');
        if(pending.parcelId)Q.resolve(state,pending.parcelId,'accepted','Imported '+fresh.sources.length+' paused Lenses and '+fresh.collections.length+' collections');
        state.sources.push(...fresh.sources);state.collections.push(...fresh.collections);pending=null;save();renderImportPreview();notify('Recipes imported. New Lenses are paused.');go('sources');
      }catch(error){notify('Import blocked: '+error.message,true)}},'primary'),
      action('Discard',()=>{pending=null;renderImportPreview()})
    ])
  ]));
}
async function doImport(file){if(!file)return;if(file.size>12_000_000)return notify('Import file exceeds 12MB',true);try{const raw=await file.text();if(/\.opml$|\.xml$/i.test(file.name)){const recipes=C.parseOPML(raw);previewImport({schema:C.SCHEMA,sources:recipes,collections:[]});return;}
    const parsed=JSON.parse(raw);
    if(parsed.schema==='progrss.private.v1' && parsed.state){
      notify('Whole-library moves use the everyday reader so you can review what will be replaced, see which sources need Reconnect, and keep a 30-minute local undo. Open everyday reader → Add → Move this ProgRSS library. Nothing changed.',true);return;
    }
    if([Q.SCHEMA,C.PATCH_SCHEMA,G.SCHEMA,C.SCHEMA,D.SCHEMA,L.SCHEMA,T.SCHEMA,W.HEAD,W.SIGHT,E.REQUEST,E.REPLY,E.FORK,Y.SCHEMA].includes(parsed.schema)){receiveCourier(parsed,'file');return;}
    previewImport(parsed);
  }catch(error){notify('Import failed: '+error.message,true)}
}
function loadDemo(){if(state.sources.some(s=>s.id==='demo-blog'))return notify('Offline demo already present.');const feed={id:'demo-blog',title:'DEMO · Indie web posts',url:'https://example.org/blog.xml',type:'rss',include:'',exclude:'',selector:'',enabled:false,version:1,author:'ProgRSS sample',origin:'demo'};const page={id:'demo-projects',title:'DEMO · Project board changes',url:'https://example.org/projects',type:'page',mode:'cards',selector:'.project',include:'',exclude:'',enabled:false,version:1,author:'ProgRSS sample',origin:'demo'};
  state.sources.push(feed,page);processContent(feed,`<?xml version="1.0"?><rss version="2.0"><channel><title>Offline Sample</title><item><guid>paper-1</guid><title>Making the web observable again</title><link>https://example.org/notes/one</link><description>A thought experiment about local-first publishing.</description><pubDate>Fri, 09 Oct 2026 00:00:00 GMT</pubDate></item><item><guid>paper-2</guid><title>A new open-source filtering engine</title><link>https://example.org/notes/two</link><description>Rule recipes can be maintained collectively.</description></item></channel></rss>`);
  processContent(page,'<main><div class="project"><h2>A tiny web observatory</h2><a href="/projects/observatory">See project</a><p>Watch public pages even without RSS.</p></div></main>');
  processContent(page,'<main><div class="project"><h2>A tiny web observatory</h2><a href="/projects/observatory">See project</a><p>Watch public pages even without RSS.</p></div><div class="project"><h2>Collaborative selectors</h2><p>Repair extraction recipes together.</p></div></main>');
  const radar={id:'demo-radar',title:'DEMO · Bob’s independent curation',url:'https://example.org/bob.xml',type:'rss',enabled:false,version:1,author:'ProgRSS sample',origin:'demo'};
  state.sources.push(radar);processContent(radar,`<?xml version="1.0"?><rss version="2.0"><channel><title>Sample Bob curation</title><item><guid>bob-1</guid><title>Making the web observable again</title><link>https://example.org/notes/one</link><description>A second independent Lens selected the same example URL.</description></item><item><guid>bob-2</guid><title>Unusual handmade tools</title><link>https://example.org/notes/three</link><description>A different research thread.</description></item></channel></rss>`);
  const sourceRef=id=>({kind:'source',id});
  state.collections.push(
    {id:'demo-curation',title:'DEMO · Open web experiments (union)',mode:'union',members:[sourceRef(feed.id),sourceRef(page.id),sourceRef(radar.id)],include:'',exclude:'sponsored',version:1,author:'ProgRSS sample'},
    {id:'demo-consensus',title:'DEMO · Two independent Lenses (intersection)',mode:'intersection',members:[sourceRef(feed.id),sourceRef(radar.id)],include:'',exclude:'',version:1,author:'ProgRSS sample'},
    {id:'demo-subtract',title:'DEMO · Alice minus Bob (subtract)',mode:'subtract',members:[sourceRef(feed.id),sourceRef(radar.id)],include:'',exclude:'',version:1,author:'ProgRSS sample'});
  save();notify('Offline witness-algebra demo created. All example feeds and URLs are fictional and paused. Choose a collection to inspect the paths.');}

// WebRTC manual signaling. No identity claims. Only user-selected, validated recipes can be sent.
let peer=null,channel=null,packetParts=new Map();
let stagedProposal=null,pendingProposal=null,stagedSignedPatch=null,pendingSignedPatch=null,pendingPatchInbound=false,patchReviewToken=0;
function peerStatus(msg){$('peer-status').textContent=msg}
function resetPeer(){try{channel?.close()}catch{}try{peer?.close()}catch{}channel=null;peer=null;$('peer-send').disabled=true;$('peer-send-proposal').disabled=true;packetParts.clear();peerStatus('Disconnected · no recipes sent')}
function makePeer(){resetPeer();if(typeof RTCPeerConnection!=='function')throw Error('WebRTC data channels unavailable in this browser context');
  const config={iceServers:$('peer-stun').checked?[{urls:'stun:stun.l.google.com:19302'}]:[]};peer=new RTCPeerConnection(config);
  peer.ondatachannel=ev=>bindChannel(ev.channel);
  peer.onconnectionstatechange=()=>{if(!peer)return;peerStatus('Peer connection: '+peer.connectionState+' · channel '+(channel?.readyState||'none'));if(['failed','closed'].includes(peer.connectionState))$('peer-send').disabled=true};
  return peer;
}
function bindChannel(ch){channel=ch;ch.binaryType='arraybuffer';ch.bufferedAmountLowThreshold=65536;ch.onopen=()=>{peerStatus('Connected · ready for manually reviewed Courier and proof exchange');$('peer-send').disabled=false;$('peer-send-proposal').disabled=!stagedProposal;renderExchange();renderMerkle();};ch.onclose=()=>{peerStatus('Data channel closed');$('peer-send').disabled=true;$('peer-send-proposal').disabled=true};ch.onmessage=ev=>{
  try{if(typeof ev.data!=='string'||ev.data.length>16_000)throw Error('Oversize data chunk');const message=JSON.parse(ev.data);
    if(!['progrss.chunk.v1','progrss.patch.chunk.v1','progrss.capsule.chunk.v1'].includes(message.type)||typeof message.id!=='string'||!/^[-a-zA-Z0-9]{1,100}$/.test(message.id)||!Number.isInteger(message.index)||!Number.isInteger(message.total)||message.total<1||message.total>65||message.index<0||message.index>=message.total||typeof message.data!=='string'||message.data.length>12000)throw Error('Invalid peer chunk');
    if(!packetParts.has(message.id)){if(packetParts.size>3)packetParts.clear();packetParts.set(message.id,{type:message.type,total:message.total,parts:new Array(message.total),received:0,when:Date.now()});}
    let entry=packetParts.get(message.id);if(entry.total!==message.total||entry.type!==message.type||Date.now()-entry.when>120_000)throw Error('Inconsistent or expired chunk sequence');
    if(!entry.parts[message.index]){entry.parts[message.index]=message.data;entry.received++;}
    if(entry.received===entry.total){packetParts.delete(message.id);const assembled=entry.parts.join('');if(assembled.length>(entry.type==='progrss.patch.chunk.v1'?16_000:entry.type==='progrss.capsule.chunk.v1'?Q.MAX_ENVELOPE:650_000))throw Error('Peer payload too large');
      receiveCourier(JSON.parse(assembled),'webrtc');peerStatus('Received checked Courier package · saved for explicit review');}
  }catch(error){peerStatus('Rejected peer data: '+error.message)}
  };
}
function waitIce(pc){return new Promise(resolve=>{if(pc.iceGatheringState==='complete')return resolve();const deadline=setTimeout(done,10000);function done(){clearTimeout(deadline);pc.removeEventListener('icegatheringstatechange',onchange);resolve()}function onchange(){if(pc.iceGatheringState==='complete')done()}pc.addEventListener('icegatheringstatechange',onchange)});}
function setLocal(type){$('peer-local').value=JSON.stringify({schema:'progrss.signal.v1',type,sdp:peer.localDescription?.sdp||''});}
function parseSignal(){const raw=$('peer-remote').value;if(raw.length>40_000)throw Error('Oversized signaling packet');const p=JSON.parse(raw);if(p.schema!=='progrss.signal.v1'||!['offer','answer'].includes(p.type)||typeof p.sdp!=='string'||p.sdp.length>35_000)throw Error('Invalid ProgRSS signaling packet');return p;}
async function createOffer(){try{const pc=makePeer();bindChannel(pc.createDataChannel('progrss-recipes'));
  const offer=await pc.createOffer();await pc.setLocalDescription(offer);peerStatus('Gathering candidates for offer…');await waitIce(pc);setLocal('offer');peerStatus('Offer ready. Send it to a known collaborator.');}
  catch(error){resetPeer();notify('WebRTC: '+error.message,true)}
}
async function acceptOffer(){try{const incoming=parseSignal();if(incoming.type!=='offer')throw Error('Paste an offer to accept');const pc=makePeer();await pc.setRemoteDescription({type:'offer',sdp:incoming.sdp});await pc.setLocalDescription(await pc.createAnswer());peerStatus('Gathering candidates for answer…');await waitIce(pc);setLocal('answer');peerStatus('Answer ready. Send it to the offer creator.');}
  catch(error){resetPeer();notify('WebRTC: '+error.message,true)}
}
async function finishAnswer(){try{if(!peer||peer.signalingState!=='have-local-offer')throw Error('Create an offer in this tab first');const incoming=parseSignal();if(incoming.type!=='answer')throw Error('Paste an answer to finish');await peer.setRemoteDescription({type:'answer',sdp:incoming.sdp});peerStatus('Answer accepted. Waiting for data channel…')}
  catch(error){notify('WebRTC: '+error.message,true)}
}
async function sendPayload(kind,data){
  if(!channel||channel.readyState!=='open')throw Error('No open WebRTC data channel');
  const serialized=JSON.stringify(data),limit=kind==='progrss.patch.chunk.v1'?16000:kind==='progrss.capsule.chunk.v1'?Q.MAX_ENVELOPE:650000;
  if(serialized.length>limit)throw Error('Outgoing payload too large');
  const chunkSize=11000,parts=[];
  for(let start=0;start<serialized.length;){
    let end=Math.min(serialized.length,start+chunkSize);
    // Never bisect a surrogate pair; the JSON wrapper must preserve Unicode.
    if(end<serialized.length&&end>start&&/^[\uD800-\uDBFF]$/.test(serialized[end-1]))end--;
    parts.push(serialized.slice(start,end));start=end;
  }
  const total=parts.length;
  if(total<1||total>65)throw Error('Invalid chunk count');
  const packetId=C.uid('packet');
  for(let i=0;i<total;i++){
    // Use WebRTC's backpressure notification, with a timer fallback for
    // implementations which don't fire bufferedamountlow at exact equality.
    while(channel.bufferedAmount>128000){
      if(channel.readyState!=='open')throw Error('Channel disconnected');
      await new Promise(resolve=>{const timer=setTimeout(done,500);function done(){clearTimeout(timer);channel.removeEventListener('bufferedamountlow',done);resolve();}
        channel.addEventListener('bufferedamountlow',done,{once:true});});
    }
    channel.send(JSON.stringify({type:kind,id:packetId,index:i,total,data:parts[i]}));
  }
}
async function sendPeer(){try{const bundle=C.exportBundle(state,activeCollection);await sendPayload('progrss.capsule.chunk.v1',Q.makeCapsule(bundle,{note:'Shared collection '+activeCollection}));
    peerStatus('Sent '+bundle.sources.length+' recipes and '+bundle.collections.length+' collections; no observations');}
  catch(error){notify('Share failed: '+error.message,true)}
}
async function sendPeerProposal(){try{if(!stagedProposal)throw Error('Stage a proposal in Patch Clinic first');
    const payload=stagedSignedPatch?G.validateShape(stagedSignedPatch):C.validateProposal(stagedProposal);await sendPayload('progrss.capsule.chunk.v1',Q.makeCapsule(payload,{note:stagedSignedPatch?'Signed selector/filter proposal':'UNSIGNED selector/filter proposal'}));
    peerStatus((stagedSignedPatch?'SIGNED':'UNSIGNED')+' patch transmitted for independent local review; never auto-applied');}
  catch(error){notify('Patch transmission failed: '+error.message,true)}
}

// Patch Clinic: purely local regression specimens, never sent to public bundle or WebRTC.
function clinicSelect(want){
  const select=$('clinic-source'),chosen=want||select.value;
  select.replaceChildren(h('option',{value:'',text:'Choose a page Lens'}));
  for(const src of state.sources.filter(s=>s.type==='page'))select.append(h('option',{value:src.id,text:src.title+' · rev '+(src.version||1)}));
  select.value=state.sources.some(s=>s.id===chosen&&s.type==='page')?chosen:'';
  if(!select.value){const first=state.sources.find(s=>s.type==='page');if(first)select.value=first.id;}
  const src=state.sources.find(s=>s.id===select.value);
  $('clinic-mode').value=src?.mode||'region';$('clinic-selector').value=src?.selector||'';
  $('clinic-title-selector').value=src?.titleSelector||'';$('clinic-link-selector').value=src?.linkSelector||'';
  $('clinic-threshold').value=src?.threshold??24;$('clinic-ignore-numbers').checked=Boolean(src?.ignoreNumbers);
  lastClinicAnalysis=null;toggleClinicCardFields();renderClinicCases();renderProposalReview();resetForge();clearArena();
}
function toggleClinicCardFields(){document.querySelectorAll('.card-only-clinic').forEach(x=>x.hidden=$('clinic-mode').value!=='cards');}
function clinicDraft(){
  const src=state.sources.find(s=>s.id===$('clinic-source').value);
  if(!src)throw Error('Create or choose a webpage Lens first');
  return C.cleanRecipe({...src,mode:$('clinic-mode').value,selector:$('clinic-selector').value,
    titleSelector:$('clinic-title-selector').value,linkSelector:$('clinic-link-selector').value,
    threshold:$('clinic-threshold').value,ignoreNumbers:$('clinic-ignore-numbers').checked});
}
function clinicHtml(){const a=$('clinic-before').value,b=$('clinic-after').value;
  if(!a.trim()||!b.trim())throw Error('Paste or load both snapshots');
  if(a.length>C.LIMIT.fixtureChars||b.length>C.LIMIT.fixtureChars)throw Error('Patch Clinic snapshots must be 160K characters or less each');
  return [a,b];
}
function clinicFormat(result){
  if(result.mode==='region')return 'RESULT: '+result.outcome.toUpperCase()+'\nChanged characters: '+result.diff.delta+' | significant: '+result.diff.meaningful+
    '\n\nADDED\n'+(result.diff.added||'(none)')+'\n\nREMOVED\n'+(result.diff.removed||'(none)')+
    '\n\nBEFORE: '+result.beforePreview+'\nAFTER: '+result.afterPreview;
  return 'RESULT: '+result.outcome.toUpperCase()+'\nBEFORE '+result.beforeCount+' cards → AFTER '+result.afterCount+' cards'+
    '\nNew cards: '+result.added+' | Removed: '+result.removed+' | Edited: '+result.changed+' | Unchanged: '+result.unchanged+
    '\n\nNew: '+(result.examples.added.join(', ')||'(none)')+
    '\nRemoved: '+(result.examples.removed.join(', ')||'(none)')+
    '\nEdited: '+(result.examples.changed.join(', ')||'(none)');
}
function clinicReport(){
  const recipe=clinicDraft(),[before,after]=clinicHtml();
  const result=C.analyzePagePair(recipe,before,after);
  const fingerprint=JSON.stringify(recipe)+'\x00'+before+'\x00'+after;
  lastClinicAnalysis={fingerprint,recipe,result};
  $('clinic-result').classList.remove('failure');$('clinic-result').textContent=clinicFormat(result);
  return lastClinicAnalysis;
}
function runClinicCase(f,recipe){return C.fixtureVerdict(f,recipe);}
function renderClinicCases(){
  const source=$('clinic-source').value;
  const cases=state.fixtures.filter(f=>f.sourceId===source);
  const place=$('clinic-cases');
  if(!cases.length){place.replaceChildren(h('div',{class:'empty content-panel'},[h('span',{class:'symbol',text:'♢'}),h('h3',{text:'No proof cases for this Lens yet.'}),h('p',{text:'Try the demonstration pair, analyze it and save the expected outcome. Your specimens are private by default.'})]));return;}
  place.replaceChildren(...cases.map(f=>h('div',{class:'clinic-case'},[
    h('div',{},[h('strong',{text:f.title}),h('p',{text:'Expect '+f.expected+' · '+new Date(f.createdAt||Date.now()).toLocaleDateString()}),h('span',{class:'mini',text:'Raw HTML: '+(f.before.length+f.after.length).toLocaleString()+' chars · PRIVATE'})]),
    h('div',{class:'row-actions'},[
      action('Load',()=>{$('clinic-before').value=f.before;$('clinic-after').value=f.after;$('clinic-expected').value=f.expected;$('clinic-test-name').value=f.title;notify('Specimen loaded. Edit draft and click Analyze.') }),
      action('Remove',()=>{if(!confirm('Permanently remove this private specimen?'))return;state.fixtures=state.fixtures.filter(x=>x.id!==f.id);save()},'danger')
    ])
  ])));
}
function clinicDemonstration(){
  if(!state.sources.some(s=>s.id==='demo-clinic')){
    if(state.sources.length>=C.LIMIT.source)return notify('Lens library full; create room for a demonstration Lens.',true);
    state.sources.push({...C.cleanRecipe({id:'demo-clinic',type:'page',title:'DEMO · Patch Clinic sandbox',url:'https://example.org/projects',mode:'cards',selector:'.project',titleSelector:'h2',linkSelector:'a[href]',threshold:12,author:'ProgRSS example'}),enabled:false,origin:'demo'});
    save();
  }
  clinicSelect('demo-clinic');
  $('clinic-mode').value='cards';$('clinic-selector').value='.project';$('clinic-title-selector').value='h2';$('clinic-link-selector').value='a[href]';$('clinic-threshold').value='12';toggleClinicCardFields();
  $('clinic-before').value='<main><article class="project"><h2>Greenhouse</h2><a href="/a">Details</a><p>A tiny open web experiment.</p></article><article class="project"><h2>Old draft</h2><a href="/old">Details</a></article></main>';
  $('clinic-after').value='<main><article class="project"><h2>Greenhouse</h2><a href="/a">Details</a><p>A radically more collaborative open web experiment.</p></article><article class="project"><h2>Patch Clinic</h2><a href="/b">Details</a><p>A repairable new project.</p></article></main>';
  $('clinic-test-name').value='New, edited, and removed cards';$('clinic-expected').value='added';
  notify('Offline demonstration loaded; no network request. Analyze it next.');
}
function clinicAnalyze(){try{clinicReport()}catch(error){lastClinicAnalysis=null;$('clinic-result').classList.add('failure');$('clinic-result').textContent='RECIPE ERROR: '+error.message;notify(error.message,true)}}
function clinicSaveCase(){try{
  const {recipe,result}=clinicReport();if(state.fixtures.length>=C.LIMIT.fixtures)throw Error('Specimen limit reached (16). Export/archive and remove old cases first.');
  const [before,after]=clinicHtml();const name=$('clinic-test-name').value.trim()||'Case '+(state.fixtures.length+1);
  const fixture=C.cleanFixture({id:C.uid('case'),sourceId:recipe.id,title:name,expected:$('clinic-expected').value,before,after,createdAt:new Date().toISOString(),note:'Observed: '+result.outcome});
  state.fixtures.push(fixture);save();notify('Stored regression specimen privately. It will not enter recipe sharing.');
}catch(error){notify('Could not save specimen: '+error.message,true)}}
function clinicSuite(){
  try{const recipe=clinicDraft(),fixtures=state.fixtures.filter(f=>f.sourceId===recipe.id);
    if(!fixtures.length)throw Error('No saved specimens yet');
    const lines=[];let pass=0;
    for(const f of fixtures){try{const v=runClinicCase(f,recipe);if(v.pass)pass++;lines.push((v.pass?'PASS':'FAIL')+' · '+f.title+' · expected '+f.expected+' / observed '+v.result.outcome);}
      catch(err){lines.push('ERROR · '+f.title+' · '+err.message);}}
    const result=pass+'/'+fixtures.length+' passed against DRAFT recipe';
    $('clinic-result').classList.toggle('failure',pass!==fixtures.length);$('clinic-result').textContent=result+'\n\n'+lines.join('\n');
    lastClinicAnalysis=null;return {pass:pass===fixtures.length,summary:result};
  }catch(error){notify(error.message,true);return {pass:false,summary:error.message}};
}
function clinicApply(){try{
  const recipe=clinicDraft(),[a,b]=clinicHtml();
  const fingerprint=JSON.stringify(recipe)+'\x00'+a+'\x00'+b;
  if(!lastClinicAnalysis||lastClinicAnalysis.fingerprint!==fingerprint)throw Error('Analyze these exact snapshots with this draft before applying it');
  const fixtures=state.fixtures.filter(f=>f.sourceId===recipe.id);
  for(const f of fixtures){const test=runClinicCase(f,recipe);if(!test.pass)throw Error('Blocked: regression case '+f.title+' expects '+test.expected+' but observed '+test.result.outcome);}
  const original=state.sources.find(s=>s.id===recipe.id);
  if(!confirm('Apply this tested recipe to '+original.title+'? This will increment its version and reset its live page baseline.'))return;
  Object.assign(original,{...recipe,version:(original.version||1)+1,lastError:''});delete original.pulse;delete original.httpCache;delete state.snapshots[recipe.id];
  save();clinicSelect(recipe.id);notify('Tested recipe applied · revision '+original.version+' · baseline reset.');
}catch(error){notify('Patch refused: '+error.message,true)}}
function clinicExport(){try{
  const source=$('clinic-source').value;if(!source)throw Error('Choose a Lens');
  const bundle=C.exportFixtures(state.fixtures,source);
  if(!bundle.fixtures.length)throw Error('No specimens for this Lens');
  if(!confirm('This exports RAW HTML from '+bundle.fixtures.length+' cases. It may contain private content. Share only after inspecting the file. Continue?'))return;
  download('ProgRSS-SENSITIVE-HTML-specimens.json',JSON.stringify(bundle,null,2),'application/json');
  notify('Raw-HTML specimens exported separately. NEVER sent automatically over WebRTC.');
}catch(error){notify(error.message,true)}}
async function clinicImport(file){if(!file)return;try{
  if(file.size>5_300_000)throw Error('Fixture file too large');
  const incoming=C.validateFixtureBundle(JSON.parse(await file.text())),source=$('clinic-source').value;
  if(!source)throw Error('Choose a target page Lens first');
  if(state.fixtures.length+incoming.length>C.LIMIT.fixtures)throw Error('Total specimen limit is 16');
  if(!confirm('Import '+incoming.length+' raw-HTML specimens into the selected Lens? They remain private until explicitly exported.'))return;
  state.fixtures.push(...incoming.map(f=>({...f,id:C.uid('case'),sourceId:source})));
  save();notify('Imported '+incoming.length+' specimens into selected Lens.');
}catch(error){notify('Fixture import refused: '+error.message,true)}}

// Rev0009 / Selector Forge: only private snapshots are read. The Forge creates
// a temporary candidate shortlist, not a recipe change or transferable proof.
let lastForge=null;
function resetForge(){lastForge=null;const el=$('forge-results');if(el)el.replaceChildren(h('div',{class:'empty'},[h('p',{text:'Run Selector Forge on your current snapshot pair or saved specimens.'})]));}
function runForge(){
  const dest=$('forge-results');try{
    const draft=clinicDraft(),cases=[];
    const a=$('clinic-before').value,b=$('clinic-after').value;
    if(a.trim()&&b.trim())cases.push({name:$('clinic-test-name').value||'Current snapshot pair',before:a,after:b,expected:$('clinic-expected').value});
    const saved=state.fixtures.filter(f=>f.sourceId===draft.id);
    let remaining=F.MAX_TOTAL_CHARS-cases.reduce((n,c)=>n+c.before.length+c.after.length,0);
    for(const f of saved){if(cases.length>=F.MAX_CASES)break;
      if(f.before.length+f.after.length>remaining)continue;
      cases.push({name:f.title,before:f.before,after:f.after,expected:f.expected});remaining-=f.before.length+f.after.length;
    }
    if(!cases.length)throw Error('Provide a current before/after pair or save some private regression specimens first');
    const report=F.assess(draft,cases);
    lastForge={report,sourceId:draft.id};
    const lead=h('div',{class:'forge-intro'},[
      h('strong',{text:report.considered+' candidates · '+report.readyCount+' pass every included case'}),
      h('p',{text:'Tested '+report.caseCount+' private scenario(s). Passing means expected changes were detected on these snapshots; not that a selector is universally correct.'})
    ]);
    const cards=report.suggestions.map((suggestion,index)=>{
      const detail=suggestion.tests.map(t=>(t.pass?'✓ ':'✗ ')+t.name+': '+t.actual+' (expected '+t.expected+')').join(' · ');
      return h('article',{class:'forge-candidate'},[
        h('div',{},[h('strong',{text:(index+1)+'. '+suggestion.selector}),h('p',{text:detail}),h('span',{class:'mini',text:suggestion.passed+'/'+suggestion.total+' cases · '+(suggestion.ready?'ALL PASS':'NEEDS WORK')+(suggestion.isCurrent?' · CURRENT':'')})]),
        action('Use as draft',()=>{
          if($('clinic-source').value!==lastForge?.sourceId)return notify('Select the original Lens and rerun Forge.',true);
          $('clinic-selector').value=suggestion.selector;lastClinicAnalysis=null;
          notify('Selector loaded into DRAFT only. Analyze its extracted content, then stage a proposal if satisfied.');
        },'ghost')
      ]);
    });
    dest.replaceChildren(lead,...(cards.length?cards:[h('p',{class:'mini',text:'No safe selector candidates found in the supplied snapshots.'})]));
  }catch(e){lastForge=null;dest.replaceChildren(h('div',{class:'forge-intro forge-error',text:'Cannot suggest a repair: '+e.message}));notify('Selector Forge: '+e.message,true);}
}

// rev0021 / Fixture Garden: declarative fictional DOM packs; never derives
// shared content from private snapshots. Sharing is separately opt-in.
let gardenDraft=null,gardenCourierId=null;
function gardenOpen(raw,courierId=null){
  const pack=Y.validate(raw);gardenDraft=pack;gardenCourierId=courierId;
  $('garden-editor').value=JSON.stringify(pack,null,2);$('garden-attest').checked=false;
  gardenDescribe();return pack;
}
function gardenDescribe(){
 const p=gardenDraft;
 $('garden-report').textContent=p?'CHECKSUM VERIFIED · NOT A SIGNATURE\n'+p.title+'\n'+p.cases.length+' fictional cases · '+p.cases.filter(c=>c.holdout).length+' holdouts\n'+p.digest+'\n'+p.cases.map(c=>' · '+c.expected+' / '+c.label).join('\n')+'\nReview all text for sensitive content before exporting or saving.':'No checked pack in editor.';
}
function gardenCheck(){try{const raw=JSON.parse($('garden-editor').value);
 gardenDraft=raw?.digest?Y.validate(raw):Y.make(raw);gardenCourierId=null;gardenDescribe();
 notify('Fictional tree shapes and SHA-256 verified. Provenance and privacy are still your responsibility.');
}catch(e){gardenDraft=null;$('garden-report').textContent='FIXTURE GARDEN REFUSED: '+e.message;notify('Garden: '+e.message,true)}}
function gardenSeed(){gardenOpen(Y.example());notify('Invented three-case challenge. Try replaying against a webpage Lens; no network.');}
function gardenAttested(){if(!gardenDraft)throw Error('Verify a pack first');
 if(!$('garden-attest').checked)throw Error('Review the full pack and check the synthetic-content attestation first');
 return Y.validate(gardenDraft);}
function gardenSave(){try{const pack=gardenAttested();if(!Array.isArray(state.fixturePacks))state.fixturePacks=[];
 if(state.fixturePacks.some(p=>p.digest===pack.digest))throw Error('Pack already in your local shelf');
 if(state.fixturePacks.length>=12)throw Error('Garden shelf full (12 packs)');
 state.fixturePacks.unshift(pack);
 if(gardenCourierId){const row=state.inbox.find(e=>e.id===gardenCourierId&&e.status==='pending');if(row)Q.resolve(state,gardenCourierId,'accepted','Explicitly reviewed fictional DOM pack');}
 gardenCourierId=null;save();notify('Fixture pack saved after explicit review. Nothing changed on your Lenses.');
}catch(e){notify('Garden save blocked: '+e.message,true)}}
function gardenExport(){try{const pack=gardenAttested();
 if(!confirm('SHARE THIS PUBLIC, UNSIGNED FICTIONAL PACK?\n\n'+pack.title+'\n'+pack.cases.length+' cases / '+pack.digest+'\n\nEven fictional text can reveal details if copied from real pages. Confirm you reviewed the ENTIRE JSON.'))return;
 const pkg=Q.makeCapsule(pack,{note:'User-reviewed fictional DOM test pack; no signature or origin proof'});
 download('ProgRSS-fixture-garden-'+pack.digest.slice(7,19)+'.json',JSON.stringify(pkg,null,2),'application/json');
 notify('Exported fictional pack with two checksums; NOT signed or automatically trusted.');
}catch(e){notify('Garden export blocked: '+e.message,true)}}
async function gardenShare(){try{const pack=gardenAttested();
 if(!confirm('Send all '+pack.cases.length+' synthetic cases over WebRTC? This discloses all invented text in the pack.'))return;
 await sendPayload('progrss.capsule.chunk.v1',Q.makeCapsule(pack,{note:'Fictional DOM test pack; explicit local attestation'}));
 notify('Sent a fictional pack to peer Courier; recipient must review it.');
}catch(e){notify('Garden WebRTC send blocked: '+e.message,true)}}
function gardenRun(){try{const pack=Y.validate(gardenDraft),base=state.sources.find(s=>s.id===$('clinic-source').value);
 if(!base||base.type!=='page')throw Error('Choose a page Lens in Patch Clinic first');
 const candidates=[{label:'Current installed selector',changes:{}}];
 if(pack.hint&&pack.hint!==base.selector)candidates.push({label:'Community fictional hint',changes:{selector:pack.hint}});
 for(const parsed of B.parseCandidates($('arena-candidates').value))if(candidates.length<B.MAX_CANDIDATES&&!candidates.some(c=>c.changes.selector===parsed.changes.selector))candidates.push(parsed);
 const result=B.compare(base,Y.toCases(pack),candidates);
 $('garden-report').textContent='FICTIONAL OFFLINE REPLAY · '+pack.title+'\n'+pack.digest+'\n'+
 result.ranking.map(i=>{const row=result.rows[i],s=row.stats;return row.label+' · '+s.score+'/100 · pass '+s.pass+' · false alarms '+s.falsePositive+' · misses '+s.miss+' · wrong kinds '+s.wrongKind+' · errors '+s.error+'\n'+row.tests.map(t=>'  '+t.expected+' → '+t.actual+' · '+t.result).join('\n');}).join('\n')+
 '\n\nResults are from invented DOM trees, not the watched website. No selector was adopted.';
 notify('Compared '+result.rows.length+' filters against '+result.caseCount+' invented scenarios.');
}catch(e){$('garden-report').textContent='FICTIONAL REPLAY REFUSED: '+e.message;notify('Garden replay: '+e.message,true)}}
function renderGardenShelf(){const slot=$('garden-library');if(!slot)return;
 const packs=(state.fixturePacks||[]);
 slot.replaceChildren(...(packs.length?packs.map(pack=>h('div',{class:'row-card'},[
   h('div',{},[h('strong',{text:pack.title}),h('p',{class:'mini',text:pack.cases.length+' cases · '+pack.digest.slice(7,23)+'…'})]),
   h('div',{class:'row-actions'},[action('Inspect',()=>{gardenOpen(pack);}),action('Remove',()=>{if(!confirm('Remove fictional pack from this local shelf?'))return;state.fixturePacks=state.fixturePacks.filter(p=>p.digest!==pack.digest);save();},'danger')])
 ])):[h('p',{class:'mini',text:'No saved fictional regression packs. Your private Clinic specimens are separate.'})]));
}
async function gardenImportFile(file){if(!file)return;try{if(file.size>105000)throw Error('Fixture file exceeds 105KB');
 const raw=JSON.parse(await file.text());
 if(raw.schema===Q.SCHEMA){const cap=Q.validateCapsule(raw);if(cap.kind!=='fixture-pack')throw Error('Not a fictional fixture capsule');receiveCourier(cap,'file');}
 else gardenOpen(raw);
 notify('Fixture import requires explicit inspection and attestation.');
}catch(e){notify('Fixture import refused: '+e.message,true)}}

// rev0020 Filter Arena: ephemeral local scoreboards only. Never put specimen HTML
// in Courier, WebRTC, scorecards or recipe JSON. Adopting a winner is DRAFT ONLY.
let lastArena=null;
function clearArena(){lastArena=null;const out=$('arena-results');if(out)out.replaceChildren(h('p',{class:'mini',text:'Arena reset. Run comparisons on this Lens’s private regression specimens.'}));$('arena-export').disabled=true;}
function arenaCandidates(base){
  const entries=[{label:'Installed baseline',changes:Object.fromEntries(['mode','selector','titleSelector','linkSelector','threshold','ignoreNumbers'].map(k=>[k,base[k]]))}];
  const draft=clinicDraft();
  entries.push({label:'Current clinic draft',changes:Object.fromEntries(['mode','selector','titleSelector','linkSelector','threshold','ignoreNumbers'].map(k=>[k,draft[k]]))});
  entries.push(...B.parseCandidates($('arena-candidates').value));
  if($('arena-include-forge').checked&&lastForge?.sourceId===base.id){
    for(const f of lastForge.report.suggestions.slice(0,3))entries.push({label:'Forge: '+f.selector,changes:{...Object.fromEntries(['mode','selector','titleSelector','linkSelector','threshold','ignoreNumbers'].map(k=>[k,draft[k]])),selector:f.selector}});
  }
  const seen=new Set(),filtered=[];
  for(const entry of entries){
    const recipe=C.cleanRecipe({...base,...entry.changes});
    const key=JSON.stringify([recipe.mode,recipe.selector,recipe.titleSelector,recipe.linkSelector,recipe.threshold,Boolean(recipe.ignoreNumbers)]);
    if(!seen.has(key)){seen.add(key);filtered.push(entry);}
    if(filtered.length>=B.MAX_CANDIDATES)break;
  }
  return filtered;
}
function arenaCases(base){
  const selected=state.fixtures.filter(f=>f.sourceId===base.id),cases=[];
  // A holdout must be from SAVED specimens; never mark the current hand-edited
  // pair as held out because authors are adjusting it while testing.
  const holdout=$('arena-holdout').checked&&selected.length>1?selected[selected.length-1].id:null;
  let left=B.MAX_CHARS;
  for(const c of selected.slice(-B.MAX_CASES)){
    const chars=c.before.length+c.after.length;if(chars>left)continue;left-=chars;
    cases.push({name:c.title,before:c.before,after:c.after,expected:c.expected,holdout:c.id===holdout});
  }
  if($('arena-current-pair').checked&&cases.length<B.MAX_CASES){
    const a=$('clinic-before').value,b=$('clinic-after').value;
    if(a.trim()&&b.trim()&&a.length+b.length<=left&&a.length<=C.LIMIT.fixtureChars&&b.length<=C.LIMIT.fixtureChars){
      cases.push({name:'Current unsaved pair',before:a,after:b,expected:$('clinic-expected').value,holdout:false});
    }
  }
  return cases;
}
function runArena(){
  const slot=$('arena-results');$('arena-export').disabled=true;lastArena=null;
  try{
    const base=state.sources.find(s=>s.id===$('clinic-source').value);
    if(!base||base.type!=='page')throw Error('Choose a page Lens first');
    const entries=arenaCandidates(base),cases=arenaCases(base);
    if(!cases.length)throw Error('Save at least one regression specimen or provide a current before/after pair');
    const result=B.compare(base,cases,entries);lastArena={report:result,sourceId:base.id};$('arena-export').disabled=false;
    const scored=result.rows[0].stats.scored;
    const summary=h('div',{class:'forge-intro'},[
      h('strong',{text:result.rows.length+' distinct recipes · '+cases.length+' local cases · '+scored+' scored'}),
      h('p',{text:result.rows[0].stats.balanced?'Both quiet and changing cases included.':'ONE-SIDED: save at least one QUIET and one CHANGED case before drawing conclusions.'}),
      h('p',{text:result.leader===null?'No decisive leader under the current evidence.':'Local leader: '+result.rows[result.leader].label+'. Review each extraction before using it.'})
    ]);
    const cards=result.ranking.map(index=>{
      const row=result.rows[index],s=row.stats;
      const cases=h('div',{class:'arena-cases'},row.tests.map(test=>h('div',{class:'arena-case '+(test.result==='pass'||test.result==='smoke'?'pass':'fail'),text:(test.result==='pass'||test.result==='smoke'?'✓ ':'✗ ')+(test.holdout?'HOLDOUT · ':'')+test.name+': '+test.actual+' (wanted '+test.expected+')'})));
      return h('article',{class:'arena-entry '+(index===result.leader?'is-leader':'')},[
        h('div',{},[
          h('span',{class:'arena-badge',text:'OPTION '+(index+1)+(index===result.leader?' · LOCAL LEADER':'')+(s.clean?' · ALL SCORED PASS':'')}),
          h('h4',{text:row.label+' · '+(row.recipe.selector||'(entire document)')}),
          h('p',{text:'PASS '+s.pass+' · QUIET FALSE ALARMS '+s.falsePositive+' · MISSED EVENTS '+s.miss+' · WRONG KIND '+s.wrongKind+' · ERRORS '+s.error}),
          h('p',{text:'Held-out '+s.holdoutPass+'/'+s.holdoutTests+' · Balanced '+(s.balanced?'yes':'NO')+' · scores rank only your own cases.'}),
          cases]),
        h('div',{},[h('div',{class:'arena-score',text:String(s.score)+'/100'}),action('Use as draft',()=>{
          if(!lastArena||lastArena.sourceId!==$('clinic-source').value)return notify('Lens changed; rerun the Arena.',true);
          const r=lastArena.report.rows[index].recipe;
          $('clinic-mode').value=r.mode;$('clinic-selector').value=r.selector;
          $('clinic-title-selector').value=r.titleSelector||'';$('clinic-link-selector').value=r.linkSelector||'';
          $('clinic-threshold').value=r.threshold??24;$('clinic-ignore-numbers').checked=Boolean(r.ignoreNumbers);
          toggleClinicCardFields();lastClinicAnalysis=null;
          notify('Arena rule loaded as a DRAFT only. Recheck extracted content, then stage a reviewable patch to share.');
        },'ghost')])
      ]);
    });
    slot.replaceChildren(summary,...cards);
  }catch(e){slot.replaceChildren(h('div',{class:'forge-intro forge-error',text:'Filter Arena: '+e.message}));notify('Arena: '+e.message,true);}
}
function exportArena(){
  try{if(!lastArena||lastArena.sourceId!==$('clinic-source').value)throw Error('Run an Arena comparison on this Lens first');
    const data=B.publicAggregate(lastArena.report);
    if(!confirm('Export self-reported AGGREGATE COUNTS? No URLs, selectors, test HTML or names are included. Small counts could still disclose information about your local tests.'))return;
    download('ProgRSS-arena-aggregate.json',JSON.stringify(data,null,2),'application/json');
    notify('Exported anonymous aggregate scoreboard only. To share the actual selector, stage and sign a separate patch.');
  }catch(e){notify('Arena export refused: '+e.message,true)}
}
function arenaDemo(){
  clinicDemonstration();
  const src=state.sources.find(s=>s.id==='demo-clinic');if(!src)return;
  const one='<main><header>A compact navigation header with older links to previous documents</header><article class="project"><h2>Garden</h2><a href="/g">View</a><p>Ready</p></article></main>';
  const nav='<main><header>A huge promotion and navigation redesign with entirely rewritten advertisements and updated links</header><article class="project"><h2>Garden</h2><a href="/g">View</a><p>Ready</p></article></main>';
  const fresh='<main><header>A huge promotion and navigation redesign with entirely rewritten advertisements and updated links</header><article class="project"><h2>Garden</h2><a href="/g">View</a><p>Ready</p></article><article class="project"><h2>New Signal</h2><a href="/n">View</a></article></main>';
  const edited='<main><header>A huge promotion and navigation redesign with entirely rewritten advertisements and updated links</header><article class="project"><h2>Garden</h2><a href="/g">View</a><p>Changed substantially, the content has been rewritten here</p></article></main>';
  const samples=[{id:'demo-arena-quiet',title:'Navigation-only noise',before:one,after:nav,expected:'quiet'},
    {id:'demo-arena-added',title:'New project appears',before:nav,after:fresh,expected:'added'},
    {id:'demo-arena-edited',title:'Edited existing project [holdout]',before:nav,after:edited,expected:'changed-card'}];
  for(const data of samples)if(!state.fixtures.some(f=>f.id===data.id)){
    if(state.fixtures.length>=C.LIMIT.fixtures)break;
    state.fixtures.push(C.cleanFixture({...data,sourceId:src.id,createdAt:new Date().toISOString(),note:'Offline demo: no network or personal data'}));
  }
  save();clinicSelect(src.id);$('arena-candidates').value='main | 12 | off\n.broken | 12 | off';
  $('arena-include-forge').checked=false;$('arena-holdout').checked=true;
  $('arena-current-pair').checked=false;runArena();
  notify('Seeded a local quiet/add/edit challenge. Try other selectors; no network request made.');
}

// Rev0004 / non-executable proposals. These live in RAM until exported;
// peer exchange is transport only, not identity verification or auto-adoption.
function renderPatchPins(src){
  const slot=$('proposal-pins');slot.replaceChildren();
  if(!src){slot.append(h('p',{class:'mini',text:'Select a target page Lens first.'}));return;}
  const pins=G.pinsFor(state,src.url);
  if(!pins.length){slot.append(h('p',{class:'mini',text:'No signed-patch contributor pinned for this URL yet.'}));return;}
  for(const p of pins)slot.append(h('div',{class:'patch-pin'},[
    h('code',{text:p.keyId+' · '+p.addedAt.slice(0,10)}),
    action('Revoke pin',()=>{if(!confirm('Revoke trust pin '+p.keyId+' for '+p.url+'? A subsequent signed proposal from this key will require new approval.'))return;G.unpin(state,p.url,p.keyId);save();renderProposalReview();},'danger')
  ]));
}
async function renderProposalReview(){
  const token=++patchReviewToken,target=$('proposal-target'),previous=target.value;
  const output=$('proposal-report');$('proposal-apply').disabled=true;
  target.replaceChildren(h('option',{value:'',text:'Choose matching local page Lens'}));
  if(!pendingProposal){output.textContent='No proposal staged. Import a patch or draft one above.';renderPatchPins(null);return;}
  for(const src of state.sources.filter(s=>s.type==='page'&&s.url===pendingProposal.target.url))target.append(h('option',{value:src.id,text:src.title+' · rev '+(src.version||1)}));
  if([...target.options].some(o=>o.value===previous))target.value=previous;
  else{const exact=state.sources.find(s=>s.id===pendingProposal.target.id&&s.url===pendingProposal.target.url);target.value=exact?.id||target.options[1]?.value||'';}
  const src=state.sources.find(s=>s.id===target.value);renderPatchPins(src);
  if(!src){output.textContent='Patch targets '+pendingProposal.target.url+' but no matching page Lens exists. No URLs are added or fetched.';return;}
  output.textContent='Running local regression cases and independent signature verification…';
  try{
    const report=C.reviewProposal(pendingProposal,src,state.fixtures);
    const identity=pendingSignedPatch?await G.verify(pendingSignedPatch):null;
    if(token!==patchReviewToken)return;
    if(identity&&Q.canonical(identity.patch)!==Q.canonical(pendingProposal))throw Error('Signed patch no longer matches staged review');
    const guard=G.guard(state,src.url,identity,{incoming:pendingPatchInbound});
    const auth=identity?'SIGNATURE VERIFIED · '+identity.algorithm+'\nKEY: '+identity.keyId+'\n'+guard.status:
      (pendingPatchInbound?'UNSIGNED REMOTE PATCH · NO AUTHENTICATED SENDER':'LOCAL UNSIGNED DRAFT');
    output.textContent='PROPOSAL → '+pendingProposal.target.title+' · expected v'+pendingProposal.base.version+
      '\nAUTHENTICATION\n'+auth+'\nAuthor label: '+pendingProposal.author+' (self-declared)'+
      '\nNote: '+(pendingProposal.message||'(no explanation)')+
      '\n\nFIELD DIFF\n'+report.differences.map(d=>d.field+': '+JSON.stringify(d.old)+' → '+JSON.stringify(d.next)).join('\n')+
      '\n\nLOCAL REGRESSION ('+report.tests.filter(t=>t.pass).length+'/'+report.tests.length+')\n'+report.tests.map(t=>(t.pass?'PASS ':'FAIL ')+t.name+' · '+t.expected+' / '+t.actual).join('\n')+
      '\n\n'+(report.ok?'READY FOR EXPLICIT APPROVAL':'BLOCKED\n'+report.reasons.join('\n'));
    $('proposal-apply').disabled=!report.ok;
  }catch(error){if(token!==patchReviewToken)return;output.textContent='PATCH BLOCKED: '+error.message+'\nNo recipe or snapshot has been modified.';$('proposal-apply').disabled=true;}
}
function acceptIncomingProposal(value,signed=null){
  pendingProposal=C.validateProposal(value);pendingSignedPatch=signed?G.validateShape(signed):null;
  pendingPatchInbound=true;renderProposalReview();notify(signed?'Signed patch received. Verify fingerprint and local tests before approval.':'UNSIGNED patch received. It must pass local tests; existing pins may block adoption.');
}
async function signStagedPatch(){
  try{if(!stagedProposal)throw Error('Stage a local proposal before signing');
    const signed=await G.sign(stagedProposal);stagedSignedPatch=signed;pendingProposal=C.validateProposal(stagedProposal);pendingSignedPatch=signed;pendingPatchInbound=false;pendingPatchCourierId=null;
    $('proposal-export-signed').disabled=false;
    $('proposal-sign-status').textContent='SIGNED · '+signed.algorithm+'\n'+signed.keyId+'\nExact staged patch; no raw snapshots included.';
    await renderProposalReview();notify('Signed patch ready. Review and export, or send over WebRTC.');
  }catch(error){notify('Signing failed: '+error.message,true);$('proposal-sign-status').textContent='Not signed: '+error.message;}
}
function exportSignedPatch(){try{
  if(!stagedSignedPatch)throw Error('Sign a staged proposal first');
  const signed=G.validateShape(stagedSignedPatch),capsule=Q.makeCapsule(signed,{note:'Signed selector repair · local tests still required'});
  download('ProgRSS-capsule-signed-patch-'+capsule.digest.slice(7,19)+'.json',JSON.stringify(capsule,null,2),'application/json');
}catch(error){notify('Signed-patch export blocked: '+error.message,true)}}
function stagePatch(){const original=state.sources.find(s=>s.id===$('clinic-source').value);if(!original)throw Error('Choose a source Lens in Patch Clinic');
  const draft=clinicDraft();const tests=state.fixtures.filter(f=>f.sourceId===original.id).slice(0,12).map(f=>{
    let pass=false;try{pass=C.fixtureVerdict(f,draft).pass}catch{}
    return {name:f.title,expected:f.expected,pass};
  });
  const proposal=C.makeProposal(original,draft,$('proposal-note').value,tests);
  pendingPatchCourierId=null;stagedProposal=proposal;pendingProposal=proposal;stagedSignedPatch=null;pendingSignedPatch=null;pendingPatchInbound=false;
  $('proposal-export-signed').disabled=true;$('proposal-sign-status').textContent='UNSIGNED staged patch. Sign it to authenticate the contributor key.';renderProposalReview();
  $('peer-send-proposal').disabled=!(channel?.readyState==='open');
  notify('Patch staged without raw HTML. Use Export or the Exchange studio.');return proposal;
}
function exportPatch(){try{const proposal=stagePatch();download('ProgRSS-patch-'+proposal.target.id+'-v'+proposal.base.version+'.json',JSON.stringify(proposal,null,2),'application/json');}
  catch(error){notify('Cannot export patch: '+error.message,true)}
}
async function importPatch(file){if(!file)return;try{if(file.size>690000)throw Error('Patch file exceeds 690KB');const raw=JSON.parse(await file.text());pendingPatchCourierId=null;
    if(raw?.schema===Q.SCHEMA){const parcel=Q.validateCapsule(raw);if(!['patch','signed-patch'].includes(parcel.kind))throw Error('Not a patch parcel');receiveCourier(parcel,'file');return;}
    if(raw?.schema===G.SCHEMA){receiveCourier(raw,'file');return;}acceptIncomingProposal(raw);}
  catch(error){notify('Proposal import refused: '+error.message,true)}
}
async function applyPatch(){
  const button=$('proposal-apply');button.disabled=true;
  try{
    if(!pendingProposal)throw Error('No pending proposal');
    const proposal=C.validateProposal(pendingProposal),src=state.sources.find(s=>s.id===$('proposal-target').value),signedEnvelope=pendingSignedPatch;
    const identity=signedEnvelope?await G.verify(signedEnvelope):null;
    if(identity&&Q.canonical(identity.patch)!==Q.canonical(proposal))throw Error('Signed patch no longer matches previewed proposal');
    const status=G.guard(state,src?.url||proposal.target.url,identity,{incoming:pendingPatchInbound});
    const report=C.reviewProposal(proposal,src,state.fixtures);if(!report.ok)throw Error(report.reasons.join('; '));
    if(identity&&!status.known&&(G.pinsFor(state,src.url).length>=G.MAX_KEYS_PER_URL||state.patchPins.length>=G.MAX_PINS))throw Error('Contributor trust pin capacity reached');
    const label=identity?'Verified key '+identity.keyId+'\n'+status.status:'UNSIGNED '+(pendingPatchInbound?'REMOTE':'LOCAL')+' proposal';
    if(!confirm('Apply this tested repair to '+src.title+' after '+report.tests.length+' passing LOCAL cases?\n'+label+'\nThe old page baseline will be cleared.'))return;
    if(identity&&!status.known&&!confirm('PIN NEW CONTRIBUTOR? Compare the full key fingerprint through an independent channel first.\n'+identity.keyId+'\nThis is NOT proof of a human identity or a correct selector.'))return;
    if(pendingPatchCourierId){const e=state.inbox.find(x=>x.id===pendingPatchCourierId);if(!e||e.status!=='pending')throw Error('Courier patch was already resolved');
      const parcel=Q.validateCapsule(e.capsule);if(!['signed-patch','patch'].includes(parcel.kind))throw Error('Courier item is not a patch');
      const expected=parcel.kind==='signed-patch'?G.validateShape(parcel.payload).patch:C.validateProposal(parcel.payload);
      if(Q.canonical(expected)!==Q.canonical(proposal))throw Error('Courier package changed after review');
      if(parcel.kind==='signed-patch'&&!identity)throw Error('Signed Courier envelope missing verified signature');
      if(parcel.kind==='patch'&&identity)throw Error('Unsigned Courier envelope mismatches authenticated patch');
    }
    // No user-provided JS executes. Local test approval and signature verification
    // are repeated after the async consent flow before any mutation.
    if(identity){await G.verify(signedEnvelope);if(Q.canonical(G.validateShape(signedEnvelope))!==Q.canonical(G.validateShape(pendingSignedPatch)))throw Error('Signed envelope changed during approval');}
    if(Q.canonical(proposal)!==Q.canonical(C.validateProposal(pendingProposal)))throw Error('Patch was replaced while waiting for approval');
    const fresh=C.reviewProposal(proposal,src,state.fixtures);if(!fresh.ok)throw Error('Local regression suite changed since confirmation');
    if(identity){G.guard(state,src.url,identity,{incoming:pendingPatchInbound});G.pin(state,src.url,identity);}
    if(pendingPatchCourierId)Q.resolve(state,pendingPatchCourierId,'accepted',
      (identity?'SIGNED '+identity.keyId.slice(0,24):'UNSIGNED')+' reviewed patch to '+src.id+' v'+fresh.candidate.version);
    Object.assign(src,{...fresh.candidate,enabled:src.enabled,lastError:''});delete src.pulse;delete src.httpCache;delete state.snapshots[src.id];
    const id=src.id;pendingProposal=null;pendingPatchCourierId=null;pendingSignedPatch=null;stagedProposal=null;stagedSignedPatch=null;pendingPatchInbound=false;
    $('proposal-export-signed').disabled=true;$('proposal-sign-status').textContent='No staged signature.';$('peer-send-proposal').disabled=true;
    save();clinicSelect(id);renderProposalReview();notify('Reviewed '+(identity?'SIGNED ':'')+'repair adopted for '+src.title+' · revision '+src.version);
  }catch(error){notify('Patch application blocked: '+error.message,true);renderProposalReview();}
}

// Rev0005 / Courier: durable local inbox, no automatic adoption or fetch.
// Checksums are deliberately NOT signatures or trusted human identities.
function receiveCourier(packet,via='file'){
  try{const result=Q.receive(state,packet,via);save();go('peers');
    notify(result.duplicate?'Already in your Courier Inbox (same content digest).':'Courier package saved locally · checksum verified · waiting for review.');
    return result;
  }catch(error){notify('Courier refused: '+error.message,true);throw error;}
}
function renderInbox(){
  const slot=$('courier-inbox'),history=$('courier-receipts');
  slot.replaceChildren();
  if(!state.inbox?.length)slot.append(h('div',{class:'empty'},[h('h3',{text:'The Courier Inbox is empty.'}),h('p',{text:'Import a recipe/patch capsule, or receive one over WebRTC. Decisions persist when your browser storage does.'})]));
  for(const e of state.inbox||[]){
    let label='UNREADABLE',good=false,count='';
    try{const p=Q.validateCapsule(e.capsule);good=true;label=p.kind==='fixture-pack'?'Fictional regression pack (VERIFY BEFORE SAVING)':p.kind==='recipes'?'Recipe collection':p.kind==='patch'?'Unsigned repair patch':p.kind==='signed-patch'?'Signed repair patch (VERIFY ON REVIEW)':p.kind==='recovery-charter'?'Recovery Circle · owner-signed charter (VERIFY ON REVIEW)':p.kind==='recovery-packet'?'Recovery Circle · guardian packet (VERIFY ON REVIEW)':p.kind==='charter-change'?'Trust Ledger · signed charter change (VERIFY ON REVIEW)':p.kind.startsWith('merkle-')?'Merkle · signed tree/proof (VERIFY BEFORE PINNING)':['proof-request','proof-reply','fork-dossier'].includes(p.kind)?'Proof Exchange · '+p.kind+' (REVIEW FIRST)':p.kind==='trust-head'?'Signed publisher trust head (VERIFY ON REVIEW)':p.kind==='trust-sighting'?'Witness signed trust head (VERIFY ON REVIEW)':p.kind==='key-rotation'?'Key Bridge · DOUBLE signature (VERIFY ON REVIEW)':['edition','signed-edition'].includes(p.kind)?(p.kind==='signed-edition'?'Signed curator edition (UNVERIFIED until reviewed)':'Unsigned collection edition'):'Discovery evidence';count=p.kind==='fixture-pack'?p.payload.title+' · '+p.payload.cases.length+' fabricated cases':p.kind==='recipes'?p.payload.sources.length+' Lenses / '+p.payload.collections.length+' collections':p.kind==='patch'?p.payload.target.title:p.kind==='signed-patch'?p.payload.patch.target.title+' · '+p.payload.keyId:p.kind==='recovery-charter'?p.payload.subject.keyId.slice(0,25)+'… · '+p.payload.threshold+' of '+p.payload.guardians.length+' guardians':p.kind==='recovery-packet'?p.payload.request.successor.keyId.slice(0,25)+'… · '+p.payload.votes.length+' votes':p.kind==='charter-change'?p.payload.subject.keyId.slice(0,24)+'… · '+p.payload.action+' #'+p.payload.sequence:p.kind.startsWith('merkle-')?(p.payload.subject||p.payload.current?.subject||p.payload.head?.subject)?.keyId.slice(0,22)+'… · cryptographic proof':['proof-request','proof-reply','fork-dossier'].includes(p.kind)?(p.payload.previous||p.payload.request?.previous||p.payload.left)?.subject.keyId.slice(0,22)+'… · bounded public commitment':p.kind==='trust-head'?p.payload.subject.keyId.slice(0,22)+'… · #'+p.payload.sequence:p.kind==='trust-sighting'?p.payload.head.subject.keyId.slice(0,22)+'… · witnessed #'+p.payload.head.sequence:p.kind==='key-rotation'?p.payload.from.keyId.slice(0,27)+'… → '+p.payload.to.keyId.slice(0,27)+'…':['edition','signed-edition'].includes(p.kind)?'Channel '+(p.kind==='signed-edition'?p.payload.edition:p.payload).channel+' · #'+(p.kind==='signed-edition'?p.payload.edition:p.payload).sequence+' · '+(p.kind==='signed-edition'?p.payload.keyId:'UNSIGNED') :p.payload.candidate.url;}
    catch(error){count='Invalid content: '+error.message;}
    slot.append(h('article',{class:'courier-card'},[
      h('div',{class:'courier-top'},[h('div',{},[h('strong',{text:label}),h('span',{class:'courier-status',text:e.status.toUpperCase()+' · '+e.via})]),h('span',{class:'mini',text:relative(e.receivedAt)})]),
      h('p',{text:count}),h('p',{class:'courier-digest',text:e.id}),
      h('div',{class:'row-actions'},[
        ...(e.status==='pending'&&good?[action('Review contents',()=>reviewCourier(e.id),'primary'),action('Dismiss',()=>dismissCourier(e.id),'ghost')]:[]),
        ...(good?[action('Export',()=>exportCourier(e.id))]:[]),action('Delete',()=>{if(!confirm('Permanently delete this Courier package? The tiny acceptance/dismissal receipt remains.'))return;Q.deleteEntry(state,e.id);if(pending?.parcelId===e.id)pending=null;if(pendingPatchCourierId===e.id){pendingPatchCourierId=null;pendingProposal=null;pendingSignedPatch=null;pendingPatchInbound=false;}save();renderImportPreview();})
      ])
    ]));
  }
  const rows=(state.receipts||[]).slice(0,14);
  history.textContent=rows.length?rows.map(r=>r.at.slice(0,19).replace('T',' ')+' · '+r.action.toUpperCase()+' · '+r.kind+' · '+r.digest.slice(7,21)+'… · '+r.detail).join('\n'):'No adoption or dismissal decisions recorded yet.';
}
async function reviewCourier(id){
  try{
    const e=state.inbox.find(x=>x.id===id);
    if(!e||e.status!=='pending')throw Error('Not a pending package');
    const pkg=Q.validateCapsule(e.capsule);
    if(pkg.kind==='fixture-pack'){
      gardenOpen(pkg.payload,id);go('clinic');notify('Fictional pack opened for review. Confirm it contains no real or private data before saving or sharing.');
    }else if(pkg.kind==='recipes'){
      const plan=C.importPreview(pkg.payload,state);
      if(plan.sources.length+state.sources.length>C.LIMIT.source||plan.collections.length+state.collections.length>C.LIMIT.collection)throw Error('Library source/collection capacity exceeded');
      pending={plan,bundle:pkg.payload,parcelId:id};go('peers');renderImportPreview();
    }else if(pkg.kind==='patch'||pkg.kind==='signed-patch'){
      pendingPatchCourierId=id;acceptIncomingProposal(pkg.kind==='signed-patch'?pkg.payload.patch:pkg.payload,pkg.kind==='signed-patch'?pkg.payload:null);go('clinic');notify('Patch opened in Patch Clinic. Signature verification and local regression checks required.');
    }else if(pkg.kind==='edition'||pkg.kind==='signed-edition'){
      pendingEditionCourierId=id;pendingSignedEdition=pkg.kind==='signed-edition'?pkg.payload:null;pendingEdition=pendingSignedEdition?pendingSignedEdition.edition:pkg.payload;pendingLineageChoices=Object.create(null);go('lineage');notify('Edition opened. Signature verification and pinned-key review required before approval.');
    }else if(['proof-request','proof-reply','fork-dossier'].includes(pkg.kind)){
      await exchangeLoad(pkg.payload,id);notify('Proof Exchange opened. Signatures checked; proof requests never receive automatic replies or pin changes.');
    }else if(['merkle-head','merkle-consistency','merkle-inclusion'].includes(pkg.kind)){
      await merkleLoad(pkg.payload,id);notify('Signed Merkle artifact verified; explicit checkpoint approval is required.');
    }else if(pkg.kind==='trust-head'||pkg.kind==='trust-sighting'){
      await gossipLoad(pkg.payload,id);notify('Verified Witness Gossip opened; record only by explicit approval. No trust pin changed.');
    }else if(pkg.kind==='charter-change'){
      await ledgerLoad(pkg.payload,id);notify('Signed charter change loaded. Compare its predecessor, owner fingerprint and any forks before accepting.');
    }else if(pkg.kind==='recovery-charter'||pkg.kind==='recovery-packet'){
      await recoveryLoad(pkg.payload,id);notify('Recovery artifact opened for independent verification and explicit review.');
    }else if(pkg.kind==='key-rotation'){
      pendingRotationCourierId=id;go('lineage');renderRotationReview();notify('Rotation received. Verify both signatures and your existing pins before approval.');
    }else{
      activeProof=D.validateProof(pkg.payload);proofReplay=null;pendingDiscoveryCourierId=id;go('scout');renderProofWorkbench();
      notify('Discovery opened for review. Supply an independent site snapshot and replay before adopting.');
    }
  }catch(error){notify('Review blocked: '+error.message,true)}
}
function dismissCourier(id){
  try{if(!confirm('Dismiss this package without adding its recipes?'))return;
    Q.resolve(state,id,'dismissed','Declined without applying or fetching');
    if(pending?.parcelId===id)pending=null;
    if(pendingPatchCourierId===id){pendingPatchCourierId=null;pendingProposal=null;pendingSignedPatch=null;pendingPatchInbound=false;stagedProposal=null;stagedSignedPatch=null;}
    if(pendingDiscoveryCourierId===id){pendingDiscoveryCourierId=null;activeProof=null;proofReplay=null;renderProofWorkbench();}
    if(pendingEditionCourierId===id){pendingEditionCourierId=null;pendingEdition=null;pendingSignedEdition=null;pendingLineageChoices=Object.create(null);renderLineageReview();}
    if(pendingRotationCourierId===id){pendingRotationCourierId=null;renderRotationReview();}
    if(recoveryCourierId===id){recoveryCourierId=null;recoveryArtifact=null;renderRecovery();}
    if(ledgerCourierId===id){ledgerCourierId=null;ledgerArtifact=null;renderLedger();}
    if(gossipCourierId===id){gossipCourierId=null;gossipArtifact=null;renderGossip();}
    if(merkleCourierId===id){merkleCourierId=null;merkleArtifact=null;renderMerkle();}
    if(exchangeCourierId===id){exchangeCourierId=null;exchangeArtifact=null;renderExchange();}
    if(gardenCourierId===id){gardenCourierId=null;gardenDraft=null;}
    save();renderImportPreview();renderProposalReview();notify('Package dismissed; local receipt saved.');
  }catch(error){notify('Dismiss refused: '+error.message,true)}
}
function exportCourier(id){try{const e=state.inbox.find(x=>x.id===id);if(!e)throw Error('Package not found');const pkg=Q.validateCapsule(e.capsule);
  download('ProgRSS-capsule-'+pkg.kind+'-'+pkg.digest.slice(7,19)+'.json',JSON.stringify(pkg,null,2),'application/json');
}catch(error){notify('Export failed: '+error.message,true)}}
function courierDemonstration(){
  try{
    const demoSource=C.cleanRecipe({id:'courier-demo-notes',title:'DEMO · Handbuilt notes',type:'rss',url:'https://example.org/courier-notes.xml',author:'fictional collaborator'});
    const demoCollection=C.cleanCollection({id:'courier-demo-collection',title:'DEMO · Offline-curated collection',mode:'union',members:[{kind:'source',id:demoSource.id}],author:'fictional collaborator'});
    const payload=C.validateBundle({schema:C.SCHEMA,exportedAt:'2026-10-09T00:00:00Z',sources:[demoSource],collections:[demoCollection]});
    const parcel=Q.makeCapsule(payload,{note:'Offline demonstration only · URLs are examples, not real feeds'});
    const result=Q.receive(state,parcel,'local');save();go('peers');
    notify(result.duplicate?'Demo package already in Courier Inbox':'Demonstration package received · review it without fetching any website');
  }catch(error){notify('Demo creation failed: '+error.message,true)}
}
function exportNewCourier(){try{const pkg=Q.makeCapsule(C.exportBundle(state,activeCollection),{note:'Selected collection: '+activeCollection});
  download('ProgRSS-capsule-recipes-'+pkg.digest.slice(7,19)+'.json',JSON.stringify(pkg,null,2),'application/json');notify('Shareable checked capsule exported · observations excluded.');
}catch(error){notify('Capsule export failed: '+error.message,true)}}
function exportCourierPatch(){try{if(!stagedProposal)throw Error('Stage a proposal in Patch Clinic first');const pkg=Q.makeCapsule(stagedSignedPatch||stagedProposal);
  download('ProgRSS-capsule-patch-'+pkg.digest.slice(7,19)+'.json',JSON.stringify(pkg,null,2),'application/json');
}catch(error){notify('Patch capsule export failed: '+error.message,true)}}

// Rev0011: signer state is separate from the JSON vault and is never exported.
async function renderTrustIdentity(){
  const field=$('trust-key-status'),create=$('trust-key-create');
  try{const identity=await T.getIdentity();
    field.textContent=identity?'ACTIVE '+identity.algorithm+'\nFINGERPRINT: '+identity.keyId+'\nCreated '+identity.createdAt+'\nUse another trusted channel to compare this fingerprint.':'No signing key in this browser origin. Signed publishing is unavailable until you create one.';
    create.disabled=Boolean(identity);
  }catch(e){field.textContent='IDENTITY STORAGE UNAVAILABLE: '+e.message+'\nUnsigned compatibility publication remains available; signatures may still be verified where Web Crypto works.';create.disabled=false;}
}
async function createTrustIdentity(){
  if(!confirm('Create a new non-exportable curator signing key for this browser origin? It will NOT be included in JSON backups. Losing the origin may permanently strand signed publication channels.'))return;
  try{const identity=await T.createIdentity();await renderTrustIdentity();notify('Signing key created: '+identity.keyId+'. Compare this fingerprint out of band with collaborators.');}
  catch(e){notify('Signing key not created: '+e.message,true);await renderTrustIdentity();}
}
// Rev0013 · Key Bridge: staged non-exportable key; manual dual-signature handoff.
let pendingRotationCourierId=null,rotationReviewToken=0;
function latestLocalRotationCapsule(){
  return (state.inbox||[]).filter(e=>e.via==='local'&&e.capsule?.kind==='key-rotation')
    .map(e=>{try{return {entry:e,capsule:Q.validateCapsule(e.capsule)}}catch{return null}}).find(Boolean)||null;
}
function localRotationCapsule(oldKeyId,newKeyId){
  return (state.inbox||[]).filter(e=>e.via==='local'&&e.capsule?.kind==='key-rotation')
    .map(e=>{try{return {entry:e,capsule:Q.validateCapsule(e.capsule)}}catch{return null}})
    .find(e=>e?.capsule.payload.from.keyId===oldKeyId&&e.capsule.payload.to.keyId===newKeyId)||null;
}
async function renderKeyBridge(){
  const slot=$('key-bridge-status');if(!slot)return;
  try{const active=await T.getIdentity(),pending=await T.getPendingIdentity();
    const local=active&&pending?localRotationCapsule(active.keyId,pending.keyId):null;
    slot.textContent=(active?'ACTIVE '+active.keyId:'Create a Trust Keys identity first.')+ '\n'+
      (pending?'STAGED replacement '+pending.keyId+'\n'+(local?'Joint proof retained in Courier · export again before activation.':'No retained proof · stage/export first.'):
        'No pending replacement. Your active identity remains in use.');
    $('key-bridge-stage').disabled=!active;
    $('key-bridge-activate').disabled=!local;
    $('key-bridge-send').disabled=!(latestLocalRotationCapsule()&&channel?.readyState==='open');
  }catch(e){slot.textContent='Key Bridge storage unavailable: '+e.message;$('key-bridge-stage').disabled=true;$('key-bridge-activate').disabled=true;$('key-bridge-send').disabled=true;}
}
async function stageKeyRotation(){
  try{
    const active=await T.getIdentity();if(!active)throw Error('Create a signing key first');
    let pending=await T.getPendingIdentity();
    if(!pending){if(!confirm('Generate a new non-exportable key? The old key stays ACTIVE while its replacement is staged. Export the jointly signed transition BEFORE activation.'))return;pending=await T.createPendingIdentity();}
    let local=localRotationCapsule(active.keyId,pending.keyId);
    if(!local){const certificate=await R.sign(active,pending,$('key-bridge-note').value);
      const capsule=Q.makeCapsule(certificate,{note:'Two-key rotation proof · review before pin migration'});
      const entry=Q.receive(state,capsule,'local').entry;local={entry,capsule};save();}
    download('ProgRSS-key-bridge-'+local.capsule.payload.from.keyId.slice(0,17)+'-'+local.capsule.payload.to.keyId.slice(0,17)+'.json',JSON.stringify(local.capsule,null,2),'application/json');
    await renderKeyBridge();notify('Dual-signed certificate exported. Save it and send it to subscribers BEFORE activating the replacement key.');
  }catch(e){notify('Rotation staging blocked: '+e.message,true);await renderKeyBridge()}
}
async function activateKeyRotation(){
  try{
    const active=await T.getIdentity(),pending=await T.getPendingIdentity();
    if(!active||!pending)throw Error('No staged key ready to activate');
    const local=localRotationCapsule(active.keyId,pending.keyId);
    if(!local)throw Error('No durable rotation certificate in Courier. Export a dual-signed certificate first.');
    const verified=await R.verify(local.capsule.payload);
    if(verified.from.keyId!==active.keyId||verified.to.keyId!==pending.keyId)throw Error('Staged proof and keys differ');
    if(!confirm('ACTIVATE NEW SIGNING KEY?\n\nOld: '+active.keyId+'\nNew: '+pending.keyId+'\n\nHave you SAVED the exported capsule and shared its old+new signed proof? The old non-exportable signing key will be retired. Your followers must separately approve the rotation. There is no automatic lost-key recovery.'))return;
    await T.activatePendingIdentity(active.keyId,pending.keyId);
    for(const record of state.publications||[])if(record.signerKeyId===active.keyId){record.signerKeyId=pending.keyId;record.rotationNeedsEdition=true;}
    if(local.entry.status==='pending')Q.resolve(state,local.entry.id,'accepted','Locally activated dual-signed key bridge; certificate retained for forwarding');
    if(!Array.isArray(state.keyRotations))state.keyRotations=[];
    state.keyRotations.unshift({digest:verified.digest,from:verified.from.keyId,to:verified.to.keyId,at:new Date().toISOString(),curators:0,contributors:0});state.keyRotations=state.keyRotations.slice(0,60);
    save();await renderTrustIdentity();await renderKeyBridge();notify('New signing key is ACTIVE. Publish a new edition on each signed channel; recipients must approve the key bridge first.');
  }catch(e){notify('Key activation failed: '+e.message,true);await renderKeyBridge()}
}
async function sendKeyRotation(){
  try{const local=latestLocalRotationCapsule();if(!local)throw Error('No locally retained rotation certificate; export one first');
    await sendPayload('progrss.capsule.chunk.v1',local.capsule);
    notify('Sent dual-signed key-rotation capsule for manual Courier review.');
  }catch(e){notify('Key bridge peer transfer failed: '+e.message,true)}
}
async function renderRotationReview(){
  const token=++rotationReviewToken,slot=$('key-bridge-review'),button=$('key-bridge-approve');button.disabled=true;
  if(!pendingRotationCourierId){slot.textContent='Import a key-rotation certificate through Courier to review it here.';return;}
  slot.textContent='Verifying BOTH cryptographic signatures and exact local pins…';
  try{
    const entry=state.inbox.find(e=>e.id===pendingRotationCourierId&&e.status==='pending');
    if(!entry)throw Error('Courier item no longer pending');
    const capsule=Q.validateCapsule(entry.capsule);if(capsule.kind!=='key-rotation')throw Error('Not a rotation certificate');
    const verified=await R.verify(capsule.payload);
    if(token!==rotationReviewToken)return;
    const plan=R.preview(state,verified);
    slot.textContent=[
      'BOTH SIGNATURES VALID · this proves OLD + NEW private-key authorization, not human identity',
      'OLD KEY: '+plan.from,'NEW KEY: '+plan.to,
      'ISSUED: '+verified.issuedAt,'NOTE: '+(verified.note||'(none)'),
      'CERTIFICATE SHA-256: '+verified.digest,
      '','PIN TRANSFER (only pre-existing old-key pins):',
      ...plan.curatorChannels.map(v=>'  Collection channel: '+v),...plan.patchUrls.map(v=>'  Watched URL: '+v),
      'TOTAL: '+plan.curatorCount+' curator(s) + '+plan.patchCount+' repair contributor(s)',
      '','Old pins are REPLACED, never kept as silent alternates. New editions/patches still require separate review.',
      'IMPORTANT: If the OLD key was compromised, a malicious rotation may also be validly signed. Compare fingerprints out-of-band.'
    ].join('\n');button.disabled=false;
  }catch(e){if(token!==rotationReviewToken)return;slot.textContent='ROTATION NOT APPROVABLE\n'+e.message+'\n\nA lost old key cannot authorize this transition; re-establish trust manually out of band.';}
}
async function applyRotation(){
  const id=pendingRotationCourierId;if(!id)return;
  $('key-bridge-approve').disabled=true;
  try{const entry=state.inbox.find(e=>e.id===id&&e.status==='pending');if(!entry)throw Error('Courier parcel unavailable');
    const capsule=Q.validateCapsule(entry.capsule);if(capsule.kind!=='key-rotation')throw Error('Wrong Courier kind');
    const verified=await R.verify(capsule.payload),plan=R.preview(state,verified);
    if(!confirm('REPLACE '+(plan.curatorCount+plan.patchCount)+' EXISTING TRUST PIN(S)?\n\n'+plan.from+'\n      →\n'+plan.to+'\n\nOnly proceed after confirming this rotation with the collaborator through a separate trusted channel. This cannot be undone automatically.')){await renderRotationReview();return;}
    // Final verification and pin selection repeated at commit; no preview-only authority.
    const applied=await R.apply(state,capsule.payload);
    Q.resolve(state,id,'accepted','BOTH signatures verified; rotated '+applied.curatorCount+' curator + '+applied.patchCount+' exact-URL pins');
    pendingRotationCourierId=null;save();renderLineage();notify('Trust pins migrated by explicit approval. Prior key revoked for those pins; content updates still need review.');
  }catch(e){notify('Rotation approval blocked: '+e.message,true);await renderRotationReview()}
}
// Rev0010 · Lineage Room: manual proof-of-lineage sharing, no external fetch.
let pendingEdition=null,pendingEditionCourierId=null,pendingLineageChoices=Object.create(null);
function lineageIssueCurrent(record){
  const current=C.exportBundle(state,record.root),history=record.history||[];
  const last=history[history.length-1],prev=history.length>1?history[history.length-2].digest:'';
  if(!last||record.sequence!==last.sequence)throw Error('Publisher history missing');
  const edition=L.editionFromGraph(record.channel,record.sequence,prev,record.root,current,last.note,last.at);
  if(edition.digest!==record.digest)throw Error('Your collection changed since publication. Publish a new edition first.');
  return edition;
}
function renderLineage(){
  const select=$('lineage-root'),keep=select.value;
  select.replaceChildren(h('option',{value:'',text:'Choose a local collection'}));
  for(const col of state.collections)select.append(h('option',{value:col.id,text:col.title}));
  if(state.collections.some(c=>c.id===keep))select.value=keep;
  const pubs=$('lineage-publications');pubs.replaceChildren();
  if(!state.publications.length)pubs.append(h('p',{class:'mini',text:'No publication channels yet. Choose a collection and publish its first edition.'}));
  for(const rec of state.publications){
    const row=h('article',{class:'lineage-record'},[
      h('strong',{text:state.collections.find(c=>c.id===rec.root)?.title||'Retired collection'}),
      h('p',{text:'Published edition #'+rec.sequence+' · '+(rec.history||[]).length+' locally recorded revision(s) · '+(rec.signerKeyId?'SIGNED '+rec.signerKeyId:'UNSIGNED LEGACY')}),
      h('code',{text:rec.channel+' · '+rec.digest.slice(0,24)+'…'}),
      h('p',{text:(rec.history||[]).slice(-3).map(e=>'#'+e.sequence+' '+(e.summary||'No note')).join(' · ')})
    ]);pubs.append(row);
  }
  const subs=$('lineage-subscriptions');subs.replaceChildren();
  if(!state.subscriptions.length)subs.append(h('p',{class:'mini',text:'No pinned subscriptions. Import a curator edition through Courier or try the offline demo.'}));
  for(const sub of state.subscriptions){
    const local=state.collections.find(c=>c.id===sub.localRoot);
    const row=h('article',{class:'lineage-record'},[
      h('strong',{text:local?.title||sub.title}),
      h('p',{text:'Following edition #'+sub.sequence+' · '+(sub.history||[]).length+' pinned revision(s) · '+(local?'Local mirror available':'Mirror missing')}),
      h('p',{class:sub.publisherKeyId?'trust-verified':'trust-warning',text:sub.publisherKeyId?'Publisher PIN: '+sub.publisherKeyId:'UNSIGNED LEGACY · no publisher authentication'}),
      h('code',{text:sub.channel+' · '+sub.digest.slice(0,24)+'…'}),
      h('p',{text:(sub.history||[]).slice(-4).map(e=>'#'+e.sequence+': '+(e.note||'Untitled')).join(' / ')}),
      h('div',{class:'lineage-actions'},[
        action('View feed',()=>{activeCollection=sub.localRoot;go('home')}),
        action('Unfollow (keep local copies)',()=>{
          if(!confirm('Stop tracking upstream revisions? Your imported Lenses, observations, and collections will remain local.'))return;
          L.unsubscribe(state,sub.channel);save();notify('Subscription detached. Local recipes and observations remain.');
        })
      ])
    ]);subs.append(row);
  }
  renderLineageReview();renderRotationReview();renderKeyBridge();
  $('lineage-send').disabled=!(channel?.readyState==='open'&&state.publications.length);
}
function lineageSourceNoteValue(value){return value===null?'(no reason)':String(value);}
function renderLineageSourceNoteConflicts(plan){
  const slot=$('lineage-source-note-conflicts');slot.replaceChildren();
  if(!plan?.sourceNoteConflicts?.length){slot.hidden=true;return;}
  slot.hidden=false;
  slot.append(
    h('h3',{text:'Source Note decisions'}),
    h('p',{class:'mini',text:'These two copies changed the same direct folder-to-source reason differently. ProgRSS will not choose a winner.'})
  );
  for(const row of plan.sourceNoteConflicts){
    const group=h('fieldset',{class:'lineage-conflict'}),name='lineage-source-note-'+row.id;
    group.append(
      h('legend',{text:row.folderTitle+' → '+row.sourceTitle}),
      h('p',{class:'mini',text:'Previously received: '+lineageSourceNoteValue(row.base)})
    );
    const options=h('div',{class:'lineage-conflict-options'});
    for(const choice of [
      {value:'keep_mine',label:'Keep mine',note:row.mine},
      {value:'use_curator',label:'Use curator’s',note:row.curator}
    ]){
      const input=h('input',{type:'radio',name,value:choice.value,checked:row.choice===choice.value});
      input.addEventListener('change',()=>{pendingLineageChoices[row.id]=choice.value;renderLineageReview();});
      options.append(h('label',{class:'lineage-conflict-choice'},[
        input,h('span',{},[h('strong',{text:choice.label}),h('small',{text:lineageSourceNoteValue(choice.note)})])
      ]));
    }
    group.append(options);slot.append(group);
  }
}
async function renderLineageReview(){
  const myToken=++trustReviewToken,slot=$('lineage-review'),approve=$('lineage-apply'),conflictSlot=$('lineage-source-note-conflicts');approve.disabled=true;trustVerified=null;conflictSlot.replaceChildren();conflictSlot.hidden=true;
  if(!pendingEdition){slot.textContent='No edition selected. Open a Courier package or import an edition. An untrusted signature is never auto-accepted.';return;}
  slot.textContent='Checking edition and curator signature…';
  try{
    const candidate=pendingEdition;let identity=null;
    if(pendingSignedEdition){identity=await T.verify(pendingSignedEdition);if(candidate.digest!==identity.edition.digest)throw Error('Signed envelope no longer matches selected edition');}
    if(myToken!==trustReviewToken)return;
    const auth=T.guard(state,candidate,identity),plan=L.review(state,candidate,pendingLineageChoices),edition=plan.edition;
    const lines=[
      'EDITION: '+edition.channel+' / #'+edition.sequence,
      'PUBLISHER AUTHENTICATION: '+auth.status,
      'SIGNATURE: '+(identity?'VALID · '+identity.algorithm:'NONE · unsigned legacy format'),
      'CURATOR FINGERPRINT: '+(identity?.keyId||'NOT AVAILABLE'),
      'WARNING: A valid signature does not establish the human identity of the key owner. Confirm fingerprint independently.',
      'CONTENT DIGEST: '+edition.digest,
      'PREDECESSOR: '+(edition.previous||'(new channel)'),
      'ROOT: '+edition.bundle.collections.find(c=>c.id===edition.root)?.title,
      'ISSUED: '+edition.issuedAt+' · NOTE: '+(edition.note||'(none)'),
      'STATUS: '+(plan.first?'NEW FOLLOW / PINNED MIRROR':'PROPOSED UPSTREAM FAST-FORWARD'),
      '', 'SOURCE URLS (not fetched or enabled automatically):',
      ...edition.bundle.sources.map(s=>'  ◉ '+s.title+' → '+s.url),
      '', 'GRAPH CHANGES:',
      ...(plan.notes.length?plan.notes.map(n=>'  '+n.kind.toUpperCase()+' '+n.type+' '+n.title+(n.fields.length?' · '+n.fields.join(', '):'')):['  No graph additions or field differences']),
      ...(plan.retired.length?['','RETIRED UPSTREAM (kept locally):',...plan.retired.map(x=>'  '+x.type+' '+x.title)]:[]),
      ...(plan.conflicts.length?['','LOCAL STRUCTURE/FIELD OVERRIDES (preserved):',...plan.conflicts.map(x=>'  '+x.type+' '+x.title+' · '+x.field)]:[]),
      ...(plan.sourceNoteConflicts.length?['','SOURCE NOTE DECISIONS: '+plan.sourceNoteConflicts.length+' divergent placement'+(plan.sourceNoteConflicts.length===1?'':'s')+' · '+plan.unresolvedSourceNoteConflicts.length+' still require'+(plan.unresolvedSourceNoteConflicts.length===1?'s':'')+' a choice.']:[]),
      '', 'WILL PAUSE '+(plan.notes.filter(x=>x.kind==='added'&&x.type==='source').length+plan.resets.length)+' NEW/RETARGETED SOURCE(S).',
      'History: '+(plan.record.history||[]).length+' editions; stable local IDs. No automatic upstream polling.'
    ];
    slot.textContent=lines.join('\n');renderLineageSourceNoteConflicts(plan);trustVerified=identity;approve.disabled=plan.unresolvedSourceNoteConflicts.length>0;
  }catch(error){if(myToken!==trustReviewToken)return;slot.textContent='REVIEW BLOCKED\n'+error.message+'\n\nReject invalid signatures, unsigned downgrades and unexpected replacement keys. For a new key, manually unfollow and establish a new trusted relationship.';}
}

async function publishEdition(forceUnsigned=false){
  const root=$('lineage-root').value;
  const previous=state.publications.map(x=>({...x,history:(x.history||[]).map(v=>({...v}))}));
  try{
    const prior=state.publications.find(x=>x.root===root),identity=forceUnsigned?null:await T.getIdentity();
    if(!forceUnsigned&&!identity)throw Error('Create your signing key first. Or explicitly choose legacy unsigned publication.');
    if(prior?.signerKeyId&&(!identity||prior.signerKeyId!==identity.keyId))throw Error('This collection channel is bound to a different signing key; refusing silent downgrade or key replacement');
    if(forceUnsigned&&!confirm('Publish an UNSIGNED legacy edition? Anybody can impersonate this curator. Use only for compatibility and offline experiments.'))return;
    const edition=L.publish(state,root,$('lineage-note').value||(prior?.rotationNeedsEdition?'Signer rotated; first edition under replacement key':''),{forKeyRotation:prior?.rotationNeedsEdition===true});
    const payload=identity?await T.signEdition(edition,identity):edition;
    if(identity){const published=state.publications.find(x=>x.root===root);published.signerKeyId=identity.keyId;delete published.rotationNeedsEdition;}
    const capsule=Q.makeCapsule(payload,{note:(identity?'Signed':'Unsigned legacy')+' collection edition #'+edition.sequence});
    download('ProgRSS-'+(identity?'signed-':'unsigned-')+'edition-'+edition.channel+'-v'+edition.sequence+'.json',JSON.stringify(capsule,null,2),'application/json');
    save();renderLineage();notify('Edition #'+edition.sequence+' published · '+(identity?'SIGNED '+identity.keyId:'UNSIGNED LEGACY')+'. Keep the capsule for subscribers.');
  }catch(e){state.publications=previous;notify('Publish blocked: '+e.message,true)}
}

async function sendLastEdition(){
  try{
    const record=state.publications.find(r=>r.root===$('lineage-root').value)||state.publications.at(-1);
    if(!record)throw Error('Publish a collection first');
    if(record.rotationNeedsEdition)throw Error('Key rotated: publish the next edition with the replacement key before sending a signed publication');
    const edition=lineageIssueCurrent(record);let payload=edition;
    if(record.signerKeyId){const identity=await T.getIdentity();if(!identity||identity.keyId!==record.signerKeyId)throw Error('Original signing identity missing or changed; cannot resend as unsigned');payload=await T.signEdition(edition,identity);}
    await sendPayload('progrss.capsule.chunk.v1',Q.makeCapsule(payload,{note:(record.signerKeyId?'Signed ':'Unsigned legacy ')+'curator edition #'+edition.sequence}));
    peerStatus('Sent edition #'+edition.sequence+' to Courier review; no HTML or private observations included.');
  }catch(e){notify('Edition transfer blocked: '+e.message,true)}
}
async function applyEdition(){
  if(!pendingEdition)return notify('Open a pending curator edition from Courier first.',true);
  $('lineage-apply').disabled=true;
  try{
    const e=state.inbox.find(x=>x.id===pendingEditionCourierId);
    if(!e||e.status!=='pending')throw Error('Review parcel is no longer pending');
    const capsule=Q.validateCapsule(e.capsule);
    if(!['edition','signed-edition'].includes(capsule.kind))throw Error('Courier item is not an edition');
    const selected=capsule.kind==='signed-edition'?capsule.payload.edition:capsule.payload;
    if(selected.digest!==pendingEdition.digest)throw Error('Edition switched during review');
    const identity=capsule.kind==='signed-edition'?await T.verify(capsule.payload):null;
    T.guard(state,selected,identity);
    const preview=L.review(state,selected,pendingLineageChoices);
    if(preview.unresolvedSourceNoteConflicts.length)throw Error('Choose Keep mine or Use curator’s for every divergent Source Note before approval');
    if(!confirm('Approve edition #'+preview.edition.sequence+' for '+preview.record.title+'? '+(identity?'Pin/check signer '+identity.keyId+'.':'WARNING: UNSIGNED LEGACY.')+' Adds '+preview.notes.filter(x=>x.kind==='added').length+' graph nodes, keeps '+preview.conflicts.length+' local structure/field overrides, applies '+preview.sourceNoteDecisions.length+' explicit Source Note decision(s), and pauses new or retargeted feeds.')){renderLineageReview();return;}
    // Repeat integrity/identity check at commit, not just preview, and re-plan against live state.
    const confirmed=capsule.kind==='signed-edition'?await T.verify(capsule.payload):null;
    T.guard(state,selected,confirmed);
    const report=L.apply(state,selected,pendingLineageChoices);
    if(confirmed)T.pin(state,selected.channel,confirmed);
    Q.resolve(state,e.id,'accepted','Pinned #'+report.sequence+(confirmed?' · signer '+confirmed.keyId:' · UNSIGNED LEGACY'));
    pendingEdition=null;pendingSignedEdition=null;pendingEditionCourierId=null;pendingLineageChoices=Object.create(null);trustVerified=null;save();go('lineage');
    notify('Pinned edition #'+report.sequence+' · '+report.added+' added · '+report.conflicts+' local structure/field overrides · '+report.sourceNoteDecisions+' Source Note decision(s) · '+(confirmed?'SIGNATURE VERIFIED':'UNSIGNED LEGACY'));
  }catch(error){notify('Edition adoption refused: '+error.message,true);renderLineageReview();}
}

function lineageDemo(){
  try{
    const channel='demo-curator-channel',root='demo-small-web',sub=state.subscriptions.find(x=>x.channel===channel);
    const notes=C.cleanRecipe({id:'demo-notes',type:'rss',url:'https://example.org/notes.atom',title:'DEMO · Curator notes',author:'Demo curator'});
    const projects=C.cleanRecipe({id:'demo-projects-feed',type:'page',url:'https://example.org/projects',title:'DEMO · New handbuilt projects',selector:'article.project',mode:'cards',author:'Demo curator'});
    let edition;
    if(!sub){
      const bundle=C.validateBundle({schema:C.SCHEMA,exportedAt:'2026-10-09T00:00:00.000Z',sources:[notes],collections:[C.cleanCollection({id:root,title:'DEMO · Handbuilt corners',author:'Demo curator',members:[{kind:'source',id:notes.id}]})]});
      edition=L.editionFromGraph(channel,1,'',root,bundle,'An initial tiny collection','2026-10-09T00:00:00.000Z');
    }else if(sub.sequence===1){
      const bundle=C.validateBundle({schema:C.SCHEMA,exportedAt:'2026-10-09T01:00:00.000Z',sources:[notes,projects],collections:[C.cleanCollection({id:root,title:'DEMO · Handbuilt corners',author:'Demo curator',members:[{kind:'source',id:notes.id},{kind:'source',id:projects.id}]})]});
      edition=L.editionFromGraph(channel,2,sub.digest,root,bundle,'Added a project-monitoring Lens','2026-10-09T01:00:00.000Z');
    }else throw Error('You have already accepted the demo editions. Try real collaboration!');
    const result=Q.receive(state,Q.makeCapsule(edition,{note:'Safe fictional UNSIGNED offline demonstration'}),'local');
    save();reviewCourier(result.entry.id);
    notify('Offline demo edition #'+edition.sequence+' opened for review. No network fetches.');
  }catch(e){notify('Lineage demo: '+e.message,true)}
}

// Site Scout has no lasting raw-HTML state and performs no automatic fetching.
let scoutReport=null,scoutMarkupMemory='',scoutLinkHeader='',activeProof=null,proofReplay=null,pendingDiscoveryCourierId=null;
function renderScout(report){
  const slot=$('scout-results');scoutReport=report;
  if(!report){slot.replaceChildren(h('div',{class:'empty'},[h('h3',{text:'No discovery yet'}),h('p',{text:'Paste, load, or fetch a webpage when ready.'})]));return;}
  const candidates=[...report.candidates,...report.recommendations];
  $('scout-status').textContent=report.kind==='direct-feed'?'Valid feed detected · '+report.count+' entries':'Site: '+report.title+' · '+report.candidates.length+' declared feed(s) · '+report.recommendations.length+' suggested page watch(es)';
  const cards=candidates.map((candidate,i)=>h('article',{class:'scout-result'},[
    h('span',{class:'mini',text:(i+1)+' · '+candidate.format+' · '+candidate.confidence}),
    h('h4',{text:candidate.title}),
    h('p',{class:'mono',text:candidate.url||report.siteUrl}),
    ...(candidate.selector?[h('p',{text:'Suggested CSS: '+candidate.selector+(candidate.count?' · '+candidate.count+' matches':'' )})]:[]),
    h('div',{class:'row-actions'},[action(candidate.kind==='page'?'Create paused page Lens':'Create paused feed Lens',()=>addScoutLens(candidate,report),'ghost'),
      action('♧ Make replayable proof',()=>selectScoutProof(report,candidate),'primary')])
  ]));
  if(!cards.length)cards.push(h('div',{class:'empty'},[h('h3',{text:'No advertised feed found'}),h('p',{text:'Try creating a page Lens to monitor a selected region.'})]));
  slot.replaceChildren(...cards);
}
function addScoutLens(item,report){
  try{
    if(state.sources.length>=C.LIMIT.source)throw Error('Source limit reached');
    const mode=item.mode||'region',url=C.safeUrl(item.url||report.siteUrl),type=item.kind==='page'?'page':'rss';
    const selector=item.selector||'';
    const duplicate=state.sources.find(s=>s.url===url&&s.type===type&&s.mode===mode&&s.selector===selector);
    if(duplicate){go('sources');return notify('An equivalent Lens already exists: '+duplicate.title);}
    const clean=C.cleanRecipe({id:C.uid('lens'),type,url,title:item.title,mode,selector,
      titleSelector:item.titleSelector||'',linkSelector:item.linkSelector||'',threshold:24,author:'local'});
    state.sources.push({...clean,enabled:false,origin:'site-scout',lastScan:'',lastError:'',lastOutcome:'waiting'});
    save();go('sources');notify('Added PAUSED Lens: '+clean.title+'. Edit and enable it when ready.');
  }catch(err){notify('Scout: '+err.message,true)}
}
function analyzeScout(body,linkHeader=''){
  try{
    const siteUrl=C.safeUrl($('scout-url').value);if(!body||!body.trim())throw Error('Paste content or fetch a webpage first');
    const report=S.scanMarkup(body,siteUrl,{linkHeader:linkHeader||$('scout-header').value});scoutMarkupMemory=body;scoutLinkHeader=linkHeader||$('scout-header').value;proofReplay=null;renderScout(report);renderProofWorkbench();
    return report;
  }catch(err){$('scout-status').textContent='SCOUT ERROR: '+err.message;notify('Scout: '+err.message,true);return null}
}
async function fetchScout(){
  const button=$('scout-fetch');if(button.disabled)return;
  const target=$('scout-url').value;
  if(!await requestOriginAccess(target))return;
  button.disabled=true;$('scout-status').textContent='Fetching the user-selected URL…';
  try{const result=await requestRemote(target);
    if(result.notModified)throw Error('Unexpected conditional response to an unconditional discovery request');
    $('scout-html').value=result.body;$('scout-header').value=result.linkHeader||'';analyzeScout(result.body,result.linkHeader||'');
  }catch(err){$('scout-status').textContent='SCOUT FETCH ERROR: '+err.message;notify('Scout: '+err.message,true)}
  finally{button.disabled=false}
}
function demoScout(){
  $('scout-url').value='https://demo.example/notes/index.html';$('scout-header').value='';
  $('scout-html').value='<!doctype html><html><head><title>The Small Web</title><link rel="alternate" type="application/rss+xml" title="Tiny notes RSS" href="/feed.xml"><link rel="alternate" type="application/feed+json" title="Tiny projects JSON Feed" href="/projects.json"><link rel="stylesheet" href="/style.css"></head><body><main><article><h2>Wooden laptop</h2></article><article><h2>Radio garden</h2></article><article><h2>Shared gardens</h2></article></main></body></html>';
  analyzeScout($('scout-html').value);
}

// Discovery evidence stays memory-only until a user explicitly chooses to share
// it, or accepts an incoming capsule after locally replaying the claim.
function renderProofWorkbench(){
  const slot=$('proof-preview'),status=$('proof-status'),has=Boolean(activeProof);
  for(const id of ['proof-replay','proof-export','proof-capsule','proof-send'])$(id).disabled=!has;
  $('proof-adopt').disabled=!(has&&proofReplay?.pass);
  if(!has){slot.textContent='Choose a Scout finding or review a discovery capsule from Courier.';status.textContent='No discovery selected.';return;}
  const p=D.validateProof(activeProof);
  slot.textContent=JSON.stringify({kind:p.candidate.kind,siteUrl:p.siteUrl,candidate:p.candidate,witness:p.witness,observedAt:p.observedAt,digest:p.digest},null,2);
  status.textContent=proofReplay ? (proofReplay.pass?'✓ ':'✕ ')+proofReplay.status+' · '+proofReplay.detail :
    'UNVERIFIED · '+(pendingDiscoveryCourierId?'Received package · ':'Locally generated · ')+'no replay run yet';
}
function selectScoutProof(report,candidate){try{
  activeProof=D.makeProof(report,candidate);pendingDiscoveryCourierId=null;proofReplay=null;renderProofWorkbench();
  notify('Evidence claim prepared in memory. Replay the snapshot before adopting or sharing.');
}catch(error){notify('Discovery evidence: '+error.message,true)}}
function replayDiscovery(){try{
  if(!activeProof)throw Error('Choose a discovery');
  let raw=$('scout-html').value||scoutMarkupMemory;
  proofReplay=D.evaluateProof(activeProof,raw,{linkHeader:$('scout-header').value||scoutLinkHeader});
  renderProofWorkbench();notify('Replay: '+proofReplay.status+' — '+proofReplay.detail,!proofReplay.pass);
}catch(error){proofReplay=null;renderProofWorkbench();notify('Replay failed: '+error.message,true)}}
function adoptDiscovery(){try{
  if(!activeProof||!proofReplay?.pass)throw Error('Local replay is required before adoption');
  if(proofReplay.status==='drift'&&!confirm('Selector still works, but the observed match count changed. Create a PAUSED Lens anyway?'))return;
  const p=D.validateProof(activeProof),source=D.toPausedLens(p);
  if(state.sources.length>=C.LIMIT.source)throw Error('Source limit reached');
  const duplicate=state.sources.find(x=>x.type===source.type&&x.url===source.url&&x.mode===source.mode&&x.selector===source.selector);
  if(duplicate)throw Error('An equivalent Lens already exists: '+duplicate.title);
  if(pendingDiscoveryCourierId){const e=state.inbox.find(x=>x.id===pendingDiscoveryCourierId);
    if(!e||e.status!=='pending'||Q.validateCapsule(e.capsule).digest!==e.id)throw Error('Courier evidence is no longer pending');
    Q.resolve(state,e.id,'accepted','Locally replayed; created paused Lens '+source.id);
  }
  state.sources.push(source);pendingDiscoveryCourierId=null;proofReplay=null;save();go('sources');renderProofWorkbench();
  notify('Created PAUSED Lens after independent replay. Review it before enabling checks.');
}catch(error){notify('Discovery adoption refused: '+error.message,true)}}
function proofDownload(wrap){try{
  if(!activeProof)throw Error('No proof selected');const p=D.validateProof(activeProof),data=wrap?Q.makeCapsule(p,{note:'Unsigned discovery evidence; replay before adoption'}):p;
  download('ProgRSS-'+(wrap?'capsule-':'')+'discovery-'+p.digest.slice(7,21)+'.json',JSON.stringify(data,null,2),'application/json');
  notify('Evidence exported without raw HTML; still review URLs/selectors before sharing.');
}catch(error){notify('Proof export failed: '+error.message,true)}}
async function proofSend(){try{
  if(!activeProof)throw Error('No discovery selected');
  if(!channel||channel.readyState!=='open')throw Error('Connect a trusted peer in Exchange studio first');
  await sendPayload('progrss.capsule.chunk.v1',Q.makeCapsule(D.validateProof(activeProof),{note:'Peer discovery · verify independently'}));
  notify('Unsigned discovery capsule transmitted for independent review.');
}catch(error){notify('Peer evidence send: '+error.message,true)}}
async function importProofFile(file){if(!file)return;try{
  if(file.size>D.MAX_BYTES+3000)throw Error('Evidence file too large');
  const raw=JSON.parse(await file.text());if(![D.SCHEMA,Q.SCHEMA].includes(raw?.schema))throw Error('Expected discovery evidence or Courier capsule');
  if(raw.schema===Q.SCHEMA && Q.validateCapsule(raw).kind!=='discovery')throw Error('Courier capsule is not discovery evidence');
  receiveCourier(raw,'file');
}catch(error){notify('Import evidence: '+error.message,true)}}

// Recovery Circle is intentionally separate from Key Bridge and normal editor flows.
// Rev0014: Recovery Circle · no old private key or observation data on the wire.
let recoveryArtifact=null,recoveryCourierId=null,recoveryToken=0;
async function recoveryLoad(raw,parcelId=null){
  const payload=raw?.schema===Q.SCHEMA?Q.validateCapsule(raw).payload:raw;
  if(![H.CHARTER,H.PACKET].includes(payload?.schema))throw Error('Select a recovery charter or recovery packet');
  if(payload.schema===H.CHARTER){await H.verifyCharter(payload);recoveryArtifact=payload;}
  else{
    await H.verifyPacket(payload);
    if(recoveryArtifact?.schema===H.PACKET){
      const old=await H.verifyPacket(recoveryArtifact),next=await H.verifyPacket(payload);
      if(old.requestDigest===next.requestDigest&&old.charterDigest===next.charterDigest)recoveryArtifact=await H.combine(recoveryArtifact,payload);
      else if(confirm('This is a different recovery request. Replace the current workbench packet?'))recoveryArtifact=payload;
      else return;
    }else recoveryArtifact=payload;
  }
  recoveryCourierId=parcelId;go('recovery');await renderRecovery();
}
function recoveryExport(){
  if(!recoveryArtifact)throw Error('No selected recovery artifact');
  const capsule=Q.makeCapsule(recoveryArtifact,{note:'Recovery Circle · verify old pinned charter and quorum'});
  download('ProgRSS-recovery-'+capsule.kind+'-'+capsule.digest.slice(7,19)+'.json',JSON.stringify(capsule,null,2),'application/json');
  return capsule;
}
async function renderRecovery(){
  const slot=$('recovery-status'),token=++recoveryToken;
  const policies=state.recoveryPolicies||[],receipts=state.recoveryReceipts||[];
  $('recovery-pins').textContent=policies.length?'ADVANCE-PINNED CHARTERS ('+policies.length+'):\n'+policies.map(p=>p.subjectKeyId.slice(0,31)+'… · '+p.digest+'\n  '+p.charter.threshold+'/'+p.charter.guardians.length+' guardians · '+(p.status==='revoked'?'REVOKED':'active')+' · expires '+p.charter.expiresAt).join('\n'):'No pinned Recovery Circle policies. Your trust pins will not change from a recovered request without advance registration.';
  if(receipts.length)$('recovery-pins').textContent+='\n\nRECOVERY RECEIPTS:\n'+receipts.slice(0,8).map(x=>x.at+' · '+x.from.slice(0,22)+'… → '+x.to.slice(0,22)+'… · '+x.quorum).join('\n');
  $('recovery-pin').disabled=true;$('recovery-apply').disabled=true;
  $('recovery-export').disabled=!recoveryArtifact;$('recovery-peer').disabled=!recoveryArtifact||channel?.readyState!=='open';
  if(!recoveryArtifact){slot.textContent='No selected artifact. Issue or import an owner-signed charter, or import a signed recovery packet.';return;}
  try{
    if(recoveryArtifact.schema===H.CHARTER){const checked=await H.verifyCharter(recoveryArtifact);if(token!==recoveryToken)return;
      const own=state.recoveryPolicies?.find(x=>x.subjectKeyId===recoveryArtifact.subject.keyId),scope=recoveryArtifact.scope;
      const matching=(scope!=='patch'?(state.subscriptions||[]).filter(x=>x.publisherKeyId===recoveryArtifact.subject.keyId):[]).length+(scope!=='curator'?(state.patchPins||[]).filter(x=>x.keyId===recoveryArtifact.subject.keyId):[]).length;
      slot.textContent='OWNER-SIGNED CHARTER · VERIFIED\n'+checked.digest+'\nOld key: '+recoveryArtifact.subject.keyId+'\nThreshold: '+recoveryArtifact.threshold+'/'+recoveryArtifact.guardians.length+' · scope '+scope+'\nExpires: '+recoveryArtifact.expiresAt+'\nExisting matching trusted pins: '+matching+'\n\nGuardians:\n'+recoveryArtifact.guardians.map(x=>' · '+x.keyId).join('\n')+'\n\nThe subscriber must APPROVE pinning before the old key is lost; a charter received after loss is not independently sufficient.';
      $('recovery-pin').disabled=!matching||!!own||Date.now()>Date.parse(recoveryArtifact.expiresAt);
    }else{
      const checked=await H.verifyPacket(recoveryArtifact);if(token!==recoveryToken)return;
      const policy=(state.recoveryPolicies||[]).find(x=>x.subjectKeyId===checked.subject);
      const summary=['RECOVERY REQUEST · signatures verified','Old key: '+checked.subject,'New key: '+checked.successor,'Charter: '+checked.charterDigest,'Request: '+checked.requestDigest,'Guardian votes: '+checked.votes+'/'+checked.threshold,'Quorum: '+(checked.quorum?'REACHED':'NOT YET'),'Charter active: '+(checked.active?'YES':'NO'),'Pre-registered charter: '+(policy?.digest===checked.charterDigest?'EXACT MATCH':'NOT PINNED')];
      try{const p=await H.preview(state,recoveryArtifact);summary.push('Affected: '+p.curatorCount+' curator channel(s), '+p.patchCount+' contributor pin(s)',...p.curatorChannels.map(x=>' · '+x),...p.patchUrls.map(x=>' · '+x));$('recovery-apply').disabled=false;}
      catch(error){summary.push('Approval blocked: '+error.message)}
      slot.textContent=summary.join('\n')+'\n\nNo automatic trust transfer. Compare the replacement key and signed guardian votes with independent contacts.';
    }
  }catch(error){if(token!==recoveryToken)return;slot.textContent='RECOVERY ARTIFACT REFUSED\n'+error.message;}
}
async function recoveryCreateCharter(){try{
  const active=await T.getIdentity();if(!active)throw Error('Create a signing identity under Trust Keys first');
  let guardians=JSON.parse($('recovery-guardians').value);if(!Array.isArray(guardians))throw Error('Paste a JSON array of Guardian Cards');
  const charter=await H.makeCharter(active,guardians,Number($('recovery-threshold').value),$('recovery-scope').value,Number($('recovery-days').value));
  recoveryArtifact=charter;recoveryCourierId=null;recoveryExport();await renderRecovery();notify('Owner-signed charter exported. Have subscribers pin it NOW, while the old key is trusted.');
}catch(error){notify('Cannot issue recovery charter: '+error.message,true)}}
async function recoveryCreateRequest(){try{
  const charter=recoveryArtifact?.schema===H.CHARTER?recoveryArtifact:recoveryArtifact?.charter;if(!charter)throw Error('Import the pre-loss charter first');
  const active=await T.getIdentity(),pending=await T.getPendingIdentity();
  const who=pending&&pending.keyId!==charter.subject.keyId?pending:active;
  if(!who)throw Error('Generate a NEW signing identity, in a new profile if the old one is lost');
  if(!confirm('Sign a recovery REQUEST with '+who.keyId+'? The old private key will NOT be recovered. Guardian signatures and recipient approval are still required.'))return;
  recoveryArtifact=await H.newPacket(charter,who,$('recovery-reason').value);recoveryCourierId=null;recoveryExport();await renderRecovery();notify('New replacement-key request exported; ask authorized guardians to vote after independent verification.');
}catch(error){notify('Recovery request refused: '+error.message,true)}}
async function recoveryVote(){try{
  if(recoveryArtifact?.schema!==H.PACKET)throw Error('Import a recovery packet first');
  const identity=await T.getIdentity();if(!identity)throw Error('No signing identity in this browser origin');
  if(!confirm('Guardian vote: do you independently recognize this recovery request and successor fingerprint?\n\n'+recoveryArtifact.request.successor.keyId+'\n\nOnly sign when you have verified the person out of band.'))return;
  recoveryArtifact=await H.addVote(recoveryArtifact,identity);recoveryCourierId=null;recoveryExport();await renderRecovery();notify('Signed guardian vote exported. Send packet back to the requester.');
}catch(error){notify('Guardian vote refused: '+error.message,true)}}
async function recoveryPin(){try{
  if(recoveryArtifact?.schema!==H.CHARTER)throw Error('Select a signed recovery charter');
  const x=recoveryArtifact;
  if(!confirm('PIN THIS RECOVERY POLICY IN ADVANCE?\n\nOwner: '+x.subject.keyId+'\n'+x.threshold+'/'+x.guardians.length+' guardian votes · '+x.scope+'\nExpires: '+x.expiresAt+'\n\nVerify guardian fingerprints independently. If enough guardians collude, they can authorize a successor without the old key.'))return;
  const report=await H.register(state,x);
  if(recoveryCourierId){const e=state.inbox.find(e=>e.id===recoveryCourierId&&e.status==='pending');if(e)Q.resolve(state,e.id,'accepted','Pre-registered signed charter '+report.record.digest)}
  recoveryCourierId=null;save();await renderRecovery();notify('Recovery charter pinned BEFORE loss. Replacement will still require explicit approval.');
}catch(error){notify('Recovery charter not pinned: '+error.message,true)}}
async function recoveryApply(){try{
  if(recoveryArtifact?.schema!==H.PACKET)throw Error('Select a complete recovery packet');
  const planned=await H.preview(state,recoveryArtifact);
  if(!confirm('TRANSFER TRUST AFTER LOST KEY?\n\n'+planned.subject+'\n → '+planned.successor+'\n\n'+planned.votes+'/'+planned.threshold+' independent guardian signatures.\n'+planned.curatorCount+' curator and '+planned.patchCount+' repair contributor pins.\n\nConfirm the person and replacement key OUTSIDE ProgRSS. This revokes the old pins and cannot be undone automatically.'))return;
  const report=await H.apply(state,recoveryArtifact);
  if(recoveryCourierId){const e=state.inbox.find(e=>e.id===recoveryCourierId&&e.status==='pending');if(e)Q.resolve(state,e.id,'accepted','Verified quorum '+report.votes+'/'+report.threshold+' and manually changed trusted pins');}
  recoveryCourierId=null;save();await renderRecovery();notify('Recovery approved. Old key pins replaced; ordinary feed/patch revisions still require separate review.');
}catch(error){notify('Recovery approval blocked: '+error.message,true)}}
async function recoveryImport(file){if(!file)return;try{
  if(file.size>25000)throw Error('Recovery artifact too large');const raw=JSON.parse(await file.text());await recoveryLoad(raw);
  notify('Recovery artifact verified and loaded; no trust pins changed.');
}catch(error){notify('Recovery import refused: '+error.message,true)}}
async function recoverySend(){try{if(!recoveryArtifact)throw Error('No selected recovery artifact');await sendPayload('progrss.capsule.chunk.v1',Q.makeCapsule(recoveryArtifact,{note:'Recovery Circle · no automatic trust'}));notify('Signed recovery artifact transmitted for independent review.');}
catch(error){notify('Recovery WebRTC send blocked: '+error.message,true)}}


// rev0015 · Signed charter changes and local fork witness history.
let ledgerArtifact=null,ledgerCourierId=null,ledgerToken=0;
async function ledgerLoad(raw,parcelId=null){
  const payload=raw?.schema===Q.SCHEMA?Q.validateCapsule(raw).payload:raw;
  if(payload?.schema!==J.SCHEMA)throw Error('Expected a signed charter-change document');
  await J.verify(payload);
  const observed=await J.observe(state,payload); // Verified signatures only, no approval.
  ledgerArtifact=payload;ledgerCourierId=parcelId;persist();go('recovery');await renderLedger();
  if(observed.conflicts.length)notify('SIGNED FORK ALERT: two owner-signed claims conflict. Adoption is blocked.',true);
}
async function renderLedger(){
  const token=++ledgerToken,view=$('ledger-status'),log=$('ledger-history');
  $('ledger-approve').disabled=true;$('ledger-export').disabled=!ledgerArtifact;$('ledger-send').disabled=!ledgerArtifact||channel?.readyState!=='open';
  const changes=state.charterHistory||[],claims=state.charterClaims||[];
  const forks=[];for(let i=0;i<claims.length;i++)for(let j=i+1;j<claims.length;j++)if(claims[i].subjectKeyId===claims[j].subjectKeyId&&claims[i].priorDigest===claims[j].priorDigest&&claims[i].sequence===claims[j].sequence&&claims[i].digest!==claims[j].digest)forks.push([claims[i],claims[j]]);
  log.textContent='ACCEPTED LOCAL HISTORY · '+changes.length+' entries\n'+changes.slice(-22).map(e=>'#'+e.sequence+' · '+e.action.toUpperCase()+' · '+e.subjectKeyId.slice(0,24)+'…\n  '+e.digest+'\n  parent '+(e.priorDigest||'(genesis)')).join('\n')+'\n\nOBSERVED SIGNED CLAIMS · '+claims.length+' · competing pairs '+forks.length+(forks.length?'\n⚠ Conflicting owner signatures observed. Keep both claims as evidence; verify out of band.':'');
  if(!ledgerArtifact){view.textContent='No selected claim. Create an owner-signed change or import an existing claim.\nUnsigned/unpinned data can never replace a trust pin.';return;}
  try{const check=await J.verify(ledgerArtifact);if(token!==ledgerToken)return;
    const lines=['OWNER SIGNATURE VERIFIED (NOT HUMAN IDENTITY)','Owner: '+ledgerArtifact.subject.keyId,'Action: '+ledgerArtifact.action+' · sequence #'+ledgerArtifact.sequence,'Claim digest: '+check.digest,'Predecessor: '+ledgerArtifact.priorDigest,'Next charter: '+(ledgerArtifact.nextCharter?H.digest(ledgerArtifact.nextCharter):'REVOKED'),'Claim recorded locally; trust unchanged.'];
    try{const p=await J.preview(state,ledgerArtifact);lines.push('LOCAL PIN: exact owner + predecessor + sequence verified','Previous scope: '+p.scopeBefore+' · proposed: '+p.scopeAfter,'Guardian count: '+p.guardianCountBefore+' → '+p.guardianCountAfter);if(p.conflicts.length)lines.push('BLOCKED: '+p.conflicts.length+' conflicting signed claims');else $('ledger-approve').disabled=false;}
    catch(err){lines.push('Cannot adopt here: '+err.message)}
    view.textContent=lines.join('\n');
  }catch(err){if(token===ledgerToken)view.textContent='REJECTED: '+err.message}
}
async function ledgerCreate(){try{
  const me=await T.getIdentity();if(!me)throw Error('Generate an active signing identity first');
  const policy=(state.recoveryPolicies||[]).find(p=>p.subjectKeyId===me.keyId);
  let parent,sequence;
  if(policy){parent=policy.ledgerDigest||policy.digest;sequence=(policy.ledgerSequence||0)+1;}
  else if(ledgerArtifact?.schema===J.SCHEMA&&ledgerArtifact.subject.keyId===me.keyId){parent=J.digest(ledgerArtifact);sequence=ledgerArtifact.sequence+1;}
  else if(recoveryArtifact?.schema===H.CHARTER&&recoveryArtifact.subject.keyId===me.keyId){await H.verifyCharter(recoveryArtifact);parent=H.digest(recoveryArtifact);sequence=1;}
  else throw Error('Load your existing signed charter, or use a pinned local policy as predecessor');
  const action=$('ledger-action').value;
  let next=null;
  if(action==='replace'){
    const guardians=JSON.parse($('recovery-guardians').value);if(!Array.isArray(guardians))throw Error('Paste new guardian cards in the charter editor above');
    next=await H.makeCharter(me,guardians,Number($('recovery-threshold').value),$('recovery-scope').value,Number($('recovery-days').value));
  }
  ledgerArtifact=await J.make(me,{priorDigest:parent,sequence,action,nextCharter:next,note:$('ledger-note').value});ledgerCourierId=null;
  await J.observe(state,ledgerArtifact);persist();ledgerExport();await renderLedger();notify('Signed claim exported. Each recipient must verify and approve their own pinned chain.');
}catch(err){notify('Charter change refused: '+err.message,true)}}
function ledgerExport(){if(!ledgerArtifact)throw Error('No claim selected');const capsule=Q.makeCapsule(ledgerArtifact,{note:'Signed charter change; recipient approval required'});download('ProgRSS-charter-change-'+capsule.digest.slice(7,19)+'.json',JSON.stringify(capsule,null,2),'application/json');return capsule;}
async function ledgerApprove(){try{
  if(!ledgerArtifact)throw Error('Import and verify a change first');const check=await J.preview(state,ledgerArtifact);
  if(check.conflicts.length)throw Error('Competing signed claims: cannot approve automatically');
  if(!confirm('APPLY SIGNED CHARTER '+ledgerArtifact.action.toUpperCase()+'?\n\nOld owner: '+ledgerArtifact.subject.keyId+'\nSequence '+ledgerArtifact.sequence+'\nPrevious '+ledgerArtifact.priorDigest+'\n\nThis changes YOUR pinned recovery rules only. Verify issuer and guardian roster out of band. Incoming packets from a revoked charter must fail.'))return;
  await J.approve(state,ledgerArtifact);
  if(ledgerCourierId){const entry=state.inbox.find(e=>e.id===ledgerCourierId&&e.status==='pending');if(entry)Q.resolve(state,entry.id,'accepted','Manually approved signed charter '+ledgerArtifact.action+' #'+ledgerArtifact.sequence);}
  ledgerCourierId=null;save();await renderLedger();notify('Charter change accepted locally. Signed evidence preserved in your private audit trail.');
}catch(err){notify('Charter adoption blocked: '+err.message,true)}}
async function ledgerImport(file){if(!file)return;try{if(file.size>35000)throw Error('Change claim file too large');await ledgerLoad(JSON.parse(await file.text()));notify('Verified signed claim imported for local review. No trust changed.');}catch(err){notify('Import refused: '+err.message,true)}}
async function ledgerPeer(){try{if(!ledgerArtifact)throw Error('No claim');await sendPayload('progrss.capsule.chunk.v1',Q.makeCapsule(ledgerArtifact,{note:'Trust Ledger; explicit review'}));notify('Signed claim sent for manual review.');}catch(err){notify('WebRTC send blocked: '+err.message,true)}}
async function ledgerAudit(){try{const report=await J.audit(state);$('ledger-status').textContent='LOCAL CRYPTOGRAPHIC AUDIT\n'+JSON.stringify(report,null,2)+'\n\nThis is not a public transparency log, external clock or proof everyone sees the same history.';notify(report.failures.length||report.forks.length?'Audit found anomalies: inspect your history.':'Local signed-history audit complete.',Boolean(report.failures.length||report.forks.length));}catch(err){notify('Audit failed: '+err.message,true)}}

// Witness Gossip event handlers are explicitly user-triggered and do not change trust on import.
// rev0016 · Witness Gossip: all network/receipt changes require explicit user clicks.
let gossipArtifact=null,gossipCourierId=null,gossipToken=0;
async function gossipLoad(raw,id=null){
  const x=raw?.schema===Q.SCHEMA?Q.validateCapsule(raw).payload:raw;
  await W.verify(x);gossipArtifact=x;gossipCourierId=id;go('recovery');await renderGossip();
}
async function renderGossip(){
  const token=++gossipToken,status=$('gossip-status'),history=$('gossip-history');
  W.ensureState(state);
  $('gossip-export').disabled=!gossipArtifact;
  $('gossip-send').disabled=!gossipArtifact||channel?.readyState!=='open';
  $('gossip-witness').disabled=true;$('gossip-record').disabled=true;$('gossip-pin').disabled=true;
  const rows=state.gossipCards.slice(-14).reverse();
  history.textContent='VERIFIED POSTCARDS RECORDED: '+state.gossipCards.length+' / 128 · INDEPENDENTLY PINNED WITNESSES: '+state.witnessPins.length+' / 64\n'+
    (rows.length?rows.map(r=>r.sequence+' · '+r.subjectKeyId.slice(0,25)+'… · tip '+r.tipDigest.slice(7,22)+'… · '+(r.witnessKeyId?'witness '+r.witnessKeyId.slice(0,18)+'…':'publisher')+' · '+r.seenAt.slice(0,16)).join('\n'):'No postcards recorded. Importing a card does NOT automatically record it.');
  if(!gossipArtifact){status.textContent='No postcard selected. You can sign your local charter head or import a verified head from another person.\nA witnessed head does not prove a human identity or the true contents of a complete remote history.';return;}
  try{
    const p=await W.preview(state,gossipArtifact);if(token!==gossipToken)return;
    const notes=['SIGNATURES VERIFIED · '+p.kind.toUpperCase(),'SUBJECT: '+p.head.subject.keyId,'OWNER SEQUENCE: '+p.head.sequence,
      'OWNER TIP: '+p.head.tipDigest,'PARENT: '+(p.head.parentDigest||'(GENESIS)'),
      'SIGNED HEAD HASH: '+p.headDigest,'ARTIFACT HASH: '+p.artifactDigest,
      'SIGNATURE WITNESS: '+(p.witnessKeyId||'(none)'),
      'WITNESS PRE-APPROVED: '+(p.witnessPinned?'YES, separately pinned':'NO / NOT APPLICABLE'),
      'LOCAL POLICY: '+p.localPin,
      'JOURNAL: '+(p.duplicate?'ALREADY RECORDED':'NOT YET RECORDED'),
      'COMPETING OWNER-SIGNED HEADS, SAME SEQUENCE: '+p.forks.length];
    if(p.forks.length)notes.push(...p.forks.map(f=>'⚠ POTENTIAL EQUIVOCATION '+f.sequence+' · '+f.headA+' versus '+f.headB));
    notes.push('','Signature proves the public key signed this statement, not a trustworthy timestamp, human identity or append-only history.');
    status.textContent=notes.join('\n');
    $('gossip-record').disabled=p.duplicate;
    $('gossip-witness').disabled=false;
    $('gossip-pin').disabled=!p.witnessKeyId||p.witnessPinned;
  }catch(err){if(token===gossipToken)status.textContent='UNVERIFIED WITNESS DATA: '+err.message;}
}
async function gossipCreate(){try{
  const me=await T.getIdentity();const loaded=recoveryArtifact?.schema===H.CHARTER?recoveryArtifact:null;const head=await W.mintFromLocal(me,state,loaded);
  gossipArtifact=head;gossipCourierId=null;await renderGossip();notify('Signed local trust head ready. Nothing has been sent.');
}catch(e){notify('Cannot publish trust head: '+e.message,true)}}
async function gossipSign(){try{
  if(!gossipArtifact)throw Error('Import a verified head first');
  const original=await W.verify(gossipArtifact),me=await T.getIdentity();
  if(!me)throw Error('Generate a separate witness Trust Key first');
  if(!confirm('Sign a PUBLIC witness postcard?\n\nSubject: '+original.head.subject.keyId+'\n\nYour witness key '+me.keyId+' will be visible to recipients. Signing only means you SAW this signed head, not that its entire history is accurate.'))return;
  gossipArtifact=await W.witness(me,original.head);gossipCourierId=null;await renderGossip();notify('Witness postcard signed; export or send only if you choose.');
}catch(e){notify('Witness signature refused: '+e.message,true)}}
function gossipExport(){if(!gossipArtifact)throw Error('No selected witness postcard');const capsule=Q.makeCapsule(gossipArtifact,{note:'Witness Gossip: signed head, manual observation only'});
  download('ProgRSS-witness-'+capsule.kind+'-'+capsule.digest.slice(7,19)+'.json',JSON.stringify(capsule,null,2),'application/json');return capsule;}
async function gossipRecord(){try{
  if(!gossipArtifact)throw Error('No selected card');const report=await W.preview(state,gossipArtifact);
  if(!confirm('Record a VERIFIED signed statement in YOUR local witness journal?\n\n'+report.head.subject.keyId+'\nSequence '+report.head.sequence+'\n'+(report.forks.length?'WARNING: conflicting signed head already observed. Keep as evidence, do not adopt trust.':'No same-sequence conflict observed locally.')+'\n\nThis does NOT change any trust pins or feed subscriptions.'))return;
  const result=await W.record(state,gossipArtifact);if(gossipCourierId){const e=state.inbox.find(x=>x.id===gossipCourierId&&x.status==='pending');if(e)Q.resolve(state,e.id,'accepted','Observed verified trust-head; NO trust transfer');}
  gossipCourierId=null;persist();await renderGossip();renderInbox();notify(result.forks.length?'Signed conflicting head captured for investigation.':'Verified head recorded locally.',Boolean(result.forks.length));
}catch(e){notify('Cannot record postcard: '+e.message,true)}}
async function gossipPin(){try{
  if(!gossipArtifact)throw Error('No loaded witness card');const checked=await W.verify(gossipArtifact);
  if(!checked.witnessKeyId)throw Error('A publisher head cannot pin a witness');
  if(!confirm('Independently verify this witness fingerprint OUTSIDE ProgRSS, then pin?\n\n'+checked.witnessKeyId+'\n\nPinning identifies whose sightings you recognize. It DOES NOT make their claims true.'))return;
  await W.pinWitness(state,gossipArtifact);persist();await renderGossip();notify('Witness key pinned locally, independent of curator and recovery pins.');
}catch(e){notify('Witness pin refused: '+e.message,true)}}
async function gossipImport(file){if(!file)return;try{
  if(file.size>12_000)throw Error('Witness JSON is too large');const doc=JSON.parse(await file.text());
  if(doc.schema===Q.SCHEMA){const capsule=Q.validateCapsule(doc);if(!['trust-head','trust-sighting'].includes(capsule.kind))throw Error('Courier capsule is not witness gossip');await gossipLoad(capsule.payload);}
  else await gossipLoad(doc);
  notify('Verified signed gossip imported for review; no trust changed.');
}catch(e){notify('Witness import refused: '+e.message,true)}}
async function gossipSend(){try{
  if(!gossipArtifact)throw Error('No selected postcard');const capsule=Q.makeCapsule(gossipArtifact,{note:'Witness Gossip: explicit delivery; no automatic adoption'});
  if(!confirm('Send this signed '+capsule.kind+' postcard to the connected WebRTC peer?\n\nThe subject key is revealed, and a witness card also reveals your witness key.'))return;
  await sendPayload('progrss.capsule.chunk.v1',capsule);notify('Witness postcard sent for explicit Courier review.');
}catch(e){notify('Witness peer send blocked: '+e.message,true)}}
async function gossipAudit(){try{
  const result=await W.audit(state);$('gossip-status').textContent='INDEPENDENT LOCAL SIGNATURE AUDIT\n'+JSON.stringify(result,null,2)+'\n\nNo global log, consistency proof or automatic trust transfer.';
  notify(result.failures.length||result.forks.length?'Witness audit found anomalies; preserve both signed statements.':'Verified local witness journal.',Boolean(result.failures.length||result.forks.length));
}catch(e){notify('Witness audit refused: '+e.message,true)}}

// rev0017 · Merkle Observatory. Import is inert; pinning requires consent.
let merkleArtifact=null,merkleCourierId=null,merklePrevious=null,merkleToken=0;
async function merkleLoad(raw,id=null){
 const x=raw?.schema===Q.SCHEMA?Q.validateCapsule(raw).payload:raw;
 await M.verify(x);merkleArtifact=x;merkleCourierId=id;
 if(x.schema===M.HEAD)merklePrevious=x;
 go('recovery');await renderMerkle();
}
async function renderMerkle(){
 const token=++merkleToken,status=$('merkle-status'),history=$('merkle-history');M.ensureState(state);
 $('merkle-export').disabled=!merkleArtifact;
 $('merkle-send').disabled=!merkleArtifact||channel?.readyState!=='open';
 $('merkle-pin').disabled=true;
 history.textContent='LOCAL TREE PINS: '+state.merklePins.length+' / 32 · REVIEWED CONSISTENCY RECEIPTS: '+state.merkleReceipts.length+' / 96+'+'\n'+
   (state.merklePins.length?state.merklePins.map(r=>r.subjectKeyId+'\n  '+r.head.treeSize+' leaves · '+r.head.rootDigest+'\n  last approved '+r.pinnedAt).join('\n'):'No trusted checkpoints. Confirm fingerprints out of band before first pinning.');
 if(!merkleArtifact){status.textContent='Create a checkpoint from an approved local charter history or import a signed head/proof.\nFirst head requires fingerprint confirmation; extensions require a proof against your pinned root.';return;}
 try{
  const p=await M.preview(state,merkleArtifact);if(token!==merkleToken)return;
  status.textContent='CRYPTOGRAPHIC VERIFICATION: PASS · '+p.kind.toUpperCase()+'\nSUBJECT KEY: '+p.subject+'\nTREE SIZE: '+p.head.treeSize+
    '\nROOT: '+p.head.rootDigest+'\nLATEST EVENT COMMITMENT: '+p.head.tipDigest+
    '\nLOCAL COMPARISON: '+p.relation+'\n\n'+(p.kind==='merkle-inclusion'?'INCLUSION PROOF VERIFIED · index '+p.sequence+'\nIt does not by itself authorize a new checkpoint.':
      p.kind==='merkle-consistency'?'APPEND-ONLY PROOF VERIFIED · '+p.first+' → '+p.second+' leaves.\nThis is a cryptographic prefix proof; neither owner identity nor full truth is proven.':
      'OWNER SIGNATURE VERIFIED. No append-only extension is established by a naked head.')+
    '\n\nNo new feed, guardian charter or source permission is adopted by this workbench.';
  $('merkle-pin').disabled=!p.adoptable;
 }catch(e){if(token===merkleToken){status.textContent='INVALID MERKLE ARTIFACT: '+e.message;$('merkle-pin').disabled=true;}}
}
async function merkleCreate(){try{
 const me=await T.getIdentity();if(!me)throw Error('Generate a Trust Keys identity first');
 const events=await M.eventsFromState(state,me.keyId,recoveryArtifact?.schema===H.CHARTER?recoveryArtifact:null),head=await M.mint(me,events);
 const base=merklePrevious?.subject?.keyId===me.keyId?merklePrevious:(state.merklePins||[]).find(p=>p.subjectKeyId===me.keyId)?.head;
 let result=head;
 if(base&&base.treeSize<head.treeSize)result=await M.makeExtension(base,head,events);
 else if(base&&base.treeSize===head.treeSize&&base.rootDigest!==head.rootDigest)throw Error('Local tree conflicts with previous signed root. Do not publish this as an extension.');
 else if(base&&base.treeSize>head.treeSize)throw Error('Current accepted history has fewer events than the earlier checkpoint');
 merkleArtifact=result;merkleCourierId=null;await renderMerkle();
 notify(result.schema===M.EXT?'Signed append-only extension prepared. Nothing sent.':'Signed checkpoint prepared. Load this head again before publishing a later edition.');
}catch(e){notify('Merkle publishing blocked: '+e.message,true)}}
async function merkleInclusion(){try{
 const me=await T.getIdentity();if(!me)throw Error('A signing identity is required');
 const events=await M.eventsFromState(state,me.keyId,recoveryArtifact?.schema===H.CHARTER?recoveryArtifact:null),head=await M.mint(me,events),sequence=Number($('merkle-index').value);
 const proof=await M.makeInclusion(head,events,sequence);
 merkleArtifact=proof;merkleCourierId=null;await renderMerkle();notify('Signed inclusion receipt generated: event digest only, not raw charter details.');
}catch(e){notify('Inclusion proof unavailable: '+e.message,true)}}
async function merklePin(){try{
 if(!merkleArtifact)throw Error('No reviewed artifact');const p=await M.preview(state,merkleArtifact);
 if(!p.adoptable)throw Error('Not an approved prefix extension: '+p.relation);
 const message=p.pinned?'VERIFY that this proof extends YOUR previously approved root, then accept the new checkpoint?':
   'FIRST TRUST CHECKPOINT: VERIFY THIS PUBLIC KEY FINGERPRINT OUTSIDE ProgRSS before pinning.\n\n'+p.subject+'\n\nThis only pins a transparency comparison baseline; it does NOT authenticate a person, authorize feeds or alter any recovery policy.';
 if(!confirm(message))return;
 const applied=await M.adopt(state,merkleArtifact);
 if(exchangeReplyNonce){const r=state.proofRequests.find(x=>x.nonce===exchangeReplyNonce&&x.status==='pending');if(r&&merkleArtifact.schema===M.EXT&&r.request.current.rootDigest===merkleArtifact.current.rootDigest&&r.request.current.treeSize===merkleArtifact.current.treeSize){r.status='fulfilled';exchangeReplyNonce=null;}}
 if(merkleCourierId){const row=state.inbox.find(x=>x.id===merkleCourierId&&x.status==='pending');if(row)Q.resolve(state,merkleCourierId,'accepted',applied.kind+'; no other trust change');}
 merkleCourierId=null;persist();await renderMerkle();renderInbox();notify(applied.kind==='first-pin'?'First Merkle root pinned locally.':'Verified append-only extension accepted locally.');
}catch(e){notify('Merkle pin refused: '+e.message,true)}}
function merkleExport(){if(!merkleArtifact)throw Error('No artifact');const p=Q.makeCapsule(merkleArtifact,{note:'Merkle Observatory · signed commitment, explicit comparison only'});
 download('ProgRSS-'+p.kind+'-'+p.digest.slice(7,19)+'.json',JSON.stringify(p,null,2),'application/json');return p;}
async function merkleImport(file){if(!file)return;try{
 if(file.size>20000)throw Error('Merkle artifact file exceeds 20 KB');await merkleLoad(JSON.parse(await file.text()));notify('Merkle signatures and proofs independently verified, awaiting explicit review.');
}catch(e){notify('Merkle import refused: '+e.message,true)}}
async function merkleSend(){try{
 if(!merkleArtifact)throw Error('No selected Merkle artifact');const capsule=Q.makeCapsule(merkleArtifact);
 if(!confirm('Share this signed Merkle artifact with the connected peer?\n\nThe publisher public fingerprint is disclosed. Feed subscriptions and raw charters are not.'))return;
 await sendPayload('progrss.capsule.chunk.v1',capsule);notify('Proof delivered to Courier for explicit review.');
}catch(e){notify('WebRTC Merkle send blocked: '+e.message,true)}}
async function merkleAudit(){try{const p=await M.audit(state);$('merkle-status').textContent=JSON.stringify(p,null,2);notify(p.failures.length?'Merkle audit reports failures.':'Stored Merkle pins and proofs verified.',Boolean(p.failures.length));}catch(e){notify('Merkle audit failed: '+e.message,true)}}
async function merkleDemo(){try{
 if(!crypto?.subtle)throw Error('Web Crypto required');
 const pair=await crypto.subtle.generateKey({name:'Ed25519'},false,['sign','verify']);
 const publicKey=T.b64url(new Uint8Array(await crypto.subtle.exportKey('raw',pair.publicKey)));
 const me={algorithm:'Ed25519',publicKey,keyId:await T.keyId('Ed25519',publicKey),privateKey:pair.privateKey};
 const events=Array.from({length:5},(_,i)=>'sha256:'+String(i+1).repeat(64));
 const old=await M.mint(me,events.slice(0,2)),next=await M.mint(me,events);
 merklePrevious=old;merkleArtifact=await M.makeExtension(old,next,events);merkleCourierId=null;await renderMerkle();
 notify('Fictional offline demo: a verified 2 → 5 leaf extension. It cannot update any existing pin.');
}catch(e){notify('Offline Merkle demo failed: '+e.message,true)}}
// rev0018 / Proof Exchange: no request is answered automatically; no received
// proof can pin or alter a trust relationship. Every transfer is opt-in.
let exchangeArtifact=null,exchangeCourierId=null,exchangeReplyNonce=null,exchangeToken=0;
function exchangeHeadFromLoaded(){
 if(merkleArtifact?.schema===M.HEAD)return merkleArtifact;
 if(merkleArtifact?.schema===M.EXT)return merkleArtifact.current;
 if(merkleArtifact?.schema===M.INCL)return merkleArtifact.head;
 return null;
}
let doctorReport=null,doctorScanToken=0;
async function scanDoctor(){
  const token=++doctorScanToken,container=$('doctor-results');container.replaceChildren(h('p',{class:'mini',text:'Verifying saved signed checkpoints locally…'}));
  try{
    const report=await X.inspect(state);if(token!==doctorScanToken)return;doctorReport=report;
    const summary=h('p',{class:'mini',text:'Verified '+report.pins+' local pins; examined '+report.checked+' stored sightings. '+report.rows.length+' actionable or informational comparisons.'});
    const list=[summary];
    for(const row of report.rows){
      const verb=row.kind==='missing-proof'?'Prepare a proof request':row.kind==='fork'?'Open signed fork dossier':null;
      const tools=verb?[action(verb,async()=>{
        try{
          if(row.kind==='missing-proof'){
            const request=await X.prepare(state,row);
            exchangeArtifact=request;exchangeCourierId=null;persist();await renderExchange();notify('Local request STAGED, not sent. Export or manually send in Proof Exchange.');
          }else{
            exchangeArtifact=await E.makeFork(row.previous,row.head);exchangeCourierId=null;await renderExchange();notify('Verified signed fork dossier opened; nothing pinned or broadcast.');
          }
          await scanDoctor();
        }catch(e){notify('Chain Doctor: '+e.message,true)}
      })]:[];
      list.push(h('article',{class:'row-card'},[h('div',{},[
        h('h3',{text:row.kind.toUpperCase().replace('-', ' ')+' · '+row.head.subject.keyId.slice(0,36)}),
        h('p',{class:'mini',text:'Tree size '+(row.previous?.treeSize??'not pinned')+' → '+row.head.treeSize+' · '+row.meaning})]),
        h('div',{class:'row-actions'},tools)]));
    }
    if(report.errors.length)list.push(h('pre',{class:'trace-result',text:'UNVERIFIABLE ENTRIES (never trusted):\n'+report.errors.join('\n')}));
    if(!report.rows.length&&!report.errors.length)list.push(h('p',{class:'mini',text:'No missing links or signed forks found in the locally stored sightings. Signed checkpoints must be explicitly imported and recorded first.'}));
    container.replaceChildren(...list);
  }catch(e){if(token===doctorScanToken)container.replaceChildren(h('p',{class:'mini',text:'Doctor could not verify signed heads: '+e.message}));}
}

async function exchangeLoad(raw,id=null){
 const artifact=raw?.schema===Q.SCHEMA?Q.validateCapsule(raw).payload:raw;
 const result=await E.verify(artifact);exchangeArtifact=artifact;exchangeCourierId=id;
 go('recovery');await renderExchange();return result;
}
async function renderExchange(){
 const token=++exchangeToken,status=$('exchange-status'),history=$('exchange-history');E.ensureState(state);
 $('exchange-export').disabled=!exchangeArtifact;$('exchange-send').disabled=!exchangeArtifact||channel?.readyState!=='open';
 $('exchange-answer').disabled=!exchangeArtifact||exchangeArtifact.schema!==E.REQUEST;
 $('exchange-review').disabled=!exchangeArtifact||exchangeArtifact.schema!==E.REPLY;
 $('exchange-record').disabled=!exchangeArtifact||exchangeArtifact.schema!==E.FORK;
 $('exchange-open-fork').disabled=!state.proofForks.length;
 history.textContent='PENDING PROOF REQUESTS: '+state.proofRequests.filter(x=>x.status==='pending').length+' / 20 · OBSERVED SIGNED HEADS: '+state.proofSightings.length+' / 80 · CONFIRMED LOCAL FORKS: '+state.proofForks.length+' / 24\n'+
   (state.proofForks.length?state.proofForks.slice(0,8).map(x=>'FORK '+x.artifact.left.subject.keyId+' · size '+x.artifact.left.treeSize+'\n '+x.artifact.left.rootDigest+' ≠ '+x.artifact.right.rootDigest).join('\n'):'No contradicting SAME-SIZE signed roots observed.')+'\n\n'+
   state.proofRequests.slice(0,7).map(x=>(x.status||'pending').toUpperCase()+' '+x.nonce+' · '+x.request.previous.treeSize+'→'+x.request.current.treeSize).join('\n');
 if(!exchangeArtifact){status.textContent='Create a request from YOUR pinned checkpoint and a newly received signed head, or import an artifact. Incoming requests need no response, and a reply never changes your pins automatically.';return;}
 try{
  const p=await E.verify(exchangeArtifact);if(token!==exchangeToken)return;
  status.textContent='VERIFIED · '+p.kind.toUpperCase()+'\nSUBJECT: '+p.subject+
   (p.nonce?'\nREQUEST NONCE: '+p.nonce:'')+
   (p.first?'\nTREE SIZES: '+p.first+' → '+p.second:'')+
   (p.treeSize?'\nTREE SIZE: '+p.treeSize:'')+
   '\n'+p.meaning+'\n'+(p.kind==='proof-reply'?'\nMATCHES LOCAL OUTSTANDING REQUEST: '+(E.match(state,exchangeArtifact)?'YES':'NO; inspect out of band; cannot adopt as an answered request here.'):'')+
   '\n\nFile and WebRTC transfers are deliberate. The signed public key and checkpoint sizes will be visible to recipients.';
 }catch(e){if(token===exchangeToken)status.textContent='PROOF EXCHANGE REJECTED: '+e.message;}
}
async function exchangeRequest(){try{
 const later=exchangeHeadFromLoaded();if(!later)throw Error('Load a NEWER signed Merkle head in Merkle Observatory first');
 const pin=(state.merklePins||[]).find(p=>p.subjectKeyId===later.subject.keyId);
 if(!pin)throw Error('You must explicitly pin the OLDER head before requesting a proof');
 const request=await E.makeRequest(pin.head,later);
 await E.stage(state,request);
 exchangeArtifact=request;exchangeCourierId=null;persist();await renderExchange();notify('Proof request staged. Export or manually send it; no network action occurred.');
 }catch(e){notify('Proof request blocked: '+e.message,true)}
}
async function exchangeAnswer(){try{
 if(exchangeArtifact?.schema!==E.REQUEST)throw Error('Import a verified request first');
 const req=exchangeArtifact,me=await T.getIdentity();if(!me||me.keyId!==req.previous.subject.keyId)throw Error('Only the requested curator key may answer from locally approved history');
 const events=await M.eventsFromState(state,me.keyId,recoveryArtifact?.schema===H.CHARTER?recoveryArtifact:null);
 const reply=await E.makeReply(req,events);
 exchangeArtifact=reply;
 if(exchangeCourierId){const row=state.inbox.find(x=>x.id===exchangeCourierId&&x.status==='pending');if(row)Q.resolve(state,row.id,'accepted','Request inspected and matching proof prepared; no trust update');}
 exchangeCourierId=null;persist();await renderExchange();renderInbox();notify('Proof reply computed from verified local history. Share it only if you choose.');
 }catch(e){notify('Cannot answer: '+e.message,true)}
}
async function exchangeReview(){try{
 if(exchangeArtifact?.schema!==E.REPLY)throw Error('Choose an authenticated proof reply first');
 const response=await E.verify(exchangeArtifact);
 if(!E.match(state,exchangeArtifact))throw Error('Reply does not match a PENDING request created locally, or request is already fulfilled');
 const pin=state.merklePins.find(p=>p.subjectKeyId===response.subject);
 if(!pin||Q.canonical(pin.head)!==Q.canonical(exchangeArtifact.request.previous))throw Error('Your pinned checkpoint differs from the proof request; never auto-rebase');
 exchangeReplyNonce=response.nonce;
 await merkleLoad(exchangeArtifact.extension,exchangeCourierId);
 notify('Requested consistency path verified. Review then APPROVE separately in Merkle Observatory; pin still unchanged.');
 }catch(e){notify('Proof review blocked: '+e.message,true)}
}
async function exchangeObserve(){try{
 const head=exchangeHeadFromLoaded();if(!head)throw Error('Load a signed Merkle head in Merkle Observatory first');
 if(!confirm('Record this SIGNED public checkpoint locally for fork comparison? It reveals no feeds, but persists the public signer fingerprint and root.'))return;
 const result=await E.observe(state,head);persist();await renderExchange();
 notify(result.forks.length?'SIGNED FORK EVIDENCE recorded. Review/export only by choice.':result.duplicate?'Already observed this exact head.':'Verified head recorded; different-size comparisons remain unresolved.',Boolean(result.forks.length));
 }catch(e){notify('Head observation blocked: '+e.message,true)}
}
async function exchangeRecord(){try{
 if(exchangeArtifact?.schema!==E.FORK)throw Error('Load a signed fork dossier');
 if(!confirm('Keep these TWO verified, contradictory signed heads in your private local evidence journal?'))return;
 const result=await E.recordFork(state,exchangeArtifact);
 if(exchangeCourierId){const row=state.inbox.find(x=>x.id===exchangeCourierId&&x.status==='pending');if(row)Q.resolve(state,row.id,'accepted','Signed conflicting heads archived as evidence only');}
 exchangeCourierId=null;persist();await renderExchange();renderInbox();notify(result.duplicate?'Dossier already recorded.':'Signed fork evidence saved locally. No identity pin changed.');
 }catch(e){notify('Dossier refused: '+e.message,true)}
}
async function exchangeOpenFork(){try{if(!state.proofForks.length)throw Error('No signed same-size conflict has been recorded');await exchangeLoad(state.proofForks[0].artifact);notify('Latest contradictory signed roots opened. Export manually if you choose.');}catch(e){notify('Fork review: '+e.message,true)}}
function exchangeExport(){if(!exchangeArtifact)throw Error('No proof exchange artifact');const pkg=Q.makeCapsule(exchangeArtifact,{note:'Proof Exchange: public signed commitments, opt-in inspection only'});
 download('ProgRSS-'+pkg.kind+'-'+pkg.digest.slice(7,19)+'.json',JSON.stringify(pkg,null,2),'application/json');return pkg;}
async function exchangeSend(){try{
 const p=exchangeExportPayload();if(!confirm('Share this '+p.kind+' with the connected WebRTC peer? This reveals the SIGNER FINGERPRINT and checkpoint sizes (and your interest in this subject if requesting). No feeds, snapshots or raw charters are shared.'))return;
 await sendPayload('progrss.capsule.chunk.v1',p);notify('Proof Exchange parcel sent for Courier review.');
 }catch(e){notify('Proof transfer blocked: '+e.message,true)}
}
function exchangeExportPayload(){if(!exchangeArtifact)throw Error('No artifact');return Q.makeCapsule(exchangeArtifact);}
async function exchangeImport(file){if(!file)return;try{
 if(file.size>20000)throw Error('Proof exchange file exceeds 20 KB');await exchangeLoad(JSON.parse(await file.text()));notify('Proof Exchange artifact verified; no trust changed.');
 }catch(e){notify('Proof Exchange import refused: '+e.message,true)}
}
async function exchangeDemo(){try{
 if(!crypto?.subtle)throw Error('Web Crypto needed for the offline demonstration');
 const pair=await crypto.subtle.generateKey({name:'Ed25519'},false,['sign','verify']);
 const publicKey=T.b64url(new Uint8Array(await crypto.subtle.exportKey('raw',pair.publicKey)));
 const me={algorithm:'Ed25519',publicKey,keyId:await T.keyId('Ed25519',publicKey),privateKey:pair.privateKey};
 const events=Array.from({length:5},(_,i)=>'sha256:'+((i+17).toString(16).padStart(2,'0')).repeat(32));
 const first=await M.mint(me,events.slice(0,2)),later=await M.mint(me,events);
 const req=await E.makeRequest(first,later);const reply=await E.makeReply(req,events);await E.verify(reply);
 exchangeArtifact=reply;exchangeCourierId=null;await renderExchange();
 notify('Offline 2→5 signed request/reply generated and verified. It is a fictional example, NOT associated with any existing pin; export and inspect safely.');
 }catch(e){notify('Proof Exchange demo blocked: '+e.message,true)}
}

// Wire controls.
document.querySelectorAll('[data-view]').forEach(el=>el.addEventListener('click',()=>go(el.dataset.view)));
document.querySelectorAll('[data-close]').forEach(el=>el.addEventListener('click',()=>close(el.dataset.close)));
for(const id of ['rail-add','top-add','hero-add','sources-add'])$(id).addEventListener('click',()=>openLens());
$('top-scout').addEventListener('click',()=>go('scout'));
$('proof-replay').addEventListener('click',replayDiscovery);$('proof-adopt').addEventListener('click',adoptDiscovery);
$('proof-export').addEventListener('click',()=>proofDownload(false));$('proof-capsule').addEventListener('click',()=>proofDownload(true));$('proof-send').addEventListener('click',proofSend);
$('proof-import-button').addEventListener('click',()=>$('proof-import-file').click());$('proof-import-file').addEventListener('change',async e=>{await importProofFile(e.target.files[0]);e.target.value='';});
$('scout-fetch').addEventListener('click',fetchScout);$('scout-analyze').addEventListener('click',()=>analyzeScout($('scout-html').value));
$('scout-demo').addEventListener('click',demoScout);$('scout-clear').addEventListener('click',()=>{$('scout-html').value='';$('scout-header').value='';scoutMarkupMemory='';scoutLinkHeader='';scoutReport=null;activeProof=null;pendingDiscoveryCourierId=null;proofReplay=null;$('scout-status').textContent='Cleared. No content stored.';renderScout(null);renderProofWorkbench()});
for(const id of ['scout-html','scout-header','scout-url'])$(id).addEventListener('input',()=>{if(proofReplay){proofReplay=null;renderProofWorkbench()}});
$('scout-file').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;try{if(file.size>C.LIMIT.characters)throw Error('Local file exceeds 2MB');$('scout-html').value=await file.text();analyzeScout($('scout-html').value);}catch(error){notify('Scout file: '+error.message,true)}finally{e.target.value=''}});
for(const id of ['collections-add'])$(id).addEventListener('click',()=>openCollection());
$('collections-lineage').addEventListener('click',()=>go('lineage'));
$('lineage-publish').addEventListener('click',()=>publishEdition(false));$('lineage-publish-legacy').addEventListener('click',()=>publishEdition(true));$('trust-key-create').addEventListener('click',createTrustIdentity);$('trust-key-refresh').addEventListener('click',renderTrustIdentity);$('lineage-send').addEventListener('click',sendLastEdition);
$('recovery-open-courier').addEventListener('click',()=>go('peers'));
$('merkle-create').addEventListener('click',merkleCreate);$('merkle-inclusion').addEventListener('click',merkleInclusion);$('merkle-pin').addEventListener('click',merklePin);$('merkle-audit').addEventListener('click',merkleAudit);$('merkle-demo').addEventListener('click',merkleDemo);$('merkle-export').addEventListener('click',()=>{try{merkleExport()}catch(e){notify(e.message,true)}});$('merkle-send').addEventListener('click',merkleSend);$('merkle-file-button').addEventListener('click',()=>$('merkle-file').click());$('merkle-file').addEventListener('change',async e=>{await merkleImport(e.target.files[0]);e.target.value=''});
$('doctor-scan').addEventListener('click',scanDoctor);$('commons-demo').addEventListener('click',commonsDemo);
$('exchange-request').addEventListener('click',exchangeRequest);$('exchange-answer').addEventListener('click',exchangeAnswer);$('exchange-review').addEventListener('click',exchangeReview);$('exchange-observe').addEventListener('click',exchangeObserve);$('exchange-record').addEventListener('click',exchangeRecord);$('exchange-open-fork').addEventListener('click',exchangeOpenFork);$('exchange-demo').addEventListener('click',exchangeDemo);$('exchange-export').addEventListener('click',()=>{try{exchangeExport()}catch(e){notify(e.message,true)}});$('exchange-send').addEventListener('click',exchangeSend);$('exchange-import-button').addEventListener('click',()=>$('exchange-import-file').click());$('exchange-import-file').addEventListener('change',async e=>{await exchangeImport(e.target.files[0]);e.target.value=''});
$('gossip-create').addEventListener('click',gossipCreate);$('gossip-witness').addEventListener('click',gossipSign);$('gossip-record').addEventListener('click',gossipRecord);$('gossip-pin').addEventListener('click',gossipPin);$('gossip-export').addEventListener('click',()=>{try{gossipExport()}catch(e){notify(e.message,true)}});$('gossip-send').addEventListener('click',gossipSend);$('gossip-audit').addEventListener('click',gossipAudit);$('gossip-file-button').addEventListener('click',()=>$('gossip-file').click());$('gossip-file').addEventListener('change',async e=>{await gossipImport(e.target.files[0]);e.target.value=''});
$('ledger-create').addEventListener('click',ledgerCreate);$('ledger-approve').addEventListener('click',ledgerApprove);$('ledger-export').addEventListener('click',()=>{try{ledgerExport()}catch(e){notify(e.message,true)}});$('ledger-send').addEventListener('click',ledgerPeer);$('ledger-audit').addEventListener('click',ledgerAudit);$('ledger-file-button').addEventListener('click',()=>$('ledger-file').click());$('ledger-file').addEventListener('change',async e=>{await ledgerImport(e.target.files[0]);e.target.value=''});
$('recovery-card').addEventListener('click',async()=>{try{const x=await T.getIdentity();if(!x)throw Error('Create your signing identity first');download('ProgRSS-guardian-card-'+x.keyId.slice(0,19)+'.json',JSON.stringify(H.descriptor(x),null,2),'application/json');notify('Public Guardian Card exported; no secret keys included.')}catch(e){notify('Guardian Card: '+e.message,true)}});
$('recovery-charter-create').addEventListener('click',recoveryCreateCharter);$('recovery-request').addEventListener('click',recoveryCreateRequest);$('recovery-vote').addEventListener('click',recoveryVote);
$('recovery-pin').addEventListener('click',recoveryPin);$('recovery-apply').addEventListener('click',recoveryApply);$('recovery-export').addEventListener('click',()=>{try{recoveryExport()}catch(e){notify(e.message,true)}});
$('recovery-peer').addEventListener('click',recoverySend);$('recovery-file-button').addEventListener('click',()=>$('recovery-file').click());$('recovery-file').addEventListener('change',async e=>{await recoveryImport(e.target.files[0]);e.target.value=''});
$('key-bridge-stage').addEventListener('click',stageKeyRotation);$('key-bridge-activate').addEventListener('click',activateKeyRotation);$('key-bridge-send').addEventListener('click',sendKeyRotation);$('key-bridge-approve').addEventListener('click',applyRotation);
$('lineage-demo').addEventListener('click',lineageDemo);$('lineage-open-courier').addEventListener('click',()=>go('peers'));
$('lineage-import-button').addEventListener('click',()=>$('lineage-import-file').click());
$('lineage-import-file').addEventListener('change',async e=>{await doImport(e.target.files[0]);e.target.value='';});
$('lineage-apply').addEventListener('click',applyEdition);$('lineage-cancel').addEventListener('click',()=>{pendingEdition=null;pendingSignedEdition=null;pendingEditionCourierId=null;pendingLineageChoices=Object.create(null);renderLineageReview();});
for(const id of ['top-import'])$(id).addEventListener('click',()=>$('import-file').click());
$('import-file').addEventListener('change',async e=>{await doImport(e.target.files[0]);e.target.value=''});
$('lens-type').addEventListener('change',toggleLensFields);$('lens-mode').addEventListener('change',toggleLensFields);
$('lens-form').addEventListener('submit',saveLens);$('collection-form').addEventListener('submit',saveCollection);
$('refresh-all').addEventListener('click',refreshAll);$('search-items').addEventListener('input',renderHome);
$('collection-choice').addEventListener('change',e=>{activeCollection=e.target.value;renderHome();traceSelected()});
$('trace-run').addEventListener('click',traceSelected);$('trace-choose').addEventListener('change',traceSelected);
$('collection-mode').addEventListener('change',refreshCollectionBase);
$('top-export').addEventListener('click',downloadRecipes);$('export-feed').addEventListener('click',exportJSONFeed);
$('hero-demo').addEventListener('click',loadDemo);$('home-docs').addEventListener('click',()=>go('docs'));
$('auto-interval').addEventListener('change',()=>{applySchedule();notify(Number($('auto-interval').value)?'Open-tab scheduling enabled. Only due Lenses are checked, with per-site pacing.':'Scheduled checks disabled.')});
$('refresh-due').addEventListener('click',refreshDue);
$('docs-backup').addEventListener('click',exportBackup);$('docs-opml').addEventListener('click',()=>download('ProgRSS-feeds.opml',C.makeOPML(state),'text/xml'));
$('clinic-source').addEventListener('change',e=>clinicSelect(e.target.value));$('clinic-mode').addEventListener('change',()=>{toggleClinicCardFields();resetForge();});$('forge-run').addEventListener('click',runForge);
$('arena-run').addEventListener('click',runArena);$('arena-demo').addEventListener('click',arenaDemo);$('arena-export').addEventListener('click',exportArena);
$('clinic-demo').addEventListener('click',clinicDemonstration);$('clinic-analyze').addEventListener('click',clinicAnalyze);
$('clinic-save-case').addEventListener('click',clinicSaveCase);$('clinic-run-suite').addEventListener('click',clinicSuite);$('clinic-apply').addEventListener('click',clinicApply);
$('clinic-export').addEventListener('click',clinicExport);$('clinic-import-button').addEventListener('click',()=>$('clinic-import-file').click());
$('clinic-import-file').addEventListener('change',async e=>{await clinicImport(e.target.files[0]);e.target.value=''});
for(const side of ['before','after'])$('clinic-'+side+'-file').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;if(file.size>160_000)return notify('Fixture file exceeds 160K characters',true);$('clinic-'+side).value=await file.text();e.target.value='';notify('Loaded snapshot '+side+'.')});
$('proposal-stage').addEventListener('click',()=>{try{stagePatch()}catch(error){notify('Proposal: '+error.message,true)}});
$('proposal-export').addEventListener('click',exportPatch);$('proposal-sign').addEventListener('click',signStagedPatch);$('proposal-export-signed').addEventListener('click',exportSignedPatch);
$('proposal-import-button').addEventListener('click',()=>$('proposal-import-file').click());
$('proposal-import-file').addEventListener('change',async e=>{await importPatch(e.target.files[0]);e.target.value=''});
$('proposal-target').addEventListener('change',renderProposalReview);
$('proposal-apply').addEventListener('click',applyPatch);
$('proposal-clear').addEventListener('click',()=>{pendingProposal=null;pendingPatchCourierId=null;pendingSignedPatch=null;stagedSignedPatch=null;stagedProposal=null;pendingPatchInbound=false;$('proposal-export-signed').disabled=true;$('proposal-sign-status').textContent='No staged signature.';$('peer-send-proposal').disabled=true;renderProposalReview();notify('Staged proposal discarded')});
$('peers-file-export').addEventListener('click',exportNewCourier);
$('courier-demo').addEventListener('click',courierDemonstration);$('courier-file-export').addEventListener('click',exportNewCourier);$('courier-patch-export').addEventListener('click',exportCourierPatch);
$('peer-offer').addEventListener('click',createOffer);$('peer-accept').addEventListener('click',acceptOffer);$('peer-finish').addEventListener('click',finishAnswer);$('peer-close').addEventListener('click',resetPeer);$('peer-send').addEventListener('click',sendPeer);$('peer-send-proposal').addEventListener('click',sendPeerProposal);
$('peer-copy').addEventListener('click',async()=>{try{await navigator.clipboard.writeText($('peer-local').value);notify('Packet copied to clipboard')}catch{$('peer-local').focus();$('peer-local').select();notify('Clipboard unavailable; packet selected for manual copy.')}});
// Boot is asynchronous because IndexedDB is not synchronous. Keep controls inert
// until migration from rev0002 Web Storage has completed.
$('shell').inert=true;
async function boot(){
  try{state=L.stateInit(Q.initializeState(await V.init()));G.normalizePins(state);}catch(err){state=emptyState();notify('Vault unavailable: '+err.message,true);}
  renderVault();renderProofWorkbench();renderTrustIdentity();renderKeyBridge();renderMerkle();renderExchange();
  try{const interval=Number(localStorage.getItem(AUTO)||0);$('auto-interval').value=[0,5,15,60].includes(interval)?String(interval):'0'}catch{}
  applySchedule();$('shell').inert=false;render();detectBridge();
  const info=V.info();if(info.warning)notify(info.warning,info.mode==='memory');
}
window.addEventListener('beforeunload',()=>{if(peer)resetPeer()});
// Fixture Garden UI · no automatic transfer, adoption or network activity.
$('garden-demo').addEventListener('click',gardenSeed);
$('garden-check').addEventListener('click',gardenCheck);
$('garden-run').addEventListener('click',gardenRun);
$('garden-save').addEventListener('click',gardenSave);
$('garden-export').addEventListener('click',gardenExport);
$('garden-share').addEventListener('click',gardenShare);
$('garden-import').addEventListener('click',()=>$('garden-file').click());
$('garden-file').addEventListener('change',e=>{gardenImportFile(e.target.files?.[0]);e.target.value='';});
$('garden-editor').addEventListener('input',()=>{gardenDraft=null;gardenCourierId=null;$('garden-attest').checked=false;gardenDescribe();});
boot();
})();
