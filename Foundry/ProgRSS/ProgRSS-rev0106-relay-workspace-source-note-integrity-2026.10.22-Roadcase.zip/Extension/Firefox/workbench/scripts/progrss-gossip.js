/* ProgRSS rev0016 · Witness Gossip
 * Opt-in, signed, bounded trust-history checkpoints. Not a global log or anonymity service.
 * No feed addresses, graph, guardian roster, browsing history or raw content in payloads.
 * Same-subject/same-sequence different owner-signed tips constitute detectable equivocation.
 */
(function(root){
'use strict';
const Q=root.ProgRSSCourier,T=root.ProgRSSTrust,J=root.ProgRSSLedger,H=root.ProgRSSRecovery;
const HEAD='progrss.trust-head.v1',SIGHT='progrss.trust-sighting.v1';
const DOMAIN_HEAD='ProgRSS/trust-head/v1',DOMAIN_SIGHT='ProgRSS/trust-sighting/v1';
const HEAD_FIELDS=['schema','subject','sequence','tipDigest','parentDigest','issuedAt','signature'];
const SIGHT_FIELDS=['schema','head','witness','seenAt','signature'];
const DIGEST=/^sha256:[a-f0-9]{64}$/;
const UTC=/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;
const iso=()=>new Date().toISOString();
const hash=x=>'sha256:'+Q.sha256(Q.canonical(x));
const descriptor=x=>({algorithm:x.algorithm,publicKey:x.publicKey,keyId:x.keyId});
const params=a=>a==='Ed25519'?{name:'Ed25519'}:{name:'ECDSA',namedCurve:'P-256'};
const sigparams=a=>a==='Ed25519'?{name:'Ed25519'}:{name:'ECDSA',hash:'SHA-256'};
const signable=(domain,obj)=>new TextEncoder().encode(Q.canonical({domain,statement:Object.fromEntries(Object.entries(obj).filter(([k])=>k!=='signature'))}));
function exact(obj,fields){if(!obj||typeof obj!=='object'||Array.isArray(obj)||Object.keys(obj).length!==fields.length||fields.some(k=>!Object.hasOwn(obj,k)))throw Error('Unknown/missing Witness Gossip fields');}
function stamp(s){if(typeof s!=='string'||!UTC.test(s)||!Number.isFinite(Date.parse(s))||new Date(s).toISOString()!==s)throw Error('Invalid UTC witness timestamp');}
function key(k){H.checkKey(k);exact(k,['algorithm','publicKey','keyId']);return k;}
function shapeHead(x){
 exact(x,HEAD_FIELDS);
 if(x.schema!==HEAD||JSON.stringify(x).length>2600)throw Error('Unsupported/oversized trust head');
 key(x.subject);
 if(!Number.isSafeInteger(x.sequence)||x.sequence<0||x.sequence>64)throw Error('Invalid trust-head sequence');
 if(typeof x.tipDigest!=='string'||!DIGEST.test(x.tipDigest))throw Error('Invalid tip digest');
 if(x.sequence===0?x.parentDigest!==null:!DIGEST.test(x.parentDigest))throw Error('Invalid trust-head predecessor');
 stamp(x.issuedAt);T.unb64(x.signature,64);return x;
}
function shapeSighting(x){
 exact(x,SIGHT_FIELDS);
 if(x.schema!==SIGHT||JSON.stringify(x).length>4400)throw Error('Unsupported/oversized witness sighting');
 shapeHead(x.head);key(x.witness);stamp(x.seenAt);
 if(x.witness.keyId===x.head.subject.keyId)throw Error('Self witnessing adds no independent evidence');
 T.unb64(x.signature,64);return x;
}
function shape(x){if(x?.schema===HEAD)return {kind:'trust-head',artifact:shapeHead(x)};
 if(x?.schema===SIGHT)return {kind:'trust-sighting',artifact:shapeSighting(x)};
 throw Error('Not a supported Witness Gossip artifact');}
async function verifiedSigner(k,signature,bytes){
 if(!root.crypto?.subtle)throw Error('Web Crypto required for signature validation');
 if(await T.keyId(k.algorithm,k.publicKey)!==k.keyId)throw Error('Witness Gossip fingerprint mismatch');
 const pub=await root.crypto.subtle.importKey('raw',T.unb64(k.publicKey,k.algorithm==='Ed25519'?32:65),params(k.algorithm),false,['verify']);
 const good=await root.crypto.subtle.verify(sigparams(k.algorithm),pub,T.unb64(signature,64),bytes);
 if(!good)throw Error('INVALID WITNESS GOSSIP SIGNATURE');
 return true;
}
async function verify(raw){
 const {kind,artifact}=shape(raw),head=kind==='trust-head'?artifact:artifact.head;
 await verifiedSigner(head.subject,head.signature,signable(DOMAIN_HEAD,head));
 if(kind==='trust-sighting')await verifiedSigner(artifact.witness,artifact.signature,signable(DOMAIN_SIGHT,artifact));
 return {kind,artifact,head,headDigest:hash(head),artifactDigest:hash(artifact),
   witnessKeyId:kind==='trust-sighting'?artifact.witness.keyId:null,verified:true};
}
async function mint(identity,{sequence,tipDigest,parentDigest=null,issuedAt=iso()}={}){
 if(!identity?.privateKey||identity.privateKey.extractable)throw Error('Non-exportable signing key required');
 const card={schema:HEAD,subject:descriptor(identity),sequence,tipDigest,parentDigest,issuedAt,signature:T.b64url(new Uint8Array(64))};
 shapeHead(card);
 if(await T.keyId(identity.algorithm,identity.publicKey)!==identity.keyId)throw Error('Local publisher key mismatch');
 card.signature=T.b64url(new Uint8Array(await root.crypto.subtle.sign(sigparams(identity.algorithm),identity.privateKey,signable(DOMAIN_HEAD,card))));
 await verify(card);return card;
}
async function mintFromLocal(identity,state,loaded=null){
 if(!identity)throw Error('Generate a Trust Keys identity first');
 const p=(state.recoveryPolicies||[]).find(x=>x.subjectKeyId===identity.keyId);
 if(!p){
   // The publisher is not required to follow/pin THEMSELVES. A currently loaded,
   // owner-signed charter is sufficient to advertise its genesis commitment.
   if(!loaded||loaded.schema!==H.CHARTER)throw Error('Load your own signed genesis recovery charter first, or use an existing pinned local history');
   const checked=await H.verifyCharter(loaded);
   if(Q.canonical(loaded.subject)!==Q.canonical(descriptor(identity)))throw Error('Loaded charter belongs to a different publisher key');
   return mint(identity,{sequence:0,tipDigest:checked.digest});
 }
 if(Q.canonical(p.charter.subject)!==Q.canonical(descriptor(identity)))throw Error('Pinned owner charter does not match signing key');
 const sequence=p.ledgerSequence||0,tipDigest=p.ledgerDigest||p.digest;
 let parentDigest=null;
 if(sequence===0){const checked=await H.verifyCharter(p.charter);if(checked.digest!==tipDigest)throw Error('Pinned genesis charter does not match hash');}
 else{
   const hist=(state.charterHistory||[]).filter(x=>x.subjectKeyId===identity.keyId&&x.sequence===sequence&&x.digest===tipDigest);
   if(hist.length!==1)throw Error('Cannot sign a head without local approved revision evidence');
   const item=hist[0],checked=await J.verify(item.statement);
   if(checked.digest!==tipDigest||item.priorDigest!==item.statement.priorDigest)throw Error('Invalid approved charter-change evidence');
   parentDigest=item.priorDigest;
   const audit=await J.audit(state);if(audit.failures.some(f=>f.subject===identity.keyId))throw Error('Local trust-history audit failed');
 }
 return mint(identity,{sequence,tipDigest,parentDigest});
}
async function witness(identity,card){
 if(!identity?.privateKey||identity.privateKey.extractable)throw Error('Witness signer requires an active non-exportable key');
 const original=await verify(card),head=original.head;
 if(identity.keyId===head.subject.keyId)throw Error('Use publisher head, not a self-witness');
 const out={schema:SIGHT,head,witness:descriptor(identity),seenAt:iso(),signature:T.b64url(new Uint8Array(64))};
 shapeSighting(out);
 out.signature=T.b64url(new Uint8Array(await root.crypto.subtle.sign(sigparams(identity.algorithm),identity.privateKey,signable(DOMAIN_SIGHT,out))));
 await verify(out);return out;
}
function ensureState(state){if(!Array.isArray(state.gossipCards))state.gossipCards=[];if(!Array.isArray(state.witnessPins))state.witnessPins=[];return state;}
function forks(records){const out=[],seen=new Set();for(let i=0;i<records.length;i++)for(let j=i+1;j<records.length;j++){
 const a=records[i],b=records[j];
 if(a.subjectKeyId===b.subjectKeyId&&a.sequence===b.sequence&&a.tipDigest!==b.tipDigest){
 const pair=[a.headDigest,b.headDigest].sort(),id=a.subjectKeyId+':'+a.sequence+':'+pair.join(':');
 if(!seen.has(id)){out.push({subject:a.subjectKeyId,sequence:a.sequence,headA:pair[0],headB:pair[1]});seen.add(id)}
 }
 }return out;}
function localComparison(state,head){const p=(state.recoveryPolicies||[]).find(x=>x.subjectKeyId===head.subject.keyId);
 if(!p)return 'NO LOCAL TRUST PIN. A verified signature alone cannot establish one.';
 const seq=p.ledgerSequence||0,tip=p.ledgerDigest||p.digest;
 if(seq===head.sequence)return tip===head.tipDigest?'MATCHES YOUR PINNED REVISION':'CONFLICTS WITH YOUR PINNED REVISION';
 return seq>head.sequence?'OLDER THAN LOCAL PIN (not automatically a fork)':'AHEAD OF LOCAL PIN (ancestry not established)';
}
async function preview(state,raw){const check=await verify(raw);ensureState(state);
 const self=(state.gossipCards||[]).find(x=>x.artifactDigest===check.artifactDigest);
 const candidates=[...(state.gossipCards||[]),{artifactDigest:check.artifactDigest,headDigest:check.headDigest,subjectKeyId:check.head.subject.keyId,sequence:check.head.sequence,tipDigest:check.head.tipDigest}];
 const other=forks(candidates).filter(x=>x.subject===check.head.subject.keyId&&x.sequence===check.head.sequence);
 const witnessPin=check.witnessKeyId?(state.witnessPins||[]).find(p=>p.keyId===check.witnessKeyId&&p.publicKey===check.artifact.witness.publicKey):null;
 return {...check,duplicate:Boolean(self),forks:other,localPin:localComparison(state,check.head),witnessPinned:Boolean(witnessPin)};
}
async function record(state,raw){const result=await preview(state,raw);ensureState(state);
 if(result.duplicate)return {...result,stored:false};
 if(state.gossipCards.length>=128)throw Error('Witness journal full; export a PRIVATE backup before adding more');
 const item={artifactDigest:result.artifactDigest,headDigest:result.headDigest,
   subjectKeyId:result.head.subject.keyId,sequence:result.head.sequence,tipDigest:result.head.tipDigest,
   witnessKeyId:result.witnessKeyId,artifact:result.artifact,seenAt:iso()};
 state.gossipCards.push(item);return {...result,stored:true};
}
async function pinWitness(state,raw,label=''){
 const check=await verify(raw);if(!check.witnessKeyId)throw Error('Only a distinct witness can be pinned');
 ensureState(state);const k=check.artifact.witness;
 const found=state.witnessPins.find(x=>x.keyId===k.keyId);
 if(found){if(Q.canonical(descriptor(found))!==Q.canonical(k))throw Error('Pinned witness identity differs');return {alreadyPinned:true,witnessKeyId:k.keyId};}
 if(state.witnessPins.length>=64)throw Error('Witness pin list full');
 if(typeof label!=='string'||label.length>72)throw Error('Invalid local label');
 state.witnessPins.push({...k,label:label.trim(),pinnedAt:iso()});return {alreadyPinned:false,witnessKeyId:k.keyId};
}
async function audit(state){ensureState(state);const verified=[],failures=[];
 for(const row of state.gossipCards){try{
   const r=await verify(row.artifact);
   if(r.artifactDigest!==row.artifactDigest||r.headDigest!==row.headDigest||r.head.subject.keyId!==row.subjectKeyId||r.head.tipDigest!==row.tipDigest||r.head.sequence!==row.sequence||r.witnessKeyId!==row.witnessKeyId)throw Error('Saved receipt metadata changed');
   verified.push(row);
 }catch(e){failures.push({digest:String(row?.artifactDigest||'').slice(0,84),error:String(e.message||e)});}}
 return {checked:verified.length,failed:failures.length,failures,forks:forks(verified),pinnedWitnesses:state.witnessPins.length,
 caveat:'Independent signed statements; no Merkle consistency proof, universal visibility, trusted clock or automatic trust transfer.'};
}
root.ProgRSSGossip=Object.freeze({HEAD,SIGHT,DOMAIN_HEAD,DOMAIN_SIGHT,shape,shapeHead,shapeSighting,verify,mint,mintFromLocal,witness,ensureState,preview,record,pinWitness,audit,forks,hash});
})(globalThis);
