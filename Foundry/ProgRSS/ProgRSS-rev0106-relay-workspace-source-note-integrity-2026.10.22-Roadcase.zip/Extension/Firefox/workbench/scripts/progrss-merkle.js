/* ProgRSS rev0017 · Merkle Observatory
 * Compact RFC 9162-style SHA-256 tree with inclusion and consistency proofs.
 * This is a LOCAL tree of approved owner-signed recovery-charter history, NOT
 * a public Certificate Transparency server or globally consistent log.
 * No raw charters, guardian lists, feeds or snapshots in public artifacts.
 */
(function(root){
'use strict';
const Q=root.ProgRSSCourier,T=root.ProgRSSTrust,H=root.ProgRSSRecovery,J=root.ProgRSSLedger;
const HEAD='progrss.merkle-head.v1',EXT='progrss.merkle-consistency.v1',INCL='progrss.merkle-inclusion.v1';
const DOMAIN='ProgRSS/merkle-head/v1',D=/^sha256:[0-9a-f]{64}$/,MAX=65;
const utf8=x=>new TextEncoder().encode(x);
const descriptor=x=>({algorithm:x.algorithm,publicKey:x.publicKey,keyId:x.keyId});
const signParams=a=>a==='Ed25519'?{name:'Ed25519'}:{name:'ECDSA',hash:'SHA-256'};
const importParams=a=>a==='Ed25519'?{name:'Ed25519'}:{name:'ECDSA',namedCurve:'P-256'};
const hex=bytes=>[...bytes].map(b=>b.toString(16).padStart(2,'0')).join('');
const bytes=d=>{if(typeof d!=='string'||!D.test(d))throw Error('Invalid SHA-256 node');return Uint8Array.from(d.slice(7).match(/../g),x=>parseInt(x,16));};
const hash=async b=>'sha256:'+hex(new Uint8Array(await subtle().digest('SHA-256',b)));
function subtle(){if(!root.crypto?.subtle)throw Error('Secure WebCrypto required for Merkle proof checks');return root.crypto.subtle;}
function exact(x,keys){if(!x||typeof x!=='object'||Array.isArray(x)||Object.keys(x).length!==keys.length||keys.some(k=>!Object.hasOwn(x,k)))throw Error('Unknown or missing Merkle artifact fields');}
function date(s){if(typeof s!=='string'||!/^[0-9]{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(s)||!Number.isFinite(Date.parse(s))||new Date(s).toISOString()!==s)throw Error('Invalid Merkle timestamp');}
function shapeHead(x){
  exact(x,['schema','subject','treeSize','rootDigest','tipDigest','issuedAt','signature']);
  if(x.schema!==HEAD||JSON.stringify(x).length>2700)throw Error('Invalid Merkle head schema/size');
  exact(x.subject,['algorithm','publicKey','keyId']);H.checkKey(x.subject);
  if(!Number.isSafeInteger(x.treeSize)||x.treeSize<1||x.treeSize>MAX)throw Error('Invalid Merkle size');
  bytes(x.rootDigest);bytes(x.tipDigest);date(x.issuedAt);T.unb64(x.signature,64);return x;
}
function shapeExtension(x){
  exact(x,['schema','previous','current','path']);
  if(x.schema!==EXT||JSON.stringify(x).length>10000)throw Error('Invalid Merkle consistency schema/size');
  shapeHead(x.previous);shapeHead(x.current);
  if(Q.canonical(x.previous.subject)!==Q.canonical(x.current.subject))throw Error('Merkle subject key mismatch');
  if(x.previous.treeSize>=x.current.treeSize)throw Error('Consistency must increase tree size');
  if(!Array.isArray(x.path)||x.path.length<1||x.path.length>10)throw Error('Invalid consistency proof length');
  x.path.forEach(bytes);return x;
}
function shapeInclusion(x){
  exact(x,['schema','head','sequence','eventDigest','path']);
  if(x.schema!==INCL||JSON.stringify(x).length>9000)throw Error('Invalid Merkle inclusion schema/size');
  shapeHead(x.head);
  if(!Number.isSafeInteger(x.sequence)||x.sequence<0||x.sequence>=x.head.treeSize)throw Error('Invalid inclusion sequence');
  bytes(x.eventDigest);
  if(!Array.isArray(x.path)||x.path.length>10)throw Error('Invalid inclusion path');x.path.forEach(bytes);return x;
}
function shape(x){if(x?.schema===HEAD)return {kind:'merkle-head',artifact:shapeHead(x)};
  if(x?.schema===EXT)return {kind:'merkle-consistency',artifact:shapeExtension(x)};
  if(x?.schema===INCL)return {kind:'merkle-inclusion',artifact:shapeInclusion(x)};
  throw Error('Unsupported Merkle artifact');}
async function digestSigned(x){
  shapeHead(x);
  if(await T.keyId(x.subject.algorithm,x.subject.publicKey)!==x.subject.keyId)throw Error('Merkle signer fingerprint mismatch');
  const pub=await subtle().importKey('raw',T.unb64(x.subject.publicKey,x.subject.algorithm==='Ed25519'?32:65),importParams(x.subject.algorithm),false,['verify']);
  const statement={...x};delete statement.signature;
  const signed=utf8(Q.canonical({domain:DOMAIN,statement}));
  if(!await subtle().verify(signParams(x.subject.algorithm),pub,T.unb64(x.signature,64),signed))throw Error('INVALID MERKLE CHECKPOINT SIGNATURE');
  return true;
}
async function leafHash(keyId,seq,event){
  if(typeof keyId!=='string'||!/^(ed25519|ecdsa-p256-sha256):[0-9a-f]{64}$/.test(keyId))throw Error('Invalid Merkle leaf subject');
  if(!Number.isSafeInteger(seq)||seq<0||seq>=MAX)throw Error('Invalid Merkle leaf index');bytes(event);
  const payload=utf8(Q.canonical({subject:keyId,sequence:seq,eventDigest:event}));
  const encoded=new Uint8Array(1+payload.length);encoded.set(payload,1);
  return hash(encoded);
}
async function nodeHash(a,b){const l=bytes(a),r=bytes(b),data=new Uint8Array(65);data[0]=1;data.set(l,1);data.set(r,33);return hash(data);}
function cut(n){let k=1;while(k*2<n)k*=2;return k;}
async function rootOf(nodes){if(!nodes.length)return hash(new Uint8Array());if(nodes.length===1){bytes(nodes[0]);return nodes[0];}
  const k=cut(nodes.length);return nodeHash(await rootOf(nodes.slice(0,k)),await rootOf(nodes.slice(k)));}
async function leafHashes(subject,events){if(!Array.isArray(events)||!events.length||events.length>MAX)throw Error('Invalid Merkle event count');
  return Promise.all(events.map((event,i)=>leafHash(subject,i,event)));}
async function rootFromEvents(subject,events){return rootOf(await leafHashes(subject,events));}
async function pathInclusion(nodes,idx){if(nodes.length<1||idx<0||idx>=nodes.length)throw Error('Invalid inclusion index');
  if(nodes.length===1)return [];
  const k=cut(nodes.length);return idx<k?
    [...await pathInclusion(nodes.slice(0,k),idx),await rootOf(nodes.slice(k))]:
    [...await pathInclusion(nodes.slice(k),idx-k),await rootOf(nodes.slice(0,k))];}
async function proofConsistency(nodes,m){const n=nodes.length;if(!Number.isSafeInteger(m)||m<1||m>=n||n>MAX)throw Error('Invalid consistency sizes');
  async function sub(part,count,b){if(count===part.length)return b?[]:[await rootOf(part)];
    const k=cut(part.length);return count<=k?
      [...await sub(part.slice(0,k),count,b),await rootOf(part.slice(k))]:
      [...await sub(part.slice(k),count-k,false),await rootOf(part.slice(0,k))];}
  return sub(nodes,m,true);
}
async function checkInclusion(x){shapeInclusion(x);await digestSigned(x.head);
  let fn=x.sequence,sn=x.head.treeSize-1,r=await leafHash(x.head.subject.keyId,x.sequence,x.eventDigest);
  for(const p of x.path){if(sn===0)throw Error('EXTRA MERKLE INCLUSION NODE');
    if((fn%2)===1||fn===sn){r=await nodeHash(p,r);if(fn%2===0){while(fn!==0&&fn%2===0){fn=Math.floor(fn/2);sn=Math.floor(sn/2);}}}
    else r=await nodeHash(r,p);
    fn=Math.floor(fn/2);sn=Math.floor(sn/2);
  }
  if(sn!==0||r!==x.head.rootDigest)throw Error('INVALID MERKLE INCLUSION PROOF');
  return {kind:'merkle-inclusion',verified:true,subject:x.head.subject.keyId,treeSize:x.head.treeSize,sequence:x.sequence,eventDigest:x.eventDigest};
}
async function checkExtension(x){shapeExtension(x);await digestSigned(x.previous);await digestSigned(x.current);
  let fn=x.previous.treeSize-1,sn=x.current.treeSize-1;
  let path=x.path.slice();
  if((x.previous.treeSize&(x.previous.treeSize-1))===0)path=[x.previous.rootDigest,...path];
  while((fn%2)===1){fn=Math.floor(fn/2);sn=Math.floor(sn/2);}
  let fr=path[0],sr=path[0];
  for(const c of path.slice(1)){
    if(sn===0)throw Error('EXTRA MERKLE CONSISTENCY NODE');
    if(fn%2===1||fn===sn){fr=await nodeHash(c,fr);sr=await nodeHash(c,sr);
      if(fn%2===0){while(fn!==0&&fn%2===0){fn=Math.floor(fn/2);sn=Math.floor(sn/2);}}}
    else sr=await nodeHash(sr,c);
    fn=Math.floor(fn/2);sn=Math.floor(sn/2);
  }
  if(sn!==0||fr!==x.previous.rootDigest||sr!==x.current.rootDigest)throw Error('INVALID MERKLE CONSISTENCY PROOF');
  return {kind:'merkle-consistency',verified:true,subject:x.current.subject.keyId,first:x.previous.treeSize,second:x.current.treeSize,previousRoot:x.previous.rootDigest,currentRoot:x.current.rootDigest};
}
async function verify(x){const s=shape(x);if(s.kind==='merkle-head'){
    await digestSigned(x);return {kind:s.kind,verified:true,subject:x.subject.keyId,treeSize:x.treeSize,rootDigest:x.rootDigest,tipDigest:x.tipDigest};}
  return s.kind==='merkle-consistency'?checkExtension(x):checkInclusion(x);}
async function eventsFromState(state,subject,ownerSignedGenesis=null){
  const policy=(state.recoveryPolicies||[]).find(x=>x.subjectKeyId===subject);
  if(!policy){
    // Publishing your OWN first charter does not require pinning yourself as a subscriber.
    // The supplied charter must be verified, signed by the matching owner and never changes state.
    if(ownerSignedGenesis?.schema===H.CHARTER){
      const c=await H.verifyCharter(ownerSignedGenesis);
      if(ownerSignedGenesis.subject.keyId!==subject)throw Error('Owner-signed genesis subject mismatch');
      return [c.digest];
    }
    throw Error('No locally approved owner charter history (or matching owner-signed first charter)');
  }
  if(policy.status==='revoked'&&!(state.charterHistory||[]).some(x=>x.subjectKeyId===subject))throw Error('No locally approved owner charter history');
  const history=(state.charterHistory||[]).filter(x=>x.subjectKeyId===subject).sort((a,b)=>a.sequence-b.sequence);
  if(!history.length){const c=await H.verifyCharter(policy.charter);if(c.digest!==policy.digest||(policy.ledgerSequence||0)!==0||(policy.ledgerDigest||policy.digest)!==policy.digest)throw Error('Unverified genesis/pin mismatch');return [policy.digest];}
  if(history.length>MAX||history[0].action!=='pin')throw Error('Invalid genesis in approved charter history');
  let prior=null;
  for(let i=0;i<history.length;i++){
    const e=history[i];if(e.sequence!==i||e.subjectKeyId!==subject||e.priorDigest!==prior)throw Error('Non-contiguous local charter history');
    const v=i===0?await H.verifyCharter(e.statement):await J.verify(e.statement);
    if(v.digest!==e.digest||e.statement.subject.keyId!==subject)throw Error('Invalid signed local charter record');
    prior=e.digest;
  }
  if(policy.ledgerSequence!==history.length-1||policy.ledgerDigest!==prior)throw Error('Local pin does not match approved history');
  return history.map(e=>e.digest);
}
async function mint(identity,events,{issuedAt=new Date().toISOString()}={}){
  if(!identity?.privateKey||identity.privateKey.extractable)throw Error('Non-exportable signing key required');
  const subject=descriptor(identity);if(identity.keyId!==await T.keyId(identity.algorithm,identity.publicKey))throw Error('Local publisher key mismatch');
  const head={schema:HEAD,subject,treeSize:events.length,rootDigest:await rootFromEvents(identity.keyId,events),tipDigest:events[events.length-1],issuedAt,signature:T.b64url(new Uint8Array(64))};
  shapeHead(head);const statement={...head};delete statement.signature;
  head.signature=T.b64url(new Uint8Array(await subtle().sign(signParams(identity.algorithm),identity.privateKey,utf8(Q.canonical({domain:DOMAIN,statement})))));
  await verify(head);return head;
}
async function mintLocal(identity,state){if(!identity)throw Error('Generate a Trust Keys identity first');return mint(identity,await eventsFromState(state,identity.keyId));}
async function makeExtension(oldHead,newHead,events){await digestSigned(oldHead);await digestSigned(newHead);
  if(oldHead.subject.keyId!==newHead.subject.keyId||oldHead.treeSize>=newHead.treeSize||events.length!==newHead.treeSize)throw Error('Incompatible extension heads');
  const nodes=await leafHashes(oldHead.subject.keyId,events);
  if(oldHead.rootDigest!==await rootOf(nodes.slice(0,oldHead.treeSize))||newHead.rootDigest!==await rootOf(nodes))throw Error('Cannot prove missing/altered source history');
  const result={schema:EXT,previous:oldHead,current:newHead,path:await proofConsistency(nodes,oldHead.treeSize)};
  await verify(result);return result;
}
async function makeInclusion(head,events,sequence){await digestSigned(head);if(head.treeSize!==events.length)throw Error('Head does not match local log length');
  const nodes=await leafHashes(head.subject.keyId,events);if(await rootOf(nodes)!==head.rootDigest)throw Error('Head does not commit to these events');
  const result={schema:INCL,head,sequence,eventDigest:events[sequence],path:await pathInclusion(nodes,sequence)};
  await verify(result);return result;
}
function ensureState(s){if(!Array.isArray(s.merklePins))s.merklePins=[];if(!Array.isArray(s.merkleReceipts))s.merkleReceipts=[];return s;}
async function preview(state,artifact){ensureState(state);const checked=await verify(artifact),head=artifact.schema===EXT?artifact.current:artifact.schema===INCL?artifact.head:artifact;
  const pinned=state.merklePins.find(x=>x.subjectKeyId===head.subject.keyId);
  const relation=!pinned?'UNPINNED: compare publisher fingerprint out of band before pinning':
    head.treeSize===pinned.head.treeSize?(head.rootDigest===pinned.head.rootDigest?'MATCHES LOCAL PIN':'OWNER-SIGNED FORK AT SAME TREE SIZE'):
    head.treeSize<pinned.head.treeSize?'OLDER CHECKPOINT; cannot roll back':
    artifact.schema===EXT&&artifact.previous.treeSize===pinned.head.treeSize&&artifact.previous.rootDigest===pinned.head.rootDigest?'PROVEN APPEND-ONLY EXTENSION':'AHEAD WITHOUT PROOF LINKED TO YOUR PIN';
  return {...checked,head,pinned,relation,adoptable:!pinned?artifact.schema===HEAD:relation==='PROVEN APPEND-ONLY EXTENSION'};
}
async function adopt(state,artifact){const result=await preview(state,artifact);ensureState(state);
  if(!result.adoptable)throw Error('Cannot update checkpoint: '+result.relation);
  if(!result.pinned){if(state.merklePins.length>=32)throw Error('Merkle pin capacity reached');
    state.merklePins.push({subjectKeyId:result.head.subject.keyId,head:result.head,pinnedAt:new Date().toISOString()});return {...result,kind:'first-pin'};}
  if(state.merkleReceipts.length>=96)throw Error('Merkle proof receipt capacity reached');
  const record={subjectKeyId:result.head.subject.keyId,artifact,acceptedAt:new Date().toISOString()};
  state.merkleReceipts.push(record);result.pinned.head=result.head;result.pinned.pinnedAt=record.acceptedAt;
  return {...result,kind:'extension-approved'};
}
async function audit(state){ensureState(state);const failures=[],verified=[];
  for(const p of state.merklePins){try{await verify(p.head);if(p.subjectKeyId!==p.head.subject.keyId)throw Error('Pin subject mismatch');verified.push(p);}catch(e){failures.push('pin: '+e.message);}}
  for(const r of state.merkleReceipts){try{const p=await verify(r.artifact);if(p.kind!=='merkle-consistency'||p.subject!==r.subjectKeyId)throw Error('Receipt does not match signed extension');}catch(e){failures.push('receipt: '+e.message);}}
  return {pins:verified.length,receipts:state.merkleReceipts.length,failures,caveat:'Signed private checkpoints + local continuity proofs. No globally available log, clock or automatic trust transfer.'};
}
root.ProgRSSMerkle=Object.freeze({HEAD,EXT,INCL,DOMAIN,MAX,shape,verify,mint,mintLocal,eventsFromState,makeExtension,makeInclusion,
  leafHash,nodeHash,rootOf,leafHashes,pathInclusion,proofConsistency,checkExtension,checkInclusion,preview,adopt,ensureState,audit});
})(globalThis);
