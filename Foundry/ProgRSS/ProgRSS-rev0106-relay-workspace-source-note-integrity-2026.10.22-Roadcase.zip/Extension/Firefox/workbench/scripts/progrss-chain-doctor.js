/* ProgRSS rev0020 · Chain Doctor. Verified LOCAL suggestions; no network, writes or pin updates. */
(function(root){
'use strict';
const M=root.ProgRSSMerkle,E=root.ProgRSSProofExchange,Q=root.ProgRSSCourier;
const same=(a,b)=>Q.canonical(a)===Q.canonical(b);
async function inspect(state){
  // Read-only inspection: absent request/sighting fields are treated as empty, not inserted.
  const verifiedPins=new Map(),errors=[],observations=[];
  for(const row of (state.merklePins||[]).slice(0,32)){
    try{await M.verify(row.head);verifiedPins.set(row.head.subject.keyId,row.head)}catch(e){errors.push('Unverifiable local pin: '+String(e.message).slice(0,110));}
  }
  const heads=[...(state.proofSightings||[]).map(r=>r?.head).filter(Boolean)].slice(0,80);
  for(const seen of heads){
    try{await M.verify(seen);}catch(e){errors.push('Unverifiable signed head: '+String(e.message).slice(0,110));continue;}
    const pin=verifiedPins.get(seen.subject.keyId);
    if(!pin){observations.push({kind:'unfamiliar',head:seen,previous:null,rank:5,meaning:'No locally pinned checkpoint for this signer. Review the fingerprint independently.'});continue;}
    if(seen.treeSize===pin.treeSize&&seen.rootDigest===pin.rootDigest)continue;
    if(seen.treeSize===pin.treeSize){observations.push({kind:'fork',head:seen,previous:pin,rank:0,meaning:'OWNER-SIGNED SAME-SIZE ROOT CONFLICT. This is fork evidence; do not auto-choose a side.'});continue;}
    if(seen.treeSize<pin.treeSize){observations.push({kind:'stale',head:seen,previous:pin,rank:4,meaning:'Older signed checkpoint than your current pin. No proof requested.'});continue;}
    const waiting=(state.proofRequests||[]).some(r=>r.status==='pending'&&r.request?.previous&&r.request?.current&&same(r.request.previous,pin)&&same(r.request.current,seen));
    observations.push({kind:waiting?'waiting':'missing-proof',head:seen,previous:pin,rank:waiting?2:1,
      meaning:waiting?'An exact request for these signed endpoints is already pending.':'A consistency proof is required; only prepare a request on explicit approval.'});
  }
  const dedup=new Set();
  return {rows:observations.sort((a,b)=>a.rank-b.rank||a.head.subject.keyId.localeCompare(b.head.subject.keyId)||a.head.treeSize-b.head.treeSize)
    .filter(r=>{const k=r.kind+'|'+r.head.subject.keyId+'|'+r.head.treeSize+'|'+r.head.rootDigest;if(dedup.has(k))return false;dedup.add(k);return true;}).slice(0,40),errors:errors.slice(0,15),checked:heads.length,pins:verifiedPins.size};
}
async function prepare(state,row){
  if(row?.kind!=='missing-proof'||!row.previous||!row.head)throw Error('Only an unresolved larger signed checkpoint can request a proof');
  const inspected=await inspect(state);
  if(!inspected.rows.some(x=>x.kind==='missing-proof'&&same(x.previous,row.previous)&&same(x.head,row.head)))throw Error('Suggestion no longer matches current pinned history');
  const request=await E.makeRequest(row.previous,row.head);
  await E.stage(state,request); // changes only the bounded local pending-request queue
  return request;
}
root.ProgRSSChainDoctor=Object.freeze({inspect,prepare});
})(globalThis);
