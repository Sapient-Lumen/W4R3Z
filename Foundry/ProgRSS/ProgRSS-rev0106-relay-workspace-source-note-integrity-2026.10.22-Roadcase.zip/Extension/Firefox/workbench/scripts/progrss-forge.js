/* ProgRSS rev0009 / Selector Forge.
 * Suggests bounded CSS candidates from private offline HTML, then tests
 * each candidate against independent saved fixtures using the real extractor.
 * Everything remains local until a human deliberately stages a standard patch.
 * Candidate generation is heuristic, NOT a security parser or semantic proof.
 */
(function(root){
'use strict';
const C=root.ProgRSSCore;
const MAX_CANDIDATES=42, MAX_CASES=7, MAX_TOTAL_CHARS=520_000;
const TAGS=new Set(['main','article','section','li','div','ul','ol','table','tbody','tr','aside','p','dl','dt','dd','h2','h3']);
const NOISE=/^(?:active|selected|open|hidden|loading|empty|hover|focus|disabled|dark|light|error|success|sponsored|advert|ad|cookie|spinner|animate|transition|relative|timestamp|date|icon|btn|button|container|wrapper|root|app)$/i;
const validToken=s=>/^[A-Za-z_][\w-]{1,48}$/.test(s)&&!NOISE.test(s)&&!/(?:^\d|[0-9a-f]{14,}|\d{6,})/i.test(s);
function mustHtml(raw){if(typeof raw!=='string'||!raw.trim()||raw.length>C.LIMIT.fixtureChars)throw Error('Forge needs nonempty snapshots of at most 160K characters each');return C.staticHtml(raw);}
function extractSignals(raw){
  const map=new Map(),markup=mustHtml(raw);let matches=0;
  const add=key=>map.set(key,(map.get(key)||0)+1);
  const starts=/<([a-z][a-z0-9-]{0,25})\b([^<>]{0,450})>/gi;
  for(const match of markup.matchAll(starts)){
    if(++matches>1600)break;
    const tag=match[1].toLowerCase();if(!TAGS.has(tag))continue;
    const attrs=match[2], cls=attrs.match(/(?:^|\s)class\s*=\s*(?:"([^"]{1,240})"|'([^']{1,240})')/i);
    if(cls){let seen=new Set();for(const name of (cls[1]||cls[2]).split(/\s+/).slice(0,10)){
      if(!validToken(name)||seen.has(name))continue;seen.add(name);
      add('.'+name);add(tag+'.'+name);
    }}
    const ident=attrs.match(/(?:^|\s)id\s*=\s*(?:"([^"]{1,80})"|'([^']{1,80})')/i);
    if(ident&&validToken(ident[1]||ident[2])){add('#'+(ident[1]||ident[2]));}
    if(['article','section','main','li','tr','tbody'].includes(tag))add(tag);
  }
  return map;
}
function discover(before,after,mode,current=''){
  if(!['cards','region'].includes(mode))throw Error('Forge requires page region or cards mode');
  const a=extractSignals(before),b=extractSignals(after),candidates=new Map();
  const add=(s,priority=0)=>{if(s&&s.length<=350&&!candidates.has(s))candidates.set(s,priority)};
  if(typeof current==='string'&&current.trim())add(current.trim(),50);
  const union=new Set([...a.keys(),...b.keys()]);
  const ranked=[];
  for(const selector of union){
    const countA=a.get(selector)||0,countB=b.get(selector)||0;
    if(!countB)continue; // A repair must work on the newer snapshot
    const stable=countA&&countB,kind=selector[0]==='#'?'id':selector.includes('.')?'class':'tag';
    const adequate=mode==='cards'?countB>=2&&countA>=1:countB>=1;
    if(!adequate)continue;
    let prior=stable?32:2;
    prior+=kind==='class'?18:kind==='id'?10:-5;
    prior+=selector.includes('.')&&/^[a-z]+\./.test(selector)?3:0;
    prior-=Math.min(22,Math.abs(countA-countB)*3);
    prior-=Math.max(0,countB-25)*2;
    ranked.push({selector,priority:prior,countA,countB});
  }
  ranked.sort((x,y)=>y.priority-x.priority||x.selector.length-y.selector.length||x.selector.localeCompare(y.selector));
  for(const entry of ranked)if(candidates.size<MAX_CANDIDATES)add(entry.selector,entry.priority);
  return [...candidates].slice(0,MAX_CANDIDATES).map(([selector,prior])=>({selector,prior}));
}
function verdictPass(expected,outcome){return expected==='any'||expected===outcome||(expected==='changed'&&outcome!=='quiet');}
function assess(draft,cases,options={}){
  if(!draft||draft.type!=='page')throw Error('Select a webpage Lens before forging selectors');
  if(!Array.isArray(cases)||!cases.length)throw Error('Forge needs a current snapshot pair or saved regression specimens');
  if(cases.length>MAX_CASES)throw Error('Forge accepts at most '+MAX_CASES+' cases');
  let sum=0;
  const cleaned=cases.map((c,i)=>{
    if(!c||!['any','quiet','changed','added','removed','changed-card'].includes(c.expected))throw Error('Invalid Forge expectation');
    mustHtml(c.before);mustHtml(c.after);sum+=c.before.length+c.after.length;
    return {name:C.text(c.name||('Case '+(i+1)),85),before:c.before,after:c.after,expected:c.expected};
  });
  if(sum>MAX_TOTAL_CHARS)throw Error('Forge specimen budget exceeded (520K characters)');
  const current=C.cleanRecipe(draft);
  const base=cleaned[0];
  const possible=discover(base.before,base.after,current.mode,current.selector);
  // Fixture existence and expected results are checked locally, NOT transmitted.
  const rows=possible.map(({selector,prior})=>{
    const candidate=C.cleanRecipe({...current,selector});
    const tests=cleaned.map(c=>{
      try{
        const result=C.analyzePagePair(candidate,c.before,c.after),pass=verdictPass(c.expected,result.outcome);
        return {name:c.name,expected:c.expected,actual:result.outcome,pass};
      }catch(e){return {name:c.name,expected:c.expected,actual:'error',pass:false};}
    });
    const passed=tests.filter(t=>t.pass).length;
    // Only local verified tests can make a suggestion 'ready'. Coverage is
    // about these snapshots, never a prediction of future site stability.
    const score=passed*125-(tests.length-passed)*170+prior;
    return {selector,score,passed,total:tests.length,ready:passed===tests.length,
      isCurrent:selector===current.selector,tests};
  });
  rows.sort((a,b)=>Number(b.ready)-Number(a.ready)||b.score-a.score||a.selector.length-b.selector.length||a.selector.localeCompare(b.selector));
  return {schema:'progrss.forge.report.v1',target:current.id,mode:current.mode,
    caseCount:cleaned.length,considered:rows.length,readyCount:rows.filter(r=>r.ready).length,
    suggestions:rows.slice(0,12)};
}
root.ProgRSSForge=Object.freeze({discover,assess,extractSignals,MAX_CANDIDATES,MAX_CASES,MAX_TOTAL_CHARS});
})(globalThis);
