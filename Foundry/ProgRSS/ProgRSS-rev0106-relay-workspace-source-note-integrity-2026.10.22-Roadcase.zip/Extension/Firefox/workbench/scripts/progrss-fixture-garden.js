/* ProgRSS rev0021 · Fixture Garden / fictitious, declarative DOM scenes.
   No imports, selectors execute only through the existing local Arena extractor.
   A digest proves exact bytes, NOT authorship, safety, or a real-world site.
*/
(function(root){
'use strict';
const Q=root.ProgRSSCourier;
const SCHEMA='progrss.fixture-garden.v1';
const MAX_CASES=8,MAX_SIZE=76000,MAX_NODES=240;
const TAGS=new Set('main header footer nav section article div span h1 h2 h3 h4 p small strong em ul li a time'.split(' '));
const EXPECT=new Set(['quiet','added','removed','changed-card','changed','any']);
const ID=/^[a-zA-Z][a-zA-Z0-9_-]{0,47}$/;
const own=(x)=>x&&typeof x==='object'&&!Array.isArray(x)&&Object.getPrototypeOf(x)===Object.prototype;
const exact=(v,fields)=>{
  if(!own(v)||Object.keys(v).some(k=>!fields.includes(k)))throw Error('Unexpected fixture field');
};
const str=(x,max,field)=>{if(typeof x!=='string'||!x||x.length>max||/[\u0000-\u001f\u007f]/.test(x))throw Error('Invalid '+field);return x};
function scene(node,depth=0,counter={n:0}){
  if(depth>9||++counter.n>MAX_NODES)throw Error('Synthetic DOM exceeds depth/node budget');
  exact(node,['tag','id','classes','text','href','children']);
  if(!TAGS.has(node.tag))throw Error('Tag not allowed in synthetic fixture');
  const out={tag:node.tag};
  if(node.id!==undefined){if(typeof node.id!=='string'||!ID.test(node.id))throw Error('Unsafe fictional ID');out.id=node.id;}
  if(node.classes!==undefined){if(!Array.isArray(node.classes)||node.classes.length>6||node.classes.some(s=>typeof s!=='string'||!ID.test(s)))throw Error('Unsafe fictional class');out.classes=node.classes.slice();}
  if(node.text!==undefined)out.text=str(node.text,800,'fictional text');
  if(node.href!==undefined){if(node.tag!=='a'||typeof node.href!=='string'||!/^\/fictional\/[a-z0-9-]{1,48}$/.test(node.href))throw Error('Only invented relative /fictional/ links allowed');out.href=node.href;}
  if(node.children!==undefined){if(!Array.isArray(node.children)||node.children.length>60)throw Error('Too many child nodes');out.children=node.children.map(child=>scene(child,depth+1,counter));}
  return out;
}
function make(draft){
  exact(draft,['schema','title','hint','cases','digest']);
  if(draft.schema!==SCHEMA)throw Error('Unknown synthetic fixture schema');
  if(!Array.isArray(draft.cases)||!draft.cases.length||draft.cases.length>MAX_CASES)throw Error('Need 1–8 fictional cases');
  if(typeof draft.hint!=='string'||draft.hint.length>120||!/^[-_a-zA-Z0-9 .#>:+,*]*$/.test(draft.hint))throw Error('Invalid optional selector hint');
  const names=new Set(),out={schema:SCHEMA,title:str(draft.title,100,'pack title'),hint:draft.hint,cases:draft.cases.map(c=>{
    exact(c,['label','expected','holdout','before','after']);
    if(!EXPECT.has(c.expected)||typeof c.holdout!=='boolean')throw Error('Invalid scenario expectation or holdout');
    const label=str(c.label,90,'scenario label');
    if(names.has(label))throw Error('Duplicate scenario label');names.add(label);
    const counter={n:0};return {label,expected:c.expected,holdout:c.holdout,
      before:scene(c.before,0,counter),after:scene(c.after,0,counter)};
  })};
  const serialized=Q.canonical(out);
  if(new TextEncoder().encode(serialized).length>MAX_SIZE)throw Error('Fictional pack exceeds 76KB');
  return {...out,digest:'sha256:'+Q.sha256(serialized)};
}
function validate(raw){
  const normalized=make(raw);
  if(typeof raw.digest!=='string'||raw.digest!==normalized.digest)throw Error('Fixture pack checksum mismatch');
  if(Q.canonical(raw)!==Q.canonical(normalized))throw Error('Noncanonical synthetic fixture payload');
  return normalized;
}
function escape(x){return String(x).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
function markup(node){
  const attrs=(node.id?' id="'+escape(node.id)+'"':'')+(node.classes?.length?' class="'+node.classes.map(escape).join(' ')+'"':'')+(node.href?' href="'+escape(node.href)+'"':'');
  return '<'+node.tag+attrs+'>'+(node.text?escape(node.text):'')+(node.children||[]).map(markup).join('')+'</'+node.tag+'>';
}
function toCases(raw){const pack=validate(raw);return pack.cases.map(c=>({
  name:c.label,expected:c.expected,holdout:c.holdout,before:markup(c.before),after:markup(c.after)
}));}
function example(){
  const title=(text)=>({tag:'h2',text});
  const card=(name,body,slug)=>({tag:'article',classes:['project'],children:[title(name),{tag:'a',text:'Explore',href:'/fictional/'+slug},{tag:'p',text:body}]});
  const layout=(nav,cards)=>({tag:'main',classes:['board'],children:[{tag:'nav',text:nav},...cards]});
  const fern=card('Fern clock','A small fictional botanical clock.','fern'),
    moss=card('Moss compass','An invented tool for tiny explorations.','moss'),
    revised=card('Fern clock','An extensively redesigned imaginary botanical clock.','fern');
  return make({schema:SCHEMA,title:'Invented workshop board',hint:'.project',cases:[
    {label:'Navigation noise (quiet)',expected:'quiet',holdout:false,before:layout('Home and gallery',[fern]),after:layout('Entire navigation layout rewritten with imaginary advertisements and links',[fern])},
    {label:'New fictional card (added)',expected:'added',holdout:false,before:layout('Home',[fern]),after:layout('Home',[fern,moss])},
    {label:'Fictional card edited (holdout)',expected:'changed-card',holdout:true,before:layout('Home',[fern]),after:layout('Home',[revised])}
  ]});
}
root.ProgRSSFixtureGarden=Object.freeze({SCHEMA,MAX_CASES,MAX_SIZE,make,validate,markup,toCases,example});
})(globalThis);
