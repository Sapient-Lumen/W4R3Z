/* ProgRSS rev0011 · Trust Keys.
 * Cryptographic sender authentication for curator editions, not identity proof.
 * ECDSA signatures use WebCrypto IEEE-P1363 r||s; Ed25519 preferred.
 * Non-extractable private CryptoKey is stored in a distinct IndexedDB database.
 * No code execution, no remote requests, no recovery/export of secret keys.
 */
(function(root){
'use strict';
const Q=root.ProgRSSCourier,L=root.ProgRSSLineage;
const SCHEMA='progrss.signed-edition.v1', DOMAIN='ProgRSS/curator-edition/v1';
const ALG=['Ed25519','ECDSA-P256-SHA256'],DB='progrss-curator-keys',STORE='identities',ACTIVE='active',PENDING='pending';
const own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
const plain=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const enc=x=>new TextEncoder().encode(x);
const webcrypto=()=>{if(!root.crypto?.subtle)throw Error('Web Crypto unavailable: open ProgRSS on file://, HTTPS or localhost in a supported browser');return root.crypto.subtle};
function b64url(bytes){let b='';for(let i=0;i<bytes.length;i++)b+=String.fromCharCode(bytes[i]);return btoa(b).replace(/\+/g,'-').replace(/\//g,'_').replace(/=/g,'');}
function unb64(value,size){if(typeof value!=='string'||!/^[A-Za-z0-9_-]+$/.test(value)||value.length>180)throw Error('Invalid base64url key or signature');
  const chars=value.replace(/-/g,'+').replace(/_/g,'/');const raw=atob(chars+'='.repeat((4-chars.length%4)%4));const bytes=Uint8Array.from(raw,c=>c.charCodeAt(0));
  if(bytes.length!==size||b64url(bytes)!==value)throw Error('Noncanonical or wrong-length key/signature');return bytes;}
const params=algo=>algo==='Ed25519'?{name:'Ed25519'}:{name:'ECDSA',namedCurve:'P-256'};
const signParams=algo=>algo==='Ed25519'?{name:'Ed25519'}:{name:'ECDSA',hash:'SHA-256'};
const pubSize=algo=>algo==='Ed25519'?32:65;
async function keyId(algo,publicKey){
  if(!ALG.includes(algo))throw Error('Unsupported signing algorithm');
  const bytes=unb64(publicKey,pubSize(algo));if(algo!=='Ed25519'&&bytes[0]!==4)throw Error('Malformed uncompressed P-256 point');
  const hash=new Uint8Array(await webcrypto().digest('SHA-256',bytes));
  return algo.toLowerCase()+':'+Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('');
}
function signedContent(e,algorithm,publicKey){return enc(Q.canonical({domain:DOMAIN,edition:e,algorithm,publicKey}));}
function validateShape(raw){
  if(!plain(raw)||raw.schema!==SCHEMA||JSON.stringify(raw).length>Q.MAX_ENVELOPE-1500)throw Error('Invalid or oversized signed edition');
  const keys=['schema','edition','algorithm','publicKey','keyId','signature'];
  if(Object.keys(raw).length!==keys.length||Object.keys(raw).some(k=>!keys.includes(k)))throw Error('Unexpected signed edition fields');
  if(!ALG.includes(raw.algorithm))throw Error('Unsupported signer algorithm');
  const edition=L.validate(raw.edition);
  unb64(raw.publicKey,pubSize(raw.algorithm));unb64(raw.signature,64);
  if(raw.algorithm==='ECDSA-P256-SHA256'&&unb64(raw.publicKey,65)[0]!==4)throw Error('Malformed P-256 key');
  if(typeof raw.keyId!=='string'||!new RegExp('^'+raw.algorithm.toLowerCase()+':[a-f0-9]{64}$').test(raw.keyId))throw Error('Bad signer fingerprint');
  if(Q.canonical(raw.edition)!==Q.canonical(edition))throw Error('Signer payload normalization mismatch');
  return {schema:SCHEMA,edition,algorithm:raw.algorithm,publicKey:raw.publicKey,keyId:raw.keyId,signature:raw.signature};
}
async function verify(raw){
  const signed=validateShape(raw);
  if(await keyId(signed.algorithm,signed.publicKey)!==signed.keyId)throw Error('Signer fingerprint does not match public key');
  let publicKey;try{publicKey=await webcrypto().importKey('raw',unb64(signed.publicKey,pubSize(signed.algorithm)),params(signed.algorithm),false,['verify']);}
  catch(e){throw Error('Unable to import curator public key: '+e.message)}
  let valid=false;try{valid=await webcrypto().verify(signParams(signed.algorithm),publicKey,unb64(signed.signature,64),signedContent(signed.edition,signed.algorithm,signed.publicKey));}
  catch(e){throw Error('Signature verification unavailable: '+e.message)}
  if(!valid)throw Error('INVALID SIGNATURE: curator edition was not signed by this key');
  return {edition:signed.edition,keyId:signed.keyId,algorithm:signed.algorithm,verified:true};
}
function guard(state,edition,identity=null){
  const sub=(state.subscriptions||[]).find(x=>x.channel===edition.channel);
  if(sub?.publisherKeyId){
    if(!identity?.verified)throw Error('DOWNGRADE BLOCKED: pinned curator requires a valid signature');
    if(sub.publisherKeyId!==identity.keyId)throw Error('KEY CHANGE BLOCKED: pinned curator fingerprint differs; no automatic rotation');
  }
  return {status:identity?.verified?(sub?.publisherKeyId?'MATCHED PIN':'FIRST VERIFIED KEY / PIN ON APPROVAL'):(sub?'UNSIGNED LEGACY / NOT AUTHENTICATED':'UNSIGNED / NOT AUTHENTICATED'),keyId:identity?.keyId||''};
}
function pin(state,channel,identity){
  if(!identity?.verified||!identity.keyId)throw Error('Only verified publisher keys may be pinned');
  const sub=(state.subscriptions||[]).find(x=>x.channel===channel);
  if(!sub)throw Error('No local subscription to pin');
  if(sub.publisherKeyId&&sub.publisherKeyId!==identity.keyId)throw Error('Pinned curator key cannot change');
  sub.publisherKeyId=identity.keyId;sub.publisherAlgorithm=identity.algorithm;
  return sub;
}
function openDB(){return new Promise((resolve,reject)=>{
  if(!root.indexedDB)return reject(Error('IndexedDB unavailable; signed publishing needs origin-persistent key storage'));
  const req=root.indexedDB.open(DB,1);
  req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains(STORE))req.result.createObjectStore(STORE)};
  req.onerror=()=>reject(req.error||Error('Signing-key vault unavailable'));
  req.onblocked=()=>reject(Error('Signing-key vault blocked by another tab'));
  req.onsuccess=()=>resolve(req.result);
});}
async function withDB(mode,fn){const db=await openDB();try{return await new Promise((resolve,reject)=>{
  let result,tx;try{tx=db.transaction(STORE,mode);result=fn(tx.objectStore(STORE));}catch(e){reject(e);return}
  tx.oncomplete=()=>resolve(result?.result);
  tx.onerror=()=>reject(tx.error||Error('Signing-key transaction failed'));
  tx.onabort=()=>reject(tx.error||Error('Signing-key transaction aborted'));
});}finally{db.close();}}
async function getIdentity(){const identity=await withDB('readonly',store=>store.get(ACTIVE));if(!identity)return null;
  if(!identity.privateKey||!identity.publicKey||identity.privateKey.extractable)throw Error('Local signing identity is corrupted or unexpectedly extractable');
  if(identity.keyId!==await keyId(identity.algorithm,identity.publicKey))throw Error('Local signing fingerprint mismatch');return identity;}
async function createIdentity(){
  if(await getIdentity())throw Error('An identity already exists. Refusing to overwrite its private key');
  let pair,algorithm='Ed25519';
  try{pair=await webcrypto().generateKey({name:'Ed25519'},false,['sign','verify']);}
  catch {algorithm='ECDSA-P256-SHA256';pair=await webcrypto().generateKey({name:'ECDSA',namedCurve:'P-256'},false,['sign','verify']);}
  if(pair.privateKey.extractable)throw Error('Signing key unexpectedly extractable');
  const publicKey=b64url(new Uint8Array(await webcrypto().exportKey('raw',pair.publicKey)));
  const record={algorithm,publicKey,keyId:await keyId(algorithm,publicKey),privateKey:pair.privateKey,createdAt:new Date().toISOString()};
  // Check again to reduce accidental replacement between multiple app windows.
  await withDB('readwrite',store=>{const request=store.add(record,ACTIVE);return request;});
  return {algorithm:record.algorithm,publicKey:record.publicKey,keyId:record.keyId,createdAt:record.createdAt};
}
async function signEdition(edition,identity){const validated=L.validate(edition),who=identity||await getIdentity();if(!who)throw Error('No signing identity: generate a local signing key first');
  const signature=b64url(new Uint8Array(await webcrypto().sign(signParams(who.algorithm),who.privateKey,signedContent(validated,who.algorithm,who.publicKey))));
  const payload=validateShape({schema:SCHEMA,edition:validated,algorithm:who.algorithm,publicKey:who.publicKey,keyId:who.keyId,signature});
  await verify(payload);return payload;
}
// rev0013 · pending replacement key stays in the same protected-origin vault.
// A pending key NEVER replaces the active identity until the user has exported
// a jointly signed certificate and explicitly activates it.
async function getPendingIdentity(){
  const identity=await withDB('readonly',store=>store.get(PENDING));
  if(!identity)return null;
  if(!identity.privateKey||identity.privateKey.extractable||!identity.publicKey)throw Error('Pending rotation key is corrupted');
  if(identity.keyId!==await keyId(identity.algorithm,identity.publicKey))throw Error('Pending key fingerprint mismatch');
  return identity;
}
async function createPendingIdentity(){
  const active=await getIdentity();if(!active)throw Error('Create an active signing identity before rotation');
  if(await getPendingIdentity())throw Error('A replacement key is already staged; export that certificate first');
  let pair,algorithm='Ed25519';
  try{pair=await webcrypto().generateKey({name:'Ed25519'},false,['sign','verify']);}
  catch{algorithm='ECDSA-P256-SHA256';pair=await webcrypto().generateKey({name:'ECDSA',namedCurve:'P-256'},false,['sign','verify']);}
  if(pair.privateKey.extractable)throw Error('Rotation key unexpectedly extractable');
  const publicKey=b64url(new Uint8Array(await webcrypto().exportKey('raw',pair.publicKey)));
  const next={algorithm,publicKey,keyId:await keyId(algorithm,publicKey),privateKey:pair.privateKey,createdAt:new Date().toISOString()};
  await withDB('readwrite',store=>store.add(next,PENDING));
  return next;
}
async function activatePendingIdentity(fromId,toId){
  const active=await getIdentity(),pending=await getPendingIdentity();
  if(!active||!pending||active.keyId!==fromId||pending.keyId!==toId||fromId===toId)throw Error('Staged identity does not match the reviewed rotation');
  const db=await openDB();
  try{await new Promise((resolve,reject)=>{
    const tx=db.transaction(STORE,'readwrite'),store=tx.objectStore(STORE);
    let original,next,valid=false;
    const a=store.get(ACTIVE),b=store.get(PENDING);
    a.onsuccess=()=>{original=a.result};b.onsuccess=()=>{next=b.result};
    b.onerror=()=>{try{tx.abort()}catch{}};
    a.onerror=()=>{try{tx.abort()}catch{}};
    // Both get operations have completed before the queued get at key 'pending'
    // fires; the transaction ensures competing tabs cannot switch keys between
    // the read and write.
    b.onsuccess=()=>{next=b.result;
      if(original?.keyId!==fromId||next?.keyId!==toId||original.privateKey?.extractable||next.privateKey?.extractable){tx.abort();return;}
      valid=true;store.put(next,ACTIVE);store.delete(PENDING);
    };
    tx.oncomplete=()=>valid?resolve():reject(Error('Activation transaction did not verify keys'));
    tx.onabort=()=>reject(Error('Staged signing key changed during activation'));
    tx.onerror=()=>reject(tx.error||Error('Signing-key rotation transaction failed'));
  });}finally{db.close();}
  return {from:fromId,to:toId};
}
root.ProgRSSTrust=Object.freeze({SCHEMA,DOMAIN,ALG,b64url,unb64,keyId,validateShape,verify,guard,pin,createIdentity,getIdentity,getPendingIdentity,createPendingIdentity,activatePendingIdentity,signEdition});
})(globalThis);
