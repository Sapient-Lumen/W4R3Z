/* ProgRSS rev0015 · Trust Ledger / signed charter amendment, revocation and local fork evidence.
 * This is NOT a globally consistent transparency log: it is a local hash-linked audit trail.
 * Signed conflicting claims are detectable only when independently observed and compared.
 * No remote fetching, automatic trust changes, shared raw observations or escrow.
 */
(function(root){
'use strict';
const H=root.ProgRSSRecovery,T=root.ProgRSSTrust,Q=root.ProgRSSCourier;
const SCHEMA='progrss.charter-change.v1',DOMAIN='ProgRSS/recovery-charter-change/v1';
const KEYS=['schema','subject','priorDigest','sequence','action','nextCharter','issuedAt','note','signature'];
const DIGEST=/^sha256:[0-9a-f]{64}$/;
const time=()=>new Date().toISOString();
const digest=obj=>'sha256:'+Q.sha256(Q.canonical(obj));
const parameters=algorithm=>algorithm==='Ed25519'?{name:'Ed25519'}:{name:'ECDSA',hash:'SHA-256'};
const keyParams=algorithm=>algorithm==='Ed25519'?{name:'Ed25519'}:{name:'ECDSA',namedCurve:'P-256'};
const descriptor=k=>({algorithm:k.algorithm,publicKey:k.publicKey,keyId:k.keyId});
const withoutSignature=e=>{const s={...e};delete s.signature;return s;};
const bytes=e=>new TextEncoder().encode(Q.canonical({domain:DOMAIN,statement:withoutSignature(e)}));
function validateShape(e){
  if(!e||typeof e!=='object'||Array.isArray(e)||Object.keys(e).length!==KEYS.length||KEYS.some(k=>!Object.hasOwn(e,k)))throw Error('Invalid charter-change fields');
  if(e.schema!==SCHEMA||JSON.stringify(e).length>12000)throw Error('Unsupported/oversized charter-change claim');
  H.checkKey(e.subject);
  if(typeof e.priorDigest!=='string'||!DIGEST.test(e.priorDigest))throw Error('Invalid predecessor hash');
  if(!Number.isSafeInteger(e.sequence)||e.sequence<1||e.sequence>64)throw Error('Invalid charter-change sequence');
  if(!['revoke','replace'].includes(e.action))throw Error('Invalid charter-change action');
  if(e.action==='revoke'&&e.nextCharter!==null)throw Error('Revocation cannot include a replacement charter');
  if(e.action==='replace'){
    H.validateCharter(e.nextCharter);
    if(Q.canonical(e.nextCharter.subject)!==Q.canonical(e.subject))throw Error('New charter owner does not match previously trusted owner');
  }
  if(!/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(e.issuedAt)||!Number.isFinite(Date.parse(e.issuedAt))||new Date(e.issuedAt).toISOString()!==e.issuedAt)throw Error('Invalid claim timestamp');
  if(typeof e.note!=='string'||e.note.length>240||/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(e.note))throw Error('Invalid claim note');
  T.unb64(e.signature,64);return e;
}
async function verify(e){
  validateShape(e);
  const who=e.subject;
  if(await T.keyId(who.algorithm,who.publicKey)!==who.keyId)throw Error('Charter-change fingerprint mismatch');
  if(!root.crypto?.subtle)throw Error('Charter-change verification requires secure Web Crypto');
  const pub=await root.crypto.subtle.importKey('raw',T.unb64(who.publicKey,who.algorithm==='Ed25519'?32:65),keyParams(who.algorithm),false,['verify']);
  if(!await root.crypto.subtle.verify(parameters(who.algorithm),pub,T.unb64(e.signature,64),bytes(e)))throw Error('INVALID CHARTER-CHANGE SIGNATURE');
  if(e.nextCharter)await H.verifyCharter(e.nextCharter);
  return {event:e,digest:digest(e)};
}
function head(state,subject){
  const policy=(state.recoveryPolicies||[]).find(p=>p.subjectKeyId===subject);
  if(!policy)return null;
  return {policy,priorDigest:policy.ledgerDigest||policy.digest,sequence:(policy.ledgerSequence||0)+1,revoked:policy.status==='revoked'};
}
async function make(identity,{priorDigest,sequence,action,nextCharter=null,note=''}={}){
  if(!identity?.privateKey||identity.privateKey.extractable)throw Error('Non-exportable current signing key required');
  const claim={schema:SCHEMA,subject:descriptor(identity),priorDigest,sequence,action,nextCharter,issuedAt:time(),note:String(note),signature:''};
  // The shape validator expects the signature before signing; validate the rest with a fixed placeholder.
  validateShape({...claim,signature:T.b64url(new Uint8Array(64))});
  if(identity.keyId!==await T.keyId(identity.algorithm,identity.publicKey))throw Error('Local signing key fingerprint mismatch');
  claim.signature=T.b64url(new Uint8Array(await root.crypto.subtle.sign(parameters(identity.algorithm),identity.privateKey,bytes(claim))));
  await verify(claim);return claim;
}
function sameFork(a,b){return a.subjectKeyId===b.subjectKeyId&&a.priorDigest===b.priorDigest&&a.sequence===b.sequence&&a.digest!==b.digest;}
async function observe(state,raw){
  const checked=await verify(raw),claim={subjectKeyId:raw.subject.keyId,priorDigest:raw.priorDigest,sequence:raw.sequence,digest:checked.digest,statement:raw,seenAt:time()};
  const entries=state.charterClaims||[];
  if(entries.some(x=>x.digest===claim.digest))return {duplicate:true,conflicts:entries.filter(x=>sameFork(claim,x)),claim};
  if(entries.length>=128)throw Error('Charter claim journal full: export a private backup before further review');
  state.charterClaims=[...entries,claim];
  return {duplicate:false,conflicts:entries.filter(x=>sameFork(claim,x)),claim};
}
async function preview(state,raw){
  const checked=await verify(raw),h=head(state,raw.subject.keyId);
  if(!h)throw Error('No pre-pinned charter for this owner; incoming signature cannot bootstrap trust');
  if(Q.canonical(h.policy.charter.subject)!==Q.canonical(raw.subject))throw Error('Owner signing descriptor differs from originally pinned key');
  if(raw.action==='replace'&&Date.now()>Date.parse(raw.nextCharter.expiresAt))throw Error('Replacement charter already expired');
  if(h.priorDigest!==raw.priorDigest||h.sequence!==raw.sequence)throw Error('STALE OR FORKED charter update: does not follow the locally pinned head');
  if((state.charterHistory||[]).some(x=>x.digest===checked.digest))throw Error('Charter update already applied');
  const conflicts=(state.charterClaims||[]).filter(x=>sameFork({subjectKeyId:raw.subject.keyId,priorDigest:raw.priorDigest,sequence:raw.sequence,digest:checked.digest},x));
  return {...checked,head:h,conflicts,scopeBefore:h.policy.charter.scope,scopeAfter:raw.nextCharter?.scope||'revoked',guardianCountBefore:h.policy.charter.guardians.length,guardianCountAfter:raw.nextCharter?.guardians.length||0};
}
async function approve(state,raw){
  const p=await preview(state,raw);
  if(p.conflicts.length)throw Error('SIGNED FORK DETECTED: conflicting owner claims; review evidence outside ProgRSS before any change');
  await observe(state,raw);
  const history=state.charterHistory||[];
  const genesis=history.some(x=>x.subjectKeyId===raw.subject.keyId)?[]:[{
    subjectKeyId:raw.subject.keyId,sequence:0,priorDigest:null,digest:p.head.policy.digest,action:'pin',statement:p.head.policy.charter,committedAt:p.head.policy.registeredAt}];
  if(history.length+genesis.length+1>160)throw Error('Charter audit history full; refusing to truncate signed events');
  // Recheck after asynchronous crypto to reject races with another approval.
  const nowHead=head(state,raw.subject.keyId);
  if(!nowHead||nowHead.priorDigest!==p.head.priorDigest||nowHead.sequence!==raw.sequence)throw Error('Charter head changed during review');
  const old=nowHead.policy;
  const updated={...old,digest:raw.action==='replace'?H.digest(raw.nextCharter):old.digest,
    charter:raw.action==='replace'?raw.nextCharter:old.charter,
    status:raw.action==='replace'?'active':'revoked',ledgerSequence:raw.sequence,ledgerDigest:p.digest};
  state.recoveryPolicies=(state.recoveryPolicies||[]).map(x=>x===old?updated:x);
  state.charterHistory=[...history,...genesis,{subjectKeyId:raw.subject.keyId,sequence:raw.sequence,priorDigest:raw.priorDigest,digest:p.digest,action:raw.action,statement:raw,committedAt:time()}];
  return {...p,record:updated};
}
async function audit(state){
  const hist=state.charterHistory||[], groups=new Map(),failures=[];
  for(const x of hist){let a=groups.get(x.subjectKeyId)||[];a.push(x);groups.set(x.subjectKeyId,a)}
  for(const [subject,entries] of groups){
    let prev=null,seq=-1;
    for(const entry of entries){
      try{
        if(entry.sequence!==seq+1||entry.priorDigest!==prev)throw Error('Broken sequence/parent');
        if(entry.action==='pin'){
          const c=await H.verifyCharter(entry.statement);
          if(c.digest!==entry.digest||entry.statement.subject.keyId!==subject)throw Error('Pin digest mismatch');
        }else{
          const c=await verify(entry.statement);
          if(c.digest!==entry.digest||entry.statement.subject.keyId!==subject)throw Error('Claim digest mismatch');
        }
        prev=entry.digest;seq=entry.sequence;
      }catch(error){failures.push({subject,sequence:entry.sequence,error:String(error.message||error)})}
    }
    const policy=(state.recoveryPolicies||[]).find(x=>x.subjectKeyId===subject);
    if(policy&&(policy.ledgerDigest||policy.digest)!==prev)failures.push({subject,error:'Pinned head differs from accepted history'});
  }
  for(const claim of state.charterClaims||[]){try{const verified=await verify(claim.statement);if(verified.digest!==claim.digest||claim.subjectKeyId!==claim.statement.subject.keyId)throw Error('Claim digest/identity mismatch');}catch(error){failures.push({subject:claim.subjectKeyId,error:'Observed claim: '+String(error.message||error)})}}
  const forks=[];for(let i=0;i<(state.charterClaims||[]).length;i++)for(let j=i+1;j<(state.charterClaims||[]).length;j++)if(sameFork(state.charterClaims[i],state.charterClaims[j]))forks.push({subject:state.charterClaims[i].subjectKeyId,sequence:state.charterClaims[i].sequence,first:state.charterClaims[i].digest,second:state.charterClaims[j].digest});
  return {checked:hist.length,heads:groups.size,failures,forks};
}
root.ProgRSSLedger=Object.freeze({SCHEMA,DOMAIN,validateShape,verify,head,make,observe,preview,approve,audit,digest});
})(globalThis);
