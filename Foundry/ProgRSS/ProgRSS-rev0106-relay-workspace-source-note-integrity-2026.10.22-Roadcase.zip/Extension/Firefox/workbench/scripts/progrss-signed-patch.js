/* ProgRSS rev0012 · Signed Patch Workshop
 * Reuses the non-exportable rev0011 signing key, but a distinct signature domain.
 * Signing authenticates a *key*, not the author's self-described name, website,
 * extraction accuracy, or right to modify the target website.
 * Incoming patches are NEVER executed, fetched, or applied automatically.
 */
(function(root){
'use strict';
const C=root.ProgRSSCore,Q=root.ProgRSSCourier,T=root.ProgRSSTrust;
const SCHEMA='progrss.signed-patch.v1', DOMAIN='ProgRSS/selector-patch/v1';
const MAX_PINS=96, MAX_KEYS_PER_URL=8;
const ALGORITHMS=['Ed25519','ECDSA-P256-SHA256'];
const plain=o=>o!==null&&typeof o==='object'&&!Array.isArray(o);
const enc=str=>new TextEncoder().encode(str);
const cryptoAPI=()=>{if(!root.crypto?.subtle)throw Error('Web Crypto unavailable. Use HTTPS, localhost, or a supporting file:// browser.');return root.crypto.subtle};
const params=algo=>algo==='Ed25519'?{name:'Ed25519'}:{name:'ECDSA',namedCurve:'P-256'};
const signParams=algo=>algo==='Ed25519'?{name:'Ed25519'}:{name:'ECDSA',hash:'SHA-256'};
function signedBytes(patch,algorithm,publicKey){return enc(Q.canonical({domain:DOMAIN,patch,algorithm,publicKey}));}
function validateShape(raw){
  if(!plain(raw)||raw.schema!==SCHEMA||JSON.stringify(raw).length>22000)throw Error('Invalid or oversized signed patch');
  const fields=['schema','patch','algorithm','publicKey','keyId','signature'];
  if(Object.keys(raw).length!==fields.length||fields.some(k=>!Object.prototype.hasOwnProperty.call(raw,k)))throw Error('Unexpected or missing signed-patch field');
  if(!ALGORITHMS.includes(raw.algorithm))throw Error('Unsupported signing algorithm');
  const patch=C.validateProposal(raw.patch);
  if(Q.canonical(patch)!==Q.canonical(raw.patch))throw Error('Unexpected or unnormalized patch data');
  const size=raw.algorithm==='Ed25519'?32:65,publicBytes=T.unb64(raw.publicKey,size);
  if(size===65&&publicBytes[0]!==4)throw Error('Malformed uncompressed P-256 public key');
  T.unb64(raw.signature,64);
  if(typeof raw.keyId!=='string'||!new RegExp('^'+raw.algorithm.toLowerCase()+':[a-f0-9]{64}$').test(raw.keyId))throw Error('Malformed signer fingerprint');
  return {schema:SCHEMA,patch,algorithm:raw.algorithm,publicKey:raw.publicKey,keyId:raw.keyId,signature:raw.signature};
}
async function verify(input){
  const packet=validateShape(input);
  if(await T.keyId(packet.algorithm,packet.publicKey)!==packet.keyId)throw Error('Signer fingerprint does not match public key');
  const bytes=T.unb64(packet.publicKey,packet.algorithm==='Ed25519'?32:65);
  let key;try{key=await cryptoAPI().importKey('raw',bytes,params(packet.algorithm),false,['verify']);}
  catch(err){throw Error('Cannot import patch signer public key: '+err.message)}
  let valid=false;try{valid=await cryptoAPI().verify(signParams(packet.algorithm),key,T.unb64(packet.signature,64),signedBytes(packet.patch,packet.algorithm,packet.publicKey));}
  catch(err){throw Error('Patch signature cannot be verified: '+err.message)}
  if(!valid)throw Error('INVALID SIGNATURE: patch differs from signed content or key');
  return {verified:true,algorithm:packet.algorithm,keyId:packet.keyId,patch:packet.patch};
}
async function sign(patch,identity){
  const clean=C.validateProposal(patch),who=identity||await T.getIdentity();
  if(!who||!who.privateKey||!who.publicKey||!who.keyId)throw Error('Create a local Trust Keys identity in Lineage Room first');
  if(!ALGORITHMS.includes(who.algorithm))throw Error('Unsupported local key algorithm');
  if(who.privateKey.extractable)throw Error('Signing key unexpectedly extractable');
  if(await T.keyId(who.algorithm,who.publicKey)!==who.keyId)throw Error('Local signing key fingerprint mismatch');
  const signature=T.b64url(new Uint8Array(await cryptoAPI().sign(signParams(who.algorithm),who.privateKey,signedBytes(clean,who.algorithm,who.publicKey))));
  const signed=validateShape({schema:SCHEMA,patch:clean,algorithm:who.algorithm,publicKey:who.publicKey,keyId:who.keyId,signature});
  await verify(signed);return signed;
}
function normalizePins(state){
  // Private backup and local storage are still untrusted input. Reject malformed
  // pin records rather than treating a forged fingerprint as trusted.
  if(!Array.isArray(state.patchPins))state.patchPins=[];
  const clean=[],seen=new Set(),counts=new Map();
  for(const p of state.patchPins.slice(0,MAX_PINS))try{
    if(!plain(p)||Object.keys(p).some(k=>!['url','keyId','algorithm','addedAt'].includes(k)))continue;
    const url=C.safeUrl(p.url);
    if(url!==p.url||!ALGORITHMS.includes(p.algorithm)||typeof p.keyId!=='string'||
       !new RegExp('^'+p.algorithm.toLowerCase()+':[a-f0-9]{64}$').test(p.keyId)||
       typeof p.addedAt!=='string'||p.addedAt.length>40||!Number.isFinite(Date.parse(p.addedAt)))continue;
    const k=url+'|'+p.keyId;
    if(seen.has(k)||(counts.get(url)||0)>=MAX_KEYS_PER_URL)continue;
    seen.add(k);counts.set(url,(counts.get(url)||0)+1);
    clean.push({url,keyId:p.keyId,algorithm:p.algorithm,addedAt:p.addedAt});
  }catch{}
  state.patchPins=clean;return clean;
}
function pinsFor(state,url){const target=C.safeUrl(url);return normalizePins(state).filter(p=>p.url===target);}
function guard(state,url,identity=null,{incoming=true}={}){
  const target=C.safeUrl(url),existing=pinsFor(state,target);
  if(!incoming)return {status:'LOCAL DRAFT / NOT REMOTE',known:false,existing:existing.length};
  if(!identity?.verified){
    if(existing.length)throw Error('UNSIGNED DOWNGRADE BLOCKED: watched URL has trusted patch contributors');
    return {status:'UNSIGNED EXTERNAL PATCH / NEVER AUTHENTICATED',known:false,existing:0};
  }
  if(!ALGORITHMS.includes(identity.algorithm)||typeof identity.keyId!=='string')throw Error('Invalid signature identity');
  const known=existing.some(p=>p.keyId===identity.keyId&&p.algorithm===identity.algorithm);
  return {status:known?'MATCHED CONTRIBUTOR PIN':existing.length?'NEW CONTRIBUTOR KEY — VERIFY OUT OF BAND':'FIRST VERIFIED CONTRIBUTOR — VERIFY OUT OF BAND',known,existing:existing.length};
}
function pin(state,url,identity){
  if(!identity?.verified||!ALGORITHMS.includes(identity.algorithm)||typeof identity.keyId!=='string')throw Error('Cannot pin an unverified contributor');
  if(!new RegExp('^'+identity.algorithm.toLowerCase()+':[a-f0-9]{64}$').test(identity.keyId))throw Error('Invalid contributor key ID');
  const target=C.safeUrl(url),existing=pinsFor(state,target);
  const match=existing.find(p=>p.keyId===identity.keyId);
  if(match){if(match.algorithm!==identity.algorithm)throw Error('Algorithm for an existing key pin changed');return {existing:true,pin:match};}
  if(existing.length>=MAX_KEYS_PER_URL||state.patchPins.length>=MAX_PINS)throw Error('Trusted patch-contributor pin limit reached');
  const record={url:target,keyId:identity.keyId,algorithm:identity.algorithm,addedAt:new Date().toISOString()};
  state.patchPins.push(record);return {existing:false,pin:record};
}
function unpin(state,url,keyId){const target=C.safeUrl(url),pins=normalizePins(state),before=pins.length;
  state.patchPins=pins.filter(p=>p.url!==target||p.keyId!==keyId);return state.patchPins.length!==before;}
root.ProgRSSSignedPatch=Object.freeze({SCHEMA,DOMAIN,MAX_PINS,MAX_KEYS_PER_URL,signedBytes,validateShape,sign,verify,normalizePins,pinsFor,guard,pin,unpin});
})(globalThis);
