/* ProgRSS rev0013 · Key Bridge / jointly authorized key rotation.
 * The old AND new private keys sign one domain-separated, byte-identical
 * statement. Receivers check current exact-key pins and approve explicitly.
 * This deliberately is NOT lost-key recovery; no secret keys travel on the wire.
 */
(function(root){
'use strict';
const T=root.ProgRSSTrust,Q=root.ProgRSSCourier;
const SCHEMA='progrss.key-rotation.v1',DOMAIN='ProgRSS/key-rotation/v1';
const ALGORITHMS=['Ed25519','ECDSA-P256-SHA256'];
const plain=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
const sameKeys=(v,keys)=>plain(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.prototype.hasOwnProperty.call(v,k));
const signParams=a=>a==='Ed25519'?{name:'Ed25519'}:{name:'ECDSA',hash:'SHA-256'};
const importParams=a=>a==='Ed25519'?{name:'Ed25519'}:{name:'ECDSA',namedCurve:'P-256'};
const subtle=()=>{if(!root.crypto?.subtle)throw Error('Web Crypto is unavailable for key rotation; use a secure context');return root.crypto.subtle};
const ident=x=>({algorithm:x.algorithm,publicKey:x.publicKey,keyId:x.keyId});
function checkKey(x){
  if(!sameKeys(x,['algorithm','publicKey','keyId'])||!ALGORITHMS.includes(x.algorithm))throw Error('Invalid rotation key descriptor');
  const bytes=T.unb64(x.publicKey,x.algorithm==='Ed25519'?32:65);
  if(x.algorithm!=='Ed25519'&&bytes[0]!==4)throw Error('Invalid P-256 public point');
  if(typeof x.keyId!=='string'||!new RegExp('^'+x.algorithm.toLowerCase()+':[a-f0-9]{64}$').test(x.keyId))throw Error('Malformed rotation key fingerprint');
  return ident(x);
}
function validateShape(input){
  const keys=['schema','from','to','issuedAt','note','nonce','oldSignature','newSignature'];
  if(!sameKeys(input,keys)||input.schema!==SCHEMA||JSON.stringify(input).length>6000)throw Error('Invalid or oversized key rotation certificate');
  const from=checkKey(input.from),to=checkKey(input.to);
  if(from.keyId===to.keyId)throw Error('Rotation cannot replace a key with itself');
  if(typeof input.issuedAt!=='string'||!/^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,3})?Z$/.test(input.issuedAt)||!Number.isFinite(Date.parse(input.issuedAt)))throw Error('Invalid rotation timestamp');
  if(typeof input.note!=='string'||input.note.length>240||/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(input.note))throw Error('Invalid rotation note');
  T.unb64(input.nonce,24);T.unb64(input.oldSignature,64);T.unb64(input.newSignature,64);
  return {schema:SCHEMA,from,to,issuedAt:input.issuedAt,note:input.note,nonce:input.nonce,oldSignature:input.oldSignature,newSignature:input.newSignature};
}
function signedStatement(packet){return {schema:SCHEMA,from:packet.from,to:packet.to,issuedAt:packet.issuedAt,note:packet.note,nonce:packet.nonce};}
function signedBytes(packet){return new TextEncoder().encode(Q.canonical({domain:DOMAIN,statement:signedStatement(packet)}));}
async function verify(raw){
  const proof=validateShape(raw);
  for(const side of ['from','to']){
    const x=proof[side];if(await T.keyId(x.algorithm,x.publicKey)!==x.keyId)throw Error('Rotation fingerprint mismatch: '+side);
    const key=await subtle().importKey('raw',T.unb64(x.publicKey,x.algorithm==='Ed25519'?32:65),importParams(x.algorithm),false,['verify']);
    const signature=T.unb64(side==='from'?proof.oldSignature:proof.newSignature,64);
    let good=false;try{good=await subtle().verify(signParams(x.algorithm),key,signature,signedBytes(proof));}catch(e){throw Error('Rotation verification unavailable: '+e.message)}
    if(!good)throw Error('INVALID ROTATION SIGNATURE: '+side+' has not authorized this exact transition');
  }
  return {verified:true,from:proof.from,to:proof.to,issuedAt:proof.issuedAt,note:proof.note,digest:'sha256:'+Q.sha256(Q.canonical(proof)),certificate:proof};
}
async function sign(oldIdentity,nextIdentity,note='',opts={}){
  if(!oldIdentity?.privateKey||!nextIdentity?.privateKey||oldIdentity.privateKey.extractable||nextIdentity.privateKey.extractable)throw Error('Both non-exportable private keys are required');
  const old=checkKey(ident(oldIdentity)),next=checkKey(ident(nextIdentity));
  if(old.keyId===next.keyId)throw Error('Cannot rotate to the existing key');
  if(await T.keyId(old.algorithm,old.publicKey)!==old.keyId||await T.keyId(next.algorithm,next.publicKey)!==next.keyId)throw Error('Local key fingerprint mismatch');
  const bytes=new Uint8Array(24);root.crypto.getRandomValues(bytes);
  const proof={schema:SCHEMA,from:old,to:next,issuedAt:opts.issuedAt||new Date().toISOString(),note:String(note).slice(0,240),nonce:T.b64url(bytes),oldSignature:'',newSignature:''};
  const body=signedBytes(proof);
  proof.oldSignature=T.b64url(new Uint8Array(await subtle().sign(signParams(old.algorithm),oldIdentity.privateKey,body)));
  proof.newSignature=T.b64url(new Uint8Array(await subtle().sign(signParams(next.algorithm),nextIdentity.privateKey,body)));
  await verify(proof);return proof;
}
function preview(state,verified){
  if(!verified?.verified||!verified.from?.keyId||!verified.to?.keyId)throw Error('Verify the rotation signatures before previewing pins');
  const subscriptions=Array.isArray(state.subscriptions)?state.subscriptions:[];
  const patchPins=Array.isArray(state.patchPins)?state.patchPins:[];
  const curator=subscriptions.filter(s=>s.publisherKeyId===verified.from.keyId);
  const patches=patchPins.filter(p=>p.keyId===verified.from.keyId);
  if([...curator,...patches].some(p=>p.publisherAlgorithm!==undefined?p.publisherAlgorithm!==verified.from.algorithm:p.algorithm!==verified.from.algorithm))throw Error('Pinned key algorithm inconsistent with rotation proof');
  if(!curator.length&&!patches.length)throw Error('No locally trusted OLD key matches this rotation. Verify a new identity out-of-band; do not auto-pin.');
  if(patches.some(p=>patchPins.some(other=>other!==p&&other.url===p.url&&other.keyId===verified.to.keyId)))throw Error('New contributor is already pinned for a watched URL; resolve duplicate pins manually');
  return {from:verified.from.keyId,to:verified.to.keyId,curatorChannels:curator.map(s=>s.channel),patchUrls:patches.map(p=>p.url),curatorCount:curator.length,patchCount:patches.length};
}
async function apply(state,raw){
  const checked=await verify(raw),plan=preview(state,checked);
  const subscriptions=(state.subscriptions||[]).map(s=>plan.curatorChannels.includes(s.channel)?{...s,publisherKeyId:checked.to.keyId,publisherAlgorithm:checked.to.algorithm}:s);
  const patchPins=(state.patchPins||[]).map(p=>p.keyId===checked.from.keyId?{...p,keyId:checked.to.keyId,algorithm:checked.to.algorithm,addedAt:new Date().toISOString()}:p);
  const history=Array.isArray(state.keyRotations)?state.keyRotations:[];
  if(history.some(x=>x.digest===checked.digest))throw Error('Rotation proof was already approved locally');
  const record={digest:checked.digest,from:checked.from.keyId,to:checked.to.keyId,at:new Date().toISOString(),curators:plan.curatorCount,contributors:plan.patchCount};
  // Validate all changes before mutating any shared state object.
  if(JSON.stringify(record).length>600||history.length>120)throw Error('Rotation receipt capacity exceeded');
  state.subscriptions=subscriptions;state.patchPins=patchPins;state.keyRotations=[record,...history].slice(0,60);
  return {...plan,record};
}
root.ProgRSSRotation=Object.freeze({SCHEMA,DOMAIN,validateShape,signedStatement,signedBytes,sign,verify,preview,apply});
})(globalThis);
