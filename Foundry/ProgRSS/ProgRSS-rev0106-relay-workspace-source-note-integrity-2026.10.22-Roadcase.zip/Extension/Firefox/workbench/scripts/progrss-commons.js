/* ProgRSS rev0020 · Feed Commons. Pure, offline analysis; never sends an observed URL. */
(function(root){
'use strict';
const C=root.ProgRSSCore;
function crossings(state,limit=40){
  const sources=new Map((state.sources||[]).map(s=>[s.id,s])),groups=new Map();
  for(const item of (state.items||[]).slice(0,1200)){
    if(!item.url||item.kind==='removed'||!sources.has(item.sourceId))continue;
    let key;try{key=C.safeUrl(item.url)}catch{continue;}
    let group=groups.get(key);
    if(!group){group={url:key,observations:0,latest:'',bySource:new Map()};groups.set(key,group);}
    group.observations++;
    if(!group.bySource.has(item.sourceId))group.bySource.set(item.sourceId,item);
    if((item.observedAt||'')>group.latest)group.latest=item.observedAt||'';
  }
  const results=[];
  for(const group of groups.values()){
    if(group.bySource.size<2)continue;
    const witness=[...group.bySource].map(([id,item])=>{
      const source=sources.get(id);let host='';try{host=new URL(C.safeUrl(source.url)).hostname.toLowerCase()}catch{}
      return {sourceId:id,sourceName:source.title||id,sourceHost:host,itemId:item.id,title:item.title||'',kind:item.kind||'new'};
    }).sort((a,b)=>a.sourceId.localeCompare(b.sourceId));
    const hosts=[...new Set(witness.map(w=>w.sourceHost).filter(Boolean))].sort();
    results.push({url:group.url,title:witness[0].title||'Untitled',sources:witness,sourceCount:witness.length,hostCount:hosts.length,hosts,
      observationCount:group.observations,latest:group.latest,classification:hosts.length>=2?'cross-host':'same-host'});
  }
  return results.sort((a,b)=>b.hostCount-a.hostCount||b.sourceCount-a.sourceCount||b.latest.localeCompare(a.latest)||a.url.localeCompare(b.url)).slice(0,Math.max(1,Math.min(100,Number(limit)||40)));
}
function edits(state,limit=40){
  const sources=new Map((state.sources||[]).map(s=>[s.id,s]));
  return (state.items||[]).filter(i=>i.kind==='changed'&&typeof i.entryKey==='string'&&sources.get(i.sourceId)?.type==='rss')
    .slice(0,Math.max(1,Math.min(100,Number(limit)||40))).map(i=>({id:i.id,sourceId:i.sourceId,sourceName:sources.get(i.sourceId).title,title:i.title,url:i.url,revision:i.feedRevision,observedAt:i.observedAt}));
}
function intersectionDraft(state,row){
  if(!row||!Array.isArray(row.sources)||row.sources.length<2||row.sources.length>150)throw Error('At least two known Lenses required');
  const known=new Set((state.sources||[]).map(s=>s.id)),ids=[...new Set(row.sources.map(w=>w.sourceId))];
  if(ids.length<2||ids.some(id=>!known.has(id)))throw Error('Unknown source Lens in Commons draft');
  return C.cleanCollection({id:C.uid('commons'),title:'Crossing · '+String(row.title||'Shared link').slice(0,85),mode:'intersection',members:ids.map(id=>({kind:'source',id})),include:'',exclude:'',version:1,author:'local'});
}
root.ProgRSSCommons=Object.freeze({crossings,edits,intersectionDraft});
})(globalThis);
