/* ProgRSS rev0010 · Lineage Room: immutable curator editions, opt-in pinned mirrors.
 * Every edition is a FULL declarative collection graph, never observations.
 * Checksums detect changed bytes; NOT publisher signatures or authentication.
 * Safe to run under file://; pure helpers do no networking, DOM operations, or storage.
 */
(function(root){
'use strict';
const C=root.ProgRSSCore, Q=root.ProgRSSCourier;
const SCHEMA='progrss.edition.v1',MAX_SUBS=12,MAX_PUBS=24,MAX_HISTORY=16,MAX_STATE_CHARS=4_800_000;
const FIELDS={source:['title','type','url','mode','selector','titleSelector','linkSelector','include','exclude','threshold','ignoreNumbers','author'],collection:['title','mode','include','exclude','members','author']};
const isObj=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const eq=(a,b)=>Q.canonical(a)===Q.canonical(b);
const ident=x=>typeof x==='string'&&/^[A-Za-z0-9_-]{1,100}$/.test(x)&&!['__proto__','constructor','prototype'].includes(x);
const digestRE=/^sha256:[a-f0-9]{64}$/;
const own=(o,k)=>Object.prototype.hasOwnProperty.call(o,k);
function stateInit(s){
  if(!Array.isArray(s.subscriptions))s.subscriptions=[];
  if(!Array.isArray(s.publications))s.publications=[];
  return s;
}
function contentOf(raw){return {channel:raw.channel,sequence:raw.sequence,previous:raw.previous,root:raw.root,bundle:raw.bundle};}
function hash(raw){return 'sha256:'+Q.sha256(Q.canonical(contentOf(raw)));}
function validate(raw){
  if(!isObj(raw)||raw.schema!==SCHEMA||JSON.stringify(raw).length>Q.MAX_ENVELOPE-8000)throw Error('Not a bounded ProgRSS collection edition');
  const fields=['schema','channel','sequence','previous','root','issuedAt','note','bundle','digest'];
  if(Object.keys(raw).length!==fields.length||Object.keys(raw).some(k=>!fields.includes(k)))throw Error('Unexpected edition fields');
  if(!ident(raw.channel)||!ident(raw.root)||!Number.isInteger(raw.sequence)||raw.sequence<1||raw.sequence>10000)throw Error('Invalid edition identity or sequence');
  if(typeof raw.previous!=='string'||(raw.previous!==''&&!digestRE.test(raw.previous))||(raw.sequence===1&&raw.previous!=='')||(raw.sequence>1&&!raw.previous))throw Error('Invalid predecessor digest');
  if(typeof raw.issuedAt!=='string'||raw.issuedAt.length>40||!Number.isFinite(Date.parse(raw.issuedAt))||typeof raw.note!=='string'||raw.note.length>300)throw Error('Invalid edition description');
  if(!digestRE.test(raw.digest))throw Error('Invalid edition content digest');
  const bundle=C.validateBundle(raw.bundle);
  if([...bundle.sources,...bundle.collections].some(x=>!ident(x.id)) || bundle.collections.some(c=>c.members.some(m=>!ident(m.id))))throw Error('Reserved or unsafe edition recipe ID');
  if(bundle.exportedAt!==raw.issuedAt)throw Error('Edition graph timestamp mismatch');
  if(!eq(bundle,raw.bundle))throw Error('Edition graph contains unreviewed or private properties');
  if(!bundle.collections.some(c=>c.id===raw.root))throw Error('Edition root collection missing from graph');
  if(hash(raw)!==raw.digest)throw Error('Edition digest mismatch');
  return {schema:SCHEMA,channel:raw.channel,sequence:raw.sequence,previous:raw.previous,root:raw.root,
    issuedAt:raw.issuedAt,note:raw.note,bundle,digest:raw.digest};
}
function editionFromGraph(channel,sequence,previous,root,bundle,note='',issuedAt=new Date().toISOString()){
  const candidate={schema:SCHEMA,channel,sequence,previous,root,issuedAt,note:C.text(note,300),bundle:{...bundle,exportedAt:issuedAt}};
  candidate.digest=hash(candidate);return validate(candidate);
}
function publish(state,root,note='',options={}){
  stateInit(state);
  if(!ident(root)||!state.collections.some(c=>c.id===root))throw Error('Choose an existing collection to publish');
  const prior=state.publications.find(x=>x.root===root);
  if(!prior&&state.publications.length>=MAX_PUBS)throw Error('Publisher channel limit reached');
  const bundle=C.exportBundle(state,root);
  const fingerprint='sha256:'+Q.sha256(Q.canonical({root,sources:bundle.sources,collections:bundle.collections}));
  if(prior?.fingerprint===fingerprint&&options?.forKeyRotation!==true)throw Error('Collection graph has not changed since the last edition');
  const channel=prior?.channel||C.uid('channel');
  const edition=editionFromGraph(channel,(prior?.sequence||0)+1,prior?.digest||'',root,bundle,note);
  const record={root,channel,sequence:edition.sequence,digest:edition.digest,fingerprint,
    history:[...(prior?.history||[]),{sequence:edition.sequence,digest:edition.digest,at:edition.issuedAt,summary:C.text(note,100)}].slice(-MAX_HISTORY)};
  state.publications=prior?state.publications.map(p=>p.root===root?record:p):[...state.publications,record];
  return edition;
}
function validateGraph(sources,collections){
  const ids=new Map();
  for(const s of sources){if(ids.has(s.id))throw Error('Conflicting local recipe IDs');ids.set(s.id,'source');}
  for(const c of collections){if(ids.has(c.id))throw Error('Conflicting local recipe IDs');ids.set(c.id,'collection');}
  const graph=new Map(collections.map(c=>[c.id,c]));
  for(const c of collections)for(const m of c.members||[]){if(ids.get(m.id)!==m.kind)throw Error('Missing or mismatched local collection member');}
  const stack=new Set(),visited=new Set();
  function walk(id){if(stack.has(id))throw Error('Update creates a collection cycle');if(visited.has(id))return;stack.add(id);
    for(const m of graph.get(id).members)if(m.kind==='collection')walk(m.id);
    stack.delete(id);visited.add(id);}
  for(const id of graph.keys())walk(id);
}
function mapped(type,node,mapping){
  const id=mapping[node.id];if(!ident(id))throw Error('Edition mapping missing node '+node.id);
  const clean=type==='source'?C.cleanRecipe(node):C.cleanCollection(node);
  if(type==='source')return {...clean,id};
  return {...clean,id,members:clean.members.map(member=>{
    if(!ident(mapping[member.id]))throw Error('Edition references unmapped member');
    const projected={kind:member.kind,id:mapping[member.id]};
    if(member.kind==='source'&&own(member,'reason'))projected.reason=member.reason;
    return projected;
  })};
}
const SOURCE_NOTE_CHOICES=new Set(['keep_mine','use_curator']);
function sourceNoteValue(member){return member&&own(member,'reason')?member.reason:null;}
function memberStructure(rows){return rows.map(member=>({kind:member.kind,id:member.id}));}
function sourceMembers(rows){return new Map(rows.filter(member=>member.kind==='source').map(member=>[member.id,member]));}
function mergeCollectionMembers(base,local,incoming,decisions,usedDecisions,context){
  if(eq(local,incoming))return {members:local,structuralConflict:false,sourceNoteConflicts:[]};
  if(eq(local,base))return {members:incoming,structuralConflict:false,sourceNoteConflicts:[]};
  if(eq(incoming,base))return {members:local,structuralConflict:false,sourceNoteConflicts:[]};
  const localStructure=memberStructure(local),incomingStructure=memberStructure(incoming);
  const structuralConflict=!eq(localStructure,incomingStructure);
  const chosenMembers=local.map(member=>({...member}));
  const baseSources=sourceMembers(base),localSources=sourceMembers(local),incomingSources=sourceMembers(incoming);
  const sourceNoteConflicts=[];
  const members=chosenMembers.map(member=>{
    if(member.kind!=='source')return {...member};
    const baseMember=baseSources.get(member.id),localMember=localSources.get(member.id),incomingMember=incomingSources.get(member.id);
    // A structurally removed upstream placement is not a Source Note deletion.
    // When both sides changed the member graph, local structure is preserved as
    // before; retain the whole local placement unless the placement still
    // exists upstream and its reason can be compared independently.
    if(!incomingMember)return {...member};
    const baseValue=sourceNoteValue(baseMember);
    const localValue=sourceNoteValue(localMember);
    const incomingValue=sourceNoteValue(incomingMember);
    let selected;
    if(localValue===incomingValue)selected=localValue;
    else if(baseMember&&localValue===baseValue)selected=incomingValue;
    else if(baseMember&&incomingValue===baseValue)selected=localValue;
    else{
      const remoteSourceId=context.remoteByLocal.get(member.id)||member.id;
      const id='source-note:'+context.remoteFolderId+':'+remoteSourceId;
      const hasChoice=own(decisions,id),choice=hasChoice?decisions[id]:'';
      if(hasChoice&&!SOURCE_NOTE_CHOICES.has(choice))throw Error('Source Note decision must be Keep mine or Use curator’s');
      if(hasChoice)usedDecisions.add(id);
      selected=choice==='use_curator'?incomingValue:localValue;
      sourceNoteConflicts.push({
        id,folderId:context.localFolderId,folderRemoteId:context.remoteFolderId,
        sourceId:member.id,sourceRemoteId:remoteSourceId,
        folderTitle:context.folderTitle,sourceTitle:context.sourceTitleByLocal.get(member.id)||remoteSourceId,
        base:baseValue,mine:localValue,curator:incomingValue,choice
      });
    }
    const projected={...member};if(selected===null)delete projected.reason;else projected.reason=selected;return projected;
  });
  return {members,structuralConflict,sourceNoteConflicts};
}
function stamp(e){return {sequence:e.sequence,digest:e.digest,at:e.issuedAt,note:C.text(e.note,100)};}
function review(state,raw,decisions={}){
  stateInit(state);
  if(!isObj(decisions))throw Error('Source Note decisions must be an object');
  const edition=validate(raw),sub=state.subscriptions.find(s=>s.channel===edition.channel),notes=[],conflicts=[],retired=[],resets=[],sourceNoteConflicts=[];
  const usedDecisions=new Set();
  if(!sub&&state.subscriptions.length>=MAX_SUBS)throw Error('Following limit of 12 channels reached');
  if(sub){
    if(sub.root!==edition.root)throw Error('Channel changed its root collection');
    if(edition.digest===sub.digest)throw Error('Already following exactly this edition');
    if(edition.sequence!==sub.sequence+1||edition.previous!==sub.digest)throw Error('Missing predecessor, rollback, or divergent upstream branch; refusing unsafe fast-forward');
    if(!isObj(sub.mapping)||!isObj(sub.base))throw Error('Invalid saved subscriber mapping');
    // A pinned mirror must not have been edited out of the graph without user intervention.
    for(const x of [...sub.base.sources,...sub.base.collections]){
      const id=sub.mapping[x.id],list=sub.base.sources.includes(x)?state.sources:state.collections;
      if(!ident(id)||!list.some(n=>n.id===id))throw Error('Local mirror node deleted; unsubscribe/re-follow explicitly');
    }
  }
  const used=new Set([...state.sources,...state.collections].map(x=>x.id));
  const mapping=Object.create(null);
  if(sub)for(const [remote,local] of Object.entries(sub.mapping)){
    if(!ident(remote)||!ident(local))throw Error('Bad saved mapping');
    mapping[remote]=local;
  }
  const all=[...edition.bundle.sources,...edition.bundle.collections];
  for(const x of all)if(!own(mapping,x.id)){
    let id=C.uid('follow');while(used.has(id))id=C.uid('follow');mapping[x.id]=id;used.add(id);
  }
  const remoteByLocal=new Map(Object.entries(mapping).map(([remote,local])=>[local,remote]));
  const sources=state.sources.map(s=>({...s}));
  const collections=state.collections.map(c=>({...c,members:(c.members||[]).map(m=>({...m}))}));
  const sourceTitleByLocal=new Map(sources.map(source=>[source.id,source.title]));
  const oldSources=new Map((sub?.base.sources||[]).map(x=>[x.id,x]));
  const oldCollections=new Map((sub?.base.collections||[]).map(x=>[x.id,x]));
  const touched=[];
  for(const kind of ['source','collection'])for(const remote of edition.bundle[kind==='source'?'sources':'collections']){
    const id=mapping[remote.id],next=mapped(kind,remote,mapping),list=kind==='source'?sources:collections;
    const ix=list.findIndex(x=>x.id===id);
    if(ix<0){
      list.push(kind==='source'?{...next,enabled:false,lastScan:'',lastError:'',origin:'followed'}:next);
      if(kind==='source')sourceTitleByLocal.set(id,next.title);
      notes.push({kind:'added',type:kind,id,title:next.title,fields:[]});touched.push(id);continue;
    }
    const current=list[ix],previous=(kind==='source'?oldSources:oldCollections).get(remote.id);
    if(!previous)throw Error('Local mirror mapping collides with an unrelated node');
    const base=mapped(kind,previous,mapping);
    const merged={...current};const fields=[];
    for(const field of FIELDS[kind]){
      if(kind==='collection'&&field==='members'){
        const currentMembers=C.cleanCollection(current).members;
        if(eq(next.members,base.members))continue;
        const memberPlan=mergeCollectionMembers(base.members,currentMembers,next.members,decisions,usedDecisions,{
          remoteFolderId:remote.id,localFolderId:id,folderTitle:current.title||next.title,remoteByLocal,sourceTitleByLocal
        });
        sourceNoteConflicts.push(...memberPlan.sourceNoteConflicts);
        if(!eq(memberPlan.members,currentMembers))merged.members=memberPlan.members;
        if(memberPlan.structuralConflict){
          fields.push('members (kept local structure)');
          conflicts.push({type:kind,id,field:'members',title:current.title});
        }else if(memberPlan.sourceNoteConflicts.length){
          const unresolved=memberPlan.sourceNoteConflicts.filter(row=>!row.choice).length;
          fields.push(unresolved?'members (Source Note decision required)':'members (Source Note decision applied)');
        }else if(eq(currentMembers,next.members))fields.push('members (already agrees)');
        else fields.push('members');
        continue;
      }
      if(eq(next[field],base[field]))continue;
      if(eq(current[field],base[field])){merged[field]=next[field];fields.push(field);}
      else {fields.push(field+' (kept local)');if(!eq(current[field],next[field]))conflicts.push({type:kind,id,field,title:current.title});}
    }
    if(fields.length){
      // Local editor increments revision numbers; don't silently decrease them.
      merged.version=Math.min(10000,Math.max(Number(current.version)||1,Number(next.version)||1)+1);
      if(kind==='source'&&['url','mode','selector','titleSelector','linkSelector','ignoreNumbers','threshold'].some(k=>!eq(current[k],merged[k]))){
        merged.enabled=false;merged.lastScan='';merged.lastError='';delete merged.pulse;delete merged.httpCache;resets.push(id);
      }
      notes.push({kind:'revised',type:kind,id,title:merged.title,fields});touched.push(id);
    }
    list[ix]=merged;
  }
  for(const key of Object.keys(decisions))if(!usedDecisions.has(key))throw Error('Source Note decision is stale or does not match a divergent placement');
  if(sub){const upcomingIds=new Set(all.map(x=>x.id));for(const prev of [...sub.base.sources,...sub.base.collections])if(!upcomingIds.has(prev.id)){
    // Never destroy local content or observations on upstream deletion.
    const id=mapping[prev.id];retired.push({type:oldSources.has(prev.id)?'source':'collection',id,title:prev.title});
  }}
  if(sources.length>C.LIMIT.source||collections.length>C.LIMIT.collection)throw Error('Follow update exceeds local library capacity');
  validateGraph(sources,collections);
  const record={id:sub?.id||C.uid('sub'),channel:edition.channel,root:edition.root,localRoot:mapping[edition.root],
    sequence:edition.sequence,digest:edition.digest,mapping:{...mapping},base:{sources:edition.bundle.sources,collections:edition.bundle.collections},
    title:edition.bundle.collections.find(x=>x.id===edition.root).title,
    publisherKeyId:sub?.publisherKeyId||'',publisherAlgorithm:sub?.publisherAlgorithm||'',
    history:[...(sub?.history||[]),stamp(edition)].slice(-MAX_HISTORY),updatedAt:new Date().toISOString()};
  const nextSubscriptions=sub?state.subscriptions.map(x=>x.channel===sub.channel?record:x):[...state.subscriptions,record];
  if(JSON.stringify(nextSubscriptions).length>MAX_STATE_CHARS)throw Error('Subscription vault size budget reached');
  const unresolvedSourceNoteConflicts=sourceNoteConflicts.filter(row=>!row.choice);
  return {edition,first:!sub,record,sources,collections,nextSubscriptions,notes,conflicts,retired,resets,touched,
    sourceNoteConflicts,unresolvedSourceNoteConflicts,sourceNoteDecisions:sourceNoteConflicts.filter(row=>row.choice)};
}
function apply(state,raw,decisions={}){
  // Redo ALL checks against the live state; preview plans and caller-held IDs
  // are never trusted at commit time.
  const plan=review(state,raw,decisions);
  if(plan.unresolvedSourceNoteConflicts.length)throw Error('Choose Keep mine or Use curator’s for every divergent Source Note before approval');
  state.sources=plan.sources;state.collections=plan.collections;state.subscriptions=plan.nextSubscriptions;
  if(isObj(state.snapshots))for(const id of plan.resets)delete state.snapshots[id];
  return {first:plan.first,channel:plan.record.channel,sequence:plan.record.sequence,localRoot:plan.record.localRoot,
    added:plan.notes.filter(x=>x.kind==='added').length,revised:plan.notes.filter(x=>x.kind==='revised').length,
    conflicts:plan.conflicts.length,sourceNoteDecisions:plan.sourceNoteDecisions.length,retired:plan.retired.length,paused:plan.resets.length};
}
function unsubscribe(state,channel){
  stateInit(state);const before=state.subscriptions.length;
  state.subscriptions=state.subscriptions.filter(x=>x.channel!==channel);
  // Explicitly leave mirrored recipes and their observations in the local library.
  return state.subscriptions.length!==before;
}
root.ProgRSSLineage=Object.freeze({SCHEMA,MAX_SUBS,MAX_PUBS,stateInit,contentOf,hash,validate,editionFromGraph,publish,review,apply,unsubscribe});
})(globalThis);
