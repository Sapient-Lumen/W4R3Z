/* ProgRSS rev0014 · Recovery Circle
 * Pre-authorized, signed guardians. Distinct votes, no private-key escrow.
 * Quorum is evidence only: local pin adoption still requires human consent.
 */
(function(root){
'use strict';
const T=root.ProgRSSTrust,Q=root.ProgRSSCourier;
const CHARTER='progrss.recovery.charter.v1',REQUEST='progrss.recovery.request.v1',VOTE='progrss.recovery.vote.v1',PACKET='progrss.recovery.packet.v1';
const DOMAIN={charter:'ProgRSS/recovery-charter/v1',request:'ProgRSS/recovery-request/v1',vote:'ProgRSS/recovery-vote/v1'};
const dkeys={charter:['schema','subject','guardians','threshold','scope','issuedAt','expiresAt','nonce','signature'],request:['schema','charterDigest','successor','issuedAt','nonce','note','signature'],vote:['schema','charterDigest','requestDigest','guardian','issuedAt','signature'],packet:['schema','charter','request','votes']};
const plain=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
const exact=(o,keys)=>plain(o)&&Object.keys(o).length===keys.length&&keys.every(k=>Object.prototype.hasOwnProperty.call(o,k));
const descriptor=x=>({algorithm:x.algorithm,publicKey:x.publicKey,keyId:x.keyId});
const subtle=()=>{if(!root.crypto?.subtle)throw Error('Recovery Circle requires Web Crypto in a secure context');return root.crypto.subtle};
const sigParams=a=>a==='Ed25519'?{name:'Ed25519'}:{name:'ECDSA',hash:'SHA-256'};
const importParams=a=>a==='Ed25519'?{name:'Ed25519'}:{name:'ECDSA',namedCurve:'P-256'};
const digest=x=>'sha256:'+Q.sha256(Q.canonical(x));
const dateRe=/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;
function validDate(x){if(typeof x!=='string'||!dateRe.test(x)||!Number.isFinite(Date.parse(x))||new Date(x).toISOString()!==x)throw Error('Invalid UTC timestamp');return Date.parse(x);}
function checkKey(x){if(!exact(x,['algorithm','publicKey','keyId'])||!T.ALG.includes(x.algorithm))throw Error('Invalid recovery key descriptor');
  let bytes=T.unb64(x.publicKey,x.algorithm==='Ed25519'?32:65);if(x.algorithm!=='Ed25519'&&bytes[0]!==4)throw Error('Invalid P-256 point');
  if(typeof x.keyId!=='string'||!new RegExp('^'+x.algorithm.toLowerCase()+':[a-f0-9]{64}$').test(x.keyId))throw Error('Malformed key fingerprint');return descriptor(x);
}
async function verifyKey(x){const key=checkKey(x);if(await T.keyId(key.algorithm,key.publicKey)!==key.keyId)throw Error('Recovery key fingerprint mismatch');return key;}
function nonce(){let b=new Uint8Array(24);root.crypto.getRandomValues(b);return T.b64url(b)}
const timestamp=()=>new Date().toISOString();
function signable(kind,record){const b={...record};delete b.signature;return new TextEncoder().encode(Q.canonical({domain:DOMAIN[kind],statement:b}));}
async function sign(kind,record,identity){if(!identity?.privateKey||identity.privateKey.extractable)throw Error('Non-exportable signer key required');
  if(identity.keyId!==await T.keyId(identity.algorithm,identity.publicKey))throw Error('Signing identity fingerprint mismatch');
  record.signature=T.b64url(new Uint8Array(await subtle().sign(sigParams(identity.algorithm),identity.privateKey,signable(kind,record))));return record;
}
async function verifySig(kind,record,signer){await verifyKey(signer);
  let pub=await subtle().importKey('raw',T.unb64(signer.publicKey,signer.algorithm==='Ed25519'?32:65),importParams(signer.algorithm),false,['verify']);
  if(!await subtle().verify(sigParams(signer.algorithm),pub,T.unb64(record.signature,64),signable(kind,record)))throw Error('INVALID RECOVERY SIGNATURE: '+kind);return true;
}
function validateCharter(raw){
  if(!exact(raw,dkeys.charter)||raw.schema!==CHARTER||JSON.stringify(raw).length>8000)throw Error('Invalid recovery charter fields/size');
  const subject=checkKey(raw.subject);
  if(!Array.isArray(raw.guardians)||raw.guardians.length<2||raw.guardians.length>5)throw Error('Recovery requires 2–5 guardian keys');
  const guardians=raw.guardians.map(checkKey),ids=guardians.map(x=>x.keyId);
  if(new Set(ids).size!==ids.length||ids.includes(subject.keyId)||ids.join('|')!==ids.slice().sort().join('|'))throw Error('Guardian roster must be sorted, distinct and independent of owner');
  if(!Number.isSafeInteger(raw.threshold)||raw.threshold<2||raw.threshold>ids.length)throw Error('Recovery threshold must be 2..guardian count');
  if(!['curator','patch','both'].includes(raw.scope))throw Error('Invalid recovery scope');
  const first=validDate(raw.issuedAt),last=validDate(raw.expiresAt);
  if(last<=first||last-first>366*86400000)throw Error('Recovery charter validity must be at most 366 days');
  T.unb64(raw.nonce,24);T.unb64(raw.signature,64);return raw;
}
async function verifyCharter(raw){const c=validateCharter(raw);await verifySig('charter',c,c.subject);for(const k of c.guardians)await verifyKey(k);return {charter:c,digest:digest(c)};}
async function makeCharter(identity,guardians,threshold,scope='both',days=180,opts={}){
  if(!identity?.privateKey||identity.privateKey.extractable)throw Error('Owner signing identity unavailable');
  if(!Number.isSafeInteger(days)||days<1||days>365)throw Error('Use 1–365 days for a recovery charter');
  const start=opts.issuedAt||timestamp(),c={schema:CHARTER,subject:checkKey(descriptor(identity)),guardians:guardians.map(checkKey).sort((a,b)=>a.keyId.localeCompare(b.keyId)),threshold,scope,issuedAt:start,expiresAt:new Date(Date.parse(start)+days*86400000).toISOString(),nonce:nonce(),signature:''};
  await sign('charter',c,identity);await verifyCharter(c);return c;
}
function validateRequest(raw){
  if(!exact(raw,dkeys.request)||raw.schema!==REQUEST||JSON.stringify(raw).length>1800)throw Error('Invalid recovery request');
  if(typeof raw.charterDigest!=='string'||!/^sha256:[a-f0-9]{64}$/.test(raw.charterDigest))throw Error('Invalid request charter digest');
  checkKey(raw.successor);validDate(raw.issuedAt);T.unb64(raw.nonce,24);T.unb64(raw.signature,64);
  if(typeof raw.note!=='string'||raw.note.length>240||/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(raw.note))throw Error('Invalid recovery note');return raw;
}
async function makeRequest(charter,identity,note='',opts={}){
  const checked=await verifyCharter(charter);
  if(identity?.keyId===charter.subject.keyId||charter.guardians.some(g=>g.keyId===identity?.keyId))throw Error('Successor key must differ from owner and guardians');
  const req={schema:REQUEST,charterDigest:checked.digest,successor:checkKey(descriptor(identity)),issuedAt:opts.issuedAt||timestamp(),nonce:nonce(),note:String(note).slice(0,240),signature:''};
  if(validDate(req.issuedAt)<validDate(charter.issuedAt)||validDate(req.issuedAt)>validDate(charter.expiresAt))throw Error('Request issued outside charter validity');
  await sign('request',req,identity);await verifyRequest(req,charter);return req;
}
async function verifyRequest(raw,charter){const r=validateRequest(raw),c=await verifyCharter(charter);
  if(r.charterDigest!==c.digest||r.successor.keyId===charter.subject.keyId||charter.guardians.some(g=>g.keyId===r.successor.keyId))throw Error('Recovery request conflicts with charter');
  const at=validDate(r.issuedAt);if(at<validDate(charter.issuedAt)||at>validDate(charter.expiresAt))throw Error('Request is outside charter validity');
  await verifySig('request',r,r.successor);return {request:r,digest:digest(r)};
}
function validateVote(raw){if(!exact(raw,dkeys.vote)||raw.schema!==VOTE||JSON.stringify(raw).length>1700)throw Error('Invalid guardian vote');
  checkKey(raw.guardian);validDate(raw.issuedAt);T.unb64(raw.signature,64);
  for(const d of ['charterDigest','requestDigest'])if(typeof raw[d]!=='string'||!/^sha256:[a-f0-9]{64}$/.test(raw[d]))throw Error('Invalid vote '+d);return raw;
}
async function makeVote(packet,identity,opts={}){
  const checked=await verifyPacket(packet,{requireQuorum:false});const c=checked.charter,r=checked.request;
  if(!c.guardians.some(g=>g.keyId===identity?.keyId&&g.publicKey===identity?.publicKey&&g.algorithm===identity?.algorithm))throw Error('Local identity is not an authorized guardian');
  if(packet.votes.some(v=>v.guardian.keyId===identity.keyId))throw Error('This guardian has already voted');
  const v={schema:VOTE,charterDigest:digest(c),requestDigest:digest(r),guardian:descriptor(identity),issuedAt:opts.issuedAt||timestamp(),signature:''};
  if(validDate(v.issuedAt)<validDate(r.issuedAt)||validDate(v.issuedAt)>validDate(c.expiresAt))throw Error('Guardian vote is outside charter validity');
  await sign('vote',v,identity);await verifyVote(v,c,r);return v;
}
async function verifyVote(raw,c,r){const v=validateVote(raw);
  if(v.charterDigest!==digest(c)||v.requestDigest!==digest(r)||!c.guardians.some(g=>Q.canonical(g)===Q.canonical(v.guardian)))throw Error('Unauthorized or mismatched guardian vote');
  const at=validDate(v.issuedAt);if(at<validDate(r.issuedAt)||at>validDate(c.expiresAt))throw Error('Guardian vote outside charter period');
  await verifySig('vote',v,v.guardian);return v;
}
function validatePacket(raw){if(!exact(raw,dkeys.packet)||raw.schema!==PACKET||JSON.stringify(raw).length>18000)throw Error('Invalid or oversized recovery packet');
  validateCharter(raw.charter);validateRequest(raw.request);
  if(!Array.isArray(raw.votes)||raw.votes.length>5)throw Error('Invalid recovery vote count');raw.votes.forEach(validateVote);return raw;
}
async function verifyPacket(raw,{requireQuorum=false,now=Date.now()}={}){
  const packet=validatePacket(raw),c=packet.charter,r=packet.request;
  await verifyRequest(r,c);
  const ids=new Set();for(const v of packet.votes){await verifyVote(v,c,r);if(ids.has(v.guardian.keyId))throw Error('Duplicate guardian vote');ids.add(v.guardian.keyId)}
  const quorum=ids.size>=c.threshold;
  if(requireQuorum&&!quorum)throw Error('Recovery quorum not reached: '+ids.size+'/'+c.threshold);
  const active=now>=validDate(c.issuedAt)&&now<=validDate(c.expiresAt);
  return {charter:c,request:r,votes:packet.votes.length,threshold:c.threshold,quorum,active,subject:c.subject.keyId,successor:r.successor.keyId,charterDigest:digest(c),requestDigest:digest(r),voteKeys:[...ids].sort()};
}
async function newPacket(charter,identity,note=''){const r=await makeRequest(charter,identity,note);return {schema:PACKET,charter,request:r,votes:[]};}
async function addVote(packet,identity){const vote=await makeVote(packet,identity);const next={...packet,votes:[...packet.votes,vote].sort((a,b)=>a.guardian.keyId.localeCompare(b.guardian.keyId))};await verifyPacket(next);return next;}
async function combine(a,b){const x=await verifyPacket(a),y=await verifyPacket(b);if(x.charterDigest!==y.charterDigest||x.requestDigest!==y.requestDigest)throw Error('Recovery packets refer to different requests');
  const votes=new Map();for(const v of [...a.votes,...b.votes]){const id=v.guardian.keyId;const earlier=votes.get(id);if(earlier&&Q.canonical(earlier)!==Q.canonical(v))throw Error('Conflicting signatures from same guardian');votes.set(id,v)}
  const combined={schema:PACKET,charter:a.charter,request:a.request,votes:[...votes.values()].sort((v,w)=>v.guardian.keyId.localeCompare(w.guardian.keyId))};await verifyPacket(combined);return combined;
}
function affected(state,key,scope){const curator=scope!=='patch'?(state.subscriptions||[]).filter(x=>x.publisherKeyId===key):[];
  const patch=scope!=='curator'?(state.patchPins||[]).filter(x=>x.keyId===key):[];return {curator,patch};}
async function register(state,charter){const checked=await verifyCharter(charter),found=affected(state,charter.subject.keyId,charter.scope);
  if(!found.curator.length&&!found.patch.length)throw Error('No pre-existing trusted publisher or contributor pin matches the charter');
  if(Date.now()>validDate(charter.expiresAt))throw Error('Cannot pin an expired charter');
  const existing=(state.recoveryPolicies||[]).find(x=>x.subjectKeyId===charter.subject.keyId);
  if(existing)throw Error('Recovery policy already pinned for this key; explicit revocation/replacement is a future feature');
  if((state.recoveryPolicies||[]).length>=32)throw Error('Recovery policy capacity exceeded');
  const record={subjectKeyId:charter.subject.keyId,digest:checked.digest,charter,registeredAt:timestamp()};state.recoveryPolicies=[...(state.recoveryPolicies||[]),record];
  return {record,curator:found.curator.length,patch:found.patch.length};
}
async function preview(state,packet,now=Date.now()){
  const r=await verifyPacket(packet,{requireQuorum:true,now});
  if(!r.active)throw Error('Recovery charter has expired or is not yet active');
  const pinned=(state.recoveryPolicies||[]).find(x=>x.subjectKeyId===r.subject);
  if(!pinned||pinned.status==='revoked'||pinned.digest!==r.charterDigest||Q.canonical(pinned.charter)!==Q.canonical(packet.charter))throw Error('No PRE-REGISTERED recovery charter matches this request');
  if((state.recoveryReceipts||[]).some(x=>x.requestDigest===r.requestDigest))throw Error('Recovery request already applied');
  const a=affected(state,r.subject,packet.charter.scope);
  if(!a.curator.length&&!a.patch.length)throw Error('Old key is not pinned for this charter scope');
  if(a.patch.some(p=>(state.patchPins||[]).some(other=>other!==p&&other.url===p.url&&other.keyId===r.successor)))throw Error('Successor contributor already pinned for a watched URL');
  return {...r,curatorChannels:a.curator.map(x=>x.channel),patchUrls:a.patch.map(x=>x.url),curatorCount:a.curator.length,patchCount:a.patch.length};
}
async function apply(state,packet){const r=await preview(state,packet);const subscriptions=(state.subscriptions||[]).map(s=>r.curatorChannels.includes(s.channel)?{...s,publisherKeyId:r.successor,publisherAlgorithm:packet.request.successor.algorithm}:s);
  const patchPins=(state.patchPins||[]).map(p=>r.patchUrls.includes(p.url)&&p.keyId===r.subject?{...p,keyId:r.successor,algorithm:packet.request.successor.algorithm,addedAt:timestamp()}:p);
  if((state.recoveryReceipts||[]).length>=120)throw Error('Recovery receipt capacity exceeded');
  const receipt={requestDigest:r.requestDigest,charterDigest:r.charterDigest,from:r.subject,to:r.successor,at:timestamp(),curators:r.curatorCount,contributors:r.patchCount,quorum:r.votes+'/'+r.threshold};
  state.subscriptions=subscriptions;state.patchPins=patchPins;state.recoveryPolicies=(state.recoveryPolicies||[]).filter(x=>x.subjectKeyId!==r.subject);
  state.recoveryReceipts=[receipt,...(state.recoveryReceipts||[])].slice(0,80);return {...r,receipt};
}
root.ProgRSSRecovery=Object.freeze({CHARTER,REQUEST,VOTE,PACKET,DOMAIN,descriptor,checkKey,validateCharter,validateRequest,validateVote,validatePacket,verifyCharter,verifyRequest,verifyPacket,makeCharter,makeRequest,newPacket,makeVote,addVote,combine,register,preview,apply,digest});
})(globalThis);
