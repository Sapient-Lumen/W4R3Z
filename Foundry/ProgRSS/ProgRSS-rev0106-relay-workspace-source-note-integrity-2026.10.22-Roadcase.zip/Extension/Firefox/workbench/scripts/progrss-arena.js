/* ProgRSS rev0020 — Filter Arena.
   Declarative offline head-to-head recipe comparisons using the EXACT page
   extractor from ProgRSSCore. Tests and recipes are never silently shared.
*/
(function(root){
'use strict';
const C=root.ProgRSSCore;
const SCHEMA='progrss.arena.matrix.v1', PUBLIC='progrss.arena.aggregate.v1';
const MAX_CANDIDATES=8, MAX_CASES=12, MAX_CHARS=600000;
const EXPECT=new Set(['quiet','changed','added','removed','changed-card','any']);
const ACTUAL=new Set(['quiet','changed','added','removed','changed-card','error']);
const KEYS=['mode','selector','titleSelector','linkSelector','threshold','ignoreNumbers'];
function checkedOutcome(x){
  if(!x||typeof x!=='object'||!EXPECT.has(x.expected)||!ACTUAL.has(x.actual)||typeof x.holdout!=='boolean')throw Error('Invalid Filter Arena outcome');
  return {expected:x.expected,actual:x.actual,holdout:x.holdout};
}
function kindOf(x){
  if(x.expected==='any')return x.actual==='error'?'error':'smoke';
  if(x.actual==='error')return 'error';
  if(x.expected==='quiet'&&x.actual!=='quiet')return 'falsePositive';
  if(x.expected!=='quiet'&&x.actual==='quiet')return 'miss';
  if(x.expected==='changed'&&x.actual!=='quiet')return 'pass';
  if(x.expected===x.actual)return 'pass';
  return 'wrongKind';
}
function scoreOutcomes(outcomes){
  if(!Array.isArray(outcomes)||!outcomes.length||outcomes.length>MAX_CASES)throw Error('Arena needs 1–12 cases');
  const counts={pass:0,falsePositive:0,miss:0,wrongKind:0,error:0,smoke:0};
  let weighted=0,passedWeighted=0,penalty=0,holdoutTests=0,holdoutPass=0,changedCases=0,quietCases=0;
  for(const raw of outcomes){
    const row=checkedOutcome(raw),kind=kindOf(row),w=row.holdout?2:1;
    counts[kind]++;
    if(row.expected==='any')continue;
    if(row.expected==='quiet')quietCases++;else changedCases++;
    if(row.holdout){holdoutTests++;if(kind==='pass')holdoutPass++;}
    weighted+=w;
    if(kind==='pass')passedWeighted+=w;
    else penalty+=(kind==='falsePositive'?2:kind==='miss'?1.5:kind==='error'?2.5:1)*w;
  }
  const score=weighted?Math.max(0,Math.round(100*(passedWeighted-0.25*penalty)/weighted)):0;
  return {...counts,scored:quietCases+changedCases,quietCases,changedCases,holdoutTests,holdoutPass,score,
    balanced:quietCases>0&&changedCases>0,clean:weighted>0&&passedWeighted===weighted};
}
function scoreMatrix(matrix){
  if(!matrix||matrix.schema!==SCHEMA||!Array.isArray(matrix.rows)||!matrix.rows.length||matrix.rows.length>MAX_CANDIDATES)throw Error('Invalid Arena matrix or too many contenders');
  const reference=matrix.rows[0]?.outcomes;
  if(!Array.isArray(reference)||!reference.length||reference.length>MAX_CASES)throw Error('Invalid Arena reference cases');
  for(const row of matrix.rows){
    if(!row||!Array.isArray(row.outcomes)||row.outcomes.length!==reference.length)throw Error('All contenders must use the same cases');
    for(let i=0;i<reference.length;i++){
      const a=checkedOutcome(reference[i]),b=checkedOutcome(row.outcomes[i]);
      if(a.expected!==b.expected||a.holdout!==b.holdout)throw Error('All contenders must use matching expectations and holdouts');
    }
  }
  const rows=matrix.rows.map((r,index)=>{
    if(!r||!Array.isArray(r.outcomes))throw Error('Arena contender has no outcomes');
    const stats=scoreOutcomes(r.outcomes);
    const shortId='Option '+(index+1);
    return {id:shortId,stats};
  });
  // A held-out case is a convenience split of user-owned fixtures, not a
  // statistically independent or cryptographically hidden test set.
  const order=rows.map((r,index)=>({...r,index})).sort((a,b)=>
    b.stats.score-a.stats.score||a.stats.falsePositive-b.stats.falsePositive||
    a.stats.error-b.stats.error||a.stats.miss-b.stats.miss||
    b.stats.holdoutPass-a.stats.holdoutPass||a.index-b.index);
  const best=order[0],other=order[1];
  const hasSeparation=!other||best.stats.score!==other.stats.score||
    best.stats.falsePositive!==other.stats.falsePositive||best.stats.error!==other.stats.error||best.stats.miss!==other.stats.miss;
  const leader=rows.length>1&&best.stats.balanced&&best.stats.scored>=2&&hasSeparation&&
    (best.stats.holdoutTests===0||best.stats.holdoutPass===best.stats.holdoutTests)?best.index:null;
  return {schema:'progrss.arena.scores.v1',rows,ranking:order.map(r=>r.index),leader,
    note:'Local expected outcomes are human labels; results are neither a proof of a correct extraction nor a blind evaluation.'};
}
function draftFor(base,changes){
  if(!base||base.type!=='page')throw Error('Arena requires a selected webpage Lens');
  if(!changes||typeof changes!=='object'||Array.isArray(changes))throw Error('Candidate must be an object');
  if(Object.keys(changes).some(k=>!KEYS.includes(k)))throw Error('Candidate cannot change URL, permissions, ID, or other recipe fields');
  const draft=C.cleanRecipe({...base,...changes});
  if(draft.id!==base.id||draft.url!==base.url||draft.type!=='page')throw Error('Candidate retargeted the Lens');
  return draft;
}
function normalizeCandidates(base,candidates){
  if(!Array.isArray(candidates)||!candidates.length||candidates.length>MAX_CANDIDATES)throw Error('Arena expects 1–8 candidates');
  const seen=new Set();
  return candidates.map((candidate,index)=>{
    const recipe=draftFor(base,candidate.changes||{});
    const identity=JSON.stringify(KEYS.map(k=>recipe[k]??null));
    if(seen.has(identity))throw Error('Duplicate Arena candidate');seen.add(identity);
    return {label:C.text(candidate.label||'Option '+(index+1),80),recipe};
  });
}
function compare(base,cases,candidates){
  const opts=normalizeCandidates(base,candidates);
  if(!Array.isArray(cases)||!cases.length||cases.length>MAX_CASES)throw Error('Arena expects 1–12 cases');
  let size=0;
  const local=cases.map((c,i)=>{
    if(!c||!EXPECT.has(c.expected)||typeof c.before!=='string'||typeof c.after!=='string'||
       !c.before.trim()||!c.after.trim()||c.before.length>C.LIMIT.fixtureChars||c.after.length>C.LIMIT.fixtureChars)
       throw Error('Arena cases must be valid nonempty HTML snapshots (max 160K each)');
    size+=c.before.length+c.after.length;
    return {name:C.text(c.name||c.title||'Case '+(i+1),90),expected:c.expected,
      before:c.before,after:c.after,holdout:Boolean(c.holdout)};
  });
  if(size>MAX_CHARS)throw Error('Arena specimen budget exceeded: 600K total characters');
  const rows=opts.map((option,index)=>{
    const tests=local.map(f=>{
      let actual='error';
      try{actual=C.analyzePagePair(option.recipe,f.before,f.after).outcome;}catch{}
      return {name:f.name,expected:f.expected,actual,holdout:f.holdout,
        result:kindOf({expected:f.expected,actual,holdout:f.holdout})};
    });
    return {id:'Option '+(index+1),label:option.label,recipe:option.recipe,tests};
  });
  const matrix={schema:SCHEMA,rows:rows.map(r=>({outcomes:r.tests.map(t=>({expected:t.expected,actual:t.actual,holdout:t.holdout}))}))};
  const scored=scoreMatrix(matrix);
  rows.forEach((r,i)=>r.stats=scored.rows[i].stats);
  return {schema:'progrss.arena.local.v1',rows,ranking:scored.ranking,leader:scored.leader,
    scoredCases:rows[0].stats.scored,caseCount:local.length,
    private:true,canClaimCoverage:rows[0].stats.balanced,
    note:'Results reflect ONLY manually labeled local snapshots. Using a selector as a draft does not apply or share a patch.'};
}
function publicAggregate(local){
  if(!local||local.schema!=='progrss.arena.local.v1'||!Array.isArray(local.rows)||local.rows.length>MAX_CANDIDATES)throw Error('Not a private Arena report');
  const source=local.rows.map(r=>r.stats);
  if(source.some(s=>!s||!Number.isInteger(s.scored)||!Number.isInteger(s.score)))throw Error('Malformed Arena scores');
  return {schema:PUBLIC,selfReported:true,authenticated:false,caseCount:local.caseCount,
    contenders:source.map((s,i)=>({option:i+1,score:s.score,scored:s.scored,
      pass:s.pass,falsePositive:s.falsePositive,miss:s.miss,wrongKind:s.wrongKind,error:s.error,
      holdoutTests:s.holdoutTests,holdoutPass:s.holdoutPass,quietCases:s.quietCases,changedCases:s.changedCases})),
    caution:'Only self-reported aggregates. Small counts may still disclose facts. No source URLs, selectors, raw HTML, fixture names, or fingerprints are included.'};
}
function parseCandidates(text){
  if(typeof text!=='string'||text.length>2200)throw Error('Arena candidates exceed 2200 characters');
  const lines=text.split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
  if(lines.length>MAX_CANDIDATES)throw Error('At most 8 manual contenders');
  return lines.map((line,i)=>{
    const bits=line.split('|').map(s=>s.trim());
    if(bits.length>3||!bits[0]||bits[0].length>320)throw Error('Invalid candidate line '+(i+1));
    const changes={selector:bits[0]};
    if(bits.length>1&&bits[1]!==''){
      if(!/^(?:0|[1-9][0-9]{0,4})$/.test(bits[1])||Number(bits[1])>10000)throw Error('Threshold must be 0–10000 on line '+(i+1));
      changes.threshold=Number(bits[1]);
    }
    if(bits.length>2&&bits[2]!==''){
      if(!/^(?:yes|no|true|false|on|off)$/i.test(bits[2]))throw Error('Ignore-numbers must be on/off on line '+(i+1));
      changes.ignoreNumbers=/^(yes|true|on)$/i.test(bits[2]);
    }
    return {label:'Community candidate '+(i+1),changes};
  });
}
root.ProgRSSArena=Object.freeze({SCHEMA,PUBLIC,MAX_CANDIDATES,MAX_CASES,MAX_CHARS,
  kindOf,scoreOutcomes,scoreMatrix,compare,publicAggregate,parseCandidates});
})(globalThis);
