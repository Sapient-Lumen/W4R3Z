/* ProgRSS rev0005: pure, offline Courier capsules and local review history.
 * SHA-256 checksums verify bytes/content agreement, NOT sender identity.
 * This purposely is NOT an RFC 8785/JCS implementation: the bounded ProgRSS
 * schema only permits finite integer numbers and fixed ASCII property names.
 */
(function(root){
'use strict';
const C=root.ProgRSSCore;
const SCHEMA='progrss.capsule.v1';
const MAX_ENVELOPE=690_000,MAX_INBOX=24,MAX_INBOX_CHARS=2_400_000,MAX_RECEIPTS=100;
function plain(v){return v!==null && typeof v==='object'&&!Array.isArray(v);}
function canonical(value,depth=0){
  if(depth>40)throw Error('Capsule nesting too deep');
  if(value===null)return 'null';
  if(typeof value==='string')return JSON.stringify(value);
  if(typeof value==='number'&&Number.isSafeInteger(value))return JSON.stringify(value);
  if(typeof value==='boolean')return value?'true':'false';
  if(Array.isArray(value))return '['+value.map(v=>canonical(v,depth+1)).join(',')+']';
  if(plain(value)){
    const keys=Object.keys(value).sort();
    if(keys.some(k=>['__proto__','constructor','prototype'].includes(k)))throw Error('Forbidden JSON property');
    return '{'+keys.map(k=>JSON.stringify(k)+':'+canonical(value[k],depth+1)).join(',')+'}';
  }
  throw Error('Non-JSON value in capsule');
}
// Small, deterministic SHA-256 implementation for offline file:// contexts
// where SubtleCrypto may be unavailable. Not a signature or trust mechanism.
const K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
  0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
  0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
  0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
  0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
  0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
  0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
  0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
const INITIAL=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
const rr=(x,n)=>(x>>>n)|(x<<(32-n));
function sha256(value){
  const bytes=new TextEncoder().encode(value);
  if(bytes.length>MAX_ENVELOPE+1024)throw Error('Hash input is too large');
  const length=Math.ceil((bytes.length+9)/64)*64,buf=new Uint8Array(length);buf.set(bytes);buf[bytes.length]=0x80;
  const v=new DataView(buf.buffer),bitLength=bytes.length*8;
  v.setUint32(length-8,Math.floor(bitLength/0x100000000),false);v.setUint32(length-4,bitLength>>>0,false);
  const h=INITIAL.slice(),w=new Uint32Array(64);
  for(let p=0;p<length;p+=64){
    for(let i=0;i<16;i++)w[i]=v.getUint32(p+i*4,false);
    for(let i=16;i<64;i++){
      const x=w[i-15],y=w[i-2],s0=rr(x,7)^rr(x,18)^(x>>>3),s1=rr(y,17)^rr(y,19)^(y>>>10);
      w[i]=(w[i-16]+s0+w[i-7]+s1)>>>0;
    }
    let [a,b,c,d,e,f,g,hh]=h;
    for(let i=0;i<64;i++){
      const s1=rr(e,6)^rr(e,11)^rr(e,25),ch=(e&f)^((~e)&g);
      const t1=(hh+s1+ch+K[i]+w[i])>>>0,s0=rr(a,2)^rr(a,13)^rr(a,22),maj=(a&b)^(a&c)^(b&c);
      const t2=(s0+maj)>>>0;
      hh=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;
    }
    for(const [i,x] of [a,b,c,d,e,f,g,hh].entries())h[i]=(h[i]+x)>>>0;
  }
  return h.map(x=>x.toString(16).padStart(8,'0')).join('');
}
function normalizePayload(payload){
  if(!plain(payload))throw Error('Capsule content must be a recipe bundle or patch');
  if(payload.schema===C.SCHEMA)return {kind:'recipes',payload:C.validateBundle(payload)};
  if(payload.schema===C.PATCH_SCHEMA)return {kind:'patch',payload:C.validateProposal(payload)};
  if(payload.schema===root.ProgRSSFixtureGarden?.SCHEMA)return {kind:'fixture-pack',payload:root.ProgRSSFixtureGarden.validate(payload)};
  if(payload.schema===root.ProgRSSProof?.SCHEMA)return {kind:'discovery',payload:root.ProgRSSProof.validateProof(payload)};
  if(payload.schema===root.ProgRSSLineage?.SCHEMA)return {kind:'edition',payload:root.ProgRSSLineage.validate(payload)};
  if(payload.schema===root.ProgRSSTrust?.SCHEMA)return {kind:'signed-edition',payload:root.ProgRSSTrust.validateShape(payload)};
  if(payload.schema===root.ProgRSSSignedPatch?.SCHEMA)return {kind:'signed-patch',payload:root.ProgRSSSignedPatch.validateShape(payload)};
  if(payload.schema===root.ProgRSSRotation?.SCHEMA)return {kind:'key-rotation',payload:root.ProgRSSRotation.validateShape(payload)};
  if(payload.schema===root.ProgRSSRecovery?.CHARTER)return {kind:'recovery-charter',payload:root.ProgRSSRecovery.validateCharter(payload)};
  if(payload.schema===root.ProgRSSRecovery?.PACKET)return {kind:'recovery-packet',payload:root.ProgRSSRecovery.validatePacket(payload)};
  if(payload.schema===root.ProgRSSLedger?.SCHEMA)return {kind:'charter-change',payload:root.ProgRSSLedger.validateShape(payload)};
  if(payload.schema===root.ProgRSSGossip?.HEAD)return {kind:'trust-head',payload:root.ProgRSSGossip.shapeHead(payload)};
  if(payload.schema===root.ProgRSSGossip?.SIGHT)return {kind:'trust-sighting',payload:root.ProgRSSGossip.shapeSighting(payload)};
  if([root.ProgRSSMerkle?.HEAD,root.ProgRSSMerkle?.EXT,root.ProgRSSMerkle?.INCL].includes(payload.schema)){const shape=root.ProgRSSMerkle.shape(payload);return {kind:shape.kind,payload:shape.artifact};}
  if([root.ProgRSSProofExchange?.REQUEST,root.ProgRSSProofExchange?.REPLY,root.ProgRSSProofExchange?.FORK].includes(payload.schema)){const shape=root.ProgRSSProofExchange.shape(payload);return {kind:shape.kind,payload:shape.artifact};}
  throw Error('Unsupported capsule content; private backups, raw specimens, observations and code are forbidden');
}
function contentDigest(kind,payload){return 'sha256:'+sha256(canonical({kind,payload}));}
function makeCapsule(payload,{note='',createdAt}={}){
  const normalized=normalizePayload(payload);
  if(canonical(normalized.payload)!==canonical(payload))throw Error('Unexpected/unnormalized capsule content');
  const capsule={schema:SCHEMA,kind:normalized.kind,createdAt:createdAt||new Date().toISOString(),
    note:C.text(note,240),payload:normalized.payload,digest:contentDigest(normalized.kind,normalized.payload)};
  return validateCapsule(capsule);
}
function validateCapsule(raw){
  if(!plain(raw)||raw.schema!==SCHEMA||JSON.stringify(raw).length>MAX_ENVELOPE)throw Error('Unsupported or oversized Courier capsule');
  if(Object.keys(raw).some(k=>!['schema','kind','createdAt','note','payload','digest'].includes(k)))throw Error('Unexpected capsule property');
  if(!['recipes','patch','signed-patch','discovery','edition','signed-edition','key-rotation','recovery-charter','recovery-packet','charter-change','trust-head','trust-sighting','merkle-head','merkle-consistency','merkle-inclusion','proof-request','proof-reply','fork-dossier','fixture-pack'].includes(raw.kind)||typeof raw.createdAt!=='string'||raw.createdAt.length>42||!Number.isFinite(Date.parse(raw.createdAt)) || typeof raw.note!=='string'||raw.note.length>240)throw Error('Invalid capsule metadata');
  if(typeof raw.digest!=='string'||!/^sha256:[0-9a-f]{64}$/.test(raw.digest))throw Error('Missing SHA-256 checksum');
  const normalized=normalizePayload(raw.payload);
  if(normalized.kind!==raw.kind)throw Error('Capsule kind and payload differ');
  // Do not silently strip unrecognized raw fields and claim they were reviewed.
  if(canonical(normalized.payload)!==canonical(raw.payload))throw Error('Unexpected/unnormalized capsule content');
  if(contentDigest(raw.kind,raw.payload)!==raw.digest)throw Error('Capsule checksum mismatch');
  return {schema:SCHEMA,kind:raw.kind,createdAt:raw.createdAt,note:raw.note,payload:normalized.payload,digest:raw.digest};
}
function initializeState(state){if(!Array.isArray(state.inbox))state.inbox=[];if(!Array.isArray(state.receipts))state.receipts=[];return state;}
function receive(state,input,via='file'){
  initializeState(state);
  // Older rev0004 bundles and patches can be safely carried by a new capsule.
  const capsule=input?.schema===SCHEMA?validateCapsule(input):makeCapsule(input);
  const id=capsule.digest;
  const old=state.inbox.find(e=>e.id===id||capsule.kind==='edition'&&e.capsule?.kind==='edition'&&e.capsule.payload?.digest===capsule.payload.digest);
  if(old)return {duplicate:true,entry:old};
  if(state.inbox.length>=MAX_INBOX)throw Error('Courier Inbox full (24 entries). Dismiss and delete older entries');
  const entry={id,receivedAt:new Date().toISOString(),via:['file','webrtc','local'].includes(via)?via:'file',status:'pending',capsule};
  if(JSON.stringify([...state.inbox,entry]).length>MAX_INBOX_CHARS)throw Error('Courier Inbox capacity reached (2.4M characters). Export or delete old entries');
  state.inbox.unshift(entry);
  return {duplicate:false,entry};
}
function resolve(state,id,decision,detail=''){
  initializeState(state);
  if(!['accepted','dismissed'].includes(decision))throw Error('Invalid Courier decision');
  const e=state.inbox.find(x=>x.id===id);
  if(!e)throw Error('Courier item not found');
  validateCapsule(e.capsule);
  if(e.status!=='pending')throw Error('Courier item already resolved');
  e.status=decision;
  const receipt={digest:id,kind:e.capsule.kind,action:decision,at:new Date().toISOString(),detail:C.text(detail,180)};
  state.receipts.unshift(receipt);state.receipts=state.receipts.slice(0,MAX_RECEIPTS);
  return receipt;
}
function deleteEntry(state,id){initializeState(state);const count=state.inbox.length;state.inbox=state.inbox.filter(x=>x.id!==id);return count!==state.inbox.length;}
root.ProgRSSCourier=Object.freeze({SCHEMA,MAX_ENVELOPE,MAX_INBOX,MAX_INBOX_CHARS,MAX_RECEIPTS,canonical,sha256,contentDigest,makeCapsule,validateCapsule,initializeState,receive,resolve,deleteEntry});
})(globalThis);
