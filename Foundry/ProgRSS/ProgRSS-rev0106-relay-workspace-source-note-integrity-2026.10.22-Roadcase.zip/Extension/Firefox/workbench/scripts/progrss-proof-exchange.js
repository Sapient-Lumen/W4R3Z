/* ProgRSS rev0018 · Proof Exchange / explicit missing-consistency request and fork dossiers.
 * Data-only, no timers, sockets, DOM, page snapshots, feeds, guardians or automatic trust.
 * All cryptographic validation delegates to rev0017 Merkle and owner-signed checkpoints.
 */
(function(root){
'use strict';
const M=root.ProgRSSMerkle,Q=root.ProgRSSCourier;
const REQUEST='progrss.proof-request.v1';
const REPLY='progrss.proof-reply.v1';
const FORK='progrss.fork-dossier.v1';
const NONCE=/^p18-[0-9a-f]{32}$/;
const MAX_REQUESTS=20,MAX_SIGHTINGS=80,MAX_FORKS=24;
const owns=(x,k)=>Object.prototype.hasOwnProperty.call(x,k);
function exact(x,fields){if(!x||typeof x!=='object'||Array.isArray(x)||Object.keys(x).length!==fields.length||fields.some(k=>!owns(x,k)))throw Error('Malformed or unexpected Proof Exchange fields');}
function equal(a,b){return Q.canonical(a)===Q.canonical(b);}
function sameSubject(a,b){return equal(a.subject,b.subject);}
function headShape(x){if(M.shape(x).kind!=='merkle-head')throw Error('Expected signed Merkle head');return x;}
function requestShape(x){
 exact(x,['schema','nonce','previous','current','requestedAt']);
 if(x.schema!==REQUEST||JSON.stringify(x).length>6700||!NONCE.test(x.nonce))throw Error('Invalid proof request schema, size or nonce');
 headShape(x.previous);headShape(x.current);
 if(!sameSubject(x.previous,x.current)||x.previous.treeSize>=x.current.treeSize)throw Error('Request needs ordered checkpoints of the SAME signer');
 if(typeof x.requestedAt!=='string'||!/^[0-9]{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(x.requestedAt)||!Number.isFinite(Date.parse(x.requestedAt))||new Date(x.requestedAt).toISOString()!==x.requestedAt)throw Error('Invalid request creation time');
 return x;
}
function replyShape(x){
 exact(x,['schema','request','extension']);
 if(x.schema!==REPLY||JSON.stringify(x).length>16000)throw Error('Oversized/invalid proof reply');
 requestShape(x.request);
 if(M.shape(x.extension).kind!=='merkle-consistency'||!equal(x.extension.previous,x.request.previous)||!equal(x.extension.current,x.request.current))throw Error('Proof reply changed signed checkpoints');
 return x;
}
function forkShape(x){
 exact(x,['schema','left','right']);
 if(x.schema!==FORK||JSON.stringify(x).length>6500)throw Error('Oversized/invalid fork dossier');
 headShape(x.left);headShape(x.right);
 if(!sameSubject(x.left,x.right)||x.left.treeSize!==x.right.treeSize||x.left.rootDigest===x.right.rootDigest)throw Error('Not an OWNER-SIGNED same-size fork');
 return x;
}
function shape(x){if(x?.schema===REQUEST)return {kind:'proof-request',artifact:requestShape(x)};
 if(x?.schema===REPLY)return {kind:'proof-reply',artifact:replyShape(x)};
 if(x?.schema===FORK)return {kind:'fork-dossier',artifact:forkShape(x)};
 throw Error('Unsupported Proof Exchange artifact');}
async function verify(x){const {kind}=shape(x);
 if(kind==='proof-request'){
  await M.verify(x.previous);await M.verify(x.current);
  return {kind,verified:true,nonce:x.nonce,subject:x.previous.subject.keyId,first:x.previous.treeSize,second:x.current.treeSize,meaning:'REQUEST ONLY: unsigned and requester identity not authenticated; zero automatic disclosure'};
 }
 if(kind==='proof-reply'){
  await verify(x.request);
  await M.verify(x.extension);
  return {kind,verified:true,nonce:x.request.nonce,subject:x.request.previous.subject.keyId,first:x.request.previous.treeSize,second:x.request.current.treeSize,meaning:'SIGNED ENDPOINTS + VERIFIED APPEND-ONLY PATH; does not update pin'};
 }
 await M.verify(x.left);await M.verify(x.right);
 return {kind,verified:true,subject:x.left.subject.keyId,treeSize:x.left.treeSize,roots:[x.left.rootDigest,x.right.rootDigest],meaning:'TWO VALID OWNER SIGNATURES FOR DIFFERENT ROOTS AT IDENTICAL SIZE; signed fork evidence, not a verdict about the owner\'s human identity'};
}
async function makeRequest(previous,current,{requestedAt=new Date().toISOString()}={}){
 if(!root.crypto?.getRandomValues)throw Error('Secure random generator required for private request nonce');
 const random=new Uint8Array(16);root.crypto.getRandomValues(random);
 const request={schema:REQUEST,nonce:'p18-'+[...random].map(x=>x.toString(16).padStart(2,'0')).join(''),previous,current,requestedAt};
 await verify(request);return request;
}
async function makeReply(request,events){await verify(request);
 if(!Array.isArray(events)||events.length!==request.current.treeSize)throw Error('Responder has no matching approved event-digest history');
 const extension=await M.makeExtension(request.previous,request.current,events);
 const reply={schema:REPLY,request,extension};await verify(reply);return reply;
}
async function makeFork(left,right){const ordered=[left,right].sort((a,b)=>a.rootDigest.localeCompare(b.rootDigest));
 const dossier={schema:FORK,left:ordered[0],right:ordered[1]};await verify(dossier);return dossier;}
async function compare(a,b){headShape(a);headShape(b);await M.verify(a);await M.verify(b);
 if(!sameSubject(a,b))return {relation:'DIFFERENT SUBJECTS',fork:false,needsProof:false};
 if(a.treeSize===b.treeSize)return {relation:a.rootDigest===b.rootDigest?'SAME SIGNED ROOT':'PROVABLE SIGNED FORK',fork:a.rootDigest!==b.rootDigest,needsProof:false};
 return {relation:'DIFFERENT SIZES: REQUIRE CONSISTENCY PROOF',fork:false,needsProof:true};
}
function ensureState(s){
 for(const name of ['proofRequests','proofSightings','proofForks'])if(!Array.isArray(s[name]))s[name]=[];
 return s;
}
async function stage(state,request){ensureState(state);await verify(request);
 if(state.proofRequests.some(r=>r.nonce===request.nonce))return {duplicate:true};
 if(state.proofRequests.length>=MAX_REQUESTS)throw Error('Proof request queue full; delete older requests');
 state.proofRequests.unshift({nonce:request.nonce,request,createdAt:new Date().toISOString(),status:'pending'});
 return {duplicate:false};
}
function match(state,reply){ensureState(state);replyShape(reply);
 const row=state.proofRequests.find(r=>r.nonce===reply.request.nonce&&equal(r.request,reply.request));
 return Boolean(row&&row.status==='pending');
}
async function observe(state,head){ensureState(state);headShape(head);await M.verify(head);
 const candidates=[...state.proofSightings.map(s=>s.head),...(state.merklePins||[]).map(p=>p.head)];
 const dossiers=[];
 for(const prior of candidates){
  if(!prior||!sameSubject(prior,head)||prior.treeSize!==head.treeSize||prior.rootDigest===head.rootDigest)continue;
  const dossier=await makeFork(prior,head);
  const digest=Q.contentDigest('fork-dossier',dossier);
  if(!state.proofForks.some(r=>r.digest===digest)&&!dossiers.some(r=>r.digest===digest))dossiers.push({digest,artifact:dossier,seenAt:new Date().toISOString()});
 }
 const duplicate=state.proofSightings.some(r=>equal(r.head,head));
 if(!duplicate){state.proofSightings.unshift({head,seenAt:new Date().toISOString()});state.proofSightings=state.proofSightings.slice(0,MAX_SIGHTINGS);}
 state.proofForks.unshift(...dossiers);state.proofForks=state.proofForks.slice(0,MAX_FORKS);
 return {duplicate,forks:dossiers,tracked:state.proofSightings.length};
}
async function recordFork(state,dossier){ensureState(state);await verify(dossier);
 const canonical=await makeFork(dossier.left,dossier.right),digest=Q.contentDigest('fork-dossier',canonical);
 if(state.proofForks.some(r=>r.digest===digest))return {duplicate:true,digest};
 state.proofForks.unshift({digest,artifact:canonical,seenAt:new Date().toISOString()});state.proofForks=state.proofForks.slice(0,MAX_FORKS);
 return {duplicate:false,digest};
}
root.ProgRSSProofExchange=Object.freeze({REQUEST,REPLY,FORK,MAX_REQUESTS,MAX_SIGHTINGS,MAX_FORKS,shape,verify,makeRequest,makeReply,makeFork,compare,ensureState,stage,match,observe,recordFork});
})(globalThis);
