/* ProgRSS shared parser facade.
   Browser-neutral parsing semantics; transport is chosen by the background runtime. */
(function(root){
'use strict';

const C = root.ProgRSSCore;
const S = root.ProgRSSScout;

function requireEngines() {
  if (!C || !S) throw new Error('ProgRSS parser engines are unavailable.');
}

function cleanPreviewText(value, limit = 240) {
  const clean = String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
  return clean.length > limit ? `${clean.slice(0, Math.max(0, limit - 1)).trimEnd()}…` : clean;
}

function previewContentKind(item = {}) {
  const body = cleanPreviewText(item.body, 12_000);
  const summary = cleanPreviewText(item.summary, 12_000);
  if (body && !item.bodyIsSummary && !item.bodyOmitted) return 'full-text';
  if (body || summary) return 'summary';
  return 'title-only';
}

function feedPreview(feed = {}) {
  const items = Array.isArray(feed.items) ? feed.items.slice(0, 3) : [];
  const examples = items.map(item => ({
    title: cleanPreviewText(item?.title, 240) || 'Untitled update',
    url: cleanPreviewText(item?.url, 2_048),
    published: cleanPreviewText(item?.published, 80),
    content: previewContentKind(item),
    language: cleanPreviewText(item?.language, 100),
    titleLanguage: cleanPreviewText(item?.titleLanguage || item?.language, 100)
  }));
  return {
    examples,
    exampleCount: examples.length,
    fullTextCount: examples.filter(item => item.content === 'full-text').length,
    summaryCount: examples.filter(item => item.content === 'summary').length,
    datedCount: examples.filter(item => item.published).length
  };
}

function inspectResource(data = {}) {
  requireEngines();
  try {
    const feed = C.parseFeed(data.body, data.url);
    const preview = feedPreview(feed);
    return {
      kind: 'feed', url: data.url, title: feed.title, titleLanguage: feed.titleLanguage || '', language: feed.language || '', feedType: feed.type,
      feedUrl: feed.feedUrl || '', itemCount: feed.items.length,
      previewItems: preview.examples,
      previewCount: preview.exampleCount,
      previewFullTextCount: preview.fullTextCount,
      previewSummaryCount: preview.summaryCount,
      previewDatedCount: preview.datedCount,
      edition: feed.edition || null
    };
  } catch (error) {
    const mime = String(data.contentType || '').split(';', 1)[0].trim().toLowerCase();
    const feedLikeMime = /^(?:application\/(?:rss\+xml|atom\+xml|feed\+json|json|xml)|text\/xml)$/.test(mime);
    const feedLikeBody = /^\s*(?:<\?xml\b|<rss\b|<feed\b|\{)/i.test(String(data.body || '').slice(0, 256));
    if (feedLikeMime || feedLikeBody) throw error;
    const scan = S.scanMarkup(data.body, data.url, {linkHeader: data.linkHeader || ''});
    return {
      kind: 'html',
      url: scan.siteUrl,
      title: scan.title || new URL(data.url).hostname,
      candidates: scan.candidates || [],
      sharedFolders: scan.sharedFolders || [],
      publicationChoices: scan.publicationChoices || null,
      recommendations: scan.recommendations || []
    };
  }
}

function handle(type, data = {}) {
  requireEngines();
  if (type === 'parse-feed') return C.parseFeed(data.body, data.url);
  if (type === 'parse-opml') return C.parseOPMLDetailed(data.body);
  if (type === 'extract-page') return C.extractPage(data.body, data.source);
  if (type === 'repair-page-watch') return C.pageWatchRepairProposals(data.body, data.source);
  if (type === 'inspect-resource') return inspectResource(data);
  throw new Error('Unknown parser request.');
}

root.ProgRSSParser = Object.freeze({handle, inspectResource});
})(globalThis);
