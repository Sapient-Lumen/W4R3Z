/* ProgRSS rev0070 vault: local-only IndexedDB persistence with a WebStorage fallback.
   No network, no library, no donor code. Parts updated atomically per revision. */
(function(root){
'use strict';
const F=root.ProgRSSSharedFolder;
const DB_NAME='progrss-vault', DB_VERSION=1, STORE='parts', CURRENT='progrss.rev0003.state', LEGACY='progrss.rev0002.state';
// IndexedDB part keys are additive; existing v2/v3 state migrates without changing its browser origin.
const PARTS=['_revision','version','sources','collections','items','snapshots','fixtures','inbox','receipts','retiredReceipts','subscriptions','publications','patchPins','keyRotations','recoveryPolicies','recoveryReceipts','charterHistory','charterClaims','gossipCards','witnessPins','merklePins','merkleReceipts','proofRequests','proofSightings','proofForks','fixturePacks','transferUndo','sourceRepairUndo','receiptRetirementUndo','sharedFolderUpdateUndo','pageWatchRepairUndo'];
const blank=()=>({_revision:0,version:17,sources:[],collections:[],items:[],snapshots:{},fixtures:[],inbox:[],receipts:[],retiredReceipts:[],subscriptions:[],publications:[],patchPins:[],keyRotations:[],recoveryPolicies:[],recoveryReceipts:[],charterHistory:[],charterClaims:[],gossipCards:[],witnessPins:[],merklePins:[],merkleReceipts:[],proofRequests:[],proofSightings:[],proofForks:[],fixturePacks:[],transferUndo:null,sourceRepairUndo:null,receiptRetirementUndo:null,sharedFolderUpdateUndo:null,pageWatchRepairUndo:null});
let db=null,mode='memory',writer=Promise.resolve(),known=new Map(),warning='';
let initialRecordExists=null,initialRecordValid=null,lastRecordExists=null,lastRecordValid=null,openedWithoutRecord=false;
function storageReason(error){
  const name=String(error?.name||'');
  const message=String(error?.message||error||'').toLowerCase();
  if(name==='QuotaExceededError'||/quota|disk full|storage full|no space|out of space/.test(message))return 'quota';
  if(name==='NotReadableError'||name==='UnknownError'||/\bi\/o\b|input\/output|disk error|write failed/.test(message))return 'io';
  if(name==='AbortError'||/transaction.*abort|write aborted/.test(message))return 'aborted';
  if(name==='InvalidStateError'||mode==='memory'||/unavailable|not available|closed unexpectedly/.test(message))return 'unavailable';
  return 'unknown';
}
function writeFailure(error,message='Browser storage could not save this change.'){
  const detail=String(error?.message||error||'').trim();
  const failed=Error(detail?`${message} ${detail}`:message);
  failed.code='VAULT_WRITE_FAILED';
  failed.storageReason=storageReason(error);
  failed.storageName=String(error?.name||'Error').slice(0,80);
  return failed;
}
function localGet(){
  try{
    const raw=localStorage.getItem(CURRENT)||localStorage.getItem(LEGACY);
    return raw?JSON.parse(raw):null;
  }catch{return null;}
}
function languageTag(value){
  const raw=String(value == null ? '' : value).trim();
  return raw&&raw.length<=100&&!/[\u0000-\u0020\u007f]/.test(raw)&&/^[A-Za-z]{1,8}(?:-[A-Za-z0-9]{1,8})*$/.test(raw)?raw.toLowerCase():'';
}
function boundedNumber(value,max=1_000_000){
  const number=Number(value);
  return Number.isFinite(number)&&number>=0?Math.min(max,Math.floor(number)):0;
}
function normalizePageChange(raw){
  if(!raw||typeof raw!=='object'||Array.isArray(raw)||raw.schema!=='progrss.page-change.v1')return null;
  const kind=String(raw.kind||'');
  const mode=String(raw.mode||'');
  if(!['entry-added','entry-changed','entry-removed','text-changed'].includes(kind)||!['cards','region'].includes(mode))return null;
  const change={schema:'progrss.page-change.v1',kind,mode,
    summary:String(raw.summary||'').replace(/\s+/g,' ').trim().slice(0,500),
    before:String(raw.before||'').replace(/\s+/g,' ').trim().slice(0,1200),
    after:String(raw.after||'').replace(/\s+/g,' ').trim().slice(0,1200),
    removed:String(raw.removed||'').replace(/\s+/g,' ').trim().slice(0,1000),
    added:String(raw.added||'').replace(/\s+/g,' ').trim().slice(0,1000),
    removedWords:boundedNumber(raw.removedWords,20_000),addedWords:boundedNumber(raw.addedWords,20_000),
    delta:boundedNumber(raw.delta),threshold:boundedNumber(raw.threshold,120_000),ignoreNumbers:Boolean(raw.ignoreNumbers)};
  if(!change.summary&&!change.before&&!change.after&&!change.removed&&!change.added)return null;
  return change;
}
function normalizeWatchRepair(raw){
  if(!raw||typeof raw!=='object'||Array.isArray(raw)||raw.schema!=='progrss.page-watch.repair.v1')return null;
  const reason=String(raw.reason||'');
  if(!['invalid-selector','no-match','structure-changed','unstable-shape'].includes(reason))return null;
  const noticedAt=String(raw.noticedAt||'');
  return {schema:'progrss.page-watch.repair.v1',reason,noticedAt:Number.isFinite(Date.parse(noticedAt))?noticedAt:'',message:String(raw.message||'').replace(/\s+/g,' ').trim().slice(0,300)};
}
function normalizeWatchHealth(raw){
  if(!raw||typeof raw!=='object'||Array.isArray(raw)||raw.schema!=='progrss.page-watch.health.v1')return null;
  const status=String(raw.status||''),reason=String(raw.reason||'');
  if(!['steady','changed-shape','attention'].includes(status)||!['baseline','matched','entry-count-shift','text-size-shift','structure-changed','confirmed-shape-change','returned-to-steady','unstable-shape'].includes(reason))return null;
  const checkedAt=String(raw.checkedAt||''),metrics={};
  if(raw.metrics&&typeof raw.metrics==='object'&&!Array.isArray(raw.metrics)){
    for(const key of ['previousEntries','currentEntries','previousCharacters','currentCharacters','matchCount']){
      if(raw.metrics[key]!==undefined)metrics[key]=boundedNumber(raw.metrics[key],2_000_000);
    }
  }
  return {schema:'progrss.page-watch.health.v1',status,reason,checkedAt:Number.isFinite(Date.parse(checkedAt))?checkedAt:'',message:String(raw.message||'').replace(/\s+/g,' ').trim().slice(0,300),metrics};
}
function normalizeWatchStability(raw){
  if(!raw||typeof raw!=='object'||Array.isArray(raw)||raw.schema!=='progrss.page-watch.stability.v1'||raw.status!=='pending')return null;
  const reason=String(raw.reason||'');if(!['entry-count-shift','text-size-shift'].includes(reason))return null;
  const firstSeenAt=String(raw.firstSeenAt||''),lastSeenAt=String(raw.lastSeenAt||'');
  const recipeVersion=Math.max(1,Math.min(10000,Math.floor(Number(raw.recipeVersion)||1)));
  const observations=Math.max(1,Math.min(2,Math.floor(Number(raw.observations)||1))),metrics={};
  if(raw.metrics&&typeof raw.metrics==='object'&&!Array.isArray(raw.metrics)){
    for(const key of ['previousEntries','currentEntries','previousCharacters','currentCharacters','matchCount']){
      if(raw.metrics[key]!==undefined)metrics[key]=boundedNumber(raw.metrics[key],2_000_000);
    }
  }
  return {schema:'progrss.page-watch.stability.v1',status:'pending',reason,recipeVersion,
    firstSeenAt:Number.isFinite(Date.parse(firstSeenAt))?firstSeenAt:'',lastSeenAt:Number.isFinite(Date.parse(lastSeenAt))?lastSeenAt:'',observations,
    message:String(raw.message||'').replace(/\s+/g,' ').trim().slice(0,300),metrics};
}
function normalizeSources(rows){
  return rows.slice(0,200).filter(row=>row&&typeof row==='object'&&!Array.isArray(row)).map(row=>{
    const source={...row};
    for(const key of ['language','titleLanguage']){const value=languageTag(source[key]);if(value)source[key]=value;else delete source[key];}
    if(String(source.textRetention||'').toLowerCase()==='summary')source.textRetention='summary';else delete source.textRetention;
    const watchRepair=normalizeWatchRepair(source.watchRepair);if(source.type==='page'&&watchRepair)source.watchRepair=watchRepair;else delete source.watchRepair;
    const watchHealth=normalizeWatchHealth(source.watchHealth);if(source.type==='page'&&watchHealth)source.watchHealth=watchHealth;else delete source.watchHealth;
    const watchStability=normalizeWatchStability(source.watchStability);if(source.type==='page'&&watchStability)source.watchStability=watchStability;else delete source.watchStability;
    return source;
  });
}
function normalizeCollections(rows){
  return rows.slice(0,200).filter(row=>row&&typeof row==='object'&&!Array.isArray(row)).map(row=>{
    const collection={...row};
    if(collection.sharedFolderOrigin!==undefined){
      const origin=F?.normalizeOrigin?.(collection.sharedFolderOrigin,false);
      if(origin)collection.sharedFolderOrigin=origin;else delete collection.sharedFolderOrigin;
    }
    return collection;
  });
}
function normalizeItems(rows){
  return rows.slice(0,1200).filter(row=>row&&typeof row==='object'&&!Array.isArray(row)).map(row=>{
    const item={...row};
    if(typeof item.body==='string')item.body=item.body.slice(0,12000);else delete item.body;
    if(item.bodyIsSummary!==undefined)item.bodyIsSummary=Boolean(item.bodyIsSummary);
    if(item.bodyOmitted===true)item.bodyOmitted=true;else delete item.bodyOmitted;
    for(const key of ['language','titleLanguage','summaryLanguage','bodyLanguage']){const value=languageTag(item[key]);if(value)item[key]=value;else delete item[key];}
    const change=normalizePageChange(item.change);if(change)item.change=change;else delete item.change;
    return item;
  });
}
function validRaw(raw){
  return Boolean(raw&&[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17].includes(raw.version)&&Array.isArray(raw.sources)&&Array.isArray(raw.collections)&&Array.isArray(raw.items));
}
function noteRead(exists,raw,{initial=false,openedEmpty=false}={}){
  const valid=exists?validRaw(raw):null;
  lastRecordExists=Boolean(exists);lastRecordValid=valid;openedWithoutRecord=Boolean(openedEmpty);
  if(initialRecordExists===null||initial){initialRecordExists=Boolean(exists);initialRecordValid=valid;}
}
function normalize(raw){
  if(!validRaw(raw))return blank();
  const undo=raw.transferUndo;
  const undoState=undo&&undo.previousState;
  const transferUndo=undo&&typeof undo==='object'&&!Array.isArray(undo)&&undo.schema==='progrss.transfer.undo.v1'&&
    typeof undo.createdAt==='string'&&typeof undo.expiresAt==='string'&&Number.isFinite(Date.parse(undo.expiresAt))&&
    undoState&&typeof undoState==='object'&&!Array.isArray(undoState)&&!undoState.transferUndo&&
    [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17].includes(undoState.version)&&Array.isArray(undoState.sources)&&undoState.sources.length<=200&&
    Array.isArray(undoState.collections)&&undoState.collections.length<=200&&Array.isArray(undoState.items)&&undoState.items.length<=1200?undo:null;
  const repair=raw.sourceRepairUndo;
  const repairState=repair&&repair.previousState;
  const sourceRepairUndo=repair&&typeof repair==='object'&&!Array.isArray(repair)&&repair.schema==='progrss.source.repair.undo.v1'&&
    typeof repair.createdAt==='string'&&typeof repair.expiresAt==='string'&&Number.isFinite(Date.parse(repair.expiresAt))&&
    Number.isSafeInteger(repair.expectedRevision)&&repair.expectedRevision>=0&&
    repairState&&typeof repairState==='object'&&!Array.isArray(repairState)&&!repairState.sourceRepairUndo&&
    [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17].includes(repairState.version)&&Array.isArray(repairState.sources)&&repairState.sources.length<=200&&
    Array.isArray(repairState.collections)&&repairState.collections.length<=200&&Array.isArray(repairState.items)&&repairState.items.length<=1200?repair:null;
  const receiptUndo=raw.receiptRetirementUndo;
  const receiptRetirementUndo=receiptUndo&&typeof receiptUndo==='object'&&!Array.isArray(receiptUndo)&&receiptUndo.schema==='progrss.receipt.retirement.undo.v1'&&
    typeof receiptUndo.createdAt==='string'&&typeof receiptUndo.expiresAt==='string'&&Number.isFinite(Date.parse(receiptUndo.expiresAt))&&
    Number.isSafeInteger(receiptUndo.expectedRevision)&&receiptUndo.expectedRevision>=0&&Number.isInteger(receiptUndo.originalIndex)&&receiptUndo.originalIndex>=0&&
    typeof receiptUndo.retirementId==='string'&&receiptUndo.retirementId.length<=220&&receiptUndo.receipt&&typeof receiptUndo.receipt==='object'&&!Array.isArray(receiptUndo.receipt)&&
    receiptUndo.receipt.schema==='progrss.recipe.graft.receipt.v1'?receiptUndo:null;
  const sharedUndo=raw.sharedFolderUpdateUndo;
  const sharedUndoState=sharedUndo&&sharedUndo.previousState;
  const sharedFolderUpdateUndo=sharedUndo&&typeof sharedUndo==='object'&&!Array.isArray(sharedUndo)&&sharedUndo.schema==='progrss.shared-folder.update.undo.v1'&&
    typeof sharedUndo.createdAt==='string'&&typeof sharedUndo.expiresAt==='string'&&Number.isFinite(Date.parse(sharedUndo.expiresAt))&&
    Number.isSafeInteger(sharedUndo.expectedRevision)&&sharedUndo.expectedRevision>=0&&
    sharedUndoState&&typeof sharedUndoState==='object'&&!Array.isArray(sharedUndoState)&&!sharedUndoState.sharedFolderUpdateUndo&&
    [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17].includes(sharedUndoState.version)&&Array.isArray(sharedUndoState.sources)&&sharedUndoState.sources.length<=200&&
    Array.isArray(sharedUndoState.collections)&&sharedUndoState.collections.length<=200&&Array.isArray(sharedUndoState.items)&&sharedUndoState.items.length<=1200?sharedUndo:null;
  const pageUndo=raw.pageWatchRepairUndo;
  const pageUndoState=pageUndo&&pageUndo.previousState;
  const pageWatchRepairUndo=pageUndo&&typeof pageUndo==='object'&&!Array.isArray(pageUndo)&&pageUndo.schema==='progrss.page-watch.repair.undo.v1'&&
    typeof pageUndo.createdAt==='string'&&typeof pageUndo.expiresAt==='string'&&Number.isFinite(Date.parse(pageUndo.expiresAt))&&
    Number.isSafeInteger(pageUndo.expectedRevision)&&pageUndo.expectedRevision>=0&&typeof pageUndo.sourceId==='string'&&pageUndo.sourceId.length<=300&&
    pageUndoState&&typeof pageUndoState==='object'&&!Array.isArray(pageUndoState)&&!pageUndoState.pageWatchRepairUndo&&
    [2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17].includes(pageUndoState.version)&&Array.isArray(pageUndoState.sources)&&pageUndoState.sources.length<=200&&
    Array.isArray(pageUndoState.collections)&&pageUndoState.collections.length<=200&&Array.isArray(pageUndoState.items)&&pageUndoState.items.length<=1200?pageUndo:null;
  const retiredReceipts=Array.isArray(raw.retiredReceipts)?raw.retiredReceipts.filter(row=>row&&typeof row==='object'&&!Array.isArray(row)&&
    row.schema==='progrss.retired.graft-receipt.v1'&&typeof row.id==='string'&&row.id.length<=220&&typeof row.retiredAt==='string'&&
    typeof row.originalDigest==='string'&&/^[0-9a-f]{64}$/.test(row.originalDigest)&&row.originalReceipt&&typeof row.originalReceipt==='object'&&!Array.isArray(row.originalReceipt)&&
    row.originalReceipt.schema==='progrss.recipe.graft.receipt.v1').slice(0,64):[];
  return {_revision:Number.isSafeInteger(raw._revision)&&raw._revision>=0?raw._revision:0,version:17,sources:normalizeSources(raw.sources),collections:normalizeCollections(raw.collections),items:normalizeItems(raw.items),
    snapshots:raw.snapshots&&typeof raw.snapshots==='object'&&!Array.isArray(raw.snapshots)?raw.snapshots:{},
    fixtures:Array.isArray(raw.fixtures)?raw.fixtures.slice(0,16):[],
    inbox:Array.isArray(raw.inbox)?raw.inbox.slice(0,24):[],receipts:Array.isArray(raw.receipts)?raw.receipts.slice(0,100):[],retiredReceipts,
    subscriptions:Array.isArray(raw.subscriptions)?raw.subscriptions.slice(0,12):[],publications:Array.isArray(raw.publications)?raw.publications.slice(0,24):[],patchPins:Array.isArray(raw.patchPins)?raw.patchPins.slice(0,96):[],
    keyRotations:Array.isArray(raw.keyRotations)?raw.keyRotations.slice(0,60):[],
    recoveryPolicies:Array.isArray(raw.recoveryPolicies)?raw.recoveryPolicies.slice(0,32):[],
    recoveryReceipts:Array.isArray(raw.recoveryReceipts)?raw.recoveryReceipts.slice(0,80):[],
    charterHistory:Array.isArray(raw.charterHistory)?raw.charterHistory.slice(0,160):[],
    charterClaims:Array.isArray(raw.charterClaims)?raw.charterClaims.slice(0,128):[],
    gossipCards:Array.isArray(raw.gossipCards)?raw.gossipCards.slice(0,128):[],
    witnessPins:Array.isArray(raw.witnessPins)?raw.witnessPins.slice(0,64):[],
    merklePins:Array.isArray(raw.merklePins)?raw.merklePins.slice(0,32):[],
    merkleReceipts:Array.isArray(raw.merkleReceipts)?raw.merkleReceipts.slice(0,96):[],
    proofRequests:Array.isArray(raw.proofRequests)?raw.proofRequests.slice(0,20):[],
    proofSightings:Array.isArray(raw.proofSightings)?raw.proofSightings.slice(0,80):[],
    proofForks:Array.isArray(raw.proofForks)?raw.proofForks.slice(0,24):[],
    fixturePacks:Array.isArray(raw.fixturePacks)?raw.fixturePacks.slice(0,12):[],
    transferUndo,sourceRepairUndo,receiptRetirementUndo,sharedFolderUpdateUndo,pageWatchRepairUndo};
}
function idbOpen(){return new Promise((resolve,reject)=>{
  if(!root.indexedDB)return reject(Error('IndexedDB unavailable'));
  let req;
  try{req=root.indexedDB.open(DB_NAME,DB_VERSION);}catch(err){reject(err);return;}
  req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains(STORE))d.createObjectStore(STORE);};
  req.onerror=()=>reject(req.error||Error('IndexedDB open failed'));
  req.onblocked=()=>reject(Error('IndexedDB upgrade is blocked by another tab'));
  req.onsuccess=()=>resolve(req.result);
});}
function idbRead(d){return new Promise((resolve,reject)=>{
  const result={};let pending=PARTS.length;
  const tx=d.transaction(STORE,'readonly'),store=tx.objectStore(STORE);
  for(const key of PARTS){const req=store.get(key);req.onsuccess=()=>{if(req.result!==undefined)result[key]=req.result;pending--;};}
  tx.oncomplete=()=>resolve({exists:result.version!==undefined,state:result});
  tx.onerror=()=>reject(tx.error||Error('IndexedDB read failed'));
  tx.onabort=()=>reject(tx.error||Error('IndexedDB read aborted'));
});}
function conflict(){
  warning='ProgRSS changed in another open view. Reload this view before saving so newer work is not overwritten.';
  const err=Error(warning);err.code='STALE_VAULT';return err;
}
function idbWrite(state){
  writer=writer.catch(()=>{}).then(()=>new Promise((resolve,reject)=>{
    const base=Number.isSafeInteger(state._revision)&&state._revision>=0?state._revision:0;
    const before=new Map(PARTS.filter(p=>p!=='_revision').map(p=>[p,JSON.stringify(state[p])]));
    const changes=[...before.keys()].filter(p=>known.get(p)!==before.get(p));
    if(!changes.length)return resolve();
    let tx,settled=false;
    const rejectOnce=err=>{if(settled)return;settled=true;reject(err);};
    try{
      tx=db.transaction(STORE,'readwrite');const store=tx.objectStore(STORE),req=store.get('_revision');
      req.onerror=()=>{try{tx.abort();}catch{}rejectOnce(req.error||Error('IndexedDB revision read failed'));};
      req.onsuccess=()=>{
        const current=Number.isSafeInteger(req.result)&&req.result>=0?req.result:0;
        if(current!==base){try{tx.abort();}catch{}rejectOnce(conflict());return;}
        const next=base+1;
        try{for(const key of changes)store.put(JSON.parse(before.get(key)),key);store.put(next,'_revision');}
        catch(err){try{tx.abort();}catch{}rejectOnce(err);return;}
        tx.oncomplete=()=>{if(settled)return;settled=true;state._revision=next;for(const key of changes)known.set(key,before.get(key));known.set('_revision',JSON.stringify(next));resolve();};
      };
    }catch(err){rejectOnce(err);return;}
    tx.onerror=()=>rejectOnce(tx.error||Error('IndexedDB write failed'));
    tx.onabort=()=>rejectOnce(tx.error||Error('IndexedDB write aborted'));
  }));
  return writer;
}
function idbProbe(){
  writer=writer.catch(()=>{}).then(()=>new Promise((resolve,reject)=>{
    let tx,settled=false;
    const rejectOnce=err=>{if(settled)return;settled=true;reject(err);};
    try{
      tx=db.transaction(STORE,'readwrite');
      const store=tx.objectStore(STORE),key='__progrss_write_probe__';
      store.put(Date.now(),key);store.delete(key);
      tx.oncomplete=()=>{if(settled)return;settled=true;resolve(true);};
    }catch(err){rejectOnce(err);return;}
    tx.onerror=()=>rejectOnce(tx.error||Error('IndexedDB test write failed'));
    tx.onabort=()=>rejectOnce(tx.error||Error('IndexedDB test write aborted'));
  }));
  return writer;
}
function localSave(state){
  try{
    const current=normalize(localGet())._revision,base=Number.isSafeInteger(state._revision)&&state._revision>=0?state._revision:0;
    if(current!==base)throw conflict();
    const next=base+1,serialized=JSON.stringify({...state,_revision:next});
    localStorage.setItem(CURRENT,serialized);state._revision=next;return true;
  }catch(err){
    if(err?.code==='STALE_VAULT')throw err;
    warning='Browser storage could not save a change. The last saved library remains available; export a private backup now.';
    throw writeFailure(err,'Browser storage could not save this change.');
  }
}
function remember(raw){known.clear();for(const key of PARTS)if(raw[key]!==undefined)known.set(key,JSON.stringify(raw[key]));}
async function init(){
  if(db){const saved=await idbRead(db);noteRead(saved.exists,saved.state);remember(saved.state);warning='';return normalize(saved.state);}
  if(mode==='localStorage'){
    if(/another open view/i.test(warning))warning='';
    const raw=localGet();noteRead(Boolean(raw),raw,{initial:initialRecordExists===null});return normalize(raw);
  }
  const old=localGet();
  try{
    db=await idbOpen();let saved=await idbRead(db);
    mode='indexeddb';
    const migrated=Boolean(!saved.exists&&old);
    noteRead(saved.exists||migrated,saved.exists?saved.state:old,{initial:initialRecordExists===null,openedEmpty:!saved.exists&&!old});
    let state=normalize(saved.exists?saved.state:old);
    if(saved.exists)remember(saved.state);
    else{
      // _revision coordinates one storage backend; it is reset while migrating
      // fallback data into a newly created IndexedDB vault.
      state._revision=0;
      try{await idbWrite(state);}
      catch(err){
        if(err?.code!=='STALE_VAULT')throw err;
        // Another view may have initialized the empty database first. Join its
        // committed revision instead of falling back to a second storage silo.
        saved=await idbRead(db);if(!saved.exists)throw err;
        state=normalize(saved.state);remember(saved.state);noteRead(true,saved.state);
      }
      lastRecordExists=true;lastRecordValid=true;
    }
    warning='';
    db.onclose=()=>{db=null;mode='memory';warning='Vault closed unexpectedly. Export a backup.';};
    return state;
  }catch(err){try{db?.close();}catch{}db=null;
    warning='IndexedDB not available ('+String(err?.message||err).slice(0,100)+'). Browser storage varies on file://.';
    let probe=false;try{localStorage.setItem('__progrss_probe__','1');localStorage.removeItem('__progrss_probe__');probe=true;}catch{}
    mode=probe?'localStorage':'memory';noteRead(Boolean(old),old,{initial:initialRecordExists===null});return normalize(old);
  }
}
function save(state){
  if(mode==='indexeddb'&&db)return idbWrite(state).catch(err=>{
    if(err?.code==='STALE_VAULT')throw err;
    warning='Browser storage could not save a change. The last saved library remains available; export a private backup now.';
    throw writeFailure(err,'Browser storage could not save this change.');
  });
  if(mode==='localStorage')return Promise.resolve().then(()=>localSave(state));
  return Promise.reject(writeFailure(Error('Browser storage is unavailable.'),'Browser storage is unavailable.'));
}
function probe(){
  if(mode==='indexeddb'&&db)return idbProbe().then(()=>true).catch(err=>{
    warning='Browser storage still cannot accept a test write.';
    throw writeFailure(err,'Browser storage still cannot accept a test write.');
  });
  if(mode==='localStorage')return Promise.resolve().then(()=>{
    const key='__progrss_write_probe__';
    try{localStorage.setItem(key,String(Date.now()));localStorage.removeItem(key);return true;}
    catch(err){warning='Browser storage still cannot accept a test write.';throw writeFailure(err,'Browser storage still cannot accept a test write.');}
  });
  return Promise.reject(writeFailure(Error('Browser storage is unavailable.'),'Browser storage is unavailable.'));
}
function info(){return {mode,warning,initialRecordExists,initialRecordValid,recordExists:lastRecordExists,recordValid:lastRecordValid,openedWithoutRecord};}
root.ProgRSSVault=Object.freeze({init,save,probe,info,normalize});
})(globalThis);
