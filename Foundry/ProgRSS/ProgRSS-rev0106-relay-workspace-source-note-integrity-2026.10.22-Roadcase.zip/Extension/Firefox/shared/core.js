/* ProgRSS rev0004: deterministic browser core. No network, DOM mutations or storage on load. */
(function (root) {
'use strict';
const SCHEMA = 'progrss.bundle.v1';
const PAGE_WATCH_REPAIR_SCHEMA = 'progrss.page-watch.repair.v1';
const PAGE_WATCH_HEALTH_SCHEMA = 'progrss.page-watch.health.v1';
const PAGE_WATCH_STABILITY_SCHEMA = 'progrss.page-watch.stability.v1';
const LIMIT = { source: 200, collection: 200, items: 1200, characters: 2_000_000, body: 12_000, bundle: 650_000, edition: 250_000, fixtures: 16, fixtureChars: 160_000 };
const FOLDER_EDITION_SCHEMA='progrss.folder-edition.v1';
function uid(prefix='id') { return prefix + '-' + (root.crypto && typeof root.crypto.randomUUID==='function' ? root.crypto.randomUUID() : Math.random().toString(36).slice(2)+Date.now().toString(36)); }
function safeUrl(raw, base) {
  if (typeof raw !== 'string' || raw.length > 2048 || !raw.trim() || /[\u0000-\u001f\u007f]/.test(raw)) throw Error('A valid HTTP(S) URL is required');
  const u = new URL(raw, base);
  if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password || !u.hostname) throw Error('Only credential-free HTTP(S) links are supported');
  u.hash = ''; return u.href;
}
function text(value, limit=1000) { return String(value == null ? '' : value).replace(/\s+/g,' ').trim().slice(0,limit); }
function languageTag(value) {
  const raw=String(value == null ? '' : value).trim();
  if(!raw||raw.length>100||/[\u0000-\u0020\u007f]/.test(raw)||!/^[A-Za-z]{1,8}(?:-[A-Za-z0-9]{1,8})*$/.test(raw))return '';
  return raw.toLowerCase();
}
function xmlLanguage(el) {
  for(let node=el;node&&node.nodeType===1;node=node.parentElement){
    const has=node.hasAttributeNS?.('http://www.w3.org/XML/1998/namespace','lang')||node.hasAttribute?.('xml:lang');
    if(has)return languageTag(node.getAttributeNS?.('http://www.w3.org/XML/1998/namespace','lang')||node.getAttribute?.('xml:lang')||'');
  }
  return '';
}
function bodyText(value,limit=LIMIT.body) {
  let raw=String(value == null ? '' : value).replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ');
  raw=raw.split('\n').map(line=>line.replace(/[\t ]+/g,' ').trim()).join('\n');
  return raw.replace(/\n{3,}/g,'\n\n').trim().slice(0,limit);
}
const READING_BLOCKS=new Set(['address','article','aside','blockquote','dd','div','dl','dt','figcaption','figure','footer','h1','h2','h3','h4','h5','h6','header','hr','li','main','nav','ol','p','pre','section','table','tbody','td','tfoot','th','thead','tr','ul']);
const READING_PARAGRAPHS=new Set(['address','blockquote','dd','dt','figcaption','h1','h2','h3','h4','h5','h6','hr','li','p','pre','tr']);
function readingTreeText(root,limit=LIMIT.body) {
  let out='';
  function add(value){if(out.length<limit*2)out+=value;}
  function walk(node){
    if(!node)return;
    if(node.nodeType===3){add(node.nodeValue||'');return;}
    if(node.nodeType!==1)return;
    const name=String(node.localName||node.nodeName||'').toLowerCase();
    if(['script','style','template','iframe','object','svg','video','audio','img','picture','source','track','link','embed','base'].includes(name))return;
    if(name==='br'){add('\n');return;}
    const block=READING_BLOCKS.has(name);
    if(block&&out&&!out.endsWith('\n'))add('\n');
    if(name==='li')add('• ');
    for(const child of Array.from(node.childNodes||[]))walk(child);
    if(block){
      if(READING_PARAGRAPHS.has(name))add('\n\n');
      else if(!out.endsWith('\n'))add('\n');
    }
  }
  walk(root);
  return bodyText(out,limit);
}
function htmlText(value,limit=1200) {
  const raw=String(value || '');
  if(!raw)return '';
  try{
    const doc=new DOMParser().parseFromString('<!doctype html><body>'+staticHtml(raw),'text/html');
    return readingTreeText(doc.body,limit);
  }catch{
    return bodyText(raw.replace(/<[^>]*>/g,' ').replace(/&nbsp;|&#160;/gi,' ').replace(/&amp;/gi,'&').replace(/&lt;/gi,'<').replace(/&gt;/gi,'>'),limit);
  }
}
function atomContentText(element,limit=LIMIT.body) {
  if(!element||element.getAttribute?.('src'))return '';
  const type=String(element.getAttribute?.('type')||'text').toLowerCase();
  if(type==='html')return htmlText(element.textContent||'',limit);
  if(type==='xhtml')return readingTreeText(element,limit);
  return bodyText(element.textContent||'',limit);
}
function unique(items) { const ids=new Set(); return items.filter(i=>{let key=['changed','removed'].includes(i.kind) ? i.id : (i.url || i.id || (i.sourceId+'::'+i.title)); if(ids.has(key))return false; ids.add(key); return true;}); }
function filterMatch(item, rule) {
  let blob = (item.title+' '+(item.summary||'')+' '+(item.body||'')).toLocaleLowerCase();
  const terms = s=>String(s||'').split(',').map(v=>v.trim().toLocaleLowerCase()).filter(Boolean);
  const needed=terms(rule.include), excluded=terms(rule.exclude);
  return (!needed.length || needed.some(x=>blob.includes(x))) && !excluded.some(x=>blob.includes(x));
}
function namedChildren(el,name) {
  const wanted=String(name||'').toLowerCase();
  const candidates=Array.from(el?.children||[]).filter(node=>node.localName?.toLowerCase()===wanted);
  const parentNamespace=el?.namespaceURI||'';
  const preferred=candidates.filter(node=>(node.namespaceURI||'')===parentNamespace);
  return preferred.length?preferred:candidates;
}
function getChild(el, name) { return namedChildren(el,name)[0]||null; }
function childText(el,name) { return getChild(el,name)?.textContent?.trim()||''; }
function bestDate(val) { let n=Date.parse(val||''); return Number.isFinite(n) ? new Date(n).toISOString() : ''; }
function folderEditionInfo(doc) {
  if(!doc||typeof doc!=='object'||Array.isArray(doc)||doc.version!=='https://jsonfeed.org/version/1.1')return null;
  const meta=doc._progrss;
  const allowed=new Set(['schema','generatedAt','folder','folderSourceCount','representedSourceCount','itemCount','omittedByLimit','included','excluded']);
  if(!meta||typeof meta!=='object'||Array.isArray(meta)||meta.schema!==FOLDER_EDITION_SCHEMA||Object.keys(meta).some(key=>!allowed.has(key)))return null;
  const included=meta.included,excluded=meta.excluded;
  const includedKeys=['titles','shortSummaries','links','dates','languages','sourceLabels'];
  const excludedKeys=['fullRetainedText','readingState','savedState','pageWatchEvidence','snapshots','browserAuthority','privateKeys'];
  if(!included||typeof included!=='object'||Array.isArray(included)||includedKeys.some(key=>included[key]!==true))return null;
  if(!excluded||typeof excluded!=='object'||Array.isArray(excluded)||excludedKeys.some(key=>excluded[key]!==true))return null;
  const count=value=>Number.isInteger(value)&&value>=0?value:null;
  const itemCount=count(meta.itemCount),folderSourceCount=count(meta.folderSourceCount),representedSourceCount=count(meta.representedSourceCount),omittedByLimit=count(meta.omittedByLimit);
  if(itemCount===null||folderSourceCount===null||representedSourceCount===null||omittedByLimit===null||itemCount>100||folderSourceCount>LIMIT.source||representedSourceCount>folderSourceCount||itemCount!==(Array.isArray(doc.items)?doc.items.length:-1))return null;
  const generatedAt=bestDate(meta.generatedAt),folder=text(meta.folder,180);
  if(!generatedAt||!folder)return null;
  const author=Array.isArray(doc.authors)&&doc.authors[0]&&typeof doc.authors[0]==='object'?text(doc.authors[0].name,80):'';
  return {schema:FOLDER_EDITION_SCHEMA,folder,curator:author,generatedAt,itemCount,omittedByLimit,folderSourceCount,representedSourceCount,manualSnapshot:true};
}
function xmlBase(el, fallback) {
  const chain=[]; for(let node=el;node&&node.nodeType===1;node=node.parentElement)chain.push(node);
  let base=fallback;
  for(const node of chain.reverse()){const value=node.getAttributeNS?.('http://www.w3.org/XML/1998/namespace','base')||node.getAttribute?.('xml:base')||'';if(value){try{base=safeUrl(value,base);}catch{}}}
  return base;
}
function parseFeed(raw, url) {
  if(typeof raw!=='string' || raw.length>LIMIT.characters)throw Error('Feed exceeds 2MB text limit');
  const origin=safeUrl(url), trimmed=raw.trim();
  if(!trimmed.startsWith('{') && /<!DOCTYPE|<!ENTITY/i.test(raw)) throw Error('Feeds with DTD or entity declarations are refused');
  if(trimmed.startsWith('{')) {
    let doc=JSON.parse(trimmed);
    if(!doc || !Array.isArray(doc.items) || typeof doc.version!=='string' || !/^https?:\/\/(www\.)?jsonfeed\.org\/version\/1(\.1)?\/?$/.test(doc.version)) throw Error('Not a JSON Feed 1.x document');
    let feedUrl='';try{if(doc.feed_url)feedUrl=safeUrl(doc.feed_url,origin);}catch{}
    const language=languageTag(doc.language),edition=folderEditionInfo(doc);
    return {title:text(doc.title||origin,180),titleLanguage:language,language,type:'json',feedUrl,edition,items:doc.items.slice(0,250).flatMap((entry,i)=>{
      const id=text(entry?.id,400); if(!id) return [];
      let link=''; try{link=entry.url?safeUrl(entry.url,origin):'';}catch{}
      const body=entry.content_text?bodyText(entry.content_text):htmlText(entry.content_html,LIMIT.body);
      const summary=entry.summary?htmlText(entry.summary,1200):text(body,1200);
      const itemLanguage=languageTag(entry.language)||language;
      return [{key:id,title:text(entry.title||summary||body||'Untitled update',240),url:link,summary,body,bodyIsSummary:false,
        language:itemLanguage,titleLanguage:itemLanguage,summaryLanguage:itemLanguage,bodyLanguage:itemLanguage,
        published:bestDate(entry.date_published||entry.date_modified)}];
    })};
  }
  const parsed = new DOMParser().parseFromString(raw,'application/xml');
  if(parsed.querySelector('parsererror'))throw Error('Invalid XML feed');
  const doc=parsed.documentElement; if(!doc)throw Error('Empty XML document');
  const local=doc.localName?.toLowerCase();
  if(local==='feed') {
    let entries=namedChildren(doc,'entry');
    const selfLink=namedChildren(doc,'link').find(x=>String(x.getAttribute('rel')||'').toLowerCase()==='self');
    let feedUrl='';try{const href=selfLink?.getAttribute('href')||'';if(href)feedUrl=safeUrl(href,xmlBase(selfLink,origin));}catch{}
    const titleEl=getChild(doc,'title'),language=xmlLanguage(doc),titleLanguage=xmlLanguage(titleEl)||language;
    return {title:text(titleEl?.textContent||origin,180),titleLanguage,language,type:'atom',feedUrl,items:entries.slice(0,250).map((e,i)=>{
      let linkEl=namedChildren(e,'link').find(x=>!x.getAttribute('rel')||x.getAttribute('rel')==='alternate');
      let href=linkEl?.getAttribute('href')||'';let link='';try{if(href)link=safeUrl(href,xmlBase(e,origin));}catch{}
      const titleEl=getChild(e,'title'),summaryEl=getChild(e,'summary'),contentEl=getChild(e,'content');
      const full=atomContentText(contentEl,LIMIT.body),summary=summaryEl?atomContentText(summaryEl,1200):text(full,1200);
      const body=full||summary,itemLanguage=xmlLanguage(e)||language;
      return {key:childText(e,'id')||link||('entry-'+i),title:text(titleEl?.textContent||'Untitled update',240),summary,body,bodyIsSummary:!full,
        language:itemLanguage,titleLanguage:xmlLanguage(titleEl)||itemLanguage,summaryLanguage:xmlLanguage(summaryEl)||itemLanguage,
        bodyLanguage:xmlLanguage(contentEl)||xmlLanguage(summaryEl)||itemLanguage,
        published:bestDate(childText(e,'published')||childText(e,'updated')),url:link};
    })};
  }
  let channel=local==='rss'?getChild(doc,'channel'):(local==='rdf'?(getChild(doc,'channel')||doc):null);
  if(!channel) throw Error('Not RSS, Atom, or JSON Feed');
  const candidates=local==='rdf'?namedChildren(doc,'item'):namedChildren(channel,'item');
  const atomNs='http://www.w3.org/2005/Atom';
  const selfLink=Array.from(channel?.children||[]).find(node=>node.localName?.toLowerCase()==='link'&&(node.namespaceURI||'')===atomNs&&String(node.getAttribute('rel')||'').toLowerCase()==='self');
  let feedUrl='';try{const href=selfLink?.getAttribute('href')||'';if(href)feedUrl=safeUrl(href,origin);}catch{}
  const channelTitle=getChild(channel,'title'),language=languageTag(childText(channel,'language'))||xmlLanguage(channel),titleLanguage=xmlLanguage(channelTitle)||language;
  return {title:text(channelTitle?.textContent||origin,180),titleLanguage,language,type:'rss',feedUrl,items:candidates.slice(0,250).map((e,i)=>{
    const guidEl=getChild(e,'guid'),guid=guidEl?.textContent?.trim()||'';
    const href=childText(e,'link');let link='';try{if(href)link=safeUrl(href,origin);}catch{}
    const permalink=guid&&String(guidEl?.getAttribute('isPermaLink')||'').toLowerCase()!=='false';
    if(!link&&permalink){try{link=safeUrl(guid,origin);}catch{}}
    const titleEl=getChild(e,'title'),descriptionEl=getChild(e,'description'),description=descriptionEl?.textContent?.trim()||'';
    const encodedEl=Array.from(e?.children||[]).find(node=>node.localName?.toLowerCase()==='encoded');
    const encoded=encodedEl?.textContent||'';
    const full=htmlText(encoded,LIMIT.body),summary=description?htmlText(description,1200):text(full,1200),body=full||htmlText(description,LIMIT.body);
    const itemLanguage=xmlLanguage(e)||language;
    return {key:guid||link||('item-'+i),title:text(titleEl?.textContent||'Untitled update',240),summary,body,bodyIsSummary:!full,
      language:itemLanguage,titleLanguage:xmlLanguage(titleEl)||itemLanguage,summaryLanguage:xmlLanguage(descriptionEl)||itemLanguage,
      bodyLanguage:xmlLanguage(encodedEl)||xmlLanguage(descriptionEl)||itemLanguage,
      published:bestDate(childText(e,'pubDate')||childText(e,'date')),url:link};
  })};
}
const PAGE_CHANGE_SCHEMA='progrss.page-change.v1';
function normalizePageText(raw,ignoreNumbers=false) {let s=String(raw||'').replace(/\s+/g,' ').trim(); return ignoreNumbers?s.replace(/\d+(?:[.,]\d+)*/g,'#'):s;}
function pageWordTokens(raw,ignoreNumbers=false){
  const source=normalizePageText(raw,false),rows=[];
  // Word and punctuation tokens keep the explanation on human boundaries. A
  // no-whitespace script may remain one bounded token; that is still clearer
  // than exposing arbitrary code-unit fragments from the page.
  const pattern=/\d+(?:[.,]\d+)*|[\p{L}\p{M}\p{N}]+(?:['’\-][\p{L}\p{M}\p{N}]+)*|[^\s]/gu;
  for(const match of source.matchAll(pattern)){
    const rawToken=match[0],number=/^\d+(?:[.,]\d+)*$/.test(rawToken);
    rows.push({raw:rawToken,value:ignoreNumbers&&number?'#':rawToken,start:match.index,end:match.index+rawToken.length,
      word:/^[\p{L}\p{M}\p{N}]/u.test(rawToken)});
  }
  return {source,tokens:rows};
}
function changeSnippet(source,start,end,limit=760){
  const textValue=String(source||'');
  if(!textValue)return '';
  const left=Math.max(0,start-180),right=Math.min(textValue.length,Math.max(end,start)+180);
  let value=textValue.slice(left,right).trim();
  if(left>0)value='…'+value;
  if(right<textValue.length)value+='…';
  return value.slice(0,limit);
}
function changeQuote(raw,limit=150){const value=text(raw,limit);return value?`“${value}”`:'';}
function changeSummary(removed,added,removedWords,addedWords){
  const before=changeQuote(removed),after=changeQuote(added);
  if(!removed&&added)return after?`Added ${after}`:`Added ${addedWords} word${addedWords===1?'':'s'}.`;
  if(removed&&!added)return before?`Removed ${before}`:`Removed ${removedWords} word${removedWords===1?'':'s'}.`;
  if(before&&after&&before.length+after.length<=270)return `Changed ${before} to ${after}`;
  if(!addedWords&&!removedWords)return 'Punctuation or symbols changed.';
  return `${addedWords} word${addedWords===1?' was':'s were'} added and ${removedWords} word${removedWords===1?' was':'s were'} removed.`;
}
function diffText(before,after,threshold=1,ignoreNumbers=false) {
  const left=pageWordTokens(before,ignoreNumbers),right=pageWordTokens(after,ignoreNumbers),a=left.tokens,b=right.tokens;
  if(normalizePageText(before,ignoreNumbers)===normalizePageText(after,ignoreNumbers))return {changed:false,meaningful:false,delta:0,added:'',removed:'',addedWords:0,removedWords:0,beforeSnippet:'',afterSnippet:'',summary:''};
  let front=0;while(front<a.length&&front<b.length&&a[front].value===b[front].value)front++;
  let back=0;while(back<a.length-front&&back<b.length-front&&a[a.length-back-1].value===b[b.length-back-1].value)back++;
  const aLast=a.length-back-1,bLast=b.length-back-1;
  const aStart=front<a.length?a[front].start:left.source.length,aEnd=aLast>=front?a[aLast].end:aStart;
  const bStart=front<b.length?b[front].start:right.source.length,bEnd=bLast>=front?b[bLast].end:bStart;
  const removed=left.source.slice(aStart,aEnd).trim(),added=right.source.slice(bStart,bEnd).trim();
  const removedWords=a.slice(front,a.length-back).filter(token=>token.word).length;
  const addedWords=b.slice(front,b.length-back).filter(token=>token.word).length;
  const delta=Math.max(removed.length,added.length),minimum=Math.max(0,Math.floor(Number(threshold)||0));
  return {changed:true,meaningful:delta>=minimum,delta,added:added.slice(0,1000),removed:removed.slice(0,1000),addedWords,removedWords,
    beforeSnippet:changeSnippet(left.source,aStart,aEnd),afterSnippet:changeSnippet(right.source,bStart,bEnd),summary:changeSummary(removed,added,removedWords,addedWords)};
}
function staticHtml(raw){
  // Ignore scripting/styling noise, and remove the most common incidental
  // resource-loading elements BEFORE parsing. This is defense in depth, NOT
  // a full HTML sanitizer. Parsed nodes never enter the live ProgRSS DOM.
  return raw.replace(/<\s*(script|style|template|iframe|svg|object|video|audio)\b[^>]*>[\s\S]*?(?:<\s*\/\s*\1\s*>|$)/gi,'')
    .replace(/<\s*(img|picture|source|track|link|embed|base)\b[^>]*>/gi,'');
}
function pageWatchError(message,code,detail={}){
  const error=Error(message);error.code=code;error.detail=detail;return error;
}
function extractPage(raw, source) {
  if(typeof raw!=='string'||raw.length>LIMIT.characters)throw pageWatchError('Page exceeds 2MB text limit','PAGE_TOO_LARGE');
  const doc=new DOMParser().parseFromString(staticHtml(raw),'text/html');
  const selector=String(source.selector||'').trim();
  let nodes;
  try { nodes=selector?Array.from(doc.querySelectorAll(selector)):Array.from(doc.querySelectorAll('main')) }
  catch { throw pageWatchError('The saved page-watch selector is no longer valid.','PAGE_SELECTOR_INVALID',{field:'selector'}); }
  if(!nodes.length && !selector) nodes=[doc.body].filter(Boolean);
  if(!nodes.length)throw pageWatchError('The saved page-watch selector no longer finds anything on this page.','PAGE_SELECTOR_NO_MATCH',{field:'selector'});
  if(source.mode==='cards'){
    const collisions=new Map();let meaningfulCount=0;
    const cards=nodes.slice(0,200).map((node,index)=>{
      let titleNode,linkNode;
      try{
        titleNode=source.titleSelector?node.querySelector(source.titleSelector):node.querySelector('h1,h2,h3,h4');
        linkNode=source.linkSelector?node.querySelector(source.linkSelector):node.querySelector('a[href]');
      }catch{
        throw pageWatchError('A saved page-watch title or link rule is no longer valid.','PAGE_SELECTOR_INVALID',{field:'card'});
      }
      const rawText=text(node.textContent||'',1000);if(rawText)meaningfulCount++;
      const title=text(titleNode?.textContent||rawText||('Item '+(index+1)),240);
      const summary=rawText;
      let url='';try{const href=linkNode?.getAttribute('href');if(href)url=safeUrl(href,source.url);}catch{}
      const stem=normalizePageText(title).toLocaleLowerCase();
      const occurrence=collisions.get(stem)||0;collisions.set(stem,occurrence+1);
      return {key:url||'title:'+stem+'#'+occurrence,title,summary,url};
    });
    if(!meaningfulCount)throw pageWatchError('The saved watch still matches page elements, but they no longer contain readable entries.','PAGE_WATCH_STRUCTURE_CHANGED',{field:'cards'});
    return {mode:'cards',cards,matchCount:nodes.length,meaningfulCount,contentChars:cards.reduce((total,card)=>total+card.summary.length,0)};
  }
  const content=nodes.map(n=>n.textContent||'').join('\n').trim().slice(0,120000);
  if(!content)throw pageWatchError('The saved watch still matches the page, but the watched section no longer contains readable text.','PAGE_WATCH_STRUCTURE_CHANGED',{field:'region'});
  return {mode:'region',content,matchCount:nodes.length,meaningfulCount:content?1:0,contentChars:content.length};
}
function pageWatchCaptureSignature(capture){
  if(capture?.mode==='cards')return 'cards:'+capture.cards.slice(0,40).map(card=>[card.key,text(card.title,160),text(card.summary,320),card.url||''].join('\u0001')).join('\u0002');
  return 'region:'+normalizePageText(capture?.content||'').slice(0,8000);
}
function pageWatchCaptureHealth(previous,capture,source={}){
  const checkedAt=new Date().toISOString();
  if(capture?.mode==='cards'){
    const current=Math.max(0,Number(capture.cards?.length)||0);
    const prior=Array.isArray(previous?.entries)?previous.entries.length:Array.isArray(previous?.keys)?previous.keys.length:0;
    const metrics={previousEntries:prior,currentEntries:current,matchCount:Math.max(0,Number(capture.matchCount)||current)};
    if(prior>=4&&current<=1)return {schema:PAGE_WATCH_HEALTH_SCHEMA,status:'attention',reason:'structure-changed',checkedAt,message:'The repeated list collapsed to one or no readable entry, so ProgRSS stopped before treating the rest as removed.',metrics};
    if(prior>=4&&(current<Math.ceil(prior*.4)||current>prior*3))return {schema:PAGE_WATCH_HEALTH_SCHEMA,status:'changed-shape',reason:'entry-count-shift',checkedAt,message:'The page’s repeated list changed shape, but ProgRSS is still finding readable entries.',metrics};
    return {schema:PAGE_WATCH_HEALTH_SCHEMA,status:'steady',reason:prior?'matched':'baseline',checkedAt,message:prior?'The watched repeated list still matches.':'The watched repeated list has a baseline.',metrics};
  }
  const current=normalizePageText(capture?.content||'').length;
  const prior=normalizePageText(previous?.text||'').length;
  const metrics={previousCharacters:prior,currentCharacters:current,matchCount:Math.max(0,Number(capture?.matchCount)||0)};
  if(prior>=800&&current<80)return {schema:PAGE_WATCH_HEALTH_SCHEMA,status:'attention',reason:'structure-changed',checkedAt,message:'The watched text collapsed to a very small fragment, so ProgRSS stopped before treating the rest as removed.',metrics};
  if(prior>=400&&(current<Math.ceil(prior*.25)||current>prior*4))return {schema:PAGE_WATCH_HEALTH_SCHEMA,status:'changed-shape',reason:'text-size-shift',checkedAt,message:'The watched text changed size sharply, but ProgRSS is still finding the configured section.',metrics};
  return {schema:PAGE_WATCH_HEALTH_SCHEMA,status:'steady',reason:prior?'matched':'baseline',checkedAt,message:prior?'The watched text still matches.':'The watched text has a baseline.',metrics};
}
function pageWatchStabilityDecision(previous,health,source={}){
  const stamp=text(health?.checkedAt,60)||new Date().toISOString();
  const reason=String(health?.reason||'');
  const changed=health?.status==='changed-shape'&&['entry-count-shift','text-size-shift'].includes(reason);
  const recipeVersion=Math.max(1,Math.min(10000,Math.floor(Number(source?.version)||1)));
  const prior=previous&&typeof previous==='object'&&!Array.isArray(previous)&&previous.schema===PAGE_WATCH_STABILITY_SCHEMA&&previous.status==='pending'&&previous.recipeVersion===recipeVersion?previous:null;
  if(!changed){
    if(prior)return {action:'accept',clear:true,recovered:true,health:{...health,status:'steady',reason:'returned-to-steady',message:'The page returned to its usual shape. The held result was discarded without creating an alert.'}};
    return {action:'accept',clear:true,recovered:false,health};
  }
  const metrics={};
  for(const key of ['previousEntries','currentEntries','previousCharacters','currentCharacters','matchCount']){
    const value=Number(health?.metrics?.[key]);if(Number.isFinite(value)&&value>=0)metrics[key]=Math.min(2_000_000,Math.floor(value));
  }
  const current=reason==='entry-count-shift'?Number(metrics.currentEntries||0):Number(metrics.currentCharacters||0);
  const priorCurrent=reason==='entry-count-shift'?Number(prior?.metrics?.currentEntries||0):Number(prior?.metrics?.currentCharacters||0);
  const currentMatches=Math.max(0,Number(metrics.matchCount)||0),priorMatches=Math.max(0,Number(prior?.metrics?.matchCount)||0);
  const ratio=priorCurrent>0&&current>0?current/priorCurrent:0;
  const sizeCompatible=reason==='entry-count-shift'
    ? (priorCurrent>0&&current>0&&Math.abs(current-priorCurrent)<=Math.max(2,Math.ceil(Math.max(current,priorCurrent)*.3)))
    : (ratio>=.7&&ratio<=1.43);
  const matchesCompatible=!priorMatches||!currentMatches||Math.abs(currentMatches-priorMatches)<=Math.max(2,Math.ceil(Math.max(currentMatches,priorMatches)*.3));
  if(prior&&prior.reason===reason&&sizeCompatible&&matchesCompatible){
    return {action:'accept',clear:true,confirmed:true,health:{...health,status:'steady',reason:'confirmed-shape-change',message:'The page showed the same new shape twice, so ProgRSS accepted it as a real change.'}};
  }
  const observations=prior?Math.min(3,Math.max(1,Number(prior.observations)||1)+1):1;
  if(observations>=3){
    return {action:'repair',clear:true,stability:null,health:{...health,status:'attention',reason:'unstable-shape',message:'The page changed shape differently across three checks. ProgRSS stopped before creating unreliable alerts.'}};
  }
  const stability={schema:PAGE_WATCH_STABILITY_SCHEMA,status:'pending',reason,recipeVersion,firstSeenAt:prior?.firstSeenAt||stamp,lastSeenAt:stamp,observations,metrics,
    message:observations===1?'This page looked unusually different once. ProgRSS held that result until the next check.':'The page looked unusually different again, but not in the same way. ProgRSS is holding the result until one more check.'};
  return {action:'hold',clear:false,stability,health:{...health,message:stability.message}};
}
function pageWatchRepairProposals(raw,source){
  if(!source||source.type!=='page')throw Error('Page-watch repair requires a page source');
  const proposals=[],seen=new Set();
  const add=(recipe,title,description)=>{
    let capture;try{capture=extractPage(raw,{...source,...recipe});}catch{return;}
    if(recipe.mode==='cards'&&capture.cards.length<2)return;
    const signature=pageWatchCaptureSignature(capture);if(!signature||seen.has(signature))return;seen.add(signature);
    const examples=recipe.mode==='cards'?capture.cards.slice(0,4).map(card=>text(card.title||card.summary,160)).filter(Boolean):[];
    const preview=recipe.mode==='region'?text(capture.content,360):'';
    proposals.push({
      schema:PAGE_WATCH_REPAIR_SCHEMA,
      title,description,mode:recipe.mode,count:recipe.mode==='cards'?capture.cards.length:1,examples,preview,
      recipe:{mode:recipe.mode,selector:recipe.selector,titleSelector:recipe.titleSelector||'',linkSelector:recipe.linkSelector||'',threshold:Math.max(0,Math.floor(Number(source.threshold)||1)),ignoreNumbers:Boolean(source.ignoreNumbers)},
      evidence:{signature,matchCount:Math.max(0,Number(capture.matchCount)||0),contentChars:Math.max(0,Number(capture.contentChars)||0)},
      capture
    });
  };
  const cardSelectors=['main article','article','main .post','main .entry','.h-entry','.post','.entry','.news-item','main li'];
  for(const selector of cardSelectors){
    add({mode:'cards',selector,titleSelector:'h1,h2,h3,h4',linkSelector:'a[href]'},'Watch repeated entries','Notice when an entry is added, removed, or reworded.');
    if(proposals.filter(row=>row.mode==='cards').length>=4)break;
  }
  add({mode:'region',selector:'main',titleSelector:'',linkSelector:''},'Watch the page’s main text','Notice meaningful wording changes in the main part of the page.');
  add({mode:'region',selector:'[role="main"]',titleSelector:'',linkSelector:''},'Watch the page’s main text','Notice meaningful wording changes in the main part of the page.');
  add({mode:'region',selector:'',titleSelector:'',linkSelector:''},'Watch the page’s readable text','Use the page’s readable body as a fallback when no clear main section exists.');
  return proposals.slice(0,6);
}
// RFC 5005-compatible principle: a stable feed entry identifier is not a promise of immutable text.
// Existing rev0002-0018 records have no entryKey; their historical ID serves as the first baseline.
// Revision counts are local event indices, not signatures or publisher-controlled version numbers.
function ingestFeed(state,source,parsed){
  if(!state||!Array.isArray(state.items)||!parsed||!Array.isArray(parsed.items))throw Error('Invalid feed update');
  const now=new Date().toISOString(), latest=new Map();
  const summariesOnly=String(source?.textRetention||'').toLowerCase()==='summary';
  for(const old of state.items){
    if(old.sourceId!==source.id)continue;
    const key=typeof old.entryKey==='string'?old.entryKey:old.id;
    if(!latest.has(key))latest.set(key,old); // newest-first vault order
  }
  const incoming=new Map();
  for(const entry of parsed.items.slice(0,250)){
    const base=source.id+'|'+String(entry.key||entry.url||entry.title).slice(0,500);
    if(!incoming.has(base))incoming.set(base,entry);
    else {
      const old=incoming.get(base),a=Date.parse(old.published||'')||0,b=Date.parse(entry.published||'')||0;
      if(b>a)incoming.set(base,entry); // prefer most recently updated duplicate entry
    }
  }
  const languageKeys=['language','titleLanguage','summaryLanguage','bodyLanguage'];
  const metadataFor=(entry,bodyOmitted)=>{
    const metadata=Object.fromEntries(languageKeys.map(key=>[key,languageTag(entry[key])]).filter(([,value])=>value));
    if(bodyOmitted)metadata.bodyLanguage=metadata.summaryLanguage||metadata.language||'';
    return metadata;
  };
  const applyMetadata=(target,metadata)=>{for(const key of languageKeys){if(metadata[key])target[key]=metadata[key];else delete target[key];}};
  let events=0;
  for(const [entryKey,entry] of incoming){
    const title=text(entry.title,240),summary=text(entry.summary||'',1200),fullBody=bodyText(entry.body||entry.summary||''),incomingIsSummary=Boolean(entry.bodyIsSummary)||!entry.body,url=entry.url?safeUrl(entry.url):'',prior=latest.get(entryKey);
    const bodyOmitted=Boolean(summariesOnly&&!incomingIsSummary&&fullBody);
    const body=bodyOmitted?summary:fullBody,bodyIsSummary=bodyOmitted||incomingIsSummary;
    const metadata=metadataFor(entry,bodyOmitted);
    const sameFrame=prior&&text(prior.title,240)===title&&text(prior.summary||'',1200)===summary&&(prior.url||'')===url;
    if(sameFrame&&prior.body===undefined){prior.body=body;prior.bodyIsSummary=bodyIsSummary;if(bodyOmitted)prior.bodyOmitted=true;else delete prior.bodyOmitted;applyMetadata(prior,metadata);continue;}
    // A locally omitted body can be restored on a later full-text check without
    // creating a false unread revision. The feed entry frame itself is unchanged.
    if(sameFrame&&prior.bodyOmitted&&!bodyOmitted&&!incomingIsSummary&&fullBody){prior.body=fullBody;prior.bodyIsSummary=false;delete prior.bodyOmitted;applyMetadata(prior,metadata);continue;}
    // Choosing summaries only governs future retained text. It does not silently
    // delete an older full body; the reader offers that cleanup separately.
    if(sameFrame&&summariesOnly&&!prior.bodyOmitted&&!Boolean(prior.bodyIsSummary)){applyMetadata(prior,metadataFor(entry,false));continue;}
    if(sameFrame&&bodyText(prior.body||prior.summary||'')===body&&Boolean(prior.bodyIsSummary)===bodyIsSummary){
      if(bodyOmitted)prior.bodyOmitted=true;
      applyMetadata(prior,metadata);
      continue;
    }
    const revision=prior?Math.max(0,Number(prior.feedRevision)||0)+1:0;
    const id=revision?entryKey+'|edit:'+revision:entryKey;
    if(state.items.some(item=>item.id===id))continue; // never overwrite an earlier event
    state.items.unshift({id,entryKey,feedRevision:revision,sourceId:source.id,title,url,summary,body,bodyIsSummary,...(bodyOmitted?{bodyOmitted:true}:{}),...metadata,
      published:entry.published||'',observedAt:now,kind:prior?'changed':'new'});
    events++;
  }
  state.items=state.items.slice(0,LIMIT.items);
  return events;
}
function compareCards(before,after,threshold=1,ignoreNumbers=false){
  const a=new Map((before||[]).map(card=>[card.key,card]));
  const b=new Map((after||[]).map(card=>[card.key,card]));
  const added=[],removed=[],changed=[];
  for(const [key,card] of b){
    const old=a.get(key);
    if(!old){added.push(card);continue;}
    // Stable key (usually canonical link) lets us distinguish edits from new cards.
    const difference=diffText(old.title+' '+old.summary,card.title+' '+card.summary,threshold,ignoreNumbers);
    if(difference.meaningful)changed.push({before:old,after:card,difference});
  }
  for(const [key,card] of a)if(!b.has(key))removed.push(card);
  return {added,removed,changed,unchanged:b.size-added.length-changed.length};
}
function analyzePagePair(source,beforeHtml,afterHtml){
  if(source.type!=='page')throw Error('Patch Clinic expects a webpage Lens');
  const before=extractPage(beforeHtml,source),after=extractPage(afterHtml,source);
  if(before.mode!==after.mode)throw Error('Incompatible snapshot types');
  if(before.mode==='region'){
    const diff=diffText(before.content,after.content,source.threshold||1,Boolean(source.ignoreNumbers));
    return {mode:'region',outcome:diff.meaningful?'changed':'quiet',diff,
      beforePreview:before.content.slice(0,650),afterPreview:after.content.slice(0,650),
      beforeCount:before.content.length,afterCount:after.content.length};
  }
  const result=compareCards(before.cards,after.cards,source.threshold||1,Boolean(source.ignoreNumbers));
  const outcome=result.added.length?'added':result.removed.length?'removed':result.changed.length?'changed-card':'quiet';
  return {mode:'cards',outcome,added:result.added.length,removed:result.removed.length,changed:result.changed.length,
    unchanged:result.unchanged,beforeCount:before.cards.length,afterCount:after.cards.length,
    examples:{added:result.added.slice(0,3).map(x=>x.title),removed:result.removed.slice(0,3).map(x=>x.title),changed:result.changed.slice(0,3).map(x=>x.after.title)}};
}
const FIXTURE_SCHEMA='progrss.fixtures.v1';
function cleanFixture(f){
  if(!f||!cleanId(f.id)||!cleanId(f.sourceId))throw Error('Invalid fixture identity');
  if(typeof f.before!=='string'||typeof f.after!=='string'||!f.before.trim()||!f.after.trim()||f.before.length>LIMIT.fixtureChars||f.after.length>LIMIT.fixtureChars)
    throw Error('Fixture snapshots must be nonempty and <=160K characters each');
  if(!['changed','quiet','added','removed','changed-card','any'].includes(f.expected))throw Error('Invalid fixture expectation');
  return {id:f.id,sourceId:f.sourceId,title:text(f.title,110)||'Unnamed scenario',expected:f.expected,
    before:f.before,after:f.after,createdAt:text(f.createdAt,40),note:text(f.note,500)};
}
function fixtureVerdict(f,source){
  const fixture=cleanFixture(f),result=analyzePagePair(source,fixture.before,fixture.after);
  return {pass:fixture.expected==='any'||fixture.expected===result.outcome||fixture.expected==='changed'&&result.outcome!=='quiet',expected:fixture.expected,result};
}
function exportFixtures(fixtures,sourceId='all'){
  const result=(fixtures||[]).filter(f=>sourceId==='all'||f.sourceId===sourceId).map(cleanFixture);
  if(result.length>LIMIT.fixtures)throw Error('Too many fixtures');
  return {schema:FIXTURE_SCHEMA,notice:'CONTAINS RAW HTML: may expose private content. Share only after review.',exportedAt:new Date().toISOString(),fixtures:result};
}
function validateFixtureBundle(bundle){
  if(!bundle||bundle.schema!==FIXTURE_SCHEMA||!Array.isArray(bundle.fixtures)||bundle.fixtures.length>LIMIT.fixtures||JSON.stringify(bundle).length>5_300_000)
    throw Error('Not a supported fixture bundle');
  const fixtures=bundle.fixtures.map(cleanFixture),ids=new Set();
  for(const f of fixtures){if(ids.has(f.id))throw Error('Duplicate fixture ID');ids.add(f.id);}
  return fixtures;
}
function ingestPage(state,source,capture){
  state.snapshots=state.snapshots||{};
  const prev=state.snapshots[source.id];
  const now=new Date().toISOString();
  const commonChange=(kind,difference,before='',after='')=>({schema:PAGE_CHANGE_SCHEMA,kind,mode:source.mode==='cards'?'cards':'region',
    summary:text(difference?.summary,500),before:text(before||difference?.beforeSnippet,1200),after:text(after||difference?.afterSnippet,1200),
    removed:text(difference?.removed,1000),added:text(difference?.added,1000),removedWords:Math.max(0,Number(difference?.removedWords)||0),
    addedWords:Math.max(0,Number(difference?.addedWords)||0),delta:Math.max(0,Number(difference?.delta)||0),
    threshold:Math.max(1,Math.floor(Number(source.threshold)||1)),ignoreNumbers:Boolean(source.ignoreNumbers)});
  if(capture.mode==='cards'){
    const next=capture.cards.slice(0,200).map(c=>({key:c.key,title:c.title,summary:c.summary,url:c.url}));
    const hasEntryHistory=Array.isArray(prev?.entries);
    const old=prev?.entries || (prev?.keys||[]).map(key=>({key,title:'',summary:'',url:''}));
    const delta=prev?compareCards(old,next,source.threshold||1,Boolean(source.ignoreNumbers)):{added:[],removed:[],changed:[],unchanged:0};
    // A legacy snapshot may know only stable keys, not the earlier wording. It
    // can still identify additions and removals, but must not invent an edit.
    if(prev&&!hasEntryHistory&&delta.changed.length){delta.unchanged+=delta.changed.length;delta.changed=[];}
    if(prev){
      for(const card of delta.added){
        const after=text(`${card.title}. ${card.summary}`,1200),change=commonChange('entry-added',{summary:'A new entry appeared in the watched list.',afterSnippet:after,added:after,addedWords:pageWordTokens(after).tokens.filter(token=>token.word).length,delta:after.length},'',after);
        state.items.unshift({id:uid('card'),sourceId:source.id,title:card.title,url:card.url||source.url,summary:card.summary,published:'',observedAt:now,kind:'new',change});
      }
      for(const {before,after,difference} of delta.changed){
        const beforeText=text(`${before.title}. ${before.summary}`,1200),afterText=text(`${after.title}. ${after.summary}`,1200),change=commonChange('entry-changed',difference,beforeText,afterText);
        state.items.unshift({id:uid('edit'),sourceId:source.id,title:after.title+' changed',url:after.url||source.url,summary:text(difference.summary,1200)||'The wording in this watched entry changed.',published:'',observedAt:now,kind:'changed',change});
      }
      for(const card of delta.removed){
        const before=text(`${card.title}. ${card.summary}`,1200),change=commonChange('entry-removed',{summary:'An entry no longer appeared in the watched list.',beforeSnippet:before,removed:before,removedWords:pageWordTokens(before).tokens.filter(token=>token.word).length,delta:before.length},before,'');
        state.items.unshift({id:uid('gone'),sourceId:source.id,title:card.title+' removed',url:card.url||source.url,summary:'This entry no longer appeared in the watched list.',published:'',observedAt:now,kind:'removed',change});
      }
    }
    state.snapshots[source.id]={mode:'cards',keys:next.map(c=>c.key),entries:next,capturedAt:now};
    state.items=unique(state.items).slice(0,LIMIT.items);
    return {added:delta.added.length+delta.changed.length+delta.removed.length,baseline:!prev,delta};
  }
  const delta=diffText(prev?.text||'',capture.content,source.threshold||1,Boolean(source.ignoreNumbers));
  if(prev && delta.meaningful){
    state.items.unshift({id:uid('diff'),sourceId:source.id,title:source.title+' changed',url:source.url,summary:text(delta.summary,1200)||'The watched main text changed.',published:'',observedAt:now,kind:'changed',change:commonChange('text-changed',delta)});
  }
  state.snapshots[source.id]={mode:'region',text:capture.content.slice(0,120000),capturedAt:now};
  state.items=state.items.slice(0,LIMIT.items);
  return {added:prev && delta.meaningful ? 1 : 0,baseline:!prev,delta};
}

// Rev0004 / Witness-aware feed algebra.
// A URL is sufficient to correlate *new* observations, but not a proof that
// independent people corroborated a claim. Edits/deletions remain event-local.
function itemSignature(item){
  if(item.kind==='changed'||item.kind==='removed') return 'event:'+item.sourceId+':'+item.id;
  if(item.url){try{return 'url:'+safeUrl(item.url)}catch{}}
  return 'local:'+item.sourceId+':'+item.id;
}
function observationTime(item){return Date.parse(item.published||item.observedAt)||0;}
function mergeWitnesses(records){
  const byKey=new Map();
  for(const r of records){
    if(!byKey.has(r.key))byKey.set(r.key,{key:r.key,item:r.item,witnesses:[],variants:[]});
    const dest=byKey.get(r.key);
    if(observationTime(r.item)>observationTime(dest.item))dest.item=r.item;
    const variants=new Set(dest.variants.map(i=>i.id));
    for(const variant of r.variants||[r.item])if(!variants.has(variant.id)){dest.variants.push(variant);variants.add(variant.id)}
    const ids=new Set(dest.witnesses.map(w=>w.itemId+'@'+w.path.map(p=>p.kind+':'+p.id).join('/')));
    for(const w of r.witnesses){const wk=w.itemId+'@'+w.path.map(p=>p.kind+':'+p.id).join('/');if(!ids.has(wk)&&dest.witnesses.length<300){dest.witnesses.push(w);ids.add(wk)}}
  }
  return [...byKey.values()];
}
function composeEvidence(state,collectionId='all'){
  const sources=new Map((state.sources||[]).map(s=>[s.id,s]));
  const groups=new Map((state.collections||[]).map(g=>[g.id,g]));
  const items=state.items||[];
  function leaf(id){
    const src=sources.get(id);if(!src)return [];
    return mergeWitnesses(items.filter(i=>i.sourceId===id&&filterMatch(i,src)).map(item=>({key:itemSignature(item),item,
      witnesses:[{sourceId:id,itemId:item.id,path:[{kind:'source',id,title:src.title,version:src.version||1}]}]})));
  }
  function branch(member,seen){return member.kind==='source'?leaf(member.id):walk(member.id,seen)}
  function walk(id,seen){
    if(seen.has(id))return [];
    const group=groups.get(id);if(!group)return [];
    const next=new Set(seen);next.add(id);
    const members=(group.members||[]).map(m=>branch(m,next));
    const mode=['intersection','subtract'].includes(group.mode)?group.mode:'union';
    let rows=[];
    if(mode==='intersection'){
      if(members.length>=2){
        const common=members[0].filter(x=>members.every(list=>list.some(y=>y.key===x.key))).map(x=>x.key);
        rows=mergeWitnesses(members.flat().filter(r=>common.includes(r.key))).filter(r=>new Set(r.witnesses.map(w=>w.sourceId)).size>=2);
      }
    }else if(mode==='subtract'){
      if(members.length>=1){const omitted=new Set(members.slice(1).flat().map(r=>r.key));
        rows=members[0].filter(r=>!omitted.has(r.key));}
    }else rows=mergeWitnesses(members.flat());
    // Filter the signal against ANY eligible variant, not arbitrarily the
    // newest duplicate. Otherwise a peer's newer title could mask a match.
    rows=rows.flatMap(r=>{const eligible=(r.variants||[r.item]).filter(i=>filterMatch(i,group));
      if(!eligible.length)return [];
      const chosen=eligible.reduce((a,b)=>observationTime(b)>observationTime(a)?b:a);
      return [{...r,item:chosen,variants:eligible}];});
    return rows.map(r=>({...r,witnesses:r.witnesses.map(w=>({...w,path:[{kind:'collection',id,title:group.title,mode,version:group.version||1},...w.path]}))}));
  }
  const rows=collectionId==='all'?mergeWitnesses([...sources.keys()].flatMap(leaf)):walk(collectionId,new Set());
  return rows.sort((a,b)=>observationTime(b.item)-observationTime(a.item)||a.key.localeCompare(b.key));
}
function compose(state,collectionId='all'){return composeEvidence(state,collectionId).map(r=>r.item);}
function explainItem(state,itemId,collectionId='all'){
  const item=(state.items||[]).find(i=>i.id===itemId);
  if(!item)return {included:false,reason:'Observation not found in this local vault',paths:[]};
  const key=itemSignature(item),all=composeEvidence(state,collectionId),row=all.find(r=>r.key===key);
  const source=(state.sources||[]).find(s=>s.id===item.sourceId);
  if(row){const exactWitness=(row.variants||[row.item]).some(v=>v.id===item.id);
    if(!exactWitness)return {included:false,key,reason:'The same permalink is included via another Lens, but THIS observation did not survive the collection filters',paths:[]};
    return {included:true,key,sourceId:item.sourceId,mode:collectionId==='all'?'union':((state.collections||[]).find(c=>c.id===collectionId)?.mode||'union'),
    witnesses:row.witnesses,independentSources:new Set(row.witnesses.map(w=>w.sourceId)).size,
    reason:'Included by the selected collection and its source/keyword rules. The paths are observed routes, not authenticated curator endorsements.'};}
  if(!source)return {included:false,key,reason:'Its source Lens is missing from the library',paths:[]};
  if(!filterMatch(item,source))return {included:false,key,reason:'Filtered out by its source Lens include/exclude keywords',paths:[]};
  if(collectionId==='all')return {included:false,key,reason:'Not present in the active local source set',paths:[]};
  const group=(state.collections||[]).find(c=>c.id===collectionId);
  if(!group)return {included:false,key,reason:'Collection not found',paths:[]};
  const matches=(group.members||[]).map((m,index)=>({index,member:m,match:(m.kind==='collection'?composeEvidence(state,m.id).some(r=>r.key===key):(state.items||[]).some(i=>i.sourceId===m.id&&itemSignature(i)===key&&filterMatch(i,(state.sources||[]).find(src=>src.id===m.id)||{})))}));
  const hit=matches.filter(m=>m.match).length;
  const mode=group.mode||'union';
  let reason='Not selected by any direct member, possibly because of a nested filter';
  if(mode==='intersection'&&hit<(group.members||[]).length)reason='Intersection requires a matching signal in every direct member; '+hit+'/'+group.members.length+' matched';
  else if(mode==='subtract'&&matches.slice(1).some(m=>m.match))reason='Subtraction removed this signal because it appears in an exclusion member';
  else if(!filterMatch(item,group))reason='Excluded by this collection\'s include/exclude keywords';
  else if(mode==='intersection')reason='Intersection lacks evidence from two distinct originating sources';
  return {included:false,key,mode,matchedMembers:hit,totalMembers:(group.members||[]).length,reason,paths:[]};
}

function cleanId(id) {return typeof id==='string' && /^[a-zA-Z0-9_-]{1,100}$/.test(id);}
const SOURCE_NOTE_MAX_CODE_POINTS=280;
const SOURCE_NOTE_ASCII_EDGE=/^[ \t\r\n\f\v]+|[ \t\r\n\f\v]+$/g;
function normalizeSourceNoteReason(value){
  if(value===undefined||value===null)return undefined;
  if(typeof value!=='string')throw Error('Placement reason must be a string');
  const reason=value.replace(SOURCE_NOTE_ASCII_EDGE,'');
  if(!reason)return undefined;
  for(const character of reason){const point=character.codePointAt(0);if(point>=0xd800&&point<=0xdfff)throw Error('Placement reason contains an invalid Unicode scalar value');}
  if(Array.from(reason).length>SOURCE_NOTE_MAX_CODE_POINTS)throw Error('Placement reason exceeds 280 Unicode code points');
  return reason;
}
function auditSourceNotes(state,knownSourceIds=null){
  const errors=[];
  const sourceIds=knownSourceIds instanceof Set?knownSourceIds:new Set(
    (Array.isArray(state?.sources)?state.sources:[])
      .filter(source=>source&&typeof source==='object'&&!Array.isArray(source))
      .map(source=>text(source.id,300)).filter(Boolean)
  );
  let count=0;
  for(const [collectionIndex,collection] of (Array.isArray(state?.collections)?state.collections:[]).entries()){
    if(!collection||typeof collection!=='object'||Array.isArray(collection))continue;
    const folderId=text(collection.id,300)||String(collectionIndex+1);
    if(Object.prototype.hasOwnProperty.call(collection,'reason'))errors.push(`Collection ${folderId} carries a Source Note on the folder instead of one direct source placement.`);
    const seen=new Map();
    for(const [memberIndex,member] of (Array.isArray(collection.members)?collection.members:[]).entries()){
      if(!member||typeof member!=='object'||Array.isArray(member))continue;
      const kind=member.kind,memberId=text(member.id,300),hasReason=Object.prototype.hasOwnProperty.call(member,'reason');
      const key=memberId?`${String(kind||'')}:${memberId}`:'';
      if(key){
        const previousHadReason=seen.get(key);
        if(previousHadReason!==undefined&&(previousHadReason||hasReason))errors.push(`Collection ${folderId} repeats placement ${kind}:${memberId}; a reason-bearing direct relationship must appear exactly once.`);
        seen.set(key,Boolean(previousHadReason||hasReason));
      }
      if(!hasReason)continue;
      if(kind!=='source'){errors.push(`Collection ${folderId} member ${memberIndex+1} carries a Source Note on something other than a direct source placement.`);continue;}
      if(!memberId){errors.push(`Collection ${folderId} member ${memberIndex+1} has a Source Note but no source identity.`);continue;}
      if(!sourceIds.has(memberId)){errors.push(`Collection ${folderId} gives missing source ${memberId} a Source Note.`);continue;}
      let normalized;
      try{normalized=normalizeSourceNoteReason(member.reason)}catch(error){errors.push(`Collection ${folderId} placement source:${memberId} has an invalid Source Note: ${error.message||error}.`);continue;}
      if(normalized===undefined){errors.push(`Collection ${folderId} placement source:${memberId} has an empty Source Note; omit the field instead.`);continue;}
      if(member.reason!==normalized){errors.push(`Collection ${folderId} placement source:${memberId} has a noncanonical Source Note; remove leading or trailing ASCII whitespace.`);continue;}
      count+=1;
    }
  }
  return {count,errors};
}
function cleanRecipe(s){
  if(!s||!cleanId(s.id)||!['rss','page'].includes(s.type))throw Error('Invalid source recipe');
  return {id:s.id,title:text(s.title,130)||'Untitled lens',type:s.type,url:safeUrl(s.url),mode:s.mode==='cards'?'cards':'region',selector:text(s.selector,350),titleSelector:text(s.titleSelector,200),linkSelector:text(s.linkSelector,200),include:text(s.include,280),exclude:text(s.exclude,280),threshold:Math.min(10000,Math.max(0,Math.round(s.threshold===undefined||s.threshold===null||s.threshold===''?1:Number(s.threshold)||0))),ignoreNumbers:Boolean(s.ignoreNumbers),version:Math.min(10000,Math.max(1,Math.round(Number(s.version)||1))),author:text(s.author,80)||'anonymous'};
}
function cleanCollection(g){
  if(!g||!cleanId(g.id)||!Array.isArray(g.members)||g.members.length>150)throw Error('Invalid collection');
  if(Object.prototype.hasOwnProperty.call(g,'reason'))throw Error('A Source Note belongs to one direct folder-to-source placement, not to a folder');
  const members=[],seen=new Map();
  for(const m of g.members){
    if(!m || !['source','collection'].includes(m.kind)||!cleanId(m.id))throw Error('Invalid collection reference');
    if(m.kind!=='source'&&Object.prototype.hasOwnProperty.call(m,'reason'))throw Error('Only a direct source placement may carry a Source Note');
    const projected={kind:m.kind,id:m.id};
    if(m.kind==='source'&&Object.prototype.hasOwnProperty.call(m,'reason')){
      const reason=normalizeSourceNoteReason(m.reason);if(reason!==undefined)projected.reason=reason;
    }
    const key=`${m.kind}:${m.id}`,previous=seen.get(key);
    if(previous){if(JSON.stringify(previous)!==JSON.stringify(projected))throw Error('Conflicting Source Notes for the same direct placement');continue;}
    seen.set(key,projected);members.push(projected);
  }
  return {id:g.id,title:text(g.title,130)||'Untitled collection',mode:['intersection','subtract'].includes(g.mode)?g.mode:'union',include:text(g.include,280),exclude:text(g.exclude,280),version:Math.min(10000,Math.max(1,Math.round(Number(g.version)||1))),author:text(g.author,80)||'anonymous',members};
}
function validateBundle(raw){
  if(!raw||raw.schema!==SCHEMA||!Array.isArray(raw.sources)||!Array.isArray(raw.collections)||raw.sources.length>100||raw.collections.length>100)throw Error('Invalid or oversized ProgRSS bundle');
  if(JSON.stringify(raw).length>LIMIT.bundle)throw Error('Bundle exceeds 650 KB');
  const sources=raw.sources.map(cleanRecipe),collections=raw.collections.map(cleanCollection);
  const ids=new Set();for(const x of [...sources,...collections]){if(ids.has(x.id))throw Error('Duplicate recipe ID');ids.add(x.id)}
  for(const col of collections)for(const m of col.members){
    if(!ids.has(m.id))throw Error('Bundle has an unresolved reference');
    if(m.kind==='source'&&!sources.some(s=>s.id===m.id)||m.kind==='collection'&&!collections.some(c=>c.id===m.id))throw Error('Bundle has a mismatched reference');
  }
  const map=new Map(collections.map(c=>[c.id,c]));
  const visiting=new Set(),visited=new Set();function visit(id){if(visiting.has(id))throw Error('Collection cycle detected');if(visited.has(id))return;visiting.add(id);for(const m of map.get(id).members)if(m.kind==='collection')visit(m.id);visiting.delete(id);visited.add(id)}
  for(const id of map.keys())visit(id);
  const root=raw.root===undefined||raw.root===null||raw.root===''?'':String(raw.root);
  if(root&&(!cleanId(root)||!map.has(root)))throw Error('Bundle root must name one included collection');
  const title=text(raw.title,130);
  return {schema:SCHEMA,exportedAt:text(raw.exportedAt,60),...(root?{root}:{}),...(title?{title}:{}),sources,collections};
}
function exportBundle(state,chosen='all'){
  const sourceIds=new Set(),groupIds=new Set();
  function collect(id){if(groupIds.has(id))return;const col=(state.collections||[]).find(c=>c.id===id);if(!col)return;groupIds.add(id);for(const m of col.members||[]){if(m.kind==='source')sourceIds.add(m.id);else collect(m.id)}}
  if(chosen==='all'){(state.sources||[]).forEach(s=>sourceIds.add(s.id));(state.collections||[]).forEach(c=>groupIds.add(c.id))}else collect(chosen);
  const selected=(state.collections||[]).find(c=>c.id===chosen);
  const out={schema:SCHEMA,exportedAt:new Date().toISOString(),...(chosen!=='all'&&selected?{root:chosen,title:text(selected.title,130)}:{}),sources:(state.sources||[]).filter(s=>sourceIds.has(s.id)).map(cleanRecipe),collections:(state.collections||[]).filter(c=>groupIds.has(c.id)).map(cleanCollection)};
  return validateBundle(out);
}
function importPreview(bundle,state){
  const incoming=validateBundle(bundle),currentIds=new Set([...(state.sources||[]),...(state.collections||[])].map(x=>x.id));
  const seen=new Set(currentIds),remap={};
  for(const x of [...incoming.sources,...incoming.collections]){
    let id=x.id;while(seen.has(id))id=uid(x===null?'id':('import'));
    remap[x.id]=id;seen.add(id);
  }
  const sources=incoming.sources.map(s=>({...s,id:remap[s.id],enabled:false,lastScan:'',lastError:'',origin:'import'}));
  const collections=incoming.collections.map(c=>({...c,id:remap[c.id],members:c.members.map(m=>({...m,id:remap[m.id]}))}));
  return {sources,collections,count:sources.length+collections.length};
}
function attributeCI(node,name){
  const wanted=String(name||'').toLocaleLowerCase();
  const found=Array.from(node?.attributes||[]).find(attr=>attr.name.toLocaleLowerCase()===wanted);
  return found?.value||'';
}
function parseOPMLDetailed(raw){
  if(typeof raw!=='string'||raw.length>LIMIT.characters)throw Error('OPML exceeds the 2 MB safety limit');
  if(/<!DOCTYPE|<!ENTITY/i.test(raw))throw Error('OPML with DTD or entity declarations is refused');
  const doc=new DOMParser().parseFromString(raw,'application/xml');
  if(doc.querySelector('parsererror')||doc.documentElement?.localName?.toLowerCase()!=='opml')throw Error('Invalid OPML document');
  const root=doc.documentElement;
  const head=Array.from(root.children||[]).find(node=>node.localName?.toLowerCase()==='head');
  const body=Array.from(root.children||[]).find(node=>node.localName?.toLowerCase()==='body');
  if(!body)throw Error('OPML body is missing');
  const feeds=new Map(),folders=new Set();
  let feedOutlines=0,invalidCount=0,duplicateCount=0,outlineCount=0,truncatedCount=0;
  const addFolderPath=(entry,path)=>{
    if(!path.length)return;
    const key=JSON.stringify(path);
    if(!entry.folderPaths.some(item=>JSON.stringify(item)===key))entry.folderPaths.push(path);
    for(let index=1;index<=path.length;index++)folders.add(JSON.stringify(path.slice(0,index)));
  };
  const walk=(parent,path=[])=>{
    for(const node of Array.from(parent.children||[]).filter(child=>child.localName?.toLowerCase()==='outline')){
      outlineCount++;
      if(outlineCount>1000)throw Error('OPML contains more than 1,000 outlines');
      const label=text(attributeCI(node,'title')||attributeCI(node,'text'),130);
      const xmlUrl=attributeCI(node,'xmlUrl');
      const children=Array.from(node.children||[]).filter(child=>child.localName?.toLowerCase()==='outline');
      if(xmlUrl){
        feedOutlines++;
        try{
          const url=safeUrl(xmlUrl),existing=feeds.get(url);
          if(existing){duplicateCount++;addFolderPath(existing,path);}
          else if(feeds.size>=500)truncatedCount++;
          else{
            const entry={title:label||'Imported feed',url,folderPaths:[]};
            addFolderPath(entry,path);feeds.set(url,entry);
          }
        }catch{invalidCount++;}
        if(children.length)walk(node,label?[...path,label]:path);
      }else{
        const next=label?[...path,label]:path;
        if(label&&children.length)folders.add(JSON.stringify(next));
        if(children.length)walk(node,next);
      }
    }
  };
  walk(body,[]);
  return {title:text(head?childText(head,'title'):'',180)||'Imported subscriptions',feeds:[...feeds.values()],feedOutlines,invalidCount,duplicateCount,truncatedCount,folderCount:folders.size};
}
function parseOPML(raw){
  return parseOPMLDetailed(raw).feeds.map(feed=>({id:uid('rss'),title:feed.title,url:feed.url,type:'rss',selector:'',include:'',exclude:'',enabled:false,version:1,author:'OPML import'}));
}
function makeOPML(state){
  const escape=x=>String(x||'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');
  return '<?xml version="1.0"?><opml version="2.0"><head><title>ProgRSS feeds</title></head><body>'+(state.sources||[]).filter(s=>s.type==='rss').map(s=>'<outline type="rss" text="'+escape(s.title)+'" xmlUrl="'+escape(s.url)+'"/>').join('')+'</body></opml>';
}
function makeJSONFeed(state,chosen='all') {
  const sources=new Map((state.sources||[]).map(source=>[source.id,source]));
  const items=compose(state,chosen).slice(0,250).map(i=>{const source=sources.get(i.sourceId)||{},language=languageTag(i.language||source.language);return {id:i.id,url:i.url||undefined,title:i.title,summary:i.summary||undefined,
    content_text:bodyText(i.body||i.summary||''),language:language||undefined,date_published:i.published||i.observedAt};});
  const declared=items.map(item=>item.language),languages=[...new Set(declared.filter(Boolean))];
  const language=items.length&&declared.every(Boolean)&&languages.length===1?languages[0]:undefined;
  return {version:'https://jsonfeed.org/version/1.1',title:'ProgRSS / '+chosen,language,items};
}
function makeFolderEdition(state,collectionId,options={}) {
  const limit=Math.max(1,Math.min(100,Math.floor(Number(options.limit)||100)));
  const folderTitle=text(options.title,180)||text((state.collections||[]).find(row=>row.id===collectionId)?.title,180)||'Shared folder';
  const curator=text(options.curator,80),note=text(options.note,280),generatedAt=bestDate(options.generatedAt)||new Date().toISOString();
  const groups=new Map((state.collections||[]).map(group=>[group.id,group]));
  const selectedSourceIds=new Set();
  const collect=(id,seen=new Set())=>{
    if(seen.has(id))return;
    const group=groups.get(id);if(!group)return;
    const next=new Set(seen);next.add(id);
    for(const member of group.members||[]){
      if(member?.kind==='source')selectedSourceIds.add(member.id);
      else if(member?.kind==='collection')collect(member.id,next);
    }
  };
  collect(collectionId);
  const sources=new Map((state.sources||[]).filter(source=>selectedSourceIds.has(source.id)&&!source.archivedAt).map(source=>[source.id,source]));
  const allRows=composeEvidence({...state,sources:[...sources.values()]},collectionId);
  const editionToken=value=>{
    const bytes=typeof TextEncoder==='function'?new TextEncoder().encode(String(value||'')):Array.from(String(value||''),character=>character.charCodeAt(0)&255);
    let hash=14695981039346656037n;
    for(const byte of bytes){hash^=BigInt(byte);hash=BigInt.asUintN(64,hash*1099511628211n);}
    return hash.toString(16).padStart(16,'0');
  };
  const rows=allRows.slice(0,limit);
  const represented=new Set();
  const items=rows.map(row=>{
    const item=row.item||{};
    const witnesses=[];
    const witnessIds=new Set();
    for(const witness of row.witnesses||[]){
      const source=sources.get(witness.sourceId);
      if(!source||witnessIds.has(source.id))continue;
      witnessIds.add(source.id);represented.add(source.id);
      if(witnesses.length<8)witnesses.push({title:text(source.title,130)||'Untitled source',type:source.type==='page'?'page':'feed'});
    }
    const source=sources.get(item.sourceId)||{};
    if(source.id&&!witnessIds.has(source.id)){witnessIds.add(source.id);represented.add(source.id);if(witnesses.length<8)witnesses.push({title:text(source.title,130)||'Untitled source',type:source.type==='page'?'page':'feed'});}
    const summary=text(item.summary||item.change?.summary||item.title,800);
    const language=languageTag(item.language||source.language);
    const stamp=bestDate(item.published||item.observedAt);
    const extension={sourceCount:witnessIds.size||1,sources:witnesses};
    // Keep the public evidence small and legible: source labels and the kind of
    // observed page change are useful; private before/after passages are not.
    if(item.change?.kind)extension.changeKind=text(item.change.kind,40);
    let url='';try{if(item.url)url=safeUrl(item.url)}catch{}
    const eventLocal=item.kind==='changed'||item.kind==='removed';
    const publicId=url&&!eventLocal?url:`urn:progrss:edition:${editionToken(row.key)}`;
    const out={
      id:publicId,
      title:text(item.title,240)||'Untitled update',
      content_text:summary||text(item.title,800)||'Untitled update',
      _progrss:extension
    };
    if(summary)out.summary=summary;
    if(url)out.url=url;
    if(stamp)out.date_published=stamp;
    if(language)out.language=language;
    return out;
  });
  const declared=items.map(item=>item.language),languages=[...new Set(declared.filter(Boolean))];
  const document={
    version:'https://jsonfeed.org/version/1.1',
    title:`${folderTitle} · recent updates`,
    description:note||`Recent updates selected from ${folderTitle}.`,
    user_comment:'Prepared manually from a local ProgRSS folder. Full retained feed text, read and saved state, page-watch comparison evidence, snapshots, browser permissions, and private keys are not included.',
    items,
    _progrss:{
      schema:FOLDER_EDITION_SCHEMA,
      generatedAt,
      folder:folderTitle,
      folderSourceCount:sources.size,
      representedSourceCount:represented.size,
      itemCount:items.length,
      omittedByLimit:Math.max(0,allRows.length-items.length),
      included:{titles:true,shortSummaries:true,links:true,dates:true,languages:true,sourceLabels:true},
      excluded:{fullRetainedText:true,readingState:true,savedState:true,pageWatchEvidence:true,snapshots:true,browserAuthority:true,privateKeys:true}
    }
  };
  if(curator)document.authors=[{name:curator}];
  if(items.length&&declared.every(Boolean)&&languages.length===1)document.language=languages[0];
  const raw=JSON.stringify(document);
  const bytes=typeof TextEncoder==='function'?new TextEncoder().encode(raw).length:raw.length;
  if(bytes>LIMIT.edition)throw Error('Recent-updates feed exceeds the 250 KB public-feed limit');
  return {document,summary:{title:folderTitle,items:items.length,sources:represented.size,folderSources:sources.size,omittedByLimit:Math.max(0,allRows.length-items.length),curator,bytes,fullTextIncluded:false,readingStateIncluded:false,savedStateIncluded:false,pageWatchEvidenceIncluded:false}};
}
// Rev0004 / Patch proposals: strict, declarative, stale-base-checked.
// No remote code, no URLs being silently swapped, no HTML specimens shared.
const PATCH_SCHEMA='progrss.patch.v1';
const PATCH_KEYS=['mode','selector','titleSelector','linkSelector','threshold','ignoreNumbers','include','exclude'];
function recipeFields(source){const c=cleanRecipe(source),o={};for(const k of PATCH_KEYS)o[k]=c[k];return o;}
function cleanPatchFields(raw,requireAll=false){
  if(!raw||typeof raw!=='object'||Array.isArray(raw))throw Error('Patch fields must be an object');
  const keys=Object.keys(raw);
  if(!keys.length||keys.some(k=>!PATCH_KEYS.includes(k))||(requireAll&&keys.length!==PATCH_KEYS.length))throw Error('Invalid patch field list');
  const out={};
  for(const k of keys){const v=raw[k];
    if(k==='ignoreNumbers'){if(typeof v!=='boolean')throw Error('Expected boolean ignoreNumbers');out[k]=v;}
    else if(k==='threshold'){if(!Number.isInteger(v)||v<0||v>10000)throw Error('Invalid patch threshold');out[k]=v;}
    else if(k==='mode'){if(!['cards','region'].includes(v))throw Error('Invalid patch mode');out[k]=v;}
    else {const cap=k==='selector'?350:['titleSelector','linkSelector'].includes(k)?200:280;
      if(typeof v!=='string'||v.length>cap||/[\u0000-\u001f\u007f]/.test(v))throw Error('Invalid selector/filter patch');out[k]=v;}
  }
  return out;
}
function validateProposal(raw){
  if(!raw||typeof raw!=='object'||Array.isArray(raw)||raw.schema!==PATCH_SCHEMA||JSON.stringify(raw).length>16000)throw Error('Not a ProgRSS patch proposal (16KB maximum)');
  const allowed=new Set(['schema','target','base','changes','message','author','createdAt','evidence']);
  if(Object.keys(raw).some(k=>!allowed.has(k)))throw Error('Unexpected patch payload fields; raw HTML specimens are forbidden');
  const t=raw.target,b=raw.base;
  if(t&&Object.keys(t).some(k=>!['id','type','url','title'].includes(k)))throw Error('Unexpected target field');
  if(b&&Object.keys(b).some(k=>!['version','fields'].includes(k)))throw Error('Unexpected patch base field');
  if(!t||t.type!=='page'||!cleanId(t.id)||typeof t.url!=='string'||!b||!Number.isInteger(b.version)||b.version<1||b.version>10000)throw Error('Invalid patch target/base');
  const url=safeUrl(t.url),base=cleanPatchFields(b.fields,true),changes=cleanPatchFields(raw.changes);
  if(!Object.keys(changes).some(k=>changes[k]!==base[k]))throw Error('Patch does not change any fields');
  if(raw.evidence!==undefined&&!Array.isArray(raw.evidence))throw Error('Invalid patch evidence list');
  const evidence=raw.evidence||[];
  if(evidence.length>12)throw Error('Too many evidence labels');
  if(evidence.some(e=>!e||typeof e!=='object'||Object.keys(e).some(k=>!['name','expected','pass'].includes(k))||typeof e.name!=='string'||e.name.length>110||!['quiet','changed','added','removed','changed-card','any'].includes(e.expected)||typeof e.pass!=='boolean'))throw Error('Invalid patch evidence label');
  return {schema:PATCH_SCHEMA,target:{id:t.id,type:'page',url,title:text(t.title,130)},base:{version:b.version,fields:base},
    changes,message:text(raw.message,500),author:text(raw.author,80)||'anonymous',
    createdAt:text(raw.createdAt,40),evidence:evidence.map(e=>({name:e.name,expected:e.expected,pass:e.pass}))};
}
function makeProposal(source,draft,message='',evidence=[]){
  if(draft?.url!==undefined&&safeUrl(draft.url)!==safeUrl(source.url))throw Error('Proposal cannot change the watched URL');
  if(draft?.type!==undefined&&draft.type!=='page')throw Error('Proposal cannot change Lens type');
  const original=cleanRecipe(source),candidate=cleanRecipe({...source,...draft,id:source.id,url:source.url,type:'page',version:source.version});
  if(original.type!=='page')throw Error('Only webpage Lenses support patch proposals');
  const base=recipeFields(original),after=recipeFields(candidate),changes={};
  for(const k of PATCH_KEYS)if(base[k]!==after[k])changes[k]=after[k];
  if(!Object.keys(changes).length)throw Error('Patch does not change any fields');
  return validateProposal({schema:PATCH_SCHEMA,target:{id:original.id,type:'page',url:original.url,title:original.title},
    base:{version:original.version,fields:base},changes,message,author:original.author,createdAt:new Date().toISOString(),evidence});
}
function reviewProposal(raw,source,fixtures=[]){
  const proposal=validateProposal(raw),reasons=[];
  if(!source||source.type!=='page'||safeUrl(source.url)!==proposal.target.url)reasons.push('Choose a webpage Lens with the EXACT proposed URL');
  if(source&&source.type==='page'){
    if((source.version||1)!==proposal.base.version)reasons.push('Stale base version: local revision '+(source.version||1)+' vs proposed '+proposal.base.version);
    const current=recipeFields(source);
    for(const k of PATCH_KEYS)if(current[k]!==proposal.base.fields[k]){reasons.push('Base changed since this patch was made: '+k);break;}
  }
  const candidate=source&&source.type==='page'?cleanRecipe({...source,...proposal.changes,version:(source.version||1)+1}):null;
  const tests=source&&candidate?(fixtures||[]).filter(f=>f.sourceId===source.id).map(f=>{
    try{const verdict=fixtureVerdict(f,candidate);return {name:text(f.title,110),pass:verdict.pass,expected:verdict.expected,actual:verdict.result.outcome};}
    catch(e){return {name:text(f.title,110),pass:false,expected:f.expected,actual:'error: '+e.message};}
  }):[];
  if(!tests.length)reasons.push('No private local regression cases for the target Lens: create at least one');
  if(tests.some(t=>!t.pass))reasons.push('At least one local regression case failed');
  return {ok:!reasons.length,reasons,tests,candidate,proposal,differences:Object.keys(proposal.changes).map(k=>({field:k,old:proposal.base.fields[k],next:proposal.changes[k]}))};
}
root.ProgRSSCore=Object.freeze({SCHEMA,LIMIT,FOLDER_EDITION_SCHEMA,PAGE_CHANGE_SCHEMA,PAGE_WATCH_REPAIR_SCHEMA,PAGE_WATCH_HEALTH_SCHEMA,PAGE_WATCH_STABILITY_SCHEMA,SOURCE_NOTE_MAX_CODE_POINTS,uid,safeUrl,text,languageTag,bodyText,htmlText,filterMatch,folderEditionInfo,parseFeed,staticHtml,extractPage,pageWatchCaptureSignature,pageWatchCaptureHealth,pageWatchStabilityDecision,pageWatchRepairProposals,diffText,compareCards,analyzePagePair,fixtureVerdict,cleanFixture,exportFixtures,validateFixtureBundle,FIXTURE_SCHEMA,ingestFeed,ingestPage,compose,composeEvidence,explainItem,itemSignature,validateBundle,exportBundle,importPreview,parseOPML,parseOPMLDetailed,makeOPML,makeJSONFeed,makeFolderEdition,cleanRecipe,cleanCollection,normalizeSourceNoteReason,auditSourceNotes,PATCH_SCHEMA,recipeFields,validateProposal,makeProposal,reviewProposal});
})(globalThis);
