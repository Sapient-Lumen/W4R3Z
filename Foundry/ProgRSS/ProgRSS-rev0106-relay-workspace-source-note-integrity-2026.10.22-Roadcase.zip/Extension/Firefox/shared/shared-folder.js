/* ProgRSS rev0070 · attributable source lists with bounded branch adoption.
 * Pure validation, canonicalization, digest, signature and local-key helpers.
 * A valid signature authenticates one local key over one exact document. It is
 * not proof of a person's identity, publisher authority, or source safety.
 */
(function (root) {
'use strict';

const C = root.ProgRSSCore;
if (!C) throw new Error('ProgRSS shared-folder support requires shared/core.js first.');

const LEGACY_SCHEMA = 'progrss.bundle.v1';
const SCHEMA = 'progrss.bundle.v2';
const LOCATED_SCHEMA = 'progrss.bundle.v3';
const PUBLICATION_SCHEMA = 'progrss.shared-folder.publication.v1';
const INTEGRITY_SCHEMA = 'progrss.shared-folder.integrity.v1';
const SIGNATURE_SCHEMA = 'progrss.shared-folder.signature.v1';
const DISTRIBUTION_SCHEMA = 'progrss.shared-folder.distribution.v1';
const LEGACY_ORIGIN_SCHEMA = 'progrss.shared-folder.origin.v1';
const ORIGIN_SCHEMA = 'progrss.shared-folder.origin.v2';
const LOCATED_ORIGIN_SCHEMA = 'progrss.shared-folder.origin.v3';
const BASELINE_SCHEMA = 'progrss.shared-folder.baseline.v1';
const CONTENTS_SCHEMA = 'progrss.shared-folder.contents.v2';
const DIGEST_DOMAIN = 'ProgRSS/shared-folder-content/v1';
const SIGNATURE_DOMAIN = 'ProgRSS/shared-folder-signature/v1';
const LOCATED_DIGEST_DOMAIN = 'ProgRSS/shared-folder-content/v2';
const LOCATED_SIGNATURE_DOMAIN = 'ProgRSS/shared-folder-signature/v2';
const ALGORITHMS = Object.freeze(['Ed25519', 'ECDSA-P256-SHA256']);
const KEY_DB = 'progrss-curator-keys';
const KEY_STORE = 'identities';
const ACTIVE_KEY = 'active';

const own = (object, key) => Object.prototype.hasOwnProperty.call(object, key);
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const encoder = new TextEncoder();

function exactKeys(value, required, optional = []) {
  if (!plain(value)) return false;
  const allowed = new Set([...required, ...optional]);
  const keys = Object.keys(value);
  return required.every(key => own(value, key)) && keys.every(key => allowed.has(key));
}

function scalarString(value) {
  const string = String(value);
  for (let index = 0; index < string.length; index++) {
    const code = string.charCodeAt(index);
    if (code >= 0xD800 && code <= 0xDBFF) {
      const next = string.charCodeAt(index + 1);
      if (!(next >= 0xDC00 && next <= 0xDFFF)) throw new Error('Shared-folder text contains invalid Unicode.');
      index++;
    } else if (code >= 0xDC00 && code <= 0xDFFF) {
      throw new Error('Shared-folder text contains invalid Unicode.');
    }
  }
  return string;
}

function canonicalString(value) {
  return JSON.stringify(scalarString(value));
}

function canonical(value) {
  if (value === null || typeof value === 'boolean') return JSON.stringify(value);
  if (typeof value === 'string') return canonicalString(value);
  if (typeof value === 'number') {
    if (!Number.isSafeInteger(value)) throw new Error('Shared folders use only portable safe-integer numbers.');
    return String(value);
  }
  if (Array.isArray(value)) return `[${value.map(canonical).join(',')}]`;
  if (plain(value)) {
    return `{${Object.keys(value).sort().map(key => `${canonicalString(key)}:${canonical(value[key])}`).join(',')}}`;
  }
  throw new Error('Shared-folder data contains a value that is not portable JSON.');
}

function bytesToBase64Url(bytes) {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

function base64UrlToBytes(value, expectedLength) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9_-]+$/.test(value) || value.length > 180) {
    throw new Error('The shared-folder signing key or signature is malformed.');
  }
  const padded = value.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - value.length % 4) % 4);
  let raw;
  try { raw = atob(padded); } catch { throw new Error('The shared-folder signing key or signature is malformed.'); }
  const bytes = Uint8Array.from(raw, character => character.charCodeAt(0));
  if (bytes.length !== expectedLength || bytesToBase64Url(bytes) !== value) {
    throw new Error('The shared-folder signing key or signature has the wrong length.');
  }
  return bytes;
}

function webCrypto() {
  if (!root.crypto?.subtle) throw new Error('Web Crypto is unavailable in this browser context.');
  return root.crypto.subtle;
}

function algorithmParams(algorithm) {
  return algorithm === 'Ed25519' ? {name: 'Ed25519'} : {name: 'ECDSA', namedCurve: 'P-256'};
}

function signatureParams(algorithm) {
  return algorithm === 'Ed25519' ? {name: 'Ed25519'} : {name: 'ECDSA', hash: 'SHA-256'};
}

function publicKeySize(algorithm) {
  return algorithm === 'Ed25519' ? 32 : 65;
}

async function sha256Hex(value) {
  const digest = await webCrypto().digest('SHA-256', encoder.encode(typeof value === 'string' ? value : canonical(value)));
  return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
}

/* Hash raw bytes rather than their base64 text for compatibility with the
 * existing Advanced Workbench identity fingerprint. */
async function rawKeyId(algorithm, publicKey) {
  if (!ALGORITHMS.includes(algorithm)) throw new Error('The shared folder uses an unsupported signing algorithm.');
  const bytes = base64UrlToBytes(publicKey, publicKeySize(algorithm));
  if (algorithm === 'ECDSA-P256-SHA256' && bytes[0] !== 4) throw new Error('The shared folder contains a malformed P-256 public key.');
  const digest = await webCrypto().digest('SHA-256', bytes);
  const hex = [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, '0')).join('');
  return `${algorithm.toLowerCase()}:${hex}`;
}

function cleanTime(value, label) {
  const time = C.text(value, 60);
  if (!time || !Number.isFinite(Date.parse(time)) || new Date(time).toISOString() !== time) {
    throw new Error(`${label} must be an exact ISO timestamp.`);
  }
  return time;
}

function cleanPublication(raw, rootId, exportedAt) {
  if (!exactKeys(raw, ['schema', 'id', 'curator', 'note', 'issuedAt']) || raw.schema !== PUBLICATION_SCHEMA) {
    throw new Error('The shared folder has invalid attribution metadata.');
  }
  const id = String(raw.id || '');
  if (!/^[A-Za-z0-9_-]{1,100}$/.test(id)) throw new Error('The shared folder has an invalid publication identity.');
  const publication = {
    schema: PUBLICATION_SCHEMA,
    id,
    curator: C.text(raw.curator, 80),
    note: C.text(raw.note, 280),
    issuedAt: cleanTime(raw.issuedAt, 'The shared-folder issue time')
  };
  if (publication.issuedAt !== exportedAt) throw new Error('The shared-folder issue time does not match its export time.');
  if (!rootId) throw new Error('The shared folder has no top-level folder identity.');
  return publication;
}

function cleanUpdateUrl(value) {
  const raw = String(value || '');
  if (!raw) return '';
  try { return C.safeUrl(raw); }
  catch { throw new Error('The shared folder has an invalid future-copy address.'); }
}

function cleanDistribution(raw) {
  if (!exactKeys(raw, ['schema', 'updateUrl']) || raw.schema !== DISTRIBUTION_SCHEMA) {
    throw new Error('The shared folder has invalid future-copy metadata.');
  }
  const updateUrl = cleanUpdateUrl(raw.updateUrl);
  if (!updateUrl) throw new Error('The shared folder has no future-copy address.');
  const distribution = {schema: DISTRIBUTION_SCHEMA, updateUrl};
  if (canonical(distribution) !== canonical(raw)) throw new Error('The shared-folder future-copy metadata is not canonical.');
  return distribution;
}

function cleanSignature(raw) {
  if (!exactKeys(raw, ['schema', 'algorithm', 'publicKey', 'keyId', 'value']) || raw.schema !== SIGNATURE_SCHEMA) {
    throw new Error('The shared folder has invalid signature metadata.');
  }
  const algorithm = String(raw.algorithm || '');
  if (!ALGORITHMS.includes(algorithm)) throw new Error('The shared folder uses an unsupported signing algorithm.');
  const publicKey = String(raw.publicKey || '');
  const value = String(raw.value || '');
  base64UrlToBytes(publicKey, publicKeySize(algorithm));
  base64UrlToBytes(value, 64);
  if (algorithm === 'ECDSA-P256-SHA256' && base64UrlToBytes(publicKey, 65)[0] !== 4) {
    throw new Error('The shared folder contains a malformed P-256 public key.');
  }
  const fingerprint = String(raw.keyId || '');
  if (!new RegExp(`^${algorithm.toLowerCase()}:[a-f0-9]{64}$`).test(fingerprint)) {
    throw new Error('The shared-folder signer fingerprint is malformed.');
  }
  return {schema: SIGNATURE_SCHEMA, algorithm, publicKey, keyId: fingerprint, value};
}

function semanticPayload(document) {
  const located = document.schema === LOCATED_SCHEMA;
  return {
    domain: located ? LOCATED_DIGEST_DOMAIN : DIGEST_DOMAIN,
    schema: document.schema,
    root: document.root,
    title: document.title,
    publication: {
      schema: PUBLICATION_SCHEMA,
      id: document.publication.id,
      curator: document.publication.curator,
      note: document.publication.note
    },
    ...(located ? {distribution: document.distribution} : {}),
    sources: document.sources,
    collections: document.collections
  };
}

function unsignedDocument(document) {
  const located = document.schema === LOCATED_SCHEMA;
  return {
    schema: document.schema,
    exportedAt: document.exportedAt,
    root: document.root,
    title: document.title,
    publication: document.publication,
    ...(located ? {distribution: document.distribution} : {}),
    integrity: {schema: INTEGRITY_SCHEMA, digest: document.integrity.digest},
    sources: document.sources,
    collections: document.collections
  };
}

function signatureContent(document) {
  const domain = document.schema === LOCATED_SCHEMA ? LOCATED_SIGNATURE_DOMAIN : SIGNATURE_DOMAIN;
  return encoder.encode(canonical({domain, document: unsignedDocument(document)}));
}

async function contentDigest(document) {
  return `sha256:${await sha256Hex(semanticPayload(document))}`;
}

function normalizeBase(raw) {
  const base = C.validateBundle({
    schema: LEGACY_SCHEMA,
    exportedAt: raw.exportedAt,
    root: raw.root,
    title: raw.title,
    sources: raw.sources,
    collections: raw.collections
  });
  if (!base.root) throw new Error('The shared folder does not identify one top-level folder.');
  const expected = {
    exportedAt: C.text(raw.exportedAt, 60),
    root: base.root,
    title: base.title || '',
    sources: base.sources,
    collections: base.collections
  };
  const actual = {
    exportedAt: raw.exportedAt,
    root: raw.root,
    title: raw.title,
    sources: raw.sources,
    collections: raw.collections
  };
  if (canonical(expected) !== canonical(actual)) {
    throw new Error('The shared folder contains unexpected or noncanonical recipe fields.');
  }
  return base;
}

async function verifySignature(document, signature) {
  const expectedKeyId = await rawKeyId(signature.algorithm, signature.publicKey);
  if (expectedKeyId !== signature.keyId) throw new Error('The shared-folder signer fingerprint does not match its public key.');
  let key;
  try {
    key = await webCrypto().importKey(
      'raw',
      base64UrlToBytes(signature.publicKey, publicKeySize(signature.algorithm)),
      algorithmParams(signature.algorithm),
      false,
      ['verify']
    );
  } catch (error) {
    throw new Error(`The shared-folder public key could not be read: ${error.message}`);
  }
  let verified = false;
  try {
    verified = await webCrypto().verify(
      signatureParams(signature.algorithm),
      key,
      base64UrlToBytes(signature.value, 64),
      signatureContent(document)
    );
  } catch (error) {
    throw new Error(`Shared-folder signature verification is unavailable: ${error.message}`);
  }
  if (!verified) throw new Error('The shared-folder signature is invalid. Nothing was added.');
  return true;
}

async function validateAttributed(raw, schema) {
  const located = schema === LOCATED_SCHEMA;
  const required = ['schema', 'exportedAt', 'root', 'title', 'publication', 'integrity', 'sources', 'collections'];
  if (located) required.splice(5, 0, 'distribution');
  if (!exactKeys(raw, required) || raw.schema !== schema) {
    throw new Error(located
      ? 'That file is not a supported located ProgRSS shared folder.'
      : 'That file is not a supported attributed ProgRSS shared folder.');
  }
  const base = normalizeBase(raw);
  const exportedAt = cleanTime(raw.exportedAt, 'The shared-folder export time');
  const publication = cleanPublication(raw.publication, base.root, exportedAt);
  const distribution = located ? cleanDistribution(raw.distribution) : null;
  if (!exactKeys(raw.integrity, ['schema', 'digest'], ['signature']) || raw.integrity.schema !== INTEGRITY_SCHEMA) {
    throw new Error('The shared folder has invalid integrity metadata.');
  }
  const digest = String(raw.integrity.digest || '');
  if (!/^sha256:[a-f0-9]{64}$/.test(digest)) throw new Error('The shared-folder content digest is malformed.');
  const signature = own(raw.integrity, 'signature') ? cleanSignature(raw.integrity.signature) : null;
  const document = {
    schema,
    exportedAt,
    root: base.root,
    title: base.title || '',
    publication,
    ...(located ? {distribution} : {}),
    integrity: {schema: INTEGRITY_SCHEMA, digest, ...(signature ? {signature} : {})},
    sources: base.sources,
    collections: base.collections
  };
  const expectedDigest = await contentDigest(document);
  if (expectedDigest !== digest) throw new Error('The shared-folder content digest does not match. Nothing was added.');
  if (signature) await verifySignature(document, signature);
  return {
    document,
    bundle: {
      schema: LEGACY_SCHEMA,
      exportedAt,
      root: base.root,
      title: base.title || '',
      sources: base.sources,
      collections: base.collections
    },
    provenance: {
      schema: located ? LOCATED_ORIGIN_SCHEMA : ORIGIN_SCHEMA,
      publicationId: publication.id,
      curator: publication.curator,
      note: publication.note,
      issuedAt: publication.issuedAt,
      digest,
      signatureState: signature ? 'verified' : 'unsigned',
      ...(located ? {updateUrl: distribution.updateUrl} : {}),
      ...(signature ? {algorithm: signature.algorithm, keyId: signature.keyId} : {})
    }
  };
}

async function validateV2(raw) { return validateAttributed(raw, SCHEMA); }
async function validateV3(raw) { return validateAttributed(raw, LOCATED_SCHEMA); }

async function validate(raw) {
  if (!plain(raw)) throw new Error('That file is not a ProgRSS shared folder.');
  if (raw.schema === SCHEMA) return validateV2(raw);
  if (raw.schema === LOCATED_SCHEMA) return validateV3(raw);
  if (raw.schema === LEGACY_SCHEMA) {
    const bundle = C.validateBundle(raw);
    return {
      document: bundle,
      bundle,
      provenance: {
        schema: ORIGIN_SCHEMA,
        publicationId: bundle.root || '',
        curator: '',
        note: '',
        issuedAt: bundle.exportedAt || '',
        digest: '',
        signatureState: 'legacy'
      }
    };
  }
  throw new Error('That file is not a supported ProgRSS shared folder.');
}

async function create(bundle, options = {}) {
  const base = C.validateBundle(bundle);
  if (!base.root) throw new Error('Choose one top-level folder before sharing.');
  const exportedAt = options.exportedAt ? cleanTime(options.exportedAt, 'The shared-folder export time') : new Date().toISOString();
  const publicationId = String(options.publicationId || base.root);
  if (!/^[A-Za-z0-9_-]{1,100}$/.test(publicationId)) throw new Error('The shared-folder publication identity is invalid.');
  const updateUrl = cleanUpdateUrl(options.updateUrl);
  const schema = updateUrl ? LOCATED_SCHEMA : SCHEMA;
  const document = {
    schema,
    exportedAt,
    root: base.root,
    title: base.title || '',
    publication: {
      schema: PUBLICATION_SCHEMA,
      id: publicationId,
      curator: C.text(options.curator, 80),
      note: C.text(options.note, 280),
      issuedAt: exportedAt
    },
    ...(updateUrl ? {distribution: {schema: DISTRIBUTION_SCHEMA, updateUrl}} : {}),
    integrity: {schema: INTEGRITY_SCHEMA, digest: ''},
    sources: base.sources,
    collections: base.collections
  };
  document.integrity.digest = await contentDigest(document);
  return document;
}

async function sign(document, identity = null) {
  const checked = await validate(document);
  if (checked.document.integrity.signature) throw new Error('This shared folder is already signed.');
  const local = identity || await getIdentity();
  if (!local) throw new Error('No local signing identity exists in this browser.');
  if (!local.privateKey || local.privateKey.extractable || !ALGORITHMS.includes(local.algorithm)) {
    throw new Error('The local signing identity is unavailable or unsafe.');
  }
  if (await rawKeyId(local.algorithm, local.publicKey) !== local.keyId) {
    throw new Error('The local signing identity fingerprint no longer matches its public key.');
  }
  const value = bytesToBase64Url(new Uint8Array(await webCrypto().sign(
    signatureParams(local.algorithm), local.privateKey, signatureContent(checked.document)
  )));
  const signed = {
    ...checked.document,
    integrity: {
      ...checked.document.integrity,
      signature: {
        schema: SIGNATURE_SCHEMA,
        algorithm: local.algorithm,
        publicKey: local.publicKey,
        keyId: local.keyId,
        value
      }
    }
  };
  await validate(signed);
  return signed;
}

function openIdentityDatabase() {
  return new Promise((resolve, reject) => {
    if (!root.indexedDB) return reject(new Error('IndexedDB is unavailable; a local signing identity cannot be stored safely.'));
    const request = root.indexedDB.open(KEY_DB, 1);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(KEY_STORE)) request.result.createObjectStore(KEY_STORE);
    };
    request.onerror = () => reject(request.error || new Error('The signing-key vault is unavailable.'));
    request.onblocked = () => reject(new Error('The signing-key vault is blocked by another ProgRSS window.'));
    request.onsuccess = () => resolve(request.result);
  });
}

async function withIdentityDatabase(mode, operation) {
  const database = await openIdentityDatabase();
  try {
    return await new Promise((resolve, reject) => {
      let request;
      let transaction;
      try {
        transaction = database.transaction(KEY_STORE, mode);
        request = operation(transaction.objectStore(KEY_STORE));
      } catch (error) {
        reject(error);
        return;
      }
      transaction.oncomplete = () => resolve(request?.result);
      transaction.onerror = () => reject(transaction.error || new Error('The signing-key transaction failed.'));
      transaction.onabort = () => reject(transaction.error || new Error('The signing-key transaction was aborted.'));
    });
  } finally {
    database.close();
  }
}

async function getIdentity() {
  const identity = await withIdentityDatabase('readonly', store => store.get(ACTIVE_KEY));
  if (!identity) return null;
  if (!identity.privateKey || identity.privateKey.extractable || !identity.publicKey || !ALGORITHMS.includes(identity.algorithm)) {
    throw new Error('The local signing identity is corrupted or unexpectedly exportable.');
  }
  if (identity.keyId !== await rawKeyId(identity.algorithm, identity.publicKey)) {
    throw new Error('The local signing identity fingerprint does not match its public key.');
  }
  return identity;
}

function publicIdentity(identity) {
  if (!identity) return null;
  return {
    algorithm: identity.algorithm,
    publicKey: identity.publicKey,
    keyId: identity.keyId,
    createdAt: C.text(identity.createdAt, 60)
  };
}

async function createIdentity() {
  if (await getIdentity()) throw new Error('A local signing identity already exists. ProgRSS will not overwrite its private key.');
  let pair;
  let algorithm = 'Ed25519';
  try {
    pair = await webCrypto().generateKey({name: 'Ed25519'}, false, ['sign', 'verify']);
  } catch {
    algorithm = 'ECDSA-P256-SHA256';
    pair = await webCrypto().generateKey({name: 'ECDSA', namedCurve: 'P-256'}, false, ['sign', 'verify']);
  }
  if (pair.privateKey.extractable) throw new Error('The generated signing key was unexpectedly exportable.');
  const publicKey = bytesToBase64Url(new Uint8Array(await webCrypto().exportKey('raw', pair.publicKey)));
  const record = {
    algorithm,
    publicKey,
    keyId: await rawKeyId(algorithm, publicKey),
    privateKey: pair.privateKey,
    createdAt: new Date().toISOString()
  };
  try {
    await withIdentityDatabase('readwrite', store => store.add(record, ACTIVE_KEY));
  } catch (error) {
    if (String(error?.name || '').includes('Constraint')) throw new Error('Another ProgRSS window created a signing identity first.');
    throw error;
  }
  return publicIdentity(record);
}

function connectedBaseline(base) {
  if (!base.root) throw new Error('The shared-folder baseline has no top-level folder.');
  const byCollection = new Map(base.collections.map(collection => [collection.id, collection]));
  const reachableCollections = new Set();
  const reachableSources = new Set();
  function walk(id) {
    if (reachableCollections.has(id)) return;
    const collection = byCollection.get(id);
    if (!collection) throw new Error('The shared-folder baseline contains a missing nested folder.');
    reachableCollections.add(id);
    for (const member of collection.members) {
      if (member.kind === 'source') reachableSources.add(member.id);
      else walk(member.id);
    }
  }
  walk(base.root);
  if (reachableCollections.size !== base.collections.length || reachableSources.size !== base.sources.length) {
    throw new Error('The shared-folder baseline contains unrelated extra records.');
  }
  return base;
}

function normalizeBaseline(raw, strict = false) {
  try {
    if (!exactKeys(raw, ['schema', 'root', 'title', 'sources', 'collections', 'sourceMap', 'collectionMap']) || raw.schema !== BASELINE_SCHEMA) {
      throw new Error('The shared-folder update baseline has unexpected fields.');
    }
    const base = connectedBaseline(C.validateBundle({
      schema: LEGACY_SCHEMA,
      exportedAt: '',
      root: raw.root,
      title: raw.title,
      sources: raw.sources,
      collections: raw.collections
    }));
    const sourceIds = new Set(base.sources.map(source => source.id));
    const collectionIds = new Set(base.collections.map(collection => collection.id));
    if (!Array.isArray(raw.sourceMap) || raw.sourceMap.length !== sourceIds.size ||
        !Array.isArray(raw.collectionMap) || raw.collectionMap.length !== collectionIds.size) {
      throw new Error('The shared-folder update baseline has an incomplete identity map.');
    }
    const sourceMap = [];
    const sourceRemote = new Set();
    for (const row of raw.sourceMap) {
      if (!exactKeys(row, ['remoteId', 'localId', 'created'])) throw new Error('The shared-folder source map is malformed.');
      const remoteId = String(row.remoteId || '');
      const localId = String(row.localId || '');
      if (!sourceIds.has(remoteId) || sourceRemote.has(remoteId) || !/^[A-Za-z0-9_-]{1,100}$/.test(localId) || typeof row.created !== 'boolean') {
        throw new Error('The shared-folder source map is invalid.');
      }
      sourceRemote.add(remoteId);
      sourceMap.push({remoteId, localId, created: row.created});
    }
    const collectionMap = [];
    const collectionRemote = new Set();
    const collectionLocal = new Set();
    for (const row of raw.collectionMap) {
      if (!exactKeys(row, ['remoteId', 'localId'])) throw new Error('The shared-folder folder map is malformed.');
      const remoteId = String(row.remoteId || '');
      const localId = String(row.localId || '');
      if (!collectionIds.has(remoteId) || collectionRemote.has(remoteId) || collectionLocal.has(localId) || !/^[A-Za-z0-9_-]{1,100}$/.test(localId)) {
        throw new Error('The shared-folder folder map is invalid.');
      }
      collectionRemote.add(remoteId);
      collectionLocal.add(localId);
      collectionMap.push({remoteId, localId});
    }
    const baseline = {
      schema: BASELINE_SCHEMA,
      root: base.root,
      title: base.title || '',
      sources: base.sources,
      collections: base.collections,
      sourceMap,
      collectionMap
    };
    if (canonical(baseline) !== canonical(raw)) throw new Error('The shared-folder update baseline is not canonical.');
    return baseline;
  } catch (error) {
    if (strict) throw error;
    return null;
  }
}

function createBaseline(bundle, sourceMap, collectionMap) {
  const base = connectedBaseline(C.validateBundle(bundle));
  return normalizeBaseline({
    schema: BASELINE_SCHEMA,
    root: base.root,
    title: base.title || '',
    sources: base.sources,
    collections: base.collections,
    sourceMap: Array.isArray(sourceMap) ? sourceMap : [],
    collectionMap: Array.isArray(collectionMap) ? collectionMap : []
  }, true);
}

function normalizeOriginV1(raw) {
  if (!exactKeys(raw, ['schema', 'publicationId', 'curator', 'note', 'issuedAt', 'importedAt', 'digest', 'signatureState'], ['algorithm', 'keyId']) || raw.schema !== LEGACY_ORIGIN_SCHEMA) {
    throw new Error('The shared-folder origin record has unexpected fields.');
  }
  const publicationId = String(raw.publicationId || '');
  if (!/^[A-Za-z0-9_-]{1,100}$/.test(publicationId)) throw new Error('The shared-folder origin has an invalid publication identity.');
  const signatureState = String(raw.signatureState || '');
  if (!['verified', 'unsigned', 'legacy'].includes(signatureState)) throw new Error('The shared-folder origin has an invalid signature state.');
  const importedAt = cleanTime(raw.importedAt, 'The shared-folder import time');
  let issuedAt = C.text(raw.issuedAt, 60);
  if (issuedAt) issuedAt = cleanTime(issuedAt, 'The shared-folder issue time');
  const digest = String(raw.digest || '');
  if (signatureState === 'legacy') {
    if (digest) throw new Error('A legacy shared-folder origin cannot claim a content digest.');
    if (own(raw, 'algorithm') || own(raw, 'keyId')) throw new Error('A legacy shared-folder origin cannot claim a verified signing key.');
  } else if (!/^sha256:[a-f0-9]{64}$/.test(digest)) {
    throw new Error('The shared-folder origin has an invalid content digest.');
  }
  const origin = {
    schema: LEGACY_ORIGIN_SCHEMA,
    publicationId,
    curator: C.text(raw.curator, 80),
    note: C.text(raw.note, 280),
    issuedAt,
    importedAt,
    digest,
    signatureState
  };
  if (signatureState === 'verified') {
    const algorithm = String(raw.algorithm || '');
    const fingerprint = String(raw.keyId || '');
    if (!ALGORITHMS.includes(algorithm) || !new RegExp(`^${algorithm.toLowerCase()}:[a-f0-9]{64}$`).test(fingerprint)) {
      throw new Error('The shared-folder origin has invalid signer evidence.');
    }
    origin.algorithm = algorithm;
    origin.keyId = fingerprint;
  } else if (own(raw, 'algorithm') || own(raw, 'keyId')) {
    throw new Error('An unsigned shared-folder origin cannot claim a verified signing key.');
  }
  if (canonical(origin) !== canonical(raw)) throw new Error('The shared-folder origin is not canonical.');
  return origin;
}

function normalizeOriginV2(raw) {
  if (!exactKeys(raw, ['schema', 'publicationId', 'curator', 'note', 'issuedAt', 'importedAt', 'updatedAt', 'digest', 'signatureState', 'baseline'], ['algorithm', 'keyId']) || raw.schema !== ORIGIN_SCHEMA) {
    throw new Error('The shared-folder continuity record has unexpected fields.');
  }
  const publicationId = String(raw.publicationId || '');
  if (!/^[A-Za-z0-9_-]{1,100}$/.test(publicationId)) throw new Error('The shared-folder continuity record has an invalid publication identity.');
  const signatureState = String(raw.signatureState || '');
  if (!['verified', 'unsigned', 'legacy'].includes(signatureState)) throw new Error('The shared-folder continuity record has an invalid signature state.');
  const importedAt = cleanTime(raw.importedAt, 'The shared-folder first import time');
  const updatedAt = cleanTime(raw.updatedAt, 'The shared-folder last update time');
  let issuedAt = C.text(raw.issuedAt, 60);
  if (issuedAt) issuedAt = cleanTime(issuedAt, 'The shared-folder issue time');
  const digest = String(raw.digest || '');
  if (signatureState === 'legacy') {
    if (digest) throw new Error('A legacy shared-folder continuity record cannot claim a content digest.');
    if (own(raw, 'algorithm') || own(raw, 'keyId')) throw new Error('A legacy shared-folder continuity record cannot claim a verified signing key.');
  } else if (!/^sha256:[a-f0-9]{64}$/.test(digest)) {
    throw new Error('The shared-folder continuity record has an invalid content digest.');
  }
  const origin = {
    schema: ORIGIN_SCHEMA,
    publicationId,
    curator: C.text(raw.curator, 80),
    note: C.text(raw.note, 280),
    issuedAt,
    importedAt,
    updatedAt,
    digest,
    signatureState,
    baseline: normalizeBaseline(raw.baseline, true)
  };
  if (signatureState === 'verified') {
    const algorithm = String(raw.algorithm || '');
    const fingerprint = String(raw.keyId || '');
    if (!ALGORITHMS.includes(algorithm) || !new RegExp(`^${algorithm.toLowerCase()}:[a-f0-9]{64}$`).test(fingerprint)) {
      throw new Error('The shared-folder continuity record has invalid signer evidence.');
    }
    origin.algorithm = algorithm;
    origin.keyId = fingerprint;
  } else if (own(raw, 'algorithm') || own(raw, 'keyId')) {
    throw new Error('An unsigned shared-folder continuity record cannot claim a verified signing key.');
  }
  if (canonical(origin) !== canonical(raw)) throw new Error('The shared-folder continuity record is not canonical.');
  return origin;
}

function normalizeOriginV3(raw) {
  if (!exactKeys(raw, ['schema', 'publicationId', 'curator', 'note', 'issuedAt', 'importedAt', 'updatedAt', 'digest', 'signatureState', 'baseline', 'updateUrl'], ['algorithm', 'keyId']) || raw.schema !== LOCATED_ORIGIN_SCHEMA) {
    throw new Error('The shared-folder located continuity record has unexpected fields.');
  }
  const {updateUrl, ...withoutUpdateUrl} = raw;
  const base = normalizeOriginV2({...withoutUpdateUrl, schema: ORIGIN_SCHEMA});
  const origin = {
    ...base,
    schema: LOCATED_ORIGIN_SCHEMA,
    updateUrl: cleanUpdateUrl(raw.updateUrl)
  };
  if (!origin.updateUrl) throw new Error('The shared-folder located continuity record has no future-copy address.');
  if (canonical(origin) !== canonical(raw)) throw new Error('The shared-folder located continuity record is not canonical.');
  return origin;
}

function normalizeOrigin(raw, strict = false) {
  try {
    if (!plain(raw)) throw new Error('The shared-folder origin record is missing.');
    if (raw.schema === LOCATED_ORIGIN_SCHEMA) return normalizeOriginV3(raw);
    if (raw.schema === ORIGIN_SCHEMA) return normalizeOriginV2(raw);
    if (raw.schema === LEGACY_ORIGIN_SCHEMA) return normalizeOriginV1(raw);
    throw new Error('The shared-folder origin record uses an unsupported schema.');
  } catch (error) {
    if (strict) throw error;
    return null;
  }
}

function createOrigin(provenance, appliedAt, baseline, previous = null) {
  const prior = normalizeOrigin(previous, false);
  const time = cleanTime(appliedAt, 'The shared-folder update time');
  const state = ['verified', 'unsigned', 'legacy'].includes(provenance?.signatureState) ? provenance.signatureState : 'legacy';
  const updateUrl = cleanUpdateUrl(provenance?.updateUrl);
  const origin = {
    schema: updateUrl ? LOCATED_ORIGIN_SCHEMA : ORIGIN_SCHEMA,
    publicationId: C.text(provenance?.publicationId, 100),
    curator: C.text(provenance?.curator, 80),
    note: C.text(provenance?.note, 280),
    issuedAt: C.text(provenance?.issuedAt, 60),
    importedAt: prior?.importedAt || time,
    updatedAt: time,
    digest: C.text(provenance?.digest, 80),
    signatureState: state,
    baseline: normalizeBaseline(baseline, true),
    ...(updateUrl ? {updateUrl} : {}),
    ...(state === 'verified' ? {algorithm: C.text(provenance?.algorithm, 40), keyId: C.text(provenance?.keyId, 100)} : {})
  };
  return normalizeOrigin(origin, true);
}

function compactFingerprint(value) {
  const text = String(value || '');
  const colon = text.indexOf(':');
  if (colon < 0) return text;
  const algorithm = text.slice(0, colon);
  const digest = text.slice(colon + 1);
  return `${algorithm}:${digest.slice(0, 12)}…${digest.slice(-8)}`;
}

/* Return one connected folder branch from an already validated bundle. The
 * result is deliberately a legacy portable recipe graph: it is a local
 * excerpt of the checked document, not a newly signed publication and not an
 * update subscription to the parent publication.
 */
function branch(bundle, folderId) {
  const base = C.validateBundle(bundle);
  const selectedId = String(folderId || '');
  const collectionById = new Map(base.collections.map(collection => [collection.id, collection]));
  const selected = collectionById.get(selectedId);
  if (!selected) throw new Error('Choose one folder that is present in this source list.');
  const collectionIds = new Set();
  const sourceIds = new Set();
  function walk(id) {
    if (collectionIds.has(id)) return;
    const collection = collectionById.get(id);
    if (!collection) throw new Error('The selected folder contains a missing nested folder.');
    collectionIds.add(id);
    for (const member of collection.members || []) {
      if (member.kind === 'source') sourceIds.add(member.id);
      else walk(member.id);
    }
  }
  walk(selectedId);
  const subset = {
    schema: LEGACY_SCHEMA,
    exportedAt: base.exportedAt,
    root: selectedId,
    title: selected.title,
    sources: base.sources.filter(source => sourceIds.has(source.id)),
    collections: base.collections.filter(collection => collectionIds.has(collection.id))
  };
  return C.validateBundle(subset);
}

/* A bounded, human-facing table of contents for an already validated bundle.
 * It deliberately exposes host names and folder paths rather than selectors,
 * recipe internals, or complete addresses. The bundle contains at most one
 * hundred source and folder records, so the complete result remains bounded.
 */
function contents(bundle, sourceStates = {}, folderStates = {}) {
  const base = C.validateBundle(bundle);
  if (!base.root) throw new Error('The shared folder has no top-level folder to describe.');
  const sourceById = new Map(base.sources.map(source => [source.id, source]));
  const collectionById = new Map(base.collections.map(collection => [collection.id, collection]));
  const rootFolder = collectionById.get(base.root);
  if (!rootFolder) throw new Error('The shared folder top-level folder is unavailable.');

  const stateValue = (states, id) => states && typeof states.get === 'function' ? states.get(id) : states?.[id];
  const pathByCollection = new Map([[base.root, [rootFolder.title]]]);
  const folderOrder = [];
  const queue = [base.root];
  while (queue.length) {
    const id = queue.shift();
    if (folderOrder.includes(id)) continue;
    folderOrder.push(id);
    const folder = collectionById.get(id);
    const parentPath = pathByCollection.get(id) || [folder?.title || 'Untitled folder'];
    for (const member of folder?.members || []) {
      if (member.kind !== 'collection' || pathByCollection.has(member.id)) continue;
      const child = collectionById.get(member.id);
      if (!child) continue;
      pathByCollection.set(member.id, [...parentPath, child.title]);
      queue.push(member.id);
    }
  }
  for (const collection of base.collections) {
    if (!pathByCollection.has(collection.id)) {
      pathByCollection.set(collection.id, [collection.title]);
      folderOrder.push(collection.id);
    }
  }

  const sourceFolders = new Map(base.sources.map(source => [source.id, []]));
  const sourcePlacements = new Map(base.sources.map(source => [source.id, []]));
  const sourceOrder = [];
  const sourceSeen = new Set();
  for (const folderId of folderOrder) {
    const folder = collectionById.get(folderId);
    const path = (pathByCollection.get(folderId) || [folder?.title || 'Untitled folder']).join(' › ');
    for (const member of folder?.members || []) {
      if (member.kind !== 'source' || !sourceById.has(member.id)) continue;
      const paths = sourceFolders.get(member.id) || [];
      if (!paths.includes(path)) paths.push(path);
      sourceFolders.set(member.id, paths);
      const placement = {folderId, folderPath: path};
      const reason = C.normalizeSourceNoteReason(member.reason);
      if (reason !== undefined) placement.reason = reason;
      sourcePlacements.get(member.id).push(placement);
      if (!sourceSeen.has(member.id)) {
        sourceSeen.add(member.id);
        sourceOrder.push(member.id);
      }
    }
  }
  for (const source of base.sources) if (!sourceSeen.has(source.id)) sourceOrder.push(source.id);

  const branchMemo = new Map();
  function branchCounts(id) {
    if (branchMemo.has(id)) return branchMemo.get(id);
    const folder = collectionById.get(id);
    const collectionIds = new Set([id]);
    const sourceIds = new Set();
    for (const member of folder?.members || []) {
      if (member.kind === 'source') sourceIds.add(member.id);
      else {
        const child = branchCounts(member.id);
        for (const childId of child.collectionIds) collectionIds.add(childId);
        for (const sourceId of child.sourceIds) sourceIds.add(sourceId);
      }
    }
    const result = {collectionIds, sourceIds};
    branchMemo.set(id, result);
    return result;
  }

  const folders = folderOrder.map(id => {
    const folder = collectionById.get(id);
    const path = pathByCollection.get(id) || [folder.title];
    const selected = branchCounts(id);
    const selectedSources = [...selected.sourceIds].map(sourceId => sourceById.get(sourceId)).filter(Boolean);
    return {
      id,
      title: folder.title,
      path: path.join(' › '),
      depth: Math.max(0, path.length - 1),
      isRoot: id === base.root,
      directSources: (folder.members || []).filter(member => member.kind === 'source').length,
      directSourceNotes: (folder.members || []).filter(member => member.kind === 'source' && C.normalizeSourceNoteReason(member.reason) !== undefined).length,
      directFolders: (folder.members || []).filter(member => member.kind === 'collection').length,
      branchSources: selectedSources.length,
      branchFeeds: selectedSources.filter(source => source.type === 'rss').length,
      branchPageWatches: selectedSources.filter(source => source.type === 'page').length,
      branchFolders: selected.collectionIds.size,
      branchSourceNotes: Array.from(selected.collectionIds).reduce((total, branchFolderId) => {
        const branchFolder = collectionById.get(branchFolderId);
        return total + (branchFolder?.members || []).filter(member => member.kind === 'source' && C.normalizeSourceNoteReason(member.reason) !== undefined).length;
      }, 0),
      state: C.text(stateValue(folderStates, id), 40) || 'listed'
    };
  });
  const sources = sourceOrder.map(id => {
    const source = sourceById.get(id);
    let host = '';
    try { host = new URL(source.url).host; } catch {}
    const paths = sourceFolders.get(id) || [];
    const placements = sourcePlacements.get(id) || [];
    return {
      id,
      title: source.title,
      type: source.type,
      host,
      folderCount: paths.length,
      folders: paths.slice(0, 8),
      foldersOmitted: Math.max(0, paths.length - 8),
      placements,
      sourceNoteCount: placements.filter(placement => placement.reason !== undefined).length,
      state: C.text(stateValue(sourceStates, id), 40) || 'listed'
    };
  });
  return {
    schema: CONTENTS_SCHEMA,
    title: base.title || rootFolder.title || 'Shared folder',
    root: base.root,
    sourceCount: sources.length,
    feedCount: sources.filter(source => source.type === 'rss').length,
    pageWatchCount: sources.filter(source => source.type === 'page').length,
    folderCount: folders.length,
    sourceNoteCount: sources.reduce((total, source) => total + source.sourceNoteCount, 0),
    maxDepth: folders.reduce((maximum, folder) => Math.max(maximum, folder.depth), 0),
    sources,
    folders,
    network: false,
    writes: false
  };
}

root.ProgRSSSharedFolder = Object.freeze({
  LEGACY_SCHEMA, SCHEMA, LOCATED_SCHEMA, PUBLICATION_SCHEMA, INTEGRITY_SCHEMA, SIGNATURE_SCHEMA, DISTRIBUTION_SCHEMA, LEGACY_ORIGIN_SCHEMA, ORIGIN_SCHEMA, LOCATED_ORIGIN_SCHEMA, BASELINE_SCHEMA, CONTENTS_SCHEMA,
  DIGEST_DOMAIN, SIGNATURE_DOMAIN, LOCATED_DIGEST_DOMAIN, LOCATED_SIGNATURE_DOMAIN, ALGORITHMS, canonical, contentDigest, validate, validateV2, validateV3,
  create, sign, verifySignature, rawKeyId, bytesToBase64Url, base64UrlToBytes,
  getIdentity, createIdentity, publicIdentity, normalizeBaseline, createBaseline, normalizeOrigin, createOrigin, compactFingerprint, branch, contents
});
})(globalThis);
