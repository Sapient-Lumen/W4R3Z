'use strict';

(function installProgRSSCapture(root) {
  /**
   * Extract bounded rendered-page candidates and page-boundary evidence.
   *
   * This function is intentionally self-contained because WebExtensions
   * serializes it for scripting.executeScript(). It must not depend on page
   * globals beyond the DOM, URL, and standard built-ins.
   */
  function extract(reviewedUrl, reviewedSourceId, incomingRecipe, version) {
    const ASSESSMENT_SCHEMA = 'progrss.capture-section-assessment.v1';
    const CONTEXT_SCHEMA = 'progrss.capture-page-context.v1';
    const MAX_OPEN_ROOTS = 32;
    const MAX_ROOT_SCAN = 20000;
    const MAX_QUERY_MATCHES = 5000;
    const tidy = (value, limit = 1200) => String(value || '').replace(/\s+/g, ' ').trim().slice(0, limit);
    const cleanSelector = (value, limit) => tidy(value, limit);
    const clamp = (value, minimum, maximum) => Math.max(minimum, Math.min(maximum, value));

    // querySelectorAll does not cross a shadow boundary. Capture deliberately
    // observes open shadow roots while retaining a top-frame-only boundary.
    // Closed shadow roots remain inaccessible and are never claimed as absent.
    const queryRoots = [document];
    const seenRoots = new Set(queryRoots);
    let scannedElements = 0;
    for (let rootIndex = 0; rootIndex < queryRoots.length && queryRoots.length <= MAX_OPEN_ROOTS; rootIndex += 1) {
      let elements = [];
      try { elements = Array.from(queryRoots[rootIndex].querySelectorAll('*')); } catch {}
      for (const element of elements) {
        scannedElements += 1;
        if (scannedElements > MAX_ROOT_SCAN || queryRoots.length >= MAX_OPEN_ROOTS) break;
        const shadow = element?.shadowRoot;
        if (shadow && !seenRoots.has(shadow)) {
          seenRoots.add(shadow);
          queryRoots.push(shadow);
        }
      }
      if (scannedElements > MAX_ROOT_SCAN) break;
    }

    const safeAllRaw = selector => {
      if (!selector) return [];
      const result = [];
      const seen = new Set();
      for (const queryRoot of queryRoots) {
        let rows = [];
        try { rows = Array.from(queryRoot.querySelectorAll(selector)); } catch { return []; }
        for (const row of rows) {
          if (seen.has(row)) continue;
          seen.add(row);
          result.push(row);
          if (result.length >= MAX_QUERY_MATCHES) return result;
        }
      }
      return result;
    };
    const composedParent = node => {
      if (!node) return null;
      if (node.parentElement) return node.parentElement;
      try { return node.getRootNode?.()?.host || null; } catch { return null; }
    };
    const hidden = node => {
      if (!node || node.nodeType !== 1) return true;
      const visited = new Set();
      for (let current = node; current && current.nodeType === 1 && !visited.has(current); current = composedParent(current)) {
        visited.add(current);
        if (current.hidden || current.getAttribute?.('aria-hidden') === 'true') return true;
        try {
          const style = getComputedStyle(current);
          if (style.display === 'none' || style.visibility === 'hidden' || style.visibility === 'collapse') return true;
        } catch {}
      }
      return false;
    };
    const safeAll = selector => safeAllRaw(selector).filter(node => !hidden(node));
    const composedContains = (container, node) => {
      if (!container || !node) return false;
      try { if (container === node || container.contains?.(node)) return true; } catch {}
      const visited = new Set();
      for (let current = composedParent(node); current && !visited.has(current); current = composedParent(current)) {
        if (current === container) return true;
        visited.add(current);
      }
      return false;
    };
    const absolute = value => {
      try {
        const url = new URL(String(value || ''), location.href);
        url.hash = '';
        return /^https?:$/.test(url.protocol) ? url.href : '';
      } catch { return ''; }
    };
    const recipe = raw => ({
      mode: raw?.mode === 'cards' ? 'cards' : 'region',
      selector: cleanSelector(raw?.selector, 350),
      titleSelector: cleanSelector(raw?.titleSelector, 200),
      linkSelector: cleanSelector(raw?.linkSelector, 200),
      threshold: clamp(Math.floor(Number(raw?.threshold) || 1), 1, 100000),
      ignoreNumbers: Boolean(raw?.ignoreNumbers),
    });
    const selectorLooksVolatile = selector => {
      const value = String(selector || '');
      return /(?:^|[.#_-])(?:css|jsx|sc|emotion|styled)[-_][a-z0-9_-]{5,}/i.test(value)
        || /[.#][a-z_-]*[0-9a-f]{8,}[a-z0-9_-]*/i.test(value)
        || /[.#][a-z_-]*\d{5,}[a-z0-9_-]*/i.test(value);
    };
    const semanticSelector = selector => /(^|[\s>+~,])(main|article)(?=$|[\s>+~,.#[:])/i.test(String(selector || ''))
      || /\[(?:role\s*=\s*["']?(?:main|article)|itemprop\s*=\s*["']?(?:articleBody|itemListElement))/i.test(String(selector || ''))
      || /\.h-entry(?:\b|$)/i.test(String(selector || ''));
    const nodeHasSemanticBoundary = node => {
      const tag = String(node?.tagName || '').toLowerCase();
      const role = String(node?.getAttribute?.('role') || '').toLowerCase();
      const itemprop = String(node?.getAttribute?.('itemprop') || '');
      const classes = String(node?.className || '');
      return tag === 'main' || tag === 'article' || role === 'main' || role === 'article'
        || itemprop === 'articleBody' || itemprop === 'itemListElement' || /(?:^|\s)h-entry(?:\s|$)/.test(classes);
    };
    const stableNameCount = nodes => nodes.slice(0, 24).reduce((total, node) => {
      const id = tidy(node?.id, 120);
      const role = tidy(node?.getAttribute?.('role'), 80);
      const itemprop = tidy(node?.getAttribute?.('itemprop'), 100);
      const aria = tidy(node?.getAttribute?.('aria-label'), 120);
      const stableId = id && !selectorLooksVolatile(`#${id}`);
      return total + Number(Boolean(stableId || role || itemprop || aria));
    }, 0);
    const ignoredExample = selectedNodes => {
      const selected = Array.isArray(selectedNodes) ? selectedNodes : [selectedNodes].filter(Boolean);
      for (const node of safeAll('nav,footer,aside,[role="navigation"],[role="contentinfo"],[role="complementary"]')) {
        if (selected.some(row => composedContains(row, node) || composedContains(node, row))) continue;
        const value = tidy(node.innerText || node.textContent, 500);
        if (value) return value;
      }
      return '';
    };
    const clutterCount = nodes => {
      let count = 0;
      for (const node of nodes.slice(0, 30)) {
        try {
          count += node.querySelectorAll('nav,footer,aside,form,[role="navigation"],[role="contentinfo"],[role="complementary"]').length;
        } catch {}
      }
      return Math.min(count, 999);
    };
    const median = values => {
      if (!values.length) return 0;
      const sorted = [...values].sort((a, b) => a - b);
      const middle = Math.floor(sorted.length / 2);
      return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
    };
    const integerAttribute = (node, name) => {
      const value = Number.parseInt(String(node?.getAttribute?.(name) || ''), 10);
      return Number.isInteger(value) && value > 0 ? value : 0;
    };

    const pageContext = () => {
      const continuationLinks = safeAllRaw('link[rel~="next"],a[rel~="next"]').length;
      const paginationLandmarks = safeAll('nav[aria-label*="pag" i],[role="navigation"][aria-label*="pag" i],[class*="pagination" i],[class~="pager"],[id*="pagination" i],[id*="pager" i]').length;
      const continuationControls = safeAll('[data-load-more],button[aria-label*="more" i],a[aria-label*="more" i]').length;

      const ariaSetNodes = safeAllRaw('[aria-setsize]');
      const ariaPositionedItems = safeAll('[aria-posinset]').length;
      const maximumSetSize = ariaSetNodes.reduce((maximum, node) => Math.max(maximum, integerAttribute(node, 'aria-setsize')), 0);
      let partialSetSignals = Number(maximumSetSize > Math.max(ariaPositionedItems, ariaSetNodes.length));
      for (const grid of safeAllRaw('[aria-rowcount]')) {
        const declared = integerAttribute(grid, 'aria-rowcount');
        let rendered = 0;
        try { rendered = grid.querySelectorAll('[role="row"]').length; } catch {}
        if (declared > rendered && rendered >= 0) partialSetSignals += 1;
      }
      partialSetSignals = Math.min(partialSetSignals, 100);

      const virtualMarkers = safeAll('[data-virtualized],[data-virtual-list],[class*="virtualized" i],[class*="virtual-list" i],[class*="react-window" i],[class*="react-virtualized" i],[id*="virtual-list" i]').length;
      let scrollWindows = 0;
      for (const node of safeAll('[role="list"],[role="listbox"],[role="grid"],[role="tree"],ul,ol,[data-scroll-container]').slice(0, 80)) {
        try {
          const style = getComputedStyle(node);
          if (/(auto|scroll)/.test(style.overflowY || '') && node.clientHeight >= 60 && node.scrollHeight > node.clientHeight + 120) scrollWindows += 1;
        } catch {}
      }
      const modalNodes = new Set(safeAll('dialog[open],[role="dialog"][aria-modal="true"],[aria-modal="true"]'));
      for (const node of safeAll('[class*="consent" i],[id*="consent" i],[class*="cookie-banner" i],[id*="cookie-banner" i],[class*="modal" i],[id*="modal" i]')) {
        try {
          const style = getComputedStyle(node);
          if (style.position === 'fixed' || style.position === 'sticky') modalNodes.add(node);
        } catch {}
      }
      const modalLayers = modalNodes.size;
      const embeddedFrames = safeAll('iframe,frame').length;
      const openShadowRoots = Math.max(0, queryRoots.length - 1);
      const busyRegions = safeAll('[aria-busy="true"]').length;
      const notices = [];
      const addNotice = (kind, tone, summary) => {
        if (notices.length >= 6) return;
        notices.push({kind, tone, summary: tidy(summary, 180)});
      };
      if (continuationLinks || paginationLandmarks || continuationControls) addNotice(
        'continuation', 'boundary',
        'This page appears to continue elsewhere. Capture includes only this rendered page.',
      );
      if (partialSetSignals || virtualMarkers || scrollWindows) addNotice(
        'partial-render', 'caution',
        'This list may render only part of its items at once. Capture includes only entries currently present in the page DOM.',
      );
      if (modalLayers) addNotice(
        'overlay', 'caution',
        'A dialog or consent layer is visible. Dismiss it before choosing if it hides the updates you need.',
      );
      if (busyRegions) addNotice(
        'loading', 'caution',
        'Part of the page still reports that it is loading. Wait, then capture again for a steadier observation.',
      );
      if (embeddedFrames) addNotice(
        'frames', 'boundary',
        `Content inside ${embeddedFrames} embedded frame${embeddedFrames === 1 ? ' is' : 's are'} outside this top-frame capture.`,
      );
      if (openShadowRoots) addNotice(
        'open-shadow', 'included',
        `ProgRSS inspected ${openShadowRoots} open shadow root${openShadowRoots === 1 ? '' : 's'}. Closed shadow content remains outside the capture boundary.`,
      );
      return {
        schema: CONTEXT_SCHEMA,
        notices,
        signals: {
          continuationLinks: Math.min(1000, continuationLinks),
          paginationLandmarks: Math.min(1000, paginationLandmarks),
          continuationControls: Math.min(1000, continuationControls),
          partialSetSignals,
          virtualMarkers: Math.min(1000, virtualMarkers),
          scrollWindows: Math.min(1000, scrollWindows),
          modalLayers: Math.min(1000, modalLayers),
          embeddedFrames: Math.min(1000, embeddedFrames),
          openShadowRoots: Math.min(MAX_OPEN_ROOTS, openShadowRoots),
          busyRegions: Math.min(1000, busyRegions),
        },
      };
    };

    const context = pageContext();

    const assess = ({id, current, nodes, cards, content, rawMatchCount}) => {
      const visibleNodes = nodes.filter(node => !hidden(node));
      const hiddenMatches = Math.max(0, rawMatchCount - visibleNodes.length);
      const semanticBoundary = semanticSelector(current.selector) || visibleNodes.some(nodeHasSemanticBoundary);
      const uniqueMatch = current.mode === 'region' && visibleNodes.length === 1;
      const repeatedEntries = current.mode === 'cards' ? cards.length : 0;
      const linkedEntries = cards.filter(row => row.url).length;
      const titledEntries = cards.filter(row => row.title).length;
      const lengths = cards.map(row => tidy(row.summary || row.title, 1200).length).filter(Boolean);
      const middle = median(lengths);
      const consistentEntries = middle ? lengths.filter(length => length >= Math.max(12, middle * 0.35) && length <= middle * 2.8).length : 0;
      const textCharacters = Math.min(120000, current.mode === 'cards'
        ? cards.reduce((total, row) => total + tidy(row.summary || row.title, 1200).length, 0)
        : tidy(content, 120000).length);
      const clutterElements = clutterCount(visibleNodes);
      const stableNames = stableNameCount(visibleNodes);
      const volatileSelector = selectorLooksVolatile(current.selector);
      const selectorKind = semanticBoundary ? 'semantic' : (/[#[]/.test(current.selector) || stableNames ? 'named' : 'generic');
      const reasons = [];
      const warnings = [];
      let rank = 42;

      if (id === 'saved') { reasons.push('This is the section already saved for this watched page.'); rank += 5; }
      if (semanticBoundary) { reasons.push('The match uses a semantic main, article, role, or item boundary.'); rank += 20; }
      else if (selectorKind === 'named') { reasons.push('The match has a named attribute or stable element identity.'); rank += 10; }
      else { warnings.push('The selector depends mostly on generic page structure or class names.'); rank -= 8; }

      if (volatileSelector) { warnings.push('The selector contains a generated-looking class or identifier that may change after deployment.'); rank -= 24; }
      if (hiddenMatches) { warnings.push(`${hiddenMatches} hidden match${hiddenMatches === 1 ? ' was' : 'es were'} excluded.`); rank -= Math.min(15, hiddenMatches * 4); }
      if (clutterElements) { warnings.push('The selected area contains navigation, forms, sidebars, or footer-like structure.'); rank -= Math.min(24, 8 + clutterElements * 3); }
      else if (visibleNodes.length) { reasons.push('No navigation, form, sidebar, or footer landmark was found inside the match.'); rank += 6; }

      if (current.mode === 'region') {
        if (uniqueMatch) { reasons.push('The selector matches one visible region.'); rank += 15; }
        else if (!visibleNodes.length) { warnings.push('No visible region matched this selector.'); rank = 0; }
        else { warnings.push(`The selector matches ${visibleNodes.length} visible regions; only the first would be watched.`); rank -= 18; }
        if (textCharacters < 80 && visibleNodes.length) { warnings.push('The matched region has very little readable text right now.'); rank -= 18; }
        else if (textCharacters >= 80) rank += 6;
        if (textCharacters > 60000) { warnings.push('The region is very broad and may include unrelated page changes.'); rank -= 8; }
      } else {
        if (repeatedEntries >= 3 && repeatedEntries <= 80) { reasons.push(`${repeatedEntries} visible entries form a bounded repeated set.`); rank += 13; }
        else if (repeatedEntries === 2) { reasons.push('Two visible entries form a small repeated set.'); rank += 4; }
        else if (!repeatedEntries) { warnings.push('No readable repeated entry matched this selector.'); rank = 0; }
        else if (repeatedEntries > 80) { warnings.push('The repeated set is broad and may include unrelated list items.'); rank -= 8; }
        if (repeatedEntries) {
          const linkRatio = linkedEntries / repeatedEntries;
          const titleRatio = titledEntries / repeatedEntries;
          const consistencyRatio = consistentEntries / Math.max(1, lengths.length);
          if (linkRatio >= 0.7) { reasons.push('Most entries have their own destination link.'); rank += 10; }
          else if (linkRatio < 0.35) { warnings.push('Few entries have a stable destination link, so identity may depend on wording.'); rank -= 12; }
          if (titleRatio >= 0.7) { reasons.push('Most entries expose a heading or title.'); rank += 8; }
          else if (titleRatio < 0.35) { warnings.push('Few entries expose a clear heading.'); rank -= 10; }
          if (consistencyRatio >= 0.7) { reasons.push('Most entry text lengths are structurally similar.'); rank += 10; }
          else if (lengths.length >= 3) { warnings.push('Entry shapes vary widely, which may indicate a mixed list.'); rank -= 12; }
        }
      }

      rank = clamp(Math.round(rank), 0, 100);
      const level = rank >= 72 ? 'steadier' : rank >= 45 ? 'watchful' : 'fragile';
      const summary = level === 'steadier'
        ? 'More likely to stay put, based on the structure visible now.'
        : level === 'watchful'
          ? 'Usable, but one or more page details may shift.'
          : 'Fragile: weak or noisy structure may require repair.';
      return {
        rank,
        assessment: {
          schema: ASSESSMENT_SCHEMA,
          level,
          summary,
          reasons: reasons.slice(0, 4).map(value => tidy(value, 180)),
          warnings: warnings.slice(0, 4).map(value => tidy(value, 180)),
          signals: {
            selectorKind,
            semanticBoundary,
            uniqueMatch,
            visibleMatches: Math.min(100000, visibleNodes.length),
            hiddenMatches: Math.min(100000, hiddenMatches),
            repeatedEntries: Math.min(200, repeatedEntries),
            linkedEntries: Math.min(200, linkedEntries),
            titledEntries: Math.min(200, titledEntries),
            consistentEntries: Math.min(200, consistentEntries),
            clutterElements,
            textCharacters,
          },
        },
      };
    };
    const capture = (id, raw) => {
      const current = recipe(raw);
      const rawNodes = current.selector ? safeAllRaw(current.selector) : [];
      const nodes = current.selector ? rawNodes.filter(node => !hidden(node)) : [];
      if (current.mode === 'cards') {
        const selected = nodes.slice(0, 200);
        const cards = selected.map((node, index) => {
          const titleNode = current.titleSelector ? (() => { try { return node.querySelector(current.titleSelector); } catch { return null; } })() : node.querySelector('h1,h2,h3,h4,h5,h6,[role="heading"]');
          const linkNode = current.linkSelector ? (() => { try { return node.querySelector(current.linkSelector); } catch { return null; } })() : node.querySelector('a[href]');
          const title = tidy(titleNode?.innerText || titleNode?.textContent || node.innerText || node.textContent, 300);
          const url = absolute(linkNode?.href || linkNode?.getAttribute?.('href') || '');
          const summary = tidy(node.innerText || node.textContent, 1200);
          return {key: tidy(url || `${title}\u0000${summary.slice(0, 300)}\u0000${index}`, 600), title, url, summary};
        }).filter(row => row.title || row.summary || row.url);
        const evaluated = assess({id, current, nodes: selected, cards, content: '', rawMatchCount: rawNodes.length});
        return {
          recipe: current,
          capture: {mode: 'cards', matchCount: selected.length, content: '', cards},
          examples: {matched: cards.slice(0, 3).map(row => tidy(`${row.title}${row.summary && row.summary !== row.title ? ` — ${row.summary}` : ''}`, 500)).filter(Boolean), ignored: ignoredExample(selected)},
          assessment: evaluated.assessment,
          rank: evaluated.rank,
        };
      }
      let selected = nodes;
      let rawCount = rawNodes.length;
      if (!selected.length && !current.selector) {
        selected = [safeAll('main')[0] || safeAll('[role="main"]')[0] || safeAll('article')[0] || document.body].filter(node => node && !hidden(node));
        rawCount = selected.length;
      }
      const first = selected[0] || null;
      const content = tidy(first?.innerText || first?.textContent, 120000);
      const evaluated = assess({id, current, nodes: selected, cards: [], content, rawMatchCount: rawCount});
      return {
        recipe: current,
        capture: {mode: 'region', matchCount: selected.length, content, cards: []},
        examples: {matched: content ? [content.slice(0, 500)] : [], ignored: ignoredExample(first)},
        assessment: evaluated.assessment,
        rank: evaluated.rank,
      };
    };
    const proposal = (id, label, description, raw) => ({id, label, description, ...capture(id, raw)});
    const candidates = [];
    const seen = new Set();
    const add = row => {
      const key = JSON.stringify(row.recipe);
      if (seen.has(key) || candidates.length >= 3) return false;
      seen.add(key);
      const {rank, ...portable} = row;
      candidates.push(portable);
      return true;
    };

    add(proposal('saved', 'Saved watched section', 'Use the declarative section already stored for this watched page.', incomingRecipe || {}));

    const repeatedProbes = [
      ['main article', 'semantic articles in the main region'],
      ['[role="main"] article', 'semantic articles in the main landmark'],
      ['main [role="article"]', 'article landmarks in the main region'],
      ['article', 'article elements'],
      ['[role="article"]', 'article landmarks'],
      ['main .h-entry', 'microformat entries in the main region'],
      ['.h-entry', 'microformat entries'],
      ['main [itemprop="itemListElement"]', 'structured list entries'],
      ['[itemprop="itemListElement"]', 'structured list entries'],
      ['main .post', 'post-like entries in the main region'],
      ['main .entry', 'entry-like records in the main region'],
      ['main .news-item', 'news-like records in the main region'],
      ['main li', 'list items in the main region'],
    ];
    const repeated = [];
    for (const [selector, basis] of repeatedProbes) {
      const count = safeAll(selector).length;
      if (count < 2 || count > 200) continue;
      const row = proposal('repeated', 'Repeated entries on this page', `Use ${count} visible records found through ${basis}.`, {
        mode: 'cards', selector, titleSelector: 'h1,h2,h3,h4,h5,h6,[role="heading"]', linkSelector: 'a[href]',
        threshold: incomingRecipe?.threshold || 1, ignoreNumbers: Boolean(incomingRecipe?.ignoreNumbers),
      });
      const signature = row.capture.cards.slice(0, 8).map(card => `${card.url}\u0000${card.title}\u0000${card.summary.slice(0, 80)}`).join('\u0001');
      if (signature && !repeated.some(existing => existing.signature === signature)) repeated.push({...row, signature});
    }
    repeated.sort((a, b) => b.rank - a.rank || b.capture.matchCount - a.capture.matchCount || a.recipe.selector.localeCompare(b.recipe.selector));
    if (repeated[0]) {
      const {signature, ...row} = repeated[0];
      add(row);
    }

    const regionProbes = [
      ['main', 'the main element'],
      ['[role="main"]', 'the main landmark'],
      ['[itemprop="articleBody"]', 'structured article text'],
      ['article', 'the first article element'],
      ['', 'the primary readable page region'],
    ];
    const regions = regionProbes.map(([selector, basis]) => proposal('main', 'Primary readable text', `Use ${basis}.`, {
      mode: 'region', selector, threshold: incomingRecipe?.threshold || 1, ignoreNumbers: Boolean(incomingRecipe?.ignoreNumbers),
    })).sort((a, b) => b.rank - a.rank || a.recipe.selector.localeCompare(b.recipe.selector));
    for (const row of regions) {
      if (add(row)) break;
    }

    if (candidates.length < 3) {
      for (const candidate of repeated.slice(1)) {
        const {signature, ...row} = candidate;
        row.id = `repeated-${candidates.length + 1}`;
        row.label = 'Another repeated section';
        if (add(row)) break;
      }
    }

    return {
      schema: 'progrss.browser-capture-candidates.v3',
      capturedAt: new Date().toISOString(),
      page: {
        url: (() => { const url = new URL(location.href); url.hash = ''; return url.href; })(),
        title: tidy(document.title || location.hostname, 300),
        language: tidy(document.documentElement.lang, 35),
        direction: tidy(document.documentElement.dir || getComputedStyle(document.documentElement).direction, 10),
      },
      source: {id: reviewedSourceId, url: reviewedUrl},
      context,
      candidates: candidates.slice(0, 3),
      provenance: {
        kind: 'rendered-browser-dom', topFrameOnly: true, isolatedWorld: true,
        arbitrarySharedCode: false, extensionVersion: version, extractorRevision: 'perimeter-v1',
      },
    };
  }

  root.ProgRSSCapture = Object.freeze({extract});
})(globalThis);
