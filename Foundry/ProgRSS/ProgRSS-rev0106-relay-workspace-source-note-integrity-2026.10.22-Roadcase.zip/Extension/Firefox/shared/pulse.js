/* ProgRSS rev0007 / Pulse Planner. Pure, declarative, no network and no timers.
 * Values on Lens.pulse are LOCAL diagnostics and never enter public recipes.
 */
(function(root){
'use strict';
const MIN_MS=15*60_000, BASE_MS=30*60_000, MAX_MS=7*24*60*60_000, HOST_GAP_MS=45_000;
const EVENT_TYPES=new Set(['changed','quiet','error','throttled']);
const integer=(v,fallback=0)=>Number.isSafeInteger(v)&&v>=0?v:fallback;
function retryHint(value,now){
  if(typeof value!=='string'||value.length>95)return null;
  const raw=value.trim();let delay=null;
  if(/^\d{1,12}$/.test(raw))delay=Number(raw)*1000;
  else if(/^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun), \d{2} (?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec) \d{4} \d{2}:\d{2}:\d{2} GMT$/.test(raw)){
    const dt=Date.parse(raw);if(Number.isFinite(dt))delay=Math.max(0,dt-now);
  }
  return delay===null||!Number.isFinite(delay)?null:{delayMs:Math.min(delay,MAX_MS),needsReview:delay>MAX_MS,raw};
}
function freshnessHint(header){
  if(typeof header!=='string'||header.length>1024)return 0;
  if(/(?:^|,)\s*(?:no-cache|no-store)\b/i.test(header))return 0;
  const found=[...header.matchAll(/(?:^|,)\s*max-age\s*=\s*(\d{1,12})\s*(?:,|$)/ig)];
  if(!found.length)return 0;
  return Math.min(MAX_MS,Math.max(...found.map(m=>Number(m[1])*1000)));
}
function originKey(url){try{const u=new URL(url);return /^https?:$/.test(u.protocol)?u.origin:''}catch{return ''}}
function advance(prior={},outcome='quiet',now=Date.now(),response={}){
  if(!EVENT_TYPES.has(outcome))throw Error('Pulse: invalid outcome');
  if(!Number.isFinite(now)||now<0)throw Error('Pulse: invalid timestamp');
  const was=prior&&typeof prior==='object'?prior:{};
  const quiet=outcome==='quiet'?Math.min(10,integer(was.quietStreak)+1):0;
  const failures=['error','throttled'].includes(outcome)?Math.min(10,integer(was.failureStreak)+1):0;
  const cadence=outcome==='changed'?BASE_MS:outcome==='quiet'?Math.min(MAX_MS,BASE_MS*2**quiet):Math.min(MAX_MS,BASE_MS*2**failures);
  const freshness=outcome==='changed'||outcome==='quiet'?freshnessHint(response.cacheControl):0;
  const retry=['throttled','error'].includes(outcome)?retryHint(response.retryAfter||'',now):null;
  let intervalMs=Math.max(MIN_MS,cadence,freshness,retry?.delayMs||0);
  intervalMs=Math.min(MAX_MS,intervalMs);
  const needsReview=Boolean(retry?.needsReview);
  let reason=outcome==='changed'?'New observations; return to the normal interval':
    outcome==='quiet'?'Quiet source; spacing checks further':outcome==='throttled'?'Server requested a slower pace':'Error; exponential backoff';
  if(freshness>=cadence)reason+='; respecting Cache-Control freshness';
  if(retry&&retry.delayMs>=cadence)reason+='; respecting Retry-After';
  if(needsReview)reason+='; oversized Retry-After requires manual review';
  return {lastAt:new Date(now).toISOString(),nextAt:new Date(now+intervalMs).toISOString(),
    quietStreak:quiet,failureStreak:failures,intervalMinutes:Math.round(intervalMs/60_000),
    lastOutcome:outcome,lastStatus:integer(response.status),needsReview,reason};
}
function schedule(sources,now=Date.now(),limit=12){
  const all=Array.isArray(sources)?sources:[];
  const recentHosts=new Map(),due=[],later=[],held=[];
  // Keep same-host pacing across page reloads from persisted lastAt timestamps.
  for(const src of all){
    if(!src?.enabled)continue;
    const host=originKey(src.url),recent=Date.parse(src.pulse?.lastAt)||0;
    if(host&&recent>0)recentHosts.set(host,Math.max(recentHosts.get(host)||0,recent));
  }
  const selectedHosts=new Set();
  for(const src of all.filter(s=>s?.enabled).sort((a,b)=>(Date.parse(a.pulse?.nextAt)||0)-(Date.parse(b.pulse?.nextAt)||0)||String(a.id).localeCompare(String(b.id)))){
    const next=Date.parse(src.pulse?.nextAt)||0,host=originKey(src.url);
    if(src.pulse?.needsReview){held.push(src);continue;}
    if(next>now){later.push(src);continue;}
    if((host&&selectedHosts.has(host))||(host&&recentHosts.get(host)>now-HOST_GAP_MS)){
      later.push(src);continue;
    }
    if(due.length>=Math.max(0,Math.min(100,limit))){later.push(src);continue;}
    due.push(src);if(host)selectedHosts.add(host);
  }
  return {due,later,held};
}
function format(pulse,now=Date.now()){
  if(!pulse||!pulse.nextAt)return 'Ready for first check · adaptive plan begins afterward';
  const remaining=Date.parse(pulse.nextAt)-now;
  const wait=remaining>0?Math.ceil(remaining/60_000)+' min':'ready now';
  return (pulse.needsReview?'REVIEW REQUIRED · ':'NEXT '+wait+' · ')+pulse.intervalMinutes+' min cadence · '+pulse.reason;
}
root.ProgRSSPulse=Object.freeze({MIN_MS,BASE_MS,MAX_MS,HOST_GAP_MS,advance,schedule,format,retryHint,freshnessHint,originKey});
})(globalThis);
