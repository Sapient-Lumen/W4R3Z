/* ProgRSS rev0070 · one script-free static home for a folder and its recent updates. */
(function (root) {
'use strict';

const SITE_SCHEMA = 'progrss.publication-site.v1';
const LOCATED_BUNDLE_SCHEMA = 'progrss.bundle.v3';
const DISTRIBUTION_SCHEMA = 'progrss.shared-folder.distribution.v1';
const BUNDLE_MEDIA_TYPE = 'application/vnd.progrss.shared-folder+json';
const EDITION_SCHEMA = 'progrss.folder-edition.v1';
const JSON_FEED_VERSION = 'https://jsonfeed.org/version/1.1';
const FEED_MEDIA_TYPE = 'application/feed+json';
const EDITION_FILE = 'recent-updates.json';
const MAX_BUNDLE_BYTES = 650_000;
const MAX_EDITION_BYTES = 250_000;
const MAX_EDITION_ITEMS = 100;
const MAX_SITE_BYTES = 2_500_000;
const encoder = new TextEncoder();

function text(value, limit = 1000) {
  return String(value == null ? '' : value).replace(/\s+/g, ' ').trim().slice(0, limit);
}

function escapeHtml(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function escapeXml(value) {
  return escapeHtml(value);
}

function byteLength(value) {
  return encoder.encode(String(value == null ? '' : value)).length;
}

function sourceNoteReason(member) {
  if (!member || !Object.prototype.hasOwnProperty.call(member, 'reason')) return '';
  if (typeof member.reason !== 'string') throw new Error('A curator reason must be plain text.');
  const reason = member.reason.replace(/^[ \t\r\n\f\v]+|[ \t\r\n\f\v]+$/g, '');
  if (!reason) return '';
  let count = 0;
  for (const character of reason) {
    const code = character.codePointAt(0);
    if (code >= 0xD800 && code <= 0xDFFF) throw new Error('A curator reason contains an invalid Unicode scalar value.');
    count++;
  }
  if (count > 280) throw new Error('A curator reason may contain at most 280 Unicode code points.');
  return reason;
}

function siteFileName(updateUrl) {
  let parsed;
  try { parsed = new URL(String(updateUrl || '')); }
  catch { throw new Error('Use a complete public http or https address for the hosted ProgRSS JSON file.'); }
  if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password || !parsed.hostname) {
    throw new Error('Use a credential-free public http or https address for the hosted ProgRSS JSON file.');
  }
  if (parsed.search || parsed.hash) {
    throw new Error('A ready-to-host package needs a direct .json address without a query or fragment.');
  }
  let name = '';
  try { name = decodeURIComponent(parsed.pathname.split('/').pop() || ''); }
  catch { throw new Error('The hosted ProgRSS address has an unreadable file name.'); }
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,118}\.json$/i.test(name)) {
    throw new Error('End the hosted ProgRSS address with a simple .json file name, such as latest.json.');
  }
  const reserved = new Set(['index.html', 'subscriptions.opml', EDITION_FILE, 'README.txt']);
  if (reserved.has(name)) throw new Error('Choose a different .json file name for the hosted ProgRSS copy.');
  return name;
}

function normalizeBundle(raw) {
  if (typeof raw !== 'string' || !raw.trim()) throw new Error('The shared-folder contents are empty.');
  if (byteLength(raw) > MAX_BUNDLE_BYTES) throw new Error('The shared folder is larger than the 650 KB safety limit.');
  let document;
  try { document = JSON.parse(raw); }
  catch { throw new Error('The shared-folder contents are not readable JSON.'); }
  if (!document || document.schema !== LOCATED_BUNDLE_SCHEMA) {
    throw new Error('A ready-to-host website needs a shared folder with a future-copy address.');
  }
  if (!document.distribution || document.distribution.schema !== DISTRIBUTION_SCHEMA) {
    throw new Error('The shared folder is missing its future-copy address.');
  }
  if (!Array.isArray(document.sources) || !Array.isArray(document.collections) || !document.root) {
    throw new Error('The shared folder is missing its portable source or folder list.');
  }
  const updateFile = siteFileName(document.distribution.updateUrl);
  const roots = new Set(document.collections.map(row => String(row?.id || '')));
  if (!roots.has(String(document.root))) throw new Error('The shared folder has no included top-level folder.');
  return {document, updateFile};
}

function safeHttpUrl(value) {
  try {
    const parsed = new URL(String(value || ''));
    if (!['http:', 'https:'].includes(parsed.protocol) || parsed.username || parsed.password || !parsed.hostname) return '';
    parsed.hash = '';
    return parsed.href;
  } catch {
    return '';
  }
}

function languageTag(value) {
  const raw = String(value == null ? '' : value).trim();
  return raw && raw.length <= 100 && !/[\u0000-\u0020\u007f]/.test(raw) && /^[A-Za-z]{1,8}(?:-[A-Za-z0-9]{1,8})*$/.test(raw)
    ? raw.toLowerCase()
    : '';
}

function boundedInteger(value, minimum, maximum, fallback = 0) {
  const number = Number(value);
  return Number.isInteger(number) && number >= minimum && number <= maximum ? number : fallback;
}

function strictInteger(value, minimum, maximum, label) {
  const number = Number(value);
  if (!Number.isInteger(number) || number < minimum || number > maximum) {
    throw new Error(`${label} is outside its supported bounds.`);
  }
  return number;
}

function hasOnlyKeys(value, allowed) {
  return value && typeof value === 'object' && !Array.isArray(value)
    && Object.keys(value).every(key => allowed.has(key));
}

function normalizeEdition(raw, bundleDocument) {
  if (!raw) return null;
  if (typeof raw !== 'string' || !raw.trim()) throw new Error('The recent-updates feed is empty.');
  if (byteLength(raw) > MAX_EDITION_BYTES) throw new Error('The recent-updates feed is larger than the 250 KB safety limit.');
  let source;
  try { source = JSON.parse(raw); }
  catch { throw new Error('The recent-updates feed is not readable JSON.'); }
  if (!source || typeof source !== 'object' || Array.isArray(source) || source.version !== JSON_FEED_VERSION) {
    throw new Error('The recent-updates file is not a supported JSON Feed 1.1 document.');
  }
  const allowedTop = new Set(['version', 'title', 'description', 'user_comment', 'home_page_url', 'feed_url', 'authors', 'language', 'items', '_progrss']);
  if (Object.keys(source).some(key => !allowedTop.has(key))) {
    throw new Error('The recent-updates feed contains material ProgRSS did not prepare for a public folder edition.');
  }
  const metadata = source._progrss;
  const allowedMetadata = new Set(['schema', 'generatedAt', 'folder', 'folderSourceCount', 'representedSourceCount', 'itemCount', 'omittedByLimit', 'included', 'excluded']);
  if (!hasOnlyKeys(metadata, allowedMetadata) || metadata.schema !== EDITION_SCHEMA) {
    throw new Error('The recent-updates feed is missing or extends its bounded ProgRSS folder-edition marker.');
  }
  const folder = text(metadata.folder, 180);
  const bundleTitle = text(bundleDocument?.title, 180);
  if (!folder || folder !== bundleTitle) {
    throw new Error('The recent-updates feed belongs to a different folder.');
  }
  if (!Array.isArray(source.items) || source.items.length > MAX_EDITION_ITEMS) {
    throw new Error('The recent-updates feed may contain at most 100 items.');
  }
  const generatedAt = text(metadata.generatedAt, 60);
  if (!generatedAt || !Number.isFinite(Date.parse(generatedAt))) {
    throw new Error('The recent-updates feed has no valid generation time.');
  }
  const included = metadata.included;
  const excluded = metadata.excluded;
  const requiredIncluded = ['titles', 'shortSummaries', 'links', 'dates', 'languages', 'sourceLabels'];
  const requiredExclusions = ['fullRetainedText', 'readingState', 'savedState', 'pageWatchEvidence', 'snapshots', 'browserAuthority', 'privateKeys'];
  if (!hasOnlyKeys(included, new Set(requiredIncluded)) || requiredIncluded.some(key => included[key] !== true)) {
    throw new Error('The recent-updates feed does not confirm its bounded public fields.');
  }
  if (!hasOnlyKeys(excluded, new Set(requiredExclusions)) || requiredExclusions.some(key => excluded[key] !== true)) {
    throw new Error('The recent-updates feed does not confirm the required private-data exclusions.');
  }
  const folderSourceCount = strictInteger(metadata.folderSourceCount, 0, 200, 'The folder source count');
  const representedSourceCount = strictInteger(metadata.representedSourceCount, 0, 200, 'The represented source count');
  const itemCount = strictInteger(metadata.itemCount, 0, MAX_EDITION_ITEMS, 'The recent-update item count');
  const omittedByLimit = strictInteger(metadata.omittedByLimit, 0, 100000, 'The omitted-item count');
  if (itemCount !== source.items.length || representedSourceCount > folderSourceCount) {
    throw new Error('The recent-updates feed has inconsistent public counts.');
  }
  const curator = text(bundleDocument?.publication?.curator, 80);
  let authors;
  if (source.authors != null) {
    if (!Array.isArray(source.authors) || source.authors.length !== 1 || !hasOnlyKeys(source.authors[0], new Set(['name']))) {
      throw new Error('The recent-updates feed has an invalid curator label.');
    }
    const authorName = text(source.authors[0].name, 80);
    if (!authorName || authorName !== curator) {
      throw new Error('The recent-updates feed attribution does not match the shared folder.');
    }
    authors = [{name: authorName}];
  } else if (curator) {
    throw new Error('The recent-updates feed attribution does not match the shared folder.');
  }
  const allowedItem = new Set(['id', 'title', 'content_text', 'summary', 'url', 'date_published', 'language', '_progrss']);
  const changeKinds = new Set(['entry-added', 'entry-changed', 'entry-removed', 'text-changed']);
  const items = source.items.map((item, index) => {
    if (!item || typeof item !== 'object' || Array.isArray(item) || Object.keys(item).some(key => !allowedItem.has(key))) {
      throw new Error(`Recent update ${index + 1} contains unsupported material.`);
    }
    let id = text(item.id, 2048);
    const title = text(item.title, 240) || 'Untitled update';
    const content = text(item.content_text, 800);
    const summary = text(item.summary, 800);
    if (!id || !content) throw new Error(`Recent update ${index + 1} is missing its public identifier or summary text.`);
    if (!/^urn:progrss:edition:[0-9a-f]{16}$/.test(id) && !id.startsWith('http://') && !id.startsWith('https://')) {
      throw new Error(`Recent update ${index + 1} has an unsupported public identifier.`);
    }
    if (id.startsWith('http://') || id.startsWith('https://')) {
      const normalizedId = safeHttpUrl(id);
      if (!normalizedId) throw new Error(`Recent update ${index + 1} has an unsafe public identifier.`);
      id = normalizedId;
    }
    const extension = item._progrss;
    if (!extension || typeof extension !== 'object' || Array.isArray(extension)) {
      throw new Error(`Recent update ${index + 1} is missing its bounded source evidence.`);
    }
    const allowedExtension = new Set(['sourceCount', 'sources', 'changeKind']);
    if (Object.keys(extension).some(key => !allowedExtension.has(key))) {
      throw new Error(`Recent update ${index + 1} contains unsupported source evidence.`);
    }
    if (!Array.isArray(extension.sources) || extension.sources.length > 8) {
      throw new Error(`Recent update ${index + 1} names too many source witnesses.`);
    }
    const sources = extension.sources.map(source => {
      if (!hasOnlyKeys(source, new Set(['title', 'type'])) || !['feed', 'page'].includes(source.type)) {
        throw new Error(`Recent update ${index + 1} has malformed source evidence.`);
      }
      const sourceTitle = text(source.title, 130) || 'Untitled source';
      return {title: sourceTitle, type: source.type};
    });
    const sourceCount = strictInteger(extension.sourceCount, 1, 200, `Recent update ${index + 1} source count`);
    if (sourceCount < sources.length) throw new Error(`Recent update ${index + 1} has inconsistent source evidence.`);
    const changeKind = text(extension.changeKind, 40);
    if (changeKind && !changeKinds.has(changeKind)) throw new Error(`Recent update ${index + 1} has an unsupported page-change kind.`);
    const out = {
      id,
      title,
      content_text: content,
      _progrss: {sourceCount, sources, ...(changeKind ? {changeKind} : {})}
    };
    if (summary) out.summary = summary;
    const url = safeHttpUrl(item.url);
    if (item.url && !url) throw new Error(`Recent update ${index + 1} has an unsafe public address.`);
    if (url) out.url = url;
    const published = text(item.date_published, 60);
    if (published) {
      if (!Number.isFinite(Date.parse(published))) throw new Error(`Recent update ${index + 1} has an invalid publication time.`);
      out.date_published = new Date(published).toISOString();
    }
    const language = languageTag(item.language);
    if (item.language && !language) throw new Error(`Recent update ${index + 1} has an invalid language tag.`);
    if (language) out.language = language;
    return out;
  });
  const updateUrl = String(bundleDocument?.distribution?.updateUrl || '');
  const feedUrl = new URL(EDITION_FILE, updateUrl).href;
  const homePageUrl = new URL('index.html', updateUrl).href;
  const document = {
    version: JSON_FEED_VERSION,
    title: text(source.title, 240) || `${folder} · recent updates`,
    description: text(source.description, 280) || `Recent updates selected from ${folder}.`,
    user_comment: text(source.user_comment, 500) || 'Prepared manually from a local ProgRSS folder.',
    home_page_url: homePageUrl,
    feed_url: feedUrl,
    ...(authors ? {authors} : {}),
    ...(() => {
      if (!source.language) return {};
      const language = languageTag(source.language);
      if (!language) throw new Error('The recent-updates feed has an invalid top-level language tag.');
      return {language};
    })(),
    items,
    _progrss: {
      schema: EDITION_SCHEMA,
      generatedAt: new Date(generatedAt).toISOString(),
      folder,
      folderSourceCount,
      representedSourceCount,
      itemCount,
      omittedByLimit,
      included: {
        titles: true,
        shortSummaries: true,
        links: true,
        dates: true,
        languages: true,
        sourceLabels: true
      },
      excluded: Object.fromEntries(requiredExclusions.map(key => [key, true]))
    }
  };
  const normalizedRaw = `${JSON.stringify(document, null, 2)}\n`;
  if (byteLength(normalizedRaw) > MAX_EDITION_BYTES) throw new Error('The normalized recent-updates feed is larger than the 250 KB safety limit.');
  return {document, raw: normalizedRaw, feedUrl, homePageUrl};
}

function sourceKind(source) {
  if (source?.type === 'rss' || source?.kind === 'feed') return 'feed';
  if (source?.type === 'page' || source?.kind === 'page') return 'page';
  return 'source';
}

function sourceHost(source) {
  try { return new URL(String(source?.url || '')).host; }
  catch { return ''; }
}

function renderSourceTree(document) {
  const sources = new Map((document.sources || []).map(row => [String(row?.id || ''), row]));
  const collections = new Map((document.collections || []).map(row => [String(row?.id || ''), row]));
  function renderCollection(id, stack = []) {
    if (!collections.has(id) || stack.includes(id) || stack.length >= 24) return '';
    const collection = collections.get(id);
    const items = [];
    for (const member of Array.isArray(collection.members) ? collection.members : []) {
      const memberId = String(member?.id || '');
      if (member?.kind === 'source' && sources.has(memberId)) {
        const source = sources.get(memberId);
        const kind = sourceKind(source);
        const label = kind === 'feed' ? 'Feed' : kind === 'page' ? 'Watched page' : 'Source';
        const title = text(source?.title, 130) || 'Untitled source';
        const url = String(source?.url || '');
        const host = sourceHost(source);
        const reason = sourceNoteReason(member);
        const reasonNode = reason
          ? `<p class="source-note"><strong>Curator’s reason for this folder:</strong> <span dir="auto">${escapeHtml(reason)}</span></p>`
          : '';
        items.push(`<li class="source"><span class="kind">${label}</span><a href="${escapeHtml(url)}" rel="noreferrer">${escapeHtml(title)}</a>${host ? `<span class="host">${escapeHtml(host)}</span>` : ''}${reasonNode}</li>`);
      } else if (member?.kind === 'collection' && collections.has(memberId)) {
        const child = collections.get(memberId);
        const nested = renderCollection(memberId, [...stack, id]);
        if (nested) items.push(`<li class="folder"><strong>${escapeHtml(text(child?.title, 130) || 'Untitled folder')}</strong>${nested}</li>`);
      }
    }
    return `<ul>${items.join('')}</ul>`;
  }
  return renderCollection(String(document.root));
}

function renderOpml(document) {
  const sources = new Map((document.sources || []).map(row => [String(row?.id || ''), row]));
  const collections = new Map((document.collections || []).map(row => [String(row?.id || ''), row]));
  function renderCollection(id, stack = []) {
    if (!collections.has(id) || stack.includes(id) || stack.length >= 24) return '';
    const collection = collections.get(id);
    const children = [];
    for (const member of Array.isArray(collection.members) ? collection.members : []) {
      const memberId = String(member?.id || '');
      if (member?.kind === 'source' && sources.has(memberId)) {
        const source = sources.get(memberId);
        if (sourceKind(source) === 'feed') {
          children.push(`<outline type="rss" text="${escapeXml(text(source?.title, 130) || 'Untitled feed')}" xmlUrl="${escapeXml(String(source?.url || ''))}"/>`);
        }
      } else if (member?.kind === 'collection' && collections.has(memberId)) {
        children.push(renderCollection(memberId, [...stack, id]));
      }
    }
    return `<outline text="${escapeXml(text(collection?.title, 130) || 'Untitled folder')}">${children.join('')}</outline>`;
  }
  const curator = text(document?.publication?.curator, 80);
  const owner = curator ? `<ownerName>${escapeXml(curator)}</ownerName>` : '';
  const created = Number.isFinite(Date.parse(document.exportedAt)) ? new Date(document.exportedAt).toUTCString() : new Date(0).toUTCString();
  return `<?xml version="1.0" encoding="UTF-8"?>\n<opml version="2.0"><head><title>${escapeXml(text(document.title, 180) || 'ProgRSS shared folder')}</title><dateCreated>${escapeXml(created)}</dateCreated>${owner}</head><body>${renderCollection(String(document.root))}</body></opml>\n`;
}

function publicationCounts(document) {
  let feeds = 0;
  let pageWatches = 0;
  let sourceNotes = 0;
  for (const source of document.sources || []) {
    if (sourceKind(source) === 'feed') feeds++;
    else if (sourceKind(source) === 'page') pageWatches++;
  }
  for (const collection of document.collections || []) {
    for (const member of Array.isArray(collection?.members) ? collection.members : []) {
      if (member?.kind === 'source' && sourceNoteReason(member)) sourceNotes++;
      else if (member?.kind !== 'source' && Object.prototype.hasOwnProperty.call(member || {}, 'reason')) {
        throw new Error('Only a direct source placement may carry a curator reason.');
      }
    }
  }
  return {feeds, pageWatches, folders: (document.collections || []).length, sourceNotes};
}

function renderRecentUpdates(edition) {
  if (!edition?.document?.items?.length) return '';
  const labels = {
    'entry-added': 'New entry',
    'entry-changed': 'Changed entry',
    'entry-removed': 'Removed entry',
    'text-changed': 'Page text changed'
  };
  const items = edition.document.items.slice(0, 10).map(item => {
    const language = languageTag(item.language);
    const languageAttribute = language ? ` lang="${escapeHtml(language)}"` : '';
    const title = escapeHtml(text(item.title, 240) || 'Untitled update');
    const titleNode = item.url
      ? `<a href="${escapeHtml(item.url)}" rel="noreferrer"${languageAttribute} dir="auto">${title}</a>`
      : `<span${languageAttribute} dir="auto">${title}</span>`;
    const summary = text(item.summary || item.content_text, 800);
    const sources = Array.isArray(item?._progrss?.sources)
      ? item._progrss.sources.map(source => text(source?.title, 130)).filter(Boolean).slice(0, 8)
      : [];
    const date = item.date_published && Number.isFinite(Date.parse(item.date_published))
      ? new Date(item.date_published).toLocaleDateString('en', {year: 'numeric', month: 'short', day: 'numeric', timeZone: 'UTC'})
      : '';
    const kind = labels[text(item?._progrss?.changeKind, 40)] || '';
    const metadata = [date, ...sources, kind].filter(Boolean).map(escapeHtml).join(' · ');
    return `<li class="update"><h3>${titleNode}</h3>${summary ? `<p${languageAttribute} dir="auto">${escapeHtml(summary)}</p>` : ''}${metadata ? `<p class="fine">${metadata}</p>` : ''}</li>`;
  });
  const remaining = Math.max(0, edition.document.items.length - items.length);
  return `<ol class="updates">${items.join('')}</ol>${remaining ? `<p class="fine">The feed contains ${remaining} more recent update${remaining === 1 ? '' : 's'}.</p>` : ''}`;
}

function renderIndex(document, updateFile, includeOpml, edition = null) {
  const counts = publicationCounts(document);
  const title = text(document.title, 180) || 'Shared sources';
  const curator = text(document?.publication?.curator, 80);
  const note = text(document?.publication?.note, 280);
  const issue = Number.isFinite(Date.parse(document.exportedAt)) ? new Date(document.exportedAt).toLocaleDateString('en', {year: 'numeric', month: 'long', day: 'numeric', timeZone: 'UTC'}) : '';
  const signed = Boolean(document?.integrity?.signature);
  const tree = renderSourceTree(document);
  const editionCount = edition?.document?.items?.length || 0;
  const sourceNoteFact = counts.sourceNotes
    ? `<span class="fact">${counts.sourceNotes} curator reason${counts.sourceNotes === 1 ? '' : 's'}</span>`
    : '';
  const sourceNoteExplainer = counts.sourceNotes
    ? '<p class="fine source-note-explainer">Curator reasons explain why a source appears in a particular folder. They are written by the person who prepared this source list and are not a ProgRSS safety claim.</p>'
    : '';
  const editionLink = edition
    ? `\n<link rel="alternate" type="${FEED_MEDIA_TYPE}" href="${EDITION_FILE}" title="${escapeHtml(title)} recent updates">`
    : '';
  const editionAction = edition
    ? `<a class="action" href="${EDITION_FILE}" download>Get recent updates feed</a>`
    : '';
  const recentUpdates = renderRecentUpdates(edition);
  const editionGetSection = edition
    ? `<section aria-labelledby="get-updates-heading"><h2 id="get-updates-heading">Follow recent updates</h2><div class="actions">${editionAction}</div><p class="fine">This is one summary feed. Following it does not add the source list’s underlying feeds, watched pages, or folders.</p></section>`
    : '';
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'; object-src 'none'; frame-src 'none'; img-src 'none'">
<link rel="alternate" type="${BUNDLE_MEDIA_TYPE}" href="${escapeHtml(updateFile)}" title="${escapeHtml(title)} source list for ProgRSS">${editionLink}
<title>${escapeHtml(title)} · shared sources</title>
<style>
:root{color-scheme:light dark;font:18px/1.55 system-ui,sans-serif}body{max-width:48rem;margin:auto;padding:clamp(1rem,4vw,3rem)}main{display:grid;gap:1.4rem}h1,h2,h3{line-height:1.15}p{max-width:68ch}.lede{font-size:1.1rem}.facts{display:flex;flex-wrap:wrap;gap:.65rem}.fact,.kind{border:1px solid currentColor;border-radius:999px;padding:.18rem .65rem}.actions{display:flex;flex-wrap:wrap;gap:.75rem}.action{display:inline-block;border:2px solid currentColor;border-radius:.6rem;padding:.75rem 1rem;font-weight:700}.secondary{font-weight:600}ul{padding-left:1.35rem}li{margin:.55rem 0}.source{display:grid;grid-template-columns:max-content minmax(0,1fr);gap:.2rem .65rem;align-items:start}.source .host{grid-column:2;opacity:.72;font-size:.9rem;overflow-wrap:anywhere}.source-note{grid-column:2;margin:.15rem 0 0;white-space:pre-wrap;overflow-wrap:anywhere}.source-note strong{font-weight:700}.source-note-explainer{margin-top:.35rem}.folder>strong{display:block;margin-top:1rem}.updates{display:grid;gap:1rem;padding:0;list-style:none}.update{border-top:1px solid currentColor;padding-top:1rem}.update:first-child{border-top:0;padding-top:0}.update h3{margin:.1rem 0 .35rem;font-size:1.05rem}.update p{margin:.35rem 0}.note{border-left:.3rem solid currentColor;padding-left:1rem}.fine{font-size:.9rem;opacity:.78}a{color:inherit;text-underline-offset:.18em}a:focus-visible{outline:.2rem solid currentColor;outline-offset:.2rem}@media(max-width:32rem){.actions{display:grid}.action{text-align:center}.source{grid-template-columns:1fr}.source .host,.source-note{grid-column:1}}
</style>
</head>
<body>
<main>
<header>
<p class="fine">ProgRSS source list${curator ? ` · ${escapeHtml(curator)}` : ''}</p>
<h1>${escapeHtml(title)}</h1>
${note ? `<p class="lede note">${escapeHtml(note)}</p>` : '<p class="lede">A portable collection of feeds and watched webpages.</p>'}
<div class="facts"><span class="fact">${counts.feeds} feed${counts.feeds === 1 ? '' : 's'}</span><span class="fact">${counts.pageWatches} watched page${counts.pageWatches === 1 ? '' : 's'}</span><span class="fact">${counts.folders} folder${counts.folders === 1 ? '' : 's'}</span>${sourceNoteFact}${edition ? `<span class="fact">${editionCount} recent update${editionCount === 1 ? '' : 's'}</span>` : ''}</div>
</header>
<section aria-labelledby="get-heading">
<h2 id="get-heading">Get the source list</h2>
<div class="actions"><a class="action" href="${escapeHtml(updateFile)}" download>Get source list for ProgRSS</a>${includeOpml ? '<a class="action secondary" href="subscriptions.opml" download>Get feeds for another reader</a>' : ''}</div>
<p class="fine">Already using ProgRSS? Choose Add → Use this page while this page is open, or paste the direct JSON address into Add. ProgRSS will offer the source list for review before adding anything.</p>
<p class="fine">The ProgRSS file preserves feed and page-watch recipes and curator-written folder reasons. OPML carries feeds only and omits those reasons. These files do not include anyone’s reading history, saved items, page snapshots, browser permissions, or private signing key.</p>
</section>
${editionGetSection}
${edition ? `<section aria-labelledby="updates-heading"><h2 id="updates-heading">Recent updates</h2><p class="fine">This is a manual snapshot. It changes only when the curator prepares and uploads a new package.</p>${recentUpdates}</section>` : ''}
<section aria-labelledby="sources-heading">
<h2 id="sources-heading">What it follows</h2>
${sourceNoteExplainer}
${tree || '<p>No public sources were included.</p>'}
</section>
<footer>
<p>${signed ? 'This ProgRSS copy includes a signature that recipients can verify against its included public key. A valid signature does not prove the curator’s real-world identity or that every listed site is safe.' : 'This ProgRSS copy is unsigned. Its content digest detects accidental or malicious changes but does not establish a curator’s identity.'}</p>
<p class="fine">Prepared${issue ? ` ${escapeHtml(issue)}` : ''}. This page has no scripts, trackers, remote images, or automatic update checks. It contacts a listed site only when a visitor chooses one of its links.</p>
</footer>
</main>
</body>
</html>
`;
}

function renderReadme(document, updateFile, includeOpml, edition = null) {
  const counts = publicationCounts(document);
  const editionLine = edition ? `  ${EDITION_FILE}  Summary-only JSON Feed of ${edition.document.items.length} recent update(s).\n` : '';
  const editionNote = edition
    ? `The index page also advertises ${EDITION_FILE} as a standard JSON Feed and\nshows a small readable selection. It is a manual snapshot, not an account or a\nlive publishing service. Prepare and upload a new package when the folder changes.\n\n`
    : '';
  const editionPrivacy = edition ? ' The recent-updates feed also excludes full retained text and page-watch Before/Now evidence.' : '';
  const sourceNoteNote = counts.sourceNotes
    ? `The HTML page and ProgRSS JSON show ${counts.sourceNotes} curator-written folder reason${counts.sourceNotes === 1 ? '' : 's'}. Each reason belongs to one direct folder/source placement and is not a ProgRSS safety claim.\n`
    : '';
  return `ProgRSS ready-to-host source list
=====================================

Upload these files together to the public website named in the source list:

  ${updateFile}       The ProgRSS source list used by manual update checks.
  index.html${' '.repeat(Math.max(1, 15 - 'index.html'.length))}A script-free page for people.
${includeOpml ? `  subscriptions.opml  Feed-only import for other readers.\n` : ''}${editionLine}  README.txt${' '.repeat(Math.max(1, 15 - 'README.txt'.length))}These instructions.

Configured public address:
  ${document.distribution.updateUrl}

The uploaded JSON file must remain at that exact address. Recipients choose when
to check it. ProgRSS does not poll it, apply updates automatically, or create a
notification stream.

The index page advertises the JSON file as a ProgRSS source list. A visitor
can open the page beside ProgRSS and choose Add → Use this page to review the
source list. Discovery does not add anything or schedule a future check.

${editionNote}${edition ? 'The page gives the source list and recent-updates feed separate, named actions.\nFollowing recent updates adds one summary feed; it does not add the underlying\nfeeds, watched pages, or folders.\n\n' : ''}Contents: ${counts.feeds} feed(s), ${counts.pageWatches} page watch(es), ${counts.folders} folder(s), ${counts.sourceNotes} curator reason(s).

${sourceNoteNote}OPML carries feeds and hierarchy only; it omits watched-page recipes, curator reasons, and ProgRSS branch semantics.

The shared files do not contain reading history, saved items, page snapshots,
browser permissions, or private signing keys.${editionPrivacy}\nThe HTML page has no scripts,
trackers, remote images, frames, or embedded media.
`;
}

let crcTable = null;
function crc32(bytes) {
  if (!crcTable) {
    crcTable = new Uint32Array(256);
    for (let index = 0; index < 256; index++) {
      let value = index;
      for (let bit = 0; bit < 8; bit++) value = (value & 1) ? (0xEDB88320 ^ (value >>> 1)) : (value >>> 1);
      crcTable[index] = value >>> 0;
    }
  }
  let crc = 0xFFFFFFFF;
  for (const byte of bytes) crc = crcTable[(crc ^ byte) & 0xFF] ^ (crc >>> 8);
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function dosDateTime(value) {
  let date = new Date(value);
  if (!Number.isFinite(date.getTime())) date = new Date('1980-01-01T00:00:00Z');
  let year = Math.max(1980, Math.min(2107, date.getUTCFullYear()));
  const month = Math.max(1, Math.min(12, date.getUTCMonth() + 1));
  const day = Math.max(1, Math.min(31, date.getUTCDate()));
  const hour = Math.max(0, Math.min(23, date.getUTCHours()));
  const minute = Math.max(0, Math.min(59, date.getUTCMinutes()));
  const second = Math.max(0, Math.min(59, date.getUTCSeconds()));
  return {
    date: (((year - 1980) << 9) | (month << 5) | day) & 0xFFFF,
    time: ((hour << 11) | (minute << 5) | Math.floor(second / 2)) & 0xFFFF
  };
}

function concat(parts) {
  const total = parts.reduce((sum, part) => sum + part.length, 0);
  const result = new Uint8Array(total);
  let offset = 0;
  for (const part of parts) { result.set(part, offset); offset += part.length; }
  return result;
}

function localHeader(nameBytes, data, crc, stamp) {
  const header = new Uint8Array(30);
  const view = new DataView(header.buffer);
  view.setUint32(0, 0x04034B50, true);
  view.setUint16(4, 20, true);
  view.setUint16(6, 0x0800, true);
  view.setUint16(8, 0, true);
  view.setUint16(10, stamp.time, true);
  view.setUint16(12, stamp.date, true);
  view.setUint32(14, crc, true);
  view.setUint32(18, data.length, true);
  view.setUint32(22, data.length, true);
  view.setUint16(26, nameBytes.length, true);
  view.setUint16(28, 0, true);
  return header;
}

function centralHeader(nameBytes, data, crc, stamp, offset) {
  const header = new Uint8Array(46);
  const view = new DataView(header.buffer);
  view.setUint32(0, 0x02014B50, true);
  view.setUint16(4, 0x0314, true);
  view.setUint16(6, 20, true);
  view.setUint16(8, 0x0800, true);
  view.setUint16(10, 0, true);
  view.setUint16(12, stamp.time, true);
  view.setUint16(14, stamp.date, true);
  view.setUint32(16, crc, true);
  view.setUint32(20, data.length, true);
  view.setUint32(24, data.length, true);
  view.setUint16(28, nameBytes.length, true);
  view.setUint16(30, 0, true);
  view.setUint16(32, 0, true);
  view.setUint16(34, 0, true);
  view.setUint16(36, 0, true);
  view.setUint32(38, (0o100644 << 16) >>> 0, true);
  view.setUint32(42, offset, true);
  return header;
}

function zipStore(files, timestamp) {
  const names = new Set();
  const localParts = [];
  const centralParts = [];
  const stamp = dosDateTime(timestamp);
  let offset = 0;
  for (const file of files) {
    const name = String(file.name || '');
    if (!name || name.startsWith('/') || name.includes('..') || name.includes('\\') || names.has(name)) throw new Error('The publication package contains an unsafe or repeated file name.');
    names.add(name);
    const nameBytes = encoder.encode(name);
    const data = typeof file.data === 'string' ? encoder.encode(file.data) : new Uint8Array(file.data || []);
    const crc = crc32(data);
    const local = localHeader(nameBytes, data, crc, stamp);
    localParts.push(local, nameBytes, data);
    centralParts.push(centralHeader(nameBytes, data, crc, stamp, offset), nameBytes);
    offset += local.length + nameBytes.length + data.length;
  }
  const central = concat(centralParts);
  const end = new Uint8Array(22);
  const view = new DataView(end.buffer);
  view.setUint32(0, 0x06054B50, true);
  view.setUint16(4, 0, true);
  view.setUint16(6, 0, true);
  view.setUint16(8, files.length, true);
  view.setUint16(10, files.length, true);
  view.setUint32(12, central.length, true);
  view.setUint32(16, offset, true);
  view.setUint16(20, 0, true);
  const archive = concat([...localParts, central, end]);
  if (archive.length > MAX_SITE_BYTES) throw new Error('The ready-to-host website is larger than the 2.5 MB safety limit.');
  return archive;
}

function safeFilePart(value, fallback = 'shared-sources') {
  const cleaned = text(value, 120).replace(/[\\/:*?"<>|]+/g, '-').replace(/\s+/g, '-').replace(/^-+|-+$/g, '');
  return cleaned || fallback;
}

function build(bundleRaw, options = {}) {
  const {document, updateFile} = normalizeBundle(bundleRaw);
  const counts = publicationCounts(document);
  const includeOpml = counts.feeds > 0;
  const edition = options?.editionRaw ? normalizeEdition(options.editionRaw, document) : null;
  const files = [
    {name: 'index.html', data: renderIndex(document, updateFile, includeOpml, edition)},
    {name: updateFile, data: `${JSON.stringify(document, null, 2)}\n`},
    ...(edition ? [{name: EDITION_FILE, data: edition.raw}] : []),
    ...(includeOpml ? [{name: 'subscriptions.opml', data: renderOpml(document)}] : []),
    {name: 'README.txt', data: renderReadme(document, updateFile, includeOpml, edition)}
  ];
  const bytes = zipStore(files, document.exportedAt);
  const day = Number.isFinite(Date.parse(document.exportedAt)) ? new Date(document.exportedAt).toISOString().slice(0, 10) : 'undated';
  return {
    schema: SITE_SCHEMA,
    fileName: `ProgRSS-${safeFilePart(document.title)}-website-${day}.zip`,
    mime: 'application/zip',
    bytes,
    files: files.map(file => ({name: file.name, bytes: byteLength(file.data)})),
    summary: {
      title: text(document.title, 180),
      curator: text(document?.publication?.curator, 80),
      updateUrl: String(document.distribution.updateUrl || ''),
      updateFile,
      feeds: counts.feeds,
      pageWatches: counts.pageWatches,
      folders: counts.folders,
      sourceNotes: counts.sourceNotes,
      recentUpdatesIncluded: Boolean(edition),
      updates: edition?.document?.items?.length || 0,
      updatesFile: edition ? EDITION_FILE : '',
      feedUrl: edition?.feedUrl || '',
      signed: Boolean(document?.integrity?.signature),
      files: files.length,
      bytes: bytes.length,
      scripts: 0,
      trackers: 0,
      automaticChecks: false,
      discoverableFromPage: true,
      advertisedMediaType: BUNDLE_MEDIA_TYPE,
      advertisedFeedMediaType: edition ? FEED_MEDIA_TYPE : ''
    }
  };
}

root.ProgRSSPublicationSite = Object.freeze({
  SITE_SCHEMA,
  BUNDLE_MEDIA_TYPE,
  FEED_MEDIA_TYPE,
  EDITION_SCHEMA,
  EDITION_FILE,
  MAX_SITE_BYTES,
  build,
  siteFileName,
  normalizeEdition,
  renderIndex,
  renderOpml,
  renderReadme,
  zipStore
});
})(typeof globalThis !== 'undefined' ? globalThis : this);
