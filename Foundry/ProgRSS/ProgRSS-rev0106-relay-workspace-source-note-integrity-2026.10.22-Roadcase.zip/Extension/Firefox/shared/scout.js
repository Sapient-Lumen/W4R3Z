/* ProgRSS rev0006 Site Scout: deliberate, offline-first feed autodiscovery.
   Pure candidate normalization is separately testable without a DOM/browser. */
(function(root){
'use strict';
const C=root.ProgRSSCore;
const MAX_HEAD=320_000, MAX_LINK_HEADER=8192, MAX_CANDIDATES=24, MAX_SHARED_FOLDERS=4;
const SHARED_FOLDER_MIME='application/vnd.progrss.shared-folder+json';
const FORMATS=Object.freeze({
  'application/rss+xml':'RSS',
  'application/atom+xml':'Atom',
  'application/feed+json':'JSON Feed',
  'application/json':'JSON (verify feed)'
});
function relIsAlternate(rel){const words=String(rel||'').toLowerCase().split(/\s+/);return words.includes('alternate')&&!words.includes('stylesheet');}
function mimeOf(type){return String(type||'').split(';',1)[0].trim().toLowerCase();}
function splitLinkHeader(value){
  if(typeof value!=='string'||value.length>MAX_LINK_HEADER)return [];
  let pieces=[],inQuote=false,inAngle=false,start=0,escape=false;
  for(let i=0;i<value.length;i++){
    let c=value[i];if(escape){escape=false;continue}
    if(c==='\\'&&inQuote){escape=true;continue}
    if(c==='"'&&!inAngle){inQuote=!inQuote;continue}
    if(c==='<'&&!inQuote){inAngle=true;continue}
    if(c==='>'&&!inQuote){inAngle=false;continue}
    if(c===','&&!inQuote&&!inAngle){pieces.push(value.slice(start,i));start=i+1;}
  }
  pieces.push(value.slice(start));
  return pieces.slice(0,40).flatMap(piece=>{
    const m=piece.match(/^\s*<([^>]*)>([\s\S]*)$/);
    if(!m)return [];
    const rec={href:m[1],rel:'',type:'',title:''};
    for(const pair of m[2].matchAll(/;\s*(rel|type|title)\s*=\s*("(?:\\.|[^"])*"|'[^']*'|[^;\s,]+)/gi)){
      let v=pair[2];if(v.startsWith('"')||v.startsWith("'"))v=v.slice(1,-1).replace(/\\"/g,'"');
      rec[pair[1].toLowerCase()]=v;
    }
    return [{...rec,_header:true}];
  });
}
function chooseCandidates(records,siteUrl,options={}){
  const from=C.safeUrl(siteUrl);
  const suppliedBase=options.baseHref;
  let base=from;
  if(suppliedBase){try{base=C.safeUrl(suppliedBase,from)}catch{}}
  const links=[...(Array.isArray(records)?records:[]),...splitLinkHeader(options.linkHeader||'')];
  const out=[],seen=new Set();
  for(const record of links.slice(0,150)){
    if(!record||!relIsAlternate(record.rel)||!record.href)continue;
    const mime=mimeOf(record.type);
    if(!Object.hasOwn(FORMATS,mime))continue;
    const baseUrl=record._header?from:base;
    let url;try{url=C.safeUrl(String(record.href),baseUrl)}catch{continue}
    if(seen.has(url))continue;
    seen.add(url);
    out.push({url,title:C.text(record.title,120)||FORMATS[mime]+' from '+new URL(url).hostname,
      format:FORMATS[mime],mime,kind:'feed',confidence:mime==='application/json'?'verify':'advertised',origin:record._header?'http-header':'html-head',
      evidence:{rel:String(record.rel||''),type:String(record.type||''),href:String(record.href),baseUrl}});
    if(out.length>=MAX_CANDIDATES)break;
  }
  // Full JSON Feed MIME wins over the fallback generic JSON declaration.
  out.sort((a,b)=>Number(a.confidence==='verify')-Number(b.confidence==='verify'));
  return out;
}
function chooseSharedFolders(records,siteUrl,options={}){
  const from=C.safeUrl(siteUrl);
  const pageOrigin=new URL(from).origin;
  const suppliedBase=options.baseHref;
  let base=from;
  if(suppliedBase){try{base=C.safeUrl(suppliedBase,from)}catch{}}
  const links=[...(Array.isArray(records)?records:[]),...splitLinkHeader(options.linkHeader||'')];
  const out=[],seen=new Set();
  for(const record of links.slice(0,150)){
    if(!record||!relIsAlternate(record.rel)||!record.href||mimeOf(record.type)!==SHARED_FOLDER_MIME)continue;
    const baseUrl=record._header?from:base;
    let url;try{url=C.safeUrl(String(record.href),baseUrl)}catch{continue}
    if(new URL(url).origin!==pageOrigin||seen.has(url))continue;
    seen.add(url);
    out.push({
      kind:'shared-folder',url,
      title:C.text(record.title,120)||'ProgRSS shared folder',
      mime:SHARED_FOLDER_MIME,
      origin:record._header?'http-header':'html-head',
      evidence:{rel:String(record.rel||''),type:String(record.type||''),href:String(record.href),baseUrl}
    });
    if(out.length>=MAX_SHARED_FOLDERS)break;
  }
  return out;
}
function publicationChoices(candidates,sharedFolders,siteUrl){
  const page=C.safeUrl(siteUrl),pageOrigin=new URL(page).origin;
  const folders=(Array.isArray(sharedFolders)?sharedFolders:[]).filter(row=>{
    try{return row?.kind==='shared-folder'&&new URL(C.safeUrl(row.url,page)).origin===pageOrigin;}catch{return false;}
  });
  if(folders.length!==1)return null;
  const editions=(Array.isArray(candidates)?candidates:[]).filter(row=>{
    if(row?.mime!=='application/feed+json')return false;
    try{
      const url=C.safeUrl(row.url,page),path=new URL(url).pathname.toLowerCase();
      const named=/\brecent updates\b/i.test(String(row.title||''));
      return new URL(url).origin===pageOrigin&&(named||path.endsWith('/recent-updates.json'));
    }catch{return false;}
  });
  if(editions.length!==1)return null;
  return {schema:'progrss.publication-choices.v1',sourceList:folders[0],recentUpdates:editions[0]};
}
function suggestPageRegions(doc){
  const suggestions=[];
  const probes=['main article','article','main .post','main .entry','.h-entry','.post','.entry','.news-item','main li'];
  for(const selector of probes){
    const nodes=Array.from(doc.querySelectorAll(selector));
    const n=nodes.length;
    if(n>=2&&n<=200){
      const examples=nodes.slice(0,4).map(node=>C.text(node.querySelector('h1,h2,h3,h4')?.textContent||node.textContent||'',120)).filter(Boolean);
      suggestions.push({kind:'page',mode:'cards',selector,titleSelector:'h1,h2,h3,h4',linkSelector:'a[href]',
        title:'Watch repeated entries',format:'Page watcher',confidence:'heuristic',count:n,examples});
    }
    if(suggestions.length===3)break;
  }
  const region=doc.querySelector('main')||doc.body;
  suggestions.push({kind:'page',mode:'region',selector:doc.querySelector('main')?'main':'',
    title:'Watch the primary text region',format:'Page watcher',confidence:'manual',
    preview:C.text(region?.textContent||'',260)});
  return suggestions;
}
function scanMarkup(raw,siteUrl,options={}){
  if(typeof raw!=='string'||raw.length>C.LIMIT.characters)throw Error('Site Scout can inspect at most 2 million characters');
  const sourceUrl=C.safeUrl(siteUrl);
  // Full feed documents are accepted only after actual feed parsing.
  try{let f=C.parseFeed(raw,sourceUrl);return {siteUrl:sourceUrl,title:f.title,kind:'direct-feed',
    candidates:[{kind:'feed',url:sourceUrl,title:f.title,format:f.type==='json'?'JSON Feed':f.type==='atom'?'Atom':'RSS',
      mime:'',confidence:'parsed',origin:'body'}],sharedFolders:[],recommendations:[],count:f.items.length};}
  catch { /* Not a supported feed: attempt HTML head discovery instead. */ }
  if(typeof root.DOMParser!=='function')throw Error('Site Scout markup parsing needs DOMParser; use the webpage or CLI scout.');
  // Parse a HEAD-ONLY surrogate. Remote images, frames and body subresources never
  // enter this inert parse tree. The original page scripts are never run.
  const match=raw.match(/<head\b[^>]*>([\s\S]*?)<\/head\s*>/i);
  const head=(match?match[1]:raw.slice(0,MAX_HEAD)).slice(0,MAX_HEAD)
    .replace(/<\s*(script|style|iframe|object|svg|template)\b[^>]*>[\s\S]*?<\s*\/\s*\1\s*>/gi,'')
    .replace(/<\s*(img|source|track|embed|meta)\b[^>]*>/gi,'');
  const doc=new root.DOMParser().parseFromString('<!doctype html><html><head>'+head+'</head><body></body></html>','text/html');
  const items=Array.from(doc.head.querySelectorAll('link[rel][href]')).slice(0,140).map(el=>({
    href:el.getAttribute('href'),rel:el.getAttribute('rel'),type:el.getAttribute('type'),title:el.getAttribute('title')
  }));
  const baseHref=doc.head.querySelector('base[href]')?.getAttribute('href')||'';
  const title=C.text(doc.head.querySelector('title')?.textContent||new URL(sourceUrl).hostname,150);
  // Page-region suggestions require a second, still-inert document constructed
  // from the sanitized HTML used by the existing Patch Clinic.
  const safeDoc=new root.DOMParser().parseFromString(C.staticHtml(raw),'text/html');
  const recommendations=suggestPageRegions(safeDoc);
  const candidates=chooseCandidates(items,sourceUrl,{baseHref,linkHeader:options.linkHeader});
  const sharedFolders=chooseSharedFolders(items,sourceUrl,{baseHref,linkHeader:options.linkHeader});
  return {
    siteUrl:sourceUrl,title,kind:'html',
    candidates,
    sharedFolders,
    publicationChoices:publicationChoices(candidates,sharedFolders,sourceUrl),
    recommendations,count:0
  };
}
root.ProgRSSScout=Object.freeze({scanMarkup,chooseCandidates,chooseSharedFolders,publicationChoices,splitLinkHeader,suggestPageRegions,relIsAlternate,mimeOf,SHARED_FOLDER_MIME});
})(globalThis);
