'use strict';

(() => {
  const api = globalThis.browser || globalThis.chrome;
  const PublicationSite = globalThis.ProgRSSPublicationSite;
  const MAX_OPML_BYTES = 2_000_000;
  const MAX_PRIVATE_BACKUP_BYTES = 24_000_000;
  const MAX_SHARED_FOLDER_BYTES = 650_000;
  const MAX_ACTIVE_IMPORT_ORIGINS = 20;
  const MAX_READING_RESULTS = 80;
  const MAX_TEXT_CLEANUP_BYTES = 1_500_000;
  const MAX_TEXT_CLEANUP_ITEMS = 240;
  const PAGE_CHANGE_SCHEMA = 'progrss.page-change.v1';
  const NODE_PAIRING_SCHEMA = 'progrss.node.pairing.v1';
  const NODE_PAIRING_STORAGE_SCHEMA = 'progrss.extension.node-pairing.v1';
  const NODE_PAIRING_PERMISSION = 'http://127.0.0.1/*';
  const NODE_EXCHANGE_SCHEMA = 'progrss.node.exchange.v1';
  const NODE_CAPTURE_SCHEMA = 'progrss.node.capture.v1';
  const NODE_CAPTURE_ARTIFACT_SCHEMA = 'progrss.browser-capture.v4';
  const NODE_CAPTURE_CANDIDATES_SCHEMA = 'progrss.browser-capture-candidates.v3';
  const NODE_CAPTURE_SELECTION_SCHEMA = 'progrss.capture-selection.v1';
  const NODE_CAPTURE_ASSESSMENT_SCHEMA = 'progrss.capture-section-assessment.v1';
  const NODE_CAPTURE_CONTEXT_SCHEMA = 'progrss.capture-page-context.v1';
  const NODE_CAPTURE_COVERAGE_SCHEMA = 'progrss.capture-coverage-review.v1';
  const MAX_CAPTURE_ARTIFACT_BYTES = 300_000;
  const NODE_EXCHANGE_PERMISSION = NODE_PAIRING_PERMISSION;
  const MAX_EXCHANGE_ARTIFACT_BYTES = 2_000_000;
  const app = {
    state: {sources: [], collections: [], items: [], vault: {}},
    view: 'today',
    filter: 'unread',
    folder: 'all',
    search: '',
    theme: 'dark',
    detailItemId: '',
    detailReturnFocusId: '',
    detailSequence: [],
    followHandoff: null,
    folderUndo: null,
    folderUndoTimer: 0,
    sourceNoteEditor: null,
    sourceNoteUndo: null,
    sourceNoteUndoTimer: 0,
    textCleanupUndo: null,
    textCleanupUndoTimer: 0,
    storageEstimate: null,
    repairPreview: null,
    repairChoice: '',
    repairAcknowledged: false,
    pageWatchRepairReview: null,
    pageWatchRepairChoice: '',
    undoIds: [],
    undoTimer: 0,
    discovery: null,
    opml: null,
    sharedFolder: null,
    shareFolder: null,
    shareIdentity: null,
    shareAttribution: {curator: '', note: '', updateUrl: '', sign: false, includeUpdates: false},
    transfer: null,
    copyCheck: null,
    recoveryWasVisible: false,
    privateCopyWasDue: false,
    nodeReview: null,
    nodePairing: null,
    busy: new Set()
  };

  const $ = selector => document.querySelector(selector);
  const $$ = selector => Array.from(document.querySelectorAll(selector));
  const els = {
    status: $('#status'),
    libraryRecovery: $('#library-recovery'),
    libraryRecoveryHeading: $('#library-recovery-heading'),
    libraryRecoveryMessage: $('#library-recovery-message'),
    libraryRecoveryDetail: $('#library-recovery-detail'),
    restoreMissingLibrary: $('#restore-missing-library'),
    acceptEmptyLibrary: $('#accept-empty-library'),
    storageIncident: $('#storage-incident'),
    storageIncidentHeading: $('#storage-incident-heading'),
    storageIncidentMessage: $('#storage-incident-message'),
    storageIncidentDetail: $('#storage-incident-detail'),
    saveRecoveryCopy: $('#save-recovery-copy'),
    checkStorage: $('#check-storage'),
    libraryUndo: $('#library-undo'),
    libraryUndoMessage: $('#library-undo-message'),
    undoLibraryMove: $('#undo-library-move'),
    refreshAll: $('#refresh-all'),
    themeToggle: $('#theme-toggle'),
    themeIcon: $('#theme-icon'),
    todaySummary: $('#today-summary'),
    markAll: $('#mark-all-read'),
    followHandoff: $('#follow-handoff'),
    followHandoffHeading: $('#follow-handoff-heading'),
    followHandoffMessage: $('#follow-handoff-message'),
    followHandoffFolder: $('#follow-handoff-folder'),
    showFollowedSource: $('#show-followed-source'),
    dismissFollowHandoff: $('#dismiss-follow-handoff'),
    readingSearch: $('#reading-search'),
    clearSearch: $('#clear-search'),
    searchSummary: $('#search-summary'),
    undoRow: $('#undo-row'),
    undoMessage: $('#undo-message'),
    undo: $('#undo-mark-all'),
    itemList: $('#item-list'),
    detailBack: $('#detail-back'),
    detailSource: $('#detail-source'),
    detailTime: $('#detail-time'),
    detailHeading: $('#detail-heading'),
    detailNote: $('#detail-note'),
    detailBody: $('#detail-body'),
    detailRead: $('#detail-read'),
    detailSave: $('#detail-save'),
    detailOpen: $('#detail-open'),
    detailNewer: $('#detail-newer'),
    detailOlder: $('#detail-older'),
    sourceSummary: $('#source-summary'),
    sourceList: $('#source-list'),
    todayFolderScope: $('#today-folder-scope'),
    todayFolders: $('#today-folders'),
    sourceFolderScope: $('#source-folder-scope'),
    sourceFolders: $('#source-folders'),
    checkSharedFolderUpdate: $('#check-shared-folder-update'),
    shareFolderButton: $('#share-folder-button'),
    shareFolderReview: $('#share-folder-review'),
    shareFolderHeading: $('#share-folder-heading'),
    shareFolderMessage: $('#share-folder-message'),
    shareFolderFacts: $('#share-folder-facts'),
    shareAttribution: $('#share-attribution'),
    shareCurator: $('#share-curator'),
    shareNote: $('#share-note'),
    shareUpdateUrl: $('#share-update-url'),
    siteIncludeUpdates: $('#site-include-updates'),
    shareSign: $('#share-sign'),
    shareIdentityStatus: $('#share-identity-status'),
    createShareIdentity: $('#create-share-identity'),
    saveSharedFolder: $('#save-shared-folder'),
    saveFolderOpml: $('#save-folder-opml'),
    savePublicationSite: $('#save-publication-site'),
    saveFolderEdition: $('#save-folder-edition'),
    closeShareFolder: $('#close-share-folder'),
    privateCopy: $('#private-copy'),
    privateCopyOptions: $('#private-copy-options'),
    backupReminderMessage: $('#backup-reminder-message'),
    backupReminderSummary: $('#backup-reminder-summary'),
    savePrivateCopy: $('#save-private-copy'),
    checkPrivateCopy: $('#check-private-copy'),
    copyCheckFile: $('#copy-check-file'),
    copyCheckResult: $('#copy-check-result'),
    copyCheckHeading: $('#copy-check-heading'),
    copyCheckMessage: $('#copy-check-message'),
    copyCheckFacts: $('#copy-check-facts'),
    snoozeBackupReminder: $('#snooze-backup-reminder'),
    disableBackupReminder: $('#disable-backup-reminder'),
    enableBackupReminder: $('#enable-backup-reminder'),
    markBackupCopyMissing: $('#mark-backup-copy-missing'),
    storageOverview: $('#storage-overview'),
    storageSummary: $('#storage-summary'),
    storageTextSummary: $('#storage-text-summary'),
    storageBrowserRow: $('#storage-browser-row'),
    storageBrowserSummary: $('#storage-browser-summary'),
    textCleanupUndo: $('#text-cleanup-undo'),
    textCleanupUndoMessage: $('#text-cleanup-undo-message'),
    undoTextCleanup: $('#undo-text-cleanup'),
    sourceRepairUndo: $('#source-repair-undo'),
    sourceRepairUndoMessage: $('#source-repair-undo-message'),
    undoSourceRepair: $('#undo-source-repair'),
    pageWatchRepairUndo: $('#page-watch-repair-undo'),
    pageWatchRepairUndoMessage: $('#page-watch-repair-undo-message'),
    undoPageWatchRepair: $('#undo-page-watch-repair'),
    sharedFolderUpdateUndo: $('#shared-folder-update-undo'),
    sharedFolderUpdateUndoMessage: $('#shared-folder-update-undo-message'),
    undoSharedFolderUpdate: $('#undo-shared-folder-update'),
    sourceRepairNotice: $('#source-repair-notice'),
    sourceRepairReview: $('#source-repair-review'),
    folderUndoRow: $('#folder-undo-row'),
    folderUndoMessage: $('#folder-undo-message'),
    undoFolderChange: $('#undo-folder-change'),
    sourceNoteUndo: $('#source-note-undo'),
    sourceNoteUndoMessage: $('#source-note-undo-message'),
    undoSourceNote: $('#undo-source-note'),
    unreadCount: $('#unread-count'),
    useCurrent: $('#use-current-page'),
    focusAddress: $('#focus-address'),
    chooseOpml: $('#choose-opml'),
    focusNodePairing: $('#focus-node-pairing'),
    nodePairingCard: $('#node-pairing-card'),
    nodePairingHeading: $('#node-pairing-heading'),
    nodePairingSummary: $('#node-pairing-summary'),
    nodeStateBadge: $('#node-state-badge'),
    nodePairingStart: $('#node-pairing-start'),
    nodeInvitation: $('#node-invitation'),
    reviewNode: $('#review-node'),
    nodeReview: $('#node-review'),
    nodeReviewHeading: $('#node-review-heading'),
    nodeReviewExpiry: $('#node-review-expiry'),
    nodeReviewMessage: $('#node-review-message'),
    nodeReviewFacts: $('#node-review-facts'),
    pairNode: $('#pair-node'),
    cancelNodeReview: $('#cancel-node-review'),
    nodePaired: $('#node-paired'),
    nodePairedHeading: $('#node-paired-heading'),
    nodePairedMessage: $('#node-paired-message'),
    nodePairedFacts: $('#node-paired-facts'),
    nodeAdvancedFacts: $('#node-advanced-facts'),
    checkNode: $('#check-node'),
    unpairNode: $('#unpair-node'),
    forgetNode: $('#forget-node'),
    chooseSharedFolder: $('#choose-shared-folder'),
    form: $('#address-form'),
    address: $('#address'),
    addressSubmit: $('#address-form button[type="submit"]'),
    discovery: $('#discovery'),
    opmlFile: $('#opml-file'),
    opmlCard: $('#opml-card'),
    opmlPreview: $('#opml-preview'),
    sharedFolderCard: $('#shared-folder-card'),
    sharedFolderFile: $('#shared-folder-file'),
    sharedFolderPreview: $('#shared-folder-preview'),
    exportLibrary: $('#export-library'),
    backupFile: $('#backup-file'),
    backupPreview: $('#backup-preview'),
    openWorkbench: $('#open-workbench')
  };


  function applyTheme(value) {
    const theme = value === 'light' ? 'light' : 'dark';
    app.theme = theme;
    document.documentElement.dataset.theme = theme;
    const nextLabel = theme === 'dark' ? 'Use light theme' : 'Use dark theme';
    els.themeToggle.setAttribute('aria-label', nextLabel);
    els.themeToggle.title = nextLabel;
    els.themeToggle.setAttribute('aria-pressed', String(theme === 'light'));
    els.themeIcon.textContent = theme === 'dark' ? '☼' : '☾';
  }

  async function toggleTheme() {
    const next = app.theme === 'dark' ? 'light' : 'dark';
    applyTheme(next);
    try {
      await api.storage.local.set({appearanceTheme: next});
    } catch {
      setStatus('Theme changed for this open panel. The browser could not save that preference.', 'decision');
    }
  }

  function text(value, fallback = '') {
    const clean = String(value == null ? '' : value).replace(/\s+/g, ' ').trim();
    return clean || fallback;
  }

  function languageTag(value) {
    const raw = String(value == null ? '' : value).trim();
    return raw && raw.length <= 100 && !/[\u0000-\u0020\u007f]/.test(raw) && /^[A-Za-z]{1,8}(?:-[A-Za-z0-9]{1,8})*$/.test(raw) ? raw.toLowerCase() : '';
  }

  function languageFor(item, field, source = null) {
    return languageTag(item?.[`${field}Language`] || item?.language || source?.language || '');
  }

  function markNaturalText(node, language = '') {
    const clean = languageTag(language);
    if (clean) node.lang = clean;
    else node.removeAttribute('lang');
    node.dir = 'auto';
    return node;
  }

  function h(tag, attrs = {}, children = []) {
    const node = document.createElement(tag);
    for (const [key, value] of Object.entries(attrs)) {
      if (value == null || value === false) continue;
      if (key === 'class') node.className = value;
      else if (key === 'text') node.textContent = value;
      else if (key === 'dataset') Object.assign(node.dataset, value);
      else if (key === 'ariaLabel') node.setAttribute('aria-label', value);
      else if (key === 'ariaPressed') node.setAttribute('aria-pressed', String(value));
      else if (key === 'checked') node.checked = Boolean(value);
      else if (key === 'disabled') node.disabled = Boolean(value);
      else if (key === 'hidden') node.hidden = Boolean(value);
      else node.setAttribute(key, String(value));
    }
    const list = Array.isArray(children) ? children : [children];
    for (const child of list) {
      if (child == null) continue;
      node.append(child.nodeType ? child : document.createTextNode(String(child)));
    }
    return node;
  }

  function normalized(value) {
    let result = String(value == null ? '' : value);
    try { result = result.normalize('NFKD').replace(/[\u0300-\u036f]/g, ''); } catch {}
    return result.toLocaleLowerCase().replace(/\s+/g, ' ').trim();
  }

  function utf8Bytes(value) {
    return new TextEncoder().encode(String(value == null ? '' : value)).byteLength;
  }

  function formatBytes(value) {
    const bytes = Math.max(0, Number(value) || 0);
    if (bytes < 1000) return `${Math.round(bytes)} B`;
    if (bytes < 1_000_000) return `${(bytes / 1000).toFixed(bytes < 10_000 ? 1 : 0)} KB`;
    return `${(bytes / 1_000_000).toFixed(bytes < 10_000_000 ? 1 : 0)} MB`;
  }

  function fullTextItems(sourceId = '') {
    return (app.state.items || []).filter(item => (!sourceId || item.sourceId === sourceId) && item.body && !item.bodyIsSummary);
  }

  function cleanupBatch(sourceId) {
    const candidates = fullTextItems(sourceId)
      .filter(item => item.readAt && !item.starred)
      .sort((a, b) => (Date.parse(a.observedAt || a.published || '') || 0) - (Date.parse(b.observedAt || b.published || '') || 0));
    const selected = [];
    let bytes = 0;
    for (const item of candidates) {
      if (selected.length >= MAX_TEXT_CLEANUP_ITEMS) break;
      const itemBytes = utf8Bytes(item.body);
      if (selected.length && bytes + itemBytes > MAX_TEXT_CLEANUP_BYTES) break;
      selected.push(item);
      bytes += itemBytes;
    }
    return {candidates, selected, bytes};
  }

  function renderStorageOverview() {
    const items = fullTextItems();
    const bytes = items.reduce((total, item) => total + utf8Bytes(item.body), 0);
    const omitted = (app.state.items || []).filter(item => item.bodyOmitted).length;
    els.storageSummary.textContent = bytes ? `${formatBytes(bytes)} retained` : 'No full text retained';
    els.storageTextSummary.textContent = bytes
      ? `${formatBytes(bytes)} across ${items.length} update${items.length === 1 ? '' : 's'}${omitted ? ` · ${omitted} intentionally summary-only` : ''}`
      : (omitted ? `${omitted} update${omitted === 1 ? '' : 's'} kept as summaries by your choices` : 'None retained');
    const estimate = app.storageEstimate;
    els.storageBrowserRow.hidden = !estimate || !Number.isFinite(estimate.usage);
    if (!els.storageBrowserRow.hidden) {
      els.storageBrowserSummary.textContent = `about ${formatBytes(estimate.usage)} total for ProgRSS`;
    }
  }

  function renderBackupReminder() {
    const reminder = app.state.backupReminder && typeof app.state.backupReminder === 'object'
      ? app.state.backupReminder : {};
    const blockedByRecovery = libraryRecoveryRequired();
    const blockedByIncident = Boolean(app.state.storageIncident?.schema === 'progrss.storage.incident.v1');
    const meaningful = Boolean(reminder.meaningful);
    const due = Boolean(reminder.visible && meaningful && !blockedByRecovery && !blockedByIncident);
    const wasDue = app.privateCopyWasDue;
    const enteringDue = due && !wasDue;
    const leavingDue = !due && wasDue;
    app.privateCopyWasDue = due;
    els.privateCopy.hidden = !meaningful || blockedByRecovery || blockedByIncident;
    els.privateCopy.classList.toggle('attention', due);
    if (enteringDue) els.privateCopy.open = true;
    else if (leavingDue && !app.copyCheck) els.privateCopy.open = false;

    let message = 'A private file can restore this portable library if the browser profile loses its local data.';
    let saveLabel = 'Save private copy';
    let checkLabel = 'Check saved copy';
    let checkFirst = false;
    if (reminder.pendingCheck) {
      message = 'The browser started a private-file download, but downloads can be cancelled or fail. Select the file the browser kept so ProgRSS can check it.';
      saveLabel = 'Save again';
      checkLabel = 'Check saved copy';
      checkFirst = true;
    } else if (reminder.checkedCopyMissing) {
      message = 'You marked the last checked copy as missing. Save and check a new copy before relying on this browser alone.';
      saveLabel = 'Save new copy';
      checkLabel = 'Check a copy';
    } else if (reminder.lastCheckedAt && reminder.changedSinceChecked) {
      message = `This library changed after its private copy was checked ${relativeTime(reminder.lastCheckedAt)}. Save and check an updated copy to include those changes.`;
      saveLabel = 'Save updated copy';
      checkLabel = 'Check saved copy';
    } else if (reminder.recheckDue) {
      message = `ProgRSS has not read the checked copy for ${reminder.recheckDays || 90} days. Select it to make sure it still opens, or save a fresh copy.`;
      saveLabel = 'Save fresh copy';
      checkLabel = 'Check saved copy';
      checkFirst = true;
    } else if (!reminder.lastCheckedAt) {
      message = 'This library has had time to become useful. Save a private file, then select the saved file so ProgRSS can check it.';
    } else if (reminder.disabled) {
      message = 'Private-copy reminders are off. You can still save or check a copy here.';
    } else if (reminder.snoozedUntil && Date.parse(reminder.snoozedUntil) > Date.now()) {
      message = `No reminder is due now. The next reminder can appear ${relativeTime(reminder.snoozedUntil)}.`;
    } else {
      message = `The checked private copy was last read ${relativeTime(reminder.lastSeenAt || reminder.lastCheckedAt)}.`;
    }
    els.backupReminderMessage.textContent = message;
    els.savePrivateCopy.textContent = saveLabel;
    els.checkPrivateCopy.textContent = checkLabel;
    els.savePrivateCopy.className = checkFirst ? 'secondary' : (due ? 'primary' : 'secondary');
    els.checkPrivateCopy.className = checkFirst ? 'primary' : 'secondary';
    els.savePrivateCopy.style.order = checkFirst ? '2' : '1';
    els.checkPrivateCopy.style.order = checkFirst ? '1' : '2';

    if (!meaningful) {
      els.backupReminderSummary.textContent = 'Nothing to copy yet';
    } else if (reminder.disabled) {
      if (reminder.pendingCheck && reminder.lastPreparedAt) els.backupReminderSummary.textContent = 'Reminders off · prepared copy not checked';
      else if (reminder.checkedCopyMissing) els.backupReminderSummary.textContent = 'Reminders off · checked copy marked missing';
      else if (reminder.lastCheckedAt && reminder.changedSinceChecked) els.backupReminderSummary.textContent = `Reminders off · older copy checked ${relativeTime(reminder.lastSeenAt || reminder.lastCheckedAt)}`;
      else if (reminder.lastCheckedAt) els.backupReminderSummary.textContent = `Reminders off · copy checked ${relativeTime(reminder.lastSeenAt || reminder.lastCheckedAt)}`;
      else els.backupReminderSummary.textContent = 'Reminders off';
    } else if (reminder.snoozedUntil && Date.parse(reminder.snoozedUntil) > Date.now()) {
      els.backupReminderSummary.textContent = `Reminder returns ${relativeTime(reminder.snoozedUntil)}`;
    } else if (reminder.pendingCheck && reminder.lastPreparedAt) {
      els.backupReminderSummary.textContent = `Prepared ${relativeTime(reminder.lastPreparedAt)} · not checked`;
    } else if (reminder.checkedCopyMissing) {
      els.backupReminderSummary.textContent = `Checked copy marked missing ${relativeTime(reminder.missingSince)}`;
    } else if (reminder.lastCheckedAt && reminder.changedSinceChecked) {
      els.backupReminderSummary.textContent = `Older copy checked ${relativeTime(reminder.lastSeenAt || reminder.lastCheckedAt)} · library changed`;
    } else if (reminder.recheckDue) {
      els.backupReminderSummary.textContent = `Copy last read ${relativeTime(reminder.lastSeenAt || reminder.lastCheckedAt)} · check again`;
    } else if (reminder.lastCheckedAt) {
      els.backupReminderSummary.textContent = `Copy checked ${relativeTime(reminder.lastSeenAt || reminder.lastCheckedAt)}`;
    } else {
      els.backupReminderSummary.textContent = 'No checked private copy';
    }

    els.snoozeBackupReminder.hidden = !due || reminder.disabled;
    els.disableBackupReminder.hidden = Boolean(reminder.disabled);
    els.enableBackupReminder.hidden = !reminder.disabled;
    els.markBackupCopyMissing.hidden = !reminder.lastCheckedAt || reminder.checkedCopyMissing;
  }

  function copyCheckFact(title, detail) {
    return h('div', {}, [h('dt', {text: title}), h('dd', {text: detail})]);
  }

  function renderCopyCheck() {
    const check = app.copyCheck;
    els.copyCheckResult.hidden = !check;
    els.copyCheckResult.removeAttribute('data-state');
    els.copyCheckFacts.replaceChildren();
    if (!check) return;
    if (check.loading) {
      els.copyCheckResult.dataset.state = 'loading';
      els.copyCheckHeading.textContent = 'Checking saved copy…';
      els.copyCheckMessage.textContent = 'ProgRSS is reading the selected local file. Nothing is being uploaded or restored.';
      return;
    }
    if (check.error) {
      els.copyCheckResult.dataset.state = 'invalid';
      els.copyCheckHeading.textContent = 'That file could not be checked';
      els.copyCheckMessage.textContent = check.error;
      return;
    }
    const report = check.report || {};
    const file = report.file || {};
    const current = report.current || {};
    els.copyCheckResult.dataset.state = report.state || 'different';
    if (report.state === 'current') {
      els.copyCheckHeading.textContent = 'This saved copy matches';
      els.copyCheckMessage.textContent = 'ProgRSS read the selected file and it matches the portable library here now. This confirms the file was readable at this check; it cannot promise the file will remain available later.';
    } else if (report.state === 'previous') {
      els.copyCheckHeading.textContent = report.relationship === 'last-prepared'
        ? 'This prepared copy still opens'
        : 'This older checked copy still opens';
      els.copyCheckMessage.textContent = report.relationship === 'last-prepared'
        ? 'ProgRSS recognized the file it prepared earlier. It is readable, but the library changed before it was checked. Nothing was restored or changed.'
        : 'ProgRSS recognized the copy checked earlier. It is still readable, but this library has changed since that copy was current. Nothing was restored or changed.';
    } else {
      els.copyCheckHeading.textContent = 'This is a different valid copy';
      els.copyCheckMessage.textContent = 'The file is readable ProgRSS data, but it is not the current library or the private copy ProgRSS remembers checking here. Nothing was restored or changed. Use Add → Move this ProgRSS library only when you intend to review a replacement.';
    }
    if (report.exportedAt) els.copyCheckFacts.append(copyCheckFact('Prepared', relativeTime(report.exportedAt)));
    els.copyCheckFacts.append(
      copyCheckFact('Selected file', `${Number(file.sources) || 0} sources · ${Number(file.items) || 0} updates · ${Number(file.saved) || 0} saved`),
      copyCheckFact('Library here', `${Number(current.sources) || 0} sources · ${Number(current.items) || 0} updates · ${Number(current.saved) || 0} saved`)
    );
    if (report.state === 'previous') els.copyCheckFacts.append(copyCheckFact('Copy status', 'Readable, but older than this library'));
    if (!report.samePortableLibrary && Array.isArray(report.changedAreas) && report.changedAreas.length) {
      els.copyCheckFacts.append(copyCheckFact('Different areas', report.changedAreas.join(', ')));
    }
  }

  async function refreshStorageEstimate() {
    try {
      app.storageEstimate = await navigator.storage?.estimate?.() || null;
    } catch {
      app.storageEstimate = null;
    }
    renderStorageOverview();
  }



  function folderModel() {
    const sourceIds = new Set((app.state.sources || []).map(row => text(row?.id)).filter(Boolean));
    const simple = new Map();
    for (const row of app.state.collections || []) {
      if (!row || typeof row !== 'object') continue;
      const id = text(row.id);
      const title = text(row.title);
      const mode = text(row.mode || 'union').toLowerCase();
      if (!id || !title || mode !== 'union' || text(row.include) || text(row.exclude) || !Array.isArray(row.members)) continue;
      simple.set(id, row);
    }
    const children = new Map([...simple.keys()].map(id => [id, []]));
    const direct = new Map([...simple.keys()].map(id => [id, new Set()]));
    const referenced = new Set();
    for (const [id, row] of simple) {
      for (const member of row.members.slice(0, 500)) {
        const memberId = text(member?.id);
        if (member?.kind === 'source' && sourceIds.has(memberId)) direct.get(id).add(memberId);
        else if (member?.kind === 'collection' && simple.has(memberId)) {
          children.get(id).push(memberId);
          referenced.add(memberId);
        }
      }
    }
    const paths = new Map([...simple.keys()].map(id => [id, []]));
    function walk(id, path = [], stack = []) {
      if (stack.includes(id) || stack.length >= 24) return;
      const here = [...path, text(simple.get(id).title)];
      const known = paths.get(id);
      if (known.length < 12 && !known.some(candidate => candidate.join('\u0000') === here.join('\u0000'))) known.push(here);
      for (const child of children.get(id)) walk(child, here, [...stack, id]);
    }
    [...simple.keys()].filter(id => !referenced.has(id)).sort((a, b) => text(simple.get(a).title).localeCompare(text(simple.get(b).title))).forEach(id => walk(id));
    const visible = new Set([...paths].filter(([, values]) => values.length).map(([id]) => id));
    function closure(id, stack = []) {
      if (stack.includes(id) || stack.length >= 24) return new Set();
      const result = new Set(direct.get(id));
      for (const child of children.get(id)) {
        if (!visible.has(child)) continue;
        for (const sourceId of closure(child, [...stack, id])) result.add(sourceId);
      }
      return result;
    }
    const rows = [...visible].map(id => {
      const path = [...paths.get(id)].sort((a, b) => a.length - b.length || a.join(' › ').localeCompare(b.join(' › ')))[0];
      return {id, title: text(simple.get(id).title), path: path.join(' › '), collection: simple.get(id), sourceIds: closure(id), directSourceIds: new Set(direct.get(id))};
    }).sort((a, b) => a.path.localeCompare(b.path));
    const filed = new Set();
    rows.forEach(row => row.sourceIds.forEach(id => filed.add(id)));
    return {rows, unfiledSourceIds: new Set([...sourceIds].filter(id => !filed.has(id)))};
  }

  function selectedFolder(model = folderModel()) {
    if (app.folder === 'all') return {id: 'all', label: 'All', sourceIds: null};
    if (app.folder === 'unfiled') return {id: 'unfiled', label: 'Unfiled', sourceIds: model.unfiledSourceIds};
    const row = model.rows.find(folder => folder.id === app.folder);
    if (row) return {id: row.id, label: row.path, sourceIds: row.sourceIds};
    app.folder = 'all';
    return {id: 'all', label: 'All', sourceIds: null};
  }

  function setFolder(folder) {
    const previous = app.folder;
    app.folder = text(folder, 'all') || 'all';
    const model = folderModel();
    selectedFolder(model);
    if (previous !== app.folder) { app.shareFolder = null; app.shareIdentity = null; app.shareAttribution = {curator: '', note: '', updateUrl: '', sign: false, includeUpdates: false}; }
    renderFolderControls(model);
    renderShareFolder();
    renderItems();
    renderDetail();
    renderSources();
    try { api.storage.local.set({libraryFolder: app.folder}); } catch {}
  }

  function renderFolderControl(scope, container, model, label) {
    scope.hidden = model.rows.length === 0;
    container.replaceChildren();
    if (scope.hidden) return;
    const chosen = selectedFolder(model);
    const select = h('select', {class: 'folder-select', ariaLabel: label});
    select.append(h('option', {value: 'all', text: 'All folders'}));
    for (const row of model.rows) select.append(h('option', {value: row.id, text: row.path}));
    if (model.unfiledSourceIds.size) select.append(h('option', {value: 'unfiled', text: 'Unfiled'}));
    select.value = chosen.id;
    select.addEventListener('change', () => setFolder(select.value));
    container.append(select);
  }

  function renderFolderControls(model = folderModel()) {
    renderFolderControl(els.todayFolderScope, els.todayFolders, model, 'Reading folder');
    renderFolderControl(els.sourceFolderScope, els.sourceFolders, model, 'Source folder');
    const chosen = selectedFolder(model);
    const chosenRow = model.rows.find(row => row.id === chosen.id);
    els.shareFolderButton.hidden = !chosenRow;
    const origin = chosenRow?.collection?.sharedFolderOrigin;
    const updateUrl = canonicalAddress(origin?.updateUrl);
    els.checkSharedFolderUpdate.hidden = !chosenRow || !updateUrl;
    els.checkSharedFolderUpdate.dataset.url = updateUrl || '';
  }

  function itemsInSelectedFolder() {
    const selected = selectedFolder();
    return sortedItems().filter(item => selected.sourceIds === null || selected.sourceIds.has(text(item.sourceId)));
  }

  function folderLabelsForSource(sourceId, model = folderModel()) {
    return model.rows.filter(row => row.directSourceIds.has(sourceId)).map(row => row.path).slice(0, 3);
  }

  function folderMembershipForSource(sourceId, model = folderModel()) {
    return {
      direct: model.rows.filter(row => row.directSourceIds.has(sourceId)),
      inherited: model.rows.filter(row => row.sourceIds.has(sourceId) && !row.directSourceIds.has(sourceId)),
      available: model.rows.filter(row => !row.sourceIds.has(sourceId))
    };
  }

  function currentFolderShare() {
    if (!app.state) return null;
    const model = folderModel();
    const chosen = selectedFolder(model);
    const row = model.rows.find(folder => folder.id === chosen.id);
    if (!row) return null;
    const sources = (app.state.sources || []).filter(source => !source.archivedAt && row.sourceIds.has(text(source.id)));
    const nestedFolders = model.rows.filter(folder => folder.id === row.id || folder.path.startsWith(`${row.path} › `));
    const sourceById = new Map(sources.map(source => [text(source.id), source]));
    const editionKeys = new Set();
    for (const item of app.state.items || []) {
      const source = sourceById.get(text(item?.sourceId));
      if (!source) continue;
      const haystack = [item?.title, item?.summary, item?.body].map(value => text(value).toLocaleLowerCase()).join(' ');
      const include = text(source.include).split(',').map(value => value.trim().toLocaleLowerCase()).filter(Boolean);
      const exclude = text(source.exclude).split(',').map(value => value.trim().toLocaleLowerCase()).filter(Boolean);
      if (include.length && !include.some(value => haystack.includes(value))) continue;
      if (exclude.some(value => haystack.includes(value))) continue;
      const kind = text(item?.kind).toLocaleLowerCase();
      const address = canonicalAddress(item?.url);
      const key = kind === 'changed' || kind === 'removed'
        ? `event:${text(item?.sourceId)}:${text(item?.id)}`
        : address ? `url:${address}` : `local:${text(item?.sourceId)}:${text(item?.id)}`;
      editionKeys.add(key);
    }
    const updates = editionKeys.size;
    const origin = row.collection?.sharedFolderOrigin && typeof row.collection.sharedFolderOrigin === 'object'
      ? row.collection.sharedFolderOrigin : null;
    return {
      collectionId: row.id,
      title: row.path,
      sources: sources.length,
      feeds: sources.filter(source => source.type === 'rss').length,
      pageWatches: sources.filter(source => source.type === 'page').length,
      folders: nestedFolders.length,
      updates,
      origin
    };
  }

  function shareFact(title, detail) {
    return h('div', {}, [h('dt', {text: title}), h('dd', {text: detail})]);
  }

  function compactFingerprint(value) {
    const raw = String(value || '');
    const colon = raw.indexOf(':');
    if (colon < 0) return raw;
    const algorithm = raw.slice(0, colon);
    const digest = raw.slice(colon + 1);
    return `${algorithm}:${digest.slice(0, 12)}…${digest.slice(-8)}`;
  }

  function renderShareFolder() {
    const share = app.shareFolder;
    const current = currentFolderShare();
    const valid = share && current && share.collectionId === current.collectionId;
    els.shareFolderReview.hidden = !valid;
    els.shareFolderFacts.replaceChildren();
    if (!valid) return;
    app.shareFolder = current;
    els.shareFolderHeading.textContent = `Share ${current.title}`;
    els.shareFolderMessage.textContent = 'Save a source list that another person can review and add. Attribution is optional, and signing stays behind the advanced disclosure.';
    els.shareFolderFacts.append(
      shareFact('Feeds', `${current.feeds}`),
      shareFact('Page watches', `${current.pageWatches}`),
      shareFact('Folders', `${current.folders}`),
      shareFact('Recent updates', `${current.updates}`),
      shareFact('Site access', 'Never included')
    );

    const attribution = app.shareAttribution || {curator: '', note: '', updateUrl: '', sign: false};
    if (els.shareCurator.value !== attribution.curator) els.shareCurator.value = attribution.curator;
    if (els.shareNote.value !== attribution.note) els.shareNote.value = attribution.note;
    if (els.shareUpdateUrl.value !== attribution.updateUrl) els.shareUpdateUrl.value = attribution.updateUrl;
    const identity = app.shareIdentity;
    if (identity?.loading) {
      els.shareIdentityStatus.textContent = 'Checking for a local signing identity…';
      els.shareSign.disabled = true;
      els.shareSign.checked = false;
      els.createShareIdentity.hidden = true;
    } else if (identity?.error) {
      els.shareIdentityStatus.textContent = `Signing is unavailable here: ${identity.error}`;
      els.shareSign.disabled = true;
      els.shareSign.checked = false;
      els.createShareIdentity.hidden = false;
    } else if (identity?.keyId) {
      els.shareIdentityStatus.textContent = `Local key ${compactFingerprint(identity.keyId)} · private key stays in this browser.`;
      els.shareSign.disabled = libraryRecoveryRequired() || app.busy.has('share-folder') || app.busy.has('share-identity');
      els.shareSign.checked = Boolean(attribution.sign);
      els.createShareIdentity.hidden = true;
    } else {
      els.shareIdentityStatus.textContent = 'No local signing identity yet. Unsigned shared folders still work.';
      els.shareSign.disabled = true;
      els.shareSign.checked = false;
      els.createShareIdentity.hidden = false;
    }
    els.saveSharedFolder.textContent = identity?.keyId && attribution.sign ? 'Save signed ProgRSS file' : 'Save for ProgRSS';
    els.saveFolderOpml.disabled = current.feeds === 0;
    els.saveFolderOpml.textContent = current.feeds ? 'Save for another feed reader' : 'No feeds available for OPML';
    const canIncludeUpdates = current.updates > 0;
    els.siteIncludeUpdates.disabled = !canIncludeUpdates || libraryRecoveryRequired() || app.busy.has('share-folder');
    els.siteIncludeUpdates.checked = Boolean(canIncludeUpdates && attribution.includeUpdates);
    els.savePublicationSite.disabled = libraryRecoveryRequired() || app.busy.has('share-folder');
    els.savePublicationSite.textContent = attribution.includeUpdates && canIncludeUpdates ? 'Save website with recent updates' : 'Save ready-to-host website';
    els.saveFolderEdition.disabled = current.updates === 0 || libraryRecoveryRequired() || app.busy.has('share-folder');
    els.saveFolderEdition.textContent = current.updates ? 'Save recent updates as feed' : 'No recent updates to share';
  }

  async function loadSharingIdentity() {
    app.shareIdentity = {loading: true};
    renderShareFolder();
    try {
      const identity = await request('get-sharing-identity', {});
      app.shareIdentity = identity || null;
    } catch (error) {
      app.shareIdentity = {error: error.message};
    }
    renderShareFolder();
  }

  async function createSharingIdentity() {
    if (app.busy.has('share-identity')) return;
    busy('share-identity', true);
    const original = els.createShareIdentity.textContent;
    els.createShareIdentity.textContent = 'Creating local identity…';
    els.createShareIdentity.disabled = true;
    try {
      const identity = await request('create-sharing-identity', {});
      app.shareIdentity = identity;
      app.shareAttribution = {...app.shareAttribution, sign: true};
      renderShareFolder();
      setStatus(`Local signing identity created · ${compactFingerprint(identity.keyId)}.`, 'success');
    } catch (error) {
      setStatus(error.message, 'error');
      try {
        const identity = await request('get-sharing-identity', {});
        app.shareIdentity = identity || {error: error.message};
      } catch {
        app.shareIdentity = {error: error.message};
      }
      renderShareFolder();
    } finally {
      els.createShareIdentity.textContent = original;
      els.createShareIdentity.disabled = false;
      busy('share-identity', false);
    }
  }

  function openShareFolder() {
    const current = currentFolderShare();
    if (!current) return;
    app.shareFolder = current;
    app.shareAttribution = {
      curator: text(current.origin?.curator),
      note: text(current.origin?.note),
      updateUrl: canonicalAddress(current.origin?.updateUrl),
      sign: false,
      includeUpdates: false
    };
    app.shareIdentity = {loading: true};
    renderShareFolder();
    loadSharingIdentity();
    requestAnimationFrame(() => {
      els.shareFolderHeading.focus({preventScroll: true});
      els.shareFolderReview.scrollIntoView({block: 'nearest'});
    });
  }

  async function saveCurrentFolder(format) {
    const share = currentFolderShare();
    if (!share) return;
    const button = format === 'opml' ? els.saveFolderOpml : format === 'site' ? els.savePublicationSite : format === 'edition' ? els.saveFolderEdition : els.saveSharedFolder;
    const original = button.textContent;
    button.disabled = true;
    button.textContent = format === 'opml' ? 'Preparing OPML…' : format === 'site' ? 'Preparing website…' : format === 'edition' ? 'Preparing recent updates…' : 'Preparing shared folder…';
    busy('share-folder', true);
    try {
      const updateAddressInput = text(app.shareAttribution?.updateUrl).slice(0, 2048);
      const updateUrl = canonicalAddress(updateAddressInput);
      if ((format === 'bundle' || format === 'site') && updateAddressInput && !updateUrl) {
        throw new Error('Use a complete public http or https address for future copies, or leave that field empty.');
      }
      if (format === 'site') {
        if (!PublicationSite) throw new Error('The ready-to-host website builder is unavailable in this package.');
        if (!updateUrl) throw new Error('Add the public .json address where the hosted ProgRSS file will live.');
        PublicationSite.siteFileName(updateUrl);
      }
      const options = {
        curator: text(app.shareAttribution?.curator).slice(0, 80),
        note: text(app.shareAttribution?.note).slice(0, 280),
        updateUrl,
        sign: format !== 'opml' && Boolean(app.shareAttribution?.sign && app.shareIdentity?.keyId)
      };
      if (format === 'edition') {
        const edition = await request('export-folder-edition', {
          collectionId: share.collectionId,
          options: {
            curator: text(app.shareAttribution?.curator).slice(0, 80),
            note: text(app.shareAttribution?.note).slice(0, 280),
            limit: 100
          }
        });
        downloadText(edition.fileName || 'ProgRSS-recent-updates.json', edition.raw || '', edition.mime || 'application/feed+json');
        const summary = edition.summary || {};
        const omitted = Number(summary.omittedByLimit) > 0 ? ` · ${summary.omittedByLimit} older update${summary.omittedByLimit === 1 ? '' : 's'} left out` : '';
        setStatus(`Recent-updates feed prepared · ${summary.items || 0} update${summary.items === 1 ? '' : 's'} · ${summary.sources || 0} source${summary.sources === 1 ? '' : 's'} represented${omitted}. Full retained text and reading state stayed private.`, 'success');
        return;
      }
      const exportFormat = format === 'site' ? 'bundle' : format;
      const result = format === 'site'
        ? await request('export-publication-site', {
            collectionId: share.collectionId,
            options: {...options, includeUpdates: Boolean(app.shareAttribution?.includeUpdates && share.updates > 0), limit: 100}
          })
        : await request('export-shared-folder', {collectionId: share.collectionId, format: exportFormat, options});
      if (format === 'site') {
        const website = PublicationSite.build(result.bundle?.raw || '', {editionRaw: result.edition?.raw || ''});
        downloadBytes(website.fileName, website.bytes, website.mime);
        const summary = website.summary || {};
        const signed = summary.signed ? ' · signed ProgRSS copy' : ' · unsigned ProgRSS copy';
        const updates = summary.recentUpdatesIncluded ? ` · ${summary.updates || 0} recent update${summary.updates === 1 ? '' : 's'}` : '';
        setStatus(`Ready-to-host website prepared · ${summary.files || 0} files · ${summary.feeds || 0} feed${summary.feeds === 1 ? '' : 's'} · ${summary.pageWatches || 0} page watch${summary.pageWatches === 1 ? '' : 'es'}${updates}${signed}. No scripts, trackers, or automatic checks were added.`, 'success');
        return;
      }
      downloadText(result.fileName || (format === 'opml' ? 'ProgRSS-folder.opml' : 'ProgRSS-shared-folder.json'), result.raw || '', result.mime || (format === 'opml' ? 'text/x-opml' : 'application/json'));
      const summary = result.summary || {};
      const omitted = format === 'opml' && Number(summary.omittedPageWatches) > 0
        ? ` ${summary.omittedPageWatches} page watch${summary.omittedPageWatches === 1 ? ' was' : 'es were'} left out because OPML carries feeds.` : '';
      const sourceNotesOmitted = format === 'opml' && Number(summary.omittedSourceNoteCount) > 0
        ? ` ${summary.omittedSourceNoteCount} Source Note${summary.omittedSourceNoteCount === 1 ? ' was' : 's were'} left out because OPML has no ProgRSS placement-reason contract.` : '';
      const addressOmitted = format === 'opml' && summary.updateUrlOmitted
        ? ' The future-copy address was left out because OPML cannot carry ProgRSS update metadata.' : '';
      const attribution = summary.curator ? ` · shown as ${summary.curator}` : '';
      const signature = format === 'bundle' && summary.signed ? ` · signed ${summary.fingerprint || ''}` : (format === 'bundle' ? ' · unsigned' : '');
      const located = format === 'bundle' && summary.updateUrl ? ' · manual future-copy address included' : '';
      setStatus(format === 'opml'
        ? `OPML source list prepared · ${summary.feeds || 0} feed${summary.feeds === 1 ? '' : 's'}${attribution}.${omitted}${sourceNotesOmitted}${addressOmitted}`
        : `Shared folder prepared · ${summary.feeds || 0} feed${summary.feeds === 1 ? '' : 's'} · ${summary.pageWatches || 0} page watch${summary.pageWatches === 1 ? '' : 'es'}${attribution}${signature}${located}.`, 'success');
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      button.textContent = original;
      button.disabled = (format === 'opml' && share.feeds === 0) || (format === 'edition' && share.updates === 0);
      busy('share-folder', false);
      renderShareFolder();
    }
  }

  function canonicalAddress(raw) {
    try {
      const url = new URL(String(raw || ''));
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) return '';
      url.hash = '';
      return url.href;
    } catch {
      return '';
    }
  }

  function sourceAliasSet(source) {
    const aliases = new Set();
    const values = [
      source?.url,
      source?.declaredFeedUrl,
      ...(Array.isArray(source?.previousUrls) ? source.previousUrls : []),
      ...(Array.isArray(source?.aliasUrls) ? source.aliasUrls : [])
    ];
    for (const value of values) {
      const address = canonicalAddress(value);
      if (address) aliases.add(address);
    }
    return aliases;
  }

  function sourceRepairCandidates() {
    const sources = (app.state.sources || [])
      .filter(source => source?.type === 'rss' && !source.archivedAt)
      .sort((a, b) => text(a.title, a.id).localeCompare(text(b.title, b.id)));
    const pairs = [];
    let total = 0;
    for (let left = 0; left < sources.length; left++) {
      const leftAliases = sourceAliasSet(sources[left]);
      for (let right = left + 1; right < sources.length; right++) {
        const shared = [...sourceAliasSet(sources[right])].filter(address => leftAliases.has(address));
        if (!shared.length) continue;
        total++;
        if (pairs.length < 12) pairs.push({first: sources[left], second: sources[right], shared});
      }
    }
    return {pairs, total};
  }

  function renderFollowHandoff() {
    const handoff = app.followHandoff;
    els.followHandoff.hidden = !handoff;
    els.followHandoffFolder.replaceChildren();
    els.followHandoffFolder.hidden = true;
    if (!handoff) return;
    els.followHandoffHeading.textContent = handoff.heading;
    els.followHandoffMessage.textContent = handoff.message;
    els.showFollowedSource.dataset.sourceId = handoff.sourceId;
    const source = (app.state.sources || []).find(row => row.id === handoff.sourceId && !row.archivedAt);
    if (!source) return;
    const membership = folderMembershipForSource(source.id);
    if (!membership.available.length) return;
    const safeId = text(source.id).replace(/[^a-z0-9_-]/gi, '-').slice(0, 70) || 'followed';
    const label = h('label', {for: `follow-folder-${safeId}`, text: 'Optional: place in a folder'});
    const row = h('div', {class: 'folder-add-row'});
    const select = h('select', {id: `follow-folder-${safeId}`, class: 'folder-select'});
    membership.available.forEach(folder => select.append(h('option', {value: folder.id, text: folder.path})));
    const add = h('button', {class: 'secondary', type: 'button', text: 'Add to folder'});
    add.addEventListener('click', () => addSourceToFolder(source, select.value, add));
    row.append(select, add);
    els.followHandoffFolder.append(label, row, h('p', {class: 'field-help', text: 'Reading is ready now. Folder placement is optional.'}));
    els.followHandoffFolder.hidden = false;
  }

  function clearFolderUndo() {
    clearTimeout(app.folderUndoTimer);
    app.folderUndoTimer = 0;
    app.folderUndo = null;
    renderFolderUndo();
  }

  function renderFolderUndo() {
    const undo = app.folderUndo;
    els.folderUndoRow.hidden = !undo;
    if (!undo) return;
    els.folderUndoMessage.textContent = undo.kind === 'remove'
      ? `Removed ${undo.sourceTitle} from ${undo.folderPath}.`
      : `Added ${undo.sourceTitle} to ${undo.folderPath}.`;
  }

  function clearSourceNoteUndo() {
    clearTimeout(app.sourceNoteUndoTimer);
    app.sourceNoteUndoTimer = 0;
    app.sourceNoteUndo = null;
    renderSourceNoteUndo();
  }

  function renderSourceNoteUndo() {
    const undo = app.sourceNoteUndo;
    els.sourceNoteUndo.hidden = !undo;
    if (!undo) return;
    els.sourceNoteUndoMessage.textContent = undo.currentReason == null
      ? `Cleared the reason for ${undo.sourceTitle} in ${undo.folderPath}.`
      : `Changed the reason for ${undo.sourceTitle} in ${undo.folderPath}.`;
  }

  function armSourceNoteUndo(change) {
    clearTimeout(app.sourceNoteUndoTimer);
    app.sourceNoteUndo = change;
    renderSourceNoteUndo();
    app.sourceNoteUndoTimer = setTimeout(clearSourceNoteUndo, 12_000);
  }

  async function undoSourceNoteChange() {
    const undo = app.sourceNoteUndo;
    if (!undo) return;
    clearTimeout(app.sourceNoteUndoTimer);
    els.undoSourceNote.disabled = true;
    els.undoSourceNote.textContent = 'Restoring reason…';
    try {
      await request('undo-source-placement-reason', {
        sourceId: undo.sourceId,
        collectionId: undo.collectionId,
        expectedVersion: undo.expectedVersion,
        expectedRevision: undo.expectedRevision,
        expectedCurrentReason: undo.currentReason,
        previousReason: undo.previousReason
      });
      app.sourceNoteUndo = null;
      app.sourceNoteEditor = null;
      await loadState();
      setStatus('The earlier placement reason was restored.', 'success');
    } catch (error) {
      app.sourceNoteUndo = null;
      await loadState().catch(() => {});
      setStatus(error.message, 'error');
    } finally {
      els.undoSourceNote.disabled = false;
      els.undoSourceNote.textContent = 'Undo reason edit';
      renderSourceNoteUndo();
    }
  }

  function clearTextCleanupUndo() {
    clearTimeout(app.textCleanupUndoTimer);
    app.textCleanupUndoTimer = 0;
    app.textCleanupUndo = null;
    renderTextCleanupUndo();
    renderSources();
  }

  function armTextCleanupUndo(undo) {
    clearTimeout(app.textCleanupUndoTimer);
    app.textCleanupUndo = undo;
    app.textCleanupUndoTimer = setTimeout(clearTextCleanupUndo, 12_000);
    renderTextCleanupUndo();
    renderSources();
  }

  function renderTextCleanupUndo() {
    const undo = app.textCleanupUndo;
    els.textCleanupUndo.hidden = !undo;
    if (!undo) return;
    els.textCleanupUndoMessage.textContent = `${undo.count} read, unsaved update${undo.count === 1 ? '' : 's'} from ${undo.sourceTitle} · ${formatBytes(undo.bytes)}. Undo is available briefly in this open reader.`;
  }

  function relativeTime(raw) {
    const then = Date.parse(raw || '');
    if (!Number.isFinite(then)) return 'Recently';
    const seconds = Math.round((then - Date.now()) / 1000);
    const absolute = Math.abs(seconds);
    const formatter = new Intl.RelativeTimeFormat(undefined, {numeric: 'auto'});
    if (absolute < 60) return formatter.format(seconds, 'second');
    if (absolute < 3600) return formatter.format(Math.round(seconds / 60), 'minute');
    if (absolute < 86400) return formatter.format(Math.round(seconds / 3600), 'hour');
    if (absolute < 604800) return formatter.format(Math.round(seconds / 86400), 'day');
    return new Intl.DateTimeFormat(undefined, {
      month: 'short', day: 'numeric',
      year: new Date(then).getFullYear() === new Date().getFullYear() ? undefined : 'numeric'
    }).format(new Date(then));
  }

  function exactTime(raw) {
    const then = Date.parse(raw || '');
    if (!Number.isFinite(then)) return '';
    return new Intl.DateTimeFormat(undefined, {dateStyle: 'medium', timeStyle: 'short'}).format(new Date(then));
  }

  function nextCheck(source) {
    if (source.pendingRedirect) return 'Waiting for you to review its new address';
    if (source.permissionMissing) return 'Reconnect this site to keep checking it';
    if (source.type === 'page' && source.watchRepair) return 'Waiting for you to choose what to watch now';
    if (!source.enabled) return 'Paused';
    if (source.pulse?.needsReview) return 'Needs a quick review in the Workbench';
    if (!source.pulse?.nextAt) return 'Ready for its first refresh';
    const when = Date.parse(source.pulse.nextAt);
    if (!Number.isFinite(when) || when <= Date.now()) return 'Ready to refresh';
    return `Next check ${relativeTime(source.pulse.nextAt)}`;
  }

  function sourceFor(item) {
    return app.state.sources.find(source => source.id === item.sourceId) || null;
  }

  function libraryRecoveryRequired() {
    return app.state.libraryRecovery?.state === 'missing';
  }

  async function request(type, data = {}) {
    if (!api?.runtime?.sendMessage) throw new Error('Extension messaging is unavailable.');
    const response = await api.runtime.sendMessage({target: 'background', type, data});
    if (!response?.ok) {
      const error = new Error(response?.error || 'ProgRSS could not complete that action.');
      error.code = response?.code || 'FAILED';
      error.detail = response?.detail && typeof response.detail === 'object' ? response.detail : null;
      if (error.code === 'VAULT_WRITE_FAILED' && error.detail?.incident) {
        app.state.storageIncident = error.detail.incident;
        renderStorageIncident();
      }
      if (error.code === 'LIBRARY_RECOVERY_REQUIRED' && error.detail?.libraryRecovery) {
        app.state.libraryRecovery = error.detail.libraryRecovery;
        renderLibraryRecovery();
        renderItems();
        renderSources();
      }
      throw error;
    }
    return response.result;
  }

  function setStatus(message = '', tone = '') {
    clearTimeout(setStatus.timer);
    els.status.textContent = message;
    els.status.className = `status${tone ? ` ${tone}` : ''}`;
    els.status.hidden = !message;
    if (message && !['error', 'decision'].includes(tone)) setStatus.timer = setTimeout(() => { els.status.hidden = true; }, 6000);
  }

  function updateActionAvailability() {
    const recovery = libraryRecoveryRequired();
    const copyBusy = app.busy.has('backup-copy');
    const copyCheckBusy = app.busy.has('backup-check');
    const reminderBusy = app.busy.has('backup-reminder');
    const publicationBusy = app.busy.has('shared-folder-remote-check');
    const hasLibrary = Boolean(app.state.backupReminder?.meaningful);
    els.refreshAll.disabled = recovery || app.busy.has('refresh-all');
    els.markAll.disabled = recovery || app.busy.has('mark-all');
    els.useCurrent.disabled = recovery || app.busy.has('discover');
    els.focusAddress.disabled = recovery;
    els.chooseOpml.disabled = recovery || app.busy.has('opml');
    const nodeBusy = app.busy.has('node-pairing');
    els.focusNodePairing.disabled = nodeBusy;
    els.nodeInvitation.disabled = nodeBusy || Boolean(app.nodePairing);
    els.reviewNode.disabled = nodeBusy || Boolean(app.nodePairing);
    els.pairNode.disabled = nodeBusy || !app.nodeReview;
    els.cancelNodeReview.disabled = nodeBusy;
    els.checkNode.disabled = nodeBusy || !app.nodePairing;
    els.unpairNode.disabled = nodeBusy || !app.nodePairing;
    els.forgetNode.disabled = nodeBusy || !app.nodePairing;
    els.chooseSharedFolder.disabled = recovery || app.busy.has('shared-folder-import');
    els.address.disabled = recovery || app.busy.has('inspect');
    els.addressSubmit.disabled = recovery || app.busy.has('inspect');
    els.opmlFile.disabled = recovery || app.busy.has('opml');
    els.sharedFolderFile.disabled = recovery || app.busy.has('shared-folder-import');
    const sharingBusy = app.busy.has('share-folder') || app.busy.has('share-identity');
    els.shareFolderButton.disabled = recovery || sharingBusy;
    els.checkSharedFolderUpdate.disabled = recovery || publicationBusy;
    els.saveSharedFolder.disabled = recovery || sharingBusy;
    els.saveFolderOpml.disabled = recovery || sharingBusy || !app.shareFolder || (app.shareFolder.feeds || 0) === 0;
    els.shareCurator.disabled = recovery || sharingBusy;
    els.shareNote.disabled = recovery || sharingBusy;
    els.shareUpdateUrl.disabled = recovery || sharingBusy;
    if (recovery || sharingBusy || !app.shareIdentity?.keyId) els.shareSign.disabled = true;
    els.createShareIdentity.disabled = recovery || sharingBusy;
    els.exportLibrary.disabled = recovery || app.busy.has('transfer-export') || app.busy.has('transfer-import');
    els.backupFile.disabled = app.busy.has('transfer-import') || app.busy.has('transfer-export') || app.busy.has('library-recovery');
    els.undoLibraryMove.disabled = recovery || app.busy.has('transfer-undo');
    els.undoSourceRepair.disabled = recovery || app.busy.has('source-repair-undo');
    els.undoPageWatchRepair.disabled = recovery || app.busy.has('page-watch-repair-undo');
    els.undoSharedFolderUpdate.disabled = recovery || app.busy.has('shared-folder-update-undo');
    els.undoSourceNote.disabled = recovery || app.busy.has('source-note-undo');
    els.saveRecoveryCopy.disabled = recovery || app.busy.has('storage-recovery') || app.busy.has('storage-check');
    els.checkStorage.disabled = recovery || app.busy.has('storage-check') || app.busy.has('storage-recovery');
    els.restoreMissingLibrary.disabled = app.busy.has('library-recovery') || app.busy.has('transfer-import');
    els.acceptEmptyLibrary.disabled = app.busy.has('library-recovery') || app.busy.has('transfer-import');
    els.savePrivateCopy.disabled = recovery || !hasLibrary || copyBusy;
    els.checkPrivateCopy.disabled = recovery || !hasLibrary || copyCheckBusy;
    els.copyCheckFile.disabled = recovery || !hasLibrary || copyCheckBusy;
    els.snoozeBackupReminder.disabled = recovery || reminderBusy;
    els.disableBackupReminder.disabled = recovery || reminderBusy;
    els.enableBackupReminder.disabled = recovery || reminderBusy;
    els.markBackupCopyMissing.disabled = recovery || reminderBusy;
  }

  function busy(key, value) {
    if (value) app.busy.add(key); else app.busy.delete(key);
    els.refreshAll.setAttribute('aria-busy', String(app.busy.has('refresh-all')));
    updateActionAvailability();
  }

  async function loadState({announce = false} = {}) {
    const result = await request('get-state');
    app.state = result || {sources: [], collections: [], items: [], vault: {}};
    if (app.pageWatchRepairReview) {
      const current = (app.state.sources || []).find(source => source.id === app.pageWatchRepairReview.source?.id);
      if (!current?.watchRepair) { app.pageWatchRepairReview = null; app.pageWatchRepairChoice = ''; }
    }
    render();
    refreshStorageEstimate();
    if (announce) setStatus('Your reading is up to date.', 'success');
  }

  function setView(view, {focus = false} = {}) {
    if (!['today', 'sources', 'add'].includes(view)) return;
    if (view !== 'add' && app.discovery?.kind === 'exchange' && app.discovery.exchange) {
      releaseExchangeHostPermission(app.discovery.exchange).catch(() => {});
    }
    if (view !== 'add' && app.discovery?.kind === 'capture' && app.discovery.capture) {
      releaseCapturePermissions(app.discovery.capture).catch(() => {});
    }
    app.detailItemId = '';
    app.detailSequence = [];
    app.view = view;
    document.body.classList.remove('reading-detail');
    $$('.view').forEach(section => { section.hidden = section.id !== `view-${view}`; });
    $$('[data-view]').forEach(button => {
      const current = button.dataset.view === view;
      if (current) button.setAttribute('aria-current', 'page');
      else button.removeAttribute('aria-current');
    });
    if (focus) $(`#${view === 'today' ? 'today' : view}-heading`)?.focus();
    try { api.storage.local.set({primaryView: view}); } catch {}
  }

  function setFilter(filter) {
    if (!['unread', 'all', 'starred'].includes(filter)) return;
    app.filter = filter;
    $$('[data-filter]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.filter === filter)));
    renderItems();
    try { api.storage.local.set({readingFilter: filter}); } catch {}
  }

  function setSearch(value, {focus = false} = {}) {
    app.search = String(value || '').slice(0, 180);
    if (els.readingSearch.value !== app.search) els.readingSearch.value = app.search;
    renderItems();
    if (focus) els.readingSearch.focus();
  }

  function sortedItems() {
    return [...(app.state.items || [])].sort((a, b) => {
      const left = Date.parse(a.published || a.observedAt || '') || 0;
      const right = Date.parse(b.published || b.observedAt || '') || 0;
      return right - left;
    });
  }

  function matchingItems() {
    const terms = normalized(app.search).split(' ').filter(Boolean).slice(0, 12);
    return itemsInSelectedFolder().filter(item => {
      if (app.filter === 'unread' && item.readAt) return false;
      if (app.filter === 'starred' && !item.starred) return false;
      if (!terms.length) return true;
      const source = sourceFor(item);
      const change = pageChange(item);
      const haystack = normalized(`${source?.title || ''} ${item.title || ''} ${item.summary || ''} ${item.body || ''} ${change?.before || ''} ${change?.after || ''} ${change?.removed || ''} ${change?.added || ''}`);
      return terms.every(term => haystack.includes(term));
    });
  }

  function pageChange(item) {
    const change = item?.change;
    if (!change || typeof change !== 'object' || Array.isArray(change) || change.schema !== PAGE_CHANGE_SCHEMA) return null;
    if (!['entry-added', 'entry-changed', 'entry-removed', 'text-changed'].includes(change.kind)) return null;
    if (!['cards', 'region'].includes(change.mode)) return null;
    return change;
  }

  function wordCountPhrase(count, noun = 'word') {
    const value = Math.max(0, Math.floor(Number(count) || 0));
    return `${value} ${noun}${value === 1 ? '' : 's'}`;
  }

  function pageChangeReason(change) {
    if (!change) return 'This older page-watch alert does not contain a before-and-after explanation.';
    if (change.kind === 'entry-added') return 'A new entry appeared in the repeated list this watch follows.';
    if (change.kind === 'entry-removed') return 'An entry that appeared in the repeated list was no longer present.';
    const added = Math.max(0, Math.floor(Number(change.addedWords) || 0));
    const removed = Math.max(0, Math.floor(Number(change.removedWords) || 0));
    if (!added && !removed) return change.kind === 'entry-changed'
      ? 'Punctuation or symbols changed in an entry already in the watched list.'
      : 'Punctuation or symbols changed in the watched main text.';
    const amount = added && removed
      ? `${wordCountPhrase(added)} added and ${wordCountPhrase(removed)} removed`
      : added ? `${wordCountPhrase(added)} added` : `${wordCountPhrase(removed)} removed`;
    return change.kind === 'entry-changed'
      ? `The wording of an entry already in the watched list changed: ${amount}.`
      : `The watched main text changed: ${amount}.`;
  }

  function pageChangePolicy(change) {
    if (!change) return '';
    const parts = [];
    const threshold = Math.max(0, Math.floor(Number(change.threshold) || 0));
    if (threshold > 1) parts.push(`Changes smaller than ${threshold} characters are ignored.`);
    parts.push(change.ignoreNumbers ? 'Changes made only to numbers are ignored.' : 'Number changes are included.');
    return parts.join(' ');
  }

  function renderPageChangeDetail(item, source) {
    const change = pageChange(item);
    els.detailNote.textContent = pageChangeReason(change);
    els.detailBody.replaceChildren();
    els.detailBody.classList.remove('empty');
    els.detailBody.classList.add('page-change-detail');

    const explanation = h('section', {class: 'change-explanation'});
    explanation.append(h('h3', {text: 'Why ProgRSS noticed this'}));
    const summary = text(change?.summary || item.summary);
    if (summary) explanation.append(h('p', {class: 'change-summary', text: summary}));
    const policy = pageChangePolicy(change);
    if (policy) explanation.append(h('p', {class: 'change-policy', text: policy}));
    els.detailBody.append(explanation);

    const before = text(change?.before || change?.removed);
    const after = text(change?.after || change?.added);
    if (before || after) {
      const comparison = h('div', {class: 'change-comparison'});
      if (before) {
        const panel = h('section', {class: 'change-panel change-before'});
        panel.append(h('h3', {text: 'Before'}), markNaturalText(h('del', {text: before}), languageFor(item, 'summary', source)));
        comparison.append(panel);
      }
      if (after) {
        const panel = h('section', {class: 'change-panel change-after'});
        panel.append(h('h3', {text: 'Now'}), markNaturalText(h('ins', {text: after}), languageFor(item, 'summary', source)));
        comparison.append(panel);
      }
      els.detailBody.append(comparison);
    } else {
      els.detailBody.append(h('p', {class: 'change-legacy', text: 'This alert was created before ProgRSS kept readable before-and-after context. Open the watched page to see its current state.'}));
    }
    els.detailOpen.textContent = 'Open watched page';
  }

  function emptyState(kind) {
    const wrapper = h('div', {class: 'empty-state'});
    wrapper.append(h('span', {class: 'empty-icon', text: kind === 'fresh' ? '✓' : kind === 'search' ? '⌕' : '☕', 'aria-hidden': 'true'}));
    if (kind === 'search') {
      wrapper.append(h('h3', {text: 'No matching updates'}));
      wrapper.append(h('p', {text: 'Try fewer words, or search Everything instead of only this view.'}));
      const button = h('button', {class: 'secondary', type: 'button', text: 'Clear search'});
      button.addEventListener('click', () => setSearch('', {focus: true}));
      wrapper.append(button);
    } else if (kind === 'fresh') {
      wrapper.append(h('h3', {text: 'You’re caught up'}));
      wrapper.append(h('p', {text: 'Nothing unread. Saved stories and older updates are still under Everything.'}));
      const button = h('button', {class: 'secondary', type: 'button', text: 'Show everything'});
      button.addEventListener('click', () => setFilter('all'));
      wrapper.append(button);
    } else if (kind === 'folder') {
      wrapper.append(h('h3', {text: 'Nothing in this folder yet'}));
      wrapper.append(h('p', {text: 'Choose All folders to see the rest of your reading.'}));
      const button = h('button', {class: 'secondary', type: 'button', text: 'Show all folders'});
      button.addEventListener('click', () => setFolder('all'));
      wrapper.append(button);
    } else if (libraryRecoveryRequired()) {
      wrapper.append(h('h3', {text: 'Your reading library is missing here'}));
      wrapper.append(h('p', {text: 'Use the recovery choices above. ProgRSS will not rebuild your reading history from websites.'}));
      const review = h('button', {class: 'secondary', type: 'button', text: 'Review recovery choices'});
      review.addEventListener('click', () => {
        els.libraryRecovery.scrollIntoView({block: 'start'});
        els.restoreMissingLibrary.focus();
      });
      wrapper.append(review);
    } else if (!(app.state.sources || []).length) {
      wrapper.append(h('h3', {text: 'Start with something you already know'}));
      wrapper.append(h('p', {text: 'No setup tour. Use the page beside ProgRSS, paste an address, or bring subscriptions from another reader.'}));
      const choices = h('div', {class: 'empty-start-actions'});
      const current = h('button', {class: 'primary', type: 'button', text: 'Use this page'});
      current.addEventListener('click', startFromCurrentPage);
      const paste = h('button', {class: 'secondary', type: 'button', text: 'Paste an address'});
      paste.addEventListener('click', focusAddressEntry);
      const move = h('button', {class: 'secondary', type: 'button', text: 'Move from another reader'});
      move.addEventListener('click', chooseOpmlFile);
      choices.append(current, paste, move);
      wrapper.append(choices);
    } else {
      wrapper.append(h('h3', {text: app.filter === 'starred' ? 'Nothing saved yet' : 'No updates here yet'}));
      wrapper.append(h('p', {text: app.filter === 'starred' ? 'Use Save on an update to keep it close.' : 'Refresh your sources, or enjoy the calm.'}));
    }
    return wrapper;
  }

  function itemCard(item, index) {
    const source = sourceFor(item);
    const card = h('article', {class: `item-card${item.readAt ? '' : ' unread'}`, dataset: {itemId: item.id}});
    const meta = h('div', {class: 'item-meta'});
    meta.append(markNaturalText(h('span', {text: text(source?.title, 'Unknown source')}), source?.titleLanguage || source?.language));
    meta.append(h('span', {class: 'dot', 'aria-hidden': 'true'}));
    meta.append(h('time', {
      text: relativeTime(item.published || item.observedAt),
      datetime: item.published || item.observedAt || '',
      title: exactTime(item.published || item.observedAt)
    }));
    card.append(meta);

    const heading = h('h3', {class: 'item-title'});
    if (item.url) {
      const link = h('a', {
        href: item.url, target: '_blank', rel: 'noreferrer',
        text: text(item.title, 'Untitled update'), dataset: {itemLink: String(index)}
      });
      link.addEventListener('click', () => {
        if (!item.readAt) changeItem(item.id, {read: true}, {quiet: true});
      });
      markNaturalText(link, languageFor(item, 'title', source));
      heading.append(link);
    } else {
      heading.textContent = text(item.title, 'Untitled update');
      markNaturalText(heading, languageFor(item, 'title', source));
    }
    card.append(heading);
    if (text(item.summary)) card.append(markNaturalText(h('p', {class: 'item-summary', text: text(item.summary)}), languageFor(item, 'summary', source)));

    const actions = h('div', {class: 'item-actions'});
    const detailButton = h('button', {class: 'secondary read-here', type: 'button', text: source?.type === 'page' ? 'See change' : 'Read here', dataset: {openDetail: item.id}});
    detailButton.addEventListener('click', () => openItemDetail(item.id, detailButton));
    const readButton = h('button', {class: 'quiet-button', type: 'button', text: item.readAt ? 'Mark unread' : 'Mark read'});
    readButton.addEventListener('click', () => changeItem(item.id, {read: !item.readAt}));
    const saveButton = h('button', {
      class: 'quiet-button save-button', type: 'button',
      ariaLabel: item.starred ? 'Remove from saved' : 'Save this update',
      ariaPressed: Boolean(item.starred), text: item.starred ? 'Saved' : 'Save'
    });
    saveButton.addEventListener('click', () => changeItem(item.id, {starred: !item.starred}));
    actions.append(detailButton, readButton, saveButton);
    card.append(actions);
    return card;
  }

  function detailItem() {
    return (app.state.items || []).find(item => item.id === app.detailItemId) || null;
  }

  function detailBodyText(item) {
    return String(item?.body || item?.summary || '').replace(/\r\n?/g, '\n').trim().slice(0, 12_000);
  }

  function renderDetail() {
    if (app.view !== 'detail') return;
    const item = detailItem();
    if (!item) {
      closeItemDetail({focus: false});
      setStatus('That update is no longer in this library.', 'error');
      return;
    }
    const source = sourceFor(item);
    const stamp = item.published || item.observedAt || '';
    els.detailSource.textContent = text(source?.title, 'Unknown source');
    markNaturalText(els.detailSource, source?.titleLanguage || source?.language);
    els.detailTime.textContent = relativeTime(stamp);
    els.detailTime.dateTime = stamp;
    els.detailTime.title = exactTime(stamp);
    els.detailHeading.textContent = text(item.title, 'Untitled update');
    markNaturalText(els.detailHeading, languageFor(item, 'title', source));
    els.detailBody.classList.remove('page-change-detail');
    if (source?.type === 'page') {
      renderPageChangeDetail(item, source);
      els.detailRead.textContent = item.readAt ? 'Mark unread' : 'Mark read';
      els.detailSave.textContent = item.starred ? 'Saved' : 'Save';
      els.detailSave.setAttribute('aria-pressed', String(Boolean(item.starred)));
      els.detailSave.setAttribute('aria-label', item.starred ? 'Remove from saved' : 'Save this change');
      els.detailOpen.hidden = !item.url;
      if (item.url) els.detailOpen.href = item.url;
      const index = app.detailSequence.indexOf(item.id);
      els.detailNewer.disabled = index <= 0;
      els.detailOlder.disabled = index < 0 || index >= app.detailSequence.length - 1;
      return;
    }
    els.detailOpen.textContent = 'Open original';
    const body = detailBodyText(item);
    const excerptOnly = Boolean(item.bodyIsSummary) || !item.body;
    els.detailNote.textContent = item.bodyOmitted
      ? (item.url ? 'This source is set to keep summaries only. Open the original for the full page.' : 'This source is set to keep summaries only, and no original address was supplied.')
      : excerptOnly
        ? (item.url ? 'This feed supplied an excerpt. Open the original for the full page.' : 'This feed supplied an excerpt and no original address.')
        : 'Text supplied by this feed. Page scripts, frames, and remote images are not loaded here.';
    els.detailBody.replaceChildren();
    const bodyLanguage = languageFor(item, 'body', source);
    const paragraphs = body ? body.split(/\n{2,}/).map(value => value.trim()).filter(Boolean) : [];
    if (paragraphs.length) paragraphs.forEach(value => els.detailBody.append(markNaturalText(h('p', {text: value}), bodyLanguage)));
    else els.detailBody.append(h('p', {text: 'This feed did not supply readable text for this update.'}));
    els.detailBody.classList.toggle('empty', !body);
    els.detailRead.textContent = item.readAt ? 'Mark unread' : 'Mark read';
    els.detailSave.textContent = item.starred ? 'Saved' : 'Save';
    els.detailSave.setAttribute('aria-pressed', String(Boolean(item.starred)));
    els.detailSave.setAttribute('aria-label', item.starred ? 'Remove from saved' : 'Save this update');
    els.detailOpen.hidden = !item.url;
    if (item.url) els.detailOpen.href = item.url;
    const index = app.detailSequence.indexOf(item.id);
    els.detailNewer.disabled = index <= 0;
    els.detailOlder.disabled = index < 0 || index >= app.detailSequence.length - 1;
  }

  function openItemDetail(itemId, trigger = null, {preserveSequence = false} = {}) {
    const item = (app.state.items || []).find(row => row.id === itemId);
    if (!item) return;
    if (!preserveSequence) app.detailSequence = matchingItems().map(row => row.id);
    if (!app.detailSequence.includes(itemId)) app.detailSequence.push(itemId);
    app.detailItemId = itemId;
    app.detailReturnFocusId = trigger?.closest?.('.item-card')?.dataset?.itemId || itemId;
    app.view = 'detail';
    document.body.classList.add('reading-detail');
    $$('.view').forEach(section => { section.hidden = section.id !== 'view-detail'; });
    $$('[data-view]').forEach(button => {
      if (button.dataset.view === 'today') button.setAttribute('aria-current', 'page');
      else button.removeAttribute('aria-current');
    });
    renderDetail();
    requestAnimationFrame(() => {
      els.detailHeading.focus();
      window.scrollTo({top: 0, behavior: 'auto'});
    });
  }

  function closeItemDetail({focus = true} = {}) {
    const returnId = app.detailReturnFocusId;
    setView('today');
    renderItems();
    if (!focus) return;
    requestAnimationFrame(() => {
      const card = returnId ? $(`.item-card[data-item-id="${CSS.escape(returnId)}"]`) : null;
      const target = card?.querySelector('[data-open-detail]') || $('#today-heading');
      target?.focus();
      card?.scrollIntoView({block: 'nearest'});
    });
  }

  function moveDetail(offset) {
    const index = app.detailSequence.indexOf(app.detailItemId);
    const targetId = app.detailSequence[index + offset];
    if (targetId) openItemDetail(targetId, null, {preserveSequence: true});
  }

  function renderItems() {
    const allItems = app.state.items || [];
    const globalUnread = allItems.filter(item => !item.readAt).length;
    const scopedItems = itemsInSelectedFolder();
    const scopedUnread = scopedItems.filter(item => !item.readAt).length;
    const folder = selectedFolder();
    els.unreadCount.textContent = globalUnread > 99 ? '99+' : String(globalUnread);
    els.unreadCount.hidden = globalUnread === 0;
    const matched = matchingItems();
    const visible = matched.slice(0, MAX_READING_RESULTS);
    const query = text(app.search);
    els.clearSearch.hidden = !query;
    els.markAll.textContent = query ? 'Mark results read' : folder.id === 'all' ? 'Mark all read' : 'Mark folder read';
    const unreadInScope = query ? matched.filter(item => !item.readAt).length : scopedUnread;
    els.markAll.hidden = unreadInScope === 0;

    if (query) {
      const suffix = folder.id === 'all' ? '' : ` in ${folder.label}`;
      const label = `${matched.length} result${matched.length === 1 ? '' : 's'} for “${query}”${suffix}`;
      els.todaySummary.textContent = label;
      els.searchSummary.textContent = label;
    } else {
      els.searchSummary.textContent = '';
      els.todaySummary.textContent = folder.id === 'all'
        ? (globalUnread ? `${globalUnread} unread update${globalUnread === 1 ? '' : 's'}` : allItems.length ? 'All caught up' : 'Your reading will appear here.')
        : (scopedUnread ? `${scopedUnread} unread in ${folder.label}` : scopedItems.length ? `${folder.label} is caught up` : `No reading in ${folder.label}`);
    }

    els.itemList.replaceChildren();
    els.itemList.classList.toggle('has-items', visible.length > 0);
    if (!visible.length) {
      const kind = query ? 'search' : (folder.id !== 'all' && scopedItems.length === 0 ? 'folder' : (app.filter === 'unread' && scopedItems.length ? 'fresh' : 'empty'));
      els.itemList.append(emptyState(kind));
    } else {
      visible.forEach((item, index) => els.itemList.append(itemCard(item, index)));
    }
    els.itemList.setAttribute('aria-busy', 'false');
  }

  function sourceOutcome(source) {
    if (source.pendingRedirect) return {label: 'Moved', className: 'error'};
    if (source.permissionMissing && source.enabled) return {label: 'Reconnect', className: 'error'};
    if (source.type === 'page' && source.watchRepair) return {label: 'Repair watch', className: 'error'};
    if (!source.enabled) return {label: 'Paused', className: 'paused'};
    if (source.type === 'page' && source.watchStability) return {label: 'Checking again', className: ''};
    if (source.lastError) return {label: 'Needs attention', className: 'error'};
    if (source.lastOutcome === 'changed') {
      const count = Math.max(0, Math.floor(Number(source.lastItems) || 0));
      return {label: source.type === 'page' ? (count ? `${count} change${count === 1 ? '' : 's'}` : 'Changed') : (count ? `${count} new` : 'Updated'), className: ''};
    }
    if (source.lastOutcome === 'baseline') return {label: source.type === 'page' ? 'Watching' : 'Ready', className: ''};
    return {label: 'Following', className: ''};
  }

  function latestItemAt(sourceId) {
    let result = '';
    let newest = 0;
    for (const item of app.state.items || []) {
      if (item.sourceId !== sourceId) continue;
      const raw = item.observedAt || item.published || '';
      const stamp = Date.parse(raw) || 0;
      if (stamp > newest) { newest = stamp; result = raw; }
    }
    return result;
  }

  function activityTime(raw, emptyText) {
    if (!Date.parse(raw || '')) return h('span', {text: emptyText});
    return h('time', {datetime: raw, title: exactTime(raw), text: relativeTime(raw)});
  }

  function activityRow(label, value) {
    const row = h('div', {class: 'activity-row'});
    row.append(h('dt', {text: label}), h('dd', {}, value));
    return row;
  }

  function addressRow(label, value) {
    const row = h('div', {class: 'address-line'});
    row.append(h('span', {text: label}), h('code', {text: value}));
    return row;
  }

  function pageWatchProposalChoice(proposal, selected) {
    const label = h('label', {class: `watch-repair-choice${selected ? ' selected' : ''}`});
    const radio = h('input', {
      type: 'radio', name: 'page-watch-repair-choice', value: proposal.token,
      checked: selected
    });
    const body = h('span', {class: 'watch-repair-choice-body'});
    body.append(
      h('strong', {text: text(proposal.title, proposal.mode === 'cards' ? 'Watch repeated entries' : 'Watch page text')}),
      h('span', {class: 'watch-repair-description', text: text(proposal.description)})
    );
    if (proposal.mode === 'cards') {
      body.append(h('span', {class: 'watch-repair-count', text: `${Math.max(0, Number(proposal.count) || 0)} readable entr${Number(proposal.count) === 1 ? 'y' : 'ies'} found` }));
      const examples = (proposal.examples || []).map(value => text(value)).filter(Boolean);
      if (examples.length) {
        const list = h('ul', {class: 'watch-repair-examples'});
        examples.forEach(value => list.append(h('li', {text: value})));
        body.append(list);
      }
    } else if (text(proposal.preview)) {
      body.append(h('span', {class: 'watch-repair-preview', text: text(proposal.preview)}));
    }
    radio.addEventListener('change', () => {
      app.pageWatchRepairChoice = proposal.token;
      renderSources();
      requestAnimationFrame(() => document.querySelector(`.source-card[data-source-id="${CSS.escape(app.pageWatchRepairReview?.source?.id || '')}"] .watch-repair-commit`)?.focus());
    });
    label.append(radio, body);
    return label;
  }

  async function beginPageWatchRepair(source, button) {
    // Optional host permission must be the first awaited operation in this user action.
    if (!await askPermission(source.url, 'The watch was not inspected. Its current rule and earlier alerts were kept.')) return;
    const original = button.textContent;
    button.disabled = true;
    button.textContent = 'Inspecting page…';
    try {
      const review = await request('preview-page-watch-repair', {sourceId: source.id});
      app.pageWatchRepairReview = review;
      app.pageWatchRepairChoice = review.proposals?.[0]?.token || '';
      renderSources();
      requestAnimationFrame(() => {
        const heading = document.querySelector(`.source-card[data-source-id="${CSS.escape(source.id)}"] .watch-repair-heading`);
        heading?.focus({preventScroll: true});
        heading?.scrollIntoView({block: 'nearest'});
      });
      setStatus('Nothing changed. Choose a section only after the examples look right.', 'success');
    } catch (error) {
      await loadState().catch(() => {});
      setStatus(error.message, 'error');
      button.disabled = false;
      button.textContent = original;
    }
  }

  function cancelPageWatchRepair(sourceId) {
    if (app.pageWatchRepairReview?.source?.id !== sourceId) return;
    app.pageWatchRepairReview = null;
    app.pageWatchRepairChoice = '';
    renderSources();
    requestAnimationFrame(() => document.querySelector(`.source-card[data-source-id="${CSS.escape(sourceId)}"] .watch-repair-start`)?.focus());
    setStatus('The current watch was kept. ProgRSS will not check it again until it is repaired.');
  }

  async function commitPageWatchRepair(source, button) {
    const review = app.pageWatchRepairReview;
    const proposalToken = app.pageWatchRepairChoice;
    if (!review || review.source?.id !== source.id || !proposalToken) return;
    // Recheck site authority from the visible commit action before refetching.
    if (!await askPermission(source.url, 'The watch was not repaired. Its current rule, baseline, and earlier alerts were kept.')) return;
    const original = button.textContent;
    button.disabled = true;
    button.textContent = 'Checking and repairing…';
    try {
      const result = await request('repair-page-watch', {
        sourceId: source.id,
        reviewedRevision: review.reviewedRevision,
        proposalToken
      });
      app.pageWatchRepairReview = null;
      app.pageWatchRepairChoice = '';
      await loadState();
      setStatus(`${text(result.title, 'Page watch')} is watching the selected section from a fresh baseline. Earlier alerts were kept.`, 'success');
    } catch (error) {
      app.pageWatchRepairReview = null;
      app.pageWatchRepairChoice = '';
      await loadState().catch(() => {});
      setStatus(error.message, 'error');
      button.disabled = false;
      button.textContent = original;
    }
  }

  function pageWatchRepairDecision(source) {
    const review = app.pageWatchRepairReview?.source?.id === source.id ? app.pageWatchRepairReview : null;
    const region = h('section', {class: 'source-decision watch-repair-decision', 'aria-labelledby': `watch-repair-${source.id}`});
    const heading = h('h4', {id: `watch-repair-${source.id}`, class: 'watch-repair-heading', tabindex: review ? '-1' : undefined, text: review ? 'Choose what to watch now' : 'This page watch needs a new section'});
    region.append(heading);
    if (!review) {
      region.append(
        h('p', {text: text(source.watchRepair?.message, 'ProgRSS can no longer trust the saved page section. It stopped checking before creating misleading alerts.')}),
        h('p', {class: 'watch-repair-preserves', text: 'Earlier alerts, read and saved state, and folder placement will stay unchanged.'})
      );
      const start = h('button', {class: 'primary wide watch-repair-start', type: 'button', text: 'Find what to watch now'});
      start.addEventListener('click', () => beginPageWatchRepair(source, start));
      region.append(start);
      return region;
    }
    region.append(
      h('p', {text: 'ProgRSS found these readable sections on the page now. Review the examples; selector details stay in Advanced Workbench.'}),
      h('p', {class: 'watch-repair-preserves', text: 'Using a section creates a fresh baseline. It will not invent a change alert or rewrite earlier alerts.'})
    );
    const choices = h('fieldset', {class: 'watch-repair-choices'});
    choices.append(h('legend', {text: 'What should ProgRSS watch?'}));
    (review.proposals || []).forEach(proposal => choices.append(pageWatchProposalChoice(proposal, proposal.token === app.pageWatchRepairChoice)));
    region.append(choices);
    if ((review.warnings || []).length) {
      const warning = h('p', {class: 'watch-repair-warning', text: review.warnings.join(' ')});
      region.append(warning);
    }
    const actions = h('div', {class: 'watch-repair-actions'});
    const commit = h('button', {class: 'primary watch-repair-commit', type: 'button', text: 'Use this section', disabled: !app.pageWatchRepairChoice});
    const cancel = h('button', {class: 'quiet-button', type: 'button', text: 'Keep current watch'});
    commit.addEventListener('click', () => commitPageWatchRepair(source, commit));
    cancel.addEventListener('click', () => cancelPageWatchRepair(source.id));
    actions.append(commit, cancel);
    region.append(actions);
    return region;
  }

  function pageWatchStabilityNotice(source) {
    const pending = source.watchStability || {};
    const region = h('section', {class: 'source-decision watch-stability-decision', 'aria-labelledby': `watch-stability-${source.id}`});
    region.append(
      h('h4', {id: `watch-stability-${source.id}`, text: 'ProgRSS is checking one unusual result'}),
      h('p', {text: text(pending.message, 'This page looked unusually different once. ProgRSS held that result until the next check.')}),
      h('p', {class: 'watch-stability-preserves', text: 'No page-change alert was created. Check again now or let the next scheduled check confirm or discard it.'})
    );
    return region;
  }

  function sourceDecision(source) {
    if (source.pendingRedirect) {
      const move = source.pendingRedirect;
      const region = h('section', {class: 'source-decision', 'aria-labelledby': `move-${source.id}`});
      region.append(h('h4', {id: `move-${source.id}`, text: 'Review this source’s new address'}));
      region.append(h('p', {text: `It now points to ${text(move.destinationHost, 'another site')}. ProgRSS stopped before contacting that site.`}));
      const addresses = h('div', {class: 'address-pair'});
      addresses.append(addressRow('Old', text(move.from || source.url)), addressRow('New', text(move.to)));
      region.append(addresses);
      const follow = h('button', {class: 'primary wide', type: 'button', text: `Follow at ${text(move.destinationHost, 'new site')}`});
      follow.addEventListener('click', () => acceptSourceMove(source, follow));
      region.append(follow);
      return region;
    }
    if (source.permissionMissing && source.enabled) {
      const region = h('section', {class: 'source-decision', 'aria-labelledby': `reconnect-${source.id}`});
      region.append(h('h4', {id: `reconnect-${source.id}`, text: 'Reconnect this source'}));
      region.append(h('p', {text: source.permissionMissingReason === 'transfer'
        ? 'Site access stays with the other browser. ProgRSS will not check this source here until you reconnect it.'
        : 'Site access was removed. ProgRSS will not check this source again until you reconnect it.'}));
      const reconnect = h('button', {class: 'primary wide', type: 'button', text: 'Reconnect and check now'});
      reconnect.addEventListener('click', () => reconnectSource(source, reconnect));
      region.append(reconnect);
      return region;
    }
    if (source.type === 'page' && source.watchRepair) return pageWatchRepairDecision(source);
    if (source.type === 'page' && source.watchStability) return pageWatchStabilityNotice(source);
    return null;
  }

  function readableList(values) {
    const clean = values.map(value => text(value)).filter(Boolean);
    if (!clean.length) return '';
    try { return new Intl.ListFormat(undefined, {style: 'long', type: 'conjunction'}).format(clean); }
    catch { return clean.join(', '); }
  }

  function armFolderUndo(change) {
    clearTimeout(app.folderUndoTimer);
    app.folderUndo = change;
    renderFolderUndo();
    app.folderUndoTimer = setTimeout(clearFolderUndo, 12_000);
  }

  async function addSourceToFolder(source, collectionId, button) {
    button.disabled = true;
    const original = button.textContent;
    button.textContent = 'Adding…';
    const switchedFromUnfiled = app.folder === 'unfiled';
    try {
      const result = await request('add-source-to-folder', {sourceId: source.id, collectionId});
      if (!result.added) {
        if (result.reason === 'inherited') setStatus(`${text(source.title, 'This source')} already appears in ${result.folderPath} through a nested folder.`, 'success');
        else setStatus(`${text(source.title, 'This source')} is already directly in ${result.folderPath}.`, 'success');
        await loadState();
        return;
      }
      if (switchedFromUnfiled) {
        app.folder = result.collectionId;
        try { await api.storage.local.set({libraryFolder: app.folder}); } catch {}
      }
      await loadState();
      armFolderUndo({
        kind: 'add',
        sourceId: source.id,
        sourceTitle: text(source.title, 'Source'),
        collectionId: result.collectionId,
        folderPath: result.folderPath,
        expectedVersion: result.folderVersion,
        expectedRevision: result.expectedRevision,
        switchedFromUnfiled
      });
      const inherited = readableList((result.membership?.inherited || []).map(row => row.path));
      setStatus(inherited
        ? `Added to ${result.folderPath}. It also appears in ${inherited}.`
        : `Added to ${result.folderPath}.`, 'success');
    } catch (error) {
      await loadState().catch(() => {});
      setStatus(error.message, 'error');
      button.disabled = false;
      button.textContent = original;
    }
  }

  async function removeSourceFromFolder(source, folder, button) {
    button.disabled = true;
    const original = button.textContent;
    button.textContent = 'Removing…';
    try {
      const member = (folder?.collection?.members || []).find(row => row?.kind === 'source' && text(row.id) === text(source.id));
      if (!member) throw new Error('That direct folder relationship is no longer available. Review the latest folder state.');
      const result = await request('remove-source-from-folder', {
        sourceId: source.id,
        collectionId: folder.id,
        expectedVersion: Math.max(1, Math.round(Number(folder.collection.version) || 1)),
        expectedRevision: Number.isSafeInteger(app.state?.revision) ? app.state.revision : 0,
        expectedReason: Object.prototype.hasOwnProperty.call(member, 'reason') ? String(member.reason) : null
      });
      await loadState();
      armFolderUndo({
        kind: 'remove',
        sourceId: source.id,
        sourceTitle: text(source.title, 'Source'),
        collectionId: result.collectionId,
        folderPath: result.folderPath,
        expectedVersion: result.folderVersion,
        expectedRevision: result.expectedRevision,
        removedMember: result.removedMember,
        removedIndex: result.removedIndex,
        switchedFromUnfiled: false
      });
      const inherited = readableList((result.membership?.inherited || []).map(row => row.path));
      setStatus(inherited
        ? `Removed the direct placement from ${result.folderPath}. It still appears in ${inherited} through a nested folder.`
        : `Removed from ${result.folderPath}.`, 'success');
    } catch (error) {
      await loadState().catch(() => {});
      setStatus(error.message, 'error');
      button.disabled = false;
      button.textContent = original;
    }
  }

  async function undoFolderChange() {
    const undo = app.folderUndo;
    if (!undo) return;
    clearTimeout(app.folderUndoTimer);
    els.undoFolderChange.disabled = true;
    try {
      await request(undo.kind === 'remove' ? 'undo-source-folder-remove' : 'undo-source-folder-add', {
        sourceId: undo.sourceId,
        collectionId: undo.collectionId,
        expectedVersion: undo.expectedVersion,
        expectedRevision: undo.expectedRevision,
        ...(undo.kind === 'remove' ? {
          removedMember: undo.removedMember,
          removedIndex: undo.removedIndex
        } : {})
      });
      if (undo.switchedFromUnfiled) {
        app.folder = 'unfiled';
        try { await api.storage.local.set({libraryFolder: app.folder}); } catch {}
      }
      app.folderUndo = null;
      await loadState();
      setStatus(undo.kind === 'remove' ? 'Folder removal undone.' : 'Folder placement undone.', 'success');
    } catch (error) {
      app.folderUndo = null;
      await loadState().catch(() => {});
      setStatus(error.message, 'error');
    } finally {
      els.undoFolderChange.disabled = false;
      renderFolderUndo();
    }
  }

  function sourceNotePlacementKey(collectionId, sourceId) {
    return `${collectionId}/${sourceId}`;
  }

  function sourceNoteReason(member) {
    return member && Object.prototype.hasOwnProperty.call(member, 'reason') ? String(member.reason) : null;
  }

  function sourceNoteCodePointCount(value) {
    const trimmed = String(value == null ? '' : value).replace(/^[ \t\r\n\f\v]+|[ \t\r\n\f\v]+$/g, '');
    return Array.from(trimmed).length;
  }

  function sourceNoteEditorElement(selector, key) {
    return Array.from(document.querySelectorAll(selector)).find(node => node.dataset.sourceNoteEditorKey === key) || null;
  }

  function beginSourceNoteEdit(source, folder) {
    const member = (folder.collection.members || []).find(row => row?.kind === 'source' && text(row.id) === text(source.id));
    if (!member) {
      setStatus('That direct folder placement is no longer available.', 'error');
      return;
    }
    const key = sourceNotePlacementKey(folder.id, source.id);
    const reason = sourceNoteReason(member);
    app.sourceNoteEditor = {
      key,
      sourceId: source.id,
      sourceTitle: text(source.title, 'Source'),
      collectionId: folder.id,
      folderPath: folder.path,
      expectedVersion: Math.max(1, Math.round(Number(folder.collection.version) || 1)),
      expectedRevision: Number.isSafeInteger(app.state?.revision) ? app.state.revision : 0,
      baseReason: reason,
      draft: reason || '',
      stale: false
    };
    renderSources();
    requestAnimationFrame(() => {
      const textarea = sourceNoteEditorElement('textarea[data-source-note-editor-key]', key);
      textarea?.focus();
      if (textarea) textarea.setSelectionRange(textarea.value.length, textarea.value.length);
    });
  }

  function cancelSourceNoteEdit(key, {focus = true} = {}) {
    if (!app.sourceNoteEditor || app.sourceNoteEditor.key !== key) return;
    app.sourceNoteEditor = null;
    renderSources();
    if (focus) requestAnimationFrame(() => {
      const button = Array.from(document.querySelectorAll('button[data-source-note-edit-key]'))
        .find(node => node.dataset.sourceNoteEditKey === key);
      button?.focus();
    });
  }

  async function saveSourceNoteEdit(editor, value, button, {clear = false} = {}) {
    if (!app.sourceNoteEditor || app.sourceNoteEditor.key !== editor.key) return;
    const draft = clear ? '' : String(value == null ? '' : value);
    const count = sourceNoteCodePointCount(draft);
    if (count > 280) {
      setStatus(`This reason is ${count} Unicode characters. Keep it to 280 or fewer.`, 'error');
      return;
    }
    const original = button.textContent;
    button.disabled = true;
    button.textContent = clear ? 'Clearing…' : 'Saving…';
    try {
      const result = await request('set-source-placement-reason', {
        sourceId: editor.sourceId,
        collectionId: editor.collectionId,
        expectedVersion: editor.expectedVersion,
        expectedRevision: editor.expectedRevision,
        expectedReason: editor.baseReason,
        reason: clear ? null : draft
      });
      app.sourceNoteEditor = null;
      await loadState();
      if (result.changed) {
        armSourceNoteUndo({
          sourceId: editor.sourceId,
          sourceTitle: editor.sourceTitle,
          collectionId: editor.collectionId,
          folderPath: result.folderPath || editor.folderPath,
          expectedVersion: result.folderVersion,
          expectedRevision: result.expectedRevision,
          previousReason: result.previousReason,
          currentReason: result.reason
        });
        setStatus(result.cleared
          ? `Cleared the reason for ${result.folderPath}. Nothing was published or contacted.`
          : `Saved the reason for ${result.folderPath}. Nothing was published or contacted.`, 'success');
      } else {
        setStatus('That placement reason was already unchanged.', 'success');
      }
    } catch (error) {
      if (error.code === 'STALE_SOURCE_NOTE' && app.sourceNoteEditor?.key === editor.key) {
        app.sourceNoteEditor.stale = true;
      }
      await loadState().catch(() => {});
      setStatus(error.message, 'error');
      if (app.sourceNoteEditor?.key === editor.key) {
        button.disabled = false;
        button.textContent = original;
      }
    }
  }

  function sourceNoteEditorControl(source, folder, member) {
    const key = sourceNotePlacementKey(folder.id, source.id);
    const editor = app.sourceNoteEditor?.key === key ? app.sourceNoteEditor : null;
    const reason = sourceNoteReason(member);
    const placement = h('section', {class: 'source-note-placement', dataset: {sourceNotePlacementKey: key}});
    const summary = h('div', {class: 'source-note-placement-summary'});
    const copy = h('div');
    copy.append(
      h('h5', {text: folder.path}),
      h('p', {class: reason == null ? 'source-note-empty' : 'source-note-reason', text: reason == null ? 'No reason on this folder relationship.' : reason})
    );
    const edit = h('button', {
      class: 'secondary source-note-edit-button',
      type: 'button',
      text: reason == null ? 'Add reason' : 'Edit reason',
      ariaLabel: `${reason == null ? 'Add' : 'Edit'} reason for ${folder.path}`,
      dataset: {sourceNoteEditKey: key}
    });
    edit.addEventListener('click', () => beginSourceNoteEdit(source, folder));
    summary.append(copy, edit);
    placement.append(summary);
    if (!editor) return placement;

    const helpId = `source-note-help-${text(folder.id).replace(/[^a-z0-9_-]/gi, '-')}-${text(source.id).replace(/[^a-z0-9_-]/gi, '-')}`;
    const countId = `${helpId}-count`;
    const errorId = `${helpId}-error`;
    const form = h('div', {class: 'source-note-editor'});
    form.append(
      h('p', {id: helpId, class: 'source-note-boundary', text: 'This edit stays in this local ProgRSS library. It publishes nothing, contacts nobody, creates no schedule, and is not a ProgRSS safety claim.'})
    );
    const label = h('label', {for: `${helpId}-input`, text: `Reason for ${folder.path}`});
    const textarea = h('textarea', {
      id: `${helpId}-input`, rows: '4',
      'aria-describedby': `${helpId} ${countId} ${errorId}`,
      dataset: {sourceNoteEditorKey: key}
    });
    textarea.value = editor.draft;
    const count = sourceNoteCodePointCount(editor.draft);
    const counter = h('p', {id: countId, class: `source-note-count${count > 280 ? ' error' : ''}`, 'aria-live': 'polite', text: `${count} of 280 Unicode characters`});
    const error = h('p', {
      id: errorId,
      class: 'source-note-editor-error',
      text: editor.stale ? 'This folder changed in another view. Cancel, review the latest reason, and reopen the editor.' : (count > 280 ? 'Shorten this reason before saving.' : '')
    });
    textarea.setAttribute('aria-invalid', String(editor.stale || count > 280));
    textarea.addEventListener('input', () => {
      if (!app.sourceNoteEditor || app.sourceNoteEditor.key !== key) return;
      app.sourceNoteEditor.draft = textarea.value;
      const nextCount = sourceNoteCodePointCount(textarea.value);
      counter.textContent = `${nextCount} of 280 Unicode characters`;
      counter.classList.toggle('error', nextCount > 280);
      textarea.setAttribute('aria-invalid', String(app.sourceNoteEditor.stale || nextCount > 280));
      error.textContent = app.sourceNoteEditor.stale
        ? 'This folder changed in another view. Cancel, review the latest reason, and reopen the editor.'
        : (nextCount > 280 ? 'Shorten this reason before saving.' : '');
      save.disabled = app.sourceNoteEditor.stale || nextCount > 280;
    });
    textarea.addEventListener('keydown', event => {
      if (event.key === 'Escape') {
        event.preventDefault();
        cancelSourceNoteEdit(key);
      }
    });
    const actions = h('div', {class: 'source-note-editor-actions'});
    const save = h('button', {class: 'primary', type: 'button', text: 'Save reason', disabled: editor.stale || count > 280});
    const clear = h('button', {class: 'secondary', type: 'button', text: 'Clear reason', disabled: editor.stale || reason == null});
    const cancel = h('button', {class: 'quiet-button', type: 'button', text: 'Cancel'});
    save.addEventListener('click', () => saveSourceNoteEdit(editor, textarea.value, save));
    clear.addEventListener('click', () => saveSourceNoteEdit(editor, '', clear, {clear: true}));
    cancel.addEventListener('click', () => cancelSourceNoteEdit(key));
    actions.append(save, clear, cancel);
    form.append(label, textarea, counter, error, actions);
    placement.append(form);
    return placement;
  }

  function sourceFolderOrganizer(source) {
    const model = folderModel();
    if (!model.rows.length) return null;
    const membership = folderMembershipForSource(source.id, model);
    const safeId = text(source.id).replace(/[^a-z0-9_-]/gi, '-').slice(0, 70) || 'source';
    const region = h('section', {class: 'source-folder-organizer', 'aria-labelledby': `folder-heading-${safeId}`});
    region.append(h('h4', {id: `folder-heading-${safeId}`, text: 'Folders'}));
    if (membership.direct.length) {
      region.append(h('p', {text: `Directly in ${readableList(membership.direct.map(row => row.path))}.`}));
    } else {
      region.append(h('p', {text: 'Not directly in a folder yet.'}));
    }
    if (membership.inherited.length) {
      region.append(h('p', {class: 'folder-inherited', text: `Also appears in ${readableList(membership.inherited.map(row => row.path))} because those folders contain a nested folder.`}));
    }
    if (membership.direct.length) {
      const placements = h('div', {class: 'source-note-placements', ariaLabel: 'Reasons for direct folder relationships'});
      membership.direct.forEach(folder => {
        const member = (folder.collection.members || []).find(row => row?.kind === 'source' && text(row.id) === text(source.id));
        if (member) placements.append(sourceNoteEditorControl(source, folder, member));
      });
      region.append(placements);
    }
    if (membership.direct.length) {
      const controls = h('div', {class: 'folder-remove-controls'});
      const label = h('label', {for: `folder-remove-${safeId}`, text: membership.direct.length === 1 ? 'Remove direct placement' : 'Remove a direct placement'});
      const row = h('div', {class: 'folder-add-row'});
      const select = h('select', {id: `folder-remove-${safeId}`, class: 'folder-select source-folder-remove-select'});
      membership.direct.forEach(folder => select.append(h('option', {value: folder.id, text: folder.path})));
      const remove = h('button', {class: 'secondary', type: 'button', text: 'Remove from folder'});
      remove.addEventListener('click', () => {
        const reviewedFolder = membership.direct.find(folder => folder.id === select.value);
        removeSourceFromFolder(source, reviewedFolder, remove);
      });
      row.append(select, remove);
      controls.append(label, row, h('p', {class: 'field-help', text: 'Only the selected direct placement is removed. Membership inherited from nested folders is kept.'}));
      region.append(controls);
    }
    if (membership.available.length) {
      const controls = h('div', {class: 'folder-add-controls'});
      const label = h('label', {for: `folder-select-${safeId}`, text: 'Add to another folder'});
      const row = h('div', {class: 'folder-add-row'});
      const select = h('select', {id: `folder-select-${safeId}`, class: 'folder-select source-folder-select'});
      membership.available.forEach(folder => select.append(h('option', {value: folder.id, text: folder.path})));
      const add = h('button', {class: 'secondary', type: 'button', text: 'Add to folder'});
      add.addEventListener('click', () => addSourceToFolder(source, select.value, add));
      row.append(select, add);
      controls.append(label, row, h('p', {class: 'field-help', text: 'This adds one direct placement. Parent folders include it automatically.'}));
      region.append(controls);
    } else {
      region.append(h('p', {class: 'field-help', text: 'This source already appears in every simple folder.'}));
    }
    return region;
  }

  async function setSourceTextRetention(source, mode, button) {
    const original = button.textContent;
    button.disabled = true;
    button.textContent = 'Saving…';
    try {
      const result = await request('set-source-text-retention', {sourceId: source.id, mode});
      await loadState();
      setStatus(result.mode === 'summary'
        ? 'Future checks will keep summaries only. Existing unread and saved text was kept.'
        : 'Future checks will keep full text supplied by this feed. Summary-only updates may be filled in on a later check without becoming unread.', 'success');
    } catch (error) {
      await loadState().catch(() => {});
      setStatus(error.message, 'error');
      button.disabled = false;
      button.textContent = original;
    }
  }

  async function pruneSourceText(source, button) {
    if (app.textCleanupUndo) return;
    const original = button.textContent;
    button.disabled = true;
    button.textContent = 'Clearing…';
    try {
      const result = await request('prune-source-text', {sourceId: source.id});
      if (!result.changed?.length) {
        await loadState();
        setStatus('There is no read, unsaved full text to clear for this source.', 'success');
        return;
      }
      await loadState();
      armTextCleanupUndo({
        sourceId: source.id,
        sourceTitle: text(source.title, 'this source'),
        items: result.changed,
        expectedRevision: result.expectedRevision,
        count: result.changed.length,
        bytes: result.bytes
      });
      const remainder = result.remaining ? ` ${result.remaining} older full-text update${result.remaining === 1 ? '' : 's'} remain for another pass.` : '';
      setStatus(`Cleared ${result.changed.length} read, unsaved update${result.changed.length === 1 ? '' : 's'}.${remainder}`, 'success');
    } catch (error) {
      await loadState().catch(() => {});
      setStatus(error.message, 'error');
      button.disabled = false;
      button.textContent = original;
    }
  }

  async function undoSourceTextPrune() {
    const undo = app.textCleanupUndo;
    if (!undo) return;
    clearTimeout(app.textCleanupUndoTimer);
    els.undoTextCleanup.disabled = true;
    try {
      await request('undo-source-text-prune', {
        sourceId: undo.sourceId,
        items: undo.items,
        expectedRevision: undo.expectedRevision
      });
      app.textCleanupUndo = null;
      await loadState();
      setStatus('The cleared feed text has been restored.', 'success');
    } catch (error) {
      app.textCleanupUndo = null;
      await loadState().catch(() => {});
      setStatus(error.message, 'error');
    } finally {
      els.undoTextCleanup.disabled = false;
      renderTextCleanupUndo();
      renderSources();
    }
  }

  function sourceTextRetentionControls(source) {
    if (source.type !== 'rss') return null;
    const safeId = text(source.id).replace(/[^a-z0-9_-]/gi, '-').slice(0, 70) || 'source';
    const summariesOnly = source.textRetention === 'summary';
    const fullItems = fullTextItems(source.id);
    const fullBytes = fullItems.reduce((total, item) => total + utf8Bytes(item.body), 0);
    const plan = cleanupBatch(source.id);
    const region = h('section', {class: 'source-text-retention', 'aria-labelledby': `text-retention-${safeId}`});
    region.append(h('h4', {id: `text-retention-${safeId}`, text: 'Offline text'}));
    region.append(h('p', {text: summariesOnly
      ? 'New updates keep the feed’s summary. ProgRSS does not save the article page, images, scripts, or frames.'
      : 'New updates keep the full text supplied by the feed. ProgRSS does not save the article page, images, scripts, or frames.'}));
    const controls = h('div', {class: 'text-retention-controls'});
    const label = h('label', {for: `text-retention-choice-${safeId}`, text: 'New updates'});
    const row = h('div', {class: 'text-retention-row'});
    const select = h('select', {id: `text-retention-choice-${safeId}`, class: 'folder-select source-text-retention-select'});
    select.append(
      h('option', {value: 'full', text: 'Keep full feed text'}),
      h('option', {value: 'summary', text: 'Keep summaries only'})
    );
    select.value = summariesOnly ? 'summary' : 'full';
    const apply = h('button', {class: 'secondary', type: 'button', text: 'Use this choice', disabled: true});
    select.addEventListener('change', () => { apply.disabled = select.value === (summariesOnly ? 'summary' : 'full'); });
    apply.addEventListener('click', () => setSourceTextRetention(source, select.value, apply));
    row.append(select, apply);
    controls.append(label, row);
    region.append(controls);
    if (fullItems.length) {
      region.append(h('p', {class: 'field-help', text: `${formatBytes(fullBytes)} of full feed text is currently retained for ${fullItems.length} update${fullItems.length === 1 ? '' : 's'}.`}));
    }
    if (summariesOnly) {
      if (plan.selected.length) {
        const cleanup = h('button', {
          class: 'quiet-button text-cleanup-button', type: 'button',
          text: `Clear ${plan.selected.length} read, unsaved update${plan.selected.length === 1 ? '' : 's'}`,
          disabled: Boolean(app.textCleanupUndo)
        });
        cleanup.addEventListener('click', () => pruneSourceText(source, cleanup));
        region.append(cleanup, h('p', {class: 'field-help', text: `Clears ${formatBytes(plan.bytes)} in this pass. Unread and saved updates keep their text.${plan.candidates.length > plan.selected.length ? ' More can be cleared in another pass.' : ''}`}));
      } else if (fullItems.length) {
        region.append(h('p', {class: 'field-help', text: 'The remaining full text belongs to unread or saved updates, so ProgRSS leaves it alone.'}));
      } else {
        region.append(h('p', {class: 'field-help', text: 'No read, unsaved full text remains for this source.'}));
      }
    }
    return region;
  }

  function repairValidatorLabel(validators = {}) {
    return validators.etag || validators.lastModified ? 'Saved' : 'None';
  }

  function repairFolderLabel(folders = {}) {
    const direct = (folders.direct || []).map(row => row.path);
    const inherited = (folders.inherited || []).map(row => row.path);
    if (!direct.length && !inherited.length) return 'Unfiled';
    const parts = [];
    if (direct.length) parts.push(`directly in ${readableList(direct)}`);
    if (inherited.length) parts.push(`also in ${readableList(inherited)} through nested folders`);
    return parts.join('; ');
  }

  function repairChoiceCard(source, selected) {
    const label = h('label', {class: `repair-source-choice${selected ? ' selected' : ''}`});
    const radio = h('input', {
      type: 'radio', name: 'repair-survivor', value: source.id,
      checked: selected
    });
    const body = h('span', {class: 'repair-choice-body'});
    const heading = h('span', {class: 'repair-choice-heading'});
    heading.append(h('strong', {text: text(source.title, 'Untitled source')}), h('span', {class: 'state-pill', text: source.status}));
    body.append(heading, h('code', {text: source.url}));
    const facts = h('dl', {class: 'repair-facts'});
    facts.append(
      activityRow('Updates', h('span', {text: `${source.items.items} retained · ${source.items.unread} unread · ${source.items.saved} saved`})),
      activityRow('Folders', h('span', {text: repairFolderLabel(source.folders)})),
      activityRow('Successful check', h('span', {text: source.activity.successfulAt ? relativeTime(source.activity.successfulAt) : 'Not yet', title: exactTime(source.activity.successfulAt)})),
      activityRow('New update', h('span', {text: source.activity.newAt ? relativeTime(source.activity.newAt) : 'None yet', title: exactTime(source.activity.newAt)})),
      activityRow('Next check', h('span', {text: source.enabled ? (source.nextAt ? relativeTime(source.nextAt) : 'Not scheduled yet') : 'Paused', title: exactTime(source.nextAt)})),
      activityRow('Site access', h('span', {text: source.permissionGranted ? 'Allowed in this browser' : 'Not currently allowed'})),
      activityRow('Check memory', h('span', {text: repairValidatorLabel(source.validators)}))
    );
    if (source.activity.problemAt || source.activity.problem) {
      facts.append(activityRow('Last problem', h('span', {
        text: `${source.activity.problemAt ? relativeTime(source.activity.problemAt) : 'Time unknown'}${source.activity.problem ? ` · ${source.activity.problem}` : ''}`,
        title: exactTime(source.activity.problemAt)
      })));
    }
    body.append(facts, h('span', {class: 'repair-keep-note', text: 'Keep this title, address, checking state, site access, and check memory.'}));
    label.append(radio, body);
    return {label, radio};
  }

  function renderRepairOutcome(container, preview, survivorId) {
    container.replaceChildren();
    const outcome = (preview.outcomes || []).find(row => row.survivorId === survivorId);
    if (!outcome) {
      container.append(h('p', {text: 'Choose which source should remain. ProgRSS will then show the exact combined result.'}));
      return;
    }
    const survivor = (preview.sources || []).find(row => row.id === survivorId);
    const other = (preview.sources || []).find(row => row.id !== survivorId);
    container.append(
      h('h4', {text: `Result: keep ${text(survivor?.title, 'selected source')}`}),
      h('p', {text: `${outcome.retainedItems} update${outcome.retainedItems === 1 ? '' : 's'} remain · ${outcome.unread} unread · ${outcome.saved} saved. ${outcome.exactRepeatsCollapsed} exact repeat${outcome.exactRepeatsCollapsed === 1 ? '' : 's'} will be collapsed.`}),
      h('p', {text: `${outcome.directFolders.length} direct folder placement${outcome.directFolders.length === 1 ? '' : 's'} remain. The address, checking schedule, site access, and check memory from ${text(other?.title, 'the other source')} are not copied.`})
    );
  }

  async function openSourceReferenceReport(preview, button) {
    const sources = Array.isArray(preview?.sources) ? preview.sources : [];
    if (sources.length !== 2) return;
    const params = new URLSearchParams({repairFirst: sources[0].id, repairSecond: sources[1].id});
    const url = api.runtime.getURL(`workbench/index.html?${params.toString()}#source-reference-report`);
    const original = button.textContent;
    button.disabled = true;
    button.textContent = 'Opening report…';
    try {
      if (api.tabs?.create) await api.tabs.create({url});
      else await api.runtime.openOptionsPage();
    } catch (error) {
      setStatus(`Could not open the references report: ${error.message}`, 'error');
      button.disabled = false;
      button.textContent = original;
    }
  }

  function renderSharedFolderUpdateUndo() {
    const undo = app.state.sharedFolderUpdate || {};
    const available = Boolean(undo.undoAvailable && Date.parse(undo.expiresAt || '') > Date.now());
    els.sharedFolderUpdateUndo.hidden = !available;
    if (available) {
      const changes = undo.changes || {};
      const changed = (Number(changes.sourcesAdded) || 0) + (Number(changes.sourcesRemoved) || 0) +
        (Number(changes.sourceRecipesChanged) || 0) + (Number(changes.foldersAdded) || 0) +
        (Number(changes.foldersRemoved) || 0) + (Number(changes.foldersChanged) || 0);
      els.sharedFolderUpdateUndoMessage.textContent = `${text(undo.title, 'The shared folder')} changed${changed ? ` in ${changed} reviewed place${changed === 1 ? '' : 's'}` : ''}. Undo is available ${relativeTime(undo.expiresAt)}.`;
    }
  }

  function renderSourceRepair() {
    const undo = app.state.sourceRepair || {};
    const undoAvailable = Boolean(undo.undoAvailable && Date.parse(undo.expiresAt || '') > Date.now());
    els.sourceRepairUndo.hidden = !undoAvailable;
    if (undoAvailable) {
      els.sourceRepairUndoMessage.textContent = `${text(undo.survivorTitle, 'One source')} now includes ${text(undo.otherTitle, 'the other history')}. Undo is available ${relativeTime(undo.expiresAt)}.`;
    }

    els.sourceRepairNotice.replaceChildren();
    const candidateSet = sourceRepairCandidates();
    const candidates = candidateSet.pairs;
    if (candidateSet.total) {
      const notice = h('section', {class: 'repair-notice', 'aria-labelledby': 'repair-notice-heading'});
      notice.append(
        h('div', {class: 'repair-notice-copy'}, [
          h('strong', {id: 'repair-notice-heading', text: `${candidateSet.total} possible same-source pair${candidateSet.total === 1 ? '' : 's'}`}),
          h('p', {text: 'These sources share a reviewed address. Nothing is combined until you compare both histories and choose what remains.'})
        ])
      );
      const list = h('div', {class: 'repair-pair-list'});
      for (const pair of candidates.slice(0, 4)) {
        const row = h('div', {class: 'repair-pair'});
        const names = h('div');
        names.append(
          h('span', {text: text(pair.first.title, 'Untitled source')}),
          h('span', {class: 'repair-pair-and', text: 'and'}),
          h('span', {text: text(pair.second.title, 'Untitled source')})
        );
        const review = h('button', {class: 'secondary compact', type: 'button', text: 'Review histories'});
        review.addEventListener('click', () => reviewSourceRepair(pair, review));
        row.append(names, review);
        list.append(row);
      }
      notice.append(list);
      if (candidateSet.total > 4) notice.append(h('p', {class: 'repair-more', text: `Showing four pairs first. ${candidateSet.total - 4} more will remain available after you resolve or keep these.`}));
      els.sourceRepairNotice.append(notice);
    }

    els.sourceRepairReview.replaceChildren();
    const preview = app.repairPreview;
    if (!preview) return;
    const review = h('section', {class: 'repair-review-card', 'aria-labelledby': 'repair-review-heading'});
    const close = h('button', {class: 'quiet-button repair-close', type: 'button', text: 'Close review'});
    close.addEventListener('click', () => {
      app.repairPreview = null;
      app.repairChoice = '';
      app.repairAcknowledged = false;
      renderSourceRepair();
    });
    review.append(
      h('div', {class: 'repair-review-head'}, [
        h('div', {}, [
          h('p', {class: 'section-kicker', text: 'Same source repair'}),
          h('h3', {id: 'repair-review-heading', tabindex: '-1', text: 'Compare both histories'})
        ]),
        close
      ]),
      h('p', {class: 'repair-intro', text: 'ProgRSS will keep all non-identical update events. When an exact repeat exists in both histories, unread wins over read and saved wins over unsaved.'})
    );

    const evidence = h('details', {class: 'repair-evidence'});
    evidence.append(h('summary', {text: `${preview.sharedAddresses.length} shared address${preview.sharedAddresses.length === 1 ? '' : 'es'} found`}));
    const addressList = h('div', {class: 'repair-addresses'});
    (preview.sharedAddresses || []).forEach(address => addressList.append(h('code', {text: address})));
    evidence.append(addressList);
    review.append(evidence);

    if (!preview.canRepair) {
      const blocked = h('div', {class: 'repair-blocked'});
      const placementConflicts = Array.isArray(preview.placementConflicts) ? preview.placementConflicts : [];
      const sourceNames = new Map((preview.sources || []).map(source => [source.id, text(source.title, 'Source')]));
      if (placementConflicts.length) {
        blocked.append(
          h('strong', {text: 'Different folder reasons need a decision first.'}),
          h('p', {text: `ProgRSS found ${placementConflicts.length} direct folder placement${placementConflicts.length === 1 ? '' : 's'} that cannot be combined without discarding meaning.`})
        );
        const list = h('ul', {class: 'repair-reference-summary'});
        for (const conflict of placementConflicts) {
          if (conflict.kind === 'divergent-reasons') {
            const firstReason = conflict.firstReason === null ? 'no reason' : `“${conflict.firstReason}”`;
            const secondReason = conflict.secondReason === null ? 'no reason' : `“${conflict.secondReason}”`;
            list.append(h('li', {text: `${text(conflict.folderPath, conflict.folderTitle || conflict.folderId)}: ${sourceNames.get(conflict.firstSourceId) || 'First source'} has ${firstReason}; ${sourceNames.get(conflict.secondSourceId) || 'Second source'} has ${secondReason}.`}));
          } else {
            list.append(h('li', {text: `${text(conflict.folderPath, conflict.folderTitle || conflict.folderId)}: ${text(conflict.message, 'A placement reason is invalid.')}`}));
          }
        }
        blocked.append(
          list,
          h('p', {class: 'privacy-note', text: 'Edit or clear one reason in that folder, then review the repair again. Nothing was combined, and ProgRSS will not choose a reason automatically.'})
        );
      }
      const report = preview.referenceReport || {};
      const summary = report.summary || {};
      const groups = Array.isArray(report.groups) ? report.groups : [];
      const hasReferenceBlock = Boolean(summary.blockingRecords || groups.length || preview.scanExceeded || (preview.advancedReferences || []).length);
      if (hasReferenceBlock) {
        blocked.append(h('strong', {text: 'Advanced records still refer to these histories.'}));
        if (summary.blockingRecords) {
          blocked.append(h('p', {text: `${summary.blockingRecords} blocking record${summary.blockingRecords === 1 ? '' : 's'} contain ${summary.exactReferences || 0} exact reference${summary.exactReferences === 1 ? '' : 's'}.`}));
        }
        if (groups.length) {
          const list = h('ul', {class: 'repair-reference-summary'});
          groups.forEach(group => list.append(h('li', {text: `${text(group.label, group.key)}: ${Number(group.recordCount) || 0} record${Number(group.recordCount) === 1 ? '' : 's'}`})));
          blocked.append(list);
        }
        blocked.append(h('p', {class: 'privacy-note', text: 'The detailed report is read-only. ProgRSS will not rewrite, delete, or transfer trust from these records automatically.'}));
        const openReport = h('button', {class: 'secondary wide', type: 'button', text: 'See references in Advanced Workbench'});
        openReport.addEventListener('click', () => openSourceReferenceReport(preview, openReport));
        blocked.append(openReport);
      }
      const detailedMessages = (preview.blockers || []).filter(message => !placementConflicts.length || !String(message).includes('incompatible Source Notes'));
      detailedMessages.forEach(message => blocked.append(h('p', {text: message})));
      review.append(blocked);
      els.sourceRepairReview.append(review);
      return;
    }

    const fieldset = h('fieldset', {class: 'repair-choices'});
    fieldset.append(h('legend', {text: 'Which source should remain?'}));
    const radios = [];
    for (const source of preview.sources || []) {
      const choice = repairChoiceCard(source, app.repairChoice === source.id);
      radios.push(choice.radio);
      fieldset.append(choice.label);
    }
    review.append(fieldset);

    const outcome = h('div', {class: 'repair-outcome'});
    renderRepairOutcome(outcome, preview, app.repairChoice);
    review.append(outcome);

    if (Array.isArray(preview.warnings) && preview.warnings.length) {
      const warnings = h('details', {class: 'repair-warnings'});
      warnings.append(h('summary', {text: `${preview.warnings.length} important boundar${preview.warnings.length === 1 ? 'y' : 'ies'}`}));
      warnings.append(h('ul', {}, preview.warnings.map(message => h('li', {text: message}))));
      review.append(warnings);
    }

    review.append(h('p', {class: 'privacy-note', text: `This local repair contacts no site. You can undo it for ${preview.undoMinutes} minutes, but undo stops if newer reading or organization would be overwritten.`}));
    const confirmation = h('label', {class: 'replace-confirm'});
    const checkbox = h('input', {type: 'checkbox', checked: app.repairAcknowledged});
    confirmation.append(checkbox, h('span', {text: 'I reviewed which source will remain.'}));
    review.append(confirmation);
    const actions = h('div', {class: 'repair-actions'});
    const commit = h('button', {class: 'primary wide', type: 'button', text: 'Combine as one source'});
    const cancel = h('button', {class: 'quiet-button wide', type: 'button', text: 'Keep both sources'});
    cancel.addEventListener('click', () => {
      app.repairPreview = null;
      app.repairChoice = '';
      app.repairAcknowledged = false;
      renderSourceRepair();
    });
    const update = () => {
      commit.disabled = !app.repairChoice || !app.repairAcknowledged || app.busy.has('source-repair');
      renderRepairOutcome(outcome, preview, app.repairChoice);
      radios.forEach(radio => radio.closest('label')?.classList.toggle('selected', radio.checked));
    };
    radios.forEach(radio => radio.addEventListener('change', () => {
      app.repairChoice = radio.value;
      update();
    }));
    checkbox.addEventListener('change', () => {
      app.repairAcknowledged = checkbox.checked;
      update();
    });
    commit.addEventListener('click', () => commitSourceRepair(commit));
    actions.append(commit, cancel);
    review.append(actions);
    els.sourceRepairReview.append(review);
    update();
  }

  async function reviewSourceRepair(pair, button) {
    button.disabled = true;
    const original = button.textContent;
    button.textContent = 'Preparing review…';
    busy('source-repair', true);
    try {
      app.repairPreview = await request('preview-source-repair', {
        firstSourceId: pair.first.id,
        secondSourceId: pair.second.id
      });
      app.repairChoice = '';
      app.repairAcknowledged = false;
      renderSourceRepair();
      requestAnimationFrame(() => $('#repair-review-heading')?.focus());
    } catch (error) {
      setStatus(error.message, 'error');
      button.disabled = false;
      button.textContent = original;
    } finally {
      busy('source-repair', false);
    }
  }

  async function commitSourceRepair(button) {
    const preview = app.repairPreview;
    if (!preview || !app.repairChoice || !app.repairAcknowledged) return;
    button.disabled = true;
    button.textContent = 'Combining histories…';
    busy('source-repair', true);
    try {
      const result = await request('repair-same-source', {
        firstSourceId: preview.sources[0].id,
        secondSourceId: preview.sources[1].id,
        survivorId: app.repairChoice,
        reviewedRevision: preview.reviewedRevision
      });
      app.repairPreview = null;
      app.repairChoice = '';
      app.repairAcknowledged = false;
      await loadState();
      setStatus(`Combined the histories. ${result.itemMerge.afterCount} update${result.itemMerge.afterCount === 1 ? '' : 's'} remain; ${result.itemMerge.exactRepeatsCollapsed} exact repeat${result.itemMerge.exactRepeatsCollapsed === 1 ? '' : 's'} collapsed.`, 'success');
      openSourceDetails(result.survivorId);
    } catch (error) {
      if (error.code === 'SOURCE_REPAIR_STALE') {
        try {
          app.repairPreview = await request('preview-source-repair', {
            firstSourceId: preview.sources[0].id,
            secondSourceId: preview.sources[1].id
          });
          app.repairChoice = '';
          app.repairAcknowledged = false;
          setStatus('ProgRSS changed while you were reviewing. Compare the updated histories before continuing.', 'error');
        } catch (refreshError) {
          app.repairPreview = null;
          setStatus(refreshError.message, 'error');
        }
      } else {
        setStatus(error.message, 'error');
      }
      renderSourceRepair();
    } finally {
      busy('source-repair', false);
    }
  }

  async function undoSharedFolderUpdate() {
    busy('shared-folder-update-undo', true);
    els.undoSharedFolderUpdate.textContent = 'Restoring folder…';
    try {
      const result = await request('undo-shared-folder-update');
      await loadState();
      setStatus(`${text(result.title, 'The shared folder')} was restored to its earlier local version.`, 'success');
    } catch (error) {
      await loadState().catch(() => {});
      setStatus(error.message, 'error');
    } finally {
      els.undoSharedFolderUpdate.textContent = 'Undo folder update';
      busy('shared-folder-update-undo', false);
    }
  }

  async function undoSourceRepair() {
    busy('source-repair-undo', true);
    els.undoSourceRepair.textContent = 'Restoring histories…';
    try {
      await request('undo-source-repair');
      app.repairPreview = null;
      await loadState();
      setStatus('The two source histories have been restored.', 'success');
    } catch (error) {
      await loadState().catch(() => {});
      setStatus(error.message, 'error');
    } finally {
      els.undoSourceRepair.textContent = 'Undo source repair';
      busy('source-repair-undo', false);
    }
  }

  function sourceCard(source) {
    const status = sourceOutcome(source);
    const attention = Boolean(source.pendingRedirect || (source.permissionMissing && source.enabled) || source.watchRepair || source.lastError);
    const card = h('article', {class: `source-card${source.enabled ? '' : ' paused'}${attention ? ' attention' : ''}`, dataset: {sourceId: source.id}});
    const head = h('div', {class: 'source-head'});
    const title = h('div', {class: 'source-title'});
    title.append(markNaturalText(h('h3', {text: text(source.title, 'Untitled source')}), source.titleLanguage || source.language));
    let host = source.url;
    try { host = new URL(source.url).hostname.replace(/^www\./, ''); } catch {}
    title.append(h('p', {text: host}));
    head.append(title, h('span', {class: `state-pill${status.className ? ` ${status.className}` : ''}`, text: status.label}));
    card.append(head);
    const folderLabels = folderLabelsForSource(source.id);
    if (folderLabels.length) {
      const labels = h('div', {class: 'source-folders', ariaLabel: 'Folders'});
      folderLabels.forEach(label => labels.append(h('span', {class: 'folder-badge', text: label})));
      card.append(labels);
    }

    const decision = sourceDecision(source);
    if (decision) card.append(decision);
    else if (source.lastError) card.append(h('p', {class: 'source-note error', text: text(source.lastError)}));
    else card.append(h('p', {class: 'source-note', text: nextCheck(source)}));

    const actions = h('div', {class: 'source-actions'});
    const refresh = h('button', {class: 'secondary', type: 'button', text: source.watchStability ? 'Check again' : 'Refresh'});
    refresh.disabled = !source.enabled || Boolean(source.pendingRedirect) || Boolean(source.permissionMissing) || Boolean(source.watchRepair);
    refresh.addEventListener('click', () => refreshSource(source.id, refresh));
    const toggle = h('button', {class: 'secondary', type: 'button', text: source.enabled ? 'Pause' : 'Resume'});
    toggle.addEventListener('click', () => toggleSource(source.id, !source.enabled, toggle));
    actions.append(refresh, toggle);
    card.append(actions);

    const lastSuccess = source.lastSuccessfulAt || ((source.lastScan && !['error', 'throttled', 'permission', 'moved'].includes(source.lastOutcome)) ? source.lastScan : '');
    const lastNew = source.lastNewAt || latestItemAt(source.id);
    const lastProblemAt = source.lastProblemAt || (source.lastError ? source.lastScan : '');
    const lastProblem = text(source.lastProblem || source.lastError);
    const more = h('details');
    if (app.sourceNoteEditor?.sourceId === source.id) more.open = true;
    more.append(h('summary', {text: 'Activity and options'}));
    const activity = h('dl', {class: 'activity-grid'});
    activity.append(
      activityRow('Successful check', activityTime(lastSuccess, 'Not yet')),
      activityRow('New update', activityTime(lastNew, 'None yet')),
      activityRow('Last problem', lastProblemAt
        ? h('span', {text: `${relativeTime(lastProblemAt)}${lastProblem ? ` · ${lastProblem}` : ''}`, title: exactTime(lastProblemAt)})
        : h('span', {text: 'None recorded'}))
    );
    if (source.type === 'page') {
      const healthMessage = source.watchRepair
        ? 'Stopped until you choose a page section again.'
        : text(source.watchHealth?.message, source.lastOutcome === 'baseline' ? 'The watch has a baseline.' : 'No watch-health result recorded yet.');
      activity.append(activityRow('Watch health', h('span', {text: healthMessage})));
    }
    more.append(activity);
    if (source.type === 'page') {
      const watch = h('section', {class: 'source-watch-explanation'});
      watch.append(h('h4', {text: 'What this watch notices'}));
      watch.append(h('p', {text: source.mode === 'cards'
        ? 'New, removed, or reworded entries in a repeated list on this page.'
        : 'Meaningful wording changes in the page’s watched main text.'}));
      const threshold = Math.max(0, Math.floor(Number(source.threshold) || 0));
      const details = [];
      if (threshold > 1) details.push(`Changes smaller than ${threshold} characters are ignored.`);
      details.push(source.ignoreNumbers ? 'Changes made only to numbers are ignored.' : 'Number changes are included.');
      watch.append(h('p', {class: 'source-watch-policy', text: details.join(' ')}));
      watch.append(h('p', {class: 'source-watch-advanced', text: 'Selector and fine-tuning controls remain in Advanced Workbench.'}));
      more.append(watch);
    }
    const organizer = sourceFolderOrganizer(source);
    if (organizer) more.append(organizer);
    const retention = sourceTextRetentionControls(source);
    if (retention) more.append(retention);
    const moreActions = h('div', {class: 'source-more-actions'});
    if (source.url) moreActions.append(h('a', {class: 'source-link', href: source.url, target: '_blank', rel: 'noreferrer', text: 'Open source address'}));
    const archive = h('button', {class: 'quiet-button archive-button', type: 'button', text: 'Archive this source'});
    archive.addEventListener('click', () => archiveSource(source, archive));
    moreActions.append(archive);
    more.append(moreActions);
    card.append(more);
    return card;
  }

  function sourceAttentionRank(source) {
    if (source.pendingRedirect) return 0;
    if (source.permissionMissing && source.enabled) return 1;
    if (source.type === 'page' && source.watchRepair) return 2;
    if (source.lastError) return 2;
    return 3;
  }

  function sourceNeedsAttention(source) {
    return sourceAttentionRank(source) < 3;
  }

  function sourceGroup(title, sources, tone = '') {
    const safeId = title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    const section = h('section', {class: `source-group${tone ? ` ${tone}` : ''}`, 'aria-labelledby': `source-group-${safeId}`});
    const heading = h('div', {class: 'source-group-heading'});
    heading.append(
      h('h3', {id: `source-group-${safeId}`, text: title}),
      h('span', {text: String(sources.length), ariaLabel: `${sources.length} source${sources.length === 1 ? '' : 's'}`})
    );
    const list = h('div', {class: 'source-group-list'});
    sources.forEach(source => list.append(sourceCard(source)));
    section.append(heading, list);
    return section;
  }

  function renderPageWatchRepairUndo() {
    const undo = app.state.pageWatchRepair || {};
    const available = Boolean(undo.undoAvailable && Date.parse(undo.expiresAt || '') > Date.now());
    els.pageWatchRepairUndo.hidden = !available;
    if (!available) return;
    els.pageWatchRepairUndoMessage.textContent = `${text(undo.sourceTitle, 'The page watch')} can be restored ${relativeTime(undo.expiresAt)} if nothing newer changes.`;
  }

  async function undoPageWatchRepair() {
    busy('page-watch-repair-undo', true);
    els.undoPageWatchRepair.textContent = 'Restoring watch…';
    try {
      const result = await request('undo-page-watch-repair');
      app.pageWatchRepairReview = null;
      app.pageWatchRepairChoice = '';
      await loadState();
      setStatus(`${text(result.sourceTitle, 'The page watch')} was restored to its earlier rule and baseline.`, 'success');
    } catch (error) {
      await loadState().catch(() => {});
      setStatus(error.message, 'error');
    } finally {
      els.undoPageWatchRepair.textContent = 'Undo watch repair';
      busy('page-watch-repair-undo', false);
    }
  }

  function renderSources() {
    const activeEditorKey = document.activeElement?.dataset?.sourceNoteEditorKey || '';
    const selectionStart = activeEditorKey && Number.isInteger(document.activeElement?.selectionStart) ? document.activeElement.selectionStart : null;
    const selectionEnd = activeEditorKey && Number.isInteger(document.activeElement?.selectionEnd) ? document.activeElement.selectionEnd : null;
    const folder = selectedFolder();
    const sources = (app.state.sources || []).filter(source => !source.archivedAt && (folder.sourceIds === null || folder.sourceIds.has(text(source.id))));
    const active = sources.filter(source => source.enabled).length;
    const moved = sources.filter(source => source.pendingRedirect).length;
    const reconnect = sources.filter(source => source.enabled && source.permissionMissing && !source.pendingRedirect).length;
    const otherAttention = sources.filter(source => source.lastError && !source.pendingRedirect && !source.permissionMissing).length;
    const notices = [moved ? `${moved} moved` : '', reconnect ? `${reconnect} reconnect` : '', otherAttention ? `${otherAttention} need attention` : ''].filter(Boolean);
    els.sourceSummary.textContent = sources.length
      ? `${active} active · ${sources.length - active} paused${notices.length ? ` · ${notices.join(' · ')}` : ''}`
      : folder.id === 'all' ? 'The places you follow.' : `No sources in ${folder.label}.`;
    els.sourceList.replaceChildren();
    els.sourceList.setAttribute('aria-busy', 'false');
    if (!sources.length) {
      els.sourceList.append(emptyState('empty'));
      return;
    }
    const byTitle = (a, b) => text(a.title).localeCompare(text(b.title));
    const attention = sources.filter(sourceNeedsAttention).sort((a, b) => sourceAttentionRank(a) - sourceAttentionRank(b) || byTitle(a, b));
    const following = sources.filter(source => !sourceNeedsAttention(source)).sort(byTitle);
    if (attention.length) els.sourceList.append(sourceGroup('Needs your attention', attention, 'attention'));
    if (following.length) els.sourceList.append(sourceGroup(attention.length ? 'Following' : 'Your sources', following));
    if (activeEditorKey && app.sourceNoteEditor?.key === activeEditorKey) requestAnimationFrame(() => {
      const textarea = sourceNoteEditorElement('textarea[data-source-note-editor-key]', activeEditorKey);
      if (!textarea) return;
      textarea.focus({preventScroll: true});
      if (selectionStart != null && selectionEnd != null) textarea.setSelectionRange(selectionStart, selectionEnd);
    });
  }

  function renderLibraryUndo() {
    const transfer = app.state.transfer || {};
    const available = Boolean(transfer.undoAvailable && Date.parse(transfer.expiresAt || '') > Date.now());
    els.libraryUndo.hidden = !available;
    if (!available) return;
    const previous = transfer.previous || {};
    const sourceCount = Number(previous.sources) || 0;
    els.libraryUndoMessage.textContent = `Your previous ${sourceCount}-source library can be restored ${relativeTime(transfer.expiresAt)}.`;
  }

  function renderLibraryRecovery() {
    const recovery = app.state.libraryRecovery;
    const visible = recovery?.state === 'missing';
    const entering = visible && !app.recoveryWasVisible;
    if (entering) {
      app.followHandoff = null;
      app.folderUndo = null;
      app.sourceNoteEditor = null;
      app.sourceNoteUndo = null;
      app.textCleanupUndo = null;
      app.repairPreview = null;
      app.repairChoice = '';
      app.repairAcknowledged = false;
      app.pageWatchRepairReview = null;
      app.pageWatchRepairChoice = '';
      app.transfer = null;
      setStatus();
    }
    app.recoveryWasVisible = visible;
    els.libraryRecovery.hidden = !visible;
    document.body.classList.toggle('library-recovery-required', visible);
    updateActionAvailability();
    if (!visible) return;

    els.libraryRecoveryHeading.textContent = recovery.reason === 'vault-unreadable'
      ? 'ProgRSS couldn’t read your local library'
      : 'Your local library appears missing';
    const messages = {
      'vault-unreadable': 'This browser still remembers an earlier ProgRSS library, but its saved vault could not be read safely.',
      'vault-reset': 'This browser still remembers an earlier ProgRSS library, but its local vault has started over.',
      'vault-emptied': 'This browser still remembers an earlier ProgRSS library, but the local vault is now empty.',
      'vault-missing': 'This browser still remembers an earlier ProgRSS library, but its local vault is no longer present.'
    };
    els.libraryRecoveryMessage.textContent = `${messages[recovery.reason] || messages['vault-missing']} ProgRSS stopped new saves so the empty vault would not be mistaken for a fresh installation.`;
    const known = recovery.lastKnown && typeof recovery.lastKnown === 'object' ? recovery.lastKnown : {};
    const sources = Number(known.sources) || 0;
    const items = Number(known.items) || 0;
    const unread = Number(known.unread) || 0;
    const saved = Number(known.saved) || 0;
    const parts = [`Last remembered: ${sources} source${sources === 1 ? '' : 's'}, ${items} update${items === 1 ? '' : 's'}, ${unread} unread, ${saved} saved`];
    if (recovery.lastCommittedAt) parts.push(`last saved ${exactTime(recovery.lastCommittedAt) || relativeTime(recovery.lastCommittedAt)}`);
    els.libraryRecoveryDetail.textContent = parts.join(' · ');
    if (entering) requestAnimationFrame(() => {
      els.libraryRecoveryHeading.focus({preventScroll: true});
      els.libraryRecovery.scrollIntoView({block: 'start'});
    });
  }

  function renderStorageIncident() {
    const incident = app.state.storageIncident;
    const visible = !libraryRecoveryRequired() && Boolean(incident && incident.schema === 'progrss.storage.incident.v1');
    els.storageIncident.hidden = !visible;
    if (!visible) return;
    const operation = text(incident.operation, 'Saving a ProgRSS change');
    els.storageIncidentHeading.textContent = 'ProgRSS couldn’t save a change';
    els.storageIncidentMessage.textContent = `${text(incident.message, 'The browser could not complete the storage write.')} The attempted change was not saved. Your last saved library remains available.`;
    const parts = [operation];
    if (incident.occurredAt) parts.push(exactTime(incident.occurredAt) || relativeTime(incident.occurredAt));
    const library = incident.savedLibrary;
    if (library && typeof library === 'object') {
      const sources = Number(library.sources) || 0;
      const items = Number(library.items) || 0;
      const unread = Number(library.unread) || 0;
      const saved = Number(library.saved) || 0;
      parts.push(`Last saved library: ${sources} source${sources === 1 ? '' : 's'}, ${items} update${items === 1 ? '' : 's'}, ${unread} unread, ${saved} saved`);
    }
    els.storageIncidentDetail.textContent = parts.join(' · ');
  }

  function render() {
    renderLibraryRecovery();
    renderStorageIncident();
    renderFolderControls();
    renderShareFolder();
    renderFollowHandoff();
    renderFolderUndo();
    renderSourceNoteUndo();
    renderBackupReminder();
    renderCopyCheck();
    renderStorageOverview();
    renderTextCleanupUndo();
    renderItems();
    renderDetail();
    renderSources();
    renderSourceRepair();
    renderPageWatchRepairUndo();
    renderSharedFolderUpdateUndo();
    renderOpml();
    renderSharedFolder();
    renderTransfer();
    renderLibraryUndo();
  }

  function restoreMissingLibraryFile() {
    setView('add', {focus: true});
    requestAnimationFrame(() => {
      els.backupFile.value = '';
      els.backupFile.click();
    });
  }

  async function acceptEmptyLibrary() {
    busy('library-recovery', true);
    try {
      const result = await request('accept-empty-library');
      await loadState();
      if (result?.accepted) setStatus('This empty library is now accepted. You can still restore a private file from Add.', 'success');
      else setStatus('This library no longer needs an empty-library decision.', 'success');
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      busy('library-recovery', false);
    }
  }

  function openSourceDetails(sourceId) {
    sourceId = text(sourceId);
    if (!sourceId) return;
    app.folder = 'all';
    try { api.storage.local.set({libraryFolder: 'all'}); } catch {}
    setView('sources', {focus: true});
    renderFolderControls();
    renderSources();
    requestAnimationFrame(() => {
      const card = $(`.source-card[data-source-id="${CSS.escape(sourceId)}"]`);
      const target = card?.querySelector('summary, button, a');
      target?.focus();
      card?.scrollIntoView({block: 'center'});
    });
  }

  function showFollowedSource() {
    openSourceDetails(app.followHandoff?.sourceId || els.showFollowedSource.dataset.sourceId);
  }

  async function changeItem(itemId, changes, {quiet = false} = {}) {
    const item = app.state.items.find(row => row.id === itemId);
    if (!item) return;
    const before = {readAt: item.readAt, starred: item.starred};
    if (changes.read !== undefined) item.readAt = changes.read ? (item.readAt || new Date().toISOString()) : '';
    if (changes.starred !== undefined) item.starred = Boolean(changes.starred);
    renderItems();
    renderDetail();
    try {
      await request('set-item', {itemId, ...changes});
    } catch (error) {
      item.readAt = before.readAt;
      item.starred = before.starred;
      renderItems();
      renderDetail();
      setStatus(error.message, 'error');
      return;
    }
    if (!quiet && changes.starred !== undefined) setStatus(changes.starred ? 'Saved for later.' : 'Removed from saved.', 'success');
  }

  async function markAllRead() {
    const matched = matchingItems();
    const folder = selectedFolder();
    const scope = app.search ? matched : (folder.id === 'all' ? (app.state.items || []) : itemsInSelectedFolder());
    const ids = scope.filter(item => !item.readAt).map(item => item.id);
    if (!ids.length) return;
    els.markAll.disabled = true;
    try {
      if (app.search || folder.id !== 'all') await request('mark-items-read', {ids});
      else await request('mark-all-read');
      app.undoIds = ids;
      clearTimeout(app.undoTimer);
      els.undoMessage.textContent = `${ids.length} update${ids.length === 1 ? '' : 's'} marked read.`;
      els.undoRow.hidden = false;
      app.undoTimer = setTimeout(() => { app.undoIds = []; els.undoRow.hidden = true; }, 12_000);
      await loadState();
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      els.markAll.disabled = false;
    }
  }

  async function undoMarkAll() {
    const ids = [...app.undoIds];
    if (!ids.length) return;
    els.undo.disabled = true;
    try {
      await request('mark-items-unread', {ids});
      app.undoIds = [];
      clearTimeout(app.undoTimer);
      els.undoRow.hidden = true;
      await loadState();
      setStatus('Restored as unread.', 'success');
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      els.undo.disabled = false;
    }
  }

  async function refreshAll() {
    busy('refresh-all', true);
    setStatus('Checking your sources…');
    try {
      const result = await request('refresh-all');
      await loadState();
      const rows = result.results || [];
      const added = rows.reduce((sum, row) => sum + (Number(row.added) || 0), 0);
      const decisions = rows.filter(row => ['moved', 'permission'].includes(row.outcome)).length;
      const problems = rows.filter(row => row.error || ['error', 'throttled'].includes(row.outcome)).length;
      const skipped = rows.filter(row => row.skipped).length;
      if (added) setStatus(`${added} new update${added === 1 ? '' : 's'} found${problems || decisions ? ` · ${problems + decisions} source${problems + decisions === 1 ? '' : 's'} need attention` : ''}.`, 'success');
      else if (decisions) setStatus(`No new updates · ${decisions} source${decisions === 1 ? '' : 's'} need a decision.`, 'error');
      else if (problems) setStatus(`No new updates · ${problems} source${problems === 1 ? '' : 's'} need attention.`, 'error');
      else if (skipped) setStatus(`No new updates. ${skipped} source${skipped === 1 ? '' : 's'} still need site access.`, 'success');
      else setStatus('No new updates. You’re caught up.', 'success');
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      busy('refresh-all', false);
    }
  }

  async function refreshSource(sourceId, button) {
    const source = app.state.sources.find(row => row.id === sourceId);
    if (source && !await askPermission(source.url, source.watchStability
      ? 'The held page result is still waiting for another check. No alert or source change was created.'
      : 'The source was not checked. Nothing changed.')) return;
    button.disabled = true;
    button.textContent = 'Checking…';
    try {
      const result = await request('refresh-source', {sourceId});
      await loadState();
      setStatus(result.added ? `${result.added} new update${result.added === 1 ? '' : 's'} found.` : 'That source is up to date.', 'success');
    } catch (error) {
      await loadState().catch(() => {});
      setStatus(error.message, 'error');
    } finally {
      button.disabled = false;
      button.textContent = 'Refresh';
    }
  }

  async function toggleSource(sourceId, enabled, button) {
    const source = app.state.sources.find(row => row.id === sourceId);
    if (enabled && source && !await askPermission(source.url, 'The source stayed paused. Nothing changed.')) return;
    button.disabled = true;
    try {
      await request('toggle-source', {sourceId, enabled});
      await loadState();
      setStatus(enabled ? 'Source resumed. It is ready to refresh.' : 'Source paused.', 'success');
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      button.disabled = false;
    }
  }

  async function acceptSourceMove(source, button) {
    const move = source.pendingRedirect;
    if (!move || !await askMovePermissions(move.from || source.url, move.to)) return;
    button.disabled = true;
    const old = button.textContent;
    button.textContent = 'Verifying move…';
    try {
      const result = await request('accept-source-redirect', {sourceId: source.id, from: move.from || source.url, to: move.to});
      await loadState();
      setStatus(result.recovered ? 'The old address is working again. Nothing moved.' : 'Source moved and checked at its new address.', 'success');
    } catch (error) {
      await loadState().catch(() => {});
      setStatus(error.message, 'error');
      button.disabled = false;
      button.textContent = old;
    }
  }

  async function reconnectSource(source, button) {
    if (!await askPermission(source.url, 'The source still needs reconnecting. Nothing changed.')) return;
    button.disabled = true;
    const old = button.textContent;
    button.textContent = 'Reconnecting…';
    try {
      await request('toggle-source', {sourceId: source.id, enabled: true});
      const result = await request('refresh-source', {sourceId: source.id});
      await loadState();
      setStatus(result.added ? `Reconnected · ${result.added} new update${result.added === 1 ? '' : 's'} found.` : 'Reconnected. This source is up to date.', 'success');
    } catch (error) {
      await loadState().catch(() => {});
      setStatus(error.message, 'error');
      button.disabled = false;
      button.textContent = old;
    }
  }

  async function archiveSource(source, button) {
    const confirmed = confirm(`Archive “${text(source.title, 'this source')}”? Its saved updates stay in ProgRSS.`);
    if (!confirmed) return;
    button.disabled = true;
    try {
      await request('archive-source', {sourceId: source.id});
      await loadState();
      setStatus('Source archived. Its saved history is still here.', 'success');
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      button.disabled = false;
    }
  }

  function permissionPattern(raw) {
    const url = new URL(raw);
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Use a normal http or https address.');
    return `${url.origin}/*`;
  }

  function permissionDecisionStatus(raws, consequence) {
    const labels = [...new Set((Array.isArray(raws) ? raws : [raws]).map(raw => {
      try { return new URL(raw).host; } catch { return ''; }
    }).filter(Boolean))];
    const subject = labels.length === 1
      ? labels[0]
      : labels.length === 2
        ? `${labels[0]} and ${labels[1]}`
        : `${labels.length || 'the requested'} sites`;
    const lead = labels.length === 1
      ? `The browser did not grant the requested ProgRSS site access for ${subject}.`
      : `The browser did not grant all requested ProgRSS site access for ${subject}.`;
    setStatus(`${lead} ${consequence}`, 'decision');
  }

  async function askPermission(raw, consequence = 'The requested action was not completed. Nothing changed.') {
    try {
      const origins = [permissionPattern(raw)];
      // Keep request() as the first asynchronous extension call in the click path.
      // Browsers require optional permissions to be requested from a user gesture.
      const granted = await api.permissions.request({origins});
      if (!granted) permissionDecisionStatus([raw], consequence);
      return granted;
    } catch (error) {
      setStatus(`Site access could not be requested: ${text(error?.message || error)}`, 'error');
      return false;
    }
  }

  async function checkSelectedSharedFolderUpdate(button = els.checkSharedFolderUpdate) {
    const share = currentFolderShare();
    const updateUrl = canonicalAddress(share?.origin?.updateUrl);
    if (!share || !updateUrl || app.busy.has('shared-folder-remote-check')) return;
    // Keep the permission request as the first awaited operation in this click path.
    if (!await askPermission(updateUrl, 'The later copy was not checked. The local shared folder was kept.')) return;
    const original = button.textContent;
    button.disabled = true;
    button.textContent = 'Checking…';
    busy('shared-folder-remote-check', true);
    app.sharedFolder = {
      fileName: new URL(updateUrl).hostname || 'Shared-folder address',
      loading: true,
      remoteAttempt: true,
      targetRootId: share.collectionId
    };
    els.sharedFolderCard.hidden = false;
    setView('add', {focus: true});
    renderSharedFolder();
    try {
      const result = await request('check-shared-folder-update', {collectionId: share.collectionId});
      app.sharedFolder = {
        fileName: new URL(result.remote?.finalUrl || updateUrl).hostname || 'Shared-folder address',
        raw: result.raw,
        preview: result.preview,
        remote: result.remote,
        trustAcknowledged: false
      };
      setStatus('Future copy checked only because you asked. Nothing changed yet.', 'success');
    } catch (error) {
      const detail = error?.detail || {};
      const moved = error?.code === 'CROSS_ORIGIN_REDIRECT' && detail.destinationHost;
      app.sharedFolder = {
        fileName: new URL(updateUrl).hostname || 'Shared-folder address',
        error: moved
          ? `This update address moved to ${detail.destinationHost}. ProgRSS stopped before contacting that site. Ask for a new shared copy or import one from a file.`
          : error.message,
        remoteAttempt: true,
        targetRootId: share.collectionId
      };
      setStatus(app.sharedFolder.error, 'error');
    } finally {
      button.disabled = false;
      button.textContent = original;
      busy('shared-folder-remote-check', false);
      renderSharedFolder();
    }
  }

  async function reviewDiscoveredSharedFolder(candidate, page, button) {
    const url = canonicalAddress(candidate?.url);
    const pageUrl = canonicalAddress(page?.url);
    if (!url || !pageUrl || app.busy.has('shared-folder-page-review')) return;
    // Keep the permission request as the first awaited operation in this click path.
    if (!await askPermission(url, 'The shared folder was not opened. Nothing was added.')) return;
    const original = button.textContent;
    button.disabled = true;
    button.textContent = 'Opening review…';
    busy('shared-folder-page-review', true);
    app.sharedFolder = {
      fileName: text(candidate?.title, new URL(url).hostname || 'Shared-folder address'),
      loading: true,
      remoteAttempt: true,
      returnToDiscovery: true,
      returnContext: 'page'
    };
    els.sharedFolderCard.hidden = false;
    renderSharedFolder();
    try {
      const result = await request('review-shared-folder-url', {url, pageUrl});
      app.sharedFolder = {
        fileName: text(candidate?.title, new URL(result.remote?.finalUrl || url).hostname || 'Shared-folder address'),
        raw: result.raw,
        preview: result.preview,
        remote: result.remote,
        returnToDiscovery: true,
        returnContext: 'page',
        trustAcknowledged: false
      };
      setStatus('Shared folder opened for review only because you asked. Nothing changed yet.', 'success');
    } catch (error) {
      const detail = error?.detail || {};
      const moved = error?.code === 'CROSS_ORIGIN_REDIRECT' && detail.destinationHost;
      app.sharedFolder = {
        fileName: text(candidate?.title, new URL(url).hostname || 'Shared-folder address'),
        error: moved
          ? `The advertised file moved to ${detail.destinationHost}. ProgRSS stopped before contacting that site.`
          : error.message,
        remoteAttempt: true,
        returnToDiscovery: true,
        returnContext: 'page'
      };
      setStatus(app.sharedFolder.error, 'error');
    } finally {
      button.disabled = false;
      button.textContent = original;
      busy('shared-folder-page-review', false);
      renderSharedFolder();
      requestAnimationFrame(() => $('#shared-folder-review-heading')?.focus());
    }
  }

  async function askMovePermissions(from, to) {
    const origins = [...new Set([permissionPattern(from), permissionPattern(to)])];
    try {
      // This must remain the first awaited operation in the move-review button path.
      const granted = await api.permissions.request({origins});
      if (!granted) permissionDecisionStatus([from, to], 'The current source address was kept. No destination was contacted.');
      return granted;
    } catch (error) {
      setStatus(`Site access could not be requested: ${text(error?.message || error)}`, 'error');
      return false;
    }
  }

  async function askImportPermissions(origins) {
    const patterns = origins.map(permissionPattern);
    try {
      // This must remain the first awaited operation in the Import button path.
      const granted = await api.permissions.request({origins: patterns});
      if (!granted) permissionDecisionStatus(origins, 'The file was not imported. Add paused remains available without site access.');
      return granted;
    } catch (error) {
      setStatus(`Site access could not be requested: ${text(error?.message || error)}`, 'error');
      return false;
    }
  }

  function restoreDiscovery(parent, focusId = '') {
    if (!parent) return;
    app.discovery = parent;
    renderDiscovery();
    if (focusId) requestAnimationFrame(() => document.getElementById(focusId)?.focus());
  }

  function discoveryBackButton(discovery, label = '') {
    if (!discovery?.returnDiscovery) return null;
    const resolvedLabel = label || (discovery.returnDiscovery?.kind === 'exchange' ? 'Back to shared route choices' : 'Back to page options');
    const back = h('button', {class: 'quiet-button wide discovery-back', type: 'button', text: resolvedLabel});
    back.addEventListener('click', () => restoreDiscovery(discovery.returnDiscovery, discovery.returnFocusId || ''));
    return back;
  }

  function previewContentSummary(discovery, count) {
    const full = Math.max(0, Number(discovery?.previewFullTextCount) || 0);
    const summaries = Math.max(0, Number(discovery?.previewSummaryCount) || 0);
    if (!count) return 'This response did not include any items. You can still follow the feed and wait for a future update.';
    if (full === 1) return 'One of these examples includes fuller feed text for focused reading inside ProgRSS.';
    if (full > 1) return `${full} of these examples include fuller feed text for focused reading inside ProgRSS.`;
    if (summaries) return 'These examples include feed summaries. Open original remains available after following.';
    return 'These examples include titles only. Open original remains available after following.';
  }


  function renderExchangeDiscovery(exchange) {
    const document = exchange?.document;
    if (!document) return;
    const card = h('section', {class: 'discovery-card exchange-review-card', 'aria-labelledby': 'exchange-review-heading'});
    const heading = h('div', {class: 'exchange-review-heading'});
    const headingCopy = h('div');
    headingCopy.append(
      h('p', {class: 'exchange-kicker', text: 'One reviewed route · three choices'}),
      h('h3', {id: 'exchange-review-heading', tabindex: '-1', text: `How do you want to use “${text(document.title, 'Shared route')}”?`}),
    );
    heading.append(headingCopy, h('span', {class: 'exchange-expiry', text: `Expires ${relativeTime(document.expiresAt)}`}));
    card.append(heading);
    if (document.curator) card.append(h('p', {class: 'exchange-curator', text: `Shared by ${document.curator}` }));
    if (document.note) {
      const note = h('blockquote', {class: 'exchange-note'});
      note.append(h('span', {class: 'exchange-note-label', text: 'Why this route matters'}), h('p', {text: document.note}));
      card.append(note);
    }
    card.append(h('p', {text: 'Choose the result you want. Reviewing this handoff has not followed a feed, imported a source, contacted any listed site, or connected your library to the sender.'}));

    const stats = h('div', {class: 'exchange-stats', ariaLabel: 'Shared route contents'});
    stats.append(
      h('span', {}, [h('strong', {text: String(document.counts.sources)}), document.counts.sources === 1 ? ' source' : ' sources']),
      h('span', {}, [h('strong', {text: String(document.counts.feeds)}), document.counts.feeds === 1 ? ' feed' : ' feeds']),
      h('span', {}, [h('strong', {text: String(document.counts.pageWatches)}), document.counts.pageWatches === 1 ? ' watched page' : ' watched pages']),
      h('span', {}, [h('strong', {text: String(document.counts.folders)}), document.counts.folders === 1 ? ' folder' : ' folders']),
    );
    if (Number(document.counts.sourceNotes) > 0) stats.append(
      h('span', {}, [h('strong', {text: String(document.counts.sourceNotes)}), Number(document.counts.sourceNotes) === 1 ? ' curator reason' : ' curator reasons']),
    );
    card.append(stats);

    const choices = h('section', {class: 'exchange-choices', 'aria-labelledby': 'exchange-choices-heading'});
    choices.append(h('h4', {id: 'exchange-choices-heading', text: 'Choose one door'}));

    const followChoice = document.choices.followUpdates;
    const followCard = h('article', {class: `exchange-choice ${followChoice.available ? '' : 'unavailable'}`.trim()});
    followCard.append(
      h('p', {class: 'exchange-choice-number', text: '01'}),
      h('h5', {text: 'Follow updates'}),
      h('p', {text: 'Add one ordinary summary feed. The underlying feeds, watched pages, and folders stay out of your library.'}),
    );
    const follow = h('button', {id: 'exchange-follow-updates', class: 'primary wide', type: 'button', text: 'Preview recent updates', disabled: !followChoice.available});
    follow.addEventListener('click', () => followExchangeUpdates(exchange, follow));
    followCard.append(follow);
    if (!followChoice.available) followCard.append(h('p', {class: 'field-help', text: text(followChoice.reason, 'The sender did not publish a durable updates feed.')}));

    const routeCard = h('article', {class: 'exchange-choice featured'});
    routeCard.append(
      h('p', {class: 'exchange-choice-number', text: '02'}),
      h('h5', {text: 'Add the complete route'}),
      h('p', {text: 'Review every shared feed, watched-page recipe, and folder. Existing sources are reused; new sources start paused.'}),
    );
    const route = h('button', {id: 'exchange-add-route', class: 'primary wide', type: 'button', text: 'Review complete route'});
    route.addEventListener('click', () => useExchangeSourceList(exchange, '', route));
    routeCard.append(route);

    const branches = Array.isArray(document.choices.takeBranch?.branches) ? document.choices.takeBranch.branches : [];
    const branchCard = h('article', {class: `exchange-choice ${branches.length ? '' : 'unavailable'}`.trim()});
    branchCard.append(
      h('p', {class: 'exchange-choice-number', text: '03'}),
      h('h5', {text: 'Take one branch'}),
      h('p', {text: 'Adopt one selected folder section as an independent local route. It will not silently track future copies of the parent publication.'}),
    );
    if (branches.length) {
      const id = `exchange-branch-${Math.random().toString(36).slice(2, 9)}`;
      const label = h('label', {for: id, text: 'Folder branch'});
      const select = h('select', {id, class: 'exchange-branch-select'});
      branches.forEach(branch => {
        const sourceNotes = Number(branch.sourceNotes) || 0;
        const noteLabel = sourceNotes ? ` · ${sourceNotes} curator reason${sourceNotes === 1 ? '' : 's'}` : '';
        select.append(h('option', {value: branch.id, text: `${branch.path} · ${branch.sources} source${branch.sources === 1 ? '' : 's'}${noteLabel}`}));
      });
      const branch = h('button', {id: 'exchange-take-branch', class: 'secondary wide', type: 'button', text: 'Review selected branch'});
      branch.addEventListener('click', () => useExchangeSourceList(exchange, select.value, branch));
      branchCard.append(label, select, branch);
    } else {
      branchCard.append(h('button', {class: 'secondary wide', type: 'button', text: 'No separate branch available', disabled: true}));
    }
    choices.append(followCard, routeCard, branchCard);
    card.append(choices);

    const contents = h('details', {class: 'exchange-contents'});
    const sourceNotes = Number(document.counts.sourceNotes) || 0;
    const sourceNoteSummary = sourceNotes ? ` · ${sourceNotes} curator reason${sourceNotes === 1 ? '' : 's'}` : '';
    contents.append(h('summary', {text: `See what is inside · ${document.counts.sources} source${document.counts.sources === 1 ? '' : 's'}${sourceNoteSummary}`}));
    const sourceList = h('ul', {class: 'exchange-source-list'});
    (document.contents.sources || []).forEach(source => {
      const row = h('li');
      row.append(
        h('strong', {text: text(source.title, 'Untitled source')}),
        h('span', {text: `${source.type === 'page' ? 'Watched page' : 'Feed'}${source.host ? ` · ${source.host}` : ''}`}),
      );
      const placements = Array.isArray(source.placements) ? source.placements : [];
      if (placements.length) {
        const placementList = h('div', {class: 'exchange-placement-list'});
        placements.forEach(placement => {
          const placementRow = h('div', {class: 'exchange-placement'});
          placementRow.append(h('small', {class: 'exchange-placement-route', text: `In ${text(placement.folderPath, 'folder route unavailable')}`}));
          if (typeof placement.reason === 'string' && placement.reason) {
            placementRow.append(h('p', {class: 'exchange-source-note'}, [
              h('strong', {text: 'Curator’s reason for this folder'}),
              h('span', {dir: 'auto', text: placement.reason}),
            ]));
          }
          placementList.append(placementRow);
        });
        row.append(placementList);
      } else {
        const routes = Array.isArray(source.folders) ? source.folders.filter(Boolean) : [];
        if (routes.length) row.append(h('small', {text: `In ${routes.join(' · ')}`}));
      }
      sourceList.append(row);
    });
    contents.append(sourceList);
    if (sourceNotes) contents.append(h('p', {class: 'exchange-source-note-boundary', text: 'Curator reasons explain why a source appears in a particular folder. They are not a ProgRSS safety claim.'}));
    if (Number(document.contents.sourcesOmitted) > 0) contents.append(h('p', {class: 'field-help', text: `${document.contents.sourcesOmitted} more source${document.contents.sourcesOmitted === 1 ? '' : 's'} remain in the checked artifact.`}));
    card.append(contents);

    const privacy = h('details', {class: 'exchange-privacy'});
    privacy.append(h('summary', {text: 'What stays private'}));
    const excluded = h('ul');
    (document.privacy?.excluded || []).forEach(value => excluded.append(h('li', {text: value})));
    privacy.append(h('p', {text: 'This handoff intentionally excludes:'}), excluded);
    card.append(privacy);

    const advanced = h('details', {class: 'exchange-advanced'});
    advanced.append(h('summary', {text: 'Advanced handoff evidence'}));
    const facts = h('dl', {class: 'node-facts'});
    facts.append(
      nodeFact('Node', document.node.origin),
      nodeFact('Node session', compactNodeFingerprint(document.node.instanceFingerprint)),
      nodeFact('Library copy', document.library.file),
      nodeFact('Library SHA-256', document.library.sha256),
      nodeFact('Source-list SHA-256', document.artifacts.sourceList.sha256),
      nodeFact('Handoff ID', document.exchangeId),
    );
    advanced.append(facts, h('p', {class: 'field-help', text: 'These values identify the exact reviewed bytes and running Node session. They do not prove that the curator’s wording is true or that every listed site is safe.'}));
    card.append(advanced);

    const close = h('button', {class: 'quiet-button wide exchange-close', type: 'button', text: 'Close without using it'});
    close.addEventListener('click', () => cancelExchangeReview(exchange));
    card.append(close, h('p', {class: 'field-help exchange-boundary', text: 'The handoff expires, can be revoked by the sender, and grants no write access to either library.'}));
    els.discovery.append(card);
  }

  function renderDiscovery() {
    els.discovery.replaceChildren();
    const discovery = app.discovery;
    if (!discovery) return;
    if (discovery.loading) {
      const card = h('div', {class: 'discovery-card'});
      card.append(h('h3', {text: 'Looking for something to follow…'}));
      card.append(h('p', {text: 'ProgRSS is checking only the address you chose.'}));
      els.discovery.append(card);
      return;
    }
    if (discovery.kind === 'redirect' && discovery.redirect) {
      const move = discovery.redirect;
      const card = h('section', {class: 'discovery-card redirect-review', 'aria-labelledby': 'discovery-redirect-heading'});
      card.append(h('h3', {id: 'discovery-redirect-heading', text: 'This address moved to another site'}));
      card.append(h('p', {text: `It now points to ${text(move.destinationHost, 'another site')}. ProgRSS stopped before contacting that site.`}));
      const addresses = h('div', {class: 'address-pair'});
      addresses.append(addressRow('From', text(move.from || discovery.originalUrl)), addressRow('To', text(move.to)));
      card.append(addresses);
      const proceed = h('button', {class: 'primary wide', type: 'button', text: `Continue to ${text(move.destinationHost, 'new site')}`});
      proceed.addEventListener('click', () => continueRedirect(discovery, proceed));
      const cancel = h('button', {class: 'quiet-button wide', type: 'button', text: discovery.returnDiscovery ? 'Back to page options' : 'Do not continue'});
      cancel.addEventListener('click', () => {
        if (discovery.returnDiscovery) restoreDiscovery(discovery.returnDiscovery, discovery.returnFocusId || '');
        else { app.discovery = null; renderDiscovery(); els.address.focus(); }
      });
      card.append(proceed, cancel);
      els.discovery.append(card);
      return;
    }
    if (discovery.error) {
      const card = h('div', {class: 'discovery-card'});
      card.append(h('h3', {text: 'That did not work'}));
      card.append(h('p', {text: discovery.error}));
      const back = discoveryBackButton(discovery);
      if (back) card.append(back);
      els.discovery.append(card);
      return;
    }

    if (discovery.kind === 'exchange' && discovery.exchange) {
      renderExchangeDiscovery(discovery.exchange);
      return;
    }

    if (discovery.kind === 'capture' && discovery.capture) {
      renderCaptureDiscovery(discovery.capture);
      return;
    }

    const page = discovery.page || null;
    if (discovery.kind === 'shared-folder') {
      const card = h('section', {class: 'discovery-card page-shared-folder', 'aria-labelledby': 'direct-shared-folder-heading'});
      card.append(
        h('h3', {id: 'direct-shared-folder-heading', text: 'Source list found'}),
        h('p', {text: `${text(discovery.title, 'This source list')} contains feeds, watched pages, and folders for ProgRSS.`}),
        h('p', {text: 'ProgRSS checked the file structure and integrity. Nothing has been added, scheduled, or contacted beyond the address you chose.'})
      );
      const review = h('button', {class: 'primary wide', type: 'button', text: 'Review source list'});
      review.addEventListener('click', () => {
        let label = text(discovery.title, 'Shared-folder address');
        try { label = `${label} · ${new URL(discovery.url).host}`; } catch {}
        app.sharedFolder = {
          fileName: label,
          raw: discovery.raw,
          preview: discovery.preview,
          remote: discovery.remote || {automatic: false, directAddress: true},
          returnToDiscovery: true,
          returnContext: 'address',
          trustAcknowledged: false
        };
        els.sharedFolderCard.hidden = false;
        renderSharedFolder();
        requestAnimationFrame(() => $('#shared-folder-review-heading')?.focus());
      });
      card.append(review, h('p', {class: 'field-help', text: 'Review is local. Adding it remains a separate decision, and any new sources start paused.'}));
      els.discovery.append(card);
      return;
    }
    if (discovery.kind === 'feed') {
      const card = h('section', {class: 'discovery-card feed-preview', 'aria-labelledby': 'feed-preview-heading'});
      const heading = markNaturalText(h('h3', {id: 'feed-preview-heading', tabindex: '-1', text: text(discovery.title, 'Feed preview')}), discovery.titleLanguage || discovery.language);
      card.append(heading);
      const existing = discovery.existingSource;
      if (existing && !existing.archived) {
        const reason = existing.match === 'declared-self'
          ? `This address identifies the same feed you already follow as ${text(existing.title, 'a source')}.`
          : `You already follow this feed as ${text(existing.title, 'a source')}.`;
        card.append(h('p', {text: `${reason} ProgRSS will not add a duplicate.`}));
        const actions = h('div', {class: 'feed-preview-actions'});
        const view = h('button', {class: 'primary wide', type: 'button', text: 'View source'});
        view.addEventListener('click', () => openSourceDetails(existing.id));
        actions.append(view);
        const back = discoveryBackButton(discovery);
        if (back) actions.append(back);
        card.append(actions);
        els.discovery.append(card);
        return;
      }

      const edition = discovery.edition && discovery.edition.schema === 'progrss.folder-edition.v1' ? discovery.edition : null;
      if (edition) {
        card.append(
          h('p', {class: 'publication-feed-note', text: `This is one summary feed prepared from the source list “${text(edition.folder, 'Untitled source list')}”. Following it adds only this feed. It does not add the underlying feeds or watched pages.`}),
          h('p', {class: 'field-help', text: 'It is a manual snapshot. New editions appear only when the curator prepares and publishes them.'})
        );
      }
      const itemCount = Math.max(0, Number(discovery.itemCount) || 0);
      card.append(h('p', {text: `${itemCount} item${itemCount === 1 ? '' : 's'} in this feed response. Nothing has been followed yet.`}));
      const examples = Array.isArray(discovery.previewItems) ? discovery.previewItems.slice(0, 3) : [];
      if (examples.length) {
        const sampleHeading = h('h4', {class: 'feed-preview-label', text: 'A few items from this feed'});
        const list = h('ul', {class: 'feed-preview-items', ariaLabel: 'Example items from this feed'});
        examples.forEach(example => {
          const title = markNaturalText(h('span', {class: 'feed-preview-title', text: text(example?.title, 'Untitled update')}), example?.titleLanguage || example?.language || discovery.language);
          const when = example?.published ? relativeTime(example.published) : 'No date supplied';
          list.append(h('li', {}, [title, h('span', {class: 'feed-preview-time', text: when})]));
        });
        card.append(sampleHeading, list);
      }
      card.append(h('p', {class: 'field-help feed-preview-content-note', text: previewContentSummary(discovery, examples.length)}));
      card.append(h('p', {class: 'field-help', text: 'The preview uses feed-supplied titles and dates only. It loads no article page, image, script, frame, or embedded media.'}));

      const actions = h('div', {class: 'feed-preview-actions'});
      const followLabel = edition ? 'Follow recent updates' : (existing?.archived ? 'Follow this feed again' : 'Follow this feed');
      const follow = h('button', {class: 'primary wide', type: 'button', text: followLabel});
      follow.addEventListener('click', () => addChosen({url: discovery.url, feedUrl: discovery.feedUrl, title: discovery.title, titleLanguage: discovery.titleLanguage, language: discovery.language, type: 'rss'}, follow, {permissionGranted: Boolean(discovery.permissionGranted)}));
      actions.append(follow);
      const back = discoveryBackButton(discovery);
      if (back) actions.append(back);
      card.append(actions);
      els.discovery.append(card);
      return;
    }

    const intro = h('div', {class: 'discovery-card'});
    intro.append(h('h3', {text: text(page?.title || discovery.title, 'Page found')}));
    const candidates = Array.isArray(discovery.candidates) ? discovery.candidates : [];
    const sharedFolders = Array.isArray(discovery.sharedFolders) ? discovery.sharedFolders : [];
    const publication = discovery.publicationChoices?.schema === 'progrss.publication-choices.v1' ? discovery.publicationChoices : null;
    const publicationFeedUrl = publication?.recentUpdates?.url || '';
    const otherCandidates = publicationFeedUrl ? candidates.filter(row => row?.url !== publicationFeedUrl) : candidates;
    intro.append(h('p', {text: publication
      ? 'This publication offers two different choices. Choose the source list to bring its underlying sources into ProgRSS, or choose recent updates to follow one summary feed.'
      : (sharedFolders.length
        ? `${sharedFolders.length === 1 ? 'A source list is' : `${sharedFolders.length} source lists are`} available${candidates.length ? `, along with ${candidates.length} likely feed${candidates.length === 1 ? '' : 's'}` : ''}.`
        : (candidates.length ? `${candidates.length} likely feed${candidates.length === 1 ? '' : 's'} found.` : 'No clear feed or ProgRSS source list was found on this page.'))}));
    if (publication) {
      const choices = h('section', {class: 'publication-choices', 'aria-labelledby': 'publication-choices-heading'});
      choices.append(h('h4', {id: 'publication-choices-heading', text: 'Choose what you want'}));
      const sourceChoice = h('div', {class: 'publication-choice'});
      sourceChoice.append(
        h('h5', {text: 'Add the source list'}),
        h('p', {text: 'Review its feeds, watched pages, and folders. Existing sources are reused; new sources start paused.'})
      );
      const review = h('button', {class: 'primary wide', type: 'button', text: 'Review source list'});
      review.addEventListener('click', () => reviewDiscoveredSharedFolder(publication.sourceList, page || {url: discovery.url}, review));
      sourceChoice.append(review);
      const updatesChoice = h('div', {class: 'publication-choice'});
      updatesChoice.append(
        h('h5', {text: 'Follow recent updates'}),
        h('p', {text: 'Preview one summary feed. Following it adds only that feed—not the publication’s underlying sources or page watches.'})
      );
      const preview = h('button', {id: 'publication-updates-candidate', class: 'secondary wide', type: 'button', text: 'Preview recent updates'});
      const existing = publication.recentUpdates?.existingSource;
      preview.textContent = existing && !existing.archived ? `View ${text(existing.title, 'recent updates')} · already following` : 'Preview recent updates';
      preview.addEventListener('click', () => existing && !existing.archived ? openSourceDetails(existing.id) : previewCandidate(publication.recentUpdates, preview));
      updatesChoice.append(preview);
      choices.append(sourceChoice, updatesChoice, h('p', {class: 'field-help', text: 'Neither choice contacts any listed source until you make the later follow or import decision.'}));
      intro.append(choices);
    } else if (sharedFolders.length) {
      const shared = h('section', {class: 'page-shared-folder', 'aria-labelledby': 'page-shared-folder-heading'});
      shared.append(
        h('h4', {id: 'page-shared-folder-heading', text: sharedFolders.length === 1 ? 'Source list available' : 'Source lists available'}),
        h('p', {text: 'This page publishes a portable list of feeds and watched pages. ProgRSS will verify and explain it before adding anything.'})
      );
      sharedFolders.slice(0, 4).forEach((candidate, index) => {
        const review = h('button', {
          class: index === 0 ? 'primary wide' : 'secondary wide',
          type: 'button',
          text: sharedFolders.length === 1 ? 'Review source list' : `Review ${text(candidate.title, `source list ${index + 1}`)}`
        });
        review.addEventListener('click', () => reviewDiscoveredSharedFolder(candidate, page || {url: discovery.url}, review));
        shared.append(review);
      });
      shared.append(h('p', {class: 'field-help', text: 'Review contacts only the advertised file on this site. It does not add sources, schedule checks, or contact any listed source.'}));
      intro.append(shared);
    }
    if (otherCandidates.length) {
      if (publication) intro.append(h('h4', {class: 'other-feeds-heading', text: 'Other feeds on this page'}));
      const list = h('div', {class: 'discovery-list'});
      otherCandidates.slice(0, 8).forEach((candidate, index) => {
        const existing = candidate.existingSource;
        const button = h('button', {
          id: `feed-candidate-${index}`,
          class: index === 0 ? 'primary' : 'secondary', type: 'button',
          text: existing && !existing.archived
            ? `View ${text(existing.title, candidate.title || `Feed ${index + 1}`)} · already following`
            : `Preview ${text(candidate.title, index === 0 ? 'the recommended feed' : `feed ${index + 1}`)}`
        });
        button.addEventListener('click', () => existing && !existing.archived ? openSourceDetails(existing.id) : previewCandidate(candidate, button));
        list.append(button);
      });
      intro.append(list);
    }
    els.discovery.append(intro);

    const watchUrl = page?.url || discovery.url;
    if (watchUrl && !sharedFolders.length) {
      const recommendations = Array.isArray(discovery.recommendations) ? discovery.recommendations.filter(row => row?.kind === 'page').slice(0, 4) : [];
      const cards = recommendations.find(row => row.mode === 'cards');
      const region = recommendations.find(row => row.mode === 'region') || {mode: 'region', selector: ''};
      const watch = h('section', {class: 'discovery-card page-watch-review', 'aria-labelledby': 'page-watch-heading'});
      watch.append(h('h3', {id: 'page-watch-heading', text: 'Watch this page'}));
      if (cards) {
        watch.append(h('p', {text: `ProgRSS found ${Number(cards.count) || 'several'} repeated entries. It can notice entries that appear, disappear, or change without asking you to understand a selector.`}));
        const examples = Array.isArray(cards.examples) ? cards.examples.filter(Boolean).slice(0, 3) : [];
        if (examples.length) {
          const preview = h('ul', {class: 'page-watch-examples', ariaLabel: 'Examples found on this page'});
          examples.forEach(example => preview.append(h('li', {text: example})));
          watch.append(preview);
        }
        const button = h('button', {class: 'primary wide', type: 'button', text: 'Watch new and changed entries'});
        button.addEventListener('click', () => addChosen({
          url: watchUrl, title: page?.title || discovery.title, type: 'page', mode: 'cards',
          selector: cards.selector || '', titleSelector: cards.titleSelector || '', linkSelector: cards.linkSelector || ''
        }, button, {permissionGranted: Boolean(discovery.permissionGranted)}));
        watch.append(button);
      } else {
        watch.append(h('p', {text: 'ProgRSS can notice meaningful changes in the page’s main text. It does not run the page inside the reader.'}));
        if (region.preview) watch.append(h('blockquote', {class: 'page-watch-preview', text: region.preview}));
      }
      const regionButton = h('button', {class: cards ? 'secondary wide' : 'primary wide', type: 'button', text: cards ? 'Watch any main text change' : 'Watch meaningful text changes'});
      regionButton.addEventListener('click', () => addChosen({
        url: watchUrl, title: page?.title || discovery.title, type: 'page', mode: 'region', selector: region.selector || ''
      }, regionButton, {permissionGranted: Boolean(discovery.permissionGranted)}));
      watch.append(regionButton);
      watch.append(h('p', {class: 'field-help', text: 'The first check saves a starting point; it does not invent an old change. Fine-tuning stays in the Advanced Workbench.'}));
      els.discovery.append(watch);
    }
  }

  async function inspectAddress(raw) {
    if (looksLikeCaptureInvitation(raw)) {
      await reviewCaptureInvitation(raw);
      return;
    }
    if (looksLikeExchangeInvitation(raw)) {
      await reviewExchangeInvitation(raw);
      return;
    }
    let url;
    try { url = new URL(raw).href; } catch { setStatus('Enter a complete website address, including https://.', 'error'); return; }
    if (!await askPermission(url, 'The address was not checked. Nothing was added.')) return;
    app.discovery = {loading: true};
    renderDiscovery();
    busy('inspect', true);
    try {
      app.discovery = {...await request('inspect-url', {url}), permissionGranted: true};
    } catch (error) {
      app.discovery = error.code === 'CROSS_ORIGIN_REDIRECT' && error.detail
        ? {kind: 'redirect', redirect: error.detail, originalUrl: url}
        : {error: error.message};
    } finally {
      busy('inspect', false);
      renderDiscovery();
      if (app.discovery?.kind === 'feed') requestAnimationFrame(() => document.getElementById('feed-preview-heading')?.focus());
    }
  }

  async function discoverCurrentPage() {
    busy('discover', true);
    app.discovery = {loading: true};
    renderDiscovery();
    try {
      const result = await request('discover-active');
      app.discovery = {kind: 'html', page: result.page, candidates: result.candidates || [], sharedFolders: result.sharedFolders || [], publicationChoices: result.publicationChoices || null, recommendations: result.recommendations || [], url: result.page?.url, title: result.page?.title};
    } catch (error) {
      app.discovery = {error: error.message};
    } finally {
      busy('discover', false);
      renderDiscovery();
    }
  }

  async function previewCandidate(candidate, button) {
    const url = candidate.url || candidate.href;
    if (!url) return;
    if (!await askPermission(url, 'The feed preview was not opened. Nothing was followed.')) return;
    const returnDiscovery = app.discovery;
    const returnFocusId = button.id || '';
    button.disabled = true;
    const old = button.textContent;
    button.textContent = 'Opening preview…';
    try {
      const inspected = await request('inspect-url', {url});
      if (inspected.kind !== 'feed') throw new Error('That link did not contain a readable feed.');
      app.discovery = {
        ...inspected,
        permissionGranted: true,
        returnDiscovery,
        returnFocusId
      };
      renderDiscovery();
      requestAnimationFrame(() => document.getElementById('feed-preview-heading')?.focus());
    } catch (error) {
      if (error.code === 'CROSS_ORIGIN_REDIRECT' && error.detail) {
        app.discovery = {
          kind: 'redirect', redirect: error.detail, originalUrl: url,
          candidateTitle: candidate.title || '', returnDiscovery, returnFocusId
        };
        renderDiscovery();
      } else {
        setStatus(error.message, 'error');
        button.disabled = false;
        button.textContent = old;
      }
    }
  }

  async function continueRedirect(discovery, button) {
    const target = discovery.redirect?.to;
    if (!target || !await askPermission(target, 'The new site was not checked. The earlier result was kept.')) return;
    const returnDiscovery = discovery.returnDiscovery || null;
    const returnFocusId = discovery.returnFocusId || '';
    button.disabled = true;
    button.textContent = 'Checking new site…';
    app.discovery = {loading: true};
    renderDiscovery();
    busy('inspect', true);
    try {
      app.discovery = {
        ...await request('inspect-url', {url: target}),
        permissionGranted: true,
        ...(returnDiscovery ? {returnDiscovery, returnFocusId} : {})
      };
    } catch (error) {
      app.discovery = error.code === 'CROSS_ORIGIN_REDIRECT' && error.detail
        ? {kind: 'redirect', redirect: error.detail, originalUrl: target, candidateTitle: discovery.candidateTitle || '', ...(returnDiscovery ? {returnDiscovery, returnFocusId} : {})}
        : {error: error.message, ...(returnDiscovery ? {returnDiscovery, returnFocusId} : {})};
    } finally {
      busy('inspect', false);
      renderDiscovery();
      if (app.discovery?.kind === 'feed') requestAnimationFrame(() => document.getElementById('feed-preview-heading')?.focus());
    }
  }

  async function addChosen(source, button, {permissionGranted = false} = {}) {
    if (!permissionGranted && !await askPermission(source.url, 'Nothing was followed.')) return;
    const wasEmpty = !(app.state.sources || []).some(row => !row.archivedAt);
    button.disabled = true;
    const old = button.textContent;
    button.textContent = 'Adding…';
    try {
      const result = await request('add-source', source);
      if (result.alreadyFollowing) {
        await loadState();
        app.discovery = null;
        renderDiscovery();
        setStatus(`You already follow ${text(result.source?.title, 'that source')}. No duplicate was added.`, 'success');
        openSourceDetails(result.source?.id);
        return;
      }
      let refresh = null;
      let refreshError = null;
      try { refresh = await request('refresh-source', {sourceId: result.source.id}); }
      catch (error) { refreshError = error; }
      app.folder = 'all';
      app.search = '';
      els.readingSearch.value = '';
      try { await api.storage.local.set({libraryFolder: 'all'}); } catch {}
      await loadState();
      const savedSource = (app.state.sources || []).find(row => row.id === result.source.id) || result.source;
      const sourceItems = (app.state.items || []).filter(item => item.sourceId === result.source.id);
      const unreadItems = sourceItems.filter(item => !item.readAt);
      app.filter = unreadItems.length || !sourceItems.length ? 'unread' : 'all';
      setFilter(app.filter);
      app.discovery = null;
      renderDiscovery();
      const title = text(savedSource.title, 'this source');
      let message;
      if (refreshError || savedSource.lastError) {
        message = 'The source is saved, but its first check needs attention. Open Source details to retry, reconnect, or review a move.';
      } else if (savedSource.type === 'page') {
        message = 'The first check saved a starting point. Future meaningful page changes will appear in Today.';
      } else if (Number(refresh?.added) > 0) {
        const count = Number(refresh.added);
        message = `${count} update${count === 1 ? ' is' : 's are'} ready below.`;
      } else if (sourceItems.length) {
        message = `${sourceItems.length} retained update${sourceItems.length === 1 ? ' is' : 's are'} ready below.`;
      } else {
        message = 'Nothing new was available on the first check. ProgRSS will keep checking quietly.';
      }
      app.followHandoff = {
        sourceId: savedSource.id,
        heading: wasEmpty ? 'Your first source is ready' : result.restored ? `Following ${title} again` : `Following ${title}`,
        message
      };
      setView('today', {focus: true});
      renderFollowHandoff();
      setStatus(result.restored ? 'Source restored.' : 'Source added.', 'success');
    } catch (error) {
      setStatus(error.message, 'error');
      button.disabled = false;
      button.textContent = old;
    }
  }

  function importStat(value, label) {
    const row = h('div', {class: 'import-stat'});
    row.append(h('strong', {text: String(value)}), h('span', {text: label}));
    return row;
  }

  function resetOpml() {
    app.opml = null;
    els.opmlFile.value = '';
    renderOpml();
  }

  function renderOpml() {
    els.opmlPreview.replaceChildren();
    const opml = app.opml;
    if (!opml) return;
    const review = h('div', {class: 'opml-review'});
    if (opml.loading) {
      review.append(h('h4', {text: 'Reviewing the file…'}));
      review.append(h('p', {text: 'Nothing will be added until you approve the review.'}));
      els.opmlPreview.append(review);
      return;
    }
    if (opml.error) {
      review.append(h('h4', {text: 'That file could not be reviewed'}));
      review.append(h('p', {class: 'import-warning', text: opml.error}));
      const again = h('button', {class: 'secondary wide', type: 'button', text: 'Choose another file'});
      again.addEventListener('click', resetOpml);
      review.append(again);
      els.opmlPreview.append(review);
      return;
    }

    const preview = opml.preview;
    review.append(h('h4', {text: preview.newCount ? `Ready to add ${preview.newCount} feed${preview.newCount === 1 ? '' : 's'}` : 'Nothing new to add'}));
    review.append(h('p', {text: `${text(opml.fileName, 'OPML file')} · reviewed locally`}));
    const stats = h('div', {class: 'import-stats'});
    stats.append(
      importStat(preview.newCount, 'new feeds'),
      importStat(preview.existingCount, 'already here'),
      importStat(preview.duplicateInFileCount + preview.invalidCount, 'duplicates or invalid'),
      importStat(preview.folderCount, 'folders kept')
    );
    review.append(stats);

    if (!preview.canImport) {
      review.append(h('p', {class: 'import-warning', text: preview.reason}));
    } else {
      if (preview.folderCount) review.append(h('p', {text: 'Simple folders will appear in Today and Sources. Advanced collection controls stay in the Workbench.'}));
      const options = h('fieldset', {class: 'import-options'});
      options.append(h('legend', {text: 'How should these feeds start?'}));
      const activeDisabled = preview.originCount > MAX_ACTIVE_IMPORT_ORIGINS;
      const active = h('label', {class: `import-option${activeDisabled ? ' disabled' : ''}`});
      const activeInput = h('input', {
        type: 'radio', name: 'opml-mode', value: 'active',
        checked: opml.mode === 'active', disabled: activeDisabled
      });
      const activeCopy = h('span');
      activeCopy.append(
        h('strong', {text: 'Start following now'}),
        h('span', {text: activeDisabled
          ? `This file spans ${preview.originCount} sites, so it must start paused.`
          : `Ask for access to ${preview.originCount} site${preview.originCount === 1 ? '' : 's'}, then check a bounded first batch.`})
      );
      active.append(activeInput, activeCopy);
      const paused = h('label', {class: 'import-option'});
      const pausedInput = h('input', {type: 'radio', name: 'opml-mode', value: 'paused', checked: opml.mode !== 'active'});
      const pausedCopy = h('span');
      pausedCopy.append(h('strong', {text: 'Add paused'}), h('span', {text: 'No site access now. Resume individual sources when you are ready.'}));
      paused.append(pausedInput, pausedCopy);
      options.append(active, paused);
      review.append(options);

      const actions = h('div', {class: 'import-actions'});
      const importButton = h('button', {
        class: 'primary wide', type: 'button',
        text: opml.mode === 'active' ? `Add and check ${preview.newCount}` : `Add ${preview.newCount} paused`
      });
      activeInput.addEventListener('change', () => {
        if (activeInput.checked) { app.opml.mode = 'active'; importButton.textContent = `Add and check ${preview.newCount}`; }
      });
      pausedInput.addEventListener('change', () => {
        if (pausedInput.checked) { app.opml.mode = 'paused'; importButton.textContent = `Add ${preview.newCount} paused`; }
      });
      importButton.addEventListener('click', () => importReviewedOpml(importButton));
      const another = h('button', {class: 'quiet-button wide', type: 'button', text: 'Choose another file'});
      another.addEventListener('click', resetOpml);
      actions.append(importButton, another);
      review.append(actions);
    }
    els.opmlPreview.append(review);
  }

  async function reviewOpmlFile(file) {
    if (!file) return;
    els.opmlCard.hidden = false;
    if (file.size > MAX_OPML_BYTES) {
      app.opml = {fileName: file.name, error: 'That file is larger than the 2 MB safety limit.'};
      renderOpml();
      return;
    }
    app.opml = {fileName: file.name, loading: true};
    renderOpml();
    busy('opml', true);
    try {
      const raw = await file.text();
      if (new TextEncoder().encode(raw).byteLength > MAX_OPML_BYTES) throw new Error('That file is larger than the 2 MB safety limit.');
      const preview = await request('preview-opml', {raw});
      const large = preview.newCount > 20 || preview.originCount > 10;
      app.opml = {fileName: file.name, raw, preview, mode: large ? 'paused' : 'active'};
    } catch (error) {
      app.opml = {fileName: file.name, error: error.message};
    } finally {
      busy('opml', false);
      renderOpml();
    }
  }

  async function importReviewedOpml(button) {
    const opml = app.opml;
    if (!opml?.preview?.canImport || !opml.raw) return;
    const paused = opml.mode !== 'active';
    if (!paused && !await askImportPermissions(opml.preview.origins)) return;
    button.disabled = true;
    button.textContent = paused ? 'Adding…' : 'Adding and checking…';
    busy('opml', true);
    try {
      const result = await request('import-opml', {raw: opml.raw, paused});
      let checked = 0;
      let addedUpdates = 0;
      if (!paused && result.sourceIds?.length) {
        const refresh = await request('refresh-sources', {sourceIds: result.sourceIds});
        checked = refresh.checked || 0;
        addedUpdates = (refresh.results || []).reduce((sum, row) => sum + (Number(row.added) || 0), 0);
      }
      await loadState();
      resetOpml();
      setView(paused ? 'sources' : 'today', {focus: true});
      if (paused) {
        setStatus(`${result.added} feed${result.added === 1 ? '' : 's'} added paused. Resume any source when you are ready.`, 'success');
      } else {
        const remaining = Math.max(0, result.added - checked);
        setStatus(`${result.added} feed${result.added === 1 ? '' : 's'} added · ${addedUpdates} update${addedUpdates === 1 ? '' : 's'} found${remaining ? ` · ${remaining} will be checked gradually` : ''}.`, 'success');
      }
    } catch (error) {
      setStatus(error.message, 'error');
      button.disabled = false;
      renderOpml();
    } finally {
      busy('opml', false);
    }
  }

  function resetSharedFolder() {
    app.sharedFolder = null;
    els.sharedFolderFile.value = '';
    renderSharedFolder();
  }

  function appendSharedFolderProvenance(container, preview) {
    const provenance = h('div', {class: 'shared-folder-provenance'});
    if (preview.signatureState === 'verified') {
      provenance.append(
        h('p', {}, [h('strong', {text: 'Signature verified'}), document.createTextNode(preview.curator ? ` · shown as ${preview.curator}` : ' · no curator name supplied')]),
        h('p', {text: `Signing key ${preview.fingerprint || compactFingerprint(preview.keyId)}`}),
        h('p', {class: 'field-help', text: preview.independentExcerpt
          ? 'The matching private key signed the complete checked source list. This selected section is a local excerpt, not a separately signed publication. The signature does not prove the curator’s real-world identity or that every source is safe.'
          : 'This proves that the matching private key signed these exact shared-folder contents. It does not prove the curator’s real-world identity or that every source is safe.'})
      );
    } else if (preview.signatureState === 'unsigned') {
      provenance.append(
        h('p', {}, [h('strong', {text: 'Unsigned shared folder'}), document.createTextNode(preview.curator ? ` · shown as ${preview.curator}` : '')]),
        h('p', {class: 'field-help', text: preview.curator ? 'The curator name is self-described and was not verified by a signature.' : 'No curator name or cryptographic signature was supplied.'})
      );
    } else {
      provenance.append(
        h('p', {}, [h('strong', {text: 'Older ProgRSS shared folder'})]),
        h('p', {class: 'field-help', text: 'This Relay-era file has no attribution or signature record. Its sources and folders can still be reviewed normally.'})
      );
    }
    if (preview.note) provenance.append(h('p', {class: 'shared-folder-note', text: preview.note}));
    const updateUrl = canonicalAddress(preview.updateUrl);
    if (updateUrl) {
      let host = updateUrl;
      try { host = new URL(updateUrl).host; } catch {}
      provenance.append(
        h('p', {}, [h('strong', {text: 'Future copies can be checked manually'}), document.createTextNode(` · ${host}`)]),
        h('p', {class: 'field-help', text: 'This address is part of the checked shared-folder contents. ProgRSS contacts it only when someone chooses Check for a newer copy; it is not polled in the background.'})
      );
    }
    container.append(provenance);
  }

  function sharedFolderChangeCount(changes = {}) {
    return (Number(changes.sourcesAdded) || 0) + (Number(changes.sourcesRemoved) || 0) +
      (Number(changes.sourceRecipesChanged) || 0) + (Number(changes.sourceMetadataChanged) || 0) +
      (Number(changes.foldersAdded) || 0) + (Number(changes.foldersRemoved) || 0) +
      (Number(changes.foldersChanged) || 0) + (changes.updateAddressChanged ? 1 : 0);
  }

  function sharedFolderBackLabel(incoming, fallback) {
    if (!incoming?.returnToDiscovery) return fallback;
    if (incoming.returnContext === 'address') return 'Back to address result';
    if (incoming.returnContext === 'exchange') return 'Back to shared route choices';
    return 'Back to page options';
  }

  function sharedFolderContentsStateLabel(state, kind = 'source') {
    const labels = kind === 'folder' ? {
      added: 'Added folder',
      changed: 'Folder route changed',
      unchanged: 'Unchanged folder',
      'removed-from-list': 'Removed from this source list'
    } : {
      'already-here': 'Already in this library',
      'same-incoming-source': 'Same source reused within this list',
      'new-paused': 'New · starts paused',
      unchanged: 'Unchanged',
      'details-changed': 'Name or attribution changed',
      'recipe-changed-new-paused': 'Changed recipe · new source starts paused',
      'recipe-changed-reuses-existing': 'Changed recipe · matches a source already here',
      'added-new-paused': 'Added · new source starts paused',
      'added-reuses-existing': 'Added to this list · source already here',
      'removed-from-list': 'Removed from this source list · local history kept'
    };
    return labels[state] || '';
  }

  function appendSharedFolderContents(container, preview) {
    const contents = preview?.contents;
    if (!contents || contents.schema !== 'progrss.shared-folder.contents.v2') return;
    const sources = Array.isArray(contents.sources) ? contents.sources : [];
    const folders = Array.isArray(contents.folders) ? contents.folders : [];
    const sourceCount = sources.length;
    const folderCount = folders.length;
    const details = h('details', {
      class: 'shared-folder-contents',
      open: sourceCount <= 6 && folderCount <= 4
    });
    const sourceNoteCount = Math.max(0, Number(contents.sourceNoteCount) || 0);
    details.append(h('summary', {
      text: `See ${sourceCount} source${sourceCount === 1 ? '' : 's'} and ${folderCount} folder${folderCount === 1 ? '' : 's'}${sourceNoteCount ? ` · ${sourceNoteCount} curator reason${sourceNoteCount === 1 ? '' : 's'}` : ''}`
    }));
    details.append(h('p', {class: 'field-help', text: 'These names, sites, folder routes, and optional placement reasons come from the checked file. A reason is the curator’s explanation for putting one source in one folder; it is not a ProgRSS safety claim. ProgRSS has not contacted any listed site.'}));

    if (folders.length) {
      details.append(h('p', {class: 'shared-folder-contents-label', text: 'Folder routes'}));
      const list = h('ul', {class: 'shared-folder-contents-list folder-routes'});
      folders.forEach(folder => {
        const item = h('li');
        item.append(h('span', {class: 'shared-folder-content-title', text: text(folder.path, folder.title || 'Untitled folder')}));
        item.append(h('span', {
          class: 'shared-folder-content-meta',
          text: `${Number(folder.branchSources) || 0} source${Number(folder.branchSources) === 1 ? '' : 's'} · ${Number(folder.branchFolders) || 0} folder${Number(folder.branchFolders) === 1 ? '' : 's'} in this section`
        }));
        const label = sharedFolderContentsStateLabel(folder.state, 'folder');
        if (label) item.append(h('span', {class: 'shared-folder-content-state', text: label}));
        list.append(item);
      });
      details.append(list);
    }

    if (sources.length) {
      details.append(h('p', {class: 'shared-folder-contents-label', text: 'Sources'}));
      const list = h('ul', {class: 'shared-folder-contents-list sources'});
      sources.forEach(source => {
        const item = h('li');
        item.append(h('span', {class: 'shared-folder-content-title', text: text(source.title, 'Untitled source')}));
        const kind = source.type === 'page' ? 'Watched page' : 'Feed';
        item.append(h('span', {class: 'shared-folder-content-meta', text: `${kind}${source.host ? ` · ${source.host}` : ''}`}));
        const state = sharedFolderContentsStateLabel(source.state, 'source');
        if (state) item.append(h('span', {class: 'shared-folder-content-state', text: state}));
        const placements = Array.isArray(source.placements) ? source.placements : [];
        if (placements.length) {
          placements.forEach(placement => {
            const route = text(placement.folderPath, 'Unfiled');
            item.append(h('span', {class: 'shared-folder-content-route', text: `In ${route}`}));
            if (text(placement.reason)) item.append(h('span', {class: 'shared-folder-content-note', text: `Curator’s reason for this placement: ${text(placement.reason)}`}));
          });
        } else {
          const paths = Array.isArray(source.folders) ? source.folders.filter(Boolean) : [];
          if (paths.length) {
            const omitted = Math.max(0, Number(source.foldersOmitted) || 0);
            item.append(h('span', {class: 'shared-folder-content-route', text: `In ${paths.join(' · ')}${omitted ? ` · ${omitted} more route${omitted === 1 ? '' : 's'}` : ''}`}));
          }
        }
        list.append(item);
      });
      details.append(list);
    }
    container.append(details);
  }

  function appendSharedFolderSectionChoice(container, incoming, preview) {
    const sections = Array.isArray(preview?.availableSections) ? preview.availableSections.filter(section => section?.id && Number(section.sourceCount) > 0) : [];
    if (!sections.length) return;
    if (preview.independentExcerpt) {
      const section = h('section', {class: 'shared-folder-section-summary'});
      section.append(
        h('strong', {text: 'Adding one folder section'}),
        h('p', {text: text(preview.selectedFolderPath, preview.title || 'Selected section')}),
        h('p', {class: 'field-help', text: 'This becomes an independent local folder. It keeps no update link to the parent publication, so a later publication copy will not rewrite this excerpt.'})
      );
      const full = h('button', {class: 'quiet-button', type: 'button', text: 'Review the full source list'});
      full.addEventListener('click', () => reviewSharedFolderSection(incoming, '', full));
      section.append(full);
      container.append(section);
      return;
    }

    const details = h('details', {class: 'shared-folder-section-choice'});
    details.append(
      h('summary', {text: 'Add just one folder section (optional)'}),
      h('p', {class: 'field-help', text: 'The full source list is the default. A selected section becomes its own local folder and is not linked to future copies of the parent publication.'})
    );
    const id = `shared-folder-section-${Math.random().toString(36).slice(2, 9)}`;
    const label = h('label', {for: id, text: 'Folder section'});
    const select = h('select', {id, class: 'folder-select shared-folder-section-select'});
    select.append(h('option', {value: '', text: 'Choose a folder section'}));
    sections.forEach(section => {
      const counts = `${Number(section.sourceCount) || 0} source${Number(section.sourceCount) === 1 ? '' : 's'}`;
      select.append(h('option', {value: section.id, text: `${section.path} · ${counts}`}));
    });
    const review = h('button', {class: 'secondary', type: 'button', text: 'Review this section', disabled: true});
    select.addEventListener('change', () => { review.disabled = !select.value; });
    review.addEventListener('click', () => reviewSharedFolderSection(incoming, select.value, review));
    details.append(label, h('div', {class: 'shared-folder-section-row'}, [select, review]));
    container.append(details);
  }

  function sharedFolderMergeValue(value) {
    if (value === true) return 'Included';
    if (value === false) return 'Not included';
    if (value === null || value === undefined || value === '') return 'None';
    if (typeof value === 'object') {
      const evidence = [];
      if (value.type) evidence.push(value.type === 'page' ? 'Watched page' : 'Feed');
      if (value.host) evidence.push(value.host);
      if (value.mode && value.mode !== 'feed') evidence.push(value.mode);
      if (value.present === false) evidence.push('Not present');
      if (value.changed === true) evidence.push('Locally changed');
      if (Number.isFinite(Number(value.members))) evidence.push(`${Number(value.members)} member${Number(value.members) === 1 ? '' : 's'}`);
      return evidence.join(' · ') || 'Structured value';
    }
    return String(value);
  }

  function sharedFolderSourceNoteRoute(row) {
    return text(row?.folderPath, text(row?.folderLabel, 'Untitled folder'));
  }

  function sharedFolderSourceNoteValue(value, tag = 'span') {
    return h(tag, {
      class: 'merge-source-note-value',
      dir: 'auto',
      text: value === null || value === undefined || value === '' ? 'No reason' : String(value)
    });
  }

  function appendSharedFolderSourceNoteContext(container, row) {
    container.append(
      h('p', {class: 'merge-source-note-route', text: sharedFolderSourceNoteRoute(row)}),
      h('p', {
        class: 'merge-source-note-boundary',
        text: 'Curator’s reason for this folder belongs to one direct folder/source placement. It is not a ProgRSS safety claim.'
      })
    );
  }

  function appendSharedFolderMergeAdvanced(container, row) {
    const details = h('details', {class: 'merge-advanced'});
    details.append(h('summary', {text: row.kind === 'source-note' ? 'Placement comparison' : 'Advanced comparison'}));
    const grid = h('dl', {class: 'merge-values'});
    const rows = row.kind === 'source-note'
      ? [['Last accepted curator reason', row.baseline], ['Your reason', row.local], ['Curator’s reason', row.incoming]]
      : [['Last accepted copy', row.baseline], ['Your library', row.local], ['Curator’s copy', row.incoming]];
    rows.forEach(([label, value]) => {
      const definition = h('dd');
      if (row.kind === 'source-note') definition.append(sharedFolderSourceNoteValue(value));
      else definition.textContent = sharedFolderMergeValue(value);
      grid.append(h('dt', {text: label}), definition);
    });
    if (row.ownerNote) grid.append(h('dt', {text: 'Ownership rule'}), h('dd', {text: row.ownerNote}));
    if (row.kind === 'source-note') details.append(h('p', {class: 'merge-source-note-route', text: sharedFolderSourceNoteRoute(row)}));
    details.append(grid);
    container.append(details);
  }

  function appendSharedFolderMergeReview(container, incoming, preview) {
    const merge = preview?.mergeReview;
    if (!merge || merge.schema !== 'progrss.shared-folder-merge-review.v1') return;
    if (!incoming.conflictChoices || typeof incoming.conflictChoices !== 'object') incoming.conflictChoices = {};
    const counts = merge.counts || {};
    const section = h('section', {class: 'shared-folder-merge-review', 'aria-labelledby': 'merge-review-heading'});
    section.append(
      h('div', {class: 'merge-review-heading'}, [
        h('span', {class: 'merge-kicker', text: 'Three-way review'}),
        h('h5', {id: 'merge-review-heading', text: 'What changed since the copy you added'})
      ]),
      h('p', {class: 'field-help', text: 'ProgRSS compared the last curator copy you accepted, your current library, and this incoming copy. It will not use “last write wins.”'})
    );
    const pulse = h('div', {class: 'merge-pulse', 'aria-label': 'Merge review summary'});
    const pulseRows = [
      ['Curator only', counts.curatorOnly || 0, 'curator'],
      ['Yours only', counts.recipientOnly || 0, 'local'],
      ['Both agree', counts.agreed || 0, 'agreed'],
      ['Need a choice', counts.conflicts || 0, 'conflict'],
      ['Added', counts.additions || 0, 'addition'],
      ['Removed', counts.removals || 0, 'removal'],
      ['Recipe changes', counts.recipeChanges || 0, 'recipe']
    ].filter(([, count]) => Number(count) > 0);
    pulseRows.forEach(([label, count, kind]) => pulse.append(h('span', {class: `merge-pulse-item ${kind}`, text: `${count} ${label}`})));
    if (pulseRows.length) section.append(pulse);

    const conflicts = Array.isArray(merge.conflicts) ? merge.conflicts : [];
    if (conflicts.length) {
      const conflictSection = h('section', {class: 'merge-group merge-conflicts'});
      conflictSection.append(
        h('h6', {text: `Choose for ${conflicts.length} wording conflict${conflicts.length === 1 ? '' : 's'}`}),
        h('p', {class: 'field-help', text: 'Nothing is preselected. Each choice applies only to the named wording field.'})
      );
      conflicts.forEach((row, index) => {
        const card = h('fieldset', {class: 'merge-conflict-card'});
        const sourceNote = row.kind === 'source-note';
        card.append(h('legend', {text: sourceNote ? text(row.label, 'Untitled source') : `${text(row.label, 'Untitled item')} · ${text(row.fieldLabel, 'Wording')}`}));
        if (sourceNote) appendSharedFolderSourceNoteContext(card, row);
        card.append(h('p', {text: text(row.summary, 'You and the curator changed this differently.')}));
        const choiceName = `merge-conflict-${index}-${Math.random().toString(36).slice(2, 7)}`;
        const choices = h('div', {class: 'merge-conflict-choices'});
        const localLabel = h('label', {class: 'merge-choice'});
        const localInput = h('input', {type: 'radio', name: choiceName, value: 'keep-local', checked: incoming.conflictChoices[row.id] === 'keep-local'});
        localInput.addEventListener('change', () => { incoming.conflictChoices[row.id] = 'keep-local'; renderSharedFolder(); });
        localLabel.append(localInput, h('span', {}, [
          h('strong', {text: 'Keep mine'}),
          sourceNote ? sharedFolderSourceNoteValue(row.local, 'small') : h('small', {text: sharedFolderMergeValue(row.local)})
        ]));
        const curatorLabel = h('label', {class: 'merge-choice'});
        const curatorInput = h('input', {type: 'radio', name: choiceName, value: 'use-curator', checked: incoming.conflictChoices[row.id] === 'use-curator'});
        curatorInput.addEventListener('change', () => { incoming.conflictChoices[row.id] = 'use-curator'; renderSharedFolder(); });
        curatorLabel.append(curatorInput, h('span', {}, [
          h('strong', {text: 'Use curator’s'}),
          sourceNote ? sharedFolderSourceNoteValue(row.incoming, 'small') : h('small', {text: sharedFolderMergeValue(row.incoming)})
        ]));
        choices.append(localLabel, curatorLabel);
        card.append(choices);
        appendSharedFolderMergeAdvanced(card, row);
        conflictSection.append(card);
      });
      section.append(conflictSection);
    }

    const recipes = Array.isArray(merge.recipeChanges) ? merge.recipeChanges : [];
    if (recipes.length) {
      const recipeSection = h('section', {class: 'merge-group merge-recipes'});
      recipeSection.append(
        h('h6', {text: `Review ${recipes.length} change${recipes.length === 1 ? '' : 's'} to how a source is checked`}),
        h('p', {class: 'field-help', text: 'A changed recipe can contact a different address or extract a different part of a page. A newly created recipe begins paused, and the earlier source history stays local.'})
      );
      recipes.forEach(row => {
        const card = h('article', {class: 'merge-change-card recipe'});
        card.append(h('strong', {text: text(row.label, 'Untitled source')}), h('p', {text: text(row.summary, 'The curator changed how this source is checked.')}));
        const route = [row.oldHost && `Earlier ${row.oldHost}`, row.newHost && `Incoming ${row.newHost}`].filter(Boolean).join(' → ');
        if (route) card.append(h('p', {class: 'merge-route', text: route}));
        appendSharedFolderMergeAdvanced(card, row);
        recipeSection.append(card);
      });
      const acknowledge = h('label', {class: 'replace-confirm merge-recipe-confirm'});
      const input = h('input', {type: 'checkbox', checked: Boolean(incoming.recipeAcknowledged)});
      input.addEventListener('change', () => { incoming.recipeAcknowledged = input.checked; renderSharedFolder(); });
      acknowledge.append(input, h('span', {text: 'I reviewed these acquisition changes and understand that new recipes start paused.'}));
      recipeSection.append(acknowledge);
      section.append(recipeSection);
    }

    const appendGroup = (key, heading, explanation, open = false) => {
      const rows = Array.isArray(merge[key]) ? merge[key] : [];
      if (!rows.length) return;
      const details = h('details', {class: `merge-group-list ${key}`, open});
      details.append(h('summary', {text: `${heading} · ${rows.length}`}));
      if (explanation) details.append(h('p', {class: 'field-help', text: explanation}));
      const list = h('ul');
      rows.forEach(row => {
        const item = h('li');
        item.append(h('strong', {text: text(row.label, 'Reviewed change')}));
        if (row.kind === 'source-note') {
          item.append(
            h('span', {class: 'merge-source-note-route', text: sharedFolderSourceNoteRoute(row)}),
            h('span', {class: 'merge-source-note-boundary', text: 'Curator placement reason · not a ProgRSS safety claim.'})
          );
        }
        item.append(h('span', {text: text(row.summary, row.fieldLabel || 'Reviewed change')}));
        appendSharedFolderMergeAdvanced(item, row);
        list.append(item);
      });
      const omitted = Number(merge.omitted?.[key]) || 0;
      if (omitted) list.append(h('li', {class: 'field-help', text: `${omitted} more ${heading.toLowerCase()} omitted from this bounded view.`}));
      details.append(list);
      section.append(details);
    };
    appendGroup('curatorOnly', 'Changed only by the curator', 'These changes apply automatically because your copy still matched the last accepted version.', !conflicts.length && !recipes.length);
    appendGroup('recipientOnly', 'Changed only in your library', 'Your local wording and placements stay local.');
    appendGroup('agreed', 'Same change on both sides', 'You and the curator independently reached the same value.');
    appendGroup('additions', 'Added by the curator', 'New sources start paused unless an exact source is already present.');
    appendGroup('removals', 'Removed by the curator', 'Retained updates and local source records are not silently deleted.');
    container.append(section);
  }

  function renderSharedFolder() {
    els.sharedFolderPreview.replaceChildren();
    const incoming = app.sharedFolder;
    if (!incoming) return;
    const review = h('section', {class: 'opml-review shared-folder-import-review', 'aria-labelledby': 'shared-folder-review-heading'});
    if (incoming.loading) {
      review.append(h('h4', {id: 'shared-folder-review-heading', text: 'Reviewing the shared folder…'}));
      review.append(h('p', {text: incoming.remoteAttempt ? 'ProgRSS is contacting only the future-copy address you chose. Nothing will change until you review the result.' : 'Nothing will change until you choose what to do.'}));
      els.sharedFolderPreview.append(review);
      return;
    }
    if (incoming.error) {
      review.append(h('h4', {id: 'shared-folder-review-heading', text: 'That shared folder could not be reviewed'}));
      review.append(h('p', {class: 'import-warning', text: incoming.error}));
      const again = h('button', {class: 'secondary wide', type: 'button', text: 'Choose a file instead'});
      again.addEventListener('click', () => { resetSharedFolder(); els.sharedFolderFile.click(); });
      review.append(again);
      if (incoming.remoteAttempt) {
        const back = h('button', {class: 'quiet-button wide', type: 'button', text: sharedFolderBackLabel(incoming, 'Back to my folder')});
        back.addEventListener('click', () => {
          const target = incoming.targetRootId || app.folder;
          resetSharedFolder();
          if (incoming.returnToDiscovery) {
            setView('add', {focus: true});
            renderDiscovery();
          } else {
            if (target) app.folder = target;
            setView('sources', {focus: true});
          }
        });
        review.append(back);
      }
      els.sharedFolderPreview.append(review);
      return;
    }

    const preview = incoming.preview || {};
    const updateReview = ['progrss.shared-folder-update.preview.v1', 'progrss.shared-folder-update.preview.v2'].includes(preview.schema);
    const heading = updateReview
      ? (preview.mode === 'current' ? `${text(preview.localTitle || preview.title, 'Shared folder')} is already current` : `Review update for ${text(preview.localTitle || preview.title, 'shared folder')}`)
      : `Ready to add ${text(preview.title, 'a shared folder')}`;
    review.append(h('h4', {id: 'shared-folder-review-heading', text: heading}));
    review.append(h('p', {text: incoming.remote
      ? `${text(incoming.fileName, 'Publication address')} · fetched only on your request · reviewed locally`
      : `${text(incoming.fileName, 'ProgRSS shared folder')} · reviewed locally` }));
    if (incoming.remote) review.append(h('p', {class: 'field-help', text: 'The request omitted cookies and credentials. ProgRSS does not schedule another check or notify you later.'}));
    appendSharedFolderProvenance(review, preview);

    if (!updateReview) {
      if (preview.independentExcerpt) {
        review.append(h('p', {class: 'shared-folder-section-intro', text: `This review contains ${preview.sourceCount || 0} of ${preview.fullSourceCount || preview.sourceCount || 0} sources from ${text(preview.parentTitle, 'the complete source list')}.` }));
      }
      const stats = h('div', {class: 'import-stats'});
      stats.append(
        importStat(preview.feedCount || 0, 'feeds'),
        importStat(preview.pageWatchCount || 0, 'page watches'),
        importStat(preview.folders || 0, 'folders'),
        importStat(preview.reusedSources || 0, 'sources already here')
      );
      review.append(stats);
      appendSharedFolderContents(review, preview);
      appendSharedFolderSectionChoice(review, incoming, preview);
      review.append(h('p', {text: preview.newSources
        ? `${preview.newSources} new source${preview.newSources === 1 ? '' : 's'} will start paused. ProgRSS will not contact any site or ask for site access during this import.`
        : 'Every source is already here. ProgRSS will add the shared folder structure without contacting any site.'}));
      review.append(h('p', {class: 'privacy-note', text: 'This file contains source addresses and page-watch rules only. It does not bring in someone else’s reading history, saved items, observations, or browser permissions.'}));
      if (!preview.canImport) {
        review.append(h('p', {class: 'import-warning', text: preview.reason || 'This shared folder cannot be added.'}));
      } else {
        const actions = h('div', {class: 'import-actions'});
        const add = h('button', {class: 'primary wide', type: 'button', text: preview.independentExcerpt ? 'Add this section' : 'Add source list'});
        add.addEventListener('click', () => importReviewedSharedFolder(add, false));
        const another = h('button', {class: 'quiet-button wide', type: 'button', text: sharedFolderBackLabel(incoming, 'Choose another file')});
        another.addEventListener('click', () => {
          resetSharedFolder();
          if (incoming.returnToDiscovery) {
            setView('add', {focus: true});
            renderDiscovery();
          } else {
            els.sharedFolderFile.click();
          }
        });
        actions.append(add, another);
        review.append(actions);
      }
      els.sharedFolderPreview.append(review);
      return;
    }

    const trust = preview.trust || {};
    const continuity = h('section', {class: `shared-folder-continuity ${trust.state || ''}`});
    continuity.append(
      h('strong', {text: trust.state === 'same-key' ? 'Same signing key' : trust.state === 'key-change' ? 'Signing key changed' : trust.state === 'signed-to-unsigned' ? 'Signature removed' : trust.state === 'newly-signed' ? 'Signature added' : 'Signature continuity'}),
      h('p', {text: trust.message || 'ProgRSS compared the signing evidence from both copies.'})
    );
    if (preview.previous?.fingerprint && preview.fingerprint && preview.previous.fingerprint !== preview.fingerprint) {
      continuity.append(h('p', {class: 'field-help', text: `Earlier ${preview.previous.fingerprint} · this copy ${preview.fingerprint}` }));
    }
    review.append(continuity);

    const changes = preview.changes || {};
    const local = preview.localEdits || {};
    const changedSources = (Number(changes.sourcesAdded) || 0) + (Number(changes.sourceRecipesChanged) || 0) + (Number(changes.sourceMetadataChanged) || 0);
    const changedFolders = (Number(changes.foldersAdded) || 0) + (Number(changes.foldersRemoved) || 0) + (Number(changes.foldersChanged) || 0);
    const stats = h('div', {class: 'import-stats'});
    stats.append(
      importStat(changedSources, 'added or changed sources'),
      importStat(changes.sourcesRemoved || 0, 'sources removed from list'),
      importStat(changedFolders, 'folder changes'),
      importStat((Number(local.sourceOverrides) || 0) + (Number(local.folderOverrides) || 0), 'local edits kept')
    );
    review.append(stats);
    appendSharedFolderContents(review, preview);
    appendSharedFolderMergeReview(review, incoming, preview);
    if (preview.mode === 'current') {
      review.append(h('p', {text: 'The publication contents and signer continuity already match this local folder. Nothing needs to change.'}));
    } else {
      review.append(h('p', {text: 'Updating changes only this publication’s source recipes and folder route. Local reading history, read and saved state, source activity, and browser site access stay local.'}));
      if (changes.sourceRecipesChanged) review.append(h('p', {text: `${changes.sourceRecipesChanged} changed source recipe${changes.sourceRecipesChanged === 1 ? '' : 's'} will use a new paused source. The earlier source history will remain in the library.`}));
      if (changes.sourcesRemoved) review.append(h('p', {text: `${changes.sourcesRemoved} source${changes.sourcesRemoved === 1 ? '' : 's'} removed from the shared list will be detached from unchanged publication folders. Their retained updates will not be deleted.`}));
      if (changes.updateAddressChanged) review.append(h('p', {text: preview.updateUrl ? 'This copy changes where future copies can be checked. The new address will be used only when you ask.' : 'This copy removes the future-copy address. ProgRSS will stop offering manual checks for this folder.'}));
      if (local.present) review.append(h('p', {class: 'privacy-note', text: `ProgRSS found local changes and will keep them: ${local.sourceOverrides || 0} source override${local.sourceOverrides === 1 ? '' : 's'}, ${local.folderOverrides || 0} folder edit${local.folderOverrides === 1 ? '' : 's'}${local.detachedFolders ? `, and ${local.detachedFolders} locally changed folder${local.detachedFolders === 1 ? '' : 's'} kept as local` : ''}.`}));
    }
    if (Array.isArray(preview.warnings) && preview.warnings.length) {
      const warnings = h('details', {class: 'transfer-warnings'});
      warnings.append(h('summary', {text: `${preview.warnings.length} consequence${preview.warnings.length === 1 ? '' : 's'} to review`}), h('ul', {}, preview.warnings.map(message => h('li', {text: message}))));
      review.append(warnings);
    }
    if (preview.reason && !preview.canUpdate) review.append(h('p', {class: 'import-warning', text: preview.reason}));

    if (preview.requiresTrustAcknowledgement) {
      const confirm = h('label', {class: 'replace-confirm shared-folder-trust-confirm'});
      const input = h('input', {type: 'checkbox', checked: Boolean(incoming.trustAcknowledged)});
      input.addEventListener('change', () => {
        incoming.trustAcknowledged = input.checked;
        renderSharedFolder();
      });
      confirm.append(input, h('span', {text: trust.state === 'signed-to-unsigned'
        ? 'I understand that this update removes the earlier signing-key continuity.'
        : 'I understand that this update was signed by a different key.'}));
      review.append(confirm);
    }

    const decisionIds = Array.isArray(preview.mergeReview?.decisionIds) ? preview.mergeReview.decisionIds : [];
    const conflictChoicesReady = decisionIds.every(id => ['keep-local', 'use-curator'].includes(incoming.conflictChoices?.[id]));
    const recipeReady = !preview.requiresRecipeAcknowledgement || Boolean(incoming.recipeAcknowledged);
    const actions = h('div', {class: 'import-actions shared-folder-update-actions'});
    const update = h('button', {
      class: 'primary wide', type: 'button', text: preview.requiresConflictChoices ? 'Apply reviewed choices' : 'Update from this copy',
      disabled: !preview.canUpdate || (preview.requiresTrustAcknowledgement && !incoming.trustAcknowledged) || !conflictChoicesReady || !recipeReady
    });
    update.addEventListener('click', () => updateReviewedSharedFolder(update));
    const keep = h('button', {class: 'quiet-button wide', type: 'button', text: 'Keep my local version'});
    keep.addEventListener('click', keepLocalSharedFolder);
    const separate = h('button', {class: 'secondary wide', type: 'button', text: 'Import as a separate folder', disabled: preview.separate && preview.separate.canImport === false});
    separate.addEventListener('click', () => importReviewedSharedFolder(separate, true));
    actions.append(update, keep, separate);
    review.append(actions);
    els.sharedFolderPreview.append(review);
  }

  async function reviewSharedFolderFile(file) {
    if (!file) return;
    els.sharedFolderCard.hidden = false;
    if (file.size > MAX_SHARED_FOLDER_BYTES) {
      app.sharedFolder = {fileName: file.name, error: 'That shared folder is larger than the 650 KB safety limit.'};
      renderSharedFolder();
      return;
    }
    app.sharedFolder = {fileName: file.name, loading: true, trustAcknowledged: false, conflictChoices: {}, recipeAcknowledged: false};
    renderSharedFolder();
    busy('shared-folder-import', true);
    try {
      const raw = await file.text();
      if (new TextEncoder().encode(raw).byteLength > MAX_SHARED_FOLDER_BYTES) throw new Error('That shared folder is larger than the 650 KB safety limit.');
      const preview = await request('preview-shared-folder', {raw});
      app.sharedFolder = {fileName: file.name, raw, preview, trustAcknowledged: false, conflictChoices: {}, recipeAcknowledged: false};
    } catch (error) {
      app.sharedFolder = {fileName: file.name, error: error.message};
    } finally {
      busy('shared-folder-import', false);
      renderSharedFolder();
    }
  }

  async function reviewSharedFolderSection(incoming, selectedFolderId, button = null) {
    if (!incoming?.raw) return;
    if (button) {
      button.disabled = true;
      button.textContent = selectedFolderId ? 'Reviewing section…' : 'Reviewing full list…';
    }
    busy('shared-folder-import', true);
    try {
      const preview = await request('preview-shared-folder', {raw: incoming.raw, selectedFolderId});
      app.sharedFolder = {...incoming, preview, trustAcknowledged: false, conflictChoices: {}, recipeAcknowledged: false};
    } catch (error) {
      app.sharedFolder = {...incoming, error: error.message, loading: false};
    } finally {
      busy('shared-folder-import', false);
      renderSharedFolder();
      requestAnimationFrame(() => document.querySelector('#shared-folder-review-heading')?.focus?.());
    }
  }

  async function refreshSharedFolderReview(incoming, message) {
    try {
      const preview = await request('preview-shared-folder', {
        raw: incoming.raw,
        targetRootId: incoming.preview?.targetRootId || '',
        selectedFolderId: incoming.preview?.selectedFolderId || ''
      });
      app.sharedFolder = {...incoming, preview, trustAcknowledged: false, conflictChoices: {}, recipeAcknowledged: false};
      setStatus(message, 'error');
    } catch (previewError) {
      app.sharedFolder = {fileName: incoming.fileName, error: previewError.message};
      setStatus(previewError.message, 'error');
    }
    renderSharedFolder();
  }

  async function importReviewedSharedFolder(button, separate = false) {
    const incoming = app.sharedFolder;
    const preview = incoming?.preview || {};
    const canImport = ['progrss.shared-folder-update.preview.v1', 'progrss.shared-folder-update.preview.v2'].includes(preview.schema)
      ? preview.separate?.canImport !== false
      : Boolean(preview.canImport);
    if (!incoming?.raw || !canImport) return;
    button.disabled = true;
    button.textContent = separate ? 'Adding separate folder…' : 'Adding folder…';
    busy('shared-folder-import', true);
    try {
      const result = await request('import-shared-folder', {
        raw: incoming.raw,
        reviewedRevision: preview.reviewedRevision,
        selectedFolderId: preview.selectedFolderId || ''
      });
      app.sharedFolder = null;
      els.sharedFolderFile.value = '';
      els.sharedFolderCard.hidden = true;
      await loadState();
      app.folder = result.rootId || 'all';
      try { await api.storage.local.set({libraryFolder: app.folder}); } catch {}
      render();
      setView('sources', {focus: true});
      const newCount = Number(result.importedSources) || 0;
      const reused = Number(result.reusedSources) || 0;
      const provenance = preview.signatureState === 'verified'
        ? ` · signature verified${preview.curator ? ` · ${preview.curator}` : ''}`
        : (preview.curator ? ` · shown as ${preview.curator} · unsigned` : '');
      const resultLabel = preview.independentExcerpt ? 'Folder section added' : (separate ? 'Separate shared folder added' : 'Source list added');
      const continuity = preview.independentExcerpt ? ' · independent local excerpt' : '';
      setStatus(`${resultLabel} · ${newCount} new source${newCount === 1 ? '' : 's'} paused${reused ? ` · ${reused} existing source${reused === 1 ? '' : 's'} reused` : ''}${continuity}${provenance}.`, 'success');
    } catch (error) {
      if (error.code === 'SHARED_FOLDER_REVIEW_STALE') {
        await refreshSharedFolderReview(incoming, 'ProgRSS changed while you were reviewing. Check the updated shared-folder summary before adding it.');
      } else {
        setStatus(error.message, 'error');
        renderSharedFolder();
      }
    } finally {
      busy('shared-folder-import', false);
    }
  }

  async function updateReviewedSharedFolder(button) {
    const incoming = app.sharedFolder;
    const preview = incoming?.preview || {};
    if (!incoming?.raw || !['progrss.shared-folder-update.preview.v1', 'progrss.shared-folder-update.preview.v2'].includes(preview.schema) || !preview.canUpdate) return;
    button.disabled = true;
    button.textContent = 'Updating folder…';
    busy('shared-folder-import', true);
    try {
      const result = await request('update-shared-folder', {
        raw: incoming.raw,
        reviewedRevision: preview.reviewedRevision,
        targetRootId: preview.targetRootId,
        acknowledgeTrustChange: Boolean(incoming.trustAcknowledged),
        conflictChoices: {...(incoming.conflictChoices || {})},
        acknowledgeRecipeChanges: Boolean(incoming.recipeAcknowledged)
      });
      app.sharedFolder = null;
      els.sharedFolderFile.value = '';
      els.sharedFolderCard.hidden = true;
      await loadState();
      app.folder = result.targetRootId || result.rootId || preview.targetRootId || 'all';
      try { await api.storage.local.set({libraryFolder: app.folder}); } catch {}
      render();
      setView('sources', {focus: true});
      const count = sharedFolderChangeCount(result.changes);
      setStatus(`${text(result.localTitle || result.title, 'Shared folder')} updated${count ? ` · ${count} reviewed change${count === 1 ? '' : 's'}` : ''}. Local reading history and source state were kept.`, 'success');
    } catch (error) {
      if (error.code === 'SHARED_FOLDER_UPDATE_STALE') {
        await refreshSharedFolderReview(incoming, 'ProgRSS changed while you were reviewing. Check the updated comparison before continuing.');
      } else {
        setStatus(error.message, 'error');
        renderSharedFolder();
      }
    } finally {
      busy('shared-folder-import', false);
    }
  }

  async function keepLocalSharedFolder() {
    const incoming = app.sharedFolder;
    const targetRootId = incoming?.preview?.targetRootId || '';
    app.sharedFolder = null;
    els.sharedFolderFile.value = '';
    els.sharedFolderCard.hidden = true;
    if (targetRootId) {
      app.folder = targetRootId;
      try { await api.storage.local.set({libraryFolder: app.folder}); } catch {}
    }
    render();
    setView('sources', {focus: true});
    setStatus('Your local shared folder was kept. Nothing changed.', 'success');
  }
  function downloadBytes(fileName, bytes, type = 'application/octet-stream') {
    const blob = new Blob([bytes], {type});
    const url = URL.createObjectURL(blob);
    const link = h('a', {href: url, download: fileName});
    link.hidden = true;
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function downloadText(fileName, raw, type = 'application/json') {
    downloadBytes(fileName, raw, type);
  }

  function applyBackupReminderResult(result) {
    if (result?.backupReminder && typeof result.backupReminder === 'object') {
      app.state.backupReminder = result.backupReminder;
      renderBackupReminder();
      updateActionAvailability();
    }
  }

  async function savePrivateCopy() {
    busy('backup-copy', true);
    const button = els.savePrivateCopy;
    const label = button.textContent;
    button.textContent = 'Preparing private copy…';
    try {
      const result = await request('export-private-backup', {recovery: true});
      downloadText(result.fileName || 'ProgRSS-recovery.json', result.raw || '');
      applyBackupReminderResult(result);
      app.copyCheck = null;
      renderCopyCheck();
      const sources = Number(result.summary?.sources) || 0;
      const items = Number(result.summary?.items) || 0;
      setStatus(`Private copy prepared · ${sources} source${sources === 1 ? '' : 's'} · ${items} update${items === 1 ? '' : 's'}. After the browser finishes, choose Check saved copy.`, 'success');
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      button.textContent = label;
      busy('backup-copy', false);
    }
  }

  function choosePrivateCopyForCheck() {
    els.copyCheckFile.value = '';
    els.copyCheckFile.click();
  }

  async function checkPrivateCopyFile(file) {
    if (!file) return;
    if (file.size > MAX_PRIVATE_BACKUP_BYTES) {
      app.copyCheck = {error: 'That file is larger than the 24 MB private-copy limit.'};
      renderCopyCheck();
      els.copyCheckHeading.focus({preventScroll: true});
      return;
    }
    busy('backup-check', true);
    app.copyCheck = {loading: true, fileName: file.name};
    renderCopyCheck();
    try {
      const raw = await file.text();
      if (new TextEncoder().encode(raw).byteLength > MAX_PRIVATE_BACKUP_BYTES) throw new Error('That file is larger than the 24 MB private-copy limit.');
      const report = await request('check-private-backup', {raw});
      app.copyCheck = {fileName: file.name, report};
      applyBackupReminderResult(report);
      renderCopyCheck();
      requestAnimationFrame(() => els.copyCheckHeading.focus({preventScroll: true}));
      if (report.state === 'current') {
        setStatus('Saved copy checked. It is readable and matches the portable library here now.', 'success');
      } else if (report.state === 'previous') {
        setStatus('Older private copy found. It is readable, but the library here has changed.', 'success');
      } else {
        setStatus('That file is readable ProgRSS data, but it is different from the library here. Nothing was changed.', 'error');
      }
    } catch (error) {
      app.copyCheck = {fileName: file.name, error: error.message};
      renderCopyCheck();
      requestAnimationFrame(() => els.copyCheckHeading.focus({preventScroll: true}));
      setStatus(error.message, 'error');
    } finally {
      els.copyCheckFile.value = '';
      busy('backup-check', false);
    }
  }

  async function changeBackupReminder(type) {
    busy('backup-reminder', true);
    try {
      const reminder = await request(type);
      app.state.backupReminder = reminder;
      renderBackupReminder();
      const messages = {
        'snooze-backup-reminder': 'Private-copy reminder paused for 30 days.',
        'disable-backup-reminder': 'Private-copy reminders are off. You can turn them on under Private copy.',
        'enable-backup-reminder': 'Private-copy reminders are on.'
      };
      setStatus(messages[type] || 'Private-copy reminder updated.', 'success');
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      busy('backup-reminder', false);
    }
  }

  async function markBackupCopyMissing() {
    busy('backup-reminder', true);
    try {
      const reminder = await request('mark-backup-copy-missing');
      app.state.backupReminder = reminder;
      app.copyCheck = null;
      renderBackupReminder();
      renderCopyCheck();
      setStatus('The recorded checked copy is now marked missing. No file was deleted.', 'success');
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      busy('backup-reminder', false);
    }
  }

  async function saveRecoveryCopy() {
    busy('storage-recovery', true);
    const original = els.saveRecoveryCopy.textContent;
    els.saveRecoveryCopy.textContent = 'Preparing recovery copy…';
    try {
      const result = await request('export-private-backup', {recovery: true});
      downloadText(result.fileName || 'ProgRSS-recovery.json', result.raw || '');
      applyBackupReminderResult(result);
      app.copyCheck = null;
      renderCopyCheck();
      const sources = Number(result.summary?.sources) || 0;
      const items = Number(result.summary?.items) || 0;
      const sourceNotes = Number(result.summary?.sourceNotes) || 0;
      setStatus(`Recovery copy prepared · ${sources} source${sources === 1 ? '' : 's'} · ${items} update${items === 1 ? '' : 's'} · ${sourceNotes} curator reason${sourceNotes === 1 ? '' : 's'}. Check the saved file from Sources when the browser finishes.`, 'success');
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      els.saveRecoveryCopy.textContent = original;
      busy('storage-recovery', false);
    }
  }

  async function checkStorage() {
    busy('storage-check', true);
    const original = els.checkStorage.textContent;
    els.checkStorage.textContent = 'Checking…';
    try {
      const result = await request('probe-vault-write');
      await loadState();
      setStatus(result.note || 'A small test write succeeded. Repeat the action that failed.', 'success');
    } catch (error) {
      setStatus(error.message, 'error');
      try { await loadState(); } catch {}
    } finally {
      els.checkStorage.textContent = original;
      busy('storage-check', false);
    }
  }

  function resetTransfer() {
    app.transfer = null;
    els.backupFile.value = '';
    renderTransfer();
  }

  function transferFact(title, detail) {
    const row = h('li');
    row.append(h('strong', {text: title}), document.createTextNode(` ${detail}`));
    return row;
  }

  function renderTransfer() {
    els.backupPreview.replaceChildren();
    const transfer = app.transfer;
    if (!transfer) return;
    const review = h('section', {class: 'backup-review', 'aria-labelledby': 'backup-review-heading'});
    if (transfer.loading) {
      review.append(h('h4', {id: 'backup-review-heading', text: 'Reviewing the transfer file…'}));
      review.append(h('p', {text: 'Nothing in this browser will change until you approve the review.'}));
      els.backupPreview.append(review);
      return;
    }
    if (transfer.error) {
      review.append(h('h4', {id: 'backup-review-heading', text: 'That file could not be reviewed'}));
      review.append(h('p', {class: 'import-warning', text: transfer.error}));
      const again = h('button', {class: 'secondary wide', type: 'button', text: 'Choose another file'});
      again.addEventListener('click', resetTransfer);
      review.append(again);
      els.backupPreview.append(review);
      return;
    }

    const preview = transfer.preview;
    const incoming = preview.incoming || {};
    const current = preview.current || {};
    const permissions = preview.permissions || {};
    const hasCurrent = ['sources', 'items', 'collections', 'snapshots', 'advancedRecords']
      .some(key => Number(current[key]) > 0);
    review.append(h('h4', {id: 'backup-review-heading', text: `Ready to bring in ${incoming.sources || 0} source${incoming.sources === 1 ? '' : 's'}`}));
    const fileMeta = [text(transfer.fileName, 'ProgRSS transfer file')];
    if (Date.parse(preview.exportedAt || '')) fileMeta.push(`saved ${relativeTime(preview.exportedAt)}`);
    review.append(h('p', {text: fileMeta.join(' · ')}));

    const stats = h('div', {class: 'import-stats'});
    stats.append(
      importStat(incoming.sources || 0, 'sources'),
      importStat(incoming.items || 0, 'updates'),
      importStat(incoming.saved || 0, 'saved'),
      importStat(incoming.collections || 0, 'collections'),
      importStat(incoming.sourceNotes || 0, 'curator reasons')
    );
    review.append(stats);

    if (hasCurrent) {
      review.append(h('p', {class: 'replace-warning', text: `This replaces the library currently here: ${current.sources || 0} sources and ${current.items || 0} updates.`}));
    }

    const facts = h('ul', {class: 'transfer-facts'});
    facts.append(transferFact('Moves with the file:', 'sources, read and saved state, collections, curator-written folder reasons, page-watch history, and Advanced Workbench records.'));
    facts.append(transferFact('Stays with the browser:', 'site access, extension identity, and non-exportable curator signing keys.'));
    if (permissions.reconnectSources) {
      facts.append(transferFact('After arrival:', `${permissions.reconnectSources} active source${permissions.reconnectSources === 1 ? '' : 's'} across ${permissions.reconnectOrigins} site${permissions.reconnectOrigins === 1 ? '' : 's'} will show Reconnect.`));
    } else if (permissions.activeOrigins) {
      facts.append(transferFact('After arrival:', 'this browser already has access to the active source sites in the file.'));
    } else {
      facts.append(transferFact('After arrival:', 'paused sources stay paused and ask for site access only when you resume them.'));
    }
    if (permissions.movedSources) facts.append(transferFact('Still needs review:', `${permissions.movedSources} source move${permissions.movedSources === 1 ? '' : 's'} will remain waiting for your decision.`));
    facts.append(preview.willKeepUndo === false
      ? transferFact('No replacement needed:', 'this ProgRSS installation is empty, so no temporary copy is necessary.')
      : transferFact('Safety copy:', `the library currently here stays on this device for ${preview.undoMinutes || 30} minutes so you can undo the move.`));
    review.append(facts);

    if (Array.isArray(preview.warnings) && preview.warnings.length) {
      const warnings = h('details', {class: 'transfer-warnings'});
      warnings.append(h('summary', {text: `${preview.warnings.length} item${preview.warnings.length === 1 ? '' : 's'} need review`}),
        h('ul', {}, preview.warnings.slice(0, 6).map(message => h('li', {text: message}))));
      review.append(warnings);
    }

    let acknowledged = !hasCurrent;
    if (hasCurrent) {
      const confirm = h('label', {class: 'replace-confirm'});
      const input = h('input', {type: 'checkbox'});
      confirm.append(input, h('span', {text: 'I understand this replaces the library currently here.'}));
      review.append(confirm);
      input.addEventListener('change', () => {
        acknowledged = input.checked;
        restoreButton.disabled = !acknowledged;
      });
    }

    const actions = h('div', {class: 'import-actions'});
    const restoreButton = h('button', {
      class: 'primary wide', type: 'button', disabled: !acknowledged,
      text: hasCurrent ? 'Replace with this library' : 'Bring in this library'
    });
    restoreButton.addEventListener('click', () => restoreReviewedLibrary(restoreButton));
    const another = h('button', {class: 'quiet-button wide', type: 'button', text: 'Choose another file'});
    another.addEventListener('click', resetTransfer);
    actions.append(restoreButton, another);
    review.append(actions);
    els.backupPreview.append(review);
  }

  async function exportLibrary() {
    busy('transfer-export', true);
    const original = els.exportLibrary.textContent;
    els.exportLibrary.textContent = 'Preparing private file…';
    try {
      const result = await request('export-private-backup');
      downloadText(result.fileName || 'ProgRSS-library.json', result.raw || '');
      applyBackupReminderResult(result);
      const sourceNotes = Number(result.summary?.sourceNotes) || 0;
      setStatus(`Private transfer file saved · ${result.summary?.sources || 0} source${result.summary?.sources === 1 ? '' : 's'} · ${sourceNotes} curator reason${sourceNotes === 1 ? '' : 's'}. Keep it private.`, 'success');
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      els.exportLibrary.textContent = original;
      busy('transfer-export', false);
    }
  }

  async function reviewTransferFile(file) {
    if (!file) return;
    if (file.size > MAX_PRIVATE_BACKUP_BYTES) {
      app.transfer = {fileName: file.name, error: 'That file is larger than the 24 MB transfer limit.'};
      renderTransfer();
      return;
    }
    app.transfer = {fileName: file.name, loading: true};
    renderTransfer();
    busy('transfer-import', true);
    try {
      const raw = await file.text();
      if (new TextEncoder().encode(raw).byteLength > MAX_PRIVATE_BACKUP_BYTES) throw new Error('That file is larger than the 24 MB transfer limit.');
      const preview = await request('preview-private-backup', {raw});
      app.transfer = {fileName: file.name, raw, preview};
    } catch (error) {
      app.transfer = {fileName: file.name, error: error.message};
    } finally {
      busy('transfer-import', false);
      renderTransfer();
    }
  }

  async function restoreReviewedLibrary(button) {
    const transfer = app.transfer;
    if (!transfer?.raw || !transfer?.preview?.canRestore) return;
    button.disabled = true;
    button.textContent = 'Moving library…';
    busy('transfer-import', true);
    try {
      const result = await request('restore-private-backup', {raw: transfer.raw, reviewedRevision: transfer.preview.reviewedRevision});
      resetTransfer();
      await loadState();
      const needsSources = Boolean(result.permissions?.reconnectSources || result.permissions?.movedSources);
      setView(needsSources ? 'sources' : 'today', {focus: true});
      const reconnect = Number(result.permissions?.reconnectSources) || 0;
      const undoNote = result.undoAvailable ? ' Your previous library can still be restored.' : '';
      setStatus(reconnect
        ? `Library moved here. ${reconnect} source${reconnect === 1 ? '' : 's'} need reconnecting.${undoNote}`
        : `Library moved here.${undoNote}`, 'success');
    } catch (error) {
      if (error.code === 'TRANSFER_REVIEW_STALE') {
        try {
          const preview = await request('preview-private-backup', {raw: transfer.raw});
          app.transfer = {...transfer, preview};
          setStatus('ProgRSS changed while you were reviewing. Check the updated replacement summary before continuing.', 'error');
        } catch (previewError) {
          app.transfer = {fileName: transfer.fileName, error: previewError.message};
          setStatus(previewError.message, 'error');
        }
      } else {
        setStatus(error.message, 'error');
      }
      button.disabled = false;
      renderTransfer();
    } finally {
      busy('transfer-import', false);
    }
  }

  async function undoLibraryMove() {
    busy('transfer-undo', true);
    els.undoLibraryMove.textContent = 'Restoring…';
    try {
      await request('undo-private-backup-restore');
      await loadState();
      setView('today', {focus: true});
      setStatus('Your previous library has been restored. Site access was checked again in this browser.', 'success');
    } catch (error) {
      setStatus(error.message, 'error');
    } finally {
      els.undoLibraryMove.textContent = 'Undo library move';
      busy('transfer-undo', false);
    }
  }


  function startFromCurrentPage() {
    setView('add');
    discoverCurrentPage();
  }

  function focusAddressEntry() {
    setView('add');
    els.address.scrollIntoView({block: 'center'});
    els.address.focus();
  }

  function chooseOpmlFile() {
    setView('add');
    els.opmlCard.hidden = false;
    els.opmlCard.scrollIntoView({block: 'nearest'});
    requestAnimationFrame(() => $('#opml-heading')?.focus({preventScroll: true}));
  }

  function chooseSharedFolderFile() {
    setView('add');
    els.sharedFolderCard.hidden = false;
    els.sharedFolderCard.scrollIntoView({block: 'nearest'});
    els.sharedFolderFile.click();
  }


  function nodeFact(label, value) {
    return h('div', {}, [h('dt', {text: label}), h('dd', {text: value})]);
  }

  function compactNodeFingerprint(value) {
    const clean = text(value);
    if (clean.length <= 31) return clean;
    return `${clean.slice(0, 18)}…${clean.slice(-10)}`;
  }

  function countLabel(value, singular, plural = `${singular}s`) {
    const count = Number.isInteger(Number(value)) && Number(value) >= 0 ? Number(value) : 0;
    return `${count} ${count === 1 ? singular : plural}`;
  }

  function parseNodeInvitation(value) {
    const raw = String(value || '').trim();
    if (!raw || raw.length > 4096) throw new Error('Paste the complete invitation from your Node.');
    let url;
    try { url = new URL(raw); } catch { throw new Error('That is not a complete Node invitation.'); }
    if (url.protocol !== 'http:' || url.hostname !== '127.0.0.1') {
      throw new Error('This release pairs only with a Node on 127.0.0.1 on this device.');
    }
    if (url.username || url.password || url.search || !url.port || !['', '/'].includes(url.pathname)) {
      throw new Error('That invitation has an unexpected address shape. Create a new invitation on the Node.');
    }
    const port = Number(url.port);
    if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('That Node invitation has an invalid port.');
    const fragment = new URLSearchParams(url.hash.slice(1));
    const values = fragment.getAll('pair');
    const allowedKeys = [...fragment.keys()].every(key => key === 'pair');
    const token = values.length === 1 ? values[0] : '';
    if (!allowedKeys || !/^[A-Za-z0-9_-]{40,80}$/.test(token)) {
      throw new Error('That invitation is incomplete or contains unexpected information.');
    }
    return {origin: url.origin, token};
  }



  function looksLikeCaptureInvitation(value) {
    try {
      const url = new URL(String(value || '').trim());
      return url.protocol === 'http:' && url.hostname === '127.0.0.1' && new URLSearchParams(url.hash.slice(1)).has('capture');
    } catch { return false; }
  }

  function parseCaptureInvitation(value) {
    const raw = String(value || '').trim();
    if (!raw || raw.length > 4096) throw new Error('Paste the complete browser request from ProgRSS Node.');
    let url;
    try { url = new URL(raw); } catch { throw new Error('That is not a complete ProgRSS browser request.'); }
    if (url.protocol !== 'http:' || url.hostname !== '127.0.0.1') throw new Error('This release accepts browser requests only from 127.0.0.1 on this device.');
    if (url.username || url.password || url.search || !url.port || !['', '/'].includes(url.pathname)) throw new Error('That browser request has an unexpected address shape. Create a new request in the Node.');
    const port = Number(url.port);
    if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('That browser request has an invalid Node port.');
    const fragment = new URLSearchParams(url.hash.slice(1));
    const values = fragment.getAll('capture');
    const token = values.length === 1 ? values[0] : '';
    if ([...fragment.keys()].some(key => key !== 'capture') || !/^[A-Za-z0-9_-]{40,80}$/.test(token)) throw new Error('That browser request is incomplete or contains unexpected information.');
    return {origin: url.origin, token};
  }

  function normalizedCaptureUrl(value) {
    const url = new URL(String(value || ''));
    url.hash = '';
    return url.href;
  }

  function captureRecipe(value = {}) {
    return {
      mode: value.mode === 'cards' ? 'cards' : 'region',
      selector: text(value.selector).slice(0, 350),
      titleSelector: text(value.titleSelector).slice(0, 200),
      linkSelector: text(value.linkSelector).slice(0, 200),
      threshold: Math.max(1, Math.min(100000, Math.floor(Number(value.threshold) || 1))),
      ignoreNumbers: Boolean(value.ignoreNumbers),
    };
  }

  function captureRecipeKey(value) {
    return JSON.stringify(captureRecipe(value));
  }

  function captureAssessment(value = {}) {
    const level = ['steadier', 'watchful', 'fragile'].includes(value.level) ? value.level : 'fragile';
    const strings = rows => (Array.isArray(rows) ? rows : []).slice(0, 4).map(row => text(row).slice(0, 180)).filter(Boolean);
    const signals = value.signals && typeof value.signals === 'object' && !Array.isArray(value.signals) ? value.signals : {};
    const integer = (key, maximum) => Math.max(0, Math.min(maximum, Math.floor(Number(signals[key]) || 0)));
    return {
      schema: NODE_CAPTURE_ASSESSMENT_SCHEMA,
      level,
      summary: text(value.summary).slice(0, 220) || (level === 'steadier' ? 'More likely to stay put, based on the structure visible now.' : level === 'watchful' ? 'Usable, but one or more page details may shift.' : 'Fragile: weak or noisy structure may require repair.'),
      reasons: strings(value.reasons),
      warnings: strings(value.warnings),
      signals: {
        selectorKind: ['semantic', 'named', 'generic'].includes(signals.selectorKind) ? signals.selectorKind : 'generic',
        semanticBoundary: Boolean(signals.semanticBoundary),
        uniqueMatch: Boolean(signals.uniqueMatch),
        visibleMatches: integer('visibleMatches', 100000),
        hiddenMatches: integer('hiddenMatches', 100000),
        repeatedEntries: integer('repeatedEntries', 200),
        linkedEntries: integer('linkedEntries', 200),
        titledEntries: integer('titledEntries', 200),
        consistentEntries: integer('consistentEntries', 200),
        clutterElements: integer('clutterElements', 999),
        textCharacters: integer('textCharacters', 120000),
      },
    };
  }

  function captureAssessmentLabel(level) {
    return level === 'steadier' ? 'More likely to stay put' : level === 'watchful' ? 'Needs watching' : 'Fragile';
  }

  function capturePageContext(value = {}) {
    if (!value || typeof value !== 'object' || Array.isArray(value) || value.schema !== NODE_CAPTURE_CONTEXT_SCHEMA) throw new Error('The rendered page did not return the expected page-boundary evidence.');
    const allowedKinds = new Set(['continuation', 'partial-render', 'overlay', 'loading', 'frames', 'open-shadow']);
    const allowedTones = new Set(['boundary', 'caution', 'included']);
    const rawNotices = Array.isArray(value.notices) ? value.notices : null;
    if (!rawNotices || rawNotices.length > 6) throw new Error('The rendered page returned too much page-boundary evidence.');
    const notices = rawNotices.map(row => {
      if (!row || typeof row !== 'object' || Array.isArray(row)) throw new Error('The rendered page returned malformed page-boundary evidence.');
      const keys = Object.keys(row);
      if (keys.some(key => !['kind', 'tone', 'summary'].includes(key))) throw new Error('The rendered page returned unsupported page-boundary evidence.');
      const kind = text(row.kind).slice(0, 32);
      const tone = text(row.tone).slice(0, 20);
      const summary = text(row.summary).slice(0, 180);
      if (!allowedKinds.has(kind) || !allowedTones.has(tone) || !summary) throw new Error('The rendered page returned unsupported page-boundary evidence.');
      return {kind, tone, summary};
    });
    const rawSignals = value.signals && typeof value.signals === 'object' && !Array.isArray(value.signals) ? value.signals : null;
    if (!rawSignals) throw new Error('The rendered page did not identify its page-boundary signals.');
    const signalKeys = ['continuationLinks', 'paginationLandmarks', 'continuationControls', 'partialSetSignals', 'virtualMarkers', 'scrollWindows', 'modalLayers', 'embeddedFrames', 'openShadowRoots', 'busyRegions'];
    if (Object.keys(rawSignals).some(key => !signalKeys.includes(key))) throw new Error('The rendered page returned unsupported page-boundary signals.');
    const signals = {};
    signalKeys.forEach(key => { signals[key] = Math.max(0, Math.min(1000, Math.floor(Number(rawSignals[key]) || 0))); });
    signals.openShadowRoots = Math.min(32, signals.openShadowRoots);
    return {schema: NODE_CAPTURE_CONTEXT_SCHEMA, notices, signals};
  }

  function captureLimitingKinds(value = {}) {
    const context = capturePageContext(value);
    const limiting = new Set(['continuation', 'partial-render', 'overlay', 'loading', 'frames']);
    return context.notices.filter(row => limiting.has(row.kind)).map(row => row.kind);
  }

  function captureCoverageReview(value = {}, acknowledged = false) {
    const kinds = captureLimitingKinds(value);
    if (kinds.length && !acknowledged) throw new Error('Review the visible page-coverage limits before sending this capture.');
    return {
      schema: NODE_CAPTURE_COVERAGE_SCHEMA,
      decision: kinds.length ? 'use-current-rendering' : 'no-limiting-boundary-observed',
      acknowledgedNoticeKinds: kinds,
    };
  }

  function captureContextToneLabel(tone) {
    return tone === 'included' ? 'Included' : tone === 'caution' ? 'Check first' : 'Outside capture';
  }

  function captureContextKindLabel(kind) {
    const labels = {
      continuation: 'Page continues', 'partial-render': 'Partial rendering', overlay: 'Visible overlay',
      loading: 'Still loading', frames: 'Frames excluded', 'open-shadow': 'Open shadow inspected',
    };
    return labels[kind] || 'Page boundary';
  }

  function validateCaptureDocument(value, {origin} = {}) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('The Node returned an invalid browser request.');
    if (value.schema !== NODE_CAPTURE_SCHEMA || value.state !== 'review' || value.operationType !== 'capture-rendered-page-once') throw new Error('The Node returned an unsupported browser request.');
    if (value.scope !== 'one-expiring-rendered-page-capture' || value.automatic !== false || value.revocable !== true || value.network !== false || value.writes !== false) throw new Error('The browser request boundary is not the one this Extension expects.');
    const source = value.source;
    const node = value.node;
    const library = value.library;
    if (!source || source.type !== 'page' || !node || node.origin !== origin || !library) throw new Error('The Node browser request does not identify one watched page.');
    if (!text(source.sourceId) || !/^https?:/.test(text(source.url)) || !source.pageRecipe) throw new Error('The Node browser request is missing its exact watched-page recipe.');
    if (!/^sha256:[0-9a-f]{64}$/.test(text(node.instanceFingerprint)) || !/^[0-9a-f]{64}$/.test(text(library.sha256)) || !/^[0-9a-f]{64}$/.test(text(value.previewDigest)) || !/^[0-9a-f]{64}$/.test(text(value.recipeSha256))) throw new Error('The Node browser request is missing integrity evidence.');
    if (!['capture-now', 'enable-and-capture'].includes(value.action)) throw new Error('The Node browser request has an unsupported action.');
    const expiry = Date.parse(value.expiresAt || '');
    if (!Number.isFinite(expiry) || expiry <= Date.now() || expiry > Date.now() + 15 * 60 * 1000) throw new Error('This browser request is expired or has an unexpected lifetime.');
    if (Number(value.limits?.artifactBytes) !== MAX_CAPTURE_ARTIFACT_BYTES || value.limits?.topFrameOnly !== true || value.limits?.isolatedWorld !== true || value.limits?.arbitrarySharedCode !== false || Number(value.limits?.networkRequestsByNode) !== 0) throw new Error('The Node browser request has an unexpected capture boundary.');
    return value;
  }

  function capturePagePermissionPattern(value) {
    const url = new URL(String(value || ''));
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) throw new Error('The watched page address is not eligible for browser capture.');
    return `${url.protocol}//${url.host}/*`;
  }

  async function requestCapturePagePermission(capture) {
    const pattern = capturePagePermissionPattern(capture.document.source.url);
    const request = {origins: [pattern]};
    const already = api.permissions?.contains ? await api.permissions.contains(request).catch(() => false) : false;
    if (already) return {granted: true, added: false, pattern};
    if (!api.permissions?.request) throw new Error('This browser cannot request temporary access to the watched page.');
    const granted = Boolean(await api.permissions.request(request));
    return {granted, added: granted, pattern};
  }

  async function releaseCapturePermissions(capture) {
    if (!capture) return;
    if (capture.pagePermissionAdded && capture.pagePermissionPattern && api.permissions?.remove) {
      try { await api.permissions.remove({origins: [capture.pagePermissionPattern]}); } catch {}
    }
    capture.pagePermissionAdded = false;
    await releaseNodeHostPermission(Boolean(capture.hostPermissionAdded));
    capture.hostPermissionAdded = false;
  }

  function captureOutcome(value) {
    const labels = {baseline: 'Baseline saved', changed: 'Rendered change retained', unchanged: 'No meaningful change', 'watch-pending': 'Unusual shape held', 'coverage-shift': 'Rendered window held', 'needs-repair': 'Needs repair'};
    return labels[text(value)] || text(value, 'Capture completed').replaceAll('-', ' ');
  }

  function renderCaptureDiscovery(capture) {
    const doc = capture.document;
    const card = h('section', {class: 'discovery-card capture-review-card', 'aria-labelledby': 'capture-review-heading'});
    const result = capture.result;
    if (result) {
      const receipt = result.receipt || {};
      const summary = receipt.summary || {};
      const requestInfo = receipt.request || {};
      card.append(
        h('span', {class: 'node-state', text: result.replayed ? 'Receipt recovered' : captureOutcome(receipt.outcome)}),
        h('h3', {id: 'capture-review-heading', tabindex: '-1', text: receipt.outcome === 'coverage-shift' ? 'Earlier baseline kept' : captureOutcome(receipt.outcome)}),
        h('p', {text: result.replayed ? 'ProgRSS returned the original durable receipt. No second browser capture or library write occurred.' : receipt.outcome === 'coverage-shift' ? `${text(requestInfo.sourceTitle, doc.source.title)} kept its earlier baseline because this partial rendering looked like a different window.` : `${text(requestInfo.sourceTitle, doc.source.title)} was updated from one reviewed rendered-page artifact.`}),
        receipt.outcome === 'coverage-shift' ? h('p', {class: 'capture-anchor-note', text: 'The local Node now has a separate review for replacing this baseline. Nothing has been replaced yet.'}) : null,
        summary.message ? h('p', {class: `capture-result-note${summary.baselinePreserved ? ' baseline-preserved' : ''}`, text: summary.message}) : null,
        requestInfo.coverageDecision === 'use-current-rendering'
          ? h('p', {class: 'capture-coverage-result', text: 'You deliberately used the current rendered view despite visible page-coverage limits. ProgRSS did not follow, scroll, click, wait, or read frame contents.'})
          : null,
        h('div', {class: 'capture-result-metrics'}, [
          nodeFact('Items added', String(Number(summary.itemsAdded || 0))),
          nodeFact('Node site requests', '0'),
          nodeFact('Library revision', String(receipt.resultRevision || '—')),
          nodeFact('Schedule', 'None created'),
        ]),
      );
      const evidence = h('details', {class: 'node-advanced'});
      evidence.append(h('summary', {text: 'Advanced capture receipt'}), h('dl', {class: 'node-facts node-facts-advanced'}, [
        nodeFact('Receipt', receipt.receiptId || '—'), nodeFact('Operation', receipt.operationId || '—'),
        nodeFact('Artifact SHA-256', requestInfo.artifactSha256 || '—'), nodeFact('Recipe changed', requestInfo.recipeChanged ? 'Yes · fresh baseline' : 'No'),
        nodeFact('Top frame', requestInfo.topFrameOnly ? 'Only' : 'Unexpected'), nodeFact('Extraction world', requestInfo.isolatedWorld ? 'Isolated' : 'Unexpected'),
        nodeFact('Section evidence', requestInfo.selectionLevel ? `${captureAssessmentLabel(requestInfo.selectionLevel)} · ${text(requestInfo.selectionSummary, 'reviewed evidence retained')}` : 'Legacy capture · no section assessment'),
        nodeFact('Page boundary evidence', Array.isArray(requestInfo.pageContextKinds) && requestInfo.pageContextKinds.length ? requestInfo.pageContextKinds.map(captureContextKindLabel).join(' · ') : 'No retained page-boundary notice'),
        nodeFact('Coverage decision', requestInfo.coverageDecision === 'use-current-rendering'
          ? `Used current rendering · ${(requestInfo.acknowledgedBoundaryKinds || []).map(captureContextKindLabel).join(' · ') || 'reviewed limits'}`
          : requestInfo.coverageDecision === 'no-limiting-boundary-observed' ? 'No limiting boundary observed in this rendering' : 'Legacy capture · no coverage decision'),
        nodeFact('Rendered-window comparison', requestInfo.continuityAction === 'hold'
          ? `Held · ${Number(requestInfo.continuityOverlapPercent || 0)}% overlap · earlier baseline preserved`
          : requestInfo.continuitySchema ? `Accepted · ${Number(requestInfo.continuityOverlapPercent || 0)}% overlap` : 'Legacy capture · no continuity evidence'),
        nodeFact('Frames excluded', String(Number(requestInfo.embeddedFrames || 0))),
        nodeFact('Open shadow roots', String(Number(requestInfo.openShadowRoots || 0))),
      ]));
      card.append(evidence);
      const done = h('button', {class: 'primary wide', type: 'button', text: 'Done'});
      done.addEventListener('click', async () => { await releaseCapturePermissions(capture); app.discovery = null; renderDiscovery(); els.address.focus(); });
      card.append(done);
      els.discovery.append(card);
      return;
    }

    card.append(
      h('span', {class: 'node-state', text: capture.candidates ? 'Review extracted evidence' : 'Browser-assisted watch'}),
      h('h3', {id: 'capture-review-heading', tabindex: '-1', text: capture.candidates ? 'What part of this page counts as an update?' : 'Use the rendered page without sending the login'}),
      h('p', {text: capture.candidates
        ? 'Choose one bounded rendered section. ProgRSS shows examples before it sends text and links to the Node.'
        : `${text(doc.source.title, 'This watched page')} must be open at the exact reviewed address. The page may already be signed in, but the Node receives no cookie, credential, storage, raw HTML, form value, or screenshot.`}),
      h('dl', {class: 'node-facts'}, [
        nodeFact('Watched page', doc.source.url),
        nodeFact('Node', doc.node.origin),
        nodeFact('Request expires', relativeTime(doc.expiresAt)),
        nodeFact('Current recipe', doc.source.pageRecipe.mode === 'cards' ? `Repeated entries · ${text(doc.source.pageRecipe.selector, 'automatic')}` : `Readable region · ${text(doc.source.pageRecipe.selector, 'page body')}`),
      ]),
    );
    if (!capture.candidates) {
      const boundaries = h('div', {class: 'capture-boundaries'}, [
        h('article', {}, [h('strong', {text: 'Browser keeps authority'}), h('p', {text: 'The browser loads the page. Cookies, credentials, permissions, and storage never become a Node capability.'})]),
        h('article', {}, [h('strong', {text: 'Fixed extractor'}), h('p', {text: 'ProgRSS runs its own bounded top-frame extractor in the isolated extension world. Shared arbitrary JavaScript is not accepted.'})]),
        h('article', {}, [h('strong', {text: 'One reviewed result'}), h('p', {text: 'Nothing is sent until you review matched and ignored examples. No recurring schedule is created.'})]),
      ]);
      const captureButton = h('button', {class: 'primary wide', type: 'button', text: 'Capture this open page'});
      captureButton.addEventListener('click', () => captureOpenPage(capture, captureButton));
      const cancel = h('button', {class: 'quiet-button wide', type: 'button', text: 'Cancel without sending anything'});
      cancel.addEventListener('click', () => cancelCaptureReview(capture));
      card.append(boundaries, captureButton, cancel);
      els.discovery.append(card);
      return;
    }

    const choices = h('fieldset', {class: 'capture-choices'});
    choices.append(h('legend', {text: 'Rendered section'}));
    capture.candidates.forEach((candidate, index) => {
      const viable = candidate.recipe.mode === 'cards' ? Number(candidate.capture?.matchCount) > 0 : Boolean(text(candidate.capture?.content));
      const input = h('input', {type: 'radio', name: 'capture-choice', value: candidate.id, disabled: !viable});
      input.checked = capture.choice === candidate.id;
      input.addEventListener('change', () => { capture.choice = candidate.id; renderDiscovery(); });
      const examples = Array.isArray(candidate.examples?.matched) ? candidate.examples.matched.slice(0, 3) : [];
      const assessment = captureAssessment(candidate.assessment);
      const label = h('label', {class: `capture-choice${viable ? '' : ' unavailable'}`}, [
        input,
        h('span', {class: 'capture-choice-copy'}, [
          h('span', {class: 'capture-choice-heading'}, [
            h('strong', {text: candidate.label || `Choice ${index + 1}`}),
            h('span', {class: 'capture-stability-badge', 'data-level': assessment.level, text: captureAssessmentLabel(assessment.level)}),
          ]),
          h('small', {text: `${candidate.description || ''}${viable ? '' : ' No readable match was found.'}`}),
          h('small', {class: 'capture-assessment-summary', text: assessment.summary}),
          examples.length ? h('blockquote', {text: examples[0]}) : null,
        ]),
      ]);
      choices.append(label);
    });
    const pageContext = capturePageContext(capture.captureMeta?.context);
    const limitingKinds = captureLimitingKinds(pageContext);
    const contextPanel = h('section', {class: 'capture-page-context', 'aria-label': 'Page coverage boundaries'}, [
      h('div', {class: 'capture-page-context-heading'}, [
        h('strong', {text: 'What this browser view may leave outside'}),
        h('span', {class: 'capture-context-count', text: pageContext.notices.length ? `${pageContext.notices.length} notice${pageContext.notices.length === 1 ? '' : 's'}` : 'No extra notice'}),
      ]),
      h('p', {text: pageContext.notices.length
        ? 'These boundaries describe page coverage. They do not change the section-stability label below.'
        : 'No additional page-boundary warning was found in this one rendering. That is not proof that the page is complete.'}),
      pageContext.notices.length ? h('div', {class: 'capture-context-notices'}, pageContext.notices.map(notice => h('article', {'data-tone': notice.tone}, [
        h('div', {class: 'capture-context-notice-heading'}, [
          h('strong', {text: captureContextKindLabel(notice.kind)}),
          h('span', {text: captureContextToneLabel(notice.tone)}),
        ]),
        h('p', {text: notice.summary}),
      ]))) : null,
      pageContext.notices.some(row => ['continuation', 'partial-render', 'overlay', 'loading'].includes(row.kind))
        ? h('p', {class: 'field-help', text: 'Scroll, load more, or dismiss overlays first when needed, then use Capture the page again.'})
        : null,
      pageContext.notices.some(row => row.kind === 'partial-render')
        ? h('p', {class: 'capture-drift-note', text: 'Later comparison stays conservative: if another partial rendering looks like a different virtual window, ProgRSS keeps the earlier baseline instead of reporting a mass add-or-remove change.'})
        : null,
    ]);
    const advancedContext = h('details', {class: 'node-advanced capture-context-advanced'});
    advancedContext.append(h('summary', {text: 'Advanced page-boundary evidence'}), h('dl', {class: 'node-facts node-facts-advanced'}, [
      nodeFact('Continuation links', String(pageContext.signals.continuationLinks)),
      nodeFact('Pagination landmarks', String(pageContext.signals.paginationLandmarks)),
      nodeFact('Continuation controls', String(pageContext.signals.continuationControls)),
      nodeFact('Partial-set signals', String(pageContext.signals.partialSetSignals)),
      nodeFact('Virtual-list markers', String(pageContext.signals.virtualMarkers)),
      nodeFact('Scrollable list windows', String(pageContext.signals.scrollWindows)),
      nodeFact('Modal or consent layers', String(pageContext.signals.modalLayers)),
      nodeFact('Busy regions', String(pageContext.signals.busyRegions)),
      nodeFact('Embedded frames excluded', String(pageContext.signals.embeddedFrames)),
      nodeFact('Open shadow roots inspected', String(pageContext.signals.openShadowRoots)),
    ]), h('p', {class: 'field-help', text: 'Closed shadow roots cannot be inspected. Frame contents remain outside this top-frame-only capture.'}));
    card.append(contextPanel, advancedContext, choices);
    const selected = capture.candidates.find(row => row.id === capture.choice) || null;
    if (selected) {
      const examples = h('div', {class: 'capture-examples'}, [
        h('article', {}, [h('strong', {text: 'Matched now'}), ...(selected.examples.matched || []).slice(0, 3).map(row => h('p', {text: row}))]),
        h('article', {}, [h('strong', {text: 'Ignored example'}), h('p', {text: text(selected.examples.ignored, 'No separate navigation, footer, or aside example was found.')})]),
      ]);
      card.append(examples);
      const assessment = captureAssessment(selected.assessment);
      const assessmentPanel = h('section', {class: 'capture-assessment', 'aria-label': 'Section stability evidence'}, [
        h('div', {class: 'capture-assessment-heading'}, [
          h('strong', {text: captureAssessmentLabel(assessment.level)}),
          h('span', {class: 'capture-stability-badge', 'data-level': assessment.level, text: assessment.level === 'steadier' ? 'Steadier evidence' : assessment.level === 'watchful' ? 'Watchful evidence' : 'Fragile evidence'}),
        ]),
        h('p', {text: assessment.summary}),
        assessment.reasons.length ? h('div', {class: 'capture-assessment-column'}, [h('strong', {text: 'Why this may hold'}), h('ul', {}, assessment.reasons.map(row => h('li', {text: row})))]) : null,
        h('div', {class: 'capture-assessment-column'}, [h('strong', {text: 'What could break'}), assessment.warnings.length ? h('ul', {}, assessment.warnings.map(row => h('li', {text: row}))) : h('p', {text: 'No specific structural warning was found in this one observation.'})]),
        h('p', {class: 'field-help', text: 'This is bounded evidence from the page as rendered now, not a promise that the site will keep the same structure.'}),
      ]);
      const advancedAssessment = h('details', {class: 'node-advanced capture-assessment-advanced'});
      advancedAssessment.append(h('summary', {text: 'Advanced section evidence'}), h('dl', {}, [
        nodeFact('Selector kind', assessment.signals.selectorKind),
        nodeFact('Visible matches', String(assessment.signals.visibleMatches)),
        nodeFact('Hidden matches excluded', String(assessment.signals.hiddenMatches)),
        nodeFact('Repeated entries', String(assessment.signals.repeatedEntries)),
        nodeFact('Linked / titled', `${assessment.signals.linkedEntries} / ${assessment.signals.titledEntries}`),
        nodeFact('Consistent shapes', String(assessment.signals.consistentEntries)),
        nodeFact('Clutter landmarks', String(assessment.signals.clutterElements)),
        nodeFact('Readable characters', String(assessment.signals.textCharacters)),
      ]));
      card.append(assessmentPanel, advancedAssessment);
      if (limitingKinds.length) {
        const recaptureBeforeBaseline = h('button', {class: 'secondary wide', type: 'button', text: 'Capture the page again first'});
        recaptureBeforeBaseline.addEventListener('click', () => captureOpenPage(capture, recaptureBeforeBaseline));
        const coverageConfirm = h('label', {class: 'decision-check capture-coverage-decision'}, [
          h('input', {type: 'checkbox'}),
          h('span', {}, [
            h('strong', {text: 'Use this rendered view as the baseline'}),
            h('small', {text: 'ProgRSS will save only this current top-frame rendering. It will not follow pagination, scroll a virtual list, click or dismiss controls, wait for loading, or read frame contents.'}),
          ]),
        ]);
        coverageConfirm.querySelector('input').checked = Boolean(capture.coverageAcknowledged);
        coverageConfirm.querySelector('input').addEventListener('change', event => { capture.coverageAcknowledged = event.target.checked; renderDiscovery(); });
        card.append(h('section', {class: 'capture-coverage-review', 'aria-label': 'Rendered view coverage decision'}, [
          h('h4', {text: 'Before this becomes the baseline'}),
          h('p', {text: `This rendering has ${limitingKinds.length} visible coverage limit${limitingKinds.length === 1 ? '' : 's'}. Capture again after loading or dismissing what you can, or deliberately use only this view.`}),
          recaptureBeforeBaseline,
          coverageConfirm,
        ]));
      }
      const changed = captureRecipeKey(selected.recipe) !== captureRecipeKey(doc.source.pageRecipe);
      capture.recipeChanged = changed;
      if (changed) {
        const confirm = h('label', {class: 'decision-check'}, [h('input', {type: 'checkbox'}), h('span', {}, [h('strong', {text: 'Use this new watched section'}), h('small', {text: 'The Node will replace the declarative extraction recipe and save a fresh baseline. It will not invent an old change.'})])]);
        confirm.querySelector('input').checked = Boolean(capture.recipeChangeAcknowledged);
        confirm.querySelector('input').addEventListener('change', event => { capture.recipeChangeAcknowledged = event.target.checked; renderDiscovery(); });
        card.append(confirm);
      }
      const send = h('button', {
        class: 'primary wide', type: 'button',
        text: limitingKinds.length ? (doc.action === 'enable-and-capture' ? 'Enable, use this view, and send once' : 'Use this view and send once') : (doc.action === 'enable-and-capture' ? 'Enable and send this capture once' : 'Send this reviewed capture once'),
        disabled: (changed && !capture.recipeChangeAcknowledged) || (limitingKinds.length && !capture.coverageAcknowledged),
      });
      send.addEventListener('click', () => commitBrowserCapture(capture, selected, send));
      card.append(send);
    }
    const recapture = h('button', {class: 'secondary wide', type: 'button', text: 'Capture the page again'});
    recapture.addEventListener('click', () => captureOpenPage(capture, recapture));
    const cancel = h('button', {class: 'quiet-button wide', type: 'button', text: 'Cancel without sending anything'});
    cancel.addEventListener('click', () => cancelCaptureReview(capture));
    if (!limitingKinds.length) card.append(recapture);
    card.append(cancel, h('p', {class: 'field-help', text: 'Only the selected bounded text and links are sent. Site scripts, cookies, storage, form values, raw markup, and screenshots are excluded.'}));
    els.discovery.append(card);
  }

  async function reviewCaptureInvitation(raw) {
    let invitation;
    try { invitation = parseCaptureInvitation(raw); }
    catch (error) { setStatus(error.message, 'error'); return; }
    busy('inspect', true);
    let permission = {granted: false, added: false};
    try {
      permission = await requestNodeHostPermission();
      if (!permission.granted) { setStatus('The browser did not grant access to this local Node. Nothing was captured or changed.', 'decision'); return; }
      const document = validateCaptureDocument(await nodeFetch(invitation.origin, '/api/v1/capture-review', invitation.token), {origin: invitation.origin});
      app.discovery = {kind: 'capture', capture: {origin: invitation.origin, token: invitation.token, document, hostPermissionAdded: permission.added, pagePermissionAdded: false, pagePermissionPattern: '', candidates: null, choice: '', operationId: `cap-${crypto.randomUUID()}`}};
      els.address.value = '';
      renderDiscovery();
      requestAnimationFrame(() => $('#capture-review-heading')?.focus());
      setStatus('Browser request reviewed · the watched page has not been read or sent yet', 'success');
    } catch (error) {
      await releaseNodeHostPermission(permission.added);
      setStatus(error.message || 'ProgRSS could not review that browser request.', 'error');
    } finally { busy('inspect', false); }
  }

  async function captureOpenPage(capture, button) {
    button.disabled = true;
    const old = button.textContent;
    button.textContent = 'Reading rendered page…';
    try {
      const permission = await requestCapturePagePermission(capture);
      if (!permission.granted) { setStatus('The browser did not grant access to this page. Nothing was sent to the Node.', 'decision'); return; }
      capture.pagePermissionAdded = Boolean(capture.pagePermissionAdded || permission.added);
      capture.pagePermissionPattern = permission.pattern;
      const result = await request('capture-rendered-page', {expectedUrl: capture.document.source.url, sourceId: capture.document.source.sourceId, recipe: capture.document.source.pageRecipe});
      if (result.schema !== NODE_CAPTURE_CANDIDATES_SCHEMA || normalizedCaptureUrl(result.page?.url) !== normalizedCaptureUrl(capture.document.source.url) || result.source?.id !== capture.document.source.sourceId || !Array.isArray(result.candidates) || result.candidates.length < 1 || result.candidates.length > 3) throw new Error('The rendered-page evidence did not match this watched page.');
      capture.captureMeta = {...result, context: capturePageContext(result.context)};
      capture.candidates = result.candidates;
      const saved = result.candidates.find(row => row.id === 'saved' && (row.recipe?.mode === 'cards' ? Number(row.capture?.matchCount) > 0 : Boolean(text(row.capture?.content))));
      const viable = saved || result.candidates.find(row => row.recipe?.mode === 'cards' ? Number(row.capture?.matchCount) > 0 : Boolean(text(row.capture?.content)));
      capture.choice = viable?.id || '';
      capture.recipeChangeAcknowledged = false;
      capture.coverageAcknowledged = false;
      renderDiscovery();
      requestAnimationFrame(() => $('#capture-review-heading')?.focus());
      setStatus('Rendered evidence is ready for review. Nothing has been sent to the Node.', 'success');
    } catch (error) { setStatus(error.message, 'error'); }
    finally { button.disabled = false; button.textContent = old; }
  }

  async function commitBrowserCapture(capture, selected, button) {
    const meta = capture.captureMeta;
    const pageContext = capturePageContext(meta?.context);
    const limitingKinds = captureLimitingKinds(pageContext);
    if (!selected || (capture.recipeChanged && !capture.recipeChangeAcknowledged) || (limitingKinds.length && !capture.coverageAcknowledged)) return;
    const artifact = {
      schema: NODE_CAPTURE_ARTIFACT_SCHEMA,
      capturedAt: meta.capturedAt,
      page: meta.page,
      source: meta.source,
      context: pageContext,
      coverage: captureCoverageReview(pageContext, Boolean(capture.coverageAcknowledged)),
      recipe: captureRecipe(selected.recipe),
      capture: selected.capture,
      examples: {matched: (selected.examples?.matched || []).slice(0, 3), ignored: text(selected.examples?.ignored).slice(0, 500)},
      selection: {schema: NODE_CAPTURE_SELECTION_SCHEMA, candidateId: text(selected.id).slice(0, 40), assessment: captureAssessment(selected.assessment)},
      provenance: meta.provenance,
    };
    const bytes = new TextEncoder().encode(JSON.stringify(artifact));
    if (bytes.byteLength > MAX_CAPTURE_ARTIFACT_BYTES) { setStatus('This rendered capture is larger than the 300 KB boundary. Choose a smaller section.', 'error'); return; }
    button.disabled = true;
    const old = button.textContent;
    button.textContent = 'Committing one capture…';
    try {
      capture.result = await nodeFetch(capture.origin, '/api/v1/captures', capture.token, {
        method: 'POST',
        headers: {'If-Match': `"${capture.document.library.sha256}"`, 'Idempotency-Key': capture.operationId},
        body: JSON.stringify({operationType: 'capture-rendered-page-once', sourceId: capture.document.source.sourceId, action: capture.document.action, previewDigest: capture.document.previewDigest, recipeChangeAcknowledged: Boolean(capture.recipeChangeAcknowledged), artifact}),
      });
      renderDiscovery();
      requestAnimationFrame(() => $('#capture-review-heading')?.focus());
      setStatus(capture.result.replayed ? 'Original capture receipt recovered · no second write occurred' : `${captureOutcome(capture.result.receipt?.outcome)} · zero Node site requests · no schedule created`, 'success');
    } catch (error) { setStatus(`${error.message} Retrying keeps the same operation key; a completed write returns its original receipt.`, 'error'); }
    finally { button.disabled = false; button.textContent = old; }
  }

  async function cancelCaptureReview(capture) {
    await releaseCapturePermissions(capture);
    app.discovery = null;
    renderDiscovery();
    els.address.focus();
    setStatus('Browser request canceled. No rendered evidence was sent and no library write occurred.', '');
  }

  function looksLikeExchangeInvitation(value) {
    try {
      const url = new URL(String(value || '').trim());
      return url.protocol === 'http:' && url.hostname === '127.0.0.1' && new URLSearchParams(url.hash.slice(1)).has('exchange');
    } catch {
      return false;
    }
  }

  function parseExchangeInvitation(value) {
    const raw = String(value || '').trim();
    if (!raw || raw.length > 4096) throw new Error('Paste the complete handoff from ProgRSS Node.');
    let url;
    try { url = new URL(raw); } catch { throw new Error('That is not a complete ProgRSS handoff.'); }
    if (url.protocol !== 'http:' || url.hostname !== '127.0.0.1') {
      throw new Error('This release accepts Node handoffs only from 127.0.0.1 on this device.');
    }
    if (url.username || url.password || url.search || !url.port || !['', '/'].includes(url.pathname)) {
      throw new Error('That handoff has an unexpected address shape. Ask the sender to create a new handoff.');
    }
    const port = Number(url.port);
    if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('That handoff has an invalid Node port.');
    const fragment = new URLSearchParams(url.hash.slice(1));
    const values = fragment.getAll('exchange');
    const allowedKeys = [...fragment.keys()].every(key => key === 'exchange');
    const token = values.length === 1 ? values[0] : '';
    if (!allowedKeys || !/^[A-Za-z0-9_-]{40,80}$/.test(token)) {
      throw new Error('That handoff is incomplete or contains unexpected information.');
    }
    return {origin: url.origin, token};
  }

  function validExchangePublicUrl(value) {
    try {
      const url = new URL(String(value || ''));
      return ['http:', 'https:'].includes(url.protocol) && !url.username && !url.password ? url.href : '';
    } catch {
      return '';
    }
  }

  function validateExchangeDocument(value, {origin} = {}) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('The Node returned an invalid handoff response.');
    if (value.schema !== NODE_EXCHANGE_SCHEMA || value.state !== 'review') throw new Error('The Node returned an unsupported handoff response.');
    if (value.scope !== 'one-expiring-reviewed-artifact-handoff' || value.revocable !== true || value.automatic !== false || value.network !== false || value.writes !== false) {
      throw new Error('The Node handoff boundary is not the one this Extension expects.');
    }
    const node = value.node;
    const library = value.library;
    const counts = value.counts;
    const choices = value.choices;
    const artifacts = value.artifacts;
    if (!node || !library || !counts || !choices || !artifacts || node.origin !== origin) throw new Error('The Node response does not match this handoff.');
    if (!/^sha256:[0-9a-f]{64}$/.test(text(node.instanceFingerprint)) || node.identityPersistence !== 'until-node-stops') {
      throw new Error('The Node did not provide the expected session fingerprint.');
    }
    if (!/^[0-9a-f]{64}$/.test(text(library.sha256)) || !text(library.file)) throw new Error('The Node did not identify the exact library copy used for this handoff.');
    const numericCounts = ['sources', 'feeds', 'pageWatches', 'folders', 'recentUpdates'];
    if (numericCounts.some(key => !Number.isInteger(Number(counts[key])) || Number(counts[key]) < 0 || Number(counts[key]) > 1_000_000)) {
      throw new Error('The Node returned invalid handoff counts.');
    }
    if (Number(counts.feeds) + Number(counts.pageWatches) !== Number(counts.sources)) throw new Error('The Node returned inconsistent handoff counts.');
    const expiry = Date.parse(value.expiresAt || '');
    const now = Date.now();
    if (!Number.isFinite(expiry) || expiry <= now || expiry > now + 40 * 60 * 1000) throw new Error('This handoff is expired or has an unexpected lifetime.');
    const sourceArtifact = artifacts.sourceList;
    if (!sourceArtifact || sourceArtifact.available !== true || sourceArtifact.mediaType !== 'application/vnd.progrss.shared-folder+json' ||
        !Number.isInteger(Number(sourceArtifact.bytes)) || Number(sourceArtifact.bytes) < 1 || Number(sourceArtifact.bytes) > MAX_EXCHANGE_ARTIFACT_BYTES ||
        !/^[0-9a-f]{64}$/.test(text(sourceArtifact.sha256))) {
      throw new Error('This handoff does not contain a bounded ProgRSS source list.');
    }
    if (choices.addRoute?.available !== true) throw new Error('This handoff does not offer the expected complete-route choice.');
    const branchChoice = choices.takeBranch;
    const branches = Array.isArray(branchChoice?.branches) ? branchChoice.branches : [];
    if (branchChoice?.available !== Boolean(branches.length) || branches.length > 200 || branches.some(branch =>
      !text(branch?.id) || !text(branch?.path) || !Number.isInteger(Number(branch?.sources)) || Number(branch.sources) < 1 || Number(branch.sources) > Number(counts.sources)
    )) throw new Error('This handoff contains invalid branch choices.');
    const follow = choices.followUpdates;
    const updateArtifact = artifacts.recentUpdates;
    if (!follow || typeof follow.available !== 'boolean') throw new Error('This handoff does not explain whether recent updates can be followed.');
    if (follow.available) {
      if (!validExchangePublicUrl(follow.feedUrl) || !updateArtifact || updateArtifact.available !== true || updateArtifact.mediaType !== 'application/feed+json' ||
          !Number.isInteger(Number(updateArtifact.bytes)) || Number(updateArtifact.bytes) < 1 || Number(updateArtifact.bytes) > MAX_EXCHANGE_ARTIFACT_BYTES ||
          !/^[0-9a-f]{64}$/.test(text(updateArtifact.sha256))) {
        throw new Error('This handoff offers recent updates without a valid durable feed artifact.');
      }
    }
    const contents = value.contents;
    if (!contents || !Array.isArray(contents.sources) || !Array.isArray(contents.folders) || contents.sources.length > 40 || contents.folders.length > 30) {
      throw new Error('This handoff contains an invalid bounded contents preview.');
    }
    if (!/^[0-9a-f]{20}$/.test(text(value.exchangeId)) || !/^[0-9a-f]{64}$/.test(text(value.previewDigest))) {
      throw new Error('The Node did not identify the reviewed handoff.');
    }
    return value;
  }

  async function sha256Hex(bytes) {
    if (!globalThis.crypto?.subtle) throw new Error('This browser cannot verify the handoff artifact digest.');
    const digest = await globalThis.crypto.subtle.digest('SHA-256', bytes);
    return [...new Uint8Array(digest)].map(value => value.toString(16).padStart(2, '0')).join('');
  }

  async function nodeFetchBytes(origin, path, token, {maxBytes = MAX_EXCHANGE_ARTIFACT_BYTES, mediaType = ''} = {}) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10_000);
    try {
      const response = await fetch(`${origin}${path}`, {
        cache: 'no-store', credentials: 'omit', referrerPolicy: 'no-referrer', signal: controller.signal,
        headers: {Authorization: `Bearer ${token}`},
      });
      const bytes = await response.arrayBuffer();
      if (!response.ok) {
        let message = `Node request failed (${response.status}).`;
        try { message = text(JSON.parse(new TextDecoder().decode(bytes))?.error, message); } catch {}
        throw new Error(message);
      }
      if (bytes.byteLength < 1 || bytes.byteLength > maxBytes) throw new Error(`The handoff artifact is empty or larger than the ${Math.round(maxBytes / 1_000_000)} MB review limit.`);
      const type = String(response.headers.get('Content-Type') || '').split(';', 1)[0].trim().toLowerCase();
      if (mediaType && type !== mediaType.toLowerCase()) throw new Error('The Node returned an unexpected artifact type.');
      return {bytes, contentType: type};
    } catch (error) {
      if (error?.name === 'AbortError') throw new Error('The Node did not respond. Make sure the handoff is still available, then try again.');
      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }

  async function ensureExchangeHostPermission(exchange) {
    if (!exchange) return false;
    const permission = await requestNodeHostPermission();
    if (!permission.granted) {
      setStatus('The browser did not grant access to this local Node. Nothing was imported or followed.', 'decision');
      return false;
    }
    exchange.hostPermissionAdded = Boolean(exchange.hostPermissionAdded || permission.added);
    return true;
  }

  async function releaseExchangeHostPermission(exchange) {
    if (!exchange) return;
    await releaseNodeHostPermission(Boolean(exchange.hostPermissionAdded));
    exchange.hostPermissionAdded = false;
  }

  function exchangeArtifact(value, kind) {
    if (kind === 'source-list') return value?.artifacts?.sourceList;
    if (kind === 'recent-updates') return value?.artifacts?.recentUpdates;
    return null;
  }

  async function fetchExchangeArtifact(exchange, kind) {
    if (!exchange || !await ensureExchangeHostPermission(exchange)) return null;
    const artifact = exchangeArtifact(exchange.document, kind);
    if (!artifact?.available) throw new Error('That artifact is not available in this handoff.');
    const path = kind === 'source-list' ? '/api/v1/exchange/source-list' : '/api/v1/exchange/recent-updates';
    try {
      const fetched = await nodeFetchBytes(exchange.origin, path, exchange.token, {
        maxBytes: MAX_EXCHANGE_ARTIFACT_BYTES,
        mediaType: artifact.mediaType,
      });
      if (fetched.bytes.byteLength !== Number(artifact.bytes)) throw new Error('The handoff artifact size changed after review.');
      const digest = await sha256Hex(fetched.bytes);
      if (digest !== artifact.sha256) throw new Error('The handoff artifact digest changed after review.');
      let raw;
      try { raw = new TextDecoder('utf-8', {fatal: true}).decode(fetched.bytes); }
      catch { throw new Error('The handoff artifact is not valid UTF-8 text.'); }
      return {raw, contentType: fetched.contentType, artifact};
    } finally {
      await releaseExchangeHostPermission(exchange);
    }
  }

  async function reviewExchangeInvitation(raw) {
    let invitation;
    try { invitation = parseExchangeInvitation(raw); }
    catch (error) { setStatus(error.message, 'error'); els.address.focus(); return; }
    app.discovery = {loading: true};
    renderDiscovery();
    busy('exchange-review', true);
    let permission = {granted: false, added: false};
    try {
      permission = await requestNodeHostPermission();
      if (!permission.granted) {
        app.discovery = null;
        renderDiscovery();
        setStatus('The browser did not grant access to this local Node. Nothing was reviewed.', 'decision');
        return;
      }
      const exchangeDocument = validateExchangeDocument(
        await nodeFetch(invitation.origin, '/api/v1/exchange-review', invitation.token),
        {origin: invitation.origin},
      );
      app.discovery = {
        kind: 'exchange',
        exchange: {origin: invitation.origin, token: invitation.token, document: exchangeDocument, hostPermissionAdded: permission.added},
      };
      els.address.value = '';
      renderDiscovery();
      requestAnimationFrame(() => globalThis.document.getElementById('exchange-review-heading')?.focus());
    } catch (error) {
      await releaseNodeHostPermission(permission.added);
      app.discovery = {error: error.message || 'ProgRSS could not review that handoff.'};
      renderDiscovery();
    } finally {
      busy('exchange-review', false);
    }
  }

  async function useExchangeSourceList(exchange, selectedFolderId = '', button = null) {
    if (!exchange) return;
    if (button) { button.disabled = true; button.textContent = selectedFolderId ? 'Opening branch…' : 'Opening route…'; }
    busy('exchange-artifact', true);
    try {
      const fetched = await fetchExchangeArtifact(exchange, 'source-list');
      if (!fetched) return;
      const preview = await request('preview-shared-folder', {raw: fetched.raw, selectedFolderId});
      app.sharedFolder = {
        fileName: `${text(exchange.document.title, 'Shared route')} · ProgRSS handoff`,
        raw: fetched.raw,
        preview,
        remote: {automatic: false, handoff: true, nodeOrigin: exchange.origin, artifactSha256: fetched.artifact.sha256},
        returnToDiscovery: true,
        returnContext: 'exchange',
        trustAcknowledged: false,
      };
      els.sharedFolderCard.hidden = false;
      renderSharedFolder();
      requestAnimationFrame(() => {
        $('#shared-folder-review-heading')?.focus();
        els.sharedFolderCard.scrollIntoView({block: 'start'});
      });
    } catch (error) {
      setStatus(error.message || 'ProgRSS could not open that source route.', 'error');
    } finally {
      busy('exchange-artifact', false);
      if (button) button.disabled = false;
    }
  }

  async function followExchangeUpdates(exchange, button = null) {
    if (!exchange) return;
    if (button) { button.disabled = true; button.textContent = 'Opening updates…'; }
    busy('exchange-artifact', true);
    try {
      const feedUrl = validExchangePublicUrl(exchange.document.choices?.followUpdates?.feedUrl);
      if (!feedUrl) throw new Error(text(exchange.document.choices?.followUpdates?.reason, 'This handoff does not include a durable updates feed.'));
      const fetched = await fetchExchangeArtifact(exchange, 'recent-updates');
      if (!fetched) return;
      const inspected = await request('preview-feed-text', {raw: fetched.raw, url: feedUrl, contentType: fetched.contentType});
      const returnDiscovery = {kind: 'exchange', exchange};
      app.discovery = {...inspected, permissionGranted: false, returnDiscovery, returnFocusId: 'exchange-follow-updates'};
      renderDiscovery();
      requestAnimationFrame(() => document.getElementById('feed-preview-heading')?.focus());
    } catch (error) {
      setStatus(error.message || 'ProgRSS could not open those recent updates.', 'error');
    } finally {
      busy('exchange-artifact', false);
      if (button) button.disabled = false;
    }
  }

  async function cancelExchangeReview(exchange) {
    await releaseExchangeHostPermission(exchange);
    app.discovery = null;
    renderDiscovery();
    els.address.focus();
    setStatus('Handoff closed. Nothing was imported or followed, and newly granted Node access was released.', 'decision');
  }

  function validateNodePairingDocument(value, {origin, state, fingerprint = '', libraryDigest = ''} = {}) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('The Node returned an invalid pairing response.');
    if (value.schema !== NODE_PAIRING_SCHEMA || value.state !== state) throw new Error('The Node returned an unsupported pairing response.');
    const node = value.node;
    const library = value.library;
    const capabilities = value.capabilities;
    if (!node || !library || !capabilities || node.origin !== origin) throw new Error('The Node response does not match this invitation.');
    if (!/^sha256:[0-9a-f]{64}$/.test(text(node.instanceFingerprint)) || node.identityPersistence !== 'until-node-stops') {
      throw new Error('The Node did not provide the expected session fingerprint.');
    }
    if (fingerprint && node.instanceFingerprint !== fingerprint) throw new Error('The Node session changed. Stop and create a new invitation.');
    if (!/^[0-9a-f]{64}$/.test(text(library.sha256)) || !text(library.file) || !library.stats || typeof library.stats !== 'object') {
      throw new Error('The Node did not provide a valid library summary.');
    }
    const libraryMode = text(library.mode, 'exported-backup');
    if (!['exported-backup', 'node-owned'].includes(libraryMode)) throw new Error('The Node reported an unsupported library mode.');
    library.mode = libraryMode;
    if (libraryDigest && library.sha256 !== libraryDigest) throw new Error('The selected Node library changed after review. Review a fresh invitation.');
    const numericStats = ['sources', 'activeSources', 'pageWatches', 'folders', 'items', 'unread', 'saved'];
    if (numericStats.some(key => !Number.isInteger(Number(library.stats[key])) || Number(library.stats[key]) < 0 || Number(library.stats[key]) > 1_000_000)) {
      throw new Error('The Node returned invalid library counts.');
    }
    const exact = {
      readLibrarySummary: true,
      readItems: false,
      readSourceAddresses: false,
      writeLibrary: false,
      fetchSources: false,
      publish: false,
      merge: false,
      nodeToNode: false,
      webrtcCourier: false,
    };
    if (capabilities.schema !== 'progrss.node.capabilities.v1' || Object.entries(exact).some(([key, expected]) => capabilities[key] !== expected)) {
      throw new Error('This Node is asking for capabilities this Extension does not accept.');
    }
    if (value.scope !== 'loopback-session-read-only-summary' || value.automatic !== false || value.revocable !== true) {
      throw new Error('The Node pairing boundary is not the one this Extension expects.');
    }
    if (state === 'review') {
      const expiry = Date.parse(value.expiresAt || '');
      const now = Date.now();
      if (!Number.isFinite(expiry) || expiry <= now || expiry > now + 15 * 60 * 1000) throw new Error('This invitation is expired or has an unexpected lifetime.');
    }
    if (state === 'paired') {
      const pairing = value.pairing;
      let thisExtensionOrigin = '';
      try { thisExtensionOrigin = new URL(api?.runtime?.getURL?.('') || globalThis.location?.href || '').origin; } catch {}
      if (
        !pairing ||
        !/^[0-9a-f]{20}$/.test(text(pairing.pairId)) ||
        !/^[0-9a-f]{64}$/.test(text(pairing.reviewedLibrarySha256)) ||
        !['chrome-extension:', 'moz-extension:'].includes((() => { try { return new URL(text(pairing.origin)).protocol; } catch { return ''; } })()) ||
        !thisExtensionOrigin ||
        pairing.origin !== thisExtensionOrigin
      ) {
        throw new Error('The Node did not return a pairing record for this Extension.');
      }
    }
    return value;
  }

  async function nodeFetch(origin, path, token, options = {}) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10_000);
    try {
      const response = await fetch(`${origin}${path}`, {
        ...options,
        cache: 'no-store',
        credentials: 'omit',
        referrerPolicy: 'no-referrer',
        signal: controller.signal,
        headers: {
          ...(options.body ? {'Content-Type': 'application/json'} : {}),
          ...options.headers,
          Authorization: `Bearer ${token}`,
        },
      });
      const body = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(text(body?.error, `Node request failed (${response.status}).`));
      return body;
    } catch (error) {
      if (error?.name === 'AbortError') throw new Error('The Node did not respond. Make sure it is still running, then try again.');
      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }

  function renderNodePairing() {
    const review = app.nodeReview;
    const pairing = app.nodePairing;
    els.nodePairingStart.hidden = Boolean(review || pairing);
    els.nodeReview.hidden = !review || Boolean(pairing);
    els.nodePaired.hidden = !pairing;
    els.nodeReviewFacts.replaceChildren();
    els.nodePairedFacts.replaceChildren();
    els.nodeAdvancedFacts.replaceChildren();

    if (pairing) {
      const document = pairing.document;
      const stats = document.library.stats;
      const libraryChanged = document.library.sha256 !== document.pairing.reviewedLibrarySha256;
      els.nodeStateBadge.textContent = libraryChanged ? 'Paired · file changed' : 'Paired read-only';
      els.nodeStateBadge.dataset.state = libraryChanged ? 'review' : 'paired';
      els.nodePairingSummary.textContent = libraryChanged
        ? 'The same Node session answered, but its selected library file changed after pairing.'
        : 'One running Node is paired. It shares only a session marker and library counts.';
      const libraryModeLabel = document.library.mode === 'node-owned' ? 'Node-owned transactional library' : 'Exported backup opened read-only';
      els.nodePairedMessage.textContent = libraryChanged
        ? `Connected to ${document.library.file}. Its current digest differs from the copy reviewed at pairing. Nothing was synchronized.`
        : `Connected to ${document.library.file}. ${document.library.mode === 'node-owned' ? 'The Node can perform its own locally reviewed operations, but this pairing remains summary-only.' : 'Nothing is synchronized automatically.'}`;
      els.nodePairedFacts.append(
        nodeFact('Node', document.node.origin),
        nodeFact('Session fingerprint', compactNodeFingerprint(document.node.instanceFingerprint)),
        nodeFact('Library', document.library.file),
        nodeFact('Library mode', libraryModeLabel),
        nodeFact('Library state', libraryChanged ? 'Changed since pairing' : 'Matches reviewed copy'),
        nodeFact('Contents', `${countLabel(stats.sources, 'source')} · ${countLabel(stats.unread, 'unread update')}`),
      );
      els.nodeAdvancedFacts.append(
        nodeFact('Full session fingerprint', document.node.instanceFingerprint),
        nodeFact('Current library SHA-256', document.library.sha256),
        nodeFact('Reviewed library SHA-256', document.pairing.reviewedLibrarySha256),
        nodeFact('Pair ID', document.pairing.pairId),
        nodeFact('Scope', document.scope),
        nodeFact('Browser access', '127.0.0.1 · host-scoped'),
      );
      return;
    }
    if (review) {
      const document = review.document;
      const stats = document.library.stats;
      els.nodeStateBadge.textContent = 'Reviewing';
      els.nodeStateBadge.dataset.state = 'review';
      els.nodePairingSummary.textContent = 'Check this Node session and its limits before pairing.';
      els.nodeReviewExpiry.textContent = `Expires ${relativeTime(document.expiresAt)}`;
      const libraryModeLabel = document.library.mode === 'node-owned' ? 'Node-owned transactional library' : 'Exported backup opened read-only';
      els.nodeReviewMessage.textContent = `This is ${document.library.file}. Pairing reveals only the summary shown here; it does not grant the Extension Node write authority.`;
      els.nodeReviewFacts.append(
        nodeFact('Node', document.node.origin),
        nodeFact('Session fingerprint', compactNodeFingerprint(document.node.instanceFingerprint)),
        nodeFact('Library', document.library.file),
        nodeFact('Library mode', libraryModeLabel),
        nodeFact('Sources', `${countLabel(stats.sources, 'source')} · ${countLabel(stats.pageWatches, 'watched page')}`),
        nodeFact('Reading', `${countLabel(stats.items, 'update')} · ${countLabel(stats.unread, 'unread')}`),
      );
      return;
    }
    els.nodeStateBadge.textContent = 'Not connected';
    delete els.nodeStateBadge.dataset.state;
    els.nodePairingSummary.textContent = 'Use a short-lived invitation from a Node you started yourself.';
  }

  function focusNodePairing() {
    setView('add');
    els.nodePairingCard.scrollIntoView({block: 'nearest'});
    requestAnimationFrame(() => (app.nodePairing ? els.nodePairedHeading : app.nodeReview ? els.nodeReviewHeading : els.nodeInvitation).focus({preventScroll: true}));
  }

  async function requestNodeHostPermission() {
    const request = {origins: [NODE_PAIRING_PERMISSION]};
    if (!api?.permissions?.request) throw new Error('This browser cannot request local Node access.');
    // Start the prior-authority check without awaiting it, then invoke request() in the
    // same visible Review gesture. Awaiting unrelated work first can lose user activation.
    const alreadyGranted = api.permissions.contains
      ? Promise.resolve(api.permissions.contains(request)).catch(() => false)
      : Promise.resolve(false);
    const granted = Boolean(await api.permissions.request(request));
    return {granted, added: granted && !Boolean(await alreadyGranted)};
  }

  async function releaseNodeHostPermission(added) {
    if (!added || !api?.permissions?.remove) return false;
    try { return Boolean(await api.permissions.remove({origins: [NODE_PAIRING_PERMISSION]})); }
    catch { return false; }
  }

  async function reviewNodeInvitation() {
    let invitation;
    try { invitation = parseNodeInvitation(els.nodeInvitation.value); }
    catch (error) { setStatus(error.message, 'error'); els.nodeInvitation.focus(); return; }
    busy('node-pairing', true);
    let permission = {granted: false, added: false};
    try {
      permission = await requestNodeHostPermission();
      if (!permission.granted) {
        setStatus('The browser did not grant access to this device. Nothing was paired.', 'decision');
        return;
      }
      const document = validateNodePairingDocument(
        await nodeFetch(invitation.origin, '/api/v1/pairing-review', invitation.token),
        {origin: invitation.origin, state: 'review'},
      );
      app.nodeReview = {origin: invitation.origin, token: invitation.token, document, hostPermissionAdded: permission.added};
      els.nodeInvitation.value = '';
      renderNodePairing();
      requestAnimationFrame(() => els.nodeReviewHeading.focus());
    } catch (error) {
      await releaseNodeHostPermission(permission.added);
      setStatus(error.message || 'ProgRSS could not review that Node.', 'error');
    } finally {
      busy('node-pairing', false);
    }
  }

  async function pairReviewedNode() {
    if (!app.nodeReview) return;
    const review = app.nodeReview;
    busy('node-pairing', true);
    try {
      const manifestVersion = text(api?.runtime?.getManifest?.()?.version, 'unknown');
      const response = await nodeFetch(review.origin, '/api/v1/pairings', review.token, {
        method: 'POST',
        body: JSON.stringify({clientName: 'ProgRSS Extension', clientVersion: manifestVersion}),
      });
      const pairToken = text(response?.token);
      if (!/^[A-Za-z0-9_-]{40,80}$/.test(pairToken)) throw new Error('The Node did not return a valid pairing capability.');
      const document = validateNodePairingDocument(response, {
        origin: review.origin,
        state: 'paired',
        fingerprint: review.document.node.instanceFingerprint,
        libraryDigest: review.document.library.sha256,
      });
      const stored = {
        schema: NODE_PAIRING_STORAGE_SCHEMA,
        origin: review.origin,
        token: pairToken,
        document,
        savedAt: new Date().toISOString(),
        hostPermissionAdded: Boolean(review.hostPermissionAdded),
      };
      app.nodePairing = stored;
      app.nodeReview = null;
      await api.storage.local.set({nodePairing: stored});
      renderNodePairing();
      setStatus('Node paired read-only. No items, addresses, writes, or automatic synchronization were granted.', 'success');
      requestAnimationFrame(() => els.nodePairedHeading.focus());
    } catch (error) {
      setStatus(error.message || 'ProgRSS could not pair that Node.', 'error');
    } finally {
      busy('node-pairing', false);
    }
  }

  async function cancelNodeReview() {
    const review = app.nodeReview;
    app.nodeReview = null;
    els.nodeInvitation.value = '';
    await releaseNodeHostPermission(Boolean(review?.hostPermissionAdded));
    renderNodePairing();
    els.nodeInvitation.focus();
    setStatus('Pairing review cancelled. The invitation was not used, and newly granted Node access was released.', 'decision');
  }

  function validStoredNodePairing(value) {
    try {
      if (!value || value.schema !== NODE_PAIRING_STORAGE_SCHEMA || !/^[A-Za-z0-9_-]{40,80}$/.test(text(value.token))) return null;
      const origin = new URL(value.origin);
      if (origin.protocol !== 'http:' || origin.hostname !== '127.0.0.1' || !origin.port || origin.origin !== value.origin) return null;
      validateNodePairingDocument(value.document, {origin: value.origin, state: 'paired'});
      if (value.hostPermissionAdded !== undefined && typeof value.hostPermissionAdded !== 'boolean') return null;
      return value;
    } catch { return null; }
  }

  async function checkNodePairing() {
    const pairing = app.nodePairing;
    if (!pairing) return;
    busy('node-pairing', true);
    try {
      const document = validateNodePairingDocument(
        await nodeFetch(pairing.origin, '/api/v1/pairing', pairing.token),
        {origin: pairing.origin, state: 'paired', fingerprint: pairing.document.node.instanceFingerprint},
      );
      const libraryChanged = document.library.sha256 !== document.pairing.reviewedLibrarySha256;
      app.nodePairing = {...pairing, document, checkedAt: new Date().toISOString()};
      await api.storage.local.set({nodePairing: app.nodePairing});
      renderNodePairing();
      setStatus(
        libraryChanged
          ? 'The Node session matches, but its selected library file changed since pairing. Review the updated counts; nothing was synchronized.'
          : 'Node session fingerprint and library summary checked. Nothing was synchronized.',
        libraryChanged ? 'decision' : 'success',
      );
    } catch (error) {
      setStatus(`${error.message || 'The Node could not be checked.'} You can start it again and create a new invitation, or forget this local pairing.`, 'error');
    } finally {
      busy('node-pairing', false);
    }
  }

  async function clearStoredNodePairing() {
    app.nodePairing = null;
    app.nodeReview = null;
    try { await api.storage.local.remove('nodePairing'); }
    catch { await api.storage.local.set({nodePairing: null}); }
    renderNodePairing();
  }

  async function unpairNode() {
    const pairing = app.nodePairing;
    if (!pairing) return;
    if (!globalThis.confirm('Unpair this Extension from the running Node? The Node library will not be changed.')) return;
    busy('node-pairing', true);
    try {
      await nodeFetch(pairing.origin, '/api/v1/pairing/revoke', pairing.token, {method: 'POST', body: '{}'});
      const permissionReleased = await releaseNodeHostPermission(Boolean(pairing.hostPermissionAdded));
      await clearStoredNodePairing();
      setStatus(`Node pairing revoked on both sides. The library was not changed.${permissionReleased ? ' Newly granted loopback access was released.' : ''}`, 'success');
      els.nodeInvitation.focus();
    } catch (error) {
      setStatus(`${error.message || 'The Node could not revoke this pairing.'} Use “Forget this pairing locally” only when you understand the Node may keep a stale grant until it stops.`, 'error');
    } finally {
      busy('node-pairing', false);
    }
  }

  async function forgetNodePairing() {
    if (!app.nodePairing) return;
    if (!globalThis.confirm('Forget this pairing only in the Extension? If the Node is still running, revoke it there too.')) return;
    const pairing = app.nodePairing;
    const permissionReleased = await releaseNodeHostPermission(Boolean(pairing?.hostPermissionAdded));
    await clearStoredNodePairing();
    setStatus(`Local pairing forgotten.${permissionReleased ? ' Newly granted loopback access was released.' : ''} A still-running Node may retain the stale grant until you revoke it there or stop the Node.`, 'decision');
    els.nodeInvitation.focus();
  }

  function keyboard(event) {
    if (event.defaultPrevented || event.altKey || event.ctrlKey || event.metaKey) return;
    const target = event.target;
    if (app.view === 'detail') {
      if (event.key === 'Escape') {
        event.preventDefault();
        closeItemDetail();
        return;
      }
      if (event.key === 'j' || event.key === 'k') {
        event.preventDefault();
        moveDetail(event.key === 'j' ? 1 : -1);
        return;
      }
      if (event.key === 'm' || event.key === 's') {
        event.preventDefault();
        const item = detailItem();
        if (!item) return;
        if (event.key === 'm') changeItem(item.id, {read: !item.readAt});
        else changeItem(item.id, {starred: !item.starred});
        return;
      }
    }
    if (event.key === 'Escape' && app.search) {
      event.preventDefault();
      setSearch('', {focus: target === els.readingSearch});
      return;
    }
    const typing = target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target?.isContentEditable;
    if (typing) return;
    const cards = $$('.item-card');
    const focused = document.activeElement?.closest?.('.item-card');
    let index = focused ? cards.indexOf(focused) : -1;
    if (event.key === 'j' || event.key === 'k') {
      if (!cards.length || app.view !== 'today') return;
      event.preventDefault();
      index = event.key === 'j' ? Math.min(cards.length - 1, index + 1) : Math.max(0, index < 0 ? 0 : index - 1);
      const focusable = cards[index].querySelector('a, button');
      focusable?.focus();
      cards[index].scrollIntoView({block: 'nearest'});
    } else if ((event.key === 'm' || event.key === 's') && focused) {
      event.preventDefault();
      const id = focused.dataset.itemId;
      const item = app.state.items.find(row => row.id === id);
      if (!item) return;
      if (event.key === 'm') changeItem(id, {read: !item.readAt});
      else changeItem(id, {starred: !item.starred});
    } else if (event.key === 'r') {
      event.preventDefault();
      refreshAll();
    } else if (event.key === 'a') {
      event.preventDefault();
      setView('add', {focus: true});
    } else if (event.key === '/') {
      event.preventDefault();
      setView('today');
      els.readingSearch.focus();
    }
  }

  function bind() {
    $$('[data-view]').forEach(button => button.addEventListener('click', () => setView(button.dataset.view, {focus: true})));
    $$('[data-go]').forEach(button => button.addEventListener('click', () => setView(button.dataset.go, {focus: true})));
    $$('[data-filter]').forEach(button => button.addEventListener('click', () => setFilter(button.dataset.filter)));
    els.refreshAll.addEventListener('click', refreshAll);
    els.themeToggle.addEventListener('click', toggleTheme);
    els.markAll.addEventListener('click', markAllRead);
    els.showFollowedSource.addEventListener('click', showFollowedSource);
    els.dismissFollowHandoff.addEventListener('click', () => { app.followHandoff = null; renderFollowHandoff(); });
    els.undo.addEventListener('click', undoMarkAll);
    els.undoFolderChange.addEventListener('click', undoFolderChange);
    els.undoSourceNote.addEventListener('click', undoSourceNoteChange);
    els.undoTextCleanup.addEventListener('click', undoSourceTextPrune);
    els.undoSourceRepair.addEventListener('click', undoSourceRepair);
    els.undoSharedFolderUpdate.addEventListener('click', undoSharedFolderUpdate);
    els.saveRecoveryCopy.addEventListener('click', saveRecoveryCopy);
    els.savePrivateCopy.addEventListener('click', savePrivateCopy);
    els.checkPrivateCopy.addEventListener('click', choosePrivateCopyForCheck);
    els.copyCheckFile.addEventListener('change', () => checkPrivateCopyFile(els.copyCheckFile.files?.[0]));
    els.snoozeBackupReminder.addEventListener('click', () => changeBackupReminder('snooze-backup-reminder'));
    els.disableBackupReminder.addEventListener('click', () => changeBackupReminder('disable-backup-reminder'));
    els.enableBackupReminder.addEventListener('click', () => changeBackupReminder('enable-backup-reminder'));
    els.markBackupCopyMissing.addEventListener('click', markBackupCopyMissing);
    els.checkStorage.addEventListener('click', checkStorage);
    els.restoreMissingLibrary.addEventListener('click', restoreMissingLibraryFile);
    els.acceptEmptyLibrary.addEventListener('click', acceptEmptyLibrary);
    els.readingSearch.addEventListener('input', () => setSearch(els.readingSearch.value));
    els.clearSearch.addEventListener('click', () => setSearch('', {focus: true}));
    els.useCurrent.addEventListener('click', startFromCurrentPage);
    els.focusAddress.addEventListener('click', focusAddressEntry);
    els.chooseOpml.addEventListener('click', chooseOpmlFile);
    els.focusNodePairing.addEventListener('click', focusNodePairing);
    els.reviewNode.addEventListener('click', reviewNodeInvitation);
    els.nodeInvitation.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); reviewNodeInvitation(); } });
    els.pairNode.addEventListener('click', pairReviewedNode);
    els.cancelNodeReview.addEventListener('click', cancelNodeReview);
    els.checkNode.addEventListener('click', checkNodePairing);
    els.unpairNode.addEventListener('click', unpairNode);
    els.forgetNode.addEventListener('click', forgetNodePairing);
    els.chooseSharedFolder.addEventListener('click', chooseSharedFolderFile);
    els.checkSharedFolderUpdate.addEventListener('click', event => checkSelectedSharedFolderUpdate(event.currentTarget));
    els.shareFolderButton.addEventListener('click', openShareFolder);
    els.shareCurator.addEventListener('input', () => { app.shareAttribution = {...app.shareAttribution, curator: els.shareCurator.value.slice(0, 80)}; });
    els.shareNote.addEventListener('input', () => { app.shareAttribution = {...app.shareAttribution, note: els.shareNote.value.slice(0, 280)}; });
    els.shareUpdateUrl.addEventListener('input', () => { app.shareAttribution = {...app.shareAttribution, updateUrl: els.shareUpdateUrl.value.slice(0, 2048)}; });
    els.siteIncludeUpdates.addEventListener('change', () => { app.shareAttribution = {...app.shareAttribution, includeUpdates: Boolean(els.siteIncludeUpdates.checked)}; renderShareFolder(); });
    els.shareSign.addEventListener('change', () => { app.shareAttribution = {...app.shareAttribution, sign: Boolean(els.shareSign.checked && app.shareIdentity?.keyId)}; renderShareFolder(); });
    els.createShareIdentity.addEventListener('click', createSharingIdentity);
    els.saveSharedFolder.addEventListener('click', () => saveCurrentFolder('bundle'));
    els.saveFolderOpml.addEventListener('click', () => saveCurrentFolder('opml'));
    els.savePublicationSite.addEventListener('click', () => saveCurrentFolder('site'));
    els.saveFolderEdition.addEventListener('click', () => saveCurrentFolder('edition'));
    els.closeShareFolder.addEventListener('click', () => {
      app.shareFolder = null; app.shareIdentity = null; app.shareAttribution = {curator: '', note: '', updateUrl: '', sign: false, includeUpdates: false};
      renderShareFolder(); els.shareFolderButton.focus();
    });
    els.form.addEventListener('submit', event => {
      event.preventDefault();
      inspectAddress(els.address.value.trim());
    });
    els.opmlFile.addEventListener('change', () => reviewOpmlFile(els.opmlFile.files?.[0]));
    els.sharedFolderFile.addEventListener('change', () => reviewSharedFolderFile(els.sharedFolderFile.files?.[0]));
    els.exportLibrary.addEventListener('click', exportLibrary);
    els.backupFile.addEventListener('change', () => reviewTransferFile(els.backupFile.files?.[0]));
    els.undoLibraryMove.addEventListener('click', undoLibraryMove);
    els.undoPageWatchRepair.addEventListener('click', undoPageWatchRepair);
    els.openWorkbench.addEventListener('click', () => api.runtime.openOptionsPage());
    els.detailBack.addEventListener('click', () => closeItemDetail());
    els.detailRead.addEventListener('click', () => { const item = detailItem(); if (item) changeItem(item.id, {read: !item.readAt}); });
    els.detailSave.addEventListener('click', () => { const item = detailItem(); if (item) changeItem(item.id, {starred: !item.starred}); });
    els.detailOpen.addEventListener('click', () => { const item = detailItem(); if (item && !item.readAt) changeItem(item.id, {read: true}, {quiet: true}); });
    els.detailNewer.addEventListener('click', () => moveDetail(-1));
    els.detailOlder.addEventListener('click', () => moveDetail(1));
    document.addEventListener('keydown', keyboard);
    api.runtime.onMessage.addListener(message => {
      if (message?.type === 'progrss:state-changed') loadState().catch(() => {});
    });
  }

  async function start() {
    applyTheme('dark');
    bind();
    try {
      const prefs = await api.storage.local.get(['primaryView', 'readingFilter', 'libraryFolder', 'appearanceTheme', 'nodePairing']);
      if (prefs.readingFilter) app.filter = prefs.readingFilter;
      if (prefs.primaryView) app.view = prefs.primaryView;
      if (prefs.libraryFolder) app.folder = prefs.libraryFolder;
      if (prefs.appearanceTheme) applyTheme(prefs.appearanceTheme);
      app.nodePairing = validStoredNodePairing(prefs.nodePairing);
    } catch {}
    renderNodePairing();
    setFilter(app.filter);
    setView(app.view);
    try {
      await loadState();
      if (app.state.vault?.warning && !app.state.storageIncident) setStatus(app.state.vault.warning, 'error');
    } catch (error) {
      els.itemList.setAttribute('aria-busy', 'false');
      setStatus(error.message, 'error');
      els.itemList.replaceChildren(emptyState('empty'));
    }
  }

  start();
})();
