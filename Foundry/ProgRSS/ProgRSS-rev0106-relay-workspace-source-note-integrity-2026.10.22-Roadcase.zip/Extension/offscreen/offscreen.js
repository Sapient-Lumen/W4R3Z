'use strict';

const api = globalThis.browser || globalThis.chrome;
const parser = globalThis.ProgRSSParser;

function respond(result) {
  return {ok: true, result};
}

api.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.target !== 'offscreen') return false;
  try {
    sendResponse(respond(parser.handle(message.type, message.data || {})));
  } catch (error) {
    sendResponse({ok: false, error: String(error?.message || error).slice(0, 500), code: String(error?.code || 'FAILED').slice(0, 80), detail: error?.detail && typeof error.detail === 'object' ? error.detail : null});
  }
  return false;
});
