"use strict";

export const SOURCE_NOTE_PLACEMENT_KEY = Object.freeze(["folderId", "sourceId"]);
export const MAX_SOURCE_NOTE_CODE_POINTS = 280;
const ASCII_EDGE_WHITESPACE = /^[ \t\r\n\f\v]+|[ \t\r\n\f\v]+$/g;

export function normalizeSourceNoteReason(value) {
  if (value === undefined || value === null) return undefined;
  if (typeof value !== "string") throw new TypeError("placement reason must be a string");
  const reason = value.replace(ASCII_EDGE_WHITESPACE, "");
  if (reason.length === 0) return undefined;
  for (let index = 0; index < reason.length; index += 1) {
    const unit = reason.charCodeAt(index);
    if (unit >= 0xd800 && unit <= 0xdbff) {
      const next = reason.charCodeAt(index + 1);
      if (!(next >= 0xdc00 && next <= 0xdfff)) throw new TypeError("invalid Unicode scalar value");
      index += 1;
    } else if (unit >= 0xdc00 && unit <= 0xdfff) {
      throw new TypeError("invalid Unicode scalar value");
    }
  }
  if (Array.from(reason).length > MAX_SOURCE_NOTE_CODE_POINTS) {
    throw new RangeError("placement reason exceeds 280 Unicode code points");
  }
  return reason;
}

export function preserveSourceNoteReason(sourceMember, projectedMember) {
  const out = { ...projectedMember };
  if (Object.prototype.hasOwnProperty.call(sourceMember, "reason")) {
    const reason = normalizeSourceNoteReason(sourceMember.reason);
    if (reason === undefined) delete out.reason;
    else out.reason = reason;
  }
  return out;
}

export function sourceNotePlacementKey(folderId, sourceId) {
  if (typeof folderId !== "string" || folderId.length === 0) throw new TypeError("folderId must be non-empty");
  if (typeof sourceId !== "string" || sourceId.length === 0) throw new TypeError("sourceId must be non-empty");
  return `${folderId}/${sourceId}`;
}
