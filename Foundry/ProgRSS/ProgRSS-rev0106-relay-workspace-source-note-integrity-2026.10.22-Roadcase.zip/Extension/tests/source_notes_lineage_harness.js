'use strict';
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const extensionRoot = path.resolve(__dirname, '..', process.env.PROGRSS_EXTENSION_ROOT || '.');
const requests = [];
globalThis.fetch = async (...args) => { requests.push(args); throw new Error('network forbidden in lineage harness'); };
for (const file of [
  path.join(extensionRoot, 'shared', 'core.js'),
  path.join(extensionRoot, 'workbench', 'scripts', 'progrss-courier.js'),
  path.join(extensionRoot, 'workbench', 'scripts', 'progrss-lineage.js'),
]) vm.runInThisContext(fs.readFileSync(file, 'utf8'), {filename:file});

const C = globalThis.ProgRSSCore;
const L = globalThis.ProgRSSLineage;
const deep = value => JSON.parse(JSON.stringify(value));
const member = (id, reason) => ({kind:'source', id, ...(reason === undefined ? {} : {reason})});
const source = (id='feed') => C.cleanRecipe({id, type:'rss', url:`https://${id}.test/feed.xml`, title:id.toUpperCase(), author:'Curator'});
const folder = (id, title, members) => C.cleanCollection({id, title, mode:'union', members, author:'Curator'});
const blankSubscriber = () => ({sources:[], collections:[], subscriptions:[], publications:[], snapshots:{}});
function localCollection(state, remoteId) {
  const sub = state.subscriptions[0];
  return state.collections.find(row => row.id === sub.mapping[remoteId]);
}
function localMember(state, remoteFolder, remoteSource='feed') {
  const sub = state.subscriptions[0];
  const row = localCollection(state, remoteFolder);
  return row.members.find(item => item.kind === 'source' && item.id === sub.mapping[remoteSource]);
}
function reasonOf(row) { return Object.prototype.hasOwnProperty.call(row, 'reason') ? row.reason : null; }
function makePublisher(rootReason='Root reason.', childReason='Child reason.') {
  return {
    sources:[source('feed')],
    collections:[
      folder('root', 'Root', [member('feed', rootReason), {kind:'collection', id:'child'}]),
      folder('child', 'Child', [member('feed', childReason)]),
    ],
    publications:[],
  };
}
function publish(state, note) { return L.publish(state, 'root', note); }
function expectThrows(fn, pattern) {
  let error = null;
  try { fn(); } catch (caught) { error = caught; }
  assert(error, 'expected operation to throw');
  if (pattern) assert(pattern.test(String(error.message)), String(error.message));
}

const passed = [];

// Initial follow: the frozen rev0096 parent published both reasons but dropped them during ID remapping.
{
  const publisher = makePublisher();
  const edition = publish(publisher, 'Initial reasons');
  assert.strictEqual(edition.bundle.collections[0].members[0].reason, 'Root reason.');
  const subscriber = blankSubscriber();
  const plan = L.review(subscriber, edition);
  assert.strictEqual(reasonOf(plan.collections.find(row => row.id === plan.record.localRoot).members[0]), 'Root reason.');
  const report = L.apply(subscriber, edition);
  assert.strictEqual(report.sourceNoteDecisions, 0);
  assert.strictEqual(reasonOf(localMember(subscriber, 'root')), 'Root reason.');
  assert.strictEqual(reasonOf(localMember(subscriber, 'child')), 'Child reason.');
  passed.push('initial follow preserves independent direct-placement reasons');
}

// Curator-only, recipient-only, and identical changes follow the three-way rule.
{
  const publisher = makePublisher('Base reason.', 'Child base.');
  const subscriber = blankSubscriber();
  L.apply(subscriber, publish(publisher, 'Initial'));

  publisher.collections[0].members[0].reason = 'Curator only.';
  L.apply(subscriber, publish(publisher, 'Curator-only reason'));
  assert.strictEqual(reasonOf(localMember(subscriber, 'root')), 'Curator only.');
  assert.strictEqual(reasonOf(localMember(subscriber, 'child')), 'Child base.');

  localMember(subscriber, 'root').reason = 'Recipient only.';
  publisher.collections[0].title = 'Root renamed';
  L.apply(subscriber, publish(publisher, 'Title only upstream'));
  assert.strictEqual(reasonOf(localMember(subscriber, 'root')), 'Recipient only.');
  assert.strictEqual(localCollection(subscriber, 'root').title, 'Root renamed');

  localMember(subscriber, 'root').reason = 'Same next wording.';
  publisher.collections[0].members[0].reason = 'Same next wording.';
  publisher.collections[0].title = 'Root renamed again';
  const plan = L.review(subscriber, publish(publisher, 'Same reason on both sides'));
  assert.strictEqual(plan.sourceNoteConflicts.length, 0);
  L.apply(subscriber, plan.edition);
  assert.strictEqual(reasonOf(localMember(subscriber, 'root')), 'Same next wording.');
  passed.push('one-sided and identical later changes merge without a false conflict');
}

// A structural upstream removal is not interpreted as deleting the reason on
// the locally preserved placement when both member graphs changed.
{
  const publisher = makePublisher('Keep with local structure.', 'Child.');
  const subscriber = blankSubscriber();
  L.apply(subscriber, publish(publisher, 'Initial'));
  const localExtra = source('local-extra');
  subscriber.sources.push(localExtra);
  localCollection(subscriber, 'root').members.push(member(localExtra.id, 'Local-only placement.'));
  publisher.collections[0].members = publisher.collections[0].members.filter(row => !(row.kind === 'source' && row.id === 'feed'));
  const edition = publish(publisher, 'Upstream removed root placement');
  const preview = L.review(subscriber, edition);
  assert.strictEqual(preview.conflicts.some(row => row.field === 'members'), true);
  assert.strictEqual(preview.sourceNoteConflicts.length, 0);
  L.apply(subscriber, edition);
  assert.strictEqual(reasonOf(localMember(subscriber, 'root')), 'Keep with local structure.');
  assert.strictEqual(reasonOf(localCollection(subscriber, 'root').members.find(row => row.id === localExtra.id)), 'Local-only placement.');
  passed.push('structurally retained local placements keep their reasons when upstream removes them');
}

// Divergent edits never receive an automatic winner; both explicit decisions are exercised.
{
  const publisher = makePublisher('Old reason.', 'Child.');
  const subscriber = blankSubscriber();
  L.apply(subscriber, publish(publisher, 'Initial'));
  localMember(subscriber, 'root').reason = 'Mine divergent.';
  publisher.collections[0].members[0].reason = 'Curator divergent.';
  const edition = publish(publisher, 'Divergent reason');
  const before = deep(subscriber);
  const preview = L.review(subscriber, edition);
  assert.strictEqual(preview.sourceNoteConflicts.length, 1);
  assert.strictEqual(preview.unresolvedSourceNoteConflicts.length, 1);
  assert.strictEqual(preview.sourceNoteConflicts[0].mine, 'Mine divergent.');
  assert.strictEqual(preview.sourceNoteConflicts[0].curator, 'Curator divergent.');
  assert.deepStrictEqual(subscriber, before, 'review must be read-only');
  expectThrows(() => L.apply(subscriber, edition), /Choose Keep mine or Use curator/);
  assert.deepStrictEqual(subscriber, before, 'unresolved apply must not mutate');
  const id = preview.sourceNoteConflicts[0].id;
  expectThrows(() => L.review(subscriber, edition, {[id]:'automatic'}), /must be Keep mine or Use curator/);
  expectThrows(() => L.review(subscriber, edition, {'source-note:unknown:unknown':'keep_mine'}), /stale or does not match/);

  const keep = deep(subscriber);
  const keepReport = L.apply(keep, edition, {[id]:'keep_mine'});
  assert.strictEqual(keepReport.sourceNoteDecisions, 1);
  assert.strictEqual(reasonOf(localMember(keep, 'root')), 'Mine divergent.');

  const use = deep(subscriber);
  const useReport = L.apply(use, edition, {[id]:'use_curator'});
  assert.strictEqual(useReport.sourceNoteDecisions, 1);
  assert.strictEqual(reasonOf(localMember(use, 'root')), 'Curator divergent.');
  passed.push('divergent reason requires and obeys Keep mine / Use curator’s');
}

// Deletion versus edit, including a missing value, is also an explicit conflict.
{
  const publisher = makePublisher('Old reason.', 'Child.');
  const subscriber = blankSubscriber();
  L.apply(subscriber, publish(publisher, 'Initial'));
  delete localMember(subscriber, 'root').reason;
  publisher.collections[0].members[0].reason = 'Curator edited.';
  const edition = publish(publisher, 'Deletion versus edit');
  const preview = L.review(subscriber, edition);
  assert.strictEqual(preview.sourceNoteConflicts.length, 1);
  assert.strictEqual(preview.sourceNoteConflicts[0].mine, null);
  assert.strictEqual(preview.sourceNoteConflicts[0].curator, 'Curator edited.');
  const id = preview.sourceNoteConflicts[0].id;
  const mine = deep(subscriber); L.apply(mine, edition, {[id]:'keep_mine'});
  assert.strictEqual(reasonOf(localMember(mine, 'root')), null);
  const curator = deep(subscriber); L.apply(curator, edition, {[id]:'use_curator'});
  assert.strictEqual(reasonOf(localMember(curator, 'root')), 'Curator edited.');
  passed.push('reason deletion versus edit remains unresolved until explicit choice');
}

// The opposite deletion-versus-edit direction also needs a decision, and
// choosing the curator's deletion removes the field rather than retaining mine.
{
  const publisher = makePublisher('Old reason.', 'Child.');
  const subscriber = blankSubscriber();
  L.apply(subscriber, publish(publisher, 'Initial'));
  localMember(subscriber, 'root').reason = 'Recipient edited.';
  delete publisher.collections[0].members[0].reason;
  const edition = publish(publisher, 'Edit versus deletion');
  const preview = L.review(subscriber, edition);
  assert.strictEqual(preview.sourceNoteConflicts.length, 1);
  assert.strictEqual(preview.sourceNoteConflicts[0].mine, 'Recipient edited.');
  assert.strictEqual(preview.sourceNoteConflicts[0].curator, null);
  const id = preview.sourceNoteConflicts[0].id;
  const mine = deep(subscriber); L.apply(mine, edition, {[id]:'keep_mine'});
  assert.strictEqual(reasonOf(localMember(mine, 'root')), 'Recipient edited.');
  const curator = deep(subscriber); L.apply(curator, edition, {[id]:'use_curator'});
  assert.strictEqual(reasonOf(localMember(curator, 'root')), null);
  passed.push('edit versus curator deletion requires a choice and can remove the reason');
}

// Different additions from an absent base conflict independently by placement.
{
  const publisher = makePublisher(null, 'Child.');
  const subscriber = blankSubscriber();
  L.apply(subscriber, publish(publisher, 'No root reason'));
  localMember(subscriber, 'root').reason = 'Mine added.';
  publisher.collections[0].members[0].reason = 'Curator added.';
  const edition = publish(publisher, 'Both added a reason');
  const preview = L.review(subscriber, edition);
  assert.strictEqual(preview.sourceNoteConflicts.length, 1);
  assert.strictEqual(preview.sourceNoteConflicts[0].base, null);
  passed.push('different reason additions conflict from an absent base');
}

// Stale decisions are refused after the live copy changes enough to remove the divergence.
{
  const publisher = makePublisher('Old.', 'Child.');
  const subscriber = blankSubscriber();
  L.apply(subscriber, publish(publisher, 'Initial'));
  localMember(subscriber, 'root').reason = 'Mine.';
  publisher.collections[0].members[0].reason = 'Curator.';
  const edition = publish(publisher, 'Conflict');
  const preview = L.review(subscriber, edition);
  const id = preview.sourceNoteConflicts[0].id;
  localMember(subscriber, 'root').reason = 'Curator.';
  expectThrows(() => L.review(subscriber, edition, {[id]:'keep_mine'}), /stale or does not match/);
  passed.push('stale Source Note decisions are rejected against live state');
}

// Reason-only publication changes the edition fingerprint and remains canonical.
{
  const publisher = makePublisher('First.', 'Child.');
  const first = publish(publisher, 'Initial');
  publisher.collections[0].members[0].reason = 'Second.';
  const second = publish(publisher, 'Reason-only change');
  assert.notStrictEqual(first.digest, second.digest);
  assert.strictEqual(second.bundle.collections[0].members[0].reason, 'Second.');
  passed.push('reason-only publication changes immutable edition content');
}

// Malformed and wrong-level data are refused by the canonical native bundle path.
{
  expectThrows(() => C.cleanCollection({id:'bad',members:[{kind:'source',id:'feed',reason:'x'.repeat(281)}]}), /280 Unicode code points/);
  expectThrows(() => C.cleanCollection({id:'bad',members:[{kind:'collection',id:'child',reason:'wrong'}]}), /Only a direct source placement/);
  passed.push('invalid or wrong-level reasons cannot enter an edition');
}

assert.strictEqual(requests.length, 0, 'lineage preservation must not add network activity');
passed.push('focused lineage path performs no network request');
console.log(JSON.stringify({variant:extensionRoot, count:passed.length, passed}, null, 2));
console.log(`PASS Source Notes Lineage preservation: ${passed.length} cases`);
