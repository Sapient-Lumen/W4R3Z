#!/usr/bin/env python3
"""Managed shipped-side-panel replay for shared-folder Source Note conflicts.

This harness loads the shipped side-panel HTML/CSS/JavaScript, substitutes only
browser APIs with the established deterministic smoke backend, and presents two
placement-scoped conflicts for the same source in identically titled folders.
It is managed UI regression evidence, not installed-browser or participant
acceptance.
"""
from __future__ import annotations

import argparse
import asyncio
import importlib.util
import os
from pathlib import Path
import shutil
import tempfile
from typing import Any

from playwright.async_api import async_playwright

TESTS = Path(__file__).resolve().parent
BASE_EXTENSION = TESTS.parent
spec = importlib.util.spec_from_file_location("progrss_browser_smoke", TESTS / "browser_smoke.py")
if spec is None or spec.loader is None:
    raise RuntimeError("Could not load browser smoke support")
smoke = importlib.util.module_from_spec(spec)
spec.loader.exec_module(smoke)


INTERCEPT = r"""
(() => {
  const original = chrome.runtime.sendMessage.bind(chrome.runtime);
  let imported = false;
  const conflictIds = [
    'placement:remote-north-updates:source:remote-feed-two:reason',
    'placement:remote-south-updates:source:remote-feed-two:reason'
  ];
  const preview = {
    schema: 'progrss.shared-folder-update.preview.v2',
    mode: 'update',
    title: 'Civic route',
    localTitle: 'Civic route',
    targetRootId: 'folder-practical',
    publicationId: 'smoke-publication',
    feedCount: 1,
    pageWatchCount: 0,
    folders: 5,
    curator: 'Neighborhood readers',
    note: 'Two independently routed update folders.',
    signatureState: 'verified',
    algorithm: 'Ed25519',
    keyId: `ed25519:${'1'.repeat(64)}`,
    fingerprint: 'ed25519:111111111111…11111111',
    previous: {
      signatureState: 'verified', algorithm: 'Ed25519',
      keyId: `ed25519:${'1'.repeat(64)}`,
      fingerprint: 'ed25519:111111111111…11111111'
    },
    trust: {state: 'same-key', requiresAcknowledgement: false, message: 'The same signing key signed this copy.'},
    requiresTrustAcknowledgement: false,
    requiresConflictChoices: true,
    requiresRecipeAcknowledgement: false,
    mergeReview: {
      schema: 'progrss.shared-folder-merge-review.v1',
      counts: {curatorOnly: 0, recipientOnly: 0, agreed: 0, conflicts: 2, additions: 0, removals: 0, recipeChanges: 0},
      curatorOnly: [], recipientOnly: [], agreed: [], additions: [], removals: [], recipeChanges: [],
      conflicts: [
        {
          id: conflictIds[0], kind: 'source-note', label: 'Workshop log',
          folderLabel: 'Updates', folderPath: 'Civic route › North › Updates',
          field: 'reason', fieldLabel: 'Reason for this source in this folder',
          baseline: 'Earlier north reason.\nSecond north line.',
          local: 'Keep north context.\n<literal & local>',
          incoming: 'سبب شمالي من المنسّق.\nCurator north line.',
          default: 'decision-required',
          summary: 'You and the curator changed this placement reason differently.',
          choices: ['keep-local', 'use-curator'],
          placement: {folderId: 'remote-north-updates', sourceId: 'remote-feed-two'}
        },
        {
          id: conflictIds[1], kind: 'source-note', label: 'Workshop log',
          folderLabel: 'Updates', folderPath: 'Civic route › South › Updates',
          field: 'reason', fieldLabel: 'Reason for this source in this folder',
          baseline: 'Earlier south reason.',
          local: 'Keep south context.',
          incoming: 'Curator south context.\n<label stays literal>',
          default: 'decision-required',
          summary: 'You and the curator changed this placement reason differently.',
          choices: ['keep-local', 'use-curator'],
          placement: {folderId: 'remote-south-updates', sourceId: 'remote-feed-two'}
        }
      ],
      omitted: {}, requiresDecisions: true, decisionIds: conflictIds,
      recipeAcknowledgementRequired: false, network: false, writes: false
    },
    changes: {sourcesAdded: 0, sourcesRemoved: 0, sourceRecipesChanged: 0, sourceMetadataChanged: 0, foldersAdded: 0, foldersRemoved: 0, foldersChanged: 2},
    localEdits: {sourceOverrides: 0, folderOverrides: 2, detachedFolders: 0, present: true},
    preservation: {readingHistory: true, readAndSavedState: true, sourceActivity: true, changedRecipesStartPaused: 0, localEditsKept: true},
    warnings: [], canUpdate: true, reason: '', reviewedRevision: 74,
    network: false, writes: false,
    separate: {canImport: true, newSources: 0, reusedSources: 1, folders: 5, startsPaused: true},
    contents: {schema: 'progrss.shared-folder.contents.v2', title: 'Civic route', root: 'remote-root', sourceCount: 1, sourceNoteCount: 2, feedCount: 1, pageWatchCount: 0, folderCount: 5, maxDepth: 2, folders: [], sources: [], network: false, writes: false}
  };
  chrome.runtime.sendMessage = async message => {
    if (message?.type === 'import-shared-folder') {
      const result = await original(message);
      if (result?.ok) imported = true;
      return result;
    }
    if (imported && message?.type === 'preview-shared-folder') {
      return {ok: true, result: structuredClone(preview)};
    }
    if (imported && message?.type === 'update-shared-folder') {
      for (const id of conflictIds) {
        if (!['keep-local', 'use-curator'].includes(message?.data?.conflictChoices?.[id])) {
          return {ok: false, code: 'SHARED_FOLDER_CONFLICT_DECISION', error: 'Choose how to resolve each wording conflict.'};
        }
      }
      return {ok: true, result: {...structuredClone(preview), updated: true, conflictChoices: structuredClone(message.data.conflictChoices), undoAvailable: false}};
    }
    return original(message);
  };
})();
"""


async def run_variant(browser: Any, root: Path, artifacts: Path) -> list[str]:
    page = await browser.new_page(viewport={"width": 390, "height": 844}, device_scale_factor=1)
    errors: list[str] = []
    page.on("console", lambda msg: errors.append(f"console:{msg.type}:{msg.text}") if msg.type == "error" else None)
    page.on("pageerror", lambda error: errors.append(f"page:{error}"))
    html_text, _ = smoke.html_without_external_scripts(root / "sidepanel" / "index.html", embed_images=True)
    await page.set_content(html_text, wait_until="domcontentloaded")
    await page.add_style_tag(content=(root / "sidepanel" / "app.css").read_text())
    await page.add_script_tag(content=(root / "shared" / "core.js").read_text())
    await page.add_script_tag(content=smoke.MOCK)
    await page.add_script_tag(content=INTERCEPT)
    await page.add_script_tag(content=(root / "shared" / "publication-site.js").read_text())
    await page.add_script_tag(content=(root / "sidepanel" / "app.js").read_text())
    await page.wait_for_function("document.querySelector('#today-summary').textContent.includes('1 unread')")

    await page.locator("#tab-add").click()
    await page.locator("#shared-folder-file").set_input_files(str(root / "fixtures" / "shared-folder" / "ed25519.json"))
    await page.wait_for_function("document.querySelector('#shared-folder-preview').textContent.includes('Signature verified')")
    await page.locator("#shared-folder-preview button", has_text="Add source list").click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('signature verified')")

    await page.locator("#tab-add").click()
    await page.locator("#shared-folder-file").set_input_files(str(root / "fixtures" / "shared-folder" / "p256.json"))
    await page.wait_for_function("document.querySelector('#shared-folder-preview').textContent.includes('Three-way review')")
    cards = page.locator(".merge-conflict-card")
    assert await cards.count() == 2
    text = await page.locator(".shared-folder-merge-review").inner_text()
    assert "Civic route › North › Updates" in text
    assert "Civic route › South › Updates" in text
    assert text.count("Workshop log") >= 2
    assert "Curator’s reason for this folder" in text
    assert "not a ProgRSS safety claim" in text
    assert "<literal & local>" in text and "<label stays literal>" in text

    values = page.locator(".merge-source-note-value")
    assert await values.count() >= 6
    assert all(value == "auto" for value in await values.evaluate_all("nodes => nodes.map(node => node.getAttribute('dir'))"))
    assert all("pre-wrap" in value for value in await values.evaluate_all("nodes => nodes.map(node => getComputedStyle(node).whiteSpace)"))
    assert "\n" in await values.nth(0).text_content()

    await cards.nth(0).locator('input[value="keep-local"]').check()
    await cards.nth(1).locator('input[value="use-curator"]').check()
    assert not await page.locator("#shared-folder-preview button", has_text="Apply reviewed choices").is_disabled()
    artifacts.mkdir(parents=True, exist_ok=True)
    await page.screenshot(path=str(artifacts / f"{root.name}-shared-folder-source-note-review.png"), full_page=True)
    assert not errors, errors
    await page.close()
    return [
        "two same-source conflicts expose distinct full folder routes",
        "last accepted, local, and curator values remain literal multiline direction-aware text",
        "curator attribution and the non-safety boundary are visible",
        "each placement retains an independent explicit conflict choice",
    ]


async def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--extension", type=Path, default=BASE_EXTENSION)
    parser.add_argument("--artifacts", type=Path, default=Path(os.environ.get("PROGRSS_TEST_ARTIFACTS", tempfile.gettempdir())) / "progrss-shared-folder-source-notes")
    args = parser.parse_args()
    root = args.extension.resolve()
    async with async_playwright() as p:
        executable = os.environ.get("PROGRSS_CHROMIUM") or shutil.which("chromium") or shutil.which("chromium-browser") or shutil.which("google-chrome")
        launch: dict[str, Any] = {"headless": True, "args": ["--no-sandbox"]}
        if executable:
            launch["executable_path"] = executable
        browser = await p.chromium.launch(**launch)
        try:
            passed = await run_variant(browser, root, args.artifacts.resolve())
        finally:
            await browser.close()
    print(f"PASS shared-folder Source Note merge review ({root.name}): {len(passed)} checks")
    for row in passed:
        print(f"- {row}")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
