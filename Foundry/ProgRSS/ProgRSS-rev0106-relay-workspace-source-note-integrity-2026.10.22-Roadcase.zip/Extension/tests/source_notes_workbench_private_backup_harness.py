#!/usr/bin/env python3
"""Managed shipped-Workbench replay for private-backup Source Note integrity.

The harness loads the real Workbench HTML and scripts, substitutes only a
bounded in-page vault, and drives the shipped Private backup control. It is
managed regression evidence, not installed-browser or participant evidence.
"""
from __future__ import annotations

import argparse
import asyncio
import importlib.util
import json
import os
from pathlib import Path
import shutil
import tempfile
from typing import Any

from bs4 import BeautifulSoup
from playwright.async_api import async_playwright, Page

TESTS = Path(__file__).resolve().parent
BASE_EXTENSION = TESTS.parent

collection_spec = importlib.util.spec_from_file_location(
    "progrss_workbench_collection_harness", TESTS / "source_notes_workbench_collection_harness.py"
)
if collection_spec is None or collection_spec.loader is None:
    raise RuntimeError("Could not load Workbench harness support")
collection_support = importlib.util.module_from_spec(collection_spec)
collection_spec.loader.exec_module(collection_support)

smoke_spec = importlib.util.spec_from_file_location("progrss_browser_smoke", TESTS / "browser_smoke.py")
if smoke_spec is None or smoke_spec.loader is None:
    raise RuntimeError("Could not load browser smoke support")
smoke = importlib.util.module_from_spec(smoke_spec)
smoke_spec.loader.exec_module(smoke)


def html_without_scripts(path: Path) -> tuple[str, list[Path]]:
    soup = BeautifulSoup(path.read_text(encoding="utf-8"), "html.parser")
    scripts: list[Path] = []
    for tag in list(soup.find_all("script", src=True)):
        scripts.append((path.parent / tag["src"]).resolve())
        tag.decompose()
    return str(soup), scripts


def base_state() -> dict[str, Any]:
    state = collection_support.blank_state()
    root = next(row for row in state["collections"] if row["id"] == "folder-reading")
    child = next(row for row in state["collections"] if row["id"] == "folder-child")
    root["members"] = [
        {"kind": "source", "id": "feed-one", "reason": "Root reason.\nSecond line 🌱"},
        {"kind": "source", "id": "feed-two"},
        {"kind": "collection", "id": "folder-child"},
    ]
    child["members"] = [
        {"kind": "source", "id": "feed-one", "reason": "سبب المسار الفرعي."}
    ]
    return state


async def load_workbench(browser, root: Path, seed: dict[str, Any]) -> tuple[Page, list[str]]:
    page = await browser.new_page(viewport={"width": 920, "height": 900}, device_scale_factor=1)
    errors: list[str] = []
    page.on("console", lambda msg: errors.append(f"console:{msg.type}:{msg.text}") if msg.type == "error" else None)
    page.on("pageerror", lambda error: errors.append(f"page:{error}"))
    html, scripts = html_without_scripts(root / "workbench" / "index.html")
    await page.set_content(html, wait_until="domcontentloaded")
    await page.add_script_tag(content=smoke.MOCK)
    for script in scripts:
        if script.name == "vault.js":
            fake = f"""(() => {{
              let stored={json.dumps(seed, ensure_ascii=True)};
              globalThis.__workbenchSavedState=null;
              globalThis.__workbenchSaveCalls=0;
              globalThis.__workbenchCurrentState=()=>structuredClone(stored);
              globalThis.ProgRSSVault=Object.freeze({{
                init:async()=>structuredClone(stored),
                save:async state=>{{
                  state._revision=(Number(state._revision)||0)+1;
                  stored=structuredClone(state);
                  globalThis.__workbenchSavedState=structuredClone(state);
                  globalThis.__workbenchSaveCalls+=1;
                }},
                probe:async()=>true,
                info:()=>({{mode:'indexeddb',warning:''}}),
                normalize:value=>structuredClone(value)
              }});
            }})();"""
            await page.add_script_tag(content=fake)
        else:
            await page.add_script_tag(content=script.read_text(encoding="utf-8"))
    await page.wait_for_function("!document.querySelector('#shell').inert")
    return page, errors


async def click_backup(page: Page) -> None:
    await page.evaluate("document.getElementById('docs-backup').click()")


async def assert_refused(browser, root: Path, seed: dict[str, Any], expected: str, label: str) -> str:
    page, errors = await load_workbench(browser, root, seed)
    downloads: list[Any] = []
    page.on("download", lambda download: downloads.append(download))
    try:
        await click_backup(page)
        await page.wait_for_function("!document.querySelector('#toast').hidden")
        await page.wait_for_timeout(250)
        toast = await page.locator("#toast").inner_text()
        assert expected in toast, (label, toast)
        assert "Private backup not created" in toast, (label, toast)
        assert not downloads, f"{label}: invalid state still downloaded a private backup"
        assert await page.evaluate("globalThis.__workbenchSaveCalls") == 0
        assert not await page.evaluate("globalThis.__nodeFetchRequests.length")
        assert not errors, errors
        return toast
    finally:
        await page.close()


async def run_variant(browser, root: Path, artifacts: Path) -> dict[str, Any]:
    passed: list[str] = []

    # Valid route-specific reasons remain exact in the downloaded private file.
    state = base_state()
    page, errors = await load_workbench(browser, root, state)
    try:
        async with page.expect_download(timeout=10_000) as pending:
            await click_backup(page)
        download = await pending.value
        destination = artifacts / f"{root.name}-workbench-private-backup.json"
        await download.save_as(str(destination))
        document = json.loads(destination.read_text(encoding="utf-8"))
        assert document["schema"] == "progrss.private.v1"
        folders = {row["id"]: row for row in document["state"]["collections"]}
        root_members = folders["folder-reading"]["members"]
        child_members = folders["folder-child"]["members"]
        assert root_members[0]["reason"] == "Root reason.\nSecond line 🌱"
        assert "reason" not in root_members[1]
        assert child_members == [{"kind": "source", "id": "feed-one", "reason": "سبب المسار الفرعي."}]
        toast = await page.locator("#toast").inner_text()
        assert "2 curator-written folder reasons" in toast, toast
        assert await page.evaluate("globalThis.__workbenchSaveCalls") == 0
        assert not await page.evaluate("globalThis.__nodeFetchRequests.length")
        assert not errors, errors
        await page.screenshot(path=str(artifacts / f"{root.name}-workbench-private-backup.png"), full_page=True)
        passed.append("valid private backup preserves two route-specific reasons and one explicit absence")
    finally:
        await page.close()

    invalid: list[tuple[str, Any, str]] = []

    seed = base_state(); seed["collections"][0]["members"][0]["reason"] = "x" * 281
    invalid.append(("over-limit reason", seed, "280 Unicode code points"))

    seed = base_state(); seed["collections"][0]["reason"] = "Wrong level."
    invalid.append(("folder-level reason", seed, "on the folder"))

    seed = base_state(); seed["collections"][0]["members"][-1]["reason"] = "Wrong level."
    invalid.append(("nested-folder-member reason", seed, "something other than a direct source placement"))

    seed = base_state(); seed["collections"][0]["members"].insert(1, {"kind": "source", "id": "feed-one", "reason": "Duplicate."})
    invalid.append(("reason-bearing duplicate", seed, "must appear exactly once"))

    seed = base_state(); seed["collections"][0]["members"][0]["reason"] = " \t\r\n "
    invalid.append(("empty reason", seed, "empty Source Note"))

    seed = base_state(); seed["collections"][0]["members"][0]["reason"] = "  edge wording"
    invalid.append(("edge-whitespace reason", seed, "noncanonical Source Note"))

    seed = base_state(); seed["collections"][0]["members"][0]["reason"] = 7
    invalid.append(("non-string reason", seed, "must be a string"))

    seed = base_state(); seed["collections"][0]["members"][0]["reason"] = "\ud800"
    invalid.append(("invalid Unicode scalar", seed, "invalid Unicode scalar value"))

    seed = base_state(); seed["collections"][0]["members"][0] = {"kind": "source", "id": "missing", "reason": "Missing source reason."}
    invalid.append(("missing-source reason", seed, "gives missing source"))

    for label, seed, expected in invalid:
        await assert_refused(browser, root, seed, expected, label)
        passed.append(f"{label} refuses without download, write, or network")

    return {"variant": str(root), "passed": passed, "count": len(passed)}


async def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(os.environ.get("PROGRSS_EXTENSION_ROOT", BASE_EXTENSION)))
    parser.add_argument("--artifacts", type=Path, default=Path(os.environ.get("PROGRSS_TEST_ARTIFACTS", tempfile.gettempdir())) / "progrss-workbench-private-backup")
    args = parser.parse_args()
    root = args.root.resolve(); args.artifacts.mkdir(parents=True, exist_ok=True)
    if not (root / "workbench" / "scripts" / "progrss-app.js").is_file():
        raise SystemExit(f"Missing Workbench under {root}")
    async with async_playwright() as p:
        executable = os.environ.get("PROGRSS_CHROMIUM") or shutil.which("chromium") or shutil.which("chromium-browser") or shutil.which("google-chrome")
        launch: dict[str, Any] = {"headless": True, "args": ["--no-sandbox"]}
        if executable:
            launch["executable_path"] = executable
        browser = await p.chromium.launch(**launch)
        try:
            result = await run_variant(browser, root, args.artifacts)
        finally:
            await browser.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print(f"PASS Workbench private-backup Source Note integrity: {result['count']} cases")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
