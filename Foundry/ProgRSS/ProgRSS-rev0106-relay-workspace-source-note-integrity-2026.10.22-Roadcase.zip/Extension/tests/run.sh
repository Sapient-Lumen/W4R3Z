#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$HERE/.."
python -m unittest discover -s tests -p 'test_*.py' -v
node tests/background_harness.js
node tests/source_notes_folder_undo_harness.js
PROGRSS_EXTENSION_ROOT=Firefox node tests/source_notes_folder_undo_harness.js
node tests/source_notes_source_repair_harness.js
PROGRSS_EXTENSION_ROOT=Firefox node tests/source_notes_source_repair_harness.js
node tests/relay_core_harness.js
node tests/source_notes_entrypoints_harness.js
PROGRSS_EXTENSION_ROOT=Firefox node tests/source_notes_entrypoints_harness.js
node tests/source_notes_lineage_harness.js
PROGRSS_EXTENSION_ROOT=Firefox node tests/source_notes_lineage_harness.js
node tests/source_notes_publication_site_harness.js
PROGRSS_EXTENSION_ROOT=Firefox node tests/source_notes_publication_site_harness.js
node tests/source_notes_private_transfer_harness.js
PROGRSS_EXTENSION_ROOT=Firefox node tests/source_notes_private_transfer_harness.js
python tests/source_notes_workbench_private_backup_harness.py --root . --artifacts ../evidence/rev0104/extension-workbench-private-backup-chromium
python tests/source_notes_workbench_private_backup_harness.py --root Firefox --artifacts ../evidence/rev0104/extension-workbench-private-backup-firefox
node tests/firefox_background_harness.js
node tests/acquisition_harness.js
node tests/vault_conflict_harness.js
python tests/source_notes_shared_folder_merge_review_harness.py --extension . --artifacts ../evidence/rev0104/extension-shared-folder-merge-chromium
python tests/source_notes_shared_folder_merge_review_harness.py --extension Firefox --artifacts ../evidence/rev0104/extension-shared-folder-merge-firefox
python tests/browser_smoke.py
