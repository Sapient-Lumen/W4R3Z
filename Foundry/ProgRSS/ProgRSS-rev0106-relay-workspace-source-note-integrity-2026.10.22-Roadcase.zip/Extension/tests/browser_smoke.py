#!/usr/bin/env python3
from __future__ import annotations

import asyncio
import base64
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import zipfile
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = Path(os.environ.get('PROGRSS_TEST_ARTIFACTS', str(Path(tempfile.gettempdir()) / 'progrss-rev0080-validation')))
ARTIFACTS.mkdir(parents=True, exist_ok=True)

SAMPLE_STATE = {
    "schemaVersion": 17,
    "revision": 74,
    "sources": [
        {
            "id": "feed-one", "title": "Garden Notes", "type": "rss",
            "language": "en-gb", "titleLanguage": "en-gb",
            "url": "https://example.test/feed.xml", "enabled": True, "archivedAt": "",
            "lastOutcome": "changed", "lastItems": 1, "lastScan": "2026-10-17T20:00:00Z",
            "lastSuccessfulAt": "2026-10-17T20:00:00Z", "lastNewAt": "2026-10-17T20:00:00Z",
            "lastError": "", "lastProblemAt": "2026-10-10T08:00:00Z", "lastProblem": "Temporary HTTP 503",
            "pulse": {"nextAt": "2026-10-18T02:00:00Z"},
        },
        {
            "id": "feed-two", "title": "سجل الورشة", "type": "rss",
            "language": "ar", "titleLanguage": "ar",
            "url": "https://workshop.test/atom.xml", "enabled": False, "archivedAt": "",
            "lastOutcome": "unchanged", "lastItems": 0, "lastScan": "2026-10-17T19:00:00Z",
            "lastSuccessfulAt": "2026-10-17T19:00:00Z", "lastNewAt": "2026-10-16T10:01:00Z",
            "lastError": "", "lastProblemAt": "", "lastProblem": "",
        },
        {
            "id": "feed-moved", "title": "Neighborhood Calendar", "type": "rss",
            "url": "https://old.example.test/calendar.xml", "enabled": True, "archivedAt": "",
            "lastOutcome": "moved", "lastItems": 0, "lastScan": "2026-10-17T21:00:00Z",
            "lastSuccessfulAt": "2026-10-16T21:00:00Z", "lastNewAt": "2026-10-16T21:00:00Z",
            "lastError": "This source moved to calendar.example.test:8443.",
            "lastProblemAt": "2026-10-17T21:00:00Z", "lastProblem": "Address moved",
            "pendingRedirect": {
                "from": "https://old.example.test/calendar.xml",
                "to": "https://calendar.example.test:8443/feed.xml",
                "status": 301,
                "sourceOrigin": "https://old.example.test",
                "destinationOrigin": "https://calendar.example.test:8443",
                "sourceHost": "old.example.test",
                "destinationHost": "calendar.example.test:8443",
                "observedAt": "2026-10-17T21:00:00Z",
                "chain": [{"from": "https://old.example.test/calendar.xml", "to": "https://calendar.example.test:8443/feed.xml", "status": 301}],
            },
        },
        {
            "id": "feed-reconnect", "title": "Library Notices", "type": "rss",
            "url": "https://library.example.test/feed.xml", "enabled": True, "archivedAt": "",
            "lastOutcome": "permission", "lastItems": 0, "lastScan": "2026-10-17T22:00:00Z",
            "lastSuccessfulAt": "2026-10-16T22:00:00Z", "lastNewAt": "",
            "lastError": "Site access was removed. Reconnect this source before checking it again.",
            "lastProblemAt": "2026-10-17T22:00:00Z", "lastProblem": "Site access was removed.",
            "permissionMissing": True,
        },
        {
            "id": "watch-repair", "title": "Town notices", "type": "page",
            "url": "https://notices.example.test/", "enabled": True, "archivedAt": "",
            "mode": "cards", "selector": ".old-list", "titleSelector": "h2", "linkSelector": "a[href]",
            "threshold": 4, "ignoreNumbers": False, "version": 3,
            "lastOutcome": "watch-repair", "lastItems": 0, "lastScan": "2026-10-17T23:00:00Z",
            "lastSuccessfulAt": "2026-10-16T23:00:00Z", "lastNewAt": "2026-10-16T23:00:00Z",
            "lastError": "ProgRSS can no longer find the watched section. It stopped before creating misleading alerts.",
            "lastProblemAt": "2026-10-17T23:00:00Z", "lastProblem": "The watched section is no longer on the page.",
            "watchRepair": {
                "schema": "progrss.page-watch.repair.v1", "reason": "no-match",
                "noticedAt": "2026-10-17T23:00:00Z",
                "message": "ProgRSS can no longer find the watched section. It stopped before creating misleading alerts."
            },
            "watchHealth": {
                "schema": "progrss.page-watch.health.v1", "status": "attention", "reason": "structure-changed",
                "checkedAt": "2026-10-17T23:00:00Z",
                "message": "The watched page no longer resembles the section ProgRSS had been observing.",
                "metrics": {"previousEntries": 5, "currentEntries": 1, "matchCount": 1}
            },
        },
        {
            "id": "watch-steady", "title": "Community board", "type": "page",
            "url": "https://community.example.test/", "enabled": True, "archivedAt": "",
            "mode": "region", "selector": "main", "titleSelector": "", "linkSelector": "",
            "threshold": 4, "ignoreNumbers": False, "version": 2,
            "lastOutcome": "watch-pending", "lastItems": 0, "lastScan": "2026-10-18T00:15:00Z",
            "lastSuccessfulAt": "2026-10-17T20:00:00Z", "lastNewAt": "",
            "lastError": "", "lastProblemAt": "", "lastProblem": "",
            "watchStability": {
                "schema": "progrss.page-watch.stability.v1", "status": "pending",
                "reason": "text-size-shift", "recipeVersion": 2,
                "firstSeenAt": "2026-10-18T00:15:00Z", "lastSeenAt": "2026-10-18T00:15:00Z",
                "observations": 1,
                "metrics": {"previousCharacters": 1200, "currentCharacters": 180, "matchCount": 1},
                "message": "This page looked unusually different once. ProgRSS held that result until the next check."
            },
            "watchHealth": {
                "schema": "progrss.page-watch.health.v1", "status": "changed-shape", "reason": "text-size-shift",
                "checkedAt": "2026-10-18T00:15:00Z",
                "message": "This page looked unusually different once. ProgRSS held that result until the next check.",
                "metrics": {"previousCharacters": 1200, "currentCharacters": 180, "matchCount": 1}
            },
        },
    ],
    "collections": [
        {"id": "folder-reading", "title": "Reading", "mode": "union", "version": 7, "members": [
            {"kind": "source", "id": "feed-one", "reason": "Independent garden reporting for this reading route."}, {"kind": "collection", "id": "folder-practical"}
        ]},
        {"id": "folder-practical", "title": "Practical", "mode": "union", "version": 5, "members": [
            {"kind": "source", "id": "feed-two"}
        ], "sharedFolderOrigin": {
            "schema": "progrss.shared-folder.origin.v3",
            "publicationId": "smoke-publication",
            "curator": "Neighborhood readers",
            "note": "A small practical reading list for the repair café.",
            "issuedAt": "2026-10-18T22:01:00Z",
            "importedAt": "2026-10-18T22:02:00Z",
            "updatedAt": "2026-10-18T22:02:00Z",
            "digest": "sha256:bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
            "signatureState": "verified",
            "algorithm": "Ed25519",
            "keyId": "ed25519:1111111111111111111111111111111111111111111111111111111111111111",
            "updateUrl": "https://updates.example.test/practical.json"
        }},
    ],
    "items": [
        {
            "id": "feed-one|new", "sourceId": "feed-one", "title": "Seed library opens",
            "url": "https://example.test/posts/seed-library",
            "summary": "Neighbors can borrow seeds and share planting notes.",
            "body": "Neighbors can borrow seeds and share planting notes.\n\nThe new cabinet map is posted beside the greenhouse.\n\nLiteral <strong>feed text</strong> stays text.",
            "bodyIsSummary": False,
            "language": "en-gb", "titleLanguage": "en-gb", "summaryLanguage": "en-gb", "bodyLanguage": "en-gb",
            "published": "2026-10-17T20:00:00Z", "observedAt": "2026-10-17T20:01:00Z",
            "kind": "new", "readAt": "", "starred": False,
        },
        {
            "id": "feed-two|old", "sourceId": "feed-two", "title": "جدول مقهى الإصلاح",
            "url": "https://workshop.test/repair", "summary": "أحضر جهازًا صغيرًا واحدًا.",
            "body": "أحضر جهازًا صغيرًا واحدًا.", "bodyIsSummary": True,
            "language": "ar", "titleLanguage": "ar", "summaryLanguage": "ar", "bodyLanguage": "ar",
            "published": "2026-10-16T10:00:00Z", "observedAt": "2026-10-16T10:01:00Z",
            "kind": "new", "readAt": "2026-10-16T11:00:00Z", "starred": True,
        },
    ],
    "vault": {"mode": "indexeddb", "warning": ""},
    "transfer": {"undoAvailable": False},
    "sourceRepair": {"undoAvailable": False},
    "receiptRetirement": {"undoAvailable": False},
    "sharedFolderUpdate": {"undoAvailable": False},
    "pageWatchRepair": {"undoAvailable": False},
    "backupReminder": {
        "schema": "progrss.backup-reminder.v3", "visible": True, "meaningful": True,
        "status": "no-checked-copy", "disabled": False, "pendingCheck": False,
        "checkedCopyMissing": False, "changedSinceChecked": True, "recheckDue": False,
        "firstMeaningfulAt": "2026-10-01T00:00:00Z",
        "lastPreparedAt": "", "lastPreparedRevision": 0, "lastCheckedAt": "",
        "lastCheckedRevision": 0, "lastSeenAt": "", "missingSince": "",
        "snoozedUntil": "", "dueAt": "2026-10-08T00:00:00Z",
        "currentRevision": 74, "reminderDays": 30, "recheckDays": 90,
        "network": False, "writesVault": False,
    },
}


EXCHANGE_PREVIEW = json.loads((ROOT / "fixtures" / "exchange-preview.json").read_text())
EXCHANGE_SOURCE_LIST = (ROOT / "fixtures" / "exchange-source-list.json").read_text()
EXCHANGE_RECENT_UPDATES = (ROOT / "fixtures" / "exchange-recent-updates.json").read_text()

MOCK = r"""
(() => {
  const listeners = [];
  let state = __STATE__;
  let storageIncident = null;
  let libraryRecovery = null;
  let lastPreparedRaw = '';
  let lastCheckedRaw = '';
  let missingLibraryPrevious = null;
  let transferPrevious = null;
  let repairFixturePrevious = null;
  let repairUndoPrevious = null;
  let repairRevision = 70;
  let repairBlocked = false;
  let repairReasonConflict = false;
  let activeGraftReceipt = true;
  let retiredEvidence = [];
  let receiptRetirementUndo = {undoAvailable:false};
  let textRevision = 60;
  let sharingIdentity = null;
  let lastSharedFolderRaw = '';
  let sharedPublicationImported = false;
  let sharedUpdateUndoPrevious = null;
  let permissionResults = [];
  const permissionRequests = [];
  const permissionRemovals = [];
  let nodeHostPermission = false;
  const messageTypes = [];
  const localStore = {};
  const nodeFetchRequests = [];
  const nodeOrigin = 'http://127.0.0.1:43161';
  const nodeInvitationToken = 'AbCdEfGhIjKlMnOpQrStUvWxYz0123456789_-abcde';
  const nodePairToken = 'ZyXwVuTsRqPoNmLkJiHgFeDcBa9876543210_-zyxwv';
  const nodeFingerprint = `sha256:${'a'.repeat(64)}`;
  const nodeReviewedDigest = 'b'.repeat(64);
  let nodeCurrentDigest = nodeReviewedDigest;
  let nodeInvitationUsed = false;
  let nodePairActive = false;
  const nodePairId = '0123456789abcdefabcd';
  const nodeStats = {sources:7,activeSources:5,pageWatches:2,folders:4,items:31,unread:8,saved:3};
  const exchangeToken = 'ExChAnGeAbCdEfGhIjKlMnOpQrStUvWxYz0123456789_';
  const captureToken = 'CaPtUrEAbCdEfGhIjKlMnOpQrStUvWxYz0123456789_';
  const captureSourceId = 'watch-repair';
  const capturePageUrl = 'https://notices.example.test/';
  const capturePagePermissionPattern = 'https://notices.example.test/*';
  const captureBaseDigest = 'd'.repeat(64);
  const capturePreviewDigest = 'e'.repeat(64);
  const captureRecipeDigest = 'f'.repeat(64);
  let captureInvitationUsed = false;
  let capturePagePermission = false;
  const exchangePreview = __EXCHANGE_PREVIEW__;
  const exchangeSourceList = __EXCHANGE_SOURCE_LIST__;
  const exchangeRecentUpdates = __EXCHANGE_RECENT_UPDATES__;
  if (!globalThis.crypto?.randomUUID) {
    const fallbackUuid = () => '11111111-2222-4333-8444-555555555555';
    if (globalThis.crypto) Object.defineProperty(globalThis.crypto, 'randomUUID', {value:fallbackUuid, configurable:true});
    else Object.defineProperty(globalThis, 'crypto', {value:{randomUUID:fallbackUuid}, configurable:true});
  }
  if (!globalThis.crypto?.subtle) {
    const bytesFromHex = value => Uint8Array.from(String(value).match(/../g).map(part => parseInt(part, 16))).buffer;
    const subtle = {digest: async (_algorithm, value) => {
      const raw = new TextDecoder().decode(value);
      if (raw === exchangeSourceList) return bytesFromHex(exchangePreview.artifacts.sourceList.sha256);
      if (raw === exchangeRecentUpdates) return bytesFromHex(exchangePreview.artifacts.recentUpdates.sha256);
      throw new Error('Unexpected bytes in mock SHA-256 boundary.');
    }};
    if (globalThis.crypto) Object.defineProperty(globalThis.crypto, 'subtle', {value: subtle, configurable: true});
    else Object.defineProperty(globalThis, 'crypto', {value: {subtle}, configurable: true});
  }
  const exchangeDocument = () => ({
    ...structuredClone(exchangePreview), schema:'progrss.node.exchange.v1', state:'review',
    exchangeId:'abcdef0123456789abcd', createdAt:new Date().toISOString(), expiresAt:new Date(Date.now()+29*60*1000).toISOString(),
    node:{origin:nodeOrigin,version:'0.80.0',revision:'rev0080',instanceFingerprint:nodeFingerprint,identityPersistence:'until-node-stops'},
    scope:'one-expiring-reviewed-artifact-handoff', revocable:true, automatic:false, network:false, writes:false
  });
  const captureDocument = () => ({
    schema:'progrss.node.capture.v1', state:'review', operationType:'capture-rendered-page-once',
    captureId:'capture0123456789abcd', createdAt:new Date().toISOString(), expiresAt:new Date(Date.now()+9*60*1000).toISOString(),
    previewDigest:capturePreviewDigest, recipeSha256:captureRecipeDigest,
    source:{sourceId:captureSourceId,title:'Town notices',type:'page',site:'notices.example.test',url:capturePageUrl,enabled:true,paused:false,action:'capture-now',pageRecipe:{mode:'cards',selector:'main article',titleSelector:'h1,h2,h3,h4,h5,h6,[role="heading"]',linkSelector:'a[href]',threshold:4,ignoreNumbers:false}},
    action:'capture-now',
    library:{file:'reading-room.sqlite3',mode:'node-owned',sha256:captureBaseDigest,bytes:8192,revision:2},
    node:{origin:nodeOrigin,version:'0.80.0',revision:'rev0080',instanceFingerprint:nodeFingerprint,identityPersistence:'until-node-stops'},
    scope:'one-expiring-rendered-page-capture',
    limits:{artifactBytes:300000,topFrameOnly:true,isolatedWorld:true,arbitrarySharedCode:false,networkRequestsByNode:0},
    consequences:{browserMayAlreadyBeSignedIn:true,cookiesTransferredToNode:false,credentialsTransferredToNode:false,browserStorageTransferredToNode:false,rawHtmlTransferred:false,screenshotTransferred:false,selectedTextAndLinksTransferred:true,automaticScheduleCreated:false,resultCommittedAtomically:true,durableReceipt:true},
    automatic:false,revocable:true,network:false,writes:false
  });
  const captureResult = body => ({
    schema:'progrss.node.acquisition-result.v1',state:'committed',captureSchema:'progrss.node.capture.v1',replayed:false,
    receipt:{schema:'progrss.node.acquisition-receipt.v1',receiptId:`sha256:${'1'.repeat(64)}`,operationId:'cap-smoke-operation',operationType:'capture-rendered-page-once',sourceId:captureSourceId,outcome:'coverage-shift',startedAt:new Date().toISOString(),completedAt:new Date().toISOString(),baseLibrarySha256:captureBaseDigest,previewDigest:capturePreviewDigest,resultLibrarySha256:'2'.repeat(64),resultRevision:3,
      request:{sourceTitle:'Town notices',sourceHost:'notices.example.test',sourceType:'page',action:'capture-now',transport:'extension-rendered-dom',networkRequests:0,artifactSchema:'progrss.browser-capture.v4',artifactSha256:'3'.repeat(64),recipeChanged:false,extractorRevision:'perimeter-v1',selectionCandidateId:body?.artifact?.selection?.candidateId||'',selectionLevel:body?.artifact?.selection?.assessment?.level||'',selectionSummary:body?.artifact?.selection?.assessment?.summary||'',pageContextSchema:body?.artifact?.context?.schema||'',pageContextKinds:(body?.artifact?.context?.notices||[]).map(row=>row.kind),possibleContinuation:true,possiblePartialRendering:true,modalLayers:1,embeddedFrames:1,openShadowRoots:0,busyRegions:0,coverageReviewSchema:body?.artifact?.coverage?.schema||'',coverageDecision:body?.artifact?.coverage?.decision||'',acknowledgedBoundaryKinds:body?.artifact?.coverage?.acknowledgedNoticeKinds||[],partialViewAcknowledged:body?.artifact?.coverage?.decision==='use-current-rendering',continuitySchema:'progrss.capture-continuity.v1',continuityAction:'hold',continuityReason:'partial-render-window-shift',continuityOverlapPercent:0,baselinePreserved:true,topFrameOnly:true,isolatedWorld:true,browserCookiesTransferred:false,browserCredentialsTransferred:false,browserStorageTransferred:false,rawHtmlTransferred:false,screenshotTransferred:false,automaticScheduleCreated:false,resumed:false,attempt:1},
      summary:{itemsAdded:0,baseline:false,baselinePreserved:true,enabledNow:false,recipeChanged:false,message:'This partial list appears to show a different rendered window. ProgRSS kept the earlier baseline and created no mass add-or-remove alert.'},
      effects:{networkRequests:0,sourceEnabled:false,automaticScheduleCreated:false},
      evidence:{capture:{capturedAt:body?.artifact?.capturedAt||new Date().toISOString(),page:body?.artifact?.page||{},provenance:body?.artifact?.provenance||{}},continuity:{schema:'progrss.capture-continuity.v1',action:'hold',reason:'partial-render-window-shift',overlapPercent:0,baselinePreserved:true},browserCapture:true}},
    library:{file:'reading-room.sqlite3',mode:'node-owned',sha256:'2'.repeat(64),revision:3},network:false,writes:true,automaticSchedule:false
  });
  const sectionAssessment = (level, summary, reasons, warnings, signals={}) => ({
    schema:'progrss.capture-section-assessment.v1',level,summary,reasons,warnings,
    signals:{selectorKind:signals.selectorKind||'generic',semanticBoundary:Boolean(signals.semanticBoundary),uniqueMatch:Boolean(signals.uniqueMatch),visibleMatches:Number(signals.visibleMatches||0),hiddenMatches:Number(signals.hiddenMatches||0),repeatedEntries:Number(signals.repeatedEntries||0),linkedEntries:Number(signals.linkedEntries||0),titledEntries:Number(signals.titledEntries||0),consistentEntries:Number(signals.consistentEntries||0),clutterElements:Number(signals.clutterElements||0),textCharacters:Number(signals.textCharacters||0)}
  });
  const captureCandidates = () => ({
    schema:'progrss.browser-capture-candidates.v3',capturedAt:new Date().toISOString(),
    page:{url:capturePageUrl,title:'Town notices — signed in',language:'en',direction:'ltr'},source:{id:captureSourceId,url:capturePageUrl},
    context:{
      schema:'progrss.capture-page-context.v1',
      notices:[
        {kind:'continuation',tone:'boundary',summary:'This page appears to continue elsewhere. Capture includes only this rendered page.'},
        {kind:'partial-render',tone:'caution',summary:'This list may render only part of its items at once. Capture includes only entries currently present in the page DOM.'},
        {kind:'overlay',tone:'caution',summary:'A dialog or consent layer is visible. Dismiss it before choosing if it hides the updates you need.'},
        {kind:'frames',tone:'boundary',summary:'Content inside 1 embedded frame is outside this top-frame capture.'}
      ],
      signals:{continuationLinks:1,paginationLandmarks:1,continuationControls:0,partialSetSignals:1,virtualMarkers:1,scrollWindows:1,modalLayers:1,embeddedFrames:1,openShadowRoots:0,busyRegions:0}
    },
    candidates:[
      {id:'saved',label:'Saved watched section',description:'Use the declarative repeated-entry section already stored for this watched page.',recipe:{mode:'cards',selector:'main article',titleSelector:'h1,h2,h3,h4,h5,h6,[role="heading"]',linkSelector:'a[href]',threshold:4,ignoreNumbers:false},capture:{mode:'cards',matchCount:3,content:'',cards:[{key:'detour',title:'Bus detour begins Monday',url:'https://notices.example.test/detour',summary:'Bus detour begins Monday around the civic center.'},{key:'pool',title:'Pool hours adjusted',url:'https://notices.example.test/pool',summary:'Pool hours adjusted for maintenance.'},{key:'market',title:'Night market permits',url:'https://notices.example.test/market',summary:'Night market permit applications close Friday.'}]},examples:{matched:['Bus detour begins Monday around the civic center.','Pool hours adjusted for maintenance.','Night market permit applications close Friday.'],ignored:'Signed-in account menu · Edit profile · Log out'},assessment:sectionAssessment('steadier','More likely to stay put, based on the structure visible now.',['The match uses a semantic main, article, role, or item boundary.','Most entries have their own destination link.'],[],{selectorKind:'semantic',semanticBoundary:true,visibleMatches:3,repeatedEntries:3,linkedEntries:3,titledEntries:3,consistentEntries:3,textCharacters:132})},
      {id:'repeated',label:'Repeated entries on this page',description:'Use 3 visible records found through semantic articles in the main region.',recipe:{mode:'cards',selector:'main article',titleSelector:'h1,h2,h3,h4,h5,h6,[role="heading"]',linkSelector:'a[href]',threshold:4,ignoreNumbers:false},capture:{mode:'cards',matchCount:3,content:'',cards:[{key:'road',title:'Road closure moved to Thursday',url:'https://notices.example.test/road',summary:'Road closure moved to Thursday — crews begin at 8 AM.'},{key:'library',title:'Library meeting room closed',url:'https://notices.example.test/library',summary:'Library meeting room closed for repairs this weekend.'},{key:'garden',title:'Garden volunteers needed',url:'https://notices.example.test/garden',summary:'Garden volunteers needed Saturday morning.'}]},examples:{matched:['Road closure moved to Thursday — crews begin at 8 AM.','Library meeting room closed for repairs this weekend.','Garden volunteers needed Saturday morning.'],ignored:'Signed-in account menu · Edit profile · Log out'},assessment:sectionAssessment('steadier','More likely to stay put, based on the structure visible now.',['The match uses a semantic main, article, role, or item boundary.','Most entries have their own destination link.','Most entry text lengths are structurally similar.'],[],{selectorKind:'semantic',semanticBoundary:true,visibleMatches:3,repeatedEntries:3,linkedEntries:3,titledEntries:3,consistentEntries:3,textCharacters:146})},
      {id:'main',label:'Primary readable text',description:'Use the main element.',recipe:{mode:'region',selector:'main',titleSelector:'',linkSelector:'',threshold:4,ignoreNumbers:false},capture:{mode:'region',matchCount:1,content:'Town notices Road closure moved to Thursday Library meeting room closed Garden volunteers needed',cards:[]},examples:{matched:['Town notices · Road closure moved to Thursday · Library meeting room closed · Garden volunteers needed'],ignored:'Signed-in account menu · Edit profile · Log out'},assessment:sectionAssessment('watchful','Usable, but one or more page details may shift.',['The match uses a semantic main, article, role, or item boundary.','The selector matches one visible region.'],['The region is broad and may include unrelated page changes.'],{selectorKind:'semantic',semanticBoundary:true,uniqueMatch:true,visibleMatches:1,textCharacters:94})}
    ],
    provenance:{kind:'rendered-browser-dom',topFrameOnly:true,isolatedWorld:true,arbitrarySharedCode:false,extensionVersion:'0.80.0',extractorRevision:'perimeter-v1'}
  });
  const nodeDocument = stateName => ({
    schema:'progrss.node.pairing.v1',state:stateName,
    node:{origin:nodeOrigin,version:'0.80.0',revision:'rev0080',instanceFingerprint:nodeFingerprint,identityPersistence:'until-node-stops'},
    library:{file:'reading-room.sqlite3',mode:'node-owned',sha256:nodeCurrentDigest,bytes:4096,revision:2,stats:structuredClone(nodeStats)},
    capabilities:{schema:'progrss.node.capabilities.v1',readLibrarySummary:true,readItems:false,readSourceAddresses:false,writeLibrary:false,fetchSources:false,publish:false,merge:false,nodeToNode:false,webrtcCourier:false},
    scope:'loopback-session-read-only-summary',automatic:false,revocable:true,
    ...(stateName==='review'?{expiresAt:new Date(Date.now()+9*60*1000).toISOString()}:{}),
    ...(stateName==='paired'?{pairing:{pairId:nodePairId,origin:'chrome-extension://smoke-test',clientName:'ProgRSS Extension',clientVersion:'0.80.0',createdAt:new Date().toISOString(),lastSeenAt:new Date().toISOString(),reviewedLibrarySha256:nodeReviewedDigest}}:{}),
  });
  globalThis.__setPermissionResults = (...values) => { permissionResults = values.flat().map(Boolean); };
  globalThis.__permissionRequests = permissionRequests;
  globalThis.__permissionRemovals = permissionRemovals;
  globalThis.__nodeHostPermission = () => nodeHostPermission;
  globalThis.__messageTypes = messageTypes;
  globalThis.__nodeFetchRequests = nodeFetchRequests;
  globalThis.__nodeInvitationUrl = `${nodeOrigin}/#pair=${nodeInvitationToken}`;
  globalThis.__exchangeInvitationUrl = `${nodeOrigin}/#exchange=${exchangeToken}`;
  globalThis.__captureInvitationUrl = `${nodeOrigin}/#capture=${captureToken}`;
  globalThis.__capturePagePermission = () => capturePagePermission;
  globalThis.__changeNodeLibraryDigest = () => { nodeCurrentDigest = 'c'.repeat(64); };
  globalThis.__clearMockLogs = () => { permissionRequests.length = 0; permissionRemovals.length = 0; messageTypes.length = 0; nodeFetchRequests.length = 0; };
  globalThis.fetch = async (input, options={}) => {
    const url = new URL(String(input), location.href);
    const headers = new Headers(options.headers || {});
    const auth = headers.get('Authorization') || '';
    const method = String(options.method || 'GET').toUpperCase();
    nodeFetchRequests.push({url:url.href,method,authorization:auth,credentials:options.credentials||'',cache:options.cache||''});
    const respond = (status, body) => new Response(JSON.stringify(body), {status,headers:{'Content-Type':'application/json'}});
    const respondRaw = (status, body, type) => new Response(body, {status,headers:{'Content-Type':type}});
    if (url.origin !== nodeOrigin) return respond(404,{error:'mock Node not found'});
    if (url.pathname === '/api/v1/capture-review' && method === 'GET') {
      if (auth !== `Bearer ${captureToken}` || captureInvitationUsed) return respond(401,{error:'browser request is invalid, expired, or already used'});
      return respond(200,captureDocument());
    }
    if (url.pathname === '/api/v1/captures' && method === 'POST') {
      if (auth !== `Bearer ${captureToken}` || captureInvitationUsed) return respond(401,{error:'browser request is invalid, expired, or already used'});
      const body = JSON.parse(String(options.body || '{}'));
      captureInvitationUsed = true;
      return respond(201,captureResult(body));
    }
    if (url.pathname === '/api/v1/exchange-review' && method === 'GET') {
      if (auth !== `Bearer ${exchangeToken}`) return respond(401,{error:'exchange invitation is invalid, expired, or revoked'});
      return respond(200,exchangeDocument());
    }
    if (url.pathname === '/api/v1/exchange/source-list' && method === 'GET') {
      if (auth !== `Bearer ${exchangeToken}`) return respond(401,{error:'exchange invitation is invalid, expired, or revoked'});
      return respondRaw(200,exchangeSourceList,'application/vnd.progrss.shared-folder+json');
    }
    if (url.pathname === '/api/v1/exchange/recent-updates' && method === 'GET') {
      if (auth !== `Bearer ${exchangeToken}`) return respond(401,{error:'exchange invitation is invalid, expired, or revoked'});
      return respondRaw(200,exchangeRecentUpdates,'application/feed+json');
    }
    if (url.pathname === '/api/v1/pairing-review' && method === 'GET') {
      if (auth !== `Bearer ${nodeInvitationToken}` || nodeInvitationUsed) return respond(401,{error:'pairing invitation is invalid or already used'});
      return respond(200,nodeDocument('review'));
    }
    if (url.pathname === '/api/v1/pairings' && method === 'POST') {
      if (auth !== `Bearer ${nodeInvitationToken}` || nodeInvitationUsed) return respond(401,{error:'pairing invitation is invalid or already used'});
      nodeInvitationUsed = true; nodePairActive = true;
      return respond(201,{...nodeDocument('paired'),token:nodePairToken});
    }
    if (url.pathname === '/api/v1/pairing' && method === 'GET') {
      if (auth !== `Bearer ${nodePairToken}` || !nodePairActive) return respond(401,{error:'pairing capability is invalid or revoked'});
      return respond(200,nodeDocument('paired'));
    }
    if (url.pathname === '/api/v1/pairing/revoke' && method === 'POST') {
      if (auth !== `Bearer ${nodePairToken}` || !nodePairActive) return respond(401,{error:'pairing capability is invalid or revoked'});
      nodePairActive = false;
      return respond(200,{schema:'progrss.node.pairing.v1',state:'revoked',pairId:nodePairId});
    }
    return respond(404,{error:'unknown mock Node route'});
  };
  const broadcast = detail => listeners.forEach(listener => { try { listener({type:'progrss:state-changed', detail}, {}, () => {}); } catch {} });
  const normalizeSourceNoteReason = value => {
    if(value===undefined||value===null)return null;
    if(typeof value!=='string')throw new Error('placement reason must be a string');
    const reason=value.replace(/^[ \t\r\n\f\v]+|[ \t\r\n\f\v]+$/g,'');
    if(!reason)return null;
    if(Array.from(reason).length>280)throw new Error('placement reason exceeds 280 Unicode code points');
    return reason;
  };
  const summarize = value => ({
    sources:value.sources.length, activeSources:value.sources.filter(row=>row.enabled&&!row.archivedAt).length,
    pausedSources:value.sources.filter(row=>!row.enabled&&!row.archivedAt).length,
    archivedSources:value.sources.filter(row=>row.archivedAt).length,
    movedSources:value.sources.filter(row=>row.enabled&&!row.archivedAt&&row.pendingRedirect).length,
    feeds:value.sources.filter(row=>row.type==='rss').length,pageWatches:value.sources.filter(row=>row.type==='page').length,
    collections:value.collections.length,items:value.items.length,unread:value.items.filter(row=>!row.readAt).length,
    saved:value.items.filter(row=>row.starred).length,snapshots:0,advancedRecords:0
  });
  const sourceReferenceReport = (firstId='repair-main', secondId='repair-copy') => {
    const fallback={
      'repair-main':{id:'repair-main',title:'Field Notes',url:'https://notes.example.test/feed.xml'},
      'repair-copy':{id:'repair-copy',title:'Field Notes (old copy)',url:'https://notes.example.test/old.xml'}
    };
    const readSource=id=>{const row=state.sources.find(source=>source.id===id)||fallback[id]||{id,title:id,url:''};return {id:row.id,title:row.title||'Untitled source',url:row.url||''};};
    const record={index:0,recordId:'graft-receipt',title:'Reviewed garden graft',schema:'progrss.recipe.graft.receipt.v1',referenceCount:2,sourceReferenceCount:1,updateReferenceCount:1,pathsTruncated:false,retirement:{eligible:true,action:'retire-graft-receipt',label:'Review retirement',explanation:'ProgRSS can preserve this exact graft receipt in a retired-evidence archive without changing what it recorded.'},references:[{kind:'source',targetId:'repair-copy',sourceId:'repair-copy',sourceTitle:'Field Notes (old copy)',label:'Source history',referenceCount:1,paths:['$["sourceId"]']},{kind:'update',targetId:'repair-main|shared',sourceId:'repair-main',sourceTitle:'Field Notes',label:'A shared field report',referenceCount:1,paths:['$["evidence"]["itemId"]']} ]};
    const groups=activeGraftReceipt?[{key:'receipts',label:'Receipts',reason:'This record describes past evidence or a completed operation. Rewriting it would make the record describe something that did not happen.',recordCount:1,referenceCount:2,scanExceeded:false,records:[record]}]:[];
    return {
      schema:'progrss.source-reference-report.v1',reviewedRevision:repairRevision,
      sources:[readSource(firstId),readSource(secondId)],sharedAddresses:['https://notes.example.test/feed.xml'],canRepair:!activeGraftReceipt,
      summary:{blockingGroups:groups.length,blockingRecords:groups.length,exactReferences:groups.length?2:0,sourceHistoryReferences:groups.length?1:0,retainedUpdateReferences:groups.length?1:0,retiredRecords:retiredEvidence.length,retiredReferences:retiredEvidence.length?2:0,scanExceeded:false},
      groups,retiredEvidence:structuredClone(retiredEvidence),retirementUndo:structuredClone(receiptRetirementUndo),
      network:false,writes:false,browserProfileRead:false,note:'This report does not rewrite or transfer trust. An eligible graft receipt may be moved intact into retired evidence only after a separate review.'
    };
  };
  const communitySharedFolder = (sourcePageUrl='') => {
    const updateUrl='https://example.test/community.json';
    const raw=JSON.stringify({schema:'progrss.bundle.v3',exportedAt:'2026-10-18T23:30:00Z',root:'community-root',title:'Community sources',publication:{schema:'progrss.shared-folder.publication.v1',id:'community-publication',curator:'Community desk',note:'A small public reading route.',issuedAt:'2026-10-18T23:30:00Z'},distribution:{schema:'progrss.shared-folder.distribution.v1',updateUrl},integrity:{schema:'progrss.shared-folder.integrity.v1',digest:`sha256:${'d'.repeat(64)}`},sources:[{kind:'feed',id:'community-feed',title:'Community bulletin',url:'https://community.test/feed.xml'}],collections:[{id:'community-root',title:'Community sources',mode:'union',members:[{kind:'collection',id:'community-local'}]},{id:'community-local',title:'Local notices',mode:'union',members:[{kind:'source',id:'community-feed'}]}]},null,2);
    const preview={schema:'progrss.shared-folder.preview.v3',mode:'new',title:'Community sources',feedCount:1,pageWatchCount:0,folders:2,reusedSources:0,newSources:1,duplicateRecipes:0,canImport:true,reason:'',reviewedRevision:74,curator:'Community desk',note:'A small public reading route.',publicationId:'community-publication',updateUrl,signatureState:'unsigned',algorithm:'',keyId:'',fingerprint:'',network:true,writes:false,selectionMode:'all',independentExcerpt:false,updateLinked:true,selectedFolderId:'',selectedFolderPath:'',parentTitle:'',parentPublicationId:'',fullSourceCount:1,fullFolderCount:2,availableSections:[{id:'community-local',title:'Local notices',path:'Community sources › Local notices',sourceCount:1,feedCount:1,pageWatchCount:0,folderCount:1}],contents:{schema:'progrss.shared-folder.contents.v2',title:'Community sources',root:'community-root',sourceCount:1,sourceNoteCount:1,feedCount:1,pageWatchCount:0,folderCount:2,maxDepth:1,folders:[{id:'community-root',title:'Community sources',path:'Community sources',depth:0,isRoot:true,directSources:0,directFolders:1,branchSources:1,branchFeeds:1,branchPageWatches:0,branchFolders:2,state:'listed'},{id:'community-local',title:'Local notices',path:'Community sources › Local notices',depth:1,isRoot:false,directSources:1,directFolders:0,branchSources:1,branchFeeds:1,branchPageWatches:0,branchFolders:1,state:'listed'}],sources:[{id:'community-feed',title:'Community bulletin',type:'rss',host:'community.test',folderCount:1,folders:['Community sources › Local notices'],foldersOmitted:0,sourceNoteCount:1,placements:[{folderId:'community-local',folderPath:'Community sources › Local notices',reason:'Useful for local service changes.'}],state:'new-paused'}],network:false,writes:false}};
    const remote={requestedUrl:updateUrl,finalUrl:updateUrl,status:200,contentType:'application/vnd.progrss.shared-folder+json',redirects:[],credentials:'omitted',automatic:false,directAddress:!sourcePageUrl};
    if(sourcePageUrl)remote.sourcePageUrl=sourcePageUrl;
    return {raw,preview,remote};
  };
  function reply(message) {
    const data = message.data || {};
    if (message.type === 'capture-rendered-page') return {ok:true,result:captureCandidates()};
    if (message.type === 'get-state') return {ok:true,result:{...structuredClone(state),storageIncident:structuredClone(storageIncident),libraryRecovery:structuredClone(libraryRecovery)}};
    if (message.type === 'seed-backup-reminder') {
      state.backupReminder={schema:'progrss.backup-reminder.v3',visible:true,meaningful:true,status:'no-checked-copy',disabled:false,pendingCheck:false,checkedCopyMissing:false,changedSinceChecked:true,recheckDue:false,firstMeaningfulAt:'2026-10-01T00:00:00Z',lastPreparedAt:'',lastPreparedRevision:0,lastCheckedAt:'',lastCheckedRevision:0,lastSeenAt:'',missingSince:'',snoozedUntil:'',dueAt:'2026-10-08T00:00:00Z',currentRevision:74,reminderDays:30,recheckDays:90,network:false,writesVault:false};
      broadcast({kind:'backup-reminder-test'});
      return {ok:true,result:structuredClone(state.backupReminder)};
    }
    if (message.type === 'seed-library-recovery') {
      const remembered=(state.sources?.length||state.items?.length||state.collections?.length)?structuredClone(state):(missingLibraryPrevious?structuredClone(missingLibraryPrevious):structuredClone(state));
      missingLibraryPrevious=remembered;
      const known=summarize(remembered);
      state={schemaVersion:17,sources:[],collections:[],items:[],vault:{mode:'indexeddb',warning:''},transfer:{undoAvailable:false},sourceRepair:{undoAvailable:false},receiptRetirement:{undoAvailable:false}};
      libraryRecovery={schema:'progrss.library.recovery.v1',state:'missing',reason:'vault-missing',detectedAt:new Date().toISOString(),lastCommittedAt:'2026-10-18T12:40:00Z',lastRevision:81,currentRevision:0,lastKnown:known,canRestoreFile:true,canUseEmptyLibrary:true,network:false};
      storageIncident=null;broadcast({kind:'library-recovery-required'});return {ok:true,result:structuredClone(libraryRecovery)};
    }
    if (message.type === 'accept-empty-library') {
      if(!libraryRecovery)return {ok:true,result:{accepted:false,summary:summarize(state),libraryRecovery:{schema:'progrss.library.recovery.v1',state:'empty'}}};
      libraryRecovery=null;broadcast({kind:'library-empty-accepted'});return {ok:true,result:{accepted:true,summary:summarize(state),libraryRecovery:{schema:'progrss.library.recovery.v1',state:'empty'}}};
    }
    if (message.type === 'seed-storage-incident') {
      storageIncident={schema:'progrss.storage.incident.v1',occurredAt:'2026-10-18T11:40:00Z',reason:'quota',operationKind:'item',operation:'Changing read or saved state',message:'Browser storage appears full or at its limit.',vaultMode:'indexeddb',savedRevision:74,savedLibrary:{sources:state.sources.length,items:state.items.length,unread:state.items.filter(row=>!row.readAt).length,saved:state.items.filter(row=>row.starred).length}};
      broadcast({kind:'storage-write-failed'});
      return {ok:true,result:structuredClone(storageIncident)};
    }
    if (message.type === 'probe-vault-write') {
      storageIncident=null;broadcast({kind:'storage-write-restored'});
      return {ok:true,result:{available:true,mode:'indexeddb',note:'A small test write succeeded. Repeat the action that failed; larger writes can still require more room.'}};
    }
    if (message.type === 'set-item') {
      const item=state.items.find(x=>x.id===data.itemId); if(!item)return {ok:false,error:'missing'};
      if(data.read!==undefined)item.readAt=data.read?(item.readAt||new Date().toISOString()):'';
      if(data.starred!==undefined)item.starred=Boolean(data.starred);
      if(state.backupReminder?.lastCheckedAt){state.backupReminder={...state.backupReminder,changedSinceChecked:true,status:'changed'};}
      broadcast({kind:'item'});
      return {ok:true,result:{item}};
    }
    if (message.type === 'seed-page-change') {
      if(!state.sources.some(row=>row.id==='watch-hours'))state.sources.push({id:'watch-hours',title:'Library hours',type:'page',url:'https://library.example.test/hours',enabled:true,archivedAt:'',mode:'region',selector:'main',threshold:4,ignoreNumbers:false,lastOutcome:'changed',lastItems:1,lastScan:'2026-10-18T18:00:00Z',lastSuccessfulAt:'2026-10-18T18:00:00Z',lastNewAt:'2026-10-18T18:00:00Z',lastError:'',lastProblemAt:'',lastProblem:''});
      if(!state.items.some(row=>row.id==='watch-hours|legacy'))state.items.push({id:'watch-hours|legacy',sourceId:'watch-hours',title:'Older library alert',url:'https://library.example.test/hours',summary:'+opening time  −previous time',observedAt:'2026-10-17T18:00:00Z',published:'',kind:'changed',readAt:'',starred:false});
      if(!state.items.some(row=>row.id==='watch-hours|change'))state.items.unshift({id:'watch-hours|change',sourceId:'watch-hours',title:'Library hours changed',url:'https://library.example.test/hours',summary:'Changed “Monday at 9” to “Tuesday at 10”',observedAt:'2026-10-18T18:00:00Z',published:'',kind:'changed',readAt:'',starred:false,change:{schema:'progrss.page-change.v1',kind:'text-changed',mode:'region',summary:'Changed “Monday at 9” to “Tuesday at 10”',before:'Library opens Monday at 9. The reading room closes at 6.',after:'Library opens Tuesday at 10. The reading room closes at 6.',removed:'Monday at 9',added:'Tuesday at 10',removedWords:3,addedWords:3,delta:13,threshold:4,ignoreNumbers:false}});
      broadcast({kind:'page-change-seeded'});return {ok:true,result:{sourceId:'watch-hours',itemId:'watch-hours|change'}};
    }
    if (message.type === 'mark-all-read') {
      const ids=[]; for(const item of state.items){if(!item.readAt){item.readAt=new Date().toISOString();ids.push(item.id)}}
      return {ok:true,result:{changed:ids}};
    }
    if (message.type === 'mark-items-read') {
      const ids=[]; for(const item of state.items){if(data.ids.includes(item.id)&&!item.readAt){item.readAt=new Date().toISOString();ids.push(item.id)}}
      return {ok:true,result:{changed:ids}};
    }
    if (message.type === 'mark-items-unread') {
      for(const item of state.items){if(data.ids.includes(item.id))item.readAt=''}
      return {ok:true,result:{}};
    }
    if (message.type === 'toggle-source') {
      const s=state.sources.find(x=>x.id===data.sourceId);s.enabled=data.enabled;
      if(data.enabled){delete s.permissionMissing;if(s.lastOutcome==='permission'){s.lastOutcome='ready';s.lastError=''}}
      return {ok:true,result:{source:s}};
    }
    if (message.type === 'accept-source-redirect') {
      const s=state.sources.find(x=>x.id===data.sourceId);if(!s||!s.pendingRedirect)return {ok:false,error:'stale move',code:'STALE_REDIRECT'};
      const from=s.url,to=s.pendingRedirect.to;s.previousUrls=[...(s.previousUrls||[]),from];s.url=to;delete s.pendingRedirect;
      s.lastOutcome='unchanged';s.lastError='';s.lastSuccessfulAt=new Date().toISOString();
      return {ok:true,result:{source:s,moved:true,recovered:false,from,to}};
    }
    if (message.type === 'archive-source') {
      const s=state.sources.find(x=>x.id===data.sourceId);s.archivedAt=new Date().toISOString();s.enabled=false;return {ok:true,result:{source:s}};
    }
    if (message.type === 'refresh-all') return {ok:true,result:{checked:1,results:[{added:0}]}};
    if (message.type === 'refresh-source') return {ok:true,result:{added:0}};
    if (message.type === 'refresh-sources') return {ok:true,result:{checked:data.sourceIds.length,results:data.sourceIds.map(()=>({added:0}))}};
    if (message.type === 'preview-page-watch-repair') {
      const source=state.sources.find(row=>row.id===data.sourceId);
      if(!source||!source.watchRepair)return {ok:false,error:'That page watch is no longer waiting for repair.',code:'PAGE_WATCH_REPAIR_NOT_FOUND'};
      return {ok:true,result:{schema:'progrss.page-watch.repair-review.v1',reviewedRevision:74,source:{id:source.id,title:source.title,url:source.url,reason:source.watchRepair.reason},proposals:[
        {token:'repair-cards',title:'Watch notice entries',description:'Watch repeated notices and alert when one is added, removed, or reworded.',mode:'cards',count:3,examples:['Road work moves to Tuesday','Library roof meeting','Garden volunteer morning'],preview:''},
        {token:'repair-main',title:'Watch the page’s main text',description:'Use the main readable text when repeated entries are not reliable.',mode:'region',count:1,examples:[],preview:'Town notices, road work, library meeting, and garden volunteer updates.'}
      ],warnings:[],preserves:['Earlier page-change alerts','Read and saved state','Folder placement','Source activity history'],network:true,writes:false,automatic:false}};
    }
    if (message.type === 'repair-page-watch') {
      const source=state.sources.find(row=>row.id===data.sourceId);
      if(!source||!source.watchRepair)return {ok:false,error:'That page watch is no longer waiting for repair.',code:'PAGE_WATCH_REPAIR_NOT_FOUND'};
      if(data.reviewedRevision!==74)return {ok:false,error:'ProgRSS changed while this repair was being reviewed.',code:'PAGE_WATCH_REPAIR_STALE'};
      if(!['repair-cards','repair-main'].includes(data.proposalToken))return {ok:false,error:'The page changed after review. Nothing was repaired.',code:'PAGE_WATCH_REPAIR_STALE'};
      source.mode=data.proposalToken==='repair-cards'?'cards':'region';source.selector=data.proposalToken==='repair-cards'?'article':'main';source.titleSelector=data.proposalToken==='repair-cards'?'h2':'';source.linkSelector=data.proposalToken==='repair-cards'?'a[href]':'';source.version=(source.version||1)+1;
      delete source.watchRepair;source.watchHealth={schema:'progrss.page-watch.health.v1',status:'healthy',reason:'baseline',checkedAt:new Date().toISOString(),message:'A fresh starting point was saved.',metrics:{previousEntries:0,currentEntries:data.proposalToken==='repair-cards'?3:1,matchCount:data.proposalToken==='repair-cards'?3:1}};source.lastOutcome='baseline';source.lastError='';source.lastSuccessfulAt=new Date().toISOString();
      state.pageWatchRepair={undoAvailable:true,createdAt:new Date().toISOString(),expiresAt:new Date(Date.now()+30*60*1000).toISOString(),sourceId:source.id,sourceTitle:source.title};
      broadcast({kind:'page-watch-repair',sourceId:source.id});
      return {ok:true,result:{sourceId:source.id,title:source.title,mode:source.mode,baseline:true,added:0,undoAvailable:true,undoUntil:state.pageWatchRepair.expiresAt}};
    }
    if (message.type === 'undo-page-watch-repair') {
      const source=state.sources.find(row=>row.id==='watch-repair');
      if(!state.pageWatchRepair?.undoAvailable||!source)return {ok:false,error:'The page-watch repair undo has expired.',code:'PAGE_WATCH_REPAIR_UNDO_EXPIRED'};
      source.mode='cards';source.selector='.old-list';source.titleSelector='h2';source.linkSelector='a[href]';source.watchRepair={schema:'progrss.page-watch.repair.v1',reason:'no-match',noticedAt:'2026-10-17T23:00:00Z',message:'ProgRSS can no longer find the watched section. It stopped before creating misleading alerts.'};source.lastOutcome='watch-repair';source.lastError=source.watchRepair.message;
      state.pageWatchRepair={undoAvailable:false};broadcast({kind:'page-watch-repair-undo',sourceId:source.id});return {ok:true,result:{sourceId:source.id,sourceTitle:source.title}};
    }
    if (message.type === 'discover-active') {const sourceList={kind:'shared-folder',url:'https://example.test/community.json',title:'Community sources source list for ProgRSS',mime:'application/vnd.progrss.shared-folder+json',origin:'html-head'};const recentUpdates={kind:'feed',url:'https://example.test/recent-updates.json',title:'Community sources recent updates',mime:'application/feed+json',existingSource:null};return {ok:true,result:{page:{url:'https://example.test/',title:'Example Garden'},candidates:[{url:'https://example.test/feed.xml',title:'Garden feed',existingSource:{id:'feed-one',title:'Garden Notes',url:'https://example.test/feed.xml',enabled:true,archived:false,match:'advertised-address'}},{url:'https://preview.example.test/feed.xml',title:'Community events',existingSource:null},recentUpdates],sharedFolders:[sourceList],publicationChoices:{schema:'progrss.publication-choices.v1',sourceList,recentUpdates}}};}
    if (message.type === 'preview-feed-text') {
      let feed;try{feed=JSON.parse(data.raw);}catch{return {ok:false,error:'That recent-updates artifact is not readable JSON.'};}
      const items=Array.isArray(feed.items)?feed.items:[];
      return {ok:true,result:{kind:'feed',url:data.url,feedUrl:String(feed.feed_url||''),title:String(feed.title||'Recent updates'),language:String(feed.language||''),titleLanguage:String(feed.language||''),feedType:'json',itemCount:items.length,previewFullTextCount:items.filter(row=>row.content_text).length,previewSummaryCount:items.filter(row=>row.summary).length,previewItems:items.slice(0,3).map(row=>({title:String(row.title||'Untitled update'),published:String(row.date_published||''),language:String(row.language||feed.language||''),titleLanguage:String(row.language||feed.language||'')})),edition:feed._progrss||null,existingSource:null,network:false,writes:false,handoffPreview:true}};
    }
    if (message.type === 'inspect-url' && data.url === 'https://move.example.test/old') return {ok:false,error:'This address moved.',code:'CROSS_ORIGIN_REDIRECT',detail:{from:data.url,to:'https://new.example.test/feed.xml',status:301,sourceOrigin:'https://move.example.test',destinationOrigin:'https://new.example.test',sourceHost:'move.example.test',destinationHost:'new.example.test',chain:[{from:data.url,to:'https://new.example.test/feed.xml',status:301}]}};
    if (message.type === 'inspect-url' && data.url === 'https://example.test/alternate.xml') return {ok:true,result:{kind:'feed',url:data.url,feedUrl:'https://example.test/feed.xml',title:'Garden Notes',feedType:'rss',itemCount:2,existingSource:{id:'feed-one',title:'Garden Notes',url:'https://example.test/feed.xml',enabled:true,archived:false,match:'declared-self'}}};
    if (message.type === 'inspect-url' && data.url === 'https://example.test/community.json') {const row=communitySharedFolder();return {ok:true,result:{kind:'shared-folder',requestedUrl:data.url,url:data.url,title:'Community sources',raw:row.raw,preview:row.preview,remote:row.remote}};}
    if (message.type === 'inspect-url' && data.url === 'https://example.test/recent-updates.json') return {ok:true,result:{kind:'feed',url:data.url,feedUrl:data.url,title:'Community sources · recent updates',titleLanguage:'en',language:'en',feedType:'json',itemCount:3,previewCount:3,previewFullTextCount:0,previewSummaryCount:3,previewDatedCount:2,previewItems:[{title:'Library repair workshop',published:'2026-10-18T14:00:00Z',content:'summary',titleLanguage:'en',language:'en'},{title:'Neighborhood compost day',published:'2026-10-17T09:30:00Z',content:'summary',titleLanguage:'en',language:'en'},{title:'Quiet reading hour',published:'',content:'summary',titleLanguage:'en',language:'en'}],edition:{schema:'progrss.folder-edition.v1',folder:'Community sources',curator:'Community desk',generatedAt:'2026-10-18T15:00:00Z',itemCount:3,omittedByLimit:0,folderSourceCount:2,representedSourceCount:2,manualSnapshot:true},existingSource:null}};
    if (message.type === 'inspect-url') {const events=data.url.includes('preview.example.test');return {ok:true,result:{kind:'feed',url:data.url,feedUrl:data.url,title:events?'Community Events':'Garden Notes',titleLanguage:'en',language:'en',feedType:'rss',itemCount:4,previewCount:3,previewFullTextCount:1,previewSummaryCount:1,previewDatedCount:2,previewItems:[{title:events?'Library repair workshop':'Seed library opens',published:'2026-10-18T14:00:00Z',content:'full-text',titleLanguage:'en',language:'en'},{title:events?'Neighborhood compost day':'Autumn planting guide',published:'2026-10-17T09:30:00Z',content:'summary',titleLanguage:'en',language:'en'},{title:events?'Quiet reading hour':'Winter seed exchange',published:'',content:'title-only',titleLanguage:'en',language:'en'}],existingSource:null}};}
    if (message.type === 'add-source') {
      let source=state.sources.find(row=>row.url===data.url||(data.feedUrl&&row.url===data.feedUrl));
      if(source&&!source.archivedAt)return {ok:true,result:{source,restored:false,alreadyFollowing:true,match:data.feedUrl&&source.url!==data.url?'declared-self':'address'}};
      if(source){source.archivedAt='';source.enabled=true;return {ok:true,result:{source,restored:true,alreadyFollowing:false}};}
      source={id:`added-${state.sources.length+1}`,title:data.title||'New source',type:data.type||'rss',url:data.url,declaredFeedUrl:data.feedUrl||'',enabled:true,archivedAt:'',lastOutcome:'ready',lastScan:'',lastError:''};
      state.sources.push(source);return {ok:true,result:{source,restored:false,alreadyFollowing:false}};
    }
    if (message.type === 'set-source-text-retention') {
      const source=state.sources.find(row=>row.id===data.sourceId&&!row.archivedAt);
      if(!source||source.type!=='rss')return {ok:false,error:'That feed is no longer available.',code:'SOURCE_NOT_FOUND'};
      if(data.mode==='summary')source.textRetention='summary';else delete source.textRetention;
      textRevision++;
      const eligible=state.items.filter(item=>item.sourceId===source.id&&item.readAt&&!item.starred&&item.body&&!item.bodyIsSummary);
      return {ok:true,result:{sourceId:source.id,mode:data.mode,cleanupEligible:eligible.length,cleanupBatch:eligible.length,cleanupBytes:eligible.reduce((total,item)=>total+new TextEncoder().encode(item.body).byteLength,0)}};
    }
    if (message.type === 'prune-source-text') {
      const source=state.sources.find(row=>row.id===data.sourceId&&!row.archivedAt);
      if(!source||source.textRetention!=='summary')return {ok:false,error:'Choose summaries only first.',code:'TEXT_RETENTION_FULL'};
      const selected=state.items.filter(item=>item.sourceId===source.id&&item.readAt&&!item.starred&&item.body&&!item.bodyIsSummary).slice(0,240);
      const changed=selected.map(item=>({id:item.id,body:item.body,bodyIsSummary:Boolean(item.bodyIsSummary),bodyLanguage:item.bodyLanguage||'',bodyOmitted:Boolean(item.bodyOmitted)}));
      const bytes=selected.reduce((total,item)=>total+new TextEncoder().encode(item.body).byteLength,0);
      for(const item of selected){item.body=item.summary||'';item.bodyIsSummary=true;item.bodyOmitted=true;item.bodyLanguage=item.summaryLanguage||item.language||'';}
      textRevision++;
      return {ok:true,result:{sourceId:source.id,changed,bytes,remaining:0,remainingBytes:0,expectedRevision:textRevision}};
    }
    if (message.type === 'undo-source-text-prune') {
      if(data.expectedRevision!==textRevision)return {ok:false,error:'ProgRSS changed after this cleanup. Undo was stopped so newer work would not be overwritten.',code:'STALE_TEXT_CLEANUP_UNDO'};
      for(const row of data.items||[]){const item=state.items.find(candidate=>candidate.id===row.id&&candidate.sourceId===data.sourceId);if(!item||!item.bodyOmitted)return {ok:false,error:'One of those updates changed after cleanup.',code:'STALE_TEXT_CLEANUP_UNDO'};item.body=row.body;item.bodyIsSummary=Boolean(row.bodyIsSummary);if(row.bodyOmitted)item.bodyOmitted=true;else delete item.bodyOmitted;if(row.bodyLanguage)item.bodyLanguage=row.bodyLanguage;else delete item.bodyLanguage;}
      textRevision++;
      return {ok:true,result:{sourceId:data.sourceId,restored:(data.items||[]).length}};
    }
    if (message.type === 'test-source-note-interruption') {
      broadcast({kind:'test-source-note-interruption'});return {ok:true,result:{broadcast:true}};
    }
    if (message.type === 'test-source-note-stale') {
      const folder=state.collections.find(row=>row.id===data.collectionId);
      const member=folder?.members?.find(row=>row.kind==='source'&&row.id===data.sourceId);
      if(!folder||!member)return {ok:false,error:'missing test placement'};
      member.reason='Changed in another view.';folder.version=(folder.version||1)+1;
      broadcast({kind:'test-source-note-stale'});return {ok:true,result:{folderVersion:folder.version}};
    }
    if (message.type === 'set-source-placement-reason') {
      const source=state.sources.find(row=>row.id===data.sourceId&&!row.archivedAt);
      const folder=state.collections.find(row=>row.id===data.collectionId&&row.mode==='union');
      const matches=(folder?.members||[]).filter(row=>row.kind==='source'&&row.id===data.sourceId);
      if(!source||!folder||matches.length!==1)return {ok:false,error:'That direct folder placement is no longer available.',code:'SOURCE_NOTE_PLACEMENT_NOT_AVAILABLE'};
      const currentVersion=folder.version||1;
      if(currentVersion!==data.expectedVersion)return {ok:false,error:'That folder changed in another view. Its newer reason was kept.',code:'STALE_SOURCE_NOTE'};
      let current,next,expected;
      try{current=Object.hasOwn(matches[0],'reason')?normalizeSourceNoteReason(matches[0].reason):null;expected=normalizeSourceNoteReason(data.expectedReason);next=normalizeSourceNoteReason(data.reason);}catch(error){return {ok:false,error:'Keep this reason to 280 Unicode characters or fewer.',code:'INVALID_SOURCE_NOTE'};}
      if(current!==expected)return {ok:false,error:'That reason changed in another view. Its newer wording was kept.',code:'STALE_SOURCE_NOTE'};
      if(current===next)return {ok:true,result:{changed:false,sourceId:source.id,collectionId:folder.id,folderPath:folder.id==='folder-practical'?'Reading › Practical':folder.title,folderVersion:currentVersion,previousReason:current,reason:current,cleared:current===null}};
      if(next===null)delete matches[0].reason;else matches[0].reason=next;
      folder.version=currentVersion+1;
      broadcast({kind:next===null?'source-note-clear':'source-note-set',sourceId:source.id,collectionId:folder.id});
      return {ok:true,result:{changed:true,sourceId:source.id,collectionId:folder.id,folderPath:folder.id==='folder-practical'?'Reading › Practical':folder.title,folderVersion:folder.version,previousReason:current,reason:next,cleared:next===null}};
    }
    if (message.type === 'undo-source-placement-reason') {
      const folder=state.collections.find(row=>row.id===data.collectionId&&row.mode==='union');
      const matches=(folder?.members||[]).filter(row=>row.kind==='source'&&row.id===data.sourceId);
      if(!folder||matches.length!==1||(folder.version||1)!==data.expectedVersion)return {ok:false,error:'That folder changed after this edit. Undo was stopped so newer wording would not be overwritten.',code:'STALE_SOURCE_NOTE_UNDO'};
      let current,expected,previous;
      try{current=Object.hasOwn(matches[0],'reason')?normalizeSourceNoteReason(matches[0].reason):null;expected=normalizeSourceNoteReason(data.expectedCurrentReason);previous=normalizeSourceNoteReason(data.previousReason);}catch(error){return {ok:false,error:'The Source Note undo is invalid.',code:'INVALID_SOURCE_NOTE_UNDO'};}
      if(current!==expected)return {ok:false,error:'That reason changed after this edit. Undo was stopped so the newer wording would be kept.',code:'STALE_SOURCE_NOTE_UNDO'};
      if(previous===null)delete matches[0].reason;else matches[0].reason=previous;
      folder.version=(folder.version||1)+1;broadcast({kind:'source-note-undo',sourceId:data.sourceId,collectionId:folder.id});
      return {ok:true,result:{restored:true,sourceId:data.sourceId,collectionId:folder.id,folderPath:folder.id==='folder-practical'?'Reading › Practical':folder.title,folderVersion:folder.version,reason:previous}};
    }
    if (message.type === 'add-source-to-folder') {
      const source=state.sources.find(row=>row.id===data.sourceId&&!row.archivedAt);
      const folder=state.collections.find(row=>row.id===data.collectionId&&row.mode==='union');
      if(!source||!folder)return {ok:false,error:'That source or folder changed.',code:'FOLDER_NOT_AVAILABLE'};
      const direct=(folder.members||[]).some(row=>row.kind==='source'&&row.id===source.id);
      if(direct)return {ok:true,result:{added:false,reason:'direct',sourceId:source.id,collectionId:folder.id,folderPath:folder.title,membership:{direct:[{id:folder.id,path:folder.title}],inherited:[]}}};
      folder.members.push({kind:'source',id:source.id});folder.version=(folder.version||1)+1;
      const folderPath=folder.id==='folder-practical'?'Reading › Practical':folder.title;
      const inherited=folder.id==='folder-practical'?[{id:'folder-reading',path:'Reading'}]:[];
      return {ok:true,result:{added:true,sourceId:source.id,collectionId:folder.id,folderPath,folderVersion:folder.version,membership:{direct:[{id:folder.id,path:folderPath}],inherited}}};
    }
    if (message.type === 'undo-source-folder-add') {
      const folder=state.collections.find(row=>row.id===data.collectionId);
      if(!folder||(folder.version||1)!==data.expectedVersion)return {ok:false,error:'That folder changed in another view. Its newer organization was kept.',code:'STALE_FOLDER_UNDO'};
      folder.members=folder.members.filter(row=>!(row.kind==='source'&&row.id===data.sourceId));folder.version=(folder.version||1)+1;
      return {ok:true,result:{removed:true,sourceId:data.sourceId,collectionId:data.collectionId,folderPath:folder.title,membership:{direct:[],inherited:[]}}};
    }
    if (message.type === 'remove-source-from-folder') {
      const folder=state.collections.find(row=>row.id===data.collectionId);
      if(!folder)return {ok:false,error:'That folder is no longer available.',code:'FOLDER_NOT_AVAILABLE'};
      const currentVersion=Math.max(1,Math.round(Number(folder.version)||1));
      if(!Number.isInteger(data.expectedVersion)||data.expectedVersion!==currentVersion||!Object.hasOwn(data,'expectedReason'))return {ok:false,error:'That folder changed in another view. Its newer relationship was kept.',code:'STALE_FOLDER_REMOVE'};
      if(currentVersion===10000&&data.expectedRevision!==state.revision)return {ok:false,error:'ProgRSS changed after this folder relationship was reviewed. Its newer relationship was kept.',code:'STALE_FOLDER_REMOVE'};
      const matches=(folder.members||[]).map((member,index)=>({member,index})).filter(row=>row.member?.kind==='source'&&row.member.id===data.sourceId);
      if(matches.length!==1)return {ok:false,error:'That direct folder relationship changed in another view. Its newer organization was kept.',code:'STALE_FOLDER_REMOVE'};
      let current,expected;
      try{current=Object.hasOwn(matches[0].member,'reason')?normalizeSourceNoteReason(matches[0].member.reason):null;expected=normalizeSourceNoteReason(data.expectedReason);}catch(error){return {ok:false,error:'Keep this reason to 280 Unicode characters or fewer.',code:'INVALID_SOURCE_NOTE'};}
      if(current!==expected)return {ok:false,error:'That folder relationship received newer wording in another view. It was kept.',code:'STALE_FOLDER_REMOVE'};
      const removedIndex=matches[0].index;
      const removedMember=structuredClone(matches[0].member);
      folder.members.splice(removedIndex,1);folder.version=Math.min(10000,currentVersion+1);
      state.revision=(state.revision||0)+1;
      return {ok:true,result:{removed:true,sourceId:data.sourceId,collectionId:folder.id,folderPath:folder.id==='folder-practical'?'Reading › Practical':folder.title,folderVersion:folder.version,removedMember,removedIndex,expectedRevision:state.revision,membership:{direct:[],inherited:[]}}};
    }
    if (message.type === 'undo-source-folder-remove') {
      const folder=state.collections.find(row=>row.id===data.collectionId);
      if(!folder||(folder.version||1)!==data.expectedVersion)return {ok:false,error:'That folder changed in another view. Its newer organization was kept.',code:'STALE_FOLDER_UNDO'};
      if(folder.members.some(row=>row.kind==='source'&&row.id===data.sourceId))return {ok:false,error:'That source’s folder relationship changed in another view. Its newer organization was kept.',code:'STALE_FOLDER_UNDO'};
      if(!data.removedMember||data.removedMember.kind!=='source'||data.removedMember.id!==data.sourceId||!Number.isSafeInteger(data.removedIndex)||data.removedIndex<0||data.removedIndex>folder.members.length)return {ok:false,error:'The removed folder relationship is incomplete.',code:'INVALID_FOLDER_UNDO'};
      folder.members.splice(data.removedIndex,0,structuredClone(data.removedMember));folder.version=(folder.version||1)+1;
      return {ok:true,result:{added:true,sourceId:data.sourceId,collectionId:data.collectionId,folderPath:folder.id==='folder-practical'?'Reading › Practical':folder.title,membership:{direct:[{id:folder.id,path:folder.title}],inherited:folder.id==='folder-practical'?[{id:'folder-reading',path:'Reading'}]:[]}}};
    }
    if (message.type === 'seed-source-repair') {
      if(!repairFixturePrevious) repairFixturePrevious=structuredClone(state);
      if(!state.sources.some(row=>row.id==='repair-main')){
        state.sources.push(
          {id:'repair-main',title:'Field Notes',type:'rss',url:'https://notes.example.test/feed.xml',declaredFeedUrl:'https://notes.example.test/feed.xml',enabled:true,archivedAt:'',createdAt:'2026-10-14T08:00:00Z',lastOutcome:'changed',lastItems:1,lastScan:'2026-10-18T05:40:00Z',lastSuccessfulAt:'2026-10-18T05:40:00Z',lastNewAt:'2026-10-18T05:40:00Z',lastError:'',lastProblemAt:'2026-10-10T08:00:00Z',lastProblem:'Temporary HTTP 503',httpCache:{etag:'"field-v3"'},pulse:{nextAt:'2026-10-18T08:00:00Z'}},
          {id:'repair-copy',title:'Field Notes (old copy)',type:'rss',url:'https://notes.example.test/old.xml',declaredFeedUrl:'https://notes.example.test/feed.xml',enabled:false,archivedAt:'',createdAt:'2026-10-13T08:00:00Z',lastOutcome:'unchanged',lastItems:1,lastScan:'2026-10-17T05:40:00Z',lastSuccessfulAt:'2026-10-17T05:40:00Z',lastNewAt:'2026-10-16T05:40:00Z',lastError:'',lastProblemAt:'',lastProblem:'',httpCache:{lastModified:'Fri, 17 Oct 2026 05:40:00 GMT'},pulse:{nextAt:'2026-10-19T08:00:00Z'}}
        );
        state.items.push(
          {id:'repair-main|shared',entryKey:'repair-main|shared',feedRevision:0,sourceId:'repair-main',title:'A shared field report',url:'https://notes.example.test/posts/shared',summary:'The same update appeared in both local histories.',published:'2026-10-18T05:00:00Z',observedAt:'2026-10-18T05:01:00Z',kind:'new',readAt:'',starred:true},
          {id:'repair-copy|shared',entryKey:'repair-copy|shared',feedRevision:0,sourceId:'repair-copy',title:'A shared field report',url:'https://notes.example.test/posts/shared',summary:'The same update appeared in both local histories.',published:'2026-10-18T05:00:00Z',observedAt:'2026-10-18T05:02:00Z',kind:'new',readAt:'2026-10-18T05:30:00Z',starred:false},
          {id:'repair-copy|older',entryKey:'repair-copy|older',feedRevision:0,sourceId:'repair-copy',title:'An older note worth keeping',url:'https://notes.example.test/posts/older',summary:'Only the older copy retained this update.',published:'2026-10-15T05:00:00Z',observedAt:'2026-10-15T05:01:00Z',kind:'new',readAt:'2026-10-15T06:00:00Z',starred:true}
        );
        state.collections.push({id:'folder-field',title:'Field work',mode:'union',version:1,members:[{kind:'source',id:'repair-main'},{kind:'source',id:'repair-copy'}]});
        state.sourceRepair={undoAvailable:false};
      }
      repairBlocked=true;repairReasonConflict=false;activeGraftReceipt=true;retiredEvidence=[];receiptRetirementUndo={undoAvailable:false};repairRevision++;
      broadcast({kind:'seed-source-repair'});
      return {ok:true,result:{}};
    }
    if (message.type === 'clear-source-repair-fixture') {
      if(repairFixturePrevious) state=repairFixturePrevious;
      repairFixturePrevious=null;repairUndoPrevious=null;repairBlocked=false;repairReasonConflict=false;activeGraftReceipt=true;retiredEvidence=[];receiptRetirementUndo={undoAvailable:false};repairRevision++;
      broadcast({kind:'clear-source-repair-fixture'});
      return {ok:true,result:{}};
    }
    if (message.type === 'unblock-source-repair') {
      repairBlocked=false;activeGraftReceipt=false;repairRevision++;broadcast({kind:'unblock-source-repair'});return {ok:true,result:{}};
    }
    if (message.type === 'seed-source-repair-reason-conflict') {
      const folder=state.collections.find(row=>row.id==='folder-field');
      const first=folder?.members?.find(row=>row.kind==='source'&&row.id==='repair-main');
      const second=folder?.members?.find(row=>row.kind==='source'&&row.id==='repair-copy');
      if(first)first.reason='Useful for current field reports.';
      if(second)second.reason='Preserves the older archive route.';
      repairReasonConflict=true;repairRevision++;broadcast({kind:'source-repair-reason-conflict'});return {ok:true,result:{}};
    }
    if (message.type === 'resolve-source-repair-reason-conflict') {
      const folder=state.collections.find(row=>row.id==='folder-field');
      const second=folder?.members?.find(row=>row.kind==='source'&&row.id==='repair-copy');
      if(second)delete second.reason;
      repairReasonConflict=false;repairRevision++;broadcast({kind:'source-repair-reason-resolved'});return {ok:true,result:{}};
    }
    if (message.type === 'preview-graft-receipt-retirement') {
      if(!activeGraftReceipt)return {ok:false,error:'That receipt is no longer in active history.',code:'RECEIPT_NOT_FOUND'};
      return {ok:true,result:{schema:'progrss.graft-receipt.retirement.preview.v1',canRetire:true,reviewedRevision:repairRevision,sources:[{id:'repair-main',title:'Field Notes',url:'https://notes.example.test/feed.xml'},{id:'repair-copy',title:'Field Notes (old copy)',url:'https://notes.example.test/old.xml'}],sharedAddresses:['https://notes.example.test/feed.xml'],receipt:{index:0,recordId:'graft-receipt',title:'Reviewed garden graft',schema:'progrss.recipe.graft.receipt.v1',digest:'6b35b7ec8eeb263a957dd6d37e6cd32c41962b147b51a55b9b7e04b4fce5c25f',referenceCount:2,sourceReferenceCount:1,updateReferenceCount:1,references:sourceReferenceReport().groups[0].records[0].references},effects:['The exact receipt is removed from active Workbench receipts.','An unchanged copy, its canonical SHA-256 digest, and its retirement time are preserved in the private library.','No source, retained update, permission, validator, schedule, or trust binding is changed.','The same-source repair is still a separate review and does not run automatically.'],warnings:[],retiredReceiptCount:retiredEvidence.length,retiredReceiptLimit:64,undoMinutes:30,network:false,permissionRequest:false}};
    }
    if (message.type === 'retire-graft-receipt') {
      if(data.reviewedRevision!==repairRevision)return {ok:false,error:'ProgRSS changed while this retirement was being reviewed.',code:'RECEIPT_REVIEW_STALE'};
      if(!activeGraftReceipt)return {ok:false,error:'That receipt is no longer in active history.',code:'RECEIPT_NOT_FOUND'};
      activeGraftReceipt=false;repairBlocked=false;repairRevision++;
      const retiredAt=new Date().toISOString();
      retiredEvidence=[{index:0,retirementId:'retired-graft-smoke',retiredAt,originalDigest:data.expectedDigest,originalRecordId:'graft-receipt',originalTitle:'Reviewed garden graft',referenceCount:2,pathsTruncated:false,scanExceeded:false,references:[{kind:'source',targetId:'repair-copy',sourceId:'repair-copy',sourceTitle:'Field Notes (old copy)',label:'Source history',referenceCount:1,paths:['$["sourceId"]']},{kind:'update',targetId:'repair-main|shared',sourceId:'repair-main',sourceTitle:'Field Notes',label:'A shared field report',referenceCount:1,paths:['$["evidence"]["itemId"]']}]}];
      receiptRetirementUndo={undoAvailable:true,createdAt:retiredAt,expiresAt:new Date(Date.now()+30*60*1000).toISOString(),retirementId:'retired-graft-smoke',receiptTitle:'Reviewed garden graft',receiptId:'graft-receipt'};
      broadcast({kind:'graft-receipt-retired'});
      return {ok:true,result:{retirementId:'retired-graft-smoke',receiptId:'graft-receipt',receiptTitle:'Reviewed garden graft',digest:data.expectedDigest,retiredAt,undoAvailable:true,undoUntil:receiptRetirementUndo.expiresAt,activeReceipts:0,retiredReceipts:1}};
    }
    if (message.type === 'undo-graft-receipt-retirement') {
      if(!receiptRetirementUndo.undoAvailable)return {ok:false,error:'The receipt-retirement undo has expired or newer work has been saved.',code:'RECEIPT_UNDO_STALE'};
      activeGraftReceipt=true;repairBlocked=true;retiredEvidence=[];receiptRetirementUndo={undoAvailable:false};repairRevision++;broadcast({kind:'graft-receipt-retirement-undone'});return {ok:true,result:{restored:true,receiptId:'graft-receipt',receiptTitle:'Reviewed garden graft'}};
    }
    if (message.type === 'source-repair-references') return {ok:true,result:sourceReferenceReport(data.firstSourceId,data.secondSourceId)};
    if (message.type === 'preview-source-repair') {
      const first=state.sources.find(row=>row.id===data.firstSourceId),second=state.sources.find(row=>row.id===data.secondSourceId);
      if(!first||!second)return {ok:false,error:'Choose two different sources that are still in this library.',code:'SOURCE_REPAIR_NOT_FOUND'};
      const aliases=source=>new Set([source.url,source.declaredFeedUrl,...(source.previousUrls||[]),...(source.aliasUrls||[])].filter(Boolean));
      const secondAliases=aliases(second);const shared=[...aliases(first)].filter(value=>secondAliases.has(value));
      if(!shared.length)return {ok:false,error:'These sources no longer share a reviewed address.',code:'SOURCE_REPAIR_NO_EVIDENCE'};
      const summary=source=>{
        const items=state.items.filter(item=>item.sourceId===source.id);
        const direct=state.collections.filter(folder=>(folder.members||[]).some(member=>member.kind==='source'&&member.id===source.id)).map(folder=>({id:folder.id,path:folder.title}));
        return {id:source.id,title:source.title,url:source.url,status:source.enabled?'Following':'Paused',enabled:Boolean(source.enabled),permissionGranted:true,pendingMove:false,items:{items:items.length,unread:items.filter(item=>!item.readAt).length,saved:items.filter(item=>item.starred).length,newestAt:items.map(item=>item.observedAt||item.published||'').sort().at(-1)||''},folders:{direct,inherited:[]},activity:{successfulAt:source.lastSuccessfulAt||'',newAt:source.lastNewAt||'',problemAt:source.lastProblemAt||'',problem:source.lastProblem||''},validators:{etag:Boolean(source.httpCache?.etag),lastModified:Boolean(source.httpCache?.lastModified)},nextAt:source.pulse?.nextAt||'',aliasCount:aliases(source).size};
      };
      const outcome=survivor=>({survivorId:survivor.id,retainedItems:2,exactRepeatsCollapsed:1,identities:2,unread:1,saved:2,directFolders:[{id:'folder-field',path:'Field work'}],inheritedFolders:[],collectionsUpdated:1});
      const report=sourceReferenceReport(first.id,second.id);
      const placementConflicts=repairReasonConflict?[{kind:'divergent-reasons',folderId:'folder-field',folderTitle:'Field work',folderPath:'Field work',firstSourceId:'repair-main',secondSourceId:'repair-copy',firstReason:'Useful for current field reports.',secondReason:'Preserves the older archive route.'}]:[];
      const blockers=[];
      if(repairReasonConflict)blockers.push('1 direct folder placement in Field work has incompatible Source Notes. Edit or clear one reason before combining these histories; ProgRSS will not choose a reason automatically.');
      if(repairBlocked)blockers.push('Advanced Workbench records refer to one of these source histories. Open References to these histories to see each blocking record before deciding what to keep or remove.');
      return {ok:true,result:{schema:'progrss.source-repair.preview.v1',canRepair:!repairBlocked&&!repairReasonConflict,reviewedRevision:repairRevision,sharedAddresses:shared,sources:[summary(first),summary(second)],outcomes:repairReasonConflict?[]:[outcome(first),outcome(second)],blockers,placementConflicts,advancedReferences:repairBlocked?[{key:'receipts',count:2}]:[],referenceReport:repairBlocked?report:{...report,summary:{...report.summary,blockingGroups:0,blockingRecords:0,exactReferences:0,sourceHistoryReferences:0,retainedUpdateReferences:0},groups:[],canRepair:true},scanExceeded:false,warnings:['Only the selected survivor keeps its cached HTTP validators. Validators from the other address are discarded.'],undoMinutes:30}};
    }
    if (message.type === 'repair-same-source') {
      if(repairReasonConflict)return {ok:false,error:'Different folder reasons need a decision first.',code:'SOURCE_REPAIR_REASON_CONFLICT'};
      if(data.reviewedRevision!==repairRevision)return {ok:false,error:'ProgRSS changed while this repair was being reviewed.',code:'SOURCE_REPAIR_STALE'};
      const survivor=state.sources.find(row=>row.id===data.survivorId);
      const otherId=data.survivorId===data.firstSourceId?data.secondSourceId:data.firstSourceId;
      const other=state.sources.find(row=>row.id===otherId);
      if(!survivor||!other)return {ok:false,error:'One of these sources changed.',code:'SOURCE_REPAIR_STALE'};
      repairUndoPrevious=structuredClone(state);
      const affected=state.items.filter(item=>item.sourceId===survivor.id||item.sourceId===other.id);
      const untouched=state.items.filter(item=>item.sourceId!==survivor.id&&item.sourceId!==other.id);
      const groups=new Map();
      for(const item of affected){const prefix=item.sourceId+'|';let tail=(item.entryKey||item.id||'').replace(prefix,'').replace(/\|edit:\d+$/,'');if(!groups.has(tail))groups.set(tail,[]);groups.get(tail).push(item);}
      const merged=[];let collapsed=0;
      for(const [tail,rows] of groups){
        const content=new Map();
        for(const row of rows){const key=JSON.stringify([row.title||'',row.summary||'',row.url||'',row.published||'']);if(!content.has(key))content.set(key,[]);content.get(key).push(row);}
        collapsed+=rows.length-content.size;let revision=0;
        for(const matches of content.values()){
          const row=structuredClone(matches.at(-1));row.sourceId=survivor.id;row.entryKey=`${survivor.id}|${tail}`;row.id=revision?`${row.entryKey}|edit:${revision}`:row.entryKey;row.feedRevision=revision;row.kind=revision?'changed':'new';row.readAt=matches.some(item=>!item.readAt)?'':(matches.map(item=>item.readAt).filter(Boolean).sort()[0]||'');row.starred=matches.some(item=>item.starred);merged.push(row);revision++;
        }
      }
      state.items=[...untouched,...merged];
      for(const folder of state.collections){const seen=new Set();folder.members=(folder.members||[]).map(member=>member.kind==='source'&&member.id===other.id?{...member,id:survivor.id}:member).filter(member=>{const key=`${member.kind}:${member.id}`;if(seen.has(key))return false;seen.add(key);return true;});}
      survivor.aliasUrls=[...(survivor.aliasUrls||[]),other.url].filter((value,index,array)=>array.indexOf(value)===index);
      state.sources=state.sources.filter(row=>row.id!==other.id);
      const expiresAt=new Date(Date.now()+30*60*1000).toISOString();
      state.sourceRepair={undoAvailable:true,createdAt:new Date().toISOString(),expiresAt,survivorId:survivor.id,survivorTitle:survivor.title,otherTitle:other.title};
      repairRevision++;
      return {ok:true,result:{survivorId:survivor.id,survivorTitle:survivor.title,removedSourceId:other.id,removedSourceTitle:other.title,itemMerge:{afterCount:merged.length,exactRepeatsCollapsed:collapsed,unread:merged.filter(item=>!item.readAt).length,saved:merged.filter(item=>item.starred).length},changedCollections:1,undoAvailable:true,undoUntil:expiresAt}};
    }
    if (message.type === 'undo-source-repair') {
      if(!repairUndoPrevious)return {ok:false,error:'The same-source repair undo has expired.',code:'SOURCE_REPAIR_UNDO_EXPIRED'};
      state=repairUndoPrevious;state.sourceRepair={undoAvailable:false};repairUndoPrevious=null;repairRevision++;
      return {ok:true,result:{restoredSources:2}};
    }
    if (message.type === 'preview-opml') return {ok:true,result:{
      schema:'progrss.opml.preview.v1',title:'Reading list',feedOutlines:6,uniqueFeeds:5,newCount:3,
      existingCount:1,duplicateInFileCount:1,invalidCount:1,truncatedCount:0,folderCount:2,
      originCount:3,origins:['https://one.test','https://two.test','https://three.test'],canImport:true,reason:'',network:false,
      sample:[{title:'One',url:'https://one.test/feed.xml'}]
    }};
    if (message.type === 'import-opml') {
      const rows=[
        {id:'opml-one',title:'Independent One',type:'rss',url:'https://one.test/feed.xml',enabled:!data.paused,archivedAt:'',origin:'opml-import',lastScan:'',lastError:''},
        {id:'opml-two',title:'Independent Two',type:'rss',url:'https://two.test/feed.xml',enabled:!data.paused,archivedAt:'',origin:'opml-import',lastScan:'',lastError:''},
        {id:'opml-three',title:'Independent Three',type:'rss',url:'https://three.test/feed.xml',enabled:!data.paused,archivedAt:'',origin:'opml-import',lastScan:'',lastError:''}
      ];
      state.sources.push(...rows);
      return {ok:true,result:{added:3,paused:Boolean(data.paused),foldersAdded:2,existingSkipped:1,duplicateInFileCount:1,invalidCount:1,sourceIds:rows.map(row=>row.id)}};
    }
    if (message.type === 'get-sharing-identity') return {ok:true,result:structuredClone(sharingIdentity)};
    if (message.type === 'create-sharing-identity') {
      sharingIdentity={algorithm:'Ed25519',publicKey:'smoke-public-key',keyId:`ed25519:${'a'.repeat(64)}`,createdAt:'2026-10-18T22:00:00Z'};
      return {ok:true,result:structuredClone(sharingIdentity)};
    }
    if (message.type === 'export-shared-folder') {
      const curator=String(data.options?.curator||'').slice(0,80);const note=String(data.options?.note||'').slice(0,280);const updateUrl=String(data.options?.updateUrl||'').slice(0,2048);const signed=Boolean(data.options?.sign&&sharingIdentity);
      const document={schema:updateUrl?'progrss.bundle.v3':'progrss.bundle.v2',exportedAt:'2026-10-18T22:01:00Z',root:'folder-practical',title:'Reading › Practical',publication:{schema:'progrss.shared-folder.publication.v1',id:'smoke-publication',curator,note,issuedAt:'2026-10-18T22:01:00Z'},integrity:{schema:'progrss.shared-folder.integrity.v1',digest:`sha256:${'b'.repeat(64)}`},sources:[{kind:'feed',id:'feed-two',title:'سجل الورشة',url:'https://workshop.test/atom.xml'}],collections:[{id:'folder-practical',title:'Practical',mode:'union',members:[{kind:'source',id:'feed-two'}]}]};
      if(updateUrl)document.distribution={schema:'progrss.shared-folder.distribution.v1',updateUrl};
      if(signed)document.integrity.signature={schema:'progrss.shared-folder.signature.v1',algorithm:'Ed25519',publicKey:sharingIdentity.publicKey,keyId:sharingIdentity.keyId,value:'smoke-signature'};
      lastSharedFolderRaw=JSON.stringify(document,null,2);
      return {ok:true,result:{fileName:'ProgRSS-Reading-Practical.json',raw:lastSharedFolderRaw,mime:'application/json',summary:{feeds:1,pageWatches:0,folders:1,curator,signed,updateUrl,manualUpdateCheck:Boolean(updateUrl),fingerprint:signed?'ed25519:aaaaaaaaaaaa…aaaaaaaa':''}}};
    }
    if (message.type === 'export-folder-edition') {
      const built=globalThis.ProgRSSCore.makeFolderEdition(state,data.collectionId,{title:'Reading › Practical',curator:String(data.options?.curator||''),note:String(data.options?.note||''),limit:100,generatedAt:'2026-10-19T01:00:00Z'});
      const raw=JSON.stringify(built.document,null,2);
      return {ok:true,result:{fileName:'ProgRSS-Reading-Practical-2026-10-19-updates.json',raw,mime:'application/feed+json',summary:built.summary}};
    }
    if (message.type === 'export-publication-site') {
      const curator=String(data.options?.curator||'').slice(0,80);const note=String(data.options?.note||'').slice(0,280);const updateUrl=String(data.options?.updateUrl||'').slice(0,2048);const signed=Boolean(data.options?.sign&&sharingIdentity);const exportedAt='2026-10-19T01:00:00Z';
      const document={schema:'progrss.bundle.v3',exportedAt,root:'folder-practical',title:'Reading › Practical',publication:{schema:'progrss.shared-folder.publication.v1',id:'smoke-publication',curator,note,issuedAt:exportedAt},distribution:{schema:'progrss.shared-folder.distribution.v1',updateUrl},integrity:{schema:'progrss.shared-folder.integrity.v1',digest:`sha256:${'b'.repeat(64)}`},sources:[{kind:'feed',id:'feed-two',title:'سجل الورشة',url:'https://workshop.test/atom.xml'}],collections:[{id:'folder-practical',title:'Practical',mode:'union',members:[{kind:'source',id:'feed-two',reason:'Useful for repair-café workshop notices.'}]}]};
      if(signed)document.integrity.signature={schema:'progrss.shared-folder.signature.v1',algorithm:'Ed25519',publicKey:sharingIdentity.publicKey,keyId:sharingIdentity.keyId,value:'smoke-signature'};
      const bundleRaw=JSON.stringify(document,null,2);lastSharedFolderRaw=bundleRaw;
      let edition=null;
      if(data.options?.includeUpdates){const built=globalThis.ProgRSSCore.makeFolderEdition(state,data.collectionId,{title:'Reading › Practical',curator,note,limit:100,generatedAt:exportedAt});edition={fileName:'ProgRSS-Reading-Practical-2026-10-19-updates.json',raw:JSON.stringify(built.document,null,2),mime:'application/feed+json',summary:built.summary};}
      return {ok:true,result:{bundle:{fileName:'ProgRSS-Reading-Practical.json',raw:bundleRaw,mime:'application/json',summary:{feeds:1,pageWatches:0,folders:1,curator,signed,updateUrl,fingerprint:signed?'ed25519:aaaaaaaaaaaa…aaaaaaaa':''}},edition,summary:{includeUpdates:Boolean(edition),updates:edition?.summary?.items||0,reviewedRevision:74,network:false,writes:false}}};
    }
    if (message.type === 'check-shared-folder-update') {
      const folder=state.collections.find(row=>row.id===data.collectionId);
      const updateUrl=String(folder?.sharedFolderOrigin?.updateUrl||'');
      if(!updateUrl)return {ok:false,code:'SHARED_FOLDER_UPDATE_ADDRESS_MISSING',error:'This folder has no future-copy address.'};
      const raw=JSON.stringify({schema:'progrss.bundle.v3',exportedAt:'2026-10-18T23:00:00Z',root:'remote-practical',title:'Practical',publication:{schema:'progrss.shared-folder.publication.v1',id:'smoke-publication',curator:'Neighborhood readers',note:'A small practical reading list for the repair café.',issuedAt:'2026-10-18T23:00:00Z'},distribution:{schema:'progrss.shared-folder.distribution.v1',updateUrl},integrity:{schema:'progrss.shared-folder.integrity.v1',digest:`sha256:${'c'.repeat(64)}`,signature:{schema:'progrss.shared-folder.signature.v1',algorithm:'Ed25519',publicKey:'smoke-remote-public-key',keyId:`ed25519:${'1'.repeat(64)}`,value:'smoke-remote-signature'}},sources:[{kind:'feed',id:'remote-feed-two',title:'سجل الورشة',url:'https://workshop.test/atom.xml'},{kind:'feed',id:'remote-feed-three',title:'Repair café bulletin',url:'https://bulletin.test/feed.xml'}],collections:[{id:'remote-practical',title:'Practical',mode:'union',members:[{kind:'source',id:'remote-feed-two'},{kind:'source',id:'remote-feed-three'}]}]},null,2);
      const preview={schema:'progrss.shared-folder-update.preview.v1',mode:'update',title:'Practical',localTitle:'Practical',targetRootId:'folder-practical',publicationId:'smoke-publication',feedCount:2,pageWatchCount:0,folders:1,curator:'Neighborhood readers',note:'A small practical reading list for the repair café.',updateUrl,signatureState:'verified',algorithm:'Ed25519',keyId:`ed25519:${'1'.repeat(64)}`,fingerprint:'ed25519:111111111111…11111111',previous:{signatureState:'verified',algorithm:'Ed25519',keyId:`ed25519:${'1'.repeat(64)}`,fingerprint:'ed25519:111111111111…11111111'},trust:{state:'same-key',requiresAcknowledgement:false,message:'The same signing key signed this copy.'},requiresTrustAcknowledgement:false,changes:{sourcesAdded:1,sourcesRemoved:0,sourceRecipesChanged:0,sourceMetadataChanged:0,foldersAdded:0,foldersRemoved:0,foldersChanged:1,updateAddressChanged:false},localEdits:{sourceOverrides:0,folderOverrides:0,detachedFolders:0,present:false},preservation:{readingHistory:true,readAndSavedState:true,sourceActivity:true,changedRecipesStartPaused:0,localEditsKept:true},warnings:[],canUpdate:true,reason:'',reviewedRevision:74,network:true,writes:false,separate:{canImport:true,newSources:1,reusedSources:1,folders:1,startsPaused:true}};
      return {ok:true,result:{raw,preview,remote:{requestedUrl:updateUrl,finalUrl:updateUrl,status:200,contentType:'application/json; charset=utf-8',redirects:[],credentials:'omitted',automatic:false}}};
    }
    if (message.type === 'review-shared-folder-url') return {ok:true,result:communitySharedFolder(data.pageUrl)};
    if (message.type === 'preview-shared-folder') {
      let doc;try{doc=JSON.parse(data.raw);}catch{return {ok:false,error:'That shared folder is not readable JSON.'};}
      const signature=doc?.integrity?.signature;const curator=String(doc?.publication?.curator||'');const algorithm=String(signature?.algorithm||'');
      const fingerprint=signature?(algorithm==='Ed25519'?'ed25519:1a2b3c4d5e6f…7a8b9c0d':'ecdsa-p256-sha256:2b3c4d5e6f70…8b9c0d1e'):'';
      if(doc?.root==='folder-neighborhood'){
        const selected=data.selectedFolderId==='folder-meetings';
        const sources=selected?[{id:'feed-council',title:'Council agenda',type:'rss',host:'council.example',folderCount:1,folders:['Public meetings'],foldersOmitted:0,state:'new-paused'},{id:'page-notices',title:'Town notices',type:'page',host:'town.example',folderCount:1,folders:['Public meetings'],foldersOmitted:0,state:'new-paused'}]:[{id:'feed-community',title:'Community bulletin',type:'rss',host:'community.example',folderCount:1,folders:['Neighborhood signal'],foldersOmitted:0,state:'new-paused'},{id:'feed-council',title:'Council agenda',type:'rss',host:'council.example',folderCount:1,folders:['Neighborhood signal › Public meetings'],foldersOmitted:0,state:'new-paused'},{id:'page-notices',title:'Town notices',type:'page',host:'town.example',folderCount:1,folders:['Neighborhood signal › Public meetings'],foldersOmitted:0,state:'new-paused'}];
        const folders=selected?[{id:'folder-meetings',title:'Public meetings',path:'Public meetings',depth:0,isRoot:true,directSources:2,directFolders:0,branchSources:2,branchFeeds:1,branchPageWatches:1,branchFolders:1,state:'listed'}]:[{id:'folder-neighborhood',title:'Neighborhood signal',path:'Neighborhood signal',depth:0,isRoot:true,directSources:1,directFolders:1,branchSources:3,branchFeeds:2,branchPageWatches:1,branchFolders:2,state:'listed'},{id:'folder-meetings',title:'Public meetings',path:'Neighborhood signal › Public meetings',depth:1,isRoot:false,directSources:2,directFolders:0,branchSources:2,branchFeeds:1,branchPageWatches:1,branchFolders:1,state:'listed'}];
        return {ok:true,result:{schema:'progrss.shared-folder.preview.v3',mode:'new',title:selected?'Public meetings':'Neighborhood signal',sourceCount:selected?2:3,feedCount:selected?1:2,pageWatchCount:1,folders:selected?1:2,reusedSources:0,newSources:selected?2:3,duplicateRecipes:0,canImport:true,reason:'',reviewedRevision:74,curator:'Neighborhood readers',note:'A practical route for local meetings and useful notices.',publicationId:selected?'':'folder-neighborhood',parentPublicationId:selected?'folder-neighborhood':'',signatureState:'unsigned',algorithm:'',keyId:'',fingerprint:'',updateUrl:selected?'':'https://exchange.example.test/neighborhood/progrss-source-list.json',manualUpdateCheck:!selected,network:false,writes:false,selectionMode:selected?'section':'full',independentExcerpt:selected,updateLinked:!selected,selectedFolderId:selected?'folder-meetings':'',selectedFolderPath:selected?'Neighborhood signal › Public meetings':'',parentTitle:selected?'Neighborhood signal':'',fullSourceCount:3,fullFolderCount:2,availableSections:[{id:'folder-meetings',title:'Public meetings',path:'Neighborhood signal › Public meetings',sourceCount:2,feedCount:1,pageWatchCount:1,folderCount:1}],contents:{schema:'progrss.shared-folder.contents.v2',title:selected?'Public meetings':'Neighborhood signal',root:selected?'folder-meetings':'folder-neighborhood',sourceCount:sources.length,feedCount:selected?1:2,pageWatchCount:1,folderCount:folders.length,maxDepth:selected?0:1,folders,sources,network:false,writes:false}}};
      }
      if(data.selectedFolderId==='community-local'){
        return {ok:true,result:{schema:'progrss.shared-folder.preview.v3',mode:'new',title:'Local notices',feedCount:1,pageWatchCount:0,folders:1,reusedSources:0,newSources:1,canImport:true,reason:'',reviewedRevision:74,curator:'Community desk',note:'A small public reading route.',publicationId:'',parentPublicationId:'community-publication',signatureState:'unsigned',algorithm:'',keyId:'',fingerprint:'',updateUrl:'',manualUpdateCheck:false,network:false,writes:false,selectionMode:'section',independentExcerpt:true,updateLinked:false,selectedFolderId:'community-local',selectedFolderPath:'Community sources › Local notices',parentTitle:'Community sources',fullSourceCount:1,fullFolderCount:2,availableSections:[{id:'community-local',title:'Local notices',path:'Community sources › Local notices',sourceCount:1,feedCount:1,pageWatchCount:0,folderCount:1}],contents:{schema:'progrss.shared-folder.contents.v2',title:'Local notices',root:'community-local',sourceCount:1,feedCount:1,pageWatchCount:0,folderCount:1,maxDepth:0,folders:[{id:'community-local',title:'Local notices',path:'Local notices',depth:0,isRoot:true,directSources:1,directFolders:0,branchSources:1,branchFeeds:1,branchPageWatches:0,branchFolders:1,state:'listed'}],sources:[{id:'community-feed',title:'Community bulletin',type:'rss',host:'community.test',folderCount:1,folders:['Local notices'],foldersOmitted:0,state:'new-paused'}],network:false,writes:false}}};
      }
      if(doc?.publication?.id==='community-publication')return {ok:true,result:communitySharedFolder('').preview};
      if(sharedPublicationImported){
        const conflictId='source:remote-feed-two:title';
        const mergeReview={
          schema:'progrss.shared-folder-merge-review.v1',
          counts:{curatorOnly:2,recipientOnly:1,agreed:1,conflicts:1,additions:1,removals:1,recipeChanges:1},
          curatorOnly:[
            {id:'publication:note',kind:'publication',label:'Practical',field:'note',fieldLabel:'Curator note',baseline:'A small practical reading list.',local:'A small practical reading list.',incoming:'Updated sources for repair and reuse.',summary:'The curator changed the route explanation.'},
            {id:'source:remote-feed-three:author',kind:'source',label:'Repair café bulletin',field:'author',fieldLabel:'Source attribution',baseline:'Community desk',local:'Community desk',incoming:'Repair network',summary:'The curator changed the source attribution.'}
          ],
          recipientOnly:[{id:'folder:remote-practical:title',kind:'folder',label:'My practical sources',field:'title',fieldLabel:'Folder name',baseline:'Practical',local:'My practical sources',incoming:'Practical',summary:'You changed this folder name; the curator did not.'}],
          agreed:[{id:'source:remote-feed-two:author',kind:'source',label:'Workshop log',field:'author',fieldLabel:'Source attribution',baseline:'Workshop desk',local:'Repair café',incoming:'Repair café',summary:'You and the curator made the same attribution change.'}],
          conflicts:[{id:conflictId,kind:'source',label:'Workshop log',field:'title',fieldLabel:'Source name',baseline:'سجل الورشة',local:'My workshop log',incoming:'Repair workshop journal',default:'decision-required',summary:'You and the curator changed this source name differently.'}],
          additions:[{id:'source:remote-feed-three:added',kind:'source',label:'Repair café bulletin',field:'source',fieldLabel:'Source',baseline:null,local:null,incoming:{type:'rss',host:'bulletin.test'},summary:'Curator added Repair café bulletin. It starts paused.'}],
          removals:[{id:'source:old-schedule:removed',kind:'source',label:'Old repair schedule',field:'source',fieldLabel:'Source',baseline:{type:'rss',host:'old-schedule.test'},local:{type:'rss',host:'old-schedule.test'},incoming:null,summary:'Curator removed Old repair schedule from this route; local history stays.'}],
          recipeChanges:[{id:'source:remote-feed-two:recipe',kind:'source',label:'Workshop log',field:'recipe',fieldLabel:'How this source is checked',baseline:{present:true,type:'rss',host:'old-workshop.test',mode:'feed'},local:{present:true,type:'rss',host:'old-workshop.test',mode:'feed'},incoming:{present:true,type:'rss',host:'workshop.test',mode:'feed'},oldHost:'old-workshop.test',newHost:'workshop.test',reusesExisting:false,default:'new-paused',summary:'Curator changed how Workshop log is checked from old-workshop.test to workshop.test. The new recipe starts paused; earlier source history stays local.'}],
          omitted:{},requiresDecisions:true,decisionIds:[conflictId],recipeAcknowledgementRequired:true,network:false,writes:false
        };
        return {ok:true,result:{schema:'progrss.shared-folder-update.preview.v2',mode:'update',title:String(doc?.title||'Shared folder'),localTitle:'Practical',targetRootId:'folder-practical',publicationId:String(doc?.publication?.id||'root'),feedCount:1,pageWatchCount:0,folders:1,curator,note:String(doc?.publication?.note||''),signatureState:signature?'verified':'unsigned',algorithm,keyId:String(signature?.keyId||''),fingerprint,previous:{signatureState:'verified',algorithm:'Ed25519',keyId:`ed25519:${'1'.repeat(64)}`,fingerprint:'ed25519:111111111111…11111111'},trust:{state:algorithm==='Ed25519'?'same-key':'key-change',requiresAcknowledgement:algorithm!=='Ed25519',message:algorithm==='Ed25519'?'The same signing key signed this copy.':'This copy uses a different signing key. The signature is valid, but ProgRSS cannot know why the key changed.'},requiresTrustAcknowledgement:algorithm!=='Ed25519',requiresConflictChoices:true,requiresRecipeAcknowledgement:true,mergeReview,changes:{sourcesAdded:1,sourcesRemoved:1,sourceRecipesChanged:1,sourceMetadataChanged:1,foldersAdded:1,foldersRemoved:0,foldersChanged:1},localEdits:{sourceOverrides:1,folderOverrides:1,detachedFolders:0,present:true},preservation:{readingHistory:true,readAndSavedState:true,sourceActivity:true,changedRecipesStartPaused:1,localEditsKept:true},warnings:['Changed acquisition recipes become paused sources; the earlier source histories remain in the library.'],canUpdate:true,reason:'',reviewedRevision:74,network:false,writes:false,separate:{canImport:true,newSources:1,reusedSources:0,folders:1,startsPaused:true}}};
      }
      return {ok:true,result:{schema:'progrss.shared-folder.preview.v3',mode:'new',title:String(doc?.title||'Shared folder'),feedCount:1,pageWatchCount:0,folders:1,reusedSources:1,newSources:0,duplicateRecipes:0,canImport:true,reason:'',reviewedRevision:74,curator,note:String(doc?.publication?.note||''),publicationId:String(doc?.publication?.id||'legacy'),signatureState:signature?'verified':'unsigned',algorithm,keyId:String(signature?.keyId||''),fingerprint,network:false,writes:false}};
    }
    if (message.type === 'import-shared-folder') {sharedPublicationImported=true;return {ok:true,result:{rootId:'folder-practical',importedSources:0,reusedSources:1,foldersAdded:1}};}
    if (message.type === 'update-shared-folder') {
      if(!data.acknowledgeTrustChange)return {ok:false,code:'SHARED_FOLDER_TRUST_ACKNOWLEDGEMENT',error:'Review and acknowledge the signing-key change before updating.'};
      if(data.conflictChoices?.['source:remote-feed-two:title']!=='keep-local')return {ok:false,code:'SHARED_FOLDER_CONFLICT_CHOICE',error:'Choose how to resolve each wording conflict.'};
      if(data.acknowledgeRecipeChanges!==true)return {ok:false,code:'SHARED_FOLDER_RECIPE_ACKNOWLEDGEMENT',error:'Review and acknowledge acquisition changes before updating.'};
      sharedUpdateUndoPrevious=structuredClone(state);const expiresAt=new Date(Date.now()+30*60*1000).toISOString();state.sharedFolderUpdate={undoAvailable:true,createdAt:new Date().toISOString(),expiresAt,rootId:'folder-practical',title:'Practical',changes:{sourcesAdded:1,sourcesRemoved:1,sourceRecipesChanged:1,foldersAdded:1,foldersRemoved:0,foldersChanged:1}};
      return {ok:true,result:{schema:'progrss.shared-folder-update.preview.v2',updated:true,targetRootId:'folder-practical',localTitle:'Practical',title:'Practical',changes:state.sharedFolderUpdate.changes,conflictChoices:structuredClone(data.conflictChoices),recipeChangesAcknowledged:true,undoAvailable:true,undoUntil:expiresAt}};
    }
    if (message.type === 'undo-shared-folder-update') {
      if(!sharedUpdateUndoPrevious)return {ok:false,code:'SHARED_FOLDER_UPDATE_UNDO_EXPIRED',error:'The shared-folder update undo has expired.'};
      state=sharedUpdateUndoPrevious;state.sharedFolderUpdate={undoAvailable:false};sharedUpdateUndoPrevious=null;
      return {ok:true,result:{restored:true,rootId:'folder-practical',title:'Practical'}};
    }
    if (message.type === 'export-private-backup') {
      const backupState={version:17,sources:structuredClone(state.sources),collections:structuredClone(state.collections),items:structuredClone(state.items),snapshots:{},fixtures:[],inbox:[],receipts:[],subscriptions:[],publications:[],patchPins:[],keyRotations:[],recoveryPolicies:[],recoveryReceipts:[],charterHistory:[],charterClaims:[],gossipCards:[],witnessPins:[],merklePins:[],merkleReceipts:[],proofRequests:[],proofSightings:[],proofForks:[],fixturePacks:[]};
      const recovery=Boolean(data.recovery);const raw=JSON.stringify({schema:'progrss.private.v1',exportedAt:new Date().toISOString(),purpose:recovery?'recovery-copy':'library-transfer',producer:{name:'ProgRSS',version:'0.80.0',revision:'rev0080'},state:backupState},null,2);
      const preparedAt=new Date().toISOString();lastPreparedRaw=raw;
      state.backupReminder={schema:'progrss.backup-reminder.v3',visible:true,meaningful:true,status:'prepared-not-checked',disabled:false,pendingCheck:true,checkedCopyMissing:false,changedSinceChecked:true,recheckDue:false,firstMeaningfulAt:state.backupReminder?.firstMeaningfulAt||preparedAt,lastPreparedAt:preparedAt,lastPreparedRevision:74,lastCheckedAt:state.backupReminder?.lastCheckedAt||'',lastCheckedRevision:state.backupReminder?.lastCheckedRevision||0,lastSeenAt:state.backupReminder?.lastSeenAt||'',missingSince:'',snoozedUntil:'',dueAt:preparedAt,currentRevision:74,reminderDays:30,recheckDays:90,network:false,writesVault:false};
      return {ok:true,result:{fileName:recovery?'ProgRSS-recovery-smoke.json':'ProgRSS-library-smoke.json',raw,purpose:recovery?'recovery-copy':'library-transfer',summary:summarize(state),bytes:new TextEncoder().encode(raw).byteLength,backupReminder:structuredClone(state.backupReminder)}};
    }
    if (message.type === 'check-private-backup') {
      let doc;try{doc=JSON.parse(data.raw);}catch{return {ok:false,code:'INVALID_BACKUP',error:'That file is not readable JSON.'};}
      if(!doc||doc.schema!=='progrss.private.v1'||!doc.state)return {ok:false,code:'INVALID_BACKUP',error:'That is not a ProgRSS private transfer file.'};
      const currentState={version:17,sources:structuredClone(state.sources),collections:structuredClone(state.collections),items:structuredClone(state.items),snapshots:{},fixtures:[],inbox:[],receipts:[],subscriptions:[],publications:[],patchPins:[],keyRotations:[],recoveryPolicies:[],recoveryReceipts:[],charterHistory:[],charterClaims:[],gossipCards:[],witnessPins:[],merklePins:[],merkleReceipts:[],proofRequests:[],proofSightings:[],proofForks:[],fixturePacks:[]};
      const same=JSON.stringify(doc.state)===JSON.stringify(currentState);const fileSummary=summarize(doc.state);const currentSummary=summarize(currentState);
      let checkState='different';let relationship='different';
      if(same){checkState='current';relationship='current';lastCheckedRaw=data.raw;}
      else if(lastCheckedRaw&&data.raw===lastCheckedRaw){checkState='previous';relationship='last-checked';}
      else if(lastPreparedRaw&&data.raw===lastPreparedRaw){checkState='previous';relationship='last-prepared';lastCheckedRaw=data.raw;}
      if(checkState!=='different'){const seenAt=new Date().toISOString();state.backupReminder={...state.backupReminder,visible:false,status:same?'current':'changed',pendingCheck:false,checkedCopyMissing:false,changedSinceChecked:!same,recheckDue:false,lastCheckedAt:state.backupReminder?.lastCheckedAt||seenAt,lastCheckedRevision:74,lastSeenAt:seenAt,missingSince:'',dueAt:new Date(Date.now()+(same?90:30)*24*60*60*1000).toISOString()};}
      return {ok:true,result:{schema:'progrss.private-copy-check.v2',state:checkState,relationship,knownCopy:checkState!=='different',knownRevision:74,samePortableLibrary:same,exportedAt:doc.exportedAt||'',producer:doc.producer||null,file:fileSummary,current:currentSummary,countDeltas:{},changedAreas:same?[]:['updates'],backupReminder:structuredClone(state.backupReminder),network:false,writesVault:false,writesMarker:checkState!=='different'}};
    }
    if (message.type === 'mark-backup-copy-missing') {
      const now=new Date().toISOString();state.backupReminder={...state.backupReminder,visible:true,status:'copy-missing',checkedCopyMissing:true,missingSince:now,snoozedUntil:''};
      return {ok:true,result:structuredClone(state.backupReminder)};
    }
    if (message.type === 'snooze-backup-reminder') {
      state.backupReminder={...state.backupReminder,visible:false,disabled:false,snoozedUntil:new Date(Date.now()+30*24*60*60*1000).toISOString()};
      return {ok:true,result:structuredClone(state.backupReminder)};
    }
    if (message.type === 'disable-backup-reminder') {
      state.backupReminder={...state.backupReminder,visible:false,disabled:true,snoozedUntil:''};
      return {ok:true,result:structuredClone(state.backupReminder)};
    }
    if (message.type === 'enable-backup-reminder') {
      state.backupReminder={...state.backupReminder,visible:true,disabled:false,snoozedUntil:''};
      return {ok:true,result:structuredClone(state.backupReminder)};
    }
    if (message.type === 'preview-private-backup') {
      const doc=JSON.parse(data.raw);const incoming={sources:doc.state.sources||[],collections:doc.state.collections||[],items:doc.state.items||[]};
      const active=incoming.sources.filter(row=>row.enabled&&!row.archivedAt&&!row.pendingRedirect);
      const origins=new Set(active.map(row=>new URL(row.url).origin));
      const currentSummary=summarize(state);const hasCurrent=['sources','items','collections','snapshots','advancedRecords'].some(key=>Number(currentSummary[key])>0);
      return {ok:true,result:{canRestore:true,exportedAt:doc.exportedAt||'',producer:doc.producer||null,incoming:summarize(incoming),current:currentSummary,permissions:{activeOrigins:origins.size,alreadyAllowedOrigins:0,reconnectOrigins:origins.size,reconnectSources:active.length,movedSources:incoming.sources.filter(row=>row.enabled&&!row.archivedAt&&row.pendingRedirect).length,origins:[...origins].map(origin=>({origin,granted:false,sourceCount:1,reconnectSourceCount:1,movedSourceCount:0}))},warnings:[],willKeepUndo:hasCurrent,undoMinutes:30,reviewedRevision:41}};
    }
    if (message.type === 'restore-private-backup') {
      const doc=JSON.parse(data.raw);transferPrevious=structuredClone(state);const incoming=structuredClone(doc.state);
      for(const source of incoming.sources){if(source.enabled&&!source.archivedAt){source.permissionMissing=true;source.permissionMissingReason='transfer';}}
      const previousSummary=summarize(transferPrevious);
      const keepUndo=['sources','items','collections','snapshots','advancedRecords'].some(key=>Number(previousSummary[key])>0);
      state={schemaVersion:17,sources:incoming.sources,collections:incoming.collections||[],items:incoming.items||[],vault:{mode:'indexeddb',warning:''},transfer:keepUndo?{undoAvailable:true,createdAt:new Date().toISOString(),expiresAt:new Date(Date.now()+30*60*1000).toISOString(),previous:previousSummary}:{undoAvailable:false}};
      libraryRecovery=null;
      const active=state.sources.filter(row=>row.enabled&&!row.archivedAt&&!row.pendingRedirect);const origins=new Set(active.map(row=>new URL(row.url).origin));
      broadcast({kind:'private-backup-restored'});
      return {ok:true,result:{summary:summarize(state),permissions:{activeOrigins:origins.size,alreadyAllowedOrigins:0,reconnectOrigins:origins.size,reconnectSources:active.length,movedSources:state.sources.filter(row=>row.pendingRedirect).length},undoAvailable:keepUndo,undoUntil:state.transfer.expiresAt||''}};
    }
    if (message.type === 'undo-private-backup-restore') {
      if(!transferPrevious)return {ok:false,error:'The library-move undo has expired.',code:'TRANSFER_UNDO_EXPIRED'};
      state=transferPrevious;state.transfer={undoAvailable:false};transferPrevious=null;
      return {ok:true,result:{summary:summarize(state),permissions:{activeOrigins:0,alreadyAllowedOrigins:0,reconnectOrigins:0,reconnectSources:0,movedSources:0}}};
    }
    return {ok:true,result:{}};
  }
  globalThis.chrome = {
    runtime: {id:'smoke-test', getURL:path=>`chrome-extension://smoke-test/${String(path).replace(/^\//,'')}`, getManifest:()=>({version:'0.80.0'}), sendMessage: async message => { messageTypes.push(message.type); return reply(message); }, onMessage:{addListener(fn){listeners.push(fn)}}, openOptionsPage: async()=>{}},
    storage: {local:{
      get:async keys=>{const result={};for(const key of (Array.isArray(keys)?keys:[keys]))if(Object.prototype.hasOwnProperty.call(localStore,key))result[key]=structuredClone(localStore[key]);return result;},
      set:async values=>{Object.assign(localStore,structuredClone(values));},
      remove:async keys=>{for(const key of (Array.isArray(keys)?keys:[keys]))delete localStore[key];}
    }},
    permissions: {
      contains:async request=>request?.origins?.includes('http://127.0.0.1/*')?nodeHostPermission:request?.origins?.includes(capturePagePermissionPattern)?capturePagePermission:true,
      request:async request=>{permissionRequests.push(structuredClone(request));const result=permissionResults.length?permissionResults.shift():true;if(result&&request?.origins?.includes('http://127.0.0.1/*'))nodeHostPermission=true;if(result&&request?.origins?.includes(capturePagePermissionPattern))capturePagePermission=true;return result;},
      remove:async request=>{permissionRemovals.push(structuredClone(request));if(request?.origins?.includes('http://127.0.0.1/*')){const had=nodeHostPermission;nodeHostPermission=false;return had;}if(request?.origins?.includes(capturePagePermissionPattern)){const had=capturePagePermission;capturePagePermission=false;return had;}return false;}
    },
    sidePanel: {open:async()=>{}},
    tabs: {create:async options=>{globalThis.__openedTab=options;return {id:99,...options}}},
    windows: {getCurrent:async()=>({id:1})}
  };
})();
""".replace('__STATE__', json.dumps(SAMPLE_STATE)).replace('__EXCHANGE_PREVIEW__', json.dumps(EXCHANGE_PREVIEW)).replace('__EXCHANGE_SOURCE_LIST__', json.dumps(EXCHANGE_SOURCE_LIST)).replace('__EXCHANGE_RECENT_UPDATES__', json.dumps(EXCHANGE_RECENT_UPDATES))

OPML_SAMPLE = (ROOT / 'fixtures' / 'sample-subscriptions.opml').read_bytes()

TRANSFER_SAMPLE = json.dumps({
    "schema": "progrss.private.v1",
    "exportedAt": "2026-10-18T05:20:00Z",
    "producer": {"name": "ProgRSS", "version": "0.80.0", "revision": "rev0080"},
    "state": {
        "version": 13,
        "sources": [
            {"id": "moved-reading", "title": "Moved Reading", "type": "rss", "url": "https://arrival.test/feed.xml", "enabled": True, "archivedAt": ""},
            {"id": "moved-paused", "title": "Someday Reading", "type": "rss", "url": "https://later.test/feed.xml", "enabled": False, "archivedAt": ""},
        ],
        "collections": [{"id": "arrival-folder", "title": "From laptop", "mode": "union", "members": [{"kind": "source", "id": "moved-reading"}]}],
        "items": [{"id": "moved-reading|one", "sourceId": "moved-reading", "title": "A carried update", "url": "https://arrival.test/one", "summary": "Private reading text", "observedAt": "2026-10-18T05:00:00Z", "readAt": "", "starred": True}],
        "snapshots": {}, "fixtures": [], "inbox": [], "receipts": [], "subscriptions": [], "publications": [], "patchPins": [], "keyRotations": [], "recoveryPolicies": [], "recoveryReceipts": [], "charterHistory": [], "charterClaims": [], "gossipCards": [], "witnessPins": [], "merklePins": [], "merkleReceipts": [], "proofRequests": [], "proofSightings": [], "proofForks": [], "fixturePacks": [],
    },
}).encode()


def html_without_external_scripts(path: Path, *, embed_images: bool = False) -> tuple[str, list[Path]]:
    soup = BeautifulSoup(path.read_text(), 'html.parser')
    scripts: list[Path] = []
    for tag in list(soup.find_all('script', src=True)):
        scripts.append((path.parent / tag['src']).resolve())
        tag.decompose()
    if embed_images:
        for tag in soup.find_all('img', src=True):
            image_path = (path.parent / tag['src']).resolve()
            if image_path.is_file():
                encoded = base64.b64encode(image_path.read_bytes()).decode('ascii')
                tag['src'] = f'data:image/png;base64,{encoded}'
    return str(soup), scripts


async def visible_small_targets(page) -> list[dict[str, object]]:
    return await page.evaluate("""() => Array.from(document.querySelectorAll('button, label.file-button'))
      .filter(node => !node.hidden && node.offsetParent !== null && !node.disabled)
      .map(node => { const box=node.getBoundingClientRect(); return {text:(node.textContent||'').trim(),width:box.width,height:box.height}; })
      .filter(row => row.width < 43.5 || row.height < 43.5)""")


async def capture_node_card(page, filename: str) -> None:
    await page.evaluate("""() => {
      for (const node of document.querySelectorAll('.topbar, .bottom-nav, .skip-link')) {
        node.dataset.captureVisibility = node.style.visibility;
        node.style.visibility = 'hidden';
      }
    }""")
    try:
        await page.locator('#node-pairing-card').screenshot(path=str(ARTIFACTS / filename))
    finally:
        await page.evaluate("""() => {
          for (const node of document.querySelectorAll('.topbar, .bottom-nav, .skip-link')) {
            node.style.visibility = node.dataset.captureVisibility || '';
            delete node.dataset.captureVisibility;
          }
        }""")


async def capture_exchange_card(page, filename: str) -> None:
    await page.evaluate("""() => {
      for (const node of document.querySelectorAll('.topbar, .bottom-nav, .skip-link')) {
        node.dataset.captureVisibility = node.style.visibility;
        node.style.visibility = 'hidden';
      }
    }""")
    try:
        await page.locator('.exchange-review-card').screenshot(path=str(ARTIFACTS / filename))
    finally:
        await page.evaluate("""() => {
          for (const node of document.querySelectorAll('.topbar, .bottom-nav, .skip-link')) {
            node.style.visibility = node.dataset.captureVisibility || '';
            delete node.dataset.captureVisibility;
          }
        }""")


async def capture_capture_card(page, filename: str) -> None:
    await page.evaluate("""() => {
      for (const node of document.querySelectorAll('.topbar, .bottom-nav, .skip-link')) {
        node.dataset.captureVisibility = node.style.visibility;
        node.style.visibility = 'hidden';
      }
    }""")
    try:
        await page.locator('.capture-review-card').screenshot(path=str(ARTIFACTS / filename))
    finally:
        await page.evaluate("""() => {
          for (const node of document.querySelectorAll('.topbar, .bottom-nav, .skip-link')) {
            node.style.visibility = node.dataset.captureVisibility || '';
            delete node.dataset.captureVisibility;
          }
        }""")


async def sidepanel(browser) -> list[str]:
    errors: list[str] = []
    page = await browser.new_page(viewport={"width": 390, "height": 844}, device_scale_factor=1)
    page.on('console', lambda msg: errors.append(f"console:{msg.type}:{msg.text}") if msg.type == 'error' else None)
    page.on('pageerror', lambda error: errors.append(f"page:{error}"))
    html_text, _ = html_without_external_scripts(ROOT / 'sidepanel' / 'index.html', embed_images=True)
    await page.set_content(html_text, wait_until='domcontentloaded')
    await page.add_style_tag(content=(ROOT / 'sidepanel' / 'app.css').read_text())
    await page.add_script_tag(content=(ROOT / 'shared' / 'core.js').read_text())
    await page.add_script_tag(content=MOCK)
    await page.add_script_tag(content=(ROOT / 'shared' / 'publication-site.js').read_text())
    await page.add_script_tag(content=(ROOT / 'sidepanel' / 'app.js').read_text())
    await page.wait_for_function("document.querySelector('#today-summary').textContent.includes('1 unread')")

    assert await page.locator('#unread-count').text_content() == '1'
    assert await page.locator('.item-card').count() == 1
    assert not await visible_small_targets(page), await visible_small_targets(page)

    # Exchange is dark by default. Light remains one explicit, reversible choice.
    assert await page.evaluate("document.documentElement.dataset.theme") == 'dark'
    assert await page.locator('#theme-toggle').get_attribute('aria-label') == 'Use light theme'
    await page.screenshot(path=str(ARTIFACTS / 'reader-handshake-dark.png'), full_page=True)
    await page.locator('#theme-toggle').click()
    assert await page.evaluate("document.documentElement.dataset.theme") == 'light'
    assert await page.locator('#theme-toggle').get_attribute('aria-label') == 'Use dark theme'
    await page.screenshot(path=str(ARTIFACTS / 'reader-handshake-light.png'), full_page=True)
    await page.locator('#theme-toggle').click()
    assert await page.evaluate("document.documentElement.dataset.theme") == 'dark'

    # Exchange performs no Node request on startup. Review is one explicit,
    # browser-owned permission decision followed by a bounded identity/counts review.
    assert await page.evaluate("__nodeFetchRequests.length") == 0
    await page.locator('#tab-add').click()
    await page.locator('#focus-node-pairing').click()
    await page.locator('#node-invitation').fill(await page.evaluate("__nodeInvitationUrl"))
    await page.evaluate("__setPermissionResults(true); __clearMockLogs()")
    await page.locator('#review-node').click()
    await page.wait_for_function("document.querySelector('#node-review').hidden === false")
    assert await page.evaluate("JSON.stringify(__permissionRequests)") == '[{"origins":["http://127.0.0.1/*"]}]'
    assert await page.evaluate("__nodeFetchRequests.length") == 1
    review_text = await page.locator('#node-review').inner_text()
    assert 'Read-only library summary' in review_text
    assert '7 sources' in review_text and '2 watched pages' in review_text
    assert 'Node-owned transactional library' in review_text
    assert 'cannot' in review_text and 'synchronize' in review_text
    assert await page.locator('#node-invitation').input_value() == ''
    await page.screenshot(path=str(ARTIFACTS / 'reader-node-review.png'), full_page=True)
    await capture_node_card(page, 'reader-node-review-card.png')

    await page.locator('#pair-node').click()
    await page.wait_for_function("document.querySelector('#node-paired').hidden === false")
    paired_text = await page.locator('#node-paired').inner_text()
    assert 'Paired read-only' in await page.locator('#node-state-badge').inner_text()
    assert 'this pairing remains summary-only' in paired_text
    assert 'Node-owned transactional library' in paired_text
    assert await page.evaluate("async () => Boolean((await chrome.storage.local.get(['nodePairing'])).nodePairing)")
    assert await page.evaluate("__nodeFetchRequests.length") == 2
    await page.screenshot(path=str(ARTIFACTS / 'reader-node-paired.png'), full_page=True)
    await capture_node_card(page, 'reader-node-paired-card.png')

    await page.evaluate("__changeNodeLibraryDigest()")
    await page.locator('#check-node').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('changed since pairing')")
    assert 'file changed' in (await page.locator('#node-state-badge').inner_text()).lower()
    assert 'Changed since pairing' in await page.locator('#node-paired').inner_text()
    assert await page.evaluate("__nodeFetchRequests.length") == 3
    await page.screenshot(path=str(ARTIFACTS / 'reader-node-library-changed.png'), full_page=True)
    await capture_node_card(page, 'reader-node-library-changed-card.png')
    page.once('dialog', lambda dialog: asyncio.create_task(dialog.accept()))
    await page.locator('#unpair-node').click()
    await page.wait_for_function("document.querySelector('#node-pairing-start').hidden === false")
    assert not await page.evaluate("async () => Boolean((await chrome.storage.local.get(['nodePairing'])).nodePairing)")
    assert await page.evaluate("__nodeFetchRequests.length") == 4
    assert await page.evaluate("JSON.stringify(__permissionRemovals)") == '[{"origins":["http://127.0.0.1/*"]}]'
    assert not await page.evaluate("__nodeHostPermission()")

    # Capture is a separate one-use browser request. Review touches only the
    # local Node; the exact watched page is read only after a second visible
    # browser-owned permission decision.
    await page.evaluate("__setPermissionResults(true, true); __clearMockLogs()")
    await page.locator('#address').fill(await page.evaluate("__captureInvitationUrl"))
    await page.locator('#address-form button[type=submit]').click()
    await page.wait_for_function("document.querySelector('#capture-review-heading')")
    capture_review = await page.locator('.capture-review-card').inner_text()
    assert 'Use the rendered page without sending the login' in capture_review
    assert 'Town notices' in capture_review
    assert 'Cookies, credentials, permissions, and storage never become a Node capability' in capture_review
    assert 'Nothing is sent until you review matched and ignored examples' in capture_review
    assert await page.evaluate("__nodeFetchRequests.length") == 1
    assert await page.evaluate("__messageTypes.includes('capture-rendered-page')") is False
    assert await page.evaluate("JSON.stringify(__permissionRequests)") == '[{"origins":["http://127.0.0.1/*"]}]'
    await page.screenshot(path=str(ARTIFACTS / 'reader-capture-review.png'), full_page=True)
    await capture_capture_card(page, 'reader-capture-review-card.png')

    await page.get_by_role('button', name='Capture this open page').click()
    await page.wait_for_function("document.querySelectorAll('input[name=capture-choice]').length === 3")
    capture_choices = await page.locator('.capture-review-card').inner_text()
    assert 'What part of this page counts as an update?' in capture_choices
    assert 'What this browser view may leave outside' in capture_choices
    assert 'Page continues' in capture_choices
    assert 'Partial rendering' in capture_choices
    assert 'Visible overlay' in capture_choices
    assert 'Frames excluded' in capture_choices
    assert 'Advanced page-boundary evidence' in capture_choices
    assert 'Saved watched section' in capture_choices
    assert 'Repeated entries on this page' in capture_choices
    assert 'Primary readable text' in capture_choices
    assert 'Road closure moved to Thursday' in capture_choices
    assert 'Signed-in account menu' in capture_choices
    assert 'Later comparison stays conservative' in capture_choices
    assert 'More likely to stay put' in capture_choices
    assert 'why this may hold' in capture_choices.lower()
    assert 'what could break' in capture_choices.lower()
    assert 'not a promise' in capture_choices
    assert 'Before this becomes the baseline' in capture_choices
    assert 'Use this rendered view as the baseline' in capture_choices
    assert 'It will not follow pagination, scroll a virtual list, click or dismiss controls, wait for loading, or read frame contents' in capture_choices
    assert 'Capture the page again first' in capture_choices
    assert await page.evaluate("__messageTypes.filter(value => value === 'capture-rendered-page').length") == 1
    assert await page.evaluate("JSON.stringify(__permissionRequests)") == '[{"origins":["http://127.0.0.1/*"]},{"origins":["https://notices.example.test/*"]}]'
    assert await page.evaluate("__capturePagePermission()")
    send_capture = page.get_by_role('button', name='Use this view and send once')
    assert await send_capture.is_disabled()
    await page.screenshot(path=str(ARTIFACTS / 'reader-capture-choices.png'), full_page=True)
    await capture_capture_card(page, 'reader-drift-choices-card.png')
    await page.locator('#theme-toggle').click()
    assert await page.evaluate("document.documentElement.dataset.theme") == 'light'
    await page.screenshot(path=str(ARTIFACTS / 'reader-perimeter-choices-light.png'), full_page=True)
    await capture_capture_card(page, 'reader-drift-choices-light-card.png')
    await page.locator('#theme-toggle').click()
    assert await page.evaluate("document.documentElement.dataset.theme") == 'dark'

    await page.get_by_label('Use this rendered view as the baseline').check()
    assert not await send_capture.is_disabled()
    await capture_capture_card(page, 'reader-drift-acknowledged-card.png')
    await send_capture.click()
    await page.wait_for_function("document.querySelector('.capture-result-metrics')")
    capture_result = await page.locator('.capture-review-card').inner_text()
    assert 'Rendered window held' in capture_result
    assert 'Node site requests' in capture_result and '\n0' in capture_result
    assert 'Library revision' in capture_result and '\n3' in capture_result
    assert 'None created' in capture_result
    assert 'Advanced capture receipt' in capture_result
    assert 'kept its earlier baseline because this partial rendering looked like a different window' in capture_result
    assert 'created no mass add-or-remove alert' in capture_result
    await page.locator('.capture-review-card details.node-advanced summary').click()
    capture_result = await page.locator('.capture-review-card').inner_text()
    assert 'Section evidence' in capture_result
    assert 'More likely to stay put' in capture_result
    assert 'Page boundary evidence' in capture_result
    assert 'Page continues' in capture_result
    assert 'Frames excluded' in capture_result
    assert 'Coverage decision' in capture_result
    assert 'Used current rendering' in capture_result
    assert 'Rendered-window comparison' in capture_result
    assert 'Held' in capture_result and 'earlier baseline preserved' in capture_result
    assert await page.evaluate("__nodeFetchRequests.length") == 2
    await page.screenshot(path=str(ARTIFACTS / 'reader-capture-receipt.png'), full_page=True)
    await capture_capture_card(page, 'reader-drift-receipt-card.png')

    await page.get_by_role('button', name='Done').click()
    await page.wait_for_function("!document.querySelector('#capture-review-heading')")
    assert not await page.evaluate("__nodeHostPermission()")
    assert not await page.evaluate("__capturePagePermission()")
    assert await page.evaluate("JSON.stringify(__permissionRemovals)") == '[{"origins":["https://notices.example.test/*"]},{"origins":["http://127.0.0.1/*"]}]'

    # Exchange is a separate, expiring artifact handoff. One reviewed route
    # leads to three explicit consequences; it does not upgrade pairing or
    # silently synchronize either library.
    await page.evaluate("__setPermissionResults(true, true, true, true); __clearMockLogs()")
    await page.locator('#address').fill(await page.evaluate("__exchangeInvitationUrl"))
    await page.locator('#address-form button[type=submit]').click()
    await page.wait_for_function("document.querySelector('#exchange-review-heading')")
    exchange_text = await page.locator('.exchange-review-card').inner_text()
    assert 'one reviewed route · three choices' in exchange_text.lower()
    assert 'Follow updates' in exchange_text
    assert 'Add the complete route' in exchange_text
    assert 'Take one branch' in exchange_text
    assert await page.locator('.exchange-stats span').all_inner_texts() == ['3\nsources', '2\nfeeds', '1\nwatched page', '2\nfolders', '3\ncurator reasons']
    assert 'Reviewing this handoff has not followed a feed' in exchange_text
    assert 'grants no write access to either library' in exchange_text
    assert await page.evaluate("__nodeFetchRequests.length") == 1
    assert await page.evaluate("JSON.stringify(__permissionRequests)") == '[{"origins":["http://127.0.0.1/*"]}]'
    await page.locator('.exchange-contents summary').click()
    await page.locator('.exchange-privacy summary').click()
    expanded_exchange_text = await page.locator('.exchange-review-card').inner_text()
    for phrase in (
        'Community bulletin', 'Council agenda', 'Town notices', 'Curator’s reason for this folder',
        'Broad neighborhood context.', '<literal & reviewed>', 'Broad agenda overview.',
        'سبب لاجتماعات المجلس المحلية.', 'not a ProgRSS safety claim',
    ):
        assert phrase in expanded_exchange_text, (phrase, expanded_exchange_text)
    assert 'read and unread state' in expanded_exchange_text
    assert 'browser permissions and cookies' in expanded_exchange_text
    await page.screenshot(path=str(ARTIFACTS / 'reader-exchange-three-doors.png'), full_page=True)
    await capture_exchange_card(page, 'reader-exchange-three-doors-card.png')

    # Following updates retrieves only the bounded JSON Feed artifact, verifies
    # its reviewed digest, releases loopback authority, and previews it locally.
    await page.locator('#exchange-follow-updates').click()
    await page.wait_for_function("document.querySelector('#feed-preview-heading')")
    feed_text = await page.locator('.feed-preview').inner_text()
    assert 'one summary feed prepared from the source list' in feed_text.lower()
    assert 'does not add the underlying feeds or watched pages' in feed_text
    assert '3 items in this feed response' in feed_text
    assert await page.evaluate("__nodeFetchRequests.length") == 2
    assert not await page.evaluate("__nodeHostPermission()")
    await page.screenshot(path=str(ARTIFACTS / 'reader-exchange-follow-preview.png'), full_page=True)
    await page.get_by_role('button', name='Back to shared route choices').click()
    await page.wait_for_function("document.querySelector('#exchange-review-heading')")
    await page.wait_for_function("document.activeElement?.id === 'exchange-follow-updates'")

    # A branch opens the existing independent-excerpt review and does not claim
    # a continuing parent update relationship.
    await page.locator('#exchange-take-branch').click()
    await page.wait_for_function("document.querySelector('#shared-folder-review-heading')")
    branch_text = await page.locator('#shared-folder-preview').inner_text()
    assert 'Adding one folder section' in branch_text
    assert 'Neighborhood signal › Public meetings' in branch_text
    assert 'independent local folder' in branch_text
    assert '2 of 3 sources' in branch_text
    assert (await page.locator('#shared-folder-preview .import-stat strong').all_text_contents())[:4] == ['1', '1', '1', '0']
    assert (await page.locator('#shared-folder-preview .import-stat span').all_text_contents())[:4] == ['feeds', 'page watches', 'folders', 'sources already here']
    assert not await page.evaluate("__nodeHostPermission()")
    await page.screenshot(path=str(ARTIFACTS / 'reader-exchange-branch-review.png'), full_page=True)
    await page.get_by_role('button', name='Back to shared route choices').click()
    await page.wait_for_function("document.querySelector('#exchange-review-heading')")

    # The full route opens the ordinary source-list review. It still requires a
    # separate import decision and new sources remain paused.
    await page.locator('#exchange-add-route').click()
    await page.wait_for_function("document.querySelector('#shared-folder-review-heading')")
    route_text = await page.locator('#shared-folder-preview').inner_text()
    assert 'Ready to add Neighborhood signal' in route_text
    assert '3 new sources will start paused' in route_text
    assert 'Community bulletin' in route_text and 'Council agenda' in route_text
    assert 'Town notices' in route_text
    assert not await page.evaluate("__nodeHostPermission()")
    await page.screenshot(path=str(ARTIFACTS / 'reader-exchange-route-review.png'), full_page=True)
    await page.get_by_role('button', name='Back to shared route choices').click()
    await page.wait_for_function("document.querySelector('#exchange-review-heading')")

    # Closing the handoff leaves no pairing record or import behind.
    await page.get_by_role('button', name='Close without using it').click()
    await page.wait_for_function("!document.querySelector('#exchange-review-heading')")
    assert not await page.evaluate("__nodeHostPermission()")
    assert not await page.evaluate("async () => Boolean((await chrome.storage.local.get(['nodePairing'])).nodePairing)")
    assert await page.evaluate("__nodeFetchRequests.length") == 4
    await page.locator('#tab-today').click()

    # A failed storage write remains a persistent, plain-language recovery
    # decision. Export works from the banner and the check is deliberately a
    # small probe rather than an automatic retry of the failed action.
    await page.evaluate("chrome.runtime.sendMessage({target:'background',type:'seed-storage-incident'})")
    await page.wait_for_function("document.querySelector('#storage-incident').hidden === false")
    incident_text = await page.locator('#storage-incident').inner_text()
    assert 'attempted change was not saved' in incident_text
    assert 'last saved library remains available' in incident_text.lower()
    assert '2 updates' in incident_text
    assert 'does not delete unread or saved material automatically' in incident_text
    assert not await visible_small_targets(page), await visible_small_targets(page)
    await page.screenshot(path=str(ARTIFACTS / 'reader-storage-recovery.png'), full_page=True)
    await page.set_viewport_size({"width": 320, "height": 844})
    recovery_text_scale = await page.add_style_tag(content="html{font-size:20px!important}")
    recovery_overflow = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
    assert recovery_overflow <= 1, recovery_overflow
    assert not await visible_small_targets(page), await visible_small_targets(page)
    await page.screenshot(path=str(ARTIFACTS / 'reader-storage-recovery-320-large-text.png'), full_page=True)
    await recovery_text_scale.evaluate("node => node.remove()")
    await page.set_viewport_size({"width": 390, "height": 844})
    async with page.expect_download() as download_info:
        await page.locator('#save-recovery-copy').click()
    recovery_download = await download_info.value
    assert recovery_download.suggested_filename == 'ProgRSS-recovery-smoke.json'
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Recovery copy prepared')")
    await page.locator('#check-storage').click()
    await page.wait_for_function("document.querySelector('#storage-incident').hidden === true")
    assert 'small test write succeeded' in (await page.locator('#status').inner_text()).lower()

    # Focused reading search: source/title/summary, keyboard entry, and Escape clear.
    await page.locator('[data-filter="all"]').click()
    assert await page.locator('.item-card').count() == 2
    arabic_card = page.locator('.item-card[data-item-id="feed-two|old"]')
    assert await arabic_card.locator('.item-title a').get_attribute('lang') == 'ar'
    assert await arabic_card.locator('.item-title a').get_attribute('dir') == 'auto'
    assert await arabic_card.locator('.item-title a').evaluate("node => getComputedStyle(node).direction") == 'rtl'
    assert await arabic_card.locator('.item-summary').get_attribute('lang') == 'ar'
    await page.keyboard.press('/')
    assert await page.evaluate("document.activeElement?.id") == 'reading-search'
    await page.locator('#reading-search').fill('الورشة الإصلاح')
    assert await page.locator('.item-card').count() == 1
    assert 'مقهى الإصلاح' in await page.locator('.item-title').text_content()
    assert '1 result' in await page.locator('#today-summary').text_content()
    await page.keyboard.press('Escape')
    assert await page.locator('#reading-search').input_value() == ''
    assert await page.locator('.item-card').count() == 2

    # Search includes the feed-provided reading body, not only its timeline excerpt.
    await page.locator('#reading-search').fill('cabinet greenhouse')
    assert await page.locator('.item-card').count() == 1
    assert 'Seed library' in await page.locator('.item-title').text_content()
    await page.locator('#clear-search').click()

    # Focused reading stays inside ProgRSS when the feed supplied text. It renders
    # inert text only, supports keyboard return/paging, and reflows at 320 CSS px.
    first_card = page.locator('.item-card[data-item-id="feed-one|new"]')
    await first_card.locator('button', has_text='Read here').click()
    await page.wait_for_function("document.activeElement?.id === 'detail-heading'")
    assert await page.locator('#view-detail').is_visible()
    assert await page.locator('.bottom-nav').is_hidden()
    assert await page.locator('#detail-heading').text_content() == 'Seed library opens'
    assert await page.locator('#detail-heading').get_attribute('lang') == 'en-gb'
    assert await page.locator('#detail-heading').get_attribute('dir') == 'auto'
    assert await page.locator('#detail-source').get_attribute('lang') == 'en-gb'
    assert await page.locator('#detail-body p').count() == 3
    assert await page.locator('#detail-body p').evaluate_all("nodes => nodes.every(node => node.lang === 'en-gb' && node.dir === 'auto')")
    assert await page.locator('#detail-body p').first.evaluate("node => getComputedStyle(node).direction") == 'ltr'
    detail_text = await page.locator('#detail-body').inner_text()
    assert 'new cabinet map' in detail_text
    assert '<strong>feed text</strong>' in detail_text
    assert await page.locator('#detail-body strong').count() == 0
    assert 'Page scripts, frames, and remote images are not loaded here' in await page.locator('#detail-note').inner_text()
    assert await page.locator('#detail-open').get_attribute('rel') == 'noreferrer'
    assert not await visible_small_targets(page), await visible_small_targets(page)
    await page.screenshot(path=str(ARTIFACTS / 'reader-focused-detail.png'), full_page=True)

    cdp = await page.context.new_cdp_session(page)
    detail_tree = await cdp.send('Accessibility.getFullAXTree')
    detail_names = {(node.get('role') or {}).get('value','') + ':' + (node.get('name') or {}).get('value','') for node in detail_tree.get('nodes', [])}
    assert 'heading:Seed library opens' in detail_names
    assert any(value.startswith('button:Back to updates') for value in detail_names)
    assert any(value.startswith('link:Open original') for value in detail_names)

    await page.set_viewport_size({"width": 320, "height": 844})
    await page.evaluate("document.documentElement.style.fontSize='20px'")
    detail_overflow = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
    assert detail_overflow <= 1, detail_overflow
    assert not await visible_small_targets(page), await visible_small_targets(page)
    await page.screenshot(path=str(ARTIFACTS / 'reader-focused-detail-320-large-text.png'), full_page=True)
    await page.emulate_media(forced_colors='active', reduced_motion='reduce')
    assert await page.evaluate("matchMedia('(forced-colors: active)').matches")
    await page.screenshot(path=str(ARTIFACTS / 'reader-focused-detail-forced-colors.png'), full_page=True)
    await page.emulate_media(forced_colors='none', reduced_motion='no-preference')
    await page.set_viewport_size({"width": 390, "height": 844})
    await page.evaluate("document.documentElement.style.fontSize=''")

    await page.keyboard.press('j')
    assert await page.locator('#detail-heading').text_content() == 'جدول مقهى الإصلاح'
    assert await page.locator('#detail-heading').get_attribute('lang') == 'ar'
    assert await page.locator('#detail-heading').get_attribute('dir') == 'auto'
    assert await page.locator('#detail-heading').evaluate("node => getComputedStyle(node).direction") == 'rtl'
    assert await page.locator('#detail-source').get_attribute('lang') == 'ar'
    assert await page.locator('#detail-body p').first.get_attribute('lang') == 'ar'
    assert await page.locator('#detail-body p').first.get_attribute('dir') == 'auto'
    assert await page.locator('#detail-body p').first.evaluate("node => getComputedStyle(node).direction") == 'rtl'
    assert 'excerpt' in (await page.locator('#detail-note').inner_text()).lower()
    await page.screenshot(path=str(ARTIFACTS / 'reader-focused-arabic.png'), full_page=True)
    await page.keyboard.press('k')
    assert await page.locator('#detail-heading').text_content() == 'Seed library opens'
    await page.keyboard.press('Escape')
    await page.wait_for_function("document.activeElement?.dataset?.openDetail === 'feed-one|new'")
    assert await page.locator('#view-today').is_visible()
    assert await page.locator('.bottom-nav').is_visible()
    assert await page.locator('[aria-live]').count() == 2

    # Existing OPML-style folders are calm reading scopes, not a filing UI.
    assert await page.locator('#today-folder-scope').is_visible()
    options = await page.locator('#today-folders option').all_text_contents()
    assert options == ['All folders', 'Reading', 'Reading › Practical', 'Unfiled'], options
    await page.locator('#today-folders select').select_option('folder-practical')
    assert await page.locator('.item-card').count() == 1
    assert 'مقهى الإصلاح' in await page.locator('.item-title').text_content()
    assert 'Reading › Practical' in await page.locator('#today-summary').text_content()
    await page.locator('#today-folders select').select_option('all')
    assert await page.locator('.item-card').count() == 2

    # Scoped mark-read applies to matching results and remains undoable.
    await page.locator('[data-filter="unread"]').click()
    await page.locator('#reading-search').fill('seed library')
    assert await page.locator('.item-card').count() == 1
    assert await page.locator('#mark-all-read').text_content() == 'Mark results read'
    await page.locator('#mark-all-read').click()
    await page.wait_for_function("document.querySelector('#undo-row').hidden === false")
    await page.locator('#undo-mark-all').click()
    await page.wait_for_function("document.querySelector('#today-summary').textContent.includes('1 result')")
    await page.locator('#clear-search').click()
    await page.locator('[data-filter="all"]').click()
    first_card = page.locator('.item-card[data-item-id="feed-one|new"]')
    await first_card.locator('button', has_text='Mark read').click()
    await page.wait_for_function("document.querySelector('.item-card[data-item-id=\"feed-one|new\"]')?.textContent.includes('Mark unread')")
    await page.screenshot(path=str(ARTIFACTS / 'reader-demo.png'), full_page=True)

    # Human-readable source activity, not a scheduler dump.
    await page.locator('#tab-sources').focus()
    await page.keyboard.press('Enter')
    assert await page.evaluate("document.activeElement?.id") == 'sources-heading'

    # Sources prioritize work that needs a decision. Routine library care comes
    # afterward in one compact, state-driven surface rather than two competing
    # private-copy panels above the source list.
    await page.evaluate("chrome.runtime.sendMessage({target:'background',type:'seed-backup-reminder'})")
    await page.wait_for_function("document.querySelector('#private-copy').hidden === false")
    assert await page.locator('#private-copy').is_visible()
    assert await page.locator('#private-copy').get_attribute('open') is not None
    assert await page.locator('.source-group-heading h3').all_text_contents() == ['Needs your attention', 'Following']
    attention_cards = page.locator('.source-group.attention .source-card')
    assert await attention_cards.count() == 3
    assert await attention_cards.nth(0).get_attribute('data-source-id') == 'feed-moved'
    assert await attention_cards.nth(1).get_attribute('data-source-id') == 'feed-reconnect'
    assert await attention_cards.nth(2).get_attribute('data-source-id') == 'watch-repair'
    source_before_care = await page.evaluate("""() => {
      const sources = document.querySelector('#source-list');
      const care = document.querySelector('.library-care');
      return Boolean(sources && care && (sources.compareDocumentPosition(care) & Node.DOCUMENT_POSITION_FOLLOWING));
    }""")
    assert source_before_care
    assert await page.locator('#save-private-copy').count() == 1
    assert await page.locator('#check-private-copy').count() == 1
    reminder_text = await page.locator('#private-copy').inner_text()
    assert 'Keep a copy outside this browser' in reminder_text
    assert 'Save a private file, then select the saved file' in reminder_text
    assert not await visible_small_targets(page), await visible_small_targets(page)
    await page.screenshot(path=str(ARTIFACTS / 'reader-sources-prioritized.png'), full_page=True)
    await page.set_viewport_size({"width": 320, "height": 844})
    reminder_text_scale = await page.add_style_tag(content="html{font-size:20px!important}")
    reminder_overflow = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
    assert reminder_overflow <= 1, reminder_overflow
    assert not await visible_small_targets(page), await visible_small_targets(page)
    await page.screenshot(path=str(ARTIFACTS / 'reader-sources-prioritized-320-large-text.png'), full_page=True)
    await reminder_text_scale.evaluate("node => node.remove()")
    await page.set_viewport_size({"width": 390, "height": 844})
    await page.locator('#private-copy-options > summary').click()
    await page.locator('#snooze-backup-reminder').click()
    await page.wait_for_function("document.querySelector('#backup-reminder-summary').textContent.includes('Reminder returns')")
    assert await page.locator('#private-copy').is_visible()
    assert 'attention' not in (await page.locator('#private-copy').get_attribute('class') or '')
    assert not await page.locator('#private-copy').evaluate('node => node.open')
    await page.evaluate("chrome.runtime.sendMessage({target:'background',type:'seed-backup-reminder'})")
    await page.wait_for_function("document.querySelector('#private-copy').classList.contains('attention')")
    if not await page.locator('#private-copy-options').evaluate('node => node.open'):
        await page.locator('#private-copy-options > summary').click()
    await page.locator('#disable-backup-reminder').click()
    await page.wait_for_function("document.querySelector('#backup-reminder-summary').textContent.includes('Reminders off')")
    assert await page.locator('#private-copy').is_visible()
    assert not await page.locator('#private-copy').evaluate('node => node.open')
    await page.locator('#private-copy > summary').click()
    assert await page.locator('#enable-backup-reminder').is_visible()
    await page.locator('#enable-backup-reminder').click()
    await page.wait_for_function("document.querySelector('#private-copy').classList.contains('attention')")
    async with page.expect_download() as private_copy_info:
        await page.locator('#save-private-copy').click()
    private_copy = await private_copy_info.value
    assert private_copy.suggested_filename == 'ProgRSS-recovery-smoke.json'
    try:
        await private_copy.cancel()
    except Exception:
        pass
    await page.wait_for_function("document.querySelector('#private-copy').hidden === false")
    assert 'not checked' in (await page.locator('#backup-reminder-summary').inner_text()).lower()
    assert await page.locator('#check-private-copy').is_visible()

    async with page.expect_download() as checked_copy_info:
        await page.locator('#save-private-copy').click()
    checked_copy = await checked_copy_info.value
    checked_path = await checked_copy.path()
    assert checked_path
    await page.locator('#copy-check-file').set_input_files(str(checked_path))
    await page.wait_for_function("document.querySelector('#copy-check-heading').textContent.includes('matches')")
    assert 'matches' in (await page.locator('#copy-check-heading').inner_text()).lower()
    assert 'cannot promise' in (await page.locator('#copy-check-message').inner_text()).lower()
    await page.screenshot(path=str(ARTIFACTS / 'reader-private-copy-checked.png'), full_page=True)
    await page.wait_for_function("document.querySelector('#backup-reminder-summary').textContent.includes('Copy checked')")
    assert await page.locator('#private-copy').is_visible()
    assert 'Copy checked' in await page.locator('#backup-reminder-summary').inner_text()

    # A person can say the checked copy is no longer findable. ProgRSS records
    # that fact without deleting anything; selecting the file again clears it.
    if not await page.locator('#private-copy-options').evaluate('node => node.open'):
        await page.locator('#private-copy-options > summary').click()
    assert await page.locator('#mark-backup-copy-missing').is_visible()
    await page.locator('#mark-backup-copy-missing').click()
    await page.wait_for_function("document.querySelector('#backup-reminder-summary').textContent.includes('marked missing')")
    assert await page.locator('#private-copy').is_visible()
    await page.screenshot(path=str(ARTIFACTS / 'reader-private-copy-missing.png'), full_page=True)
    await page.locator('#copy-check-file').set_input_files(str(checked_path))
    await page.wait_for_function("document.querySelector('#copy-check-heading').textContent.includes('matches')")
    assert 'Copy checked' in await page.locator('#backup-reminder-summary').inner_text()

    # The same checked file remains recognizable after the live library changes.
    # It is described as readable but older, never as current.
    await page.evaluate("chrome.runtime.sendMessage({target:'background',type:'set-item',data:{itemId:'feed-one|new',starred:true}})")
    await page.wait_for_function("document.querySelector('#backup-reminder-summary').textContent.includes('library changed')")
    if not await page.locator('#private-copy-options').evaluate('node => node.open'):
        await page.locator('#private-copy-options > summary').click()
    await page.locator('#mark-backup-copy-missing').click()
    await page.wait_for_function("document.querySelector('#backup-reminder-summary').textContent.includes('marked missing')")
    await page.locator('#copy-check-file').set_input_files(str(checked_path))
    await page.wait_for_function("document.querySelector('#copy-check-heading').textContent.includes('older checked copy')")
    assert 'Readable, but older' in await page.locator('#copy-check-result').inner_text()
    assert 'marked missing' not in (await page.locator('#backup-reminder-summary').inner_text()).lower()
    await page.screenshot(path=str(ARTIFACTS / 'reader-private-copy-older.png'), full_page=True)
    await page.evaluate("chrome.runtime.sendMessage({target:'background',type:'set-item',data:{itemId:'feed-one|new',starred:false}})")

    different_copy = json.loads(Path(checked_path).read_text(encoding='utf-8'))
    different_copy['state']['items'] = different_copy['state']['items'][:-1]
    different_copy_path = ARTIFACTS / 'different-valid-copy.json'
    different_copy_path.write_text(json.dumps(different_copy, ensure_ascii=False, indent=2), encoding='utf-8')
    await page.locator('#copy-check-file').set_input_files(str(different_copy_path))
    await page.wait_for_function("document.querySelector('#copy-check-heading').textContent.includes('different valid copy')")
    assert 'Nothing was restored or changed' in await page.locator('#copy-check-message').inner_text()
    assert 'marked missing' not in (await page.locator('#backup-reminder-summary').inner_text()).lower()

    assert await page.locator('.source-card').count() == 6
    assert await page.locator('#source-folder-scope').is_visible()
    await page.locator('#source-folders select').select_option('folder-practical')
    assert await page.locator('.source-card').count() == 1
    assert 'Reading › Practical' in await page.locator('.folder-badge').text_content()

    # A simple folder has one contextual sharing action. Attribution and signing
    # stay behind a disclosure, and the generated file says what the signature
    # can and cannot establish.
    assert await page.locator('#share-folder-button').is_visible()
    await page.locator('#share-folder-button').click()
    await page.wait_for_function("document.querySelector('#share-folder-review').hidden === false")
    share_text = await page.locator('#share-folder-review').inner_text()
    assert 'source list that another person can review' in share_text
    await page.locator('#share-attribution > summary').click()
    await page.wait_for_function("document.querySelector('#share-identity-status').textContent.includes('No local signing identity')")
    assert await page.locator('#create-share-identity').is_visible()
    await page.locator('#create-share-identity').click()
    await page.wait_for_function("document.querySelector('#share-identity-status').textContent.includes('Local key')")
    assert await page.locator('#share-sign').is_checked()
    await page.locator('#share-curator').fill('Neighborhood readers')
    await page.locator('#share-note').fill('A small practical reading list for the repair café.')
    await page.locator('#share-publication-site > summary').click()
    await page.locator('#share-update-url').fill('https://updates.example.test/practical.json')
    async with page.expect_download() as shared_folder_info:
        await page.locator('#save-shared-folder').click()
    shared_folder_download = await shared_folder_info.value
    shared_folder_path = await shared_folder_download.path()
    assert shared_folder_path
    shared_folder_doc = json.loads(Path(shared_folder_path).read_text(encoding='utf-8'))
    assert shared_folder_doc['schema'] == 'progrss.bundle.v3'
    assert shared_folder_doc['distribution'] == {'schema': 'progrss.shared-folder.distribution.v1', 'updateUrl': 'https://updates.example.test/practical.json'}
    assert shared_folder_doc['publication']['curator'] == 'Neighborhood readers'
    assert shared_folder_doc['publication']['note'].startswith('A small practical')
    assert shared_folder_doc['integrity']['signature']['algorithm'] == 'Ed25519'
    await page.wait_for_function("document.querySelector('#status').textContent.includes('signed')")
    assert 'does not prove a person' in (await page.locator('#share-folder-review').inner_text()).lower()

    await page.locator('#share-edition > summary').click()
    async with page.expect_download() as edition_info:
        await page.locator('#save-folder-edition').click()
    edition_download = await edition_info.value
    edition_path = await edition_download.path()
    assert edition_path
    edition_doc = json.loads(Path(edition_path).read_text(encoding='utf-8'))
    assert edition_doc['version'] == 'https://jsonfeed.org/version/1.1'
    assert edition_doc['_progrss']['schema'] == 'progrss.folder-edition.v1'
    assert edition_doc['authors'] == [{'name': 'Neighborhood readers'}]
    assert edition_doc['title'] == 'Reading › Practical · recent updates'
    assert len(edition_doc['items']) == 1
    edition_item = edition_doc['items'][0]
    assert edition_item['content_text'] == 'أحضر جهازًا صغيرًا واحدًا.'
    assert not {'body', 'readAt', 'starred', 'change'} & set(edition_item)
    assert edition_doc['_progrss']['excluded']['fullRetainedText'] is True
    assert edition_doc['_progrss']['excluded']['readingState'] is True
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Recent-updates feed prepared')")
    assert 'Full retained text and reading state stayed private' in await page.locator('#status').inner_text()

    assert await page.locator('#site-include-updates').is_visible()
    assert not await page.locator('#site-include-updates').is_checked()
    await page.locator('#site-include-updates').check()
    assert await page.locator('#save-publication-site').inner_text() == 'Save website with recent updates'

    publication_probe = await page.evaluate("""raw => {
      try {
        const built = globalThis.ProgRSSPublicationSite?.build(raw);
        return {available: Boolean(globalThis.ProgRSSPublicationSite), bytes: built?.bytes?.length || 0, files: built?.summary?.files || 0, error: ''};
      } catch (error) {
        return {available: Boolean(globalThis.ProgRSSPublicationSite), bytes: 0, files: 0, error: String(error?.message || error)};
      }
    }""", json.dumps(shared_folder_doc, ensure_ascii=False))
    assert publication_probe['available'], publication_probe
    assert publication_probe['bytes'] > 0 and publication_probe['files'] == 4, publication_probe
    try:
        async with page.expect_download(timeout=45000) as publication_site_info:
            await page.locator('#save-publication-site').click()
        publication_site_download = await publication_site_info.value
    except Exception as error:
        status_text = await page.locator('#status').inner_text()
        button_enabled = await page.locator('#save-publication-site').is_enabled()
        raise AssertionError(f"Publication-site download did not start; status={status_text!r}, enabled={button_enabled}, probe={publication_probe}") from error
    publication_site_path = await publication_site_download.path()
    assert publication_site_path
    with zipfile.ZipFile(publication_site_path, 'r') as publication_site:
        assert set(publication_site.namelist()) == {'index.html', 'practical.json', 'subscriptions.opml', 'recent-updates.json', 'README.txt'}
        publication_page = publication_site.read('index.html').decode('utf-8')
        assert '<script' not in publication_page.lower()
        assert '<iframe' not in publication_page.lower()
        assert 'no scripts, trackers, remote images, or automatic update checks' in publication_page.lower()
        assert '<link rel="alternate" type="application/feed+json" href="recent-updates.json"' in publication_page
        assert 'Recent updates' in publication_page
        assert 'This is a manual snapshot' in publication_page
        assert 'Curator’s reason for this folder:' in publication_page
        assert 'Useful for repair-café workshop notices.' in publication_page
        assert 'not a ProgRSS safety claim' in publication_page
        assert '1 curator reason' in publication_page
        publication_doc = json.loads(publication_site.read('practical.json'))
        assert publication_doc['schema'] == 'progrss.bundle.v3'
        assert publication_doc['integrity']['signature']['algorithm'] == 'Ed25519'
        assert publication_doc['distribution']['updateUrl'] == 'https://updates.example.test/practical.json'
        assert publication_doc['collections'][0]['members'][0]['reason'] == 'Useful for repair-café workshop notices.'
        assert 'xmlUrl="https://workshop.test/atom.xml"' in publication_site.read('subscriptions.opml').decode('utf-8')
        assert 'Useful for repair-café workshop notices.' not in publication_site.read('subscriptions.opml').decode('utf-8')
        hosted_edition = json.loads(publication_site.read('recent-updates.json'))
        assert hosted_edition['feed_url'] == 'https://updates.example.test/recent-updates.json'
        assert hosted_edition['home_page_url'] == 'https://updates.example.test/index.html'
        assert len(hosted_edition['items']) == 1
        hosted_edition_raw = json.dumps(hosted_edition, ensure_ascii=False)
        assert 'body' not in hosted_edition['items'][0]
        assert 'readAt' not in hosted_edition_raw and 'starred' not in hosted_edition_raw and 'change' not in hosted_edition['items'][0]
        assert 'does not poll' in publication_site.read('README.txt').decode('utf-8')
        assert 'Summary-only JSON Feed' in publication_site.read('README.txt').decode('utf-8')
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Ready-to-host website prepared')")
    publication_status = await page.locator('#status').inner_text()
    assert 'No scripts, trackers, or automatic checks' in publication_status
    assert '1 recent update' in publication_status
    await page.screenshot(path=str(ARTIFACTS / 'reader-share-folder-signed.png'), full_page=True)
    await page.locator('#close-share-folder').click()

    # A located publication is checked only from a literal human action. The
    # remote copy is reviewed using the same three decisions and is never
    # scheduled or applied by the check itself.
    assert await page.locator('#check-shared-folder-update').is_visible()
    assert await page.locator('#check-shared-folder-update').inner_text() == 'Check for a newer copy'
    await page.locator('#check-shared-folder-update').click()
    await page.wait_for_function("document.querySelector('#shared-folder-preview').textContent.includes('fetched only on your request')")
    remote_review = await page.locator('#shared-folder-preview').inner_text()
    for phrase in ('fetched only on your request', 'omitted cookies and credentials', 'does not schedule another check', 'Same signing key', 'Update from this copy', 'Keep my local version', 'Import as a separate folder'):
        assert phrase.lower() in remote_review.lower(), (phrase, remote_review)
    assert 'Nothing changed yet' in await page.locator('#status').inner_text()
    await page.screenshot(path=str(ARTIFACTS / 'reader-check-publication.png'), full_page=True)
    await page.locator('#shared-folder-preview button', has_text='Keep my local version').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Nothing changed')")
    assert await page.locator('#check-shared-folder-update').is_visible()

    # Incoming signed folders are reviewed locally. The UI verifies the file
    # while refusing to turn a key fingerprint into a real-world identity claim.
    await page.locator('#tab-add').click()
    signed_fixture = ROOT / 'fixtures' / 'shared-folder' / 'ed25519.json'
    await page.locator('#shared-folder-file').set_input_files(str(signed_fixture))
    await page.wait_for_function("document.querySelector('#shared-folder-preview').textContent.includes('Signature verified')")
    incoming_text = await page.locator('#shared-folder-preview').inner_text()
    for phrase in ('Signature verified', 'matching private key', 'does not prove', 'without contacting any site'):
        assert phrase.lower() in incoming_text.lower(), (phrase, incoming_text)
    await page.screenshot(path=str(ARTIFACTS / 'reader-shared-folder-verified.png'), full_page=True)
    await page.locator('#shared-folder-preview button', has_text='Add source list').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('signature verified')")

    # A later copy of the same publication becomes a reviewed update, not a
    # silent replacement. Key changes require an explicit acknowledgement and
    # the three human choices stay visible together.
    await page.locator('#tab-add').click()
    changed_key_fixture = ROOT / 'fixtures' / 'shared-folder' / 'p256.json'
    await page.locator('#shared-folder-file').set_input_files(str(changed_key_fixture))
    await page.wait_for_function("document.querySelector('#shared-folder-preview').textContent.includes('Signing key changed')")
    update_review_text = await page.locator('#shared-folder-preview').inner_text()
    for phrase in ('Three-way review', 'Curator only', 'Yours only', 'Need a choice', 'Keep mine', 'Use curator’s', 'Review 1 change to how a source is checked', 'old-workshop.test', 'workshop.test', 'Import as a separate folder', 'Local reading history', 'new paused source'):
        assert phrase.lower() in update_review_text.lower(), (phrase, update_review_text)
    update_button = page.locator('#shared-folder-preview button', has_text='Apply reviewed choices')
    assert await update_button.is_disabled()
    await page.locator('.shared-folder-trust-confirm input').check()
    assert await update_button.is_disabled()
    await page.locator('.merge-conflict-card label', has_text='Keep mine').click()
    assert await update_button.is_disabled()
    await page.locator('.merge-recipe-confirm input').check()
    assert not await update_button.is_disabled()
    await page.locator('.merge-conflict-card .merge-advanced summary').click()
    await page.screenshot(path=str(ARTIFACTS / 'reader-merge-review.png'), full_page=True)
    await page.locator('.shared-folder-merge-review').screenshot(path=str(ARTIFACTS / 'reader-merge-review-card.png'))
    await update_button.click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('updated')")
    await page.wait_for_function("document.querySelector('#shared-folder-update-undo').hidden === false")
    assert 'Undo folder update' in await page.locator('#shared-folder-update-undo').inner_text()
    await page.locator('#undo-shared-folder-update').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('restored')")

    await page.locator('#source-folders select').select_option('all')
    assert await page.locator('.source-card').count() == 6
    moved = page.locator('.source-card[data-source-id="feed-moved"]')
    reconnect = page.locator('.source-card[data-source-id="feed-reconnect"]')
    moved_text = await moved.inner_text()
    assert 'Review this source’s new address' in moved_text
    assert 'https://old.example.test/calendar.xml' in moved_text
    assert 'https://calendar.example.test:8443/feed.xml' in moved_text
    assert await moved.locator('button', has_text='Follow at calendar.example.test:8443').is_visible()
    assert 'Reconnect this source' in await reconnect.inner_text()
    assert await reconnect.locator('button', has_text='Reconnect and check now').is_visible()
    feed_one = page.locator('.source-card[data-source-id="feed-one"]')
    await feed_one.locator('summary').click()
    activity = ' '.join(await feed_one.locator('.activity-grid').all_text_contents())
    assert 'Successful check' in activity and 'New update' in activity and 'Last problem' in activity

    # Retained feed text is visible without pretending to know exact browser
    # overhead. Each feed has one future-facing choice; cleanup is separate,
    # limited to read and unsaved text, and briefly undoable.
    assert await page.locator('#storage-overview').is_visible()
    assert 'retained' in (await page.locator('#storage-summary').inner_text()).lower()
    await page.locator('#storage-overview > summary').click()
    storage_text = await page.locator('#storage-overview').inner_text()
    assert 'feed-supplied text' in storage_text
    assert 'not a backup' in storage_text
    retention = feed_one.locator('.source-text-retention')
    assert 'Keep full feed text' in await retention.inner_text()
    await retention.locator('select').select_option('summary')
    await retention.locator('button', has_text='Use this choice').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Future checks will keep summaries only')")
    feed_one = page.locator('.source-card[data-source-id="feed-one"]')
    await feed_one.locator('summary').click()
    retention = feed_one.locator('.source-text-retention')
    assert 'Unread and saved updates keep their text' in await retention.inner_text()
    await page.screenshot(path=str(ARTIFACTS / 'reader-offline-reading.png'), full_page=True)
    await retention.locator('button', has_text='Clear 1 read, unsaved update').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Cleared 1 read, unsaved update')")
    assert await page.locator('#text-cleanup-undo').is_visible()
    assert 'briefly in this open reader' in await page.locator('#text-cleanup-undo-message').inner_text()
    assert 'summary' in (await page.locator('#storage-summary').inner_text()).lower() or 'no full text' in (await page.locator('#storage-summary').inner_text()).lower()
    await page.locator('#undo-text-cleanup').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('feed text has been restored')")
    assert await page.locator('#text-cleanup-undo').is_hidden()
    feed_one = page.locator('.source-card[data-source-id="feed-one"]')
    await feed_one.locator('summary').click()
    retention = feed_one.locator('.source-text-retention')
    await retention.locator('select').select_option('full')
    await retention.locator('button', has_text='Use this choice').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Future checks will keep full text')")

    # A source can be placed in an existing simple folder without exposing
    # collection operators. Parent-folder inclusion is explained and undoable.
    await reconnect.locator('summary').click()
    organizer = reconnect.locator('.source-folder-organizer')
    assert 'Not directly in a folder yet' in await organizer.inner_text()
    await organizer.locator('select').select_option('folder-practical')
    await organizer.locator('button', has_text='Add to folder').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('It also appears in Reading')")
    assert await page.locator('#folder-undo-row').is_visible()
    assert 'Reading › Practical' in await reconnect.inner_text()
    await page.locator('#undo-folder-change').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Folder placement undone')")
    assert await page.locator('#folder-undo-row').is_hidden()
    assert 'Reading › Practical' not in await reconnect.inner_text()

    # The inverse correction is equally direct. It removes only one direct
    # placement, explains inherited membership, and has its own guarded undo.
    await reconnect.locator('summary').click()
    organizer = reconnect.locator('.source-folder-organizer')
    await organizer.locator('select.source-folder-select').select_option('folder-practical')
    await organizer.locator('button', has_text='Add to folder').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Added to Reading › Practical')")
    await reconnect.locator('summary').click()
    organizer = reconnect.locator('.source-folder-organizer')
    organizer_text = await organizer.inner_text()
    assert 'Directly in Reading › Practical' in organizer_text, organizer_text
    assert 'Also appears in Reading' in organizer_text, organizer_text
    await organizer.locator('select.source-folder-remove-select').select_option('folder-practical')
    await organizer.locator('button', has_text='Remove from folder').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Removed from Reading › Practical')")
    assert 'Removed Library Notices from Reading › Practical' in await page.locator('#folder-undo-message').inner_text()
    assert 'Reading › Practical' not in await reconnect.inner_text()
    await page.locator('#undo-folder-change').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Folder removal undone')")
    await reconnect.locator('summary').click()
    assert 'Directly in Reading › Practical' in await reconnect.inner_text()

    # A Source Note is authored on one selected direct folder/source
    # relationship. The editor states its local boundary, enforces the shared
    # Unicode-code-point limit, survives an ordinary rerender, and has guarded
    # undo rather than silently overwriting a newer placement.
    feed_one = page.locator('.source-card[data-source-id="feed-one"]')
    await feed_one.locator('summary', has_text='Activity and options').click()
    organizer = feed_one.locator('.source-folder-organizer')
    reading_placement = organizer.locator('.source-note-placement[data-source-note-placement-key="folder-reading/feed-one"]')
    assert 'Independent garden reporting for this reading route.' in await reading_placement.inner_text()
    await reading_placement.get_by_role('button', name='Edit reason for Reading', exact=True).click()
    editor = feed_one.locator('.source-note-editor')
    editor_text = await editor.inner_text()
    assert 'stays in this local ProgRSS library' in editor_text
    assert 'publishes nothing' in editor_text
    assert 'contacts nobody' in editor_text
    assert 'creates no schedule' in editor_text
    assert 'not a ProgRSS safety claim' in editor_text
    textarea = editor.locator('textarea')
    await textarea.fill('Community garden reporting selected for this route. 🪴')
    await page.evaluate("chrome.runtime.sendMessage({target:'background',type:'test-source-note-interruption',data:{}})")
    await page.wait_for_function("document.querySelector('textarea[data-source-note-editor-key=\"folder-reading/feed-one\"]')?.value.includes('Community garden reporting')")
    textarea = feed_one.locator('textarea[data-source-note-editor-key="folder-reading/feed-one"]')
    assert await textarea.input_value() == 'Community garden reporting selected for this route. 🪴'
    assert await textarea.evaluate('node => document.activeElement === node')
    await textarea.fill('x' * 281)
    assert await textarea.get_attribute('aria-invalid') == 'true'
    assert await feed_one.get_by_role('button', name='Save reason').is_disabled()
    assert '281 of 280 Unicode characters' in await feed_one.locator('.source-note-count').inner_text()
    await textarea.fill('Community garden reporting selected for this route. 🪴')
    await feed_one.get_by_role('button', name='Save reason').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Saved the reason for Reading')")
    assert await page.locator('#source-note-undo').is_visible()
    assert 'Changed the reason for Garden Notes in Reading' in await page.locator('#source-note-undo-message').inner_text()
    await feed_one.locator('summary', has_text='Activity and options').click()
    reading_placement = feed_one.locator('.source-note-placement[data-source-note-placement-key="folder-reading/feed-one"]')
    assert 'Community garden reporting selected for this route. 🪴' in await reading_placement.inner_text()
    await page.locator('#undo-source-note').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('earlier placement reason was restored')")
    await feed_one.locator('summary', has_text='Activity and options').click()
    reading_placement = feed_one.locator('.source-note-placement[data-source-note-placement-key="folder-reading/feed-one"]')
    assert 'Independent garden reporting for this reading route.' in await reading_placement.inner_text()

    # The same source may have a different reason in another direct folder.
    # Editing the new placement leaves the Reading reason unchanged.
    organizer = feed_one.locator('.source-folder-organizer')
    await organizer.locator('select.source-folder-select').select_option('folder-practical')
    await organizer.locator('button', has_text='Add to folder').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Added to Reading › Practical')")
    await feed_one.locator('summary', has_text='Activity and options').click()
    practical_placement = feed_one.locator('.source-note-placement[data-source-note-placement-key="folder-practical/feed-one"]')
    await practical_placement.get_by_role('button', name='Add reason for Reading › Practical', exact=True).click()
    practical_editor = feed_one.locator('.source-note-editor')
    await practical_editor.locator('textarea').fill('Hands-on repair references for this practical route.')
    await practical_editor.get_by_role('button', name='Save reason').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Saved the reason for Reading › Practical')")
    await feed_one.locator('summary', has_text='Activity and options').click()
    reading_placement = feed_one.locator('.source-note-placement[data-source-note-placement-key="folder-reading/feed-one"]')
    practical_placement = feed_one.locator('.source-note-placement[data-source-note-placement-key="folder-practical/feed-one"]')
    assert 'Independent garden reporting for this reading route.' in await reading_placement.inner_text()
    assert 'Hands-on repair references for this practical route.' in await practical_placement.inner_text()

    # Cancel does not write. Clear removes the field, and undo restores the
    # exact earlier value on this placement only.
    await practical_placement.get_by_role('button', name='Edit reason for Reading › Practical', exact=True).click()
    practical_editor = feed_one.locator('.source-note-editor')
    await practical_editor.locator('textarea').fill('This draft must not be saved.')
    await practical_editor.get_by_role('button', name='Cancel').click()
    await feed_one.locator('summary', has_text='Activity and options').click()
    practical_placement = feed_one.locator('.source-note-placement[data-source-note-placement-key="folder-practical/feed-one"]')
    assert 'Hands-on repair references for this practical route.' in await practical_placement.inner_text()
    assert 'This draft must not be saved.' not in await practical_placement.inner_text()
    await practical_placement.get_by_role('button', name='Edit reason for Reading › Practical', exact=True).click()
    await feed_one.locator('.source-note-editor').get_by_role('button', name='Clear reason').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Cleared the reason for Reading › Practical')")
    await feed_one.locator('summary', has_text='Activity and options').click()
    practical_placement = feed_one.locator('.source-note-placement[data-source-note-placement-key="folder-practical/feed-one"]')
    assert 'No reason on this folder relationship.' in await practical_placement.inner_text()
    await page.locator('#undo-source-note').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('earlier placement reason was restored')")
    await feed_one.locator('summary', has_text='Activity and options').click()
    practical_placement = feed_one.locator('.source-note-placement[data-source-note-placement-key="folder-practical/feed-one"]')
    assert 'Hands-on repair references for this practical route.' in await practical_placement.inner_text()

    # A real concurrent folder change is refused. The interrupted draft stays
    # available for review, while the newer reason remains authoritative.
    reading_placement = feed_one.locator('.source-note-placement[data-source-note-placement-key="folder-reading/feed-one"]')
    await reading_placement.get_by_role('button', name='Edit reason for Reading', exact=True).click()
    stale_textarea = feed_one.locator('textarea[data-source-note-editor-key="folder-reading/feed-one"]')
    await stale_textarea.fill('Draft that must not overwrite a newer reason.')
    await page.evaluate("chrome.runtime.sendMessage({target:'background',type:'test-source-note-stale',data:{sourceId:'feed-one',collectionId:'folder-reading'}})")
    await page.wait_for_function("document.querySelector('textarea[data-source-note-editor-key=\"folder-reading/feed-one\"]')?.value.startsWith('Draft that must not')")
    stale_textarea = feed_one.locator('textarea[data-source-note-editor-key="folder-reading/feed-one"]')
    assert await stale_textarea.evaluate('node => document.activeElement === node')
    await feed_one.get_by_role('button', name='Save reason').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('newer reason was kept')")
    assert 'Cancel, review the latest reason' in await feed_one.locator('.source-note-editor-error').inner_text()
    reading_placement = feed_one.locator('.source-note-placement[data-source-note-placement-key="folder-reading/feed-one"]')
    assert 'Changed in another view.' in await reading_placement.inner_text()
    await feed_one.locator('.source-note-editor').get_by_role('button', name='Cancel').click()

    # One unusual page shape stays in Following and remains visibly pending
    # without manufacturing a page-change alert or demanding immediate repair.
    steady_watch = page.locator('.source-card[data-source-id="watch-steady"]')
    steady_text = await steady_watch.inner_text()
    assert 'Checking again' in steady_text, steady_text
    assert 'ProgRSS is checking one unusual result' in steady_text, steady_text
    assert 'No page-change alert was created' in steady_text, steady_text
    assert await steady_watch.locator('button', has_text='Check again').is_visible()
    following_group = page.locator('.source-group', has=page.locator('h3', has_text='Following'))
    assert await following_group.locator('.source-card[data-source-id="watch-steady"]').count() == 1
    attention_group = page.locator('.source-group', has=page.locator('h3', has_text='Needs your attention'))
    assert await attention_group.locator('.source-card[data-source-id="watch-steady"]').count() == 0

    # A declined or dismissed browser prompt is a neutral decision, not an
    # application failure. The held observation remains pending and no refresh
    # message reaches the background context.
    await page.evaluate("__clearMockLogs(); __setPermissionResults(false)")
    await steady_watch.locator('button', has_text='Check again').click()
    await page.wait_for_function("document.querySelector('#status').classList.contains('decision')")
    steady_access_text = await page.locator('#status').inner_text()
    assert 'community.example.test' in steady_access_text, steady_access_text
    assert 'still waiting for another check' in steady_access_text, steady_access_text
    assert 'No alert or source change was created' in steady_access_text, steady_access_text
    assert await page.evaluate("!__messageTypes.includes('refresh-source')")
    assert await steady_watch.locator('button', has_text='Check again').is_visible()
    assert 'Checking again' in await steady_watch.inner_text()

    # A broken page watch stops checking and offers a selector-free repair.
    watch_repair = page.locator('.source-card[data-source-id="watch-repair"]')
    watch_repair_text = await watch_repair.inner_text()
    assert 'Repair watch' in watch_repair_text, watch_repair_text
    assert 'Find what to watch now' in watch_repair_text, watch_repair_text
    assert '.old-list' not in watch_repair_text
    await page.evaluate("__clearMockLogs(); __setPermissionResults(false)")
    await watch_repair.locator('button', has_text='Find what to watch now').click()
    await page.wait_for_function("document.querySelector('#status').classList.contains('decision')")
    repair_access_text = await page.locator('#status').inner_text()
    assert 'notices.example.test' in repair_access_text, repair_access_text
    assert 'current rule and earlier alerts were kept' in repair_access_text, repair_access_text
    assert await page.evaluate("!__messageTypes.includes('preview-page-watch-repair')")
    assert 'Find what to watch now' in await watch_repair.inner_text()
    await watch_repair.locator('button', has_text='Find what to watch now').click()
    await page.wait_for_function("document.querySelector('.source-card[data-source-id=\"watch-repair\"] .watch-repair-heading')?.textContent.includes('Choose what to watch now')")
    assert await page.evaluate("document.activeElement?.classList.contains('watch-repair-heading')")
    review_text = await watch_repair.inner_text()
    assert 'Road work moves to Tuesday' in review_text, review_text
    assert 'Library roof meeting' in review_text, review_text
    assert 'selector details stay in Advanced Workbench' in review_text, review_text
    assert '.old-list' not in review_text
    assert 'Nothing changed' in await page.locator('#status').inner_text()
    await watch_repair.locator('button', has_text='Use this section').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('fresh baseline')")
    assert await page.locator('#page-watch-repair-undo').is_visible()
    assert 'Earlier alerts were kept' in await page.locator('#status').inner_text()
    await watch_repair.locator('summary').click()
    assert 'A fresh starting point was saved' in await watch_repair.inner_text()
    await page.locator('#undo-page-watch-repair').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('restored to its earlier rule and baseline')")
    assert await page.locator('#page-watch-repair-undo').is_hidden()
    assert 'Find what to watch now' in await watch_repair.inner_text()

    assert not await visible_small_targets(page), await visible_small_targets(page)
    await page.screenshot(path=str(ARTIFACTS / 'reader-sources.png'), full_page=True)
    await page.evaluate("__clearMockLogs(); __setPermissionResults(false)")
    await moved.locator('button', has_text='Follow at calendar.example.test:8443').click()
    await page.wait_for_function("document.querySelector('#status').classList.contains('decision')")
    moved_access_text = await page.locator('#status').inner_text()
    assert 'old.example.test and calendar.example.test:8443' in moved_access_text, moved_access_text
    assert 'current source address was kept' in moved_access_text, moved_access_text
    assert await page.evaluate("!__messageTypes.includes('accept-source-redirect')")
    assert await moved.locator('.source-decision').count() == 1

    await moved.locator('button', has_text='Follow at calendar.example.test:8443').focus()
    await page.keyboard.press('Enter')
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Source moved and checked')")
    assert 'calendar.example.test' in await moved.inner_text()
    assert await moved.locator('.source-decision').count() == 0

    await page.evaluate("__clearMockLogs(); __setPermissionResults(false)")
    await reconnect.locator('button', has_text='Reconnect and check now').click()
    await page.wait_for_function("document.querySelector('#status').classList.contains('decision')")
    reconnect_access_text = await page.locator('#status').inner_text()
    assert 'library.example.test' in reconnect_access_text, reconnect_access_text
    assert 'still needs reconnecting' in reconnect_access_text, reconnect_access_text
    assert await page.evaluate("!__messageTypes.includes('toggle-source') && !__messageTypes.includes('refresh-source')")
    assert 'Reconnect this source' in await reconnect.inner_text()

    await reconnect.locator('button', has_text='Reconnect and check now').focus()
    await page.keyboard.press('Space')
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Reconnected')")

    # OPML review is local, counts migration consequences, and offers an explicit paused path.
    await page.locator('#tab-add').click()
    assert await page.locator('.start-choice').count() == 4
    assert await page.locator('#use-current-page').inner_text() == '◎\nUse this page\nLook for a feed on the page beside ProgRSS.'

    # Page discovery recognizes an advertised feed already in the library and
    # offers the existing source instead of a misleading second Follow action.
    await page.locator('#use-current-page').click()
    await page.wait_for_function("document.querySelector('#discovery').textContent.includes('already following')")
    discovery_text = await page.locator('#discovery').inner_text()
    for phrase in ('Choose what you want', 'Add the source list', 'Review source list', 'Follow recent updates', 'Preview recent updates', 'Other feeds on this page'):
        assert phrase in discovery_text, (phrase, discovery_text)
    assert 'Watch this page' not in discovery_text, discovery_text
    await page.locator('#discovery button', has_text='Review source list').click()
    await page.wait_for_function("document.querySelector('#shared-folder-preview').textContent.includes('fetched only on your request')")
    page_folder_review = await page.locator('#shared-folder-preview').inner_text()
    assert 'Ready to add Community sources' in page_folder_review, page_folder_review
    assert 'Community desk' in page_folder_review, page_folder_review
    assert 'does not schedule another check' in page_folder_review, page_folder_review
    assert 'See 1 source and 2 folders · 1 curator reason' in page_folder_review, page_folder_review
    assert 'curator’s explanation for putting one source in one folder' in page_folder_review, page_folder_review
    assert 'not a ProgRSS safety claim' in page_folder_review, page_folder_review
    assert 'Curator’s reason for this placement: Useful for local service changes.' in page_folder_review, page_folder_review
    assert 'Community bulletin' in page_folder_review, page_folder_review
    assert 'Feed · community.test' in page_folder_review, page_folder_review
    assert 'New · starts paused' in page_folder_review, page_folder_review
    assert await page.locator('#shared-folder-preview .shared-folder-contents').get_attribute('open') is not None
    await page.locator('#shared-folder-preview summary', has_text='Add just one folder section').click()
    await page.locator('#shared-folder-preview .shared-folder-section-select').select_option('community-local')
    await page.locator('#shared-folder-preview button', has_text='Review this section').click()
    await page.wait_for_function("document.querySelector('#shared-folder-preview').textContent.includes('Adding one folder section')")
    section_review = await page.locator('#shared-folder-preview').inner_text()
    for phrase in ('Community sources › Local notices', 'independent local folder', 'will not rewrite this excerpt', 'Add this section'):
        assert phrase in section_review, (phrase, section_review)
    await page.evaluate("document.activeElement?.blur(); document.querySelector('.skip-link').hidden = true")
    await page.screenshot(path=str(ARTIFACTS / 'reader-shared-folder-section.png'), full_page=True)
    await page.evaluate("document.querySelector('.skip-link').hidden = false")
    await page.locator('#shared-folder-preview button', has_text='Review the full source list').click()
    await page.wait_for_function("document.querySelector('#shared-folder-preview').textContent.includes('Add just one folder section')")
    await page.locator('#shared-folder-preview button', has_text='Back to page options').click()
    await page.wait_for_function("document.querySelector('#discovery').textContent.includes('already following')")

    # The same address field accepts an exact native shared-folder link. The
    # fetch has already happened in the explicit Check action; Review is local.
    await page.locator('#focus-address').click()
    await page.locator('#address').fill('https://example.test/community.json')
    await page.locator('#address-form button[type="submit"]').click()
    await page.wait_for_function("document.querySelector('#discovery').textContent.includes('Source list found')")
    direct_discovery = await page.locator('#discovery').inner_text()
    assert 'Review source list' in direct_discovery, direct_discovery
    assert 'Nothing has been added' in direct_discovery, direct_discovery
    await page.locator('#discovery button', has_text='Review source list').click()
    await page.wait_for_function("document.querySelector('#shared-folder-preview').textContent.includes('Ready to add Community sources')")
    direct_review = await page.locator('#shared-folder-preview').inner_text()
    assert 'fetched only on your request' in direct_review, direct_review
    assert 'new source will start paused' in direct_review, direct_review
    assert 'Community bulletin' in direct_review, direct_review
    assert 'ProgRSS has not contacted any listed site' in direct_review, direct_review
    await page.locator('#shared-folder-preview button', has_text='Back to address result').click()
    await page.wait_for_function("document.querySelector('#discovery').textContent.includes('Source list found')")

    # Return to page discovery. A new feed candidate opens a bounded text-only
    # preview before any source is created, and Back restores the exact page
    # choices and candidate focus.
    await page.locator('#use-current-page').click()
    await page.wait_for_function("document.querySelector('#discovery').textContent.includes('already following')")
    await page.locator('#discovery button', has_text='Preview recent updates').click()
    await page.wait_for_function("document.activeElement?.id === 'feed-preview-heading'")
    edition_preview = await page.locator('.feed-preview').inner_text()
    for phrase in ('summary feed prepared from the source list', 'adds only this feed', 'does not add the underlying feeds or watched pages', 'Follow recent updates'):
        assert phrase in edition_preview, (phrase, edition_preview)
    await page.locator('.feed-preview button', has_text='Back to page options').click()
    await page.wait_for_function("document.activeElement?.id === 'publication-updates-candidate'")
    assert await page.locator('#discovery button', has_text='Preview Community events').is_visible()
    source_count_before = await page.locator('.source-card').count()
    await page.locator('#discovery button', has_text='Preview Community events').click()
    await page.wait_for_function("document.activeElement?.id === 'feed-preview-heading'")
    feed_preview = await page.locator('.feed-preview').inner_text()
    for phrase in ('Community Events', 'Nothing has been followed yet', 'Library repair workshop', 'Neighborhood compost day', 'Quiet reading hour', 'fuller feed text', 'loads no article page'):
        assert phrase in feed_preview, (phrase, feed_preview)
    assert await page.locator('.feed-preview-items li').count() == 3
    assert await page.locator('.source-card').count() == source_count_before
    await page.locator('.feed-preview button', has_text='Back to page options').click()
    await page.wait_for_function("document.activeElement?.id === 'feed-candidate-1'")
    assert await page.locator('#discovery button', has_text='View Garden Notes').is_visible()
    await page.locator('#discovery button', has_text='View Garden Notes').click()
    assert await page.locator('.source-card[data-source-id="feed-one"]').is_visible()
    assert await page.locator('.source-card').count() == source_count_before
    await page.locator('#tab-add').click()
    await page.locator('#focus-address').click()
    assert await page.evaluate("document.activeElement?.id") == 'address'
    await page.locator('#opml-file').set_input_files({"name": "reading-list.opml", "mimeType": "text/xml", "buffer": OPML_SAMPLE})
    await page.wait_for_function("document.querySelector('#opml-preview').textContent.includes('Ready to add 3 feeds')")
    preview_text = await page.locator('#opml-preview').text_content()
    for phrase in ('3new feeds', '1already here', '2duplicates or invalid', '2folders kept', 'Add paused'):
        assert phrase in preview_text.replace('\n', '').replace('  ', '')
    await page.locator('input[name="opml-mode"][value="paused"]').check()
    assert await page.locator('.import-actions .primary').text_content() == 'Add 3 paused'
    assert not await visible_small_targets(page), await visible_small_targets(page)
    await page.add_style_tag(content='body.capture-static .topbar, body.capture-static .bottom-nav { position: static !important; } body.capture-static .skip-link { display: none !important; }')
    await page.evaluate("document.activeElement?.blur(); document.body.classList.add('capture-static')")
    await page.screenshot(path=str(ARTIFACTS / 'reader-add-opml.png'), full_page=True)
    await page.evaluate("document.body.classList.remove('capture-static')")
    await page.locator('.import-actions .primary').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('3 feeds added paused')")
    assert await page.locator('.source-card').count() == 9

    # A full ProgRSS library move is reviewed before replacement, explains
    # destination reconnect work, and keeps a bounded local undo path.
    await page.locator('#tab-add').click()
    await page.locator('#backup-file').set_input_files({"name": "ProgRSS-library.json", "mimeType": "application/json", "buffer": TRANSFER_SAMPLE})
    await page.wait_for_function("document.querySelector('#backup-preview').textContent.includes('Ready to bring in 2 sources')")
    transfer_text = await page.locator('#backup-preview').inner_text()
    assert 'This replaces the library currently here: 9 sources and 2 updates.' in transfer_text
    assert '1 active source across 1 site will show Reconnect.' in transfer_text
    assert 'site access, extension identity' in transfer_text
    assert '30 minutes' in transfer_text
    restore = page.locator('#backup-preview button', has_text='Replace with this library')
    assert await restore.is_disabled()
    await page.locator('.replace-confirm input').check()
    assert await restore.is_enabled()
    assert not await visible_small_targets(page), await visible_small_targets(page)
    await page.screenshot(path=str(ARTIFACTS / 'reader-transfer-review.png'), full_page=True)
    await restore.click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Library moved here')")
    assert await page.locator('#view-sources').is_visible()
    assert await page.locator('.source-card').count() == 2
    moved_here = page.locator('.source-card[data-source-id="moved-reading"]')
    assert 'Site access stays with the other browser' in await moved_here.inner_text()
    assert await page.locator('#library-undo').is_visible()
    assert '9-source library' in await page.locator('#library-undo-message').inner_text()
    await page.locator('#undo-library-move').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('previous library has been restored')")
    assert await page.locator('#library-undo').is_hidden()
    await page.locator('#tab-sources').click()
    assert await page.locator('.source-card').count() == 9

    # A cross-site discovery move is a visible decision, never a silent follow.
    await page.locator('#tab-add').click()

    # A different same-site address that declares the feed already followed is
    # explained before mutation. No second source is created.
    await page.locator('#address').fill('https://example.test/alternate.xml')
    await page.locator('#address-form button[type="submit"]').click()
    await page.wait_for_function("document.querySelector('#discovery').textContent.includes('same feed you already follow')")
    assert await page.locator('#discovery button', has_text='View source').is_visible()
    await page.locator('#discovery button', has_text='View source').click()
    assert await page.locator('.source-card[data-source-id="feed-one"]').is_visible()
    await page.locator('#tab-add').click()

    await page.locator('#address').fill('https://move.example.test/old')
    await page.locator('#address-form button[type="submit"]').click()
    await page.wait_for_function("document.querySelector('#discovery').textContent.includes('moved to another site')")
    redirect_text = await page.locator('.redirect-review').inner_text()
    assert 'ProgRSS stopped before contacting that site' in redirect_text
    assert 'https://move.example.test/old' in redirect_text
    assert 'https://new.example.test/feed.xml' in redirect_text
    assert await page.locator('.redirect-review button', has_text='Continue to new.example.test').is_visible()

    # Following a source ends with a clear human handoff rather than a silent
    # tab change or an empty-looking reader.
    await page.locator('#address').fill('https://fresh.example.test/feed.xml')
    await page.locator('#address-form button[type="submit"]').click()
    await page.wait_for_function("document.querySelector('#discovery').textContent.includes('Garden Notes')")
    direct_feed_preview = await page.locator('.feed-preview').inner_text()
    assert '4 items in this feed response' in direct_feed_preview
    assert 'Seed library opens' in direct_feed_preview
    assert 'Nothing has been followed yet' in direct_feed_preview
    assert await page.locator('.feed-preview-items li').count() == 3
    await page.locator('#discovery button', has_text='Follow this feed').click()
    await page.wait_for_function("document.querySelector('#follow-handoff').hidden === false")
    assert 'Nothing new was available on the first check' in await page.locator('#follow-handoff-message').inner_text()

    # Organization is offered after the useful result, never as a prerequisite.
    assert await page.locator('#follow-handoff-folder').is_visible()
    await page.locator('#follow-handoff-folder select').select_option('folder-practical')
    await page.locator('#follow-handoff-folder button', has_text='Add to folder').click()
    await page.wait_for_function("document.querySelector('#folder-undo-message').textContent.includes('Reading › Practical')")
    assert await page.locator('#folder-undo-row').is_visible()
    await page.locator('#undo-folder-change').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Folder placement undone')")
    await page.locator('#show-followed-source').click()
    assert await page.locator('.source-card[data-source-id="added-10"]').is_visible()
    assert await page.evaluate("document.activeElement?.closest('.source-card')?.dataset.sourceId") == 'added-10'
    await page.locator('#tab-add').click()

    # Two local histories that now point to the same feed are reviewed rather
    # than silently deduplicated. The chosen survivor keeps its operational
    # context, and the repair has one bounded local undo.
    await page.evaluate("chrome.runtime.sendMessage({target:'background',type:'seed-source-repair'})")
    await page.locator('#tab-sources').click()
    await page.wait_for_function("document.querySelector('#source-repair-notice').textContent.includes('possible same-source pair')")
    assert await page.locator('.source-card').count() == 12
    await page.locator('#source-repair-notice button', has_text='Review histories').click()
    await page.wait_for_function("document.querySelector('#repair-review-heading')?.textContent.includes('Compare both histories')")
    repair_text = await page.locator('#source-repair-review').inner_text()
    for phrase in ('Advanced records still refer', '1 blocking record', '2 exact references', 'Receipts', 'read-only'):
        assert phrase.lower() in repair_text.lower(), (phrase, repair_text)
    report_button = page.locator('#source-repair-review button', has_text='See references in Advanced Workbench')
    assert await report_button.is_visible()
    await report_button.click()
    opened_report = await page.evaluate("globalThis.__openedTab?.url || ''")
    assert 'workbench/index.html?' in opened_report and 'repairFirst=repair-main' in opened_report and 'repairSecond=repair-copy' in opened_report, opened_report
    await page.screenshot(path=str(ARTIFACTS / 'reader-source-references-blocked.png'), full_page=True)
    await page.locator('#source-repair-review button', has_text='Close review').click()
    await page.evaluate("chrome.runtime.sendMessage({target:'background',type:'unblock-source-repair'})")
    await page.evaluate("chrome.runtime.sendMessage({target:'background',type:'seed-source-repair-reason-conflict'})")
    await page.locator('#source-repair-notice button', has_text='Review histories').click()
    await page.wait_for_function("document.querySelector('#source-repair-review')?.textContent.includes('Different folder reasons need a decision first')")
    reason_conflict_text = await page.locator('#source-repair-review').inner_text()
    for phrase in ('Different folder reasons need a decision first', 'Field work', 'Useful for current field reports', 'Preserves the older archive route', 'Nothing was combined', 'will not choose a reason automatically'):
        assert phrase.lower() in reason_conflict_text.lower(), (phrase, reason_conflict_text)
    assert await page.locator('#source-repair-review button', has_text='See references in Advanced Workbench').count() == 0
    assert await page.locator('#source-repair-review input[name=repair-survivor]').count() == 0
    await page.screenshot(path=str(ARTIFACTS / 'reader-source-repair-reason-conflict.png'), full_page=True)
    await page.locator('#source-repair-review button', has_text='Close review').click()
    await page.evaluate("chrome.runtime.sendMessage({target:'background',type:'resolve-source-repair-reason-conflict'})")
    await page.locator('#source-repair-notice button', has_text='Review histories').click()
    await page.wait_for_function("document.querySelector('#source-repair-review input[name=repair-survivor]')")
    repair_text = await page.locator('#source-repair-review').inner_text()
    for phrase in ('Which source should remain?', 'Site access', 'Check memory', 'Next check', 'shared address', 'contacts no site'):
        assert phrase.lower() in repair_text.lower(), (phrase, repair_text)
    await page.locator('input[name="repair-survivor"][value="repair-main"]').check()
    await page.locator('#source-repair-review .replace-confirm input').check()
    combine = page.locator('#source-repair-review button', has_text='Combine as one source')
    assert await combine.is_enabled()
    assert not await visible_small_targets(page), await visible_small_targets(page)
    await page.set_viewport_size({"width": 320, "height": 844})
    await page.evaluate("document.documentElement.style.fontSize='20px'")
    repair_overflow = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
    assert repair_overflow <= 1, repair_overflow
    assert not await visible_small_targets(page), await visible_small_targets(page)
    await page.screenshot(path=str(ARTIFACTS / 'reader-source-repair-320-large-text.png'), full_page=True)
    await page.set_viewport_size({"width": 390, "height": 844})
    await page.evaluate("document.documentElement.style.fontSize=''")
    await page.screenshot(path=str(ARTIFACTS / 'reader-source-repair.png'), full_page=True)
    await combine.click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Combined the histories')")
    assert await page.locator('.source-card[data-source-id="repair-main"]').is_visible()
    assert await page.locator('.source-card[data-source-id="repair-copy"]').count() == 0
    assert await page.locator('#source-repair-undo').is_visible()
    assert 'Field Notes (old copy)' in await page.locator('#source-repair-undo-message').inner_text()
    await page.locator('#undo-source-repair').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('two source histories have been restored')")
    assert await page.locator('.source-card[data-source-id="repair-copy"]').is_visible()
    await page.evaluate("chrome.runtime.sendMessage({target:'background',type:'clear-source-repair-fixture'})")
    await page.wait_for_function("document.querySelectorAll('.source-card').length === 10")
    await page.locator('#tab-add').click()

    # The advanced surface remains one deliberate door away.
    await page.locator('.advanced-door summary').click()
    assert await page.locator('#open-workbench').is_visible()

    # A browser that remembers a populated library but opens an empty vault is
    # not shown the ordinary first-run screen. Mutating entry points stop until
    # the person restores a private file or deliberately accepts an empty start.
    await page.evaluate("chrome.runtime.sendMessage({target:'background',type:'seed-library-recovery'})")
    await page.wait_for_function("document.querySelector('#library-recovery').hidden === false")
    recovery_text = await page.locator('#library-recovery').inner_text()
    for phrase in ('local library appears missing', 'last remembered', 'Restore private file', 'Use empty library', 'cannot reconstruct cleared reading history'):
        assert phrase.lower() in recovery_text.lower(), (phrase, recovery_text)
    assert await page.locator('#storage-incident').is_hidden()
    assert await page.locator('#refresh-all').is_disabled()
    assert await page.locator('#use-current-page').is_disabled()
    assert await page.locator('#address').is_disabled()
    assert await page.locator('#opml-file').is_disabled()
    assert await page.locator('#export-library').is_disabled()
    assert not await page.locator('#backup-file').is_disabled()
    await page.locator('#tab-today').click()
    assert 'Your reading library is missing here' in await page.locator('#view-today .empty-state').inner_text()
    assert not await visible_small_targets(page), await visible_small_targets(page)
    await page.screenshot(path=str(ARTIFACTS / 'reader-library-recovery.png'), full_page=True)
    await page.set_viewport_size({"width": 320, "height": 844})
    await page.evaluate("document.documentElement.style.fontSize='20px'")
    recovery_overflow = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
    assert recovery_overflow <= 1, recovery_overflow
    assert not await visible_small_targets(page), await visible_small_targets(page)
    await page.screenshot(path=str(ARTIFACTS / 'reader-library-recovery-320-large-text.png'), full_page=True)
    await page.set_viewport_size({"width": 390, "height": 844})
    await page.evaluate("document.documentElement.style.fontSize=''")

    await page.locator('#accept-empty-library').click()
    await page.wait_for_function("document.querySelector('#library-recovery').hidden === true")
    assert 'Start with something you already know' in await page.locator('#view-today .empty-state').inner_text()
    assert not await page.locator('#address').is_disabled()

    # The alternate path uses the same reviewed private-transfer flow. The file
    # chooser is opened from the visible recovery action, and no replacement
    # acknowledgement is required because the local vault is actually empty.
    await page.evaluate("chrome.runtime.sendMessage({target:'background',type:'seed-library-recovery'})")
    await page.wait_for_function("document.querySelector('#library-recovery').hidden === false")
    async with page.expect_file_chooser() as chooser_info:
        await page.locator('#restore-missing-library').click()
    chooser = await chooser_info.value
    await chooser.set_files({"name": "ProgRSS-library.json", "mimeType": "application/json", "buffer": TRANSFER_SAMPLE})
    await page.wait_for_function("document.querySelector('#backup-preview').textContent.includes('Ready to bring in 2 sources')")
    missing_review = await page.locator('#backup-preview').inner_text()
    assert 'No replacement needed' in missing_review
    assert 'I understand this replaces' not in missing_review
    await page.locator('#backup-preview button', has_text='Bring in this library').click()
    await page.wait_for_function("document.querySelector('#status').textContent.includes('Library moved here')")
    assert await page.locator('#library-recovery').is_hidden()
    assert await page.locator('.source-card').count() == 2
    assert await page.locator('#library-undo').is_hidden()

    # A page-watch alert explains itself in ordinary reading language. Before
    # and Now are semantic text, not live page markup, and the watch policy is
    # visible without exposing selector syntax in the basic reader.
    await page.evaluate("chrome.runtime.sendMessage({target:'background',type:'seed-page-change'})")
    await page.locator('#tab-today').click()
    if await page.locator('#today-folders select').count():
        await page.locator('#today-folders select').select_option('all')
    await page.locator('[data-filter="all"]').click()
    watch_card = page.locator('.item-card[data-item-id="watch-hours|change"]')
    await watch_card.wait_for()
    assert await watch_card.locator('button', has_text='See change').count() == 1
    await watch_card.locator('button', has_text='See change').click()
    await page.wait_for_function("document.activeElement?.id === 'detail-heading'")
    assert await page.locator('#detail-open').text_content() == 'Open watched page'
    assert 'watched main text changed' in (await page.locator('#detail-note').inner_text()).lower()
    assert await page.locator('#detail-body h3', has_text='Why ProgRSS noticed this').count() == 1
    assert await page.locator('#detail-body h3', has_text='Before').count() == 1
    assert await page.locator('#detail-body h3', has_text='Now').count() == 1
    assert await page.locator('#detail-body del').text_content() == 'Library opens Monday at 9. The reading room closes at 6.'
    assert await page.locator('#detail-body ins').text_content() == 'Library opens Tuesday at 10. The reading room closes at 6.'
    assert await page.locator('#detail-body script').count() == 0
    await page.set_viewport_size({"width": 320, "height": 844})
    await page.evaluate("document.documentElement.style.fontSize='20px'")
    watch_overflow = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
    assert watch_overflow <= 1, watch_overflow
    assert not await visible_small_targets(page), await visible_small_targets(page)
    await page.screenshot(path=str(ARTIFACTS / 'reader-page-change-320-large-text.png'), full_page=True)
    await page.set_viewport_size({"width": 390, "height": 844})
    await page.evaluate("document.documentElement.style.fontSize=''")
    await page.locator('#detail-back').click()

    legacy_watch_card = page.locator('.item-card[data-item-id="watch-hours|legacy"]')
    await legacy_watch_card.locator('button', has_text='See change').click()
    assert 'older page-watch alert' in (await page.locator('#detail-note').inner_text()).lower()
    assert 'created before ProgRSS kept readable before-and-after context' in await page.locator('#detail-body').inner_text()
    assert await page.locator('#detail-body h3', has_text='Before').count() == 0
    assert await page.locator('#detail-body h3', has_text='Now').count() == 0
    await page.locator('#detail-back').click()
    await page.locator('#tab-sources').click()
    watch_source = page.locator('.source-card[data-source-id="watch-hours"]')
    await watch_source.locator('summary', has_text='Activity and options').click()
    watch_source_text = await watch_source.inner_text()
    assert 'What this watch notices' in watch_source_text
    assert 'Meaningful wording changes' in watch_source_text
    assert 'Changes smaller than 4 characters are ignored' in watch_source_text
    assert 'Advanced Workbench' in watch_source_text

    # Reading keyboard navigation still works after the richer flows.
    await page.locator('#tab-today').click()
    if await page.locator('#today-folders select').count():
        await page.locator('#today-folders select').select_option('all')
    await page.locator('[data-filter="all"]').click()
    await page.wait_for_function("document.querySelectorAll('.item-card').length > 0")
    await page.locator('#today-heading').focus()
    await page.keyboard.press('j')
    assert await page.evaluate("document.activeElement && document.activeElement.closest('.item-card') !== null")
    overflow = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
    assert overflow <= 1, overflow

    # 320 CSS px reflow, enlarged text, and an accessibility-tree smoke.
    await page.set_viewport_size({"width": 320, "height": 844})
    await page.evaluate("document.documentElement.style.fontSize='20px'")
    await page.locator('#tab-sources').click()
    overflow = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
    assert overflow <= 1, overflow
    assert not await visible_small_targets(page), await visible_small_targets(page)
    cdp = await page.context.new_cdp_session(page)
    tree = await cdp.send('Accessibility.getFullAXTree')
    names = {(node.get('role') or {}).get('value','') + ':' + (node.get('name') or {}).get('value','') for node in tree.get('nodes', [])}
    assert 'heading:Places you follow' in names
    assert any(value.startswith('button:Refresh') for value in names)
    assert any('Activity and options' in value for value in names)
    live_count = await page.locator('[aria-live]').count()
    assert live_count == 2, live_count
    await page.screenshot(path=str(ARTIFACTS / 'reader-320-large-text.png'), full_page=True)
    await page.close()
    return errors


async def workbench(browser) -> list[str]:
    errors: list[str] = []
    page = await browser.new_page(viewport={"width": 390, "height": 844}, device_scale_factor=1)
    page.on('console', lambda msg: errors.append(f"console:{msg.type}:{msg.text}") if msg.type == 'error' else None)
    page.on('pageerror', lambda error: errors.append(f"page:{error}"))
    html_text, scripts = html_without_external_scripts(ROOT / 'workbench' / 'index.html')
    await page.set_content(html_text, wait_until='domcontentloaded')
    await page.add_style_tag(content=(ROOT / 'workbench' / 'styles' / 'workbench-1.css').read_text())
    await page.add_style_tag(content=(ROOT / 'workbench' / 'extension-workbench.css').read_text())
    await page.add_script_tag(content=MOCK)
    for script in scripts:
        await page.add_script_tag(content=script.read_text())

    rss = (ROOT / 'fixtures' / 'sample-rss.xml').read_text()
    atom = (ROOT / 'fixtures' / 'sample-atom.xml').read_text()
    json_feed = (ROOT / 'fixtures' / 'sample-json-feed.json').read_text()
    parsed = await page.evaluate("([rss, atom, jf]) => [ProgRSSCore.parseFeed(rss, 'https://example.test/feed.xml'), ProgRSSCore.parseFeed(atom, 'https://example.test/workshop/feed.atom'), ProgRSSCore.parseFeed(jf, 'https://example.test/library/feed.json')]", [rss, atom, json_feed])
    assert [(row['type'], len(row['items'])) for row in parsed] == [('rss', 2), ('atom', 1), ('json', 1)]
    assert parsed[0]['items'][1]['url'] == 'https://example.test/posts/autumn-planting'
    exported_language = await page.evaluate("() => ProgRSSCore.makeJSONFeed({sources:[{id:'a',language:'AR'}],collections:[],items:[{id:'a|1',sourceId:'a',title:'One',summary:'Text',body:'Text',observedAt:'2026-10-18T00:00:00Z'}]}, 'all')")
    assert exported_language['items'][0]['language'] == 'ar'
    assert exported_language['language'] == 'ar'
    exported_mixed = await page.evaluate("() => ProgRSSCore.makeJSONFeed({sources:[{id:'a',language:'AR'},{id:'b'}],collections:[],items:[{id:'a|1',sourceId:'a',title:'One',summary:'Text',body:'Text',observedAt:'2026-10-18T00:00:00Z'},{id:'b|1',sourceId:'b',title:'Two',summary:'Text',body:'Text',observedAt:'2026-10-18T00:00:01Z'}]}, 'all')")
    assert 'language' not in exported_mixed or exported_mixed['language'] is None

    # The browser parser replays the same byte-identical, local corpus as the CLI.
    corpus_dir = ROOT / 'fixtures' / 'interoperability'
    corpus = json.loads((corpus_dir / 'corpus.json').read_text())
    corpus_passed = 0
    for case in corpus['cases']:
        encoding = {'windows-1252': 'cp1252'}.get(case['decode'], case['decode'])
        body = (corpus_dir / case['file']).read_bytes().decode(encoding)
        result = await page.evaluate("([raw, origin]) => { try { const parsed=ProgRSSCore.parseFeed(raw, origin); const first=parsed.items[0]||{}; const replay={items:[]}; const ingestEventCount=ProgRSSCore.ingestFeed(replay,{id:'corpus-source'},parsed); return {ok:true,type:parsed.type,title:parsed.title,feedUrl:parsed.feedUrl||'',language:parsed.language||'',titleLanguage:parsed.titleLanguage||'',itemCount:parsed.items.length,firstTitle:first.title||'',firstUrl:first.url||'',firstSummary:first.summary||'',firstBody:first.body||'',firstBodyIsSummary:Boolean(first.bodyIsSummary),firstLanguage:first.language||'',firstTitleLanguage:first.titleLanguage||'',firstSummaryLanguage:first.summaryLanguage||'',firstBodyLanguage:first.bodyLanguage||'',firstKey:first.key||'',firstPublished:first.published||'',uniqueKeyCount:new Set(parsed.items.map(row=>String(row.key||''))).size,ingestEventCount,ingestedTitle:replay.items[0]?.title||'',ingestedUrl:replay.items[0]?.url||''}; } catch(error) { return {ok:false,error:String(error?.message||error)}; } }", [body, case['origin']])
        expected = case['expected']
        assert result['ok'] == expected['ok'], (case['id'], result)
        if expected['ok']:
            for key in ('type', 'title', 'feedUrl', 'language', 'titleLanguage', 'itemCount', 'firstTitle', 'firstUrl', 'firstBody', 'firstBodyIsSummary', 'firstLanguage', 'firstTitleLanguage', 'firstSummaryLanguage', 'firstBodyLanguage', 'firstKey', 'uniqueKeyCount', 'ingestEventCount', 'ingestedTitle', 'ingestedUrl'):
                if key in expected:
                    assert result[key] == expected[key], (case['id'], key, result[key], expected[key])
            if expected.get('firstSummaryIncludes'):
                assert expected['firstSummaryIncludes'].lower() in result['firstSummary'].lower(), (case['id'], result)
            if expected.get('firstBodyIncludes'):
                assert expected['firstBodyIncludes'].lower() in result['firstBody'].lower(), (case['id'], result)
            for excluded in expected.get('firstBodyExcludes', []):
                assert excluded.lower() not in result['firstBody'].lower(), (case['id'], excluded, result)
            if expected.get('firstPublishedStartsWith'):
                assert result['firstPublished'].startswith(expected['firstPublishedStartsWith']), (case['id'], result)
        else:
            assert expected.get('errorIncludes', '').lower() in result['error'].lower(), (case['id'], result)
        corpus_passed += 1
    assert corpus_passed == corpus['caseCount'] == 32

    dtd_refused = await page.evaluate("() => { try { ProgRSSCore.parseFeed('<!DOCTYPE rss [<!ENTITY x \"boom\">]><rss version=\"2.0\"><channel><title>&x;</title></channel></rss>', 'https://example.test/feed.xml'); return false; } catch (error) { return /DTD|entity/i.test(String(error.message || error)); } }")
    assert dtd_refused
    opml = '''<?xml version="1.0"?><opml version="2.0"><head><title>Nested</title></head><body><outline text="A"><outline text="B"><outline text="One" xmlUrl="https://one.test/feed.xml"/></outline><outline text="Again" xmlUrl="https://one.test/feed.xml"/><outline text="Bad" xmlUrl="javascript:alert(1)"/></outline></body></opml>'''
    opml_result = await page.evaluate("raw => ProgRSSCore.parseOPMLDetailed(raw)", opml)
    assert opml_result['title'] == 'Nested'
    assert len(opml_result['feeds']) == 1
    assert opml_result['duplicateCount'] == 1
    assert opml_result['invalidCount'] == 1
    assert opml_result['folderCount'] == 2
    opml_dtd_refused = await page.evaluate("() => { try { ProgRSSCore.parseOPMLDetailed('<!DOCTYPE opml [<!ENTITY x \"boom\">]><opml version=\"2.0\"><body/></opml>'); return false; } catch (error) { return /DTD|entity/i.test(String(error.message || error)); } }")
    assert opml_dtd_refused

    await page.evaluate("ProgRSSOpenSourceReferenceReport('repair-main','repair-copy')")
    await page.wait_for_function("!document.querySelector('#source-reference-report').hidden && document.querySelector('#source-reference-status').textContent.includes('1 blocking record')")
    reference_text = await page.locator('#source-reference-report').inner_text()
    for phrase in ('References to these histories', 'Reviewed garden graft', 'Receipts', 'why this blocks the repair', 'Review retirement'):
        assert phrase.lower() in reference_text.lower(), (phrase, reference_text)
    await page.locator('.source-reference-tech summary').click()
    assert '$["sourceId"]' in await page.locator('.source-reference-tech').inner_text()
    reference_overflow = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
    assert reference_overflow <= 2, reference_overflow
    await page.screenshot(path=str(ARTIFACTS / 'workbench-source-references.png'), full_page=True)

    await page.locator('.source-reference-record button', has_text='Review retirement').click()
    await page.wait_for_selector('.receipt-retirement-review')
    retirement_text = await page.locator('.receipt-retirement-review').inner_text()
    for phrase in ('Retire this graft receipt?', 'Canonical receipt digest', 'No source, retained update, permission, validator, schedule, or trust binding is changed.', 'remain preserved as retired evidence'):
        assert phrase.lower() in retirement_text.lower(), (phrase, retirement_text)
    retire_button = page.locator('.receipt-retirement-review button', has_text='Retire receipt')
    assert await retire_button.is_disabled()
    await page.locator('.receipt-retirement-check input').check()
    assert not await retire_button.is_disabled()
    await page.screenshot(path=str(ARTIFACTS / 'workbench-receipt-retirement-review.png'), full_page=True)
    await retire_button.click()
    await page.wait_for_function("document.querySelector('#source-reference-status').textContent.includes('0 blocking records')")
    retired_text = await page.locator('#source-reference-report').inner_text()
    for phrase in ('No blocking Advanced Workbench references remain', 'Receipt retirement can still be undone', 'Preserved retired evidence'):
        assert phrase.lower() in retired_text.lower(), (phrase, retired_text)
    await page.locator('.retired-evidence-group summary').click()
    assert '6b35b7ec8eeb263a957dd6d37e6cd32c41962b147b51a55b9b7e04b4fce5c25f' in await page.locator('.retired-evidence-group').inner_text()
    await page.screenshot(path=str(ARTIFACTS / 'workbench-retired-evidence.png'), full_page=True)
    await page.locator('.receipt-retirement-undo button', has_text='Undo receipt retirement').click()
    await page.wait_for_function("document.querySelector('#source-reference-status').textContent.includes('1 blocking record')")

    await page.wait_for_function("document.querySelector('#vault-status').textContent.toLowerCase().includes('vault')")
    assert await page.locator('.workbench-mode').is_visible()
    assert await page.locator('nav button[data-view="sources"]').is_visible()
    await page.locator('nav button[data-view="sources"]').click()
    assert await page.locator('#view-sources').is_visible()
    await page.locator('nav button[data-view="home"]').click()
    assert await page.locator('#view-home').is_visible()
    overflow = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
    assert overflow <= 2, overflow
    await page.screenshot(path=str(ARTIFACTS / 'workbench-demo.png'), full_page=False)
    await page.close()
    # Expected warnings from opaque-origin IndexedDB/localStorage are not app failures.
    return [row for row in errors if 'SecurityError' not in row and 'IndexedDB' not in row]


async def main() -> int:
    async with async_playwright() as p:
        executable = os.environ.get('PROGRSS_CHROMIUM') or shutil.which('chromium') or shutil.which('chromium-browser') or shutil.which('google-chrome')
        launch = {'headless': True, 'args': ['--no-sandbox']}
        if executable:
            launch['executable_path'] = executable
        browser = await p.chromium.launch(**launch)
        try:
            side_errors = await sidepanel(browser)
            work_errors = await workbench(browser)
        finally:
            await browser.close()
    errors = side_errors + work_errors
    if errors:
        print('\n'.join(errors), file=sys.stderr)
        return 1
    print('PASS side panel: placement-scoped Source Notes add/edit/clear/cancel with two-folder independence, Unicode counting, interruption-preserved draft, stale-write refusal, guarded undo, local-only disclosure, keyboard focus, 44px controls, and 320px enlarged-text reflow; human-first three-way later-copy review with explicit per-conflict wording choices and acquisition-change acknowledgement; optional one-branch source-list adoption as an independent local excerpt; bounded source-list contents review; manual summary-only folder editions with private-state exclusion; contextual neutral site-access decisions with no background mutation; quiet Checking again page-watch confirmation in Following with no alert and optional manual recheck; selector-free broken page-watch repair with bounded examples, no selector leakage, stale-review refusal, fresh baseline, preserved earlier alerts, and guarded undo; feed preview before follow with bounded title/date samples, no summary/body payload, separate Follow decision, and exact Back focus return; direct-address plus page-advertised shared-folder discovery and review, v3 signed shared-folder export plus ready-to-host script-free website ZIP, explicit manual publication check with no automatic apply, and verified local import review with explicit identity limits; page-watch See change detail with reason, semantic Before/Now context, legacy explanation and watch-policy disclosure; attention-first source grouping, one compact private-copy surface, storage recovery, calm starting choices, folder correction, language-aware focused feed reading, source repair, body-aware search, scoped read/undo, move/reconnect decisions, OPML, reviewed library transfer, keyboard/switch paths, accessibility tree, 44px controls, and 320px enlarged-text reflow')
    print('PASS workbench: exact source-reference report with reviewed graft-receipt retirement, preserved evidence and guarded undo, external scripts, 32-case local interoperability corpus, secure nested OPML, advanced navigation, 390px no page overflow')
    print(f'Artifacts: {ARTIFACTS}')
    return 0


if __name__ == '__main__':
    raise SystemExit(asyncio.run(main()))
