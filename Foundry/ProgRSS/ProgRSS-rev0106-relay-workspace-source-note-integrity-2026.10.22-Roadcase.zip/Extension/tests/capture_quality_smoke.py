#!/usr/bin/env python3
"""Exercise the shipped rendered-section extractor against a retained fixture garden."""
from __future__ import annotations

import argparse
import asyncio
import json
import os
from pathlib import Path
import shutil

from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parents[1]
CAPTURE_JS = ROOT / "shared" / "capture.js"
FIXTURES = ROOT / "tests" / "fixtures" / "capture-garden"
ARTIFACTS = Path(os.environ.get("PROGRSS_TEST_ARTIFACTS", "/tmp/progrss-rev0080-validation"))
ARTIFACTS.mkdir(parents=True, exist_ok=True)


async def extract(page, fixture: str, recipe: dict[str, object]) -> dict[str, object]:
    await page.set_content((FIXTURES / fixture).read_text(encoding="utf-8"), wait_until="load")
    await page.add_script_tag(path=str(CAPTURE_JS))
    return await page.evaluate(
        "recipe => ProgRSSCapture.extract('https://fixtures.example/page', 'page-fixture', recipe, '0.80.0')",
        recipe,
    )


def notice_kinds(result: dict[str, object]) -> set[str]:
    return {str(row["kind"]) for row in result["context"]["notices"]}


async def run(headless: bool = True) -> dict[str, object]:
    async with async_playwright() as playwright:
        executable = os.environ.get("PROGRSS_CHROMIUM") or shutil.which("chromium") or shutil.which("chromium-browser") or shutil.which("google-chrome")
        launch: dict[str, object] = {"headless": headless, "args": ["--no-sandbox", "--disable-dev-shm-usage"]}
        if executable:
            launch["executable_path"] = executable
        browser = await playwright.chromium.launch(**launch)
        page = await browser.new_page(viewport={"width": 1100, "height": 900})

        semantic = await extract(page, "semantic-hidden.html", {
            "mode": "cards", "selector": ".old-list", "titleSelector": "h2",
            "linkSelector": "a[href]", "threshold": 1, "ignoreNumbers": False,
        })
        assert semantic["schema"] == "progrss.browser-capture-candidates.v3"
        assert semantic["context"]["schema"] == "progrss.capture-page-context.v1"
        repeated = next(row for row in semantic["candidates"] if row["id"] == "repeated")
        assert repeated["recipe"]["selector"] == "main article"
        assert repeated["capture"]["matchCount"] == 3
        assert repeated["assessment"]["level"] == "steadier"
        assert repeated["assessment"]["signals"]["hiddenMatches"] == 1
        assert repeated["assessment"]["signals"]["semanticBoundary"] is True
        assert repeated["assessment"]["signals"]["linkedEntries"] == 3
        assert "Account" in repeated["examples"]["ignored"]

        pagination = await extract(page, "pagination.html", {
            "mode": "cards", "selector": "main article", "titleSelector": "h2",
            "linkSelector": "a[href]", "threshold": 1, "ignoreNumbers": False,
        })
        assert "continuation" in notice_kinds(pagination)
        assert pagination["context"]["signals"]["continuationLinks"] >= 1
        assert pagination["context"]["signals"]["paginationLandmarks"] >= 1

        virtualized = await extract(page, "virtualized.html", {
            "mode": "cards", "selector": ".virtual-list article", "titleSelector": "h2",
            "linkSelector": "a[href]", "threshold": 1, "ignoreNumbers": False,
        })
        assert "partial-render" in notice_kinds(virtualized)
        assert virtualized["context"]["signals"]["partialSetSignals"] >= 1
        assert virtualized["context"]["signals"]["virtualMarkers"] >= 1
        assert virtualized["context"]["signals"]["scrollWindows"] >= 1

        shifted = await extract(page, "virtualized-shifted.html", {
            "mode": "cards", "selector": ".virtual-list article", "titleSelector": "h2",
            "linkSelector": "a[href]", "threshold": 1, "ignoreNumbers": False,
        })
        assert "partial-render" in notice_kinds(shifted)
        first_window = next(row for row in virtualized["candidates"] if row["id"] == "saved")
        second_window = next(row for row in shifted["candidates"] if row["id"] == "saved")
        first_keys = {row["key"] for row in first_window["capture"]["cards"]}
        second_keys = {row["key"] for row in second_window["capture"]["cards"]}
        assert first_keys and second_keys and first_keys.isdisjoint(second_keys)

        duplicates = await extract(page, "duplicate-layouts.html", {
            "mode": "cards", "selector": "main article", "titleSelector": "h2",
            "linkSelector": "a[href]", "threshold": 1, "ignoreNumbers": False,
        })
        duplicate_saved = next(row for row in duplicates["candidates"] if row["id"] == "saved")
        assert duplicate_saved["capture"]["matchCount"] == 3
        assert duplicate_saved["assessment"]["signals"]["hiddenMatches"] == 3

        mixed = await extract(page, "mixed-ads.html", {
            "mode": "cards", "selector": "main article", "titleSelector": "h2",
            "linkSelector": "a[href]", "threshold": 1, "ignoreNumbers": False,
        })
        mixed_saved = next(row for row in mixed["candidates"] if row["id"] == "saved")
        assert mixed_saved["assessment"]["signals"]["clutterElements"] >= 1
        assert any("navigation, forms, sidebars, or footer" in row for row in mixed_saved["assessment"]["warnings"])

        overlay = await extract(page, "overlay.html", {
            "mode": "cards", "selector": "main article", "titleSelector": "h2",
            "linkSelector": "a[href]", "threshold": 1, "ignoreNumbers": False,
        })
        assert "overlay" in notice_kinds(overlay)
        assert overlay["context"]["signals"]["modalLayers"] >= 1

        shadow = await extract(page, "frames-shadow.html", {
            "mode": "cards", "selector": "article", "titleSelector": "h2",
            "linkSelector": "a[href]", "threshold": 1, "ignoreNumbers": False,
        })
        assert {"frames", "open-shadow"}.issubset(notice_kinds(shadow))
        assert shadow["context"]["signals"]["embeddedFrames"] == 1
        assert shadow["context"]["signals"]["openShadowRoots"] == 1
        shadow_saved = next(row for row in shadow["candidates"] if row["id"] == "saved")
        assert shadow_saved["capture"]["matchCount"] == 3
        assert shadow_saved["capture"]["cards"][0]["title"].startswith("Shadow notice")

        busy = await extract(page, "busy.html", {
            "mode": "cards", "selector": "main article", "titleSelector": "h2",
            "linkSelector": "a[href]", "threshold": 1, "ignoreNumbers": False,
        })
        assert "loading" in notice_kinds(busy)
        assert busy["context"]["signals"]["busyRegions"] == 1

        rtl_pagination = await extract(page, "rtl-pagination.html", {
            "mode": "cards", "selector": "main article", "titleSelector": "h2",
            "linkSelector": "a[href]", "threshold": 1, "ignoreNumbers": False,
        })
        assert rtl_pagination["page"]["direction"] == "rtl"
        assert "continuation" in notice_kinds(rtl_pagination)

        closed = await extract(page, "closed-shadow.html", {
            "mode": "cards", "selector": "article", "titleSelector": "h2",
            "linkSelector": "a[href]", "threshold": 1, "ignoreNumbers": False,
        })
        assert "open-shadow" not in notice_kinds(closed)
        assert closed["context"]["signals"]["openShadowRoots"] == 0
        closed_saved = next(row for row in closed["candidates"] if row["id"] == "saved")
        assert closed_saved["capture"]["matchCount"] == 1
        assert closed_saved["capture"]["cards"][0]["title"] == "Visible notice"

        rtl = await extract(page, "rtl.html", {
            "mode": "region", "selector": "main", "titleSelector": "",
            "linkSelector": "", "threshold": 1, "ignoreNumbers": False,
        })
        assert rtl["page"]["language"] == "ar"
        assert rtl["page"]["direction"] == "rtl"
        assert rtl["provenance"]["extractorRevision"] == "perimeter-v1"
        assert all(len(row["assessment"]["reasons"]) <= 4 for row in rtl["candidates"])
        assert all(len(row["assessment"]["warnings"]) <= 4 for row in rtl["candidates"])

        await page.set_content((FIXTURES / "garden.html").read_text(encoding="utf-8"), wait_until="load")
        await page.screenshot(path=str(ARTIFACTS / "drift-specimen-garden.png"), full_page=True)
        await browser.close()

    return {
        "schema": "progrss.capture-quality-smoke.v3",
        "cases": 12,
        "semanticRepeated": "steadier",
        "pageBoundaryKinds": ["continuation", "partial-render", "overlay", "loading", "frames", "open-shadow"],
        "openShadowCards": 3,
        "virtualWindowsDisjoint": True,
        "hiddenDuplicateCards": 3,
        "closedShadowExcluded": True,
        "rtlDirection": "rtl",
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--headed", action="store_true")
    args = parser.parse_args()
    result = asyncio.run(run(headless=not args.headed))
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
