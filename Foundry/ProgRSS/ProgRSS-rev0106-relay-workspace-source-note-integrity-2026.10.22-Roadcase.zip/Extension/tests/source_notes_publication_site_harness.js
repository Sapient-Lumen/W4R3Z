'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const family = process.env.PROGRSS_EXTENSION_ROOT || '';
const root = path.resolve(__dirname, '..', family);
const context = {
  console, URL, TextEncoder, TextDecoder, crypto: require('crypto').webcrypto,
  structuredClone: global.structuredClone,
  atob: value => Buffer.from(value, 'base64').toString('binary'),
  btoa: value => Buffer.from(value, 'binary').toString('base64'),
  setTimeout, clearTimeout
};
context.globalThis = context;
context.window = context;
context.self = context;
vm.createContext(context);
for (const relative of ['shared/core.js', 'shared/shared-folder.js', 'shared/publication-site.js']) {
  vm.runInContext(fs.readFileSync(path.join(root, relative), 'utf8'), context, {filename: relative});
}
const C = context.ProgRSSCore;
const F = context.ProgRSSSharedFolder;
const S = context.ProgRSSPublicationSite;
assert(C && F && S, 'publication-site dependencies should load');

function storedZipEntries(bytes) {
  const buffer = Buffer.from(bytes);
  const entries = new Map();
  let offset = 0;
  while (offset + 4 <= buffer.length && buffer.readUInt32LE(offset) === 0x04034b50) {
    const method = buffer.readUInt16LE(offset + 8);
    const size = buffer.readUInt32LE(offset + 18);
    const nameLength = buffer.readUInt16LE(offset + 26);
    const extraLength = buffer.readUInt16LE(offset + 28);
    assert.strictEqual(method, 0);
    const nameStart = offset + 30;
    const dataStart = nameStart + nameLength + extraLength;
    const name = buffer.subarray(nameStart, nameStart + nameLength).toString('utf8');
    entries.set(name, buffer.subarray(dataStart, dataStart + size));
    offset = dataStart + size;
  }
  return entries;
}

async function buildSite() {
  const state = {
    sources: [
      {id: 'shared', type: 'rss', title: 'Same source', url: 'https://example.com/feed', enabled: true},
      {id: 'plain', type: 'rss', title: 'No reason', url: 'https://plain.example/feed', enabled: true}
    ],
    collections: [
      {id: 'root', title: 'Shared reasons', mode: 'union', members: [
        {kind: 'collection', id: 'alpha'},
        {kind: 'collection', id: 'beta'}
      ]},
      {id: 'alpha', title: 'Folder Alpha', mode: 'union', members: [
        {kind: 'source', id: 'shared', reason: 'Reason Alpha <safe>.\nSecond line & more.'},
        {kind: 'source', id: 'plain'}
      ]},
      {id: 'beta', title: 'Folder Beta', mode: 'union', members: [
        {kind: 'source', id: 'shared', reason: 'Reason Beta.'}
      ]}
    ]
  };
  const portable = C.exportBundle(state, 'root');
  const located = await F.create(portable, {
    curator: 'Neighborhood <desk>',
    note: 'A public route with placement reasons.',
    updateUrl: 'https://example.com/shared/latest.json',
    exportedAt: '2026-10-21T12:00:00.000Z'
  });
  const built = S.build(JSON.stringify(located));
  return {state, portable, located, built};
}

(async () => {
  const first = await buildSite();
  const second = await buildSite();
  assert.deepStrictEqual(Buffer.from(first.built.bytes), Buffer.from(second.built.bytes), 'publication ZIP should be deterministic');
  assert.deepStrictEqual(first.built.summary, second.built.summary);
  assert.strictEqual(first.built.summary.sourceNotes, 2);
  assert.strictEqual(first.built.summary.feeds, 2);
  assert.strictEqual(first.built.summary.folders, 3);

  const entries = storedZipEntries(first.built.bytes);
  assert.deepStrictEqual(Array.from(entries.keys()).sort(), ['README.txt', 'index.html', 'latest.json', 'subscriptions.opml']);
  const page = entries.get('index.html').toString('utf8');
  const native = JSON.parse(entries.get('latest.json').toString('utf8'));
  const opml = entries.get('subscriptions.opml').toString('utf8');
  const readme = entries.get('README.txt').toString('utf8');

  assert.strictEqual(JSON.stringify(native), JSON.stringify(first.located));
  assert.strictEqual((page.match(/Curator’s reason for this folder:/g) || []).length, 2);
  assert.strictEqual((page.match(/Same source/g) || []).length, 2);
  assert(page.includes('Reason Alpha &lt;safe&gt;.\nSecond line &amp; more.'));
  assert(page.includes('Reason Beta.'));
  assert(!page.includes('Reason Alpha <safe>'));
  assert(page.includes('not a ProgRSS safety claim'));
  assert(page.includes('2 curator reasons'));
  assert(page.includes('dir="auto"'));
  assert(page.includes('white-space:pre-wrap'));
  assert(!/<script\b/i.test(page));
  assert(!opml.includes('Reason Alpha'));
  assert(!opml.includes('Reason Beta'));
  assert(readme.includes('2 curator-written folder reasons'));
  assert(readme.includes('OPML carries feeds and hierarchy only'));

  const wrongLevel = JSON.parse(JSON.stringify(first.located));
  wrongLevel.collections[0].members[0].reason = 'Wrong level';
  assert.throws(() => S.build(JSON.stringify(wrongLevel)), /Only a direct source placement/);

  const overLimit = JSON.parse(JSON.stringify(first.located));
  overLimit.collections[1].members[0].reason = 'x'.repeat(281);
  assert.throws(() => S.build(JSON.stringify(overLimit)), /280 Unicode code points/);

  console.log('PASS Source Notes publication-site disclosure: 12 checks');
})().catch(error => {
  console.error(error && error.stack || error);
  process.exitCode = 1;
});
