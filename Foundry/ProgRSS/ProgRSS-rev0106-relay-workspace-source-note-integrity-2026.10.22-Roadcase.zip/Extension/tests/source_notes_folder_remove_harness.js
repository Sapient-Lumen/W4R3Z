// Managed production-handler tests with in-memory browser API doubles. Not an installed-browser run.
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const ROOT = path.resolve(__dirname, '..', process.env.PROGRSS_EXTENSION_ROOT || '.');
const FAMILY = process.env.PROGRSS_EXTENSION_ROOT === 'Firefox' ? 'generated-Firefox' : 'Chromium-source';

const storage = new Map();
const extensionStorage = new Map();
let failVaultWrites = false;
let pageExtractContent = 'Library opens Monday at 9.';
let pageExtractErrorCode = '';
let pageRepairVariant = 0;
globalThis.localStorage = {
  getItem(key) { return storage.has(key) ? storage.get(key) : null; },
  setItem(key, value) {
    if (failVaultWrites) {
      const error = Error('quota exceeded while writing the test vault');
      error.name = 'QuotaExceededError';
      throw error;
    }
    storage.set(key, String(value));
  },
  removeItem(key) { storage.delete(key); }
};

const messageListeners = [];
const alarms = [];
globalThis.chrome = {
  storage: {
    local: {
      async get(key) {
        if (key == null) return Object.fromEntries(extensionStorage);
        const keys = Array.isArray(key) ? key : [key];
        return Object.fromEntries(keys.filter(value => extensionStorage.has(value)).map(value => [value, extensionStorage.get(value)]));
      },
      async set(values) { for (const [key, value] of Object.entries(values || {})) extensionStorage.set(key, value); },
      async remove(key) { for (const value of (Array.isArray(key) ? key : [key])) extensionStorage.delete(value); }
    }
  },
  permissions: {
    async contains() { return true; },
    async getAll() { return {permissions: [], origins: ['https://example.test/*']}; }
  },
  runtime: {
    getURL(value) { return `chrome-extension://test/${value}`; },
    getManifest() { return {version: '0.80.0'}; },
    async getContexts() { return []; },
    async sendMessage(message) {
      if (message?.target === 'offscreen') {
        if (message.type === 'parse-feed') {
          return {ok: true, result: {
            title: 'Harness Feed', titleLanguage: 'en-GB', language: 'en-GB', type: 'rss', feedUrl: 'https://example.test/feed.xml', items: [
              {key: 'entry-1', title: 'A new entry', url: 'https://example.test/post/1', summary: 'ملخص الاختبار', body: 'نص الاختبار\n\nفقرة ثانية محفوظة.', bodyIsSummary: false, language: 'AR', titleLanguage: 'EN', summaryLanguage: 'AR', bodyLanguage: 'AR', published: '2026-10-17T12:00:00.000Z'}
            ]
          }};
        }
        if (message.type === 'parse-opml') {
          return {ok: true, result: {
            title: 'Harness subscriptions', feedOutlines: 4, invalidCount: 1, duplicateCount: 1, truncatedCount: 0, folderCount: 2,
            feeds: [
              {title: 'Harness Feed', url: 'https://example.test/feed.xml', folderPaths: [['Reading']]},
              {title: 'Independent Notes', url: 'https://new.test/feed.xml', folderPaths: [['Reading', 'Independent']]},
              {title: 'Other Notes', url: 'https://other.test/atom.xml', folderPaths: [['Reading']]}
            ]
          }};
        }
        if (message.type === 'inspect-resource') return {ok: true, result: {kind: 'feed', url: message.data.url, title: 'Harness Feed', titleLanguage: 'en-GB', language: 'en-GB', feedType: 'rss', feedUrl: 'https://example.test/feed.xml', itemCount: 1, previewCount: 1, previewFullTextCount: 1, previewSummaryCount: 0, previewDatedCount: 1, previewItems: [{title: 'A new entry', url: 'https://example.test/post/1', published: '2026-10-17T12:00:00.000Z', content: 'full-text', language: 'ar', titleLanguage: 'en'}]}};
        if (message.type === 'extract-page') {
          if (pageExtractErrorCode) return {ok: false, error: 'The watched section is missing.', code: pageExtractErrorCode, detail: {field: 'selector'}};
          return {ok: true, result: {mode: 'region', content: pageExtractContent, matchCount: 1, meaningfulCount: 1, contentChars: pageExtractContent.length}};
        }
        if (message.type === 'repair-page-watch') {
          const content = pageRepairVariant ? `${pageExtractContent} changed after review` : pageExtractContent;
          return {ok: true, result: [{
            schema: 'progrss.page-watch.repair.v1', title: 'Watch the page’s main text',
            description: 'Notice meaningful wording changes in the main part of the page.',
            mode: 'region', count: 1, examples: [], preview: content,
            recipe: {mode: 'region', selector: 'main', titleSelector: '', linkSelector: '', threshold: 4, ignoreNumbers: false},
            evidence: {signature: `region:${content}`, matchCount: 1, contentChars: content.length},
            capture: {mode: 'region', content, matchCount: 1, meaningfulCount: 1, contentChars: content.length}
          }]};
        }
      }
      return undefined;
    },
    onMessage: { addListener(listener) { messageListeners.push(listener); } },
    onInstalled: { addListener() {} },
    onStartup: { addListener() {} }
  },
  offscreen: { async createDocument() {} },
  action: {
    async setBadgeBackgroundColor() {}, async setBadgeText() {}, async setTitle() {}
  },
  sidePanel: { async setPanelBehavior() {} },
  alarms: { async create(name, details) { alarms.push({name, details}); }, onAlarm: { addListener() {} } },
  tabs: { async query() { return [{id: 1, url: 'https://example.test/', title: 'Example'}]; } },
  scripting: { async executeScript() { return [{result: {url: 'https://example.test/', title: 'Example', links: []}}]; } }
};

let fetchMode = 'normal';
let publicationPayload = '';
let publicationContentType = 'application/vnd.progrss.shared-folder+json; charset=utf-8';
const fetchCalls = [];
globalThis.fetch = async (url, options) => {
  fetchCalls.push({url: String(url), options});
  if (fetchMode === 'large') {
    return new Response('too large', {status: 200, headers: {'Content-Type': 'application/rss+xml', 'Content-Length': '2000001'}});
  }
  if (fetchMode === 'page') {
    return new Response(`<html><body><main>${pageExtractContent}</main></body></html>`, {
      status: 200, headers: {'Content-Type': 'text/html; charset=utf-8'}
    });
  }
  if (fetchMode === 'publication') {
    return new Response(publicationPayload, {
      status: 200, headers: {'Content-Type': publicationContentType, 'Content-Length': String(Buffer.byteLength(publicationPayload))}
    });
  }
  if (options?.headers?.['If-None-Match'] === '"harness-v1"') {
    return new Response(null, {status: 304, headers: {'ETag': '"harness-v1"', 'Last-Modified': 'Fri, 17 Oct 2026 12:00:00 GMT'}});
  }
  return new Response(
    '<rss><channel><title>Harness Feed</title><item><guid>entry-1</guid><title>A new entry</title></item></channel></rss>',
    {status: 200, headers: {'Content-Type': 'application/rss+xml', 'Content-Length': '120', 'ETag': '"harness-v1"', 'Last-Modified': 'Fri, 17 Oct 2026 12:00:00 GMT'}}
  );
};

globalThis.importScripts = (...files) => {
  for (const file of files) {
    const code = fs.readFileSync(path.join(ROOT, file), 'utf8');
    vm.runInThisContext(code, {filename: file});
  }
};

if (FAMILY === 'generated-Firefox') {
  globalThis.browser = globalThis.chrome;
  browser.runtime.getURL = value => `moz-extension://test/${String(value).replace(/^\//, '')}`;
  browser.sidebarAction = {async open() {}};
  browser.action.onClicked = {addListener() {}};
  delete browser.sidePanel;
  delete browser.offscreen;
}
vm.runInThisContext(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8'), {filename: 'background.js'});
assert.strictEqual(messageListeners.length, 1, 'background message listener registered');
const listener = messageListeners[0];

function setBackupReminderFixture(marker) {
  extensionStorage.set('progrssBackupReminder', marker);
  vm.runInThisContext(`volatileBackupReminder = ${JSON.stringify(marker)};`);
}

function message(type, data = {}) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timeout = setTimeout(() => { if (!settled) reject(new Error(`timeout: ${type}`)); }, 1500);
    const keep = listener({target: 'background', type, data}, {}, response => {
      settled = true;
      clearTimeout(timeout);
      resolve(response);
    });
    assert.strictEqual(keep, true, `${type} keeps response channel open`);
  });
}


const cases = [];
function test(name, fn) { cases.push([name, fn]); }
const snapshot = async () => JSON.stringify(await ProgRSSVault.init());
async function fixture(reason = 'Direct reason.', version = 1) {
  await message('get-state');
  const state = await ProgRSSVault.init();
  const member = {kind: 'source', id: 'one'};
  if (reason !== undefined) member.reason = reason;
  state.sources = ['one', 'two', 'three'].map(id => ({
    id, title: id, type: 'rss', url: `https://notes.example/${id}.xml`, enabled: false
  }));
  state.items = [];
  state.collections = [
    {id: 'parent', title: 'Parent', mode: 'union', version, members: [
      {kind: 'source', id: 'two'}, member, {kind: 'collection', id: 'child'}, {kind: 'source', id: 'three'}
    ]},
    {id: 'child', title: 'Child', mode: 'union', version: 1, members: [
      {kind: 'source', id: 'one', reason: 'Child reason.'}
    ]},
    {id: 'other', title: 'Other', mode: 'union', version: 1, members: [
      {kind: 'source', id: 'one', reason: 'Other reason.'}
    ]}
  ];
  await ProgRSSVault.save(state);
  return ProgRSSVault.init();
}
const folder = (state, id='parent') => state.collections.find(c => c.id === id);
async function removalReview(collectionId='parent', sourceId='one') {
  const state = await ProgRSSVault.init();
  const target = folder(state, collectionId);
  const matches = (target?.members || []).filter(member => member?.kind === 'source' && member.id === sourceId);
  assert.strictEqual(matches.length, 1, 'reviewed removal needs one direct placement');
  const member = matches[0];
  return {
    sourceId, collectionId,
    expectedVersion: Math.max(1, Math.round(Number(target.version) || 1)),
    expectedRevision: state._revision,
    expectedReason: Object.hasOwn(member, 'reason') ? member.reason : null
  };
}
async function remove(collectionId='parent', sourceId='one') {
  const response = await message('remove-source-from-folder', await removalReview(collectionId, sourceId));
  assert.strictEqual(response.ok, true, response.error);
  assert.strictEqual(response.result.removed, true);
  return response.result;
}
function undoPayload(removed) {
  return {sourceId: removed.sourceId, collectionId: removed.collectionId,
    expectedVersion: removed.folderVersion, expectedRevision: removed.expectedRevision,
    removedMember: removed.removedMember, removedIndex: removed.removedIndex};
}
async function undo(removed) {
  const response = await message('undo-source-folder-remove', undoPayload(removed));
  assert.strictEqual(response.ok, true, response.error);
  assert.strictEqual(response.result.added, true);
  return ProgRSSVault.init();
}
async function refuse(payload, code) {
  const before = await snapshot();
  const response = await message('undo-source-folder-remove', payload);
  assert.strictEqual(response.ok, false, 'invalid or stale undo must be refused');
  assert.strictEqual(response.code, code);
  assert.strictEqual(await snapshot(), before, 'refusal must not alter persisted state');
}

async function add(collectionId='child', sourceId='two') {
  const response = await message('add-source-to-folder', {sourceId, collectionId});
  assert.strictEqual(response.ok, true, response.error);
  assert.strictEqual(response.result.added, true);
  assert(Number.isSafeInteger(response.result.expectedRevision), 'add returns committed vault revision');
  return response.result;
}
function addUndoPayload(added) {
  return {sourceId: added.sourceId, collectionId: added.collectionId,
    expectedVersion: added.folderVersion, expectedRevision: added.expectedRevision};
}
async function undoAdd(added) {
  const response = await message('undo-source-folder-add', addUndoPayload(added));
  assert.strictEqual(response.ok, true, response.error);
  assert.strictEqual(response.result.removed, true);
  return ProgRSSVault.init();
}
async function refuseAdd(payload, code='STALE_FOLDER_UNDO') {
  const before = await snapshot();
  const response = await message('undo-source-folder-add', payload);
  assert.strictEqual(response.ok, false, 'invalid or stale add undo must be refused');
  assert.strictEqual(response.code, code);
  assert.strictEqual(await snapshot(), before, 'refusal must not alter persisted state');
}
async function setFolderVersion(id, version) {
  const state = await ProgRSSVault.init();
  folder(state, id).version = version;
  await ProgRSSVault.save(state);
  return ProgRSSVault.init();
}


async function refuseRemoval(payload, code) {
  const before = await snapshot();
  const response = await message('remove-source-from-folder', payload);
  assert.strictEqual(response.ok, false, 'stale or incomplete removal review must be refused');
  assert.strictEqual(response.code, code, response.error);
  assert.strictEqual(await snapshot(), before, 'refusal must not alter persisted state');
  return response;
}

test('exact reviewed removal preserves complete relationship and position', async () => {
  const before = await fixture('Reviewed reason.', 4);
  const review = await removalReview();
  const response = await message('remove-source-from-folder', review);
  assert(response.ok && response.result.removed, response.error);
  assert.deepStrictEqual(response.result.removedMember, {kind:'source', id:'one', reason:'Reviewed reason.'});
  assert.strictEqual(response.result.removedIndex, 1);
  assert.strictEqual(response.result.folderVersion, 5);
  const after = await ProgRSSVault.init();
  assert(!folder(after).members.some(member => member.kind === 'source' && member.id === 'one'));
  assert.deepStrictEqual(folder(before,'child'), folder(after,'child'));
});

test('reviewed absent reason can be removed without inventing a field', async () => {
  await fixture(undefined, 3);
  const state = await ProgRSSVault.init();
  delete folder(state).members[1].reason;
  await ProgRSSVault.save(state);
  const review = await removalReview();
  assert.strictEqual(review.expectedReason, null);
  const response = await message('remove-source-from-folder', review);
  assert(response.ok && response.result.removed, response.error);
  assert(!Object.hasOwn(response.result.removedMember, 'reason'));
});

test('missing reviewed version or reason is refused', async () => {
  await fixture();
  const review = await removalReview();
  const missingVersion = {...review}; delete missingVersion.expectedVersion;
  await refuseRemoval(missingVersion, 'INVALID_FOLDER_REMOVE_REVIEW');
  const missingReason = {...review}; delete missingReason.expectedReason;
  await refuseRemoval(missingReason, 'INVALID_FOLDER_REMOVE_REVIEW');
});

test('wrong reviewed folder version is refused', async () => {
  await fixture();
  const review = await removalReview();
  await refuseRemoval({...review, expectedVersion: review.expectedVersion + 1}, 'STALE_FOLDER_REMOVE');
});

test('newer reason below the ceiling is preserved from a stale remove', async () => {
  await fixture('Visible in view A.', 1);
  const review = await removalReview();
  const edit = await message('set-source-placement-reason', {
    sourceId:'one', collectionId:'parent', expectedVersion:1,
    expectedRevision:review.expectedRevision, expectedReason:'Visible in view A.', reason:'Newer wording from view B.'
  });
  assert(edit.ok && edit.result.changed, edit.error);
  await refuseRemoval(review, 'STALE_FOLDER_REMOVE');
  assert.strictEqual(folder(await ProgRSSVault.init()).members[1].reason, 'Newer wording from view B.');
});

test('saturated exact review succeeds only with exact persisted revision', async () => {
  await fixture('At ceiling.', 10000);
  const review = await removalReview();
  const missing = {...review}; delete missing.expectedRevision;
  await refuseRemoval(missing, 'STALE_FOLDER_REMOVE');
  await refuseRemoval({...review, expectedRevision: review.expectedRevision + 1}, 'STALE_FOLDER_REMOVE');
  const response = await message('remove-source-from-folder', review);
  assert(response.ok && response.result.removed, response.error);
});

test('saturated stale review cannot delete a removed-and-restored replacement', async () => {
  await fixture('Same wording.', 10000);
  const oldReview = await removalReview();
  const first = await message('remove-source-from-folder', oldReview);
  assert(first.ok && first.result.removed, first.error);
  const restored = await message('undo-source-folder-remove', undoPayload(first.result));
  assert(restored.ok && restored.result.added, restored.error);
  await refuseRemoval(oldReview, 'STALE_FOLDER_REMOVE');
  const current = await ProgRSSVault.init();
  assert.strictEqual(folder(current).members[1].reason, 'Same wording.');
});

test('below-ceiling unrelated vault write does not invalidate reviewed removal', async () => {
  await fixture('Parent wording.', 2);
  const review = await removalReview();
  const edit = await message('set-source-placement-reason', {
    sourceId:'one', collectionId:'other', expectedVersion:1,
    expectedReason:'Other reason.', reason:'Other updated.'
  });
  assert(edit.ok && edit.result.changed, edit.error);
  const response = await message('remove-source-from-folder', review);
  assert(response.ok && response.result.removed, response.error);
  assert.strictEqual(folder(await ProgRSSVault.init(),'other').members[0].reason, 'Other updated.');
});

test('saturated unrelated vault write conservatively invalidates reviewed removal', async () => {
  await fixture('Parent wording.', 10000);
  const review = await removalReview();
  const edit = await message('set-source-placement-reason', {
    sourceId:'one', collectionId:'other', expectedVersion:1,
    expectedReason:'Other reason.', reason:'Other updated at cap.'
  });
  assert(edit.ok && edit.result.changed, edit.error);
  await refuseRemoval(review, 'STALE_FOLDER_REMOVE');
});

test('ambiguous duplicate placement is refused without mutation', async () => {
  await fixture('First reason.', 8);
  const state = await ProgRSSVault.init();
  folder(state).members.push({kind:'source', id:'one', reason:'Second reason.'});
  await ProgRSSVault.save(state);
  const current = await ProgRSSVault.init();
  await refuseRemoval({
    sourceId:'one', collectionId:'parent', expectedVersion:8,
    expectedRevision:current._revision, expectedReason:'First reason.'
  }, 'STALE_FOLDER_REMOVE');
});

test('inherited-only or missing direct placement is refused as stale', async () => {
  await fixture();
  const exact = await removalReview();
  const removed = await message('remove-source-from-folder', exact);
  assert(removed.ok && removed.result.removed, removed.error);
  const current = await ProgRSSVault.init();
  await refuseRemoval({
    sourceId:'one', collectionId:'parent', expectedVersion:folder(current).version,
    expectedRevision:current._revision, expectedReason:null
  }, 'STALE_FOLDER_REMOVE');
});

test('invalid reviewed reason values are refused', async () => {
  await fixture();
  const review = await removalReview();
  for (const expectedReason of ['😀'.repeat(281), '\ud800', 12, {}]) {
    await refuseRemoval({...review, expectedReason}, 'INVALID_SOURCE_NOTE');
  }
});

test('side panel forwards the displayed version revision and reason', async () => {
  await fixture('Displayed reason.', 9);
  const persisted = await ProgRSSVault.init();
  const reviewedCollection = folder(persisted);
  const reviewedFolder = {id:'parent', path:'Parent', collection:reviewedCollection};
  const code = fs.readFileSync(path.join(ROOT,'sidepanel/app.js'),'utf8');
  const start = code.indexOf('  async function removeSourceFromFolder(');
  const end = code.indexOf('  function sourceNotePlacementKey(', start);
  assert(start >= 0 && end > start);
  let armed = null; const requests = [];
  const app = {folderUndo:null, state:{revision:persisted._revision}};
  const ctx = {app, els:{undoFolderChange:{}}, clearTimeout(){},
    text:value=>value, readableList:rows=>rows.join(', '),
    async loadState(){}, renderFolderUndo(){}, setStatus(){},
    armFolderUndo(value){armed=value;app.folderUndo=value;},
    async request(type,data){requests.push({type,data});const response=await message(type,data);
      if(!response.ok){const error=new Error(response.error);error.code=response.code;throw error;}return response.result;}
  };
  vm.createContext(ctx); vm.runInContext(code.slice(start,end),ctx);
  await ctx.removeSourceFromFolder({id:'one',title:'One'}, reviewedFolder, {textContent:'Remove',disabled:false});
  assert.strictEqual(requests[0].type, 'remove-source-from-folder');
  assert.strictEqual(requests[0].data.expectedVersion, 9);
  assert.strictEqual(requests[0].data.expectedRevision, persisted._revision);
  assert.strictEqual(requests[0].data.expectedReason, 'Displayed reason.');
  assert(armed && armed.removedMember.reason === 'Displayed reason.');
});

test('the reviewed-removal corpus makes no network requests', async () => {
  assert.strictEqual(fetchCalls.length, 0);
});

(async () => {
  let failures=0;
  for (const [name, fn] of cases) {
    try { await fn(); console.log(`PASS ${name}`); }
    catch (error) { failures++; console.error(`FAIL ${name}\n${error.stack}`); }
  }
  console.log(JSON.stringify({suite:'source-notes-reviewed-folder-removal',family:FAMILY,cases:cases.length,
    passed:cases.length-failures,failed:failures,installedBrowserRuntime:false}));
  if(failures)process.exitCode=1;
})().catch(error=>{console.error(error);process.exitCode=1;});
