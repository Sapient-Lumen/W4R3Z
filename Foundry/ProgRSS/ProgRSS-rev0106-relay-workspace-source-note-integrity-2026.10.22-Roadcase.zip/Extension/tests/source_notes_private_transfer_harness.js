// Managed production-handler tests with in-memory browser API doubles. Not an installed-browser run.
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const ROOT = path.resolve(__dirname, '..', process.env.PROGRSS_EXTENSION_ROOT || '.');
const FAMILY = process.env.PROGRSS_EXTENSION_ROOT === 'Firefox' ? 'generated-Firefox' : 'Chromium-source';

const storage = new Map();
const extensionStorage = new Map();
let failVaultWrites = false;
let pageExtractContent = 'Library opens Monday at 9.';
let pageExtractErrorCode = '';
let pageRepairVariant = 0;
globalThis.localStorage = {
  getItem(key) { return storage.has(key) ? storage.get(key) : null; },
  setItem(key, value) {
    if (failVaultWrites) {
      const error = Error('quota exceeded while writing the test vault');
      error.name = 'QuotaExceededError';
      throw error;
    }
    storage.set(key, String(value));
  },
  removeItem(key) { storage.delete(key); }
};

const messageListeners = [];
const alarms = [];
globalThis.chrome = {
  storage: {
    local: {
      async get(key) {
        if (key == null) return Object.fromEntries(extensionStorage);
        const keys = Array.isArray(key) ? key : [key];
        return Object.fromEntries(keys.filter(value => extensionStorage.has(value)).map(value => [value, extensionStorage.get(value)]));
      },
      async set(values) { for (const [key, value] of Object.entries(values || {})) extensionStorage.set(key, value); },
      async remove(key) { for (const value of (Array.isArray(key) ? key : [key])) extensionStorage.delete(value); }
    }
  },
  permissions: {
    async contains() { return true; },
    async getAll() { return {permissions: [], origins: ['https://example.test/*']}; }
  },
  runtime: {
    getURL(value) { return `chrome-extension://test/${value}`; },
    getManifest() { return {version: '0.80.0'}; },
    async getContexts() { return []; },
    async sendMessage(message) {
      if (message?.target === 'offscreen') {
        if (message.type === 'parse-feed') {
          return {ok: true, result: {
            title: 'Harness Feed', titleLanguage: 'en-GB', language: 'en-GB', type: 'rss', feedUrl: 'https://example.test/feed.xml', items: [
              {key: 'entry-1', title: 'A new entry', url: 'https://example.test/post/1', summary: 'ملخص الاختبار', body: 'نص الاختبار\n\nفقرة ثانية محفوظة.', bodyIsSummary: false, language: 'AR', titleLanguage: 'EN', summaryLanguage: 'AR', bodyLanguage: 'AR', published: '2026-10-17T12:00:00.000Z'}
            ]
          }};
        }
        if (message.type === 'parse-opml') {
          return {ok: true, result: {
            title: 'Harness subscriptions', feedOutlines: 4, invalidCount: 1, duplicateCount: 1, truncatedCount: 0, folderCount: 2,
            feeds: [
              {title: 'Harness Feed', url: 'https://example.test/feed.xml', folderPaths: [['Reading']]},
              {title: 'Independent Notes', url: 'https://new.test/feed.xml', folderPaths: [['Reading', 'Independent']]},
              {title: 'Other Notes', url: 'https://other.test/atom.xml', folderPaths: [['Reading']]}
            ]
          }};
        }
        if (message.type === 'inspect-resource') return {ok: true, result: {kind: 'feed', url: message.data.url, title: 'Harness Feed', titleLanguage: 'en-GB', language: 'en-GB', feedType: 'rss', feedUrl: 'https://example.test/feed.xml', itemCount: 1, previewCount: 1, previewFullTextCount: 1, previewSummaryCount: 0, previewDatedCount: 1, previewItems: [{title: 'A new entry', url: 'https://example.test/post/1', published: '2026-10-17T12:00:00.000Z', content: 'full-text', language: 'ar', titleLanguage: 'en'}]}};
        if (message.type === 'extract-page') {
          if (pageExtractErrorCode) return {ok: false, error: 'The watched section is missing.', code: pageExtractErrorCode, detail: {field: 'selector'}};
          return {ok: true, result: {mode: 'region', content: pageExtractContent, matchCount: 1, meaningfulCount: 1, contentChars: pageExtractContent.length}};
        }
        if (message.type === 'repair-page-watch') {
          const content = pageRepairVariant ? `${pageExtractContent} changed after review` : pageExtractContent;
          return {ok: true, result: [{
            schema: 'progrss.page-watch.repair.v1', title: 'Watch the page’s main text',
            description: 'Notice meaningful wording changes in the main part of the page.',
            mode: 'region', count: 1, examples: [], preview: content,
            recipe: {mode: 'region', selector: 'main', titleSelector: '', linkSelector: '', threshold: 4, ignoreNumbers: false},
            evidence: {signature: `region:${content}`, matchCount: 1, contentChars: content.length},
            capture: {mode: 'region', content, matchCount: 1, meaningfulCount: 1, contentChars: content.length}
          }]};
        }
      }
      return undefined;
    },
    onMessage: { addListener(listener) { messageListeners.push(listener); } },
    onInstalled: { addListener() {} },
    onStartup: { addListener() {} }
  },
  offscreen: { async createDocument() {} },
  action: {
    async setBadgeBackgroundColor() {}, async setBadgeText() {}, async setTitle() {}
  },
  sidePanel: { async setPanelBehavior() {} },
  alarms: { async create(name, details) { alarms.push({name, details}); }, onAlarm: { addListener() {} } },
  tabs: { async query() { return [{id: 1, url: 'https://example.test/', title: 'Example'}]; } },
  scripting: { async executeScript() { return [{result: {url: 'https://example.test/', title: 'Example', links: []}}]; } }
};

let fetchMode = 'normal';
let publicationPayload = '';
let publicationContentType = 'application/vnd.progrss.shared-folder+json; charset=utf-8';
const fetchCalls = [];
globalThis.fetch = async (url, options) => {
  fetchCalls.push({url: String(url), options});
  if (fetchMode === 'large') {
    return new Response('too large', {status: 200, headers: {'Content-Type': 'application/rss+xml', 'Content-Length': '2000001'}});
  }
  if (fetchMode === 'page') {
    return new Response(`<html><body><main>${pageExtractContent}</main></body></html>`, {
      status: 200, headers: {'Content-Type': 'text/html; charset=utf-8'}
    });
  }
  if (fetchMode === 'publication') {
    return new Response(publicationPayload, {
      status: 200, headers: {'Content-Type': publicationContentType, 'Content-Length': String(Buffer.byteLength(publicationPayload))}
    });
  }
  if (options?.headers?.['If-None-Match'] === '"harness-v1"') {
    return new Response(null, {status: 304, headers: {'ETag': '"harness-v1"', 'Last-Modified': 'Fri, 17 Oct 2026 12:00:00 GMT'}});
  }
  return new Response(
    '<rss><channel><title>Harness Feed</title><item><guid>entry-1</guid><title>A new entry</title></item></channel></rss>',
    {status: 200, headers: {'Content-Type': 'application/rss+xml', 'Content-Length': '120', 'ETag': '"harness-v1"', 'Last-Modified': 'Fri, 17 Oct 2026 12:00:00 GMT'}}
  );
};

globalThis.importScripts = (...files) => {
  for (const file of files) {
    const code = fs.readFileSync(path.join(ROOT, file), 'utf8');
    vm.runInThisContext(code, {filename: file});
  }
};

if (FAMILY === 'generated-Firefox') {
  globalThis.browser = globalThis.chrome;
  browser.runtime.getURL = value => `moz-extension://test/${String(value).replace(/^\//, '')}`;
  browser.sidebarAction = {async open() {}};
  browser.action.onClicked = {addListener() {}};
  delete browser.sidePanel;
  delete browser.offscreen;
}
vm.runInThisContext(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8'), {filename: 'background.js'});
assert.strictEqual(messageListeners.length, 1, 'background message listener registered');
const listener = messageListeners[0];

function setBackupReminderFixture(marker) {
  extensionStorage.set('progrssBackupReminder', marker);
  vm.runInThisContext(`volatileBackupReminder = ${JSON.stringify(marker)};`);
}

function message(type, data = {}) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timeout = setTimeout(() => { if (!settled) reject(new Error(`timeout: ${type}`)); }, 1500);
    const keep = listener({target: 'background', type, data}, {}, response => {
      settled = true;
      clearTimeout(timeout);
      resolve(response);
    });
    assert.strictEqual(keep, true, `${type} keeps response channel open`);
  });
}



function deepClone(value) { return JSON.parse(JSON.stringify(value)); }
function backup(state) {
  return {
    schema: 'progrss.private.v1',
    exportedAt: '2026-10-21T12:00:00.000Z',
    purpose: 'library-transfer',
    producer: {name: 'ProgRSS', version: '0.80.0', revision: 'rev0080'},
    state
  };
}
function validState() {
  return {
    version: 17,
    sources: [
      {id: 'shared', title: 'Shared source', type: 'rss', url: 'https://example.test/feed.xml', enabled: false, archivedAt: ''},
      {id: 'plain', title: 'Plain source', type: 'rss', url: 'https://plain.test/feed.xml', enabled: false, archivedAt: ''}
    ],
    collections: [
      {id: 'alpha', title: 'Alpha', mode: 'union', version: 1, members: [
        {kind: 'source', id: 'shared', reason: 'Alpha reason.\nSecond line.'},
        {kind: 'source', id: 'plain'}
      ]},
      {id: 'beta', title: 'Beta', mode: 'union', version: 1, members: [
        {kind: 'source', id: 'shared', reason: 'سبب بيتا.'}
      ]}
    ],
    items: [], snapshots: {}, retiredReceipts: []
  };
}
function reasonMember(document, folderId = 'alpha', index = 0) {
  return document.state.collections.find(row => row.id === folderId).members[index];
}
async function currentPortable() {
  const response = await message('export-private-backup');
  assert.strictEqual(response.ok, true, response.error);
  return JSON.parse(response.result.raw).state;
}

(async () => {
  await message('get-state');
  const prior = await ProgRSSVault.init();
  prior.sources = [{id: 'prior', title: 'Prior source', type: 'rss', url: 'https://prior.test/feed.xml', enabled: false, archivedAt: ''}];
  prior.collections = [{id: 'prior-folder', title: 'Prior', mode: 'union', version: 1, members: [{kind: 'source', id: 'prior', reason: 'Prior reason.'}]}];
  prior.items = [];
  await ProgRSSVault.save(prior);

  const document = backup(validState());
  let response = await message('preview-private-backup', {raw: JSON.stringify(document)});
  assert.strictEqual(response.ok, true, response.error);
  assert.strictEqual(response.result.incoming.sourceNotes, 2, 'preview counts exact direct-placement reasons');
  assert.strictEqual(response.result.current.sourceNotes, 1, 'preview counts current reasons separately');
  assert.strictEqual(response.result.willKeepUndo, true);
  const reviewedRevision = response.result.reviewedRevision;

  response = await message('restore-private-backup', {raw: JSON.stringify(document), reviewedRevision});
  assert.strictEqual(response.ok, true, response.error);
  assert.strictEqual(response.result.summary.sourceNotes, 2);
  assert.strictEqual(response.result.undoAvailable, true);

  response = await message('get-state');
  assert.strictEqual(response.ok, true, response.error);
  const alpha = response.result.collections.find(row => row.id === 'alpha');
  const beta = response.result.collections.find(row => row.id === 'beta');
  assert.strictEqual(alpha.members[0].reason, 'Alpha reason.\nSecond line.');
  assert.strictEqual(beta.members[0].reason, 'سبب بيتا.');
  assert.ok(!Object.hasOwn(alpha.members[1], 'reason'), 'absent reason remains absent');

  response = await message('export-private-backup');
  assert.strictEqual(response.ok, true, response.error);
  assert.strictEqual(response.result.summary.sourceNotes, 2);
  const exported = JSON.parse(response.result.raw);
  assert.strictEqual(exported.state.collections.find(row => row.id === 'alpha').members[0].reason, 'Alpha reason.\nSecond line.');
  assert.strictEqual(exported.state.collections.find(row => row.id === 'beta').members[0].reason, 'سبب بيتا.');
  assert.ok(!Object.hasOwn(exported.state.collections.find(row => row.id === 'alpha').members[1], 'reason'));

  response = await message('check-private-backup', {raw: JSON.stringify(document)});
  assert.strictEqual(response.ok, true, response.error);
  assert.strictEqual(response.result.file.sourceNotes, 2);
  assert.strictEqual(response.result.current.sourceNotes, 2);

  response = await message('undo-private-backup-restore');
  assert.strictEqual(response.ok, true, response.error);
  assert.strictEqual(response.result.summary.sourceNotes, 1);
  response = await message('get-state');
  assert.strictEqual(response.result.collections[0].members[0].reason, 'Prior reason.');

  // Restore the valid incoming library for refusal/no-mutation controls.
  response = await message('preview-private-backup', {raw: JSON.stringify(document)});
  assert.strictEqual(response.ok, true, response.error);
  response = await message('restore-private-backup', {raw: JSON.stringify(document), reviewedRevision: response.result.reviewedRevision});
  assert.strictEqual(response.ok, true, response.error);
  const baseline = JSON.stringify(await currentPortable());

  const invalid = [];
  let row = deepClone(document);
  reasonMember(row).reason = '😀'.repeat(281);
  invalid.push(['over-limit', row, /280/]);

  row = deepClone(document);
  row.state.collections[0].members.push({kind: 'collection', id: 'beta', reason: 'Wrong level'});
  invalid.push(['wrong-level', row, /direct source placement/i]);

  row = deepClone(document);
  row.state.collections[0].reason = 'Wrong level';
  invalid.push(['folder-level', row, /on the folder/i]);

  row = deepClone(document);
  row.state.collections[0].members.splice(1, 0, {kind: 'source', id: 'shared', reason: 'Alpha reason.\nSecond line.'});
  invalid.push(['duplicate', row, /exactly once/i]);

  row = deepClone(document);
  reasonMember(row).reason = ' \t\n ';
  invalid.push(['whitespace-only', row, /empty Source Note/i]);

  row = deepClone(document);
  reasonMember(row).reason = '  Alpha reason.  ';
  invalid.push(['edge-whitespace', row, /noncanonical Source Note/i]);

  row = deepClone(document);
  reasonMember(row).reason = 42;
  invalid.push(['non-string', row, /must be a string/i]);

  row = deepClone(document);
  reasonMember(row).reason = `bad${String.fromCharCode(0xD800)}value`;
  invalid.push(['invalid-unicode', row, /Unicode scalar/i]);

  row = deepClone(document);
  reasonMember(row).id = 'not-present';
  invalid.push(['missing-source', row, /missing source/i]);

  for (const [name, candidate, pattern] of invalid) {
    response = await message('preview-private-backup', {raw: JSON.stringify(candidate)});
    assert.strictEqual(response.ok, false, `${name} preview refused`);
    assert.strictEqual(response.code, 'INVALID_BACKUP', `${name} uses private-file refusal code`);
    assert.match(response.error, pattern, `${name} explains the placement problem`);
    assert.strictEqual(JSON.stringify(await currentPortable()), baseline, `${name} refusal does not mutate the vault`);
  }

  // Outbound copies also fail closed if a legacy or externally manipulated
  // local vault contains a malformed Source Note.
  const malformedLocal = await ProgRSSVault.init();
  malformedLocal.collections.find(row => row.id === 'alpha').members[0].reason = 'x'.repeat(281);
  await ProgRSSVault.save(malformedLocal);
  response = await message('export-private-backup');
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'INVALID_SOURCE_NOTE_STATE');
  assert.match(response.error, /280/);

  assert.strictEqual(fetchCalls.length, 0, 'private transfer validation performs no network activity');
  const checks = [
    'valid-preview-counts', 'valid-restore-preserves', 'valid-export-preserves',
    'valid-check-preserves', 'valid-undo-restores-prior',
    ...invalid.map(([name]) => `refuse-${name}`),
    'refuse-malformed-local-export', 'no-network'
  ];
  console.log(`PASS ${FAMILY} private transfer: 2 valid placement reasons preserved, 9 malformed forms refused, outbound malformed state refused, no network.`);
  console.log(`RESULT ${JSON.stringify({pass: true, family: FAMILY, sourceNotes: 2, malformedForms: invalid.map(([name]) => name), checks})}`);
})().catch(error => {
  console.error(error && error.stack ? error.stack : error);
  process.exitCode = 1;
});
