#!/usr/bin/env python3
"""Installed MV3 acquisition acceptance against two real local HTTP origins.

A temporary copy of the delivered Extension receives a test-only loopback host
permission. This avoids automating Chrome's browser-owned optional-permission
prompt while exercising the actual service worker, webRequest redirect signal,
offscreen parser, byte streaming, conditional headers, and IndexedDB runtime.
The release manifest is never modified.
"""
from __future__ import annotations

import asyncio
import gzip
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import threading
import time
from typing import Any

from playwright.async_api import Error as PlaywrightError, async_playwright

ROOT = Path(__file__).resolve().parents[1]
CHROMIUM = os.environ.get("PROGRSS_CHROMIUM") or shutil.which("chromium") or shutil.which("chromium-browser") or shutil.which("google-chrome")
RSS = b'<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>Local matrix</title><item><guid>one</guid><title>One item</title><description>Body</description></item></channel></rss>'
SHARED_FOLDER = json.dumps({
    "schema": "progrss.bundle.v1",
    "exportedAt": "2026-10-19T03:00:00.000Z",
    "root": "shared-root",
    "title": "Shared matrix",
    "sources": [{
        "id": "shared-feed", "title": "Shared matrix feed", "type": "rss",
        "url": "https://shared-matrix.invalid/feed.xml", "mode": "region",
        "selector": "", "titleSelector": "", "linkSelector": "",
        "include": "", "exclude": "", "threshold": 1,
        "ignoreNumbers": False, "version": 1, "author": "Matrix curator",
    }],
    "collections": [{
        "id": "shared-root", "title": "Shared matrix", "mode": "union",
        "include": "", "exclude": "", "version": 1, "author": "Matrix curator",
        "members": [{"kind": "source", "id": "shared-feed"}],
    }],
}, separators=(",", ":")).encode("utf-8")


class MatrixHandler(BaseHTTPRequestHandler):
    destination_origin = ""
    hits: list[dict[str, Any]] = []

    def record(self) -> None:
        type(self).hits.append({
            "path": self.path,
            "if_none_match": self.headers.get("If-None-Match", ""),
            "if_modified_since": self.headers.get("If-Modified-Since", ""),
        })

    def send(self, status: int, body: bytes = b"", **headers: str) -> None:
        self.send_response(status)
        for name, value in headers.items():
            self.send_header(name.replace("_", "-"), value)
        self.end_headers()
        if body:
            self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802
        self.record()
        if self.path == "/same":
            self.send(301, Location="/feed.xml")
        elif self.path == "/cross":
            self.send(302, Location=f"{type(self).destination_origin}/feed.xml")
        elif self.path == "/feed.xml":
            if self.headers.get("If-None-Match") == '"matrix-v1"' or self.headers.get("If-Modified-Since") == "Sun, 18 Oct 2026 03:00:00 GMT":
                self.send(304, ETag='"matrix-v1"', Last_Modified="Sun, 18 Oct 2026 03:00:00 GMT")
            else:
                self.send(200, RSS, Content_Type="application/rss+xml; charset=utf-8", Content_Length=str(len(RSS)), ETag='"matrix-v1"', Last_Modified="Sun, 18 Oct 2026 03:00:00 GMT")
        elif self.path == "/gzip":
            body = gzip.compress(RSS)
            self.send(200, body, Content_Type="application/rss+xml; charset=utf-8", Content_Encoding="gzip", Content_Length=str(len(body)))
        elif self.path == "/cp1252":
            body = b"caf\xe9"
            self.send(200, body, Content_Type="text/plain; charset=windows-1252", Content_Length=str(len(body)))
        elif self.path == "/utf16":
            text = '<?xml version="1.0" encoding="utf-16"?><rss><channel><title>Snow \u2603</title></channel></rss>'
            body = text.encode("utf-16")
            self.send(200, body, Content_Type="application/rss+xml", Content_Length=str(len(body)))
        elif self.path == "/bom-wins":
            body = b"\xef\xbb\xbf" + "Café snowman ☃".encode("utf-8")
            self.send(200, body, Content_Type="text/plain; charset=windows-1252", Content_Length=str(len(body)))
        elif self.path == "/unsupported-charset":
            body = b"unsupported encoding fixture"
            self.send(200, body, Content_Type="text/plain; charset=shift_jis", Content_Length=str(len(body)))
        elif self.path == "/json-feed":
            body = json.dumps({
                "version": "https://jsonfeed.org/version/1.1",
                "title": "Local JSON Feed",
                "items": [{
                    "id": "json-one", "title": "JSON item", "summary": "Timeline excerpt",
                    "content_html": "<p>Full local feed body.</p><p>A second paragraph.</p><script>steal-me</script><iframe src='/reader-frame'>remote-only</iframe><img src='/reader-pixel' alt='remote-only'>",
                }],
            }).encode("utf-8")
            self.send(200, body, Content_Type="application/feed+json; charset=utf-8", Content_Length=str(len(body)))
        elif self.path == "/link-page":
            body = b"<!doctype html><html><head><title>Header discovery</title></head><body><main>Page</main></body></html>"
            self.send(200, body, Content_Type="text/html; charset=utf-8", Content_Length=str(len(body)), Link='</feed.xml>; rel="alternate"; type="application/rss+xml"; title="Header feed"')
        elif self.path == "/shared-folder":
            self.send(200, SHARED_FOLDER, Content_Type="text/plain", Content_Length=str(len(SHARED_FOLDER)))
        elif self.path == "/shared-folder-wrong-encoding":
            self.send(200, SHARED_FOLDER, Content_Type="text/plain; charset=windows-1252", Content_Length=str(len(SHARED_FOLDER)))
        elif self.path == "/malformed":
            body = b"<rss><channel><title>broken"
            self.send(200, body, Content_Type="application/rss+xml", Content_Length=str(len(body)))
        elif self.path == "/malformed-plain":
            body = b"<rss><channel><title>broken"
            self.send(200, body, Content_Type="text/plain", Content_Length=str(len(body)))
        elif self.path == "/too-large":
            self.send(200, b"small", Content_Type="text/plain", Content_Length="2000001")
        elif self.path == "/slow":
            self.send_response(200)
            self.send_header("Content-Type", "application/rss+xml; charset=utf-8")
            self.end_headers()
            for offset in range(0, len(RSS), 31):
                self.wfile.write(RSS[offset : offset + 31])
                self.wfile.flush()
                time.sleep(0.015)
        elif self.path == "/throttle":
            self.send(429, Retry_After="120")
        elif self.path == "/unavailable":
            self.send(503, Retry_After="60")
        else:
            self.send(404, b"missing", Content_Type="text/plain")

    def log_message(self, _format: str, *_args: object) -> None:
        return


class DestinationHandler(MatrixHandler):
    hits: list[dict[str, Any]] = []


class OriginHandler(MatrixHandler):
    hits: list[dict[str, Any]] = []


def server(handler: type[MatrixHandler]) -> tuple[ThreadingHTTPServer, threading.Thread, str]:
    instance = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    thread = threading.Thread(target=instance.serve_forever, daemon=True)
    thread.start()
    return instance, thread, f"http://127.0.0.1:{instance.server_port}"


async def raw_message(page: Any, message_type: str, data: dict[str, Any]) -> dict[str, Any]:
    value = await page.evaluate(
        "([type, data]) => chrome.runtime.sendMessage({target:'background', type, data})",
        [message_type, data],
    )
    assert isinstance(value, dict), value
    return value


async def main() -> int:
    if not CHROMIUM:
        print("SKIP network acceptance: Chromium is unavailable", file=sys.stderr)
        return 77

    origin_server, origin_thread, origin = server(OriginHandler)
    destination_server, destination_thread, destination = server(DestinationHandler)
    OriginHandler.destination_origin = destination
    OriginHandler.hits = []
    DestinationHandler.hits = []

    try:
        with tempfile.TemporaryDirectory(prefix="progrss-network-extension-") as extension_temp, tempfile.TemporaryDirectory(prefix="progrss-network-profile-") as profile:
            extension = Path(extension_temp) / "Extension"
            shutil.copytree(ROOT, extension)
            manifest_path = extension / "manifest.json"
            manifest = json.loads(manifest_path.read_text())
            manifest["host_permissions"] = ["http://127.0.0.1/*"]
            manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")

            async with async_playwright() as p:
                context = await p.chromium.launch_persistent_context(
                    profile,
                    executable_path=CHROMIUM,
                    headless=True,
                    viewport={"width": 390, "height": 844},
                    ignore_default_args=["--disable-extensions"],
                    args=["--no-sandbox", "--disable-dev-shm-usage", "--enable-unsafe-extension-debugging"],
                )
                try:
                    browser = context.browser
                    assert browser is not None
                    session = await browser.new_browser_cdp_session()
                    try:
                        installed = await session.send("Extensions.loadUnpacked", {"path": str(extension)})
                    except PlaywrightError as error:
                        if "disabled by the administrator" in str(error).lower():
                            print("SKIP network acceptance: Chromium policy blocks unpacked extensions", file=sys.stderr)
                            return 77
                        raise
                    extension_id = installed.get("id")
                    assert extension_id
                    page = await context.new_page()
                    response = await page.goto(f"chrome-extension://{extension_id}/sidepanel/index.html", wait_until="domcontentloaded")
                    assert response and response.status == 200

                    same = await raw_message(page, "fetch-resource", {"url": origin + "/same"})
                    assert same.get("ok") is True, same
                    result = same["result"]
                    assert result["url"] == origin + "/feed.xml", result
                    assert result["requestedUrl"] == origin + "/same", result
                    assert result["redirects"] == [{"from": origin + "/same", "to": origin + "/feed.xml", "status": 301}], result
                    assert "Local matrix" in result["body"]

                    DestinationHandler.hits = []
                    cross = await raw_message(page, "fetch-resource", {"url": origin + "/cross"})
                    assert cross.get("ok") is False and cross.get("code") == "CROSS_ORIGIN_REDIRECT", cross
                    assert cross["detail"]["to"] == destination + "/feed.xml", cross
                    assert DestinationHandler.hits == [], DestinationHandler.hits

                    compressed = await raw_message(page, "fetch-resource", {"url": origin + "/gzip"})
                    assert compressed.get("ok") is True and "Local matrix" in compressed["result"]["body"], compressed

                    cp1252 = await raw_message(page, "fetch-resource", {"url": origin + "/cp1252"})
                    assert cp1252.get("ok") is True and cp1252["result"]["body"] == "café", cp1252
                    assert cp1252["result"]["encoding"] == "windows-1252"

                    utf16 = await raw_message(page, "fetch-resource", {"url": origin + "/utf16"})
                    assert utf16.get("ok") is True and "Snow ☃" in utf16["result"]["body"], utf16
                    assert utf16["result"]["encoding"] == "utf-16le"

                    bom = await raw_message(page, "fetch-resource", {"url": origin + "/bom-wins"})
                    assert bom.get("ok") is True and bom["result"]["body"] == "Café snowman ☃", bom
                    assert bom["result"]["encoding"] == "utf-8", bom

                    unsupported = await raw_message(page, "fetch-resource", {"url": origin + "/unsupported-charset"})
                    assert unsupported.get("ok") is False and unsupported.get("code") == "UNSUPPORTED_ENCODING", unsupported

                    OriginHandler.hits = []
                    json_feed = await raw_message(page, "inspect-url", {"url": origin + "/json-feed"})
                    assert json_feed.get("ok") is True and json_feed["result"]["kind"] == "feed", json_feed
                    assert json_feed["result"]["feedType"] == "json" and json_feed["result"]["title"] == "Local JSON Feed", json_feed
                    assert not any(row["path"] in {"/reader-frame", "/reader-pixel"} for row in OriginHandler.hits), OriginHandler.hits
                    added = await raw_message(page, "add-source", {"url": origin + "/json-feed", "title": "Local JSON Feed", "type": "rss"})
                    assert added.get("ok") is True, added
                    refreshed = await raw_message(page, "refresh-source", {"sourceId": added["result"]["source"]["id"]})
                    assert refreshed.get("ok") is True and refreshed["result"]["added"] == 1, refreshed
                    reader_state = await raw_message(page, "get-state", {})
                    retained = next(row for row in reader_state["result"]["items"] if row["sourceId"] == added["result"]["source"]["id"])
                    assert retained["body"] == "Full local feed body.\n\nA second paragraph.", retained
                    assert retained["bodyIsSummary"] is False, retained
                    assert "steal-me" not in retained["body"] and "remote-only" not in retained["body"], retained
                    assert not any(row["path"] in {"/reader-frame", "/reader-pixel"} for row in OriginHandler.hits), OriginHandler.hits

                    header_discovery = await raw_message(page, "inspect-url", {"url": origin + "/link-page"})
                    assert header_discovery.get("ok") is True and header_discovery["result"]["kind"] == "html", header_discovery
                    candidates = header_discovery["result"]["candidates"]
                    assert candidates and candidates[0]["url"] == origin + "/feed.xml", header_discovery
                    assert candidates[0]["origin"] == "http-header" and candidates[0]["title"] == "Header feed", header_discovery

                    state_before_shared = await raw_message(page, "get-state", {})
                    source_count_before_shared = len(state_before_shared["result"]["sources"])
                    OriginHandler.hits = []
                    direct_shared = await raw_message(page, "inspect-url", {"url": origin + "/shared-folder"})
                    assert direct_shared.get("ok") is True and direct_shared["result"]["kind"] == "shared-folder", direct_shared
                    assert direct_shared["result"]["title"] == "Shared matrix", direct_shared
                    assert direct_shared["result"]["preview"]["canImport"] is True, direct_shared
                    assert direct_shared["result"]["preview"]["network"] is True, direct_shared
                    assert direct_shared["result"]["preview"]["writes"] is False, direct_shared
                    assert direct_shared["result"]["remote"]["directAddress"] is True, direct_shared
                    assert direct_shared["result"]["remote"]["automatic"] is False, direct_shared
                    assert [row["path"] for row in OriginHandler.hits] == ["/shared-folder"], OriginHandler.hits
                    state_after_shared = await raw_message(page, "get-state", {})
                    assert len(state_after_shared["result"]["sources"]) == source_count_before_shared, state_after_shared

                    wrong_shared_encoding = await raw_message(page, "inspect-url", {"url": origin + "/shared-folder-wrong-encoding"})
                    assert wrong_shared_encoding.get("ok") is False and wrong_shared_encoding.get("code") == "INVALID_SHARED_FOLDER", wrong_shared_encoding
                    assert "UTF-8 JSON" in wrong_shared_encoding.get("error", ""), wrong_shared_encoding

                    conditional = await raw_message(page, "fetch-resource", {
                        "url": origin + "/feed.xml",
                        "validators": {"etag": '"matrix-v1"', "lastModified": "Sun, 18 Oct 2026 03:00:00 GMT"},
                    })
                    assert conditional.get("ok") is True and conditional["result"]["status"] == 304, conditional
                    assert conditional["result"]["body"] == ""
                    last_feed_hit = [row for row in OriginHandler.hits if row["path"] == "/feed.xml"][-1]
                    assert last_feed_hit["if_none_match"] == '"matrix-v1"'
                    assert last_feed_hit["if_modified_since"] == "Sun, 18 Oct 2026 03:00:00 GMT"

                    malformed = await raw_message(page, "inspect-url", {"url": origin + "/malformed"})
                    assert malformed.get("ok") is False, malformed
                    assert any(word in malformed.get("error", "").lower() for word in ("feed", "xml", "parse")), malformed
                    malformed_plain = await raw_message(page, "inspect-url", {"url": origin + "/malformed-plain"})
                    assert malformed_plain.get("ok") is False, malformed_plain
                    assert any(word in malformed_plain.get("error", "").lower() for word in ("feed", "xml", "parse")), malformed_plain

                    too_large = await raw_message(page, "fetch-resource", {"url": origin + "/too-large"})
                    assert too_large.get("ok") is False and too_large.get("code") == "BODY_TOO_LARGE", too_large

                    slow = await raw_message(page, "fetch-resource", {"url": origin + "/slow"})
                    assert slow.get("ok") is True and slow["result"]["body"].encode() == RSS, slow

                    throttled = await raw_message(page, "fetch-resource", {"url": origin + "/throttle"})
                    assert throttled.get("ok") is True and throttled["result"]["status"] == 429, throttled
                    unavailable = await raw_message(page, "fetch-resource", {"url": origin + "/unavailable"})
                    assert unavailable.get("ok") is True and unavailable["result"]["status"] == 503, unavailable
                finally:
                    await context.close()
    finally:
        origin_server.shutdown(); destination_server.shutdown()
        origin_server.server_close(); destination_server.server_close()
        origin_thread.join(timeout=2); destination_thread.join(timeout=2)

    print("PASS installed local-server matrix: same-site redirect, cross-site stop, gzip, BOM/header precedence, supported and refused encodings, JSON Feed MIME/full-text retention without embedded-resource loads, HTTP Link discovery, direct shared-folder JSON under generic media type, UTF-8 enforcement, validators/304, malformed XML under feed and generic media types, size bound, slow stream, 429/503")
    print("NOTE test copy used a loopback-only required host permission; the delivered optional-permission manifest was unchanged")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
