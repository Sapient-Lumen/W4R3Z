'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const root = path.resolve(__dirname, '..');
const context = {
  console, URL, TextEncoder, TextDecoder, crypto: require('crypto').webcrypto,
  structuredClone: global.structuredClone,
  atob: value => Buffer.from(value, 'base64').toString('binary'),
  btoa: value => Buffer.from(value, 'binary').toString('base64'),
  setTimeout, clearTimeout
};
context.globalThis = context;
context.window = context;
context.self = context;
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(root, 'shared', 'core.js'), 'utf8'), context, {filename: 'core.js'});
const C = context.ProgRSSCore || context.ProgRSS?.Core || context.ProgRSS?.core || Object.values(context).find(value => value && typeof value === 'object' && typeof value.exportBundle === 'function' && typeof value.validateBundle === 'function');
assert(C, 'ProgRSS core API should be available');
vm.runInContext(fs.readFileSync(path.join(root, 'shared', 'shared-folder.js'), 'utf8'), context, {filename: 'shared-folder.js'});
const F = context.ProgRSSSharedFolder;
assert(F, 'shared-folder API should be available');
vm.runInContext(fs.readFileSync(path.join(root, 'shared', 'scout.js'), 'utf8'), context, {filename: 'scout.js'});
const Scout = context.ProgRSSScout;
assert(Scout, 'site scout API should be available');
vm.runInContext(fs.readFileSync(path.join(root, 'shared', 'parser.js'), 'utf8'), context, {filename: 'parser.js'});
const Parser = context.ProgRSSParser;
assert(Parser, 'shared parser facade should be available');
const previewInspection = Parser.inspectResource({
  body: fs.readFileSync(path.join(root, 'fixtures', 'interoperability', 'json-full-content.json'), 'utf8'),
  url: 'https://json-full.example/feed.json',
  contentType: 'application/feed+json'
});
assert.strictEqual(previewInspection.kind, 'feed');
assert.strictEqual(previewInspection.previewCount, 1);
assert.strictEqual(previewInspection.previewFullTextCount, 1);
assert.strictEqual(previewInspection.previewItems[0].content, 'full-text');
assert.strictEqual(previewInspection.previewItems[0].title, 'A complete JSON note');
assert.ok(!Object.hasOwn(previewInspection.previewItems[0], 'body'));
assert.ok(!Object.hasOwn(previewInspection.previewItems[0], 'summary'));
vm.runInContext(fs.readFileSync(path.join(root, 'shared', 'publication-site.js'), 'utf8'), context, {filename: 'publication-site.js'});
const S = context.ProgRSSPublicationSite;
assert(S, 'publication-site API should be available');

function storedZipEntries(bytes) {
  const buffer = Buffer.from(bytes);
  const entries = new Map();
  let offset = 0;
  while (offset + 4 <= buffer.length && buffer.readUInt32LE(offset) === 0x04034b50) {
    const method = buffer.readUInt16LE(offset + 8);
    const size = buffer.readUInt32LE(offset + 18);
    const nameLength = buffer.readUInt16LE(offset + 26);
    const extraLength = buffer.readUInt16LE(offset + 28);
    assert.strictEqual(method, 0, 'website ZIP entries are deliberately stored without compression');
    const nameStart = offset + 30;
    const dataStart = nameStart + nameLength + extraLength;
    const name = buffer.subarray(nameStart, nameStart + nameLength).toString('utf8');
    entries.set(name, buffer.subarray(dataStart, dataStart + size));
    offset = dataStart + size;
  }
  return entries;
}

const state = {
  sources: [
    {id: 'feed_one', type: 'rss', title: 'Feed', url: 'https://example.com/feed', enabled: true},
    {id: 'watch_one', type: 'page', title: 'Watch', url: 'https://example.net/news', enabled: true, mode: 'cards', selector: 'article', titleSelector: 'h2', linkSelector: 'a'},
    {id: 'private_feed', type: 'rss', title: 'Private', url: 'https://private.example/feed', enabled: true}
  ],
  collections: [
    {id: 'folder_root', title: 'Shared route', mode: 'union', members: [{kind: 'source', id: 'feed_one'}, {kind: 'collection', id: 'folder_child'}]},
    {id: 'folder_child', title: 'Pages', mode: 'union', members: [{kind: 'source', id: 'watch_one'}]},
    {id: 'folder_private', title: 'Private', mode: 'union', members: [{kind: 'source', id: 'private_feed'}]}
  ],
  items: [{id: 'reading-history'}],
  snapshots: {watch_one: 'private page text'}
};
const bundle = C.exportBundle(state, 'folder_root');
assert.strictEqual(bundle.root, 'folder_root');
assert.strictEqual(bundle.title, 'Shared route');
assert.deepStrictEqual(Array.from(bundle.sources, source => source.id).sort(), ['feed_one', 'watch_one']);
assert(!JSON.stringify(bundle).includes('reading-history'));
assert(!JSON.stringify(bundle).includes('private page text'));
assert.throws(() => C.validateBundle({...bundle, root: 'folder_private'}), /root/i);

const contents = F.contents(bundle, new Map([
  ['feed_one', 'already-here'],
  ['watch_one', 'new-paused']
]));
assert.strictEqual(contents.schema, 'progrss.shared-folder.contents.v2');
assert.strictEqual(contents.network, false);
assert.strictEqual(contents.writes, false);
assert.strictEqual(contents.sourceCount, 2);
assert.strictEqual(contents.folderCount, 2);
assert.deepStrictEqual(Array.from(contents.folders, row => row.path), ['Shared route', 'Shared route › Pages']);
assert.deepStrictEqual(Array.from(contents.sources, row => row.title), ['Feed', 'Watch']);
assert.strictEqual(contents.sources[0].host, 'example.com');
assert.deepStrictEqual(Array.from(contents.sources[1].folders), ['Shared route › Pages']);
assert.strictEqual(contents.sources[0].state, 'already-here');
assert.strictEqual(contents.sources[1].state, 'new-paused');
assert.strictEqual(contents.folders[0].isRoot, true);
assert.strictEqual(contents.folders[0].branchSources, 2);
assert.strictEqual(contents.folders[0].branchFolders, 2);
assert.strictEqual(contents.folders[1].branchSources, 1);
assert.strictEqual(contents.folders[1].branchPageWatches, 1);

const branch = F.branch(bundle, 'folder_child');
assert.strictEqual(branch.schema, 'progrss.bundle.v1');
assert.strictEqual(branch.root, 'folder_child');
assert.strictEqual(branch.title, 'Pages');
assert.deepStrictEqual(Array.from(branch.sources, source => source.id), ['watch_one']);
assert.deepStrictEqual(Array.from(branch.collections, folder => folder.id), ['folder_child']);
assert.strictEqual(bundle.sources.length, 2, 'branch selection does not mutate the checked source list');

const editionState = {
  sources: [
    {id: 'feed_a', type: 'rss', title: 'First desk', url: 'https://first.example/feed', enabled: true},
    {id: 'feed_b', type: 'rss', title: 'Second desk', url: 'https://second.example/feed', enabled: true},
    {id: 'watch_a', type: 'page', title: 'Town page', url: 'https://town.example/notices', enabled: true}
  ],
  collections: [{id: 'edition_root', title: 'Neighborhood', mode: 'union', members: [
    {kind: 'source', id: 'feed_a'}, {kind: 'source', id: 'feed_b'}, {kind: 'source', id: 'watch_a'}
  ]}],
  items: [
    {id: 'feed-a-1', sourceId: 'feed_a', title: 'Garden opens', url: 'https://news.example/garden', summary: 'Saturday morning.', body: 'PRIVATE FULL TEXT A', readAt: '2026-10-19T01:00:00Z', starred: true, observedAt: '2026-10-19T01:00:00Z'},
    {id: 'feed-b-1', sourceId: 'feed_b', title: 'Garden opens today', url: 'https://news.example/garden', summary: 'Saturday at nine.', body: 'PRIVATE FULL TEXT B', observedAt: '2026-10-19T02:00:00Z'},
    {id: 'watch-change-1', sourceId: 'watch_a', title: 'Town notice changed', url: 'https://town.example/notices', summary: 'Meeting time changed.', kind: 'changed', observedAt: '2026-10-19T03:00:00Z', change: {schema: C.PAGE_CHANGE_SCHEMA, kind: 'text-changed', mode: 'region', summary: 'Meeting time changed.', before: 'PRIVATE BEFORE', after: 'PRIVATE AFTER'}}
  ]
};
const edition = C.makeFolderEdition(editionState, 'edition_root', {title: 'Neighborhood', curator: 'Neighborhood desk', note: 'A weekly selection.', generatedAt: '2026-10-19T04:00:00Z'});
assert.strictEqual(edition.document.version, 'https://jsonfeed.org/version/1.1');
assert.strictEqual(edition.document._progrss.schema, C.FOLDER_EDITION_SCHEMA);
assert.strictEqual(edition.document.items.length, 2, 'matching article URLs collapse into one public item');
const gardenEditionItem = edition.document.items.find(item => item.url === 'https://news.example/garden');
assert(gardenEditionItem);
assert.strictEqual(gardenEditionItem._progrss.sourceCount, 2);
assert.deepStrictEqual(Array.from(gardenEditionItem._progrss.sources, row => row.title).sort(), ['First desk', 'Second desk']);
const changeEditionItem = edition.document.items.find(item => item._progrss.changeKind === 'text-changed');
assert(changeEditionItem, 'page-change kind remains visible without private comparison passages');
const editionRaw = JSON.stringify(edition.document);
for (const secret of ['PRIVATE FULL TEXT A', 'PRIVATE FULL TEXT B', 'PRIVATE BEFORE', 'PRIVATE AFTER', 'readAt', 'starred']) {
  assert(!editionRaw.includes(secret), `folder edition must exclude ${secret}`);
}
assert.strictEqual(edition.summary.fullTextIncluded, false);
assert.strictEqual(edition.summary.readingStateIncluded, false);
assert.strictEqual(edition.summary.savedStateIncluded, false);
assert.strictEqual(gardenEditionItem.id, 'https://news.example/garden');
assert.match(changeEditionItem.id, /^urn:progrss:edition:[a-f0-9]{16}$/);
assert(!changeEditionItem.id.includes('watch_a') && !changeEditionItem.id.includes('watch-change-1'), 'public IDs do not expose local source or item IDs');
const parsedEdition = C.parseFeed(JSON.stringify(edition.document), 'https://publisher.example/edition.json');
assert.strictEqual(parsedEdition.type, 'json');
assert.strictEqual(parsedEdition.items.length, 2, 'the independent feed parser accepts the generated edition');

const advertisedFolders = Scout.chooseSharedFolders([
  {rel: 'alternate', type: 'application/vnd.progrss.shared-folder+json', href: 'latest.json', title: 'Neighborhood sources'},
  {rel: 'alternate', type: 'application/vnd.progrss.shared-folder+json', href: 'https://other.example/list.json', title: 'Cross-site'},
  {rel: 'alternate', type: 'application/json', href: 'generic.json', title: 'Generic JSON'}
], 'https://example.com/reading/index.html');
assert.deepStrictEqual(Array.from(advertisedFolders, row => row.url), ['https://example.com/reading/latest.json']);
assert.strictEqual(advertisedFolders[0].title, 'Neighborhood sources');
assert.strictEqual(advertisedFolders[0].kind, 'shared-folder');

const wording = C.diffText('Library opens Monday at 9.', 'Library opens Tuesday at 10.', 1, false);
assert.strictEqual(wording.meaningful, true);
assert.strictEqual(wording.removed, 'Monday at 9');
assert.strictEqual(wording.added, 'Tuesday at 10');
assert.strictEqual(wording.beforeSnippet, 'Library opens Monday at 9.');
assert.strictEqual(wording.afterSnippet, 'Library opens Tuesday at 10.');
assert(!wording.summary.startsWith('+'), 'human explanation should not expose +/- diagnostic syntax');

const ignoredNumber = C.diffText('Seats available: 12', 'Seats available: 13', 1, true);
assert.strictEqual(ignoredNumber.changed, false, 'number-only change should be quiet when numbers are ignored');

const punctuation = C.diffText('Notice open.', 'Notice open!', 1, false);
assert.strictEqual(punctuation.meaningful, true);
assert.strictEqual(punctuation.addedWords, 0);
assert.strictEqual(punctuation.removedWords, 0);
assert.strictEqual(punctuation.summary, 'Changed “.” to “!”');
const belowThreshold = C.diffText('Open A', 'Open B', 2, false);
assert.strictEqual(belowThreshold.changed, true);
assert.strictEqual(belowThreshold.meaningful, false, 'the existing meaningful-change threshold remains authoritative');

const collapsedWatch = C.pageWatchCaptureHealth(
  {mode: 'cards', entries: [1, 2, 3, 4, 5].map(index => ({key: String(index)}))},
  {mode: 'cards', cards: [{key: 'only'}], matchCount: 1},
  {mode: 'cards'}
);
assert.strictEqual(collapsedWatch.status, 'attention');
assert.strictEqual(collapsedWatch.reason, 'structure-changed');
const shiftedWatch = C.pageWatchCaptureHealth(
  {mode: 'region', text: 'x'.repeat(500)},
  {mode: 'region', content: 'x'.repeat(100), matchCount: 1},
  {mode: 'region'}
);
assert.strictEqual(shiftedWatch.status, 'changed-shape');
assert.strictEqual(shiftedWatch.reason, 'text-size-shift');
const firstShift = C.pageWatchStabilityDecision(null, shiftedWatch, {version: 1});
assert.strictEqual(firstShift.action, 'hold');
assert.strictEqual(firstShift.stability.observations, 1);
assert.match(firstShift.stability.message, /held/i);
const similarShiftHealth = C.pageWatchCaptureHealth(
  {mode: 'region', text: 'x'.repeat(500)},
  {mode: 'region', content: 'x'.repeat(110), matchCount: 1},
  {mode: 'region'}
);
const confirmedShift = C.pageWatchStabilityDecision(firstShift.stability, similarShiftHealth, {version: 1});
assert.strictEqual(confirmedShift.action, 'accept');
assert.strictEqual(confirmedShift.confirmed, true);
assert.strictEqual(confirmedShift.health.reason, 'confirmed-shape-change');
const returnedSteady = C.pageWatchStabilityDecision(firstShift.stability, {
  schema: C.PAGE_WATCH_HEALTH_SCHEMA, status: 'steady', reason: 'matched', checkedAt: new Date().toISOString(), message: 'matched', metrics: {previousCharacters: 500, currentCharacters: 490, matchCount: 1}
}, {version: 1});
assert.strictEqual(returnedSteady.action, 'accept');
assert.strictEqual(returnedSteady.recovered, true);
assert.strictEqual(returnedSteady.health.reason, 'returned-to-steady');
const incompatibleSecond = C.pageWatchStabilityDecision(firstShift.stability, C.pageWatchCaptureHealth(
  {mode: 'region', text: 'x'.repeat(500)},
  {mode: 'region', content: 'x'.repeat(20), matchCount: 1},
  {mode: 'region'}
), {version: 1});
assert.strictEqual(incompatibleSecond.action, 'hold');
assert.strictEqual(incompatibleSecond.stability.observations, 2);
const unstableThird = C.pageWatchStabilityDecision(incompatibleSecond.stability, similarShiftHealth, {version: 1});
assert.strictEqual(unstableThird.action, 'repair');
assert.strictEqual(unstableThird.health.reason, 'unstable-shape');
const differentKindSecond = C.pageWatchStabilityDecision(firstShift.stability, {
  schema: C.PAGE_WATCH_HEALTH_SCHEMA, status: 'changed-shape', reason: 'entry-count-shift', checkedAt: new Date().toISOString(),
  message: 'different shape', metrics: {previousEntries: 10, currentEntries: 25, matchCount: 25}
}, {version: 1});
assert.strictEqual(differentKindSecond.action, 'hold');
assert.strictEqual(differentKindSecond.stability.observations, 2, 'an incompatible unusual reason still advances the bounded observation count');
const alternatingThird = C.pageWatchStabilityDecision(differentKindSecond.stability, similarShiftHealth, {version: 1});
assert.strictEqual(alternatingThird.action, 'repair', 'three incompatible unusual shapes escalate even when their reason alternates');

const watchState = {items: [], snapshots: {}};
const watch = {id: 'region_watch', type: 'page', title: 'Library hours', url: 'https://library.example/hours', mode: 'region', threshold: 1, ignoreNumbers: false};
const baseline = C.ingestPage(watchState, watch, {mode: 'region', content: 'Doors open Monday at 9.'});
assert.strictEqual(baseline.baseline, true);
assert.strictEqual(watchState.items.length, 0, 'baseline must not manufacture a page-change alert');
const observed = C.ingestPage(watchState, watch, {mode: 'region', content: 'Doors open Tuesday at 10.'});
assert.strictEqual(observed.added, 1);
assert.strictEqual(watchState.items[0].change.schema, C.PAGE_CHANGE_SCHEMA);
assert.strictEqual(watchState.items[0].change.kind, 'text-changed');
assert.strictEqual(watchState.items[0].change.before, 'Doors open Monday at 9.');
assert.strictEqual(watchState.items[0].change.after, 'Doors open Tuesday at 10.');

const cardState = {items: [], snapshots: {}};
const cards = {id: 'card_watch', type: 'page', title: 'Community notices', url: 'https://community.example/notices', mode: 'cards', threshold: 1, ignoreNumbers: false};
C.ingestPage(cardState, cards, {mode: 'cards', cards: [{key: 'a', title: 'Seed swap', summary: 'Saturday morning', url: 'https://community.example/a'}]});
C.ingestPage(cardState, cards, {mode: 'cards', cards: [
  {key: 'a', title: 'Seed swap', summary: 'Sunday morning', url: 'https://community.example/a'},
  {key: 'b', title: 'Tool library', summary: 'Now open', url: 'https://community.example/b'}
]});
assert.deepStrictEqual(Array.from(cardState.items, item => item.change.kind).sort(), ['entry-added', 'entry-changed']);
const addedEvent = cardState.items.find(item => item.change.kind === 'entry-added');
assert.strictEqual(addedEvent.change.addedWords, 4, 'whole-entry word counts exclude punctuation');
C.ingestPage(cardState, cards, {mode: 'cards', cards: [
  {key: 'b', title: 'Tool library', summary: 'Now open', url: 'https://community.example/b'}
]});
assert(cardState.items.some(item => item.change.kind === 'entry-removed'), 'removed entries retain a Before explanation');

const legacyCardState = {items: [], snapshots: {legacy_watch: {mode: 'cards', keys: ['a'], capturedAt: '2026-10-01T00:00:00Z'}}};
const legacyCards = {...cards, id: 'legacy_watch'};
const legacyResult = C.ingestPage(legacyCardState, legacyCards, {mode: 'cards', cards: [
  {key: 'a', title: 'Known entry', summary: 'Wording was not stored before Trace', url: 'https://community.example/a'}
]});
assert.strictEqual(legacyResult.added, 0);
assert.strictEqual(legacyCardState.items.length, 0, 'a key-only legacy snapshot must not manufacture a changed-entry alert');

async function testSharedFolderIntegrity() {
  const attributed = await F.create(bundle, {
    curator: 'Garden Group', note: 'A calm list.', exportedAt: '2026-10-18T22:30:00.000Z'
  });
  const checked = await F.validate(attributed);
  assert.strictEqual(checked.provenance.signatureState, 'unsigned');
  assert.strictEqual(checked.provenance.curator, 'Garden Group');
  const tampered = JSON.parse(JSON.stringify(attributed));
  tampered.sources[0].title += ' changed';
  await assert.rejects(() => F.validate(tampered), /digest does not match/i);

  const located = await F.create(bundle, {
    curator: 'Garden Group', note: 'A calm list.', updateUrl: 'https://example.com/shared/garden.json',
    exportedAt: '2026-10-18T22:30:00.000Z'
  });
  const locatedChecked = await F.validate(located);
  assert.strictEqual(located.schema, F.LOCATED_SCHEMA);
  assert.strictEqual(locatedChecked.provenance.schema, F.LOCATED_ORIGIN_SCHEMA);
  assert.strictEqual(locatedChecked.provenance.updateUrl, 'https://example.com/shared/garden.json');
  const changedLocation = JSON.parse(JSON.stringify(located));
  changedLocation.distribution.updateUrl = 'https://example.com/shared/other.json';
  await assert.rejects(() => F.validate(changedLocation), /digest does not match/i);

  let pair;
  let algorithm = 'Ed25519';
  try {
    pair = await context.crypto.subtle.generateKey({name: 'Ed25519'}, false, ['sign', 'verify']);
  } catch {
    algorithm = 'ECDSA-P256-SHA256';
    pair = await context.crypto.subtle.generateKey({name: 'ECDSA', namedCurve: 'P-256'}, false, ['sign', 'verify']);
  }
  const publicKey = F.bytesToBase64Url(new Uint8Array(await context.crypto.subtle.exportKey('raw', pair.publicKey)));
  const signedRoundTrip = await F.sign(attributed, {
    algorithm,
    publicKey,
    keyId: await F.rawKeyId(algorithm, publicKey),
    privateKey: pair.privateKey,
    createdAt: '2026-10-18T22:31:00.000Z'
  });
  const signedRoundTripChecked = await F.validate(signedRoundTrip);
  assert.strictEqual(signedRoundTripChecked.provenance.signatureState, 'verified');
  assert.strictEqual(signedRoundTripChecked.provenance.algorithm, algorithm);
  const signedLocated = await F.sign(located, {
    algorithm, publicKey, keyId: await F.rawKeyId(algorithm, publicKey), privateKey: pair.privateKey,
    createdAt: '2026-10-18T22:31:00.000Z'
  });
  const signedLocatedChecked = await F.validate(signedLocated);
  assert.strictEqual(signedLocatedChecked.provenance.signatureState, 'verified');
  assert.strictEqual(signedLocatedChecked.provenance.updateUrl, 'https://example.com/shared/garden.json');

  const website = S.build(JSON.stringify(signedLocated));
  assert.strictEqual(website.schema, 'progrss.publication-site.v1');
  assert.strictEqual(website.summary.signed, true);
  assert.strictEqual(website.summary.automaticChecks, false);
  assert.strictEqual(website.summary.discoverableFromPage, true);
  assert.strictEqual(website.summary.advertisedMediaType, 'application/vnd.progrss.shared-folder+json');
  assert.match(website.fileName, /website-2026-10-18\.zip$/);
  const entries = storedZipEntries(website.bytes);
  assert.deepStrictEqual(Array.from(entries.keys()).sort(), ['README.txt', 'garden.json', 'index.html', 'subscriptions.opml']);
  const hosted = JSON.parse(entries.get('garden.json').toString('utf8'));
  assert.strictEqual(hosted.integrity.signature.keyId, signedLocated.integrity.signature.keyId);
  assert.strictEqual(hosted.distribution.updateUrl, 'https://example.com/shared/garden.json');
  const page = entries.get('index.html').toString('utf8');
  assert(!/<script\b/i.test(page));
  assert(!/<(?:iframe|img|object|embed)\b/i.test(page));
  assert(page.includes('Get source list for ProgRSS'));
  assert(page.includes('<link rel="alternate" type="application/vnd.progrss.shared-folder+json" href="garden.json" title="Shared route source list for ProgRSS">'));
  assert(page.includes('Add → Use this page'));
  assert(page.includes('paste the direct JSON address into Add'));
  assert(page.includes('no scripts, trackers, remote images, or automatic update checks'));
  assert(entries.get('subscriptions.opml').toString('utf8').includes('xmlUrl="https://example.com/feed"'));
  assert(entries.get('README.txt').toString('utf8').includes('ProgRSS does not poll it'));
  assert(entries.get('README.txt').toString('utf8').includes('advertises the JSON file as a ProgRSS source list'));

  const editionBundle = C.exportBundle(editionState, 'edition_root');
  const locatedEdition = await F.create(editionBundle, {
    curator: 'Neighborhood desk', note: 'A weekly selection.', updateUrl: 'https://publisher.example/neighborhood/latest.json',
    exportedAt: '2026-10-19T04:00:00.000Z'
  });
  const websiteWithUpdates = S.build(JSON.stringify(locatedEdition), {editionRaw: JSON.stringify(edition.document)});
  assert.strictEqual(websiteWithUpdates.summary.recentUpdatesIncluded, true);
  assert.strictEqual(websiteWithUpdates.summary.updates, 2);
  assert.strictEqual(websiteWithUpdates.summary.advertisedFeedMediaType, 'application/feed+json');
  const updateEntries = storedZipEntries(websiteWithUpdates.bytes);
  assert.deepStrictEqual(Array.from(updateEntries.keys()).sort(), ['README.txt', 'index.html', 'latest.json', 'recent-updates.json', 'subscriptions.opml']);
  const updatePage = updateEntries.get('index.html').toString('utf8');
  assert(updatePage.includes('<link rel="alternate" type="application/feed+json" href="recent-updates.json"'));
  assert(updatePage.includes('Follow recent updates'));
  assert(updatePage.includes('Following it does not add the source list’s underlying feeds'));
  assert(updatePage.includes('Recent updates'));
  assert(updatePage.includes('Garden opens today'));
  assert(updatePage.includes('This is a manual snapshot'));
  const hostedEdition = JSON.parse(updateEntries.get('recent-updates.json').toString('utf8'));
  assert.strictEqual(hostedEdition.feed_url, 'https://publisher.example/neighborhood/recent-updates.json');
  assert.strictEqual(hostedEdition.home_page_url, 'https://publisher.example/neighborhood/index.html');
  assert.strictEqual(hostedEdition._progrss.folder, 'Neighborhood');
  const parsedEdition = C.parseFeed(JSON.stringify(hostedEdition), hostedEdition.feed_url);
  assert.strictEqual(parsedEdition.edition.schema, 'progrss.folder-edition.v1');
  assert.strictEqual(parsedEdition.edition.folder, 'Neighborhood');
  assert.strictEqual(parsedEdition.edition.itemCount, 2);
  const paired = Scout.publicationChoices(
    [{kind:'feed',url:hostedEdition.feed_url,title:'Neighborhood recent updates',mime:'application/feed+json'}],
    [{kind:'shared-folder',url:locatedEdition.distribution.updateUrl,title:'Neighborhood source list for ProgRSS'}],
    hostedEdition.home_page_url
  );
  assert.strictEqual(paired.schema, 'progrss.publication-choices.v1');
  assert.strictEqual(paired.sourceList.url, locatedEdition.distribution.updateUrl);
  assert.strictEqual(paired.recentUpdates.url, hostedEdition.feed_url);
  assert.strictEqual(Scout.publicationChoices(
    [
      {kind:'feed',url:hostedEdition.feed_url,title:'Neighborhood recent updates',mime:'application/feed+json'},
      {kind:'feed',url:'https://publisher.example/neighborhood/other.json',title:'Other recent updates',mime:'application/feed+json'}
    ],
    [{kind:'shared-folder',url:locatedEdition.distribution.updateUrl,title:'Neighborhood source list for ProgRSS'}],
    hostedEdition.home_page_url
  ), null, 'competing recent-update feeds do not become one confident paired choice');
  assert.strictEqual(Scout.publicationChoices(
    [{kind:'feed',url:'https://other.example/recent-updates.json',title:'Neighborhood recent updates',mime:'application/feed+json'}],
    [{kind:'shared-folder',url:locatedEdition.distribution.updateUrl,title:'Neighborhood source list for ProgRSS'}],
    hostedEdition.home_page_url
  ), null, 'cross-origin recent updates do not become a paired choice');
  for (const secret of ['PRIVATE FULL TEXT A', 'PRIVATE FULL TEXT B', 'PRIVATE BEFORE', 'PRIVATE AFTER', 'readAt', 'starred']) {
    assert(!JSON.stringify(hostedEdition).includes(secret), `publication edition must exclude ${secret}`);
  }
  const wrongEdition = JSON.parse(JSON.stringify(edition.document));
  wrongEdition._progrss.folder = 'Another folder';
  assert.throws(() => S.build(JSON.stringify(locatedEdition), {editionRaw: JSON.stringify(wrongEdition)}), /different folder/i);
  const unsafeEdition = JSON.parse(JSON.stringify(edition.document));
  unsafeEdition.items[0].content_html = '<script>alert(1)</script>';
  assert.throws(() => S.build(JSON.stringify(locatedEdition), {editionRaw: JSON.stringify(unsafeEdition)}), /unsupported material/i);

  const inconsistentEdition = JSON.parse(JSON.stringify(edition.document));
  inconsistentEdition._progrss.itemCount += 1;
  assert.throws(() => S.build(JSON.stringify(locatedEdition), {editionRaw: JSON.stringify(inconsistentEdition)}), /inconsistent public counts/i);
  const malformedWitnessEdition = JSON.parse(JSON.stringify(edition.document));
  malformedWitnessEdition.items[0]._progrss.sources[0].type = 'mystery';
  assert.throws(() => S.build(JSON.stringify(locatedEdition), {editionRaw: JSON.stringify(malformedWitnessEdition)}), /malformed source evidence/i);
  const unattributedEdition = JSON.parse(JSON.stringify(edition.document));
  delete unattributedEdition.authors;
  assert.throws(() => S.build(JSON.stringify(locatedEdition), {editionRaw: JSON.stringify(unattributedEdition)}), /attribution does not match/i);

  assert.throws(() => S.siteFileName('https://example.com/shared/?release=1'), /direct \.json address/i);

  for (const name of ['ed25519.json', 'p256.json']) {
    const signed = JSON.parse(fs.readFileSync(path.join(root, 'fixtures', 'shared-folder', name), 'utf8'));
    const verified = await F.validate(signed);
    assert.strictEqual(verified.provenance.signatureState, 'verified');
    assert.match(verified.provenance.keyId, /:[a-f0-9]{64}$/);
  }
}

testSharedFolderIntegrity().then(() => {
  console.log('Branch selection, Contents review, Signpost publication choices, Edition folder-feed, Steady page-watch health, and shared-folder core harness: PASS');
}).catch(error => {
  console.error(error);
  process.exitCode = 1;
});
