#!/usr/bin/env python3
"""Focused Source Notes acceptance in a real installed Chromium extension.

The result identifies the rev0089 candidate while preserving the inherited
15-check managed preflight scope; the separate 18-case operator evidence
protocol remains the release-runtime boundary.

This lane loads the unpacked Extension directory with the Chrome DevTools
Protocol, writes the fixture through the shipped IndexedDB vault, and drives
the shipped side-panel UI in two real extension documents. It intentionally
uses no source-note-only test message handlers.

The result is managed browser-runtime evidence. It is not an unmanaged-browser
session, accessibility conformance, assistive-technology evidence, permission-
prompt observation, or unfamiliar-person comprehension evidence.
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import traceback
from typing import Any
import zipfile

from playwright.async_api import BrowserContext, Error as PlaywrightError, Page, async_playwright

ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = ROOT.parent
DEFAULT_BROWSER = (
    os.environ.get("PROGRSS_CHROMIUM")
    or shutil.which("chromium")
    or shutil.which("chromium-browser")
    or shutil.which("google-chrome")
    or shutil.which("google-chrome-stable")
)
SOURCE_ID = "runtime-source"
ROOT_FOLDER_ID = "runtime-reading"
CHILD_FOLDER_ID = "runtime-practical"
BASE_REASON = "Independent reporting selected for this reading route."
PRACTICAL_REASON = "Hands-on references selected for this practical route."
FINAL_REASON = "Newest reviewed wording from the first view."


def announce(label: str) -> None:
    print(f"[source-notes-runtime] {label}", flush=True)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def canonical_mode(mode: int) -> int:
    return 0o755 if stat.S_IMODE(mode) & 0o111 else 0o644


def tree_inventory(root: Path) -> tuple[list[dict[str, Any]], str]:
    rows: list[dict[str, Any]] = []
    for path in sorted(root.rglob("*"), key=lambda value: value.relative_to(root).as_posix()):
        if not path.is_file() or path.is_symlink() or path.name == ".DS_Store" or path.suffix == ".pyc":
            continue
        relative = path.relative_to(root).as_posix()
        data = path.read_bytes()
        rows.append({
            "path": relative,
            "mode": oct(canonical_mode(path.stat().st_mode)),
            "bytes": len(data),
            "sha256": sha256_bytes(data),
        })
    payload = (json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
    return rows, sha256_bytes(payload)


def archive_extension_inventory(roadcase: Path) -> tuple[list[dict[str, Any]], str]:
    rows: list[dict[str, Any]] = []
    with zipfile.ZipFile(roadcase) as archive:
        for info in sorted(archive.infolist(), key=lambda row: row.filename):
            name = info.filename.rstrip("/")
            if info.is_dir() or not name.startswith("Extension/"):
                continue
            relative = PurePosixPath(name).relative_to("Extension").as_posix()
            if PurePosixPath(relative).name == ".DS_Store" or PurePosixPath(relative).suffix == ".pyc":
                continue
            raw_mode = (info.external_attr >> 16) & 0xFFFF
            if stat.S_ISLNK(raw_mode):
                raise AssertionError(f"Extension runtime subtree contains a symlink: {name}")
            data = archive.read(info)
            rows.append({
                "path": relative,
                "mode": oct(canonical_mode(raw_mode)),
                "bytes": len(data),
                "sha256": sha256_bytes(data),
            })
    payload = (json.dumps(rows, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
    return rows, sha256_bytes(payload)


def read_os_release() -> dict[str, str]:
    result: dict[str, str] = {}
    path = Path("/etc/os-release")
    if path.is_file():
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            if "=" not in line or line.lstrip().startswith("#"):
                continue
            key, value = line.split("=", 1)
            result[key] = value.strip().strip('"')
    return result


def executable_version(executable: Path) -> str:
    try:
        completed = subprocess.run(
            [str(executable), "--version"],
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=True,
            timeout=30,
        )
        return completed.stdout.strip()
    except Exception as error:  # pragma: no cover - only used for evidence detail
        return f"unavailable: {error}"


def permission_projection(manifest: dict[str, Any]) -> dict[str, Any]:
    keys = ("permissions", "optional_permissions", "host_permissions", "optional_host_permissions")
    return {key: manifest.get(key, []) for key in keys}


async def launch(p: Any, executable: Path, profile: Path, *, headed: bool) -> BrowserContext:
    return await p.chromium.launch_persistent_context(
        str(profile),
        executable_path=str(executable),
        headless=not headed,
        viewport={"width": 430, "height": 900},
        ignore_default_args=["--disable-extensions"],
        args=[
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--enable-unsafe-extension-debugging",
            "--window-size=430,900",
        ],
    )


async def install_unpacked(context: BrowserContext, extension_root: Path) -> str:
    browser = context.browser
    if browser is None:
        raise RuntimeError("Persistent Chromium browser handle is unavailable.")
    session = await browser.new_browser_cdp_session()
    try:
        result = await session.send("Extensions.loadUnpacked", {"path": str(extension_root.resolve())})
    except PlaywrightError as error:
        if "disabled by the administrator" in str(error).lower():
            raise PermissionError("Chromium policy blocks unpacked extension installation") from error
        raise
    extension_id = str(result.get("id") or "")
    if not extension_id:
        raise AssertionError("Extensions.loadUnpacked returned no extension id")
    return extension_id


async def stop_service_worker(context: BrowserContext, extension_id: str) -> None:
    browser = context.browser
    if browser is None:
        return
    session = await browser.new_browser_cdp_session()
    expected = f"chrome-extension://{extension_id}/background.js"
    targets = (await session.send("Target.getTargets")).get("targetInfos", [])
    for target in targets:
        if target.get("type") == "service_worker" and str(target.get("url") or "") == expected:
            try:
                await session.send("Target.closeTarget", {"targetId": target["targetId"]})
            except PlaywrightError:
                pass


async def browser_metadata(context: BrowserContext) -> dict[str, Any]:
    browser = context.browser
    if browser is None:
        return {}
    session = await browser.new_browser_cdp_session()
    version = await session.send("Browser.getVersion")
    return {
        "product": version.get("product", ""),
        "revision": version.get("revision", ""),
        "userAgent": version.get("userAgent", ""),
        "jsVersion": version.get("jsVersion", ""),
        "protocolVersion": version.get("protocolVersion", ""),
    }


async def seed_fixture(context: BrowserContext, extension_id: str) -> int:
    page = await context.new_page()
    response = await page.goto(f"chrome-extension://{extension_id}/workbench/index.html", wait_until="domcontentloaded")
    assert response is not None and response.status == 200, response
    await page.wait_for_function("() => Boolean(globalThis.ProgRSSVault && globalThis.ProgRSSCore)")
    revision = await page.evaluate(
        """async ([sourceId, rootId, childId, baseReason]) => {
          const state = await ProgRSSVault.init();
          state.sources = [{
            id: sourceId, title: 'Runtime Garden Notes', type: 'rss',
            url: 'https://runtime.invalid/feed.xml', enabled: false, archivedAt: '',
            author: 'runtime acceptance', version: 1, language: 'en', titleLanguage: 'en',
            lastOutcome: 'unchanged', lastItems: 1, lastScan: '2026-10-21T11:00:00.000Z',
            lastSuccessfulAt: '2026-10-21T11:00:00.000Z', lastNewAt: '2026-10-20T11:00:00.000Z',
            lastError: '', lastProblemAt: '', lastProblem: ''
          }];
          state.collections = [
            {id: rootId, title: 'Reading', mode: 'union', version: 7, members: [
              {kind:'source', id:sourceId, reason:baseReason},
              {kind:'collection', id:childId}
            ]},
            {id: childId, title: 'Practical', mode: 'union', version: 5, members: [
              {kind:'source', id:sourceId}
            ]}
          ];
          state.items = [{
            id:`${sourceId}|runtime`, entryKey:`${sourceId}|runtime`, sourceId,
            title:'Runtime fixture update', url:'https://runtime.invalid/update',
            summary:'A bounded runtime fixture.', body:'A bounded runtime fixture.', bodyIsSummary:true,
            published:'2026-10-20T11:00:00.000Z', observedAt:'2026-10-20T11:01:00.000Z',
            kind:'new', readAt:'', starred:false
          }];
          state.snapshots = {};
          state.transferUndo = null;
          state.sourceRepairUndo = null;
          state.receiptRetirementUndo = null;
          state.sharedFolderUpdateUndo = null;
          state.pageWatchRepairUndo = null;
          await ProgRSSVault.save(state);
          await chrome.storage.local.set({libraryFolder:'all'});
          return state._revision;
        }""",
        [SOURCE_ID, ROOT_FOLDER_ID, CHILD_FOLDER_ID, BASE_REASON],
    )
    await page.close()
    await stop_service_worker(context, extension_id)
    return int(revision)


async def open_reader(context: BrowserContext, extension_id: str, errors: list[str]) -> Page:
    page = await context.new_page()
    page.on("pageerror", lambda error: errors.append(f"pageerror: {error}"))
    page.on("console", lambda message: errors.append(f"console-{message.type}: {message.text}") if message.type == "error" else None)
    response = await page.goto(f"chrome-extension://{extension_id}/sidepanel/index.html", wait_until="domcontentloaded")
    assert response is not None and response.status == 200, response
    await page.wait_for_function("() => document.querySelector('#status') && document.querySelector('#source-list').getAttribute('aria-busy') !== 'true'")
    await page.locator("#tab-sources").click()
    await page.wait_for_selector(f'.source-card[data-source-id="{SOURCE_ID}"]')
    if await page.locator("#source-folders").count():
        try:
            await page.locator("#source-folders").select_option("all")
        except PlaywrightError:
            pass
    return page


async def runtime_message(page: Page, message_type: str, data: dict[str, Any] | None = None) -> Any:
    response = await page.evaluate(
        "([type, data]) => chrome.runtime.sendMessage({target:'background', type, data:data || {}})",
        [message_type, data or {}],
    )
    if not isinstance(response, dict) or response.get("ok") is not True:
        error = (response or {}).get("error") if isinstance(response, dict) else None
        message = (error or {}).get("message") if isinstance(error, dict) else str(response)
        code = (error or {}).get("code") if isinstance(error, dict) else ""
        exc = RuntimeError(message or f"background request failed: {message_type}")
        setattr(exc, "code", code)
        raise exc
    return response.get("result")


async def runtime_message_raw(page: Page, message_type: str, data: dict[str, Any] | None = None) -> dict[str, Any]:
    result = await page.evaluate(
        "([type, data]) => chrome.runtime.sendMessage({target:'background', type, data:data || {}})",
        [message_type, data or {}],
    )
    assert isinstance(result, dict), result
    return result


def find_collection(state: dict[str, Any], collection_id: str) -> dict[str, Any]:
    return next(row for row in state.get("collections", []) if row.get("id") == collection_id)


def placement_reason(collection: dict[str, Any], source_id: str) -> str | None:
    member = next(row for row in collection.get("members", []) if row.get("kind") == "source" and row.get("id") == source_id)
    return member.get("reason") if "reason" in member else None


async def expand_source(page: Page) -> Any:
    card = page.locator(f'.source-card[data-source-id="{SOURCE_ID}"]')
    details = card.locator("details.source-options")
    if await details.count():
        if not await details.evaluate("node => node.open"):
            await details.locator("summary").click()
    elif await card.locator("summary", has_text="Activity and options").count():
        summary = card.locator("summary", has_text="Activity and options")
        parent = summary.locator("xpath=..")
        if not await parent.evaluate("node => node.open"):
            await summary.click()
    return card


async def placement(page: Page, folder_id: str) -> Any:
    card = await expand_source(page)
    return card.locator(f'.source-note-placement[data-source-note-placement-key="{folder_id}/{SOURCE_ID}"]')


async def save_reason(page: Page, folder_id: str, button_name: str, value: str) -> None:
    row = await placement(page, folder_id)
    await row.get_by_role("button", name=button_name, exact=True).click()
    card = page.locator(f'.source-card[data-source-id="{SOURCE_ID}"]')
    editor = card.locator(".source-note-editor")
    await editor.locator("textarea").fill(value)
    await editor.get_by_role("button", name="Save reason", exact=True).click()
    await page.wait_for_function("() => document.querySelector('#status').textContent.includes('Saved the reason')")


async def exercise_ui(context: BrowserContext, extension_id: str, artifacts: Path, checks: dict[str, bool], details: dict[str, Any]) -> tuple[Page, Page]:
    announce("open two real extension views")
    errors: list[str] = []
    page_a = await open_reader(context, extension_id, errors)
    page_b = await open_reader(context, extension_id, errors)

    manifest = await page_a.evaluate("chrome.runtime.getManifest()")
    permissions_before = await page_a.evaluate("chrome.permissions.getAll()")
    details["manifest"] = {"version": manifest.get("version"), "projection": permission_projection(manifest)}
    details["permissionsBefore"] = permissions_before

    announce("cancel and consequence disclosure")
    reading = await placement(page_a, ROOT_FOLDER_ID)
    assert BASE_REASON in await reading.inner_text()
    await reading.get_by_role("button", name="Edit reason for Reading", exact=True).click()
    editor = page_a.locator(f'.source-card[data-source-id="{SOURCE_ID}"] .source-note-editor')
    editor_text = await editor.inner_text()
    for phrase in (
        "stays in this local ProgRSS library",
        "publishes nothing",
        "contacts nobody",
        "creates no schedule",
        "not a ProgRSS safety claim",
    ):
        assert phrase in editor_text, (phrase, editor_text)
    textarea = editor.locator("textarea")
    await textarea.fill("Draft cancelled with Escape.")
    await textarea.press("Escape")
    await page_a.wait_for_function("() => !document.querySelector('.source-note-editor')")
    state = await runtime_message(page_a, "get-state")
    assert placement_reason(find_collection(state, ROOT_FOLDER_ID), SOURCE_ID) == BASE_REASON
    checks["cancelAndEscapeNoWrite"] = True
    checks["consequenceDisclosure"] = True

    announce("independent two-folder reasons")
    practical = await placement(page_a, CHILD_FOLDER_ID)
    await practical.get_by_role("button", name="Add reason for Reading › Practical", exact=True).click()
    editor = page_a.locator(f'.source-card[data-source-id="{SOURCE_ID}"] .source-note-editor')
    await editor.locator("textarea").fill(PRACTICAL_REASON)
    await editor.get_by_role("button", name="Save reason", exact=True).click()
    await page_a.wait_for_function("() => document.querySelector('#status').textContent.includes('Saved the reason for Reading › Practical')")
    state = await runtime_message(page_a, "get-state")
    assert placement_reason(find_collection(state, ROOT_FOLDER_ID), SOURCE_ID) == BASE_REASON
    assert placement_reason(find_collection(state, CHILD_FOLDER_ID), SOURCE_ID) == PRACTICAL_REASON
    checks["twoFolderIndependence"] = True

    announce("clear and guarded undo")
    practical = await placement(page_a, CHILD_FOLDER_ID)
    await practical.get_by_role("button", name="Edit reason for Reading › Practical", exact=True).click()
    editor = page_a.locator(f'.source-card[data-source-id="{SOURCE_ID}"] .source-note-editor')
    await editor.get_by_role("button", name="Clear reason", exact=True).click()
    await page_a.wait_for_function("() => document.querySelector('#status').textContent.includes('Cleared the reason for Reading › Practical')")
    state = await runtime_message(page_a, "get-state")
    assert placement_reason(find_collection(state, CHILD_FOLDER_ID), SOURCE_ID) is None
    await page_a.locator("#undo-source-note").click()
    await page_a.wait_for_function("() => document.querySelector('#status').textContent.includes('earlier placement reason was restored')")
    state = await runtime_message(page_a, "get-state")
    assert placement_reason(find_collection(state, CHILD_FOLDER_ID), SOURCE_ID) == PRACTICAL_REASON
    checks["clearAndGuardedUndo"] = True

    announce("Unicode boundary and interrupted draft")
    reading = await placement(page_a, ROOT_FOLDER_ID)
    await reading.get_by_role("button", name="Edit reason for Reading", exact=True).click()
    editor = page_a.locator(f'.source-card[data-source-id="{SOURCE_ID}"] .source-note-editor')
    textarea = editor.locator("textarea")
    await textarea.fill("x" * 281)
    assert await textarea.get_attribute("aria-invalid") == "true"
    assert await editor.get_by_role("button", name="Save reason", exact=True).is_disabled()
    await textarea.fill("Draft survives an ordinary library rename. 🪴")
    await page_a.bring_to_front()
    await textarea.focus()
    assert await textarea.evaluate("node => document.activeElement === node")
    await runtime_message(page_a, "rename-source", {"sourceId": SOURCE_ID, "title": "Runtime Garden Notes renamed"})
    await page_a.wait_for_function(
        f"() => document.querySelector('textarea[data-source-note-editor-key=\"{ROOT_FOLDER_ID}/{SOURCE_ID}\"]')?.value.includes('Draft survives')"
    )
    textarea = page_a.locator(f'textarea[data-source-note-editor-key="{ROOT_FOLDER_ID}/{SOURCE_ID}"]')
    assert await textarea.input_value() == "Draft survives an ordinary library rename. 🪴"
    assert await textarea.evaluate("node => document.activeElement === node")
    checks["unicodeBoundary"] = True
    checks["ordinaryInterruptionPreservesDraftAndFocus"] = True

    announce("real two-view stale edit")
    # Real two-view stale edit. No source-note test hook is used.
    reading_b = await placement(page_b, ROOT_FOLDER_ID)
    await reading_b.get_by_role("button", name="Edit reason for Reading", exact=True).click()
    editor_b = page_b.locator(f'.source-card[data-source-id="{SOURCE_ID}"] .source-note-editor')
    await editor_b.locator("textarea").fill("Newer wording from the second view.")
    await editor_b.get_by_role("button", name="Save reason", exact=True).click()
    await page_b.wait_for_function("() => document.querySelector('#status').textContent.includes('Saved the reason for Reading')")
    assert await page_b.locator("#source-note-undo").is_visible()
    state_after_page_b_save = await runtime_message(page_b, "get-state")
    page_b_undo_version = find_collection(state_after_page_b_save, ROOT_FOLDER_ID)["version"]

    textarea = page_a.locator(f'textarea[data-source-note-editor-key="{ROOT_FOLDER_ID}/{SOURCE_ID}"]')
    await textarea.fill("Stale draft that must not overwrite the second view.")
    await page_a.locator(f'.source-card[data-source-id="{SOURCE_ID}"] .source-note-editor').get_by_role("button", name="Save reason", exact=True).click()
    await page_a.wait_for_function("() => document.querySelector('#status').textContent.includes('newer')")
    assert "Cancel, review the latest reason" in await page_a.locator(".source-note-editor-error").inner_text()
    assert await textarea.input_value() == "Stale draft that must not overwrite the second view."
    state = await runtime_message(page_a, "get-state")
    assert placement_reason(find_collection(state, ROOT_FOLDER_ID), SOURCE_ID) == "Newer wording from the second view."
    checks["realTwoViewStaleSaveRefused"] = True
    await page_a.locator(".source-note-editor").get_by_role("button", name="Cancel", exact=True).click()

    announce("real two-view stale undo")
    # A newer first-view save invalidates the second view's guarded undo.
    # The broadcast proactively hides page B's local undo control; replay the
    # exact previously armed guard through the shipped background request and
    # require a fail-closed stale refusal. This is a production request, not a
    # source-note-only test hook.
    await save_reason(page_a, ROOT_FOLDER_ID, "Edit reason for Reading", FINAL_REASON)
    details["undoVisibleAfterNewerEdit"] = await page_b.locator("#source-note-undo").is_visible()
    stale_undo = await runtime_message_raw(page_b, "undo-source-placement-reason", {
        "sourceId": SOURCE_ID,
        "collectionId": ROOT_FOLDER_ID,
        "expectedVersion": page_b_undo_version,
        "expectedCurrentReason": "Newer wording from the second view.",
        "previousReason": BASE_REASON,
    })
    assert stale_undo.get("ok") is False, stale_undo
    assert stale_undo.get("code") == "STALE_SOURCE_NOTE_UNDO", stale_undo
    assert "Undo was stopped" in str(stale_undo.get("error") or ""), stale_undo
    state = await runtime_message(page_b, "get-state")
    assert placement_reason(find_collection(state, ROOT_FOLDER_ID), SOURCE_ID) == FINAL_REASON
    details["staleUndoRefusal"] = {"code": stale_undo.get("code"), "message": stale_undo.get("error")}
    checks["realTwoViewStaleUndoRefused"] = True

    announce("capture pre-restart evidence and permission projection")
    await (await placement(page_a, ROOT_FOLDER_ID)).screenshot(path=str(artifacts / "source-note-reading-placement.png"))
    await (await placement(page_a, CHILD_FOLDER_ID)).screenshot(path=str(artifacts / "source-note-practical-placement.png"))
    await page_a.screenshot(path=str(artifacts / "source-notes-runtime-before-restart.png"), full_page=True)

    permissions_after = await page_a.evaluate("chrome.permissions.getAll()")
    details["permissionsAfter"] = permissions_after
    assert permissions_before == permissions_after
    checks["permissionStateUnchanged"] = True

    filtered_errors = [row for row in errors if "favicon" not in row.lower()]
    if filtered_errors:
        raise AssertionError(f"extension page errors: {filtered_errors}")
    return page_a, page_b


async def post_restart_and_artifacts(
    p: Any,
    executable: Path,
    profile: Path,
    extension_id: str,
    *,
    headed: bool,
    artifacts: Path,
    checks: dict[str, bool],
    details: dict[str, Any],
) -> None:
    announce("restart persistent browser profile")
    context = await launch(p, executable, profile, headed=headed)
    context.set_default_timeout(15000)
    context.set_default_navigation_timeout(30000)
    errors: list[str] = []
    try:
        page = await open_reader(context, extension_id, errors)
        state = await runtime_message(page, "get-state")
        assert placement_reason(find_collection(state, ROOT_FOLDER_ID), SOURCE_ID) == FINAL_REASON
        assert placement_reason(find_collection(state, CHILD_FOLDER_ID), SOURCE_ID) == PRACTICAL_REASON
        checks["restartPersistence"] = True
        announce("native complete-route export")

        root_export = await runtime_message(page, "export-shared-folder", {
            "collectionId": ROOT_FOLDER_ID,
            "format": "bundle",
            "options": {
                "curator": "Runtime curator",
                "note": "Exact-package runtime fixture.",
                "exportedAt": "2026-10-21T12:00:00.000Z",
            },
        })
        root_raw = str(root_export["raw"])
        root_document = json.loads(root_raw)
        root_collection = next(row for row in root_document["collections"] if row["id"] == ROOT_FOLDER_ID)
        child_collection = next(row for row in root_document["collections"] if row["id"] == CHILD_FOLDER_ID)
        assert placement_reason(root_collection, SOURCE_ID) == FINAL_REASON
        assert placement_reason(child_collection, SOURCE_ID) == PRACTICAL_REASON
        assert root_export["summary"]["sourceNoteCount"] == 2
        details["completeRouteArtifact"] = {
            "sha256": sha256_bytes(root_raw.encode("utf-8")),
            "bytes": len(root_raw.encode("utf-8")),
            "integrityDigest": root_document["integrity"]["digest"],
            "sourceNoteCount": root_export["summary"]["sourceNoteCount"],
        }
        checks["completeRouteDisclosure"] = True
        announce("selected-branch export")

        child_export = await runtime_message(page, "export-shared-folder", {
            "collectionId": CHILD_FOLDER_ID,
            "format": "bundle",
            "options": {
                "curator": "Runtime curator",
                "note": "Selected branch fixture.",
                "exportedAt": "2026-10-21T12:01:00.000Z",
            },
        })
        child_raw = str(child_export["raw"])
        child_document = json.loads(child_raw)
        assert FINAL_REASON not in child_raw
        assert PRACTICAL_REASON in child_raw
        assert len(child_document["collections"]) == 1
        details["selectedBranchArtifact"] = {
            "sha256": sha256_bytes(child_raw.encode("utf-8")),
            "bytes": len(child_raw.encode("utf-8")),
            "integrityDigest": child_document["integrity"]["digest"],
            "sourceNoteCount": child_export["summary"]["sourceNoteCount"],
        }
        checks["selectedBranchPreservation"] = True
        announce("OPML omission evidence")

        opml = await runtime_message(page, "export-shared-folder", {
            "collectionId": ROOT_FOLDER_ID,
            "format": "opml",
            "options": {"curator": "Runtime curator"},
        })
        assert FINAL_REASON not in opml["raw"] and PRACTICAL_REASON not in opml["raw"]
        assert "reason=" not in opml["raw"]
        assert opml["summary"]["omittedSourceNoteCount"] == 2
        omitted = {(row["folderId"], row["sourceId"]) for row in opml["summary"]["omittedSourceNotePlacements"]}
        assert omitted == {(ROOT_FOLDER_ID, SOURCE_ID), (CHILD_FOLDER_ID, SOURCE_ID)}
        details["opmlArtifact"] = {
            "sha256": sha256_bytes(str(opml["raw"]).encode("utf-8")),
            "bytes": len(str(opml["raw"]).encode("utf-8")),
            "omittedSourceNoteCount": opml["summary"]["omittedSourceNoteCount"],
            "omittedPlacementKeys": sorted(f"{folder}/{source}" for folder, source in omitted),
        }
        checks["opmlOmissionEvidence"] = True
        announce("native digest refusal")

        valid_preview = await runtime_message(page, "preview-shared-folder", {"raw": root_raw})
        assert valid_preview.get("canImport") is True or valid_preview.get("canUpdate") is True
        tampered = json.loads(root_raw)
        next(row for row in tampered["collections"] if row["id"] == ROOT_FOLDER_ID)["members"][0]["reason"] = "Changed after digest."
        tampered_raw = json.dumps(tampered, ensure_ascii=False, separators=(",", ":"))
        tampered_response = await runtime_message_raw(page, "preview-shared-folder", {"raw": tampered_raw})
        assert tampered_response.get("ok") is False, tampered_response
        tampered_message = str(tampered_response.get("error") or "")
        assert "digest" in tampered_message.lower() and "match" in tampered_message.lower(), tampered_response
        checks["nativeIntegrityRefusesReasonMutation"] = True

        announce("divergent later-copy placement decision")
        # Import the reviewed native artifact, make a recipient-only edit, then
        # present a divergent curator copy and resolve that exact placement by
        # keeping the recipient wording.
        initial_preview = await runtime_message(page, "preview-shared-folder", {"raw": root_raw})
        imported = await runtime_message(page, "import-shared-folder", {
            "raw": root_raw,
            "reviewedRevision": initial_preview["reviewedRevision"],
            "selectedFolderId": "",
        })
        imported_root_id = imported["rootId"]
        state = await runtime_message(page, "get-state")
        imported_root = find_collection(state, imported_root_id)
        imported_source = next(row["id"] for row in imported_root["members"] if row["kind"] == "source")
        imported_base = placement_reason(imported_root, imported_source)
        assert imported_base == FINAL_REASON
        await runtime_message(page, "set-source-placement-reason", {
            "sourceId": imported_source,
            "collectionId": imported_root_id,
            "expectedVersion": imported_root["version"],
            "expectedReason": imported_base,
            "reason": "Recipient wording kept after review.",
        })

        state = await runtime_message(page, "get-state")
        original_root = find_collection(state, ROOT_FOLDER_ID)
        await runtime_message(page, "set-source-placement-reason", {
            "sourceId": SOURCE_ID,
            "collectionId": ROOT_FOLDER_ID,
            "expectedVersion": original_root["version"],
            "expectedReason": placement_reason(original_root, SOURCE_ID),
            "reason": "Curator wording in the later copy.",
        })
        later_export = await runtime_message(page, "export-shared-folder", {
            "collectionId": ROOT_FOLDER_ID,
            "format": "bundle",
            "options": {
                "curator": "Runtime curator",
                "note": "Exact-package runtime fixture.",
                "exportedAt": "2026-10-21T12:05:00.000Z",
            },
        })
        later_raw = str(later_export["raw"])
        update_preview = await runtime_message(page, "preview-shared-folder", {
            "raw": later_raw,
            "targetRootId": imported_root_id,
        })
        assert update_preview["requiresConflictChoices"] is True
        decision_ids = list(update_preview["mergeReview"]["decisionIds"])
        placement_ids = [value for value in decision_ids if value.startswith("placement:") and value.endswith(":reason")]
        assert len(placement_ids) == 1, decision_ids
        conflict_rows = update_preview["mergeReview"].get("conflicts", [])
        conflict = next(row for row in conflict_rows if row["id"] == placement_ids[0])
        assert conflict["local"] == "Recipient wording kept after review."
        assert conflict["incoming"] == "Curator wording in the later copy."
        updated = await runtime_message(page, "update-shared-folder", {
            "raw": later_raw,
            "reviewedRevision": update_preview["reviewedRevision"],
            "targetRootId": imported_root_id,
            "acknowledgeTrustChange": False,
            "conflictChoices": {placement_ids[0]: "keep-local"},
            "acknowledgeRecipeChanges": False,
        })
        assert updated["conflictChoices"][placement_ids[0]] == "keep-local"
        state = await runtime_message(page, "get-state")
        imported_root = find_collection(state, imported_root_id)
        assert placement_reason(imported_root, imported_source) == "Recipient wording kept after review."
        details["divergentLaterCopy"] = {
            "conflictId": placement_ids[0],
            "base": FINAL_REASON,
            "recipient": "Recipient wording kept after review.",
            "curator": "Curator wording in the later copy.",
            "decision": "keep-local",
        }
        checks["divergentLaterCopyPlacementDecision"] = True

        await page.screenshot(path=str(artifacts / "source-notes-runtime-after-restart.png"), full_page=True)
        filtered_errors = [row for row in errors if "favicon" not in row.lower()]
        if filtered_errors:
            raise AssertionError(f"extension page errors after restart: {filtered_errors}")
        await page.close()
    finally:
        await context.close()


async def run_acceptance(args: argparse.Namespace, result: dict[str, Any]) -> None:
    executable = Path(args.browser).resolve()
    extension_root = Path(args.extension_root).resolve()
    roadcase = Path(args.roadcase).resolve() if args.roadcase else None
    profile = Path(args.profile).resolve()
    artifacts = Path(args.artifacts).resolve()
    artifacts.mkdir(parents=True, exist_ok=True)
    profile.mkdir(parents=True, exist_ok=True)

    local_rows, local_digest = tree_inventory(extension_root)
    result["package"] = {
        "extensionRoot": str(extension_root),
        "extensionFiles": len(local_rows),
        "extensionSubtreeSha256": local_digest,
        "manifestSha256": sha256_file(extension_root / "manifest.json"),
        "fixtureSha256": sha256_file(REPO_ROOT / "fixtures" / "source-notes" / "native-placement-replay.json"),
    }
    if roadcase:
        archive_rows, archive_digest = archive_extension_inventory(roadcase)
        result["package"].update({
            "roadcase": roadcase.name,
            "roadcaseSha256": sha256_file(roadcase),
            "roadcaseBytes": roadcase.stat().st_size,
            "archiveExtensionFiles": len(archive_rows),
            "archiveExtensionSubtreeSha256": archive_digest,
            "archiveMatchesExtractedExtension": archive_rows == local_rows and archive_digest == local_digest,
        })
        if archive_rows != local_rows or archive_digest != local_digest:
            raise AssertionError("the extracted Extension subtree does not match the supplied Roadcase")

    result["environment"] = {
        "browserExecutable": str(executable),
        "browserCommandVersion": executable_version(executable),
        "headedUnderVirtualDisplay": bool(args.headed),
        "automation": "Playwright persistent context plus Chrome DevTools Protocol Extensions.loadUnpacked",
        "profile": {"path": str(profile), "freshAtStart": not any(profile.iterdir())},
        "osRelease": read_os_release(),
        "kernel": platform.platform(),
        "python": sys.version.split()[0],
        "playwright": getattr(sys.modules.get("playwright"), "__version__", "installed"),
        "policyOverrideDeclared": bool(args.policy_override_declared),
    }
    result["claimBoundary"] = {
        "classification": "managed-exact-archive-runtime-preflight",
        "unmanagedBrowserAcceptance": False,
        "currentStableAcceptance": False,
        "humanPermissionPromptObservation": False,
        "accessibilityConformance": False,
        "assistiveTechnologyEvidence": False,
        "unfamiliarPersonComprehension": False,
    }

    checks: dict[str, bool] = {}
    details: dict[str, Any] = {}
    result["checks"] = checks
    result["details"] = details

    async with async_playwright() as p:
        announce("launch available Chromium")
        context = await launch(p, executable, profile, headed=args.headed)
        context.set_default_timeout(15000)
        context.set_default_navigation_timeout(30000)
        try:
            details["browser"] = await browser_metadata(context)
            announce("load exact unpacked Extension subtree")
            extension_id = await install_unpacked(context, extension_root)
            details["extensionId"] = extension_id
            announce("seed fixture through shipped IndexedDB vault")
            seeded_revision = await seed_fixture(context, extension_id)
            details["seededVaultRevision"] = seeded_revision
            page_a, page_b = await exercise_ui(context, extension_id, artifacts, checks, details)
            await page_a.close()
            await page_b.close()
        finally:
            await context.close()
        await post_restart_and_artifacts(
            p,
            executable,
            profile,
            extension_id,
            headed=args.headed,
            artifacts=artifacts,
            checks=checks,
            details=details,
        )

    expected_checks = {
        "cancelAndEscapeNoWrite",
        "consequenceDisclosure",
        "twoFolderIndependence",
        "clearAndGuardedUndo",
        "unicodeBoundary",
        "ordinaryInterruptionPreservesDraftAndFocus",
        "realTwoViewStaleSaveRefused",
        "realTwoViewStaleUndoRefused",
        "permissionStateUnchanged",
        "restartPersistence",
        "completeRouteDisclosure",
        "selectedBranchPreservation",
        "opmlOmissionEvidence",
        "nativeIntegrityRefusesReasonMutation",
        "divergentLaterCopyPlacementDecision",
    }
    missing = sorted(expected_checks - {key for key, value in checks.items() if value})
    if missing:
        raise AssertionError(f"runtime checks did not pass: {missing}")


async def async_main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--browser", default=DEFAULT_BROWSER)
    parser.add_argument("--extension-root", type=Path, default=ROOT)
    parser.add_argument("--roadcase", type=Path)
    parser.add_argument("--profile", type=Path)
    parser.add_argument("--artifacts", type=Path)
    parser.add_argument("--result", type=Path)
    parser.add_argument("--headed", action="store_true")
    parser.add_argument("--policy-override-declared", action="store_true")
    args = parser.parse_args()
    if not args.browser:
        print("SKIP Source Notes installed acceptance: no Chromium executable", file=sys.stderr)
        return 77

    temporary: tempfile.TemporaryDirectory[str] | None = None
    if args.profile is None or args.artifacts is None or args.result is None:
        temporary = tempfile.TemporaryDirectory(prefix="progrss-source-notes-runtime-")
        base = Path(temporary.name)
        args.profile = args.profile or base / "profile"
        args.artifacts = args.artifacts or base / "artifacts"
        args.result = args.result or base / "result.json"

    result: dict[str, Any] = {
        "schema": "progrss.source-notes.packaged-runtime.v1",
        "revision": "rev0089-source-notes-channel-binding",
        "startedUtc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "pass": False,
    }
    result_path = Path(args.result).resolve()
    result_path.parent.mkdir(parents=True, exist_ok=True)
    exit_code = 1
    try:
        await run_acceptance(args, result)
        result["pass"] = True
        exit_code = 0
    except PermissionError as error:
        result["blocked"] = {"kind": "extension-install-policy", "message": str(error)}
        exit_code = 77
    except Exception as error:
        result["error"] = {
            "type": type(error).__name__,
            "message": str(error),
            "traceback": traceback.format_exc(),
        }
        exit_code = 1
    finally:
        result["finishedUtc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        result_path.write_text(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
        print(json.dumps({
            "pass": result.get("pass"),
            "blocked": result.get("blocked"),
            "result": str(result_path),
            "checks": result.get("checks", {}),
        }, ensure_ascii=False, sort_keys=True))
        if temporary is not None and exit_code != 0:
            # Keep the path in the printed result useful only for the duration of
            # this process; callers needing evidence must pass explicit paths.
            temporary.cleanup()
    return exit_code


if __name__ == "__main__":
    raise SystemExit(asyncio.run(async_main()))
