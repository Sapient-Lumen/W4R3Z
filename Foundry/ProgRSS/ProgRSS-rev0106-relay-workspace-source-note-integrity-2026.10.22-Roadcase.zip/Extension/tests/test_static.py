from __future__ import annotations

import json
from pathlib import Path
import re
import subprocess
import unittest
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parents[1]


class ManifestTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.manifest = json.loads((ROOT / "manifest.json").read_text())

    def test_manifest_v3_and_version(self) -> None:
        self.assertEqual(self.manifest["manifest_version"], 3)
        self.assertEqual(self.manifest["version"], "0.80.0")
        self.assertIn("Roadcase", self.manifest["version_name"])

    def test_permissions_are_bounded(self) -> None:
        self.assertNotIn("<all_urls>", self.manifest.get("host_permissions", []))
        self.assertEqual(set(self.manifest["optional_host_permissions"]), {"http://*/*", "https://*/*"})
        self.assertNotIn("history", self.manifest["permissions"])
        self.assertNotIn("tabs", self.manifest["permissions"])
        self.assertNotIn("downloads", self.manifest["permissions"])
        self.assertNotIn("unlimitedStorage", self.manifest["permissions"])
        self.assertIn("sidePanel", self.manifest["permissions"])
        self.assertIn("offscreen", self.manifest["permissions"])
        self.assertIn("webRequest", self.manifest["permissions"])
        self.assertEqual(self.manifest.get("host_permissions", []), [])

    def test_manifest_references_exist(self) -> None:
        refs = [
            self.manifest["background"]["service_worker"],
            self.manifest["side_panel"]["default_path"],
            self.manifest["options_ui"]["page"],
            *self.manifest["icons"].values(),
        ]
        for ref in refs:
            self.assertTrue((ROOT / ref).is_file(), ref)

    def test_local_only_csp(self) -> None:
        csp = self.manifest["content_security_policy"]["extension_pages"]
        self.assertIn("script-src 'self'", csp)
        self.assertNotRegex(csp, r"https?://")
        self.assertNotIn("unsafe-eval", csp)
        self.assertNotIn("unsafe-inline", csp)


class FirefoxManifestTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.root = ROOT / "Firefox"
        cls.manifest = json.loads((cls.root / "manifest.json").read_text())

    def test_firefox_is_a_native_sidebar_package(self) -> None:
        self.assertEqual(self.manifest["manifest_version"], 3)
        self.assertEqual(self.manifest["version"], "0.80.0")
        self.assertNotIn("version_name", self.manifest)
        self.assertEqual(self.manifest["sidebar_action"]["default_panel"], "sidepanel/index.html")
        self.assertFalse(self.manifest["sidebar_action"]["open_at_install"])
        self.assertFalse(self.manifest["background"]["persistent"])
        self.assertNotIn("sidePanel", self.manifest["permissions"])
        self.assertNotIn("offscreen", self.manifest["permissions"])
        self.assertIn("webRequest", self.manifest["permissions"])
        self.assertEqual(set(self.manifest["optional_host_permissions"]), {"http://*/*", "https://*/*"})
        gecko = self.manifest["browser_specific_settings"]["gecko"]
        self.assertEqual(gecko["data_collection_permissions"]["required"], ["none"])
        self.assertTrue(gecko["id"].startswith("progrss@"))

    def test_firefox_background_scripts_are_ordered_and_present(self) -> None:
        scripts = self.manifest["background"]["scripts"]
        self.assertEqual(scripts[-1], "background.js")
        self.assertLess(scripts.index("shared/core.js"), scripts.index("shared/parser.js"))
        self.assertLess(scripts.index("shared/parser.js"), scripts.index("background.js"))
        refs = [
            *scripts,
            self.manifest["sidebar_action"]["default_panel"],
            self.manifest["options_ui"]["page"],
            *self.manifest["icons"].values(),
        ]
        for ref in refs:
            self.assertTrue((self.root / ref).is_file(), ref)

    def test_firefox_runtime_is_generated_from_shared_sources(self) -> None:
        shared_files = ["background.js"]
        for directory in ("fixtures", "icons", "shared", "sidepanel", "workbench"):
            shared_files.extend(str(path.relative_to(ROOT)) for path in (ROOT / directory).rglob("*") if path.is_file())
        for relative in shared_files:
            self.assertEqual((ROOT / relative).read_bytes(), (self.root / relative).read_bytes(), relative)
        self.assertFalse((self.root / "offscreen").exists())
        self.assertFalse((self.root / "tests").exists())

    def test_browser_runtime_uses_both_standard_namespaces(self) -> None:
        for relative in ("background.js", "sidepanel/app.js", "offscreen/offscreen.js", "workbench/extension-workbench.js"):
            source = (ROOT / relative).read_text()
            self.assertIn("globalThis.browser || globalThis.chrome", source, relative)
        background = (ROOT / "background.js").read_text()
        self.assertIn("api.sidebarAction.open()", background)
        self.assertIn("canParseInBackground", background)
        self.assertIn("PARSER_UNAVAILABLE", background)



class HtmlTests(unittest.TestCase):
    def check_document(self, relative: str) -> BeautifulSoup:
        path = ROOT / relative
        soup = BeautifulSoup(path.read_text(), "html.parser")
        self.assertIsNotNone(soup.html)
        ids: dict[str, int] = {}
        for tag in soup.find_all(id=True):
            ids[tag["id"]] = ids.get(tag["id"], 0) + 1
        self.assertEqual([key for key, count in ids.items() if count > 1], [], relative)
        for tag in soup.find_all(True):
            for attr in tag.attrs:
                self.assertFalse(attr.lower().startswith("on"), f"inline handler {relative}: {attr}")
        for script in soup.find_all("script"):
            source = script.get("src")
            if source:
                self.assertFalse(re.match(r"(?:https?:)?//", source), source)
                self.assertTrue((path.parent / source).resolve().is_file(), source)
            else:
                self.assertNotIn(script.get("type", "").lower(), {"", "text/javascript", "application/javascript"}, f"executable inline script in {relative}")
        for link in soup.find_all("link", href=True):
            href = link["href"]
            self.assertFalse(re.match(r"(?:https?:)?//", href), href)
            self.assertTrue((path.parent / href).resolve().is_file(), href)
        return soup

    def test_sidepanel_document(self) -> None:
        soup = self.check_document("sidepanel/index.html")
        labels = " ".join(soup.stripped_strings)
        self.assertIn("What’s new", labels)
        self.assertIn("Places you follow", labels)
        self.assertIn("Follow something useful", labels)
        self.assertIn("Use this page", labels)
        self.assertIn("Paste an address", labels)
        self.assertIn("Move from another reader", labels)
        self.assertIn("Move subscriptions from another reader", labels)
        self.assertIn("Move this ProgRSS library", labels)
        self.assertIn("Keep the file private", labels)
        self.assertIn("Open Advanced Workbench", labels)
        self.assertIsNotNone(soup.select_one('input[type="search"]#reading-search'))
        self.assertIsNotNone(soup.select_one('input[type="file"]#opml-file'))
        self.assertIsNotNone(soup.select_one('input[type="file"]#backup-file'))
        self.assertIsNotNone(soup.select_one('#export-library'))
        self.assertIsNotNone(soup.select_one('#undo-library-move'))
        self.assertIsNotNone(soup.select_one('#share-publication-site'))
        self.assertIsNotNone(soup.select_one('#save-publication-site'))
        self.assertIn("Save ready-to-host website", labels)
        self.assertIn("Put this folder on a website", labels)
        self.assertIsNotNone(soup.select_one('#storage-incident'))
        self.assertIsNotNone(soup.select_one('#save-recovery-copy'))
        self.assertIsNotNone(soup.select_one('#check-storage'))
        self.assertIsNone(soup.select_one('#storage-incident[aria-live]'))
        self.assertIsNotNone(soup.select_one('#today-folder-scope'))
        self.assertIsNotNone(soup.select_one('#source-folder-scope'))
        self.assertIsNotNone(soup.select_one('#follow-handoff'))
        self.assertIsNotNone(soup.select_one('#folder-undo-row'))
        self.assertIsNotNone(soup.select_one('#view-detail'))
        self.assertIsNotNone(soup.select_one('#detail-body'))
        self.assertIsNotNone(soup.select_one('#detail-back'))
        self.assertEqual(soup.select_one('#detail-heading').get('tabindex'), '-1')
        self.assertEqual(len(soup.select('.start-choice')), 4)
        self.assertNotIn("semantic digest", labels.lower())
        self.assertIsNotNone(soup.select_one("[role=status][aria-live=polite]"))
        self.assertEqual(len(soup.select("[aria-live]")), 2)
        self.assertIsNone(soup.select_one("#item-list[aria-live], #source-list[aria-live], #discovery[aria-live], #opml-preview[aria-live]"))
        for heading in ("today-heading", "sources-heading", "add-heading"):
            self.assertEqual(soup.select_one(f"#{heading}").get("tabindex"), "-1")
        self.assertIsNotNone(soup.select_one("nav[aria-label]"))
        theme = soup.select_one("#theme-toggle")
        self.assertIsNotNone(theme)
        self.assertEqual(theme.get("aria-label"), "Use light theme")
        self.assertEqual(soup.select_one("meta[name=color-scheme]").get("content"), "dark light")

    def test_everyday_reader_dark_theme_is_default_and_light_is_explicit(self) -> None:
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        css = (ROOT / "sidepanel" / "app.css").read_text()
        self.assertIn("theme: 'dark'", panel)
        self.assertIn("appearanceTheme", panel)
        self.assertIn("applyTheme('dark')", panel)
        self.assertIn(':root[data-theme="light"]', css)
        self.assertIn('color-scheme: dark', css)
        self.assertIn('--accent: #2df7ce', css)
        self.assertIn('@media (forced-colors: active)', css)
        self.assertIn('.app-shell::before { display: none; }', css)

    def test_offscreen_document(self) -> None:
        self.check_document("offscreen/index.html")

    def test_workbench_document(self) -> None:
        soup = self.check_document("workbench/index.html")
        labels = " ".join(list(soup.stripped_strings)[:1000])
        self.assertIn("Advanced Workbench", labels)
        self.assertIn("Open everyday reader", labels)
        self.assertIn("Timeline", labels)
        self.assertIn("Page repair lab", labels)

    def test_local_interoperability_corpus_is_shared_byte_for_byte(self) -> None:
        extension = ROOT / "fixtures" / "interoperability"
        cli = ROOT.parent / "CLI" / "fixtures" / "interoperability"
        manifest = json.loads((extension / "corpus.json").read_text())
        self.assertEqual(manifest["schema"], "progrss.feed.corpus.v1")
        self.assertEqual(manifest["caseCount"], 32)
        self.assertFalse(manifest["network"])
        self.assertFalse(manifest["writes"])
        extension_files = sorted(path.relative_to(extension) for path in extension.rglob("*") if path.is_file())
        cli_files = sorted(path.relative_to(cli) for path in cli.rglob("*") if path.is_file())
        self.assertEqual(extension_files, cli_files)
        for relative in extension_files:
            self.assertEqual((extension / relative).read_bytes(), (cli / relative).read_bytes(), str(relative))


class JavaScriptTests(unittest.TestCase):
    def test_every_javascript_file_parses(self) -> None:
        files = sorted(ROOT.rglob("*.js"))
        self.assertGreater(len(files), 20)
        failures = []
        for path in files:
            result = subprocess.run(["node", "--check", str(path)], text=True, capture_output=True, check=False)
            if result.returncode:
                failures.append(f"{path.relative_to(ROOT)}\n{result.stderr}")
        self.assertEqual(failures, [])

    def test_sidepanel_avoids_untrusted_inner_html(self) -> None:
        source = (ROOT / "sidepanel" / "app.js").read_text()
        self.assertNotIn("innerHTML", source)
        self.assertIn("textContent", source)
        self.assertIn("api.permissions.request", source)

    def test_node_pairing_is_explicit_loopback_summary_only_and_revocable(self) -> None:
        manifest = json.loads((ROOT / "manifest.json").read_text())
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        html = (ROOT / "sidepanel" / "index.html").read_text()
        css = (ROOT / "sidepanel" / "app.css").read_text()
        self.assertIn("http://*/*", manifest["optional_host_permissions"])
        for marker in (
            'id="focus-node-pairing"', 'id="node-invitation"', 'id="review-node"',
            'id="pair-node"', 'id="check-node"', 'id="unpair-node"',
            'id="forget-node"', 'This pairing cannot', 'Nothing is synchronized automatically',
        ):
            self.assertIn(marker, html)
        for marker in (
            "NODE_PAIRING_PERMISSION = 'http://127.0.0.1/*'",
            "url.protocol !== 'http:' || url.hostname !== '127.0.0.1'",
            "const granted = Boolean(await api.permissions.request(request))",
            "api.permissions.remove({origins: [NODE_PAIRING_PERMISSION]})",
            "hostPermissionAdded: Boolean(review.hostPermissionAdded)",
            "'/api/v1/pairing-review'", "'/api/v1/pairings'",
            "'/api/v1/pairing'", "'/api/v1/pairing/revoke'",
            "readLibrarySummary: true", "readItems: false",
            "readSourceAddresses: false", "writeLibrary: false",
            "fetchSources: false", "automatic !== false",
            "api.storage.local.set({nodePairing: stored})",
            "api.storage.local.remove('nodePairing')",
        ):
            self.assertIn(marker, panel)
        self.assertIn("@media (forced-colors: active)", css)
        self.assertIn(".node-pairing-card::before { display: none; }", css)
        start_body = panel[panel.index('async function start()'):]
        self.assertNotIn("checkNodePairing()", start_body)
        self.assertNotIn("reviewNodeInvitation()", start_body)

    def test_node_exchange_is_explicit_artifact_scoped_and_three_door(self) -> None:
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        html = (ROOT / "sidepanel" / "index.html").read_text()
        css = (ROOT / "sidepanel" / "app.css").read_text()
        background = (ROOT / "background.js").read_text()
        for marker in (
            "progrss.node.exchange.v1", "fragment.getAll('exchange')",
            "'/api/v1/exchange-review'", "'/api/v1/exchange/source-list'",
            "'/api/v1/exchange/recent-updates'",
            "One reviewed route · three choices", "Follow updates",
            "Add the complete route", "Take one branch",
            "The handoff artifact digest changed after review.",
            "Back to shared route choices",
            "grants no write access to either library",
            "Curator’s reason for this folder", "not a ProgRSS safety claim",
            "document.counts.sourceNotes", "source.placements",
        ):
            self.assertIn(marker, panel)
        self.assertIn("preview-feed-text", panel)
        self.assertIn("preview-feed-text", background)
        self.assertIn("Website, feed, source-list, or ProgRSS handoff address", html)
        self.assertIn(".exchange-review-card", css)
        self.assertIn(".exchange-choice.featured", css)
        self.assertIn(".exchange-source-note", css)
        self.assertIn("white-space: pre-wrap", css)
        self.assertIn("@media (forced-colors: active)", css)
        self.assertNotIn("api.storage.local.set({nodeExchange", panel)
        self.assertNotIn("api.storage.local.set({exchange", panel)
        start_body = panel[panel.index('async function start()'):]
        self.assertNotIn("reviewExchangeInvitation(", start_body)
        self.assertNotIn("/api/v1/exchange-review", start_body)

    def test_later_copy_merge_review_is_three_way_explicit_and_non_defaulting(self) -> None:
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        background = (ROOT / "background.js").read_text()
        css = (ROOT / "sidepanel" / "app.css").read_text()
        for marker in (
            "progrss.shared-folder-merge-review.v1", "Three-way review",
            "Keep mine", "Use curator’s", "Advanced comparison",
            "Changed only in your library", "Apply reviewed choices",
            "acknowledgeRecipeChanges",
        ):
            self.assertIn(marker, panel)
        for marker in (
            "requiresConflictChoices", "SHARED_FOLDER_CONFLICT_DECISION",
            "SHARED_FOLDER_RECIPE_ACKNOWLEDGEMENT", "conflictChoices",
            "acknowledgeRecipeChanges",
        ):
            self.assertIn(marker, background)
        self.assertIn(".merge-conflict", css)
        self.assertIn(".merge-recipe", css)
        self.assertNotIn("checked: true", panel[panel.index("function appendSharedFolderMergeReview"):panel.index("function renderSharedFolder()")])

    def test_permission_request_stays_in_the_gesture_path(self) -> None:
        source = (ROOT / "sidepanel" / "app.js").read_text()
        start = source.index("async function askPermission")
        end = source.index("function renderDiscovery", start)
        body = source[start:end]
        self.assertIn("api.permissions.request", body)
        self.assertNotIn("permissions.contains", body)

    def test_ungranted_site_access_is_contextual_neutral_and_non_mutating(self) -> None:
        source = (ROOT / "sidepanel" / "app.js").read_text()
        css = (ROOT / "sidepanel" / "app.css").read_text()
        self.assertIn("permissionDecisionStatus", source)
        self.assertIn("'decision'", source)
        self.assertIn(".status.decision", css)
        self.assertNotIn("ProgRSS did not get access to that site. Nothing was added.", source)
        for phrase in (
            "The source still needs reconnecting. Nothing changed.",
            "The current source address was kept. No destination was contacted.",
            "The held page result is still waiting for another check. No alert or source change was created.",
            "The watch was not repaired. Its current rule, baseline, and earlier alerts were kept.",
            "The feed preview was not opened. Nothing was followed.",
            "The file was not imported. Add paused remains available without site access.",
        ):
            self.assertIn(phrase, source)
        self.assertIn("!['error', 'decision'].includes(tone)", source)

    def test_workbench_uses_gesture_permission_and_bounded_background_fetch(self) -> None:
        source = (ROOT / "workbench" / "scripts" / "progrss-app.js").read_text()
        grant_start = source.index("async function requestOriginAccess")
        fetch_start = source.index("async function requestRemote", grant_start)
        grant = source[grant_start:fetch_start]
        remote_end = source.index("function cleanHttpCache", fetch_start)
        remote = source[fetch_start:remote_end]
        self.assertIn("api.permissions.request", grant)
        self.assertNotIn("permissions.contains", grant)
        self.assertIn("type:'fetch-resource'", remote)
        self.assertNotIn("permissions.request", remote)

    def test_service_worker_has_no_dom_use(self) -> None:
        source = (ROOT / "background.js").read_text()
        self.assertNotIn("new DOMParser", source)
        self.assertIn("typeof globalThis.DOMParser", source)
        self.assertIn("offscreen.createDocument", source)
        self.assertIn("R.handle(type, data", source)
        self.assertIn("isOwnExtensionInitiator", source)
        self.assertIn("api.runtime.getURL('/')", source)
        self.assertIn("credentials: 'omit'", source)
        self.assertIn("optional", json.dumps(json.loads((ROOT / "manifest.json").read_text())))


    def test_redirects_are_observed_but_not_implicitly_followed_cross_site(self) -> None:
        background = (ROOT / "background.js").read_text()
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        self.assertIn("redirect: 'error'", background)
        self.assertIn("onBeforeRedirect", background)
        self.assertIn("onHeadersReceived", background)
        self.assertIn("CROSS_ORIGIN_REDIRECT", background)
        self.assertIn("MAX_REDIRECTS = 5", background)
        self.assertIn("fetchResource(expectedTo, {})", background)
        self.assertIn("Validators belong to the old origin", background)
        self.assertIn("accept-source-redirect", panel)
        self.assertIn("ProgRSS stopped before contacting that site", panel)
        self.assertIn("askMovePermissions", panel)

    def test_permission_removal_aborts_active_reads_and_becomes_reconnect(self) -> None:
        background = (ROOT / "background.js").read_text()
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        self.assertIn("permissions.onRemoved", background)
        self.assertIn("permission-removed", background)
        self.assertIn("controller.abort()", background)
        self.assertIn("permissionMissing", background)
        self.assertIn("Reconnect this source", panel)
        self.assertIn("Reconnect and check now", panel)

    def test_text_decoding_is_bounded_and_explicit(self) -> None:
        background = (ROOT / "background.js").read_text()
        for marker in ("charsetFromContentType", "charsetFromXmlPrefix", "windows-1252", "utf-16le", "utf-16be", "fatal: true"):
            self.assertIn(marker, background)
        self.assertIn("BODY_TOO_LARGE", background)
        self.assertIn("UNSUPPORTED_ENCODING", background)
        self.assertIn("INVALID_ENCODING", background)

    def test_feed_like_malformed_documents_do_not_become_page_watches(self) -> None:
        parser = (ROOT / "shared" / "parser.js").read_text()
        self.assertIn("feedLikeMime", parser)
        self.assertIn("feedLikeBody", parser)
        self.assertIn(r"<rss\b", parser)
        self.assertNotIn("\x08", parser)
        self.assertIn("if (feedLikeMime || feedLikeBody) throw error", parser)

    def test_reader_has_narrow_large_text_reflow_guards(self) -> None:
        css = (ROOT / "sidepanel" / "app.css").read_text()
        self.assertIn("@media (max-width: 330px)", css)
        self.assertIn("Reflow guard", css)
        self.assertIn("max-width: 100%", css)
        self.assertIn("overflow-wrap: anywhere", css)

    def test_page_watch_alerts_have_bounded_human_change_explanations(self) -> None:
        core = (ROOT / "shared" / "core.js").read_text()
        vault = (ROOT / "shared" / "vault.js").read_text()
        background = (ROOT / "background.js").read_text()
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        css = (ROOT / "sidepanel" / "app.css").read_text()
        for marker in (
            "progrss.page-change.v1", "beforeSnippet", "afterSnippet",
            "entry-added", "entry-changed", "entry-removed", "text-changed",
        ):
            self.assertIn(marker, core)
        self.assertIn("normalizePageChange", vault)
        self.assertIn("invalid page-change explanation", background)
        for phrase in ("See change", "Why ProgRSS noticed this", "Before", "Now", "What this watch notices"):
            self.assertIn(phrase, panel)
        self.assertIn("document.createElement", panel)
        self.assertNotIn("innerHTML", panel)
        self.assertIn(".change-comparison", css)
        self.assertIn(".change-panel del", css)
        self.assertIn(".change-panel ins", css)

    def test_real_acquisition_acceptance_lanes_are_packaged(self) -> None:
        for relative in (
            "tests/acquisition_harness.js",
            "tests/network_acceptance.py",
            "tests/installed_acceptance.py",
            "tests/firefox_manual_acceptance.md",
            "tests/tired_reader_acceptance.md",
        ):
            self.assertTrue((ROOT / relative).is_file(), relative)
        network = (ROOT / "tests" / "network_acceptance.py").read_text()
        self.assertIn("test-only loopback host", network)
        self.assertIn("DestinationHandler.hits == []", network)
        self.assertIn("/link-page", network)
        self.assertIn("/shared-folder", network)
        self.assertIn("directAddress", network)
        self.assertIn("UTF-8 JSON", network)
        self.assertIn("UNSUPPORTED_ENCODING", network)
        self.assertIn("/bom-wins", network)
        tired_reader = (ROOT / "tests" / "tired_reader_acceptance.md").read_text()
        self.assertIn("Sixteen tasks", tired_reader)
        self.assertIn("Someone sent you this direct ProgRSS folder link", tired_reader)
        self.assertIn("Back to address result", tired_reader)
        self.assertIn("This page offers two feeds", tired_reader)
        self.assertIn("This published page offers a source list and recent updates", tired_reader)
        self.assertIn("Review this source list. Without adding it", tired_reader)
        self.assertIn("without granting ProgRSS site access", tired_reader)
        self.assertIn("Back to page options", tired_reader)
        self.assertIn("Do not explain the screen", tired_reader)
        self.assertIn("two visible actions appeared to mean the same thing", tired_reader)
        self.assertIn("automated accessibility-tree check", tired_reader)

    def test_vault_refuses_stale_writes(self) -> None:
        source = (ROOT / "shared" / "vault.js").read_text()
        self.assertIn("'_revision'", source)
        self.assertIn("STALE_VAULT", source)
        self.assertIn("if(current!==base)", source)

    def test_workbench_surfaces_external_changes(self) -> None:
        source = (ROOT / "workbench" / "extension-workbench.js").read_text()
        self.assertIn("progrss:state-changed", source)
        self.assertIn("reload-workbench", source)
        self.assertIn("message?.detail?.instanceId !== instanceId", source)

    def test_workbench_reader_open_preserves_the_user_gesture(self) -> None:
        source = (ROOT / "workbench" / "extension-workbench.js").read_text()
        self.assertIn("api.windows?.WINDOW_ID_CURRENT", source)
        self.assertIn("api.sidePanel.open({windowId: api.windows.WINDOW_ID_CURRENT})", source)
        self.assertIn("api.sidebarAction.open()", source)
        self.assertNotIn("await api.windows.getCurrent", source)


    def test_basic_folders_allow_direct_placement_and_correction_without_hierarchy_editing(self) -> None:
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        html = (ROOT / "sidepanel" / "index.html").read_text()
        background = (ROOT / "background.js").read_text()
        self.assertIn("function folderModel", panel)
        self.assertIn("function selectedFolder", panel)
        self.assertIn("libraryFolder", panel)
        self.assertIn("All folders", panel)
        self.assertIn("mode !== 'union'", panel)
        self.assertIn("Add to folder", panel)
        self.assertIn("Parent folders include it automatically", panel)
        self.assertIn("add-source-to-folder", panel)
        self.assertIn("remove-source-from-folder", panel)
        self.assertIn("undo-source-folder-add", panel)
        self.assertIn("undo-source-folder-remove", panel)
        self.assertIn("Remove from folder", panel)
        self.assertIn("Only the selected direct placement is removed", panel)
        self.assertIn("STALE_FOLDER_UNDO", background)
        self.assertNotIn("Create folder", html)
        self.assertNotIn("Rename folder", html)
        self.assertNotIn("Delete folder", html)

    def test_source_note_authoring_is_placement_scoped_local_and_stale_safe(self) -> None:
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        html = (ROOT / "sidepanel" / "index.html").read_text()
        css = (ROOT / "sidepanel" / "app.css").read_text()
        background = (ROOT / "background.js").read_text()
        manifest = json.loads((ROOT / "manifest.json").read_text())
        self.assertIn("sourceNotePlacementKey", panel)
        self.assertIn("sourceNoteCodePointCount", panel)
        self.assertIn("set-source-placement-reason", panel)
        self.assertIn("undo-source-placement-reason", panel)
        self.assertIn("expectedVersion: editor.expectedVersion", panel)
        self.assertIn("expectedReason: editor.baseReason", panel)
        self.assertIn("publishes nothing, contacts nobody, creates no schedule", panel)
        self.assertIn("not a ProgRSS safety claim", panel)
        self.assertIn("280 Unicode characters", panel)
        self.assertIn("data-source-note-editor-key", panel)
        self.assertIn("aria-invalid", panel)
        self.assertIn("event.key === 'Escape'", panel)
        self.assertIn("source-note-undo", html)
        self.assertIn("undo-source-note", html)
        self.assertIn("source-note-placement", css)
        self.assertIn(".source-note-editor-actions button { min-height: 44px; }", css)
        self.assertIn("@media (forced-colors: active)", css)
        self.assertIn("@media (prefers-reduced-motion: reduce)", css)
        self.assertIn("async function setSourcePlacementReason", background)
        self.assertIn("async function undoSourcePlacementReason", background)
        self.assertIn("STALE_SOURCE_NOTE", background)
        self.assertIn("STALE_SOURCE_NOTE_UNDO", background)
        self.assertIn("INVALID_SOURCE_NOTE", background)
        self.assertIn("delete placement.reason", background)
        self.assertNotIn("notifications", manifest.get("permissions", []))
        self.assertEqual(manifest.get("host_permissions", []), [])
        self.assertEqual(manifest.get("optional_host_permissions"), ["http://*/*", "https://*/*"])

    def test_source_note_installed_runtime_lane_is_real_view_fail_closed_evidence(self) -> None:
        runtime = (ROOT / "tests" / "source_notes_installed_acceptance.py").read_text()
        self.assertIn("Extensions.loadUnpacked", runtime)
        self.assertIn("open two real extension views", runtime)
        self.assertIn("page_a", runtime)
        self.assertIn("page_b", runtime)
        self.assertIn("undo-source-placement-reason", runtime)
        self.assertIn("STALE_SOURCE_NOTE_UNDO", runtime)
        self.assertIn("archiveMatchesExtractedExtension", runtime)
        self.assertIn("managed-exact-archive-runtime-preflight", runtime)
        self.assertIn('"unmanagedBrowserAcceptance": False', runtime)
        self.assertIn('"currentStableAcceptance": False', runtime)
        self.assertIn('"humanPermissionPromptObservation": False', runtime)
        self.assertNotIn("test-source-note-", runtime)

    def test_parser_supports_namespaces_xml_base_rss1_and_guid_links(self) -> None:
        core = (ROOT / "shared" / "core.js").read_text()
        self.assertIn("function namedChildren", core)
        self.assertIn("namespaceURI", core)
        self.assertIn("function xmlBase", core)
        self.assertIn("XML/1998/namespace", core)
        self.assertIn("getChild(doc,'channel')||doc", core)
        self.assertIn("isPermaLink", core)
        self.assertIn("if(!link&&permalink)", core)
        self.assertIn("feedUrl", core)
        self.assertIn("http://www.w3.org/2005/Atom", core)

    def test_feed_identity_is_same_origin_and_duplicate_aware(self) -> None:
        background = (ROOT / "background.js").read_text()
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        self.assertIn("function sameOriginFeedUrl", background)
        self.assertIn("function sourceAddressAliases", background)
        self.assertIn("declared-self", background)
        self.assertIn("alreadyFollowing", background)
        self.assertIn("ProgRSS will not add a duplicate", panel)

    def test_reader_search_and_scoped_read_are_local_state_actions(self) -> None:
        source = (ROOT / "sidepanel" / "app.js").read_text()
        self.assertIn("Search titles, sources, and feed text", (ROOT / "sidepanel" / "index.html").read_text())
        self.assertIn("function matchingItems", source)
        self.assertIn("source.title", source)
        self.assertIn("mark-items-read", source)
        self.assertIn("event.key === '/'", source)
        self.assertIn("event.key === 'Escape'", source)

    def test_focused_reading_is_bounded_plain_text_and_keyboard_reversible(self) -> None:
        core = (ROOT / "shared" / "core.js").read_text()
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        html = (ROOT / "sidepanel" / "index.html").read_text()
        css = (ROOT / "sidepanel" / "app.css").read_text()
        vault = (ROOT / "shared" / "vault.js").read_text()
        self.assertIn("body: 12_000", core)
        self.assertIn("function atomContentText", core)
        self.assertIn("staticHtml(raw)", core)
        self.assertIn("img','picture','source','track','link','embed','base", core)
        self.assertIn("contentEl", core)
        self.assertIn("encodedEl", core)
        self.assertIn("bodyIsSummary", core)
        self.assertIn("item.body || ''", panel)
        self.assertIn("els.detailBody.replaceChildren()", panel)
        self.assertIn("markNaturalText", panel)
        self.assertIn("node.dir = 'auto'", panel)
        self.assertIn("slice(0, 12_000)", panel)
        self.assertIn("openItemDetail", panel)
        self.assertIn("closeItemDetail", panel)
        self.assertIn("event.key === 'j' || event.key === 'k'", panel)
        self.assertIn("reading-detail", panel)
        self.assertIn('id="view-detail"', html)
        self.assertIn(".reading-detail .bottom-nav", css)
        self.assertIn("max-width: 68ch", css)
        self.assertIn("white-space: pre-wrap", css)
        self.assertIn("item.body=item.body.slice(0,12000)", vault)
        self.assertNotIn("innerHTML", panel)

    def test_storage_write_failure_preserves_last_commit_and_offers_bounded_recovery(self) -> None:
        manifest = json.loads((ROOT / "manifest.json").read_text())
        background = (ROOT / "background.js").read_text()
        vault = (ROOT / "shared" / "vault.js").read_text()
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        html = (ROOT / "sidepanel" / "index.html").read_text()
        workbench = (ROOT / "workbench" / "scripts" / "progrss-app.js").read_text()
        self.assertNotIn("unlimitedStorage", manifest.get("permissions", []))
        self.assertNotIn("navigator.storage.persist", vault)
        self.assertNotIn("requestPersistence", vault)
        for marker in ("VAULT_WRITE_FAILED", "storageReason", "idbProbe", "function probe"):
            self.assertIn(marker, vault)
        for marker in ("progrss.storage.incident.v1", "probe-vault-write", "recovery-copy", "The attempted change was not saved"):
            self.assertIn(marker, background)
        self.assertIn("report-storage-write-failure", workbench)
        self.assertIn("Your last saved library remains available", workbench)
        self.assertIn('id="storage-incident"', html)
        self.assertIn('id="save-recovery-copy"', html)
        self.assertIn('id="check-storage"', html)
        self.assertIn("A small test write succeeded", panel)
        self.assertIn("does not delete unread or saved material automatically", html)

    def test_missing_library_is_not_mistaken_for_a_fresh_installation(self) -> None:
        manifest = json.loads((ROOT / "manifest.json").read_text())
        background = (ROOT / "background.js").read_text()
        vault = (ROOT / "shared" / "vault.js").read_text()
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        html = (ROOT / "sidepanel" / "index.html").read_text()
        workbench = (ROOT / "workbench" / "scripts" / "progrss-app.js").read_text()
        self.assertNotIn("unlimitedStorage", manifest.get("permissions", []))
        self.assertNotIn("navigator.storage.persist", background)
        for marker in (
            "progrss.library.presence.v1", "progrss.library.recovery.v1",
            "LIBRARY_RECOVERY_REQUIRED", "accept-empty-library",
            "assert-workbench-writable", "note-workbench-commit",
        ):
            self.assertIn(marker, background)
        self.assertIn("api.storage?.local?.get", background)
        self.assertIn("api.runtime.onInstalled.addListener(async details", background)
        self.assertIn("lastKnown: cleanLibrarySummary", background)
        self.assertIn("openedWithoutRecord", vault)
        self.assertIn("initialRecordExists", vault)
        self.assertIn('id="library-recovery"', html)
        self.assertIn('id="restore-missing-library"', html)
        self.assertIn('id="accept-empty-library"', html)
        soup = BeautifulSoup(html, "html.parser")
        self.assertIsNone(soup.select_one("#library-recovery[aria-live]"))
        self.assertIn("Your local library appears missing", panel)
        self.assertIn("ProgRSS cannot reconstruct cleared reading history", html)
        self.assertIn("Restore private file", html)
        self.assertIn("Use empty library", html)
        self.assertIn("assert-workbench-writable", workbench)
        self.assertIn("LIBRARY_RECOVERY_REQUIRED", workbench)

    def test_private_copy_reminder_is_quiet_controllable_and_outside_vault(self) -> None:
        manifest = json.loads((ROOT / "manifest.json").read_text())
        background = (ROOT / "background.js").read_text()
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        html = (ROOT / "sidepanel" / "index.html").read_text()
        css = (ROOT / "sidepanel" / "app.css").read_text()
        self.assertNotIn("notifications", manifest.get("permissions", []))
        for marker in (
            "progrss.backup-reminder.v3",
            "progrss.backup-reminder.v2",
            "progrss.backup-reminder.v1",
            "progrss.private-copy-check.v2",
            "BACKUP_FIRST_DELAY_MS = 7 * 24 * 60 * 60 * 1000",
            "BACKUP_REPEAT_MS = 30 * 24 * 60 * 60 * 1000",
            "BACKUP_RECHECK_MS = 90 * 24 * 60 * 60 * 1000",
            "portableBackupFingerprint",
            "lastPreparedFingerprint",
            "lastCheckedFingerprint",
            "mark-backup-copy-missing",
            "check-private-backup",
            "snooze-backup-reminder",
            "disable-backup-reminder",
            "enable-backup-reminder",
            "writesVault: false",
        ):
            self.assertIn(marker, background)
        self.assertIn("api.storage?.local?.set", background)
        for marker in (
            'id="private-copy"',
            'id="private-copy-options"',
            'id="library-care-heading"',
            'id="save-private-copy"',
            'id="check-private-copy"',
            'id="copy-check-file"',
            'id="copy-check-result"',
            'id="snooze-backup-reminder"',
            'id="disable-backup-reminder"',
            'id="enable-backup-reminder"',
            'id="mark-backup-copy-missing"',
        ):
            self.assertIn(marker, html)
        self.assertEqual(html.count('id="save-private-copy"'), 1)
        self.assertEqual(html.count('id="check-private-copy"'), 1)
        self.assertNotIn('id="backup-reminder"', html)
        self.assertNotIn('id="library-safety"', html)
        self.assertNotIn('id="save-private-copy-manual"', html)
        soup = BeautifulSoup(html, "html.parser")
        self.assertIsNone(soup.select_one("#private-copy[aria-live]"))
        source_list = soup.select_one("#source-list")
        library_care = soup.select_one(".library-care")
        self.assertIsNotNone(source_list)
        self.assertIsNotNone(library_care)
        self.assertLess(list(source_list.parent.children).index(source_list), list(source_list.parent.children).index(library_care))
        self.assertIn("Keep a copy outside this browser", html)
        self.assertIn("Reminder and copy options", html)
        self.assertIn("Remind me in 30 days", html)
        self.assertIn("Don’t remind me again", html)
        self.assertIn("Keep the file private", html)
        self.assertIn("renderBackupReminder", panel)
        self.assertIn("sourceAttentionRank", panel)
        self.assertIn("if (source.pendingRedirect) return 0", panel)
        self.assertIn("if (source.permissionMissing && source.enabled) return 1", panel)
        self.assertIn("sourceNeedsAttention", panel)
        self.assertIn("Needs your attention", panel)
        self.assertIn("Private-copy reminders are off", panel)
        self.assertIn("This older checked copy still opens", panel)
        self.assertIn("The recorded checked copy is now marked missing", panel)
        self.assertIn('data-state="previous"', css)
        self.assertIn("downloads can be cancelled or fail", panel)
        self.assertIn("This saved copy matches", panel)
        self.assertIn("This is a different valid copy", panel)
        self.assertIn("file.text()", panel)
        self.assertIn(".private-copy-actions", css)
        self.assertIn(".private-copy-options", css)
        self.assertIn(".source-group", css)
        self.assertIn(".copy-check-result", css)

    def test_offline_text_storage_is_visible_per_source_and_cleanup_is_narrow(self) -> None:
        manifest = json.loads((ROOT / "manifest.json").read_text())
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        html = (ROOT / "sidepanel" / "index.html").read_text()
        css = (ROOT / "sidepanel" / "app.css").read_text()
        background = (ROOT / "background.js").read_text()
        core = (ROOT / "shared" / "core.js").read_text()
        vault = (ROOT / "shared" / "vault.js").read_text()
        self.assertNotIn("unlimitedStorage", manifest.get("permissions", []))
        for marker in ('id="storage-overview"', 'id="storage-text-summary"', 'id="text-cleanup-undo"'):
            self.assertIn(marker, html)
        self.assertIn("navigator.storage?.estimate", panel)
        self.assertIn("Keep full feed text", panel)
        self.assertIn("Keep summaries only", panel)
        self.assertIn("readAt && !item.starred", panel)
        self.assertIn("MAX_TEXT_CLEANUP_BYTES = 1_500_000", panel)
        self.assertIn("MAX_TEXT_CLEANUP_ITEMS = 240", panel)
        for marker in ("set-source-text-retention", "prune-source-text", "undo-source-text-prune"):
            self.assertIn(marker, panel)
            self.assertIn(marker, background)
        self.assertIn("item.readAt && !item.starred", background)
        self.assertIn("STALE_TEXT_CLEANUP_UNDO", background)
        self.assertIn("bodyOmitted", core)
        self.assertIn("bodyOmitted", vault)
        self.assertIn("textRetention", vault)
        self.assertIn("version:17", vault)
        self.assertIn("Offline reading", html)
        self.assertIn("article pages, images, scripts, or frames", html)
        self.assertIn(".source-text-retention", css)
        self.assertIn(".text-cleanup-undo", css)

    def test_feed_declared_language_is_preserved_and_rendered_without_guessing(self) -> None:
        core = (ROOT / "shared" / "core.js").read_text()
        parser = (ROOT / "shared" / "parser.js").read_text()
        background = (ROOT / "background.js").read_text()
        vault = (ROOT / "shared" / "vault.js").read_text()
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        self.assertIn("function languageTag", core)
        self.assertIn("function xmlLanguage", core)
        self.assertIn("doc.language", core)
        self.assertIn("childText(channel,'language')", core)
        for marker in ("titleLanguage", "summaryLanguage", "bodyLanguage"):
            self.assertIn(marker, core)
            self.assertIn(marker, vault)
        self.assertIn("language: feed.language", parser)
        self.assertIn("C.languageTag(parsed.language)", background)
        self.assertIn("version:17", vault)
        self.assertIn("markNaturalText", panel)
        self.assertIn("node.lang = clean", panel)
        self.assertIn("node.dir = 'auto'", panel)
        self.assertIn(r"body.split(/\n{2,}/)", panel)
        self.assertNotIn("innerHTML", panel)

    def test_direct_shared_folder_address_reuses_the_review_boundary(self) -> None:
        background = (ROOT / "background.js").read_text()
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        html = (ROOT / "sidepanel" / "index.html").read_text()
        self.assertIn("previewSharedFolder(rawBody)", background)
        self.assertIn("kind: 'shared-folder'", background)
        self.assertIn("directAddress: true", background)
        self.assertIn("ProgRSS shared folders must be UTF-8 JSON", background)
        self.assertIn("application/vnd.progrss.shared-folder+json", background)
        self.assertIn("discovery.kind === 'shared-folder'", panel)
        self.assertIn("Source list found", panel)
        self.assertIn("Review source list", panel)
        self.assertIn("Back to address result", panel)
        self.assertIn("Website, feed, source-list, or ProgRSS handoff address", html)
        self.assertNotIn("application/json links are shared folders", panel.lower())

    def test_feed_candidates_preview_before_follow_without_remote_article_content(self) -> None:
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        parser = (ROOT / "shared" / "parser.js").read_text()
        css = (ROOT / "sidepanel" / "app.css").read_text()
        self.assertIn("async function previewCandidate", panel)
        self.assertIn("Preview ${text(candidate.title", panel)
        self.assertIn("Nothing has been followed yet", panel)
        self.assertIn("A few items from this feed", panel)
        self.assertIn("Back to page options", panel)
        self.assertIn("feed-preview-heading", panel)
        preview_start = panel.index("async function previewCandidate")
        preview_end = panel.index("async function continueRedirect", preview_start)
        self.assertNotIn("addChosen(", panel[preview_start:preview_end])
        self.assertIn("previewItems", parser)
        self.assertIn("previewFullTextCount", parser)
        self.assertIn("function feedPreview", parser)
        self.assertIn(".feed-preview-items", css)
        self.assertIn(".feed-preview-actions", css)

    def test_publication_discovery_names_the_two_different_choices(self) -> None:
        core = (ROOT / "shared" / "core.js").read_text()
        scout = (ROOT / "shared" / "scout.js").read_text()
        parser = (ROOT / "shared" / "parser.js").read_text()
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        site = (ROOT / "shared" / "publication-site.js").read_text()
        self.assertIn("function folderEditionInfo", core)
        self.assertIn("edition: feed.edition || null", parser)
        self.assertIn("function publicationChoices", scout)
        self.assertIn("progrss.publication-choices.v1", scout)
        for phrase in (
            "Choose what you want",
            "Add the source list",
            "Review source list",
            "Follow recent updates",
            "Preview recent updates",
            "does not add the underlying feeds or watched pages",
        ):
            self.assertIn(phrase, panel)
        self.assertIn("source list for ProgRSS", site)
        self.assertIn("Follow recent updates", site)
        self.assertIn("Following it does not add the source list", site)
        self.assertIn("Curator’s reason for this folder:", site)
        self.assertIn("not a ProgRSS safety claim", site)
        self.assertIn("sourceNotes", site)
        self.assertIn("white-space:pre-wrap", site)

    def test_opml_is_bounded_reviewed_and_revalidated(self) -> None:
        core = (ROOT / "shared" / "core.js").read_text()
        background = (ROOT / "background.js").read_text()
        parser = (ROOT / "shared" / "parser.js").read_text()
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        self.assertIn("parseOPMLDetailed", core)
        self.assertRegex(core, r"DOCTYPE\|<!ENTITY")
        self.assertIn("parse-opml", parser)
        self.assertIn("preview-opml", background)
        self.assertIn("import-opml", background)
        self.assertIn("planOpml(parsed, state)", background)
        self.assertIn("MAX_OPML_BYTES = 2_000_000", panel)
        self.assertIn("Add paused", panel)
        self.assertIn("askImportPermissions", panel)

    def test_bulk_permission_request_stays_in_import_button_gesture(self) -> None:
        source = (ROOT / "sidepanel" / "app.js").read_text()
        grant_start = source.index("async function askImportPermissions")
        grant_end = source.index("function renderDiscovery", grant_start)
        grant = source[grant_start:grant_end]
        self.assertIn("api.permissions.request", grant)
        self.assertNotIn("permissions.contains", grant)
        import_start = source.index("async function importReviewedOpml")
        import_end = source.index("function keyboard", import_start)
        importer = source[import_start:import_end]
        self.assertLess(importer.index("askImportPermissions"), importer.index("request('import-opml'"))

    def test_following_ends_with_a_clear_reader_handoff(self) -> None:
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        html = (ROOT / "sidepanel" / "index.html").read_text()
        self.assertIn("Your first source is ready", panel)
        self.assertIn("Nothing new was available on the first check", panel)
        self.assertIn("Source details", html)
        self.assertIn("showFollowedSource", panel)

    def test_source_activity_has_human_landmarks(self) -> None:
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        background = (ROOT / "background.js").read_text()
        for label in ("Successful check", "New update", "Last problem"):
            self.assertIn(label, panel)
        for field in ("lastSuccessfulAt", "lastNewAt", "lastProblemAt", "lastProblem"):
            self.assertIn(field, background)

    def test_everyday_targets_and_focus_are_explicit(self) -> None:
        css = (ROOT / "sidepanel" / "app.css").read_text()
        self.assertIn("min-width: 44px", css)
        self.assertIn("min-height: 44px", css)
        self.assertIn(":focus-visible", css)
        self.assertIn("prefers-reduced-motion", css)
        self.assertIn("forced-colors: active", css)

    def test_private_backups_do_not_export_storage_revision_or_bypass_reader_review(self) -> None:
        source = (ROOT / "workbench" / "scripts" / "progrss-app.js").read_text()
        self.assertIn("delete portableState._revision", source)
        self.assertIn("delete portableState.transferUndo", source)
        self.assertIn("delete portableState.sourceRepairUndo", source)
        self.assertIn("delete portableState.receiptRetirementUndo", source)
        self.assertIn("delete portable.watchStability", source)
        self.assertIn("Whole-library moves use the everyday reader", source)
        self.assertNotIn("validated._revision=currentRevision", source)

    def test_same_source_repair_is_reviewed_bounded_and_reversible(self) -> None:
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        html = (ROOT / "sidepanel" / "index.html").read_text()
        background = (ROOT / "background.js").read_text()
        vault = (ROOT / "shared" / "vault.js").read_text()
        css = (ROOT / "sidepanel" / "app.css").read_text()
        for marker in ("preview-source-repair", "repair-same-source", "undo-source-repair"):
            self.assertIn(marker, panel)
            self.assertIn(marker, background)
        for phrase in (
            "Compare both histories", "Which source should remain?", "Combine as one source",
            "Keep both sources", "I reviewed which source will remain.",
        ):
            self.assertIn(phrase, panel)
        self.assertIn('id="source-repair-review"', html)
        self.assertIn("SOURCE_REPAIR_UNDO_MS = 30 * 60 * 1000", background)
        self.assertIn("SOURCE_REPAIR_STALE", background)
        self.assertIn("SOURCE_REPAIR_UNDO_STALE", background)
        self.assertIn("exactStringReferenceDetails", background)
        self.assertIn("sourceReferenceReport", background)
        self.assertIn("sourceRepairBlockers", background)
        self.assertIn("retainedUpdateReferences", background)
        self.assertIn("delete result.sourceRepairUndo", background)
        self.assertIn("sourceRepairUndo", vault)
        self.assertIn("version:17", vault)
        self.assertIn(".repair-source-choice", css)
        self.assertIn(".source-repair-review", css)
        self.assertNotIn("Deduplicate all", panel)
        workbench_html = (ROOT / "workbench" / "index.html").read_text()
        workbench_js = (ROOT / "workbench" / "extension-workbench.js").read_text()
        workbench_css = (ROOT / "workbench" / "extension-workbench.css").read_text()
        self.assertIn("See references in Advanced Workbench", panel)
        self.assertIn("source-repair-references", background)
        self.assertIn('id="source-reference-report"', workbench_html)
        self.assertIn("References to these histories", workbench_html)
        self.assertIn("ProgRSSOpenSourceReferenceReport", workbench_js)
        self.assertIn("Review retirement", workbench_js)
        self.assertIn(".source-reference-record", workbench_css)

    def test_exact_graft_receipt_retirement_preserves_evidence_and_keeps_other_schemas_blocked(self) -> None:
        background = (ROOT / "background.js").read_text()
        vault = (ROOT / "shared" / "vault.js").read_text()
        workbench = (ROOT / "workbench" / "extension-workbench.js").read_text()
        css = (ROOT / "workbench" / "extension-workbench.css").read_text()
        for marker in (
            "preview-graft-receipt-retirement", "retire-graft-receipt",
            "undo-graft-receipt-retirement",
        ):
            self.assertIn(marker, background)
            self.assertIn(marker, workbench)
        self.assertIn("progrss.recipe.graft.receipt.v1", background)
        self.assertIn("progrss.retired.graft-receipt.v1", background)
        self.assertIn("invalid Unicode and cannot receive a portable digest", background)
        self.assertIn("canonicalDigest", background)
        self.assertIn("RECEIPT_REVIEW_STALE", background)
        self.assertIn("RECEIPT_UNDO_STALE", background)
        self.assertIn("Only progrss.recipe.graft.receipt.v1", background)
        self.assertIn("receiptRetirementUndo", vault)
        self.assertIn("retiredReceipts", vault)
        self.assertIn("version:17", vault)
        self.assertIn("Retire receipt", workbench)
        self.assertIn("preserved as retired evidence", workbench)
        self.assertIn(".receipt-retirement-review", css)
        self.assertIn(".retired-evidence", css)

    def test_page_watch_repair_is_selector_free_guarded_and_reversible(self) -> None:
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        html = (ROOT / "sidepanel" / "index.html").read_text()
        css = (ROOT / "sidepanel" / "app.css").read_text()
        background = (ROOT / "background.js").read_text()
        core = (ROOT / "shared" / "core.js").read_text()
        parser = (ROOT / "shared" / "parser.js").read_text()
        vault = (ROOT / "shared" / "vault.js").read_text()
        manifest = json.loads((ROOT / "manifest.json").read_text())
        for code in (
            "PAGE_SELECTOR_INVALID", "PAGE_SELECTOR_NO_MATCH",
            "PAGE_WATCH_STRUCTURE_CHANGED", "PAGE_WATCH_REPAIR_STALE",
            "PAGE_WATCH_REPAIR_UNDO_STALE",
        ):
            self.assertIn(code, core + background)
        for marker in (
            "pageWatchRepairProposals", "pageWatchCaptureHealth",
            "preview-page-watch-repair", "repair-page-watch",
            "undo-page-watch-repair",
        ):
            self.assertIn(marker, core + parser + background + panel)
        for phrase in (
            "Repair watch", "Find what to watch now", "Choose what to watch now",
            "Use this section", "Keep current watch", "Watch health",
            "Undo watch repair", "fresh baseline", "Earlier alerts",
        ):
            self.assertIn(phrase, panel + html)
        self.assertIn("PAGE_WATCH_REPAIR_UNDO_MS = 30 * 60 * 1000", background)
        self.assertIn("source.watchRepair", background)
        self.assertIn("delete state.snapshots[source.id]", background)
        self.assertIn("C.ingestPage(state,source,chosen.capture)", background)
        self.assertIn("pageWatchRepairUndo", vault)
        self.assertIn('id="page-watch-repair-undo"', html)
        self.assertIn('id="undo-page-watch-repair"', html)
        self.assertIn(".watch-repair-choice", css)
        self.assertIn(".watch-repair-actions", css)
        self.assertNotIn("unlimitedStorage", manifest.get("permissions", []))
        self.assertEqual(manifest.get("optional_host_permissions"), ["http://*/*", "https://*/*"])

    def test_page_watch_shape_changes_are_confirmed_before_alerting(self) -> None:
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        css = (ROOT / "sidepanel" / "app.css").read_text()
        background = (ROOT / "background.js").read_text()
        core = (ROOT / "shared" / "core.js").read_text()
        vault = (ROOT / "shared" / "vault.js").read_text()
        for marker in (
            "progrss.page-watch.stability.v1", "pageWatchStabilityDecision",
            "confirmed-shape-change", "returned-to-steady", "unstable-shape",
            "PAGE_WATCH_UNSTABLE", "watch-pending",
        ):
            self.assertIn(marker, core + background + vault)
        for phrase in (
            "Checking again", "ProgRSS is checking one unusual result",
            "No page-change alert was created", "Check again",
        ):
            self.assertIn(phrase, panel)
        self.assertIn("delete portable.watchStability", background)
        self.assertIn(".watch-stability-decision", css)
        self.assertNotIn("source.watchStability) return 2", panel)

    def test_browser_assisted_capture_is_bounded_reviewed_and_node_zero_network(self) -> None:
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        css = (ROOT / "sidepanel" / "app.css").read_text()
        background = (ROOT / "background.js").read_text()
        manifest = json.loads((ROOT / "manifest.json").read_text())
        capture = (ROOT / "shared" / "capture.js").read_text()
        for marker in (
            "progrss.node.capture.v1", "progrss.browser-capture.v4",
            "progrss.browser-capture-candidates.v3",
            "progrss.capture-section-assessment.v1",
            "capture-rendered-page-once", "one-expiring-rendered-page-capture",
            "Capture this open page", "What part of this page counts as an update?",
            "Use this new watched section", "zero Node site requests",
            "Why this may hold", "What could break", "not a promise",
            "progrss.capture-page-context.v1",
            "progrss.capture-coverage-review.v1",
            "What this browser view may leave outside",
            "Advanced page-boundary evidence",
            "Before this becomes the baseline",
            "Use this rendered view as the baseline",
            "Use this view and send once",
        ):
            self.assertIn(marker, panel + background + capture)
        for marker in (
            "api.scripting.executeScript", "frameIds: [0]",
            "rendered-browser-dom", "topFrameOnly: true",
            "isolatedWorld: true", "arbitrarySharedCode: false",
            "CAPTURE_PAGE_MISMATCH", "ProgRSSCapture",
        ):
            self.assertIn(marker, background + capture)
        for marker in (
            "semanticBoundary", "uniqueMatch", "hiddenMatches",
            "consistentEntries", "selectorLooksVolatile", "perimeter-v1",
            "continuationLinks", "partialSetSignals", "virtualMarkers",
            "modalLayers", "embeddedFrames", "openShadowRoots", "busyRegions",
        ):
            self.assertIn(marker, capture)
        self.assertNotIn("probability", capture.lower())
        self.assertNotIn("confidence score", panel.lower())
        for phrase in (
            "Node receives no cookie, credential, storage, raw HTML, form value, or screenshot",
            "Only the selected bounded text and links are sent",
            "Site scripts, cookies, storage, form values, raw markup, and screenshots are excluded",
        ):
            self.assertIn(phrase, panel)
        self.assertIn("MAX_CAPTURE_ARTIFACT_BYTES = 300_000", panel)
        self.assertIn("releaseCapturePermissions", panel)
        self.assertIn("requestCapturePagePermission", panel)
        self.assertIn(".capture-boundaries", css)
        self.assertIn(".capture-choice", css)
        self.assertIn(".capture-assessment", css)
        self.assertIn(".capture-stability-badge", css)
        self.assertIn(".capture-coverage-review", css)
        self.assertIn(".capture-coverage-decision", css)
        self.assertIn("Later comparison stays conservative", panel)
        self.assertIn("Rendered window held", panel)
        self.assertIn("Rendered-window comparison", panel)
        self.assertIn(".capture-drift-note", css)
        self.assertIn(".capture-result-note", css)
        self.assertIn("activeTab", manifest.get("permissions", []))
        self.assertIn("scripting", manifest.get("permissions", []))
        self.assertEqual(manifest.get("optional_host_permissions"), ["http://*/*", "https://*/*"])
        self.assertNotIn("cookies", manifest.get("permissions", []))
        self.assertNotIn("webNavigation", manifest.get("permissions", []))

    def test_perimeter_fixture_garden_is_retained(self) -> None:
        garden = ROOT / "tests" / "fixtures" / "capture-garden"
        expected = {
            "semantic-hidden.html", "pagination.html", "virtualized.html", "virtualized-shifted.html",
            "duplicate-layouts.html", "mixed-ads.html", "rtl-pagination.html", "closed-shadow.html",
            "overlay.html", "frames-shadow.html", "busy.html", "rtl.html", "garden.html",
        }
        self.assertEqual({path.name for path in garden.glob("*.html")}, expected)
        smoke = (ROOT / "tests" / "capture_quality_smoke.py").read_text()
        for phrase in (
            "progrss.browser-capture-candidates.v3",
            "progrss.capture-page-context.v1",
            "perimeter-v1",
            "pageBoundaryKinds",
            "virtualWindowsDisjoint",
            "closedShadowExcluded",
        ):
            self.assertIn(phrase, smoke)

    def test_private_library_move_is_reviewed_local_and_reversible(self) -> None:
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        background = (ROOT / "background.js").read_text()
        vault = (ROOT / "shared" / "vault.js").read_text()
        for marker in (
            "export-private-backup", "preview-private-backup", "restore-private-backup",
            "undo-private-backup-restore",
        ):
            self.assertIn(marker, panel)
            self.assertIn(marker, background)
        self.assertIn("TRANSFER_UNDO_MS = 30 * 60 * 1000", background)
        self.assertIn("delete result.transferUndo", background)
        self.assertIn("permissionMissingReason = 'transfer'", background)
        self.assertIn("currentOriginPatterns", background)
        self.assertIn("TRANSFER_REVIEW_STALE", background)
        self.assertIn("reviewedRevision: transfer.preview.reviewedRevision", panel)
        self.assertIn("transferUndo", vault)
        self.assertIn("version:17", vault)
        self.assertNotIn("downloads.download", panel)

    def test_private_transfer_validates_and_discloses_source_notes(self) -> None:
        panel = (ROOT / "sidepanel" / "app.js").read_text()
        background = (ROOT / "background.js").read_text()
        core = (ROOT / "shared" / "core.js").read_text()
        workbench = (ROOT / "workbench" / "scripts" / "progrss-app.js").read_text()
        runner = (ROOT / "tests" / "run.sh").read_text()
        for marker in (
            "function privateSourceNoteAudit",
            "return C.auditSourceNotes(state, knownSourceIds)",
            "INVALID_SOURCE_NOTE_STATE",
            "sourceNotes",
        ):
            self.assertIn(marker, background)
        for marker in (
            "function auditSourceNotes",
            "normalizeSourceNoteReason(member.reason)",
            "noncanonical Source Note",
            "reason-bearing direct relationship must appear exactly once",
        ):
            self.assertIn(marker, core)
        self.assertIn("C.auditSourceNotes(portableState)", workbench)
        self.assertIn("curator-written folder reasons", panel)
        self.assertIn("curator reasons", panel)
        self.assertIn("source_notes_private_transfer_harness.js", runner)
        self.assertIn("source_notes_workbench_private_backup_harness.py", runner)
        self.assertNotIn("fetch(", background[background.index("function privateSourceNoteAudit"):background.index("function transferSummary")])


def test_relay_everyday_share_and_watch_surface():
    import json
    from pathlib import Path
    extension = Path(__file__).resolve().parents[1]
    html = (extension / "sidepanel" / "index.html").read_text(encoding="utf-8")
    app = (extension / "sidepanel" / "app.js").read_text(encoding="utf-8")
    background = (extension / "background.js").read_text(encoding="utf-8")
    core = (extension / "shared" / "core.js").read_text(encoding="utf-8")
    shared = (extension / "shared" / "shared-folder.js").read_text(encoding="utf-8")
    publication_site = (extension / "shared" / "publication-site.js").read_text(encoding="utf-8")
    vault = (extension / "shared" / "vault.js").read_text(encoding="utf-8")
    manifest = json.loads((extension / "manifest.json").read_text(encoding="utf-8"))
    for marker in ("share-folder-button", "check-shared-folder-update", "share-folder-review", "shared-folder-file", "shared-folder-preview", "share-curator", "share-note", "share-update-url", "share-sign", "create-share-identity", "share-publication-site", "save-publication-site", "site-include-updates", "share-edition", "save-folder-edition"):
        assert f'id="{marker}"' in html
    for message in ("get-sharing-identity", "create-sharing-identity", "export-shared-folder", "export-publication-site", "export-folder-edition", "preview-shared-folder", "review-shared-folder-url", "import-shared-folder", "check-shared-folder-update", "update-shared-folder", "undo-shared-folder-update"):
        assert f"case '{message}':" in background
    assert "enabled: false" in background
    assert "network: false" in background and "writes: false" in background
    assert "Watch new and changed entries" in app
    assert "The first check saves a starting point" in app
    assert "root:chosen" in core and "title:text(selected.title" in core
    assert "progrss.bundle.v3" in shared and "progrss.bundle.v2" in shared and "progrss.bundle.v1" in shared
    assert "progrss.shared-folder.distribution.v1" in shared
    assert "progrss.shared-folder.origin.v3" in shared
    assert "ProgRSS/shared-folder-content/v1" in shared
    assert "ProgRSS/shared-folder-signature/v1" in shared
    assert "ProgRSS/shared-folder-content/v2" in shared
    assert "ProgRSS/shared-folder-signature/v2" in shared
    assert "Ed25519" in shared and "ECDSA-P256-SHA256" in shared
    assert "privateKey.extractable" in shared
    assert "sharedFolderOrigin" in vault
    assert "progrss.shared-folder.origin.v2" in shared
    assert "progrss.shared-folder.baseline.v1" in shared
    assert "progrss.shared-folder.contents.v2" in shared
    assert "function contents(" in shared
    assert "function branch(" in shared
    assert "appendSharedFolderContents" in app
    assert "Add just one folder section (optional)" in app
    assert "independent local folder" in app
    assert "selectedFolderId" in background
    assert "ProgRSS has not contacted any listed site" in app
    assert "open: sourceCount <= 6 && folderCount <= 4" in app
    assert "Removed from this source list · local history kept" in app
    assert "sharedFolderUpdateContents" in background
    assert ".shared-folder-contents" in (extension / "sidepanel" / "app.css").read_text(encoding="utf-8")
    assert "sharedFolderUpdateUndo" in vault
    for action in ("Update from this copy", "Keep my local version", "Import as a separate folder", "Undo folder update"):
        assert action in app or action in html
    assert "SHARED_FOLDER_UPDATE_UNDO_MS = 30 * 60 * 1000" in background
    assert "SHARED_FOLDER_UPDATE_STALE" in background
    assert "maxBytes: C.LIMIT.bundle" in background
    assert "checkSharedFolderUpdate" in background
    assert "automatic: false" in background
    assert "if (!await askPermission(updateUrl," in app
    assert "The later copy was not checked. The local shared folder was kept." in app
    assert "Future copy checked only because you asked" in app
    assert "does not schedule another check" in app
    assert "verify that the exact shared-folder contents were signed by the matching private key" in html.lower()
    assert "Save ready-to-host website" in html
    assert "Share recent updates" in html
    assert "Save recent updates as feed" in html
    assert "makeFolderEdition" in core
    assert "progrss.folder-edition.v1" in core
    for excluded in ("fullRetainedText", "readingState", "savedState", "pageWatchEvidence", "snapshots", "browserAuthority", "privateKeys"):
        assert excluded in core
    assert "application/feed+json" in background
    assert "Include a recent-updates feed" in html
    assert "summary-only manual snapshot" in (html + publication_site)
    assert "recent-updates.json" in publication_site
    assert "recentUpdatesIncluded" in publication_site
    assert "advertisedFeedMediaType" in publication_site
    assert "export-publication-site" in app
    assert "ProgRSSPublicationSite" in app
    assert "progrss.publication-site.v1" in publication_site
    assert "Content-Security-Policy" in publication_site
    assert "default-src 'none'" in publication_site
    assert "scripts: 0" in publication_site and "trackers: 0" in publication_site
    assert "automaticChecks: false" in publication_site
    assert "discoverableFromPage: true" in publication_site
    assert "application/vnd.progrss.shared-folder+json" in publication_site
    assert 'rel="alternate"' in publication_site
    assert "Add → Use this page" in publication_site
    assert "does not poll" in publication_site
    assert "Curator’s reason for this folder:" in publication_site
    assert "not a ProgRSS safety claim" in publication_site
    assert "sourceNotes" in publication_site
    assert "white-space:pre-wrap" in publication_site
    assert "zipStore" in publication_site
    assert "chooseSharedFolders" in (extension / "shared" / "scout.js").read_text(encoding="utf-8")
    assert "Review source list" in app
    assert "SHARED_FOLDER_DISCOVERY_CROSS_ORIGIN" in background
    assert manifest.get("optional_host_permissions"), "site access must remain optional"

if __name__ == "__main__":
    test_relay_everyday_share_and_watch_surface()
    unittest.main(verbosity=2)
