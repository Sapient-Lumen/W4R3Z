'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const SOURCE_ROOT = path.resolve(__dirname, '..');
const ROOT = path.join(SOURCE_ROOT, 'Firefox');

const storage = new Map();
globalThis.localStorage = {
  getItem(key) { return storage.has(key) ? storage.get(key) : null; },
  setItem(key, value) { storage.set(key, String(value)); },
  removeItem(key) { storage.delete(key); }
};

const extensionStorage = new Map();
const messageListeners = [];
const actionListeners = [];
let sidebarOpenCount = 0;
let offscreenMessages = 0;
const parserCalls = [];

globalThis.DOMParser = function DOMParser() {};
globalThis.browser = {
  storage: {
    local: {
      async get(key) {
        if (typeof key === 'string') return {[key]: extensionStorage.get(key)};
        return Object.fromEntries(extensionStorage);
      },
      async set(values) { for (const [key, value] of Object.entries(values || {})) extensionStorage.set(key, value); },
      async remove(key) { extensionStorage.delete(key); }
    }
  },
  permissions: {
    async contains() { return true; },
    async getAll() { return {permissions: [], origins: ['https://example.test/*']}; },
    onRemoved: {addListener() {}}
  },
  runtime: {
    getURL(value) { return `moz-extension://test/${String(value).replace(/^\//, '')}`; },
    getManifest() { return {version: '0.80.0'}; },
    async sendMessage(message) {
      if (message?.target === 'offscreen') offscreenMessages++;
      throw new Error('Firefox background parsing must not use an offscreen document.');
    },
    onMessage: {addListener(listener) { messageListeners.push(listener); }},
    onInstalled: {addListener() {}},
    onStartup: {addListener() {}}
  },
  action: {
    async setBadgeBackgroundColor() {},
    async setBadgeText() {},
    async setTitle() {},
    onClicked: {addListener(listener) { actionListeners.push(listener); }}
  },
  sidebarAction: {async open() { sidebarOpenCount++; }},
  alarms: {async create() {}, onAlarm: {addListener() {}}},
  tabs: {async query() { return [{id: 1, url: 'https://example.test/', title: 'Example'}]; }},
  scripting: {async executeScript() { return [{result: {url: 'https://example.test/', title: 'Example', links: []}}]; }},
  webRequest: {}
};

let firefoxFetchMode = 'feed';
let firefoxPageContent = 'Library opens Monday morning at nine o’clock for quiet reading. The reading room closes at 6.';
globalThis.fetch = async () => firefoxFetchMode === 'page'
  ? new Response(`<html><body><main>${firefoxPageContent}</main></body></html>`, {status: 200, headers: {'Content-Type': 'text/html; charset=utf-8'}})
  : new Response(
      '<rss><channel><title>Firefox Harness</title><item><guid>entry-1</guid><title>One</title></item></channel></rss>',
      {status: 200, headers: {'Content-Type': 'application/rss+xml', 'Content-Length': '116'}}
    );

globalThis.importScripts = (...files) => {
  for (const file of files) {
    if (file === 'shared/parser.js') {
      globalThis.ProgRSSParser = Object.freeze({
        handle(type, data) {
          parserCalls.push({type, data});
          if (type === 'parse-feed') return {title: 'Firefox Harness', titleLanguage: 'en-GB', language: 'en-GB', type: 'rss', items: [{key: 'entry-1', title: 'One', url: 'https://example.test/1', summary: 'ملخص فايرفوكس', body: 'نص فايرفوكس الكامل\n\nفقرة ثانية.', bodyIsSummary: false, language: 'AR', titleLanguage: 'EN', summaryLanguage: 'AR', bodyLanguage: 'AR', published: ''}]};
          if (type === 'inspect-resource') return {kind: 'feed', url: data.url, title: 'Firefox Harness', titleLanguage: 'en-GB', language: 'en-GB', feedType: 'rss', itemCount: 1};
          if (type === 'parse-opml') return {title: 'Empty', feeds: [], feedOutlines: 0, duplicateCount: 0, invalidCount: 0, truncatedCount: 0};
          if (type === 'extract-page') return {mode: 'region', content: firefoxPageContent};
          throw new Error(`unexpected parser call ${type}`);
        }
      });
      continue;
    }
    vm.runInThisContext(fs.readFileSync(path.join(ROOT, file), 'utf8'), {filename: file});
  }
};

vm.runInThisContext(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8'), {filename: 'background.js'});
assert.strictEqual(messageListeners.length, 1, 'Firefox background message listener registered');
assert.strictEqual(actionListeners.length, 1, 'Firefox toolbar action opens the native sidebar');

function setBackupReminderFixture(marker) {
  extensionStorage.set('progrssBackupReminder', marker);
  vm.runInThisContext(`volatileBackupReminder = ${JSON.stringify(marker)};`);
}

function message(type, data = {}) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error(`timeout: ${type}`)), 1500);
    const keep = messageListeners[0]({target: 'background', type, data}, {}, response => {
      clearTimeout(timeout);
      resolve(response);
    });
    assert.strictEqual(keep, true, `${type} keeps response channel open`);
  });
}

(async () => {
  await actionListeners[0]();
  await new Promise(resolve => setTimeout(resolve, 0));
  assert.strictEqual(sidebarOpenCount, 1, 'native Firefox sidebar opened from the user action');

  let response = await message('add-source', {url: 'https://example.test/feed.xml', title: 'Firefox Harness', titleLanguage: 'EN-GB', language: 'EN-GB', type: 'rss'});
  assert.strictEqual(response.ok, true);
  const firefoxSourceId = response.result.source.id;
  response = await message('refresh-source', {sourceId: firefoxSourceId});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.added, 1);
  response = await message('get-state');
  assert.strictEqual(response.result.sources[0].language, 'en-gb');
  assert.strictEqual(response.result.sources[0].titleLanguage, 'en-gb');
  assert.strictEqual(response.result.items[0].body, 'نص فايرفوكس الكامل\n\nفقرة ثانية.');
  assert.strictEqual(response.result.items[0].bodyIsSummary, false);
  assert.strictEqual(response.result.items[0].language, 'ar');
  assert.strictEqual(response.result.items[0].titleLanguage, 'en');
  assert.strictEqual(response.result.items[0].bodyLanguage, 'ar');
  const firefoxItemId = response.result.items[0].id;
  setBackupReminderFixture({
    schema: 'progrss.backup-reminder.v1',
    firstMeaningfulAt: '2026-09-01T00:00:00.000Z',
    lastCopyAt: '', lastCopyRevision: 0, snoozedUntil: '', disabled: false,
    updatedAt: '2026-09-01T00:00:00.000Z'
  });
  response = await message('get-state');
  assert.strictEqual(response.result.backupReminder.visible, true);
  assert.strictEqual(response.result.backupReminder.status, 'no-checked-copy');
  assert.strictEqual(extensionStorage.get('progrssBackupReminder').schema, 'progrss.backup-reminder.v3');
  assert.match(extensionStorage.get('progrssBackupReminder').fingerprintKey, /^[0-9a-f]{64}$/);
  assert.ok(!JSON.stringify(extensionStorage.get('progrssBackupReminder')).includes('example.test'));
  response = await message('disable-backup-reminder');
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.disabled, true);
  response = await message('enable-backup-reminder');
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.visible, true);
  response = await message('export-private-backup', {recovery: true});
  assert.strictEqual(response.ok, true);
  const firefoxPreparedRaw = response.result.raw;
  assert.strictEqual(response.result.backupReminder.status, 'prepared-not-checked');
  assert.strictEqual(response.result.backupReminder.visible, true);
  assert.strictEqual(response.result.backupReminder.pendingCheck, true);
  response = await message('check-private-backup', {raw: firefoxPreparedRaw});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.state, 'current');
  assert.strictEqual(response.result.backupReminder.status, 'current');
  assert.strictEqual(response.result.backupReminder.visible, false);
  assert.strictEqual(response.result.writesVault, false);
  assert.strictEqual(response.result.schema, 'progrss.private-copy-check.v2');

  response = await message('mark-backup-copy-missing');
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.status, 'copy-missing');
  assert.strictEqual(response.result.checkedCopyMissing, true);
  response = await message('check-private-backup', {raw: firefoxPreparedRaw});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.state, 'current');
  assert.strictEqual(response.result.backupReminder.checkedCopyMissing, false);

  response = await message('set-item', {itemId: firefoxItemId, read: true, starred: false});
  assert.strictEqual(response.ok, true);
  response = await message('check-private-backup', {raw: firefoxPreparedRaw});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.state, 'previous');
  assert.strictEqual(response.result.relationship, 'last-checked');
  assert.strictEqual(response.result.samePortableLibrary, false);
  response = await message('set-source-text-retention', {sourceId: firefoxSourceId, mode: 'summary'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.cleanupEligible, 1);
  response = await message('prune-source-text', {sourceId: firefoxSourceId});
  assert.strictEqual(response.ok, true);
  const firefoxTextUndo = response.result;
  assert.strictEqual(firefoxTextUndo.changed.length, 1);
  response = await message('get-state');
  assert.strictEqual(response.result.items[0].bodyOmitted, true);
  assert.strictEqual(response.result.items[0].body, response.result.items[0].summary);
  response = await message('undo-source-text-prune', {sourceId: firefoxSourceId, items: firefoxTextUndo.changed, expectedRevision: firefoxTextUndo.expectedRevision});
  assert.strictEqual(response.ok, true);
  response = await message('set-source-text-retention', {sourceId: firefoxSourceId, mode: 'full'});
  assert.strictEqual(response.ok, true);

  response = await message('inspect-url', {url: 'https://example.test/feed.xml'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.kind, 'feed');
  assert.ok(parserCalls.some(call => call.type === 'parse-feed'));
  assert.ok(parserCalls.some(call => call.type === 'inspect-resource'));
  assert.strictEqual(offscreenMessages, 0, 'Firefox direct parser path never messaged an offscreen document');

  response = await message('export-private-backup');
  assert.strictEqual(response.ok, true);
  const exported = JSON.parse(response.result.raw);
  assert.strictEqual(exported.producer.version, '0.80.0');
  assert.strictEqual(exported.producer.revision, 'rev0080');
  assert.ok(!Object.hasOwn(exported.state, 'transferUndo'));
  assert.ok(!Object.hasOwn(exported.state, 'sourceRepairUndo'));
  assert.ok(!Object.hasOwn(exported.state, 'receiptRetirementUndo'));

  response = await message('report-storage-write-failure', {
    name: 'QuotaExceededError', reason: 'quota', message: 'Injected Firefox harness limit'
  });
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.reason, 'quota');
  assert.strictEqual(extensionStorage.get('progrssStorageIncident').reason, 'quota');
  response = await message('get-state');
  assert.strictEqual(response.result.storageIncident.reason, 'quota');
  response = await message('export-private-backup', {recovery: true});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(JSON.parse(response.result.raw).purpose, 'recovery-copy');
  response = await message('probe-vault-write');
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.available, true);
  response = await message('get-state');
  assert.strictEqual(response.result.storageIncident, null);
  assert.strictEqual(extensionStorage.has('progrssStorageIncident'), false);

  const repairState = await globalThis.ProgRSSVault.init();
  const original = repairState.sources.find(source => source.id === firefoxSourceId);
  original.declaredFeedUrl = 'https://example.test/feed.xml';
  original.httpCache = {etag: '"firefox-survivor"'};
  repairState.sources.push({
    id: 'firefox-copy', title: 'Firefox Harness copy', type: 'rss',
    url: 'https://example.test/alternate.xml', declaredFeedUrl: 'https://example.test/feed.xml',
    enabled: false, archivedAt: '', httpCache: {lastModified: 'Fri, 17 Oct 2026 12:00:00 GMT'}
  });
  const firefoxItem = repairState.items.find(item => item.sourceId === firefoxSourceId);
  assert.ok(firefoxItem, 'refreshed Firefox source retained an update');
  repairState.receipts.push(
    {
      id: 'firefox-graft-reference', schema: 'progrss.recipe.graft.receipt.v1',
      title: 'Firefox reviewed graft', sourceId: 'firefox-copy', itemId: firefoxItem.id
    },
    {
      id: 'firefox-merge-reference', schema: 'progrss.recipe.merge.receipt.v1',
      title: 'Firefox branch receipt', sourceId: 'firefox-copy'
    }
  );
  await globalThis.ProgRSSVault.save(repairState);
  response = await message('source-repair-references', {firstSourceId: firefoxSourceId, secondSourceId: 'firefox-copy'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.schema, 'progrss.source-reference-report.v1');
  assert.strictEqual(response.result.summary.blockingRecords, 2);
  const firefoxGraft = response.result.groups[0].records.find(row => row.recordId === 'firefox-graft-reference');
  const firefoxMerge = response.result.groups[0].records.find(row => row.recordId === 'firefox-merge-reference');
  assert.strictEqual(firefoxGraft.retirement.eligible, true);
  assert.strictEqual(firefoxMerge.retirement, null, 'unknown receipt schemas remain blocked');
  assert.strictEqual(response.result.network, false);

  const retirementPayload = {
    firstSourceId: firefoxSourceId,
    secondSourceId: 'firefox-copy',
    recordIndex: firefoxGraft.index,
    recordId: firefoxGraft.recordId
  };
  response = await message('preview-graft-receipt-retirement', retirementPayload);
  assert.strictEqual(response.ok, true);
  assert.match(response.result.receipt.digest, /^[0-9a-f]{64}$/);
  response = await message('retire-graft-receipt', {
    ...retirementPayload,
    reviewedRevision: response.result.reviewedRevision,
    expectedDigest: response.result.receipt.digest
  });
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.undoAvailable, true);
  response = await message('source-repair-references', {firstSourceId: firefoxSourceId, secondSourceId: 'firefox-copy'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.summary.blockingRecords, 1);
  assert.strictEqual(response.result.summary.retiredRecords, 1);
  assert.strictEqual(response.result.groups[0].records[0].recordId, 'firefox-merge-reference');

  // The merge receipt still has no safe cleanup rule and therefore remains a
  // blocker. Remove it explicitly in the harness before testing source repair.
  const unblockedFirefox = await globalThis.ProgRSSVault.init();
  unblockedFirefox.receipts = unblockedFirefox.receipts.filter(row => row.id !== 'firefox-merge-reference');
  await globalThis.ProgRSSVault.save(unblockedFirefox);
  response = await message('preview-source-repair', {firstSourceId: firefoxSourceId, secondSourceId: 'firefox-copy'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.canRepair, true);
  response = await message('repair-same-source', {
    firstSourceId: firefoxSourceId, secondSourceId: 'firefox-copy', survivorId: firefoxSourceId,
    reviewedRevision: response.result.reviewedRevision
  });
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  assert.strictEqual(response.result.sources.some(source => source.id === 'firefox-copy'), false);
  assert.strictEqual(response.result.sourceRepair.undoAvailable, true);
  assert.strictEqual(response.result.receiptRetirement.undoAvailable, false);
  response = await message('undo-source-repair');
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  assert.strictEqual(response.result.sources.some(source => source.id === 'firefox-copy'), true);

  const incoming = JSON.stringify({
    schema: 'progrss.private.v1', exportedAt: '2026-10-18T05:10:00Z',
    state: {
      version: 13,
      sources: [{id: 'firefox-move', title: 'Moved Library', type: 'rss', url: 'https://new.test/feed.xml', enabled: true, archivedAt: ''}],
      collections: [], items: [], snapshots: {}, fixtures: [], inbox: [], receipts: [], subscriptions: [], publications: [],
      patchPins: [], keyRotations: [], recoveryPolicies: [], recoveryReceipts: [], charterHistory: [], charterClaims: [], gossipCards: [],
      witnessPins: [], merklePins: [], merkleReceipts: [], proofRequests: [], proofSightings: [], proofForks: [], fixturePacks: []
    }
  });
  response = await message('preview-private-backup', {raw: incoming});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.permissions.reconnectSources, 1);
  const reviewedRevision = response.result.reviewedRevision;
  assert.ok(Number.isSafeInteger(reviewedRevision));
  response = await message('restore-private-backup', {raw: incoming, reviewedRevision});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.undoAvailable, true);
  response = await message('get-state');
  assert.strictEqual(response.result.sources[0].permissionMissingReason, 'transfer');
  assert.strictEqual(response.result.transfer.undoAvailable, true);

  response = await message('export-private-backup');
  assert.strictEqual(response.ok, true);
  const firefoxMissingBackup = response.result.raw;
  const firefoxPresence = extensionStorage.get('progrssLibraryPresence');
  assert.strictEqual(firefoxPresence.schema, 'progrss.library.presence.v1');
  assert.strictEqual(firefoxPresence.hadLibrary, true);
  assert.ok(!JSON.stringify(firefoxPresence).includes('https://'));
  storage.clear();
  response = await message('get-state');
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.libraryRecovery.state, 'missing');
  response = await message('add-source', {url: 'https://example.test/blocked.xml', title: 'Blocked', type: 'rss'});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'LIBRARY_RECOVERY_REQUIRED');
  response = await message('preview-private-backup', {raw: firefoxMissingBackup});
  assert.strictEqual(response.ok, true);
  response = await message('restore-private-backup', {raw: firefoxMissingBackup, reviewedRevision: response.result.reviewedRevision});
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  assert.notStrictEqual(response.result.libraryRecovery.state, 'missing');

  response = await message('add-source', {
    url: 'https://example.test/firefox-hours', title: 'Firefox library hours', type: 'page', mode: 'region', selector: 'main'
  });
  assert.strictEqual(response.ok, true);
  const firefoxWatchId = response.result.source.id;
  firefoxFetchMode = 'page';
  firefoxPageContent = 'Library opens Monday morning at nine o’clock for quiet reading. The reading room closes at 6.';
  response = await message('refresh-source', {sourceId: firefoxWatchId});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.baseline, true);
  firefoxPageContent = 'Library now opens Tuesday afternoon at ten o’clock for community workshops. The reading room closes at 6.';
  response = await message('refresh-source', {sourceId: firefoxWatchId});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.added, 1);
  response = await message('get-state');
  const firefoxPageChange = response.result.items.find(item => item.sourceId === firefoxWatchId);
  assert.strictEqual(firefoxPageChange.change.schema, 'progrss.page-change.v1');
  assert.strictEqual(firefoxPageChange.change.kind, 'text-changed');
  assert.match(firefoxPageChange.change.before, /Monday morning/);
  assert.match(firefoxPageChange.change.after, /Tuesday afternoon/);
  assert.ok(parserCalls.some(call => call.type === 'extract-page'));
  assert.strictEqual(offscreenMessages, 0, 'Firefox page watching still uses the direct parser path');

  response = await message('add-source', {
    url: 'https://example.test/firefox-steady', title: 'Firefox steady watch', type: 'page', mode: 'region', selector: 'main'
  });
  assert.strictEqual(response.ok, true);
  const firefoxSteadyId = response.result.source.id;
  firefoxPageContent = Array(110).fill('baseline').join(' ');
  response = await message('refresh-source', {sourceId: firefoxSteadyId});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.baseline, true);
  firefoxPageContent = Array(20).fill('unusual').join(' ');
  response = await message('refresh-source', {sourceId: firefoxSteadyId});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.held, true);
  response = await message('get-state');
  const firefoxSteadySource = response.result.sources.find(source => source.id === firefoxSteadyId);
  assert.strictEqual(firefoxSteadySource.lastOutcome, 'watch-pending');
  assert.strictEqual(firefoxSteadySource.watchStability.schema, 'progrss.page-watch.stability.v1');
  assert.strictEqual(response.result.items.some(item => item.sourceId === firefoxSteadyId), false);
  response = await message('export-private-backup');
  assert.strictEqual(response.ok, true);
  const portableSteady = JSON.parse(response.result.raw).state.sources.find(source => source.id === firefoxSteadyId);
  assert.ok(portableSteady);
  assert.strictEqual(portableSteady.watchStability, undefined);
  firefoxPageContent = Array(22).fill('unusual').join(' ');
  response = await message('refresh-source', {sourceId: firefoxSteadyId});
  assert.strictEqual(response.ok, true);
  assert.notStrictEqual(response.result.held, true);
  response = await message('get-state');
  const confirmedSteady = response.result.sources.find(source => source.id === firefoxSteadyId);
  assert.strictEqual(confirmedSteady.watchStability, undefined);
  assert.strictEqual(confirmedSteady.watchHealth.reason, 'confirmed-shape-change');

  console.log('PASS Firefox background harness: browser namespace, native sidebar, direct parser, shared vault, structured page-change baseline and Before/Now ingestion, held/confirmed page-watch shape changes with portable-state exclusion, private-copy marker migration, keyed current/older-copy recognition, explicit missing-copy recovery, reminder choices, persistent storage-incident recovery copy and probe, missing-library detection and reviewed restore, feed refresh, offline-text policy and guarded cleanup, exact graft-receipt retirement with other schemas still blocked, same-source repair and private-library transfer');
})().catch(error => {
  console.error(error.stack || error);
  process.exitCode = 1;
});
