#!/usr/bin/env python3
"""Native unpacked-extension acceptance against a persistent Chromium profile.

This uses the Chrome DevTools Protocol Extensions.loadUnpacked command rather
than the removed branded-Chrome --load-extension path. Chromium must allow
unpacked extension installation; managed ExtensionInstallBlocklist policy can
legitimately block this test and yields exit status 77.
"""
from __future__ import annotations

import asyncio
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
from typing import Any

from playwright.async_api import BrowserContext, Error as PlaywrightError, async_playwright

ROOT = Path(__file__).resolve().parents[1]
CHROMIUM = os.environ.get("PROGRSS_CHROMIUM") or shutil.which("chromium") or shutil.which("chromium-browser") or shutil.which("google-chrome")
SOURCE_URL = "https://installed-profile.test/feed.xml"
SOURCE_TITLE = "Installed profile persistence"


async def launch(p: Any, profile: Path) -> BrowserContext:
    if not CHROMIUM:
        raise RuntimeError("No Chromium executable found. Set PROGRSS_CHROMIUM.")
    return await p.chromium.launch_persistent_context(
        str(profile),
        executable_path=CHROMIUM,
        headless=True,
        viewport={"width": 390, "height": 844},
        ignore_default_args=["--disable-extensions"],
        args=[
            "--no-sandbox",
            "--disable-dev-shm-usage",
            "--enable-unsafe-extension-debugging",
        ],
    )


async def install_unpacked(context: BrowserContext) -> str:
    browser = context.browser
    if browser is None:
        raise RuntimeError("Persistent Chromium browser handle is unavailable.")
    session = await browser.new_browser_cdp_session()
    try:
        result = await session.send("Extensions.loadUnpacked", {"path": str(ROOT.resolve())})
    except PlaywrightError as error:
        message = str(error)
        if "disabled by the administrator" in message.lower():
            raise PermissionError("Chromium policy blocks unpacked extension installation") from error
        raise
    extension_id = str(result.get("id") or "")
    if not extension_id:
        raise AssertionError("Extensions.loadUnpacked did not return an extension id")
    return extension_id


async def seed_source_through_vault(context: BrowserContext, extension_id: str) -> str:
    """Seed the real vault without bypassing production code or granting a host.

    The installed-profile lane is about storage/worker continuity. Site-access
    acquisition is covered by network_acceptance.py with a loopback test grant.
    """
    page = await context.new_page()
    response = await page.goto(f"chrome-extension://{extension_id}/workbench/index.html", wait_until="domcontentloaded")
    assert response is not None and response.status == 200, response
    await page.wait_for_function("() => Boolean(globalThis.ProgRSSVault && globalThis.ProgRSSCore)")
    source_id = await page.evaluate(
        """async ([url, title]) => {
          const state = await ProgRSSVault.init();
          const existing = state.sources.find(row => row.url === url);
          if (existing) return existing.id;
          const source = {...ProgRSSCore.cleanRecipe({id: ProgRSSCore.uid('feed'), title, type:'rss', url, mode:'region', selector:'', titleSelector:'', linkSelector:'', include:'', exclude:'', threshold:1, ignoreNumbers:false, author:'installed acceptance', version:1}), enabled:false, origin:'installed-acceptance', createdAt:new Date().toISOString(), lastScan:'', lastError:'', lastSuccessfulAt:'', lastNewAt:'', lastProblemAt:'', lastProblem:''};
          state.sources.push(source);
          await ProgRSSVault.save(state);
          return source.id;
        }""",
        [SOURCE_URL, SOURCE_TITLE],
    )
    await page.close()
    return str(source_id)


async def seed_text_retention_fixture(context: BrowserContext, extension_id: str, source_id: str) -> str:
    """Add one read, unsaved full-text item through the real vault."""
    item_id = f"{source_id}|installed-offline-text"
    page = await context.new_page()
    response = await page.goto(f"chrome-extension://{extension_id}/workbench/index.html", wait_until="domcontentloaded")
    assert response is not None and response.status == 200, response
    await page.wait_for_function("() => Boolean(globalThis.ProgRSSVault)")
    await page.evaluate(
        """async ([sourceId, itemId]) => {
          const state = await ProgRSSVault.init();
          const source = state.sources.find(row => row.id === sourceId);
          if (!source) throw new Error('Installed source is unavailable.');
          source.type = 'rss';
          source.enabled = false;
          state.items = state.items.filter(row => row.id !== itemId);
          state.items.push({
            id: itemId, entryKey: itemId, sourceId, feedRevision: 0,
            title: 'Installed offline text',
            url: 'https://installed-profile.test/offline-text',
            summary: 'A short feed summary.',
            body: 'A short feed summary.\\n\\nA fuller paragraph retained for offline reading.',
            bodyIsSummary: false,
            published: '2026-10-18T10:30:00.000Z',
            observedAt: '2026-10-18T10:31:00.000Z',
            kind: 'new', readAt: '2026-10-18T10:40:00.000Z', starred: false
          });
          await ProgRSSVault.save(state);
        }""",
        [source_id, item_id],
    )
    await page.close()
    return item_id


async def seed_source_repair_fixture(context: BrowserContext, extension_id: str, source_id: str) -> str:
    """Create two reviewed alias histories in the real IndexedDB vault."""
    duplicate_id = "installed-repair-copy"
    page = await context.new_page()
    response = await page.goto(f"chrome-extension://{extension_id}/workbench/index.html", wait_until="domcontentloaded")
    assert response is not None and response.status == 200, response
    await page.wait_for_function("() => Boolean(globalThis.ProgRSSVault && globalThis.ProgRSSCore)")
    result = await page.evaluate(
        """async ([sourceId, duplicateId, sourceUrl]) => {
          const state = await ProgRSSVault.init();
          const source = state.sources.find(row => row.id === sourceId);
          if (!source) throw new Error('Installed source is unavailable.');
          source.url = sourceUrl;
          source.declaredFeedUrl = sourceUrl;
          source.enabled = false;
          source.httpCache = {etag: '"installed-survivor"'};
          source.pulse = {nextAt: '2026-10-19T12:00:00.000Z'};
          source.lastSuccessfulAt = '2026-10-18T10:00:00.000Z';
          source.lastNewAt = '2026-10-18T09:00:00.000Z';
          state.sources = state.sources.filter(row => row.id !== duplicateId);
          state.items = state.items.filter(row => row.sourceId !== sourceId && row.sourceId !== duplicateId);
          state.collections = state.collections.filter(row => row.id !== 'installed-repair-folder');
          state.sources.push({
            id: duplicateId, title: 'Installed duplicate history', type: 'rss',
            url: 'https://installed-profile.test/alternate.xml', declaredFeedUrl: sourceUrl,
            enabled: false, archivedAt: '', origin: 'installed-acceptance',
            createdAt: '2026-10-16T08:00:00.000Z',
            lastSuccessfulAt: '2026-10-17T08:00:00.000Z',
            lastNewAt: '2026-10-17T07:00:00.000Z',
            lastProblemAt: '2026-10-17T06:00:00.000Z', lastProblem: 'Earlier timeout',
            checkCount: 3, httpCache: {lastModified: 'Fri, 17 Oct 2026 08:00:00 GMT'},
            pulse: {nextAt: '2026-10-20T12:00:00.000Z'}
          });
          const common = {
            title: 'Installed retained update', url: 'https://installed-profile.test/post/1',
            summary: 'The same retained update in both histories.',
            body: 'The same retained update in both histories.\\n\\nThis second paragraph is available inside ProgRSS.',
            bodyIsSummary: false,
            published: '2026-10-18T08:00:00.000Z', kind: 'new', feedRevision: 0
          };
          state.items.push(
            {...common, id: `${sourceId}|entry-1`, entryKey: `${sourceId}|entry-1`, sourceId, observedAt: '2026-10-18T08:01:00.000Z', readAt: '', starred: true},
            {...common, id: `${duplicateId}|entry-1`, entryKey: `${duplicateId}|entry-1`, sourceId: duplicateId, observedAt: '2026-10-18T08:02:00.000Z', readAt: '2026-10-18T09:00:00.000Z', starred: false},
            {id: `${duplicateId}|entry-2`, entryKey: `${duplicateId}|entry-2`, sourceId: duplicateId, feedRevision: 0, title: 'Copy-only retained update', url: 'https://installed-profile.test/post/2', summary: 'Only in the second history.', published: '2026-10-18T07:00:00.000Z', observedAt: '2026-10-18T07:01:00.000Z', kind: 'new', readAt: '', starred: false}
          );
          state.collections.push({
            id: 'installed-repair-folder', title: 'Installed repair', mode: 'union', version: 1,
            members: [{kind: 'source', id: sourceId}, {kind: 'source', id: duplicateId}]
          });
          state.receipts = (Array.isArray(state.receipts) ? state.receipts : [])
            .filter(row => row.id !== 'installed-repair-reference');
          state.receipts.push({
            id: 'installed-repair-reference', schema: 'progrss.recipe.graft.receipt.v1',
            title: 'Installed reviewed garden graft', sourceId: duplicateId,
            evidence: {retainedItemId: `${sourceId}|entry-1`, companionItemId: `${duplicateId}|entry-2`}
          });
          await ProgRSSVault.save(state);
          return duplicateId;
        }""",
        [source_id, duplicate_id, SOURCE_URL],
    )
    await page.close()
    return str(result)


async def remove_source_repair_blocker(context: BrowserContext, extension_id: str) -> None:
    """Remove the exact advanced record after proving its read-only report."""
    page = await context.new_page()
    response = await page.goto(f"chrome-extension://{extension_id}/workbench/index.html", wait_until="domcontentloaded")
    assert response is not None and response.status == 200, response
    await page.wait_for_function("() => Boolean(globalThis.ProgRSSVault)")
    await page.evaluate(
        """async () => {
          const state = await ProgRSSVault.init();
          state.receipts = (Array.isArray(state.receipts) ? state.receipts : [])
            .filter(row => row.id !== 'installed-repair-reference');
          await ProgRSSVault.save(state);
        }"""
    )
    await page.close()


async def clear_source_repair_fixture(context: BrowserContext, extension_id: str, source_id: str, duplicate_id: str) -> None:
    """Return the installed profile to one source after the repair/undo proof."""
    page = await context.new_page()
    response = await page.goto(f"chrome-extension://{extension_id}/workbench/index.html", wait_until="domcontentloaded")
    assert response is not None and response.status == 200, response
    await page.wait_for_function("() => Boolean(globalThis.ProgRSSVault && globalThis.ProgRSSCore)")
    await page.evaluate(
        """async ([sourceId, duplicateId]) => {
          const state = await ProgRSSVault.init();
          state.sources = state.sources.filter(row => row.id !== duplicateId);
          state.items = state.items.filter(row => row.sourceId !== duplicateId);
          state.collections = state.collections
            .filter(row => row.id !== 'installed-repair-folder')
            .map(row => ({...row, members: Array.isArray(row.members) ? row.members.filter(member => !(member.kind === 'source' && member.id === duplicateId)) : row.members}));
          state.sourceRepairUndo = null;
          state.receiptRetirementUndo = null;
          state.retiredReceipts = [];
          state.receipts = (Array.isArray(state.receipts) ? state.receipts : [])
            .filter(row => row.id !== 'installed-repair-reference');
          const source = state.sources.find(row => row.id === sourceId);
          if (!source) throw new Error('Installed source disappeared during cleanup.');
          source.title = 'Installed profile persistence';
          await ProgRSSVault.save(state);
        }""",
        [source_id, duplicate_id],
    )
    await page.close()


async def open_reader(context: BrowserContext, extension_id: str):
    page = await context.new_page()
    response = await page.goto(f"chrome-extension://{extension_id}/sidepanel/index.html", wait_until="domcontentloaded")
    assert response is not None and response.status == 200, response
    await page.wait_for_function("() => document.querySelector('#today-summary').textContent !== 'Loading your reading…'")
    return page


async def runtime_message(page: Any, message_type: str, data: dict[str, Any] | None = None) -> dict[str, Any]:
    result = await page.evaluate(
        "([type, data]) => chrome.runtime.sendMessage({target:'background', type, data})",
        [message_type, data or {}],
    )
    assert isinstance(result, dict) and result.get("ok") is True, result
    return result["result"]


async def runtime_message_raw(page: Any, message_type: str, data: dict[str, Any] | None = None) -> dict[str, Any]:
    result = await page.evaluate(
        "([type, data]) => chrome.runtime.sendMessage({target:'background', type, data})",
        [message_type, data or {}],
    )
    assert isinstance(result, dict), result
    return result


async def delete_extension_vault(page: Any) -> None:
    """Delete only ProgRSS IndexedDB, leaving extension storage.local intact."""
    result = await page.evaluate(
        """async () => await new Promise((resolve, reject) => {
          const request = indexedDB.deleteDatabase('progrss-vault');
          request.onsuccess = () => resolve('deleted');
          request.onerror = () => reject(request.error || new Error('IndexedDB deletion failed'));
          request.onblocked = () => reject(new Error('IndexedDB deletion was blocked'));
        })"""
    )
    assert result == "deleted", result


async def stop_service_worker(context: BrowserContext, extension_id: str) -> None:
    browser = context.browser
    assert browser is not None
    session = await browser.new_browser_cdp_session()
    targets = (await session.send("Target.getTargets"))["targetInfos"]
    expected = f"chrome-extension://{extension_id}/background.js"
    matches = [row for row in targets if row.get("type") == "service_worker" and row.get("url") == expected]
    assert matches, f"No running MV3 service worker for {expected}"
    result = await session.send("Target.closeTarget", {"targetId": matches[0]["targetId"]})
    assert result.get("success") is True, result


async def main() -> int:
    profile_override = os.environ.get("PROGRSS_TEST_PROFILE")
    temporary = None if profile_override else tempfile.TemporaryDirectory(prefix="progrss-installed-")
    profile = Path(profile_override) if profile_override else Path(temporary.name)
    profile.mkdir(parents=True, exist_ok=True)

    try:
        async with async_playwright() as p:
            first = await launch(p, profile)
            try:
                extension_id = await install_unpacked(first)
                page = await open_reader(first, extension_id)
                manifest = await page.evaluate("chrome.runtime.getManifest()")
                assert manifest["version"] == "0.80.0", manifest

                state = await runtime_message(page, "get-state")
                assert state["vault"]["mode"] == "indexeddb", state["vault"]
                assert state["sources"] == [], state["sources"]

                source_id = await seed_source_through_vault(first, extension_id)
                state = await runtime_message(page, "get-state")
                assert [row["id"] for row in state["sources"]] == [source_id]

                # The private-copy reminder is one non-sensitive marker outside
                # the vault. It stays quiet for a new library, survives worker
                # interruption, and can be paused or disabled by the person.
                reminder_marker = await page.evaluate("chrome.storage.local.get('progrssBackupReminder')")
                reminder_marker = reminder_marker.get("progrssBackupReminder")
                assert reminder_marker["schema"] == "progrss.backup-reminder.v3", reminder_marker
                assert len(reminder_marker["fingerprintKey"]) == 64, reminder_marker
                serialized_reminder = json.dumps(reminder_marker, ensure_ascii=False)
                assert "https://" not in serialized_reminder and SOURCE_TITLE not in serialized_reminder, reminder_marker
                await page.evaluate(
                    """async () => chrome.storage.local.set({progrssBackupReminder:{
                      schema:'progrss.backup-reminder.v2', firstMeaningfulAt:'2026-09-01T00:00:00.000Z',
                      lastPreparedAt:'', lastPreparedRevision:0, lastCheckedAt:'', lastCheckedRevision:0,
                      snoozedUntil:'', disabled:false, updatedAt:'2026-09-01T00:00:00.000Z'
                    }})"""
                )
                await stop_service_worker(first, extension_id)
                state = await runtime_message(page, "get-state")
                assert state["backupReminder"]["visible"] is True, state["backupReminder"]
                migrated_marker = (await page.evaluate("chrome.storage.local.get('progrssBackupReminder')"))["progrssBackupReminder"]
                assert migrated_marker["schema"] == "progrss.backup-reminder.v3", migrated_marker
                assert len(migrated_marker["fingerprintKey"]) == 64, migrated_marker
                snoozed = await runtime_message(page, "snooze-backup-reminder")
                assert snoozed["visible"] is False and snoozed["snoozedUntil"], snoozed
                await stop_service_worker(first, extension_id)
                state = await runtime_message(page, "get-state")
                assert state["backupReminder"]["visible"] is False, state["backupReminder"]
                enabled = await runtime_message(page, "enable-backup-reminder")
                assert enabled["visible"] is True and enabled["disabled"] is False, enabled

                exported = await runtime_message(page, "export-private-backup")
                export_doc = json.loads(exported["raw"])
                assert export_doc["schema"] == "progrss.private.v1", export_doc
                assert export_doc["producer"]["version"] == "0.80.0", export_doc["producer"]
                assert "_revision" not in export_doc["state"]
                assert "transferUndo" not in export_doc["state"]
                assert "sourceRepairUndo" not in export_doc["state"]
                assert "receiptRetirementUndo" not in export_doc["state"]
                assert "progrss.backup-reminder.v3" not in exported["raw"]
                prepared_marker = (await page.evaluate("chrome.storage.local.get('progrssBackupReminder')"))["progrssBackupReminder"]
                assert prepared_marker["fingerprintKey"] not in exported["raw"], prepared_marker
                assert prepared_marker["lastPreparedFingerprint"] not in exported["raw"], prepared_marker
                assert exported["backupReminder"]["visible"] is True, exported["backupReminder"]
                assert exported["backupReminder"]["status"] == "prepared-not-checked", exported["backupReminder"]
                assert exported["backupReminder"]["pendingCheck"] is True, exported["backupReminder"]
                await stop_service_worker(first, extension_id)
                state = await runtime_message(page, "get-state")
                assert state["backupReminder"]["status"] == "prepared-not-checked", state["backupReminder"]
                checked = await runtime_message(page, "check-private-backup", {"raw": exported["raw"]})
                assert checked["samePortableLibrary"] is True, checked
                assert checked["state"] == "current", checked
                assert checked["writesVault"] is False, checked
                assert checked["backupReminder"]["status"] == "current", checked["backupReminder"]
                await stop_service_worker(first, extension_id)
                state = await runtime_message(page, "get-state")
                assert state["backupReminder"]["status"] == "current", state["backupReminder"]
                assert state["backupReminder"]["visible"] is False, state["backupReminder"]

                missing_copy = await runtime_message(page, "mark-backup-copy-missing")
                assert missing_copy["status"] == "copy-missing", missing_copy
                assert missing_copy["checkedCopyMissing"] is True, missing_copy
                await stop_service_worker(first, extension_id)
                state = await runtime_message(page, "get-state")
                assert state["backupReminder"]["checkedCopyMissing"] is True, state["backupReminder"]
                found_again = await runtime_message(page, "check-private-backup", {"raw": exported["raw"]})
                assert found_again["state"] == "current", found_again
                assert found_again["backupReminder"]["checkedCopyMissing"] is False, found_again["backupReminder"]

                await runtime_message(page, "rename-source", {"sourceId": source_id, "title": "Installed source renamed after copy"})
                older = await runtime_message(page, "check-private-backup", {"raw": exported["raw"]})
                assert older["state"] == "previous", older
                assert older["relationship"] == "last-checked", older
                assert older["samePortableLibrary"] is False, older
                await runtime_message(page, "mark-backup-copy-missing")
                await stop_service_worker(first, extension_id)
                older_found = await runtime_message(page, "check-private-backup", {"raw": exported["raw"]})
                assert older_found["state"] == "previous", older_found
                assert older_found["backupReminder"]["checkedCopyMissing"] is False, older_found["backupReminder"]
                await runtime_message(page, "rename-source", {"sourceId": source_id, "title": SOURCE_TITLE})

                # A Workbench-style write failure becomes one persistent,
                # reader-facing incident without mutating the committed vault.
                incident = await runtime_message(page, "report-storage-write-failure", {
                    "name": "QuotaExceededError",
                    "reason": "quota",
                    "message": "Injected installed-profile storage limit",
                })
                assert incident["schema"] == "progrss.storage.incident.v1", incident
                assert incident["reason"] == "quota", incident
                state = await runtime_message(page, "get-state")
                assert state["storageIncident"]["reason"] == "quota", state["storageIncident"]
                assert [row["id"] for row in state["sources"]] == [source_id], state["sources"]
                recovery = await runtime_message(page, "export-private-backup", {"recovery": True})
                recovery_doc = json.loads(recovery["raw"])
                assert recovery_doc["purpose"] == "recovery-copy", recovery_doc
                assert recovery["fileName"].startswith("ProgRSS-recovery-"), recovery
                assert "_revision" not in recovery_doc["state"], recovery_doc["state"]

                await stop_service_worker(first, extension_id)
                state = await runtime_message(page, "get-state")
                assert state["storageIncident"]["reason"] == "quota", state["storageIncident"]
                probe = await runtime_message(page, "probe-vault-write")
                assert probe["available"] is True, probe
                assert "small test write" in probe["note"].lower(), probe
                state = await runtime_message(page, "get-state")
                assert state["storageIncident"] is None, state["storageIncident"]

                transfer_doc = {
                    "schema": "progrss.private.v1",
                    "exportedAt": "2026-10-18T06:00:00Z",
                    "producer": {"name": "ProgRSS", "version": "0.80.0", "revision": "rev0080"},
                    "state": {
                        "version": 14,
                        "sources": [{
                            "id": "installed-transfer",
                            "title": "Installed transfer source",
                            "type": "rss",
                            "url": "https://transfer.example.test/feed.xml",
                            "enabled": True,
                            "archivedAt": "",
                        }],
                        "collections": [], "items": [], "snapshots": {},
                        "fixtures": [], "inbox": [], "receipts": [], "subscriptions": [], "publications": [],
                        "patchPins": [], "keyRotations": [], "recoveryPolicies": [], "recoveryReceipts": [],
                        "charterHistory": [], "charterClaims": [], "gossipCards": [], "witnessPins": [],
                        "merklePins": [], "merkleReceipts": [], "proofRequests": [], "proofSightings": [],
                        "proofForks": [], "fixturePacks": [],
                    },
                }
                transfer_raw = json.dumps(transfer_doc)
                preview = await runtime_message(page, "preview-private-backup", {"raw": transfer_raw})
                assert preview["incoming"]["sources"] == 1, preview
                assert preview["current"]["sources"] == 1, preview
                assert preview["permissions"]["reconnectSources"] == 1, preview
                reviewed_revision = preview["reviewedRevision"]
                assert isinstance(reviewed_revision, int)
                restored = await runtime_message(page, "restore-private-backup", {"raw": transfer_raw, "reviewedRevision": reviewed_revision})
                assert restored["permissions"]["reconnectSources"] == 1, restored
                state = await runtime_message(page, "get-state")
                assert state["sources"][0]["id"] == "installed-transfer", state["sources"]
                assert state["sources"][0]["permissionMissingReason"] == "transfer", state["sources"][0]
                assert state["transfer"]["undoAvailable"] is True, state["transfer"]

                await stop_service_worker(first, extension_id)
                # A new message must wake a fresh worker and retain both the
                # transferred library and its bounded local undo record.
                state = await runtime_message(page, "get-state")
                assert state["sources"][0]["id"] == "installed-transfer", state["sources"]
                assert state["transfer"]["undoAvailable"] is True, state["transfer"]
                nested_export = json.loads((await runtime_message(page, "export-private-backup"))["raw"])
                assert "transferUndo" not in nested_export["state"]
                await runtime_message(page, "undo-private-backup-restore")
                state = await runtime_message(page, "get-state")
                assert state["sources"][0]["title"] == SOURCE_TITLE, state["sources"]
                assert state["transfer"]["undoAvailable"] is False, state["transfer"]

                # Retained full text is an explicit source choice. A cleanup
                # touches only read, unsaved text and its exact snapshot remains
                # usable after Chromium terminates the service worker while this
                # reader page stays open.
                text_item_id = await seed_text_retention_fixture(first, extension_id, source_id)
                retention = await runtime_message(page, "set-source-text-retention", {
                    "sourceId": source_id, "mode": "summary",
                })
                assert retention["cleanupEligible"] == 1, retention
                pruned = await runtime_message(page, "prune-source-text", {"sourceId": source_id})
                assert len(pruned["changed"]) == 1 and pruned["bytes"] > 0, pruned
                state = await runtime_message(page, "get-state")
                text_item = next(row for row in state["items"] if row["id"] == text_item_id)
                assert text_item["body"] == text_item["summary"], text_item
                assert text_item["bodyIsSummary"] is True and text_item["bodyOmitted"] is True, text_item
                portable_text = json.loads((await runtime_message(page, "export-private-backup"))["raw"])
                exported_text_item = next(row for row in portable_text["state"]["items"] if row["id"] == text_item_id)
                assert exported_text_item["bodyOmitted"] is True, exported_text_item
                assert portable_text["state"]["sources"][0]["textRetention"] == "summary", portable_text["state"]["sources"][0]

                await stop_service_worker(first, extension_id)
                state = await runtime_message(page, "get-state")
                assert next(row for row in state["items"] if row["id"] == text_item_id)["bodyOmitted"] is True
                await runtime_message(page, "undo-source-text-prune", {
                    "sourceId": pruned["sourceId"],
                    "items": pruned["changed"],
                    "expectedRevision": pruned["expectedRevision"],
                })
                restored_text = next(row for row in (await runtime_message(page, "get-state"))["items"] if row["id"] == text_item_id)
                assert 'fuller paragraph retained' in restored_text["body"], restored_text
                assert not restored_text.get("bodyOmitted"), restored_text
                await runtime_message(page, "set-source-text-retention", {"sourceId": source_id, "mode": "full"})

                # Create two local histories for the same reviewed feed address.
                # The selected survivor keeps its current network context; the
                # other history contributes retained reading and organization.
                duplicate_id = await seed_source_repair_fixture(first, extension_id, source_id)

                # The installed reader can open retained feed text without leaving
                # the extension or creating a network request. Escape returns to
                # the exact update action that opened the focused view.
                await page.reload(wait_until="domcontentloaded")
                await page.wait_for_function("() => document.querySelector('#today-summary')?.textContent.includes('unread')")
                await page.locator('[data-filter="all"]').click()
                installed_card = page.locator('.item-card', has_text='Installed retained update').first
                await installed_card.locator('button', has_text='Read here').click()
                await page.wait_for_function("() => document.activeElement?.id === 'detail-heading'")
                assert await page.locator('#detail-heading').inner_text() == 'Installed retained update'
                assert 'second paragraph is available inside ProgRSS' in await page.locator('#detail-body').inner_text()
                assert await page.locator('.bottom-nav').is_hidden()
                await page.keyboard.press('Escape')
                await page.wait_for_function("() => Boolean(document.activeElement?.dataset?.openDetail)")
                assert await page.locator('.bottom-nav').is_visible()

                preview = await runtime_message(page, "preview-source-repair", {
                    "firstSourceId": source_id, "secondSourceId": duplicate_id,
                })
                assert preview["canRepair"] is False, preview
                assert preview["referenceReport"]["summary"]["blockingRecords"] == 1, preview
                report = await runtime_message(page, "source-repair-references", {
                    "firstSourceId": source_id, "secondSourceId": duplicate_id,
                })
                assert report["schema"] == "progrss.source-reference-report.v1", report
                assert report["network"] is False and report["writes"] is False, report
                record = report["groups"][0]["records"][0]
                assert record["title"] == "Installed reviewed garden graft", record
                assert any(row["targetId"] == duplicate_id for row in record["references"]), record

                # The report is vault-derived, not a worker-global snapshot. It
                # remains available after Chromium terminates the worker.
                await stop_service_worker(first, extension_id)
                revived_report = await runtime_message(page, "source-repair-references", {
                    "firstSourceId": source_id, "secondSourceId": duplicate_id,
                })
                assert revived_report["summary"]["blockingRecords"] == 1, revived_report
                revived_record = revived_report["groups"][0]["records"][0]
                assert revived_record["retirement"]["eligible"] is True, revived_record

                retirement_payload = {
                    "firstSourceId": source_id,
                    "secondSourceId": duplicate_id,
                    "recordIndex": revived_record["index"],
                    "recordId": revived_record["recordId"],
                }
                retirement_preview = await runtime_message(page, "preview-graft-receipt-retirement", retirement_payload)
                assert retirement_preview["canRetire"] is True, retirement_preview
                assert retirement_preview["network"] is False, retirement_preview
                assert len(retirement_preview["receipt"]["digest"]) == 64, retirement_preview

                # Commit through a freshly revived worker. The reviewed revision
                # and digest are explicit; no worker-global state authorizes it.
                await stop_service_worker(first, extension_id)
                retired = await runtime_message(page, "retire-graft-receipt", {
                    **retirement_payload,
                    "reviewedRevision": retirement_preview["reviewedRevision"],
                    "expectedDigest": retirement_preview["receipt"]["digest"],
                })
                assert retired["undoAvailable"] is True, retired
                state = await runtime_message(page, "get-state")
                assert state["receiptRetirement"]["undoAvailable"] is True, state["receiptRetirement"]
                retired_export = json.loads((await runtime_message(page, "export-private-backup"))["raw"])
                assert "receiptRetirementUndo" not in retired_export["state"]
                assert len(retired_export["state"]["retiredReceipts"]) == 1, retired_export["state"]

                await stop_service_worker(first, extension_id)
                retired_report = await runtime_message(page, "source-repair-references", {
                    "firstSourceId": source_id, "secondSourceId": duplicate_id,
                })
                assert retired_report["summary"]["blockingRecords"] == 0, retired_report
                assert retired_report["summary"]["retiredRecords"] == 1, retired_report
                assert retired_report["retirementUndo"]["undoAvailable"] is True, retired_report
                await runtime_message(page, "undo-graft-receipt-retirement")
                restored_report = await runtime_message(page, "source-repair-references", {
                    "firstSourceId": source_id, "secondSourceId": duplicate_id,
                })
                assert restored_report["summary"]["blockingRecords"] == 1, restored_report
                assert restored_report["summary"]["retiredRecords"] == 0, restored_report

                # Retire once more so the separate same-source review can proceed.
                restored_record = restored_report["groups"][0]["records"][0]
                retirement_payload = {
                    "firstSourceId": source_id,
                    "secondSourceId": duplicate_id,
                    "recordIndex": restored_record["index"],
                    "recordId": restored_record["recordId"],
                }
                retirement_preview = await runtime_message(page, "preview-graft-receipt-retirement", retirement_payload)
                await runtime_message(page, "retire-graft-receipt", {
                    **retirement_payload,
                    "reviewedRevision": retirement_preview["reviewedRevision"],
                    "expectedDigest": retirement_preview["receipt"]["digest"],
                })

                preview = await runtime_message(page, "preview-source-repair", {
                    "firstSourceId": source_id, "secondSourceId": duplicate_id,
                })
                assert preview["canRepair"] is True, preview
                assert preview["sharedAddresses"] == [SOURCE_URL], preview
                repaired = await runtime_message(page, "repair-same-source", {
                    "firstSourceId": source_id, "secondSourceId": duplicate_id,
                    "survivorId": source_id, "reviewedRevision": preview["reviewedRevision"],
                })
                assert repaired["itemMerge"]["afterCount"] == 2, repaired
                assert repaired["itemMerge"]["exactRepeatsCollapsed"] == 1, repaired
                state = await runtime_message(page, "get-state")
                assert [row["id"] for row in state["sources"]] == [source_id], state["sources"]
                assert state["sourceRepair"]["undoAvailable"] is True, state["sourceRepair"]
                assert state["receiptRetirement"]["undoAvailable"] is False, state["receiptRetirement"]
                survivor = state["sources"][0]
                assert survivor["httpCache"]["etag"] == '"installed-survivor"', survivor
                assert "lastModified" not in survivor["httpCache"], survivor

                await stop_service_worker(first, extension_id)
                state = await runtime_message(page, "get-state")
                assert [row["id"] for row in state["sources"]] == [source_id], state["sources"]
                assert state["sourceRepair"]["undoAvailable"] is True, state["sourceRepair"]
                repair_export = json.loads((await runtime_message(page, "export-private-backup"))["raw"] )
                assert "sourceRepairUndo" not in repair_export["state"]
                assert "receiptRetirementUndo" not in repair_export["state"]
                assert len(repair_export["state"]["retiredReceipts"]) == 1
                await runtime_message(page, "undo-source-repair")
                state = await runtime_message(page, "get-state")
                assert {row["id"] for row in state["sources"]} == {source_id, duplicate_id}, state["sources"]
                assert state["sourceRepair"]["undoAvailable"] is False, state["sourceRepair"]
                await clear_source_repair_fixture(first, extension_id, source_id, duplicate_id)
                state = await runtime_message(page, "get-state")
                assert [row["id"] for row in state["sources"]] == [source_id], state["sources"]

                # The browser-local presence marker is intentionally separate
                # from IndexedDB. Removing only the real vault must therefore
                # look like missing local data, not a brand-new installation.
                loss_backup = await runtime_message(page, "export-private-backup")
                marker = await page.evaluate("chrome.storage.local.get('progrssLibraryPresence')")
                marker = marker.get("progrssLibraryPresence")
                assert marker["schema"] == "progrss.library.presence.v1", marker
                assert marker["hadLibrary"] is True and marker["lastLibrary"]["sources"] == 1, marker
                serialized_marker = json.dumps(marker, ensure_ascii=False)
                assert "https://" not in serialized_marker and SOURCE_TITLE not in serialized_marker, marker

                await stop_service_worker(first, extension_id)
                await delete_extension_vault(page)
                state = await runtime_message(page, "get-state")
                assert state["sources"] == [], state["sources"]
                assert state["libraryRecovery"]["state"] == "missing", state["libraryRecovery"]
                assert state["libraryRecovery"]["lastKnown"]["sources"] == 1, state["libraryRecovery"]

                blocked = await runtime_message_raw(page, "assert-workbench-writable")
                assert blocked.get("ok") is False and blocked.get("code") == "LIBRARY_RECOVERY_REQUIRED", blocked

                await page.reload(wait_until="domcontentloaded")
                await page.wait_for_function("() => document.querySelector('#library-recovery')?.hidden === false")
                recovery_text = await page.locator("#library-recovery").inner_text()
                assert "local library appears missing" in recovery_text.lower(), recovery_text
                assert "last remembered: 1 source" in recovery_text.lower(), recovery_text
                assert await page.locator("#restore-missing-library").is_visible()
                assert await page.locator("#accept-empty-library").is_visible()
                assert await page.locator("#refresh-all").is_disabled()

                # Recovery state is derived again after a real worker death;
                # no service-worker global is being used as the memory.
                await stop_service_worker(first, extension_id)
                revived_loss = await runtime_message(page, "get-state")
                assert revived_loss["libraryRecovery"]["state"] == "missing", revived_loss["libraryRecovery"]

                loss_preview = await runtime_message(page, "preview-private-backup", {"raw": loss_backup["raw"]})
                assert loss_preview["current"]["sources"] == 0, loss_preview
                assert loss_preview["willKeepUndo"] is False, loss_preview
                await runtime_message(page, "restore-private-backup", {
                    "raw": loss_backup["raw"], "reviewedRevision": loss_preview["reviewedRevision"],
                })
                restored_loss = await runtime_message(page, "get-state")
                assert restored_loss["libraryRecovery"]["state"] != "missing", restored_loss["libraryRecovery"]
                assert [row["id"] for row in restored_loss["sources"]] == [source_id], restored_loss["sources"]

                # The alternate decision is explicit and reversible only by a
                # later private-file restore; ProgRSS never reconstructs data
                # from the web or silently replays the failed state.
                await stop_service_worker(first, extension_id)
                await delete_extension_vault(page)
                state = await runtime_message(page, "get-state")
                assert state["libraryRecovery"]["state"] == "missing", state["libraryRecovery"]
                accepted = await runtime_message(page, "accept-empty-library")
                assert accepted["accepted"] is True, accepted
                empty = await runtime_message(page, "get-state")
                assert empty["sources"] == [] and empty["libraryRecovery"]["state"] != "missing", empty
                later_preview = await runtime_message(page, "preview-private-backup", {"raw": loss_backup["raw"]})
                await runtime_message(page, "restore-private-backup", {
                    "raw": loss_backup["raw"], "reviewedRevision": later_preview["reviewedRevision"],
                })
                state = await runtime_message(page, "get-state")
                assert [row["id"] for row in state["sources"]] == [source_id], state["sources"]
            finally:
                await first.close()

            second = await launch(p, profile)
            try:
                page = await open_reader(second, extension_id)
                state = await runtime_message(page, "get-state")
                assert state["vault"]["mode"] == "indexeddb", state["vault"]
                persisted = [row for row in state["sources"] if row.get("url") == SOURCE_URL]
                assert len(persisted) == 1 and persisted[0]["title"] == SOURCE_TITLE, persisted

                # Mutate after restart to prove the revived worker joins the same
                # optimistic-lock revision instead of creating a second silo.
                renamed = SOURCE_TITLE + " — after restart"
                await runtime_message(page, "rename-source", {"sourceId": persisted[0]["id"], "title": renamed})
                state = await runtime_message(page, "get-state")
                assert state["sources"][0]["title"] == renamed
                assert state["sources"][0]["enabled"] is False
                await page.locator("#tab-sources").click()
                await page.wait_for_function("() => document.querySelectorAll('.source-card').length === 1")
                card_text = await page.locator(".source-card").inner_text()
                assert renamed in card_text and "Paused" in card_text
                overflow = await page.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
                assert overflow <= 1, overflow
            finally:
                await second.close()
    except PermissionError as error:
        print(f"SKIP installed Chromium acceptance: {error}", file=sys.stderr)
        print("Run in a developer-enabled Chromium profile or temporarily remove the managed extension blocklist.", file=sys.stderr)
        return 77
    finally:
        if temporary is not None:
            temporary.cleanup()

    print("PASS installed Chromium profile: unpacked MV3 load, IndexedDB, v2-to-v3 private-copy marker migration, prepared-not-checked state, exact current-copy check, explicit missing state across forced worker restart, older-known-copy recognition without restore, reminder pause/re-enable, persistent write-failure recovery, real vault deletion detected from a non-sensitive presence marker, blocked writes, reviewed private-file restore and explicit empty-library acceptance, guarded offline-text cleanup/undo, read-only blocking-reference report, reviewed library transfer, reviewed same-source repair, reports/undos across forced worker restart, browser restart, post-restart mutation")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
