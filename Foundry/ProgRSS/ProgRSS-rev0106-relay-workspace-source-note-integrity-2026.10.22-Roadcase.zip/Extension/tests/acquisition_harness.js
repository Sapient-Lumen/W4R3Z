'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const ROOT = path.resolve(__dirname, '..');

const storage = new Map();
globalThis.localStorage = {
  getItem(key) { return storage.has(key) ? storage.get(key) : null; },
  setItem(key, value) { storage.set(key, String(value)); },
  removeItem(key) { storage.delete(key); }
};

function event() {
  const listeners = new Set();
  return {
    addListener(listener) { listeners.add(listener); },
    removeListener(listener) { listeners.delete(listener); },
    emit(details) { for (const listener of [...listeners]) listener(details); },
    listeners
  };
}

const messageListeners = [];
const permissionRemoved = event();
const beforeRedirect = event();
const headersReceived = event();
const allowedOrigins = new Set([
  'https://old.test', 'https://new.test', 'https://same.test', 'https://temporary.test',
  'https://encoding.test', 'https://slow.test', 'https://hop-old.test', 'https://hop-middle.test', 'https://hop-final.test'
]);

globalThis.chrome = {
  permissions: {
    async contains(query) {
      const origins = Array.isArray(query?.origins) ? query.origins : [];
      return origins.every(pattern => allowedOrigins.has(new URL(pattern.replace(/\*+$/, '')).origin));
    },
    onRemoved: permissionRemoved
  },
  webRequest: {onBeforeRedirect: beforeRedirect, onHeadersReceived: headersReceived},
  runtime: {
    getURL(value) { return `chrome-extension://test/${String(value).replace(/^\//, '')}`; },
    async getContexts() { return []; },
    async sendMessage(message) {
      if (message?.target !== 'offscreen') return undefined;
      if (message.type === 'parse-feed') {
        const title = /New origin/i.test(message.data.body) ? 'New origin' : (/Same destination/i.test(message.data.body) ? 'Same destination' : 'Harness Feed');
        return {ok: true, result: {title, type: 'rss', items: [{key: `${title}-1`, title: `${title} entry`, url: message.data.url, summary: title, published: '2026-10-18T03:00:00.000Z'}]}};
      }
      if (message.type === 'inspect-resource') {
        return {ok: true, result: {kind: 'feed', url: message.data.url, title: 'Inspected', feedType: 'rss', itemCount: 1}};
      }
      if (message.type === 'extract-page') return {ok: true, result: {mode: 'region', content: 'changed'}};
      throw new Error(`unexpected offscreen call ${message.type}`);
    },
    onMessage: {addListener(listener) { messageListeners.push(listener); }},
    onInstalled: {addListener() {}},
    onStartup: {addListener() {}}
  },
  offscreen: {async createDocument() {}},
  action: {async setBadgeBackgroundColor() {}, async setBadgeText() {}, async setTitle() {}},
  sidePanel: {async setPanelBehavior() {}},
  alarms: {async create() {}, onAlarm: {addListener() {}}},
  tabs: {async query() { return []; }},
  scripting: {async executeScript() { return []; }}
};

globalThis.importScripts = (...files) => {
  for (const file of files) vm.runInThisContext(fs.readFileSync(path.join(ROOT, file), 'utf8'), {filename: file});
};

const fetchCalls = [];
let mode = 'normal';
let slowStarted = null;
function rss(title) {
  return `<?xml version="1.0"?><rss version="2.0"><channel><title>${title}</title><item><guid>${title}-1</guid><title>${title} entry</title></item></channel></rss>`;
}
function redirect(url, target, status) {
  const details = {url, redirectUrl: target, statusCode: status, type: 'xmlhttprequest'};
  headersReceived.emit({...details, responseHeaders: [{name: 'Location', value: target}]});
  beforeRedirect.emit(details);
  throw new TypeError('Failed to fetch');
}

globalThis.fetch = async (raw, options = {}) => {
  const url = String(raw);
  fetchCalls.push({url, headers: {...(options.headers || {})}});
  if (mode === 'cross' && url === 'https://old.test/feed.xml') return redirect(url, 'https://new.test/feed.xml', 301);
  if (mode === 'cross-throttle' && url === 'https://old.test/deferred.xml') return redirect(url, 'https://new.test/deferred.xml', 301);
  if (mode === 'cross-throttle' && url === 'https://new.test/deferred.xml') return new Response('', {status: 503, headers: {'Retry-After': '60'}});
  if (mode === 'same-permanent' && url === 'https://same.test/old.xml') return redirect(url, 'https://same.test/new.xml', 301);
  if (mode === 'same-temporary' && url === 'https://temporary.test/old.xml') return redirect(url, 'https://temporary.test/new.xml', 302);
  if ((mode === 'hop-first' || mode === 'hop-second') && url === 'https://hop-old.test/feed.xml') return redirect(url, 'https://hop-middle.test/feed.xml', 301);
  if (mode === 'hop-second' && url === 'https://hop-middle.test/feed.xml') return redirect(url, 'https://hop-final.test/feed.xml', 302);
  if (mode === 'hop-final' && url === 'https://hop-middle.test/feed.xml') return redirect(url, 'https://hop-final.test/feed.xml', 302);
  if (mode === 'loop' && url === 'https://same.test/loop-a') return redirect(url, 'https://same.test/loop-b', 302);
  if (mode === 'loop' && url === 'https://same.test/loop-b') return redirect(url, 'https://same.test/loop-a', 302);
  if (mode === 'slow' && url === 'https://slow.test/feed.xml') {
    let controller;
    const stream = new ReadableStream({
      start(value) {
        controller = value;
        value.enqueue(new TextEncoder().encode('<rss><channel><title>Slow'));
        slowStarted?.();
      }
    });
    options.signal.addEventListener('abort', () => controller.error(new DOMException('Aborted', 'AbortError')), {once: true});
    return new Response(stream, {status: 200, headers: {'Content-Type': 'application/rss+xml'}});
  }
  if (url === 'https://encoding.test/cp1252') {
    return new Response(Uint8Array.from([0x63, 0x61, 0x66, 0xe9]), {status: 200, headers: {'Content-Type': 'text/plain; charset=windows-1252'}});
  }
  if (url === 'https://encoding.test/utf16') {
    const text = '<?xml version="1.0" encoding="utf-16"?><rss><channel><title>Snow ☃</title></channel></rss>';
    const bytes = new Uint8Array(2 + text.length * 2);
    bytes[0] = 0xff; bytes[1] = 0xfe;
    for (let i = 0; i < text.length; i++) { bytes[2 + i * 2] = text.charCodeAt(i) & 0xff; bytes[3 + i * 2] = text.charCodeAt(i) >> 8; }
    return new Response(bytes, {status: 200, headers: {'Content-Type': 'application/rss+xml'}});
  }
  if (url === 'https://encoding.test/unsupported') {
    return new Response('hello', {status: 200, headers: {'Content-Type': 'text/plain; charset=koi8-r'}});
  }
  if (url === 'https://encoding.test/invalid') {
    return new Response(Uint8Array.from([0xc3, 0x28]), {status: 200, headers: {'Content-Type': 'text/plain; charset=utf-8'}});
  }
  const title = url.startsWith('https://new.test') ? 'New origin' : (url.endsWith('/new.xml') ? 'Same destination' : 'Harness Feed');
  const headers = {'Content-Type': 'application/rss+xml; charset=utf-8', 'ETag': url.startsWith('https://new.test') ? '"new-v1"' : '"old-v1"'};
  return new Response(rss(title), {status: 200, headers});
};

vm.runInThisContext(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8'), {filename: 'background.js'});
assert.strictEqual(messageListeners.length, 1);
const listener = messageListeners[0];
function message(type, data = {}) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`timeout: ${type}`)), 4000);
    const keep = listener({target: 'background', type, data}, {}, response => { clearTimeout(timer); resolve(response); });
    assert.strictEqual(keep, true);
  });
}

async function add(url, title) {
  const response = await message('add-source', {url, title, type: 'rss'});
  assert.strictEqual(response.ok, true, JSON.stringify(response));
  return response.result.source.id;
}

(async () => {
  const oldId = await add('https://old.test/feed.xml', 'Old source');
  let response = await message('refresh-source', {sourceId: oldId});
  assert.strictEqual(response.ok, true);
  mode = 'cross';
  fetchCalls.length = 0;
  response = await message('refresh-source', {sourceId: oldId});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'CROSS_ORIGIN_REDIRECT');
  assert.strictEqual(response.detail.to, 'https://new.test/feed.xml');
  assert.deepStrictEqual(fetchCalls.map(row => row.url), ['https://old.test/feed.xml']);
  response = await message('get-state');
  let old = response.result.sources.find(row => row.id === oldId);
  assert.strictEqual(old.pendingRedirect.destinationHost, 'new.test');
  assert.strictEqual(old.url, 'https://old.test/feed.xml');

  fetchCalls.length = 0;
  response = await message('accept-source-redirect', {sourceId: oldId, from: 'https://old.test/feed.xml', to: 'https://new.test/feed.xml'});
  assert.strictEqual(response.ok, true, JSON.stringify(response));
  assert.strictEqual(response.result.moved, true);
  assert.deepStrictEqual(fetchCalls.map(row => row.url), ['https://old.test/feed.xml', 'https://new.test/feed.xml']);
  assert.strictEqual(fetchCalls[0].headers['If-None-Match'], '"old-v1"');
  assert.strictEqual(fetchCalls[1].headers['If-None-Match'], undefined, 'old-origin validator leaked to new origin');
  response = await message('get-state');
  old = response.result.sources.find(row => row.id === oldId);
  assert.strictEqual(old.url, 'https://new.test/feed.xml');
  assert.deepStrictEqual(old.previousUrls, ['https://old.test/feed.xml']);
  assert.strictEqual(old.httpCache.etag, '"new-v1"');
  assert.strictEqual(old.pendingRedirect, undefined);

  const movedRepairState = await globalThis.ProgRSSVault.init();
  movedRepairState.sources.push({
    id: 'moved-history-copy', title: 'Old-origin history copy', type: 'rss',
    url: 'https://old.test/feed.xml', enabled: false, archivedAt: ''
  });
  await globalThis.ProgRSSVault.save(movedRepairState);
  response = await message('preview-source-repair', {firstSourceId: oldId, secondSourceId: 'moved-history-copy'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.canRepair, true);
  assert.deepStrictEqual(response.result.sharedAddresses, ['https://old.test/feed.xml']);
  const movedRepairCleanup = await globalThis.ProgRSSVault.init();
  movedRepairCleanup.sources = movedRepairCleanup.sources.filter(source => source.id !== 'moved-history-copy');
  await globalThis.ProgRSSVault.save(movedRepairCleanup);

  mode = 'normal';
  const deferredId = await add('https://old.test/deferred.xml', 'Temporarily unavailable move');
  mode = 'cross-throttle';
  response = await message('refresh-source', {sourceId: deferredId});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'CROSS_ORIGIN_REDIRECT');
  response = await message('accept-source-redirect', {sourceId: deferredId, from: 'https://old.test/deferred.xml', to: 'https://new.test/deferred.xml'});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'REDIRECT_DESTINATION_UNAVAILABLE');
  response = await message('get-state');
  const deferred = response.result.sources.find(row => row.id === deferredId);
  assert.strictEqual(deferred.url, 'https://old.test/deferred.xml', 'unverified destination must not replace the followed address');
  assert.strictEqual(deferred.pendingRedirect.to, 'https://new.test/deferred.xml');
  assert.strictEqual(deferred.lastOutcome, 'throttled');

  mode = 'same-permanent';
  const permanentId = await add('https://same.test/old.xml', 'Permanent same-site');
  response = await message('refresh-source', {sourceId: permanentId});
  assert.strictEqual(response.ok, true, JSON.stringify(response));
  response = await message('get-state');
  const permanent = response.result.sources.find(row => row.id === permanentId);
  assert.strictEqual(permanent.url, 'https://same.test/new.xml');
  assert.deepStrictEqual(permanent.previousUrls, ['https://same.test/old.xml']);
  assert.strictEqual(permanent.lastRedirects.length, 1);

  mode = 'same-temporary';
  const temporaryId = await add('https://temporary.test/old.xml', 'Temporary same-site');
  response = await message('refresh-source', {sourceId: temporaryId});
  assert.strictEqual(response.ok, true, JSON.stringify(response));
  response = await message('get-state');
  const temporary = response.result.sources.find(row => row.id === temporaryId);
  assert.strictEqual(temporary.url, 'https://temporary.test/old.xml', 'temporary redirect must not rewrite the followed address');
  assert.strictEqual(temporary.lastResolvedUrl, 'https://temporary.test/new.xml');

  mode = 'normal';
  const hopId = await add('https://hop-old.test/feed.xml', 'Two-crossing source');
  response = await message('refresh-source', {sourceId: hopId});
  assert.strictEqual(response.ok, true);
  mode = 'hop-first';
  response = await message('refresh-source', {sourceId: hopId});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'CROSS_ORIGIN_REDIRECT');
  mode = 'hop-second';
  response = await message('accept-source-redirect', {sourceId: hopId, from: 'https://hop-old.test/feed.xml', to: 'https://hop-middle.test/feed.xml'});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'CROSS_ORIGIN_REDIRECT');
  response = await message('get-state');
  let hopping = response.result.sources.find(row => row.id === hopId);
  assert.strictEqual(hopping.url, 'https://hop-middle.test/feed.xml');
  assert.strictEqual(hopping.pendingRedirect.from, 'https://hop-middle.test/feed.xml');
  assert.strictEqual(hopping.pendingRedirect.to, 'https://hop-final.test/feed.xml');
  assert.deepStrictEqual(hopping.previousUrls, ['https://hop-old.test/feed.xml']);
  mode = 'hop-final';
  response = await message('accept-source-redirect', {sourceId: hopId, from: 'https://hop-middle.test/feed.xml', to: 'https://hop-final.test/feed.xml'});
  assert.strictEqual(response.ok, true, JSON.stringify(response));
  response = await message('get-state');
  hopping = response.result.sources.find(row => row.id === hopId);
  assert.strictEqual(hopping.url, 'https://hop-final.test/feed.xml');
  assert.deepStrictEqual(hopping.previousUrls, ['https://hop-old.test/feed.xml', 'https://hop-middle.test/feed.xml']);
  assert.strictEqual(hopping.pendingRedirect, undefined);

  mode = 'loop';
  response = await message('fetch-resource', {url: 'https://same.test/loop-a'});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'REDIRECT_LOOP');

  mode = 'encoding';
  response = await message('fetch-resource', {url: 'https://encoding.test/cp1252'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.body, 'café');
  assert.strictEqual(response.result.encoding, 'windows-1252');
  response = await message('fetch-resource', {url: 'https://encoding.test/utf16'});
  assert.strictEqual(response.ok, true);
  assert.match(response.result.body, /Snow ☃/);
  assert.strictEqual(response.result.encoding, 'utf-16le');
  response = await message('fetch-resource', {url: 'https://encoding.test/unsupported'});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'UNSUPPORTED_ENCODING');
  response = await message('fetch-resource', {url: 'https://encoding.test/invalid'});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'INVALID_ENCODING');

  mode = 'normal';
  const slowId = await add('https://slow.test/feed.xml', 'Slow source');
  mode = 'slow';
  const started = new Promise(resolve => { slowStarted = resolve; });
  const inFlight = message('refresh-source', {sourceId: slowId});
  await started;
  allowedOrigins.delete('https://slow.test');
  permissionRemoved.emit({origins: ['https://slow.test/*']});
  response = await inFlight;
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'PERMISSION_REMOVED');
  await new Promise(resolve => setTimeout(resolve, 25));
  response = await message('get-state');
  const slow = response.result.sources.find(row => row.id === slowId);
  assert.strictEqual(slow.permissionMissing, true);
  assert.strictEqual(slow.lastOutcome, 'permission');
  assert.match(slow.lastProblem, /access was removed/i);
  response = await message('refresh-source', {sourceId: slowId});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'PERMISSION_REQUIRED');

  console.log('PASS acquisition harness: same-site redirects, single/multi-hop cross-site review, unavailable-destination retention, validator isolation, redirect loops, encodings, active permission removal');
})().catch(error => {
  console.error(error.stack || error);
  process.exitCode = 1;
});
