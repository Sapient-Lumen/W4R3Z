'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');

const sourceRoot = path.resolve(__dirname, '..');
const root = process.env.PROGRSS_EXTENSION_ROOT
  ? path.resolve(sourceRoot, process.env.PROGRSS_EXTENSION_ROOT)
  : sourceRoot;
const runtimeLabel = process.env.PROGRSS_EXTENSION_ROOT || 'Chromium source';
const context = {
  console,
  URL,
  TextEncoder,
  TextDecoder,
  crypto: require('crypto').webcrypto,
  structuredClone: global.structuredClone,
  atob: value => Buffer.from(value, 'base64').toString('binary'),
  btoa: value => Buffer.from(value, 'binary').toString('base64')
};
context.globalThis = context;
context.window = context;
context.self = context;
vm.createContext(context);
vm.runInContext(fs.readFileSync(path.join(root, 'shared', 'core.js'), 'utf8'), context, {filename: 'core.js'});
vm.runInContext(fs.readFileSync(path.join(root, 'shared', 'shared-folder.js'), 'utf8'), context, {filename: 'shared-folder.js'});
const C = context.ProgRSSCore;
const F = context.ProgRSSSharedFolder;
assert(C && F, 'shared browser entry points load');

const state = {
  sources: [{
    id: 'source_one', type: 'rss', title: 'Source one',
    url: 'https://notes.example/feed.xml', enabled: true
  }],
  collections: [
    {
      id: 'route_root', title: 'Route', mode: 'union', members: [
        {kind: 'source', id: 'source_one', reason: '  Root reason.\n'},
        {kind: 'collection', id: 'route_child'}
      ]
    },
    {
      id: 'route_child', title: 'Child', mode: 'union', members: [
        {kind: 'source', id: 'source_one', reason: 'Child reason.'}
      ]
    }
  ],
  items: []
};

assert.strictEqual(C.normalizeSourceNoteReason(' \tReason.\n'), 'Reason.');
assert.strictEqual(C.normalizeSourceNoteReason(' \t\n'), undefined);
assert.strictEqual(C.normalizeSourceNoteReason('😀'.repeat(280)), '😀'.repeat(280));
assert.throws(() => C.normalizeSourceNoteReason('😀'.repeat(281)), /280 Unicode code points/);
assert.throws(() => C.normalizeSourceNoteReason('\ud800'), /Unicode scalar/);
assert.throws(() => C.cleanCollection({
  id: 'folder', title: 'Folder', members: [{kind: 'collection', id: 'child', reason: 'Not allowed'}]
}), /direct source placement/);
assert.throws(() => C.cleanCollection({
  id: 'folder', title: 'Folder', reason: 'Not allowed', members: []
}), /not to a folder/);
assert.throws(() => C.cleanCollection({
  id: 'folder', title: 'Folder', members: [
    {kind: 'source', id: 'source_one', reason: 'First'},
    {kind: 'source', id: 'source_one', reason: 'Second'}
  ]
}), /Conflicting Source Notes/);
const identical = C.cleanCollection({
  id: 'folder', title: 'Folder', members: [
    {kind: 'source', id: 'source_one', reason: 'Same'},
    {kind: 'source', id: 'source_one', reason: 'Same'}
  ]
});
assert.strictEqual(identical.members.length, 1, 'identical duplicate placement is canonicalized once');

const bundle = C.exportBundle(state, 'route_root');
const rootFolder = bundle.collections.find(row => row.id === 'route_root');
const childFolder = bundle.collections.find(row => row.id === 'route_child');
assert.strictEqual(rootFolder.members.find(row => row.kind === 'source').reason, 'Root reason.');
assert.strictEqual(childFolder.members.find(row => row.kind === 'source').reason, 'Child reason.');
const checked = C.validateBundle(bundle);
assert.strictEqual(checked.collections.find(row => row.id === 'route_root').members[0].reason, 'Root reason.');

const contents = F.contents(bundle);
assert.strictEqual(contents.sourceNoteCount, 2);
assert.strictEqual(contents.sources[0].sourceNoteCount, 2);
assert.deepStrictEqual(
  Array.from(contents.sources[0].placements, row => [row.folderId, row.reason]),
  [['route_root', 'Root reason.'], ['route_child', 'Child reason.']]
);
assert.strictEqual(contents.folders.find(row => row.id === 'route_root').directSourceNotes, 1);
assert.strictEqual(contents.folders.find(row => row.id === 'route_child').directSourceNotes, 1);

const branch = F.branch(bundle, 'route_child');
assert.strictEqual(branch.root, 'route_child');
assert.strictEqual(branch.collections.length, 1);
assert.strictEqual(branch.collections[0].members[0].reason, 'Child reason.');
assert(!JSON.stringify(branch).includes('Root reason.'), 'out-of-branch reason is omitted');

const preview = C.importPreview(bundle, {
  sources: [{id: 'source_one'}],
  collections: [{id: 'route_root'}, {id: 'route_child'}]
});
const previewRoot = preview.collections.find(row => row.title === 'Route');
const previewChild = preview.collections.find(row => row.title === 'Child');
assert.strictEqual(previewRoot.members.find(row => row.kind === 'source').reason, 'Root reason.');
assert.strictEqual(previewChild.members.find(row => row.kind === 'source').reason, 'Child reason.');
assert.notStrictEqual(previewRoot.members.find(row => row.kind === 'source').id, 'source_one', 'import remaps the source identity while preserving the relationship field');

const opml = C.makeOPML(state);
assert(!opml.includes('Root reason.') && !opml.includes('Child reason.'), 'generic OPML omits Source Notes');
assert(!/\breason=/.test(opml), 'generic OPML invents no Source Notes attribute');

(async () => {
  const native = await F.create(bundle, {
    curator: 'Route desk',
    note: 'A reviewed route.',
    exportedAt: '2026-10-21T01:00:00.000Z'
  });
  const verified = await F.validate(native);
  assert.strictEqual(verified.bundle.collections.find(row => row.id === 'route_root').members[0].reason, 'Root reason.');
  assert.strictEqual(verified.bundle.collections.find(row => row.id === 'route_child').members[0].reason, 'Child reason.');
  const tampered = structuredClone(native);
  tampered.collections.find(row => row.id === 'route_root').members[0].reason = 'Changed after integrity was recorded.';
  await assert.rejects(() => F.validate(tampered), /digest does not match/, 'a Source Note mutation invalidates the native artifact digest');
  console.log(`PASS Source Notes browser entrypoint harness (${runtimeLabel}): schema, canonicalization, integrity, disclosure, branch, import, and OPML omission`);
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
