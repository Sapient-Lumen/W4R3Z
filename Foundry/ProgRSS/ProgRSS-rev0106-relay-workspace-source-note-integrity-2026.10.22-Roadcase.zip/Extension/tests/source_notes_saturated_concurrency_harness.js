// Managed production-handler tests with in-memory browser API doubles. Not an installed-browser run.
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const ROOT = path.resolve(__dirname, '..', process.env.PROGRSS_EXTENSION_ROOT || '.');
const FAMILY = process.env.PROGRSS_EXTENSION_ROOT === 'Firefox' ? 'generated-Firefox' : 'Chromium-source';

const storage = new Map();
const extensionStorage = new Map();
let failVaultWrites = false;
let pageExtractContent = 'Library opens Monday at 9.';
let pageExtractErrorCode = '';
let pageRepairVariant = 0;
globalThis.localStorage = {
  getItem(key) { return storage.has(key) ? storage.get(key) : null; },
  setItem(key, value) {
    if (failVaultWrites) {
      const error = Error('quota exceeded while writing the test vault');
      error.name = 'QuotaExceededError';
      throw error;
    }
    storage.set(key, String(value));
  },
  removeItem(key) { storage.delete(key); }
};

const messageListeners = [];
const alarms = [];
globalThis.chrome = {
  storage: {
    local: {
      async get(key) {
        if (key == null) return Object.fromEntries(extensionStorage);
        const keys = Array.isArray(key) ? key : [key];
        return Object.fromEntries(keys.filter(value => extensionStorage.has(value)).map(value => [value, extensionStorage.get(value)]));
      },
      async set(values) { for (const [key, value] of Object.entries(values || {})) extensionStorage.set(key, value); },
      async remove(key) { for (const value of (Array.isArray(key) ? key : [key])) extensionStorage.delete(value); }
    }
  },
  permissions: {
    async contains() { return true; },
    async getAll() { return {permissions: [], origins: ['https://example.test/*']}; }
  },
  runtime: {
    getURL(value) { return `chrome-extension://test/${value}`; },
    getManifest() { return {version: '0.80.0'}; },
    async getContexts() { return []; },
    async sendMessage(message) {
      if (message?.target === 'offscreen') {
        if (message.type === 'parse-feed') {
          return {ok: true, result: {
            title: 'Harness Feed', titleLanguage: 'en-GB', language: 'en-GB', type: 'rss', feedUrl: 'https://example.test/feed.xml', items: [
              {key: 'entry-1', title: 'A new entry', url: 'https://example.test/post/1', summary: 'ملخص الاختبار', body: 'نص الاختبار\n\nفقرة ثانية محفوظة.', bodyIsSummary: false, language: 'AR', titleLanguage: 'EN', summaryLanguage: 'AR', bodyLanguage: 'AR', published: '2026-10-17T12:00:00.000Z'}
            ]
          }};
        }
        if (message.type === 'parse-opml') {
          return {ok: true, result: {
            title: 'Harness subscriptions', feedOutlines: 4, invalidCount: 1, duplicateCount: 1, truncatedCount: 0, folderCount: 2,
            feeds: [
              {title: 'Harness Feed', url: 'https://example.test/feed.xml', folderPaths: [['Reading']]},
              {title: 'Independent Notes', url: 'https://new.test/feed.xml', folderPaths: [['Reading', 'Independent']]},
              {title: 'Other Notes', url: 'https://other.test/atom.xml', folderPaths: [['Reading']]}
            ]
          }};
        }
        if (message.type === 'inspect-resource') return {ok: true, result: {kind: 'feed', url: message.data.url, title: 'Harness Feed', titleLanguage: 'en-GB', language: 'en-GB', feedType: 'rss', feedUrl: 'https://example.test/feed.xml', itemCount: 1, previewCount: 1, previewFullTextCount: 1, previewSummaryCount: 0, previewDatedCount: 1, previewItems: [{title: 'A new entry', url: 'https://example.test/post/1', published: '2026-10-17T12:00:00.000Z', content: 'full-text', language: 'ar', titleLanguage: 'en'}]}};
        if (message.type === 'extract-page') {
          if (pageExtractErrorCode) return {ok: false, error: 'The watched section is missing.', code: pageExtractErrorCode, detail: {field: 'selector'}};
          return {ok: true, result: {mode: 'region', content: pageExtractContent, matchCount: 1, meaningfulCount: 1, contentChars: pageExtractContent.length}};
        }
        if (message.type === 'repair-page-watch') {
          const content = pageRepairVariant ? `${pageExtractContent} changed after review` : pageExtractContent;
          return {ok: true, result: [{
            schema: 'progrss.page-watch.repair.v1', title: 'Watch the page’s main text',
            description: 'Notice meaningful wording changes in the main part of the page.',
            mode: 'region', count: 1, examples: [], preview: content,
            recipe: {mode: 'region', selector: 'main', titleSelector: '', linkSelector: '', threshold: 4, ignoreNumbers: false},
            evidence: {signature: `region:${content}`, matchCount: 1, contentChars: content.length},
            capture: {mode: 'region', content, matchCount: 1, meaningfulCount: 1, contentChars: content.length}
          }]};
        }
      }
      return undefined;
    },
    onMessage: { addListener(listener) { messageListeners.push(listener); } },
    onInstalled: { addListener() {} },
    onStartup: { addListener() {} }
  },
  offscreen: { async createDocument() {} },
  action: {
    async setBadgeBackgroundColor() {}, async setBadgeText() {}, async setTitle() {}
  },
  sidePanel: { async setPanelBehavior() {} },
  alarms: { async create(name, details) { alarms.push({name, details}); }, onAlarm: { addListener() {} } },
  tabs: { async query() { return [{id: 1, url: 'https://example.test/', title: 'Example'}]; } },
  scripting: { async executeScript() { return [{result: {url: 'https://example.test/', title: 'Example', links: []}}]; } }
};

let fetchMode = 'normal';
let publicationPayload = '';
let publicationContentType = 'application/vnd.progrss.shared-folder+json; charset=utf-8';
const fetchCalls = [];
globalThis.fetch = async (url, options) => {
  fetchCalls.push({url: String(url), options});
  if (fetchMode === 'large') {
    return new Response('too large', {status: 200, headers: {'Content-Type': 'application/rss+xml', 'Content-Length': '2000001'}});
  }
  if (fetchMode === 'page') {
    return new Response(`<html><body><main>${pageExtractContent}</main></body></html>`, {
      status: 200, headers: {'Content-Type': 'text/html; charset=utf-8'}
    });
  }
  if (fetchMode === 'publication') {
    return new Response(publicationPayload, {
      status: 200, headers: {'Content-Type': publicationContentType, 'Content-Length': String(Buffer.byteLength(publicationPayload))}
    });
  }
  if (options?.headers?.['If-None-Match'] === '"harness-v1"') {
    return new Response(null, {status: 304, headers: {'ETag': '"harness-v1"', 'Last-Modified': 'Fri, 17 Oct 2026 12:00:00 GMT'}});
  }
  return new Response(
    '<rss><channel><title>Harness Feed</title><item><guid>entry-1</guid><title>A new entry</title></item></channel></rss>',
    {status: 200, headers: {'Content-Type': 'application/rss+xml', 'Content-Length': '120', 'ETag': '"harness-v1"', 'Last-Modified': 'Fri, 17 Oct 2026 12:00:00 GMT'}}
  );
};

globalThis.importScripts = (...files) => {
  for (const file of files) {
    const code = fs.readFileSync(path.join(ROOT, file), 'utf8');
    vm.runInThisContext(code, {filename: file});
  }
};

if (FAMILY === 'generated-Firefox') {
  globalThis.browser = globalThis.chrome;
  browser.runtime.getURL = value => `moz-extension://test/${String(value).replace(/^\//, '')}`;
  browser.sidebarAction = {async open() {}};
  browser.action.onClicked = {addListener() {}};
  delete browser.sidePanel;
  delete browser.offscreen;
}
vm.runInThisContext(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8'), {filename: 'background.js'});
assert.strictEqual(messageListeners.length, 1, 'background message listener registered');
const listener = messageListeners[0];

function setBackupReminderFixture(marker) {
  extensionStorage.set('progrssBackupReminder', marker);
  vm.runInThisContext(`volatileBackupReminder = ${JSON.stringify(marker)};`);
}

function message(type, data = {}) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timeout = setTimeout(() => { if (!settled) reject(new Error(`timeout: ${type}`)); }, 1500);
    const keep = listener({target: 'background', type, data}, {}, response => {
      settled = true;
      clearTimeout(timeout);
      resolve(response);
    });
    assert.strictEqual(keep, true, `${type} keeps response channel open`);
  });
}


const cases = [];
function test(name, fn) { cases.push([name, fn]); }
const snapshot = async () => JSON.stringify(await ProgRSSVault.init());
async function fixture(reason = 'Direct reason.', version = 1) {
  await message('get-state');
  const state = await ProgRSSVault.init();
  const member = {kind: 'source', id: 'one'};
  if (reason !== undefined) member.reason = reason;
  state.sources = ['one', 'two', 'three'].map(id => ({
    id, title: id, type: 'rss', url: `https://notes.example/${id}.xml`, enabled: false
  }));
  state.items = [];
  state.collections = [
    {id: 'parent', title: 'Parent', mode: 'union', version, members: [
      {kind: 'source', id: 'two'}, member, {kind: 'collection', id: 'child'}, {kind: 'source', id: 'three'}
    ]},
    {id: 'child', title: 'Child', mode: 'union', version: 1, members: [
      {kind: 'source', id: 'one', reason: 'Child reason.'}
    ]},
    {id: 'other', title: 'Other', mode: 'union', version: 1, members: [
      {kind: 'source', id: 'one', reason: 'Other reason.'}
    ]}
  ];
  await ProgRSSVault.save(state);
  return ProgRSSVault.init();
}
const folder = (state, id='parent') => state.collections.find(c => c.id === id);
async function removalReview(collectionId='parent', sourceId='one') {
  const state = await ProgRSSVault.init();
  const target = folder(state, collectionId);
  const matches = (target?.members || []).filter(member => member?.kind === 'source' && member.id === sourceId);
  assert.strictEqual(matches.length, 1, 'reviewed removal needs one direct placement');
  const member = matches[0];
  return {
    sourceId, collectionId,
    expectedVersion: Math.max(1, Math.round(Number(target.version) || 1)),
    expectedRevision: state._revision,
    expectedReason: Object.hasOwn(member, 'reason') ? member.reason : null
  };
}
async function remove(collectionId='parent', sourceId='one') {
  const response = await message('remove-source-from-folder', await removalReview(collectionId, sourceId));
  assert.strictEqual(response.ok, true, response.error);
  assert.strictEqual(response.result.removed, true);
  return response.result;
}
function undoPayload(removed) {
  return {sourceId: removed.sourceId, collectionId: removed.collectionId,
    expectedVersion: removed.folderVersion, expectedRevision: removed.expectedRevision,
    removedMember: removed.removedMember, removedIndex: removed.removedIndex};
}
async function undo(removed) {
  const response = await message('undo-source-folder-remove', undoPayload(removed));
  assert.strictEqual(response.ok, true, response.error);
  assert.strictEqual(response.result.added, true);
  return ProgRSSVault.init();
}
async function refuse(payload, code) {
  const before = await snapshot();
  const response = await message('undo-source-folder-remove', payload);
  assert.strictEqual(response.ok, false, 'invalid or stale undo must be refused');
  assert.strictEqual(response.code, code);
  assert.strictEqual(await snapshot(), before, 'refusal must not alter persisted state');
}


async function setReason(data) {
  const response = await message('set-source-placement-reason', data);
  return response;
}
async function expectRefusal(type, data, code) {
  const before = await snapshot();
  const response = await message(type, data);
  assert.strictEqual(response.ok, false, `${type} must refuse stale or incomplete review`);
  assert.strictEqual(response.code, code, response.error);
  assert.strictEqual(await snapshot(), before, 'refusal must not alter persisted state');
  return response;
}
async function setOtherFolderAtCap(reason) {
  await fixture('Parent reason.', 1);
  const state = await ProgRSSVault.init();
  const target = folder(state, 'other');
  target.version = 10000;
  target.members[0].reason = reason;
  await ProgRSSVault.save(state);
  return ProgRSSVault.init();
}
async function replaceOtherPlacement(reason) {
  let response = await message('remove-source-from-folder', await removalReview('other', 'one'));
  assert(response.ok && response.result.removed, response.error);
  response = await message('add-source-to-folder', {sourceId:'one', collectionId:'other'});
  assert(response.ok && response.result.added, response.error);
  const current = await ProgRSSVault.init();
  response = await setReason({
    sourceId:'one', collectionId:'other', expectedVersion:10000,
    expectedRevision:current._revision, expectedReason:null, reason
  });
  assert(response.ok && response.result.changed, response.error);
  return response.result;
}

test('public state exposes the exact vault revision used for ceiling review', async () => {
  await fixture('Reviewed reason.', 10000);
  const persisted = await ProgRSSVault.init();
  const response = await message('get-state');
  assert(response.ok, response.error);
  assert.strictEqual(response.result.revision, persisted._revision);
  assert(Number.isSafeInteger(response.result.revision));
});

test('exact save at the folder-version ceiling returns the committed vault revision', async () => {
  await fixture('Reviewed reason.', 10000);
  const before = await ProgRSSVault.init();
  const response = await setReason({
    sourceId:'one', collectionId:'parent', expectedVersion:10000,
    expectedRevision:before._revision, expectedReason:'Reviewed reason.', reason:'Saved at ceiling.'
  });
  assert(response.ok && response.result.changed, response.error);
  const after = await ProgRSSVault.init();
  assert.strictEqual(response.result.expectedRevision, after._revision);
  assert.strictEqual(folder(after).members[1].reason, 'Saved at ceiling.');
});

test('missing or wrong save revision is refused at the ceiling', async () => {
  await fixture('Reviewed reason.', 10000);
  const state = await ProgRSSVault.init();
  const common = {sourceId:'one', collectionId:'parent', expectedVersion:10000,
    expectedReason:'Reviewed reason.', reason:'Should not save.'};
  await expectRefusal('set-source-placement-reason', common, 'STALE_SOURCE_NOTE');
  await expectRefusal('set-source-placement-reason', {...common, expectedRevision:state._revision - 1}, 'STALE_SOURCE_NOTE');
});

test('stale editor cannot mutate a removed-and-recreated placement at the ceiling', async () => {
  const reviewed = await setOtherFolderAtCap('Reviewed reason.');
  await replaceOtherPlacement('Reviewed reason.');
  await expectRefusal('set-source-placement-reason', {
    sourceId:'one', collectionId:'other', expectedVersion:10000,
    expectedRevision:reviewed._revision,
    expectedReason:'Reviewed reason.', reason:'Stale editor value.'
  }, 'STALE_SOURCE_NOTE');
  assert.strictEqual(folder(await ProgRSSVault.init(), 'other').members[0].reason, 'Reviewed reason.');
});

test('stale undo cannot mutate a removed-and-recreated placement at the ceiling', async () => {
  const before = await setOtherFolderAtCap('Before edit.');
  let response = await setReason({
    sourceId:'one', collectionId:'other', expectedVersion:10000,
    expectedRevision:before._revision, expectedReason:'Before edit.', reason:'Edited value.'
  });
  assert(response.ok && response.result.changed, response.error);
  const undoRevision = response.result.expectedRevision;
  await replaceOtherPlacement('Edited value.');
  await expectRefusal('undo-source-placement-reason', {
    sourceId:'one', collectionId:'other', expectedVersion:10000,
    expectedRevision:undoRevision,
    expectedCurrentReason:'Edited value.', previousReason:'Before edit.'
  }, 'STALE_SOURCE_NOTE_UNDO');
  assert.strictEqual(folder(await ProgRSSVault.init(), 'other').members[0].reason, 'Edited value.');
});

test('exact guarded undo still succeeds at the ceiling', async () => {
  const before = await setOtherFolderAtCap('Before edit.');
  let response = await setReason({
    sourceId:'one', collectionId:'other', expectedVersion:10000,
    expectedRevision:before._revision, expectedReason:'Before edit.', reason:'Edited value.'
  });
  assert(response.ok && response.result.changed, response.error);
  response = await message('undo-source-placement-reason', {
    sourceId:'one', collectionId:'other', expectedVersion:10000,
    expectedRevision:response.result.expectedRevision,
    expectedCurrentReason:'Edited value.', previousReason:'Before edit.'
  });
  assert(response.ok && response.result.restored, response.error);
  assert.strictEqual(folder(await ProgRSSVault.init(), 'other').members[0].reason, 'Before edit.');
});

test('missing or wrong undo revision is refused at the ceiling', async () => {
  const before = await setOtherFolderAtCap('Before edit.');
  let response = await setReason({
    sourceId:'one', collectionId:'other', expectedVersion:10000,
    expectedRevision:before._revision, expectedReason:'Before edit.', reason:'Edited value.'
  });
  assert(response.ok && response.result.changed, response.error);
  const common = {sourceId:'one', collectionId:'other', expectedVersion:10000,
    expectedCurrentReason:'Edited value.', previousReason:'Before edit.'};
  await expectRefusal('undo-source-placement-reason', common, 'STALE_SOURCE_NOTE_UNDO');
  await expectRefusal('undo-source-placement-reason', {...common, expectedRevision:response.result.expectedRevision - 1}, 'STALE_SOURCE_NOTE_UNDO');
});

test('below the ceiling an unrelated vault write does not invalidate the placement review', async () => {
  await fixture('Reviewed reason.', 4);
  const reviewed = await ProgRSSVault.init();
  let response = await setReason({sourceId:'one', collectionId:'other', expectedVersion:1,
    expectedRevision:reviewed._revision, expectedReason:'Other reason.', reason:'Other updated.'});
  assert(response.ok && response.result.changed, response.error);
  response = await setReason({sourceId:'one', collectionId:'parent', expectedVersion:4,
    expectedRevision:reviewed._revision, expectedReason:'Reviewed reason.', reason:'Saved after unrelated write.'});
  assert(response.ok && response.result.changed, response.error);
  assert.strictEqual(folder(await ProgRSSVault.init()).members[1].reason, 'Saved after unrelated write.');
});

test('at the ceiling an unrelated vault write conservatively invalidates the review', async () => {
  await fixture('Reviewed reason.', 10000);
  const reviewed = await ProgRSSVault.init();
  let response = await setReason({sourceId:'one', collectionId:'other', expectedVersion:1,
    expectedRevision:reviewed._revision, expectedReason:'Other reason.', reason:'Other updated.'});
  assert(response.ok && response.result.changed, response.error);
  await expectRefusal('set-source-placement-reason', {sourceId:'one', collectionId:'parent', expectedVersion:10000,
    expectedRevision:reviewed._revision, expectedReason:'Reviewed reason.', reason:'Should be stale.'}, 'STALE_SOURCE_NOTE');
});

test('side panel carries the state revision through save and undo requests', async () => {
  const code = fs.readFileSync(path.join(ROOT, 'sidepanel/app.js'), 'utf8');
  assert(code.includes('expectedRevision: Number.isSafeInteger(app.state?.revision) ? app.state.revision : 0'));
  assert(code.includes('expectedRevision: editor.expectedRevision'));
  assert(code.includes('expectedRevision: result.expectedRevision'));
  assert(code.includes('expectedRevision: undo.expectedRevision'));
});

test('no network requests are made by the saturated-concurrency corpus', async () => {
  assert.strictEqual(fetchCalls.length, 0);
});

(async () => {
  let failures=0;
  for (const [name, fn] of cases) {
    try { await fn(); console.log(`PASS ${name}`); }
    catch (error) { failures++;console.error(`FAIL ${name}\n${error.stack}`); }
  }
  console.log(JSON.stringify({suite:'source-notes-saturated-concurrency',family:FAMILY,cases:cases.length,
    passed:cases.length-failures,failed:failures,installedBrowserRuntime:false}));
  if(failures)process.exitCode=1;
})().catch(error=>{console.error(error);process.exitCode=1;});
