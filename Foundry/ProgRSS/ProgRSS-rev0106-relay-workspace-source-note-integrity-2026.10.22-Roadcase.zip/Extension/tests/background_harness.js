'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const ROOT = path.resolve(__dirname, '..');

const storage = new Map();
const extensionStorage = new Map();
let failVaultWrites = false;
let pageExtractContent = 'Library opens Monday at 9.';
let pageExtractErrorCode = '';
let pageRepairVariant = 0;
globalThis.localStorage = {
  getItem(key) { return storage.has(key) ? storage.get(key) : null; },
  setItem(key, value) {
    if (failVaultWrites) {
      const error = Error('quota exceeded while writing the test vault');
      error.name = 'QuotaExceededError';
      throw error;
    }
    storage.set(key, String(value));
  },
  removeItem(key) { storage.delete(key); }
};

const messageListeners = [];
const alarms = [];
globalThis.chrome = {
  storage: {
    local: {
      async get(key) {
        if (key == null) return Object.fromEntries(extensionStorage);
        const keys = Array.isArray(key) ? key : [key];
        return Object.fromEntries(keys.filter(value => extensionStorage.has(value)).map(value => [value, extensionStorage.get(value)]));
      },
      async set(values) { for (const [key, value] of Object.entries(values || {})) extensionStorage.set(key, value); },
      async remove(key) { for (const value of (Array.isArray(key) ? key : [key])) extensionStorage.delete(value); }
    }
  },
  permissions: {
    async contains() { return true; },
    async getAll() { return {permissions: [], origins: ['https://example.test/*']}; }
  },
  runtime: {
    getURL(value) { return `chrome-extension://test/${value}`; },
    getManifest() { return {version: '0.80.0'}; },
    async getContexts() { return []; },
    async sendMessage(message) {
      if (message?.target === 'offscreen') {
        if (message.type === 'parse-feed') {
          return {ok: true, result: {
            title: 'Harness Feed', titleLanguage: 'en-GB', language: 'en-GB', type: 'rss', feedUrl: 'https://example.test/feed.xml', items: [
              {key: 'entry-1', title: 'A new entry', url: 'https://example.test/post/1', summary: 'ملخص الاختبار', body: 'نص الاختبار\n\nفقرة ثانية محفوظة.', bodyIsSummary: false, language: 'AR', titleLanguage: 'EN', summaryLanguage: 'AR', bodyLanguage: 'AR', published: '2026-10-17T12:00:00.000Z'}
            ]
          }};
        }
        if (message.type === 'parse-opml') {
          return {ok: true, result: {
            title: 'Harness subscriptions', feedOutlines: 4, invalidCount: 1, duplicateCount: 1, truncatedCount: 0, folderCount: 2,
            feeds: [
              {title: 'Harness Feed', url: 'https://example.test/feed.xml', folderPaths: [['Reading']]},
              {title: 'Independent Notes', url: 'https://new.test/feed.xml', folderPaths: [['Reading', 'Independent']]},
              {title: 'Other Notes', url: 'https://other.test/atom.xml', folderPaths: [['Reading']]}
            ]
          }};
        }
        if (message.type === 'inspect-resource') return {ok: true, result: {kind: 'feed', url: message.data.url, title: 'Harness Feed', titleLanguage: 'en-GB', language: 'en-GB', feedType: 'rss', feedUrl: 'https://example.test/feed.xml', itemCount: 1, previewCount: 1, previewFullTextCount: 1, previewSummaryCount: 0, previewDatedCount: 1, previewItems: [{title: 'A new entry', url: 'https://example.test/post/1', published: '2026-10-17T12:00:00.000Z', content: 'full-text', language: 'ar', titleLanguage: 'en'}]}};
        if (message.type === 'extract-page') {
          if (pageExtractErrorCode) return {ok: false, error: 'The watched section is missing.', code: pageExtractErrorCode, detail: {field: 'selector'}};
          return {ok: true, result: {mode: 'region', content: pageExtractContent, matchCount: 1, meaningfulCount: 1, contentChars: pageExtractContent.length}};
        }
        if (message.type === 'repair-page-watch') {
          const content = pageRepairVariant ? `${pageExtractContent} changed after review` : pageExtractContent;
          return {ok: true, result: [{
            schema: 'progrss.page-watch.repair.v1', title: 'Watch the page’s main text',
            description: 'Notice meaningful wording changes in the main part of the page.',
            mode: 'region', count: 1, examples: [], preview: content,
            recipe: {mode: 'region', selector: 'main', titleSelector: '', linkSelector: '', threshold: 4, ignoreNumbers: false},
            evidence: {signature: `region:${content}`, matchCount: 1, contentChars: content.length},
            capture: {mode: 'region', content, matchCount: 1, meaningfulCount: 1, contentChars: content.length}
          }]};
        }
      }
      return undefined;
    },
    onMessage: { addListener(listener) { messageListeners.push(listener); } },
    onInstalled: { addListener() {} },
    onStartup: { addListener() {} }
  },
  offscreen: { async createDocument() {} },
  action: {
    async setBadgeBackgroundColor() {}, async setBadgeText() {}, async setTitle() {}
  },
  sidePanel: { async setPanelBehavior() {} },
  alarms: { async create(name, details) { alarms.push({name, details}); }, onAlarm: { addListener() {} } },
  tabs: { async query() { return [{id: 1, url: 'https://example.test/', title: 'Example'}]; } },
  scripting: { async executeScript() { return [{result: {url: 'https://example.test/', title: 'Example', links: []}}]; } }
};

let fetchMode = 'normal';
let publicationPayload = '';
let publicationContentType = 'application/vnd.progrss.shared-folder+json; charset=utf-8';
const fetchCalls = [];
globalThis.fetch = async (url, options) => {
  fetchCalls.push({url: String(url), options});
  if (fetchMode === 'large') {
    return new Response('too large', {status: 200, headers: {'Content-Type': 'application/rss+xml', 'Content-Length': '2000001'}});
  }
  if (fetchMode === 'page') {
    return new Response(`<html><body><main>${pageExtractContent}</main></body></html>`, {
      status: 200, headers: {'Content-Type': 'text/html; charset=utf-8'}
    });
  }
  if (fetchMode === 'publication') {
    return new Response(publicationPayload, {
      status: 200, headers: {'Content-Type': publicationContentType, 'Content-Length': String(Buffer.byteLength(publicationPayload))}
    });
  }
  if (options?.headers?.['If-None-Match'] === '"harness-v1"') {
    return new Response(null, {status: 304, headers: {'ETag': '"harness-v1"', 'Last-Modified': 'Fri, 17 Oct 2026 12:00:00 GMT'}});
  }
  return new Response(
    '<rss><channel><title>Harness Feed</title><item><guid>entry-1</guid><title>A new entry</title></item></channel></rss>',
    {status: 200, headers: {'Content-Type': 'application/rss+xml', 'Content-Length': '120', 'ETag': '"harness-v1"', 'Last-Modified': 'Fri, 17 Oct 2026 12:00:00 GMT'}}
  );
};

globalThis.importScripts = (...files) => {
  for (const file of files) {
    const code = fs.readFileSync(path.join(ROOT, file), 'utf8');
    vm.runInThisContext(code, {filename: file});
  }
};

vm.runInThisContext(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8'), {filename: 'background.js'});
assert.strictEqual(messageListeners.length, 1, 'background message listener registered');
const listener = messageListeners[0];

function setBackupReminderFixture(marker) {
  extensionStorage.set('progrssBackupReminder', marker);
  vm.runInThisContext(`volatileBackupReminder = ${JSON.stringify(marker)};`);
}

function message(type, data = {}) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timeout = setTimeout(() => { if (!settled) reject(new Error(`timeout: ${type}`)); }, 1500);
    const keep = listener({target: 'background', type, data}, {}, response => {
      settled = true;
      clearTimeout(timeout);
      resolve(response);
    });
    assert.strictEqual(keep, true, `${type} keeps response channel open`);
  });
}

async function folderRemovalReview(sourceId, collectionId) {
  const response = await message('get-state');
  assert.strictEqual(response.ok, true, response.error);
  const folder = response.result.collections.find(row => row.id === collectionId);
  assert(folder, 'reviewed folder exists');
  const matches = (folder.members || []).filter(row => row?.kind === 'source' && row.id === sourceId);
  const member = matches.length === 1 ? matches[0] : null;
  return {
    sourceId,
    collectionId,
    expectedVersion: Math.max(1, Math.round(Number(folder.version) || 1)),
    expectedRevision: response.result.revision,
    expectedReason: member && Object.hasOwn(member, 'reason') ? member.reason : null
  };
}

(async () => {
  const languageEnrichmentState = {items: [{
    id: 'language-source|entry-1', entryKey: 'language-source|entry-1', feedRevision: 0, sourceId: 'language-source',
    title: 'A note', url: 'https://example.test/note', summary: 'Same text', body: 'Same text', bodyIsSummary: true,
    published: '', observedAt: '2026-10-18T00:00:00.000Z', kind: 'new'
  }]};
  const languageEnrichmentEvents = globalThis.ProgRSSCore.ingestFeed(languageEnrichmentState, {id: 'language-source'}, {items: [{
    key: 'entry-1', title: 'A note', url: 'https://example.test/note', summary: 'Same text', body: 'Same text', bodyIsSummary: true,
    language: 'AR', titleLanguage: 'EN', summaryLanguage: 'AR', bodyLanguage: 'AR', published: ''
  }]});
  assert.strictEqual(languageEnrichmentEvents, 0, 'language-only enrichment does not manufacture an update event');
  assert.strictEqual(languageEnrichmentState.items.length, 1);
  assert.strictEqual(languageEnrichmentState.items[0].language, 'ar');
  assert.strictEqual(languageEnrichmentState.items[0].titleLanguage, 'en');

  const summaryPolicyState = {items: []};
  const summaryPolicySource = {id: 'summary-policy-source', textRetention: 'summary'};
  let summaryPolicyEvents = globalThis.ProgRSSCore.ingestFeed(summaryPolicyState, summaryPolicySource, {items: [{
    key: 'entry-1', title: 'Stored lightly', url: 'https://example.test/light', summary: 'Short feed summary',
    body: 'Longer full text supplied by the feed.', bodyIsSummary: false, language: 'EN', summaryLanguage: 'EN', bodyLanguage: 'EN', published: ''
  }]});
  assert.strictEqual(summaryPolicyEvents, 1);
  assert.strictEqual(summaryPolicyState.items[0].body, 'Short feed summary');
  assert.strictEqual(summaryPolicyState.items[0].bodyIsSummary, true);
  assert.strictEqual(summaryPolicyState.items[0].bodyOmitted, true);
  summaryPolicyEvents = globalThis.ProgRSSCore.ingestFeed(summaryPolicyState, {id: 'summary-policy-source'}, {items: [{
    key: 'entry-1', title: 'Stored lightly', url: 'https://example.test/light', summary: 'Short feed summary',
    body: 'Longer full text supplied by the feed.', bodyIsSummary: false, language: 'EN', summaryLanguage: 'EN', bodyLanguage: 'EN', published: ''
  }]});
  assert.strictEqual(summaryPolicyEvents, 0, 'restoring fuller retained text does not manufacture an unread event');
  assert.strictEqual(summaryPolicyState.items[0].body, 'Longer full text supplied by the feed.');
  assert.strictEqual(summaryPolicyState.items[0].bodyIsSummary, false);
  assert.ok(!Object.hasOwn(summaryPolicyState.items[0], 'bodyOmitted'));

  let response = await message('get-state');
  assert.strictEqual(response.ok, true);
  assert.deepStrictEqual(response.result.sources, []);

  response = await message('add-source', {url: 'https://example.test/feed.xml', title: 'Harness Feed', titleLanguage: 'EN-GB', language: 'EN-GB', type: 'rss'});
  assert.strictEqual(response.ok, true);
  const sourceId = response.result.source.id;

  response = await message('refresh-source', {sourceId});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.added, 1);
  assert.strictEqual(fetchCalls[0].options.credentials, 'omit');
  assert.strictEqual(fetchCalls[0].options.redirect, 'error');

  response = await message('get-state');
  assert.strictEqual(response.result.sources.length, 1);
  assert.strictEqual(response.result.items.length, 1);
  assert.strictEqual(response.result.sources[0].language, 'en-gb');
  assert.strictEqual(response.result.sources[0].titleLanguage, 'en-gb');
  assert.strictEqual(response.result.items[0].body, 'نص الاختبار\n\nفقرة ثانية محفوظة.');
  assert.strictEqual(response.result.items[0].bodyIsSummary, false);
  assert.strictEqual(response.result.items[0].language, 'ar');
  assert.strictEqual(response.result.items[0].titleLanguage, 'en');
  assert.strictEqual(response.result.items[0].summaryLanguage, 'ar');
  assert.strictEqual(response.result.items[0].bodyLanguage, 'ar');
  assert.strictEqual(response.result.sources[0].httpCache.etag, '"harness-v1"');
  assert.ok(response.result.sources[0].lastSuccessfulAt, 'successful refresh is recorded');
  assert.ok(response.result.sources[0].lastNewAt, 'new update time is recorded');
  const itemId = response.result.items[0].id;

  response = await message('refresh-source', {sourceId});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.notModified, true);
  assert.strictEqual(response.result.added, 0);
  assert.strictEqual(fetchCalls.at(-1).options.headers['If-None-Match'], '"harness-v1"');
  assert.strictEqual(fetchCalls.at(-1).options.headers['If-Modified-Since'], 'Fri, 17 Oct 2026 12:00:00 GMT');

  setBackupReminderFixture({
    schema: 'progrss.backup-reminder.v1',
    firstMeaningfulAt: '2026-09-01T00:00:00.000Z',
    lastCopyAt: '', lastCopyRevision: 0, snoozedUntil: '', disabled: false,
    updatedAt: '2026-09-01T00:00:00.000Z'
  });
  response = await message('get-state');
  assert.strictEqual(response.result.backupReminder.visible, true, 'an established library without a checked copy receives one quiet reminder');
  assert.strictEqual(response.result.backupReminder.status, 'no-checked-copy');
  assert.strictEqual(response.result.backupReminder.meaningful, true);
  let reminderMarker = extensionStorage.get('progrssBackupReminder');
  assert.strictEqual(reminderMarker.schema, 'progrss.backup-reminder.v3', 'the legacy reminder marker migrates without calling an initiated download checked');
  assert.match(reminderMarker.fingerprintKey, /^[0-9a-f]{64}$/);
  assert.strictEqual(reminderMarker.lastCheckedAt, '');
  assert.strictEqual(reminderMarker.lastCheckedFingerprint, '');
  assert.ok(!JSON.stringify(reminderMarker).includes('example.test'), 'the reminder marker contains no source address');
  assert.ok(!JSON.stringify(reminderMarker).includes('Harness Feed'), 'the reminder marker contains no source title');
  assert.ok(!JSON.stringify(reminderMarker).includes('نص الاختبار'), 'the reminder marker contains no retained text');

  response = await message('snooze-backup-reminder');
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.visible, false);
  assert.ok(Date.parse(response.result.snoozedUntil) > Date.now());
  response = await message('disable-backup-reminder');
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.disabled, true);
  response = await message('enable-backup-reminder');
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.disabled, false);
  assert.strictEqual(response.result.visible, true);

  response = await message('export-private-backup', {recovery: true});
  assert.strictEqual(response.ok, true);
  const preparedRaw = response.result.raw;
  assert.strictEqual(response.result.backupReminder.visible, true, 'preparing a browser download does not suppress the reminder');
  assert.strictEqual(response.result.backupReminder.status, 'prepared-not-checked');
  assert.strictEqual(response.result.backupReminder.pendingCheck, true);
  assert.ok(response.result.backupReminder.lastPreparedAt);
  assert.strictEqual(response.result.backupReminder.lastCheckedAt, '');
  assert.ok(!response.result.raw.includes('progrss.backup-reminder.v3'), 'the browser-local reminder marker is not exported');
  const preparedRevision = response.result.backupReminder.lastPreparedRevision;
  reminderMarker = extensionStorage.get('progrssBackupReminder');
  assert.match(reminderMarker.lastPreparedFingerprint, /^[0-9a-f]{64}$/);
  assert.ok(!response.result.raw.includes(reminderMarker.fingerprintKey), 'the installation-local fingerprint key is not exported');
  assert.ok(!response.result.raw.includes(reminderMarker.lastPreparedFingerprint), 'the installation-local prepared fingerprint is not exported');

  response = await message('check-private-backup', {raw: preparedRaw});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.schema, 'progrss.private-copy-check.v2');
  assert.strictEqual(response.result.state, 'current');
  assert.strictEqual(response.result.relationship, 'current');
  assert.strictEqual(response.result.samePortableLibrary, true);
  assert.strictEqual(response.result.backupReminder.visible, false);
  assert.strictEqual(response.result.backupReminder.status, 'current');
  assert.ok(response.result.backupReminder.lastCheckedAt);
  assert.strictEqual(response.result.backupReminder.lastCheckedRevision, preparedRevision);
  assert.strictEqual(response.result.writesVault, false);
  assert.strictEqual(response.result.writesMarker, true);
  reminderMarker = extensionStorage.get('progrssBackupReminder');
  assert.strictEqual(reminderMarker.lastCheckedFingerprint, reminderMarker.lastPreparedFingerprint);
  assert.ok(reminderMarker.lastSeenAt);

  response = await message('mark-backup-copy-missing');
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.status, 'copy-missing');
  assert.strictEqual(response.result.checkedCopyMissing, true);
  assert.strictEqual(response.result.visible, true);
  assert.ok(response.result.missingSince);
  response = await message('check-private-backup', {raw: preparedRaw});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.state, 'current');
  assert.strictEqual(response.result.backupReminder.checkedCopyMissing, false, 'reading the recorded file clears the missing marker');

  response = await message('set-item', {itemId, read: false, starred: true});
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  assert.strictEqual(response.result.backupReminder.changedSinceChecked, true);
  assert.strictEqual(response.result.backupReminder.visible, false, 'a recently checked copy is not followed by an immediate interruption');

  response = await message('check-private-backup', {raw: preparedRaw});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.state, 'previous', 'the last checked file remains recognizable after the library changes');
  assert.strictEqual(response.result.relationship, 'last-checked');
  assert.strictEqual(response.result.knownRevision, preparedRevision);
  assert.strictEqual(response.result.samePortableLibrary, false);
  assert.ok(response.result.changedAreas.includes('updates'));
  assert.strictEqual(response.result.writesMarker, true);
  response = await message('get-state');
  assert.strictEqual(response.result.backupReminder.changedSinceChecked, true, 'checking an older copy cannot make it current');

  response = await message('mark-backup-copy-missing');
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.checkedCopyMissing, true);
  response = await message('check-private-backup', {raw: preparedRaw});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.state, 'previous');
  assert.strictEqual(response.result.backupReminder.checkedCopyMissing, false, 'finding the older known file clears the missing marker without changing the vault');

  response = await message('export-private-backup', {recovery: true});
  assert.strictEqual(response.ok, true);
  const changedPreparedRaw = response.result.raw;
  assert.strictEqual(response.result.backupReminder.pendingCheck, true);
  response = await message('check-private-backup', {raw: preparedRaw});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.state, 'previous');
  assert.strictEqual(response.result.backupReminder.pendingCheck, true, 'reading an older checked copy cannot satisfy a newly prepared current copy');
  response = await message('check-private-backup', {raw: changedPreparedRaw});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.state, 'current');
  assert.strictEqual(response.result.backupReminder.pendingCheck, false, 'reading the newly prepared current copy clears its pending check');

  setBackupReminderFixture({
    schema: 'progrss.backup-reminder.v2',
    firstMeaningfulAt: '2026-08-01T00:00:00.000Z',
    lastPreparedAt: '2026-08-15T00:00:00.000Z',
    lastPreparedRevision: preparedRevision,
    lastCheckedAt: '2026-08-15T00:00:00.000Z',
    lastCheckedRevision: preparedRevision,
    snoozedUntil: '', disabled: false,
    updatedAt: '2026-08-15T00:00:00.000Z'
  });
  response = await message('get-state');
  assert.strictEqual(extensionStorage.get('progrssBackupReminder').schema, 'progrss.backup-reminder.v3');
  assert.match(extensionStorage.get('progrssBackupReminder').fingerprintKey, /^[0-9a-f]{64}$/);
  assert.strictEqual(response.result.backupReminder.status, 'changed');
  assert.strictEqual(response.result.backupReminder.visible, true, 'a changed library can remind again after thirty days');

  const currentRevision = response.result.backupReminder.currentRevision;
  setBackupReminderFixture({
    schema: 'progrss.backup-reminder.v3',
    fingerprintKey: '11'.repeat(32),
    firstMeaningfulAt: '2026-05-01T00:00:00.000Z',
    lastPreparedAt: '2026-05-02T00:00:00.000Z',
    lastPreparedRevision: currentRevision,
    lastPreparedFingerprint: '',
    lastCheckedAt: '2026-06-01T00:00:00.000Z',
    lastCheckedRevision: currentRevision,
    lastCheckedFingerprint: '',
    lastSeenAt: '2026-06-01T00:00:00.000Z',
    missingSince: '', snoozedUntil: '', disabled: false,
    updatedAt: '2026-06-01T00:00:00.000Z'
  });
  response = await message('get-state');
  assert.strictEqual(response.result.backupReminder.status, 'recheck');
  assert.strictEqual(response.result.backupReminder.recheckDue, true);
  assert.strictEqual(response.result.backupReminder.visible, true, 'a current copy receives a quiet readability recheck after ninety days');
  assert.strictEqual(response.result.backupReminder.recheckDays, 90);

  response = await message('export-private-backup', {recovery: true});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.backupReminder.status, 'prepared-not-checked');
  assert.strictEqual(response.result.backupReminder.visible, true);
  response = await message('check-private-backup', {raw: response.result.raw});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.backupReminder.status, 'current');
  assert.strictEqual(response.result.backupReminder.visible, false);

  response = await message('check-private-backup', {raw: '{not-json'});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'INVALID_BACKUP');
  response = await message('mark-items-read', {ids: [itemId]});
  assert.strictEqual(response.ok, true);
  assert.deepStrictEqual(response.result.changed, [itemId]);
  response = await message('get-state');
  assert.ok(response.result.items[0].readAt);
  assert.strictEqual(response.result.items[0].starred, true);
  response = await message('mark-items-unread', {ids: [itemId]});
  assert.strictEqual(response.ok, true);

  failVaultWrites = true;
  response = await message('set-item', {itemId, starred: false});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'VAULT_WRITE_FAILED');
  assert.strictEqual(response.detail.incident.reason, 'quota');
  assert.strictEqual(response.detail.incident.operation, 'Changing read or saved state');
  assert.strictEqual(response.detail.incident.savedLibrary.sources, 1);
  assert.strictEqual(response.detail.incident.savedLibrary.items, 1);
  response = await message('get-state');
  assert.strictEqual(response.result.items[0].starred, true, 'failed write leaves the last committed item unchanged');
  assert.strictEqual(response.result.storageIncident.reason, 'quota', 'storage incident survives a state reload');
  response = await message('export-private-backup', {recovery: true});
  assert.strictEqual(response.ok, true);
  assert.match(response.result.fileName, /^ProgRSS-recovery-/);
  assert.strictEqual(JSON.parse(response.result.raw).purpose, 'recovery-copy');
  response = await message('probe-vault-write');
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'VAULT_WRITE_FAILED');
  failVaultWrites = false;
  response = await message('probe-vault-write');
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.available, true);
  response = await message('get-state');
  assert.strictEqual(response.result.storageIncident, null, 'successful test write clears the incident');
  response = await message('set-item', {itemId, starred: false});
  assert.strictEqual(response.ok, true, 'the person explicitly repeats the failed action');

  response = await message('set-item', {itemId, read: true, starred: false});
  assert.strictEqual(response.ok, true);
  response = await message('set-source-text-retention', {sourceId, mode: 'summary'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.mode, 'summary');
  assert.strictEqual(response.result.cleanupEligible, 1);
  response = await message('prune-source-text', {sourceId});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.changed.length, 1);
  assert.ok(response.result.bytes > 0);
  const textCleanup = response.result;
  response = await message('get-state');
  assert.strictEqual(response.result.sources.find(source => source.id === sourceId).textRetention, 'summary');
  const cleanedItem = response.result.items.find(item => item.id === itemId);
  assert.strictEqual(cleanedItem.body, cleanedItem.summary);
  assert.strictEqual(cleanedItem.bodyIsSummary, true);
  assert.strictEqual(cleanedItem.bodyOmitted, true);
  response = await message('undo-source-text-prune', {sourceId, items: textCleanup.changed, expectedRevision: textCleanup.expectedRevision - 1});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'STALE_TEXT_CLEANUP_UNDO');
  response = await message('undo-source-text-prune', {sourceId, items: textCleanup.changed, expectedRevision: textCleanup.expectedRevision});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.restored, 1);
  response = await message('get-state');
  const restoredItem = response.result.items.find(item => item.id === itemId);
  assert.strictEqual(restoredItem.body, 'نص الاختبار\n\nفقرة ثانية محفوظة.');
  assert.strictEqual(restoredItem.bodyIsSummary, false);
  assert.ok(!Object.hasOwn(restoredItem, 'bodyOmitted'));
  response = await message('set-source-text-retention', {sourceId, mode: 'full'});
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  assert.ok(!Object.hasOwn(response.result.sources.find(source => source.id === sourceId), 'textRetention'));

  response = await message('inspect-url', {url: 'https://example.test/feed.xml'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.kind, 'feed');
  assert.strictEqual(response.result.previewCount, 1);
  assert.strictEqual(response.result.previewFullTextCount, 1);
  assert.deepStrictEqual(response.result.previewItems.map(item => Object.keys(item).sort()), [["content", "language", "published", "title", "titleLanguage", "url"]]);
  assert.ok(!Object.hasOwn(response.result.previewItems[0], 'body'));
  assert.ok(!Object.hasOwn(response.result.previewItems[0], 'summary'));
  assert.strictEqual(response.result.existingSource.id, sourceId);

  response = await message('inspect-url', {url: 'https://example.test/alternate.xml'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.existingSource.id, sourceId);
  assert.strictEqual(response.result.existingSource.match, 'declared-self');
  response = await message('inspect-url', {url: 'https://other.test/alternate.xml'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.feedUrl, '', 'a cross-origin self declaration remains inert');
  assert.strictEqual(response.result.existingSource, null);

  response = await message('add-source', {
    url: 'https://example.test/alternate.xml', feedUrl: 'https://example.test/feed.xml', title: 'Duplicate Alias', type: 'rss'
  });
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.alreadyFollowing, true);
  response = await message('get-state');
  assert.strictEqual(response.result.sources.length, 1, 'declared self URL prevents a duplicate source');

  response = await message('preview-opml', {raw: '<opml version="2.0"><body/></opml>'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.newCount, 2);
  assert.strictEqual(response.result.existingCount, 1);
  assert.strictEqual(response.result.duplicateInFileCount, 1);
  assert.strictEqual(response.result.invalidCount, 1);
  assert.strictEqual(response.result.folderCount, 2);
  assert.strictEqual(response.result.originCount, 2);
  assert.strictEqual(response.result.canImport, true);

  response = await message('import-opml', {raw: '<opml version="2.0"><body/></opml>', paused: true});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.added, 2);
  assert.strictEqual(response.result.foldersAdded, 2);
  response = await message('get-state');
  const imported = response.result.sources.filter(source => source.origin === 'opml-import');
  assert.strictEqual(imported.length, 2);
  assert.ok(imported.every(source => source.enabled === false));
  assert.strictEqual(response.result.collections.length, 2);
  const reading = response.result.collections.find(collection => collection.title === 'Reading');
  const independent = response.result.collections.find(collection => collection.title === 'Independent');
  assert.ok(reading && independent, 'nested OPML folders were preserved');
  assert.ok(reading.members.some(member => member.kind === 'collection' && member.id === independent.id));

  response = await message('add-source', {
    url: 'https://example.test/changes', title: 'Harness Page Watch', type: 'page', mode: 'cards',
    selector: 'article', titleSelector: 'h2', linkSelector: 'a[href]'
  });
  assert.strictEqual(response.ok, true);
  const pageWatch = response.result.source;

  response = await message('add-source', {
    url: 'https://example.test/hours', title: 'Library hours', type: 'page', mode: 'region',
    selector: 'main', threshold: 4, ignoreNumbers: false
  });
  assert.strictEqual(response.ok, true);
  const traceWatch = response.result.source;
  fetchMode = 'page';
  pageExtractContent = 'Library opens Monday morning at nine o’clock for quiet reading. The reading room closes at 6.';
  response = await message('refresh-source', {sourceId: traceWatch.id});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.baseline, true);
  assert.strictEqual(response.result.added, 0, 'the first page observation remains a baseline');
  pageExtractContent = 'Library now opens Tuesday afternoon at ten o’clock for community workshops. The reading room closes at 6.';
  response = await message('refresh-source', {sourceId: traceWatch.id});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.added, 1);
  response = await message('get-state');
  const traceEvent = response.result.items.find(item => item.sourceId === traceWatch.id);
  assert.strictEqual(traceEvent.change.schema, 'progrss.page-change.v1');
  assert.strictEqual(traceEvent.change.kind, 'text-changed');
  assert.strictEqual(traceEvent.change.before, 'Library opens Monday morning at nine o’clock for quiet reading. The reading room closes at 6.');
  assert.strictEqual(traceEvent.change.after, 'Library now opens Tuesday afternoon at ten o’clock for community workshops. The reading room closes at 6.');
  assert.match(traceEvent.summary, /Monday morning.*Tuesday afternoon/);

  response = await message('add-source', {
    url: 'https://example.test/steady', title: 'Steady page watch', type: 'page', mode: 'region',
    selector: 'main', threshold: 4, ignoreNumbers: false
  });
  assert.strictEqual(response.ok, true);
  const steadyWatch = response.result.source;
  pageExtractContent = 'A'.repeat(500);
  response = await message('refresh-source', {sourceId: steadyWatch.id});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.baseline, true);
  pageExtractContent = 'B'.repeat(100);
  response = await message('refresh-source', {sourceId: steadyWatch.id});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.held, true, 'one sharp shape shift is held rather than emitted');
  assert.strictEqual(response.result.outcome, 'watch-pending');
  response = await message('get-state');
  let steadyState = response.result;
  let steadySource = steadyState.sources.find(source => source.id === steadyWatch.id);
  assert.strictEqual(steadySource.watchStability.schema, 'progrss.page-watch.stability.v1');
  assert.strictEqual(steadySource.watchStability.observations, 1);
  assert.strictEqual(steadyState.items.filter(item => item.sourceId === steadyWatch.id).length, 0, 'held observation creates no alert');
  pageExtractContent = 'C'.repeat(110);
  response = await message('refresh-source', {sourceId: steadyWatch.id});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.added, 1, 'a similar second shape confirms the change');
  response = await message('get-state');
  steadyState = response.result;
  steadySource = steadyState.sources.find(source => source.id === steadyWatch.id);
  assert.strictEqual(steadySource.watchStability, undefined);
  assert.strictEqual(steadySource.watchHealth.reason, 'confirmed-shape-change');
  assert.strictEqual(steadyState.items.filter(item => item.sourceId === steadyWatch.id).length, 1);
  response = await message('export-private-backup');
  assert.strictEqual(response.ok, true);
  assert.ok(!response.result.raw.includes('watchStability'), 'transient confirmation state never travels in a private copy');

  response = await message('add-source', {
    url: 'https://example.test/steady-return', title: 'Returning page watch', type: 'page', mode: 'region',
    selector: 'main', threshold: 4, ignoreNumbers: false
  });
  assert.strictEqual(response.ok, true);
  const returningWatch = response.result.source;
  pageExtractContent = 'R'.repeat(500);
  response = await message('refresh-source', {sourceId: returningWatch.id});
  assert.strictEqual(response.ok, true);
  pageExtractContent = 'S'.repeat(100);
  response = await message('refresh-source', {sourceId: returningWatch.id});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.held, true);
  pageExtractContent = 'R'.repeat(500);
  response = await message('refresh-source', {sourceId: returningWatch.id});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.added, 0, 'a return to the saved shape discards the held result without an alert');
  response = await message('get-state');
  let returningState = response.result.sources.find(source => source.id === returningWatch.id);
  assert.strictEqual(returningState.watchStability, undefined);
  assert.strictEqual(returningState.watchHealth.reason, 'returned-to-steady');
  assert.strictEqual(response.result.items.filter(item => item.sourceId === returningWatch.id).length, 0);

  response = await message('add-source', {
    url: 'https://example.test/steady-unstable', title: 'Unstable page watch', type: 'page', mode: 'region',
    selector: 'main', threshold: 4, ignoreNumbers: false
  });
  assert.strictEqual(response.ok, true);
  const unstableWatch = response.result.source;
  pageExtractContent = 'U'.repeat(500);
  response = await message('refresh-source', {sourceId: unstableWatch.id});
  assert.strictEqual(response.ok, true);
  pageExtractContent = 'V'.repeat(100);
  response = await message('refresh-source', {sourceId: unstableWatch.id});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.held, true);
  pageExtractContent = 'W'.repeat(20);
  response = await message('refresh-source', {sourceId: unstableWatch.id});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.held, true);
  response = await message('get-state');
  let unstableSource = response.result.sources.find(source => source.id === unstableWatch.id);
  assert.strictEqual(unstableSource.watchStability.observations, 2);
  pageExtractContent = 'X'.repeat(110);
  response = await message('refresh-source', {sourceId: unstableWatch.id});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'PAGE_WATCH_UNSTABLE');
  response = await message('get-state');
  unstableSource = response.result.sources.find(source => source.id === unstableWatch.id);
  assert.strictEqual(unstableSource.watchStability, undefined);
  assert.strictEqual(unstableSource.watchRepair.reason, 'unstable-shape');
  assert.strictEqual(response.result.items.filter(item => item.sourceId === unstableWatch.id).length, 0, 'incompatible sharp shapes never become page alerts');

  const traceItemsBeforeRepair = steadyState.items.filter(item => item.sourceId === traceWatch.id).length;
  pageExtractErrorCode = 'PAGE_SELECTOR_NO_MATCH';
  response = await message('refresh-source', {sourceId: traceWatch.id});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'PAGE_SELECTOR_NO_MATCH');
  response = await message('get-state');
  let brokenWatch = response.result.sources.find(source => source.id === traceWatch.id);
  assert.strictEqual(brokenWatch.watchRepair.schema, 'progrss.page-watch.repair.v1');
  assert.strictEqual(brokenWatch.watchRepair.reason, 'no-match');
  assert.match(brokenWatch.lastError, /choose what to watch/i);
  const callsBeforeSkippedRefresh = fetchCalls.length;
  response = await message('refresh-all');
  assert.strictEqual(response.ok, true);
  const bulkCalls = fetchCalls.slice(callsBeforeSkippedRefresh);
  assert.ok(!bulkCalls.some(call => call.url === traceWatch.url), 'a watch awaiting repair is excluded from bulk refresh');
  assert.ok(!bulkCalls.some(call => call.url === unstableWatch.url), 'an unstable watch escalated to repair is excluded from bulk refresh');

  pageExtractErrorCode = '';
  pageExtractContent = 'Library hours and services are listed here now.';
  response = await message('preview-page-watch-repair', {sourceId: traceWatch.id});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.writes, false);
  assert.strictEqual(response.result.proposals.length, 1);
  let repairReview = response.result;
  pageRepairVariant = 1;
  response = await message('repair-page-watch', {
    sourceId: traceWatch.id,
    reviewedRevision: repairReview.reviewedRevision,
    proposalToken: repairReview.proposals[0].token
  });
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'PAGE_WATCH_REPAIR_STALE');
  pageRepairVariant = 0;
  response = await message('preview-page-watch-repair', {sourceId: traceWatch.id});
  assert.strictEqual(response.ok, true);
  repairReview = response.result;
  response = await message('repair-page-watch', {
    sourceId: traceWatch.id,
    reviewedRevision: repairReview.reviewedRevision,
    proposalToken: repairReview.proposals[0].token
  });
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.baseline, true);
  assert.strictEqual(response.result.added, 0, 'repair must not manufacture a change alert');
  response = await message('get-state');
  const repairedWatch = response.result.sources.find(source => source.id === traceWatch.id);
  assert.strictEqual(repairedWatch.watchRepair, undefined);
  assert.strictEqual(repairedWatch.lastOutcome, 'baseline');
  assert.strictEqual(repairedWatch.watchHealth.reason, 'baseline');
  assert.strictEqual(response.result.items.filter(item => item.sourceId === traceWatch.id).length, traceItemsBeforeRepair, 'earlier page alerts are preserved exactly');
  assert.strictEqual(response.result.pageWatchRepair.undoAvailable, true);
  response = await message('undo-page-watch-repair');
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  brokenWatch = response.result.sources.find(source => source.id === traceWatch.id);
  assert.strictEqual(brokenWatch.watchRepair.reason, 'no-match');
  assert.strictEqual(response.result.pageWatchRepair.undoAvailable, false);

  fetchMode = 'normal';
  response = await message('add-source-to-folder', {sourceId: pageWatch.id, collectionId: reading.id});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.added, true);
  response = await message('add-source-to-folder', {sourceId, collectionId: reading.id});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.added, true, 'the feed has a direct placement available for a Source Note');

  // Source Notes are authored through the shipped placement mutation rather
  // than by editing the vault or treating the reason as source metadata.
  const sourceNoteText = 'Primary reporting for this reading route.';
  const initialSourceNoteVersion = response.result.folderVersion;
  response = await message('set-source-placement-reason', {
    sourceId, collectionId: reading.id, expectedVersion: initialSourceNoteVersion,
    expectedReason: null, reason: sourceNoteText
  });
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.changed, true);
  assert.strictEqual(response.result.previousReason, null);
  assert.strictEqual(response.result.reason, sourceNoteText);
  let sourceNoteVersion = response.result.folderVersion;

  response = await message('set-source-placement-reason', {
    sourceId, collectionId: reading.id, expectedVersion: sourceNoteVersion - 1,
    expectedReason: sourceNoteText, reason: 'A stale edit that must not win.'
  });
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'STALE_SOURCE_NOTE');
  response = await message('set-source-placement-reason', {
    sourceId, collectionId: reading.id, expectedVersion: sourceNoteVersion,
    expectedReason: sourceNoteText, reason: 'x'.repeat(281)
  });
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'INVALID_SOURCE_NOTE');

  response = await message('set-source-placement-reason', {
    sourceId, collectionId: reading.id, expectedVersion: sourceNoteVersion,
    expectedReason: sourceNoteText, reason: null
  });
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.cleared, true);
  assert.strictEqual(response.result.reason, null);
  const clearedSourceNoteVersion = response.result.folderVersion;
  response = await message('get-state');
  let sourceNoteFolder = response.result.collections.find(collection => collection.id === reading.id);
  let sourceNotePlacement = sourceNoteFolder.members.find(member => member.kind === 'source' && member.id === sourceId);
  assert.ok(!Object.hasOwn(sourceNotePlacement, 'reason'), 'clearing preserves reason absence rather than an empty string');

  response = await message('undo-source-placement-reason', {
    sourceId, collectionId: reading.id, expectedVersion: clearedSourceNoteVersion - 1,
    expectedCurrentReason: null, previousReason: sourceNoteText
  });
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'STALE_SOURCE_NOTE_UNDO');
  response = await message('undo-source-placement-reason', {
    sourceId, collectionId: reading.id, expectedVersion: clearedSourceNoteVersion,
    expectedCurrentReason: null, previousReason: sourceNoteText
  });
  assert.strictEqual(response.ok, true);
  sourceNoteVersion = response.result.folderVersion;
  response = await message('get-state');
  sourceNoteFolder = response.result.collections.find(collection => collection.id === reading.id);
  sourceNotePlacement = sourceNoteFolder.members.find(member => member.kind === 'source' && member.id === sourceId);
  assert.strictEqual(sourceNotePlacement.reason, sourceNoteText, 'guarded undo restores the exact earlier placement reason');

  response = await message('export-shared-folder', {
    collectionId: reading.id, format: 'bundle',
    options: {curator: 'Harness Garden', note: 'Public-interest sources selected for neighbors.', sign: false}
  });
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.summary.pageWatches, 1);
  assert.strictEqual(response.result.summary.folders, 2);
  assert.strictEqual(response.result.summary.signatureState, 'unsigned');
  assert.strictEqual(response.result.summary.sourceNoteCount, 1);
  assert.strictEqual(response.result.summary.sourceNotesIncluded, true);
  const sharedBundle = JSON.parse(response.result.raw);
  assert.strictEqual(sharedBundle.schema, 'progrss.bundle.v2');
  assert.strictEqual(sharedBundle.root, reading.id);
  assert.strictEqual(sharedBundle.publication.curator, 'Harness Garden');
  assert.strictEqual(sharedBundle.publication.note, 'Public-interest sources selected for neighbors.');
  assert.match(sharedBundle.integrity.digest, /^sha256:[a-f0-9]{64}$/);
  assert.ok(sharedBundle.sources.some(source => source.type === 'page' && source.url === pageWatch.url));
  assert.ok(sharedBundle.collections.some(collection => collection.members.some(member => member.kind === 'source' && member.id === sourceId && member.reason === 'Primary reporting for this reading route.')));
  assert.ok(sharedBundle.sources.every(source => !Object.hasOwn(source, 'enabled')), 'shared recipes do not carry source activity');
  assert.ok(!Object.hasOwn(sharedBundle, 'items') && !Object.hasOwn(sharedBundle, 'snapshots'), 'shared folders do not carry private observations');

  response = await message('export-shared-folder', {collectionId: reading.id, format: 'opml', options: {curator: 'Harness Garden'}});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.summary.omittedPageWatches, 1);
  assert.strictEqual(response.result.summary.sourceNotesIncluded, false);
  assert.strictEqual(response.result.summary.omittedSourceNoteCount, 1);
  assert.deepStrictEqual(response.result.summary.omittedSourceNotePlacements, [{folderId: reading.id, sourceId}]);
  assert.ok(!response.result.raw.includes(pageWatch.url), 'OPML leaves page watches out explicitly');
  assert.ok(!response.result.raw.includes('Primary reporting for this reading route.'), 'OPML leaves Source Notes out explicitly');
  assert.match(response.result.raw, /<ownerName>Harness Garden<\/ownerName>/);
  assert.match(response.result.raw, /<outline text="Reading">/);

  response = await message('add-source-to-folder', {sourceId: traceWatch.id, collectionId: reading.id});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.added, true);

  response = await message('export-folder-edition', {
    collectionId: reading.id,
    options: {curator: 'Harness Garden', note: 'Recent neighborhood updates.', limit: 100}
  });
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.mime, 'application/feed+json');
  assert.match(response.result.fileName, /-updates\.json$/);
  const edition = JSON.parse(response.result.raw);
  assert.strictEqual(edition.version, 'https://jsonfeed.org/version/1.1');
  assert.strictEqual(edition._progrss.schema, 'progrss.folder-edition.v1');
  assert.strictEqual(edition.authors[0].name, 'Harness Garden');
  assert.ok(edition.items.length > 0, 'selected folder should have recent updates to share');
  assert.ok(edition.items.every(item => Object.hasOwn(item, 'content_text')));
  assert.ok(edition.items.every(item => !Object.hasOwn(item, 'readAt') && !Object.hasOwn(item, 'starred')));
  assert.ok(!response.result.raw.includes('فقرة ثانية محفوظة.'), 'full retained feed text stays private');
  assert.ok(!response.result.raw.includes('"before"') && !response.result.raw.includes('"after"'), 'page-watch comparison passages stay private');
  assert.strictEqual(response.result.summary.fullTextIncluded, false);
  assert.strictEqual(response.result.summary.readingStateIncluded, false);
  assert.strictEqual(response.result.summary.savedStateIncluded, false);

  const fetchCountBeforeSharedPreview = fetchCalls.length;
  response = await message('preview-shared-folder', {raw: JSON.stringify(sharedBundle)});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.newSources, 0);
  assert.strictEqual(response.result.reusedSources, sharedBundle.sources.length);
  assert.strictEqual(response.result.signatureState, 'unsigned');
  assert.strictEqual(response.result.curator, 'Harness Garden');
  assert.strictEqual(response.result.network, false);
  assert.strictEqual(response.result.writes, false);
  assert.strictEqual(response.result.contents.schema, 'progrss.shared-folder.contents.v2');
  assert.strictEqual(response.result.contents.sourceCount, sharedBundle.sources.length);
  assert.strictEqual(response.result.contents.sourceNoteCount, 1);
  assert.strictEqual(response.result.contents.sources.find(source => source.id === sourceId).placements.find(placement => placement.folderId === reading.id).reason, 'Primary reporting for this reading route.');
  assert.ok(response.result.contents.sources.every(source => source.state === 'already-here'));
  assert.ok(response.result.contents.folders.some(folder => folder.path.includes('Reading')));
  const selectableSection = response.result.availableSections.find(section => section.sourceCount > 0);
  assert.ok(selectableSection, 'a populated nested folder is available as one optional section');
  const stateBeforeSectionReview = await message('get-state');
  response = await message('preview-shared-folder', {raw: JSON.stringify(sharedBundle), selectedFolderId: selectableSection.id});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.selectionMode, 'section');
  assert.strictEqual(response.result.independentExcerpt, true);
  assert.strictEqual(response.result.updateLinked, false);
  assert.strictEqual(response.result.selectedFolderPath, selectableSection.path);
  assert.strictEqual(response.result.publicationId, '');
  assert.strictEqual(response.result.updateUrl, '');
  assert.strictEqual(response.result.contents.root, selectableSection.id);
  assert.strictEqual(response.result.contents.sourceCount, selectableSection.sourceCount);
  const stateAfterSectionReview = await message('get-state');
  assert.strictEqual(stateAfterSectionReview.result._revision, stateBeforeSectionReview.result._revision, 'section review performs no write');
  assert.strictEqual(fetchCalls.length, fetchCountBeforeSharedPreview, 'shared-folder review performs no network request');

  const tamperedShared = JSON.parse(JSON.stringify(sharedBundle));
  tamperedShared.sources[0].title += ' tampered';
  response = await message('preview-shared-folder', {raw: JSON.stringify(tamperedShared)});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'INVALID_SHARED_FOLDER');

  const legacyShared = {
    schema: 'progrss.bundle.v1', exportedAt: sharedBundle.exportedAt, root: sharedBundle.root, title: sharedBundle.title,
    sources: sharedBundle.sources, collections: sharedBundle.collections
  };
  const advancedShared = JSON.parse(JSON.stringify(legacyShared));
  advancedShared.collections.find(collection => collection.id === advancedShared.root).mode = 'intersection';
  response = await message('preview-shared-folder', {raw: JSON.stringify(advancedShared)});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'ADVANCED_SHARED_FOLDER');

  const incomingShared = JSON.parse(JSON.stringify(legacyShared));
  const newRecipe = {
    id: 'shared-new-feed', title: 'Shared New Feed', type: 'rss', url: 'https://shared-new.test/feed.xml',
    mode: 'region', selector: '', titleSelector: '', linkSelector: '', include: '', exclude: '', threshold: 1,
    ignoreNumbers: false, version: 1, author: 'Harness curator'
  };
  incomingShared.sources.push(newRecipe, {...newRecipe, id: 'shared-new-feed-copy', title: 'Duplicate Shared New Feed'});
  incomingShared.collections.push({
    id: 'shared-sibling-folder', title: 'Sibling route', mode: 'union', include: '', exclude: '', version: 1,
    author: 'Harness curator', members: []
  });
  incomingShared.collections.find(collection => collection.id === incomingShared.root).members.push(
    {kind: 'source', id: newRecipe.id},
    {kind: 'source', id: 'shared-new-feed-copy'},
    {kind: 'collection', id: 'shared-sibling-folder'}
  );
  response = await message('preview-shared-folder', {raw: JSON.stringify(incomingShared)});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.newSources, 1);
  assert.strictEqual(response.result.duplicateInFileSources, 1);
  assert.strictEqual(response.result.reusedSources, sharedBundle.sources.length);
  assert.strictEqual(response.result.contents.sources.find(source => source.id === newRecipe.id).state, 'new-paused');
  assert.strictEqual(response.result.contents.sources.find(source => source.id === 'shared-new-feed-copy').state, 'same-incoming-source');
  assert.strictEqual(response.result.contents.sources.find(source => source.id === newRecipe.id).host, 'shared-new.test');
  const sharedReviewRevision = response.result.reviewedRevision;
  response = await message('import-shared-folder', {raw: JSON.stringify(incomingShared), reviewedRevision: sharedReviewRevision});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.importedSources, 1);
  assert.ok(response.result.rootId);
  const importedSharedRootId = response.result.rootId;
  response = await message('get-state');
  const addedSharedSource = response.result.sources.find(source => source.url === newRecipe.url);
  assert.ok(addedSharedSource, 'new shared-folder source was added');
  assert.strictEqual(addedSharedSource.enabled, false);
  assert.strictEqual(addedSharedSource.origin, 'shared-folder');
  const importedRoot = response.result.collections.find(collection => collection.id === importedSharedRootId);
  assert.ok(importedRoot, 'a separate reviewed folder tree was added');
  assert.strictEqual(importedRoot.members.filter(member => member.kind === 'source' && member.id === addedSharedSource.id).length, 1, 'duplicate incoming recipes collapse to one folder member');
  assert.strictEqual(importedRoot.sharedFolderOrigin.schema, 'progrss.shared-folder.origin.v2');
  assert.strictEqual(importedRoot.sharedFolderOrigin.baseline.schema, 'progrss.shared-folder.baseline.v1');
  assert.strictEqual(importedRoot.sharedFolderOrigin.signatureState, 'legacy');
  assert.strictEqual(importedRoot.sharedFolderOrigin.publicationId, legacyShared.root);
  assert.strictEqual(importedRoot.members.find(member => member.kind === 'source' && member.id === sourceId).reason, 'Primary reporting for this reading route.', 'native import preserves the direct-placement Source Note');

  // A later copy is reviewed as a three-way update. Local labels, reading
  // history, source state, and unrelated membership stay local.
  response = await message('rename-source', {sourceId, title: 'My local Harness label'});
  assert.strictEqual(response.ok, true);
  let continuityState = await globalThis.ProgRSSVault.init();
  const continuityRoot = continuityState.collections.find(collection => collection.id === importedSharedRootId);
  continuityRoot.title = 'My local shared folder';
  const continuityCollectionMap = new Map(continuityRoot.sharedFolderOrigin.baseline.collectionMap.map(row => [row.remoteId, row.localId]));
  const locallyReferencedRemovedFolderId = continuityCollectionMap.get(independent.id);
  const localSiblingFolderId = continuityCollectionMap.get('shared-sibling-folder');
  assert.ok(locallyReferencedRemovedFolderId && localSiblingFolderId, 'continuity baseline maps both shared folders');
  continuityState.collections.find(collection => collection.id === localSiblingFolderId).members.push({kind: 'collection', id: locallyReferencedRemovedFolderId});
  await globalThis.ProgRSSVault.save(continuityState);
  const updatedShared = JSON.parse(JSON.stringify(incomingShared));
  updatedShared.exportedAt = new Date(Date.parse(incomingShared.exportedAt) + 24 * 60 * 60 * 1000).toISOString();
  updatedShared.title = 'Harness shared folder, second edition';
  const changedSharedRecipe = updatedShared.sources.find(source => source.id === 'shared-new-feed');
  changedSharedRecipe.url = 'https://shared-new.test/feed-v2.xml';
  changedSharedRecipe.title = 'Shared New Feed v2';
  updatedShared.sources = updatedShared.sources.filter(source => source.id !== 'shared-new-feed-copy');
  const updatedRootRecipe = updatedShared.collections.find(collection => collection.id === updatedShared.root);
  updatedRootRecipe.members = updatedRootRecipe.members.filter(member => member.id !== 'shared-new-feed-copy' && member.id !== independent.id);
  const removedSharedFolder = updatedShared.collections.find(collection => collection.id === independent.id);
  const removedSharedSourceIds = new Set((removedSharedFolder?.members || []).filter(member => member.kind === 'source').map(member => member.id));
  updatedShared.collections = updatedShared.collections.filter(collection => collection.id !== independent.id);
  const stillReferencedSourceIds = new Set(updatedShared.collections.flatMap(collection => collection.members.filter(member => member.kind === 'source').map(member => member.id)));
  updatedShared.sources = updatedShared.sources.filter(source => !removedSharedSourceIds.has(source.id) || stillReferencedSourceIds.has(source.id));
  const addedUpdateRecipe = {
    id: 'shared-update-added', title: 'Added by update', type: 'rss', url: 'https://shared-added.test/feed.xml',
    mode: 'region', selector: '', titleSelector: '', linkSelector: '', include: '', exclude: '', threshold: 1,
    ignoreNumbers: false, version: 1, author: 'Harness curator'
  };
  updatedShared.sources.push(addedUpdateRecipe);
  updatedShared.collections.push({
    id: 'shared-update-folder', title: 'New route', mode: 'union', include: '', exclude: '', version: 1,
    author: 'Harness curator', members: [{kind: 'source', id: addedUpdateRecipe.id}]
  });
  updatedRootRecipe.members.push({kind: 'collection', id: 'shared-update-folder'});
  const fetchCountBeforeSharedUpdatePreview = fetchCalls.length;
  response = await message('preview-shared-folder', {raw: JSON.stringify(updatedShared)});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.schema, 'progrss.shared-folder-update.preview.v2');
  assert.strictEqual(response.result.mode, 'update');
  assert.strictEqual(response.result.canUpdate, true);
  assert.strictEqual(response.result.network, false);
  assert.strictEqual(response.result.writes, false);
  assert.strictEqual(response.result.changes.sourcesAdded, 1);
  assert.strictEqual(response.result.changes.sourceRecipesChanged, 1);
  assert.ok(response.result.changes.sourcesRemoved >= 2);
  assert.strictEqual(response.result.changes.foldersAdded, 1);
  assert.strictEqual(response.result.contents.schema, 'progrss.shared-folder.contents.v2');
  assert.strictEqual(response.result.contents.sources.find(source => source.id === addedUpdateRecipe.id).state, 'added-new-paused');
  assert.strictEqual(response.result.contents.folders.find(folder => folder.id === 'shared-update-folder').state, 'added');
  assert.ok(response.result.contents.sources.some(source => source.state === 'removed-from-list'), 'removed source names remain visible in update review');
  assert.strictEqual(response.result.contents.folders.find(folder => folder.id === independent.id).state, 'removed-from-list');
  assert.ok(response.result.contents.removedSourceCount >= 2);
  assert.strictEqual(response.result.contents.removedFolderCount, 1);
  assert.ok(response.result.localEdits.folderOverrides >= 1, 'local folder title is detected and kept');
  assert.strictEqual(response.result.mergeReview.schema, 'progrss.shared-folder-merge-review.v1');
  assert.strictEqual(response.result.mergeReview.counts.recipeChanges, 1);
  assert.strictEqual(response.result.requiresRecipeAcknowledgement, true);
  assert.strictEqual(fetchCalls.length, fetchCountBeforeSharedUpdatePreview, 'shared-folder update review performs no network request');
  const sharedUpdateReviewRevision = response.result.reviewedRevision;
  response = await message('update-shared-folder', {
    raw: JSON.stringify(updatedShared), reviewedRevision: sharedUpdateReviewRevision,
    targetRootId: importedSharedRootId, acknowledgeTrustChange: false,
    acknowledgeRecipeChanges: true, conflictChoices: {}
  });
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.updated, true);
  response = await message('get-state');
  const updatedLocalRoot = response.result.collections.find(collection => collection.id === importedSharedRootId);
  assert.strictEqual(updatedLocalRoot.title, 'My local shared folder', 'local folder label survives publication update');
  assert.strictEqual(updatedLocalRoot.sharedFolderOrigin.schema, 'progrss.shared-folder.origin.v2');
  assert.strictEqual(updatedLocalRoot.sharedFolderOrigin.baseline.sources.length, updatedShared.sources.length);
  const changedRecipeLocal = response.result.sources.find(source => source.url === changedSharedRecipe.url);
  const addedUpdateLocal = response.result.sources.find(source => source.url === addedUpdateRecipe.url);
  assert.ok(changedRecipeLocal && addedUpdateLocal, 'changed and added recipes become local sources');
  assert.strictEqual(changedRecipeLocal.enabled, false);
  assert.strictEqual(addedUpdateLocal.enabled, false);
  assert.ok(response.result.sources.some(source => source.url === newRecipe.url), 'the earlier source history is retained');
  assert.strictEqual(response.result.sources.find(source => source.id === sourceId).title, 'My local Harness label', 'local source label survives publication update');
  const retainedRemovedFolder = response.result.collections.find(collection => collection.id === locallyReferencedRemovedFolderId);
  const survivingSiblingFolder = response.result.collections.find(collection => collection.id === localSiblingFolderId);
  assert.ok(retainedRemovedFolder, 'a remotely removed folder remains when a surviving publication folder still refers to it locally');
  assert.ok(survivingSiblingFolder.members.some(member => member.kind === 'collection' && member.id === locallyReferencedRemovedFolderId));
  assert.strictEqual(response.result.sharedFolderUpdate.undoAvailable, true);
  response = await message('undo-shared-folder-update');
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  assert.strictEqual(response.result.collections.find(collection => collection.id === importedSharedRootId).title, 'My local shared folder');
  assert.ok(!response.result.sources.some(source => source.url === changedSharedRecipe.url), 'undo restores the exact earlier local library');
  assert.ok(!response.result.sources.some(source => source.url === addedUpdateRecipe.url));

  // A true three-way wording conflict has no implicit winner. The engine must
  // refuse application until one reviewed choice is supplied, then apply only
  // that choice and preserve the ability to undo the whole transaction.
  const conflictState = await globalThis.ProgRSSVault.init();
  const conflictRoot = conflictState.collections.find(collection => collection.id === importedSharedRootId);
  const conflictSourceRow = conflictRoot.sharedFolderOrigin.baseline.sourceMap.find(row => row.remoteId === 'shared-new-feed');
  assert.ok(conflictSourceRow, 'the imported source is present in the continuity baseline');
  const conflictLocalSource = conflictState.sources.find(source => source.id === conflictSourceRow.localId);
  conflictLocalSource.title = 'My local source wording';
  await globalThis.ProgRSSVault.save(conflictState);
  const conflictShared = JSON.parse(JSON.stringify(incomingShared));
  conflictShared.exportedAt = new Date(Date.parse(incomingShared.exportedAt) + 2 * 24 * 60 * 60 * 1000).toISOString();
  conflictShared.sources.find(source => source.id === 'shared-new-feed').title = 'Curator source wording';
  response = await message('preview-shared-folder', {raw: JSON.stringify(conflictShared)});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.mergeReview.counts.conflicts, 1);
  assert.strictEqual(response.result.requiresConflictChoices, true);
  const wordingConflict = response.result.mergeReview.conflicts[0];
  assert.strictEqual(wordingConflict.local, 'My local source wording');
  assert.strictEqual(wordingConflict.incoming, 'Curator source wording');
  response = await message('update-shared-folder', {
    raw: JSON.stringify(conflictShared), reviewedRevision: response.result.reviewedRevision,
    targetRootId: importedSharedRootId, conflictChoices: {}
  });
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'SHARED_FOLDER_CONFLICT_DECISION');
  response = await message('preview-shared-folder', {raw: JSON.stringify(conflictShared)});
  const conflictReviewRevision = response.result.reviewedRevision;
  const conflictId = response.result.mergeReview.conflicts[0].id;
  response = await message('update-shared-folder', {
    raw: JSON.stringify(conflictShared), reviewedRevision: conflictReviewRevision,
    targetRootId: importedSharedRootId, conflictChoices: {[conflictId]: 'use-curator'}
  });
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  assert.strictEqual(response.result.sources.find(source => source.id === conflictSourceRow.localId).title, 'Curator source wording');
  response = await message('undo-shared-folder-update');
  assert.strictEqual(response.ok, true);

  // A divergent Source Note has one placement-scoped decision ID. Unknown or
  // stale decisions are refused, and no note conflict receives an automatic
  // winner.
  const noteConflictState = await globalThis.ProgRSSVault.init();
  const noteConflictRoot = noteConflictState.collections.find(collection => collection.id === importedSharedRootId);
  const noteSourceMap = noteConflictRoot.sharedFolderOrigin.baseline.sourceMap.find(row => row.remoteId === sourceId);
  assert.ok(noteSourceMap, 'the reason-bearing source has a continuity mapping');
  const localNotePlacement = noteConflictRoot.members.find(member => member.kind === 'source' && member.id === noteSourceMap.localId);
  assert.ok(localNotePlacement, 'the local direct placement is available');
  localNotePlacement.reason = 'My later reason for this placement.';
  await globalThis.ProgRSSVault.save(noteConflictState);
  const noteConflictShared = JSON.parse(JSON.stringify(incomingShared));
  noteConflictShared.exportedAt = new Date(Date.parse(incomingShared.exportedAt) + 3 * 24 * 60 * 60 * 1000).toISOString();
  noteConflictShared.collections.find(collection => collection.id === noteConflictShared.root)
    .members.find(member => member.kind === 'source' && member.id === sourceId).reason = 'Curator’s later reason for this placement.';
  response = await message('preview-shared-folder', {raw: JSON.stringify(noteConflictShared)});
  assert.strictEqual(response.ok, true);
  const sourceNoteConflict = response.result.mergeReview.conflicts.find(row => row.kind === 'source-note');
  assert.ok(sourceNoteConflict, 'the divergent placement reason is shown as a Source Note conflict');
  assert.strictEqual(sourceNoteConflict.id, `placement:${incomingShared.root}:source:${sourceId}:reason`);
  assert.strictEqual(
    sourceNoteConflict.folderPath,
    response.result.contents.folders.find(folder => folder.id === incomingShared.root).path,
    'the conflict carries the full canonical folder route rather than only a repeated folder title'
  );
  assert.strictEqual(sourceNoteConflict.local, 'My later reason for this placement.');
  assert.strictEqual(sourceNoteConflict.incoming, 'Curator’s later reason for this placement.');
  const noteConflictRevision = response.result.reviewedRevision;
  response = await message('update-shared-folder', {
    raw: JSON.stringify(noteConflictShared), reviewedRevision: noteConflictRevision,
    targetRootId: importedSharedRootId, conflictChoices: {}
  });
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'SHARED_FOLDER_CONFLICT_DECISION');
  response = await message('preview-shared-folder', {raw: JSON.stringify(noteConflictShared)});
  const noteConflictReviewRevision = response.result.reviewedRevision;
  response = await message('update-shared-folder', {
    raw: JSON.stringify(noteConflictShared), reviewedRevision: noteConflictReviewRevision,
    targetRootId: importedSharedRootId,
    conflictChoices: {[sourceNoteConflict.id]: 'keep-local', 'placement:stale:source:stale:reason': 'keep-local'}
  });
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'SHARED_FOLDER_CONFLICT_STALE');
  response = await message('preview-shared-folder', {raw: JSON.stringify(noteConflictShared)});
  response = await message('update-shared-folder', {
    raw: JSON.stringify(noteConflictShared), reviewedRevision: response.result.reviewedRevision,
    targetRootId: importedSharedRootId, conflictChoices: {[sourceNoteConflict.id]: 'use-curator'}
  });
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  assert.strictEqual(response.result.collections.find(collection => collection.id === importedSharedRootId)
    .members.find(member => member.kind === 'source' && member.id === noteSourceMap.localId).reason, 'Curator’s later reason for this placement.');
  response = await message('undo-shared-folder-update');
  assert.strictEqual(response.ok, true);

  // A located publication is checked only from an explicit message. The check
  // fetches and verifies a copy, but performs no update transaction.
  const locatedLegacy = {
    schema: 'progrss.bundle.v1', exportedAt: '2026-10-18T23:00:00.000Z', root: 'located-root', title: 'Located route',
    sources: [{id: 'located-feed', title: 'Located feed', type: 'rss', url: 'https://located-source.test/feed.xml', mode: 'region', selector: '', titleSelector: '', linkSelector: '', include: '', exclude: '', threshold: 1, ignoreNumbers: false, version: 1, author: 'Harness'}],
    collections: [{id: 'located-root', title: 'Located route', mode: 'union', include: '', exclude: '', version: 1, author: 'Harness', members: [{kind: 'source', id: 'located-feed'}]}]
  };
  const locatedInitial = await globalThis.ProgRSSSharedFolder.create(globalThis.ProgRSSCore.validateBundle(locatedLegacy), {
    publicationId: 'located-publication', curator: 'Harness Garden', note: 'Checked only on request.',
    updateUrl: 'https://example.test/publications/located.json', exportedAt: '2026-10-18T23:00:00.000Z'
  });
  publicationPayload = JSON.stringify(locatedInitial);
  fetchMode = 'publication';
  const pageReviewFetches = fetchCalls.length;
  response = await message('review-shared-folder-url', {
    pageUrl: 'https://example.test/publications/index.html',
    url: 'https://example.test/publications/located.json'
  });
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.preview.network, true);
  assert.strictEqual(response.result.preview.writes, false);
  assert.strictEqual(response.result.preview.canImport, true);
  assert.strictEqual(response.result.remote.sourcePageUrl, 'https://example.test/publications/index.html');
  assert.strictEqual(response.result.remote.automatic, false);
  assert.strictEqual(fetchCalls.length, pageReviewFetches + 1, 'page-advertised folder is fetched only after the explicit review message');
  // A person may also paste the exact JSON address. Recognition depends on the
  // validated native schema, not a friendly media type or .json suffix.
  publicationContentType = 'text/plain; charset=utf-8';
  const directAddressFetches = fetchCalls.length;
  response = await message('inspect-url', {url: 'https://example.test/publications/located.json'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.kind, 'shared-folder');
  assert.strictEqual(response.result.preview.network, true);
  assert.strictEqual(response.result.preview.writes, false);
  assert.strictEqual(response.result.preview.canImport, true);
  assert.strictEqual(response.result.remote.directAddress, true);
  assert.strictEqual(response.result.remote.automatic, false);
  assert.strictEqual(response.result.remote.credentials, 'omitted');
  assert.strictEqual(fetchCalls.length, directAddressFetches + 1, 'direct address is fetched once from the explicit inspect action');
  assert.strictEqual(fetchCalls.at(-1).options.credentials, 'omit');
  assert.match(fetchCalls.at(-1).options.headers.Accept, /progrss\.shared-folder/);
  publicationContentType = 'text/plain; charset=windows-1252';
  response = await message('inspect-url', {url: 'https://example.test/publications/located.json'});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'INVALID_SHARED_FOLDER');
  assert.match(response.error, /UTF-8 JSON/);
  publicationContentType = 'application/vnd.progrss.shared-folder+json; charset=utf-8';
  const crossOriginReviewFetches = fetchCalls.length;
  response = await message('review-shared-folder-url', {
    pageUrl: 'https://other.test/publications/index.html',
    url: 'https://example.test/publications/located.json'
  });
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'SHARED_FOLDER_DISCOVERY_CROSS_ORIGIN');
  assert.strictEqual(fetchCalls.length, crossOriginReviewFetches, 'cross-site advertisement is refused before network access');
  fetchMode = 'normal';
  response = await message('preview-shared-folder', {raw: JSON.stringify(locatedInitial)});
  assert.strictEqual(response.ok, true);
  const locatedReviewRevision = response.result.reviewedRevision;
  response = await message('import-shared-folder', {raw: JSON.stringify(locatedInitial), reviewedRevision: locatedReviewRevision});
  assert.strictEqual(response.ok, true);
  const locatedLocalRootId = response.result.rootId;
  const locatedLaterLegacy = JSON.parse(JSON.stringify(locatedLegacy));
  locatedLaterLegacy.exportedAt = '2026-10-19T23:00:00.000Z';
  locatedLaterLegacy.sources.push({id: 'located-added', title: 'Added later', type: 'rss', url: 'https://located-source.test/added.xml', mode: 'region', selector: '', titleSelector: '', linkSelector: '', include: '', exclude: '', threshold: 1, ignoreNumbers: false, version: 1, author: 'Harness'});
  locatedLaterLegacy.collections[0].members.push({kind: 'source', id: 'located-added'});
  const locatedLater = await globalThis.ProgRSSSharedFolder.create(globalThis.ProgRSSCore.validateBundle(locatedLaterLegacy), {
    publicationId: 'located-publication', curator: 'Harness Garden', note: 'A later copy.',
    updateUrl: 'https://example.test/publications/located.json', exportedAt: '2026-10-19T23:00:00.000Z'
  });
  publicationPayload = JSON.stringify(locatedLater);
  fetchMode = 'publication';
  const locatedStateBefore = await message('get-state');
  const locatedSourcesBefore = locatedStateBefore.result.sources.length;
  const fetchCountBeforePublicationCheck = fetchCalls.length;
  response = await message('check-shared-folder-update', {collectionId: locatedLocalRootId});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.preview.network, true);
  assert.strictEqual(response.result.preview.writes, false);
  assert.strictEqual(response.result.preview.canUpdate, true);
  assert.strictEqual(response.result.remote.automatic, false);
  assert.strictEqual(response.result.remote.credentials, 'omitted');
  assert.strictEqual(fetchCalls.length, fetchCountBeforePublicationCheck + 1);
  assert.strictEqual(fetchCalls.at(-1).options.credentials, 'omit');
  assert.match(fetchCalls.at(-1).options.headers.Accept, /progrss\.shared-folder/);
  const locatedStateAfter = await message('get-state');
  assert.strictEqual(locatedStateAfter.result.sources.length, locatedSourcesBefore, 'manual check does not apply or create sources');
  assert.ok(!locatedStateAfter.result.sources.some(source => source.url === 'https://located-source.test/added.xml'));
  fetchMode = 'normal';

  // The same source can carry a different reason in a second direct folder.
  // Editing that second placement must not change the first placement.
  response = await message('add-source-to-folder', {sourceId, collectionId: independent.id});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.added, true);
  response = await message('set-source-placement-reason', {
    sourceId, collectionId: independent.id, expectedVersion: response.result.folderVersion,
    expectedReason: null, reason: 'Hands-on references for the nested practical route.'
  });
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  const readingReasonAfterSecondPlacement = response.result.collections.find(collection => collection.id === reading.id)
    .members.find(member => member.kind === 'source' && member.id === sourceId).reason;
  const independentReason = response.result.collections.find(collection => collection.id === independent.id)
    .members.find(member => member.kind === 'source' && member.id === sourceId).reason;
  assert.strictEqual(readingReasonAfterSecondPlacement, sourceNoteText);
  assert.strictEqual(independentReason, 'Hands-on references for the nested practical route.');
  response = await message('remove-source-from-folder', await folderRemovalReview(sourceId, independent.id));
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.removed, true);
  response = await message('get-state');
  assert.strictEqual(
    response.result.collections.find(collection => collection.id === reading.id)
      .members.find(member => member.kind === 'source' && member.id === sourceId).reason,
    sourceNoteText,
    'removing the second placement leaves the first placement reason intact'
  );

  response = await message('add-source', {url: 'https://unfiled.test/feed.xml', title: 'Unfiled Notes', type: 'rss'});
  assert.strictEqual(response.ok, true);
  const otherSource = response.result.source;
  response = await message('add-source-to-folder', {sourceId: otherSource.id, collectionId: independent.id});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.added, true);
  assert.strictEqual(response.result.folderPath, 'Reading › Independent');
  assert.deepStrictEqual(response.result.membership.inherited.map(row => row.path), ['Reading']);
  const folderVersion = response.result.folderVersion;
  response = await message('undo-source-folder-add', {sourceId: otherSource.id, collectionId: independent.id, expectedVersion: folderVersion - 1});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'STALE_FOLDER_UNDO');
  response = await message('undo-source-folder-add', {sourceId: otherSource.id, collectionId: independent.id, expectedVersion: folderVersion});
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  const independentAfterUndo = response.result.collections.find(collection => collection.id === independent.id);
  assert.ok(!independentAfterUndo.members.some(member => member.kind === 'source' && member.id === otherSource.id));

  response = await message('add-source-to-folder', {sourceId: otherSource.id, collectionId: independent.id});
  assert.strictEqual(response.ok, true);
  response = await message('remove-source-from-folder', await folderRemovalReview(otherSource.id, reading.id));
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'STALE_FOLDER_REMOVE');
  response = await message('remove-source-from-folder', await folderRemovalReview(otherSource.id, independent.id));
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.removed, true);
  assert.deepStrictEqual(response.result.membership.inherited, []);
  const removedVersion = response.result.folderVersion;
  const removedPlacement = {removedMember: response.result.removedMember, removedIndex: response.result.removedIndex, expectedRevision: response.result.expectedRevision};
  response = await message('undo-source-folder-remove', {sourceId: otherSource.id, collectionId: independent.id, ...removedPlacement, expectedVersion: removedVersion - 1});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'STALE_FOLDER_UNDO');
  response = await message('undo-source-folder-remove', {sourceId: otherSource.id, collectionId: independent.id, ...removedPlacement, expectedVersion: removedVersion});
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  assert.ok(response.result.collections.find(collection => collection.id === independent.id).members.some(member => member.kind === 'source' && member.id === otherSource.id));

  response = await message('toggle-source', {sourceId, enabled: false});
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  assert.strictEqual(response.result.sources[0].enabled, false);

  response = await message('add-source', {url: 'https://large.test/feed.xml', title: 'Large Feed', type: 'rss'});
  assert.strictEqual(response.ok, true);
  fetchMode = 'large';
  const largeSourceId = response.result.source.id;
  response = await message('refresh-source', {sourceId: largeSourceId});
  assert.strictEqual(response.ok, false);
  assert.match(response.error, /larger than the 2 MB/i);
  response = await message('get-state');
  const failed = response.result.sources.find(source => source.id === largeSourceId);
  assert.ok(failed.lastProblemAt, 'problem time is recorded');
  assert.match(failed.lastProblem, /larger than the 2 MB/i);

  response = await message('export-private-backup');
  assert.strictEqual(response.ok, true);
  assert.match(response.result.fileName, /^ProgRSS-library-\d{4}-\d{2}-\d{2}\.json$/);
  const exported = JSON.parse(response.result.raw);
  assert.strictEqual(exported.schema, 'progrss.private.v1');
  assert.strictEqual(exported.purpose, 'library-transfer');
  assert.strictEqual(exported.producer.version, '0.80.0');
  assert.strictEqual(exported.producer.revision, 'rev0080');
  assert.strictEqual(exported.state.version, 17);
  assert.ok(!Object.hasOwn(exported.state, '_revision'));
  assert.ok(!Object.hasOwn(exported.state, 'transferUndo'));
  assert.ok(!Object.hasOwn(exported.state, 'sourceRepairUndo'));
  assert.ok(!Object.hasOwn(exported.state, 'receiptRetirementUndo'));
  assert.ok(!Object.hasOwn(exported.state, 'sharedFolderUpdateUndo'));

  const beforeTransfer = await message('get-state');
  const beforeSourceCount = beforeTransfer.result.sources.length;
  const incoming = {
    schema: 'progrss.private.v1',
    exportedAt: '2026-10-18T05:00:00Z',
    producer: {name: 'ProgRSS', version: '0.80.0', revision: 'rev0080'},
    state: {
      version: 13,
      sources: [
        {id: 'incoming-active', title: 'Incoming Active', type: 'rss', url: 'https://new.test/feed.xml', enabled: true, archivedAt: ''},
        {id: 'incoming-paused', title: 'Incoming Paused', type: 'rss', url: 'https://paused.test/feed.xml', enabled: false, archivedAt: ''}
      ],
      collections: [
        {id: 'incoming-alpha', title: 'Incoming Alpha', mode: 'union', version: 1, members: [
          {kind: 'source', id: 'incoming-active', reason: 'Reason for Alpha.\nSecond line.'},
          {kind: 'source', id: 'incoming-paused'}
        ]},
        {id: 'incoming-beta', title: 'Incoming Beta', mode: 'union', version: 1, members: [
          {kind: 'source', id: 'incoming-active', reason: 'Reason for Beta.'}
        ]}
      ],
      items: [{id: 'incoming-active|one', sourceId: 'incoming-active', title: 'Moved update', url: 'https://new.test/one', summary: 'Private reading text', observedAt: '2026-10-18T05:00:00Z', readAt: '', starred: true}],
      snapshots: {}, fixtures: [], inbox: [], receipts: [], subscriptions: [], publications: [], patchPins: [], keyRotations: [],
      recoveryPolicies: [], recoveryReceipts: [], charterHistory: [], charterClaims: [], gossipCards: [], witnessPins: [],
      merklePins: [], merkleReceipts: [], proofRequests: [], proofSightings: [], proofForks: [], fixturePacks: []
    }
  };
  const incomingRaw = JSON.stringify(incoming);
  const oversizedAdvanced = JSON.parse(incomingRaw);
  oversizedAdvanced.state.fixtures = Array.from({length: 17}, (_, index) => ({id: `too-many-${index}`}));
  response = await message('preview-private-backup', {raw: JSON.stringify(oversizedAdvanced)});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'INVALID_BACKUP');
  assert.match(response.error, /too many fixtures/i);

  const invalidPageChange = JSON.parse(incomingRaw);
  invalidPageChange.state.items[0].change = {
    schema: 'progrss.page-change.v1',
    kind: 'text-changed',
    mode: 'region',
    before: 'x'.repeat(1201),
    after: 'Changed text'
  };
  response = await message('preview-private-backup', {raw: JSON.stringify(invalidPageChange)});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'INVALID_BACKUP');
  assert.match(response.error, /page-change explanation/i);

  const nestedPageChange = JSON.parse(incomingRaw);
  nestedPageChange.state.items[0].change = {
    schema: 'progrss.page-change.v1', kind: 'text-changed', mode: 'region',
    before: 'Before', after: 'After', diagnostics: {rawDom: 'not portable'}
  };
  response = await message('preview-private-backup', {raw: JSON.stringify(nestedPageChange)});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'INVALID_BACKUP');
  assert.match(response.error, /page-change explanation/i);

  response = await message('preview-private-backup', {raw: incomingRaw});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.incoming.sources, 2);
  assert.strictEqual(response.result.incoming.sourceNotes, 2);
  assert.strictEqual(response.result.current.sources, beforeSourceCount);
  assert.strictEqual(response.result.permissions.reconnectSources, 1);
  assert.strictEqual(response.result.permissions.reconnectOrigins, 1);
  assert.strictEqual(response.result.willKeepUndo, true);
  assert.strictEqual(response.result.undoMinutes, 30);
  const staleRevision = response.result.reviewedRevision;
  assert.ok(Number.isSafeInteger(staleRevision));

  response = await message('toggle-source', {sourceId: largeSourceId, enabled: false});
  assert.strictEqual(response.ok, true);
  response = await message('restore-private-backup', {raw: incomingRaw, reviewedRevision: staleRevision});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'TRANSFER_REVIEW_STALE');

  response = await message('preview-private-backup', {raw: incomingRaw});
  assert.strictEqual(response.ok, true);
  response = await message('restore-private-backup', {raw: incomingRaw, reviewedRevision: response.result.reviewedRevision});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.undoAvailable, true);
  response = await message('get-state');
  assert.deepStrictEqual(response.result.sources.map(source => source.id), ['incoming-active', 'incoming-paused']);
  assert.strictEqual(response.result.collections.find(row => row.id === 'incoming-alpha').members[0].reason, 'Reason for Alpha.\nSecond line.');
  assert.strictEqual(response.result.collections.find(row => row.id === 'incoming-beta').members[0].reason, 'Reason for Beta.');
  assert.ok(!Object.hasOwn(response.result.collections.find(row => row.id === 'incoming-alpha').members[1], 'reason'));
  assert.strictEqual(response.result.sources[0].permissionMissing, true);
  assert.strictEqual(response.result.sources[0].permissionMissingReason, 'transfer');
  assert.ok(!response.result.sources[1].permissionMissing, 'paused sources stay paused without a reconnect badge');
  assert.strictEqual(response.result.transfer.undoAvailable, true);
  assert.strictEqual(response.result.transfer.previous.sources, beforeSourceCount);

  response = await message('export-private-backup');
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.summary.sourceNotes, 2);
  assert.ok(!Object.hasOwn(JSON.parse(response.result.raw).state, 'transferUndo'), 'a transfer file never nests the local safety copy');

  response = await message('undo-private-backup-restore');
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  assert.strictEqual(response.result.sources.length, beforeSourceCount);
  assert.strictEqual(response.result.transfer.undoAvailable, false);

  // A reviewed same-source repair keeps the selected source's operational
  // context, merges reading history and folders, and remains locally undoable.
  const repairState = await globalThis.ProgRSSVault.init();
  const repairOriginal = repairState.sources.find(source => source.id === sourceId);
  assert.ok(repairOriginal, 'original source remains available for repair fixture');
  repairOriginal.enabled = true;
  repairOriginal.url = 'https://example.test/feed.xml';
  repairOriginal.declaredFeedUrl = 'https://example.test/feed.xml';
  repairOriginal.httpCache = {etag: '"survivor-etag"'};
  repairOriginal.pulse = {nextAt: '2026-10-19T12:00:00.000Z'};
  repairOriginal.lastSuccessfulAt = '2026-10-18T10:00:00.000Z';
  repairOriginal.lastNewAt = '2026-10-18T09:00:00.000Z';
  const originalItem = repairState.items.find(item => item.sourceId === sourceId);
  assert.ok(originalItem, 'original item remains available for repair fixture');
  originalItem.id = `${sourceId}|entry-1`;
  originalItem.entryKey = `${sourceId}|entry-1`;
  originalItem.feedRevision = 0;
  originalItem.readAt = '';
  originalItem.starred = true;
  repairState.sources.push({
    id: 'repair-copy', title: 'Harness Feed copy', type: 'rss',
    url: 'https://example.test/alternate.xml', declaredFeedUrl: 'https://example.test/feed.xml',
    enabled: false, archivedAt: '', createdAt: '2026-10-16T08:00:00.000Z',
    lastSuccessfulAt: '2026-10-17T08:00:00.000Z', lastNewAt: '2026-10-17T07:00:00.000Z',
    lastProblemAt: '2026-10-17T06:00:00.000Z', lastProblem: 'Earlier timeout',
    checkCount: 3, httpCache: {lastModified: 'Fri, 17 Oct 2026 08:00:00 GMT'},
    pulse: {nextAt: '2026-10-20T12:00:00.000Z'}
  });
  repairState.items.push(
    {
      ...originalItem,
      id: 'repair-copy|entry-1', entryKey: 'repair-copy|entry-1', sourceId: 'repair-copy',
      readAt: '2026-10-18T11:00:00.000Z', starred: false, observedAt: '2026-10-18T09:10:00.000Z'
    },
    {
      id: 'repair-copy|entry-2', entryKey: 'repair-copy|entry-2', feedRevision: 0,
      sourceId: 'repair-copy', title: 'A second retained entry', url: 'https://example.test/post/2',
      summary: 'Only in the copy history', published: '2026-10-18T08:00:00.000Z',
      observedAt: '2026-10-18T08:01:00.000Z', kind: 'new', readAt: '', starred: false
    }
  );
  repairState.collections.push({
    id: 'repair-folder', title: 'Repair review', mode: 'union', version: 1,
    members: [{kind: 'source', id: sourceId}, {kind: 'source', id: 'repair-copy'}]
  });
  await globalThis.ProgRSSVault.save(repairState);

  const blockedRepairState = await globalThis.ProgRSSVault.init();
  blockedRepairState.receipts.push(
    {
      id: 'advanced-repair-reference', schema: 'progrss.recipe.graft.receipt.v1',
      title: 'Reviewed garden graft', sourceId: 'repair-copy',
      evidence: {retainedItemId: originalItem.id, companionItemId: 'repair-copy|entry-2'}
    },
    {
      id: 'invalid-unicode-graft', schema: 'progrss.recipe.graft.receipt.v1',
      title: 'Invalid Unicode graft', sourceId: 'repair-copy',
      note: String.fromCharCode(0xD800)
    }
  );
  await globalThis.ProgRSSVault.save(blockedRepairState);

  // A digest is portable evidence only when both runtimes can represent the
  // same Unicode scalar data. RFC 8785-style lone surrogates are refused.
  response = await message('source-repair-references', {firstSourceId: sourceId, secondSourceId: 'repair-copy'});
  assert.strictEqual(response.ok, true);
  const invalidUnicodeReceipt = response.result.groups[0].records.find(row => row.recordId === 'invalid-unicode-graft');
  assert.ok(invalidUnicodeReceipt?.retirement?.eligible);
  response = await message('preview-graft-receipt-retirement', {
    firstSourceId: sourceId,
    secondSourceId: 'repair-copy',
    recordIndex: invalidUnicodeReceipt.index,
    recordId: invalidUnicodeReceipt.recordId
  });
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'RECEIPT_NOT_CANONICAL');
  const canonicalRepairState = await globalThis.ProgRSSVault.init();
  canonicalRepairState.receipts = canonicalRepairState.receipts.filter(row => row.id !== 'invalid-unicode-graft');
  await globalThis.ProgRSSVault.save(canonicalRepairState);

  response = await message('preview-source-repair', {firstSourceId: sourceId, secondSourceId: 'repair-copy'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.canRepair, false);
  assert.strictEqual(response.result.advancedReferences[0].key, 'receipts');
  assert.strictEqual(response.result.advancedReferences[0].count, 3);
  assert.strictEqual(response.result.referenceReport.summary.blockingRecords, 1);
  assert.strictEqual(response.result.referenceReport.summary.sourceHistoryReferences, 1);
  assert.strictEqual(response.result.referenceReport.summary.retainedUpdateReferences, 2);
  assert.ok(response.result.blockers[0].includes('References to these histories'));
  response = await message('source-repair-references', {firstSourceId: sourceId, secondSourceId: 'repair-copy'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.schema, 'progrss.source-reference-report.v1');
  assert.deepStrictEqual(response.result.sharedAddresses, ['https://example.test/feed.xml']);
  assert.strictEqual(response.result.network, false);
  assert.strictEqual(response.result.writes, false);
  assert.strictEqual(response.result.browserProfileRead, false);
  assert.strictEqual(response.result.groups[0].label, 'Receipts');
  assert.strictEqual(response.result.groups[0].records[0].title, 'Reviewed garden graft');
  assert.strictEqual(response.result.groups[0].records[0].schema, 'progrss.recipe.graft.receipt.v1');
  assert.ok(response.result.groups[0].records[0].references.some(row => row.targetId === 'repair-copy'));
  assert.ok(response.result.groups[0].records[0].references.some(row => row.targetId === originalItem.id));
  assert.ok(response.result.groups[0].records[0].references.flatMap(row => row.paths).includes('$["sourceId"]'));
  assert.strictEqual(response.result.groups[0].records[0].retirement.eligible, true);
  assert.strictEqual(response.result.groups[0].records[0].retirement.action, 'retire-graft-receipt');

  // The only meaning-preserving cleanup in this release moves the exact graft
  // receipt out of active history while retaining an immutable, digest-bound
  // copy as retired evidence. A stale review never crosses newer work.
  const retirementPayload = {
    firstSourceId: sourceId,
    secondSourceId: 'repair-copy',
    recordIndex: response.result.groups[0].records[0].index,
    recordId: response.result.groups[0].records[0].recordId
  };
  response = await message('preview-graft-receipt-retirement', retirementPayload);
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.schema, 'progrss.graft-receipt.retirement.preview.v1');
  assert.strictEqual(response.result.canRetire, true);
  assert.strictEqual(response.result.network, false);
  assert.strictEqual(response.result.permissionRequest, false);
  assert.match(response.result.receipt.digest, /^[0-9a-f]{64}$/);
  assert.strictEqual(response.result.receipt.referenceCount, 3);
  const staleRetirement = response.result;
  response = await message('set-item', {itemId: originalItem.id, starred: false});
  assert.strictEqual(response.ok, true);
  response = await message('retire-graft-receipt', {
    ...retirementPayload,
    reviewedRevision: staleRetirement.reviewedRevision,
    expectedDigest: staleRetirement.receipt.digest
  });
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'RECEIPT_REVIEW_STALE');
  response = await message('set-item', {itemId: originalItem.id, starred: true});
  assert.strictEqual(response.ok, true);

  response = await message('preview-graft-receipt-retirement', retirementPayload);
  assert.strictEqual(response.ok, true);
  const reviewedRetirement = response.result;
  response = await message('retire-graft-receipt', {
    ...retirementPayload,
    reviewedRevision: reviewedRetirement.reviewedRevision,
    expectedDigest: reviewedRetirement.receipt.digest
  });
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.undoAvailable, true);
  assert.match(response.result.retirementId, /^retired-graft-/);
  let retirementState = await globalThis.ProgRSSVault.init();
  assert.strictEqual(retirementState.receipts.some(row => row.id === 'advanced-repair-reference'), false);
  assert.strictEqual(retirementState.retiredReceipts.length, 1);
  assert.strictEqual(retirementState.retiredReceipts[0].schema, 'progrss.retired.graft-receipt.v1');
  assert.strictEqual(retirementState.retiredReceipts[0].originalDigest, reviewedRetirement.receipt.digest);
  assert.deepStrictEqual(retirementState.retiredReceipts[0].originalReceipt, blockedRepairState.receipts.find(row => row.id === 'advanced-repair-reference'));

  response = await message('source-repair-references', {firstSourceId: sourceId, secondSourceId: 'repair-copy'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.summary.blockingRecords, 0);
  assert.strictEqual(response.result.summary.retiredRecords, 1);
  assert.strictEqual(response.result.retiredEvidence[0].originalDigest, reviewedRetirement.receipt.digest);
  assert.strictEqual(response.result.retirementUndo.undoAvailable, true);
  response = await message('export-private-backup');
  assert.strictEqual(response.ok, true);
  const retirementExport = JSON.parse(response.result.raw).state;
  assert.strictEqual(retirementExport.retiredReceipts.length, 1);
  assert.ok(!Object.hasOwn(retirementExport, 'receiptRetirementUndo'));

  response = await message('undo-graft-receipt-retirement');
  assert.strictEqual(response.ok, true);
  retirementState = await globalThis.ProgRSSVault.init();
  assert.strictEqual(retirementState.receipts.some(row => row.id === 'advanced-repair-reference'), true);
  assert.strictEqual(retirementState.retiredReceipts.length, 0);

  // Retire it once more so the same-source repair can proceed. The later repair
  // intentionally ends the separate retirement undo while preserving evidence.
  response = await message('source-repair-references', {firstSourceId: sourceId, secondSourceId: 'repair-copy'});
  assert.strictEqual(response.ok, true);
  const activeReceipt = response.result.groups[0].records[0];
  const secondRetirementPayload = {
    firstSourceId: sourceId,
    secondSourceId: 'repair-copy',
    recordIndex: activeReceipt.index,
    recordId: activeReceipt.recordId
  };
  response = await message('preview-graft-receipt-retirement', secondRetirementPayload);
  assert.strictEqual(response.ok, true);
  response = await message('retire-graft-receipt', {
    ...secondRetirementPayload,
    reviewedRevision: response.result.reviewedRevision,
    expectedDigest: response.result.receipt.digest
  });
  assert.strictEqual(response.ok, true);

  response = await message('preview-source-repair', {firstSourceId: sourceId, secondSourceId: 'repair-copy'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.canRepair, true);
  assert.deepStrictEqual(response.result.sharedAddresses, ['https://example.test/feed.xml']);
  assert.strictEqual(response.result.sources.length, 2);
  assert.strictEqual(response.result.sources.find(source => source.id === sourceId).validators.etag, true);
  assert.strictEqual(response.result.sources.find(source => source.id === 'repair-copy').validators.lastModified, true);
  const staleRepairRevision = response.result.reviewedRevision;
  response = await message('set-item', {itemId: originalItem.id, starred: true});
  assert.strictEqual(response.ok, true);
  response = await message('repair-same-source', {
    firstSourceId: sourceId, secondSourceId: 'repair-copy', survivorId: sourceId,
    reviewedRevision: staleRepairRevision
  });
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'SOURCE_REPAIR_STALE');

  response = await message('preview-source-repair', {firstSourceId: sourceId, secondSourceId: 'repair-copy'});
  assert.strictEqual(response.ok, true);
  response = await message('repair-same-source', {
    firstSourceId: sourceId, secondSourceId: 'repair-copy', survivorId: sourceId,
    reviewedRevision: response.result.reviewedRevision
  });
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.itemMerge.afterCount, 2);
  assert.strictEqual(response.result.itemMerge.exactRepeatsCollapsed, 1);
  assert.strictEqual(response.result.changedCollections, 1);

  response = await message('get-state');
  assert.strictEqual(response.result.sources.some(source => source.id === 'repair-copy'), false);
  const repaired = response.result.sources.find(source => source.id === sourceId);
  assert.strictEqual(repaired.url, 'https://example.test/feed.xml');
  assert.strictEqual(repaired.httpCache.etag, '"survivor-etag"');
  assert.strictEqual(repaired.httpCache.lastModified, undefined, 'the removed source validator is not pooled');
  assert.strictEqual(repaired.pulse.nextAt, '2026-10-19T12:00:00.000Z');
  assert.ok(repaired.aliasUrls.includes('https://example.test/alternate.xml'));
  assert.strictEqual(repaired.repairHistory.at(-1).sourceId, 'repair-copy');
  const repairedItems = response.result.items.filter(item => item.sourceId === sourceId);
  assert.strictEqual(repairedItems.length, 2);
  const repairedRepeat = repairedItems.find(item => item.url === 'https://example.test/post/1');
  assert.strictEqual(repairedRepeat.readAt, '', 'unread wins when an exact repeat is collapsed');
  assert.strictEqual(repairedRepeat.starred, true, 'saved wins when an exact repeat is collapsed');
  const repairFolder = response.result.collections.find(collection => collection.id === 'repair-folder');
  assert.deepStrictEqual(repairFolder.members, [{kind: 'source', id: sourceId}]);
  assert.strictEqual(response.result.sourceRepair.undoAvailable, true);
  assert.strictEqual(response.result.receiptRetirement.undoAvailable, false, 'source repair ends the separate receipt-retirement undo');

  response = await message('export-private-backup');
  assert.strictEqual(response.ok, true);
  const repairedExport = JSON.parse(response.result.raw).state;
  assert.ok(!Object.hasOwn(repairedExport, 'sourceRepairUndo'), 'a transfer file never carries local source-repair undo state');
  assert.ok(!Object.hasOwn(repairedExport, 'receiptRetirementUndo'), 'a transfer file never carries local receipt-retirement undo state');
  assert.strictEqual(repairedExport.retiredReceipts.length, 1, 'retired evidence remains portable after repair');

  response = await message('undo-source-repair');
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  assert.strictEqual(response.result.sources.some(source => source.id === 'repair-copy'), true);
  assert.strictEqual(response.result.items.filter(item => item.sourceId === 'repair-copy').length, 2);
  assert.strictEqual(response.result.sourceRepair.undoAvailable, false);

  // A later reading mutation must make the bounded undo refuse rather than
  // replacing the newer state with the pre-repair snapshot.
  response = await message('preview-source-repair', {firstSourceId: sourceId, secondSourceId: 'repair-copy'});
  assert.strictEqual(response.ok, true);
  response = await message('repair-same-source', {
    firstSourceId: sourceId, secondSourceId: 'repair-copy', survivorId: sourceId,
    reviewedRevision: response.result.reviewedRevision
  });
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  const postRepairItem = response.result.items.find(item => item.sourceId === sourceId);
  assert.ok(postRepairItem, 'repaired source retains at least one update');
  response = await message('set-item', {itemId: postRepairItem.id, starred: false});
  assert.strictEqual(response.ok, true);
  response = await message('undo-source-repair');
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'SOURCE_REPAIR_UNDO_STALE');
  response = await message('get-state');
  assert.strictEqual(response.result.sources.some(source => source.id === 'repair-copy'), false, 'stale undo keeps the merged source');
  assert.strictEqual(response.result.items.find(item => item.id === postRepairItem.id).starred, false, 'stale undo keeps newer reading state');
  assert.strictEqual(response.result.sourceRepair.undoAvailable, false);

  // One reviewed nested branch becomes an independent local excerpt. It has
  // no parent publication origin or future-copy continuity claim.
  const branchBundle = {
    schema: 'progrss.bundle.v1', exportedAt: '2026-10-19T10:00:00.000Z', root: 'branch-parent', title: 'Branch parent',
    sources: [
      {id: 'branch-root-feed', title: 'Parent-only feed', type: 'rss', url: 'https://branch-parent.test/feed.xml', mode: 'region', selector: '', titleSelector: '', linkSelector: '', include: '', exclude: '', threshold: 1, ignoreNumbers: false, version: 1, author: 'Harness'},
      {id: 'branch-child-watch', title: 'Selected page', type: 'page', url: 'https://branch-child.test/notices', mode: 'cards', selector: 'article', titleSelector: 'h2', linkSelector: 'a[href]', include: '', exclude: '', threshold: 2, ignoreNumbers: false, version: 1, author: 'Harness'}
    ],
    collections: [
      {id: 'branch-parent', title: 'Branch parent', mode: 'union', include: '', exclude: '', version: 1, author: 'Harness', members: [{kind: 'source', id: 'branch-root-feed'}, {kind: 'collection', id: 'branch-child'}]},
      {id: 'branch-child', title: 'Selected section', mode: 'union', include: '', exclude: '', version: 1, author: 'Harness', members: [{kind: 'source', id: 'branch-child-watch'}]}
    ]
  };
  const branchFetchesBefore = fetchCalls.length;
  response = await message('preview-shared-folder', {raw: JSON.stringify(branchBundle), selectedFolderId: 'branch-child'});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.independentExcerpt, true);
  assert.strictEqual(response.result.sourceCount, 1);
  assert.strictEqual(response.result.pageWatchCount, 1);
  assert.strictEqual(response.result.updateLinked, false);
  const branchReviewRevision = response.result.reviewedRevision;
  response = await message('import-shared-folder', {
    raw: JSON.stringify(branchBundle), reviewedRevision: branchReviewRevision, selectedFolderId: 'branch-child'
  });
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.importedSources, 1);
  assert.strictEqual(response.result.importedFolders, 1);
  assert.strictEqual(response.result.independentExcerpt, true);
  const branchLocalRootId = response.result.rootId;
  response = await message('get-state');
  const branchLocalRoot = response.result.collections.find(collection => collection.id === branchLocalRootId);
  const branchLocalSource = response.result.sources.find(source => source.url === 'https://branch-child.test/notices');
  assert.ok(branchLocalRoot && branchLocalSource);
  assert.strictEqual(branchLocalSource.enabled, false);
  assert.strictEqual(branchLocalSource.origin, 'shared-folder-section');
  assert.strictEqual(Object.hasOwn(branchLocalRoot, 'sharedFolderOrigin'), false);
  assert.strictEqual(response.result.sources.some(source => source.url === 'https://branch-parent.test/feed.xml'), false);
  assert.strictEqual(fetchCalls.length, branchFetchesBefore, 'branch review and import contact no listed site');
  response = await message('preview-shared-folder', {raw: JSON.stringify(branchBundle)});
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.schema, 'progrss.shared-folder.preview.v3', 'the independent excerpt is not mistaken for an updateable parent publication');

  // The tiny extension-storage presence marker survives a cleared vault and
  // prevents the empty result from impersonating a fresh installation.
  response = await message('export-private-backup');
  assert.strictEqual(response.ok, true);
  const missingLibraryBackup = response.result.raw;
  const presenceBeforeLoss = extensionStorage.get('progrssLibraryPresence');
  assert.strictEqual(presenceBeforeLoss.schema, 'progrss.library.presence.v1');
  assert.strictEqual(presenceBeforeLoss.hadLibrary, true);
  assert.ok(presenceBeforeLoss.lastLibrary.sources > 0);
  assert.ok(!JSON.stringify(presenceBeforeLoss).includes('https://'), 'the presence marker does not retain source addresses');
  assert.ok(!JSON.stringify(presenceBeforeLoss).includes('نص الاختبار'), 'the presence marker does not retain feed text');

  storage.clear();
  response = await message('get-state');
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.sources.length, 0);
  assert.strictEqual(response.result.libraryRecovery.state, 'missing');
  assert.ok(['vault-missing', 'vault-reset', 'vault-emptied'].includes(response.result.libraryRecovery.reason));
  assert.ok(response.result.libraryRecovery.lastKnown.sources > 0);

  response = await message('add-source', {url: 'https://example.test/blocked.xml', title: 'Blocked while missing', type: 'rss'});
  assert.strictEqual(response.ok, false);
  assert.strictEqual(response.code, 'LIBRARY_RECOVERY_REQUIRED');

  response = await message('preview-private-backup', {raw: missingLibraryBackup});
  assert.strictEqual(response.ok, true);
  response = await message('restore-private-backup', {raw: missingLibraryBackup, reviewedRevision: response.result.reviewedRevision});
  assert.strictEqual(response.ok, true);
  response = await message('get-state');
  assert.notStrictEqual(response.result.libraryRecovery.state, 'missing');
  assert.ok(response.result.sources.length > 0, 'a reviewed private file restores the remembered library');

  storage.clear();
  response = await message('get-state');
  assert.strictEqual(response.result.libraryRecovery.state, 'missing');
  response = await message('accept-empty-library');
  assert.strictEqual(response.ok, true);
  assert.strictEqual(response.result.accepted, true);
  response = await message('get-state');
  assert.notStrictEqual(response.result.libraryRecovery.state, 'missing');
  assert.strictEqual(response.result.sources.length, 0);
  response = await message('add-source', {url: 'https://example.test/fresh.xml', title: 'Deliberate fresh source', type: 'rss'});
  assert.strictEqual(response.ok, true, 'new writes resume only after the empty library is accepted');

  console.log('PASS background harness: direct-address and page-advertised shared-folder review plus manual located-publication check without automatic apply, private-copy marker migration, keyed current/older-copy recognition, explicit missing-copy recovery, ninety-day readability recheck, pause/disable/re-enable, failed write preserves the committed library, persistent recovery incident, private recovery export, explicit probe and manual retry, missing-library detection and guarded restore/new-start decisions, bounded fetch, validators, structured page-change baseline and Before/Now ingestion, held, recovered, confirmed, and unstable page-watch shape handling with portable-state exclusion, selector-free page-watch repair with a fresh baseline and guarded undo, feed-declared language enrichment without false events, canonical feed identity, activity, scoped read, OPML, direct folder placement/removal, reviewed private-library transfer with bounded page-change validation, exact graft-receipt retirement with portable evidence and guarded undo, reviewed same-source repair with stale-undo refusal, destination reconnect and undo');
})().catch(error => {
  console.error(error.stack || error);
  process.exitCode = 1;
});
