'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const ROOT = path.resolve(process.argv[2] || path.join(__dirname, '../../Extension'));

const storage = new Map();
const extensionStorage = new Map();
let failVaultWrites = false;
let pageExtractContent = 'Library opens Monday at 9.';
let pageExtractErrorCode = '';
let pageRepairVariant = 0;
globalThis.localStorage = {
  getItem(key) { return storage.has(key) ? storage.get(key) : null; },
  setItem(key, value) {
    if (failVaultWrites) {
      const error = Error('quota exceeded while writing the test vault');
      error.name = 'QuotaExceededError';
      throw error;
    }
    storage.set(key, String(value));
  },
  removeItem(key) { storage.delete(key); }
};

const messageListeners = [];
const alarms = [];
globalThis.chrome = {
  storage: {
    local: {
      async get(key) {
        if (key == null) return Object.fromEntries(extensionStorage);
        const keys = Array.isArray(key) ? key : [key];
        return Object.fromEntries(keys.filter(value => extensionStorage.has(value)).map(value => [value, extensionStorage.get(value)]));
      },
      async set(values) { for (const [key, value] of Object.entries(values || {})) extensionStorage.set(key, value); },
      async remove(key) { for (const value of (Array.isArray(key) ? key : [key])) extensionStorage.delete(value); }
    }
  },
  permissions: {
    async contains() { return true; },
    async getAll() { return {permissions: [], origins: ['https://example.test/*']}; }
  },
  runtime: {
    getURL(value) { return `chrome-extension://test/${value}`; },
    getManifest() { return {version: '0.80.0'}; },
    async getContexts() { return []; },
    async sendMessage(message) {
      if (message?.target === 'offscreen') {
        if (message.type === 'parse-feed') {
          return {ok: true, result: {
            title: 'Harness Feed', titleLanguage: 'en-GB', language: 'en-GB', type: 'rss', feedUrl: 'https://example.test/feed.xml', items: [
              {key: 'entry-1', title: 'A new entry', url: 'https://example.test/post/1', summary: 'ملخص الاختبار', body: 'نص الاختبار\n\nفقرة ثانية محفوظة.', bodyIsSummary: false, language: 'AR', titleLanguage: 'EN', summaryLanguage: 'AR', bodyLanguage: 'AR', published: '2026-10-17T12:00:00.000Z'}
            ]
          }};
        }
        if (message.type === 'parse-opml') {
          return {ok: true, result: {
            title: 'Harness subscriptions', feedOutlines: 4, invalidCount: 1, duplicateCount: 1, truncatedCount: 0, folderCount: 2,
            feeds: [
              {title: 'Harness Feed', url: 'https://example.test/feed.xml', folderPaths: [['Reading']]},
              {title: 'Independent Notes', url: 'https://new.test/feed.xml', folderPaths: [['Reading', 'Independent']]},
              {title: 'Other Notes', url: 'https://other.test/atom.xml', folderPaths: [['Reading']]}
            ]
          }};
        }
        if (message.type === 'inspect-resource') return {ok: true, result: {kind: 'feed', url: message.data.url, title: 'Harness Feed', titleLanguage: 'en-GB', language: 'en-GB', feedType: 'rss', feedUrl: 'https://example.test/feed.xml', itemCount: 1, previewCount: 1, previewFullTextCount: 1, previewSummaryCount: 0, previewDatedCount: 1, previewItems: [{title: 'A new entry', url: 'https://example.test/post/1', published: '2026-10-17T12:00:00.000Z', content: 'full-text', language: 'ar', titleLanguage: 'en'}]}};
        if (message.type === 'extract-page') {
          if (pageExtractErrorCode) return {ok: false, error: 'The watched section is missing.', code: pageExtractErrorCode, detail: {field: 'selector'}};
          return {ok: true, result: {mode: 'region', content: pageExtractContent, matchCount: 1, meaningfulCount: 1, contentChars: pageExtractContent.length}};
        }
        if (message.type === 'repair-page-watch') {
          const content = pageRepairVariant ? `${pageExtractContent} changed after review` : pageExtractContent;
          return {ok: true, result: [{
            schema: 'progrss.page-watch.repair.v1', title: 'Watch the page’s main text',
            description: 'Notice meaningful wording changes in the main part of the page.',
            mode: 'region', count: 1, examples: [], preview: content,
            recipe: {mode: 'region', selector: 'main', titleSelector: '', linkSelector: '', threshold: 4, ignoreNumbers: false},
            evidence: {signature: `region:${content}`, matchCount: 1, contentChars: content.length},
            capture: {mode: 'region', content, matchCount: 1, meaningfulCount: 1, contentChars: content.length}
          }]};
        }
      }
      return undefined;
    },
    onMessage: { addListener(listener) { messageListeners.push(listener); } },
    onInstalled: { addListener() {} },
    onStartup: { addListener() {} }
  },
  offscreen: { async createDocument() {} },
  action: {
    async setBadgeBackgroundColor() {}, async setBadgeText() {}, async setTitle() {}
  },
  sidePanel: { async setPanelBehavior() {} },
  alarms: { async create(name, details) { alarms.push({name, details}); }, onAlarm: { addListener() {} } },
  tabs: { async query() { return [{id: 1, url: 'https://example.test/', title: 'Example'}]; } },
  scripting: { async executeScript() { return [{result: {url: 'https://example.test/', title: 'Example', links: []}}]; } }
};

let fetchMode = 'normal';
let publicationPayload = '';
let publicationContentType = 'application/vnd.progrss.shared-folder+json; charset=utf-8';
const fetchCalls = [];
globalThis.fetch = async (url, options) => {
  fetchCalls.push({url: String(url), options});
  if (fetchMode === 'large') {
    return new Response('too large', {status: 200, headers: {'Content-Type': 'application/rss+xml', 'Content-Length': '2000001'}});
  }
  if (fetchMode === 'page') {
    return new Response(`<html><body><main>${pageExtractContent}</main></body></html>`, {
      status: 200, headers: {'Content-Type': 'text/html; charset=utf-8'}
    });
  }
  if (fetchMode === 'publication') {
    return new Response(publicationPayload, {
      status: 200, headers: {'Content-Type': publicationContentType, 'Content-Length': String(Buffer.byteLength(publicationPayload))}
    });
  }
  if (options?.headers?.['If-None-Match'] === '"harness-v1"') {
    return new Response(null, {status: 304, headers: {'ETag': '"harness-v1"', 'Last-Modified': 'Fri, 17 Oct 2026 12:00:00 GMT'}});
  }
  return new Response(
    '<rss><channel><title>Harness Feed</title><item><guid>entry-1</guid><title>A new entry</title></item></channel></rss>',
    {status: 200, headers: {'Content-Type': 'application/rss+xml', 'Content-Length': '120', 'ETag': '"harness-v1"', 'Last-Modified': 'Fri, 17 Oct 2026 12:00:00 GMT'}}
  );
};

globalThis.importScripts = (...files) => {
  for (const file of files) {
    const code = fs.readFileSync(path.join(ROOT, file), 'utf8');
    vm.runInThisContext(code, {filename: file});
  }
};

vm.runInThisContext(fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8'), {filename: 'background.js'});
assert.strictEqual(messageListeners.length, 1, 'background message listener registered');
const listener = messageListeners[0];

function setBackupReminderFixture(marker) {
  extensionStorage.set('progrssBackupReminder', marker);
  vm.runInThisContext(`volatileBackupReminder = ${JSON.stringify(marker)};`);
}

function message(type, data = {}) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const timeout = setTimeout(() => { if (!settled) reject(new Error(`timeout: ${type}`)); }, 1500);
    const keep = listener({target: 'background', type, data}, {}, response => {
      settled = true;
      clearTimeout(timeout);
      resolve(response);
    });
    assert.strictEqual(keep, true, `${type} keeps response channel open`);
  });
}



(async()=>{
  await message('get-state');
  const template = structuredClone(await ProgRSSVault.init());

  function portable(state) {
    return {
      sources: structuredClone(state.sources || []),
      items: structuredClone(state.items || []),
      collections: structuredClone(state.collections || []),
      receipts: structuredClone(state.receipts || []),
      retiredReceipts: structuredClone(state.retiredReceipts || []),
      snapshots: structuredClone(state.snapshots || {})
    };
  }

  async function seed(collections, items = []) {
    const current = await ProgRSSVault.init();
    const state = structuredClone(template);
    state._revision = current._revision;
    state.sources = ['first', 'second'].map(id => ({
      id, title: id === 'first' ? 'First history' : 'Second history', type: 'rss',
      url: 'https://same.example/feed.xml', enabled: false, archivedAt: ''
    }));
    state.items = structuredClone(items);
    state.collections = structuredClone(collections);
    state.receipts = [];
    state.retiredReceipts = [];
    state.snapshots = {};
    state.sourceRepairUndo = null;
    state.receiptRetirementUndo = null;
    await ProgRSSVault.save(state);
    return ProgRSSVault.init();
  }

  function folder(id, members, title = id) {
    return {id, title, mode: 'union', version: 1, members};
  }

  function placement(id, reason) {
    const row = {kind: 'source', id};
    if (reason !== undefined) row.reason = reason;
    return row;
  }

  let cases = 0;
  for (const order of [['first', 'second'], ['second', 'first']]) {
    for (const survivorId of ['first', 'second']) {
      const reasonById = {first: 'First distinct reason.', second: 'Second distinct reason.'};
      const state = await seed([folder('reading', order.map(id => placement(id, reasonById[id])), 'Reading')]);
      const before = structuredClone(state);
      const preview = await message('preview-source-repair', {firstSourceId: 'first', secondSourceId: 'second'});
      assert.strictEqual(preview.ok, true);
      assert.strictEqual(preview.result.canRepair, false);
      assert.strictEqual(preview.result.outcomes.length, 0);
      assert.strictEqual(preview.result.placementConflicts.length, 1);
      assert.strictEqual(preview.result.placementConflicts[0].kind, 'divergent-reasons');
      assert.match(preview.result.blockers[0], /will not choose a reason automatically/i);
      const commit = await message('repair-same-source', {
        firstSourceId: 'first', secondSourceId: 'second', survivorId,
        reviewedRevision: preview.result.reviewedRevision
      });
      assert.strictEqual(commit.ok, false);
      assert.strictEqual(commit.code, 'SOURCE_REPAIR_REASON_CONFLICT');
      assert.deepStrictEqual(await ProgRSSVault.init(), before, 'conflict refusal must not mutate state');
      cases++;
    }
  }

  for (const order of [['first', 'second'], ['second', 'first']]) {
    for (const survivorId of ['first', 'second']) {
      const members = order.map(id => placement(id, id === 'first' ? 'Only meaningful reason.' : undefined));
      const before = portable(await seed([folder('reading', members, 'Reading')]));
      const preview = await message('preview-source-repair', {firstSourceId: 'first', secondSourceId: 'second'});
      assert.strictEqual(preview.ok, true);
      assert.strictEqual(preview.result.canRepair, true);
      assert.deepStrictEqual(preview.result.placementConflicts, []);
      const commit = await message('repair-same-source', {
        firstSourceId: 'first', secondSourceId: 'second', survivorId,
        reviewedRevision: preview.result.reviewedRevision
      });
      assert.strictEqual(commit.ok, true, commit.error);
      let after = await ProgRSSVault.init();
      assert.deepStrictEqual(after.collections[0].members, [{kind: 'source', id: survivorId, reason: 'Only meaningful reason.'}]);
      const undo = await message('undo-source-repair');
      assert.strictEqual(undo.ok, true, undo.error);
      after = await ProgRSSVault.init();
      assert.deepStrictEqual(portable(after), before, 'repair undo restores both exact placements and reasons');
      cases++;
    }
  }

  for (const survivorId of ['first', 'second']) {
    await seed([folder('reading', [placement('first', 'Same reason.'), placement('second', 'Same reason.')], 'Reading')]);
    const preview = await message('preview-source-repair', {firstSourceId: 'first', secondSourceId: 'second'});
    assert.strictEqual(preview.result.canRepair, true);
    const commit = await message('repair-same-source', {
      firstSourceId: 'first', secondSourceId: 'second', survivorId,
      reviewedRevision: preview.result.reviewedRevision
    });
    assert.strictEqual(commit.ok, true, commit.error);
    const after = await ProgRSSVault.init();
    assert.deepStrictEqual(after.collections[0].members, [{kind: 'source', id: survivorId, reason: 'Same reason.'}]);
    cases++;
  }

  await seed([folder('reading', [placement('first'), placement('second')], 'Reading')]);
  let preview = await message('preview-source-repair', {firstSourceId: 'first', secondSourceId: 'second'});
  let commit = await message('repair-same-source', {
    firstSourceId: 'first', secondSourceId: 'second', survivorId: 'second',
    reviewedRevision: preview.result.reviewedRevision
  });
  assert.strictEqual(commit.ok, true, commit.error);
  let after = await ProgRSSVault.init();
  assert.deepStrictEqual(after.collections[0].members, [{kind: 'source', id: 'second'}]);
  cases++;

  await seed([
    folder('alpha', [placement('first', 'Reason for Alpha.')], 'Alpha'),
    folder('beta', [placement('second', 'Reason for Beta.')], 'Beta')
  ]);
  preview = await message('preview-source-repair', {firstSourceId: 'first', secondSourceId: 'second'});
  assert.strictEqual(preview.result.canRepair, true);
  commit = await message('repair-same-source', {
    firstSourceId: 'first', secondSourceId: 'second', survivorId: 'second',
    reviewedRevision: preview.result.reviewedRevision
  });
  assert.strictEqual(commit.ok, true, commit.error);
  after = await ProgRSSVault.init();
  assert.deepStrictEqual(after.collections.find(row => row.id === 'alpha').members, [{kind: 'source', id: 'second', reason: 'Reason for Alpha.'}]);
  assert.deepStrictEqual(after.collections.find(row => row.id === 'beta').members, [{kind: 'source', id: 'second', reason: 'Reason for Beta.'}]);
  cases++;

  const malformed = structuredClone(template);
  malformed.sources = ['first', 'second'].map(id => ({id, title: id, type: 'rss', url: 'https://same.example/feed.xml', enabled: false}));
  malformed.collections = [folder('reading', [placement('first', String.fromCharCode(0xD800)), placement('second')], 'Reading')];
  const malformedPlan = sourceRepairPlacementPlan(malformed, 'first', 'second');
  assert.strictEqual(malformedPlan.conflicts.length, 1);
  assert.strictEqual(malformedPlan.conflicts[0].kind, 'invalid-reason');
  cases++;

  await seed([folder('reading', [placement('first', 'Reviewed reason.'), placement('second')], 'Reading')]);
  preview = await message('preview-source-repair', {firstSourceId: 'first', secondSourceId: 'second'});
  const staleRevision = preview.result.reviewedRevision;
  const changed = await ProgRSSVault.init();
  changed.collections[0].title = 'Reading renamed after review';
  await ProgRSSVault.save(changed);
  commit = await message('repair-same-source', {
    firstSourceId: 'first', secondSourceId: 'second', survivorId: 'first', reviewedRevision: staleRevision
  });
  assert.strictEqual(commit.ok, false);
  assert.strictEqual(commit.code, 'SOURCE_REPAIR_STALE');
  after = await ProgRSSVault.init();
  assert.strictEqual(after.sources.length, 2);
  assert.strictEqual(after.collections[0].members.length, 2);
  cases++;

  console.log(`PASS source-note same-source repair harness: ${cases} focused scenarios; divergent reasons refuse without mutation, one-sided and identical reasons preserve, separate folders stay independent, malformed input blocks, stale review refuses, and undo restores exact placements.`);
})().catch(error => { console.error(error); process.exitCode = 1; });
