#!/usr/bin/env python3
"""Managed Workbench Lineage replay for placement-scoped Source Notes.

Loads the shipped Workbench HTML/scripts, substitutes only the persistence
backend with a deterministic in-page vault, and drives Courier → Lineage review.
This is managed UI-path evidence, not installed-browser or participant evidence.
"""
from __future__ import annotations

import argparse
import asyncio
import importlib.util
import json
import os
from pathlib import Path
import shutil
import tempfile
from typing import Any

from bs4 import BeautifulSoup
from playwright.async_api import async_playwright, Page

TESTS = Path(__file__).resolve().parent
BASE_EXTENSION = TESTS.parent
spec = importlib.util.spec_from_file_location("progrss_browser_smoke", TESTS / "browser_smoke.py")
if spec is None or spec.loader is None:
    raise RuntimeError("Could not load browser smoke support")
smoke = importlib.util.module_from_spec(spec)
spec.loader.exec_module(smoke)


def html_without_scripts(path: Path) -> tuple[str, list[Path]]:
    soup = BeautifulSoup(path.read_text(), "html.parser")
    scripts: list[Path] = []
    for tag in list(soup.find_all("script", src=True)):
        scripts.append((path.parent / tag["src"]).resolve())
        tag.decompose()
    return str(soup), scripts


async def build_seed(browser, root: Path, mode: str) -> dict[str, Any]:
    page = await browser.new_page()
    for script in (
        root / "shared" / "core.js",
        root / "workbench" / "scripts" / "progrss-courier.js",
        root / "workbench" / "scripts" / "progrss-lineage.js",
    ):
        await page.add_script_tag(content=script.read_text())
    result = await page.evaluate(
        """mode => {
          const C=globalThis.ProgRSSCore,Q=globalThis.ProgRSSCourier,L=globalThis.ProgRSSLineage;
          const source=C.cleanRecipe({id:'feed',type:'rss',url:'https://lineage.test/feed.xml',title:'Lineage feed',author:'Curator'});
          const publisher={sources:[source],collections:[C.cleanCollection({id:'folder',title:'Lineage folder',author:'Curator',members:[{kind:'source',id:'feed',reason:'Initial curator reason.'}]})],publications:[]};
          const subscriber={_revision:31,version:17,sources:[],collections:[],items:[],snapshots:{},fixtures:[],inbox:[],receipts:[],retiredReceipts:[],subscriptions:[],publications:[],patchPins:[],keyRotations:[],recoveryPolicies:[],recoveryReceipts:[],charterHistory:[],charterClaims:[],gossipCards:[],witnessPins:[],merklePins:[],merkleReceipts:[],proofRequests:[],proofSightings:[],proofForks:[],fixturePacks:[],transferUndo:null,sourceRepairUndo:null,receiptRetirementUndo:null,sharedFolderUpdateUndo:null,pageWatchRepairUndo:null};
          const first=L.publish(publisher,'folder','Initial reason');
          let selected=first;
          if(mode==='conflict'){
            L.apply(subscriber,first);
            const sub=subscriber.subscriptions[0],folder=subscriber.collections.find(row=>row.id===sub.mapping.folder),feed=sub.mapping.feed;
            folder.members.find(row=>row.kind==='source'&&row.id===feed).reason='Mine from this library.';
            publisher.collections[0].members[0].reason='Curator’s later wording.';
            selected=L.publish(publisher,'folder','Divergent reason');
          }
          const received=Q.receive(subscriber,Q.makeCapsule(selected,{note:'Managed Lineage Source Notes fixture'}),'file');
          return {seed:subscriber,entryId:received.entry.id,selected};
        }""",
        mode,
    )
    await page.close()
    return result


async def load_workbench(browser, root: Path, seed: dict[str, Any]) -> tuple[Page, list[str]]:
    page = await browser.new_page(viewport={"width": 1000, "height": 950}, device_scale_factor=1)
    errors: list[str] = []
    page.on("console", lambda msg: errors.append(f"console:{msg.type}:{msg.text}") if msg.type == "error" else None)
    page.on("pageerror", lambda error: errors.append(f"page:{error}"))
    page.on("dialog", lambda dialog: asyncio.create_task(dialog.accept()))
    html, scripts = html_without_scripts(root / "workbench" / "index.html")
    await page.set_content(html, wait_until="domcontentloaded")
    await page.add_script_tag(content=smoke.MOCK)
    # file/set_content pages are not secure contexts in every managed Chromium
    # build, so browser_smoke's constant randomUUID fallback would make the
    # Lineage collision-avoidance loop repeat forever. Supply deterministic,
    # unique UUIDs for this harness only.
    await page.add_script_tag(content="""(() => {
      let serial=1;
      const next=()=>`00000000-0000-4000-8000-${String(serial++).padStart(12,'0')}`;
      Object.defineProperty(globalThis.crypto,'randomUUID',{value:next,configurable:true});
    })();""")
    for script in scripts:
        if script.name == "vault.js":
            fake = f"""(() => {{
              let stored={json.dumps(seed, ensure_ascii=False)};
              globalThis.__workbenchSavedState=null;
              globalThis.__workbenchSaveCalls=0;
              globalThis.__workbenchCurrentState=()=>structuredClone(stored);
              globalThis.ProgRSSVault=Object.freeze({{
                init:async()=>structuredClone(stored),
                save:async state=>{{
                  state._revision=(Number(state._revision)||0)+1;
                  stored=structuredClone(state);
                  globalThis.__workbenchSavedState=structuredClone(state);
                  globalThis.__workbenchSaveCalls+=1;
                }},
                probe:async()=>true,
                info:()=>({{mode:'indexeddb',warning:''}}),
                normalize:value=>structuredClone(value)
              }});
            }})();"""
            await page.add_script_tag(content=fake)
        else:
            await page.add_script_tag(content=script.read_text())
    await page.wait_for_function("!document.querySelector('#shell').inert")
    return page, errors


async def open_pending_edition(page: Page) -> None:
    await page.locator('nav button[data-view="peers"]').click()
    card = page.locator("#courier-inbox .courier-card").filter(has_text="Unsigned collection edition").first
    await card.locator("button", has_text="Review contents").click()
    await page.wait_for_selector("#view-lineage:not([hidden])", timeout=5000)
    await page.wait_for_function("!document.querySelector('#lineage-review').textContent.startsWith('Checking')", timeout=5000)


def placement_reason(state: dict[str, Any]) -> Any:
    sub = state["subscriptions"][0]
    folder = next(row for row in state["collections"] if row["id"] == sub["mapping"]["folder"])
    source_id = sub["mapping"]["feed"]
    member = next(row for row in folder["members"] if row["kind"] == "source" and row["id"] == source_id)
    return member.get("reason")


async def run_variant(browser, root: Path, artifacts: Path) -> dict[str, Any]:
    passed: list[str] = []

    # First edition: exact reason survives Courier review and Lineage adoption.
    prepared = await build_seed(browser, root, "initial")
    page, errors = await load_workbench(browser, root, prepared["seed"])
    await open_pending_edition(page)
    assert await page.locator("#lineage-source-note-conflicts").is_hidden()
    assert await page.locator("#lineage-apply").is_enabled()
    await page.locator("#lineage-apply").click()
    await page.wait_for_function("globalThis.__workbenchSaveCalls === 1")
    saved = await page.evaluate("globalThis.__workbenchSavedState")
    assert placement_reason(saved) == "Initial curator reason."
    assert not await page.evaluate("globalThis.__nodeFetchRequests.length")
    assert not errors, errors
    await page.close(); passed.append("first adopted edition preserves its direct-placement reason")

    # Divergence: approval stays disabled until an explicit choice; Use curator's commits that value.
    prepared = await build_seed(browser, root, "conflict")
    page, errors = await load_workbench(browser, root, prepared["seed"])
    await open_pending_edition(page)
    slot = page.locator("#lineage-source-note-conflicts")
    assert await slot.is_visible()
    assert "ProgRSS will not choose a winner" in await slot.inner_text()
    assert await page.locator("#lineage-apply").is_disabled()
    assert await slot.locator('input[type="radio"]').count() == 2
    await slot.locator('input[value="use_curator"]').check()
    await page.wait_for_function("!document.querySelector('#lineage-apply').disabled")
    await page.screenshot(path=str(artifacts / f"{root.name}-lineage-source-note-choice.png"), full_page=True)
    await page.locator("#lineage-apply").click()
    await page.wait_for_function("globalThis.__workbenchSaveCalls === 1")
    saved = await page.evaluate("globalThis.__workbenchSavedState")
    assert placement_reason(saved) == "Curator’s later wording."
    assert saved["subscriptions"][0]["sequence"] == 2
    assert not await page.evaluate("globalThis.__nodeFetchRequests.length")
    assert not errors, errors
    await page.close(); passed.append("Use curator’s is required explicitly and commits only that reason")

    # Keep mine commits the local wording.
    prepared = await build_seed(browser, root, "conflict")
    page, errors = await load_workbench(browser, root, prepared["seed"])
    await open_pending_edition(page)
    await page.locator('#lineage-source-note-conflicts input[value="keep_mine"]').check()
    await page.wait_for_function("!document.querySelector('#lineage-apply').disabled")
    await page.locator("#lineage-apply").click()
    await page.wait_for_function("globalThis.__workbenchSaveCalls === 1")
    saved = await page.evaluate("globalThis.__workbenchSavedState")
    assert placement_reason(saved) == "Mine from this library."
    assert not errors, errors
    await page.close(); passed.append("Keep mine is required explicitly and preserves the local reason")

    # Closing the review discards the ephemeral decision; reopening requires a fresh choice.
    prepared = await build_seed(browser, root, "conflict")
    page, errors = await load_workbench(browser, root, prepared["seed"])
    await open_pending_edition(page)
    await page.locator('#lineage-source-note-conflicts input[value="keep_mine"]').check()
    await page.wait_for_function("!document.querySelector('#lineage-apply').disabled")
    await page.locator("#lineage-cancel").click()
    await page.locator('nav button[data-view="peers"]').click()
    await page.locator("#courier-inbox .courier-card").filter(has_text="Unsigned collection edition").first.locator("button", has_text="Review contents").evaluate("el => { setTimeout(() => el.click(), 0); return true; }")
    await page.wait_for_selector("#lineage-source-note-conflicts:not([hidden])")
    await page.wait_for_function("!document.querySelector('#lineage-review').textContent.startsWith('Checking')")
    assert await page.locator('#lineage-source-note-conflicts input:checked').count() == 0
    assert await page.locator("#lineage-apply").is_disabled()
    assert await page.evaluate("globalThis.__workbenchSaveCalls") == 0
    assert not errors, errors
    await page.close(); passed.append("closing review clears an uncommitted conflict decision")

    return {"variant": str(root), "passed": passed, "count": len(passed)}


async def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(os.environ.get("PROGRSS_EXTENSION_ROOT", BASE_EXTENSION)))
    parser.add_argument("--artifacts", type=Path, default=Path(os.environ.get("PROGRSS_TEST_ARTIFACTS", tempfile.gettempdir())) / "progrss-lineage-source-notes")
    args = parser.parse_args()
    root = args.root.resolve(); args.artifacts.mkdir(parents=True, exist_ok=True)
    async with async_playwright() as p:
        executable = os.environ.get("PROGRSS_CHROMIUM") or shutil.which("chromium") or shutil.which("chromium-browser") or shutil.which("google-chrome")
        launch: dict[str, Any] = {"headless": True, "args": ["--no-sandbox"]}
        if executable: launch["executable_path"] = executable
        browser = await p.chromium.launch(**launch)
        try:
            result = await run_variant(browser, root, args.artifacts)
        finally:
            await browser.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print(f"PASS Workbench Lineage Source Notes: {result['count']} cases")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
