# Tired-reader acceptance — sources, site access, feed previews, private copies, and shared folders

This is a short human review protocol for the everyday reader. It is packaged so the same tasks can be repeated in Chromium and Firefox. Completing the automated suite does **not** count as completing this review.

## Set up

Use synthetic data only. Include:

- one source whose address moved;
- one source that needs reconnecting;
- one healthy source;
- one paused source;
- a meaningful library with a private-copy reminder due;
- one existing simple folder containing at least one feed;
- an imported signed shared folder plus a later same-key copy;
- a later copy signed by a different key;
- one local label or folder edit inside the imported publication;
- one controlled webpage advertising two unfamiliar feeds, with the second feed containing at least three clearly different item titles;
- one page watch in **Checking again** after a single unusual but still readable result;
- one page watch that genuinely requires repair;
- a controlled site for which the browser permission prompt can be declined or dismissed, then granted on a later attempt;
- one running loopback ProgRSS Node using a synthetic private backup, with a fresh pairing invitation and a second invitation that has expired.

Run once at an ordinary sidebar width and once at 320 CSS pixels with enlarged text. Record browser, operating system, assistive technology, zoom, input method, and whether the participant has used ProgRSS before.

Do not explain the screen before the first task. Stop rather than coach when the participant becomes frustrated or fatigued.

## Sixteen tasks

1. **“One place you follow needs you to decide something. Find it and tell me what ProgRSS is asking.”**
   - Record the first control or card chosen.
   - Note whether the participant distinguishes an address move from a reconnect.
   - Do not require them to complete the network or permission action.

2. **“Find a place that is working normally and pause it.”**
   - Note whether the participant can distinguish **Needs your attention** from **Following**.
   - Ask what they expect **Pause** to do before they activate it.

3. **“Your browser is the only place this library currently lives. Find the private-copy action and explain the next step in your own words.”**
   - Note whether the participant distinguishes **Save private copy** from **Check saved copy**.
   - Ask them to postpone the reminder, then find where to turn reminders back on.

4. **“Share the existing folder with another ProgRSS reader, add a group name, and explain what signing would and would not prove.”**
   - Note whether **Share this folder** appears in the folder context rather than as a global publishing dashboard.
   - Ask the participant to find optional attribution without being prompted to open an advanced settings page.
   - Record whether they distinguish a verified file/key relationship from a verified human identity or source-safety claim.
   - Confirm they understand that the unsigned path remains usable and that site access and reading history are not shared.

5. **“This group sent you a newer copy of a folder you already imported. Decide what you would do without losing your own changes.”**
   - Start with the same-key copy. Ask the participant to explain what will change and what remains local.
   - Confirm they can find **Update from this copy**, **Keep my local version**, and **Import as a separate folder** without opening the Workbench.
   - Ask what happens to a changed source recipe and to a source removed from the shared list.
   - Repeat with the changed-key copy. Record whether the participant understands that the file signature verifies while the reason for the key change remains unknown.
   - Confirm the acknowledgement is understood as accepting a continuity break, not verifying a person.
   - After updating, ask the participant to find and explain **Undo folder update**.

6. **“Someone sent you this direct ProgRSS folder link. Open it, but do not add anything until you understand what it contains.”**
   - Begin in Add without showing a hosted presentation page.
   - Record whether the participant chooses **Paste an address**, understands **Source list found** as recognition rather than import, and then chooses **Review source list**.
   - Ask what has already happened and what has not happened. Look specifically for mistaken beliefs that listed sites were contacted, sources were added, or a future check was scheduled.
   - Confirm **Back to address result** is understood and preserves the inspected result.
   - Repeat with a generic JSON file and note whether the refusal is understandable without teaching bundle schemas or media types.

7. **“This page offers two feeds. Look at the second one, decide whether it seems useful, and return without following it.”**
   - Begin at **Add → Use this page** without explaining RSS vocabulary.
   - Record whether **Preview …** is understood as inspection rather than subscription.
   - Ask what information came from the feed, what was not loaded, and whether anything has been followed.
   - Confirm the participant can distinguish **Follow this feed** from **Back to page options**.
   - After returning, check whether focus lands on the same candidate and whether the participant still understands which feed they inspected.
   - Repeat by pasting the feed address directly and note whether the same preview model feels consistent.

8. **“Community board says ‘Checking again.’ Tell me whether ProgRSS already created an alert and whether you must do anything now.”**
   - Record whether the participant can find the source in **Following** rather than **Needs your attention**.
   - Ask what they think **Checking again** means before opening the card.
   - Confirm they understand that no page-change alert was created and that one later ordinary check will confirm or discard the result.
   - Ask whether **Check again** is required. The intended answer is no: the normal schedule can perform the next check.
   - Record whether the wording is mistaken for a network failure, a broken watch, a completed change, or an urgent warning.

9. **“Town notices stopped working. Repair what ProgRSS watches without changing or deleting the earlier alerts.”**
   - Begin in **Sources → Needs your attention** without explaining selectors or page structure.
   - Record whether **Repair watch** and **Find what to watch now** communicate that checking has stopped rather than merely slowed down.
   - Ask the participant to compare the proposed sections using the visible examples and choose one.
   - Confirm they can explain that **Use this section** creates a new starting point, does not invent a change alert, and keeps earlier alerts, read/saved state, and folder placement.
   - Confirm **Keep current watch** is understood as leaving the watch stopped until repaired, not resuming the broken rule.
   - After repair, ask the participant to find and explain **Undo watch repair**.
   - Record any attempt to look for selector syntax or uncertainty about whether the current webpage was modified.

10. **“Try to check Community board without granting ProgRSS site access yet. Tell me what happened and what you can do next.”**
   - Use the browser-owned deny or dismiss path; do not simulate a network failure.
   - Record whether the participant interprets the neutral status as an application error, a permanent block, or a completed check.
   - Confirm they understand that the held observation still waits, no page-change alert was created, and the same **Check again** control can be used later.
   - Repeat with **Reconnect and check now**, an address move, and **Find what to watch now**. Confirm each explanation names the task that stayed unchanged rather than using generic “nothing added” language.
   - Grant access on a later attempt and confirm the participant expects the original action—not a hidden retry—to proceed.


11. **“Share the recent updates from this folder. Then tell me what another person receives, what stays private, and whether the file updates itself.”**
   - Begin with one existing simple folder selected in Sources.
   - Record whether the participant finds **Share recent updates (optional)** without mistaking it for the native **Share this folder** action.
   - Confirm **Save recent updates as feed** is understood as preparing a manual file, not publishing an account-backed live feed.
   - Ask whether full article text, read/unread state, saved items, page-watch Before/Now evidence, and browser site access travel. The intended answer is no.
   - Present two sources that link to the same article. Record whether the source-witness explanation is understandable without teaching deduplication terminology.
   - Ask what must happen when the folder changes. The intended answer is that a new edition must be prepared; the earlier file does not update itself.

12. **“Put this folder on a small website so visitors can get both the source list and its recent updates.”**
   - Begin in the existing **Share this folder** review. Do not tell the participant that two formats are involved.
   - Record whether **Put this folder on a website (optional)** and **Include a recent-updates feed** communicate one package rather than two unrelated export chores.
   - Ask the participant to explain the difference between **Get this folder for ProgRSS** and **Get recent updates feed** on the generated page. The intended distinction is recipes and folder structure versus a summary-only reading snapshot.
   - Confirm the participant understands that the checkbox is optional and initially off, and that the standalone **Save recent updates as feed** action still exists for feed-only sharing.
   - Ask what the webpage loads automatically. The intended answer is no listed site, article, image, script, tracker, or future update.
   - Ask what changes after the curator uploads the ZIP and then changes the local folder. The intended answer is nothing on the website until another package is prepared and uploaded.
   - Record any belief that ProgRSS hosts the site, owns an account, signs the curator’s real-world identity, or keeps the feed synchronized.

13. **“This published page offers a source list and recent updates. Choose the one that lets you read updates without adding all of its underlying sources.”**
   - Begin at **Add → Use this page** on a generated publication page. Do not explain JSON Feed, alternate links, or the package layout.
   - Record whether **Add the source list** and **Follow recent updates** communicate two consequences rather than two file formats.
   - Confirm the participant chooses **Preview recent updates**, understands that preview is not follow, and can explain that following adds one summary feed only.
   - Return to the page options and ask what **Review source list** would add. The intended answer is the reviewed feeds, watched pages, and folders, with existing recipes reused and new sources paused.
   - Ask what discovery already contacted. The intended answer is the open publication page only; neither advertised file nor any listed source was contacted until its own visible action.
   - Repeat with an intentionally source-list-only page and confirm the missing update-feed choice is not perceived as a broken page.
   - Record any attempt to choose both, any belief that following recent updates imports the folder, and any uncertainty caused by the words *source list*, *feed*, *updates*, or *follow*.


14. **“Review this source list. Without adding it, name one feed, one watched page, and the folder route where each would appear.”**
   - Use a checked source list with more than six sources so the contents disclosure begins collapsed.
   - Record whether the participant finds and opens **See … sources and … folders** without being taught the phrase *table of contents*.
   - Ask what the host name means and whether the complete source address or any selector is being shown.
   - Confirm the participant distinguishes **Feed** from **Watched page** and can follow a nested route such as **Neighborhood › Public meetings**.
   - Ask what **New · starts paused** and **Already in this library** mean before any import.
   - Ask which listed sites ProgRSS has contacted. The intended answer is none; the names came from the checked file.
   - Return without importing and confirm the person understands that review did not add, follow, refresh, or schedule anything.


15. **“This source list is larger than you need. Add only the Public meetings section, then explain what happens when the curator publishes a later copy.”**
   - Begin at the complete source-list review. Do not point out the optional disclosure.
   - Record whether the participant keeps **Add source list** as the understood default and can find **Add just one folder section (optional)** when the task requires it.
   - Confirm one folder selector is understandable without a checkbox tree or source-by-source picker.
   - After **Review this section**, ask the participant to name the selected route, the included sources, and anything from the parent list that will not be added.
   - Ask what **independent local folder** means. The intended answer is that a later copy of the parent publication will not rewrite or update this excerpt.
   - Ask what the parent signature proves. The intended answer is that the checked parent document was signed by the matching key; the derived local excerpt is not separately signed and the displayed curator is not authenticated as a person.
   - Confirm new sources start paused, exact existing sources are reused, and no listed site was contacted during review or import.
   - Return to **Review the full source list** and confirm the person can choose publication continuity instead of a smaller independent excerpt.
   - Record every misunderstanding of *source list*, *folder section*, *independent*, *parent publication*, and *future copies*.



16. **“Connect this Extension to the ProgRSS Node you started. Before pairing, tell me what the connection can and cannot reveal. Then disconnect it.”**
   - Begin at **Add** with a copied ten-minute Node invitation. Do not explain loopback, bearer capability, Origin, or fingerprint terminology.
   - Record whether the participant finds **Connect a Node**, pastes the invitation, and understands that **Review** may trigger a browser-owned local-device permission decision.
   - Before **Pair read-only**, ask what the visible session fingerprint, library filename, digest, and counts do and do not establish. The intended answer is continuity with this running Node session and this selected file—not a verified person, permanent device identity, or trustworthy source collection.
   - Ask which data the Extension will receive. The intended answer is the displayed aggregate summary only: no item text or titles, followed addresses, folders, page-watch selectors, browser permissions, writes, fetches, publication, merge, or automatic synchronization.
   - Pair, choose **Check connection**, and ask what changed in either library. The intended answer is nothing; the action rechecked the same session marker and summary.
   - Choose **Unpair** and confirm the person understands that the Node grant and Extension record are removed and that newly granted loopback access is released when ProgRSS added it.
   - Repeat with Cancel after review, a denied permission prompt, an expired invitation, a Node restart with a changed session fingerprint, and an unreachable Node followed by **Forget this pairing locally**.
   - Record any belief that pairing copied feeds, merged libraries, gave the Node browser authority, exposed reading history, remained valid across Node restart, or authenticated the human running the Node.

## What to record

For each task, record completion without prompting, wrong turns, words that were misunderstood, focus loss, controls hidden by zoom or the browser chrome, and any moment where two visible actions appeared to mean the same thing.

The review is successful only when the participant can explain the consequence of the chosen action. Speed alone is not a pass condition.

## Accessibility variants

Repeat the same sixteen tasks, where available, with:

- keyboard only;
- a screen reader;
- voice control;
- switch-style sequential navigation;
- forced colors or operating-system high contrast;
- 200% and 400% zoom.

Record exact browser and assistive-technology versions. Do not convert an automated accessibility-tree check into a claim of human acceptance.

## Publication-page and direct-link task

Present a participant with a plain hosted source-list page that they did not create. Do not explain `rel=alternate`, media types, signatures, or ProgRSS bundle versions. Ask:

> Add the shared reading list shown on this page, but do not add anything until you have reviewed what it contains.

Record whether the participant finds **Add → Use this page**, understands **Review source list** as a preview rather than an immediate import, notices the curator/signature limitation, and can return to the page options without losing place. Record any attempt to choose **Watch this page**, any belief that review already added the sources, and any confusion between initial import and **Check for a newer copy**.

Then present the exact native JSON address without the page. Ask:

> Open this shared folder link and review it, but do not add it yet.

Record whether **Paste an address** feels broad enough, whether **Source list found** is mistaken for a completed import, whether the participant can explain that only the chosen address was contacted, and whether **Back to address result** returns them to a stable place. Compare wrong turns between the page route and the direct-link route.

## Task 17 — Capture one rendered watched page without sending the login

17. **“This watched page works only in your signed-in browser. Let the Node keep one reviewed result without sending your login.”**
   - Start with one existing watched-page source in a Node-owned library and create one ten-minute browser request from **Sources → Use signed-in browser**.
   - Paste the request into **Add**. Record whether the participant understands that the Node is asking for evidence from one exact page, not access to every open tab or the browser profile.
   - Before **Capture this open page**, ask what remains in the browser. The intended answer is cookies, credentials, browser storage, form values, permissions, and the signed-in session.
   - Confirm the exact watched page must be open in the active top frame and that the browser may present an exact-site permission decision from the visible action.
   - On **What part of this page counts as an update?**, ask the participant to compare the saved watched section, repeated entries, and primary readable text when available.
   - Ask them to explain **More likely to stay put**, **Needs watching**, or **Fragile**, then name one item under **Why this may hold** and one under **What could break**. Confirm they understand this is evidence from the current rendering, not a guarantee or probability.
   - Ask the participant to name one matched example and one ignored example before sending anything.
   - When the chosen rendered section differs from the saved recipe, confirm the commit remains disabled until **Use this new watched section** is checked and that the explanation says a fresh baseline will be saved rather than inventing an old change.
   - Complete the capture. Confirm the result says **Node site requests: 0** and **Schedule: None created**.
   - Ask what traveled. The intended answer is bounded text, links, recipe evidence, examples, time, digest, and provenance—not cookies, raw HTML, screenshots, scripts, storage, or browser authority.
   - Repeat with a mismatched open page, an expired request, a second Extension Origin, an oversized artifact fixture, a lost-response exact retry, and same-key different-content reuse.
   - Choose Cancel at review and at candidate choice, then leave Add. Confirm newly granted loopback and page permissions are released when ProgRSS added them.
   - Record confusion around *rendered page*, *watched section*, *browser keeps authority*, *baseline*, *matched*, *ignored*, *more likely to stay put*, *fragile*, *Node site requests*, and *schedule*.

Repeat this task with keyboard only, the available screen reader, voice control, switch-style sequential navigation, forced colors, and 200% and 400% zoom. The protocol is packaged work; it is not a claim that those sessions occurred.

## Task 18 — Explain what one rendered page may leave outside

18. **“Review this watched-page capture. Tell me what ProgRSS saw, what it may have missed, and what you would do before sending it.”**
   - Use a fixture with a next-page link, a partially rendered list, one visible consent overlay, one embedded frame, and one open shadow root.
   - Confirm the participant finds **What this browser view may leave outside** before the rendered-section choices.
   - Ask them to distinguish **Outside capture**, **Check first**, and **Included**.
   - Ask whether **More likely to stay put** means the whole page was captured. The intended answer is no: it describes only the selected section's structure in this rendering.
   - Ask whether ProgRSS automatically followed the next page, scrolled the virtualized list, clicked the overlay, read the frame, or pierced closed shadow content. The intended answer is no.
   - Ask what they could do next. Look for scrolling, loading more, dismissing the overlay when appropriate, waiting for loading, and choosing **Capture the page again**.
   - Open **Advanced page-boundary evidence** and confirm the counts remain understandable without becoming the ordinary decision surface.
   - Complete one capture and verify **Advanced capture receipt** retains page-boundary kinds while the ordinary result still leads with baseline/change, items added, zero Node site requests, library revision, and no schedule.
   - Repeat on a page with no extra notice and ask whether that proves completeness. The intended answer is no.

Repeat with keyboard-only operation, the available screen reader, voice control, switch-style sequential navigation, forced colors, reduced motion, and 200% and 400% zoom. Record whether page-coverage notices are announced before the candidate radios and whether the recovery action is reachable without dragging.

## Threshold — accepting one limited rendered view

1. Open a Capture fixture that reports continuation, partial rendering, a visible overlay, and an excluded frame.
2. Confirm the final send action is unavailable before a coverage choice.
3. Explain what **Capture the page again first** does.
4. Explain what **Use this rendered view as the baseline** accepts and what it does not cause ProgRSS to do.
5. When a new watched section is also selected, confirm the two decisions are separate and neither is preselected.
6. Recapture and confirm the earlier coverage choice no longer counts.
7. Complete one capture and find the exact accepted boundary kinds in Advanced receipt evidence.
8. Ask whether the browser login, frame contents, or a recurring schedule moved to the Node.
9. Record keyboard, screen-reader, Braille, voice, switch, zoom, forced-colors, reduced-motion, fatigue, and interruption behavior.
10. Treat confusion as a wording or hierarchy defect, not permission to add hidden scrolling or clicking.

## Drift — a different rendered window

After a partial list baseline exists, capture a disjoint virtualized window from the same page.

Record whether the participant:

- Understands **Rendered window held** as “not safely comparable,” not “nothing changed.”
- Understands that the earlier baseline remains.
- Looks for a mass add/remove alert that should not exist.
- Can find the overlap evidence only when needed.
- Believes ProgRSS scrolled or loaded the page automatically.
- Believes the Node contacted the watched site.
- Can explain that no schedule was created.

## Task 19 — Move one held baseline without rewriting history

19. **“This watched page has one earlier baseline and one later held rendering. Decide whether to keep the earlier baseline or use the held rendering for future comparisons.”**
   - Confirm the participant can identify **Accepted now** and **Held proposal**.
   - Ask what the 0% or low-overlap evidence means without requiring them to understand the formula.
   - Ask whether replacing the baseline creates a past add/remove alert. The intended answer is no.
   - Ask whether the Node contacts the watched site or creates a schedule. The intended answer is no.
   - Confirm **Replace baseline once** remains unavailable until its separate acknowledgement is checked.
   - Cancel once and confirm nothing changes.
   - Commit once and confirm the earlier complete library remains in **Download before snapshot**.
   - Ask whether that snapshot is an automatic undo button. The intended answer is no.
   - Simulate a lost response and confirm an exact retry returns the existing receipt rather than repeating the write.
   - Ask whether the paired Extension could perform the operation. The intended answer is no.

Repeat with keyboard-only operation, available screen reader, Braille, voice control, switch-style sequential navigation, 200% and 400% zoom, forced colors, reduced motion, fatigue, and interruption. Change wording or hierarchy when people confuse *held*, *accepted*, *history*, *snapshot*, or *undo*.


## Bearing — repeated held-window comprehension

Give the participant a Node watched page with two unresolved held observations.

Ask them to:

1. Open **Understand held windows**.
2. Explain whether the accepted baseline changed.
3. Explain whether **Moving rendered window** is proven fact.
4. Choose the route that keeps everything unchanged.
5. Identify the route that reviews baseline replacement.
6. Identify the route that observes the browser page again.
7. Say whether any route has contacted the site yet.
8. Say whether the paired Extension can perform the replacement.

Record confusion among *held observation*, *accepted baseline*, *diagnosis*, *Anchor*, and *fresh Capture*. Change wording or hierarchy rather than adding automatic repair.


## Trace — observation-trail comprehension

1. Open a watched page with at least two unresolved held observations.
2. Open Bearing and read the Trace trail without expanding Advanced.
3. Identify the accepted baseline, oldest held observation, and current hold.
4. Explain what `Different window` does and does not prove.
5. Explain what the recipe-footprint label describes.
6. Confirm that opening Trace made no site request and changed no library data.
7. Confirm that exact selectors are available only under Advanced and that the paired Extension receives no repair authority.
8. Repeat with keyboard-only, enlarged text, forced colors, reduced motion, and available assistive technology.

Record whether the participant mistakes the trail for a timeline of confirmed publisher changes, treats the footprint label as a durability guarantee, or believes Open Anchor is an immediate write.

## Fieldbook — test the wording, not the person

1. Open the actual Trace/Bearing review and a downloaded Fieldbook in separate windows.
2. Confirm that the facilitator sheet is not presented as the ProgRSS product interface.
3. Ask the participant to complete the twelve comprehension tasks in the actual interface while the facilitator records outcomes separately.
4. Record whether **Different window**, overlap, semantic boundary, Keep, Anchor, fresh Capture, and paired Extension authority are understood without coaching.
5. Confirm that the sheet requests no participant identity and saves nothing automatically.
6. Confirm that report download remains unavailable until every task has an outcome and the facilitator reviews notes for sensitive information.
7. Treat every wrong turn as evidence about wording or hierarchy, not as a participant failure.
8. Do not represent an automated or facilitator-only run as unfamiliar-human acceptance.

## Debrief — find patterns without scoring people

Use several reviewed Fieldbook reports from the same exact release and task
sequence. Keep the actual product findings local until the privacy review is
complete.

1. Download a blank Debrief from **Research and acceptance**.
2. Load three compatible local Fieldbook JSON reports.
3. Explain why the report count is not a participant score.
4. Find one **Recurring wrong turn to review** signal.
5. Find one **Prompt-dependent understanding to review** or **Coverage gap**.
6. Open the local facilitator notes and explain whether they will appear in the
   exported Debrief.
7. Choose a disposition for every task.
8. Write one bounded finding and the smallest product response worth testing.
9. Open the final review.
10. Explain why **No recurring signal yet** is not a product pass.
11. Complete the three privacy confirmations.
12. Download JSON and Markdown and verify that raw notes are absent.
13. Clear the workspace and explain where the reports were stored.

Record whether the facilitator:

- Treats counts as descriptions of the loaded reports only.
- Attempts to rank or score participants.
- Mistakes a review signal for an automatic product verdict.
- Copies raw notes or identifying detail into a finding.
- Understands **More sessions needed** as a legitimate product disposition.
- Understands that no report was uploaded and nothing was saved automatically.

## Crossroads — recipient chooses among three honest consequences

Use one active Exchange handoff where all three doors are available. Keep the
actual Extension and the separate Crossroads Fieldbook open.

1. Ask the participant what access the invitation grants.
2. Give the goal “read future summary updates without adding all underlying
   sources.” Observe whether they choose **Follow updates**.
3. Give the goal “adopt the full curated source graph.” Observe whether they
   choose **Add the complete route**.
4. Give the goal “take only one nested section and keep it independent.”
   Observe whether they choose **Take one branch**.
5. Ask whether selecting a card immediately follows or imports anything.
6. Ask whether review contacted every listed site or created a schedule.
7. Ask what happens to exact existing sources and genuinely new sources.
8. Ask whether reading history, saved state, retained private text, cookies, or
   private keys travel with the handoff.
9. Ask what expiry or revocation changes.
10. Ask whether this invitation is permanent Node pairing or administrator
    access.

Record independent understanding before a neutral prompt. Wrong turns should
change wording or hierarchy; they should not be treated as participant failure.

## Dispatch — sender understands the outbound boundary

Use the exact rev0080 Node review and a separate Dispatch Fieldbook. The
participant should not have learned ProgRSS Exchange terminology beforehand.

Ask them to prepare one share without creating the handoff yet, then explain:

1. Whether review already published or sent anything.
2. What curation can be included and what private state stays out.
3. Which recipient doors are available.
4. What Follow updates ultimately follows.
5. What is reused and what begins paused in a complete route.
6. Why one branch is independent from the parent publication.
7. What a public address and static package do—and do not do.
8. What the thirty-minute handoff grants.
9. What first-review Extension-Origin binding means.
10. What expiry and revocation can and cannot undo.
11. Whether any listed source was contacted or scheduled.
12. Whether the sender can inspect a recipient library.

Record an outcome before offering a neutral prompt. Automated completion of
the Fieldbook is tool verification, not human acceptance.
