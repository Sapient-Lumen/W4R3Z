# Native Firefox desktop acceptance — Exchange

Use a fresh Firefox desktop profile. This checklist is intentionally manual until the repository has a reliable installed-Firefox automation lane. Record Firefox version, operating system, and every failed or skipped step.

## Package and reader surface

1. Open `about:debugging#/runtime/this-firefox`.
2. Load `../Firefox/manifest.json` as a temporary add-on.
3. Confirm the add-on is named **ProgRSS** and reports version **0.69.0**.
4. Click the toolbar action. Confirm the native Sidebar opens to **What’s new**.
5. Close and reopen the Sidebar. Confirm Today, Sources, and Add retain keyboard focus order and do not acquire horizontal scrolling at a narrow width.
6. Open the Advanced Workbench, then use **Open everyday reader**. Confirm the Sidebar opens from the button action.

## Read-only Node pairing in the native Sidebar

1. Start `progrss node serve` with a synthetic private backup. Confirm Firefox makes no Node request merely because the Sidebar opens or a previous pairing record exists.
2. In the Node UI, create one invitation. In Firefox choose **Add → Connect a Node**, paste it, and press **Review**. Confirm the Firefox-owned optional host-permission decision occurs only from this action and is scoped to `http://127.0.0.1/*`.
3. Deny or dismiss the prompt. Confirm no pairing exists, no library changed, and the explanation is neutral and retryable. Grant on a later attempt.
4. Confirm review shows the exact loopback origin and port, process-lifetime session fingerprint, selected backup filename and digest, bounded counts, expiry, and the complete summary-only capability boundary before acceptance.
5. Ask the participant to explain the fingerprint. Confirm it is understood as continuity with this running Node process, not a signed permanent device or person identity.
6. Choose **Pair read-only**. Confirm the invitation is consumed once, the Node lists one active pairing without exposing its bearer, and the Sidebar says that nothing is synchronized automatically.
7. Choose **Check connection**. Confirm the same session fingerprint and summary are rechecked but no item, source address, folder title, page-watch recipe, read state, or saved state crosses the boundary.
8. Restart the Node. Confirm the old pairing check fails safely, the new session fingerprint differs, and no automatic reconnect or localhost scan occurs.
9. Pair again, then choose **Unpair**. Confirm the Node grant is revoked, the local record is removed, and loopback host permission is released when this pairing action originally added it.
11. Repeat review and choose **Cancel**. Repeat with a malformed, expired, already-used, wrong-host, query-bearing, credential-bearing, and non-loopback invitation. Confirm each refuses without pairing or background contact.
11. With an unreachable Node, use **Forget this pairing locally**. Confirm the warning explains that a still-running Node may retain the grant until revoked there or stopped.
12. Repeat at 320 CSS pixels, enlarged text, forced colors, keyboard-only operation, and a screen reader. Confirm Review, Pair read-only, Check, Unpair, the capability limits, expiry, and warnings remain understandable.

## Sources hierarchy and one private-copy surface

1. Seed one moved source, one source with removed permission, one healthy source, and one paused source. Open Sources without explaining the layout. Confirm **Needs your attention** appears first and contains the moved source before the reconnect source; confirm healthy and paused sources appear under **Following**.
2. Confirm the source list appears before **Library care** and there is only one visible set of **Save private copy** and **Check saved copy** actions.
3. Make private-copy guidance due. Confirm the **Private copy** disclosure opens as a signpost but no modal, toolbar badge, browser notification, or duplicate banner appears.
4. Snooze the guidance. Confirm the panel remains available but collapses and loses its attention treatment. Open it deliberately and confirm reminder controls remain under **Reminder and copy options**.
5. Repeat at 320 CSS pixels with enlarged text, keyboard only, and the screen reader used for the rest of this checklist. Confirm group headings, counts, source cards, and Library care remain in a meaningful order.
6. Run `tired_reader_acceptance.md` with at least one person who has not seen this implementation. Record the exact Firefox and assistive-technology versions; do not count this checklist itself as a human pass.

## Shared-folder attribution and signatures

1. Select an existing simple folder in Sources. Confirm **Share this folder** appears only in that folder context and the initial review contains feeds, page watches, nested folders, and the statement that site access is never included.
2. Save an unsigned ProgRSS file without opening the attribution disclosure. Confirm another fresh ProgRSS installation reviews it as **Unsigned shared folder** and does not imply a verified curator.
3. Open **Attribution and signature (optional)**. Add a bounded name and note. Confirm no account, contact lookup, or remote request is required.
4. Create a local signing identity. Confirm the displayed fingerprint is understandable, the private key remains browser-local, and private-library or recovery exports do not contain the key.
5. Save a signed ProgRSS file. In another fresh installation, review it and confirm **Signature verified**, the curator name, note, and compact key fingerprint are shown together with the warning that this does not prove real-world identity or source safety.
6. Change one source address, page-watch rule, folder relationship, curator character, or note character in a copy of the JSON. Confirm the tampered file is refused rather than downgraded to unsigned.
7. Import the valid signed file. Confirm existing recipes are reused, new sources start paused, no site is contacted, no permission prompt appears, and the root folder retains only bounded origin evidence.
8. Import a legacy `progrss.bundle.v1` file. Confirm it remains supported and is described as an older Relay-era file without attribution or a signature record.
9. Allow the Firefox background page to unload, then repeat verification and import. Confirm durable import state does not depend on background globals.
11. Repeat the export and review at 320 CSS pixels with enlarged text, keyboard only, forced colors, and the screen reader used for the rest of this checklist. Confirm the disclosure, fingerprint, caution, and primary actions remain ordered and fully operable.

## Ready-to-host shared-folder website

1. Select a simple folder and open **Share this folder**. Confirm **Put this folder on a website (optional)** is a secondary disclosure rather than a new primary navigation destination.
2. Leave the public address empty and press **Save ready-to-host website**. Confirm ProgRSS refuses with a literal request for the hosted `.json` address and creates no file.
3. Try an address with credentials, a query string, a fragment, no filename, a non-HTTP scheme, and a traversal-like encoded filename. Confirm each is refused locally without a network request.
4. Put one source directly in two folders and give those placements different curator reasons. Leave another placement without a reason.
5. Enter a controlled direct address such as `https://example.test/reading/latest.json`, include a curator name and note, and choose signing. Save the ready-to-host website.
6. Open the downloaded ZIP outside Firefox. Confirm it contains `index.html`, `latest.json`, `subscriptions.opml` when feeds exist, and `README.txt`; confirm no duplicate member or directory traversal exists.
7. Verify the JSON as the same signed `progrss.bundle.v3` publication and confirm its configured address names `latest.json`. Confirm both placement reasons remain attached to their exact folder/source members and that the private signing key, reading history, saved state, retained items, snapshots, validators, and browser permissions are absent.
8. Inspect `index.html`. Confirm the title, curator, note, feed/page/folder/reason counts, source hierarchy, download links, and signature limitation are understandable without prior explanation. Confirm the same source appears under both folders with the correct distinct reason each time, while the reason-absent placement has no invented note.
9. Confirm each visible note is labeled **Curator’s reason for this folder**, names curator authorship rather than ProgRSS authorship, and says it is not a ProgRSS safety claim. Include multiline, markup-like, and right-to-left text; confirm line breaks are retained, markup is escaped, and direction remains readable.
10. Inspect the HTML source and network panel. Confirm there are no scripts, remote stylesheets, images, frames, forms, embedded media, trackers, service workers, or automatic requests. Confirm its Content Security Policy begins from `default-src 'none'`.
11. Import `subscriptions.opml` in another feed reader. Confirm feeds and nested simple folders are present, watched pages and every curator reason are absent, and the package never represents page watches or Source Notes as feeds or private OPML attributes. Confirm `README.txt` explains both omissions.
12. Serve the extracted directory from a plain static host. Load `index.html`, download both portable files, and use the hosted `latest.json` through **Check for a newer copy**. Confirm hosting the page does not create polling or automatic application.
13. Repeat with a folder containing only page watches. Confirm the ZIP omits OPML but retains the watches and placement reasons in the native JSON and explains the omission.
14. Repeat at 320 CSS pixels, enlarged text, keyboard-only navigation, forced colors, and the screen reader used for the rest of this checklist. Confirm the disclosure and generated page remain understandable and operable.

## Feed preview before follow

1. Open a controlled page advertising two feeds and choose **Add → Use this page**. Confirm unfamiliar candidates say **Preview**, while an already-followed candidate says **View … · already following**.
2. Activate the second candidate. Confirm the Firefox-owned optional-permission decision occurs from that visible action and no source exists before the decision.
3. Confirm the preview heading receives focus and shows at most three feed-supplied titles and dates plus a plain content-availability note. Confirm no summary/body text, article page, image, script, frame, audio, video, or embedded resource is loaded.
4. Confirm **Follow this feed** is a separate action. Choose **Back to page options** instead and verify the original candidates return with focus on the exact Preview button that opened the sample.
5. Repeat through **Paste an address** using the feed URL directly. Confirm the same preview appears, nothing is followed until the separate Follow action, and the added source receives the normal first-source handoff afterward.
6. Exercise a cross-origin redirect from a candidate. Confirm ProgRSS stops before destination contact, offers a literal continuation decision, and preserves **Back to page options** across the redirect review.
7. Repeat at 320 CSS pixels with enlarged text, keyboard only, forced colors, and the screen reader used for this checklist. Confirm the preview order, heading focus, full-word actions, and return focus remain understandable.

## Native publication-page discovery

1. Serve a generated Wayside package from a controlled HTTPS origin and open its `index.html` in Firefox. Confirm the page itself loads no script, remote image, frame, or automatic JSON request.
2. Open ProgRSS beside that page, choose **Add → Use this page**, and confirm **Shared folder available** and **Review shared folder** appear without the JSON being requested yet.
3. Confirm the generic **Watch this page** proposal is absent on that recognized publication page. If the page also advertises a feed, confirm the feed candidate remains available.
4. Press **Review shared folder**. Confirm the Firefox-owned optional-permission decision belongs to that visible action and the JSON request begins only after access exists.
5. Confirm the signed, unsigned, or legacy review uses the same attribution, safety limits, counts, existing-source reuse, paused-new-source behavior, and import/update decisions as local-file review. Return with **Back to page options** and confirm focus and discovery state remain understandable.
6. Change the advertisement to generic `application/json`, another origin, two competing ProgRSS links, malformed JSON, an invalid digest, or an invalid signature. Confirm each is refused without an import, source permission, scheduled request, or destination contact across origins.
7. Redirect the page or bundle through up to five same-origin hops and confirm bounded success. Redirect across origins and confirm ProgRSS stops before contacting the destination.
8. Open Add, choose **Paste an address**, and paste the exact hosted JSON address. Confirm the Firefox-owned optional-permission decision belongs to the explicit Check action, then confirm **Shared folder found** appears with one **Review shared folder** action.
9. Open that review and confirm it reuses the same signed/unsigned/legacy and import/update consequences as page discovery. Choose **Back to address result** and confirm the inspected result remains understandable and focused.
11. Repeat with valid native JSON served as `text/plain`; confirm full validation permits it. Repeat with an unrelated JSON object whose filename ends in `.json`; confirm it is not treated as a shared folder.

## Manual shared-publication rendezvous

1. Share a simple folder with **Address where future copies can be checked** left empty. Confirm the file is `progrss.bundle.v2` and no **Check for a newer copy** action appears after import.
2. Share the same folder with a controlled credential-free HTTP(S) address. Confirm the file is `progrss.bundle.v3`, contains `progrss.shared-folder.distribution.v1`, and changing one address character makes digest or signature verification fail.
3. Import the valid v3 file into a fresh Firefox profile. Select another folder and confirm no check action appears there. Select the imported publication and confirm exactly one **Check for a newer copy** action appears beside **Share this folder**.
4. Press the check action and deny or dismiss Firefox’s site-access prompt. Confirm the server receives no request, the library remains unchanged, and no timer or badge appears.
5. Press it again and grant access. Confirm the controlled server receives one credential-free request only after the click. Confirm the review says the copy was fetched only on request, omitted credentials, schedules no later check, and changed nothing.
6. Confirm the review presents **Update from this copy**, **Keep my local version**, and **Import as a separate folder**. Choose **Keep my local version** and verify no source, folder, read state, saved state, permission, or schedule changed.
7. Serve the same publication through up to five same-origin redirects. Confirm the review opens. Repeat with a redirect to another origin and confirm Firefox/ProgRSS stops before the destination receives a request and names the move without inheriting authority.
8. Return a different publication identifier, malformed JSON, oversized content, a disconnected graph, a digest mismatch, and an invalid signature. Confirm each is refused without a write or automatic retry.
9. Apply a valid update that changes its future-copy address. Confirm the review calls out that consequence and the new address is used only after the next explicit check. Apply a valid copy that removes the address and confirm the check action disappears.
10. Allow the Firefox background page to unload, restart Firefox, and reopen the imported folder. Confirm the address persists in the collection origin, but no request occurs until the button is pressed.
11. Export OPML from the located folder. Confirm it reports that the future-copy address, page watches, and ProgRSS integrity metadata are omitted rather than encoding them as ordinary feed outlines.
12. Repeat at 320 CSS pixels with enlarged text, keyboard only, forced colors, and the screen reader used for the rest of the checklist. Confirm the check action, permission consequence, fetched-copy note, signer warning, and three decisions remain ordered and fully operable.

## First useful minute and folder views

1. Start with a fresh library. Confirm Today explains that nothing is followed yet and offers the same three direct choices as Add: use the current page, paste an address, or move subscriptions from another reader.
2. Confirm there is no mandatory tour and no bundled starter subscription.
3. Follow one controlled feed. Confirm ProgRSS returns to Today and explains whether updates are ready, nothing was new, a webpage baseline was saved, or the source needs attention. Use **Source details** and confirm focus reaches that exact source card.
4. Import an OPML file containing nested plain folders. Confirm the review says those folders will appear in Today and Sources.
5. In Today, choose a nested folder path. Confirm reading, unread counts, search, and **Mark folder read** stay inside that folder; then undo and confirm only those updates are restored.
6. In Sources, choose the same folder. Confirm only its sources appear and direct folder membership is shown in ordinary labels.
7. Open one source’s **Activity and options**. Add it to an existing nested folder. Confirm direct membership is distinguished from the parent folders in which it appears automatically.
8. Use the twelve-second undo and confirm only that direct placement is removed. Repeat while changing the folder in another ProgRSS view and confirm stale undo refuses to erase the newer organization.
9. Add the source again, then choose **Remove from folder**. Confirm only the selected direct placement is removed and any inherited parent membership remains visible.
10. Undo the removal and confirm the exact direct placement returns. Change the folder in another view before undo and confirm the newer organization is kept.
11. Follow another source while a simple folder exists. Confirm Today shows the first reading result before offering the optional folder choice, and that reading does not depend on making a folder decision.
12. Confirm the basic reader offers no folder creation, hierarchy editing, renaming, deletion, or collection-operator controls.
13. Confirm filtered, subtractive, intersecting, or cyclic Advanced Workbench collections are not flattened into misleading basic folders.
14. Restart Firefox. Confirm the selected folder is restored when it still exists and safely falls back to **All folders** when it does not.

## Page-watch shape confirmation

1. Create a region watch with at least 400 normalized characters or a repeated-entry watch with at least four entries. Record the accepted baseline.
2. Change the controlled page once so the saved selector still matches readable content but the entry count falls below 40% or the watched text falls below 25% without reaching the immediate-collapse boundary. Refresh once.
3. Confirm the source remains in **Following**, shows **Checking again**, and says that no page-change alert was created. Confirm Today contains no new event for that observation and the saved snapshot remains unchanged.
4. Confirm **Check again** is available but no automatic immediate retry, toolbar badge, browser notification, or extra permission prompt appears. Allow the Firefox background page to unload, reopen the Sidebar, and confirm the pending state survives.
5. Restore the page to its usual shape and refresh. Confirm the held result is discarded, no alert appears, and the source reports that the page returned to its usual shape.
6. Repeat from a fresh baseline. Show one unusual shape, then a compatible second unusual shape. Confirm the second check accepts the repeated new shape, clears the pending state, and only then runs the ordinary page-change comparison.
7. Repeat with three incompatible unusual shapes. Confirm the third check stops the watch for selector-free repair and creates no alert from the unstable shape.
8. Export a private transfer while one result is pending. Confirm `watchStability` is absent. Restore that file in another installation and confirm it does not inherit the unfinished confirmation.
9. Repeat with keyboard only, enlarged text, forced colors, and the screen reader used for this checklist. Confirm **Checking again**, the no-alert explanation, and **Check again** are read in a sensible order without moving the source into the urgent group.

## Page-watch repair

1. Create a controlled repeated-entry page watch, then change the page so the saved selector is still valid but matches nothing. Confirm the source enters **Needs your attention**, scheduled and bulk refreshes skip it, and no synthetic removal alert is created.
2. Repeat with a syntactically invalid saved selector. Confirm the reader distinguishes a broken rule from a valid rule that currently finds no section, while keeping selector syntax out of Sources.
3. Choose **Find what to watch now**. Deny or dismiss Firefox's site-access prompt and confirm no inspection, source mutation, or permission retry occurs in the background.
4. Grant access and review the proposals. Confirm overlapping technical rules that observe the same content appear as one human choice, representative titles are bounded, and a main-text fallback is explicit.
5. Choose **Keep current watch**. Confirm the source remains stopped, the review closes, and focus returns to the repair action.
6. Review again and choose **Use this section**. Confirm ProgRSS re-fetches the current page, refuses a stale proposal if the page changed, updates only the watch recipe, saves a fresh baseline, creates no page-change item, and preserves earlier alerts, read/saved state, folders, and source activity.
7. Let the Firefox background page unload, reopen the Sidebar, and confirm **Undo watch repair** remains available for thirty minutes. Undo and confirm the exact earlier broken rule and baseline return.
8. Repair again, then make a newer reading or folder change. Confirm stale undo refuses rather than overwriting the newer library.
9. Export a private transfer while undo is live. Confirm `pageWatchRepairUndo` is absent, while the repaired recipe and earlier alerts remain portable.
10. At 320 CSS pixels with enlarged text, keyboard-only input, forced colors, and a screen reader, confirm proposal examples, both decisions, focus return, and the undo control remain understandable without horizontal scrolling.

## Page-watch change explanations

1. Add a controlled page watch for a repeated-entry page. Confirm the first observation becomes a baseline and creates no unread change.
2. Change words inside one watched entry. Confirm Today offers **See change**, not **Read here**, and opens a focused explanation with **Why ProgRSS noticed this**, **Before**, and **Now**.
3. Confirm removed text is represented by a semantic `del` element and added text by a semantic `ins` element, while the visible **Before** and **Now** headings remain sufficient without color.
4. Add and remove complete entries. Confirm the explanation says an entry was added or removed and preserves a bounded human-readable excerpt.
5. Enable the existing ignore-numbers option in Advanced Workbench, change only a number, and confirm no alert is created. Then change a word and confirm the alert appears.
6. Open Sources → Activity and options for the watch. Confirm the ordinary reader explains whether it watches repeated entries or main text, names the sensitivity threshold, and says where fine-tuning lives without exposing selectors.
7. Search for a word that exists only in the saved **Before** or **Now** context. Confirm the page-change result appears without network activity.
8. Export and restore a private library. Confirm a valid `progrss.page-change.v1` explanation survives, while an invalid or oversized explanation is rejected rather than silently trusted.
9. Repeat the detail view at 320 CSS pixels with a 20-pixel root font, keyboard only, forced colors, and the screen reader used for the rest of the checklist. Confirm the reason and both passages remain ordered, named, and free of horizontal scrolling.
10. Load a legacy page-watch alert created before Trace. Confirm ProgRSS labels it as an older alert whose detailed Before/Now context was not retained, rather than presenting its summary as feed-supplied article text.

## Focused feed reading

1. Load a controlled RSS, Atom, and JSON Feed where summary and full body differ. Confirm **Read here** appears and the focused view names whether full feed text or only an excerpt was supplied.
2. Include literal markup text, scripts, an iframe, an image, SVG, media, and an Atom `content src`. Confirm only inert plain text is retained, no embedded resource is requested, and the `src` content is not fetched.
3. Use `j` and `k` inside the focused view, then Escape. Confirm update movement is bounded to the current visible list and focus returns to the exact **Read here** control that opened the detail.
4. At 200% zoom and a 320 CSS-pixel Sidebar, confirm there is no horizontal scrolling and no browser or ProgRSS navigation covers Mark read, Save, Open original, Newer update, or Older update.
5. Check forced-colors/high-contrast mode. Confirm the completeness note, focus indication, buttons, disabled states, and body text remain distinguishable.
6. Search for a word present only in retained body text. Confirm the correct update appears without network activity.
7. Restart Firefox or allow the background page to unload. Confirm the retained body survives in IndexedDB and remains readable.
8. Export and restore a private library. Confirm the body, `bodyIsSummary`, and declared language metadata travel while browser permission and local undo state do not.
9. Use controlled JSON Feed, Atom, and RSS specimens declaring Arabic, Persian, Hebrew, and English language values. Confirm source names, update titles, summaries, and focused bodies expose the declared `lang`; invalid or absent tags are not guessed.
10. Put an Arabic or Hebrew paragraph beside an English paragraph in retained text. Confirm each text-only paragraph chooses its own natural direction, controls remain in the interface direction, and 200% zoom introduces no horizontal scrolling.
11. With NVDA or another available screen reader, verify pronunciation changes when moving between declared-language passages and record the browser/screen-reader versions and any mismatches. Automated DOM checks do not count as this human acceptance.

## Offline reading storage controls

1. Follow a controlled feed that supplies distinct summaries and fuller bodies. Confirm Sources shows a compact **Offline reading** disclosure rather than a dashboard of quota settings.
2. Confirm the retained-full-text count and UTF-8 byte total change when controlled bodies are added. When Firefox exposes an origin storage estimate, confirm ProgRSS labels it approximate and keeps it visually separate from the exact full-text total.
3. Open **Activity and options** for one feed and choose **Keep summaries only**. Confirm the choice says it affects future checks and does not silently delete older bodies.
4. Refresh the feed with a new item. Confirm the summary remains readable, the item explains that fuller text was omitted by the source choice, and no article page, image, script, frame, or linked content is requested.
5. Mark one full-text update read and leave it unsaved. Keep another unread and save a third. Run **Clear read, unsaved full text**. Confirm only the read, unsaved body is removed.
6. Use the twelve-second undo while the Sidebar remains open and confirm the exact body returns. Repeat, change the library in another ProgRSS view, and confirm stale undo refuses to overwrite the newer revision.
7. Choose **Keep full feed text**, refresh an otherwise unchanged intentionally omitted item, and confirm it is enriched in place without becoming a false unread revision.
8. Restart Firefox. Confirm the source choice and retained/omitted item state survive in IndexedDB, while the short open-reader cleanup undo is not presented as a durable backup.
9. Export and restore a private library. Confirm `textRetention` and `bodyOmitted` travel, while browser quota/eviction state and the live cleanup undo do not.
10. At 200% zoom, 320 CSS pixels, forced colors, keyboard-only use, and a screen reader, confirm the overview, radio choices, cleanup action, warning, and undo remain understandable and operable. Record the actual Firefox and assistive-technology versions.

## Quiet private-copy reminder and saved-file check

1. Create a meaningful controlled library and confirm no reminder appears immediately, in Today, or as a toolbar badge or browser notification.
2. In a disposable profile, backdate only `progrssBackupReminder.firstMeaningfulAt` far enough to make the first reminder due. Confirm Sources shows **Keep a copy outside this browser** without blocking source controls.
3. Inspect the marker. Confirm it uses `progrss.backup-reminder.v3` and contains reminder times/revisions, a random 64-hex-character `fingerprintKey`, keyed prepared/checked fingerprints, snooze state, missing state, and a disabled flag—but no source address, title, update identity, retained text, folder name, reading state, or Workbench record.
4. Seed a valid version 2 marker, unload and revive the Firefox background page, and confirm it migrates to version 3 without inventing prepared or checked fingerprints. Seed a version 1 marker separately and confirm its old download event remains prepared evidence rather than becoming checked evidence.
5. Choose **Remind me in 30 days**, allow the Firefox background page to unload, and reopen the Sidebar. Confirm the reminder remains quiet and **Private copy** says when it returns.
6. Turn reminders back on, choose **Don’t remind me again**, unload the background page, and confirm the choice persists. Confirm **Turn reminders on** remains available in the collapsed disclosure.
7. Choose **Save private copy**, then cancel Firefox’s download or remove the downloaded file. Confirm ProgRSS still says **Copy prepared · not checked** and does not claim that a backup was verified. Confirm `progrss.backup-reminder.v3`, its key, and its fingerprints are absent from the exported JSON.
8. Save another private copy. Choose **Check saved copy**, select that local file, and confirm ProgRSS says **This saved copy matches**. Confirm the check causes no network request, vault write, permission prompt, restore, or source refresh.
9. Choose **I can’t find the checked copy**. Confirm the reader says the recorded copy is missing without deleting any file or changing the vault. Unload and revive the background page; confirm the missing state persists.
10. Select that same known file again. Confirm ProgRSS clears the missing state and records that the copy was readable again.
11. Change the portable library after a successful check, then select the earlier checked file. Confirm ProgRSS says it is a readable older known copy, does not restore it, leaves the current library unchanged, and clears a missing marker if one was set.
12. Select a different valid ProgRSS private file that is neither the current nor remembered prepared/checked copy. Confirm ProgRSS explains that it is a different valid copy, reports only bounded differences, changes no marker or library data, and keeps reviewed replacement under Add → Move this ProgRSS library.
13. Select malformed JSON, an oversized file, and a non-ProgRSS JSON file. Confirm each is refused without changing the checked-copy marker.
14. Backdate `lastSeenAt` by more than ninety days while the current library remains unchanged. Confirm Sources quietly asks the person to check that the saved copy still opens; confirm no automatic file access or notification occurs.
15. Change the library after a successful check. Confirm the ordinary changed-library reminder does not return until thirty days have passed, unless the copy is explicitly marked missing.
16. Trigger a controlled failed-write incident and a missing-library state separately. Confirm each recovery path takes precedence and the routine reminder is hidden.


## Missing local library recovery

1. Populate a controlled library, then export a private transfer file and keep it outside the Firefox profile.
2. Inspect extension-local storage with Firefox developer tools. Confirm `progrssLibraryPresence` uses `progrss.library.presence.v1`, records bounded counts/revisions/times, and contains no source address, title, retained text, folder name, snapshot, or Workbench record.
3. In a disposable profile, delete only the ProgRSS IndexedDB database while retaining extension-local storage. Do not use a production profile for this test.
4. Reopen the Sidebar. Confirm it says the local library appears missing rather than presenting ordinary first use. Confirm the toolbar badge is `!`.
5. Confirm refresh, following, OPML import, transfer export, and Advanced Workbench saves are blocked while recovery is unresolved. Confirm the reader can still choose **Restore private file** or **Use empty library**.
6. Allow the Firefox background page to unload, then reopen ProgRSS. Confirm the recovery decision remains available and its remembered counts remain non-sensitive.
7. Choose **Restore private file**, review the transfer, and restore it. Confirm no replacement acknowledgement or local transfer undo is invented for the actually empty destination. Confirm destination site access is checked normally.
8. Repeat the controlled IndexedDB deletion, choose **Use empty library**, and confirm ordinary first use resumes. Later restore the same private file and confirm that accepting an empty start did not invalidate the external backup.
9. Clear both IndexedDB and extension-local storage in a disposable profile. Confirm the marker cannot survive and record that ProgRSS cannot distinguish that complete local loss from a new installation.
10. Uninstall the temporary add-on. Confirm no claim is made that the marker or vault survives uninstall. The external private file is the only recovery evidence outside the profile.

## Shared-folder continuity

1. In a fresh Firefox profile, import a signed native shared folder. Confirm the review is local, no site permission prompt appears, and new sources begin paused.
2. Select a later copy with the same publication identifier and the same signing key. Confirm the review says the same key signed the copy and names source, folder, hierarchy, attribution, and local-edit consequences before any write.
3. Make a local source-label change, remove one publication membership, and add a local membership. Review the later copy again. Confirm all three local choices are reported as staying local.
4. Confirm the reader presents exactly **Update from this copy**, **Keep my local version**, and **Import as a separate folder**.
5. Apply the update. Confirm changed acquisition recipes use a separate paused source, the earlier source history remains, and removed publication sources retain their updates and local placements.
6. Confirm **Undo folder update** remains available after the Firefox background page unloads. Undo and verify the exact pre-update library returns.
7. Apply the update again, then make a reading or folder change. Confirm stale undo refuses to erase the newer work.
8. Repeat with a later copy signed by a different valid key. Confirm **Update from this copy** is disabled until the signing-key change is acknowledged. Confirm the wording does not claim to know why the key changed.
9. Repeat with a signed-to-unsigned copy. Confirm the downgrade receives the same explicit continuity warning and acknowledgement boundary.
10. Present an older issued copy and an equal-time different-content copy. Confirm rollback and conflict are refused while **Import as a separate folder** remains available.
11. Import the same publication twice and present a later copy. Confirm ProgRSS refuses to guess which local copy should be updated.
12. Use a library carrying only `progrss.shared-folder.origin.v1`. Confirm it remains readable but is not overwritten in place because no safe baseline exists.
13. Give one imported folder an Advanced Workbench collection rule. Confirm in-place update is blocked rather than flattening the rule.
14. Remove a publication subfolder remotely while a surviving locally edited publication folder still refers to it. Confirm the removed branch detaches and remains valid instead of disappearing or leaving a broken reference.
15. Export a private transfer while update undo is live. Confirm `sharedFolderUpdateUndo` is absent and the continuity baseline remains portable.

## Same-source repair

1. Create two controlled feed histories that share one exact current, declared, previous, or previously reviewed alias address. Give each history distinct read/saved state, folder placement, activity, scheduling, and HTTP validators.
2. In Sources, confirm ProgRSS says that two histories may describe the same feed but combines nothing automatically.
3. Open the review. Confirm both source names, current addresses, update/unread/saved counts, direct and inherited folders, activity landmarks, next check, site access, and check-memory presence are legible.
4. Select which source remains. Confirm the projected result explains retained updates, collapsed exact repeats, reading-state union, and remapped folders before the action becomes available.
5. Complete the repair. Confirm the selected source keeps its current address, schedule, permission context, pending move, and cached validators. Confirm the removed source's validators and authority are not pooled.
6. Confirm exact duplicate update content collapses with unread and saved state preserved, while genuinely different revisions remain separate.
7. Close/reopen the Sidebar and allow the background page to unload if practical. Confirm **Undo source repair** remains available for thirty minutes.
8. Undo and confirm the two exact prior histories return. Repeat, change the merged library in another ProgRSS view, and confirm stale undo refuses to erase newer reading or organization.
9. Add an Advanced Workbench record that refers to either source or affected update. Confirm the reader blocks repair and points to Advanced cleanup rather than rewriting opaque records.
10. Export a private transfer while undo is live. Confirm `sourceRepairUndo` is absent.

## Exact graft-receipt retirement

1. Add one `progrss.recipe.graft.receipt.v1` record that exactly refers to either same-source history or an affected retained update. Confirm Sources blocks the history repair and routes to **References to these histories**.
2. In the Workbench report, confirm the receipt is named, the exact references are shown, and **Review retirement** appears only for that schema.
3. Open the review. Confirm ProgRSS says the receipt will leave active history but remain preserved as retired evidence; confirm the original receipt digest and the affected source/update references are visible.
4. Confirm **Retire receipt** remains disabled until the explicit acknowledgement is checked.
5. Change the vault in another ProgRSS view before committing. Confirm retirement refuses the stale review and requires a fresh report.
6. Complete the retirement. Confirm the exact receipt no longer blocks repair, a `progrss.retired.graft-receipt.v1` evidence envelope is shown, and the embedded original receipt is unchanged.
7. Close/reopen the Workbench and allow the Firefox background page to unload if practical. Confirm **Undo receipt retirement** remains available for thirty minutes.
8. Undo and confirm the exact active receipt returns. Retire it again, then change the library; confirm stale undo refuses to erase newer work.
9. Export a private transfer while retired evidence and undo are present. Confirm `retiredReceipts` is portable, its canonical digest verifies, and `receiptRetirementUndo` is absent.
11. Repeat with a merge receipt, trust binding, exchange record, captured fixture, or unknown schema. Confirm no retirement shortcut appears and the history repair remains blocked.

## Page discovery and optional permissions

1. Open a normal public HTTP(S) page with an advertised feed.
2. Click the ProgRSS toolbar action, open Add, and choose **Use the page I’m on**.
3. Confirm candidates are shown without fetching every candidate automatically.
4. Choose a candidate and deny or dismiss Firefox’s site-access prompt. Confirm the reader uses a neutral decision status, names the candidate site, says the preview was not opened and nothing was followed, and leaves the candidate available. Confirm no background inspection or source mutation occurs.
5. Repeat and grant access. Confirm the preview opens first and the source is added only after the separate **Follow this feed** action.
6. Paste a feed address from another origin. Decline or dismiss the prompt. Confirm the address is not checked, nothing is added, the status does not accuse the person of denying access, and the same **Check** action remains available. Then grant access and continue.
7. Follow a controlled feed whose requested address differs from its same-origin Atom `rel=self`, RSS `atom:link rel=self`, or JSON Feed `feed_url`. Paste the alternate address and confirm ProgRSS offers **View source** instead of adding a duplicate.
8. Repeat with a cross-origin declared self address. Confirm it is not accepted as an alias, does not trigger a request, and does not grant access.

## Permission refusal, dismissal, and retry

1. Put one source into each of these states: **Paused**, **Reconnect**, **Moved**, **Checking again**, and **Repair watch**.
2. For each visible action—**Resume**, **Reconnect and check now**, **Follow at …**, **Check again**, and **Find what to watch now**—decline or dismiss Firefox’s site-access prompt.
3. Confirm the status uses the same neutral decision treatment, names the relevant host or hosts, and gives an action-specific unchanged consequence.
4. Confirm no source toggle, refresh, accepted move, page-watch preview, repair, item, or alert transaction occurs after the ungranted request.
5. Close and reopen the Sidebar. Confirm the source remains in its earlier state and retry still uses the original visible action.
6. Repeat each action with access granted. Confirm it proceeds exactly once and no refused attempt was replayed in the background.
7. Start an active check, then remove its granted site permission from Firefox’s add-on controls. Confirm the request aborts, the source becomes **Reconnect**, and later scheduled checks do not produce another prompt.

## Persistence and revocation

1. Read and save an update, then close the Sidebar.
2. Restart Firefox and reload the temporary add-on if Firefox removed it as expected for temporary installations.
3. Confirm private backup export/restore preserves read and saved state. Do not claim temporary-add-on storage survival across removal unless directly observed.
4. Remove a granted site permission while its source is active.
5. Confirm the source becomes **Reconnect**, scheduled checks skip it, and **Reconnect and check now** is the only permission-requesting path.

## Private library transfer

1. In Add, choose **Save private transfer file**. Confirm Firefox downloads a JSON file without ProgRSS requesting a downloads permission.
2. Inspect the file locally. Confirm it uses `progrss.private.v1` and excludes `_revision`, `transferUndo`, `sourceRepairUndo`, and `receiptRetirementUndo`.
3. In a second fresh Firefox profile or temporary installation, choose **Bring in a ProgRSS transfer file**.
4. Confirm the local review shows source/update/saved/collection counts, replacement consequences, private-data language, and the number of active sources that may need Reconnect.
5. With a non-empty destination library, confirm **Replace with this library** remains disabled until the replacement acknowledgment is checked.
6. While the review is open, change the destination library in another ProgRSS view. Confirm replacement stops and the Sidebar presents an updated review rather than overwriting the newer state.
7. Complete the move. Confirm active sources without destination permission show **Reconnect**, paused sources stay paused, and pending cross-site moves remain **Moved** decisions.
8. Confirm **Undo library move** restores the prior local library after a Sidebar close/reopen and after the background page has been unloaded if practical.
9. Export again before undo expires. Confirm the new file does not recursively contain the previous library’s safety copy.
10. Wait beyond thirty minutes or advance a controlled test clock, then confirm the undo expires and its private copy is removed.

## Movement and bytes

1. Use controlled local servers to test a permanent same-origin redirect, temporary same-origin redirect, cross-origin redirect, loop, HTTP 304, HTTP 429, HTTP 503, UTF-16, Windows-1252, a UTF-8 byte-order mark that conflicts with the HTTP charset, an unsupported charset, `application/feed+json`, HTTP `Link` feed discovery, malformed XML, oversized bytes, and a slow stream.
2. Confirm a cross-origin redirect stops before the destination receives a request.
3. Confirm accepting a move never sends the old origin’s validators to the new origin.
4. Confirm a second cross-origin hop requires another decision.

## Accessibility and platform behavior

1. Complete the reader with keyboard only at 200% zoom and a narrow Sidebar.
2. Check visible focus, heading movement after Today/Sources/Add navigation, status announcements, and complete action names with NVDA or another available screen reader.
3. Check forced-colors/high-contrast behavior and reduced motion.
4. Confirm the browser’s native Sidebar controls remain usable and are not imitated by webpage controls.

## Reporting boundary

A pass requires observed behavior in a real Firefox desktop runtime. The Node Firefox background harness proves namespace and architectural routing only; it does not prove browser prompts, Web Request events, IndexedDB lifetime, Sidebar rendering, restart behavior, or assistive-technology behavior.

## Signpost and Edition — native Sidebar and file download

1. Select an existing simple folder containing at least two sources and retained updates.
2. Open **Share this folder**, then open **Share recent updates (optional)**.
3. Confirm the secondary disclosure does not displace or rename the native shared-folder action.
4. Activate **Save recent updates as feed** with keyboard only.
5. Confirm Firefox saves one JSON file and no site-permission prompt appears.
6. Open the file locally and verify it is JSON Feed 1.1 with `_progrss.schema` equal to `progrss.folder-edition.v1`.
7. Confirm ordinary duplicate article URLs collapse with source witness labels.
8. Confirm the file does not contain full retained feed bodies, `readAt`, `starred`, page-watch `before`/`after` passages, snapshots, permission data, validators, schedules, or private keys.
9. Repeat at 200% and 400% zoom, with forced colors, keyboard-only use, and the available screen reader.
10. Ask an unfamiliar participant whether the file updates itself. Record any answer other than “no; prepare another edition.”


### Combined static package

1. Return to **Share this folder** and open **Put this folder on a website (optional)**.
2. Enter a direct public address ending in a simple `.json` filename.
3. Confirm **Include a recent-updates feed** is initially unchecked and that the ordinary website package still works without it.
4. Check **Include a recent-updates feed** and activate **Save website with recent updates** with keyboard only.
5. Open the ZIP locally and confirm it contains `index.html`, the configured native JSON filename, `subscriptions.opml` when feeds exist, `recent-updates.json`, and `README.txt`.
6. Confirm `index.html` advertises both `application/vnd.progrss.shared-folder+json` and `application/feed+json`, displays a small recent-update list, and loads no script, frame, remote image, stylesheet, or item page.
7. Confirm `recent-updates.json` has hosted `home_page_url` and `feed_url` values, matches the shared folder’s name and attribution, and contains no full retained body, reading state, saved state, Before/Now evidence, snapshot, permission, or private key.
8. Repeat with a mismatched Edition file through the CLI or test fixture and confirm packaging is refused rather than silently omitting it.
9. Ask an unfamiliar participant to distinguish the native folder download from the recent-updates feed and to explain how either is updated.

Record the Firefox and operating-system versions, assistive technology and version, file-picker behavior, final focus location, and any wording that suggests a live publication service.


### Signpost recipient choice in the native Sidebar

1. Host the generated package on a controlled same-origin static server.
2. Open `index.html`, then use **Add → Use this page** from the native Sidebar.
3. Confirm the initial result names **Add the source list** and **Follow recent updates** as different consequences.
4. Confirm discovery itself requests neither advertised JSON file and contacts none of the listed sources.
5. Activate **Preview recent updates**. Confirm the browser-owned site-access decision occurs from that visible action, the feed receives a bounded title/date preview, and the explanation says following adds one summary feed only.
6. Return with **Back to page options** and confirm focus returns to the recent-updates choice.
7. Activate **Review source list**. Confirm the source-list file is fetched and verified separately and that review does not contact any listed feed or watched page.
8. Deny or dismiss each request once, then retry. Confirm the unchanged consequence is explained without a hidden replay.
9. Repeat with a source-list-only package and confirm the Sidebar shows the single source-list review path without inventing a missing-feed warning.
10. Record exact Firefox/ESR version, prompt behavior, Sidebar focus, screen-reader announcements, enlarged-text reflow, forced-colors behavior, and unfamiliar-participant wording errors.


## Branch — selective source-list adoption in the native Sidebar

1. Host or open a valid signed or digested source list with a root folder, two populated nested branches, at least one watched page, and one source reused across branches.
2. Reach the ordinary source-list review and confirm **Add source list** remains the primary whole-list action.
3. Open **Add just one folder section (optional)** with keyboard only. Confirm one ordinary select lists populated folder routes and bounded source counts; empty folders are absent.
4. Choose one branch and activate **Review this section**. Confirm the next review contains only the selected folder, descendants, and referenced sources.
5. Confirm the review says the result becomes an independent local folder and is not linked to future copies of the parent publication.
6. Confirm the parent signature explanation names the checked parent document and does not claim that the derived excerpt is separately signed.
7. Add the section. Confirm existing exact sources are reused, new sources begin paused, no listed site is contacted, and the imported root has no shared-publication origin or future-copy action.
8. Open a later parent publication copy. Confirm it does not offer to overwrite the independent excerpt.
9. Repeat with an ambiguous or empty section fixture and confirm ProgRSS refuses rather than guessing.
10. Test at 200% and 400% zoom, forced colors, keyboard only, and the available screen reader. Record whether **source list**, **folder section**, **independent local folder**, and **future copies** are understood without coaching.

This section is an execution protocol. Its presence in the package is not a native Firefox or human-acceptance result.

## Contents — source-list comprehension in the native Sidebar

1. Host or open a valid source list containing at least seven sources, including one feed, one watched page, and one nested simple folder.
2. Reach review through both **Add → Use this page → Review source list** and **Paste an address → Check → Review source list**.
3. Confirm the initial page or address inspection does not fetch any listed source. Grant access only to the chosen source-list file when Firefox requests it.
4. Confirm **See … sources and … folders** begins collapsed for the larger list and is operable with Enter and Space from the keyboard.
5. Confirm the disclosure exposes each source’s title, host, **Feed** or **Watched page** type, route, and import/update consequence.
6. Confirm no complete source URL, CSS selector, threshold, validator, permission state, or signature byte appears in the ordinary review.
7. Repeat with a list of six or fewer sources and four or fewer folders; confirm the contents begins open without moving focus unexpectedly.
8. Deny or dismiss the Firefox permission request once, then retry. Confirm no contents are fabricated from an unfetched file and no hidden replay occurs.
9. Test at 200% and 400% zoom, forced colors, keyboard only, and the available screen reader. Confirm summary state, heading order, list structure, and Back focus are understandable.
10. Ask an unfamiliar participant to name one feed, one watched page, and their folder routes without importing the list. Record every misunderstood word and wrong turn.

This section is an execution protocol. Its presence in the package is not a native Firefox or human-acceptance result.

## Perimeter — page coverage in the native Sidebar

1. Use the supplied pagination, virtualized-list, overlay, busy, frame/open-shadow, hidden-duplicate, and RTL fixtures. Confirm the candidate result is `progrss.browser-capture-candidates.v3` with `perimeter-v1` provenance.
2. Confirm **What this browser view may leave outside** appears before the section choices and remains distinct from **More likely to stay put / Needs watching / Fragile**.
3. Confirm pagination and partial-rendering notices do not claim that Firefox followed another page, scrolled a list, or loaded missing records.
4. Confirm frame content remains outside top-frame Capture while bounded open shadow roots may contribute ordinary text-and-link candidates. Closed shadow content must not be represented as inspected.
5. Confirm a visible overlay or busy region suggests dismissing or waiting and then using **Capture the page again**; ProgRSS must not click the page.
6. Open **Advanced page-boundary evidence** with keyboard and screen reader. Confirm exact counts are announced after the ordinary consequence language and do not become required to understand the decision.
7. Repeat at 320 CSS pixels, 200% and 400% zoom, forced colors, reduced motion, voice control, and switch-style sequential navigation. Confirm no drag gesture is required.
8. Complete the capture and confirm the receipt retains page-boundary kinds, embedded-frame count, and open-shadow-root count while still reporting zero Node site requests and no schedule.

## Capture — rendered watched-page evidence in the native Sidebar

1. Start a loopback Node with a Node-owned library containing one existing watched-page source whose page is accessible only in the signed-in Firefox session.
2. In the Node, choose **Sources → Use signed-in browser**, copy the one-use request, and paste it into the native ProgRSS Sidebar **Add** screen.
3. Confirm no Node, tab, LAN, or page request occurs before the visible review action.
4. Activate **Review browser request**. Confirm Firefox presents any required loopback permission from that action and that the review names the exact Node origin, watched page, request expiry, and current recipe.
5. Open the exact watched page in the active top frame and activate **Capture this open page**. Confirm Firefox presents exact page authority only from that action; a different page, private scheme, background tab, or mismatched origin is refused.
6. Confirm the Sidebar presents at most the saved watched section, repeated entries, and primary readable text, with bounded matched and ignored examples.
7. Confirm every candidate exposes **More likely to stay put**, **Needs watching**, or **Fragile** plus bounded **Why this may hold** and **What could break** evidence. Ask the participant to explain why this is not a guarantee.
8. Choose a candidate that changes the watched section. Confirm **Enable and send this capture once** remains disabled until **Use this new watched section** is checked and that a fresh baseline consequence is explained.
9. Complete the capture. Confirm the receipt says the Node made zero site requests, created no schedule, and retained no cookie, credential, storage, form value, raw HTML, screenshot, script, or browser permission capability.
10. Repeat with Cancel, expiry, Node restart, wrong Extension Origin, exact lost-response retry, and same-idempotency-key different-content reuse. Confirm newly added loopback and page authority is released after cancel, completion, or leaving Add when ProgRSS obtained it.
11. Repeat at 200% and 400% zoom, forced colors, keyboard only, and the available screen reader. Record focus order, browser-owned prompts, status announcements, candidate grouping, acknowledgement state, and any confusion around *browser keeps the login*, *rendered section*, *fresh baseline*, and *zero Node site requests*.

This is an execution protocol. Its inclusion does not establish native Firefox, Firefox ESR, signed-in-site, or assistive-technology acceptance.

## Threshold — coverage decision in the native Sidebar

1. Open a Capture fixture that reports continuation, partial rendering, a visible overlay, and an excluded frame.
2. Confirm the final send action is unavailable before a coverage choice.
3. Explain what **Capture the page again first** does.
4. Explain what **Use this rendered view as the baseline** accepts and what it does not cause ProgRSS to do.
5. When a new watched section is also selected, confirm the two decisions are separate and neither is preselected.
6. Recapture and confirm the earlier coverage choice no longer counts.
7. Complete one capture and find the exact accepted boundary kinds in Advanced receipt evidence.
8. Ask whether the browser login, frame contents, or a recurring schedule moved to the Node.
9. Record keyboard, screen-reader, Braille, voice, switch, zoom, forced-colors, reduced-motion, fatigue, and interruption behavior.
10. Treat confusion as a wording or hierarchy defect, not permission to add hidden scrolling or clicking.

## Drift — partial rendered-window continuity in the native Sidebar

Repeat the browser-assisted Capture flow with two disjoint windows of one virtualized list. Confirm the native Sidebar reports **Rendered window held**, preserves the earlier baseline, exposes overlap evidence under Advanced, creates no mass add/remove item, makes zero Node watched-site requests, and creates no schedule. Repeat with keyboard, screen reader, enlarged text, forced colors, and permission denial/retry.

## Anchor — held-baseline review beside the native Sidebar

1. Use Firefox Capture to produce one Drift **Rendered window held** result. Confirm the Sidebar says the local Node has a separate review and that nothing was replaced during Capture.
2. Restart the Node and confirm the held review persists.
3. In the Node Sources view, open **Understand held windows**, choose **Open Anchor**, and identify **Accepted now** and **Held proposal**.
4. Confirm no browser or watched-site permission prompt appears because the review is offline.
5. Confirm **Replace baseline once** is disabled until its acknowledgement is checked.
6. Commit and confirm zero site requests, zero past alerts, no schedule, a durable receipt, and a downloadable before snapshot.
7. Confirm the native Sidebar pairing remains summary-only and cannot invoke the operation.
8. Repeat the review with keyboard, screen reader, Braille, voice, switch-style navigation, high zoom, forced colors, reduced motion, fatigue, and interruption.
9. Record whether participants interpret the snapshot as evidence or automatic undo and revise wording if needed.

This is an execution protocol, not a claim that native Firefox or human sessions occurred.


## Bearing — read-only held-window diagnosis beside the native Sidebar

1. Pair the Firefox Sidebar to a local Node and confirm pairing remains summary-only.
2. In the Node Sources view, open a watched page with repeated unresolved Drift holds.
3. Confirm **Understand held windows** reports a diagnosis without reading the held snapshots through the Sidebar.
4. Ask whether **Open Anchor** writes immediately. It must not.
5. Ask whether **Begin a fresh Capture** reads the active page immediately. It must only create a short-lived invitation.
6. Confirm the Sidebar receives neither the Node administrator capability nor Bearing history.
7. Complete a new Capture only after the exact watched page is active and the browser-owned permission decision is made.
8. Repeat with keyboard, native Sidebar focus, screen reader, high zoom, forced colors, reduced motion, and one interrupted session.


## Trace — observation-trail comprehension

1. Open a watched page with at least two unresolved held observations.
2. Open Bearing and read the Trace trail without expanding Advanced.
3. Identify the accepted baseline, oldest held observation, and current hold.
4. Explain what `Different window` does and does not prove.
5. Explain what the recipe-footprint label describes.
6. Confirm that opening Trace made no site request and changed no library data.
7. Confirm that exact selectors are available only under Advanced and that the paired Extension receives no repair authority.
8. Repeat with keyboard-only, enlarged text, forced colors, reduced motion, and available assistive technology.

Record whether the participant mistakes the trail for a timeline of confirmed publisher changes, treats the footprint label as a durability guarantee, or believes Open Anchor is an immediate write.

## Fieldbook — native Firefox facilitator sidecar

1. Run the actual Firefox Sidebar and local Node in their native windows.
2. Download the Fieldbook from **Research and acceptance** in the Node review.
3. Open the sheet locally and confirm Firefox makes no remote request for it.
4. Complete the three research-boundary checks and the twelve tasks using the actual Sidebar and Node interface.
5. Confirm that the sheet has no participant identity field, source address, selector, held snapshot, browser credential, or Node capability.
6. Verify keyboard, screen-reader, high-zoom, forced-colors, and reduced-motion behavior in the Fieldbook and product windows.
7. Confirm that incomplete tasks and an unchecked privacy review block report download.
8. Confirm that no pairing authority, Node write, page capture, or schedule is created merely by generating or using the sheet.
9. Record wrong turns as product findings and revise language or hierarchy before adding repair automation.

## Debrief — native Firefox local analysis

1. Use the exact rev0080 Firefox package and local Node.
2. Conduct Fieldbook sessions against the actual Firefox Sidebar separately.
3. Download one blank Debrief from the Node under **Research and acceptance**.
4. Load several compatible reports through Firefox's native file picker.
5. Verify exact duplicates are ignored and a mismatched scenario is refused.
6. Confirm report files remain local to the page and no network request occurs.
7. Review recurring wrong-turn, prompt-dependence, and coverage-gap signals.
8. Confirm raw facilitator notes remain locally visible but are absent from the
   downloaded JSON and Markdown Debriefs.
9. Verify review and privacy gates with keyboard, current screen reader,
   high zoom, forced colors, and reduced motion.
10. Confirm Debrief adds no Firefox permission, paired write authority, Capture
    action, schedule, or Node-library mutation.

Do not represent automated completion or this protocol text as a completed
native Firefox or human study.

## Crossroads — native Firefox recipient fieldwork

1. Use the exact rev0080 Firefox package and an active handoff offering all
   three doors.
2. Open the invitation in the native Sidebar and keep the separate Crossroads
   Fieldbook open for the facilitator.
3. Verify **Follow updates**, **Add the complete route**, and **Take one branch**
   are keyboard reachable and announced with distinct consequences.
4. Run goal-based tasks without naming the expected button.
5. Verify choosing a door opens a later artifact review rather than immediately
   changing the library.
6. Verify review does not contact every listed site and creates no schedule.
7. Verify no new Firefox permission appears solely because the Fieldbook was
   downloaded or used.
8. Verify the Fieldbook contains no invitation secret, curator or route name,
   hostname, URL, folder path, or participant identity field.
9. Repeat with screen reader, high zoom, forced colors, reduced motion, voice
   control, and switch-style sequential navigation where available.
10. Record wrong turns before neutral prompts and review notes for identifying
    information before export.

## Dispatch — native Firefox sender fieldwork

1. Use the exact rev0080 Firefox package and local Node.
2. Prepare an Exchange preview with all three recipient doors available.
3. Keep the real Node share review and separate Dispatch Fieldbook open.
4. Run the `NODE-DISPATCH-ACCEPTANCE.md` goals without naming the expected
   answer or control.
5. Repeat under native Sidebar focus, keyboard operation, enlarged text,
   forced colors, reduced motion, and available screen-reader conditions.
6. Verify that downloading the Fieldbook creates no handoff, publication,
   listed-site request, schedule, pairing, or Node-library write.
7. Complete the privacy review before exporting the local report.
