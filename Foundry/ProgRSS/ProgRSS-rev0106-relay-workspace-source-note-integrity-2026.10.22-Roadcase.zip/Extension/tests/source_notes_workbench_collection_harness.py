#!/usr/bin/env python3
"""Managed Workbench replay for placement-scoped Source Note preservation.

This loads the shipped Workbench HTML and scripts, replaces only the browser
persistence backend with a deterministic in-page vault, and drives the actual
collection editor. It is not installed-browser or participant evidence.
"""
from __future__ import annotations

import argparse
import asyncio
import importlib.util
import json
import os
from pathlib import Path
import shutil
import tempfile
from typing import Any

from bs4 import BeautifulSoup
from playwright.async_api import async_playwright, Page

TESTS = Path(__file__).resolve().parent
BASE_EXTENSION = TESTS.parent

spec = importlib.util.spec_from_file_location("progrss_browser_smoke", TESTS / "browser_smoke.py")
if spec is None or spec.loader is None:
    raise RuntimeError("Could not load browser smoke support")
smoke = importlib.util.module_from_spec(spec)
spec.loader.exec_module(smoke)


def html_without_scripts(path: Path) -> tuple[str, list[Path]]:
    soup = BeautifulSoup(path.read_text(), "html.parser")
    scripts: list[Path] = []
    for tag in list(soup.find_all("script", src=True)):
        scripts.append((path.parent / tag["src"]).resolve())
        tag.decompose()
    return str(soup), scripts


def blank_state() -> dict[str, Any]:
    return {
        "_revision": 74,
        "version": 17,
        "sources": [
            {"id": "feed-one", "title": "One", "type": "rss", "url": "https://one.test/feed.xml", "enabled": True, "archivedAt": "", "version": 1, "author": "local"},
            {"id": "feed-two", "title": "Two", "type": "rss", "url": "https://two.test/feed.xml", "enabled": True, "archivedAt": "", "version": 1, "author": "local"},
            {"id": "feed-three", "title": "Three", "type": "rss", "url": "https://three.test/feed.xml", "enabled": True, "archivedAt": "", "version": 1, "author": "local"},
            {"id": "feed-four", "title": "Four", "type": "rss", "url": "https://four.test/feed.xml", "enabled": True, "archivedAt": "", "version": 1, "author": "local"},
        ],
        "collections": [
            {
                "id": "folder-reading",
                "title": "Reading",
                "mode": "union",
                "include": "",
                "exclude": "",
                "author": "local",
                "version": 7,
                "members": [
                    {"kind": "source", "id": "feed-one", "reason": "First placement reason."},
                    {"kind": "source", "id": "feed-two", "reason": "Second placement reason."},
                    {"kind": "collection", "id": "folder-child"},
                ],
            },
            {
                "id": "folder-child",
                "title": "Child",
                "mode": "union",
                "include": "",
                "exclude": "",
                "author": "local",
                "version": 3,
                "members": [
                    {"kind": "source", "id": "feed-three", "reason": "Independent child reason."}
                ],
            },
        ],
        "items": [],
        "snapshots": {},
        "fixtures": [],
        "inbox": [],
        "receipts": [],
        "retiredReceipts": [],
        "subscriptions": [],
        "publications": [],
        "patchPins": [],
        "keyRotations": [],
        "recoveryPolicies": [],
        "recoveryReceipts": [],
        "charterHistory": [],
        "charterClaims": [],
        "gossipCards": [],
        "witnessPins": [],
        "merklePins": [],
        "merkleReceipts": [],
        "proofRequests": [],
        "proofSightings": [],
        "proofForks": [],
        "fixturePacks": [],
        "transferUndo": None,
        "sourceRepairUndo": None,
        "receiptRetirementUndo": None,
        "sharedFolderUpdateUndo": None,
        "pageWatchRepairUndo": None,
    }


def collection(state: dict[str, Any], collection_id: str = "folder-reading") -> dict[str, Any]:
    return next(row for row in state["collections"] if row["id"] == collection_id)


def placement_map(row: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for member in row["members"]:
        if member["kind"] == "source":
            result[member["id"]] = member.get("reason", None)
    return result


async def load_workbench(browser, root: Path, seed: dict[str, Any]) -> tuple[Page, list[str]]:
    page = await browser.new_page(viewport={"width": 900, "height": 900}, device_scale_factor=1)
    errors: list[str] = []
    page.on("console", lambda msg: errors.append(f"console:{msg.type}:{msg.text}") if msg.type == "error" else None)
    page.on("pageerror", lambda error: errors.append(f"page:{error}"))
    html, scripts = html_without_scripts(root / "workbench" / "index.html")
    await page.set_content(html, wait_until="domcontentloaded")
    await page.add_script_tag(content=smoke.MOCK)
    for script in scripts:
        if script.name == "vault.js":
            fake = f"""(() => {{
              let stored={json.dumps(seed, ensure_ascii=False)};
              globalThis.__workbenchSavedState=null;
              globalThis.__workbenchSaveCalls=0;
              globalThis.__workbenchCurrentState=()=>structuredClone(stored);
              globalThis.ProgRSSVault=Object.freeze({{
                init:async()=>structuredClone(stored),
                save:async state=>{{
                  state._revision=(Number(state._revision)||0)+1;
                  stored=structuredClone(state);
                  globalThis.__workbenchSavedState=structuredClone(state);
                  globalThis.__workbenchSaveCalls+=1;
                }},
                probe:async()=>true,
                info:()=>({{mode:'indexeddb',warning:''}}),
                normalize:value=>structuredClone(value)
              }});
            }})();"""
            await page.add_script_tag(content=fake)
        else:
            await page.add_script_tag(content=script.read_text())
    await page.wait_for_function("!document.querySelector('#shell').inert")
    await page.locator('nav button[data-view="collections"]').click()
    return page, errors


async def open_reading(page: Page) -> None:
    row = page.locator("#collection-list .row-card").filter(has_text="Reading").first
    await row.locator("button", has_text="Edit").click()
    await page.wait_for_selector("#collection-dialog[open]")


async def submit_success(page: Page) -> dict[str, Any]:
    await page.locator('#collection-form button[type="submit"]').click()
    await page.wait_for_function("globalThis.__workbenchSaveCalls === 1")
    return await page.evaluate("globalThis.__workbenchSavedState")


async def submit_refusal(page: Page) -> str:
    await page.locator('#collection-form button[type="submit"]').click()
    await page.wait_for_function("!document.querySelector('#toast').hidden")
    assert await page.evaluate("globalThis.__workbenchSaveCalls") == 0
    return await page.locator("#toast").inner_text()


async def run_variant(browser, root: Path, artifacts: Path) -> dict[str, Any]:
    passed: list[str] = []

    async def fresh(seed: dict[str, Any] | None = None) -> tuple[Page, list[str]]:
        return await load_workbench(browser, root, seed or blank_state())

    # 1. A title-only edit used to erase every reason in the edited collection.
    page, errors = await fresh()
    await open_reading(page)
    await page.locator("#collection-name").fill("Reading revised")
    saved = await submit_success(page)
    assert placement_map(collection(saved)) == {"feed-one": "First placement reason.", "feed-two": "Second placement reason."}
    assert placement_map(collection(saved, "folder-child")) == {"feed-three": "Independent child reason."}
    assert not await page.evaluate("globalThis.__nodeFetchRequests.length")
    assert not errors, errors
    await page.screenshot(path=str(artifacts / f"{root.name}-workbench-preserved-reasons.png"), full_page=True)
    await page.close(); passed.append("title-only edit preserves selected placement reasons and independent folders")

    # 2. Mode/base reordering must carry reasons with source identity, not index.
    page, errors = await fresh()
    await open_reading(page)
    await page.locator("#collection-mode").select_option("subtract")
    await page.locator("#collection-base").select_option("source:feed-two")
    saved = await submit_success(page)
    row = collection(saved)
    assert [(m["kind"], m["id"], m.get("reason")) for m in row["members"]] == [
        ("source", "feed-two", "Second placement reason."),
        ("source", "feed-one", "First placement reason."),
        ("collection", "folder-child", None),
    ]
    assert not errors, errors
    await page.close(); passed.append("subtract-base reorder keeps reasons attached to source identity")

    # 3. Removing a placement removes only that placement/reason; other reasons survive.
    page, errors = await fresh()
    await open_reading(page)
    await page.locator('#collection-members input[value="source:feed-one"]').uncheck()
    saved = await submit_success(page)
    assert placement_map(collection(saved)) == {"feed-two": "Second placement reason."}
    assert placement_map(collection(saved, "folder-child")) == {"feed-three": "Independent child reason."}
    assert not errors, errors
    await page.close(); passed.append("deliberate placement removal does not erase surviving or other-folder reasons")

    # 4. A newly selected source starts without an invented reason.
    page, errors = await fresh()
    await open_reading(page)
    await page.locator('#collection-members input[value="source:feed-four"]').check()
    saved = await submit_success(page)
    members = {m["id"]: m for m in collection(saved)["members"] if m["kind"] == "source"}
    assert members["feed-one"]["reason"] == "First placement reason."
    assert members["feed-two"]["reason"] == "Second placement reason."
    assert "reason" not in members["feed-four"]
    assert not errors, errors
    await page.close(); passed.append("new placement receives no automatic reason")

    # 5. Identical duplicate placements canonicalize to one while preserving the reason.
    seed = blank_state(); row = collection(seed)
    row["members"].insert(1, {"kind": "source", "id": "feed-one", "reason": "First placement reason."})
    page, errors = await fresh(seed)
    await open_reading(page)
    await page.locator("#collection-name").fill("Reading canonicalized")
    saved = await submit_success(page)
    matches = [m for m in collection(saved)["members"] if m["kind"] == "source" and m["id"] == "feed-one"]
    assert matches == [{"kind": "source", "id": "feed-one", "reason": "First placement reason."}]
    assert not errors, errors
    await page.close(); passed.append("identical duplicate placement canonicalizes without reason loss")

    # 6. Divergent duplicates are refused rather than choosing a reason by order.
    for label, duplicate in [
        ("different reasons", {"kind": "source", "id": "feed-one", "reason": "Conflicting wording."}),
        ("absence versus reason", {"kind": "source", "id": "feed-one"}),
    ]:
        seed = blank_state(); collection(seed)["members"].insert(1, duplicate)
        page, errors = await fresh(seed)
        await open_reading(page)
        await page.locator("#collection-name").fill("Should not save")
        toast = await submit_refusal(page)
        assert "Conflicting Source Notes" in toast, toast
        current = await page.evaluate("globalThis.__workbenchCurrentState()")
        assert collection(current)["title"] == "Reading"
        assert not errors, errors
        await page.close(); passed.append(f"{label} conflict refuses without mutation")

    # 7. Invalid old note data cannot be silently dropped to make an edit succeed.
    seed = blank_state(); collection(seed)["members"][0]["reason"] = "x" * 281
    page, errors = await fresh(seed)
    await open_reading(page)
    await page.locator("#collection-name").fill("Should not save")
    toast = await submit_refusal(page)
    assert "280 Unicode code points" in toast, toast
    assert not errors, errors
    await page.close(); passed.append("invalid over-limit prior reason refuses without mutation")

    # 8. A reason on a nested-collection member is invalid and cannot be normalized away.
    seed = blank_state(); collection(seed)["members"][-1]["reason"] = "Wrong level."
    page, errors = await fresh(seed)
    await open_reading(page)
    toast = await submit_refusal(page)
    assert "Only a direct source placement" in toast, toast
    assert not errors, errors
    await page.close(); passed.append("wrong-level reason refuses without mutation")

    # 9. Empty ASCII-edge-only reasons remain canonical absence.
    seed = blank_state(); collection(seed)["members"][0]["reason"] = " \t\r\n "
    page, errors = await fresh(seed)
    await open_reading(page)
    saved = await submit_success(page)
    member = next(m for m in collection(saved)["members"] if m["kind"] == "source" and m["id"] == "feed-one")
    assert "reason" not in member
    assert not errors, errors
    await page.close(); passed.append("empty reason canonicalizes to absence")

    # 10. Unicode and multiline wording survive byte-for-byte after canonical edge trim.
    seed = blank_state(); expected = "Why this route:\n🌱 community reporting"
    collection(seed)["members"][0]["reason"] = expected
    page, errors = await fresh(seed)
    await open_reading(page)
    await page.locator("#collection-include").fill("community")
    saved = await submit_success(page)
    member = next(m for m in collection(saved)["members"] if m["kind"] == "source" and m["id"] == "feed-one")
    assert member["reason"] == expected
    assert not errors, errors
    await page.close(); passed.append("Unicode multiline reason survives collection edit")

    return {"variant": str(root), "passed": passed, "count": len(passed)}


async def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(os.environ.get("PROGRSS_EXTENSION_ROOT", BASE_EXTENSION)))
    parser.add_argument("--artifacts", type=Path, default=Path(os.environ.get("PROGRSS_TEST_ARTIFACTS", tempfile.gettempdir())) / "progrss-workbench-source-notes")
    args = parser.parse_args()
    root = args.root.resolve(); args.artifacts.mkdir(parents=True, exist_ok=True)
    if not (root / "workbench" / "scripts" / "progrss-app.js").is_file():
        raise SystemExit(f"Missing Workbench under {root}")
    async with async_playwright() as p:
        executable = os.environ.get("PROGRSS_CHROMIUM") or shutil.which("chromium") or shutil.which("chromium-browser") or shutil.which("google-chrome")
        launch: dict[str, Any] = {"headless": True, "args": ["--no-sandbox"]}
        if executable:
            launch["executable_path"] = executable
        browser = await p.chromium.launch(**launch)
        try:
            result = await run_variant(browser, root, args.artifacts)
        finally:
            await browser.close()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    print(f"PASS Workbench Source Notes collection preservation: {result['count']} cases")
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
