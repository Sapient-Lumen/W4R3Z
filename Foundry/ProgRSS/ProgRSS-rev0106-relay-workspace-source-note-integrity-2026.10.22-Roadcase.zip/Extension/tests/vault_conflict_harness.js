'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const ROOT = path.resolve(__dirname, '..');
const code = fs.readFileSync(path.join(ROOT, 'shared', 'vault.js'), 'utf8');
const map = new Map();
let failWrites=false;
const sharedStorage = {
  getItem(key){ return map.has(key) ? map.get(key) : null; },
  setItem(key,value){
    if(failWrites){const error=Error('quota exceeded while writing');error.name='QuotaExceededError';throw error;}
    map.set(key,String(value));
  },
  removeItem(key){ map.delete(key); }
};
function makeVault(){
  const context = vm.createContext({console, Promise, Error, JSON, Array, Object, String, Number, Boolean, Map, Set, Date, Math, localStorage: sharedStorage});
  context.globalThis = context;
  vm.runInContext(code, context, {filename: 'vault.js'});
  return context.ProgRSSVault;
}
(async()=>{
  const A=makeVault(),B=makeVault();
  const migrated=A.normalize({version:16,sources:[{id:'language-source',title:'لغة',type:'rss',url:'https://language.test/feed',enabled:true,language:'AR',titleLanguage:'not valid!',textRetention:'SUMMARY'},{id:'full-source',title:'Full',type:'rss',url:'https://full.test/feed',enabled:true,textRetention:'invalid'},{id:'page-source',title:'Hours',type:'page',url:'https://page.test/hours',enabled:true}],collections:[],items:[{id:'language-source|one',sourceId:'language-source',title:'שלום',language:'HE',titleLanguage:'HE',summaryLanguage:'bad tag!',bodyLanguage:'AR',body:'Excerpt',bodyIsSummary:true,bodyOmitted:true},{id:'full-source|one',sourceId:'full-source',title:'Full',body:'Text',bodyIsSummary:false,bodyOmitted:false},{id:'page-change',sourceId:'page-source',title:'Hours changed',change:{schema:'progrss.page-change.v1',kind:'text-changed',mode:'region',summary:' Changed Monday to Tuesday ',before:'Library opens Monday',after:'Library opens Tuesday',removed:'Monday',added:'Tuesday',removedWords:1,addedWords:1,delta:7,threshold:3,ignoreNumbers:false,extra:'drop me'}},{id:'bad-page-change',sourceId:'page-source',title:'Legacy',change:{schema:'progrss.page-change.v1',kind:'unknown',mode:'region'}}]});
  assert.strictEqual(migrated.version,17);
  assert.strictEqual(migrated.sources[0].language,'ar');
  assert.strictEqual(migrated.sources[0].textRetention,'summary');
  assert.ok(!Object.hasOwn(migrated.sources[0],'titleLanguage'));
  assert.ok(!Object.hasOwn(migrated.sources[1],'textRetention'));
  assert.strictEqual(migrated.items[0].titleLanguage,'he');
  assert.ok(!Object.hasOwn(migrated.items[0],'summaryLanguage'));
  assert.strictEqual(migrated.items[0].bodyLanguage,'ar');
  assert.strictEqual(migrated.items[0].bodyOmitted,true);
  assert.ok(!Object.hasOwn(migrated.items[1],'bodyOmitted'));
  assert.strictEqual(migrated.items[2].change.summary,'Changed Monday to Tuesday');
  assert.strictEqual(migrated.items[2].change.before,'Library opens Monday');
  assert.ok(!Object.hasOwn(migrated.items[2].change,'extra'));
  assert.ok(!Object.hasOwn(migrated.items[3],'change'));
  const a=await A.init(),b=await B.init();
  assert.strictEqual(a._revision,0);assert.strictEqual(b._revision,0);
  a.sources.push({id:'a',title:'A',type:'rss',url:'https://a.test/feed',enabled:true});
  await A.save(a);assert.strictEqual(a._revision,1);
  b.sources.push({id:'b',title:'B',type:'rss',url:'https://b.test/feed',enabled:true});
  await assert.rejects(B.save(b), error=>error && error.code==='STALE_VAULT');
  assert.match(B.info().warning,/another open view/i);
  const fresh=await B.init();assert.strictEqual(fresh._revision,1);assert.strictEqual(fresh.sources.length,1);
  assert.doesNotMatch(B.info().warning,/another open view/i);
  fresh.sources.push({id:'b',title:'B',type:'rss',url:'https://b.test/feed',enabled:true});
  await B.save(fresh);assert.strictEqual(fresh._revision,2);
  const final=await A.init();assert.deepStrictEqual(final.sources.map(x=>x.id),['a','b']);
  failWrites=true;
  final.sources.push({id:'c',title:'C',type:'rss',url:'https://c.test/feed',enabled:true});
  await assert.rejects(A.save(final),error=>error&&error.code==='VAULT_WRITE_FAILED'&&error.storageReason==='quota');
  assert.strictEqual(final._revision,2,'failed write does not advance the local revision');
  const afterFailure=await B.init();assert.deepStrictEqual(afterFailure.sources.map(x=>x.id),['a','b'],'failed write leaves the committed library unchanged');
  failWrites=false;
  assert.strictEqual(await A.probe(),true,'small write probe succeeds after storage is available again');
  console.log('PASS vault conflict harness: vault 16 → 17 offline-text and bounded page-change records migrate safely; stale view refused; failed quota write preserves the committed library; probe recovers');
})().catch(error=>{console.error(error.stack||error);process.exitCode=1;});
