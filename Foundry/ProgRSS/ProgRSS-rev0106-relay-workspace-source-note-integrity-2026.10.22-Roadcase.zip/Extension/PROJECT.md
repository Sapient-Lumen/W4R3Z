## rev0080 — Roadcase

Roadcase changes no Extension runtime authority. It packages the exact Chromium and generated Firefox trees inside a self-verifying fieldwork packet so native sessions can use known bytes and a fresh profile.
**Know what leaves before you send the link.**

Dispatch changes no Extension runtime authority. It adds a private sender-side
research sheet to the local Node's existing pre-send Exchange review. The
Extension remains the actual three-door recipient product under the separate
Crossroads scenario:

```text
Follow updates
Add the complete route
Take one branch
```

The sender Fieldbook receives no browser credential, Extension capability,
recipient library, route identity, source address, folder path, public URL,
library digest, artifact digest, preview capability, or participant identity.
Downloading it does not publish, upload, follow, import, pair, schedule, or
contact a listed site.

Dark fluorescent presentation remains the default, light mode remains
available, and Advanced Workbench remains secondary. Native Chromium, Firefox,
Firefox ESR, unfamiliar-sender, unfamiliar-recipient, and real assistive-
technology sessions remain outstanding.
