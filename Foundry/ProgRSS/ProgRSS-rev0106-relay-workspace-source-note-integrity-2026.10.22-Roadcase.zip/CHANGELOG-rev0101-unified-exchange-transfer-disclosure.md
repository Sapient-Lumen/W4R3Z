# Changelog — rev0101-unified-exchange-transfer-disclosure

- Integrated the delivered rev0099 private-transfer Source Notes integrity delta through its rev0098 merge base.
- Added fail-closed private-library validation before preview, restore, copy checking, Undo, and export.
- Added exact Source Note counts to private transfer review and CLI audit output.
- Corrected Node Exchange sender review to disclose exact route-bound Source Notes.
- Corrected Extension Exchange recipient review and branch choices to disclose exact counts and reasons.
- Added literal multiline, direction-aware rendering, curator attribution, and explicit non-safety wording.
- Added focused CLI, Node-rendering, Extension-rendering, Chromium, and generated-Firefox regressions.
- Kept the runtime acceptance catalog at 18 cases and advanced its binding to rev0101.
- Added no browser permission, persistent store, network authority, account, schedule, notification, ranking, profile, reaction, comment, or message feature.
