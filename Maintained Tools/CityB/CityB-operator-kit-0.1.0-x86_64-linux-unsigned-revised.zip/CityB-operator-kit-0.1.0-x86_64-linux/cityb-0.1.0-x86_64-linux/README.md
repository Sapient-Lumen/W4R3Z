# CityB standalone

This repository contains the three CityB binary surfaces and the Rust crates
they currently require:

- `cityb-node`: dependency-tiny verification node with bounded encrypted correspondence replies and node-originated status/fault/notice/capability messages.
- `cityb`: Goldilocks operator workbench.
- `cityb-biggun`: heavy exercise, measurement, adversarial proof, and development truth tool.

The export is intentionally still a Cargo workspace because the CityB binaries
share core protocol, audit, transport, council, operator, and lab code. Treat
`docs/city-b-current-state.md` as the current-state briefing. Treat
`docs/city-b-next-campaign.md` as the current executable roadmap. Treat
`docs/city-b-operator-workflow.md`,
`docs/city-b-operator-distribution.md`,
`docs/city-b-free-service-taxonomy.md`,
`docs/city-b-biggun-truth.md`,
`docs/city-b-maintainer-playbook.md`,
`docs/city-b-rendezvous-roadmap.md`,
`docs/city-b-provider-expansion-plan.md`, and `docs/city-b-plan.md` as the
main roadmap and operating notes.

## Vaulted CityB-of-ChatGPT artifact

The completed one-file no-Nix/ChatGPT carrier is no longer an active CityB
product or flake output. Its exact 2026-10-25 artifact, studies, private positive
fixtures, field-trial material, proposal note, and test-run receipts are held
together under [`vault/cityb-of-chatgpt/`](vault/cityb-of-chatgpt/README.md).
The vault is excluded from the Rust build source and is retained for custody,
inspection, and deliberate revival only. Active development is again centered
on the three CityB binaries. Stil remains m21's separately named personal
office and is not part of the public CityB runtime.

Operator/node messaging is a separate correspondence plane with named-node and isolated group send, verified inbox/read/reply/thread workflows on Goldilocks, verified inbox/reply on Tiny, bounded status/fault capsules, acknowledged key cutover, authenticated HTTP exchange, and optional live relay sidecars. See
[`docs/city-b-correspondence.md`](docs/city-b-correspondence.md) for the
canonical signed+HPKE envelope, enrollment/fleet registry, two-node spool
proof, per-node gateway bearer, Tiny replies and originated reports, live
ntfy/MQTT/Nostr bridge sidecars, privacy-minimized relay evidence, and Biggun
attack/study campaigns. Provision changes now use a staged candidate, old-node
acknowledgement, operator commit, new-key activation receipt, and recoverable
finalization instead of pretending an offline field copy rotated. The operator
also has separately encrypted group fan-out, typed delivery evidence, typed advisory tasks and bound results, digest-only public artifact requests, bounded
compaction, two-family relay soaking, evidence-derived route objectives, a capped body-free incident inbox wired into the cockpit, provision-bound Goldilocks/Tiny offline courier files with one shared QR-ready text codec, and an authenticated rate-limited gateway. The gateway's separately opt-in external-operator route applies a fixed read/correspond/operate vocabulary, short signed request lifetimes, and replay retention without evaluating shell strings. Signed public office kits contain only public fleet facts and optional credential-free relay plans; imported nodes are explicitly remote-only;
Tiny has budgeted jittered status/fault capsules and explicit public-artifact manifests that retain no source paths. Biggun's correspondence campaign now adds a 256-reply concurrency storm, malformed typed-body refusal, artifact vocabulary checks, and courier tamper refusal. Stil, the NixOS operations object,
includes opt-in node-capsule and relay-soak timers plus a loopback gateway behind
an nginx TLS fixture. The cockpit includes dry-run-first deduplicated fleet
check-ins, open-cutover attention, and a fail-closed durable-state doctor.
Correspondence authenticates communication; it never mints council authority.

The joined operator contract for readiness, current-generation reconciliation,
adaptive archive capacity, topology truth, one-command long-amnesia recovery,
binary identity, and Stil automation is
`docs/city-b-readiness-reconciliation-and-recovery.md`.

Documentation audit status as of November 4, 2026: the README, current-state
briefing, operator workflow, rendezvous roadmap, provider docs, fixture READMEs,
and standalone/release docs describe the current binaries and checked-in
fixtures. The frontier, speculation, dream, long-form plan, and governance
spec documents intentionally retain design history and future options; a claim
from those ledgers is current implementation only when it is repeated in this
README, `docs/city-b-current-state.md`, command help, or an executable fixture
gate.

## Quick proof

```sh
nix flake show
nix fmt -- --check flake.nix nix/cityb-module.nix nix/examples/*.nix
nix flake check
nix build .#cityb .#cityb-portable
nix run .#cityb -- capabilities
nix run .#cityb-node -- capabilities
nix run .#cityb-biggun -- capabilities
nix run .#cityb -- version --json
nix run .#cityb-node -- version --json
nix run .#cityb-biggun -- version --json

nix develop -c cargo build --bin cityb-node --bin cityb --bin cityb-biggun

nix run .#cityb -- release archive --plan --json
nix run .#cityb -- release archive --plan --signature-policy require-present --json
nix run .#cityb -- release ceremony --json
nix run .#cityb -- release sign RELEASE_DIR/SHA3SUMS --signing-key RELEASE_SIGNING_KEY --apply --json
nix run .#cityb -- release verify DIR_OR_TAR_GZ --json
nix run .#cityb -- release verify DIR_OR_TAR_GZ --signature-policy require-verified --signature-verifier ssh --allowed-signers ALLOWED_SIGNERS --signer-identity ID --json
nix run .#cityb -- release trust init --root ./city-b-artifacts --json
nix run .#cityb -- release trust status --root ./city-b-artifacts --json
nix run .#cityb -- reconcile --root ./city-b-artifacts --deployment ./city-b.toml --service-set free-stable --json
nix run .#cityb -- recover --root ./city-b-artifacts --deployment ./city-b.toml --anchor-source ANCHOR_FILE_OR_URL --json
nix run .#cityb -- dead-drop archive capacity-soak --root ./city-b-artifacts --service-set free-stable --json
nix run .#cityb-biggun -- footprint --json
nix run .#cityb-biggun -- gate --plan --json
nix run .#cityb-biggun -- selftest --plan --json
nix run .#cityb-biggun -- selftest --quick --plan --json
nix develop -c ./scripts/smoke-cityb-three-binaries.sh
```

`nix run .#cityb -- ...` builds and runs the packaged binary. `nix develop`
creates a Rust development shell; it does not place freshly built workspace
binaries on `PATH`, so use `cargo run --bin NAME -- ...` inside it or call
`./target/debug/NAME` after building. Without Nix, use the Rust toolchain named
in `rust-toolchain.toml` and run the same `cargo build` / smoke commands
directly.

## Published flake contract

The reviewed public entry points are deliberately small:

- `packages.<system>.default`, `cityb`, and `cityb-suite` install the same
  closure containing `cityb`, `cityb-node`, and `cityb-biggun`;
- `packages.<system>.cityb-portable` provides the three statically linked
  binaries for compatible non-Nix Linux hosts;
- `apps.<system>.default`, `cityb`, `cityb-node`, and `cityb-biggun` run the
  three roles directly;
- `nixosModules.default` and `nixosModules.cityb` are the opt-in public NixOS
  automation module;
- `formatter.<system>` and `checks.<system>.publication` provide the source and
  artifact release gates.

The source repository retains explicitly named `stil` and `stil-foundation`
compatibility outputs for m21. They are not defaults, are not installed by the
CityB module, and are not part of the portable CityB release archive. Every
distributed source and release archive is licensed under the included
[`LICENSE`](LICENSE).

“Portable” describes the ELF/libc boundary, not a hermetic operating system.
Core local verification and identity commands need no Nix installation, but
operator workflows that explicitly call Git, OpenSSH, age, DNS tools, or HTTP
clients still require those programs on the destination host. The normal Nix
package wraps the reviewed tool closure onto `PATH`; the static package reports
a missing host tool instead of pretending it was embedded.

Changes follow [`CONTRIBUTING.md`](CONTRIBUTING.md). Report suspected security
failures through the private process in [`SECURITY.md`](SECURITY.md), especially
archive-admission, signature, replay, generation, secret-handling, or unintended
provider-mutation failures.

CityB is the product and the normal operator namespace. The flake's default
package and app expose the three CityB binaries; its default NixOS module is
`nixosModules.default` (also named `nixosModules.cityb`) and is configured under
`services.cityb`. The module installs no fourth runtime role. It writes a
credential-free `/etc/cityb/runtime.json`; interactive `cityb next`, `check`,
`brief`, `doctor`, and `operator card` use those declared paths when
`CITYB_RUNTIME_CONFIG` is present, while explicit CLI flags always win. Its
opt-in services are named `cityb-*`, execute the exact package binaries, and
keep public-provider mutation disabled unless `monitor.live = true`. See
[`docs/city-b-nix.md`](docs/city-b-nix.md).

`cityb system` is the public lifecycle bridge for that descriptor. It exposes
status, timers, configuration, bounded logs, an identity-gating doctor, and
explicit run/stop/restart operations over declared role names such as
`monitor`, `truth`, or `gateway`. It never accepts an arbitrary systemd unit or
shell command. The descriptor selects the exact service, timer, and executable;
systemd and the module's optional named-operator Polkit rule retain mutation
authority.

Stil is m21's personal CityB office, not CityB's public name or default module.
It remains a one-file Nix object because m21 benefits from its resident payload
profile, typed action ceremony, collision detection, and Monsternix handoff.
Nothing in CityB requires another operator to install or understand Stil. The
personal contract and recovery machinery remain documented in
[`docs/stil.md`](docs/stil.md).

Portable Stil remains pinned wholly by its enclosing NixOS generation. A
frequently updated operator laptop can opt into the same one-file object's
resident payload profile: the host generation continues to own systemd,
hardening, paths, timers, and a narrow root helper, while `stil`, `cityb`,
`cityb-biggun`, and `cityb-node` advance together through one receipt-bearing
Nix profile. `stil generation plan --source FLAKE --check` builds and validates
without mutation; `activate --candidate STORE --expect ACTION_ID` changes only
that profile; `rollback --expect CURRENT_OBJECT_SHA256` restores its receipt-
bound predecessor. This is an opt-in development-host convenience, not a new
binary or a substitute for a host switch when the resident contract changes.

For a Monsternix machine, [`stil-foundation.nix`](stil-foundation.nix) is a
separate fifth publication object—not a fourth runtime role. It emits exact
`recovery-escrow` entries and, after the operator supplies current authority
facts, strict complete catalog/observation documents for encrypted Stil
operator-continuity artifacts. One descriptor-bound inspection supplies their
SHA-256 custody identity, SHA3-256 CityB identity, and length. `stil foundation
doctor --deep` distinguishes an inert compiler from available and contract-valid
`mnx.sync`, `mnx.secrets`, IoTox, and unobserved physical-route state, while
`stil foundation custody-plan` emits a durable, restart-safe request/IoTox/
admission/materialization ceremony without running it. `stil foundation
admission` names the exact source, maturity,
proof, ownership, ejection, machine-adapter, test, and switch obligations. Byte
custody remains distinct from decryptability, restoration, current
authority, and activation. The sovereign artifact mode uses a fixed, bounded
Argon2id policy and private password descriptors; it requires the encrypted
artifact and therefore does not claim credential-only network account recovery. See
[`docs/stil-foundation.md`](docs/stil-foundation.md).

Operator JSON distinguishes a command that executed from a deployment that is
actually ready. `next`, `check`, `doctor`, `operator card`, provider health,
rendezvous, and monitor status/nurse all expose `execution_success`,
`operational_ready`, `operational_state`, one `primary_action_detail`, and an
ordered `action_chain`. On readiness-bearing reports, `success` now follows
`operational_ready`; `execution_success` separately says that inspection ran.
`cityb check` enforces readiness by default (`--allow-attention` is the explicit
inspection-only escape hatch), while `next`, `doctor`, and the operator card
offer `--require-ready` for shell automation. Those surfaces share retained-root
discovery and the same archive-capacity facts. The complete contract and guided recovery ceremonies are documented in
[city-b-readiness-reconciliation-and-recovery.md](docs/city-b-readiness-reconciliation-and-recovery.md).

## First useful commands

```sh
cargo run --bin cityb-node -- capabilities
cargo run --bin cityb -- capabilities
cargo run --bin cityb-biggun -- capabilities
cargo run --bin cityb-node -- version --json
cargo run --bin cityb -- version --json
cargo run --bin cityb-biggun -- version --json

cargo run --bin cityb -- doctor --json
cargo run --bin cityb -- install --json
cargo run --bin cityb -- operator card --root ./city-b-artifacts --deployment ./city-b.toml --json
cargo run --bin cityb -- operator card --root ./city-b-artifacts --deployment ./city-b.toml --verbose --json
cargo run --bin cityb -- storage status --root ./city-b-artifacts --json
cargo run --bin cityb -- storage plan --root ./city-b-artifacts --json
cargo run --bin cityb -- disaster-recovery inventory --root ./city-b-artifacts --json
cargo run --bin cityb -- disaster-recovery inspect --in ./cityb-operator-recovery.stil --json
nix run .#stil-foundation -- manifest
cargo run --bin cityb -- up --root ./city-b-artifacts --deployment ./city-b.toml --json
cargo run --bin cityb -- check --root ./city-b-artifacts --deployment ./city-b.toml --json
cargo run --bin cityb -- next --root ./city-b-artifacts --deployment ./city-b.toml --json
cargo run --bin cityb -- reconcile --root ./city-b-artifacts --deployment ./city-b.toml --service-set free-stable --json
cargo run --bin cityb -- recover --root ./city-b-artifacts --deployment ./city-b.toml --anchor-source ANCHOR_FILE_OR_URL --json
cargo run --bin cityb -- recovery-card --root ./city-b-artifacts --deployment ./city-b.toml --out ./city-b-recovery-card.svg --force --json
cargo run --bin cityb -- field-pack status --root ./city-b-artifacts --deployment ./city-b.toml --json
cargo run --bin cityb -- service ls --service-set free-stable --json
cargo run --bin cityb -- provider summary --json
cargo run --bin cityb -- provider catalog --class filehost --json
cargo run --bin cityb -- provider candidates list --json
cargo run --bin cityb -- provider candidates plan --json
cargo run --bin cityb -- provider candidates capture --provider gofile --json
cargo run --bin cityb -- provider candidates promote --provider gofile --lane research --json
cargo run --bin cityb -- provider health --service-set free-stable --json
cargo run --bin cityb -- provider archive-roles --service-set free-stable --root ./city-b-artifacts --json
cargo run --bin cityb -- provider archive-roles --service-set free-stable --root ./city-b-artifacts --apply --json
cargo run --bin cityb -- provider promotion-board --service-set free-deep-web2-10 --run-checks --live-topology --json
cargo run --bin cityb -- provider dossier litterbox --service-set all --run-checks --json
cargo run --bin cityb -- provider explain nullpaste --service-set free-wide --json
cargo run --bin cityb -- provider health --service-set free-wide --json
cargo run --bin cityb -- repair queue --root ./city-b-artifacts --deployment ./city-b.toml --json
cargo run --bin cityb -- post due --root ./city-b-artifacts --deployment ./city-b.toml --json
cargo run --bin cityb -- post due --root ./city-b-artifacts --deployment ./city-b.toml --apply --max-events 8 --json
cargo run --bin cityb -- explain event --root ./city-b-artifacts --event EVENT_HEX --json
cargo run --bin cityb -- explain service catbox --root ./city-b-artifacts --deployment ./city-b.toml --json
cargo run --bin cityb -- export field-pack --root ./city-b-artifacts --out ./field-pack --force --json

cargo run --bin cityb -- run --root ./city-b-artifacts --json
cargo run --bin cityb -- deployment init --out ./city-b.toml --service-set free-stable
cargo run --bin cityb -- deployment init --out ./city-b-wide.toml --service-set free-wide
cargo run --bin cityb -- deployment init --out ./city-b-deep-10.toml --service-set free-deep-10
cargo run --bin cityb -- deployment init --out ./city-b-deep-text-10.toml --service-set free-deep-text-10
cargo run --bin cityb -- deployment init --out ./city-b-deep-web-10.toml --service-set free-deep-web-10
cargo run --bin cityb -- deployment init --out ./city-b-deep-web2-10.toml --service-set free-deep-web2-10
cargo run --bin cityb -- deployment init --out ./city-b-deep-web3-10.toml --service-set free-deep-web3-10
cargo run --bin cityb -- deployment init --out ./city-b-deep-web4-10.toml --service-set free-deep-web4-10
cargo run --bin cityb -- deployment init --out ./city-b-deep-web5-10.toml --service-set free-deep-web5-10
cargo run --bin cityb -- deployment init --out ./city-b-candidates.toml --service-set free-candidate-pool
cargo run --bin cityb -- deployment validate --file ./city-b.toml --json
cargo run --bin cityb -- deployment compile --file ./city-b.toml --root ./city-b-artifacts --json
cargo run --bin cityb -- deployment recipes --file ./city-b.toml --json
cargo run --bin cityb -- adapter doctor free-wide --fixture-root fixtures/cityb/free-service-replay --json
cargo run --bin cityb -- adapter doctor free-deep-10 --fixture-root fixtures/cityb/free-service-replay --json
cargo run --bin cityb -- adapter doctor free-deep-text-10 --fixture-root fixtures/cityb/free-service-replay --json
cargo run --bin cityb -- adapter doctor free-deep-web-10 --fixture-root fixtures/cityb/free-service-replay --json
cargo run --bin cityb -- adapter doctor free-deep-web2-10 --fixture-root fixtures/cityb/free-service-replay --json
cargo run --bin cityb -- adapter doctor free-deep-web3-10 --fixture-root fixtures/cityb/free-service-replay --json
cargo run --bin cityb -- adapter doctor free-deep-web4-10 --fixture-root fixtures/cityb/free-service-replay --json
cargo run --bin cityb -- adapter doctor free-deep-web5-10 --fixture-root fixtures/cityb/free-service-replay --json
cargo run --bin cityb -- capture free-wide --json
cargo run --bin cityb -- capture free-deep-10 --json
cargo run --bin cityb -- capture free-deep-text-10 --json
cargo run --bin cityb -- capture free-deep-web-10 --json
cargo run --bin cityb -- capture free-deep-web2-10 --json
cargo run --bin cityb -- capture free-deep-web3-10 --json
cargo run --bin cityb -- capture free-deep-web4-10 --json
cargo run --bin cityb -- capture free-deep-web5-10 --json
cargo run --bin cityb -- monitor plan --live --json
cargo run --bin cityb -- monitor install --live --enable-now --json
cargo run --bin cityb -- monitor status --json
cargo run --bin cityb -- monitor nurse --brief
cargo run --bin cityb -- monitor findings --json
cargo run --bin cityb -- monitor compact --json
cargo run --bin cityb -- monitor review --json
cargo run --bin cityb -- monitor import --apply --json
cargo run --bin cityb -- evidence sync --json
cargo run --bin cityb -- evidence sync --apply --json
cargo run --bin cityb -- evidence curate --json
cargo run --bin cityb -- evidence curate --apply --json
cargo run --bin cityb -- evidence index --apply --json
cargo run --bin cityb -- evidence board --fixture-root fixtures/cityb/free-service-replay --json
cargo run --bin cityb -- promote check --fixture-root fixtures/cityb/free-service-replay --json
cargo run --bin cityb -- rendezvous firehose-fixture --firehose-fixture-root fixtures/cityb/rendezvous-firehose --require --json
cargo run --bin cityb -- rendezvous promote-firehose --service pastebin-archive --firehose-fixture-root fixtures/cityb/rendezvous-firehose --fixture-root fixtures/cityb/free-service-replay --json
cargo run --bin cityb -- rendezvous collect-firehose --service pastebin-archive --source https://pastebin.com/archive --max-pages 1 --max-bytes 65536 --max-candidates 64 --dry-run --json
cargo run --bin cityb -- rendezvous promote-firehose --service github-gists-public --firehose-fixture-root fixtures/cityb/rendezvous-firehose --fixture-root fixtures/cityb/free-service-replay --json
cargo run --bin cityb -- rendezvous collect-firehose --service github-gists-public --source 'https://api.github.com/gists/public?per_page=10' --max-pages 1 --max-bytes 131072 --max-candidates 128 --dry-run --json
cargo run --bin cityb -- rendezvous promote-firehose --service pastefy-public --firehose-fixture-root fixtures/cityb/rendezvous-firehose --fixture-root fixtures/cityb/free-service-replay --json
cargo run --bin cityb -- rendezvous promote-firehose --service fragbin-public --firehose-fixture-root fixtures/cityb/rendezvous-firehose --fixture-root fixtures/cityb/free-service-replay --json
cargo run --bin cityb -- rendezvous collect-firehose --service fragbin-public --source https://www.fragbin.com/api/pastes --max-pages 1 --max-bytes 131072 --max-candidates 128 --dry-run --json
cargo run --bin cityb -- release archive --plan --json
cargo run --bin cityb -- release archive --plan --signature-policy require-present --json
cargo run --bin cityb -- release ceremony --json
cargo run --bin cityb -- release sign RELEASE_DIR/SHA3SUMS --signing-key RELEASE_SIGNING_KEY --apply --json
cargo run --bin cityb -- release verify DIR_OR_TAR_GZ --json
cargo run --bin cityb -- dead-drop archive capacity-soak --root ./city-b-artifacts --service-set free-stable --json
cargo run --bin cityb -- dead-drop archive preview --root ./city-b-artifacts --service-set free-stable --json
cargo run --bin cityb-biggun -- promotion-tranche --archive-evidence-root ./city-b-artifacts --require --json
cargo run --bin cityb -- anchor status --root ./city-b-artifacts --json
cargo run --bin cityb -- anchor ceremony --root ./city-b-artifacts --deployment ./city-b.toml --json
cargo run --bin cityb -- anchor policy --root ./city-b-artifacts --apply --json
cargo run --bin cityb -- anchor retrieve --root ./city-b-artifacts --source ANCHOR_FILE_OR_URL --apply --json
cargo run --bin cityb -- anchor live-drand --root ./city-b-artifacts --require-native-proof --apply --json
cargo run --bin cityb -- anchor live-rekor --root ./city-b-artifacts --uuid REKOR_UUID --apply --json
cargo run --bin cityb -- anchor live-ct --root ./city-b-artifacts --url CT_GET_STH_OR_ENTRY_URL --apply --json
cargo run --bin cityb -- cycle preview --root ./city-b-artifacts --deployment ./city-b.toml --json
cargo run --bin cityb -- cycle plan --root ./city-b-artifacts --deployment ./city-b.toml --json
cargo run --bin cityb -- cycle apply --root ./city-b-artifacts --deployment ./city-b.toml --with-collect --json
cargo run --bin cityb -- cycle run --root ./city-b-artifacts --deployment ./city-b.toml --json
cargo run --bin cityb -- collect probe --root ./city-b-artifacts --deployment ./city-b.toml --service catbox --location URL_OR_FILE --json
cargo run --bin cityb -- collect cursor --root ./city-b-artifacts --deployment ./city-b.toml --service catbox --lane mirror --source LISTING_URL_OR_FILE --json
cargo run --bin cityb -- collect fixture-template --root ./city-b-artifacts --deployment ./city-b.toml --out captured-provider-fixtures.jsonl --all-cases --json
cargo run --bin cityb -- collect live-capture --deployment ./city-b.toml --capture-dir /tmp/cityb-live-free-stable --fixture-out ./captured-provider-fixtures.jsonl --json
cargo run --bin cityb -- collect fixture --root ./city-b-artifacts --deployment ./city-b.toml --fixture captured-provider-fixtures.jsonl --json
cargo run --bin cityb -- node-kit --root ./city-b-artifacts --out ./city-b-node-kit
cargo run --bin cityb-node -- kit verify --root ./city-b-node-kit --json
cargo run --bin cityb-node -- field-mode render --profile low-power-field
cargo run --bin cityb-node -- serve --config CONFIG --state-dir /tmp/cityb-node-state --field-profile low-power-field --clock-confidence offline --now-epoch 1 --cycles 1
cargo run --bin cityb-biggun -- guide
cargo run --bin cityb-biggun -- living --max-report-age-hours 24 --json
cargo run --bin cityb-biggun -- truth --plan --json
cargo run --bin cityb-biggun -- truth --run --quick --json
cargo run --bin cityb-biggun -- mutation-corpus --json
cargo run --bin cityb-biggun -- parser-diff --require --json
cargo run --bin cityb-biggun -- parser-diff --fixture-root fixtures/cityb/free-service-replay --firehose-fixture-root fixtures/cityb/rendezvous-firehose --require --json
cargo run --bin cityb-biggun -- provider-reality --service-set free-stable --fixture-root fixtures/cityb/free-service-replay --firehose-fixture-root fixtures/cityb/rendezvous-firehose --archive-evidence-root ./city-b-artifacts/city-b-archive-erasure --required-shards 30 --require --json
cargo run --bin cityb-biggun -- soak-report --service-set free-stable --fixture-root fixtures/cityb/free-service-replay --firehose-fixture-root fixtures/cityb/rendezvous-firehose --archive-evidence-root ./city-b-artifacts --required-shards 30 --json
cargo run --bin cityb-biggun -- anchor-amnesia --json
cargo run --bin cityb-biggun -- replay --root ./city-b-artifacts --require --json
cargo run --bin cityb-biggun -- footprint --json
cargo run --bin cityb-biggun -- targets --json
cargo run --bin cityb-biggun -- targets --check --json
cargo run --bin cityb-biggun -- gate --plan --json
cargo run --bin cityb-biggun -- gate --quick --json
cargo run --bin cityb-biggun -- gate --release --quick --plan --json
cargo run --bin cityb-biggun -- selftest --plan --json
cargo run --bin cityb-biggun -- selftest --quick --plan --json
cargo run --bin cityb-biggun -- selftest --release --quick --plan --json
nix develop -c ./scripts/check-targets.sh
```

The default deployment template is a one-service local proof. `--service-set
free-stable` writes the current repeated-live, no-credential public-service
manifest. The October 18 snapshot contained 60 providers; its dated capability
counts are historical rather than the definition of the current set. Read the
embedded `capability_ledger` from `cityb next --root ROOT --free --json` (or
from `cityb provider health --root ROOT --service-set free-stable --json`)
rather than copying the dated values into automation.

The retained October 13 archive proof over the then-current 63-provider set is
forensic history. The October 18 reconciliation is the latest admitted
production proof: a signed 7.1 MiB release was encoded across the 60-provider
generation,
42 exact receipts clear the 30-shard threshold, persisted OpenSSH release
policy admitted the reconstructed bytes, and CityB regenerated the epoch-21
field pack and recovery card. The October 18 topology repair recovered Beacon
Host without rebuilding the generation. Loss of Cloudflare AS13335 would now
leave 27 of those 42 receipts. Every remaining assigned outside-root service
has already rejected or misreturned bytes at or below the current shard width,
so CityB classifies this generation as `root-diversity-constrained` instead of
inventing another capacity-probe command. The admitted release remains usable;
improved correlated-root survival requires a future generation with a
different provider mix or shard width.
bin.birdflop.com, haste.unbelievaboat.com, paste.agradip.fyi, Valhalla Paste,
Pastr, tmpfiles, zoomie.sh, and pastes.dev remain pointer-stable but
archive-shard-ineligible until archive-sized evidence proves otherwise.
Bytebin remains implemented and observed in `free-wide`; repeated required-path
rejections on November 2, 3, and 4 removed it from the stable easy path while
preserving its long positive history and later recovery evidence.
Files.offshore.cat and Sendit remain recovered watch items because each has
historical failure evidence plus later exact-byte recapture, not an active
demotion verdict. Dpaste moved back to `free-wide` after post-recovery failures
on October 17 and October 18 made the demotion gate unambiguous. NullPaste
remains implemented in `free-wide` but is
not in the easy set after repeated retained monitor fetch failures on September
17-19, 2026. Filebin, Termbin, and temp.sh also remain implemented outside the
easy set after retained monitor evidence through September 26 showed repeated
Filebin token-missing receives and repeated Termbin/temp.sh upload rejections.
Paste.rs and Catbox are also kept outside the easy set after imported September
30-October 7 monitor evidence showed date-separated upload rejections.
Bashupload is likewise outside the easy set after imported October 11-12 monitor
evidence showed repeated upload rejections.
`--free` selects `free-stable` from the short
operator path. `--service-set free-five` preserves the older
Filebin/0x0 drift bench, and `--service-set free-wide` adds the original broad
anonymous adapter bench, including Litterbox, repeated negative provider
cases, and the measured public listing carriers `pastebin-archive`,
`github-gists-public`, and `pastefy-public`. The continuous listing monitor also
keeps suspended `fragbin-public` in its research/recheck lane.
Public firehose/listing carriers are receive/listing-only: Goldilocks can fetch
and retain Pastebin Archive and unauthenticated GitHub public-Gist listing
pages through `rendezvous collect-firehose`. FragBin's reader and October 7/10
fixtures remain parser and repair evidence, but repeated October 17–18 HTTP 500
results suspended its Tiny declaration pending later recovery and source
review. Pastefy's October 18 and October 20 anonymous captures both succeeded.
They prove a large full-content JSON array with no usable cursor or expiry field,
so CityB enforces an 8 MiB fetch ceiling, a 4,096-item candidate ceiling, in-memory
normalization, and digest/fact retention rather than keeping arbitrary public
bodies. Date-separated fixtures plus Biggun parser agreement now admit Pastefy
as the third retained-local Tiny sweep. Compiled listener configs point Tiny at
retained local listing-object directories, and cycle planning never schedules
listing-only providers as posting targets. Use `cityb up --wide-free`
only when an operator intentionally wants that wider public-service mutation
and research surface. `--service-set free-deep-10` adds a
separate ten-provider research bench for x0.at, curl.by, End2End.tech, file2.me,
JuiceBox, TempFile.org, ayaya.beauty, hostb, hst.sh, and haste.rys.pw; it
requires all ten in its live capture dry-run defaults and deliberately sets the
mirror lane floor to zero because these adapters carry pointer/heartbeat/route
hint packets, not archive mirrors. `--service-set free-deep-text-10` adds the
second ten-provider bench for anonymous text and paste endpoints:
paste.code-solutions.dev, paste.helpch.at, bytebin.lucko.me, api.pastes.dev,
bpa.st, transfer.archivete.am, pastefy.app, pastefox.com, haste.zneix.eu, and
bin.birdflop.com. It also uses pointer/heartbeat/route-hint lanes only and
should be run with `cityb capture free-deep-text-10 --live --require-all` while
it remains a promotion-evidence set. `--service-set free-deep-web-10` adds the
third ten-provider bench for anonymous web paste/file endpoints: mclo.gs,
Sourcebin, paste.agradip.fyi, SpaceBin, CrafterBin, qurl.sh, Mythical Paste,
YukiAPI, AgentMediaTools, and paste.firnsy.com. It remains a strict evidence
bench, not an easy default; run `cityb capture free-deep-web-10 --live --require-all`
before deciding which services deserve later promotion.
`--service-set free-deep-web2-10` adds a fourth ten-provider web/API bench:
PasteHTML, OKFile, here.now, haste.unbelievaboat.com, rentry.co,
files.offshore.cat, qu.ax, zoomie.sh, openSUSE Paste, and Debian Pastezone.
Several of these require provider-specific normalization, rendered-page token
probes, or multi-step receive paths. The first retained September 16, 2026
corpus passed all ten adapters, and repeated retained evidence later promoted
the eight exact-byte providers into `free-stable`: PasteHTML, OKFile, here.now,
haste.unbelievaboat.com, files.offshore.cat, zoomie.sh, openSUSE Paste, and
Debian Pastezone. rentry.co and qu.ax are rendered-token probes rather than
exact raw-byte receive paths, so they remain discovery carriers rather than
archive-mirror candidates.
`--service-set free-deep-web3-10` adds a fifth ten-provider web/API bench:
CentOS Paste, rpa.st, AlmaLinux Paste, OpenStack Paste, yt-project Paste,
OpenDev Paste, Gentoo LogPaste, Ubuntu China Paste, p.defau.lt, and paste2.org.
The first seven use observed raw text receive paths from Stikked, Pinnwand,
LodgeIt, and LogPaste families; Ubuntu China Paste, p.defau.lt, and paste2.org
are rendered-token carriers. The first retained September 16, 2026 corpus
passed all ten providers, and the September 20 retained monitor pass repeated
the 10/10 result. Keep this set strict with
`cityb capture free-deep-web3-10 --live --require-all` until repeated dated
captures show which providers stay useful. CoShareX remains a built adapter,
but it is outside the strict ten-provider set until its anonymous API stops
rejecting repeated live evidence runs.
`--service-set free-deep-web4-10` adds a sixth ten-provider web/API bench:
Pastr, Valhalla Paste, Write.as, p.ip.fi, Kagit, ShareNotes, Pastebin.ai,
da.gd, TinyURL, and clck.ru. Pastr and Valhalla use Hastebin-compatible raw
receive paths; Write.as, p.ip.fi, Kagit, ShareNotes, and Pastebin.ai use
observed public text or JSON receive paths; da.gd, TinyURL, and clck.ru are
redirect-token carriers whose receive proof is the public redirect target
containing the CityB token, not exact staged bytes. Keep this set strict with
`cityb capture free-deep-web4-10 --live --require-all` until repeated dated
captures show which providers stay useful. The first retained September 16,
2026 corpus passed all ten providers and retained real redirect observations
for the three non-exact shortener lanes.
`--service-set free-deep-web5-10` adds a seventh ten-provider web/API bench:
Scuttled, ti.fo, docs-md, 8gwifi, tnypst, Droptext, Luis Aranguren Paste,
Ulvis, MeshaLive, and AISense 307.fi. Scuttled and tnypst produced direct
exact text/markdown bodies; ti.fo, docs-md, and 8gwifi strip one trailing
newline, so CityB stages newline-normalized payloads for them; Droptext and
Luis Aranguren Paste are rendered-token carriers; Ulvis, MeshaLive, and 307.fi
are redirect-token carriers. Keep this set strict with
`cityb capture free-deep-web5-10 --live --require-all` until repeated dated
captures show which providers stay useful. The first retained September 16,
2026 corpus passed all ten providers.
`--service-set free-candidate-pool` writes the researched 260-provider
candidate queue through generic/manual adapters for staged investigation; the
candidate planner includes a priority-0 newest-tranche batch so each ten-provider
expansion can be soaked before the next batch is added. It is
not a stable live-posting path. `cycle preview` and `cycle plan` are
non-mutating;
`cycle apply` and `cycle resume` are the explicit publication steps. `cycle
next` reports both the state-transition command and a separate
provider-health repair command for access, moderation/expiry, rate-limit,
provider, parser, content, local-input, and history-recovery cases. It also
includes a ranked `service_repair_queue` so a degraded service set can be fixed
without reading every receipt by hand. Each queue entry carries the adapter,
collector mode/source, recipe command, receive command, and fixture-template
command so the next operator can either inspect the service, retry the correct
receive surface, or create a local replay corpus without guessing at provider
semantics.

Routine cockpit commands use a bounded field-pack inventory: `doctor`, `next`,
and `operator card` call `field-pack status --quick`, which explicitly reports
digests as not checked and never claims handoff readiness. Use ordinary
`field-pack status`, `field-pack verify`, or `doctor --deep` when pack bytes must
be authenticated. Doctor JSON contains compact step summaries by default; add
`--verbose` for nested transcripts. The `up`, `check`, and `next` workflow JSON
uses the same compact-by-default rule while preserving its top-level decision
fields.

`doctor`, `install`, `operator card`, `up`, `check`, and `next` are the normal operator entry points: `doctor` runs the side-effect-free readiness sweep over binary identity, provider health, rendezvous, release, monitor, field-pack, install, and candidate-summary surfaces; `install` dry-runs copying `cityb`, `cityb-node`, and `cityb-biggun` from the current binary directory into the chosen bin directory before `--apply`; `operator card` is the zero-memory top-10 cockpit over `check`, `next`, provider health, monitor nurse, field-pack status, release plan, install dry-run, provider candidates, and recovery-card command; `up`
creates or validates the retained root and deployment, compiles the deployment,
previews hazards, runs or resumes the current cycle, collects, reviews, exports
the Tiny kit, and prints the next command; `check` is side-effect free; `next`
prints the shortest evidence-bound action and now reports field-pack freshness, topology/root diversity, rendezvous coverage, and provider evidence together. `recovery-card` writes a one-page SVG amnesia card with current epoch, root digest, active providers, exact recovery commands, field-pack readiness, and a verification matrix. `field-pack status|verify|export` is the obvious Tiny-kit surface: it tells the operator whether the kit and recovery capsule are present, whether their manifests still match pack contents, which runtime/deployment/release identities are known, whether chain/floor records are visible, whether read-only / zero-write Tiny operation is plausible, and exposes a compact `tiny_status` object before forwarding verification or export work. `release archive` accepts `--signature-policy require-present|require-verified` as an archive-planning annotation, adds `RELEASE-ID.json`, the canonical `SHA3SUMS` signing payload, and optional `SHA3SUMS.sig` handoff facts to the movable artifact; `release verify` can enforce signature presence or OpenSSH detached-signature verification, and field-pack status can require release manifests that already report verified signatures. `service ls` wraps the adapter doctor for the selected free-service set, `repair queue` wraps the provider-health repair selector, `post dossier` is the read-only posting decision page over cycle preview, provider health, topology severity, lane summaries, retained receipt excerpts, replacement preview, hazards, and exact apply command, `post dossier --live-topology` lets DNS/IP/ASN/CDN evidence influence replacement previews, `post due` and lane-specific `post pointer|heartbeat|route-hint|mirror` preview by default and mutate remote services only with `--apply`, `explain event` reads the projection/history/journal for one idempotency key, `explain service SERVICE` combines deployment metadata, retained cycle evidence, last cycle-result receipt excerpts, last probe/cursor excerpts, provider health, recipes, and repair commands for one declared service, and `export field-pack` wraps the public tiny-kit plus recovery-capsule handoff gate. `deployment recipes` prints the service-specific
post/probe/cursor/fixture guidance generated from the same metadata that
planning uses. Add `--with-collect` when the normal local
collection pass should run immediately after a clean batch. `cycle run` is the
operator-short path: it creates a plan when none exists, applies or resumes only
safe planned work, collects by default, and refuses staged, failed, or ambiguous
evidence states. `collect probe` is the read-only exact-location receive check
for a final URL or local carrier file; it records final URL, redirect count,
HTTP status when present, parser facts, provider-health class, and service
reliability facts used by later planning.
`collect cursor` is the bounded listing-source
collector: it retains the listing bytes, uses the service's declared cursor
mode, discovers exact candidate URLs or files where the mode allows it, probes
only those candidates, records source redirect/final-location facts, preserves a
normalized continuation location when the listing exposes one, links the new
current report to the previous current report digest, persists the next cursor
report, and feeds coverage facts back into later cycle plans. `collect
fixture` replays captured provider payload/error fixtures without touching the
network, including optional final URL, redirect count, and HTTP status facts, and
uses the same parser and reliability path as live probes. `collect
fixture-template` writes runnable fixture JSONL for the current retained pointer
and deployment, and `--all-cases` expands the adapter recipe's declared
verified and negative replay cases. `adapter doctor` is the side-effect-free
service-set inspection surface: it shows which adapters are in
free-stable/free-five/free-wide/free-deep-10/free-deep-text-10/free-deep-web-10/free-deep-web2-10/free-deep-web3-10/free-deep-web4-10/free-deep-web5-10, how much exact-byte evidence backs each one,
the dated success/failure history, the dominant provider-health failure, and
the next operator action. `capture free-stable|free-five|free-wide|free-deep-10|free-deep-text-10|free-deep-web-10|free-deep-web2-10|free-deep-web3-10|free-deep-web4-10|free-deep-web5-10` is the
Rust-owned live-service capture workflow: without `--live` it prints the
exact command and mutates nothing; with `--live` it creates a retained root,
posts through the selected free adapters, preserves transcripts, and converts
them into replay fixtures. `collect live-capture` remains the lower-level
conversion command for already-retained captures. `evidence board` summarizes
checked-in service reality by adapter, and `promote check` applies the
free-stable evidence checklist without editing deployments. `evidence sync` is the preferred local evidence inbox: it runs monitor review, monitor import in dry-run or `--apply` mode, provider health, promotion check, and parser-diff automatically after an applied import unless `--no-parser-diff` is explicit, reports top-level `status` and `success`, reports a compact `changed_summary` with provider/date/success/failure/exact-byte counts plus previews and omitted counts for large imports, and then prints one next command. `provider health` remains the explicit provider inbox over checked-in replay fixtures plus retained monitor captures: it reports healthy, degraded, recapture-needed, promotion-review, demotion-review, firehose-review, and import-pending providers, emits a priority-ordered `triage_queue` with severity/decision/failure-summary/command fields, exposes top-level `status` and `success`, and prints the exact next local command. Historical failures become `watch` once a later ordered exact-byte observation proves recovery; a newer failure always degrades current pointer health even when older archive-capacity evidence is good. Listing-only providers such as Pastebin archive route to `rendezvous promote-firehose` instead of a posting capture. `provider explain PROVIDER` is the one-provider view over the same inbox so the operator can ask why one service is healthy, degraded, promotable, listing-only, or due for recapture; it includes the same failure summary. `provider dossier PROVIDER` is the promotion-decision page: it joins selected-set membership, stable membership, date-separated exact-byte gates, mixed-history caveats, a failure summary, parser-diff and topology commands, recapture command, and dry-run/apply promotion commands without mutating anything. `provider promotion-board --service-set SET` is the batch promotion desk: it ranks every provider in the selected set, names ready/blocked/recapture/firehose/stable groups, points at dossier and source patch-plan commands, exposes top-level `status` and `success`, and can run the same bounded parser/topology gates before telling the operator which provider to review first. `provider stable-plan --from SET --to free-stable` turns a repeated-green bench into one reviewable batch source plan: exact-byte providers become stable-set additions, rendered-token/redirect-token/listing providers stay in discovery lanes, repeated-green candidate probes remain in a `native_adapter_required` lane until production Rust adapter semantics exist, and `--apply` writes only a plan artifact plus unified diff for human source review. It also names source files, review steps, and validation commands, and reports `diff_status=no-source-change` when a bench is already represented in `free-stable`. `provider lane-board --lane discovery|exact|all` is the companion board for token-only and exact-byte lane separation, so the operator can promote discovery usefulness without pretending it is mirror evidence. Add `--run-checks` to run bounded local parser/topology checks when `cityb-biggun` is available. `provider patch-plan PROVIDER --action promote|demote|retire` is the source-level provider-set planning page: it names which built-in set constants would change, cites fixture and monitor evidence, exposes top-level `status` and `success`, prints a gate summary with exact success/failure date gates, reports `already-present`, `already-demoted`, or `already-absent` when the requested source change is already true, points to evidence sync, dossier, parser-diff, and topology commands, embeds a unified source diff, and writes only a reviewable plan file when `--apply` is passed. `provider candidates list|plan|test|capture|promote` is the free-provider bench: it keeps the 260-provider hunt inside the binary, ranks behavior-diverse tranches, surfaces the newest staged candidate tranche first, exposes top-level status/success on list/plan/test/capture, dry-runs candidate capture by default, and prints retained-root/deployment/recipe/fixture-template commands for one selected provider without remote mutation. Candidate `--live` capture intentionally fails until provider-specific native adapter code exists; generic candidate adapters are staging paths, not service identities. Candidate promotion stops at `native-adapter-required` until exact provider fixtures and parser agreement justify catalog edits. `provider promote|demote|retire` is local deployment hygiene: dry-run by default, writes only valid deployment metadata with `--apply`, backs up the manifest, validates the patched file, never mutates a public service, and reports dry-run/apply/local-mutation/evidence facts in JSON. `provider promote --apply` requires a supplied fixture directory with date-separated exact-byte evidence for that provider; supplied evidence for demotion or retirement is validated when present. `monitor plan|run|install|status|nurse|review|import` turns that same capture/evidence/promote path into a retained continuous provider test facility. The default monitor preset runs `free-stable` every tick and rotates one research bench per live run, so a single small machine can cover the stable set, `free-wide`, and all seven deep benches over time without one giant public-service burst. `monitor run` is dry unless `--live` is explicit; `monitor install --live --enable-now` writes a user systemd timer, stores captures under `~/.local/state/cityb/provider-monitor` by default, keeps listing-only providers out of posting adapters, and checks Pastebin archive, GitHub public Gists, FragBin public pastes, and the bounded digest-only Pastefy research source through `rendezvous collect-firehose` instead. `monitor nurse --brief` is the timer/report/import health answer: it checks latest report presence, installed unit files, whether the installed `ExecStart` targets the selected state directory, whether the installed monitor binary matches the selected binary, systemd timer clock facts when available, importable retained evidence, provider-health attention, degraded/urgent adapters, names the latest failed monitor preset/service/adapter/failure when a run failed, parses object or plain-string failure output from retained reports, and points `DO_NOW` at monitor reinstall for stale units/binaries, the installed monitor run for service-set mismatches on the current binary, or `provider explain` for provider failures when the retained report identifies one; full JSON keeps nested monitor-review and provider-health transcripts, compact `latest_failure`, and `latest_failure_command`. `monitor review` compares retained machine evidence against checked-in fixtures and flags urgent stable-set questions without changing promotion status. `monitor import --apply` copies retained monitor JSONL/body evidence into the repo fixture corpus after review; `evidence sync --apply` wraps that import with the review, parser agreement attempt, and post-import health checks so the operator does not have to remember the sequence. Promotion and demotion decisions still require date-separated retained evidence; same-day failure evidence is an urgent repair question, not an automatic stable-set edit. `cityb next` embeds the same provider inbox for free-service workflows, so the one cockpit reports import-pending monitor evidence, healthy/degraded/recapture/promotion/demotion/firehose/urgent provider counts and lists, declared and effective rendezvous coverage, retained Tiny sweep services, topology/root diversity, a plain `topology_summary`, field-pack status and digest freshness, provider stable-plan counts from the default promotion bench, and the retained-cycle action together; explicit `--free`, `--wide-free`, `--local`, or `--service-set` selections control rendezvous/provider facts even when a retained deployment file exists, and local-proof workflows also show global `free-stable` provider health so public-service drift stays visible. When the selected set is already `free-stable`, the global provider summary reports `same-as-selected` instead of a duplicate zeroed panel. Import-pending retained monitor evidence and degraded provider source-review commands become the primary `command`, while `workflow_command` preserves the root/cycle action and archive-erasure fields preserve spray/collect work to run afterward; if a bench has repeated exact-byte promotions ready and no more urgent inbox item, `next` can point straight to the batch stable-plan review. `cityb check` includes the same topology/root-diversity summary and retained Tiny sweep fields so fake diversity and receive-only listing coverage are visible during side-effect-free checks, and `cycle preview` now emits severity-aware topology planner action plus topology hazards when roots collapse; `local-proof` single-root collapse is expected proof-path evidence, not live-provider diversity. `cycle plan` writes `city-b-pointer-chain-member.json` and, with private council seat seeds present, `city-b-pointer-chain-member-signed.json` plus a threshold-signed act; `cycle sign-pointer-chain` upgrades an existing deterministic plan with an archive-aware validity window while preserving dense serials; `publish` reports when pointer-chain acts are sealed into the next archive bundle; `anchor status` is the side-effect-free missed-cycle page over retained archive-chain, floor, pointer-chain, signed pointer-chain, field-pack, retained public-anchor evidence, source policy, and append-only history facts; `anchor policy` creates the local durable-source policy; `anchor retrieve` reads an operator-selected file or URL, validates a CityB public-anchor document, enforces source/trust-root policy plus rollback/split-view/append-only history checks, and writes only the local retained anchor file/history when `--apply` is explicit; and `cycle status`, embedded kit verification, standalone `cityb-node kit verify`, `cityb-node serve`, and `cityb-node status` report whether Tiny should treat the pointer-chain source as unsigned planning state, signed-but-pending state, or verified archive-chain state and whether a promoted retained-local Tiny sweep root is ready. Generated public-service deployments now carry adapter default `base_url` metadata, so `rendezvous doctor --service-set ... --live-topology` can inspect topology for catalog service sets instead of requiring a separately written TOML deployment. Use `cityb rendezvous doctor --live-topology --json` when the operator intentionally wants live DNS/IP/ASN/CDN hints for declared carrier hosts without making offline checks depend on the network; it attempts Team Cymru when `dig` is available and falls back to RIPEstat HTTP prefix facts when it is not. High-composition JSON surfaces now expose top-level `status`, `success`, `command`, and `reason` where practical, while detailed transcripts remain nested. Pass `--fixture-root` and `--state-dir` to `next` or `evidence sync` when reviewing copied corpora or retained monitor evidence outside the defaults. The current command-and-answer gap review lives in [docs/city-b-operator-gap-review.md](docs/city-b-operator-gap-review.md). When launched from
the source tree, repository fixtures are resolved without extra configuration.

The monitor's complete operator surface is now
`plan|run|install|status|nurse|coverage|findings|compact|review|import`.
Candidate probes are derived directly from the provider catalog and native
probe dispatch table, so a newly implemented probe automatically joins the
next live soak. Provenance-aware reports bind the exact
binary/source/build/artifact/provider generation, elapsed time, rotation
position, monotonic sequence, and predecessor fingerprint. `monitor coverage`
summarizes the dates, named vantages and egresses, build identities, research
rotations, listing feeds, sequence gaps, and fingerprint-chain breaks actually
represented by retained evidence; `status` and full `nurse --json` embed that
bounded summary. Nurse/pre-soak readiness also binds the latest report's build
identity to the selected executable; replacing a binary makes the installed
run command the next action until that exact build publishes a report.
Required infrastructure and stable-lane failures are retained
and return nonzero, while capacity, suspended-listing, and candidate findings
remain explicit non-blocking experiments. Candidate findings describe provider
semantics, not merely process exits: a probe that executes successfully while
proving a timeout, credential gate, non-exact receive path, or other classified
provider failure is still counted and routed to `monitor findings`. Retained v2
reports written before this distinction are normalized from their step bodies
at read time; evidence files are never rewritten to repair a presentation
aggregate. Completed negative archive-capacity experiments follow the same rule:
the monitor execution remains healthy, while corruption, expiry, rejection, or
other provider failure increments `capacity_findings`; current readers recover
that fact from older retained step bodies that under-counted it. Current
generated systemd units cap one pass at 5 hours 30 minutes, lower its CPU/I/O
priority, kill the complete
process group on timeout, and run best-effort post-pass compaction to the newest
96 reports and 24 disposable capture workrooms after either success or failure.
Archive capacity probes and retained-shard rechecks carry the same vantage and
egress labels as pointer/listing evidence.

The default `monitor review --json` and `monitor import --json` path lists are bounded to 64 decision-relevant rows with explicit omitted counts; already-imported rows do not inflate review output. Add `--verbose` only when a complete path transcript is intentionally needed.

Current listing and monitor state: Pastebin Archive, GitHub public Gists, and
Pastefy are promoted bounded listing readers; FragBin is the suspended research
recheck. Monitor JSON separates infrastructure, stable lane, capacity
experiments, promoted listings, research listings, and candidate probes, so an
expected experiment finding cannot make a healthy required lane look failed.

When launched from the source tree, an unpacked release, or a subdirectory beneath either one,
these fixture-backed commands find `fixtures/cityb/free-service-replay/`
automatically; pass `--fixture-root` for copied corpora or out-of-tree benches.

Monitor triage is reconciled against current provider health. A failed provider
from the latest aggregate report becomes `DO_NOW` only while newer evidence
still marks it degraded or urgent; a successful recapture clears that stale
action without rewriting the historical report.

`cityb evidence curate` closes the source-control half of that inbox. It is
dry-run first and selects the newest decision-bearing semantic facts while
preserving success/failure transitions and unparsed adversarial artifacts. It
content-addresses repeated bodies by SHA3-256, emits a manifest, and explains
every keep, preserve, or prune. The review emits an
`--expected-generation`/`--expected-fingerprint` apply command; apply fails
closed if another monitor pass changes the evidence source before the reviewed
transaction runs. It also binds curation to the monitor executable identity:
an apply from a different build fails closed until the scheduled generation is
replayed, or an operator deliberately records a compatibility decision with
`--accept-build-mismatch`. Default JSON is bounded, while `--verbose` carries the full
manifest. `--apply` removes redundant repository imports and verified raw
monitor mirrors only after the retained corpus copy exists; retention days and
maximum state bytes bound byte-identical residue. The
October 23 transaction considered 565 newly imported files, retained 176
decision-bearing JSONL/transcript files plus the required content-addressed
bodies, and removed 389 redundant repository imports plus 615 verified raw
state mirrors before source review. Its repeated preview has zero pending
curation. Curation refuses any selected fixture with a dangling
body reference and is idempotent over an already-canonical body. Evidence
generation and sealed high-water mark are both 38 after the first
system-managed Stil rotation and the repository-wide historical curation on
October 24; the shared index covers 3,334 decision records,
15,600 observations, and 206 providers. The first provenance-v2 pass imported 274 raw candidates and
retained 121 decision-bearing records. The exact-build follow-up imported 278
raw files and retained four decision-bearing JSONL artifacts plus one new
content-addressed body after generation-checked curation. The first Stil pass
then considered 275 new files, retained 164 decision-bearing records plus 48
canonical bodies, pruned 111 redundant imports and 300 verified raw-state
mirrors, and completed its source-control handoff. Mixed same-day outcome
scopes retain ordered observation identities,
so a green/failure/green transition cannot be collapsed into an obsolete final
failure merely because the two green bodies are byte-identical.

The October 24 historical-corpus migration reduced 14,407 repository artifacts
to 4,177 and 7,562 body paths to 839 without changing the 206-provider evidence
domain. All replay body byte strings are now unique: 837 live under their
SHA3-256 canonical names and the two remaining OCR source objects are distinct.
This is also a Nix correctness requirement. A local flake snapshot imports every
tracked artifact; keeping thousands of byte-identical bodies caused Nix's
hardlink deduplicator to reach the filesystem's 65,535-link ceiling. The
`evidence-body-cas` flake check now rejects duplicate body bytes or an incorrect
canonical digest before that failure can recur.

Before leaving the monitor to soak, run `cityb monitor nurse --brief --json` and inspect its generated capability ledger, fixture-import path, timer identity, and firehose rotation rather than comparing against counts copied into prose. `pre_soak_infrastructure_ready` covers mechanical prerequisites. `pre_soak_ready` becomes true only when the latest required lanes match the selected binary and current provider generation, the retained archive proof is usable, the import inbox is empty, the evidence generation is sealed, curated fixture additions have completed their source-control handoff, and provider health needs no action. Capacity, research-listing, and candidate failures remain visible experiment findings but do not make a successful stable lane false. `monitor nurse`, `monitor status`, `next`, and Stil carry the same explicit evidence root and expose the same inbox/sealed generation, curation command, repository-handoff count, timer facts, and replay command. Evidence from an older build must be replayed before curation or provider-policy changes. The archive surface calls static adapter compatibility `structural_adapter_support`; dated payload-capacity proof remains a separate capability-ledger rung. Use `cityb monitor status --archive-root ./city-b-artifacts --json` for live facts, `cityb monitor findings --json` for nonblocking experiments, `cityb monitor compact --json` for bounded local cleanup, and `cityb-biggun soak-report --service-set free-stable --archive-evidence-root ./city-b-artifacts --required-shards N` for the read-only truth rollup.

Monitor status obtains its repository handoff count from narrow tracked-diff and
untracked-path queries below the evidence root, not a full `git status` index
refresh. The monitor and compaction lifecycles also retain a timestamped
allocated-byte measurement under monitor state. Interactive cockpits reuse that
advisory measurement; a missing or invalid record falls back to an exact scan.
These optimizations change question cost only—dirty evidence still blocks
handoff, and compaction size is never treated as authority.

For a declarative Stil installation, provenance repair is ordered strictly:
activate or repair the scheduled monitor generation first, replay the monitor
with that generation second, then import, curate, hand off, and derive provider
roles. A one-off newer binary must not race an older timer that can overwrite
`latest.json`. `cityb-biggun living --cityb PATH --require-ready` independently
checks that same chain instead of blessing a merely copied fixture corpus.
Generation-mismatch actions invoke the exact selected Stil frontend rather
than a bare `stil`: the older active frontend is self-consistent and therefore
cannot diagnose whether a newer candidate package should replace it.

Failed listing experiments in `cityb monitor findings` now recommend the
bounded, evidence-scoped recapture command; they never recommend promotion.
Blocking stable/infrastructure failures sort before experiments, the JSON
separates blocking, experiment, and total counts, and the human failure summary
is bounded. Failure classes retained in placement receipts remain available
after redundant raw fixtures are curated.

Every monitor installation should name its evidence boundary with
`--vantage-id HOST --egress-label NETWORK`. Reports, run identifiers, stable
transcripts, and native-candidate transcripts retain both labels; curation
keeps equivalent observations from distinct vantages as distinct facts.
`monitor status` and `monitor nurse` distinguish the configured scope from the
latest completed report scope. A label is provenance, not a claim of
geographic independence. Merge a second operator-owned machine's fixtures
through the normal evidence-sync/curation path before making a multi-ASN claim.

`dead-drop archive preview --input RELEASE` keeps three questions separate:
the presently authorized automatic-role geometry, a prospective geometry that
models repair/recovered providers without authorizing them, and the narrowest
one-root-safe geometry available from the observed provider set. New archive
shards use canonical RFC 4648 Base64 envelopes instead of hexadecimal, cutting
the text-carrier expansion from roughly 2x to 4/3x; readers still accept the
admitted legacy v1 hex envelope. This materially narrows future shards without
reinterpreting old receipts or capacity observations, which remain measured in
actual rendered bytes. Never copy geometry counts from this README: run
`stil providers plan --json` or `cityb dead-drop archive preview --json` for
the current release, provider roles, capacity corpus, and retained topology.
CityB preserves the admitted current generation and prints a capacity proof
command; preview does not silently widen posting authority. Geometry is not
artificially limited to one shard per provider: the bounded codec can place up
to 64 shards across fewer capacity-proven services, while the assignment model
balances retained failure domains before hostname count. The executable
recommendation pins `--archive-role-policy automatic`, requires dated capacity
proof for every assigned service, and uses `--require-root-loss-ready`; plan
creation therefore refuses unknown topology or a generation that cannot
reconstruct after loss of its largest observed failure domain.

The step-by-step soak handoff is [docs/city-b-soak-runbook.md](docs/city-b-soak-runbook.md).

Post-audit correction: the retained current generation has exhausted proven
or uncontradicted outside-AS13335 repair candidates at its present shard width.
Biggun therefore preserves the admitted generation and recommends previewing a
future width/root assignment; it no longer emits an impossible three-receipt
current-generation repair command. The October 20 `p-ip-fi` recapture also
returned exact bytes, so current pointer health is recovered. PasteFox remains
pointer-stable while its archive role stays under repair; Sendit's retained-URL
404 is retrieval/expiry evidence, not upload rejection; FragBin stays suspended.
That audit's dated capability ladder belongs to retained evidence, not to this README. Read the current ladder from `cityb next --json`, `cityb monitor status --json`, or a generated `stil snapshot`; every rung is named so stable membership, pointer exactness, structural compatibility, dated capacity, receipts, and reconstruction threshold cannot be conflated.

`provider health --root ROOT`, `provider explain --root ROOT`, and `provider dossier --root ROOT` read retained archive-spray and adaptive-capacity evidence. `evidence sync --root ROOT` passes the same retained root into provider health; without an explicit root it discovers an existing `./city-b-artifacts`, while copied fixture/state scopes can still be reviewed in isolation when no retained root exists. Archive capacity and current pointer health are independent: a failure above a smaller exact success records a bounded ceiling, while a later pointer-sized failure still degrades current health. Capacity soak targets the current plan's shard width, prioritizes repair providers, and then bisects between the largest proven and smallest failed payload. Capacity-probe v2 verifies the shard-byte digest embedded in the returned shard. The former v1 oracle was impossible; CityB ignores only its mechanically invalid token/checksum failures while retaining real upload, API, and transport refusals. All operator surfaces render `cityb.capability-ledger.v1` in the same order: stable membership, latest pointer exact, structurally archive-capable, currently spray-usable, archive-capacity proven/repair/unproven/recovered, pointer-only, current receipts/assignments, and reconstruction threshold. `cityb next --root ROOT` includes the archive and pointer axes separately so the cockpit cannot hide either form of drift.

Public-anchor intake now also checks source-specific proof fields for CityB-style CT/Rekor/transparency-log and drand anchor documents. The local fixtures under `fixtures/cityb/public-anchors/` cover inclusion, retained consistency linkage, split-view refusal, rollback refusal, and beacon digest checks. `anchor ceremony` is the read-only operator sequence for this area: it prints the durable-source policy command, live drand/Rekor/CT refresh commands, missed-cycle status command, Tiny anchor-resolution command, and `cityb-biggun anchor-amnesia` proof command without reading the network or writing state. `anchor live-drand`, `anchor live-rekor`, and `anchor live-ct` fetch real upstream HTTP transcripts, normalize them into retained CityB public-anchor documents, enforce source/trust-root policy, and record explicit `native_proof_status` fields. Live drand fetches `/info` or accepts an explicit public key, verifies the chained BLS signature for the default `pedersen-bls-chained` scheme, checks that randomness equals the signature digest, and can fail closed with `--require-native-proof`. Live Rekor fetches the public Rekor verification key by default or accepts `--public-key-file`, verifies RFC6962-style Merkle inclusion when the returned entry carries body/proof fields, verifies the signed checkpoint note when present, compares checkpoint root bytes, and evaluates RFC6962 consistency paths when transcripts carry previous tree size/root plus proof hashes. Live CT verifies inclusion when a transcript carries STH root, tree size, leaf hash, leaf index, and audit path; `--public-key-file PEM` verifies RFC6962 v1 `tree_head_signature` bytes, and `--previous-anchor FILE` fetches and requires the log's consistency proof against an already native-verified head. `--require-native-proof` passes only when the STH signature and every supplied consistency path verify. Tiny `cityb-node anchor status|resolve` consumes local/imported retained anchor documents after long amnesia, enforces the same source policy and append-only history checks, optionally requires normalized native-proof status, records `anchor-state.kv`, and surfaces the result through `cityb-node status`. Pointer-chain archive members now also carry retained rendezvous-plan digest, previous archive-root ratchet metadata, Tiny slot-evaluation policy, and missed-ratchet fallback facts; Tiny persists those facts only after archive-chain verification and reports `next_plan_known`, `next_plan_missing`, or `anchor_recovery_required`. `cityb-biggun anchor-amnesia` proves the combined local flow by accepting a native-proof anchor, rejecting an unverified anchor, exporting a Tiny kit from a state-ratcheted retained root, and observing Tiny recover the next-plan breadcrumb from the signed pointer-chain archive member. The October 23 Argon corpus verifies two included leaves, two signed tree heads, and a 28-hash RFC 6962 consistency path; remaining anchor work is richer upstream-root policy, a later same-tree Rekor consistency proof, and more date-separated upstream corpora.

Archive-byte distribution is an operator workflow. `cityb dead-drop archive
refresh --input ARCHIVE --root DIR --service-set free-stable` creates a clean
generation over the current curated snapshot; repeated `--provider
ADAPTER[:ROOT]` remains available for an explicit custom generation. The
planner writes systematic GF(256) shards, assigns them only to native
exact-byte providers when such providers exist, balances provider usage and
topology roots, and uses retained proven payload sizes to order equally loaded
choices. Pointer-only members remain visible in the immutable provider-set
snapshot without receiving an unusable archive shard.

`archive stage` prepares operator-owned packets; `archive spray --apply` posts
eligible shards and retains only exact verified receipts; `archive repair`
preserves the generation while targeting missing assignments outside the
largest received diversity domain and stops when root-loss survival reaches the
threshold. Repair requires dated capacity proof by default; use its explicit
`--capacity-policy prefer-proven` only for an intentional experiment. `archive
plan --capacity-policy require-proven` is the strict next-generation planning
form. It can place multiple independently verifiable shards on one proven
provider, so readiness is counted in assignments and then constrained by the
correlated-root-loss gate—not by pretending that every required shard needs a
different hostname. Add `--archive-role-policy automatic
--require-root-loss-ready` for a production future generation. The default
`prefer-proven` preserves availability while visibly ranking unproven capacity
behind dated proof. `archive receipt`
proves externally posted bytes; `archive status --service-set free-stable`
classifies the plan as current, superseded, or invalid, distinguishes immediate
reconstruction from survival after loss of the largest observed root, and sends
`cityb next` to one specific capacity proof only while an uncontradicted repair
candidate exists. An exhausted generation is reported as constrained with no
fictional immediate command. `archive collect
--require --trust-policy POLICY` reconstructs and admits only a current
generation. A superseded plan can be reconstructable for forensics but never
emits a normal collect recommendation. `cityb release trust init --root ROOT`
persists the allowed-signers file, signer identity, namespace, release
constraints, digest policy, and runtime-match policy, allowing `cityb next` to
print a fully executable collect command with no signer placeholders. Output
is installed only after the reconstructed digest and release policy pass, and
it receives a generation sidecar.

The retained October 13, 2026 proof remains historical evidence: its
then-current 63-provider generation retained 39 verified receipts after 15
archive-sized failures and reconstructed the 5.6 MiB release with SHA3-256
`98a566eb79702d7238c7989f3b76bcc8f31f1284d4b9dbefc91826668bd38ea0`.
It is superseded and cannot masquerade as current adoption evidence. The
October 17 generations are also forensic history. After dated October 18
evidence demoted Dpaste, the signed production ceremony created the admitted
60-provider-set generation as 30 data plus 30 parity shards over a 7.1 MiB
release; `archive spray --apply` posted and verified 42/60 shards at up to
491,939 bytes. Collection reconstructed the exact planned digest, verified
OpenSSH release admission through persisted trust, installed the accepted
archive, and regenerated the field pack and recovery card. The planner now
excludes all nine pointer-only adapters from shard assignment and reports both
capacity proof at the planned width and largest-root-loss survivability.
Pointer-chain members, provider-set snapshots, field-pack
status, recovery cards, collection reports, and accepted release sidecars all
surface generation identity. `archive capacity` and bounded `archive recheck`
turn archive-sized success, failure phase, expiry, and maximum proven size into
standing monitor evidence. `archive encode|reconstruct|inspect` remains the
local codec path, and `cityb-biggun erasure-matrix --json` compares recovery
curves. Provider shards prove availability; signed release admission remains
authority. See the [generation and capacity
lifecycle](docs/city-b-generation-and-capacity.md) for the retained-state
contract and operator commands.

`cityb-biggun provider-reality --archive-evidence-root ROOT` replays retained archive-spray evidence as provider reality instead of assuming a pointer-sized success proves archive capacity. The report counts archive evidence files and records and retains archive successes/failures in provider capacity and retained-risk models. Pointer date streaks remain pointer-only, so a large-shard expiry cannot falsely turn a successful pointer provider red. Use it with checked-in replay fixtures, firehose fixtures, and the retained archive evidence root before changing archive roles after archive-sized drift.

`cityb rendezvous plan --epoch E (--beacon TEXT | --beacon-file FILE)` is the side-effect-free epoch-slot cockpit. It uses the exact same state-ratcheted derivation as `cityb dead-drop schedule`, accepts the prior verified archive root and durable slot metadata, and reports the PRF input digest, concrete selected locations, Tiny evaluation rule, and missed-ratchet fallback without writing state. Its `next_action` is the exact `dead-drop schedule` command that persists the preview; `--root` names that destination. Epoch arguments on other rendezvous modes fail as usage errors instead of being accepted as future grammar. The CLI parser likewise owns boolean/value arity at each command boundary, so reused names such as `--plan` no longer depend on one global guess table.

Native candidate probes are the bridge between the staged 260-provider pool and real adapter benches. `cityb provider candidates plan --json` marks candidates that have a provider-specific probe, and `cityb provider candidates test --provider PROVIDER --live --json` classifies those candidates without changing `free-stable` or `free-wide`. AISense Temporary Storage, Kawaii Files, temp-files, Tempcloud, tmp0.cc, and beacon.host now have production exact-byte adapters and stable membership; Bashupload and Stashr also have production adapters but are back in `free-wide` after repeated dated stable failures. EasySend, dropfile.dev, Warpbox, upload.83blue, pomf2/lain, isrv.nl, fsend.me, pb.plz.ac, paste.gg, AnonHost, readm3, MDShare, dpaste.com, mystb/Pastey, ship.page, shipsite.co, Capsule, Pastebin1s, Webionite Bin, hastebin.cc, paste.ivr.fi, PasteShare, Kodi Paste, PastyX, WaifuVault, ShareY, MSK Paste, dpaste.org, Python Discord Paste, and SquadRoom Paste now have October 13 exact-byte native-candidate evidence. Savedly, File2Share, PasteMyst, AnonPaste Lite, Telegraph, Laravel Paste, Buzzheavier, FuckingFast, bzzhr.co, pste.us, Skunk Paste, paste.aaqa.dev, 0807.st, Pixeldrain, paste.hep.gg, MantleDB, SuperJSONBlob, ExtendsClass JSON Storage, Keyval, ntfy.sh, Webhook.site, Botoi Paste API, Botoi Webhook, FilePost, Guerrilla Mail, GrabMail, Mail.gw, Mail.tm, Maildrop.cc, MeowMail, NenzMail, 1secmail, shitty.email, Smails, and TempY.email have native probes too, but their observed behavior is non-exact, rendered-token-visible, normalized-field exact (for the five production JSON-field adapters), token-only, normalized cached-event (for ntfy), webhook-JSON, API-key-gated, receive-only temp-email, public-mailbox-list, gateway-error, domain-list-only, inbox-list-only, app-shell, rate-limited, expiring-inbox, message-list, challenged, proof-of-work, or auth/captcha-required, so only the separately labeled normalized-field adapters have entered `free-wide`; raw-body stable and archive admission remain gated. The EMQX, HiveMQ, and Mosquitto public brokers now add exact retained-publish/fresh-subscribe MQTT candidate evidence, but remain ephemeral event lanes rather than archive or stable providers. Damus, nos.lol, and Primal add native NIP-01 signed-event publish/ack/read probes with best-effort NIP-09 deletion requests; a first manual pass returned exact content from all three, while the later standing-monitor pass recorded a Damus acknowledgement failure and exact nos.lol/Primal delivery; they remain public discovery candidates because relay retention and deletion are policy-dependent. The NATS public demo adds a separate exact Core NATS live publish/subscribe probe; its at-most-once delivery is useful heartbeat/event evidence but deliberately provides no retained rendezvous claim. Four IPFS public gateways add read-only known-CID retrieval probes: Pinata, Filebase, and 4EVERLAND recovered the fixed raw specification block exactly on their latest manual pass while the Foundation endpoint returned HTTP 521; none publishes, pins, or counts as an archive root. The October 20 tranche also adds exact first-pass shz.al raw-body evidence; exact first-pass signed-event evidence from the nostr.net, Snort, and Wellorder relays; an Eclipse MQTT timeout; and explicit key-gate classifiers for Simply Linux Paste and Thpaste. All nine run in the 118-probe monitor tranche and remain candidate evidence until their lane-specific gates are earned. The same monitor also runs the shiftr.io exact MQTT path, the flespi token gate, three additional exact Nostr relay paths, Bluesky Jetstream receive-only firehose scout, and four exact known-transaction Arweave gateway scouts; only shiftr.io and the Nostr relays produced generated-payload exactness, while the others retain their narrower credential-gate or receive-only classifications. Npoint, JSONBin.io, JSONStorage.net, JsonBlob, and webhooks.sh now have classified server-error, API-key, Cloudflare, or viewer-key-required transcripts that are useful for future adapter repair but not stable admission. Capsule is still a watch/onboarding case because the same day also contains earlier token-missing receive evidence. Fileditch, Gofile, Oshi.at, put.re, sto.care, take-me-to.space, fars.ee, Pastebox-family services, Pastepile, Marke.st, PasteDB, Paste.org, Skyra Hastebin, Denizen Pastebin, transfer.sh, ix.io, sprunge.us, paste.0xfc.de, paste.codenerd.com, SSHGrid, ShareNation, Originless, 1c3.ir, sharey.gay, tempditch.com, envs.sh, ttm.sh, and stale public Haste instances remain candidate-probe, near-miss, or negative-evidence cases. [city-b-provider-near-misses.md](docs/city-b-provider-near-misses.md) keeps the adapter-worthy-but-not-yet-clean list. `cityb provider health --service-set free-candidate-pool` and `cityb provider promotion-board --service-set free-candidate-pool` keep remaining candidate evidence visible in the normal operator inbox.

Web adapters use ordinary curl by default, with provider-specific methods,
request bodies, parsers, limits, and exact receive probes. Set
`CITYB_HTTP_TRANSPORT=firefox` or `chrome` to select the pinned Nix
curl-impersonate transport for an explicit comparison run; packet evidence
records the selected profile. CityB does not silently retry challenges through
a different fingerprint. See
[the adapter transport contract](docs/city-b-real-service-adapters.md#http-transport-profiles).

`cityb rendezvous firehose-fixture` checks `fixtures/cityb/rendezvous-firehose/` as a local parser contract: expected placements, extracted candidates, checksum-valid tokens, false-positive candidates, parser encoding distribution, and `--require` failure all happen without public network access. `cityb rendezvous promote-firehose --service SERVICE` is the read-only listing promotion gate: it checks service-specific date-separated fixtures, checksum-valid tokens, rejected false-positive candidates, provider-specific cursor/expiry behavior, and the Biggun parser-diff proof by default unless `--no-parser-diff` is explicit. A listing provider is not promoted into Tiny sweeps until date-separated fixture evidence and parser agreement are both clean and the service is intentionally declared as a retained-local sweep provider. Pastebin Archive, GitHub public Gists, and Pastefy currently report `tiny-sweep-promoted`. FragBin retains its parser, historical fixtures, and low-rate monitor recheck, but its Tiny declaration is suspended after HTTP 500 listing failures on October 17 and October 18; a later exact recovery and source review are required for re-admission. Pastefy's October 18 and October 20 captures prove the same bounded, multi-megabyte, pagination-resistant full-content response; its Goldilocks collector uses provider-specific 8 MiB/4,096-candidate bounds, while Tiny only consumes the retained local token projection and never retains or fetches arbitrary listing bodies.

`cityb rendezvous collect-firehose` is the bounded listing reader surface; it is dry-run unless `--apply` is explicit, requires page, byte, candidate, retry, and backoff budgets, fetches only a declared `--source`, classifies timeout/rate-limit/challenge/provider-error failures, and writes safe `cityb.rendezvous-observation.v1` facts only when a retained `--root` is supplied. With `--root`, or with an explicit `--cache FILE`, it keeps a bounded `city-b-firehose-seen-cache.json` of listing digests, checksum-valid token hashes, cursor capture status, and last-source facts; `--reset-cache` starts a new local cache without changing public services. Provider-specific retention may be narrower than the byte budget: Pastefy's oversized public body is parsed in memory but is not retained as an object. `pastebin-archive` proves `html-public-archive-table` rows, `single-recents-page-no-cursor`, relative posted ages only, and token-only receive behavior. `github-gists-public` proves unauthenticated JSON listing reads, captured Link-header page cursors, `updated_at` rows, and token-only receive behavior. FragBin's October 7 and October 10 corpus remains useful parser evidence for `page`/`limit`, `createdAt`, and no observed next cursor, but later live availability now blocks promotion. Tiny consumes only promoted providers through retained local listing-object directories after the pointer-chain member is verified by archived acts; it still does not scrape public web pages directly. `cityb-biggun parser-diff` uses the same source-tree and release-tree provider and firehose fixture discovery unless `--no-fixtures` is explicit. It keeps every fixture as evidence but bounds execution to the newest routine body per provider/encoding plus every named drift, malformed, rendered, redirect, noisy, screenshot, and OCR class; its JSON states how many records were seen, selected, and deduplicated.
Runnable local-proof, free-stable, free-five, free-deep-10, free-deep-text-10, free-deep-web-10, free-deep-web2-10, free-deep-web3-10, free-deep-web4-10, free-deep-web5-10, and cursor-listing examples live under
`fixtures/cityb/free-service-replay/`. Plans subtract only fresh verified
coverage, decay old observations, classify provider-health failures, raise
rotation pressure for stale or failed services, and enforce both per-service
and per-correlated-root request budgets before scheduling additional posts.
Provider expansion is Rust-owned too. `provider summary` reports the
260-provider candidate queue, `provider catalog` and `provider candidates list`
filter it by family, adapter, provider, or status, `provider candidates plan`
ranks behavior-diverse evidence tranches and surfaces the newest staged batch first, `provider candidates capture`
prints a retained-root/deployment/recipe/fixture-template plan for one selected
provider without remote mutation, `provider candidates promote` records the
native-adapter-required checklist without editing source, and `provider health`
turns observed service reality into an operator triage queue.
Provider health triage rows include `decision_state` and `evidence_gate` fields so wrappers can show promotion, demotion, recapture, listing-firehose, and watch decisions without reverse-engineering prose.
[docs/city-b-free-provider-candidates.md](docs/city-b-free-provider-candidates.md)
and [docs/city-b-provider-expansion-plan.md](docs/city-b-provider-expansion-plan.md)
describe how to promote a candidate without confusing research breadth with
stable receive evidence.
Tiny writes generation-numbered checkpoints with a previous-generation
fallback, persists a field-mode write-budget report, and reports the
deployment digest, listener-plan digest, shared parser version, and field-mode
state it was provisioned from. If `status.json` is lost or stale after an
interrupted final write, `serve` and `status` use the newer current or previous
checkpoint for runtime phase, hysteresis, and fetch-budget state while keeping
the authoritative reboot floor in `floor.kv`; checkpoint-sourced dashboards are
marked as incomplete recovery evidence. Process-level Tiny fixtures inject
atomic-write failures before temp-file creation, before byte write, and before
rename across provision files, current/previous checkpoints, `status.json`, and
`field-mode-report.json`, then restart from the same state directory. They also
exercise actual read-only state-directory failures and a real tmpfs-full write
failure when the host permits unprivileged mount namespaces. `cityb-biggun guide` is the amnesia-safe maintainer card for future agents: it names the safe run order, mutation posture, and failure-response branches without reading retained state. `docs/city-b-maintainer-playbook.md` is the longer handoff guide for cost tiers, provider-evidence discipline, and change-type checks. `cityb-biggun living` is the read-only monitor-state report: it reads the retained provider-monitor state directory, counts reports, detects pending evidence imports, summarizes the latest run's capture/firehose/candidate-probe steps, reports latest-report mtime/age, optionally marks the monitor stale with `--max-report-age-hours`, and prints the next maintainer command without running public-service probes. `cityb-biggun truth` is the maintainer cockpit: `--plan` names the evidence stack without running it and reports `next_command`; `--run --quick` executes the fast local stack including `living` without public-service mutation and reports failed-step/next-action fields; `--run --deep` adds parser-diff and anchor-amnesia; and `--run --full` adds the standalone quick selftest. Biggun can
diff Goldilocks and Tiny parser output over identical generated carrier files
plus checked-in provider fixture bodies wrapped as raw text, HTML, malformed
HTML, and OCR-ish noise, and can replay the retained cycle history plus collector
probe receipts, fixture
replays, redirect/status buckets, cursor reports, provider-health buckets, and
correlated-root collapse in otherwise valid runs, exposes a target matrix
for x86-64, aarch64, and the Tiny ARMv7 check target, and owns the retained
`selftest` proof that composes the three binaries without public-service
mutation. The full retained `exercise` stress proof is opt-in for tests and
deliberate operator runs; it is not part of the default focused maintainer test
path. Use `cityb-biggun selftest --quick` for the shortest no-degradation
local proof, default/`--full` for the full negative-lane proof, and
`--release` when the exact binaries under `target/release` should be checked
instead of PATH/debug selections. `cityb-biggun gate` is the Rust-owned local
readiness recipe: quick mode runs format, workspace check, binary integration
test, binary build, standalone selftest, and `git diff --check`; `--full`
promotes the test/doc depth; `--release` adds release-binary archive/verify;
`--target-check` adds the local cross-target matrix. When `gate` chooses its
default `target/cityb-biggun-gate/run-*` work directory, it retains only the
newest five generated runs; an explicit `--work-dir` is operator-owned and is
never pruned. Foreign entries under the default retention root are left alone.
The live-service smoke
script is a compatibility wrapper over `cityb capture`. It still self-skips
unless `CITYB_LIVE_FREE_SERVICES=1` is set, but new operator work should use
`cityb monitor install --live --enable-now` for continuous machine evidence,
`cityb monitor status` for the latest retained report, `cityb capture free-wide --live --min-passed 8` for a manual broad pass, or
`cityb capture free-deep-10 --live --require-all` for the ten-provider research
bench, `cityb capture free-deep-text-10 --live --require-all` for the
ten-provider text/paste research bench, `cityb capture free-deep-web-10 --live --require-all`
for the web paste/file research bench, `cityb capture free-deep-web2-10 --live --require-all`
for the second web/API bench, `cityb capture free-deep-web3-10 --live --require-all`
for the third web/API bench, `cityb capture free-deep-web4-10 --live --require-all`
for the fourth web/API bench, or `cityb capture free-deep-web5-10 --live --require-all`
for the fifth web/API bench. Set `--adapters
"paste-rs dpaste"` for a narrow run, `--require-all` for strict provider
diagnosis, and `--capture-dir DIR` to retain the raw transcripts.

See [docs/city-b-operator-distribution.md](docs/city-b-operator-distribution.md) for the practical operator guidance on improving command distribution while minimizing personal, device, account, schedule, and network metadata in carrier payloads and receipts.

## Standalone identity

This directory is maintained as a CityB-first workspace. The default Nix
app is `cityb`; package builds publish `cityb`, `cityb-node`, and
`cityb-biggun`. The explicit repository-local Nix package/app `stil` is m21's
personal resident office over the two larger surfaces, not CityB's public
product and not a fourth Rust binary. Its internal compatibility wrappers are
reached through the explicit `.#stil` package rather than advertised as public
flake apps. Tiny remains addressed through `.#cityb-node`. `cityb
release archive` builds a local release archive with
per-binary `version --json` and `capabilities --json` files, the checked-in
free-service replay corpus, the root README, CityB-only docs, the public CityB
NixOS module and examples, and SHA3-256 manifests. It excludes Stil and
repository-local Monsternix admission metadata; `--plan` reports the paths
without building or writing, and
`--signature-policy require-present` records the intended detached-signature
expectation in the archive plan/manifest while leaving enforcement to
verification surfaces. `cityb release ceremony` prints the dry-run-first archive, `SHA3SUMS` signing, OpenSSH verification, field-pack admission, and deployment-policy sequence so release adoption does not depend on remembered flags. `cityb release sign SHA3SUMS --signing-key KEY --apply` signs through `ssh-keygen -Y sign`, installs `SHA3SUMS.sig` into the release directory, transactionally reseals the distributed archive, recomputes its SHA3-256, and updates the external manifest; without `--apply` it reports the exact payload digest, signature path, signing command, and verification command without writing. `release archive --binary-dir DIR` packages three reviewed binaries without rebuilding different bytes. `cityb release verify DIR_OR_TAR_GZ` checks an unpacked
release directory or archive by
preflighting archive member names/types before extraction, validating the
manifest, running each binary's version surface, running each binary's
capability surface, confirming that both the offline fixture corpus and the
operator/developer docs and MIT license are present, and reporting detached `SHA3SUMS.sig`
presence and verification status. Verification uses an immutable release-format
baseline plus the artifact's own signed `SHA3SUMS`; growth in today's evidence
corpus cannot retroactively invalidate an older correctly signed release.
Detached signatures are optional by default; use
`--signature-policy require-present` or `--require-signature` when an unsigned
artifact must fail verification. Use `--signature-policy require-verified
--signature-verifier ssh --allowed-signers ALLOWED_SIGNERS --signer-identity
ID` when `SHA3SUMS.sig` must pass OpenSSH detached signature verification over
`SHA3SUMS`; `--signature-namespace` defaults to `cityb-release`. A present
signature without a verifier remains `present-unverified`. A deployment may
also bind field-pack admission to saved release verification facts with
`release_manifest = "./release-verify.json"` and
`release_signature_policy = "require-verified"`; richer admission fields can
then restrict accepted signer identities, signature namespaces, versions,
architectures, operating systems, archive SHA3-256 digests, and runtime
binary/deployment matches. CLI flags still override those deployment defaults.
`scripts/release-cityb-archive.sh` remains a legacy convenience, but the Rust
binary is the canonical standalone packaging surface. Neither path publishes,
uploads, starts services, reads credentials, or modifies monsternix.
All three `version --json` surfaces include source revision, semantic build
identity, invoked-artifact SHA3-256, provider-set generation, and release
identity in addition to version/platform/role. Monitor binary comparison uses
the semantic build identity, so a Nix wrapper around the same build is not
misreported as an unexplained replacement. The flake exports
`nixosModules.default` and `nixosModules.cityb` for bounded monitoring, local
evidence intake, scheduled Biggun truth checks, the correspondence gateway,
relay soaking, and Tiny status capsules. Public provider mutation is off unless
`services.cityb.monitor.live = true`. The module defaults to a dedicated
`cityb` system identity and `/var/lib/cityb`; adopting an existing home-retained
root requires `createUser = false` and `allowHomeState = true`. It rejects dual
evidence writers and incomplete gateway declarations, records exact
package/source/release identity in `/etc/cityb/runtime.json`, establishes mount
dependencies for declared paths, and applies a no-capabilities/read-only-system
hardening base. The explicit `nixosModules.stil` export remains solely for
m21's personal resident office.
The public `cityb system doctor` also verifies that the invoking Goldilocks
binary and every loaded unit's `ExecStart` resolve to that descriptor's exact
package. `cityb system status|timers|logs` provide bounded inspection, while
`cityb system run|stop|restart ROLE` permits only roles declared by the active
module generation.
`cityb-biggun targets --check` is the Rust-owned local target gate: it runs the
native workspace check, runs installed cross-target checks, skips missing cross
targets in default mode, and treats missing targets as failures under
`--strict`. It remains compile/check evidence only, not ARM runtime proof.
`cityb-biggun gate` is the Rust-owned local readiness gate for source, binary,
selftest, optional target, optional docs, and optional release-archive proof.
The machine-readable handoff candidate for a future monsternix experimental
toolset is `packaging/monsternix/cityb.experimental-toolset.json`; it is
metadata only and does not modify monsternix, start services, create state,
read credentials, or authorize public posting by itself. That handoff now names
the single Nix automation object separately from the three public binary apps.
