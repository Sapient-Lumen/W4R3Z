# Contributing to CityB

CityB is a three-binary Rust product with one public NixOS automation module.
Keep changes inside the authority split documented in `README.md`: Goldilocks
operates, Tiny verifies and receives, and Biggun tests hostile assumptions.

Before submitting a change:

```sh
nix fmt -- --check flake.nix nix/cityb-module.nix nix/examples/*.nix
nix develop -c cargo fmt --all --check
nix develop -c cargo clippy --workspace --all-targets -- -D warnings
nix flake check
```

Use focused Rust tests while developing, then let `nix flake check` prove the
packaged binaries, release plan, static portable artifacts, NixOS module,
evidence content-addressing, and retained personal compatibility objects.

Provider changes require dated evidence. A service working once is not enough
for `free-stable`; preserve exact-byte fixtures, failure phase, payload size,
retention observations, vantage label, and topology facts. Live provider
mutation must remain explicit. Tests and documentation must not contact public
services merely because a module or package was evaluated.

Do not commit credentials, private correspondence keys, operator recovery
material, retained deployment roots, build outputs, or machine-local export
markers. Release archives must include `LICENSE`, `RELEASE-ID.json`,
`SHA3SUMS`, the three binary identity reports, the offline evidence corpora,
and the public CityB module. Stil is m21's explicitly named personal object;
new public operator behavior belongs in CityB itself.
