# CityB security policy

CityB is pre-1.0 software. The current `0.1.x` line receives security fixes;
older source snapshots and unsigned release archives are not supported.

Report a suspected vulnerability privately through the security-advisory or
private-reporting facility of the repository host before opening a public
issue. Include the affected source revision, binary `version --json` output,
the smallest reproducer that preserves the failure, and whether the problem
can expose signing material, admit an unauthorized archive, bypass a replay or
generation fence, or cause unintended provider mutation. Do not include live
credentials, node private keys, operator recovery material, or third-party
service secrets.

CityB's security claims are intentionally narrow:

- carrier bytes are untrusted until schema, digest, chain, signature, and
  deployment-policy checks succeed;
- importing the NixOS module does not enable live provider mutation, public
  listeners, correspondence, or firewall openings;
- `cityb-node` shares the host kernel and is not a VM, malware sandbox, or
  whole-disk containment boundary;
- free public providers, DNS, CDNs, clocks, and network paths remain external
  failure and observation domains;
- an unsigned artifact or a signature that is merely present but not verified
  is not a production release admission.

See `docs/city-b-governance-spec.md`, `docs/city-b-standalone.md`, and
`docs/city-b-readiness-reconciliation-and-recovery.md` for the protocol,
release, and operator contracts.
