# City B hook model

This document defines the ideal contract for City B encoding, placement, and
probe hooks.

The separation is strict:

- encoding hooks decide representation;
- placement hooks decide explicit mutation;
- probe hooks decide what was actually observed afterward.

They must not bleed into each other.

## One-line rule

Encoding is pure.

Placement is explicit.

Probe is skeptical.

## Encoding hooks

Encoding hooks transform canonical City B material into carrier-shaped bytes.

They should accept:

- canonical material kind: `pointer`, `archive`, `receipt`, `heartbeat`, or
  `route-hint`;
- placement envelope;
- adapter capabilities;
- size/shape constraints;
- operator policy profile.

They should return:

- encoded bytes or text;
- encoding identifier;
- parse strategy;
- content length;
- human-copyability facts;
- OCR-tolerance facts;
- exact-vs-lossy decode claim;
- reserved extension-hook capability flags;
- narrow operator note.

Ideal properties:

- deterministic by default;
- explicit non-determinism only when a profile requests it;
- same canonical material under multiple carrier-native encodings;
- no network I/O;
- no filesystem mutation;
- no provider selection;
- no trust decision.

In code terms:

```text
encode(material, envelope, adapter_caps, policy) -> EncodedPlacement
decode(observation_bytes, parse_strategy) -> CandidateMaterial
```

## Placement hooks

Placement hooks are the mutation seam.

They should accept:

- encoded placement output;
- explicit target;
- adapter configuration;
- idempotency or replay key;
- operator policy gates.

They should return:

- placement receipt;
- exact written/published target identifiers;
- mutation mode;
- provider class;
- target kind;
- named failure on refusal.

Ideal properties:

- no implicit provider discovery;
- no silent fallback target;
- explicit local/manual/remote posture;
- idempotent behavior where practical;
- dry-run and stage-only friendly;
- receipt-first design.

In code terms:

```text
validate_target(target, adapter_config) -> ok | named failure
stage(encoded, target) -> StageReceipt
commit(stage_receipt) -> PlacementReceipt
cleanup(placement_receipt) -> CleanupReceipt
```

## Probe hooks

Probe hooks are read-only observation and verification.

They should accept:

- explicit target or prior placement receipt;
- expected material identity;
- probe policy.

They should return layered facts:

1. `reachable`
2. `retrievable`
3. `parseable`
4. `digest_match`
5. `policy_fresh`
6. `usable`

They should also return:

- probe kind;
- named failure;
- any normalized note needed for operator review.

Ideal properties:

- read-only by default;
- layered rather than binary;
- distinguishes “I connected” from “the content is correct”;
- distinguishes “content is correct” from “content is still policy-fresh”.

In code terms:

```text
probe(target_or_receipt, expected, policy) -> ProbeReceipt
observe(raw_source, expected) -> ObservationReceipt
```

## Normalized receipt minimum

Every adapter-facing receipt should be able to carry at least:

- `adapter_id`
- `provider_class`
- `mutation_mode`
- `target_kind`
- `material`
- `encoding_id`
- `parse_strategy`
- `expected_digest`
- `observed_digest`
- `status`
- `failure_name`
- `timestamp`
- `extension`

Not every current City B receipt uses every field yet, but the seam should be
ready for them.

## September 1, 2026 implementation status

City B now exposes this model in the CLI and receipts:

- `cityb dead-drop adapter catalog`
- `cityb dead-drop adapter init --root DIR`
- `cityb dead-drop adapter doctor --root DIR`

The `local-file` and `manual-drop` adapters now prove the separation in code:

- encoding hook: prepares carrier-shaped local content plus parse metadata;
- placement hook: either writes only to the explicit local target or stages an
  operator publication packet under an explicit local target;
- probe hook: records layered same-host observation facts for local-file and
  “awaiting operator publication” staged facts for manual-drop in normalized
  placement receipts; observation receipts remain read-only verification of real
  imported content.

`static-http` now proves the third posture:

- encoding hook: reuses the same canonical carrier shaping as local doubles;
- placement hook: writes only into an explicit operator-owned docroot and
  derives the public URL only from an explicit `--base-url`;
- probe hook: performs a read-only HTTP fetch of that exact URL, compares the
  served bytes against the prepared content, and records named failures such as
  `fetch-failed`, `http-body-mismatch`, and `http-token-missing`.

`filehost-generic` proves the fourth posture:

- encoding hook: reuses the same canonical carrier shaping again;
- placement hook: stages a deterministic upload packet under an explicit local
  target and never assumes the remote host path grammar;
- probe hook: becomes active only when the operator supplies an exact
  `--download-url`, then performs the same read-only HTTP byte comparison
  against that explicit URL.

`git-release-generic` and `object-store-generic` now prove the same explicit
remote-upload pattern under different operator surfaces:

- both stage deterministic local upload packets first;
- both refuse to infer remote path grammar from repository, release, bucket, or
  object naming conventions;
- both activate the probe hook only when the operator supplies one exact
  `--download-url`.

`github-release`, `gitlab-release`, and `netlify-drop` now prove the next
promotion tier:

- all three keep mutation operator-owned rather than pretending City B can
  safely own account, tag, release, or UI choreography;
- all three still stage deterministic local packets and provider-specific
  operator guides in core;
- all three activate the probe hook only when the operator supplies one exact
  final public URL.

`filebin`, `paste-rs`, `dpaste`, `paste-c-net`, `nullpaste`, `0x0`,
`catbox`, `litterbox`, `tmpfiles`, `sendit`, and `temp-sh` now prove the
built-in public-service adapter postures:

- all reuse the same canonical carrier shaping;
- all stage a local packet directory before mutation so review and replay stay
  inspectable;
- all perform the upload in Rust and normalize the returned public
  location into ordinary receipt fields;
- both immediately probe that location and convert service quirks into named
  failures.

`plugin-external` still proves the generic service-adapter seam itself:

- it stages a deterministic plugin packet under an explicit local target;
- it optionally executes one explicit local executable from `--plugin-command`
  using a fixed argv/env contract rather than a shell snippet;
- it accepts normalized probe facts on stdout and converts them into ordinary
  City B placement/distribution receipts.

More service-specific adapters are still planned. That is deliberate. The seam
now exists both as built-in code for public services, staged operator-owned
paths, exact-location collection probes, and a generic executable escape hatch
for the rest.

`cityb collect probe` is the exact-location normalized probe hook outside
immediate post/probe receipts. It fetches only operator-supplied URLs or files,
parses with the same shared pointer registry used by Goldilocks and Tiny,
records whether the selected encoding survived, retains the raw carrier bytes,
and writes one reliability observation for later planning. This gives the
receive plane a useful external-service proof without conflating it with
discovery.

`cityb collect cursor` is the first discovery hook. It fetches one
operator-declared listing URL or file, retains those raw listing bytes, extracts
exact candidate URLs or local paths, probes only those candidates, and commits a
service/lane cursor report after the probe receipts and reliability rows exist.
It is a bounded listing transaction, not a crawler. The hook is now
service-mode aware: local lists, static indexes, provider JSON fields,
gist/snippet raw URLs, release assets, returned-URL-only services, plugin
cursors, and non-enumerable services are reported differently. That distinction
is operationally important because a real empty static index, a stale returned
URL list, and an intentionally non-enumerable service imply different next
actions. The hook still preserves room for format-preserving placement
metadata and provider-specific parser modules without letting a carrier decide
archive authority.

## Probe semantics

Probe hooks report layered facts, not one universal truth bit.

- `reachable`: the adapter could contact the target surface.
- `retrievable`: bytes came back.
- `parseable`: the returned bytes still contain material that the declared parse
  strategy can recover.
- `digest_match`: the probe-specific byte identity check passed when the probe
  had enough information to make one.
- `policy_fresh`: reserved for freshness and rotation-aware probes.
- `usable`: the adapter-specific minimum for “this location is presently good
  enough to rely on” passed.

For `static-http`, `digest_match` is the exact byte comparison between the
prepared carrier body and the served HTTP response body. Archive verification
remains the separate `verified` field in receipts.
