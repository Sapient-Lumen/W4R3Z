# CityB maintainer playbook

This playbook is for a maintainer or agent who wakes up without the full project context. It explains the safe order of operations, the checks that are cheap enough for ordinary turns, the checks that require deliberate time, and the handoff facts the next maintainer needs.

## First ten minutes

Start with read-only facts:

```sh
git status --short
cityb-biggun guide
cityb-biggun living --max-report-age-hours 24 --json
cityb-biggun truth --plan --json
cityb-biggun truth --run --quick --json
```

If using the packaged Nix surface, run the same sequence through the native
Biggun app:

```sh
nix run .#cityb-biggun -- guide
nix run .#cityb-biggun -- living --max-report-age-hours 24 --json
nix run .#cityb-biggun -- truth --plan --json
nix run .#cityb-biggun -- truth --run --quick --json
```

The first pass should answer four questions: what changed in Git, whether retained provider-monitor evidence is fresh, whether Biggun's cheap local truth stack agrees, and which command Biggun says to run next. Do not start by running live captures, provider promotions, archive spraying, or the retained full exercise unless the operator explicitly wants that heavier activity.

## Cost tiers

Use the smallest proof that matches the change:

| Tier | Command | When to use |
|---|---|---|
| Read-only orientation | `cityb-biggun guide` | Always safe; no state reads, no network, no mutation. |
| Living monitor view | `cityb-biggun living --max-report-age-hours 24 --json` | Provider evidence work, adapter decisions, or any turn after monitor/fixture changes. |
| Quick truth | `cityb-biggun truth --run --quick --json` | Routine source/docs changes and fast confidence. |
| Deep truth | `cityb-biggun truth --run --deep --json` | Parser, Tiny receive, anchor, provider corpus, pointer format, or amnesia work. |
| Local gate | `cityb-biggun gate --quick --json` | Before handing off a coherent implementation change. |
| Full truth/selftest | `cityb-biggun truth --run --full --json` or `cityb-biggun selftest --quick --json` | Pre-release or when the three-binary retained workflow needs proof. |
| Full retained exercise | ignored Rust test or `cityb-biggun exercise ...` | Stress proof only; expect a long local run. |

The default `cargo test -p cityb-lab --test biggun_binary` intentionally skips the full retained `exercise` stress proof. Run the ignored test explicitly only when the host has enough time:

```sh
cargo test -p cityb-lab --test biggun_binary \
  biggun_exercise_writes_goldilocks_checkpoints_into_recovery_summary_json \
  -- --ignored --nocapture
```

## How to read Biggun next-action fields

`cityb-biggun truth --plan --json` reports `next_command` and `next_reason`; this is the safest command to run after reviewing the plan. `cityb-biggun truth --run ... --json` reports `failed_steps`, `first_failed_step`, `next_command`, and `next_reason`; when a step fails, `next_command` is the failing command rendered exactly so a maintainer can rerun it alone.

If quick truth succeeds, the next useful widening is usually deep truth. If deep truth succeeds, its emitted command runs the exact sibling product doctor; a source maintainer should then run `cityb-biggun gate --quick --json` from the pinned development shell before handing off a code change. If a truth step fails, do not widen the tier first; inspect that named step and its stdout/stderr excerpt.

## Provider evidence discipline

Provider evidence is empirical, dated, and allowed to drift. A service is not stable because it worked once, and a service is not necessarily dead because one date failed. Use retained monitor evidence, retained archive-spray evidence, provider dossiers, patch plans, and Biggun provider-reality replay together.

When `living` reports `import-pending`, import retained evidence before making catalog decisions:

```sh
cityb evidence sync --apply
cityb evidence curate --json
cityb evidence curate --apply --json
cityb-biggun living --max-report-age-hours 24 --json
cityb-biggun truth --run --quick --json
```

When `living` reports `stale`, refresh or inspect the monitor before promoting or demoting providers:

```sh
cityb monitor nurse --json
cityb provider health --json
```

When `living` reports `latest-failed`, inspect the named failed step and provider health before changing lanes. Prefer repair/demotion decisions backed by repeated date-separated evidence.

When `cityb-biggun provider-reality --json` reports `archive_spray_readiness.status = spray-ready-sustained`, the checked-in corpus has enough live archive-shard eligible exact-byte providers on the latest dated evidence row for the requested archive-shard threshold. This is stricter than pointer evidence: `latest_live_exact_ineligible_provider_names` names exact-byte carriers that remain useful for discovery or staged/manual workflows but must not count toward automatic archive spraying. Add `--archive-evidence-root ROOT` when a retained archive-spray proof exists; Biggun then replays actual archive-sized per-provider success/failure records instead of inferring capacity from pointer fixtures. Also inspect `archive_loss_model`: it replays the latest live-exact provider set as one shard per provider against every dated evidence row, separates failed providers from unknown/unobserved providers, reports whether the modeled plan reconstructs, and prints the matching dry archive-plan command. This is not adoption authority; it only says provider-backed archive spraying is empirically plausible. Treat `recovered-watch` as "old failure preserved, later exact-byte evidence exists", archive-sized one-day failures as "recapture before demotion", and `mixed-watch` as "inspect before promotion or demotion"; do not collapse them into the same operator decision.

## Change-type checklist

For docs-only updates, run formatting-sensitive checks that match the touched files and at least `git diff --check`. If Biggun command grammar or operator claims changed, also run `cityb-biggun guide`, `cityb-biggun truth --plan --json`, and the focused Biggun binary test.

For Biggun code, run:

```sh
nix develop -c cargo fmt --all --check
nix develop -c ./scripts/lint.sh
nix develop -c cargo check -p cityb-lab --bins
nix develop -c cargo test -p cityb-lab --test biggun_binary
git diff --check
```

`scripts/lint.sh` is the repository-wide warning gate: formatting plus Clippy
over the whole workspace, all targets, and all features with warnings denied.
Run it for ordinary Rust changes, not only Biggun edits.

For Nix wrapper or automation-package changes, also run the affected wrapper and automation probe:

```sh
nix run .#cityb-biggun -- guide --json
nix build .#checks.x86_64-linux.stil-probes
```

For parser, provider corpus, anchor, or Tiny receive changes, add deep truth:

```sh
cityb-biggun truth --run --deep --json
```

For release/archive/signature surfaces, include release-plan or release-verify fixtures and update the current-state docs in the same change.

## Handoff standard

A good handoff names the commit, the exact commands run, any ignored heavy proof not run, any retained monitor state that was stale or missing, and the next command Biggun printed. If the turn changed non-trivial behavior, add an Agent Note under `.agents/notes/implemented/maintenance/` or the nearest matching category.

Never commit credentials, live provider secrets, raw API keys, or unexplained public-service mutation artifacts. Keep provider captures as evidence fixtures only when they are meant to be retained and reviewed.
