# CityB generations, release trust, and archive-capacity lifecycle

This document defines the retained-state contract for provider-backed archive
distribution. It is an operator contract, not merely an implementation note.

## One generation, one set of facts

An archive generation binds the signed archive digest, complete provider-set
digest, concrete shard-assignment digest, service-set name, data-shard count,
and parity-shard count. The resulting
`generation_id` is carried by the distribution plan, shard receipts,
archive-provider evidence, reconstruction report, generation manifest,
pointer-chain member, field-pack status, and recovery card. A provider-set
snapshot is represented by the plan's complete `provider` rows and
`provider_set_sha3_256`; it is not inferred from whichever providers happened
to receive a shard. The provider-set digest binds stable membership and the
declared provider root. Dated topology observations are pinned separately in
the concrete assignment digest. A later DNS/ASN/CDN observation may improve
future assignment, but it cannot retroactively supersede a plan whose provider
membership is unchanged.

Assignment is provider-distinct, topology-aware, and capacity-aware. Among
automatic exact-byte adapters the planner first prevents provider reuse while
an unused live-exact provider remains, then minimizes retained effective
failure-domain use and declared carrier-family use; dated capacity at the
planned shard width breaks ties inside that class. Once every provider has a
shard, the same topology and capacity ordering controls unavoidable reuse.
This preserves carrier diversity instead of making one service carry several
shards merely to flatten an ASN histogram. Plan JSON records the largest
assigned failure domain, its shard count, survivors after losing it, and
whether those survivors still meet threshold. Catalog `provider_root` values
remain visible as carrier-family labels for compatibility; they are not
presented as independent infrastructure.

The codec and its carrier envelope are separately versioned. New generations
still use systematic `cityb-systematic-cauchy-rs-gf256.v1` erasure math, but
write `cityb.archive-erasure-shard.v2` envelopes with canonical RFC 4648
Base64. That reduces text expansion from hexadecimal's 2x to Base64's 4/3x.
The reader accepts both v2 Base64 and the admitted v1 `payload_hex` envelope;
the plan and manifest name the exact envelope/encoding, and every shard remains
bound by its decoded-byte SHA3-256. Capacity facts are actual rendered byte
counts, so old observations remain valid bounds rather than being rescaled.

The historical October 18 production generation used its sealed provider snapshot and
30 data plus 30 parity shards. Its full assignment map leaves 36/30 shards
after loss of the largest observed root. Receipt reality is narrower: the
first topology repair raised the verified subset to 42 total and 27/30 after
AS13335 loss. The accepted release remains valid evidence; root-loss readiness
is a stricter operating margin and never rewrites old receipts.

`cityb dead-drop archive status --plan PLAN --service-set free-stable --json`
classifies the retained plan as exactly one of:

- `current-ready`: current provider generation and enough matching receipts
  for immediate reconstruction; status separately reports whether the received
  subset survives loss of its largest observed diversity domain;
- `current-incomplete`: current generation, not enough matching receipts;
- `superseded-ready-for-forensics`: old generation with a reconstructable
  receipt set, retained for investigation only;
- `superseded-incomplete`: old and incomplete;
- `invalid`: unreadable or internally inconsistent state. Status renders this
  as a non-adoptable result with the reason and no collect command, so the
  cockpit can explain the fault instead of losing it as an opaque subprocess
  failure.

Only receipts bearing the active generation count. Legacy receipts count only
with a legacy plan. Foreign receipts are reported, never silently mixed.
Superseded plans never receive a normal collect/adopt command.

Use the transactional refresh path when the provider set changes:

```sh
cityb dead-drop archive refresh \
  --input ./signed-release.tar.gz \
  --root ./city-b-artifacts \
  --service-set free-stable \
  --data-shards 30 --parity-shards 30 --json
```

CityB constructs the new generation in a sibling staging directory, writes and
validates its complete plan, moves the previous directory under
`city-b-archive-erasure-history/`, then installs the already-complete staged
directory with a same-filesystem rename. If the final rename fails, it restores
the previous directory. Old receipts
and provider evidence remain available for forensics and capacity history; the
new generation begins with an empty receipt set.

The normal guided form is `cityb reconcile`. Its dry run prints the release,
signing, trust, refresh, spray, collect, field-pack, recovery-card, and final
`next` chain. `--apply` performs local generation and trust work; remote
provider mutation additionally requires `--live`. It chooses geometry from the
current provider set and retained evidence rather than a count copied into this
page. A resumed ceremony
validates an existing policy against the selected allowed-signers path,
identity, and namespace instead of silently rotating trust.

## Persist release trust once

Archive reconstruction proves availability and bytes, not authority. Configure
release admission once per retained root:

```sh
cityb release trust init \
  --root ./city-b-artifacts \
  --allowed-signers /absolute/path/to/cityb_allowed_signers \
  --signer-identity cityb-release \
  --signature-namespace cityb-release \
  --allowed-release-name cityb \
  --allowed-version 0.1.0 \
  --allowed-platform linux/x86_64 \
  --require-runtime-match \
  --apply --json
```

Optional repeated `--allowed-archive-sha3-256` flags pin exact release archive
digests. Empty name/version/platform/digest lists mean that dimension is not
allowlisted; signer, identity, namespace, and verified OpenSSH signature remain
mandatory. `cityb release trust status --root ./city-b-artifacts --json`
validates the policy and its allowed-signers file.

`cityb release sign SHA3SUMS --signing-key KEY --apply` makes the distributed
artifact self-contained: it installs the OpenSSH signature inside the release
directory, rebuilds the `.tar.gz` through a temporary sibling, atomically
replaces it, recomputes the archive digest, and updates the external release
manifest. The archive sprayed to providers therefore contains the signature
that `collect --release-verify` must admit. `release archive --binary-dir DIR`
packages already reviewed binaries without rebuilding different bytes.

When trust is configured, archive status and `cityb next` emit a complete,
runnable collect command containing `--trust-policy`. When it is absent, the
only release-related action is `release trust init --root ROOT`; running that
without signer arguments prints the one complete initialization command and
the inputs the human must select. Immediate-action fields never contain
`ALLOWED_SIGNERS` or `ID` placeholders. Reconstructed bytes are written to a
temporary path and are installed at the requested output path only after
digest and release admission succeed; the accepted release receives a
generation sidecar.

## Archive capacity is a lifecycle

Every applied spray writes a v2 evidence record containing generation,
provider-set digest, payload size, size band, success, verification result, and
failure phase (`upload`, `retrieval`, `byte-verification`, or `transport`). A
later bounded recheck can additionally identify observed expiry:

```sh
cityb dead-drop archive recheck --plan PLAN --max-receipts 1 --apply --json
cityb dead-drop archive capacity --root ./city-b-artifacts \
  --service-set free-stable --json
cityb dead-drop archive capacity-soak --root ./city-b-artifacts \
  --service-set free-stable --json
cityb dead-drop archive capacity-soak --root ./city-b-artifacts \
  --provider dpaste --band medium --apply --json
```

The capacity ledger reads the active generation and archived generations. Per
provider it reports maximum proven payload bytes, latest success/failure dates,
failure phases, latest expiry date, maximum payload at which expiry was
observed, shard-size band, and one of `proven`,
`recovered-watch`, `watch`, `repair`, `repeated-failure`, `unproven`, or
`pointer-only`. Historical success is not erased by a later failure; the latest
dated outcome and the date-separated failure count determine watch/repair
posture.

The ledger exposes both all-history `max_proven_payload_bytes` and
`dated_max_proven_payload_bytes`. Strict planning and receipt repair use the
dated value: an old record without a valid `YYYY-MM-DD` observation may remain
useful forensic evidence, but it cannot authorize an automatic post at that
width. `prefer-proven` and `ignore` remain explicit research choices.

`capacity-soak` is dry-run by default. It rotates the least-observed eligible
provider through approximately 4 KiB pointer, 64 KiB small, 256 KiB medium,
and 1 MiB large probes. Applied probes create a valid shard, post through the
native adapter, retrieve and byte-verify it, and append dated evidence to
`city-b-archive-capacity-evidence.jsonl`. The earned class is `pointer-only`,
`small-shard`, `medium-shard`, `large-shard`, `recovered-watch`, or
`repeated-capacity-failure`. A live monitor tick performs at most one such
adaptive mutation and at most one retained-shard recheck, keeping the evidence
ladder bounded. Capacity-probe v2 validates the shard-byte digest already
embedded in the returned packet. Probe v1 incorrectly used the digest of the
complete rendered packet as a marker expected inside that same packet. Readers
therefore discard only legacy v1 `token-missing` and `checksum-mismatch`
outcomes; v1 upload, API, timeout, and transport failures remain valid facts.

The live monitor now includes the capacity ledger on every run and, when the
active plan matches current `free-stable` and has at least one receipt,
rechecks one retained shard per run. This bounds requests while steadily
measuring expiry and retrieval drift. Planning separates membership from
assignment: every declared provider remains in the signed provider-set
snapshot, while `provider_count` in a plan report counts providers that
actually received shards and `provider_set_count` counts the snapshot. If any
native exact-byte providers exist, pointer-only providers receive no archive
shards. Among exact-byte providers the planner balances assignments first,
then uses maximum proven payload, current/recovered-watch state, topology root,
and diversity domain to order equally loaded choices. Failed attempted payload
sizes never inflate `max_proven_payload_bytes`.

The operator loop is therefore:

```text
monitor tick
  -> pointer probes
  -> one bounded archive receipt recheck
  -> capacity ledger
  -> health inbox / cityb next
  -> refresh, spray, repair, or collect exactly one current generation
```

Capacity evidence is operational evidence, not promotion authority. Pointer
stability and archive capacity remain separate lanes.

Capacity is also a planning and repair policy, not merely a report. Planning
measures the largest rendered shard packet before assignment:

```sh
# Normal availability-biased planning: rank dated proof first.
cityb dead-drop archive plan ... --capacity-policy prefer-proven

# Strict production planning: exclude providers without proof at this exact
# width, use only presently automatic archive roles, and refuse a plan that
# does not survive loss of its largest observed failure domain.
cityb dead-drop archive plan ... \
  --archive-role-policy automatic \
  --capacity-policy require-proven \
  --require-root-loss-ready

# Preserve a generation while repairing only missing outside-root receipts.
cityb dead-drop archive repair --plan PLAN --apply --json
```

`archive repair` defaults to `require-proven`; `prefer-proven` and `ignore` are
explicit experimental choices. Status reports total reconstruction,
largest-domain survivors, deficit, safe repair-candidate count, and exactly one
next action. When the safe candidate count is too small, the next action is a
provider-specific capacity probe at the current plan width—not another blind
spray. Failed repair attempts remain capacity evidence and never become shard
receipts.

Historical capacity summaries are retained in the evidence corpus and
generation records, not transcribed here as current truth. Later probes can
move a provider between proven, bounded, recovered-watch, repair, and
pointer-only without changing old receipts. Read the present ladder from
`cityb dead-drop archive capacity --json`, the shared capability ledger, or a
generated Stil snapshot. Archived generations preserve their exact failed and
successful attempts without counting removed members as current membership.

Future-generation preview does not grant recovered or repair providers posting
authority. It compares the authorized automatic-role geometry with a separate
prospective geometry over structurally capable providers. It now ranks the
intersection of dated capacity proof and observed root diversity: an enormous
shard with no provider proof cannot win merely because its data threshold is
small. The preview prints alternative shapes, capacity-proven root-loss
margins, and the exact capacity-soak target rather than pretending “narrower”
and “more root-safe” are simultaneously available from a fixed set. Generate
the current comparison with `cityb dead-drop archive preview ... --json`.

Shard geometry is independent from provider count. The systematic codec may
place up to 64 independently checksummed shards across a smaller set of
capacity-proven providers. Assignment balances observed failure domains first
and provider reuse second. Preview simulates that exact assignment algorithm;
its printed refresh command carries the automatic-role, capacity-proof, and
largest-root-loss gates, so the command either creates the promised geometry
or refuses without rotating the current generation. Reports keep distinct
provider count and capacity-proven shard count separate.
