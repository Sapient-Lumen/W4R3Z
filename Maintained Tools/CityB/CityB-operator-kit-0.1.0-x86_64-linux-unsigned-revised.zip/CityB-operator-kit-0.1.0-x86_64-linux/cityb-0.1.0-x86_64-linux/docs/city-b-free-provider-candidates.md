# City B free-provider candidate queue

CityB keeps a Rust-owned queue of 260 free-provider candidates. This queue is an investigation surface, not a stable posting surface. It exists so an operator can sort likely free services, generate conservative deployment stubs, stage packets, collect exact-byte evidence, and promote only the providers that survive replay.

The queue deliberately separates current product lanes from historical
evidence benches:

- `free-stable`: repeated date-separated exact-byte captures, fixture replay, parser-diff agreement, and root-diversity review.
- `free-wide`: built-in public adapters with mixed, negative, or still-developing evidence.
- `free-deep-*`: retained ten-provider research benches that produced much of
  the September/October corpus. Many exact providers from these benches have
  already entered `free-stable`; rendered-token, redirect-token, mixed-history,
  and failed providers remain discovery or research evidence. The bench name
  no longer implies that every member awaits the same promotion decision.
- `free-candidate-pool`: researched free candidates routed through conservative generic/manual adapters until evidence exists.

Use:

```sh
cityb provider summary --json
cityb provider catalog --json
cityb provider candidates plan --json
cityb provider candidates test --provider put-re --json
cityb provider candidates test --provider put-re --live --json
cityb provider candidates test --provider put-re --live --fixture-root fixtures/cityb/free-service-replay --json
cityb provider candidates capture --provider gofile --json
cityb provider candidates promote --provider gofile --lane research --json
cityb provider catalog --class filehost --json
cityb provider catalog --adapter manual-drop --json
cityb deployment init --out ./city-b-candidates.toml --service-set free-candidate-pool
cityb deployment validate --file ./city-b-candidates.toml --json
```

The candidate catalog is generated rather than summarized by volatile prose.
Run `cityb provider catalog --json` for the authoritative catalog and `cityb
provider candidates list --json` for the filtered candidate view; run `cityb
monitor plan --json` for the exact native probe rotation selected by the
continuous monitor.
The batch stable-plan distinguishes repeated-exact candidates that still need
production-native adapter semantics from watch, non-exact, and not-ready
candidates; no new row is entitled to automatic stable promotion merely by
entering the queue. Rerun the commands above before acting because those
decision counts change as retained evidence accumulates.

`free-candidate-pool` creates one `[[service]]` per generated candidate and one collector over the selected catalog. It validates as a normal deployment under the bounded 512-service/256-collector ceilings, but the selected adapters do not make CityB claim live public mutation success. `filehost-generic` stages upload packets and requires an operator-declared final URL before probe evidence exists. `manual-drop` is explicit human/operator publication. `object-store-generic` assumes an operator-owned free bucket, free JSON store, or account and exact public object URLs unless a native probe proves only token-field discovery. The detailed expansion strategy lives in [city-b-provider-expansion-plan.md](city-b-provider-expansion-plan.md), and providers that did not perfectly fit but still look adapter-worthy live in [city-b-provider-near-misses.md](city-b-provider-near-misses.md).

`cityb provider candidates plan` now includes a priority-0 `latest-staged-candidates` batch. That batch is intentionally insertion-ordered and currently shows up to twenty newest rows: when maintainers add a new tranche, the operator sees those candidates first, can run capture plans and fixture work for the fresh tranche, and can avoid silently cycling on the same older alphabetical candidates.

The continuous monitor does not automatically live-test generic candidate rows. It soaks native providers in `free-stable`, rotates native research benches, collects declared public listings, records a read-only `provider candidates plan` step, and runs the selected provider-specific native probe tranche. AISense Temporary Storage, Kawaii Files, temp-files, Tempcloud, tmp0.cc, and beacon.host moved from native probe evidence into `free-stable`; Bashupload and Stashr moved through the same native-adapter path but later returned to `free-wide` after repeated dated failures. The monitor still keeps these providers in the native-probe loop as low-cost regression, repair, and archive-capacity evidence. `cityb monitor plan --json` is the authoritative source for `native_candidate_probe_count` and the exact current tranche; do not copy that volatile count into prose. The tranche includes promoted regression probes, exact-byte onboarding probes, non-exact/rendered-token probes, token-visible discovery probes, receive-only temp-email probes, event protocols, content gateways, and classified repair, gated, challenged, or stale-service probes. EasySend, dropfile.dev, Warpbox, upload.83blue, pomf2/lain, isrv.nl, fsend.me, pb.plz.ac, paste.gg, AnonHost, readm3, MDShare, dpaste.com, mystb/Pastey, ship.page, shipsite.co, Capsule, Pastebin1s, Webionite Bin, hastebin.cc, paste.ivr.fi, PasteShare, Kodi Paste, PastyX, WaifuVault, ShareY, MSK Paste, dpaste.org, Python Discord Paste, and SquadRoom Paste have October 13 exact-byte candidate evidence. Savedly, File2Share, AnonPaste Lite, Telegraph, and Laravel Paste have October 13 non-exact or rendered-token page evidence. Buzzheavier, FuckingFast, and bzzhr.co currently classify as public-site Cloudflare receive pages after anonymous PUT upload; pste.us classifies as CSRF-required; Skunk Paste classifies as anonymous-encryption-required; paste.aaqa.dev classifies as client-fragment-url; 0807.st classifies as proof-of-work-required; Pixeldrain classifies as anonymous-auth-required; paste.hep.gg classifies as captcha-required; Marke.st and Paste.org classify as account-required; FilePost, JSONBin.io, JSONStorage.net, Simply Linux Paste, and Thpaste classify as API-key-required; PasteDB classifies as TLS-endpoint-failed; Skyra Hastebin classifies as stale/502; Denizen Pastebin classifies as form-challenge-or-validation; transfer.sh classifies as timeout; PasteMyst, MantleDB, SuperJSONBlob, ExtendsClass, and Botoi Paste API now classify as normalized-field exact and have production `free-wide` adapters; Keyval remains token-only KV; ntfy.sh now classifies as normalized cached-event exact and has a production `free-wide` event adapter; Webhook.site and Botoi Webhook classify as non-exact webhook JSON; Guerrilla Mail classifies as receive-only temp-email; Mail.tm classifies as a temporary-mail domain-list API; Maildrop.cc classifies as a public inbox-list API; NenzMail classifies as rate-limited temp-email; 1secmail classifies as TLS-failed temp-email from this host; GrabMail classifies as public-mailbox-list temp-email; Mail.gw classifies as HTTP-502 gateway evidence; MeowMail and TempY.email classify as app-shell/API-path repair evidence; shitty.email classifies as expiring-inbox create evidence; Smails classifies as inbox-create plus message-list evidence; Npoint, JsonBlob, and webhooks.sh classify as server-error, Cloudflare-blocked, or viewer-key-required; and Capsule also has earlier same-day token-missing evidence and remains watch/onboarding until a later date recapture proves stable exact-byte behavior. These probes are intentionally classified as candidate evidence: command `success` means the probe ran and classified the service, while `provider_success`, `receive_exact`, `failure_name`, and `status` say what the provider actually did. Add `--fixture-root DIR` to retain the run: every probe writes a transcript, and exact-byte receives also write a replay fixture plus a copied body file. Live monitor runs now pass their retained fixture root to native probes, so candidate evidence can flow through `cityb evidence sync` instead of becoming unstructured terminal output. `cityb provider health --service-set free-candidate-pool`, `cityb provider promotion-board --service-set free-candidate-pool`, and `cityb provider dossier PROVIDER --service-set free-candidate-pool` now read that evidence directly: repeated exact-byte candidate-probe success becomes `native-adapter-required`, not `promote-review`, until the provider has production Rust capture semantics or a native bench entry. A staged candidate without a native probe becomes tested only when an operator runs the capture/staging plan, checks in replay evidence, or builds a provider-specific native probe or adapter that the monitor can exercise.

Promotion remains provider-by-provider:

1. Use `cityb provider candidates plan --json` to choose a behavior-diverse tranche, not merely an alphabetical batch.
2. Use `cityb provider candidates capture --provider PROVIDER --json` to generate the retained root, `free-candidate-pool` deployment, recipe command, and fixture-template command.
3. Stage packets through the generic adapter, manual recipe, or a small provider-specific experiment; use `provider candidates test --live --fixture-root fixtures/cityb/free-service-replay` only for candidates whose plan reports `native_probe_available=true`.
4. Record exact final locations, raw bodies, rendered bodies, screenshots/OCR, redirects, HTTP status, expiry, rate-limit, and failure bodies as appropriate.
5. Replay with `cityb collect fixture` and add dated replay fixtures plus body files.
6. Run Biggun parser-diff over the corpus.
7. Build a provider-specific native adapter id only when the evidence proves behavior that generic staging cannot safely express.
8. Promote to `free-wide` only after the provider has a real receive path and a production capture adapter or bench entry that can keep writing fixtures.
9. Promote to `free-stable` only after `provider candidates promote` reaches `stable-source-review-required`, which requires provider-specific native Rust, repeated date-separated exact-byte replay fixtures, no retained failure rows for that candidate, parser agreement, root-diversity review, and a source-level patch plan with evidence references.

The October 18 event-feed expansion added Damus, nos.lol, and Primal as native
Nostr relay candidates. CityB generated ephemeral secp256k1 keys, published
correctly hashed and Schnorr-signed NIP-01 addressable events, required a
positive relay `OK`, retrieved each event through a fresh `REQ`, verified exact
event content, closed the subscription, and sent a best-effort NIP-09 deletion
request. A first manual pass succeeded on all three; the later standing-monitor
pass kept nos.lol and Primal exact but recorded a Damus acknowledgement failure.
That mixed same-day evidence is retained rather than averaged away. They remain
public discovery/event candidates—not archives, private channels, or
guaranteed-delete stores—until repeated dates, listener semantics, relay-policy
evidence, and Biggun cost/agreement justify a production event lane. See
[NIP-01](https://github.com/nostr-protocol/nips/blob/master/01.md),
[NIP-09](https://github.com/nostr-protocol/nips/blob/master/09.md), and
[NIP-11](https://github.com/nostr-protocol/nips/blob/master/11.md).

The same October 18 diversity pass added `nats-demo` as a distinct Core NATS
candidate. Its native Rust probe connects two independent clients to the
official public demo endpoint, registers one random-subject auto-unsubscribing
listener, flushes the subscription and publication with protocol `PING/PONG`,
and compares the delivered bytes exactly. This is deliberately live-only:
Core NATS is at-most-once and a message with no listener is discarded, so the
probe proves an event/heartbeat path, not retained rendezvous or archive
storage. The [official client-protocol reference](https://docs.nats.io/reference/protocols/client)
documents the `INFO`, `CONNECT`, `SUB`, `PUB`, `MSG`, and `PING/PONG` frames,
and the [official getting-started guide](https://docs.nats.io/concepts/getting-started/)
publishes `demo.nats.io` as its public example server.

The same pass added two content-gateway candidates. Both native probes make a
bounded read-only request for the IPFS specification's raw CID of the five bytes
`hello`; they never upload, pin, or claim that a CityB body was published. The
Pinata gateway returned those exact bytes on October 18, while the IPFS
Foundation gateway returned HTTP 521. The Foundation's own documentation says
that `ipfs.io`, `dweb.link`, and `trustless-gateway.link` share one backend, so
CityB deliberately does not count those aliases as topology diversity. See the
[public-utilities warning](https://docs.ipfs.tech/concepts/public-utilities/),
[gateway request reference](https://docs.ipfs.tech/reference/http/gateway/), and
[CID raw-block example](https://github.com/ipfs/specs/blob/main/src/cid.md).

The October 20 diversity tranche adds nine provider-specific probes without
pretending that nine hostnames are nine equivalent stores. `shz-al` performed
a bounded private multipart upload, served the generated body exactly through
its raw URL, and accepted best-effort deletion through the returned management
capability. `nostr-nostr-net`, `nostr-snort`, and `nostr-wellorder` each
acknowledged a signed ephemeral addressable event and returned its exact
content to a fresh subscription; they remain public event/discovery carriers,
not archives. `ipfs-filebase-gateway` and `ipfs-4everland-gateway` returned the
fixed known CID exactly, but remain receive-only gateways with no anonymous
pinning claim. `mqtt-eclipse-public` timed out from this runner and stays in
the soak as availability evidence. `simplylinux-paste` and `thpaste` now have
native key-gate classifiers: both exposed useful API shapes, but neither
accepted a keyless write during the first pass. The standing monitor runs all
nine, so later recovery and drift become dated evidence rather than prose.
Relevant upstream contracts are the [Nostr relay-information
document](https://github.com/nostr-protocol/nips/blob/master/11.md), the
[Eclipse IoT sandbox list](https://iot.eclipse.org/projects/sandboxes/), and
the [4EVERLAND gateway reference](https://docs.4everland.org/gateways).

A second October 20 tranche adds ten more provider-specific probes while preserving each carrier's actual semantics. The shiftr.io public MQTT instance recovered an exact retained message through a fresh authenticated connection using its documented public credentials; flespi's reachable broker rejected anonymous connection exactly as its token contract says. nostr.mom, OXTR, and bitcoiner.social each accepted a signed addressable Nostr event and returned exact content, but they remain event relays with policy-controlled retention. Bluesky's unauthenticated Jetstream returned a cursor-bearing JSON event and is retained as a read-only firehose candidate, not a posting adapter. The Arweave network gateway plus ar.io, WeaveGate, and Noddex gateway operators each returned the AR.IO quick-start transaction's exact five bytes; all four remain retrieval routes because permanence belongs to Arweave and publication requires a signed transaction. The standing 118-probe monitor reproduced all ten classifications and the checked-in transcripts retain gateway wallet/release and NIP-11 relay identity where exposed. Gateway and firehose results remain `receive-only-no-publish` instead of being counted as exact CityB round trips. Primary contracts: [shiftr.io public instance](https://www.shiftr.io/try/), [flespi broker configuration](https://flespi.com/mqtt-broker), [Bluesky Jetstream protocol](https://github.com/bluesky-social/jetstream/blob/main/docs/README.md), [Arweave HTTP API](https://docs.arweave.org/developers/arweave-node-server/http-api), and [AR.IO gateways](https://docs.ar.io/learn/gateways).

The queue was seeded from online free-provider research, including the maintained [Awesome File Hosts](https://github.com/FahadBinHussain/awesome-file-hosts) dataset and its machine-readable [host catalog](https://raw.githubusercontent.com/FahadBinHussain/awesome-file-hosts/main/data/hosts.json), then normalized into CityB-local identifiers and conservative adapter choices. The dataset is not proof of CityB compatibility. Provider docs and live behavior must still be verified before any provider becomes a normal operator path.

The first September 28, 2026 expansion added ImgBB, IMGPile, ki.tc, Oshi.at, PixVid, sxcu.net, TransferNow, Uptomega, vgy.me, and ViKiNG FiLE to the staged pool. The second September 28, 2026 expansion added GrosFichiers, Gulfup, Hexupload, Hostize, Hostuje, i by Tikolu, ImageBam, Imagenetz, ImageVenue, and Imouto. The third September 28, 2026 expansion added Internxt Send, Kepkuldes, Lufi/AdminForge, Lutim, MyAirBridge, pCloud Transfer, pic.maxiol, Pikky, PlusTransfer, and QuickSendFile. The fourth September 28, 2026 expansion added put.re, Ranoz, RapidFileShare, RapidGrab, Rapidshare.io, Riseup Share, Rootz, Send Anywhere, SendGB, SendSpace, Sendvid, SharePlace, Smash, Stashr, Streamable, Streamain, SwissTransfer, take-me-to.space, temp-files, and Tempcloud. The fifth September 28, 2026 expansion added AISense Temporary Storage, Kawaii Files, and tmp0.cc after live one-shot probes showed exact-byte anonymous receive. On September 30, 2026, Stashr and temp-files gained provider-specific native probes and first retained exact-byte candidate fixtures. On October 8, 2026, beacon.host joined the staged pool, gained a provider-specific native probe, entered `free-wide`, and imported one same-day native-candidate fixture plus one same-day production-capture fixture; on October 10 it had date-separated exact-byte evidence and moved into `free-stable`. The first October 13, 2026 expansion added native probes for EasySend, Savedly, dropfile.dev, File2Share, Warpbox, upload.83blue, and pomf2/lain; five returned exact bytes and two returned non-exact public pages. The second October 13, 2026 expansion added isrv.nl, fsend.me, pb.plz.ac, paste.gg, fars.ee, ShareNation, Originless, and 1c3.ir to the staged pool; the first four gained native probes and exact-byte candidate evidence, while the last four entered the near-miss ledger for later endpoint, timeout, TLS, or form repair. The third October 13, 2026 expansion added AnonHost, readm3, MDShare, FuckingFast, bzzhr.co, pste.us, Skunk Paste, paste.aaqa.dev, 0807.st, Pixeldrain, dpaste.com, and paste.hep.gg, plus a native repair probe for the existing Buzzheavier candidate; AnonHost, readm3, MDShare, and dpaste.com produced exact-byte candidate fixtures, while the others entered explicit repair/gated/discovery classifications. The fourth October 13 expansion added mystb/Pastey, ship.page, shipsite.co, Capsule, PasteMyst, and AnonPaste Lite; mystb/Pastey, ship.page, shipsite.co, and Capsule produced exact-byte candidate fixtures, PasteMyst initially produced JSON-field evidence and later gained a normalized-field-exact production adapter, AnonPaste Lite produced non-exact page evidence, and Capsule remains watch/onboarding because an earlier same-day run returned token-missing receive evidence. The fifth October 13 expansion added Pastebin1s, Webionite Bin, hastebin.cc, paste.ivr.fi, PasteShare, Kodi Paste, PastyX, WaifuVault, ShareY, and Telegraph; the first nine produced exact-byte candidate fixtures, and Telegraph produced rendered-token-visible public-page evidence. The sixth October 13 expansion added MSK Paste, dpaste.org, Python Discord Paste, Marke.st, PasteDB, Paste.org, Skyra Hastebin, Denizen Pastebin, Laravel Paste, and transfer.sh; MSK Paste, dpaste.org, and Python Discord Paste produced exact-byte candidate fixtures, while the other seven produced retained classified near-miss transcripts that are now part of the monitor rotation. The seventh October 13 expansion added MantleDB, SuperJSONBlob, ExtendsClass JSON Storage, Keyval, Npoint, JSONBin.io, JSONStorage.net, JsonBlob, ntfy.sh, Webhook.site, and webhooks.sh; MantleDB, SuperJSONBlob, ExtendsClass, Keyval, ntfy.sh, and Webhook.site produced token-visible but non-exact discovery evidence, while Npoint, JSONBin.io, JSONStorage.net, JsonBlob, and webhooks.sh produced classified repair or credential/viewer-gate evidence. The eighth October 13 expansion added Botoi Paste API, Botoi Webhook Inbox, and SquadRoom Paste; Botoi Paste later proved normalized-field exactness and gained a production discovery adapter, Botoi Webhook produced token-visible non-exact discovery transcripts, and SquadRoom Paste produced exact-byte candidate fixtures through its raw Markdown receive path. The ninth October 13 expansion added Guerrilla Mail, NenzMail, and 1secmail as a distinct temp-email family and added a native FilePost classifier for the existing FilePost row; Guerrilla Mail proved no-account inbox/listing semantics, NenzMail returned anonymous rate-limit evidence, 1secmail failed verified TLS API reads from this host, and FilePost proved the documented API-key gate. The tenth October 13 expansion added Mail.tm and Maildrop.cc to the temp-email family; Mail.tm proved a live domain-list API, and Maildrop.cc proved public GraphQL inbox-list semantics, but neither proved message delivery or exact-byte receive. The eleventh late October 13/UTC October 14 expansion added GrabMail, Mail.gw, MeowMail, shitty.email, Smails, and TempY.email; GrabMail proved a redacted public mailbox-list API, Mail.gw produced retained HTTP-502 gateway evidence, MeowMail and TempY.email produced app-shell/API-path repair evidence, shitty.email proved redacted expiring-inbox creation, and Smails proved redacted inbox-create plus message-list behavior. The twelfth October 14 expansion added the EMQX, HiveMQ, and Mosquitto public MQTT brokers as candidate event feeds. All three recovered the exact retained payload through independent MQTT 3.1.1 subscriber connections and performed best-effort retained cleanup, but remain candidate-only because test brokers provide neither durability nor privacy guarantees. New candidate additions deliberately start as `candidate-needs-fixture` entries. They are useful because they add provider families and discovery-lane possibilities for tranche planning; they are not promoted until CityB has later date-separated exact fixtures, a production capture adapter, parser agreement, and topology review.
