# CityB current operator campaign

This is the executable near-term roadmap as of October 28, 2026. It is a
handoff, not a historical ledger. Generated command output owns every volatile
fact. Completed design history remains in
[city-b-plan.md](city-b-plan.md), the provider chronology remains in
[city-b-current-state.md](city-b-current-state.md), and speculative work
remains in [city-b-frontier.md](city-b-frontier.md).

The campaign is operator-first. Work ranks highly when it makes the retained
deployment easier to understand, more likely to recover, or less likely to
mislead. Provider count alone is not progress.

## Generated starting truth

Begin each public CityB office with:

```sh
cityb system doctor
cityb operator card
cityb next --require-ready
```

For a durable machine-readable handoff, retain the bounded operator card and
the descriptor-selected system report together:

```sh
stamp=$(date -u +%Y%m%dT%H%M%SZ)
mkdir "operator-snapshot-$stamp"
cityb system doctor --allow-attention --json > "operator-snapshot-$stamp/system.json"
cityb operator card --json > "operator-snapshot-$stamp/operator-card.json"
```

That artifact, not this prose, records the active source/build/provider
identity, timer and latest-run facts, evidence generation/high-water mark,
named capability ladder, current archive receipts and threshold, topology,
field-pack freshness, correspondence posture, and one primary action. The
capability rows answer different questions and must not be substituted for one
another. Infrastructure, stable pointer capture, promoted listings, capacity
experiments, candidate probes, archive admission, and correspondence remain
independent outcomes. Dated historical receipts remain evidence; superseded
generations cannot emit a normal adoption recommendation.

The current planning rule is also generated: geometry ranking uses the
intersection of dated capacity proof and observed effective roots. A low data
threshold with enormous unproven shards no longer outranks a narrower,
evidence-backed shape. When nothing survives the selected root-loss policy,
preview names the missing joint margin and the exact next probe width.

## Completed foundations

The following are product mechanisms, not roadmap wishes:

- three public Rust binaries: Tiny `cityb-node`, Goldilocks `cityb`, and
  truth/development `cityb-biggun`;
- one opt-in public Nix automation object rather than a fourth binary, with a
  descriptor-bound `cityb system` lifecycle that refuses arbitrary units and
  verifies loaded executables against the reviewed package;
- a single operator cockpit through `cityb next`, shared readiness semantics,
  a capability ledger, and ordered action chains;
- native exact-byte provider adapters, provider dossiers, health inbox,
  dry-run-first promote/demote/retire patch planning, and candidate benches;
- continuous pointer, listing, candidate, topology, and adaptive archive
  evidence collection with automatic local import;
- generation-aware archive erasure plan, live spray, receipts, reconstruction,
  detached-signature admission, field packs, and recovery cards;
- three admitted retained-local Tiny listing sweeps: Pastebin Archive, GitHub
  public Gists, and Pastefy; FragBin remains a suspended experiment;
- content-indexed, generation-sealed evidence curation and bounded monitor
  report retention;
- state-ratcheted slots, pointer chains, durable-anchor policy, and local
  end-to-end long-amnesia proofs;
- authenticated operator/node correspondence with enrollment, HPKE, rotation,
  acknowledged cutover, bounded spool/gateway/relay paths, fleet freshness,
  tasks/results, courier exchange, a fixed-vocabulary signed external-operator
  endpoint, signed public fleet kits for remote-only offices, ordinary
  two-family relay exchange, and Biggun fault campaigns;
- Biggun provider reality, parser agreement, archive survival, topology loss,
  anchor-amnesia, correspondence chaos, gates, and selftests.

## P0 — keep the cockpit closed after a decision

An applied archive-role transaction used to remain the primary action forever:
the evidence-derived repair queue still existed, so provider health could not
distinguish “unreviewed” from “reviewed and assigned to continued soaking.”

The policy now seals a digest of the sorted provider-to-role mapping. Provider
health classifies an exact retained mapping as `archive-capacity-tracked`, does
not claim operator review is still pending, and lets the monitor continue the
current capacity-repair queue. Its membership belongs to `stil snapshot` and
`cityb provider archive-roles`, not to a count copied into this campaign.
Evidence changes that alter a role invalidate the digest
and restore the one batch apply action. Cosmetic timestamps, command paths,
reasons, and provider iteration order do not invalidate it.

Acceptance:

1. Preview is non-mutating and apply atomically replaces one local policy.
2. Immediately after apply, `provider health` reports the policy current.
3. `cityb next` never prints the same role apply as its immediate action until
   evidence changes a provider role.
4. The repair queue remains visible and soakable without making stable pointer
   health look degraded.
5. A changed provider role invalidates the retained digest and produces one
   executable batch action.

## Completed October 22 closure tranche

The archive-role mapping and current handoff now close through the cockpit
rather than a manual command composition. The proven sequence was:

1. inspect `cityb next --root ./city-b-artifacts --deployment ./city-b.toml`;
2. preview/rebuild the stale deterministic cycle if requested;
3. regenerate and verify the field pack after the evidence decision;
4. regenerate the recovery card from the same generation;
5. finish with no contradictory provider, archive, monitor, or handoff action.

The cycle rotation is crash-resumable and preserves a content-verified
forensic generation before removing the active projection. The cockpit's
headline command is now derived from the same first action as its readiness
chain, so a stale field pack cannot be hidden behind `command=none`. Default
operator-card JSON is a roughly 9 KiB bounded decision summary on the retained
root; `--verbose` preserves the roughly 420 KiB full child reports.

Do not refresh the already admitted archive generation merely because provider
capacity evidence changed. Provider evidence is planning input; release bytes,
membership, and threshold identity are generation state.

## Completed October 28 recovery and wait-semantics tranche

The retained-root drill found two operator-truth defects and closed them:

- a signed pointer-chain member pending archive inclusion now produces the
  exact `publish --epoch N` transition named by that member, rather than
  repeating `cycle apply`;
- field-pack freshness compares the kit epoch with the retained root's current
  verified chain tip, not with the stale chain copy inside the kit itself.

The proof sealed the pending act into the next declared archive, advanced the
verified retained chain, regenerated and verified the Tiny field pack, and
rebuilt the recovery card. A later dated stable-provider failure is now an
explicit automatic wait: CityB keeps the named provider dossier in the action
chain, Stil prints `WAIT_UNTIL` and optional `REVIEW`, and unrelated
current-root recovery work can proceed. It no longer emits a recursive
`DO_NOW = stil act` for a non-executable timer wait.

## P1 — let time close the remaining archive-capacity queue

The corrected v2 capacity oracle reduced the queue from 26 to eight genuine
repair providers; the later labeled pass moved Uguu into repair on observed
returned-URL expiry, so the current queue is nine. The monitor should target the current plan's real shard
width, prioritize those providers, and bisect a known success/failure interval
instead of repeating arbitrary large probes. Legacy v1 token/checksum misses
are probe defects; upload/API/transport failures remain provider evidence.

Immediate evidence questions:

- `docs-md`, `eightgwifi`, `mclogs`, `mythical-paste`, `paste-opendev`,
  `paste-openstack`, `paste-yt-project`, and `ti-fo` retain genuine repair
  outcomes with exact failure phases;
- `paste-c-net`, CentOS Paste, openSUSE Paste, Sendit, and seven other services
  have ordered exact recovery evidence and remain recovered-watch until later
  dates make that recovery boring;
- AlmaLinux Paste, Debian Paste, HelpChat Paste, PasteFox, Sourcebin, and TnyPst
  have useful bounded smaller classes rather than a false all-or-nothing
  verdict;
- the nine pointer-only providers stay excluded from automatic shards until
  later source-reviewed evidence changes their structural contract.

Acceptance is intentionally boring: later exact results earn bounded/proven
classes; repeated unresolved failures remain repair; expiry, upload, retrieval,
challenge, rate-limit, and byte-verification phases remain distinct; pointer
membership does not change because a larger archive probe failed.

## P1 — turn the promotion-review bench into source decisions

Use `cityb-biggun promotion-tranche --archive-evidence-root
./city-b-artifacts --require --json` for the generated ranked candidate set.
Do not promote it as one blob. Divide candidates by capability:

1. raw exact-byte HTTP candidates suitable for mirror/capacity work;
2. event relays (Nostr/MQTT) suitable for correspondence or discovery;
3. rendered/normalized carriers suitable only for their declared lane;
4. receive-only gateways/firehoses suitable for recovery or discovery.

For each raw-body candidate, require dossier, production-adapter semantics,
whole-corpus parser agreement, dated topology facts, an explicit expiry/body
limit, and a source patch plan. Prefer a genuinely different operator/ASN/root
over another hostname behind AS13335. Candidate exactness is necessary but not
sufficient evidence for `free-stable` or archive spraying.

The current high-value raw-body review set includes Webionite Bin, dpaste.org,
dropfile.dev, EasySend, hastebin.cc, isrv.nl, MSK Paste, mystb/Pastey,
paste.gg, paste.ivr.fi, Kodi Paste, Python Discord Paste, PastyX, pb.plz.ac,
ShareY, Shipsite, shz.al, and SquadRoom Paste. Verify each current dossier
before treating this dated list as authoritative.

## P1 — preserve evidence without publishing the monitor's disk

Automatic import is useful only if Git receives a curated truth corpus rather
than every successful body forever. After each meaningful soak window:

```sh
cityb evidence sync --apply --json
cityb evidence curate --json
cityb evidence curate --apply --json
cityb-biggun parser-diff --require --json
```

Commit the curation manifest's selected transitions and content-addressed
bodies. A repeated preview must have no pending curation. Monitor state remains
bounded by the reviewed curation transaction; full transient state is not
source material.

## P1 — use Biggun as the promotion and soak referee

`cityb-biggun promotion-tranche --archive-evidence-root ./city-b-artifacts
--require --json` now emits the first ranked, explicitly non-authoritative
review tranche. Each row scores dated
exact-body windows, parser agreement, observed archive capacity, expiry facts,
effective-root independence and stable-root concentration, and intended
archive/pointer/listing/correspondence role.

The next useful improvements remain decision-oriented rather than another
dashboard:

- compare proposed membership against present root concentration before a
  patch is recommended;
- replay capacity at the proposed shard width, not only a generic provider
  loss threshold;
- turn later FragBin recovery evidence into an explicit listing readmission
  gate, while keeping current failure out of stable readiness;
- keep failure outputs exact and successful embedded reports projected to
  scalar summaries plus content digest.

## P2 — empirical long-amnesia recovery

Local composition exists: stale field pack → durable anchor → signed chain →
shard reconstruction → release admission → current handoff. The next work is
external evidence, not a new authority path:

- accumulate a later same-tree Rekor consistency transcript and additional
  date-separated CT inclusion/consistency transcripts; the October 23 Argon
  pair already verifies inclusion, both STH signatures, and one real RFC 6962
  consistency path;
- retain root/key rotation facts and prove allowlisted transitions;
- keep real drand chained-signature captures across dates;
- exercise rollback, split view, missing proof, stale checkpoint, and root
  rotation against checked-in fixtures;
- run a retained-root drill that begins only with a stale field pack and
  accepted external-root policy.

No public anchor authorizes adoption. It only helps locate the signed archive
chain that can.

## P2 — prove the completed correspondence office modes

The correspondence mechanism is broad enough. ChatGPT can now be a genuine
operator through a deliberately shared constitutional key, an entropy-backed
private office, a signed short-lived HTTPS request to the authoritative root,
a signed public fleet kit plus relay plan, or an offline courier handoff. The
remote endpoint admits a compiled CityB vocabulary and is not a shell.

The valuable next step is deployment evidence: date-separated exchange across
at least two protocol families per field route, a real TLS gateway run from a
cloudtainer, and removable-media/camera courier drills. Keep status capsules
jittered and budgeted, gateway limits separate for nodes and operators, replay
records bounded, relay receipts body-free, and public office kits free of
private custody. Do not expand the allowlist into a general remote shell.

## P3 — structural and release polish

- Keep `cityb next` comfortably interactive as the corpus grows. The evidence
  index is mandatory; aggregate commands must project large successful child
  reports rather than copying multi-megabyte boards.
- Keep the three-binary link boundaries clean and rerun footprint/target gates
  after dependency changes.
- Refresh release/closure/size transcripts when an actual release is cut.
- Preserve the opt-in Nix automation contract: no public mutation merely by
  importing the module.
- Continue splitting only code seams that reduce review risk; line count alone
  is not a refactor goal.

## Explicitly deferred

- Clean-machine or separate-hardware handoff is deferred by operator choice.
- Real ARM hardware is unavailable; cross-target checks remain useful but are
  not field-hardware proof.
- FragBin readmission waits for later successful public evidence.
- A fourth binary is not planned. New automation belongs in the Nix object;
  new adversarial development machinery belongs in Biggun.
- Provider camouflage/steganography remains an extension seam, not a stable
  default or an excuse to mislabel carrier authority.

## Definition of this campaign being healthy

The campaign is healthy when:

1. `cityb next` prints one runnable primary action and never loops on a just
   completed local decision;
2. the monitor timer is active, the selected/installed binary identities
   match, the latest required lanes are green, and experimental failures are
   labeled separately;
3. `free-stable` has 100% current pointer exactness or an evidence-backed
   action for every exception;
4. archive capacity classes come from dated payload evidence and directly
   constrain planning;
5. the current admitted generation, field pack, recovery card, and provider
   generation are unambiguous;
6. evidence import and curation are idempotent and parser agreement passes;
7. topology risk is stated in effective roots and correlated-loss survival,
   not provider-name count;
8. a weaker maintainer can resume from this file, run the printed commands,
   and distinguish implemented mechanism, retained evidence, and future work.
