# City B provider model

City B should treat outside services as interchangeable transport surfaces, not
as protocol authorities.

The stable rule is:

- providers transport bytes;
- manifests bind bytes;
- threshold signatures authorize state.

That separation keeps City B from collapsing service availability into
governance authority. A paste page, file host, static site, release page,
object store, transcript import, or future plugin may help a node discover or
fetch a candidate archive. None of them can make that archive legitimate.

## Core terms

- Bundle: the canonical signed archive for one epoch/serial state.
- Placement: one published instance of some City B material on one provider.
- Pointer: compact discovery material naming a candidate archive identity.
- Mirror: a fetchable copy of the bundle or bundle-adjacent evidence.
- Observation: what a node or operator actually saw on a provider.
- Refusal: the exact reason a candidate was rejected.
- Adapter: the narrow driver that translates City B material into one provider's
  local/API/manual workflow.
- Provider class: a family such as local-double, human-copy, filehost,
  static-site, release-page, or object-store.
- Policy profile: an operator-chosen redundancy/freshness strategy over several
  providers.

## Design goal

The operator should think in terms of outcomes, not provider quirks:

1. build a signed bundle;
2. select a provider profile;
3. emit placements;
4. verify placements;
5. inspect health and rotation pressure;
6. export recovery evidence.

City B core should hide the per-service mechanics behind adapters.

The phase split for those adapters is defined in
[city-b-hook-model.md](city-b-hook-model.md).
The provider-growth process is defined in
[city-b-provider-expansion-plan.md](city-b-provider-expansion-plan.md).

## Cost posture

City B treats free service access as a first-class product requirement:

- no-account services are preferred when they provide enough utility;
- free account-backed services are acceptable when they materially improve
  durability, probe quality, or operator legibility;
- paid-only services are not part of the mainline City B adapter roadmap.

That constraint should appear in adapter metadata, review output, and roadmap
decisions rather than living as tribal knowledge in docs or operator memory.

## Provider classes

These classes are useful because they generalize common behavior without
hard-coding one brand or website into the protocol:

| Class | Typical role | Examples of operator intent |
|---|---|---|
| `local-double` | deterministic fixture, local observation, receipt generation | test a placement plan without mutating any remote service |
| `human-copy` | manual publication into an operator-chosen lawful service | hand-carry a pointer or bundle into a known surface |
| `static-site` | stable pointer or mirror publishing | publish pointer pages and fetchable bundles under predictable paths |
| `filehost` | temporary or lightweight mirror | drop a bundle somewhere fetchable with a simple URL |
| `release-page` | durable operator-facing mirrors and notes | attach bundles and recovery notes to release metadata |
| `object-store` | scalable mirror fleet | replicate bundles with explicit retention and probe logic |
| `extension-seam` | explicit executable seam for service-specific work | add a narrow adapter without rewriting City B core |

## Adapter contract

The adapter seam should stay narrow and boring. One adapter should describe:

- what it can publish: pointer, archive, heartbeat, route-hint, receipt;
- whether it mutates anything remote;
- what target shape it expects;
- how it reports success;
- how it probes health;
- how it normalizes placement and observation receipts;
- which failure names it may emit;
- which extension hooks are reserved for future encoding or placement logic.

Current CLI support exposes this seam through:

```sh
cityb dead-drop adapter catalog
cityb dead-drop adapter init --root DIR
cityb dead-drop adapter doctor --root DIR
cityb deployment recipes [--file city-b.toml] [--service SERVICE] [--adapter ADAPTER] [--json]
cityb collect probe --root RUN --deployment city-b.toml --service SERVICE --location URL_OR_FILE --json
cityb collect cursor --root RUN --deployment city-b.toml --service SERVICE --lane LANE --source LISTING_URL_OR_FILE --json
cityb collect fixture --root RUN --deployment city-b.toml --fixture captured-provider-fixtures.jsonl --json
cityb collect fixture-template --root RUN --deployment city-b.toml --out provider-fixtures.jsonl [--case NAME] [--all-cases] --json
cityb capture free-wide --live --min-passed 8 --out fixtures/cityb/free-service-replay
cityb capture free-deep-10 --live --require-all --out fixtures/cityb/free-service-replay
cityb capture free-deep-text-10 --live --require-all --out fixtures/cityb/free-service-replay
cityb capture free-deep-web-10 --live --require-all --out fixtures/cityb/free-service-replay
cityb capture free-deep-web2-10 --live --require-all --out fixtures/cityb/free-service-replay
cityb capture free-deep-web3-10 --live --require-all --out fixtures/cityb/free-service-replay
cityb capture free-deep-web4-10 --live --require-all --out fixtures/cityb/free-service-replay
cityb capture free-deep-web5-10 --live --require-all --out fixtures/cityb/free-service-replay
cityb collect live-capture --deployment city-b.toml --capture-dir /tmp/cityb-live-free-wide --fixture-out provider-fixtures.jsonl [--transcript-out transcript.jsonl] --json
cityb evidence board --fixture-root fixtures/cityb/free-service-replay
cityb promote check --fixture-root fixtures/cityb/free-service-replay
cityb provider candidates plan --json
cityb provider candidates capture --provider PROVIDER --json
```

`dead-drop init` also writes the adapter registry into the workspace so a
retained run can carry both substrate assumptions and adapter assumptions.
`deployment recipes` is the zero-memory service guide. Without a deployment it
prints the built-in adapter catalog; with `--file` it resolves deployment-local
service ids into their configured lanes, roots, retention, collector mode,
request budgets, preferred encodings, probe recipe, cursor recipe, fixture
cases, hazards, and repair notes. It is side-effect free and exists so an
operator can ask "how does this service behave?" without reading the whole
roadmap.
`collect probe` is the exact-location receive foothold: it reads only exact
operator-supplied locations, retains raw carrier bytes under content addresses,
records parser facts for every shared pointer encoding, and appends service
reliability events, including final location, redirect count, and HTTP status
when available. `collect cursor` is the bounded discovery foothold: it reads one
operator-declared listing URL or file, retains the listing bytes, records source
final-location/redirect/status facts, extracts exact candidate locations
according to the service's declared cursor mode, probes only those candidates,
and commits a service/lane cursor report with a normalized continuation location
when the listing exposes one. Each cursor report records the previous current
cursor report digest when present, which turns cursor replacement into a
content-addressed evidence chain rather than an unlinked dashboard update.
Returned-URL-only services remain exact-probe surfaces rather than invented
enumeration surfaces; static indexes and provider JSON fields get native
parsing. Neither command authenticates, crawls arbitrary provider state, or
mutates the service.

`collect fixture` is the offline receive replay path. It accepts captured
provider bodies or captured fetch failures, performs no network requests, and
writes the same probe receipts and service reliability rows as a live exact
probe. Fixture records may preserve final location, redirect count, and HTTP
status, so offline replay can model expiry, permission, rate-limit, redirect,
and provider-error cases. Probe and reliability rows now preserve
`provider_health` so planning can
distinguish verified content from access refusal, expiry/moderation,
rate-limit, provider, network, local-input, stale-content, and parser failure
classes. These classes change ranking and operator next actions; they do not
change the signed archive verification gate.
`collect fixture-template` writes runnable JSONL fixture records from the
current retained pointer and deployment. The generated fixtures use the same
shared renderer selected by lane policy or an explicit `--encoding`, so a field
capture can start from a valid replay file and replace only the location/body
facts that came from the service. `--case NAME` generates specific replay cases;
`--all-cases` expands the adapter recipe's declared set so an operator can start
from a ready-made verified and negative corpus.
`capture free-stable|free-five|free-wide|free-deep-10|free-deep-text-10|free-deep-web-10|free-deep-web2-10|free-deep-web3-10|free-deep-web4-10|free-deep-web5-10` is the Rust-owned live-service path. Without `--live`, it prints the exact live command and performs no remote mutation. With `--live`, it creates the retained root and deployment, executes the selected free-service adapters, preserves raw transcripts, invokes the checked conversion path, and prints the parser-diff command. `free-deep-10` is a strict provider-evidence bench for x0.at, curl.by, End2End.tech, file2.me, JuiceBox, TempFile.org, ayaya.beauty, hostb, hst.sh, and haste.rys.pw. `free-deep-text-10` is the paired strict text/paste bench for paste.code-solutions.dev, paste.helpch.at, bytebin.lucko.me, api.pastes.dev, bpa.st, transfer.archivete.am, pastefy.app, pastefox.com, haste.zneix.eu, and bin.birdflop.com. `free-deep-web-10` is the paired strict web paste/file bench for mclo.gs, Sourcebin, paste.agradip.fyi, SpaceBin, CrafterBin, qurl.sh, Mythical Paste, YukiAPI, AgentMediaTools, and paste.firnsy.com. `free-deep-web2-10` is the paired strict web/API bench for PasteHTML, OKFile, here.now, haste.unbelievaboat.com, rentry.co, files.offshore.cat, qu.ax, zoomie.sh, openSUSE Paste, and Debian Pastezone. `free-deep-web3-10` is the next strict web/API bench for CentOS Paste, rpa.st, AlmaLinux Paste, OpenStack Paste, yt-project Paste, OpenDev Paste, Gentoo LogPaste, Ubuntu China Paste, p.defau.lt, and paste2.org; it intentionally mixes exact raw receive paths with rendered-token carriers so replay can measure non-exact surfaces honestly. `free-deep-web4-10` is the mixed paste/API/shortener bench for Pastr, Valhalla Paste, Write.as, p.ip.fi, Kagit, ShareNotes, Pastebin.ai, da.gd, TinyURL, and clck.ru; its shorteners intentionally produce redirect-token evidence with `digest_match=false`, not exact-byte mirror evidence. `free-deep-web5-10` is the mixed paste/API/rendered/shortener bench for Scuttled, ti.fo, docs-md, 8gwifi, tnypst, Droptext, Luis Aranguren Paste, Ulvis, MeshaLive, and AISense 307.fi; it intentionally records final-newline normalization, rendered-token evidence, and redirect-token evidence as distinct receive behaviors. CleanURI remains an implemented drift candidate outside strict sets after live probes created unretrievable short URLs. CoShareX remains a built JSON-field drift candidate outside the strict set. All deep benches should normally run with `--require-all` until repeated dated captures justify splitting or promotion. `collect live-capture` remains the lower-level converter for already-retained capture directories: it reads `transcripts/*.stdout.json`, falls back to matching `*.stderr.txt` for `--require` failures, maps adapters to the selected deployment services, copies successful exact-byte payloads into fixture body files, copies retained observed rendered probe bodies when `digest_match=false`, emits named provider cases such as provider-error, challenge-page, tmpfiles viewer-to-direct-download, and termbin NUL-trimmed-url, and writes a summary transcript with source stream, status, redirect, parser, and SHA3-256 body facts. It performs no remote request and should be run before deciding which live captures deserve to be checked in. `evidence board` and `promote check` turn that fixture corpus into executable service-status and free-stable promotion reports; `provider promotion-board --service-set SET` then turns a whole bench into a ranked source-review queue with dossier and patch-plan commands for each provider.
`provider candidates plan` is the front door for expanding beyond built native adapters. It ranks the Rust-owned 260-provider queue into behavior-diverse evidence batches, puts the newest staged tranche first, and marks candidates that already have a native probe. `provider candidates capture --provider PROVIDER` is a staging plan, not a generic live capture path: it prints the retained root, `free-candidate-pool` deployment, recipe command, and fixture-template command. `provider candidates test --provider PROVIDER --live --json` is the native-probe path for selected candidates; it reports command success separately from provider success so disabled, DNS-dead, TLS-mismatched, rendered-page, token-gated, timeout, token-field, webhook, publish-ack, receive-only temp-email, and non-exact receive results can be soaked without pretending they passed. Add `--fixture-root DIR` when the operator wants durable onboarding evidence: the native probe posts a normal parseable CityB pointer body where the service class supports posting, writes a transcript row for every result, and writes replay fixtures only for exact-byte receives. The retained monitor uses that fixture-writing mode for native candidate probes during live soaks. Beacon.host is the newest full promotion example: it started as a staged candidate, gained a provider-specific native probe and a `free-wide` production capture path after an October 8, 2026 exact-byte one-day-filehost proof, then entered `free-stable` on October 10 after a date-separated recapture and source review. The October 13 EasySend/dropfile.dev/Warpbox/upload.83blue/pomf2/isrv.nl/fsend.me/pb.plz.ac/paste.gg/AnonHost/readm3/MDShare/dpaste.com/mystb-Pastey/ship.page/shipsite.co/Capsule/Pastebin1s/Webionite Bin/hastebin.cc/paste.ivr.fi/PasteShare/Kodi Paste/PastyX/WaifuVault/ShareY/MSK Paste/dpaste.org/Python Discord Paste and SquadRoom Paste evidence is the newest exact-byte onboarding example: native probes produced first exact-byte fixtures, but the providers still need date-separated evidence, parser/topology review, and production capture semantics before stable-set review. Savedly, File2Share, AnonPaste Lite, Telegraph, and Laravel Paste are non-exact examples because their native probes classified public receive pages rather than exact bytes. PasteMyst, MantleDB, SuperJSONBlob, ExtendsClass, and Botoi Paste API are normalized-field-exact production discovery adapters; ntfy.sh is a normalized cached-event adapter; Keyval, Webhook.site, and Botoi Webhook remain token-visible discovery examples; none proves raw-body archive receive. Guerrilla Mail, GrabMail, Mail.gw, Mail.tm, Maildrop.cc, MeowMail, NenzMail, 1secmail, shitty.email, Smails, and TempY.email are temp-email examples because their native probes classify receive-only inbox/listing, public mailbox-list, gateway-error, domain-list, public-inbox-list, app-shell, anonymous rate-limit, TLS-failed API, expiring-inbox, message-list, or API-path behavior without claiming CityB can post exact bytes there. FilePost, Buzzheavier, FuckingFast, bzzhr.co, pste.us, Skunk Paste, paste.aaqa.dev, 0807.st, Pixeldrain, paste.hep.gg, Capsule, JSONBin.io, JSONStorage.net, JsonBlob, webhooks.sh, Npoint, Marke.st, PasteDB, Paste.org, Skyra Hastebin, Denizen Pastebin, and transfer.sh are classified repair/gated/discovery examples because their native probes preserved the concrete blocker instead of marking them as generic failures. fars.ee, ShareNation, Originless, 1c3.ir, Pastebox-family services, requestcatcher.com, JSONKeeper, JSONStore.io, getpantry.cloud, envs.sh, ttm.sh, sharey.gay, tempditch.com, and stale public Haste instances live in the near-miss ledger because the first live pass found timeout, TLS, endpoint, API, receive-path, or form failures that still look repairable enough for later adapter work. `provider candidates promote --provider PROVIDER --json` reads checked-in and retained monitor fixture corpora even before the candidate belongs to a service set, then reports whether the candidate still needs native Rust, more date-separated exact evidence, a production capture adapter/bench entry, parser/topology review, or a source patch. A candidate moves into a live bench only after provider-specific evidence justifies provider-specific Rust and after the ongoing capture path is clear. The current protocol-diversity tranche adds exact shiftr.io MQTT and three exact Nostr event paths, a flespi credential classifier, a bounded Bluesky Jetstream reader, and four Arweave gateway readers; receive-only results remain route evidence rather than stable posting evidence.

## Reserved extension hooks

City B should stay ready for more advanced publication behaviors without
coupling current core logic to them. The reserved hooks are:

- encoding hooks: alternate renderings of the same pointer or receipt material;
- placement hooks: provider-specific path, slot, or staging logic;
- probe hooks: provider-specific health checks and receipt normalization.

Those hooks were reserved first so the core would not need another rewrite.
`file.io`, `uguu`, `termbin`, `storage.to`, `filebin`, `paste-rs`, `dpaste`,
`paste-c-net`, `nullpaste`, `0x0`, `catbox`, `litterbox`, `tmpfiles`,
`sendit`, and `temp-sh` now exercise the built-in public-service promotions,
while `plugin-external` remains the staged
executable contract for everything that is still too provisional to promote.
More provider-owned integrations should still fit inside the same model.
`github-gist`, `gitlab-snippet`, `github-release`, `gitlab-release`,
`netlify-drop`, `github-pages`, `gitlab-pages`, `codeberg-pages`, and
`codeberg-release` now exercise free account-backed or staged-operator tiers
inside the same seams: provider-specific packet/guidance in core, provider
mutation left explicit unless a native adapter has a narrow no-secret flow, and
probe activation only when City B has one exact final URL.

The next planned promotions should be chosen from receive value, not brand
count: documented listing APIs, stable raw URLs, explicit TTL semantics,
continuation cursors, redirect stability, and failure modes that improve the
scheduler or Biggun replay model.

Service recipes are now the public metadata seam for that decision. A provider
should not become a core adapter merely because it is reachable. It should add
at least one useful behavior to the scheduler or receiver: a clearer retention
family, a better direct URL, a documented cursor, a different transport class,
a different moderation or rate-limit failure, or a fixture corpus that improves
Biggun replay.

## Operator consequence

If an operator uses five different services, City B should not create five
different mental models. It should create one publication report containing:

- bundle identity;
- placements attempted;
- placements healthy/degraded/failed;
- receipt freshness;
- failure-domain diversity;
- next rotation actions.

`cycle next` now exposes that last item in two layers. The main `command`
advances or repairs the cycle state. The `service_repair_queue` lists degraded
service/lane pairs ranked by provider health, event state, observed failures,
penalty, rotation pressure, and rate window so the operator can fix a service
set without opening every retained receipt.

That is the level where City B becomes a usable tool rather than a pile of
service-specific folklore.

## Deployment metadata now used by the compiler

`cityb deployment init --service-set free-stable` writes the repeated-live
stable manifest for no-credential public services. `--service-set free-five`
preserves the older Filebin/0x0 drift bench. `--service-set free-wide`
expands that into the full currently built-in anonymous/free adapter bench for
fixture capture and field trials, including Litterbox, Filebin settle behavior,
and retained negative 0x0/file.io/storage.to drift evidence. Do not preserve a
volatile `free-stable` count in prose: run `stil snapshot --json` for the
shared current capability ledger and `cityb service ls --service-set
free-stable --json` for the authoritative roster. Generated deployments derive
from this same canonical roster, so a
reviewed provider patch changes monitoring, health, and newly initialized
deployments together. Bashupload has a production adapter but moved back to `free-wide` after
retained October 11-12, 2026 monitor evidence showed repeated upload
rejections. Stashr moved back after repeated October 13-14 upload failures, and
mPaste moved back after certificate-expiry failures on October 14 and October
15; their native adapters remain available for recovery evidence. NullPaste remains implemented in `free-wide`, but
retained monitor evidence from September 17 through September 19, 2026 showed
repeated fetch failures and moved it out of the easy set. Filebin, Termbin, and
temp.sh also remain implemented outside the easy set after retained monitor
evidence through September 26 showed repeated Filebin token-missing receives
and repeated Termbin/temp.sh upload rejections, and imported September
30-October 7 monitor evidence moved paste.rs and Catbox back to wider/drift
benches after date-separated upload rejections. Each service records:

- `failure_domain`
- `provider_root`
- `account_root`
- `network_root`
- `moderation_root`
- `copy_root`
- `retention_class`
- `probe_surface`
- `payload_fit`
- `request_budget`
- `request_cost`
- `rate_limit_window_secs`
- `collector_mode`
- `collector_source`

Validation counts effective independent roots as the minimum diversity across
the failure, provider, account, network, moderation, and copy roots. This is
stricter than counting adapter brands and catches common false diversity, such
as several services behind one provider, one account, one DNS/CDN family, or
one copied transcript source.

Profile defaults now compile into lane encoding, fragment scheme, rendezvous,
cadence, TTL, retry budget, storage budget, observation freshness, observation
decay, and root request budget. These policy facts are emitted in resolved
deployment JSON, listener plans, cycle plans, cycle events, and collector
snapshot receipts. Service selection now also uses operational metadata and
retained probe/cursor reliability facts. Plans freeze the chosen scores,
provider-health penalties, observed success/failure counts, health buckets,
fresh/stale observation counts, rotation pressure, request budgets, request
costs, root-budget spend, rate windows, and whether a service was already
covered by fresh observations. Biggun replay now checks retained probe receipts,
fixture replay counts, redirect/status buckets, cursor reports, provider-health
buckets, reliability links, and root-correlation collapse without touching the
remote services again.
