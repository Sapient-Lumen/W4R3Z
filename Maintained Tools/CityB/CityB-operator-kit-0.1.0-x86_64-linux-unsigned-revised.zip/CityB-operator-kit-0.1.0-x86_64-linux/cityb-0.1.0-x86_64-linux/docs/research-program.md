# CityB research and validation program

This repo is maintained as the standalone CityB workbench. The current research surface is the three-binary CityB topology plus the checks that prove operator posting, receive-only parsing, recovery handoff, and stress evidence remain aligned.

Do not copy a provider count or retained-generation status from this document.
Generate the current decision facts from the active object and evidence:

```sh
stil                         # bounded human brief
stil decisions               # evidence-derived review queue
stil snapshot write ./state-$(date -u +%Y%m%dT%H%M%SZ)
```

The immutable snapshot carries the binary/source identity, provider-set
generation, shared capability ledger, admitted archive, topology, field pack,
correspondence posture, soak state, evidence high-water marks, and one current
action. Numerical claims below are dated research history unless they are the
output of one of those commands. Stashr, mPaste, and Dpaste remain native
`free-wide` adapters after their respective repeated failures so later
recovery can be measured without weakening validation or rewriting the
historical corpus.

## Daily checks

```sh
nix develop -c cargo fmt --all
nix develop -c cargo test -p cityb-cli --test t6_cli dead_drop
nix develop -c cargo test -p cityb-cli --test cityb_binary
nix develop -c cargo test -p cityb-lab --test biggun_binary
nix develop -c cargo test -p cityb-node --test tiny_node
nix run .#cityb-biggun -- selftest --plan --json
nix develop -c ./scripts/smoke-cityb-three-binaries.sh
```

Use the flake package as the publication check:

```sh
nix build .#default --no-link --print-out-paths
nix run .#cityb -- capabilities
nix run .#cityb-node -- capabilities
nix run .#cityb-biggun -- format-corpus --json
nix run .#cityb-biggun -- mutation-corpus --json
```

## Binary surfaces

- `cityb-node` is the receive-only field node. It should stay small, ARM-friendly, parser-compatible with Goldilocks, and free of posting credentials or signing authority.
- `cityb` is the normal operator workbench. It owns planning, posting adapters, collection, review, recovery export, and the workflows a human should run directly.
- `cityb-biggun` is the large evidence and stress harness. It may be heavier, but it must produce actionable corpus, mutation, handoff, and refusal evidence for the other two binaries.

Three binaries remain the right split. A fourth binary is not justified until one job has a distinct dependency or authority profile that cannot be enforced by a subcommand.

`cityb-biggun gate --quick` is the normal local readiness command; add `--full`, `--doc`, `--target-check`, or `--release` when the larger proof is needed. `cityb-biggun selftest` is the canonical standalone interoperability proof inside that gate. It composes Goldilocks, Tiny, and Biggun executable checks, no-live capture dry runs, release planning, target/footprint/parser reports, the easy operator path, and the retained exercise into one local report. `scripts/smoke-cityb-three-binaries.sh` is now only a development wrapper that builds debug binaries before calling that Rust command.

## Operator-path commands

```sh
cityb run --nodes 32 --parallelism 16 --root ./city-b-artifacts
cityb deployment init --out ./city-b.toml --profile carrier-loss --service-set free-stable
cityb deployment init --out ./city-b-wide.toml --profile carrier-loss --service-set free-wide
cityb deployment validate --file ./city-b.toml --json
cityb deployment compile --file ./city-b.toml --root ./city-b-artifacts --json
cityb deployment recipes --file ./city-b.toml --json
cityb cycle preview --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb cycle plan --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb cycle apply --root ./city-b-artifacts --deployment ./city-b.toml --with-collect --json
cityb cycle run --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb collect probe --root ./city-b-artifacts --deployment ./city-b.toml --service catbox --location URL_OR_FILE --json
cityb collect cursor --root ./city-b-artifacts --deployment ./city-b.toml --service catbox --lane mirror --source LISTING_URL_OR_FILE --json
cityb collect fixture-template --root ./city-b-artifacts --deployment ./city-b.toml --out captured-provider-fixtures.jsonl --all-cases --json
cityb collect fixture --root ./city-b-artifacts --deployment ./city-b.toml --fixture captured-provider-fixtures.jsonl --json
cityb review --root ./city-b-artifacts
cityb brief --root ./city-b-artifacts
cityb handoff-check --root ./city-b-artifacts
cityb node-kit --root ./city-b-artifacts --out ./city-b-node-kit
cityb-node kit verify --root ./city-b-node-kit --json
cityb dead-drop init --root ./city-b-drops
cityb dead-drop adapter catalog --json
cityb dead-drop substrate catalog --json
cityb dead-drop schedule --root ./city-b-drops --epoch 0 --beacon BEACON --min-media 3 --pointer POINTER
cityb dead-drop envelope --root ./city-b-drops --epoch 0 --beacon BEACON --pointer POINTER --substrate status-thread
cityb dead-drop post --root ./city-b-drops --adapter local-file --target ./city-b-drops/local-posts --against ./city-b-artifacts/city-b-chain --require
cityb dead-drop observe ./city-b-drops/local-posts --root ./city-b-drops --against ./city-b-artifacts/city-b-chain --require
cityb dead-drop audit --root ./city-b-drops --against ./city-b-artifacts/city-b-chain --min-media 2 --require
cityb dead-drop debt --root ./city-b-drops --against ./city-b-artifacts/city-b-chain --current-epoch auto --max-age 2 --min-media 2 --require
cityb dead-drop explain --root ./city-b-drops --against ./city-b-artifacts/city-b-chain --current-epoch auto --max-age 2 --require
cityb dead-drop capsule export --root ./city-b-drops --against ./city-b-artifacts/city-b-chain --out ./city-b-recovery-capsule --current-epoch auto --max-age 2 --min-media 2
cityb-node dead-drop capsule verify --root ./city-b-recovery-capsule --json
cityb-node field-mode render --profile low-power-field --clock-confidence uncertain
cityb-node serve --config CONFIG --state-dir /tmp/cityb-node-state --field-profile low-power-field --clock-confidence offline --now-epoch 1 --cycles 1
cityb-biggun format-corpus --json
cityb-biggun mutation-corpus --json
cityb-biggun gossip-matrix --json
cityb-biggun handoff --root ./city-b-artifacts --kit ./city-b-handoff-kit
cityb-biggun replay --root ./city-b-artifacts --require --json
cityb-biggun targets --json
cityb-biggun exercise --root ./city-b-exercise --kit ./city-b-exercise-kit --nodes 3 --parallelism 3
```

## VM validation

Use Sandwurm only when the host has the direct Cloud Hypervisor path prepared:

```sh
nix develop -c ./scripts/stage-cityb-vm-trial.sh --out /tmp/cityb-vm-trial
nix develop -c ./scripts/run-cityb-sandwurm-vm-trial.sh --trial-root /tmp/cityb-vm-trial
```

This proves guest lifecycle and handoff behavior on one physical machine. It does not prove independent hardware, WAN carrier behavior, router/firewall asymmetry, radio conditions, flash wear, or battery behavior.

## Research priorities

1. Extend measured adapter selection. Profiles now compile encoding, TTL, fragment scheme, rendezvous, cadence, retry, storage, lane floors, service presets, observation freshness, observation decay, root request budgets, and metadata-based adapter ordering. `deployment recipes` renders adapter/service metadata as operator guidance. `collect probe`, `collect cursor`, `collect fixture`, and `collect live-capture` write or produce service evidence with observed epochs, preserve selected-parser evidence, classify provider health, record final-location/redirect/status facts, retain continuation footholds, chain cursor reports to the previous current digest, and feed fresh verified coverage into the cycle planner. `cityb capture free-stable|free-five|free-wide|free-deep-10|free-deep-text-10|free-deep-web-10|free-deep-web2-10|free-deep-web3-10|free-deep-web4-10|free-deep-web5-10` now closes the live-smoke-to-fixture loop from the Rust binary by creating the retained root, executing the selected adapters, preserving transcripts, converting fixtures, and printing the parser-diff command; without `--live`, it prints the exact command and mutates nothing. `cityb monitor plan|run|install|status|review|import` adds the real-machine continuity layer over that path: stable providers are checked every run, one research bench rotates per live run, listing-only providers are checked by the firehose collector rather than a posting adapter, native candidate probes classify selected experimental providers and promoted-provider regression probes, retained reports make provider drift visible without requiring a human to remember every capture incantation, `review` flags urgent stable-set drift without changing promotion status, and `import --apply` copies retained monitor evidence into checked-in fixtures only after review. `cityb evidence sync` wraps review/import/provider-health/promotion-check into the normal local inbox and optionally runs parser-diff, so retained machine evidence can move into repo fixtures with one dry-run/apply command. `cityb provider catalog` adds a Rust-owned 260-provider candidate queue, and `deployment init --service-set free-candidate-pool` turns that queue into conservative generic/manual service stubs for investigation. `evidence board` and `promote check` remain lower-level views over the checked-in corpus and free-stable promotion gates. Plans subtract only fresh coverage before scheduling posts, decay old observations, freeze reliability scores, provider-health penalties, and rotation pressure into events, and enforce service request cost, service request budget, rate window, and correlated-root request budget. The checked-in corpus now includes same-day stable captures, repeated broad captures, a cross-UTC-day free-wide capture with sanitized provider-drift bodies, September 15/16 promotion evidence for Filebin, paste.c-net.org, NullPaste, sendit.sh, temp.sh, and tmpfile-link, repeated negative evidence for 0x0/file.io/storage.to, the September 16 free-deep-10 exact-byte corpus for x0.at, curl.by, End2End.tech, file2.me, JuiceBox, TempFile.org, ayaya.beauty, hostb, hst.sh, and haste.rys.pw, the September 16 free-deep-text-10 exact-byte corpus for paste.code-solutions.dev, paste.helpch.at, bytebin.lucko.me, api.pastes.dev, bpa.st, transfer.archivete.am, pastefy.app, pastefox.com, haste.zneix.eu, and bin.birdflop.com, the September 16 free-deep-web-10 corpus for mclo.gs, Sourcebin, paste.agradip.fyi, SpaceBin, CrafterBin, qurl.sh, Mythical Paste, YukiAPI, AgentMediaTools, and paste.firnsy.com, the September 16 free-deep-web2-10 corpus for PasteHTML, OKFile, here.now, haste.unbelievaboat.com, rentry.co, files.offshore.cat, qu.ax, zoomie.sh, openSUSE Paste, and Debian Pastezone, the September 16 free-deep-web3-10 corpus for CentOS Paste, rpa.st, AlmaLinux Paste, OpenStack Paste, yt-project Paste, OpenDev Paste, Gentoo LogPaste, Ubuntu China Paste, p.defau.lt, and paste2.org, the September 16 free-deep-web4-10 corpus for Pastr, Valhalla Paste, Write.as, p.ip.fi, Kagit, ShareNotes, Pastebin.ai, da.gd, TinyURL, and clck.ru, the September 16 free-deep-web5-10 corpus for Scuttled, ti.fo, docs-md, 8gwifi, tnypst, Droptext, Luis Aranguren Paste, Ulvis, MeshaLive, and AISense 307.fi, September 17 public-listing corpora for Pastebin archive plus GitHub public Gists, October 8/10 beacon.host exact-byte native-probe plus production-capture fixtures, and October 13 candidate-probe fixtures for EasySend, dropfile.dev, Warpbox, upload.83blue, pomf2/lain, isrv.nl, fsend.me, pb.plz.ac, paste.gg, AnonHost, readm3, MDShare, dpaste.com, mystb/Pastey, ship.page, shipsite.co, Capsule, Pastebin1s, Webionite Bin, hastebin.cc, paste.ivr.fi, PasteShare, Kodi Paste, PastyX, WaifuVault, ShareY, MSK Paste, dpaste.org, and Python Discord Paste. CleanURI remains an implemented shortener drift candidate after generating immediately unretrievable links from this host. CoShareX remains a built JSON-field drift candidate outside the strict set after repeated anonymous API upload rejections. fars.ee, ShareNation, Originless, 1c3.ir, drop.plz.ac, Savedly, File2Share, PasteMyst, AnonPaste Lite, Buzzheavier, FuckingFast, bzzhr.co, pste.us, Skunk Paste, paste.aaqa.dev, 0807.st, Pixeldrain, paste.hep.gg, Marke.st, PasteDB, Paste.org, Skyra Hastebin, Denizen Pastebin, Laravel Paste, transfer.sh, FilePost, Guerrilla Mail, Mail.tm, Maildrop.cc, NenzMail, 1secmail, GrabMail, Mail.gw, MeowMail, shitty.email, Smails, TempY.email, envs.sh, and ttm.sh now live in the near-miss or candidate-classifier ledger when they look adapter-worthy but fail exact-byte receive or endpoint proof. Capsule stays in the ledger as a mixed-evidence watch item until date-separated exact receive proves the earlier token-missing result was transient. Next, let continuous monitor evidence accumulate across days, keep archive-sized soak status recurring, promote or demote only after repeated drift is visible, keep rendered-token/redirect-token/listing-token/temp-email providers as discovery lanes rather than exact-byte mirror evidence, and add service-native cursor expiry semantics where documented free services expose them.
September 19 update, revised October 22: Pastebin Archive, GitHub public Gists,
Pastefy, and FragBin have provider-specific public-listing evidence. Pastebin
Archive, GitHub public Gists, and Pastefy are the current green, declared Tiny
sweep gates after date-separated evidence and Biggun agreement. FragBin remains
a listing-token research carrier with its parser and historical fixtures intact,
but HTTP 500 listing failures on October 17, October 18, and October 22 suspend
its Tiny declaration; the monitor continues bounded rechecks, retains failures
in the rendezvous observation ledger, and requires later exact recovery plus
source review before re-admission. None of these listing carriers is a posting
adapter or exact-byte mirror.

The next paragraphs are a chronological evidence ledger, not current posture.
Their verbs and counts describe what was true on those dates. No prose update is
authoritative for the present stable set; use `stil snapshot --json` and the
Rust catalog commands for live state.

Provider-monitor update: retained monitor evidence through September 19 first imported 226 additional fixture/body files covering 86 providers, 380 success records, 40 failure records, and 367 exact-byte records. Later September 19 all-free and targeted monitor passes imported another 134 files and expanded the checked-in replay corpus to 103 fixture files, 1064 fixture records, and 89 declared native adapter IDs. Subsequent monitor imports through September 28 expanded the replay corpus to 272 top-level files and 2962 records for the current free-stable doctor view. The evidence moved NullPaste out of `free-stable` after repeated September 17-19 fetch failures, then moved Filebin, Termbin, and temp.sh out of the easy set after repeated Filebin token-missing receives and repeated Termbin/temp.sh upload rejections. Dpaste has a September 19 failure plus later exact-byte stable passes and therefore stays a recovered watch item unless a later-date failure proves repeated drift. The September 26 promotion pass moved the eight exact-byte `free-deep-web2-10` providers into `free-stable` while keeping rentry.co and qu.ax in discovery lanes; the September 28 and September 30 native candidate probes gathered repeated exact-byte evidence for AISense Temporary Storage, bashupload.app, Kawaii Files, Stashr, temp-files, Tempcloud, and tmp0.cc. The October 7 native-adapter promotion turned those seven providers into production Rust capture adapters, moved them into the stable monitor tick, and expanded the easy operator path to 23 no-credential exact-byte providers. The October 10 beacon.host promotion followed an October 8 first proof, a later date-separated exact-byte recapture, a source patch plan with evidence references, a no-source-change stable-plan review, and a fresh live stable monitor/import pass. The later October 10 deep-bench source review promoted 40 additional exact-byte providers from the strict deep benches into `free-stable`; rendered-token, redirect-token, and watch-only providers stayed in research lanes. The first October 11 soak watch kept bytebin.lucko.me and api.pastes.dev in `free-stable` after later pointer-sized recapture, but marked both archive-shard ineligible after repeated archive-sized failures. The October 12 review moved Bashupload back to `free-wide` after repeated October 11-12 upload rejections. The October 14 Stashr demotion left 62 active exact-byte providers and 53 automatic archive-shard candidates; the October 15 mPaste certificate-expiry demotion then established the then-current 61-provider set with 52 automatic archive-shard candidates and a 30-shard nurse recommendation, so the archive lane is useful but still narrower than pointer-sized exact-byte stability. The October 13 provider hunt added AnonHost, readm3, MDShare, FuckingFast, bzzhr.co, pste.us, Skunk Paste, paste.aaqa.dev, 0807.st, Pixeldrain, dpaste.com, paste.hep.gg, mystb/Pastey, ship.page, shipsite.co, Capsule, PasteMyst, AnonPaste Lite, Pastebin1s, Webionite Bin, hastebin.cc, paste.ivr.fi, PasteShare, Kodi Paste, PastyX, WaifuVault, ShareY, Telegraph, MSK Paste, dpaste.org, Python Discord Paste, Marke.st, PasteDB, Paste.org, Skyra Hastebin, Denizen Pastebin, Laravel Paste, transfer.sh, Botoi Paste API, Botoi Webhook Inbox, and SquadRoom Paste to the staged pool, added a native repair probe for existing Buzzheavier, imported exact-byte candidate fixtures for AnonHost, readm3, MDShare, dpaste.com, mystb/Pastey, ship.page, shipsite.co, Capsule, Pastebin1s, Webionite Bin, hastebin.cc, paste.ivr.fi, PasteShare, Kodi Paste, PastyX, WaifuVault, ShareY, MSK Paste, dpaste.org, Python Discord Paste, and SquadRoom Paste, and retained classified repair/gated/discovery, JSON-field, rendered-token, non-exact, and mixed token-missing/exact transcripts for the others. The October 14 pass promoted five normalized JSON-field stores and ntfy into real `free-wide` discovery/event adapters, added three independently tested public MQTT brokers to the candidate event family, imported the monitor results, and retained a 6/6 production capture for the new adapters. The live monitor now keeps 108 provider-specific native probes in rotation so promoted providers can keep producing regression/capacity evidence while unpromoted providers continue to accumulate onboarding evidence.

October 18 soak update, with an October 23 historical snapshot:
timestamp-aware replay treats the last same-day
observation as current and uses failure as the conservative tie breaker. Dpaste
failed after its October 17 post-recovery failures and moved back to
`free-wide`. PasteFox recovered exact pointer behavior while retaining
archive-capacity repair evidence. `p-ip-fi` recovered on repeated October 20
exact-byte recaptures. Spacebin's later same-date exact-byte observation
restored current health while retaining mixed-history watch evidence. FragBin's public listing API returned HTTP
500 again after bounded retries, so live use remains suspended while retained
fixtures continue to exercise the parser. The transactionally refreshed 30+30
production generation encoded the signed 7.1 MiB release, retained 42/60 exact
receipts, reconstructed the exact planned digest, verified OpenSSH release
admission through persisted trust, and regenerated the field pack and recovery
card. The October 23 capability ledger recorded 60 stable, 60 latest-pointer-exact,
51 structurally archive-capable, 51 spray-usable, 29 capacity-proven, eleven
capacity-repair, eleven recovered-watch, nine pointer-only, 42-of-60 current
receipts, and a 30-of-60 threshold. Providers with only a larger-size failure
remain capacity-bounded rather than falsely degraded at every size.

Operator-surface update: `provider health` and `provider promotion-board` now expose top-level `status` and `success`, `monitor nurse` points at the failed provider explanation when retained evidence identifies one, `stable-plan` names source files/review steps/validation commands and reports no-source-change after a promotion lands, `anchor status` gives the local missed-cycle fallback page, and release/field-pack surfaces can require detached-signature presence without pretending to verify the signature bytes.

2. Make adapter orchestration operator-simple. A human can now run `cityb up`, `cityb check`, `cityb next`, `cityb capture`, `cityb evidence sync`, `cityb evidence board`, and `cityb promote check` as the normal path: `up` creates or validates the retained root and deployment, compiles, previews, runs/resumes, collects, reviews, exports the Tiny kit, and prints the next command; `check` is side-effect free; `next` selects the shortest evidence-bound action; `capture` owns the public-service transcript-to-fixture ritual; `evidence sync` is the dry-run/apply inbox for retained monitor evidence; `evidence board` shows observed service reality; `promote check` names exactly what is missing before a wider adapter may become stable. The lower-level flow still lets an operator declare `local-proof`, `free-stable`, `free-five`, `free-wide`, `free-deep-10`, `free-deep-text-10`, `free-deep-web-10`, `free-deep-web2-10`, `free-deep-web3-10`, `free-deep-web4-10`, `free-deep-web5-10`, or `plugin-five` once, preview hazards with `cycle preview`, execute bounded batches with `cycle apply`, resume after interruption, add `--with-collect` to collect verified local outputs, generate verified or recipe-wide fixture scaffolding with `collect fixture-template --all-cases`, or use `cycle run` as the one-command cycle path. `--free` now selects the repeated-live stable no-account set, while `--wide-free` selects the wider built-in anonymous adapter bench for evidence collection. `free-deep-10`, `free-deep-text-10`, `free-deep-web-10`, `free-deep-web2-10`, `free-deep-web3-10`, `free-deep-web4-10`, and `free-deep-web5-10` are strict ten-provider benches rather than shortcut flags because they should be chosen deliberately. `cycle next` now emits both the state-transition command and a ranked `service_repair_queue` with recipe, receive, and fixture-template commands for each degraded service/lane. Next, replace more generic repair text with provider-specific commands only where captured fixtures prove stable semantics.
3. Expand mutation/refusal corpora. Biggun now has `mutation-corpus` and `parser-diff`. `parser-diff` writes one valid and four malformed carrier files for every shared pointer encoding, ingests checked-in provider fixture bodies including sanitized upload-error, challenge-page, malformed HTML, and drift bodies, wraps those bodies as raw text, HTML, malformed HTML, and OCR-ish noise, runs the Goldilocks and Tiny CLI parsers over the exact same files, compares extracted candidate sets and checksum-valid counts, and fails under `--require` on process, candidate, or checksum divergence. The September 15 true-OCR corpus uses a Chromium screenshot plus Tesseract output and exposed a real `v1`→`vl` marker confusion that the shared mnemonic parser now accepts. Next, add more real screenshot/OCR captures with lower-quality fonts, mobile photos, and partial cards.
4. Extend receive-plane collection. Goldilocks now materializes verified local adapter results into content-addressed inboxes, probes exact public URLs or local carrier files, replays captured provider fixture payloads/failures through the same receive path, and runs bounded cursor collection from operator-declared listing sources. Cursor reports are content-addressed, persisted by service/lane, retain the raw listing bytes before any candidate probe runs, distinguish exact-local, returned-URL-only, static-index, JSON-field, release-asset, plugin, and non-enumerable cursor modes, preserve source redirect/status/continuation facts, and link each replacement to the previous current cursor report digest. Next, add provider-side cursor expiry semantics where a free service exposes a documented read surface.
5. Make provenance practical. Deployment validation now collapses carrier count into effective independent roots across failure, provider, account, network, moderation, and copied-source roots. Collector probe receipts and service reliability logs preserve those roots, fresh successful observations count as existing coverage before new posts are scheduled, correlated-root request budgets limit overuse in one cycle, provider-health buckets explain degraded service families, `cycle next` maps them to repair footholds and a ranked service repair queue, and Biggun replay reports root collapse plus fixture/redirect/status/cursor/provider-health evidence from retained artifacts. Dated live fixtures now record Filebin eventual availability, paste.rs/dpaste/Catbox success, repeated 0x0/file.io/storage.to drift, mixed Litterbox behavior, a cross-day free-wide repeat, sanitized provider-error/challenge bodies, historical stable paste/file/TCP-upload captures, the Sep 16 promotion of Filebin, paste.c-net.org, NullPaste, sendit.sh, temp.sh, and tmpfile.link into the easy stable set, the Sep 19 demotion of NullPaste back to `free-wide`, and the Sep 20-26 demotion of Filebin, Termbin, and temp.sh back to the research/drift lane after repeated monitor failures. Next, add service-specific receive semantics only where the captures prove stable behavior, and keep mixed/correlated providers out of `free-stable` until they improve the easy path.
6. Improve low-power field behavior. Tiny now renders field-mode runbooks, enforces field profiles through clock-confidence checks, validates volatile and persistent state paths, applies per-cycle write budgets, persists a generation-numbered checkpoint with a previous-generation fallback, reconstructs serve state from checkpoints when `status.json` is missing or stale after an interrupted final write, writes a field-mode report naming changed files and durable commit policy, rejects mismatched listener-plan identity before boot-side state repair, and reports listener deployment/plan/parser identity plus field-mode state in status. Process-level tests cover provision-time durable files plus serve-time current/previous checkpoints, `status.json`, and `field-mode-report.json` at before-create, before-write, and before-rename atomic-write points, then restart from the same state directory. They also cover a real read-only state directory and, when unprivileged mount namespaces are available, a true tmpfs-full write failure. Next, reconstruct more startup state directly from verified chain records and monotone floor facts.
7. Compare fragment strategies under real noise. Keep Shamir for anti-leakage cases, but measure repetition, mnemonic chunks, and systematic erasure coding under OCR, copy/paste, carrier loss, and early-scraper assumptions.
8. Keep public docs and generated runbooks CityB-first. Internal crate and schema names may retain historical `cityb-*` identifiers until a deliberate migration is worth the churn.
