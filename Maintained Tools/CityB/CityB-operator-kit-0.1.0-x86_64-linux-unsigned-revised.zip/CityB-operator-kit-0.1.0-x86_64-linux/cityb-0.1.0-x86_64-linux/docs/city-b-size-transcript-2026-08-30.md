# City B binary size transcript — 2026-08-30

This file is retained evidence for the current x86-64 release-size claim in
`docs/city-b-plan.md`. It is host-specific. It does not prove ARM runtime
behavior, static-musl size, daemon steady-state RAM use, or flash write volume.

Command:

```sh
nix develop -c ./scripts/measure-cityb-size.sh
```

Output:

```text
Finished `release` profile [optimized] target(s) in 1m 08s
binary              bytes     MiB
cityb-node    758648    0.72
cityb         1426312   1.36
cityb-biggun  1516456   1.45
   text    data    bss      dec      hex  filename
 735105   16896    256   752257    b7a81  target/release/cityb-node
1394374   24592    272  1419238   15a7e6  target/release/cityb
1477320   26224    336  1503880   16f288  target/release/cityb-biggun
```

Dependency-shape check:

```text
cityb-node
├── cityb-audit
├── cityb-core
└── cityb-transports

cityb-cli
├── cityb-audit
├── cityb-core
├── cityb-council
├── cityb-transports
└── serde

cityb-lab
├── cityb-cli
├── cityb-core
├── cityb-council
└── cityb-transports
```

Nix package validation:

```sh
nix build -L .#default
```

Summary:

```text
cargoBuildHook flags: -j 12 --target x86_64-unknown-linux-gnu --offline --profile release -p cityb-cli -p cityb-lab -p cityb-node
cargoCheckHook flags: -j 12 --profile release --target x86_64-unknown-linux-gnu --offline --workspace --
release-mode workspace tests: passed
current standalone binary set: cityb, cityb-biggun, cityb-node
```

Packaged output:

```text
result/bin/cityb               1725744
result/bin/cityb         1735400
result/bin/cityb-biggun  1839064
result/bin/cityb-node     955512
historical lab-binary measurement was removed from the public binary set
store output bytes             8080520
store output du                7.8M
closure bytes                  56314968
```

Cheap field-footprint baseline:

```sh
nix develop -c ./scripts/measure-cityb-footprint.sh
```

Output:

```text
field                                           value
host_arch                                       x86_64
host_kernel                                     Linux 6.12.34
bin_dir                                         target/release
cityb-node.bytes                          758648
cityb.bytes                               1426312
cityb-biggun.bytes                        1516456
cityb-node.capabilities_max_rss_kib       2416
cityb.capabilities_max_rss_kib            3332
cityb-biggun.capabilities_max_rss_kib     3216
```
