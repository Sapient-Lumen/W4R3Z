# City B free-service taxonomy

This note is a service-hunting map for CityB operators and maintainers. It is not a list of blessed providers. It explains which kinds of free public services can carry CityB pointer, heartbeat, route-hint, mirror, or archive-location material; what makes one instance better than another; and what evidence CityB needs before promoting a service from “interesting” to “usable”.

The working rule is simple: carriers are discovery, archives are truth, and council signatures are authority. A free service can make a message easier to find, harder to lose, or easier to recover from a partition, but it never becomes the source of truth merely because it accepted a post or returned bytes.

## What “free” means here

CityB should distinguish four postures:

- `free/no-account`: no signup, no card, no token, and a documented public upload or update path.
- `free/account`: signup and token are required, but the service can be used without paying.
- `free/manual`: a no-cost UI or drag-and-drop flow exists, but the operator must perform the publication step outside CityB.
- `free-tier`: no immediate money, but meaningful account limits, card requirements, resource quotas, or provider review may apply.

The mainline starter path should prefer `free/no-account`. `free/account` and `free/manual` are still valuable when they buy durability, listing APIs, stable raw URLs, or better operator clarity. Paid-only services do not belong in the default adapter plan.

## The service scorecard

When evaluating a new service, collect these facts before writing a native adapter:

| Question | Strong answer | Weak answer | CityB consequence |
|---|---|---|---|
| How does publication happen? | Single documented POST, TCP write, Git push, API call, or explicit manual packet | Browser-only flow with opaque JavaScript and CAPTCHA | Use native adapter only for documented stable mechanics; otherwise stage an operator packet. |
| What does publication return? | Final raw URL, raw download URL, API object with stable URL fields | Pretty viewer URL, delayed processing page, shortened link with unknown target | Probe only exact returned/download URLs and retain redirect/final-location facts. |
| Is the object byte-stable? | Fetched bytes exactly equal posted bytes | HTML wrapping, image recompression, antivirus replacement, content warning page | Keep as pointer text only or reject as `content-missing`/`parser-mismatch`. |
| Can receivers discover it later? | Static index, public API listing, release asset JSON, feed cursor, or operator-maintained manifest | Returned URL only | Returned-URL-only services need receipts or another service to publish the URL. |
| How long does it last? | Documented durable, documented TTL, or observed stable retention | Vague “temporary” behavior | Use retention classes and decay old observations instead of counting stale sightings. |
| What are the natural limits? | Size cap, rate window, expiry window, MIME behavior, deletion behavior, and redirect behavior are documented | Limits are undocumented or change during smoke runs | Keep low request budgets and fixture every observed failure. |
| What roots are shared? | Distinct provider, account, network, moderation, and copy roots | Same hosting stack or same upstream clone under different names | Diversity is the minimum root diversity, not the number of brand names. |
| How hard is operator use? | One command or one obvious UI step | Multi-step account ceremony, manual URL extraction, or hidden raw link | Put service-specific next actions in `deployment recipes` and `cycle next`. |
| What can be tested without the provider? | Real response examples can become fixture JSONL | Behavior is only observable live | Keep live smoke opt-in and add replay fixtures before raising trust. |

The most useful services are not always the most durable ones. A one-hour file host can be excellent for heartbeat and route-hint lanes. A static site can be excellent for a recovery card or index. A delete-on-download file host can be useful for one-reader wakeups but bad as a shared continuity mirror. The lane fit matters more than the brand.

## Service families worth hunting

### 1. Text paste services

Examples and sources: [paste.rs](https://paste.rs/), [dpaste API](https://docs.dpaste.org/api/), [paste.c-net.org](https://paste.c-net.org/), [Termbin](https://termbin.com/), rentry-style paste sites, and PrivateBin instances.

Best use: pointer, heartbeat, route-hint, and small operator notes.

Useful properties: raw text URL, no account, direct byte fetch, stable expiry field, simple posting, tolerant of short plain text, and no mandatory viewer page.

Adapter concerns: line ending normalization, HTML viewer URLs versus raw URLs, TTL defaults, rate limits, partial responses, spam filters, body size caps, and whether a returned URL is public immediately.

CityB posture: text paste services are first-class because they are cheap to probe and easy to fixture. They should default to `log-field` or `syntactic-semver`, not raw high-entropy blobs in natural text. The `free-deep-web3-10` bench adds native coverage for several classic paste engine families: Stikked, Pinnwand, LodgeIt, and LogPaste exact raw paths, plus rendered-token carriers that stay outside exact-byte promotion until repeated captures justify them. The `free-deep-web4-10` bench adds another mixed web/API set and explicitly models URL shorteners as redirect-token carriers rather than exact-byte mirrors. The `free-deep-web5-10` bench adds final-newline-normalized exact providers plus rendered-token and redirect-token providers, making those receive behaviors explicit in fixtures. CoShareX remains a built JSON-field candidate, but it is outside strict benches until repeated anonymous API runs stop rejecting live evidence.

### 2. Temporary file hosts

Examples and sources: [Filebin](https://filebin.net/), [0x0.st](https://0x0.st/), [Catbox tools](https://catbox.moe/tools.php), [Litterbox](https://litterbox.catbox.moe/), [/tmp/files API](https://tmpfiles.org/api), [Uguu API](https://uguu.se/api), [file.io](https://www.file.io/), [sendit.sh](https://sendit.sh/), [NullPaste](https://nullpaste.org/), [temp.sh](https://temp.sh/), [tmpfile.link](https://tmpfile.link/), storage.to, Gofile, pixeldrain, and bashupload-style services.

Best use: pointer files, heartbeat files, route-hint packets, and small mirror objects.

Useful properties: documented multipart upload, final direct URL, no account, content type preserved, no recompression, known max size, documented expiry, and predictable HTTP status on expired objects.

Adapter concerns: 5xx provider drift, wrong bytes, interstitial pages, Cloudflare/challenge pages, delete-on-download semantics, delayed availability after upload, anonymous quota, malware scanning replacements, download redirects, and services that return a share page instead of a raw object.

CityB posture: these are strong no-account surfaces, but every provider needs capture fixtures. The checked-in live fixtures prove why: Filebin, paste.rs, dpaste, Catbox, tmpfiles, Uguu, and Termbin repeated cleanly; 0x0, file.io, and storage.to repeatedly produced negative provider classes; and Litterbox moved from earlier 500-class drift to later exact-byte success while still sharing Catbox's provider/network root. September 15/16 captures promoted Filebin, paste.c-net.org, sendit.sh, NullPaste, temp.sh, and tmpfile.link into `free-stable` after date-separated exact-byte receive success, fixture replay, parser-diff agreement, and root-diversity review. Retained monitor evidence from September 17 through September 19 later showed repeated NullPaste fetch failures, so NullPaste moved back to `free-wide` until its anonymous raw URL receive path is repaired. Litterbox remains a `free-wide` bench service until its mixed history and correlation risk are worth adding to the easiest operator set.

### 3. Static site drops and pages

Examples and sources: [Netlify Drop](https://app.netlify.com/drop), [GitHub Pages](https://docs.github.com/en/pages), [GitLab Pages](https://docs.gitlab.com/user/project/pages/), [Codeberg Pages](https://docs.codeberg.org/codeberg-pages/), [Neocities API](https://neocities.org/api), [sourcehut pages](https://man.sr.ht/pages.sr.ht/), Surge-style CLIs, and static hosting offered by free code forges.

Best use: stable recovery pages, small static mirrors, static indexes, route-hint pages, and operator-readable runbooks.

Useful properties: predictable URL namespace, raw/static byte serving, index files, repository history or deployment history, no server code required, and public read without tokens.

Adapter concerns: account or manual UI steps, build latency, cache staleness, redirect aliases, branch/deployment configuration, per-site quotas, and whether the service rewrites paths.

CityB posture: static-site services should usually be staged adapters first. CityB should generate an exact site tree, manifest, upload guide, and post-publication probe command rather than pretending every host has the same API.

### 4. Code-forge text, snippets, releases, and artifacts

Examples and sources: [GitHub Gists](https://docs.github.com/en/rest/gists/gists), [GitHub release assets](https://docs.github.com/en/rest/releases/assets), [GitLab snippets](https://docs.gitlab.com/api/project_snippets/), [GitLab releases](https://docs.gitlab.com/api/releases/), Codeberg/Forgejo releases, Git tags, wikis, issue comments, and raw repository files.

Best use: durable pointer text, signed release notes, archive mirrors, route-hint pages, and operator provenance.

Useful properties: public raw URLs, public API listing, release asset fields, immutable tags or release history, account-level audit logs, and broad public read availability.

Adapter concerns: account/token requirement, API rate limits, repository visibility, raw URL rotation, redirects through CDNs, release asset upload choreography, issue/comment moderation, and accidental leakage of token-bearing API responses into receipts.

CityB posture: account-backed forge adapters can be native when token use is explicit and narrow. Release/page workflows can remain staged until CityB owns each provider’s full publication grammar.

### 5. Package registries and developer metadata

Examples and sources: [npm package metadata](https://docs.npmjs.com/cli/v10/configuring-npm/package-json), [PyPI JSON API](https://docs.pypi.org/api/json/), [Cargo registry index](https://doc.rust-lang.org/cargo/reference/registry-index.html), Maven metadata, OCI image labels, container registry tags, and Homebrew tap metadata.

Best use: durable public metadata, versioned route hints, pointer-like build metadata, and recovery indexes for operator-owned packages.

Useful properties: globally mirrored metadata, version history, raw index files, common developer cache paths, and stable public read APIs.

Adapter concerns: account ownership, package name ownership, irreversible publish or unpublish restrictions, policy enforcement, ecosystem norms, metadata field limits, long cache lifetimes, and accidental pollution of real dependency ecosystems.

CityB posture: keep this family as staged/operator-owned until a package is intentionally dedicated to CityB. Use format-preserving encodings and small metadata fields; do not treat registry consensus as governance authority.

### 6. CI logs, build artifacts, status badges, and job summaries

Examples and sources: GitHub Actions artifacts/logs, GitLab CI job artifacts, Codeberg/Forgejo Actions, SourceHut builds, public status badges, and scheduled static build outputs.

Best use: generated route hints, static indexes, proof-of-publication logs, and short-lived mirror artifacts.

Useful properties: repeatable build outputs, public logs or artifacts, predictable retention, links from commits/releases, and a clear schedule.

Adapter concerns: retention expiration, account/repo coupling, build minute limits, cache replacement, log truncation, ANSI/control sequence normalization, delayed publication, and difficulty distinguishing job failure from carrier failure.

CityB posture: start with staged workflows. A native adapter should know whether it is posting a repository change, waiting for CI, reading an artifact list, or probing a final static URL.

### 7. URL shorteners and redirectors

Examples and sources: [is.gd API](https://is.gd/apishorteningreference.php), CleanURI, TinyURL APIs, kutt.it instances, YOURLS instances, and operator-owned redirect pages.

Best use: secondary pointer indirection, human-copyable recovery cards, and quick route-hint links.

Useful properties: documented API, no account or free account, final-location discoverability, custom alias support, preview endpoints, and QR-friendly URLs.

Adapter concerns: redirects are not bytes, shortened URLs can be blocked independently, final targets can change only when the service allows it, API abuse limits, and some services preview/interstitial before redirect.

CityB posture: a shortener receipt should never count as a verified payload by itself. It can count as a route hint only after CityB follows and probes the final target.

### 8. Dynamic DNS, free DNS, and public zone metadata

Examples and sources: [DuckDNS update API](https://www.duckdns.org/install.jsp), [dynv6 API](https://dynv6.com/docs/apis), FreeDNS/afraid.org update URLs, Hurricane Electric free DNS, deSEC, and operator-owned TXT/CNAME records.

Best use: tiny route hints, moving rendezvous labels, stable aliasing for current indexes, and recovery bootstrap.

Useful properties: low-cost updates, TXT/CNAME support, explicit API tokens, public read through ordinary DNS resolvers, TTL control, and operator-owned domains or subdomains.

Adapter concerns: small payloads, resolver caching, negative caching, DNSSEC behavior, API token protection, provider rate limits, and overloading DNS with data it should not carry.

CityB posture: DNS is a pointer and alias plane, not an archive plane. It deserves a native adapter only when token scope, TTL, and record-type behavior are explicit.

### 9. Federated social, forums, chat, and public timelines

Examples and sources: [Mastodon status API](https://docs.joinmastodon.org/methods/statuses/), [Matrix client-server API](https://spec.matrix.org/latest/client-server-api/), Nostr [NIP-01 events and relays](https://github.com/nostr-protocol/nips/blob/master/01.md), Discourse APIs, Lemmy APIs, public IRC logs, and mailing-list archives.

Best use: multicast notices, human-readable route hints, public timelines, and operator-to-listener rendezvous.

Useful properties: public read, feed cursors, multiple independent instances/relays, human-readable context, timestamps, and reply/thread metadata.

Adapter concerns: account creation, instance moderation, federation delay, edit/delete semantics, rate limits, timeline cursor drift, relay policy differences, room visibility, message length limits, and whether raw public history remains fetchable without authentication.

CityB posture: this family is valuable for breadth and discovery, but it must be treated as noisy public feed input. Native receive adapters should start before native post adapters: parse public timelines, extract checksum-valid CityB material, and classify moderation or deletion separately from parser failure. The October 18 native Nostr probes cover Damus, nos.lol, and Primal with ephemeral keys, NIP-01 event signing, positive publish acknowledgement, independent `REQ` retrieval, exact content comparison, and best-effort NIP-09 deletion requests. That proves an event transport path, not durability, privacy, or deletion; NIP-11 relay limits and repeated soak evidence must inform any production listener. A separate Core NATS demo probe exercises exact simultaneous publish/subscribe over the official public example server. It is useful as an at-most-once heartbeat/event class precisely because it does *not* pretend an offline node can recover an old message.

### 10. Decentralized content networks and public gateways

Examples and sources: [IPFS public utilities](https://docs.ipfs.tech/concepts/public-utilities/), [IPFS gateway requests](https://docs.ipfs.tech/reference/http/gateway/), public IPFS gateways, operator-owned free pinning tiers, Hypercore/DAT-style feeds, and BitTorrent web seeds.

Best use: mirrors, content addressing, archive distribution, and redundant gateway reads.

Useful properties: content-addressed identifiers, multiple gateways, local pinning, public read, and receiver ability to validate the bytes independent of the gateway.

Adapter concerns: pinning durability, gateway rate limits, gateway blocks, content provider availability, discovery of CIDs/magnet links, and the difference between “content-addressed” and “available right now”. IPFS Foundation documents several public gateway hostnames as one shared best-effort backend, so aliases must not be counted as independent roots.

CityB posture: gateway retrieval and publication are separate capabilities. The October 18 probes therefore retrieve one fixed raw specification CID without setting `receive_exact` for the generated CityB payload. Pinata returned the five known bytes; the Foundation endpoint returned HTTP 521. Neither result proves anonymous publication, pinning, persistence, or outside-root archive capacity.

CityB posture: content-addressed networks pair well with signed archives because byte identity is already central. A CityB adapter should still record which gateway or relay was observed and avoid counting gateway diversity as archive authority.

### 11. Public documents, pads, notebooks, and calendars

Examples: HackMD/HedgeDoc instances, Etherpad instances, public Google Docs exports, public calendars, Notion public pages, Git-backed notebooks, and static markdown renderers.

Best use: human-operated recovery pages, operator notes, low-volume route hints, and collaborative runbooks.

Useful properties: public export URL, revision history, readable text, manual edit simplicity, and stable public sharing.

Adapter concerns: account requirement, edit permissions, HTML export wrappers, anti-automation, API quotas, hidden revision state, and whether public export URLs need cookies.

CityB posture: prefer staged/manual adapters unless a service exposes a clean raw export API. These services are most valuable for humans, not Tiny nodes.

### 12. Image, media, and attachment hosts

Examples: image hosts, video clip hosts, audio hosts, attachment CDNs, social-media media APIs, and QR-friendly galleries.

Best use: human-copyable cards, OCR-first recovery material, and redundant visual transport of pointer fragments.

Useful properties: original-file mode, no recompression for uploaded files, direct media URL, EXIF behavior known, alt-text/caption fields, and stable CDN paths.

Adapter concerns: image recompression, metadata stripping, transcoding, hash changes, thumbnails instead of originals, content scanning, and viewer pages that hide the original bytes.

CityB posture: use these only when the adapter can prove whether it receives exact bytes, OCR-readable rendered text, or transformed media. A transformed image is a different carrier family, not a failed filehost.

### 13. Webhook sinks, request bins, and form endpoints

Examples: webhook.site-style bins, RequestBin/Pipedream bins, public form endpoints, and temporary HTTP capture services.

Best use: operator diagnostics, receive transcript captures, callback testing, and provider-behavior research.

Useful properties: public event log, JSON export, raw request body retention, no account for short tests, and exact timestamp/header capture.

Adapter concerns: many are operator-visible only, logs may expire quickly, public event logs can leak metadata, and listeners generally cannot discover the bin unless its viewing URL is shared separately.

CityB posture: these are excellent lab tools and fixture sources. They are usually not field carriers unless the public event log is intentionally part of the deployment.

## Adapter promotion gates

CityB should promote a service through these stages:

1. `candidate`: the service family looks useful and has public docs or a simple observed flow.
2. `staged`: `cityb dead-drop post --adapter manual-drop` or a staged provider adapter can create deterministic payloads, upload guidance, receipt commands, and probe commands without mutating the service.
3. `fixture-backed`: real provider responses have been captured as `cityb.collector-fixture.v1` JSONL with body files or fetch errors and no credentials.
4. `native-receive`: `collect probe` or `collect cursor` understands the service’s documented receive behavior: raw URL fields, redirect expectations, expiry statuses, listing pagination, or non-enumerability.
5. `native-post`: CityB can publish through a documented low-friction API and immediately generate a receipt whose probe semantics match the receive adapter.
6. `default-set`: the service has enough uptime, clarity, root diversity, and fixture coverage to appear in `free-stable` or another easy operator path.

Most services should stop at `staged` or `fixture-backed`. That is not failure. It keeps operator options broad without making undocumented behavior look stable.

## What makes a service more useful to CityB

The best services have at least one of these advantages:

- exact byte retrieval through a URL that Tiny can fetch;
- a documented raw API that does not require browser automation;
- public read without authentication;
- stable negative evidence on expiry, moderation, permission failure, or rate limit;
- a feed, listing, index, or cursor so receivers can discover current objects;
- useful retention for the intended lane;
- distinct provider, network, account, moderation, and copy roots;
- low operator friction;
- clear size limits;
- predictable redirects;
- reproducible local fixtures;
- no paid dependency;
- no mandatory human attention after the initial setup.

The warning signs are equally important:

- a service returns a viewer page while hiding the real object;
- uploads succeed before reads serve the exact bytes;
- the receive URL is single-consume;
- free use depends on CAPTCHA or phone verification;
- content is transformed, compressed, renamed, or wrapped;
- account dashboards are the only way to discover objects;
- the service silently rewrites history;
- all “different” providers are clones of the same upstream service or same CDN path;
- provider docs and live behavior disagree;
- the service is useful only if CityB scrapes search results or guesses locations.

## Default service sets

Service-set definitions are durable; their membership is not. Any numeric
roster language retained in the dated chronology below describes that dated
observation only. Use the generated Stil snapshot and Rust catalog commands for
present state.

`free-stable` is the easy no-account set. Its live membership, latest exactness,
capacity ladder, and watch queue belong to `stil snapshot --json`, `stil
decisions --json`, and `cityb service ls --service-set free-stable --json`;
this taxonomy deliberately carries no present-tense count. Membership requires
repeated checked-in exact-byte evidence plus production Rust semantics, while a
provider may remain on a narrow recapture watch without pretending its latest
failed probe succeeded. `cityb up --free` selects the generated canonical set.
The dated promotion and demotion chronology appears below and remains historical
evidence rather than the current roster.

`free-five` is the older drift/regression set. It is intentionally small and currently contains Filebin, paste.rs, dpaste, 0x0, and Catbox. It is useful when the goal is to keep testing Filebin settle behavior and 0x0 provider drift without running the whole wide bench; Filebin no longer appears in `free-stable` because repeated September 25-26 retained monitor captures fetched token-missing receive bodies.

`free-wide` is the breadth set. It keeps 0x0 drift coverage, Litterbox's mixed-history Catbox-root evidence, and the still-negative file.io and storage.to cases alongside the stable adapters. It is useful for research, corpus capture, and field trials where the operator intentionally wants more public-service coverage and accepts more provider-specific failure modes. It should not replace `free-stable` as the easy path when those mixed or negative services are the reason for choosing it.

`free-deep-10` is the ten-provider research bench added on September 16, 2026. It contains x0.at, curl.by, End2End.tech, file2.me, JuiceBox, TempFile.org, ayaya.beauty, hostb, hst.sh, and haste.rys.pw. curl.by and End2End.tech entered `free-stable` on October 7; ayaya.beauty, hostb, hst.sh, JuiceBox, TempFile.org, and haste.rys.pw followed in the October 10 deep-bench source review. x0.at and file2.me remain watch/research providers. `cityb capture free-deep-10` still defaults to all ten selected services and a 10/10 pass requirement because the bench proves provider behavior rather than hiding drift behind quorum success.

`free-deep-text-10` is the second ten-provider research bench added on September 16, 2026. It contains paste.code-solutions.dev, paste.helpch.at, bytebin.lucko.me, api.pastes.dev, bpa.st, transfer.archivete.am, pastefy.app, pastefox.com, haste.zneix.eu, and bin.birdflop.com. The October 10 source review promoted paste.code-solutions.dev, paste.helpch.at, bytebin.lucko.me, api.pastes.dev, bpa.st, pastefy.app, pastefox.com, and bin.birdflop.com into `free-stable`; the first October 11 soak watch kept bytebin.lucko.me and api.pastes.dev stable for pointer-sized captures but moved both into the archive-ineligible lane after archive-shard drift. transfer.archivete.am and haste.zneix.eu remain watch/research providers. `cityb capture free-deep-text-10` still defaults to all ten selected services and a 10/10 pass requirement because the bench proves provider behavior rather than hiding drift behind quorum success.

`free-deep-web-10` is the third ten-provider research bench added on September 16, 2026. It contains mclo.gs, Sourcebin, paste.agradip.fyi, SpaceBin, CrafterBin, qurl.sh, Mythical Paste, YukiAPI, AgentMediaTools, and paste.firnsy.com. The October 10 source review promoted mclo.gs, Sourcebin, paste.agradip.fyi, SpaceBin, CrafterBin, qurl.sh, Mythical Paste, and paste.firnsy.com into `free-stable`; YukiAPI and AgentMediaTools remain watch/research providers. `cityb capture free-deep-web-10` still defaults to all ten selected services and a 10/10 pass requirement because the bench proves provider behavior rather than hiding drift behind quorum success.

`free-deep-web2-10` is the fourth ten-provider research bench added on September 16, 2026. It contains PasteHTML, OKFile, here.now, haste.unbelievaboat.com, rentry.co, files.offshore.cat, qu.ax, zoomie.sh, openSUSE Paste, and Debian Pastezone. These are anonymous web/API paste/file endpoints with native CityB post/probe adapters; several require provider-specific normalization, rendered-page token checks, form-token handling, or multi-step static-site publish/finalize behavior. The generated deployment gives those services pointer, heartbeat, and route-hint floors only; mirror floors are zero until later evidence proves archive-mirror value. `cityb capture free-deep-web2-10` defaults to all ten selected services and a 10/10 pass requirement because the set is meant to prove provider behavior. Repeated retained evidence promoted PasteHTML, OKFile, here.now, haste.unbelievaboat.com, files.offshore.cat, zoomie.sh, openSUSE Paste, and Debian Pastezone into `free-stable`; rentry.co and qu.ax are usable rendered-token carriers with `digest_match=false`, not exact raw-byte carriers.

`free-deep-web3-10` is the fifth ten-provider research bench added on September 16, 2026. It contains CentOS Paste, rpa.st, AlmaLinux Paste, OpenStack Paste, yt-project Paste, OpenDev Paste, Gentoo LogPaste, Ubuntu China Paste, p.defau.lt, and paste2.org. The October 10 source review promoted CentOS Paste, rpa.st, AlmaLinux Paste, OpenStack Paste, yt-project Paste, OpenDev Paste, and Gentoo LogPaste into `free-stable`; Ubuntu China Paste remains watch/research, while p.defau.lt and paste2.org remain rendered-token discovery carriers. `cityb capture free-deep-web3-10` still defaults to all ten selected services and a 10/10 pass requirement because the bench proves provider behavior rather than hiding drift behind quorum success.

`free-deep-web4-10` is the sixth ten-provider research bench added on September 16, 2026. It contains Pastr, Valhalla Paste, Write.as, p.ip.fi, Kagit, ShareNotes, Pastebin.ai, da.gd, TinyURL, and clck.ru. The October 10 source review promoted Pastr, Valhalla Paste, p.ip.fi, Kagit, ShareNotes, and Pastebin.ai into `free-stable`; da.gd, TinyURL, and clck.ru remain redirect-token discovery carriers, and Write.as remains watch/research. CleanURI is implemented but remains outside the strict ten after live probes created short URLs that returned 404 from this host. `cityb capture free-deep-web4-10` still defaults to all ten selected services and a 10/10 pass requirement because the bench proves provider behavior rather than hiding drift behind quorum success.

`free-deep-web5-10` is the seventh ten-provider research bench added on September 16, 2026. It contains Scuttled, ti.fo, docs-md, 8gwifi, tnypst, Droptext, Luis Aranguren Paste, Ulvis, MeshaLive, and AISense 307.fi. The October 10 source review promoted Scuttled, ti.fo, docs-md, 8gwifi, and tnypst into `free-stable`; Droptext and Luis Aranguren Paste remain rendered-token discovery carriers, while Ulvis, MeshaLive, and 307.fi remain redirect-token discovery carriers. `cityb capture free-deep-web5-10` still defaults to all ten selected services and a 10/10 pass requirement because the bench proves provider behavior rather than hiding drift behind quorum success.

`free-candidate-pool` is the investigation set. Its generated population and
native-probe tranche are reported by `cityb provider catalog --json`, `cityb
provider candidates list --json`, and `cityb monitor plan --json`, so this
taxonomy carries no live count. Candidates route through `filehost-generic`,
`manual-drop`, or `object-store-generic` until provider-specific evidence earns
provider-specific Rust. Entering the queue never proves stable membership:
promotion still requires date-separated exact fixtures, parser agreement,
production adapter semantics, topology review, and source review. The dated
candidate and near-miss evidence belongs to
[city-b-free-provider-candidates.md](city-b-free-provider-candidates.md) and
[city-b-provider-near-misses.md](city-b-provider-near-misses.md); the expansion
algorithm belongs to
[city-b-provider-expansion-plan.md](city-b-provider-expansion-plan.md).

The September 12, 2026 free-wide baseline is intentionally mixed: Filebin, paste.rs, dpaste, Catbox, tmpfiles, Uguu, and Termbin produced verified receive fixtures; 0x0 returned HTTP 503; Litterbox returned HTTP 500; file.io rejected the current unauthenticated POST path with HTTP 405; and storage.to returned a public share URL whose fetched bytes did not contain the expected token. A second same-day broad pass repeated the same seven verified services and four negative classes. A September 13, 2026 UTC broad pass repeated that split across a date boundary and added sanitized drift bodies: 0x0 upload-disabled text, Litterbox BunkerWeb 500 HTML, file.io object-method 405 HTML, and a storage.to Cloudflare challenge page. September 15, 2026 probes added paste.c-net.org, sendit.sh, NullPaste, and temp.sh as exact-byte free-wide successes, Litterbox also served exact bytes, file.io still lacked a proved anonymous POST/GET path, and storage.to still returned a challenge page for the public share URL from this host. The full September 15 UTC3 capture repeated that broad posture with twelve exact-byte successes and the same three negative providers: 0x0, file.io, and storage.to. `live-wide-2026-09-15-214716z-provider-fixtures.jsonl` then added retained tmpfile.link evidence for a JSON `downloadLink` on a separate download host. The September 16 broad capture produced thirteen exact-byte successes and repeated the same three negative classes: 0x0 `provider-disabled`, file.io `api-method-rejected`, and storage.to `provider-challenge`. After parser-diff and root-diversity review, Filebin, paste.c-net.org, NullPaste, sendit.sh, temp.sh, and tmpfile-link moved into `free-stable`; Litterbox stayed in `free-wide` because it has older failures and shares Catbox's provider/network root. Later monitor imports changed that posture: NullPaste produced repeated `fetch-failed` evidence on September 17, September 18, and September 19, so it moved back to `free-wide`. September 20-26 retained monitor evidence then moved Filebin, Termbin, and temp.sh back to the research/drift lane: Filebin repeatedly returned receive bodies missing the expected token on September 25 and September 26, Termbin repeatedly rejected uploads across September 21-25, and temp.sh repeatedly rejected uploads across September 20-22. At that point, Dpaste remained in `free-stable` as a watch item because its September 19 upload rejection has not repeated on another evidence date and later exact-byte recaptures exist. The September 26 `live-stable-2026-09-26-053215z-provider-fixtures.jsonl` monitor import passed the previous eight-provider stable set, including Dpaste. The September 26 source promotion then added eight exact-byte `free-deep-web2-10` providers to `free-stable`, bringing the easy set to sixteen providers while keeping rentry.co and qu.ax in discovery lanes. Imported September 30-October 7 monitor evidence then moved paste.rs and Catbox back to wider/drift benches after date-separated upload rejections, temporarily leaving fourteen providers in the easy set. October 7 source review then promoted curl.by and End2End.tech after repeated exact-byte successes on thirteen dates from September 16 through October 7, no retained failures, and Biggun parser agreement, bringing `free-stable` back to sixteen providers; the later October 7 native-adapter review promoted AISense Temporary Storage, bashupload.app, Kawaii Files, Stashr, temp-files, Tempcloud, and tmp0.cc into production Rust adapters and expanded `free-stable` to 23 providers. October 8 added beacon.host to `free-wide` after both native-candidate and normal production capture paths served exact bytes from returned public URLs; October 10 date-separated recapture and source review promoted it into `free-stable`, bringing the easy set to 24 providers. The later October 10 deep-bench source review promoted 40 additional exact-byte providers from `free-deep-10`, `free-deep-text-10`, `free-deep-web-10`, `free-deep-web3-10`, `free-deep-web4-10`, and `free-deep-web5-10`, while leaving rendered-token, redirect-token, and watch-only providers in research lanes. The fresh `live-stable-2026-10-10-220407z-provider-fixtures.jsonl` capture then passed all 64 stable providers. The first October 11 soak watch kept bytebin.lucko.me and api.pastes.dev in `free-stable` after later pointer-sized recapture, but marked both archive-shard ineligible after date-separated archive-shard failures. The October 12 source review moved Bashupload back to `free-wide` after repeated upload rejections on October 11 and October 12, leaving 63 active stable providers, 54 automatic archive-shard eligible providers, and a 31-shard nurse recommendation at that time. The October 13 evidence import kept HostB in watch after same-day exact-byte recapture and kept Stashr in archive-capacity watch after one archive-sized upload rejection date. The October 14 evidence import then moved Stashr back to `free-wide` after date-separated October 13-14 stable upload failures. The retained October 13 archive proof remains valuable historical evidence with 39/31 retained shards and release verification, but it was already stale against the then-current 62-provider stable set and is now superseded again by the October 15 61-provider set. The all-free passes left 0x0, file.io, and storage.to negative, left Litterbox, NullPaste, paste.rs, Catbox, and Bashupload as mixed-history research services, and added one `paste-ubuntu-cn` form-fetch failure in the deep-web3 bench. On September 17, Pastebin archive joined the listing corpus as a public-firehose listener, not as an exact-byte posting adapter: three low-rate public archive captures plus one synthetic title-placement fixture proved token extraction, no cursor, and no advertised expiry in archive rows. The same day added GitHub public Gists as a second listing provider: one unauthenticated public-API capture plus one synthetic description-placement fixture proved JSON listing rows, Link-header page cursors, `updated_at` recency fields, and token-only receive behavior. On September 19, both listing providers gained date-separated low-rate public captures and second synthetic placement rows; `promote-firehose` now promotes both Pastebin archive and GitHub public Gists into retained-local Tiny sweeps because both are declared `free-wide` public-firehose services after parser agreement. On October 7, FragBin public pastes became the next declared firehose soak candidate after one low-rate unauthenticated API capture; on October 10 it gained a date-separated capture and passed `promote-firehose` plus Biggun parser agreement as the then-third retained-local Tiny sweep provider. Goldilocks retains bounded listing/token cache state for promoted sweeps, while Tiny still reads only retained local listing objects. Fixture replay preserves provider failures and parser-diff uses exact-byte bodies, rendered/redirect-token bodies, and public-listing bodies as malformed/noisy receive inputs.

That chronology does not describe the current Tiny declaration: repeated HTTP
500 listing reads on October 17 and October 18 suspended FragBin. Pastefy's
date-separated October 18 and October 20 captures instead proved a bounded
full-content JSON listing with 50 rows, no expiry field, no effective query
cursor, and Biggun parser agreement. Pastebin Archive, GitHub public Gists, and
Pastefy are now the three promoted retained-local sweeps. Goldilocks gives
Pastefy an 8 MiB/4,096-candidate ceiling and retains only digest/observation
facts; Tiny reads only the small local projection.

The September 16, 2026 deep capture `live-deep-10-2026-09-16-122450z-provider-fixtures.jsonl` produced exact-byte receive evidence for all ten `free-deep-10` providers. It is the first checked-in corpus for x0.at, curl.by, End2End.tech, file2.me, JuiceBox, TempFile.org, ayaya.beauty, hostb, hst.sh, and haste.rys.pw, including File2 raw-path settle behavior and HostB chunked-upload receive normalization. The promoted exact-byte subset is now in `free-stable`; x0.at and file2.me stay in watch/research lanes until later evidence proves they improve the operator default.

The September 16, 2026 deep text capture `live-deep-text-10-2026-09-16-134253z-provider-fixtures.jsonl` produced exact-byte receive evidence for all ten `free-deep-text-10` providers. It is the first checked-in corpus for paste.code-solutions.dev, paste.helpch.at, bytebin.lucko.me, api.pastes.dev, bpa.st, transfer.archivete.am, pastefy.app, pastefox.com, haste.zneix.eu, and bin.birdflop.com. The promoted exact-byte subset is now in `free-stable`; transfer.archivete.am and haste.zneix.eu stay in watch/research lanes until later evidence proves they improve the operator default.

The September 16, 2026 deep web capture `live-deep-web-10-2026-09-16-150259z-provider-fixtures.jsonl` produced exact-byte receive evidence for all ten `free-deep-web-10` providers. It retains only public final receive locations, redirect/status facts, digests, provider notes, and copied payload bodies. The run also captured two adapter repairs: qurl.sh uploads to `/upload`, not the root URL; mclo.gs, Mythical Paste, and AgentMediaTools strip one final newline, so their CityB adapter stages a no-final-newline payload before upload. The promoted exact-byte subset is now in `free-stable`; YukiAPI and AgentMediaTools stay in watch/research lanes until later evidence proves they improve the operator default.

Further promotion to `free-stable` still requires date-separated exact-byte captures, fixture replay, parser-diff agreement, and root-diversity review. Litterbox has date-separated successes and a later same-day rejection, so its mixed history and Catbox-root correlation keep it in `free-wide` until it proves that it improves the easy path rather than merely duplicating a known correlated risk.

The same date also has a narrower stable corpus: paste.rs, dpaste, Catbox, tmpfiles, Uguu, and Termbin all replay verified. Use it as the quick public-service replay corpus when the goal is to test receiver behavior without the intentionally negative wide-service drift lines.

For live research, use the Rust-owned capture workflow:

```sh
cityb monitor install --live --enable-now
cityb monitor status
cityb capture free-wide --live --min-passed 8 --out fixtures/cityb/free-service-replay
cityb capture free-deep-10 --live --require-all --out fixtures/cityb/free-service-replay
cityb capture free-deep-text-10 --live --require-all --out fixtures/cityb/free-service-replay
cityb capture free-deep-web-10 --live --require-all --out fixtures/cityb/free-service-replay
cityb capture free-deep-web2-10 --live --require-all --out fixtures/cityb/free-service-replay
cityb capture free-deep-web3-10 --live --require-all --out fixtures/cityb/free-service-replay
cityb capture free-deep-web4-10 --live --require-all --out fixtures/cityb/free-service-replay
cityb capture free-deep-web5-10 --live --require-all --out fixtures/cityb/free-service-replay
```

`cityb monitor` is the preferred real-machine watch path. It stores retained captures and reports under `~/.local/state/cityb/provider-monitor` by default, checks `free-stable` every live run, rotates one research bench per run, collects Pastebin Archive, GitHub public Gists, and Pastefy through promoted bounded readers, keeps FragBin as a suspended research recheck, runs the native candidate probe tranche, and includes a read-only candidate plan. Its report treats infrastructure, stable lane, capacity experiments, promoted listings, research listings, and candidates as independent outcomes. Without `--live`, capture, monitor, and candidate-probe commands perform no remote mutation. With `--live`, capture creates a retained CityB root, posts through selected adapters, preserves transcripts, converts evidence, and prints the parser-diff command. `cityb capture` excludes public-firehose adapters because their operator path is `rendezvous collect-firehose`. Native candidate command success means classification completed; `provider_success` and `receive_exact` state the provider result. Use `monitor review` and `evidence sync --apply` to preserve retained facts. The curator's generation/high-water mark and the shared evidence index make that intake incremental and auditable. A stable-set change still requires repeated date-separated evidence and source review.

Rendered-token, redirect-token, and listing-token providers are discovery carriers. They may count toward pointer, heartbeat, or route-hint floors when the checksum-valid token leads to a council-signed archive that verifies. They do not count as exact-byte mirrors, they do not satisfy mirror floors, and they should not be promoted into `free-stable` as easy exact-byte providers. If CityB later needs an easy discovery-only preset, it should be a separate named preset rather than a hidden reinterpretation of `free-stable`.

Current correction: Dpaste is already outside `free-stable` after unresolved October 17 and October 18 failures; later exact recovery can earn review, but it is no longer waiting for a second failure. FragBin likewise remains in the bounded listing monitor but outside the declared Tiny sweep set after HTTP 500 on both dates. Pastebin Archive, GitHub public Gists, and Pastefy are the three admitted retained-local sweeps.

For an already-retained capture directory, the lower-level conversion command remains:

```sh
cityb collect live-capture \
  --deployment ./city-b-wide.toml \
  --capture-dir /tmp/cityb-live-free-wide-YYYYMMDD-HHMMSS \
  --fixture-out fixtures/cityb/free-service-replay/live-free-wide-YYYY-MM-DD-provider-fixtures.jsonl \
  --transcript-out fixtures/cityb/free-service-replay/live-free-wide-YYYY-MM-DD-transcript.jsonl \
  --case live-wide-YYYY-MM-DD \
  --date YYYY-MM-DD \
  --json
```

After conversion, run:

```sh
cityb evidence board --fixture-root fixtures/cityb/free-service-replay
cityb promote check --fixture-root fixtures/cityb/free-service-replay
cityb-biggun parser-diff --fixture-root fixtures/cityb/free-service-replay --require --json
```

### October 15 generation correction

The provider chronology above includes an October 14 sentence that calls the
then-current set 62. The October 15 import supersedes that snapshot: mPaste
repeated its expired-certificate failure across two UTC dates and moved to
`free-wide` without bypassing TLS verification. That generation had 61 stable
providers, 52 automatic archive-shard candidates, nine pointer/mirror-only
providers, and a recommended 30-shard reconstruction threshold. The October
13 archive proof is historical evidence and was stale by both Stashr and
mPaste; the October 18 Dpaste demotion superseded this generation again.

### October 17 soak reconciliation

The continuous monitor produced date-separated stable, rotating-bench, native
candidate, and archive-capacity evidence through October 17. `evidence sync
--apply` imported 2,767 retained evidence files into the checked-in replay
corpus. The October 16 stable passes were clean. Dpaste then repeatedly failed
local TLS issuer-chain validation on October 17 and failed again on October 18;
it moved back to `free-wide` after that repeated post-recovery evidence.
PasteFox and Spacebin are pointer-exact in their latest ordered observations;
their older challenge/upload failures remain transition and archive-capacity
evidence rather than current pointer degradation. Api.pastes.dev also
recovered in later timestamped observations. Bytebin recovered during this
October window, but subsequently rejected every required pointer capture on
November 2, 3, and 4. After generation-sealed evidence review it moved from
`free-stable` to the already observed `free-wide` lane; the native adapter and
all positive and negative evidence remain available for future recovery review.
FragBin's public listing
endpoint returned HTTP 500 again on October 22 after bounded retries,
so its live source remains suspended while older fixtures remain replayable.

The archive workflow was refreshed transactionally against the then-current
source generation. The older evidence plans are forensic history.
The October 18 signed production generation encoded the 7.1 MiB release,
retained 42 exact receipts, and collection reconstructed the planned SHA3-256
release bytes from the sufficient subset. The historical receipt margin was admitted
through persisted operator-selected OpenSSH release trust, then used to
regenerate the field pack and recovery card. Read the current shared capability
ledger from `stil snapshot --json`, not this dated narrative. An
upper-bound failure no longer erases a smaller proven
capacity; the adaptive probe targets the real plan width and then bisects the
proven/failing interval on later runs.

## Fixture facts to capture

Every real-service capture should try to preserve:

- service id and adapter id;
- lane and encoding;
- posted body file or explicit fetch/upload error;
- returned location;
- final location after redirects;
- redirect count;
- HTTP status or TCP failure class;
- response `Content-Type` when available;
- content length;
- expected pointer hex;
- parser result;
- provider-health class;
- timestamp and capture date;
- notes about expiry, one-shot consumption, challenge pages, or delayed availability.

Do not commit credentials, bearer headers, account identifiers, cookies, client IPs, provider dashboards, or private URLs. `cityb capture` and `collect live-capture` copy only payload files and summary facts from the retained capture directory, but an operator should still review the generated JSONL before committing it. The fixture should make the receive path reproducible without giving the repo any special authority.

## Near-term research backlog

The next high-value service hunts are:

1. More no-account paste/text services with raw URLs and predictable expiry.
2. More no-account temporary file hosts with direct byte fetch and documented upload endpoints.
3. Free static site hosts that can publish a generated CityB index with low ceremony.
4. Free account-backed forge surfaces with public raw read and token-scoped post.
5. Public feed/cursor systems where receive can be built before post.
6. Free DNS and redirect APIs for route-hint indirection.
7. Content-addressed mirror paths where CityB can validate the archive bytes independent of the gateway.

When in doubt, add the provider to the service worksheet first, write a staged recipe, capture real replay fixtures second, and only then make posting native.
