# CityB current rendezvous tranche

This document is the near-term execution plan for rendezvous work. The earlier
Rendezvous Evidence Workbench tranche is complete: durable service metadata,
fixture replay, bounded listing collection, provider health, plan diff,
topology scoring, parser agreement, retained seen-token state, promotion gates,
state-ratcheted slots, signed pointer-chain members, and Tiny's retained-local
sweep path all exist.

The current problem is narrower: keep discovery useful when one listing source
fails, a node misses several cycles, or public-anchor evidence changes.

## Current state

- Pastebin Archive, GitHub public Gists, and Pastefy are admitted retained-local
  Tiny sweeps.
- FragBin has successful October 7/10 parser evidence but HTTP 500 listing
  failures on October 17/18 and October 22. Its source declaration is
  suspended, and the latest negative read is retained in the rendezvous
  observation ledger.
- Tiny consumes only retained local objects named by an archive-verified
  pointer-chain member; it does not scrape public services.
- State-ratcheted schedules bind the previous verified archive root, epoch,
  lane, slot template, clock source, and PRF input digest.
- Tiny derives and probes concrete retained-local/file slot roots and labels
  absent or expired roots as anchor-recovery work.
- Biggun compares Goldilocks and Tiny parsers over the same firehose corpus and
  makes a newer listing failure override historical parser success.
- Durable anchor clients and the one-command recovery transaction exist.

## Priority 1 — keep the third source honest and earn a fourth

Pastefy completed the former third-source goal with October 18/20 captures and
Biggun parser agreement. The new goal is not a larger name count: it is to keep
all three admitted paths under dated observation and find a fourth meaningfully
different way to rediscover a generated location.

For FragBin or a new source, require:

1. bounded anonymous reads on at least two UTC dates;
2. retained raw-response digests and normalized safe facts;
3. exact cursor or page semantics observed in those responses;
4. expiry and deletion claims limited to what the rows actually expose;
5. retry, timeout, challenge, rate-limit, response-size, and candidate budgets;
6. noisy false-positive fixtures and parser-cost bounds;
7. Goldilocks/Tiny parser agreement;
8. a source review that identifies its operator/CDN/ASN/root relationship to
   the three existing sweeps.

Promotion remains:

```sh
cityb rendezvous promote-firehose --service SERVICE --json
```

Old parser fixtures cannot override newer network failure. A later FragBin
success reopens review; it does not automatically restore admission.

## Priority 2 — multi-cycle Tiny lookback

Tiny can follow the current verified next-cycle member. Extend that proof to a
bounded chain of missed cycles:

```text
stale field pack
  -> last verified pointer-chain member
  -> bounded lookback or skip member
  -> current retained slot/listing roots
  -> candidate archive shards
  -> signed archive adoption
  -> new pointer-chain member
```

The implementation must:

- verify every epoch, previous-root, plan-digest, and validity-window link;
- refuse rollback, fork, mixed generations, missing intermediate authority,
  and an exhausted lookback budget by name;
- cap lookback depth, input bytes, listing pages, token candidates, and durable
  writes;
- work from signed chain/floor records when dashboard projections are absent;
- preserve read-only and zero-write field profiles;
- fall back to the durable-anchor path rather than broad unbounded searching.

Biggun should exercise zero, one, and several missed cycles, expired listing
roots, stale packs, missing prior roots, duplicate reads, and anchor reseed.

## Priority 3 — empirical public-anchor continuity

The local proof machinery is strong; the remaining gap is repeated upstream
evidence. Accumulate and check in:

- date-separated drand rounds including a key/chain transition case;
- Rekor checkpoint signature, inclusion, and later consistency evidence;
- CT STH signature, inclusion, and later consistency evidence;
- public-key rotation and policy migration cases;
- split-view, rollback, missing-proof, stale-root, and unavailable-upstream
  failures with exact refusal names.

An anchor remains discovery. Only the retrieved signed archive chain can
authorize adoption.

## Priority 4 — bounded cache and cost truth

Keep the firehose receive path cheap and restartable:

- bound listing digests, token hashes, cursors, pages, bytes, and candidates;
- persist only safe normalized facts plus content-addressed retained objects;
- avoid refetching unchanged pages after restart;
- expire seen-state deliberately rather than growing forever;
- report parser time, response bytes, duplicate rate, false-positive rate, and
  useful-candidate yield in Biggun;
- let provider-specific cursor and expiry rules enter source only after dated
  captures prove them.

## Operator acceptance

The tranche is complete when an operator can answer, from `cityb next` and one
drill-down command:

1. Which listing sources are admitted and currently healthy?
2. What did the last sweep see, skip, reject, and retain?
3. Is a missing next plan a listing failure, expired slot, stale field pack,
   missing chain member, or anchor-recovery condition?
4. What exact bounded command should run next?
5. Will Tiny make any public network request, and under which reviewed policy?

No provider is promoted to satisfy a count, and no carrier observation becomes
governance authority.
