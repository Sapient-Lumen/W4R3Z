# CityB provider soak runbook

This runbook is the operator path before leaving CityB to continuously test public providers. A soak is not a single successful live run. It is repeated, date-separated evidence that the stable set still works across service drift, archive-sized payloads, listing/firehose changes, topology concentration, and retained evidence import.

Archive capacity is part of the standing soak, not an occasional trophy run.
Each live monitor tick records the capacity ledger and, when the retained plan
matches current `free-stable`, re-fetches at most one retained shard. Inspect it
directly with:

```sh
cityb dead-drop archive capacity --root ./city-b-artifacts --service-set free-stable --json
cityb dead-drop archive status --plan ./city-b-artifacts/city-b-archive-erasure/city-b-archive-erasure-plan.tsv --service-set free-stable --json
```

If status says `superseded-*`, do not collect it for adoption. Run the emitted
transactional `archive refresh` command; the previous receipts move to the
history tree and continue contributing forensic/capacity evidence. If status
says `current-ready` but `release_trust_configured=false`, configure `cityb
release trust` before collection. See `city-b-generation-and-capacity.md` for
the full state machine.

## Pre-soak acceptance

Run the monitor nurse first:

```sh
cityb monitor nurse --brief --json
```

Read expected source facts from the activated object rather than this file:

```sh
stil soak --json
stil decisions --json
stil snapshot --markdown
```

The generated report names stable membership, latest pointer exactness,
structural and spray eligibility, every capacity class, pointer-only members,
current receipts/threshold, evidence generation, fixture writability, timer
identity, and firehose rotation. Preserve it for a handoff with `stil snapshot
write DIR`; do not paste those changing values back into this runbook.

Archive plans and status call static adapter compatibility
`structural_adapter_support`. Current pointer health, dated payload capacity,
and spray usability are separate named rungs in the shared capability ledger.

`pre_soak_infrastructure_ready` is the structural facility gate: writable
evidence paths, enabled listing rotation, adequate source eligibility, and an
archive-erasure proof matching the active provider generation. Superseded
plans are archived forensic history. `pre_soak_ready` and `operational_ready` are
the stricter answer and also require a successful latest monitor run, matching
installed binary, an enabled and active systemd timer, no import backlog, a
sealed evidence generation, no curated fixture files waiting for source-control
handoff, and no provider-health attention. A clean installation without a
local curation watermark is not
manufactured into a backlog; after the first automatic import, generation and
fingerprint drift are authoritative. They are
therefore false whenever the timer has stopped, even if the latest retained run
was green. The nurse then prints the executable `systemctl --user enable --now
cityb-provider-monitor.timer` recovery action. Dpaste is no longer in
`free-stable` after repeated post-recovery October 17–18 failures.

Historical monitor passes and their exact adapter outcomes live in retained
reports and the curated fixture corpus. `stil decisions` separates their
non-blocking experiment findings from failures of required infrastructure or
the stable pointer lane.

The installed oneshot deliberately sends its successful JSON stdout to
`/dev/null`: the complete authoritative report is already retained under the
monitor state directory, and duplicating it into journald can consume tens of
megabytes per pass. Stderr and the systemd exit result remain journaled. Use
`monitor status` while `run_active=true`. During that interval, `cityb next`
will not recommend importing partially written captures, and external
`monitor review` / `monitor import` transactions fail closed. The monitor
process itself owns the birth-pinned lease and performs its final evidence sync
before publishing the new atomic `latest.json` report.

Use `monitor status`, `monitor nurse`, or the retained `reports/latest.json` for
run evidence rather than scraping service stdout. Retained run reports are
operational indexes rather than a second evidence store: successful step
output larger than 1 KiB is reduced to top-level scalar facts, bounded adapter
identifier arrays, omitted-field counts, byte length, and a SHA3-256 digest.
Exact failure output remains inline
for `monitor nurse` and `review`; full captures, replay bodies, parser evidence,
and the shared evidence index remain in their dedicated state and fixture
locations.

Every new run report also binds the observation to its exact executable
version, source revision, semantic build identity, artifact digest,
provider-set generation, start/completion epochs, elapsed time, selected
rotation index, and monotonic local run sequence. Reports form a fingerprint
chain. This does not make public-provider evidence authoritative or
tamper-proof, but it makes missing, reordered, stale-binary, and accidentally
mixed observations mechanically visible. Inspect the actual breadth of a soak
with:

```sh
cityb monitor coverage --window-reports 128 --json
```

Coverage names every represented UTC date, vantage and egress label, build
identity, research-bench rotation, and listing feed; it also reports sequence
gaps, fingerprint-chain breaks, whole-pass timing, the twenty slowest retained
steps, and older reports that predate provenance v2. Per-step elapsed time is
part of each new report so performance drift and a repeatedly slow provider
probe are evidence rather than an operator impression. Historical reports still
contribute service and rotation facts, but `evidence_ready` remains false until
provenance-v2 reports span at least two UTC dates; `legacy-only` and
`provenance-single-date` are explicit warm-up states, not green aliases.
`monitor status` and full `monitor nurse --json` embed the same bounded object.
Do not interpret `multi_vantage=false` as a provider failure: it says that this
state directory still proves behavior from only one named observation point.
The nurse also compares the latest report's provenance build identity with the
selected/installed executable. A binary replacement invalidates pre-soak
readiness until the installed command completes one pass with that exact build;
a successful older report cannot certify newer code.

A required infrastructure result now means the subcommand both completed and
reported success. A failed topology retention, evidence board, evidence sync,
archive ledger, stable capture, or promoted listing makes `monitor run` exit
nonzero after it atomically retains the failure report. Capacity experiments,
suspended/research listings, and candidate probes remain non-blocking findings.
For candidates, “finding” is semantic: a successfully completed classifier that
reports `provider_success=false`, a checked but non-exact receive path, or a
named failure is evidence work even though the command itself succeeded. The
reader derives this from retained step bodies as well as the stored aggregate,
so older provenance-v2 reports are rendered correctly without mutating them.
The candidate-probe list is derived from the provider catalog and native-probe
dispatch table on every run, so adding a native probe automatically places it
in the next soak without maintaining a second list.

The monitor also bounds its own operational debris. Inspect and compact it with:

```sh
cityb monitor compact --json
cityb monitor compact --apply --json
```

The first command is a dry run. The default transaction retains the newest 96
reports and 24 disposable capture workrooms, rewrites historical oversized
successful step output as content-bound summaries, and reports the exact
reclaimable allocated-byte count (not merely sparse/logical file length). It
does not prune imported replay evidence, the shared
evidence index, rendezvous observations, firehose objects, topology evidence,
or `latest.json`. Use larger `--keep-reports` or `--keep-captures` values when a
forensic investigation needs a longer operational tail.

Units generated by current `monitor install` run the same bounded compaction as
an `ExecStopPost` after successful *or failed* monitor execution, cap one pass
at 5 hours 30 minutes, kill the complete timed-out process group, and run at
low CPU/I/O priority. Reinstalling the unit is therefore part of upgrading an
older soaker. `ExecStopPost` is deliberately best-effort: cleanup failure is
journaled but cannot overwrite the newly retained provider result.

The live pointer/mirror-only roster is emitted by `stil snapshot --json`,
`provider health`, and `provider archive-roles`; do not preserve its count or
membership in this runbook. Providers in that class remain available for
pointer-sized exact-byte work but stay out of automatic archive-shard assignment
until stronger dated capacity evidence changes the role. Bashupload moved back
to `free-wide` after repeated October 11-12 stable upload rejections; Stashr
moved back after repeated October 13-14 failures. Both retain native adapters
and historical evidence without re-entering the easy set prematurely.

## Archive-sized proof before soak

Pointer-sized exact-byte health is not enough. The current stable set should also prove the archive path:

```sh
cityb dead-drop archive refresh --input ARCHIVE --root city-b-artifacts --service-set free-stable --data-shards 30 --parity-shards 31 --json
cityb dead-drop archive spray --plan city-b-artifacts/city-b-archive-erasure/city-b-archive-erasure-plan.tsv --apply --json
cityb dead-drop archive status --plan city-b-artifacts/city-b-archive-erasure/city-b-archive-erasure-plan.tsv --service-set free-stable --json
cityb release trust init --root city-b-artifacts
# After filling in and applying the printed trust command:
cityb dead-drop archive collect --plan city-b-artifacts/city-b-archive-erasure/city-b-archive-erasure-plan.tsv --service-set free-stable --require --trust-policy city-b-artifacts/city-b-release-trust.policy --json
```

The October 13 and October 17 proofs remain useful historical capacity evidence, but none represents current adoption. The October 18 signed production ceremony created a 60-shard generation with 30 required data shards and a maximum 491,939-byte shard. The live spray retained 42 exact receipts. The resulting 11-shard margin reconstructed the exact release digest, passed persisted OpenSSH release admission, and regenerated the field pack and recovery card. The planner excluded all nine pointer-only providers from actual shard assignments while preserving them in the provider-set snapshot.

`monitor run` performs the archive-sized soak check before the pointer/provider evidence steps, and `monitor status --archive-root ./city-b-artifacts --json` exposes the retained archive proof without contacting public providers. The key fields are `archive_soak_status`, `archive_soak_ready`, `archive_soak_received_shards`, `archive_soak_required_shards`, `archive_soak_provider_evidence_records`, nested `archive_soak.current_stable_set_match`, `archive_soak_command`, and `archive_soak_reason`. A healthy current proof reports `collect-ready` with matching receipts at or above its generated `archive_soak_required_shards`, retained archive-provider evidence, and `current_stable_set_match=true`; an unhealthy proof points at the exact refresh, spray, status, or collect command needed next.

## Normal operator cockpit during soak

Run:

```sh
cityb next --root city-b-artifacts --deployment city-b.toml --service-set free-stable
```

The cockpit should tell the operator:

- the primary command to run next;
- stable provider health and degraded providers;
- retained monitor evidence waiting to import;
- provider promotion/demotion/recapture questions;
- archive-spray readiness or collection status;
- topology/root diversity warnings;
- field-pack freshness and Tiny readiness;
- monitor timer state, next trigger, latest report success, and archive-soak status.
- non-blocking capacity/listing/candidate findings and retained monitor storage pressure.

If current-generation archive evidence exists, `cityb next` may prioritize
release-trust initialization or `dead-drop archive collect` above provider
inbox maintenance. A superseded generation can never produce that adoption
action: its receipts are forensic/capacity evidence, and the one immediate
action is refresh. Provider shards are only availability evidence until the
reconstructed bytes pass digest and persisted release-trust admission.

The monitor line in `cityb next --json` should include `monitor_reports`, `monitor_latest_success`, `monitor_timer_status`, `monitor_timer_active_state`, `monitor_timer_sub_state`, `monitor_timer_next_elapse_realtime`, `monitor_archive_soak_status`, `monitor_archive_soak_ready`, `monitor_experiment_findings`, and `monitor_compaction_recommended`. If those fields say `unavailable` while `cityb monitor status --json` sees an active timer, check that the current binary contains the central `--archive-root` parser support and reinstall the monitor if the service points at an older binary.

The same cockpit also exposes `monitor_evidence_inbox_generation`,
`monitor_evidence_sealed_generation`, `monitor_evidence_curation_pending`, and
`monitor_evidence_repo_handoff_files`. Curation and Git handoff are distinct:
the former proves which facts were selected and pruned; the latter proves the
selected corpus did not remain as an invisible untracked worktree delta.

`operational_ready=true` means the required infrastructure and stable lanes are
ready. It does not erase adverse results from deliberately non-blocking
experiments. Run `cityb monitor findings --json` for the bounded current queue:
capacity rechecks, research/suspended listing failures, candidate-probe
findings, and any actual stable/infrastructure failure remain separate and
actionable. This distinction lets a broken research endpoint teach CityB
without pretending that the selected stable pointer lane failed.

## Health inbox during soak

Run:

```sh
cityb provider health --service-set free-stable --root city-b-artifacts --json
```

Archive-sized failures are intentionally separate from pointer-sized failures.
One dated archive failure on a stable provider is a recapture/watch item. Two
date-separated failures at or below a previously proven size without later
success justify demotion or archive-ineligible source review. A failure only
above the largest proven payload records a capacity ceiling instead of erasing
the useful smaller class. The adaptive ladder targets the retained plan's real
shard width, prioritizes repair providers, and then bisects the proven/failing
interval. Provider health, explain, dossier, promotion-board, Biggun
soak-report, and the generated Stil snapshot expose both capacity and latest
ordered pointer health. Capacity probe v2 uses the digest embedded in the
shard; legacy v1 token/checksum misses are ignored because that oracle was
self-referential. Treat live operator output as authoritative rather than
copying a dated snapshot into automation.

Both adaptive capacity probes and retained-shard rechecks carry the monitor's
`vantage_id` and `egress_label`. That prevents archive expiry or retrieval
failures from becoming unlabeled pseudo-global facts when evidence from
additional machines is merged later.

## Evidence import loop

When the nurse or cockpit reports retained evidence outside the repo, run:

```sh
cityb evidence sync --state-dir ~/.local/state/cityb/provider-monitor --repo-fixture-root fixtures/cityb/free-service-replay --apply --json
cityb evidence curate --state-dir ~/.local/state/cityb/provider-monitor --repo-fixture-root fixtures/cityb/free-service-replay --json
# Run the generation- and fingerprint-pinned --apply command printed above.
git status --short -- fixtures/cityb/free-service-replay
```

Default sync and curation JSON are bounded summaries; add `--verbose` only when
the complete child reports or manifest are intentionally needed. Do not type an
unpinned curation apply command from memory: use the command printed by review,
so a monitor tick between review and apply causes a refusal rather than pruning
a different generation.

Evidence has more than one deliberate sink. `evidence sync` imports provider
post/receive replay records and bodies. Archive-capacity observations remain in
the retained archive evidence ledger; topology observations remain in the
topology snapshot; and live listing successes *and failures* append to the
retained rendezvous observation log. The last category is intentionally not
auto-promoted into the checked-in Biggun firehose corpus: fixture promotion is
a reviewed decision after date separation and parser agreement. `monitor
findings` is therefore the immediate listing truth, while Biggun's fixture
report is the curated promotion truth.

Direct `monitor review --json` output includes only pending import paths and
caps the preview at 64 rows; `monitor import --json` applies the same bound to
planned, copied, and skipped path lists. Both report omitted counts. Use
`--verbose` only for an intentional complete transcript. This prevents a
current 10,000-file corpus from turning a zero-backlog health check into a
multi-megabyte response.

Then rerun:

```sh
cityb provider health --service-set free-stable --root city-b-artifacts --json
cityb-biggun provider-reality --service-set free-stable --fixture-root fixtures/cityb/free-service-replay --firehose-fixture-root fixtures/cityb/rendezvous-firehose --archive-evidence-root city-b-artifacts/city-b-archive-erasure --required-shards 30 --json
cityb-biggun soak-report --service-set free-stable --fixture-root fixtures/cityb/free-service-replay --firehose-fixture-root fixtures/cityb/rendezvous-firehose --archive-evidence-root city-b-artifacts --required-shards 30 --json
```

Use `provider-reality` when you need the complete machine corpus. Use `soak-report` when you need the operator answer: latest provider streaks, drift classes, archive survival, replay evidence coverage, pointer-only stable providers, firehose breadth, retained topology concentration, and exact recommendations. With `--archive-evidence-root` pointed at the retained root, Biggun loads the same bounded topology snapshot used by archive planning and models loss of the largest observed root. Without that snapshot it says `unknown`; it never equates fixture coverage with topology. The raw corpus may still name a provider that failed before a source demotion; the recommendation layer distinguishes current-set failures from stale failures that are no longer in the active service set.

## Topology snapshot

Run live topology intentionally, not as an offline gate:

```sh
cityb rendezvous doctor --service-set free-stable --fixture-root fixtures/cityb/free-service-replay --root city-b-artifacts --live-topology --json
```

The generated topology section reports observed providers, strongest effective
roots, unknowns, largest-root concentration, and receipt survival after one-
and two-root loss. This is a correlated-risk model, not proof that the services
will fail together, and it prevents many brand names from being mistaken for
the same number of independent failure domains. Unknown topology remains
unknown; it is not mislabeled as either independence or collapse.

## Field-pack and recovery drill

Before soak, the retained root should pass the ordinary operator handoff path:

```sh
cityb up --root city-b-artifacts --deployment city-b.toml --service-set free-stable --max-events 1 --json
cityb check --root city-b-artifacts --deployment city-b.toml --json
cityb export field-pack --root city-b-artifacts --force --json
cityb field-pack status --root city-b-artifacts --deployment city-b.toml --json
cityb recovery-card --root city-b-artifacts --deployment city-b.toml --out recovery-card.svg --force --json
cityb-node kit verify --root city-b-artifacts/city-b-node-kit --json
```

The October 22, 2026 drill produced fresh field-pack digests, read-only and zero-write readiness, epoch 21 matching the chain, and zero Tiny kit verification breaks.

Archive-capacity soaking appends to the Goldilocks provider-evidence ledger.
The copy sealed into an exported node kit remains covered by that kit's
manifest, but later source-ledger appends are reported as an operational
snapshot and do not make the kit stale. Authority records, pointer-chain
members, shard plans/locations, chain/floor state, and every other comparable
kit file still participate in freshness. This distinction lets the soak keep
learning without manufacturing a field-pack re-export after every capacity
probe.

## Ready-to-soak definition

CityB is ready to soak when:

- monitor nurse reports pre-soak ready;
- evidence generation and sealed generation match, with no fixture handoff left untracked;
- the current stable set has a current archive-sized proof above the shard threshold;
- `monitor status` and `cityb next` both show an active or waiting timer and the same archive-soak state;
- `cityb next` names an actionable command and does not hide provider drift;
- provider health/dossiers distinguish stable, degraded, recovered-watch, pointer-only, and archive-shard eligible providers;
- topology concentration is visible through deployment-aware `rendezvous doctor|plan` output rather than inferred from fixture coverage;
- field-pack status is fresh and Tiny kit verification has zero breaks;
- a checksum-sealed `stil snapshot write DIR` artifact identifies the current
  counts, caveats, evidence generation, and retained root without copying them
  into prose.

After that point, the next work is not more command surface. It is evidence accumulation: let the monitor run, import retained evidence, rerun Biggun provider reality plus `soak-report`, and make stable-set decisions only from repeated dated reality.

## What the soak proves—and what it cannot prove

A retained live pass proves what its records actually observed from this
machine and egress: request execution, exact returned bytes, parser agreement,
failure phase, bounded payload capacity at the sizes exercised, later TTL
rechecks, listing behavior, monitor/timer identity, and the topology facts that
were successfully resolved. Repetition across UTC dates turns isolated facts
into drift and recovery history. Archive and listing experiments remain useful
negative evidence even when the required stable lane is green.

It does **not** prove global or regional reachability, distinct ownership merely
because hostnames differ, future retention beyond the observed recheck window,
capacity at unprobed sizes, resistance to a coordinated takedown, or semantic
authority. Unknown topology stays unknown. A provider carrying bytes never
becomes an authority: signed archive/release admission remains the adoption
gate. Claims about another ISP, country, device class, or long-offline node need
evidence from that vantage or the corresponding Biggun/field drill.
`monitor status`, `monitor nurse`, and `monitor findings` expose the same
boundary as machine-readable `evidence_scope`; automation should not widen
claims beyond that object.

Name each installation rather than merging anonymous machines:

```sh
cityb monitor install --live --enable-now \
  --vantage-id comfy-m21 --egress-label home-primary --json
```

Use a different stable `vantage-id` and descriptive `egress-label` on a second
operator-owned ASN/region, then feed its retained fixtures through the same
`evidence sync` and generation-pinned curation transaction. The labels are
provenance only; independence comes from retained topology/egress facts, not
from choosing a persuasive label. Stable-set and native-candidate transcript
records carry both fields, and evidence curation includes them in its semantic
identity, so equivalent observations from two real vantages are preserved
rather than deduplicated into one sample.
