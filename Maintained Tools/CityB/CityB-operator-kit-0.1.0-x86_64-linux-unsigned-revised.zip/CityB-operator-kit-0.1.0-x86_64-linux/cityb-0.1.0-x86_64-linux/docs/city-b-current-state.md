# Current CityB

This document is the current-state briefing for the standalone CityB repository. Read it when you need to understand what the repo is, what the binaries do, how the operator workflow fits together, what the provider evidence means, and which pieces remain research rather than dependable operation.

CityB is a resilient distribution and governance toolset. Its central rule is simple: carriers are discovery, archives are truth, and council signatures are authority. A paste, file host, URL shortener, local inbox, cursor report, screenshot, or gossip transcript can help a node discover candidate bytes; it cannot authorize a state transition. Adoption requires verification of signed archive material against the current constitution, roster, threshold policy, Merkle roots, epoch/serial freshness, and refusal rules.

The repository is a Cargo workspace because the three public binaries share protocol, transport, audit, council, operator, and lab code. It is still a standalone CityB repo: the user-facing product is `cityb-node`, `cityb`, and `cityb-biggun`, not the older broader Polis workspace.

Documentation audit status as of November 4, 2026: this file, the README, the operator workflow, the current operator campaign, the current rendezvous tranche, provider docs, fixture READMEs, standalone/release docs, and command help are the implementation references. The frontier, speculation, dream, long-form plan, and governance spec files preserve design reasoning and future work; treat their unimplemented proposals as roadmap entries unless the same fact appears in this briefing or passes an executable fixture gate.

## Generated current state

Do not copy provider counts, receipt margins, evidence generations, timer ages,
or topology concentration from this prose. Those values change whenever a soak
finishes, evidence is curated, a provider is reclassified, or a retained
generation advances. Ask the CityB product instead:

```sh
cityb brief --json
cityb next --json
cityb monitor status --json
cityb-biggun living --json
```

Those reports bind the selected CityB build, provider-set generation, latest
retained soak, capability ladder, archive generation, topology, field-pack,
correspondence, and primary action. Use their JSON for handoff and incident
notes; use dated fixture and receipt corpora for historical claims. On m21,
the optional personal `stil snapshot write` convenience wraps the same product
facts in an immutable directory with `SHA256SUMS`. Neither form is an authority
object: council signatures and release/archive admission remain the
state-transition gates.

## Product surfaces

| Binary | Role | Authority | Main use |
|---|---|---|---|
| `cityb-node` | Dependency-tiny verification/correspondence node | No governance keys or public-carrier posting; may hold a narrow node correspondence key and exchange bounded reports through an operator-owned spool | Field receiver, weak device, tiny VM, offline recovery kit verifier, bounded status correspondent |
| `cityb` | Goldilocks operator workbench | May hold operator material and may mutate remote services only through explicit commands | Normal laptop/VPS/server operation, publication planning, evidence collection, council workflow, release archive |
| `cityb-biggun` | Research, measurement, adversarial proof, and development truth binary | May run large local exercises and adapter/parser comparisons; adoption still requires signed archive verification | Truth cockpit, parser differentials, fixture replay, target checks, selftest, gates, footprint, lab scenarios |

The binaries report exact semantic/source/build/artifact/provider/release
identity through `version --json` and their roles through `capabilities
--json`; Stil projects those identities into every generated snapshot. The
primary targets are `x86_64-unknown-linux-gnu` and
`aarch64-unknown-linux-gnu`; `cityb-node` also keeps
`armv7-unknown-linux-gnueabihf` as a secondary check target when the toolchain
is available.

## Repository layout

The root build files are `Cargo.toml`, `Cargo.lock`, `flake.nix`, `flake.lock`, `rust-toolchain.toml`, `Justfile`, the public `nix/cityb-module.nix`, m21's personal one-file office `stil.nix`, and the separate inert Monsternix joint `stil-foundation.nix`. Nix is the normal developer environment; plain shell sessions may not have `cargo` on `PATH`. The flake's default app/package and `nixosModules.default` all mean CityB. The public module installs the three binaries, emits `/etc/cityb/runtime.json`, and supervises opt-in `cityb-*` services without creating a fourth role. `cityb next`, `check`, `brief`, `doctor`, and `operator card` consume its declared paths through `CITYB_RUNTIME_CONFIG`. `cityb system` uses the same credential-free descriptor for typed configuration, status, timers, bounded logs, identity-gating doctor, and explicit run/stop/restart by declared role; it refuses arbitrary unit names and checks loaded `ExecStart` paths against the exact package. The explicit `.#stil` and `nixosModules.stil` exports remain m21's resident payload and typed-action office. `stil-foundation.nix` separately translates one descriptor-bound encrypted operator-recovery snapshot into Monsternix custody inputs without adding service, secret-read, restore, or activation authority. See [city-b-nix.md](city-b-nix.md), [stil.md](stil.md), and [stil-foundation.md](stil-foundation.md).

The public CityB operator surfaces share one current-root readiness model:
`execution_success` says the command ran, while `operational_ready` says the
retained generation can perform its declared job without unfinished required
generation, release-trust, monitor, provider-health, archive, field-pack, or
configured correspondence-fleet work. Optional research and preparation for a
future generation do not make an admitted current root unusable. `next`,
`check`, `doctor`, the operator card, provider health, rendezvous, and monitor
status/nurse consume the same named capability ladder and emit one primary
current-root action plus an ordered after-that chain. Stil's concise briefing
adds `maintenance_ready`; its top-level `ready` is the conjunction of current
root and maintenance readiness. A healthy current root with a pending bounded
capacity probe is therefore honestly `ready-with-maintenance`, and its one
primary action is the exact `stil act` plan. A failed probe above a provider's
largest proven payload is a capacity ceiling, not erasure of its smaller
proven class. Pointer health, archive capacity, listing health, candidate
experiments, and monitor infrastructure remain independent outcomes.

A verified and collected retained cycle is also a terminal-ready state. If
the archive root has since advanced, low-level `cycle preview` describes the
next deterministic cycle, but `next`, `check`, and Stil do not treat that next
cadence as overdue work. The operator must choose to advance it. This makes
repeated typed actions converge instead of continuously manufacturing and
sealing a new pointer-chain act.

`next` and `check` also expose the availability axis directly:
`current_service_ready`, `current_service_state`, `service_availability`, and
`readiness_grade`. `current_service_state=ready-degraded` means the admitted
signed archive, reconstruction floor, release trust, and current field pack
remain usable while a stable-provider pass or correlated-root survival needs
maintenance. `readiness_grade=maintenance-required` means an ordered operator
action remains; it does not falsely mean the current CityB is down. `blocked`
is reserved for a current-generation admission, reconstruction, pointer-floor,
release-trust, or field-pack failure.

Readiness-bearing JSON no longer uses `success=true` for an operationally
unready report: `success` follows `operational_ready`, while
`execution_success` preserves the diagnostic/execution fact. `cityb check`
returns exit 1 on attention by default; `--allow-attention` requests a
side-effect-free report with exit 0. `cityb next --require-ready`, `cityb doctor
--require-ready`, and `cityb operator card --require-ready` provide the same
automation fence. When invoked through Stil, every rendered CityB action is
namespaced `stil cityb ...`; a conflicting bare `cityb` entrypoint makes Stil's
system doctor unready.

`cityb reconcile` is the current-generation ceremony: release build/sign,
persisted release trust, transactional generation refresh, explicitly live
spray, release-admitted collection, field-pack and recovery-card refresh, and
a final honest `next`. `release sign --apply` seals its OpenSSH
signature into the archive actually distributed and updates the archive digest
and manifest. `cityb recover` is the dry-run-first long-amnesia transaction
over anchor admission, signed chain verification, shard reconstruction,
release trust, and current handoff regeneration. Biggun's `anchor-amnesia`
drill proves that whole chain locally with a real Ed25519 signature and
erasure-subset reconstruction.

Completed Tiny kits, recovery cards, archive generations, and prior cycle
projections remain useful evidence, but none is called current merely because
this document once observed it. The brief compares epoch, digest, provider
generation, and release identity; a stale projection produces a refresh action
instead of `command=none`.

Adaptive capacity soaking rotates one bounded native provider through 4 KiB,
64 KiB, 256 KiB, and 1 MiB probes per live monitor tick and records earned
small/medium/large, capacity-bounded, recovered-watch, or repeated-failure
classes. After the first upper-bound failure it bisects the interval between
the largest proven and smallest failed payload rather than repeating the same
oversized request. Probe v2 verifies the digest already embedded in the shard.
The former v1 probe's self-referential token/checksum misses are ignored as
tool faults, while real v1 upload, API, and transport refusals remain evidence.
Service topology retains typed dated provider/operator, hostname, DNS family,
IP, ASN, CDN, hosting-root, confidence, and observation facts; unknown roots
are not counted as independent. Archive plans consume that snapshot and
balance assignments by observed root; Biggun models loss of a correlated root
instead of pretending every adapter is independent. The next-generation
preview jointly compares shard geometry, dated capacity evidence, and the
intersection of capacity-proven providers with observed roots. It will not
recommend a topology-safe geometry merely because capacity and topology pass
on two disjoint provider subsets. When no evidence-backed geometry survives
the selected correlated-loss policy, it names the missing capacity/root margin
and the exact probe width rather than rewarding a tiny threshold with enormous
unproven shards. Rendezvous reports provider carrier classes
separately from CityB system mechanisms. All three binaries expose source,
semantic build, artifact, provider-generation, and release identity through
`version --json`. The flake exports an opt-in
`nixosModules.default`/`nixosModules.cityb` module for monitor, local evidence intake, Biggun truth
timers, correspondence services, and field-node capsules, with public mutation
off by default. The detailed contract
is [city-b-readiness-reconciliation-and-recovery.md](city-b-readiness-reconciliation-and-recovery.md).

The crate map is intentionally narrow:

- `crates/cityb-core` owns protocol primitives: constitution, acts, bundles, Merkle roots, Ed25519 verification, canonical correspondence/HPKE envelopes, CBOR helpers, and engine state.
- `crates/cityb-council` owns key ceremonies, council coordination, signed acts, amendments, and duty helpers.
- `crates/cityb-transports` owns pointer formats, fragments, loopback transport helpers, file transport helpers, and shared parser/rendering code used by both Goldilocks and Tiny.
- `crates/cityb-audit` owns receipt, detector, chain, and audit helpers.
- `crates/cityb-cli` builds `cityb`, the large operator binary.
- `crates/cityb-node` builds `cityb-node`, the small verification and bounded-correspondence binary.
- `crates/cityb-lab` builds `cityb-biggun`, the large test/research binary.

The docs map is organized around use:

- [city-b-operator-workflow.md](city-b-operator-workflow.md) is the normal operator path.
- [city-b-correspondence.md](city-b-correspondence.md) is the operator/node inbox, fleet, crypto, gateway, and failure-model contract.
- [../README.md](../README.md) is the shortest source-tree command index and standalone identity note.
- [city-b-provider-model.md](city-b-provider-model.md) explains adapter, collector, fixture, cursor, and evidence mechanics.
- [city-b-real-service-adapters.md](city-b-real-service-adapters.md) records observed public-service behavior.
- [city-b-free-service-taxonomy.md](city-b-free-service-taxonomy.md) explains service families and promotion standards.
- [city-b-rendezvous-roadmap.md](city-b-rendezvous-roadmap.md) explains how provider function classes solve the Rendezvous Problem.
- [city-b-biggun-truth.md](city-b-biggun-truth.md) explains Biggun as the development truth cockpit.
- [city-b-maintainer-playbook.md](city-b-maintainer-playbook.md) is the amnesia-resistant maintainer handoff guide: cheap checks, expensive checks, Biggun next-action fields, provider-evidence discipline, and change-type validation.
- [city-b-next-rendezvous-tranche.md](city-b-next-rendezvous-tranche.md) is the current evidence-gated listing, multi-cycle lookback, and public-anchor execution plan.
- [city-b-standalone.md](city-b-standalone.md) explains packaging, release verification, and repository independence.
- [city-b-next-campaign.md](city-b-next-campaign.md) is the current operator-first execution order. [city-b-plan.md](city-b-plan.md), [city-b-frontier.md](city-b-frontier.md), [city-b-speculation.md](city-b-speculation.md), [dead-drop-dreams.md](dead-drop-dreams.md), and [research-program.md](research-program.md) carry the larger roadmap and preserved design ledger.
- [../specs/governance-protocol.md](../specs/governance-protocol.md) is the protocol reference and decision ledger.

Fixture evidence lives under `fixtures/cityb/free-service-replay/` and public-listing parser evidence lives under `fixtures/cityb/rendezvous-firehose/`. Captured replay bodies are marked as raw evidence in `.gitattributes` so third-party HTML indentation does not trip source whitespace gates.

## Authority model

CityB separates five things that are easy to conflate:

1. Governance authority: council threshold signatures over protocol objects.
2. Archive truth: signed archive bundles and Merkle-linked chain material.
3. Discovery evidence: carrier bytes, pointer tokens, fragments, heartbeat hints, route hints, and cursor sightings.
4. Operator state: retained roots, cycle journals, reliability rows, plans, and recovery kits.
5. Research evidence: fixture corpora, parser differentials, live-service transcripts, and Biggun reports.

Only the first two can make a state transition valid. Discovery evidence can wake a node, tell it where to fetch candidate material, show that a service is still useful, or help an operator repair distribution. It does not grant emergency power and it does not replace archive verification.

Remote mutation is explicit. Commands that plan, inspect, validate, preview, render recipes, run dry captures, replay fixtures, show evidence boards, or verify releases do not post to public services. Public-service mutation happens through explicit posting/capture/apply paths such as `cityb capture SET --live`, `cityb cycle apply`, `cityb cycle run`, or lane-specific `cityb post ... --apply`.

## Normal operator path

The operator should start with the short verbs:

```sh
cityb operator card --root ./city-b-artifacts --deployment ./city-b.toml
cityb up --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb check --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb next --root ./city-b-artifacts --deployment ./city-b.toml --json
```

`cityb operator card` is the zero-memory cockpit. The bounded default obtains one typed `next` snapshot, projects its named provider/monitor/field-pack facts without unscoped JSON searches, checks installation identity, and emits exactly the current command and reason without remote mutation. Release construction is not a deployed-runtime readiness dependency, optional shadow copies do not poison a Nix-managed installation, and the former ranked product-feature checklist appears only as a verbose reference inventory.

Routine cockpit reads are now bounded: `doctor`, `next`, and the operator card
use `field-pack status --quick` and expose `digest_checked=false` instead of
rehashing every retained shard copy. Full digest verification remains explicit
through ordinary `field-pack status`, `field-pack verify`, or `doctor --deep`.
Doctor JSON defaults to compact per-step summaries; `--verbose` restores nested
transcripts for diagnostics.

`cityb up` is the full happy path. It creates or validates the deployment, creates or checks the retained root, compiles the deployment, previews hazards, runs or resumes a cycle, collects verified material, reviews the retained root, exports a Tiny node kit, and prints the next action.

`cityb check` is the side-effect-free readiness gate. It validates the deployment, reviews retained state, previews cycle hazards when possible, reads cycle status, and exits 1 when operational attention remains even if every inspection command succeeded mechanically. Use `--allow-attention` only when a caller deliberately wants the report without enforcing readiness.

`cityb next` is the shortest recovery/action selector. It tells an amnesic operator whether to initialize, run, resume, collect, reconcile, review, repair a service, finish durable recovery, or export handoff material. It embeds `stable_provider_watch` with the failed stable provider, dated pass, exact dossier command, and wait-for-confirmation policy. `recovery` and `recovery_ready` project `anchor status` into the same snapshot, so ordinary availability and long-amnesia readiness can differ without either fact disappearing.

`cityb rendezvous check|classify|plan|next|diff|explain|doctor|firehose-fixture` is the main Rendezvous Problem surface. It accepts a service set or deployment file, reads fixture evidence when available, classifies services from durable deployment/catalog metadata, names missing rendezvous classes, scores effective root diversity, and prints one next action. Posting-set `class_counts` stay separate from `effective_class_counts`, which also credits clean declared retained-local Tiny sweep feeds. `free-stable` therefore remains a strict exact-byte posting set while Pastebin Archive, GitHub public Gists, and Pastefy provide three admitted public-firehose sweeps. FragBin remains implemented and monitored as a research/recheck listing source, but its Tiny declaration is suspended after HTTP 500 failures on October 17 and October 18. `diff --root RUN` compares the current declaration against the retained compiled deployment. `rendezvous doctor --live-topology --json` performs explicit network enrichment for DNS, IP, ASN, and CDN hints while default checks remain offline. `firehose-fixture --firehose-fixture-root DIR --require --json` and `doctor --deep` verify the local listing corpus before any reader is promoted.

`cityb rendezvous collect-firehose --service SERVICE --max-pages 1 --max-bytes 65536 --max-candidates 64` is the bounded firehose/listing reader surface. It is dry-run unless `--apply` is explicit; with `--apply --source URL_OR_FILE` it fetches one bounded listing page, retries only within explicit retry/backoff budgets, classifies failures, parses under the declared candidate ceiling, and can retain a content-addressed observation under `city-b-rendezvous-firehose/`. It maintains bounded listing-digest, token-hash, cursor-status, and last-source cache state and never posts to a provider. After an archive-verified pointer-chain member names an admitted service, Tiny scans only retained local listing objects and never scrapes the public web directly. FragBin continues to use this reader in monitor rechecks even though it is not currently an admitted Tiny sweep. Pastefy is admitted after date-separated captures and parser agreement: its provider-specific Goldilocks reader permits 8 MiB/4,096 candidates, retains only digest plus structural facts, and exposes no inferred cursor or expiry behavior. Tiny never retrieves the multi-megabyte public body.

`cityb monitor plan|run|install|status|review|import` is the real-machine provider watch path. The installed timer stores retained captures under `~/.local/state/cityb/provider-monitor` by default, checks `free-stable` every live run, rotates one research bench per run, checks listing-only providers through `collect-firehose`, runs provider-specific native candidate probes, and records archive-sized soak status for the retained archive root. `monitor status --archive-root ROOT --json` reports the installed service/timer, systemd timer clock facts, latest retained report, archive-soak status, shard counts, and the archive command to run next. `monitor review` compares retained monitor evidence to checked-in fixtures and flags urgent stable-set drift without editing promotion state. Its default JSON includes only pending import rows, bounded to 64 with explicit omitted counts; already-imported files no longer create multi-megabyte routine output. `monitor import --apply` copies retained JSONL/body evidence into the repo fixtures after review and bounds its path transcript the same way. Add `--verbose` to either command only when every path is deliberately needed. `cityb evidence sync` is the preferred inbox wrapper over review/import/provider-health/promotion-check; it is dry-run by default, uses `--apply` only for local fixture import, performs no network request, reports top-level `status` and `success`, reports `changed_summary` with providers/dates/success/failure/exact-byte counts, and prints the exact next command.

`cityb provider health --service-set free-stable --json` is the explicit provider inbox. It reads checked-in replay fixtures plus retained monitor captures, reports healthy and degraded providers, names evidence waiting to import, recapture needs, promotion-review candidates, and date-separated demotion candidates, then prints one next command. Its `triage_queue` is the operator-facing decision list: import retained monitor evidence first, watch healthy exact-byte mirrors, wait for a second date-separated stable failure before demotion, keep intermittent providers in the research lane, recapture providers with no retained evidence, and open a provider dossier before promotion. Each provider row now includes `decision_state` and `evidence_gate` so wrappers can display the gate without reverse-engineering action names. `cityb provider explain PROVIDER --service-set free-stable --json` is the one-provider view over selected-set membership, stable membership, fixture/monitor counts, dates, top failure, import files, and the next command. `cityb provider dossier PROVIDER --json` is the promotion decision page: it defaults current stable members to `free-stable` and other providers to `free-wide`; an explicit `--service-set` still wins. It names selected-set membership, stable membership, date-separated exact-byte gates, mixed-history caveats, parser-diff and topology commands, recapture command, and dry-run/apply promotion commands. `cityb provider promotion-board --service-set SET --json` is the whole-set promotion review desk: it ranks ready, native-adapter-required, blocked, recapture, firehose, watch, and already-stable providers, prints per-provider dossier and patch-plan commands, and can run parser/topology gates before recommending the first source-review target. `cityb provider stable-plan --from SET --to free-stable --json` now keeps repeated-green candidate probes in a `native_adapter_required` lane instead of hiding them as generic watch-only providers. `cityb provider patch-plan PROVIDER --action promote|demote|retire --json` is the source-level set-change planning page: it names the built-in Rust constants that would change, cites fixture and monitor evidence references, exposes top-level `status` and `success`, prints a `gate_summary`, reports exact success/failure date gates, points to evidence sync, dossier, parser-diff, and topology commands, embeds a unified source diff, writes only a reviewable plan file when `--apply` is present, and reports already-present/already-demoted/already-absent when no source change is needed. Undated historical stable-set failures are reported as undated evidence requiring a dated recapture rather than a fake failure date. `cityb provider promote|demote|retire PROVIDER --deployment FILE --json` is dry-run by default; with `--apply` it edits only valid local deployment metadata, creates a backup, validates the patched manifest, and never mutates public services. The JSON names `dry_run`, `safe_by_default`, `apply_required`, `local_mutation`, `deployment_mutation`, `fixture_mutation`, `public_service_mutation`, evidence requirements, and the exact `apply_command`, so a wrapper or tired operator can distinguish advice from mutation. `provider promote --apply` requires a fixture corpus with date-separated exact-byte evidence for that provider. `cityb service retire|demote|replace --deployment FILE --service ID --dry-run --json` remains the lower-level patch preview for service entries.

Provider curation now has an archive-sized lane. `dead-drop archive spray --apply` appends retained per-provider records to `ROOT/city-b-archive-erasure/city-b-archive-erasure-provider-evidence.jsonl`; `provider health --root ROOT`, `provider explain --root ROOT`, `provider dossier --root ROOT`, and `cityb next --root ROOT` read that file. A stable provider with one dated archive-shard failure is an urgent recapture/review item, two date-separated archive-shard failures without later archive-sized exact success justify demotion or archive-ineligible source review, and later archive-sized exact success clears the issue into watch. This keeps Debian Pastezone and tmp0.cc in explicit recapture posture after the October 10 archive-sized spray without pretending that earlier pointer-sized successes proved archive capacity.

`cityb next` includes rendezvous, provider-health, field-pack, archive-erasure, recovery, stable-provider watch, and promotion-plan context in the normal short operator path. Its output names the retained-root/cycle recovery action, retained Tiny sweeps, provider-health facts, field-pack freshness, archive state, current-service availability, long-amnesia readiness, and topology risk. Default human output is bounded; `--verbose` or `--json` restores diagnostics. `AFTER_THAT` is the actual second item in the same action chain. Old-build evidence is replayed first; then an unsealed evidence generation and incomplete source-control handoff precede a failed-stable-lane wait and every evidence-derived provider policy mutation. This preserves the real negative observation before the operator waits for a later dated pass. Archive status names static compatibility `structural_adapter_support`; dated capacity proof remains separate. Topology is rendered as `RISK_TOPOLOGY` in the compact cockpit. Tiny status reports pointer-chain shard-plan state after archive-chain verification. The current operator command-and-answer gap review is [city-b-operator-gap-review.md](city-b-operator-gap-review.md).

When archive-spray evidence is present, `cityb next` includes selected and global archive success, failure, exact-byte, and failed-adapter fields in the provider summaries. A retained archive-erasure plan still takes priority over background inbox work: insufficient receipts produce a spray command, sufficient receipts produce the release-verifying collect command, and provider-health archive counters remain visible so the operator can decide whether failed providers need date-separated recapture after the archive is safely reconstructed.

`cityb anchor ceremony` is the read-only durable-anchor runbook. It emits executable commands only after their values are known. Missing `source-id`, `trust-root`, Rekor UUID, CT URL, or CT public-key path appear as named `missing_inputs` in typed non-executable actions; wildcard roots and shell placeholders are never presented as “run now.” Likewise, an anchor status that needs an operator-selected source returns `command=none` with `input-required(source)` rather than fabricating `ANCHOR_URL`. The remaining anchor/Tiny verification contract is unchanged: retained policy, rollback/split-view/append-only checks, upstream-native drand/Rekor/CT proof status, Tiny resolve, and Biggun amnesia proof remain distinct evidence stages.

When retained chain, floor, archived pointer-chain, and field-pack evidence are
already `fallback-ready`, `anchor status` recommends the same side-effect-free
status inspection. It does not recommend regenerating the recovery card: that
would fail when the card already exists unless the operator deliberately chose
`--force`, and a ready-state command must be safely repeatable.

The useful intent verbs are:

```sh
cityb service ls --service-set free-stable --json
cityb rendezvous check --service-set free-stable --json
cityb rendezvous plan --deployment ./city-b.toml --json
cityb rendezvous next --service-set free-wide --json
cityb repair queue --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb post due --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb post due --root ./city-b-artifacts --deployment ./city-b.toml --apply --max-events 8 --json
cityb post pointer --root ./city-b-artifacts --apply --json
cityb explain event --root ./city-b-artifacts --event EVENT_HEX --json
cityb export field-pack --root ./city-b-artifacts --out ./field-pack --force --json
```

The expanded debugging path is still available: `deployment init`, `deployment validate`, `deployment compile`, `deployment recipes`, `cycle preview`, `cycle plan`, `cycle apply`, `cycle resume`, `cycle run`, `cycle status`, `collect`, `collect probe`, `collect cursor`, `collect fixture`, `collect fixture-template`, and `collect live-capture`.

## Retained root and cycle state

A retained CityB root is the operator’s working state directory. It contains compiled deployment views, normalized inboxes, cycle plans, per-event receipts, hash-linked event history, probe objects, reliability logs, review reports, node kits, recovery capsules, and dashboard projections.

`cycle plan` computes candidate work and writes a retained plan. `cycle preview` recomputes the same work without mutation and reports hazards. `cycle apply` mutates bounded planned events. `cycle resume` continues safe untouched work and quarantines ambiguous or interrupted outcomes. `cycle run` is the operator-short path that plans when needed, applies or resumes safe work, collects by default, and refuses stale, ambiguous, failed, expired, abandoned, or staged states that need explicit reconciliation.

Every event transition appends to a hash-linked history before the current projection is replaced. A one-record-ahead history can be repaired by the next locked operation; wider disagreement is treated as corruption and fails closed.

The planner respects lane floors, request budgets, rate windows, freshness decay, root correlation, and prior verified coverage. The relevant roots are `failure_domain`, `provider_root`, `account_root`, `network_root`, `moderation_root`, and `copy_root`; effective independence is the minimum diversity across those roots. A deployment with many brands but one shared backend does not get to pretend it has many independent media.

## Deployments and service sets

`cityb deployment init --service-set NAME --out city-b.toml` writes a concrete deployment manifest with durable service metadata and, where known, adapter default `base_url` values for topology enrichment. The important built-in sets are:

| Set | Count | Role |
|---|---:|---|
| `local-proof` | 1 | Safe local proof and default bootstrap; no public-service mutation. |
| `free-stable` | generated | Curated repeated-live no-account starter set for real operators. |
| `free-five` | 5 | Older Filebin/0x0/paste-rs/dpaste/Catbox drift bench. |
| `free-wide` | generated | Broader anonymous bench including unstable/negative services, normalized-field discovery adapters, event adapters, admitted retained-local Tiny sweeps, and suspended research/recheck firehoses. |
| `free-deep-10` | 10 | Strict research bench for first deep file/text provider set. |
| `free-deep-text-10` | 10 | Strict research bench for text/paste endpoints. |
| `free-deep-web-10` | 10 | Strict research bench for web paste/file endpoints. |
| `free-deep-web2-10` | 10 | Strict research bench for additional web/API endpoints. |
| `free-deep-web3-10` | 10 | Strict research bench with exact and rendered-token paste families. |
| `free-deep-web4-10` | 10 | Strict research bench with paste/API and URL-shortener redirect-token carriers. |
| `free-deep-web5-10` | 10 | Strict research bench with exact, final-newline-normalized, rendered-token, and redirect-token providers. |
| `free-candidate-pool` | generated | Generic/manual investigation queue, not native provider semantics. |
| `plugin-five` | 5 | External adapter proof set for operator-owned plugin experiments. |

Run `cityb service ls --service-set free-stable --json` for membership and
`stil snapshot --markdown` for its current capability ladder. Never infer the
easy set from a dated prose roster. Demoted providers remain implemented for
research, repair, and later recovery evidence; pointer health and archive role
remain separate. The easy public-service path still mutates public services
and must be chosen deliberately.

The October 14 imperfect-adapter pass added production `free-wide` adapters for PasteMyst, MantleDB, SuperJSONBlob, ExtendsClass JSON Storage, Botoi Paste, and ntfy.sh. The first five verify the complete staged payload after decoding a JSON string field. ntfy publishes to a fresh cached topic and verifies a final-newline-normalized payload through an independent bounded JSON poll. These are useful pointer, heartbeat, route-hint, and event discovery lanes, but they are deliberately excluded from archive shards because the raw carrier body is an envelope. The same pass added exact retained-publish/fresh-subscribe candidate probes for the EMQX, HiveMQ, and Mosquitto public MQTT test brokers; those remain candidate-only event carriers pending repeated dated evidence and a production listener contract. On October 18, Damus, nos.lol, and Primal gained native NIP-01 signed-event publish/ack/read probes; a later monitor pass observed one Damus acknowledgement failure while nos.lol and Primal remained exact, which is precisely why they remain candidate-only public discovery relays with best-effort NIP-09 deletion rather than durable stores. The public NATS demo server adds a separate native Core NATS live publish/subscribe candidate: after honoring the server's plaintext `INFO` then TLS-upgrade requirement it delivered exact bytes while listeners were connected, but intentionally makes no retained replay or missed-listener claim. Four read-only IPFS gateway probes now add content-addressed retrieval evidence without pretending to publish: Pinata, Filebase, and 4EVERLAND returned the specification's fixed raw `hello` block exactly on their latest manual pass, while the IPFS Foundation gateway returned HTTP 521. Neither a fixed known-CID receive nor a public gateway counts as an outside-root archive provider. The October 20 diversity tranche also added exact first-pass shz.al raw-body evidence, exact first-pass event evidence from three more independently operated Nostr relays, an unreachable Eclipse MQTT sandbox classification, and credential-gate classifiers for Simply Linux Paste and Thpaste; all nine are in the continuous candidate soak rather than a stable lane. The same soak includes an exact shiftr.io MQTT event path, a flespi token-gate classifier, three more exact Nostr event relays, a receive-only Bluesky Jetstream reader, and four receive-only Arweave gateway routes with distinct observed gateway identities where AR.IO metadata is available.

The production capture `live-imperfect-2026-10-14-193000z` exercised all six of those `free-wide` adapters through their real post/receive paths and retained six exact normalized payload fixtures; Biggun parser-diff passed those bodies. The continuous monitor independently recovered exact cached ntfy payloads and exact MQTT 3.1.1 retained payloads from all three public brokers. Its October 14 stable pass caught paste.firnsy.com presenting an expired TLS certificate after an earlier same-day exact success, and the October 15 stable pass repeated the certificate-expiry failure. CityB refused to weaken TLS verification and moved `mpaste-firnsy` back to `free-wide`; the native adapter and research-bench monitoring remain available for later recovery evidence.

The seven deep-ten sets are provider-evidence benches. They should normally run with `--require-all` so drift is visible instead of hidden behind quorum success. They are not shortcut flags for routine operation.

`free-candidate-pool` is a staged research catalog. `cityb provider summary`
reports its generated family and adapter totals; `cityb provider candidates
plan` ranks it into behavior-diverse evidence tranches and places the newest
staged tranche first. `cityb provider candidates capture --provider PROVIDER`
prints retained-root/deployment/recipe/fixture-template commands without remote
mutation. Generic candidates are not automatically tested: only native
stable/research providers, declared listing readers, and selected native probes
enter the soak. Dated expansion and outcome history belongs in the fixture
corpus and provider near-miss ledger, not in a present-tense count paragraph.

## Adapter evidence and public services

`cityb adapter doctor free-stable --fixture-root fixtures/cityb/free-service-replay --json`
and `cityb provider health --service-set free-stable --root
./city-b-artifacts --json` validate the easy lane and its ordered evidence.
`stil snapshot --markdown` renders the same named capability ladder without
flattening membership, pointer exactness, structural eligibility, spray
usability, capacity classes, receipts, and reconstruction threshold into one
ambiguous provider count.

Add `--root ./city-b-artifacts` or the relevant retained root when reviewing archive-byte work. That root lets provider health read retained archive-spray evidence and report `archive_success_records`, `archive_failure_records`, `archive_exact_byte_records`, `archive_failure_adapters`, and archive-specific decision states alongside the normal replay/monitor evidence.

`cityb evidence board --fixture-root fixtures/cityb/free-service-replay --json` is the high-level evidence view. It is side-effect free and answers which adapters have exact-byte evidence, which have drift or negative evidence, which dates are covered, and what the next capture action is.

`cityb evidence sync --state-dir ~/.local/state/cityb/provider-monitor --repo-fixture-root fixtures/cityb/free-service-replay --root ./city-b-artifacts --json` is the operator evidence inbox. It reviews retained monitor captures, dry-runs the import by default, imports with `--apply`, reports what providers, dates, and record classes changed, runs provider-health and promotion checks, optionally runs parser-diff, and returns one follow-up command. An explicit or discoverable retained root includes archive-capacity evidence. Listing-only providers are never treated as missing posting adapters: admitted sources remain `listing-only`/`firehose-review`, while suspended FragBin remains visible through monitor evidence until later recovery justifies source re-admission.

`cityb monitor nurse --state-dir ~/.local/state/cityb/provider-monitor --repo-fixture-root fixtures/cityb/free-service-replay --brief` is the provider-monitor care surface. It reports whether a latest monitor report exists, whether that report succeeded, the latest failed preset/service/adapter/failure summary when a required run failed, whether the installed service/timer files are present, whether the installed `ExecStart` targets the selected state directory, whether the installed monitor binary matches the selected binary, systemd timer facts, how many retained evidence files are waiting to import, whether provider health needs attention, degraded/urgent adapter names when known, non-blocking experiment findings, retained-state size/compaction pressure, and the exact import, reinstall, run, findings, compact, provider-health, or status command to run next. Retained monitor reports that stored a failed step as a plain string are still triaged; service-set mismatch text now points to the installed monitor run when the binary already matches and to reinstall only when the unit or binary is stale. Use `cityb monitor findings --json` for current capacity/listing/candidate findings even while required lanes are green. Use `--json` without `--brief` when the nested monitor-review, provider-health transcripts, and compact `latest_failure` object are needed.

Field-pack freshness separates mutable Goldilocks soak evidence from Tiny authority. The provider-capacity evidence JSONL copied into a kit is still verified against the kit manifest, but later appends to the retained source ledger increment `operational_snapshot_files` instead of marking the kit stale. Chain/floor records, pointer-chain members, shard plans and locations, governance state, and other comparable files remain strict freshness inputs.

Latest-report failures remain historical facts, but a provider-specific failure becomes the nurse's next action only while newer provider health still marks that provider degraded or urgent. A successful recapture therefore clears stale triage without rewriting the retained report.

The pre-soak nurse gate adds `success`, `pre_soak_ready`, `pre_soak_status`,
`pre_soak_infrastructure_ready`, the shared capability ledger, fixture-path
writability, topology evidence, and firehose rotation facts.
`pre_soak_infrastructure_ready` covers installed mechanical prerequisites;
`pre_soak_ready` also requires a successful latest run, matching binary/state,
no import backlog, and no provider-health attention. This is a launch readiness
check; it does not replace the longer soak.

The operational soak checklist lives in [city-b-soak-runbook.md](city-b-soak-runbook.md).

`cityb promote check --fixture-root fixtures/cityb/free-service-replay --json` applies the free-stable promotion rules. Promotion requires date-separated exact-byte captures, fixture replay, parser-diff agreement, and root-diversity review. Rendered-token and redirect-token carriers can be useful discovery lanes, but they are not exact-byte archive mirrors.

`cityb monitor plan|run|install|status|nurse|coverage|findings|compact|review|import` is the retained provider-watch surface for a real machine. It wraps archive-sized soak status, live capture, public-firehose collectors, evidence board, promote check, a read-only provider-candidate plan, and the native candidate probe tranche into one state directory. The default preset runs `free-stable` every tick and rotates one research bench per live run, so promoted providers and selected candidates are sampled over time without treating every timer tick as one giant public-service burst. The native probe tranche is derived from the canonical provider catalog and native dispatch table rather than copied into a second monitor list; a newly implemented probe therefore joins the next pass automatically. Capture steps only include postable adapters; Pastebin Archive, GitHub public Gists, and Pastefy are collected through bounded `rendezvous collect-firehose` reads instead of being counted as failed posting adapters, while FragBin remains a suspended research recheck. Native candidate probes include exact-byte first proofs, promoted-provider regression probes, archive-capacity repair probes, token-visible discovery probes, receive-only temp-email probes, event protocols, content gateways, and classified gated/near-miss providers so the soaker keeps building evidence instead of merely remembering research notes. A live run also retains one bounded topology snapshot and, after its captures finish, applies the local evidence-sync/import/parser-agreement transaction. Each report separates infrastructure readiness, stable-lane readiness, capacity experiments, promoted-listing readiness, listing experiments, and candidate probes; negative research findings do not make healthy required lanes look broken. Required commands must both execute and report success, and a required-lane failure now produces a nonzero service result after the exact failure report is retained. `monitor findings` makes negative experiments visible rather than laundering them through a green readiness flag. Successful step output is aggressively content-bound and summarized in operational reports, and `monitor compact` can transactionally bound old reports and disposable capture workrooms without pruning evidence ledgers. Current generated service units impose a 5.5-hour whole-pass deadline, low CPU/I/O priority, whole-process-group teardown, and best-effort post-pass compaction. Stable-set source promotion and demotion remain reviewed changes; the timer imports evidence, not authority decisions. The monitor is dry unless `--live` is explicit, and the installed user timer writes reports under `~/.local/state/cityb/provider-monitor` unless `--state-dir` is supplied. `--vantage-id` and `--egress-label` bind every run, report, stable transcript, candidate transcript, capacity probe, and retained-shard recheck to a named host/egress; status and nurse show configured and latest scopes separately, and curation preserves otherwise-identical facts from distinct vantages. Those labels make evidence mergeable across operator-owned machines but do not themselves prove ASN or regional independence.

New reports carry a persistent state-lineage identifier, monotonic run sequence,
exact executable/source/build/artifact/provider-generation identity, start and
completion epochs, elapsed time, rotation movement, and a predecessor report
fingerprint. Both the named report and `latest.json` are atomically published.
`cityb monitor coverage --json` summarizes actual dates, vantages, egresses,
builds, rotations, listing collectors, whole-pass timing, the twenty slowest
steps, and per-lineage sequence/fingerprint gaps in a bounded window. This is
auditability, performance-drift visibility, and omission detection, not a
claim that public observations are authoritative or tamper-proof. Legacy
reports contribute historical coverage but cannot make the self-auditing
window ready: provenance-aware reports must span at least two UTC dates.

The complete monitor transaction is single-writer. A birth-pinned
`monitor-run.lock` in the selected state directory prevents a manual run from
overlapping the systemd timer, because concurrent runs can otherwise collide
on compact timestamp names and manufacture false provider failures. A live
owner produces an actionable refusal; a dead PID or reused PID is detected by
its `/proc` start tick and recovered automatically.

### Evidence history through October 23

The long chronological paragraph below records the curated corpus through
October 18. The October 18–22 reconciliation immediately after it records the
newer retained/imported soak state and the applied source-control curation
decision.

The current fixture corpus includes same-day and repeated captures for stable services, cross-UTC-day free-wide captures, negative provider-drift bodies for 0x0/file.io/storage.to, true-OCR evidence, the September 16 deep provider benches through `free-deep-web5-10`, September 17/19 date-separated public listing corpora for Pastebin archive plus GitHub public Gists, October 7/10 date-separated public listing corpora for FragBin public API, October 8 and October 10 beacon.host exact-byte native-probe and production-capture fixtures, retained monitor evidence through October 18 across `free-stable`, the rotating deep benches, `free-wide`, and native candidate probes, the fresh `live-stable-2026-10-10-220407z` historical 64-provider stable capture, the October 11-17 watch captures, the October 13 EasySend/dropfile.dev/Warpbox/upload.83blue/pomf2/isrv.nl/fsend.me/pb.plz.ac/paste.gg/AnonHost/readm3/MDShare/dpaste.com/mystb/Pastey/ship.page/shipsite.co/Capsule/Pastebin1s/Webionite Bin/hastebin.cc/paste.ivr.fi/PasteShare/Kodi Paste/PastyX/WaifuVault/ShareY/MSK Paste/dpaste.org/Python Discord Paste/SquadRoom Paste exact-byte candidate fixtures, the October 13 Savedly/File2Share/AnonPaste Lite/Telegraph/Laravel Paste non-exact or rendered-token candidate transcripts, the October 13 initial JSON-field transcripts plus October 14 normalized-field-exact evidence for PasteMyst/MantleDB/SuperJSONBlob/ExtendsClass/Botoi Paste API, the October 13 Keyval token-only evidence, ntfy.sh cached-replay evidence, Webhook.site and Botoi Webhook webhook-JSON, and Npoint/JSONBin.io/JSONStorage.net/JsonBlob/webhooks.sh repair/gate transcripts, the October 13 near-miss ledger plus classified probe transcripts for adapter-worthy gated, repairable, mixed-evidence, and failed fits, and retained archive-spray/capacity evidence under `city-b-artifacts/city-b-archive-erasure/`. The October 10 live stable tick passed all 64 providers after the source-reviewed promotions moved exact-byte providers from `free-deep-10`, `free-deep-text-10`, `free-deep-web-10`, `free-deep-web3-10`, `free-deep-web4-10`, and `free-deep-web5-10` into `free-stable`; rendered-token, redirect-token, and mixed/watch providers stayed out. The October 11 watch kept bytebin.lucko.me and pastes.dev in `free-stable` after later pointer-sized recapture, but marked both archive-shard ineligible after date-separated archive-shard failures. The October 12 review moved Bashupload back to `free-wide` after repeated stable upload rejections on October 11 and October 12. The October 13 import kept HostB in `free-stable` as a watch item because same-date exact-byte recapture cleared its upload rejection, and kept Stashr in archive-capacity watch because one archive-sized failure date was not enough for demotion. The October 14 import moved Stashr back to `free-wide` after date-separated October 13-14 stable upload failures. The retained October 13 archive proof planned the then-current 63-provider stable set as 31 data plus 32 parity shards, assigned all 63 stable providers once, marked 54 automatic archive-shard eligible, live-sprayed those eligible providers, retained 39 verified receipts after 15 archive-sized provider failures, reconstructed the 5.6 MiB release archive, matched SHA3-256 `98a566eb79702d7238c7989f3b76bcc8f31f1284d4b9dbefc91826668bd38ea0`, and passed `release verify --signature-policy optional`; it is now archived forensic evidence and cannot produce a current adoption recommendation. CityB marks bin.birdflop.com, haste-unbelievaboat, paste.agradip.fyi, Valhalla Paste, Pastr, tmpfiles, zoomie, bytebin.lucko.me, and pastes.dev as archive-shard-ineligible despite pointer evidence because automatic archive payload behavior is stricter than pointer or staged/manual payload behavior. Filebin, paste.rs, Catbox, Termbin, temp.sh, bashupload.app, and Stashr are no longer in `free-stable`; bytebin.lucko.me and pastes.dev remain in `free-stable` for pointer-sized captures but are excluded from automatic archive shards until later archive-sized evidence changes that lane. FragBin historically passed the retained-local Tiny sweep gate, but HTTP 500 listing failures on October 17 and October 18 removed its declaration pending later exact recovery and source review. The retained root also has a live drand public-anchor capture from October 13 with `public_anchor_native_proof_status=drand-bls-signature-verified`, source proof required and accepted, append-only/consistency checks passing, and one retained history record. The native candidate probes continue to produce onboarding evidence rather than stable admission packets until repeated date-separated exact fixtures, parser agreement, production adapter semantics, and source review justify promotion.

### October 18–23 soak reconciliation

The October 18 all-free rotation added another date-separated stable capture,
listing checks, an adaptive archive-capacity probe, the rotating candidate
bench, and automatic evidence import. Dpaste failed again after its October 17
post-recovery failures, so source review moved it back to `free-wide` while
retaining its adapter and all forensic evidence. PasteFox returned a provider
challenge and Spacebin rejected an upload; neither has two unresolved
post-success failure dates, so both remain narrow recapture/watch questions.
FragBin's public listing endpoint returned HTTP 500 again after bounded retries;
its older accepted fixtures remain replay evidence, but it is suspended as a
live source. Pastefy's October 18 and October 20 anonymous captures both
returned the same bounded full-content JSON array, with 50 rows, no expiry
field, and no effective pagination cursor. The October 20 live Goldilocks proof
read 6,026,688 bytes under an 8 MiB/4,096-candidate limit, retained only digest
and observation facts, and passed the date-separated fixture and Biggun parser
agreement gate. Pastefy is therefore the third retained-local Tiny sweep;
Tiny consumes only its small local projection and never the public body.

Later October 18–22 rotations retained more stable, wide, deep-bench, and
candidate evidence. A narrow October 20 diagnostic recapture proved `p-ip-fi`
exact again; it remains pointer-stable and its preceding same-day failure is
retained as a transition rather than treated as the current verdict. PasteFox
is likewise pointer-exact but remains an archive-capacity repair case. Sendit's latest retained URL returned HTTP 404
after an earlier 496,221-byte success, so that observation belongs to the
retrieval/expiry phase and does not erase the upload or smaller-capacity proof.
FragBin remains explicitly suspended from Tiny sweeps after its current listing
failures. The imported fixture tree has no monitor import backlog. The 19:32 UTC
standing monitor added the ten protocol-diverse candidates, another stable/deep
rotation, and the `p-ip-fi` failure; the later narrow exact recapture closed that
current health action. The October 22 18:18 UTC pass kept the stable pointer
lane 60/60 exact, retained a bounded `paste-debian` adaptive-capacity failure,
retained one openSUSE bounded-recheck failure, and observed another FragBin
HTTP 500 without treating those experimental/archive findings as stable-lane
failure. `paste-c-net`, CentOS Paste, and openSUSE Paste now belong to the
archive-capacity repair mapping; the latter two await later-date evidence.
The October 23 overnight pass again completed the required stable lane 60/60
exact. Its Sendit archive recheck is classified as retrieval expiry after the
retained URL returned HTTP 404 at 491,937 bytes; this is not an upload
rejection. FragBin returned HTTP 500 again and remains a non-blocking suspended
listing experiment. The timer, current binary, archive proof, provider health,
and field pack were otherwise coherent.
The restarted 12:52 UTC rotation then proved `free-stable` 60/60 and
`free-deep-10` 10/10 exact. Its bounded archive recheck found the retained
Tempcloud shard expired with HTTP 404 at 491,937 bytes; FragBin again returned
HTTP 500. Both remain non-blocking experiment findings, not evidence that the
stable pointer lane failed.
The later October 23 capacity repair pass exposed a CityB probe defect rather
than 26 simultaneous provider failures: v1 searched each returned shard for
the digest of the already-completed shard file. The corrected v2 oracle uses
the embedded shard-byte digest. Ten providers then passed near the current
491,939-byte width, six earned exact smaller ceilings, eight retained genuine
upload/retrieval/byte-verification repair evidence, and eleven moved to
recovered-watch. The applied archive-role mapping is therefore 32 automatic,
8 repair, 11 recovered-watch, and 9 pointer-only; it does not rewrite the
already admitted 42-receipt generation.
The first October 23 applied `evidence curate` transaction reached generation
27 with sealed high-water mark 27. It considered
565 imported files, retained 176 decision-bearing JSONL/transcript files plus
their content-addressed bodies, and removed 389 redundant repository imports
and 615 verified raw state mirrors before source review; its repeated preview
was idempotent. After the repaired timer was restarted, the next rotation
reduced another 278 imports to 11 decision-bearing files plus one new canonical
body and sealed generation/high-water mark 29. The first explicitly labeled
`comfy-m21` / `home-primary` pass then considered 280 raw handoff files,
retained 11 decision-bearing JSONL records plus one content-addressed body, and
sealed generation/high-water mark 31. Review/apply is pinned to the reviewed
generation and source fingerprint, and soak readiness separately requires the
selected files to complete source-control handoff. Mixed provider/date/record-kind
outcome scopes include their observation identity, so green/failure/green
cannot be reordered by body deduplication; routine all-green same-day evidence
still folds normally. The first provenance-v2 live pass then completed all
required lanes, rotated `free-deep-web-10`, retained Qurl expiry and FragBin
HTTP 500 as non-blocking experiments, and imported 274 candidates. Curation
kept 121 decision-bearing records, pruned 153 redundant imports, and sealed
generation/high-water mark 33. A second exact-build rotation then retained four
decision-bearing JSONL artifacts plus one canonical body and sealed generation
35. The first system-managed Stil rotation then retained 164 decision-bearing
records plus 48 canonical bodies, pruned 111 redundant imports and 300
verified raw-state mirrors, and sealed generation 37. The shared evidence
index covers 3,334 decision records, 15,600 observations,
and 206 providers; its content-bound top-level JSONL fingerprint invalidates
the derived cache even when a same-size rewrite lands within one filesystem
timestamp tick. The retained curation manifest, generation
watermark, and index live below the monitor state directory; the selected
corpus is checked in here.

On October 24, the historical corpus itself was passed through the same
decision-bearing curator. The repository went from 14,407 artifacts and 7,562
body paths to 4,177 artifacts and 839 unique bodies while retaining 15,600
observations across the same 206-provider evidence domain. This repaired a real
Nix-store pressure bug: repeated local flake snapshots had hardlinked two
highly duplicated bodies until their deduplication inodes reached 65,535 links.
The flake now checks that replay body bytes are unique and that every canonical
body filename matches its SHA3-256 content. The reviewed transaction advanced
the evidence generation and sealed high-water mark together to 38.

The October 22 maintenance review found that operational reports and capture
workrooms had reached roughly 1.0 GiB even though decision-bearing evidence was
already retained in dedicated corpora. The reviewed `monitor compact --apply`
transaction removed 82 old reports and 328 disposable capture workrooms,
rewrote 96 retained reports as content-bound summaries, and reduced allocated
monitor state to about 129 MiB. It preserved 96 reports, 24 recent capture
workrooms, the retained monitor replay corpus, the then-20,805-record repo
corpus, the evidence index/curation high-water mark, `latest.json`, and the
rendezvous observation ledger. Future reports keep bounded adapter identifiers,
exact failure output, scalar facts, byte length, and source digest without
duplicating complete successful child reports.

The generated capability ledger distinguishes stable membership, latest
pointer exactness, structural archive eligibility, present spray usability,
capacity classes, pointer-only members, current-generation receipts, and the
reconstruction threshold. Larger failed probes record a first-failure ceiling
without erasing smaller exact-byte capacity, and pointer reachability is
evaluated independently. Superseded archive and cycle generations remain
forensic history and cannot produce a normal adoption action. Use `stil
snapshot --markdown` for the exact current generation, receipt margin, Tiny
epoch/digest freshness, read-only/zero-write facts, and action chain.

`cityb storage status|plan`
classifies current authority, trust, evidence, admission, forensic
generations, receipts, reproducible caches, transient staging, and unknown
protected material. Generated `city-b-biggun-truth-*` directories are
reproducible cache even though their names share the conservative `city-b-*`
prefix; unknown CityB material remains protected. `storage prune --apply` is allowlist-only and revalidates the root;
it never silently removes current generations, trust, evidence, admission, or
unknown paths.

`cityb disaster-recovery inventory|export|verify|restore` is the encrypted
operator-machine-loss ceremony. It inventories council/signing continuity,
release trust, anchor policy, correspondence fleet state, and generation
records; streams directly to `age`; validates bundle hashes without extracting;
and restores dry-run-first with atomic files and restrictive modes. It creates
no plaintext secret archive. Sensitive files require mode 0600 and their
directory requires 0700. Incomplete steps are typed as non-executable with
named `missing_inputs`; the report no longer prints fake `ROOT`, `FD`,
`IDENTITY`, or restore-destination placeholders as a next command. The October 26 Sandwurm drill used the sovereign
Argon2id mode through anonymous password pipes, verified and dry-ran the
encrypted artifact, restored every inventoried file into an empty workroom,
proved byte identity and restrictive modes, and removed all private drill
material. Its sanitized receipt is
[`fixtures/cityb/disaster-recovery/2026-10-26-sandwurm-handoff.json`](../fixtures/cityb/disaster-recovery/2026-10-26-sandwurm-handoff.json).

Future archive generations can be inspected without mutation with `cityb
dead-drop archive preview`. Given the exact release bytes, the command compares
bounded data/parity geometries, actual rendered shard widths, dated capacity
proof at each width, effective roots, and survivors/margins after loss of the
largest one and two observed roots. It ranks alternatives and emits a refresh
command only when the evidence is ready; otherwise it points to topology or
capacity collection. When no joint capacity/topology geometry is proven, the
honest answer is `capacity-evidence-insufficient` rather than a fictional ready
plan. An admitted generation remains valid until its own authority/admission
rules say otherwise; preview describes a possible future generation, not a
reason to rebuild current authority.

`cityb post dossier --root ./city-b-artifacts --deployment ./city-b.toml --free` is the posting preflight page. It joins retained-root and deployment presence, cycle preview, provider health, rendezvous/topology facts, topology severity and planner action, preview hazards, degraded/urgent adapters, per-lane service/adapter/encoding summaries, retained cycle-result receipt excerpts, a dry-run topology replacement plan when repeated roots matter, the exact `post due --apply` command, and the recommended next command. Add `--live-topology` only when the operator intentionally wants DNS/IP/ASN/CDN enrichment to influence replacement previews. `local-proof` single-root topology is reported as expected proof-path evidence, not a live-provider diversity failure. It never mutates public services; posting still requires an explicit `--apply` command.

`cityb field-pack status --root ./city-b-artifacts --deployment ./city-b.toml --release-manifest ./dist/cityb-...manifest.json --json` reports the runtime binary identity, deployment digest identity, optional release manifest identity, field-pack freshness, digest freshness, Tiny readiness, and read-only / zero-write readiness together. The release manifest is optional so copied field packs still inspect cleanly before a release archive exists.

`free-deep-web5-10` is the newest strict bench. Its exact or normalized-exact candidates are Scuttled, ti.fo, docs-md, 8gwifi, and tnypst; those five now belong to `free-stable` after repeated source-reviewed evidence. Its rendered-token carriers are Droptext and Luis Aranguren Paste. Its redirect-token carriers are Ulvis, MeshaLive, and AISense 307.fi. The checked-in corpus still matters for replay, parser-diff, and non-exact lane research, but only exact or intentionally normalized exact-byte providers enter the easy stable mirror lane.

## Encoding and parsing

CityB avoids treating all carrier bytes as raw high-entropy strings. Shared pointer encodings live in `cityb-transports::pointer_format` and are used by Goldilocks, Tiny, adapters, collectors, and Biggun. The current catalog includes plain tokens, semver-like build metadata, log-field records, status timestamp forms, signed-event tags, and mnemonic-card forms.

Receipts record the parser version, selected parser encoding, candidate count, checksum validation, and whether the expected pointer was observed. This matters because a carrier can look retrievable but still be semantically useless if Tiny cannot parse the same evidence Goldilocks produced.

Biggun’s `parser-diff` is the cross-binary guard. It generates valid and malformed carrier files for every shared format, ingests the checked-in public-service body corpus and rendezvous firehose/listing corpus, wraps real drift bodies as raw text, HTML, malformed HTML, and OCR-ish inputs, runs both `cityb` and `cityb-node` over the same corpus, reports total and maximum carrier bytes for parser-cost visibility, and fails under `--require` when candidate extraction or checksum-valid counts diverge. Repeated soaks can retain thousands of byte-equivalent observations, so execution is bounded: Biggun selects the newest routine body per provider/encoding and preserves explicitly named drift, HTML, malformed, noisy, redirect, rendered, screenshot, and OCR classes separately. The JSON reports `fixture_records_seen`, `fixture_records_selected`, and `fixture_records_deduplicated`; provenance files remain retained even when duplicate executions are elided. Generated corpus files are temporary and removed by default; `--keep-corpus` is an explicit debugging choice and is reported as `corpus_retained=true`.

Biggun’s `provider-reality` report is the corpus-level truth machine for provider drift. It replays retained provider transcripts, exact-byte fixture records, public-listing/firehose fixtures, and optional archive-spray evidence from `--archive-evidence-root` without contacting public services; classifies repeated exact-byte candidates, recovered-watch providers whose later exact-byte evidence clears older failures, mixed-watch providers, discovery-only lanes, failing providers, and firehose promotion readiness; reports pointer-lane date rows and a top-level `archive_spray_readiness` object so the operator can see whether a real pointer-evidence day had enough structurally eligible exact-byte providers for a modeled shard threshold; and emits separate archive-capacity, archive-loss, and retained-risk facts from archive-sized evidence. Archive successes and failures remain capacity evidence, but they never overwrite pointer streaks or latest pointer failures. Biggun `soak-report` adds the same `archive_capacity` buckets the operator inbox uses: proven, repair-needed, unproven, recovered-watch, pointer-only, and maximum observed archive payload. It complements `cityb provider health`: `provider health` is the operator inbox, while `provider-reality` is the lab evidence rollup over all retained corpora.

Biggun’s `anchor-amnesia` drill proves the local/imported durable-anchor path for long-dormant Tiny nodes. It builds a temporary drand-shaped public-anchor corpus, checks the Goldilocks anchor-status surface, proves `cityb-node anchor resolve --require-native-proof --apply` accepts a native-proof anchor, verifies the persisted Tiny anchor state, and proves Tiny rejects the same anchor when native proof is missing. It also builds a retained root, emits both state-ratcheted and public-bootstrap slot schedules, signs and publishes three consecutive pointer-chain members, exports their immutable history in a Tiny kit, seeds one derived retained-local slot, proves Tiny selects the newest archive-verified member across a two-epoch recovery span and probes concrete slot roots, exercises a stale-field-pack epoch, removes the newest slot roots, proves fallback to the preceding verified member, and finally proves the expired-slot fallback becomes `anchor_recovery_required` with `derived-slot-roots-missing`. Explicit `--work-dir` state is retained for inspection; default temporary state is removed after rendering unless `--keep-work-dir` is selected, preventing repeated deep truth runs from silently exhausting tmpfs. The checked-in empirical corpus now includes real drand captures through October 26 with verified chained BLS signatures, real Rekor entries whose RFC 6962 inclusion paths and signed checkpoint notes verify against fetched public keys, an October 23-to-26 same-tree Rekor consistency proof, and Google Argon 2026h2 heads whose fetched final leaves, RFC 6962 inclusion paths, signed tree heads, and consistency paths verify against the official log key through October 26. Earlier CT STH-only captures remain honestly unverified. The current Biggun drill passes all long-amnesia steps. Synthetic fixtures enforce rollback and split-view refusal deterministically; future empirical work should add date-separated root-rotation and split-view observations where upstream sources expose them. Signed archive verification, never the public anchor alone, still authorizes adoption.

The operator can now preview that same slot derivation directly with `cityb rendezvous plan --epoch E (--beacon TEXT | --beacon-file FILE)`. The report embeds `cityb.rendezvous-epoch-preview.v1`, including the prior-root binding, exact PRF-input digest, selected concrete locations, conflict/cursor/expiry facts, Tiny policy, and fallback routes. It is side-effect free and prints the exact `cityb dead-drop schedule` command needed to persist the plan. Epoch or slot arguments on non-plan rendezvous modes are rejected rather than silently ignored.

## Tiny verification and correspondence node

`cityb-node` is intentionally boring. It can initialize and validate config, provision public state, serve receive cycles, report status, render field-mode runbooks, inspect and verify artifacts, parse shared formats, import/scan/watch dead-drop feeds, collect fragments, inspect/verify recovery capsules, verify CityB roots, verify exported kits, and exchange bounded signed-and-encrypted correspondence with an operator-owned spool. Tiny exposes a verified `correspondence inbox`, parent-bound free-form `correspondence reply`, typed `correspondence result`, explicit `correspondence artifacts create`, and provision-bound offline courier import/export/inspection; Goldilocks exposes `sync`, `inbox`, exact-message `read`/`reply`, typed `task`, digest-only artifact requests, and merged `thread` views, so operator/node dialogue does not require hand-copying thread, parent, node, or sequence fields. A typed task is advisory data and never runs itself. A public-artifact manifest contains labels, sizes, and digests but no source path or content, so an automatic reply cannot become remote filesystem access. Goldilocks can bridge those explicit spool directories through bounded live ntfy, MQTT-retained, or Nostr NIP-01 routes without copying operator private state onto the field host; Tiny itself does not link the larger relay/TLS stack.

It cannot sign governance, publish public carriers, coordinate, amend, run city workflows, or link the lab machinery. It holds only a narrow correspondence private key and may mutate only its authenticated operator-owned correspondence spool. That identity can return status, fault, notice, and capability envelopes; it cannot authorize an Act or turn the node into an operator.

Correspondence provision changes now use an acknowledged cutover rather than an immediate local rewrite. Goldilocks stages an operator-signed candidate without changing live authority; the still-current node key acknowledges the candidate digest; the current operator key issues a commit; Tiny atomically installs the candidate and proves possession of its target key; only then does Goldilocks install the target registry, operator keyring, bearer, and local provision copy. An interrupted final installation is journaled and all ordinary registry work refuses it until `correspondence provision recover` finishes idempotently. `replacement-identity` removes old private generations from the target, retains their public records as revoked rejection evidence, and rotates the gateway bearer. Direct rotation commands are refused because they would strand offline field copies. The assembled October 20 proof completed all four phases, kept the field provision unchanged through staging, changed it only at activation, and finished with a clean correspondence doctor report.

The operational plane now also retains content-bound delivery acknowledgements, drains acknowledged down-spool work, and provides dry-run-first bounded compaction for Goldilocks sent/inbox/delivery/expired/relay evidence and Tiny inbox/seen evidence. Group fan-out preflights the selected active fleet and compiles distinct signed and HPKE-encrypted envelopes per node; it does not create a reusable group ciphertext. Tiny can emit scheduled typed status/fault capsules with deterministic positive jitter and durable per-day request and byte reservations, a retained-storage ceiling, and an explicit battery floor. The operator-owned gateway applies isolated per-node request and aggregate-byte minute windows. Its separately opt-in external-operator route accepts canonical signed five-minute requests from the active operator identity, applies a fixed `read|correspond|operate` CityB vocabulary, retains replay results, and never invokes a shell. A deployment can therefore grant a shared constitutional ChatGPT identity genuine correspondence-operator authority while leaving its mutable root under one authoritative writer. Signed public office kits carry public fleet keys, groups, health facts, bearer digests, and an optional credential-free relay plan, but no private node key, raw bearer, message body, route capability, or service credential; imported nodes are marked remote-only. Ordinary `relay exchange` sends and receives through a reviewed plan requiring two protocol families per represented node/direction and then runs verified `sync`. Offline courier bundles carry at most 128 opaque envelopes and 8 MiB with a content-derived bundle identity, dry-run-first Goldilocks/Tiny import and export, and one shared numbered QR-ready text codec. Tiny refuses a bundle for another node or the wrong direction. `correspondence relay slo` calculates local route objectives from privacy-minimized receipts; `correspondence incidents` caps its output and excludes plaintext bodies while pointing to exact local review commands, and the ordinary cockpit chooses it for authenticated urgent/fault attention. The NixOS module has opt-in timers for node capsules and multi-family relay soaking plus an nginx TLS reverse-proxy fixture that keeps the built-in gateway on loopback and does not open the firewall unless requested.

The October 20 live correspondence bridge proof carried three distinct encrypted status requests over ntfy.sh cached polling, nos.lol NIP-01 events, and test.mosquitto.org retained MQTT. Each landed in an explicit field spool without exposing operator correspondence keys, each was accepted exactly once by Tiny, and each produced exactly one encrypted reply. ntfy required the bridge's third bounded poll before its acknowledged publish became cache-visible; Nostr and MQTT were visible on the first read, and the MQTT retained value was explicitly cleared afterward. Biggun ingested the separate operator/field receipts, passed all eight deterministic relay-semantics cases, and recognized all three adapter families. The new reviewed relay-soak plan refuses a field direction with fewer than two protocol families, performs bounded send/receive runs through the ordinary bridge, and retains epoch-named reports; its persistent randomized Nix timer is the facility for gathering later-date evidence. This is still one dated reachability observation, not a retention SLA: a later UTC run must earn date separation, and protocol-family diversity does not by itself prove distinct operators or network roots.

The October 23 repeat exercised ntfy and Nostr with two encrypted envelopes per route. It first falsified an optimistic ntfy assumption: cached JSONL is oldest-first, so stopping after the first bounded entries could starve fresh frames on a long-lived topic. CityB now retains the newest bounded ntfy window, retries a bounded receive round, and declares a route green only when every successfully sent message identity is observed. The repaired live repeat verified two of two messages on both protocol families, and Biggun passed its eight deterministic cases plus the retained live-evidence gate. These observations remain single-host and single-egress; they are dated relay evidence, not multi-vantage reachability or a provider SLA.

The same date also proved the native `mqtts://` path against
`broker.emqx.io:8883`: publish, retained read, duplicate-safe spool handling,
and retained clear all completed with verified WebPKI broker identity.
`test.mosquitto.org:8883` presented a certificate rustls rejected as an
unsupported certificate version; that attempt is retained as failure evidence
rather than being counted as TLS success.

Field durability is a first-class concern. `field-mode` profiles describe tmpfs state, persistent directory policy, clock confidence, heartbeat-debt behavior, write budgets, crash model, and durable commit policy. `serve` enforces field-mode flags, validates volatile and persistent state paths, writes generation-numbered checkpoints with previous-generation fallback, rejects mismatched listener-plan identity, and reports field-mode state in status. Tests cover atomic-write failure points, read-only state directories, and true tmpfs-full write failure when the host permits the necessary mount namespace behavior.

`cityb cycle preview` reports `topology_severity` in addition to the topology object. Strict repeated-root failures still block live-provider confidence, but `local-proof` collapse is classified as `expected-local-single-root` so the proof path stays smooth while remaining honest about not proving provider diversity. `cityb cycle plan` writes `city-b-pointer-chain-member.json`, retains its immutable digest-named copy under `city-b-pointer-chain-members/`, and, when private council seat seeds are present, writes `city-b-pointer-chain-member-signed.json` plus a threshold-signed act in `city-b-store/`. `cityb cycle sign-pointer-chain --root DIR --deployment FILE` upgrades an existing deterministic cycle plan without touching event state or history, computes the next archive epoch from the retained chain tip, and refreshes expired pointer-chain acts without creating serial gaps. `cityb publish` reports pointer-chain archive acts when they are included in the sealed bundle. `cityb cycle status`, `cityb anchor status`, embedded `cityb node kit inspect|verify`, and standalone `cityb-node kit verify` now report archived pointer-chain act counts, latest archived epoch/serial, and whether the preferred source is `unsigned-planning-member`, `signed-member-pending-archive`, or `verified-archive-chain`. Tiny `serve` now bounds history to 32 one-MiB candidates, accepts only exact members whose digest appears in the verified archive chain, selects the highest verified next epoch, and consumes that member as durable runtime authority: it writes `state/pointer-chain.kv`, exposes candidate/verified/recovery-span and pointer-chain source fields in `cityb-node status`, restores a missing adopted pointer from the member's previous pointer only when that pointer verifies against the local signed chain, derives promoted retained-local sweep roots from the verified service list, de-duplicates them with configured text feeds, and scans them for next-cycle pointer tokens. `cityb anchor retrieve` is the local public-anchor intake hook with CityB-local source proof verification, while `cityb-node anchor resolve` is the receive-only Tiny intake for local/imported retained anchors after long amnesia. Remaining Tiny work is broader missed-cycle lookback and optional future remote anchor fetch budgets if the project decides Tiny should make direct public-anchor network reads.

## Biggun research and gates

`cityb-biggun` owns the heavy checks that should not leak into Tiny or the daily operator binary. The important commands are:

```sh
cityb-biggun living --max-report-age-hours 24 --json
cityb-biggun guide
cityb-biggun truth --plan --json
cityb-biggun truth --run --quick --json
cityb-biggun parser-diff --fixture-root fixtures/cityb/free-service-replay --firehose-fixture-root fixtures/cityb/rendezvous-firehose --require --json
cityb-biggun provider-reality --service-set free-stable --fixture-root fixtures/cityb/free-service-replay --firehose-fixture-root fixtures/cityb/rendezvous-firehose --archive-evidence-root ./city-b-artifacts/city-b-archive-erasure --required-shards 30 --require --json
cityb-biggun soak-report --service-set free-stable --fixture-root fixtures/cityb/free-service-replay --firehose-fixture-root fixtures/cityb/rendezvous-firehose --archive-evidence-root ./city-b-artifacts --required-shards 30 --json
cityb-biggun erasure-matrix --json
cityb-biggun anchor-amnesia --json
cityb-biggun replay --root ./city-b-artifacts --require --json
cityb-biggun footprint --json
cityb-biggun targets --check --json
cityb-biggun selftest --quick --json
cityb-biggun gate --quick --json
```

`guide` is the amnesia-safe Biggun maintainer card for future agents. `living`
is the read-only provider-monitor state report: it reads retained monitor runs,
monitor fixture evidence, repo fixture evidence, import backlog, latest failed
steps, the evidence inbox/sealed generations, repository handoff count, and
provider-role policy currency without running public-service probes. It cannot
report `healthy` merely because monitor files were copied: the generation must
be sealed, the curated corpus recorded in source control, and the retained
archive-role policy evaluated against that evidence. `--require-ready` turns
that definition into an exit-code gate. `truth` is the development cockpit over
the local evidence stack. The quick tier runs identity, matrix, living,
mutation-corpus, erasure-matrix, deterministic correspondence-relay study, and
provider-reality checks; the deep tier adds parser-diff and anchor-amnesia; the
full tier adds the standalone quick selftest. Truth plan/run JSON includes
next-action fields so weak maintainers do not need to infer the next command
from step arrays. It performs no public-service mutation. Deep and full runs
may write temporary local proof state under `--work-dir`.

`correspondence-chaos` attacks the signed/encrypted message lifecycle with twenty-two named cases: duplicate and delayed delivery, replay, expiration, forgery, registered-key theft before and after revocation, stale provisions, simultaneous route loss, operator rotation, outbox exhaustion, six-month disconnection, authority smuggling, the acknowledged replacement ceremony, revoked replacement-identity re-entry, archive-before-current-provision ordering after long amnesia, typed task/result identity, malformed typed tasks, a 256-reply equal-sequence/stale-clock concurrency storm, digest-only public-artifact vocabulary, courier tamper refusal, remote-operator command/result binding, and public office-kit tamper refusal. The ordinary implementation additionally proves node-bound thread continuation, monotonic sequence allocation across automatic and explicit replies, short-ID ambiguity refusal, pending-up cockpit priority, terminal-safe typed-body rendering, dry-run courier behavior, bounded body-free incident output, and evidence-derived route-objective classification. `correspondence-relay-study` separately attacks carrier assumptions—MQTT last-value overwrite, ntfy cache expiry, Nostr duplicates, cross-route loss, route-identity mismatch, payload ceilings, and malformed frames—and can ingest the exact bounded CBOR receipts written by live bridges. This keeps a successful relay write distinct from verified correspondence intake and gives live work a reproducible Biggun evidence path.

The deterministic relay study is also part of `cityb-biggun truth --run
--quick`; retained live evidence remains an explicit input because the truth
cockpit must not silently guess which operator or field receipt roots belong
to a deployment.

`selftest` composes the three binaries, proves no-live capture dry runs, release planning, target/footprint/parser reports, the easy operator path, and retained exercises. `gate --quick` is the normal local readiness recipe over formatting, workspace checks, binary integration tests, binary build, standalone selftest, and `git diff --check`; larger `--full`, `--doc`, `--target-check`, and `--release` variants exist when the proof needs to expand. Default gate work under `target/cityb-biggun-gate` is bounded to the newest five generated runs; explicit `--work-dir` evidence is never pruned. The default Rust Biggun binary test suite skips the full retained `exercise` stress proof; use the ignored test or the `exercise` command directly when a host is intentionally assigned to that heavier evidence run.

Biggun also owns mutation corpus checks, fragment matrices, archive-byte erasure matrices, provider-reality replay, long-amnesia anchor drills, correspondence relay study, gossip matrices, gossip-evidence verification, lab scenarios, handoff/exercise drivers, and release/target measurements.

`cityb dead-drop archive refresh --input ARCHIVE --root DIR --service-set
free-stable` is the normal archive-byte distribution path. It builds a staged
generation, archives the prior generation, and installs an empty-receipt plan
for the current provider snapshot. Generation identity binds the archive,
provider set, concrete assignment set, service-set name, and erasure
parameters. Receipts from another generation never count. `archive status
--service-set free-stable` reports exactly `current-ready`,
`current-incomplete`, `superseded-ready-for-forensics`,
`superseded-incomplete`, or `invalid`; superseded and invalid plans have no
normal adoption command.

The planner writes systematic `cityb-systematic-cauchy-rs-gf256.v1` shards.
New plans wrap each shard in `cityb.archive-erasure-shard.v2` with canonical
RFC 4648 Base64. That removes the old hexadecimal envelope's 2x expansion,
while the parser retains read compatibility with admitted
`cityb.archive-erasure-shard.v1`/`payload_hex` evidence. Plans and manifests
name the envelope and payload encoding explicitly; capacity evidence continues
to describe actual transmitted bytes and therefore remains comparable across
both envelope generations. If any native exact-byte providers are present,
pointer-only providers remain in the provider-set snapshot but receive no
shard. Assignment balances exact providers and topology roots while consulting
maximum proven archive payload and watch/failure evidence. `archive stage` prepares operator packets;
`archive spray --apply` and `archive receipt --apply` retain generation-bound,
exact-byte receipts; and `archive collect --require --trust-policy POLICY`
reconstructs to a temporary file, verifies the planned digest and persisted
release-admission policy, then installs the accepted output plus generation
sidecar. `cityb release trust init --root ROOT` is the one-time policy setup;
status and `cityb next` never put signer placeholders into an immediate action.
`cycle plan` carries generation, provider-set digest, and plan digest into the
pointer-chain member, while field-pack status and recovery cards surface the
same generation. The full contract is in
`docs/city-b-generation-and-capacity.md`.

The production ceremony transactionally archives superseded generations,
encodes the signed release, sprays only eligible providers, reconstructs from
a sufficient exact-byte subset, verifies persisted release trust, and
regenerates the field pack and recovery card. Pointer-only adapters remain in
the membership snapshot but are mechanically excluded from shard assignment.
The adaptive ladder bisects between maximum proven and minimum failed sizes,
so an upper-bound experiment does not turn a useful smaller provider into a
fictional total failure.

## Release and monsternix handoff

`cityb release ceremony` is the read-only release runbook. It prints the archive, `SHA3SUMS` signing, OpenSSH verification, field-pack admission, install, and deployment-policy commands without building or writing. `cityb release archive` builds the three release binaries, writes each binary’s `version --json` and `capabilities --json`, copies the checked-in free-service replay corpus, copies the README, license, contribution and security policies, and CityB-only docs, and includes the public CityB NixOS module plus reviewed CityB deployment examples. It deliberately excludes the m21-personal Stil and Stil Foundation objects and documentation as well as repository-specific Monsternix admission metadata. It writes `RELEASE-ID.json`, writes the canonical `SHA3SUMS` signing payload, and emits a `.tar.gz` plus manifest. `cityb release archive --plan` is side-effect free, while `--binary-dir DIR` packages reviewed binaries without rebuilding different bytes. `cityb release sign SHA3SUMS --signing-key KEY --apply` creates `SHA3SUMS.sig` beside the signing payload with `ssh-keygen -Y sign`, installs it in the release directory, transactionally reseals the distributed `.tar.gz`, recomputes the archive digest, and updates the external manifest; without `--apply` it reports the payload digest, output signature path, signing command, and verification command without writing. `cityb release verify DIR_OR_TAR_GZ` checks an unpacked release directory or archive by preflighting archive members, validating the manifest, asking each binary for identity/capabilities, confirming the policy files, docs, and fixture corpus are present, reporting the `RELEASE-ID.json` digest, reporting the `SHA3SUMS` digest, and stating whether an optional detached `SHA3SUMS.sig` is present and verified. It defaults to optional signatures; `--signature-policy require-present` and `--require-signature` make an unsigned release fail. `--signature-policy require-verified --signature-verifier ssh --allowed-signers FILE --signer-identity ID` verifies `SHA3SUMS.sig` with OpenSSH over `SHA3SUMS`; `--signature-namespace` defaults to `cityb-release`. Field-pack status reads the same release manifest fields and can require `signature_verified=true` with `--signature-policy require-verified`; deployments can make that default by setting `release_manifest` and `release_signature_policy`, then narrow admission with `release_allowed_signers`, `release_allowed_namespaces`, `release_allowed_versions`, `release_allowed_arches`, `release_allowed_os`, `release_allowed_archive_sha3_256`, and `release_require_runtime_match`.

Release verification deliberately separates the immutable format baseline from the evolving evidence corpus. The signed `SHA3SUMS` is authoritative for every file packaged in that artifact; adding a newly dated provider or listing fixture to a later source tree must not make an older correctly signed release unverifiable.

`packaging/monsternix/cityb.experimental-toolset.json` is a metadata-only candidate object for a future monsternix experimental toolset. Including that JSON should not start services, open listeners, create state, read credentials, post to providers, or modify monsternix. Its intended admission handle is the public `.#default` package and `nixosModules.default`, with the three explicit role apps `.#cityb`, `.#cityb-node`, and `.#cityb-biggun`; it does not advertise m21 personal objects.

## Current maintenance posture

`cityb provider archive-roles` performs one dry-run/apply transaction over the
stable set instead of making the operator open every dossier. Its retained
policy assigns automatic, capacity-repair, recovered-watch, or
pointer/mirror-only roles without changing pointer membership. The policy seals the
sorted provider-to-role mapping: after apply, provider health reports
`archive-capacity-tracked` and does not ask the operator to apply the identical
decision forever; later evidence that changes a role invalidates the digest
and restores one batch action. Monitor reports now
separate infrastructure, stable-lane, capacity-experiment, promoted-listing,
listing-experiment, and candidate-probe outcomes.

Evidence curation has an explicit monotonic generation and sealed high-water
mark. `cityb evidence index --apply` maintains one derived, fingerprinted index
shared by evidence readers. Its generated report carries decision-record,
observation, provider, and sealed-generation counts and retains ordered
mixed-outcome transitions in addition to the ordinary provider/date/outcome
semantic key. Provider-set curation and corpus curation therefore have distinct
identities and neither ordinary cockpit reads nor Biggun need to rediscover the
same corpus facts blindly.

`cityb dead-drop archive preview` is the next-generation planning gate. It is
the Goldilocks half of a shared evidence loop: Biggun's provider-reality and
soak reports establish dated capacity and correlated-loss facts, and the
operator command consumes those retained facts for an exact release size. It
jointly searches codec-valid data/parity counts, exact rendered shard width,
dated provider ceilings, and the largest one- and two-root losses. Ranking uses
the intersection of capacity-proven providers and observed effective roots.
It searches the whole bounded 32-data/32-parity space rather than forcing total
shards to equal provider count, and simulates topology-first provider reuse for
each candidate. The recommended command uses the same automatic-role filter
and assignment algorithm and fails closed with `--require-root-loss-ready` if
retained topology changes or cannot satisfy the advertised margin.
If no geometry satisfies the selected capacity/topology policy, preview still
returns bounded structural alternatives but labels the result
`capacity-evidence-insufficient`. It separately identifies the narrowest
structurally one-root-safe geometry even before capacity proof exists and uses
that geometry's exact rendered shard width as the next probe target. Adoption
still requires the intersection of capacity proof and root-loss survival; the
planning candidate never grants posting authority by itself.

The remaining work is primarily empirical rather than missing command surface:
continue the generated capacity-repair queue on later dates, source-review the
best capability- and topology-diverse promotion candidates, retain later
listing evidence before changing provider-specific facts, and keep adding
date-separated anchor and correspondence corpora. The October 26 anchor corpus
adds verified later drand, Rekor same-tree consistency, and Google CT
consistency evidence; the correspondence corpus adds a real two-family encrypted
envelope round trip while correctly demanding later-date repetition. The executable order and
acceptance gates remain in [city-b-next-campaign.md](city-b-next-campaign.md).

The repo is already fairly modular, but several files remain large because they carry many provider adapters, state machines, and CLI surfaces. `dead_drop/live_publishers.rs` keeps provider dispatch and one provider-specific publish routine per service, while its `payloads`, `packets`, and `probes` modules own normalization, operator artifacts, and shared evidence handling. Deterministic slot derivation and envelopes now live in `dead_drop/rendezvous_schedule.rs`; Tiny durable-anchor intake lives in `cityb-node/src/anchor.rs`; Biggun publication gates live in `cityb-lab/src/gate.rs`; and both operator binaries have focused argument-arity modules. The long-term direction is not to collapse the three binaries or chase line counts. It is to split provider families and state-machine ownership when the boundary is stable and preserves the link-graph separation between Tiny, Goldilocks, and Biggun.

The provider corpus should keep growing, but `free-stable` should stay boring. New services belong in strict research benches or the `free-candidate-pool` investigation queue until captures prove exact receive behavior across dates and roots. Non-exact rendered/redirect evidence deserves explicit lane semantics before it is treated as routine.

The Tiny durability work should continue toward reconstruction from independently verified chain records and monotone floor facts, not only dashboard projections and checkpoints.

The adapter repair queue should keep becoming more provider-specific, but only where docs or dated captures prove stable receive behavior. Generic advice is safer than a fake exact command.

## What CityB does not claim

CityB is not a voting system, not a carrier-consensus system, not a public-service account manager, not a firewall, not a guarantee of anonymity, not a proof that a free provider will continue to work, and not a substitute for legal or operational judgment. Public-service posting creates remote state. Free services rate-limit, expire, transform, moderate, redirect, block, or disappear. Fixture replay proves CityB’s parser and evidence handling against captured bodies; it does not prove that the live internet will behave the same tomorrow.

The product claim is narrower and stronger: CityB provides a standalone, inspectable, three-binary toolset for signed-governance distribution where operators can publish and collect discovery evidence through explicit adapters, verification-first nodes can verify authority and return bounded correspondence without holding governance capability, and the lab binary can continuously attack the assumptions before they become routine.
