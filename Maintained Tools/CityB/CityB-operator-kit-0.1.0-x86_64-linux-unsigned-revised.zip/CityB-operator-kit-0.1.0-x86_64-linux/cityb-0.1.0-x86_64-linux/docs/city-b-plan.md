# City B plan

CityB is now the standalone product focus. The old civic-baseline workflow has
been removed from the active repo surface; regression coverage now protects the
shared authority, archive, node, adapter, and lab machinery through CityB product
runs and lower-level crate tests. The product proves its central claim when
governance pointers can still be placed, rediscovered, verified, and explained
while overt infrastructure is degraded or hostile.

Feature speculation that has not yet graduated into this plan lives in
[city-b-speculation.md](city-b-speculation.md).

The current operator campaign—provider drift, correlated-root receipt repair,
capacity-driven planning, a third listing source, empirical anchor continuity,
and portable handoff—lives in
[city-b-next-campaign.md](city-b-next-campaign.md). Earlier deployment,
resumable-cycle, parser-registry, Tiny durability, and three-binary decisions
are implemented baseline rather than current campaign work.

The generalized provider/adapter architecture lives in
[city-b-provider-model.md](city-b-provider-model.md),
[city-b-operator-workflow.md](city-b-operator-workflow.md), and
[city-b-provider-adapter-spec.md](city-b-provider-adapter-spec.md).
Real documented service candidates live in
[city-b-real-service-adapters.md](city-b-real-service-adapters.md).
The encoding/placement/probe phase split is written in
[city-b-hook-model.md](city-b-hook-model.md).

This is not a lab-only feature set. The lab is how we tune the machinery before
operator-owned deployments. The target is a capable covert-posting
engine with a strict verification core.

As of September 15, 2026, the live adapter baseline is:

- `local-file` for local doubles and normalized receipts
- `manual-drop` for operator publication staging packets
- `static-http` for operator-owned static docroots with deterministic HTTP
  probe receipts
- `filehost-generic` for deterministic filehost upload packets plus optional
  exact download-URL probes
- `git-release-generic` for deterministic release packets plus optional exact
  asset or release-note URL probes
- `object-store-generic` for deterministic object-store packets plus optional
  exact object URL probes
- `github-release` for deterministic GitHub Releases packets plus optional
  exact `browser_download_url` or release-note URL probes
- `gitlab-release` for deterministic GitLab Releases packets plus optional
  exact asset or stable release-link URL probes
- `netlify-drop` for deterministic Netlify Drop packets plus optional exact
  deployed site URL probes
- `github-pages` for deterministic GitHub Pages packets plus optional exact
  published site URL probes
- `gitlab-pages` for deterministic GitLab Pages packets plus optional exact
  published site URL probes
- `codeberg-pages` for deterministic Codeberg Pages packets plus optional
  exact published site URL probes
- `codeberg-release` for deterministic Codeberg release packets plus optional
  exact release asset or release-page URL probes
- `file.io` for built-in Rust publication to a single-consume file.io URL
- `uguu` for built-in Rust publication to a short-TTL Uguu URL
- `termbin` for built-in Rust raw TCP publication with HTTP URL observation
- `paste-c-net` for built-in Rust HTTPS text publication with exact returned
  URL observation
- `sendit` for built-in Rust HTTPS upload with returned `wget` URL observation
- `storage.to` for built-in Rust publication to the anonymous storage.to
  ShareX path
- `github-gist` for built-in Rust authenticated gist creation with raw-URL
  probing
- `gitlab-snippet` for built-in Rust authenticated snippet creation with
  raw-URL probing
- `filebin` for built-in Rust publication to a Filebin-compatible service
- `paste-rs` for built-in Rust publication to a paste.rs-compatible text
  service
- `dpaste` for built-in Rust publication to a dpaste-compatible text service
- `0x0` for built-in Rust publication to a 0x0-compatible upload service
- `catbox` for built-in Rust publication to the Catbox anonymous upload API
- `litterbox` for built-in Rust publication to the Litterbox temporary upload
  API with material-banded retention
- `tmpfiles` for built-in Rust publication to the /tmp/files API with
  material-banded expiry seconds
- `plugin-external` for deterministic plugin packets plus one explicit local
  executable that returns normalized placement/probe facts

The current operator-support baseline also includes `deployment recipes` for
service-specific guidance, `collect fixture-template` for checksum-valid replay
scaffolding, checked-in same-day and cross-day free-service replay corpora,
sanitized provider-drift bodies for parser-diff, ranked `service_repair_queue`
output from `cycle next`, and Tiny checkpoint-sourced status rendering when
`status.json` is missing but a current or previous checkpoint is valid.

The active adapter roadmap is free-first:

- prefer no-account services when the outcome is good enough;
- use free account-backed services when they materially improve durability or
  operator clarity;
- keep paid-only services out of the mainline City B product roadmap.

## October 20 operator-truth tranche

The following items are implemented and should no longer be described as
missing architecture:

1. Shared readiness: the main operator surfaces distinguish successful
   execution from actual operational readiness and share a primary/ordered
   action model plus canonical archive-capacity counters.
2. Current-generation reconciliation: `cityb reconcile` plans and applies the
   release/sign/trust/refresh/spray/collect/handoff sequence, protects
   historical generations from accidental adoption, and requires an explicit
   `--live` gate for public provider mutation.
3. Adaptive archive capacity: the monitor can rotate bounded 4 KiB, 64 KiB,
   256 KiB, and 1 MiB exact-byte probes; provider classes and planner ordering
   now use dated proven capacity rather than adapter eligibility alone.
4. Honest topology: deployments carry typed dated operator/provider, DNS,
   IP/ASN, CDN, hosting, confidence, and observation metadata. Unknown roots
   no longer manufacture diversity. Rendezvous provider classes and CityB
   system mechanisms are separate reports.
5. One-command long-amnesia recovery: `cityb recover` composes durable-anchor
   admission, signed-chain verification, erasure reconstruction, release
   admission, and handoff regeneration. Biggun proves the local chain with a
   sealed signed release and a sufficient shard subset.
6. Durable executable identity and Nix automation: all three version surfaces
   expose source/build/artifact/provider/release identities; monitor comparison
   uses semantic build identity; and the opt-in NixOS module schedules monitor,
   local evidence intake, and Biggun truth checks without a fourth binary or
   default public mutation. Its credential-free runtime descriptor now also
   drives `cityb system`: exact-package status/doctor, timers, bounded logs,
   and role-allowlisted lifecycle control without arbitrary unit execution.

The normal evidence baseline is generated, not transcribed: `stil snapshot
--json` carries the shared capability ledger and current admitted-generation
facts, while `cityb service ls --service-set free-stable --json` carries the
roster. Historical generation records remain immutable even when their
membership differs. A signed admitted generation proves only its sealed
geometry, receipts, exact reconstructed archive, and release policy; it does
not become a permanent statement about the next provider set.

## October 26 Stil action tranche

The operator bridge from evidence to work is now part of the single-file Stil
object rather than another Rust binary or an external script. `stil act`
produces one typed action bound to the exact Stil object digest, CityB build,
retained root, evidence generation, provider-role digest, and action argv. It
is dry-run-first, executes only with `--apply`, optionally fences the reviewed
plan with `--expect ACTION_ID`, and never evaluates command prose as shell.

Provider maintenance now has the uniform `status | plan | apply | verify`
ceremony under `stil providers`; `stil tend` is its short operator spelling.
The ceremony performs one step at a time in this order: seal a pending evidence
generation, complete its source handoff, update the local evidence-derived
archive-role policy, refresh topology when required, then ask CityB's
future-generation preview and adaptive capacity selector for one exact
provider probe. The remote action binds the planned generation shard width,
the provider's next ladder size, and the configured vantage/egress labels.
After that probe, the next invocation rereads evidence rather than continuing
from a stale shell plan. Provider truth and erasure geometry remain Rust-owned;
Stil supplies Nix identity, path discovery, typed execution, and ceremony
ordering.

Topology-aware repair is now an ordinary archive verb. It preserves the
generation, targets missing assignments outside the largest received diversity
domain, requires dated capacity proof at the planned shard width by default,
and stops when the receipt subset survives loss of that domain. The first live
repair recovered Beacon Host and moved the current subset from 26/30 to 27/30
after AS13335 loss. The remaining assignments failed at this width, so
`cityb next` now asks for a bounded capacity probe instead of blindly repeating
the same repair. New plans support `prefer-proven`, `require-proven`, and
explicit `ignore` capacity policies.

The current executable ordering is maintained in
[city-b-next-campaign.md](city-b-next-campaign.md). In summary, the roadmap is
empirical rather than another layer of commands:

The October 20 reconciliation exposed three operator-first P0 seams inside
that empirical program. They are now implemented: archive-role decisions have
one batch policy transaction, monitor readiness separates stable-lane health
from useful repair/research failures, and fixture curation has a generation
watermark plus a shared evidence index. The October 23 follow-through seals the
sorted provider-to-role mapping, so the generated capacity-repair queue remains
visible without making every cockpit invocation demand identical operator
approval again. These foundations still rank ahead of provider-count expansion.

1. Reconcile operator truth before expanding command surface. Immediate
   recommendations must be executable against retained state; unknown topology
   must not be rendered as collapse; impossible current-generation repairs
   must not survive Biggun's own loss model; and capacity failures must retain
   their upload/retrieval/verification/expiry phase.
2. Curate imported soak evidence as a bounded transaction. Raw captures belong
   in retained monitor state; checked-in fixtures should be content-addressed,
   decision-bearing, reproducible selections rather than an unbounded copy of
   every successful body. Import backlog and source-control curation backlog
   are separate operator facts. Review/apply is now pinned to one monotonic
   generation and source fingerprint, and monitor readiness separately blocks
   on selected files that have not completed their source-control handoff.
3. Let the adaptive ladder accumulate date-separated small, medium, and large
   results. After an upper-bound failure it now bisects the proven/failing
   interval; use the resulting ceiling to narrow shard assignments without
   confusing pointer health with shard health.
4. Keep the new bounded topology snapshots date-separated so the October 18
   observation (60/60 selected, 21 effective roots, 31 Cloudflare
   services) can be distinguished from transient DNS/CDN movement. Planning
   and Biggun now consume this evidence; root diversity is no longer inferred
   from service names.
5. Preserve the completed production reconciliation as a repeatable ceremony.
   The October 18 signed 30+30 generation persisted operator-selected OpenSSH
   trust, reconstructed and admitted the exact release from 42 receipts, and
   regenerated the field pack and recovery card. Future generation refreshes
   must pass the same executable chain; `cityb next` may still be
   `action-required` for later provider drift without misreporting release,
   archive, or handoff readiness.
6. Preview a future archive generation across candidate erasure parameters,
   rendered shard widths, dated capacity, expiry, provider health, and observed
   roots. Preserve the admitted October 18 generation as
   `root-diversity-constrained`; do not keep proposing repairs which cannot
   raise its post-AS13335 receipt count from 27 to 30.
7. Keep expanding real upstream CT/Rekor/drand proof corpora and external-root
   admission policy; the recovery transaction is composed, but public-root
   quality remains an evidence program.
8. Add more missed-cycle and provider-loss variants to Biggun only when they
   falsify a concrete operator or Tiny claim. Preserve Biggun as the truth
   machine, not as a duplicate operator interface. Cycle planning now retains
   immutable per-epoch pointer-chain members; Tiny bounds candidate count and
   bytes, accepts only members included in the verified archive chain, selects
   the newest verified member, and reports the recovery span. Biggun exercises
   three consecutive archived members, a two-epoch recovery span, fallback to
   the preceding member, and final stale/expired variants.
9. Keep identity binding end-to-end in release archives, field packs, monitor
   reports, provider-set generations, and future monsternix admission. Do not
   collapse these distinct identities into one version string.
10. The October 20 diagnostic recheck restored `p-ip-fi` pointer health; keep
   it stable and let later-date soak evidence decide any future change.
   PasteFox has recovered pointer behavior; treat its archive-sized challenges
   separately. Preserve Sendit's retained-URL 404 as retrieval/expiry evidence,
   not an upload rejection. Keep FragBin suspended until a later public listing capture
   succeeds; repeated October 17–18 HTTP 500 results do not justify live use.
   Pastefy is now the third retained-local sweep after October 18/20 captures
   and Biggun agreement; its multi-megabyte uncursored full-content response is
   read only by bounded Goldilocks and its raw public body is not retained.
   Tiny consumes only the retained local projection.
   Dpaste is already outside `free-stable` after repeated post-recovery dates.
11. Convert repeated-exact native candidate probes currently reported by
   `provider stable-plan --from free-candidate-pool` into production Rust
   capture adapters in small topology-diverse batches. Several candidates now
   have exact fixture evidence across October 13–17, but candidate probes are
   deliberately not treated as stable publication adapters. Reuse the proven
   request/receive semantics, add normal capture and archive-size behavior,
   rerun parser/topology gates, then review a source patch; do not bulk-promote
   merely because the candidate board is green. Keep MQTT/Nostr event carriers
   in a discovery lane rather than misclassifying them as archive mirrors.

See
[city-b-readiness-reconciliation-and-recovery.md](city-b-readiness-reconciliation-and-recovery.md)
for the executable operator contract.

## North star

City B succeeds when an operator can run one workflow that:

1. signs a real governance archive;
2. plans diverse covert pointer placements;
3. emits whole pointers, threshold fragments, heartbeat marks, route hints, and
   receipts through configured carrier adapters;
4. observes imported feeds and local substrate doubles;
5. reconstructs candidate pointers when enough evidence exists;
6. verifies every candidate against the signed archive and normal CityB gate;
7. explains the final state, refusals, freshness debt, and missing evidence in
   language an operator can act on.

The covert layer is allowed to be clever. The authority layer is not. Carriers
may hide, smear, delay, fragment, mirror, or lose bytes; they may not authorize
state.

## Product shape

City B should have four explicit planes:

| Plane | Owns | Must not own |
|---|---|---|
| Authority plane | council threshold signatures, serial duty, constitution amendments, signed heartbeat policies | carrier quorum, substrate trust, implicit emergency power |
| Archive plane | complete signed bundles, pointers, receipts, consistency checks, audit roots | hiding strategy or posting side effects |
| Covert-posting plane | placement envelopes, encodings, poster adapters, substrate registry, rendezvous schedules, fragments, route hints | payload execution or node authority |
| Observation plane | feed imports, scanner results, volatile-gossip observations, freshness debt, recovery explanation | remote mutation or unverified adoption |

The planes should be reflected in code ownership:

- `cityb-core`: stable types that affect verification or deterministic planning.
- `cityb-transports`: local carrier doubles, fragment handling, and adapter
  traits that move pointer material.
- `cityb-audit`: freshness debt, receipt diversity, transparency-log proofs,
  and recovery explanation facts.
- `cityb-lab`: adversarial schedules, local doubles, measurement sweeps, and
  large-fleet regression scenarios.
- `cityb-cli`: operator verbs and retained run artifacts.
- `cityb-node`: the standalone receive-only fleet binary. This is a
  packaging/link-graph split, not a protocol fork.

Do not add a new City B protocol crate until one of those boundaries becomes
unmaintainable. The exception is binary packaging: the tiny node is its own
crate specifically so `cityb-cli`, `cityb-council`, city runners, publisher
paths, and lab code cannot leak into its link graph.

## Binary split and target matrix

City B now has three binary surfaces. They share code and protocol types; the
split is for capability clarity, operator UX, and deployment size.

| Binary | Profile | Primary targets | Secondary targets | Ideal deployment |
|---|---|---|---|---|
| `cityb-node` | standalone dependency-tiny receive-only node | `x86_64-unknown-linux-gnu`, `aarch64-unknown-linux-gnu` | `armv7-unknown-linux-gnueabihf` check target until hardware proves runtime | weak fleet node, SBC, old laptop, minimal VM |
| `cityb` | Goldilocks/default operator | `x86_64-unknown-linux-gnu`, `aarch64-unknown-linux-gnu` | none promised; ARMv7 belongs to the tiny node unless proven useful | laptop, VPS, small server |
| `cityb-biggun` | research/lab/large planning surface | `x86_64-unknown-linux-gnu`, `aarch64-unknown-linux-gnu` | none promised | workstation, beefy server, lab runner |

The target promise is Linux-first. `x86_64` and `aarch64` are required for all
three surfaces. `armv7` is sensible only for the tiny node because low-resource
ARM devices are common, but Biggun's lab load and future integration adapters
should not be constrained by 32-bit embedded targets.

Research anchors as of 2026-08-30: Rust documents
`aarch64-unknown-linux-gnu` and `x86_64-unknown-linux-gnu` as Tier 1 Linux
targets with host tools, while `armv7-unknown-linux-gnueabihf` is Tier 2 with
host tools and can be cross-compiled. Cargo's release-profile knobs explicitly
cover the size controls used here: `opt-level`, `strip`, `lto`,
`codegen-units`, and `panic`. Cargo features and package boundaries are also
the correct way to prevent unwanted optional dependency graphs from compiling
into small artifacts.

Primary references:

- <https://doc.rust-lang.org/rustc/platform-support.html>
- <https://doc.rust-lang.org/rustc/platform-support/armv7-unknown-linux-gnueabi.html>
- <https://doc.rust-lang.org/cargo/reference/profiles.html>
- <https://doc.rust-lang.org/cargo/reference/features.html>

Current invocation forms:

```sh
cityb-node capabilities
cityb-node doctor --json
cityb-node provision --constitution FILE --config FILE --state-dir DIR
cityb-node serve --config FILE --state-dir DIR
cityb-node serve --config FILE --state-dir /tmp/cityb-node-state --field-profile low-power-field --clock-confidence offline --now-epoch 1 --cycles 1
cityb-node dead-drop scan PATH --against CHAIN-DIR
cityb-node dead-drop fragment collect --root DIR --against CHAIN-DIR
cityb-node dead-drop fragment collect --root DIR --path MEDIA-A --path MEDIA-B --path MEDIA-C --against CHAIN-DIR --min-source-roots 3
cityb-node dead-drop capsule verify --root CAPSULE
cityb-node format catalog|parse --encoding NAME FILE... [--json]
cityb-node kit inspect|verify --root KIT

cityb capabilities
cityb matrix
cityb up --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb check --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb next --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb deployment init --out ./city-b.toml
cityb deployment validate --file ./city-b.toml --json
cityb deployment compile --file ./city-b.toml --root ./city-b-artifacts --json
cityb cycle preview --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb cycle plan --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb cycle apply --root ./city-b-artifacts --deployment ./city-b.toml --max-events 16 --with-collect --json
cityb cycle resume --root ./city-b-artifacts --deployment ./city-b.toml --max-events 16 --with-collect --json
cityb cycle run --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb cycle next --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb cycle reconcile template --root ./city-b-artifacts --event EVENT_HEX --outcome verified --out ./reconciliation.json
cityb cycle reconcile --root ./city-b-artifacts --deployment ./city-b.toml --event EVENT_HEX --outcome verified --evidence ./reconciliation.json --json
cityb cycle status --root ./city-b-artifacts --json
cityb collect --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb collect probe --root ./city-b-artifacts --deployment ./city-b.toml --service SERVICE --location URL_OR_FILE --json
cityb collect cursor --root ./city-b-artifacts --deployment ./city-b.toml --service SERVICE --lane LANE --source LISTING_URL_OR_FILE --json
cityb collect fixture --root ./city-b-artifacts --deployment ./city-b.toml --fixture captured-provider-fixtures.jsonl --json
cityb review --root ./city-b-artifacts --json
cityb profile catalog --json
cityb profile compile --profile early-scraper --root ./city-b-profile --json
cityb format catalog --json
cityb format render --encoding syntactic-semver --hex 4a8f9c2d1e0b3a7f8e9d0c1b2a3f4e5d6c7b8a
cityb format parse --encoding syntactic-semver ./rendered-pointer.txt --json
cityb run --nodes 32 --parallelism 16 --root ./city-b-artifacts
cityb node-kit --root ./city-b-artifacts --out ./city-b-node-kit
cityb dead-drop plan --root ./city-b-drops --against ./city-b-artifacts/city-b-chain
cityb dead-drop fragment split --root ./city-b-drops --pointer POINTER
cityb dead-drop fragment collect --root ./city-b-drops --against ./city-b-artifacts/city-b-chain --require
cityb dead-drop capsule export --root ./city-b-drops --against ./city-b-artifacts/city-b-chain --out ./city-b-recovery-capsule

cityb-biggun capabilities
cityb-biggun matrix
cityb-biggun fragment-matrix --json
cityb-biggun gossip-matrix --json
cityb-biggun gossip-evidence --root ./city-b-exercise/city-b-dead-drop-governance --require --json
cityb-biggun footprint --bin-dir ./target/debug --json
cityb-biggun replay --root ./city-b-artifacts --require --json
cityb-biggun targets --json
cityb-biggun lab run --scenario city-b-phased
cityb-biggun handoff --root ./city-b-artifacts --kit ./city-b-handoff-kit
cityb-biggun exercise --root ./city-b-exercise --kit ./city-b-exercise-kit --nodes 3 --parallelism 3
cityb-biggun exercise --root ./city-b-exercise-degraded --kit ./city-b-exercise-degraded-kit --nodes 3 --parallelism 3 --degrade all
cityb-biggun run --nodes 64 --parallelism 32 --root ./city-b-artifacts
```

Capability boundaries:

| Boundary | Tiny node | Goldilocks | Biggun |
|---|---|---|---|
| Holds private signing keys | no | possible when operator asks | possible when operator asks |
| Publishes archives | no | yes | yes |
| Plans covert placements | no | yes | yes |
| Runs poster adapters | no | explicit only | explicit/lab-heavy |
| Splits pointer fragments | no | yes | yes, through Goldilocks forwarding |
| Collects pointer fragments | yes | yes | yes |
| Runs lab scenarios | no | no | yes |
| Runs three-binary handoff check | no | no | yes |
| Measures local binary split | no | no | yes |
| Runs full retained-run exercise | no | no | yes |
| Mutates remote-public substrates | no | only explicit operator-owned | only explicit operator-owned |
| Verifies/adopts governance | yes | yes | yes |
| Exports tiny-node handoff kits | no | yes | yes, through Goldilocks forwarding |
| Exports recovery capsules | no | yes | yes, through Goldilocks forwarding |
| Verifies recovery capsules | yes | yes | yes, through Tiny/Goldilocks forwarding |
| Depends on `cityb-cli` | no | yes | yes |

The three-way split is the product boundary: Tiny receives and verifies,
Goldilocks operates and may run as an unattended collector service, and Biggun
attacks assumptions. Collection does not justify a fourth public binary; a
future isolated helper may exist behind Goldilocks without creating a fourth
operator grammar or identity.

Binary personalities:

- Tiny node should be boring enough to forget. It should run on old laptops,
  cheap x86 thin clients, aarch64 boards, and plausible 32-bit ARM Linux
  devices. Its job is to receive/import feeds, reconstruct locally imported
  pointer fragments, verify signed archives, retain state, serve status, and
  make no outbound authority claim. Its dead-drop init surface should scaffold
  every local/import substrate that Goldilocks can plan and Biggun can exercise,
  but only as operator-supplied text transcripts or local doubles. It should be
  scriptable, cron-friendly, and safe to provision in large numbers.
- Goldilocks should be the default human/operator tool. It can plan, publish,
  receipt, audit, split/collect pointer fragments, and operate City B without
  carrying lab machinery. This is the binary for a laptop, VPS, small server, or
  field operator machine.
- Biggun should be unconstrained by tiny-node taste. It owns stress runs,
  local doubles, parameter sweeps, reports, and future heavy research adapters.
  If a feature needs a browser, a full local substrate model, a large corpus, or
  expensive simulation, it belongs here first.

## Three-binary workflow

The split now has an executable handoff path instead of only a conceptual one:

```sh
cityb run --nodes 32 --parallelism 16 --root ./city-b-artifacts
cityb node-kit --root ./city-b-artifacts --out ./city-b-node-kit
(cd ./city-b-node-kit && ./run-node.sh)                    # or set CITYB_NODE=/path/to/cityb-node
cityb-node kit verify --root ./city-b-node-kit --json
cityb-biggun matrix --json
cityb-biggun fragment-matrix --json
cityb-biggun lab run --scenario city-b-phased
cityb-biggun handoff --root ./city-b-artifacts --kit ./city-b-handoff-kit
cityb-biggun exercise --root ./city-b-exercise --kit ./city-b-exercise-kit --nodes 3 --parallelism 3
cityb-biggun exercise --root ./city-b-exercise-degraded --kit ./city-b-exercise-degraded-kit --nodes 3 --parallelism 3 --degrade all
```

`cityb node-kit` first verifies the retained City B workspace. It then
exports only the public receive-side materials required by `cityb-node`:
`constitution.cbor`, `city-b-chain`, `city-b-overt`, `city-b-noise`,
`city-b-floor`, `city-b-pastebins`, `city-b-dead-drops`,
`city-b-import-drops`, `city-b-dead-drop-governance`, `city-b-node.kv`, a
README, `.cityb-node-kit`, `city-b-node-kit-manifest.tsv`, and
`run-node.sh`. It deliberately excludes `city-b-council/seats`, publisher
configuration, signing desks, and lab state. Force-reuse is allowed only for
marked kit directories and rejects symlinks, special files, and
private/operator-looking leftovers. The generated
`.cityb-node-kit` marker records the exported chain-tip epoch, and
`run-node.sh` uses that value instead of a fixed test epoch. The script runs
doctor/config validation, verifies the public chain, provisions a fresh local
tiny-node state directory, serves one recovery cycle at the exported chain tip,
checks ACTIVE status, and scans baseline raw text feeds plus the full local
import-drop mesh and retained governance baseline against the signed chain.
`cityb-node kit verify --root KIT` performs the receive-only kit check
directly: marker present, required public material present, no private-looking
leftovers, the import-drop mesh and governance baseline present, exact manifest
SHA3-256/byte counts intact for every non-runtime kit file, marker epoch equal
to the signed chain tip when present, chain verification green, and at least
one text-feed pointer verified against the signed archive. It also reports the
same retained governance vocabulary used by capsule verification: rendezvous
plan/beacon presence, minimum-media, all-media schedule agreement, envelope and
receipt counts, material kinds, and retained substrate score summary. Runtime
`state/` is intentionally excluded so the same kit can be booted and reused
locally.

`cityb dead-drop capsule export` is the second portable handoff format. A
node-kit carries the public receive runtime slice of a retained City B run. A
recovery capsule carries the public dead-drop governance evidence slice:
`city-b-chain`, `city-b-dead-drop-governance`, `README.md`,
`.cityb-recovery-capsule`, `city-b-recovery-capsule.json`,
`city-b-recovery-capsule-manifest.tsv`, and `run-tiny-verify.sh`. Export
refreshes debt and recovery-explainer reports before copying, refuses unsafe
destinations, rejects symlinks/special files/private-looking paths, and writes a
SHA3-256 manifest. The capsule marker, JSON summary, and export report record
the copied signed-chain tip epoch. Verification is available in both Goldilocks
and Tiny, and both reject a capsule whose marker epoch disagrees with the copied
chain tip.
Tiny's `cityb-node dead-drop capsule verify --root CAPSULE` checks the
marker, required paths, exact manifest coverage, public-only shape, signed
chain, chain-verified pointer tokens, any reconstructable fragment set, retained
rendezvous beacon/plan presence, all-media schedule/envelope/receipt counts,
noise report presence, recovery explainer presence, and material evidence
summaries for retained heartbeat/route-hint drills. It reports strict fragment
source-root facts when `city-b-fragment-source-roots/` is retained, so a weak
receiver can tell ordinary fragment recovery apart from carrier-diverse
fragment recovery. It reports the retained substrate score summary fields from
the capsule so a weak receiver can see readiness, decision-score, rotation, and
failure-domain evidence without recomputing operator-side scoring heuristics.

This is the role contract:

1. Goldilocks (`cityb`) creates and audits the operating picture.
2. Goldilocks exports the tiny kit when a receive-only node needs a portable
   public bundle.
3. Goldilocks exports a recovery capsule when dead-drop governance evidence
   needs to cross an operator, auditor, or weak-node boundary.
4. Tiny (`cityb-node`) imports, verifies, serves, and reports status plus
   retained governance facts from kits; it also verifies recovery capsules
   without acquiring signing or posting authority. When a capsule carries
   Biggun's gossip evidence report, Tiny exposes presence, success, lane count,
   and complete-lane count as receive-side facts.
5. Biggun (`cityb-biggun`) runs matrix/fragment-matrix/gossip-matrix/lab
   checks and future large substrate doubles against the same protocol rules. Its
   `fragment-matrix` compares 3-of-5 fragments to five whole-token copies under
   the same pure carrier-loss model, so the availability tradeoff is explicit.
   It also reports an independent carrier-compromise curve, where fragments
   reduce pointer disclosure because three distinct shares are required instead
   of any one repeated whole-token copy, and an OCR/operator-entry mutation
   curve using the actual current share-line length. `gossip-matrix` ranks the
   current Nostr/libp2p/mempool/IoTox local doubles by TTL-window observation,
   correlated-failure risk, operator cost, republish cadence, and material fit.
   `gossip-evidence` then checks one retained governance root and requires the
   modeled volatile-gossip lanes to appear in local placement envelopes,
   placement receipts, and verified observation receipts before Biggun treats
   the local double seam as proven.
6. Biggun's `handoff` command drives Goldilocks and Tiny as real sibling
   binaries, so the operator can check the seam without reading the CI script.
7. Biggun's `footprint` command records local binary bytes, SHA3-256 digests,
   and `capabilities --json` execution for Tiny, Goldilocks, and Biggun. This
   is host/build evidence only; it does not replace ARM runtime transcripts,
   static packaging measurements, or steady-state memory measurements.
8. Biggun's `exercise` command creates a retained run, performs the handoff,
   records a local binary footprint report, records a local dead-drop
   distribution plan, records two verified media
   receipts from generated City B pointers, audits the minimum media target,
   checks freshness debt, writes a deterministic local rendezvous schedule
   across the full current local substrate set plus JSONL placement envelopes,
   records per-substrate recommendations and next actions,
   splits and recollects one pointer fragment set, runs a separate
   `city-b-heartbeat-drill/` and `city-b-route-hint-drill/` lanes that prove
   heartbeat and route-hint material can be enveloped, locally posted, observed,
   audited, and freshness-checked without changing the main all-media schedule
   count, writes a recovery explainer, exports a recovery capsule carrying
   those drills, verifies that capsule with Tiny, including material
   kinds/counts and drill-root reporting, executes the capsule's generated
   `run-tiny-verify.sh` replay script, runs the fragment matrix, gossip matrix,
   gossip-evidence check, and City B lab arc, and writes
   `RUN/city-b-recovery-summary.{json,md}`,
   `RUN/city-b-fragment-matrix.json` plus
   `RUN/city-b-gossip-matrix.json` plus
   `RUN/city-b-dead-drop-governance/city-b-gossip-evidence.json` plus
   `RUN/city-b-three-binary-exercise.json` when a fresh local proof is needed.
   The recovery summary ties Goldilocks run proof, Tiny kit/capsule proof,
   substrate-score summary, Biggun lab proof, local volatile-gossip proof,
   Tiny-reported capsule gossip evidence, and Biggun's own three-binary
   SHA3-256 footprint into one resumption card. The exercise
   JSON names its retained artifact paths under `artifacts` so a later operator
   can resume from the report without reconstructing directory conventions from
   step names.
   `--degrade expire-one|suppress-one|corrupt-one|all` additionally retains
   expected negative evidence for expiry, suppression, corrupt carrier input, or
   all three lanes together without changing the normal exercise success
   criteria; the report names those roots under `artifacts.degradation_roots`.

The CI-grade proof for this path is:

```sh
cityb-biggun selftest --json
./scripts/smoke-cityb-three-binaries.sh
```

## How tiny can ultra-tiny be?

There are three different size questions:

| Question | Current answer | Implication |
|---|---|---|
| Native binary bytes | Size-tuned x86-64 release build now measures standalone `cityb-node` at 758,648 bytes / 0.72 MiB. The previous wrapper build measured 1,422,216 bytes / 1.36 MiB, and the default release before size tuning was about 3.0 MiB. | Package/link-graph boundaries matter more than shaving syntax inside a broad CLI wrapper. |
| Installed closure bytes | Current Nix package output is 8,080,520 bytes / 7.8 MiB by `du`; Nix closure size is 56,314,968 bytes / 53.7 MiB. Packaged `cityb-node` is 955,512 bytes. | A Nix app is reproducible, not appliance-tiny. Standalone/static/distroless distribution is a separate product target. |
| Runtime posture | The node is dependency-tiny and capability-tiny: receive/import/verify/status only; no signing, posting, planning, city-running, or lab machinery. | The security, UX, and deployment distinction now exists in the actual binary artifact. |

The first tiny binary used to be almost the same size as Goldilocks because it
was only a wrapper around `cityb-cli`: the surface refused capabilities, but the
linker still had to retain reachable broad CLI, council, publishing, city-run,
and audit paths. The current standalone package depends only on `cityb-core`,
`cityb-audit`, and `cityb-transports`, preserving Ed25519 verification,
canonical CBOR, archive completeness checks, pointer parsing, feed scanning,
state retention, and status output without linking the operator/lab machinery.

Current measured native release sizes on this x86-64 host:

| Build style | `cityb-node` | `cityb` | `cityb-biggun` |
|---|---:|---:|---:|
| Default release before size profile | ~3.0 MiB | ~3.0 MiB | ~3.3 MiB |
| Manually stripped default release | ~2.4 MiB | ~2.4 MiB | ~2.7 MiB |
| Size-tuned wrapper release profile before standalone split | 1,422,216 bytes / 1.36 MiB | 1,426,312 bytes / 1.36 MiB | 1,508,264 bytes / 1.44 MiB |
| Size-tuned standalone split, measured 2026-08-30 | 758,648 bytes / 0.72 MiB | 1,426,312 bytes / 1.36 MiB | 1,516,456 bytes / 1.45 MiB |
| Nix packaged binary after size profile, before standalone split | 1,726,528 bytes / 1.65 MiB | 1,735,232 bytes / 1.65 MiB | 1,834,832 bytes / 1.75 MiB |
| Nix packaged standalone split, measured 2026-08-30 | 955,512 bytes / 0.91 MiB | 1,735,400 bytes / 1.66 MiB | 1,839,064 bytes / 1.75 MiB |

The release profile is now size-oriented: `opt-level = "z"`, FatLTO,
`codegen-units = 1`, `panic = "abort"`, and stripped symbols. Re-measure with:

```sh
cityb-biggun footprint --bin-dir ./target/release --json
cityb-biggun selftest --json
cityb-biggun gate --release --quick --plan --json
./scripts/smoke-cityb-three-binaries.sh
```

`cityb-biggun footprint` emits native binary bytes, SHA3-256 digests, and
capability-card execution evidence for the three binaries. `cityb-biggun gate`
is the canonical local readiness surface over source checks, binary build,
selftest, optional target checks, optional docs, and optional release
archive/verify. The old footprint and smoke scripts are host/developer
conveniences, not the canonical measurement surface.
The next real target is field-tiny, not just
dependency-tiny. The path:

1. keep the receive-only crate dependent only on `cityb-core`, `cityb-audit`,
   and `cityb-transports`;
2. keep `cityb-council`, archive publishing, city planning, city running, lab
   reports, and poster adapters out of the tiny link graph;
3. preserve Ed25519 verification, canonical CBOR decode, pointer parsing,
   completeness/fork/freshness checks, local feed scanning, status serving, and
   deterministic state migration;
4. measure dynamic glibc, static musl where practical, ARMv7/aarch64, RAM,
   startup time, state growth, and Nix-closure forms as
   different artifacts rather than one "size" claim.
5. keep the portable node-kit format public-only and relocatable; if a receive
   node needs a new file, make the export command prove it did not import
   publisher/council/lab authority.

The measured dynamic x86-64 Linux binary is already sub-1 MiB without exotic
work. A static single-file artifact may be larger in binary bytes but smaller
and simpler than a Nix closure on non-Nix appliances. A `no_std` node is likely
a research toy unless the product also abandons ordinary Linux filesystem,
process, and network ergonomics; `std` is probably worth its cost.

What might surprise us:

- The smallest useful node may be a batch verifier, not a daemon: run, import,
  verify, update state, print status, exit. A timer or external fetcher can do
  the rhythm without giving CityB a network fingerprint.
- A zero-write cron mode may be the real field appliance: keep working state in
  `tmpfs`, mount flash read-only where possible, and write durable state only
  after a higher-epoch council-signed archive has fully verified.
- Binary bytes may matter less than write amplification. Cheap flash dies from
  logs, archives, and status churn before it cares about an extra megabyte of
  executable text.
- ARMv7 may fail on operational edges before cryptographic edges: old kernels,
  libc baselines, clock behavior, filesystem durability, package availability,
  and RAM pressure are likelier killers than Ed25519 verification speed.
- Static musl may be the right field artifact even if it makes the raw binary
  larger, because it removes the target machine's libc/Nix-store assumptions.
- A truly boring tiny node is strategically strong. If it never signs, never
  posts, never plans, and can be replaced from a fresh config plus public chain
  material, compromise recovery becomes cheap.

Portability rules:

- no binary-specific protocol fork;
- no architecture-specific serialization;
- no required SIMD, GPU, browser, or heavyweight daemon in the tiny node;
- `cargo check` must cover `x86_64` and `aarch64` for the workspace;
- `cargo check --bin cityb-node` must cover ARMv7
  when the target is installed;
- `cityb-biggun gate --target-check --strict-targets` is the strict source
  readiness gate; `./scripts/check-targets.sh --strict` remains a compatibility
  wrapper for the target-check portion. Non-strict local runs
  may report skipped cross targets when the developer shell lacks `rustup`;
- actual runtime claims for ARM hardware require retained transcript evidence.
- binary-size claims require checked-in measurement output or retained command
  transcripts naming the target, profile, linker mode, and libc/static posture.

## CLI direction

Current product verbs are enough for City B today:

```sh
cityb run --nodes 32 --parallelism 16 --root ./city-b-artifacts
cityb inspect --root ./city-b-artifacts
cityb verify --root ./city-b-artifacts
cityb node-kit --root ./city-b-artifacts --out ./city-b-node-kit
# one-shot retained local posting exercise
cityb exercise --root ./city-b-artifacts
(cd ./city-b-node-kit && ./run-node.sh)
cityb dead-drop plan --root ./city-b-drops --against ./city-b-artifacts/city-b-chain
cityb dead-drop receipt --root ./city-b-drops --medium status --location WHERE --pointer POINTER --against ./city-b-artifacts/city-b-chain --ttl-epochs N
cityb dead-drop audit --root ./city-b-drops --against ./city-b-artifacts/city-b-chain --min-media 2 --require
cityb dead-drop debt --root ./city-b-drops --against ./city-b-artifacts/city-b-chain --current-epoch auto --max-age 2 --min-media 2 --require
cityb dead-drop schedule --root ./city-b-drops --epoch E --beacon BEACON --all-media --pointer POINTER
cityb dead-drop post --root ./city-b-drops --adapter local-file --target ./city-b-drops/local-posts --against ./city-b-artifacts/city-b-chain --require
cityb dead-drop observe ./city-b-drops/local-posts --root ./city-b-drops --against ./city-b-artifacts/city-b-chain --require
cityb dead-drop capsule export --root ./city-b-drops --against ./city-b-artifacts/city-b-chain --out ./city-b-recovery-capsule --current-epoch auto --max-age 2 --min-media 2

In the retained City B layout, `cityb review` now treats the City B feed
trees (`city-b-pastebins/`, `city-b-dead-drops/`, `city-b-import-drops/`) as
the local baseline for governance scoring. A fresh retained run is therefore
correctly `planned-only`, while a successful `cityb exercise` can advance
the retained review to `ready` instead of being pinned behind a false
local-feed deficit.
That retained layout now also emits an operator-first posting surface:

- `city-b-operator-surface.md`
- `city-b-operator-surface.json`
- `city-b-operator-lanes/`

The operator surface compiles the current adapter lane plan, the retained
adapter-doctor posture, four ready-made one-envelope footholds, and both a
quick working post command plus a lane-aligned post command where they differ.
The lane-default directory is not new authority or a second planner. It is a
convenience layer so a human can start with one pointer, heartbeat, route-hint,
or mirror move without hand-authoring envelopes first.

Goldilocks now adds a first-class retained selector/executor on top of those
artifacts:

```sh
cityb foothold --root ./city-b-artifacts --json
cityb foothold --root ./city-b-artifacts --lane pointer --mode aligned --json
cityb foothold post --root ./city-b-artifacts --lane pointer --adapter local-file --brief --json
```

That surface reads the retained `city-b-operator-surface.json`, chooses one
ready-made foothold, prints the exact `dead-drop post` it would run, and can
execute exactly one selected move while refreshing the retained governance
reports afterward.

The default discipline is:

1. prove locally with `cityb exercise --root DIR --brief --json`;
2. preview one retained foothold with `cityb foothold --root DIR --json`;
3. optionally inspect `city-b-operator-surface.md` for the longer rationale;
4. post one lane-default foothold with `cityb foothold post --root DIR ...`;
5. read `cityb brief --root DIR --json` again.

This is the intended operator UX direction: one retained triage surface, one
retained posting surface, one retained directory of immediate footholds, and an
explicit split between the quickest working move and the more plan-aligned
follow-up move.
cityb-node dead-drop capsule verify --root ./city-b-recovery-capsule --json
cityb-biggun gossip-evidence --root ./city-b-drops --require --json
```

The frontier wants a v5 `dead-drop` surface. Implemented registry, local
adapter, score, debt, schedule, fragment, explain, and capsule commands:

```sh
cityb dead-drop adapter catalog
cityb dead-drop adapter init --root DIR
cityb dead-drop adapter doctor --root DIR
cityb dead-drop substrate catalog
cityb dead-drop substrate init --root DIR
cityb dead-drop substrate score --root DIR --against CHAIN-DIR --current-epoch auto --max-age N
cityb dead-drop debt --root DIR --against CHAIN-DIR --current-epoch auto --max-age N --min-media N --require
cityb dead-drop schedule --root DIR --epoch E --beacon BEACON (--min-media N | --all-media)
cityb dead-drop schedule --root DIR --epoch E --beacon-file BEACON-FILE --pointer POINTER
cityb dead-drop envelope --root DIR --epoch E --beacon BEACON --pointer POINTER --substrate SUBSTRATE [--material pointer|heartbeat|route-hint]
cityb dead-drop post --root DIR --adapter local-file --target DIR --against CHAIN-DIR --require
cityb dead-drop post --root DIR --adapter manual-drop --target DIR --against CHAIN-DIR
cityb dead-drop post --root DIR --adapter static-http --target DOCROOT --base-url URL --against CHAIN-DIR --require
cityb dead-drop observe PATH --root DIR --against CHAIN-DIR --require
cityb dead-drop fragment split --root DIR --pointer POINTER
cityb dead-drop fragment collect --root DIR --against CHAIN-DIR --require
cityb dead-drop fragment collect --root DIR --path MEDIA-A --path MEDIA-B --path MEDIA-C --against CHAIN-DIR --min-source-roots N --require
cityb dead-drop explain --root DIR --against CHAIN-DIR --current-epoch auto --max-age N --require
cityb dead-drop capsule export --root DIR --against CHAIN-DIR --out CAPSULE --current-epoch auto --max-age N --min-media N
cityb dead-drop capsule verify --root CAPSULE
cityb-biggun gossip-evidence --root DIR [--require]
```

`adapter init` writes `city-b-adapters.md` and `city-b-adapters.jsonl`, which
define the stable posting/observation seam and keep future service-specific
integrations from leaking into City B core.
`post` now implements practical staged and built-in adapter families.
`local-file` consumes
placement envelopes, writes explicit local target files shaped like the
selected substrate class, records placement receipts, and appends distribution
receipts for audit/debt. `manual-drop` stages operator publication packets:
carrier-shaped payload, posting guide, receipt command, and fetch/observe
guidance. It records placement receipts but deliberately does not append a
distribution receipt before the operator records a real public location.
`static-http` writes the same carrier-shaped material into an operator-owned
static docroot, derives the published URL from `--base-url` plus the relative
path, and probes that URL back through HTTP before recording success/failure
facts. `filehost-generic`, `git-release-generic`, and `object-store-generic`
stage deterministic upload packets and optionally probe one exact declared
remote URL. `github-release`, `gitlab-release`, `netlify-drop`,
`github-pages`, `gitlab-pages`, `codeberg-pages`, and `codeberg-release` now
promote that same staged posture into service-specific core adapters: they
write deterministic packets and operator guides in core, but leave
authenticated repo/release/UI/CLI mutation operator-owned and activate the
probe hook only when one exact public URL is declared. `filebin`, `paste-rs`,
`dpaste`, `0x0`, `catbox`, `litterbox`, `tmpfiles`, `file.io`, `uguu`,
`termbin`, `paste-c-net`, `nullpaste`, `sendit`, `temp-sh`, `storage.to`, `github-gist`, and `gitlab-snippet` are the current
built-in public-service mutators: they still stage local packet directories
first, then perform the HTTP or TCP publication in Rust and normalize the
returned public location back into the same receipt model. `litterbox` and
`tmpfiles` additionally choose bounded retention defaults from material kind
so short-lived and longer-lived lanes do not collapse into one service
setting; tmpfiles also resolves the API-returned viewer page to its direct
`/dl/...` download URL before probing exact bytes, NullPaste parses the API
`raw_url`, and temp.sh probes exact bytes through the returned viewer URL's
POST download action. The implemented adapters accept
pointer-backed `pointer`, `heartbeat`, and `route-hint` material.
Heartbeat marks and route hints are discovery/freshness/routing evidence only;
they do not grant authority or bypass the signed archive gate. Placement and
distribution receipts carry material, TTL, inclusive fresh-until epoch,
first-stale expiry epoch, max-posts-per-epoch, and failure-reason fields.
`observe` scans those local target files and records classified observation
receipts with the same freshness/rate contract and recoverable material
classification when substrate metadata, `label=...`, or `material=...` can be
recovered from source text.
`substrate score` keeps the legacy 0..100 readiness score and adds
decision-facing fields: resilience weight, exposure risk, freshness pressure,
evidence depth, risk penalty, decision score/band, verified/fresh/observed
failure-domain counts, and a recommended rotation. These weights are deliberately
heuristic until Biggun has enough retained experiments to calibrate them.
`capsule export` is the close-out handoff: it refreshes the derived debt and
explanation reports, copies public evidence plus the signed chain, and writes a
portable exact SHA3-256 manifest plus a marker-recorded signed-chain tip epoch.
`capsule verify` is deliberately implemented in the receive-only Tiny binary as
well as Goldilocks so a weak node can reject capsule drift, including
marker-vs-chain epoch disagreement, without trusting the operator binary that
exported it.
Remote-public operator-owned integrations are now live through staged adapters.
The seam is explicit and the current operator-owned remote adapters are
static-http, filehost-generic, git-release-generic, object-store-generic,
github-release, gitlab-release, netlify-drop, github-pages, gitlab-pages,
codeberg-pages, and codeberg-release; there is still no implicit public
posting.

## Covert-posting object model

### Placement envelope

A placement envelope is the unit the poster plane handles. It records what is to
be placed and how the adapter is allowed to encode it.

```json
{
  "kind": "cityb.dead-drop.placement.v1",
  "city": "city-b",
  "epoch": 42,
  "material": "pointer|fragment|heartbeat|route-hint|receipt",
  "token_hex": "38_HEX_POINTER_TOKEN",
  "encoding": "plain-token|wrapped-text|ocr-card|metadata-field|signed-event|syntactic-semver|mnemonic-card",
  "substrate_id": "status-page-primary",
  "rendezvous": {
    "beacon": "drand-fixture-round-123",
    "slot": 7,
    "not_before": "2026-08-30T12:00:00Z",
    "expires_at": "2026-08-31T12:00:00Z"
  },
  "freshness": {
    "ttl_epochs": 12,
    "fresh_until_epoch": 54,
    "expires_epoch": 55
  },
  "constraints": {
    "remote_mutation_allowed": false,
    "operator_owned_required": true,
    "max_bytes": 512,
    "max_posts_per_epoch": 1
  }
}
```

### Poster adapter

A poster adapter is a deliberately narrow driver:

```text
prepare(envelope, substrate) -> planned bytes + risk note
post(prepared, explicit target) -> placement receipt
observe(source) -> observation receipt
cleanup(target, receipt) -> best-effort cleanup receipt where applicable
```

Adapters must be boring internally. The cleverness belongs in selection,
encoding, redundancy, and evidence accounting. Every adapter should expose:

- whether it mutates anything remote;
- whether it is local-only, operator-owned, or public-research;
- its retention/TTL assumptions;
- its rate limits;
- how success is observed;
- which failure names it can emit.

`cityb dead-drop adapter catalog|init|doctor` is now the operator-facing
contract for these declarations. The adapter registry now carries operational
metadata for actual City B decisions rather than product-tier labels:

- `retention_class` — how the carrier behaves over time in practice
- `operator_touch` — whether posting is no-touch, token-backed, or workflow/UI
  owned
- `probe_surface` — what sort of fetch identity comes back for verification
- `payload_fit` — whether the adapter is naturally text, small-file, site-tree,
  or mixed
- `preferred_materials` — which of `pointer`, `heartbeat`, and `route-hint`
  the adapter is actually good at
- `mirror_fit` — whether the carrier is a plausible continuity/mirror lane or
  only a signal lane
- `hazard_flags` — practical caveats like single-consume, tight TTL, token
  requirements, cookie probes, or repo-workflow coupling
- `diversity_domain` — the service family used for correlation control so five
  pastebins do not masquerade as five independent lanes

`adapter doctor` now summarizes those fields into planning output so the
operator can see which adapters are best suited to pointer continuity, short
TTL wakeups, route-hint traffic, and durable mirror duties without treating
every carrier as interchangeable. `dead-drop plan` now consumes that same
metadata into concrete lane recommendations:

- pointer continuity lanes
- heartbeat/wakeup lanes
- route-hint lanes
- continuity mirror lanes

The planner explicitly prefers service-family diversity, exact or declared
probe surfaces, and durable mirror surfaces for continuity while pushing
single-consume or short-TTL services toward wakeup traffic instead.

### Substrate registry

The substrate registry is the operator-visible map of carrier assumptions.
`cityb dead-drop plan` now writes `city-b-substrates.json` and
`city-b-substrates.md`; `cityb dead-drop substrate score` writes
`city-b-substrate-score.json` and `city-b-substrate-score.md` from local feed,
scheduled-envelope, local-post, observation, receipt verification, freshness,
expiry, and failure evidence. Each substrate row includes a recommendation and
next action so the score report can be used as an operator work queue, not just
a passive inventory. `cityb dead-drop schedule` writes
`city-b-rendezvous-plan.json`, `city-b-rendezvous-plan.md`,
`city-b-rendezvous-beacon.txt`, and `city-b-placement-envelopes.jsonl` by
deterministically ranking declared substrates with epoch plus beacon entropy and
retaining the exact public beacon fixture for replay. Required fields:

```text
id
tier
adapter
operator_owned
remote_mutation_allowed
evidence_semantics
ttl_epochs
fresh_until_epoch
expires_epoch
max_posts_per_epoch
expected_lifetime
failure_domain
poll_cost
posting_cost
observability
blocking_blast_radius
legal_status
recent_success_rate
recent_failure_reasons
diversity_tags
```

Older generated artifacts may contain `collateral_block_cost`, the current
legacy implementation/report field name.
Future schemas should prefer `blocking_blast_radius`: a narrower measurement of
what else an operator-owned carrier loses if that carrier is
blocked. City B should not optimize for coercive use of unrelated
infrastructure.

The planner should never choose an undeclared substrate. If a human manually
uses a new substrate, they record it through `receipt` or the future
`substrate` command before it becomes part of automated planning.

## Substrate classes to build

Build local doubles for each class before any live integration.

| Class | Local double | Product value | Failure modes to model |
|---|---|---|---|
| File/feed | existing feed files plus noisy corpora | cheap baseline and operator import path | stale, duplicated, malformed, oversized |
| Status page | static local HTTP status thread | obvious operator-owned web surface | takedown, cache lag, partial update |
| Repo metadata | local Git issue/comment/release-note fixture | unremarkable developer workflow | force-push, branch drift, moderation deletion |
| Package index | local npm/PyPI-shaped JSON/HTML | metadata-backed discovery | CDN lag, yanked release, version confusion |
| CI log | local retained workflow log/artifact fixture | noisy generated text channel | retention expiry, truncation, secret-redaction mutation |
| Transparency log | CT/Rekor-style append-only Merkle log | inclusion/consistency proof lane | split view, missing inclusion, MMD miss |
| Nostr relay | local signed-event relay | simple volatile/event relay model | relay refusal, spam limits, disappearing event |
| libp2p DHT | local provider-record simulation | provider observation without content trust | provider expiry, closest-peer eclipse, churn |
| Local mempool | process-local pending pool | TTL/eviction/replacement model | eviction, replacement, local-vs-remote priority |
| IoTox/Tox | exported transcript fixture | route-aware gossip and Tox/DHT realism | offline route, relay-only path, accepted-not-delivered |
| OCR/print | generated card corpus | human recovery and sneakernet | transcription errors, wrapping, screenshot blur |

The first live integrations should be status page, repository metadata, and
operator-owned static package index because ownership and rollback behavior are
easiest to reason about. Nostr/libp2p/IoTox/mempool work belongs in the lab
until the observation semantics are measured.

## Rendezvous design

The rendezvous planner should be deterministic and replayable:

```text
city seed
  + signed epoch
  + public beacon round/value/proof
  + previous verified archive root
  + substrate registry
  + recent failure/debt facts
      -> ordered placement plan
      -> ordered observation plan
      -> receipt requirements
```

The planner should optimize for:

- failure-domain diversity;
- operator-owned substrates before third-party substrates;
- bounded human burden;
- low correlation between placements;
- TTL overlap, so every epoch has enough fresh evidence;
- floor budget preservation;
- fragment independence when using threshold shares.

The planner must be replayable by an auditor. If a plan changed because a
substrate was down, expensive, expired, or blocked, that reason should appear in
the plan.

Do not rely on public randomness alone when the city seed is public. A censor
that knows the seed and sees the beacon can compute the same target schedule as
the fleet. The preferred next design is state-ratcheted rendezvous: mix the
previous verified archive root into the placement PRF. Keep an explicit public
fallback or recovery-capsule path for nodes that missed the previous epoch.

The detailed provider-classified roadmap for this work lives in
[city-b-rendezvous-roadmap.md](city-b-rendezvous-roadmap.md). Its core priority
is to build directly for how providers solve rendezvous: public firehose/listing
feeds, deterministic slotted locations, pointer chains, erasure/archive lanes,
volatile relays such as Nostr, visual/OCR carriers, slow public anchors,
operator-side canary evidence, ASN/CDN topology scoring, and verified beacon
clocks. The first binary pass now stores durable rendezvous metadata on compiled
services, compares retained compiled deployment signatures with `cityb
rendezvous diff --root`, feeds rendezvous findings into short `cityb next`,
checks local firehose/listing fixtures through `cityb rendezvous doctor`, and
scores nominal providers against effective failure/provider/account/network/
moderation/copy roots so fake diversity is visible.

## Fragment strategy

Whole-token repetition is robust and simple. Fragmented pointers add censorship
cost but increase operator error and recovery complexity. City B now supports a
local `shamir-gf256-3-of-5` fragment loop: `cityb dead-drop fragment split`
writes five copyable share files and manifests; `cityb dead-drop fragment
collect` reconstructs from any three distinct share coordinates and can verify
the result against the signed chain. Collection reports include
`coordinates_seen`, `coordinates_needed`, `missing_indices`,
`source_roots_seen`, `source_roots`, and `source_root_requirement_met` so
partial feeds are actionable instead of just "failed." Coordinate threshold is
the cryptographic reconstruction threshold; `--min-source-roots N` is the
separate operational assertion that enough independent scanned media/import
roots contributed those coordinates.

Current and desired experiments:

```text
whole token repeated across 5 media
vs.
3-of-5 pointer fragments across the same 5 media
```

Acceptance criteria:

- a single fragment is not accepted as a pointer;
- duplicate media do not count as independent shares;
- reassembly is deterministic;
- OCR/operator-entry mutation curves use actual current line lengths;
- failed reassembly reports which share coordinates are missing or still needed;
- reconstructed pointers still pass the ordinary archive gate;
- lab reports quantify recovery probability, placement cost, and time to
  explanation.
Current CLI acceptance covers single-fragment refusal, three-share
reconstruction, deterministic archive verification, the ordinary archive gate,
pure-loss availability, carrier-compromise disclosure risk, compact checksum
share lines, and a naive per-character OCR/operator-entry mutation curve. The
remaining work is media-independence accounting, measured OCR mutation
fixtures, field loss-model measurement, deciding whether the compact frame
needs more redundancy or a shorter encoding, and deciding whether configurable
M-of-N is worth the extra operator/API surface.

Shamir is not the universal availability answer. It is best justified when
early pointer disclosure lets a scraper suppress the archive before receivers
fetch it. If the pointer is already public discovery material, Biggun should
also compare systematic byte erasure codes, repetition, mnemonic chunks, and
parity-framed cards. The operator-facing profile should choose the scheme from
the threat model: anti-leakage, random carrier loss, OCR mutation, or human
transcription.

## Heartbeats and dead-man behavior

Heartbeats are postings, not authority. They answer: "Was expected governance
maintenance visible in enough places recently?"

The implemented local adapter can now carry pointer-backed `heartbeat`
placement envelopes through envelope → post → observe → audit/debt material
fields. That is plumbing, not a dead-man policy. A future heartbeat-debt command
still needs an explicit signed policy before absence can change local posture.

Use signed heartbeat policy Acts to define:

- expected cadence;
- eligible substrate classes;
- minimum fresh media;
- missed-epoch threshold;
- local posture change when debt exceeds threshold;
- expiration and amendment path.

A missed heartbeat may tighten local posture, adjust polling within a capped
budget, preserve floor budget, or alarm. It must not grant new authority, bypass
threshold signatures, or make ordinary nodes speak upstream. Debt must use
hysteresis or leaky-bucket decay so selective heartbeat starvation cannot force
the fleet into linear polling escalation, battery drain, flash churn, or
floor-token exhaustion.

## Route hints

Route hints are postings, not routing authority. They answer: "Which recovery
or observation path was visible recently?" A hint can point operators and lab
workers toward a route family such as status-page import, DHT provider
observation, Tox-family transcript import, or removable-media recovery, but it
does not make a node migrate, publish, or trust a carrier.

The implemented local adapter can now carry pointer-backed `route-hint`
placement envelopes through envelope → post → observe → audit/debt material
fields. Biggun retains a separate `city-b-route-hint-drill/` beside the
heartbeat drill. This proves material preservation and freshness accounting; it
does not yet define a signed route-adoption policy.

Use signed route policy Acts later to define:

- eligible route families;
- minimum independent observations;
- replay and expiry windows;
- when a hint may alter polling order;
- when it is only an operator advisory;
- how a successor policy rotates or revokes routes.

## Observation and adoption

Observation is deliberately separate from adoption:

```text
observed bytes
  -> candidate token or fragment
  -> checksum/format validation
  -> reconstruction if needed
  -> pointer/archive verification
  -> normal gate evaluation
  -> adoption, refusal, or debt
```

Every refusal should be named. Preferred refusal names:

- malformed-token;
- stale-pointer;
- archive-missing;
- archive-pruned;
- rollback;
- freeze;
- mix-and-match;
- wrong-object;
- fork;
- threshold-insufficient;
- ttl-expired;
- substrate-untrusted;
- remote-mutation-not-authorized;
- endless-data-budget-exceeded.

These names should show up in CLI output, JSON, lab reports, and recovery
explanations.

## City B scenario plan

The next City B scenario should stop being only a blackout story and become a
covert-posting exercise.

```text
B0 baseline
  sign archive, publish overt pointer, verify default fleet

B1 planned covert placement
  generate substrate registry, rendezvous plan, placement envelopes, shaped
  local-file posts, observation receipts, and distribution receipts for local
  doubles

B2 pressure
  cut overt mirror, serve stale pointer, prune archive copy, add noisy feed
  tokens, expire one CI log, and block one substrate class

B3 recovery through covert material
  scan feeds, reconstruct fragments, verify archive, record refusal names, and
  discharge or report freshness debt

B4 volatile gossip
  import Nostr/libp2p/local-mempool/IoTox transcript observations, run
  Biggun gossip-evidence against retained schedule/post/observe receipts, and
  prove that TTL-bound gossip improves discovery without becoming authority

B5 explanation
  emit a recovery report that tells the operator which placements worked, which
  failed, what was adopted, what was refused, and which commands replay the
  proof
```

`cityb run` should eventually retain these artifacts:

```text
city-b-substrates.json
city-b-rendezvous-plan.json
city-b-rendezvous-plan.md
city-b-rendezvous-beacon.txt
city-b-placement-envelopes.jsonl
city-b-placement-receipts.jsonl
city-b-observation-receipts.jsonl
city-b-noise-corpus/
city-b-noise-report.json
city-b-noise-report.md
city-b-fragments.json
city-b-fragment-report.json
city-b-receipt-debt.json
city-b-receipt-debt.md
city-b-heartbeat-debt.json
city-b-volatility-report.json
city-b-recovery-explainer.json
city-b-recovery-explainer.md
```

## Milestones

| ID | Name | Exit criteria |
|---|---|---|
| B0 | Current product protected | existing City B workflow, feed collection, hostile rejection, fork alarms, detector audit, and retained evidence stay green |
| B1 | Evidence grammar | substrate registry, placement envelope, placement receipt, observation receipt, TTL, rate, failure-reason, and receipt freshness-debt schemas exist in docs and code |
| B2 | Planner | deterministic `dead-drop schedule` produces replayable placement plans from beacon fixture + registry + previous verified archive root + epoch, with an explicit fallback path for receivers that missed the ratchet input |
| B3 | Local doubles | implemented `local-file` adapter posts pointer envelopes into substrate-shaped local doubles and observes them back; `static-http` extends the same envelope and receipt model to operator-owned static docroots with deterministic HTTP probe facts; `dead-drop noise corpus` generates dirty text/log/transcript/volatile-gossip recovery fixtures with valid pointer tokens, compact fragment shares, and deliberately damaged fragment lines; Biggun now cross-checks retained Nostr, libp2p/provider, local-mempool, and IoTox transcript schedule/post/observe receipts with `gossip-evidence`; next expand fixture semantics/metrics for status, repo, package, CI, transparency-log, live transcript import, and heavier OCR |
| B4 | Fragment and erasure comparison | current 3-of-5 split/collect path and Biggun subset matrix stay green; whole-token vs threshold fragments measured under pure loss, carrier-compromise disclosure risk, and OCR/operator-entry mutation models using actual current line lengths; current share output is compact `cityb-s1 SET INDEX HEX CHECK` with legacy verbose parsing retained; pure-loss and naive mutation favor whole-token repetition, while carrier-compromise disclosure risk favors threshold fragments; next measure real OCR/noise fixtures and compare systematic erasure/mnemonic/card encodings before deciding whether more redundancy or shorter encoding is needed |
| B5 | Covert-posting adapters | `local-file`, `manual-drop`, `static-http`, `filehost-generic`, `git-release-generic`, `object-store-generic`, `github-release`, `gitlab-release`, `netlify-drop`, `github-pages`, `gitlab-pages`, `codeberg-pages`, `codeberg-release`, `file.io`, `uguu`, `termbin`, `paste-c-net`, `nullpaste`, `sendit`, `temp-sh`, `storage.to`, `github-gist`, `gitlab-snippet`, `filebin`, `paste-rs`, `dpaste`, `0x0`, `catbox`, `litterbox`, `tmpfiles`, and `plugin-external` implement the first envelope/post/probe/observe seam with explicit targets, format-preserving encoding hooks, TTL/rate/failure metadata, service-specific retention defaults where the carrier enforces them, service-mode-aware receive cursors, offline provider-fixture replay, final-location/redirect/status evidence, continuation cursor footholds, observation freshness/decay, provider-health classification, rotation pressure, and service/root request budgets; the next layer is service-specific read recipes and additional free-service adapters, with `plugin-external` reserved for experiments that are not yet worthy of core promotion |
| B6 | Recovery explainer | `dead-drop explain` turns retained dead-drop evidence, including dirty-noise recovery reports when present, into a replayable operator narrative and writes JSON plus Markdown reports |
| B7 | Scaled pressure | `city-b` runs with large local fleets and per-node probes while the covert-posting scenario remains bounded and explainable |
| B8 | Operator integration pack | operator-owned status/repo/package integrations documented and gated; public science trials remain manual and transcript-based |
| B9 | Three-binary handoff | Goldilocks exports a public tiny-node kit including the retained governance baseline and compiles listener configs with deployment digest, listener-plan digest, and shared parser version; Tiny boots, verifies, rejects declared/provisioned listener identity drift, reconstructs serve state from current or previous checkpoints when `status.json` is missing, and reports the kit's governance schedule/score summary plus listener identity and field-mode report; Biggun runs matrix/lab, reports target support, runs real-binary handoff, compares Goldilocks and Tiny parser binaries over identical carrier corpora with `parser-diff`, separately requires Tiny recovery from the full local import-drop mesh, local binary footprint with per-binary SHA3-256 digests, local dead-drop plan/receipt/audit/full-substrate schedule/post/observe/noise/fragment proof, requires Tiny token recovery and Tiny fragment reconstruction from the generated dirty corpus, requires both Goldilocks and Tiny to reconstruct fragments from three distinct local source roots, requires retained `gossip-evidence` success for the four volatile-gossip lanes, replays cycle journals/history/probe/reliability/cursor evidence with correlation-root, fixture, redirect, HTTP-status, and provider-health reporting, and performs from-scratch exercise checks against the same City B protocol, retaining `city-b-three-binary-exercise.json`, `city-b-recovery-summary.{json,md}`, `city-b-binary-footprint.json`, `city-b-fragment-matrix.json`, `city-b-dead-drop-governance/city-b-gossip-evidence.json`, and `city-b-dead-drop-governance/city-b-fragment-source-roots/` as resumption proof; the recovery summary preserves explicit Goldilocks run/planned-review/exercise/ready-review checkpoints, Tiny-reported kit/capsule governance facts, and Biggun's per-binary footprint digests in first-class JSON/Markdown fields; the exercise JSON names these artifacts explicitly; degraded exercise modes retain named expiry/suppression/corruption roots |
| B10 | Field-tiny appliance proof | Tiny supports batch/zero-write receive cycles, retained field-mode write reports, retained write-count/RSS/state-growth measurements, and crash-safe epoch advancement on x86-64, aarch64, and ARMv7 check-target evidence; process-level fixtures now inject atomic-write failures before-create, before-write, and before-rename across provision files, current/previous checkpoints, `status.json`, and `field-mode-report.json`, then prove restart from the same state directory |

## Historical implementation ledger

The numbered list below records the implementation order that produced much of
the current system. Many entries are now implemented or reduced to empirical
follow-up. It is retained for architectural context, not as the current work
queue. Use [city-b-next-campaign.md](city-b-next-campaign.md) for the active
operator-first order.

1. Move receipt/debt/explain facts that are now hand-rendered in the CLI toward
   shared typed report structs if the module keeps growing. The retained review
   path should consume one governance-evidence summary model instead of
   re-deriving posture from separate score/provenance/negative-map/archive
   artifacts in multiple places.
2. Keep adapter metadata operational: `retention_class`, `operator_touch`,
   `probe_surface`, `payload_fit`, `preferred_materials`, `mirror_fit`,
   `hazard_flags`, `diversity_domain`, and provider-health buckets should stay
   first-class in catalog, doctor, planner, and review output.
3. Use those metadata fields strongly enough that another service tranche is
   chosen from evidence: continuity should prefer durable mirrors, wakeups
   should prefer ephemeral lanes, and repeated adapters inside one service
   family should count as correlated.
4. Keep `cycle next` repair guidance honest. The provider-health mapping,
   ranked `service_repair_queue`, `deployment recipes`, service-mode-aware
   receive commands, and fixture-template commands now exist; next specialize
   provider field names, expiry rules, and cursor behavior only after fixture
   or live-service evidence proves the provider's semantics.
5. Expand the captured fixture corpus for free services beyond the current
   local-proof, synthetic free-five, explicit free-stable/free-wide, and dated
   2026-09-12 through 2026-09-16 live free-five/free-stable/free-wide service
   sets, including promoted and mixed-history provider evidence, redirect drift, final URL churn, expiry, permission failure,
   rate limiting, oversized bodies, wrong encodings, stale content,
   parser-version disagreement, and cursor continuation transcripts. Replay it
   in normal tests and Biggun before promoting any new adapter behavior.
6. Keep expanding `dead-drop substrate score` from the current recommendation,
   next-action queue, resilience/exposure/freshness heuristics, and correlated
   failure-domain counts toward empirically calibrated weights.
7. Feed the implemented `cityb profile catalog|compile` seam into deeper
   placement queues and Biggun comparisons before adding more low-level knobs.
   The first implemented profiles cover benign outage, carrier loss, early
   scraper, human recovery, low-power field, high-churn gossip, and audit-heavy
   cases.
8. Keep extending the shared `cityb-transports::pointer_format` registry into
   parser-differential corpora, OCR/noise fixtures, and service-native receive
   recipes. A receipt must never claim an encoding that Tiny cannot decode.
9. Move rendezvous planning from public-beacon-only schedules toward the
   provider-classified roadmap: first metadata/posture, operator explanation,
   plan diff, bounded firehose fixtures, and one real firehose reader; then
   previous archive-root ratchets, deterministic slotted locations, pointer
   chains, slow public anchors, and explicit fallback for receivers that missed
   an epoch.
10. Add adapter authority manifests for remote-capable adapters: ownership,
    credential source, allowed targets, rate limits, public visibility, cleanup
    semantics, operator confirmation, and shutdown command.
11. Extend the retained City B governance baseline beyond registry, schedule,
    score, provenance, current `gossip-evidence`, and provider-health replay
    into richer lab-derived evidence while keeping live remote mutation explicit
    and reviewable.
12. Add richer local status/repo/package/CI doubles in `cityb-lab` and wire them
    into City B retained runs.
13. Measure compact checksum share framing against real OCR/noise fixtures
    instead of only the current naive per-character mutation curve; compare
    Shamir with systematic erasure, repetition, mnemonic chunks, and cards
    before deciding whether additional redundancy, grouping, or a shorter
    encoding is justified.
14. Keep feeding real service, OCR, screenshot, and malformed carrier captures
    into Biggun `parser-diff` so Tiny and Goldilocks keep extracting the same
    candidates and checksum-valid counts from identical carrier-shaped corpora.
15. Implement heartbeat hysteresis so debt changes posture and warning state
    without uncapped fetch escalation, battery drain, flash churn, or
    floor-token depletion.
16. Expand the current volatile-gossip fixtures from local schedule/post/observe
    receipt proof into replayable transcript-import fixtures, route diversity,
    and live-operator trial notes for Nostr/libp2p/local-mempool/IoTox.
17. Expand `dead-drop archive-availability` into review-driven next actions and
    richer mirror classes. Mirror receipts prove bytes observed, not
    legitimacy.
18. Keep expanding `dead-drop explain` from dead-drop-only evidence toward full
    retained City B run narratives that also summarize fleet status and refusal
    causes.
19. Build toward a content-addressed evidence graph under the readable
    Markdown/JSON reports.
20. Add field-tiny zero-write measurements alongside existing binary/RSS
    footprint checks and the retained field-mode write report.
21. Keep expanding `cityb-biggun selftest`, `cityb-biggun handoff`, and
    `cityb-biggun exercise` whenever a new
    receive/operator/lab seam appears; keep generated replay scripts and the
    combined degraded exercise path in the Rust proof. Keep strict fragment source-root
    recovery in that seam so one copied transcript cannot masquerade as carrier
    diversity. Full-registry exercise paths should use `--all-media`, not a
    hardcoded substrate count. For the next step beyond same-process smoke, use
    `scripts/stage-cityb-vm-trial.sh` plus `docs/city-b-vm-testing.md` to stage
    the bounded same-host multi-VM handoff drill.
22. Treat real testing as a ladder: single-host retained proof first, fixture
    replay from real free services second, same-LAN multi-host recovery third,
    carrier-shaped parser differentials fourth, adversarial timing/decay drills
    fifth, long-soak field-tiny hardware measurements sixth, and operator
    handoff trials last.

## Non-negotiable invariants

- Covert posting is real product capability.
- Posted material is discovery material, not execution authority.
- Nodes stay receive-only with respect to public carriers and governance, but
  may use their narrow correspondence identity to return bounded status,
  fault, notice, and capability envelopes to an operator-owned spool. That
  return path never carries governance authority. A Goldilocks bridge sidecar
  may transport the already encrypted envelope through bounded event relays;
  the sidecar does not gain governance or correspondence-signing authority.
- No carrier quorum: media diversity increases availability and evidence, not
  legitimacy.
- Every remote mutation is explicit, configured, bounded, and attributable to an
  operator role.
- No design depends on coercive use of unrelated infrastructure.
- Every observation has TTL/freshness semantics.
- Every refusal is named.
- Every successful recovery can be replayed from retained artifacts.
