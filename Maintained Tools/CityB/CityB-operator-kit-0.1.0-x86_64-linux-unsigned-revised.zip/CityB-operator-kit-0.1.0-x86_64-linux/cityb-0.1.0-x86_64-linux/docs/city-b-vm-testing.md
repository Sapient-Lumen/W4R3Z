# City B VM testing on one physical host

This is the practical same-host approximation for City B real testing when we do not have separate hardware. It uses multiple guests to buy process, boot, filesystem, and operator separation without overstating what that means.

Use it for:

- proving Goldilocks and Tiny survive a guest boundary
- proving the public node-kit and recovery-capsule handoff are usable outside the publisher environment
- proving retained review and exercise artifacts remain sufficient after files cross a machine boundary

Do not describe it as proof of:

- independent physical failure domains
- hostile WAN carrier behavior
- router/firewall asymmetry
- radio, battery, or flash-wear field conditions

## Host-side staging

Stage a bounded trial pack from the CityB standalone repo:

```sh
nix develop -c ./scripts/stage-cityb-vm-trial.sh --out /tmp/cityb-vm-trial
```

Preferred automated Sandwurm launch:

```sh
nix develop -c ./scripts/run-cityb-sandwurm-vm-trial.sh --trial-root /tmp/cityb-vm-trial
```

Equivalent repo gate:

```sh
just cityb-vm-trial
```

This creates:

- `publisher-city-b/` — retained Goldilocks run root
- `receiver-public/city-b-node-kit/` — public Tiny kit
- `receiver-public/city-b-recovery-capsule/` — public recovery capsule
- `observer/biggun-handoff-kit/` — host-side Biggun handoff proof
- `host-runbook.sh`, `publisher-guest.sh`, `receiver-guest.sh`, `observer-guest.sh`

The automated runner stages a temporary guest flake, launches one fresh direct Cloud Hypervisor guest per requested role, and retains live receipts under `/tmp/cityb-vm-trial/vm-live/`.

## Sandwurm preflight

Before launching guests on this machine:

```sh
cd /home/h0p3/projects/sandwurm
./sandwurm status --brief
./sandwurm probe --json
```

These are readiness checks only. The automated runner still uses Sandwurm's direct live-chain probe rather than inventing a second VM launcher.

## Automated runner contract

`scripts/run-cityb-sandwurm-vm-trial.sh` currently chooses the shortest testable path:

- host builds the role-specific guest image through Sandwurm's direct Cloud Hypervisor path
- each guest includes the CityB binaries and the packaged HTTP adapter dependency in its system closure
- each guest reads the staged trial pack as immutable input
- each guest copies only the role-local writable subset into guest-private state before executing it

That proves separate guest boot and lifecycle boundaries without depending on guest-local Rust compilation.

## Observed on September 2, 2026

The automated runner now has a real same-host green proof on `x86_64-linux` with Sandwurm direct Cloud Hypervisor guests. A full three-role run completed successfully at:

- proof root: `/tmp/cityb-vm-trial-full.yFKUP2`
- top-level summary: `/tmp/cityb-vm-trial-full.yFKUP2/vm-live-summary.json`
- top-level status: `ok`
- observed_at: `2026-09-02T01:52:37Z`
- role chain observations:
  - publisher: `2026-09-02T01:39:55Z`
  - receiver: `2026-09-02T01:47:00Z`
  - observer: `2026-09-02T01:52:37Z`

The path to green exposed four actual seams:

- guest role ordering: the CityB role service originally ran after `sandwurm-guest-receipts.service`, which let Sandwurm treat the guest as done and power it off before the role summary existed
- retained City B relocation: copied retained runs could fail Biggun handoff because City B node discovery trusted absolute topology coordinates before looking at the copied node directories
- governance overfit: City B governance verification required the original absolute `--against` chain path string inside `city-b-substrate-score.json` instead of verifying relocatable score semantics
- kernel preseed realism: the Sandwurm direct path needed the actual built guest kernel payload (`system.build.kernel/bzImage` on this guest) instead of assuming `kernel.dev/vmlinux` existed

The current runner and City B verifier now pass a clean retained VM drill after those fixes.

This VM drill is intentionally an explicit host gate, not part of `scripts/check.sh`. It depends on Sandwurm host preparation, `/dev/kvm`, and direct Cloud Hypervisor readiness; those are valid release checks for prepared operator machines, but not universal developer preconditions.

## Manual guest contract

Whichever Sandwurm guest lane you choose, the guest should have:

- the CityB repo projected into the guest
- the staged trial-pack directory mounted or copied into the guest
- a working Nix toolchain so the guest can build the CityB binaries locally

The guest should not rely on host-built binaries being directly runnable.

## Minimal three-seat drill

1. Publisher guest
   - run `publisher-guest.sh`
   - confirms retained review and local-post exercise still hold inside the guest
2. Receiver guest
   - run `receiver-guest.sh`
   - runs the Tiny node kit and verifies the public recovery capsule
3. Optional observer guest
   - run `observer-guest.sh`
   - replays the Biggun handoff path from another guest

Success means:

- Tiny in a different guest reports ACTIVE from the exported public kit
- Tiny verifies the recovery capsule without needing publisher-private authority
- Goldilocks review and exercise still produce coherent retained evidence
- Biggun handoff can be replayed from outside the original publisher session

## What this adds over the local smoke

Compared with `cityb-biggun selftest`, the VM drill adds:

- a distinct guest boot and userspace
- a real file handoff boundary between publisher and receiver roles
- an opportunity to catch path, manifest, and environment assumptions hidden by same-process or same-shell execution

## Next testing layers after this

After the VM drill is green, the next valuable layers are:

1. parser differentials over the same dirty corpus in separate guests
2. forced stale/expired/partial-archive epoch drills across guest restarts
3. long-soak zero-write Tiny runs in the smallest viable guest shapes
4. operator handoff drills where a fresh human uses only the retained artifacts
