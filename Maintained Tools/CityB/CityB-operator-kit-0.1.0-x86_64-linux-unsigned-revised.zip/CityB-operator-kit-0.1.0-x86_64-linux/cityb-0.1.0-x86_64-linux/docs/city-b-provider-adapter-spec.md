# City B provider adapter spec

This document defines the stable adapter seam for City B publication and
observation.

It is intentionally narrower than the surrounding speculation. The goal is to
let City B gain provider-specific integrations without changing its core
authority and evidence model.

The ideal phase split is specified in
[city-b-hook-model.md](city-b-hook-model.md).

## Contract

An adapter may:

- transform City B material into provider-shaped bytes;
- publish those bytes through a local, manual, or operator-owned remote path;
- fetch or observe provider results;
- normalize receipts and failure names.

An adapter may not:

- authorize state transitions;
- bypass archive verification;
- treat provider acceptance as governance acceptance;
- smuggle unreviewed provider semantics into the authority plane.

## Registry format

The operator-visible registry lives at:

- `city-b-adapters.md`
- `city-b-adapters.jsonl`

Each JSONL line is one flat adapter record:

```json
{
  "kind": "cityb.dead-drop.adapter.v1",
  "id": "local-file",
  "class": "local-double",
  "status": "implemented",
  "mutation_mode": "local-only",
  "target_kind": "directory",
  "roles": "placement,observation,receipt",
  "materials": "pointer,heartbeat,route-hint",
  "implemented": true,
  "operator_owned_required": true,
  "remote_mutation_default": false,
  "retention_class": "operator-controlled",
  "operator_touch": "none",
  "probe_surface": "local-path",
  "payload_fit": "text",
  "preferred_materials": "pointer,heartbeat,route-hint",
  "mirror_fit": "none",
  "hazard_flags": "local-double-only",
  "diversity_domain": "local-double",
  "future_encoding_hooks": true,
  "future_placement_hooks": true,
  "future_probe_hooks": true,
  "note": "Writes substrate-shaped local doubles and normalized receipts only."
}
```

The current doctor command validates:

- record kind;
- required fields;
- known adapter IDs;
- whether each entry still matches the built-in contract;
- how many adapters default to remote mutation;
- how many distinct service families exist;
- whether continuity recommendations collapse into one correlated family;
- whether at least one implemented adapter exists.

## Current built-in adapter IDs

As of September 15, 2026, the registry model includes:

- `local-file`
- `manual-drop`
- `static-http`
- `filehost-generic`
- `git-release-generic`
- `object-store-generic`
- `github-release`
- `gitlab-release`
- `netlify-drop`
- `github-pages`
- `gitlab-pages`
- `codeberg-pages`
- `codeberg-release`
- `file.io`
- `uguu`
- `termbin`
- `paste-c-net`
- `nullpaste`
- `sendit`
- `temp-sh`
- `storage.to`
- `github-gist`
- `gitlab-snippet`
- `filebin`
- `paste-rs`
- `dpaste`
- `0x0`
- `catbox`
- `litterbox`
- `tmpfiles`
- `plugin-external`

`local-file`, `manual-drop`, `static-http`, `filehost-generic`,
`git-release-generic`, `object-store-generic`, `github-release`,
`gitlab-release`, `netlify-drop`, `github-pages`, `gitlab-pages`,
`codeberg-pages`, `codeberg-release`, `file.io`, `uguu`, `termbin`,
`storage.to`, `github-gist`, `gitlab-snippet`, `filebin`, `paste-rs`,
`dpaste`, `paste-c-net`, `nullpaste`, `0x0`, `catbox`, `litterbox`,
`tmpfiles`, `sendit`, `temp-sh`, and `plugin-external` are
implemented today.

## Intended runtime interface

The runtime interface should remain close to this shape:

```text
capabilities() -> adapter contract
validate_config(registry_entry) -> ok | named failure
prepare(envelope, substrate, policy) -> prepared bytes + staging facts
publish(prepared, explicit target) -> placement receipt
observe(source) -> observation receipt
probe(target) -> health facts
replay_fixture(captured bytes or captured failure) -> probe-compatible health facts
cleanup(target, receipt) -> cleanup receipt
normalize(raw result) -> normalized receipt/failure
```

That interface is deliberately boring. The point is that City B core should
only consume normalized facts.

Probe facts now include the selected or observed `parser_encoding` when City B
can know it. Local, staged, static-HTTP, upload-packet, live-service, and
plugin-external paths therefore report not only that a payload was parseable,
but which shared parser decoded it. A plugin executable receives
`POLIS_PLUGIN_PARSER_ENCODING` and may return `"parser_encoding":"..."` in its
stdout object. Missing parser encoding is allowed only when the adapter could
not inspect bytes or the plugin did not declare a parser.

Deployment service records also carry receive-planning metadata used by the
cycle scheduler:

- `request_budget`
- `request_cost`
- `rate_limit_window_secs`
- `collector_mode`
- `collector_source`

These fields are operator policy, not provider authority. The planner subtracts
fresh verified service/lane observations first, then spends request budget only
for remaining deficits. Root request budget applies across failure,
provider, account, network, moderation, and copy roots so correlated services
cannot hide as independent spend. A cursor source lets Goldilocks discover
candidate locations from one reviewed listing endpoint or file; it does not
permit broad crawling or credential discovery.

`collector_mode` is a closed receive-mode registry:

- `exact-local`: exact local file/path lists.
- `plain-url-list`: simple URL/path token lists.
- `operator-static-index` / `static-index`: HTML `href`/`src` and JSON URL fields, including relative links resolved against the listing source.
- `json-url-fields`: provider-shaped JSON objects with `url`, `raw_url`, `download_url`, `browser_download_url`, `location`, or similar fields.
- `gist-snippet-raw`: raw URL fields from gist/snippet-style APIs.
- `release-assets`: release asset download URLs and related exact release fields.
- `returned-url-only`: exact returned URLs or files only; the service is not treated as provider-enumerable.
- `plugin-cursor`: an external adapter-owned cursor surface that must still return normalized exact probe targets.
- `not-enumerable`: explicit refusal to discover; use exact probes or returned locations.

Cursor reports include `collector_mode`, `service_native_cursor`, and
`enumeration_capable` so later review can distinguish a real empty listing
from a service that never promised enumeration.

Probe-compatible facts also include `provider_health` when the receive path can
classify the outcome. The current health labels are `verified`,
`auth-or-permission`, `moderation-or-expired`, `rate-limited`,
`provider-error`, `network-unreachable`, `network-or-provider-failure`,
`local-input-unavailable`, `content-missing`, `stale-or-wrong-content`,
`parser-mismatch`, `parser-corrupt`, and `unknown-failure`. These labels are
scheduler inputs, not authority. They tell Goldilocks whether the next action
should look like credential repair, service rotation, rate backoff, parser
investigation, or ordinary reposting.

Fixture replay is now a first-class receive input. `collect fixture` reads JSONL
records containing service, lane, encoding, expected pointer, location, optional
final location, optional redirect count, optional HTTP status, and either
captured bytes or a captured fetch failure. It performs no network request and
writes the same content-addressed probe receipts and service reliability rows as
live `collect probe`, with `source_kind=fixture-replay` and a digest-stable
`fixture_id`. This lets real service behavior be captured once and replayed in
development, Biggun analysis, and regression tests without depending on a
provider being live during every run.

Probe-compatible receipts should carry these receive facts:

- requested `location`;
- `final_location` after redirects, or the original location when no redirect
  fact is known;
- `final_location_changed`;
- `redirect_count`;
- `http_status` when HTTP(S) was used or a fixture captured it;
- `provider_health`;
- parser counts and selected encoding evidence.

Cursor reports should carry the same source-side facts for the listing fetch:
`source_final_location`, `source_final_location_changed`,
`source_redirect_count`, `source_http_status`, a retained listing digest, and an
optional continuation object with the original provider field plus a normalized
follow-up location when one can be derived. Biggun replay consumes those fields
as evidence; it does not re-fetch providers.

## Failure names

Adapters should emit named failures rather than vague status text. Good
examples:

- `target-invalid`
- `operator-owned-required`
- `remote-mutation-disabled`
- `rate-limited`
- `placement-rejected`
- `placement-unobservable`
- `fetch-failed`
- `probe-failed`
- `receipt-unparseable`
- `contract-mismatch`
- `http-body-mismatch`
- `http-token-missing`

These names belong in receipts and reports so operator review stays actionable.

## Reserved future hooks

The adapter model intentionally reserves room for:

- format-preserving encodings;
- provider-specific placement shaping;
- provider-specific probe strategies;
- service plugins that preserve the same receipt contract.

Those hooks are reserved because the architecture should be ready for them.
They are not a justification to let adapters own authority.

## CLI surface

The current seam is surfaced through:

```sh
cityb dead-drop adapter catalog
cityb dead-drop adapter init --root DIR
cityb dead-drop adapter doctor --root DIR
cityb deployment recipes [--file city-b.toml] [--service SERVICE] [--adapter ADAPTER] [--json]
cityb collect probe --root RUN --deployment city-b.toml --service SERVICE --location URL_OR_FILE --json
cityb collect cursor --root RUN --deployment city-b.toml --service SERVICE --lane LANE --source LISTING_URL_OR_FILE --json
cityb collect fixture --root RUN --deployment city-b.toml --fixture captured-provider-fixtures.jsonl --json
cityb collect fixture-template --root RUN --deployment city-b.toml --out provider-fixtures.jsonl [--case NAME] [--all-cases] --json
```

This keeps the operator-visible contract explicit while letting collection
probes and cursors record observed service health without building crawler logic
into the adapter registry.
`deployment recipes` is the side-effect-free service guide for the same seam:
provider class, mutation/receive surface, collector mode, lanes, encodings,
retention, probe and cursor recipe, fixture cases, hazards, repair notes, and
deployment-local roots/budgets when a manifest is supplied. `collect
fixture-template` writes checksum-valid fixture JSONL from the retained pointer
and deployment so field captures start as replayable records instead of bespoke
notes. By default it writes the verified case. `--case NAME` requests specific
fixture cases, while `--all-cases` expands the adapter recipe's declared replay
set and refuses cases the adapter does not claim.

The current live adapters prove these distinct postures:

- `local-file`: local doubles only
- `manual-drop`: operator-copy staging without remote mutation
- `static-http`: operator-owned docroot mutation plus deterministic HTTP probe
- `filehost-generic`: deterministic upload packet staging plus optional exact
  download-URL probe
- `git-release-generic`: deterministic release packet staging plus optional
  exact release-note or asset URL probe
- `object-store-generic`: deterministic object packet staging plus optional
  exact object URL probe
- `github-release`: deterministic GitHub Releases packet staging plus optional
  exact `browser_download_url` or release-note URL probe
- `gitlab-release`: deterministic GitLab Releases packet staging plus optional
  exact asset or stable release-link URL probe
- `netlify-drop`: deterministic Netlify Drop packet staging plus optional exact
  deployed site URL probe
- `github-pages`: deterministic GitHub Pages site staging plus optional exact
  published site URL probe
- `gitlab-pages`: deterministic GitLab Pages site staging plus optional exact
  published site URL probe
- `codeberg-pages`: deterministic Codeberg Pages site staging plus optional
  exact published site URL probe
- `codeberg-release`: deterministic Codeberg release packet staging plus
  optional exact release asset or release-page URL probe
- `file.io`: built-in Rust publication to file.io plus immediate probe of the
  returned single-consume URL
- `uguu`: built-in Rust publication to Uguu plus immediate probe of the
  returned short-TTL URL
- `termbin`: built-in Rust raw TCP publication plus HTTP probe of the returned
  URL
- `paste-c-net`: built-in Rust HTTPS text publication plus exact returned URL
  probe
- `nullpaste`: built-in Rust publication to the NullPaste anonymous text API
  plus exact payload verification at the returned JSON `raw_url`
- `sendit`: built-in Rust HTTPS upload plus exact payload verification at the
  returned download URL
- `temp-sh`: built-in Rust publication to the temp.sh upload endpoint plus
  exact payload verification through the service-specific POST download action
  on the returned viewer URL
- `storage.to`: built-in Rust publication to the storage.to ShareX endpoint
  plus immediate probe of the returned URL
- `github-gist`: built-in Rust authenticated gist creation plus anonymous
  raw-URL probe
- `gitlab-snippet`: built-in Rust authenticated GitLab snippet creation plus
  raw-URL probe
- `filebin`: built-in Rust publication to a Filebin-compatible unauthenticated
  HTTP file host plus exact payload verification through the public retrieval
  path
- `paste-rs`: built-in Rust publication to a paste.rs-compatible text endpoint
  plus exact payload verification at the returned paste URL
- `dpaste`: built-in Rust publication to a dpaste-compatible text endpoint
  plus exact payload verification through the returned paste's raw `.txt` URL
- `0x0`: built-in Rust publication to a 0x0-compatible upload endpoint plus
  exact payload verification at the returned download URL
- `catbox`: built-in Rust publication to the anonymous Catbox file-upload API
  plus exact payload verification at the returned download URL
- `litterbox`: built-in Rust publication to the anonymous Litterbox temporary
  file-upload API plus exact payload verification at the returned download URL
  with material-banded `time` defaults
- `tmpfiles`: built-in Rust publication to the /tmp/files API plus exact
  payload verification at the direct `/dl/...` URL discovered from the
  JSON-returned viewer page, with material-banded `expire` defaults in seconds
- `plugin-external`: deterministic plugin packet staging plus one explicit
  local executable that returns normalized placement/probe facts
