# CityB correspondence plane

CityB now has an explicit bidirectional correspondence plane for an operator
and individually enrolled field nodes. It is intentionally separate from the
governance and distribution planes:

```text
council Act + threshold signatures  ──► authority
signed archive + Merkle chain       ──► truth/adoption candidate
carriers and rendezvous             ──► discovery
operator/node correspondence        ──► notices, requests, status, results
```

A correspondence signature authenticates a correspondent. It does not make a
state transition valid. Only an `act-reference` message may name a council Act,
and it contains only the Act digest, constitution version, and serial. The node
must still obtain and verify the actual Act through the ordinary governance
gate. Other correspondence kinds are structurally forbidden from carrying an
authority reference.

## What is implemented

The canonical types live in `cityb-core`, so all three binaries use the same
wire contract without making Tiny depend on the operator crate:

- canonical CBOR plaintext envelope;
- stable content-derived message identity;
- thread identity, Lamport-style observed-thread sequence, parent/reply identity, created
  and expiry epochs, sender and recipient identity;
- bounded UTF-8 body and attachment-digest list;
- Ed25519 signature over the canonical plaintext;
- RFC 9180 base-mode HPKE using X25519/HKDF-SHA-256,
  HKDF-SHA-256, and ChaCha20-Poly1305;
- message and recipient-key identities authenticated as AEAD associated data;
- active, retired, and revoked key generations.

Base-mode HPKE supplies recipient confidentiality. Sender authenticity comes
from the signed inner message and the fleet registry, not from an HPKE claim.
This separation also makes rotation behavior clear: retired signing keys may
verify retained history, active keys create new work, and revoked keys are
refused during intake.

The Goldilocks surface is:

```sh
cityb correspondence init --root ROOT/city-b-correspondence
cityb correspondence enroll --root ROOT/city-b-correspondence \
  --node node-01 --node-dir /var/lib/cityb/node-01 --group west
cityb correspondence send --root ROOT/city-b-correspondence \
  --to node-01 --kind status-request --body 'report bounded status'
cityb correspondence task --root ROOT/city-b-correspondence \
  --to node-01 --operation inspect.archive-floor \
  --priority high --instruction 'inspect the retained archive floor and report'
cityb correspondence artifact request --root ROOT/city-b-correspondence \
  --to node-01 --label status/current
cityb correspondence send-group --root ROOT/city-b-correspondence \
  --group west --kind status-request --body 'report bounded status'
cityb correspondence check-in --root ROOT/city-b-correspondence --apply
cityb correspondence sync --root ROOT/city-b-correspondence
cityb correspondence fleet --root ROOT/city-b-correspondence
cityb correspondence inbox --root ROOT/city-b-correspondence --unread --mark-read
cityb correspondence read --root ROOT/city-b-correspondence --message MESSAGE_ID_OR_PREFIX --mark-read
cityb correspondence reply --root ROOT/city-b-correspondence --message MESSAGE_ID_OR_PREFIX \
  --kind notice --body 'operator response'
cityb correspondence thread --root ROOT/city-b-correspondence --thread THREAD_ID --mark-read
cityb correspondence threads --root ROOT/city-b-correspondence
cityb correspondence status --root ROOT/city-b-correspondence
cityb correspondence doctor --root ROOT/city-b-correspondence
cityb correspondence compact --root ROOT/city-b-correspondence
cityb correspondence incidents --root ROOT/city-b-correspondence
```

`init` writes a private operator keyring with mode `0600` and a public fleet registry. `enroll` writes one node provision containing that node's narrow private correspondence keyring, the operator's public generations, and a random per-node gateway bearer. Only the bearer digest enters the operator registry. The registry retains group membership, key history, enrollment time, last seen time, and revocation state. `send` writes an opaque per-node down-spool object; `sync` verifies and imports up-spool objects into the operator inbox and writes a content-bound delivery record for every reply. `inbox` is the compact triage view, `read` opens one unambiguously prefixed message and prints its runnable reply command, `reply` derives the node, thread, and exact parent from that verified inbox object, and `thread` joins the sent ledger and verified inbox into one ordered dialogue. Continuing a thread is node-bound and takes the next sequence after all locally observed sent and received records. This is a Lamport-style causal level, not a globally unique counter: disconnected peers can concurrently choose the same sequence, while the signed content-derived message ID remains unique and `in_reply_to` records causality. Thread output therefore orders by sequence before untrusted wall-clock time. Human text escapes terminal control characters; JSON preserves the authenticated body. No view interprets correspondence as governance authority. `send-group` is dry-run-first, preflights every selected active member and its bounded down spool, and then creates a separately signed and HPKE-encrypted envelope and thread for each node. It never publishes one reusable group ciphertext.

The ordinary human dialogue is intentionally short:

```sh
cityb correspondence sync --root ROOT/city-b-correspondence
cityb correspondence inbox --root ROOT/city-b-correspondence --unread
cityb correspondence read --root ROOT/city-b-correspondence --message 7f91a2bc --mark-read
cityb correspondence reply --root ROOT/city-b-correspondence \
  --message 7f91a2bc --kind notice --body 'retry the archive floor and report'
cityb correspondence thread --root ROOT/city-b-correspondence --thread THREAD_ID
```

Message IDs accept only an unambiguous 8-to-64-character hexadecimal prefix. The reply path does not ask the human to copy a node ID, thread ID, parent ID, or sequence number; those facts come from the verified message. An expired parent cannot receive a new reply; use `send --to NODE` for a fresh conversation. Use `send-group` for isolated per-node fan-out.

Typed task coordination is an intentionally narrow layer over the same envelope. `cityb correspondence task` constructs `cityb.task.v1` with a content-derived task identity, operation label, `routine|high|urgent` priority, optional requested-completion epoch, and bounded human instruction. Tiny retains and acknowledges the request but never executes the instruction merely because it is authenticated. A local human or separately authorized node program returns `cityb-node correspondence result --message ... --disposition completed|refused|failed|deferred --summary ...`; that result binds the original task identity and may name only separately transported artifact digests. Human inbox/thread views decode these bodies into useful summaries instead of displaying their canonical CBOR encoding. Free-form `notice`, `fault`, and legacy `result` messages remain available when a typed task is unnecessary.

`check-in` turns fleet freshness into a transaction. It selects active nodes that have never replied or have exceeded the configured freshness interval, optionally narrows by group, and previews by default. `--apply` writes one individually signed and HPKE-encrypted status request per selected node. A still-live pending request suppresses duplicates. `doctor` validates registry and private-key agreement, every provision, gateway bearer digests, content-addressed filenames, decryptability and signatures of pending spools, sent and inbox ledgers, and relay receipts. `cityb next` treats an audit failure as higher priority than ordinary inbox or freshness work.

Root mutations use a short-lived, crash-recoverable single-writer lock plus atomic file replacement and parent-directory synchronization. The gateway takes the same lock around authenticated list/fetch/upload operations, so a rotation cannot race an upload and two senders cannot silently reuse a thread sequence. A dead process's lock is recovered; a live writer is refused rather than guessed around. Durable correspondence CBOR reads and gateway request/response bodies have explicit byte ceilings, directory scans refuse symlinks and non-regular objects, and HTTP framing refuses transfer encoding or ambiguous content lengths.

Provision replacement and revocation are explicit. Direct local rotation is
refused because it would make the operator believe a disconnected field node
had changed when it had not. The replacement protocol is:

```sh
cityb correspondence provision stage --root ROOT/city-b-correspondence \
  --kind replacement-identity --node node-01 --apply

# On the field node, using the still-current provision and transferred candidate:
cityb-node correspondence provision stage \
  --provision CURRENT.cbor --candidate candidate-node-01.cbor \
  --state-dir NODE_STATE --ack-out acknowledgement.cbor

# Back at the operator, import the old-node-key acknowledgement and issue commit:
cityb correspondence provision accept --root ROOT/city-b-correspondence \
  --cutover TRANSACTION_ID --ack acknowledgement.cbor --apply
cityb correspondence provision commit --root ROOT/city-b-correspondence \
  --cutover TRANSACTION_ID --apply

# Field activation is atomic and proves possession of the replacement key:
cityb-node correspondence provision apply \
  --provision CURRENT.cbor --candidate candidate-node-01.cbor \
  --commit commit-node-01.cbor --state-dir NODE_STATE \
  --activation-out activation.cbor
cityb correspondence provision finalize --root ROOT/city-b-correspondence \
  --cutover TRANSACTION_ID --activation activation.cbor --apply

cityb correspondence keys revoke-operator-key --root ROOT/city-b-correspondence --generation 1
cityb correspondence keys revoke-node-key --root ROOT/city-b-correspondence --node node-01 --generation 1
cityb correspondence keys revoke-node --root ROOT/city-b-correspondence --node node-01
```

`operator-rotation` stages one candidate for every active node;
`node-rotation` retains the prior private generation for already-encrypted
mail; `replacement-identity` revokes every old public generation, carries only
the new private generation, and rotates the gateway bearer. Staging changes no
live authority. Commit is impossible until every target returns an
acknowledgement signed by its current key. Finalization is impossible until
every activated target returns a receipt signed by its replacement key. Only
then does Goldilocks install the target registry, operator keyring, and local
provision copy. A journal makes an interrupted local finalization recoverable
with `provision recover`; all ordinary registry operations refuse to guess
through that state. `cityb next` surfaces every open cutover phase.

Candidate and commit files still need a trusted transfer route. The protocol
authenticates exactly what arrived and who activated it; it does not claim an
untrusted courier is private. After replacement finalization, the old bearer
fails gateway authentication and the old signing generation is `revoked`, so
its messages cannot re-enter `sync`. Physically compromised bytes cannot be
unlearned; replacement changes future admission.

Sent, inbox, delivery, expired, relay, and Tiny seen/inbox evidence are
bounded. Goldilocks `compact` and Tiny `correspondence compact` preview by
default. Pending down objects, unread operator inbox messages, and live
unacknowledged sent messages are protected; only eligible history is selected
by age and cap. Tiny never evicts an unexpired seen-message marker merely to
meet a smaller requested cap: it reports the cap unsatisfied, and its fixed
ledger ceiling refuses new work rather than reopening replay. Seen-ledger
reads are byte- and record-bounded. Relay receipt persistence also has a hard
automatic ceiling.

## Tiny and status capsules

Tiny remains unable to author governance, plan publication, or post to public
carriers. It now has a narrower, accurately named ability: it can hold a
correspondence identity, decrypt an operator request, verify the operator
registry key, and return an encrypted signed acknowledgement, fault, or status
capsule.

```sh
cityb-node correspondence process \
  --provision /var/lib/cityb/node-01/correspondence-provision.cbor \
  --down /mnt/spool/down/node-01 \
  --up /mnt/spool/up/node-01 \
  --state-dir /var/lib/cityb/node-01 \
  --status 'epoch=21 phase=active storage=healthy'

cityb-node correspondence send \
  --provision /var/lib/cityb/node-01/correspondence-provision.cbor \
  --up /mnt/spool/up/node-01 --state-dir /var/lib/cityb/node-01 \
  --kind fault --body 'archive floor unavailable'

cityb-node correspondence inbox \
  --provision /var/lib/cityb/node-01/correspondence-provision.cbor \
  --state-dir /var/lib/cityb/node-01

cityb-node correspondence reply \
  --provision /var/lib/cityb/node-01/correspondence-provision.cbor \
  --up /mnt/spool/up/node-01 --state-dir /var/lib/cityb/node-01 \
  --message MESSAGE_ID_OR_PREFIX --kind result \
  --body 'archive floor verified'

cityb-node correspondence result \
  --provision /var/lib/cityb/node-01/correspondence-provision.cbor \
  --up /mnt/spool/up/node-01 --state-dir /var/lib/cityb/node-01 \
  --message TASK_MESSAGE_ID_OR_PREFIX --disposition completed \
  --summary 'archive floor verified' --artifact-sha3 SHA3_HEX

cityb-node correspondence artifacts create \
  --provision /var/lib/cityb/node-01/correspondence-provision.cbor \
  --out /var/lib/cityb/node-01/public-artifacts.cbor \
  --entry status/current=/var/lib/cityb/node-01/public-status.json --apply

cityb-node correspondence schedule \
  --provision /var/lib/cityb/node-01/correspondence-provision.cbor \
  --up /var/lib/cityb/node-01/up --state-dir /var/lib/cityb/node-01 \
  --kind status --body 'scheduled field capsule' \
  --interval-secs 21600 --jitter-secs 1800 \
  --max-requests-per-day 8 --max-bytes-per-day 1048576 \
  --max-storage-bytes 67108864 \
  --battery-capacity-file /sys/class/power_supply/BAT0/capacity \
  --min-battery-percent 20

cityb-node correspondence compact --state-dir /var/lib/cityb/node-01
```

Processing is bounded by the provision's outbox limit. A message is accepted
only after recipient-key selection, HPKE open, canonical decode, registry-bound
signature verification, sender/recipient match, validity-window check, and
seen-message check. A future message is deferred. An expired but otherwise
valid message is recorded without executing its request and produces a signed
terminal fault, allowing the operator spool to drain it instead of retrying it
forever. The seen ledger advances only after the inbox object and reply are
durable. A status request returns `cityb.status-capsule.v1` with only
node identity, observation epoch, seen/inbox/outbox counts, and the configured
single-line label; it does not expose process arguments, environment, paths,
network addresses, or arbitrary files. Public artifact disclosure is digest-only and explicit: `cityb-node correspondence artifacts create --provision FILE --out public-artifacts.cbor --entry LABEL=PATH --apply` hashes locally selected regular files up to 64 MiB and writes a manifest containing labels, byte lengths, and SHA3-256 digests but no paths or contents. Passing that manifest to `process` or `exchange` with `--public-artifacts FILE` lets a typed artifact request return only the allowlisted label, digest, size, and observation epoch. Missing manifests, malformed requests, unknown labels, and node-identity mismatches produce named faults. The request never selects a path and processing never reopens the source file. Act references are merely
acknowledged with a reminder that council verification remains independent.
Tiny may also originate bounded `notice`, `status`, `fault`, and `capability` envelopes. `inbox` verifies every retained operator message before showing it, and `reply` derives the authenticated parent and thread from an unambiguous message prefix. Automatic acknowledgements and explicit human/node replies share a durable per-thread sequence reservation, so both may exist without identity reuse. Tiny cannot originate `act-reference`, action requests, or public carrier mutations. Its monotone new-thread sequence is reserved durably before the message is written, so a crash may create a harmless gap but cannot reuse an identity.

`schedule` emits a typed `cityb.scheduled-capsule.v1` status or fault body on
a deterministic positive-jitter cadence. Its durable daily ledger reserves a
request and conservative byte allowance before queueing, so a crash can waste
budget but cannot silently double-spend it. Emission is refused when the daily
request ceiling, byte ceiling, retained-storage ceiling, or battery floor is
reached. Battery can come from a literal value for mains-powered fixtures or a
bounded capacity file. The NixOS automation object has an opt-in
`correspondenceNodeCapsule` timer; enabling it requires exactly one battery
source and does not grant governance or carrier-posting authority.

## Local proof and operator-owned HTTP

The complete no-network proof creates two separately keyed nodes, sends one
status request to each, processes both spools, verifies both replies, and
retains a report:

```sh
cityb correspondence local-proof --root /tmp/cityb-correspondence-proof --json
```

The Goldilocks gateway exposes only opaque spool objects:

```sh
cityb correspondence gateway serve \
  --root ROOT/city-b-correspondence \
  --bind 127.0.0.1:8787

cityb-node correspondence exchange \
  --provision /var/lib/cityb/node-01/correspondence-provision.cbor \
  --gateway 127.0.0.1:8787 \
  --state-dir /var/lib/cityb/node-01
```

The API is deliberately small: list and fetch one node's down-spool, then PUT
one content-addressed up-spool envelope. Bodies are bounded to 1 MiB. Each
node's pending up-spool is additionally capped at 1,024 objects and 256 MiB,
so possession of one node bearer does not grant unbounded gateway storage. The
default bind is loopback. Every list, fetch, and upload request must present
the random per-node bearer from the enrolled provision; a revoked node is
rejected before any spool object is revealed. Successful node uploads are
drained locally, and a verified reply drains its acknowledged operator
down-envelope. Node-key rotation also rotates the gateway bearer.

The gateway enforces independent authenticated per-node request and aggregate
request/response-byte windows. Defaults are 120 requests and 64 MiB per
minute; excess is HTTP 429 without consuming another node's budget. These are
abuse bounds, not an Internet denial-of-service shield.

A non-loopback bind requires `--allow-nonloopback`. That flag does not add TLS,
or firewall policy; the bearer is request authentication, not transport
confidentiality. Put the gateway behind an operator-owned TLS reverse proxy or
private overlay for deployment. The NixOS module exposes opt-in
`services.cityb.correspondenceGateway` and nested `tls` settings. TLS keeps the
built-in service on `127.0.0.1`, enables nginx with recommended TLS/proxy
settings, caps request bodies at 1 MiB, and leaves the firewall closed unless
`openFirewall = true` is explicit. The complete deployment-shaped fixture is
[`nix/examples/correspondence-gateway-tls.nix`](../nix/examples/correspondence-gateway-tls.nix).
Supply certificate material with the host's secret manager; do not put private
keys in the Nix store. Initialize and enroll the correspondence root before
enabling either service.

### Signed external operator office

The same gateway can optionally expose `/v1/operator` to a real ChatGPT or
other external operator office:

```sh
cityb correspondence gateway serve \
  --root ROOT/city-b-correspondence \
  --bind 127.0.0.1:8787 \
  --allow-remote-operator \
  --remote-operator-policy correspond \
  --operator-requests-per-minute 60 \
  --operator-bytes-per-minute 4194304

cityb correspondence remote call \
  --root CHATGPT-OFFICE \
  --endpoint https://cityb.example/v1/operator \
  --apply -- send --to node-01 --kind notice --body 'report current state'
```

This route is disabled by default and has independent request and byte
budgets. The client signs a canonical, content-addressed request with its
active operator key; the request has a random nonce and a lifetime of at most
five minutes. The gateway checks that key against the active operator
registry, reserves the request under the normal single-writer discipline, and
retains the signed result. An exact retry returns the same result; a conflict
or incomplete replay refuses. The client verifies the returned operator
signature.

The policy is a fixed CityB vocabulary, not a shell. `read` permits status,
doctor, fleet, inbox, threads, incidents, relay status/SLO, and provision
status. `correspond` adds send, reply, task, artifact request, group fan-out,
check-in, and sync. `operate` additionally permits bounded compaction. A
remote request cannot supply `--root` or `--json`. Mutating client calls
require `--apply`. The authoritative root remains on the gateway host. This is
genuine correspondence-operator authority when a deployment grants it; it is
still not council or release authority.

Plain remote HTTP is refused by the client. Keep the built-in listener on
loopback and terminate TLS at the reviewed reverse proxy described above.

## Live event-relay bridges

Goldilocks can move an already signed and HPKE-encrypted envelope through
three bounded live relay families:

- `nostr-nip01`;
- `mqtt-retained`;
- `ntfy-cached`.

The ordinary operator-root form reads or writes the enrolled node's existing
spool. `send` is non-mutating until `--apply` is explicit:

```sh
printf '%s\n' 'unguessable-route-capability' > /run/keys/cityb-route
chmod 600 /run/keys/cityb-route

cityb correspondence relay send \
  --root ROOT/city-b-correspondence \
  --adapter ntfy-cached --endpoint https://ntfy.sh \
  --route-file /run/keys/cityb-route \
  --direction down --node node-01 --message MESSAGE_ID
# inspect the preview, then repeat it with --apply

cityb correspondence relay receive \
  --root ROOT/city-b-correspondence \
  --adapter nostr-nip01 --endpoint wss://relay.example \
  --route-file /run/keys/cityb-route \
  --direction up --node node-01 --max-frames 32
```

The field-side form is a correspondence-credentialless bridge sidecar. It
receives directly into Tiny's explicit down spool and sends directly from
Tiny's explicit up spool. It needs neither the operator registry nor operator
private keys; a selected carrier may still require its own narrow credential:

```sh
cityb correspondence relay receive \
  --spool /var/lib/cityb/node-01/down \
  --bridge-state /var/lib/cityb/node-01/relay-bridge \
  --adapter mqtt-retained --endpoint mqtts://broker.example:8883 \
  --route-file /run/keys/cityb-node-01-down \
  --direction down --node node-01

cityb-node correspondence process \
  --provision /var/lib/cityb/node-01/correspondence-provision.cbor \
  --down /var/lib/cityb/node-01/down --up /var/lib/cityb/node-01/up \
  --state-dir /var/lib/cityb/node-01

cityb correspondence relay send \
  --spool /var/lib/cityb/node-01/up \
  --bridge-state /var/lib/cityb/node-01/relay-bridge \
  --adapter mqtt-retained --endpoint mqtts://broker.example:8883 \
  --route-file /run/keys/cityb-node-01-up \
  --direction up --node node-01 --message REPLY_MESSAGE_ID --apply
```

This preserves the three-binary split: Tiny owns correspondence verification
and private node identity; the Goldilocks binary is the network sidecar. A
field host that cannot afford Goldilocks should use the existing authenticated
HTTP exchange or an operator-supplied minimal forwarder. CityB does not hide a
large WebSocket/TLS/MQTT stack inside `cityb-node`.

`--route-file` is preferred because a literal `--route` can appear in process
listings and shell history. MQTT credentials similarly use `--password-file`.
Send previews validate the adapter-specific endpoint, route, payload ceiling,
and complete credential combination before reporting a runnable `--apply`
step; credential flags on ntfy or Nostr are refused instead of ignored.
Authenticated remote MQTT is accepted only over `mqtts://`; CityB refuses to
send a username or password over plain remote TCP. `mqtt://` and legacy bare
`HOST[:PORT]` endpoints mean plaintext MQTT and are appropriate only for an
anonymous public broker or a separately protected/local channel.
Receipts contain only a route SHA3-256 digest and a sanitized endpoint; they do
not retain the route, credentials, plaintext, or inherited environment. Each
receive validates canonical encoding plus adapter, direction, node, and
message identity before a no-clobber spool import. Tiny or Goldilocks still
performs HPKE open, inner signature, expiry, replay, sender, and authority
checks later. A relay event is never an authority decision.

This is message confidentiality and authenticity, not traffic invisibility.
The relay and network path can still observe the client address, timing, size,
route/topic, and opaque frame metadata such as node and recipient-key
identifiers. The live encodings deliberately omit a product title, public
hashtag, and descriptive carrier prefix, but that minimization is not a claim
of cover traffic, anonymity, or steganography. Use distinct random route
capabilities, independent network paths where needed, and the operator-owned
HTTP transport when public relay metadata is unacceptable.

When a relay exposes cache expiration (ntfy does), the receipt retains that
epoch and Biggun derives the minimum observed remaining TTL. MQTT 3.1.1 and
ordinary NIP-01 events expose no equivalent expiry claim, so their report stays
`unknown` instead of inventing one.

The three adapters deliberately expose different physics:

- `mqtt-retained` is one last-value register per exact topic. A later publish
  overwrites the prior value. Receive refuses a live non-retained delivery;
  `clear --apply` sends the protocol's zero-byte retained value. A QoS 0 write
  is not proof that a later subscriber received the object. `mqtts://` uses
  the pinned system-independent WebPKI root set and verifies the broker name.
- `ntfy-cached` publishes an opaque textual encoding and polls bounded cached
  JSONL. Cache expiry and provider retention remain external facts; an HTTP
  acknowledgement is not durable delivery.
- `nostr-nip01` uses the NIP-01 relay flow to publish a signed NIP-78
  kind-30078 addressable event under an ephemeral outer key, then queries the
  opaque `d` tag. CityB verifies the outer event ID and Schnorr signature,
  then verifies the inner CityB object separately. This is not a claim of
  NIP-17/NIP-59 interoperability or relay retention.

Enforced canonical-frame ceilings are 1,800 bytes for ntfy, 48 KiB for Nostr,
and 128 KiB for MQTT. Larger correspondence must use the authenticated HTTP
spool or name a separately verified artifact; it is not silently fragmented.
Receive uses three bounded attempts with a 350 ms linear backoff by default;
`--attempts` is capped at five and `--backoff-ms` at 5,000. The receipt records
the attempts consumed, which makes eventual cache visibility distinguishable
from an immediate read without creating an unbounded watcher.
The older `correspondence transport export|import` commands remain useful as
offline codec/staging tools and make no network mutation.

Disconnected movement now has a higher-level bounded courier transaction:

```sh
cityb correspondence courier export --root ROOT/city-b-correspondence \
  --node node-01 --direction down --out down-courier.cbor \
  --qr-dir down-courier-qr
# Dry-run first; repeat with --apply after reviewing message, byte, and chunk counts.
cityb correspondence courier inspect --in down-courier.cbor
cityb-node correspondence courier import --provision NODE_PROVISION \
  --state-dir NODE_STATE --qr-dir down-courier-qr --apply
cityb-node correspondence process --provision NODE_PROVISION \
  --down NODE_STATE/correspondence-transport/down \
  --up NODE_STATE/correspondence-transport/up --state-dir NODE_STATE
cityb-node correspondence courier export --provision NODE_PROVISION \
  --state-dir NODE_STATE --out up-courier.cbor --qr-dir up-courier-qr --apply
cityb correspondence courier import --root ROOT/city-b-correspondence \
  --qr-dir up-courier-qr --apply
cityb correspondence sync --root ROOT/city-b-correspondence
```

One courier file carries at most 128 opaque signed-and-encrypted envelopes and 8 MiB. Its content-derived bundle identity binds creation epoch, direction, node, message identity, and every ciphertext. Goldilocks import checks fleet enrollment; Tiny import requires the active provision and accepts only `down` envelopes for that exact node. Tiny export likewise emits only its own `up` spool. Every mutation previews by default and uses no-clobber spool placement only with `--apply`; normal process/sync intake still performs signature, recipient, expiry, replay, and authority checks. `--qr-dir` writes at most 4,096 numbered `cityb-courier-v1` text chunks of 128–1,200 raw bytes each with the bundle identity and exact ordering. Both binaries' `inspect` and `import` accept either the binary `--in` file or a scanned `--qr-dir`; a shared core decoder refuses missing, repeated, mixed-identity, oversized, or invalid-index chunk sets before validating the bundle. Those files are inputs to any ordinary QR encoder/scanner; CityB does not claim to render images or correct optical errors. The binary bundle remains the authoritative object, while the text chunks are a physical-transfer encoding.

Continuous relay evidence uses a reviewed JSON route plan and refuses any
field node/direction that has fewer than two protocol families:

```sh
cityb correspondence relay soak \
  --root ROOT/city-b-correspondence \
  --plan /etc/cityb/correspondence-relay-soak.json
# Dry-run validates enrollment, routes, credentials, and family coverage.
# Repeat with --apply only after review.
```

The opt-in NixOS `correspondenceRelaySoak` timer runs the same bounded command
with persistent scheduling and randomized delay. Every run retains an epoch-
named report plus the ordinary privacy-minimized send/receive receipts; those
reports are what allow later UTC dates to become evidence. The example plan is
[`nix/examples/correspondence-relay-soak.json`](../nix/examples/correspondence-relay-soak.json).
It contains placeholders, not public infrastructure or credentials. A route
meets the structural gate only when it uses two distinct protocol families;
operators should additionally choose different operators/network roots where
possible. An applied route is green only when a spool object is sent and the
same encrypted envelope is observed on the immediate bounded receive; an
empty spool is an explicit unexercised failure, not relay-health evidence.
Queue bounded down work and let scheduled node capsules supply up work before
the respective soak. One process run cannot prove date separation. Promotion or a
retention claim must wait for reports from genuinely later dates.

The same plan is usable as an ordinary operator exchange rather than a health
experiment:

```sh
cityb correspondence relay exchange \
  --root ROOT/city-b-correspondence \
  --plan /etc/cityb/correspondence-relay.json
# Review the dry run, then repeat with --apply.
```

For every down route, exchange sends at most the requested bounded set of
pending envelopes. For every up route, it performs the normal bounded receive,
then runs `sync` so the operator inbox contains only verified inner messages.
The plan requires at least two protocol families for every represented
node/direction. Sending the same encrypted envelope through both families is
intentional redundancy; content identity and the seen ledger make it safe.

An authoritative office can make a public handoff for a disposable or
constitutional ChatGPT office:

```sh
cityb correspondence office-kit export \
  --root ROOT/city-b-correspondence \
  --relay-plan /etc/cityb/correspondence-relay.json \
  --out public-office-kit.cbor --apply
cityb correspondence office-kit inspect --in public-office-kit.cbor
```

The signed kit contains public operator and node key histories, groups,
last-seen facts, bearer *digests*, and optionally the credential-free relay
plan. It contains no private operator or node key, raw gateway bearer,
correspondence body, route capability, password, or service credential. Import
requires an initialized empty office whose active private operator key exactly
matches the kit signer. Imported nodes are `remote-only`; local provision
cutover is refused because their private custody remains elsewhere. This is a
public fleet snapshot, not a backup of the authoritative mutable root.

Protocol behavior follows the upstream contracts rather than invented relay
semantics: [ntfy publish](https://docs.ntfy.sh/publish/) and
[subscribe/poll](https://docs.ntfy.sh/subscribe/api/),
[Nostr NIP-01](https://github.com/nostr-protocol/nips/blob/master/01.md) plus
[NIP-78 application data](https://github.com/nostr-protocol/nips/blob/master/78.md), and
[MQTT 3.1.1](https://docs.oasis-open.org/mqtt/mqtt/v3.1.1/cos01/mqtt-v3.1.1-cos01.html).

The checked-in
[`fixtures/cityb/correspondence-relay/`](../fixtures/cityb/correspondence-relay/README.md)
corpus is the deployment-evidence seam. On October 26 a fresh two-node office
created real Ed25519-signed, HPKE-encrypted work, then round-tripped the same
opaque down-envelope through ntfy cached HTTP and the independently operated
nos.lol Nostr relay. Both families returned the exact canonical message on the
first bounded receive; correspondence doctor remained clean and Biggun passed
all deterministic relay hazards against the four retained CBOR receipts. The
fixture contains sanitized endpoints, route hashes, opaque message identity,
size, timing, and results—never route capabilities, private keys, bearers,
credentials, or plaintext bodies. One date proves wiring, not durability:
Biggun deliberately recommends later-UTC-date repetitions for both families.

The operator can turn retained receipts into explicit, bounded route objectives without pretending the carrier made a service-level promise:

```sh
cityb correspondence relay slo --root ROOT/city-b-correspondence \
  --window-secs 2592000 --min-samples 3 \
  --target-success-percent 95 --max-p95-ms 10000
```

Rows are keyed by adapter, operation, direction, and privacy-preserving route digest. Each reports sample/success/failure counts, success percentage, p50/p95 latency, newest evidence age, and `met|missed|insufficient-evidence|stale`. The default window is 30 days, minimum is three observations, target is 95 percent, p95 ceiling is 10 seconds, and evidence older than seven days is stale. These are local objectives computed from retained observations, not claims of future provider availability. A missing family or direction still belongs in the Biggun relay study rather than being fabricated into a route row.

## Cockpit and Biggun

`cityb next` reads `ROOT/city-b-correspondence` and reports:

- the persisted policy mode and state: `disabled-by-policy`, optional
  `not-configured`, `required-and-missing`, configured, or `policy-conflict`;
- whether configured correspondence is ready, stale, has unread inbox
  attention, has a failed latest relay operation, has an open provision
  cutover, or fails durable-state integrity;
- total and active fleet nodes;
- never-seen and thirty-day-stale nodes;
- pending unsynchronized up-spool objects, unread operator inbox, queued down-spool, and retained delivery-acknowledgement counts;
- the exact correspondence command to run. Stale fleets route to the dry-run-first deduplicated `check-in`; integrity faults route to `doctor`.

`cityb correspondence incidents --root ROOT/city-b-correspondence` is the bounded notification sink for an external pager, terminal widget, or operator loop. It emits at most 20 items by default and at most 100 by explicit request, prioritizing unread authenticated node faults, urgent typed tasks, never-seen/stale nodes, and the newest failed relay operation per adapter/operation/direction. Each item contains only severity, kind, node, optional message identity, epoch, safe summary, and a complete local command. Message bodies, route capabilities, credentials, and correspondence plaintext are deliberately absent. JSON supplies `primary_action`, total/returned/truncated counts, and the same body-exclusion claim; CityB does not choose or contact an external notification provider.

Set policy with `cityb correspondence policy --root
ROOT/city-b-correspondence --mode disabled|optional|required [--apply]`. The
command is dry-run by default and writes only `policy.json`. Optional and absent
is non-blocking; disabled and absent is explicitly intentional; required and
absent blocks readiness; disabled with existing correspondence state is a
policy conflict requiring review. When correspondence is configured, integrity
and open-cutover failures come first, pending return mail produces
`sync-required`, unread inbox work produces `inbox-attention`, and stale or
never-seen fleet members produce `fleet-stale`. Provider evidence and archive
admission faults retain higher priority; correspondence is then the ordered
next action rather than a competing dashboard hint.

Biggun's local attack campaign is:

```sh
cityb-biggun correspondence-chaos --require --json
```

It proves twenty-two named behaviors for duplicates, delay, replay, expiration,
unregistered forgery, compromise of a genuinely registered signing key before
and after revocation, stale provisions, loss of two staged routes, operator key
rotation/revocation policy, bounded outbox exhaustion, six months of
disconnection, authority-field smuggling, forged provision acknowledgement,
replacement-key activation, revoked-generation re-entry, and the required
archive-before-provision order after long amnesia. Seven additional cases prove typed task/result binding, malformed typed-task refusal, a 256-reply concurrent thread storm with equal causal sequence values and stale clocks, digest-only public-artifact vocabulary, offline courier tamper refusal, remote-operator command/result binding, and public office-kit tamper refusal. The compromised-key case is
deliberately honest: a valid stolen key is accepted before revocation; only
distributed revocation changes later intake. This is deterministic local
evidence, not a claim about Internet relay availability.

Relay transport study is separate and consumes the exact privacy-minimized
receipts written by live bridges:

```sh
cityb correspondence relay status \
  --root ROOT/city-b-correspondence --json
cityb-biggun correspondence-relay-study \
  --evidence-root ROOT/city-b-correspondence/relay-evidence \
  --require-evidence --require --json
```

Repeat `--evidence-root` to merge operator and field-side receipt directories;
the combined read is capped at 4,096 receipts and refuses symlinks or oversized
objects.

Its deterministic cases cover canonical agreement, MQTT overwrite, ntfy
expiry windows, Nostr duplicates, cross-relay route loss, route-identity
refusal, payload ceilings, and malformed carrier objects. Live receipts add
per-adapter sends, receives, failures, latency, byte counts, imported objects,
duplicates, refusals, endpoints, and distinct route digests. Biggun recommends
the missing direction/family or a date-separated repeat. `--require-evidence`
requires every observed adapter to have both a send and an actual imported or
duplicate delivery; `--require` also refuses retained failures/refusals. It
never reads route
capabilities or correspondence plaintext.

An October 23 live local proof enrolled two nodes, queued encrypted status
requests, and completed immediate send/receive round trips through both an ntfy
route and a Nostr relay. A two-message repeat found a real adapter defect:
ntfy's cached feed is oldest-first, while the bounded reader had retained the
first entries and could hide newly published frames on a busy route. The
reader now keeps the newest bounded window, and the soak unions up to three
bounded receive rounds and requires every successfully sent envelope—not one
arbitrarily ordered item—to reappear. The exact two-message repeat then passed
both families with two of two envelopes verified per route. Sixteen cumulative
privacy-minimized receipts fed Biggun; all eight deterministic relay-semantics
cases and the live-evidence gate passed. This is a second dated family proof
after October 20, but it remains one host and one egress. It does not satisfy
multi-vantage or per-field-route deployment proof; the installed relay-soak
object and named-vantage evidence discipline are what turn later
operator-owned runs into that evidence.

## Completed tranche and remaining evidence

The eight-part operational tranche is implemented:

1. staged candidates, old-node acknowledgements, operator commits, new-key activation receipts, transactional finalization, and recovery;
2. typed delivery records plus bounded Goldilocks and Tiny compaction;
3. a continuously schedulable multi-family relay soak with retained reports;
4. deterministic-jitter status/fault capsules with request, byte, battery, and storage budgets;
5. dry-run-first per-recipient group fan-out;
6. a TLS reverse-proxy fixture and authenticated per-node gateway limits;
7. replacement-identity cutover that revokes every prior generation and rotates the bearer;
8. optional correspondence activation in `cityb recover`, strictly after durable-anchor, signed-chain, shard reconstruction, and release-admission steps.

The October 21 coordination tranche is also implemented: typed advisory tasks and parent-bound results; explicit digest-only public artifact manifests; bounded route objectives derived from retained relay receipts; capped body-free incident output; provision-bound dry-run-first offline courier exchange on both Goldilocks and Tiny with a shared QR-text codec; and Biggun concurrency, typed-body, artifact, and courier adversarial cases. These extend delivery reasoning without adding a remote shell or changing the authority split. `cityb next` leads with the bounded incident command for unread authenticated faults/urgent tasks or the latest failed relay operation.

The remaining work is empirical and deployment-owned, not a hidden ninth
protocol. Keep the relay-soak timer running across genuinely later dates;
exercise two families in both directions for every deployed field route;
retain expiry, route-loss, TLS, and rate-limit observations; and run
`cityb-biggun correspondence-relay-study` plus `correspondence-chaos` over the
result. A production operator must also supply their own certificates, route
capabilities, power-source path or fixed mains value, and trusted candidate /
commit transfer route. CityB refuses to fabricate those facts.

## Worthwhile next research

The remaining correspondence work is mostly empirical. Run multi-family relay soaks on genuinely later dates, establish deployment-specific objective thresholds, exercise courier files through real removable-media and camera paths, and decide whether a later release should include a pinned QR image codec or continue treating numbered text as the portable seam. Task operation names are intentionally operator-defined today; a future vocabulary should be standardized only after real deployments show repeated operations worth making interoperable. Incident output is local structured data rather than a notification transport; an opt-in Nix timer or external pager adapter should be added only for a selected deployment destination, with credentials outside CityB state. Biggun can still deepen the months-long model by composing relay receipts, compaction, actual provision cutover artifacts, and courier duplication across multiple node identities rather than testing each mechanism in isolation.

CityB should resist three tempting expansions: no general remote shell (the
signed remote office is a fixed CityB command vocabulary), no reply that
changes governance state, and no reusable group encryption key. Conversation
is advice, observation, and task/result coordination; archive admission and
council Acts remain the only routes to durable authority.
