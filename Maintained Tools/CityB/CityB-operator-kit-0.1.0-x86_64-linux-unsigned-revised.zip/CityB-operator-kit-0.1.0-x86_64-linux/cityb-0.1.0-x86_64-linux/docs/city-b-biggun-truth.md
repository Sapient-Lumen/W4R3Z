# CityB Biggun truth cockpit

Biggun is CityB's development truth surface. `cityb` is the operator workbench, `cityb-node` is the receive-only field binary, and `cityb-biggun` owns the expensive local evidence that tells maintainers whether the other two surfaces still agree with the claims in the docs. Parser-diff keeps all imported fixture provenance but bounds execution by semantic class: one newest routine provider/encoding body plus every explicitly named drift, malformed, rendered, redirect, noisy, screenshot, or OCR class. Its seen/selected/deduplicated counters make that reduction auditable instead of silently sampling evidence.

Thresholds have two explicit scopes. `--required-shards` controls Biggun's
hypothetical latest-provider loss model. When a retained archive root exists,
`retained_risk` and `topology_concentration.retained_plan_threshold` instead
read the threshold sealed into that generation, and all current-generation
recommendations use it. A 32-shard simulation may therefore coexist with the
actual 30-of-60 retained generation without changing its requirements.

The normal maintainer starting point is:

```sh
cityb-biggun guide
cityb-biggun truth --plan --json
cityb-biggun truth --run --quick --json
cityb-biggun truth --run --quick --root /path/to/retained-root --json
cityb-biggun living --max-report-age-hours 24 --require-ready --json
cityb-biggun promotion-tranche --archive-evidence-root ./city-b-artifacts --require --json
# Explicit network read when present-day DNS/IP/ASN/CDN diversity matters:
cityb-biggun promotion-tranche --archive-evidence-root ./city-b-artifacts --live-topology --require --json
```

The native Nix app exposes the same surface:

```sh
nix run .#cityb-biggun -- guide
nix run .#cityb-biggun -- truth --plan --json
nix run .#cityb-biggun -- truth --run --quick --json
nix run .#cityb-biggun -- living --max-report-age-hours 24 --json
```

`guide` prints the amnesia-safe maintainer sequence for future agents and performs no reads or writes. The longer [maintainer playbook](city-b-maintainer-playbook.md) explains cost tiers, provider-evidence discipline, change-type checks, and handoff expectations. `living --json` reads retained provider-monitor state and repo fixtures, then reports whether the monitor loop has a latest run, whether evidence is waiting to import, how many capture/firehose/candidate-probe steps it ran, the latest report mtime/age, and the exact maintainer command to run next. It resolves the sibling Goldilocks binary by default; `--cityb PATH` makes that identity explicit. Before it permits import, curation, or provider-policy advice, it verifies that the scheduled service and latest report match the selected executable build. A service-generation mismatch precedes replay, and replay precedes evidence mutation, so an older timer cannot overwrite newly interpreted evidence. A completed modern monitor report is gated by the typed infrastructure and stable-lane outcomes; capacity, listing, and candidate findings remain visible but do not turn its aggregate `success` false. Older retained reports may still have a false aggregate because those experiments once leaked into the gate, so `living` prefers typed lane outcomes and falls back to the aggregate only for legacy reports without them. `living` does not call a copied evidence corpus healthy merely because the import inbox is empty: it also checks the evidence high-water mark, inbox-versus-sealed generation, source-control handoff, and—after those prerequisites pass—the current retained root's provider-role policy. Supply `--root DIR` to enable that retained-policy check. `--max-report-age-hours HOURS` turns age into an explicit `stale` status; `--require-latest` gates missing, failed, or stale required lanes, while `--require-ready` gates the complete service/report/evidence/handoff/policy definition. It performs no network request and does not import evidence. `truth --plan` prints the commands Biggun would run, performs no local mutation, and reports `next_command` plus `next_reason`. `truth --run --quick` runs the fast local evidence stack: capability identity, binary matrix, monitor-state inspection, mutation corpus, archive-erasure matrix, deterministic correspondence-relay semantics, and provider-reality replay over checked-in evidence. Passing `--root DIR` makes its living step a strict production gate by forwarding both the root and `--require-ready`; the scheduled NixOS truth service always does this, so an operationally unready JSON report cannot leave a green timer merely because its command executed. For generation compatibility with an already-loaded service during a payload-only upgrade, the exact canonical `ROOT/city-b-biggun-truth` work directory also derives `ROOT` and enables the same strict gate; arbitrary work-directory names do not acquire authority or change readiness semantics. It reports `failed_steps`, `first_failed_step`, `next_command`, and `next_reason` so an agent can rerun the failing command or widen the proof only after success. It does not contact public services and does not write retained run state. `truth --run --deep` adds parser-diff and anchor-amnesia; an explicit `--work-dir` is retained for inspection, while an automatically selected temporary anchor workroom is removed after the rendered proof unless `--keep-work-dir` is explicit. It still does not mutate public services. A successful deep/full run points to the exact sibling `cityb doctor --json` product check, which works from an installed Stil closure without pretending that Cargo belongs in the operator environment; source maintainers additionally run `cityb-biggun gate --quick --json` from the pinned development shell. `truth --run --full` adds the quick standalone selftest, which writes a retained local proof root and is the right pre-release confidence step when time is available. The full retained `exercise` integration test is intentionally ignored in the default Rust test run because it is a stress proof over a large retained local workflow; run it explicitly only when the host has enough time for a heavyweight Biggun proof.

The cockpit deliberately composes existing commands instead of creating a second implementation of their checks. Each step remains inspectable and runnable alone:

| Step | Tier | Proves |
|---|---:|---|
| `guide` | preflight | A future maintainer can recover the safe Biggun command sequence without remembering the docs. |
| `capabilities --json` | quick | Biggun still advertises the expected capability envelope. |
| `matrix --json` | quick | The three-binary topology and report list are visible. |
| `living --json` | quick | The retained provider monitor has visible state, import backlog facts, latest-run status, optional freshness status, and a next maintenance command. |
| `mutation-corpus --json` | quick | Malformed carriers receive named parser/checksum refusals. |
| `erasure-matrix --json` | quick | Archive-erasure math reconstructs all required subsets and reports loss curves. |
| `correspondence-relay-study --json` | quick | Canonical frames and MQTT/ntfy/Nostr carrier-specific overwrite, expiry, duplicate, loss, identity, size, and corruption assumptions remain explicit. |
| `provider-reality --require --json` | quick | Retained provider/firehose evidence still supports exact-byte, live archive-shard eligibility, discovery-only, mixed-watch, recovered-watch, failure, archive-spray thresholds, and latest-plan provider-loss replay. |
| `soak-report --json` | quick | Operator-facing soak rollup over the same evidence: the shared capability ledger, provider streaks, provider drift, archive survival, size-dependent capacity, retained topology/root-loss risk, evidence coverage, pointer-only stable providers, firehose breadth, release-trust/field-pack risk, and exact next recommendations. |
| `promotion-tranche --require --json` | quick | Ranks repeated-green providers outside `free-stable` by exact-body history, whole-corpus Goldilocks/Tiny parser agreement, archive capacity, expiry evidence, observed root independence/concentration, and intended role. Add `--live-topology` for an explicit present-day DNS/IP/ASN/CDN read of both stable and candidate sets. It is review evidence, never promotion authority. |
| `parser-diff --require --json` | deep | Goldilocks and Tiny parse generated, service-body, malformed HTML, OCR-ish, and firehose corpora identically. Temporary corpus files are removed by default; add `--keep-corpus` only for deliberate forensic inspection. |
| `anchor-amnesia --json` | deep | Tiny accepts a native-proof retained anchor and rejects an unverified anchor; Goldilocks builds and OpenSSH-signs a reviewed release, seals the signature into the distributed archive, reconstructs it from a sufficient erasure subset, admits it through persisted release trust with the one-command recovery transaction, regenerates handoff artifacts, and then Tiny consumes archive-verified pointer-chain slot plans, probes a concrete retained-local slot, and reports stale/missing-slot fallback. |
| `selftest --quick --json` | full | The three binaries compose through the standalone retained-run proof; typed `action-required` Goldilocks `check`/`next` reports are retained as completed observations rather than confused with crashed subprocesses. |

The development rule is: if a CityB claim matters to field operation, eventually Biggun should be able to rehearse it. Operator commands can remain convenient and narrow, but Biggun should preserve the corresponding adversarial or empirical proof with a stable JSON report.

`provider-reality` now reports an `archive_spray_readiness` object in JSON and matching human lines. It names the latest evidence date, whether that date meets the requested shard threshold, exact and failed provider counts, live archive-shard eligible counts, live ineligible exact-byte carriers, threshold margins, current and longest threshold streaks, and the exact providers supporting the latest date. The live archive-shard fields intentionally use the same eligibility predicate as `dead-drop archive spray --apply`, so a provider that can carry a pointer but is staged/manual, rendered-token-only, credentialed, or observed to mishandle archive shards does not inflate automatic spray readiness. Add `--archive-evidence-root ROOT` to replay retained `city-b-archive-erasure-provider-evidence.jsonl` files from real archive sprays; those records count archive-sized successes and failures separately from pointer-sized fixture evidence. It also reports `archive_loss_model`, a conservative replay of the latest live-exact provider set as one shard per provider over every dated evidence row. That model names planned, data, and parity shard counts, comparable and fully observed evidence dates, per-date surviving/missing/unknown provider names, the worst dated row, whether the latest modeled plan reconstructs, and the exact dry `cityb dead-drop archive plan` command matching the modeled profile. Provider rows also report `latest_exact_date`, `latest_failure_date`, and `latest_failure_cleared`, so a one-day failure followed by later exact-byte recapture becomes `recovered-watch` rather than permanent mixed drift. That distinction is important for stable-set decisions: stale failures should remain visible, but they should not look equivalent to current rot.

`soak-report` is the same evidence narrowed to the operator's watch screen. It defaults to `free-stable`, the checked-in provider/firehose fixture roots, a 32-shard threshold, and `city-b-artifacts` when that retained archive root exists; pass the current plan threshold explicitly when it differs. Human output is short enough to read during a soak. JSON keeps the canonical `cityb.capability-ledger.v1` plus nested `provider_streaks`, `provider_drift`, `archive_survival`, `archive_capacity`, `evidence_coverage`, `retained_risk`, `topology_concentration`, `pointer_only_stable`, `latest_failed_providers`, `firehose`, and `recommendations`. `providers` is the selected service-set count while `corpus_provider_count` is the wider number represented by the fixture corpus. `provider_streaks` and `latest_failed_providers` are strictly pointer-lane facts; a later same-day archive-shard expiry cannot overwrite a successful tiny-pointer observation. `archive_capacity`, `archive_survival`, and `retained_risk` preserve the archive lane separately. `archive_capacity` separates proven archive-sized carriers from repair-needed carriers, unproven eligible carriers, recovered-watch carriers, and pointer-only stable carriers. A failure above the largest previously successful payload records a bounded ceiling without erasing the smaller proven class. Observations within each lane are ordered by their full capture timestamp where available, and a failure wins a same-timestamp tie, so an early same-day success cannot hide a later same-lane failure. Firehose services apply the same rule: repeated historical parser successes remain evidence, but a newer failed listing fetch produces `listing-failure-watch` and keeps that source out of Tiny sweeps until a later dated success is captured and reviewed. `evidence_coverage` describes the dates and shards actually replayed; it is not a topology score. When the retained root has a topology snapshot, `retained_risk` models largest-root loss, size-proven survivors, expiry, field-pack staleness, and release-trust rejection over the actual plan; absent evidence remains `unknown`. The report performs no remote mutation and should be run after `evidence sync`, after a monitor import, and after every archive-sized spray proof.

`promotion-tranche` consumes the same retained evidence plus `parser-diff`. It
excludes current stable members, requires the provider-reality
`exact-stable-candidate` classification, and emits ranked rows with the facts
an operator needs before opening a dossier or source patch. Its October 22
proof produced 26 candidates with parser agreement. A high score does not
change source: the output explicitly requires a dossier, dated topology,
role-specific evidence, and a reviewed patch. Offline mode uses the latest
retained topology snapshot and labels unknown candidate roots honestly.
`--live-topology` invokes the same bounded Goldilocks enrichment for the stable
set and candidate pool, merges those observations only in memory, and records
`topology_source` plus observation counts in the report. It does not retain a
snapshot, edit a provider set, or turn a hostname into proof of independent
ownership.

Future-generation geometry is also deliberately shared rather than
reimplemented. Biggun's `provider-reality` and `soak-report` own the empirical
capacity, expiry, and correlated-root-loss evidence. Goldilocks consumes that
same retained evidence with `cityb dead-drop archive preview --input RELEASE`
and compares bounded codec-valid geometries for the release's exact bytes. A
preview can rank structural alternatives while remaining explicitly
`capacity-evidence-insufficient`; only a capacity- and topology-supported
result receives a runnable generation command.

Future Biggun work should move in three directions. First, more empirical depth: accumulate date-separated topology snapshots, capacity bands, expiry observations, and upstream-anchor transcripts so correlated-loss results are not dominated by one day. Second, more parity: every parser, schedule, pointer-chain, anchor, release-admission, and Tiny durability claim should have a Goldilocks-vs-Tiny or Tiny-after-crash proof. Third, more maintainability: new evidence rollups should live in focused modules like `provider_reality.rs` and `truth.rs`, not in the already-large Biggun dispatcher.
