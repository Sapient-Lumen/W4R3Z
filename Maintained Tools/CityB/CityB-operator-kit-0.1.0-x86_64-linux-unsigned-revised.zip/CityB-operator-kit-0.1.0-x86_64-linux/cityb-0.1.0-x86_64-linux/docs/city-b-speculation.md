# City B speculation ledger

This document is intentionally speculative. It catches useful City B ideas
before they become scattered comments, half-remembered chat state, or brittle
TODOs. The implementation plan remains [city-b-plan.md](city-b-plan.md); the
frontier theory and substrate discussion remain
[city-b-frontier.md](city-b-frontier.md); the broad dream space remains
[dead-drop-dreams.md](dead-drop-dreams.md).

The center of gravity is CityB: a practical, operator-usable mode for keeping
governance discoverable under outage, filtering, poisoning, stale replay,
pruning, and carrier loss. The standalone repo no longer carries the old civic
baseline workflow; if CityB grows clever but breaks the ordinary
signed-governance path, it has failed.

## What CityB already gives City B

CityB already has a strong spine:

- council threshold signatures over binding governance artifacts;
- complete signed bundle archives;
- compact pointers to archive state;
- receive-only node adoption through the same verification gate in every
  visibility regime;
- named refusal paths for stale, pruned, forged, forked, incomplete, or malformed
  evidence;
- local CityB workflows that retain runbooks, manifests, transcripts,
  deployment maps, fleet state, and audit material;
- City B dead-drop surfaces for feed scaffolding, token rendering, text import,
  scanning, watch, distribution plans, receipts, freshness debt, rendezvous
  schedules, local posting doubles, observation, substrate scoring, threshold
  fragments, recovery explanations, and recovery capsules;
- three City B binaries:
  - `cityb-node`: dependency-tiny, receive-only, no signing or posting;
  - `cityb`: Goldilocks operator surface;
  - `cityb-biggun`: research/lab/handoff/exercise surface;
- a three-binary smoke that proves Goldilocks can create a retained City B run,
  Tiny can verify/adopt/capsule-check the receive side, and Biggun can retain
  footprint, fragment, volatile-gossip, degradation, and recovery-summary proof.

That means the next useful question is not "can City B exist?" It can. The next
question is: what would make it excellent as an actual tool?

## Governing constraint

The covert layer may be clever. The authority layer must remain boring.

```text
carrier bytes
  -> candidate token / candidate fragment / candidate heartbeat / route hint
  -> checksum and schema checks
  -> reconstruction if needed
  -> signed archive verification
  -> normal CityB gate
  -> adoption, refusal, or freshness debt
```

No substrate should become a second government. A paste, issue comment, package
metadata record, gossip event, QR card, CI log, or Tox transcript can help a node
or operator find candidate bytes. It cannot authorize state.

The product can still be a capable covert-posting engine if capability means:

1. plan placements across declared carrier classes;
2. encode material in substrate-appropriate shapes;
3. post to explicitly configured local or operator-owned targets;
4. observe and classify the resulting evidence;
5. measure survivability, latency, cost, mutation, and takedown behavior;
6. explain exactly what worked and what failed.

The line to preserve is remote mutation: it must be explicit, configured,
bounded, and attributable to an operator role.

## New feedback deltas to preserve

The useful outside feedback changes the roadmap in six concrete ways.

First: do not frame resilience as coercive leverage over unrelated
infrastructure. The useful product target is lawful high-fit placement:
operator-owned surfaces, local doubles, ordinary metadata shapes,
measured replication, and explicit blocking blast radius. A carrier may be hard
to erase because it is mundane and well-integrated. It should not be hard to
erase because CityB intentionally drags unrelated operators into the cost model.

Second: raw 38-hex pointers are scanner-friendly but not always covert. They
should remain the explicit-feed and test-fixture baseline. Covert carrier
profiles need format-preserving encodings: semver build metadata, log-shaped
fields, status-page timestamp/counter shapes, signed-event tags, and
mnemonic/parity card forms.

Third: public randomness alone is symmetric. A schedule derived from public
city seed plus public beacon is visible to observers and censors at the same
time it is visible to the fleet. The next rendezvous planner should mix in the
previous verified archive root. Nodes that missed the previous epoch still need
floor routes, recovery capsules, and slower public fallback schedules.

Fourth: Shamir 3-of-5 is an anti-leakage tool, not a universal recovery tool.
If the threat is early pointer disclosure followed by fast archive suppression,
Shamir is justified. If the threat is carrier loss, OCR damage, or human
transcription, whole-token repetition, systematic erasure coding, mnemonic
chunks, or parity-framed cards may win.

Fifth: heartbeat debt needs hysteresis. Missing heartbeats should not force a
weak fleet into linear polling escalation, battery drain, bandwidth visibility,
flash churn, or floor-token exhaustion. Escalation should mostly affect local
skepticism and operator warnings, with capped/sub-linear external fetching.

Sixth: the evidence ledger should grow toward a content-addressed DAG. The
human report can stay plain Markdown, but each claim should eventually replay
from raw carrier snapshot hash, parser version, extracted fact, archive
verification fact, and adoption/refusal fact.

## Strategic thesis

City B should become an evidence machine.

It should not merely "hide pointers." It should build and maintain an evidence
graph around every governance state:

```text
signed epoch
  ├─ archive record and receipt
  ├─ pointer token
  ├─ whole-token placements
  ├─ threshold-fragment placements
  ├─ heartbeat material
  ├─ route-hint material
  ├─ observation receipts
  ├─ freshness debt
  ├─ refusal ledger
  ├─ substrate scores
  ├─ binary footprint proof
  └─ replay commands
```

The operator should be able to answer, from one retained directory:

- which signed state is current;
- where discovery evidence was planned;
- where it was actually placed;
- which placements were observed;
- which observed bytes verify against the archive;
- which carriers are fresh, stale, failed, censored, duplicated, or suspicious;
- which fragments are still missing;
- which receiver binaries were used;
- what a weak Tiny node can independently verify;
- what the next rotation should try.

## Additional improvement seams

These are the next clever pieces that look worth exploring after the feedback
pass. They are bounded as product/lab features, not remote-public side effects.

### Threat-profile compiler

City B needs fewer independent knobs and more named threat profiles. A profile
should compile into encoding choice, placement count, fragment scheme, TTL,
heartbeat cadence, observation cadence, fallback routes, and required receipts.

Possible profiles:

- `benign-outage`: prefer whole-token repetition, long TTL, low operator cost;
- `carrier-loss`: maximize failure-domain diversity and redundancy;
- `early-scraper`: prefer Shamir or other anti-disclosure fragments;
- `human-recovery`: prefer mnemonic/card encodings and fewer manual steps;
- `low-power-field`: prefer batch receive, zero-write mode, capped polling;
- `high-churn-gossip`: prefer volatile receipts plus frequent re-observation;
- `audit-heavy`: prefer evidence-DAG completeness over speed.

The operator should pick a threat model, not hand-tune twenty weights.

Candidate command:

```text
cityb profile compile --profile early-scraper --root RUN --json
```

### Provenance and correlation hygiene

Carrier diversity is weaker than it looks if several carriers share the same
account, CDN, DNS zone, human operator, cloud provider, moderation system, or
source transcript. City B should treat provenance as graph data.

The useful output is not "five carriers observed." It is:

```text
five carriers observed
three provider domains
two operator accounts
two DNS zones
one copied transcript root
effective independent roots = 2
```

This directly extends the current strict source-root check. It should become a
general correlation graph used by scoring, review, and recovery reports.

### Clock uncertainty and epoch tolerance

Weak receivers may have bad clocks, cold boots, dead CMOS batteries, or long
offline gaps. City B should minimize reliance on local wall time where possible.

Better clock model:

- archive epoch is authoritative for state order;
- public beacon round proves schedule context when present;
- receipt wall time is an observation claim, not authority;
- Tiny reports clock confidence separately from verification status;
- freshness debt accepts a clock-uncertainty interval instead of one absolute
  timestamp;
- recovery capsules include enough epoch context to operate with no trusted
  local clock.

This matters for ARM boards and old laptops more than for lab machines.

### Scope and authority manifest for adapters

Before any live adapter exists, define the manifest it must satisfy:

```text
adapter_id
owner_identity_label
credential_source
allowed_targets
public_visibility
remote_mutation_allowed
delete_or_revert_semantics
max_bytes_per_epoch
max_posts_per_epoch
operator_confirmation_required
receipt_kind
shutdown_command
```

The adapter manifest is not just safety theater. It also lets Biggun run the
same experiment against local doubles and later against operator-owned
integrations without changing receipt semantics.

### Operator rehearsal mode

Goldilocks should let a human rehearse the next rotation without posting:

```text
render every planned placement
show exact bytes
show target class and authority claim
show expected public visibility
show what Tiny can recover
show what Biggun expects to observe
ask operator to mark "posted", "skipped", "impossible", or "unsafe"
```

This would reduce the biggest practical risk: the tool is technically right but
the operator cannot execute the plan under pressure.

### Negative-evidence maps

Missing evidence needs structure. If a carrier was planned but not observed, the
tool should distinguish:

- not attempted;
- attempted but not posted;
- posted but not visible;
- visible but mutated;
- visible but unparseable;
- parseable but stale;
- parseable but archive-missing;
- verified but no longer fresh.

This is the difference between recovery guidance and a pile of JSON.

### Archive availability mirrors without carrier authority

Pointers are useless if the archive is unavailable. City B can improve archive
availability without trusting carriers:

- local static archive mirror doubles;
- removable-media archive bundles;
- operator-owned object-store/static-site mirrors;
- mirror receipts that prove bytes observed, not legitimacy;
- partial archive chunk availability reports;
- `archive-missing` guidance that says which bytes are absent.

The rule stays simple: mirrors move bytes; signatures decide truth.

### Parser differential tests

Every format-preserving encoding creates parser risk. Biggun now compares
Goldilocks and Tiny parsers over identical generated corpora with
`cityb-biggun parser-diff --require`:

```text
same corpus
same expected candidate list
same checksum-valid counts
same reconstructed pointer
same archive gate result
```

Any mismatch between operator and Tiny parser behavior is a field bug.

### Recovery drills as generated exams

Biggun can generate exam directories with withheld answers:

- messy imported feeds;
- stale tokens;
- mutated cards;
- duplicate fragments from one root;
- missing archives;
- forked archives;
- one valid recovery path.

Then `cityb review` or a human operator tries to recover. The answer key
is revealed only after the run. This turns the lab into a repeatable usability
test instead of only a deterministic smoke.

### Two-speed publication

Some material should be fast and noisy; some should be slow and durable. A
single profile may produce two linked placement classes:

- fast volatile hints: short TTL, frequent observation, cheap to rotate;
- slow recovery anchors: long TTL, stronger encoding, lower posting cadence.

Both remain discovery evidence. The benefit is operational: nodes and humans do
not wait on slow durable media when volatile media are healthy, but recovery is
not dependent on volatile churn.

### Split signer and poster workstations

Goldilocks owns normal operator workflow, but signing material and posting
credentials should remain separable roles:

```text
signer workstation -> signed archive + pointer
poster workstation -> placement queue + adapter credentials
observer workstation -> imported transcripts + receipts
tiny node -> receive-only verification
```

This reduces blast radius. A posting credential leak should not become a council
key incident. A compromised observer should not become a publisher.

### Tiny status as the universal support artifact

Every support workflow should start with one Tiny-generated status card:

```text
binary digest
capability set
clock confidence
state epoch
latest accepted archive hash
latest refusal name
inbox candidates seen
write budget
flash mode
next safe command
```

That card can be pasted into Goldilocks, Biggun, an incident report, or a human
chat without exposing private authority.

## Speculation map

| Area | Near-term product move | Research move | Why it matters |
|---|---|---|---|
| Planner intelligence | Turn substrate scoring into an actionable placement queue | Calibrate weights from Biggun experiments | The operator needs recommendations, not raw inventories |
| Threat profiles | Compile named threat profiles into placement, encoding, fragment, TTL, and receipt settings | Compare profiles under identical Biggun scenarios | Operators should choose threat models, not tune every knob |
| Provenance graph | Implemented first pass: collapse receipts by carrier, substrate, failure domain, and location root | Measure effective independence under mirrored or copied evidence | Five carriers can still be one failure domain |
| Clock uncertainty | Add clock-confidence and epoch-window reporting | Test no-clock and wrong-clock field receivers | Weak nodes often fail in timekeeping, not crypto |
| Adapter authority | Require live adapter manifests before remote-capable posting | Reuse manifest semantics across local doubles and owned integrations | Scope and authority need machine-readable evidence |
| Encoding profiles | Add format-preserving pointer encoders and parser fixtures | Compare raw hex, semver, log-field, timestamp, signed-event, mnemonic, and card shapes | Covert carriers fail if the token is the loudest object in the carrier |
| Ratcheted rendezvous | Mix previous verified archive root into beacon-derived schedules | Measure missed-epoch recovery against floor/fallback routes | Public beacon schedules are otherwise censor-readable |
| Local doubles | Make status/repo/package/CI/transparency doubles richer | Replay deletion, truncation, moderation, CDN lag, split-view, and retention failures | Doubles let us build hard semantics before live adapters |
| Adapter governance | Add adapter manifests and explicit capability gates | Compare operator-owned integrations under transcripted trials | Remote mutation must stay visible and bounded |
| Fragment strategy | Compare Shamir, systematic erasure, repetition, mnemonic chunks, and card layouts | Tune per-profile encoding, redundancy, and OCR/human recovery | Fragments help anti-leakage; they may punish availability |
| Heartbeat policy | Add signed heartbeat-policy Acts, heartbeat-debt reports, and hysteresis | Study induced starvation under partial outage | Absence can warn; it must not drain or improvise authority |
| Route hints | Add signed route-policy Acts and route-hint prioritization | Measure whether hints speed recovery without causing churn | Hints can save operator time without changing the trust gate |
| Tiny node | Add batch verifier/appliance mode and state compaction | Measure RAM, flash writes, ARMv7/aarch64 runtime | A boring weak node is strategically powerful |
| Goldilocks UX | Add `review`, `publish queue`, and `next-action` workflows | Study operator error rates | The default tool should make safe work easy |
| Negative evidence | Make missing/failed/observed-but-unverified states first-class | Test recovery guidance under incomplete data | Silence is not one failure; it has causes |
| Archive mirrors | Add byte-availability mirrors and partial archive reports without carrier authority | Model archive-missing recovery paths | Discovery succeeds only if archive bytes are reachable |
| Parser parity | Differential-test Tiny and Goldilocks parsers | Fuzz carrier-shaped corpora | Parser mismatch is a field split-brain |
| Biggun lab | Add replayable experiment manifests, Monte Carlo sweeps, evidence-DAG validation, and exam-mode drills | Turn field transcripts into calibration data | Biggun should be the lab brain, not a bigger operator binary |
| Recovery narrative | Expand explainers from dead-drop roots to whole retained runs | Measure whether humans can recover under time pressure | A tool that cannot explain recovery is not operationally complete |

## Feature ideas by binary

### Tiny node: smallest useful receiver

Tiny should stay boring enough to deploy broadly.

Strong properties:

- receive-only forever unless a future spec defines a separate role;
- no private keys, no posting adapters, no city runner, no lab machinery;
- can verify a signed archive, pointer, fragment reconstruction, node kit,
  recovery capsule, and local text transcript;
- can produce one JSON status card that a human, Goldilocks, or Biggun can
  consume without bespoke parsing;
- can run as a daemon or as a batch verifier;
- can tolerate old kernels, small disks, low RAM, and intermittent power.

Speculative improvements:

1. `cityb-node appliance init`: write a minimal systemd/OpenRC/runit-ready
   directory with config, state path, log path, and update instructions.
2. `cityb-node once`: run one fetch/verify/adopt cycle and exit with a
   structured status. This may be more useful than a daemon on tiny devices.
3. Zero-write cron mode: keep scan/refusal/intermediate state in `tmpfs`, mount
   flash read-only where possible, and durably write only after a higher-epoch
   signed archive fully verifies.
4. `cityb-node bundle status --root KIT|CAPSULE|STATE`: one command that
   recognizes kit, capsule, retained run, or provisioned state and emits the
   best receive-side summary.
5. State compaction: retain the current chain tip, enough history to prove
   monotonicity and fork alarms, and an explicit receipt explaining what was
   compacted.
6. Flash-write budget: count writes per cycle and expose `state_bytes`,
   `writes_this_cycle`, `writes_total`, and `largest_file`.
7. Offline import inbox: a directory where copied transcript files, QR-card
   transcriptions, USB bundles, or printed-card scans can be dropped without
   changing config.
8. `--explain-refusal`: when adoption fails, emit the single best next action:
   fetch archive, import more fragments, wait for heartbeat, reject stale feed,
   or inspect fork.
9. Build-time feature proof: emit a machine-readable card showing linked crates,
   disabled capabilities, target triple, panic strategy, and binary digest.

Surprising possibility: the smallest useful Tiny may not be a long-running
network service. A batch verifier that wakes from cron, scans a small inbox,
updates state, prints status, and exits may be more robust on weak hardware than
a daemon.

Consequences:

- lower resident memory;
- fewer stuck sockets;
- simpler supervision;
- fewer flash writes if state changes are batched;
- worse latency, unless wake cadence is tight.

### Goldilocks: default operator workbench

Goldilocks should be the normal human tool: capable, not bloated; explicit, not
timid.

Strong properties:

- owns planning, signing workflows, archive publication, node-kit export,
  recovery-capsule export, dead-drop planning, local posting, observation, and
  explanation;
- now has `cityb exercise --root DIR`, which drives the retained local
  posting exercise end to end: post local doubles, observe them, refresh
  governance reports, and return the updated retained review;
- retained governance scoring now understands the City B artifact layout rather
  than only the generic dead-drop workspace layout, so `review` can distinguish
  “planned but not yet posted” from a false “local feeds missing” diagnosis;
- should be comfortable on a laptop, VPS, or small server;
- should expose everything a careful operator needs without requiring Biggun.

Speculative improvements:

1. `cityb review --root DIR`: one human-first dashboard over a retained
   City B run, including signed chain, fleet health, dead-drop evidence,
   substrate score, freshness debt, refusal names, and next commands.
2. `cityb dead-drop queue`: materialize a placement queue from the current
   substrate score and rendezvous plan. The queue should say "post this material
   to this operator-owned target by this epoch" and record whether the operator
   skipped it.
3. Adapter manifests: every future non-local adapter declares capabilities before use:
   local-only, operator-owned remote, creates public state,
   deletes public state, observes only, expected TTL, max bytes, max rate,
   credential source, and receipt semantics.
4. Dry-run preview: before any remote-capable adapter posts, render exact bytes,
   target, account/project identity, expected public visibility, cleanup limits,
   and observation method.
5. Human escrow mode: export a printable or copyable "operator bundle" with
   pointer token, fragment shares, instructions, expiry, and receipt form.
6. Substrate profiles: `conservative`, `owned-web`, `developer-metadata`,
   `volatile-gossip`, `physical`, and `full-lab` profiles selecting allowed
   substrate classes.
7. Rotation compiler: given freshness debt and substrate failures, produce the
   next plan with an explanation of why the old rotation is weak.
8. Import assistant: consume a messy directory of pasted browser saves, text
   files, logs, screenshots converted to text, and transcripts; classify them
   before scanning.
9. Safety rails for operator mistakes: warn when a plan depends on one account,
   one DNS zone, one cloud vendor, one network, one human, or one device.

### Biggun: research and pressure laboratory

Biggun should be free to be large, slow, and thorough.

Strong properties:

- owns experiment design, sweeps, local doubles, adversarial scenarios, retained
  proof, three-binary handoff, and publication-quality summaries;
- does not become the thing weak nodes need to trust;
- can produce work that Goldilocks later imports as calibrated policy.

Speculative improvements:

1. Experiment manifests: every Biggun run writes an input manifest describing
   substrate registry, random seeds, planned failures, binaries, target triples,
   and expected assertions.
2. Monte Carlo substrate sweeps: simulate loss, TTL expiry, moderation removal,
   truncation, duplicate carriers, correlated failure domains, and operator
   skipping.
3. Local transparency-log double: append-only log with inclusion and consistency
   proofs, plus split-view and maximum-merge-delay failure modes.
4. Local repo/package/CI doubles: Git issue/release metadata, package index
   metadata, build logs, artifact manifests, deletion/yank/retention behavior.
5. Volatile-gossip replay: import transcript fixtures for Nostr, libp2p,
   local-mempool, and IoTox/Tox; measure observed-before-expiry probability and
   route diversity.
6. OCR/card lab: generate rendered cards, wrap/mutate/crop/blur them, OCR or
   text-import them, and compare whole-token vs fragment recovery.
7. Operator-error lab: deliberately swap fragments, duplicate source roots,
   truncate logs, paste old tokens, or mix epochs; assert refusal names remain
   useful.
8. Field transcript importer: turn manually captured live trials into retained
   Biggun evidence without requiring Biggun to perform the live mutation.
9. Calibration exporter: write a signed or hash-pinned calibration file that
   Goldilocks can use for substrate-score weights.
10. Long-run churn test: keep a local City B over hundreds or thousands of
    epochs, rotating placements and recording state growth.

## Missing pieces worth building

### 0. A format-preserving encoding registry

Every substrate profile should name how bytes are rendered and parsed. The
registry should keep raw hex as `plain-token`, but should also define
carrier-native encodings:

- `syntactic-semver`: pointer bytes distributed through semver build metadata;
- `log-field`: pointer bytes in ordinary key/value log suffixes;
- `status-timestamp`: pointer bytes encoded in timestamp/counter-shaped fields;
- `signed-event-tags`: pointer bytes in relay event tags;
- `mnemonic-card`: word-list chunks with parity/checksum for OCR and humans;
- `systematic-erasure-card`: byte chunks plus parity lines for partial recovery.

Each encoding needs:

- renderer;
- parser;
- maximum visible bytes;
- mutation expectations;
- false-positive behavior;
- Biggun corpus fixture;
- Tiny parse/verify proof if Tiny is expected to consume it.

### 1. A unified evidence ledger

The repo already emits many evidence files. The next step is one typed ledger
schema that can ingest:

- archive records;
- pointers;
- placement envelopes;
- placement receipts;
- observation receipts;
- fragment reports;
- debt reports;
- substrate scores;
- heartbeat and route-hint material;
- Tiny status cards;
- Biggun footprint summaries.

Candidate command shape:

```text
cityb evidence ingest --root RUN FILE...
cityb evidence summarize --root RUN --json
cityb evidence explain --root RUN --for operator|node|auditor
cityb-biggun evidence check --root RUN --require B9
```

This would reduce hand-rolled report parsing and make recovery summaries more
durable.

### 2. A receipt state machine

Current receipts are useful, but City B wants a sharper lifecycle:

```text
planned
  -> prepared
  -> posted
  -> observed
  -> verified
  -> fresh
  -> stale
  -> expired
  -> failed
  -> superseded
```

Every transition should have:

- actor;
- command;
- timestamp/epoch;
- input digest;
- output digest;
- substrate id;
- failure domain;
- refusal or failure reason;
- replay command.

This would let operators distinguish "not posted," "posted but not observed,"
"observed but not verified," and "verified but expired" without reading every
artifact.

### 3. Policy objects for heartbeat and route hints

The plumbing exists for heartbeat and route-hint material, but the policy layer
is intentionally absent. That should be explicit in the spec and then added as
ordinary signed Acts.

Possible heartbeat policy fields:

```text
policy_kind = heartbeat
cadence_epochs
eligible_substrate_classes
minimum_fresh_media
miss_threshold
effect = alarm|tighten-polling|preserve-floor-budget|operator-review
expires_epoch
```

Possible route policy fields:

```text
policy_kind = route-hint
route_families
minimum_verified_observations
freshness_window
effect = reorder-polling|operator-advisory|disable-route-family
expires_epoch
```

Effects should adjust local posture or operator guidance, not grant new
authority.

### 4. A placement optimizer

The current substrate score is a good start. The eventual optimizer should
choose placements under constraints:

```text
maximize:
  verified discovery probability
  failure-domain diversity
  freshness overlap
  operator-owned preference
  low correlation

minimize:
  operator burden
  account concentration
  conspicuousness
  stale debt
  public mutation
  irreversible side effects
```

The optimizer should emit both the plan and the reason:

```json
{
  "choice": "status-page-primary",
  "reason": [
    "operator-owned",
    "fresh observation in previous epoch",
    "different account/provider than repo-metadata",
    "low posting cost",
    "enough TTL overlap with package-index-secondary"
  ],
  "rejected": [
    {
      "substrate": "ci-build-log",
      "reason": "retention expired in last two runs"
    }
  ]
}
```

### 5. A local integration harness for owned public surfaces

Before live adapters, build local service doubles that behave like likely owned
infrastructure:

- static status site;
- Git-forge issue/release metadata;
- package-index metadata;
- CI log/artifact retention;
- transparency-log monitor;
- Nostr relay;
- libp2p provider record cache;
- IoTox/Tox transcript exporter;
- local mempool queue.

Each double should support at least:

- post;
- observe;
- delete/expire;
- truncate/mutate;
- rate-limit/refuse;
- export transcript;
- explain receipt semantics.

This makes Biggun experiments useful before credentials or live endpoints exist.

### 6. Human recovery UX

City B's hard moment is a tired operator trying to recover under pressure. The
tool should optimize for that human.

Possible artifacts:

- one-page recovery card;
- QR/token cards for current pointer and fragments;
- "what I know" report for a Tiny node;
- "what to try next" operator checklist;
- "why I refused" explanation with a minimal replay command;
- printable fragment sheet with checksum and source-root expectations;
- capsule verifier transcript suitable for copying into an issue, email, or
  incident report.

The best future test may be a human test: give someone a recovery capsule,
messy transcripts, and a time limit; measure whether they can recover the
current signed pointer without help.

### 7. Field-tiny engineering

The tiny node is already dependency-tiny. Field-tiny means proving behavior on
targets that are actually annoying:

- aarch64 SBC;
- armv7 board or emulator;
- old x86 thin client;
- small RAM VM;
- read-mostly or weak flash storage;
- no Nix store;
- static musl or distroless packaging where practical.

Measurements to retain:

- binary bytes and digest;
- package output bytes;
- closure or runtime dependency bytes;
- max RSS for `capabilities`, `kit verify`, `capsule verify`, one serve cycle,
  and dirty-corpus scan;
- state growth per epoch;
- writes per cycle;
- time to verify a chain of N epochs;
- time to scan M files and K tokens;
- failure behavior under missing clock, old clock, read-only state, and partial
  write.

### 8. Full-run explanation

`dead-drop explain` explains the dead-drop evidence root. City B also needs an
operator narrative for the entire retained run:

```text
cityb explain --root RUN --json
```

It should summarize:

- city topology;
- council threshold and current constitution;
- latest signed epoch;
- fleet status;
- hostile probes;
- fork alarms;
- detector findings;
- dead-drop placements;
- freshness debt;
- fragment/capsule state;
- binary footprints;
- next action queue.

This should become the human default after `city run --name city-b --root RUN`.

### 9. A content-addressed evidence DAG

The evidence ledger should remain readable, but complex partitions need a hash
graph underneath it:

```text
carrier_snapshot_hash
  -> parser_fact_hash
  -> extracted_pointer_or_fragment_hash
  -> archive_verification_hash
  -> adoption_or_refusal_hash
```

This lets a later auditor replay a recovery report down to exact captured
carrier bytes and parser versions instead of trusting that a Markdown report was
faithful.

### 10. Passive observation lab

Passive discovery is useful only when it stays inside owned lab
boundaries. Biggun could model receive-only "ghost" nodes that emit no network
traffic and learn only from supplied captures:

- LAN multicast capture fixtures;
- local relay transcript export;
- SDR/LoRa-like one-way beacon fixture;
- browser/network metadata transcript supplied by an operator;
- removable-media inbox snapshots.

This is not a default Tiny behavior and not a packet-sniffing feature for other
people's networks. It is a lab profile for zero-packet receive-side recovery.

## More aggressive speculative ideas

These ideas may be useful, but they need Biggun experiments before product
promotion.

### Adaptive rotations

Instead of static substrate choice, City B could continuously rotate based on
observed failures:

```text
score(t)
  + freshness debt
  + observed failures
  + account/provider correlation
  + operator skip history
      -> next placement set
```

Risk: adaptive behavior can become hard to audit. The plan must remain
deterministic from retained inputs.

### Canary carriers

A low-value pointer or heartbeat could be placed in a carrier specifically to
measure deletion, mutation, lag, or observation. The canary would not be needed
for recovery. It would calibrate the substrate score.

Risk: canaries add operator burden and may create noisy public state. They
belong in operator-owned or local doubles first.

### Diversity certificates

A recovery report could certify that evidence came from distinct failure
domains:

```text
domain(account) != domain(provider) != domain(network) != domain(human)
```

This matters because three files copied from one transcript are not three
independent carriers. The existing strict source-root check is the right first
step; it should grow into failure-domain certification.

### Capsule-to-kit loop

A Tiny node can verify a recovery capsule. A future Goldilocks command could
turn a verified capsule back into a fresh node kit:

```text
cityb node-kit from-capsule --capsule CAPSULE --out KIT
```

This would help when the operator has recovery evidence but not the original
retained run.

Risk: do not accidentally treat capsule evidence as private authority. The new
kit still contains public receive-side state only.

### Local mirror autonomy

Tiny nodes might serve local read-only mirror endpoints after adopting a state,
so nearby nodes can fetch public archive material from LAN or removable media.

Risk: this changes node speech. The current spec says nodes report nothing
mandatory. If implemented, it should be a separate, explicit "mirror node" role,
not the default Tiny node.

### Delay-tolerant bundles

City B could generate bundle sets optimized for disconnected transfer:

- current pointer;
- chain tip;
- last K epochs;
- receipt proof;
- recovery capsule;
- selected fragments;
- one-page explanation.

The output should be small enough for QR chunks, email attachments, USB, or
printed transfer.

### Substrate grammar fuzzing

Every carrier class has a different way to damage text. Biggun should fuzz
substrate-specific grammar:

- Markdown rewrap;
- HTML escaping;
- JSON pretty-printing;
- log truncation;
- Unicode normalization;
- OCR confusions;
- line ending changes;
- URL auto-linking;
- issue/comment moderation banners;
- package metadata sorting;
- CI secret redaction.

This is likely high value because City B's real enemy may be boring text
mutation, not cryptographic attack.

## Possible command tree

This is not a commitment. It is a candidate shape for future product work.

```text
cityb
├─ review --root RUN [--json]
├─ explain --root RUN [--json]
├─ profile
│  ├─ catalog [--json]
│  └─ compile --profile PROFILE --root RUN [--json]
├─ format
│  ├─ render --encoding ENCODING --pointer POINTER [--json]
│  ├─ parse --encoding ENCODING FILE... [--json]
│  └─ catalog [--json]
├─ rendezvous
│  ├─ ratchet --previous-archive-root HASH --beacon FILE --epoch E [--json]
│  └─ fallback --epoch E --beacon FILE [--json]
├─ evidence
│  ├─ ingest --root RUN FILE...
│  ├─ summarize --root RUN [--json]
│  ├─ explain --root RUN --for operator|node|auditor [--json]
│  ├─ dag build --root RUN [--json]
│  ├─ provenance --root RUN [--json]
│  └─ negative-map --root RUN [--json]
├─ dead-drop
│  ├─ queue --root DIR --against CHAIN-DIR [--profile PROFILE] [--json]
│  ├─ adapter catalog [--json]
│  ├─ adapter inspect NAME [--json]
│  ├─ adapter manifest validate FILE [--json]
│  ├─ adapter dry-run NAME --envelope FILE --target TARGET [--json]
│  ├─ heartbeat policy render --out FILE
│  ├─ heartbeat debt --root DIR --against CHAIN-DIR --policy FILE [--json]
│  ├─ route policy render --out FILE
│  └─ route score --root DIR --against CHAIN-DIR --policy FILE [--json]
└─ node-kit
   └─ from-capsule --capsule CAPSULE --out KIT [--force] [--json]

cityb-node
├─ once --config FILE --state-dir DIR [--now-epoch E] [--zero-write] [--json]
├─ appliance init --out DIR --config FILE [--json]
├─ bundle status --root DIR [--json]
├─ inbox scan --inbox DIR --state-dir DIR [--against CHAIN-DIR] [--json]
└─ status-card --state-dir DIR [--json]

cityb-biggun
├─ experiment run --manifest FILE --root RUN [--json]
├─ experiment replay --root RUN [--json]
├─ exam generate --root RUN --profile PROFILE [--json]
├─ exam grade --root RUN --answers DIR [--json]
├─ format-matrix --root RUN [--encodings LIST] [--json]
├─ erasure-matrix --root RUN [--schemes LIST] [--json]
├─ parser-diff [--cityb PATH] [--cityb-node PATH] [--fixture-root DIR] [--firehose-fixture-root DIR] [--no-fixtures] [--require] [--keep-corpus] [--json]
├─ heartbeat-starvation --root RUN [--profile PROFILE] [--json]
├─ archive-availability --root RUN [--mirrors DIR] [--json]
├─ substrate-double
│  ├─ init status-site|repo|package|ci|transparency|nostr|libp2p|mempool|iotox
│  ├─ mutate expire|truncate|delete|split-view|rate-limit
│  └─ transcript --out FILE
├─ calibrate --runs DIR... --out FILE [--json]
├─ ocr-lab --root RUN --profile PROFILE [--json]
└─ long-run --root RUN --epochs N --nodes N [--json]
```

## Prioritization

### Build next

1. Extend implemented `cityb review --root RUN` from retained-run
   dashboard into a full next-action engine that explains failed checks,
   negative evidence, archive availability, and placement readiness.
2. Extend implemented `cityb profile catalog|compile` artifacts into the
   placement pipeline. The current seam writes deterministic local
   `city-b-threat-profile.{json,md}` for `benign-outage`, `carrier-loss`,
   `early-scraper`, `human-recovery`, `low-power-field`, `high-churn-gossip`,
   and `audit-heavy`.
3. Extend implemented `cityb format catalog|render|parse` into carrier
   adapters and richer parser differential fixtures. Tiny now has
   `cityb-node format parse` for receive-side extraction parity without
   render/post authority. The current seam round-trips `plain-token`,
   `syntactic-semver`, `log-field`, `status-timestamp`, `signed-event-tags`,
   and `mnemonic-card`.
4. State-ratcheted rendezvous schedule proof with explicit public fallback.
5. Shared typed evidence/report structs for receipt debt, substrate score,
   recovery explanation, gossip evidence, and binary footprint summaries.
6. Provenance/correlation graph over source roots, accounts, providers, DNS
   zones, operators, copied transcripts, and failure domains.
7. Biggun local doubles for status/repo/package/CI/transparency with explicit
   mutation modes.
8. Biggun experiment manifest and replay command.
9. Tiny `once` or `bundle status` so weak receivers can operate without daemon
   assumptions.
10. Heartbeat debt report backed by an explicit signed heartbeat policy shape,
   hysteresis, and capped polling changes.

### Build after the next seam is green

1. Placement queue and adapter manifest validation.
2. Full-run `cityb explain`.
3. Negative-evidence map: implemented through archive-missing and
   partial-archive retained archive states; next connect those states to richer
   mirror classes and repair compilers.
4. Evidence DAG builder.
5. Feed real OCR/noise/service bodies into the existing Tiny/Goldilocks parser differential gate.
6. OCR/card lab and measured mutation reports.
7. Systematic-erasure comparison against Shamir and repetition.
8. Failure-domain diversity certificate.
9. Field-tiny measurements on aarch64 and ARMv7, including zero-write mode.
10. Archive-availability mirror reports.
11. Capsule-to-kit export.

### Keep in the dream/research bucket

1. Live third-party substrate mutation.
2. Public CT/Rekor interaction.
3. Blockchain/mempool live use.
4. Automatic LLM/scraper substrate interaction.
5. Node-to-node speech from default Tiny nodes.
6. Any policy where absence alone grants authority.
7. Any design that depends on coercive use of unrelated infrastructure.

## What would make City B feel excellent

City B becomes excellent when the operator experience is:

```text
run
  -> review
  -> publish/record/observe
  -> explain
  -> export kit/capsule
  -> verify on Tiny
  -> hand off one recovery summary
```

The operator should not need to remember the theory to make correct moves. The
tool should say:

- "you have enough fresh verified media";
- "you have enough fragments but not enough source-root diversity";
- "your score depends on one provider";
- "this receipt is stale";
- "this carrier was posted but never observed";
- "this observation found a token but the archive is missing";
- "Tiny can independently verify this capsule";
- "Biggun measured these exact binaries";
- "the next useful action is this command."

That is the practical bar. Clever substrates are optional. Clear evidence and
correct refusal are not.

## Invariants to keep repeating

- City B is a real product surface, not only a lab story.
- The ordinary signed-governance path remains the regression baseline.
- Carrier evidence is not authority.
- Threshold signatures and complete archive verification are the authority gate.
- Tiny stays receive-only by default.
- Goldilocks is where normal operators work.
- Biggun is where expensive experiments happen.
- Remote-public mutation requires explicit operator-owned
  configuration.
- Do not build designs that depend on coercive use of unrelated infrastructure.
- Every claim needs retained evidence or a named speculation status.
- Every successful recovery should be replayable after the next maintainer wakes
  from amnesia.
