# City B frontier theory

City B is the hostile-pressure version of CityB: same signed governance bytes,
same receive-only node rule, same threshold authority, but operated under
partial outage, poisoning, equivocation, censorship, and confused-human
recovery. The practical frontier is a capable covert-posting engine for signed
governance pointers, pointer fragments, heartbeat evidence, and recovery
receipts. Hiding is not decorative; it is the posting and rediscovery mechanism
that keeps governance reachable when overt paths are pressured. The engine is
still useful only if it can keep answering three questions while the environment
is degraded:

1. What is the most recent legitimate state?
2. Where can a disconnected node plausibly rediscover a pointer to it?
3. Which evidence lets a human operator explain what happened afterward?

The current product already has the core: signed archives, pointer-only
carriers, floor scarcity, raw text feed collection, retained City B evidence,
dead-drop plan/receipt/audit/debt commands, deterministic placement schedules,
TTL/rate/failure-aware local-file envelope posting/observation doubles, and an
executable three-binary seam. Goldilocks (`cityb`) produces and audits
retained runs, exports public-only node kits with `node-kit`, exports public
dead-drop recovery capsules with `dead-drop capsule export`, Tiny
(`cityb-node`) verifies and adopts from kits and verifies capsules without
signing/posting authority, and Biggun
(`cityb-biggun`) runs matrix, fragment-matrix, lab, real-binary handoff
checks, local binary footprint reports, from-scratch local exercises, and Tiny
capsule verification. Biggun's exercise now also retains a strict fragment
source-root fixture so both Goldilocks and Tiny must reconstruct from three
separate local carrier roots, not just from one copied fragment directory. It
also writes `city-b-gossip-evidence.json`, requiring the Nostr relay,
libp2p provider-record, local mempool, and IoTox/Tox transcript local doubles to
appear in schedule, post, and verified observation receipts before the volatile
gossip seam is counted as proven. Tiny capsule verification reports that copied
proof's presence, success flag, lane count, and complete-lane count without
gaining Biggun's lab/posting surface. This
document is the next theory layer: the model we should use to build and test
stronger City B infrastructure.
The implementation plan lives in [city-b-plan.md](city-b-plan.md).
The provider-classified rendezvous roadmap lives in
[city-b-rendezvous-roadmap.md](city-b-rendezvous-roadmap.md).
The feature speculation ledger lives in
[city-b-speculation.md](city-b-speculation.md).

## Hard boundary

This is a research and implementation roadmap. The product should keep doing
lawful, testable, local-first work:

- model substrate classes;
- generate plans;
- ingest explicit text supplied by an operator;
- record receipts;
- verify pointer/archive agreement;
- simulate adversaries in `cityb-lab`;
- run operator-owned deployments after local fixtures prove the mechanics.

The product should not silently create remote accounts, mutate third-party
public infrastructure, generate abusive traffic, hide payload authority inside
public systems, or claim that a theoretical substrate has been tested because a
local fixture passed. Public substrates are science targets first.

## Present posture

The strongest current City B decision is authority separation:

```text
carrier layer: untrusted, stale, poisoned, suppressed, or noisy substrates
        │
        ▼
schema and checksum verification
        │
        ├── plain token
        │
        └── fragment set ──► reconstruction
        │
        ▼
compact pointer token
        │
        ▼
signed archive / Merkle gate ── failure ──► named refusal ledger
        │
        ▼
normal CityB adoption gate
        │
        ▼
ACTIVE state, or no state change
```

Carriers are discovery. Archives are truth. Council threshold signatures are
authority. That rule prevents a carrier cartel, poisoned relay, malicious Git
organization, DHT eclipse, or bad local transcript from becoming a second
government.

Mechanically solid parts to preserve:

- The tri-binary topology is real. The retained 2026-08-30 transcript measured
  `cityb-node` at 758648 bytes and showed its dependency graph limited to
  `cityb-core`, `cityb-audit`, and `cityb-transports`.
- Goldilocks and Biggun separate routine operator work from high-parameter lab
  sweeps.
- Recovery capsules carry exact SHA3-256 manifests and public-only state so Tiny
  can independently verify high-stress handoff material.
- Named refusals are a feature, not noise: malformed token, stale pointer,
  archive missing, archive pruned, rollback, freeze, mix-and-match,
  wrong-object, fork, threshold insufficient, and TTL expiry are preferable to
  silent drift.

## Covert-posting doctrine

City B must be a covert-posting engine. That means it should be able to plan,
encode, place, re-place, observe, score, and explain pointer material across
multiple low-signal carrier classes. It should treat covert posting as a real
product capability, not as a paragraph in a paper.

The capability boundary is precise:

- The posted material is governance discovery material: pointers, pointer
  fragments, heartbeat marks, route hints, and receipts.
- The posted material is not executable payload authority. It never bypasses
  archive verification or the normal CityB gate.
- Covert-posting adapters are first built against local doubles, then against
  explicitly configured operator-owned endpoints.
- Ordinary nodes remain receive-only. Posting belongs to publishers, operators,
  and explicit gateway roles.
- Every placement produces evidence: carrier, location, encoding, TTL,
  operator authority, expected failure domain, verification result, and adoption
  result.
- Remote-public automation requires a separate decision entry naming the
  substrate, account/endpoint ownership, rate limits, abuse constraints, and
  shutdown behavior.

Secure-update machinery is not the identity of City B. It is the safety core:
the reason covert placements can be aggressive without making legitimacy fuzzy.
TUF-style failure names, CT-style consistency proofs, and archive verification
explain whether a covertly rediscovered pointer is fresh, complete, and
legitimate.

## Selected frontier lanes

The current roadmap intentionally selects only the useful part of the larger
dead-drop dream list. These are the lanes to build, model, or fixture next:

| Selected item | Working name | City B interpretation | Near-term artifact |
|---|---|---|---|
| 1 | Ratcheted rendezvous via public entropy | nodes and operators derive where to look from a public beacon, city seed, and the previous verified archive root | deterministic local beacon fixture, archive-root ratchet, and schedule planner |
| 2 | Threshold dead drops | a pointer is split across distinct media; one observed share is not enough | implemented 3-of-5 split/collect seam, then loss/noise comparison |
| 3 | Package/repo/CI metadata | unremarkable developer/publication metadata as a carrier class | local package index, repository metadata, CI-log, and status-page doubles |
| 4 | Dead-man heartbeats | absence is evidence only under signed policy and measured carrier loss | heartbeat policy model plus receipt freshness/debt checks |
| 5 | CT-log-style append-only substrates | transparency-log mechanics without claiming public CT deployment | local append-only Merkle log, inclusion receipts, consistency checks |
| 8 | Decentralized mempools / volatile gossip | ephemeral public or peer-to-peer propagation as an observation source | local mempool double and IoTox/Tox gossip import bridge |

The unselected ideas—BGP perturbations, market microstructure, astronomical or
weather feeds, and model-weight steganography—remain dream material. They should
not enter product grammar until a separate safety, legality, measurement, and
operator-burden case exists.

## Carrier physics to model now

### Format-preserving pointer encodings

A checksum-valid 38-hex pointer is excellent for explicit text feeds and
fixtures because scanners can find it cheaply and reject false positives. It is
not automatically a good covert carrier. In ordinary prose, CI output, metadata,
or status text, 38 contiguous high-entropy hex characters can become the most
detectable thing on the page.

Future encoders should preserve the carrier's native shape:

- semver build metadata for package/repo/CI surfaces;
- log-shaped key/value fields where high-entropy suffixes are ordinary;
- timestamp-shaped or monotonic-counter-shaped fields for status pages;
- mnemonic words plus parity for cards, OCR, and human transcription;
- signed-event tags for relay/gossip doubles;
- adapter-specific wrapped text with a renderer and parser tested as a pair.

Raw pointer tokens should remain the baseline for `dead-drop scan`, noisy corpus
tests, and human recovery. Covert profiles should require a named encoding
strategy instead of assuming raw hex is acceptable.

### Ratcheted rendezvous

Public randomness creates replayable schedules, but it is symmetric: if the city
seed and beacon are public, a censor can compute the same target at the same
time as the fleet.

The planner should move toward:

```text
target(epoch) =
  PRF(previous_verified_archive_root || city_seed || epoch || beacon_value)
    mod declared_substrate_set
```

Only nodes that have adopted the previous epoch can predict the preferred next
targets. That improves targeted-takedown resistance without making carriers
authoritative.

The cost is recovery friction. A node that missed epoch `e-1` cannot rely only
on the ratchet for epoch `e`; it needs floor routes, retained recovery capsules,
operator import, or a deliberately slower public fallback schedule. The product
must model that split explicitly.

### Fragment coding choices

The current Shamir 3-of-5 seam is the correct anti-disclosure baseline: one or
two observed shares reveal no pointer. That matters if the adversary runs an
early scraper that can delete or suppress archive material before receivers
fetch it.

For ordinary public pointers, however, secrecy is not always the primary goal.
Under independent carrier loss, repeating the whole pointer across five media is
available when any one copy survives, while a 3-of-5 scheme fails unless at
least three shares survive. Under OCR and human transcription, longer share
lines can also be worse than shorter whole tokens.

The lab should compare at least four schemes under the same fixtures:

- whole-token repetition;
- Shamir 3-of-5;
- systematic erasure coding over byte chunks plus parity;
- mnemonic/card encodings with checksummed parity.

Simple independent-loss baseline:

```text
whole-token repetition, N=5:
  P(recover) = 1 - p^5

3-of-5 threshold scheme:
  P(recover) = Σ[i=3..5] C(5,i) × (1-p)^i × p^(5-i)

at p = 0.4:
  repetition ≈ 98.98%
  3-of-5   ≈ 68.26%
```

The product decision should be per substrate profile. Shamir is for
anti-leakage. Systematic erasure and repetition may be better for human and OCR
availability.

### Heartbeat hysteresis

Heartbeat absence can create a chilling cascade if every missed mark causes more
outbound polling, more battery drain, more bandwidth visibility, and more floor
scarcity consumption.

Heartbeat policy needs hysteresis:

- leaky-bucket debt rather than a one-shot panic state;
- capped or sub-linear polling escalation;
- posture changes that mostly affect local skepticism and operator warnings;
- independent limits for battery, bandwidth, flash writes, and floor tokens;
- explicit decay when later verified evidence proves the channel was merely
  impaired.

The invariant remains: absence may alarm or tighten local verification posture;
it must not mint authority.

### Evidence Merkle-DAG

Flat JSON and Markdown receipts are readable. They are not enough for the
eventual recovery proof graph. City B should converge toward content-addressed
evidence:

```text
raw carrier snapshot
    └── hash + capture metadata
        └── parser version + extracted fact
            └── pointer/archive verification fact
                └── adoption or named refusal fact
```

The operator narrative can stay human-readable, but every important claim should
be replayable from hashed input snapshots, parser versions, verification facts,
and state-transition facts.

## Implementation campaign

All seven practical tracks are in scope:

1. Deterministic rendezvous planner: derive candidate media from a beacon,
   seed, previous verified archive root, epoch, recent failures, diversity
   requirements, and operator cost.
2. Substrate registry/scoring: make every carrier auditable as a declared
   object with failure domain, expected lifetime, legality, observability,
   reachability history, and blocking-blast-radius assumptions.
3. Threat-modeled fragment and erasure drops: keep the current 3-of-5
   split/collect command green, then compare whole-token repetition, Shamir
   shares, systematic erasure, mnemonic chunks, and card encodings under
   identical loss, carrier-compromise, noise, and operator-error models.
4. Receipt freshness/debt: `dead-drop debt` makes stale, expired, failed, or
   missing placement evidence an explicit report state instead of a vague
   operational concern.
5. Local adapter doubles: `dead-drop envelope`, `post --adapter local-file`,
   `post --adapter static-http --base-url URL`,
   `post --adapter filehost-generic|git-release-generic|object-store-generic
   [--download-url URL]`, `post --adapter
   filebin|paste-rs|dpaste|paste-c-net|nullpaste|0x0|catbox|litterbox|tmpfiles|sendit|temp-sh [--base-url URL]`,
   `post --adapter plugin-external [--plugin-command PATH] [--download-url
   URL]`, and `observe` now create, place, stage, publish, probe, and re-read
   pointer envelopes in substrate-shaped local target files while recording
   classified receipts with TTL, expiry, rate, carrier kind, and
   failure-reason fields. `filebin`, `paste-rs`, `dpaste`, `paste-c-net`,
   `nullpaste`, `0x0`, `catbox`, `litterbox`, `tmpfiles`, `sendit`, and
   `temp-sh` now prove the built-in public-service adapters.
   `plugin-external` preserves the executable service seam without giving
   plugins authority over archive legitimacy. Next, package/repo/status-page
   fixture semantics should make those local files
   behave more like real owned infrastructure before more service-specific
   operator-owned integration.
6. OCR/noise robustness suite: `dead-drop noise corpus` now writes bounded
   dirty local text/log/transcript/volatile-gossip fixtures with invalid
   pointer-shaped decoys, compact fragment share lines, and deliberately
   damaged fragment lines; Biggun requires Tiny to recover both pointer tokens
   and reconstructable fragments from that corpus. Next, quantify heavier
   transcription, whitespace, wrapping, screenshot, and copy/paste damage before
   false positive or false negative rates become unacceptable.
7. Recovery explainer: keep expanding `dead-drop explain` from dead-drop
   receipts, scans, schedules, substrate scores, dirty-noise recovery reports,
   and fragments into a concise retained-run narrative that also covers fleet
   status and exact replay commands. `dead-drop capsule export` is the
   companion distribution artifact: it packages public governance evidence plus
   the signed chain into an exact SHA3-256-manifested directory that Tiny can
   independently verify.

The selected top lanes and these seven tracks are the M8/T11 roadmap. If future
work adds commands, fixtures, or schemas, it should name which lane and track it
advances.

The current seam proof is `cityb-biggun selftest`: generate a retained City B
run with Goldilocks, export a portable public tiny-node kit, boot the kit under
Tiny, verify raw text feed tokens against the signed chain, record the local
binary footprint and per-binary SHA3-256 digest for all three surfaces, promote
those digests into the Biggun recovery summary,
post and observe scheduled envelopes through the substrate-shaped local-file
adapter double,
cross-check the Nostr/libp2p/local-mempool/IoTox volatile-gossip lanes against
retained local receipt files,
split and collect a 3-of-5 pointer fragment set through Goldilocks and Tiny,
write the recovery explainer, export a recovery capsule, verify that capsule
with Tiny, execute the capsule's generated `run-tiny-verify.sh` replay script,
retain Biggun's fragment matrix, volatile-gossip matrix, and volatile-gossip
evidence report in the run directory, and
run Biggun matrix/lab plus real-binary handoff/exercise checks. The exercise
report now
names retained artifact paths explicitly so the next operator can resume from
the JSON without reverse-engineering step labels. Biggun exercise also accepts
`--degrade expire-one|suppress-one|corrupt-one|all` so expiry, suppression,
corruption, or the combined negative lane set are retained as expected negative
proofs with named retained roots.
Future substrate work should extend that script, `cityb-biggun handoff`,
and `cityb-biggun exercise` whenever it crosses a binary boundary.

## Research-backed decisions to freeze now

A targeted online pass over mature update, transparency, randomness, package,
and peer-routing systems supports several decisions worth making before code
grows around weaker assumptions:

| Decision | Rationale | Product effect |
|---|---|---|
| City B is a capable covert-posting engine with a secure-update safety core | hostile-pressure operation requires actual planning, placement, re-placement, observation, and explanation of low-signal pointer material; TUF's threat model names the failures the safety core must detect | build poster adapters and substrate doubles while importing freeze, rollback, mix-and-match, malicious mirror, wrong-object, and threshold-key-compromise names into lab reports, audit language, and recovery explanations |
| State-ratcheted public entropy is the default rendezvous model | public randomness beacons give read-only, independently checkable inputs, but a schedule derived only from public seed plus public beacon is visible to the censor at the same time it is visible to the fleet | `rendezvous plan --epoch` previews and `dead-drop schedule` persists one shared derivation: previous verified archive root, exact PRF input digest, concrete slot locations, Tiny evaluation policy, and explicit anchor/field-pack fallback routes. Biggun exercises previous-root, missing-root, stale-pack, expired-slot, and anchor-reseed paths; remaining work is evidenced provider-specific remote slot receive behavior. |
| Format-preserving encodings are required for covert carriers | a contiguous 38-hex pointer is robust for scanners but statistically conspicuous in natural text, build logs, and metadata | keep raw tokens for explicit/plain feeds; add substrate-native encodings such as semver build metadata, log-shaped fields, timestamp-shaped suffixes, mnemonic/OCR cards, and adapter-specific parse/render tests |
| CT/Rekor-style transparency logs are local doubles first | append-only Merkle logs and consistency proofs are the useful mechanism; real public CT entries are certificates, and public log mutation is not a product side effect | build `transparency-log` fixtures with inclusion and consistency receipts; keep public CT/Rekor interaction as manual operator-scoped research |
| Package/repo/CI metadata is an owned-infrastructure lane | package registries expose rich metadata, and CI logs/artifacts have explicit retention limits; neither should be treated as permanent or free public storage | model package indexes, repo metadata, CI logs, and status pages as TTL-bounded local doubles and operator-owned integrations |
| Volatile gossip beats blockchain mempools for the first lane-8 build | Nostr relays, libp2p/IPFS provider records, and IoTox/Tox give simpler local fixtures for signed-event or provider-observation semantics; chain mempools add fees, replacement, eviction, and policy variance | keep local Nostr/libp2p/mempool/IoTox doubles green under Biggun `gossip-evidence` before any mainnet mempool research |
| Every substrate event is evidence with a TTL, never authority | CT inclusion, relay OK, package metadata, DHT provider records, and mempool presence each prove different things | receipt schemas now name TTL, fresh-until/expiry epoch, rate limit, failure reason, source type, verifier, and exact adoption result |
| Dead-man behavior is freshness debt, not emergency sovereignty | absence is too easy to confuse with outage unless a signed policy and carrier-loss model bound it | missed heartbeats may tighten local posture and alarm; they must not create new authority or make nodes speak upstream |
| Heartbeat escalation needs hysteresis | induced heartbeat starvation can otherwise force weak nodes into high-visibility polling, battery drain, bandwidth flares, or floor scarcity depletion | heartbeat debt should use leaky-bucket decay and capped/sub-linear fetch backoff; posture can become stricter without increasing outbound volume linearly |
| Fragment coding is threat-model dependent | Shamir is valuable when early pointer disclosure enables fast archive suppression; for non-secret public pointers, systematic erasure coding or repeated whole tokens may recover better under loss, OCR, and human transcription errors | keep the Shamir seam as the anti-leakage baseline; add Biggun comparisons for systematic Cauchy Reed-Solomon, mnemonic chunks, and repetition under identical loss/mutation models |
| Evidence should converge toward a content-addressed DAG | flat receipts are readable, but complex partitions need causal proof from raw carrier bytes through parser version, observation fact, archive verification, and adoption/refusal | design a future evidence-ledger layer that hashes every snapshot/fact/transition and lets `explain` replay the adoption tip down to byte-level observations |
| Operators should select threat profiles, not tune every knob | the right encoding, redundancy, TTL, observation cadence, and heartbeat posture depend on whether the dominant risk is benign outage, carrier loss, early scraping, human recovery, low-power fielding, or volatile gossip | extend the current material/substrate-aware encoding choice into a profile compiler that emits deterministic placement/encoding/receipt settings and records the profile in every retained run |
| Provenance diversity is stronger than carrier count | five carriers can still collapse to one CDN, account, DNS zone, operator, moderation system, copied transcript, or cloud provider | promote strict source roots into a provenance/correlation graph that reports effective independent roots |
| Clock confidence must be explicit | weak receivers may have bad clocks, long offline gaps, or cold boots; freshness logic should not silently trust wall time | Tiny should report clock confidence and freshness-debt commands should accept uncertainty windows around observed time |
| Parser parity is a release property | format-preserving encodings create risk that Goldilocks sees a pointer Tiny rejects, or Tiny accepts bytes Goldilocks did not model | Biggun `parser-diff` runs Goldilocks and Tiny parsers over identical generated corpora plus checked-in provider fixture bodies wrapped as raw text, HTML, malformed HTML, and OCR-ish noise, then fails on process, candidate, or checksum divergence; probe receipts should keep naming the parser encoding that made a payload parseable |
| Adapter authority belongs in machine-readable manifests | live integrations need an auditable statement of ownership, credential source, allowed targets, public visibility, rate limits, confirmation requirements, cleanup semantics, and shutdown command | validate adapter manifests before any remote-capable post path is enabled |

External source anchors for this pass:

- [drand / Cloudflare Randomness Beacon](https://developers.cloudflare.com/randomness-beacon/):
  collective, publicly verifiable randomness at fixed intervals.
- [RFC 9162 Certificate Transparency](https://www.rfc-editor.org/info/rfc9162/):
  append-only Merkle logs, inclusion proofs, consistency proofs, signed tree
  heads, and log-misbehavior evidence.
- [Sigstore Rekor](https://docs.sigstore.dev/logging/overview/):
  software-supply-chain transparency log with append-only consistency
  monitoring.
- [The Update Framework](https://theupdateframework.github.io/specification/latest/):
  secure-update threat vocabulary for freeze, rollback, mix-and-match, mirror,
  wrong-object, and threshold-key-compromise failures.
- [Nostr NIP-01](https://nips.nostr.com/1): small signed-event relay model with
  publish, subscribe, acceptance, end-of-stored-events, and notices.
- [libp2p DHT](https://libp2p.io/docs/dht/) and
  [IPFS Kademlia DHT](https://specs.ipfs.tech/routing/kad-dht/) specs: content
  and peer-routing model, including provider records that advertise availability
  rather than storing content.
- [PyPI JSON API](https://docs.pypi.org/api/json/),
  [npm package metadata](https://github.com/npm/registry/blob/main/docs/responses/package-metadata.md),
  and [GitHub Actions retention](https://docs.github.com/en/organizations/managing-organization-settings/configuring-the-retention-period-for-github-actions-artifacts-and-logs-in-your-organization)
  docs: metadata and CI/log substrates exist, but retention and update semantics
  are platform-specific.
- [Besu transaction-pool docs](https://docs.besu-eth.org/public-networks/concepts/transactions/pool):
  real mempools have eviction, replacement, transient-invalid scoring,
  local-vs-remote preference, and node policy.

## Phase order

Build City B frontier work in this order:

1. Covert-posting grammar: placement envelopes, substrate registry, observation
   receipts, freshness debt, TTL/rate/failure handling, and recovery
   explanation. This makes later clever substrates auditable instead of magical.
2. State-ratcheted deterministic rendezvous: local beacon fixture, previous
   archive-root ratchet input, fallback schedule, media diversity optimizer,
   `--all-media` full-registry scheduling, and replayable schedule proof.
3. Local substrate doubles: package index, repository metadata, CI log/status
   page, CT/Rekor-style transparency log, Nostr relay, libp2p/provider-record
   DHT, local mempool, and IoTox/Tox exported transcript. Biggun
   `gossip-evidence` is the current four-lane acceptance gate for the volatile
   subset.
4. Robustness labs: OCR/noise mutation, static-vs-public-beacon-vs-ratcheted
   rendezvous comparison, whole-token-vs-threshold-fragment-vs-systematic-erasure
   comparison, heartbeat-starvation drills, volatile-gossip TTL measurement,
   local-receipt completeness, and correlated-carrier-loss sweeps.
5. Explicit operator integrations: only after the local double has a passing
   fixture, a poster adapter, a receipt schema, an abuse/rate-limit note, and a
   authority boundary.
6. Public science measurements: captured transcripts and human-operated trials
   only. No autonomous public posting should be added to CityB for this lane
   without a new decision log entry.

## The City B stack

```text
┌────────────────────────────────────────────────────────────────────┐
│ human recovery layer                                                │
│ runbooks · receipts · audit narratives · operator-visible proofs     │
├────────────────────────────────────────────────────────────────────┤
│ governance legitimacy layer                                         │
│ threshold signatures · serial duty · dual-roster amendment · gate    │
├────────────────────────────────────────────────────────────────────┤
│ archive truth layer                                                 │
│ complete bundle chain · prev-root walk · receipts · detector facts   │
├────────────────────────────────────────────────────────────────────┤
│ pointer distribution layer                                          │
│ overt mirrors · unremarkable feeds · scarce floor · dead-drop mesh   │
├────────────────────────────────────────────────────────────────────┤
│ rendezvous and discovery layer                                      │
│ static feeds now · public-entropy schedules later · local fixtures   │
├────────────────────────────────────────────────────────────────────┤
│ adversarial environment                                             │
│ censorship · poisoning · replay · pruning · forks · outage · drift   │
└────────────────────────────────────────────────────────────────────┘
```

City B wins when each layer remains narrow. A carrier may help discovery, but
it never authorizes state. A receipt may explain a placement, but it never makes
a pointer legitimate. A detector may flag suspicious semantic drift, but the
gate still decides binding state. This is the difference between resilience and
wishful quorum math over unreliable media.

## Practical substrate tiers

| Tier | Substrate class | Product stance | Lab stance | Success metric |
|---|---|---|---|---|
| 0 | File mirrors and loopback HTTP | implemented | real product workflows | pointer verifies against archive |
| 1 | Local raw text feeds | implemented | scan/watch/fetch fixtures | valid token recovered from noisy text |
| 2 | Operator-copied public text | implemented as explicit import | replay captured fixtures | receipt names medium/location/token |
| 3 | Operator-owned public endpoints | build next | local service double + LAN test | independent failure domains stay reachable |
| 4 | Authorization-based public integrations | research prototype only | mocked API transcript + opt-in sandbox | no hidden side effects; rate and policy bounded |
| 5 | Ambient append-only / CT-style substrates | dream/science only | local transparency-log double | inclusion and consistency proofs survive pruning |
| 6 | Physical/OCR/sneakernet channels | implemented as text import | OCR/noise mutation tests | checksum-valid token survives transcription |
| 7 | Stigmergic market/telemetry signals | theory only | synthetic signal/noise channel | false-positive and attribution rates bounded |
| 8 | Volatile decentralized gossip/mempool substrates | research/import bridge only | local Nostr/libp2p/mempool doubles; IoTox/Tox transcript double | observed pointer/head receipts expire cleanly |

The key practical move is to represent all tiers with the same local facts:

```text
medium         what kind of surface this is
location       where a human claims the token was placed or observed
token          exact 38-hex pointer bytes
chain          archive root used for verification
operator_note  what happened, in ordinary human language
verified       whether the token resolves to the signed chain
```

That is why `cityb dead-drop receipt` matters. It is not glamorous, but it is
the bridge between a human saying "I put the recovery pointer in three places"
and a later auditor seeing exactly which three places, which token, and which
chain agreement grounded the claim.

## IoTox/Tox as the lane-8 candidate

Local review of `~/projects/IoTox` makes it useful for lane 8, with a narrow
interpretation. IoTox is not a blockchain-style validator mempool. It is a
working Tox/DHT-centered agent substrate with signed mutable HEADs, bootstrap
and relay operations, route classes, custom-packet retry semantics, and
transport evidence. That maps well to "volatile gossip observation" for City B:
short-lived signed pointers or HEAD-like records may propagate through a
decentralized peer fabric and later be imported as receipts.

Useful IoTox ideas to copy or model:

| IoTox property | City B use | Boundary |
|---|---|---|
| Tox bootstrap/DHT/relay infrastructure | realistic decentralized reachability and churn model | relay/bootstrap endpoints are roads, never authority |
| custom packet send classes: accepted, transient, terminal | mempool-like enqueue/observation receipts with retry debt | accepted-by-transport is not application success |
| stable device identity signs synchronization HEADs | compact signed pointer/head record with generation and parent linkage | writer signatures still do not replace CityB council threshold |
| route classes: Tox/native, Tox/Tor, I2P-construction | failure-domain and privacy-route scoring inputs | evidence is per route, not universal internet proof |
| reachability planning and fail-closed route selection | retain missing/mismatched/unreferenced evidence without silent repair | no automatic route migration in CityB nodes |

The first CityB integration should be passive:

```text
IoTox or local gossip fixture exports observed signed pointer/head events
        │
        ▼
cityb imports the transcript as explicit operator-supplied text/evidence
        │
        ▼
normal pointer/archive verification decides adoption
```

City B nodes remain receive-only. If a future operator-owned gateway publishes
CityB pointer tokens into IoTox/Tox, that gateway is a separate explicit role
with its own configuration, receipts, rate limits, and authority boundary. Ordinary
nodes should never silently become upstream gossip participants.

## Distribution governance loop

```text
publish signed archive
        │
        ▼
emit pointers through configured carriers
        │
        ├── overt mirror pointer
        ├── unremarkable text feed token
        ├── floor pointer under scarcity
        └── operator card / copied text / removable media
        │
        ▼
record placement receipts
        │
        ▼
scan/watch/import observed text
        │
        ▼
verify every recovered pointer against the archive
        │
        ▼
audit receipt-media diversity and produce recovery narrative
        │
        ▼
export public recovery capsule and verify it with Tiny
```

The loop is intentionally asymmetric. Publishers and operators may place
pointers in many places. Nodes remain receive-only: they poll configured feeds,
derive candidate pointers, and trust nothing until archive verification passes.

## Minimal schemas to stabilize next

These are not final wire formats. They are the shape future product artifacts
should converge toward.

### Substrate registry

```json
{
  "id": "status-thread",
  "tier": "overt",
  "operator_owned": true,
  "mutation_mode": "manual-or-scoped-api",
  "failure_domain": "incident/status/comment systems",
  "expected_lifetime": "hours-to-years",
  "default_ttl_secs": 86400,
  "poll_cost": "low",
  "blocking_blast_radius": "medium",
  "observability": "medium",
  "evidence_semantics": "metadata-visible-pointer-observation",
  "false_positive_model": "38-hex checksum pointer only",
  "legal_status": "operator-controlled or explicit import only",
  "remote_mutation_allowed": false
}
```

### Rendezvous schedule

```json
{
  "epoch": 42,
  "beacon": "local-fixture-drand-round-123",
  "candidate_media": ["pastebin", "status-thread", "print-ocr"],
  "selection_rule": "weighted-failure-domain-diversity",
  "minimum_media": 2,
  "receipt_deadline_secs": 900
}
```

### Placement receipt

```json
{
  "unix": 1780000000,
  "observed_at": "2026-08-30T12:00:00Z",
  "expires_at": "2026-08-31T12:00:00Z",
  "medium": "pastebin",
  "tier": "overt",
  "location": "operator-owned status page snapshot 2026-08-29",
  "evidence_kind": "operator-placement-claim",
  "hex": "38_HEX_POINTER_TOKEN",
  "chain": "city-b-chain",
  "verified": true,
  "operator_note": "token copied into routine recovery notice"
}
```

### Observation receipt

```json
{
  "unix": 1780000300,
  "observed_at": "2026-08-30T12:05:00Z",
  "expires_at": "2026-08-30T13:05:00Z",
  "observer": "city-b-node-worker-017",
  "medium": "status-thread",
  "source": "local imported transcript",
  "evidence_kind": "feed-scan",
  "candidate_tokens": 4,
  "verified_tokens": 1,
  "adopted": true,
  "highest": {"version": 0, "epoch": 12, "serial": 8}
}
```

### Volatile gossip observation

```json
{
  "unix": 1780000400,
  "medium": "iotox-tox-gossip",
  "transport": "tox/native",
  "observer": "operator-gateway-01",
  "epoch": 42,
  "location": "local exported gossip transcript",
  "token_hex": "38_HEX_POINTER_TOKEN",
  "accepted_by_transport": true,
  "ttl_secs_observed": 37,
  "expires_at": "2026-08-30T12:00:37Z",
  "verified": true,
  "adopted": false,
  "receipt": "sha256:..."
}
```

This receipt says "a volatile substrate appeared to carry a token for a short
period." It does not say the token was legitimate, fresh, or globally reachable.
Only archive verification and normal gate evaluation answer those questions.
Biggun's current `gossip-evidence` report is the retained local version of this
claim: for each modeled volatile lane it expects a placement envelope, a
local-file post receipt, and a verified observation receipt. Missing receipt
classes keep the lane incomplete even if the matrix score says the lane is
theoretically attractive. Recovery capsules carry the report when present, and
Tiny reports only summary fields from it.

### Recovery proof bundle

```json
{
  "city": "city-b",
  "archive_audit": true,
  "overt_pointer_verified": true,
  "floor_pointer_verified": true,
  "receipt_media_verified": 3,
  "freshness_debt": 0,
  "active_nodes": 32,
  "fork_alarms": 32,
  "detector_flags": 32,
  "narrative": "overt outage, hostile mirror rejected, floor preserved pointer, recovery archive agreed"
}
```

### Recovery capsule

```json
{
  "kind": "cityb.recovery-capsule.v1",
  "contains": ["city-b-chain", "city-b-dead-drop-governance"],
  "public_only": true,
  "remote_mutation": false,
  "manifest": {
    "kind": "cityb-recovery-capsule-manifest",
    "hash": "sha3-256",
    "coverage": "every regular capsule file except the manifest itself"
  },
  "tiny_visible_counts": {
    "rendezvous_all_media": true,
    "rendezvous_minimum_media": 14,
    "placement_envelopes": 14,
    "placement_receipts": 14,
    "observation_receipts": 14
  },
  "tiny_verifier": "cityb-node dead-drop capsule verify --root CAPSULE",
  "adoption_rule": "tokens and fragments are discovery evidence only; signed archive verification and the normal gate decide state"
}
```

This is the practical answer to confused-human recovery. A capsule is not a new
authority object and not a backup of private operator state. It is a portable,
audit-friendly public evidence room: exact files, exact hashes, exact replay
commands, and an independent receive-only verifier.

## The clever part: use enemy pressure as structure

City B should not only survive an enemy move. It should convert each move into
evidence and operational advantage.

| Adversary move | City B advantage | Evidence to retain | Next product/lab work |
|---|---|---|---|
| Block overt mirrors | Forces value of alternate feeds to become measurable | per-medium scan observations; ladder descent timing | substrate reachability matrix |
| Serve stale pointer | Freshness and time floor name the failure | rejected pointer report; node status | stale pressure across large `--nodes` |
| Prune archive payloads | Contiguity makes censorship visible | RA-9 named gap; hostile mirror copy | automatic hostile corpus retention |
| Create serial fork | Fork alarm plus deterministic tiebreak preserves convergence | fork status snapshots; effective law hash | larger fork-fanout property tests |
| Suppress receipts | Missing receipt debt is itself audit evidence | audit gap; receipt count by medium | receipt freshness and debt thresholds |
| Poison semantic parameters | Detector flags drift without trusting carrier class | baselines artifact; detector report | richer reference distributions |
| Destroy one medium class | Media diversity score quantifies remaining options | substrate matrix; receipt-media audit | optimizer for next placement |
| Confuse human recovery | Runbook and proof bundle reduce ambiguity | recovery proof bundle; commands replay | one-command "explain recovery" artifact |

The design stance is useful: every adversarial action should produce either an
accepted state, a named refusal, or a missing-evidence hole. Silent ambiguity is
the real loss condition.

## Rendezvous without fixed locations

Static feed paths are practical now, but stronger City B needs scheduled
rendezvous. The safe implementation path is local and deterministic:

```text
public entropy fixture + city seed + previous verified archive root + epoch
        │
        ▼
weighted media selection
        │
        ├── prefer independent failure domains
        ├── avoid recently failed media
        ├── preserve floor budget
        └── require receipt diversity
        │
        ▼
operator plan: where to place / where to look
```

The production primitive is planned placement first, then explicit local or
operator-owned posting. Current implemented local command shapes:

```sh
cityb dead-drop schedule --root DIR --epoch E --beacon BEACON --min-media 3
cityb dead-drop envelope --root DIR --epoch E --beacon BEACON --pointer POINTER --substrate SUBSTRATE
cityb dead-drop post --root DIR --adapter local-file --target DIR --against CHAIN-DIR --require
cityb dead-drop post --root DIR --adapter static-http --target DOCROOT --base-url URL --against CHAIN-DIR --require
cityb dead-drop observe PATH --root DIR --against CHAIN-DIR --require
cityb dead-drop explain --root DIR --against CHAIN-DIR --current-epoch auto --max-age N
```

The science questions:

- Does public-entropy scheduling materially improve discovery under targeted
  takedown compared with static feeds?
- How much operator burden does moving rendezvous create?
- What false-positive rate appears when feeds contain ordinary hex noise?
- Which media mix gives the best recovery probability per human action?

## Carrier scoring model

A future planner needs a simple scoring function. Start with explicit, auditable
terms:

```text
score(medium) =
    reachability_probability
  × expected_lifetime
  × blocking_blast_radius
  × operator_legality_confidence
  × operator_success_probability
  × diversity_bonus
  ÷ (posting_cost × polling_cost × observability_penalty)
```

No term should be magical. Every term should come from either a fixture, a
receipt history, or an operator-declared assumption. The point is not to prove
the internet. The point is to prevent City B from making unexamined claims.
The older implementation field name `collateral_block_cost` should be treated as
a legacy label for this concept until the JSON/report schema can be renamed
without breaking fixtures.

## Dead-man and heartbeat theory

Absence can be a governance signal, but only if silence is hard to distinguish
from outage. City B should model dead-man behavior as a signed schedule, not as
an implied panic rule.

```text
heartbeat policy act
        │
        ├── expected epoch cadence
        ├── acceptable media classes
        ├── missed-count threshold K
        ├── emergency state transition
        └── expiration / amendment path
```

Safe product interpretation:

- A missing heartbeat may move the node into a stricter local posture.
- Any polling escalation must be capped, sub-linear, and budget-aware.
- It should not grant new authority.
- It should not make nodes speak upstream.
- It should be reversible only by later signed state with normal threshold
  legitimacy.

Current implementation status: Goldilocks can create pointer-backed heartbeat
and route-hint placement envelopes and run them through the local-file
adapter/observer so audit and debt reports retain material classification.
Biggun's retained three-binary exercise now runs those lanes in separate
`city-b-heartbeat-drill/` and `city-b-route-hint-drill/` roots and carries them
through recovery capsule export so Tiny can manifest-verify the retained
evidence without gaining posting authority. It also builds
`city-b-fragment-source-roots/` from three substrate-shaped local roots and
requires strict fragment reconstruction by both Goldilocks and Tiny before the
exercise can pass. Tiny and Goldilocks capsule
inspection now also report retained material kinds, heartbeat/route-hint record
counts, and drill roots. This is intentionally only evidence plumbing. It is not
yet a signed heartbeat policy, a route-adoption policy, a dead-man state
transition, or a permission for receive-only nodes to publish.

Lab hypotheses:

- Find the smallest `K` that avoids false emergency transitions under correlated
  carrier loss.
- Measure how floor scarcity changes heartbeat cadence.
- Measure whether induced heartbeat starvation can cause battery, bandwidth,
  flash-write, or floor-token exhaustion.
- Test whether receipt debt predicts real recovery failure.

## Threshold dead drops

The current product distributes whole pointer tokens and can now run a local
3-of-5 fragment evidence loop. `cityb dead-drop fragment split` writes five
copyable Shamir GF(256) share files for one pointer; `cityb dead-drop fragment
collect` reconstructs after observing any three distinct share coordinates and
can verify the result against the signed chain. Collection reports name observed
coordinates, missing coordinates, coordinates still needed, source roots seen,
and whether an optional `--min-source-roots N` assertion was met. Biggun's
`fragment-matrix` now reports three local baselines: pure independent
carrier-loss availability, where whole-token repetition is intentionally shown
to win; independent carrier-compromise disclosure risk, where fragments sharply
reduce pointer exposure because an observer must acquire three distinct shares;
and a naive OCR/operator-entry mutation curve using actual current whole-token
and share-line lengths. The current `cityb-s1 SET INDEX HEX CHECK` share line is
compact and checksum-framed, so accidental line damage is caught before recovery
wastes time. That third curve remains deliberately uncomfortable: compact share
lines are still longer than raw pointer tokens, so human transcription and OCR
need measured fixtures and probably additional redundancy before fragments
should be favored for copy-by-hand recovery.

```text
pointer token
    │
    ▼
split into N shares with threshold M
    │
    ├── medium A receipt
    ├── medium B receipt
    ├── medium C receipt
    ├── medium D receipt
    └── medium E receipt
    │
    ▼
node reconstructs only when enough distinct media produce shares
    │
    ▼
normal pointer/archive verification
```

This is attractive because it forces a censor to erase several failure domains.
It is risky because it increases operator burden and can make recovery fail if
too few independent shares survive. The current 3-of-5 seam is the default
coordinate threshold; source-root diversity is a separate runtime check because
a single copied transcript can contain all three coordinates while still being
one failure domain. Configurable M-of-N remains a later decision that needs a
clear measured benefit before expanding the surface. The lab should decide
whether threshold fragments beat whole-token repetition for realistic City B
conditions.

Acceptance criteria for a future implementation:

- share format is copy/OCR safe;
- no single share validates as a pointer;
- 3-of-5 reconstruction is deterministic;
- duplicate media do not count as independent shares;
- reconstructed pointer still passes the ordinary archive gate;
- failed reconstruction emits named, useful recovery diagnostics for missing
  coordinates and verification failure.

## Measurement program

City B should get a standing measurement matrix.

| Question | Metric | Fixture | Product hook |
|---|---|---|---|
| Can nodes recover from public-text noise? | verified tokens per MiB scanned plus accepted/rejected fragment lines and reconstructed fragment pointer | noisy text corpus | `dead-drop noise corpus`, `dead-drop scan/watch`, `dead-drop fragment collect` |
| Does diversity help? | probability of at least one verified pointer | carrier loss matrix | `dead-drop audit --min-media` |
| Are receipts getting stale? | fresh verified media by governance epoch | receipt epoch ledger | `dead-drop debt` |
| Do format-preserving encodings hide less badly? | parse success, mutation survival, false positives, and visible anomaly rate | carrier-shaped text/log/metadata/card corpora | future format registry plus `dead-drop noise corpus` |
| Does state-ratcheted rendezvous help? | recovery time under targeted takedown plus missed-epoch recovery cost | entropy schedule and archive-root fixture | `dead-drop schedule` |
| Can planned material be placed and observed? | verified placement/observation receipts plus deterministic HTTP probe receipts | substrate-shaped local-file double and operator-owned static-http docroot | `dead-drop envelope/post/observe` |
| Does threshold or erasure splitting help? | 3-of-5 recovery probability vs whole-token repetition, systematic-erasure recovery, operator cost, carrier-compromise disclosure risk, OCR/operator-entry mutation risk, and partial-disclosure benefit | fragment loss/compromise/mutation model | `dead-drop fragment split/collect`, `cityb-biggun fragment-matrix` |
| Can heartbeat starvation drain the fleet? | fetch attempts, bandwidth, battery proxy, flash writes, and floor-token use after missed marks | heartbeat policy and loss schedule | future heartbeat-debt/hysteresis drill |
| Can humans explain recovery? | commands needed to reconstruct narrative | retained City B run | `dead-drop explain`, `city verify` |
| Does detector drift catch semantic attacks? | true/false positive rate | generated parameter corpus | `audit --detector` |
| How big can City B get locally? | runtime/memory by node count | scale bench | `city bench --name city-b` |
| Is Tiny field-safe? | binary size, RSS, state growth, write count, and crash-safe epoch advance | aarch64/ARMv7/old-x86 fixtures | `cityb-biggun footprint`, future zero-write mode |
| Does volatile gossip help? | valid observations before TTL expiry, correlated-failure risk, republish cadence, and material fit | local Nostr/libp2p/mempool doubles and IoTox/Tox transcript fixtures | `cityb-biggun gossip-matrix`, transcript import |

## What to build next

1. Keep deepening TTL/rate/failure-reason/carrier-kind fields in local-file and
   static-http placement/probe/observation receipts, and have `dead-drop debt`
   account for expiry directly.
2. Profile-driven placement: extend the implemented `cityb profile
   catalog|compile` artifacts for `benign-outage`, `carrier-loss`,
   `early-scraper`, `human-recovery`, `low-power-field`,
   `high-churn-gossip`, and `audit-heavy` into deterministic placement queues,
   observation cadence, and receipt requirements.
3. Format-preserving encoding integration: extend the implemented
   `cityb format catalog|render|parse` registry for raw hex, semver,
   log-field, timestamp/status, signed-event, and mnemonic encodings plus
   `cityb-node format parse`, adapter-selected local carrier doubles, and
   Biggun `format-corpus` into larger parser differential corpora and mutation
   fixtures.
4. State-ratcheted deterministic rendezvous planner: local beacon fixture,
   previous archive-root input, fallback schedule, weighted media selection, and
   operator plan output.
5. Provenance/correlation graph: report effective independent roots across
   source roots, accounts, providers, DNS zones, operators, copied transcripts,
   and failure domains.
6. Substrate registry/scoring: registry file generated by `dead-drop plan`,
   consumed by `audit`, and populated with declared assumptions plus measured
   receipt history.
7. Threshold/erasure dead drops: use the current 3-of-5 split/collect reports
   as the operator seam, then compare whole-token repetition, Shamir,
   systematic erasure, mnemonic chunks, and parity cards under the same carrier
   loss and mutation models.
8. Receipt freshness/debt: the current `dead-drop debt` report handles receipt
   epochs, and `dead-drop substrate score` joins schedules, local posts,
   observations, freshness, recommendations, and next actions into one retained
   operator view. Stale verified receipts and expired verified receipts should
   remain separate states all the way through score, negative-map, review, and
   exercise reporting. Next connect that distinction to heartbeat debt and
   retained City B run verification.
9. Heartbeat hysteresis: ensure debt changes posture and warning state without
   uncapped fetch escalation, battery drain, flash churn, or floor-token
   depletion.
10. Adapter authority manifests: define and validate ownership, credential source,
    allowed targets, rate limits, public visibility, cleanup semantics, and
    shutdown behavior before remote-capable posting exists.
11. Package/repo/status-page local doubles: keep expanding implemented
   package-index, repository metadata, CI-log, status-page, CT/Rekor-style
   transparency-log, Nostr relay, libp2p/provider-record DHT, local mempool,
   and IoTox/Tox transcript fixture shapes before integrations.
12. Parser differential tests: compare Tiny and Goldilocks candidate extraction
    and refusal names over the same carrier-shaped corpora.
13. OCR/noise robustness suite: extend the implemented local corpus to mutate cards and copied token lines until
   checksum recovery fails; quantify margins.
14. Negative-evidence map: implemented with not-attempted,
    planned-not-posted, posted-not-observed, observed-unverified,
    verified-but-stale, verified-but-expired, failed, archive-missing,
    partial-archive, and active substrate states.
15. Content-addressed evidence graph: keep readable reports, but make the
    replayable proof graph hash raw carrier snapshots, parser facts,
    verification facts, and adoption/refusal facts.
16. Archive availability mirrors: report byte availability and partial archive
    gaps across local, removable-media, and operator-owned mirrors without
    granting mirror authority.
17. Field-tiny zero-write mode: measure flash writes, state growth, RSS, and
    crash-safe epoch advancement on weak targets.
18. Recovery explainer: the current `dead-drop explain` command covers local
   dead-drop governance evidence; next expand it to ingest retained City B fleet
   status, refusal causes, and benchmark artifacts.

## Practical invariant

City B is strongest when the exotic ideas collapse back into boring local
evidence:

```text
the node saw bytes
the bytes contained a checksum-valid pointer
the pointer matched a complete signed archive
the archive passed the gate
the node state changed or refused for a named reason
the operator can replay the proof later
```

Everything else—semantic camouflage, public entropy, stigmergy, threshold
fragments, erasure coding, OCR cards, and passive observation—is only useful if
it improves that chain without weakening it.
