# CityB on Nix and NixOS

CityB is the product. Its runtime has three roles and three binaries:

- `cityb`: the Goldilocks operator cockpit;
- `cityb-node`: the narrow Tiny field receiver;
- `cityb-biggun`: the empirical truth, stress, and development machine.

The flake's default package, app, and NixOS module all mean CityB. Stil is not
required; it is m21's separate personal office.

The public release gate is:

```sh
nix flake show
nix fmt -- --check flake.nix nix/cityb-module.nix nix/examples/*.nix
nix flake check
nix build .#cityb .#cityb-portable
```

`checks.<system>.publication` verifies the three packaged identities, license,
absence of personal binaries from the default closure, and a source-independent
release plan. `checks.<system>.cityb-portable-smoke` verifies that every
portable role is executable and has no dynamic ELF interpreter. The flake lock
pins nixpkgs; the package embeds the reviewed source and release identities.
The portable package does not bundle external operator programs into the ELF
files: workflows that deliberately invoke Git, OpenSSH, age, DNS, or HTTP
clients require those host tools. The ordinary Nix package supplies its
reviewed runtime `PATH` closure automatically.

## Run or install

```sh
nix run . -- next
nix profile install .
cityb version --json
cityb doctor --require-ready --json
```

For a remote source, replace `.` with the exact reviewed flake URL. Installing
the default package places all three binaries in one closure.

The runtime package has a deliberately narrow source boundary: the workspace
manifests and `crates/` are its only Rust build inputs. Provider evidence,
operator documentation, Nix modules, retained roots, and vaulted artifacts do
not change binary bytes merely because they changed in the repository. The
release/check derivation separately restores the complete publication tree and
proves it. This keeps evidence-only commits cheap, prevents a large replay
corpus from exhausting Nix store hardlink optimization, and preserves the
important distinction between executable identity and the evidence used by an
operator decision.

## NixOS module

```nix
{ inputs, ... }:
{
  imports = [ inputs.cityb.nixosModules.default ];

  services.cityb = {
    enable = true;
    monitor = {
      enable = true;
      live = false;
      preset = "all-free-rotation";
      vantageId = "operator-host";
      egressLabel = "home-primary";
    };
    truthChecks.enable = true;

    # Optional: bounded start/stop/restart of only enabled CityB units.
    operatorControl = {
      enable = true;
      user = "operator";
    };
  };
}
```

The module creates a dedicated `cityb` system identity and these defaults:

- retained root: `/var/lib/cityb/root`;
- monitor state: `/var/lib/cityb/monitor`;
- evidence corpus: `/var/lib/cityb/evidence`;
- runtime descriptor: `/etc/cityb/runtime.json`.

The descriptor contains paths and build identity, never credentials. NixOS
exports its path through `CITYB_RUNTIME_CONFIG`; `cityb next`, `check`, `brief`,
`doctor`, and `operator card` then use the declared paths automatically.
Explicit flags override every descriptor default.

The same descriptor is the allowlist for `cityb system`. This is the public
operator lifecycle surface; it is not another daemon and it does not add a
fourth runtime role:

```sh
cityb system config --json
cityb system doctor --json
cityb system status --require-ready
cityb system timers
cityb system logs monitor --lines 200
cityb system run monitor --wait
```

`system doctor` gates readiness by default. It checks the invoking binary,
each declared executable, loaded `ExecStart`, last oneshot result, continuous
service state, and timer state. A stale or substituted package is therefore a
hard failure rather than a plausible-looking healthy timer. `status` is
read-only and inspectable by default; add `--require-ready` for automation.
Only descriptor role names are accepted by lifecycle and log commands.
Authorization remains with systemd. Set `operatorControl.enable = true` and a
named human `operatorControl.user` when that user should start, stop, or restart
the enabled service units without broad system authority.

When a public descriptor is present, `cityb operator card` embeds a bounded
`system_status` child and gives a broken or substituted unit priority over
retained-root work. Source-tree and non-Nix installations omit that child as
not applicable rather than inventing a systemd dependency.

## Opt-in services

The module can own:

- `cityb-monitor.service` and `.timer`;
- `cityb-evidence-intake.service` and `.timer` (mutually exclusive with the
  monitor writer);
- `cityb-truth-check.service` and `.timer`;
- `cityb-correspondence-gateway.service`;
- `cityb-correspondence-relay-soak.service` and `.timer`;
- `cityb-correspondence-node-capsule.service` and `.timer`.

Every unit executes the role-appropriate binary from the exact configured Nix
package. The module rejects relative runtime paths, accidental root execution,
dual evidence writers, incomplete TLS declarations, and unacknowledged
non-loopback gateways. Services have no ambient capabilities and see a
read-only system outside their declared writable paths.

Public-provider mutation remains off until
`services.cityb.monitor.live = true`. Correspondence listeners and firewall
openings are also opt-in. Importing the module alone does not contact a
provider, open a port, or start correspondence.

## Existing operator root

Use the checked example
[`nix/examples/cityb-existing-operator.nix`](../nix/examples/cityb-existing-operator.nix).
Adoption is explicit: the module does not copy, reset, or infer an existing
lineage. Home-retained paths require `allowHomeState = true`.

## Daily operation

```sh
cityb system doctor
cityb system timers
cityb next --require-ready
cityb check
cityb operator card --require-ready
cityb monitor nurse --brief
cityb-biggun truth --run --quick --json
```

`cityb next` remains the single cockpit. Systemd is lifecycle machinery, not a
second policy engine: provider decisions, evidence gates, release admission,
and recovery remain in the Rust binaries. `cityb system` merely makes that
lifecycle inspectable and safely operable without asking a human to remember
unit names.

## m21 and Stil

m21 intentionally keeps `nixosModules.stil` and the `stil` package. That
personal layer adds a resident payload profile, typed action IDs, collision
diagnostics, and Monsternix custody integration. It may wrap CityB, but it does
not rename CityB and is not the deployment path other operators should copy.
The root flake advertises the native CityB command apps plus the explicitly
named personal `stil` and `stil-foundation` apps; it does not advertise Stil's
internal compatibility wrappers as CityB entry points.
