# City B operator distribution

CityB distribution succeeds when every receiver can find enough current pointer evidence to reach the signed archive chain while the operator reveals no unnecessary personal, organizational, device, location, schedule, or account facts through the carrier layer.

The rule remains unchanged: carriers are discovery, archives are truth, and council signatures are authority. A carrier post can tell a receiver where to fetch candidate bytes. It cannot make a command valid, assign council weight, override quorum, bless a fork, or excuse missing archive verification.

This document is for lawful operator-owned or operator-authorized publication. Do not use hacked hosts, unrelated communities, compromised accounts, bypassed access controls, or terms-of-service violations as CityB carriers. Treat third-party free services as revocable conveniences whose evidence value ends at exact-byte receipt facts.

## The normal operator path

Use `cityb up --free --root DIR` for the easiest no-account path, then run `cityb check --root DIR` and `cityb next --root DIR` until the next command is obvious. The default free path stays conservative and uses only services with repeated checked-in exact-byte evidence.

Use `cityb deployment init --service-set free-wide --out city-b-wide.toml` when researching additional no-account services. `free-wide` is a drift bench: it is allowed to contain services that sometimes fail, require provider-specific receive semantics, or need more dated corpus evidence before promotion.

Use `cityb deployment init --service-set free-deep-10 --out city-b-deep-10.toml` when researching the ten-provider deep bench. That set is intentionally strict and should be paired with `cityb capture free-deep-10 --live --require-all`; it exists to collect promotion evidence for x0.at, curl.by, End2End.tech, file2.me, JuiceBox, TempFile.org, ayaya.beauty, hostb, hst.sh, and haste.rys.pw, not to replace `free-stable` as the easiest operator path.

Use `cityb deployment init --service-set free-deep-text-10 --out city-b-deep-text-10.toml` when researching the ten-provider text/paste bench. That set is also strict and should be paired with `cityb capture free-deep-text-10 --live --require-all`; it exists to collect promotion evidence for paste.code-solutions.dev, paste.helpch.at, bytebin.lucko.me, api.pastes.dev, bpa.st, transfer.archivete.am, pastefy.app, pastefox.com, haste.zneix.eu, and bin.birdflop.com.

Use `cityb deployment init --service-set free-deep-web-10 --out city-b-deep-web-10.toml` when researching the ten-provider web paste/file bench. That set is strict and should be paired with `cityb capture free-deep-web-10 --live --require-all`; it exists to collect promotion evidence for mclo.gs, Sourcebin, paste.agradip.fyi, SpaceBin, CrafterBin, qurl.sh, Mythical Paste, YukiAPI, AgentMediaTools, and paste.firnsy.com.

Use `cityb deployment init --service-set free-deep-web2-10 --out city-b-deep-web2-10.toml` when researching the second ten-provider web/API bench. That set is strict and should be paired with `cityb capture free-deep-web2-10 --live --require-all`; it exists to collect promotion evidence for PasteHTML, OKFile, here.now, haste.unbelievaboat.com, rentry.co, files.offshore.cat, qu.ax, zoomie.sh, openSUSE Paste, and Debian Pastezone.

Use `cityb deployment init --service-set free-deep-web3-10 --out city-b-deep-web3-10.toml` when researching the third ten-provider web/API bench. That set is strict and should be paired with `cityb capture free-deep-web3-10 --live --require-all`; it exists to collect promotion evidence for CentOS Paste, rpa.st, AlmaLinux Paste, OpenStack Paste, yt-project Paste, OpenDev Paste, Gentoo LogPaste, Ubuntu China Paste, p.defau.lt, and paste2.org. CoShareX is built as a separate JSON-field candidate but is not part of this strict bench until later captures prove stable anonymous posting.

Use `cityb deployment init --service-set free-deep-web4-10 --out city-b-deep-web4-10.toml` when researching the fourth ten-provider web/API bench. That set is strict and should be paired with `cityb capture free-deep-web4-10 --live --require-all`; it exists to collect promotion evidence for Pastr, Valhalla Paste, Write.as, p.ip.fi, Kagit, ShareNotes, Pastebin.ai, da.gd, TinyURL, and clck.ru. The first seven providers are text/API receive candidates; the last three are redirect-token carriers, so they should not be promoted as exact-byte mirrors without a deliberate non-exact lane policy. CleanURI is implemented but stays out of this strict set until live captures prove retrievable generated short URLs.

Use `cityb deployment init --service-set free-deep-web5-10 --out city-b-deep-web5-10.toml` when researching the fifth ten-provider web/API bench. That set is strict and should be paired with `cityb capture free-deep-web5-10 --live --require-all`; it exists to collect promotion evidence for Scuttled, ti.fo, docs-md, 8gwifi, tnypst, Droptext, Luis Aranguren Paste, Ulvis, MeshaLive, and AISense 307.fi. The first five providers are exact or newline-normalized text receive candidates; Droptext and Luis Aranguren Paste are rendered-token carriers; Ulvis, MeshaLive, and 307.fi are redirect-token carriers, so they should not be promoted as exact-byte mirrors without a deliberate non-exact lane policy.

Use `cityb foothold --root DIR --json` to preview one ready-made posting lane, then `cityb foothold post --root DIR --lane pointer|heartbeat|route-hint|mirror` when the operator wants a single compiled action instead of hand-selecting envelopes and adapters.

After any live post, run `cityb collect probe` or the generated fetch command, then `cityb review --root DIR`. The operator should judge distribution health from verified receipts, freshness debt, negative maps, archive availability, and service reliability, not from the fact that a service returned a URL.

## Improve command distribution

Publish small pointer material widely and archive material narrowly. Pointer, heartbeat, and route-hint lanes should move through many cheap carriers; signed archive bundles should live on more durable operator-owned mirrors or reviewed release/static-page surfaces.

Separate lanes by lifetime. Use short-TTL services for heartbeats and route hints, variable-retention text/file services for pointer redundancy, and durable operator-owned pages/releases/object stores for recovery mirrors. Do not make a short-TTL service the only way to find the current archive.

Favor root diversity over service count. Five URLs behind one provider root, one account root, one moderation root, one network root, or one copy-root are still one correlated failure. The deployment metadata tracks those roots so rotation and review can prefer genuinely independent lanes.

Use exact returned locations. Receivers should not guess slugs, scrape search results, enumerate account dashboards, or assume directory listings. If a service has no feed or listing, keep it in returned-url-only mode and distribute that exact receive handle through another lane.

Keep the receive recipe provider-specific. NullPaste requires JSON `raw_url` parsing. temp.sh returns a viewer URL whose HTTP GET is not the raw object; the exact bytes come from the service's POST download action. tmpfiles returns a viewer URL that must be resolved to a direct `/dl/...` link. Termbin returns a TCP-upload response that may contain trailing NUL bytes. These details belong in adapters and fixtures, not in operator memory.

Retain negative evidence. A 503 upload-disabled body, a Cloudflare challenge page, a 405 method rejection, a viewer HTML page, and a token-bearing-but-wrong body are different facts. CityB should keep them as named provider cases so the next cycle can rotate, de-rank, or repair intelligently.

Use repeated dated corpora before promotion. A same-day success is useful but not stable. Promotion into `free-stable` requires repeated date-separated captures, fixture replay, Biggun parser-diff agreement, and enough root diversity that the added service improves recovery more than it adds operator confusion.

## Reveal less while staying useful

Make payloads boring and deterministic. The carrier payload should contain the encoded pointer material and the minimum envelope facts needed for replay. It should not contain the operator's name, hostname, project path, local username, comments, device identifiers, or ad-hoc prose.

Use canonical filenames and labels. Names like `cityb.txt`, `repo-metadata-double-e0-s0.jsonl`, or lane-derived names are less revealing than names containing a person, organization, place, case, device, or emergency description.

Keep time facts coarse and protocol-owned. Prefer epoch numbers, TTL fields, and UTC capture dates over local timezone strings. If a service adds timestamps, record them as provider evidence but do not duplicate local clock details inside the payload.

Batch and rotate within declared policy. The operator should compile a cycle plan, execute the selected posts, then collect/review. Avoid distinctive manual posting bursts caused by panic or memory; let CityB's cadence, retry budget, freshness debt, and root-budget fields decide when more distribution is actually needed.

Minimize account-bearing surfaces. For no-account free services, no CityB credential should exist. For token-backed services, use explicit operator-owned tokens in the host environment, never in the project tree, carrier payload, fixture body, or checked-in config.

Keep browser and UI workflows separate from authority. If a service requires a browser dashboard, use staged packets and manual receipts. Do not infer success from a green UI; the command distribution only becomes useful after an exact public fetch and archive verification.

Avoid personal network fingerprints where the operator has lawful alternatives. Prefer operator-controlled infrastructure, delegated publishing relays, or routine organizational runners over personal laptops and home networks when the publication policy allows it. Do not bypass access controls or service abuse controls.

Strip local metadata before upload. CityB pointer payloads are text by default, which avoids EXIF, office-document authorship fields, archive member paths, and platform-specific metadata. If future adapters carry binary or archive material, the adapter must document and test metadata removal before it becomes an easy-path carrier.

Use the same signed archive pointer across mirrors for one epoch. Unnecessary per-service payload variation creates copy errors and makes audits harder. Variation belongs in encoding/placement hooks only when the hook is explicit, reversible, and fixture-backed.

Record receipts by digest and exact URL. Operator logs should preserve the minimum proof needed for replay: service id, adapter id, lane, location, final location, redirect count, HTTP status, parser encoding, digest result, fixture body digest, and failure name. They should not absorb full account logs, browser history, credentials, or unrelated provider output.

## Receiver footholds

Every listener should begin from a small, explicit foothold: the constitution or trust root, the current or previous verified archive root, and a deployment service plan. Tiny nodes should need no operator memory beyond `cityb-node kit verify` or the generated recovery card.

Listeners should poll the easy path first: free-stable or operator-owned mirrors, then route-hint lanes, then free-wide and free-deep drift surfaces. `free-deep-10`, `free-deep-text-10`, `free-deep-web-10`, `free-deep-web2-10`, `free-deep-web3-10`, `free-deep-web4-10`, and `free-deep-web5-10` are evidence benches until repeated dated corpora justify promotion. A failed research-bench service should add provider-health evidence; it should not block adoption if enough other exact-byte receipts verify.

Receivers should share parser behavior with Goldilocks. Biggun's parser-diff over identical fixture corpora is the gate: if Goldilocks and Tiny disagree on a carrier body, the body is not promotion evidence until the mismatch is understood.

## Promotion checklist

Before a new adapter becomes `free-stable`, require all of the following:

- no-account or explicitly operator-owned account posture;
- documented or live-observed publish request;
- exact-byte public receive path;
- provider-specific receive quirks encoded in Rust, not in operator memory;
- checked-in fixture bodies and transcripts;
- at least two date-separated live captures;
- local fake-service tests for the publish/probe path;
- collector fixture replay;
- Biggun parser-diff agreement;
- stated retention, rate, redirect, expiry, and malformed-body behavior;
- root metadata distinct enough to improve the deployment plan.

That checklist is deliberately strict. CityB can keep broad candidate adapters in `free-wide`, but the command surface should remain easy enough that a tired operator can run the normal path without remembering which free service is currently strange.
