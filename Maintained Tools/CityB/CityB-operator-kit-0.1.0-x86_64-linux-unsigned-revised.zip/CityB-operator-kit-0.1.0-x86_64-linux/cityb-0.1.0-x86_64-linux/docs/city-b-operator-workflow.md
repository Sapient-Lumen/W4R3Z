# City B operator workflow

This is the intended operator model for City B.

The operator should not need to think in terms of service-specific mechanics
until they are intentionally configuring one adapter. The routine workflow is:

## Zero-memory operator path

The ordinary path is the cockpit plus three action commands:

```sh
cityb operator card --root ./city-b-artifacts --deployment ./city-b.toml
cityb system doctor --json
cityb system timers --json
cityb doctor --json
cityb install --json
cityb storage status --root ./city-b-artifacts --json
cityb disaster-recovery inventory --root ./city-b-artifacts --json
cityb up --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb check --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb next --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb recovery-card --root ./city-b-artifacts --deployment ./city-b.toml --out ./city-b-recovery-card.svg --force --json
cityb field-pack status --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb anchor status --root ./city-b-artifacts --json
cityb anchor retrieve --root ./city-b-artifacts --source ANCHOR_FILE_OR_URL --apply --json
cityb evidence sync --json
cityb monitor nurse --brief
cityb provider health --service-set free-stable --json
```

On a NixOS deployment, `cityb system doctor` is the first host-level question:
is this exact CityB package the one named by the runtime descriptor, are its
declared units loaded from the expected executables, and are its timers and
continuous services healthy? `cityb next` remains the policy and retained-root
cockpit. The two surfaces intentionally answer different questions. Use
`cityb system run monitor --wait` for one explicit monitor pass and
`cityb system logs monitor --lines 200` for bounded failure context; no command
accepts an undeclared unit name.

These surfaces share one readiness schema. `execution_success=true` means the
inspection ran; only `operational_ready=true` means generation, trust,
provider/monitor evidence, archive capacity, and field-pack work are all
green. Read `primary_action_detail` first and then `action_chain` in order.
The same model is emitted by `doctor`, the operator card, provider health,
rendezvous, and monitor status/nurse, so switching surfaces does not change the
meaning of ready.

When provider-set or release generation changes, use the guided ceremony:

```sh
cityb reconcile \
  --root ./city-b-artifacts --deployment ./city-b.toml \
  --service-set free-stable \
  --signing-key /secure/cityb-release-key \
  --allowed-signers /secure/cityb-allowed-signers \
  --signer-identity cityb-release --json
```

It is a plan until `--apply`; public archive spraying additionally requires
`--live`. Old generation receipts remain forensic-only. For a long-dormant
field pack, `cityb recover --anchor-source FILE_OR_URL` plans the fail-closed
anchor → signed chain → shard reconstruction → release admission → current
field-pack transaction; add `--apply` only after reviewing the named policy,
plan, receipts, and trust paths.

`cityb operator card` is the zero-memory cockpit. Its default runs one typed `next` snapshot, reuses that snapshot for correctly scoped provider, monitor, check, and field-pack projections, and adds an install-identity check. It does not require a source checkout or make release construction a production-runtime readiness gate. Default JSON is bounded below 64 KiB; `--verbose` deliberately runs and embeds the full child diagnostics and includes the reference surface inventory. The previous hard-coded `top10` feature checklist is omitted from normal live readiness (`top10_scope=omitted-use-verbose`). `details_included` makes the distinction machine-readable. `cityb operator next` is the same idea reduced to one evidence-bound command and reason. Both accept `--fixture-root` and `--state-dir` for copied corpora or non-default monitor state, and neither mutates remote services.

`cityb up` is the retained-root bootstrap and steady-state runner. It creates
the deployment when missing, validates it when present, creates the retained
City B root when missing, compiles the deployment, previews hazards, runs or
resumes the current cycle, collects verified material, reviews the retained
root, exports a Tiny node kit, and prints the exact next command. It defaults
to `--service-set local-proof`; use `--free` or
`--service-set free-stable` only when the operator intentionally wants to mutate
the repeated-live no-account public starter services. Use `--wide-free` or
`--service-set free-wide` for the broader anonymous adapter bench when the
operator is deliberately collecting service evidence.

Routine cockpit commands are deliberately bounded. `cityb doctor`, `cityb
next`, and `cityb operator card` inventory a field pack with `field-pack status
--quick`; that mode never hashes pack contents and reports
`digest_checked=false`, `digest_freshness=not-checked`, and
`field_pack_freshness=unchecked`. Use ordinary `cityb field-pack status`,
`cityb field-pack verify`, or `cityb doctor --deep` before a handoff or adoption
decision. Doctor JSON is compact by default; add `--verbose` only when a caller
needs every nested subcommand transcript. In the paragraph below, detailed
`step_results` means the compact per-step status, command, reason, and action
hint; it does not mean the full transcript unless `--verbose` is present.
The `up`, `check`, and `next` workflow JSON follows the same rule: `steps`
always carries compact status and command facts, `details_included` says whether
nested output is present, and `--verbose` opts into complete subcommand
transcripts.

Doctor now takes its first operator action from the same `next` cockpit used by
`check`, Stil, and Biggun before it renders the independent mechanism checks.
It therefore cannot put provider-role mutation ahead of evidence curation or
source-control handoff. Install classification counts a narrow
`reviewed_route_files` subset of `identical`: only a direct symlink or a strict
one-exec Bash wrapper whose target canonicalizes to the exact selected binary
qualifies. Such a reviewed Nix/Monsternix route is a no-op; an arbitrary
launcher remains `foreign/conflicting`. A complete active Nix binary set is reported as usable
without pretending that an optional duplicate `~/.local/bin` installation is
required for operational readiness.

`cityb doctor` is the side-effect-free binary readiness sweep: version, capabilities, provider health, rendezvous doctor, release archive plan, monitor nurse, field-pack status, install dry-run, provider candidate summary, recovery-card command, and optional deep parser preview. Its JSON keeps detailed `step_results` and also exposes `failed_step_names`, `attention_step_names`, `attention_required`, `next_command`, and `next_reason` so wrappers do not need to parse every nested transcript. `cityb install` is dry-run by default and classifies every destination as `identical`, `outdated`, `missing`, or `foreign/conflicting`. Identity inspection hashes files and scans bounded, role-specific artifact markers; it never executes the destination being classified. Identical artifacts are a no-op; missing and recognizably older same-role CityB artifacts reconcile atomically with `--apply`; foreign/conflicting files require the separately reviewed `--force`. Doctor forwards the exact install attention instead of recommending a generic forced reinstall. `cityb check` is the side-effect-free dashboard. It validates whatever exists, reviews the retained root, previews cycle hazards when possible, reads cycle status when a plan exists, asks the evidence-bound selector for the next action, reports `attention` when a subcommand succeeded mechanically but found degraded evidence, and surfaces topology/root-diversity fields plus `topology_summary` so fake diversity is visible before posting. Service metadata can retain typed operator/provider, hostname, DNS-family, IP, ASN, CDN, hosting-root, confidence, and observation-date facts; unknown/unverified roots do not count as fictional independence. Provider carrier classes are reported separately from CityB mechanisms such as pointer chains, fragment sharing, erasure archives, and public anchors. `cityb rendezvous doctor --live-topology --json` is the explicit live enrichment form: it resolves declared carrier hosts, records IP roots, attempts Team Cymru ASN lookup when `dig` is available, falls back to RIPEstat HTTP prefix facts when `dig` is unavailable, infers coarse CDN roots, and remains outside default offline checks. `cityb next` is the single cockpit: it tells an amnesic operator whether to run `up`, start a cycle, collect, reconcile, review, curate retained monitor evidence, recapture a provider, perform a local provider promote/demote/retire action, review a batch stable-set plan, finish durable recovery, or export a missing/partial/stale field pack. Its headline `command`, `reason`, and `primary_action` are the first item of the same readiness chain it emits. Old-build evidence replay comes first; otherwise evidence curation and source handoff precede evidence-derived provider policy. A stale field pack is current-authority work and precedes future-cycle maintenance. A failed required stable lane becomes a named `stable-provider-watch` after independent retained-root work; it blocks derived provider-policy changes but does not falsely classify the timer or monitor infrastructure as broken. The JSON keeps `service_availability`, `stable_provider_watch`, and `recovery` as separate typed objects alongside provider, topology, capability-ledger, field-pack, archive, monitor, and correspondence projections. The text answer adds `CURRENT_SERVICE`, `STABLE_WATCH`, and `RECOVERY` to the existing bounded decision lines.

Archive work in the cockpit is generation-aware. Named provider-set plans are
reconciled against the current source set; explicit custom plans are
reconciled against their own immutable snapshot. A superseded generation can
remain reconstructable for forensic analysis, but `next` never recommends it
for normal adoption. It recommends one transactional `archive refresh`
instead. When current receipts are sufficient, `next` recommends either the
one-time `cityb release trust init --root ROOT` setup or a complete
`archive collect --trust-policy ...` command—never a command with signer
placeholders. Sufficient total receipts and root-loss readiness are distinct:
`archive status` reports both, while `archive repair` preserves the generation
and targets exact missing assignments outside the largest received domain.
Repair requires dated capacity proof at the planned width by default. When too
few safe repair candidates exist, `next` emits one concrete `capacity-soak`
command rather than repeating failed posts. New planning supports
`--capacity-policy prefer-proven|require-proven|ignore`; the strict form fails
if no provider has dated proof at the rendered width, while the production
`--require-root-loss-ready` gate separately proves that sufficient assigned
shards survive the largest correlated failure domain. A provider may hold
multiple shards; JSON therefore reports proven providers and proven shard
assignments separately. The standing monitor also records the archive-capacity
ledger
and performs one bounded receipt recheck per live tick, so planning learns
proven payload bands and retrieval/expiry drift. See
`city-b-generation-and-capacity.md` for the state machine.

Cycle planning also retains immutable pointer-chain members under
`city-b-pointer-chain-members/`. Field-pack export carries that bounded history.
Tiny examines at most 32 one-MiB members, accepts only exact member bytes whose
digest appears in the verified archive chain, selects the highest verified
next epoch, and reports candidate count, verified count, and recovery span.
The current member filename is a convenience, never authority.

`cityb recovery-card` writes the one-page SVG amnesia card: the newest verified chain or planned epoch, a deterministic retained-root digest that excludes the generated card itself, active providers from TOML or resolved JSON deployments, discovered public constitution/roster/key artifacts, field-pack readiness, exact recovery commands, and a green/danger verification matrix. Its bounded digest walk is lexically ordered and does not follow symlinks, so repeated `--force` generation over unchanged state preserves the same identity. `cityb field-pack status` is the obvious Tiny handoff check: it reports kit and capsule manifests, manifest digest freshness, runtime binary identity, deployment digest identity, optional release manifest identity, pack digest matches/mismatches, Tiny kit inspection success, kit epoch, the retained root's chain epoch, epoch-match freshness, public-material violations, chain/floor record hints, read-only readiness, zero-write readiness, a compact `tiny_status` answer, and the exact verify/export command. It never compares the kit only with the chain copy carried inside that same kit. `cityb anchor ceremony` is the durable-anchor runbook as one read-only command: it prints the policy write, live drand/Rekor/CT refresh, missed-cycle status, Tiny resolve, and Biggun amnesia-proof commands without reading the network or writing state. `cityb anchor status` is the missed-cycle fallback page over retained archive-chain, floor, pointer-chain, signed pointer-chain, field-pack, public-anchor evidence, source policy, and append-only history facts. When a signed pointer-chain member is pending archive inclusion and declares its target epoch, the exact transition is `cityb publish --config .../city-b-publisher.kv --epoch N`; CityB does not incorrectly repeat `cycle apply`. `cityb anchor policy --apply` creates the retained durable-source policy. `cityb anchor retrieve --source FILE_OR_URL --apply` reads one operator-selected CityB public-anchor JSON document, enforces source/trust-root policy plus rollback, split-view, and append-only-history checks, and writes only local retained anchor state/history. `cityb evidence sync` is the evidence inbox companion to `next`. It reviews retained monitor captures, dry-runs the import by default, imports with `--apply`, reports top-level `status` and `success`, reports `changed_summary` with changed providers, dates, and success/failure/exact-byte counts, runs provider health and promotion checks, automatically attempts parser-diff after an applied import unless `--no-parser-diff` is explicit, and prints one follow-up command. It performs no network request; `--apply` mutates only the local fixture corpus.

Completed cycles are retained as immutable generations rather than overwritten.
When `cycle preview` finds a fully verified and audited completed cycle whose
deterministic projection changed, it prints one explicit `cycle plan --force`
rotation. That command copies and verifies the old plan, events, history,
journal, results, collection state, and observations beneath
`city-b-cycle-generations/CYCLE_ID/`, writes a manifest, and only then removes
the active projection. A retry verifies every remaining source byte against
the committed archive before finishing cleanup. `--force` still refuses
partial, failed, or uncertain cycles.

`cityb next` and `cityb check` treat the expected `cycle next` refusal for that
case as control flow once the independent preview succeeds; it is not reported
as a failed diagnostic. A completed retained cycle is a safe terminal point,
not immediately due work: the cockpit reports `workflow_command=none` and waits
for the operator to advance cadence deliberately. Low-level `cycle preview`
still exposes the exact `cycle plan --force` rotation. When the operator elects
to advance, Stil binds the preview cycle id and digest in a review receipt
before executing that follow-up. This distinction prevents an unattended
`stil act` loop from sealing one pointer-chain act, deriving another cycle from
the new archive root, and running forever.

Retained-root storage and operator continuity are separate ceremonies:

```sh
cityb storage status --root ./city-b-artifacts --json
cityb storage plan --root ./city-b-artifacts --json
cityb storage prune --root ./city-b-artifacts --apply --json

cityb disaster-recovery inventory --root ./city-b-artifacts \
  --include /secure/release-signing-key --json
cityb disaster-recovery export --root ./city-b-artifacts \
  --include /secure/release-signing-key --recipient age1... \
  --out ./cityb-operator-recovery.age --json
cityb disaster-recovery verify --in ./cityb-operator-recovery.age \
  --identity /secure/age-identity.txt --json
cityb disaster-recovery restore --in ./cityb-operator-recovery.age \
  --identity /secure/age-identity.txt --out-dir ./restored --json
```

Storage pruning is dry-run first and allowlist-based. Current authority,
release trust, anchor policy, evidence, admission records, current and forensic
generations, receipts, and unknown material are protected; only named
reproducible fault caches and transient field-pack refresh staging are
eligible. Apply repeats ownership, device, symlink, hardlink, and path checks
and writes a prune receipt. Disaster recovery never creates a plaintext
archive: it streams a manifest-and-bytes bundle directly through `age`,
requires sensitive inputs to be private, verifies all digests before restore,
uses atomic files and restrictive permissions, and is a dry restore unless
`--apply` is explicit. External signing identities are included only through
explicit `--include`; a public field pack is not operator continuity.

The intent verbs keep remembered incantations short:

```sh
cityb service ls --service-set free-stable --json
cityb evidence sync --json
cityb evidence sync --apply --json
cityb evidence index --apply --json
cityb monitor nurse --brief
cityb provider health --service-set free-stable --json
cityb provider archive-roles --service-set free-stable --root ./city-b-artifacts --json
cityb provider archive-roles --service-set free-stable --root ./city-b-artifacts --apply --json
cityb provider explain nullpaste --service-set free-wide --json
cityb provider dossier litterbox --service-set all --run-checks --json
cityb provider promotion-board --service-set free-deep-web2-10 --run-checks --json
cityb provider stable-plan --from free-deep-web2-10 --to free-stable --json
cityb provider lane-board --from free-deep-web2-10 --lane discovery --json
cityb provider candidates list --json
cityb provider candidates plan --json
cityb provider candidates capture --provider gofile --json
cityb provider candidates promote --provider gofile --lane research --json
cityb provider health --service-set free-wide --json
cityb provider patch-plan nullpaste --action promote --to free-stable --json
cityb repair queue --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb post due --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb post due --root ./city-b-artifacts --deployment ./city-b.toml --apply --max-events 8 --json
cityb post pointer --root ./city-b-artifacts --json
cityb post pointer --root ./city-b-artifacts --apply --json
cityb dead-drop archive preview --root ./city-b-artifacts --service-set free-stable --json
cityb explain event --root ./city-b-artifacts --event EVENT_HEX --json
cityb explain service catbox --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb recovery-card --root ./city-b-artifacts --deployment ./city-b.toml --out ./city-b-recovery-card.svg --force --json
cityb field-pack status --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb export field-pack --root ./city-b-artifacts --out ./field-pack --force --json
cityb anchor status --root ./city-b-artifacts --json
cityb anchor retrieve --root ./city-b-artifacts --source ANCHOR_FILE_OR_URL --apply --json
```

`cityb service ls` is the public-service evidence board for the configured set. It is a wrapper over the adapter doctor and reports exact-byte fixture evidence, dated drift, dominant provider-health failure, and the next capture action. `cityb evidence sync` is the local evidence inbox: it wraps monitor review/import, provider health, promotion check, and post-import parser-diff attempts so an operator can move retained machine evidence into checked-in fixtures without remembering each command; its top-level `status` and `success` make wrappers simple, and its changed summary names provider and date deltas, not just copied file paths. Provider replay is only one evidence sink: archive-capacity, topology, and rendezvous/listing observations retain their own ledgers, and checked-in listing fixtures remain a reviewed promotion corpus rather than an automatic copy of every live read. `cityb evidence index --apply` refreshes the fingerprinted shared evidence index; curation carries a separate monotonic generation and sealed high-water mark, so indexed reads and destructive pruning cannot be confused with provider-set decisions. `cityb monitor nurse --brief` is the care answer for that retained monitor: it checks report presence, latest success, installed unit files, whether the installed `ExecStart` targets the selected state directory, whether the installed monitor binary matches the selected binary, systemd timer clock facts when available, importable evidence, provider-health attention, degraded adapters, urgent adapters, and prints `DO_NOW` plus `WHY`; its JSON separately reports infrastructure, stable-lane, capacity-experiment, promoted-listing, research-listing, and candidate-probe outcomes. Required-lane readiness does not hide experimental failures: `cityb monitor findings` renders those capacity, listing, and candidate results as a bounded queue, while `cityb next` reports the aggregate finding count and exact review command. A failed required stable lane blocks provider-role or archive-capacity policy; it does not block independent current-root field-pack and recovery work. Through Stil it is an automatic dated wait with an optional bounded review, not a broken timer or executable same-day recapture. Once those custody gates are clear, `stil act` prioritizes current-root cycle plan/apply/collect and field-pack work over future-generation capacity probes. The typed bridge reconstructs only an allowlisted argv from declared runtime paths and never evaluates a rendered command; `stil tend` remains the explicit provider/future-generation queue. `cityb monitor compact` is a dry-run-first local storage transaction that bounds reports and disposable capture workrooms without deleting the replay corpus, evidence index, rendezvous observations, topology evidence, or latest report pointer. `cityb provider archive-roles` is the batch answer for archive capacity: it classifies every selected provider into automatic-proven, automatic-capacity-bounded, recovered-watch, capacity-repair, capacity-unproven, or pointer/mirror-only and writes one atomic local policy only with `--apply`. `cityb dead-drop archive preview` uses that policy with dated ceilings and topology roots to search shard width, data threshold, parity count, and largest-root survival before a generation is planned. `cityb provider health` remains the explicit pointer and capacity inbox; individual explain/dossier commands are diagnostic pages, not the required path for closing a whole archive-role queue. `cityb provider promotion-board`, `provider patch-plan`, `provider stable-plan`, `provider lane-board`, and `provider candidates` retain their source-review and candidate-onboarding roles. Public-service mutation remains explicit, evidence-driven, and separate from local policy writes. `cityb repair queue` wraps `cycle next`; `cityb post dossier|due|pointer` own ordinary posting; `cityb recovery-card`, `anchor status|retrieve`, and `field-pack status` own handoff and amnesia recovery; and release archive/sign/verify own movable artifact admission.

The findings queue orders blocking stable/infrastructure failures before non-blocking experiments and exposes separate `blocking_findings`, `experiment_findings`, and `total_findings` counts. Its human summary is limited to three named findings plus an omitted count; full JSON remains available. Placement-receipt failure classes survive raw-capture curation, so a provider diagnosis does not become `unknown` merely because redundant fixture files were pruned.

A completed capacity experiment remains execution success when it proves corruption, expiry, rejection, or another provider failure, but that negative provider observation increments `capacity_findings`. Current readers reconstruct the finding from retained step output when an older report stored an under-counted aggregate.

Timer state is part of monitor readiness, not merely diagnostic decoration.
`monitor nurse` requires the timer to be both enabled and active. An installed
but stopped timer reports `pre_soak_ready=false` and prints the executable
`systemctl --user enable --now cityb-provider-monitor.timer` recovery action.

Use `cityb monitor coverage --json` to ask what the retained soak actually
sampled rather than what the installation intended to sample. The report
names represented dates, vantages, egresses, exact build identities, research
rotations, and listing collectors, and checks monotonic sequences plus
predecessor fingerprints independently for each persistent monitor lineage.
Legacy reports remain visible as legacy instead of being silently treated as
provenance-complete. Coverage is not evidence-ready until new-format reports
span at least two UTC dates, even when older reports already cover every
rotation. A single named vantage is useful evidence, but not
multi-region or multi-ASN proof.

Routine `monitor review --json` and `monitor import --json` responses cap path details at 64 rows and state what was omitted. Review includes only not-yet-imported paths. Use `--verbose` for a complete path transcript; it is not the normal cockpit or automation path.

When the operator is working from a retained root, add `--root ROOT` to `provider health`, `provider explain`, and `provider dossier`. That includes archive-spray evidence from `ROOT/city-b-archive-erasure/city-b-archive-erasure-provider-evidence.jsonl` in the same inbox, so a provider that is still healthy for tiny pointer posts but failed archive-sized shards gets an explicit recapture or demotion-review gate instead of disappearing behind quorum success.

Provider health and dossiers now separate pointer stability from archive-shard capacity. Read `archive_shard_eligible`, `archive_shard_status`, and `archive_shard_reason` before using a stable provider for archive erasure distribution; the generated current pointer/mirror-only roster is listed by `stil snapshot`, `monitor nurse`, `provider health`, and `cityb next`.

`cityb provider stable-plan --from SET --to free-stable` is the batch source-review companion for a repeated-green bench. It emits exact-byte providers that can be reviewed for stable-set addition, separates rendered-token/redirect-token/listing providers into discovery lanes, embeds a unified diff against the built-in stable set, and writes only a review artifact when `--apply` is explicit. `cityb provider lane-board --lane discovery|exact|all` is the lane board for keeping token-only discovery value separate from exact-byte archive mirror evidence.

Recent operator polish makes the same surfaces easier to script and easier to use while tired. `provider health`, `provider promotion-board`, `evidence sync`, and provider-candidate list/test/capture surfaces now expose top-level `status` and `success`; `stable-plan` emits source files, review steps, validation commands, and `diff_status=no-source-change` when a bench is already represented in `free-stable`; `patch-plan` names already-true source states; and `monitor nurse` points at monitor reinstall for stale units/binaries, monitor rerun for service-set mismatches on the current binary, or `provider explain SERVICE` for provider failures. `cityb anchor ceremony` is the one-command durable-anchor runbook, while `cityb anchor status` is the missed-cycle fallback page over retained archive-chain, floor, pointer-chain, signed pointer-chain, field-pack/public-anchor readiness, source policy, append-only history, fallback posture, and next recovery command; `cityb anchor policy` and `cityb anchor retrieve` remain the local public-anchor policy/intake hooks. `release ceremony` is the one-command release runbook, `release archive --signature-policy require-present|require-verified` records the intended detached-signature policy, `release sign SHA3SUMS --signing-key KEY --apply` creates `SHA3SUMS.sig` with OpenSSH, `release verify --signature-policy require-verified --signature-verifier ssh --allowed-signers FILE --signer-identity ID` verifies that signature, and field-pack `--signature-policy require-verified` requires a release manifest that already reports verified signature status. A deployment can carry `release_manifest` and `release_signature_policy` so field-pack checks do not depend on remembered CLI flags.

`cityb monitor nurse` now names the latest failed monitor preset, service set, date, failed adapter, and provider-health failure where the retained monitor report contains that detail. `--brief` keeps that summary in the `WHY` line; JSON keeps the same data in `latest_failure` without forcing automation to parse the nested monitor report.

The expanded form remains useful for debugging, teaching, and exact manual
control:

```sh
cityb deployment init --out ./city-b.toml --profile carrier-loss --service-set free-stable
$EDITOR ./city-b.toml
cityb deployment validate --file ./city-b.toml --json
cityb deployment compile --file ./city-b.toml --root ./city-b-artifacts --json
cityb deployment recipes --file ./city-b.toml --json
cityb cycle preview --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb cycle plan --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb cycle apply --root ./city-b-artifacts --deployment ./city-b.toml --max-events 16 --with-collect --json
cityb cycle resume --root ./city-b-artifacts --deployment ./city-b.toml --max-events 16 --with-collect --json
cityb cycle run --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb cycle next --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb cycle status --root ./city-b-artifacts --json
cityb collect --root ./city-b-artifacts --deployment ./city-b.toml --json
cityb collect probe --root ./city-b-artifacts --deployment ./city-b.toml --service catbox --location URL_OR_FILE --json
cityb collect cursor --root ./city-b-artifacts --deployment ./city-b.toml --service catbox --lane mirror --source LISTING_URL_OR_FILE --json
cityb collect fixture-template --root ./city-b-artifacts --deployment ./city-b.toml --out captured-provider-fixtures.jsonl --all-cases --json
cityb collect fixture --root ./city-b-artifacts --deployment ./city-b.toml --fixture captured-provider-fixtures.jsonl --json
cityb-node dead-drop scan ./city-b-artifacts/city-b-normalized-inbox \
  --against ./city-b-artifacts/city-b-chain --require --json
```

Deployment commands and `cycle plan/status` perform no remote mutation. The
compiler produces an operator view, a credentialless listener plan, and a
collector plan. `deployment init` accepts `--service-set local-proof`,
`--service-set free-stable`, `--service-set free-five`, `--service-set
free-wide`, `--service-set free-deep-10`, `--service-set free-deep-text-10`,
`--service-set free-deep-web-10`, `--service-set free-deep-web2-10`,
`--service-set free-deep-web3-10`, `--service-set free-deep-web4-10`, `--service-set free-deep-web5-10`, or `--service-set plugin-five`; the default remains the safe local proof,
`free-stable` gives the operator the evidence-curated repeated-live,
no-credential starting manifest. Its current membership, structural archive
eligibility, capacity classes, and pointer-only members are emitted by the
shared capability ledger in provider health, `next`, and monitor nurse rather
than hard-coded here. `free-five`
keeps the older Filebin/0x0 drift bench, `free-wide` keeps Filebin, Termbin,
temp.sh, NullPaste, and Litterbox plus the
negative 0x0/file.io/storage.to bench for explicit wide-service trials, and the
deep benches stay strict provider-evidence sets. It also emits
`city-b-listener-node.kv`, ready for
`cityb-node config validate`, with every normalized inbox already wired
as a local feed. The cycle planner turns the retained pointer and lane envelopes
into content-addressed planned events. It satisfies each lane's declared media
and effective-root floors without blindly posting every lane to every eligible
service. Pointer floors retain the original `minimum_fresh_media` and
`minimum_failure_domains` names; heartbeat, route-hint, and mirror accept
optional `<lane>_minimum_fresh_media` and
`<lane>_minimum_failure_domains` keys and default to one each. Profile defaults
now also compile lane encodings, fragment scheme, rendezvous mode, cadence, TTL,
retry budget, storage budget, observation freshness, observation decay, and
correlated-root request budget into resolved plans and cycle events. Service
metadata records `failure_domain`, `provider_root`, `account_root`,
`network_root`, `moderation_root`, and `copy_root`; effective independence is
the minimum diversity across those roots, so brand count cannot masquerade as
resilience. Root request budgeting applies across those same dimensions, so
two services that share a provider, account, network, moderation system, or
copied source cannot silently consume the whole publication cycle. `cycle
preview` is the side-effect-free hazard check: it recomputes the next plan,
reports whether a retained plan already matches, counts planned remote
mutations, and shows reliability scores plus rotation pressure derived from
service metadata and prior probe/cursor observations. `apply` is the explicit
mutation verb;
`--max-events` bounds one invocation. `resume` continues untouched planned
events but quarantines interrupted or uncertain remote outcomes instead of
repeating them. Add `--with-collect` when a clean batch should immediately
materialize verified local results into normalized inboxes. `cycle run` is the
default short path for an operator who does not remember the sequence: it plans
when no retained plan exists, applies or resumes safe planned work, collects by
default, and refuses `mutation-started`, staged, ambiguous, failed, stale,
expired, or abandoned events so the operator must use the evidence-bound
reconciliation path. `cycle_complete=true` means every planned event reached
verified post/probe evidence; command `success=true` alone may still describe a
clean partial batch or staged manual work.
`deployment recipes` is the service guide for the selected manifest. It renders
the configured service ids, adapter families, collector modes, retention,
preferred encodings, probe/cursor recipes, fixture cases, hazards, repair
notes, and operational roots without mutating any provider. It is the command
an operator should run before deciding whether a degraded service needs a
repost, a different exact probe, a wait for rate-limit expiry, or replacement
by another service family.

Successful normalized adapter responses are content-addressed beneath
`city-b-cycle-results/`; the existing placement and distribution receipt files
remain the detailed evidence. Failure output is not retained wholesale.

Every event transition is also appended to an immutable hash-linked history
before the current-state projection is replaced. `cycle status` reports a
one-record-ahead history without repairing it; the next locked apply, resume,
reconcile, or collect operation repairs only that cryptographically linked
crash window. Any wider disagreement is corruption and fails closed.

An ambiguous or manually staged result is an operator decision, never an
excuse for an automatic retry. Reconcile it with a small JSON evidence file:

```json
{"kind":"cityb.reconciliation.v1","cycle_id":"CYCLE_HEX","idempotency_key":"EVENT_HEX","outcome":"verified","retrievable":true,"parseable":true,"digest_match":true,"authority_verified":true,"basis":"independent fetch and signed archive verification"}
```

```sh
cityb cycle reconcile template --root ./city-b-artifacts \
  --event EVENT_HEX --outcome verified --out ./reconciliation.json
$EDITOR ./reconciliation.json
cityb cycle reconcile --root ./city-b-artifacts \
  --deployment ./city-b.toml --event EVENT_HEX --outcome verified \
  --evidence ./reconciliation.json --json
```

The template deliberately sets every factual assertion to `false`. `cycle
next` is side-effect free and selects one exact apply, resume, recovery,
reconciliation-template, terminal-review, or collection command from the
verified current state; it does not fill evidence claims on the human's behalf.

Use `outcome=retry-safe` only with `"mutation_absent":true`; it explicitly
returns an ambiguous/failed event to `planned`. `outcome=abandoned` is a
terminal accounting decision. All evidence is cycle- and event-bound,
content-addressed, and retained separately from the adapter result.

`collect` is the local, non-network handoff: it takes only the exact payload
paths named by verified adapter results, checks that each remains under the
declared service target, and writes bounded content-addressed carrier objects
to each configured normalized inbox. Each inbox now has a `manifest.json`, a
deterministic `index.jsonl`, parser encoding/version facts, candidate counts,
service adapter, and provenance roots. The inbox contains no provider
credential or host source path. Tiny parses it using its normal receive path
and still adopts nothing until the signed archive gate succeeds.

`collect probe` is the remote receive foothold. It performs one read-only fetch
of each exact `--location` supplied by the operator, parses the body with the
shared pointer-format registry, writes a content-addressed raw carrier object,
writes a content-addressed probe receipt, and appends
`city-b-service-reliability.jsonl`. It does not crawl, search, infer a URL,
authenticate, or mutate the service. Every probe receipt records the requested
location, final location, whether the final location changed, redirect count,
HTTP status when available, parser facts, provider-health class, content digest
when bytes were retained, and service/root provenance fields. A successful probe
proves that a declared service/lane/location still carries the expected pointer
in the selected encoding; later `cycle preview`, `cycle plan`, and `cycle next`
use those observations to rank candidate services and recommend repairs.

`collect cursor` is the first bounded discovery path. It fetches one
operator-declared listing URL or file, stores the listing bytes under
`city-b-collector-remote-probes/listings/`, extracts exact candidate locations,
probes at most the configured request budget, and writes a current plus
historical cursor report under `city-b-collector-cursors/SERVICE/`. It records
listing digest, listing object path, source final location, source redirect
count, HTTP status when available, and a continuation object when a documented
listing exposes `next`, `next_url`, `nextCursor`, `endCursor`, or an equivalent
field. Every new current cursor report also records `previous_cursor_sha3_256`
when a prior current report exists, so the receive history can prove what cursor
state was replaced without making the listing itself authoritative. It is still
read-only with respect to the provider. It is not a general crawler. Cursor
success means at least one discovered candidate carried the current expected
pointer; stale or irrelevant candidates remain counted as failures and
`partial_failures=true` so ranking can learn from them. Cursor discovery is
mode-aware: `exact-local` and `plain-url-list` keep the original
simple list behavior; `operator-static-index` and `static-index` parse HTML
`href`/`src` plus JSON URL fields and resolve relative paths; `json-url-fields`,
`gist-snippet-raw`, and `release-assets` prefer provider-shaped JSON fields;
`returned-url-only` accepts only exact returned URLs or files and reports that
the service is not enumeration-capable; `plugin-cursor` preserves the external
adapter seam; and `not-enumerable` records a named refusal instead of inventing
discovery.

Fresh successful probe or cursor observations now count as existing coverage
for the current pointer/lane/service before the planner schedules more posts,
but only inside the deployment's `observation_fresh_epochs` window. Older rows
inside `observation_decay_epochs` can still affect ranking and rotation
pressure; rows beyond the decay window do not suppress posting. That means a
cycle can spend fewer mutations when the receive plane already proves a
service is carrying the current material, without letting last week's sighting
create false freshness. Service request budgets, request costs, root request
budgets, and rate windows are enforced across a planned cycle so one service or
one correlated root cannot consume the whole operator run.

`collect fixture` is the offline real-service replay path. A fixture JSONL file
uses one record per captured provider observation:

```json
{"kind":"cityb.collector-fixture.v1","service":"catbox","lane":"mirror","location":"https://example.invalid/final-url","final_location":"https://example.invalid/final-url","redirect_count":0,"http_status":200,"encoding":"syntactic-semver","expected_hex":"PACKED_POINTER_HEX","body_file":"captured-body.txt"}
{"kind":"cityb.collector-fixture.v1","service":"catbox","lane":"mirror","location":"https://example.invalid/missing","final_location":"https://example.invalid/gone","redirect_count":1,"http_status":404,"encoding":"syntactic-semver","expected_hex":"PACKED_POINTER_HEX","fetch_error":"curl fetch failed: The requested URL returned error: 404"}
```

`body_file` is relative to the fixture file unless absolute. Inline `body` is
accepted for tiny text captures. `fetch_error` records a captured failure
without performing a request. `final_location`, `redirect_count`, and
`http_status` are optional, but real captures should keep them when known so
replay can reproduce expiry, permission, rate-limit, redirect drift, and
provider-error behavior. Replay writes the same content-addressed probe receipts
and `city-b-service-reliability.jsonl` rows as `collect probe`, with
`source_kind=fixture-replay` and a fixture digest. Probe and reliability rows
now include `provider_health`: `verified`, `auth-or-permission`,
`moderation-or-expired`, `rate-limited`, `provider-error`,
`network-unreachable`, `network-or-provider-failure`,
`local-input-unavailable`, `content-missing`, `stale-or-wrong-content`,
`parser-mismatch`, `parser-corrupt`, or `unknown-failure`. Planner scores
apply stronger penalties to access, moderation, rate-limit, network, and
provider failures than to local fixture mistakes. The checked-in starter corpus
at `fixtures/cityb/free-service-replay/` is the recommended template for
captured free-service transcripts.

Run probes before planning when their reliability facts should affect the next
cycle. If reliability facts change after `cycle plan`, `cycle apply` will refuse
the stale plan because the deterministic recomputation no longer matches the
frozen plan bytes.

Use `collect fixture-template` before hand-authoring replay files:

```sh
cityb collect fixture-template --root ./city-b-artifacts \
  --deployment ./city-b.toml \
  --service catbox \
  --lane mirror \
  --out ./catbox-capture.jsonl \
  --all-cases \
  --json
```

The template is already checksum-valid for the current retained pointer and the
selected lane encoding. By default it writes the verified case; pass repeated
`--case NAME` flags or `--all-cases` to generate the adapter recipe's negative
cases, including parser mismatch, provider errors, network failures, expiry,
rate limit, or local-input failures where that adapter declares them. Replace
the generated location, status, error, and body fields with actual captured
provider facts, then replay it with `collect fixture`. This keeps field captures
compatible with the same parser, receipt, reliability, planner, and Biggun paths
used by live probes.

`cycle next` reads the active plan, current event projection, immutable history,
and service reliability facts. Its `command` field is the safe state-transition
or reconciliation command. Its `repair_command` field is the diagnostic or
repair foothold implied by provider health: deployment validation for access
failures, preview/repost or service rotation for expiry and missing content,
rate-window backoff for 429s, service-mode-aware `collect probe` or
`collect cursor` for network/provider failures, `format parse --encoding ...`
for parser failures, path inspection for local input failures, and history
replay when immutable history is ahead of the projection. The
`service_repair_queue` field ranks every degraded service/lane pair by provider
health, event state, observed failures, provider-health penalty, rotation
pressure, and rate window. Each queue entry also carries the adapter, collector
mode/source, `recipe_command`, `receive_command`, and
`fixture_template_command`. That queue is a repair list, not an alternate state
machine; the main `command` field remains the exact next transition command.

```sh
cityb collect probe --root ./city-b-artifacts --deployment ./city-b.toml \
  --service catbox --lane mirror --encoding syntactic-semver \
  --location https://example.invalid/exact-returned-url --require --json

cityb collect cursor --root ./city-b-artifacts --deployment ./city-b.toml \
  --service catbox --lane mirror --encoding syntactic-semver \
  --source https://example.invalid/operator-known-listing.json \
  --max-requests 4 --require --json
```

Only one planner/applicator may own a retained root at a time. City B enforces
this with a birth-pinned operator lock and safely recovers stale locks; a second
human or automation process receives a named refusal rather than racing the
same idempotency event.

`cityb evidence curate` is the dry-run-first bridge from retained soak output to
the checked-in truth corpus. Preview it after `evidence sync`; apply only the
manifested selection with the generated generation- and fingerprint-pinned
`--apply` command. It deduplicates bodies by SHA3-256 while
preserving provider/date/outcome/transport/encoding/size-band facts and unique
adversarial material. A mixed same-day outcome scope additionally preserves
ordered observation identities, preventing a later recovery from being folded
into an earlier byte-identical success that preceded a failure. Applied
curation also removes verified raw monitor mirrors and bounds byte-identical
residue by age and size. Repeating preview after apply should report zero prune
decisions. Default JSON is bounded;
`--verbose` emits the full manifest. Monitor readiness then separately requires
that selected fixture additions have been reviewed into source control, so a
sealed local watermark cannot hide an untracked corpus delta.

## 1. Build the canonical state

Create the signed archive and pointer using the ordinary CityB authority path.

The important invariant is unchanged:

- the bundle is canonical;
- the pointer is discovery material;
- the service is transport only.

## 2. Initialize the workspace

```sh
cityb dead-drop init --root ./city-b-drops
cityb dead-drop adapter doctor --root ./city-b-drops
cityb dead-drop plan --root ./city-b-drops --json
cityb dead-drop substrate score --root ./city-b-drops --json
```

This gives the operator:

- feed/import files for the declared substrate set;
- `city-b-adapters.md` and `city-b-adapters.jsonl`;
- a lane-planning report that groups adapters into pointer, wakeup,
  route-hint, and mirror roles;
- an inspectable substrate registry and score baseline.

In a retained `cityb run --root DIR` workspace, the
operator should start from these generated files instead of reconstructing
intent from raw JSON:

- `city-b-operator-surface.md`
- `city-b-operator-surface.json`
- `city-b-operator-lanes/`

`city-b-operator-surface.*` is the human and machine playbook. It compiles:

- quick proof/triage commands;
- lane-preferred adapter families;
- a quick foothold and a lane-aligned foothold for each lane;
- one retained command surface that can preview or execute those footholds
  without hand-copying a raw `dead-drop post` invocation;
- ready-made one-envelope footholds for pointer, heartbeat, route-hint, and
  mirror work;
- the listener interpretation rules that keep carriers in the discovery plane.

## 3. Generate the placement plan

```sh
cityb dead-drop schedule --root ./city-b-drops --epoch E --beacon BEACON --pointer POINTER
cityb dead-drop envelope --root ./city-b-drops --epoch E --beacon BEACON --pointer POINTER --substrate status-thread
```

The schedule decides where material should go. The envelope decides exactly
what one placement is allowed to contain. The plan command decides which
adapter families are sensible for continuity, wakeups, route hints, and
mirrors before the operator starts posting.

The retained operator-lane directory adds a narrower surface on top:

- `city-b-operator-lanes/pointer-default.json`
- `city-b-operator-lanes/heartbeat-default.json`
- `city-b-operator-lanes/route-hint-default.json`
- `city-b-operator-lanes/mirror-default.json`

Those are ready-made single-envelope footholds. They are not new authority.
They are convenience artifacts generated from the retained rendezvous plan so
the human can make one sensible move without hand-authoring an envelope first.

## 4. Execute placements

Today, the implemented posting paths are:

```sh
cityb dead-drop post --root ./city-b-drops --adapter local-file --target ./city-b-drops/local-posts --against ./city-b-chain --require
cityb dead-drop observe ./city-b-drops/local-posts --root ./city-b-drops --against ./city-b-chain --require
cityb dead-drop post --root ./city-b-drops --adapter manual-drop --target ./city-b-drops/manual-packets --against ./city-b-chain
cityb dead-drop post --root ./city-b-drops --adapter static-http --target ./site-root --base-url http://127.0.0.1:8080 --against ./city-b-chain --require
cityb dead-drop post --root ./city-b-drops --adapter filehost-generic --target ./filehost-packets
cityb dead-drop post --root ./city-b-drops --adapter filehost-generic --target ./filehost-packets --download-url https://example.invalid/status-thread-e5-s4.txt --against ./city-b-chain --require
cityb dead-drop post --root ./city-b-drops --adapter git-release-generic --target ./release-packets
cityb dead-drop post --root ./city-b-drops --adapter object-store-generic --target ./object-packets
cityb dead-drop post --root ./city-b-drops --adapter github-release --target ./github-release-packets
cityb dead-drop post --root ./city-b-drops --adapter gitlab-release --target ./gitlab-release-packets
cityb dead-drop post --root ./city-b-drops --adapter netlify-drop --target ./netlify-drop-packets
cityb dead-drop post --root ./city-b-drops --adapter github-pages --target ./github-pages-packets
cityb dead-drop post --root ./city-b-drops --adapter gitlab-pages --target ./gitlab-pages-packets
cityb dead-drop post --root ./city-b-drops --adapter codeberg-pages --target ./codeberg-pages-packets
cityb dead-drop post --root ./city-b-drops --adapter codeberg-release --target ./codeberg-release-packets
cityb dead-drop post --root ./city-b-drops --adapter file.io --target ./fileio-packets --against ./city-b-chain --require
cityb dead-drop post --root ./city-b-drops --adapter uguu --target ./uguu-packets --against ./city-b-chain --require
cityb dead-drop post --root ./city-b-drops --adapter termbin --target ./termbin-packets --against ./city-b-chain --require
cityb dead-drop post --root ./city-b-drops --adapter storage.to --target ./storage-to-packets --against ./city-b-chain --require
cityb dead-drop post --root ./city-b-drops --adapter github-gist --target ./github-gist-packets --against ./city-b-chain --require
cityb dead-drop post --root ./city-b-drops --adapter gitlab-snippet --target ./gitlab-snippet-packets --against ./city-b-chain --require
cityb dead-drop post --root ./city-b-drops --adapter filebin --target ./filebin-packets --against ./city-b-chain --require
cityb dead-drop post --root ./city-b-drops --adapter paste-rs --target ./paste-packets --against ./city-b-chain --require
cityb dead-drop post --root ./city-b-drops --adapter dpaste --target ./dpaste-packets --against ./city-b-chain --require
cityb dead-drop post --root ./city-b-drops --adapter 0x0 --target ./0x0-packets --against ./city-b-chain --require
cityb dead-drop post --root ./city-b-drops --adapter catbox --target ./catbox-packets --against ./city-b-chain --require
cityb dead-drop post --root ./city-b-drops --adapter litterbox --target ./litterbox-packets --against ./city-b-chain --require
cityb dead-drop post --root ./city-b-drops --adapter tmpfiles --target ./tmpfiles-packets --against ./city-b-chain --require
cityb dead-drop post --root ./city-b-drops --adapter plugin-external --target ./plugin-packets
```

`local-file` proves the envelope, receipt, and observation model without any
external publication.

`manual-drop` stages operator publication packets for lawful external services:

- carrier-shaped payload
- posting guide
- exact receipt command template
- fetch/observe guidance for the real published content

It does not record a distribution receipt until the operator records an actual
public location.

`static-http` is the boring live remote-shaped path:

- write the carrier-shaped file into an operator-owned static docroot;
- derive the public URL from `--base-url` plus the relative file path;
- fetch that exact URL back through HTTP;
- record normalized placement and distribution receipts with probe facts.

This makes it appropriate for simple local/static servers and plain document
roots where bytes can be checked back deterministically.

`filehost-generic` is the next step up in abstraction:

- stage a deterministic upload packet under a local target;
- let the operator upload that payload through any lawful file-host workflow;
- optionally probe one exact final download URL if the operator already knows
  it;
- refuse to invent remote path derivation rules that belong to a service plugin.

`git-release-generic` and `object-store-generic` preserve the same rule:

- City B stages deterministic local packets and receipt/fetch helpers;
- the operator owns the actual release or object-store mutation path;
- City B only probes an exact declared final URL, never a guessed one.

`github-release`, `gitlab-release`, `netlify-drop`, `github-pages`,
`gitlab-pages`, `codeberg-pages`, and `codeberg-release` are service-specific
staged operator-owned paths:

- City B writes deterministic provider-specific packets and posting guides in
  core;
- the operator owns auth plus the real release, Pages, or Netlify UI/CLI
  mutation step;
- City B only probes an exact declared final public URL, never an inferred one.

`filebin`, `paste-rs`, `dpaste`, `paste-c-net`, `nullpaste`, `0x0`,
`catbox`, `litterbox`, `tmpfiles`, `file.io`, `uguu`, `termbin`, `sendit`,
`temp-sh`, `storage.to`, `github-gist`, and `gitlab-snippet` are now the
built-in public-service adapters:

- City B stages the exact payload under a local packet directory;
- the Rust adapter performs the HTTP upload itself;
- the returned or derived public location is probed immediately;
- the same normalized receipt model is preserved.

`termbin` is the transport-diversity exception inside this group: publication
uses a raw TCP upload and observation returns to the normal HTTP probe path.

`plugin-external` remains the explicit service-adapter seam for everything
that does not yet belong in core:

- City B stages a deterministic plugin packet and contract under a local target;
- one reviewed local executable may mutate the real service and return
  normalized placement/probe facts on stdout;
- City B still owns the envelope, receipt schema, failure names, and audit
  model.

Future operator-owned service adapters should preserve the same workflow shape:

1. emit placement
2. normalize receipt
3. probe/observe
4. score/rotate

The practical operator surface is now:

1. `cityb exercise --root DIR --brief --json` to prove the retained run.
2. `cityb foothold --root DIR --json` to see the default ready-made
   pointer foothold, its target packet directory, and the alternate
   lane-aligned move.
3. Optionally inspect `city-b-operator-surface.md` and
   `city-b-operator-lanes/` if the operator wants the longer retained rationale
   or the raw envelope artifacts.
4. Execute one move with `cityb foothold post --root DIR ...`.
5. Re-run `cityb brief --root DIR --json` to see whether the foothold
   changed posture.

That keeps posting easy without pretending the service itself is authority.

The intended fast-path examples are:

```sh
cityb foothold --root ./city-b-artifacts --json
cityb foothold --root ./city-b-artifacts --lane pointer --mode aligned --json
cityb foothold post --root ./city-b-artifacts --lane pointer --adapter local-file --brief --json
```

`foothold` is intentionally narrow:

- preview mode is side-effect free and reads only retained City B operator
  state;
- `post` executes exactly one ready-made foothold and then refreshes the
  retained governance reports;
- `local-file` automatically runs the matching observe step so the operator gets
  an immediate end-to-end proof path;
- service-specific requirements stay explicit: `static-http` still requires
  `--base-url`, and `plugin-external` still requires `--plugin-command`.

## 5. Review health

```sh
cityb brief --root ./city-b-artifacts --json
cityb handoff-check --root ./city-b-artifacts --json
cityb dead-drop debt --root ./city-b-drops --against ./city-b-chain --current-epoch auto --max-age 2 --min-media 2
cityb dead-drop negative-map --root ./city-b-drops --against ./city-b-chain --current-epoch auto --max-age 2 --min-media 2
cityb dead-drop explain --root ./city-b-drops --against ./city-b-chain --current-epoch auto --max-age 2 --min-media 2
```

`cityb brief` is the shortest retained triage path. It tells the operator
the current posture, archive state, gap counts, the retained operator-surface
path, the lane-default directory, and the first few retained next actions
without requiring them to read every underlying governance report.

`city-b-operator-surface.md` is the longer retained posting path. It tells the
operator which lane to start with, which ready-made envelope file to use, which
adapter family is preferred for that lane, and what listeners will do with the
resulting carrier bytes.

`cityb foothold` is the shortest retained posting path. It compiles one
ready-made move directly from the retained operator surface and exposes the
alternate lane-aligned move when it differs.

`cityb handoff-check` is the portable operator gate. It keeps the same
retained brief, then exports and verifies both the public tiny-node kit and the
public recovery capsule in one command. The handoff gate requires the retained
chain, council, governance, pointers, active main-node states, and every
receive-side artifact that crosses the field boundary. Biggun's disposable
hostile-prune/fork mirrors and hostile probe workrooms remain part of the full
retained-city verification suite, but their absence cannot invalidate a
production field pack that does not contain them.

The deeper dead-drop reports should still provide exact next actions:

- which placements are fresh;
- which have gone stale;
- which never produced usable observation;
- which failure domains are underrepresented;
- what to rotate next.

`city-b-service-reliability.jsonl` is the retained measurement input for later
cycles. It is intentionally simple append-only JSONL: one probe result records
the service, adapter, lane, exact location, expected pointer, selected
encoding, observed epoch, whether that encoding survived, success flag, parser
counts, and probe receipt digest. Planning does not treat this as authority. It
only uses the facts as a ranking, freshness, decay, and coverage input after
the signed archive and deployment policy have already determined which services
are eligible.

## 6. Export recovery evidence

```sh
cityb dead-drop capsule export --root ./city-b-drops --against ./city-b-chain --out ./city-b-recovery-capsule
cityb-node dead-drop capsule verify --root ./city-b-recovery-capsule --json
cityb handoff-check --root ./city-b-artifacts --force --json
```

This lets the operator hand off the public receive-side evidence package without
also handing off publisher-private material.

## What “easy” should mean

City B is easy for the operator when:

- one command initializes the workspace;
- one registry explains what adapters exist;
- one recipe report explains how configured services should be posted, probed,
  replayed, and repaired;
- one report explains current health;
- one fixture-template command creates a valid replay file before field capture;
- one narrow command previews and executes the first sensible move;
- one ranked service repair queue explains degraded provider work;
- one operator surface explains the longer rationale behind that move;
- one lane-default directory gives the operator immediate footholds;
- one distinction exists between the quick first move and the lane-aligned
  durable move;
- one recovery artifact crosses the handoff boundary.

The operator should not have to remember ad hoc provider syntax, post-hoc
naming rules, or undocumented service-specific conventions.

## What remains to build

The next practical layer is not more protocol theory. It is provider-specific
receive work built on top of the existing exact-location probe seam, plus
narrower service-specific adapters where the free service adds a genuinely new
failure mode. `plugin-external` remains reserved for services that still need
field experimentation before they are worth promoting into the binary.

`static-http`, `filehost-generic`, `git-release-generic`,
`object-store-generic`, `github-release`, `gitlab-release`, and
`netlify-drop` are implemented operator-owned paths. `filebin`, `paste-rs`,
`dpaste`, `paste-c-net`, `nullpaste`, `0x0`, `catbox`, `litterbox`,
`tmpfiles`, `file.io`, `uguu`, `termbin`, `sendit`, `temp-sh`, and
`storage.to` are implemented no-account or optional-account public-service
paths. `github-gist`, `gitlab-snippet`, `github-pages`,
`gitlab-pages`, `codeberg-pages`, and `codeberg-release` are implemented or
staged native free account-backed paths with recipe metadata.
`plugin-external` remains the generic executable integration seam for
everything else.

Those should be added one at a time, with the same normalized receipts,
explicit mutation posture, exact-location health probes, and reliability
feedback already used by the local-double and free-service paths.
