# City B provider expansion plan

CityB should grow providers by operator value, not by brand count. The useful question is not “how many free services did we find?” It is “which additional receive behavior, failure mode, topology root, listing primitive, retention family, or operator workflow did this provider teach the system?” This document is the provider-expansion plan for the next phase of CityB.

The invariant stays fixed: carriers are discovery, archives are truth, and council signatures are authority. A provider may help the operator place a pointer, route hint, heartbeat, archive fragment, listing token, rendered card, or mirror. It never authorizes adoption. All provider growth must preserve that split.

## Operator outcome

The operator needs a small, repeatable loop:

```sh
cityb provider candidates plan --json
cityb provider candidates capture --provider PROVIDER --json
cityb up --root target/cityb-provider-candidates/root --deployment target/cityb-provider-candidates/free-candidate-pool.toml --service-set free-candidate-pool --json
cityb deployment recipes --file target/cityb-provider-candidates/free-candidate-pool.toml --service PROVIDER --json
cityb collect fixture-template --root target/cityb-provider-candidates/root --deployment target/cityb-provider-candidates/free-candidate-pool.toml --service PROVIDER --out target/cityb-provider-candidates/PROVIDER-fixtures.jsonl --json
```

Those commands deliberately do not publish to a public service. Candidate work starts by generating a retained root, deployment metadata, service recipes, and fixture templates. The human/operator or a later native experiment supplies lawful live observations, exact final URLs, bodies, failures, redirects, expiry behavior, rate limits, listing pages, screenshots, or rendered pages. Only after replay and parser agreement should CityB gain provider-specific native code.

## Portfolio model

CityB should maintain a balanced provider portfolio. A portfolio full of ten paste sites behind the same CDN is weak even if every site is green. A portfolio with several receive behaviors, retention families, topology roots, and failure modes teaches the planner more and gives the operator better decisions.

| Provider type | Why it matters | First evidence to collect | Promotion lane |
|---|---|---|---|
| No-account exact-byte text/file services | Lowest operator friction and best Tiny fit when returned URLs fetch exact bytes | returned URL, exact body, expiry/rate-limit failure, final-location facts | `free-wide`, then `free-stable` after date-separated exact captures |
| Public listings and firehoses | Solves rendezvous when the generated URL is not known beforehand | repeated listing pages, cursor behavior, false-positive rejection, parser cost | listing/research, then at most one Tiny sweep provider at a time |
| Deterministic slots and static indexes | Lets listeners derive where to probe instead of scraping everything | slot derivation, conflict handling, TTL, exact path probe | operator-owned or static path lanes |
| Free-account object stores and release/page surfaces | Durable mirrors and recovery packets controlled by the operator | account-owned public URL proof, object metadata, retention and delete semantics | manual/operator-owned mirror lanes |
| Image/rendered/OCR carriers | Expands discovery when text/file hosts are hostile, but often non-exact | screenshot/OCR body, checksum-visible token, OCR errors, rendered-token policy | discovery lane unless exact bytes are provable |
| Redirect and short-link carriers | Useful route hints and reachability diversity, weak as mirrors | redirect target stability, status code, final URL, token preservation | route-hint/discovery lane |
| Open/federated protocols | Can add push-style discovery without scraping HTML | relay retention, replay behavior, spam/challenge failure, parser agreement | volatile pointer/route-hint lane |
| Public anchors | Gives amnesic nodes a slow fallback when daily drops expired | inclusion/consistency proof, split-view stance, epoch skip-list semantics | anchor recovery lane |
| Negative and drift providers | Teach the monitor and planner what failure looks like | dated failures, provider-health class, body/status/redirect transcript | drift bench or retired |

The first rule for new providers is “one native adapter per new behavior, not one native adapter per similar brand clone.” If five services all behave like simple returned-URL file hosts, the first two may justify native adapters and the rest may stay generic until they prove different expiry, topology, rate limit, listing, or receive semantics.

## Value scoring

`cityb provider candidates plan` ranks candidates by practical operator value and includes a priority-0 newest-tranche batch. The current score favors no-account providers, filehost/image/object-store coverage, pointer/heartbeat/route-hint/mirror lane usefulness, and missing fixture value. The newest-tranche batch is not a promotion signal; it is a work-queue affordance so the operator can work the latest staged candidates before maintainers add another tranche. The scoring should stay explainable.

The next score improvements should use evidence, not guesses:

- exact-byte success dates and failure dates from checked-in fixtures;
- retained monitor success/failure dates waiting outside the repo;
- topology roots from offline metadata and opt-in live enrichment;
- account friction and whether anonymous use still works;
- retention/TTL and observed expiry behavior;
- listing/cursor semantics for rendezvous;
- Tiny parser cost and Goldilocks/Tiny/Biggun parser agreement;
- remote mutation risk and whether posting can be previewed without secrets;
- failure uniqueness, because a new rate-limit or challenge class can improve the planner even if the provider is never promoted.

## Candidate states

`free-candidate-pool` is not a live service set. It is a Rust-owned research queue that can produce conservative services using `filehost-generic`, `manual-drop`, and `object-store-generic`. Those generic adapters are staging paths. They are not proof that a candidate has a provider-specific live adapter.

Candidate states should remain narrow:

- `candidate-needs-fixture`: the provider may be useful, but CityB needs a final URL/body/failure fixture before native code.
- `candidate-manual`: a human or operator-owned browser/account flow is expected; keep it explicit.
- `candidate-free-account`: the useful path likely requires an operator-owned free account or bucket.
- `native-adapter-required`: promotion planning has reached the point where a provider-specific adapter id and fixture corpus are needed.
- `research-lane`: implemented enough to run in a bench, but not stable.
- `stable-lane`: repeated date-separated exact-byte evidence, parser agreement, topology review, and operator docs are present.
- `retired`: the provider is bad enough that the operator should stop spending cycles until new evidence says otherwise.

## Continuous soak and candidate growth

The retained monitor is the standing test facility. `cityb monitor install --live --enable-now` should be the normal long-running setup on one real machine. Each live run checks `free-stable`, rotates one research bench, collects declared public listing feeds through `rendezvous collect-firehose`, checks retained archive-sized soak state, runs evidence board and promotion checks, records a read-only `provider candidates plan` step, and runs the native candidate probe tranche. The plan step keeps the next candidate tranche visible; the native probe steps actually contact selected candidates through provider-specific Rust branches and classify current service behavior without pretending staged entries are stable. The authoritative current probe count and member list come from `cityb monitor plan --json`; prose deliberately does not duplicate either. The tranche is broader than only unpromoted candidates: it includes promoted providers as regression/repair probes; exact-byte onboarding candidates including EasySend, dropfile.dev, Warpbox, upload.83blue, pomf2/lain, isrv.nl, fsend.me, pb.plz.ac, paste.gg, AnonHost, readm3, MDShare, dpaste.com, mystb/Pastey, ship.page, shipsite.co, Capsule, Pastebin1s, Webionite Bin, hastebin.cc, paste.ivr.fi, PasteShare, Kodi Paste, PastyX, WaifuVault, ShareY, MSK Paste, dpaste.org, Python Discord Paste, and SquadRoom Paste; rendered-token or JSON-field carriers including Savedly, File2Share, PasteMyst, AnonPaste Lite, Telegraph, Laravel Paste, MantleDB, SuperJSONBlob, ExtendsClass JSON Storage, and Botoi Paste API; token-only, event, webhook, and receive-only carriers including Keyval, ntfy.sh, the EMQX/HiveMQ/Mosquitto public MQTT brokers, the Damus/nos.lol/Primal Nostr relays, Webhook.site, Botoi Webhook, Guerrilla Mail, GrabMail, Mail.gw, Mail.tm, Maildrop.cc, MeowMail, NenzMail, 1secmail, shitty.email, Smails, and TempY.email; classified repair, gated, challenged, proof-of-work, auth/captcha, Cloudflare, account-required, API-key-required, viewer-key-required, TLS-failed, stale-Haste, form-validation, server-error, or timeout hypotheses including Buzzheavier, FuckingFast, bzzhr.co, pste.us, Skunk Paste, paste.aaqa.dev, 0807.st, Pixeldrain, paste.hep.gg, FilePost, JSONBin.io, JSONStorage.net, JsonBlob, webhooks.sh, Npoint, Marke.st, PasteDB, Paste.org, Skyra Hastebin, Denizen Pastebin, and transfer.sh; and older negative or not-yet-stable behavior classes including Fileditch, Gofile, Oshi.at, put.re, sto-care, and take-me-to.space. Bashupload is currently a repair/regression probe and `free-wide` member, not a stable-lane provider, after repeated October 11-12 upload rejections. fars.ee, ShareNation, Originless, 1c3.ir, Pastebox-family services, requestcatcher.com, JSONKeeper, JSONStore.io, getpantry.cloud, envs.sh, ttm.sh, sharey.gay, tempditch.com, and stale Haste instances remain near-misses until their timeout, TLS, endpoint, DNS, session, API, receive-path, or form failures are repaired.

New candidates should first enter `free-candidate-pool` with conservative metadata. If a candidate has no native probe, the operator uses `provider candidates capture --provider PROVIDER` to generate the retained-root/deployment/recipe/fixture-template plan. If a candidate has a native probe, `provider candidates test --provider PROVIDER --live --json` performs a narrow provider-specific live experiment and reports command success separately from provider success. Add `--fixture-root DIR` to retain the run as replayable evidence: the probe uploads a normal checksum-valid CityB `log-field` token body, writes a `cityb.live-free-service-transcript.v1` row for every run, and writes a `cityb.collector-fixture.v1` row plus body file when the receive path is exact-byte. The retained monitor passes its fixture root to native candidate probes during live soaks, so `cityb evidence sync --apply` can import candidate evidence through the same path as stable and research-set captures. Upload-disabled, DNS-dead, TLS-mismatched, token-gated, rendered-page, and non-exact receive results are retained as useful negative evidence, not as promotion. `provider candidates promote --provider PROVIDER --json` distinguishes these cases: candidates without native Rust return `native-adapter-required`; native-probed candidates without enough exact replay dates return `promotion-evidence-required`; candidates with repeated exact-byte dates but no production capture adapter return `stable-capture-adapter-required`; only candidates that have evidence and a production adapter can proceed toward parser/topology/source review. Only date-separated exact-byte replay fixtures, parser agreement, topology review, and a source-level provider-set patch should move the candidate into a native research bench or `free-stable`.

The October 18 diversity tranche added three Nostr relays, the public NATS demo server, and two read-only IPFS gateways. Nostr and NATS are event-feed probes with deliberately different delivery semantics: Nostr uses signed public relay events and relay-policy retention; Core NATS is live at-most-once delivery. The IPFS probes are content-gateway health checks against a fixed known CID and report `remote_mutation=false`; they do not masquerade as anonymous pinning adapters. All six are in the installed monitor native-probe rotation, and mixed or negative results remain onboarding evidence rather than automatic promotion.

The October 20 protocol-diversity tranche adds shiftr.io, flespi, nostr.mom, OXTR, bitcoiner.social, Bluesky Jetstream, and four Arweave gateway routes. The native shiftr.io and Nostr probes publish a generated CityB payload and require exact delivery. The flespi probe verifies its account-token gate without publishing. Jetstream reads one bounded public cursor event without claiming write authority. Each Arweave gateway reads the same immutable quick-start transaction and records AR.IO wallet/release identity when the gateway exposes it; these are receive-route observations over one ledger, not four archive authorities. All ten run in the standing monitor and remain outside stable posting lanes until their own lane-specific evidence requirements are met.

The first September 28, 2026 pool expansion added ImgBB, IMGPile, ki.tc, Oshi.at, PixVid, sxcu.net, TransferNow, Uptomega, vgy.me, and ViKiNG FiLE. The second added GrosFichiers, Gulfup, Hexupload, Hostize, Hostuje, i by Tikolu, ImageBam, Imagenetz, ImageVenue, and Imouto. The third added Internxt Send, Kepkuldes, Lufi/AdminForge, Lutim, MyAirBridge, pCloud Transfer, pic.maxiol, Pikky, PlusTransfer, and QuickSendFile. The fourth added put.re, Ranoz, RapidFileShare, RapidGrab, Rapidshare.io, Riseup Share, Rootz, Send Anywhere, SendGB, SendSpace, Sendvid, SharePlace, Smash, Stashr, Streamable, Streamain, SwissTransfer, take-me-to.space, temp-files, and Tempcloud. The fifth added AISense Temporary Storage, Kawaii Files, and tmp0.cc after live one-shot exact-byte receive probes. The September 30, 2026 native-probe pass moved Stashr and temp-files from staged candidates into the monitored candidate-probe tranche and retained first exact-byte candidate replay fixtures for both providers. The October 7, 2026 source review promoted AISense Temporary Storage, bashupload.app, Kawaii Files, Stashr, temp-files, Tempcloud, and tmp0.cc from repeated exact-byte candidate probes into production Rust adapters, `free-stable` membership, and archive-shard spray eligibility. Bashupload returned to the wider repair lane after repeated October 11-12 stable upload rejections. Beacon.host followed on October 10 after date-separated exact-byte evidence and source review. The first October 13, 2026 expansion added native probes for EasySend, Savedly, dropfile.dev, File2Share, Warpbox, upload.83blue, and pomf2/lain; the first retained live pass proved exact-byte receive for five of them and non-exact public pages for Savedly/File2Share. The second October 13 expansion added isrv.nl, fsend.me, pb.plz.ac, paste.gg, fars.ee, ShareNation, Originless, and 1c3.ir; the first four gained exact-byte native probes, and the last four entered the near-miss ledger. The third October 13 expansion added AnonHost, readm3, MDShare, FuckingFast, bzzhr.co, pste.us, Skunk Paste, paste.aaqa.dev, 0807.st, Pixeldrain, dpaste.com, and paste.hep.gg, plus a native repair probe for existing Buzzheavier; AnonHost, readm3, MDShare, and dpaste.com produced first exact-byte candidate fixtures and the rest now have explicit repair/gated/discovery classifications. The fourth October 13 expansion added mystb/Pastey, ship.page, shipsite.co, Capsule, PasteMyst, and AnonPaste Lite; mystb/Pastey, ship.page, shipsite.co, and Capsule produced exact-byte candidate fixtures, PasteMyst initially produced JSON-field evidence and later gained a normalized-field-exact production adapter, AnonPaste Lite produced non-exact page evidence, and Capsule also has earlier token-missing receive evidence that keeps it on watch until later date-separated recapture. The fifth October 13 expansion added Pastebin1s, Webionite Bin, hastebin.cc, paste.ivr.fi, PasteShare, Kodi Paste, PastyX, WaifuVault, ShareY, and Telegraph; the first nine produced exact-byte candidate fixtures, while Telegraph produced rendered-token-visible public-page evidence. The sixth October 13 expansion added MSK Paste, dpaste.org, Python Discord Paste, Marke.st, PasteDB, Paste.org, Skyra Hastebin, Denizen Pastebin, Laravel Paste, and transfer.sh; MSK Paste, dpaste.org, and Python Discord Paste produced exact-byte candidate fixtures, and the remaining seven produced retained near-miss transcripts with account, TLS, stale-Haste, form-validation, rendered-token, or timeout classifications. The seventh October 13 expansion added MantleDB, SuperJSONBlob, ExtendsClass JSON Storage, Keyval, Npoint, JSONBin.io, JSONStorage.net, JsonBlob, ntfy.sh, Webhook.site, and webhooks.sh; MantleDB, SuperJSONBlob, and ExtendsClass later proved normalized-field exactness and gained production discovery adapters; Keyval and Webhook.site retained token-visible evidence; the remaining services produced classified repair or gate evidence. The eighth October 13 expansion added Botoi Paste API, Botoi Webhook Inbox, and SquadRoom Paste; Botoi Paste later proved normalized-field exactness and gained a production discovery adapter, while Botoi Webhook produced token-visible non-exact discovery transcripts, while SquadRoom Paste produced exact-byte candidate fixtures through its raw Markdown receive path. The ninth October 13 expansion added Guerrilla Mail, NenzMail, and 1secmail as receive-only temp-email candidates and gave FilePost a native API-key-required classifier. The tenth October 13 expansion added Mail.tm and Maildrop.cc as read-only temp-email discovery candidates. The candidate catalog now contains 260 providers, and the monitor keeps all 118 provider-specific native probes in rotation so promoted providers can continue producing regression and archive-capacity evidence while unpromoted providers continue to accumulate exact, non-exact, discovery, gated, receive-only, or not-yet-stable behavior classes.

## Promotion rules

A candidate becomes a native provider only after it has provider-specific evidence. Do not promote `filehost-generic`, `manual-drop`, or `object-store-generic` as if those adapter names were service identities.

The minimum native-adapter promotion packet is:

1. candidate id, URL, family, account posture, and intended lanes;
2. exact posting or manual staging recipe;
3. receive recipe with final URL, body rules, redirects, TTL, rate-limit and error behavior;
4. at least one dated fixture for success or an explicit negative fixture if the provider is a drift lesson;
5. parser-diff transcript over the fixture corpus;
6. topology/root review against the current portfolio;
7. docs entry naming what new behavior this provider adds;
8. operator command path for recapture, repair, and demotion.

Promotion to `free-stable` is stricter: require repeated date-separated exact-byte captures, no unresolved parser disagreement, sane root diversity, a production capture adapter or declared bench entry that can keep writing fixtures, and a provider dossier that recommends promotion. A same-day native probe rerun is useful freshness evidence, but it does not satisfy the date-separated fixture gate. Rendered-token, redirect-token, public-listing, and screenshot/OCR evidence can be very useful, but they should stay in discovery lanes unless exact bytes are proven. Archive-shard eligibility is an additional product lane: pointer-sized exact-byte success can admit a provider to `free-stable`, but real archive-spray failures from retained archive evidence should keep that provider in recapture/watch or archive-ineligible review until a later archive-sized exact success clears it.

## Recommended tranches

The next provider campaign should work in tranches instead of taking the top ten brands alphabetically.

1. No-account exact-byte scouts: choose a small batch of file hosts that might return public direct URLs with minimal friction. Goal: find exact-byte paths or useful failure fixtures.
2. Visual/rendered carriers: collect screenshots, rendered pages, OCR-ish bodies, and checksum-visible token behavior. Goal: improve non-exact discovery without pretending it is mirror evidence.
3. Durable operator-owned mirrors: test free-account object stores, pages, and release surfaces where the operator controls a public object. Goal: durable recovery packets and anchor-adjacent mirrors.
4. Manual cloud handoffs: document browser/account paths that are worth keeping as human-operated mirrors. Goal: amnesia recovery and emergency handoff, not automation.
5. Public listing/firehose providers: gather repeated listing fixtures before live readers. Goal: one additional firehose provider promoted only after Biggun agreement and parser-cost proof.
6. Negative/drift tranche: intentionally preserve bad providers with clear failure names. Goal: better monitor triage, demotion decisions, and planner refusal reasons.

## Evidence process

Every provider campaign should leave evidence in a shape the repo can replay:

1. choose the tranche with `cityb provider candidates plan --json`;
2. generate the candidate staging plan with `cityb provider candidates capture --provider PROVIDER --json`;
3. create or reuse the retained root/deployment from the generated command;
4. read `cityb deployment recipes` before live work;
5. produce fixture templates from the retained pointer;
6. run the legal live/manual experiment outside the generic candidate command;
7. save raw body, rendered body, screenshot/OCR output, HTTP status, redirect chain, final URL, TTL, and failure body as appropriate;
8. replay with `cityb collect fixture`;
9. compare parsers with Biggun before Tiny exposure;
10. update docs and provider metadata only after evidence justifies the behavior.

This is intentionally slower than “add ten adapters.” It prevents CityB from baking guesses into the binary and gives the operator a real inbox: what worked, what failed, what needs another date, and which provider type is missing.

## Native adapter seams

Provider-specific Rust belongs in the binary when it gives one of these long-term advantages:

- exact public receive semantics that the generic staging path cannot express;
- a stable API flow with bounded request count and no secret leakage into fixtures;
- provider-specific direct-download extraction or redirect normalization;
- listing/cursor behavior that improves rendezvous;
- documented TTL/rate-limit/moderation behavior that affects scheduling;
- a new failure class that improves provider health triage;
- Tiny-safe parser behavior that can be proven over corpora.

Provider-specific Rust does not belong in the binary merely to automate a fragile website form. If a service requires CAPTCHAs, abuse-prone browser interaction, or human account maintenance, keep it as a manual/operator-owned recipe until repeated evidence says otherwise.

## Operator reports to keep improving

The provider expansion loop should feed the existing cockpit surfaces:

- `cityb next` should name when provider evidence is waiting, which candidate tranche matters next, and whether stable providers need recapture.
- `cityb provider health` should remain the inbox over stable and research evidence.
- `cityb provider dossier PROVIDER` should be the promotion/demotion decision page.
- `cityb provider candidates plan` should be the front door for new provider hunting.
- `cityb provider candidates capture` should stage a safe evidence plan and never pretend generic adapters are native live paths.
- `cityb provider patch-plan` and `stable-plan` should edit source only as reviewable plans with evidence references.

## Next engineering priorities

1. Let the monitor continue accumulating date-separated evidence for existing native providers.
2. Use `provider candidates plan` to select tranches that add behavior diversity, not duplicate brands.
3. Build native adapters only after exact provider evidence exists.
4. Add screenshot/OCR capture fixtures as first-class evidence, not text-only imitations.
5. Add one more public listing provider only after repeated real listing captures and Biggun parser agreement.
6. Teach provider scoring to incorporate checked-in fixture evidence and retained monitor evidence.
7. Add source-level native-adapter creation checklists so a new provider cannot skip docs, recipes, replay, topology, and demotion commands.
8. Keep `free-stable` boring; send weird but useful carriers to discovery lanes.
