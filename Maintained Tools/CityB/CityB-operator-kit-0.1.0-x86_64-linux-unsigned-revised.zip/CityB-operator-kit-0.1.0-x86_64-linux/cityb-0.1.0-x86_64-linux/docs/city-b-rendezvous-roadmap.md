# City B rendezvous roadmap

CityB's next strategic problem is the Rendezvous Problem: receive-only nodes need to know where to look, while the operator needs a straightforward way to choose, post, observe, repair, and explain those locations. The existing rule stays intact: carriers are discovery, archives are truth, and council signatures are authority. This roadmap is about making discovery durable, diverse, measurable, and easy to operate.

The main change is to classify providers by how they function for rendezvous, not merely by brand or adapter name. A provider can be useful because it has a public recent feed, deterministic slugs, durable public anchors, returned URLs, volatile push events, image/social rendering, archive byte storage, or external topology evidence. Those are different receive protocols and they deserve different planner behavior, fixtures, and operator advice.

The immediate execution plan is [city-b-next-rendezvous-tranche.md](city-b-next-rendezvous-tranche.md). The Rendezvous Evidence Workbench is implemented. Pastefy is now the third admitted retained-local listing source; the active tranche is keeping all three healthy while reviewing a genuinely distinct fourth, bounded multi-cycle Tiny lookback, repeated upstream anchor-continuity evidence, and measurable cache/parser cost.

## Operator jobs

The operator should not have to think in terms of every adapter's implementation. They need the tool to answer a small set of recurring questions:

1. **What should I run now?** Print the shortest safe next command, the expected mutation, and the reason it is needed.
2. **Where will listeners look?** Show a compact plan grouped by rendezvous class, lane, epoch window, service, and fallback.
3. **What is safe to publish?** Separate dry-run planning, local fixture proof, explicit live posting, and public exposure. No command should silently move from one category to another.
4. **What failed and what do I do about it?** Classify failures as provider drift, rate limit, expired listing, missing cursor, topology collapse, parser mismatch, amnesia fallback, or insufficient evidence; attach one repair command or capture command.
5. **How much diversity do I really have?** Collapse services by account, domain, CDN, ASN, hosting provider, API family, and observed provider-health bucket.
6. **Can a field node recover from here?** Explain whether Tiny has a current plan, a next plan, an anchor fallback, enough firehose/listing coverage, and enough archive/fragments to adopt or name a refusal.
7. **What is public?** Say which artifacts are public carrier bytes, which are operator-only retained evidence, which are Tiny kit inputs, and which contain credentials or delete handles that must not be exported.

The preferred operator surface is a guided ladder:

```text
cityb rendezvous check      # read-only diagnosis of provider classes, gaps, and risks
cityb rendezvous next       # one exact next action, with dry-run/live distinction
cityb rendezvous plan       # full deterministic plan and listener schedule
cityb rendezvous apply      # explicit live/local mutation only after preview, reserved
cityb rendezvous collect-firehose --service SERVICE --max-pages 1 --max-bytes 65536 --max-candidates 64
cityb rendezvous explain    # human report: what happened, what failed, what to do next
```

`cityb rendezvous check|classify|plan|next|diff|explain|doctor|firehose-fixture|promote-firehose` is the implemented rendezvous surface. It reads durable service metadata and checked-in evidence, classifies carrier function, reports missing classes and topology, and prints one next action without default network or retained-root mutation. Posting declarations and receive-only sweeps stay distinct: `class_counts` names the selected service set, while `effective_class_counts` credits admitted retained-local sweeps. `promote-firehose` requires date-separated service fixtures, checksum-valid tokens, false-positive rejection, observed cursor/expiry facts, Biggun agreement, and an intentional source declaration. Pastebin Archive, GitHub public Gists, and Pastefy are currently promoted. Pastefy uses a provider-specific 8 MiB Goldilocks ceiling because its October 20 body was 6,026,688 bytes; Tiny consumes only its retained local projection. FragBin retains its parser, fixtures, and bounded live recheck but is no longer declared after HTTP 500 on October 17 and October 18; fixture history alone therefore cannot keep it promoted. `collect-firehose` remains the bounded explicit live-reader surface and Tiny consumes only retained local objects after archive-chain verification.

## Priority ladder

The boring foundation is built: exact surfaces, provider classification,
listing fixtures, three admitted firehose readers, state-ratcheted slots, signed
pointer-chain members, operator repair surfaces, erasure distribution, public
anchor clients, and topology evidence all exist. The active ladder is now:

1. **Fourth independent listing source.** Keep Pastebin Archive, GitHub public
   Gists, and Pastefy admitted. Keep FragBin suspended after October 17–18
   failures until a later recovery is captured. Admit another source only after
   repeated dated reads, parser agreement, cost bounds, and topology review.
2. **Deeper multi-cycle Tiny lookback.** Biggun now proves three signed chain
   members, a two-epoch recovery span, fallback to the preceding verified
   member, and final anchor-required refusal. Extend only when real field-pack
   and anchor evidence justifies a broader bounded history.
3. **Empirical public-anchor continuity.** Accumulate real Rekor/CT consistency,
   signature, inclusion, key-rotation, rollback, and split-view evidence beside
   the existing drand and local proof corpus.
4. **Bounded listing cache and cost truth.** Measure duplicate rate, response
   bytes, parser time, false positives, cursor behavior, and expiry without
   letting retained seen-state grow without bound.
5. **Only then expand stranger carriers.** Nostr, visual carriers, additional
   traffic shaping, and fountain-style profiles remain Biggun-led research
   until the ordinary discovery and recovery paths are boring.

The executable acceptance plan is
[city-b-next-rendezvous-tranche.md](city-b-next-rendezvous-tranche.md).

## Provider function classes

| Class | How nodes discover it | Operator action | Node action | Main proof needed |
|---|---|---|---|---|
| Public firehose/listing | recent-paste feed, public index, log, timeline, or cursor | post a token-shaped pointer, fragment, or route hint into body/title/metadata | sweep bounded windows with quick parsers, verify checksum, then fetch referenced bytes | cursor semantics, false-positive rate, retention, listing rate limits |
| Deterministic slot | predictable path, slug, query key, object name, or status field | post to a derived slot during an epoch window | derive the same slot and probe it | PRF inputs, time/beacon tolerance, expiry, collision handling |
| Pointer chain | field pack seed URL plus next-cycle plan inside signed archive | keep each archive carrying the next rendezvous plan | after adoption, read the next plan and update listener schedule | missed-epoch fallback, archive-root binding, rollback refusal |
| Fragment/share lane | partial pointer, key, or archive fragment across multiple carriers | split and place shares/chunks across independent roots | reconstruct only after enough independent observations | threshold math, source-root diversity, malformed-share refusal |
| Erasure/archive lane | parity/fragments of larger archive bytes across many hosts | encode payload into redundant chunks and spray them across services | fetch any sufficient subset and reconstruct exact archive bytes | chunk manifest, reconstruction hash, partial-host loss model |
| Volatile event relay | signed events from relays or gossip-like networks | publish micro-pointers or route hints into relays | subscribe/poll relays within TTL and verify event content | relay expiry, spam refusal, replay, route diversity |
| Visual/social carrier | image, rendered page, screenshot, OCR card, issue/comment rendering | upload token-bearing or data-bearing rendered media | OCR/decode/extract and verify checksum/signature | OCR error model, rendered-token policy, exact-vs-non-exact lane semantics |
| Public anchor | append-only transparency log, public randomness round, durable public ledger | periodically commit skip-list pointers or epoch roots | recover after long amnesia by checking slow anchors | inclusion proof, consistency proof, split-view handling |
| Topology/canary evidence | external reachability and ASN/CDN facts | run operator-side probes or import telemetry | no field-node mutation; Tiny consumes only compiled listener decisions | provenance, freshness, root-decorrelation score |

The catalog now gives each compiled service durable rendezvous metadata: `rendezvous_classes`, `receive_behavior`, `enumerable`, `slot_policy`, `exact_byte_policy`, and `maintenance_posture`. That metadata replaces the old operator-side inference wherever a deployment supplies or defaults it. The next growth area is richer observed metadata for real firehoses, anchors, topology evidence, and visual carriers.

Each service should also carry a maintenance posture:

- **default:** suitable for ordinary `cityb up --free` style operation;
- **candidate:** implemented but still needs date-separated captures or root-diversity review;
- **drift bench:** useful for learning provider failures, not for easy operation;
- **manual:** requires human-owned placement or browser/operator action;
- **operator-owned:** controlled by the user or their organization;
- **retired:** known-bad until new evidence proves otherwise.

Retirement needs to be an ordinary operator action. If a provider starts returning CAPTCHA, abuse blocks, wrong bytes, malware interstitials, oversized bodies, or unstable redirects, `cityb next` should prefer "retire or quarantine this service" over repeatedly asking the operator to repost into a bad surface.

## Three foundational rendezvous modes

### 1. Scraping public firehoses with token formats

Many anonymous pastebins and uploaders expose public recent-drop feeds or listing pages. The operator may not control the generated URL, so the post must carry a recognizable CityB pointer encoding in the text, title, metadata, or rendered output.

CityB has shared pointer encodings such as semver-like build metadata,
log-field records, status timestamp forms, signed-event tags, and mnemonic-card
forms. The bounded reader path pulls declared listing windows, runs cheap
parsers, verifies embedded checksums, and only then retains candidate objects.
This architecture is implemented; the open work is adding a third independent
listing source and learning provider-specific cursor/expiry rules from repeated
captures rather than guesses.

Implemented fixture and reader work:

1. `fixtures/cityb/rendezvous-firehose/` contains the public-recents corpus plus provider-specific Pastebin Archive, GitHub public-Gist, FragBin public-paste, and Pastefy public-paste corpora with expected token counts, duplicate/stale lines, sanitized public listing rows, and false-positive noise. `cityb rendezvous firehose-fixture --firehose-fixture-root DIR --require --json` reports fixture file count, record count, expected tokens, extracted candidates, checksum-valid tokens, false-positive candidates, rejected false positives, parser encoding distribution, maximum body bytes scanned, maximum candidates per record, and case-level failures without contacting a provider.
2. The corpus is deliberately local-first. Live collection stays behind `collect-firehose --apply --source`, and retained-listing Tiny sweeps consume only Goldilocks-retained local objects.

Remaining evidence work:

1. Capture and admit one more independent public listing source.
2. Add provider-specific cursor and expiry policy only where repeated captures
   prove the semantics.
3. Keep Biggun's noisy-corpus, parser-cost, false-positive, and Goldilocks/Tiny
   agreement gates mandatory for promotion.
4. Keep unproven providers in research/listing-only lanes.

### 2. Deterministic slotted locations

Some services allow predictable paths, slugs, object names, query parameters, status fields, or operator-owned static paths. For those, the operator and nodes can derive an epoch slot instead of relying on a returned random URL.

The safe CityB form is not a public-seed-only DGA. Public beacon plus public city seed lets an adversary compute the same slot schedule as the fleet. The default derivation should be state-ratcheted:

```text
slot = PRF(previous_verified_archive_root, epoch, lane, service_id, beacon_round, deployment_salt)
```

Nodes that verified epoch `e-1` can derive where to look for epoch `e`. Nodes that missed the ratchet need explicit public fallback through the recovery capsule, slow anchors, or seed field-pack paths.

Current implementation:

1. `rendezvous plan --epoch E` is the read-only operator preview, and `dead-drop schedule` is its retained writer. Both use one shared implementation. They accept `--previous-root` or `--previous-root-file` and report the rendezvous mode, previous archive root source, lane, slot template, slot window, clock source, deployment-salt digest, schedule-level PRF input digest, per-substrate rank keys, and concrete `slot_location` values. The preview writes nothing; its next action reproduces the inputs in the schedule command.
2. Public-beacon schedules remain valid for bootstrap and local proof. When a previous verified archive root is provided, the rank key switches to the state-ratcheted PRF so schedule choice is no longer derived solely from public beacon material.
3. The emitted ratchet object now states whether a prior root is required, how Tiny should evaluate the plan, what fallback is expected after a missed ratchet, the slot slug charset/length, the conflict policy, explicit fallback route labels, and selected slot locations. Public bootstrap schedules report `ratchet_required=false`, `tiny_slot_evaluation=derive-from-public-beacon-bootstrap`, and `missed_ratchet_fallback=no-previous-root-required`; state-ratcheted schedules report `ratchet_required=true`, `tiny_slot_evaluation=derive-only-after-previous-archive-root-verification`, and `missed_ratchet_fallback=public-anchor-or-field-pack-reseed-required`.
4. Slot templates support `{substrate}`, `{medium}`, `{epoch}`, `{slot}`, `{rank}`, `{rank16}`, `{lane}`, and `{window}` placeholders, which is enough for predictable paths, object keys, status fields, and query-like retained local fixtures.

Implemented state:

1. Retained rendezvous plans now carry durable slot metadata, the previous-root source, the deployment-salt digest, exact schedule-level PRF input digest, Tiny slot-evaluation policy, and the missed-ratchet fallback string. The pointer-chain member copies those fields plus the rendezvous-plan digest when a retained plan exists, and cycle planning retains an immutable digest-named member for every epoch.
2. Tiny examines at most 32 one-MiB history candidates, rejects symlinks and special files, accepts only exact member bytes whose digest is present in the verified archive chain, deduplicates identical current/history bytes, selects the highest verified next epoch, and then consumes its fields. It records candidate count, unique verified-member count, recovery span, and member facts in `pointer-chain.kv`, reports them through `cityb-node status`, and labels the missed-cycle state as `next_plan_known`, `next_plan_missing`, or `anchor_recovery_required` without gaining posting authority.
3. Biggun `anchor-amnesia` now builds a retained root, rewrites its governance plan as a pointer-bound state-ratcheted all-media schedule, emits a public-bootstrap variant without a previous root, signs and archives two genuinely distinct consecutive pointer-chain members, exports their bounded history in a Tiny kit, seeds one derived retained-local slot, and proves Tiny selects the newest verified member and probes concrete slot roots. It then removes both the current convenience copy and the newest retained member and proves fallback to the older archive-admitted member. It also exercises stale-field-pack and expired-slot-root variants so missed-epoch fallback labels are executable evidence.

Remaining provider-specific work:

1. Move more slotted-provider metadata into durable deployment/catalog records: `slug_charset`, `slug_length`, conflict policy, and provider-specific clock-source limits.
2. Bind the existing explicit fallback-route records for verified pointer chains, durable public anchors, and field-pack reseeds to provider-specific remote slot plans once those receive paths are evidenced.
3. Extend Tiny slot probing from retained-local/file roots into additional provider-specific slot records only after those providers have bounded, evidenced receive plans.
4. Extend Biggun beyond its current previous-root, missing-root, stale-pack, expired-slot, and anchor-reseed cases when a new remote slot family earns admission.

### 3. Pointer chains and next-cycle rendezvous plans

Nodes should not need to rediscover every large payload from a cold scrape. They only need enough signed discovery material to find candidate archives. A node may start with a field pack containing initial URLs, but every adopted signed archive should contain the rendezvous plan for the next cycle.

The daisy chain should be explicit:

```text
field pack seed
  -> first verified archive
  -> next-cycle rendezvous plan
  -> next verified archive
  -> next-cycle rendezvous plan
```

As long as a node catches at least one cycle before its lookback window expires, it remains synchronized with the operator's future posts. If it misses too many cycles, it falls back to skip-list anchors.

Implemented state:

1. `cycle plan` and `cycle sign-pointer-chain` write the next-cycle pointer-chain member, retain immutable per-epoch member bytes, include retained plan digest and schedule metadata when present, and publish it as a signed archive member.
2. Tiny restores the newest bounded archive-verified member from current plus historical candidates, validates referenced retained plan digests when the file is present, persists next-plan/history/ratchet facts, and reports `next_plan_known`, `next_plan_missing`, or `anchor_recovery_required` through text and JSON status.
3. Missing promoted retained-listing sweep roots are now an explicit `anchor_recovery_required` reason rather than a silent absent plan. A verified member with a next epoch and schedule metadata becomes `next_plan_known`.
4. Biggun `anchor-amnesia` proves the retained-root-to-node-kit path for a pointer-chain member that carries state-ratcheted schedule metadata.

Remaining work:

1. Extend the bounded multi-member selection into exact epoch/root/plan
   continuity across the selected recovery path and name budget exhaustion.
2. Add Biggun variants for several missing members, partial lookback, duplicate
   reads, unavailable listing roots, and anchor reseed.
3. Keep concrete remote slot probing out of Tiny until a reviewed receive
   policy defines provider-specific request, byte, time, and persistence
   budgets. Retained-local and file slots remain the proven path.

## Features to add around rendezvous

### Plan diff and provider learning

Rendezvous planning should be diffable. Before any live mutation, the operator should see what changed since the previous plan:

- services added, removed, retired, or demoted;
- lane floors that became satisfied or unsatisfied;
- topology roots that collapsed or improved;
- cursor/firehose windows that moved;
- TTL windows that are about to expire;
- expected Tiny listener-plan digest changes;
- new public exposure compared with the prior cycle.

Provider learning should be retained as small, safe facts: success/failure class, HTTP status bucket, redirect count, final-location host, digest match, parser encoding, body-size bucket, observed expiry, rate-limit hints, and topology roots. It should not retain secrets, delete handles, authorization headers, full provider cookies, or unrelated response headers.

This enables practical operator convenience: `cityb next` can stop saying "try again" and start saying "this service has three consecutive `provider-challenge` failures; demote it and use the next independent exact-byte provider."

### Seen-token caches and bounded firehose cost

Firehose rendezvous can become expensive if nodes rescan the same public listings forever. Tiny and Goldilocks need a bounded seen-token and seen-listing cache:

- content-addressed listing snapshots in Goldilocks retained roots;
- compact seen-token filters in Tiny state when field profile permits writes;
- epoch-window pruning so old false positives do not accumulate forever;
- cursor digests so a repeated listing does not trigger repeated payload fetches;
- request and byte budgets that survive restart.

The cache is an efficiency and safety mechanism, not authority. A cached "seen" result may suppress duplicate fetches inside policy, but adoption still requires signed archive verification when new bytes appear.

### Erasure coding and fountain-style archive distribution

Free file hosts delete, rate-limit, block regions, and drift. Splitting a payload across five exact hosts makes the whole payload dependent on all five. CityB should add erasure-coded archive distribution: encode an archive into many chunks and require any sufficient subset to reconstruct the exact archive.

The first implemented step is a dependency-free systematic Cauchy Reed-Solomon-style codec over GF(256): `cityb dead-drop archive encode|reconstruct|inspect` handles local archive-byte shards, and `cityb-biggun erasure-matrix --json` exhaustively checks all `k`-of-`n` recovery subsets for the sample profile while comparing availability curves against repetition, all-of-n splitting, and pointer Shamir. The second implemented step is provider-backed operation: `cityb dead-drop archive plan|stage|spray|receipt|status|collect` takes one signed archive, assigns shards across declared adapter/provider roots, stages per-provider packets, posts eligible exact-byte shards through native adapters when `spray --apply` is explicit, verifies exact shard receipts from local paths or URLs, names missing chunks and roots, and reconstructs only when the rebuilt archive digest matches the plan. The practical roadmap is still to compare this systematic profile with fountain-code style approaches such as RaptorQ-class designs, repetition, and the current Shamir share path under the same Biggun loss model. The operator should pick a profile goal, not a code by hand: random carrier loss, early pointer leakage, OCR/manual recovery, or archive byte distribution.

Acceptance criteria:

- chunk manifests name encoding, source archive digest, chunk count, required count, per-chunk digest, and independent source roots;
- reconstruction verifies the signed archive bytes before adoption;
- partial chunks never authorize state;
- Biggun reports recovery probability, operator cost, bytes posted, hosts lost, and roots lost;
- Tiny receives only compiled chunk manifests and reconstruction logic that fits its footprint budget.

### Nostr relays as a discovery carrier

Nostr fits CityB's carrier rule because relays are untrusted discovery surfaces for signed micro-messages. It is account-light, WebSocket-based, globally replicated in practice, and much cleaner for micro-pointers than scraping hostile HTML.

The roadmap should treat Nostr as a first-class volatile carrier family after local relay doubles stay green. Operators can publish signed pointer tags, route hints, or small fragments to a relay set. Nodes can subscribe or poll within TTL windows, verify the CityB token/checksum/signature material, and ignore relay consensus entirely.

Required work:

1. Keep the local Nostr double and Biggun `gossip-evidence` proof green.
2. Add provider metadata for relay URL, event kind, tag strategy, TTL, relay refusal class, and spam/rate behavior.
3. Add a `nostr-relay` adapter only after fixtures prove event posting, replay, deletion/expiry, and malformed-event handling.
4. Keep Nostr out of archive authority; it is a route-hint, pointer, heartbeat, and fragment lane.

### Image-based steganography and passive social carriers

CityB already has screenshots, true-OCR evidence, mnemonic-card parsing, and rendered-token carriers. The next frontier is to support visual carriers intentionally: PNG/WebP/JPEG-shaped artifacts, meme-like payload carriers, OCR cards, and rendered social surfaces.

There are two different lanes:

- **visible token/OCR lane:** the image or screenshot visibly contains a CityB token or mnemonic card; extraction is OCR and checksum verification;
- **data-bearing image lane:** archive chunks or fragments are encoded into pixels or trailing bytes of a valid image; extraction produces candidate bytes that still require archive verification.

This belongs in the lab first. Image boards, issue comments, Reddit-like pages, and wiki-like media hosts have aggressive rendering, resizing, recompression, moderation, and metadata stripping. Biggun should model those transformations before any default operator path depends on them.

Acceptance criteria:

- distinguish visible-token, rendered-token, OCR, and data-bearing image lanes;
- store original upload bytes and observed returned/rendered bytes separately;
- run Tiny/Goldilocks parser-diff over OCR output and extracted bytes;
- never treat image presence as authority without signed archive verification;
- make the operator command say whether the carrier is exact-byte, normalized-exact, rendered-token, or lossy/OCR-only.

### Traffic shaping, jitter, and chaff

Static polling schedules make receive nodes recognizable. A field node that wakes every fixed interval and queries the same providers in the same order creates an avoidable traffic signature.

CityB should add traffic-shaping research in the field profile, starting with local simulation and conservative defaults:

- Poisson-distributed or jittered polling intervals instead of fixed cron beats;
- per-provider request budgets and cool-downs;
- randomized provider ordering inside the compiled listener plan;
- optional operator-approved benign chaff requests where the operator explicitly declares allowed destinations and maximum rates;
- Biggun traffic-signature reports that compare static, jittered, and chaffed schedules.

This feature must stay bounded and non-amplifying. It is meant to avoid brittle self-identification under normal network observation, not to generate abusive load or hide authority. Tiny should report the schedule policy it is following.

### Operator presets

The operator should choose intent, not tune every field. Useful presets:

| Preset | Intended use | Default behavior |
|---|---|---|
| `easy-free` | ordinary no-account public operation | exact-byte `free-stable`, conservative firehose if proven, no visual carriers, no chaff |
| `carrier-loss` | hosts disappear or rate-limit often | more repetition, erasure/archive lanes after Biggun proof, stronger topology diversity |
| `early-scraper` | public pointers may be suppressed quickly | split-knowledge pointers, short TTL overlap, fewer whole-pointer singletons |
| `amnesia-recovery` | nodes may be offline for long periods | skip-list anchors, larger lookback, field-pack fallback, slow durable lanes |
| `low-power-field` | weak devices and low bandwidth | fewer requests, longer jitter windows, no heavy firehose scraping, stronger anchors |
| `research-drift` | learn provider behavior | broad candidate benches, fixture capture, no default promotion |

Presets compile into the same deployment and listener plan fields. The operator can override them, but the normal path should start from a named intent.

## Five high-leverage architecture tracks

### 1. Epoch skip-lists and public anchors

A node may be powered off or disconnected for months. Daily pastebin cycles will expire, so a long-dormant node needs slow, durable public anchors. Add an anchor cadence that commits epoch skip-list pointers or archive roots into append-only public logs or durable public beacons such as CT-style logs, Sigstore/Rekor-style transparency logs, or drand-like beacon records.

The node should detect excessive heartbeat debt, stop wasting effort on expired daily firehoses, and fall back to anchor recovery. The anchor does not authorize a state transition; it points to candidate modern roots that still pass archive verification.

The operator-side foundation now exists. `cityb anchor policy --apply` writes a
local source policy naming accepted source kinds, source ids, trust roots,
minimum epoch, append-only requirements, and native-proof requirements.
`anchor retrieve` and the live drand/Rekor/CT clients normalize evidence into
one CityB anchor format, reject rollback and split views, retain history only
under explicit `--apply`, and never turn public-log evidence into archive or
governance authority. Drand verifies chained BLS signatures and the randomness
digest. Rekor verifies entry inclusion and the signed checkpoint; with
`--previous-anchor`, it fetches and verifies the same shard's RFC 6962
consistency proof and refuses tree-ID drift. CT similarly verifies final-leaf
inclusion, the STH signature, and an explicitly requested consistency path.

Tiny `anchor status|resolve` consumes only local/imported retained anchors,
applies the same policy/history rules, and feeds missed-cycle recovery without
gaining posting authority. Biggun's `anchor-amnesia` proves accepted and
rejected anchors plus state-ratcheted pointer-chain recovery. The checked-in
October 23/26 corpora contain real later-head CT and Rekor consistency paths
and date-separated verified drand rounds. The next tranche is richer external
root/key-rotation policy, further dated upstream corpora, and a retained-root
recovery transaction using the selected external roots.

### 2. Split-knowledge pointers

If early public discovery lets a monitor suppress the destination before receivers fetch it, a full pointer in one carrier is fragile. CityB should support split-knowledge pointers: Shamir shares, XOR shards, or other threshold fragments across independent carriers.

This is not the same as ordinary availability. Shamir helps when secrecy before threshold reconstruction matters. For non-secret public pointers, repetition or systematic erasure may recover better. The operator profile must name the threat model before choosing split-knowledge.

### 3. Passive or blinded canary probing for operator visibility

Field nodes remain receive-only and credentialless. They should not POST back to prove they exist. The operator still needs to know whether providers are blocked in regions or networks.

The operator binary should eventually import or run blinded canary evidence from external looking-glass and uptime sources. The cycle planner can then mark a provider degraded for a region or ASN before drops fail. Tiny receives only the compiled plan and evidence digests, not probe authority.

### 4. ASN/CDN topology decorrelation

Different site names often share one CDN, hosting provider, region, or transit path. CityB already records failure roots; the planner should grow that into topology scoring.

The planner should cache DNS, CDN, ASN, and hosting-family facts when available, then enforce anti-affinity rules such as "do not satisfy a lane floor entirely through one CDN or one cloud region." A plan with many nominal providers but one effective network root should fail or warn with an `InsufficientDiversityFault`-style explanation.

### 5. Drand and logical clock anchoring

Weak field hardware may lose wall-clock time. If NTP or TLS time fails, time-slotted rendezvous can fail too. CityB should support drift-tolerant logical clocks through verifiable public randomness beacons.

Drand-style rounds are useful because a node can verify a signed monotone round and key rendezvous windows to round numbers instead of trusting local UTC. The implementation should start from recorded beacon fixtures, then add live fetching only after verification and failure modes are proven.

## Operator surface

The operator should not have to remember which provider is a firehose, returned URL, deterministic slot, visual carrier, or volatile relay. The desired surface is:

```text
cityb rendezvous classify --deployment city-b.toml
cityb rendezvous plan --root RUN --deployment city-b.toml --epoch E --beacon-file BEACON
cityb rendezvous explain --root RUN --json
cityb rendezvous doctor --fixture-root fixtures/cityb/free-service-replay
cityb rendezvous collect-firehose --service SERVICE --source URL_OR_FILE --root RUN --apply
cityb rendezvous diff --root RUN
cityb rendezvous diff --against PREVIOUS/city-b-deployment-resolved.json
cityb rendezvous retire --service SERVICE --reason REASON
cityb topology score --deployment city-b.toml --json
cityb dead-drop archive plan --input ARCHIVE --root RUN/archive-spray --provider local-file:root-a --provider static-http:root-b --provider manual-drop:root-c --data-shards 10 --parity-shards 20 --json
cityb dead-drop archive stage --plan RUN/archive-spray/city-b-archive-erasure/city-b-archive-erasure-plan.tsv --json
cityb dead-drop archive spray --plan RUN/archive-spray/city-b-archive-erasure/city-b-archive-erasure-plan.tsv --adapter filebin --apply --json
cityb dead-drop archive receipt --plan PLAN --index 0 --location FILE_OR_URL --apply --json
cityb dead-drop archive status --plan PLAN --json
cityb release trust init --root RUN/archive-spray --apply --allowed-signers /absolute/path/to/cityb_allowed_signers --signer-identity cityb-release --signature-namespace cityb-release --json
cityb dead-drop archive collect --plan PLAN --out ARCHIVE --require --trust-policy RUN/archive-spray/city-b-release-trust.policy --json
cityb-biggun erasure-matrix --json
```

The operator subset is implemented today: `check`, `classify`, `plan`, `next`, `diff`, `explain`, `doctor`, `firehose-fixture`, `collect-firehose`, `anchor status`, `anchor ceremony`, `anchor policy`, `anchor retrieve`, `anchor live-drand|live-rekor|live-ct`, Tiny `anchor status|resolve`, `monitor nurse`, `monitor review`, `monitor import`, `evidence sync`, `provider health`, `provider explain`, `provider dossier`, `provider promotion-board`, `provider stable-plan`, `provider lane-board`, `provider patch-plan`, `provider candidates`, `recovery-card`, `field-pack status`, `release archive`, `release sign`, `release ceremony`, `release verify`, `install`, `doctor`, `explain service`, dry-run/apply `provider promote|demote|retire`, and preview-only `service retire|demote|replace`. The short `cityb next` workflow now runs a rendezvous next pass, provider-health inbox pass, and default promotion-bench pass, exposing `status`, `success`, `rendezvous_outcome`, `rendezvous_command`, `rendezvous_missing_classes`, `provider_health_attention`, provider import-pending counts, healthy/degraded/recapture/demotion/promotion/firehose/urgent counts, provider adapter lists, exact/discovery stable-plan counts, `topology_summary`, field-pack status/digest freshness/export command, and the provider inbox or batch stable-plan command beside the normal retained-root/cycle action. Pending retained monitor evidence and degraded provider source-review commands become the primary cockpit command before ordinary archive spray or collect work, with `workflow_command` preserving the root/cycle action for the next step; when the inbox is not urgent but providers lack dated evidence, recapture can become the primary provider action once a deployment exists, and when repeated-green exact-byte bench providers are ready, stable-plan can become the primary provider action. Firehose collection keeps explicit preview/apply separation, request budgets, retry/backoff budgets, and provider-health classification; firehose promotion attempts Biggun parser-diff by default, states the Tiny sweep lane and research-lane policy, and refuses Tiny-sweep candidacy when date-separated listing evidence or parser agreement cannot be proven. The real-machine monitor captures stable and research benches over time, checks listing-only providers through the firehose reader, and lets the operator review/import retained evidence without changing promotion status; `monitor nurse` tells the operator whether to import, reinstall, inspect a failed provider, inspect provider health, run the monitor, or simply view status, names the latest failed preset/service/adapter/failure plus `latest_failure_command` when the retained report proves it, and parses plain-string failed-step output so service-set mismatches rerun the monitor when the current binary is already installed and reinstall only when the unit or binary is stale. `evidence sync` wraps review/import with provider health, promotion check, optional parser-diff, top-level `status`/`success`, and a `changed_summary` that names changed providers, dates, and record classes. Provider hygiene remains local-only: dry-run by default, `--apply` required, backup written, patched manifest validated, and no public service mutation; the action JSON names dry-run/apply state, local/deployment/fixture/public-service mutation facts, evidence requirements, and the exact apply command. `provider promote --apply` requires date-separated exact-byte fixture evidence. `provider health` now emits top-level `status`/`success` plus an explicit `triage_queue`, separates listing-only providers into `firehose-review` rather than fake posting recapture, `provider explain PROVIDER` is the one-provider explanation answer over inbox facts, `provider dossier PROVIDER` is the first promotion-decision answer with parser-diff/topology/recapture/promotion commands, `provider candidates` keeps the researched free-provider bench in the binary, exposes status/success on list/plan/test/capture, ranks behavior-diverse evidence tranches, and refuses generic live candidate capture until provider-specific native code exists; `provider patch-plan` turns a promotion/demotion/retirement decision into a reviewable source-level plan with evidence references and reports already-true source states without an empty diff, `provider stable-plan` batches repeated-green exact-byte providers into one review artifact while keeping token-only carriers in discovery lanes and now emits source files, review steps, validation commands, and no-source-change status when applicable, and `provider lane-board` makes those lanes inspectable. `cityb-biggun provider-reality` is the corresponding lab truth rollup: it replays provider/firehose corpora without network, separates discovery-only token evidence from exact-byte failures, reports empirical archive-shard threshold dates for evidence-driven promotion, demotion, and spraying review, and replays the latest modeled live-exact shard plan across historical evidence rows so the operator can see failed, unknown, surviving, and missing providers before spraying. `anchor status`, `anchor ceremony`, `anchor policy`, `anchor retrieve`, `anchor live-drand|live-rekor|live-ct`, Tiny `anchor status|resolve`, `recovery-card`, and `field-pack status` are the amnesia and Tiny handoff answers, including retained chain/floor/pointer-chain/public-anchor fallback posture, source policy, native proof status, append-only history, field-pack readiness, digest freshness, chain/floor recoverability, release signature policy, and compact `tiny_status` facts. `cityb-biggun anchor-amnesia` proves the local/imported long-amnesia path by accepting a native-proof public anchor and rejecting an unverified one through Tiny. `release archive --signature-policy require-present|require-verified` records signature intent in the plan/manifest; `release sign` creates an OpenSSH detached `SHA3SUMS.sig` only with explicit `--apply`; `release ceremony` prints the archive/sign/verify/admit/install sequence without writing; `release verify` can enforce signature presence or OpenSSH verification over `SHA3SUMS.sig`; field-pack status can require a release manifest that reports verified signatures. `explain service SERVICE` is the service-level answer over deployment metadata, retained cycle evidence, last reliability/rendezvous/cursor excerpts, provider health, repair queue, cycle selector output, and recipes. Automatic archive spraying exists for exact-byte live adapters via `dead-drop archive spray --apply`; direct source rewrites from plan artifacts, provider-specific firehose cursors beyond observed facts, and built-in service-set rewrites remain roadmap. The behavior matters more than spelling: one command should tell the operator what to post, where listeners will look, which providers are degraded, which provider class is missing, and what exact capture, review, or repair would improve the next cycle.

The most important convenience rule is that every command should produce one of three endings:

1. **green:** enough evidence exists and the next listener plan is current;
2. **action:** run this one command or make this one operator decision;
3. **blocked:** CityB names the missing evidence or unsafe assumption and refuses to pretend.

## Implementation status ledger

This section records what was built and what each seam can still earn. It is
not the active priority queue; use the current rendezvous tranche and operator
campaign linked at the top of this document for execution order.

1. **Metadata and posture:** implemented first pass through deployment/catalog metadata and `cityb rendezvous ...`; continue enriching observed service metadata for firehose feeds, visual carriers, anchors, volatile relays, and topology evidence.
2. **Operator explanation:** implemented first pass for plan classification, one-action `next` output, retained compiled-deployment diffing, short `cityb next` integration, provider-health inbox integration, topology summary in normal checks, field-pack cockpit freshness and digest staleness, compact Tiny status, recovery-card field-pack readiness, monitor nurse, provider dossiers, service explanation with last observation excerpts, read-only explain/doctor handles, explicit provider triage queue, safe-action mutation facts, source-level patch plans, and [operator command-and-answer gap review](city-b-operator-gap-review.md). Next, deepen those answers with repeated-failure grouping and optional bounded side-effect-free checks rather than making the operator read full inboxes.
3. **Rendezvous Evidence Workbench:** implemented the retained provider-learning path through firehose fixtures, live bounded collection, monitor review/import, `evidence sync` changed summaries, provider-health classification, explicit inbox triage, local dry-run/apply provider promote/demote/retire actions, provider candidate bench promotion plans, and source-level provider-set patch plans. Next, let monitor evidence accumulate across multiple dates, require human review before applying service-set promotion/demotion edits, and keep `triage_queue` wording aligned with the newest provider-specific failure evidence.
4. **Firehose fixtures:** local provider-specific listing corpora and Biggun parser agreement are implemented under `fixtures/cityb/rendezvous-firehose`. Pastebin Archive, GitHub public Gists, and Pastefy are current retained-local promotions. FragBin's October 7/10 corpus remains parser evidence, but October 17/18 and October 22 live failures suspend its declaration pending recovery. Pastefy's October 18/20 captures prove an uncursored full-content JSON response; Goldilocks uses an 8 MiB bound and Tiny consumes only its retained local projection.
5. **Bounded cache:** implemented seen-token/listing/cursor cache semantics through `city-b-firehose-seen-cache.json`, automatic retained-root cache paths, explicit `--cache FILE`, `--reset-cache`, token-hash deduplication, cursor capture status, and observation fields so firehose work has restartable request and byte budgets. Next, use repeated live captures to decide provider-specific cursor expiry policies rather than inferring them.
6. **Live firehose readers:** bounded collection is implemented with retry/backoff/timeout classification, three promoted real listing providers, and one suspended research/recheck reader. Add provider-specific cursor/expiry behavior only where repeated captures prove it, then promote future providers only after Biggun proves parser cost and agreement.
7. **State-ratcheted slots:** implemented schedule metadata, exact PRF input recording, Tiny reporting for previous archive-root ratchets, concrete retained-local slot derivation/probing, stale-field-pack exercise, and expired-slot-root fallback. Next, add provider-specific remote slot records and more missed-epoch variants over non-local providers.
8. **Pointer chains:** implemented first-class signed archive members in Tiny next-plan and missed-cycle recovery behavior, including `next_plan_known`, `next_plan_missing`, and `anchor_recovery_required` labels after archive-chain verification. Tiny can execute concrete retained-local next-cycle probe windows from the verified plan. Next, test more daisy-chain loss cases and extend probing only where provider-specific receive plans are bounded and evidenced.
9. **Retirement and repair:** implemented through health triage, explain,
   dossier, promotion board, stable plan, patch plan, and dry-run/apply source
   review. Remaining work is evidence accumulation and clearer correlated-root
   replacement selection.
10. **Nostr local-to-live path:** keep local relay doubles green, then add live Nostr as a volatile pointer/route-hint/fragment carrier.
11. **Erasure matrix:** compare Reed-Solomon/systematic erasure, RaptorQ-class fountain coding, repetition, mnemonic chunks, and Shamir under identical carrier-loss and early-scraper models.
12. **Anchors and logical clocks:** local policy/retrieve, live drand/Rekor/CT,
    Tiny resolve, and Biggun amnesia cover source/trust-root policy,
    append-only linkage, rollback/split-view refusal, native proofs, exported
    Tiny recovery, slots, stale field packs, and expiry fallback. October 23/26
    fixtures prove later-head CT and Rekor consistency plus dated drand BLS
    rounds. Continue dated corpora and deepen external-root/key-rotation policy.
13. **Topology scoring:** implemented through typed dated operator, hostname,
    DNS, IP, ASN, CDN, hosting-root, confidence, and observation facts. The
    planner and Biggun consume the snapshot; the current product gap is guided
    receipt repair outside the failed/correlated root.
14. **Visual carriers:** extend OCR/screenshot tests into intentional image carriers and lossy-rendering fixtures.
15. **Traffic-shape lab:** add jitter/chaff simulation and only then field-profile knobs with hard request budgets.

Current non-exact lane decision: `rendered-token`, `redirect-token`, and `listing-token` carriers are discovery-only by default. They may support pointer, heartbeat, and route-hint lanes after checksum and archive verification. They do not satisfy mirror/archive floors and should not be mixed into `free-stable` exact-byte promotion ledgers. A future easy discovery preset should be named separately.

## Historical October 8, 2026 roadmap cut

This cut is retained to explain the order in which the current machinery was
built. It is not the active queue. Use
[city-b-next-rendezvous-tranche.md](city-b-next-rendezvous-tranche.md) for the
current tranche and [city-b-next-campaign.md](city-b-next-campaign.md) for the
cross-product operator order.

The next useful work should favor operator certainty over new surface area. CityB already has a broad command tree; the missing value is repeated evidence, boring admission ceremonies, and Biggun proofs that punish optimistic assumptions.

1. **Provider evidence and stable-set curation.** Keep the monitor running, import evidence with `cityb evidence sync --apply`, and make promotion/demotion decisions from date-separated exact-byte reality. The operator should see stable providers as "worked across drift windows," not "worked once." This remains the highest practical value because every later feature depends on provider facts.
2. **Native exact-byte adapter growth.** Continue moving proven candidates from candidate probe to production Rust adapter to strict bench to stable review. A provider is useful only when CityB can post, fetch, replay, explain, demote, and model it without hand archaeology. Generic candidate rows stay staging objects until provider-specific receive behavior is proven.
3. **Archive spraying through real providers.** Keep joining provider reality to `dead-drop archive plan|spray|status|collect`: topology-aware shard assignment, automatic native exact-byte spraying where eligible, explicit ineligible-provider lists, release verification after reconstruction, and Biggun loss modeling from real dated rows.
4. **More listing/firehose providers, slowly.** Pastebin Archive, GitHub public Gists, and Pastefy are the promoted retained-local Tiny sweeps; FragBin is suspended in research/recheck. The gate for every new or returning feed is repeated low-rate capture, provider-specific cursor/expiry facts only where observed, false-positive accounting, Biggun parser agreement, and source review. Live listing failures now survive report rotation in the retained rendezvous observation ledger; checked-in listing fixtures remain the reviewed promotion corpus rather than an automatic mirror of every read.
5. **Durable anchors and long-amnesia recovery.** Keep live drand/Rekor/CT normalization and local proof verification, then add richer external-root policy, date-separated upstream inclusion/consistency fixtures, CT public-key fixtures, and Tiny proofs where a stale field pack recovers by anchor plus signed archive chain rather than dashboard state.
6. **State-ratcheted deterministic slots.** Retained-local/file slots now work after archive-chain verification. The next tranche is provider-specific remote slot metadata: slug charset, length, conflict policy, clock/beacon source, exact PRF inputs, fallback routes, and missed-epoch Biggun tests.
7. **Release and signing ceremony.** Keep release archive, `SHA3SUMS`, OpenSSH detached signature verification, release admission fixtures, and field-pack policy tied together. Add more negative fixtures and one realistic signed release transcript so adoption rules are boring for weak operators.
8. **Tiny durability and reconstruction.** Continue shifting startup truth from dashboard projections to independently verified chain, floor, pointer-chain, archive-shard, and anchor records. Add crash/restart and read-only cases only where they represent field failure modes, not artificial coverage.
9. **Topology-aware replacement.** Save provider dossiers and replacement rationales so CityB can say "replace X with Y because this CDN/ASN/root collapse is proven" rather than merely printing a topology score. Keep live ASN/CDN enrichment opt-in.
10. **Biggun realism.** Biggun should remain the star truth machine: provider drift replay, parser parity, anchor amnesia, erasure outcomes, archive-spray loss modeling, target checks, release gates, and cost stress. If a roadmap sentence matters to field operation, Biggun should eventually rehearse it.
11. **Documentation and source slimming.** Keep current-state, README, command help, fixture READMEs, and roadmap claims synchronized with executable gates. Preserve speculative ledgers, but mark them as ledgers and avoid letting old command trees masquerade as current surfaces.
12. **Soak integrity.** Treat required-lane readiness, non-blocking experiment findings, and storage health as three separate facts. `monitor findings` owns the current capacity/listing/candidate queue; `monitor compact` bounds redundant operational state while preserving evidence ledgers; and the machine-readable evidence scope keeps a single-host soak from being misreported as regional or global proof.

The priority test for any new idea is simple: does it let the operator make a better decision with less memory, or does it make Tiny recover correctly after worse conditions? If not, it belongs in a research ledger until Biggun or provider evidence makes it real.

## Summary fit

| Mechanism | Layer | Solves | CityB principle |
|---|---|---|---|
| Public firehose sweeps | Collector / listener | random returned URLs and public recents | carriers are discovery |
| Deterministic slots | Rendezvous planner | nodes need predictable places to look | claims are replayable |
| Pointer chains | Archive / listener plan | normal continuity after first adoption | archives are truth |
| Epoch skip-lists | Recovery | node amnesia after long disconnects | archive roots anchor recovery |
| Split-knowledge pointers | Transports / rendezvous | preemptive takedown after early pointer discovery | fragments are discovery until archive verification |
| Erasure coding | Archive distribution | random host loss, rate limits, regional blocks | bytes verify before adoption |
| Nostr relays | Volatile carrier | HTML scraping friction and short TTL signals | relays are untrusted |
| Visual carriers | OCR / social / image media | lossy human and web surfaces | parser evidence is explicit |
| Blinded canaries | Operator evidence | regional blackout blindness | Tiny remains passive |
| ASN/CDN decorrelation | Planner | fake diversity and hidden shared roots | failure domains are first-class |
| Drand logical clocks | Node / beacon | dead RTC and blocked NTP | public proof beats trusted wall time |
