# City B real service adapter candidates

As of September 16, 2026, City B has sixty built-in service adapters
across the stable/wide/deep anonymous provider benches. The newest ten are
`pastehtml`, `okfile`, `here-now`, `haste-unbelievaboat`, `rentry-co`,
`files-offshore`, `qu-ax`, `zoomie`, `paste-opensuse`, and
`paste-debian`. City B
also retains seven native staged free-service adapters
(`github-release`, `gitlab-release`, `netlify-drop`, `github-pages`,
`gitlab-pages`, `codeberg-pages`, and `codeberg-release`).

This note treats cost as a product constraint, not a footnote. City B is not
being aimed at paid infrastructure. The active roadmap is:

- prefer free services;
- prefer no-account services first;
- accept free account-backed services when they buy real durability or operator
  clarity;
- keep paid-only services out of the mainline adapter plan;
- keep provider brands subordinate to receipts, manifests, and signatures.

The point is not to make service brands authoritative. The point is to identify
which surfaces are worth adapter work, what exact placement/probe problems they
introduce, and which ones fit pointer-only versus archive-capable posting.
Use [city-b-free-service-taxonomy.md](city-b-free-service-taxonomy.md) while
hunting for additional free services; this document records the concrete
providers CityB already knows how to stage, post, probe, or replay.

## HTTP transport profiles

The built-in web adapters execute service-specific requests through one shared,
bounded external HTTP transport. The default is ordinary `curl`: this matches
the command-line API examples published by many providers and avoids claiming
to be a browser when CityB is using an API. Each adapter still owns its method,
body encoding, headers, returned-location parser, redirect policy, byte limit,
timeout, and exact receive probe. Raw TCP, MQTT, NATS, Nostr, and WebSocket
adapters do not pass through this HTTP layer.

Set `CITYB_HTTP_TRANSPORT=firefox` or `CITYB_HTTP_TRANSPORT=chrome` to run web
requests through the Nix-packaged `curl-impersonate` transport. An advanced
pinned target can be selected with, for example,
`CITYB_HTTP_TRANSPORT=impersonate:firefox147`. This changes the coherent
TLS/HTTP/browser-header profile; merely adding a Firefox `User-Agent` to normal
curl would leave a contradictory curl TLS fingerprint. The Nix package carries
both ordinary curl and curl-impersonate. A non-Nix installation must place the
selected executable on `PATH`.

Transport selection is explicit and run-wide. CityB never silently retries a
failed curl observation with browser impersonation, because doing that would
erase useful provider-drift evidence. Packet manifests record
`http_transport`, and service result notes carry the same label. Browser-shaped
curl does not execute JavaScript, solve a CAPTCHA, establish a human session,
or grant permission to use a service. A managed challenge remains a named
provider outcome; use a real browser only for a provider workflow that actually
documents and permits one.

PasteFox previously overrode curl with the unusually conspicuous
`User-Agent: cityb/1 dead-drop adapter`. That override has been removed. The
default adapter now follows PasteFox's documented anonymous JSON API using
curl's coherent native identity; an operator can run a separate
browser-transport capture when comparing transport-dependent availability.

The practical City B metadata is now:

- `provider_class`
- `cost_posture`
- `account_posture`
- `mutation_surface`
- `receive_surface`
- `retention_class`
- `operator_touch`
- `probe_surface`
- `payload_fit`
- `default_collector_mode`
- `preferred_encodings`
- `fixture_cases`
- `repair_notes`
- `preferred_materials`
- `mirror_fit`
- `hazard_flags`
- `diversity_domain`

The deployment compiler uses a stricter operational subset in manifests:
`failure_domain`, `provider_root`, `account_root`, `network_root`,
`moderation_root`, `copy_root`, `retention_class`, `probe_surface`, and
`payload_fit`. `cityb deployment init --service-set free-stable` seeds the
repeated-live no-account set without credential references. `cityb deployment
init --service-set free-five` preserves the older Filebin/0x0 drift bench.
`cityb deployment init --service-set free-wide` keeps those research surfaces
and adds Litterbox, /tmp/files, paste.c-net.org, file.io, Uguu, Termbin,
sendit.sh, tmpfile.link, storage.to, beacon.host, Pastebin archive, GitHub
public Gists, Pastefy's public listing, and FragBin public API as monitored
research/field-trial sources. Pastebin Archive, GitHub public Gists, and
Pastefy are different from the posting adapters: they are the three currently
declared public-listing Tiny sweeps, with token-only receive semantics and no
listing-side CityB posting command. FragBin retains its parser, historical
fixtures, and bounded monitor recheck, but its Tiny declaration is suspended
after repeated October 17–18 HTTP 500 observations; a later exact recovery and
source review are required for re-admission.
`cityb deployment init --service-set free-deep-10` adds a separate ten-provider
research bench for x0.at, curl.by, End2End.tech, file2.me, JuiceBox,
TempFile.org, ayaya.beauty, hostb, hst.sh, and haste.rys.pw. It has no mirror
floor by default: those adapters are current pointer, heartbeat, and route-hint
evidence surfaces until repeated dated captures prove promotion value.
`cityb deployment init --service-set free-deep-text-10` adds the paired
ten-provider text/paste research bench for paste.code-solutions.dev,
paste.helpch.at, bytebin.lucko.me, api.pastes.dev, bpa.st,
transfer.archivete.am, pastefy.app, pastefox.com, haste.zneix.eu, and
bin.birdflop.com. It also has no mirror floor by default; the set is for
pointer, heartbeat, and route-hint evidence until repeated dated captures prove
promotion value.
`cityb deployment init --service-set free-deep-web-10` adds the third
ten-provider research bench for mclo.gs, Sourcebin, paste.agradip.fyi,
SpaceBin, CrafterBin, qurl.sh, Mythical Paste, YukiAPI, AgentMediaTools, and
paste.firnsy.com. It also has no mirror floor by default; the set is for
pointer, heartbeat, and route-hint evidence until repeated dated captures prove
promotion value.
`cityb deployment init --service-set free-deep-web2-10` adds the fourth
ten-provider research bench for PasteHTML, OKFile, here.now,
haste.unbelievaboat.com, rentry.co, files.offshore.cat, qu.ax, zoomie.sh,
openSUSE Paste, and Debian Pastezone. It also has no mirror floor by
default; the set is for pointer, heartbeat, and route-hint evidence until
repeated dated captures prove promotion value.
`cityb deployment init --service-set free-deep-web3-10` adds the fifth
ten-provider research bench for CentOS Paste, rpa.st, AlmaLinux Paste,
OpenStack Paste, yt-project Paste, OpenDev Paste, Gentoo LogPaste, Ubuntu
China Paste, p.defau.lt, and paste2.org. It also has no mirror floor by
default; the set is for pointer, heartbeat, and route-hint evidence until
repeated dated captures prove promotion value. CoShareX remains a built
adapter and drift candidate outside this strict set.
`cityb deployment init --service-set free-deep-web4-10` adds the sixth
ten-provider research bench for Pastr, Valhalla Paste, Write.as, p.ip.fi,
Kagit, ShareNotes, Pastebin.ai, da.gd, TinyURL, and clck.ru. It also has no
mirror floor by default; the set is for pointer, heartbeat, and route-hint
evidence until repeated dated captures prove promotion value. da.gd, TinyURL,
and clck.ru are redirect-token carriers rather than exact-byte mirrors.
`cityb collect probe` turns exact observed URLs or files into
content-addressed probe receipts and `city-b-service-reliability.jsonl` facts;
later `cycle preview` and `cycle plan` use those facts to rank otherwise
eligible services.
`cityb deployment recipes [--file FILE]` renders the same metadata as an
operator guide for either the built-in adapter catalog or a concrete deployment
service. `cityb collect fixture-template --root RUN --deployment FILE --out
JSONL` writes checksum-valid replay scaffolding for the current retained
pointer, which keeps real provider captures compatible with the offline replay
path.

Those fields matter because they answer the real operator questions:

- Will this disappear too quickly for pointer continuity?
- Does this require a token, a repo workflow, or no extra human touch?
- Will the adapter get back a direct URL, a raw text URL, or only an
  operator-declared publication target?
- Is this naturally a text lane, a small-file lane, or a site-tree lane?
- Should it carry a pointer, a heartbeat, or a route hint first?
- Is it a plausible continuity mirror or only a wakeup/signal lane?
- What caveats will burn the operator if they forget them?
- Is this genuinely a new service family, or just another adapter in the same
  correlated blast radius?
- Did recent exact-location probes succeed, fail transiently, or show that the
  selected encoding no longer survives that service?
- Which exact replay cases should be captured before treating the service
  behavior as stable?

## Decision rules

- Prefer services with a stable documented upload path.
- Prefer exact fetchable URLs over opaque viewer pages.
- Prefer services whose quirks can be normalized into named failures.
- Keep pointer-only and archive-capable services separate.
- Prefer no-account surfaces before account-backed ones when the outcome is
  otherwise comparable.
- Use built-in adapters first when the service already has enough stable value
  to justify core support.
- Use `plugin-external` when the service has mechanics that still need field
  experimentation before promotion.
- Keep `static-http`, `git-release-generic`, and `object-store-generic` for
  operator-owned surfaces that already match those classes.
- Probe only exact operator-supplied URLs until a service has a safe,
  documented cursor or listing API. Discovery and proof are different jobs.
- Capture representative provider behavior as `collect fixture` JSONL before
  increasing automation. Fixture replay should prove expiry, redirect,
  rate-limit, parser, and content cases without depending on a live provider in
  every test run.

## Implemented today

| Service | Class | Cost posture | Account posture | Current City B posture | Best use | Main adapter wrinkle |
|---|---|---|---|---|---|---|
| Filebin | filehost | free | none | built-in Rust | pointer or small archive mirror | download can require verification-cookie handling |
| paste.rs | pastebin/text | free | none | built-in Rust | pointer, heartbeat, route-hint text | rate limits and possible `206` partial response |
| dpaste | pastebin/text | free | none | built-in Rust | pointer, heartbeat, route-hint text | raw probe wants `.txt` path and pacing |
| paste.c-net.org | pastebin/text | free | none | built-in Rust | pointer, route-hint, heartbeat text | documented long retention renewed by reads, but only a single dated CityB capture so far |
| NullPaste | pastebin/text | free | none | built-in Rust | pointer, heartbeat, route-hint text | anonymous API returns JSON `raw_url` that must be probed instead of the viewer page |
| 0x0 | filehost | free | none | built-in Rust | small file-style pointer mirror | small-file bias and optional expiry/delete extras |
| Catbox | filehost | free | none | built-in Rust | pointer or medium archive mirror | anonymous and account-backed flows differ |
| Litterbox | temporary filehost | free | none | built-in Rust | heartbeat, route-hint, short-TTL pointer | explicit temporary retention bands |
| /tmp/files | temporary filehost | free | none | built-in Rust | short-TTL pointer or small archive mirror | expiry in seconds, not days/epochs |
| file.io | filehost | free tier | none required | built-in Rust | one-shot pointer or small archive drop | one observer can consume the object before others fetch it |
| Uguu | temporary filehost | free | none | built-in Rust | heartbeat, route-hint, short-TTL pointer | explicit 3-hour retention and small size ceiling |
| Termbin | pastebin/text over TCP | free | none | built-in Rust | tiny text pointer carrier | upload is raw TCP while observation is HTTP |
| sendit.sh | filehost/text upload | free | none | built-in Rust | pointer, route-hint, heartbeat file | returned path differs from requested path and retention is short |
| temp.sh | temporary filehost | free | none | built-in Rust | heartbeat, route-hint, short-TTL pointer | viewer URL must be POSTed to retrieve exact bytes |
| tmpfile.link | temporary filehost | free | none | built-in Rust | heartbeat, route-hint, short-TTL pointer | anonymous `/api/upload` returns JSON `downloadLink` on a separate download host |
| beacon.host | temporary filehost | free | none | built-in Rust, free-stable | pointer, heartbeat, route-hint, small archive shard | anonymous `/v1/upload` returns a public URL; unauthenticated links are short-lived and rate-limited |
| Pastebin archive | public listing/firehose | free | none for reads | receive-only `free-wide` research carrier | pointer, heartbeat, route-hint discovery tokens | public archive rows expose generated paste paths but not exact payload bytes or expiry; Tiny sweeps retained local listing objects |
| GitHub public Gists | public listing/firehose | free | none for reads | receive-only `free-wide` research carrier | pointer, heartbeat, route-hint discovery tokens | unauthenticated JSON listing exposes public gist descriptions and Link-header cursors; Tiny sweeps retained local listing objects |
| FragBin public API | public listing/firehose | free | none for reads | receive-only research/recheck lane; Tiny declaration suspended | pointer, heartbeat, route-hint discovery tokens | October 7/10 fixtures proved public JSON listing rows with page/limit fields; HTTP 500 on October 17/18 and October 22 requires later exact recovery before source re-admission |
| x0.at | filehost | free | none | built-in Rust | pointer or small file-style carrier | 0x0-style multipart upload with a distinct provider root |
| curl.by | filehost/text upload | free | none | built-in Rust | pointer, heartbeat, route-hint file | `PUT` returns a `wget` command whose URL is receipt-authoritative |
| End2End.tech | filehost | free | none | built-in Rust | pointer or small file-style carrier | upload JSON returns `FileID`; receive is `/download?id=...` |
| file2.me | filehost | free | none | built-in Rust | pointer or small file-style carrier | share URL must be normalized to `/raw/<slug>` and may need a short settle retry |
| JuiceBox | temporary filehost | free | none | built-in Rust | pointer, heartbeat, route-hint file | explicit TTL upload returns JSON `url` |
| TempFile.org | temporary filehost | free | none | built-in Rust | pointer, heartbeat, route-hint file | JSON URL is a viewer path; exact bytes are at `/download` |
| ayaya.beauty | filehost | free | none | built-in Rust | pointer or small file-style carrier | ShareX-style JSON returns `directLink` fields |
| hostb | filehost | free | none | built-in Rust | pointer or small file-style carrier | two-step chunked upload; result URL must be normalized to `/raw` |
| hst.sh | pastebin/text | free | none | built-in Rust | pointer, heartbeat, route-hint text | Hastebin-compatible `/documents` response gives a raw key |
| haste.rys.pw | pastebin/text | free | none | built-in Rust | pointer, heartbeat, route-hint text | Hastebin-compatible `/documents` response gives a raw key |
| storage.to | temporary filehost | free tier | none required for anonymous uploads | built-in Rust | larger temporary archive mirror | anonymous ShareX path is simple, but retention and rate are still service-shaped |
| GitHub Gists | snippet/text | free tier | free account + token | built-in Rust | durable pointer text and note surfaces | authenticated create, anonymous raw read |
| GitLab Snippets | snippet/text | free tier | free account + token | built-in Rust | durable pointer text and note surfaces | authenticated create, raw probe, GitLab-specific visibility rules |
| GitHub Releases | release-page | free tier | free account + token | native staged adapter | durable archive mirror | release/tag/asset choreography is account-owned |
| GitLab Releases | release-page | free tier | free account + token | native staged adapter | durable mirror with stable redirect path | release-link creation is distinct from object placement |
| Netlify Drop | static-site | free tier | optional account; anonymous claim-later exists | native staged adapter | manual static publication | UI/CLI flow, not one raw upload endpoint |
| GitHub Pages | static-site | free tier on public repos | free account | native staged adapter | durable pointer pages and small mirrors | repo-backed static publication, not one upload endpoint |
| GitLab Pages | static-site | free tier | free account | native staged adapter | durable pointer pages and small mirrors | repo + CI/CD publication rather than one-shot upload |
| Codeberg Pages | static-site | free | free account | native staged adapter | less-corporate static publication | webhook or Forgejo Actions deployment |
| Codeberg Releases | release-page | free | free account | native staged adapter | less-corporate durable archive mirror | release UI/tag flow is explicit and stable |

## Recipe and replay evidence

Run this before selecting or repairing services:

```sh
cityb deployment recipes --adapter catbox --json
cityb deployment recipes --file ./city-b.toml --service catbox --json
cityb collect fixture-template --root ./city-b-artifacts \
  --deployment ./city-b.toml \
  --service catbox \
  --lane mirror \
  --out ./catbox-capture.jsonl \
  --all-cases \
  --json
```

`deployment recipes` is the current source of operator-facing service
semantics. Each item states the provider class, cost/account posture,
mutation/receive surface, collector mode, best lanes, preferred encodings,
retention, probe recipe, cursor recipe, fixture cases, repair notes, hazards,
and docs. With `--file`, it adds the deployment-local roots and budgets that
the scheduler will actually use.

The checked-in replay corpus lives at
`fixtures/cityb/free-service-replay/`. `captured-provider-fixtures.jsonl` is a
small local-proof template. `free-five-provider-fixtures.jsonl` exercises the
five no-account services created by `--service-set free-five`, including
verified reads plus expiry and rate-limit failures. `cursor-listings/` contains
static-index, release-asset, and snippet-raw examples for receive-parser
development. These files are intentionally not live-provider claims; they are
stable inputs for parser, provider-health, planner, and Biggun regression
paths.

`live-free-five-2026-09-12-provider-fixtures.jsonl` is the first checked-in
dated live-provider replay. It preserves a real Filebin, paste.rs, dpaste, 0x0,
and Catbox run as fixture input: Filebin is verified after an eventual
availability settle retry, paste.rs/dpaste/Catbox are verified directly, and
0x0 is retained as a provider-error HTTP 503 case. A previous tmpfiles live
smoke returned readable content without the expected token; tmpfiles remains a
supported native adapter and a useful drift case, but it is not part of the
`free-five` drift bench.

`live-free-wide-2026-09-12-provider-fixtures.jsonl` is the dated broad replay
for `free-wide`. It verifies Filebin, paste.rs, dpaste, Catbox, tmpfiles, Uguu,
and Termbin, and keeps 0x0 HTTP 503, Litterbox HTTP 500, file.io HTTP 405, and
storage.to token-missing/public-download drift as negative fixtures. Storage.to
replays as `content-missing` because the provider returned a reachable share URL
but the fetched content did not contain the expected token. The
tmpfiles pass is provider-specific: the upload API returns a viewer URL, then
the adapter reads the viewer and probes the `/dl/...` download link. `free-wide`
should be used to capture fixtures and compare service families, not as the
default first run for a new operator.

`live-free-stable-2026-09-12-provider-fixtures.jsonl` is a narrower 6/6
successful corpus from paste.rs, dpaste, Catbox, tmpfiles, Uguu, and Termbin.
It keeps a fast replay path for the services that produced exact bytes in the
same live session.

`live-free-stable-2026-09-12-pass2-provider-fixtures.jsonl` repeats that stable
six-service set in a second capture. It is intentionally redundant: repeated
dated captures let CityB learn returned-URL churn, delayed provider drift, and
which no-account services remain boring over time.

`live-free-wide-2026-09-12-pass2-provider-fixtures.jsonl` repeats the full
free-wide bench. It again verifies Filebin, paste.rs, dpaste, Catbox, tmpfiles,
Uguu, and Termbin, while preserving 0x0 HTTP 503, Litterbox HTTP 500, file.io
HTTP 405, and storage.to token-missing as negative cases. That repetition is an
operator signal: the first seven services are good default research candidates,
while the last four need adapter repair or de-ranking before they should appear
in an easy path.

`live-free-wide-2026-09-13-utc1-provider-fixtures.jsonl` is the first broad
capture across a UTC date boundary. It repeats the same result: Filebin,
paste.rs, dpaste, Catbox, tmpfiles, Uguu, and Termbin served exact bytes; 0x0,
Litterbox, file.io, and storage.to did not. The companion
`live-free-wide-2026-09-13-utc1-drift-provider-fixtures.jsonl` preserves
sanitized bodies for the failed providers. The observed 0x0 body says uploads
are disabled. The Litterbox body is a BunkerWeb HTTP 500 server-side error.
The file.io body is an HTTP 405 object-method rejection for the current
anonymous upload path. The storage.to body is a Cloudflare JavaScript/cookie
challenge on the public viewer URL. CityB now names those outcomes as
`provider-disabled`, `provider-server-error`, `api-method-rejected`, and
`provider-challenge` when the status/body proves them. This is classification
repair, not carrier promotion: none of the four has new usable receive coverage
until a later live capture or documented path proves exact-byte reads.

`live-free-wide-2026-09-15-utc1-provider-fixtures.jsonl` is the first broad
capture after adding paste.c-net.org and sendit.sh to `free-wide`. It verified
Filebin, paste.rs, dpaste, Catbox, Litterbox, tmpfiles, paste.c-net.org, Uguu,
Termbin, and sendit.sh. It retained three negative cases: 0x0 HTTP 503
`provider-disabled`, file.io HTTP 405 `api-method-rejected`, and storage.to
`provider-challenge` on the returned public share URL. That makes
paste.c-net.org and sendit.sh useful research-bench adapters, but not
`free-stable` members yet.

`live-free-wide-2026-09-15-utc1-drift-provider-fixtures.jsonl` keeps the real
failed-provider bodies from the same run. Those bodies are available to
parser-diff and are declared non-retrievable in fixture replay, so they sharpen
parsing and classification without pretending the services provided useful
carrier coverage.

`true-ocr-2026-09-15-utc1-provider-fixtures.jsonl` adds a real screenshot/OCR
body to parser-diff and fixture replay. Chromium captured a rendered mnemonic
card, Tesseract produced the checked-in text body, and the shared parser now
tolerates the observed `cityb-mnemonic-vl` marker while rendering canonical
`cityb-mnemonic-v1`.

`live-free-wide-2026-09-15-utc2-provider-fixtures.jsonl` records same-day exploratory evidence for NullPaste and temp.sh. NullPaste posted text to the anonymous API, returned JSON containing a raw URL, and served exact bytes from that raw URL. temp.sh accepted a multipart upload, returned a public viewer URL, and served exact bytes only when the adapter used the service-specific POST download action against that returned URL; HTTP GET remained a viewer-page interaction and is not receive proof. Both services are `free-wide` research adapters until repeated date-separated captures justify promotion.

`live-free-wide-2026-09-15-utc3-provider-fixtures.jsonl` records the first full broad capture after NullPaste and temp.sh joined `free-wide`. Twelve adapters returned exact bytes: Filebin, paste.rs, dpaste, Catbox, Litterbox, tmpfiles, paste.c-net.org, NullPaste, Uguu, Termbin, sendit.sh, and temp.sh. Three adapters remained negative with named failures: 0x0 `provider-disabled`, file.io `api-method-rejected`, and storage.to `provider-challenge`. This strengthens the free-wide research bench and gives Biggun a larger body corpus, but it is still same-day evidence; promotion to `free-stable` waits for a later date-separated broad capture.

`live-wide-2026-09-15-214716z-provider-fixtures.jsonl` is the first retained CityB capture for tmpfile.link. It posted one pointer carrier to `/api/upload`, parsed the returned JSON `downloadLink`, fetched exact bytes from the returned `d3.tfdl.net` download URL, and stored the body for offline replay. This is enough evidence for the native `tmpfile-link` adapter and same-day corpus coverage, not enough evidence for `free-stable`: repeat it in a later-date broad run before promotion.

`live-wide-2026-09-16-102034z-provider-fixtures.jsonl` is the later-date broad capture that closed the promotion review for six adapters. Thirteen adapters returned exact bytes: Filebin, paste.rs, dpaste, Catbox, Litterbox, tmpfiles, paste.c-net.org, NullPaste, Uguu, Termbin, sendit.sh, temp.sh, and tmpfile-link. The same three providers remained negative: 0x0 `provider-disabled`, file.io `api-method-rejected`, and storage.to `provider-challenge`. After parser-diff and root-diversity review, Filebin, paste.c-net.org, NullPaste, sendit.sh, temp.sh, and tmpfile-link joined `free-stable`; Litterbox stayed in `free-wide` because its earlier failures and Catbox-root correlation make it a research/bench surface rather than an easy default. Later retained monitor evidence moved NullPaste back to `free-wide` after repeated September 17-19 fetch failures.

`live-stable-2026-09-16-230721z-provider-fixtures.jsonl` is a later same-day stable retest after the promotion review. The then-current twelve `free-stable` adapters returned exact bytes: Filebin, paste.rs, dpaste, Catbox, tmpfiles, Uguu, Termbin, paste.c-net.org, NullPaste, sendit.sh, temp.sh, and tmpfile-link. Later retained monitor imports changed the easy set; use `cityb provider health --service-set free-stable --fixture-root fixtures/cityb/free-service-replay --json` for the current operator posture.

`live-wide-2026-09-16-230804z-provider-fixtures.jsonl` is the matching later same-day wide retest. Twelve adapters returned exact bytes: Filebin, paste.rs, dpaste, Catbox, tmpfiles, paste.c-net.org, NullPaste, Uguu, Termbin, sendit.sh, temp.sh, and tmpfile-link. Four providers returned named negative evidence: 0x0 `provider-disabled` with HTTP 503, Litterbox `upload-rejected` with HTTP 412, file.io `api-method-rejected` with HTTP 405, and storage.to `provider-challenge`. This run confirms that `free-wide` is still a research/drift bench and that Litterbox should not be promoted despite earlier exact-byte captures.

`monitor-2026-09-19-174004z` is the first retained all-free monitor pass imported after the operator asked for every provider to be checked together. It ran the then-current `free-stable`, `free-wide`, all seven deep benches, and the public-listing checks in one broad machine pass, then imported 109 additional fixture/body files. That stable pass succeeded, gave Filebin and paste.rs dated exact-byte recaptures beside only undated historical failures, and kept Dpaste as a single-date watch item. Later retained monitor imports through September 26 moved Filebin, Termbin, and temp.sh back to the research/drift lane after repeated failures. Dpaste subsequently recovered, then moved to `free-wide` after new unresolved failures on both October 17 and October 18 supplied the required repeated post-recovery evidence.

`monitor-2026-09-19-182608z` is the later same-day retained pass for `free-deep-10` plus `free-stable`. It imported 25 additional fixture/body files. All ten `free-deep-10` providers passed again, all eleven `free-stable` providers passed again, and Dpaste retained the same-date September 19 failure history from earlier reports. This strengthens dated recapture evidence for the stable and first deep bench providers, but it still does not create a second failure date for Dpaste.

`pastebin-archive-2026-09-17.jsonl` and `pastebin-archive-2026-09-19.jsonl` are the first date-separated public listing/firehose corpora. They preserve four low-rate read-only captures of `https://pastebin.com/archive` with sanitized public title data plus synthetic CityB title placements over the observed row grammar. The promoted service is `pastebin-archive` in `free-wide`: `collector_mode = public-firehose`, `receive_behavior = listing-token`, `enumerable = public-feed`, and `exact_byte_policy = token-only`. It is not a live posting adapter and is not `free-stable` evidence. Goldilocks may retain bounded listing pages with `cityb rendezvous collect-firehose`; the retained root also stores `city-b-firehose-seen-cache.json` with listing digests, checksum-valid token hashes, cursor status, and last-source facts so repeated sweeps can deduplicate without persisting raw tokens. Tiny reads the retained local `city-b-rendezvous-firehose/pastebin-archive/objects` directory. `cityb rendezvous promote-firehose --service pastebin-archive --json` now reports `tiny-sweep-promoted` after service-specific fixture dates, cursor/expiry facts, rejected false-positive probes, and Biggun parser agreement are checked.

`github-gists-public-2026-09-17.jsonl` and `github-gists-public-2026-09-19.jsonl` are the second date-separated public listing/firehose corpus. They preserve low-rate unauthenticated reads of `https://api.github.com/gists/public?per_page=10` with public user and file names normalized, plus synthetic description-placement rows over the observed JSON listing grammar. The provider is a listing reader, not a no-account posting adapter: `receive_behavior = listing-token`, `enumerable = public-feed`, and `exact_byte_policy = token-only`. The useful observed facts are the JSON public-Gists row grammar, `updated_at` timestamps, GitHub's Link-header pagination cursor, and bounded parser behavior. It is now declared in `free-wide` as the second retained-local Tiny sweep provider after the date-separated fixture gate and Biggun parser agreement passed; Tiny still consumes only retained local listing objects and does not perform public API scraping itself.

`fragbin-public-2026-10-07.jsonl` and `fragbin-public-2026-10-10.jsonl` are the third provider-specific public listing/firehose corpus. They preserve low-rate unauthenticated reads of `https://www.fragbin.com/api/pastes` with public titles normalized, plus synthetic title-placement rows over the observed JSON listing grammar. The provider is a listing reader, not a no-account posting adapter: `receive_behavior = listing-token`, `enumerable = public-feed`, and `exact_byte_policy = token-only`. The useful observed facts are the JSON public-pastes row grammar, `page` and `limit` request fields, `count`, item ids, `createdAt` timestamps, language names, password flags, coarse view buckets, and no observed next cursor. It previously became the third retained-local Tiny sweep provider after the date-separated fixture gate and Biggun parser agreement passed. That historical admission remains useful evidence, but current source no longer declares it; Tiny consumes the three currently admitted retained-local listing sources and never scrapes public API pages itself.

FragBin returned HTTP 500 on October 17, October 18, and again on October 22 after bounded retries. CityB retains the parser, monitor recheck, prior fixtures, and durable negative rendezvous observations but removed the Tiny declaration; it does not treat the old parser proof as current network health. Pastebin Archive, GitHub public Gists, and Pastefy remain the three admitted listing sources, and no fourth provider enters Tiny sweeps without repeated dated captures plus Biggun agreement and source review.

Non-exact carriers now have a fixed lane policy. `rendered-token`, `redirect-token`, and `listing-token` providers may satisfy pointer, heartbeat, and route-hint discovery floors when the token checksum and later signed archive verification pass. They do not satisfy mirror/archive floors, they do not prove exact payload bytes, and they do not enter `free-stable` as easy exact-byte providers. If an operator wants a default discovery-only set later, it should be named separately, for example `free-discovery-stable`, so exact-byte archive mirrors and token-only discovery carriers are never mixed in one promotion ledger.

`live-deep-10-2026-09-16-122450z-provider-fixtures.jsonl` is the first retained exact-byte corpus for `free-deep-10`. It verified all ten newly native adapters in one live run: x0.at, curl.by, End2End.tech, file2.me, JuiceBox, TempFile.org, ayaya.beauty, hostb, hst.sh, and haste.rys.pw. The capture records provider-specific receive facts instead of guessing: curl.by and send-like services make the returned URL authoritative, End2End.tech receives by `FileID`, file2.me needs raw-URL normalization plus a short settle retry, TempFile.org receives at `/download`, hostb is chunked plus `/raw`, and hst.sh/haste.rys.pw use the Hastebin raw-key path. curl.by and End2End.tech entered `free-stable` on October 7; ayaya.beauty, hostb, hst.sh, JuiceBox, TempFile.org, and haste.rys.pw entered on October 10 after later evidence and source review. x0.at and file2.me stay in watch/research lanes.

`live-deep-text-10-2026-09-16-134253z-provider-fixtures.jsonl` is the first retained exact-byte corpus for `free-deep-text-10`. It verified all ten newly native text/paste adapters in one live run: paste.code-solutions.dev, paste.helpch.at, bytebin.lucko.me, api.pastes.dev, bpa.st, transfer.archivete.am, pastefy.app, pastefox.com, haste.zneix.eu, and bin.birdflop.com. The capture records provider-specific receive facts instead of guessing: paste.code-solutions.dev, paste.helpch.at, haste.zneix.eu, and bin.birdflop.com use the Hastebin `/documents` plus `/raw/<key>` flow; bytebin.lucko.me and api.pastes.dev return raw text from the created object URL; bpa.st posts JSON to the API and derives `/raw/<id>`; transfer.archivete.am accepts a PUT and makes the returned URL authoritative; Pastefy returns a paste URL that becomes exact through `/raw`; and PasteFox returns a slug that becomes exact through `/api/pastes/<slug>/raw`. paste.code-solutions.dev, paste.helpch.at, bytebin.lucko.me, api.pastes.dev, bpa.st, pastefy.app, pastefox.com, and bin.birdflop.com entered `free-stable` on October 10 after later evidence and source review. transfer.archivete.am and haste.zneix.eu stay in watch/research lanes.

`live-deep-web-10-2026-09-16-150259z-provider-fixtures.jsonl` is the first retained exact-byte corpus for `free-deep-web-10`. It verified all ten newly native web paste/file adapters in one live run: mclo.gs, Sourcebin, paste.agradip.fyi, SpaceBin, CrafterBin, qurl.sh, Mythical Paste, YukiAPI, AgentMediaTools, and paste.firnsy.com. The capture records provider-specific receive facts instead of guessing: mclo.gs and Mythical Paste post form content and return JSON raw URLs; Sourcebin posts JSON to `/api/bins` and reads `/raw/<key>/0`; paste.agradip.fyi uses the Hastebin `/documents` plus `/raw/<key>` flow; SpaceBin and paste.firnsy.com return redirects that become `/raw` endpoints; CrafterBin serves exact bytes from the returned URL; qurl.sh uploads to `/upload` and makes the returned URL authoritative; YukiAPI returns `raw_url` from its upload-text endpoint; and AgentMediaTools accepts JSON at `/api/paste` and returns `raw_url`. The run also proved that mclo.gs, Mythical Paste, and AgentMediaTools strip one final newline, so their adapters stage a no-final-newline payload before upload. mclo.gs, Sourcebin, paste.agradip.fyi, SpaceBin, CrafterBin, qurl.sh, Mythical Paste, and paste.firnsy.com entered `free-stable` on October 10 after later evidence and source review. YukiAPI and AgentMediaTools stay in watch/research lanes.

`live-deep-web2-10-2026-09-16-164535z-provider-fixtures.jsonl` is the first retained corpus for `free-deep-web2-10`. It verified all ten newly native web/API paste/file adapters in one live run: PasteHTML, OKFile, here.now, haste.unbelievaboat.com, rentry.co, files.offshore.cat, qu.ax, zoomie.sh, openSUSE Paste, and Debian Pastezone. PasteHTML, OKFile, here.now, haste.unbelievaboat.com, files.offshore.cat, zoomie.sh, openSUSE Paste, and Debian Pastezone produced exact or intentionally normalized exact receive bodies and later entered `free-stable`. Rentry.co and qu.ax produced rendered public pages that contained parseable CityB tokens but did not serve exact staged bytes, so CityB marks those receipts `digest_match=false` and retains the observed rendered HTML body for parser-diff and offline fixture replay.

`live-deep-web3-10-2026-09-16-180657z-provider-fixtures.jsonl` is the first retained corpus for `free-deep-web3-10`. It verified all ten newly native old-web/API paste adapters in one live run: CentOS Paste, rpa.st, AlmaLinux Paste, OpenStack Paste, yt-project Paste, OpenDev Paste, Gentoo LogPaste, Ubuntu China Paste, p.defau.lt, and paste2.org. CentOS, rpa.st, AlmaLinux, OpenStack, yt-project, OpenDev, and Gentoo produced exact or intentionally normalized exact receive bodies. Ubuntu China Paste, p.defau.lt, and paste2.org produced rendered public pages that contained parseable CityB tokens but did not serve exact staged bytes, so CityB marks those receipts `digest_match=false` and retains the observed rendered HTML body for parser-diff and offline fixture replay. CoShareX is implemented separately as a JSON-field carrier, but repeated anonymous API runs returned 409/400 upload rejections, so it is not part of the strict service set until later captures prove stable posting.

`free-deep-web4-10` is the sixth strict web/API bench. It currently contains Pastr, Valhalla Paste, Write.as, p.ip.fi, Kagit, ShareNotes, Pastebin.ai, da.gd, TinyURL, and clck.ru. Pastr and Valhalla Paste use Hastebin-compatible `/documents` plus `/raw/<key>` paths. Write.as posts JSON to `/api/posts`, discards returned management material, and probes the public `.txt` rendering. p.ip.fi posts the payload as multipart `paste` and treats the returned URL as the exact receive handle. Kagit posts form field `c` plus a short expiry and treats the JSON `url` as the exact receive handle. ShareNotes posts raw text to `/api/v1/notes` and probes `/api/v1/notes/<slug>` for a JSON `content` field; observed headers include a strict daily rate-limit policy. Pastebin.ai posts JSON to `/api/v1/pastes` and probes the returned `raw_url`; returned delete material is not retained. Pastr, Valhalla Paste, p.ip.fi, Kagit, ShareNotes, and Pastebin.ai entered `free-stable` on October 10 after later evidence and source review. da.gd, TinyURL, and clck.ru create short links whose redirect observations contain a CityB token target, so their receipts are useful token-discovery evidence with `digest_match=false`, not exact archive-byte evidence. Write.as stays in the watch/research lane. CleanURI is implemented but stayed out of the strict set after live probes generated short URLs that returned 404 from this host.

`live-deep-web4-10-2026-09-16-192622z-provider-fixtures.jsonl` is the first retained corpus for `free-deep-web4-10`. It passed all ten providers. Pastr, Valhalla Paste, Write.as, p.ip.fi, Kagit, ShareNotes, and Pastebin.ai produced exact or JSON-field exact receive bodies. da.gd, TinyURL, and clck.ru produced token-bearing redirect/interstitial observations with `digest_match=false`, and the converter retained those observed bodies rather than the staged local payload. The promoted exact-byte subset is now in `free-stable`; the redirect-token providers remain discovery-only.

`free-deep-web5-10` is the seventh strict web/API bench. It currently contains Scuttled, ti.fo, docs-md, 8gwifi, tnypst, Droptext, Luis Aranguren Paste, Ulvis, MeshaLive, and AISense 307.fi. Scuttled posts multipart content to `/paste/` and verifies exact bytes through the derived `/raw` URL. ti.fo accepts JSON at `/t`, now returns either JSON identity or a plain paste URL, and strips one trailing newline, so the adapter stages newline-normalized content. docs-md posts JSON to `/api/share`, records `rawUrl`, and also strips one trailing newline. 8gwifi posts JSON to `/api/pastebin`, derives `/api/pastebin/<id>/raw` instead of trusting observed localhost response URLs, and strips one trailing newline. tnypst posts markdown to the root form and verifies exact bytes from the derived `.md` URL. Scuttled, ti.fo, docs-md, 8gwifi, and tnypst entered `free-stable` on October 10 after later evidence and source review. Droptext and Luis Aranguren Paste expose rendered public pages that contain parseable tokens but not exact staged bytes. Ulvis, MeshaLive, and 307.fi are redirect-token carriers; CityB uses a token-bearing public URL for these because some shorteners reject synthetic domains.

`live-deep-web5-10-2026-09-16-210617z-provider-fixtures.jsonl` is the first retained corpus for `free-deep-web5-10`. It passed all ten providers. Scuttled, ti.fo, docs-md, 8gwifi, and tnypst produced exact or intentionally normalized exact receive bodies and later entered `free-stable`. Droptext and Luis Aranguren Paste produced token-bearing rendered pages with `digest_match=false`. Ulvis, MeshaLive, and 307.fi produced token-bearing redirect observations with `digest_match=false`. The non-exact providers remain discovery-only.

PasteShare-style services, including paste.brianrianrehan.com, are documented future candidates rather than part of this bench. They can return exact raw bytes, but their create responses include edit/delete management material. City B should only promote that family after transcript scrubbing, fixture conversion, and docs prove the retained corpus cannot leak operator management handles.

`--all-cases` expands the adapter recipe's declared replay cases. Use it before
promoting a free service from "interesting" to "usable": the capture should show
at least the verified path and the most likely negative paths for that provider
family.

## Not on the active roadmap

Paid-only or meaningfully pay-walled surfaces are intentionally excluded from
the mainline City B build plan. If they remain documented elsewhere, treat them
as non-goals for the core free-service product.

Examples:

- Bunny Storage + Pull Zone
- Backblaze B2
- Cloudflare R2
- Amazon S3 static website hosting

## Detailed notes for the current built-in free adapters

### paste.c-net.org

Relevant docs:

- <https://paste.c-net.org/>

Useful facts:

- the service documents console-friendly anonymous POST and PUT uploads;
- POST returns a paste URL that can be fetched directly;
- the published limit is 50 MiB;
- the published expiry is 180 days, renewed by each access;
- a raw TCP text endpoint is documented separately, but CityB's first adapter uses HTTPS POST.

Adapter implications:

- this is a strong free-wide text carrier because the receive URL is exact bytes rather than a viewer page;
- the access-renewed expiry makes repeated probe evidence alter future lifetime, so receipts must stay dated;
- it should remain outside `free-stable` until multiple dated CityB captures prove the one-shot live result is normal behavior.

### file.io

Relevant docs:

- <https://www.file.io/>
- <https://www.file.io/developers>

Useful facts:

- the public site says files up to 4 GB can be uploaded;
- no account or personal information is required to upload or download files;
- the REST API accepts file uploads plus expiry controls;
- the service deletes files once downloaded or once the expiry is reached;
- direct text upload is also documented.

Adapter implications:

- this is a good no-account filehost for pointer drops and small archive
  mirrors;
- the delete-after-download semantic is both the value and the wrinkle: one
  observer can consume the object before the rest of the fleet sees it;
- City B should treat it as a special retention class rather than pretending it
  behaves like a shared durable mirror;
- the adapter can support both multipart file upload and direct text upload, but must normalize them back into the same receipt model;
- the September 15, 2026 live repair probe did not prove a stable anonymous exact-byte path: `POST /` redirects to `www.file.io`, and following the redirect as POST reaches an HTTP 405 object-method response. CityB keeps the failure classifier and waits for a documented working path before changing receive semantics.

### Uguu

Relevant docs:

- <https://uguu.se/>
- <https://uguu.se/api>
- <https://uguu.se/faq>

Useful facts:

- the homepage says max upload size is 128 MiB;
- the homepage and FAQ say files expire after 3 hours;
- the API is one multipart `POST` to `https://uguu.se/upload`;
- the FAQ says downloads and visits are not tracked or logged, while active
  file metadata is retained until expiry.

Adapter implications:

- this should be treated as a strict short-TTL carrier;
- it is well suited to heartbeat, route-hint, and emergency pointer lanes;
- the API is simple enough to justify a built-in Rust adapter quickly;
- probe logic is straightforward direct fetch verification once the returned URL
  is known.

### Termbin

Relevant docs:

- <https://termbin.com/>

Useful facts:

- the service uses `nc termbin.com 9999` style posting;
- the returned result is a plain URL that can then be fetched over HTTPS;
- pastes can be deleted for the first 10 minutes from the same IP address with
  an HTTP `POST`;
- the site says data lifetime is one week.

Adapter implications:

- this is valuable because it diversifies transport mechanics instead of adding
  yet another multipart HTTP clone;
- a Termbin adapter likely deserves its own protocol class inside the same
  receipt model, because publication is raw TCP while observation is HTTP;
- it should stay pointer-only or small text-only material.

### sendit.sh

Relevant docs:

- <https://sendit.sh/>

Useful facts:

- the service documents CLI upload with `curl` and returns a `wget` command containing the fetch URL;
- the service documents retention as 1 day or 5 downloads;
- uploads can use an arbitrary requested path, but the returned fetch path is service-assigned;
- no account flow is required for the documented CLI path.

Adapter implications:

- this is useful as a short-lived HTTPS file/text carrier with exact-byte receive after parsing the returned URL;
- CityB must treat the returned `wget` URL as receipt-authoritative, not the requested upload path;
- the short retention makes it a pointer, heartbeat, or route-hint lane, not a durable mirror;
- it should remain in `free-wide` until repeated dated captures prove stability.

### beacon.host

Relevant docs:

- <https://beacon.host/>
- <https://beacon.host/api>

Useful facts:

- the service documents unauthenticated multipart upload with `POST /v1/upload` and a `file=@...` part;
- the API documentation says uploads return a public file link, and October 8 plus October 10, 2026 live probes observed returned URLs that served exact bytes;
- anonymous unauthenticated links are documented as expiring after about 24 hours;
- the simple upload path is documented for small files, with a roughly 4 MiB ceiling;
- anonymous publishing is low-rate and should be paced.

Adapter implications:

- CityB treats the returned URL as receipt-authoritative and verifies the served bytes before accepting a receipt;
- this is a `free-stable` short-lived pointer, heartbeat, route-hint, or small archive-shard carrier after date-separated exact captures survived monitor import, parser replay, dossier review, source review, and topology review;
- it is not a durable mirror, so operators should keep relying on archive signatures, erasure distribution, and continued monitor evidence rather than treating one beacon.host object as durable storage;
- missing returned URLs, challenge pages, and rate-limit responses should remain named provider failures rather than generic parse errors.

### storage.to

Relevant docs:

- <https://storage.to/docs/api>

Useful facts:

- the docs say anonymous uploads do not require an API key;
- the general API offers `init`, upload to presigned R2 URL, then `confirm`;
- the ShareX endpoint offers a simpler one-shot multipart upload path;
- anonymous callers are capped at 50 files per rolling 24 hours per device or
  IP and files expire after 3 days by default;
- free authenticated accounts remove the daily file cap and upload bandwidth
  quota while keeping the service free tier.

Adapter implications:

- this is a strong free filehost candidate because it is still free without an
  account but exposes a more structured API than simpler file bins;
- it fits temporary archive mirrors better than tiny heartbeat lanes;
- City B now uses the documented ShareX upload path for the built-in adapter
  and should retain the fuller init/confirm path as future expansion if the service semantics demand it;
- the September 15, 2026 live repair probe proved upload JSON with a public URL but did not prove exact-byte anonymous receive: the returned share URL served an HTTP 403 challenge page from this host, and guessed raw/download API paths returned JSON 404. CityB keeps this as drift evidence until documentation or live capture proves a stable raw path.

### free-deep-10 anonymous adapters

Relevant docs and observed endpoints:

- <https://x0.at/>
- <https://curl.by/>
- <https://api.end2end.tech/upload>
- <https://file2.me/api/upload>
- <https://box.juicey.dev/upload>
- <https://tempfile.org/api/upload/local>
- <https://ayaya.beauty/upload>
- <https://hostb.org/>
- <https://hst.sh/>
- <https://haste.rys.pw/>

Useful facts:

- x0.at accepts 0x0-style multipart file uploads and returns a direct URL;
- curl.by accepts `PUT` payloads and prints a `wget` command containing the exact receive URL;
- End2End.tech accepts multipart file uploads and returns a `FileID` that must be converted into `/download?id=...`;
- file2.me accepts multipart file uploads, returns a share URL, and served exact bytes only after the adapter converted that URL to `/raw/<slug>` and retried briefly;
- JuiceBox accepts multipart upload with a TTL field and returns JSON containing `url`;
- TempFile.org accepts multipart upload with `expiryHours` and serves exact bytes from the returned URL plus `/download`;
- ayaya.beauty accepts ShareX-style multipart upload and returns a `directLink`;
- hostb uses a two-step upload: create an upload URL, then POST the final chunk and normalize the result URL to `/raw`;
- hst.sh and haste.rys.pw are Hastebin-compatible: POST raw text to `/documents`, parse the key, and fetch `/raw/<key>`.

Adapter implications:

- keep these ten in `free-deep-10` until a later date-separated live corpus proves which ones stay boring across time;
- do not fold them into `free-wide` merely because they are native; `free-wide` already carries mixed-history drift providers and the deep bench is a separate research surface;
- use `cityb capture free-deep-10 --live --require-all` when the goal is to test this exact ten-provider set, and keep `--require-all` there because the point of the set is provider evidence rather than an easy operator quorum;
- promote from `free-deep-10` only after parser-diff replay, repeated dated exact-byte captures, and root-diversity scoring prove that a provider improves the default distribution plan.

### free-deep-text-10 anonymous text/paste adapters

Relevant docs and observed endpoints:

- <https://paste.code-solutions.dev/>
- <https://paste.helpch.at/>
- <https://bytebin.lucko.me/>
- <https://api.pastes.dev/>
- <https://bpa.st/>
- <https://transfer.archivete.am/>
- <https://pastefy.app/>
- <https://pastefox.com/docs/api>
- <https://haste.zneix.eu/>
- <https://bin.birdflop.com/>

Useful facts:

- paste.code-solutions.dev, paste.helpch.at, haste.zneix.eu, and bin.birdflop.com are Hastebin-compatible for the observed path: POST raw text to `/documents`, parse the returned key, and fetch `/raw/<key>`;
- bytebin.lucko.me and api.pastes.dev accepted raw POST bodies and served the same bytes from the returned object URL;
- bpa.st accepted JSON through its paste API and served exact text from `/raw/<id>`;
- transfer.archivete.am accepted a PUT upload and served exact bytes from the returned URL;
- Pastefy accepted a JSON text paste and served exact bytes from the returned paste URL plus `/raw`;
- PasteFox historically accepted anonymous JSON text pastes and served exact bytes from its raw route. Its published API is now `https://api.pastefox.com/v1/pastes`, with raw receive at `/v1/pastes/<slug>/raw`; the October 17 m21 probe reached that official endpoint but received a Cloudflare managed challenge, so the adapter records `provider-challenge` and remains under stable-set review. On October 18 a separate coherent `curl-impersonate:firefox147` capture received the same HTTP 403 challenge. That falsifies the simple “curl fingerprint alone” explanation on this host; the retained evidence does not distinguish IP reputation, rate/history, or changed provider policy.

Adapter implications:

- keep these ten in `free-deep-text-10` until a later date-separated live corpus proves which ones stay boring across time;
- do not fold them into `free-stable` merely because the first same-day run passed 10/10;
- treat bytebin.lucko.me as Bytebin-compatible `free-wide` evidence rather than a default recommendation: after a long exact-byte history, the required pointer path was rejected on November 2, 3, and 4, 2026, and the landing page also discourages routine use of that instance;
- use `cityb capture free-deep-text-10 --live --require-all` when the goal is to test this exact ten-provider set, and keep `--require-all` there because the point of the set is provider evidence rather than an easy operator quorum;
- promote from `free-deep-text-10` only after parser-diff replay, repeated dated exact-byte captures, and root-diversity scoring prove that a provider improves the default distribution plan.

### free-deep-web-10 anonymous web paste/file adapters

Relevant docs and observed endpoints:

- <https://api.mclo.gs/1/log>
- <https://sourceb.in/>
- <https://paste.agradip.fyi/>
- <https://spaceb.in/>
- <https://crafterbin.glennstack.dev/>
- <https://qurl.sh/>
- <https://pastes.mythicalsystems.org/docs>
- <https://yukiapi.site/upload-text?source=web>
- <https://agentmediatools.com/>
- <https://paste.firnsy.com/>

Useful facts:

- mclo.gs accepted form content at `/1/log` and returned JSON containing a raw URL;
- Sourcebin accepted JSON at `/api/bins` and served exact bytes from `/raw/<key>/0`;
- paste.agradip.fyi is Hastebin-compatible for the observed path: POST raw text to `/documents`, parse the key, and fetch `/raw/<key>`;
- SpaceBin accepted multipart `content=<file`, redirected to a paste slug, and served exact bytes from the slug plus `/raw`;
- CrafterBin accepted multipart `file=@payload` and served exact bytes from the returned URL;
- qurl.sh accepted a `PUT` with explicit TTL/download headers and served exact bytes from the first returned URL;
- Mythical Paste accepted form/JSON content at `/log` and returned a raw URL field;
- YukiAPI accepted multipart text upload through the `upload-text` endpoint and returned `raw_url`;
- AgentMediaTools accepted JSON at `/api/paste` and returned `raw_url`;
- paste.firnsy.com uses the mPaste form: POST multipart `data=<file` to `/paste`, follow the returned paste path, and fetch `/raw`.

Adapter implications:

- keep these ten in `free-deep-web-10` until a later date-separated live corpus proves which ones stay boring across time;
- do not fold them into `free-stable` merely because the first same-day corpus passed;
- prefer exact raw URLs and returned URLs; do not invent cursor/listing behavior for these services unless a documented or captured listing surface appears;
- use `cityb capture free-deep-web-10 --live --require-all` when the goal is to test this exact ten-provider set, and keep `--require-all` there because the point of the set is provider evidence rather than an easy operator quorum;
- promote from `free-deep-web-10` only after parser-diff replay, repeated dated exact-byte captures, transcript-scrubbing review, and root-diversity scoring prove that a provider improves the default distribution plan.

### free-deep-web2-10 anonymous web/API paste/file adapters

Relevant docs and observed endpoints:

- <https://pastehtml.dev/llms.txt>
- <https://www.okfile.com/llms.txt>
- <https://here.now/llms.txt>
- <https://haste.unbelievaboat.com/>
- <https://rentry.co/>
- <https://files.offshore.cat/>
- <https://qu.ax/>
- <https://zoomie.sh/>
- <https://paste.opensuse.org/>
- <https://paste.debian.net/>

Useful facts:

- PasteHTML accepted anonymous multipart upload at `/api/pastes` and returned `raw_url`; the adapter wraps the CityB text payload in a minimal HTML document and probes the returned raw URL;
- OKFile accepted anonymous multipart upload at `/api/upload/quick`, returned `downloadUrl`, and documents short-lived/download-limited anonymous files;
- here.now accepted anonymous publish creation at `/api/v1/publish`, a presigned `PUT`, finalization through `finalizeUrl`, and exact receive from the finalized `siteUrl/cityb.txt`; the adapter discards claim material and stores only the public receive URL in receipts;
- haste.unbelievaboat.com is Haste-compatible for the observed path: POST raw text to `/documents`, parse the key, and fetch `/raw/<key>`;
- rentry.co accepted a CSRF form/API flow at `/api/new`, returned a public page URL plus edit material that CityB discards, and the rendered page contained a parseable CityB token;
- files.offshore.cat accepted multipart `file=@payload` at `/api/upload` and served exact bytes from the returned `/api/file/<id>` URL;
- qu.ax accepted multipart text upload when CityB forces `filename=cityb.txt`; the returned public URL was a rendered page containing a parseable CityB token, not an exact raw-byte endpoint;
- zoomie.sh accepted JSON at `/api/v1/files` and served exact bytes from `markdown_url` after stripping one final newline from the staged payload;
- openSUSE Paste required a form fetch, cookie jar, authenticity token, and multipart `/pastes` submit before probing `/pastes/<id>/raw`;
- Debian Pastezone required form posting to the root endpoint and at least two line breaks in the submitted body, then served exact bytes from `/plainh/<id>`.

Adapter implications:

- keep these ten in `free-deep-web2-10` until a later date-separated live corpus proves which ones stay boring across time;
- do not fold them into `free-stable` merely because the first manual probes passed;
- treat claim tokens, edit tokens, and other provider control material as upload-time secrets that must not be copied into replay fixtures or public receipts;
- prefer provider-specific exact receive paths over generic HTML scraping; when exact raw bytes are unavailable but the rendered page contains a parseable token, mark the receipt as `digest_match=false` and keep it out of exact-byte promotion decisions;
- PasteHTML, here.now, openSUSE Paste, Debian Pastezone, Zoomie, rentry.co, and qu.ax each need a named normalization, rendered-token, or multi-step flow;
- use `cityb capture free-deep-web2-10 --live --require-all` when the goal is to test this exact ten-provider set, and keep `--require-all` there because the point of the set is provider evidence rather than an easy operator quorum;
- promote exact-byte providers from `free-deep-web2-10` only after parser-diff replay, repeated dated exact-byte captures, transcript-scrubbing review, and root-diversity scoring prove that a provider improves the default distribution plan. Rendered-token providers need a separate non-exact lane decision instead of pretending they are raw byte mirrors.

### free-deep-web3-10 old-web and API paste adapters

Relevant docs and observed endpoints:

- <https://paste.centos.org/>
- <https://rpa.st/>
- <https://paste.almalinux.org/>
- <https://paste.openstack.org/>
- <https://paste.yt-project.org/>
- <https://paste.opendev.org/>
- <https://paste.gentoo.zip/>
- <https://paste.cosharex.com/>
- <https://paste.ubuntu.org.cn/>
- <https://p.defau.lt/>
- <https://paste2.org/>

Useful facts:

- CentOS Paste accepted the Stikked form fields `name`, `title`, `lang`, `code`, `expire`, and `submit`, then exposed exact text through `/view/raw/<id>`;
- rpa.st and AlmaLinux Paste are Pinnwand-family forms: CityB fetches a cookie jar and `_xsrf`, posts to `/create`, discards deletion material, and probes `/raw/<id>` for exact bytes;
- OpenStack Paste, yt-project Paste, and OpenDev Paste are LodgeIt-family forms: CityB posts `language=text`, `code`, `webpage`, `private=on`, and `submit=Paste!`, then derives `/raw/<id>/` from the returned `/show/<id>/` location;
- OpenStack Paste, yt-project Paste, and OpenDev Paste normalized one final newline away in live probes, so the adapter strips one trailing newline before staging payloads for those providers;
- Gentoo LogPaste accepted `PUT /` with text and returned JSON `id`; CityB probes `/<id>/raw`;
- Ubuntu China Paste accepted an ordinary form after a PHP session-cookie fetch and rendered the payload at a numeric page containing a parseable CityB token, but no exact raw endpoint was observed;
- CoShareX accepted one anonymous JSON snippet at `/api/snippets`, but repeated runs returned 409/400 upload rejections even after run-unique slug salting, so it remains outside the strict ten-provider bench;
- p.defau.lt and paste2.org accepted ordinary forms and rendered public pages containing parseable CityB tokens, but no exact raw endpoint was observed.

Adapter implications:

- keep `free-deep-web3-10` as the strict bench for the whole family, while the seven exact-byte Stikked/Pinnwand/LodgeIt/LogPaste providers now also live in `free-stable`;
- treat Stikked, Pinnwand, LodgeIt, and LogPaste adapters as exact-byte stable providers only while their raw receive URL remains stable across dated captures;
- treat Ubuntu China Paste, p.defau.lt, and paste2.org as rendered-token carriers; they are useful for parser-diff and non-exact discovery, not exact-byte promotion;
- keep CoShareX in the adapter catalog as a drift candidate, not a strict-set dependency, until later captures prove stable anonymous posting;
- use `cityb capture free-deep-web3-10 --live --require-all` when the goal is to test this exact ten-provider set.

### free-deep-web4-10 mixed paste/API and shortener adapters

Relevant docs and observed endpoints:

- <https://pastr.xditya.me/>
- <https://paste.valhalladev.org/>
- <https://write.as/>
- <http://p.ip.fi/>
- <https://kagit.org/>
- <https://sharenotes.dev/>
- <https://pastebin.ai/>
- <https://da.gd/>
- <https://tinyurl.com/>
- <https://clck.ru/>

Useful facts:

- Pastr and Valhalla Paste accepted the Hastebin-compatible `POST /documents` flow and served exact text through `/raw/<key>`;
- Write.as accepted anonymous JSON at `/api/posts`, returned a public URL, and served exact text from the derived `.txt` URL; the adapter discards token/edit response fields;
- p.ip.fi accepted multipart field `paste` and returned a plain public URL whose body matched the staged bytes;
- Kagit accepted form field `c` plus expiry field `e=7d`, returned JSON `url`, and served exact staged bytes from that URL;
- ShareNotes accepted raw text at `/api/v1/notes`, returned note identity data, and served exact staged bytes from JSON field `content` at `/api/v1/notes/<slug>`;
- ShareNotes exposed a daily rate-limit policy in response headers during probing, so the built service template uses a conservative one-day request window;
- Pastebin.ai accepted anonymous JSON at `/api/v1/pastes`, returned `raw_url`, and served exact staged bytes there; the adapter discards returned delete-token material;
- da.gd accepted a generated URL containing the CityB token, returned a public short URL, and exposed the token through either a no-follow `Location` header or a fresh-link interstitial HTML body depending on request headers;
- TinyURL accepted a generated URL containing the CityB token, returned a public short URL, and exposed the token through either redirect headers or a deprecated-API preview page;
- clck.ru accepted a generated URL containing the CityB token, returned a public short URL, and exposed the token through a Yandex redirect URL in the no-follow `Location` header and HTML body;
- CleanURI is implemented but not in `free-deep-web4-10`; September 16, 2026 live probes returned JSON `result_url` values whose public short URLs immediately served 404 from this host;
- redirect-token carriers deliberately produce `digest_match=false` because the public body is not the staged CityB payload.

Adapter implications:

- keep the first seven providers as exact-byte candidates only after the live capture converter records dated fixture evidence;
- keep da.gd, TinyURL, and clck.ru in a non-exact research lane until review decides whether redirect-token proofs improve discovery enough to justify promotion;
- keep CleanURI out of strict benches until a dated corpus proves generated short URLs are retrievable;
- do not retain Write.as or Pastebin.ai management/delete material in fixture transcripts;
- de-rank ShareNotes in repeated cycles if its daily anonymous quota is easy to exhaust;
- use `cityb capture free-deep-web4-10 --live --require-all` when the goal is to test this exact ten-provider set.

### free-deep-web5-10 mixed paste/API, rendered, and shortener adapters

Relevant docs and observed endpoints:

- <https://scuttled.net/paste/>
- <https://ti.fo/>
- <https://docs-md.com/>
- <https://8gwifi.org/pastebin.jsp>
- <https://tnypst.xyz/>
- <https://droptext.cc/>
- <https://paste.luisaranguren.com/>
- <https://ulvis.net/>
- <https://meshalive.com/>
- <https://aisenseapi.com/services/v1/url_shortener>

Useful facts:

- Scuttled accepted multipart field `content=<payload>` and served exact bytes through `/raw`;
- ti.fo accepted JSON at `/t`, returned a plain paste URL during the retained run, and served exact bytes after CityB removed the final staged newline before upload;
- docs-md accepted JSON at `/api/share`, returned `rawUrl`, and served exact bytes after CityB removed the final staged newline before upload;
- 8gwifi accepted JSON at `/api/pastebin`, returned an `id`, and served exact bytes from a derived raw URL after CityB removed the final staged newline before upload; observed response URLs can contain localhost and are not trusted;
- tnypst accepted URL-encoded markdown and served exact bytes through the derived `.md` URL;
- Droptext accepted a classic HTML form post and served a rendered page containing the CityB token, not exact staged bytes;
- Luis Aranguren Paste required a fresh `ajax_token`, accepted the Knoxious Pastebin API form, and served a rendered page containing the CityB token, not exact staged bytes;
- Ulvis, MeshaLive, and 307.fi returned short URLs whose no-follow redirect observations contained the CityB token;
- redirect-token adapters use `https://www.gnu.org/software/bash/?cityb=<token>` as the token-bearing target because Ulvis rejected synthetic test domains during probing.

Adapter implications:

- treat Scuttled, ti.fo, docs-md, 8gwifi, and tnypst as exact-byte candidates only after later dated captures prove that the observed newline and raw URL behavior persists;
- treat Droptext and Luis Aranguren Paste as rendered-token carriers until a raw receive path is observed;
- treat Ulvis, MeshaLive, and 307.fi as non-exact redirect-token carriers;
- keep `free-deep-web5-10` strict with `cityb capture free-deep-web5-10 --live --require-all` while building the evidence history.

## Detailed notes for the current built-in free account-backed adapters

### GitHub Gists

Relevant docs:

- <https://docs.github.com/en/rest/gists/gists>

Useful facts:

- public gists can be read anonymously;
- creating gists requires a signed-in GitHub account and a token;
- the API returns `raw_url` for file contents;
- the API only includes up to 1 MiB of content inline per file, and larger
  contents require fetching `raw_url` or cloning.

Adapter implications:

- this is a good free durable text surface for pointers, receipts, and human
  recovery notes;
- it should remain text-first, not archive-first;
- City B now probes `raw_url` directly and treats the pretty gist page as
  operator-facing, not receipt-authoritative.

### GitLab Snippets

Relevant docs:

- <https://docs.gitlab.com/api/snippets/>
- <https://docs.gitlab.com/user/snippets/>

Useful facts:

- the API is available on the Free tier;
- snippets expose both `raw_url` and `web_url`;
- creating snippets is documented as rate limited to 300 requests per hour per
  authenticated user.

Adapter implications:

- this is the GitLab-side counterpart to GitHub Gists;
- the adapter should preserve both `web_url` and `raw_url`, but probe the raw
  URL for byte identity;
- it fits pointer and operator-note lanes better than archive mirrors.

### GitHub Pages

Relevant docs:

- <https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site>

Useful facts:

- GitHub Pages is available in public repositories with GitHub Free;
- Pages sites are public on the internet;
- the site can be built from a branch/folder or a GitHub Actions workflow;
- GitHub Actions is free for public repositories.

Adapter implications:

- this belongs in the same family as `netlify-drop`, but with repository-backed
  static publication rather than drag-and-drop;
- it is a strong free pointer-page surface;
- a City B staged adapter should emit the exact site tree plus operator
  publishing notes, not try to infer repository structure after the fact.

### GitLab Pages

Relevant docs:

- <https://docs.gitlab.com/user/project/pages/>

Useful facts:

- GitLab Pages is documented on the Free tier;
- Pages sites run on GitLab-provided infrastructure at no additional cost;
- the service supports plain HTML/CSS/JavaScript and static site generators.

Adapter implications:

- this is a strong free static-site target for durable pointer pages and small
  static mirrors;
- it likely belongs as a native staged adapter because the operator flow is
  repository/CI owned rather than one simple anonymous upload.

### Codeberg Pages

Relevant docs:

- <https://docs.codeberg.org/codeberg-pages/>

Useful facts:

- Codeberg Pages provides `codeberg.page` URLs or custom domains;
- the service is described as free/libre open source software;
- deployment can be driven by a webhook or Forgejo Actions.

Adapter implications:

- this is the strongest less-corporate static publication candidate presently
  documented cleanly enough to matter;
- the staged adapter should emit the site tree plus deployment notes for the
  webhook/Forgejo-Actions split.

### Codeberg Releases

Relevant docs:

- <https://docs.codeberg.org/git/using-tags/>

Useful facts:

- releases are enabled per repository in settings;
- releases are created from the repository release UI and linked to tags;
- attached files are downloaded from the release surface.

Adapter implications:

- this is a good less-corporate counterpart to GitHub/GitLab Releases;
- the first honest version is a staged operator-owned adapter, not a built-in
  authenticated mutator.

## Active build order

### Tier 1: already implemented no-account or optional-account adapters

1. Filebin
2. paste.rs
3. dpaste
4. 0x0
5. Catbox
6. Litterbox
7. /tmp/files
8. GitHub Releases
9. GitLab Releases
10. Netlify Drop

### Tier 2: current anonymous/no-account native adapters

11. file.io
12. Uguu
13. Termbin
14. paste.c-net.org
15. sendit.sh
16. NullPaste
17. temp.sh
18. tmpfile.link
19. storage.to
20. beacon.host
21. x0.at
22. curl.by
23. End2End.tech
24. file2.me
25. JuiceBox
26. TempFile.org
27. ayaya.beauty
28. hostb
29. hst.sh
30. haste.rys.pw
31. paste.code-solutions.dev
31. paste.helpch.at
32. bytebin.lucko.me
33. api.pastes.dev
34. bpa.st
35. transfer.archivete.am
36. pastefy.app
37. pastefox.com
38. haste.zneix.eu
39. bin.birdflop.com
40. mclo.gs
41. Sourcebin
42. paste.agradip.fyi
43. SpaceBin
44. CrafterBin
45. qurl.sh
46. Mythical Paste
47. YukiAPI
48. AgentMediaTools
49. paste.firnsy.com

Why this order:

- `file.io` is the simplest documented API lift;
- Uguu is almost as simple and gives a very explicit short-TTL lane;
- Termbin adds real transport diversity instead of more multipart sameness;
- paste.c-net.org, sendit.sh, NullPaste, temp.sh, and tmpfile.link each have useful exact-byte evidence, so they belonged in `free-wide` before later promotion to `free-stable`;
- storage.to is more complex, but it buys larger temporary mirrors while still
  supporting anonymous uploads;
- the deep benches now have checked-in exact-byte, rendered-token, and redirect-token corpora through `free-deep-web5-10`. The October 10 source review promoted 40 exact-byte providers from those benches into `free-stable`; the remaining question is which watch-only, rendered-token, and redirect-token providers deserve future discovery lanes without weakening the exact-byte mirror lane.

### Tier 3: current free account-backed native adapters

50. GitHub Gists
51. GitLab Snippets
52. GitHub Pages
53. GitLab Pages
54. Codeberg Pages
55. Codeberg Releases

Why this order:

- Gists and snippets are the smallest lifts because they are text-first and
  have explicit raw URLs, which is why they were promoted into the built-in
  adapter set first;
- Pages and release adapters are higher-value but require more operator
  guidance around repository/CI publication, which is why they remain staged
  rather than implicit mutators;
- Codeberg deserves first-class attention because it is free/libre and less
  platform-centralized than the large corporate hosts.

## What to build next in code

1. Turn recipe metadata into service-native receive behavior only where a
   documented surface exists:
   - provider cursor expiry;
   - provider-specific continuation fields;
   - static index freshness and cache drift;
   - release asset redirects;
   - raw snippet URL rotation;
   - returned-URL-only refusals that tell the operator exactly what to paste
     into `collect probe`.
2. Expand the checked-in fixture corpus from real public-service captures:
   - verified current pointer;
   - expiry or moderation;
   - rate limit;
   - redirect drift;
   - permission failure;
   - oversized body;
   - wrong but parseable encoding;
   - stale pointer;
   - malformed provider JSON or HTML listing.
3. Feed captured semantics into more operator surfaces. `cycle next` now ranks
   degraded service/lane repairs and attaches recipe, receive, and
   fixture-template commands. The next improvement is provider-specific expiry,
   cursor, and field-name guidance only where captured fixtures prove those
   semantics.
4. Keep named retention classes and provider-health facts in receipts, plans,
   review, and Biggun replay. The scheduler should continue choosing from
   observed reliability, correlated roots, and lane fit rather than adapter
   brand count.
5. Decide any further free-service promotions only after recipe metadata,
   captured fixtures, and replay evidence show that the new service adds a
   distinct receive behavior or failure mode.

## Live no-account smoke harness

`cityb capture free-stable|free-five|free-wide|free-deep-10|free-deep-text-10|free-deep-web-10|free-deep-web2-10|free-deep-web3-10|free-deep-web4-10|free-deep-web5-10` is the live-service integration fixture. It prints a skip report unless `--live` is explicit or `CITYB_LIVE_FREE_SERVICES=1` is set for the legacy wrapper, builds a temporary retained City B root, attempts real `cityb dead-drop post --require --json` calls for the selected no-account adapters, and converts the retained transcripts into replay fixtures. The default named set is `free-stable`; use `cityb adapter doctor free-stable --json` when the exact current list matters rather than copying its size into prose. Use `cityb capture free-wide --live --min-passed 8` for the wider drift bench, any strict `free-deep-*` set with `--require-all` for that evidence bench, or `--adapters "dpaste sendit"` to narrow the run. Set `--capture-dir DIR` to keep the temporary retained root, per-adapter stdout JSON, and per-adapter stderr text. `scripts/live-free-service-smoke.sh` remains only as a compatibility wrapper over this Rust command.

The 2026-09-12 live free-five run is the historical five-service reality checkpoint:
Filebin returned a URL before the exact payload was immediately available and
then succeeded on settle retry 1; paste.rs, dpaste, and Catbox returned the
expected token-bearing bytes; 0x0 returned HTTP 503 before issuing a carrier
URL. The harness therefore passed the quorum posture and failed the
all-must-pass posture. That is a good City B result: provider drift becomes named
evidence, not a silent test failure.

The harness is intentionally opt-in because it mutates public services. It is
also intentionally not an account manager. Account-backed services should be
tested with explicit operator-owned tokens and separate scripts that make token
requirements obvious at startup.

That keeps City B aligned with its real audience: operators who need something
capable, reproducible, and accessible without assuming paid infrastructure.
