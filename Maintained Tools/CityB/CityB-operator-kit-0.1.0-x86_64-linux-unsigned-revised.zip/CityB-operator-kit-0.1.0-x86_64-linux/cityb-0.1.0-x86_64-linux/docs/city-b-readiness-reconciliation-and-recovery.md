# CityB readiness, reconciliation, and recovery contract

This document is the operator contract joining CityB's ordinary cockpit,
current-generation archive ceremony, adaptive capacity evidence, topology
facts, long-amnesia recovery, binary identity, and Nix automation. The
implementation is authoritative; this page explains how the pieces compose.

## One readiness language

An operator command can execute correctly while discovering that the
deployment is not operationally ready. CityB now reports those as different
facts on `next`, `check`, `doctor`, `operator card`, `provider health`,
`rendezvous`, `monitor status`, and `monitor nurse`:

- `execution_success`: the requested inspection or transaction executed
  without an internal command failure;
- `operational_ready`: no retained generation, release-trust, monitor,
  provider-health, archive-capacity, or field-pack action remains;
- `operational_state`: `ready`, `action-required`, or `blocked`;
- `current_service_ready` and `current_service_state`: whether the presently
  admitted CityB remains usable, independently of maintenance work;
- `readiness_grade`: `ready`, `ready-degraded`, `maintenance-required`, or
  `blocked`;
- `recovery_ready`: whether the retained durable anchor, signed pointer chain,
  archive inclusion, and field pack form a complete long-amnesia fallback;
- `primary_action_detail`: the first action with code, command, reason, and
  blocking status;
- `action_chain`: one ordered list of that action and the work after it.

`success=true` remains compatible command status. It is not an alias for
`operational_ready=true`. Automation must use the latter when deciding whether
the room is genuinely green. Read-only surfaces discover an explicit `--root`
first and otherwise use `./city-b-artifacts` only when that directory already
exists; inspection does not create a root merely to make the answer look
complete.

The availability floor is deliberately concrete. The current generation must
be current, reconstructable at its receipt threshold, release-trust admitted,
and paired with a ready field pack; latest exact pointer providers must remain
at or above the reconstruction-derived floor. A failed stable provider or a
largest-root-loss deficit can therefore produce `ready-degraded` while the
signed current archive remains usable. Maintenance still appears in the
ordered action chain and makes `readiness_grade=maintenance-required`; it does
not get mislabeled as an outage.

The same surfaces also publish the same five archive-capacity counters:

- `archive_capacity_proven`;
- `archive_capacity_repair_needed`;
- `archive_capacity_unproven`;
- `archive_capacity_recovered_watch`;
- `archive_capacity_pointer_only`.

Source membership and dated capacity evidence change independently. Read their
current named buckets from `stil snapshot --json`; inspect the roster with
`cityb service ls --service-set free-stable --json`. An empty retained capacity
ledger must report zero evidence-backed capacity rather than laundering source
eligibility into a successful probe.

## Current-generation reconciliation

`cityb reconcile` is the guided ceremony. It is a dry-run by default and
reports all eleven executable steps:

1. build a release from the current three binaries, or use `--release` for an
   already signed reviewed artifact;
2. sign the canonical `SHA3SUMS` payload with the selected OpenSSH identity;
3. persist or validate the retained release-trust policy;
4. verify the selected signed release before any provider posting;
5. transactionally refresh the archive-erasure generation for the current
   provider set;
6. spray the current shards;
7. inspect current receipts;
8. reconstruct and admit the release through the persisted trust policy;
9. regenerate the field pack;
10. regenerate the recovery card;
11. finish by evaluating `cityb next` and forward its actual primary action
    when the result is not green.

Example:

```sh
cityb reconcile \
  --root ./city-b-artifacts \
  --deployment ./city-b.toml \
  --service-set free-stable \
  --signing-key /secure/cityb-release-key \
  --allowed-signers /secure/cityb-allowed-signers \
  --signer-identity cityb-release \
  --json

# Review first. Public posting begins only with both flags:
cityb reconcile \
  --root ./city-b-artifacts \
  --deployment ./city-b.toml \
  --service-set free-stable \
  --signing-key /secure/cityb-release-key \
  --allowed-signers /secure/cityb-allowed-signers \
  --signer-identity cityb-release \
  --apply --live --json
```

Local generation refresh can complete under `--apply` without `--live`; the
command then stops with an exact continuation rather than posting remotely.
The selected geometry is a generated plan fact, not a constant in this
document. Previous plans, receipts, and capacity records move under the generation
history and remain forensic evidence. They cannot satisfy a current collect or
adoption recommendation.

Release signing is distribution-complete: `release sign --apply` writes the
OpenSSH signature into the release directory, rebuilds the archive through a
temporary sibling, atomically replaces the archive, recomputes its SHA3-256,
and updates the external manifest. Thus the archive sprayed to providers—not
only a sidecar left on the operator machine—contains the signature required by
`release verify --signature-policy require-verified`. `release archive
--binary-dir DIR` packages three already reviewed binaries without silently
rebuilding different bytes.

The ceremony refuses to rotate an existing trust policy unless `--force` is an
explicit part of a reviewed trust change. A resumed ceremony checks the
selected allowed-signers path, identity, and namespace against the retained
policy.

## Adaptive archive-capacity evidence

Pointer success is not archive-shard capacity. One live monitor tick now runs
one bounded adaptive probe in addition to its pointer work and one bounded
recheck of an existing shard when a current plan permits it. The rotating
ladder is:

| Requested band | Approximate payload | Earned meaning |
|---|---:|---|
| `pointer` | 4 KiB | transport can carry more than the pointer lane |
| `small` | 64 KiB | `small-shard` |
| `medium` | 256 KiB | `medium-shard` |
| `large` | 1 MiB | `large-shard` |

```sh
cityb dead-drop archive capacity-soak \
  --root ./city-b-artifacts --service-set free-stable --json
cityb dead-drop archive capacity-soak \
  --root ./city-b-artifacts --provider dpaste --band medium --apply --json
cityb dead-drop archive capacity \
  --root ./city-b-artifacts --service-set free-stable --json
```

Dry-run chooses the least-observed provider and reports the next size without
posting. Applied probes create a valid CityB shard payload, post it through the
native adapter, retrieve and byte-verify it, and append a dated record to
`city-b-archive-capacity-evidence.jsonl`. Failures name upload, retrieval,
byte-verification, or transport phase. Capacity classes include
`pointer-only`, `small-shard`, `medium-shard`, `large-shard`,
`recovered-watch`, and `repeated-capacity-failure`.

Archive planning uses proven capacity when ordering otherwise eligible
assignments. An unproven exact-byte provider remains visible and may be needed
to reach the requested erasure width, but it no longer ranks as equivalent to
a provider that repeatedly carried the required size. Adapter eligibility,
dated capacity, and provider-set membership remain separate facts.

## Topology facts and rendezvous mechanisms

Each service may carry typed, dated topology metadata:

```toml
provider_operator = "example-operator"
hostname = "drops.example.net"
dns_family = "dual-stack"
ip_addresses = "192.0.2.10,2001:db8::10"
asns = "AS64500"
cdn = "example-cdn"
hosting_root = "example-hosting-root"
topology_confidence = "operator-declared"
topology_observed_date = "2026-10-14"
```

Validation checks hostname shape, IP syntax, ASN syntax, DNS-family values,
confidence vocabulary, and ISO date shape. Unknown is a real state: inferred
or catalog-only services no longer receive fictional independent roots.
`rendezvous doctor --live-topology` can add current DNS/IP/ASN/CDN observations
without rewriting operator declarations. Scores ignore unknown or unverified
roots rather than treating absence of evidence as independence.

Provider carrier classes and CityB mechanisms are different dimensions.
`provider_missing_classes` asks which carrier behaviors are absent from the
selected provider declaration. `system_capabilities` reports mechanisms such
as `pointer-chain`, `fragment-share`, `erasure-archive`, and `public-anchor`.
An erasure archive is not a provider type, and a pointer chain is not a public
listing service.

## One-command long-amnesia recovery

`cityb recover` composes the receive-side recovery transaction. It is dry-run
by default and never posts to a provider:

```sh
cityb recover \
  --root ./city-b-artifacts \
  --deployment ./city-b.toml \
  --anchor-source ./reviewed-current-anchor.json \
  --json

cityb recover \
  --root ./city-b-artifacts \
  --deployment ./city-b.toml \
  --anchor-source ./reviewed-current-anchor.json \
  --apply --json
```

Apply performs this fail-closed chain:

```text
stale field pack
  -> durable-anchor policy, native proof, append-only and split-view gates
  -> signed CityB archive/pointer chain verification
  -> current-generation shard status and retrieval
  -> exact-byte reconstruction
  -> persisted OpenSSH release-trust admission
  -> field-pack export and verification
  -> recovery-card regeneration
  -> cityb next
```

An HTTP anchor source and provider shard reads may use the network; the report
distinguishes `network_read` from `remote_mutation`. Recovery will not invent a
missing anchor policy, archive plan, receipt set, or release-trust policy. An
old but still authoritative plan is interpreted through its own immutable
snapshot unless the operator explicitly supplies `--service-set` as an
additional current-set gate.

`cityb-biggun anchor-amnesia` proves the whole local transaction with a real
Ed25519/OpenSSH signing key, a sealed signed release archive, a local 2+1
erasure plan, two retrievable data shards, a durable native-proof anchor, an
archive-verified pointer-chain member, release admission, regenerated handoff
artifacts, and Tiny missed-cycle execution. It also retains the negative
native-proof and missing-slot/anchor-fallback cases.

## Durable binary and deployment identity

Every binary's `version --json` reports:

- package version and compiled role/platform;
- source revision, including a dirty marker when appropriate;
- semantic build identity;
- SHA3-256 of the invoked artifact;
- provider-set generation;
- bound release identity, or `unbound` outside a release.

Monitor comparisons use semantic build identity rather than only the wrapper
path or wrapper digest. A Nix launcher around the same CityB build therefore
does not appear to be an unexplained binary replacement. Release manifests,
field packs, provider-set generations, and monitor reports retain their own
identities because one hash cannot stand in for every layer.

The flake exports exactly three Rust binaries, the public
`nixosModules.default`/`nixosModules.cityb` automation module, m21's explicit
Stil office, and the inert `stil-foundation` integration object. The public
NixOS module is opt-in:

```nix
{
  services.cityb = {
    enable = true;
    root = "/var/lib/cityb/root";
    deployment = "/var/lib/cityb/city-b.toml";
    stateDir = "/var/lib/cityb/monitor";
    fixtureRoot = "/var/lib/cityb/evidence";

    monitor.enable = true;
    monitor.live = false; # inclusion alone never permits public posting
    monitor.preset = "all-free-rotation";
    monitor.vantageId = "host-name";
    monitor.egressLabel = "operator-selected-egress";
    # The monitor already performs bounded intake. Enable evidenceIntake
    # instead of monitor only on a host receiving monitor state elsewhere.
    evidenceIntake.enable = false;
    truthChecks.enable = true;
    truthChecks.quick = true;
  };
}
```

The module creates bounded oneshot services and persistent timers for provider
monitoring, local evidence intake, and Biggun truth checks. When `deployment`
is non-null, each enabled job first validates that exact manifest, so a timer
cannot silently operate beside a malformed or unintended declarative identity.
Public mutation is off unless `monitor.live = true`; evidence intake and truth
checks are local. Monitor jobs retain explicit vantage and egress labels, have
a bounded process-tree lifetime, and compact reports after each attempt. The
default dedicated identity keeps all writable state under `/var/lib/cityb`.
An established operator state can be adopted with `createUser = false` and
`allowHomeState = true`; the latter changes `ProtectHome` only to read-only and
leaves the three declared CityB paths as the sole writable home exceptions.
Adoption does not create, chmod, or chown those retained paths. It creates no
fourth binary and does not turn Tiny into an operator surface.

## Retained storage and operator disaster recovery

`cityb storage status|plan|prune` makes retained-root growth visible without
turning cleanup into an unsafe recursive delete. Status and plan are read-only;
prune is a dry run unless `--apply` is explicit. The classifier protects
current authority, trust policy, evidence, admission records, receipts,
current and forensic archive/cycle generations, and unknown material. Only
named reproducible fault caches, generated `city-b-biggun-truth-*` workrooms,
and transient field-pack refresh staging are removable. The conservative
`city-b-*` fallback remains protected for unknown state, but it no longer turns
hundreds of megabytes of duplicated Biggun proof workrooms into authority.
Apply repeats ownership, same-device, symlink, hardlink, and path
checks and writes a local prune receipt.

`cityb disaster-recovery inventory|inspect|export|verify|restore` solves a different
problem: loss of the operator machine. Inventory covers council continuity,
signed store, release trust, anchor policy/history, generation records,
correspondence fleet state, and explicitly named external signing identities.
Export streams that manifest and its bytes directly into `age`; no plaintext
archive is written. Verify decrypts and hashes without restoring. Restore
pre-verifies the whole bundle, is dry-run first, and on `--apply` uses atomic
files plus 0600 permissions for sensitive entries. Field packs remain public
node material and are not mistaken for this private continuity archive.
Inventory, inspect, export, and verify never print `ROOT`, `IDENTITY`, `FD`, or
`RESTORED_ROOT` inside an apparently executable action. They expose the known
argv prefix, `missing_inputs`, and `action_executable=false` until the operator
supplies each external value.

The original mode deliberately requires an operator-chosen age
recipient/identity. The additional sovereign mode accepts a normalized account
name and two private password descriptors, then deterministically derives the
age identity using fixed, bounded Argon2id v1.3 parameters: 64 MiB, three
iterations, four lanes, and 32 output bytes. It allows recovery from human
memory plus the encrypted artifact without persisting another random recovery
identity. It refuses passwords in argv, environment variables, and regular
files.

The sovereign artifact publicly carries its account name and format/KDF policy,
and is an offline password verifier. Weak passwords remain weak authority. A
new password creates a new artifact generation but cannot revoke an adversary's
copy of an old generation. This is not credential-only account recovery because
one encrypted artifact is still required. [`stil-foundation.nix`](../stil-foundation.nix)
can describe that artifact as opaque Monsternix `recovery-escrow`, generate a
strict full catalog and total observation only from explicit current
Monsternix facts, and report whether the accepted system even carries the
required Experimental porches. It grants no transport, enrollment, decryption,
restore, or activation authority. See
[stil-foundation.md](stil-foundation.md).

External release-signing material enters either bundle only through an explicit
`--include` path whose permissions pass the private-file gate.

## Remaining evidence work

The machinery is complete enough to operate, but empirical facts still need
time. Keep the monitor running, import date-separated capacity evidence, and
replace unverified topology declarations with dated observed roots. The
reconciliation command can only finish genuinely green when current release
trust, current-generation receipts, the monitor, provider health, and the
field pack are all green. That strictness is the point: a successful command
must never erase unfinished operational work.
