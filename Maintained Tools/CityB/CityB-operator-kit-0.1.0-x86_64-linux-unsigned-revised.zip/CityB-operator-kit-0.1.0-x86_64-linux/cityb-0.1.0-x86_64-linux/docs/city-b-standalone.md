# City B standalone repository

City B is maintained as a focused, buildable source tree. This repository must
stand on its own:

```sh
nix run .#cityb -- capabilities
nix run .#cityb-node -- capabilities
nix run .#cityb-biggun -- capabilities
nix build .#cityb .#cityb-portable
nix flake check
nix run .#cityb -- operator card --root ./city-b-artifacts --deployment ./city-b.toml --json
nix run .#cityb -- version --json
nix run .#cityb-node -- version --json
nix run .#cityb-biggun -- version --json
nix run .#cityb -- up --root ./city-b-artifacts --deployment ./city-b.toml --json
nix run .#cityb -- check --root ./city-b-artifacts --deployment ./city-b.toml --json
nix run .#cityb -- next --root ./city-b-artifacts --deployment ./city-b.toml --json
nix run .#cityb -- reconcile --root ./city-b-artifacts --deployment ./city-b.toml --service-set free-stable --json
nix run .#cityb -- recover --root ./city-b-artifacts --deployment ./city-b.toml --anchor-source ANCHOR_FILE_OR_URL --json
nix run .#cityb -- run --root ./city-b-artifacts --json
nix run .#cityb -- deployment init --out ./city-b.toml --service-set free-stable
nix run .#cityb -- deployment init --out ./city-b-wide.toml --service-set free-wide
nix run .#cityb -- deployment init --out ./city-b-deep-10.toml --service-set free-deep-10
nix run .#cityb -- deployment init --out ./city-b-deep-text-10.toml --service-set free-deep-text-10
nix run .#cityb -- deployment init --out ./city-b-deep-web-10.toml --service-set free-deep-web-10
nix run .#cityb -- deployment init --out ./city-b-deep-web2-10.toml --service-set free-deep-web2-10
nix run .#cityb -- deployment init --out ./city-b-deep-web3-10.toml --service-set free-deep-web3-10
nix run .#cityb -- deployment init --out ./city-b-deep-web4-10.toml --service-set free-deep-web4-10
nix run .#cityb -- deployment init --out ./city-b-deep-web5-10.toml --service-set free-deep-web5-10
nix run .#cityb -- adapter doctor free-wide --fixture-root fixtures/cityb/free-service-replay --json
nix run .#cityb -- adapter doctor free-deep-10 --fixture-root fixtures/cityb/free-service-replay --json
nix run .#cityb -- adapter doctor free-deep-text-10 --fixture-root fixtures/cityb/free-service-replay --json
nix run .#cityb -- adapter doctor free-deep-web-10 --fixture-root fixtures/cityb/free-service-replay --json
nix run .#cityb -- adapter doctor free-deep-web2-10 --fixture-root fixtures/cityb/free-service-replay --json
nix run .#cityb -- adapter doctor free-deep-web3-10 --fixture-root fixtures/cityb/free-service-replay --json
nix run .#cityb -- adapter doctor free-deep-web4-10 --fixture-root fixtures/cityb/free-service-replay --json
nix run .#cityb -- adapter doctor free-deep-web5-10 --fixture-root fixtures/cityb/free-service-replay --json
nix run .#cityb -- capture free-wide --json
nix run .#cityb -- capture free-deep-10 --json
nix run .#cityb -- capture free-deep-text-10 --json
nix run .#cityb -- capture free-deep-web-10 --json
nix run .#cityb -- capture free-deep-web2-10 --json
nix run .#cityb -- capture free-deep-web3-10 --json
nix run .#cityb -- capture free-deep-web4-10 --json
nix run .#cityb -- capture free-deep-web5-10 --json
nix run .#cityb -- evidence board --fixture-root fixtures/cityb/free-service-replay --json
nix run .#cityb -- promote check --fixture-root fixtures/cityb/free-service-replay --json
nix run .#cityb -- release archive --plan --json
nix run .#cityb -- release verify DIR_OR_TAR_GZ --json
nix run .#cityb -- deployment compile --file ./city-b.toml --root ./city-b-artifacts --json
nix run .#cityb -- cycle preview --root ./city-b-artifacts --deployment ./city-b.toml --json
nix run .#cityb -- cycle run --root ./city-b-artifacts --deployment ./city-b.toml --json
nix run .#cityb -- collect fixture --root ./city-b-artifacts --deployment ./city-b.toml --fixture captured-provider-fixtures.jsonl --json
nix run .#cityb-node -- field-mode render --profile low-power-field
nix run .#cityb-node -- serve --config CONFIG --state-dir /tmp/cityb-node-state --field-profile low-power-field --clock-confidence offline --now-epoch 1 --cycles 1
nix run .#cityb-biggun -- guide
nix run .#cityb-biggun -- living --max-report-age-hours 24 --json
nix run .#cityb-biggun -- truth --plan --json
nix run .#cityb-biggun -- truth --run --quick --json
nix run .#cityb-biggun -- mutation-corpus --json
nix run .#cityb-biggun -- parser-diff --require --json
nix run .#cityb-biggun -- parser-diff --fixture-root fixtures/cityb/free-service-replay --firehose-fixture-root fixtures/cityb/rendezvous-firehose --require --json
nix run .#cityb-biggun -- provider-reality --service-set free-stable --fixture-root fixtures/cityb/free-service-replay --firehose-fixture-root fixtures/cityb/rendezvous-firehose --archive-evidence-root ./city-b-artifacts/city-b-archive-erasure --required-shards 30 --require --json
nix run .#cityb-biggun -- soak-report --service-set free-stable --fixture-root fixtures/cityb/free-service-replay --firehose-fixture-root fixtures/cityb/rendezvous-firehose --archive-evidence-root ./city-b-artifacts --required-shards 30 --json
nix run .#cityb-biggun -- anchor-amnesia --json
nix run .#cityb-biggun -- footprint --json
nix run .#cityb-biggun -- targets --json
nix run .#cityb-biggun -- targets --check --json
nix run .#cityb-biggun -- gate --plan --json
nix run .#cityb-biggun -- gate --quick --json
nix run .#cityb-biggun -- gate --release --quick --plan --json
nix run .#cityb-biggun -- selftest --plan --json
nix run .#cityb-biggun -- selftest --quick --plan --json
nix run .#cityb-biggun -- selftest --release --quick --plan --json
nix develop -c ./scripts/smoke-cityb-three-binaries.sh
```

The repository is not a tarball of generated artifacts. It is a source tree
containing:

- root build files: `Cargo.toml`, `Cargo.lock`, `flake.nix`, `flake.lock`,
  `rust-toolchain.toml`, `Justfile`, `.gitignore`;
- the Rust crates needed by the three CityB binaries;
- CityB docs and the governance/dead-drop/operator-distribution docs needed to
  resume work;
- CityB smoke, size, target, live-service, and VM trial scripts;
- a README with the first commands an operator should run.

`cityb release archive` builds the three release binaries, copies them into a local `dist/cityb-VERSION-ARCH-OS/` directory, records each binary's own `version --json` and `capabilities --json`, copies the checked-in free-service replay corpus plus rendezvous firehose corpus, copies `README.md`, `LICENSE`, `CONTRIBUTING.md`, `SECURITY.md`, and CityB-only docs, and includes the public `nix/cityb-module.nix` plus its reviewed CityB examples. It deliberately excludes `stil.nix`, `stil-foundation.nix`, their example and private documentation, plus repository-specific Monsternix admission metadata: Stil is m21's resident office, not part of the portable CityB product. The command then writes `SHA3SUMS` and emits a `.tar.gz` plus manifest. `cityb release archive --plan` is side-effect free and reports the paths that would be used; `--signature-policy require-present|require-verified` records the intended detached-signature expectation in the plan/manifest without pretending to sign. `cityb release verify DIR_OR_TAR_GZ` validates an unpacked release directory or archive by preflighting archive member names/types before extraction, checking the SHA3 manifest, refusing suspicious release-tree files, asking each included binary for `version --json` and `capabilities --json`, confirming the policy files, offline fixture corpus, and operator/developer docs are present, reporting detached `SHA3SUMS.sig` presence/verification status, and honoring `--signature-policy require-present` / `--require-signature` when unsigned artifacts must fail. Use `--signature-policy require-verified --signature-verifier ssh --allowed-signers FILE --signer-identity ID` to verify `SHA3SUMS.sig` with OpenSSH over `SHA3SUMS`; `--signature-namespace` defaults to `cityb-release`. A present signature without a verifier remains `present-unverified`. A deployment can make this admission policy repeatable by setting `release_manifest = "./release-verify.json"` and `release_signature_policy = "require-verified"`; it can also restrict accepted signer identities, signature namespaces, versions, architectures, operating systems, archive SHA3-256 digests, and runtime matches with `release_allowed_*` fields plus `release_require_runtime_match`. `cityb field-pack status --deployment FILE` reports the admission decision and uses deployment defaults unless CLI flags override them. `cityb adapter doctor`, `cityb evidence board`, `cityb promote check`, `cityb release archive`, `cityb release verify`, and `cityb-biggun provider-reality` locate `fixtures/cityb/free-service-replay/` and `fixtures/cityb/rendezvous-firehose/` automatically when run from the source tree, an unpacked release, or a subdirectory below either one; explicit `--fixture-root` or `--firehose-fixture-root` selects copied corpora or an out-of-tree drift bench. The legacy `scripts/release-cityb-archive.sh` wrapper remains for old automation only; the Rust binary is the canonical standalone packaging surface. Neither path publishes, uploads, creates service state, reads credentials, or modifies monsternix.

`packaging/monsternix/cityb.experimental-toolset.json` is the compact
machine-readable candidate object for a future monsternix experimental toolset.
It records the public package/module, the three role apps, the exact local
checks to run before admission, and the authority rule that availability
is not activation: copying or including the object starts no service, opens no
listener, creates no state, reads no credential, and does not grant public
posting authority.

The public Nix operations surface is the flake's default
`nixosModules.cityb` module, documented in
[`city-b-nix.md`](city-b-nix.md). It writes `/etc/cityb/runtime.json`, and the
three CityB binaries remain the complete runtime product. The separate
[`stil.nix`](../stil.nix) object is m21's personal office, exported explicitly
as `.#stil`; Stil is not a fourth Rust binary. On m21, its frontend reads
`/etc/stil/runtime.json` and injects that machine's configured paths.
`stil identity` joins frontend, configured service, Biggun, Tiny, and runtime
identity; `stil system status|timers|doctor|logs|run` owns the declared systemd
lifecycle. The package retains internal compatibility wrappers for m21, but
the root flake no longer advertises each wrapper as a public app. Operators use
the native `cityb` and `cityb-biggun` command trees. Tiny remains the separately
addressed `.#cityb-node` app because field receivers should not inherit the
operator automation surface.

The flake exports `nixosModules.default` and `nixosModules.cityb` as the public
NixOS module. Enabling `services.cityb` installs the three-binary package and creates
a dedicated system user plus declared state directories. The provider monitor, local
evidence intake, and scheduled Biggun truth checks are separately opt-in
oneshot services with persistent timers. `services.cityb.monitor.live`
defaults to false, so importing the module or enabling CityB does not post to
public providers. The module carries the configured retained root, monitor
state, and fixture root into every service rather than relying on an ambient
working directory. The monitor records declared vantage and egress labels,
uses a bounded 5.5-hour lifecycle, and compacts retained reports after every
attempt. That lifecycle also records a timestamped allocated-byte measurement;
interactive `monitor status`, `next`, and card views consume the measurement
instead of recursively walking every retained capture. A missing or invalid
measurement falls back to an exact live scan, and the value remains advisory
compaction guidance rather than authority. `monitor status` and `monitor nurse` prefer an installed
`cityb-monitor.timer` (or m21's legacy/personal `stil-monitor.timer`) and report its system scope and unit name, so migration
does not leave the cockpit judging a disabled legacy user timer. Setting
`createUser = false` adopts an existing identity; paths beneath
`/home` additionally require `allowHomeState = true` so that home exposure is
an explicit deployment decision. Adoption mode neither creates nor changes the
mode or ownership of those paths; a missing declared path makes the unit fail
closed. The module refuses simultaneous monitor and evidence-intake writers,
live mode without a monitor, unsafe non-loopback gateway declarations, and
incomplete TLS/firewall combinations at evaluation time. Services run without
Linux capabilities against a read-only system view and gain write access only
to declared CityB state. `stil manual` prints the handbook embedded in the
same source object; [the Stil landing page](stil.md) explains direct handoff.

Public operators use `cityb system status|timers|doctor|logs|run` against
`/etc/cityb/runtime.json`. The surface resolves only Nix-declared role names,
checks loaded executables against the exact configured package, and delegates
authorization to systemd. Stil retains its own equivalent solely for m21's
resident payload and custody workflow; ordinary CityB deployments do not need
it.
The separate copyable [`stil-foundation.nix`](../stil-foundation.nix) object
and `.#stil-foundation` app form the inert Monsternix settlement-input and
recovery-custody joint.
Its NixOS module installs no service or timer; it only publishes the exact
object and compatibility descriptors. Its frontend can inspect Monsternix's
discovery-only Experimental shelf, emit an opaque `recovery-escrow` entry,
compile a strict one-entry settlement catalog and total local observation from
operator-supplied current authority facts, and byte-bind those inputs into a
runnable no-effect settlement-plan command. Its `custody-plan` surface emits a
resumable request/IoTox/admission/materialization script whose operation handle
is durably recorded before provider contact; generating the script performs none
of those effects. `doctor --deep` can also validate the installed `mnx.sync`
no-effect doctor contract. It does not enroll `mnx.sync`,
`mnx.secrets`, IoTox, or a physical route. See
[stil-foundation.md](stil-foundation.md).
See
[`nix/examples/cityb-existing-operator.nix`](../nix/examples/cityb-existing-operator.nix)
for that migration posture and
[`nix/examples/correspondence-gateway-tls.nix`](../nix/examples/correspondence-gateway-tls.nix)
for the long-running gateway posture.

`version --json` is the durable executable identity surface. Each binary
reports source revision, semantic build identity, artifact SHA3-256,
provider-set generation, and release identity in addition to its package
version and role. Monitor comparison uses semantic build identity so wrapper
path/digest differences do not turn the same Nix-built CityB into a false
binary-mismatch alarm.

The repository remains a Cargo workspace because the present Goldilocks and
Biggun surfaces still share the protocol, audit, transport, council, operator,
and lab code. That is acceptable for the current standalone goal: the repo
builds the CityB binaries and carries the documentation needed to operate and
develop them without the older workspace context. The Rust binaries own the
normal standalone rituals: `cityb adapter doctor`, `cityb capture`, `cityb evidence board`, `cityb
promote check`, `cityb release archive`, `cityb release verify`, and `cityb-biggun footprint` are the
canonical surfaces. `cityb-biggun guide` is the Rust-owned amnesia card for maintainers who need the safe Biggun run order. `cityb-biggun living --json` is the Rust-owned read-only monitor-state report; add `--max-report-age-hours HOURS` when automation should classify stale retained monitor loops. `cityb-biggun truth --plan|--run` is the Rust-owned Biggun development cockpit over the local evidence stack. `cityb-biggun targets --check` is the Rust-owned target
gate for native and installed cross-target compile checks. `cityb-biggun
selftest` is the canonical three-binary standalone proof. `cityb-biggun gate`
is the Rust-owned local readiness recipe over formatting, workspace checks,
tests, binary build, selftest, optional target checks, optional docs, and
optional release archive/verify. Shell scripts remain only for sandwurm/VM
orchestration and old automation entry points.

Biggun also carries two standalone evidence drills that are intentionally not operator mutation paths. `cityb-biggun provider-reality` replays the checked-in provider transcript, exact-byte fixture, and public-listing corpus to classify provider drift, recovered-watch providers, discovery-only lanes, firehose promotion readiness, empirical archive-shard threshold dates, live archive-shard eligible providers, exact-byte pointer carriers that remain ineligible for automatic archive spraying, and `archive_spray_readiness` for the latest eligible provider set. `cityb-biggun anchor-amnesia` builds a temporary retained public-anchor corpus, proves Tiny accepts native-proof anchors while rejecting unverified anchors under `--require-native-proof`, emits state-ratcheted and public-bootstrap schedules, builds and OpenSSH-signs a reviewed three-binary release, seals the signature into the distributed archive, reconstructs that release from a local erasure subset, admits it through persisted release trust with `cityb recover`, regenerates the field pack and recovery card, exports a Tiny kit from a retained root whose pointer-chain member is signed into the archive, proves Tiny scans a concrete derived retained-local slot, exercises a stale-field-pack epoch, and proves missing slot roots fall back to anchor recovery instead of silently pretending the plan is usable.

Longer-term cleanup is still useful:

1. Move reusable dead-drop operator machinery behind a clearer CityB module
   boundary so `cityb` stops depending on unrelated unified-CLI surface
   code.
2. Keep `cityb-node` dependency-tiny and receive-only. It is already the
   strongest split and should remain the field binary.
3. Keep `cityb-biggun` as a separate lab/measurement package. Do not let
   Monte Carlo, adversarial exercise, or large fixture dependencies bleed into
   Goldilocks or Tiny.
4. Continue the structural split where it reduces review risk. The surface
   router, profile compiler, format compiler, guard layer, service catalog, and
   low-level helpers are already separated; deployment validation, collection,
   cycle state, repair, review, adapter catalog, adapter execution, fragment
   handling, dead-drop receive, distribution planning, substrate
   registry/scoring/provenance, receipt/negative/archive reports, noise/OCR
   corpora, recovery capsule export/inspect, foothold selection, handoff/kit
   verification, retained exercise flow, adapter templates, live adapter
   profile data, live HTTP helpers, live publisher payload normalization, live
   publisher packet rendering, live publisher probe/failure evidence, live
   publisher implementations, adapter operational metadata, deterministic
   rendezvous schedules/envelopes, Tiny durable-anchor intake, command arity,
   and Biggun publication-gate orchestration now have their own modules. The
   remaining large files are predominantly provider registries, long-lived
   state machines, or scenario catalogs. Split those by stable provider family
   or state-machine ownership when it lowers review risk; do not manufacture
   layers whose only purpose is reducing a line count.

The standalone proof is `cityb-biggun selftest`: it composes the three binaries, captures local evidence, writes `city-b-standalone-selftest.json`, and performs no public-service mutation. A Goldilocks `check` or `next` command that returns the typed `action-required` readiness state has completed successfully as an observation; the selftest retains that state instead of treating its nonzero readiness exit as a subprocess crash. Use `--quick` for the shortest no-degradation proof, default/`--full` for the full negative-lane proof, and `--release` when the exact binaries under `target/release` should be checked instead of PATH/debug selections. `cityb-biggun gate --quick` is the normal local confidence pass; run it from the dev shell, for example `nix develop -c cargo run -q --bin cityb-biggun -- gate --quick --json`, because the gate invokes `cargo`, `rustfmt`, and `git`. Add `--release` when release archives must be built and verified from the same Rust-owned path. The `scripts/smoke-cityb-three-binaries.sh` wrapper builds debug binaries before invoking the selftest command for old automation. If the exported tree cannot pass the Rust proof, it is not a real CityB standalone candidate.

The live no-account service path is not part of the default standalone proof because it mutates public services. `cityb capture free-wide`, `cityb capture free-deep-10`, `cityb capture free-deep-text-10`, `cityb capture free-deep-web-10`, `cityb capture free-deep-web2-10`, `cityb capture free-deep-web3-10`, `cityb capture free-deep-web4-10`, and `cityb capture free-deep-web5-10` print the exact live command and perform no remote mutation unless `--live` is explicit. With `--live`, they run the Rust-owned capture/conversion workflow and write replay fixtures; the legacy `scripts/live-free-service-smoke.sh` wrapper exists for old automation only. By default the wide path uses a quorum rather than every selected free service because public no-account hosts can expire, reject, or degrade independently; `--require-all` restores all-adapter strictness for focused provider diagnosis. The deep-ten paths are provider-evidence benches and normally should use `--require-all`.
