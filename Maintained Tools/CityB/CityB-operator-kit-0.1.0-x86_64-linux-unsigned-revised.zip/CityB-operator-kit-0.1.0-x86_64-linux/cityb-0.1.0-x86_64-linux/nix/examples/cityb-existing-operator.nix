{ cityb, ... }:
{
  imports = [ cityb.nixosModules.default ];

  # Adopt an existing retained root and monitor lineage without copying or
  # resetting them. The operator account and paths must already exist.
  services.cityb = {
    enable = true;
    createUser = false;
    user = "operator";
    group = "users";
    allowHomeState = true;
    operatorControl = {
      enable = true;
      user = "operator";
    };

    root = "/home/operator/cityb/city-b-artifacts";
    deployment = "/home/operator/cityb/city-b.toml";
    stateDir = "/home/operator/.local/state/cityb/provider-monitor";
    fixtureRoot = "/home/operator/cityb/fixtures/cityb/free-service-replay";

    monitor = {
      enable = true;
      live = true;
      preset = "all-free-rotation";
      vantageId = "operator-host";
      egressLabel = "operator-egress";
      onCalendar = "*-*-* 02/6:17:00";
    };

    truthChecks = {
      enable = true;
      quick = true;
      onCalendar = "Sun *-*-* 05:17:00";
    };
  };

  # After activation:
  #   cityb next --require-ready
  #   cityb check
  #   cityb monitor nurse --brief
  # /etc/cityb/runtime.json supplies these retained paths.
}
