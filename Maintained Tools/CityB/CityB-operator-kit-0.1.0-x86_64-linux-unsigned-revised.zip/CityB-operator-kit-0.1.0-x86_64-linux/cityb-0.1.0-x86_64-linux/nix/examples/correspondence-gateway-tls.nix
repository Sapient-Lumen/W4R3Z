{ cityb, ... }:
{
  imports = [ cityb.nixosModules.default ];

  services.cityb = {
    enable = true;
    correspondenceGateway = {
      enable = true;
      address = "127.0.0.1";
      port = 8787;
      nodeRequestsPerMinute = 120;
      nodeBytesPerMinute = 67108864;
      # Opt-in real ChatGPT/operator authority. The endpoint still accepts only
      # active operator signatures and the selected fixed CityB vocabulary.
      remoteOperator = {
        enable = true;
        policy = "correspond";
        requestsPerMinute = 60;
        bytesPerMinute = 4194304;
      };
      tls = {
        enable = true;
        hostName = "correspondence.example.org";
        certificate = "/run/credentials/cityb-gateway/fullchain.pem";
        certificateKey = "/run/credentials/cityb-gateway/key.pem";
        port = 443;
        # Keep false when another firewall or private overlay owns ingress.
        openFirewall = false;
      };
    };
  };
}
