{
  defaultPackage ? null,
  sourceRevision ? "unavailable",
  releaseIdentity ? "unavailable",
}:
{
  config,
  lib,
  pkgs,
  ...
}:

let
  cfg = config.services.cityb;
  inherit (lib)
    mkEnableOption
    mkIf
    mkOption
    types
    ;

  package = cfg.package;
  cityb = "${package}/bin/cityb";
  biggun = "${package}/bin/cityb-biggun";
  node = "${package}/bin/cityb-node";

  monitorArgs = [
    "monitor"
    "run"
    "--state-dir"
    cfg.stateDir
    "--repo-fixture-root"
    cfg.fixtureRoot
    "--archive-root"
    cfg.root
    "--preset"
    cfg.monitor.preset
    "--http-transport"
    cfg.monitor.httpTransport
    "--vantage-id"
    cfg.monitor.vantageId
    "--egress-label"
    cfg.monitor.egressLabel
    "--json"
  ]
  ++ lib.optional cfg.monitor.live "--live";

  compactArgs = [
    "monitor"
    "compact"
    "--state-dir"
    cfg.stateDir
    "--keep-reports"
    (toString cfg.monitor.keepReports)
    "--keep-captures"
    (toString cfg.monitor.keepCaptures)
    "--apply"
    "--json"
  ];

  evidenceArgs = [
    "evidence"
    "sync"
    "--state-dir"
    cfg.stateDir
    "--repo-fixture-root"
    cfg.fixtureRoot
    "--root"
    cfg.root
    "--apply"
    "--json"
  ];

  truthArgs = [
    "truth"
    "--run"
    "--state-dir"
    cfg.stateDir
    "--repo-fixture-root"
    cfg.fixtureRoot
    "--root"
    cfg.root
    "--fixture-root"
    cfg.fixtureRoot
    "--work-dir"
    "${cfg.root}/city-b-biggun-truth"
    "--json"
  ]
  ++ lib.optional cfg.truthChecks.quick "--quick";

  correspondenceArgs = [
    "correspondence"
    "gateway"
    "serve"
    "--root"
    "${cfg.root}/city-b-correspondence"
    "--bind"
    "${cfg.correspondenceGateway.address}:${toString cfg.correspondenceGateway.port}"
    "--node-requests-per-minute"
    (toString cfg.correspondenceGateway.nodeRequestsPerMinute)
    "--node-bytes-per-minute"
    (toString cfg.correspondenceGateway.nodeBytesPerMinute)
  ]
  ++ lib.optional cfg.correspondenceGateway.allowNonLoopback "--allow-nonloopback"
  ++ lib.optionals cfg.correspondenceGateway.remoteOperator.enable [
    "--allow-remote-operator"
    "--remote-operator-policy"
    cfg.correspondenceGateway.remoteOperator.policy
    "--operator-requests-per-minute"
    (toString cfg.correspondenceGateway.remoteOperator.requestsPerMinute)
    "--operator-bytes-per-minute"
    (toString cfg.correspondenceGateway.remoteOperator.bytesPerMinute)
  ];

  relaySoakArgs = [
    "correspondence"
    "relay"
    "soak"
    "--root"
    "${cfg.root}/city-b-correspondence"
    "--plan"
    cfg.correspondenceRelaySoak.plan
    "--apply"
    "--json"
  ];

  nodeCapsuleArgs = [
    "correspondence"
    "schedule"
    "--provision"
    cfg.correspondenceNodeCapsule.provision
    "--up"
    cfg.correspondenceNodeCapsule.upDir
    "--state-dir"
    cfg.correspondenceNodeCapsule.stateDir
    "--kind"
    cfg.correspondenceNodeCapsule.kind
    "--body"
    cfg.correspondenceNodeCapsule.label
    "--interval-secs"
    (toString cfg.correspondenceNodeCapsule.intervalSeconds)
    "--jitter-secs"
    (toString cfg.correspondenceNodeCapsule.jitterSeconds)
    "--max-requests-per-day"
    (toString cfg.correspondenceNodeCapsule.maxRequestsPerDay)
    "--max-bytes-per-day"
    (toString cfg.correspondenceNodeCapsule.maxBytesPerDay)
    "--max-storage-bytes"
    (toString cfg.correspondenceNodeCapsule.maxStorageBytes)
    "--min-battery-percent"
    (toString cfg.correspondenceNodeCapsule.minBatteryPercent)
    "--json"
  ]
  ++ lib.optionals (cfg.correspondenceNodeCapsule.batteryCapacityFile != null) [
    "--battery-capacity-file"
    cfg.correspondenceNodeCapsule.batteryCapacityFile
  ]
  ++ lib.optionals (cfg.correspondenceNodeCapsule.batteryPercent != null) [
    "--battery-percent"
    (toString cfg.correspondenceNodeCapsule.batteryPercent)
  ];

  deploymentGuard = lib.optionalAttrs (cfg.deployment != null) {
    ExecStartPre = "${cityb} deployment validate --file ${lib.escapeShellArg cfg.deployment} --json";
  };
  deploymentMount = lib.optional (cfg.deployment != null) cfg.deployment;

  enabledServiceUnits =
    lib.optional cfg.monitor.enable "cityb-monitor.service"
    ++ lib.optional cfg.evidenceIntake.enable "cityb-evidence-intake.service"
    ++ lib.optional cfg.truthChecks.enable "cityb-truth-check.service"
    ++ lib.optional cfg.correspondenceGateway.enable "cityb-correspondence-gateway.service"
    ++ lib.optional cfg.correspondenceRelaySoak.enable "cityb-correspondence-relay-soak.service"
    ++ lib.optional cfg.correspondenceNodeCapsule.enable "cityb-correspondence-node-capsule.service";
  enabledTimerUnits =
    lib.optional cfg.monitor.enable "cityb-monitor.timer"
    ++ lib.optional cfg.evidenceIntake.enable "cityb-evidence-intake.timer"
    ++ lib.optional cfg.truthChecks.enable "cityb-truth-check.timer"
    ++ lib.optional cfg.correspondenceRelaySoak.enable "cityb-correspondence-relay-soak.timer"
    ++ lib.optional cfg.correspondenceNodeCapsule.enable "cityb-correspondence-node-capsule.timer";

  declaredRuntimePaths = [
    cfg.root
    cfg.stateDir
    cfg.fixtureRoot
  ]
  ++ lib.optional (cfg.deployment != null) cfg.deployment
  ++ lib.optional cfg.correspondenceRelaySoak.enable cfg.correspondenceRelaySoak.plan
  ++ lib.optionals cfg.correspondenceNodeCapsule.enable [
    cfg.correspondenceNodeCapsule.provision
    cfg.correspondenceNodeCapsule.stateDir
    cfg.correspondenceNodeCapsule.upDir
  ]
  ++ lib.optional (
    cfg.correspondenceNodeCapsule.enable && cfg.correspondenceNodeCapsule.batteryCapacityFile != null
  ) cfg.correspondenceNodeCapsule.batteryCapacityFile;

  runtimeRoles =
    lib.optionalAttrs cfg.monitor.enable {
      monitor = {
        service = "cityb-monitor.service";
        timer = "cityb-monitor.timer";
        executable = cityb;
        kind = "oneshot";
      };
    }
    // lib.optionalAttrs cfg.evidenceIntake.enable {
      evidence = {
        service = "cityb-evidence-intake.service";
        timer = "cityb-evidence-intake.timer";
        executable = cityb;
        kind = "oneshot";
      };
    }
    // lib.optionalAttrs cfg.truthChecks.enable {
      truth = {
        service = "cityb-truth-check.service";
        timer = "cityb-truth-check.timer";
        executable = biggun;
        kind = "oneshot";
      };
    }
    // lib.optionalAttrs cfg.correspondenceGateway.enable {
      gateway = {
        service = "cityb-correspondence-gateway.service";
        timer = null;
        executable = cityb;
        kind = "continuous";
      };
    }
    // lib.optionalAttrs cfg.correspondenceRelaySoak.enable {
      relay = {
        service = "cityb-correspondence-relay-soak.service";
        timer = "cityb-correspondence-relay-soak.timer";
        executable = cityb;
        kind = "oneshot";
      };
    }
    // lib.optionalAttrs cfg.correspondenceNodeCapsule.enable {
      capsule = {
        service = "cityb-correspondence-node-capsule.service";
        timer = "cityb-correspondence-node-capsule.timer";
        executable = node;
        kind = "oneshot";
      };
    };

  runtimeDescriptor = {
    schema = "cityb.nix-runtime.v1";
    package = toString package;
    identity = {
      source_revision = cfg.sourceRevision;
      release_identity = cfg.releaseIdentity;
      provider_set_generation_source = "cityb version --json";
    };
    operator = {
      inherit (cfg)
        user
        group
        createUser
        allowRoot
        ;
      unit_control_enabled = cfg.operatorControl.enable;
      unit_control_user = cfg.operatorControl.user;
    };
    paths = {
      root = cfg.root;
      state_dir = cfg.stateDir;
      fixture_root = cfg.fixtureRoot;
      # The interactive cockpit can create this default on first `cityb up`.
      # Services validate a deployment only when the operator explicitly binds
      # one through cfg.deployment.
      deployment = if cfg.deployment != null then cfg.deployment else "${cfg.root}/city-b.toml";
    };
    monitor = {
      inherit (cfg.monitor)
        enable
        live
        preset
        httpTransport
        vantageId
        egressLabel
        onCalendar
        staleAfterSeconds
        keepReports
        keepCaptures
        ;
    };
    correspondence = {
      gateway_enabled = cfg.correspondenceGateway.enable;
      gateway_bind = "${cfg.correspondenceGateway.address}:${toString cfg.correspondenceGateway.port}";
      tls_enabled = cfg.correspondenceGateway.tls.enable;
      remote_operator_enabled = cfg.correspondenceGateway.remoteOperator.enable;
      remote_operator_policy = cfg.correspondenceGateway.remoteOperator.policy;
      relay_soak_enabled = cfg.correspondenceRelaySoak.enable;
      node_capsule_enabled = cfg.correspondenceNodeCapsule.enable;
    };
    systemd = {
      services = enabledServiceUnits;
      timers = enabledTimerUnits;
      continuous_services = lib.optional cfg.correspondenceGateway.enable "cityb-correspondence-gateway.service";
      roles = runtimeRoles;
    };
  };

  serviceBase = {
    User = cfg.user;
    Group = cfg.group;
    UMask = "0027";
    CapabilityBoundingSet = "";
    AmbientCapabilities = "";
    LockPersonality = true;
    PrivateDevices = true;
    NoNewPrivileges = true;
    PrivateTmp = true;
    ProtectClock = true;
    ProtectControlGroups = true;
    ProtectHostname = true;
    ProtectKernelLogs = true;
    ProtectKernelModules = true;
    ProtectKernelTunables = true;
    ProtectProc = "invisible";
    ProcSubset = "pid";
    RemoveIPC = true;
    RestrictAddressFamilies = [
      "AF_UNIX"
      "AF_INET"
      "AF_INET6"
    ];
    RestrictRealtime = true;
    RestrictSUIDSGID = true;
    SystemCallArchitectures = "native";
    ProtectSystem = "strict";
    ProtectHome = if cfg.allowHomeState then "read-only" else true;
  }
  // deploymentGuard;

  retainedMonitorResult = pkgs.writeShellScript "cityb-monitor-retained-result-check" ''
    set -eu
    report=${lib.escapeShellArg "${cfg.stateDir}/reports/latest.json"}
    now=$(${pkgs.coreutils}/bin/date +%s)
    floor=$((now - 900))
    ${pkgs.jq}/bin/jq -e --argjson floor "$floor" '
      .run_completed == true and
      (.completed_epoch | type == "number") and
      .completed_epoch >= $floor
    ' "$report" >/dev/null
  '';
in
{
  options.services.cityb = {
    enable = mkEnableOption "CityB's three-binary operator, field-node, and truth system";
    package = mkOption (
      {
        type = types.package;
        description = "Package containing cityb, cityb-biggun, and cityb-node.";
      }
      // lib.optionalAttrs (defaultPackage != null) { default = defaultPackage; }
    );
    sourceRevision = mkOption {
      type = types.str;
      default = sourceRevision;
      description = "Reviewed CityB source revision written to the runtime descriptor.";
    };
    releaseIdentity = mkOption {
      type = types.str;
      default = releaseIdentity;
      description = "Reviewed CityB release identity written to the runtime descriptor.";
    };
    user = mkOption {
      type = types.str;
      default = "cityb";
    };
    group = mkOption {
      type = types.str;
      default = "cityb";
    };
    createUser = mkOption {
      type = types.bool;
      default = true;
      description = "Create a dedicated unprivileged CityB user and group.";
    };
    allowRoot = mkOption {
      type = types.bool;
      default = false;
      description = "Explicitly permit CityB jobs to run as root.";
    };
    allowHomeState = mkOption {
      type = types.bool;
      default = false;
      description = "Permit declared CityB state beneath /home while keeping the rest of home read-only.";
    };
    operatorControl = {
      enable = mkOption {
        type = types.bool;
        default = false;
        description = "Allow one named human operator to control only enabled CityB service units.";
      };
      user = mkOption {
        type = types.nullOr types.str;
        default = null;
        description = "Human account granted bounded CityB unit control when operatorControl.enable is true.";
      };
    };
    root = mkOption {
      type = types.str;
      default = "/var/lib/cityb/root";
    };
    deployment = mkOption {
      type = types.nullOr types.str;
      default = null;
      description = "Optional deployment manifest validated before every enabled job.";
    };
    stateDir = mkOption {
      type = types.str;
      default = "/var/lib/cityb/monitor";
    };
    fixtureRoot = mkOption {
      type = types.str;
      default = "/var/lib/cityb/evidence";
    };
    monitor = {
      enable = mkEnableOption "scheduled CityB provider monitoring";
      live = mkOption {
        type = types.bool;
        default = false;
        description = "Permit public-provider mutation during monitor runs.";
      };
      preset = mkOption {
        type = types.enum [
          "stable-only"
          "all-free-rotation"
          "all-free-once"
        ];
        default = "all-free-rotation";
      };
      httpTransport = mkOption {
        type = types.enum [
          "curl"
          "firefox"
          "chrome"
        ];
        default = "curl";
      };
      vantageId = mkOption {
        type = types.str;
        default = "local";
      };
      egressLabel = mkOption {
        type = types.str;
        default = "unclassified";
      };
      onCalendar = mkOption {
        type = types.str;
        default = "*-*-* 02/6:17:00";
      };
      staleAfterSeconds = mkOption {
        type = types.ints.positive;
        default = 43200;
      };
      keepReports = mkOption {
        type = types.ints.positive;
        default = 96;
      };
      keepCaptures = mkOption {
        type = types.ints.positive;
        default = 24;
      };
    };
    evidenceIntake = {
      enable = mkEnableOption "scheduled local monitor-evidence intake";
      onCalendar = mkOption {
        type = types.str;
        default = "*-*-* 04:17:00";
      };
    };
    truthChecks = {
      enable = mkEnableOption "scheduled Biggun truth checks";
      quick = mkOption {
        type = types.bool;
        default = true;
      };
      onCalendar = mkOption {
        type = types.str;
        default = "Sun *-*-* 05:17:00";
      };
    };
    correspondenceGateway = {
      enable = mkEnableOption "the operator-owned correspondence HTTP spool gateway";
      address = mkOption {
        type = types.str;
        default = "127.0.0.1";
      };
      port = mkOption {
        type = types.port;
        default = 8787;
      };
      allowNonLoopback = mkOption {
        type = types.bool;
        default = false;
      };
      nodeRequestsPerMinute = mkOption {
        type = types.ints.positive;
        default = 120;
      };
      nodeBytesPerMinute = mkOption {
        type = types.ints.positive;
        default = 67108864;
      };
      remoteOperator = {
        enable = mkEnableOption "the signed external operator endpoint";
        policy = mkOption {
          type = types.enum [
            "read"
            "correspond"
            "operate"
          ];
          default = "correspond";
        };
        requestsPerMinute = mkOption {
          type = types.ints.positive;
          default = 60;
        };
        bytesPerMinute = mkOption {
          type = types.ints.positive;
          default = 4194304;
        };
      };
      tls = {
        enable = mkEnableOption "an nginx TLS reverse proxy for the loopback correspondence gateway";
        hostName = mkOption {
          type = types.str;
          default = "correspondence.invalid";
        };
        certificate = mkOption {
          type = types.nullOr types.str;
          default = null;
        };
        certificateKey = mkOption {
          type = types.nullOr types.str;
          default = null;
        };
        port = mkOption {
          type = types.port;
          default = 443;
        };
        openFirewall = mkOption {
          type = types.bool;
          default = false;
        };
      };
    };
    correspondenceRelaySoak = {
      enable = mkEnableOption "scheduled multi-family correspondence relay soaking";
      plan = mkOption {
        type = types.str;
        default = "/etc/cityb/correspondence-relay-soak.json";
      };
      onCalendar = mkOption {
        type = types.str;
        default = "*-*-* 06:23:00";
      };
    };
    correspondenceNodeCapsule = {
      enable = mkEnableOption "scheduled, jittered Tiny status or fault capsules";
      provision = mkOption {
        type = types.str;
        default = "/etc/cityb/correspondence-provision.cbor";
      };
      stateDir = mkOption {
        type = types.str;
        default = "/var/lib/cityb/node-correspondence";
      };
      upDir = mkOption {
        type = types.str;
        default = "/var/lib/cityb/node-correspondence/up";
      };
      kind = mkOption {
        type = types.enum [
          "status"
          "fault"
        ];
        default = "status";
      };
      label = mkOption {
        type = types.str;
        default = "scheduled field capsule";
      };
      intervalSeconds = mkOption {
        type = types.ints.positive;
        default = 21600;
      };
      jitterSeconds = mkOption {
        type = types.ints.unsigned;
        default = 1800;
      };
      pollSeconds = mkOption {
        type = types.ints.positive;
        default = 300;
      };
      maxRequestsPerDay = mkOption {
        type = types.ints.positive;
        default = 8;
      };
      maxBytesPerDay = mkOption {
        type = types.ints.positive;
        default = 1048576;
      };
      maxStorageBytes = mkOption {
        type = types.ints.positive;
        default = 67108864;
      };
      minBatteryPercent = mkOption {
        type = types.ints.between 0 100;
        default = 20;
      };
      batteryCapacityFile = mkOption {
        type = types.nullOr types.str;
        default = null;
      };
      batteryPercent = mkOption {
        type = types.nullOr (types.ints.between 0 100);
        default = null;
      };
    };
  };

  config = mkIf cfg.enable {
    assertions = [
      {
        assertion = cfg.user != "root" || cfg.allowRoot;
        message = "Running CityB jobs as root requires services.cityb.allowRoot = true.";
      }
      {
        assertion = !cfg.operatorControl.enable || cfg.operatorControl.user != null;
        message = "services.cityb.operatorControl.enable requires a named operatorControl.user.";
      }
      {
        assertion = lib.all (path: lib.hasPrefix "/" (toString path)) declaredRuntimePaths;
        message = "Every CityB runtime, deployment, plan, provision, and battery path must be absolute.";
      }
      {
        assertion =
          cfg.allowHomeState
          || !(lib.any (path: lib.hasPrefix "/home/" (toString path)) declaredRuntimePaths);
        message = "CityB paths beneath /home require services.cityb.allowHomeState = true.";
      }
      {
        assertion = cfg.monitor.enable || !cfg.monitor.live;
        message = "services.cityb.monitor.live requires services.cityb.monitor.enable.";
      }
      {
        assertion = !(cfg.monitor.enable && cfg.evidenceIntake.enable);
        message = "Enable either CityB monitor or evidenceIntake, not both, so one lineage has one writer.";
      }
      {
        assertion =
          cfg.correspondenceGateway.address == "127.0.0.1" || cfg.correspondenceGateway.allowNonLoopback;
        message = "A non-loopback CityB correspondence gateway requires allowNonLoopback = true.";
      }
      {
        assertion = !cfg.correspondenceGateway.tls.enable || cfg.correspondenceGateway.enable;
        message = "CityB correspondence TLS requires correspondenceGateway.enable.";
      }
      {
        assertion = !cfg.correspondenceGateway.remoteOperator.enable || cfg.correspondenceGateway.enable;
        message = "CityB remote operator access requires correspondenceGateway.enable.";
      }
      {
        assertion =
          !cfg.correspondenceGateway.remoteOperator.enable || cfg.correspondenceGateway.tls.enable;
        message = "CityB remote operator access requires the configured TLS reverse proxy.";
      }
      {
        assertion = !cfg.correspondenceGateway.tls.openFirewall || cfg.correspondenceGateway.tls.enable;
        message = "CityB correspondence tls.openFirewall requires TLS enablement.";
      }
      {
        assertion =
          !cfg.correspondenceGateway.tls.enable
          || cfg.correspondenceGateway.tls.port != cfg.correspondenceGateway.port;
        message = "CityB correspondence nginx TLS and loopback gateway must use different ports.";
      }
      {
        assertion =
          !cfg.correspondenceGateway.tls.enable || cfg.correspondenceGateway.address == "127.0.0.1";
        message = "CityB correspondence TLS expects a loopback gateway behind nginx.";
      }
      {
        assertion =
          !cfg.correspondenceGateway.tls.enable
          || (
            cfg.correspondenceGateway.tls.certificate != null
            && cfg.correspondenceGateway.tls.certificateKey != null
          );
        message = "CityB correspondence TLS requires certificate and certificateKey.";
      }
      {
        assertion =
          !cfg.correspondenceNodeCapsule.enable
          || (
            (cfg.correspondenceNodeCapsule.batteryCapacityFile != null)
            != (cfg.correspondenceNodeCapsule.batteryPercent != null)
          );
        message = "CityB scheduled node capsules require exactly one battery source.";
      }
    ];

    environment.systemPackages = [ package ];
    environment.sessionVariables.CITYB_RUNTIME_CONFIG = "/etc/cityb/runtime.json";
    environment.etc."cityb/runtime.json" = {
      text = builtins.toJSON runtimeDescriptor;
      mode = "0444";
    };

    users.groups = mkIf cfg.createUser { ${cfg.group} = { }; };
    users.users = mkIf cfg.createUser {
      ${cfg.user} = {
        isSystemUser = true;
        group = cfg.group;
        home = "/var/lib/cityb";
        createHome = true;
      };
    };

    systemd.tmpfiles.rules = lib.optionals cfg.createUser (
      [
        "d ${cfg.root} 0750 ${cfg.user} ${cfg.group} -"
        "d ${cfg.stateDir} 0750 ${cfg.user} ${cfg.group} -"
        "d ${cfg.fixtureRoot} 0750 ${cfg.user} ${cfg.group} -"
      ]
      ++ lib.optionals cfg.correspondenceNodeCapsule.enable [
        "d ${cfg.correspondenceNodeCapsule.stateDir} 0750 ${cfg.user} ${cfg.group} -"
        "d ${cfg.correspondenceNodeCapsule.upDir} 0750 ${cfg.user} ${cfg.group} -"
      ]
    );

    security.polkit.enable = mkIf (cfg.operatorControl.enable && enabledServiceUnits != [ ]) true;
    security.polkit.extraConfig = mkIf (cfg.operatorControl.enable && enabledServiceUnits != [ ]) ''
      polkit.addRule(function(action, subject) {
        var units = ${builtins.toJSON enabledServiceUnits};
        var verbs = ["start", "stop", "restart"];
        if (action.id === "org.freedesktop.systemd1.manage-units" &&
            subject.user === ${builtins.toJSON cfg.operatorControl.user} &&
            units.indexOf(action.lookup("unit")) !== -1 &&
            verbs.indexOf(action.lookup("verb")) !== -1) {
          return polkit.Result.YES;
        }
      });
    '';

    systemd.services.cityb-monitor = mkIf cfg.monitor.enable {
      description = "CityB bounded provider monitor";
      after = [ "network-online.target" ];
      wants = [ "network-online.target" ];
      unitConfig.RequiresMountsFor = [
        cfg.root
        cfg.stateDir
        cfg.fixtureRoot
      ]
      ++ deploymentMount;
      serviceConfig = serviceBase // {
        Type = "oneshot";
        ReadWritePaths = [
          cfg.root
          cfg.stateDir
          cfg.fixtureRoot
        ];
        Environment = "CITYB_HTTP_TRANSPORT=${cfg.monitor.httpTransport}";
        ExecStart = "${cityb} ${lib.escapeShellArgs monitorArgs}";
        ExecStartPost = retainedMonitorResult;
        ExecStopPost = "-${cityb} ${lib.escapeShellArgs compactArgs}";
        SuccessExitStatus = [ 1 ];
        Nice = 10;
        IOSchedulingClass = "idle";
        TimeoutStartSec = "5h30m";
        TimeoutStopSec = "10m";
        KillMode = "control-group";
        StandardOutput = "null";
        StandardError = "journal";
      };
    };
    systemd.timers.cityb-monitor = mkIf cfg.monitor.enable {
      wantedBy = [ "timers.target" ];
      timerConfig = {
        OnCalendar = cfg.monitor.onCalendar;
        Persistent = true;
        RandomizedDelaySec = "15m";
      };
    };

    systemd.services.cityb-evidence-intake = mkIf cfg.evidenceIntake.enable {
      description = "CityB local evidence intake";
      unitConfig.RequiresMountsFor = [
        cfg.root
        cfg.stateDir
        cfg.fixtureRoot
      ]
      ++ deploymentMount;
      serviceConfig = serviceBase // {
        Type = "oneshot";
        ReadWritePaths = [
          cfg.root
          cfg.stateDir
          cfg.fixtureRoot
        ];
        ExecStart = "${cityb} ${lib.escapeShellArgs evidenceArgs}";
      };
    };
    systemd.timers.cityb-evidence-intake = mkIf cfg.evidenceIntake.enable {
      wantedBy = [ "timers.target" ];
      timerConfig = {
        OnCalendar = cfg.evidenceIntake.onCalendar;
        Persistent = true;
        RandomizedDelaySec = "15m";
      };
    };

    systemd.services.cityb-truth-check = mkIf cfg.truthChecks.enable {
      description = "CityB Biggun truth check";
      unitConfig.RequiresMountsFor = [
        cfg.root
        cfg.stateDir
        cfg.fixtureRoot
      ]
      ++ deploymentMount;
      serviceConfig = serviceBase // {
        Type = "oneshot";
        ReadWritePaths = [ cfg.root ];
        WorkingDirectory = cfg.root;
        ExecStart = "${biggun} ${lib.escapeShellArgs truthArgs}";
      };
    };
    systemd.timers.cityb-truth-check = mkIf cfg.truthChecks.enable {
      wantedBy = [ "timers.target" ];
      timerConfig = {
        OnCalendar = cfg.truthChecks.onCalendar;
        Persistent = true;
        RandomizedDelaySec = "30m";
      };
    };

    systemd.services.cityb-correspondence-gateway = mkIf cfg.correspondenceGateway.enable {
      description = "CityB operator-owned correspondence spool gateway";
      wantedBy = [ "multi-user.target" ];
      after = [ "network.target" ];
      unitConfig.RequiresMountsFor = [ cfg.root ] ++ deploymentMount;
      serviceConfig = serviceBase // {
        Type = "simple";
        ReadWritePaths = [ cfg.root ];
        Restart = "on-failure";
        RestartSec = "5s";
        ExecStart = "${cityb} ${lib.escapeShellArgs correspondenceArgs}";
      };
    };

    systemd.services.cityb-correspondence-relay-soak = mkIf cfg.correspondenceRelaySoak.enable {
      description = "CityB multi-family correspondence relay soak";
      unitConfig.RequiresMountsFor = [
        cfg.root
        cfg.correspondenceRelaySoak.plan
      ]
      ++ deploymentMount;
      serviceConfig = serviceBase // {
        Type = "oneshot";
        ReadWritePaths = [ cfg.root ];
        ExecStart = "${cityb} ${lib.escapeShellArgs relaySoakArgs}";
      };
    };
    systemd.timers.cityb-correspondence-relay-soak = mkIf cfg.correspondenceRelaySoak.enable {
      wantedBy = [ "timers.target" ];
      timerConfig = {
        OnCalendar = cfg.correspondenceRelaySoak.onCalendar;
        Persistent = true;
        RandomizedDelaySec = "45m";
      };
    };

    systemd.services.cityb-correspondence-node-capsule = mkIf cfg.correspondenceNodeCapsule.enable {
      description = "CityB bounded scheduled field-node capsule";
      unitConfig.RequiresMountsFor = [
        cfg.correspondenceNodeCapsule.stateDir
        cfg.correspondenceNodeCapsule.upDir
        cfg.correspondenceNodeCapsule.provision
      ]
      ++ deploymentMount;
      serviceConfig = serviceBase // {
        Type = "oneshot";
        ReadWritePaths = [
          cfg.correspondenceNodeCapsule.stateDir
          cfg.correspondenceNodeCapsule.upDir
        ];
        ExecStart = "${node} ${lib.escapeShellArgs nodeCapsuleArgs}";
      };
    };
    systemd.timers.cityb-correspondence-node-capsule = mkIf cfg.correspondenceNodeCapsule.enable {
      wantedBy = [ "timers.target" ];
      timerConfig = {
        OnBootSec = "5m";
        OnUnitActiveSec = "${toString cfg.correspondenceNodeCapsule.pollSeconds}s";
        Persistent = true;
        RandomizedDelaySec = "60s";
      };
    };

    services.nginx = mkIf cfg.correspondenceGateway.tls.enable {
      enable = true;
      recommendedProxySettings = true;
      recommendedTlsSettings = true;
      virtualHosts.${cfg.correspondenceGateway.tls.hostName} = {
        onlySSL = true;
        sslCertificate = cfg.correspondenceGateway.tls.certificate;
        sslCertificateKey = cfg.correspondenceGateway.tls.certificateKey;
        listen = [
          {
            addr = "0.0.0.0";
            port = cfg.correspondenceGateway.tls.port;
            ssl = true;
          }
        ];
        locations."/" = {
          proxyPass = "http://${cfg.correspondenceGateway.address}:${toString cfg.correspondenceGateway.port}";
          extraConfig = ''
            proxy_request_buffering on;
            client_max_body_size 1m;
            proxy_read_timeout 30s;
            proxy_send_timeout 30s;
          '';
        };
      };
    };
    networking.firewall.allowedTCPPorts = lib.optional (
      cfg.correspondenceGateway.tls.enable && cfg.correspondenceGateway.tls.openFirewall
    ) cfg.correspondenceGateway.tls.port;
  };
}
