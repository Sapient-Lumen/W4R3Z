CityB 0.1.0 local release archive

Contents:
bin/cityb-node      dependency-tiny receive-only node
bin/cityb           Goldilocks operator workbench
bin/cityb-biggun    heavy exercise and replay tool
versions/*.json     each binary's own version --json output
capabilities/*.json each binary's own capabilities --json output
RELEASE-ID.json     release identity tying binaries, docs, fixtures, and signing payload
CONTRIBUTING.md     source and evidence contribution gates
LICENSE             MIT terms for the distributed product
SECURITY.md         supported line, reporting path, and claim boundaries
README.md           source-tree quickstart and operating summary
docs/               CityB roadmap, operator workflow, distribution, adapter, and release notes
nix/cityb-module.nix public NixOS module for the CityB product
nix/examples/       reviewed CityB deployment examples
fixtures/cityb/free-service-replay/
offline public-service replay evidence for adapter doctor/evidence/promote
fixtures/cityb/rendezvous-firehose/
offline public-listing parser evidence for rendezvous firehose checks
SHA3SUMS            SHA3-256 digest manifest for archive contents; canonical signing payload
SHA3SUMS.sig        optional detached signature created by the operator after packaging

First checks after unpacking:
./bin/cityb release verify . --json
./bin/cityb adapter doctor free-stable --json
./bin/cityb rendezvous firehose-fixture --require --json
./bin/cityb evidence board --json
./bin/cityb version --json
./bin/cityb-node version --json
./bin/cityb-biggun version --json
./bin/cityb capabilities
./bin/cityb deployment init --out ./city-b.toml --force --json
./bin/cityb up --root ./city-b-artifacts --deployment ./city-b.toml --json

Signing handoff:
./bin/cityb release ceremony --json
./bin/cityb release sign ./SHA3SUMS --signing-key RELEASE_SIGNING_KEY --apply --json
./bin/cityb release verify . --signature-policy require-verified --signature-verifier ssh --allowed-signers ALLOWED_SIGNERS --signer-identity SIGNER_IDENTITY --json
This kit is distributed unsigned. SHA3SUMS provides integrity checks, not publisher authentication.

This archive does not publish anything, start a service, create authority,
read credentials, or modify monsternix.
