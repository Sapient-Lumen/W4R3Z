# AnonSSH source supplement, 2026-10-20

This publisher-added supplement leaves the supplied AnonSSH executable and original source archive unchanged. It accompanies handoff 9831b007cd47ad9d8b1c82c417804fac9a780db2.

libxcrypt-4.5.2.tar.xz is the exact upstream release input selected by the bundled Nixpkgs recipe. Its raw SHA256 matches the recipe SRI sha256-cVE6McAaQovM1TZ6Mv2V8RXW2sUPtbYMd51ceUKuwHE=. Origin: https://github.com/besser82/libxcrypt/releases/download/v4.5.2/libxcrypt-4.5.2.tar.xz .

The selected libxcrypt Nix recipe and its local patch are copied unchanged from the supplied source archive. Upstream LICENSING and COPYING.LIB are also supplied explicitly; the source tar contains the full project. libxcrypt is statically present in the embedded Dropbear. Its overall license is LGPL-2.1-or-later, with component terms detailed in LICENSING.

The original archive contains Dropbear source, its Nixpkgs recipe and pass-path.patch, and the additional AnonSSH nix/dropbear-runtime-helpers.patch selected by default.nix. These are the application-source/build materials relevant to rebuilding Dropbear with a modified libxcrypt. The application supports ANONSSH_DROPBEAR_BIN for selecting an operator-built replacement without changing the outer executable. The exact package dependency recipe selects libxcrypt as a build input. This supplement is not a new binary build or an independently verified offline-rebuild receipt.

libevent-883630f.patch is the upstream commit patch at https://github.com/libevent/libevent/commit/883630f76cbf512003b81de25cd96cb75c6cf0f9.patch . Its raw downloaded hash is recorded below. Nix fetchpatch normalizes patches, so that raw hash differs from the normalized-output hash in the supplied package recipe; this supplement does not mislabel the raw file as the normalized object.

The supplement closes the absence of the exact libxcrypt upstream source payload and supplies the identified upstream libevent patch and explicit libxcrypt terms. It does not certify an exhaustive notice/SBOM inventory or silently alter the original sources.json completeness statement. Consult the release material notes for the remaining inventory distinctions.
