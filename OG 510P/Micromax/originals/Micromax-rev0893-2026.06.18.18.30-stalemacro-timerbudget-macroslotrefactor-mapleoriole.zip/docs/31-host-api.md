# Host API (stable surface for editor scripting)

Micromax scripts should interact with the outside world only through **hostcalls**.
Hosts choose what to expose; scripts can probe capabilities via `host.feature?`.

## Versioning

- `host.api-version` returns a string like `"0.1"`.
- Hosts SHOULD expose features as strings in `host.features`.

A script may:
- check `host.api-version` for coarse compatibility
- check `host.feature?` for optional capabilities
- (optionally) call `host.capabilities` for a small registry with descriptions

## Design principles

- **Small, orthogonal primitives**: prefer a few powerful hostcalls over many narrow ones.
- **Portable stack types**: hostcalls return only ints/strings/lists/cells/quotations (no opaque objects).
- **Undo correctness**: editor mutations should record undo in a predictable way.
- **Future per-plugin VMs**: hostcalls must not assume global shared VM state.
- **Fail closed before eating evidence**: capability-denied or type-invalid host-boundary calls should leave operation arguments on the stack whenever practical (rev778 extends this to open-url, shell, filesystem, open, require, and protected option writes).


## Environment conventions (rev64)

These are *not* hostcalls, but agreed-upon conventions used by the reference editor and VM:

- `$MICROMAX_INIT` — override the user init/rc file path (default: `~/.config/micromax/init.mx`).
- `$MICROMAX_PATH` — module search path for `include`/`require` (split by `os.pathsep`, like `$PATH`).

See: `docs/87-editor-config.md` and `docs/88-require-and-paths.md`.
## Editor hostcalls (micromax-editor feature)

Current implemented hostcalls (rev63 reference editor):

### Reference host helpers

These are hostcalls (not VM primitives) installed by the editor embedding and
advertised via `host.feature?`:

- feature: `"mx.strings"`
- hostcalls/words: `s+ s-len s-slice s-index s-contains? s-split s-join s-replace s-trim s-upper s-lower s-format (plus `format` alias word)`
- `s-slice` indexes and the `s-format` argument count are integer control slots; direct Python hostcall callers must pass real integers, not `False` / `True` boolean sentinels (rev737).
- `s-format` `%d` data values reject direct Python boolean sentinels; use explicit integer `0` / `1` data instead of `False` / `True` (rev739).
- `s-format` `%s` renders direct Python boolean sentinels explicitly as `<bool True>` / `<bool False>` instead of integer-looking `1` / `0` text (rev740); boolean dictionary keys also render as quoted explicit witnesses instead of plain `"True"` / `"False"` key text (rev741).
- `s-format` preflights its declared argument count, format plan, and data conversions before consuming data, so count/data mismatches, trailing `%`, unknown specifiers, count/spec mismatches, and `%d` type failures fail at the formatter boundary without partially eating declared data (rev742, rev743, rev744).
- `s-split` preflights source/delimiter type validation before consuming its public arguments, so invalid split data remains inspectable after failure; an empty delimiter still means character split (rev747).
- `s-join` preflights delimiter/list-shape/list-element validation before consuming its public arguments, so invalid join data remains inspectable after failure (rev745).
- `s-replace` preflights source/old/new type validation and the empty-search rule before consuming its public arguments, so invalid rewrite data remains inspectable after failure; use positive-width text for string rewrites rather than Python-style zero-width insertion (rev738, rev746).

### Capability registry (rev78)

Hosts can expose a tiny registry so scripts (and humans) can discover what
optional/unsafe features exist:

- `host.capabilities` ( -- rows ) returns `[[feature option kind enabled doc] ...]`

The reference editor gates unsafe surfaces behind `cap.*` options.
See: `docs/32-capabilities.md`.

Currently registered unsafe capabilities:

- `ed.open-url` — open external URLs (used by the docs browser; rev778 restricts opener dispatch to `http`, `https`, and `mailto`)
- `ed.shell` — run a shell command and capture output
- `ed.clipboard-export` — allow scripts to export clipboard to system clipboard via privileged UI backends (OSC 52 / external tools)
- `ed.clipboard-import` — allow scripts to import/read system clipboard via external tools
- `ed.persist` — allow editor-owned persistence files (recent/history/savecursor) to be read/written
- `ed.buffer-read` — allow scripts to inspect non-active trusted/user or other-origin open-buffer metadata and picker rows (rev810; unsafe)
- `ed.buffer-switch` — allow scripts to switch to trusted/user or other-origin open buffers without granting broad inactive-buffer inventory (rev810; unsafe)
- `ed.cursor-restore` — allow scripts to replay trusted/persisted saved-cursor landings (rev801; replay-only, not write authority)
- `ed.macro-read` — allow scripts to inspect trusted/user or other-origin saved macro payloads (rev802; unsafe)
- `ed.macro-play` — allow scripts to replay trusted/user or other-origin saved macro slots under script authority (rev802; unsafe)
- `ed.mark-read` — allow scripts to inspect trusted/user or other-origin named marks (rev803; unsafe)
- `ed.mark-jump` — allow scripts to jump to trusted/user or other-origin named marks (rev803; unsafe)
- `ed.search-read` — allow scripts to inspect trusted/user or other-origin active-search query/highlight state (rev806; unsafe)
- `ed.search-replay` — allow scripts to replay or replace trusted/user or other-origin active-search state (rev806; unsafe)
- `ed.message-read` — allow scripts to inspect trusted/user or other-origin message-log rows (rev807; unsafe)
- `ed.timer-fire` — allow scripts to explicitly pump trusted/user or other-origin timer callbacks under script authority (rev817; unsafe)
- `ed.prompt-read` — allow scripts to inspect trusted/user or other-origin active prompt text/suggestion state (rev809; unsafe)
- `ed.prompt-write` — allow scripts to submit trusted/user or other-origin active prompts from script context (rev809; unsafe)
- `ed.option-read` — allow scripts to inspect protected capability, persistence, external-command, and save-policy option values (rev810; unsafe)
- `ed.recent-read` — allow scripts to inspect trusted/user, persisted, or other-origin recent-file path history (rev808; unsafe)
- `ed.open` — open a file from disk into a buffer
- `ed.save` — save the current buffer to disk
- `ed.fs-read` — read an arbitrary file from disk as UTF-8 text (capability-gated; optional `cap.fs-root` sandbox; rev770 rechecks containment at the final read seam)
- `ed.fs-list` — list directory entries from disk (capability-gated; optional `cap.fs-root` sandbox; rev770 rechecks containment at the final list seam)
- `ed.fs-stat` — stat a path (exists/kind/size/mtime) (capability-gated; optional `cap.fs-root` sandbox; rev770 rechecks containment at the final stat seam)
- `ed.require` — load/evaluate a Micromax source file (capability-gated by `cap.fs-require`; optional `cap.fs-root` sandbox; rev771 separates code-eval authority from plain `cap.fs-read`; rev773 evaluates loaded source inside script context)

### Messaging + command surface
- `ed.msg` ( "s" -- ) show a message
- `ed.messages` ( -- msgs ) return message rows visible to the current runtime authority; script-origin callers need `cap.message-read` for trusted/user or other-origin rows
- `ed.last-message` ( -- "s" ) return newest visible message (or "")
- `ed.pop-message` ( -- "s" ) pop oldest message (or ""); script-context pops respect per-row message authority unless `cap.history-clear` is enabled
- `ed.clear-messages` ( -- ) clear message list; script-context clears respect per-row message authority unless `cap.history-clear` is enabled
- `ed.with-messages` ( q -- ok ) run quotation and restore message log
- `ed.capture-messages` ( q -- msgs ok ) capture messages emitted by quotation
- `ed.command` ( "cmdline" -- ok )
- `ed.cmd-add` ( xt "name" "doc" -- ok ) define or replace a command-bar command
  - command faults now surface through the normal command dialect too: `command NAME: error: ...`
- `ed.cmd-rm` ( "name" -- ok ) remove a command-bar command
- `ed.cmds` ( -- names ) list command names
- `ed.cmd-rows` ( -- [[name doc group|0 [file line col]|0] ...] ) list command metadata
- `ed.command-detail-row` ( "name" -- [name doc group|0 [file line col]|0] | 0 ) list the tiny shared command-detail row behind `showcmd NAME`; returns `0` when the command does not exist
- `ed.action-detail-row` ( "name" -- [name doc [file line col]|0] | 0 ) list the tiny shared action-detail row behind `showaction NAME` / `help ACTION`; returns `0` when the action does not exist
- `ed.option-section-summary-rows` ( "query" -- [[label count sample_name sample_detail] ...] ) list the tiny shared broad option-family rows behind `showoptiongroups [QUERY]`
- `ed.option-detail-row` ( "name" -- [query canonical value default kind local_override? doc] | 0 ) list the tiny shared exact option-detail row behind `showoption NAME`; returns `0` when the option does not exist
- `ed.word-detail-row` ( "name" -- [name kind effect wordlist doc [file line col]|0 source|0] | 0 ) list the tiny shared visible-word detail row behind `showword NAME`; returns `0` when the word is not visible in the current search order or is hidden by script/runtime authority; protected exact denials preserve the name operand
- `ed.doc-detail-row` ( "topic" -- [topic title summary section path] | 0 ) list the tiny shared docs-detail row behind `showdoc TOPIC`; returns `0` when the target does not resolve to a docs page
- `ed.hook-detail-row` ( "name" -- [query name handler_count sample_handler|0 sample_detail|0 [file line col]|0] | 0 ) return the tiny shared exact hook row behind `showhook NAME`; returns `0` when the looked-up name is not a hook; handler metadata is authority-filtered in script context
- `ed.hook-inventory-rows` ( "name" -- [[handler group|0 [file line col]|0] ...] | 0 ) list the tiny shared hook-handler register behind `showhook NAME`; returns `0` when the looked-up name is not a hook; protected handlers require `cap.hook-read`
- `ed.hook-summary-rows` ( "query" -- [[name handler_count sample_handler|0 [file line col]|0] ...] ) list the tiny shared broad hook register behind `showhooks [QUERY]`; hook names remain public while handler rows/spans are filtered
- `ed.command-edit` ( "prefill" -- ) open command prompt with text
- `ed.command-palette` ( query -- ) open the searchable command/action palette prefilled with `query`
- `ed.command-palette-rows` ( query -- rows ) ranked command/action palette rows as `[[name kind menu info] ...]`
- `ed.command-palette-section-rows` ( query -- sections ) grouped palette rows as `[[label [[name kind menu info] ...]] ...]`; empty queries can include `Recent Files` / `Recent`, and path-like queries can include `Directories` / `Files` / `Open`
- `ed.command-palette-section-summary-rows` ( query -- rows ) tiny count-aware command-palette bucket rows as `[[label count sample_name sample_detail] ...]` behind plain `showpalettegroups [QUERY]`
- `ed.run` ( "action-chain" -- ok ) — executes the action chain inside editor script context, so `command:` and `mx:` branches do not bypass capability/option-mutation policy
- `ed.bind` ( "key" "action-chain" -- )
- `ed.bind-mode` ( "mode" "key" "action-chain" -- ) bind a key in a named keymap mode
- `ed.bind-doc` ( "key" "doc" -- ok ) attach/replace a human description for a global binding
- `ed.bind-mode-doc` ( "mode" "key" "doc" -- ok ) attach/replace a human description for a mode binding
- `ed.bind-prefix` ( "key" "mode" doc|0 -- ok ) bind a global prefix key that enters a one-shot mode
- `ed.bind-mode-prefix` ( "owner-mode" "key" "mode" doc|0 -- ok ) bind a mode-local prefix key that enters a one-shot mode
- `ed.unbind` ( "key" -- ok ) remove a global key binding
- `ed.unbind-mode` ( "mode" "key" -- ok ) remove a mode-specific key binding
- `ed.bindings` ( -- [[key action-spec [file line col]|0] ...] ) list bindings with best-effort provenance
- `ed.binding-detail` ( -- [[key action-spec group|0 [file line col]|0] ...] ) list binding metadata
- `ed.binding-detail-row` ( key -- [mode key action-spec desc|0 group|0 [file line col]|0] | 0 ) return the tiny shared resolved-binding row behind `showkey KEY`
- `ed.binding-modes` ( -- [[mode key action-spec group|0 [file line col]|0] ...] ) list bindings with mode metadata
- `ed.binding-rows-for` ( mode|0 -- [[key action-spec group|0 [file line col]|0] ...] ) list bindings for one mode
- `ed.binding-info-for` ( mode|0 -- [[key action-spec desc|0 group|0 [file line col]|0] ...] ) list bindings for one mode with human descriptions
- `ed.available-bindings` ( -- [[mode key action-spec group|0 [file line col]|0] ...] ) list precedence-resolved current bindings
- `ed.available-binding-info` ( -- [[mode key action-spec desc|0 group|0 [file line col]|0] ...] ) list precedence-resolved current bindings with human descriptions
- `ed.available-binding-inventory-rows` ( -- [[mode key action-spec label once?] ...] ) list the tiny shared current-binding register behind `showbindings active` / `whichkey`
- `ed.binding-section-summary-rows` ( "query" -- [[label count sample_name sample_detail] ...] ) list the tiny shared winning-mode binding summaries behind `showbindingmodes [QUERY]`
- `ed.resolve-key` ( key -- [mode key action-spec group|0 [file line col]|0] | 0 ) resolve one key through active keymodes
- `ed.resolve-key-info` ( key -- [mode key action-spec desc|0 group|0 [file line col]|0] | 0 ) resolve one key with human description through active keymodes
- `ed.keymode!` ( mode|0 -- ) set active key mode
- `ed.keymode@` ( -- mode|0 ) query active key mode
- `ed.keymode-push` ( "mode" -- ) push active key mode
- `ed.keymode-push-once` ( "mode" -- ) push a one-shot active key mode
- `ed.prefix-mode` ( "mode" -- ok ) enter a one-shot prefix mode and immediately emit `whichkey`
- `ed.keymode-pop` ( -- mode|0 ) pop active key mode
- `ed.keymodes` ( -- active known ) list active mode stack and known binding modes
- `ed.keymode-rows` ( -- active known ) list `[[mode once?] ...]` plus known binding modes
- `ed.keymode-inventory-rows` ( -- [[section mode once?] ...] ) list the tiny shared active/known keymode register behind `showkeymodes`
- `ed.keymode-detail-row` ( name -- [mode active? known? once? binding_count sample_key|0 sample_action|0 sample_desc|0] | 0 ) return the tiny shared exact keymode row behind `showkeymode NAME`
- `ed.press-key` ( "key" -- ok ) resolve + execute a bound key through active keymodes
- `ed.group!` ( group|0 -- ) set default editor registration group
- `ed.group@` ( -- group|0 ) query default editor registration group
- `ed.after` ( ms q -- id ) schedule a deterministic editor timer callback; script-created timers carry script/plugin authority into later execution
- `ed.cancel-timer` ( id -- ok ) cancel a timer if the current runtime authority owns it
- `ed.pump-timers` ( -- ran ) run due timers; script-origin pumping is authority-filtered and requires `cap.timer-fire` for protected timers

### Status / infobar model
- `ed.status` ( -- m ) return a portable statusline/infobar map (`keymode_once` included when a one-shot mode is active)
- `ed.status-summary` ( -- "s" ) return a compact summary string for debug/headless use; rev407 also carries actionable docs-history cues here as `help_nav='...'` / `help_actions='...'` when local docs navigation is resumable or replayable
- `ed.statusfmt` ( "template" -- "s" ) render a statusformat template against the current status model
- `ed.statusline-text` ( width -- "s" ) render the full statusline string for a given width
- `ed.statusline-model` ( width -- m ) return the shared statusline layout model (`left_raw`, visible `left`/`right`, padding width, truncation flags, `text`)
- `ed.interaction-model` ( width -- m ) return the shared visible prompt/capture row model (`kind`, `prefix`, `summary`, `detail`, `position`, `raw_line`, visible `text`, truncation flag)
- `ed.gutter-model` ( lines cols -- m ) return the shared visible gutter model (`line_numbers`, `scrollbar_rows`, widths, `scrollbar_x`)
- `ed.keymenu-model` ( width -- m ) return the shared visible keymenu row model (`context`, shortcut `entries`, `text`)
- `ed.infobar-model` ( width -- m ) return the shared idle infobar row model (`message_raw`, `summary_raw`, visible message/summary segments, padding/truncation, `text`)
- `ed.screen-layout` ( lines cols -- m ) return the tiny shared reference screen-layout model (`viewport_x/y`, viewport size, gutter widths, picker suggestion height, bottom-row y positions) used by the minimal curses TUI
- `ed.edit-window` ( lines cols -- m ) return the shared visible edit-window model (`rows`, `row_count`, viewport map, softwrap flag, cursor view/screen coordinates); unlike `ed.screen-layout`, this live snapshot also syncs viewport size/origin the way the reference renderer does before painting
- `ed.showchars-rows` ( lines cols -- m ) return the shared visible `showchars` row model (`rows`, `row_count`, `changed_rows`, raw `text`, visible `display_text`, replacement `spans`) used by the minimal curses TUI when it wants inspectable invisible-character replacement cues
- `ed.viewport-cues` ( lines cols -- m ) return the shared visible viewport-cue model (`rows`, `row_count`, per-row `cursorline` / search/showchars/trailing/tab-error/colorcolumn/brace spans) used by the minimal curses TUI when it wants inspectable non-text edit-window overlays
- `ed.display-rows` ( lines cols -- m ) return the shared painted-text screen rows (`rows`, `row_count`, final visible `text`, `raw_text`, viewport `overflow_cells`, `viewport_display_text`) for callers that want the same plain row text the reference curses TUI paints after `showchars` / overflow-marker overlays
- `ed.docs-cues` ( lines cols -- m ) return the shared visible docs/help cue model (`rows`, `row_count`, top-level heading/link/image/code/markup/literal/table/structure/definition counts and focused slice rows, per-row `line_role`, `heading_entries`, parsed `definition_entries`, `link_spans`, parsed `link_entries` / `image_entries` / `code_entries` / `markup_entries` / `literal_entries` / `table_entries` / `structure_entries`, focused sibling slices like `raw_html_literal_entries` / `escaped_markdown_entries`, `dim_spans`, `bold_spans`, `italic_spans`, inert/help scanability metadata) used by the minimal curses TUI when it wants inspectable markdown-ish docs/help emphasis
- `ed.viewport-rows` ( lines cols -- m ) return the shared visible viewport-row model (`rows`, `row_count`, visible line-number + scrollbar cells, stable row/cursor positions) used by the minimal curses TUI when it wants edit-window rows already zipped together with their gutters
- `ed.prompt-panel` ( lines cols -- m ) return the visible picker suggestion panel snapshot (`y`, `height`, `width`, positioned rendered `entries`) used by the minimal curses TUI for picker-style prompts
- `ed.screen-model` ( lines cols -- m ) return the composed visible-screen snapshot (`layout`, `search_rows`, `showchars_rows`, `viewport_rows`, `viewport_cues`, `display_rows`, `docs_cues`, `edit_window`, `prompt_panel`, positioned `bottom_rows`, active `cursor`) used by the minimal curses TUI when it wants one inspectable whole-screen reference model
- `ed.screen-rows` ( lines cols -- m ) return the flat plain-text visible-screen rows (`rows`, `row_count`, stable row/cursor metadata) for callers that want the ordered visible screen text without scraping curses or overlaying smaller row models by hand
- `ed.filetype` ( -- "s" ) return detected filetype for the active buffer

### Viewport + line access
- `ed.viewport` ( -- m ) return viewport map `{top_line,top_subline,left_col,height,width}` (height/width may be 0 until a UI sets them)
- `ed.viewport!` ( top left height width -- ) set viewport model and keep the cursor visible
- `ed.with-viewport` ( q -- ok ) run quotation and then restore the viewport model
- `ed.line` ( line -- "s" ) get one buffer line (0-based; clamped)
- `ed.lines` ( start count -- lines ) get a range of lines as `["...", ...]`

Current status map fields include:

- `mode`, `keymode`, `buffer_name`, `file_name`, `filetype`, `path`, `cwd`
- `dirty`, `readonly`
- `line`, `col`, `display_line`, `display_col`, `position`
- `line_count`, `cursor_count`, `primary_cursor_index`
- `selection_count`, `primary_selection_chars`
- `prompt_kind`, `prompt_text`, `prompt_cursor`
- `prompt_current_insert`, `prompt_current_kind`, `prompt_current_menu`, `prompt_current_info`
- `prompt_current_section`, `prompt_current_preview`
- `viewport_top_line`, `viewport_left_col`, `viewport_height`, `viewport_width`
- `last_message`
- `macro_recording`, `macro_playing`, `macro_name`

### Prompt interaction
- `ed.prompt-kind` ( -- "kind" )
- `ed.prompt-text` ( -- "text" )
- `ed.prompt-set` ( "text" -- ) set active prompt text; `find` keeps `incsearch`, and searchable `palette` / `topic` / `binding` prompts now live-refresh ranked rows
- `ed.prompt-submit` ( -- ok )
- `ed.prompt-suggestions` ( -- suggs ) list of completion candidates
- `ed.prompt-suggestion-rows` ( -- rows ) aligned `[[insert kind menu info] ...]` metadata for active suggestions
- `ed.prompt-current-row` ( -- row|[] ) current selected suggestion row as `[insert kind menu info]`
- `ed.prompt-current-section` ( -- "label" ) coarse section for the current item (`Command`, `Action`, `Word`, or a picker-specific visible section label like `Prompt`, `nav`, `Global`, `Help`, a project root, `Errors`, or `Current` / `Back` / `Forward`, or `""`)
- `ed.prompt-current-preview` ( -- "text" ) compact current-item preview string
- `ed.prompt-window` ( lines -- m ) shared picker-window model `{kind max_lines flat_count selected_index selected_flat_index start end show_top show_bottom sticky_section hidden_above hidden_below entries}` used by the minimal TUI for sticky headers / more markers / hidden counts
- `ed.prompt-display` ( lines cols -- rows ) shared rendered picker-row model `[{type text row_kind section_label selected ...}]` used by the minimal TUI for visible headers / sticky headers / more markers / selected row text
- `ed.prompt-suggest-index` ( -- i ) current candidate index (-1 if none)
- `ed.prompt-complete` ( dir -- ok ) cycle completion (dir>=0 forward, dir<0 backward)
- `ed.prompt-clear-suggestions` ( -- ok ) clear suggestion session

Rev779 prompt authority note: prompts opened or mutated from script/plugin
context are stamped with script/plugin origin.  Later UI-style submits run the
prepared prompt under that captured origin instead of ambient user authority.
Rev809 adds the read side: lower-authority scripts see blank prompt text/kind
and empty suggestion/detail rows for trusted/user or other-origin prompts unless
`cap.prompt-read` is enabled.  Direct script-origin `ed.prompt-submit` cannot
answer a protected prompt unless `cap.prompt-write` is enabled; same-origin
script-created prompts still submit normally.

- `ed.topic-rows` ( -- rows ) searchable command/action/word/doc topic rows
- `ed.topic-detail-row` ( name -- row|0 ) exact topic row as `[name kind detail_row]`, reusing the same narrower detail row already exposed by `ed.command-detail-row` / `ed.action-detail-row` / `ed.word-detail-row` / `ed.doc-detail-row`
- `ed.topic-section-rows` ( -- sections ) grouped topic rows as `[[label [[name kind menu info] ...]] ...]`
- `ed.topic-section-summary-rows` ( -- rows ) tiny count-aware topic-section rows as `[[label count sample_name sample_detail] ...]`
- `ed.apropos-rows` ( query -- rows ) ranked topic rows for a search query
- `ed.apropos-section-rows` ( query -- sections ) grouped apropos rows in the same shape
- `ed.topic-prompt` ( query -- ) open the searchable topic/help prompt prefilled with `query`; ranked rows refresh as the query changes
- `ed.binding-prompt` ( query -- ) open the searchable current-binding prompt prefilled with `query`; ranked rows refresh as the query changes
- `ed.binding-prompt-rows` ( query -- rows ) searchable current-binding rows as `[[key kind menu info] ...]`
- `ed.binding-section-rows` ( query -- sections ) grouped current-binding rows as `[[label [[key kind menu info] ...]] ...]` (typically `Prompt`, active mode names like `nav`, and `Global`)
- `ed.buffer-inventory-rows` ( -- rows ) tiny inspectable buffer inventory rows as `[name position active dirty readonly]`; script-origin callers see the active buffer and same-origin buffers unless `cap.buffer-read` is enabled
- `ed.buffer-detail-row` ( name -- row|0 ) tiny inspectable exact buffer row as `[name position active dirty readonly section path line_count]` behind plain `showbuffer NAME`; denied script calls preserve the name operand
- `ed.option-inventory-rows` ( -- rows ) tiny inspectable canonical option inventory rows as `[name value default kind local_override?]` for the active buffer context behind plain `show`
- `ed.option-section-summary-rows` ( query -- rows ) tiny count-aware option-family rows as `[[label count sample_name sample_detail] ...]` behind plain `showoptiongroups [QUERY]`
- `ed.option-detail-row` ( name -- row|0 ) tiny inspectable exact option-detail row as `[query canonical value default kind local_override doc]` for the active buffer context behind plain `showoption NAME`
- `ed.buffer-section-rows` ( query -- sections ) grouped buffer rows as `[[label [[name kind menu info] ...]] ...]` (for example `Help`, `Scratch`, project roots, or `Buffers`), filtered by buffer-read authority in script context
- `ed.buffer-section-summary-rows` ( query -- rows ) tiny count-aware buffer-bucket rows as `[[label count sample_name sample_detail] ...]` behind plain `showbuffergroups [QUERY]`, filtered by buffer-read authority in script context
- `buffer-detail` ( name -- row|0 ) small convenience word for the same exact `ed.buffer-detail-row` surface
- `ed.mark-detail-row` ( name -- row|0 ) tiny inspectable exact mark row as `[name buffer position preview active here]` behind plain `showmark NAME`
- `mark-detail` ( name -- row|0 ) small convenience word for the same exact `ed.mark-detail-row` surface
- `ed.mark-section-rows` ( query -- sections ) grouped mark rows as `[[buffer [[name kind menu info] ...]] ...]`
- `ed.mark-section-summary-rows` ( query -- rows ) tiny count-aware mark-bucket rows as `[[label count sample_name sample_detail] ...]` behind plain `showmarkgroups [QUERY]`
- `mark-section-summaries` ( query -- rows ) small convenience word for the same broad `ed.mark-section-summary-rows` surface
- `ed.plugin-inventory-rows` ( -- rows ) tiny inspectable plugin inventory rows as `[name state version deps error_count]` filtered by plugin read authority in script context
- `ed.plugin-detail-row` ( name -- row|0 ) exact plugin detail row; denied script-origin reads preserve the name operand
- `ed.plugin-section-rows` ( query -- sections ) grouped plugin rows as `[[label [[name kind menu info] ...]] ...]` (typically `Errors`, `Loaded`, `Available`) filtered by plugin read authority
- `ed.plugin-section-summary-rows` ( query -- rows ) tiny count-aware plugin-state rows as `[[label count sample_name sample_detail] ...]` filtered by plugin read authority
- `ed.jump-section-rows` ( query -- sections ) grouped jumplist rows as `[[label [[index kind menu info] ...]] ...]` (typically `Current`, `Back`, `Forward`)
- `ed.jump-section-summary-rows` ( query -- rows ) tiny count-aware jumplist-section rows as `[[label count sample_name sample_detail] ...]` behind plain `showjumpgroups [QUERY]`
- `ed.doc-section-rows` ( query -- sections ) grouped docs rows as `[[label [[topic kind menu info] ...]] ...]` (typically numbered families like `00–09 Project`, `10–19 Research`, `20–29 Language + VM`)
- `ed.doc-section-summary-rows` ( query -- rows ) tiny count-aware docs-family rows as `[[label count sample_name sample_detail] ...]`
- `ed.help-link-detail-row` ( -- row|0 ) tiny inspectable current docs-link row as `[topic label target kind line col section]` for the exact link under the primary cursor in the current docs buffer


Prompt-completion hook note: Micromax completion words may return either `( cmd tok_i prefix toks -- cands mode )` or `( cmd tok_i prefix toks -- cands rows mode )`; `rows` uses the same `[insert kind menu info]` shape returned by `ed.prompt-suggestion-rows`. Future UIs can pair those rows with `ed.prompt-current-row`, `ed.prompt-current-preview`, `ed.prompt-window`, `ed.prompt-display`, the grouped topic section hostcalls, and `ed.binding-prompt-rows` / `ed.binding-section-rows` without redoing ranking or visible-row formatting.

Command read note: command registry rows, command-palette command rows, `showcmd`, help/topic command discovery, and exact `ed.command-detail-row` are runtime-authority filtered in script context. Built-in core command docs and same-origin script commands are visible; dynamic trusted/user or other-origin command docs, groups, and source spans require `cap.command-read`. Denied exact command-detail hostcalls preflight before consuming the command-name operand.

Action read/run note: built-in core editor actions remain public UI vocabulary, but dynamic action docs, source spans, command-palette action rows, help/topic rows, `showaction`, and action-spec completion are runtime-authority filtered in script context. Protected dynamic action metadata requires `cap.action-read`; direct script-origin execution of dynamic actions requires `cap.action-run`. Denied exact `ed.action-detail-row` calls preflight before consuming the action-name operand.

Word read note: visible Micromax word detail, source text, source spans, `showword`, and help/topic word discovery are runtime-authority filtered in script context. Built-in/core words remain public; dynamic trusted/user or other-origin definitions require `cap.word-read`. Denied exact `ed.word-detail-row` calls preflight before consuming the word-name operand.


Plugin read note: plugin manager inventory is runtime code-load state.  Script-origin callers can see the currently executing loaded plugin generation's own row, but trusted/user, other-plugin, candidate-only, and broken plugin metadata/load errors require `cap.plugin-read`.  This applies to `ed.plugin-*` rows, `plugin.list`, `plugin.errors`, `showplugin`, `showplugins`, plugin picker rows, and plugin-name completion.

Hook read/fire note: hook event names are public API names, but handler names, groups, source spans, executable tokens, and explicit firing are runtime-authority filtered in script context. Same-origin script/plugin handlers remain visible/runnable. Trusted/user or other-origin handler metadata requires `cap.hook-read`; executing protected handlers or obtaining them through `hook@` requires `cap.hook-fire`, and protected execution stays under script authority rather than becoming trusted.

Timer fire note: `ed.pump-timers` is an explicit execution surface. Script-origin callers can pump same-origin due timers, but trusted/user or other-origin due timers remain pending unless `cap.timer-fire` is enabled. Protected timer execution still uses captured script/plugin authority where applicable, and script-origin pumping does not run autosave maintenance.

Keybinding read/replay note: binding rows, binding prompt rows, `showkey`/`showbindings`/`whichkey`, and exact hostcalls such as `ed.binding-detail-row`, `ed.resolve-key`, and `ed.resolve-key-info` are runtime-authority filtered in script context. Same-origin script bindings are visible; trusted/user or other-origin binding action specs and source spans require `cap.keybinding-read`. Denied exact hostcalls preflight before consuming the key operand. Script-origin `ed.press-key` is also authority checked: same-origin bindings can replay, protected trusted/user or other-origin bindings require `cap.keybinding-press`, and protected replay still runs under caller script authority.

### Inputs (for parameterized actions)

`editor.input` is a transient host-owned dict used to pass parameters into actions.
Macros snapshot it per action step.

- `ed.input-set` ( key val -- ) set input value
- `ed.input-get` ( key -- val|0 ) get input value (or 0 if missing)
- `ed.input-keys` ( -- keys ) sorted keys
- `ed.input` ( -- [[key val] ...] ) current inputs as pairs
- `ed.input-clear` ( -- ) clear input dict

### Macros

- `ed.macro-names` ( -- names ) list saved macro names visible to the current runtime authority; empty-step named slots are omitted, and an empty `last` slot stays hidden until something real is recorded or set there
- `ed.macro-inventory-rows` ( -- rows ) tiny `[name steps]` rows for the same authority-filtered saved macro inventory; empty-step named slots are omitted here too
- `ed.macro-status-rows` ( -- rows ) combined macro status rows as `[[section ...] ...]` where the first row is `[status state name steps saved_count]` and later rows reuse `[saved name steps]`
- `ed.macro-detail-row` ( name -- row|0 ) exact macro detail as `[query canonical state steps default shadow_steps]`; recording-owned `last` / target slots stay inspectable before `stop`, `shadow_steps` preserves any saved slot size hidden under an active recording, and empty idle `last` still returns `["last" "last" "saved" 0 1 0]` so the default replay slot stays inspectable too. Script-origin calls see only same-origin slots unless `cap.macro-read` is enabled
- `ed.macro-get` ( name -- steps ) returns `[]` for missing named slots (only `last` keeps the default-slot fallback). Script-origin calls cannot inspect trusted/user or other-origin macro payloads unless `cap.macro-read` is enabled; denied calls preserve the macro-name operand
- `ed.macro-set` ( steps name -- ) sets one saved macro from portable steps; passing `[]` prunes a named slot (while `last` remains the special default slot). Script-originated calls can create/update their own macro slots, but cannot overwrite trusted slots or slots owned by another script/plugin origin. Writes to `last` or the active recording target are also rejected while recording is open because `stop` / `cancel` would clobber them anyway
- `ed.macro-record` ( name -- ok ) starts recording with captured authority; script-started recordings cannot shadow trusted saved slots and later recorded steps keep script provenance even if a user action produces them
- `ed.macro-stop` ( -- ok ) stops recording, but script-originated code cannot stop a trusted recording
- `ed.macro-cancel` ( -- ok ) cancels recording, but script-originated code cannot cancel a trusted recording
- `ed.macro-play` ( name n -- ok ) replay a saved macro; direct hostcall replay is treated as script-originated, while interactive `macro play` remains a user-authority action. Script-origin replay of trusted/user or other-origin slots requires `cap.macro-play`; when allowed, the steps still run under script authority rather than gaining trusted `cap.*` mutation power
- `ed.macro-recording?` ( -- flag )
- `ed.macro-playing?` ( -- flag )

### Basic buffer IO
- `ed.open` ( "path" -- ok err ) open a file into a buffer (**capability-gated** by `cap.fs-open`; respects `cap.fs-root` when set)
- `ed.save` ( -- ok err ) save the current buffer (**capability-gated** by `cap.fs-save`; respects `cap.fs-root` when set; compatibility two-cell result)
- `ed.save-info` ( force -- ok info err ) save the current buffer and return structured save metadata; `force=1` is the script equivalent of `save!`
- `ed.save-as-info` ( path force -- ok info err ) transactionally save the current buffer under `path` and return structured save metadata
- `ed.disk-state` ( -- m ) return the active buffer's disk freshness map (**capability-gated** by `cap.fs-stat` for path-backed buffers in script context; respects `cap.fs-root` when set)
- `ed.disk-states` ( include-all -- rows ) return multi-buffer disk freshness rows as `[name state warning changed missing dirty active path error]`; path-backed rows are `cap.fs-stat` gated in script context and unauthorized paths are returned as warning rows rather than statted silently
- `ed.disk-rows` ( include-all -- rows ) alias for `ed.disk-states` for callers that prefer row-oriented naming
- `ed.diff` ( max-lines -- ok lines err ) return bounded disk-vs-buffer unified diff rows without mutating the buffer
- `ed.revert` ( force -- ok info err ) reload the current path-backed buffer from disk; `force=1` is the script equivalent of `revert!` and requires `cap.buffer-discard` in script context when the current buffer is dirty
- `ed.text` ( -- "text" )
- `ed.set-text` ( "text" -- ) direct text mutation; refused for effective `readonly` / protected buffers before consuming operation arguments; typed argument failures also preserve stack evidence

### Recent files
Recent-file rows carry runtime authority. Script-origin callers see same-origin path history only unless `cap.recent-read` is enabled; `cap.history-clear` remains destructive-clear authority and does not grant read access.

- `ed.recent` ( -- xs ) return recent file paths visible to the current runtime authority (MRU order)
- `ed.recent-clear` ( -- ) clear the recent file list (fire-and-forget compatibility surface; script-context clears respect per-row MRU authority and fail before clearing trusted/other-origin rows unless `cap.history-clear` is enabled)
- `ed.recent-clear-count` ( -- n ) clear the recent file list and return the forgotten entry count, so scripts can keep the same destructive-action truth the human `recent clear` command already reports; script-context denial preserves the list unless `cap.history-clear` is enabled
- `ed.recent-inventory-rows` ( -- rows ) tiny inspectable recent-file inventory rows as `[index path position active open dirty readonly disk_truth action_truth]` behind plain `recent`, so the flat MRU register keeps the same tiny `existing file` / `new file` plus `current buffer` / `switch buffer` / `empty buffer @ 1:0` truth cues Micromax already knows for exact recent-file surfaces
- `ed.recent-detail-row` ( path -- row|0 ) tiny inspectable exact recent-file row as `[query path index position active open dirty readonly section detail disk_truth action_truth]` behind plain `showrecent PATH`
- `ed.recent-slot-detail-row` ( n|"#n" -- row|0 ) tiny inspectable exact recent-file row addressed by visible 1-based MRU slot, so scripts can keep numbered recent-file truth in the same `N` / `#N` dialect the human command surfaces already understand
- `ed.recent-dir-detail-row` ( dir -- row|0 ) tiny inspectable exact recent-directory row as `[query directory count active_count open_count dirty_count readonly_count sample_path sample_detail sample_menu sample_info]` behind plain `showrecentdir DIR|N|#N` once the command resolves one directory label
- `ed.recent-slot-dir-detail-row` ( n|"#n" -- row|0 ) tiny inspectable exact recent-directory row addressed by the parent directory bucket of one visible 1-based recent-file slot, so scripts can branch from `#N` recent-file truth to the adjacent exact recent-directory bucket without translating the path back to a raw directory label first
- `ed.recent-section-rows` ( query -- sections ) grouped recent rows by project root (the same project-root buckets now also drive the live `recentpick` prompt)
- `ed.recent-section-summary-rows` ( query -- rows ) tiny count-aware recent-file project-bucket rows as `[[label count sample_name sample_detail] ...]` behind plain `showrecentgroups [QUERY]`; after rev508 the sample fields reuse the first visible grouped recent row's menu/info dialect instead of raw path echoes
- `ed.recent-dir-section-rows` ( query -- sections ) grouped recent rows by directory (the same directory buckets now also drive the live `recentdirpick` prompt)
- `ed.recent-dir-section-summary-rows` ( query -- rows ) tiny count-aware recent-file directory-bucket rows as `[[label count sample_name sample_detail] ...]` behind plain `showrecentdirgroups [QUERY]`; after rev508 the sample fields reuse the first visible grouped recent row's menu/info dialect and trim one echoed leading directory when the bucket label already names it
- `ed.recent-prompt-rows` ( query -- rows ) visible `recentpick` rows as `[[path kind menu info] ...]`, so scripts/future UIs can inspect the same ranked grouped pre-open row surface the live project-grouped recent picker would show for `query` without opening a prompt first
- `ed.recent-dir-prompt-rows` ( query -- rows ) visible `recentdirpick` rows as `[[path kind menu info] ...]`, so scripts/future UIs can inspect the same ranked grouped pre-open row surface the live directory-grouped recent picker would show for `query` without scraping transient prompt state
- `recent-detail` ( path -- row|0 ) small convenience word for the same exact `ed.recent-detail-row` surface
- `recent-slot-detail` ( n|"#n" -- row|0 ) small convenience word for the same exact `ed.recent-slot-detail-row` surface
- `recent-dir-detail` ( dir -- row|0 ) small convenience word for the same exact `ed.recent-dir-detail-row` surface
- `recent-prompt-rows` ( query -- rows ) small convenience word for the same visible `ed.recent-prompt-rows` picker surface
- `recent-dir-prompt-rows` ( query -- rows ) small convenience word for the same visible `ed.recent-dir-prompt-rows` picker surface
- `hook-state` ( name -- row|0 ) small convenience word for the same exact `ed.hook-detail-row` surface
- `ed.prompt-current-position` ( -- m ) compact current picker position map `{index count section section_index section_count summary}`
- `ed.prompt-display` ( lines cols -- rows ) shared rendered picker-row maps `[{type text row_kind section_label selected ...}]`

### Docs / help buffers
- `ed.doc-rows` ( -- rows ) docs picker rows as `[[topic kind menu info] ...]`
- `ed.doc-section-rows` ( query -- sections ) grouped docs picker rows as `[[label [[topic kind menu info] ...]] ...]` (for example `00–09 Project`, `10–19 Research`, `20–29 Language + VM`)
- `ed.command-palette-section-summary-rows` ( query -- rows ) tiny count-aware command-palette bucket rows as `[[label count sample_name sample_detail] ...]` behind plain `showpalettegroups [QUERY]`
- `ed.apropos-section-summary-rows` ( query -- rows ) tiny count-aware generic-topic section rows for one apropos query as `[[label count sample_name sample_detail] ...]`
- `ed.help-doc` ( "topic" -- ok ) open a docs page into a protected help buffer
- `ed.help-follow` ( -- ok ) follow a markdown link under cursor in a help buffer
- `ed.help-back` ( -- ok ) go back to the previous docs help page
- `ed.help-forward` ( -- ok ) go forward to the next docs help page after `helpback`; when the remembered forward target no longer resolves it returns `0` and leaves `helpforward: missing doc: TOPIC` in the status/message lane
- `ed.help-resume` ( -- ok ) reopen the last dormant session-local docs target without consuming back/forward history; returns `0` with `helpresume: already active: topic @ line:col` when the docs page is already on-screen, and with `helpresume: missing doc: TOPIC` when the remembered dormant target no longer resolves
- `ed.help-prune` ( -- ok ) prune missing session/back/forward docs targets from local help history without touching ready targets
- `ed.helphistory-rows` ( -- rows ) docs-history register rows as `[[lane depth topic title position state] ...]` with `current`, `dormant`, `back`, and `forward` lanes ordered by immediate actionability; `state` is one of `active`, `ready`, or `missing` so stale targets stay witnessable without posing as replayable
  - companion status fields expose exact replay commands plus blockers: `help_resume_command`, `help_back_command`, `help_forward_command`, `help_prune_command`, ordered `help_navigation_actions` / `help_navigation_action_summary`, and the matching `help_*_warning` / `help_navigation_warning_summary` fields when a remembered target no longer resolves; rev413 also keeps `help_resume_available` aligned with that same actionability contract so an already-active help page does not advertise `helpresume`, and rev414 closes the matching active-command seam so plain `helpresume` / `ed.help-resume` now fail explicitly instead of replaying the already-active page, and rev415 keeps the same action name visible for stale replay misses too so `helpresume` / `helpback` / `helpforward` no longer fall back to generic `help docs:` wording when the remembered target is gone
- `ed.help-link-rows` ( query -- rows ) markdown links in the current docs buffer as `[[label kind target info] ...]`
- `ed.helplink-section-rows` ( query -- sections ) grouped markdown links as `[[label [[label kind target info] ...]] ...]` (grouping controlled by `help.linksections`)
- `ed.help-outline-rows` ( query -- rows ) markdown headings in the current docs buffer as `[[title kind level info] ...]`
- `ed.help-outline-section-rows` ( query -- sections ) grouped outline rows as `[[label [[title kind level info] ...]] ...]` using parent-heading breadcrumb labels (`Top`, `Guide`, `Guide › Links`, ...)
- `ed.help-current-heading-detail-row` ( -- [topic title fragment level line col section] | 0 ) tiny inspectable current docs-heading row for the nearest heading owning the primary cursor in the current docs buffer
- `ed.help-heading-detail-row` ( query -- [topic title fragment level line col section] | 0 ) resolve the exact current-doc heading row that `helpjump QUERY` would use; returns `0` when there is no docs buffer or no heading match
- `ed.helpnav-section-rows` ( query -- sections ) grouped headings + grouped links as `[[label [[name kind menu info] ...]] ...]`
- `ed.helpnav-section-summary-rows` ( query -- rows ) tiny current-doc navigator summaries as `[[label count sample_name sample_detail] ...]` behind plain `showhelpnav [QUERY]`

### Editor lifecycle hooks (VM hooks, not hostcalls)

The editor defines hook words you can attach handlers to with `hook-add`:

- `ed.on-open` ( "buffer" "path" "filetype" -- )
- `ed.on-save` ( "buffer" "path" -- )
- `ed.on-change` ( "buffer" "action" -- )

See `docs/86-editor-lifecycle-hooks.md` for stack contracts and the per-handler
stack isolation rule. Script-origin hook reads/fires are governed by `cap.hook-read`
and `cap.hook-fire`; editor-owned lifecycle emission outside script context keeps
ordinary trusted behavior.



### Plugins
- `plugin.list` ( -- xs ) return loaded plugin names visible to plugin read authority
- `plugin.reload` ( "name" -- ok ) reload a plugin by name (ok is 0/1); it reuses the same user-visible reload feedback dialect as command-bar `plugin reload NAME`; from script context it requires `cap.fs-require` because reload can evaluate code from disk
- `plugin.errors` ( -- xs ) return plugin load errors visible to plugin read authority as `[[name,err] ...]`

### Buffers + marks (navigation helpers)
- `ed.buffers` ( -- names ) list open buffer names visible to the current runtime authority
- `ed.buffer-inventory-rows` ( -- rows ) tiny inspectable buffer inventory rows as `[name position active dirty readonly]`, filtered by the same buffer-read authority
- `ed.active-buffer` ( -- "name" ) current active buffer name (or "") when visible to the current runtime authority
- `ed.set-active-buffer` ( "name" -- ok ) switch active buffer; script-origin callers need same-origin ownership or `cap.buffer-switch` for protected inactive buffers
- `ed.with-buffer` ( "name" q -- ok ) switch to buffer for duration of quotation, then restore; script-origin callers need the same buffer-switch authority

Buffer rows expose live session names, paths, dirty state, cursor positions, and
line counts. Script-origin callers can inspect the active buffer they were invoked
on and buffers they created themselves. Trusted/user or other-origin inactive
buffers require `cap.buffer-read`; switching into them requires the separate
`cap.buffer-switch` replay/navigation capability. Closing protected inactive
buffers is destructive session-state cleanup and requires same-origin ownership,
active-buffer authority, or `cap.buffer-discard`.


- `ed.marks` ( -- [[name buffer line col] ...] ) list named marks visible to the current runtime authority; script-origin callers need `cap.mark-read` for trusted/other-origin marks
- `ed.mark-inventory-rows` ( -- rows ) tiny inspectable mark inventory rows as `[name buffer position preview active here]`, filtered by the same mark-read authority
- `ed.mark-detail-row` ( "name" -- row|0 ) exact mark row as `[name buffer position preview active here]` behind plain `showmark NAME`; denied script calls preserve the name operand
- `ed.mark-section-summary-rows` ( "query" -- rows ) count-aware broad mark-bucket rows reusing the same owning-buffer groups plain `showmarkgroups [QUERY]` now uses
- `ed.mark-set` ( "name" -- ok ) set a named mark at the primary cursor; lower-authority scripts cannot overwrite trusted/other-origin marks
- `ed.mark-jump` ( "name" -- ok ) jump to a named mark (pushes jumplist); script-origin callers need `cap.mark-jump` for trusted/other-origin marks and denied calls preserve the name operand

### Cursor + selection (primary cursor)
- `ed.cursor` ( -- line col )
- `ed.set-cursor` ( line col -- )
- `ed.has-selection` ( -- flag )
- `ed.selection` ( -- "text" )
- `ed.clear-selection` ( -- )

### Multi-cursor + selections
- `ed.cursors` ( -- [[line col] ...] ) cursor list in document order
- `ed.set-cursors` ( [[line col] ...] -- ) set cursor list, clear selections
- `ed.primary` ( -- i ) primary cursor index
- `ed.set-primary` ( i -- ) set primary cursor index
- `ed.selections` ( -- [[aL aC cL cC] ...] ) selections per cursor (directed), [] if none
- `ed.set-selections` ( sels -- ) set directed selections per cursor (cursor positions may update)
- `ed.selection-range` ( -- [line1 col1 line2 col2] | [] ) normalized primary selection range
- `ed.set-selection-range` ( line1 col1 line2 col2 -- ) set primary selection from a range (clamped)

### Cursor/selection state snapshots

These are *state* tools (cursor+selection only) and do not mutate buffer text.

- `ed.cursorstate` ( -- state ) where `state` is `[primary [[id line col aL aC] ...]]` and `aL/aC` are `-1/-1` if no anchor
- `ed.set-cursorstate` ( state -- ) restore cursor/selection state
- `ed.with-cursorstate` ( q -- ok ) run quotation and then restore cursor/selection state (save-excursion style)

### Jumplist (navigation history)

These are navigation tools (not undo): a small per-buffer history of cursor/selection states.

- `ed.push-jump` ( -- ok ) save current cursor/selection state to jumplist
- `ed.jump-back` ( -- ok )
- `ed.jump-forward` ( -- ok )
- `ed.jump-info` ( -- [index size] ) current index and total size
- `ed.jump-history-rows` ( -- rows ) ordered jumplist register rows as `[lane depth index buffer position preview]`
- `ed.jump-detail-row` ( n|"#n" -- row|0 ) tiny inspectable exact jumplist row as `[query index lane depth buffer position preview]` behind plain `showjump INDEX|#N`, so scripts can keep using the same visible hash-prefixed entry token the human jumplist register already prints
- `jump-detail` ( n|"#n" -- row|0 ) small convenience word for the same exact `ed.jump-detail-row` surface
- `jump-section-summaries` ( query -- rows ) small convenience word for the same broad `ed.jump-section-summary-rows` surface
- `ed.clear-jumps` ( -- )

In script context, jumplist rows carry runtime authority: lower-authority scripts may create and navigate their own rows, but cannot clear, truncate, evict, or traverse trusted/user jump rows. `cap.history-clear` permits destructive clears/evictions/truncations, but not navigation through trusted rows.

### Orthogonal text primitives (undoable)
- `ed.range-text` ( line1 col1 line2 col2 -- "text" )
- `ed.replace-range` ( line1 col1 line2 col2 "text" -- line col ) refused for effective `readonly` / protected buffers before consuming operation arguments; typed argument failures also preserve stack evidence
- `ed.delete-range` ( line1 col1 line2 col2 -- line col ) refused for effective `readonly` / protected buffers before consuming operation arguments; typed argument failures also preserve stack evidence
- `ed.replace-selections` ( replacements -- line col ) refused for effective `readonly` / protected buffers before consuming operation arguments
- `ed.replace-preview` ( search value replace_all literal -- row ) side-effect-free replace plan as `[ok count replace_all literal case_sensitive start_index error rows]`, with rows `[line col end_line end_col old new]`

### Undo + grouping
- `ed.with-undo` ( "desc" q -- ok ) execute quotation as a single undo step (transactional for active buffer)

### Clipboard
- `ed.clipboard` ( -- "text" )
- `ed.set-clipboard` ( "text" -- )
- `ed.clipboard-items` ( -- items kind ) where `kind` is `"items"` or `"lines"`
- `ed.set-clipboard-items` ( items kind -- )

Rev799 policy note: the internal clipboard is a protected runtime register in
script context. Same-origin scripts can read/update their own clipboard state;
trusted/user or other-origin clipboard rows require `cap.clipboard-read` for
reads and `cap.clipboard-write` for writes. Denied `ed.set-clipboard` and
`ed.set-clipboard-items` calls validate before mutation, so their operation
operands remain available on the VM stack when the policy refuses the write.
Script-triggered Paste uses the same guarded internal snapshot.

### Selection recovery stack
- `ed.push-selections` ( -- ) save current cursor+selection state
- `ed.pop-selections` ( -- ok ) restore last saved cursor+selection state
- `ed.clear-saved-selections` ( -- )

### Search
- `ed.find` ( "query" -- ok ) set and jump to an active search. Script-origin calls cannot replace trusted/user or other-origin active search state unless `cap.search-replay` is enabled; denied calls preserve the query operand.
- `ed.find-next` ( -- ok ) replay the active search. Script-origin calls may replay same-origin search state, but trusted/user or other-origin search state requires `cap.search-replay`.
- `ed.find-prev` ( -- ok ) same authority rule as `ed.find-next`, in reverse.
- `ed.search-rows` / status search fields redact protected active-search query/highlight state for script-origin callers unless `cap.search-read` is enabled.

### Options
- `ed.option-inventory-rows` ( -- rows ) canonical option inventory rows for the active buffer context; rows reuse the same display-oriented value/default text and local-override flag plain `show` now uses
- `ed.option-section-summary-rows` ( "query" -- rows ) count-aware option-family rows for the active buffer context; rows reuse the same visible family buckets plain `showoptiongroups [QUERY]` now uses
- `ed.option-detail-row` ( "name" -- row|0 ) exact option row for the active buffer context; rows preserve the queried spelling plus canonical target and reuse the same display-oriented value/default text plain `showoption NAME` now uses
- `ed.opt-get` ( "name" -- value )
- `ed.opt-set` ( "name" "raw" -- value )
- `ed.opt-set-local` ( "name" "raw" -- value )

Rev772/773/778 policy note: when execution is inside editor script context (for example
through `ed.command`, `ed.prompt-submit`, `ed.press-key`, `ed.run`, `ed.require`,
script-originated timers, or script-originated hook handlers), option mutation may
not change `cap.*` options. Trusted user init/config code and direct interactive
commands can still enable capabilities explicitly. Core `include` / `require` /
`reload` / `unrequire` also route through the editor load policy in script
context and require `cap.fs-require`. Rev778 also protects runtime registries:
script-originated command/key/timer/hook mutations can only update registrations
owned by the same script origin or live plugin generation. Scripted process `cd`
requires `cap.fs-chdir`, and scripted dirty-buffer force discard requires
`cap.buffer-discard`.

Convenience words (editor):
- `set` — immediate; parses `OPTION VALUE` and sets the option
- `show` — immediate; parses `OPTION` and pushes its value
- `toggle` — immediate; parses `OPTION` and toggles it (bool only)
- `opt@` ( "name" -- value ) — stack-oriented synonym for `ed.opt-get`
- `opt!` ( "name" "raw" -- value ) — stack-oriented synonym for `ed.opt-set`

### Loading micromax code
- `ed.require` ( "path" -- ) load and eval a Micromax file (**capability-gated** by `cap.fs-require`; respects `cap.fs-root` when set; loaded source runs inside editor script context)

## Planned near-term hostcalls (rich-but-stable)

- `ed.with-undo`-style grouping for *cursor/selection-only* edits (no buffer mutation)
- Multi-cursor batch primitives that preserve deterministic ordering (`ed.replace-selections` already covers many cases)

## Safety note

Hosts SHOULD:
- enforce step budgets when running untrusted scripts
- apply capability allowlists per plugin
- keep filesystem/network access out of the default capability set

### Message-log authority (rev795)

Message rows are user-facing recovery/audit evidence.  Script-origin calls may add their own messages, but destructive `ed.pop-message` / `ed.clear-messages` operations are checked against per-row runtime authority.  The scoped helpers `ed.with-messages` and `ed.capture-messages` preserve that authority sidecar when restoring the original log, so temporary capture scopes do not launder script-owned or trusted rows into a different provenance class.  Trusted code can explicitly enable broad script history clearing with `cap.history-clear`. Rev807 adds a separate read-only `cap.message-read` boundary for `ed.messages`, `ed.last-message`, capture results, and statusline `last_message`; read authority does not grant pop/clear authority.


### Option read authority (rev810)

`ed.option-inventory-rows`, `ed.option-detail-row`, `show`, `showoption`, and
statusformat `$(opt:NAME)` now respect the protected option-value policy in
script context. Names and docs remain discoverable, but capability values,
capability roots, persistence paths, external-command settings, URL-confirmation
policy, and save-safety knobs are redacted unless `cap.option-read` is enabled.
Direct `ed.opt-get` refuses protected reads before consuming the option name.

## rev0819 keymode read authority

Keymode read hostcalls are now authority-filtered for script-origin callers. `ed.keymodes`, `ed.keymode-rows`, `ed.keymode-inventory-rows`, and `ed.keymode-detail-row` show public `global` and same-origin script/plugin keymodes by default. Trusted/user or other-origin active and known keymodes require `cap.keymode-read`. Exact denied `ed.keymode-detail-row` calls preserve their mode-name operand. `cap.keymode-read` does not reveal key/action specs; those still require `cap.keybinding-read`.
