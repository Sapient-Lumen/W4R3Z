from __future__ import annotations


from micromax_editor.editor import Editor
from micromax_editor.buffer import Cursor


def _set_cursor_on_substring(ed: Editor, needle: str) -> None:
    eb = ed.cur()
    for i, line in enumerate(eb.buf.lines):
        s = str(line)
        if needle in s:
            col = s.index(needle)
            eb.cursors[0] = Cursor(i, col)
            eb.primary = 0
            return
    raise AssertionError(f"needle not found: {needle}")


def test_helplinkcopy_copies_target_under_cursor() -> None:
    ed = Editor()
    assert ed.open_help_doc("help-browser") is True

    _set_cursor_on_substring(ed, "Softwrap")
    assert ed.exec_command_line("helplinkcopy") is True
    assert ed.clipboard_text().strip() == "94-softwrap.md"
    assert ed.messages[-1] == "helplinkcopy: 94-softwrap.md"



def test_helplinkcopy_copies_footnote_target_under_cursor() -> None:
    ed = Editor()
    assert ed.open_help_doc("help-browser") is True

    _set_cursor_on_substring(ed, "[^help-footnote]")
    assert ed.exec_command_line("helplinkcopy") is True
    assert ed.clipboard_text().strip() == "#^help-footnote"
    assert ed.messages[-1] == "helplinkcopy: #^help-footnote"

def test_docs_buffer_y_copies_target_under_cursor() -> None:
    ed = Editor()
    assert ed.open_help_doc("help-browser") is True

    _set_cursor_on_substring(ed, "Vision")
    assert ed.dispatch_key("y") is True
    assert ed.clipboard_text().strip() == "00-vision.md"
    assert ed.messages[-1] == "helplinkcopy: 00-vision.md"


def test_external_help_link_requires_confirmation_when_enabled() -> None:
    ed = Editor()
    assert ed.open_help_doc("help-browser") is True
    ed.options.set("cap.open-url", "true")

    opened: list[str] = []

    def _opener(url: str, new: int = 0):
        opened.append(url)
        return True

    ed._open_url_fn = _opener

    _set_cursor_on_substring(ed, "micro editor")

    # Starts a confirmation mode; does not open yet.
    assert ed.exec_command_line("helpfollow") is True
    assert ed.current_key_mode() == "openurl"
    st = ed.status_model()
    assert st["mode"] == "openurl"
    assert st["keymode"] == "openurl"
    assert st["keymode_capture"] == 1
    assert st["capture_kind"] == "openurl"
    assert st["interaction_kind"] == "openurl"
    assert st["interaction_prefix"] == "?"
    assert st["interaction_line"].startswith("?open external link from help")
    assert st["capture_source"] == "help"
    assert st["capture_url"] == "https://micro-editor.github.io/"
    assert st["capture_detail"] == "https://micro-editor.github.io/"
    assert st["capture_summary"] == "?open external link from help"
    assert opened == []

    # Copy cancels and copies.
    assert ed.dispatch_key("c") is True
    assert opened == []
    assert ed.clipboard_text().strip() == "https://micro-editor.github.io/"
    assert ed.current_key_mode() != "openurl"

    # Try again and accept.
    assert ed.exec_command_line("helpfollow") is True
    assert ed.dispatch_key("y") is True
    assert opened == ["https://micro-editor.github.io/"]
    assert ed.messages[-1] == "helpfollow: https://micro-editor.github.io/"


def test_external_help_link_copy_uses_typed_helplinkcopy_feedback() -> None:
    ed = Editor()
    assert ed.open_help_doc("help-browser") is True
    ed.options.set("cap.open-url", "true")

    _set_cursor_on_substring(ed, "micro editor")
    assert ed.exec_command_line("helpfollow") is True
    assert ed.dispatch_key("c") is True
    assert ed.clipboard_text().strip() == "https://micro-editor.github.io/"
    assert ed.messages[-1] == "helplinkcopy: https://micro-editor.github.io/"


def test_external_help_link_cancel_does_not_open() -> None:
    ed = Editor()
    assert ed.open_help_doc("help-browser") is True
    ed.options.set("cap.open-url", "true")

    opened: list[str] = []
    ed._open_url_fn = lambda url, new=0: opened.append(url) or True

    _set_cursor_on_substring(ed, "micro editor")
    assert ed.exec_command_line("helpfollow") is True
    assert ed.dispatch_key("n") is True
    assert opened == []


def test_external_help_link_confirmation_mentions_help_source() -> None:
    ed = Editor()
    assert ed.open_help_doc("help-browser") is True
    ed.options.set("cap.open-url", "true")

    _set_cursor_on_substring(ed, "micro editor")
    assert ed.exec_command_line("helpfollow") is True

    msg = ed.messages[-1] if ed.messages else ""
    assert "open external link from help?" in msg
