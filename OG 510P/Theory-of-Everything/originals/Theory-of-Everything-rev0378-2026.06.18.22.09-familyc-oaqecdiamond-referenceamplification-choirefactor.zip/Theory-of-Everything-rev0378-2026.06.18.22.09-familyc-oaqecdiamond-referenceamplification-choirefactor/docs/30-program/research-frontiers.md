# Research frontiers

## RF-01 — QFT on fixed background vs dynamical geometry
Known local quantum theory works astonishingly well, but gravity makes spacetime itself dynamical. Any bridge must say how local field structure survives or emerges when background structure becomes part of the dynamics.

## RF-02 — Black-hole entropy and information
Horizons, entropy, and unitarity produce some of the sharpest cross-domain pressure in modern physics. The archive now holds a bounded fourth-pass answer on the thermodynamic lane: the equilibrium clue itself is slightly stronger because a March 2026 quantum-relative-entropy result recasts Jacobson-style reasoning in a sharper semiclassical / modular-theory form, while widening beyond equilibrium can count as meaningful only when extra constitutive structure, local-law role, observable discriminator, witness route, and regime portability are all named explicitly. Current family B therefore earns a stronger bounded equation-recovery clue plus stricter discipline and better trace bookkeeping, but still no clean beyond-equilibrium explanatory surplus and no climb beyond `WB-1`.

## RF-03 — Entanglement, geometry, and causal order
Multiple programs now treat entanglement as a bridge quantity. The live question is which part is clue, which part is chart artifact, which part is regime-specific, and which part survives once record-bearing observables are demanded. The current archive answer is now eleven-step and bounded: an RT-style claim survives provisional admission, its real surplus over thermodynamic language is isolated as partition-sensitive subregion geometry linkage, a first covariant stress test says that some of that surplus survives beyond the static RT lane, a first stronger-reconstruction audit says that a sharper boundary-to-bulk dictionary still does not reduce witness borrowing below `WB-2`, a family-C partial-identification audit says restricted inverse progress is real without becoming identifiability closure, a family-C inverse-portability screen says that inverse progress is method-diverse rather than one-method narrow but still remains window-, cutoff-, and large-`N`-bound, a family-C non-uniqueness triage says that multiplicity must first be sorted into frame/gauge redescription, observer/dictionary drift, and only then residual empirical collapse, a family-C overlap-class screen says several routes must align before they count as common-target convergence, and a family-C thin-data / acquirable-witness screen says sparse-data geometry recovery is still weaker than candidate-thick identification or witness closure, and a family-C inverse-stability / regularization screen says robustness under one filter, training package, or ansatz is still weaker than portable inverse stability or candidate-native identifiability closure, and a family-C recoverand-versus-surrogate screen says accurate bulk output inside one reconstruction ecology is still weaker than recovery of the candidate-native bulk target itself, and a family-C point-estimate-versus-calibrated-solution-bundle screen says one confident geometry-like answer is still weaker than calibrated bundle-aware or abstention-ready identification, and a family-C abstention-competence-versus-soft-confidence screen says nominal uncertainty is still weaker than a route with declared coverage semantics, audited deferral profile, and shift triggers. The durable record story is still borrowed from the boundary/laboratory side, data-acquisition burden remains unresolved, portable inverse stability remains unresolved, recoverand-versus-target debt remains unresolved, calibration-and-abstention debt remains unresolved, coverage-profiled abstention competence remains unresolved, finite-`N` portability remains unresolved, and stronger regime robustness remains unresolved.

## RF-04 — Measurement, records, and classicality
A ToE that says little about how stable records arise risks becoming mathematically elegant but empirically underdescribed. The archive now carries a witness-borrowing ladder, a three-book split, a witness-package subgate, a cross-frame portability gate, a public-reference-standard gate, a diachronic witness-lineage gate, a cross-site reproducibility gate, an intervention-grade control gate, a drift-resilient autonomy gate, a public-auditability gate, an assertibility gate, a public-adjudication gate, and now a public-evidence-custody gate, so future bridge claims can be judged not only by whether they mention records, but by whether they actually reduce witness-package debt rather than merely borrowing an observer story, an asymptotic access window, a special local-reference construction, one privileged frame-relative success, a silently imported public comparison standard, a silently imported continuity / calibration / archive lineage, a silently inherited site-specific stack, a silently borrowed actuation / feedback stack, a silently borrowed maintenance ecology, a silently borrowed decision-provenance / audit stack, a silently borrowed public-claim entitlement stack, a silently borrowed dispute-resolution stack, or a silently borrowed repository-of-record / artifact-custody stack from elsewhere. The witness-side frame lane is now slightly sharper than that broad brake sentence alone: observer-dependent entropy work has a first bounded invariants-and-bounds audit, a new intersubjectivity coarse-graining audit now says one observer-agreement regime is weaker than coarse-graining-stable publicity while ideal intersubjectivity is finite-resource impossible, a new relational-frame dynamics audit says one chosen frame package can now carry explicit relational observables plus constraint-derived evolution without thereby buying public witness transport, and a new geometric-observable noncommutativity audit says observer-indexed geometric observables in different Lorentz frames need not even be simultaneously sharp. The archive can therefore distinguish raw one-frame rhetoric from stronger but still bounded publicity criteria, from one-frame dynamical execution, from one explicit global↔perspectival entanglement-plus-coherence bookkeeping map, and from an explicit incompatibility brake while still holding the line that none of those gains amount to cross-frame witness portability, public reference-standard closure, or local witness closure. The observer-relative local-operator lane is also slightly sharper than before: recent JHEP work now has a first bounded audit, so the archive can distinguish explicit Stückelberg / clock-and-rod local operators in isometry-breaking backgrounds from the much stronger claims of reliable local-region closure, island-ready operator control, or local witness closure, especially once accumulated spacetime-point fluctuation debt is named. The asymptotic-access lane is also slightly sharper than before: recent flat / celestial holography work now has a first bounded audit, so the archive can distinguish real asymptotic-dictionary gains in universal soft sectors and free-spinor Milne constructions from the much stronger claims of an independent interacting dual or local witness closure. The special finite-region lane is now slightly sharper too: recent de Sitter horizon-edge work now has a first bounded audit, so the archive can distinguish real codimension-2 edge-spectrum and horizon-fluctuation structure in `\Lambda>0` settings from the much stronger claims of generic local observables or local witness closure. A new de Sitter gravitational-observer audit now sharpens the same neighborhood from a different side: worldlines and informational clocks are real observer-language structure, but weakly backreacting or topological sectors can still factorize as spectators, so one information-bearing observer story is weaker than a genuinely gravitational observer and far weaker than public witness closure. The laboratory gravity lane is also slightly sharper than before: gravity-induced-entanglement work now has a first compact interpretation audit, so the archive can distinguish experimentally important low-energy theory discrimination from the much stronger claim of theory-independent proof that gravity is quantum. And a new stimulated single-graviton access audit now gives the archive one bounded low-energy corridor into linearized quantum gravity while holding the line that discrete graviton access is still weaker than quantization closure unless stronger statistics or tomography-grade evidence also lands. A new gravitational-environment state-structure audit now sharpens that same laboratory lane further: within one fixed tidal detector coupling, a quantized graviton bath can preserve a protected low-phonon coherence sector while a classical stochastic background decoheres even there, so the archive now has one bounded same-coupling quantum-versus-classical discriminator that is stronger than raw decoherence rhetoric but still weaker than graviton-state characterization or local witness closure. A new semiclassical-backreaction simulation audit now sharpens the same empirical-contact corridor from a different angle: a renormalized hybrid quantum/classical loop can now execute one bounded class of self-consistent nonlinear semiclassical dynamics with explicit continuum-limit and shot-noise discipline, but that is still weaker than attribution-grade support for semiclassical gravity, weaker than package-independent empirical cash-out, and far weaker than local witness closure. The strongest current completion-bid lane now also has one bounded stringy-collapse corridor: a DP-like kernel can arise in one instant-folded-string cosmology package, but that gain is still weaker than package-independent support for objective collapse, weaker than pointer/record closure, and far weaker than local witness closure.

## RF-05 — Cosmological boundary conditions and constants
The archive now carries a local-law / cosmological-boundary split, a concrete cosmological-constant debt audit, and one canonical vacuum-energy proposal-class stack. The stable gain is the burden split plus a named audit-family router, and the newest sharpened brake is a slow-physics-selectivity burden on relaxation-style vacuum relief: a mechanism that calms vacuum energy but drags nearby slow scalar sectors with it has not yet bought clean local-law closure. The only surviving measure lane remains compressed under `CL-0049`.

## RF-06 — Completion bids versus bridge and tool lanes
The archive now treats this as an explicit frontier rather than background confusion. String / M-theory, asymptotic safety, loop / canonical quantum gravity, causal-set discreteness, and bootstrap / positive-geometry programs do not currently earn the same kind of credit. Some are ambitious completion bids, some are live bridge windows, and some are sharp diagnostic / reconstruction tools. The atlas surface keeps those roles separate, the cash-out sieve forces completion bids to pay separately for recovery, package disclosure, observables, and wedge thickness, the string lane now has five additional strongest-lane brakes and gains together — a bounded worldsheet UV/IR-universality audit saying generic low-energy correlation structure is real but still weaker than observed-sector closure, package relief, or empirical cash-out, a bounded texture-restriction audit saying explicit heterotic Yukawa textures and special-locus flavor symmetries are real but still weaker than observed-parameter fixation or portability, a bounded matrix-theory / asymptotically-flat bulk-corridor audit saying a cleaner BFSS overlap chart between non-Lorentzian and Lorentzian bulk regimes is real but still weaker than generic low-energy recovery, package independence, or witness-package relief, a bounded parent-theory on-shell holography audit saying direct ten-dimensional Type IIB action-level cash-out is real truncation-relief progress in special AdS packages but still weaker than package-independent recovery, observed-sector portability, or witness-package relief, and a bounded stringy-collapse corridor audit saying a DP-like kernel in one instant-folded-string cosmology package is real cross-domain structure but still weaker than package-independent collapse support, measurement closure, or local witness closure — the asymptotic-safety lane has one additional conservative brake saying UV fixed-point existence is still weaker than portable low-energy predictive extraction, especially in massless IR-sensitive sectors where momentum dependence matters explicitly, one fresh gauge-honesty brake saying explicit off-shell effective-action control is still weaker than on-shell observable cash-out or attribution-grade support, and one fresh sign-envelope brake saying positivity / dispersion rhetoric is still weaker than a graviton-aware running envelope with explicit scale, loop, and species disclosure, the loop / canonical lane now has one additional continuum-limit brake saying sufficiently strong spin-foam convergence can collapse into a topological theory while the surviving distributional route yields a rigging-map / physical-Hilbert-space corridor rather than broad semiclassical recovery, the causal-set lane now has one additional minimalist brake saying native quantum-growth ambition is still weaker than a workable non-commuting dynamics because two natural quantum-Bell-causality orderings collapse back to commutativity while the remaining option stays algebraically under-solved and computationally thin, and the bootstrap / positive-geometry / amplitude tool lane now has one additional bounded corridor-level selection gain saying one-loop AdS$_3\times$S$^3$ consistency can fix `n=21` inside a known holographic package while still falling short of standalone ontology, generic low-energy recovery, or witness-package relief. The witness-package subgates now block asymptotic or observer-relative access, one privileged frame success, frame-ported agreement, one-time public standards with borrowed continuity, one-lineage reproducibility rhetoric, cross-site readout portability, portable actuation under one borrowed maintenance ecology, long-run autonomous control with opaque decision provenance, certificate-free categorical claims, entitlement-disciplined outputs with no bounded public challenge route, or bounded public challenge surfaces with no durable public artifact custody, or public artifact custody with no executable rerun path on fresh infrastructure, or fresh independently generated evidence with no candidate-native record-carrier story, or candidate-native witness language with no native preparation / update story, or candidate-native intervention language with no native experiment menu, or native experiment menus with no native threshold / tolerance / coarse-graining story, or native threshold stories with no native learnability / inverse-map / empirical-collapse story, from being over-credited as local closure, intervention-grade control, drift-resilient autonomy, public auditability, assertibility, public adjudication, public evidence custody, fresh-host reinstantiation, candidate-native witness closure, candidate-native intervention closure, candidate-native counterfactual closure, candidate-native threshold closure, candidate-native identifiability closure, or actual local witness closure, and the three-book split blocks broad ToE rhetoric unless local-law, cosmological-package, and witness-package debt are all scored explicitly. A first cross-family candidate-native-identifiability audit now says no current live lane clears that last gate; family C is the strongest partial case, now even has a small method-diverse inverse portfolio plus thin-data/acquisition, inverse-stability/regularization, recoverand-versus-surrogate, point-estimate-versus-calibrated-solution-bundle, abstention-competence-versus-soft-confidence, policy-choice-versus-candidate-order-stability, and order-stability-versus-separation-margin brakes, but it still borrows the decisive inverse map and same/different machinery from boundary packaging, route-specific windows/cutoffs, sparse-data route assumptions, filtering or training-package choices, posterior-collapse effects under strong physics priors, coverage/deferral semantics not yet fixed candidate-natively, rank-margin and no-inversion discipline not yet fixed candidate-natively, reference-frame conventions, and partial-observability assumptions; the new inverse-completeness / stability protocol now prevents those reconstruction, fit, regularization, and margin gains from being upgraded unless target quotient, deficiency map, separation / tie margin, robustness transport, no-inversion zone, and public audit handle are declared, and the new abstention / no-verdict protocol now prevents soft confidence, calibrated bundles, policy deferral, null results, or forced best-answer outputs from being upgraded unless trigger states, returned evidence states, re-entry conditions, and public challenge handles are declared.


## Candidate-native head-succession discipline

Frontier summaries that describe a later release, extracted continuation, generated mirror, local edit, fork, or returned bundle as the current `OQ-0057` head should route that claim through `docs/40-model/candidate-native-identifiability-head-succession-docket.md`. Newness, clean packaging, and mirror wording identify a candidate continuation, not authority transfer; the successor needs predecessor, lineage, owner-delta, mirror, cap, validation, challenge, and rollback replay.


## RF-07 — Public records, identifiability, and gravitational locality

The archive now treats public-record formation as a three-part problem: gravity may obstruct exact local subsystem language, candidate-native identifiability needs a state-machine denominator rather than a pile of dockets, and frame / QES / island routes need explicit equivalence and record-ownership rules. The new surfaces do not close the witness problem; they make the remaining obstruction more precise and easier to test with negative controls.

## RF-08 — Executable route-state and quotient discipline

Current research frontier: turn route states, empirical deltas, negative controls, residual caps, and cross-candidate quotient claims into replayable rows before any future `S4`/`S5` wording. This frontier routes through `docs/30-program/executable-route-ledger.md`, `docs/30-program/empirical-delta-roadmap.md`, and `docs/10-method/duality-and-underdetermination-adjudication.md`.

## RF-09 — Promotion gates, observed-sector recovery, and discriminator forecasts

Current research frontier: route updates must now say which promotion gate they attempt to cross, which observed-sector obligations they touch, and what future artifact would actually change a route row. The single-graviton / graviton-counting corridor is now explicit: it can raise quantum-gravity record pressure, but it remains target-quotient and source/detector-attribution limited.

## RF-10 — Executable public-record carriers and acquisition closure

Current research frontier: distinguish paper-public, metadata-public, replay-public, challenge-public, and candidate-native-public records without confusing any of them with ToE identification. Any future empirical update should pass through the carrier/protocol/claim-binding triad before editing route state.

## RF-11 — Defeaters, rollback propagation, and severe tests

Current research frontier: make authority loss replayable. The new defeater, rollback, dependency-graph, and severity ledgers ask what would remove support, what would propagate downstream, what repair is required, and which alternatives a positive result actually tests. The goal is conservative: no route is promoted by the new layer, and silent repromotion after repair is blocked.


## RF-12 — Evidence aggregation and independent-support accounting

Open frontier: turn robustness, replication, reproducibility, independent implementation, public replay, and variety-of-evidence claims into route-local credit rows. The aim is not to maximize counted support, but to prevent shared assumptions from masquerading as independent confirmations.


## RF-13 — Contrastive confirmation, prior sensitivity, and update ceilings

Evidence for a ToE candidate is rarely unconditional. It is usually evidence against a specified rival set under a model class, likelihood object, nuisance stack, and prior basis. This frontier asks which route rows can survive explicit contrast-class enumeration and prior-sensitivity stress tests without inflating support into candidate-native identifiability. Cosmology, gravitational-wave model comparison, holographic reconstruction, and benchmark-driven inverse maps are the first pressure points.

## RF-14 — Measurement models, calibration traceability, and systematic-error budgets

Current frontier: make raw-record-to-likelihood conversion explicit across all routes. The pressure points are laboratory GIE/BMV calibration and environmental noise, gravitational-wave strain calibration and waveform-systematic propagation, DESI/BAO covariance and prior/model bounds, CMB foreground/delensing/beam calibration, learned inverse benchmark leakage, and regulator/truncation portability. The aim is conservative: measurement and traceability coverage can cap or repair update wording, but cannot promote a route beyond its state-machine ceiling.

## RF-15 — Validity domains, transportability, and extrapolation fences

Current frontier: prevent local evidence from becoming global candidate support by prose. Code-subspace, benchmark, EFT, regulator, laboratory, waveform, survey, CMB, reference-frame, and metadata routes now carry explicit source-domain, transportability, and forbidden-inference rows. The aim is conservative: support can be narrowed, transported under declared maps, or quarantined; no route is promoted by the new layer.

- `RF-16` — Causal and counterfactual identifiability frontier: import causal graph, interventionist, potential-outcomes, and invariant-prediction discipline into route authority without mistaking causal wording for ToE closure.

## RF-17 — Selection effects, multiplicity, and reporting-bias frontiers

- Import selective-inference, look-elsewhere, false-discovery-rate, p-hacking, and file-drawer methods into route credit.
- Priority: distinguish local success from global discovery across theory searches, simulations, lab protocols, survey pipelines, and benchmark corridors.

- `RF-18` — **Model capacity, MDL / Occam penalties, and candidate-family generalization**
  - Pressure: ToE candidates are often expressive enough to absorb many records. Future work should import description-length, marginal-likelihood, information-criterion, holdout, and benchmark-leakage methods without letting any one metric define ontology.


- `RF-19` — **Semantic drift, theoretical terms, and ontology-identity frontier**
  - Pressure: ToE candidates often use the same words for different theoretical objects, and different words for quotient-equivalent structures. Future work should import controlled-vocabulary, ontology, theoretical-term, semantic/pragmatic theory-structure, scientific-realism, and structural-realism discipline without allowing vocabulary management itself to become evidence.

- `RF-20` — formal social-epistemic authority accounting for ToE candidate archives: testimony, peer review, replication, consensus, dissent, and prestige as bounded metadata rather than candidate-native evidence.

- `RF-21` — Computational evidence frontier: distinguish runnable artifact, reproduced result, numerical stability, independent replication, supply-chain integrity, and candidate-native support.

- `RF-22` — Formal proof and assumption-discharge frontier: import proof-assistant, proof-certificate, de Bruijn-factor, and kernel-trust discipline without confusing mechanized fragments with physical or candidate-native closure.

- `RF-23` — Idealization and singular-limit frontier: import model-target, asymptotic-reasoning, VVUQ, and EFT-failure discipline into candidate route authority accounting.

- `RF-24` — Boundary, initial-data, and sector-selection frontier: import background-independence, initial-boundary-value, holographic-boundary, causal-growth, cosmological-initial-condition, and gravitational-boundary-term discipline without letting one selected sector become global candidate support.

- `RF-25` — Gauge, constraint, and observable-quotient frontier: import constrained-Hamiltonian, BRST/BV, Gribov-copy, anomaly, reduction-versus-quantization, Dirac-observable, and relational-observable discipline without letting gauge-fixed representatives become candidate-native public records.

- `RF-26` — Regularization, RG, and matching frontier: import Wilsonian/exact-RG, EFT matching, scheme-dependence, asymptotic-safety regulator, essential-coupling, and scale-setting discipline without letting running parameters, fixed points, or threshold matches become candidate-native observables by prose.


- `RF-27` — Composition and local-to-global consistency: import factorization, cospan/open-system composition, descent/gluing, and cluster/factorization pressure into candidate-native identifiability discipline.

- `RF-28` — Physical viability frontier: unitarity, causality, analyticity, positivity, and ghost/tachyon/gradient stability as candidate-native route filters rather than generic approval labels.

- `RF-29` — Quantization and correspondence frontier: import deformation/geometric/canonical quantization, quantum-gravity semiclassical expansion, decoherence, and problem-of-time discipline without letting classical recovery or formal quantization become candidate-native closure.

- `RF-30` — Route-layer registry / handle-sprawl frontier: use a generated ledger-family registry and route-layer coverage audit to keep executable evidence-control layers route-local, noncompensatory, and visible as the cube grows.

## RF-31 — Information flow, entropy accounting, and no-go constraints

Research frontier for importing quantum-information no-go theorems, data-processing/recovery-map discipline, generalized entropy, entropy cones, Page-curve pressure, and observer-dependent information-access limits into route-local authority controls.

- `RF-32` — **Symmetry/anomaly/no-global-symmetry frontier**
  - Track generalized symmetries, non-invertible symmetries, anomaly matching, no-global-symmetry constraints, and conservation-law leakage as route-local pressure surfaces for future candidate comparisons.
  - Status: research frontier; no route promotion.




- `RF-33` — Topology, dimension, and signature frontier: import topology-change, spectral/operational dimension, Lorentzian/Euclidean contour, and Wick-rotation discipline without letting one spacetime-recovery proxy become candidate closure.

- `RF-34` — Subsystem algebra, factorization, and edge/center frontier: import operator-algebraic locality, split-property, edge-mode, center-choice, and observer-algebra discipline without turning local entropy into candidate identity.

- `RF-35` — Measure, ensemble, typicality, and anthropic/reference-class frontier in gravitational path integrals, landscapes, cosmology, surveys, catalogs, and benchmark samplers; active import lane for `OQ-0084`.

- `RF-36` — Matter-sector recovery frontier: import Standard Model, SMEFT, Higgs/EWSB, Yukawa/flavor, neutrino, dark-sector, and string-phenomenology discipline without letting observed-sector resemblance become ToE identification.

- `RF-37` — Cosmology observed-sector frontier: import Lambda-CDM parameter discipline, cosmological-constant/vacuum-energy pressure, dark-sector constraints, inflation/reheating, BBN, and structure-formation controls without letting one cosmology corridor become ToE identification.

- `RF-38` — Black-hole sector recovery versus route credit. Adds horizon-structure, black-hole-thermodynamics, and evaporation/radiation route controls under `OQ-0087`; no route promotion.


- `RF-39` — Singularity, censorship, and hyperbolicity frontier: keep high-curvature, singularity-resolution, geodesic-completeness, weak/strong cosmic-censorship, Cauchy-development, and global-hyperbolicity language route-local under `OQ-0088`; no candidate promotion.

- `RF-40` — stress-energy / backreaction / energy-condition frontier
  - Added in rev0291; routes source, backreaction, and energy-condition language through `OQ-0089` and the stress-energy/backreaction ledgers.

- `RF-41` — Classical-GR recovery frontier: import equivalence-principle, PPN, solar-system, binary-pulsar, and gravitational-wave testing discipline without letting one corridor become observed-sector or candidate-native closure.

- `RF-42` — State preparation, detector response, and decoherence frontier: import POVM/instrument, localized detector, SPAM, decoherence/einselection, quantum Darwinism, and pointer-record discipline without letting measurement-chain success become candidate-native closure.

- `RF-43` — Asymptotic, infrared, and scattering frontier: import IR-finite scattering, Faddeev-Kulish/dressed-state pressure, BMS/memory/soft-theorem structure, inclusive-observable caveats, and finite-time memory-detector discipline without letting S-matrix success become candidate-native closure.

- `RF-44` — Discretization, finite-volume, and continuum-limit frontier: import lattice field theory, Regge/simplicial gravity, CDT, finite-size scaling, and continuum-extrapolation discipline without letting a finite regulator result become candidate-native closure.

- `RF-45` — correlator/operator/bootstrap frontier.
  - Added in `rev0296`.
  - Owns `OQ-0094`, correlation-function/operator-insertion/bootstrap-data ledgers, and claim-route binding schema-field audit routing.

- `RF-46` — Phase structure, order parameters, and universality frontier: import critical phenomena, CDT phase diagrams, RG universality, bootstrap-critical data, and moduli-space phase-transition discipline without letting phase resemblance become candidate identity.

- `RF-47` — Hilbert-space, representation, and spectral-reconstruction frontier: import AQFT/GNS, Haag/inequivalent-representation, Stone-von Neumann domain, spectral-density, and spectral-geometry discipline without letting one representation or spectrum become candidate identity.

- `RF-48` — Defects, instantons, and vacuum-decay frontier: import topological-defect, BPST/Yang-Mills instanton, Coleman/Coleman-De Luccia bounce, false-vacuum decay, and Standard Model metastability discipline without letting one nonperturbative sector become candidate identity.

- `RF-49` — Compactification, moduli stabilization, and swampland frontier: import flux compactification, KKLT/LVS, distance/tower, WGC, de Sitter, tadpole, and landscape/swampland discipline without letting one controlled vacuum become candidate identity.

- `RF-50` — Lorentz covariance, CPT, and spin-statistics frontier: import SME test discipline, CPT theorem assumptions, spin-statistics theorem assumptions, and gravity-sector Lorentz-test pressure without letting a null corridor or theorem-like relation become candidate identity.


- `RF-51` — Locality, microcausality, and cluster decomposition: import AQFT causal-axiom, local-measurement, cluster-decomposition, and local-QFT definition pressure into candidate-route ledgers without promoting any route.

- `RF-52` — Entanglement, modular flow, and relative-entropy/recovery frontier: import RT/HRT/QES, Tomita–Takesaki modular theory, JLMS, Petz/recovery, and quantum-error-correction discipline without letting entanglement success become candidate identity.


## rev0304 update

Added QEC code-subspace, logical-operator reconstruction, decoder-certification controls, and registered source-kind coverage auditing. No route is promoted to S4/S5.


- `RF-53` — Circuit, holographic complexity, and computational-hardness frontier: import quantum circuit complexity, QFT state complexity, black-hole complexity, complexity=volume/action, and computational-complexity-class discipline without letting complexity or hardness become candidate identity.


- `RF-54` — Equation-of-state, transport, and fluctuation-dissipation frontier: import hydrodynamic EFT, Kubo/FDT, fluid/gravity, Schwinger-Keldysh, and nonequilibrium-response discipline without letting effective-fluid success become candidate identity.


- `RF-55` — Perturbative loop and resummation frontier
  - Added in `rev0307`; routes perturbative-expansion, loop-order/counterterm, and resummation/Borel support through `OQ-0105` without promotion.

- `RF-56` — Stochastic sampling, estimator variance, and convergence frontier: import Monte Carlo, MCMC, nested sampling, HMC, effective-sample-size, and convergence-diagnostic discipline without letting sampler output become candidate identity.

### RF-57 — Sufficiency, score compression, information bottlenecks, and SBI summaries

Track score/MOPED compression, information bottleneck methods, learned summaries, IMNN-style features, ABC summaries, and simulation-based inference compression as denominator-bound pressure surfaces rather than prediction or candidate-identity evidence.

- `RF-58` — Simulator fidelity, surrogate emulation, and sim-to-real transfer frontier: import computer-model calibration, emulator uncertainty, digital-twin credibility, SBI misspecification, and domain-gap discipline without letting synthetic success become candidate evidence.

- `RF-59` — Benchmark/leaderboard evidence frontier: contamination, leakage, Goodhart pressure, adaptive holdout reuse, metric proxy failure, evaluation independence, and public/private challenge maintenance.

- `RF-60` — Prospective prediction, preregistration, and blinding frontier: import preregistration, Registered Reports, blind-analysis, unblinding, and protocol-deviation discipline without letting prediction rhetoric become candidate identity.

- `RF-61` — Unit conventions, fundamental constants, scale-setting, naturalness, and release-chronology audit.
- `RF-62` — Statistical interval, significance, and coverage frontier: import confidence/credible interval, likelihood-ratio, HEP discovery-threshold, and simulation-based calibration discipline without letting error bars or p-values become candidate evidence.

