#!/usr/bin/env python3
"""Build the rev0838 audit for all artifact-emitting publication entry points."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
JSON_OUT = ROOT / "AUDIT" / "PUBLICATION_ENTRYPOINT_RIGHTS_GATE_REV0838.json"
MD_OUT = ROOT / "AUDIT" / "PUBLICATION_ENTRYPOINT_RIGHTS_GATE_REV0838.md"
HELPER = ROOT / "scripts" / "publication_rights_gate.py"

ENTRYPOINTS = [
    {
        "id": "publish_audit_runner",
        "path": "scripts/publish_audit.py",
        "context": "publish-audit",
        "purpose": "run the bounded public-release ledger/materialization audit sequence",
        "mutation_markers": ["\n    for script_name in load_sequence('publish_audit')", "run_script(script_name)"],
        "forbidden_after_block_markers": ["publish-audit: build_release_queue_index.py", "publish-audit: materialize_public_release.py", "release-ledger: OK"],
    },
    {
        "id": "full_archive_package_release",
        "path": "scripts/package_release.py",
        "context": "package-release",
        "purpose": "emit the named full-archive ZIP, SHA-256 sidecar, and artifact-verifier replay",
        "mutation_markers": ["\n    run_package_refresh_sequence()", "\n    digest = write_bundle_atomically("],
        "forbidden_after_block_markers": ["package-refresh:", "package-write:", "package-verify:", "package-artifact-verify:"],
    },
    {
        "id": "public_release_materializer",
        "path": "scripts/materialize_public_release.py",
        "context": "materialize-public-release",
        "purpose": "rewrite public release bundle ZIPs, bundle manifests, and the public artifact index",
        "mutation_markers": ["records = []", "materialize(path)", "ARTIFACT_INDEX.json"],
        "forbidden_after_block_markers": ["materialize-public-release: OK"],
    },
    {
        "id": "public_queue_publisher",
        "path": "scripts/publish_queue_item.py",
        "context": "publish-queue-item",
        "purpose": "write public release records, snapshots, notes, and transition queue items to published state",
        "mutation_markers": ["\n    state, path = find_item(args.item)", "\n        write_public_surface_snapshot(", "\n        atomic_write_text(record_json,"],
        "forbidden_after_block_markers": ["queue item not found", "publish-queue-item: OK"],
    },
]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.is_file() else ""


def load_json(path: Path) -> dict[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def helper_status(root: Path) -> dict[str, Any]:
    helper = root / "scripts" / "publication_rights_gate.py"
    text = read(helper)
    required = [
        "RIGHTS/component_license_ledger.json",
        "publication_rights_gate_status",
        "assert_publication_rights_ready",
        "publication rights gate blocked",
        "decision_required_before_publication",
        "blocking_findings",
        "root_license_or_notice_file_present",
        "root_license_or_notice_file_absent",
    ]
    return {
        "path": "scripts/publication_rights_gate.py",
        "sha256": sha256_file(helper) if helper.is_file() else None,
        "required_snippets": required,
        "missing_required_snippets": [snippet for snippet in required if snippet not in text],
    }


def entrypoint_status(root: Path, cfg: dict[str, Any]) -> dict[str, Any]:
    path = root / cfg["path"]
    text = read(path)
    call = f"assert_publication_rights_ready(ROOT, '{cfg['context']}')"
    call_index = text.find(call)
    imports_helper = "from publication_rights_gate import assert_publication_rights_ready" in text
    mutation_indexes = {marker: text.find(marker) for marker in cfg["mutation_markers"]}
    present_mutations = {marker: idx for marker, idx in mutation_indexes.items() if idx >= 0}
    first_mutation_index = min(present_mutations.values()) if present_mutations else -1
    guard_precedes_first_mutation = call_index >= 0 and first_mutation_index >= 0 and call_index < first_mutation_index
    return {
        "id": cfg["id"],
        "path": cfg["path"],
        "context": cfg["context"],
        "purpose": cfg["purpose"],
        "sha256": sha256_file(path) if path.is_file() else None,
        "imports_shared_helper": imports_helper,
        "expected_guard_call": call,
        "guard_call_present": call_index >= 0,
        "guard_call_index": call_index,
        "mutation_marker_indexes": mutation_indexes,
        "first_mutation_index": first_mutation_index,
        "guard_precedes_first_mutation_marker": guard_precedes_first_mutation,
        "forbidden_after_block_markers": cfg["forbidden_after_block_markers"],
    }


def current_rights_status(root: Path) -> dict[str, Any]:
    ledger = load_json(root / "RIGHTS" / "component_license_ledger.json")
    blockers = ledger.get("blocking_findings", []) if isinstance(ledger.get("blocking_findings", []), list) else []
    return {
        "rights_ledger": "RIGHTS/component_license_ledger.json",
        "rights_ledger_sha256": sha256_file(root / "RIGHTS" / "component_license_ledger.json") if (root / "RIGHTS" / "component_license_ledger.json").is_file() else None,
        "ledger_status": str(ledger.get("status", "missing")),
        "decision_required_before_publication": bool(ledger.get("decision_required_before_publication")),
        "root_license_or_notice_file_present": bool(ledger.get("root_license_or_notice_file_present")),
        "blocking_finding_ids": [str(item.get("id")) for item in blockers if isinstance(item, dict) and item.get("id")],
    }


def build(root: Path = ROOT) -> dict[str, Any]:
    helper = helper_status(root)
    entrypoints = [entrypoint_status(root, cfg) for cfg in ENTRYPOINTS]
    rights = current_rights_status(root)
    all_entrypoints_guarded = all(
        item["imports_shared_helper"] and item["guard_call_present"] and item["guard_precedes_first_mutation_marker"]
        for item in entrypoints
    )
    helper_ok = not helper["missing_required_snippets"]
    current_tree_blocked = (
        rights["decision_required_before_publication"]
        or rights["ledger_status"].startswith("publication_blocked")
        or bool(rights["blocking_finding_ids"])
        or not rights["root_license_or_notice_file_present"]
    )
    return {
        "version": 1,
        "revision_context": "rev0838-session-patch-over-rev0837-over-rev0826",
        "status": "all_publication_entrypoints_rights_gated_and_current_tree_blocked" if helper_ok and all_entrypoints_guarded and current_tree_blocked else "publication_entrypoint_rights_gate_attention_required",
        "purpose": "Ensure all artifact-emitting publication paths fail fast while RIGHTS/component_license_ledger.json blocks publication; rev0837 guarded the full archive packager, while rev0838 extends the guard to public-release materialization and queue publication.",
        "shared_helper": helper,
        "current_rights_status": rights,
        "current_tree_expected_to_refuse_publication_entrypoints": current_tree_blocked,
        "entrypoints": entrypoints,
        "publish_audit_inherits_materializer_gate": True,
        "builder": "scripts/build_publication_entrypoint_rights_gate_audit_rev0838.py",
        "validator": "scripts/validate_publication_entrypoint_rights_gate_rev0838.py",
    }


def render_markdown(data: dict[str, Any]) -> str:
    lines = [
        "# Publication entrypoint rights gate audit — rev0838",
        "",
        "This audit covers artifact-emitting publication paths, not general development validation. A rights-blocked tree may remain development-gate-clean, but it must not create or refresh distributable release outputs.",
        "",
        f"- Status: `{data['status']}`",
        f"- Shared helper: `{data['shared_helper']['path']}`",
        f"- Shared-helper SHA-256: `{data['shared_helper']['sha256']}`",
        f"- Rights ledger: `{data['current_rights_status']['rights_ledger']}`",
        f"- Rights-ledger SHA-256: `{data['current_rights_status']['rights_ledger_sha256']}`",
        f"- Current rights status: `{data['current_rights_status']['ledger_status']}`",
        f"- Current tree expected to refuse publication entrypoints: `{str(data['current_tree_expected_to_refuse_publication_entrypoints']).lower()}`",
        f"- Publish-audit inherits materializer gate: `{str(data['publish_audit_inherits_materializer_gate']).lower()}`",
        "",
        "## Shared-helper required snippets",
        "",
    ]
    for snippet in data["shared_helper"]["required_snippets"]:
        mark = "present" if snippet not in data["shared_helper"]["missing_required_snippets"] else "missing"
        lines.append(f"- `{snippet}` — {mark}")
    lines.extend(["", "## Protected entrypoints", "", "| Entrypoint | Purpose | Imports helper | Guard present | Guard before first mutation marker |", "| --- | --- | ---: | ---: | ---: |"])
    for item in data["entrypoints"]:
        lines.append(
            f"| `{item['path']}` | {item['purpose']} | `{str(item['imports_shared_helper']).lower()}` | `{str(item['guard_call_present']).lower()}` | `{str(item['guard_precedes_first_mutation_marker']).lower()}` |"
        )
    lines.extend(["", "## Blocking finding IDs", ""])
    ids = data["current_rights_status"].get("blocking_finding_ids", [])
    if ids:
        lines.extend(f"- `{item}`" for item in ids)
    else:
        lines.append("- none")
    lines.extend([
        "",
        "## Validator behavior",
        "",
        "`scripts/validate_publication_entrypoint_rights_gate_rev0838.py` regenerates this audit and invokes the publish-audit runner, full-archive packager, public-release materializer, and queue publisher probe. In the current rights-blocked tree each must fail with `publication rights gate blocked` before its mutation markers are reached.",
    ])
    return "\n".join(lines).rstrip() + "\n"


def main() -> int:
    data = build(ROOT)
    JSON_OUT.parent.mkdir(parents=True, exist_ok=True)
    JSON_OUT.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    MD_OUT.write_text(render_markdown(data), encoding="utf-8")
    print(f"publication-entrypoint-rights-gate-audit-build: OK ({data['status']})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
