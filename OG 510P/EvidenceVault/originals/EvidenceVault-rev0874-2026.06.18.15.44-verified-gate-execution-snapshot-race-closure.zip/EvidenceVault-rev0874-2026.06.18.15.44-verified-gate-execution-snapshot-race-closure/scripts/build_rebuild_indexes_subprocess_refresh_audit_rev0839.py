#!/usr/bin/env python3
"""Build the rev0839 rebuild-index material-surface subprocess isolation audit."""
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
JSON_OUT = ROOT / "AUDIT" / "REBUILD_INDEXES_SUBPROCESS_REFRESH_REV0839.json"
MD_OUT = ROOT / "AUDIT" / "REBUILD_INDEXES_SUBPROCESS_REFRESH_REV0839.md"
SCRIPT_REL = "scripts/rebuild_indexes.py"
REQUIRED_BUILDERS = [
    "build_asset_indexes",
    "build_release_refresh_asset_index_audit_rev0834",
    "build_upstream_retention_coverage",
    "build_absolute_path_reference_audit",
    "build_path_reference_shape_audit",
    "build_external_license_evidence_candidates_rev0834",
    "build_rights_evidence_scan",
    "build_license_reference_integrity_audit",
    "build_rights_readiness",
    "build_publication_rights_gate_audit_rev0837",
    "build_publication_entrypoint_rights_gate_audit_rev0838",
    "build_publication_state_transition_rights_gate_audit_rev0839",
    "build_publication_preflight_dry_run_safety_audit_rev0840",
]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def build() -> dict[str, Any]:
    path = ROOT / SCRIPT_REL
    text = path.read_text(encoding="utf-8")
    refresh_match = re.search(r"def refresh_cycle_safe_material_surfaces\(\).*?\ndef classify\(", text, re.S)
    refresh_text = refresh_match.group(0) if refresh_match else ""
    required_snippets = [
        "import subprocess",
        "def run_material_builder_subprocess",
        "env = os.environ.copy()",
        "env[\"PYTHONDONTWRITEBYTECODE\"] = \"1\"",
        "env[\"PYTHONUNBUFFERED\"] = \"1\"",
        "subprocess.run([sys.executable, \"-u\", str(script)]",
        "cwd=ROOT",
        "check=False",
        "returned non-zero status",
    ]
    missing = [item for item in required_snippets if item not in text]
    missing_builders = [item for item in REQUIRED_BUILDERS if item not in refresh_text]
    stale_inprocess_patterns = [
        "module = __import__(module_name)",
        "getattr(module, entrypoint)",
        "inspect.signature(fn)",
    ]
    stale_present = [item for item in stale_inprocess_patterns if item in refresh_text]
    return {
        "version": 1,
        "revision_context": "rev0839-session-patch-over-rev0838-over-rev0826",
        "status": "material_surface_refresh_uses_subprocess_isolation" if not missing and not missing_builders and not stale_present else "material_surface_refresh_subprocess_attention_required",
        "purpose": "Keep scripts/rebuild_indexes.py from importing every material-surface builder into one long-lived Python process; run each refresh builder as a bytecode-suppressed unbuffered subprocess so one builder cannot poison interpreter shutdown or leave hidden state for the next.",
        "script": SCRIPT_REL,
        "script_sha256": sha256_file(path),
        "required_snippets": required_snippets,
        "missing_required_snippets": missing,
        "required_builders": REQUIRED_BUILDERS,
        "missing_required_builders": missing_builders,
        "stale_inprocess_patterns_forbidden_in_refresh_function": stale_inprocess_patterns,
        "stale_inprocess_patterns_present_in_refresh_function": stale_present,
        "validator": "scripts/validate_rebuild_indexes_subprocess_refresh_rev0839.py",
    }


def render_markdown(data: dict[str, Any]) -> str:
    lines = [
        "# Rebuild-indexes subprocess refresh audit — rev0839",
        "",
        "This audit records a concrete cloudtainer reliability refactor: content-derived material surfaces are refreshed through isolated child Python processes instead of being imported into one long-lived `rebuild_indexes.py` interpreter.",
        "",
        f"- Status: `{data['status']}`",
        f"- Script: `{data['script']}`",
        f"- Script SHA-256: `{data['script_sha256']}`",
        "",
        "## Required subprocess-refresh snippets",
        "",
    ]
    for item in data["required_snippets"]:
        mark = "present" if item not in data["missing_required_snippets"] else "missing"
        lines.append(f"- `{item}` — {mark}")
    lines.extend(["", "## Required material-surface builders", ""])
    for item in data["required_builders"]:
        mark = "present" if item not in data["missing_required_builders"] else "missing"
        lines.append(f"- `{item}.py` — {mark}")
    lines.extend(["", "## Forbidden stale in-process refresh patterns", ""])
    if data["stale_inprocess_patterns_present_in_refresh_function"]:
        lines.extend(f"- `{item}` — present" for item in data["stale_inprocess_patterns_present_in_refresh_function"])
    else:
        lines.append("- none present in `refresh_cycle_safe_material_surfaces()`")
    lines.extend(["", "## Rationale", "", "The prior in-process refresh path made a long refresh harder to diagnose and could hang at interpreter shutdown after many builder imports. Subprocess isolation mirrors the existing command-runner policy: each builder gets a clean interpreter, unbuffered progress output, and bytecode suppression."])
    return "\n".join(lines).rstrip() + "\n"


def main() -> int:
    data = build()
    JSON_OUT.parent.mkdir(parents=True, exist_ok=True)
    JSON_OUT.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    MD_OUT.write_text(render_markdown(data), encoding="utf-8")
    print(f"rebuild-indexes-subprocess-refresh-audit-build: OK ({data['status']})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
