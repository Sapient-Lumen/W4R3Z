# Command-surface validation inventory — rev0790

This witness records the rev0790 bounded validation pass that made the operator Makefile command surface explicitly checked against the machine-readable validation inventory, context-pack command hints, and canonical release policy.

## New governed check

- `scripts/validate_makefile_surface.py`
- `make command-surface-check`

The validator checks that:

- `Makefile` keeps `help` as the default goal and disables Python bytecode emission.
- The `.PHONY` declaration, target definitions, help text, and public command order stay aligned.
- Each public command recipe remains the expected bounded script invocation, and referenced scripts exist.
- `VALIDATION_INDEX.json` covers every public target except `help` through either a checked target or composite target.
- `CONTEXT_PACK.json` lists the public `make` command hints and the direct command-surface validator invocation.
- `publishing/CANONICAL_POLICY.json` and `RELEASE_MANIFEST.json` continue to identify `Makefile` as the command surface and `scripts/validate_makefile_surface.py` as its validator.

## Wiring

The command-surface validator is wired into:

- `Makefile`
- `scripts/gate.py`
- `scripts/publish_audit.py`
- `scripts/package_release.py`
- `scripts/publish_preflight.sh`
- `scripts/validate_command_runners.py`
- `scripts/validate_validation_index.py`
- `scripts/validate_control_surfaces.py`
- `scripts/validate_revision_anchors.py`
- `scripts/validate_archive_identity.py`
- `VALIDATION_INDEX.md`
- `VALIDATION_INDEX.json`
- `CONTEXT_PACK.json`
- `CONTROL_SURFACES.json`
- `LIFECYCLE_GATES.json`
- `REVISION_ANCHORS.json`
- `REVISION_RECEIPT.json`
- `CURRENT_FRONTIER.md`
- `CURRENT_FRONTIER.json`
- `publishing/CANONICAL_POLICY.json`

## Boundary

This pass does not add a new public release surface and does not change paper, source, certificate, or artifact payload semantics. It only closes drift risk in the operator command map used to run existing checks and package the archive.
