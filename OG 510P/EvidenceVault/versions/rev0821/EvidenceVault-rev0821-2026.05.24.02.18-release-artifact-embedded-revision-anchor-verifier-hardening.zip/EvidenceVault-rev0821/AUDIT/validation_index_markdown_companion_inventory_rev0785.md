# Validation-index Markdown companion inventory — rev0785

This witness records the rev0785 pass over the human-facing validation and archive-index companions.

## Finding

`VALIDATION_INDEX.json` and `RELEASE_MANIFEST.json` had advanced to rev0784, but `VALIDATION_INDEX.md` still named the rev0783 archive in the `make package-release` row and in the generated-artifact list.  The same Markdown companion also omitted the `make context-check` row introduced when context-pack validation became governed.

A second companion-surface drift was present in `ARCHIVE_INDEX.md`: it contained a current rev0784 section above an older `# Archive bundle index` body whose latest-revision line still pointed at rev0783.

## Repair

- Updated `VALIDATION_INDEX.md` to list `make context-check` and the current named archive `EvidenceVault-rev0785-2026.05.13.16.41-validationindex-mdmirror-gate.zip`.
- Extended `scripts/validate_validation_index.py` so the Markdown companion must mention every JSON-declared checked target, every composite target, every generated artifact path, and no named package bundle other than the current `RELEASE_MANIFEST.json` bundle.
- Rebuilt `ARCHIVE_INDEX.md` from `ARCHIVE_INDEX.json`.
- Extended `scripts/validate_archive_identity.py` so `ARCHIVE_INDEX.md` must mirror the JSON archive ledger's latest revision, top revision heading, bundle order, and summaries.
- Stabilized `scripts/publish_audit.py` by running its explicit script sequence in subprocesses, avoiding repeated in-process validator state bleed during the post-gate release-ledger check set.
- Removed the redundant post-ledger scoped asset-index rebuild from `scripts/publish_audit.py`; the full gate still refreshes and validates asset indexes, while public-release materialization only changes `published/` surfaces.
- Added staged exec boundaries to `scripts/publish_audit.py` so the gate, release-ledger materialization, and post-materialization checks each run from a clean interpreter phase.

## Boundary

`VALIDATION_INDEX.json` and `ARCHIVE_INDEX.json` remain the machine-governing surfaces.  The Markdown companions are operator recovery surfaces, but they are now checked strongly enough that stale package names or omitted current targets become release-gate failures.
