# Asset index inventory repair — rev0775

This audit note records the asset-index gap closed in rev0775.

## Finding

The archive-wide `INDEX/files.*` and `MANIFEST.sha256` were current in rev0774, but the scoped payload indexes were not governed by the gate:

- `artifacts/ARTIFACTS_INDEX.*` still advertised removed curated mirrors after the dedupe pass and omitted current shipped files, including `CANONICAL_PATHS.json` pointer files and `artifacts/repro_packs/` payloads.
- `certs/CERTS_INDEX.*` still advertised three pruned temporary split-view cache certificates under `_tmp/`.

## Repair

Rev0775 adds:

- `scripts/build_asset_indexes.py` to regenerate `artifacts/ARTIFACTS_INDEX.{json,csv}` and `certs/CERTS_INDEX.{json,csv}` from the shipped tree.
- `scripts/validate_asset_indexes.py` to check exact path coverage, row order, byte counts, SHA-256 digests, CSV mirroring, and `artifacts/curated/**/CANONICAL_PATHS.json` target integrity.
- `make asset-indexes` and `make asset-check`, wired into `make gate`, `make publish-audit`, `make preflight`, and `make package-release`.

## Current scoped inventory counts

- `artifacts/ARTIFACTS_INDEX.json`: 219 shipped artifact files, excluding the two artifact-index files themselves.
- `certs/CERTS_INDEX.json`: 110 shipped certificate/signed-example files, excluding the two cert-index files themselves.
- `artifacts/curated/**/CANONICAL_PATHS.json`: 4 pointer files covering 58 deduplicated canonical-path entries.

## Boundary

This repair does not restore removed duplicate mirrors.  The dedupe boundary remains: compact `CANONICAL_PATHS.json` pointer files carry removed-path to canonical-path mappings, and the new validator verifies that those canonical targets exist and still match their recorded size and SHA-256 digest.
