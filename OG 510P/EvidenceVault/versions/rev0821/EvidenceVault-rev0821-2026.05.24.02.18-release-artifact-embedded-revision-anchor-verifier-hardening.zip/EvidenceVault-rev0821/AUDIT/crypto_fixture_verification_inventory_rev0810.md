# Crypto fixture verification inventory — rev0810

This retained witness records the rev0810 move from crypto-envelope syntax-only assurance toward a bounded, locally falsifiable verification lane.

## Added surfaces

- `certs/CRYPTO_FIXTURE_INDEX.json` declares the positive and negative Ed25519 DSSE verification fixtures.
- `certs/CRYPTO_FIXTURE_INDEX.md` is the human-readable companion for the fixture index.
- `schemas/crypto_fixture_index.schema.json` makes the fixture index a registered JSON-schema surface.
- `certs/verification_fixtures/rev0810_ed25519_public.pem` is the public key used by the fixture lane.
- `certs/verification_fixtures/rev0810_positive.dsse.json` must verify over DSSEv1 PAE bytes.
- `certs/verification_fixtures/rev0810_negative_payload_tamper.dsse.json` is syntax-valid but must fail verification because its payload was changed after the positive signature was produced.

## Validator obligations

`scripts/validate_crypto_envelopes.py` still permits retained demo/conformance DSSE examples whose historical signatures are syntax fixtures, but the indexed rev0810 fixtures now have explicit truth expectations:

- positive fixtures must pass Ed25519 verification over `DSSEv1 PAE(payloadType, payload)`,
- negative fixtures must remain syntactically valid and fail Ed25519 verification,
- key IDs must match the shipped public key derivation,
- payload, PAE, and signature SHA-256 values in the index must match the files on disk.

## Boundary

The rev0810 fixture lane does not reclassify every retained historical DSSE example as a valid production signature. It creates a minimal verification contract that proves the validator can distinguish a true positive signature from a syntax-valid tampered negative fixture.
