# rev0786 dedupe-report inventory

## Finding
`DEDUPE_REPORT.md` was still a static rev0436-era witness. It reported 4,261 scanned files and 437 duplicate copies even though the shipped tree had grown past 4,400 regular files and the duplicate-payload profile had changed.

## Repair
- Regenerated `DEDUPE_REPORT.md` from the current shipped tree.
- Added `scripts/build_dedupe_report.py` to compute file count, unique SHA-256 blob count, duplicate-copy count, duplicate-byte count, and the largest duplicate blob groups.
- Added `scripts/validate_dedupe_report.py` to recompute the expected report and fail if the Markdown witness is stale.
- Wired `make dedupe-report` and `make dedupe-check` into the release gate, publish audit, preflight, package-release, validation index, control surfaces, lifecycle gates, revision anchors, context pack, and canonical policy.

## Boundary
This check is an inventory guard, not an instruction to delete every duplicate. Root paper PDF mirrors, retained upstream snapshots, audit trails, and content-addressed bundle stores can intentionally duplicate bytes when provenance or operator convenience depends on the copy.
