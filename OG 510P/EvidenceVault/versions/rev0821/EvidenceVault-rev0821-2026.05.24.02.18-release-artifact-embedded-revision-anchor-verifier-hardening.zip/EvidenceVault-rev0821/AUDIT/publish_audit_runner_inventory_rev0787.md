# Publish-audit runner inventory — rev0787

This audit witness records the rev0787 pass that made the operator-facing publish-audit command bounded and governed instead of relying on a split-check workaround.

## Finding

A fresh rev0786 baseline passed `make gate`, but `make publish-audit` reproduced the previous unresolved behavior: it shelled out to the full gate and then repeated post-ledger checks.  The underlying validators were clean, yet the monolithic wrapper could exceed the wall-clock budget before it reached the final release identity checks.

## Repair

- `scripts/publish_audit.py` now owns the bounded release-materialization/post-refresh sequence: queue index, release ledger, public bundle materialization, asset indexes, dedupe report, file/source indexes, context-pack, manifest, dedupe, governed text surface, embedded archive, publishing, and archive identity checks.
- Full archive-wide validation remains owned by `make gate` and by `scripts/publish_preflight.sh` before shipping/package claims.
- Added `scripts/validate_command_runners.py` and `make runner-check` so runner sequence drift is detected before a package is emitted.
- Wired runner validation through gate, publish-audit, preflight, package final validation, lifecycle gates, control surfaces, validation inventory, revision anchors, context pack, canonical policy, and archive identity surfaces.

## Result

The release path now has separate, truthful command boundaries:

```bash
make gate
make publish-audit
bash scripts/publish_preflight.sh
python3 scripts/package_release.py
```

The package receipt for rev0787 records all four commands plus a fresh-extraction deterministic repackage check.
