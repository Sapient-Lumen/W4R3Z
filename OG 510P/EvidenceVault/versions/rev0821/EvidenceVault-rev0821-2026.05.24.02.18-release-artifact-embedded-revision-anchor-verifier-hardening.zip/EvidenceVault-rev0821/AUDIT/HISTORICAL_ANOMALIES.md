# Historical anomaly ledger

This file is the exact human-facing companion to `AUDIT/HISTORICAL_ANOMALIES.json`.

- Revision: `rev0821`
- Previous revision: `rev0820`
- Generated: `2026-05-24T02:18:00-0400`
- Recent-history floor: `rev0770`
- Validator: `scripts/validate_historical_anomalies.py`
- Anomaly count: `16`

## Carried-forward anomalies

### HA-0001 — audit_witness_body_label_carry_forward
- Status: `carried_forward`
- Path: `AUDIT/asset_index_inventory_rev0775.md`
- Revision: `rev0775`
- Details: `{"filename_revision": "rev0775", "retained_body_labels": ["rev0774"]}`
- Reason: Retained audit witness body preserves historical revision label(s) that do not match the witness filename revision.
- Validator policy: Allowed only when the exact witness path and retained body-label set are ledgered.

### HA-0002 — audit_witness_body_label_carry_forward
- Status: `carried_forward`
- Path: `AUDIT/context_pack_anchor_inventory_rev0784.md`
- Revision: `rev0784`
- Details: `{"filename_revision": "rev0784", "retained_body_labels": ["rev0782", "rev0783"]}`
- Reason: Retained audit witness body preserves historical revision label(s) that do not match the witness filename revision.
- Validator policy: Allowed only when the exact witness path and retained body-label set are ledgered.

### HA-0003 — audit_witness_body_label_carry_forward
- Status: `carried_forward`
- Path: `AUDIT/dedupe_report_inventory_rev0786.md`
- Revision: `rev0786`
- Details: `{"filename_revision": "rev0786", "retained_body_labels": ["rev0436"]}`
- Reason: Retained audit witness body preserves historical revision label(s) that do not match the witness filename revision.
- Validator policy: Allowed only when the exact witness path and retained body-label set are ledgered.

### HA-0004 — audit_witness_body_label_carry_forward
- Status: `carried_forward`
- Path: `AUDIT/filesystem_path_mode_inventory_rev0782.md`
- Revision: `rev0782`
- Details: `{"filename_revision": "rev0782", "retained_body_labels": ["rev0781"]}`
- Reason: Retained audit witness body preserves historical revision label(s) that do not match the witness filename revision.
- Validator policy: Allowed only when the exact witness path and retained body-label set are ledgered.

### HA-0005 — audit_witness_body_label_carry_forward
- Status: `carried_forward`
- Path: `AUDIT/payload_format_zip_container_inventory_rev0778.md`
- Revision: `rev0778`
- Details: `{"filename_revision": "rev0778", "retained_body_labels": ["rev0777"]}`
- Reason: Retained audit witness body preserves historical revision label(s) that do not match the witness filename revision.
- Validator policy: Allowed only when the exact witness path and retained body-label set are ledgered.

### HA-0006 — audit_witness_body_label_carry_forward
- Status: `carried_forward`
- Path: `AUDIT/publish_audit_runner_inventory_rev0787.md`
- Revision: `rev0787`
- Details: `{"filename_revision": "rev0787", "retained_body_labels": ["rev0786"]}`
- Reason: Retained audit witness body preserves historical revision label(s) that do not match the witness filename revision.
- Validator policy: Allowed only when the exact witness path and retained body-label set are ledgered.

### HA-0007 — audit_witness_body_label_carry_forward
- Status: `carried_forward`
- Path: `AUDIT/publishing_helper_entrypoint_inventory_rev0800.md`
- Revision: `rev0800`
- Details: `{"filename_revision": "rev0800", "retained_body_labels": ["rev0799"]}`
- Reason: Retained audit witness body preserves historical revision label(s) that do not match the witness filename revision.
- Validator policy: Allowed only when the exact witness path and retained body-label set are ledgered.

### HA-0008 — audit_witness_body_label_carry_forward
- Status: `carried_forward`
- Path: `AUDIT/validation_index_markdown_companion_inventory_rev0785.md`
- Revision: `rev0785`
- Details: `{"filename_revision": "rev0785", "retained_body_labels": ["rev0783", "rev0784"]}`
- Reason: Retained audit witness body preserves historical revision label(s) that do not match the witness filename revision.
- Validator policy: Allowed only when the exact witness path and retained body-label set are ledgered.

### HA-0009 — audit_witness_body_label_carry_forward
- Status: `carried_forward`
- Path: `AUDIT/zip_extractability_public_bundle_inventory_rev0779.md`
- Revision: `rev0779`
- Details: `{"filename_revision": "rev0779", "retained_body_labels": ["rev0778"]}`
- Reason: Retained audit witness body preserves historical revision label(s) that do not match the witness filename revision.
- Validator policy: Allowed only when the exact witness path and retained body-label set are ledgered.

### HA-0010 — duplicate_archive_bundle
- Status: `carried_forward`
- Path: `ARCHIVE_INDEX.json`
- Revision: `rev0539`
- Details: `{"bundle": "EvidenceVault-rev0539-2026.03.21.23.18-projectionfamilymap-rowkey-bridgehandoff-architecturetighten.zip", "occurrence_count": 2, "revisions": ["rev0539", "rev0539"], "row_indexes": [268, 269]}`
- Reason: Historical archive-index bundle-name duplicate is retained as an inherited archive-lineage fact.
- Validator policy: Allowed only below rev0770 and only while exactly ledgered.

### HA-0011 — duplicate_archive_revision
- Status: `carried_forward`
- Path: `ARCHIVE_INDEX.json`
- Revision: `rev0539`
- Details: `{"bundles": ["EvidenceVault-rev0539-2026.03.21.23.18-projectionfamilymap-rowkey-bridgehandoff-architecturetighten.zip", "EvidenceVault-rev0539-2026.03.21.23.18-projectionfamilymap-rowkey-bridgehandoff-architecturetighten.zip"], "occurrence_count": 2, "row_indexes": [268, 269]}`
- Reason: Historical archive-index revision-label duplicate is retained to preserve bundle-lineage provenance.
- Validator policy: Allowed only below rev0770 and only while exactly ledgered.

### HA-0012 — duplicate_archive_revision
- Status: `carried_forward`
- Path: `ARCHIVE_INDEX.json`
- Revision: `rev0700`
- Details: `{"bundles": ["EvidenceVault-rev0700-2026.03.23.22.31-rowtupledrop-inlinetableownership-familysurfacesonly.zip", "EvidenceVault-rev0700-2026.03.23.22.24-projectionlabeldrop-directrowtriple-rowsurfaceflattened.zip"], "occurrence_count": 2, "row_indexes": [109, 110]}`
- Reason: Historical archive-index revision-label duplicate is retained to preserve bundle-lineage provenance.
- Validator policy: Allowed only below rev0770 and only while exactly ledgered.

### HA-0013 — duplicate_changelog_heading
- Status: `carried_forward`
- Path: `CHANGELOG.md`
- Revision: `rev0539`
- Details: `{"line_numbers": [1292, 1296], "occurrence_count": 2}`
- Reason: Historical changelog headings are retained as provenance rather than renumbered in-place.
- Validator policy: Allowed only below rev0770 and only while exactly ledgered.

### HA-0014 — non_descending_archive_row
- Status: `carried_forward`
- Path: `ARCHIVE_INDEX.json`
- Revision: `rev0539`
- Details: `{"current_bundle": "EvidenceVault-rev0539-2026.03.21.23.18-projectionfamilymap-rowkey-bridgehandoff-architecturetighten.zip", "current_revision": "rev0539", "current_row_index": 269, "previous_bundle": "EvidenceVault-rev0539-2026.03.21.23.18-projectionfamilymap-rowkey-bridgehandoff-architecturetighten.zip", "previous_revision": "rev0539", "previous_row_index": 268}`
- Reason: Historical archive-index ordering collision is retained rather than rewritten after the fact.
- Validator policy: Allowed only below rev0770 and only while exactly ledgered.

### HA-0015 — non_descending_archive_row
- Status: `carried_forward`
- Path: `ARCHIVE_INDEX.json`
- Revision: `rev0700`
- Details: `{"current_bundle": "EvidenceVault-rev0700-2026.03.23.22.24-projectionlabeldrop-directrowtriple-rowsurfaceflattened.zip", "current_revision": "rev0700", "current_row_index": 110, "previous_bundle": "EvidenceVault-rev0700-2026.03.23.22.31-rowtupledrop-inlinetableownership-familysurfacesonly.zip", "previous_revision": "rev0700", "previous_row_index": 109}`
- Reason: Historical archive-index ordering collision is retained rather than rewritten after the fact.
- Validator policy: Allowed only below rev0770 and only while exactly ledgered.

### HA-0016 — non_descending_changelog_heading
- Status: `carried_forward`
- Path: `CHANGELOG.md`
- Revision: `rev0539`
- Details: `{"current_line": 1296, "current_revision": "rev0539", "previous_line": 1292, "previous_revision": "rev0539"}`
- Reason: Historical changelog ordering collision is retained as part of the inherited archive record.
- Validator policy: Allowed only below rev0770 and only while exactly ledgered.
