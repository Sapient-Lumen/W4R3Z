# Publishing helper entrypoint inventory — rev0800

This retained audit witness records the rev0800 publishing-lane repair and hardening. The pass restores the governed public-release queue publisher CLI and then makes publishing validation prove that the release helper entrypoints are callable, not merely present as files.

## Scope
- Restore `scripts/publish_queue_item.py` as a complete argparse CLI after the previous public-release-note companion hardening left the file truncated before `main()`.
- Preserve the canonical public-release-note renderer introduced in rev0799 so future emitted `published/releases/*.md` notes still exactly render from adjacent JSON release records.
- Harden `scripts/validate_publishing.py` so `scripts/scaffold_queue_item.py`, `scripts/transition_queue_item.py`, and `scripts/publish_queue_item.py` must all pass `--help` smoke tests under `PYTHONDONTWRITEBYTECODE=1`.

## Checks
- `python3 scripts/publish_queue_item.py --help`
- `python3 scripts/validate_publishing.py`
- `make publishing-check`
- `python3 scripts/validate_audit_witnesses.py`
- `make audit-witness-check`
- `python3 scripts/validate_current_frontier.py`
- `python3 scripts/validate_validation_index.py`
- `python3 scripts/validate_changelog.py`
- `make gate`
- `make publish-audit`
- `bash scripts/publish_preflight.sh`
- `python3 scripts/package_release.py`

## Non-changes
- No public-release decision changed.
- No public-surface snapshot changed.
- No public path list changed.
- No canonical TeX/PDF paper payload changed.
- No retained upstream source payload was normalized.
- No historical audit witness labels were rewritten.
