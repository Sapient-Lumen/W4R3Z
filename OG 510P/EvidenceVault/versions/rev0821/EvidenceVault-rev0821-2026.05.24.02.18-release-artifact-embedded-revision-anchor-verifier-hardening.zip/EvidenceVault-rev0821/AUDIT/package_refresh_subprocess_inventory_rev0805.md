# Package refresh subprocess inventory (rev0805)

## Scope
This witness records the rev0805 hardening that makes `scripts/package_release.py` run package-refresh builders in fresh subprocesses rather than importing their `main()` functions into the packager process.

## Finding
Rev0803 isolated package-final validators, but the earlier package-refresh phase still called `build_asset_indexes.py`, `build_dedupe_report.py`, and `rebuild_indexes.py` through in-process imports. That left package identity generation dependent on imported builder module state, even though the rest of the command-runner lane was already subprocess-isolated.

## Repair
- `scripts/package_release.py` now declares `PACKAGE_REFRESH_SEQUENCE` and runs the refresh builders through `run_child_script(..., 'package-refresh')` with `PYTHONDONTWRITEBYTECODE=1`, `cwd=ROOT`, and `sys.executable`.
- The post-`RELEASE_MANIFEST.json` index rebuild also uses the same subprocess child runner before package-final validators execute.
- `scripts/validate_command_runners.py` now validates the package-refresh sequence, rejects direct in-process refresh-builder imports/calls, and requires the canonical policy principle for package-refresh subprocess isolation.
- `VALIDATION_INDEX.*`, `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `CURRENT_FRONTIER.*`, `REVISION_ANCHORS.json`, and `publishing/CANONICAL_POLICY.json` now describe the package-refresh subprocess-isolation guard.

## Guardrail
This pass changes package-refresh execution and command-runner validation only. It does not change canonical paper/source payloads, public-release decisions, queue state, historical audit labels, or the stable `published/` surface.
