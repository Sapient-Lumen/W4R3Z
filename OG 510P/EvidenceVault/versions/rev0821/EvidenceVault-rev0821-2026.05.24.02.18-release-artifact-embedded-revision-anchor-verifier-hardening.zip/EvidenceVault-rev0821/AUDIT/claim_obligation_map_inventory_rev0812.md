# Claim-obligation map inventory rev0812

## Scope

rev0812 adds a governed claim-obligation crosswalk without widening the public surface or changing canonical paper/source payloads.  The new map is derivative: it records how selected paper/release claims are supported by already-shipped archive surfaces, validators, Makefile targets, obligations, known limits, and negative-regression expectations.

## Witnessed surfaces

- `CLAIM_OBLIGATION_MAP.json` — machine-readable claim-obligation map.
- `CLAIM_OBLIGATION_MAP.md` — exact rendered companion checked by `scripts/validate_claim_obligation_map.py`.
- `schemas/claim_obligation_map.schema.json` — schema for the governed map.
- `scripts/validate_claim_obligation_map.py` — validator for schema, exact rendering, referenced paths, validator wiring, Makefile target wiring, canonical paper coverage, and policy/control/lifecycle/context/revision-anchor linkage.
- `make claim-obligation-check` — operator-facing validation target.

## Package-blocking posture

The validator is wired into `scripts/gate.py`, `scripts/package_release.py`, `scripts/publish_audit.py`, `scripts/publish_preflight.sh`, `VALIDATION_INDEX.*`, `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `CONTEXT_PACK.json`, `REVISION_ANCHORS.json`, `publishing/CANONICAL_POLICY.json`, and `RELEASE_MANIFEST.json`, so a stale or untruthful claim-obligation map blocks package emission.
