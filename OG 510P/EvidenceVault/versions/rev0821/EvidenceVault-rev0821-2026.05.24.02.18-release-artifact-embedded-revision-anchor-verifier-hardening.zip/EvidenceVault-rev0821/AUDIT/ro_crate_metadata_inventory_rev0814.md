# Research-object metadata bridge inventory rev0814

## Scope
This witness records the current research-object metadata bridge hardening pass.

## Files added
- `ro-crate-metadata.json`
- `RO_CRATE_PROFILE.md`
- `schemas/ro_crate_metadata.schema.json`
- `scripts/validate_ro_crate_metadata.py`

## Validation wiring
- `make ro-crate-check`
- `python3 scripts/validate_ro_crate_metadata.py`
- `scripts/gate.py`
- `scripts/package_release.py`
- `scripts/publish_audit.py`
- `scripts/publish_preflight.sh`

## Boundary
The bridge is a compact external-legibility profile for selected core archive surfaces. It does not replace the native release manifest, full file inventory, SHA-256 manifest, claim-obligation map, or package gate as governing archive truth.
