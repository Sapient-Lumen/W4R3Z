# Public release note companion inventory — rev0799

This retained audit witness records the rev0799 publishing-lane hardening. The pass does not change public-release decisions, public paths, public-surface snapshots, canonical paper/source payloads, or the size of `published/`; it tightens the existing `make publishing-check` lane so published public-release notes cannot drift from their adjacent JSON records.

## Scope
- Harden `scripts/validate_publishing.py` so each shipped `published/releases/*.md` public-release note must exactly equal `render_public_release_markdown(<adjacent JSON record>)`.
- Update `scripts/publish_queue_item.py` and `publishing/templates/public_release.md` so future public release notes are emitted in the same canonical shape.
- Rematerialize the existing public release bundle under `published/releases/artifacts/` from the refreshed note and existing release record.

## Checks
- `python3 scripts/validate_publishing.py`
- `make publishing-check`
- `python3 scripts/validate_audit_witnesses.py`
- `make audit-witness-check`
- `python3 scripts/validate_embedded_archives.py`
- `make gate`
- `make publish-audit`
- `bash scripts/publish_preflight.sh`
- `python3 scripts/package_release.py`

## Non-changes
- No public-release decision changed.
- No public-surface snapshot changed.
- No canonical TeX/PDF paper payload changed.
- No retained upstream source payload was normalized.
- No historical audit witness labels were rewritten.
