# Public status bridge inventory — rev0813

This witness records the addition of the governed public/internal status bridge for the current archive revision.

## Scope
- Added `PUBLIC_STATUS.json` as the machine-readable status bridge.
- Added `PUBLIC_STATUS.md` as the exact human-facing companion.
- Added `schemas/public_status.schema.json` and `scripts/validate_public_status.py`.
- Added `make public-status-check` and wired the validator into gate, package-release, publish-audit, lifecycle, control, context, validation, policy, revision-anchor, and release-manifest surfaces.

## Boundary
- The latest public release pointer remains governed by `published/releases/LATEST.json`.
- The status bridge does not publish a new public release, widen `published/`, move queue state, or change canonical paper/source payloads.
- Direct package emission must fail if the status bridge stops matching the current receipt, release manifest, revision anchors, or latest public-release ledger.
