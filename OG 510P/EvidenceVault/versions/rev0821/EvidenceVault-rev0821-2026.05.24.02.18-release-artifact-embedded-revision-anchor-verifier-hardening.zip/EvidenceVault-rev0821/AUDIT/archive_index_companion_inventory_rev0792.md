# Archive-index companion inventory — rev0792

This witness records the rev0792 bounded validation pass that made the archive bundle-index companion surface explicitly checked rather than relying on `scripts/validate_archive_identity.py` to check only the current top row.

## Governed validator
- `scripts/validate_archive_index.py`
- `make archive-index-check`

## Scope checked
The new validator proves that:
- `ARCHIVE_INDEX.json` validates against `schemas/archive_bundle_index.schema.json`;
- `ARCHIVE_INDEX.json` has a current top row matching `RELEASE_MANIFEST.json` and `REVISION_RECEIPT.json`;
- retained bundle rows are unique and strictly descending by revision number;
- each bundle filename embeds the row revision and a timestamp date matching the row date;
- `ARCHIVE_INDEX.md` exactly mirrors every JSON bundle row, including revision, date, bundle filename, and summary; and
- the archive-index validator is exposed through validation, lifecycle, control, context, canonical policy, revision-anchor, Makefile, composite-runner, changelog, and audit-witness surfaces.

## Runner wiring
The archive-index companion validator is wired into:
- `make archive-index-check`;
- `make gate`;
- `make publish-audit`;
- package-final validation in `scripts/package_release.py`;
- strict required-file preflight in `scripts/publish_preflight.sh`;
- `scripts/validate_command_runners.py` runner-sequence validation;
- `VALIDATION_INDEX.json` and `VALIDATION_INDEX.md`;
- `CONTEXT_PACK.json` command hints and key-machine surfaces;
- `CONTROL_SURFACES.json` and `LIFECYCLE_GATES.json`;
- `REVISION_ANCHORS.json`; and
- `publishing/CANONICAL_POLICY.json`.

## Non-goals
This pass does not rewrite historical changelog entries, does not normalize older audit-witness body labels, does not widen the public release surface, and does not change canonical paper/source payload semantics. It only closes drift risk between the human and machine archive-bundle lineage surfaces.
