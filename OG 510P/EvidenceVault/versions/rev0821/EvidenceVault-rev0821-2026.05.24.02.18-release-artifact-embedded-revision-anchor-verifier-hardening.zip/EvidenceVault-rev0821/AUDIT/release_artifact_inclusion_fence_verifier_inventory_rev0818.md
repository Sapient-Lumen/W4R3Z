# Release artifact inclusion-fence verifier inventory (rev0818)

## Scope

This witness records the rev0818 hardening pass that makes the detached release-artifact verifier replay the `RELEASE_MANIFEST.json` `included_roots` perimeter from emitted ZIP bytes.

## Added or changed surfaces

- `scripts/verify_release_artifact.py` now includes `validate_included_roots_coverage(...)` and rejects ZIP members outside the embedded release manifest's declared inclusion fence.
- `schemas/release_manifest.schema.json` now requires non-empty unique `included_roots` entries.
- `scripts/validate_command_runners.py` now guards the detached included-roots verifier snippets.
- `VALIDATION_INDEX.*`, `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `CONTEXT_PACK.json`, `CLAIM_OBLIGATION_MAP.*`, `CURRENT_FRONTIER.*`, `PUBLIC_STATUS.*`, `TOOLCHAIN_LOCK.*`, `REVISION_ANCHORS.json`, `ARCHIVE_INDEX.*`, and `CHANGELOG.md` were refreshed to name the new artifact-byte inclusion-fence boundary.

## Negative regression

A mutated emitted ZIP that adds a payload outside `RELEASE_MANIFEST.json` `included_roots` while refreshing embedded `MANIFEST.sha256`, `INDEX/files.json`, `INDEX/files.csv`, `RELEASE_MANIFEST.json` `file_count`, and the `.zip.sha256` sidecar must fail `scripts/verify_release_artifact.py` with an included-roots coverage error.

## Non-changes

No canonical paper/source payloads, queue state, public-release decision, or `published/` payload scope were widened.
