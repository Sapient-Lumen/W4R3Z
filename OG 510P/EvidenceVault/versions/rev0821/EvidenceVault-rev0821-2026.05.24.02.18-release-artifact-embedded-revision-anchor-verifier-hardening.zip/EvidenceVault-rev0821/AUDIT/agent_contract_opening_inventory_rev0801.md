# Agent contract opening inventory (rev0801)

## Scope
This witness records the rev0801 opening-surface hardening that makes `AGENTS.md` a parsed part of the governed restart surface rather than a file-presence-only derivative note.

## Checked surfaces
- `scripts/validate_opening_surface.py` now validates `OPENING_CONTRACT.json` and `OPENING_SURFACE_CONFORMANCE.json` against their schemas.
- `OPENING_SURFACE_CONFORMANCE.json` now owns `agents_read_first_sequence` and `agents_command_posture_must_reference`.
- `AGENTS.md` now names `ARCHIVE_INDEX.md` in its read-first list and must match the conformance sequence exactly.
- `scripts/validate_cross_references.py` resolves the new agent read-first path list as governed references.

## Guardrail
This pass does not promote `AGENTS.md` to canon. It remains a compact derivative operating contract checked by the opening/reentry surface.
