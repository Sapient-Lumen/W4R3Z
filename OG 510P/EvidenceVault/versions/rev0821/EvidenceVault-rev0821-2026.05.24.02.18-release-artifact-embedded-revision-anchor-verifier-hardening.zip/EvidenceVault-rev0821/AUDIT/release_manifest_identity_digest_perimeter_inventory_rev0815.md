# Release-manifest identity digest perimeter inventory rev0815

## Scope
This witness records the current release-manifest identity digest perimeter hardening pass.

## Files hardened
- `RELEASE_MANIFEST.json`
- `schemas/release_manifest.schema.json`
- `scripts/validate_archive_identity.py`
- `scripts/rebuild_indexes.py`
- `scripts/package_release.py`
- `scripts/validate_validation_index.py`
- `scripts/validate_ro_crate_metadata.py`
- `ro-crate-metadata.json`
- `RO_CRATE_PROFILE.md`

## Validation wiring
- `make identity-check`
- `python3 scripts/validate_archive_identity.py`
- `make ro-crate-check`
- `python3 scripts/validate_ro_crate_metadata.py`
- `scripts/rebuild_indexes.py`
- `scripts/package_release.py`
- `make audit-witness-check`
- `scripts/validate_audit_witnesses.py`

## Boundary
The pass extends internal named-bundle identity coverage through an acyclic perimeter. It does not widen the public payload, alter queue state, or change canonical paper/source payloads.

## Command-runner sequence contract companion hardening

The same revision also introduced `COMMAND_RUNNER_SEQUENCE.json`, `COMMAND_RUNNER_SEQUENCE.md`, and `schemas/command_runner_sequence.schema.json` so composite runner order is governed by a single schema-checked contract. `scripts/validate_command_runners.py` enforces exact Markdown rendering, runner consumption, publish-audit boundedness, and package-final/full-gate equivalence before package emission.
