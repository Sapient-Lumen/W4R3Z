# Release manifest inclusion fence inventory (rev0807)

## Scope
This witness records the rev0807 hardening that makes `RELEASE_MANIFEST.json` `included_roots` an enforced bundle-scope fence rather than a descriptive list beside the actual packaged tree.

## Finding
The named packager intentionally emits every checked regular file under the revision root, but `RELEASE_MANIFEST.json` did not cover every shipped path in `included_roots`: root PDF mirrors and legacy render directories were present in the bundle while absent from that operator-facing scope list.

## Repair
- `RELEASE_MANIFEST.json` now names the root PDF mirrors and legacy render directories that were already shipped as part of the archive.
- `scripts/validate_archive_identity.py` now fails when any shipped regular file is not covered by an `included_roots` entry, while still checking that every listed entry exists.
- `scripts/package_release.py` now runs the same inclusion-fence check after release-manifest refresh and again immediately before ZIP emission.
- `scripts/validate_command_runners.py`, `VALIDATION_INDEX.*`, `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `CURRENT_FRONTIER.*`, `REVISION_ANCHORS.json`, and `publishing/CANONICAL_POLICY.json` now describe and validate the release-manifest inclusion fence.

## Guardrail
This pass changes bundle-scope metadata and release-path validation only. It does not change canonical paper/source payloads, public-release decisions, queue state, historical audit labels, or the stable `published/` surface.
