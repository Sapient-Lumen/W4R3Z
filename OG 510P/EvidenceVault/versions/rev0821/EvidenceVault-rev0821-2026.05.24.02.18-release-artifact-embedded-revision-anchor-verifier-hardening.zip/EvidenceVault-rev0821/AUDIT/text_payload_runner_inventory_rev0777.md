# Text-payload and runner inventory — rev0777

This audit witness records the rev0777 hygiene pass over non-JSON text payloads and long command runners.

## Findings

- Added `scripts/validate_text_payloads.py` for YAML, JSONL, CSV, Python syntax, UTF-8 text-like payloads, and zero-byte governed-file absence.
- Removed three zero-byte retained placeholders that did not carry governed evidence:
  - `sources/ocf_llm/examples/err_test.txt`
  - `sources/ocf_llm/examples/out_test.txt`
  - `sources/ocf_llm/tools/_perm_test`
- Made `VALIDATION_INDEX.json` composite target coverage duplicate-free while allowing executable runners to repeat refresh steps where needed.
- Converted `scripts/gate.py` and `scripts/publish_audit.py` to explicit runpy sequencing so the shipped commands execute each script path as a command surface rather than silently relying on importable `main()` functions.
- Kept `scripts/package_release.py` final validation explicit through script-path execution so validators without importable `main()` functions still run before ZIP emission.

## Scope

This audit does not promote text payloads to canon. It records that non-JSON payload formats are now governed by validation rather than only by outer archive checksums.
