# Release artifact verifier inventory — rev0816

## Scope

rev0816 adds a detached release-artifact verifier for emitted EvidenceVault ZIP bundles and their SHA-256 sidecars. The verifier reads the ZIP bytes directly, checks portable ZIP metadata, replays the embedded `RELEASE_MANIFEST.json` and `MANIFEST.sha256`, and confirms the sidecar digest.

## Checked surfaces

- `scripts/verify_release_artifact.py`
- `scripts/package_release.py`
- `scripts/rebuild_indexes.py`
- `scripts/validate_command_runners.py`
- `scripts/validate_archive_identity.py`
- `RELEASE_MANIFEST.json`
- `schemas/release_manifest.schema.json`
- `VALIDATION_INDEX.json`
- `CONTROL_SURFACES.json`
- `LIFECYCLE_GATES.json`
- `CONTEXT_PACK.json`
- `CLAIM_OBLIGATION_MAP.json`
- `publishing/CANONICAL_POLICY.json`

## Artifact-boundary obligations

The emitted bundle must have a matching sidecar, a single root directory, lexicographic member order, no duplicate or directory entries, normalized ZIP timestamps and file modes, no ZIP extra fields, a matching embedded release manifest, and a complete embedded `MANIFEST.sha256` that covers every bundled file except the manifest itself.

## Negative regression posture

A corrupted `.zip.sha256` sidecar or a ZIP whose embedded manifest/inventory no longer matches its bytes must fail `scripts/verify_release_artifact.py` before external acceptance.
