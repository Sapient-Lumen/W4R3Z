# Preflight shell-wrapper inventory (rev0804)

## Scope
This witness records the rev0804 hardening that makes `scripts/validate_command_runners.py` inspect the shell preflight wrapper, not only the Python composite runners.

## Finding
`scripts/publish_preflight.sh` owned release-facing promises about required surfaces, full-gate execution, transient-artifact refusal, and final `MANIFEST.sha256` verification, but runner validation previously focused on `gate.py`, `publish_audit.py`, and `package_release.py`. A stale shell wrapper could therefore drift while the subprocess-isolated Python runners still validated.

## Repair
- `scripts/validate_command_runners.py` now validates `scripts/publish_preflight.sh` for strict shell mode, revision-root binding, explicit `python3 scripts/gate.py` execution, required file/directory sentinels, transient-artifact refusal, and final `sha256sum -c MANIFEST.sha256` verification.
- `scripts/publish_preflight.sh` now includes itself, the gate/publish-audit runners, `MANIFEST.sha256`, and `INDEX/files.*` in its required-file preflight set, and treats `schemas/` as a required directory.
- `VALIDATION_INDEX.*`, `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `CURRENT_FRONTIER.*`, `REVISION_ANCHORS.json`, and `publishing/CANONICAL_POLICY.json` now describe the preflight shell-wrapper validation guard.

## Guardrail
This pass changes preflight wrapper validation and release/revision metadata only. It does not change canonical paper/source payloads, public-release decisions, queue state, historical audit labels, or the stable `published/` surface.
