# Payload-format and ZIP-container metadata hardening — rev0778

This audit witness records the rev0778 pass over payload formats that were previously protected by archive-wide hashes but not by local structure checks.

## Gap closed

The rev0777 gate proved JSON/schema coherence, non-JSON text hygiene, scoped asset indexes, canonical papers, and embedded archive/repro-pack payload digests.  It did not separately prove minimal structure for shipped PDFs, PNG render witnesses, JSON-LD, SD-JWT examples, or small residual source/evidence formats such as DOT, Lean, Rego, PCG, and toy binary stubs.  Package-release also verified payload membership and hashes, but not the ZIP container metadata contract itself.

## Repair

- Added `scripts/validate_payload_formats.py` and `make payload-format-check`.
- The new validator checks PDF headers/EOF markers, PNG signatures/chunk CRCs/IEND termination, JSON-LD object parseability, compact SD-JWT header/payload/disclosure decoding, and UTF-8/NUL hygiene for residual payload formats.
- Wired payload-format validation into `make gate`, `make publish-audit`, `make preflight`, `make package-release`, lifecycle gates, control surfaces, revision anchors, validation inventory, and publishing policy.
- Changed `scripts/package_release.py` from stored ZIP entries to deterministic deflated entries and made package self-verification enforce fixed timestamps, compression method, empty extra metadata, empty ZIP comment, safe paths, member ordering, file modes, embedded `RELEASE_MANIFEST.json`, and embedded `MANIFEST.sha256` digests.

## Local result before packaging

`python3 scripts/validate_payload_formats.py` reported 294 PDFs, 48 PNGs, 1 JSON-LD file, 5 SD-JWT files, and 9 residual UTF-8 payloads validated.
