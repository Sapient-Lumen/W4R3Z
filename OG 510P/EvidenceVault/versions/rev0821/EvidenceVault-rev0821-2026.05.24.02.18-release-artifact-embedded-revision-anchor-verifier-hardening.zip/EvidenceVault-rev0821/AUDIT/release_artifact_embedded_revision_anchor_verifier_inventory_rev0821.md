# Release-artifact embedded revision-anchor verifier inventory — rev0821

## Scope

Records the rev0821 hardening pass that extends `scripts/verify_release_artifact.py` so emitted ZIP artifacts replay embedded `REVISION_ANCHORS.json` semantics from artifact bytes rather than only trusting the live checkout validator or the release-manifest byte digest.

## Added verifier obligations

- `REVISION_ANCHORS.json current_revision` must agree with embedded `REVISION_RECEIPT.json`, embedded `RELEASE_MANIFEST.json`, the ZIP root prefix, and the artifact filename.
- Every `anchored_surfaces[]` path must be safe, present in the ZIP, unique, and backed by non-empty `required_pairs`.
- Every anchored required-pair pointer must resolve against the corresponding embedded JSON surface and equal the declared value.
- Required anchor paths for receipt, manifest, archive index, validation index, public status, claim map, toolchain lock, command sequence, historical anomalies, crypto fixture index, and RO-Crate metadata must remain present.
- `REVISION_ANCHORS.json validators` must exactly mirror embedded `VALIDATION_INDEX.json` validate_*.py scripts and every listed validator must exist in the ZIP.

## Regression posture

A self-consistent artifact mutation that refreshes `.zip.sha256`, `MANIFEST.sha256`, `INDEX/files.*`, release-manifest identity digests, and RO-Crate digests must still fail if embedded `REVISION_ANCHORS.json` lies about an anchored required pair or validator inventory.

## Wiring

The hardening is wired through `scripts/verify_release_artifact.py`, `scripts/validate_command_runners.py`, `VALIDATION_INDEX.*`, `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `CONTEXT_PACK.json`, `CURRENT_FRONTIER.*`, `CLAIM_OBLIGATION_MAP.*`, `PUBLIC_STATUS.*`, `REVISION_ANCHORS.json`, `ARCHIVE_INDEX.*`, `CHANGELOG.md`, and `AUDIT/README.md`.
