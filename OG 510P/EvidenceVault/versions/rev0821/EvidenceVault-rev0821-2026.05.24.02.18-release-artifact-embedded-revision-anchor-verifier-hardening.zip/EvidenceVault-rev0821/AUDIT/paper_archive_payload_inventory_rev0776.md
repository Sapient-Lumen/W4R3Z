# Paper/extraction-map and embedded-archive payload repair — rev0776

This audit note records the two silent-consistency gaps closed in rev0776.

## Gap 1 — extraction-map path pointers

`papers/EXTRACTION_MAP.json` carried present-state provenance entries for `sources/streamfold/`, `sources/zkrtp_v2/`, and `sources/zkrtp_portfolio/` even though those families are represented in this compressed archive by curated artifact/cert paths and legacy renders rather than retained `sources/` roots.

The repair keeps retained source roots as `sources/...` paths where they really are shipped, and rewrites non-retained StreamFold / zk-RTP provenance pointers to the actual shipped representation paths under `artifacts/curated/`, `certs/curated/`, and `renders/legacy_pdfs/`.

The new `scripts/validate_paper_series.py` check now verifies:

- the canonical five-paper TeX set,
- the `papers/EXTRACTION_MAP.json` key set and path-pointer existence,
- root-level PDF mirrors against `papers/*.pdf` by byte size and SHA-256, and
- absence of transient TeX build byproducts under `papers/`.

## Gap 2 — repro-pack payload manifests inside embedded archives

The archive-wide manifest and scoped artifact index correctly hashed the shipped files, but one embedded repro-pack manifest was stale:

- `artifacts/repro_packs/acceptance_repro_pack/acceptance_min_repro_kit_manifest_example.json`
- `artifacts/repro_packs/original/acceptance_repro_pack.tar.gz`

The stale row was for `policy_selection_witness_example.json`; the shipped artifact bytes were 14,111 bytes with SHA-256 `643c3d40569a181c0e9940d0a65ead61151133ee4c09c72c8bfdb3cdfa0a764e`, while the manifest row still carried the older 13,524-byte digest.

The repair updates both the extracted repro-pack manifest and the paired original `.tar.gz` manifest, then adds `scripts/validate_embedded_archives.py` to check:

- safe member paths in shipped ZIP and `.tar.gz` files,
- no duplicate archive members,
- public-release ZIP membership and per-file digests against its `.bundle.json`,
- repro-pack manifest coverage, member sizes, SHA-256 rows, and totals, and
- extracted repro-pack directories against the same manifest rules.

Both new checks are wired into `make gate`, `make publish-audit`, `make preflight`, and `make package-release`.
