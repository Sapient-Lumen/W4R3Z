# Crypto-envelope and statement-suffix inventory — rev0781

## Scope

This witness records the rev0781 pass that made cryptographic envelope/key-material structure a governed shipping check.
It is an audit witness, not a canonical architecture statement.

## Finding

The archive already validated JSON parseability, residual payload formats, scoped asset indexes, embedded archives, and provenance/absence ledgers, but it did not separately enforce the distinction between:

- DSSE envelopes named `*.dsse.json`,
- raw in-toto Statement payloads, and
- PEM key material retained as public verification material.

That gap let one raw in-toto Statement ship under a DSSE suffix:

- `certs/curated/zkrtp_v2/attestations/rtp_clauseD_contract_example.dsse.json`

The file was syntactically valid JSON, but it had `_type: https://in-toto.io/Statement/v1` at the top level instead of DSSE envelope fields (`payload`, `payloadType`, and `signatures`).

## Repair

The raw statement was renamed to:

- `certs/curated/zkrtp_v2/attestations/rtp_clauseD_contract_example.statement.json`

The scoped certificate index builder now recognizes `.statement.json` as a distinct kind, so the cert index no longer classifies the file as an opaque JSON payload after refresh.

## New governed check

`scripts/validate_crypto_envelopes.py` was added as `make crypto-check`.
The validator checks:

- shipped `.pem` files are parseable public keys and do not contain private-key material,
- every top-level `*.dsse.json` file is an actual DSSE envelope,
- DSSE payloads and signatures are locally decodable as base64/base64url,
- top-level shipped DSSE signatures decode to 64-byte Ed25519-sized signatures,
- JSON DSSE payloads decode as JSON when their payload type advertises JSON,
- raw in-toto Statement objects keep statement-style suffixes instead of masquerading as DSSE envelopes.

The check remains structural rather than cryptographic-verification authoritative because the shipped corpus intentionally includes conformance and negative-test signatures.

## Wiring

The new validator is wired into:

- `make gate`,
- `make publish-audit`,
- `publish_preflight.sh`,
- `make package-release`,
- `VALIDATION_INDEX.*`,
- `CONTROL_SURFACES.json`,
- `LIFECYCLE_GATES.json`,
- `REVISION_ANCHORS.json`,
- `publishing/CANONICAL_POLICY.json`.
