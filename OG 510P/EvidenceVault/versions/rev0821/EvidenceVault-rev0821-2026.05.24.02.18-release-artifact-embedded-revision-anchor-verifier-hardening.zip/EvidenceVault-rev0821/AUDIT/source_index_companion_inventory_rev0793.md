# Source-index companion inventory — rev0793

This witness records the rev0793 bounded hardening pass that made the retained-source companion surface exact rather than relying on substring checks in `SOURCE_INDEX.md`.

## Governed validator
- `scripts/validate_source_index.py`
- `make source-check`

## Scope checked
The hardened source-index validator now proves that:
- `SOURCE_INDEX.json` validates against `schemas/source_index.schema.json`;
- `SOURCE_INDEX.json` exactly equals the current output of `scripts/build_source_index.py`;
- `SOURCE_INDEX.md` exactly equals `render_markdown(SOURCE_INDEX.json)` with a single final newline;
- retained source-root file counts, key-subtree counts, paper consumers, companion paths, and non-root represented families are still path-resolved and revision-aligned; and
- source-index wiring remains visible through validation, lifecycle, control, context, policy, release-manifest, and revision-anchor surfaces.

## Non-goals
This pass does not add a new Make target, does not widen `published/`, does not rewrite historical audit witnesses, and does not change canonical paper/source payload semantics. It tightens the existing `source-check` lane so the human and machine retained-source companions cannot silently drift.
