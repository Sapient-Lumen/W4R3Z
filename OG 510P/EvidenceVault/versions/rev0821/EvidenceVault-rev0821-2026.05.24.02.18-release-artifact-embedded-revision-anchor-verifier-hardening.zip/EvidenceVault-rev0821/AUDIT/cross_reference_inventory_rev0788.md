# Cross-reference inventory — rev0788

## Scope

This witness records the rev0788 pass that made machine-readable cross-reference/path resolution a governed release check.

## What changed

- Added `scripts/validate_cross_references.py` to collect explicit path references from restart, control, lifecycle, frontier, validation, revision-anchor, release-manifest, revision-receipt, ADR/RFC, assimilation, and canonical-policy machine surfaces.
- The validator rejects absolute paths, parent traversal, backslash paths, and missing shipped files/directories.
- The only intentional non-root output is the current named package ZIP, because `scripts/package_release.py` writes that bundle beside the archive root rather than inside it.
- Wired the validator into `make cross-reference-check`, `make gate`, `make publish-audit`, preflight, package final validation, validation inventory, lifecycle gates, control surfaces, revision anchors, context pack, and canonical policy.

## Boundary

This is not a full prose link checker and does not alter canonical paper or publishing ownership.  It governs operator-facing machine-readable path references whose drift could make a cold-open or release pass misleading.
