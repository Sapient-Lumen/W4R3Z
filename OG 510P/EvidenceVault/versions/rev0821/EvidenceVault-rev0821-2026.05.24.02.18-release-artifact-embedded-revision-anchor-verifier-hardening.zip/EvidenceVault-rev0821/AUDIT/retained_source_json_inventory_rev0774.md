# Retained-source JSON inventory repair — rev0774

This audit note records a suffix-hygiene repair made during the rev0774 maintenance pass.
The existing gate covered governed root metadata and, after the first hardening pass, archive manifests and indexes.
It still did not parse every retained-source file carrying a `.json` suffix.
A whole-tree parse audit found five retained-source paths whose suffix said JSON while their contents were YAML or empty placeholders.

## Repairs

- Removed two zero-byte duplicate trace placeholders that already had non-empty YAML companions:
  - `sources/ocf_llm/examples/drc_toy_trace.json`
  - `sources/ocf_llm/examples/resolver_trace_rbc_compiler_demo_v3.json`
- Renamed two YAML-formatted resolver traces so their suffix matches their content, and updated the generator that writes them:
  - `sources/ocf_llm/examples/ndc_noop_update_v175/resolver_trace_noop.json` → `sources/ocf_llm/examples/ndc_noop_update_v175/resolver_trace_noop.yaml`
  - `sources/ocf_llm/examples/ndc_noop_update_v175/resolver_trace_real.json` → `sources/ocf_llm/examples/ndc_noop_update_v175/resolver_trace_real.yaml`
  - `sources/ocf_llm/tools/ndc_noop_update_demo_v175.py`
- Preserved the older YAML-formatted fail-closed trace under a YAML suffix because `trace_good.yaml` already names the current good trace:
  - `sources/ocf_llm/examples/verify_dof_attack_v222/trace_good.json` → `sources/ocf_llm/examples/verify_dof_attack_v222/trace_good_legacy_failclosed.yaml`

## New guard

`make json-check` now runs `scripts/validate_json_inventory.py`.
The validator parses every shipped `.json` file, checks every bundled JSON Schema file under `schemas/` except the registry itself, and confirms that `schemas/registry.json` targets present schema files.
The check is part of `make gate`, `make publish-audit`, `make preflight`, and `make package-release`.
