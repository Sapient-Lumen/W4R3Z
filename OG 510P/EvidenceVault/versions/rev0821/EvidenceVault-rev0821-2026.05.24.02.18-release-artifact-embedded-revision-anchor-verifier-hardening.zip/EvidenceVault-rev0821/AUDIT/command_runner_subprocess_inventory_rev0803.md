# Command-runner subprocess inventory (rev0803)

## Scope
This witness records the rev0803 hardening that makes `scripts/gate.py`, `scripts/publish_audit.py`, and `scripts/package_release.py` execute composite child checks in fresh subprocesses instead of sharing one long-lived Python interpreter.

## Finding
The validation index already described `scripts/gate.py` as running explicit script paths in subprocesses, but the shipped runner still used `runpy.run_path`. A heavy archive scan could therefore retain imports, globals, file handles, or memory into the next validator in the same process, and a command could fail for runner-resource reasons even when each child validator passed independently.

## Repair
- `scripts/gate.py` now invokes each sequence entry with `subprocess.run([sys.executable, str(script)], cwd=ROOT, env=env, check=True)`.
- `scripts/publish_audit.py` uses the same subprocess runner while preserving its bounded post-gate release-materialization sequence.
- `scripts/package_release.py` now executes its final validators through subprocesses instead of `runpy.run_path`.
- `scripts/validate_command_runners.py` now rejects `runpy`-backed composite runners and checks policy, validation-index, lifecycle, context-pack, and revision-anchor wiring for the runner lane.

## Guardrail
This pass changes composite command execution and runner validation only. It does not change canonical paper/source payloads, public-release decisions, queue state, historical audit labels, or the stable `published/` surface.
