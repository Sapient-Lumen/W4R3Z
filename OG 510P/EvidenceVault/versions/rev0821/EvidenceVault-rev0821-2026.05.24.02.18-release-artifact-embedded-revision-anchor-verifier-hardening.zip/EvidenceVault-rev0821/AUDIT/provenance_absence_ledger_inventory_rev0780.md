# rev0780 provenance and absence-ledger inventory

This audit note records the rev0780 pass over shipped upstream/provenance absence ledgers.
The pass did **not** require the external upstream ZIP payloads, which remain intentionally out-of-band and digest-addressed by `UPSTREAM_INPUTS.sha256`.
Instead, it checked the self-contained ledgers that ship inside the archive.

## Findings repaired

- `REDACTIONS.paths` was missing one secret-class omission already recorded in `AUDIT/UPSTREAM_OMISSIONS.csv`:
  - `sources/zkrtp_v2/audit/testkeys/govrec_ed25519_priv.pem`
- `PRUNED_TRANSIENT.paths` still listed two local path-index README files that are intentionally present in the shipped archive and are not pruned/transient payloads:
  - `artifacts/curated/ctg/README.md`
  - `artifacts/curated/pact/replay_pack/README.md`

## New guard

`validate_provenance_ledgers.py` now checks:

- `UPSTREAM_INPUTS.sha256` row format, uniqueness, and linkage to `UPSTREAM_COVERAGE.md`;
- that upstream ZIP payloads named by the digest ledger are not embedded in the archive root;
- `AUDIT/UPSTREAM_OMISSIONS.csv` header, duplicate rows, safe paths, project names, and governed reason classes;
- that `AUDIT/UPSTREAM_DIFF_REPORT.md` omitted-count and reason-count summaries match the CSV;
- that `REDACTIONS.paths` exactly equals the set of `secret`-reason omissions mapped back into retained archive paths;
- that every redacted and pruned/transient path is absent from the shipped tree.

## Current counts

- Upstream inputs: 7
- Upstream omission rows: 645
- Redacted paths: 35
- Pruned/transient paths: 149

## Command

```bash
python3 scripts/validate_provenance_ledgers.py
```

Expected result:

```text
provenance-ledgers-validate: OK (7 upstream inputs, 645 omission rows, 35 redactions, 149 pruned/transient paths)
```
