# Text-surface LF policy inventory — rev0783

This audit witness records the pass that made generated and governing text-surface formatting explicit.

## Finding

The archive already validated broad text payload parseability, but it did not separately prove that generated and operator-facing text surfaces used normalized UTF-8 with LF line endings.  The gap was concrete:

- `INDEX/files.csv` used CRLF rows from Python `csv.DictWriter` defaults.
- `artifacts/ARTIFACTS_INDEX.csv` used CRLF rows from Python `csv.DictWriter` defaults.
- `certs/CERTS_INDEX.csv` used CRLF rows from Python `csv.DictWriter` defaults.
- `release_queue/hold/2026-03-20-full-archive-mirror-not-public.md` carried trailing whitespace on one line.
- `SOURCE_INDEX.md` could be regenerated with a doubled terminal blank line because `render_markdown()` already ended with an empty row before callers appended another newline.

## Repair

- Added `scripts/validate_text_surface_policy.py` and `make text-surface-check`.
- Taught generated CSV writers to use `lineterminator="\n"`.
- Made source-index Markdown writers trim terminal blank rows before appending the final newline.
- Normalized the release-queue hold note and one carried audit witness to single-LF text endings.
- Wired the validator into gate, publish-audit, preflight, package-release, lifecycle gates, control surfaces, revision anchors, validation inventory, archive identity, publishing validation, and canonical policy.

## Validator boundary

The validator intentionally covers governed/operator/generated text surfaces, not every retained upstream source file.  Retained upstream payloads may preserve upstream whitespace or final-newline conventions; the policy guard exists to keep EvidenceVault's own control and generated surfaces portable, diff-stable, and deterministic.
