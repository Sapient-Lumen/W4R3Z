# Revision-anchor validator inventory (rev0802)

## Scope
This witness records the rev0802 hardening that makes `REVISION_ANCHORS.json` validator inventory derive from the active `VALIDATION_INDEX.json` `scripts/validate_*.py` surface instead of a hand-maintained historical subset.

## Checked surfaces
- `scripts/validate_revision_anchors.py` now computes the expected validator list from `VALIDATION_INDEX.json` and requires `REVISION_ANCHORS.json` `validators` to match it exactly, including order.
- `REVISION_ANCHORS.json` now anchors all active validation scripts referenced by `VALIDATION_INDEX.json`, including ADR/RFC/source/frontier/assimilation/opening/control/publishing validators that were absent from the older subset.
- `publishing/CANONICAL_POLICY.json` records `explicit_revision_anchor_validator_inventory_validation` as the policy guard for the tightened anchor inventory.

## Guardrail
This pass changes validator-inventory governance only. It does not change canonical paper/source payloads, release decisions, public-surface scope, or historical audit labels.
