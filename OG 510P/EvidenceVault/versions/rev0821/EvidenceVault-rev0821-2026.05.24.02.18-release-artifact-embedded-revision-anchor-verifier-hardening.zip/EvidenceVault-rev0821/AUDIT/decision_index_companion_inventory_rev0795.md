# Decision-index companion inventory — rev0795

This witness records the rev0795 bounded hardening pass that made the ADR and RFC decision-memory Markdown companions exact renderer outputs of their JSON indexes instead of relying on substring checks.

## Scope
- `ADR_INDEX.md` now has to exactly mirror `ADR_INDEX.json` through `scripts/validate_adrs.py`.
- `RFC_INDEX.md` now has to exactly mirror `RFC_INDEX.json` through `scripts/validate_rfcs.py`.
- The RFC validator still checks assimilation-ledger origin records and related-RFC backlinks, so unresolved proposal memory remains subordinate to assimilation and ADR records.

## Validation wiring
- `make adr-check` remains the bounded public command for standing decision-memory validation.
- `make rfc-check` remains the bounded public command for unresolved proposal-memory validation.
- `VALIDATION_INDEX.json`, `CONTEXT_PACK.json`, `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `publishing/CANONICAL_POLICY.json`, and `RELEASE_MANIFEST.json` now name the exact companion surfaces that these existing validators protect.
- `AUDIT/README.md` and `scripts/validate_audit_witnesses.py` retain this file as the current-revision audit witness.

## Boundary
No ADR/RFC record semantics were changed.  The update is a companion-surface and wiring hardening: future edits must keep human Markdown and machine JSON decision indexes aligned before a named package is accepted.
