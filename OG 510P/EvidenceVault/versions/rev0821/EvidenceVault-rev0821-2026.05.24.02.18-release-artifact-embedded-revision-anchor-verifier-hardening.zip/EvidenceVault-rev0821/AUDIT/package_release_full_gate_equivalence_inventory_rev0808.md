# Package-release full-gate equivalence inventory (rev0808)

## Scope
This witness records the rev0808 hardening that makes direct `scripts/package_release.py` package-final validation full-gate equivalent before a named archive ZIP can be emitted.

## Finding
The direct packager already refreshed generated package inputs, enforced the release-manifest inclusion fence, refused transient artifacts, and ran a bounded set of final validators. That bounded set did not exactly match `scripts/gate.py`, so a tree with a failure in a gate-only validator could still reach ZIP emission when an operator invoked `make package-release` directly.

## Repair
- `scripts/package_release.py` now runs the full `scripts/gate.py` sequence in its package-final validator loop after package refresh and before ZIP emission.
- `scripts/validate_command_runners.py` now treats the package-final validator list as equivalent to the gate sequence and rejects drift.
- `publishing/CANONICAL_POLICY.json`, `VALIDATION_INDEX.*`, `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `CURRENT_FRONTIER.*`, `REVISION_ANCHORS.json`, and `ARCHIVE_INDEX.*` now describe the full-gate package-emission guard.

## Guardrail
This pass changes release-path validation and its governing metadata only. It does not widen `published/`, change public-release decisions, alter queue state, normalize historical audit labels, or modify canonical paper/source payloads.
