# Context-pack anchor inventory — rev0784

This witness records the rev0784 pass that made `CONTEXT_PACK.json` a governed revision-bearing operator restart surface instead of an implicitly trusted note.

## Finding

A deep revision-bearing surface audit found `CONTEXT_PACK.json` still reported `rev0782` while the packaged archive had advanced through `rev0783`. The existing opening-surface validator checked the context-pack read order, but not its current revision, command hints, schema, or key-machine-surface path coherence.

## Repair

- Updated `CONTEXT_PACK.json` to `rev0784`.
- Added `schemas/context_pack.schema.json`.
- Added `scripts/validate_context_pack.py` and `make context-check`.
- Added `context_pack_sha256` to release-manifest identity digests.
- Wired context-pack validation through gate, publish-audit, preflight, package-release, revision anchors, validation inventory, control surfaces, lifecycle gates, archive identity, and canonical policy.

## Guardrail

Future stale context-pack revision, missing command hint, missing key-machine path, missing validator/schema policy pointer, or release-manifest context digest omission is now a release-gate failure.
