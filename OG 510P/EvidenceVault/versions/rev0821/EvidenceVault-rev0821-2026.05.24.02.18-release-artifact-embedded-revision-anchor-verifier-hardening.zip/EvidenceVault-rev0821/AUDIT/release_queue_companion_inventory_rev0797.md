# Release queue companion inventory — rev0797

This retained audit witness records the rev0797 publishing-lane hardening.  The pass did not publish new material, change public-release decisions, or widen `published/`; it tightened queue-item companion drift detection under the existing `make publishing-check` lane.

## Scope
- Governed queue-item `.md` / `.json` pairs under `release_queue/candidates/`, `release_queue/hold/`, `release_queue/published_ready/`, and `release_queue/published/`.
- Kept release decisions and public-release notes historical; this pass only makes queue-item companions exact renderer outputs of their JSON records.
- Left the full-archive public mirror on hold and did not change public-release artifact contents.

## Validator change
- `scripts/validate_publishing.py` now renders each queue item from its JSON record and fails when the adjacent Markdown companion drifts.
- The check covers field order, empty decision/public-release fields, tracked-path order, summary text, and next-action text.
- The validator continues to rebuild/compare queue index records, release decisions, public release ledgers, latest pointers, public snapshots, and public-release artifact manifests.

## Tooling change
- `scripts/scaffold_queue_item.py` now writes queue-item Markdown through the same canonical renderer shape used by the validator.
- `scripts/transition_queue_item.py` now regenerates the destination Markdown companion from the transitioned JSON record instead of copying and patching selected lines from the prior state.
- Existing queue records remain semantically unchanged; both shipped queue-item companions already match the canonical renderer.

## Release-path checks
- `python3 scripts/validate_publishing.py`
- `make publishing-check`
- `python3 scripts/validate_audit_witnesses.py`
- `make audit-witness-check`
- `make gate`
- `make publish-audit`
- `bash scripts/publish_preflight.sh`
- `python3 scripts/package_release.py`

## Non-changes
- No public release record was added or modified semantically.
- No release decision was relabeled.
- No canonical paper/source payload was changed.
- No widened public mirror was introduced.
