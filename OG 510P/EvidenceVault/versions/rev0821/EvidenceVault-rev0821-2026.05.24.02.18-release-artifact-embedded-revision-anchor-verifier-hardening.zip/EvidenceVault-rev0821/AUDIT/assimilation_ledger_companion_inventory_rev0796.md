# Assimilation-ledger companion inventory — rev0796

This witness records the rev0796 bounded hardening pass that made `ASSIMILATION_LEDGER.md` an exact renderer output of `ASSIMILATION_LEDGER.json` instead of relying only on ledger-record coherence checks and broad surface presence.

## Scope
- `ASSIMILATION_LEDGER.md` now has to exactly mirror `ASSIMILATION_LEDGER.json` through `scripts/validate_assimilation_ledger.py`.
- The renderer preserves record content and uses stable ledger ID order so adopted, rejected, and deferred comparison-memory records remain human-reviewable without rewriting their historical meaning.
- Existing related-RFC backlinks, landed-surface existence checks, revision-receipt updated-record checks, control/lifecycle/policy/context wiring, and schema validation remain in the same `make assimilation-check` lane.

## Validation wiring
- `make assimilation-check` remains the bounded public command for adopted/rejected/deferred comparison-memory validation.
- `VALIDATION_INDEX.json`, `VALIDATION_INDEX.md`, `CONTEXT_PACK.json`, `CURRENT_FRONTIER.*`, `publishing/CANONICAL_POLICY.json`, and the audit-witness inventory now name the exact companion hardening.
- `AUDIT/README.md` and `scripts/validate_audit_witnesses.py` retain this file as the current-revision audit witness.

## Boundary
No assimilation decision was adopted, rejected, deferred, or relabeled in this pass.  The update is a companion-surface hardening: future edits must keep the human Markdown and machine JSON assimilation ledger aligned before a named package is accepted.
