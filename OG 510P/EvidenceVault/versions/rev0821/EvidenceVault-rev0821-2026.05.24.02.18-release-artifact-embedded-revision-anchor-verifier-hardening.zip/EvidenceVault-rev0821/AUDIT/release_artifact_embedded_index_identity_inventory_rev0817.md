# Release-artifact embedded index and identity verifier inventory — rev0817

## Scope
Records the rev0817 hardening pass that extends `scripts/verify_release_artifact.py` beyond detached ZIP/sidecar and `MANIFEST.sha256` checks into embedded `INDEX/files.json`, `INDEX/files.csv`, and `RELEASE_MANIFEST.json` identity-digest replay from ZIP bytes.

## Material change
- Added stdlib-only embedded index replay for `INDEX/files.json` rows: path order, size, SHA-256, category, project, and extension are recomputed from the ZIP payload.
- Added embedded `INDEX/files.csv` mirror validation so the CSV companion cannot drift from the JSON inventory inside a self-consistent artifact.
- Added embedded release-manifest identity digest replay for the non-cyclic identity perimeter already governed by `RELEASE_MANIFEST.json`.
- Updated `scripts/validate_command_runners.py` so future removal of `validate_embedded_index`, `validate_embedded_identity_digests`, `IDENTITY_DIGEST_TARGETS`, or `INDEX_FIELDS` from the detached verifier is package-blocking.

## Validation posture
- `scripts/package_release.py` still emits the `.zip.sha256` sidecar and invokes `scripts/verify_release_artifact.py --require-sidecar` after deterministic ZIP writing.
- Negative regression mutates embedded `INDEX/files.json` semantics while refreshing `MANIFEST.sha256` and the sidecar; the detached verifier must still fail.
- Negative regression mutates `RELEASE_MANIFEST.json` identity_digests while refreshing `MANIFEST.sha256` and the sidecar; the detached verifier must still fail.

## Non-change
No canonical paper/source payloads, public-release decisions, release-queue state, or published payload scope were widened.
