# Filesystem path/mode policy inventory — rev0782

This witness records the rev0782 pass that made filesystem packaging hygiene a governed shipping check instead of an implicit side effect of ZIP packaging.

## Issue found

A mode audit of rev0781 found two regular files with executable bits while the rest of the script surface was shipped as non-executable regular files and invoked through explicit interpreters from `Makefile`, `scripts/gate.py`, `scripts/publish_audit.py`, `scripts/publish_preflight.sh`, and `scripts/package_release.py`:

- `scripts/validate_crypto_envelopes.py`
- `scripts/validate_provenance_ledgers.py`

The inconsistency did not affect byte digests or gate results, but it meant the portable ZIP metadata preserved avoidable executable-bit drift.

## Repair

- Normalized the leaked executable bits back to `0644`.
- Added `scripts/validate_filesystem_policy.py`.
- Added `make filesystem-check`.
- Wired the filesystem-policy validator into gate, publish-audit, preflight, package-release, lifecycle gates, control surfaces, validation inventory, revision anchors, archive identity, publishing policy, and the final package self-verification path.

## Guardrails now enforced

- every shipped path is a regular file, not a symlink or special file;
- every shipped regular file uses least-privilege mode `0644`;
- shipped path components are NFC-normalized and free of control characters, embedded separators, leading/trailing whitespace, trailing dots, Windows-reserved names, and Windows-unsafe characters;
- casefold and NFC+casefold path collisions are refused;
- transient platform/editor/bytecode/patch byproducts are refused;
- root-level archive artifacts are refused inside the archive tree;
- zero-byte files are refused by the filesystem policy as well as the text-payload validator.

## Boundary

This checker intentionally does not make scripts executable. The archive's command surface already invokes scripts through `python3` or `bash`, so the shipping policy is a least-privilege regular-file tree plus portable ZIP regular-file metadata.

## Runner hardening

The same pass exposed a publish-audit execution weakness: the composite runner reused one Python process for a long sequence with repeated JSON/text/schema validators, and the second JSON inventory pass could stall under constrained execution.  `scripts/gate.py`, `scripts/publish_audit.py`, and the final validator phase in `scripts/package_release.py` now invoke each explicit script path in a clean subprocess with `PYTHONDONTWRITEBYTECODE=1`.  The command order remains governed by the checked script lists, but import/global state no longer accumulates across repeated validator passes.
