# rev0779 ZIP extractability and public-bundle inventory

This audit note records the rev0779 follow-up to the rev0778 ZIP-container pass.

## Finding

The rev0778 package writer and public-release materializer encoded permission bits in ZIP external attributes but omitted the Unix regular-file type bits. Python's `zipfile` reader could extract the archive, and `unzip -t` could test it, but a normal system `unzip` extraction reported file-type ambiguity and failed while creating later paths.

The same metadata issue was present in the embedded public release ZIP under `published/releases/artifacts/`.

## Repair

- `scripts/package_release.py` now writes regular-file external attributes as `S_IFREG | mode`, sets Unix `create_system`, refuses symlinks/special files, and self-verifies that emitted ZIP members are marked as regular files.
- `scripts/materialize_public_release.py` now emits deterministic public-release ZIP members with regular-file type bits and rewrites bundles deterministically instead of trusting a stale existing artifact.
- `scripts/validate_embedded_archives.py` now checks embedded public-release ZIP member timestamps, compression, extra fields, Unix external-attribute provenance, regular-file type bits, modes, source-record freshness, snapshot digest coherence, and materialized payload freshness.
- `scripts/validate_manifest_index.py` now refuses symlinks and other unsupported non-regular filesystem entries in the archive tree.

## Public release bundle refresh

The existing embedded public release bundle was regenerated through the repaired materializer.

| Artifact | rev0778 SHA-256 | rev0779 SHA-256 |
| --- | --- | --- |
| `published/releases/artifacts/EV-PUB-2026-03-20-public-surface-bootstrap.zip` | `e01b9dac9684c9117645c5f28385d4c9aa03fbc59765e514a2a93550d089f05f` | `06f4a792ff8407ad3eabcfe9301d4c7dcd93728b14152d81d6f419c93e47aae8` |
| `published/releases/artifacts/EV-PUB-2026-03-20-public-surface-bootstrap.bundle.json` | `38896a0d45d91df9a058ac485d3c9de60b3ee9fb5e83953846a07510bfa1c8d2` | `4d080b25f433bbe01476b587ee7e736bd732e5e4d48b080608e078af5cc30151` |

## Expected proof path

`make gate`, `make publish-audit`, `make preflight`, and `make package-release` all transitively run the embedded-archive validator. The final package-release self-verifier checks the outer archive ZIP metadata directly, and the operator should also verify system-tool extractability with `unzip -q` on a fresh extraction before distributing the bundle.
