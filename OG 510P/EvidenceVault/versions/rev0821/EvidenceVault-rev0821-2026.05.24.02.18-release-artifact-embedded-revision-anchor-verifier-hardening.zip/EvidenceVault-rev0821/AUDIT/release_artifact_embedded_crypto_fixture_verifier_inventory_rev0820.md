# Release artifact embedded crypto fixture verifier inventory (rev0820)

This witness records the rev0820 hardening pass that makes the detached release-artifact verifier replay indexed positive/negative Ed25519 DSSE crypto fixture verification from emitted ZIP bytes.

## Boundary

The immediately previous release-artifact pass already replayed sidecar, portable ZIP metadata, embedded `MANIFEST.sha256`, `INDEX/files.*`, release-manifest identity digests, `included_roots`, and RO-Crate bridge semantics from artifact bytes. This pass adds the crypto fixture lane so the emitted artifact itself proves that `certs/CRYPTO_FIXTURE_INDEX.json`, its Markdown companion, public key material, positive DSSE fixture, and negative payload-tamper fixture remain coherent.

## Verification wiring

- Verifier: `scripts/verify_release_artifact.py`
- Runner guard: `scripts/validate_command_runners.py`
- Live crypto validator retained: `scripts/validate_crypto_envelopes.py`
- Fixture index: `certs/CRYPTO_FIXTURE_INDEX.json`
- Fixture companion: `certs/CRYPTO_FIXTURE_INDEX.md`
- Fixture key and DSSE envelopes: `certs/verification_fixtures/`

## Negative-regression expectation

A release artifact whose embedded crypto fixture index, DSSE payload, signature, public key, or index digest rows are made self-consistent at the `MANIFEST.sha256`, `INDEX/files.*`, and sidecar levels must still fail `scripts/verify_release_artifact.py` when a fixture expected to pass no longer verifies or a fixture expected to fail begins verifying.
