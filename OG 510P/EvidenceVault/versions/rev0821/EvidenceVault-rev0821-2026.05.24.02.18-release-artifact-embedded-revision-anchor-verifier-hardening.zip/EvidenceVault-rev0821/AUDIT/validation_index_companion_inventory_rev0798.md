# Validation index companion inventory — rev0798

This retained audit witness records the rev0798 validation-lane hardening. The pass does not change canonical paper/source payloads, public release state, queue decisions, or the size of `published/`; it tightens the human/machine assurance-map companion check inside the existing `make validation-check` lane.

## Scope
- Harden `scripts/validate_validation_index.py` so `VALIDATION_INDEX.md` must exactly equal `render_markdown(VALIDATION_INDEX.json)`.
- Keep `VALIDATION_INDEX.json` as the governing assurance inventory while making the Markdown recovery surface fully generated and checked.
- Preserve the existing `make validation-check` public target instead of adding another helper/root surface.

## Checks
- `python3 scripts/validate_validation_index.py`
- `make validation-check`
- `python3 scripts/validate_audit_witnesses.py`
- `make audit-witness-check`
- `make gate`
- `make publish-audit`
- `bash scripts/publish_preflight.sh`
- `python3 scripts/package_release.py`

## Non-changes
- No public-release decision changed.
- No canonical TeX/PDF paper payload changed.
- No retained upstream source payload was normalized.
- No historical audit witness labels were rewritten.
