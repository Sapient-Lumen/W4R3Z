# Current-frontier companion inventory — rev0794

This witness records the rev0794 bounded hardening pass that made the live frontier resume surface exact rather than relying on substring checks in `CURRENT_FRONTIER.md`.

## Governed validator
- `scripts/validate_current_frontier.py`
- `make frontier-check`

## Scope checked
The hardened current-frontier validator now proves that:
- `CURRENT_FRONTIER.json` validates against `schemas/current_frontier.schema.json`;
- `CURRENT_FRONTIER.json` carries the same revision and generated-at timestamp as `REVISION_RECEIPT.json`;
- `CURRENT_FRONTIER.json` names `scripts/validate_current_frontier.py` as its validator;
- `CURRENT_FRONTIER.md` exactly equals `render_markdown(CURRENT_FRONTIER.json)` with a single final newline;
- frontier lane IDs remain unique, at least one lane stays active, linked surfaces resolve, and RFC/ADR/assimilation drivers point at known records; and
- current-frontier wiring remains visible through opening, control, lifecycle, canonical policy, validation, cross-reference, changelog, and audit-witness surfaces.

## Non-goals
This pass does not promote frontier notes to canon, does not settle deferred RFCs, does not widen `published/`, does not rewrite historical audit witnesses, and does not change canonical paper/source payload semantics. It tightens the existing `frontier-check` lane so the human and machine current-frontier companions cannot silently drift.
