# Toolchain lock inventory — rev0811

## Scope
This witness records the bounded toolchain-lock hardening pass that introduced `TOOLCHAIN_LOCK.json`, `TOOLCHAIN_LOCK.md`, `schemas/toolchain_lock.schema.json`, and `scripts/validate_toolchain_lock.py` as governed replay surfaces.

## Inventory
- Added a schema-checked lock for Python runtime floor, required Python packages, required external commands, and deterministic ZIP package-policy constants.
- Wired `make toolchain-check` through `Makefile`, `scripts/gate.py`, `scripts/publish_audit.py`, `scripts/package_release.py`, `scripts/publish_preflight.sh`, `VALIDATION_INDEX.*`, `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `CONTEXT_PACK.json`, `CURRENT_FRONTIER.*`, `REVISION_ANCHORS.json`, and `publishing/CANONICAL_POLICY.json`.
- Kept observed package versions as replay witnesses while enforcing minimum-supported versions and exact package-policy constants.

## Acceptance
- `scripts/validate_toolchain_lock.py` must reject a missing required Python package or required external command.
- `scripts/validate_toolchain_lock.py` must reject drift between `TOOLCHAIN_LOCK.md` and `TOOLCHAIN_LOCK.json`.
- `scripts/validate_toolchain_lock.py` must reject drift between package ZIP constants in `TOOLCHAIN_LOCK.json` and `scripts/package_release.py`.
- Direct package release must run the full gate-equivalent sequence including `validate_toolchain_lock.py` before ZIP emission.
