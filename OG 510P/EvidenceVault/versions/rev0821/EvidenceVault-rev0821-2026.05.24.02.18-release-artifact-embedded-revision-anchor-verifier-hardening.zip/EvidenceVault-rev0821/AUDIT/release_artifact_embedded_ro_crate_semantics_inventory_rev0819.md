# Release artifact embedded RO-Crate semantics verifier inventory (rev0819)

## Scope

This witness records the rev0819 hardening pass that makes the detached release-artifact verifier replay the embedded RO-Crate-style metadata bridge from emitted ZIP bytes.

## Added or changed surfaces

- `scripts/verify_release_artifact.py` now includes `validate_embedded_ro_crate_metadata(...)` and checks embedded `ro-crate-metadata.json` descriptor/root shape, required `hasPart` ordering, digest-bearing file entities, self-referential inventory omissions, directory entities, and exact `RO_CRATE_PROFILE.md` rendering from ZIP bytes.
- `scripts/verify_release_artifact.py` now cross-checks embedded `REVISION_RECEIPT.json` against embedded `RELEASE_MANIFEST.json` before accepting the RO-Crate root version/date/identifier claims.
- `scripts/validate_command_runners.py` now guards the detached RO-Crate verifier snippets so future package-runner drift cannot silently remove the artifact-byte metadata replay lane.
- `VALIDATION_INDEX.*`, `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `CONTEXT_PACK.json`, `CLAIM_OBLIGATION_MAP.*`, `CURRENT_FRONTIER.*`, `PUBLIC_STATUS.*`, `TOOLCHAIN_LOCK.*`, `REVISION_ANCHORS.json`, `ARCHIVE_INDEX.*`, and `CHANGELOG.md` were refreshed to name the new artifact-byte RO-Crate semantics boundary.

## Negative regression

A mutated emitted ZIP that changes the embedded RO-Crate root version or a digest-bearing RO-Crate file entity while refreshing embedded `MANIFEST.sha256`, `INDEX/files.json`, `INDEX/files.csv`, and the `.zip.sha256` sidecar must fail `scripts/verify_release_artifact.py` with an embedded RO-Crate semantic or digest error.

## Non-changes

No canonical paper/source payloads, queue state, public-release decision, or `published/` payload scope were widened.
