# Changelog/history-anchor validation inventory — rev0789

## Purpose
This witness records the rev0789 bounded validation pass that made the current human revision history anchor (`CHANGELOG.md`) explicitly checked against the machine-readable release identity surfaces.

## What was added
- `scripts/validate_changelog.py`
- `make changelog-check`

## Governed assertions
The validator checks that:
- `RELEASE_MANIFEST.json`, `REVISION_RECEIPT.json`, `REVISION_ANCHORS.json`, and `publishing/CANONICAL_POLICY.json` all point at `CHANGELOG.md` as the current history anchor where applicable;
- `CHANGELOG.md` starts with `# Revision changelog` and uses UTF-8/LF newline discipline;
- the first revision heading matches the current revision and date;
- the second revision heading matches the previous revision;
- the current/recent release-lineage heading prefix is unique and strictly descending;
- the current changelog section contains substantive bullets and names only the current package bundle; and
- `ARCHIVE_INDEX.json` top bundle agrees with the current release manifest.

## Wired surfaces
The check is wired through:
- `Makefile`
- `scripts/gate.py`
- `scripts/publish_audit.py`
- `scripts/package_release.py`
- `scripts/publish_preflight.sh`
- `scripts/validate_command_runners.py`
- `VALIDATION_INDEX.json`
- `VALIDATION_INDEX.md`
- `CONTROL_SURFACES.json`
- `LIFECYCLE_GATES.json`
- `REVISION_ANCHORS.json`
- `CONTEXT_PACK.json`
- `publishing/CANONICAL_POLICY.json`

## Boundary
This is not a general prose link checker and does not try to validate every historical changelog sentence.
It protects the current release-recovery facts that future operators need most: current revision, current date, previous-revision adjacency, descending unique recent revision headings, and current named bundle identity.
