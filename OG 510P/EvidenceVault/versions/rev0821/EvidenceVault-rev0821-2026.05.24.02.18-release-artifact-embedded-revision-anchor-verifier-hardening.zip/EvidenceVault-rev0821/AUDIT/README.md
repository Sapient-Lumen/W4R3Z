# EvidenceVault audit surfaces

This directory and the neighboring audit/retention files are **retained audit witnesses**.
They explain how the shipped archive was assembled, pruned, deduplicated, and checked.
They are not architecture statements and they do not own release workflow.

- `AUDIT/HISTORICAL_ANOMALIES.json` and `AUDIT/HISTORICAL_ANOMALIES.md` — governed ledger/companion pair for carried-forward historical duplicate/order and audit-witness body-label exceptions.

## Scope
Use these files for questions like:
- which upstream trees were retained in full,
- which inputs were omitted, redacted, pruned, or deduplicated,
- which legacy renders remain canonical,
- and which audit batch originally established a carry-forward witness.

For architecture and reading order, use `SERIES.md`.
For publishing workflow, use `PUBLISHING.md`.

## Historical-label rule
Some retained audit files may preserve earlier audit-batch labels or headings (for example older `rev####` references inside file bodies) even when they are shipped in later revisions.
That is intentional when the underlying audit basis has not changed materially and the file is being carried forward as a witness rather than regenerated from scratch.

Do **not** normalize those historical labels just to make them “match the current revision” unless the underlying audit basis was actually rerun or the file is being substantively refreshed.
When the audit basis changes materially, update both the witness and `CHANGELOG.md`.

## Key audit/retention surfaces
- `AUDIT/UPSTREAM_DIFF_REPORT.md` — concise upstream retention/omission comparison.
- `AUDIT/UPSTREAM_OMISSIONS.csv` — machine-sortable omission list.
- `UPSTREAM.md` — retained upstream inputs and consolidation notes.
- `UPSTREAM_COVERAGE.md` — coverage/omission witness for the retained upstream set.
- `MIGRATION_AUDIT.md` — archive migration and carry-forward audit notes.
- `DEDUPE_REPORT.md` — exact-duplicate pruning / canonical-path witness.
- `PRUNED_TRANSIENT.paths` — retained record of removed transient outputs.
- `REDACTIONS.md` and `REDACTIONS.paths` — deliberate redaction policy and redacted path list.
- `AUDIT/retained_source_json_inventory_rev0774.md` — records retained-source JSON suffix/schema inventory validation and release-package self-verification wiring.
- `AUDIT/asset_index_inventory_rev0775.md` — records scoped artifact/certificate asset-index generation and canonical-path pointer validation.
- `AUDIT/paper_archive_payload_inventory_rev0776.md` — records canonical paper and embedded archive/repro-pack payload validation.
- `AUDIT/text_payload_runner_inventory_rev0777.md` — records text-payload hygiene validation and composite runner hardening.
- `AUDIT/payload_format_zip_container_inventory_rev0778.md` — records payload-format validation and deterministic ZIP container metadata self-checks.
- `AUDIT/zip_extractability_public_bundle_inventory_rev0779.md` — records portable ZIP extractability and public-bundle freshness validation.
- `AUDIT/provenance_absence_ledger_inventory_rev0780.md` — records the governed provenance/absence-ledger repair and validator guard.
- `AUDIT/crypto_envelope_statement_suffix_inventory_rev0781.md` — records crypto-envelope/key-material validation and the DSSE-vs-statement suffix repair.
- `AUDIT/filesystem_path_mode_inventory_rev0782.md` — records filesystem/path/mode policy validation and executable-bit normalization.
- `AUDIT/text_surface_lf_inventory_rev0783.md` — records governed text-surface LF/final-newline policy validation and generated CSV line-ending normalization.
- `AUDIT/context_pack_anchor_inventory_rev0784.md` — records context-pack revision drift repair and validator wiring.

- `AUDIT/validation_index_markdown_companion_inventory_rev0785.md` — records validation-index/archive-index Markdown companion drift repair and coverage enforcement.
- `AUDIT/publish_audit_runner_inventory_rev0787.md` — records the bounded publish-audit runner repair and governed command-runner validation wiring.
- `AUDIT/cross_reference_inventory_rev0788.md` — records governed cross-reference/path-resolution validation wiring.
- `AUDIT/changelog_history_anchor_inventory_rev0789.md` — records governed changelog/history-anchor validation wiring.
- `AUDIT/command_surface_inventory_rev0790.md` — records governed Makefile command-surface validation wiring.
- `AUDIT/archive_index_companion_inventory_rev0792.md` — records governed archive-index Markdown/JSON companion validation and release-lineage wiring.
- `AUDIT/source_index_companion_inventory_rev0793.md` — records exact source-index Markdown/JSON companion validation through the existing source-check lane.
- `AUDIT/current_frontier_companion_inventory_rev0794.md` — records exact current-frontier Markdown/JSON companion validation through the existing frontier-check lane.
- `AUDIT/decision_index_companion_inventory_rev0795.md` — records exact ADR/RFC decision-index Markdown/JSON companion validation through the existing adr-check and rfc-check lanes.
- `AUDIT/assimilation_ledger_companion_inventory_rev0796.md` — records exact assimilation-ledger Markdown/JSON companion validation through the existing assimilation-check lane.
- `AUDIT/release_queue_companion_inventory_rev0797.md` — records exact release-queue item Markdown/JSON companion validation through the existing publishing-check lane.
- `AUDIT/validation_index_companion_inventory_rev0798.md` — records exact validation-index Markdown/JSON companion rendering through the existing validation-check lane.
- `AUDIT/public_release_note_companion_inventory_rev0799.md` — records exact published public-release note Markdown/JSON companion rendering through the existing publishing-check lane.
- `AUDIT/publishing_helper_entrypoint_inventory_rev0800.md` — records publishing helper CLI entrypoint repair and validation through the existing publishing-check lane.
- `AUDIT/agent_contract_opening_inventory_rev0801.md` — records AGENTS.md read-first and command-posture validation through the existing opening-check lane.
- `AUDIT/revision_anchor_validator_inventory_rev0802.md` — records exact revision-anchor validator inventory validation against the active validation index surface.
- `AUDIT/command_runner_subprocess_inventory_rev0803.md` — records subprocess-isolated composite command-runner execution and validation hardening.
- `AUDIT/preflight_shell_wrapper_inventory_rev0804.md` — records preflight shell-wrapper validation hardening and runner-check coverage for required-surface/full-gate/transient/manifest guardrails.
- `AUDIT/package_refresh_subprocess_inventory_rev0805.md` — records package-refresh subprocess isolation for package-release builders and runner-check regression coverage.
- `AUDIT/package_transient_artifact_guard_inventory_rev0806.md` — records direct package-release transient build/review artifact refusal and runner-check regression coverage.
- `AUDIT/release_manifest_inclusion_fence_inventory_rev0807.md` — records release-manifest included_roots coverage enforcement in archive-identity validation and direct package-release execution.
- `AUDIT/package_release_full_gate_equivalence_inventory_rev0808.md` — records direct package-release full-gate equivalence and runner-check regression coverage.
- `AUDIT/audit_witness_inventory_rev0791.md` — records governed audit-witness inventory validation and runner/policy wiring.
- `AUDIT/dedupe_report_inventory_rev0786.md` — records dedupe-report regeneration and duplicate-payload inventory validator wiring.

## Editing posture
A good audit edit usually does one of the following:
- records a newly rerun audit,
- clarifies the role of an existing audit witness,
- or tightens cross-links between audit files and the rest of the archive.

A poor audit edit merely rewrites historical labels or paraphrases canon-owned statements.
- `AUDIT/historical_anomaly_ledger_inventory_rev0809.md` — records the rev0809 historical-anomaly ledger hardening.
- `AUDIT/crypto_fixture_verification_inventory_rev0810.md` — records indexed positive/negative Ed25519 DSSE fixture verification under the crypto-envelope validator.
- `AUDIT/toolchain_lock_inventory_rev0811.md` — rev0811 toolchain-lock inventory witness.
- `AUDIT/claim_obligation_map_inventory_rev0812.md` — records the rev0812 claim-obligation map hardening and package-blocking validation.
- `AUDIT/public_status_bridge_inventory_rev0813.md` — records public/internal status bridge validation and package-blocking wiring.
- `AUDIT/ro_crate_metadata_inventory_rev0814.md` — records RO-Crate-style research-object metadata bridge validation and package-blocking wiring.
- `AUDIT/release_manifest_identity_digest_perimeter_inventory_rev0815.md` — records release-manifest identity digest perimeter hardening and package-blocking acyclic digest refresh/validation.
- `AUDIT/release_artifact_verifier_inventory_rev0816.md` — records detached release-artifact verifier and package-emitted SHA-256 sidecar hardening.
- `AUDIT/release_artifact_embedded_index_identity_inventory_rev0817.md` — records embedded INDEX/files.* and release-manifest identity digest replay in the detached release-artifact verifier.
- `AUDIT/release_artifact_inclusion_fence_verifier_inventory_rev0818.md` — records detached release-artifact included-roots coverage replay from emitted ZIP bytes.
- `AUDIT/release_artifact_embedded_ro_crate_semantics_inventory_rev0819.md` — records detached artifact-byte RO-Crate bridge semantic verification and exact profile rendering.
- `AUDIT/release_artifact_embedded_crypto_fixture_verifier_inventory_rev0820.md` — records detached artifact-byte positive/negative Ed25519 DSSE fixture verification.
- `AUDIT/release_artifact_embedded_revision_anchor_verifier_inventory_rev0821.md` — records detached artifact-byte revision-anchor crosswalk semantic verification.
