# Package transient artifact guard inventory (rev0806)

## Scope
This witness records the rev0806 hardening that makes `scripts/package_release.py` refuse transient build/review artifacts directly, even when the named packager is run outside the shell preflight wrapper.

## Finding
`scripts/publish_preflight.sh` already refused LaTeX and review byproducts such as `*.aux`, `*.log`, `*.out`, `*.toc`, `*.bbl`, `*.blg`, `_render*`, `_renders*`, and `render_check*`. The direct `make package-release` path still only had its own bytecode-specific transient check before ZIP emission, relying on earlier wrapper posture to catch broader transient artifact names.

## Repair
- `scripts/package_release.py` now declares `TRANSIENT_SKIP_ROOTS` and `TRANSIENT_BUILD_PATTERNS` and runs `assert_no_transient_build_artifacts()` before package refresh and again immediately before ZIP emission.
- The package guard uses the same skip-root boundary and build/review artifact filename patterns as `scripts/publish_preflight.sh`, so retained source or curated artifact payload names are not reclassified by filename alone.
- `scripts/validate_command_runners.py` now checks the packager's transient guard constants, failure string, pre-refresh call, post-final-validator call, and continued alignment with the shell preflight pattern set.
- `VALIDATION_INDEX.*`, `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `CURRENT_FRONTIER.*`, `REVISION_ANCHORS.json`, and `publishing/CANONICAL_POLICY.json` now describe the direct packager transient-artifact refusal guard.

## Guardrail
This pass changes direct package-release guardrails and command-runner validation only. It does not change canonical paper/source payloads, public-release decisions, queue state, historical audit labels, or the stable `published/` surface.
