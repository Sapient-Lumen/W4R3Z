# Audit-witness inventory — rev0791

This witness records the rev0791 bounded validation pass that made the AUDIT inventory-witness surface explicitly checked rather than maintained only by human convention.

## New governed check

- `scripts/validate_audit_witnesses.py`
- `make audit-witness-check`

The validator checks that:

- every `AUDIT/*_inventory_rev####.md` witness shipped on disk is listed exactly once in `AUDIT/README.md`;
- the current revision witness `AUDIT/audit_witness_inventory_rev0791.md` exists;
- `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `VALIDATION_INDEX.*`, `CONTEXT_PACK.json`, `REVISION_ANCHORS.json`, and `publishing/CANONICAL_POLICY.json` expose the audit-witness validator;
- composite runners and package-final validators include `scripts/validate_audit_witnesses.py`; and
- the top `CHANGELOG.md` section names the current validator and witness without rewriting older audit-batch labels.

## Wiring

The audit-witness validator is wired into:

- `Makefile`
- `scripts/gate.py`
- `scripts/publish_audit.py`
- `scripts/package_release.py`
- `scripts/publish_preflight.sh`
- `scripts/validate_command_runners.py`
- `scripts/validate_makefile_surface.py`
- `scripts/validate_validation_index.py`
- `scripts/validate_control_surfaces.py`
- `scripts/validate_revision_anchors.py`
- `scripts/validate_archive_identity.py`
- `VALIDATION_INDEX.md`
- `VALIDATION_INDEX.json`
- `CONTEXT_PACK.json`
- `CONTROL_SURFACES.json`
- `LIFECYCLE_GATES.json`
- `REVISION_ANCHORS.json`
- `REVISION_RECEIPT.json`
- `CURRENT_FRONTIER.md`
- `CURRENT_FRONTIER.json`
- `AUDIT/README.md`
- `publishing/CANONICAL_POLICY.json`

## Boundary

This pass does not normalize historical witness labels, does not change paper/source payload semantics, and does not widen the public release surface.  It only closes drift risk in the retained audit-witness index so future deep passes can tell which audit inventory files are intentionally shipped and named.
