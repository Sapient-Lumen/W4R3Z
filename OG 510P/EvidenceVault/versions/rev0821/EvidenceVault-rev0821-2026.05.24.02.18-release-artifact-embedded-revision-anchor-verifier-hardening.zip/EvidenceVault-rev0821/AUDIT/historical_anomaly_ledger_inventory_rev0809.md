# Historical anomaly ledger inventory — rev0809

This witness records the rev0809 pass that moved carried-forward historical anomaly handling from implicit validator tolerance into an audit-scoped, machine-checked ledger.

## Finding

The archive already enforced strict recent-history behavior while carrying forward older duplicate/non-descending changelog and archive-index rows. It also retained audit witnesses whose bodies mention earlier revision labels. Those exceptions were understandable after manual review, but the exact exception set was not a first-class machine-readable surface.

## Repair

- Added `AUDIT/HISTORICAL_ANOMALIES.json`.
- Added `AUDIT/HISTORICAL_ANOMALIES.md` as the exact rendered companion.
- Added `schemas/historical_anomalies.schema.json`.
- Added `scripts/validate_historical_anomalies.py` and `make historical-anomaly-check`.
- Wired the validator through gate, publish-audit, package-release, preflight, validation inventory, control/lifecycle surfaces, context/frontier surfaces, canonical policy, and revision anchors.

## Guardrail

Future old-history exceptions must appear in the ledger exactly as scanned. New duplicate/order drift in the recent history window is not accepted as a carried-forward anomaly; it must be fixed instead.
