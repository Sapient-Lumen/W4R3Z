# ADR 0004: Derivative startup and control-plane surfaces stay derivative

- Status: Accepted
- Date: 2026-03-20

## Context
EvidenceVault now has startup contracts, receipts, bundle identity, control crosswalks, assimilation memory, a repo contract, and command wrappers.
Those surfaces reduce reopen error, but they could also become accidental pseudo-canon if their status is left implicit.

## Decision
Keep startup/reentry aids, control-plane crosswalks, receipts, bundle-identity surfaces, and low-entropy agent/command wrappers explicitly derivative or governing support surfaces.
They may summarize, validate, or point to canon, but they do not replace canonical statements.

## Consequences
- Future maintainers can safely improve recovery surfaces without moving substantive ownership.
- The archive can gain mechanical discipline without turning every helper surface into doctrine.

## Links
- `OPENING_CONTRACT.json`
- `CONTROL_SURFACES.json`
- `LIFECYCLE_GATES.json`
- `AGENTS.md`
- `Makefile`
