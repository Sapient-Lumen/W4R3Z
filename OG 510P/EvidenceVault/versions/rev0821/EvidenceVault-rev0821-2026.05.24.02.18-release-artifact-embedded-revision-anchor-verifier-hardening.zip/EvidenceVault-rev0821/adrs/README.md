# EvidenceVault ADRs

This directory holds **standing architecture decisions** that are more durable than a single revision receipt but still narrower than `SERIES.md` or `PUBLISHING.md`.
Use ADRs when a decision has become stable enough that future passes should treat it as settled unless explicitly superseded.

Rules:
- keep ADRs compact and link outward instead of copying long doctrine;
- use `ADR_INDEX.md` / `ADR_INDEX.json` as the root entry surfaces;
- do not restate canon already owned by `SERIES.md`, `PUBLISHING.md`, or `CHANGELOG.md` except to pin one architectural decision and its consequence.
