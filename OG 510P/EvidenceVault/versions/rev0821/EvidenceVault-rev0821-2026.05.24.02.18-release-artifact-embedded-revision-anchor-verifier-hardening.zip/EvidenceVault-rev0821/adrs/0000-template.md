# ADR 0000: <title>

- Status: <Accepted | Superseded | Rejected>
- Date: <YYYY-MM-DD>

## Context
What problem, pressure, or recurring drift made this decision worth pinning?

## Decision
What is now settled?

## Consequences
What becomes easier, what remains bounded, and what should not be inferred?

## Links
- `<canonical or governing surface>`
