# ADR 0003: Immutable public-release snapshots as historical authority

- Status: Accepted
- Date: 2026-03-20

## Context
A historical public release should not depend on whatever the current live `published/PUBLIC_SURFACE.json` happens to say later.
EvidenceVault already materializes historical release records and public bundles, but history needed a frozen authority surface.

## Decision
Historical public-release interpretation is anchored by the paired release-scoped snapshot plus stored manifest/snapshot digests.
Live public-surface paths may remain for operator convenience, but they are not the final historical authority once a release exists.

## Consequences
- Historical release meaning no longer drifts with later live-path edits.
- Release bundles and ledgers can be regenerated or audited against frozen authority surfaces.

## Links
- `published/releases/snapshots/`
- `published/releases/RELEASE_INDEX.json`
- `scripts/materialize_public_release.py`
