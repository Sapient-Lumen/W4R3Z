# ADR 0005: Historical audit labels may remain carried forward

- Status: Accepted
- Date: 2026-03-20

## Context
Some retained audit witnesses were generated from earlier audit batches and preserve older revision labels in their headings.
A later cleanup pass could mistake those labels for drift and rewrite historical witnesses inaccurately.

## Decision
When the underlying audit basis predates the current revision, retained audit witnesses may preserve their earlier audit-batch labels.
The right fix is to explain the boundary clearly, not to rewrite the historical witness as though it were generated later.

## Consequences
- Audit history stays honest about when a witness basis was actually produced.
- Cleanup passes are less likely to falsify retained audit evidence in the name of normalization.

## Links
- `AUDIT/README.md`
- `UPSTREAM_COVERAGE.md`
- `MIGRATION_AUDIT.md`
- `DEDUPE_REPORT.md`
