# ADR 0002: Small stable public surface

- Status: Accepted
- Date: 2026-03-20

## Context
The archive retains more material than it should publish directly.
Repeated comparison pressure from other cubes could easily widen `published/` into a convenience mirror.

## Decision
Treat `published/` as a deliberately small stable frontage rather than a mirror of the working archive.
Public release execution must move through explicit queue states, written/machine-readable decisions, release records, immutable public-surface snapshots, and deterministic public bundles.

## Consequences
- Public claims remain bounded and reviewable.
- Internal archive growth does not automatically widen the public frontage.
- Requests for broader disclosure should appear as explicit release-queue or decision activity rather than silent surface growth.

## Links
- `PUBLISHING.md`
- `published/README.md`
- `release_queue/`
