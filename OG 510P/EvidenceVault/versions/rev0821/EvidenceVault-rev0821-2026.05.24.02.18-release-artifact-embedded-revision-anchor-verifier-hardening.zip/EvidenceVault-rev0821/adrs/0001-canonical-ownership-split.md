# ADR 0001: Canonical ownership split

- Status: Accepted
- Date: 2026-03-20

## Context
EvidenceVault carries papers, retained evidence, release machinery, and later governance overlays.
Without an explicit ownership split, future revisions can drift by letting startup aids, indexes, or receipts silently become substitute canon.

## Decision
Keep canonical ownership narrow and explicit:
- `SERIES.md` owns architecture and reading order.
- `PUBLISHING.md` owns the public-release workflow.
- `PAPER_SERIES_INDEX.md` owns only titles/layer placement.
- `CATALOG.md` owns only archive lookup.
- `papers/EXTRACTION_MAP.json` owns present-state provenance.
- `CHANGELOG.md` owns revision history.

All other startup, control-plane, receipt, bundle-identity, and assimilation surfaces remain derivative or governing aids around that split.

## Consequences
- Future passes can add recovery or validation surfaces without pretending they are new canon.
- Drift is easier to detect because a question about ownership has one narrow answer.

## Links
- `SERIES.md`
- `PUBLISHING.md`
- `publishing/CANONICAL_POLICY.json`
