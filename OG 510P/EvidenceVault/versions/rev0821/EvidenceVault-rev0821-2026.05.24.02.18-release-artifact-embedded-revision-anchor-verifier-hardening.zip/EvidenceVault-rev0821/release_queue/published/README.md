# Published queue items

Place one paired `.md` and `.json` queue-item record here for each queue item that has already become a public release.

A published queue item should point to:
- one `publish` decision under `release_queue/decisions/`, and
- one public release id under `published/releases/`.

This directory closes the lifecycle: candidate -> hold or published_ready -> published.
It is a record of queue execution, not a second public surface.
