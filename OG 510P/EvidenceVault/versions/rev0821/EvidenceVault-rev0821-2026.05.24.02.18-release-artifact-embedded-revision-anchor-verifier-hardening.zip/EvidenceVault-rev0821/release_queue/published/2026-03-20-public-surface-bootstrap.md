# Release queue item

- Date: 2026-03-20
- Queue item id: EV-QUEUE-2026-03-20-public-surface-bootstrap
- State: published
- Scope: bootstrap stable public-facing landing surface and publishing controls
- Owner: EvidenceVault publishing pass
- Decision id: EV-REL-2026-03-20-public-surface-bootstrap
- Public release id: EV-PUB-2026-03-20-public-surface-bootstrap

## Tracked paths
- `published/index.md`
- `published/reader_guide.md`
- `published/artifact_request.md`
- `published/PUBLIC_SURFACE.json`
- `published/releases/README.md`
- `published/releases/2026-03-20-public-surface-bootstrap.md`
- `published/releases/2026-03-20-public-surface-bootstrap.json`
- `published/releases/RELEASE_INDEX.json`
- `published/releases/LATEST.json`

## Summary
The stable public-facing landing surface has been issued as a public release and is now tracked as an executed queue item.

## Next action
Update the queue item only if a later public release supersedes this surface.
