# Release queue item

- Date: 2026-03-20
- Queue item id: EV-QUEUE-2026-03-20-full-archive-mirror-not-public
- State: hold
- Scope: full working archive mirror public release posture
- Owner: EvidenceVault publishing posture
- Decision id: EV-REL-2026-03-20-full-archive-mirror-not-public
- Public release id:

## Tracked paths
- `published/index.md`
- `published/reader_guide.md`
- `published/artifact_request.md`
- `published/PUBLIC_SURFACE.json`

## Summary
Track the deliberate decision that the stable public surface remains smaller than a full working-archive mirror.

## Next action
Review only if there is a concrete public-use case for mirroring more than the stable entry surface.
