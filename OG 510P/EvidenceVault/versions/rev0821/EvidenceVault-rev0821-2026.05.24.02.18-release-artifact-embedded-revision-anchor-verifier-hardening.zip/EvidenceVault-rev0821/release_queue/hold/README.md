# Hold

Place materials here when the decision is intentionally not to publish yet.
`hold` is a normal outcome.

Use this directory for materials intentionally not being published yet.
Every held item should have a written decision under `release_queue/decisions/`.

Prefer one paired `.md` and `.json` queue-item record per held item.
Held items should point to a `hold` or `no-release` decision.
