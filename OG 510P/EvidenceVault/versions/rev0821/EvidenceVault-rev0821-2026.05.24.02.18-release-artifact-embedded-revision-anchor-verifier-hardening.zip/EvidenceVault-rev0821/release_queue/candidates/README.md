# Candidates

Place materials here that are under active consideration for publication.

Candidate materials under active review for a possible public release belong here.
Do not treat this directory alone as a release decision.

Prefer one paired `.md` and `.json` queue-item record per candidate.
Candidates may exist before a release decision is written.
