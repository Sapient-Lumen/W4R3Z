# Decisions

Record one concise decision note per release pass.
State the subject, decision, date, and why the material is publish / hold / no-release.

Keep paired `.md` and `.json` records here for every publish / hold / no-release decision.
Use `publishing/templates/release_decision.md` for the human-readable side and `schemas/release_decision.schema.json` for the machine-readable side.

Queue items live in the state directories; decisions explain why those items are published, held, or not released. Publish decisions should line up with paired public release records and materialized public release bundles.
