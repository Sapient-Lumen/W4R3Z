# Release decision

- Date: 2026-03-20
- Decision id: EV-REL-2026-03-20-full-archive-mirror-not-public
- Status: hold
- Scope: do not publish the full working archive as a public mirror
- Decision owner: EvidenceVault publishing posture

## Materials
- Candidate paths:
  - `README.md`
  - `SERIES.md`
  - `published/index.md`
  - `published/PUBLIC_SURFACE.json`
  - `release_queue/hold/2026-03-20-full-archive-mirror-not-public.md`
  - `release_queue/hold/2026-03-20-full-archive-mirror-not-public.json`
- Public-surface paths affected:
  - `published/index.md`
  - `published/reader_guide.md`
  - `published/artifact_request.md`
  - `published/PUBLIC_SURFACE.json`

## Reasoning
- Why this status: keep the public surface intentionally smaller than the full archive mirror and preserve the distinction between stable public entry points and the fuller working archive.
- Risks / blockers:
  - a full public mirror would blur the boundary between canonical papers, retained archive matter, and public entry points
  - full mirroring would increase public-surface size without improving first-contact clarity
- Follow-up needed:
  - release individual public drops through written publish decisions and paired public release records
  - revisit a broader mirror only if public-use cases require it

## Checks
- `bash scripts/build_papers.sh`
- `python3 scripts/build_release_queue_index.py`
- `python3 scripts/build_release_ledger.py`
- `python3 scripts/validate_publishing.py`
- `bash scripts/publish_preflight.sh`
