# EV-REL-2026-03-20-public-surface-bootstrap

- Date: 2026-03-20
- Status: publish
- Scope: bootstrap stable public-facing landing surface and publishing controls
- Decision owner: EvidenceVault publishing pass

## Candidate paths
- `published/index.md`
- `published/reader_guide.md`
- `published/artifact_request.md`
- `published/PUBLIC_SURFACE.json`
- `published/releases/README.md`

## Decision
Publish these as the initial stable public-facing surface.
They are intentionally smaller than the working archive and do not mirror the full source tree.

## Follow-up
- add stable release notes under `published/releases/` when specific public drops are ready
- use the same decision schema for future publish / hold / no-release decisions


Additional public release records for this decision:
- `published/releases/2026-03-20-public-surface-bootstrap.md`
- `published/releases/2026-03-20-public-surface-bootstrap.json`
- `published/releases/RELEASE_INDEX.json`
- `published/releases/LATEST.json`

Additional public release artifacts for this decision:
- `published/releases/artifacts/EV-PUB-2026-03-20-public-surface-bootstrap.zip`
- `published/releases/artifacts/EV-PUB-2026-03-20-public-surface-bootstrap.bundle.json`
- `published/releases/artifacts/ARTIFACT_INDEX.json`
