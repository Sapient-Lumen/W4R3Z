# Published-ready

Place materials here only after they have passed review and preflight and are ready to move to the public surface.

Use this directory for materials that have passed checks and are ready to be copied or linked into the stable public surface.

Once a published-ready item becomes public, create the matching paired public release note under `published/releases/`, freeze its snapshot under `published/releases/snapshots/`, materialize its bundle under `published/releases/artifacts/`, move the queue item into `release_queue/published/`, and rebuild the ledgers.

Prefer one paired `.md` and `.json` queue-item record per published-ready item.
Published-ready items should point to a `publish` decision and may optionally point forward to a public release id once issued. After publication, they should no longer remain here.
