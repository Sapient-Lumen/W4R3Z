# EvidenceVault release queue

This directory owns release-state staging only.
Use written decisions, not implicit folder motion, to explain why something is published, held, or not released.


## Required decision shape
- keep one paired `.md` and `.json` record per decision id under `release_queue/decisions/`
- `publish`, `hold`, and `no-release` are all first-class statuses
- folder placement should never be the only explanation for release state

A `publish` decision should have a matching paired public release note under `published/releases/` before the package ships.
A published public release should also have a materialized bundle under `published/releases/artifacts/`.

`release_queue/QUEUE_INDEX.json` is the machine-readable state summary across `candidate`, `hold`, `published_ready`, and `published`.

Published queue items live under `release_queue/published/`; they are queue execution records, not a second public surface.
