#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / 'scripts'
SEQUENCE_CONTRACT = ROOT / 'COMMAND_RUNNER_SEQUENCE.json'
# Governed publish-audit members are loaded from COMMAND_RUNNER_SEQUENCE.json: build_release_queue_index.py, build_release_ledger.py, materialize_public_release.py, build_asset_indexes.py, build_dedupe_report.py, rebuild_indexes.py, validate_context_pack.py, validate_makefile_surface.py, validate_toolchain_lock.py, validate_manifest_index.py, validate_dedupe_report.py, validate_changelog.py, validate_archive_index.py, validate_historical_anomalies.py, validate_claim_obligation_map.py, validate_public_status.py, validate_ro_crate_metadata.py, validate_text_surface_policy.py, validate_embedded_archives.py, validate_cross_references.py, validate_audit_witnesses.py, validate_command_runners.py, validate_publishing.py, validate_archive_identity.py


def load_sequence(sequence_id: str) -> list[str]:
    data = json.loads(SEQUENCE_CONTRACT.read_text(encoding='utf-8'))
    for sequence in data.get('sequences', []):
        if sequence.get('id') == sequence_id:
            scripts = [step.get('script') for step in sequence.get('steps', [])]
            if not scripts or not all(isinstance(name, str) and name for name in scripts):
                raise SystemExit(f'publish-audit: invalid command-runner sequence {sequence_id}')
            return scripts
    raise SystemExit(f'publish-audit: missing command-runner sequence {sequence_id}')


def run_script(script_name: str) -> None:
    env = os.environ.copy()
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    script = SCRIPTS / script_name
    print(f'publish-audit: {script_name}', flush=True)
    subprocess.run([sys.executable, str(script)], cwd=ROOT, env=env, check=True)


def main() -> None:
    # Publish audit remains bounded and intentionally does not call gate.py; the
    # JSON sequence contract owns that invariant and runner-check enforces it.
    for script_name in load_sequence('publish_audit'):
        run_script(script_name)
    print('publish-audit: OK')


if __name__ == '__main__':
    main()
