#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_VALIDATOR = 'scripts/validate_assimilation_ledger.py'
EXPLICIT_PRINCIPLE = 'explicit_assimilation_ledger_companion_validation'


def fail(msg: str) -> None:
    print(f"assimilation-ledger-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def load_json(rel: str):
    path = ROOT / rel
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"invalid JSON in {rel}: {exc}")


def require(rel: str) -> None:
    target = ROOT / rel.rstrip('/')
    if rel.endswith('/'):
        if not target.is_dir():
            fail(f"missing directory: {rel}")
    elif not target.exists():
        fail(f"missing path: {rel}")


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = "/".join(str(p) for p in err.path) or "<root>"
        fail(f"{label} schema violation at {where}: {err.message}")


def render_revision(record: dict) -> str:
    if record['status'] == 'adopted':
        return f"considered+landed `{record['landed_revision']}`"
    return f"reviewed `{record['decision_revision']}`"


def render_surfaces_or_note(record: dict) -> str:
    if record['status'] == 'adopted':
        return ', '.join(f"`{rel}`" for rel in record['implementation_surfaces'])
    return record['rationale']


def render_markdown(ledger: dict) -> str:
    lines = [
        '# Assimilation ledger',
        '',
        'This file is the compact human-facing companion to `ASSIMILATION_LEDGER.json`.',
        'It records which outside patterns were adopted, rejected, or deferred across EvidenceVault revisions so repeated comparison passes do not restart from zero.',
        '',
        '## Records',
        '',
        '| ID | Status | Pattern | Source pressure | Revision | Landed surfaces / note |',
        '| --- | --- | --- | --- | --- | --- |',
    ]
    for record in sorted(ledger['records'], key=lambda item: item['id']):
        sources = ', '.join(record['sources'])
        lines.append(
            f"| {record['id']} | {record['status']} | {record['pattern']} | {sources} | "
            f"{render_revision(record)} | {render_surfaces_or_note(record)} |"
        )
    return '\n'.join(lines).rstrip() + '\n'


def validate_markdown_companion(ledger: dict) -> None:
    data = (ROOT / 'ASSIMILATION_LEDGER.md').read_bytes()
    if b'\r' in data:
        fail('ASSIMILATION_LEDGER.md must use LF line endings')
    if not data.endswith(b'\n'):
        fail('ASSIMILATION_LEDGER.md must end with a newline')
    expected = render_markdown(ledger)
    if data.decode('utf-8') != expected:
        fail('ASSIMILATION_LEDGER.md must exactly mirror render_markdown(ASSIMILATION_LEDGER.json)')


def validate_validation_index(validation_index: dict) -> None:
    checks = {check['id']: check for check in validation_index.get('checks', [])}
    check = checks.get('assimilation-check')
    if check is None:
        fail('VALIDATION_INDEX.json missing assimilation-check')
    if check.get('make_target') != 'assimilation-check':
        fail('assimilation-check make_target mismatch')
    if check.get('scripts') != [EXPECTED_VALIDATOR]:
        fail('assimilation-check scripts mismatch')
    needed = {
        'ASSIMILATION_LEDGER.md',
        'ASSIMILATION_LEDGER.json',
        'schemas/assimilation_ledger.schema.json',
        EXPECTED_VALIDATOR,
        'RFC_INDEX.md',
        'RFC_INDEX.json',
        'REVISION_RECEIPT.json',
        'OPENING_CONTRACT.json',
        'CONTROL_SURFACES.json',
        'LIFECYCLE_GATES.json',
        'CONTEXT_PACK.json',
        'VALIDATION_INDEX.json',
        'publishing/CANONICAL_POLICY.json',
        'RELEASE_MANIFEST.json',
    }
    missing = sorted(needed - set(check.get('validates', [])))
    if missing:
        fail(f'assimilation-check validates missing surfaces: {missing}')
    for gate_id in ('careful_revision_pass', 'comparison_and_pattern_assimilation'):
        if gate_id not in check.get('used_in_gates', []):
            fail(f'assimilation-check used_in_gates missing {gate_id}')
    md = (ROOT / 'VALIDATION_INDEX.md').read_text(encoding='utf-8')
    if '`make assimilation-check`' not in md or EXPECTED_VALIDATOR not in md:
        fail('VALIDATION_INDEX.md missing assimilation-check coverage')


def main() -> None:
    ledger = load_json('ASSIMILATION_LEDGER.json')
    schema = load_json('schemas/assimilation_ledger.schema.json')
    receipt = load_json('REVISION_RECEIPT.json')
    opening = load_json('OPENING_CONTRACT.json')
    control = load_json('CONTROL_SURFACES.json')
    gates = load_json('LIFECYCLE_GATES.json')
    policy = load_json('publishing/CANONICAL_POLICY.json')
    archive_index = load_json('ARCHIVE_INDEX.json')
    rfc_index = load_json('RFC_INDEX.json')
    context = load_json('CONTEXT_PACK.json')
    validation_index = load_json('VALIDATION_INDEX.json')
    manifest = load_json('RELEASE_MANIFEST.json')

    validate_against_schema(ledger, schema, 'ASSIMILATION_LEDGER.json')
    validate_markdown_companion(ledger)

    if ledger['project'] != 'EvidenceVault':
        fail('ledger project must be EvidenceVault')

    ids = set()
    by_id = {}
    rfc_ids = {entry['id'] for entry in rfc_index.get('entries', [])}
    for record in ledger['records']:
        rid = record['id']
        if rid in ids:
            fail(f'duplicate ledger id: {rid}')
        ids.add(rid)
        by_id[rid] = record
        status = record['status']
        landed = record['landed_revision']
        surfaces = record['implementation_surfaces']
        related_rfc = record.get('related_rfc')
        if status == 'adopted':
            if landed is None:
                fail(f'{rid} is adopted but landed_revision is null')
            if record['decision_revision'] != landed:
                fail(f'{rid} adopted record must have decision_revision == landed_revision')
            if not surfaces:
                fail(f'{rid} adopted record must list implementation surfaces')
            for rel in surfaces:
                require(rel)
        else:
            if landed is not None:
                fail(f'{rid} non-adopted record must have null landed_revision')
            if surfaces:
                fail(f'{rid} non-adopted record must not list implementation surfaces')
        if related_rfc is not None and related_rfc not in rfc_ids:
            fail(f'{rid} related_rfc references missing RFC: {related_rfc}')

    updated = receipt.get('assimilation_records_updated', [])
    for rid in updated:
        if rid not in by_id:
            fail(f'revision receipt references missing assimilation record: {rid}')
        rec = by_id[rid]
        if rec['decision_revision'] != receipt['revision']:
            fail(f'{rid} decision_revision does not match current revision receipt')

    entrypoints = {item['path'] for item in opening.get('entrypoints', [])}
    if not {'ASSIMILATION_LEDGER.md', 'ASSIMILATION_LEDGER.json', 'RFC_INDEX.md', 'RFC_INDEX.json'}.issubset(entrypoints):
        fail('opening contract entrypoints missing assimilation/RFC surfaces')

    control_section = {item['path'] for item in control['surfaces'].get('comparison_and_assimilation', [])}
    expected_control = {'ASSIMILATION_LEDGER.md', 'ASSIMILATION_LEDGER.json', 'RFC_INDEX.md', 'RFC_INDEX.json', 'CURRENT_FRONTIER.md', 'CURRENT_FRONTIER.json', EXPECTED_VALIDATOR, 'scripts/validate_rfcs.py', 'scripts/validate_current_frontier.py'}
    if control_section != expected_control:
        fail('comparison_and_assimilation section must contain assimilation + RFC + current-frontier surfaces and validators')

    gate = gates['gates'].get('comparison_and_pattern_assimilation')
    if gate is None:
        fail('lifecycle gates missing comparison_and_pattern_assimilation gate')
    for rel in gate['required_surfaces'] + gate['checks']:
        require(rel)
    if EXPECTED_VALIDATOR not in gate['checks']:
        fail('comparison_and_pattern_assimilation gate missing assimilation validator')

    if policy.get('assimilation_ledger_markdown') != 'ASSIMILATION_LEDGER.md':
        fail('publishing/CANONICAL_POLICY.json assimilation_ledger_markdown mismatch')
    if policy.get('assimilation_ledger_json') != 'ASSIMILATION_LEDGER.json':
        fail('publishing/CANONICAL_POLICY.json assimilation_ledger_json mismatch')
    if policy.get('assimilation_ledger_validator') != EXPECTED_VALIDATOR:
        fail('publishing/CANONICAL_POLICY.json assimilation_ledger_validator mismatch')
    if policy.get('assimilation_ledger_schema') != 'schemas/assimilation_ledger.schema.json':
        fail('publishing/CANONICAL_POLICY.json assimilation_ledger_schema mismatch')
    if policy.get('rfc_index_markdown') != 'RFC_INDEX.md':
        fail('publishing/CANONICAL_POLICY.json rfc_index_markdown mismatch')
    if policy.get('rfc_index_json') != 'RFC_INDEX.json':
        fail('publishing/CANONICAL_POLICY.json rfc_index_json mismatch')
    if EXPLICIT_PRINCIPLE not in '\n'.join(policy.get('principles', [])):
        fail('publishing/CANONICAL_POLICY.json principles missing explicit assimilation-ledger companion validation')

    kms = context.get('key_machine_surfaces', {})
    if kms.get('assimilation_ledger_markdown') != 'ASSIMILATION_LEDGER.md':
        fail('CONTEXT_PACK.json key_machine_surfaces assimilation_ledger_markdown mismatch')
    if kms.get('assimilation_ledger_json') != 'ASSIMILATION_LEDGER.json':
        fail('CONTEXT_PACK.json key_machine_surfaces assimilation_ledger_json mismatch')
    if kms.get('assimilation_ledger_validator') != EXPECTED_VALIDATOR:
        fail('CONTEXT_PACK.json key_machine_surfaces assimilation_ledger_validator mismatch')

    if 'assimilation_ledger_json_sha256' not in manifest.get('identity_digests', {}):
        fail('RELEASE_MANIFEST.json missing assimilation_ledger_json_sha256 digest')

    validate_validation_index(validation_index)

    latest = archive_index.get('latest_revision')
    if latest != receipt['revision']:
        fail('archive index latest_revision does not match current revision')

    print(f'assimilation-ledger-validate: OK ({len(ledger["records"])} records, exact Markdown/JSON companion)')


if __name__ == '__main__':
    main()
