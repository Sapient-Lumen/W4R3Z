#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]


def fail(msg: str) -> None:
    print(f"control-surfaces-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def load_json(rel: str):
    path = ROOT / rel
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"invalid JSON in {rel}: {exc}")


def require(rel: str) -> None:
    if not (ROOT / rel).exists():
        fail(f"missing path: {rel}")


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = "/".join(str(p) for p in err.path) or "<root>"
        fail(f"{label} schema violation at {where}: {err.message}")


def main() -> None:
    control = load_json("CONTROL_SURFACES.json")
    gates = load_json("LIFECYCLE_GATES.json")
    control_schema = load_json("schemas/control_surfaces.schema.json")
    gates_schema = load_json("schemas/lifecycle_gates.schema.json")
    opening = load_json("OPENING_CONTRACT.json")
    opening_conformance = load_json("OPENING_SURFACE_CONFORMANCE.json")
    revision_receipt = load_json("REVISION_RECEIPT.json")
    policy = load_json("publishing/CANONICAL_POLICY.json")

    validate_against_schema(control, control_schema, "CONTROL_SURFACES.json")
    validate_against_schema(gates, gates_schema, "LIFECYCLE_GATES.json")

    if control["revision"] != gates["revision"]:
        fail("control surfaces and lifecycle gates revision mismatch")
    if control["revision"] != revision_receipt["revision"]:
        fail("control surfaces and lifecycle gates must match current revision receipt")

    for section in control["surfaces"].values():
        for item in section:
            require(item["path"])

    for gate in gates["gates"].values():
        for key in ("authoritative_sequence", "required_records", "required_surfaces", "checks"):
            for rel in gate.get(key, []):
                if rel.endswith("/"):
                    if not (ROOT / rel.rstrip("/")).is_dir():
                        fail(f"missing directory: {rel}")
                else:
                    require(rel)

    canonical_map = {item["path"] for item in control["surfaces"]["canonical_statements"]}
    expected_canonical = {
        policy["canonical_architecture"],
        policy["canonical_publishing"],
        policy["canonical_title_index"],
        policy["canonical_lookup"],
        policy["canonical_provenance"],
        policy["canonical_history"],
    }
    if canonical_map != expected_canonical:
        fail("canonical_statements section does not match publishing/CANONICAL_POLICY.json")

    opening_paths = {item["path"] for item in control["surfaces"]["opening_and_resumption"]}
    required_opening = set(opening_conformance["required_root_entrypoints"]) - {
        "CONTROL_SURFACES.json",
        "LIFECYCLE_GATES.json",
        "RELEASE_MANIFEST.json",
        "ARCHIVE_INDEX.md",
        "ARCHIVE_INDEX.json",
        "CHANGELOG.md",
    }
    if not required_opening.issubset(opening_paths):
        fail("opening_and_resumption section is missing one or more required startup surfaces")

    comparison_paths = {item["path"] for item in control["surfaces"]["comparison_and_assimilation"]}
    if comparison_paths != {'ASSIMILATION_LEDGER.md', 'ASSIMILATION_LEDGER.json', 'RFC_INDEX.md', 'RFC_INDEX.json', 'CURRENT_FRONTIER.md', 'CURRENT_FRONTIER.json', 'scripts/validate_assimilation_ledger.py', 'scripts/validate_rfcs.py', 'scripts/validate_current_frontier.py'}:
        fail('comparison_and_assimilation section must contain assimilation + RFC + current-frontier surfaces and validators')

    crosswalk_paths = {item["path"] for item in control["surfaces"]["control_crosswalks"]}
    if crosswalk_paths != {"CONTROL_SURFACES.json", "LIFECYCLE_GATES.json"}:
        fail("control_crosswalks section must contain CONTROL_SURFACES.json and LIFECYCLE_GATES.json")

    bundle_paths = {item["path"] for item in control["surfaces"]["bundle_identity"]}
    if bundle_paths != {"RELEASE_MANIFEST.json", "REVISION_ANCHORS.json", "ARCHIVE_INDEX.md", "ARCHIVE_INDEX.json", "INDEX/files.json", "INDEX/files.csv", "MANIFEST.sha256"}:
        fail("bundle_identity section must contain release manifest, revision anchors, archive index, file inventory, and SHA-256 manifest surfaces")

    profiles = {item["id"]: item for item in opening["profiles"]}
    if gates["gates"]["cold_open_and_reentry"]["authoritative_sequence"] != opening["cold_open_minimum"]:
        fail("cold_open_and_reentry sequence does not match OPENING_CONTRACT.json")
    for gate_id in ("careful_revision_pass", "publish_audit"):
        gate = gates["gates"][gate_id]
        profile_id = gate["opening_profile"]
        if profile_id not in profiles:
            fail(f"unknown opening profile in lifecycle gates: {profile_id}")
        if gate["authoritative_sequence"] != profiles[profile_id]["sequence"]:
            fail(f"{gate_id} sequence does not match OPENING_CONTRACT.json profile")

    validation_paths = {item["path"] for item in control["surfaces"]["validation_and_packaging"]}
    if 'scripts/build_source_index.py' not in validation_paths:
        fail('validation_and_packaging missing source-index builder')
    if 'scripts/validate_source_index.py' not in validation_paths:
        fail('validation_and_packaging missing source-index validator')
    if 'scripts/validate_revision_anchors.py' not in validation_paths:
        fail('validation_and_packaging missing revision-anchor validator')
    if 'scripts/validate_context_pack.py' not in validation_paths:
        fail('validation_and_packaging missing context-pack validator')
    if 'scripts/validate_toolchain_lock.py' not in validation_paths:
        fail('validation_and_packaging missing toolchain-lock validator')
    for rel in ('TOOLCHAIN_LOCK.json', 'TOOLCHAIN_LOCK.md', 'schemas/toolchain_lock.schema.json'):
        if rel not in validation_paths:
            fail(f'validation_and_packaging missing toolchain-lock surface {rel}')
    if 'scripts/validate_claim_obligation_map.py' not in validation_paths:
        fail('validation_and_packaging missing claim-obligation validator')
    for rel in ('CLAIM_OBLIGATION_MAP.json', 'CLAIM_OBLIGATION_MAP.md', 'schemas/claim_obligation_map.schema.json'):
        if rel not in validation_paths:
            fail(f'validation_and_packaging missing claim-obligation surface {rel}')
    if 'scripts/validate_public_status.py' not in validation_paths:
        fail('validation_and_packaging missing public-status validator')
    for rel in ('PUBLIC_STATUS.json', 'PUBLIC_STATUS.md', 'schemas/public_status.schema.json'):
        if rel not in validation_paths:
            fail(f'validation_and_packaging missing public-status surface {rel}')
    if 'scripts/validate_ro_crate_metadata.py' not in validation_paths:
        fail('validation_and_packaging missing RO-Crate metadata validator')
    for rel in ('ro-crate-metadata.json', 'RO_CRATE_PROFILE.md', 'schemas/ro_crate_metadata.schema.json'):
        if rel not in validation_paths:
            fail(f'validation_and_packaging missing RO-Crate metadata surface {rel}')
    if 'scripts/validate_rfcs.py' not in validation_paths:
        fail('validation_and_packaging missing RFC validator')
    if 'scripts/validate_validation_index.py' not in validation_paths:
        fail('validation_and_packaging missing validation-index validator')
    if 'scripts/validate_makefile_surface.py' not in validation_paths:
        fail('validation_and_packaging missing command-surface validator')
    if 'scripts/validate_command_runners.py' not in validation_paths:
        fail('validation_and_packaging missing command-runner validator')
    for rel in ('COMMAND_RUNNER_SEQUENCE.json', 'COMMAND_RUNNER_SEQUENCE.md', 'schemas/command_runner_sequence.schema.json'):
        if rel not in validation_paths:
            fail(f'validation_and_packaging missing command-runner sequence surface {rel}')
    if 'scripts/validate_changelog.py' not in validation_paths:
        fail('validation_and_packaging missing changelog/history-anchor validator')
    if 'scripts/validate_archive_index.py' not in validation_paths:
        fail('validation_and_packaging missing archive-index validator')
    if 'scripts/validate_historical_anomalies.py' not in validation_paths:
        fail('validation_and_packaging missing historical-anomaly validator')
    for rel in ('AUDIT/HISTORICAL_ANOMALIES.json', 'AUDIT/HISTORICAL_ANOMALIES.md', 'schemas/historical_anomalies.schema.json'):
        if rel not in validation_paths:
            fail(f'validation_and_packaging missing historical anomaly surface {rel}')
    if 'scripts/validate_cross_references.py' not in validation_paths:
        fail('validation_and_packaging missing cross-reference validator')
    if 'scripts/validate_audit_witnesses.py' not in validation_paths:
        fail('validation_and_packaging missing audit-witness validator')
    if 'scripts/validate_manifest_index.py' not in validation_paths:
        fail('validation_and_packaging missing manifest/index validator')
    if 'scripts/build_dedupe_report.py' not in validation_paths:
        fail('validation_and_packaging missing dedupe-report builder')
    if 'scripts/validate_dedupe_report.py' not in validation_paths:
        fail('validation_and_packaging missing dedupe-report validator')
    if 'scripts/validate_json_inventory.py' not in validation_paths:
        fail('validation_and_packaging missing JSON-inventory validator')
    if 'scripts/validate_text_payloads.py' not in validation_paths:
        fail('validation_and_packaging missing text-payload validator')
    if 'scripts/validate_text_surface_policy.py' not in validation_paths:
        fail('validation_and_packaging missing text-surface policy validator')
    if 'scripts/build_asset_indexes.py' not in validation_paths:
        fail('validation_and_packaging missing asset-index builder')
    if 'scripts/validate_asset_indexes.py' not in validation_paths:
        fail('validation_and_packaging missing asset-index validator')
    if 'scripts/validate_crypto_envelopes.py' not in validation_paths:
        fail('validation_and_packaging missing crypto-envelope validator')
    for rel in (
        'certs/CRYPTO_FIXTURE_INDEX.json',
        'certs/CRYPTO_FIXTURE_INDEX.md',
        'schemas/crypto_fixture_index.schema.json',
        'certs/verification_fixtures/README.md',
        'certs/verification_fixtures/rev0810_ed25519_public.pem',
        'certs/verification_fixtures/rev0810_positive.dsse.json',
        'certs/verification_fixtures/rev0810_negative_payload_tamper.dsse.json',
    ):
        if rel not in validation_paths:
            fail(f'validation_and_packaging missing crypto verification fixture surface {rel}')
    if 'scripts/validate_provenance_ledgers.py' not in validation_paths:
        fail('validation_and_packaging missing provenance-ledger validator')
    if 'scripts/validate_filesystem_policy.py' not in validation_paths:
        fail('validation_and_packaging missing filesystem-policy validator')
    if 'scripts/validate_paper_series.py' not in validation_paths:
        fail('validation_and_packaging missing paper-series validator')
    if 'scripts/validate_embedded_archives.py' not in validation_paths:
        fail('validation_and_packaging missing embedded-archive validator')
    if 'VALIDATION_INDEX.json' not in validation_paths:
        fail('validation_and_packaging missing VALIDATION_INDEX.json')

    audit_paths = {item['path'] for item in control['surfaces']['audit_and_retention']}
    if 'SOURCE_INDEX.md' not in audit_paths or 'SOURCE_INDEX.json' not in audit_paths:
        fail('audit_and_retention missing SOURCE_INDEX surfaces')
    for rel in ('artifacts/ARTIFACTS_INDEX.json', 'artifacts/ARTIFACTS_INDEX.csv', 'certs/CERTS_INDEX.json', 'certs/CERTS_INDEX.csv'):
        if rel not in audit_paths and rel not in validation_paths:
            fail(f'audit/validation surfaces missing asset index {rel}')


    if policy.get("control_surfaces") != "CONTROL_SURFACES.json":
        fail("publishing/CANONICAL_POLICY.json control_surfaces mismatch")
    if policy.get("lifecycle_gates") != "LIFECYCLE_GATES.json":
        fail("publishing/CANONICAL_POLICY.json lifecycle_gates mismatch")
    if policy.get("control_surfaces_validator") != "scripts/validate_control_surfaces.py":
        fail("publishing/CANONICAL_POLICY.json control_surfaces_validator mismatch")
    if policy.get("assimilation_ledger_markdown") != "ASSIMILATION_LEDGER.md":
        fail("publishing/CANONICAL_POLICY.json assimilation_ledger_markdown mismatch")
    if policy.get("adr_index_markdown") != "ADR_INDEX.md":
        fail("publishing/CANONICAL_POLICY.json adr_index_markdown mismatch")
    if policy.get("adr_index_json") != "ADR_INDEX.json":
        fail("publishing/CANONICAL_POLICY.json adr_index_json mismatch")
    if policy.get("adr_index_validator") != "scripts/validate_adrs.py":
        fail("publishing/CANONICAL_POLICY.json adr_index_validator mismatch")
    if policy.get("rfc_index_markdown") != "RFC_INDEX.md":
        fail("publishing/CANONICAL_POLICY.json rfc_index_markdown mismatch")
    if policy.get("rfc_index_json") != "RFC_INDEX.json":
        fail("publishing/CANONICAL_POLICY.json rfc_index_json mismatch")
    if policy.get("rfc_index_validator") != "scripts/validate_rfcs.py":
        fail("publishing/CANONICAL_POLICY.json rfc_index_validator mismatch")
    if policy.get("current_frontier_markdown") != "CURRENT_FRONTIER.md":
        fail("publishing/CANONICAL_POLICY.json current_frontier_markdown mismatch")
    if policy.get("current_frontier_json") != "CURRENT_FRONTIER.json":
        fail("publishing/CANONICAL_POLICY.json current_frontier_json mismatch")
    if policy.get("current_frontier_validator") != "scripts/validate_current_frontier.py":
        fail("publishing/CANONICAL_POLICY.json current_frontier_validator mismatch")
    if policy.get("assimilation_ledger_json") != "ASSIMILATION_LEDGER.json":
        fail("publishing/CANONICAL_POLICY.json assimilation_ledger_json mismatch")
    if policy.get("assimilation_ledger_validator") != "scripts/validate_assimilation_ledger.py":
        fail("publishing/CANONICAL_POLICY.json assimilation_ledger_validator mismatch")
    if policy.get("control_surfaces_schema") != "schemas/control_surfaces.schema.json":
        fail("publishing/CANONICAL_POLICY.json control_surfaces_schema mismatch")
    if policy.get("lifecycle_gates_schema") != "schemas/lifecycle_gates.schema.json":
        fail("publishing/CANONICAL_POLICY.json lifecycle_gates_schema mismatch")
    if policy.get("historical_anomalies_json") != "AUDIT/HISTORICAL_ANOMALIES.json":
        fail("publishing/CANONICAL_POLICY.json historical_anomalies_json mismatch")
    if policy.get("historical_anomalies_markdown") != "AUDIT/HISTORICAL_ANOMALIES.md":
        fail("publishing/CANONICAL_POLICY.json historical_anomalies_markdown mismatch")
    if policy.get("historical_anomalies_validator") != "scripts/validate_historical_anomalies.py":
        fail("publishing/CANONICAL_POLICY.json historical_anomalies_validator mismatch")
    if policy.get("historical_anomalies_schema") != "schemas/historical_anomalies.schema.json":
        fail("publishing/CANONICAL_POLICY.json historical_anomalies_schema mismatch")
    if policy.get("validation_index_markdown") != "VALIDATION_INDEX.md":
        fail("publishing/CANONICAL_POLICY.json validation_index_markdown mismatch")
    if policy.get("validation_index_json") != "VALIDATION_INDEX.json":
        fail("publishing/CANONICAL_POLICY.json validation_index_json mismatch")
    if policy.get("validation_index_validator") != "scripts/validate_validation_index.py":
        fail("publishing/CANONICAL_POLICY.json validation_index_validator mismatch")
    if policy.get("validation_index_schema") != "schemas/validation_index.schema.json":
        fail("publishing/CANONICAL_POLICY.json validation_index_schema mismatch")
    if policy.get("source_index_markdown") != "SOURCE_INDEX.md":
        fail("publishing/CANONICAL_POLICY.json source_index_markdown mismatch")
    if policy.get("source_index_json") != "SOURCE_INDEX.json":
        fail("publishing/CANONICAL_POLICY.json source_index_json mismatch")
    if policy.get("source_index_builder") != "scripts/build_source_index.py":
        fail("publishing/CANONICAL_POLICY.json source_index_builder mismatch")
    if policy.get("source_index_validator") != "scripts/validate_source_index.py":
        fail("publishing/CANONICAL_POLICY.json source_index_validator mismatch")
    if policy.get("source_index_schema") != "schemas/source_index.schema.json":
        fail("publishing/CANONICAL_POLICY.json source_index_schema mismatch")
    if policy.get("manifest_index_validator") != "scripts/validate_manifest_index.py":
        fail("publishing/CANONICAL_POLICY.json manifest_index_validator mismatch")
    if policy.get("file_inventory_json") != "INDEX/files.json":
        fail("publishing/CANONICAL_POLICY.json file_inventory_json mismatch")
    if policy.get("file_inventory_csv") != "INDEX/files.csv":
        fail("publishing/CANONICAL_POLICY.json file_inventory_csv mismatch")
    if policy.get("sha256_manifest") != "MANIFEST.sha256":
        fail("publishing/CANONICAL_POLICY.json sha256_manifest mismatch")
    if policy.get("dedupe_report") != "DEDUPE_REPORT.md":
        fail("publishing/CANONICAL_POLICY.json dedupe_report mismatch")
    if policy.get("dedupe_report_builder") != "scripts/build_dedupe_report.py":
        fail("publishing/CANONICAL_POLICY.json dedupe_report_builder mismatch")
    if policy.get("dedupe_report_validator") != "scripts/validate_dedupe_report.py":
        fail("publishing/CANONICAL_POLICY.json dedupe_report_validator mismatch")
    if policy.get("context_pack_validator") != "scripts/validate_context_pack.py":
        fail("publishing/CANONICAL_POLICY.json context_pack_validator mismatch")
    if policy.get("context_pack_schema") != "schemas/context_pack.schema.json":
        fail("publishing/CANONICAL_POLICY.json context_pack_schema mismatch")
    if policy.get("toolchain_lock_json") != "TOOLCHAIN_LOCK.json":
        fail("publishing/CANONICAL_POLICY.json toolchain_lock_json mismatch")
    if policy.get("toolchain_lock_markdown") != "TOOLCHAIN_LOCK.md":
        fail("publishing/CANONICAL_POLICY.json toolchain_lock_markdown mismatch")
    if policy.get("toolchain_lock_schema") != "schemas/toolchain_lock.schema.json":
        fail("publishing/CANONICAL_POLICY.json toolchain_lock_schema mismatch")
    if policy.get("toolchain_lock_validator") != "scripts/validate_toolchain_lock.py":
        fail("publishing/CANONICAL_POLICY.json toolchain_lock_validator mismatch")
    if policy.get("claim_obligation_map_json") != "CLAIM_OBLIGATION_MAP.json":
        fail("publishing/CANONICAL_POLICY.json claim_obligation_map_json mismatch")
    if policy.get("claim_obligation_map_markdown") != "CLAIM_OBLIGATION_MAP.md":
        fail("publishing/CANONICAL_POLICY.json claim_obligation_map_markdown mismatch")
    if policy.get("claim_obligation_map_schema") != "schemas/claim_obligation_map.schema.json":
        fail("publishing/CANONICAL_POLICY.json claim_obligation_map_schema mismatch")
    if policy.get("claim_obligation_map_validator") != "scripts/validate_claim_obligation_map.py":
        fail("publishing/CANONICAL_POLICY.json claim_obligation_map_validator mismatch")
    if policy.get("public_status_json") != "PUBLIC_STATUS.json":
        fail("publishing/CANONICAL_POLICY.json public_status_json mismatch")
    if policy.get("public_status_markdown") != "PUBLIC_STATUS.md":
        fail("publishing/CANONICAL_POLICY.json public_status_markdown mismatch")
    if policy.get("public_status_schema") != "schemas/public_status.schema.json":
        fail("publishing/CANONICAL_POLICY.json public_status_schema mismatch")
    if policy.get("public_status_validator") != "scripts/validate_public_status.py":
        fail("publishing/CANONICAL_POLICY.json public_status_validator mismatch")
    for key, expected in {
        "ro_crate_metadata_json": "ro-crate-metadata.json",
        "ro_crate_profile_markdown": "RO_CRATE_PROFILE.md",
        "ro_crate_metadata_schema": "schemas/ro_crate_metadata.schema.json",
        "ro_crate_metadata_validator": "scripts/validate_ro_crate_metadata.py",
        "release_artifact_verifier": "scripts/verify_release_artifact.py",
        "release_artifact_verifier_validator": "scripts/validate_command_runners.py",
    }.items():
        if policy.get(key) != expected:
            fail(f"publishing/CANONICAL_POLICY.json {key} mismatch")
    if policy.get("json_inventory_validator") != "scripts/validate_json_inventory.py":
        fail("publishing/CANONICAL_POLICY.json json_inventory_validator mismatch")
    if policy.get("text_payload_validator") != "scripts/validate_text_payloads.py":
        fail("publishing/CANONICAL_POLICY.json text_payload_validator mismatch")
    if policy.get("text_surface_policy_validator") != "scripts/validate_text_surface_policy.py":
        fail("publishing/CANONICAL_POLICY.json text_surface_policy_validator mismatch")
    if policy.get("command_surface_validator") != "scripts/validate_makefile_surface.py":
        fail("publishing/CANONICAL_POLICY.json command_surface_validator mismatch")
    for key, expected in {
        "command_runner_sequence_json": "COMMAND_RUNNER_SEQUENCE.json",
        "command_runner_sequence_markdown": "COMMAND_RUNNER_SEQUENCE.md",
        "command_runner_sequence_schema": "schemas/command_runner_sequence.schema.json",
        "command_runner_validator": "scripts/validate_command_runners.py",
    }.items():
        if policy.get(key) != expected:
            fail(f"publishing/CANONICAL_POLICY.json {key} mismatch")
    if policy.get("changelog_history_validator") != "scripts/validate_changelog.py":
        fail("publishing/CANONICAL_POLICY.json changelog_history_validator mismatch")
    if policy.get("archive_index_validator") != "scripts/validate_archive_index.py":
        fail("publishing/CANONICAL_POLICY.json archive_index_validator mismatch")
    if policy.get("cross_reference_validator") != "scripts/validate_cross_references.py":
        fail("publishing/CANONICAL_POLICY.json cross_reference_validator mismatch")
    if policy.get("audit_witness_validator") != "scripts/validate_audit_witnesses.py":
        fail("publishing/CANONICAL_POLICY.json audit_witness_validator mismatch")
    if policy.get("payload_format_validator") != "scripts/validate_payload_formats.py":
        fail("publishing/CANONICAL_POLICY.json payload_format_validator mismatch")
    if policy.get("crypto_envelope_validator") != "scripts/validate_crypto_envelopes.py":
        fail("publishing/CANONICAL_POLICY.json crypto_envelope_validator mismatch")
    if policy.get("crypto_fixture_index_json") != "certs/CRYPTO_FIXTURE_INDEX.json":
        fail("publishing/CANONICAL_POLICY.json crypto_fixture_index_json mismatch")
    if policy.get("crypto_fixture_index_markdown") != "certs/CRYPTO_FIXTURE_INDEX.md":
        fail("publishing/CANONICAL_POLICY.json crypto_fixture_index_markdown mismatch")
    if policy.get("crypto_fixture_index_schema") != "schemas/crypto_fixture_index.schema.json":
        fail("publishing/CANONICAL_POLICY.json crypto_fixture_index_schema mismatch")
    if policy.get("crypto_verification_fixture_directory") != "certs/verification_fixtures/":
        fail("publishing/CANONICAL_POLICY.json crypto_verification_fixture_directory mismatch")
    if policy.get("provenance_ledger_validator") != "scripts/validate_provenance_ledgers.py":
        fail("publishing/CANONICAL_POLICY.json provenance_ledger_validator mismatch")
    if policy.get("filesystem_policy_validator") != "scripts/validate_filesystem_policy.py":
        fail("publishing/CANONICAL_POLICY.json filesystem_policy_validator mismatch")
    for key, expected in {
        "upstream_inputs": "UPSTREAM_INPUTS.sha256",
        "upstream_omissions_csv": "AUDIT/UPSTREAM_OMISSIONS.csv",
        "upstream_diff_report": "AUDIT/UPSTREAM_DIFF_REPORT.md",
        "redactions_paths": "REDACTIONS.paths",
        "pruned_transient_paths": "PRUNED_TRANSIENT.paths",
    }.items():
        if policy.get(key) != expected:
            fail(f"publishing/CANONICAL_POLICY.json {key} mismatch")
    if policy.get("asset_index_builder") != "scripts/build_asset_indexes.py":
        fail("publishing/CANONICAL_POLICY.json asset_index_builder mismatch")
    if policy.get("asset_index_validator") != "scripts/validate_asset_indexes.py":
        fail("publishing/CANONICAL_POLICY.json asset_index_validator mismatch")
    if policy.get("artifact_index_json") != "artifacts/ARTIFACTS_INDEX.json":
        fail("publishing/CANONICAL_POLICY.json artifact_index_json mismatch")
    if policy.get("artifact_index_csv") != "artifacts/ARTIFACTS_INDEX.csv":
        fail("publishing/CANONICAL_POLICY.json artifact_index_csv mismatch")
    if policy.get("cert_index_json") != "certs/CERTS_INDEX.json":
        fail("publishing/CANONICAL_POLICY.json cert_index_json mismatch")
    if policy.get("cert_index_csv") != "certs/CERTS_INDEX.csv":
        fail("publishing/CANONICAL_POLICY.json cert_index_csv mismatch")
    if policy.get("schema_registry") != "schemas/registry.json":
        fail("publishing/CANONICAL_POLICY.json schema_registry mismatch")
    if policy.get("schema_directory") != "schemas/":
        fail("publishing/CANONICAL_POLICY.json schema_directory mismatch")
    if policy.get("paper_series_validator") != "scripts/validate_paper_series.py":
        fail("publishing/CANONICAL_POLICY.json paper_series_validator mismatch")
    if policy.get("embedded_archive_validator") != "scripts/validate_embedded_archives.py":
        fail("publishing/CANONICAL_POLICY.json embedded_archive_validator mismatch")
    for gate_id in ("careful_revision_pass", "publish_audit", "named_bundle_packaging"):
        if "scripts/validate_context_pack.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing context-pack validator")
        if "scripts/validate_makefile_surface.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing command-surface validator")
        if "scripts/validate_toolchain_lock.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing toolchain-lock validator")
        if "scripts/validate_claim_obligation_map.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing claim-obligation validator")
        if "scripts/validate_ro_crate_metadata.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing RO-Crate metadata validator")
        if "scripts/build_dedupe_report.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing dedupe-report builder")
        if "scripts/validate_dedupe_report.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing dedupe-report validator")
        if "scripts/validate_json_inventory.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing JSON-inventory validator")
        if "scripts/validate_text_payloads.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing text-payload validator")
        if "scripts/validate_text_surface_policy.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing text-surface policy validator")
        if "scripts/validate_payload_formats.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing payload-format validator")
        if "scripts/validate_crypto_envelopes.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing crypto-envelope validator")
        if "scripts/validate_provenance_ledgers.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing provenance-ledger validator")
        if "scripts/validate_asset_indexes.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing asset-index validator")
        if "scripts/validate_paper_series.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing paper-series validator")
        if "scripts/validate_embedded_archives.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing embedded-archive validator")
        if "scripts/validate_changelog.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing changelog/history-anchor validator")
        if "scripts/validate_archive_index.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing archive-index validator")
        if "scripts/validate_cross_references.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing cross-reference validator")
        if "scripts/validate_audit_witnesses.py" not in gates["gates"][gate_id].get("checks", []):
            fail(f"{gate_id} missing audit-witness validator")

    print("control-surfaces-validate: OK")


if __name__ == "__main__":
    main()
