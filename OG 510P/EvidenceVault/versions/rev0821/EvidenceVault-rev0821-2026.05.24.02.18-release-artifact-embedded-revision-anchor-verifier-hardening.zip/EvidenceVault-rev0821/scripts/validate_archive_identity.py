#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]


def fail(msg: str) -> None:
    print(f"archive-identity-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def load_json(rel: str):
    path = ROOT / rel
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"invalid JSON in {rel}: {exc}")


def require(rel: str) -> None:
    if not (ROOT / rel).exists():
        fail(f"missing path: {rel}")


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = "/".join(str(p) for p in err.path) or "<root>"
        fail(f"{label} schema violation at {where}: {err.message}")


def file_count() -> int:
    return sum(1 for p in ROOT.rglob('*') if p.is_file())


def included_root_covers(rel: str, included_root: str) -> bool:
    if included_root.endswith('/'):
        return rel.startswith(included_root)
    return rel == included_root


def validate_included_roots_coverage(release_manifest: dict) -> None:
    included_roots = release_manifest.get('included_roots', [])
    if len(included_roots) != len(set(included_roots)):
        fail('release manifest included_roots must not contain duplicates')
    for item in included_roots:
        if not isinstance(item, str) or not item:
            fail('release manifest included_roots entries must be non-empty strings')
        if item.startswith('/') or '\\' in item or '..' in Path(item).parts:
            fail(f'release manifest included_roots has unsafe entry: {item}')
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT).as_posix()
        if not any(included_root_covers(rel, item) for item in included_roots):
            fail(f'release manifest included_roots does not cover shipped path: {rel}')


def main() -> None:
    release_manifest = load_json('RELEASE_MANIFEST.json')
    archive_index = load_json('ARCHIVE_INDEX.json')
    revision_receipt = load_json('REVISION_RECEIPT.json')
    revision_anchors = load_json('REVISION_ANCHORS.json')
    opening_contract = load_json('OPENING_CONTRACT.json')
    policy = load_json('publishing/CANONICAL_POLICY.json')
    release_manifest_schema = load_json('schemas/release_manifest.schema.json')
    archive_index_schema = load_json('schemas/archive_bundle_index.schema.json')

    validate_against_schema(release_manifest, release_manifest_schema, 'RELEASE_MANIFEST.json')
    validate_against_schema(archive_index, archive_index_schema, 'ARCHIVE_INDEX.json')

    for rel in [
        release_manifest['history_anchor'],
        release_manifest['revision_receipt'],
        release_manifest['opening_contract'],
        release_manifest['revision_anchors'],
        'ASSIMILATION_LEDGER.md',
        'ASSIMILATION_LEDGER.json',
        release_manifest['adr_index_markdown'],
        release_manifest['adr_index_json'],
        release_manifest['rfc_index_markdown'],
        release_manifest['rfc_index_json'],
        release_manifest['current_frontier_markdown'],
        release_manifest['current_frontier_json'],
        release_manifest['claim_obligation_map_markdown'],
        release_manifest['claim_obligation_map_json'],
        release_manifest['public_status_markdown'],
        release_manifest['public_status_json'],
        release_manifest['release_manifest_schema'],
        release_manifest['archive_identity_validator'],
        release_manifest['release_artifact_verifier'],
        release_manifest['release_artifact_verifier_validator'],
        release_manifest['ro_crate_metadata_json'],
        release_manifest['ro_crate_profile_markdown'],
        release_manifest['ro_crate_metadata_schema'],
        release_manifest['ro_crate_metadata_validator'],
        release_manifest['agent_contract'],
        release_manifest['source_index_markdown'],
        release_manifest['source_index_json'],
        release_manifest['command_surface'],
        release_manifest['archive_index_markdown'],
        release_manifest['archive_index_json'],
        'CONTROL_SURFACES.json',
        'LIFECYCLE_GATES.json',
        'TOOLCHAIN_LOCK.json',
        'TOOLCHAIN_LOCK.md',
        'schemas/toolchain_lock.schema.json',
        'scripts/validate_toolchain_lock.py',
        'scripts/validate_adrs.py',
        'scripts/validate_assimilation_ledger.py',
        release_manifest['inventory'],
        'INDEX/files.csv',
        'MANIFEST.sha256',
        policy['archive_identity_validator'],
        policy.get('context_pack_validator'),
        policy.get('context_pack_schema'),
        policy['release_packager'],
        policy['release_manifest_schema'],
        policy['archive_bundle_index_schema'],
        policy['operator_release_manifest'],
        policy['revision_anchors'],
        policy['revision_anchor_validator'],
        policy['revision_anchor_schema'],
        policy['archive_bundle_index_markdown'],
        policy['archive_bundle_index_json'],
        policy['adr_index_markdown'],
        policy['adr_index_json'],
        policy['adr_index_validator'],
        policy['adr_index_schema'],
        policy['rfc_index_markdown'],
        policy['rfc_index_json'],
        policy['rfc_index_validator'],
        policy['rfc_index_schema'],
        policy.get('manifest_index_validator'),
        policy.get('file_inventory_json'),
        policy.get('file_inventory_csv'),
        policy.get('sha256_manifest'),
        policy.get('dedupe_report'),
        policy.get('dedupe_report_builder'),
        policy.get('dedupe_report_validator'),
        policy.get('json_inventory_validator'),
        policy.get('text_payload_validator'),
        policy.get('text_surface_policy_validator'),
        policy.get('payload_format_validator'),
        policy.get('command_surface_validator'),
        policy.get('toolchain_lock_json'),
        policy.get('toolchain_lock_markdown'),
        policy.get('toolchain_lock_schema'),
        policy.get('toolchain_lock_validator'),
        policy.get('claim_obligation_map_json'),
        policy.get('claim_obligation_map_markdown'),
        policy.get('claim_obligation_map_schema'),
        policy.get('claim_obligation_map_validator'),
        policy.get('public_status_json'),
        policy.get('public_status_markdown'),
        policy.get('public_status_schema'),
        policy.get('public_status_validator'),
        policy.get('ro_crate_metadata_json'),
        policy.get('ro_crate_profile_markdown'),
        policy.get('ro_crate_metadata_schema'),
        policy.get('ro_crate_metadata_validator'),
        policy.get('command_runner_sequence_json'),
        policy.get('command_runner_sequence_markdown'),
        policy.get('command_runner_sequence_schema'),
        policy.get('command_runner_validator'),
        policy.get('release_artifact_verifier'),
        policy.get('release_artifact_verifier_validator'),
        policy.get('crypto_envelope_validator'),
        policy.get('provenance_ledger_validator'),
        policy.get('filesystem_policy_validator'),
        policy.get('upstream_inputs'),
        policy.get('upstream_omissions_csv'),
        policy.get('upstream_diff_report'),
        policy.get('redactions_paths'),
        policy.get('pruned_transient_paths'),
        policy.get('asset_index_builder'),
        policy.get('asset_index_validator'),
        policy.get('paper_series_validator'),
        policy.get('embedded_archive_validator'),
        policy.get('artifact_index_json'),
        policy.get('artifact_index_csv'),
        policy.get('cert_index_json'),
        policy.get('cert_index_csv'),
        policy.get('schema_registry'),
        policy.get('schema_directory'),
    ]:
        require(rel)

    if release_manifest['project'] != 'EvidenceVault':
        fail('release manifest project must be EvidenceVault')
    if revision_receipt['project'] != release_manifest['project']:
        fail('revision receipt project mismatch')
    if release_manifest['revision'] != revision_receipt['revision']:
        fail('release manifest revision mismatch')
    if release_manifest['previous_revision'] != revision_receipt['previous_revision']:
        fail('release manifest previous_revision mismatch')
    if release_manifest['history_anchor'] != revision_receipt['history_anchor']:
        fail('release manifest history anchor mismatch')
    if release_manifest['revision_anchors'] != 'REVISION_ANCHORS.json':
        fail('release manifest revision_anchors must be REVISION_ANCHORS.json')
    if release_manifest['opening_contract'] != 'OPENING_CONTRACT.json':
        fail('release manifest opening_contract must be OPENING_CONTRACT.json')
    if release_manifest['adr_index_markdown'] != 'ADR_INDEX.md':
        fail('release manifest adr_index_markdown must be ADR_INDEX.md')
    if release_manifest['adr_index_json'] != 'ADR_INDEX.json':
        fail('release manifest adr_index_json must be ADR_INDEX.json')
    if release_manifest['rfc_index_markdown'] != 'RFC_INDEX.md':
        fail('release manifest rfc_index_markdown must be RFC_INDEX.md')
    if release_manifest['rfc_index_json'] != 'RFC_INDEX.json':
        fail('release manifest rfc_index_json must be RFC_INDEX.json')
    if release_manifest.get('current_frontier_markdown') != 'CURRENT_FRONTIER.md':
        fail('release manifest current_frontier_markdown must be CURRENT_FRONTIER.md')
    if release_manifest.get('current_frontier_json') != 'CURRENT_FRONTIER.json':
        fail('release manifest current_frontier_json must be CURRENT_FRONTIER.json')
    if release_manifest['agent_contract'] != 'AGENTS.md':
        fail('release manifest agent_contract must be AGENTS.md')
    if release_manifest['command_surface'] != 'Makefile':
        fail('release manifest command_surface must be Makefile')
    if release_manifest.get('source_index_markdown') != 'SOURCE_INDEX.md':
        fail('release manifest source_index_markdown must be SOURCE_INDEX.md')
    if release_manifest.get('source_index_json') != 'SOURCE_INDEX.json':
        fail('release manifest source_index_json must be SOURCE_INDEX.json')
    if release_manifest.get('validation_index_markdown') != 'VALIDATION_INDEX.md':
        fail('release manifest validation_index_markdown must be VALIDATION_INDEX.md')
    if release_manifest.get('validation_index_json') != 'VALIDATION_INDEX.json':
        fail('release manifest validation_index_json must be VALIDATION_INDEX.json')
    if release_manifest.get('claim_obligation_map_markdown') != 'CLAIM_OBLIGATION_MAP.md':
        fail('release manifest claim_obligation_map_markdown must be CLAIM_OBLIGATION_MAP.md')
    if release_manifest.get('claim_obligation_map_json') != 'CLAIM_OBLIGATION_MAP.json':
        fail('release manifest claim_obligation_map_json must be CLAIM_OBLIGATION_MAP.json')
    if release_manifest.get('public_status_markdown') != 'PUBLIC_STATUS.md':
        fail('release manifest public_status_markdown must be PUBLIC_STATUS.md')
    if release_manifest.get('public_status_json') != 'PUBLIC_STATUS.json':
        fail('release manifest public_status_json must be PUBLIC_STATUS.json')
    expected_release_manifest_paths = {'release_manifest_schema': 'schemas/release_manifest.schema.json', 'archive_identity_validator': 'scripts/validate_archive_identity.py', 'release_artifact_verifier': 'scripts/verify_release_artifact.py', 'release_artifact_verifier_validator': 'scripts/validate_command_runners.py', 'ro_crate_metadata_json': 'ro-crate-metadata.json', 'ro_crate_profile_markdown': 'RO_CRATE_PROFILE.md', 'ro_crate_metadata_schema': 'schemas/ro_crate_metadata.schema.json', 'ro_crate_metadata_validator': 'scripts/validate_ro_crate_metadata.py'}
    for key, expected in expected_release_manifest_paths.items():
        if release_manifest.get(key) != expected:
            fail(f'release manifest {key} must be {expected}')
    expected_exclusions = [{'path': 'ro-crate-metadata.json', 'reason': 'acyclic_release_identity_boundary: ro-crate-metadata.json digest-checks RELEASE_MANIFEST.json, so RELEASE_MANIFEST.json path-pins but does not digest it'}, {'path': 'RO_CRATE_PROFILE.md', 'reason': 'acyclic_release_identity_boundary: RO_CRATE_PROFILE.md exactly renders ro-crate-metadata.json and would carry the RELEASE_MANIFEST.json digest row'}]
    if release_manifest.get('identity_digest_exclusions') != expected_exclusions:
        fail('release manifest identity_digest_exclusions must exactly document the acyclic RO-Crate metadata/profile boundary')
    for forbidden_key in ['ro_crate_metadata_json_sha256', 'ro_crate_profile_markdown_sha256']:
        if forbidden_key in release_manifest.get('identity_digests', {}):
            fail(f'release manifest must not include cyclic digest key {forbidden_key}')
    if release_manifest['repo_root'] != ROOT.name:
        fail('release manifest repo_root must match archive root directory name')
    if revision_anchors['current_revision']['root_dir'] != ROOT.name:
        fail('revision anchors root_dir must match archive root directory name')
    if not re.fullmatch(r'EvidenceVault-rev\d{4}', ROOT.name):
        fail('archive root directory must be named EvidenceVault-rev####')

    expected_archive_name = f"EvidenceVault-{release_manifest['revision']}-{release_manifest['timestamp']}-{release_manifest['slug']}"
    if release_manifest['archive_name'] != expected_archive_name:
        fail('release manifest archive_name does not match revision/timestamp/slug')
    if release_manifest['bundle'] != expected_archive_name + '.zip':
        fail('release manifest bundle does not match archive_name')
    if archive_index['latest_revision'] != release_manifest['revision']:
        fail('archive index latest_revision mismatch')
    if revision_anchors['current_revision']['revision'] != release_manifest['revision']:
        fail('revision anchors revision mismatch')

    bundles = archive_index.get('bundles', [])
    if not bundles:
        fail('archive index bundles must not be empty')
    latest = bundles[0]
    if latest['revision'] != release_manifest['revision']:
        fail('archive index top row must match current revision')
    if latest['bundle'] != release_manifest['bundle']:
        fail('archive index top row bundle mismatch')
    if latest['date'] != release_manifest['date']:
        fail('archive index top row date mismatch')
    if release_manifest['revision'] not in (ROOT / release_manifest['history_anchor']).read_text(encoding='utf-8').splitlines()[2]:
        fail('changelog top revision heading mismatch')

    md = (ROOT / release_manifest['archive_index_markdown']).read_text(encoding='utf-8')
    if release_manifest['bundle'] not in md:
        fail('archive index markdown missing current bundle name')
    md_lines = md.splitlines()
    if not md_lines or md_lines[0].strip() != '# Archive bundle index':
        fail('archive index markdown must start with # Archive bundle index')
    if md.count('# Archive bundle index') != 1:
        fail('archive index markdown must contain exactly one top-level title')
    latest_line = f"- Latest revision: `{release_manifest['revision']}`"
    if latest_line not in md_lines[:8]:
        fail('archive index markdown latest revision line mismatch')
    first_heading = next((line.strip() for line in md_lines if line.startswith('## ')), None)
    expected_heading = f"## {release_manifest['revision']} - {release_manifest['date']}"
    if first_heading != expected_heading:
        fail('archive index markdown top revision heading mismatch')
    bundle_lines = [line.strip() for line in md_lines if line.strip().startswith('- Bundle:')]
    expected_bundle_lines = [f"- Bundle: `{entry['bundle']}`" for entry in bundles]
    if bundle_lines != expected_bundle_lines:
        fail('archive index markdown bundle order/content does not mirror ARCHIVE_INDEX.json')
    summary_lines = [line.strip() for line in md_lines if line.strip().startswith('- Summary:')]
    expected_summary_lines = [f"- Summary: {entry['summary']}" for entry in bundles]
    if summary_lines != expected_summary_lines:
        fail('archive index markdown summary order/content does not mirror ARCHIVE_INDEX.json')

    digest_targets = {
        'revision_receipt_sha256': ROOT / release_manifest['revision_receipt'],
        'opening_contract_sha256': ROOT / release_manifest['opening_contract'],
        'revision_anchors_sha256': ROOT / release_manifest['revision_anchors'],
        'context_pack_sha256': ROOT / 'CONTEXT_PACK.json',
        'agents_sha256': ROOT / release_manifest['agent_contract'],
        'makefile_sha256': ROOT / release_manifest['command_surface'],
        'source_index_json_sha256': ROOT / release_manifest['source_index_json'],
        'current_frontier_json_sha256': ROOT / release_manifest['current_frontier_json'],
        'validation_index_json_sha256': ROOT / release_manifest['validation_index_json'],
        'assimilation_ledger_json_sha256': ROOT / 'ASSIMILATION_LEDGER.json',
        'adr_index_json_sha256': ROOT / release_manifest['adr_index_json'],
        'rfc_index_json_sha256': ROOT / release_manifest['rfc_index_json'],
        'archive_index_json_sha256': ROOT / release_manifest['archive_index_json'],
        'control_surfaces_sha256': ROOT / 'CONTROL_SURFACES.json',
        'lifecycle_gates_sha256': ROOT / 'LIFECYCLE_GATES.json',
        'artifact_index_json_sha256': ROOT / 'artifacts' / 'ARTIFACTS_INDEX.json',
        'cert_index_json_sha256': ROOT / 'certs' / 'CERTS_INDEX.json',
        'toolchain_lock_json_sha256': ROOT / 'TOOLCHAIN_LOCK.json',
        'claim_obligation_map_json_sha256': ROOT / 'CLAIM_OBLIGATION_MAP.json',
        'public_status_json_sha256': ROOT / 'PUBLIC_STATUS.json',
        'command_runner_sequence_json_sha256': ROOT / 'COMMAND_RUNNER_SEQUENCE.json',
        'release_artifact_verifier_sha256': ROOT / release_manifest['release_artifact_verifier'],
        'release_artifact_verifier_validator_sha256': ROOT / release_manifest['release_artifact_verifier_validator'],
        'release_manifest_schema_sha256': ROOT / release_manifest['release_manifest_schema'],
        'archive_identity_validator_sha256': ROOT / release_manifest['archive_identity_validator'],
        'ro_crate_metadata_schema_sha256': ROOT / release_manifest['ro_crate_metadata_schema'],
        'ro_crate_metadata_validator_sha256': ROOT / release_manifest['ro_crate_metadata_validator'],
    }
    import hashlib
    for key, path in digest_targets.items():
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if release_manifest['identity_digests'][key] != digest:
            fail(f'release manifest digest mismatch for {key}')

    if policy.get('context_pack_validator') != 'scripts/validate_context_pack.py':
        fail('publishing/CANONICAL_POLICY.json context_pack_validator mismatch')
    if policy.get('context_pack_schema') != 'schemas/context_pack.schema.json':
        fail('publishing/CANONICAL_POLICY.json context_pack_schema mismatch')
    if policy.get('dedupe_report') != 'DEDUPE_REPORT.md':
        fail('publishing/CANONICAL_POLICY.json dedupe_report mismatch')
    if policy.get('dedupe_report_builder') != 'scripts/build_dedupe_report.py':
        fail('publishing/CANONICAL_POLICY.json dedupe_report_builder mismatch')
    if policy.get('dedupe_report_validator') != 'scripts/validate_dedupe_report.py':
        fail('publishing/CANONICAL_POLICY.json dedupe_report_validator mismatch')
    if policy.get('json_inventory_validator') != 'scripts/validate_json_inventory.py':
        fail('publishing/CANONICAL_POLICY.json json_inventory_validator mismatch')
    if policy.get('text_payload_validator') != 'scripts/validate_text_payloads.py':
        fail('publishing/CANONICAL_POLICY.json text_payload_validator mismatch')
    if policy.get('text_surface_policy_validator') != 'scripts/validate_text_surface_policy.py':
        fail('publishing/CANONICAL_POLICY.json text_surface_policy_validator mismatch')
    if policy.get('command_surface_validator') != 'scripts/validate_makefile_surface.py':
        fail('publishing/CANONICAL_POLICY.json command_surface_validator mismatch')
    if policy.get('toolchain_lock_json') != 'TOOLCHAIN_LOCK.json':
        fail('publishing/CANONICAL_POLICY.json toolchain_lock_json mismatch')
    if policy.get('toolchain_lock_markdown') != 'TOOLCHAIN_LOCK.md':
        fail('publishing/CANONICAL_POLICY.json toolchain_lock_markdown mismatch')
    if policy.get('toolchain_lock_schema') != 'schemas/toolchain_lock.schema.json':
        fail('publishing/CANONICAL_POLICY.json toolchain_lock_schema mismatch')
    if policy.get('toolchain_lock_validator') != 'scripts/validate_toolchain_lock.py':
        fail('publishing/CANONICAL_POLICY.json toolchain_lock_validator mismatch')
    if policy.get('claim_obligation_map_json') != 'CLAIM_OBLIGATION_MAP.json':
        fail('publishing/CANONICAL_POLICY.json claim_obligation_map_json mismatch')
    if policy.get('claim_obligation_map_markdown') != 'CLAIM_OBLIGATION_MAP.md':
        fail('publishing/CANONICAL_POLICY.json claim_obligation_map_markdown mismatch')
    if policy.get('claim_obligation_map_schema') != 'schemas/claim_obligation_map.schema.json':
        fail('publishing/CANONICAL_POLICY.json claim_obligation_map_schema mismatch')
    if policy.get('claim_obligation_map_validator') != 'scripts/validate_claim_obligation_map.py':
        fail('publishing/CANONICAL_POLICY.json claim_obligation_map_validator mismatch')
    if policy.get('public_status_json') != 'PUBLIC_STATUS.json':
        fail('publishing/CANONICAL_POLICY.json public_status_json mismatch')
    if policy.get('public_status_markdown') != 'PUBLIC_STATUS.md':
        fail('publishing/CANONICAL_POLICY.json public_status_markdown mismatch')
    if policy.get('public_status_schema') != 'schemas/public_status.schema.json':
        fail('publishing/CANONICAL_POLICY.json public_status_schema mismatch')
    if policy.get('public_status_validator') != 'scripts/validate_public_status.py':
        fail('publishing/CANONICAL_POLICY.json public_status_validator mismatch')
    for key, expected in {
        'ro_crate_metadata_json': 'ro-crate-metadata.json',
        'ro_crate_profile_markdown': 'RO_CRATE_PROFILE.md',
        'ro_crate_metadata_schema': 'schemas/ro_crate_metadata.schema.json',
        'ro_crate_metadata_validator': 'scripts/validate_ro_crate_metadata.py',
    }.items():
        if policy.get(key) != expected:
            fail(f'publishing/CANONICAL_POLICY.json {key} mismatch')
    for key, expected in {
        'command_runner_sequence_json': 'COMMAND_RUNNER_SEQUENCE.json',
        'command_runner_sequence_markdown': 'COMMAND_RUNNER_SEQUENCE.md',
        'command_runner_sequence_schema': 'schemas/command_runner_sequence.schema.json',
        'command_runner_validator': 'scripts/validate_command_runners.py',
    }.items():
        if policy.get(key) != expected:
            fail(f'publishing/CANONICAL_POLICY.json {key} mismatch')
    if policy.get('release_artifact_verifier') != 'scripts/verify_release_artifact.py':
        fail('publishing/CANONICAL_POLICY.json release_artifact_verifier mismatch')
    if policy.get('release_artifact_verifier_validator') != 'scripts/validate_command_runners.py':
        fail('publishing/CANONICAL_POLICY.json release_artifact_verifier_validator mismatch')
    if policy.get('changelog_history_validator') != 'scripts/validate_changelog.py':
        fail('publishing/CANONICAL_POLICY.json changelog_history_validator mismatch')
    if policy.get('archive_index_validator') != 'scripts/validate_archive_index.py':
        fail('publishing/CANONICAL_POLICY.json archive_index_validator mismatch')
    if policy.get('cross_reference_validator') != 'scripts/validate_cross_references.py':
        fail('publishing/CANONICAL_POLICY.json cross_reference_validator mismatch')
    if policy.get('audit_witness_validator') != 'scripts/validate_audit_witnesses.py':
        fail('publishing/CANONICAL_POLICY.json audit_witness_validator mismatch')
    if policy.get('payload_format_validator') != 'scripts/validate_payload_formats.py':
        fail('publishing/CANONICAL_POLICY.json payload_format_validator mismatch')
    if policy.get('crypto_envelope_validator') != 'scripts/validate_crypto_envelopes.py':
        fail('publishing/CANONICAL_POLICY.json crypto_envelope_validator mismatch')
    if policy.get('provenance_ledger_validator') != 'scripts/validate_provenance_ledgers.py':
        fail('publishing/CANONICAL_POLICY.json provenance_ledger_validator mismatch')
    if policy.get('filesystem_policy_validator') != 'scripts/validate_filesystem_policy.py':
        fail('publishing/CANONICAL_POLICY.json filesystem_policy_validator mismatch')
    for key, expected in {
        'upstream_inputs': 'UPSTREAM_INPUTS.sha256',
        'upstream_omissions_csv': 'AUDIT/UPSTREAM_OMISSIONS.csv',
        'upstream_diff_report': 'AUDIT/UPSTREAM_DIFF_REPORT.md',
        'redactions_paths': 'REDACTIONS.paths',
        'pruned_transient_paths': 'PRUNED_TRANSIENT.paths',
    }.items():
        if policy.get(key) != expected:
            fail(f'publishing/CANONICAL_POLICY.json {key} mismatch')
    if policy.get('asset_index_builder') != 'scripts/build_asset_indexes.py':
        fail('publishing/CANONICAL_POLICY.json asset_index_builder mismatch')
    if policy.get('asset_index_validator') != 'scripts/validate_asset_indexes.py':
        fail('publishing/CANONICAL_POLICY.json asset_index_validator mismatch')
    if policy.get('artifact_index_json') != 'artifacts/ARTIFACTS_INDEX.json':
        fail('publishing/CANONICAL_POLICY.json artifact_index_json mismatch')
    if policy.get('artifact_index_csv') != 'artifacts/ARTIFACTS_INDEX.csv':
        fail('publishing/CANONICAL_POLICY.json artifact_index_csv mismatch')
    if policy.get('cert_index_json') != 'certs/CERTS_INDEX.json':
        fail('publishing/CANONICAL_POLICY.json cert_index_json mismatch')
    if policy.get('cert_index_csv') != 'certs/CERTS_INDEX.csv':
        fail('publishing/CANONICAL_POLICY.json cert_index_csv mismatch')
    if policy.get('schema_registry') != 'schemas/registry.json':
        fail('publishing/CANONICAL_POLICY.json schema_registry mismatch')
    if policy.get('schema_directory') != 'schemas/':
        fail('publishing/CANONICAL_POLICY.json schema_directory mismatch')
    if policy.get('paper_series_validator') != 'scripts/validate_paper_series.py':
        fail('publishing/CANONICAL_POLICY.json paper_series_validator mismatch')
    if policy.get('embedded_archive_validator') != 'scripts/validate_embedded_archives.py':
        fail('publishing/CANONICAL_POLICY.json embedded_archive_validator mismatch')

    for rel in release_manifest.get('included_roots', []):
        target = ROOT / rel.rstrip('/')
        if rel.endswith('/'):
            if not target.is_dir():
                fail(f'release manifest included_roots references missing directory: {rel}')
        elif not target.exists():
            fail(f'release manifest included_roots references missing path: {rel}')
    validate_included_roots_coverage(release_manifest)
    if 'explicit_release_manifest_inclusion_fence_validation' not in policy.get('principles', []):
        fail('publishing/CANONICAL_POLICY.json principles missing release-manifest inclusion fence validation')

    if release_manifest['file_count'] != file_count():
        fail('release manifest file_count does not match current archive file count')

    required_opening = {'AGENTS.md', 'Makefile', 'COMMAND_RUNNER_SEQUENCE.md', 'COMMAND_RUNNER_SEQUENCE.json', 'VALIDATION_INDEX.md', 'VALIDATION_INDEX.json', 'SOURCE_INDEX.md', 'SOURCE_INDEX.json', 'ADR_INDEX.md', 'ADR_INDEX.json', 'RFC_INDEX.md', 'RFC_INDEX.json', 'CURRENT_FRONTIER.md', 'CURRENT_FRONTIER.json', 'ASSIMILATION_LEDGER.md', 'ASSIMILATION_LEDGER.json', 'RELEASE_MANIFEST.json', 'REVISION_ANCHORS.json', 'ARCHIVE_INDEX.md', 'ARCHIVE_INDEX.json', 'CONTROL_SURFACES.json', 'LIFECYCLE_GATES.json'}
    entrypoint_paths = {item['path'] for item in opening_contract.get('entrypoints', [])}
    if not required_opening.issubset(entrypoint_paths):
        fail('opening contract entrypoints missing bundle-identity/ADR/control surfaces')
    cold_open = set(opening_contract.get('cold_open_minimum', []))
    if not {'ADR_INDEX.md', 'RFC_INDEX.md', 'CURRENT_FRONTIER.md', 'VALIDATION_INDEX.md', 'SOURCE_INDEX.md', 'ASSIMILATION_LEDGER.md', 'RELEASE_MANIFEST.json', 'REVISION_ANCHORS.json', 'ARCHIVE_INDEX.md', 'CONTROL_SURFACES.json', 'LIFECYCLE_GATES.json'}.issubset(cold_open):
        fail('opening contract cold_open_minimum missing bundle-identity/source/ADR/RFC/frontier/validation/control surfaces')

    print('archive-identity-validate: OK')


if __name__ == '__main__':
    main()
