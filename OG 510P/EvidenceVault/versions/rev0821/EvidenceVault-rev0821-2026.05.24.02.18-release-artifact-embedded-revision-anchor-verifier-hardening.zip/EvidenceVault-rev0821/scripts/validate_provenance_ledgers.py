#!/usr/bin/env python3
"""Validate shipped upstream/provenance and absence ledgers.

This check is intentionally self-contained.  The upstream ZIP inputs are not
shipped in the archive, so the validator does not try to reopen them.  Instead
it checks that the retained, shipped audit ledgers agree with each other:

* upstream input digest rows are well-formed and are cited by the upstream docs;
* redacted paths are absent and exactly match secret-class upstream omissions;
* pruned/transient paths are absent from the shipped tree;
* the upstream omissions CSV has only governed reason classes; and
* the human upstream diff report is not stale relative to the CSV.
"""

from __future__ import annotations

import csv
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HEX64 = re.compile(r"^[0-9a-f]{64}$")
UPSTREAM_ROW = re.compile(r"^([0-9a-f]{64})\s+([^\s]+\.zip)\s+([1-9][0-9]*)$")
ALLOWED_REASONS = {"build", "cache", "tmp", "secret", "nested_archive"}
PROJECT_SOURCE_PREFIX = {
    "ctg": "sources/ctg/",
    "docf": "sources/docf/",
    "pact": "sources/pact/",
    "ocf_llm": "sources/ocf_llm/",
    "streamfold": "sources/streamfold/",
    "zkrtp_portfolio": "sources/zkrtp_portfolio/",
    "zkrtp_v2": "sources/zkrtp_v2/",
}


def fail(msg: str) -> None:
    print(f"provenance-ledgers-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def require(rel: str) -> Path:
    path = ROOT / rel
    if not path.exists():
        fail(f"missing path: {rel}")
    return path


def safe_rel(rel: str, label: str) -> None:
    p = Path(rel)
    if not rel or rel.startswith("/") or "\\" in rel or ".." in p.parts:
        fail(f"unsafe {label} path: {rel!r}")


def data_lines(rel: str) -> list[str]:
    rows: list[str] = []
    seen: set[str] = set()
    for n, raw in enumerate(require(rel).read_text(encoding="utf-8").splitlines(), start=1):
        s = raw.strip()
        if not s or s.startswith("#"):
            continue
        safe_rel(s, rel)
        if s in seen:
            fail(f"duplicate row in {rel}: {s}")
        seen.add(s)
        rows.append(s)
    return rows


def parse_upstream_inputs() -> dict[str, dict[str, object]]:
    inputs: dict[str, dict[str, object]] = {}
    for n, raw in enumerate(require("UPSTREAM_INPUTS.sha256").read_text(encoding="utf-8").splitlines(), start=1):
        line = raw.strip()
        if not line:
            continue
        m = UPSTREAM_ROW.fullmatch(line)
        if not m:
            fail(f"UPSTREAM_INPUTS.sha256 line {n} is malformed")
        digest, name, size_s = m.groups()
        if name in inputs:
            fail(f"duplicate upstream input name: {name}")
        inputs[name] = {"sha256": digest, "size": int(size_s)}
    if not inputs:
        fail("UPSTREAM_INPUTS.sha256 contains no input rows")
    return inputs


def validate_upstream_input_docs(inputs: dict[str, dict[str, object]]) -> None:
    upstream_md = require("UPSTREAM.md").read_text(encoding="utf-8")
    coverage_md = require("UPSTREAM_COVERAGE.md").read_text(encoding="utf-8")
    if "UPSTREAM_INPUTS.sha256" not in upstream_md:
        fail("UPSTREAM.md must point readers to UPSTREAM_INPUTS.sha256")
    for name, row in inputs.items():
        digest = str(row["sha256"])
        if name not in coverage_md:
            fail(f"UPSTREAM_COVERAGE.md does not cite upstream input {name}")
        if digest not in coverage_md:
            fail(f"UPSTREAM_COVERAGE.md does not cite digest for {name}")
        if (ROOT / name).exists():
            fail(f"upstream ZIP is embedded in archive root despite policy: {name}")


def parse_omissions_csv() -> list[dict[str, str]]:
    path = require("AUDIT/UPSTREAM_OMISSIONS.csv")
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        expected = ["project", "reason", "upstream_path", "normalized_path"]
        if reader.fieldnames != expected:
            fail(f"AUDIT/UPSTREAM_OMISSIONS.csv header mismatch: {reader.fieldnames!r}")
        rows = list(reader)
    seen: set[tuple[str, str, str, str]] = set()
    for i, row in enumerate(rows, start=2):
        key = tuple(row.get(k, "") for k in ("project", "reason", "upstream_path", "normalized_path"))
        if key in seen:
            fail(f"duplicate omission row at CSV line {i}: {key!r}")
        seen.add(key)
        project = row["project"]
        reason = row["reason"]
        if project not in PROJECT_SOURCE_PREFIX:
            fail(f"unknown upstream project in omissions CSV line {i}: {project}")
        if reason not in ALLOWED_REASONS:
            fail(f"ungoverned omission reason in CSV line {i}: {reason}")
        safe_rel(row["upstream_path"], f"omission upstream_path line {i}")
        safe_rel(row["normalized_path"], f"omission normalized_path line {i}")
    return rows


def secret_omission_paths(rows: list[dict[str, str]]) -> set[str]:
    secrets = set()
    for row in rows:
        if row["reason"] != "secret":
            continue
        prefix = PROJECT_SOURCE_PREFIX[row["project"]]
        secrets.add(prefix + row["normalized_path"])
    return secrets


def validate_absent_paths(rel: str, *, expected: set[str] | None = None) -> set[str]:
    rows = set(data_lines(rel))
    if expected is not None and rows != expected:
        missing = sorted(expected - rows)[:8]
        extra = sorted(rows - expected)[:8]
        fail(f"{rel} does not match expected governed path set; missing={missing}, extra={extra}")
    for path in sorted(rows):
        if (ROOT / path).exists():
            fail(f"{rel} records an absent/pruned path that is present in the shipped archive: {path}")
    return rows


def parse_upstream_report() -> tuple[dict[str, int], dict[str, Counter[str]]]:
    text = require("AUDIT/UPSTREAM_DIFF_REPORT.md").read_text(encoding="utf-8")
    omitted_counts: dict[str, int] = {}
    reason_counts: dict[str, Counter[str]] = defaultdict(Counter)
    current: str | None = None
    for raw in text.splitlines():
        line = raw.strip()
        m = re.fullmatch(r"##\s+([A-Za-z0-9_]+)", line)
        if m:
            current = m.group(1)
            if current not in PROJECT_SOURCE_PREFIX:
                fail(f"upstream report uses unknown project section: {current}")
            continue
        if current is None:
            continue
        m = re.fullmatch(r"- Omitted: \*\*([0-9]+)\*\*", line)
        if m:
            omitted_counts[current] = int(m.group(1))
            continue
        m = re.fullmatch(r"- `([a-z_]+)`: ([0-9]+)", line)
        if m:
            reason, count_s = m.groups()
            if reason not in ALLOWED_REASONS:
                fail(f"upstream report uses ungoverned omission reason: {reason}")
            reason_counts[current][reason] = int(count_s)
    return omitted_counts, reason_counts


def validate_report_matches_csv(rows: list[dict[str, str]]) -> None:
    omitted_by_project = Counter(row["project"] for row in rows)
    reason_by_project: dict[str, Counter[str]] = defaultdict(Counter)
    for row in rows:
        reason_by_project[row["project"]][row["reason"]] += 1

    report_omitted, report_reasons = parse_upstream_report()
    if set(report_omitted) != set(PROJECT_SOURCE_PREFIX):
        missing = sorted(set(PROJECT_SOURCE_PREFIX) - set(report_omitted))
        extra = sorted(set(report_omitted) - set(PROJECT_SOURCE_PREFIX))
        fail(f"upstream report project sections mismatch; missing={missing}, extra={extra}")
    for project in PROJECT_SOURCE_PREFIX:
        if report_omitted.get(project, 0) != omitted_by_project.get(project, 0):
            fail(
                f"upstream report omitted count stale for {project}: "
                f"report={report_omitted.get(project, 0)}, csv={omitted_by_project.get(project, 0)}"
            )
        if report_reasons.get(project, Counter()) != reason_by_project.get(project, Counter()):
            fail(
                f"upstream report reason counts stale for {project}: "
                f"report={dict(report_reasons.get(project, Counter()))}, csv={dict(reason_by_project.get(project, Counter()))}"
            )


def main() -> None:
    inputs = parse_upstream_inputs()
    validate_upstream_input_docs(inputs)
    rows = parse_omissions_csv()
    validate_report_matches_csv(rows)

    redactions = validate_absent_paths("REDACTIONS.paths", expected=secret_omission_paths(rows))
    pruned = validate_absent_paths("PRUNED_TRANSIENT.paths")

    for rel in ["REDACTIONS.md", "PRUNING_POLICY.md", "UPSTREAM.md", "UPSTREAM_COVERAGE.md", "AUDIT/README.md"]:
        require(rel)

    print(
        "provenance-ledgers-validate: OK "
        f"({len(inputs)} upstream inputs, {len(rows)} omission rows, "
        f"{len(redactions)} redactions, {len(pruned)} pruned/transient paths)"
    )


if __name__ == "__main__":
    main()
