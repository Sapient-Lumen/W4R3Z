#!/usr/bin/env python3
"""Validate that DEDUPE_REPORT.md mirrors the shipped tree."""
from __future__ import annotations

import runpy
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / 'DEDUPE_REPORT.md'


def fail(msg: str) -> None:
    print(f'dedupe-report-validate: FAIL: {msg}', file=sys.stderr)
    sys.exit(1)


def main() -> None:
    namespace = runpy.run_path(str(ROOT / 'scripts' / 'build_dedupe_report.py'))
    expected = namespace['render']()
    try:
        actual = REPORT.read_text(encoding='utf-8')
    except Exception as exc:
        fail(f'cannot read DEDUPE_REPORT.md: {exc}')
    if actual != expected:
        fail('DEDUPE_REPORT.md is stale; run python3 scripts/build_dedupe_report.py')
    file_count, unique_count, duplicate_copies, duplicate_bytes, groups = namespace['duplicate_groups']()
    print(
        'dedupe-report-validate: OK '
        f'({file_count} scanned files, {unique_count} unique blobs, '
        f'{duplicate_copies} duplicate copies, {duplicate_bytes} duplicate bytes, '
        f'{len(groups)} duplicate blob groups)'
    )


if __name__ == '__main__':
    main()
