#!/usr/bin/env python3
"""Rebuild EvidenceVault artifact/cert asset indexes.

The archive-wide INDEX/files.* records every shipped file.  These smaller
indexes are scoped recovery surfaces for the two payload-bearing asset roots:

  - artifacts/ARTIFACTS_INDEX.{json,csv}: every shipped file under artifacts/
    except the index files themselves.
  - certs/CERTS_INDEX.{json,csv}: every shipped file under certs/ except the
    index files themselves.

Rows are deliberately simple and deterministic so stale mirrors or removed
curated files cannot remain silently advertised after dedupe/pruning passes.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIELDS = ["path", "project", "kind", "bytes", "sha256"]
INDEXES = [
    {
        "root": ROOT / "artifacts",
        "json": ROOT / "artifacts" / "ARTIFACTS_INDEX.json",
        "csv": ROOT / "artifacts" / "ARTIFACTS_INDEX.csv",
        "excluded": {"ARTIFACTS_INDEX.json", "ARTIFACTS_INDEX.csv"},
    },
    {
        "root": ROOT / "certs",
        "json": ROOT / "certs" / "CERTS_INDEX.json",
        "csv": ROOT / "certs" / "CERTS_INDEX.csv",
        "excluded": {"CERTS_INDEX.json", "CERTS_INDEX.csv"},
    },
]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def project_for(rel: str) -> str:
    parts = rel.split("/")
    if parts[0] == "artifacts":
        if len(parts) > 2 and parts[1] == "curated":
            return parts[2] if parts[2] != "README.md" else "curated"
        if len(parts) > 2 and parts[1] == "repro_packs":
            return "repro_packs"
        return parts[1] if len(parts) > 1 else ""
    if parts[0] == "certs":
        if len(parts) > 2 and parts[1] == "curated":
            return parts[2] if parts[2] != "README.md" else "curated"
        return "root"
    return parts[0]


def kind_for(path: Path) -> str:
    suffixes = path.suffixes
    if len(suffixes) >= 2 and suffixes[-2:] == [".tar", ".gz"]:
        return "tar.gz"
    if len(suffixes) >= 2 and suffixes[-2:] == [".dsse", ".json"]:
        return "dsse.json"
    if len(suffixes) >= 2 and suffixes[-2:] == [".statement", ".json"]:
        return "statement.json"
    if len(suffixes) >= 2 and suffixes[-2:] == [".schema", ".json"]:
        return "schema.json"
    return path.suffix.lower().lstrip(".") or "file"


def row_for(path: Path) -> dict[str, object]:
    rel = path.relative_to(ROOT).as_posix()
    return {
        "path": rel,
        "project": project_for(rel),
        "kind": kind_for(path),
        "bytes": path.stat().st_size,
        "sha256": sha256_file(path),
    }


def rows_for(root: Path, excluded: set[str]) -> list[dict[str, object]]:
    rows = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        if path.name in excluded and path.parent == root:
            continue
        rows.append(row_for(path))
    return rows


def write_index(spec: dict[str, object]) -> int:
    root = spec["root"]
    json_path = spec["json"]
    csv_path = spec["csv"]
    excluded = spec["excluded"]
    assert isinstance(root, Path)
    assert isinstance(json_path, Path)
    assert isinstance(csv_path, Path)
    assert isinstance(excluded, set)

    rows = rows_for(root, excluded)
    json_path.write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS, lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow(row)
    return len(rows)


def main() -> None:
    counts = []
    for spec in INDEXES:
        counts.append((Path(spec["json"]).relative_to(ROOT).as_posix(), write_index(spec)))
    msg = "; ".join(f"{path}: {count} files" for path, count in counts)
    print(f"asset-indexes: OK ({msg})")


if __name__ == "__main__":
    main()
