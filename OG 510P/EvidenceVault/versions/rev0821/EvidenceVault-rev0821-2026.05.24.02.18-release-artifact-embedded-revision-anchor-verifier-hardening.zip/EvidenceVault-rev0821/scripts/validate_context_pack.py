#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]

PATHISH_KEYS = {'architecture', 'publishing', 'title_index', 'lookup', 'provenance', 'history', 'public_surface', 'queue'}


def fail(msg: str) -> None:
    print(f"context-pack-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def load_json(rel: str):
    path = ROOT / rel
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        fail(f'invalid JSON in {rel}: {exc}')


def require(rel: str) -> None:
    if not isinstance(rel, str) or not rel:
        fail(f'empty/non-string path reference: {rel!r}')
    if rel.startswith('/') or '\\' in rel or '..' in Path(rel).parts:
        fail(f'unsafe path reference: {rel}')
    path = ROOT / rel.rstrip('/')
    if rel.endswith('/'):
        if not path.is_dir():
            fail(f'missing directory reference: {rel}')
    else:
        if not path.exists():
            fail(f'missing path reference: {rel}')


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = '/'.join(str(p) for p in err.path) or '<root>'
        fail(f'{label} schema violation at {where}: {err.message}')


def parse_make_targets() -> set[str]:
    text = (ROOT / 'Makefile').read_text(encoding='utf-8')
    targets = set()
    for line in text.splitlines():
        if line.startswith('.') or line.startswith('\t') or not line.strip() or '=' in line:
            continue
        m = re.match(r'^([A-Za-z0-9_.-]+):', line)
        if m:
            targets.add(m.group(1))
    return targets


def command_covers_target(commands: set[str], target: str) -> bool:
    return f'make {target}' in commands


def main() -> None:
    context = load_json('CONTEXT_PACK.json')
    schema = load_json('schemas/context_pack.schema.json')
    opening = load_json('OPENING_CONTRACT.json')
    conformance = load_json('OPENING_SURFACE_CONFORMANCE.json')
    manifest = load_json('RELEASE_MANIFEST.json')
    receipt = load_json('REVISION_RECEIPT.json')
    anchors = load_json('REVISION_ANCHORS.json')
    validation_index = load_json('VALIDATION_INDEX.json')
    policy = load_json('publishing/CANONICAL_POLICY.json')

    validate_against_schema(context, schema, 'CONTEXT_PACK.json')

    current = manifest['revision']
    if context['revision'] != current:
        fail(f'CONTEXT_PACK.json revision mismatch: expected {current}, got {context["revision"]}')
    if receipt['revision'] != current or anchors['current_revision']['revision'] != current:
        fail('manifest, receipt, and revision anchors disagree on current revision')
    if validation_index['revision'] != current:
        fail('VALIDATION_INDEX.json revision mismatch')

    profiles = {item['id']: item for item in opening['profiles']}
    profile_id = conformance['context_pack_profile_id']
    if profile_id not in profiles:
        fail(f'unknown context-pack opening profile: {profile_id}')
    if context['read_order'] != profiles[profile_id]['sequence']:
        fail('CONTEXT_PACK.json read_order does not match OPENING_CONTRACT.json context-pack profile sequence')
    for rel in context['read_order']:
        require(rel)

    for key, rel in context['canonical_surfaces'].items():
        if key in PATHISH_KEYS:
            require(rel)
    for key, rel in context['key_machine_surfaces'].items():
        require(rel)

    expected_papers = [
        'papers/ev_acceptability_kernel.tex',
        'papers/ev_interpretation_profiles.tex',
        'papers/ev_streamfold.tex',
        'papers/ev_zkrtp.tex',
        'papers/ev_pact_ocf.tex',
    ]
    if context['paper_order'] != expected_papers:
        fail('CONTEXT_PACK.json paper_order does not match canonical paper order')
    for rel in context['paper_order']:
        require(rel)

    make_targets = parse_make_targets()
    commands = set(context.get('checks', []))
    for check in validation_index['checks']:
        target = check['make_target']
        if target not in make_targets:
            fail(f'VALIDATION_INDEX target missing from Makefile: {target}')
        if not command_covers_target(commands, target):
            fail(f'CONTEXT_PACK.json checks missing make target: make {target}')
        for script in check.get('scripts', []):
            require(script)
    for required in ['make gate', 'make publish-audit', 'make preflight', 'make package-release']:
        if required not in commands:
            fail(f'CONTEXT_PACK.json checks missing required command: {required}')

    if policy.get('operator_context_pack') != 'CONTEXT_PACK.json':
        fail('publishing/CANONICAL_POLICY.json operator_context_pack mismatch')
    if policy.get('context_pack_validator') != 'scripts/validate_context_pack.py':
        fail('publishing/CANONICAL_POLICY.json context_pack_validator mismatch')
    if policy.get('context_pack_schema') != 'schemas/context_pack.schema.json':
        fail('publishing/CANONICAL_POLICY.json context_pack_schema mismatch')

    if 'context_pack_sha256' not in manifest.get('identity_digests', {}):
        fail('RELEASE_MANIFEST.json missing context_pack_sha256 identity digest')

    print(f'context-pack-validate: OK ({len(commands)} command hints, {len(context["read_order"])} read-order entries)')


if __name__ == '__main__':
    main()
