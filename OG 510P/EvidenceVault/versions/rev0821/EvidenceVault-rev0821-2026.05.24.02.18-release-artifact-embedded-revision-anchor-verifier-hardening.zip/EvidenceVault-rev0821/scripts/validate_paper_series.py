#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_PAPERS = [
    "ev_acceptability_kernel.tex",
    "ev_interpretation_profiles.tex",
    "ev_streamfold.tex",
    "ev_zkrtp.tex",
    "ev_pact_ocf.tex",
]
TRANSIENT_SUFFIXES = {".aux", ".bbl", ".blg", ".fdb_latexmk", ".fls", ".log", ".out", ".toc", ".synctex.gz"}
SAFE_PATH = re.compile(r"^[A-Za-z0-9_./+@()=-]+$")


def fail(msg: str) -> None:
    print(f"paper-series-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def load_json(rel: str):
    path = ROOT / rel
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"invalid JSON in {rel}: {exc}")


def require_existing_rel(value: str, label: str) -> None:
    if not isinstance(value, str) or not value:
        fail(f"{label} must be a non-empty string")
    if value.startswith(("/", "./", "../")) or "\\" in value or ".." in Path(value).parts:
        fail(f"{label} is unsafe: {value}")
    if not SAFE_PATH.fullmatch(value):
        fail(f"{label} contains unexpected characters: {value}")
    path = ROOT / value.rstrip("/")
    if value.endswith("/"):
        if not path.is_dir():
            fail(f"{label} references missing directory: {value}")
    elif not path.exists():
        fail(f"{label} references missing path: {value}")


def validate_extraction_map() -> None:
    data = load_json("papers/EXTRACTION_MAP.json")
    if sorted(data) != sorted(EXPECTED_PAPERS):
        fail(f"EXTRACTION_MAP keys must match canonical papers: {EXPECTED_PAPERS}")
    for paper in EXPECTED_PAPERS:
        meta = data.get(paper)
        if not isinstance(meta, dict):
            fail(f"EXTRACTION_MAP[{paper}] must be an object")
        for key in ("from", "kind", "note"):
            if key not in meta:
                fail(f"EXTRACTION_MAP[{paper}] missing {key}")
        sources = meta["from"]
        if not isinstance(sources, list) or not sources:
            fail(f"EXTRACTION_MAP[{paper}].from must be a non-empty list")
        if not isinstance(meta["kind"], str) or not meta["kind"].strip():
            fail(f"EXTRACTION_MAP[{paper}].kind must be non-empty")
        if not isinstance(meta["note"], str) or len(meta["note"].strip()) < 20:
            fail(f"EXTRACTION_MAP[{paper}].note must be substantive")
        for idx, item in enumerate(sources):
            if not isinstance(item, str) or not item.strip():
                fail(f"EXTRACTION_MAP[{paper}].from[{idx}] must be a non-empty string")
            item = item.strip()
            if item.startswith("(") and item.endswith(")"):
                continue
            # Non-parenthesized provenance entries are archive-relative path pointers.
            require_existing_rel(item, f"EXTRACTION_MAP[{paper}].from[{idx}]")


def validate_tex_pdf_surfaces() -> None:
    tex_files = sorted(p.name for p in (ROOT / "papers").glob("ev_*.tex"))
    if tex_files != sorted(EXPECTED_PAPERS):
        fail(f"canonical TeX set mismatch: {tex_files}")
    for tex_name in EXPECTED_PAPERS:
        tex_path = ROOT / "papers" / tex_name
        pdf_name = tex_name[:-4] + ".pdf"
        paper_pdf = ROOT / "papers" / pdf_name
        root_pdf = ROOT / pdf_name
        if not tex_path.is_file():
            fail(f"missing canonical TeX paper: papers/{tex_name}")
        if not paper_pdf.is_file():
            fail(f"missing compiled paper PDF: papers/{pdf_name}")
        if not root_pdf.is_file():
            fail(f"missing root PDF mirror: {pdf_name}")
        if paper_pdf.stat().st_size != root_pdf.stat().st_size:
            fail(f"root PDF mirror size mismatch for {pdf_name}")
        if sha256_file(paper_pdf) != sha256_file(root_pdf):
            fail(f"root PDF mirror digest mismatch for {pdf_name}")

    for path in (ROOT / "papers").iterdir():
        if path.is_file():
            name = path.name
            if any(name.endswith(suffix) for suffix in TRANSIENT_SUFFIXES):
                fail(f"transient paper build output present: papers/{name}")


def validate_title_indexes() -> None:
    paper_index = (ROOT / "PAPER_SERIES_INDEX.md").read_text(encoding="utf-8")
    series = (ROOT / "SERIES.md").read_text(encoding="utf-8")
    catalog = (ROOT / "CATALOG.md").read_text(encoding="utf-8")
    for tex_name in EXPECTED_PAPERS:
        if f"`{tex_name}`" not in paper_index:
            fail(f"PAPER_SERIES_INDEX.md missing {tex_name}")
        if f"papers/{tex_name}" not in series:
            fail(f"SERIES.md missing papers/{tex_name}")
    for rel in [
        "papers/EXTRACTION_MAP.json",
        "papers/",
        "renders/legacy_pdfs/",
        "artifacts/repro_packs/",
    ]:
        if rel not in catalog:
            fail(f"CATALOG.md missing lookup pointer {rel}")


def main() -> None:
    validate_extraction_map()
    validate_tex_pdf_surfaces()
    validate_title_indexes()
    print(f"paper-series-validate: OK ({len(EXPECTED_PAPERS)} canonical papers, root PDF mirrors verified)")


if __name__ == "__main__":
    main()
