#!/usr/bin/env python3
"""Validate the current changelog/history anchor.

The changelog is a human-facing history surface, not an executable ledger.  This
bounded validator checks only the properties needed for release recovery: the
current entry is first, it agrees with the revision receipt/release manifest,
the previous revision follows it, the current/recent release-lineage headings are unique and descending,
and the package emitted by the current manifest is named in the current entry.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HEADING_RE = re.compile(r'^## (rev\d{4})(?:\s+[-—]\s+(\d{4}-\d{2}-\d{2}))?\s*$')
BUNDLE_RE = re.compile(r'EvidenceVault-rev\d{4}-\d{4}\.\d{2}\.\d{2}\.\d{2}\.\d{2}-[A-Za-z0-9_.-]+\.zip')
RECENT_HISTORY_FLOOR = 770


def fail(msg: str) -> None:
    print(f'changelog-validate: FAIL: {msg}', file=sys.stderr)
    sys.exit(1)


def load_json(rel: str) -> dict:
    try:
        data = json.loads((ROOT / rel).read_text(encoding='utf-8'))
    except Exception as exc:  # pragma: no cover - diagnostic wrapper
        fail(f'invalid JSON in {rel}: {exc}')
    if not isinstance(data, dict):
        fail(f'{rel} must be a JSON object')
    return data


def heading_number(revision: str) -> int:
    return int(revision.removeprefix('rev'))


def section_text(lines: list[str], start: int, next_start: int | None) -> str:
    end = next_start if next_start is not None else len(lines)
    return '\n'.join(lines[start:end])


def main() -> None:
    release = load_json('RELEASE_MANIFEST.json')
    receipt = load_json('REVISION_RECEIPT.json')
    anchors = load_json('REVISION_ANCHORS.json')
    archive_index = load_json('ARCHIVE_INDEX.json')
    policy = load_json('publishing/CANONICAL_POLICY.json')

    history = release.get('history_anchor')
    if history != 'CHANGELOG.md' or receipt.get('history_anchor') != history:
        fail('release manifest and revision receipt must point at CHANGELOG.md')
    if policy.get('canonical_history') != history:
        fail('canonical policy history anchor mismatch')

    path = ROOT / history
    if not path.exists():
        fail(f'missing history anchor: {history}')
    data = path.read_bytes()
    if b'\r' in data:
        fail('CHANGELOG.md must use LF line endings')
    if not data.endswith(b'\n'):
        fail('CHANGELOG.md must end with a newline')
    text = data.decode('utf-8')
    lines = text.splitlines()
    if not lines or lines[0].strip() != '# Revision changelog':
        fail('CHANGELOG.md must start with # Revision changelog')

    headings: list[tuple[int, str, str | None]] = []
    for lineno, line in enumerate(lines, start=1):
        m = HEADING_RE.match(line)
        if m:
            headings.append((lineno, m.group(1), m.group(2)))
    if len(headings) < 2:
        fail('CHANGELOG.md must contain at least current and previous revision headings')

    current = release['revision']
    previous = release['previous_revision']
    if receipt.get('revision') != current or anchors.get('current_revision', {}).get('revision') != current:
        fail('release manifest, revision receipt, and revision anchors disagree on current revision')
    if receipt.get('previous_revision') != previous or anchors.get('current_revision', {}).get('previous_revision') != previous:
        fail('release manifest, revision receipt, and revision anchors disagree on previous revision')

    first_lineno, first_revision, first_date = headings[0]
    if first_revision != current:
        fail(f'first changelog heading at line {first_lineno} must be {current}, got {first_revision}')
    if first_date != release['date'] or first_date != receipt['date']:
        fail('current changelog heading date must match release manifest and revision receipt')

    second_lineno, second_revision, _ = headings[1]
    if second_revision != previous:
        fail(f'second changelog heading at line {second_lineno} must be previous revision {previous}, got {second_revision}')

    # Govern the current/recent release-lineage prefix.  Older carried-forward
    # changelog sections may preserve historical-label anomalies under the audit
    # directory's historical-label rule; this check protects the current release
    # recovery path without rewriting those older witnesses.
    seen: set[str] = set()
    previous_number: int | None = None
    recent_count = 0
    for lineno, revision, _date in headings:
        number = heading_number(revision)
        if number < RECENT_HISTORY_FLOOR:
            break
        recent_count += 1
        if revision in seen:
            fail(f'duplicate recent changelog revision heading: {revision} at line {lineno}')
        seen.add(revision)
        if previous_number is not None and number >= previous_number:
            fail(f'recent changelog revision headings must descend; {revision} at line {lineno} follows rev{previous_number:04d}')
        previous_number = number
    if recent_count < 2:
        fail('recent changelog prefix must contain at least current and previous revision headings')

    top_section = section_text(lines, headings[0][0] - 1, headings[1][0] - 1)
    bullet_count = sum(1 for line in top_section.splitlines() if line.startswith('- '))
    if bullet_count < 3:
        fail('current changelog section must contain at least three bullet entries')
    bundle = release['bundle']
    if bundle not in top_section:
        fail('current changelog section must name the current release bundle')
    if set(BUNDLE_RE.findall(top_section)) != {bundle}:
        fail('current changelog section must mention only the current named bundle')
    if 'scripts/validate_changelog.py' not in top_section:
        fail('current changelog section must mention the changelog validator')

    archive_bundles = archive_index.get('bundles', [])
    if not archive_bundles or archive_bundles[0].get('revision') != current:
        fail('ARCHIVE_INDEX.json top bundle must match current revision')
    if archive_bundles[0].get('bundle') != bundle:
        fail('ARCHIVE_INDEX.json top bundle name must match release manifest')

    print(f'changelog-validate: OK ({recent_count} recent headings checked, {len(headings)} total headings, current={current})')


if __name__ == '__main__':
    main()
