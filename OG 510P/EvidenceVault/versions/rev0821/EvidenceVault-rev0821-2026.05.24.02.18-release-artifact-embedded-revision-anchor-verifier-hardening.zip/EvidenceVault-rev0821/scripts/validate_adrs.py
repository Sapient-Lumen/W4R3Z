#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_VALIDATOR = 'scripts/validate_adrs.py'
EXPLICIT_PRINCIPLE = 'explicit_decision_index_companion_validation'


def fail(msg: str) -> None:
    print(f"adrs-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def load_json(rel: str):
    path = ROOT / rel
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        fail(f"invalid JSON in {rel}: {exc}")


def require(rel: str) -> None:
    path = ROOT / rel.rstrip('/')
    if rel.endswith('/'):
        if not path.is_dir():
            fail(f"missing directory: {rel}")
    elif not path.exists():
        fail(f"missing path: {rel}")


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = '/'.join(str(p) for p in err.path) or '<root>'
        fail(f"{label} schema violation at {where}: {err.message}")


def render_markdown(index: dict) -> str:
    lines = [
        '# EvidenceVault ADR index',
        '',
        index['purpose'],
        '',
        '| ADR | Status | Date | Summary | Path |',
        '| --- | --- | --- | --- | --- |',
    ]
    for entry in index['entries']:
        lines.append(f"| {entry['id'].replace('-', ' ')} | {entry['status'].title()} | {entry['date']} | {entry['summary']} | `{entry['path']}` |")
    return '\n'.join(lines).rstrip() + '\n'


def validate_markdown_companion(index: dict) -> None:
    data = (ROOT / 'ADR_INDEX.md').read_bytes()
    if b'\r' in data:
        fail('ADR_INDEX.md must use LF line endings')
    if not data.endswith(b'\n'):
        fail('ADR_INDEX.md must end with a newline')
    if data.decode('utf-8') != render_markdown(index):
        fail('ADR_INDEX.md must exactly mirror render_markdown(ADR_INDEX.json)')


def validate_validation_index(validation_index: dict) -> None:
    checks = {check['id']: check for check in validation_index.get('checks', [])}
    check = checks.get('adr-check')
    if check is None:
        fail('VALIDATION_INDEX.json missing adr-check')
    if check.get('make_target') != 'adr-check':
        fail('adr-check make_target mismatch')
    if check.get('scripts') != [EXPECTED_VALIDATOR]:
        fail('adr-check scripts mismatch')
    needed = {
        'ADR_INDEX.md', 'ADR_INDEX.json', 'adrs/', 'schemas/adr_index.schema.json',
        EXPECTED_VALIDATOR, 'OPENING_CONTRACT.json', 'OPENING_SURFACE_CONFORMANCE.json',
        'CONTROL_SURFACES.json', 'LIFECYCLE_GATES.json', 'CONTEXT_PACK.json',
        'publishing/CANONICAL_POLICY.json', 'RELEASE_MANIFEST.json'
    }
    missing = sorted(needed - set(check.get('validates', [])))
    if missing:
        fail(f'adr-check validates missing surfaces: {missing}')


def main() -> None:
    index = load_json('ADR_INDEX.json')
    schema = load_json('schemas/adr_index.schema.json')
    opening = load_json('OPENING_CONTRACT.json')
    conformance = load_json('OPENING_SURFACE_CONFORMANCE.json')
    control = load_json('CONTROL_SURFACES.json')
    gates = load_json('LIFECYCLE_GATES.json')
    policy = load_json('publishing/CANONICAL_POLICY.json')
    manifest = load_json('RELEASE_MANIFEST.json')
    context = load_json('CONTEXT_PACK.json')
    validation_index = load_json('VALIDATION_INDEX.json')

    validate_against_schema(index, schema, 'ADR_INDEX.json')
    if index['project'] != 'EvidenceVault':
        fail('ADR index project must be EvidenceVault')
    validate_markdown_companion(index)

    ids = set()
    for entry in index['entries']:
        eid = entry['id']
        if eid in ids:
            fail(f'duplicate ADR id: {eid}')
        ids.add(eid)
        require(entry['path'])
        for rel in entry['links']:
            require(rel.rstrip('/'))
        text = (ROOT / entry['path']).read_text(encoding='utf-8')
        if not text.startswith(f"# {eid.replace('-', ' ')}: {entry['title']}"):
            fail(f"{entry['path']} heading must start with '# {eid.replace('-', ' ')}: {entry['title']}'")

    require('adrs/README.md')
    require('adrs/0000-template.md')
    if not {'ADR_INDEX.md', 'ADR_INDEX.json'}.issubset({item['path'] for item in opening.get('entrypoints', [])}):
        fail('opening contract entrypoints missing ADR index surfaces')
    if not {'ADR_INDEX.md', 'ADR_INDEX.json'}.issubset(set(conformance.get('required_root_entrypoints', []))):
        fail('opening surface conformance missing ADR index surfaces')
    if not {'ADR_INDEX.md', 'ADR_INDEX.json'}.issubset({item['path'] for item in control['surfaces']['opening_and_resumption']}):
        fail('control surfaces opening_and_resumption missing ADR index surfaces')
    if EXPECTED_VALIDATOR not in {item['path'] for item in control['surfaces']['validation_and_packaging']}:
        fail('control surfaces validation_and_packaging missing ADR validator')

    for rel in gates['gates']['careful_revision_pass']['checks'] + gates['gates']['named_bundle_packaging']['checks']:
        require(rel)
    if EXPECTED_VALIDATOR not in gates['gates']['careful_revision_pass']['checks']:
        fail('careful_revision_pass checks missing ADR validator')
    if EXPECTED_VALIDATOR not in gates['gates']['named_bundle_packaging']['checks']:
        fail('named_bundle_packaging checks missing ADR validator')

    if policy.get('adr_index_markdown') != 'ADR_INDEX.md':
        fail('publishing/CANONICAL_POLICY.json adr_index_markdown mismatch')
    if policy.get('adr_index_json') != 'ADR_INDEX.json':
        fail('publishing/CANONICAL_POLICY.json adr_index_json mismatch')
    if policy.get('adr_index_validator') != EXPECTED_VALIDATOR:
        fail('publishing/CANONICAL_POLICY.json adr_index_validator mismatch')
    if policy.get('adr_index_schema') != 'schemas/adr_index.schema.json':
        fail('publishing/CANONICAL_POLICY.json adr_index_schema mismatch')
    if EXPLICIT_PRINCIPLE not in '\n'.join(policy.get('principles', [])):
        fail('publishing/CANONICAL_POLICY.json principles missing explicit decision-index companion validation')

    kms = context.get('key_machine_surfaces', {})
    if kms.get('adr_index_markdown') != 'ADR_INDEX.md':
        fail('CONTEXT_PACK.json key_machine_surfaces adr_index_markdown mismatch')
    if kms.get('adr_index_json') != 'ADR_INDEX.json':
        fail('CONTEXT_PACK.json key_machine_surfaces adr_index_json mismatch')
    if kms.get('adr_validator') != EXPECTED_VALIDATOR:
        fail('CONTEXT_PACK.json key_machine_surfaces adr_validator mismatch')

    validate_validation_index(validation_index)
    if manifest.get('adr_index_markdown') != 'ADR_INDEX.md':
        fail('RELEASE_MANIFEST.json adr_index_markdown mismatch')
    if manifest.get('adr_index_json') != 'ADR_INDEX.json':
        fail('RELEASE_MANIFEST.json adr_index_json mismatch')
    print(f'adrs-validate: OK ({len(index["entries"])} entries, exact Markdown/JSON companion)')


if __name__ == '__main__':
    main()
