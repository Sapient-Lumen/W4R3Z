#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
STATES = {'candidate', 'hold', 'published_ready'}
DIR_MAP = {'candidate': 'candidates', 'hold': 'hold', 'published_ready': 'published_ready'}


def fail(msg: str) -> None:
    print(f"scaffold-queue-item: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def slugify(s: str) -> str:
    out = []
    prev_dash = False
    for ch in s.lower():
        if ch.isalnum():
            out.append(ch)
            prev_dash = False
        else:
            if not prev_dash:
                out.append('-')
                prev_dash = True
    slug = ''.join(out).strip('-')
    return slug or 'item'


def queue_field_line(label: str, value: object) -> str:
    text = '' if value is None else str(value)
    return f"- {label}: {text}" if text else f"- {label}:"


def render_queue_item_markdown(data: dict) -> str:
    lines = [
        '# Release queue item',
        '',
        f"- Date: {data.get('date', '')}",
        f"- Queue item id: {data.get('item_id', '')}",
        f"- State: {data.get('state', '')}",
        f"- Scope: {data.get('scope', '')}",
        f"- Owner: {data.get('owner', '')}",
        queue_field_line('Decision id', data.get('decision_id')),
        queue_field_line('Public release id', data.get('public_release_id')),
        '',
        '## Tracked paths',
    ]
    tracked = data.get('tracked_paths', [])
    if tracked:
        lines.extend(f"- `{rel}`" for rel in tracked)
    else:
        lines.append('-')
    lines.extend([
        '',
        '## Summary',
        data.get('summary', ''),
        '',
        '## Next action',
        data.get('next_action') or '-',
    ])
    return '\n'.join(lines) + '\n'


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--state', required=True, choices=sorted(STATES))
    ap.add_argument('--date', required=True)
    ap.add_argument('--slug', required=True)
    ap.add_argument('--scope', required=True)
    ap.add_argument('--owner', required=True)
    ap.add_argument('--summary', required=True)
    ap.add_argument('--decision-id')
    ap.add_argument('--public-release-id')
    ap.add_argument('--next-action', default='')
    ap.add_argument('--path', action='append', default=[])
    args = ap.parse_args()

    slug = slugify(args.slug)
    basename = f"{args.date}-{slug}"
    item_id = f"EV-QUEUE-{args.date}-{slug}"
    state_dir = ROOT / 'release_queue' / DIR_MAP[args.state]
    state_dir.mkdir(parents=True, exist_ok=True)
    json_path = state_dir / f"{basename}.json"
    md_path = state_dir / f"{basename}.md"
    if json_path.exists() or md_path.exists():
        fail(f"queue item already exists: {basename}")

    data = {
        'item_id': item_id,
        'date': args.date,
        'state': args.state,
        'scope': args.scope,
        'owner': args.owner,
        'tracked_paths': args.path,
        'summary': args.summary,
    }
    if args.decision_id:
        data['decision_id'] = args.decision_id
    if args.public_release_id:
        data['public_release_id'] = args.public_release_id
    if args.next_action:
        data['next_action'] = args.next_action

    md = render_queue_item_markdown(data)


    json_path.write_text(json.dumps(data, indent=2) + '\n')
    md_path.write_text(md)
    print(f"scaffold-queue-item: OK ({json_path.relative_to(ROOT).as_posix()})")


if __name__ == '__main__':
    main()
