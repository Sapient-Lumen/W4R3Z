#!/usr/bin/env python3
"""Validate artifact/cert asset indexes and curated canonical-path pointers."""
from __future__ import annotations

import csv
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIELDS = ["path", "project", "kind", "bytes", "sha256"]
HEX64 = re.compile(r"^[0-9a-f]{64}$")
INDEXES = [
    {
        "label": "artifacts",
        "root": ROOT / "artifacts",
        "json": ROOT / "artifacts" / "ARTIFACTS_INDEX.json",
        "csv": ROOT / "artifacts" / "ARTIFACTS_INDEX.csv",
        "excluded": {"ARTIFACTS_INDEX.json", "ARTIFACTS_INDEX.csv"},
    },
    {
        "label": "certs",
        "root": ROOT / "certs",
        "json": ROOT / "certs" / "CERTS_INDEX.json",
        "csv": ROOT / "certs" / "CERTS_INDEX.csv",
        "excluded": {"CERTS_INDEX.json", "CERTS_INDEX.csv"},
    },
]
CANONICAL_FIELDS = {"removed_path", "canonical_path", "sha256", "size"}


def fail(msg: str) -> None:
    print(f"asset-index-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def project_for(rel: str) -> str:
    parts = rel.split("/")
    if parts[0] == "artifacts":
        if len(parts) > 2 and parts[1] == "curated":
            return parts[2] if parts[2] != "README.md" else "curated"
        if len(parts) > 2 and parts[1] == "repro_packs":
            return "repro_packs"
        return parts[1] if len(parts) > 1 else ""
    if parts[0] == "certs":
        if len(parts) > 2 and parts[1] == "curated":
            return parts[2] if parts[2] != "README.md" else "curated"
        return "root"
    return parts[0]


def kind_for(path: Path) -> str:
    suffixes = path.suffixes
    if len(suffixes) >= 2 and suffixes[-2:] == [".tar", ".gz"]:
        return "tar.gz"
    if len(suffixes) >= 2 and suffixes[-2:] == [".dsse", ".json"]:
        return "dsse.json"
    if len(suffixes) >= 2 and suffixes[-2:] == [".statement", ".json"]:
        return "statement.json"
    if len(suffixes) >= 2 and suffixes[-2:] == [".schema", ".json"]:
        return "schema.json"
    return path.suffix.lower().lstrip(".") or "file"


def row_for(path: Path) -> dict[str, object]:
    rel = path.relative_to(ROOT).as_posix()
    return {
        "path": rel,
        "project": project_for(rel),
        "kind": kind_for(path),
        "bytes": path.stat().st_size,
        "sha256": sha256_file(path),
    }


def expected_rows(root: Path, excluded: set[str]) -> list[dict[str, object]]:
    rows = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        if path.name in excluded and path.parent == root:
            continue
        rows.append(row_for(path))
    return rows


def load_json(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"invalid JSON in {path.relative_to(ROOT).as_posix()}: {exc}")


def validate_index(spec: dict[str, object]) -> int:
    label = str(spec["label"])
    root = spec["root"]
    json_path = spec["json"]
    csv_path = spec["csv"]
    excluded = spec["excluded"]
    assert isinstance(root, Path)
    assert isinstance(json_path, Path)
    assert isinstance(csv_path, Path)
    assert isinstance(excluded, set)

    if not root.is_dir():
        fail(f"missing {label} root: {root.relative_to(ROOT).as_posix()}/")
    expected = expected_rows(root, excluded)
    rows = load_json(json_path)
    if not isinstance(rows, list):
        fail(f"{json_path.relative_to(ROOT).as_posix()} must be a list")
    seen: set[str] = set()
    for i, row in enumerate(rows, start=1):
        if not isinstance(row, dict):
            fail(f"{label} JSON index row {i} is not an object")
        if list(row.keys()) != FIELDS:
            fail(f"{label} JSON index row {i} fields mismatch: {list(row.keys())}")
        rel = row["path"]
        if not isinstance(rel, str) or not rel.startswith(f"{label}/"):
            fail(f"{label} JSON index row {i} has invalid path: {rel!r}")
        if rel in seen:
            fail(f"{label} JSON index duplicates path: {rel}")
        seen.add(rel)
        if Path(rel).name in excluded and Path(rel).parent == Path(label):
            fail(f"{label} JSON index must not include index file: {rel}")
        if not isinstance(row["project"], str) or not row["project"]:
            fail(f"{label} JSON index row {i} has empty project")
        if not isinstance(row["kind"], str) or not row["kind"]:
            fail(f"{label} JSON index row {i} has empty kind")
        if not isinstance(row["bytes"], int) or row["bytes"] < 0:
            fail(f"{label} JSON index row {i} has invalid byte count")
        if not isinstance(row["sha256"], str) or not HEX64.fullmatch(row["sha256"]):
            fail(f"{label} JSON index row {i} has invalid sha256")
    if rows != expected:
        expected_paths = [r["path"] for r in expected]
        actual_paths = [r.get("path") for r in rows if isinstance(r, dict)]
        missing = sorted(set(expected_paths) - set(actual_paths))[:10]
        extra = sorted(set(actual_paths) - set(expected_paths))[:10]
        mismatched = [p for p, a, e in zip(actual_paths, rows, expected) if p == e["path"] and a != e][:10]
        fail(f"{label} index mismatch; missing={missing}, extra={extra}, mismatched={mismatched}")

    with csv_path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != FIELDS:
            fail(f"{label} CSV index fieldnames mismatch: {reader.fieldnames}")
        csv_rows = list(reader)
    expected_csv = [{k: str(v) for k, v in row.items()} for row in expected]
    if csv_rows != expected_csv:
        fail(f"{label} CSV index does not exactly mirror JSON index")
    return len(expected)


def safe_relative_path(value: str, label: str) -> Path:
    if not isinstance(value, str) or not value:
        fail(f"{label} must be a non-empty string")
    path = Path(value)
    if path.is_absolute() or "\\" in value or ".." in path.parts:
        fail(f"{label} is unsafe: {value}")
    return path


def validate_canonical_paths() -> tuple[int, int]:
    files = sorted((ROOT / "artifacts" / "curated").rglob("CANONICAL_PATHS.json"))
    entries = 0
    for path in files:
        data = load_json(path)
        if not isinstance(data, list) or not data:
            fail(f"{path.relative_to(ROOT).as_posix()} must be a non-empty list")
        seen_removed: set[str] = set()
        for i, item in enumerate(data, start=1):
            if not isinstance(item, dict) or set(item) != CANONICAL_FIELDS:
                fail(f"{path.relative_to(ROOT).as_posix()} entry {i} fields mismatch")
            removed = safe_relative_path(item["removed_path"], "removed_path")
            canonical_rel = safe_relative_path(item["canonical_path"], "canonical_path")
            if removed.as_posix() in seen_removed:
                fail(f"{path.relative_to(ROOT).as_posix()} duplicates removed_path {removed.as_posix()}")
            seen_removed.add(removed.as_posix())
            removed_abs = path.parent / removed
            if removed_abs.exists():
                fail(f"canonical-path entry still exists at removed path: {removed_abs.relative_to(ROOT).as_posix()}")
            canonical_abs = ROOT / canonical_rel
            if not canonical_abs.is_file():
                fail(f"canonical-path target missing: {canonical_rel.as_posix()}")
            if not isinstance(item["size"], int) or item["size"] != canonical_abs.stat().st_size:
                fail(f"canonical-path size mismatch for {canonical_rel.as_posix()}")
            if not isinstance(item["sha256"], str) or item["sha256"] != sha256_file(canonical_abs):
                fail(f"canonical-path sha256 mismatch for {canonical_rel.as_posix()}")
            entries += 1
    return len(files), entries


def main() -> None:
    counts = {str(spec["label"]): validate_index(spec) for spec in INDEXES}
    canonical_files, canonical_entries = validate_canonical_paths()
    print(
        "asset-index-validate: OK "
        f"(artifacts={counts['artifacts']}, certs={counts['certs']}, "
        f"canonical_path_files={canonical_files}, canonical_path_entries={canonical_entries})"
    )


if __name__ == "__main__":
    main()
