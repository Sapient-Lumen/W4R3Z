#!/usr/bin/env python3
"""Validate archive filesystem and ZIP-mode policy before shipping.

Digest manifests prove byte identity, and package_release.py proves the emitted
ZIP payload.  This checker owns the filesystem hygiene layer that can still
silently drift in a working tree: unsafe path components, Unicode/casefold
collisions, special files/symlinks, transient platform files, and executable-bit
leakage.  The archive's command surface invokes scripts through explicit
interpreters (`python3 ...`, `bash ...`), so regular shipped files use a
least-privilege 0644 mode; package_release.py then preserves that mode into the
portable ZIP regular-file metadata.
"""
from __future__ import annotations

import re
import stat
import sys
import unicodedata
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAX_REL_PATH_LEN = 220
EXPECTED_FILE_MODE = 0o644
RESERVED_WINDOWS_NAMES = {
    'CON', 'PRN', 'AUX', 'NUL',
    *{f'COM{i}' for i in range(1, 10)},
    *{f'LPT{i}' for i in range(1, 10)},
}
TRANSIENT_NAMES = {
    '.DS_Store', 'Thumbs.db', 'desktop.ini',
}
TRANSIENT_SUFFIXES = {
    '.pyc', '.pyo', '.swp', '.swo', '.tmp', '.bak', '.orig', '.rej',
}
CONTROL_CHARS = re.compile(r'[\x00-\x1f\x7f]')


def fail(msg: str) -> None:
    print(f'filesystem-policy-validate: FAIL: {msg}', file=sys.stderr)
    sys.exit(1)


def rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def validate_component(component: str, path_label: str) -> None:
    if component in {'', '.', '..'}:
        fail(f'unsafe path component {component!r} in {path_label}')
    if component != unicodedata.normalize('NFC', component):
        fail(f'path component is not NFC-normalized in {path_label}: {component!r}')
    if CONTROL_CHARS.search(component):
        fail(f'control character in path component for {path_label}: {component!r}')
    if '\\' in component or '/' in component:
        fail(f'path separator embedded in component for {path_label}: {component!r}')
    if component[0].isspace() or component[-1].isspace():
        fail(f'leading/trailing whitespace in path component for {path_label}: {component!r}')
    if component.endswith('.'):
        fail(f'trailing dot in path component for {path_label}: {component!r}')
    if any(ch in component for ch in ':*?"<>|'):
        fail(f'Windows-unsafe character in path component for {path_label}: {component!r}')
    stem = component.split('.', 1)[0].upper()
    if stem in RESERVED_WINDOWS_NAMES:
        fail(f'Windows-reserved path component in {path_label}: {component!r}')


def validate_path_shape(path: Path) -> None:
    r = rel(path)
    if len(r) > MAX_REL_PATH_LEN:
        fail(f'relative path exceeds {MAX_REL_PATH_LEN} characters: {r}')
    for part in Path(r).parts:
        validate_component(part, r)
    if path.name in TRANSIENT_NAMES:
        fail(f'transient platform file present: {r}')
    if path.suffix.lower() in TRANSIENT_SUFFIXES:
        fail(f'transient/patch byproduct file present: {r}')
    if path.name.endswith('~'):
        fail(f'editor backup file present: {r}')
    if '__pycache__' in path.parts:
        fail(f'Python bytecode cache directory present: {r}')


def validate_file_mode(path: Path) -> None:
    r = rel(path)
    st = path.lstat()
    mode_type = stat.S_IFMT(st.st_mode)
    if mode_type != stat.S_IFREG:
        fail(f'shipped path is not a regular file: {r} ({stat.filemode(st.st_mode)})')
    actual_mode = stat.S_IMODE(st.st_mode)
    if actual_mode != EXPECTED_FILE_MODE:
        fail(f'shipped file mode must be {EXPECTED_FILE_MODE:o}: {r} has {actual_mode:o}')
    if st.st_size == 0:
        fail(f'zero-byte file present: {r}')


def main() -> None:
    rels: list[str] = []
    file_count = 0
    for path in sorted(ROOT.rglob('*')):
        # Use lstat semantics so symlinks cannot hide behind their target type.
        if path.is_symlink():
            fail(f'symlink present in shipped tree: {rel(path)}')
        if path.is_dir():
            validate_path_shape(path)
            continue
        validate_path_shape(path)
        validate_file_mode(path)
        rels.append(rel(path))
        file_count += 1

    for label, normalizer in {
        'casefold': lambda s: s.casefold(),
        'NFC+casefold': lambda s: unicodedata.normalize('NFC', s).casefold(),
    }.items():
        by_norm: dict[str, list[str]] = defaultdict(list)
        for r in rels:
            by_norm[normalizer(r)].append(r)
        collisions = [paths for paths in by_norm.values() if len(paths) > 1]
        if collisions:
            fail(f'{label} path collision: {collisions[0]}')

    root_zip_like = [r for r in rels if '/' not in r and r.endswith(('.zip', '.tar', '.tar.gz', '.tgz'))]
    if root_zip_like:
        fail(f'archive artifact must not be shipped inside archive root: {root_zip_like[0]}')

    print(
        'filesystem-policy-validate: OK '
        f'({file_count} regular files, mode {EXPECTED_FILE_MODE:o}, safe/collision-free paths)'
    )


if __name__ == '__main__':
    main()
