#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_VALIDATOR = 'scripts/validate_rfcs.py'
EXPLICIT_PRINCIPLE = 'explicit_decision_index_companion_validation'


def fail(msg: str) -> None:
    print(f"rfcs-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def load_json(rel: str):
    path = ROOT / rel
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        fail(f"invalid JSON in {rel}: {exc}")


def require(rel: str) -> None:
    target = ROOT / rel.rstrip('/')
    if rel.endswith('/'):
        if not target.is_dir():
            fail(f"missing directory: {rel}")
    elif not target.exists():
        fail(f"missing path: {rel}")


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = '/'.join(str(p) for p in err.path) or '<root>'
        fail(f"{label} schema violation at {where}: {err.message}")


def render_markdown(index: dict) -> str:
    lines = [
        '# EvidenceVault RFC index',
        '',
        index['purpose'],
        '',
        '| RFC | Status | Date | Summary | Path |',
        '| --- | --- | --- | --- | --- |',
    ]
    for entry in index['entries']:
        lines.append(f"| {entry['id'].replace('-', ' ')} | {entry['status'].title()} | {entry['date']} | {entry['summary']} | `{entry['path']}` |")
    return '\n'.join(lines).rstrip() + '\n'


def validate_markdown_companion(index: dict) -> None:
    data = (ROOT / 'RFC_INDEX.md').read_bytes()
    if b'\r' in data:
        fail('RFC_INDEX.md must use LF line endings')
    if not data.endswith(b'\n'):
        fail('RFC_INDEX.md must end with a newline')
    if data.decode('utf-8') != render_markdown(index):
        fail('RFC_INDEX.md must exactly mirror render_markdown(RFC_INDEX.json)')


def validate_validation_index(validation_index: dict) -> None:
    checks = {check['id']: check for check in validation_index.get('checks', [])}
    check = checks.get('rfc-check')
    if check is None:
        fail('VALIDATION_INDEX.json missing rfc-check')
    if check.get('make_target') != 'rfc-check':
        fail('rfc-check make_target mismatch')
    if check.get('scripts') != [EXPECTED_VALIDATOR]:
        fail('rfc-check scripts mismatch')
    needed = {
        'RFC_INDEX.md', 'RFC_INDEX.json', 'rfcs/', 'schemas/rfc_index.schema.json',
        EXPECTED_VALIDATOR, 'ASSIMILATION_LEDGER.md', 'ASSIMILATION_LEDGER.json',
        'OPENING_CONTRACT.json', 'OPENING_SURFACE_CONFORMANCE.json', 'CONTROL_SURFACES.json',
        'LIFECYCLE_GATES.json', 'CONTEXT_PACK.json', 'publishing/CANONICAL_POLICY.json',
        'RELEASE_MANIFEST.json'
    }
    missing = sorted(needed - set(check.get('validates', [])))
    if missing:
        fail(f'rfc-check validates missing surfaces: {missing}')


def main() -> None:
    index = load_json('RFC_INDEX.json')
    schema = load_json('schemas/rfc_index.schema.json')
    opening = load_json('OPENING_CONTRACT.json')
    conformance = load_json('OPENING_SURFACE_CONFORMANCE.json')
    control = load_json('CONTROL_SURFACES.json')
    gates = load_json('LIFECYCLE_GATES.json')
    policy = load_json('publishing/CANONICAL_POLICY.json')
    manifest = load_json('RELEASE_MANIFEST.json')
    ledger = load_json('ASSIMILATION_LEDGER.json')
    context = load_json('CONTEXT_PACK.json')
    validation_index = load_json('VALIDATION_INDEX.json')

    validate_against_schema(index, schema, 'RFC_INDEX.json')
    if index['project'] != 'EvidenceVault':
        fail('RFC index project must be EvidenceVault')
    validate_markdown_companion(index)

    ledger_by_id = {record['id']: record for record in ledger['records']}
    ids = set()
    for entry in index['entries']:
        eid = entry['id']
        if eid in ids:
            fail(f'duplicate RFC id: {eid}')
        ids.add(eid)
        require(entry['path'])
        for rel in entry['links']:
            require(rel)
        origin = entry['origin_record']
        if origin not in ledger_by_id:
            fail(f'{eid} origin_record missing from ASSIMILATION_LEDGER.json: {origin}')
        origin_record = ledger_by_id[origin]
        if origin_record['status'] == 'adopted':
            fail(f'{eid} origin_record should not point at an adopted assimilation record')
        if origin_record.get('related_rfc') != eid:
            fail(f'{eid} origin_record does not link back via related_rfc')
        text = (ROOT / entry['path']).read_text(encoding='utf-8')
        if not text.startswith(f"# {eid.replace('-', ' ')}: {entry['title']}"):
            fail(f"{entry['path']} heading must start with '# {eid.replace('-', ' ')}: {entry['title']}'")

    require('rfcs/README.md')
    require('rfcs/RFC-0000-template.md')
    if not {'RFC_INDEX.md', 'RFC_INDEX.json'}.issubset({item['path'] for item in opening.get('entrypoints', [])}):
        fail('opening contract entrypoints missing RFC index surfaces')
    if not {'RFC_INDEX.md', 'RFC_INDEX.json'}.issubset(set(conformance.get('required_root_entrypoints', []))):
        fail('opening surface conformance missing RFC index surfaces')
    if not {'RFC_INDEX.md', 'RFC_INDEX.json'}.issubset({item['path'] for item in control['surfaces']['opening_and_resumption']}):
        fail('control surfaces opening_and_resumption missing RFC index surfaces')

    comparison_paths = {item['path'] for item in control['surfaces']['comparison_and_assimilation']}
    expected = {'ASSIMILATION_LEDGER.md','ASSIMILATION_LEDGER.json','RFC_INDEX.md','RFC_INDEX.json','CURRENT_FRONTIER.md','CURRENT_FRONTIER.json','scripts/validate_assimilation_ledger.py','scripts/validate_rfcs.py','scripts/validate_current_frontier.py'}
    if comparison_paths != expected:
        fail('comparison_and_assimilation section must contain assimilation + RFC + current-frontier surfaces and validators')
    if EXPECTED_VALIDATOR not in {item['path'] for item in control['surfaces']['validation_and_packaging']}:
        fail('control surfaces validation_and_packaging missing RFC validator')

    gate = gates['gates'].get('comparison_and_pattern_assimilation')
    if gate is None:
        fail('lifecycle gates missing comparison_and_pattern_assimilation gate')
    for rel in gate['required_surfaces'] + gate['checks']:
        require(rel)
    if 'RFC_INDEX.md' not in gate['required_surfaces'] or 'RFC_INDEX.json' not in gate['required_surfaces']:
        fail('comparison_and_pattern_assimilation required_surfaces missing RFC index surfaces')
    if EXPECTED_VALIDATOR not in gate['checks']:
        fail('comparison_and_pattern_assimilation checks missing RFC validator')
    if EXPECTED_VALIDATOR not in gates['gates']['careful_revision_pass']['checks']:
        fail('careful_revision_pass checks missing RFC validator')
    if EXPECTED_VALIDATOR not in gates['gates']['named_bundle_packaging']['checks']:
        fail('named_bundle_packaging checks missing RFC validator')

    if policy.get('rfc_index_markdown') != 'RFC_INDEX.md':
        fail('publishing/CANONICAL_POLICY.json rfc_index_markdown mismatch')
    if policy.get('rfc_index_json') != 'RFC_INDEX.json':
        fail('publishing/CANONICAL_POLICY.json rfc_index_json mismatch')
    if policy.get('rfc_index_validator') != EXPECTED_VALIDATOR:
        fail('publishing/CANONICAL_POLICY.json rfc_index_validator mismatch')
    if policy.get('rfc_index_schema') != 'schemas/rfc_index.schema.json':
        fail('publishing/CANONICAL_POLICY.json rfc_index_schema mismatch')
    if EXPLICIT_PRINCIPLE not in '\n'.join(policy.get('principles', [])):
        fail('publishing/CANONICAL_POLICY.json principles missing explicit decision-index companion validation')

    kms = context.get('key_machine_surfaces', {})
    if kms.get('rfc_index_markdown') != 'RFC_INDEX.md':
        fail('CONTEXT_PACK.json key_machine_surfaces rfc_index_markdown mismatch')
    if kms.get('rfc_index_json') != 'RFC_INDEX.json':
        fail('CONTEXT_PACK.json key_machine_surfaces rfc_index_json mismatch')
    if kms.get('rfc_validator') != EXPECTED_VALIDATOR:
        fail('CONTEXT_PACK.json key_machine_surfaces rfc_validator mismatch')

    validate_validation_index(validation_index)
    if manifest.get('rfc_index_markdown') != 'RFC_INDEX.md':
        fail('RELEASE_MANIFEST.json rfc_index_markdown mismatch')
    if manifest.get('rfc_index_json') != 'RFC_INDEX.json':
        fail('RELEASE_MANIFEST.json rfc_index_json mismatch')
    print(f'rfcs-validate: OK ({len(index["entries"])} entries, exact Markdown/JSON companion)')


if __name__ == '__main__':
    main()
