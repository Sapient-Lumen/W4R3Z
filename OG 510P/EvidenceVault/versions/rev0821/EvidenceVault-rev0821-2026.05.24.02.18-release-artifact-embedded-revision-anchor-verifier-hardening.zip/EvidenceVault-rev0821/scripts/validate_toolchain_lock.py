#!/usr/bin/env python3
"""Validate the governed toolchain/replay surface.

The archive's validators are local and deterministic only if the runtime layer is
explicit enough to replay.  This check keeps the top-level TOOLCHAIN_LOCK JSON,
its exact Markdown companion, required Python modules, required shell commands,
and package ZIP assumptions aligned with REVISION_RECEIPT.json and
scripts/package_release.py.
"""
from __future__ import annotations

import ast
import importlib
import importlib.metadata
import json
import platform
import re
import shutil
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
LOCK_JSON = ROOT / 'TOOLCHAIN_LOCK.json'
LOCK_MD = ROOT / 'TOOLCHAIN_LOCK.md'
SCHEMA = ROOT / 'schemas' / 'toolchain_lock.schema.json'
PACKAGE_RELEASE = ROOT / 'scripts' / 'package_release.py'


def fail(msg: str) -> None:
    print(f'toolchain-lock-validate: FAIL: {msg}', file=sys.stderr)
    sys.exit(1)


def load_json(rel: str | Path):
    path = ROOT / rel if isinstance(rel, str) else rel
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        label = path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else str(path)
        fail(f'invalid JSON in {label}: {exc}')


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = '/'.join(str(p) for p in err.path) or '<root>'
        fail(f'{label} schema violation at {where}: {err.message}')


def receipt_timestamp_local(receipt: dict) -> str:
    stamp = receipt['timestamp']
    date = stamp[:10].replace('.', '-')
    hour = stamp[11:13]
    minute = stamp[14:16]
    return f'{date}T{hour}:{minute}:00-0400'


def parse_version(value: str) -> tuple[int, ...]:
    parts = re.findall(r'\d+', value.split('+', 1)[0])
    if not parts:
        fail(f'cannot parse version: {value!r}')
    return tuple(int(part) for part in parts)


def version_gte(actual: str, minimum: str) -> bool:
    a = parse_version(actual)
    b = parse_version(minimum)
    n = max(len(a), len(b))
    a = a + (0,) * (n - len(a))
    b = b + (0,) * (n - len(b))
    return a >= b


def render_markdown(lock: dict) -> str:
    lines = [
        '# EvidenceVault toolchain lock',
        '',
        'This file is the exact human-facing companion to `TOOLCHAIN_LOCK.json`.',
        'It records the local replay floor, observed package versions, and deterministic package assumptions checked by `scripts/validate_toolchain_lock.py`.',
        '',
        '## Environment policy',
        f"- Revision: `{lock['revision']}`",
        f"- Generated: `{lock['generated_at_local']}`",
        f"- Version enforcement: `{lock['policy']['version_enforcement']}`",
        f"- Strict exact replay: `{str(lock['policy']['strict_exact_replay']).lower()}`",
        f"- Bytecode policy: `{lock['policy']['bytecode_policy']}`",
        f"- Observed versions are witnesses: `{str(lock['policy']['observed_versions_are_witnesses']).lower()}`",
        '',
        '## Python runtime',
        f"- Executable hint: `{lock['python_runtime']['executable_hint']}`",
        f"- Implementation: `{lock['python_runtime']['implementation']}`",
        f"- Minimum version: `{lock['python_runtime']['minimum_version']}`",
        f"- Observed version: `{lock['python_runtime']['observed_version']}`",
        f"- Required for: {', '.join(f'`{item}`' for item in lock['python_runtime']['required_for'])}",
        '',
        '## Required Python packages',
        '',
        '| Distribution | Import | Minimum | Observed | Required | Used by | Reason |',
        '| --- | --- | --- | --- | --- | --- | --- |',
    ]
    for pkg in lock['python_packages']:
        used_by = ', '.join(f"`{item}`" for item in pkg['used_by'])
        lines.append(
            f"| `{pkg['distribution']}` | `{pkg['import_name']}` | `{pkg['minimum_version']}` | `{pkg['observed_version']}` | `{str(pkg['required']).lower()}` | {used_by} | {pkg['reason']} |"
        )

    lines.extend([
        '',
        '## Required external commands',
        '',
        '| Command | Required | Scope | Reason |',
        '| --- | --- | --- | --- |',
    ])
    for command in lock['external_commands']:
        lines.append(
            f"| `{command['command']}` | `{str(command['required']).lower()}` | {command['scope']} | {command['reason']} |"
        )

    policy = lock['package_policy']
    lines.extend([
        '',
        '## Package policy',
        f"- ZIP timestamp: `{policy['zip_timestamp']}`",
        f"- ZIP compression: `{policy['zip_compression']}`",
        f"- ZIP compresslevel: `{policy['zip_compresslevel']}`",
        f"- ZIP entry order: `{policy['zip_entry_order']}`",
        f"- ZIP file mode policy: `{policy['zip_file_mode_policy']}`",
        f"- ZIP extra fields: `{policy['zip_extra_fields']}`",
        f"- ZIP directory entries: `{policy['zip_directory_entries']}`",
        f"- Manifest verification command: `{policy['manifest_verification_command']}`",
        '',
        '## Boundary note',
        '',
        'The lock intentionally records a minimum-supported replay floor plus observed-version witnesses rather than forbidding newer compatible patch releases.',
        'The package-policy rows are stricter: they must match `scripts/package_release.py` because ZIP identity depends on those constants.',
    ])
    return '\n'.join(lines).rstrip() + '\n'


def literal_value(script: Path, variable: str):
    tree = ast.parse(script.read_text(encoding='utf-8'), filename=str(script))
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == variable:
                    try:
                        return ast.literal_eval(node.value)
                    except Exception as exc:
                        fail(f'{script.relative_to(ROOT)} {variable} is not a literal value: {exc}')
    fail(f'{script.relative_to(ROOT)} missing literal {variable}')


def validate_runtime(lock: dict) -> None:
    runtime = lock['python_runtime']
    if platform.python_implementation() != runtime['implementation']:
        fail(f"Python implementation mismatch: expected {runtime['implementation']}, got {platform.python_implementation()}")
    actual_version = '.'.join(str(part) for part in sys.version_info[:3])
    if not version_gte(actual_version, runtime['minimum_version']):
        fail(f"Python {actual_version} is below minimum {runtime['minimum_version']}")
    if not version_gte(runtime['observed_version'], runtime['minimum_version']):
        fail('recorded observed Python version is below declared minimum')


def validate_packages(lock: dict) -> tuple[int, int]:
    required = 0
    optional = 0
    seen: set[str] = set()
    for pkg in lock['python_packages']:
        key = pkg['distribution']
        if key in seen:
            fail(f'duplicate Python package entry: {key}')
        seen.add(key)
        if pkg['required']:
            required += 1
        else:
            optional += 1
        try:
            importlib.import_module(pkg['import_name'])
        except Exception as exc:
            if pkg['required']:
                fail(f"required Python import {pkg['import_name']} failed: {exc}")
            continue
        try:
            actual = importlib.metadata.version(pkg['distribution'])
        except importlib.metadata.PackageNotFoundError:
            if pkg['required']:
                fail(f"required Python distribution not found: {pkg['distribution']}")
            continue
        if not version_gte(actual, pkg['minimum_version']):
            fail(f"{pkg['distribution']} {actual} is below minimum {pkg['minimum_version']}")
        if not version_gte(pkg['observed_version'], pkg['minimum_version']):
            fail(f"recorded observed version for {pkg['distribution']} is below declared minimum")
    return required, optional


def validate_commands(lock: dict) -> int:
    required = 0
    seen: set[str] = set()
    for entry in lock['external_commands']:
        command = entry['command']
        if command in seen:
            fail(f'duplicate external command entry: {command}')
        seen.add(command)
        if entry['required']:
            required += 1
            if shutil.which(command) is None:
                fail(f'required external command not found on PATH: {command}')
    return required


def validate_package_policy(lock: dict) -> None:
    policy = lock['package_policy']
    timestamp = literal_value(PACKAGE_RELEASE, 'FIXED_ZIP_TIMESTAMP')
    if timestamp != (1980, 1, 1, 0, 0, 0):
        fail(f'package_release.py FIXED_ZIP_TIMESTAMP drift: {timestamp!r}')
    if policy['zip_timestamp'] != '1980-01-01T00:00:00':
        fail('TOOLCHAIN_LOCK.json zip_timestamp mismatch')
    compresslevel = literal_value(PACKAGE_RELEASE, 'ZIP_COMPRESSLEVEL')
    if compresslevel != policy['zip_compresslevel']:
        fail('package_release.py ZIP_COMPRESSLEVEL drift')
    text = PACKAGE_RELEASE.read_text(encoding='utf-8')
    required_snippets = {
        'ZIP_COMPRESSION = zipfile.ZIP_DEFLATED': 'ZIP_DEFLATED compression',
        'for path in sorted(ROOT.rglob': 'lexicographic shipped-file ordering',
        'info.extra': 'ZIP extra-field refusal',
        'any(name.endswith(\'/\') for name in actual)': 'ZIP directory-entry refusal',
        'regular_file_external_attr(mode)': 'regular-file mode encoding',
        'sha256sum -c MANIFEST.sha256 >/dev/null': 'preflight manifest command reference',
    }
    preflight_text = (ROOT / 'scripts' / 'publish_preflight.sh').read_text(encoding='utf-8')
    for snippet, label in list(required_snippets.items()):
        target_text = preflight_text if snippet.startswith('sha256sum') else text
        if snippet not in target_text:
            fail(f'missing package policy snippet for {label}: {snippet}')


def validate_wiring(lock: dict) -> None:
    policy = load_json('publishing/CANONICAL_POLICY.json')
    if policy.get('toolchain_lock_json') != 'TOOLCHAIN_LOCK.json':
        fail('publishing/CANONICAL_POLICY.json toolchain_lock_json mismatch')
    if policy.get('toolchain_lock_markdown') != 'TOOLCHAIN_LOCK.md':
        fail('publishing/CANONICAL_POLICY.json toolchain_lock_markdown mismatch')
    if policy.get('toolchain_lock_schema') != 'schemas/toolchain_lock.schema.json':
        fail('publishing/CANONICAL_POLICY.json toolchain_lock_schema mismatch')
    if policy.get('toolchain_lock_validator') != 'scripts/validate_toolchain_lock.py':
        fail('publishing/CANONICAL_POLICY.json toolchain_lock_validator mismatch')
    if 'explicit_toolchain_lock_validation' not in policy.get('principles', []):
        fail('publishing/CANONICAL_POLICY.json principles missing explicit_toolchain_lock_validation')

    context = load_json('CONTEXT_PACK.json')
    kms = context.get('key_machine_surfaces', {})
    for key, expected in {
        'toolchain_lock_json': 'TOOLCHAIN_LOCK.json',
        'toolchain_lock_markdown': 'TOOLCHAIN_LOCK.md',
        'toolchain_lock_validator': 'scripts/validate_toolchain_lock.py',
    }.items():
        if kms.get(key) != expected:
            fail(f'CONTEXT_PACK.json key_machine_surfaces {key} mismatch')
    checks = set(context.get('checks', []))
    for command in ('make toolchain-check', 'python3 scripts/validate_toolchain_lock.py'):
        if command not in checks:
            fail(f'CONTEXT_PACK.json checks missing {command}')

    validation = load_json('VALIDATION_INDEX.json')
    checks_by_id = {check['id']: check for check in validation.get('checks', [])}
    check = checks_by_id.get('toolchain-check')
    if check is None:
        fail('VALIDATION_INDEX.json missing toolchain-check')
    if check.get('scripts') != ['scripts/validate_toolchain_lock.py']:
        fail('toolchain-check scripts mismatch')
    needed = {
        'TOOLCHAIN_LOCK.json',
        'TOOLCHAIN_LOCK.md',
        'schemas/toolchain_lock.schema.json',
        'scripts/validate_toolchain_lock.py',
        'scripts/package_release.py',
        'scripts/publish_preflight.sh',
        'REVISION_RECEIPT.json',
        'VALIDATION_INDEX.json',
        'CONTEXT_PACK.json',
        'CONTROL_SURFACES.json',
        'LIFECYCLE_GATES.json',
        'publishing/CANONICAL_POLICY.json',
    }
    if not needed.issubset(set(check.get('validates', []))):
        missing = sorted(needed - set(check.get('validates', [])))
        fail(f'toolchain-check validates missing surfaces: {missing}')
    for comp_name in ('gate', 'publish-audit'):
        comp = next((item for item in validation.get('composite_targets', []) if item.get('make_target') == comp_name), None)
        if comp is None or 'toolchain-check' not in comp.get('includes', []):
            fail(f'VALIDATION_INDEX.json {comp_name} composite missing toolchain-check')

    control = load_json('CONTROL_SURFACES.json')
    validation_paths = {item['path'] for item in control['surfaces']['validation_and_packaging']}
    all_control_paths = {item['path'] for section in control['surfaces'].values() for item in section}
    for rel in ('TOOLCHAIN_LOCK.json', 'TOOLCHAIN_LOCK.md', 'schemas/toolchain_lock.schema.json', 'scripts/validate_toolchain_lock.py'):
        if rel not in validation_paths:
            fail(f'CONTROL_SURFACES.json validation_and_packaging missing {rel}')
    for rel in needed - {'REVISION_RECEIPT.json'}:
        if rel not in all_control_paths:
            fail(f'CONTROL_SURFACES.json missing governed toolchain-adjacent surface {rel}')

    gates = load_json('LIFECYCLE_GATES.json')
    for gate_id in ('careful_revision_pass', 'publish_audit', 'named_bundle_packaging'):
        if 'scripts/validate_toolchain_lock.py' not in set(gates['gates'][gate_id].get('checks', [])):
            fail(f'LIFECYCLE_GATES.json {gate_id} missing toolchain-lock validator')
    if 'scripts/validate_toolchain_lock.py' not in set(gates['gates']['cold_open_and_reentry'].get('checks', [])):
        fail('LIFECYCLE_GATES.json cold_open_and_reentry missing toolchain-lock validator')

    anchors = load_json('REVISION_ANCHORS.json')
    if 'scripts/validate_toolchain_lock.py' not in set(anchors.get('validators', [])):
        fail('REVISION_ANCHORS.json validators missing toolchain-lock validator')
    anchored = {item['path'] for item in anchors.get('anchored_surfaces', [])}
    if 'TOOLCHAIN_LOCK.json' not in anchored:
        fail('REVISION_ANCHORS.json anchored surfaces missing TOOLCHAIN_LOCK.json')


def main() -> None:
    lock = load_json(LOCK_JSON)
    schema = load_json(SCHEMA)
    receipt = load_json('REVISION_RECEIPT.json')
    validate_against_schema(lock, schema, 'TOOLCHAIN_LOCK.json')
    if lock['revision'] != receipt['revision']:
        fail('TOOLCHAIN_LOCK.json revision must match REVISION_RECEIPT.json')
    if lock['generated_at_local'] != receipt_timestamp_local(receipt):
        fail('TOOLCHAIN_LOCK.json generated_at_local must match REVISION_RECEIPT.json timestamp')
    if lock.get('validator') != 'scripts/validate_toolchain_lock.py':
        fail('TOOLCHAIN_LOCK.json validator mismatch')
    if LOCK_MD.read_text(encoding='utf-8') != render_markdown(lock):
        fail('TOOLCHAIN_LOCK.md must exactly mirror TOOLCHAIN_LOCK.json')
    validate_runtime(lock)
    required_packages, optional_packages = validate_packages(lock)
    required_commands = validate_commands(lock)
    validate_package_policy(lock)
    validate_wiring(lock)
    print(f'toolchain-lock-validate: OK ({required_packages} required Python packages, {optional_packages} optional Python packages, {required_commands} required external commands)')


if __name__ == '__main__':
    main()
