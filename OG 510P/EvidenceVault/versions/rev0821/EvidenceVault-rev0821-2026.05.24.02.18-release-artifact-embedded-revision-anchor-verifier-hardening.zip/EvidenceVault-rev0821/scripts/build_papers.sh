#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PAPERS_DIR="${ROOT_DIR}/papers"
TMP_ROOT="$(mktemp -d)"
cleanup() {
  rm -rf "$TMP_ROOT"
}
trap cleanup EXIT

# Build each one-file TeX paper into a transient temp dir, then refresh the
# canonical convenience PDFs under papers/ directly.
# Notes:
# - Some papers embed a .bib via filecontents* and require BibTeX.
# - Builds run in transient temp dirs so the shipped archive keeps only the
#   canonical papers/*.pdf set and no duplicate convenience mirror.

for tex in "$PAPERS_DIR"/*.tex; do
  base="$(basename "$tex" .tex)"
  work="$TMP_ROOT/$base"
  mkdir -p "$work"
  cp "$tex" "$work/$base.tex"

  # First pass
  (cd "$work" && pdflatex -interaction=nonstopmode "$base.tex" >/dev/null)

  # BibTeX if needed
  if grep -q "\bibliography{" "$work/$base.tex" ; then
    (cd "$work" && bibtex "$base" >/dev/null || true)
  fi

  # Finish passes
  (cd "$work" && pdflatex -interaction=nonstopmode "$base.tex" >/dev/null)
  (cd "$work" && pdflatex -interaction=nonstopmode "$base.tex" >/dev/null)

  cp "$work/$base.pdf" "$PAPERS_DIR/$base.pdf"
  echo "built: papers/$base.pdf"
done

echo "PDFs are in: $PAPERS_DIR"
