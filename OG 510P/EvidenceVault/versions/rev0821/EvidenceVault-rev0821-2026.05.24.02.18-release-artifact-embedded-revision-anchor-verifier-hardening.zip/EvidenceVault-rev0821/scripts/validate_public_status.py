#!/usr/bin/env python3
"""Validate the current public/internal status bridge.

The latest public release can intentionally lag the internal archive revision.
This validator makes that relationship explicit: the bridge must mirror the
current archive receipt/manifest/anchors and the latest public-release pointer,
while also proving that the status bridge itself does not claim a new public
payload release or queue transition.
"""
from __future__ import annotations

import hashlib
import json
import re
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
STATUS_JSON = ROOT / 'PUBLIC_STATUS.json'
STATUS_MD = ROOT / 'PUBLIC_STATUS.md'
SCHEMA = ROOT / 'schemas' / 'public_status.schema.json'
EXPECTED_VALIDATOR = 'scripts/validate_public_status.py'


def fail(msg: str) -> None:
    print(f'public-status-validate: FAIL: {msg}', file=sys.stderr)
    sys.exit(1)


def load_json(rel: str | Path):
    path = ROOT / rel if isinstance(rel, str) else rel
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        label = path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else str(path)
        fail(f'invalid JSON in {label}: {exc}')


def require(rel: str) -> None:
    if not isinstance(rel, str) or not rel:
        fail(f'empty/non-string path reference: {rel!r}')
    if rel.startswith('/') or '\\' in rel or '..' in Path(rel).parts:
        fail(f'unsafe path reference: {rel}')
    target = ROOT / rel.rstrip('/')
    if rel.endswith('/'):
        if not target.is_dir():
            fail(f'missing directory: {rel}')
    elif not target.exists():
        fail(f'missing path: {rel}')


def sha256_file(rel: str) -> str:
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = '/'.join(str(p) for p in err.path) or '<root>'
        fail(f'{label} schema violation at {where}: {err.message}')


def receipt_timestamp_local(receipt: dict) -> str:
    stamp = receipt.get('timestamp', '')
    parts = stamp.split('.')
    if len(parts) != 5 or not all(part.isdigit() for part in parts):
        fail('REVISION_RECEIPT.json timestamp must use YYYY.MM.DD.HH.MM format')
    year, month, day, hour, minute = parts
    return f'{year}-{month}-{day}T{hour}:{minute}:00-0400'


def rev_num(revision: str) -> int:
    match = re.fullmatch(r'rev(\d{4})', revision)
    if not match:
        fail(f'invalid revision label: {revision!r}')
    return int(match.group(1))


def format_items(items: list[str]) -> str:
    return ', '.join(f'`{item}`' for item in items)


def render_markdown(status: dict) -> str:
    latest = status['latest_public_release']
    current = status['current_archive']
    rel = status['relationship']
    lines = [
        '# Public/internal status bridge',
        '',
        'This file is the exact human-facing companion to `PUBLIC_STATUS.json`.',
        'It records the relationship between the latest governed public release and the current internal archive revision without widening the public payload surface.',
        '',
        f"- Revision: `{status['revision']}`",
        f"- Previous revision: `{status['previous_revision']}`",
        f"- Generated: `{status['generated_at_local']}`",
        f"- Scope: `{status['policy']['scope']}`",
        f"- Validator: `{status['validator']}`",
        '',
        '## Current internal archive',
        '',
        f"- Revision: `{current['revision']}`",
        f"- Previous revision: `{current['previous_revision']}`",
        f"- Date: `{current['date']}`",
        f"- Timestamp: `{current['timestamp']}`",
        f"- Bundle: `{current['bundle']}`",
        f"- Archive name: `{current['archive_name']}`",
        f"- Root directory: `{current['repo_root']}`",
        '',
        '## Latest public release',
        '',
        f"- Release ID: `{latest['release_id']}`",
        f"- Date: `{latest['date']}`",
        f"- Status: `{latest['status']}`",
        f"- Revision: `{latest['revision']}`",
        f"- Decision: `{latest['decision_id']}`",
        f"- Queue item: `{latest['queue_item_id']}`",
        f"- Notes: `{latest['notes_path']}`",
        f"- Artifact manifest: `{latest['artifact_manifest']}`",
        f"- Artifact ZIP: `{latest['artifact_zip']}`",
        f"- Public surface manifest: `{latest['public_surface_manifest']}`",
        f"- Public surface manifest SHA-256: `{latest['public_surface_manifest_sha256']}`",
        f"- Public surface snapshot: `{latest['public_surface_snapshot']}`",
        f"- Public surface snapshot SHA-256: `{latest['public_surface_snapshot_sha256']}`",
        '',
        '## Relationship',
        '',
        f"- Current internal revision: `{rel['current_internal_revision']}`",
        f"- Latest public revision: `{rel['latest_public_revision']}`",
        f"- Internal revision delta: `{rel['internal_revision_delta']}`",
        f"- Latest public release pointer is latest: `{str(rel['latest_public_release_is_latest']).lower()}`",
        f"- Public surface state: {rel['public_surface_state']}",
        f"- Public payload widened: `{str(rel['public_payload_widened']).lower()}`",
        f"- Queue state changed: `{str(rel['queue_state_changed']).lower()}`",
        f"- Canonical paper/source payload changed: `{str(rel['canonical_paper_or_source_payload_changed']).lower()}`",
        f"- Status bridge surface: {format_items(rel['status_bridge_surface'])}",
        '',
        '## Boundary',
        '',
        status['policy']['truth_boundary'],
        '',
        '## Supporting surfaces',
        '',
    ]
    lines.extend(f'- `{item}`' for item in status['supporting_surfaces'])
    return '\n'.join(lines).rstrip() + '\n'


def validate_status(status: dict) -> None:
    receipt = load_json('REVISION_RECEIPT.json')
    manifest = load_json('RELEASE_MANIFEST.json')
    anchors = load_json('REVISION_ANCHORS.json')
    latest = load_json('published/releases/LATEST.json')
    ledger = load_json('published/releases/RELEASE_INDEX.json')
    policy = load_json('publishing/CANONICAL_POLICY.json')
    validation = load_json('VALIDATION_INDEX.json')
    control = load_json('CONTROL_SURFACES.json')
    gates = load_json('LIFECYCLE_GATES.json')
    context = load_json('CONTEXT_PACK.json')
    frontier = load_json('CURRENT_FRONTIER.json')

    if status['revision'] != receipt['revision']:
        fail('PUBLIC_STATUS.json revision must match REVISION_RECEIPT.json')
    if status['previous_revision'] != receipt['previous_revision']:
        fail('PUBLIC_STATUS.json previous_revision must match REVISION_RECEIPT.json')
    if status['generated_at_local'] != receipt_timestamp_local(receipt):
        fail('PUBLIC_STATUS.json generated_at_local must match REVISION_RECEIPT.json timestamp')
    if status['validator'] != EXPECTED_VALIDATOR:
        fail('PUBLIC_STATUS.json validator mismatch')
    if status['policy']['markdown_companion'] != 'PUBLIC_STATUS.md':
        fail('PUBLIC_STATUS.json markdown companion mismatch')
    if status['policy']['schema'] != 'schemas/public_status.schema.json':
        fail('PUBLIC_STATUS.json schema pointer mismatch')

    current = status['current_archive']
    expected_current = {
        'revision': receipt['revision'],
        'previous_revision': receipt['previous_revision'],
        'date': receipt['date'],
        'timestamp': receipt['timestamp'],
        'bundle': manifest['bundle'],
        'archive_name': manifest['archive_name'],
        'repo_root': ROOT.name,
    }
    if current != expected_current:
        fail(f'PUBLIC_STATUS.json current_archive mismatch: expected {expected_current!r}, got {current!r}')
    if anchors['current_revision']['bundle'] != current['bundle'] or anchors['current_revision']['root_dir'] != ROOT.name:
        fail('REVISION_ANCHORS.json current revision does not match PUBLIC_STATUS current archive')

    latest_expected = {key: latest[key] for key in status['latest_public_release']}
    if status['latest_public_release'] != latest_expected:
        fail('PUBLIC_STATUS.json latest_public_release must mirror published/releases/LATEST.json')
    release_records = ledger.get('release_records', [])
    if ledger.get('latest_release_id') != latest['release_id']:
        fail('published/releases/RELEASE_INDEX.json latest_release_id mismatch')
    matching = [item for item in release_records if item.get('release_id') == latest['release_id']]
    if len(matching) != 1:
        fail('published/releases/RELEASE_INDEX.json must contain exactly one latest release record')
    for key in ('revision', 'decision_id', 'queue_item_id', 'public_surface_snapshot', 'artifact_manifest', 'artifact_zip'):
        if matching[0].get(key) != latest[key]:
            fail(f'published/releases/RELEASE_INDEX.json latest release {key} mismatch')

    for rel in [
        latest['notes_path'],
        latest['artifact_manifest'],
        latest['artifact_zip'],
        latest['public_surface_manifest'],
        latest['public_surface_snapshot'],
        *status['relationship']['status_bridge_surface'],
        *status['supporting_surfaces'],
    ]:
        require(rel)

    rel = status['relationship']
    if rel['current_internal_revision'] != receipt['revision']:
        fail('relationship.current_internal_revision mismatch')
    if rel['latest_public_revision'] != latest['revision']:
        fail('relationship.latest_public_revision mismatch')
    expected_delta = rev_num(receipt['revision']) - rev_num(latest['revision'])
    if rel['internal_revision_delta'] != expected_delta:
        fail(f'relationship.internal_revision_delta mismatch: expected {expected_delta}')
    if expected_delta < 0:
        fail('latest public revision cannot be ahead of current internal revision')
    if set(rel['status_bridge_surface']) != {'PUBLIC_STATUS.json', 'PUBLIC_STATUS.md'}:
        fail('relationship.status_bridge_surface must name PUBLIC_STATUS.json and PUBLIC_STATUS.md')
    if latest['revision'] == receipt['revision'] and rel['public_payload_widened'] is False:
        fail('public payload widening cannot be false when latest public release equals current internal revision')
    if sha256_file(latest['public_surface_snapshot']) != latest['public_surface_snapshot_sha256']:
        fail('latest public surface snapshot digest mismatch')

    for key, expected in {
        'public_status_json': 'PUBLIC_STATUS.json',
        'public_status_markdown': 'PUBLIC_STATUS.md',
        'public_status_schema': 'schemas/public_status.schema.json',
        'public_status_validator': EXPECTED_VALIDATOR,
    }.items():
        if policy.get(key) != expected:
            fail(f'publishing/CANONICAL_POLICY.json {key} mismatch')
    if 'explicit_public_status_bridge_validation' not in policy.get('principles', []):
        fail('publishing/CANONICAL_POLICY.json principles missing explicit_public_status_bridge_validation')

    checks = {check['id']: check for check in validation.get('checks', [])}
    check = checks.get('public-status-check')
    if check is None:
        fail('VALIDATION_INDEX.json missing public-status-check')
    if check.get('scripts') != [EXPECTED_VALIDATOR]:
        fail('public-status-check scripts mismatch')
    required_validates = {
        'PUBLIC_STATUS.json',
        'PUBLIC_STATUS.md',
        'schemas/public_status.schema.json',
        EXPECTED_VALIDATOR,
        'REVISION_RECEIPT.json',
        'RELEASE_MANIFEST.json',
        'REVISION_ANCHORS.json',
        'published/releases/LATEST.json',
        'published/releases/RELEASE_INDEX.json',
        'published/PUBLIC_SURFACE.json',
        'publishing/CANONICAL_POLICY.json',
        'VALIDATION_INDEX.json',
        'CONTROL_SURFACES.json',
        'LIFECYCLE_GATES.json',
        'CONTEXT_PACK.json',
        'CURRENT_FRONTIER.json',
    }
    if not required_validates.issubset(set(check.get('validates', []))):
        fail(f'public-status-check validates missing surfaces: {sorted(required_validates - set(check.get("validates", [])))}')

    validation_paths = {item['path'] for item in control.get('surfaces', {}).get('validation_and_packaging', [])}
    public_paths = {item['path'] for item in control.get('surfaces', {}).get('public_surface_and_release_history', [])}
    for item in ('PUBLIC_STATUS.json', 'PUBLIC_STATUS.md', 'schemas/public_status.schema.json', EXPECTED_VALIDATOR):
        if item not in validation_paths and item not in public_paths:
            fail(f'CONTROL_SURFACES.json missing public-status surface: {item}')

    for gate_id in ('careful_revision_pass', 'publish_audit', 'named_bundle_packaging'):
        refs = set(gates['gates'][gate_id].get('authoritative_sequence', []) + gates['gates'][gate_id].get('required_surfaces', []) + gates['gates'][gate_id].get('checks', []))
        if EXPECTED_VALIDATOR not in refs:
            fail(f'LIFECYCLE_GATES.json {gate_id} missing public-status validator')
    if 'make public-status-check' not in context.get('checks', []):
        fail('CONTEXT_PACK.json checks missing make public-status-check')
    if f'python3 {EXPECTED_VALIDATOR}' not in context.get('checks', []):
        fail('CONTEXT_PACK.json checks missing direct public-status validator')
    kms = context.get('key_machine_surfaces', {})
    for key, expected in {'public_status_json': 'PUBLIC_STATUS.json', 'public_status_markdown': 'PUBLIC_STATUS.md', 'public_status_validator': EXPECTED_VALIDATOR}.items():
        if kms.get(key) != expected:
            fail(f'CONTEXT_PACK.json key_machine_surfaces.{key} mismatch')

    linked = set()
    for lane in frontier.get('lanes', []):
        linked.update(lane.get('linked_surfaces', []))
    if 'PUBLIC_STATUS.json' not in linked or EXPECTED_VALIDATOR not in linked:
        fail('CURRENT_FRONTIER.json missing public-status linkage')

    anchored = {item['path'] for item in anchors.get('anchored_surfaces', [])}
    if 'PUBLIC_STATUS.json' not in anchored:
        fail('REVISION_ANCHORS.json missing PUBLIC_STATUS.json anchor')
    if EXPECTED_VALIDATOR not in set(anchors.get('validators', [])):
        fail('REVISION_ANCHORS.json validators missing public-status validator')
    if manifest.get('public_status_json') != 'PUBLIC_STATUS.json' or manifest.get('public_status_markdown') != 'PUBLIC_STATUS.md':
        fail('RELEASE_MANIFEST.json public-status pointers mismatch')
    if 'public_status_json_sha256' not in manifest.get('identity_digests', {}):
        fail('RELEASE_MANIFEST.json missing public_status_json_sha256 identity digest')


def main() -> None:
    for rel in ('PUBLIC_STATUS.json', 'PUBLIC_STATUS.md', 'schemas/public_status.schema.json'):
        require(rel)
    status = load_json(STATUS_JSON)
    schema = load_json(SCHEMA)
    validate_against_schema(status, schema, 'PUBLIC_STATUS.json')
    expected_md = render_markdown(status)
    if STATUS_MD.read_text(encoding='utf-8') != expected_md:
        fail('PUBLIC_STATUS.md must exactly mirror PUBLIC_STATUS.json')
    validate_status(status)
    print(f"public-status-validate: OK (current {status['revision']}, latest public {status['latest_public_release']['revision']}, delta {status['relationship']['internal_revision_delta']})")


if __name__ == '__main__':
    main()
