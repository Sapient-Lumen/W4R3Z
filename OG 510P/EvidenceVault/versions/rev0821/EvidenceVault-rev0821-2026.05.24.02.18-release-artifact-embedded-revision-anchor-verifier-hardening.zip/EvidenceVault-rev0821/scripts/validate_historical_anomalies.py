#!/usr/bin/env python3
"""Validate the governed historical anomaly ledger.

Older archive history can contain carried-forward duplicate labels or retained
audit-witness body labels that should not be normalized away.  This validator
makes that exception set explicit: it rescans CHANGELOG.md, ARCHIVE_INDEX.json,
and retained AUDIT inventory witnesses; requires every carried-forward anomaly to
be named in AUDIT/HISTORICAL_ANOMALIES.json; requires the Markdown companion to
render exactly; and fails immediately if a recent changelog/archive-index
duplicate/order anomaly appears above the governed floor.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
LEDGER = ROOT / 'AUDIT' / 'HISTORICAL_ANOMALIES.json'
MARKDOWN = ROOT / 'AUDIT' / 'HISTORICAL_ANOMALIES.md'
SCHEMA = ROOT / 'schemas' / 'historical_anomalies.schema.json'
RECENT_HISTORY_FLOOR = 770
REV_RE = re.compile(r'\brev(\d{4})\b')
CHANGELOG_HEADING_RE = re.compile(r'^## (rev\d{4})\b', re.MULTILINE)
AUDIT_WITNESS_RE = re.compile(r'_rev(\d{4})\.md$')
CURRENT_WITNESS = 'AUDIT/historical_anomaly_ledger_inventory_rev0809.md'


def fail(msg: str) -> None:
    print(f'historical-anomaly-validate: FAIL: {msg}', file=sys.stderr)
    sys.exit(1)


def rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def require(relpath: str) -> None:
    path = ROOT / relpath
    if relpath.endswith('/'):
        if not path.is_dir():
            fail(f'missing directory: {relpath}')
    elif not path.exists():
        fail(f'missing path: {relpath}')


def load_json(relpath: str):
    try:
        return json.loads((ROOT / relpath).read_text(encoding='utf-8'))
    except Exception as exc:
        fail(f'invalid JSON in {relpath}: {exc}')


def receipt_timestamp_local(receipt: dict) -> str:
    stamp = receipt.get('timestamp', '')
    parts = stamp.split('.')
    if len(parts) != 5 or not all(part.isdigit() for part in parts):
        fail('REVISION_RECEIPT.json timestamp must use YYYY.MM.DD.HH.MM format')
    year, month, day, hour, minute = parts
    return f'{year}-{month}-{day}T{hour}:{minute}:00-0400'


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = '/'.join(str(p) for p in err.path) or '<root>'
        fail(f'{label} schema violation at {where}: {err.message}')


def rev_num(revision: str) -> int:
    m = re.fullmatch(r'rev(\d{4})', revision)
    if not m:
        fail(f'invalid revision label: {revision!r}')
    return int(m.group(1))


def recent_guard(kind: str, revision: str, path: str) -> None:
    if rev_num(revision) >= RECENT_HISTORY_FLOOR:
        fail(f'recent-history anomaly is not allowed without fixing history: {kind} {revision} in {path}')


def mk(kind: str, path: str, revision: str, details: dict, reason: str, validator_policy: str) -> dict:
    return {
        'kind': kind,
        'status': 'carried_forward',
        'path': path,
        'revision': revision,
        'details': details,
        'reason': reason,
        'validator_policy': validator_policy,
    }


def scan_changelog() -> list[dict]:
    path = ROOT / 'CHANGELOG.md'
    text = path.read_text(encoding='utf-8')
    matches = [(m.group(1), text.count('\n', 0, m.start()) + 1) for m in CHANGELOG_HEADING_RE.finditer(text)]
    out: list[dict] = []
    seen: dict[str, list[int]] = {}
    for revision, line in matches:
        seen.setdefault(revision, []).append(line)
    for revision, lines in seen.items():
        if len(lines) > 1:
            recent_guard('duplicate_changelog_heading', revision, 'CHANGELOG.md')
            out.append(mk(
                'duplicate_changelog_heading',
                'CHANGELOG.md',
                revision,
                {'occurrence_count': len(lines), 'line_numbers': lines},
                'Historical changelog headings are retained as provenance rather than renumbered in-place.',
                f'Allowed only below rev{RECENT_HISTORY_FLOOR:04d} and only while exactly ledgered.',
            ))

    for idx in range(1, len(matches)):
        previous_revision, previous_line = matches[idx - 1]
        current_revision, current_line = matches[idx]
        if rev_num(current_revision) >= rev_num(previous_revision):
            recent_guard('non_descending_changelog_heading', current_revision, 'CHANGELOG.md')
            out.append(mk(
                'non_descending_changelog_heading',
                'CHANGELOG.md',
                current_revision,
                {
                    'previous_revision': previous_revision,
                    'previous_line': previous_line,
                    'current_revision': current_revision,
                    'current_line': current_line,
                },
                'Historical changelog ordering collision is retained as part of the inherited archive record.',
                f'Allowed only below rev{RECENT_HISTORY_FLOOR:04d} and only while exactly ledgered.',
            ))
    return out


def scan_archive_index() -> list[dict]:
    data = load_json('ARCHIVE_INDEX.json')
    bundles = data.get('bundles', [])
    if not isinstance(bundles, list):
        fail('ARCHIVE_INDEX.json bundles must be a list')
    out: list[dict] = []

    by_revision: dict[str, list[int]] = {}
    by_bundle: dict[str, list[int]] = {}
    for idx, row in enumerate(bundles):
        revision = row.get('revision')
        bundle = row.get('bundle')
        if isinstance(revision, str):
            by_revision.setdefault(revision, []).append(idx)
        if isinstance(bundle, str):
            by_bundle.setdefault(bundle, []).append(idx)

    for revision, rows in by_revision.items():
        if len(rows) > 1:
            recent_guard('duplicate_archive_revision', revision, 'ARCHIVE_INDEX.json')
            out.append(mk(
                'duplicate_archive_revision',
                'ARCHIVE_INDEX.json',
                revision,
                {'occurrence_count': len(rows), 'row_indexes': rows, 'bundles': [bundles[i].get('bundle') for i in rows]},
                'Historical archive-index revision-label duplicate is retained to preserve bundle-lineage provenance.',
                f'Allowed only below rev{RECENT_HISTORY_FLOOR:04d} and only while exactly ledgered.',
            ))

    for bundle, rows in by_bundle.items():
        if len(rows) > 1:
            revisions = [bundles[i].get('revision') for i in rows]
            revision = next((r for r in revisions if isinstance(r, str)), 'rev0000')
            recent_guard('duplicate_archive_bundle', revision, 'ARCHIVE_INDEX.json')
            out.append(mk(
                'duplicate_archive_bundle',
                'ARCHIVE_INDEX.json',
                revision,
                {'occurrence_count': len(rows), 'row_indexes': rows, 'bundle': bundle, 'revisions': revisions},
                'Historical archive-index bundle-name duplicate is retained as an inherited archive-lineage fact.',
                f'Allowed only below rev{RECENT_HISTORY_FLOOR:04d} and only while exactly ledgered.',
            ))

    for idx in range(1, len(bundles)):
        prev = bundles[idx - 1].get('revision')
        cur = bundles[idx].get('revision')
        if isinstance(prev, str) and isinstance(cur, str) and rev_num(cur) >= rev_num(prev):
            recent_guard('non_descending_archive_row', cur, 'ARCHIVE_INDEX.json')
            out.append(mk(
                'non_descending_archive_row',
                'ARCHIVE_INDEX.json',
                cur,
                {
                    'previous_revision': prev,
                    'previous_row_index': idx - 1,
                    'current_revision': cur,
                    'current_row_index': idx,
                    'previous_bundle': bundles[idx - 1].get('bundle'),
                    'current_bundle': bundles[idx].get('bundle'),
                },
                'Historical archive-index ordering collision is retained rather than rewritten after the fact.',
                f'Allowed only below rev{RECENT_HISTORY_FLOOR:04d} and only while exactly ledgered.',
            ))
    return out


def scan_audit_witness_labels() -> list[dict]:
    out: list[dict] = []
    for path in sorted((ROOT / 'AUDIT').glob('*_inventory_rev*.md')):
        relpath = rel(path)
        if relpath == CURRENT_WITNESS:
            continue
        m = AUDIT_WITNESS_RE.search(path.name)
        if not m:
            continue
        filename_revision = f"rev{m.group(1)}"
        labels = sorted(set(REV_RE.findall(path.read_text(encoding='utf-8'))))
        body_labels = [f"rev{digits}" for digits in labels]
        retained = [label for label in body_labels if label != filename_revision]
        if retained:
            out.append(mk(
                'audit_witness_body_label_carry_forward',
                relpath,
                filename_revision,
                {'filename_revision': filename_revision, 'retained_body_labels': retained},
                'Retained audit witness body preserves historical revision label(s) that do not match the witness filename revision.',
                'Allowed only when the exact witness path and retained body-label set are ledgered.',
            ))
    return out


def anomaly_key(item: dict) -> tuple[str, str, str, str]:
    return (
        item['kind'],
        item['path'],
        item['revision'],
        json.dumps(item.get('details', {}), sort_keys=True, ensure_ascii=False),
    )


def expected_anomalies() -> list[dict]:
    items = scan_changelog() + scan_archive_index() + scan_audit_witness_labels()
    items = sorted(items, key=anomaly_key)
    for idx, item in enumerate(items, start=1):
        item = item.copy()
        item['id'] = f'HA-{idx:04d}'
        items[idx - 1] = item
    return items


def comparable(item: dict) -> dict:
    return {k: item.get(k) for k in ['id', 'kind', 'status', 'path', 'revision', 'details', 'reason', 'validator_policy']}


def render_markdown(ledger: dict) -> str:
    lines = [
        '# Historical anomaly ledger',
        '',
        'This file is the exact human-facing companion to `AUDIT/HISTORICAL_ANOMALIES.json`.',
        '',
        f"- Revision: `{ledger['revision']}`",
        f"- Previous revision: `{ledger['previous_revision']}`",
        f"- Generated: `{ledger['generated_at_local']}`",
        f"- Recent-history floor: `rev{ledger['policy']['recent_history_floor']:04d}`",
        f"- Validator: `{ledger['policy']['validator']}`",
        f"- Anomaly count: `{len(ledger['anomalies'])}`",
        '',
        '## Carried-forward anomalies',
        '',
    ]
    for item in ledger['anomalies']:
        detail_text = json.dumps(item['details'], sort_keys=True, ensure_ascii=False)
        lines.extend([
            f"### {item['id']} — {item['kind']}",
            f"- Status: `{item['status']}`",
            f"- Path: `{item['path']}`",
            f"- Revision: `{item['revision']}`",
            f"- Details: `{detail_text}`",
            f"- Reason: {item['reason']}",
            f"- Validator policy: {item['validator_policy']}",
            '',
        ])
    return '\n'.join(lines)


def validate_wiring(ledger: dict) -> None:
    receipt = load_json('REVISION_RECEIPT.json')
    policy = load_json('publishing/CANONICAL_POLICY.json')
    context = load_json('CONTEXT_PACK.json')
    validation = load_json('VALIDATION_INDEX.json')
    control = load_json('CONTROL_SURFACES.json')
    gates = load_json('LIFECYCLE_GATES.json')
    frontier = load_json('CURRENT_FRONTIER.json')
    anchors = load_json('REVISION_ANCHORS.json')
    makefile = (ROOT / 'Makefile').read_text(encoding='utf-8')
    gate_py = (ROOT / 'scripts' / 'gate.py').read_text(encoding='utf-8')
    publish_audit = (ROOT / 'scripts' / 'publish_audit.py').read_text(encoding='utf-8')
    package_release = (ROOT / 'scripts' / 'package_release.py').read_text(encoding='utf-8')

    if ledger['revision'] != receipt['revision']:
        fail('historical anomaly ledger revision must match REVISION_RECEIPT.json')
    if ledger['previous_revision'] != receipt['previous_revision']:
        fail('historical anomaly ledger previous_revision must match REVISION_RECEIPT.json')
    if ledger['generated_at_local'] != receipt_timestamp_local(receipt):
        fail('historical anomaly ledger generated_at_local must match REVISION_RECEIPT.json timestamp')
    if ledger['policy']['validator'] != 'scripts/validate_historical_anomalies.py':
        fail('historical anomaly validator path mismatch')
    if ledger['policy']['markdown_companion'] != 'AUDIT/HISTORICAL_ANOMALIES.md':
        fail('historical anomaly markdown companion mismatch')
    if ledger['policy']['schema'] != 'schemas/historical_anomalies.schema.json':
        fail('historical anomaly schema pointer mismatch')
    if ledger['policy']['recent_history_floor'] != RECENT_HISTORY_FLOOR:
        fail('historical anomaly recent_history_floor mismatch')
    if ledger['policy']['anomaly_count'] != len(ledger['anomalies']):
        fail('historical anomaly count mismatch')

    for key, expected in {
        'historical_anomalies_json': 'AUDIT/HISTORICAL_ANOMALIES.json',
        'historical_anomalies_markdown': 'AUDIT/HISTORICAL_ANOMALIES.md',
        'historical_anomalies_schema': 'schemas/historical_anomalies.schema.json',
        'historical_anomalies_validator': 'scripts/validate_historical_anomalies.py',
    }.items():
        if policy.get(key) != expected:
            fail(f'publishing/CANONICAL_POLICY.json {key} mismatch')

    kms = context.get('key_machine_surfaces', {})
    for key, expected in {
        'historical_anomalies_json': 'AUDIT/HISTORICAL_ANOMALIES.json',
        'historical_anomalies_markdown': 'AUDIT/HISTORICAL_ANOMALIES.md',
        'historical_anomalies_validator': 'scripts/validate_historical_anomalies.py',
    }.items():
        if kms.get(key) != expected:
            fail(f'CONTEXT_PACK.json key_machine_surfaces.{key} mismatch')
    if 'make historical-anomaly-check' not in context.get('checks', []):
        fail('CONTEXT_PACK.json checks missing make historical-anomaly-check')
    if 'python3 scripts/validate_historical_anomalies.py' not in context.get('checks', []):
        fail('CONTEXT_PACK.json checks missing direct historical anomaly validator command')

    validation_paths = {item['path'] for item in control.get('surfaces', {}).get('validation_and_packaging', [])}
    for relpath in (
        'AUDIT/HISTORICAL_ANOMALIES.json',
        'AUDIT/HISTORICAL_ANOMALIES.md',
        'schemas/historical_anomalies.schema.json',
        'scripts/validate_historical_anomalies.py',
    ):
        if relpath not in validation_paths:
            fail(f'CONTROL_SURFACES.json validation_and_packaging missing {relpath}')

    audit_paths = {item['path'] for item in control.get('surfaces', {}).get('audit_and_retention', [])}
    for relpath in ('AUDIT/HISTORICAL_ANOMALIES.json', 'AUDIT/HISTORICAL_ANOMALIES.md'):
        if relpath not in audit_paths and relpath not in validation_paths:
            fail(f'CONTROL_SURFACES.json missing audit/validation surface {relpath}')

    check = next((c for c in validation.get('checks', []) if c.get('id') == 'historical-anomaly-check'), None)
    if not check:
        fail('VALIDATION_INDEX.json missing historical-anomaly-check')
    if check.get('scripts') != ['scripts/validate_historical_anomalies.py']:
        fail('historical-anomaly-check scripts mismatch')
    required = {
        'AUDIT/',
        'AUDIT/HISTORICAL_ANOMALIES.json',
        'AUDIT/HISTORICAL_ANOMALIES.md',
        'schemas/historical_anomalies.schema.json',
        'CHANGELOG.md',
        'ARCHIVE_INDEX.json',
        'scripts/validate_historical_anomalies.py',
    }
    if not required.issubset(set(check.get('validates', []))):
        fail(f'historical-anomaly-check validates missing surfaces: {sorted(required - set(check.get("validates", [])))}')

    for gate_id in ('careful_revision_pass', 'publish_audit', 'named_bundle_packaging', 'comparison_and_pattern_assimilation'):
        gate = gates['gates'][gate_id]
        refs = set(gate.get('authoritative_sequence', []) + gate.get('required_surfaces', []) + gate.get('checks', []))
        if 'scripts/validate_historical_anomalies.py' not in refs:
            fail(f'{gate_id} missing historical-anomaly validator')
        if gate_id in {'named_bundle_packaging', 'comparison_and_pattern_assimilation'}:
            if 'AUDIT/HISTORICAL_ANOMALIES.json' not in refs:
                fail(f'{gate_id} missing historical anomaly ledger')

    linked = set()
    for lane in frontier.get('lanes', []):
        linked.update(lane.get('linked_surfaces', []))
    if 'AUDIT/HISTORICAL_ANOMALIES.json' not in linked or 'scripts/validate_historical_anomalies.py' not in linked:
        fail('CURRENT_FRONTIER.json missing historical anomaly linkage')

    anchored = {item['path'] for item in anchors.get('anchored_surfaces', [])}
    if 'AUDIT/HISTORICAL_ANOMALIES.json' not in anchored:
        fail('REVISION_ANCHORS.json missing historical anomaly ledger anchor')
    validators = set(anchors.get('validators', []))
    if 'scripts/validate_historical_anomalies.py' not in validators:
        fail('REVISION_ANCHORS.json validators missing historical anomaly validator')

    if 'historical-anomaly-check:' not in makefile or 'scripts/validate_historical_anomalies.py' not in makefile:
        fail('Makefile missing historical-anomaly-check target')
    if 'validate_historical_anomalies.py' not in gate_py:
        fail('scripts/gate.py missing historical anomaly validator')
    if 'validate_historical_anomalies.py' not in publish_audit:
        fail('scripts/publish_audit.py missing historical anomaly validator')
    if 'validate_historical_anomalies.py' not in package_release:
        fail('scripts/package_release.py missing historical anomaly validator')


def main() -> None:
    for relpath in (
        'AUDIT/',
        'AUDIT/HISTORICAL_ANOMALIES.json',
        'AUDIT/HISTORICAL_ANOMALIES.md',
        'schemas/historical_anomalies.schema.json',
        'CHANGELOG.md',
        'ARCHIVE_INDEX.json',
        'AUDIT/README.md',
    ):
        require(relpath)

    ledger = load_json('AUDIT/HISTORICAL_ANOMALIES.json')
    schema = load_json('schemas/historical_anomalies.schema.json')
    validate_against_schema(ledger, schema, 'AUDIT/HISTORICAL_ANOMALIES.json')

    expected = expected_anomalies()
    actual = ledger.get('anomalies', [])
    if len(actual) != len(expected):
        fail(f'historical anomaly count drift: expected {len(expected)}, got {len(actual)}')
    expected_cmp = [comparable(item) for item in expected]
    actual_cmp = [comparable(item) for item in actual]
    if actual_cmp != expected_cmp:
        fail('AUDIT/HISTORICAL_ANOMALIES.json does not exactly match scanned carried-forward anomaly set')

    expected_md = render_markdown(ledger)
    if MARKDOWN.read_text(encoding='utf-8') != expected_md:
        fail('AUDIT/HISTORICAL_ANOMALIES.md must exactly mirror the JSON ledger')

    validate_wiring(ledger)
    print(f'historical-anomaly-validate: OK ({len(actual)} carried-forward anomalies ledgered)')


if __name__ == '__main__':
    main()
