#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import shutil
import stat
import sys
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parent.parent
RELEASE_DIR = ROOT / 'published' / 'releases'
ARTIFACT_DIR = RELEASE_DIR / 'artifacts'
EXCLUDE = {'RELEASE_INDEX.json', 'LATEST.json'}


def fail(msg: str) -> None:
    print(f"materialize-public-release: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def load_json(path: Path):
    try:
        return json.loads(path.read_text())
    except Exception as exc:
        fail(f"invalid JSON in {path}: {exc}")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def regular_file_external_attr(mode: int = 0o644) -> int:
    return (stat.S_IFREG | (mode & 0o777)) << 16


def public_zip_container_ok(path: Path) -> bool:
    try:
        with zipfile.ZipFile(path, 'r') as zf:
            if zf.comment or zf.testzip() is not None:
                return False
            names = zf.namelist()
            if not names or len(names) != len(set(names)):
                return False
            for info in zf.infolist():
                if info.filename.endswith('/') or info.date_time != (1980, 1, 1, 0, 0, 0):
                    return False
                if info.create_system != 3 or info.compress_type != zipfile.ZIP_DEFLATED or info.extra:
                    return False
                encoded_mode = info.external_attr >> 16
                if stat.S_IFMT(encoded_mode) != stat.S_IFREG or stat.S_IMODE(encoded_mode) != 0o644:
                    return False
        return True
    except Exception:
        return False


def snapshot_manifest_bytes(snapshot: dict) -> bytes:
    manifest = {
        'version': snapshot['manifest_version'],
        'owner': 'published/',
        'entry_points': [{'path': item['path'], 'role': item['role']} for item in snapshot['entry_points']],
        'canonical_context': snapshot['canonical_context'],
        'principles': snapshot['principles'],
    }
    return (json.dumps(manifest, indent=2) + '\n').encode()


def write_zip(zf: zipfile.ZipFile, arcname: str, payload: bytes) -> None:
    info = zipfile.ZipInfo(arcname, (1980, 1, 1, 0, 0, 0))
    info.create_system = 3
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = regular_file_external_attr(0o644)
    zf.writestr(info, payload)


def materialize(record_path: Path):
    data = load_json(record_path)
    release_id = data['release_id']
    bundle_name = f"{release_id}.zip"
    bundle_rel = f"published/releases/artifacts/{bundle_name}"
    manifest_rel = f"published/releases/artifacts/{release_id}.bundle.json"
    if data.get('artifact_zip') != bundle_rel:
        fail(f"{record_path.name} artifact_zip must be {bundle_rel}")
    if data.get('artifact_manifest') != manifest_rel:
        fail(f"{record_path.name} artifact_manifest must be {manifest_rel}")

    bundle_path = ROOT / bundle_rel
    manifest_path = ROOT / manifest_rel
    bundle_root = release_id
    snapshot = load_json(ROOT / data['public_surface_snapshot'])
    frozen_manifest_bytes = snapshot_manifest_bytes(snapshot)

    include_paths = []
    for rel in data.get('public_paths', []):
        if rel not in include_paths:
            include_paths.append(rel)
    for rel in [data.get('notes_path'), record_path.relative_to(ROOT).as_posix(), data.get('public_surface_snapshot')]:
        if rel and rel not in include_paths:
            include_paths.append(rel)

    included = []
    payloads = {}
    for rel in include_paths:
        if rel == data['public_surface_manifest']:
            payload = frozen_manifest_bytes
        else:
            src = ROOT / rel
            if not src.exists():
                fail(f"{record_path.name} references missing public path: {rel}")
            payload = src.read_bytes()
        payloads[rel] = payload
        included.append({'path': rel, 'sha256': sha256_bytes(payload), 'size_bytes': len(payload)})

    with tempfile.TemporaryDirectory() as _tmp:
        tmp_bundle = Path(_tmp) / bundle_name
        with zipfile.ZipFile(tmp_bundle, 'w') as zf:
            for item in included:
                write_zip(zf, f"{bundle_root}/{item['path']}", payloads[item['path']])
        bundle_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(tmp_bundle, bundle_path)
    if not public_zip_container_ok(bundle_path):
        fail(f"generated public ZIP failed portable container metadata checks: {bundle_rel}")

    manifest = {
        'release_id': release_id,
        'date': data['date'],
        'revision': data['revision'],
        'decision_id': data['decision_id'],
        'queue_item_id': data['queue_item_id'],
        'source_record': record_path.relative_to(ROOT).as_posix(),
        'source_record_sha256': sha256_file(record_path),
        'public_surface_manifest': data['public_surface_manifest'],
        'public_surface_manifest_sha256': data['public_surface_manifest_sha256'],
        'public_surface_snapshot': data['public_surface_snapshot'],
        'public_surface_snapshot_sha256': data['public_surface_snapshot_sha256'],
        'bundle_path': bundle_rel,
        'bundle_root': bundle_root,
        'bundle_sha256': sha256_file(bundle_path),
        'bundle_size_bytes': bundle_path.stat().st_size,
        'included_files': included,
    }
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    return {
        'release_id': release_id,
        'date': data['date'],
        'revision': data['revision'],
        'queue_item_id': data['queue_item_id'],
        'manifest_path': manifest_rel,
        'bundle_path': bundle_rel,
        'bundle_sha256': manifest['bundle_sha256'],
        'public_surface_manifest_sha256': data['public_surface_manifest_sha256'],
        'public_surface_snapshot_sha256': data['public_surface_snapshot_sha256'],
    }


def main() -> None:
    records = []
    for path in sorted(RELEASE_DIR.glob('*.json')):
        if path.name in EXCLUDE:
            continue
        data = load_json(path)
        if data.get('status') != 'published':
            fail(f"release record {path.name} must have status 'published'")
        records.append(materialize(path))

    if not records:
        fail('no public release records found under published/releases/')

    index = {'owner': 'published/releases/artifacts/', 'artifacts': records}
    (ARTIFACT_DIR / 'ARTIFACT_INDEX.json').write_text(json.dumps(index, indent=2) + '\n')
    print(f"materialize-public-release: OK ({len(records)} bundle(s))")


if __name__ == '__main__':
    main()
