#!/usr/bin/env python3
"""Validate the audit-witness index surface.

AUDIT/ contains retained evidence about prior packaging, retention, and
validator-introduction passes.  Most of those files are intentionally historical,
so this check does not rewrite their body labels.  It only proves that the audit
boundary names every current inventory witness, that the current revision's
witness is present, and that the new audit-witness validator is wired through the
operator-facing release surfaces.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AUDIT = ROOT / 'AUDIT'
WITNESS_RE = re.compile(r'^[a-z0-9_]+_inventory_rev\d{4}\.md$')
REV_RE = re.compile(r'rev(\d{4})')


def fail(msg: str) -> None:
    print(f'audit-witness-validate: FAIL: {msg}', file=sys.stderr)
    sys.exit(1)


def load_json(rel: str):
    try:
        return json.loads((ROOT / rel).read_text(encoding='utf-8'))
    except Exception as exc:
        fail(f'invalid JSON in {rel}: {exc}')


def require(rel: str) -> None:
    path = ROOT / rel
    if rel.endswith('/'):
        if not path.is_dir():
            fail(f'missing directory: {rel}')
    elif not path.exists():
        fail(f'missing path: {rel}')


def listed_witnesses(readme: str) -> list[str]:
    matches = re.findall(r'`(AUDIT/[a-z0-9_]+_inventory_rev\d{4}\.md)`', readme)
    if len(matches) != len(set(matches)):
        dupes = sorted({m for m in matches if matches.count(m) > 1})
        fail(f'AUDIT/README.md lists duplicate witness paths: {dupes}')
    return matches


def witness_revision(rel: str) -> int:
    match = REV_RE.search(rel)
    if not match:
        fail(f'cannot parse revision from witness path: {rel}')
    return int(match.group(1))


def require_contains(text: str, needle: str, label: str) -> None:
    if needle not in text:
        fail(f'{label} missing {needle}')


def validate_inventory_files(receipt: dict, readme: str) -> list[str]:
    disk = sorted(f'AUDIT/{path.name}' for path in AUDIT.iterdir() if path.is_file() and WITNESS_RE.fullmatch(path.name))
    listed = sorted(listed_witnesses(readme))
    if disk != listed:
        missing = sorted(set(disk) - set(listed))
        stale = sorted(set(listed) - set(disk))
        fail(f'AUDIT/README.md witness list drift; missing={missing}, stale={stale}')

    if len(disk) < 5:
        fail('audit inventory witness set is unexpectedly small')

    revisions = [witness_revision(rel) for rel in disk]
    if len(revisions) != len(set(revisions)):
        dupes = sorted({rev for rev in revisions if revisions.count(rev) > 1})
        fail(f'audit inventory witnesses repeat revision numbers: {dupes}')

    current = receipt['revision']
    current_witnesses = [rel for rel in disk if rel.endswith(f'_{current}.md')]
    if not current_witnesses:
        fail(f'missing current audit inventory file for {current}')

    for rel in disk:
        text = (ROOT / rel).read_text(encoding='utf-8')
        if not text.endswith('\n'):
            fail(f'{rel} must end with a newline')
        if '\r' in text:
            fail(f'{rel} must use LF line endings')
        headings = [line for line in text.splitlines() if line.startswith('## ')]
        if len(headings) < 2:
            fail(f'{rel} must contain at least two second-level witness sections')

    return disk


def validate_control_surfaces(witnesses: list[str]) -> None:
    control = load_json('CONTROL_SURFACES.json')
    audit_paths = {item['path'] for item in control['surfaces']['audit_and_retention']}
    validation_paths = {item['path'] for item in control['surfaces']['validation_and_packaging']}
    for rel in ['AUDIT/README.md', 'scripts/validate_audit_witnesses.py', *witnesses]:
        if rel not in audit_paths and rel not in validation_paths:
            fail(f'CONTROL_SURFACES.json missing audit witness surface: {rel}')

    gates = load_json('LIFECYCLE_GATES.json')
    for gate_id in ('careful_revision_pass', 'publish_audit', 'named_bundle_packaging'):
        checks = set(gates['gates'][gate_id].get('checks', []))
        if 'scripts/validate_audit_witnesses.py' not in checks:
            fail(f'LIFECYCLE_GATES.json {gate_id} missing audit-witness validator')
    if 'scripts/validate_audit_witnesses.py' not in set(gates['gates']['cold_open_and_reentry'].get('checks', [])):
        fail('LIFECYCLE_GATES.json cold_open_and_reentry missing audit-witness validator')


def validate_validation_index(witnesses: list[str]) -> None:
    validation = load_json('VALIDATION_INDEX.json')
    checks = {check['id']: check for check in validation.get('checks', [])}
    check = checks.get('audit-witness-check')
    if check is None:
        fail('VALIDATION_INDEX.json missing audit-witness-check')
    if check.get('make_target') != 'audit-witness-check':
        fail('audit-witness-check make_target mismatch')
    if check.get('scripts') != ['scripts/validate_audit_witnesses.py']:
        fail('audit-witness-check script mismatch')
    needed = {'AUDIT/README.md', 'CONTROL_SURFACES.json', 'LIFECYCLE_GATES.json', 'VALIDATION_INDEX.json', 'CONTEXT_PACK.json', 'publishing/CANONICAL_POLICY.json', 'scripts/validate_audit_witnesses.py', *witnesses}
    if not needed.issubset(set(check.get('validates', []))):
        missing = sorted(needed - set(check.get('validates', [])))
        fail(f'audit-witness-check validates missing surfaces: {missing}')

    gate_comp = next((comp for comp in validation.get('composite_targets', []) if comp.get('make_target') == 'gate'), None)
    if gate_comp is None or 'audit-witness-check' not in gate_comp.get('includes', []):
        fail('VALIDATION_INDEX.json gate composite missing audit-witness-check')
    pub_comp = next((comp for comp in validation.get('composite_targets', []) if comp.get('make_target') == 'publish-audit'), None)
    if pub_comp is None or 'audit-witness-check' not in pub_comp.get('includes', []):
        fail('VALIDATION_INDEX.json publish-audit composite missing audit-witness-check')

    md = (ROOT / 'VALIDATION_INDEX.md').read_text(encoding='utf-8')
    require_contains(md, '`make audit-witness-check`', 'VALIDATION_INDEX.md')
    require_contains(md, 'scripts/validate_audit_witnesses.py', 'VALIDATION_INDEX.md')


def validate_policy_and_context() -> None:
    policy = load_json('publishing/CANONICAL_POLICY.json')
    if policy.get('audit_witness_validator') != 'scripts/validate_audit_witnesses.py':
        fail('publishing/CANONICAL_POLICY.json audit_witness_validator mismatch')
    require_contains('\n'.join(policy.get('principles', [])), 'explicit_audit_witness_inventory_validation', 'publishing/CANONICAL_POLICY.json principles')

    context = load_json('CONTEXT_PACK.json')
    if context.get('key_machine_surfaces', {}).get('audit_witness_validator') != 'scripts/validate_audit_witnesses.py':
        fail('CONTEXT_PACK.json key_machine_surfaces audit_witness_validator mismatch')
    checks = set(context.get('checks', []))
    if 'make audit-witness-check' not in checks:
        fail('CONTEXT_PACK.json checks missing make audit-witness-check')
    if 'python3 scripts/validate_audit_witnesses.py' not in checks:
        fail('CONTEXT_PACK.json checks missing direct audit-witness validator')


def validate_runners_and_identity(receipt: dict) -> None:
    anchors = load_json('REVISION_ANCHORS.json')
    if 'scripts/validate_audit_witnesses.py' not in set(anchors.get('validators', [])):
        fail('REVISION_ANCHORS.json validators missing audit-witness validator')

    for rel in ('scripts/gate.py', 'scripts/publish_audit.py', 'scripts/package_release.py'):
        require_contains((ROOT / rel).read_text(encoding='utf-8'), 'validate_audit_witnesses.py', rel)
    makefile = (ROOT / 'Makefile').read_text(encoding='utf-8')
    require_contains(makefile, 'audit-witness-check:', 'Makefile')
    require_contains(makefile, '$(PYTHON) scripts/validate_audit_witnesses.py', 'Makefile')

    changelog = (ROOT / 'CHANGELOG.md').read_text(encoding='utf-8')
    top_section = changelog.split('\n## ', 2)[1] if '\n## ' in changelog else changelog
    for needle in ('scripts/validate_audit_witnesses.py', 'make audit-witness-check'):
        require_contains(top_section, needle, 'CHANGELOG.md top section')
    if f'_{receipt["revision"]}.md' not in top_section:
        fail('CHANGELOG.md top section missing a current-revision audit witness path')
    if receipt['history_anchor'] != 'CHANGELOG.md':
        fail('REVISION_RECEIPT.json history_anchor must be CHANGELOG.md')


def main() -> None:
    receipt = load_json('REVISION_RECEIPT.json')
    if not re.fullmatch(r'rev\d{4}', receipt.get('revision', '')):
        fail('REVISION_RECEIPT.json revision must be rev####')
    readme = (AUDIT / 'README.md').read_text(encoding='utf-8')
    witnesses = validate_inventory_files(receipt, readme)
    validate_control_surfaces(witnesses)
    validate_validation_index(witnesses)
    validate_policy_and_context()
    validate_runners_and_identity(receipt)
    print(f'audit-witness-validate: OK ({len(witnesses)} inventory witnesses indexed)')


if __name__ == '__main__':
    main()
