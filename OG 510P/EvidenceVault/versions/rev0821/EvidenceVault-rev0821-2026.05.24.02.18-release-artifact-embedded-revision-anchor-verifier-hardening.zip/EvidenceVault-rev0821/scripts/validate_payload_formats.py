#!/usr/bin/env python3
"""Validate residual structured payload formats not owned by JSON/text/archive checks.

This validator closes the gap between the JSON/text validators and the
archive-wide digest manifest.  The manifest proves byte identity, but it does
not prove that binary/render payloads are minimally well-formed or that compact
residual evidence formats can be decoded.  The checks here intentionally stay
small and dependency-free:

- PDFs must have a PDF header and EOF marker.
- PNGs must have a valid signature, chunk order, chunk CRCs, and terminal IEND.
- JSON-LD files must parse as JSON objects.
- SD-JWT examples must have a compact JWT component with decodable JSON header
  and payload, plus decodable disclosure fragments when present.
- Residual source/control formats (.dot, .lean, .rego, .pcg, toy .bin stubs)
  must be valid UTF-8 without NUL bytes.
"""
from __future__ import annotations

import base64
import binascii
import json
import re
import struct
import sys
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PNG_SIG = b"\x89PNG\r\n\x1a\n"
BASE64URL_RE = re.compile(r"^[A-Za-z0-9_-]*$")
HEX64_RE = re.compile(r"^[0-9a-f]{64}$")
UTF8_EXTENSIONS = {".bin", ".dot", ".lean", ".pcg", ".rego"}


def fail(msg: str) -> None:
    print(f"payload-format-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def read_utf8(path: Path) -> str:
    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        fail(f"{rel(path)} is not valid UTF-8: {exc}")
    if "\x00" in text:
        fail(f"{rel(path)} contains NUL bytes")
    return text


def b64url_decode(value: str, label: str, path: Path) -> bytes:
    if not BASE64URL_RE.fullmatch(value):
        fail(f"{rel(path)} {label} contains non-base64url characters")
    try:
        return base64.urlsafe_b64decode(value + "=" * ((4 - len(value) % 4) % 4))
    except binascii.Error as exc:
        fail(f"{rel(path)} {label} is not decodable base64url: {exc}")


def validate_pdf(path: Path) -> None:
    data = path.read_bytes()
    if len(data) < 32:
        fail(f"{rel(path)} is too small to be a PDF")
    if not data.startswith(b"%PDF-"):
        fail(f"{rel(path)} is missing a PDF header")
    if b"%%EOF" not in data[-4096:]:
        fail(f"{rel(path)} is missing a trailing PDF EOF marker")


def validate_png(path: Path) -> None:
    data = path.read_bytes()
    if not data.startswith(PNG_SIG):
        fail(f"{rel(path)} is missing a PNG signature")
    pos = len(PNG_SIG)
    seen_ihdr = False
    seen_iend = False
    while pos < len(data):
        if pos + 12 > len(data):
            fail(f"{rel(path)} has a truncated PNG chunk header")
        length = struct.unpack(">I", data[pos:pos + 4])[0]
        ctype = data[pos + 4:pos + 8]
        chunk_start = pos + 8
        chunk_end = chunk_start + length
        crc_end = chunk_end + 4
        if crc_end > len(data):
            fail(f"{rel(path)} has a truncated PNG chunk {ctype!r}")
        chunk_data = data[chunk_start:chunk_end]
        expected_crc = struct.unpack(">I", data[chunk_end:crc_end])[0]
        actual_crc = zlib.crc32(ctype + chunk_data) & 0xFFFFFFFF
        if actual_crc != expected_crc:
            fail(f"{rel(path)} PNG chunk {ctype.decode('latin1', 'replace')} has a CRC mismatch")
        if ctype == b"IHDR":
            if seen_ihdr:
                fail(f"{rel(path)} has multiple IHDR chunks")
            if pos != len(PNG_SIG):
                fail(f"{rel(path)} IHDR is not the first chunk")
            if length != 13:
                fail(f"{rel(path)} IHDR length is not 13")
            width, height = struct.unpack(">II", chunk_data[:8])
            if width == 0 or height == 0:
                fail(f"{rel(path)} has a zero PNG dimension")
            seen_ihdr = True
        elif not seen_ihdr:
            fail(f"{rel(path)} has data before IHDR")
        elif ctype == b"IEND":
            if length != 0:
                fail(f"{rel(path)} IEND chunk must be empty")
            seen_iend = True
            if crc_end != len(data):
                fail(f"{rel(path)} has trailing bytes after IEND")
            break
        pos = crc_end
    if not seen_ihdr:
        fail(f"{rel(path)} is missing IHDR")
    if not seen_iend:
        fail(f"{rel(path)} is missing IEND")


def validate_jsonld(path: Path) -> None:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"invalid JSON-LD in {rel(path)}: {exc}")
    if not isinstance(data, dict):
        fail(f"{rel(path)} JSON-LD payload must be an object")
    if "@context" not in data:
        fail(f"{rel(path)} JSON-LD payload is missing @context")


def validate_sdjwt(path: Path) -> None:
    text = read_utf8(path).strip()
    if not text:
        fail(f"{rel(path)} is empty")
    parts = text.split("~")
    jwt = parts[0]
    jwt_parts = jwt.split(".")
    if len(jwt_parts) != 3:
        fail(f"{rel(path)} compact JWT component must have three segments")
    header_raw = b64url_decode(jwt_parts[0], "JWT header", path)
    payload_raw = b64url_decode(jwt_parts[1], "JWT payload", path)
    b64url_decode(jwt_parts[2], "JWT signature", path)
    try:
        header = json.loads(header_raw)
        payload = json.loads(payload_raw)
    except Exception as exc:
        fail(f"{rel(path)} JWT header/payload JSON decode failed: {exc}")
    if not isinstance(header, dict) or not isinstance(payload, dict):
        fail(f"{rel(path)} JWT header and payload must be JSON objects")
    if "alg" not in header:
        fail(f"{rel(path)} JWT header is missing alg")
    if "iss" not in payload:
        fail(f"{rel(path)} JWT payload is missing iss")
    # SD-JWT disclosures are optional after tildes.  Examples in this archive use
    # compact base64url JSON-array disclosures, with a possible terminal empty kb-jwt slot.
    for i, disclosure in enumerate(parts[1:], start=1):
        if disclosure == "":
            continue
        raw = b64url_decode(disclosure, f"disclosure {i}", path)
        try:
            decoded = json.loads(raw)
        except Exception as exc:
            fail(f"{rel(path)} disclosure {i} is not JSON: {exc}")
        if not isinstance(decoded, list) or len(decoded) < 2:
            fail(f"{rel(path)} disclosure {i} must be a JSON array with at least salt/name")


def validate_dot(path: Path) -> None:
    text = read_utf8(path).strip()
    if not text.startswith(("digraph", "graph", "strict digraph", "strict graph")):
        fail(f"{rel(path)} does not look like a Graphviz DOT graph")
    if text.count("{") != text.count("}"):
        fail(f"{rel(path)} has unbalanced DOT braces")


def validate_utf8_payload(path: Path) -> None:
    text = read_utf8(path)
    if path.suffix.lower() == ".pcg" and "PCG-Policy" not in text.splitlines()[0]:
        fail(f"{rel(path)} PCG example is missing its PCG-Policy header")
    if path.suffix.lower() == ".rego" and not text.lstrip().startswith("package "):
        fail(f"{rel(path)} Rego file is missing a package declaration")
    if path.suffix.lower() == ".lean" and not text.strip():
        fail(f"{rel(path)} Lean file is empty")
    if path.suffix.lower() == ".bin" and "stub" not in text.lower():
        fail(f"{rel(path)} .bin file is treated as a toy stub and must say so")


def main() -> None:
    pdfs = pngs = jsonlds = sdjwts = utf8_payloads = 0
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        suffix = path.suffix.lower()
        if suffix == ".pdf":
            validate_pdf(path)
            pdfs += 1
        elif suffix == ".png":
            validate_png(path)
            pngs += 1
        elif suffix == ".jsonld":
            validate_jsonld(path)
            jsonlds += 1
        elif suffix == ".sdjwt":
            validate_sdjwt(path)
            sdjwts += 1
        elif suffix in UTF8_EXTENSIONS:
            if suffix == ".dot":
                validate_dot(path)
            else:
                validate_utf8_payload(path)
            utf8_payloads += 1

    print(
        "payload-format-validate: OK "
        f"({pdfs} PDFs, {pngs} PNGs, {jsonlds} JSON-LD files, "
        f"{sdjwts} SD-JWT files, {utf8_payloads} residual UTF-8 payloads)"
    )


if __name__ == "__main__":
    main()
