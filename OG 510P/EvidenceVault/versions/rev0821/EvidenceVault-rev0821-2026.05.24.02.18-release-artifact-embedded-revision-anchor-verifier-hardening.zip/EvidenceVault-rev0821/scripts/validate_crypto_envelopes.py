#!/usr/bin/env python3
"""Validate shipped cryptographic envelope/key material.

This archive intentionally carries demo and conformance signatures, including
some negative-test signatures.  Most legacy examples are still checked at the
syntax layer only: PEM files are parseable public keys only; files named
``*.dsse.json`` are actual DSSE envelopes; DSSE payloads/signatures are locally
base64-decodable; and raw in-toto Statement payloads keep a statement suffix
rather than masquerading as DSSE envelopes.

The rev0810 fixture lane is stronger.  Fixtures listed in
``certs/CRYPTO_FIXTURE_INDEX.json`` are verified as Ed25519 DSSE obligations:
positive fixtures must verify over the DSSEv1 PAE bytes, while negative fixtures
must be syntax-valid but fail signature verification.  That keeps the broad demo
surface compatible while making at least one cryptographic truth claim locally
falsifiable.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

ROOT = Path(__file__).resolve().parents[1]
INTOTO_STATEMENT_TYPE = 'https://in-toto.io/Statement/v1'
FIXTURE_INDEX = ROOT / 'certs' / 'CRYPTO_FIXTURE_INDEX.json'
FIXTURE_MARKDOWN = ROOT / 'certs' / 'CRYPTO_FIXTURE_INDEX.md'


def fail(msg: str) -> None:
    print(f'crypto-envelope-validate: FAIL: {msg}', file=sys.stderr)
    sys.exit(1)


def rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        fail(f'invalid JSON in {rel(path)}: {exc}')


def decode_b64ish(value: str, label: str) -> bytes:
    if not isinstance(value, str) or not value:
        fail(f'{label} must be a non-empty base64 string')
    try:
        raw = value.encode('ascii')
    except UnicodeEncodeError as exc:
        fail(f'{label} must contain only ASCII base64/base64url characters: {exc}')
    padded = raw + b'=' * ((4 - len(raw) % 4) % 4)
    errors: list[str] = []
    for altchars in (None, b'-_'):
        try:
            return base64.b64decode(padded, altchars=altchars, validate=True)
        except (binascii.Error, ValueError) as exc:
            errors.append(str(exc))
    fail(f'{label} is not decodable as base64/base64url: {errors[-1]}')


def validate_public_pem(path: Path) -> None:
    data = path.read_bytes()
    if b'PRIVATE KEY' in data:
        fail(f'private key material is not allowed in shipped PEM file: {rel(path)}')
    if b'-----BEGIN PUBLIC KEY-----' not in data:
        fail(f'PEM file must be a public key: {rel(path)}')
    try:
        serialization.load_pem_public_key(data)
    except Exception as exc:
        fail(f'PEM public key does not parse in {rel(path)}: {exc}')


def is_dsse_envelope(obj: Any) -> bool:
    return (
        isinstance(obj, dict)
        and isinstance(obj.get('payload'), str)
        and isinstance(obj.get('payloadType'), str)
        and isinstance(obj.get('signatures'), list)
    )


def validate_intoto_statement(obj: Any, label: str) -> None:
    if not isinstance(obj, dict):
        fail(f'{label} in-toto Statement must be a JSON object')
    if obj.get('_type') != INTOTO_STATEMENT_TYPE:
        fail(f'{label} in-toto Statement has wrong _type')
    if not isinstance(obj.get('predicateType'), str) or not obj['predicateType']:
        fail(f'{label} in-toto Statement must have a non-empty predicateType')
    subjects = obj.get('subject')
    if not isinstance(subjects, list):
        fail(f'{label} in-toto Statement subject must be a list')
    for i, subject in enumerate(subjects):
        if not isinstance(subject, dict):
            fail(f'{label} subject[{i}] must be an object')
        digest = subject.get('digest')
        if digest is not None:
            if not isinstance(digest, dict):
                fail(f'{label} subject[{i}].digest must be an object')
            sha = digest.get('sha256')
            if sha is not None and (not isinstance(sha, str) or not sha.strip()):
                fail(f'{label} subject[{i}].digest.sha256 must be a non-empty string when present')


def validate_dsse_envelope(obj: Any, label: str, *, require_ed25519_sig_length: bool = False, allow_empty_signature: bool = False) -> tuple[bytes, int]:
    if not is_dsse_envelope(obj):
        fail(f'{label} must be a DSSE envelope with payload, payloadType, and signatures')
    payload_type = obj['payloadType']
    if not payload_type.strip():
        fail(f'{label} payloadType must be non-empty')
    payload = decode_b64ish(obj['payload'], f'{label} payload')
    signatures = obj['signatures']
    if not signatures:
        fail(f'{label} signatures must be non-empty')
    for i, sig_obj in enumerate(signatures):
        if not isinstance(sig_obj, dict):
            fail(f'{label} signatures[{i}] must be an object')
        if 'keyid' in sig_obj and not isinstance(sig_obj['keyid'], str):
            fail(f'{label} signatures[{i}].keyid must be a string when present')
        sig_value = sig_obj.get('sig')
        if allow_empty_signature and sig_value == '':
            sig = b''
        else:
            sig = decode_b64ish(sig_value, f'{label} signatures[{i}].sig')
        if not sig and not allow_empty_signature:
            fail(f'{label} signatures[{i}].sig decodes to an empty byte string')
        if require_ed25519_sig_length and len(sig) != 64:
            fail(f'{label} signatures[{i}].sig length must be 64 bytes for shipped Ed25519 DSSE examples')
    if 'json' in payload_type:
        try:
            decoded = json.loads(payload.decode('utf-8'))
        except Exception as exc:
            fail(f'{label} JSON payload does not decode cleanly: {exc}')
        # Some shipped conformance fixtures intentionally carry bad in-toto
        # statement fields inside otherwise well-formed DSSE envelopes.  Validate
        # real statement payloads when they identify themselves as such, but do
        # not reject negative-test payloads whose purpose is to be semantically
        # wrong while remaining envelope-decodable.
        if payload_type == 'application/vnd.in-toto+json' and isinstance(decoded, dict) and decoded.get('_type') == INTOTO_STATEMENT_TYPE:
            validate_intoto_statement(decoded, f'{label} decoded payload')
    return payload, len(signatures)


def dsse_pae(payload_type: str, payload: bytes) -> bytes:
    """Return DSSEv1 pre-authentication encoding bytes."""
    encoded_type = payload_type.encode('utf-8')
    return b'DSSEv1 %d %s %d ' % (len(encoded_type), encoded_type, len(payload)) + payload


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_rel_path(value: Any, label: str) -> Path:
    if not isinstance(value, str) or not value:
        fail(f'{label} must be a non-empty relative path')
    path = Path(value)
    if path.is_absolute() or '\\' in value or '..' in path.parts:
        fail(f'{label} is unsafe: {value}')
    full = ROOT / path
    if not full.is_file():
        fail(f'{label} does not exist: {value}')
    return full


def public_keyid(key: Ed25519PublicKey) -> str:
    der = key.public_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return 'ed25519:' + sha256_bytes(der)[:16]


def load_ed25519_public_key(path: Path) -> Ed25519PublicKey:
    key = serialization.load_pem_public_key(path.read_bytes())
    if not isinstance(key, Ed25519PublicKey):
        fail(f'crypto fixture public key is not Ed25519: {rel(path)}')
    return key


def render_crypto_fixture_markdown(index: dict) -> str:
    profile = index['verification_profile']
    lines = [
        '# Crypto fixture index',
        '',
        'This file is the human-readable companion to `certs/CRYPTO_FIXTURE_INDEX.json`.',
        '`scripts/validate_crypto_envelopes.py` treats the listed fixtures as verification obligations, not merely syntax examples.',
        '',
        '## Verification profile',
        '',
        f"- Envelope: `{profile['envelope']}`",
        f"- Signature scheme: `{profile['signature_scheme']}`",
        f"- PAE: `{profile['pae']}`",
        f"- Key ID derivation: `{profile['keyid_derivation']}`",
        '',
        '## Fixtures',
        '',
    ]
    for fixture in index['fixtures']:
        negative_reason = fixture.get('negative_reason') or 'not_applicable'
        lines.extend([
            f"### `{fixture['id']}`",
            f"- Role: `{fixture['role']}`",
            f"- Expected result: `{fixture['expected_result']}`",
            f"- Envelope: `{fixture['envelope_path']}`",
            f"- Public key: `{fixture['public_key_path']}`",
            f"- Key ID: `{fixture['keyid']}`",
            f"- Payload SHA-256: `{fixture['payload_sha256']}`",
            f"- PAE SHA-256: `{fixture['pae_sha256']}`",
            f"- Signature SHA-256: `{fixture['signature_sha256']}`",
            f"- Negative reason: `{negative_reason}`",
            '',
        ])
    return '\n'.join(lines).rstrip()


def validate_crypto_fixture_index() -> tuple[int, int]:
    """Verify indexed positive/negative Ed25519 DSSE fixtures."""
    if not FIXTURE_INDEX.is_file():
        fail('missing certs/CRYPTO_FIXTURE_INDEX.json')
    index = load_json(FIXTURE_INDEX)
    if not isinstance(index, dict):
        fail('certs/CRYPTO_FIXTURE_INDEX.json must be a JSON object')
    if index.get('format') != 'evidencevault-crypto-fixture-index':
        fail('certs/CRYPTO_FIXTURE_INDEX.json format mismatch')
    receipt = load_json(ROOT / 'REVISION_RECEIPT.json')
    if index.get('revision') != receipt.get('revision'):
        fail('certs/CRYPTO_FIXTURE_INDEX.json revision must match REVISION_RECEIPT.json')
    if not FIXTURE_MARKDOWN.is_file():
        fail('missing certs/CRYPTO_FIXTURE_INDEX.md')
    expected_markdown = render_crypto_fixture_markdown(index)
    if FIXTURE_MARKDOWN.read_text(encoding='utf-8') != expected_markdown:
        fail('certs/CRYPTO_FIXTURE_INDEX.md must exactly mirror certs/CRYPTO_FIXTURE_INDEX.json')

    fixtures = index.get('fixtures')
    if not isinstance(fixtures, list) or not fixtures:
        fail('certs/CRYPTO_FIXTURE_INDEX.json fixtures must be a non-empty list')

    seen_ids: set[str] = set()
    positive = 0
    negative = 0
    for i, fixture in enumerate(fixtures):
        label = f'certs/CRYPTO_FIXTURE_INDEX.json fixtures[{i}]'
        if not isinstance(fixture, dict):
            fail(f'{label} must be an object')
        fixture_id = fixture.get('id')
        if not isinstance(fixture_id, str) or not fixture_id:
            fail(f'{label}.id must be a non-empty string')
        if fixture_id in seen_ids:
            fail(f'duplicate crypto fixture id: {fixture_id}')
        seen_ids.add(fixture_id)

        role = fixture.get('role')
        expected = fixture.get('expected_result')
        if role == 'positive':
            if expected != 'verify_pass':
                fail(f'{fixture_id} positive fixture must expect verify_pass')
            positive += 1
        elif role == 'negative':
            if expected != 'verify_fail':
                fail(f'{fixture_id} negative fixture must expect verify_fail')
            negative += 1
        else:
            fail(f'{fixture_id} role must be positive or negative')

        envelope_path = safe_rel_path(fixture.get('envelope_path'), f'{fixture_id}.envelope_path')
        key_path = safe_rel_path(fixture.get('public_key_path'), f'{fixture_id}.public_key_path')
        if not rel(envelope_path).endswith('.dsse.json'):
            fail(f'{fixture_id} envelope_path must end with .dsse.json')
        if key_path.suffix != '.pem':
            fail(f'{fixture_id} public_key_path must end with .pem')

        key = load_ed25519_public_key(key_path)
        computed_keyid = public_keyid(key)
        if fixture.get('keyid') != computed_keyid:
            fail(f'{fixture_id} keyid mismatch: expected {computed_keyid}, got {fixture.get("keyid")!r}')

        envelope = load_json(envelope_path)
        payload, sig_count = validate_dsse_envelope(envelope, rel(envelope_path), require_ed25519_sig_length=True)
        if sig_count != 1:
            fail(f'{fixture_id} must carry exactly one DSSE signature')
        payload_type = envelope['payloadType']
        if fixture.get('payload_type') != payload_type:
            fail(f'{fixture_id} payload_type mismatch')
        signature_obj = envelope['signatures'][0]
        if signature_obj.get('keyid') != computed_keyid:
            fail(f'{fixture_id} DSSE signature keyid mismatch')
        signature = decode_b64ish(signature_obj.get('sig'), f'{fixture_id} signature')
        pae = dsse_pae(payload_type, payload)

        expected_digests = {
            'payload_sha256': sha256_bytes(payload),
            'pae_sha256': sha256_bytes(pae),
            'signature_sha256': sha256_bytes(signature),
        }
        for field, actual in expected_digests.items():
            if fixture.get(field) != actual:
                fail(f'{fixture_id} {field} mismatch: expected {actual}, got {fixture.get(field)!r}')

        verified = True
        try:
            key.verify(signature, pae)
        except InvalidSignature:
            verified = False
        except Exception as exc:
            fail(f'{fixture_id} verification raised unexpected error: {exc}')

        if role == 'positive' and not verified:
            fail(f'{fixture_id} expected Ed25519 DSSE verification to pass')
        if role == 'negative' and verified:
            fail(f'{fixture_id} expected Ed25519 DSSE verification to fail')

    if positive < 1 or negative < 1:
        fail('crypto fixture index must include at least one positive and one negative verification fixture')
    return positive, negative


def walk_nested_dsse(obj: Any, path: Path, where: str = '<root>') -> tuple[int, int]:
    """Validate embedded DSSE-looking objects without treating schemas as payloads."""
    envelopes = 0
    signatures = 0
    if isinstance(obj, dict):
        if is_dsse_envelope(obj):
            _, sig_count = validate_dsse_envelope(obj, f'{rel(path)}:{where}', allow_empty_signature=True)
            envelopes += 1
            signatures += sig_count
        for key, value in obj.items():
            child = f'{where}.{key}' if where != '<root>' else key
            e, s = walk_nested_dsse(value, path, child)
            envelopes += e
            signatures += s
    elif isinstance(obj, list):
        for i, value in enumerate(obj):
            e, s = walk_nested_dsse(value, path, f'{where}[{i}]')
            envelopes += e
            signatures += s
    return envelopes, signatures


def main() -> None:
    positive_fixtures, negative_fixtures = validate_crypto_fixture_index()

    pem_count = 0
    for path in sorted(ROOT.rglob('*.pem')):
        validate_public_pem(path)
        pem_count += 1

    top_level_dsse = 0
    top_level_dsse_sigs = 0
    raw_statement_count = 0
    nested_dsse = 0
    nested_dsse_sigs = 0

    for path in sorted(ROOT.rglob('*.json')):
        data = load_json(path)
        r = rel(path)
        if r.endswith('.dsse.json'):
            _, sig_count = validate_dsse_envelope(data, r, require_ed25519_sig_length=True)
            top_level_dsse += 1
            top_level_dsse_sigs += sig_count
        elif isinstance(data, dict) and data.get('_type') == INTOTO_STATEMENT_TYPE:
            if r.endswith('.dsse.json'):
                fail(f'raw in-toto Statement must not use .dsse.json suffix: {r}')
            validate_intoto_statement(data, r)
            raw_statement_count += 1
        e, s = walk_nested_dsse(data, path)
        nested_dsse += e
        nested_dsse_sigs += s

    print(
        'crypto-envelope-validate: OK '
        f'({pem_count} PEM public keys, {top_level_dsse} top-level DSSE files/{top_level_dsse_sigs} signatures, '
        f'{raw_statement_count} raw in-toto statements, {nested_dsse} DSSE-shaped JSON objects/{nested_dsse_sigs} signatures, '
        f'{positive_fixtures} positive verification fixtures, {negative_fixtures} negative verification fixtures)'
    )


if __name__ == '__main__':
    main()
