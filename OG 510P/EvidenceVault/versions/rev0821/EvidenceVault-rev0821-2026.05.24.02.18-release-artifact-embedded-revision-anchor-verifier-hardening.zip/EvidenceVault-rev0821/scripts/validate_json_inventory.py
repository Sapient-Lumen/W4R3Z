#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

from jsonschema.validators import validator_for

try:
    import yaml
except Exception:  # pragma: no cover - PyYAML is expected in release tooling.
    yaml = None

ROOT = Path(__file__).resolve().parents[1]
SCHEMA_DIR = ROOT / 'schemas'
REGISTRY = SCHEMA_DIR / 'registry.json'


def fail(msg: str) -> None:
    print(f'json-inventory-validate: FAIL: {msg}', file=sys.stderr)
    sys.exit(1)


def rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def load_json(path: Path):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        fail(f'invalid JSON in {rel(path)}: {exc}')


def validate_json_files() -> int:
    count = 0
    for path in sorted(ROOT.rglob('*.json')):
        load_json(path)
        count += 1
    return count


def validate_schemas() -> int:
    if not SCHEMA_DIR.is_dir():
        fail('missing schemas/ directory')
    count = 0
    for path in sorted(SCHEMA_DIR.glob('*.json')):
        if path.name == 'registry.json':
            continue
        # The directory is reserved for schemas; check every non-registry JSON under it.
        schema = load_json(path)
        try:
            validator = validator_for(schema)
            validator.check_schema(schema)
        except Exception as exc:
            fail(f'invalid JSON Schema in {rel(path)}: {exc}')
        count += 1
    return count


def validate_registry() -> int:
    if not REGISTRY.is_file():
        fail('missing schemas/registry.json')
    registry = load_json(REGISTRY)
    if not isinstance(registry, dict):
        fail('schemas/registry.json must be an object mapping artifact names to schema filenames')
    seen: set[str] = set()
    for artifact_name, schema_name in sorted(registry.items()):
        if not isinstance(artifact_name, str) or not artifact_name:
            fail('schemas/registry.json contains an empty or non-string artifact name')
        if artifact_name in seen:
            fail(f'schemas/registry.json contains duplicate artifact name: {artifact_name}')
        seen.add(artifact_name)
        if '/' in artifact_name or '\\' in artifact_name or artifact_name.startswith('.'):
            fail(f'schemas/registry.json artifact key is not a basename: {artifact_name}')
        if not isinstance(schema_name, str) or not schema_name:
            fail(f'schemas/registry.json has empty/non-string schema target for {artifact_name}')
        if '/' in schema_name or '\\' in schema_name or schema_name.startswith('.'):
            fail(f'schemas/registry.json schema target is not a basename for {artifact_name}: {schema_name}')
        if not (SCHEMA_DIR / schema_name).is_file():
            fail(f'schemas/registry.json target missing for {artifact_name}: {schema_name}')
    return len(registry)



def load_registered_instance(path: Path):
    if path.suffix.lower() == '.json':
        return load_json(path)
    if path.suffix.lower() in {'.yaml', '.yml'}:
        if yaml is None:
            fail(f'cannot validate YAML registry instance without PyYAML: {rel(path)}')
        try:
            return yaml.safe_load(path.read_text(encoding='utf-8'))
        except Exception as exc:
            fail(f'invalid YAML in registry instance {rel(path)}: {exc}')
    fail(f'schemas/registry.json names unsupported instance suffix for {rel(path)}')


def validate_present_registry_instances(registry: dict[str, str]) -> tuple[int, int]:
    """Validate shipped files whose basename appears in schemas/registry.json.

    The registry is inherited from upstream example inventories, so not every
    registered example basename is necessarily shipped in this compressed
    archive.  Missing basenames are counted but not treated as a failure; any
    shipped basename that is registered must conform to the registered schema.
    """
    by_basename: dict[str, list[Path]] = {}
    for path in ROOT.rglob('*'):
        if path.is_file():
            by_basename.setdefault(path.name, []).append(path)

    present = 0
    absent = 0
    for artifact_name, schema_name in sorted(registry.items()):
        paths = by_basename.get(artifact_name, [])
        if not paths:
            absent += 1
            continue
        schema = load_json(SCHEMA_DIR / schema_name)
        validator_cls = validator_for(schema)
        try:
            validator_cls.check_schema(schema)
        except Exception as exc:
            fail(f'invalid JSON Schema in {schema_name}: {exc}')
        validator = validator_cls(schema)
        for path in paths:
            instance = load_registered_instance(path)
            errors = sorted(validator.iter_errors(instance), key=lambda e: list(e.path))
            if errors:
                err = errors[0]
                where = '/'.join(str(p) for p in err.path) or '<root>'
                fail(f'registered instance schema violation in {rel(path)} via {schema_name} at {where}: {err.message}')
            present += 1
    return present, absent

def main() -> None:
    json_count = validate_json_files()
    schema_count = validate_schemas()
    registry_count = validate_registry()
    registry = load_json(REGISTRY)
    present_count, absent_count = validate_present_registry_instances(registry)
    print(f'json-inventory-validate: OK ({json_count} JSON files, {schema_count} schema files, {registry_count} registry entries, {present_count} present registered instances validated, {absent_count} registry entries absent from shipped payload)')


if __name__ == '__main__':
    main()
