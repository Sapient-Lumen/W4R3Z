#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]


def fail(msg: str) -> None:
    print(f"revision-anchors-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def load_json(rel: str):
    path = ROOT / rel
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"invalid JSON in {rel}: {exc}")


def require(rel: str) -> None:
    if not (ROOT / rel).exists():
        fail(f"missing path: {rel}")


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = "/".join(str(p) for p in err.path) or "<root>"
        fail(f"{label} schema violation at {where}: {err.message}")


def resolve(data, pointer: str):
    cur = data
    for token in pointer.split('.'):
        if '[' in token:
            name, rest = token.split('[', 1)
            idx = int(rest[:-1])
            cur = cur[name][idx]
        else:
            cur = cur[token]
    return cur


def main() -> None:
    anchors = load_json('REVISION_ANCHORS.json')
    schema = load_json('schemas/revision_anchors.schema.json')
    receipt_schema = load_json('schemas/revision_receipt.schema.json')
    receipt = load_json('REVISION_RECEIPT.json')
    manifest = load_json('RELEASE_MANIFEST.json')
    control = load_json('CONTROL_SURFACES.json')
    gates = load_json('LIFECYCLE_GATES.json')
    validation_index = load_json('VALIDATION_INDEX.json')
    source_index = load_json('SOURCE_INDEX.json')
    context_pack = load_json('CONTEXT_PACK.json')
    policy = load_json('publishing/CANONICAL_POLICY.json')
    opening = load_json('OPENING_CONTRACT.json')
    conformance = load_json('OPENING_SURFACE_CONFORMANCE.json')

    validate_against_schema(anchors, schema, 'REVISION_ANCHORS.json')
    validate_against_schema(receipt, receipt_schema, 'REVISION_RECEIPT.json')

    if anchors['project'] != 'EvidenceVault':
        fail('revision anchors project must be EvidenceVault')

    current = anchors['current_revision']
    expected_archive_name = f"EvidenceVault-{current['revision']}-{current['timestamp']}-{manifest['slug']}"
    if current['archive_name'] != expected_archive_name:
        fail('current_revision archive_name does not match revision/timestamp/manifest slug')
    if current['bundle'] != current['archive_name'] + '.zip':
        fail('current_revision bundle does not match archive_name')
    if current['root_dir'] != ROOT.name:
        fail('current_revision root_dir does not match current archive root directory')

    seen = set()
    for entry in anchors['anchored_surfaces']:
        path = entry['path']
        if path in seen:
            fail(f'duplicate anchored surface: {path}')
        seen.add(path)
        require(path)
        data = load_json(path)
        for key, expected in entry['required_pairs'].items():
            actual = resolve(data, key)
            if actual != expected:
                fail(f'{path} mismatch at {key}: expected {expected!r}, got {actual!r}')

    for rel in anchors['validators']:
        require(rel)

    if receipt['revision'] != current['revision']:
        fail('revision anchors revision does not match REVISION_RECEIPT.json')
    if receipt['previous_revision'] != current['previous_revision']:
        fail('revision anchors previous_revision does not match REVISION_RECEIPT.json')
    if manifest['revision'] != current['revision']:
        fail('revision anchors revision does not match RELEASE_MANIFEST.json')
    if manifest['previous_revision'] != current['previous_revision']:
        fail('revision anchors previous_revision does not match RELEASE_MANIFEST.json')
    if manifest['timestamp'] != current['timestamp']:
        fail('revision anchors timestamp does not match RELEASE_MANIFEST.json')
    if manifest['archive_name'] != current['archive_name']:
        fail('revision anchors archive_name does not match RELEASE_MANIFEST.json')
    if manifest['bundle'] != current['bundle']:
        fail('revision anchors bundle does not match RELEASE_MANIFEST.json')
    if control['revision'] != current['revision']:
        fail('revision anchors revision does not match CONTROL_SURFACES.json')
    if gates['revision'] != current['revision']:
        fail('revision anchors revision does not match LIFECYCLE_GATES.json')
    if validation_index['revision'] != current['revision']:
        fail('revision anchors revision does not match VALIDATION_INDEX.json')
    if source_index['revision'] != current['revision']:
        fail('revision anchors revision does not match SOURCE_INDEX.json')
    if context_pack['revision'] != current['revision']:
        fail('revision anchors revision does not match CONTEXT_PACK.json')

    entrypoints = {item['path'] for item in opening.get('entrypoints', [])}
    if 'REVISION_ANCHORS.json' not in entrypoints:
        fail('opening contract entrypoints missing REVISION_ANCHORS.json')
    if 'REVISION_ANCHORS.json' not in conformance.get('required_root_entrypoints', []):
        fail('opening surface conformance missing REVISION_ANCHORS.json')

    if policy.get('revision_anchors') != 'REVISION_ANCHORS.json':
        fail('publishing/CANONICAL_POLICY.json revision_anchors mismatch')
    if policy.get('revision_anchor_validator') != 'scripts/validate_revision_anchors.py':
        fail('publishing/CANONICAL_POLICY.json revision_anchor_validator mismatch')
    if policy.get('revision_anchor_schema') != 'schemas/revision_anchors.schema.json':
        fail('publishing/CANONICAL_POLICY.json revision_anchor_schema mismatch')
    if 'explicit_revision_anchor_validator_inventory_validation' not in policy.get('principles', []):
        fail('publishing/CANONICAL_POLICY.json principles missing explicit_revision_anchor_validator_inventory_validation')
    expected_validators = sorted({
        script
        for check in validation_index['checks']
        for script in check.get('scripts', [])
        if script.startswith('scripts/validate_')
    })
    actual_validators = anchors.get('validators', [])
    if actual_validators != expected_validators:
        missing = sorted(set(expected_validators) - set(actual_validators))
        extra = sorted(set(actual_validators) - set(expected_validators))
        if missing or extra:
            fail(f'revision anchors validator inventory mismatch; missing={missing}, extra={extra}')
        fail('revision anchors validator inventory must be sorted and exactly mirror VALIDATION_INDEX.json validate_*.py scripts')

    for rel in expected_validators:
        require(rel)

    print(f'revision-anchors-validate: OK ({len(expected_validators)} validators anchored)')


if __name__ == '__main__':
    main()
