#!/usr/bin/env python3
import argparse
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
DIR_MAP = {'candidate': 'candidates', 'hold': 'hold', 'published_ready': 'published_ready', 'published': 'published'}
STATES = ['candidate', 'hold', 'published_ready', 'published']


def fail(msg: str) -> None:
    print(f"transition-queue-item: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def load_json(path: Path):
    try:
        return json.loads(path.read_text())
    except Exception as exc:
        fail(f"invalid JSON in {path}: {exc}")


def queue_field_line(label: str, value: object) -> str:
    text = '' if value is None else str(value)
    return f"- {label}: {text}" if text else f"- {label}:"


def render_queue_item_markdown(data: dict) -> str:
    lines = [
        '# Release queue item',
        '',
        f"- Date: {data.get('date', '')}",
        f"- Queue item id: {data.get('item_id', '')}",
        f"- State: {data.get('state', '')}",
        f"- Scope: {data.get('scope', '')}",
        f"- Owner: {data.get('owner', '')}",
        queue_field_line('Decision id', data.get('decision_id')),
        queue_field_line('Public release id', data.get('public_release_id')),
        '',
        '## Tracked paths',
    ]
    tracked = data.get('tracked_paths', [])
    if tracked:
        lines.extend(f"- `{rel}`" for rel in tracked)
    else:
        lines.append('-')
    lines.extend([
        '',
        '## Summary',
        data.get('summary', ''),
        '',
        '## Next action',
        data.get('next_action') or '-',
    ])
    return '\n'.join(lines) + '\n'


def find_item(name: str):
    for state in STATES:
        state_dir = ROOT / 'release_queue' / DIR_MAP[state]
        for path in state_dir.glob('*.json'):
            if path.stem == name:
                return state, path
            data = load_json(path)
            if data.get('item_id') == name:
                return state, path
    fail(f"queue item not found: {name}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--item', required=True, help='basename or queue item id')
    ap.add_argument('--to-state', required=True, choices=STATES)
    ap.add_argument('--decision-id')
    ap.add_argument('--public-release-id')
    ap.add_argument('--next-action')
    args = ap.parse_args()

    src_state, json_path = find_item(args.item)
    if src_state == args.to_state:
        fail('source and destination state are the same')
    data = load_json(json_path)
    data['state'] = args.to_state
    if args.decision_id is not None:
        data['decision_id'] = args.decision_id
    if args.public_release_id is not None:
        data['public_release_id'] = args.public_release_id
    if args.next_action is not None:
        if args.next_action:
            data['next_action'] = args.next_action
        elif 'next_action' in data:
            del data['next_action']

    dest_dir = ROOT / 'release_queue' / DIR_MAP[args.to_state]
    dest_json = dest_dir / json_path.name
    dest_md = dest_dir / (json_path.stem + '.md')
    src_md = json_path.with_suffix('.md')

    dest_json.write_text(json.dumps(data, indent=2) + '\n')
    dest_md.write_text(render_queue_item_markdown(data))
    if src_md.exists() and src_md != dest_md:
        src_md.unlink()
    json_path.unlink()
    print(f"transition-queue-item: OK ({src_state} -> {args.to_state}: {dest_json.relative_to(ROOT).as_posix()})")


if __name__ == '__main__':
    main()
