#!/usr/bin/env python3
"""Build the governed duplicate-payload inventory report."""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT / 'DEDUPE_REPORT.md'
EXCLUDE = {'MANIFEST.sha256', 'INDEX/files.json', 'INDEX/files.csv'}
TOP_N = 20


@dataclass(frozen=True)
class BlobGroup:
    digest: str
    count: int
    size_each: int
    duplicate_bytes: int
    paths: tuple[str, ...]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 16), b''):
            h.update(chunk)
    return h.hexdigest()


def shipped_rows() -> list[tuple[str, int, str]]:
    rows: list[tuple[str, int, str]] = []
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT).as_posix()
        if rel in EXCLUDE:
            continue
        rows.append((rel, path.stat().st_size, sha256_file(path)))
    return rows


def duplicate_groups() -> tuple[int, int, int, int, list[BlobGroup]]:
    rows = shipped_rows()
    by_digest: dict[str, list[tuple[str, int]]] = defaultdict(list)
    for rel, size, digest in rows:
        by_digest[digest].append((rel, size))
    groups: list[BlobGroup] = []
    for digest, members in by_digest.items():
        if len(members) < 2:
            continue
        members.sort(key=lambda x: x[0])
        size_each = members[0][1]
        groups.append(
            BlobGroup(
                digest=digest,
                count=len(members),
                size_each=size_each,
                duplicate_bytes=(len(members) - 1) * size_each,
                paths=tuple(rel for rel, _size in members),
            )
        )
    groups.sort(key=lambda g: (-g.duplicate_bytes, -g.size_each, g.digest))
    duplicate_copies = sum(g.count - 1 for g in groups)
    duplicate_bytes = sum(g.duplicate_bytes for g in groups)
    return len(rows), len(by_digest), duplicate_copies, duplicate_bytes, groups


def render() -> str:
    file_count, unique_count, duplicate_copies, duplicate_bytes, groups = duplicate_groups()
    approx_mb = duplicate_bytes / (1024 * 1024)
    lines = [
        '# Deduplication report',
        '',
        'This governed report is regenerated from the shipped tree by `python3 scripts/build_dedupe_report.py` and checked by `python3 scripts/validate_dedupe_report.py`.',
        '',
        'Scope excludes `MANIFEST.sha256`, `INDEX/files.json`, and `INDEX/files.csv` to avoid self-referential manifest/index loops.',
        '',
        '## Current duplicate-payload summary',
        '',
        f'- Files scanned: **{file_count}**',
        f'- Unique blobs by SHA-256: **{unique_count}**',
        f'- Duplicate copies: **{duplicate_copies}**',
        f'- Duplicate bytes, counting only extra copies: **{duplicate_bytes}** (~{approx_mb:.2f} MiB)',
        '',
        '## Deduplication policy',
        '',
        '- Exact duplicate detection is advisory unless a duplicate is already covered by a canonical-path pointer or a governed mirror policy.',
        '- Root paper PDF mirrors are intentionally duplicated from `papers/*.pdf` and are separately checked by `scripts/validate_paper_series.py`.',
        '- Retained upstream snapshots, audit trails, and content-addressed bundle stores may intentionally retain duplicate blobs because collapsing them can obscure provenance.',
        '- Curated exact mirrors should use `CANONICAL_PATHS.json` when a retained canonical owner exists and the rehydration path is clear.',
        '',
        f'## Largest duplicate blobs (top {min(TOP_N, len(groups))})',
        '',
        '| count | size each (bytes) | duplicate bytes | sha256 | example paths |',
        '|---:|---:|---:|---|---|',
    ]
    for group in groups[:TOP_N]:
        examples = '; '.join(group.paths[:4])
        if len(group.paths) > 4:
            examples += ' ...'
        lines.append(f'| {group.count} | {group.size_each} | {group.duplicate_bytes} | `{group.digest}` | {examples} |')
    lines.extend([
        '',
        '## Notes',
        '',
        '- This report is intentionally a measured inventory, not an instruction to remove every duplicate.',
        '- Future pruning should prefer explicit canonical-path ledgers plus absence/provenance ledger updates over silent deletion.',
    ])
    return '\n'.join(lines).rstrip() + '\n'


def main() -> None:
    REPORT.write_text(render(), encoding='utf-8')
    print(f'dedupe-report-build: wrote {REPORT.relative_to(ROOT).as_posix()}')


if __name__ == '__main__':
    main()
