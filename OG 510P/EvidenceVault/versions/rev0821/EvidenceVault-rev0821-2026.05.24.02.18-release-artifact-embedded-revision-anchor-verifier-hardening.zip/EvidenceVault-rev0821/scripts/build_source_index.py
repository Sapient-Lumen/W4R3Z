#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def current_revision_metadata() -> tuple[str, str]:
    receipt = json.loads((ROOT / "REVISION_RECEIPT.json").read_text(encoding="utf-8"))
    ts = receipt["timestamp"]
    date, hour, minute = ts[:10].replace(".", "-"), ts[11:13], ts[14:16]
    return receipt["revision"], f"{date}T{hour}:{minute}:00-0400"

SOURCE_ROOT_CONFIG = {
    "ctg": {
        "label": "CTG policy examples and traces",
        "key_subtrees": ["policy_examples", "traces"],
        "companion_paths": [
            "artifacts/curated/ctg/",
            "papers/ev_pact_ocf.tex",
            "papers/ev_interpretation_profiles.tex",
        ],
        "note": "Retained CTG inputs stay as a compact full source tree; the curated CTG artifact directory is now mostly a canonical-path pointer rather than a duplicate mirror."
    },
    "docf": {
        "label": "dOCF data, examples, figures, and test vectors",
        "key_subtrees": ["data", "examples", "figures", "test_vectors"],
        "companion_paths": [
            "artifacts/curated/docf/",
            "renders/legacy_pdfs/docf/",
            "papers/ev_streamfold.tex",
            "papers/ev_interpretation_profiles.tex",
        ],
        "note": "docf is the retained source tree that backs both the StreamFold family note and part of the interpretation bridge; curated docf artifacts stay as canonical-path pointers and unique local files rather than a full duplicate copy."
    },
    "ocf_llm": {
        "label": "OCF LLM examples, profiles, schemas, tables, and verifier tooling",
        "key_subtrees": ["archive", "examples", "figs", "profiles", "schemas", "tables", "tools"],
        "companion_paths": [
            "certs/curated/ocf_llm/",
            "renders/legacy_pdfs/ocf_llm/",
            "papers/ev_pact_ocf.tex",
            "papers/ev_interpretation_profiles.tex",
        ],
        "note": "OCF LLM remains a large retained source family because many compact front / governance / admission examples still matter as audit substrate rather than just as rendered paper inputs."
    },
    "pact": {
        "label": "PACT workdir, demos, benchmarks, and replay-pack substrate",
        "key_subtrees": ["PACT_workdir"],
        "companion_paths": [
            "artifacts/curated/pact/",
            "certs/curated/pact/",
            "papers/ev_pact_ocf.tex",
            "papers/ev_interpretation_profiles.tex",
        ],
        "note": "PACT stays as a retained full source tree because replay packs, workdir benchmarks, and decision-object examples are still the canonical audit substrate for the PACT family extraction."
    },
}

NON_ROOT_FAMILY_CONFIG = [
    {
        "family": "streamfold",
        "canonical_paper": "papers/ev_streamfold.tex",
        "representation_paths": [
            "artifacts/curated/streamfold/",
            "certs/curated/streamfold/",
            "renders/legacy_pdfs/streamfold/",
        ],
        "note": "StreamFold is represented in this unified archive by curated ABI material, signed examples, and retained legacy renders rather than a full retained sources/streamfold tree."
    },
    {
        "family": "zkrtp",
        "canonical_paper": "papers/ev_zkrtp.tex",
        "representation_paths": [
            "artifacts/curated/zkrtp_v2/",
            "certs/curated/zkrtp_v2/",
            "renders/legacy_pdfs/zkrtp_v2/",
            "renders/legacy_pdfs/zkrtp_portfolio/",
        ],
        "note": "zk-RTP is represented by curated material, signed examples, and retained legacy renders from v2 and portfolio lines rather than by a single retained full source tree under sources/."
    },
]


def file_count(path: Path) -> int:
    return sum(1 for p in path.rglob("*") if p.is_file())


def extraction_consumers() -> dict[str, list[str]]:
    data = json.loads((ROOT / "papers/EXTRACTION_MAP.json").read_text(encoding="utf-8"))
    out: dict[str, list[str]] = {k: [] for k in SOURCE_ROOT_CONFIG}
    for paper_name, meta in data.items():
        paper_path = f"papers/{paper_name}"
        for src in meta.get("from", []):
            if isinstance(src, str) and src.startswith("sources/"):
                parts = src.split("/")
                if len(parts) >= 2 and parts[1] in out:
                    out[parts[1]].append(paper_path)
    return {k: sorted(set(v)) for k, v in out.items()}


def build_source_index() -> dict:
    consumers = extraction_consumers()
    source_roots = []
    for root_name, cfg in SOURCE_ROOT_CONFIG.items():
        root_rel = f"sources/{root_name}"
        root_path = ROOT / root_rel
        subtrees = []
        for sub in cfg["key_subtrees"]:
            sub_rel = f"{root_rel}/{sub}"
            subtrees.append({
                "path": sub_rel,
                "file_count": file_count(ROOT / sub_rel),
            })
        source_roots.append({
            "id": root_name,
            "retained_root": root_rel,
            "label": cfg["label"],
            "file_count": file_count(root_path),
            "key_subtrees": subtrees,
            "consumed_by_papers": consumers[root_name],
            "companion_paths": cfg["companion_paths"],
            "note": cfg["note"],
        })

    non_root = []
    for cfg in NON_ROOT_FAMILY_CONFIG:
        non_root.append({
            "family": cfg["family"],
            "canonical_paper": cfg["canonical_paper"],
            "representation_paths": cfg["representation_paths"],
            "note": cfg["note"],
        })

    revision, generated_at_local = current_revision_metadata()
    data = {
        "version": 1,
        "revision": revision,
        "generated_at_local": generated_at_local,
        "purpose": "Compact machine-readable map of retained source roots, their notable subtrees, which canonical papers consume them, and which family lines are represented instead by curated artifacts/certs/legacy renders so source-facing archive work no longer has to reconstruct that map from CATALOG.md, papers/EXTRACTION_MAP.json, and directory archaeology alone.",
        "source_roots": source_roots,
        "represented_without_retained_source_root": non_root,
        "builder": "scripts/build_source_index.py",
        "validator": "scripts/validate_source_index.py",
    }
    return data


def render_markdown(data: dict) -> str:
    lines = [
        "# Source index",
        "",
        "This file is a compact retained-source and family-representation map.",
        "It complements `CATALOG.md` and `papers/EXTRACTION_MAP.json`; it does not replace canon ownership.",
        "",
        "## Retained source roots",
        "",
        "| Root | Files | Consumed by papers | Companion surfaces |",
        "| --- | ---: | --- | --- |",
    ]
    for entry in data["source_roots"]:
        lines.append(
            f"| `{entry['retained_root']}` | {entry['file_count']} | "
            f"{', '.join(f'`{p}`' for p in entry['consumed_by_papers'])} | "
            f"{', '.join(f'`{p}`' for p in entry['companion_paths'])} |"
        )
    lines += ["", "## Root details", ""]
    for entry in data["source_roots"]:
        lines += [
            f"### `{entry['retained_root']}` — {entry['label']}",
            f"- Files: {entry['file_count']}",
            f"- Consumed by: {', '.join(f'`{p}`' for p in entry['consumed_by_papers'])}",
            f"- Companion surfaces: {', '.join(f'`{p}`' for p in entry['companion_paths'])}",
            f"- Note: {entry['note']}",
            "- Key subtrees:",
        ]
        for subtree in entry["key_subtrees"]:
            lines.append(f"  - `{subtree['path']}` — {subtree['file_count']} files")
        lines.append("")
    lines += ["## Families represented without a retained `sources/` root", ""]
    for entry in data["represented_without_retained_source_root"]:
        lines += [
            f"### `{entry['family']}`",
            f"- Canonical paper: `{entry['canonical_paper']}`",
            f"- Representation paths: {', '.join(f'`{p}`' for p in entry['representation_paths'])}",
            f"- Note: {entry['note']}",
            "",
        ]
    return "\n".join(lines)


def main() -> None:
    data = build_source_index()
    (ROOT / "SOURCE_INDEX.json").write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    (ROOT / "SOURCE_INDEX.md").write_text(render_markdown(data).rstrip() + "\n", encoding="utf-8")
    print("Wrote SOURCE_INDEX.md and SOURCE_INDEX.json")


if __name__ == "__main__":
    main()
