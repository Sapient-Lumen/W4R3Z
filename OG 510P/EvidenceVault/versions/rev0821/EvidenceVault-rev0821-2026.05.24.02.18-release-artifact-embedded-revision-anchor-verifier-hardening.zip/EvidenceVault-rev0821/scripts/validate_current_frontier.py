#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_VALIDATOR = 'scripts/validate_current_frontier.py'


def fail(msg: str) -> None:
    print(f"current-frontier-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def load_json(rel: str):
    path = ROOT / rel
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"invalid JSON in {rel}: {exc}")


def require(rel: str) -> None:
    if not (ROOT / rel).exists():
        fail(f"missing path: {rel}")


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = "/".join(str(p) for p in err.path) or "<root>"
        fail(f"{label} schema violation at {where}: {err.message}")


def receipt_timestamp(receipt: dict) -> str:
    stamp = receipt['timestamp']
    date = stamp[:10].replace('.', '-')
    hour = stamp[11:13]
    minute = stamp[14:16]
    return f'{date}T{hour}:{minute}:00-0400'


def render_markdown(frontier: dict) -> str:
    lines = [
        '# Current frontier',
        '',
        'This file is the compact human-facing companion to `CURRENT_FRONTIER.json`.',
        "It records the archive's live comparison pressure and open/deferred structural lanes without promoting them to canon or standing ADR memory.",
        '',
        '## Current focus',
        frontier['current_focus'],
        '',
    ]
    for lane in frontier['lanes']:
        lines.extend([
            f"### `{lane['id']}` — {lane['status']} — {lane['title']}",
            f"- Drivers: {', '.join(f'`{driver}`' for driver in lane['drivers'])}",
            f"- Linked surfaces: {', '.join(f'`{rel}`' for rel in lane['linked_surfaces'])}",
            f"- Note: {lane['note']}",
            '',
        ])
    return '\n'.join(lines).rstrip() + '\n'


def main() -> None:
    frontier = load_json('CURRENT_FRONTIER.json')
    schema = load_json('schemas/current_frontier.schema.json')
    opening = load_json('OPENING_CONTRACT.json')
    conformance = load_json('OPENING_SURFACE_CONFORMANCE.json')
    control = load_json('CONTROL_SURFACES.json')
    gates = load_json('LIFECYCLE_GATES.json')
    policy = load_json('publishing/CANONICAL_POLICY.json')
    revision = load_json('REVISION_RECEIPT.json')
    rfc_index = load_json('RFC_INDEX.json')
    assimilation = load_json('ASSIMILATION_LEDGER.json')

    validate_against_schema(frontier, schema, 'CURRENT_FRONTIER.json')
    if frontier['revision'] != revision['revision']:
        fail('CURRENT_FRONTIER.json revision must match REVISION_RECEIPT.json')
    if frontier.get('generated_at_local') != receipt_timestamp(revision):
        fail('CURRENT_FRONTIER.json generated_at_local must match REVISION_RECEIPT.json timestamp')
    if frontier.get('validator') != EXPECTED_VALIDATOR:
        fail(f'CURRENT_FRONTIER.json validator must be {EXPECTED_VALIDATOR}')

    require('CURRENT_FRONTIER.md')
    require(frontier['validator'])

    md = (ROOT / 'CURRENT_FRONTIER.md').read_text(encoding='utf-8')
    expected_md = render_markdown(frontier)
    if md != expected_md:
        fail('CURRENT_FRONTIER.md must exactly mirror render_markdown(CURRENT_FRONTIER.json)')

    known_rfcs = {entry['id'] for entry in rfc_index.get('entries', [])}
    known_assimilation = {entry['id'] for entry in assimilation.get('records', [])}
    known_adrs = {entry['id'] for entry in load_json('ADR_INDEX.json').get('entries', [])}
    lane_ids = set()
    saw_active = False
    for lane in frontier['lanes']:
        if lane['id'] in lane_ids:
            fail(f"duplicate frontier lane id: {lane['id']}")
        lane_ids.add(lane['id'])
        if lane['status'] == 'active':
            saw_active = True
        for drv in lane['drivers']:
            if drv.startswith('RFC-') and drv not in known_rfcs:
                fail(f"frontier lane references unknown RFC id: {drv}")
            if drv.startswith('AL-') and drv not in known_assimilation:
                fail(f"frontier lane references unknown assimilation id: {drv}")
            if drv.startswith('ADR-') and drv not in known_adrs:
                fail(f"frontier lane references unknown ADR id: {drv}")
        for rel in lane['linked_surfaces']:
            require(rel)
    if not saw_active:
        fail('CURRENT_FRONTIER.json must keep at least one active lane')

    entrypoints = {item['path'] for item in opening.get('entrypoints', [])}
    for rel in ('CURRENT_FRONTIER.md', 'CURRENT_FRONTIER.json'):
        if rel not in entrypoints:
            fail(f'opening contract entrypoints missing {rel}')
    if 'CURRENT_FRONTIER.md' not in opening.get('cold_open_minimum', []):
        fail('opening contract cold_open_minimum missing CURRENT_FRONTIER.md')
    required_root = set(conformance.get('required_root_entrypoints', []))
    if not {'CURRENT_FRONTIER.md', 'CURRENT_FRONTIER.json'}.issubset(required_root):
        fail('opening surface conformance missing CURRENT_FRONTIER surfaces')

    comparison_paths = {item['path'] for item in control['surfaces']['comparison_and_assimilation']}
    if not {'CURRENT_FRONTIER.md', 'CURRENT_FRONTIER.json', EXPECTED_VALIDATOR}.issubset(comparison_paths):
        fail('control surfaces comparison_and_assimilation missing CURRENT_FRONTIER linkage')
    open_paths = {item['path'] for item in control['surfaces']['opening_and_resumption']}
    if not {'CURRENT_FRONTIER.md', 'CURRENT_FRONTIER.json'}.issubset(open_paths):
        fail('control surfaces opening_and_resumption missing CURRENT_FRONTIER linkage')

    compare_gate = gates['gates']['comparison_and_pattern_assimilation']
    compare_refs = set(compare_gate.get('required_surfaces', []) + compare_gate.get('checks', []))
    needed = {'CURRENT_FRONTIER.md', 'CURRENT_FRONTIER.json', EXPECTED_VALIDATOR}
    if not needed.issubset(compare_refs):
        fail('comparison_and_pattern_assimilation gate missing CURRENT_FRONTIER linkage')

    if policy.get('current_frontier_markdown') != 'CURRENT_FRONTIER.md':
        fail('publishing/CANONICAL_POLICY.json current_frontier_markdown mismatch')
    if policy.get('current_frontier_json') != 'CURRENT_FRONTIER.json':
        fail('publishing/CANONICAL_POLICY.json current_frontier_json mismatch')
    if policy.get('current_frontier_validator') != EXPECTED_VALIDATOR:
        fail('publishing/CANONICAL_POLICY.json current_frontier_validator mismatch')
    if policy.get('current_frontier_schema') != 'schemas/current_frontier.schema.json':
        fail('publishing/CANONICAL_POLICY.json current_frontier_schema mismatch')

    print(f'current-frontier-validate: OK ({len(frontier["lanes"])} lanes mirrored)')


if __name__ == '__main__':
    main()
