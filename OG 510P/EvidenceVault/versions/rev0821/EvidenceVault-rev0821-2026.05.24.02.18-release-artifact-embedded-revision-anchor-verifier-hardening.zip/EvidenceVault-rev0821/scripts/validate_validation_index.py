#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]

PRIMARY_DESCRIPTIONS: dict[str, str] = {
    'opening-check': 'Startup/reentry surfaces, opening contract schemas, AGENTS.md read-first/command-posture guidance, and opening-surface conformance stay aligned.',
    'context-check': '`CONTEXT_PACK.json`, its schema, opening-surface linkage, command hints, read-order paths, validation-index references, release-manifest identity, and revision anchors stay aligned.',
    'command-surface-check': '`Makefile` phony targets, help text, recipes, script references, validation-index target coverage, context-pack command hints, and canonical policy command-surface pointers stay aligned.',
    'toolchain-check': '`TOOLCHAIN_LOCK.json`, its exact Markdown companion, required Python modules, required external commands, package ZIP constants, policy, context, lifecycle, and validation wiring stay aligned.',
    'asset-indexes': 'Refreshes `artifacts/ARTIFACTS_INDEX.*` and `certs/CERTS_INDEX.*` from the shipped artifact/certificate trees.',
    'dedupe-report': 'Refreshes `DEDUPE_REPORT.md` from the shipped regular-file tree, excluding manifest/index self-reference files.',
    'rebuild-indexes': 'Refreshes `SOURCE_INDEX.md`, `SOURCE_INDEX.json`, `INDEX/files.json`, `INDEX/files.csv`, `MANIFEST.sha256`, and acyclic release-manifest identity digests.',
    'manifest-check': '`MANIFEST.sha256`, `INDEX/files.json`, and `INDEX/files.csv` cover the complete packaged regular-file set with correct path order, hashes, sizes, classifications, CSV mirroring, and no symlinks/special files.',
    'dedupe-check': '`DEDUPE_REPORT.md` exactly mirrors the current duplicate-payload inventory computed from the shipped tree.',
    'json-check': 'Every shipped `.json` file parses, bundled JSON Schema files are valid schemas, `schemas/registry.json` points at present schema files, and present registry-named instances validate against their schema.',
    'text-check': 'YAML, JSONL, CSV, Python source, and UTF-8 text-like payloads parse/decode cleanly, and governed zero-byte files are refused.',
    'text-surface-check': 'Governed/operator/generated text surfaces use UTF-8, LF line endings, exactly one terminal newline, and no trailing whitespace while retained upstream payload formatting remains preserved.',
    'payload-format-check': 'PDFs, PNGs, JSON-LD, SD-JWT examples, DOT graphs, Lean/Rego/PCG examples, and toy stub payloads have locally decodable structure beyond archive-wide hashes.',
    'crypto-check': 'PEM public keys, DSSE envelopes, DSSE payload/signature encodings, raw in-toto Statement suffixes, and indexed positive/negative Ed25519 DSSE verification fixtures stay parseable, accurately named, free of private-key material, and locally falsifiable.',
    'provenance-check': 'Upstream input digests, upstream omission rows, redaction paths, pruned/transient paths, and the human upstream diff report stay mutually coherent, safe, governed, and absent where absence is claimed.',
    'filesystem-check': 'Shipped paths are safe, NFC/casefold collision-free, transient byproducts are absent, every shipped path is a regular file, and regular-file modes are least-privilege `0644`.',
    'asset-check': '`ARTIFACTS_INDEX.*` and `CERTS_INDEX.*` exactly mirror shipped scoped payloads, and `CANONICAL_PATHS.json` dedupe pointers target existing files with matching size and SHA-256.',
    'paper-check': 'The five canonical paper TeX files, root PDF mirrors, paper index/catalog pointers, and every path-like `papers/EXTRACTION_MAP.json` source reference are present and safe.',
    'archive-payload-check': 'Embedded public-release ZIPs and repro-pack tarballs have safe members, no duplicates, portable ZIP regular-file metadata, public-bundle source freshness, bundle-manifest digest coherence, and repro-pack manifest artifact rows with correct sizes, SHA-256 values, coverage, and totals.',
    'source-check': 'Retained-source roots, family-representation coverage, and exact `SOURCE_INDEX.md`/`SOURCE_INDEX.json` companion rendering stay explicit, governed, and revision-aligned.',
    'adr-check': 'Standing architecture decision memory stays coherent, schema-checked, policy/context wired, and exactly mirrored between `ADR_INDEX.md` and `ADR_INDEX.json`.',
    'rfc-check': 'Bounded unresolved RFC/proposal memory stays coherent, assimilation-linked, schema-checked, policy/context wired, and exactly mirrored between `RFC_INDEX.md` and `RFC_INDEX.json`.',
    'frontier-check': 'Current live comparison pressure and deferred lanes stay explicit, bounded, revision-aligned, exactly mirrored between `CURRENT_FRONTIER.md` and `CURRENT_FRONTIER.json`, and linked back to assimilation/RFC/control surfaces.',
    'assimilation-check': 'Cross-revision adopted/rejected/deferred comparison memory stays coherent, schema-checked, policy/context wired, and exactly mirrored between `ASSIMILATION_LEDGER.md` and `ASSIMILATION_LEDGER.json`.',
    'revision-check': 'Current revision-bearing bundle/control/validation/source/frontier surfaces still agree on the packaged revision and REVISION_ANCHORS.json validators exactly mirror VALIDATION_INDEX.json validate_*.py scripts.',
    'control-check': 'Authority and lifecycle crosswalks still match opening, frontier, source-inventory, manifest/index, JSON/schema inventory, scoped asset indexes, paper/extraction-map validation, embedded-archive validation, and policy surfaces.',
    'validation-check': 'The validation/assurance inventory itself stays truthful, including exact `VALIDATION_INDEX.md`/`VALIDATION_INDEX.json` companion rendering, checked targets, composite wrappers, generated artifacts, current named bundle identity, policy, control, lifecycle, frontier, source inventory, manifest/index, JSON/text/payload/asset/paper/embedded-archive checks, claim-obligation map validation, changelog/history-anchor validation, audit-witness validation, archive-index companion validation, historical-anomaly ledger validation, and bundle identity.',
    'claim-obligation-check': '`CLAIM_OBLIGATION_MAP.json` and its Markdown companion map selected paper/release claims to concrete archive surfaces, validators, make targets, obligations, known limits, and negative-regression expectations.',
    'public-status-check': '`PUBLIC_STATUS.json` and its Markdown companion mirror the latest public-release pointer, current internal archive revision, revision delta, and no-public-payload-widening posture.',
    'ro-crate-check': '`ro-crate-metadata.json` and its Markdown companion expose selected core archive surfaces as compact RO-Crate-style JSON-LD metadata while digest-checking non-self-referential file entities and preserving manifest/index authority.',
    'changelog-check': '`CHANGELOG.md` top entry, previous-revision adjacency, descending unique recent revision headings, and current package-bundle mention agree with release, receipt, anchor, archive-index, and policy metadata.',
    'archive-index-check': '`ARCHIVE_INDEX.md` and `ARCHIVE_INDEX.json` exactly mirror the retained bundle lineage, maintain unique descending rows, and agree with current release/receipt/schema/policy/revision-anchor metadata.',
    'historical-anomaly-check': '`AUDIT/HISTORICAL_ANOMALIES.json` and its Markdown companion exactly name the carried-forward historical duplicate/order and audit-witness body-label exception set scanned from CHANGELOG.md, ARCHIVE_INDEX.json, and retained AUDIT witnesses.',
    'cross-reference-check': 'Governed machine-readable path references across restart, control, lifecycle, frontier, validation, revision-anchor, receipt, release-manifest, ADR/RFC, assimilation, and policy surfaces resolve safely to shipped files/directories, except for the intentional external named package ZIP.',
    'runner-check': 'Composite command runners (`gate.py`, `publish_audit.py`, `package_release.py`), package refresh builders, direct package transient-artifact refusal, release-manifest inclusion fencing, package-release full-gate equivalence, and the shell preflight wrapper (`publish_preflight.sh`) stay explicit, bounded, path-based, subprocess-isolated where applicable, and aligned with Makefile, validation inventory, changelog/history-anchor, audit-witness, cross-reference inventory, lifecycle, and policy surfaces.',
    'audit-witness-check': 'Retained `AUDIT/*_inventory_rev####.md` witnesses are listed in `AUDIT/README.md`, include the current revision witness, and stay wired through validation, lifecycle, context, policy, revision-anchor, and runner surfaces.',
    'identity-check': 'Internal bundle identity, recent bundle lineage, anchored digest surfaces, acyclic release-manifest perimeter digest/exclusion policy, asset-index digests, package-manifest policy links, and included-root existence remain truthful.',
    'publishing-check': 'Queue state, exact queue-item and public-release-note Markdown/JSON companions, governed publishing helper CLI entrypoints, public-surface state, and historical release state remain internally consistent.',
    'release-ledgers': 'Refreshes queue/release/public-bundle ledgers and deterministic public-release ZIP artifacts with portable regular-file metadata.',
    'preflight': 'Strict shipping wrapper check over required files, schemas, validators, scoped asset indexes, ledgers, compiled papers, full-gate execution, manifest/index completeness, JSON/schema inventory, paper/extraction-map validation, embedded-archive payload/source-freshness validation, transient-artifact absence, and final manifest verification.',
    'package-release': 'Refuses transient build/review artifacts, enforces RELEASE_MANIFEST.json included_roots coverage for every shipped path, refreshes generated indexes and release identity through subprocess-isolated refresh builders, reruns the full gate sequence through subprocess-isolated final validators, and atomically emits the current named archive bundle declared by `VALIDATION_INDEX.json`.',
}

COMPOSITE_DESCRIPTIONS: dict[str, str] = {
    'gate': '`scripts/gate.py` running explicit script paths in subprocesses for opening + command-surface + toolchain-lock + audit-witness + archive-index companion + asset-index refresh + dedupe-report refresh + source/file-index refresh + manifest/index completeness + dedupe-report freshness + JSON/schema inventory + text-payload validation + governed text-surface policy + payload-format validation + crypto-envelope/key-material validation with indexed positive/negative Ed25519 DSSE verification fixtures + provenance/absence-ledger validation + filesystem-policy validation + asset-index validation + paper/extraction-map validation + embedded-archive payload/source-freshness validation + source-index companion + source + exact ADR/RFC decision-index companions + ADR + RFC + frontier + exact assimilation-ledger companion + assimilation + revision-anchor + control + exact validation-index companion + validation-inventory + claim-obligation map + changelog/history-anchor + archive-index companion + historical-anomaly ledger + cross-reference + command-runner + identity + publishing validation, including exact release-queue item/public-release-note companion validation and publishing-helper entrypoint validation, and agent-contract opening validation.',
    'publish-audit': '`scripts/publish_audit.py` running the bounded post-gate release-materialization/post-refresh sequence in subprocesses: release queue index + release ledger + public bundle materialization + asset-index refresh + dedupe-report refresh + source/file-index refresh + source-index companion validation + exact ADR/RFC decision-index companion validation + exact validation-index companion validation + context-pack, command-surface, toolchain-lock, manifest/index, dedupe-report, governed text-surface, changelog/history-anchor, archive-index companion, historical-anomaly ledger, claim-obligation map, embedded-archive/public-bundle freshness, cross-reference, audit-witness, command-runner, publishing, and archive-identity validation.',
}


def tick(value: str) -> str:
    return f'`{value}`'


def format_paths(paths: list[str]) -> str:
    return ', '.join(tick(path) for path in paths)


def description_for(check: dict) -> str:
    target = check['make_target']
    if target == 'package-release':
        bundles = [path for path in check.get('outputs', []) if path.endswith('.zip')]
        if len(bundles) != 1:
            fail('package-release check must declare exactly one ZIP output for Markdown rendering')
        return (
            'Refuses transient build/review artifacts, enforces the release-manifest inclusion fence, refreshes generated indexes and release identity, validates governed command/audit/history/reference surfaces '
            f'and package payloads, and atomically emits `{bundles[0]}`.'
        )
    try:
        return PRIMARY_DESCRIPTIONS[target]
    except KeyError:
        fail(f'VALIDATION_INDEX.md renderer lacks description for make target: {target}')


def render_markdown(idx: dict) -> str:
    lines = [
        '# EvidenceVault validation index',
        '',
        'This file is the compact human-facing companion to `VALIDATION_INDEX.json`.',
        'It says which checked command proves what and which builder refreshes which governed artifacts.',
        '',
        '## Primary checked targets',
        '',
        '| Target | Primary scripts | What it proves or refreshes |',
        '| --- | --- | --- |',
    ]
    for check in idx['checks']:
        lines.append(f"| `make {check['make_target']}` | {format_paths(check['scripts'])} | {description_for(check)} |")

    lines.extend(['', '## Composite wrappers', ''])
    for comp in idx['composite_targets']:
        target = comp['make_target']
        try:
            description = COMPOSITE_DESCRIPTIONS[target]
        except KeyError:
            includes = ' + '.join(tick(item) for item in comp['includes'])
            description = f'includes {includes}.'
        lines.append(f'- `make {target}` = {description}')

    lines.extend(['', '## Generated artifacts', ''])
    for artifact in idx['generated_artifacts']:
        lines.append(f"- `{artifact['path']}` — {artifact['purpose']}")

    lines.extend([
        '',
        '## Boundary note',
        '',
        '`VALIDATION_INDEX.*` is not canon.',
        'Its JSON file is governing for the validation inventory, while the Markdown companion is checked as an exact renderer output from that JSON and the validator\'s bounded command descriptions.',
        '`SOURCE_INDEX.*` is likewise a governed generated recovery surface: its JSON file owns the retained-source map and its Markdown companion is checked as an exact renderer output.',
        'It is a governed recovery surface that sits beside `Makefile`, command-surface validation, subprocess-isolated command-runner, toolchain-lock validation, claim-obligation map validation, package-refresh, direct package transient-artifact refusal, release-manifest inclusion-fence, package-release full-gate equivalence, and preflight shell-wrapper validation, audit-witness validation, `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `CURRENT_FRONTIER.*` exact companion validation, `SOURCE_INDEX.*`, paper/extraction-map surfaces, duplicate-payload inventory, embedded archive payload surfaces, release-artifact revision-anchor replay, non-JSON text-payload hygiene, governed text-surface policy, residual payload-format validation, crypto-envelope/key-material validation with indexed positive/negative Ed25519 DSSE verification fixtures, toolchain-lock validation, changelog/history-anchor validation, archive-index companion validation, cross-reference validation, portable ZIP metadata validation, public-bundle freshness checks, ADR/RFC decision-index companion validation, assimilation-ledger companion validation, release-queue item/public-release-note companion validation, publishing-helper entrypoint validation, agent-contract opening validation, provenance/absence-ledger validation, and the scoped asset indexes so future passes do not have to rediscover the assurance map from scattered script names and prose.',
    ])
    return '\n'.join(lines).rstrip() + '\n'



def fail(msg: str) -> None:
    print(f"validation-index-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def load_json(rel: str):
    path = ROOT / rel
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"invalid JSON in {rel}: {exc}")


def require(rel: str) -> None:
    path = ROOT / rel
    if rel.endswith('/'):
        if not path.is_dir():
            fail(f"missing directory: {rel}")
    elif not path.exists():
        fail(f"missing path: {rel}")


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = "/".join(str(p) for p in err.path) or "<root>"
        fail(f"{label} schema violation at {where}: {err.message}")


def parse_make_targets(text: str) -> set[str]:
    targets = set()
    for line in text.splitlines():
        if line.startswith('.') or line.startswith('	') or not line.strip() or '=' in line:
            continue
        m = re.match(r'^([A-Za-z0-9_.-]+):', line)
        if m:
            targets.add(m.group(1))
    return targets


def main() -> None:
    idx = load_json('VALIDATION_INDEX.json')
    schema = load_json('schemas/validation_index.schema.json')
    opening = load_json('OPENING_CONTRACT.json')
    conformance = load_json('OPENING_SURFACE_CONFORMANCE.json')
    control = load_json('CONTROL_SURFACES.json')
    gates = load_json('LIFECYCLE_GATES.json')
    policy = load_json('publishing/CANONICAL_POLICY.json')
    release_manifest = load_json('RELEASE_MANIFEST.json')
    receipt = load_json('REVISION_RECEIPT.json')
    anchors = load_json('REVISION_ANCHORS.json')

    validate_against_schema(idx, schema, 'VALIDATION_INDEX.json')

    if idx['revision'] != receipt['revision'] or idx['revision'] != control['revision'] or idx['revision'] != gates['revision']:
        fail('validation index revision must match revision receipt, control surfaces, and lifecycle gates')

    makefile_text = (ROOT / 'Makefile').read_text(encoding='utf-8')
    make_targets = parse_make_targets(makefile_text)

    known_ids = set()
    for check in idx['checks']:
        cid = check['id']
        if cid in known_ids:
            fail(f'duplicate check id: {cid}')
        known_ids.add(cid)
        if check['make_target'] not in make_targets:
            fail(f"make target missing from Makefile: {check['make_target']}")
        for rel in check['scripts'] + check['validates']:
            require(rel)
        for rel in check['outputs']:
            if check['kind'] == 'packager' and (rel.endswith('.zip') or rel.endswith('.zip.sha256')):
                continue
            require(rel)
        for gate_id in check['used_in_gates']:
            if gate_id not in gates['gates'] and gate_id not in {'gate', 'publish-audit'}:
                fail(f'unknown lifecycle/composite gate reference: {gate_id}')

    for comp in idx['composite_targets']:
        if comp['make_target'] not in make_targets:
            fail(f"composite make target missing from Makefile: {comp['make_target']}")
        seen_includes = set()
        for cid in comp['includes']:
            if cid in seen_includes:
                fail(f"composite target {comp['make_target']} repeats check id: {cid}")
            seen_includes.add(cid)
            if cid not in known_ids:
                fail(f"composite target {comp['make_target']} references unknown check id: {cid}")

    for artifact in idx['generated_artifacts']:
        if not ((artifact['path'].endswith('.zip') or artifact['path'].endswith('.zip.sha256')) and 'package-release' in artifact['produced_by']):
            require(artifact['path'])
        for prod in artifact['produced_by']:
            if prod not in known_ids:
                fail(f"generated artifact references unknown producer: {prod}")

    opening_paths = {item['path'] for item in opening['entrypoints']}
    required_opening = {'COMMAND_RUNNER_SEQUENCE.md', 'COMMAND_RUNNER_SEQUENCE.json', 'VALIDATION_INDEX.md', 'VALIDATION_INDEX.json', 'CLAIM_OBLIGATION_MAP.md', 'CLAIM_OBLIGATION_MAP.json', 'SOURCE_INDEX.md', 'SOURCE_INDEX.json', 'CURRENT_FRONTIER.md', 'CURRENT_FRONTIER.json'}
    if not required_opening.issubset(opening_paths):
        fail('opening contract entrypoints missing VALIDATION_INDEX surfaces')
    required_root = set(conformance['required_root_entrypoints'])
    if not required_opening.issubset(required_root):
        fail('opening conformance required_root_entrypoints missing VALIDATION_INDEX surfaces')

    validation_paths = {item['path'] for item in control['surfaces']['validation_and_packaging']}
    for rel in ('scripts/build_source_index.py', 'scripts/validate_source_index.py', 'scripts/validate_context_pack.py', 'scripts/validate_makefile_surface.py', 'scripts/validate_toolchain_lock.py', 'scripts/build_dedupe_report.py', 'scripts/validate_json_inventory.py', 'scripts/validate_text_payloads.py', 'scripts/validate_text_surface_policy.py', 'scripts/validate_payload_formats.py', 'scripts/validate_crypto_envelopes.py', 'scripts/validate_provenance_ledgers.py', 'scripts/validate_filesystem_policy.py', 'scripts/build_asset_indexes.py', 'scripts/validate_asset_indexes.py', 'scripts/validate_paper_series.py', 'scripts/validate_embedded_archives.py', 'scripts/validate_changelog.py', 'scripts/validate_archive_index.py', 'scripts/validate_cross_references.py', 'scripts/validate_historical_anomalies.py', 'scripts/validate_claim_obligation_map.py', 'scripts/validate_public_status.py', 'scripts/validate_ro_crate_metadata.py', 'scripts/validate_audit_witnesses.py', 'scripts/validate_command_runners.py', 'COMMAND_RUNNER_SEQUENCE.json', 'COMMAND_RUNNER_SEQUENCE.md', 'schemas/command_runner_sequence.schema.json'):
        if rel not in validation_paths:
            fail(f'validation_and_packaging missing {rel}')
    for rel in ('VALIDATION_INDEX.md', 'VALIDATION_INDEX.json', 'scripts/validate_validation_index.py', 'scripts/validate_manifest_index.py', 'scripts/validate_dedupe_report.py', 'scripts/validate_context_pack.py', 'scripts/validate_makefile_surface.py', 'scripts/validate_toolchain_lock.py', 'scripts/build_dedupe_report.py', 'scripts/validate_json_inventory.py', 'scripts/validate_text_payloads.py', 'scripts/validate_text_surface_policy.py', 'scripts/validate_payload_formats.py', 'scripts/validate_crypto_envelopes.py', 'scripts/validate_provenance_ledgers.py', 'scripts/validate_filesystem_policy.py', 'scripts/validate_asset_indexes.py', 'scripts/validate_paper_series.py', 'scripts/validate_embedded_archives.py', 'scripts/validate_changelog.py', 'scripts/validate_archive_index.py', 'scripts/validate_cross_references.py', 'scripts/validate_historical_anomalies.py', 'scripts/validate_claim_obligation_map.py', 'scripts/validate_public_status.py', 'scripts/validate_ro_crate_metadata.py', 'scripts/validate_audit_witnesses.py', 'scripts/validate_command_runners.py', 'COMMAND_RUNNER_SEQUENCE.json', 'COMMAND_RUNNER_SEQUENCE.md', 'schemas/command_runner_sequence.schema.json'):
        if rel not in validation_paths:
            fail(f'validation_and_packaging missing {rel}')
    open_paths = {item['path'] for item in control['surfaces']['opening_and_resumption']}
    for rel in ('VALIDATION_INDEX.md', 'VALIDATION_INDEX.json', 'CLAIM_OBLIGATION_MAP.md', 'CLAIM_OBLIGATION_MAP.json'):
        if rel not in open_paths:
            fail(f'opening_and_resumption missing {rel}')

    for gate_id in ('careful_revision_pass', 'publish_audit', 'named_bundle_packaging'):
        gate = gates['gates'][gate_id]
        refs = set(gate.get('authoritative_sequence', []) + gate.get('required_surfaces', []) + gate.get('checks', []))
        needed = {'scripts/validate_validation_index.py'}
        if gate_id != 'named_bundle_packaging':
            needed.add('VALIDATION_INDEX.md')
        else:
            needed.add('VALIDATION_INDEX.json')
        if not needed.issubset(refs):
            fail(f'{gate_id} missing validation-index linkage')

    if policy.get('context_pack_validator') != 'scripts/validate_context_pack.py':
        fail('publishing/CANONICAL_POLICY.json context_pack_validator mismatch')
    if policy.get('context_pack_schema') != 'schemas/context_pack.schema.json':
        fail('publishing/CANONICAL_POLICY.json context_pack_schema mismatch')

    if policy.get('validation_index_markdown') != 'VALIDATION_INDEX.md':
        fail('publishing/CANONICAL_POLICY.json validation_index_markdown mismatch')
    if policy.get('validation_index_json') != 'VALIDATION_INDEX.json':
        fail('publishing/CANONICAL_POLICY.json validation_index_json mismatch')
    if policy.get('validation_index_validator') != 'scripts/validate_validation_index.py':
        fail('publishing/CANONICAL_POLICY.json validation_index_validator mismatch')
    if policy.get('validation_index_schema') != 'schemas/validation_index.schema.json':
        fail('publishing/CANONICAL_POLICY.json validation_index_schema mismatch')
    if policy.get('claim_obligation_map_json') != 'CLAIM_OBLIGATION_MAP.json':
        fail('publishing/CANONICAL_POLICY.json claim_obligation_map_json mismatch')
    if policy.get('claim_obligation_map_markdown') != 'CLAIM_OBLIGATION_MAP.md':
        fail('publishing/CANONICAL_POLICY.json claim_obligation_map_markdown mismatch')
    if policy.get('claim_obligation_map_schema') != 'schemas/claim_obligation_map.schema.json':
        fail('publishing/CANONICAL_POLICY.json claim_obligation_map_schema mismatch')
    if policy.get('claim_obligation_map_validator') != 'scripts/validate_claim_obligation_map.py':
        fail('publishing/CANONICAL_POLICY.json claim_obligation_map_validator mismatch')
    if policy.get('public_status_json') != 'PUBLIC_STATUS.json':
        fail('publishing/CANONICAL_POLICY.json public_status_json mismatch')
    if policy.get('public_status_markdown') != 'PUBLIC_STATUS.md':
        fail('publishing/CANONICAL_POLICY.json public_status_markdown mismatch')
    if policy.get('public_status_schema') != 'schemas/public_status.schema.json':
        fail('publishing/CANONICAL_POLICY.json public_status_schema mismatch')
    if policy.get('public_status_validator') != 'scripts/validate_public_status.py':
        fail('publishing/CANONICAL_POLICY.json public_status_validator mismatch')
    for key, expected in {
        'ro_crate_metadata_json': 'ro-crate-metadata.json',
        'ro_crate_profile_markdown': 'RO_CRATE_PROFILE.md',
        'ro_crate_metadata_schema': 'schemas/ro_crate_metadata.schema.json',
        'ro_crate_metadata_validator': 'scripts/validate_ro_crate_metadata.py',
        'release_artifact_verifier': 'scripts/verify_release_artifact.py',
        'release_artifact_verifier_validator': 'scripts/validate_command_runners.py',
        'command_runner_sequence_json': 'COMMAND_RUNNER_SEQUENCE.json',
        'command_runner_sequence_markdown': 'COMMAND_RUNNER_SEQUENCE.md',
        'command_runner_sequence_schema': 'schemas/command_runner_sequence.schema.json',
    }.items():
        if policy.get(key) != expected:
            fail(f'publishing/CANONICAL_POLICY.json {key} mismatch')

    if policy.get('source_index_markdown') != 'SOURCE_INDEX.md':
        fail('publishing/CANONICAL_POLICY.json source_index_markdown mismatch')
    if policy.get('source_index_json') != 'SOURCE_INDEX.json':
        fail('publishing/CANONICAL_POLICY.json source_index_json mismatch')
    if policy.get('source_index_builder') != 'scripts/build_source_index.py':
        fail('publishing/CANONICAL_POLICY.json source_index_builder mismatch')
    if policy.get('source_index_validator') != 'scripts/validate_source_index.py':
        fail('publishing/CANONICAL_POLICY.json source_index_validator mismatch')
    if policy.get('source_index_schema') != 'schemas/source_index.schema.json':
        fail('publishing/CANONICAL_POLICY.json source_index_schema mismatch')

    if release_manifest.get('source_index_markdown') != 'SOURCE_INDEX.md':
        fail('release manifest source_index_markdown mismatch')
    if release_manifest.get('source_index_json') != 'SOURCE_INDEX.json':
        fail('release manifest source_index_json mismatch')
    if 'source_index_json_sha256' not in release_manifest.get('identity_digests', {}):
        fail('release manifest missing source_index_json_sha256 digest')
    if release_manifest.get('current_frontier_markdown') != 'CURRENT_FRONTIER.md':
        fail('release manifest current_frontier_markdown mismatch')
    if release_manifest.get('current_frontier_json') != 'CURRENT_FRONTIER.json':
        fail('release manifest current_frontier_json mismatch')
    if 'current_frontier_json_sha256' not in release_manifest.get('identity_digests', {}):
        fail('release manifest missing current_frontier_json_sha256 digest')
    if release_manifest.get('validation_index_markdown') != 'VALIDATION_INDEX.md':
        fail('release manifest validation_index_markdown mismatch')
    if release_manifest.get('validation_index_json') != 'VALIDATION_INDEX.json':
        fail('release manifest validation_index_json mismatch')
    if 'validation_index_json_sha256' not in release_manifest.get('identity_digests', {}):
        fail('release manifest missing validation_index_json_sha256 digest')
    if release_manifest.get('claim_obligation_map_markdown') != 'CLAIM_OBLIGATION_MAP.md':
        fail('release manifest claim_obligation_map_markdown mismatch')
    if release_manifest.get('claim_obligation_map_json') != 'CLAIM_OBLIGATION_MAP.json':
        fail('release manifest claim_obligation_map_json mismatch')
    if 'claim_obligation_map_json_sha256' not in release_manifest.get('identity_digests', {}):
        fail('release manifest missing claim_obligation_map_json_sha256 digest')
    if release_manifest.get('public_status_markdown') != 'PUBLIC_STATUS.md':
        fail('release manifest public_status_markdown mismatch')
    if release_manifest.get('public_status_json') != 'PUBLIC_STATUS.json':
        fail('release manifest public_status_json mismatch')
    if 'public_status_json_sha256' not in release_manifest.get('identity_digests', {}):
        fail('release manifest missing public_status_json_sha256 digest')
    expected_release_manifest_paths = {'release_manifest_schema': 'schemas/release_manifest.schema.json', 'archive_identity_validator': 'scripts/validate_archive_identity.py', 'release_artifact_verifier': 'scripts/verify_release_artifact.py', 'release_artifact_verifier_validator': 'scripts/validate_command_runners.py', 'ro_crate_metadata_json': 'ro-crate-metadata.json', 'ro_crate_profile_markdown': 'RO_CRATE_PROFILE.md', 'ro_crate_metadata_schema': 'schemas/ro_crate_metadata.schema.json', 'ro_crate_metadata_validator': 'scripts/validate_ro_crate_metadata.py'}
    for key, expected in expected_release_manifest_paths.items():
        if release_manifest.get(key) != expected:
            fail(f'release manifest {key} mismatch')
    expected_exclusions = [{'path': 'ro-crate-metadata.json', 'reason': 'acyclic_release_identity_boundary: ro-crate-metadata.json digest-checks RELEASE_MANIFEST.json, so RELEASE_MANIFEST.json path-pins but does not digest it'}, {'path': 'RO_CRATE_PROFILE.md', 'reason': 'acyclic_release_identity_boundary: RO_CRATE_PROFILE.md exactly renders ro-crate-metadata.json and would carry the RELEASE_MANIFEST.json digest row'}]
    if release_manifest.get('identity_digest_exclusions') != expected_exclusions:
        fail('release manifest identity_digest_exclusions mismatch')
    for forbidden_key in ['ro_crate_metadata_json_sha256', 'ro_crate_profile_markdown_sha256']:
        if forbidden_key in release_manifest.get('identity_digests', {}):
            fail(f'release manifest must not contain cyclic digest key {forbidden_key}')
    if 'context_pack_sha256' not in release_manifest.get('identity_digests', {}):
        fail('release manifest missing context_pack_sha256 digest')
    for digest_key in ('artifact_index_json_sha256', 'cert_index_json_sha256', *('release_manifest_schema_sha256', 'archive_identity_validator_sha256', 'release_artifact_verifier_sha256', 'release_artifact_verifier_validator_sha256', 'ro_crate_metadata_schema_sha256', 'ro_crate_metadata_validator_sha256')):
        if digest_key not in release_manifest.get('identity_digests', {}):
            fail(f'release manifest missing {digest_key} digest')


    checks_by_id = {check['id']: check for check in idx['checks']}

    if 'claim-obligation-check' not in checks_by_id:
        fail('validation index missing claim-obligation-check')
    claim_check = checks_by_id['claim-obligation-check']
    if claim_check['scripts'] != ['scripts/validate_claim_obligation_map.py']:
        fail('claim-obligation-check scripts mismatch')
    if not {'CLAIM_OBLIGATION_MAP.json', 'CLAIM_OBLIGATION_MAP.md', 'schemas/claim_obligation_map.schema.json', 'scripts/validate_claim_obligation_map.py', 'REVISION_RECEIPT.json', 'VALIDATION_INDEX.json', 'REVISION_ANCHORS.json', 'CONTROL_SURFACES.json', 'LIFECYCLE_GATES.json', 'CONTEXT_PACK.json', 'publishing/CANONICAL_POLICY.json', 'RELEASE_MANIFEST.json', 'CURRENT_FRONTIER.json'}.issubset(set(claim_check['validates'])):
        fail('claim-obligation-check validates missing claim-obligation map surfaces')


    if 'ro-crate-check' not in checks_by_id:
        fail('validation index missing ro-crate-check')
    ro_crate_check = checks_by_id['ro-crate-check']
    if ro_crate_check['scripts'] != ['scripts/validate_ro_crate_metadata.py']:
        fail('ro-crate-check scripts mismatch')
    if not {'ro-crate-metadata.json', 'RO_CRATE_PROFILE.md', 'schemas/ro_crate_metadata.schema.json', 'scripts/validate_ro_crate_metadata.py', 'REVISION_RECEIPT.json', 'RELEASE_MANIFEST.json', 'REVISION_ANCHORS.json', 'VALIDATION_INDEX.json', 'CONTROL_SURFACES.json', 'LIFECYCLE_GATES.json', 'CONTEXT_PACK.json', 'CURRENT_FRONTIER.json', 'CLAIM_OBLIGATION_MAP.json', 'PUBLIC_STATUS.json', 'COMMAND_RUNNER_SEQUENCE.json', 'publishing/CANONICAL_POLICY.json', 'schemas/registry.json'}.issubset(set(ro_crate_check['validates'])):
        fail('ro-crate-check validates missing RO-Crate metadata bridge surfaces')

    if 'manifest-check' not in checks_by_id:
        fail('validation index missing manifest-check')
    manifest_check = checks_by_id['manifest-check']
    if manifest_check['scripts'] != ['scripts/validate_manifest_index.py']:
        fail('manifest-check scripts mismatch')
    if not {'MANIFEST.sha256', 'INDEX/files.json', 'INDEX/files.csv', 'RELEASE_MANIFEST.json'}.issubset(set(manifest_check['validates'])):
        fail('manifest-check validates missing manifest/index surfaces')
    if policy.get('manifest_index_validator') != 'scripts/validate_manifest_index.py':
        fail('publishing/CANONICAL_POLICY.json manifest_index_validator mismatch')
    if policy.get('file_inventory_json') != 'INDEX/files.json':
        fail('publishing/CANONICAL_POLICY.json file_inventory_json mismatch')
    if policy.get('file_inventory_csv') != 'INDEX/files.csv':
        fail('publishing/CANONICAL_POLICY.json file_inventory_csv mismatch')
    if policy.get('sha256_manifest') != 'MANIFEST.sha256':
        fail('publishing/CANONICAL_POLICY.json sha256_manifest mismatch')
    if policy.get('dedupe_report') != 'DEDUPE_REPORT.md':
        fail('publishing/CANONICAL_POLICY.json dedupe_report mismatch')
    if policy.get('dedupe_report_builder') != 'scripts/build_dedupe_report.py':
        fail('publishing/CANONICAL_POLICY.json dedupe_report_builder mismatch')
    if policy.get('dedupe_report_validator') != 'scripts/validate_dedupe_report.py':
        fail('publishing/CANONICAL_POLICY.json dedupe_report_validator mismatch')
    if policy.get('json_inventory_validator') != 'scripts/validate_json_inventory.py':
        fail('publishing/CANONICAL_POLICY.json json_inventory_validator mismatch')
    if policy.get('text_payload_validator') != 'scripts/validate_text_payloads.py':
        fail('publishing/CANONICAL_POLICY.json text_payload_validator mismatch')
    if policy.get('text_surface_policy_validator') != 'scripts/validate_text_surface_policy.py':
        fail('publishing/CANONICAL_POLICY.json text_surface_policy_validator mismatch')
    if policy.get('command_surface_validator') != 'scripts/validate_makefile_surface.py':
        fail('publishing/CANONICAL_POLICY.json command_surface_validator mismatch')
    if policy.get('toolchain_lock_json') != 'TOOLCHAIN_LOCK.json':
        fail('publishing/CANONICAL_POLICY.json toolchain_lock_json mismatch')
    if policy.get('toolchain_lock_markdown') != 'TOOLCHAIN_LOCK.md':
        fail('publishing/CANONICAL_POLICY.json toolchain_lock_markdown mismatch')
    if policy.get('toolchain_lock_schema') != 'schemas/toolchain_lock.schema.json':
        fail('publishing/CANONICAL_POLICY.json toolchain_lock_schema mismatch')
    if policy.get('toolchain_lock_validator') != 'scripts/validate_toolchain_lock.py':
        fail('publishing/CANONICAL_POLICY.json toolchain_lock_validator mismatch')
    if policy.get('command_runner_validator') != 'scripts/validate_command_runners.py':
        fail('publishing/CANONICAL_POLICY.json command_runner_validator mismatch')
    if policy.get('changelog_history_validator') != 'scripts/validate_changelog.py':
        fail('publishing/CANONICAL_POLICY.json changelog_history_validator mismatch')
    if policy.get('archive_index_validator') != 'scripts/validate_archive_index.py':
        fail('publishing/CANONICAL_POLICY.json archive_index_validator mismatch')
    if policy.get('historical_anomalies_validator') != 'scripts/validate_historical_anomalies.py':
        fail('publishing/CANONICAL_POLICY.json historical_anomalies_validator mismatch')
    if policy.get('historical_anomalies_json') != 'AUDIT/HISTORICAL_ANOMALIES.json':
        fail('publishing/CANONICAL_POLICY.json historical_anomalies_json mismatch')
    if policy.get('historical_anomalies_markdown') != 'AUDIT/HISTORICAL_ANOMALIES.md':
        fail('publishing/CANONICAL_POLICY.json historical_anomalies_markdown mismatch')
    if policy.get('historical_anomalies_schema') != 'schemas/historical_anomalies.schema.json':
        fail('publishing/CANONICAL_POLICY.json historical_anomalies_schema mismatch')
    if policy.get('cross_reference_validator') != 'scripts/validate_cross_references.py':
        fail('publishing/CANONICAL_POLICY.json cross_reference_validator mismatch')
    if policy.get('audit_witness_validator') != 'scripts/validate_audit_witnesses.py':
        fail('publishing/CANONICAL_POLICY.json audit_witness_validator mismatch')
    if policy.get('asset_index_builder') != 'scripts/build_asset_indexes.py':
        fail('publishing/CANONICAL_POLICY.json asset_index_builder mismatch')
    if policy.get('asset_index_validator') != 'scripts/validate_asset_indexes.py':
        fail('publishing/CANONICAL_POLICY.json asset_index_validator mismatch')
    if policy.get('artifact_index_json') != 'artifacts/ARTIFACTS_INDEX.json':
        fail('publishing/CANONICAL_POLICY.json artifact_index_json mismatch')
    if policy.get('artifact_index_csv') != 'artifacts/ARTIFACTS_INDEX.csv':
        fail('publishing/CANONICAL_POLICY.json artifact_index_csv mismatch')
    if policy.get('cert_index_json') != 'certs/CERTS_INDEX.json':
        fail('publishing/CANONICAL_POLICY.json cert_index_json mismatch')
    if policy.get('cert_index_csv') != 'certs/CERTS_INDEX.csv':
        fail('publishing/CANONICAL_POLICY.json cert_index_csv mismatch')
    if policy.get('schema_registry') != 'schemas/registry.json':
        fail('publishing/CANONICAL_POLICY.json schema_registry mismatch')
    if policy.get('schema_directory') != 'schemas/':
        fail('publishing/CANONICAL_POLICY.json schema_directory mismatch')
    if policy.get('paper_series_validator') != 'scripts/validate_paper_series.py':
        fail('publishing/CANONICAL_POLICY.json paper_series_validator mismatch')
    if policy.get('embedded_archive_validator') != 'scripts/validate_embedded_archives.py':
        fail('publishing/CANONICAL_POLICY.json embedded_archive_validator mismatch')
    if 'asset-indexes' not in checks_by_id:
        fail('validation index missing asset-indexes')
    asset_builder = checks_by_id['asset-indexes']
    if asset_builder['scripts'] != ['scripts/build_asset_indexes.py']:
        fail('asset-indexes scripts mismatch')
    if set(asset_builder['outputs']) != {'artifacts/ARTIFACTS_INDEX.json', 'artifacts/ARTIFACTS_INDEX.csv', 'certs/CERTS_INDEX.json', 'certs/CERTS_INDEX.csv'}:
        fail('asset-indexes outputs mismatch')
    if 'payload-format-check' not in checks_by_id:
        fail('validation index missing payload-format-check')
    payload_check = checks_by_id['payload-format-check']
    if payload_check['scripts'] != ['scripts/validate_payload_formats.py']:
        fail('payload-format-check scripts mismatch')
    if not {'scripts/validate_payload_formats.py', 'renders/', 'render0501_spine/', 'render0503_family/', 'render0510/', 'papers/', 'artifacts/', 'sources/'}.issubset(set(payload_check['validates'])):
        fail('payload-format-check validates missing payload format surfaces')
    if policy.get('payload_format_validator') != 'scripts/validate_payload_formats.py':
        fail('publishing/CANONICAL_POLICY.json payload_format_validator mismatch')
    if policy.get('crypto_envelope_validator') != 'scripts/validate_crypto_envelopes.py':
        fail('publishing/CANONICAL_POLICY.json crypto_envelope_validator mismatch')

    if 'crypto-check' not in checks_by_id:
        fail('validation index missing crypto-check')
    crypto_check = checks_by_id['crypto-check']
    if crypto_check['scripts'] != ['scripts/validate_crypto_envelopes.py']:
        fail('crypto-check scripts mismatch')
    if not {'scripts/validate_crypto_envelopes.py', 'certs/', 'sources/', 'artifacts/', 'certs/CRYPTO_FIXTURE_INDEX.json', 'certs/CRYPTO_FIXTURE_INDEX.md', 'schemas/crypto_fixture_index.schema.json', 'certs/verification_fixtures/rev0810_ed25519_public.pem', 'certs/verification_fixtures/rev0810_positive.dsse.json', 'certs/verification_fixtures/rev0810_negative_payload_tamper.dsse.json'}.issubset(set(crypto_check['validates'])):
        fail('crypto-check validates missing crypto-envelope/key-material surfaces')
    if policy.get('crypto_envelope_validator') != 'scripts/validate_crypto_envelopes.py':
        fail('publishing/CANONICAL_POLICY.json crypto_envelope_validator mismatch')
    if policy.get('crypto_fixture_index_json') != 'certs/CRYPTO_FIXTURE_INDEX.json':
        fail('publishing/CANONICAL_POLICY.json crypto_fixture_index_json mismatch')
    if policy.get('crypto_fixture_index_markdown') != 'certs/CRYPTO_FIXTURE_INDEX.md':
        fail('publishing/CANONICAL_POLICY.json crypto_fixture_index_markdown mismatch')
    if policy.get('crypto_fixture_index_schema') != 'schemas/crypto_fixture_index.schema.json':
        fail('publishing/CANONICAL_POLICY.json crypto_fixture_index_schema mismatch')
    if policy.get('provenance_ledger_validator') != 'scripts/validate_provenance_ledgers.py':
        fail('publishing/CANONICAL_POLICY.json provenance_ledger_validator mismatch')
    if policy.get('filesystem_policy_validator') != 'scripts/validate_filesystem_policy.py':
        fail('publishing/CANONICAL_POLICY.json filesystem_policy_validator mismatch')
    for key, expected in {
        'upstream_inputs': 'UPSTREAM_INPUTS.sha256',
        'upstream_omissions_csv': 'AUDIT/UPSTREAM_OMISSIONS.csv',
        'upstream_diff_report': 'AUDIT/UPSTREAM_DIFF_REPORT.md',
        'redactions_paths': 'REDACTIONS.paths',
        'pruned_transient_paths': 'PRUNED_TRANSIENT.paths',
    }.items():
        if policy.get(key) != expected:
            fail(f'publishing/CANONICAL_POLICY.json {key} mismatch')

    if 'filesystem-check' not in checks_by_id:
        fail('validation index missing filesystem-check')
    filesystem_check = checks_by_id['filesystem-check']
    if filesystem_check['scripts'] != ['scripts/validate_filesystem_policy.py']:
        fail('filesystem-check scripts mismatch')
    if not {'scripts/validate_filesystem_policy.py', 'scripts/', 'Makefile', 'MANIFEST.sha256', 'INDEX/files.json'}.issubset(set(filesystem_check['validates'])):
        fail('filesystem-check validates missing filesystem policy surfaces')

    if 'provenance-check' not in checks_by_id:
        fail('validation index missing provenance-check')
    provenance_check = checks_by_id['provenance-check']
    if provenance_check['scripts'] != ['scripts/validate_provenance_ledgers.py']:
        fail('provenance-check scripts mismatch')
    if not {'UPSTREAM_INPUTS.sha256', 'AUDIT/UPSTREAM_OMISSIONS.csv', 'AUDIT/UPSTREAM_DIFF_REPORT.md', 'REDACTIONS.paths', 'PRUNED_TRANSIENT.paths'}.issubset(set(provenance_check['validates'])):
        fail('provenance-check validates missing provenance/absence ledger surfaces')

    if 'asset-check' not in checks_by_id:
        fail('validation index missing asset-check')
    asset_check = checks_by_id['asset-check']
    if asset_check['scripts'] != ['scripts/validate_asset_indexes.py']:
        fail('asset-check scripts mismatch')
    if not {'artifacts/ARTIFACTS_INDEX.json', 'artifacts/ARTIFACTS_INDEX.csv', 'certs/CERTS_INDEX.json', 'certs/CERTS_INDEX.csv', 'artifacts/', 'certs/'}.issubset(set(asset_check['validates'])):
        fail('asset-check validates missing artifact/cert index surfaces')

    if 'paper-check' not in checks_by_id:
        fail('validation index missing paper-check')
    paper_check = checks_by_id['paper-check']
    if paper_check['scripts'] != ['scripts/validate_paper_series.py']:
        fail('paper-check scripts mismatch')
    if not {'PAPER_SERIES_INDEX.md', 'SERIES.md', 'CATALOG.md', 'papers/EXTRACTION_MAP.json', 'papers/'}.issubset(set(paper_check['validates'])):
        fail('paper-check validates missing canonical paper/extraction surfaces')

    if 'archive-payload-check' not in checks_by_id:
        fail('validation index missing archive-payload-check')
    payload_check = checks_by_id['archive-payload-check']
    if payload_check['scripts'] != ['scripts/validate_embedded_archives.py']:
        fail('archive-payload-check scripts mismatch')
    if not {'artifacts/repro_packs/', 'artifacts/repro_packs/original/', 'published/releases/', 'published/releases/snapshots/', 'published/releases/artifacts/', 'scripts/materialize_public_release.py'}.issubset(set(payload_check['validates'])):
        fail('archive-payload-check validates missing embedded archive/repro-pack/public-bundle freshness surfaces')

    if 'release-ledgers' in checks_by_id:
        release_outputs = set(checks_by_id['release-ledgers']['outputs'])
        if not {'published/releases/artifacts/EV-PUB-2026-03-20-public-surface-bootstrap.bundle.json', 'published/releases/artifacts/EV-PUB-2026-03-20-public-surface-bootstrap.zip'}.issubset(release_outputs):
            fail('release-ledgers outputs missing materialized public-release bundle artifacts')
        generated_paths = {artifact['path'] for artifact in idx['generated_artifacts']}
        if not {'published/releases/artifacts/EV-PUB-2026-03-20-public-surface-bootstrap.bundle.json', 'published/releases/artifacts/EV-PUB-2026-03-20-public-surface-bootstrap.zip'}.issubset(generated_paths):
            fail('generated artifacts missing materialized public-release bundle artifacts')

    if 'dedupe-report' not in checks_by_id:
        fail('validation index missing dedupe-report')
    dedupe_builder = checks_by_id['dedupe-report']
    if dedupe_builder['scripts'] != ['scripts/build_dedupe_report.py']:
        fail('dedupe-report scripts mismatch')
    if set(dedupe_builder['outputs']) != {'DEDUPE_REPORT.md'}:
        fail('dedupe-report outputs mismatch')

    if 'dedupe-check' not in checks_by_id:
        fail('validation index missing dedupe-check')
    dedupe_check = checks_by_id['dedupe-check']
    if dedupe_check['scripts'] != ['scripts/validate_dedupe_report.py']:
        fail('dedupe-check scripts mismatch')
    if not {'DEDUPE_REPORT.md', 'scripts/build_dedupe_report.py', 'scripts/validate_dedupe_report.py'}.issubset(set(dedupe_check['validates'])):
        fail('dedupe-check validates missing dedupe report surfaces')
    generated_paths = {artifact['path'] for artifact in idx['generated_artifacts']}
    if 'DEDUPE_REPORT.md' not in generated_paths:
        fail('generated artifacts missing DEDUPE_REPORT.md')

    if 'json-check' not in checks_by_id:
        fail('validation index missing json-check')
    json_check = checks_by_id['json-check']
    if json_check['scripts'] != ['scripts/validate_json_inventory.py']:
        fail('json-check scripts mismatch')
    if not {'schemas/', 'schemas/registry.json', 'scripts/validate_json_inventory.py'}.issubset(set(json_check['validates'])):
        fail('json-check validates missing JSON/schema inventory surfaces')

    if 'text-surface-check' not in checks_by_id:
        fail('validation index missing text-surface-check')
    text_surface_check = checks_by_id['text-surface-check']
    if text_surface_check['scripts'] != ['scripts/validate_text_surface_policy.py']:
        fail('text-surface-check scripts mismatch')
    if not {'scripts/validate_text_surface_policy.py', 'INDEX/files.csv', 'artifacts/ARTIFACTS_INDEX.csv', 'certs/CERTS_INDEX.csv', 'release_queue/'}.issubset(set(text_surface_check['validates'])):
        fail('text-surface-check validates missing governed text-surface policy surfaces')

    if 'text-check' not in checks_by_id:
        fail('validation index missing text-check')
    text_check = checks_by_id['text-check']
    if text_check['scripts'] != ['scripts/validate_text_payloads.py']:
        fail('text-check scripts mismatch')
    if not {'scripts/validate_text_payloads.py', 'sources/', 'papers/', 'artifacts/', 'certs/'}.issubset(set(text_check['validates'])):
        fail('text-check validates missing text payload surfaces')


    if 'public-status-check' not in checks_by_id:
        fail('validation index missing public-status-check')
    public_status_check = checks_by_id['public-status-check']
    if public_status_check['scripts'] != ['scripts/validate_public_status.py']:
        fail('public-status-check scripts mismatch')
    if not {'PUBLIC_STATUS.json', 'PUBLIC_STATUS.md', 'schemas/public_status.schema.json', 'scripts/validate_public_status.py', 'REVISION_RECEIPT.json', 'RELEASE_MANIFEST.json', 'REVISION_ANCHORS.json', 'published/releases/LATEST.json', 'published/releases/RELEASE_INDEX.json', 'published/PUBLIC_SURFACE.json', 'publishing/CANONICAL_POLICY.json', 'VALIDATION_INDEX.json', 'CONTROL_SURFACES.json', 'LIFECYCLE_GATES.json', 'CONTEXT_PACK.json', 'CURRENT_FRONTIER.json'}.issubset(set(public_status_check['validates'])):
        fail('public-status-check validates missing public-status bridge surfaces')

    if 'toolchain-check' not in checks_by_id:
        fail('validation index missing toolchain-check')
    toolchain_check = checks_by_id['toolchain-check']
    if toolchain_check['scripts'] != ['scripts/validate_toolchain_lock.py']:
        fail('toolchain-check scripts mismatch')
    if not {'TOOLCHAIN_LOCK.json', 'TOOLCHAIN_LOCK.md', 'schemas/toolchain_lock.schema.json', 'scripts/validate_toolchain_lock.py', 'scripts/package_release.py', 'scripts/publish_preflight.sh', 'REVISION_RECEIPT.json', 'VALIDATION_INDEX.json', 'CONTEXT_PACK.json', 'CONTROL_SURFACES.json', 'LIFECYCLE_GATES.json', 'publishing/CANONICAL_POLICY.json'}.issubset(set(toolchain_check['validates'])):
        fail('toolchain-check validates missing toolchain lock surfaces')

    if 'command-surface-check' not in checks_by_id:
        fail('validation index missing command-surface-check')
    command_surface_check = checks_by_id['command-surface-check']
    if command_surface_check['scripts'] != ['scripts/validate_makefile_surface.py']:
        fail('command-surface-check scripts mismatch')
    if not {'Makefile', 'CONTEXT_PACK.json', 'VALIDATION_INDEX.json', 'publishing/CANONICAL_POLICY.json', 'RELEASE_MANIFEST.json', 'scripts/validate_makefile_surface.py'}.issubset(set(command_surface_check['validates'])):
        fail('command-surface-check validates missing command-surface inventory surfaces')

    if 'changelog-check' not in checks_by_id:
        fail('validation index missing changelog-check')
    changelog_check = checks_by_id['changelog-check']
    if changelog_check['scripts'] != ['scripts/validate_changelog.py']:
        fail('changelog-check scripts mismatch')
    if not {'CHANGELOG.md', 'REVISION_RECEIPT.json', 'RELEASE_MANIFEST.json', 'REVISION_ANCHORS.json', 'ARCHIVE_INDEX.json', 'publishing/CANONICAL_POLICY.json', 'scripts/validate_changelog.py'}.issubset(set(changelog_check['validates'])):
        fail('changelog-check validates missing governed history-anchor surfaces')



    if 'archive-index-check' not in checks_by_id:
        fail('validation index missing archive-index-check')
    archive_index_check = checks_by_id['archive-index-check']
    if archive_index_check['scripts'] != ['scripts/validate_archive_index.py']:
        fail('archive-index-check scripts mismatch')
    if not {'ARCHIVE_INDEX.md', 'ARCHIVE_INDEX.json', 'schemas/archive_bundle_index.schema.json', 'RELEASE_MANIFEST.json', 'REVISION_RECEIPT.json', 'REVISION_ANCHORS.json', 'VALIDATION_INDEX.json', 'CONTEXT_PACK.json', 'CONTROL_SURFACES.json', 'LIFECYCLE_GATES.json', 'publishing/CANONICAL_POLICY.json', 'scripts/validate_archive_index.py'}.issubset(set(archive_index_check['validates'])):
        fail('archive-index-check validates missing governed archive-index companion surfaces')

    if 'historical-anomaly-check' not in checks_by_id:
        fail('validation index missing historical-anomaly-check')
    historical_check = checks_by_id['historical-anomaly-check']
    if historical_check['scripts'] != ['scripts/validate_historical_anomalies.py']:
        fail('historical-anomaly-check scripts mismatch')
    if not {'AUDIT/', 'AUDIT/HISTORICAL_ANOMALIES.json', 'AUDIT/HISTORICAL_ANOMALIES.md', 'schemas/historical_anomalies.schema.json', 'CHANGELOG.md', 'ARCHIVE_INDEX.json', 'scripts/validate_historical_anomalies.py'}.issubset(set(historical_check['validates'])):
        fail('historical-anomaly-check validates missing governed historical-anomaly surfaces')

    if 'audit-witness-check' not in checks_by_id:
        fail('validation index missing audit-witness-check')
    audit_witness_check = checks_by_id['audit-witness-check']
    if audit_witness_check['scripts'] != ['scripts/validate_audit_witnesses.py']:
        fail('audit-witness-check scripts mismatch')
    if not {'AUDIT/README.md', 'CONTROL_SURFACES.json', 'LIFECYCLE_GATES.json', 'VALIDATION_INDEX.json', 'CONTEXT_PACK.json', 'REVISION_ANCHORS.json', 'publishing/CANONICAL_POLICY.json', 'scripts/validate_audit_witnesses.py'}.issubset(set(audit_witness_check['validates'])):
        fail('audit-witness-check validates missing governed audit-witness surfaces')

    if 'cross-reference-check' not in checks_by_id:
        fail('validation index missing cross-reference-check')
    cross_reference_check = checks_by_id['cross-reference-check']
    if cross_reference_check['scripts'] != ['scripts/validate_cross_references.py']:
        fail('cross-reference-check scripts mismatch')
    if not {'OPENING_CONTRACT.json', 'CONTROL_SURFACES.json', 'LIFECYCLE_GATES.json', 'CURRENT_FRONTIER.json', 'VALIDATION_INDEX.json', 'REVISION_ANCHORS.json', 'RELEASE_MANIFEST.json', 'publishing/CANONICAL_POLICY.json', 'scripts/validate_cross_references.py'}.issubset(set(cross_reference_check['validates'])):
        fail('cross-reference-check validates missing governed machine-readable path-reference surfaces')

    for gate_id in ('careful_revision_pass', 'publish_audit', 'named_bundle_packaging'):
        gate = gates['gates'][gate_id]
        if 'scripts/validate_makefile_surface.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing command-surface validator')
        if 'scripts/validate_manifest_index.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing manifest/index validator')
        if 'scripts/build_dedupe_report.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing dedupe-report builder')
        if 'scripts/validate_dedupe_report.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing dedupe-report validator')
        if 'scripts/validate_json_inventory.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing JSON-inventory validator')
        if 'scripts/validate_text_payloads.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing text-payload validator')
        if 'scripts/validate_text_surface_policy.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing text-surface policy validator')
        if 'scripts/validate_payload_formats.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing payload-format validator')
        if 'scripts/validate_crypto_envelopes.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing crypto-envelope validator')
        if 'scripts/validate_provenance_ledgers.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing provenance-ledger validator')
        if 'scripts/validate_filesystem_policy.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing filesystem-policy validator')
        if 'scripts/validate_asset_indexes.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing asset-index validator')
        if 'scripts/validate_paper_series.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing paper-series validator')
        if 'scripts/validate_embedded_archives.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing embedded-archive validator')
        if 'scripts/validate_changelog.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing changelog/history-anchor validator')
        if 'scripts/validate_archive_index.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing archive-index validator')
        if 'scripts/validate_historical_anomalies.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing historical-anomaly validator')
        if 'scripts/validate_claim_obligation_map.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing claim-obligation validator')
        if 'scripts/validate_public_status.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing public-status validator')
        if 'scripts/validate_ro_crate_metadata.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing RO-Crate metadata validator')
        if 'scripts/validate_cross_references.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing cross-reference validator')
        if 'scripts/validate_audit_witnesses.py' not in set(gate.get('checks', [])):
            fail(f'{gate_id} missing audit-witness validator')
    if 'frontier-check' not in checks_by_id:
        fail('validation index missing frontier-check')
    frontier_validates = set(checks_by_id['frontier-check']['validates'])
    if not {'CURRENT_FRONTIER.md', 'CURRENT_FRONTIER.json', 'RFC_INDEX.md', 'ASSIMILATION_LEDGER.md'}.issubset(frontier_validates):
        fail('frontier-check missing current-frontier/RFC/assimilation linkage')

    package_outputs = checks_by_id['package-release']['outputs']
    expected_package_outputs = [release_manifest['bundle'], release_manifest['bundle'] + '.sha256']
    if package_outputs != expected_package_outputs:
        fail('package-release outputs must match RELEASE_MANIFEST.json bundle and sidecar')
    package_generated = [artifact['path'] for artifact in idx['generated_artifacts'] if artifact['produced_by'] == ['package-release']]
    expected_package_generated = [release_manifest['bundle'], release_manifest['bundle'] + '.sha256']
    if package_generated != expected_package_generated:
        fail('generated package-release artifacts must match RELEASE_MANIFEST.json bundle and sidecar')

    md_text = (ROOT / 'VALIDATION_INDEX.md').read_text(encoding='utf-8')
    expected_md = render_markdown(idx)
    if md_text != expected_md:
        fail('VALIDATION_INDEX.md must exactly mirror render_markdown(VALIDATION_INDEX.json)')
    for check in idx['checks']:
        marker = f"`make {check['make_target']}`"
        if marker not in md_text:
            fail(f'VALIDATION_INDEX.md missing make target marker: {marker}')
    for comp in idx['composite_targets']:
        marker = f"`make {comp['make_target']}`"
        if marker not in md_text:
            fail(f'VALIDATION_INDEX.md missing composite target marker: {marker}')
    for artifact in idx['generated_artifacts']:
        if artifact['path'] not in md_text:
            fail(f"VALIDATION_INDEX.md missing generated artifact path: {artifact['path']}")
    named_bundles = set(re.findall(r'EvidenceVault-rev\d{4}-\d{4}\.\d{2}\.\d{2}\.\d{2}\.\d{2}-[A-Za-z0-9_.-]+\.zip', md_text))
    if named_bundles != {release_manifest['bundle']}:
        fail(f'VALIDATION_INDEX.md named bundle set must equal current RELEASE_MANIFEST bundle; got {sorted(named_bundles)!r}')

    anchored = {item['path'] for item in anchors.get('anchored_surfaces', [])}
    if 'VALIDATION_INDEX.json' not in anchored:
        fail('revision anchors missing VALIDATION_INDEX.json')
    if 'SOURCE_INDEX.json' not in anchored:
        fail('revision anchors missing SOURCE_INDEX.json')
    if 'CURRENT_FRONTIER.json' not in anchored:
        fail('revision anchors missing CURRENT_FRONTIER.json')
    if 'CLAIM_OBLIGATION_MAP.json' not in anchored:
        fail('revision anchors missing CLAIM_OBLIGATION_MAP.json')
    if 'PUBLIC_STATUS.json' not in anchored:
        fail('revision anchors missing PUBLIC_STATUS.json')
    if 'ro-crate-metadata.json' not in anchored:
        fail('revision anchors missing ro-crate-metadata.json')

    print(f'validation-index-validate: OK ({len(idx["checks"])} targets mirrored, {len(idx["generated_artifacts"])} generated artifacts)')


if __name__ == '__main__':
    main()
