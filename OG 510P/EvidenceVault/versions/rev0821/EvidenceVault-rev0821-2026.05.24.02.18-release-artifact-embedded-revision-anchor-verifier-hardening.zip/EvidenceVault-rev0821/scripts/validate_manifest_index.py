#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INDEX_JSON = ROOT / 'INDEX' / 'files.json'
INDEX_CSV = ROOT / 'INDEX' / 'files.csv'
MANIFEST = ROOT / 'MANIFEST.sha256'
EXCLUDE_FROM_INDEX = {'MANIFEST.sha256', 'INDEX/files.json', 'INDEX/files.csv'}
EXCLUDE_FROM_MANIFEST = {'MANIFEST.sha256'}
INDEX_FIELDS = ['path', 'size', 'sha256', 'category', 'project', 'ext']
HEX64 = re.compile(r'^[0-9a-f]{64}$')


def fail(msg: str) -> None:
    print(f'manifest-index-validate: FAIL: {msg}', file=sys.stderr)
    sys.exit(1)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 16), b''):
            h.update(chunk)
    return h.hexdigest()


def all_files() -> list[str]:
    files: list[str] = []
    for p in sorted(ROOT.rglob('*')):
        rel = p.relative_to(ROOT).as_posix()
        if p.is_symlink():
            fail(f'archive tree contains unsupported symlink: {rel}')
        if p.is_dir():
            continue
        if not p.is_file():
            fail(f'archive tree contains unsupported non-regular entry: {rel}')
        files.append(rel)
    return files


def classify(rel_path: str) -> tuple[str, str, str]:
    parts = rel_path.split('/')
    category = parts[0]
    project = parts[1] if len(parts) > 1 else ''
    ext = Path(rel_path).suffix.lower()
    return category, project, ext


def expected_index_row(rel_path: str) -> dict[str, object]:
    path = ROOT / rel_path
    category, project, ext = classify(rel_path)
    return {
        'path': rel_path,
        'size': path.stat().st_size,
        'sha256': sha256_file(path),
        'category': category,
        'project': project,
        'ext': ext,
    }


def validate_manifest(expected_files: list[str]) -> None:
    if not MANIFEST.is_file():
        fail('missing MANIFEST.sha256')
    rows: list[tuple[str, str]] = []
    seen: set[str] = set()
    for n, line in enumerate(MANIFEST.read_text(encoding='utf-8').splitlines(), start=1):
        if not line.strip():
            fail(f'MANIFEST.sha256 line {n} is blank')
        try:
            digest, rel = line.split(None, 1)
        except ValueError:
            fail(f'MANIFEST.sha256 line {n} is malformed')
        rel = rel.strip()
        if not HEX64.fullmatch(digest):
            fail(f'MANIFEST.sha256 line {n} has a non-SHA256 digest')
        if rel in seen:
            fail(f'MANIFEST.sha256 has duplicate path: {rel}')
        seen.add(rel)
        if rel in EXCLUDE_FROM_MANIFEST:
            fail(f'MANIFEST.sha256 must not include self-reference: {rel}')
        path = ROOT / rel
        if not path.is_file():
            fail(f'MANIFEST.sha256 references missing file: {rel}')
        actual = sha256_file(path)
        if actual != digest:
            fail(f'MANIFEST.sha256 mismatch for {rel}: expected {digest}, got {actual}')
        rows.append((digest, rel))
    expected_paths = [p for p in expected_files if p not in EXCLUDE_FROM_MANIFEST]
    actual_paths = [rel for _, rel in rows]
    if actual_paths != expected_paths:
        missing = sorted(set(expected_paths) - set(actual_paths))[:10]
        extra = sorted(set(actual_paths) - set(expected_paths))[:10]
        fail(f'MANIFEST.sha256 path coverage/order mismatch; missing={missing}, extra={extra}')


def validate_index_json(expected_files: list[str]) -> list[dict[str, object]]:
    if not INDEX_JSON.is_file():
        fail('missing INDEX/files.json')
    try:
        rows = json.loads(INDEX_JSON.read_text(encoding='utf-8'))
    except Exception as exc:
        fail(f'invalid JSON in INDEX/files.json: {exc}')
    if not isinstance(rows, list):
        fail('INDEX/files.json must be a list')
    expected_paths = [p for p in expected_files if p not in EXCLUDE_FROM_INDEX]
    expected_by_path = {p: expected_index_row(p) for p in expected_paths}
    actual_paths = []
    seen: set[str] = set()
    for i, row in enumerate(rows, start=1):
        if not isinstance(row, dict):
            fail(f'INDEX/files.json row {i} is not an object')
        if set(row) != set(INDEX_FIELDS):
            fail(f'INDEX/files.json row {i} has unexpected fields: {sorted(row)}')
        rel = row['path']
        if not isinstance(rel, str):
            fail(f'INDEX/files.json row {i} path is not a string')
        if rel in seen:
            fail(f'INDEX/files.json has duplicate path: {rel}')
        seen.add(rel)
        actual_paths.append(rel)
        if rel in EXCLUDE_FROM_INDEX:
            fail(f'INDEX/files.json includes excluded generated/self path: {rel}')
        expected = expected_by_path.get(rel)
        if expected is None:
            fail(f'INDEX/files.json references unexpected path: {rel}')
        if row != expected:
            fail(f'INDEX/files.json row mismatch for {rel}')
    if actual_paths != expected_paths:
        missing = sorted(set(expected_paths) - set(actual_paths))[:10]
        extra = sorted(set(actual_paths) - set(expected_paths))[:10]
        fail(f'INDEX/files.json path coverage/order mismatch; missing={missing}, extra={extra}')
    return rows


def validate_index_csv(json_rows: list[dict[str, object]]) -> None:
    if not INDEX_CSV.is_file():
        fail('missing INDEX/files.csv')
    with INDEX_CSV.open(newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != INDEX_FIELDS:
            fail(f'INDEX/files.csv fieldnames mismatch: {reader.fieldnames}')
        rows = list(reader)
    expected = [
        {
            'path': str(r['path']),
            'size': str(r['size']),
            'sha256': str(r['sha256']),
            'category': str(r['category']),
            'project': str(r['project']),
            'ext': str(r['ext']),
        }
        for r in json_rows
    ]
    if rows != expected:
        fail('INDEX/files.csv rows do not exactly mirror INDEX/files.json')


def validate_release_manifest_file_count(expected_files: list[str]) -> None:
    path = ROOT / 'RELEASE_MANIFEST.json'
    if not path.is_file():
        fail('missing RELEASE_MANIFEST.json')
    try:
        manifest = json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        fail(f'invalid JSON in RELEASE_MANIFEST.json: {exc}')
    if manifest.get('inventory') != 'INDEX/files.json':
        fail('RELEASE_MANIFEST.json inventory must be INDEX/files.json')
    if manifest.get('file_count') != len(expected_files):
        fail(f'RELEASE_MANIFEST.json file_count mismatch: expected {len(expected_files)}, got {manifest.get("file_count")}')


def main() -> None:
    expected_files = all_files()
    validate_manifest(expected_files)
    rows = validate_index_json(expected_files)
    validate_index_csv(rows)
    validate_release_manifest_file_count(expected_files)
    print('manifest-index-validate: OK')


if __name__ == '__main__':
    main()
