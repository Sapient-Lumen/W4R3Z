#!/usr/bin/env python3
"""Audit upstream zip inputs against the EvidenceVault working tree.

This script is intentionally conservative: it only tries to establish that
*something equivalent* to each upstream file exists, either in-place under
sources/<proj>/... or relocated into curated locations (renders/, artifacts/).

It produces:
  - AUDIT/UPSTREAM_DIFF_REPORT.md
  - AUDIT/UPSTREAM_OMISSIONS.csv

Run from the repository root.
"""

from __future__ import annotations

import csv
import os
import re
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

ROOT = Path(__file__).resolve().parents[1]

UPSTREAMS: Dict[str, str] = {
    "ctg": "../ctg_evolving_docs_v219.zip",
    "docf": "../docf_evolving_docs_v86_44_ai.zip",
    "pact": "../PACT_evolving_iter173.zip",
    "ocf_llm": "../ocf_llm_paper_evolving_current_v264.zip",
    "streamfold": "../streamfold_evolving_docs_v3_26.zip",
    "zkrtp_portfolio": "../zk_rtp_evolving_documents_portfolio_2026-02-28_v3.85draft_turn50.zip",
    "zkrtp_v2": "../zk_rtp_v2_02_archive_v2_02.zip",
}

BUILD_EXTS = {
    ".aux", ".log", ".out", ".toc", ".bbl", ".blg", ".bcf", ".run.xml",
    ".fdb_latexmk", ".fls", ".synctex.gz",
}

CACHE_PATTERNS = [
    re.compile(r"(^|/)__pycache__(/|$)"),
]

SECRET_PATTERNS = [
    re.compile(r"private", re.I),
    re.compile(r"priv", re.I),
    re.compile(r"secret", re.I),
]

SECRET_EXTS = {".pem", ".key", ".p12", ".pfx", ".der", ".hex"}

TMP_PATTERNS = [
    re.compile(r"(^|/)_tmp"),
    re.compile(r"_tmp_"),
    re.compile(r"/tmp(/|$)"),
    re.compile(r"\.tmp$", re.I),
]

JUNK_NAMES = {".DS_Store", "Thumbs.db"}

NESTED_ARCHIVE_EXTS = {".zip", ".tar", ".tgz", ".tar.gz"}


@dataclass
class Omission:
    project: str
    upstream_path: str
    normalized_path: str
    reason: str


def is_build_artifact(p: str) -> bool:
    lp = p.lower()
    for ext in BUILD_EXTS:
        if lp.endswith(ext):
            return True

    # Versioned PDFs are typically retained only selectively (they are build outputs).
    base = Path(p).name.lower()
    if base.startswith("paper_v") and base.endswith(".pdf"):
        return True
    if base.startswith("zk_rtp_paper_evolving_v") and base.endswith(".pdf"):
        return True

    # Compiled verifier binaries (Go) are build products; we retain source by default.
    if "verifier_go/" in lp and Path(p).suffix == "" and base.startswith("zkrtp_"):
        return True

    return False


def is_cache(p: str) -> bool:
    if p.endswith(".pyc"):
        return True
    return any(r.search(p) for r in CACHE_PATTERNS)


def is_tmp(p: str) -> bool:
    return any(r.search(p) for r in TMP_PATTERNS)


def is_junk(p: str) -> bool:
    return Path(p).name in JUNK_NAMES


def is_secret(p: str) -> bool:
    ext = Path(p).suffix.lower()
    if ext not in SECRET_EXTS:
        return False
    s = p.lower()
    base = Path(p).name.lower()

    # Common secret-key markers used across the upstreams.
    if base.endswith("_sk.pem") or base.endswith("_sk.hex") or base.endswith(".sk.pem"):
        return True
    if "ed25519_sk" in base or "issuer_sk" in base:
        return True

    return (
        any(r.search(s) for r in SECRET_PATTERNS)
        or "ed25519_private" in s
        or "operator_private" in s
    )


def is_nested_archive(p: str) -> bool:
    lp = p.lower()
    return any(lp.endswith(ext) for ext in NESTED_ARCHIVE_EXTS)


def list_zip_files(zip_path: Path) -> List[str]:
    with zipfile.ZipFile(zip_path, "r") as z:
        names = [n for n in z.namelist() if not n.endswith("/") and not n.startswith("__MACOSX")]
    return names


def best_strip_components(names: List[str], dest_root: Path) -> Tuple[int, float]:
    """Pick how many leading path components to strip to maximize matches."""
    best_k, best_ratio = 0, -1.0
    for k in (0, 1, 2):
        hits = 0
        total = 0
        for n in names:
            parts = n.replace("\\", "/").split("/")
            if len(parts) <= k:
                continue
            rel = "/".join(parts[k:])
            if not rel:
                continue
            total += 1
            if (dest_root / rel).exists():
                hits += 1
        ratio = hits / total if total else 0.0
        if ratio > best_ratio:
            best_ratio = ratio
            best_k = k
    return best_k, best_ratio


def normalize_path(n: str, k: int) -> str:
    parts = n.replace("\\", "/").split("/")
    if len(parts) <= k:
        return ""
    return "/".join(parts[k:])


def relocated_ok(project: str, rel: str) -> bool:
    """Allow specific relocations into renders/ or artifacts/."""
    fn = Path(rel).name

    # PDFs of papers/figures: allow relocation into renders/legacy_pdfs/<project>/
    if fn.lower().endswith(".pdf"):
        base = ROOT / "renders" / "legacy_pdfs" / project
        if base.exists() and any(True for _ in base.rglob(fn)):
            return True

    # zkRTP portfolio acceptance repro packs: allow relocation into artifacts/repro_packs/original/
    if fn in {
        "acceptance_delta_repro_pack.tar.gz",
        "acceptance_repro_pack.tar.gz",
        "acceptance_semantic_repro_pack.tar.gz",
    }:
        alt = ROOT / "artifacts" / "repro_packs" / "original" / fn
        if alt.exists():
            return True

    return False


def main() -> None:
    audit_dir = ROOT / "AUDIT"
    audit_dir.mkdir(parents=True, exist_ok=True)

    omissions: List[Omission] = []
    summary = {}

    for proj, zrel in UPSTREAMS.items():
        zpath = (ROOT / zrel).resolve()
        dest = ROOT / "sources" / ("ocf_llm" if proj == "ocf_llm" else proj)
        names = list_zip_files(zpath)

        # strip the common first component implicitly by trying k=1/2
        k, ratio = best_strip_components(names, dest)

        present = 0
        relocated = 0
        omitted = 0

        for n in names:
            rel = normalize_path(n, k)
            if not rel:
                continue
            if (dest / rel).exists():
                present += 1
                continue
            if relocated_ok(proj if proj != "ocf_llm" else "ocf_llm", rel):
                relocated += 1
                continue

            # classify omission
            reason = "uncategorized"
            if is_secret(rel):
                reason = "secret"
            elif is_build_artifact(rel):
                reason = "build"
            elif is_cache(rel):
                reason = "cache"
            elif is_tmp(rel):
                reason = "tmp"
            elif is_junk(rel):
                reason = "junk"
            elif is_nested_archive(rel):
                reason = "nested_archive"

            omissions.append(Omission(
                project=proj,
                upstream_path=n,
                normalized_path=rel,
                reason=reason,
            ))
            omitted += 1

        summary[proj] = {
            "zip": zpath.name,
            "files": len(names),
            "strip_components": k,
            "match_ratio": round(ratio, 4),
            "present_in_sources": present,
            "present_relocated": relocated,
            "omitted": omitted,
        }

    # write CSV
    csv_path = audit_dir / "UPSTREAM_OMISSIONS.csv"
    with csv_path.open("w", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["project", "reason", "upstream_path", "normalized_path"])
        for o in sorted(omissions, key=lambda x: (x.project, x.reason, x.normalized_path)):
            w.writerow([o.project, o.reason, o.upstream_path, o.normalized_path])

    # reason breakdown
    reason_counts = {}
    for o in omissions:
        reason_counts.setdefault(o.project, {})
        reason_counts[o.project].setdefault(o.reason, 0)
        reason_counts[o.project][o.reason] += 1

    # write report
    md_path = audit_dir / "UPSTREAM_DIFF_REPORT.md"
    with md_path.open("w") as f:
        f.write("# Upstream audit (EvidenceVault)\n\n")
        f.write("This report compares each upstream zip against `sources/<project>/...`, allowing a small set of explicit relocations into `renders/` and `artifacts/`.\n\n")

        for proj, s in summary.items():
            f.write(f"## {proj}\n\n")
            f.write(f"- Upstream: `{s['zip']}`\n")
            f.write(f"- Files in zip: **{s['files']}**\n")
            f.write(f"- Path strip heuristic: strip **{s['strip_components']}** leading component(s) (match ratio ~{s['match_ratio']})\n")
            f.write(f"- Present in `sources/`: **{s['present_in_sources']}**\n")
            f.write(f"- Present via relocation: **{s['present_relocated']}**\n")
            f.write(f"- Omitted: **{s['omitted']}**\n\n")

            rc = reason_counts.get(proj, {})
            if not rc:
                f.write("No omissions recorded.\n\n")
                continue

            f.write("Omissions by category:\n\n")
            for reason, cnt in sorted(rc.items(), key=lambda x: (-x[1], x[0])):
                f.write(f"- `{reason}`: {cnt}\n")

            # show up to 12 uncategorized examples
            unc = [o for o in omissions if o.project == proj and o.reason == "uncategorized"]
            if unc:
                f.write("\nUncategorized omissions (inspect manually):\n\n")
                for o in unc[:12]:
                    f.write(f"- `{o.normalized_path}`\n")
            f.write("\n")

        f.write("\n---\n\n")
        f.write("Generated by `scripts/audit_upstreams.py`. Full omissions list in `AUDIT/UPSTREAM_OMISSIONS.csv`.\n")


if __name__ == "__main__":
    main()
