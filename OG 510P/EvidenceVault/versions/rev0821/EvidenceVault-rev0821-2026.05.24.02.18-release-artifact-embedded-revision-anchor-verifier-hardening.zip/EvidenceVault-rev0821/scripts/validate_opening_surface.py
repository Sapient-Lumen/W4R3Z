#!/usr/bin/env python3
import json
import re
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parent.parent


def fail(msg: str) -> None:
    print(f"opening-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def load_json(rel: str):
    path = ROOT / rel
    try:
        return json.loads(path.read_text())
    except Exception as exc:
        fail(f"invalid JSON in {rel}: {exc}")


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = '/'.join(str(p) for p in err.path) or '<root>'
        fail(f"{label} schema violation at {where}: {err.message}")


def require_paths(paths):
    for rel in paths:
        if rel and not (ROOT / rel).exists():
            fail(f"missing path: {rel}")


def parse_start_here_read_first(text: str):
    marker = "## Read first"
    if marker not in text:
        fail("START_HERE.md missing '## Read first' section")
    section = text.split(marker, 1)[1]
    lines = []
    for line in section.splitlines():
        if line.startswith("## ") and lines:
            break
        m = re.match(r"\s*\d+\.\s+`([^`]+)`\s*$", line)
        if m:
            lines.append(m.group(1))
    if not lines:
        fail("START_HERE.md read-first list could not be parsed")
    return lines


def parse_agents_read_first(text: str):
    marker = "## Read first"
    if marker not in text:
        fail("AGENTS.md missing '## Read first' section")
    section = text.split(marker, 1)[1]
    lines = []
    for line in section.splitlines():
        if line.startswith("## ") and lines:
            break
        m = re.match(r"\s*\d+\.\s+`([^`]+)`\s*$", line)
        if m:
            lines.append(m.group(1))
    if not lines:
        fail("AGENTS.md read-first list could not be parsed")
    return lines


def parse_readme_start_here(text: str):
    marker = "## Start here"
    if marker not in text:
        fail("README.md missing '## Start here' section")
    section = text.split(marker, 1)[1]
    refs = []
    for line in section.splitlines():
        if line.startswith("## ") and refs:
            break
        m = re.match(r"\s*-\s+`([^`]+)`\s+—", line)
        if m:
            refs.append(m.group(1))
    if not refs:
        fail("README.md start-here list could not be parsed")
    return refs


def main() -> None:
    opening_contract = load_json("OPENING_CONTRACT.json")
    opening_conformance = load_json("OPENING_SURFACE_CONFORMANCE.json")
    opening_contract_schema = load_json("schemas/opening_contract.schema.json")
    opening_conformance_schema = load_json("schemas/opening_surface_conformance.schema.json")
    context_pack = load_json("CONTEXT_PACK.json")
    revision_receipt = load_json("REVISION_RECEIPT.json")
    policy = load_json("publishing/CANONICAL_POLICY.json")

    validate_against_schema(opening_contract, opening_contract_schema, "OPENING_CONTRACT.json")
    validate_against_schema(opening_conformance, opening_conformance_schema, "OPENING_SURFACE_CONFORMANCE.json")

    require_paths(opening_conformance["required_root_entrypoints"])
    require_paths(opening_contract["cold_open_minimum"])
    require_paths([item["path"] for item in opening_contract["entrypoints"]])
    require_paths([opening_conformance["policy_reference"], opening_conformance["revision_receipt_history_anchor"], 'AGENTS.md', 'Makefile', 'VALIDATION_INDEX.md', 'VALIDATION_INDEX.json', 'SOURCE_INDEX.md', 'SOURCE_INDEX.json', 'CURRENT_FRONTIER.md', 'CURRENT_FRONTIER.json', 'ASSIMILATION_LEDGER.md', 'ASSIMILATION_LEDGER.json', 'ADR_INDEX.md', 'ADR_INDEX.json', 'RFC_INDEX.md', 'RFC_INDEX.json', 'RELEASE_MANIFEST.json', 'REVISION_ANCHORS.json', 'ARCHIVE_INDEX.md', 'ARCHIVE_INDEX.json', 'schemas/opening_contract.schema.json', 'schemas/opening_surface_conformance.schema.json'])
    require_paths(revision_receipt["touched_surfaces"])
    require_paths(['ASSIMILATION_LEDGER.md', 'ASSIMILATION_LEDGER.json', 'RFC_INDEX.md', 'RFC_INDEX.json'])

    profiles = {item["id"]: item for item in opening_contract["profiles"]}
    for profile_id in [opening_conformance["start_here_profile_id"], opening_conformance["context_pack_profile_id"], revision_receipt["opening_profile"]]:
        if profile_id not in profiles:
            fail(f"unknown opening profile id: {profile_id}")

    for profile in opening_contract["profiles"]:
        require_paths([profile["start"]] + profile["sequence"])

    start_here_text = (ROOT / "START_HERE.md").read_text()
    readme_text = (ROOT / "README.md").read_text()
    agents_text = (ROOT / "AGENTS.md").read_text()
    changelog_text = (ROOT / revision_receipt["history_anchor"]).read_text()

    start_here_sequence = parse_start_here_read_first(start_here_text)
    expected_sequence = profiles[opening_conformance["start_here_profile_id"]]["sequence"]
    if start_here_sequence != expected_sequence:
        fail("START_HERE.md read-first sequence does not match OPENING_CONTRACT.json")

    if context_pack.get("read_order") != profiles[opening_conformance["context_pack_profile_id"]]["sequence"]:
        fail("CONTEXT_PACK.json read_order does not match OPENING_CONTRACT.json")

    readme_refs = parse_readme_start_here(readme_text)
    for rel in opening_conformance["readme_start_here_must_reference"]:
        if rel not in readme_refs:
            fail(f"README.md start-here section missing required reference: {rel}")

    agents_sequence = parse_agents_read_first(agents_text)
    expected_agents_sequence = opening_conformance["agents_read_first_sequence"]
    require_paths(expected_agents_sequence)
    if agents_sequence != expected_agents_sequence:
        fail("AGENTS.md read-first sequence does not match OPENING_SURFACE_CONFORMANCE.json")
    for command in opening_conformance["agents_command_posture_must_reference"]:
        if command not in agents_text:
            fail(f"AGENTS.md command posture missing required command: {command}")

    for rel in opening_conformance["start_here_must_reference"]:
        if rel not in start_here_text:
            fail(f"START_HERE.md missing required reference: {rel}")

    if revision_receipt["history_anchor"] != opening_conformance["revision_receipt_history_anchor"]:
        fail("revision receipt history anchor does not match opening conformance anchor")

    top_heading = next((line for line in changelog_text.splitlines() if line.startswith("## ")), None)
    if top_heading is None:
        fail("CHANGELOG.md missing revision heading")
    if revision_receipt["revision"] not in top_heading:
        fail("REVISION_RECEIPT.json revision does not match top CHANGELOG heading")

    if policy.get("opening_contract") != "OPENING_CONTRACT.json":
        fail("publishing/CANONICAL_POLICY.json opening_contract mismatch")
    if policy.get("opening_surface_conformance") != "OPENING_SURFACE_CONFORMANCE.json":
        fail("publishing/CANONICAL_POLICY.json opening_surface_conformance mismatch")
    if policy.get("opening_contract_schema") != "schemas/opening_contract.schema.json":
        fail("publishing/CANONICAL_POLICY.json opening_contract_schema mismatch")
    if policy.get("opening_surface_conformance_schema") != "schemas/opening_surface_conformance.schema.json":
        fail("publishing/CANONICAL_POLICY.json opening_surface_conformance_schema mismatch")
    if policy.get("opening_surface_validator") != "scripts/validate_opening_surface.py":
        fail("publishing/CANONICAL_POLICY.json opening_surface_validator mismatch")
    if not any("explicit_agent_contract_opening_validation" in item for item in policy.get("principles", [])):
        fail("publishing/CANONICAL_POLICY.json principles missing explicit_agent_contract_opening_validation")
    if policy.get("agent_contract") != "AGENTS.md":
        fail("publishing/CANONICAL_POLICY.json agent_contract mismatch")
    if policy.get("operator_command_surface") != "Makefile":
        fail("publishing/CANONICAL_POLICY.json operator_command_surface mismatch")
    if policy.get("validation_index_markdown") != "VALIDATION_INDEX.md":
        fail("publishing/CANONICAL_POLICY.json validation_index_markdown mismatch")
    if policy.get("validation_index_json") != "VALIDATION_INDEX.json":
        fail("publishing/CANONICAL_POLICY.json validation_index_json mismatch")
    if policy.get("validation_index_validator") != "scripts/validate_validation_index.py":
        fail("publishing/CANONICAL_POLICY.json validation_index_validator mismatch")
    if policy.get("source_index_markdown") != "SOURCE_INDEX.md":
        fail("publishing/CANONICAL_POLICY.json source_index_markdown mismatch")
    if policy.get("source_index_json") != "SOURCE_INDEX.json":
        fail("publishing/CANONICAL_POLICY.json source_index_json mismatch")
    if policy.get("source_index_builder") != "scripts/build_source_index.py":
        fail("publishing/CANONICAL_POLICY.json source_index_builder mismatch")
    if policy.get("source_index_validator") != "scripts/validate_source_index.py":
        fail("publishing/CANONICAL_POLICY.json source_index_validator mismatch")
    if policy.get("operator_context_pack") != "CONTEXT_PACK.json":
        fail("publishing/CANONICAL_POLICY.json operator_context_pack mismatch")
    if policy.get("context_pack_validator") != "scripts/validate_context_pack.py":
        fail("publishing/CANONICAL_POLICY.json context_pack_validator mismatch")
    if policy.get("context_pack_schema") != "schemas/context_pack.schema.json":
        fail("publishing/CANONICAL_POLICY.json context_pack_schema mismatch")
    if context_pack.get("revision") != revision_receipt["revision"]:
        fail("CONTEXT_PACK.json revision does not match REVISION_RECEIPT.json")
    if policy.get("operator_revision_receipt") != "REVISION_RECEIPT.json":
        fail("publishing/CANONICAL_POLICY.json operator_revision_receipt mismatch")
    if policy.get("assimilation_ledger_markdown") != "ASSIMILATION_LEDGER.md":
        fail("publishing/CANONICAL_POLICY.json assimilation_ledger_markdown mismatch")
    if policy.get("adr_index_markdown") != "ADR_INDEX.md":
        fail("publishing/CANONICAL_POLICY.json adr_index_markdown mismatch")
    if policy.get("adr_index_json") != "ADR_INDEX.json":
        fail("publishing/CANONICAL_POLICY.json adr_index_json mismatch")
    if policy.get("adr_index_validator") != "scripts/validate_adrs.py":
        fail("publishing/CANONICAL_POLICY.json adr_index_validator mismatch")
    if policy.get("rfc_index_markdown") != "RFC_INDEX.md":
        fail("publishing/CANONICAL_POLICY.json rfc_index_markdown mismatch")
    if policy.get("rfc_index_json") != "RFC_INDEX.json":
        fail("publishing/CANONICAL_POLICY.json rfc_index_json mismatch")
    if policy.get("rfc_index_validator") != "scripts/validate_rfcs.py":
        fail("publishing/CANONICAL_POLICY.json rfc_index_validator mismatch")
    if policy.get("current_frontier_markdown") != "CURRENT_FRONTIER.md":
        fail("publishing/CANONICAL_POLICY.json current_frontier_markdown mismatch")
    if policy.get("current_frontier_json") != "CURRENT_FRONTIER.json":
        fail("publishing/CANONICAL_POLICY.json current_frontier_json mismatch")
    if policy.get("current_frontier_validator") != "scripts/validate_current_frontier.py":
        fail("publishing/CANONICAL_POLICY.json current_frontier_validator mismatch")
    if policy.get("assimilation_ledger_json") != "ASSIMILATION_LEDGER.json":
        fail("publishing/CANONICAL_POLICY.json assimilation_ledger_json mismatch")
    if policy.get("assimilation_ledger_validator") != "scripts/validate_assimilation_ledger.py":
        fail("publishing/CANONICAL_POLICY.json assimilation_ledger_validator mismatch")
    if policy.get("operator_release_manifest") != "RELEASE_MANIFEST.json":
        fail("publishing/CANONICAL_POLICY.json operator_release_manifest mismatch")
    if policy.get("revision_anchors") != "REVISION_ANCHORS.json":
        fail("publishing/CANONICAL_POLICY.json revision_anchors mismatch")
    if policy.get("revision_anchor_validator") != "scripts/validate_revision_anchors.py":
        fail("publishing/CANONICAL_POLICY.json revision_anchor_validator mismatch")
    if policy.get("archive_bundle_index_markdown") != "ARCHIVE_INDEX.md":
        fail("publishing/CANONICAL_POLICY.json archive_bundle_index_markdown mismatch")
    if policy.get("archive_bundle_index_json") != "ARCHIVE_INDEX.json":
        fail("publishing/CANONICAL_POLICY.json archive_bundle_index_json mismatch")
    if policy.get("archive_identity_validator") != "scripts/validate_archive_identity.py":
        fail("publishing/CANONICAL_POLICY.json archive_identity_validator mismatch")

    if not re.fullmatch(r"rev\d{4}", revision_receipt["revision"]):
        fail("revision receipt has invalid revision format")
    if revision_receipt["project"] != "EvidenceVault":
        fail("revision receipt project must be EvidenceVault")

    print("opening-validate: OK")


if __name__ == "__main__":
    main()
