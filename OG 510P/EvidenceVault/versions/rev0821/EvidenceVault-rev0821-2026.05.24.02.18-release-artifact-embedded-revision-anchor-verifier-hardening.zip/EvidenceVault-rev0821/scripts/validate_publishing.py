#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
RELEASE_DIR = ROOT / 'release_queue' / 'decisions'
PUBLISHED_RELEASE_DIR = ROOT / 'published' / 'releases'
ARTIFACT_DIR = PUBLISHED_RELEASE_DIR / 'artifacts'
QUEUE_DIR = ROOT / 'release_queue'
QUEUE_STATES = ['candidate', 'hold', 'published_ready', 'published']
QUEUE_STATE_DIRS = {'candidate': 'candidates', 'hold': 'hold', 'published_ready': 'published_ready', 'published': 'published'}


def fail(msg: str) -> None:
    print(f"publishing-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def load_json(path: Path):
    try:
        return json.loads(path.read_text())
    except Exception as exc:
        fail(f"invalid JSON in {path}: {exc}")


def require_paths(paths):
    for rel in paths:
        if rel and not (ROOT / rel).exists():
            fail(f"missing path: {rel}")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def snapshot_manifest_bytes(snapshot: dict) -> bytes:
    manifest = {
        'version': snapshot['manifest_version'],
        'owner': 'published/',
        'entry_points': [{'path': item['path'], 'role': item['role']} for item in snapshot['entry_points']],
        'canonical_context': snapshot['canonical_context'],
        'principles': snapshot['principles'],
    }
    return (json.dumps(manifest, indent=2) + '\n').encode()


def release_field_line(label: str, value: object) -> str:
    text = '' if value is None else str(value)
    return f"- {label}: `{text}`" if text else f"- {label}:"


def render_public_release_markdown(data: dict) -> str:
    """Render the canonical human companion for a public release record."""
    lines = [
        '# Public release',
        '',
        release_field_line('Release ID', data.get('release_id')),
        release_field_line('Date', data.get('date')),
        release_field_line('Status', data.get('status')),
        release_field_line('Decision', data.get('decision_id')),
        release_field_line('Queue item', data.get('queue_item_id')),
        release_field_line('Revision', data.get('revision')),
        release_field_line('Public surface manifest', data.get('public_surface_manifest')),
        release_field_line('Public surface manifest sha256', data.get('public_surface_manifest_sha256')),
        release_field_line('Public surface snapshot', data.get('public_surface_snapshot')),
        release_field_line('Public surface snapshot sha256', data.get('public_surface_snapshot_sha256')),
        '',
        '## Summary',
        data.get('summary', ''),
        '',
        '## Public paths',
    ]
    public_paths = data.get('public_paths', [])
    if public_paths:
        lines.extend(f'- `{rel}`' for rel in public_paths)
    else:
        lines.append('-')
    lines.extend([
        '',
        '## Public surface snapshot',
        f"- `{data.get('public_surface_snapshot', '')}`",
        '',
        '## Release artifact',
        f"- `{data.get('artifact_zip', '')}`",
        f"- `{data.get('artifact_manifest', '')}`",
        '',
        '## Archive note',
        data.get('archive_note', ''),
    ])
    return '\n'.join(lines) + '\n'

def queue_field_line(label: str, value: object) -> str:
    text = '' if value is None else str(value)
    return f"- {label}: {text}" if text else f"- {label}:"


def render_queue_item_markdown(data: dict) -> str:
    """Render the canonical human companion for a release-queue item."""
    lines = [
        '# Release queue item',
        '',
        f"- Date: {data.get('date', '')}",
        f"- Queue item id: {data.get('item_id', '')}",
        f"- State: {data.get('state', '')}",
        f"- Scope: {data.get('scope', '')}",
        f"- Owner: {data.get('owner', '')}",
        queue_field_line('Decision id', data.get('decision_id')),
        queue_field_line('Public release id', data.get('public_release_id')),
        '',
        '## Tracked paths',
    ]
    tracked = data.get('tracked_paths', [])
    if tracked:
        lines.extend(f"- `{rel}`" for rel in tracked)
    else:
        lines.append('-')
    lines.extend([
        '',
        '## Summary',
        data.get('summary', ''),
        '',
        '## Next action',
        data.get('next_action') or '-',
    ])
    return '\n'.join(lines) + '\n'




def require_cli_help(rel: str) -> None:
    """Smoke-test governed publishing helper entry points without changing state."""
    env = os.environ.copy()
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    result = subprocess.run(
        [sys.executable, str(ROOT / rel), '--help'],
        cwd=ROOT,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        timeout=20,
    )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout).strip().splitlines()
        suffix = f": {detail[-1]}" if detail else ''
        fail(f"publishing helper entrypoint failed --help: {rel}{suffix}")
    if 'usage:' not in result.stdout.lower():
        fail(f"publishing helper entrypoint did not emit argparse usage: {rel}")

def require_exact_file(path: Path, expected: str, label: str) -> None:
    actual = path.read_text(encoding='utf-8')
    if actual != expected:
        fail(f"{label} drift: {path.relative_to(ROOT).as_posix()} does not exactly match its JSON render")



policy = load_json(ROOT / 'publishing' / 'CANONICAL_POLICY.json')
public_surface = load_json(ROOT / 'published' / 'PUBLIC_SURFACE.json')
release_schema = load_json(ROOT / 'schemas' / 'release_decision.schema.json')
public_schema = load_json(ROOT / 'schemas' / 'public_surface_manifest.schema.json')
public_release_schema = load_json(ROOT / 'schemas' / 'public_release.schema.json')
ledger_schema = load_json(ROOT / 'schemas' / 'release_ledger.schema.json')
bundle_schema = load_json(ROOT / 'schemas' / 'public_release_bundle.schema.json')
artifact_index_schema = load_json(ROOT / 'schemas' / 'public_release_artifact_index.schema.json')
queue_item_schema = load_json(ROOT / 'schemas' / 'release_queue_item.schema.json')
queue_index_schema = load_json(ROOT / 'schemas' / 'release_queue_index.schema.json')
snapshot_schema = load_json(ROOT / 'schemas' / 'public_surface_snapshot.schema.json')
release_ledger = load_json(PUBLISHED_RELEASE_DIR / 'RELEASE_INDEX.json')
latest_release = load_json(PUBLISHED_RELEASE_DIR / 'LATEST.json')
artifact_index = load_json(ARTIFACT_DIR / 'ARTIFACT_INDEX.json')
queue_index = load_json(QUEUE_DIR / 'QUEUE_INDEX.json')

required_policy_keys = [
    'canonical_architecture', 'canonical_publishing', 'canonical_public_surface',
    'canonical_public_surface_manifest', 'canonical_public_release_ledger',
    'canonical_latest_public_release', 'canonical_public_release_artifact_index',
    'release_queue', 'preflight_script', 'publishing_validator', 'release_ledger_builder',
    'public_release_materializer', 'bundle_manifest_schema', 'bundle_artifact_index_schema',
    'canonical_release_queue_index', 'public_surface_snapshot_schema', 'publishing_templates', 'queue_item_publisher', 'text_payload_validator', 'text_surface_policy_validator', 'payload_format_validator', 'command_surface_validator', 'crypto_envelope_validator', 'provenance_ledger_validator', 'filesystem_policy_validator'
]
for key in required_policy_keys:
    if key not in policy:
        fail(f"publishing policy missing key: {key}")

require_paths([
    policy['canonical_architecture'], policy['canonical_publishing'], policy['canonical_title_index'],
    policy['canonical_lookup'], policy['canonical_provenance'], policy['canonical_history'],
    policy['canonical_public_surface_manifest'], policy['canonical_public_release_ledger'],
    policy['canonical_latest_public_release'], policy['canonical_public_release_artifact_index'],
    policy['publishing_validator'], policy['release_ledger_builder'], policy['public_release_materializer'],
    policy['bundle_manifest_schema'], policy['bundle_artifact_index_schema'], policy['canonical_release_queue_index'],
    policy['queue_index_builder'], policy['queue_item_schema'], policy['queue_index_schema'],
    policy['queue_item_scaffolder'], policy['queue_item_transition'], policy['public_surface_snapshot_schema'],
    policy['queue_item_publisher'], *policy['publishing_templates'].values(), policy['text_payload_validator'], policy['text_surface_policy_validator'], policy['payload_format_validator'], policy['command_surface_validator'], policy['crypto_envelope_validator'], policy['provenance_ledger_validator'], policy['filesystem_policy_validator']
])
for rel in policy['release_queue'].values():
    require_paths([rel])
for rel in policy['publishing_templates'].values():
    require_paths([rel])
principles = '\n'.join(policy.get('principles', []))
if 'explicit_release_queue_item_companion_validation' not in principles:
    fail('publishing/CANONICAL_POLICY.json principles missing release-queue item companion validation')
if 'explicit_public_release_note_companion_validation' not in principles:
    fail('publishing/CANONICAL_POLICY.json principles missing public-release note companion validation')
if 'explicit_publishing_helper_entrypoint_validation' not in principles:
    fail('publishing/CANONICAL_POLICY.json principles missing publishing-helper entrypoint validation')
for helper in [policy['queue_item_scaffolder'], policy['queue_item_transition'], policy['queue_item_publisher']]:
    require_cli_help(helper)

missing_public = set(public_schema['required']) - public_surface.keys()
if missing_public:
    fail(f"public surface manifest missing keys: {sorted(missing_public)}")
if public_surface.get('owner') != 'published/':
    fail('public surface owner must be published/')
entry_paths = []
for entry in public_surface.get('entry_points', []):
    if set(public_schema['properties']['entry_points']['items']['required']) - entry.keys():
        fail(f"public surface entry malformed: {entry}")
    if not (ROOT / entry['path']).exists():
        fail(f"public surface entry point missing: {entry['path']}")
    entry_paths.append(entry['path'])
for rel in public_surface.get('canonical_context', {}).values():
    if not (ROOT / rel).exists():
        fail(f"public surface canonical context missing path: {rel}")
for must in ['published/releases/RELEASE_INDEX.json', 'published/releases/LATEST.json', 'published/releases/artifacts/ARTIFACT_INDEX.json']:
    if must not in entry_paths:
        fail(f"public surface entry_points missing: {must}")

decisions_by_id = {}
for path in sorted(RELEASE_DIR.glob('*.json')):
    data = load_json(path)
    missing = set(release_schema['required']) - data.keys()
    if missing:
        fail(f"decision file {path.name} missing keys: {sorted(missing)}")
    if not re.match(release_schema['properties']['decision_id']['pattern'], data['decision_id']):
        fail(f"decision file {path.name} has invalid decision_id")
    require_paths(data.get('candidate_paths', []) + data.get('public_paths', []))
    if not path.with_suffix('.md').exists():
        fail(f"decision markdown missing for {path.name}")
    decisions_by_id[data['decision_id']] = data

release_records = {}
for path in sorted(PUBLISHED_RELEASE_DIR.glob('*.json')):
    if path.name in {'RELEASE_INDEX.json', 'LATEST.json'}:
        continue
    data = load_json(path)
    missing = set(public_release_schema['required']) - data.keys()
    if missing:
        fail(f"release record {path.name} missing keys: {sorted(missing)}")
    if data['decision_id'] not in decisions_by_id:
        fail(f"release record {path.name} references unknown decision_id: {data['decision_id']}")
    if decisions_by_id[data['decision_id']]['status'] != 'publish':
        fail(f"release record {path.name} must point to a publish decision")
    md_path = path.with_suffix('.md')
    if not md_path.exists():
        fail(f"release markdown missing for {path.name}")
    if data['notes_path'] != md_path.relative_to(ROOT).as_posix():
        fail(f"release notes_path mismatch for {path.name}")
    require_exact_file(md_path, render_public_release_markdown(data), 'public release Markdown companion')
    require_paths(data['public_paths'] + [data['notes_path'], data['public_surface_snapshot']])
    snap = load_json(ROOT / data['public_surface_snapshot'])
    miss_snap = set(snapshot_schema['required']) - snap.keys()
    if miss_snap:
        fail(f"snapshot {data['public_surface_snapshot']} missing keys: {sorted(miss_snap)}")
    if snap['release_id'] != data['release_id']:
        fail(f"snapshot mismatch for {data['release_id']}")
    if snap['source_manifest'] != data['public_surface_manifest']:
        fail(f"snapshot source manifest mismatch for {data['release_id']}")
    if sha256_file(ROOT / data['public_surface_snapshot']) != data['public_surface_snapshot_sha256']:
        fail(f"snapshot digest mismatch for {data['release_id']}")
    frozen_manifest = snapshot_manifest_bytes(snap)
    if sha256_bytes(frozen_manifest) != data['public_surface_manifest_sha256']:
        fail(f"historical public surface digest mismatch for {data['release_id']}")
    if snap['source_manifest_sha256'] != data['public_surface_manifest_sha256']:
        fail(f"snapshot source digest mismatch for {data['release_id']}")
    for entry in snap['entry_points']:
        src = ROOT / entry['path']
        if not src.exists():
            fail(f"snapshot entry point missing in working tree: {entry['path']}")
    release_records[data['release_id']] = data

missing_ledger = set(ledger_schema['required']) - release_ledger.keys()
if missing_ledger:
    fail(f"release ledger missing keys: {sorted(missing_ledger)}")
if release_ledger.get('owner') != 'published/releases/':
    fail('release ledger owner must be published/releases/')
ledger_release_ids = [item['release_id'] for item in release_ledger.get('release_records', [])]
if sorted(ledger_release_ids) != sorted(release_records):
    fail('release ledger does not match public release records')
for item in release_ledger.get('release_records', []):
    rec = release_records[item['release_id']]
    if item['path'] != f"published/releases/{Path(rec['notes_path']).stem}.json":
        fail(f"release ledger path mismatch for {item['release_id']}")
    if item['artifact_manifest'] != rec['artifact_manifest'] or item['artifact_zip'] != rec['artifact_zip']:
        fail(f"release ledger artifact linkage mismatch for {item['release_id']}")
    if item['queue_item_id'] != rec['queue_item_id'] or item['public_surface_snapshot'] != rec['public_surface_snapshot']:
        fail(f"release ledger queue/snapshot linkage mismatch for {item['release_id']}")
    if item['public_surface_manifest_sha256'] != rec['public_surface_manifest_sha256'] or item['public_surface_snapshot_sha256'] != rec['public_surface_snapshot_sha256']:
        fail(f"release ledger digest linkage mismatch for {item['release_id']}")
if latest_release['release_id'] != release_ledger['latest_release_id']:
    fail('LATEST.json does not match release ledger latest_release_id')
if latest_release['release_id'] not in release_records:
    fail('LATEST.json release_id is not present in public release records')

missing_artifact_index = set(artifact_index_schema['required']) - artifact_index.keys()
if missing_artifact_index:
    fail(f"artifact index missing keys: {sorted(missing_artifact_index)}")
if artifact_index.get('owner') != 'published/releases/artifacts/':
    fail('artifact index owner must be published/releases/artifacts/')
artifact_ids = [a['release_id'] for a in artifact_index.get('artifacts', [])]
if sorted(artifact_ids) != sorted(release_records):
    fail('artifact index does not match public release record set')
for item in artifact_index.get('artifacts', []):
    rec = release_records[item['release_id']]
    if item['manifest_path'] != rec['artifact_manifest'] or item['bundle_path'] != rec['artifact_zip']:
        fail(f"artifact index linkage mismatch for {item['release_id']}")
    if item['queue_item_id'] != rec['queue_item_id']:
        fail(f"artifact index queue item mismatch for {item['release_id']}")
    if item['public_surface_manifest_sha256'] != rec['public_surface_manifest_sha256'] or item['public_surface_snapshot_sha256'] != rec['public_surface_snapshot_sha256']:
        fail(f"artifact index digest mismatch for {item['release_id']}")
    require_paths([item['manifest_path'], item['bundle_path']])
    manifest = load_json(ROOT / item['manifest_path'])
    missing_manifest = set(bundle_schema['required']) - manifest.keys()
    if missing_manifest:
        fail(f"bundle manifest {item['manifest_path']} missing keys: {sorted(missing_manifest)}")
    if manifest['release_id'] != item['release_id'] or manifest['queue_item_id'] != rec['queue_item_id']:
        fail(f"bundle manifest linkage mismatch for {item['release_id']}")
    bundle_path = ROOT / item['bundle_path']
    if manifest['bundle_sha256'] != sha256_file(bundle_path):
        fail(f"bundle digest mismatch for {item['release_id']}")
    if manifest['public_surface_manifest_sha256'] != rec['public_surface_manifest_sha256'] or manifest['public_surface_snapshot_sha256'] != rec['public_surface_snapshot_sha256']:
        fail(f"bundle manifest digest mismatch for {item['release_id']}")
    if manifest['source_record_sha256'] != sha256_file(ROOT / manifest['source_record']):
        fail(f"bundle manifest source record digest mismatch for {item['release_id']}")
    included = {f['path']: f for f in manifest.get('included_files', [])}
    if rec['public_surface_snapshot'] not in included:
        fail(f"bundle manifest missing public surface snapshot for {item['release_id']}")
    if rec['public_surface_manifest'] not in included:
        fail(f"bundle manifest missing reconstructed public surface manifest for {item['release_id']}")
    if included[rec['public_surface_snapshot']]['sha256'] != rec['public_surface_snapshot_sha256']:
        fail(f"bundle snapshot digest mismatch for {item['release_id']}")
    if included[rec['public_surface_manifest']]['sha256'] != rec['public_surface_manifest_sha256']:
        fail(f"bundle historical manifest digest mismatch for {item['release_id']}")

missing_queue = set(queue_index_schema['required']) - queue_index.keys()
if missing_queue:
    fail(f"queue index missing keys: {sorted(missing_queue)}")
if queue_index.get('owner') != 'release_queue/':
    fail('queue index owner must be release_queue/')
queue_records = []
queue_by_id = {}
for state in QUEUE_STATES:
    state_dir = QUEUE_DIR / QUEUE_STATE_DIRS[state]
    for path in sorted(state_dir.glob('*.json')):
        data = load_json(path)
        missing = set(queue_item_schema['required']) - data.keys()
        if missing:
            fail(f"queue item {path.name} missing keys: {sorted(missing)}")
        if data['state'] != state:
            fail(f"queue item {path.name} state does not match directory {state}")
        require_paths(data.get('tracked_paths', []))
        md_path = path.with_suffix('.md')
        if not md_path.exists():
            fail(f"queue markdown missing for {path.name}")
        require_exact_file(md_path, render_queue_item_markdown(data), 'release queue item Markdown companion')
        if state in {'hold', 'published_ready', 'published'} and not data.get('decision_id'):
            fail(f"queue item {path.name} in state {state} must reference a decision_id")
        if data.get('decision_id') and data['decision_id'] not in decisions_by_id:
            fail(f"queue item {path.name} references unknown decision_id: {data['decision_id']}")
        if state == 'hold' and decisions_by_id[data['decision_id']]['status'] not in {'hold', 'no-release'}:
            fail(f"queue item {path.name} in hold state must point to hold/no-release decision")
        if state == 'published_ready' and decisions_by_id[data['decision_id']]['status'] != 'publish':
            fail(f"queue item {path.name} in published_ready state must point to publish decision")
        if state == 'published':
            if decisions_by_id[data['decision_id']]['status'] != 'publish':
                fail(f"queue item {path.name} in published state must point to publish decision")
            if not data.get('public_release_id'):
                fail(f"queue item {path.name} in published state must reference public_release_id")
        if data.get('public_release_id') and data['public_release_id'] not in release_records:
            fail(f"queue item {path.name} references unknown public_release_id: {data['public_release_id']}")
        queue_by_id[data['item_id']] = data
        queue_records.append({'item_id': data['item_id'], 'state': state, 'path': path.relative_to(ROOT).as_posix(), 'date': data['date'], **({'decision_id': data['decision_id']} if data.get('decision_id') else {}), **({'public_release_id': data['public_release_id']} if data.get('public_release_id') else {})})

index_records = []
for state in QUEUE_STATES:
    index_records.extend(queue_index.get('states', {}).get(state, []))
if sorted(index_records, key=lambda x: x['item_id']) != sorted(queue_records, key=lambda x: x['item_id']):
    fail('queue index does not match queue item set')

for release_id, rec in release_records.items():
    qid = rec['queue_item_id']
    if qid not in queue_by_id:
        fail(f"release record {release_id} points to missing queue item {qid}")
    q = queue_by_id[qid]
    if q['state'] != 'published':
        fail(f"release record {release_id} queue item must be in published state")
    if q.get('public_release_id') != release_id:
        fail(f"release record {release_id} queue item linkage mismatch")

print(f'publishing-validate: OK ({len(queue_records)} queue-item Markdown companions exact, {len(release_records)} public release Markdown companions exact, 3 helper CLI entrypoints live)')
