#!/usr/bin/env python3
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
RELEASE_DIR = ROOT / 'published' / 'releases'
EXCLUDE = {'RELEASE_INDEX.json', 'LATEST.json'}


def fail(msg: str) -> None:
    print(f"release-ledger: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def load_json(path: Path):
    try:
        return json.loads(path.read_text())
    except Exception as exc:
        fail(f"invalid JSON in {path}: {exc}")


def main() -> None:
    records = []
    for path in sorted(RELEASE_DIR.glob('*.json')):
        if path.name in EXCLUDE:
            continue
        data = load_json(path)
        if data.get('status') != 'published':
            fail(f"release record {path.name} must have status 'published'")
        for rel in [data.get('notes_path', ''), data.get('artifact_manifest', ''), data.get('artifact_zip', ''), data.get('public_surface_snapshot', '')]:
            if not rel:
                fail(f"release record {path.name} missing release linkage")
        if not (ROOT / data['notes_path']).exists():
            fail(f"release record {path.name} references missing notes path: {data['notes_path']}")
        records.append((data['date'], data['release_id'], path, data))

    if not records:
        fail('no public release records found under published/releases/')

    records.sort()
    latest = records[-1][3]
    ledger = {
        'owner': 'published/releases/',
        'latest_release_id': latest['release_id'],
        'release_records': [
            {
                'release_id': data['release_id'],
                'path': path.relative_to(ROOT).as_posix(),
                'date': data['date'],
                'revision': data['revision'],
                'decision_id': data['decision_id'],
                'queue_item_id': data['queue_item_id'],
                'public_surface_snapshot': data['public_surface_snapshot'],
                'public_surface_manifest_sha256': data['public_surface_manifest_sha256'],
                'public_surface_snapshot_sha256': data['public_surface_snapshot_sha256'],
                'artifact_manifest': data['artifact_manifest'],
                'artifact_zip': data['artifact_zip'],
            }
            for _, _, path, data in records
        ],
    }

    (RELEASE_DIR / 'RELEASE_INDEX.json').write_text(json.dumps(ledger, indent=2) + '\n')
    (RELEASE_DIR / 'LATEST.json').write_text(json.dumps(latest, indent=2) + '\n')
    print(f"release-ledger: OK ({len(records)} release record(s))")


if __name__ == '__main__':
    main()
