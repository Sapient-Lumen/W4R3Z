#!/usr/bin/env python3
"""Validate the claim-obligation crosswalk.

The archive has many validators and several paper/release claims.  This check
keeps the bridge between those layers explicit: each selected claim must name the
surfaces, validators, make targets, obligations, limits, and a negative
regression that make the claim locally reviewable.  The map does not create new
canon; it makes existing claim-to-validator support falsifiable.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
MAP_JSON = ROOT / 'CLAIM_OBLIGATION_MAP.json'
MAP_MD = ROOT / 'CLAIM_OBLIGATION_MAP.md'
SCHEMA = ROOT / 'schemas' / 'claim_obligation_map.schema.json'
EXPECTED_VALIDATOR = 'scripts/validate_claim_obligation_map.py'


def fail(msg: str) -> None:
    print(f'claim-obligation-validate: FAIL: {msg}', file=sys.stderr)
    sys.exit(1)


def load_json(rel: str | Path):
    path = ROOT / rel if isinstance(rel, str) else rel
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        label = path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else str(path)
        fail(f'invalid JSON in {label}: {exc}')


def require(rel: str) -> None:
    if not isinstance(rel, str) or not rel:
        fail(f'empty/non-string path reference: {rel!r}')
    if rel.startswith('/') or '\\' in rel or '..' in Path(rel).parts:
        fail(f'unsafe path reference: {rel}')
    target = ROOT / rel.rstrip('/')
    if rel.endswith('/'):
        if not target.is_dir():
            fail(f'missing directory: {rel}')
    elif not target.exists():
        fail(f'missing path: {rel}')


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = '/'.join(str(p) for p in err.path) or '<root>'
        fail(f'{label} schema violation at {where}: {err.message}')


def receipt_timestamp_local(receipt: dict) -> str:
    stamp = receipt.get('timestamp', '')
    parts = stamp.split('.')
    if len(parts) != 5 or not all(part.isdigit() for part in parts):
        fail('REVISION_RECEIPT.json timestamp must use YYYY.MM.DD.HH.MM format')
    year, month, day, hour, minute = parts
    return f'{year}-{month}-{day}T{hour}:{minute}:00-0400'


def parse_make_targets() -> set[str]:
    text = (ROOT / 'Makefile').read_text(encoding='utf-8')
    out: set[str] = set()
    for line in text.splitlines():
        if line.startswith('.') or line.startswith('\t') or not line.strip() or '=' in line:
            continue
        match = re.match(r'^([A-Za-z0-9_.-]+):', line)
        if match:
            out.add(match.group(1))
    return out


def format_items(items: list[str]) -> str:
    return ', '.join(f'`{item}`' for item in items)


def render_markdown(mapping: dict) -> str:
    lines = [
        '# Claim-obligation map',
        '',
        'This file is the exact human-facing companion to `CLAIM_OBLIGATION_MAP.json`.',
        'It maps selected EvidenceVault paper/release claims to the concrete local surfaces, validators, obligations, limits, and negative-regression expectations that support them.',
        '',
        f"- Revision: `{mapping['revision']}`",
        f"- Previous revision: `{mapping['previous_revision']}`",
        f"- Generated: `{mapping['generated_at_local']}`",
        f"- Scope: `{mapping['policy']['scope']}`",
        f"- Validator: `{mapping['validator']}`",
        f"- Claim count: `{len(mapping['claims'])}`",
        '',
        '## Boundary',
        '',
        mapping['policy']['truth_boundary'],
        '',
        '## Required canonical papers',
        '',
    ]
    for paper in mapping['policy']['required_canonical_papers']:
        lines.append(f'- `{paper}`')
    lines.extend(['', '## Claim obligations', ''])
    for claim in mapping['claims']:
        lines.extend([
            f"### {claim['id']} — {claim['title']}",
            f"- Class: `{claim['claim_class']}`",
            f"- Status: `{claim['status']}`",
            f"- Summary: {claim['claim_summary']}",
            f"- Archive surfaces: {format_items(claim['archive_surfaces'])}",
            f"- Validators: {format_items(claim['validators'])}",
            f"- Make targets: {format_items(['make ' + item for item in claim['make_targets']])}",
            '- Paper references:',
        ])
        for ref in claim['paper_refs']:
            lines.append(f"  - `{ref['path']}` — {ref['section_hint']}")
        lines.append('- Obligations:')
        for obligation in claim['obligations']:
            lines.append(f'  - {obligation}')
        lines.append('- Known limits:')
        for limit in claim['known_limits']:
            lines.append(f'  - {limit}')
        lines.extend([
            f"- Negative regression: {claim['negative_regression']}",
            '',
        ])
    return '\n'.join(lines).rstrip() + '\n'


def validate_claims(mapping: dict) -> None:
    claims = mapping['claims']
    ids = [claim['id'] for claim in claims]
    if ids != sorted(ids):
        fail('claim ids must be sorted ascending')
    if len(ids) != len(set(ids)):
        fail('claim ids must be unique')
    if len(claims) < mapping['policy']['minimum_claim_count']:
        fail('claim count is below policy.minimum_claim_count')

    validation = load_json('VALIDATION_INDEX.json')
    anchors = load_json('REVISION_ANCHORS.json')
    make_targets = parse_make_targets()
    indexed_targets = {check['make_target'] for check in validation.get('checks', [])} | {comp['make_target'] for comp in validation.get('composite_targets', [])}
    indexed_scripts = {script for check in validation.get('checks', []) for script in check.get('scripts', [])}
    anchored_validators = set(anchors.get('validators', []))

    required_papers = set(mapping['policy']['required_canonical_papers'])
    referenced_papers: set[str] = set()
    claim_classes: set[str] = set()
    for claim in claims:
        claim_classes.add(claim['claim_class'])
        for ref in claim['paper_refs']:
            require(ref['path'])
            if ref['path'] in required_papers:
                referenced_papers.add(ref['path'])
        for rel in claim['archive_surfaces']:
            require(rel)
        for rel in claim['validators']:
            require(rel)
            if rel not in anchored_validators:
                fail(f"{claim['id']} validator is not anchored in REVISION_ANCHORS.json: {rel}")
            if rel not in indexed_scripts:
                fail(f"{claim['id']} validator is not listed as a primary script in VALIDATION_INDEX.json: {rel}")
        for target in claim['make_targets']:
            if target not in make_targets:
                fail(f"{claim['id']} make target missing from Makefile: {target}")
            if target not in indexed_targets:
                fail(f"{claim['id']} make target missing from VALIDATION_INDEX.json: {target}")

    missing_papers = sorted(required_papers - referenced_papers)
    if missing_papers:
        fail(f'required canonical papers not referenced by any claim: {missing_papers}')
    required_classes = {'release_identity', 'replay_validation', 'source_provenance', 'public_surface', 'paper_payload', 'historical_exception', 'crypto_truth', 'toolchain_replay', 'decision_memory', 'external_artifact_verification'}
    missing_classes = sorted(required_classes - claim_classes)
    if missing_classes:
        fail(f'missing required claim classes: {missing_classes}')


def validate_wiring(mapping: dict) -> None:
    receipt = load_json('REVISION_RECEIPT.json')
    policy = load_json('publishing/CANONICAL_POLICY.json')
    context = load_json('CONTEXT_PACK.json')
    validation = load_json('VALIDATION_INDEX.json')
    control = load_json('CONTROL_SURFACES.json')
    gates = load_json('LIFECYCLE_GATES.json')
    frontier = load_json('CURRENT_FRONTIER.json')
    anchors = load_json('REVISION_ANCHORS.json')
    manifest = load_json('RELEASE_MANIFEST.json')

    if mapping['revision'] != receipt['revision']:
        fail('CLAIM_OBLIGATION_MAP.json revision must match REVISION_RECEIPT.json')
    if mapping['previous_revision'] != receipt['previous_revision']:
        fail('CLAIM_OBLIGATION_MAP.json previous_revision must match REVISION_RECEIPT.json')
    if mapping['generated_at_local'] != receipt_timestamp_local(receipt):
        fail('CLAIM_OBLIGATION_MAP.json generated_at_local must match REVISION_RECEIPT.json timestamp')
    if mapping['validator'] != EXPECTED_VALIDATOR:
        fail('CLAIM_OBLIGATION_MAP.json validator mismatch')

    for key, expected in {
        'claim_obligation_map_json': 'CLAIM_OBLIGATION_MAP.json',
        'claim_obligation_map_markdown': 'CLAIM_OBLIGATION_MAP.md',
        'claim_obligation_map_schema': 'schemas/claim_obligation_map.schema.json',
        'claim_obligation_map_validator': EXPECTED_VALIDATOR,
    }.items():
        if policy.get(key) != expected:
            fail(f'publishing/CANONICAL_POLICY.json {key} mismatch')
    if 'explicit_claim_obligation_map_validation' not in policy.get('principles', []):
        fail('publishing/CANONICAL_POLICY.json principles missing explicit_claim_obligation_map_validation')

    kms = context.get('key_machine_surfaces', {})
    for key, expected in {
        'claim_obligation_map_json': 'CLAIM_OBLIGATION_MAP.json',
        'claim_obligation_map_markdown': 'CLAIM_OBLIGATION_MAP.md',
        'claim_obligation_map_validator': EXPECTED_VALIDATOR,
    }.items():
        if kms.get(key) != expected:
            fail(f'CONTEXT_PACK.json key_machine_surfaces.{key} mismatch')
    for command in ('make claim-obligation-check', f'python3 {EXPECTED_VALIDATOR}'):
        if command not in context.get('checks', []):
            fail(f'CONTEXT_PACK.json checks missing {command}')

    checks = {check['id']: check for check in validation.get('checks', [])}
    check = checks.get('claim-obligation-check')
    if check is None:
        fail('VALIDATION_INDEX.json missing claim-obligation-check')
    if check.get('scripts') != [EXPECTED_VALIDATOR]:
        fail('claim-obligation-check scripts mismatch')
    required_validates = {
        'CLAIM_OBLIGATION_MAP.json',
        'CLAIM_OBLIGATION_MAP.md',
        'schemas/claim_obligation_map.schema.json',
        EXPECTED_VALIDATOR,
        'REVISION_RECEIPT.json',
        'VALIDATION_INDEX.json',
        'REVISION_ANCHORS.json',
        'CONTROL_SURFACES.json',
        'LIFECYCLE_GATES.json',
        'CONTEXT_PACK.json',
        'publishing/CANONICAL_POLICY.json',
        'RELEASE_MANIFEST.json',
        'CURRENT_FRONTIER.json',
    }
    if not required_validates.issubset(set(check.get('validates', []))):
        fail(f'claim-obligation-check validates missing surfaces: {sorted(required_validates - set(check.get("validates", [])))}')

    validation_paths = {item['path'] for item in control.get('surfaces', {}).get('validation_and_packaging', [])}
    opening_paths = {item['path'] for item in control.get('surfaces', {}).get('opening_and_resumption', [])}
    for rel in ('CLAIM_OBLIGATION_MAP.json', 'CLAIM_OBLIGATION_MAP.md', 'schemas/claim_obligation_map.schema.json', EXPECTED_VALIDATOR):
        if rel not in validation_paths:
            fail(f'CONTROL_SURFACES.json validation_and_packaging missing {rel}')
    for rel in ('ro-crate-metadata.json', 'RO_CRATE_PROFILE.md', 'scripts/validate_ro_crate_metadata.py'):
        if rel not in validation_paths:
            fail(f'CONTROL_SURFACES.json validation_and_packaging missing RO-Crate bridge {rel}')
    for rel in ('CLAIM_OBLIGATION_MAP.json', 'CLAIM_OBLIGATION_MAP.md'):
        if rel not in opening_paths:
            fail(f'CONTROL_SURFACES.json opening_and_resumption missing {rel}')

    for gate_id in ('careful_revision_pass', 'publish_audit', 'named_bundle_packaging'):
        refs = set(gates['gates'][gate_id].get('authoritative_sequence', []) + gates['gates'][gate_id].get('required_surfaces', []) + gates['gates'][gate_id].get('checks', []))
        if EXPECTED_VALIDATOR not in refs:
            fail(f'LIFECYCLE_GATES.json {gate_id} missing claim-obligation validator')
        if gate_id == 'named_bundle_packaging':
            for rel in ('CLAIM_OBLIGATION_MAP.json', 'CLAIM_OBLIGATION_MAP.md'):
                if rel not in refs:
                    fail(f'LIFECYCLE_GATES.json {gate_id} missing {rel}')

    linked = set()
    for lane in frontier.get('lanes', []):
        linked.update(lane.get('linked_surfaces', []))
    if 'CLAIM_OBLIGATION_MAP.json' not in linked or EXPECTED_VALIDATOR not in linked:
        fail('CURRENT_FRONTIER.json missing claim-obligation linkage')

    anchored = {item['path'] for item in anchors.get('anchored_surfaces', [])}
    if 'CLAIM_OBLIGATION_MAP.json' not in anchored:
        fail('REVISION_ANCHORS.json missing CLAIM_OBLIGATION_MAP.json anchor')
    if EXPECTED_VALIDATOR not in set(anchors.get('validators', [])):
        fail('REVISION_ANCHORS.json validators missing claim-obligation validator')

    for key, expected in {
        'claim_obligation_map_markdown': 'CLAIM_OBLIGATION_MAP.md',
        'claim_obligation_map_json': 'CLAIM_OBLIGATION_MAP.json',
    }.items():
        if manifest.get(key) != expected:
            fail(f'RELEASE_MANIFEST.json {key} mismatch')

    for rel in ('scripts/gate.py', 'scripts/publish_audit.py', 'scripts/package_release.py', 'Makefile'):
        if 'validate_claim_obligation_map.py' not in (ROOT / rel).read_text(encoding='utf-8') and rel != 'Makefile':
            fail(f'{rel} missing claim-obligation validator')
        if rel == 'Makefile' and 'claim-obligation-check:' not in (ROOT / rel).read_text(encoding='utf-8'):
            fail('Makefile missing claim-obligation-check target')


def main() -> None:
    for rel in ('CLAIM_OBLIGATION_MAP.json', 'CLAIM_OBLIGATION_MAP.md', 'schemas/claim_obligation_map.schema.json'):
        require(rel)
    mapping = load_json(MAP_JSON)
    schema = load_json(SCHEMA)
    validate_against_schema(mapping, schema, 'CLAIM_OBLIGATION_MAP.json')
    if MAP_MD.read_text(encoding='utf-8') != render_markdown(mapping):
        fail('CLAIM_OBLIGATION_MAP.md must exactly mirror CLAIM_OBLIGATION_MAP.json')
    validate_claims(mapping)
    validate_wiring(mapping)
    print(f'claim-obligation-validate: OK ({len(mapping["claims"])} claims mapped)')


if __name__ == '__main__':
    main()
