#!/usr/bin/env python3
"""Validate non-JSON text payload hygiene across the shipped archive.

The JSON inventory validator owns .json and JSON Schema semantics.  This
validator covers the other text-like payload formats that are easy to corrupt
without tripping a JSON parser: YAML, JSONL, CSV, Python source, TeX/Markdown,
manifest files, shell scripts, and extensionless command surfaces.
"""
from __future__ import annotations

import ast
import csv
import json
import sys
import warnings
from pathlib import Path

try:
    import yaml  # type: ignore
except Exception as exc:  # pragma: no cover - environment failure is explicit.
    yaml = None
    YAML_IMPORT_ERROR = exc
else:
    YAML_IMPORT_ERROR = None

ROOT = Path(__file__).resolve().parents[1]
warnings.simplefilter("ignore", SyntaxWarning)

TEXT_EXTENSIONS = {
    '.bib', '.cfg', '.conf', '.css', '.csv', '.gitignore', '.html', '.ini',
    '.jsonl', '.latexmkrc', '.license', '.log', '.md', '.out', '.patch',
    '.pem', '.profile', '.properties', '.py', '.rst', '.sha256', '.sh',
    '.sql', '.sty', '.tex', '.toml', '.tsv', '.txt', '.xml', '.yaml', '.yml',
}
TEXT_FILENAMES = {
    'AGENTS.md', 'CHANGELOG.md', 'LICENSE', 'Makefile', 'PUBLISHING.md',
    'README', 'README.md', 'SERIES.md', 'START_HERE.md', 'CATALOG.md',
}
SKIP_DIR_PARTS = {'.git'}


def fail(msg: str) -> None:
    print(f'text-payload-validate: FAIL: {msg}', file=sys.stderr)
    sys.exit(1)


def rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def is_text_like(path: Path) -> bool:
    name = path.name
    suffixes = [s.lower() for s in path.suffixes]
    suffix = path.suffix.lower()
    if name in TEXT_FILENAMES:
        return True
    if suffix in TEXT_EXTENSIONS:
        return True
    if suffixes[-2:] == ['.tar', '.gz']:
        return False
    # Treat known manifest/checksum-ish extensionless files as text surfaces.
    if not suffix and any(part in {'scripts', 'rfcs', 'adrs'} for part in path.parts):
        return True
    return False


def read_utf8(path: Path) -> str:
    try:
        data = path.read_text(encoding='utf-8')
    except UnicodeDecodeError as exc:
        fail(f'{rel(path)} is not valid UTF-8: {exc}')
    except Exception as exc:
        fail(f'could not read {rel(path)}: {exc}')
    if '\x00' in data:
        fail(f'{rel(path)} contains NUL bytes')
    return data


def validate_yaml(path: Path) -> None:
    if yaml is None:
        fail(f'PyYAML is unavailable: {YAML_IMPORT_ERROR}')
    text = read_utf8(path)
    try:
        list(yaml.safe_load_all(text))
    except Exception as exc:
        fail(f'invalid YAML in {rel(path)}: {exc}')


def validate_jsonl(path: Path) -> int:
    text = read_utf8(path)
    records = 0
    for n, line in enumerate(text.splitlines(), start=1):
        if not line.strip():
            continue
        try:
            json.loads(line)
        except Exception as exc:
            fail(f'invalid JSONL in {rel(path)} line {n}: {exc}')
        records += 1
    return records


def validate_csv(path: Path) -> None:
    text = read_utf8(path)
    try:
        rows = list(csv.reader(text.splitlines()))
    except Exception as exc:
        fail(f'invalid CSV in {rel(path)}: {exc}')
    # Empty CSV files are refused by the archive-wide zero-byte check below; a
    # file containing only blank lines is also unhelpful as a governed CSV.
    if not rows and path.stat().st_size > 0:
        fail(f'CSV file has no parseable rows: {rel(path)}')




def iter_files_sorted(root: Path):
    """Yield files deterministically without materializing the whole tree."""
    import os

    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIR_PARTS)
        for filename in sorted(filenames):
            yield Path(dirpath) / filename

def validate_python(path: Path) -> None:
    text = read_utf8(path)
    try:
        ast.parse(text, filename=rel(path))
    except SyntaxError as exc:
        fail(f'invalid Python syntax in {rel(path)}: {exc}')


def main() -> None:
    text_count = 0
    yaml_count = 0
    jsonl_count = 0
    jsonl_records = 0
    csv_count = 0
    python_count = 0
    zero_byte = []

    for path in iter_files_sorted(ROOT):
        r = rel(path)
        if path.stat().st_size == 0:
            zero_byte.append(r)
        suffix = path.suffix.lower()
        if is_text_like(path) and suffix != '.json':
            read_utf8(path)
            text_count += 1
        if suffix in {'.yaml', '.yml'}:
            validate_yaml(path)
            yaml_count += 1
        elif suffix == '.jsonl':
            jsonl_records += validate_jsonl(path)
            jsonl_count += 1
        elif suffix == '.csv':
            validate_csv(path)
            csv_count += 1
        elif suffix == '.py':
            validate_python(path)
            python_count += 1

    if zero_byte:
        fail('zero-byte governed files present: ' + ', '.join(zero_byte[:20]))

    print(
        'text-payload-validate: OK '
        f'({text_count} UTF-8 non-JSON text-like files, '
        f'{yaml_count} YAML files, '
        f'{jsonl_count} JSONL files/{jsonl_records} records, '
        f'{csv_count} CSV files, '
        f'{python_count} Python files parsed, '
        f'{len(zero_byte)} governed zero-byte files)'
    )


if __name__ == '__main__':
    main()
