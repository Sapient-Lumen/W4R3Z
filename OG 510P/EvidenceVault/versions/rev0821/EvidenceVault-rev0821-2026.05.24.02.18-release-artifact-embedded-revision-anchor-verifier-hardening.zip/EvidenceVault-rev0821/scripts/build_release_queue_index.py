#!/usr/bin/env python3
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
QUEUE_DIR = ROOT / 'release_queue'
DIR_MAP = {'candidate': 'candidates', 'hold': 'hold', 'published_ready': 'published_ready', 'published': 'published'}
STATES = ['candidate', 'hold', 'published_ready', 'published']


def fail(msg: str) -> None:
    print(f"queue-index: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def load_json(path: Path):
    try:
        return json.loads(path.read_text())
    except Exception as exc:
        fail(f"invalid JSON in {path}: {exc}")


def main() -> None:
    states = {}
    seen = set()
    for state in STATES:
        state_dir = QUEUE_DIR / DIR_MAP[state]
        if not state_dir.exists():
            fail(f"missing state directory: {state_dir}")
        items = []
        for path in sorted(state_dir.glob('*.json')):
            data = load_json(path)
            item_id = data.get('item_id')
            if not item_id:
                fail(f"queue item missing item_id: {path}")
            if item_id in seen:
                fail(f"duplicate queue item id: {item_id}")
            seen.add(item_id)
            item = {
                'item_id': item_id,
                'state': data.get('state', state),
                'path': path.relative_to(ROOT).as_posix(),
                'date': data.get('date', ''),
            }
            if data.get('decision_id'):
                item['decision_id'] = data['decision_id']
            if data.get('public_release_id'):
                item['public_release_id'] = data['public_release_id']
            items.append(item)
        states[state] = items

    out = {'owner': 'release_queue/', 'states': states}
    (QUEUE_DIR / 'QUEUE_INDEX.json').write_text(json.dumps(out, indent=2) + '\n')
    counts = ', '.join(f"{state}={len(states[state])}" for state in STATES)
    print(f"queue-index: OK ({counts})")


if __name__ == '__main__':
    main()
