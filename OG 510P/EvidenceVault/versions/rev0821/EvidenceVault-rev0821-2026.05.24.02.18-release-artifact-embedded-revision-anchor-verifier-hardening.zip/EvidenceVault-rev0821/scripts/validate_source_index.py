#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True

from jsonschema import Draft202012Validator

from build_source_index import build_source_index, render_markdown

ROOT = Path(__file__).resolve().parents[1]


def fail(msg: str) -> None:
    print(f"source-index-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def load_json(rel: str):
    path = ROOT / rel
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"invalid JSON in {rel}: {exc}")


def require(rel: str) -> None:
    path = ROOT / rel.rstrip('/')
    if rel.endswith('/'):
        if not path.is_dir():
            fail(f"missing directory: {rel}")
    elif not path.exists():
        fail(f"missing path: {rel}")


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = "/".join(str(p) for p in err.path) or "<root>"
        fail(f"{label} schema violation at {where}: {err.message}")


def file_count(path: Path) -> int:
    return sum(1 for p in path.rglob('*') if p.is_file())


def extraction_consumers() -> dict[str, list[str]]:
    data = load_json('papers/EXTRACTION_MAP.json')
    out: dict[str, list[str]] = {}
    for paper_name, meta in data.items():
        paper_path = f'papers/{paper_name}'
        for src in meta.get('from', []):
            if isinstance(src, str) and src.startswith('sources/'):
                parts = src.split('/')
                if len(parts) >= 2:
                    out.setdefault(parts[1], []).append(paper_path)
    return {k: sorted(set(v)) for k, v in out.items()}



def validate_generated_companions(idx: dict) -> None:
    expected = build_source_index()
    if idx != expected:
        fail('SOURCE_INDEX.json does not exactly match scripts/build_source_index.py output')
    expected_md = render_markdown(idx).rstrip() + "\n"
    actual_md = (ROOT / 'SOURCE_INDEX.md').read_text(encoding='utf-8')
    if actual_md != expected_md:
        fail('SOURCE_INDEX.md does not exactly mirror SOURCE_INDEX.json via scripts/build_source_index.py render_markdown()')


def main() -> None:
    idx = load_json('SOURCE_INDEX.json')
    schema = load_json('schemas/source_index.schema.json')
    opening = load_json('OPENING_CONTRACT.json')
    conformance = load_json('OPENING_SURFACE_CONFORMANCE.json')
    control = load_json('CONTROL_SURFACES.json')
    gates = load_json('LIFECYCLE_GATES.json')
    policy = load_json('publishing/CANONICAL_POLICY.json')
    validation_index = load_json('VALIDATION_INDEX.json')
    receipt = load_json('REVISION_RECEIPT.json')
    manifest = load_json('RELEASE_MANIFEST.json')
    anchors = load_json('REVISION_ANCHORS.json')

    validate_against_schema(idx, schema, 'SOURCE_INDEX.json')
    validate_generated_companions(idx)

    if idx['revision'] != receipt['revision']:
        fail('SOURCE_INDEX revision must match current revision receipt')

    consumers = extraction_consumers()
    root_ids = set()
    for entry in idx['source_roots']:
        root_ids.add(entry['id'])
        require(entry['retained_root'] + '/')
        if file_count(ROOT / entry['retained_root']) != entry['file_count']:
            fail(f"file_count mismatch for {entry['retained_root']}")
        if entry['consumed_by_papers'] != consumers.get(entry['id'], []):
            fail(f"consumed_by_papers mismatch for {entry['retained_root']}")
        for subtree in entry['key_subtrees']:
            require(subtree['path'] + '/')
            if file_count(ROOT / subtree['path']) != subtree['file_count']:
                fail(f"file_count mismatch for {subtree['path']}")
        for rel in entry['companion_paths']:
            require(rel)

    for entry in idx['represented_without_retained_source_root']:
        require(entry['canonical_paper'])
        for rel in entry['representation_paths']:
            require(rel)
        if (ROOT / 'sources' / entry['family']).exists():
            fail(f"family {entry['family']} unexpectedly has a retained sources/ root")

    opening_paths = {item['path'] for item in opening['entrypoints']}
    needed_opening = {'SOURCE_INDEX.md', 'SOURCE_INDEX.json'}
    if not needed_opening.issubset(opening_paths):
        fail('opening contract entrypoints missing SOURCE_INDEX surfaces')
    if not needed_opening.issubset(set(conformance['required_root_entrypoints'])):
        fail('opening conformance required_root_entrypoints missing SOURCE_INDEX surfaces')

    opening_control = {item['path'] for item in control['surfaces']['opening_and_resumption']}
    audit_control = {item['path'] for item in control['surfaces']['audit_and_retention']}
    packaging_control = {item['path'] for item in control['surfaces']['validation_and_packaging']}
    for rel in ('SOURCE_INDEX.md', 'SOURCE_INDEX.json'):
        if rel not in opening_control:
            fail(f'opening_and_resumption missing {rel}')
        if rel not in audit_control:
            fail(f'audit_and_retention missing {rel}')
    for rel in ('scripts/build_source_index.py', 'scripts/validate_source_index.py'):
        if rel not in packaging_control:
            fail(f'validation_and_packaging missing {rel}')

    careful = gates['gates']['careful_revision_pass']
    named = gates['gates']['named_bundle_packaging']
    if 'SOURCE_INDEX.md' not in careful['authoritative_sequence']:
        fail('careful_revision_pass sequence missing SOURCE_INDEX.md')
    if 'scripts/validate_source_index.py' not in careful['checks']:
        fail('careful_revision_pass checks missing scripts/validate_source_index.py')
    if 'SOURCE_INDEX.json' not in named['required_surfaces']:
        fail('named_bundle_packaging required_surfaces missing SOURCE_INDEX.json')
    if 'scripts/validate_source_index.py' not in named['checks']:
        fail('named_bundle_packaging checks missing scripts/validate_source_index.py')

    checks = {c['id']: c for c in validation_index['checks']}
    if 'source-check' not in checks:
        fail('VALIDATION_INDEX.json missing source-check')
    source_check = checks['source-check']
    if source_check['make_target'] != 'source-check':
        fail('source-check make_target mismatch')
    if source_check['scripts'] != ['scripts/validate_source_index.py']:
        fail('source-check scripts mismatch')
    if 'SOURCE_INDEX.md' not in source_check['validates'] or 'SOURCE_INDEX.json' not in source_check['validates']:
        fail('source-check validates missing SOURCE_INDEX surfaces')
    rebuild = checks['rebuild-indexes']
    if 'SOURCE_INDEX.md' not in rebuild['outputs'] or 'SOURCE_INDEX.json' not in rebuild['outputs']:
        fail('rebuild-indexes outputs missing SOURCE_INDEX surfaces')

    if policy.get('source_index_markdown') != 'SOURCE_INDEX.md':
        fail('publishing/CANONICAL_POLICY.json source_index_markdown mismatch')
    if policy.get('source_index_json') != 'SOURCE_INDEX.json':
        fail('publishing/CANONICAL_POLICY.json source_index_json mismatch')
    if policy.get('source_index_builder') != 'scripts/build_source_index.py':
        fail('publishing/CANONICAL_POLICY.json source_index_builder mismatch')
    if policy.get('source_index_validator') != 'scripts/validate_source_index.py':
        fail('publishing/CANONICAL_POLICY.json source_index_validator mismatch')
    if policy.get('source_index_schema') != 'schemas/source_index.schema.json':
        fail('publishing/CANONICAL_POLICY.json source_index_schema mismatch')

    if manifest.get('source_index_markdown') != 'SOURCE_INDEX.md':
        fail('release manifest source_index_markdown mismatch')
    if manifest.get('source_index_json') != 'SOURCE_INDEX.json':
        fail('release manifest source_index_json mismatch')
    if 'source_index_json_sha256' not in manifest.get('identity_digests', {}):
        fail('release manifest missing source_index_json_sha256 digest')

    anchored = {item['path'] for item in anchors.get('anchored_surfaces', [])}
    if 'SOURCE_INDEX.json' not in anchored:
        fail('revision anchors missing SOURCE_INDEX.json')

    print(f"source-index-validate: OK ({len(idx['source_roots'])} retained source roots, {len(idx['represented_without_retained_source_root'])} non-root represented families, exact Markdown/JSON companion)")


if __name__ == '__main__':
    main()
