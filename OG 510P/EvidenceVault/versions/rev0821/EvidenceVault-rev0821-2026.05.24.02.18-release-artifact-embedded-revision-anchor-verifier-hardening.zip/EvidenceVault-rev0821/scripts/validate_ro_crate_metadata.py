#!/usr/bin/env python3
"""Validate the RO-Crate-style research-object metadata bridge.

This bridge is deliberately compact: it exposes selected core EvidenceVault
archive surfaces to external research-object metadata consumers without replacing
RELEASE_MANIFEST.json, MANIFEST.sha256, INDEX/files.*, or the internal validation
ledgers as the archive's governing truth sources.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
CRATE_JSON = ROOT / 'ro-crate-metadata.json'
PROFILE_MD = ROOT / 'RO_CRATE_PROFILE.md'
SCHEMA = ROOT / 'schemas' / 'ro_crate_metadata.schema.json'
EXPECTED_VALIDATOR = 'scripts/validate_ro_crate_metadata.py'
CONTEXT = 'https://w3id.org/ro/crate/1.2/context'
CONFORMS_TO = 'https://w3id.org/ro/crate/1.2'

REQUIRED_HAS_PARTS = [
    'RELEASE_MANIFEST.json',
    'REVISION_RECEIPT.json',
    'REVISION_ANCHORS.json',
    'VALIDATION_INDEX.json',
    'CLAIM_OBLIGATION_MAP.json',
    'PUBLIC_STATUS.json',
    'TOOLCHAIN_LOCK.json',
    'COMMAND_RUNNER_SEQUENCE.json',
    'SOURCE_INDEX.json',
    'ARCHIVE_INDEX.json',
    'CONTROL_SURFACES.json',
    'LIFECYCLE_GATES.json',
    'papers/EXTRACTION_MAP.json',
    'published/PUBLIC_SURFACE.json',
    'MANIFEST.sha256',
    'INDEX/files.json',
    'ev_acceptability_kernel.pdf',
    'ev_interpretation_profiles.pdf',
    'ev_streamfold.pdf',
    'ev_zkrtp.pdf',
    'ev_pact_ocf.pdf',
    'sources/',
    'artifacts/',
    'certs/',
    'published/',
]
DIGESTED_FILE_ENTITIES = [
    'RELEASE_MANIFEST.json',
    'REVISION_RECEIPT.json',
    'REVISION_ANCHORS.json',
    'VALIDATION_INDEX.json',
    'CLAIM_OBLIGATION_MAP.json',
    'PUBLIC_STATUS.json',
    'TOOLCHAIN_LOCK.json',
    'COMMAND_RUNNER_SEQUENCE.json',
    'SOURCE_INDEX.json',
    'ARCHIVE_INDEX.json',
    'CONTROL_SURFACES.json',
    'LIFECYCLE_GATES.json',
    'papers/EXTRACTION_MAP.json',
    'published/PUBLIC_SURFACE.json',
    'ev_acceptability_kernel.pdf',
    'ev_interpretation_profiles.pdf',
    'ev_streamfold.pdf',
    'ev_zkrtp.pdf',
    'ev_pact_ocf.pdf',
]
SELF_REFERENTIAL_FILE_ENTITIES = {'MANIFEST.sha256', 'INDEX/files.json'}
DIRECTORY_ENTITIES = {'sources/', 'artifacts/', 'certs/', 'published/'}


def fail(msg: str) -> None:
    print(f'ro-crate-validate: FAIL: {msg}', file=sys.stderr)
    sys.exit(1)


def load_json(rel: str | Path):
    path = ROOT / rel if isinstance(rel, str) else rel
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:
        label = path.relative_to(ROOT).as_posix() if path.is_relative_to(ROOT) else str(path)
        fail(f'invalid JSON in {label}: {exc}')


def require(rel: str) -> None:
    if not isinstance(rel, str) or not rel:
        fail(f'empty/non-string path reference: {rel!r}')
    if rel.startswith('/') or '\\' in rel or '..' in Path(rel).parts:
        fail(f'unsafe path reference: {rel}')
    target = ROOT / rel.rstrip('/')
    if rel.endswith('/'):
        if not target.is_dir():
            fail(f'missing directory: {rel}')
    elif not target.exists():
        fail(f'missing path: {rel}')


def sha256_file(rel: str) -> str:
    return hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = '/'.join(str(p) for p in err.path) or '<root>'
        fail(f'{label} schema violation at {where}: {err.message}')


def as_type_set(value) -> set[str]:
    if isinstance(value, str):
        return {value}
    if isinstance(value, list) and all(isinstance(item, str) for item in value):
        return set(value)
    fail(f'invalid @type value: {value!r}')


def entity_map(crate: dict) -> dict[str, dict]:
    graph = crate.get('@graph')
    if not isinstance(graph, list):
        fail('ro-crate-metadata.json @graph must be a list')
    out: dict[str, dict] = {}
    for entity in graph:
        if not isinstance(entity, dict):
            fail('every @graph entity must be an object')
        eid = entity.get('@id')
        if not isinstance(eid, str) or not eid:
            fail('every @graph entity must have non-empty @id')
        if eid in out:
            fail(f'duplicate @graph entity id: {eid}')
        out[eid] = entity
    return out


def receipt_timestamp_local(receipt: dict) -> str:
    stamp = receipt.get('timestamp', '')
    parts = stamp.split('.')
    if len(parts) != 5 or not all(part.isdigit() for part in parts):
        fail('REVISION_RECEIPT.json timestamp must use YYYY.MM.DD.HH.MM format')
    year, month, day, hour, minute = parts
    return f'{year}-{month}-{day}T{hour}:{minute}:00-0400'


def render_markdown(crate: dict) -> str:
    entities = entity_map(crate)
    root = entities['./']
    descriptor = entities['ro-crate-metadata.json']
    has_part = [item['@id'] for item in root['hasPart']]
    digest_rows = []
    for rel in DIGESTED_FILE_ENTITIES:
        ent = entities[rel]
        digest_rows.append((rel, ent['contentSize'], ent['sha256']))
    lines = [
        '# RO-Crate metadata bridge',
        '',
        'This file is the exact human-facing companion to `ro-crate-metadata.json`.',
        'The bridge exposes selected EvidenceVault core archive surfaces as compact JSON-LD research-object metadata without replacing `RELEASE_MANIFEST.json`, `MANIFEST.sha256`, or `INDEX/files.*` as governing inventory surfaces.',
        '',
        f"- Context: `{crate['@context']}`",
        f"- Descriptor: `{descriptor['@id']}`",
        f"- Conforms to: `{descriptor['conformsTo']['@id']}`",
        f"- Root entity: `{root['@id']}`",
        f"- Root version: `{root['version']}`",
        f"- Date published: `{root['datePublished']}`",
        f"- Identifier: `{root['identifier']}`",
        f"- Required hasPart entries: `{len(has_part)}`",
        f"- Digest-checked file entities: `{len(digest_rows)}`",
        '',
        '## Required root hasPart entries',
        '',
    ]
    lines.extend(f'- `{rel}`' for rel in has_part)
    lines.extend(['', '## Digest-checked file entities', ''])
    for rel, size, digest in digest_rows:
        lines.append(f'- `{rel}` — size `{size}` — sha256 `{digest}`')
    lines.extend([
        '',
        '## Self-referential inventory entries',
        '',
        '`MANIFEST.sha256` and `INDEX/files.json` are listed as core inventory surfaces but their own size/hash are omitted from this bridge to avoid a metadata/manifest digest cycle. Their governing verification remains `make manifest-check`.',
        '',
        '## Directory entities',
        '',
    ])
    for rel in sorted(DIRECTORY_ENTITIES):
        lines.append(f'- `{rel}`')
    return '\n'.join(lines).rstrip() + '\n'


def validate_crate(crate: dict) -> None:
    receipt = load_json('REVISION_RECEIPT.json')
    manifest = load_json('RELEASE_MANIFEST.json')
    validation = load_json('VALIDATION_INDEX.json')
    control = load_json('CONTROL_SURFACES.json')
    gates = load_json('LIFECYCLE_GATES.json')
    context = load_json('CONTEXT_PACK.json')
    frontier = load_json('CURRENT_FRONTIER.json')
    anchors = load_json('REVISION_ANCHORS.json')
    policy = load_json('publishing/CANONICAL_POLICY.json')
    registry = load_json('schemas/registry.json')

    if crate.get('@context') != CONTEXT:
        fail('ro-crate-metadata.json @context must be RO-Crate 1.2 context')
    entities = entity_map(crate)
    for required_id in ['ro-crate-metadata.json', './', *REQUIRED_HAS_PARTS]:
        if required_id not in entities:
            fail(f'ro-crate-metadata.json missing entity: {required_id}')

    descriptor = entities['ro-crate-metadata.json']
    if 'CreativeWork' not in as_type_set(descriptor.get('@type')):
        fail('metadata descriptor must have @type CreativeWork')
    if descriptor.get('about') != {'@id': './'}:
        fail('metadata descriptor about must reference ./')
    if descriptor.get('conformsTo') != {'@id': CONFORMS_TO}:
        fail('metadata descriptor conformsTo must reference RO-Crate 1.2')

    root = entities['./']
    if 'Dataset' not in as_type_set(root.get('@type')):
        fail('root entity must have @type Dataset')
    expected_date = receipt['date']
    if root.get('datePublished') != expected_date:
        fail('root datePublished must match REVISION_RECEIPT.json date')
    if root.get('version') != receipt['revision']:
        fail('root version must match REVISION_RECEIPT.json revision')
    if root.get('identifier') != manifest['archive_name']:
        fail('root identifier must match RELEASE_MANIFEST.json archive_name')
    expected_release_manifest_paths = {'release_manifest_schema': 'schemas/release_manifest.schema.json', 'archive_identity_validator': 'scripts/validate_archive_identity.py', 'release_artifact_verifier': 'scripts/verify_release_artifact.py', 'release_artifact_verifier_validator': 'scripts/validate_command_runners.py', 'ro_crate_metadata_json': 'ro-crate-metadata.json', 'ro_crate_profile_markdown': 'RO_CRATE_PROFILE.md', 'ro_crate_metadata_schema': 'schemas/ro_crate_metadata.schema.json', 'ro_crate_metadata_validator': 'scripts/validate_ro_crate_metadata.py'}
    for key, expected in expected_release_manifest_paths.items():
        if manifest.get(key) != expected:
            fail(f'RELEASE_MANIFEST.json {key} must be {expected}')
    expected_exclusions = [{'path': 'ro-crate-metadata.json', 'reason': 'acyclic_release_identity_boundary: ro-crate-metadata.json digest-checks RELEASE_MANIFEST.json, so RELEASE_MANIFEST.json path-pins but does not digest it'}, {'path': 'RO_CRATE_PROFILE.md', 'reason': 'acyclic_release_identity_boundary: RO_CRATE_PROFILE.md exactly renders ro-crate-metadata.json and would carry the RELEASE_MANIFEST.json digest row'}]
    if manifest.get('identity_digest_exclusions') != expected_exclusions:
        fail('RELEASE_MANIFEST.json must document the acyclic RO-Crate metadata/profile digest boundary')
    for forbidden_key in ['ro_crate_metadata_json_sha256', 'ro_crate_profile_markdown_sha256']:
        if forbidden_key in manifest.get('identity_digests', {}):
            fail(f'RELEASE_MANIFEST.json must not contain cyclic digest key {forbidden_key}')
    for required_key in ('ro_crate_metadata_schema_sha256', 'ro_crate_metadata_validator_sha256', 'release_artifact_verifier_sha256', 'release_artifact_verifier_validator_sha256'):
        if required_key not in manifest.get('identity_digests', {}):
            fail(f'RELEASE_MANIFEST.json missing {required_key} identity digest')
    if root.get('conformsTo') != {'@id': CONFORMS_TO}:
        fail('root conformsTo must reference RO-Crate 1.2')
    has_part = root.get('hasPart')
    if not isinstance(has_part, list) or not all(isinstance(x, dict) and set(x) == {'@id'} for x in has_part):
        fail('root hasPart must be a list of {@id} references')
    has_part_ids = [item['@id'] for item in has_part]
    if has_part_ids != REQUIRED_HAS_PARTS:
        fail(f'root hasPart drift; expected {REQUIRED_HAS_PARTS!r}, got {has_part_ids!r}')
    for rel in has_part_ids:
        require(rel)

    for rel in DIGESTED_FILE_ENTITIES:
        entity = entities[rel]
        if 'File' not in as_type_set(entity.get('@type')):
            fail(f'{rel} entity must have @type File')
        if entity.get('contentSize') != str((ROOT / rel).stat().st_size):
            fail(f'{rel} contentSize mismatch')
        if entity.get('sha256') != sha256_file(rel):
            fail(f'{rel} sha256 mismatch')
        if 'encodingFormat' not in entity:
            fail(f'{rel} missing encodingFormat')
    for rel in SELF_REFERENTIAL_FILE_ENTITIES:
        entity = entities[rel]
        if 'File' not in as_type_set(entity.get('@type')):
            fail(f'{rel} entity must have @type File')
        if 'sha256' in entity or 'contentSize' in entity:
            fail(f'{rel} must omit sha256/contentSize to avoid self-reference cycle')
    for rel in DIRECTORY_ENTITIES:
        if 'Dataset' not in as_type_set(entities[rel].get('@type')):
            fail(f'{rel} directory entity must have @type Dataset')

    for key, expected in {
        'ro_crate_metadata_json': 'ro-crate-metadata.json',
        'ro_crate_profile_markdown': 'RO_CRATE_PROFILE.md',
        'ro_crate_metadata_schema': 'schemas/ro_crate_metadata.schema.json',
        'ro_crate_metadata_validator': EXPECTED_VALIDATOR,
        'release_artifact_verifier': 'scripts/verify_release_artifact.py',
        'release_artifact_verifier_validator': 'scripts/validate_command_runners.py',
    }.items():
        if policy.get(key) != expected:
            fail(f'publishing/CANONICAL_POLICY.json {key} mismatch')
    if 'explicit_ro_crate_metadata_bridge_validation' not in policy.get('principles', []):
        fail('publishing/CANONICAL_POLICY.json principles missing explicit_ro_crate_metadata_bridge_validation')
    if registry.get('ro-crate-metadata.json') != 'ro_crate_metadata.schema.json':
        fail('schemas/registry.json missing ro-crate-metadata.json schema entry')

    checks = {check['id']: check for check in validation.get('checks', [])}
    check = checks.get('ro-crate-check')
    if check is None:
        fail('VALIDATION_INDEX.json missing ro-crate-check')
    if check.get('scripts') != [EXPECTED_VALIDATOR]:
        fail('ro-crate-check scripts mismatch')
    required_validates = {
        'ro-crate-metadata.json',
        'RO_CRATE_PROFILE.md',
        'schemas/ro_crate_metadata.schema.json',
        EXPECTED_VALIDATOR,
        'REVISION_RECEIPT.json',
        'RELEASE_MANIFEST.json',
        'REVISION_ANCHORS.json',
        'VALIDATION_INDEX.json',
        'CONTROL_SURFACES.json',
        'LIFECYCLE_GATES.json',
        'CONTEXT_PACK.json',
        'CURRENT_FRONTIER.json',
        'CLAIM_OBLIGATION_MAP.json',
        'PUBLIC_STATUS.json',
        'publishing/CANONICAL_POLICY.json',
        'schemas/registry.json',
        'COMMAND_RUNNER_SEQUENCE.json',
        'scripts/verify_release_artifact.py',
    }
    if not required_validates.issubset(set(check.get('validates', []))):
        missing = sorted(required_validates - set(check.get('validates', [])))
        fail(f'ro-crate-check validates missing surfaces: {missing}')

    for command in ('make ro-crate-check', f'python3 {EXPECTED_VALIDATOR}'):
        if command not in context.get('checks', []):
            fail(f'CONTEXT_PACK.json checks missing {command}')
    kms = context.get('key_machine_surfaces', {})
    for key, expected in {
        'ro_crate_metadata_json': 'ro-crate-metadata.json',
        'ro_crate_profile_markdown': 'RO_CRATE_PROFILE.md',
        'ro_crate_metadata_validator': EXPECTED_VALIDATOR,
        'ro_crate_metadata_schema': 'schemas/ro_crate_metadata.schema.json',
        'release_artifact_verifier': 'scripts/verify_release_artifact.py',
        'release_artifact_verifier_validator': 'scripts/validate_command_runners.py',
    }.items():
        if kms.get(key) != expected:
            fail(f'CONTEXT_PACK.json key_machine_surfaces.{key} mismatch')

    validation_paths = {item['path'] for item in control.get('surfaces', {}).get('validation_and_packaging', [])}
    opening_paths = {item['path'] for item in control.get('surfaces', {}).get('opening_and_resumption', [])}
    for rel in ('ro-crate-metadata.json', 'RO_CRATE_PROFILE.md', 'schemas/ro_crate_metadata.schema.json', EXPECTED_VALIDATOR):
        if rel not in validation_paths:
            fail(f'CONTROL_SURFACES.json validation_and_packaging missing {rel}')
    for rel in ('ro-crate-metadata.json', 'RO_CRATE_PROFILE.md'):
        if rel not in opening_paths:
            fail(f'CONTROL_SURFACES.json opening_and_resumption missing {rel}')

    for gate_id in ('careful_revision_pass', 'publish_audit', 'named_bundle_packaging'):
        refs = set(gates['gates'][gate_id].get('authoritative_sequence', []) + gates['gates'][gate_id].get('required_surfaces', []) + gates['gates'][gate_id].get('checks', []))
        if EXPECTED_VALIDATOR not in refs:
            fail(f'LIFECYCLE_GATES.json {gate_id} missing RO-Crate validator')
    linked = set()
    for lane in frontier.get('lanes', []):
        linked.update(lane.get('linked_surfaces', []))
    if 'ro-crate-metadata.json' not in linked or EXPECTED_VALIDATOR not in linked:
        fail('CURRENT_FRONTIER.json missing RO-Crate metadata linkage')
    anchored = {item['path'] for item in anchors.get('anchored_surfaces', [])}
    if 'ro-crate-metadata.json' not in anchored:
        fail('REVISION_ANCHORS.json missing ro-crate-metadata.json anchor')
    if EXPECTED_VALIDATOR not in set(anchors.get('validators', [])):
        fail('REVISION_ANCHORS.json validators missing RO-Crate validator')
    for rel in ('ro-crate-metadata.json', 'RO_CRATE_PROFILE.md'):
        if rel not in manifest.get('included_roots', []):
            fail(f'RELEASE_MANIFEST.json included_roots missing {rel}')
    command_runner = load_json('COMMAND_RUNNER_SEQUENCE.json')
    sequences = {sequence.get('id'): [step.get('script') for step in sequence.get('steps', [])] for sequence in command_runner.get('sequences', [])}
    for sequence_id in ('gate', 'publish_audit', 'package_final_validators'):
        if 'validate_ro_crate_metadata.py' not in sequences.get(sequence_id, []):
            fail(f'COMMAND_RUNNER_SEQUENCE.json {sequence_id} missing RO-Crate validator')
    for rel in ('scripts/gate.py', 'scripts/publish_audit.py', 'scripts/package_release.py'):
        text = (ROOT / rel).read_text(encoding='utf-8')
        if 'COMMAND_RUNNER_SEQUENCE.json' not in text and 'load_runner_sequence' not in text and 'load_sequence' not in text:
            fail(f'{rel} missing governed command-runner loading')
    if 'ro-crate-check:' not in (ROOT / 'Makefile').read_text(encoding='utf-8'):
        fail('Makefile missing ro-crate-check target')


def main() -> None:
    print('ro-crate-validate: loading metadata surfaces', flush=True)
    for rel in ('ro-crate-metadata.json', 'RO_CRATE_PROFILE.md', 'schemas/ro_crate_metadata.schema.json'):
        require(rel)
    crate = load_json(CRATE_JSON)
    schema = load_json(SCHEMA)
    print('ro-crate-validate: checking schema and exact Markdown mirror', flush=True)
    validate_against_schema(crate, schema, 'ro-crate-metadata.json')
    if PROFILE_MD.read_text(encoding='utf-8') != render_markdown(crate):
        fail('RO_CRATE_PROFILE.md must exactly mirror ro-crate-metadata.json')
    print('ro-crate-validate: checking archive wiring and file digests', flush=True)
    validate_crate(crate)
    print(f'ro-crate-validate: OK ({len(entity_map(crate))} entities, {len(REQUIRED_HAS_PARTS)} hasPart entries, {len(DIGESTED_FILE_ENTITIES)} digest-checked files)')


if __name__ == '__main__':
    main()
