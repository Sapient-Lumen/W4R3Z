#!/usr/bin/env python3
from __future__ import annotations

import fnmatch
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import zipfile
from pathlib import Path

sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / 'scripts'
SEQUENCE_CONTRACT = ROOT / 'COMMAND_RUNNER_SEQUENCE.json'
RELEASE_ARTIFACT_VERIFIER = SCRIPTS / 'verify_release_artifact.py'
# Governed package refresh/final members are loaded from COMMAND_RUNNER_SEQUENCE.json: build_asset_indexes.py, build_dedupe_report.py, rebuild_indexes.py, validate_opening_surface.py, validate_context_pack.py, validate_makefile_surface.py, validate_toolchain_lock.py, build_asset_indexes.py, build_dedupe_report.py, rebuild_indexes.py, validate_manifest_index.py, validate_dedupe_report.py, validate_json_inventory.py, validate_text_payloads.py, validate_text_surface_policy.py, validate_payload_formats.py, validate_crypto_envelopes.py, validate_provenance_ledgers.py, validate_filesystem_policy.py, validate_asset_indexes.py, validate_paper_series.py, validate_embedded_archives.py, validate_source_index.py, validate_adrs.py, validate_rfcs.py, validate_current_frontier.py, validate_assimilation_ledger.py, validate_revision_anchors.py, validate_control_surfaces.py, validate_validation_index.py, validate_claim_obligation_map.py, validate_public_status.py, validate_ro_crate_metadata.py, validate_changelog.py, validate_archive_index.py, validate_historical_anomalies.py, validate_cross_references.py, validate_audit_witnesses.py, validate_command_runners.py, validate_archive_identity.py, validate_publishing.py
FIXED_ZIP_TIMESTAMP = (1980, 1, 1, 0, 0, 0)
ZIP_COMPRESSION = zipfile.ZIP_DEFLATED
ZIP_COMPRESSLEVEL = 6
HEX64 = re.compile(r'^[0-9a-f]{64}$')
TRANSIENT_SKIP_ROOTS = {'sources', 'artifacts', 'certs'}
TRANSIENT_BUILD_PATTERNS = [
    '_renders*',
    'render_check*',
    '_render*',
    '*.aux',
    '*.log',
    '*.out',
    '*.toc',
    '*.bbl',
    '*.blg',
]


def load_runner_sequence(sequence_id: str) -> list[str]:
    data = json.loads(SEQUENCE_CONTRACT.read_text(encoding='utf-8'))
    for sequence in data.get('sequences', []):
        if sequence.get('id') == sequence_id:
            scripts = [step.get('script') for step in sequence.get('steps', [])]
            if not scripts or not all(isinstance(name, str) and name for name in scripts):
                raise SystemExit(f'package-release: invalid command-runner sequence {sequence_id}')
            return scripts
    raise SystemExit(f'package-release: missing command-runner sequence {sequence_id}')


def file_count(root: Path) -> int:
    if root == ROOT:
        return len(shipped_files())
    return sum(1 for p in root.rglob('*') if p.is_file())


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 16), b''):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def regular_file_external_attr(mode: int) -> int:
    """Return portable Unix ZIP external attributes for a regular file."""
    return (stat.S_IFREG | (mode & 0o777)) << 16


def shipped_files() -> list[Path]:
    """Return shipped regular files and refuse symlinks/special files."""
    files: list[Path] = []
    for path in sorted(ROOT.rglob('*')):
        rel = path.relative_to(ROOT).as_posix()
        if path.is_symlink():
            raise SystemExit(f'package-release: refusing to ship symlink: {rel}')
        if path.is_dir():
            continue
        if not path.is_file():
            raise SystemExit(f'package-release: refusing to ship non-regular file: {rel}')
        files.append(path)
    return files


def assert_root_name() -> None:
    if not re.fullmatch(r'EvidenceVault-rev\d{4}', ROOT.name):
        raise SystemExit(f'package-release: repo root must be named EvidenceVault-rev####, got {ROOT.name!r}')


def assert_no_transient_bytecode() -> None:
    offenders = []
    for path in ROOT.rglob('*'):
        if path.name == '__pycache__' or path.suffix == '.pyc':
            offenders.append(path.relative_to(ROOT).as_posix())
            if len(offenders) >= 10:
                break
    if offenders:
        joined = ', '.join(offenders)
        raise SystemExit(f'package-release: transient Python bytecode present: {joined}')


def assert_no_transient_build_artifacts() -> None:
    """Refuse paper/review build byproducts before ZIP emission.

    Preflight owns the broad shipping posture, but package_release.py is also a
    direct operator-facing command.  Keep the final packager from shipping
    accidental LaTeX/review outputs when it is run outside the shell preflight
    wrapper.  The skip roots match publish_preflight.sh so retained source or
    curated artifact payload names are not reclassified by filename alone.
    """
    for path in ROOT.rglob('*'):
        try:
            rel_parts = path.relative_to(ROOT).parts
        except ValueError:
            continue
        if rel_parts and rel_parts[0] in TRANSIENT_SKIP_ROOTS:
            continue
        if any(fnmatch.fnmatch(path.name, pattern) for pattern in TRANSIENT_BUILD_PATTERNS):
            rel = path.relative_to(ROOT).as_posix()
            raise SystemExit(f'package-release: transient build/review artifact present: {rel}')


def included_root_covers(rel: str, included_root: str) -> bool:
    if included_root.endswith('/'):
        return rel.startswith(included_root)
    return rel == included_root


def assert_manifest_inclusion_coverage(manifest: dict) -> None:
    """Require RELEASE_MANIFEST.included_roots to fence every shipped path.

    The packager intentionally ships the whole checked archive root.  This guard
    makes that broad behavior auditable: every emitted file must be covered by
    an explicit RELEASE_MANIFEST.json included_roots entry, so new root files or
    legacy payload directories cannot silently enter the named bundle without
    bundle-identity metadata being updated first.
    """
    included_roots = manifest.get('included_roots')
    if not isinstance(included_roots, list) or not all(isinstance(item, str) and item for item in included_roots):
        raise SystemExit('package-release: RELEASE_MANIFEST included_roots must be a non-empty list of strings')
    if len(included_roots) != len(set(included_roots)):
        raise SystemExit('package-release: RELEASE_MANIFEST included_roots contains duplicate entries')
    for item in included_roots:
        if item.startswith('/') or '\\' in item or '..' in Path(item).parts:
            raise SystemExit(f'package-release: unsafe RELEASE_MANIFEST included_roots entry: {item}')
        target = ROOT / item.rstrip('/')
        if item.endswith('/'):
            if not target.is_dir():
                raise SystemExit(f'package-release: RELEASE_MANIFEST included_roots missing directory: {item}')
        elif not target.exists():
            raise SystemExit(f'package-release: RELEASE_MANIFEST included_roots missing path: {item}')
    for path in shipped_files():
        rel = path.relative_to(ROOT).as_posix()
        if not any(included_root_covers(rel, item) for item in included_roots):
            raise SystemExit(f'package-release: RELEASE_MANIFEST included_roots does not cover shipped path: {rel}')


def refresh_release_manifest() -> dict:
    path = ROOT / 'RELEASE_MANIFEST.json'
    data = json.loads(path.read_text(encoding='utf-8'))
    data['repo_root'] = ROOT.name
    data['file_count'] = file_count(ROOT)
    data['identity_digests'] = {
        'revision_receipt_sha256': sha256(ROOT / data['revision_receipt']),
        'opening_contract_sha256': sha256(ROOT / data['opening_contract']),
        'revision_anchors_sha256': sha256(ROOT / data['revision_anchors']),
        'context_pack_sha256': sha256(ROOT / 'CONTEXT_PACK.json'),
        'agents_sha256': sha256(ROOT / data['agent_contract']),
        'makefile_sha256': sha256(ROOT / data['command_surface']),
        'source_index_json_sha256': sha256(ROOT / data['source_index_json']),
        'current_frontier_json_sha256': sha256(ROOT / data['current_frontier_json']),
        'validation_index_json_sha256': sha256(ROOT / data['validation_index_json']),
        'assimilation_ledger_json_sha256': sha256(ROOT / 'ASSIMILATION_LEDGER.json'),
        'adr_index_json_sha256': sha256(ROOT / data['adr_index_json']),
        'rfc_index_json_sha256': sha256(ROOT / data['rfc_index_json']),
        'archive_index_json_sha256': sha256(ROOT / data['archive_index_json']),
        'control_surfaces_sha256': sha256(ROOT / 'CONTROL_SURFACES.json'),
        'lifecycle_gates_sha256': sha256(ROOT / 'LIFECYCLE_GATES.json'),
        'artifact_index_json_sha256': sha256(ROOT / 'artifacts' / 'ARTIFACTS_INDEX.json'),
        'cert_index_json_sha256': sha256(ROOT / 'certs' / 'CERTS_INDEX.json'),
        'toolchain_lock_json_sha256': sha256(ROOT / 'TOOLCHAIN_LOCK.json'),
        'claim_obligation_map_json_sha256': sha256(ROOT / 'CLAIM_OBLIGATION_MAP.json'),
        'public_status_json_sha256': sha256(ROOT / 'PUBLIC_STATUS.json'),
        'command_runner_sequence_json_sha256': sha256(ROOT / 'COMMAND_RUNNER_SEQUENCE.json'),
        'release_artifact_verifier_sha256': sha256(ROOT / data['release_artifact_verifier']),
        'release_artifact_verifier_validator_sha256': sha256(ROOT / data['release_artifact_verifier_validator']),
        'release_manifest_schema_sha256': sha256(ROOT / data['release_manifest_schema']),
        'archive_identity_validator_sha256': sha256(ROOT / data['archive_identity_validator']),
        'ro_crate_metadata_schema_sha256': sha256(ROOT / data['ro_crate_metadata_schema']),
        'ro_crate_metadata_validator_sha256': sha256(ROOT / data['ro_crate_metadata_validator']),
    }
    path.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    return data


def run_child_script(script_name: str, label: str) -> None:
    """Run a package-refresh or package-final child in a fresh interpreter."""
    env = os.environ.copy()
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    script = SCRIPTS / script_name
    print(f'{label}: {script_name}', flush=True)
    subprocess.run([sys.executable, str(script)], cwd=ROOT, env=env, check=True)


def run_package_refresh_sequence() -> None:
    """Refresh generated package inputs without importing builders in-process."""
    for script_name in load_runner_sequence('package_refresh'):
        run_child_script(script_name, 'package-refresh')


def run_final_validators() -> None:
    """Run the governed full-gate-equivalent sequence immediately before ZIP emission.

    Direct package emission is an operator-facing release path, not a shortcut
    around archive assurance.  The package-final sequence is loaded from
    COMMAND_RUNNER_SEQUENCE.json and runner-check requires it to equal the gate
    sequence.
    """
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    for script_name in load_runner_sequence('package_final_validators'):
        run_child_script(script_name, 'package-final')


def expected_zip_members() -> list[str]:
    return [f"{ROOT.name}/{p.relative_to(ROOT).as_posix()}" for p in shipped_files()]


def parse_manifest_bytes(data: bytes) -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    seen: set[str] = set()
    text = data.decode('utf-8')
    for n, line in enumerate(text.splitlines(), start=1):
        if not line.strip():
            raise SystemExit(f'package-release: embedded MANIFEST.sha256 line {n} is blank')
        try:
            digest, rel = line.split(None, 1)
        except ValueError as exc:
            raise SystemExit(f'package-release: embedded MANIFEST.sha256 line {n} is malformed') from exc
        rel = rel.strip()
        if not HEX64.fullmatch(digest):
            raise SystemExit(f'package-release: embedded MANIFEST.sha256 line {n} has invalid digest')
        if rel in seen:
            raise SystemExit(f'package-release: embedded MANIFEST.sha256 duplicates path: {rel}')
        if rel == 'MANIFEST.sha256':
            raise SystemExit('package-release: embedded MANIFEST.sha256 must not include itself')
        seen.add(rel)
        rows.append((digest, rel))
    return rows


def verify_zip_payload(bundle_path: Path, expected_bundle_name: str | None = None) -> None:
    expected = expected_zip_members()
    expected_bundle_name = expected_bundle_name or bundle_path.name
    root_prefix = f'{ROOT.name}/'
    with zipfile.ZipFile(bundle_path, 'r') as zf:
        bad = zf.testzip()
        if bad is not None:
            raise SystemExit(f'package-release: ZIP integrity check failed at {bad}')
        actual = zf.namelist()
        if actual != expected:
            missing = sorted(set(expected) - set(actual))[:10]
            extra = sorted(set(actual) - set(expected))[:10]
            raise SystemExit(f'package-release: zip member mismatch; missing={missing}, extra={extra}')
        if len(actual) != len(set(actual)):
            raise SystemExit('package-release: duplicate ZIP entries')
        if any(name.endswith('/') for name in actual):
            raise SystemExit('package-release: ZIP contains directory entries; expected file entries only')
        if zf.comment:
            raise SystemExit('package-release: ZIP file comment must be empty')
        info_by_name = {info.filename: info for info in zf.infolist()}
        for name in actual:
            if not name.startswith(root_prefix):
                raise SystemExit(f'package-release: ZIP entry outside expected root: {name}')
            rel = name[len(root_prefix):]
            if not rel or rel.startswith('/') or '..' in Path(rel).parts or '\\' in rel:
                raise SystemExit(f'package-release: unsafe ZIP entry path: {name}')
            if rel.endswith('.pyc') or '__pycache__' in Path(rel).parts:
                raise SystemExit(f'package-release: transient bytecode in ZIP: {name}')
            info = info_by_name[name]
            if info.date_time != FIXED_ZIP_TIMESTAMP:
                raise SystemExit(f'package-release: ZIP entry timestamp is not fixed for {name}')
            if info.compress_type != ZIP_COMPRESSION:
                raise SystemExit(f'package-release: ZIP entry compression mismatch for {name}')
            if info.extra:
                raise SystemExit(f'package-release: ZIP entry has non-empty extra metadata for {name}')
            source = ROOT / rel
            if info.create_system != 3:
                raise SystemExit(f'package-release: ZIP entry must use Unix external attributes for {name}')
            expected_mode = (stat.S_IMODE(source.stat().st_mode) or 0o644) & 0o777
            encoded_mode = info.external_attr >> 16
            if stat.S_IFMT(encoded_mode) != stat.S_IFREG:
                raise SystemExit(f'package-release: ZIP entry is not marked as a regular file for {name}: {stat.filemode(encoded_mode)}')
            actual_mode = stat.S_IMODE(encoded_mode)
            if actual_mode != expected_mode:
                raise SystemExit(f'package-release: ZIP mode mismatch for {name}: expected {expected_mode:o}, got {actual_mode:o}')

        release_manifest = json.loads(zf.read(root_prefix + 'RELEASE_MANIFEST.json').decode('utf-8'))
        if release_manifest['repo_root'] != ROOT.name:
            raise SystemExit('package-release: embedded repo_root mismatch')
        expected_name = expected_bundle_name or bundle_path.name
        if release_manifest['bundle'] != expected_name:
            raise SystemExit('package-release: embedded bundle name mismatch')
        if release_manifest['file_count'] != len(actual):
            raise SystemExit('package-release: embedded file_count does not match ZIP entry count')

        manifest_rows = parse_manifest_bytes(zf.read(root_prefix + 'MANIFEST.sha256'))
        expected_manifest_rels = [name[len(root_prefix):] for name in actual if name[len(root_prefix):] != 'MANIFEST.sha256']
        actual_manifest_rels = [rel for _, rel in manifest_rows]
        if actual_manifest_rels != expected_manifest_rels:
            missing = sorted(set(expected_manifest_rels) - set(actual_manifest_rels))[:10]
            extra = sorted(set(actual_manifest_rels) - set(expected_manifest_rels))[:10]
            raise SystemExit(f'package-release: embedded MANIFEST path coverage/order mismatch; missing={missing}, extra={extra}')
        for digest, rel in manifest_rows:
            actual_digest = sha256_bytes(zf.read(root_prefix + rel))
            if actual_digest != digest:
                raise SystemExit(f'package-release: embedded MANIFEST digest mismatch for {rel}')



def write_sha256_sidecar(bundle_path: Path, digest: str) -> Path:
    """Write the detached SHA-256 sidecar atomically next to the emitted ZIP."""
    sidecar_path = bundle_path.with_name(bundle_path.name + '.sha256')
    tmp_path = sidecar_path.with_name(f'.{sidecar_path.name}.tmp')
    tmp_path.write_text(f'{digest}  {bundle_path.name}\n', encoding='utf-8')
    tmp_path.replace(sidecar_path)
    return sidecar_path


def run_release_artifact_verifier(bundle_path: Path, sidecar_path: Path) -> None:
    """Verify the emitted ZIP as an external artifact, including its sidecar."""
    env = os.environ.copy()
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    print('package-artifact-verify: verify_release_artifact.py', flush=True)
    subprocess.run(
        [sys.executable, str(RELEASE_ARTIFACT_VERIFIER), str(bundle_path), '--sidecar', str(sidecar_path), '--require-sidecar'],
        cwd=ROOT,
        env=env,
        check=True,
    )

def write_bundle_atomically(bundle_path: Path) -> str:
    try:
        inside_root = bundle_path.resolve().is_relative_to(ROOT.resolve())
    except AttributeError:
        root_resolved = str(ROOT.resolve())
        inside_root = str(bundle_path.resolve()).startswith(root_resolved + '/')
    if inside_root:
        raise SystemExit('package-release: refusing to write bundle inside archive root')

    tmp_path = bundle_path.with_name(f'.{bundle_path.name}.tmp')
    if tmp_path.exists():
        tmp_path.unlink()
    try:
        files = shipped_files()
        with zipfile.ZipFile(tmp_path, 'w', compression=ZIP_COMPRESSION, compresslevel=ZIP_COMPRESSLEVEL) as zf:
            for index, path in enumerate(files, start=1):
                rel = path.relative_to(ROOT).as_posix()
                arcname = f'{ROOT.name}/{rel}'
                info = zipfile.ZipInfo(arcname, FIXED_ZIP_TIMESTAMP)
                info.create_system = 3
                info.compress_type = ZIP_COMPRESSION
                mode = stat.S_IMODE(path.stat().st_mode) or 0o644
                info.external_attr = regular_file_external_attr(mode)
                with path.open('rb') as src, zf.open(info, 'w') as dst:
                    shutil.copyfileobj(src, dst, length=1024 * 1024)
                if index == 1 or index % 500 == 0 or index == len(files):
                    print(f'package-write: {index}/{len(files)}', flush=True)
        print('package-verify: begin', flush=True)
        verify_zip_payload(tmp_path, expected_bundle_name=bundle_path.name)
        print('package-verify: OK', flush=True)
        tmp_path.replace(bundle_path)
        digest = sha256(bundle_path)
        sidecar_path = write_sha256_sidecar(bundle_path, digest)
        run_release_artifact_verifier(bundle_path, sidecar_path)
        print(f'package-sidecar: {sidecar_path}', flush=True)
        return digest
    finally:
        if tmp_path.exists():
            tmp_path.unlink()


def main() -> None:
    assert_root_name()
    assert_no_transient_bytecode()
    assert_no_transient_build_artifacts()
    # First rebuild scoped asset indexes and source/index surfaces so release identity digests see current generated files.
    run_package_refresh_sequence()
    manifest = refresh_release_manifest()
    assert_manifest_inclusion_coverage(manifest)
    # RELEASE_MANIFEST.json has just changed; rebuild again so INDEX/files.* and MANIFEST.sha256
    # describe the exact files that will be zipped.
    run_child_script('rebuild_indexes.py', 'package-refresh')
    run_final_validators()
    assert_no_transient_bytecode()
    assert_no_transient_build_artifacts()
    manifest = json.loads((ROOT / 'RELEASE_MANIFEST.json').read_text(encoding='utf-8'))
    assert_manifest_inclusion_coverage(manifest)
    bundle_path = ROOT.parent / manifest['bundle']
    digest = write_bundle_atomically(bundle_path)
    print(bundle_path)
    print(f'sha256={digest}')


if __name__ == '__main__':
    main()
