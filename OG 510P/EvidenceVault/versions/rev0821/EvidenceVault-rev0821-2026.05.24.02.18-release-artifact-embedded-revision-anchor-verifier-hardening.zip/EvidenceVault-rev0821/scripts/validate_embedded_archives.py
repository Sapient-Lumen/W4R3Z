#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import stat
import sys
import tarfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
HEX64 = set("0123456789abcdef")


def fail(msg: str) -> None:
    print(f"embedded-archive-validate: FAIL: {msg}", file=sys.stderr)
    sys.exit(1)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_member_name(name: str, archive_label: str) -> None:
    if not name or name.startswith("/") or "\\" in name:
        fail(f"{archive_label} has unsafe member path: {name!r}")
    parts = Path(name).parts
    if ".." in parts:
        fail(f"{archive_label} has path traversal member: {name!r}")


def snapshot_manifest_bytes(snapshot: dict) -> bytes:
    manifest = {
        "version": snapshot["manifest_version"],
        "owner": "published/",
        "entry_points": [
            {"path": item["path"], "role": item["role"]}
            for item in snapshot["entry_points"]
        ],
        "canonical_context": snapshot["canonical_context"],
        "principles": snapshot["principles"],
    }
    return (json.dumps(manifest, indent=2) + "\n").encode()


def validate_zip_member_metadata(info: zipfile.ZipInfo, rel: str) -> None:
    if info.date_time != (1980, 1, 1, 0, 0, 0):
        fail(f"ZIP member timestamp is not fixed: {rel}:{info.filename}")
    if info.compress_type != zipfile.ZIP_DEFLATED:
        fail(f"ZIP member compression must be deflated: {rel}:{info.filename}")
    if info.create_system != 3:
        fail(f"ZIP member must use Unix external attrs: {rel}:{info.filename}")
    if info.extra:
        fail(f"ZIP member has non-empty extra metadata: {rel}:{info.filename}")
    encoded_mode = info.external_attr >> 16
    if stat.S_IFMT(encoded_mode) != stat.S_IFREG:
        fail(f"ZIP member is not marked as a regular file: {rel}:{info.filename} ({stat.filemode(encoded_mode)})")
    if stat.S_IMODE(encoded_mode) != 0o644:
        fail(f"ZIP member mode must be 0644: {rel}:{info.filename} ({stat.S_IMODE(encoded_mode):04o})")


def validate_public_release_zip(path: Path) -> int:
    rel = path.relative_to(ROOT).as_posix()
    with zipfile.ZipFile(path, "r") as zf:
        bad = zf.testzip()
        if bad is not None:
            fail(f"ZIP integrity failure in {rel}: {bad}")
        names = zf.namelist()
        if zf.comment:
            fail(f"ZIP file comment must be empty: {rel}")
        if not names:
            fail(f"ZIP is empty: {rel}")
        if len(names) != len(set(names)):
            fail(f"ZIP has duplicate members: {rel}")
        roots = set()
        info_by_name = {info.filename: info for info in zf.infolist()}
        for name in names:
            safe_member_name(name, rel)
            if name.endswith("/"):
                fail(f"ZIP contains directory entry rather than file entry: {rel}:{name}")
            validate_zip_member_metadata(info_by_name[name], rel)
            parts = Path(name).parts
            roots.add(parts[0])
        if len(roots) != 1:
            fail(f"ZIP must have one bundle root: {rel}")
        root = next(iter(roots))
        manifest_path = path.with_suffix(".bundle.json")
        if manifest_path.is_file():
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            if manifest.get("bundle_path") != rel:
                fail(f"public release bundle manifest path mismatch for {rel}")
            if manifest.get("bundle_sha256") != sha256_file(path):
                fail(f"public release bundle sha256 mismatch for {rel}")
            if manifest.get("bundle_size_bytes") != path.stat().st_size:
                fail(f"public release bundle size mismatch for {rel}")
            if manifest.get("bundle_root") != root:
                fail(f"public release bundle root mismatch for {rel}")
            expected = [f"{root}/{item['path']}" for item in manifest.get("included_files", [])]
            if names != expected:
                missing = sorted(set(expected) - set(names))[:10]
                extra = sorted(set(names) - set(expected))[:10]
                fail(f"public release ZIP payload mismatch for {rel}; missing={missing}, extra={extra}")
            source_record_rel = manifest.get("source_record")
            if not isinstance(source_record_rel, str) or not source_record_rel:
                fail(f"public release bundle manifest missing source_record for {rel}")
            source_record_path = ROOT / source_record_rel
            if not source_record_path.is_file():
                fail(f"public release bundle source_record is missing for {rel}: {source_record_rel}")
            if manifest.get("source_record_sha256") != sha256_file(source_record_path):
                fail(f"public release bundle source_record sha256 mismatch for {rel}")
            source_record = json.loads(source_record_path.read_text(encoding="utf-8"))
            snapshot_rel = manifest.get("public_surface_snapshot")
            if not isinstance(snapshot_rel, str) or not (ROOT / snapshot_rel).is_file():
                fail(f"public release bundle snapshot is missing for {rel}: {snapshot_rel!r}")
            snapshot_bytes = (ROOT / snapshot_rel).read_bytes()
            if manifest.get("public_surface_snapshot_sha256") != sha256_bytes(snapshot_bytes):
                fail(f"public release bundle snapshot sha256 mismatch for {rel}")
            snapshot = json.loads(snapshot_bytes.decode("utf-8"))
            for item in manifest.get("included_files", []):
                member = f"{root}/{item['path']}"
                data = zf.read(member)
                if item.get("size_bytes") != len(data):
                    fail(f"public release ZIP member size mismatch for {rel}:{member}")
                if item.get("sha256") != sha256_bytes(data):
                    fail(f"public release ZIP member sha256 mismatch for {rel}:{member}")
                if item["path"] == source_record.get("public_surface_manifest"):
                    expected_payload = snapshot_manifest_bytes(snapshot)
                else:
                    source_path = ROOT / item["path"]
                    if not source_path.is_file():
                        fail(f"public release included file missing on disk for {rel}: {item['path']}")
                    expected_payload = source_path.read_bytes()
                if data != expected_payload:
                    fail(f"public release ZIP member is stale relative to materialized source for {rel}:{member}")
    return len(names)


def validate_repro_pack_tar(path: Path) -> int:
    rel = path.relative_to(ROOT).as_posix()
    with tarfile.open(path, "r:gz") as tf:
        members = tf.getmembers()
        if not members:
            fail(f"tar.gz is empty: {rel}")
        names = [m.name for m in members]
        if len(names) != len(set(names)):
            fail(f"tar.gz has duplicate members: {rel}")
        for m in members:
            safe_member_name(m.name, rel)
            if m.isdir():
                # Directory entries are harmless but this archive family currently stores files only.
                continue
            if not m.isfile():
                fail(f"tar.gz contains non-regular member: {rel}:{m.name}")
        manifest_names = [n for n in names if Path(n).parent == Path(".") and Path(n).name.endswith("manifest_example.json")]
        if not manifest_names:
            manifest_names = [n for n in names if Path(n).parent == Path(".") and "manifest" in Path(n).name and n.endswith(".json")]
        if len(manifest_names) != 1:
            fail(f"tar.gz must contain exactly one root manifest JSON: {rel}; got {manifest_names}")
        manifest_file = tf.extractfile(manifest_names[0])
        if manifest_file is None:
            fail(f"cannot read root manifest in {rel}")
        manifest = json.loads(manifest_file.read().decode("utf-8"))
        files = manifest.get("files")
        if not isinstance(files, list) or not files:
            fail(f"repro-pack manifest has no files list: {rel}")
        expected_artifacts = []
        total_bytes = 0
        for idx, item in enumerate(files):
            if not isinstance(item, dict):
                fail(f"repro-pack manifest files[{idx}] must be an object: {rel}")
            artifact = item.get("artifact")
            digest = item.get("sha256")
            size = item.get("bytes")
            if not isinstance(artifact, str) or not artifact or "/" in artifact or "\\" in artifact or artifact.startswith("."):
                fail(f"repro-pack manifest artifact must be a basename: {rel}:{artifact!r}")
            if not isinstance(digest, str) or len(digest) != 64 or any(c not in HEX64 for c in digest):
                fail(f"repro-pack manifest artifact has invalid sha256: {rel}:{artifact}")
            if not isinstance(size, int) or size < 0:
                fail(f"repro-pack manifest artifact has invalid byte count: {rel}:{artifact}")
            member_name = f"artifacts/{artifact}"
            try:
                data = tf.extractfile(member_name).read()
            except Exception as exc:
                fail(f"repro-pack manifest references missing member {member_name} in {rel}: {exc}")
            if len(data) != size:
                fail(f"repro-pack member size mismatch: {rel}:{member_name}")
            if sha256_bytes(data) != digest:
                fail(f"repro-pack member sha256 mismatch: {rel}:{member_name}")
            expected_artifacts.append(member_name)
            total_bytes += size
        actual_artifacts = sorted(n for n in names if n.startswith("artifacts/") and not n.endswith("/"))
        if actual_artifacts != sorted(expected_artifacts):
            missing = sorted(set(expected_artifacts) - set(actual_artifacts))[:10]
            extra = sorted(set(actual_artifacts) - set(expected_artifacts))[:10]
            fail(f"repro-pack artifact coverage mismatch for {rel}; missing={missing}, extra={extra}")
        totals = manifest.get("totals", {})
        if isinstance(totals, dict):
            if totals.get("artifact_count") is not None and totals["artifact_count"] != len(files):
                fail(f"repro-pack totals.artifact_count mismatch for {rel}")
            if totals.get("bytes") is not None and totals["bytes"] != total_bytes:
                fail(f"repro-pack totals.bytes mismatch for {rel}")
            if totals.get("total_bytes") is not None and totals["total_bytes"] != total_bytes:
                fail(f"repro-pack totals.total_bytes mismatch for {rel}")
    return len(members)


def validate_extracted_repro_pack_dir(path: Path) -> int:
    rel = path.relative_to(ROOT).as_posix()
    manifest_paths = sorted(p for p in path.glob("*manifest*.json") if p.is_file())
    if len(manifest_paths) != 1:
        fail(f"extracted repro-pack must contain exactly one root manifest JSON: {rel}; got {[p.name for p in manifest_paths]}")
    manifest = json.loads(manifest_paths[0].read_text(encoding="utf-8"))
    files = manifest.get("files")
    if not isinstance(files, list) or not files:
        fail(f"extracted repro-pack manifest has no files list: {rel}")
    artifacts_dir = path / "artifacts"
    if not artifacts_dir.is_dir():
        fail(f"extracted repro-pack missing artifacts/ directory: {rel}")
    expected: list[str] = []
    total_bytes = 0
    for idx, item in enumerate(files):
        artifact = item.get("artifact")
        digest = item.get("sha256")
        size = item.get("bytes")
        if not isinstance(artifact, str) or not artifact or "/" in artifact or "\\" in artifact or artifact.startswith("."):
            fail(f"extracted repro-pack manifest artifact must be a basename: {rel}:{artifact!r}")
        if not isinstance(digest, str) or len(digest) != 64 or any(c not in HEX64 for c in digest):
            fail(f"extracted repro-pack manifest artifact has invalid sha256: {rel}:{artifact}")
        if not isinstance(size, int) or size < 0:
            fail(f"extracted repro-pack manifest artifact has invalid byte count: {rel}:{artifact}")
        artifact_path = artifacts_dir / artifact
        if not artifact_path.is_file():
            fail(f"extracted repro-pack manifest references missing file: {artifact_path.relative_to(ROOT).as_posix()}")
        data = artifact_path.read_bytes()
        if len(data) != size:
            fail(f"extracted repro-pack file size mismatch: {artifact_path.relative_to(ROOT).as_posix()}")
        if sha256_bytes(data) != digest:
            fail(f"extracted repro-pack file sha256 mismatch: {artifact_path.relative_to(ROOT).as_posix()}")
        expected.append(artifact_path.relative_to(path).as_posix())
        total_bytes += size
    actual = sorted(p.relative_to(path).as_posix() for p in artifacts_dir.rglob("*") if p.is_file())
    if actual != sorted(expected):
        missing = sorted(set(expected) - set(actual))[:10]
        extra = sorted(set(actual) - set(expected))[:10]
        fail(f"extracted repro-pack artifact coverage mismatch for {rel}; missing={missing}, extra={extra}")
    totals = manifest.get("totals", {})
    if isinstance(totals, dict):
        if totals.get("artifact_count") is not None and totals["artifact_count"] != len(files):
            fail(f"extracted repro-pack totals.artifact_count mismatch for {rel}")
        if totals.get("bytes") is not None and totals["bytes"] != total_bytes:
            fail(f"extracted repro-pack totals.bytes mismatch for {rel}")
        if totals.get("total_bytes") is not None and totals["total_bytes"] != total_bytes:
            fail(f"extracted repro-pack totals.total_bytes mismatch for {rel}")
    return len(files)


def main() -> None:
    zip_paths = sorted(ROOT.rglob("*.zip"))
    tar_paths = sorted(p for p in ROOT.rglob("*.tar.gz") if p.is_file())
    repro_dirs = sorted(
        p for p in (ROOT / "artifacts" / "repro_packs").iterdir()
        if p.is_dir() and p.name != "original"
    )
    zip_members = 0
    tar_members = 0
    repro_artifacts = 0
    for path in zip_paths:
        zip_members += validate_public_release_zip(path)
    for path in tar_paths:
        tar_members += validate_repro_pack_tar(path)
    for path in repro_dirs:
        repro_artifacts += validate_extracted_repro_pack_dir(path)
    print(
        "embedded-archive-validate: OK "
        f"({len(zip_paths)} ZIP files/{zip_members} metadata-checked members, "
        f"{len(tar_paths)} tar.gz files/{tar_members} members, "
        f"{len(repro_dirs)} extracted repro-packs/{repro_artifacts} manifest artifacts)"
    )


if __name__ == "__main__":
    main()
