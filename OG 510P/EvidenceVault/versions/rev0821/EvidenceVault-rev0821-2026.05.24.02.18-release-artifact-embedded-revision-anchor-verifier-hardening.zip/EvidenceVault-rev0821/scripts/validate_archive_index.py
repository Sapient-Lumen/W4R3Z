#!/usr/bin/env python3
"""Validate the archive bundle-index companion surface.

ARCHIVE_INDEX.json is the machine-readable bundle lineage; ARCHIVE_INDEX.md is
its cold-open human mirror.  Archive identity validation checks the current
bundle row, but this dedicated companion validator proves the complete retained
bundle list is unique, descending, name/date coherent, mirrored into Markdown,
and wired through the release/restart validation surfaces.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]
REV_RE = re.compile(r'^rev(\d{4})$')
BUNDLE_RE = re.compile(r'^EvidenceVault-(rev\d{4})-(\d{4}\.\d{2}\.\d{2}\.\d{2}\.\d{2})-([a-z0-9-]+)\.zip$')
RECENT_BUNDLE_FLOOR = 770

MD_SECTION_RE = re.compile(
    r'^## (rev\d{4}) - (\d{4}-\d{2}-\d{2})\n'
    r'- Bundle: `(EvidenceVault-rev\d{4}-\d{4}\.\d{2}\.\d{2}\.\d{2}\.\d{2}-[a-z0-9-]+\.zip)`\n'
    r'- Summary: ([^\n]+)$',
    re.MULTILINE,
)


def fail(msg: str) -> None:
    print(f'archive-index-validate: FAIL: {msg}', file=sys.stderr)
    sys.exit(1)


def load_json(rel: str):
    try:
        return json.loads((ROOT / rel).read_text(encoding='utf-8'))
    except Exception as exc:
        fail(f'invalid JSON in {rel}: {exc}')


def require(rel: str) -> None:
    path = ROOT / rel
    if rel.endswith('/'):
        if not path.is_dir():
            fail(f'missing directory: {rel}')
    elif not path.exists():
        fail(f'missing path: {rel}')


def validate_against_schema(data, schema, label: str) -> None:
    errors = sorted(Draft202012Validator(schema).iter_errors(data), key=lambda e: list(e.path))
    if errors:
        err = errors[0]
        where = '/'.join(str(p) for p in err.path) or '<root>'
        fail(f'{label} schema violation at {where}: {err.message}')


def revision_number(revision: str) -> int:
    m = REV_RE.fullmatch(revision)
    if not m:
        fail(f'invalid revision label: {revision}')
    return int(m.group(1))


def bundle_parts(bundle: str) -> tuple[str, str, str]:
    m = BUNDLE_RE.fullmatch(bundle)
    if not m:
        fail(f'invalid bundle filename: {bundle}')
    return m.group(1), m.group(2), m.group(3)


def validate_json_index(index: dict, release: dict, receipt: dict) -> None:
    if index.get('project') != 'EvidenceVault':
        fail('ARCHIVE_INDEX.json project must be EvidenceVault')
    if index.get('latest_revision') != release['revision']:
        fail('ARCHIVE_INDEX.json latest_revision must match RELEASE_MANIFEST.json')
    bundles = index.get('bundles', [])
    if not bundles:
        fail('ARCHIVE_INDEX.json bundles must not be empty')

    seen_recent_revisions: set[str] = set()
    seen_recent_bundles: set[str] = set()
    previous_recent_number: int | None = None
    for i, entry in enumerate(bundles):
        revision = entry['revision']
        date = entry['date']
        bundle = entry['bundle']
        summary = entry['summary']
        if not summary.strip():
            fail(f'{revision} archive-index summary must be non-empty')
        number = revision_number(revision)
        if number >= RECENT_BUNDLE_FLOOR:
            if bundle in seen_recent_bundles:
                fail(f'duplicate recent archive-index bundle filename: {bundle}')
            seen_recent_bundles.add(bundle)
            if revision in seen_recent_revisions:
                fail(f'duplicate recent archive-index revision: {revision}')
            seen_recent_revisions.add(revision)
            if previous_recent_number is not None and number >= previous_recent_number:
                fail(f'ARCHIVE_INDEX.json recent bundles must descend by revision; {revision} follows rev{previous_recent_number:04d}')
            previous_recent_number = number

        bundle_revision, timestamp, _slug = bundle_parts(bundle)
        if bundle_revision != revision:
            fail(f'{revision} bundle filename embeds {bundle_revision}')
        timestamp_date = timestamp.replace('.', '-', 2).split('.', 1)[0]
        if timestamp_date != date:
            fail(f'{revision} bundle timestamp date {timestamp_date} does not match index date {date}')
        if i == 0:
            for key in ('revision', 'date', 'bundle'):
                if entry[key] != release[key]:
                    fail(f'ARCHIVE_INDEX.json top {key} does not match RELEASE_MANIFEST.json')
            if receipt['revision'] != revision or receipt['date'] != date:
                fail('ARCHIVE_INDEX.json top row does not match REVISION_RECEIPT.json')
            if bundle != release['archive_name'] + '.zip':
                fail('ARCHIVE_INDEX.json top bundle does not match RELEASE_MANIFEST archive_name')
        elif i == 1 and revision != release['previous_revision']:
            fail('ARCHIVE_INDEX.json second row must be previous revision')


def validate_markdown_mirror(index: dict, release: dict) -> None:
    path = ROOT / 'ARCHIVE_INDEX.md'
    data = path.read_bytes()
    if b'\r' in data:
        fail('ARCHIVE_INDEX.md must use LF line endings')
    if not data.endswith(b'\n'):
        fail('ARCHIVE_INDEX.md must end with a newline')
    text = data.decode('utf-8')
    lines = text.splitlines()
    if len(lines) < 4:
        fail('ARCHIVE_INDEX.md is unexpectedly short')
    if lines[0] != '# Archive bundle index':
        fail('ARCHIVE_INDEX.md must start with # Archive bundle index')
    if lines[2] != f'- Latest revision: `{release["revision"]}`':
        fail('ARCHIVE_INDEX.md latest revision line mismatch')

    sections = [(m.group(1), m.group(2), m.group(3), m.group(4)) for m in MD_SECTION_RE.finditer(text)]
    expected = [(entry['revision'], entry['date'], entry['bundle'], entry['summary']) for entry in index['bundles']]
    if sections != expected:
        fail('ARCHIVE_INDEX.md bundle sections do not exactly mirror ARCHIVE_INDEX.json')
    if text.count('# Archive bundle index') != 1:
        fail('ARCHIVE_INDEX.md must contain exactly one top-level title')


def validate_wiring(current: str) -> None:
    policy = load_json('publishing/CANONICAL_POLICY.json')
    if policy.get('archive_bundle_index_markdown') != 'ARCHIVE_INDEX.md':
        fail('publishing/CANONICAL_POLICY.json archive_bundle_index_markdown mismatch')
    if policy.get('archive_bundle_index_json') != 'ARCHIVE_INDEX.json':
        fail('publishing/CANONICAL_POLICY.json archive_bundle_index_json mismatch')
    if policy.get('archive_bundle_index_schema') != 'schemas/archive_bundle_index.schema.json':
        fail('publishing/CANONICAL_POLICY.json archive_bundle_index_schema mismatch')
    if policy.get('archive_index_validator') != 'scripts/validate_archive_index.py':
        fail('publishing/CANONICAL_POLICY.json archive_index_validator mismatch')
    if 'explicit_archive_index_companion_validation' not in policy.get('principles', []):
        fail('publishing/CANONICAL_POLICY.json principles missing explicit_archive_index_companion_validation')

    context = load_json('CONTEXT_PACK.json')
    kms = context.get('key_machine_surfaces', {})
    if kms.get('archive_bundle_index_json') != 'ARCHIVE_INDEX.json':
        fail('CONTEXT_PACK.json archive_bundle_index_json mismatch')
    if kms.get('archive_index_validator') != 'scripts/validate_archive_index.py':
        fail('CONTEXT_PACK.json archive_index_validator mismatch')
    checks = set(context.get('checks', []))
    for command in ('make archive-index-check', 'python3 scripts/validate_archive_index.py'):
        if command not in checks:
            fail(f'CONTEXT_PACK.json checks missing {command}')

    validation = load_json('VALIDATION_INDEX.json')
    checks_by_id = {check['id']: check for check in validation.get('checks', [])}
    check = checks_by_id.get('archive-index-check')
    if check is None:
        fail('VALIDATION_INDEX.json missing archive-index-check')
    if check.get('make_target') != 'archive-index-check':
        fail('archive-index-check make_target mismatch')
    if check.get('scripts') != ['scripts/validate_archive_index.py']:
        fail('archive-index-check script mismatch')
    needed = {
        'ARCHIVE_INDEX.md',
        'ARCHIVE_INDEX.json',
        'schemas/archive_bundle_index.schema.json',
        'RELEASE_MANIFEST.json',
        'REVISION_RECEIPT.json',
        'REVISION_ANCHORS.json',
        'VALIDATION_INDEX.json',
        'CONTEXT_PACK.json',
        'CONTROL_SURFACES.json',
        'LIFECYCLE_GATES.json',
        'publishing/CANONICAL_POLICY.json',
        'scripts/validate_archive_index.py',
    }
    if not needed.issubset(set(check.get('validates', []))):
        missing = sorted(needed - set(check.get('validates', [])))
        fail(f'archive-index-check validates missing surfaces: {missing}')
    md = (ROOT / 'VALIDATION_INDEX.md').read_text(encoding='utf-8')
    if '`make archive-index-check`' not in md or 'scripts/validate_archive_index.py' not in md:
        fail('VALIDATION_INDEX.md missing archive-index-check coverage')

    for comp_name in ('gate', 'publish-audit'):
        comp = next((c for c in validation.get('composite_targets', []) if c.get('make_target') == comp_name), None)
        if comp is None or 'archive-index-check' not in comp.get('includes', []):
            fail(f'VALIDATION_INDEX.json {comp_name} composite missing archive-index-check')

    control = load_json('CONTROL_SURFACES.json')
    validation_paths = {item['path'] for item in control['surfaces']['validation_and_packaging']}
    bundle_paths = {item['path'] for item in control['surfaces']['bundle_identity']}
    if 'scripts/validate_archive_index.py' not in validation_paths:
        fail('CONTROL_SURFACES.json validation_and_packaging missing archive-index validator')
    if not {'ARCHIVE_INDEX.md', 'ARCHIVE_INDEX.json'}.issubset(bundle_paths):
        fail('CONTROL_SURFACES.json bundle_identity missing ARCHIVE_INDEX companions')

    gates = load_json('LIFECYCLE_GATES.json')
    for gate_id in ('cold_open_and_reentry', 'careful_revision_pass', 'publish_audit', 'named_bundle_packaging'):
        if 'scripts/validate_archive_index.py' not in set(gates['gates'][gate_id].get('checks', [])):
            fail(f'LIFECYCLE_GATES.json {gate_id} missing archive-index validator')

    anchors = load_json('REVISION_ANCHORS.json')
    if 'scripts/validate_archive_index.py' not in set(anchors.get('validators', [])):
        fail('REVISION_ANCHORS.json validators missing archive-index validator')
    anchored = {item['path'] for item in anchors.get('anchored_surfaces', [])}
    if 'ARCHIVE_INDEX.json' not in anchored:
        fail('REVISION_ANCHORS.json anchored surfaces missing ARCHIVE_INDEX.json')

    for rel in ('scripts/gate.py', 'scripts/publish_audit.py', 'scripts/package_release.py'):
        if 'validate_archive_index.py' not in (ROOT / rel).read_text(encoding='utf-8'):
            fail(f'{rel} missing archive-index validator')
    makefile = (ROOT / 'Makefile').read_text(encoding='utf-8')
    if 'archive-index-check:' not in makefile or '$(PYTHON) scripts/validate_archive_index.py' not in makefile:
        fail('Makefile missing archive-index-check target')

    # The archive-index companion validator is persistent across later revisions.
    # Only the revision that materially introduced or reran the archive-index
    # companion audit needs an archive_index_companion_inventory_* witness.
    # Later revisions must still name the archive index surfaces in the current
    # changelog entry, but their current audit witness may belong to another
    # bounded lane and is governed by scripts/validate_audit_witnesses.py.
    top_changelog = (ROOT / 'CHANGELOG.md').read_text(encoding='utf-8').split('\n## ', 2)[1]
    if 'ARCHIVE_INDEX.md' not in top_changelog and 'ARCHIVE_INDEX.*' not in top_changelog:
        fail('CHANGELOG.md top section missing archive-index surface mention')


def main() -> None:
    release = load_json('RELEASE_MANIFEST.json')
    receipt = load_json('REVISION_RECEIPT.json')
    index = load_json('ARCHIVE_INDEX.json')
    schema = load_json('schemas/archive_bundle_index.schema.json')
    validate_against_schema(index, schema, 'ARCHIVE_INDEX.json')
    if release['revision'] != receipt['revision']:
        fail('release manifest and revision receipt revision mismatch')
    validate_json_index(index, release, receipt)
    validate_markdown_mirror(index, release)
    validate_wiring(release['revision'])
    recent = sum(1 for entry in index['bundles'] if revision_number(entry['revision']) >= RECENT_BUNDLE_FLOOR)
    print(f'archive-index-validate: OK ({len(index["bundles"])} bundle rows mirrored, {recent} recent rows checked)')


if __name__ == '__main__':
    main()
