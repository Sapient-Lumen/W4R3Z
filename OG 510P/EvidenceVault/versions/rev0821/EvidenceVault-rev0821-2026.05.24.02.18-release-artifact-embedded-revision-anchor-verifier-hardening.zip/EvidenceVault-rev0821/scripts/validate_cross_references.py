#!/usr/bin/env python3
"""Validate governed cross-reference surfaces resolve to shipped paths.

This check is intentionally narrower than a full prose link checker.  It audits
machine-readable restart/control/frontier/validation surfaces whose path fields
are meant to be operator guidance.  A stale path in those surfaces can make a
cold-open or release pass misleading even when payload validators still pass.
"""
from __future__ import annotations

import json
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Iterable

ROOT = Path(__file__).resolve().parents[1]

PATH_SUFFIXES = (
    '.csv',
    '.json',
    '.jsonl',
    '.md',
    '.pdf',
    '.paths',
    '.py',
    '.sha256',
    '.sh',
    '.tex',
    '.zip',
)
PROVENANCE_PREFIXES = ('AL-', 'ADR-', 'RFC-', 'FR-')


def fail(msg: str) -> None:
    print(f'cross-reference-validate: FAIL: {msg}', file=sys.stderr)
    sys.exit(1)


def load_json(rel: str) -> object:
    try:
        return json.loads((ROOT / rel).read_text(encoding='utf-8'))
    except Exception as exc:  # pragma: no cover - deliberate diagnostic wrapper
        fail(f'could not load {rel}: {exc}')


def add(refs: dict[str, set[str]], source: str, rel: object) -> None:
    if not isinstance(rel, str):
        return
    rel = rel.strip()
    if not rel:
        return
    refs[rel].add(source)


def add_many(refs: dict[str, set[str]], source: str, values: Iterable[object]) -> None:
    for value in values:
        add(refs, source, value)


def pathish(value: str) -> bool:
    if value.startswith(PROVENANCE_PREFIXES):
        return False
    if ' ' in value or '\n' in value or '\t' in value:
        return False
    return '/' in value or value.endswith(PATH_SUFFIXES)


def collect_pathish_strings(obj: object, source: str, refs: dict[str, set[str]]) -> None:
    if isinstance(obj, dict):
        for value in obj.values():
            collect_pathish_strings(value, source, refs)
    elif isinstance(obj, list):
        for value in obj:
            collect_pathish_strings(value, source, refs)
    elif isinstance(obj, str) and pathish(obj):
        add(refs, source, obj)


def collect() -> dict[str, set[str]]:
    refs: dict[str, set[str]] = defaultdict(set)

    control = load_json('CONTROL_SURFACES.json')
    for section, items in control.get('surfaces', {}).items():  # type: ignore[union-attr]
        for idx, item in enumerate(items):
            add(refs, f'CONTROL_SURFACES.json:{section}[{idx}].path', item.get('path'))

    lifecycle = load_json('LIFECYCLE_GATES.json')
    for gate, spec in lifecycle.get('gates', {}).items():  # type: ignore[union-attr]
        for field in ('authoritative_sequence', 'checks', 'required_records', 'required_surfaces'):
            add_many(refs, f'LIFECYCLE_GATES.json:{gate}.{field}', spec.get(field, []))

    opening = load_json('OPENING_CONTRACT.json')
    add_many(refs, 'OPENING_CONTRACT.json:cold_open_minimum', opening.get('cold_open_minimum', []))  # type: ignore[union-attr]
    for idx, profile in enumerate(opening.get('profiles', [])):  # type: ignore[union-attr]
        add(refs, f'OPENING_CONTRACT.json:profiles[{idx}].start', profile.get('start'))
        add_many(refs, f'OPENING_CONTRACT.json:profiles[{idx}].sequence', profile.get('sequence', []))
    for idx, entry in enumerate(opening.get('entrypoints', [])):  # type: ignore[union-attr]
        add(refs, f'OPENING_CONTRACT.json:entrypoints[{idx}].path', entry.get('path'))

    conformance = load_json('OPENING_SURFACE_CONFORMANCE.json')
    for field in (
        'required_root_entrypoints',
        'start_here_must_reference',
        'readme_start_here_must_reference',
        'agents_read_first_sequence',
    ):
        add_many(refs, f'OPENING_SURFACE_CONFORMANCE.json:{field}', conformance.get(field, []))  # type: ignore[union-attr]
    add(refs, 'OPENING_SURFACE_CONFORMANCE.json:revision_receipt_history_anchor', conformance.get('revision_receipt_history_anchor'))  # type: ignore[union-attr]
    add(refs, 'OPENING_SURFACE_CONFORMANCE.json:policy_reference', conformance.get('policy_reference'))  # type: ignore[union-attr]

    frontier = load_json('CURRENT_FRONTIER.json')
    for idx, lane in enumerate(frontier.get('lanes', [])):  # type: ignore[union-attr]
        add_many(refs, f'CURRENT_FRONTIER.json:lanes[{idx}].linked_surfaces', lane.get('linked_surfaces', []))

    context = load_json('CONTEXT_PACK.json')
    add_many(refs, 'CONTEXT_PACK.json:read_order', context.get('read_order', []))  # type: ignore[union-attr]
    add_many(refs, 'CONTEXT_PACK.json:paper_order', context.get('paper_order', []))  # type: ignore[union-attr]
    for section in ('canonical_surfaces', 'key_machine_surfaces', 'support_surfaces'):
        values = context.get(section, {})  # type: ignore[union-attr]
        if isinstance(values, dict):
            for key, value in values.items():
                add(refs, f'CONTEXT_PACK.json:{section}.{key}', value)

    validation = load_json('VALIDATION_INDEX.json')
    for idx, check in enumerate(validation.get('checks', [])):  # type: ignore[union-attr]
        for field in ('scripts', 'validates', 'outputs'):
            add_many(refs, f'VALIDATION_INDEX.json:checks[{idx}].{field}', check.get(field, []))
    for idx, artifact in enumerate(validation.get('generated_artifacts', [])):  # type: ignore[union-attr]
        add(refs, f'VALIDATION_INDEX.json:generated_artifacts[{idx}].path', artifact.get('path'))

    anchors = load_json('REVISION_ANCHORS.json')
    for idx, surface in enumerate(anchors.get('anchored_surfaces', [])):  # type: ignore[union-attr]
        add(refs, f'REVISION_ANCHORS.json:anchored_surfaces[{idx}].path', surface.get('path'))
    add_many(refs, 'REVISION_ANCHORS.json:validators', anchors.get('validators', []))  # type: ignore[union-attr]

    release = load_json('RELEASE_MANIFEST.json')
    add_many(refs, 'RELEASE_MANIFEST.json:included_roots', release.get('included_roots', []))  # type: ignore[union-attr]
    for field in (
        'history_anchor',
        'revision_receipt',
        'opening_contract',
        'archive_index_markdown',
        'archive_index_json',
        'inventory',
        'agent_contract',
        'command_surface',
        'adr_index_markdown',
        'adr_index_json',
        'revision_anchors',
        'rfc_index_markdown',
        'rfc_index_json',
        'validation_index_markdown',
        'validation_index_json',
        'source_index_markdown',
        'source_index_json',
        'current_frontier_markdown',
        'current_frontier_json',
        'claim_obligation_map_markdown',
        'claim_obligation_map_json',
        'public_status_markdown',
        'public_status_json',
        'release_manifest_schema',
        'archive_identity_validator',
        'ro_crate_metadata_json',
        'ro_crate_profile_markdown',
        'ro_crate_metadata_schema',
        'ro_crate_metadata_validator',
        'release_artifact_verifier',
        'release_artifact_verifier_validator',
    ):
        add(refs, f'RELEASE_MANIFEST.json:{field}', release.get(field))  # type: ignore[union-attr]

    receipt = load_json('REVISION_RECEIPT.json')
    add_many(refs, 'REVISION_RECEIPT.json:touched_surfaces', receipt.get('touched_surfaces', []))  # type: ignore[union-attr]
    add(refs, 'REVISION_RECEIPT.json:history_anchor', receipt.get('history_anchor'))  # type: ignore[union-attr]

    assimilation = load_json('ASSIMILATION_LEDGER.json')
    for idx, entry in enumerate(assimilation.get('entries', [])):  # type: ignore[union-attr]
        add_many(refs, f'ASSIMILATION_LEDGER.json:entries[{idx}].implementation_surfaces', entry.get('implementation_surfaces', []))

    for index_rel in ('ADR_INDEX.json', 'RFC_INDEX.json'):
        index = load_json(index_rel)
        for idx, entry in enumerate(index.get('entries', [])):  # type: ignore[union-attr]
            add(refs, f'{index_rel}:entries[{idx}].path', entry.get('path'))
            add_many(refs, f'{index_rel}:entries[{idx}].links', entry.get('links', []))

    collect_pathish_strings(load_json('publishing/CANONICAL_POLICY.json'), 'publishing/CANONICAL_POLICY.json', refs)
    return refs


def is_allowed_external(rel: str, release: dict) -> bool:
    # The named package is deliberately emitted next to the archive root, not
    # inside it, but validation/package surfaces still need to name it.
    bundle = release.get('bundle')
    return rel == bundle or rel == f'{bundle}.sha256'


def validate_reference(rel: str, sources: set[str], release: dict) -> None:
    if rel.startswith('/') or '\\' in rel or '..' in Path(rel).parts:
        fail(f'unsafe relative reference {rel!r} from {sorted(sources)!r}')
    if is_allowed_external(rel, release):
        return
    path = ROOT / rel.rstrip('/')
    if rel.endswith('/'):
        if not path.is_dir():
            fail(f'reference expects missing directory {rel!r} from {sorted(sources)!r}')
        return
    if not path.exists():
        fail(f'reference points to missing path {rel!r} from {sorted(sources)!r}')


def main() -> None:
    release = load_json('RELEASE_MANIFEST.json')
    if not isinstance(release, dict):
        fail('RELEASE_MANIFEST.json must be an object')
    refs = collect()

    anchors = load_json('REVISION_ANCHORS.json')
    root_dir = anchors.get('current_revision', {}).get('root_dir')  # type: ignore[union-attr]
    if root_dir != ROOT.name:
        fail(f'REVISION_ANCHORS.json root_dir {root_dir!r} does not match extracted root {ROOT.name!r}')
    if release.get('repo_root') != ROOT.name:
        fail(f'RELEASE_MANIFEST.json repo_root {release.get("repo_root")!r} does not match extracted root {ROOT.name!r}')

    for rel, sources in sorted(refs.items()):
        validate_reference(rel, sources, release)

    print(f'cross-reference-validate: OK ({len(refs)} governed path references resolved)')


if __name__ == '__main__':
    main()
