#!/usr/bin/env python3
"""Validate canonical text-surface hygiene for governed archive surfaces.

This is deliberately narrower than validate_text_payloads.py.  Retained source
payloads may preserve upstream formatting, but EvidenceVault's governing,
generated, and operator-facing text surfaces should be byte-stable UTF-8 with LF
line endings so diffs, manifests, and deterministic packaging remain portable.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEXT_SUFFIXES = {
    '.md',
    '.txt',
    '.json',
    '.yaml',
    '.yml',
    '.csv',
    '.py',
    '.sh',
    '.tex',
    '.bib',
    '.paths',
    '.sha256',
}
ROOT_TEXT_NAMES = {'Makefile'}
GOVERNED_DIRS = {
    'AUDIT',
    'INDEX',
    'adrs',
    'rfcs',
    'papers',
    'published',
    'publishing',
    'release_queue',
    'scripts',
}
EXTRA_GOVERNED = {
    'artifacts/ARTIFACTS_INDEX.json',
    'artifacts/ARTIFACTS_INDEX.csv',
    'certs/CERTS_INDEX.json',
    'certs/CERTS_INDEX.csv',
}


def fail(msg: str) -> None:
    print(f'text-surface-policy-validate: FAIL: {msg}', file=sys.stderr)
    sys.exit(1)


def rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def is_text_surface(path: Path) -> bool:
    r = rel(path)
    if r in EXTRA_GOVERNED:
        return True
    if path.name in ROOT_TEXT_NAMES and path.parent == ROOT:
        return True
    if path.suffix.lower() not in TEXT_SUFFIXES:
        return False
    parts = Path(r).parts
    if len(parts) == 1:
        return True
    return parts[0] in GOVERNED_DIRS


def validate_file(path: Path) -> None:
    r = rel(path)
    data = path.read_bytes()
    if not data:
        fail(f'governed text surface is empty: {r}')
    if data.startswith(b'\xef\xbb\xbf'):
        fail(f'UTF-8 BOM is not allowed in governed text surface: {r}')
    if b'\r' in data:
        fail(f'CR/CRLF line ending is not allowed in governed text surface: {r}')
    try:
        text = data.decode('utf-8')
    except UnicodeDecodeError as exc:
        fail(f'governed text surface is not UTF-8: {r}: {exc}')
    if not data.endswith(b'\n'):
        fail(f'governed text surface must end with a single LF newline: {r}')
    if data.endswith(b'\n\n') and r not in {'CHANGELOG.md'}:
        fail(f'governed text surface has multiple terminal blank lines: {r}')
    for lineno, line in enumerate(text.split('\n')[:-1], start=1):
        if line.rstrip(' \t') != line:
            fail(f'trailing whitespace in governed text surface: {r}:{lineno}')


def iter_files_sorted(root: Path):
    """Yield files in deterministic path order without materializing the tree.

    The archive has grown enough that sorted(ROOT.rglob('*')) can be an
    unnecessary memory spike inside composite gate runners after heavier
    validators.  A sorted os.walk stream preserves deterministic traversal while
    avoiding a whole-tree Path list.
    """
    import os

    for dirpath, dirnames, filenames in os.walk(root):
        dirnames.sort()
        for filename in sorted(filenames):
            yield Path(dirpath) / filename


def main() -> None:
    checked = 0
    for path in iter_files_sorted(ROOT):
        if not is_text_surface(path):
            continue
        validate_file(path)
        checked += 1
    if checked == 0:
        fail('no governed text surfaces were checked')
    print(f'text-surface-policy-validate: OK ({checked} governed UTF-8/LF text surfaces)')


if __name__ == '__main__':
    main()
