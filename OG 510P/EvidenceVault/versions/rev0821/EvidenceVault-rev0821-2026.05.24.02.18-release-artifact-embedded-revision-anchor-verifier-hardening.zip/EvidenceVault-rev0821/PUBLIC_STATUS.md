# Public/internal status bridge

This file is the exact human-facing companion to `PUBLIC_STATUS.json`.
It records the relationship between the latest governed public release and the current internal archive revision without widening the public payload surface.

- Revision: `rev0821`
- Previous revision: `rev0820`
- Generated: `2026-05-24T02:18:00-0400`
- Scope: `public-internal-status-bridge`
- Validator: `scripts/validate_public_status.py`

## Current internal archive

- Revision: `rev0821`
- Previous revision: `rev0820`
- Date: `2026-05-24`
- Timestamp: `2026.05.24.02.18`
- Bundle: `EvidenceVault-rev0821-2026.05.24.02.18-release-artifact-embedded-revision-anchor-verifier-hardening.zip`
- Archive name: `EvidenceVault-rev0821-2026.05.24.02.18-release-artifact-embedded-revision-anchor-verifier-hardening`
- Root directory: `EvidenceVault-rev0821`

## Latest public release

- Release ID: `EV-PUB-2026-03-20-public-surface-bootstrap`
- Date: `2026-03-20`
- Status: `published`
- Revision: `rev0484`
- Decision: `EV-REL-2026-03-20-public-surface-bootstrap`
- Queue item: `EV-QUEUE-2026-03-20-public-surface-bootstrap`
- Notes: `published/releases/2026-03-20-public-surface-bootstrap.md`
- Artifact manifest: `published/releases/artifacts/EV-PUB-2026-03-20-public-surface-bootstrap.bundle.json`
- Artifact ZIP: `published/releases/artifacts/EV-PUB-2026-03-20-public-surface-bootstrap.zip`
- Public surface manifest: `published/PUBLIC_SURFACE.json`
- Public surface manifest SHA-256: `04f8aebf31f45649629c29686cf421081c93513373db253abff9541841287581`
- Public surface snapshot: `published/releases/snapshots/EV-PUB-2026-03-20-public-surface-bootstrap.surface.json`
- Public surface snapshot SHA-256: `608858ad6127d44c973ad3a13c20d0a72afe03b686379aa5162152c540dcc83c`

## Relationship

- Current internal revision: `rev0821`
- Latest public revision: `rev0484`
- Internal revision delta: `337`
- Latest public release pointer is latest: `true`
- Public surface state: Latest public release remains the 2026-03-20 public-surface bootstrap while internal archive hardening continues through rev0821 without public payload widening.
- Public payload widened: `false`
- Queue state changed: `false`
- Canonical paper/source payload changed: `false`
- Status bridge surface: `PUBLIC_STATUS.json`, `PUBLIC_STATUS.md`

## Boundary

This bridge reports the status relationship between public release ledgers and the current internal archive. It is not itself a public-release decision, public payload expansion, or release-queue transition.

## Supporting surfaces

- `published/PUBLIC_SURFACE.json`
- `published/releases/LATEST.json`
- `published/releases/RELEASE_INDEX.json`
- `published/releases/artifacts/ARTIFACT_INDEX.json`
- `release_queue/QUEUE_INDEX.json`
- `publishing/CANONICAL_POLICY.json`
- `RELEASE_MANIFEST.json`
- `REVISION_RECEIPT.json`
- `REVISION_ANCHORS.json`
- `VALIDATION_INDEX.json`
- `CONTROL_SURFACES.json`
- `LIFECYCLE_GATES.json`
- `CONTEXT_PACK.json`
- `CURRENT_FRONTIER.json`
- `CLAIM_OBLIGATION_MAP.json`
- `ro-crate-metadata.json`
- `RO_CRATE_PROFILE.md`
- `scripts/validate_ro_crate_metadata.py`
- `COMMAND_RUNNER_SEQUENCE.json`
- `COMMAND_RUNNER_SEQUENCE.md`
- `schemas/release_manifest.schema.json`
- `scripts/validate_archive_identity.py`
- `schemas/ro_crate_metadata.schema.json`
- `scripts/verify_release_artifact.py`
- `AUDIT/release_artifact_inclusion_fence_verifier_inventory_rev0818.md`
- `AUDIT/release_artifact_embedded_revision_anchor_verifier_inventory_rev0821.md`
