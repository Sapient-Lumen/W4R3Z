# EvidenceVault: start here (for maintainers, including LLMs)

EvidenceVault already has a tight canon. A good pass usually sharpens boundaries, provenance, startup/reentry discipline, or release governance; it does not widen scope.

## Non-negotiables
- **Do not move canon ownership.** `SERIES.md` owns architecture and reading order; `PUBLISHING.md` owns public-release workflow; `PAPER_SERIES_INDEX.md` owns only titles/layer placement; `CATALOG.md` owns only archive lookup; `papers/EXTRACTION_MAP.json` owns present-state provenance; `CHANGELOG.md` owns revision history.
- **Do not casually widen the public surface.** `published/` is a small stable frontage, not a mirror of the working archive.
- **Do not let folder motion replace explanation.** Queue state should always be backed by paired written/machine-readable decisions.
- **Do not spread revision identity gratuitously.** Revision identity still lives primarily in the archive filename and the top entry of `CHANGELOG.md`; `RELEASE_MANIFEST.json` preserves the exact packaged bundle identity inside the extracted archive, `REVISION_ANCHORS.json` is the compact cross-check for current revision-bearing surfaces, `REVISION_RECEIPT.json` records the packaged delta, `ASSIMILATION_LEDGER.*` records adopted/rejected/deferred outside-pattern decisions across revisions, `ADR_INDEX.*` records standing architecture decisions that should survive multiple revision receipts, `RFC_INDEX.*` records bounded unresolved structural proposals that are worth preserving without prematurely promoting them to ADRs, `CURRENT_FRONTIER.*` records the current live priority/open-pressure summary for repeated comparison-driven passes, `AGENTS.md` is a derivative operating contract, `Makefile` is a derivative command wrapper, `VALIDATION_INDEX.*` is a governed assurance/command inventory, `CLAIM_OBLIGATION_MAP.*` is a derivative claim-to-obligation crosswalk, `SOURCE_INDEX.*` is a governed retained-source and family-representation map, and other metadata surfaces should stay revisionless unless they truly govern packaging or standing architectural memory.
- **Do not mistake crosswalks, ADRs, or RFCs for canon.** `CONTROL_SURFACES.json` and `LIFECYCLE_GATES.json` are derivative authority/lifecycle maps, `CLAIM_OBLIGATION_MAP.*` is a derivative claim-support map, `ADR_INDEX.*` is standing-decision memory, and `RFC_INDEX.*` is bounded unresolved-proposal memory; they are there to help find the right surface quickly and remember settled or still-open structure, not to replace `SERIES.md`, `PUBLISHING.md`, or `CHANGELOG.md`.
- **Do not silently rewrite carried-forward audit witnesses.** Some audit documents preserve earlier audit-batch labels because the underlying audit basis predates the current revision; see `AUDIT/README.md` before “fixing” those labels.

## Read first
1. `README.md`
2. `OPENING_CONTRACT.json`
3. `SERIES.md`
4. `PUBLISHING.md`
5. `publishing/OPERATOR_STARTUP.md`
6. `publishing/CANONICAL_POLICY.json`
7. `CONTROL_SURFACES.json`
8. `LIFECYCLE_GATES.json`
9. `VALIDATION_INDEX.md`
10. `CLAIM_OBLIGATION_MAP.md`
11. `ADR_INDEX.md`
12. `RFC_INDEX.md`
13. `CURRENT_FRONTIER.md`
14. `CATALOG.md`
15. `SOURCE_INDEX.md`
16. `PAPER_SERIES_INDEX.md`
17. `papers/EXTRACTION_MAP.json`
18. `published/README.md`
19. `release_queue/README.md`
20. `AUDIT/README.md`
21. `CONTEXT_PACK.json`
22. `REVISION_RECEIPT.json`
23. `ASSIMILATION_LEDGER.md`
24. `RELEASE_MANIFEST.json`
25. `REVISION_ANCHORS.json`
26. `ARCHIVE_INDEX.md`

## Fast checks
```bash
make gate
```

Expanded form:
```bash
python3 scripts/validate_opening_surface.py
python3 scripts/validate_source_index.py
python3 scripts/validate_adrs.py
python3 scripts/validate_rfcs.py
python3 scripts/validate_current_frontier.py
python3 scripts/validate_assimilation_ledger.py
python3 scripts/validate_revision_anchors.py
python3 scripts/validate_control_surfaces.py
python3 scripts/validate_validation_index.py
python3 scripts/validate_claim_obligation_map.py
python3 scripts/validate_archive_identity.py
python3 scripts/validate_provenance_ledgers.py
python3 scripts/rebuild_indexes.py
python3 scripts/validate_publishing.py
bash scripts/publish_preflight.sh
```

Use `VALIDATION_INDEX.json` when you need the machine-readable assurance map.

Use `make provenance-check` when upstream input, omission, redaction, or pruning ledgers changed, `make source-check` when retained-source or family-representation surfaces changed, `make rfc-check` when bounded unresolved-proposal surfaces changed, `make frontier-check` when current live-priority/open-pressure surfaces changed, `make assimilation-check` when comparison-memory surfaces changed, `make validation-check` when assurance/command inventory surfaces changed, `make claim-obligation-check` when claim-support crosswalk surfaces changed, `make runner-check` when composite command runners changed, `make publish-audit` when the release path changed, and `make preflight` before claiming a shipping posture. Only run `make build-papers` when paper sources changed.

## What a good revision looks like
A good revision usually does at least one of these:
- tightens a paper/bridge/family ownership seam without widening claims,
- improves lookup, provenance, or startup/reentry discipline without changing canon ownership,
- hardens release/public-surface governance without mirroring the full archive,
- clarifies audit or retention boundaries without pretending historical witnesses were generated later than they were,
- or emits one compact revision receipt when the packaged delta would otherwise have to be reconstructed indirectly from prose history.
- or tightens current revision-anchor coherence so control/bundle surfaces stop drifting from the actual packaged revision.
- or preserves cross-revision memory about which outside patterns were adopted, rejected, or deferred so future comparison-driven passes stop re-litigating the same imports from scratch.
- or promotes a now-stable structural boundary into `ADR_INDEX.*` and `adrs/` so future passes do not recover it only from receipts, changelog entries, and helper-surface prose.
- or tightens bundle self-identity so an extracted revision still knows its exact packaged name and recent lineage without depending on the surrounding filesystem.
- or sharpens the authority/lifecycle crosswalk so future careful passes can tell which surface governs a claim and which gate must pass before a change is treated as real.
- or sharpens the validation/assurance inventory so future passes can tell which check proves what and which builder refreshes which governed artifact without reconstructing that map from scattered script names.
- or sharpens `CLAIM_OBLIGATION_MAP.*` so future reviewers can see which selected claims are supported by which archive surfaces, validators, and negative-regression expectations without mistaking the map for canon.
- or sharpens retained-source lookup so future passes can tell which canonical papers consume which retained source roots and which family lines are represented only through curated artifacts, certs, or legacy renders.
- or preserves one compact current frontier so future comparison-driven passes can resume from live pressure and deferred lanes without mistaking them for settled architecture.

## Watchpoints
- `OPENING_CONTRACT.json` is the machine-readable startup contract; `OPENING_SURFACE_CONFORMANCE.json` is the small checklist that keeps `START_HERE.md`, `README.md`, `AGENTS.md`, `Makefile`, `CONTEXT_PACK.json`, `REVISION_RECEIPT.json`, `REVISION_ANCHORS.json`, and the bundle-identity surfaces aligned with it.
- `CONTROL_SURFACES.json` tells you which surface owns which kind of statement; `LIFECYCLE_GATES.json` tells you where startup, revision, comparison-assimilation, release, and bundle-packaging checks are expected to bite; `VALIDATION_INDEX.*` tells you which specific target/script proves which surface and which builder refreshes which governed artifact; `CLAIM_OBLIGATION_MAP.*` tells you which selected claims are mapped to concrete obligations and known limits; `SOURCE_INDEX.*` tells you which retained source roots feed which canonical papers and which families are represented without a full retained `sources/` root.
- Public release records may keep the live `published/PUBLIC_SURFACE.json` path for operator convenience, but the immutable historical authority is the paired snapshot plus the stored manifest/snapshot digests.
- `release_queue/published/` is execution history, not a second public surface.
- `AUDIT/`, `UPSTREAM*.md`, `DEDUPE_REPORT.md`, `MIGRATION_AUDIT.md`, and `PRUNED_TRANSIENT.paths` are retained audit/retention witnesses; they are not architecture statements.
- `ASSIMILATION_LEDGER.*` should carry adopted, rejected, and deferred outside-pattern decisions so future comparison-driven passes do not have to reconstruct them only from receipts/changelog entries.
- `CURRENT_FRONTIER.*` should stay bounded and live; use it for what is currently active, deferred, or being watched, not for settled policy or architectural memory.
- `RFC_INDEX.*` plus `rfcs/` should carry any unresolved structural proposal that deserves more detail than a one-line deferred ledger record but is still too unsettled for ADR status.
- `ADR_INDEX.*` should carry durable architecture decisions that outlive one packaged delta, while `REVISION_RECEIPT.json` stays focused on the current revision.
- `RELEASE_MANIFEST.json` should preserve the exact external bundle identity inside the extracted archive, `REVISION_ANCHORS.json` should keep current revision-bearing surfaces aligned, and `ARCHIVE_INDEX.*` should summarize recent named bundle lineage without replacing `CHANGELOG.md`.

## Scoped asset index check

Before packaging, run `make asset-indexes` and `make asset-check` so `artifacts/ARTIFACTS_INDEX.*`, `certs/CERTS_INDEX.*`, and curated `CANONICAL_PATHS.json` dedupe pointers describe the shipped payload exactly.

## Command-runner sequence contract

`COMMAND_RUNNER_SEQUENCE.json` and its exact `COMMAND_RUNNER_SEQUENCE.md` companion now govern composite runner order for `gate`, `publish-audit`, package refresh, and package-final validation. `scripts/validate_command_runners.py` rejects drift between the contract and the runner scripts.
