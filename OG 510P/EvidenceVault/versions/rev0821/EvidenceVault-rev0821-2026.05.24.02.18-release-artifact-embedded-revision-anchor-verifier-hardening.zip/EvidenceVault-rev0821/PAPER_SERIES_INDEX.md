# EvidenceVault paper series index

This file records only paper titles and layer placement.
`SERIES.md` owns the full architecture and reading order.

## Layer 0 — Spine / entry paper
| file | title |
|---|---|
| `ev_acceptability_kernel.tex` | EvidenceVault: Portable Acceptability, Replay Kernel, and Receipt Algebra |

## Layer 1 — Interpretation bridge
| file | title |
|---|---|
| `ev_interpretation_profiles.tex` | EvidenceVault: Interpretation Profiles, Governed Replay, and Accountable Replay Projection |

## Layer 2 — Mechanism families
| family | file | title |
|---|---|---|
| StreamFold / dOCF | `ev_streamfold.tex` | EvidenceVault: StreamFold / dOCF: Run Manifests and Authenticated Run Views |
| zk-RTP | `ev_zkrtp.tex` | EvidenceVault: zk-RTP: Evidence Packages and Support Manifests |
| PACT / OCF | `ev_pact_ocf.tex` | EvidenceVault: PACT / OCF: Decision Packages |

Editorial boundary: `SERIES.md` owns architecture and reading order; this file keeps only titles and layer placement.


For public onboarding rather than title lookup, use `published/index.md` and `published/reader_guide.md`.
