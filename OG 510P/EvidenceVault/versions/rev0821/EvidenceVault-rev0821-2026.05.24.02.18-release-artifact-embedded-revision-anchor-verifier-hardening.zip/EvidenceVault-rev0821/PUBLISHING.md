# EvidenceVault publishing

This file owns the public-release workflow only.
It does not restate series architecture; `SERIES.md` remains the sole architecture and reading-order statement.

## Canonical publishing split
- `published/` — stable public surface and public-facing entry points only.
- `release_queue/candidates/` — materials being considered for publication.
- `release_queue/hold/` — materials intentionally not being published yet.
- `release_queue/published_ready/` — items that passed review and preflight and are ready to ship.
- `release_queue/published/` — queue items that have already been issued as public releases.
- `release_queue/decisions/` — concise written release decisions in paired `.md` and `.json` form.
- `release_queue/QUEUE_INDEX.json` — machine-readable ledger of queue items by state.
- `published/PUBLIC_SURFACE.json` — machine-readable description of the stable public surface.
- `publishing/OPERATOR_STARTUP.md` — operator checklist for a release pass.
- `publishing/CANONICAL_POLICY.json` — machine-readable publishing policy.
- `CONTROL_SURFACES.json` — machine-readable authority/control-surface crosswalk.
- `LIFECYCLE_GATES.json` — machine-readable lifecycle-gate crosswalk.
- `ADR_INDEX.*` — standing architecture decisions that explain structural publishing boundaries without turning queue records into pseudo-canon.
- `AGENTS.md` — compact derivative repo contract for future careful passes.
- `Makefile` — compact command wrapper for validation, publish-audit, and package flows.
- `publishing/templates/release_decision.md` — release-decision template.
- `scripts/validate_publishing.py` — publishing-state validator, including exact queue-item/public-release-note Markdown/JSON companion checks and helper CLI entrypoint smoke tests.
- `scripts/validate_archive_identity.py` — bundle-identity / archive-lineage validator.
- `scripts/package_release.py` — write the root release manifest and package one named archive bundle.
- `scripts/publish_preflight.sh` — release preflight checks.
- `published/releases/RELEASE_INDEX.json` — machine-readable ledger of public releases.
- `published/releases/LATEST.json` — pointer to the latest public release.
- `published/releases/artifacts/ARTIFACT_INDEX.json` — machine-readable ledger of materialized public release bundles.
- `publishing/templates/public_release.md` — public release-note template.
- `scripts/build_release_ledger.py` — generator for the public release ledger.
- `scripts/materialize_public_release.py` — materializer for deterministic public release bundles with portable regular-file ZIP metadata.
- `scripts/build_release_queue_index.py` — generator for the release-queue state index.
- `scripts/scaffold_queue_item.py` — scaffold a paired queue-item `.md` and `.json` record.
- `scripts/transition_queue_item.py` — move a queue item between queue states and regenerate its machine-readable and Markdown companions.
- `scripts/publish_queue_item.py` — promote one published-ready queue item into a public release, freeze a public-surface snapshot, emit the canonical public-release note companion, and move the item into `release_queue/published/`.

## Public-release posture
- Publish from a small stable surface, not directly from the whole working archive.
- Treat `no release` and `hold` as normal outcomes.
- Keep paper canon, archive canon, and public-release decisions distinct.
- Prefer written release decisions over implicit folder motion.

## Minimal release flow
1. Read `publishing/OPERATOR_STARTUP.md`.
2. Place candidate materials under `release_queue/candidates/`, preferably by scaffolding a paired queue item.
3. Record the decision in `release_queue/decisions/` using paired `.md` and `.json` files.
4. Move the queue item into `release_queue/hold/` or `release_queue/published_ready/` once the decision is written.
5. For a `publish` decision, either run `python3 scripts/publish_queue_item.py ...` or create/update the paired public release record under `published/releases/`, freeze a public-surface snapshot under `published/releases/snapshots/`, store the paired manifest/snapshot digests on the release record, and move the queue item into `release_queue/published/`.
6. Materialize the public release bundle from that record; the materializer should rebuild the deterministic ZIP and paired bundle manifest, mark ZIP members as regular files for portable extraction, and reconstruct the release-scoped `published/PUBLIC_SURFACE.json` from the immutable snapshot rather than trusting whatever the live manifest says later.
7. Run `make gate` first for the archive-wide check, then either `make publish-audit` for the bounded release-materialization/post-refresh wrapper, or the expanded release-specific form:
   ```bash
   make gate
   python3 scripts/build_release_queue_index.py
   python3 scripts/build_release_ledger.py
   python3 scripts/materialize_public_release.py
   python3 scripts/build_asset_indexes.py
   python3 scripts/build_dedupe_report.py
   python3 scripts/rebuild_indexes.py
   python3 scripts/validate_command_runners.py
   python3 scripts/validate_publishing.py
   bash scripts/publish_preflight.sh
   ```
8. Copy only the intended stable public-facing material into `published/` and list it in `published/PUBLIC_SURFACE.json`.
9. Rebuild the release queue index, public release ledger, and public release artifact index before shipping.

## Scope boundary
- Canonical single-file TeX papers remain under `papers/`.
- Archive lookup remains in `CATALOG.md`.
- Current extraction/consolidation provenance remains in `papers/EXTRACTION_MAP.json`.
- Revision history remains in `CHANGELOG.md`.

## Release records
- Every publish / hold / no-release decision should have one paired `release_queue/decisions/<id>.md` and `<id>.json`.
- Every actual public release should also have one paired `published/releases/<slug>.md` and `<slug>.json`, with the `.md` note rendered exactly from the JSON release record.
- Every actual public release should point back to one published queue item and one immutable public-surface snapshot under `published/releases/snapshots/`.
- Every actual public release should also carry the frozen public-surface manifest digest and snapshot digest so release history remains stable even if the live `published/PUBLIC_SURFACE.json` evolves later.
- Every actual public release should materialize one deterministic bundle plus one paired `.bundle.json` manifest under `published/releases/artifacts/`, with portable regular-file ZIP metadata and the release-scoped `published/PUBLIC_SURFACE.json` reconstructed from the snapshot.
- Markdown is for human explanation; JSON is for machine validation and release-state tooling; queue-item Markdown and public release-note Markdown are checked as exact renders of their adjacent JSON records, and the helper CLIs that create or move those records are smoke-tested by publishing validation.
- `published/PUBLIC_SURFACE.json` is the machine-readable record of what belongs on the stable public surface.
- `published/releases/RELEASE_INDEX.json` and `published/releases/LATEST.json` are the machine-readable records of what has actually been released.
- `published/releases/artifacts/ARTIFACT_INDEX.json` is the machine-readable record of the materialized public release bundles.

## Queue items
- Every staged candidate / hold / published-ready / published item should have one paired `.md` and `.json` record in its state directory, with the `.md` companion rendered from the JSON record.
- Queue items explain what is under review; decisions explain why the state is what it is.
- `release_queue/QUEUE_INDEX.json` is the machine-readable state summary across the four queue stages.
- `candidate` items may exist before a decision is written; `hold`, `published_ready`, and `published` items should point to a written decision.
- `published` items should also point to the public release they executed.


## Opening and resumption surfaces
- `OPENING_CONTRACT.json` is the machine-readable startup/reentry contract for this archive.
- `OPENING_SURFACE_CONFORMANCE.json` records the small root-level opening checklist that must stay aligned with `START_HERE.md`, `README.md`, `AGENTS.md`, `Makefile`, `CONTEXT_PACK.json`, `SOURCE_INDEX.*`, `ADR_INDEX.*`, `REVISION_RECEIPT.json`, and the bundle-identity surfaces.
- `CONTROL_SURFACES.json` is the machine-readable crosswalk of which surfaces govern which statements and witnesses.
- `SOURCE_INDEX.*` is the compact retained-source and family-representation map; use it when a release or archive change touches retained source roots, curated mirrors, or legacy-family representation boundaries.
- `LIFECYCLE_GATES.json` is the machine-readable crosswalk of which checks should fire during startup, revision passes, release execution, and bundle packaging.
- `REVISION_RECEIPT.json` is the compact machine-readable summary of the packaged revision delta; it complements but does not replace the prose lineage in `CHANGELOG.md`.
- `ADR_INDEX.*` records standing architecture decisions that should persist across many revision receipts without widening canon.
- `AGENTS.md` and `Makefile` are deliberate low-entropy wrappers over the opening/governance surfaces; they should stay derivative and should not become competing canon.
- `RELEASE_MANIFEST.json` preserves the exact packaged bundle identity inside the extracted archive, and `ARCHIVE_INDEX.*` preserves recent named bundle lineage without widening the canon or public surface.
- `SOURCE_INDEX.*` complements `CATALOG.md` by keeping one compact governed map of retained source roots, their paper consumers, and family lines represented without a full `sources/` root.


## Comparison-memory boundary
`ASSIMILATION_LEDGER.*` may mention publishing-related outside patterns or rejected widening pressures, but it does not replace `PUBLISHING.md`, queue decisions, or public-release records. It is a cross-revision memory surface for why certain publishing imports were adopted, rejected, or deferred.

`RFC_INDEX.*` and `rfcs/` may preserve a bounded unresolved publishing-side proposal when a deferred import deserves more than one ledger line, but they do not authorize workflow changes until a later revision actually lands them.

Validation/assurance note: use `VALIDATION_INDEX.md` when you need the shortest truthful map from check targets to governed surfaces and refreshed release/build artifacts; `make validation-check` verifies it as the exact rendered companion of `VALIDATION_INDEX.json`.


Note: `CURRENT_FRONTIER.*` may summarize live comparison pressure and deferred structural lanes for future archive passes, but it does not widen the public surface or change release authority.
