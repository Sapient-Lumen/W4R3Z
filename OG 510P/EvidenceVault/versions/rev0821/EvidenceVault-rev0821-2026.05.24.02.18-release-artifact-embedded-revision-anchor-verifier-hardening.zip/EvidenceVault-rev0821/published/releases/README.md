# EvidenceVault public releases

Use this directory for stable release notes or release pointers that are intended to remain public.
Keep it small.
Do not mirror the full working archive here.

Use paired `.md` and `.json` files for each public release.
`RELEASE_INDEX.json` is the machine-readable ledger of all public releases, and `LATEST.json` points to the latest one.
Materialized public release bundles live under `artifacts/`, with `ARTIFACT_INDEX.json` as their machine-readable ledger. The non-public staging queue stays under `release_queue/` in the working archive.

Each public release should also have one immutable snapshot in `snapshots/` recording the public surface that was in force when that release was issued. The release record carries paired public-surface manifest/snapshot digests so the historical release remains stable even if the live public surface changes later.
