# Public surface snapshots

This directory holds immutable release-scoped snapshots of `published/PUBLIC_SURFACE.json`.

Each snapshot records the full release-scoped public-surface contract that was in force when a specific public release was issued: manifest version, principles, canonical context, and digested entry points.
Use it when you need to answer not only what is public now, but what the public surface was for a given release, or when you need to reconstruct the historical `published/PUBLIC_SURFACE.json` for a deterministic bundle.
