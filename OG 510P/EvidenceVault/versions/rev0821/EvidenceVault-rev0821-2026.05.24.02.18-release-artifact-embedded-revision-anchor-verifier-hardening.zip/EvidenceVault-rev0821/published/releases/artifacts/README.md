# EvidenceVault public release artifacts

This directory holds materialized bundles for stable public releases.
Each published release may have:
- one deterministic `.zip` bundle built from the release record's `public_paths`, with any release-scoped `published/PUBLIC_SURFACE.json` reconstructed from the immutable snapshot,
- one paired `.bundle.json` manifest with file-level digests plus frozen public-surface manifest/snapshot digests, and
- one machine-readable `ARTIFACT_INDEX.json` summarizing the available public release artifacts.

These artifacts remain smaller than the full working archive.
They are release execution outputs, not a mirror of the repository root.
