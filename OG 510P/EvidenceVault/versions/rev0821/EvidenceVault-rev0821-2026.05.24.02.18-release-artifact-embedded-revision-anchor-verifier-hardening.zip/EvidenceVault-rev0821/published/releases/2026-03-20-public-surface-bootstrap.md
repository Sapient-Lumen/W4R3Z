# Public release

- Release ID: `EV-PUB-2026-03-20-public-surface-bootstrap`
- Date: `2026-03-20`
- Status: `published`
- Decision: `EV-REL-2026-03-20-public-surface-bootstrap`
- Queue item: `EV-QUEUE-2026-03-20-public-surface-bootstrap`
- Revision: `rev0484`
- Public surface manifest: `published/PUBLIC_SURFACE.json`
- Public surface manifest sha256: `04f8aebf31f45649629c29686cf421081c93513373db253abff9541841287581`
- Public surface snapshot: `published/releases/snapshots/EV-PUB-2026-03-20-public-surface-bootstrap.surface.json`
- Public surface snapshot sha256: `608858ad6127d44c973ad3a13c20d0a72afe03b686379aa5162152c540dcc83c`

## Summary
Bootstrap the stable public-facing landing surface and record it as a first-class public release linked to a written release decision.

## Public paths
- `published/index.md`
- `published/reader_guide.md`
- `published/artifact_request.md`
- `published/PUBLIC_SURFACE.json`
- `published/releases/README.md`
- `published/releases/2026-03-20-public-surface-bootstrap.md`
- `published/releases/2026-03-20-public-surface-bootstrap.json`
- `published/releases/RELEASE_INDEX.json`
- `published/releases/LATEST.json`

## Public surface snapshot
- `published/releases/snapshots/EV-PUB-2026-03-20-public-surface-bootstrap.surface.json`

## Release artifact
- `published/releases/artifacts/EV-PUB-2026-03-20-public-surface-bootstrap.zip`
- `published/releases/artifacts/EV-PUB-2026-03-20-public-surface-bootstrap.bundle.json`

## Archive note
The public release is a stable entry surface, not a mirror of the full working archive.
