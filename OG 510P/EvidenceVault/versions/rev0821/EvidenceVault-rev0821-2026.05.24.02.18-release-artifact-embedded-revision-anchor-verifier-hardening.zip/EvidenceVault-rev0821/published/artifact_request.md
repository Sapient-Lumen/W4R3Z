# EvidenceVault artifact availability

The public surface does not include every retained artifact, source extract, certificate, tooling output, or replay pack.
That omission is intentional.

## What is available on request
- retained replay packs and selected artifact bundles
- supporting certificates and curated evidence objects
- additional source extracts or legacy renders when they are relevant to a paper claim
- other archive-backed companion materials that are not part of the stable public surface

## Integrity posture
- archive bundles carry `MANIFEST.sha256`
- upstream inputs are tracked in `UPSTREAM_INPUTS.sha256`
- archive inventory is tracked in `INDEX/files.json` and `INDEX/files.csv`
- current public-surface membership is tracked in `published/PUBLIC_SURFACE.json`

## Release posture
- not every retained material is public by default
- `hold` and `no release` are normal outcomes
- written release decisions live under `release_queue/decisions/` in the working archive
