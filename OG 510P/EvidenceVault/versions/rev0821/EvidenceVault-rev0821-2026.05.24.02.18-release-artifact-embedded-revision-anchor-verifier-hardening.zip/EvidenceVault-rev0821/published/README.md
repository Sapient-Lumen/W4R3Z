# EvidenceVault public surface

This directory is the stable public-facing surface.
It should stay smaller than the working archive.

Publish here only materials that are intended to remain public and easy to cite:
- a reader-facing entry page,
- a public artifact/request note,
- selected release-ready paper copies or release pointers,
- other small stable companions.

Do not treat this directory as a mirror of the full archive.
The working source of truth remains the canonical archive root and the papers under `papers/`.


## Public entry points
- `index.md` — landing page
- `reader_guide.md` — onboarding guide
- `artifact_request.md` — public artifact/request note
- `PUBLIC_SURFACE.json` — machine-readable public-surface membership
- `releases/` — stable public release notes or pointers
- `releases/snapshots/` — immutable release-scoped public-surface snapshots
- `releases/artifacts/` — deterministic public release bundles and bundle manifests
