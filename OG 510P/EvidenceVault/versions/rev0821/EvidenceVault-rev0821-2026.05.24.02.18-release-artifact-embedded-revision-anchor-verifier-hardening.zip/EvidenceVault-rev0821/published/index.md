# EvidenceVault public release surface

This is the stable public-facing entry point for the EvidenceVault series.
It is intentionally smaller than the full working archive.

## Read first
- `reader_guide.md` — short guide to the series, reading order, and layer ownership.
- `artifact_request.md` — what is not bundled publicly and how to request the archive-backed companion materials.
- `PUBLIC_SURFACE.json` — machine-readable description of the public surface.
- `releases/README.md` — public release notes and release-ledger boundary.
- `releases/RELEASE_INDEX.json` — machine-readable ledger of public releases.
- `releases/LATEST.json` — pointer to the latest public release.
- `releases/snapshots/README.md` — immutable public-surface snapshots per release.
- `releases/artifacts/ARTIFACT_INDEX.json` — machine-readable ledger of materialized public release bundles.

The broader release queue remains in the working archive at `release_queue/`; only stable public outputs belong here.

## Canonical series boundary
The canonical single-file TeX papers remain under `papers/` in the working archive.
`SERIES.md` remains the sole architecture and reading-order statement.
This public surface exists to make first contact and public release posture easier to audit.
