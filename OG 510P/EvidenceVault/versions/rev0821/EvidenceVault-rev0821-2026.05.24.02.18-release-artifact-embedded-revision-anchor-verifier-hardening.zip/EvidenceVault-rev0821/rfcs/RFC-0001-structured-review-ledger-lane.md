# RFC 0001: Structured review-ledger lane for future publishing rounds

- Status: proposed
- Date: 2026-03-20
- Origin record: AL-9003
- Review posture: bounded proposal memory only

## Context
Repeated comparison passes surfaced a family of review-ledger / rubric / status-board patterns that are visibly useful in other datacubes, but not yet clearly necessary in EvidenceVault.
EvidenceVault already has stronger-than-average queue, decision, release, snapshot, bootstrap, ADR, and assimilation-memory machinery, so a larger review layer should not be imported just because it exists elsewhere.
At the same time, keeping this pressure as only a one-line deferred assimilation record risks future re-litigation from scratch.

## Proposal
If a sharper archive-internal need appears, add one **bounded review-ledger lane** for future paper/release review rounds.
That lane should stay subordinate to `PUBLISHING.md`, reuse the existing queue/decision structure, and record review state without widening `published/` or creating a second canon.
The likely minimal surfaces would be a compact human-facing review register, a machine-readable twin, and one validator linking them back to queue/decision/release state.

## Non-goals
- widening `published/` into a porch mirror of the working archive;
- replacing `PUBLISHING.md`, `release_queue/`, or public-release records;
- importing broad status-board or feedback systems without a narrow EvidenceVault-specific need;
- turning review helpers into standing canon.

## Adoption trigger
Adopt only if one future revision needs to track multiple simultaneous review lanes, reviewer states, or explicit correction/re-review obligations that are no longer carried cleanly by the current queue/decision/release stack plus receipts.

## Rejection condition
Reject if the current queue + decision + release + bootstrap + ADR + assimilation-memory surfaces continue to cover review pressure without repeated confusion, loss, or governance drift.

## Current posture
Deferred.
The idea is worth preserving because it recurs across several comparison cubes, but the current EvidenceVault archive still does not show a strong enough internal need to justify landing it now.
