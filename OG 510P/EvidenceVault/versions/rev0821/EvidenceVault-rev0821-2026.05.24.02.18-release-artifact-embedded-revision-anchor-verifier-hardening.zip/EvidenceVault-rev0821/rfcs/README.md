# EvidenceVault RFCs

This directory holds **bounded unresolved proposals** that are worth preserving in more detail than a one-line deferral, but are **not** yet standing architecture decisions.

Use this layer when a structural idea is:
- serious enough to deserve a real proposal surface,
- still unsettled enough that it should **not** become an ADR, and
- worth keeping recoverable across repeated comparison-driven passes.

`RFC_INDEX.md` is the compact human-facing map.
`RFC_INDEX.json` is the machine-readable twin.
The canonical archive surfaces remain `SERIES.md`, `PUBLISHING.md`, `PAPER_SERIES_INDEX.md`, `CATALOG.md`, `papers/EXTRACTION_MAP.json`, and `CHANGELOG.md`.
