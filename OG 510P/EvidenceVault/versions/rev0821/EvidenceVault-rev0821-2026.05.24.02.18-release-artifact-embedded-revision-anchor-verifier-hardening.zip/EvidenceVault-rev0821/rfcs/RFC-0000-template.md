# RFC 0000: Template

- Status: proposed
- Date: YYYY-MM-DD
- Origin record: AL-XXXX
- Review posture: bounded proposal memory only

## Context
State the pressure or unresolved question precisely.

## Proposal
Describe the bounded change being considered.

## Non-goals
List nearby moves this RFC does not authorize.

## Adoption trigger
State what sharper archive-internal need or evidence would justify landing the proposal.

## Rejection condition
State what would make the proposal unnecessary or clearly wrong for EvidenceVault.

## Current posture
Explain why the proposal remains unresolved today.
