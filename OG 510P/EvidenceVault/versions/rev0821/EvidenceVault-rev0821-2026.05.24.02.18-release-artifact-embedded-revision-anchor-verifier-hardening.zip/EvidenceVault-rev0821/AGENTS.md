# Repo contract for careful EvidenceVault passes

This file is a compact derivative wrapper for humans and LLMs working inside this archive.
It does not replace `SERIES.md`, `PUBLISHING.md`, or `CHANGELOG.md`.

## Read first
1. `START_HERE.md`
2. `OPENING_CONTRACT.json`
3. `SERIES.md`
4. `PUBLISHING.md`
5. `CONTROL_SURFACES.json`
6. `LIFECYCLE_GATES.json`
7. `VALIDATION_INDEX.md`
8. `CLAIM_OBLIGATION_MAP.md`
9. `VALIDATION_INDEX.json`
10. `SOURCE_INDEX.md`
11. `ADR_INDEX.md`
12. `RFC_INDEX.md`
13. `CURRENT_FRONTIER.md`
14. `REVISION_RECEIPT.json`
15. `ASSIMILATION_LEDGER.md`
16. `RELEASE_MANIFEST.json`
17. `REVISION_ANCHORS.json`
18. `ARCHIVE_INDEX.md`
## Non-negotiables
- Do not move canon ownership out of `SERIES.md`, `PUBLISHING.md`, `PAPER_SERIES_INDEX.md`, `CATALOG.md`, `papers/EXTRACTION_MAP.json`, or `CHANGELOG.md`.
- Do not casually widen `published/`; it is a small stable public frontage, not a mirror of the archive.
- Do not treat `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `VALIDATION_INDEX.*`, `CLAIM_OBLIGATION_MAP.*`, `SOURCE_INDEX.*`, `ADR_INDEX.*`, `RFC_INDEX.*`, or `CURRENT_FRONTIER.*` as new canon; they are governed recovery/decision surfaces around the canon.
- Do not silently rewrite carried-forward audit witnesses that preserve earlier audit-batch labels; check `AUDIT/README.md` first.
- Keep `REVISION_RECEIPT.json`, `REVISION_ANCHORS.json`, `ASSIMILATION_LEDGER.*`, `ADR_INDEX.*`, `RFC_INDEX.*`, `CURRENT_FRONTIER.*`, `VALIDATION_INDEX.*`, `CLAIM_OBLIGATION_MAP.*`, `SOURCE_INDEX.*`, `RELEASE_MANIFEST.json`, `ARCHIVE_INDEX.md`, and `ARCHIVE_INDEX.json` truthful whenever standing decisions, unresolved proposal memory, live comparison/frontier memory, retained-source inventory, validation/assurance inventory, selected claim-obligation mapping, current revision-bearing identity, or bundle identity changes.

## Command posture
- Prefer the root `Makefile` wrappers over hand-retyping long check sequences.
- Run `make gate` after meaningful archive changes.
- Run `make source-check` when retained-source or family-representation surfaces changed.
- Run `make rfc-check` when bounded unresolved-proposal surfaces changed.
- Run `make frontier-check` when current live-priority/open-pressure surfaces changed.
- Run `make assimilation-check` when comparison-memory surfaces changed.
- Run `make revision-check` when revision-bearing bundle/control surfaces changed.
- Run `make validation-check` when validation/assurance inventory surfaces changed.
- Run `make claim-obligation-check` when selected claim-support mapping, claim-obligation schema, or claim-map validator wiring changed.
- Run `make runner-check` when composite command runners changed; run `make publish-audit` when release-path or public-surface state changed.
- Run `make preflight` before claiming a shipping posture.
- Run `make package-release` only after revision identity, archive index, and changelog surfaces already describe the intended bundle.
- Only run `make build-papers` when canonical paper sources changed.

## What good changes usually do
- sharpen ownership boundaries without widening claims,
- improve startup/reentry discipline,
- harden public-release governance,
- clarify audit/retention boundaries,
- or reduce operator/LLM recovery error by adding low-entropy governed entry surfaces.
- or preserve cross-revision memory about adopted, rejected, and deferred outside patterns so repeated comparison-driven passes do not restart from zero.
- or preserve a bounded unresolved proposal in `RFC_INDEX.*` / `rfcs/` when an idea is serious enough to keep but still too unsettled for ADR status.
- or preserve one bounded current priority/open-pressure resume surface in `CURRENT_FRONTIER.*` when repeated comparison-driven passes need live context that should not be confused with settled ADR memory.
- or preserve one now-stable structural decision in `ADR_INDEX.*` and `adrs/` so future passes do not re-derive it only from receipts and changelog prose.
- or make the assurance map more truthful by recording which target proves which surface and which builder refreshes which governed artifact.
- or make selected claim support more truthful by mapping claims to concrete surfaces, validators, obligations, known limits, and negative-regression expectations.
- or make retained-source lookup more truthful by recording which canonical papers consume which retained source roots and which family lines are represented only via curated artifacts, certs, or legacy renders.

## Asset-index discipline

Run `make asset-indexes` and `make asset-check` whenever files under `artifacts/` or `certs/` change.  The scoped indexes are generated governance surfaces, not hand-maintained notes.
