# assurance_case_ccc_demo_v208

This demo shows how to export a **release assurance case** that includes a **Change-Control Certificate (CCC)** update gate.

Inputs:
- A tiny ABOM that contains a `change_control` obligation (`ccc_release_abom_v208.json`).
- The end-to-end CCC bundle emitted in `examples/change_control_demo_v207/ccc.json`.

Run:

```bash
python3 tools/assurance_case_export_v208.py \
  --abom examples/assurance_case_ccc_demo_v208/ccc_release_abom_v208.json \
  --ccc  examples/change_control_demo_v207/ccc.json \
  --out-dot  examples/assurance_case_ccc_demo_v208/ccc_release_case_v208.dot \
  --out-json examples/assurance_case_ccc_demo_v208/ccc_release_case_v208.json \
  --render-pdf examples/assurance_case_ccc_demo_v208/ccc_release_case_v208.pdf
```

Outputs:
- `ccc_release_case_v208.dot` (Graphviz DOT)
- `ccc_release_case_v208.json` (simple node/edge structure)
- `ccc_release_case_v208.pdf` (rendered graph)
