#!/usr/bin/env python3
"""assurance_adc_hotspot_multibudget_v264.py

v264 research artifact: multi-budget admission control that targets *hot shared
artifacts* explicitly.

Key idea
--------
Churn debt (total outstanding validation work per claim) captures governance
rework, but tail risk is often dominated by a *small set of shared artifacts*
(e.g., global policy packs, safety layers, retrieval sharding). If those artifacts
stay "hot" (many pending validations tied to them), they become operational
single points of failure:
  - reviews bottleneck on a single team,
  - evidence stales and incidents trigger broad recertification,
  - audit readiness collapses when a hotspot misses its cadence.

We therefore add an artifact-level debt signal:
  - hotspot churn: H_t = max_{a in TopK} churn_a(t)
    where churn_a(t) = sum_{claims requiring a} backlog(claim) / N.

We compare:
  1) shadow_bool: single shadow price on boolean invalidation (fail-closed cap)
  2) artifact_soft: shadow_bool + soft per-artifact churn prices (v263-style)
  3) multibudget_hard: shadow_bool + *hard caps* on churn_a for TopK artifacts

We sweep a multiplier gamma that scales per-artifact caps and report a Pareto
frontier: normalized value vs P95 hotspot churn.

Generates:
  - figs/assurance_adc_hotspot_frontier_v264.pdf
  - figs/assurance_adc_hotspot_trace_v264.pdf
  - tables/assurance_adc_hotspot_summary_v264.tex
  - examples/assurance_adc_hotspot_run_v264.json
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

import numpy as np

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent.parent


def load_json(p: Path) -> Dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def artifact_kind(aid: str) -> str:
    if aid.startswith("A_prompt_"):
        return "prompt"
    if aid.startswith("A_retr_"):
        return "retr"
    if aid.startswith("A_policy_"):
        return "policy"
    if aid in ("A_fm", "A_profile", "A_monitor"):
        return "global"
    if aid.startswith("A_fm") or aid.startswith("A_profile") or aid.startswith("A_monitor"):
        return "global"
    return "other"


@dataclass
class Change:
    day: int
    artifact_ids: Tuple[str, ...]
    impacted_idx: np.ndarray
    br_union: float
    value: float


def build_rev_maps(abom: Dict[str, Any], scope_prefix: str) -> Tuple[List[str], Dict[str, np.ndarray]]:
    obligations = [o for o in (abom.get("obligations") or []) if isinstance(o, dict) and str(o.get("id", "")).startswith(scope_prefix)]
    oids = [str(o.get("id")) for o in obligations]
    oid_to_i = {oid: i for i, oid in enumerate(oids)}

    rev: Dict[str, List[int]] = {}
    for o in obligations:
        oid = str(o.get("id"))
        i = oid_to_i[oid]
        for req in (o.get("requires") or []):
            aid = str(req)
            rev.setdefault(aid, []).append(i)

    rev_np: Dict[str, np.ndarray] = {aid: np.array(sorted(set(ixs)), dtype=np.int32) for aid, ixs in rev.items()}
    return oids, rev_np


def zipf_weights(n: int, alpha: float) -> np.ndarray:
    r = np.arange(1, n + 1, dtype=float)
    w = 1.0 / np.power(r, alpha)
    return w / w.sum()


def draw_value(rng: np.random.Generator, kinds: Sequence[str], breadth: float) -> float:
    base_mu = 0.0
    base_sigma = 0.65
    if "global" in kinds:
        base_mu += 0.9
    if "policy" in kinds:
        base_mu += 0.5
    if "retr" in kinds:
        base_mu += 0.2
    if "prompt" in kinds and len(kinds) == 1:
        base_mu += -0.1

    base = float(np.exp(rng.normal(base_mu, base_sigma)))
    corr = 0.80 + 0.20 * np.sqrt(max(1e-9, breadth))
    return base * float(corr)


def union_impacted(rev: Dict[str, np.ndarray], aids: Sequence[str]) -> np.ndarray:
    arrs = [rev.get(a) for a in aids if a in rev]
    arrs = [a for a in arrs if a is not None and a.size > 0]
    if not arrs:
        return np.array([], dtype=np.int32)
    if len(arrs) == 1:
        return arrs[0]
    return np.unique(np.concatenate(arrs))


def make_change_stream_bundles(
    *,
    rng: np.random.Generator,
    days: int,
    lam_per_day: float,
    artifacts_by_kind: Dict[str, List[str]],
    rev: Dict[str, np.ndarray],
    N: int,
    zipf_alpha_policy: float = 1.7,
    zipf_alpha_retr: float = 1.15,
) -> List[List[Change]]:
    mix = {"prompt": 0.62, "retr": 0.18, "policy": 0.16, "global": 0.04}
    kinds = list(mix.keys())
    kind_p = np.array([mix[k] for k in kinds], dtype=float)
    kind_p /= kind_p.sum()

    kind_choice_weights: Dict[str, np.ndarray] = {}
    for k, aids in artifacts_by_kind.items():
        if not aids:
            continue
        if k == "policy":
            kind_choice_weights[k] = zipf_weights(len(aids), zipf_alpha_policy)
        elif k == "retr":
            kind_choice_weights[k] = zipf_weights(len(aids), zipf_alpha_retr)
        else:
            kind_choice_weights[k] = np.ones(len(aids), dtype=float) / max(1, len(aids))

    arrivals: List[List[Change]] = [[] for _ in range(days)]
    for d in range(days):
        k = int(rng.poisson(lam_per_day))
        if k <= 0:
            continue
        ks = rng.choice(kinds, size=k, p=kind_p)
        for primary_kind in ks:
            aids_primary = artifacts_by_kind.get(str(primary_kind), [])
            if not aids_primary:
                continue
            w = kind_choice_weights[str(primary_kind)]
            a0 = str(rng.choice(aids_primary, p=w))

            bundle = [a0]
            if str(primary_kind) in ("policy", "retr") and artifacts_by_kind.get("prompt"):
                if rng.random() < 0.55:
                    bundle.append(str(rng.choice(artifacts_by_kind["prompt"])))
            if str(primary_kind) == "policy" and artifacts_by_kind.get("global"):
                if rng.random() < 0.15:
                    bundle.append(str(rng.choice(artifacts_by_kind["global"])))

            bundle = list(dict.fromkeys(bundle))
            impacted = union_impacted(rev, bundle)
            if impacted.size == 0:
                continue
            breadth = float(impacted.size) / max(1, N)
            br_union = float(impacted.size) / max(1, N)
            kinds_in = [artifact_kind(a) for a in bundle]
            val = draw_value(rng, kinds_in, breadth)
            arrivals[d].append(Change(day=d, artifact_ids=tuple(bundle), impacted_idx=impacted, br_union=br_union, value=val))
    return arrivals


def discounted_value(v: float, delay: int, tau: float) -> float:
    return float(v * np.exp(-delay / max(1e-9, tau)))


def pctl(xs: np.ndarray, q: float) -> float:
    if xs.size == 0:
        return 0.0
    return float(np.quantile(xs, q))


def simulate(
    *,
    arrivals: List[List[Change]],
    N: int,
    rev: Dict[str, np.ndarray],
    top_artifacts: List[str],
    br: Dict[str, float],
    capacity: int,
    D_cap: float,
    tau: float,
    policy: str,
    gamma: float,
    seed: int,
    candidate_pool: int = 160,
    max_ship_per_day: int = 80,
    eta: float = 0.08,
    lambda_bool: float = 18.0,
    lambda_hot: float = 5.0,
) -> Dict[str, Any]:
    rng = np.random.default_rng(seed)
    days = len(arrivals)

    backlog = np.zeros(N, dtype=np.int32)
    q: List[Change] = []

    p_bool = 12.0
    pA: Dict[str, float] = {a: 10.0 for a in top_artifacts}

    A_cap: Dict[str, float] = {a: max(1e-6, gamma * br.get(a, 0.0)) for a in top_artifacts}

    series_bool = np.zeros(days, dtype=float)
    series_total = np.zeros(days, dtype=float)
    series_hot = np.zeros(days, dtype=float)

    shipped = 0
    value = 0.0

    top_idx: Dict[str, np.ndarray] = {a: rev.get(a, np.array([], dtype=np.int32)) for a in top_artifacts}

    def cur_bool() -> float:
        return float(np.count_nonzero(backlog > 0)) / max(1, N)

    def cur_total_churn() -> float:
        return float(backlog.sum()) / max(1, N)

    def cur_hotspot() -> float:
        hs = 0.0
        for a, idx in top_idx.items():
            if idx.size == 0:
                continue
            hs = max(hs, float(backlog[idx].sum()) / max(1, N))
        return hs


    def artifact_pressure(a: str) -> float:
        idx = top_idx.get(a)
        if idx is None or idx.size == 0:
            return 0.0
        return float(backlog[idx].sum()) / max(1, N)

    for d in range(days):
        # Clear capacity units (highest backlog first, sampled).
        if capacity > 0:
            pos = np.nonzero(backlog > 0)[0]
            if pos.size > 0:
                sample = pos
                if pos.size > 4 * capacity:
                    sample = rng.choice(pos, size=4 * capacity, replace=False)
                order = sample[np.argsort(-backlog[sample])]
                cleared = 0
                for i in order:
                    if cleared >= capacity:
                        break
                    if backlog[i] > 0:
                        backlog[i] -= 1
                        cleared += 1

        q.extend(arrivals[d])

        def feasible(c: Change) -> bool:
            approx_bool_after = min(1.0, cur_bool() + c.br_union * (1.0 - cur_bool()))
            if approx_bool_after > D_cap + 1e-12:
                return False
            if policy == "multibudget_hard":
                for a in c.artifact_ids:
                    if a in A_cap:
                        if artifact_pressure(a) + br.get(a, 0.0) > A_cap[a] + 1e-12:
                            return False
            return True

        def score(c: Change) -> float:
            dv = discounted_value(c.value, d - c.day, tau)
            m_bool = max(1e-12, c.br_union * (1.0 - cur_bool()))
            if policy == "shadow_bool":
                return dv - lambda_bool * p_bool * m_bool
            if policy in ("artifact_soft", "multibudget_hard"):
                s = dv - lambda_bool * p_bool * m_bool
                for a in c.artifact_ids:
                    if a in pA:
                        s -= lambda_hot * pA[a] * br.get(a, 0.0)
                return s
            return dv / m_bool

        shipped_today = 0
        while q and shipped_today < max_ship_per_day:
            scan_n = min(len(q), candidate_pool)
            best_i = None
            best_s = -1e30
            for i in range(scan_n):
                c = q[i]
                if not feasible(c):
                    continue
                s = score(c)
                if s > best_s:
                    best_s = s
                    best_i = i

            if best_i is None:
                break
            if policy in ("shadow_bool", "artifact_soft", "multibudget_hard") and best_s <= 0.0:
                break

            c = q.pop(best_i)
            if not feasible(c):
                continue
            backlog[c.impacted_idx] += 1
            shipped += 1
            shipped_today += 1
            value += discounted_value(c.value, d - c.day, tau)

        # Update price signals.
        if policy in ("shadow_bool", "artifact_soft", "multibudget_hard"):
            ratio = cur_bool() / max(1e-9, D_cap)
            p_bool *= float(np.exp(eta * (ratio - 1.0)))
            p_bool = float(np.clip(p_bool, 1e-4, 1e4))

        if policy in ("artifact_soft", "multibudget_hard"):
            for a in top_artifacts:
                cap = max(1e-6, A_cap[a])
                pa = artifact_pressure(a)
                pA[a] *= float(np.exp(eta * (pa / cap - 1.0)))
                pA[a] = float(np.clip(pA[a], 1e-4, 1e4))

        series_bool[d] = cur_bool()
        series_total[d] = cur_total_churn()
        series_hot[d] = cur_hotspot()

    return {
        "policy": policy,
        "gamma": float(gamma),
        "value": float(value),
        "shipped": int(shipped),
        "p95_bool": pctl(series_bool, 0.95),
        "p95_total": pctl(series_total, 0.95),
        "p95_hot": pctl(series_hot, 0.95),
        "series_bool": series_bool,
        "series_total": series_total,
        "series_hot": series_hot,
    }


def write_table(path: Path, rows: List[Dict[str, Any]], D_cap: float) -> None:
    def fmt(x: float) -> str:
        return f"{x:.3f}"

    gammas = sorted({float(r["gamma"]) for r in rows})
    g_star = gammas[len(gammas) // 2]
    reps = [r for r in rows if abs(float(r["gamma"]) - g_star) < 1e-9]

    name = {
        "shadow_bool": "Shadow (bool)",
        "artifact_soft": "Artifact prices (soft)",
        "multibudget_hard": "Multi-budget (hard)",
    }
    order = ["shadow_bool", "artifact_soft", "multibudget_hard"]
    reps = sorted(reps, key=lambda r: order.index(str(r["policy"])) if str(r["policy"]) in order else 99)

    lines: List[str] = []
    lines.append("% Auto-generated by tools/assurance_adc_hotspot_multibudget_v264.py")
    lines.append("\\begin{tabular}{lrrrrr}")
    lines.append("\\toprule")
    lines.append(f"Policy (D\\_cap={D_cap:.2f}, $\\gamma$={g_star:.2f}) & Value & Shipped & P95 hotspot & P95 churn & P95 bool \\\\")
    lines.append("\\midrule")
    for r in reps:
        lines.append(f"{name.get(r['policy'], r['policy'])} & {fmt(r['value'])} & {int(r['shipped'])} & {fmt(r['p95_hot'])} & {fmt(r['p95_total'])} & {fmt(r['p95_bool'])} \\\\")
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--abom", default="examples/fleet_abom_v165_policy_shared.json")
    ap.add_argument("--scope-prefix", default="O_sys_")
    ap.add_argument("--days", type=int, default=90)
    ap.add_argument("--capacity", type=int, default=160)
    ap.add_argument("--lam", type=float, default=14.0)
    ap.add_argument("--tau", type=float, default=14.0)
    ap.add_argument("--D-cap", type=float, default=0.30)
    ap.add_argument("--top-k", type=int, default=15)
    ap.add_argument("--seed", type=int, default=9)

    ap.add_argument("--out-frontier", default="figs/assurance_adc_hotspot_frontier_v264.pdf")
    ap.add_argument("--out-trace", default="figs/assurance_adc_hotspot_trace_v264.pdf")
    ap.add_argument("--out-tex", default="tables/assurance_adc_hotspot_summary_v264.tex")
    ap.add_argument("--out-json", default="examples/assurance_adc_hotspot_run_v264.json")
    args = ap.parse_args()

    abom = load_json(ROOT / args.abom)
    oids, rev = build_rev_maps(abom, args.scope_prefix)
    N = len(oids)
    if N <= 0:
        raise SystemExit("No scoped obligations found")

    artifacts = [a for a in (abom.get("artifacts") or []) if isinstance(a, dict) and a.get("id")]
    aids = [str(a["id"]) for a in artifacts if str(a["id"]) in rev]

    br = {aid: float(rev[aid].size) / max(1, N) for aid in aids}
    aids_sorted = sorted(aids, key=lambda a: br.get(a, 0.0), reverse=True)
    top_artifacts = aids_sorted[: max(1, args.top_k)]

    artifacts_by_kind: Dict[str, List[str]] = {"prompt": [], "retr": [], "policy": [], "global": []}
    for aid in aids:
        k = artifact_kind(aid)
        if k in artifacts_by_kind:
            artifacts_by_kind[k].append(aid)

    rng = np.random.default_rng(args.seed)
    arrivals = make_change_stream_bundles(
        rng=rng,
        days=args.days,
        lam_per_day=args.lam,
        artifacts_by_kind=artifacts_by_kind,
        rev=rev,
        N=N,
    )

    loose = simulate(
        arrivals=arrivals,
        N=N,
        rev=rev,
        top_artifacts=top_artifacts,
        br=br,
        capacity=args.capacity,
        D_cap=0.95,
        tau=args.tau,
        policy="shadow_bool",
        gamma=10.0,
        seed=args.seed + 101,
    )
    v_norm = max(1e-9, float(loose["value"]))

    gammas = np.linspace(0.8, 4.0, 9)
    policies = ["shadow_bool", "artifact_soft", "multibudget_hard"]

    rows: List[Dict[str, Any]] = []
    frontier: Dict[str, List[Tuple[float, float]]] = {p: [] for p in policies}

    for g in gammas:
        for p in policies:
            out = simulate(
                arrivals=arrivals,
                N=N,
                rev=rev,
                top_artifacts=top_artifacts,
                br=br,
                capacity=args.capacity,
                D_cap=float(args.D_cap),
                tau=args.tau,
                policy=p,
                gamma=float(g),
                seed=args.seed + 17,
            )
            out["value_norm"] = float(out["value"]) / v_norm
            rows.append(out)
            frontier[p].append((float(out["p95_hot"]), float(out["value_norm"])))

    out_frontier = ROOT / args.out_frontier
    out_frontier.parent.mkdir(parents=True, exist_ok=True)

    plt.figure(figsize=(7.2, 4.3))
    for p in policies:
        xs = [x for x, _ in frontier[p]]
        ys = [y for _, y in frontier[p]]
        plt.plot(xs, ys, marker="o", linewidth=1.6, markersize=3, label=p)
    plt.xlabel("P95 hotspot churn $\\max_a \\; churn_a$ (work/N)")
    plt.ylabel("Realized discounted value (normalized)")
    plt.title("Multi-budget ADC frontier: value vs hotspot churn (v264)")
    plt.grid(True, alpha=0.25)
    plt.ylim(0.0, 1.05)
    plt.tight_layout()
    plt.legend(fontsize=8, loc="lower right")
    plt.savefig(out_frontier, format="pdf")
    plt.close()

    g_star = float(gammas[len(gammas) // 2])
    outs_trace = {
        p: simulate(
            arrivals=arrivals,
            N=N,
            rev=rev,
            top_artifacts=top_artifacts,
            br=br,
            capacity=args.capacity,
            D_cap=float(args.D_cap),
            tau=args.tau,
            policy=p,
            gamma=g_star,
            seed=args.seed + 33,
        )
        for p in ("shadow_bool", "multibudget_hard")
    }

    out_trace = ROOT / args.out_trace
    out_trace.parent.mkdir(parents=True, exist_ok=True)

    plt.figure(figsize=(7.2, 4.4))
    t = np.arange(args.days)
    for p, out in outs_trace.items():
        plt.plot(t, out["series_hot"], linewidth=1.3, label=f"{p}: hotspot")
    plt.xlabel("Day")
    plt.ylabel("Hotspot churn (work/N)")
    plt.title(f"Hotspot churn trace at $\\gamma$={g_star:.2f} (v264)")
    plt.grid(True, alpha=0.25)
    plt.legend(fontsize=8, loc="upper right")
    plt.tight_layout()
    plt.savefig(out_trace, format="pdf")
    plt.close()

    out_tex = ROOT / args.out_tex
    out_tex.parent.mkdir(parents=True, exist_ok=True)
    write_table(out_tex, rows, float(args.D_cap))

    out_json = ROOT / args.out_json
    out_json.parent.mkdir(parents=True, exist_ok=True)
    capsule = {
        "abom": args.abom,
        "N": N,
        "days": args.days,
        "capacity": args.capacity,
        "lam": args.lam,
        "D_cap": float(args.D_cap),
        "top_k": int(args.top_k),
        "gammas": [float(x) for x in gammas],
        "out_frontier": str(out_frontier),
        "out_trace": str(out_trace),
        "out_tex": str(out_tex),
    }
    out_json.write_text(json.dumps(capsule, indent=2) + "\n", encoding="utf-8")

    print(json.dumps(capsule, indent=2))


if __name__ == "__main__":
    main()
