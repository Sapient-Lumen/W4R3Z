#!/usr/bin/env python3
"""assurance_adc_artifact_churn_v263.py

v263 research artifact: unify blast-radius attribution with ADC via a
*churn-sensitive* debt model and artifact-aware shadow prices.

Motivation
----------
The simplest assurance-debt metric (fraction of claims currently invalid) is a
set union: repeated changes to already-invalidated claims do not increase debt.
In practice, repeated broad updates before evidence refresh create *rework* and
queueing pressure (more evaluation runs, more sign-offs, more evidence edits).

We therefore simulate two coupled signals:
  - Boolean invalidation ("is this claim currently uncertified?")
  - Churn debt: outstanding validation work units per claim.

Each shipped change adds +1 work unit to every impacted claim; the organization
clears a fixed capacity C work units/day (highest-backlog-first).

We compare admission policies under the same hard fail-closed cap on boolean
invalidation (D_cap), but different *value-aware* ranking rules:
  - FIFO gate
  - Value/boolean-marginal greedy
  - Single-price shadow controller (boolean)
  - Artifact-aware shadow controller: adds per-artifact prices for churn,
    initialized/structured by blast radius (top-K artifacts).

The artifact-aware controller is the risk-taking move: it makes governance
multi-resource (boolean invalidation + churn on shared artifacts), using the
obligation archive to attribute backlog pressure to concrete refactoring
targets.

Generates:
  - figs/assurance_adc_churn_value_v263.pdf
  - figs/assurance_adc_churn_p95_v263.pdf
  - tables/assurance_adc_churn_summary_v263.tex

Usage:
  python3 tools/assurance_adc_artifact_churn_v263.py \
    --abom examples/fleet_abom_v165_policy_shared.json \
    --days 240 --window 30 --capacity 180 --seed 7
"""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple

import numpy as np

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parent.parent


def load_json(p: Path) -> Dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def artifact_kind(aid: str) -> str:
    if aid.startswith("A_prompt_"):
        return "prompt"
    if aid.startswith("A_retr_"):
        return "retr"
    if aid.startswith("A_policy_"):
        return "policy"
    if aid.startswith("A_fm") or aid.startswith("A_profile") or aid.startswith("A_monitor"):
        return "global"
    if aid in ("A_fm", "A_profile", "A_monitor"):
        return "global"
    return "other"


@dataclass
class Change:
    day: int
    artifact_id: str
    impacted_idx: np.ndarray  # int indices into obligations
    value: float


def build_rev_maps(abom: Dict[str, Any], scope_prefix: str) -> Tuple[List[str], Dict[str, np.ndarray]]:
    """Return ordered obligation ids and artifact->impacted obligation indices."""
    obligations = [o for o in (abom.get("obligations") or []) if isinstance(o, dict) and str(o.get("id", "")).startswith(scope_prefix)]
    oids = [str(o.get("id")) for o in obligations]
    oid_to_i = {oid: i for i, oid in enumerate(oids)}

    rev: Dict[str, List[int]] = {}
    for o in obligations:
        oid = str(o.get("id"))
        i = oid_to_i[oid]
        for req in (o.get("requires") or []):
            aid = str(req)
            rev.setdefault(aid, []).append(i)

    rev_np: Dict[str, np.ndarray] = {aid: np.array(sorted(set(ixs)), dtype=np.int32) for aid, ixs in rev.items()}
    return oids, rev_np


def draw_value(rng: np.random.Generator, kind: str, breadth: float) -> float:
    # Log-normal baseline by kind, then gently correlate with breadth.
    params = {
        "prompt": (-0.2, 0.7),
        "retr": (0.2, 0.6),
        "policy": (0.4, 0.6),
        "global": (0.8, 0.7),
    }
    mu, sigma = params.get(kind, (0.0, 0.7))
    base = float(np.exp(rng.normal(mu, sigma)))
    # Keep the breadth/value correlation mild so that local updates can still be high-value.
    corr = 0.80 + 0.20 * np.sqrt(max(1e-9, breadth))
    return base * float(corr)


def zipf_weights(n: int, alpha: float) -> np.ndarray:
    r = np.arange(1, n + 1, dtype=float)
    w = 1.0 / np.power(r, alpha)
    return w / w.sum()


def make_change_stream(
    *,
    rng: np.random.Generator,
    days: int,
    lam_per_day: float,
    artifacts_by_kind: Dict[str, List[str]],
    rev: Dict[str, np.ndarray],
    N: int,
    zipf_alpha_policy: float = 1.6,
    zipf_alpha_retr: float = 1.1,
) -> List[List[Change]]:
    """Generate daily arrivals as changes to single artifacts."""
    # Stress the shared-artifact tail: policies/retrievers are less frequent than prompts
    # in most systems, but are the dominant tail drivers when they churn.
    mix = {
        "prompt": 0.70,
        "retr": 0.17,
        "policy": 0.11,
        "global": 0.02,
    }
    kinds = list(mix.keys())
    kind_p = np.array([mix[k] for k in kinds], dtype=float)
    kind_p /= kind_p.sum()

    # Heavy-tail over shared artifacts: a few policies/retr shards change much more.
    kind_choice_weights: Dict[str, np.ndarray] = {}
    for k, aids in artifacts_by_kind.items():
        if not aids:
            continue
        if k == "policy":
            kind_choice_weights[k] = zipf_weights(len(aids), zipf_alpha_policy)
        elif k == "retr":
            kind_choice_weights[k] = zipf_weights(len(aids), zipf_alpha_retr)
        else:
            kind_choice_weights[k] = np.ones(len(aids), dtype=float) / max(1, len(aids))

    arrivals: List[List[Change]] = [[] for _ in range(days)]
    for d in range(days):
        k = int(rng.poisson(lam_per_day))
        if k <= 0:
            continue
        ks = rng.choice(kinds, size=k, p=kind_p)
        for kind in ks:
            aids = artifacts_by_kind.get(str(kind), [])
            if not aids:
                continue
            w = kind_choice_weights[str(kind)]
            aid = str(rng.choice(aids, p=w))
            impacted = rev.get(aid)
            if impacted is None or impacted.size == 0:
                continue
            breadth = float(impacted.size) / max(1, N)
            val = draw_value(rng, str(kind), breadth)
            arrivals[d].append(Change(day=d, artifact_id=aid, impacted_idx=impacted, value=val))
    return arrivals


def discounted_value(v: float, delay: int, tau: float) -> float:
    return float(v * np.exp(-delay / max(1e-9, tau)))


def pctl(xs: np.ndarray, q: float) -> float:
    if xs.size == 0:
        return 0.0
    return float(np.quantile(xs, q))


def simulate_policy(
    *,
    arrivals: List[List[Change]],
    N: int,
    capacity: int,
    D_cap: float,
    tau: float,
    policy: str,
    top_artifacts: Set[str],
    br: Dict[str, float],
    rev: Dict[str, np.ndarray] | None = None,
    eta: float = 0.08,
    lambda_bool: float = 18.0,
    lambda_churn: float = 4.0,
    target_churn_total: float = 0.25,
    seed: int = 0,
    candidate_pool: int = 140,
    max_ship_per_day: int = 70,
) -> Dict[str, Any]:
    """Simulate a policy under a hard cap on boolean invalidation."""
    rng = np.random.default_rng(seed)
    days = len(arrivals)

    backlog = np.zeros(N, dtype=np.int32)  # work units outstanding per claim

    q: List[Change] = []
    daily_bool = np.zeros(days, dtype=float)
    daily_churn = np.zeros(days, dtype=float)
    value = 0.0
    shipped_count = 0
    end_backlog = 0

    # Shadow prices. Initialize at a scale comparable to typical (value / fractional-cost).
    p0 = 12.0
    pA: Dict[str, float] = {a: 12.0 for a in top_artifacts}
    p_other = 12.0

    # Cost scaling: costs are fractions (0..1) but values are O(1); scale costs into value units.
    # v263 tuning note: keep churn pricing *soft* so artifact-aware policies compete on value,
    # rather than trivially winning on churn by shipping almost nothing.

    # Targets for artifact-level churn pressure: proportional to blast radius.
    # This is intentionally heuristic; it encodes "large shared artifacts should not stay hot".
    total_br_top = sum(br.get(a, 0.0) for a in top_artifacts) + 1e-12
    # normalized churn (work/N) we tolerate as "hot" in steady-state
    targetA: Dict[str, float] = {a: target_churn_total * (br.get(a, 0.0) / total_br_top) for a in top_artifacts}

    for d in range(days):
        # Clear capacity units (highest backlog first).
        if capacity > 0:
            pos = np.nonzero(backlog > 0)[0]
            if pos.size > 0:
                # Sample a larger set, then take top backlog to avoid full sort.
                sample = pos
                if pos.size > 4 * capacity:
                    sample = rng.choice(pos, size=4 * capacity, replace=False)
                # Greedy clear.
                order = sample[np.argsort(-backlog[sample])]
                cleared = 0
                for i in order:
                    if cleared >= capacity:
                        break
                    if backlog[i] > 0:
                        backlog[i] -= 1
                        cleared += 1

        q.extend(arrivals[d])

        shipped_today: List[Change] = []

        def bool_frac_after(add_idx: np.ndarray) -> float:
            # Boolean invalidation is claims with backlog>0.
            cur = np.count_nonzero(backlog > 0)
            # Newly invalidated claims among impacted.
            newly = int(np.count_nonzero(backlog[add_idx] == 0))
            return float(cur + newly) / max(1, N)

        def marginal_bool(add_idx: np.ndarray) -> float:
            return float(np.count_nonzero(backlog[add_idx] == 0)) / max(1, N)

        def get_idx(aid: str) -> np.ndarray:
            if rev is None:
                return np.array([], dtype=np.int32)
            return rev.get(aid, np.array([], dtype=np.int32))

        def choose_next() -> int | None:
            if not q:
                return None
            if policy == "fifo":
                return 0

            best_i = None
            best_score = -1e30
            scan_n = min(len(q), candidate_pool)
            for i in range(scan_n):
                c = q[i]
                idx = c.impacted_idx
                if bool_frac_after(idx) > D_cap + 1e-12:
                    continue
                delay = d - c.day
                dv = discounted_value(c.value, delay, tau)
                m_bool = max(1e-12, marginal_bool(idx))
                m_churn = float(idx.size) / max(1, N)

                if policy == "value_greedy":
                    score = dv / m_bool
                elif policy == "shadow_bool":
                    score = dv - lambda_bool * p0 * m_bool
                elif policy == "artifact_shadow":
                    pa = pA.get(c.artifact_id, p_other)
                    score = dv - lambda_bool * p0 * m_bool - lambda_churn * pa * m_churn
                else:
                    score = dv / m_bool

                if score > best_score:
                    best_score = score
                    best_i = i
            # Shadow-price policies only ship when net value exceeds priced cost.
            if best_i is None:
                return None
            if policy in ("shadow_bool", "artifact_shadow") and best_score <= 0.0:
                return None
            return best_i

        # Ship changes until no feasible improvement.
        shipped_this_day = 0
        while True:
            i = choose_next()
            if i is None:
                break
            c = q[i]
            idx = c.impacted_idx
            if bool_frac_after(idx) > D_cap + 1e-12:
                # Can't ship this now; if FIFO, stop; otherwise remove infeasible and continue.
                if policy == "fifo":
                    break
                q.pop(i)
                continue

            # Accept.
            q.pop(i)
            shipped_today.append(c)
            backlog[idx] += 1
            shipped_count += 1
            shipped_this_day += 1

            delay = d - c.day
            value += discounted_value(c.value, delay, tau)

            # For FIFO, keep going in order.
            if policy == "fifo":
                continue

            # Stop if we're near the cap and the remaining candidates are low score.
            if np.count_nonzero(backlog > 0) / max(1, N) >= D_cap - 1e-3:
                # Still allow another pass in case there's a zero-marginal-bool change.
                pass

            if shipped_this_day >= max_ship_per_day:
                break

        # Update price signals.
        cur_bool = float(np.count_nonzero(backlog > 0)) / max(1, N)
        cur_churn = float(backlog.sum()) / max(1, N)

        # Single boolean price.
        if policy in ("shadow_bool", "artifact_shadow"):
            ratio = cur_bool / max(1e-9, D_cap)
            p0 *= float(np.exp(eta * (ratio - 1.0)))
            p0 = float(np.clip(p0, 1e-4, 1e4))

        # Artifact prices track artifact-specific churn pressure.
        if policy == "artifact_shadow":
            for a in list(pA.keys()):
                idx = get_idx(a)
                if idx.size == 0:
                    continue
                pressure = float(backlog[idx].sum()) / max(1, N)
                tgt = max(1e-6, targetA.get(a, target_churn_total / max(1, len(pA))))
                pA[a] *= float(np.exp(eta * (pressure / tgt - 1.0)))
                pA[a] = float(np.clip(pA[a], 1e-4, 1e4))
            # Background price on everything else uses total churn.
            p_other *= float(np.exp(0.5 * eta * (cur_churn / max(1e-6, target_churn_total) - 1.0)))
            p_other = float(np.clip(p_other, 1e-4, 1e4))

        daily_bool[d] = cur_bool
        daily_churn[d] = cur_churn

    end_backlog = len(q)

    return {
        "policy": policy,
        "value": float(value),
        "shipped": int(shipped_count),
        "end_backlog": int(end_backlog),
        "p50_bool": pctl(daily_bool, 0.50),
        "p95_bool": pctl(daily_bool, 0.95),
        "p50_churn": pctl(daily_churn, 0.50),
        "p95_churn": pctl(daily_churn, 0.95),
        "series_bool": daily_bool,
        "series_churn": daily_churn,
    }


def write_table(path: Path, rows: List[Dict[str, Any]], cap: float) -> None:
    def fmt(x: float) -> str:
        return f"{x:.3f}"

    order = ["fifo", "value_greedy", "shadow_bool", "artifact_shadow"]
    rows = sorted(rows, key=lambda r: order.index(str(r["policy"])) if str(r["policy"]) in order else 99)

    names = {
        "fifo": "FIFO gate",
        "value_greedy": "Value/$\\Delta$ bool",
        "shadow_bool": "Shadow price (bool)",
        "artifact_shadow": "Artifact-aware (bool+churn)",
    }

    lines: List[str] = []
    lines.append("% Auto-generated by tools/assurance_adc_artifact_churn_v263.py")
    lines.append("\\begin{tabular}{lrrrrrr}")
    lines.append("\\toprule")
    lines.append(f"Policy (D\\_cap={cap:.2f}) & Value & Shipped & End backlog & P95 bool & P95 churn & P50 churn \\\\")
    lines.append("\\midrule")
    for r in rows:
        lines.append(
            f"{names.get(r['policy'], r['policy'])} & {fmt(r['value'])} & {int(r['shipped'])} & {int(r['end_backlog'])} & {fmt(r['p95_bool'])} & {fmt(r['p95_churn'])} & {fmt(r['p50_churn'])} \\\\")
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--abom", default="examples/fleet_abom_v165_policy_shared.json")
    ap.add_argument("--scope-prefix", default="O_sys_")
    ap.add_argument("--days", type=int, default=240)
    ap.add_argument("--window", type=int, default=30)
    ap.add_argument("--capacity", type=int, default=180, help="Work units cleared per day")
    ap.add_argument("--lam", type=float, default=12.0, help="Mean changes/day")
    ap.add_argument("--tau", type=float, default=14.0, help="Value decay timescale (days)")
    ap.add_argument("--lambda-bool", type=float, default=18.0, help="Boolean invalidation price scale")
    ap.add_argument("--lambda-churn", type=float, default=4.0, help="Churn price scale")
    ap.add_argument("--target-churn-total", type=float, default=0.25, help="Target steady churn (work/N)")
    ap.add_argument("--top-k", type=int, default=15)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--out-fig-value", default="figs/assurance_adc_churn_value_v263.pdf")
    ap.add_argument("--out-fig-p95", default="figs/assurance_adc_churn_p95_v263.pdf")
    ap.add_argument("--out-tex", default="tables/assurance_adc_churn_summary_v263.tex")
    args = ap.parse_args()

    abom = load_json(ROOT / args.abom)
    oids, rev = build_rev_maps(abom, args.scope_prefix)
    N = len(oids)
    if N <= 0:
        raise SystemExit("No scoped obligations found")

    # Artifact list (only those that impact something in scope).
    artifacts = [a for a in (abom.get("artifacts") or []) if isinstance(a, dict) and a.get("id")]
    aids = [str(a["id"]) for a in artifacts if str(a["id"]) in rev]

    br = {aid: float(rev[aid].size) / max(1, N) for aid in aids}
    aids_sorted = sorted(aids, key=lambda a: br.get(a, 0.0), reverse=True)
    top_artifacts = set(aids_sorted[: max(1, args.top_k)])

    artifacts_by_kind: Dict[str, List[str]] = {"prompt": [], "retr": [], "policy": [], "global": []}
    for aid in aids:
        k = artifact_kind(aid)
        if k in artifacts_by_kind:
            artifacts_by_kind[k].append(aid)

    rng = np.random.default_rng(args.seed)
    arrivals = make_change_stream(
        rng=rng,
        days=args.days,
        lam_per_day=args.lam,
        artifacts_by_kind=artifacts_by_kind,
        rev=rev,
        N=N,
    )

    # Sweep boolean caps (assurance budgets).
    caps = np.linspace(0.05, 0.55, 11)
    policies = ["fifo", "value_greedy", "shadow_bool", "artifact_shadow"]

    series_value: Dict[str, List[float]] = {p: [] for p in policies}
    series_p95_churn: Dict[str, List[float]] = {p: [] for p in policies}
    series_p95_bool: Dict[str, List[float]] = {p: [] for p in policies}
    end_backlog: Dict[str, List[int]] = {p: [] for p in policies}

    # Normalize value by the best achievable under a very loose cap.
    loose = simulate_policy(
        arrivals=arrivals,
        N=N,
        capacity=args.capacity,
        D_cap=0.95,
        tau=args.tau,
        policy="value_greedy",
        top_artifacts=top_artifacts,
        br=br,
        rev=rev,
        lambda_bool=float(args.lambda_bool),
        lambda_churn=float(args.lambda_churn),
        target_churn_total=float(args.target_churn_total),
        seed=args.seed + 11,
    )
    v_norm = max(1e-9, float(loose["value"]))

    for cap in caps:
        for p in policies:
            out = simulate_policy(
                arrivals=arrivals,
                N=N,
                capacity=args.capacity,
                D_cap=float(cap),
                tau=args.tau,
                policy=p,
                top_artifacts=top_artifacts,
                br=br,
                rev=rev,
                lambda_bool=float(args.lambda_bool),
                lambda_churn=float(args.lambda_churn),
                target_churn_total=float(args.target_churn_total),
                seed=args.seed + 17,
            )
            series_value[p].append(float(out["value"]) / v_norm)
            series_p95_churn[p].append(float(out["p95_churn"]))
            series_p95_bool[p].append(float(out["p95_bool"]))
            end_backlog[p].append(int(out["end_backlog"]))

    # Plots.
    out_fig_value = ROOT / args.out_fig_value
    out_fig_value.parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(7.2, 4.2))
    for p in policies:
        plt.plot(caps, series_value[p], marker="o", linewidth=1.6, markersize=3, label=p)
    plt.xlabel("Boolean debt cap $D_{cap}$")
    plt.ylabel("Realized discounted value (normalized)")
    plt.title("ADC under a boolean debt cap: value vs cap (v263)")
    plt.ylim(0.0, 1.05)
    plt.grid(True, alpha=0.25)
    plt.legend(fontsize=8, loc="lower right")
    plt.tight_layout()
    plt.savefig(out_fig_value, format="pdf")
    plt.close()

    out_fig_p95 = ROOT / args.out_fig_p95
    out_fig_p95.parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(7.2, 4.2))
    for p in policies:
        plt.plot(caps, series_p95_churn[p], marker="o", linewidth=1.6, markersize=3, label=p)
    plt.xlabel("Boolean debt cap $D_{cap}$")
    plt.ylabel("P95 churn debt (work/N)")
    plt.title("Churn pressure under the same cap (v263)")
    plt.grid(True, alpha=0.25)
    plt.legend(fontsize=8, loc="upper left")
    plt.tight_layout()
    plt.savefig(out_fig_p95, format="pdf")
    plt.close()

    # Representative table at a mid cap.
    cap_star = float(caps[len(caps) // 2])
    reps = [simulate_policy(
        arrivals=arrivals,
        N=N,
        capacity=args.capacity,
        D_cap=cap_star,
        tau=args.tau,
        policy=p,
        top_artifacts=top_artifacts,
        br=br,
        rev=rev,
        lambda_bool=float(args.lambda_bool),
        lambda_churn=float(args.lambda_churn),
        target_churn_total=float(args.target_churn_total),
        seed=args.seed + 23,
    ) for p in policies]

    out_tex = ROOT / args.out_tex
    out_tex.parent.mkdir(parents=True, exist_ok=True)
    write_table(out_tex, reps, cap_star)

    print(json.dumps({
        "abom": args.abom,
        "N": N,
        "days": args.days,
        "capacity": args.capacity,
        "caps": [float(x) for x in caps],
        "top_k": args.top_k,
        "out_fig_value": str(out_fig_value),
        "out_fig_p95": str(out_fig_p95),
        "out_tex": str(out_tex),
    }, indent=2))


if __name__ == "__main__":
    main()
