# JBC demo (v234)

This demo shows a **Judge Bridging Certificate (JBC)** that bounds disagreement between two judges on a committed bridge suite.

## Files
- `suite.jsonl`: bridge suite
- `judge0_labels.jsonl`, `judge1_labels.jsonl`: paired judge labels (binary)
- `jbc.json`: the emitted certificate (includes suite root + a one-sided CP bound on disagreement)

## Run

From repo root:

```bash
python3 tools/jbc_verify_v234.py --cert examples/jbc_demo_v234/jbc.json \
  --suite examples/jbc_demo_v234/suite.jsonl \
  --j0 examples/jbc_demo_v234/judge0_labels.jsonl \
  --j1 examples/jbc_demo_v234/judge1_labels.jsonl
```

You should see `status: ok`.

If you edit any line in `suite.jsonl` or in a labels file, verification should fail closed.
