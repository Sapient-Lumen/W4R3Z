# NUC demo (v197)

This directory demonstrates **Non-Equivocation Certificates (NUCs)**: small, DSSE-signable facts produced by a *monitor* that amortize receipt discovery.

## Files

- `receipt_cache_ok/`: a receipt-cache directory containing **exactly one** MER.
- `receipt_cache_ok_index.json`: Receipt Cache Index (RCI) built from `receipt_cache_ok/`.
- `nuc_ok_dsse.json`: NUC issued over `receipt_cache_ok_index.json` (matches = 1).
- `nuc_ok_verify_summary.json`: verification summary for `nuc_ok_dsse.json`.

- `nuc_equivocation_dsse.json`: NUC issued over the `examples/mer_demo/receipt_cache_index.json` corpus (matches = 2).
- `nuc_equivocation_verify_summary.json`: verification summary (shows `nonEquivocation=false`).

- `mvs_single_via_nuc.json`: MER Verification Summary (MVS) produced by `tools/mer_verify.py` using `--nuc` (offline uniqueness satisfied).
- `mvs_single_via_nuc_equivocation.json`: MVS produced using `nuc_equivocation_dsse.json` (fails uniqueness).

## Reproduce

```bash
# Build a cache index
python3 tools/receipt_cache.py --in-dir examples/nuc_demo/receipt_cache_ok \
  --out examples/nuc_demo/receipt_cache_ok_index.json --rel-paths

# Issue a NUC
python3 tools/nuc_issue.py --index examples/nuc_demo/receipt_cache_ok_index.json \
  --abom-digest sha256:... --run-id run-... --obligation-id obl:... \
  --ed25519-private-key examples/mer_demo/ed25519_sk.pem \
  --out examples/nuc_demo/nuc_ok_dsse.json

# Verify the NUC
python3 tools/nuc_verify.py --nuc examples/nuc_demo/nuc_ok_dsse.json \
  --ed25519-public-key examples/mer_demo/ed25519_pk.pem \
  --expect-abom-digest sha256:... --expect-run-id run-... --expect-obligation-id obl:...

# Verify a MER *with* offline uniqueness via NUC
python3 tools/mer_verify.py --abom-digest sha256:... --mer examples/mer_demo/mer_single_signed.json \
  --ed25519-public-key examples/mer_demo/ed25519_pk.pem \
  --nuc examples/nuc_demo/nuc_ok_dsse.json --nuc-public-key examples/mer_demo/ed25519_pk.pem \
  --enforce-unique
```
