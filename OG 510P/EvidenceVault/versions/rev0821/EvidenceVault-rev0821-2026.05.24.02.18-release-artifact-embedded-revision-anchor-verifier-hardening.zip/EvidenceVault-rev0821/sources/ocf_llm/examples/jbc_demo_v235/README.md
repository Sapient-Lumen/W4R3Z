# JBC demo (v235)

This demo shows a *generalized* Judge Bridging Certificate (JBC) with multiclass labels (`win`/`lose`/`tie`).

## Files
- `bridge_suite_v1.jsonl`: bridge suite (10 cases)
- `judge0_labels_v1.jsonl`, `judge1_labels_v1.jsonl`: paired judge labels (multiclass)
- `scoremap_winrate_v1.json`: score map for win-rate (`win`=1, `lose`=0, `tie`=1/2)
- `jbc_demo_v1.json`: emitted certificate

## Reproduce
```bash
python3 tools/jbc_emit_v235.py \
  --id JBC_demo_v235_1 \
  --suite examples/jbc_demo_v235/bridge_suite_v1.jsonl \
  --j0    examples/jbc_demo_v235/judge0_labels_v1.jsonl \
  --j1    examples/jbc_demo_v235/judge1_labels_v1.jsonl \
  --score-map examples/jbc_demo_v235/scoremap_winrate_v1.json \
  --out   examples/jbc_demo_v235/jbc_demo_v1.json

python3 tools/jbc_verify_v235.py --cert examples/jbc_demo_v235/jbc_demo_v1.json
```
