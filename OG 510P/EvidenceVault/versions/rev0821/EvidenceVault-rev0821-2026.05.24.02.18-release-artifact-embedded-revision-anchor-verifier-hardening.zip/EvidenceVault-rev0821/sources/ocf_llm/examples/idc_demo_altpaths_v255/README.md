# IDC demo: alternative compliance paths (v255)

Files:
- `report.json`: per-fixture newly failing IDs + naive vs optimized repair actions/cost.
- `tables/idc_toy_altpaths_repair_cost_v255.tex`: LaTeX table for the paper.
