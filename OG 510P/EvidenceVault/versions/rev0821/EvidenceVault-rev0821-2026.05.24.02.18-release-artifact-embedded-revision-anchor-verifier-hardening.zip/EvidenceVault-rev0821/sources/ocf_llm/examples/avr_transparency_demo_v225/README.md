# AVR transparency demo (v225)

This folder demonstrates **append-only transparency** for Axis Verification Receipts (AVR)
and a minimal **keyed non-equivocation monitor**.

- `log.jsonl`: append-only log of leaves `{statementId, subjectDigest}`.
- `step1/`, `step2/`: two AVRs signed by the same issuer **under the same statementId**.
- `verify_step*.json`: both pass signature + inclusion verification.
- `equivocation_report.json`: monitor detects that the same statementId has multiple digests.

Reproduce from repo root:

```bash
python3 tools/avr_transparency_demo_v225.py
```
