# Drift budget demo (v203)

This folder demonstrates **drift budgets**: SRE-style error budgets applied to
**policy drift debt** computed by Interface Drift Certificates (IDCs).

Artifacts:
- `cache.json`: a synthetic receipt cache (200 endpoints) with `issuedAt` timestamps.
- `idc_30_to_7.json`: IDC for tightening freshness from 30d → 7d.
- `idc_7_to_1.json`: IDC for tightening freshness from 7d → 1d.
- `timeline.json`: drift budget thresholds + the IDC sequence.
- `drift_budget_report.json`: budget check output.

Reproduce:
```bash
# from repo root
python3 tools/interface_drift_delta_cert_v201.py \
  --old-profile profiles/delta_scitt_freshness_days30_v1.json \
  --new-profile profiles/delta_scitt_freshness_days7_v1.json \
  --cache examples/drift_budget_demo_v203/cache.json \
  --out examples/drift_budget_demo_v203/idc_30_to_7.json

python3 tools/interface_drift_delta_cert_v201.py \
  --old-profile profiles/delta_scitt_freshness_days7_v1.json \
  --new-profile profiles/delta_scitt_freshness_days1_v1.json \
  --cache examples/drift_budget_demo_v203/cache.json \
  --out examples/drift_budget_demo_v203/idc_7_to_1.json

python3 tools/drift_budget_check_v203.py \
  --timeline examples/drift_budget_demo_v203/timeline.json \
  --out examples/drift_budget_demo_v203/drift_budget_report.json
```
