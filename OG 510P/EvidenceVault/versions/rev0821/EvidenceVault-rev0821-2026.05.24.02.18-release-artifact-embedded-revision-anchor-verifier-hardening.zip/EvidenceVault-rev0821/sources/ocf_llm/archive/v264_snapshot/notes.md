## 2026-02-28 (v264)

- **New metric: hotspot debt (artifact churn).** Extended churn debt to an artifact-localized tail-risk signal: for artifact $a$, $churn_a(t)=\sum_{i\in rev(a)} backlog_i(t)/N$ and hotspot churn $H_t=\max_{a\in\mathcal{A}_{top}} churn_a(t)$ over the TopK highest-blast-radius artifacts. This captures the operational failure mode where a small shared artifact set stays continuously ``hot'' and dominates tail governance load.
- **New controller: multi-budget admission control.** Added a *vector budget* that enforces (i) the existing fail-closed boolean cap $D_{cap}$ and (ii) per-artifact churn caps for TopK artifacts (scaled by blast radius). This turns ``audit locality'' rankings into actionable governance constraints.
- **New benchmark harness:** added `tools/assurance_adc_hotspot_multibudget_v264.py`.
  - Generates: `figs/assurance_adc_hotspot_frontier_v264.pdf`, `figs/assurance_adc_hotspot_trace_v264.pdf`, `tables/assurance_adc_hotspot_summary_v264.tex`.
  - Writes a reproducibility capsule: `examples/assurance_adc_hotspot_run_v264.json`.
- **Paper updates:**
  - `paper_assurance_admission_control.tex`: new v264 section on hotspot debt + multi-budget gating with the new figures/table.
  - `paper_assurance_debt.tex` and `paper_audit_locality.tex`: tie heavy-tail locality to hotspot budgets as the next control-plane primitive.
  - `paper.tex`: short unifying paragraph on vector assurance budgets and hotspot debt.
- **Bib refresh:** added canonical references for online primal-dual packing and multi-resource fairness to motivate vector budgets.

---

## 2026-02-28 (v263)

- **New metric: churn debt.** Extended the assurance-debt observable beyond set-union invalidation ("claim currently uncertified") to a *work/backlog* signal: each shipped change adds validation work units to impacted claims, and limited recertification capacity clears work over time. This captures the operational failure mode where repeatedly-hot shared artifacts create perpetual review/eval/edit churn even when boolean invalidation stays bounded.
- **New benchmark harness:** added `tools/assurance_adc_artifact_churn_v263.py`, a churn-sensitive ADC simulator grounded in the fleet ABOM archive (default: `examples/fleet_abom_v165_policy_shared.json`).
  - Generates: `figs/assurance_adc_churn_value_v263.pdf`, `figs/assurance_adc_churn_p95_v263.pdf`, `tables/assurance_adc_churn_summary_v263.tex`.
  - Writes a reproducibility capsule: `examples/assurance_adc_churn_run_v263.json`.
- **Risk-taking controller:** introduced an *artifact-aware* shadow-price policy that prices churn on the top-$K$ blast-radius artifacts (from the ABOM impact map) to explicitly target the shared-tail drivers of governance load.
- **Paper updates:**
  - `paper_assurance_admission_control.tex`: new "Churn-sensitive debt + artifact-aware prices" section + figures/table.
  - `paper_assurance_debt.tex`: new "Churn debt" paragraph connecting debt to rework/queue pressure.
- **Bib refresh:** added a canonical online allocation reference (Mehta et al., JACM 2007, AdWords / generalized online matching).

---

## 2026-02-28 (v262)

- **Blast-radius attribution (new):** added `tools/blast_radius_attribution_v262.py` to compute *deterministic* blast radius (impacted top-level claim fraction) for each artifact in a fleet ABOM, plus a Pareto concentration plot and summary table.
  - New artifacts: `figs/blast_radius_pareto_v262.pdf`, `tables/blast_radius_attribution_summary_v262.tex`.
  - Integrated into both `paper_audit_locality.tex` and `paper_assurance_debt.tex` as an actionable ``refactor target'' view of tail locality.
- **ADC oracle baseline (new):** added `tools/assurance_adc_oracle_bench_v262.py` implementing an *exact within-day* submodular knapsack solver over the top-$M$ pending changes, yielding a strong comparator for online heuristics.
  - New artifacts: `figs/assurance_adc_oracle_gap_v262.pdf`, `tables/assurance_adc_oracle_summary_v262.tex`.
  - Integrated into `paper_assurance_admission_control.tex` to quantify the remaining gap to a strong baseline.
- **Paper hygiene:** fixed an accidental LaTeX nesting bug in `paper_assurance_debt.tex` (a proposition inside a table environment).

---

## 2026-02-28 (v261)

- **New companion paper:** added `paper_audit_locality.tex` (*Audit Locality for AI Assurance*), extracting the impact-query / locality-engineering story into a standalone systems-style draft.
  - Reuses existing scaling + realistic + tail locality artifacts (`figs/audit_locality_*` and `tables/audit_locality_*`).
- **ADC strengthened (new policy + new sweep):** added a lightweight **shadow-price** (primal-dual flavored) controller and a budget sweep harness `tools/assurance_adc_budget_sweep_v261.py`.
  - New artifacts: `figs/assurance_adc_budget_sweep_v261.pdf`, `tables/assurance_adc_budget_sweep_summary_v261.tex`.
  - `paper_assurance_admission_control.tex` updated: shadow-price subsection + proposition, swapped in the budget-sweep figure/table, and added cATO analogy.
- **Assurance Debt strengthened:** added a simple **workload-queue** framing linking debt to recertification throughput, plus cATO and continuous assurance-case tooling citations.
- **Bib refresh:** added primary refs for online primal-dual packing (Buchbinder--Naor), DoD cATO docs, and queueing stability background.

---

## 2026-02-28 (v260)

- **New companion paper:** added `paper_assurance_admission_control.tex`, turning the control-loop story into an explicit online allocation problem (maximize discounted value under an assurance budget), with runnable benchmark artifacts.
- **New empirical/time-series artifact:** added a *change-log replay* harness (`tools/assurance_debt_replay_v260.py`) that computes daily max assurance debt and rolling burn directly from a fleet ABOM via conservative impact queries (new fig `figs/assurance_debt_replay_v260.pdf`, new table `tables/assurance_debt_replay_summary_v260.tex`, new JSON trace `examples/assurance_debt_replay_v260.json`).
- **New ADC benchmark:** `tools/assurance_adc_frontier_v260.py` compares FIFO gating vs value-aware greedy vs tiered token-bucket policies under the same assurance budget (new fig `figs/assurance_adc_frontier_v260.pdf`, new table `tables/assurance_adc_summary_v260.tex`).
- **Assurance Debt paper strengthened:** added a tail-dominance proposition (why rare shared updates pin tail SLOs) and integrated the change-log replay as an operational telemetry example; updated EU AI Act post-market monitoring text to reference Article 72's template deadline.
- **Suite bump:** updated all draft stamps to **v260** for coherence.

---

## 2026-02-28 (v259)

- **Assurance Debt paper strengthened:** added a *capacity-planning / tail-coupling* empirical section tying assurance debt to SRE-style recertification budgets (new fig `figs/assurance_debt_capacity_v259.pdf`, new table `tables/assurance_debt_capacity_summary_v259.tex`).
- **New reproducible artifacts:** `tools/assurance_debt_capacity_v259.py` (simulation) and `tools/assurance_debt_metric_v259.py` (compute impacted-claim fraction from ABOM + change set).
- **Research refresh:** added citations for dynamic assurance-case management (OntoGSN), AMLAS, NIST AI RMF (and GenAI Profile), and ISO/IEC 42001 to tighten the governance/continuous-monitoring positioning.
- **Suite bump:** updated all draft stamps to **v259** for coherence.

---

## 2026-02-28 (v258)

- **New companion paper:** added `paper_assurance_debt.tex`, extracting and sharpening the *Assurance Debt* / *Assurance SLO* / *governance control-loop* story into a focused submission draft.
- **Suite version bump:** bumped paper-suite date strings to **v258** (`paper.tex`, `paper_idc.tex`, `paper_discovery.tex`, etc.) and updated `README.md` accordingly.
- **Bibliography expansion:** added canonical citations for *Hidden Technical Debt in ML Systems* and an evolving assurance-case methodology (ACCESS) to position assurance debt vs. technical debt and safety-case maintenance.

---

## 2026-02-28 (v257)

- **IDC planning hardness + stronger baselines:** `paper_idc.tex` adds an NP-hardness note for cheapest repair planning (via a weighted set cover special case), and a stronger fast baseline (**satisfy-greedy**) alongside the share-aware optimizer.
- **New optimizer + benchmark:** added `tools/idc_optimizer_v257.py` (satisfy-greedy + local-search + exact) and `tools/idc_synth_bench_v257.py` (new table `tables/idc_synth_bench_v257.tex` and new figures `figs/idc_synth_cost_none_v257.png`, `figs/idc_synth_runtime_none_v257.png`).
- **Paper-suite bump:** bumped `paper.tex`, `paper_idc.tex`, and `paper_discovery.tex` to **v257** for coherence.

---

## 2026-02-28 (v255)

- **Cost-aware repair planning (new):** `tools/idc_demo_article53_v255.py` adds a cost-aware layer on top of minimal repair slicing: treat some constraint structures (notably `anyOf`) as \emph{alternative evidence pathways} and minimize total recertification cost under a simple (pluggable) cost model. Generates `tables/idc_article53_repair_cost_v255.tex`.
- **Alternative-paths case study (new):** `profiles/toy_altpaths_v1.json` $
ightarrow$ `profiles/toy_altpaths_v2.json` introduces an `anyOf` requirement (either a `model_card` artifact or an `EIC_latency_v1` certificate). `tools/idc_demo_altpaths_v255.py` demonstrates that a naive plan does both, while the optimizer selects the cheaper clause; outputs `tables/idc_toy_altpaths_repair_cost_v255.tex`.
- **Paper update:** `paper_idc.tex` adds the cost-aware table, an `anyOf` subsection, and brief positioning vs. regression test selection / safety-case maintenance.

---

## 2026-02-28 (v254)

- **IDC minimal repair plan (new):** `tools/idc_demo_article53_v254.py` extends the Article~53 IDC demo with a *minimal repair slice*: it separates (i) obligations that must be rerun to mint missing/new evidence from (ii) prerequisite obligations whose certificates already exist and can be reused. Generates `tables/idc_article53_repair_v254.tex` alongside updated impact/closure tables.
- **Paper update:** `paper_idc.tex` and the main paper now distinguish *impact closure* (for audit locality) from an actionable *repair plan* (for rollout planning and drift budgets).

---

## 2026-02-28 (v253)

- **IDC impact closure (new):** `tools/idc_demo_article53_v253.py` extends the Article 53 IDC demo with an *obligation-graph impact closure*: newly failing constraint IDs map to implicated ABOM nodes (certs, obligations, artifacts), and we compute prerequisite + dependent obligation closure. Generates `tables/idc_article53_impact_v253.tex` and `tables/idc_article53_closure_v253.tex`, and writes detailed per-fixture closure reports under `examples/idc_demo_article53_v253/`.
- **Paper update:** `paper_idc.tex` now includes the closure table and a short explanation of the structural point: stable requirement IDs + explicit obligation dependencies let IDCs commit to localized, replayable slices instead of opaque deltas.
- **Bug fix:** `tools/profile_check.py` fixed a missing helper reference for `anyPointLeq` constraints (uses `_collect_frontier_points`).
- **Bib refresh:** updated the KeyTrans architecture citation to draft-ietf-keytrans-architecture-07 (Feb 2026).

---

## 2026-02-28 (v251)

- **ADCP made enforceable (not just verifiable):** added a small **conformance gate** `tools/ocf_discovery_adcp_gate_v251.py` that validates discovery receipts offline *and* enforces ADCP-style bounds (allowed proof modes, depth, and a proof-size cap), plus optional SDT/MID liveness checks via stapled SDTs.
  - New profile: `profiles/discovery_adcp_profile_v251.json`.
- **Discoverability vector bundle expanded:** new generator `tools/ocf_discovery_conformance_vectors_v251.py` writes `examples/discovery_conformance_v251/` with additional vectors (absence verification, oversize-but-valid proof rejection, SDT/MID pass/fail, split-view detection).
  - New summary table: `tables/discovery_conformance_vectors_v251.tex` and `paper_discovery.tex` updated to reference the v251 bundle.
- **Concrete IDC worked example:** added `tools/idc_demo_article53_v251.py` which emits a toy IDC for the EU AI Act GPAI Article 53 profile update (v1→v2) and replays a small ABOM fleet sample under both profiles.
  - Outputs `examples/idc_demo_article53_v251/` and generates `tables/idc_article53_impact_v251.tex`, now included in `paper_idc.tex`.
- **Paper-suite bump:** bumped `paper.tex`, `paper_idc.tex`, and `paper_discovery.tex` to **v251** and updated the main paper’s contribution bullets to explicitly include **IDCs** and the **ADCP gate**.

---

## 2026-02-28 (v250)

- **Paper-suite coherence pass:** bumped `paper.tex`, `paper_idc.tex`, and `paper_discovery.tex` to **v250** and tightened the cross-links between the main OCF-LLM paper, the IDC companion, and the discoverability companion.
- **Runnable discoverability vectors made legible in the paper:** added `tables/discovery_conformance_vectors_v250.tex`, a compact summary table of the shipped ADCP conformance vectors (generated from `examples/discovery_conformance_v249/vectors.json`).
- **Discoverability companion strengthened:** expanded the conformance section to treat the vector bundle + offline runner as the intended auditor/implementer harness, not just an appendix artifact.
- **Main + IDC papers strengthened:** main paper now lists accountable discoverability conformance (ADCP + vectors/runner) as a first-class contribution; IDC paper now explicitly points to the shipped runner/vectors in `paper_discovery.tex`.

---

## 2026-02-28 (v249)

- **Accountable discoverability made testable:** added a new section to `paper_discovery.tex` defining an **Accountable Discoverability Conformance Profile (ADCP)** and a minimal **conformance matrix** (portable presence/absence, bounded proofs, witnessed checkpoints, SDT/MID liveness).
  - New table: `tables/discovery_conformance_matrix_v249.tex` (generated).
  - New tools:
    - `tools/ocf_discovery_conformance_vectors_v249.py` (machine-readable test vectors)
    - `tools/ocf_discovery_conformance_runner_v249.py` (offline fixture runner / service harness skeleton)
- **Ecosystem grounding refreshed:** replaced hand-wavy tile-log references with the **C2SP tlog-tiles** and **tlog-witness** specs as primary sources for static-asset transparency read APIs and witness cosigning.
- **Main + IDC papers strengthened:** both now explicitly treat **ADCP + test vectors** as driftable interfaces that should be pinned and evolved under IDC histories, and point to `paper_discovery.tex` for the full model.

---

## 2026-02-28 (v248)

- **New companion paper:** added `paper_discovery.tex` (*Accountable Discoverability for AI Assurance*), a standalone writeup that treats **evidence lookup as a security property** and develops the log-backed-map + discovery-receipt + SDT/MID design with an explicit threat model and integration points for MERs and output credentials.
  - Includes the **discovery receipt sizing** table and **split-view checkpoint detection budgets** table by reusing the generated artifacts already in `tables/`.
- **Main paper strengthening:** updated the **verification DoF** table to include **discoverability / indexing drift** as its own failure mode, and added an explicit pointer to the new companion note in the discoverability section.
- **IDC strengthening:** `paper_idc.tex` now explicitly frames evidence-discovery contracts (query semantics, presence/absence proofs, indexing deadlines) as a driftable interface surface that can be pinned and evolved under IDC histories.
- **Bib hygiene:** made KeyTrans citations version-specific and stable (architecture draft-07 and protocol draft-03 on the IETF datatracker HTML endpoints).

---

## 2026-02-28 (v247)

- **Accountable discoverability, made operational:** strengthened the new *log-backed map + discovery receipt* story by adding a concrete **monitoring budget model** for detecting split-view map checkpoints.
  - Added Proposition~\ref{proposition:map-splitview} (sampling-based split-view detection) and Table~\ref{tab:discovery-splitview-detection} to `paper.tex`.
  - New generator: `tools/discovery_splitview_detection_table_v247.py` → `tables/discovery_splitview_detection_curve_v247.tex`.
- **Research validation pass:** verified two real-world motivators with primary sources and kept the citations wired:
- **Indexing liveness for discoverability:** added a runnable SDT reference artifact and demo:
  - `tools/ocf_discovery_sdt_sign_v247.py` (emit SDT)
  - `tools/ocf_discovery_sdt_verify_v247.py` (verify SDT against a discovery receipt + enforce MID)
  - `tools/ocf_discovery_sdt_demo_v247.py` (writes `examples/discovery_sdt_demo_v247/` with pass/fail)

  - Rekor v2 GA removes the best-effort search index and exposes only `/api/v2/log/entries` (Sigstore blog).
  - Rekor v1 indexing endpoint had an SSRF issue (CVE-2026-24117), reinforcing that “discovery endpoints are part of the attack surface” and should be sandboxed.

---

## 2026-02-28 (v246)

- **Accountable discoverability (new verification DoF):** added a concrete design for making *evidence discovery* itself verifiable, motivated by Rekor v2's removal of the best-effort search index. The core move is to pair the append-only log with a **log-backed map** (verifiable key directory / sparse Merkle map) and return **signed discovery receipts** that prove presence *or absence* for a queried key under a signed map checkpoint.
- **New runnable tools + demo:**
  - `tools/discovery_smt_v246.py` (toy sparse Merkle map, full + default-elided proofs)
  - `tools/ocf_discovery_receipt_gen_v246.py` (emit signed map checkpoint + discovery receipts)
  - `tools/ocf_discovery_receipt_verify_v246.py` (verify receipt signature + SMT proof)
  - `tools/ocf_discovery_drift_monitor_v246.py` (detect map equivocation / query split-view)
  - `tools/ocf_discovery_receipt_demo_v246.py` + `examples/discovery_receipt_demo_v246/` (generates a split-view variant and shows the monitor failing closed)
- **Measurement:** added Table `tables/discovery_receipt_overhead_v246.tex` (generated by `tools/discovery_receipt_overhead_table_v246.py`) to quantify the naive `32*d` proof size and the *expected* number of non-default siblings when default hashes are omitted (sparse proofs), for a large map.
- **Paper updates:** `paper.tex` now treats **discoverability** as a first-class interface surface for output-credential provenance (discovery receipts + optional indexing deadlines), and `paper_idc.tex` expands the drift discussion: query semantics / indexing guarantees are validator-interface commitments that should be pinned and updated via PUT/RUT.
- **Research/bib refresh:** added citations for **Key Transparency** (IETF KeyTrans WG + Trillian log-backed map explanation) and **CONIKS**, grounding the map/receipt design as a known transparency primitive, now applied to AI assurance discovery.

---

## 2026-02-28 (v245)

- **Cost curve for output-credential provenance:** added Fig.~\ref{fig:output-credential-cost-curve} + Table~\ref{tab:output-credential-cost-curve} to summarize the per-output byte tradeoff between (i) per-output receipts, (ii) epoch batching, and (iii) batching + SOT liveness. Generated by the new script `tools/output_credential_cost_curve_v245.py` (outputs `figs/output_credential_cost_curve_v245.pdf` and `tables/output_credential_cost_curve_v245.tex`).
- **Research refresh (validator economics):** tightened the output-credential motivation to reflect that C2PA now operates a **conformance program + official trust list** (launched mid-2025), making validator behavior and trust roots an explicit interface surface. Added bib entry `c2pa_conformance_program_2025`.
- **Liveness parameters as governed commitments:** strengthened the SOT paragraph with an operational CT precedent: Apple's CT log program constrains MMD (24h), highlighting that MMD is a platform policy choice and should be pinned/updated via profile + PUT/RUT. Added bib entry `apple_ct_log_program_2025` and wired it into both `paper.tex` and `paper_idc.tex`.

---

## 2026-02-28 (v244)

- **CT-style liveness for batched output credentials:** introduced **Signed Output Timestamps (SOTs)**, a compact issuer-signed promise (credCoreDigest, serviceId, issuedAt, MMD) adapted from CT’s SCT+Maximum-Merge-Delay idea (RFC 6962). Verifiers can now fail-closed on “publication liveness” by requiring an epoch checkpoint receipt timestamp no later than `issuedAt + mmdSeconds`.
- **New tools:** `tools/ocf_output_sot_sign_v244.py` (emit SOT) and `tools/ocf_output_sot_verify_v244.py` (verify SOT and enforce MMD against a checkpoint receipt for the epoch root).
- **New end-to-end demo:** `tools/ocf_output_credential_batch_sot_demo_v244.py` writes `examples/output_credential_batch_sot_demo_v244/` (sign → batch+staple → log epoch root → SOT → verify signature + inclusion + MMD).
- **Measurement:** added Table `tables/output_credential_sot_overhead_v244.tex` (generated by `tools/output_credential_sot_overhead_table_v244.py`) quantifying the byte overhead of SOTs + amortized checkpoint receipts on top of epoch-batched inclusion paths.
- **Paper updates:** `paper.tex` adds a new “Liveness and selective omission” paragraph + listing + Table~\ref{tab:output-credential-sot-overhead}; `paper_idc.tex` notes that MMD-style liveness parameters are themselves driftable validator-interface commitments that should be pinned by IDC and updated via PUT/RUT.

---

## 2026-02-28 (v243)

- **Epoch-batched output credentials:** added a CT-style Merkle batching mode for signed output credentials to reduce per-output transparency overhead. New tool `tools/ocf_output_credential_batch_v243.py` builds an RFC 9162-style Merkle root over credential *core* digests and can staple inclusion proofs into each credential (`batch` field with `treeSize`, `rootHash`, `leafIndex`, `path[]`).
- **Batch verification:** new verifier `tools/ocf_output_credential_batch_verify_v243.py` composes the v242 signature verifier with RFC 9162 inclusion-proof checks.
- **End-to-end demo (batch + witnessed checkpoint):** `tools/ocf_output_credential_batch_transparency_demo_v243.py` generates N credentials, batches them, logs the batch root in a toy SCITT receipt, and produces a threshold witness-cosigning bundle (WCO) before verifying a stapled credential.
- **Paper updates:** `paper.tex` gains a new scaling subsection + Table `tables/output_credential_batch_overhead_v243.tex` (generated by `tools/output_credential_batch_overhead_table_v243.py`). `paper_idc.tex` adds a drift note: batching/stapling rules are part of the validator interface that should be pinned by IDC.
- **Research/bib:** added citations for the C2PA 2.3 launch + conformance program and the OpenAI steering-committee announcement.


## 2026-02-28 (v242)

- **Signed output credentials (bridged C2PA profile):** replaced the schematic emitter with a runnable signed format: `tools/ocf_output_credential_sign_v242.py` emits a canonical JSON payload (C2PA-shaped: `specVersion`, `subject`, `assertions`) plus an **Ed25519 proof**; `tools/ocf_output_credential_verify_v242.py` verifies signature + output digest binding.
- **Output-credential transparency pipeline:** new end-to-end demo `tools/ocf_output_credential_transparency_demo_v242.py` + `examples/output_credential_demo_v242/` that (i) signs an output credential, (ii) logs the **credential digest** as a `subjectDigest` in a toy SCITT receipt, and (iii) verifies both.
- **Keyed equivocation monitor for outputs:** `tools/ocf_output_credential_equivocation_monitor_v242.py` detects split-view issuance of multiple distinct credentials for the **same output digest**.
- **Overhead measurement:** added Table~\ref{tab:output-credential-overhead} to `paper.tex` (generated by `tools/output_credential_overhead_table_v242.py`) to quantify the byte overhead of stapling a signed credential + transparency receipt to outputs.
- **Paper refresh:** `paper.tex` now explicitly frames the bridge-to-C2PA mapping via **JUMBF + COSE signatures** and updates the output credential listing/caption to v242; both papers’ draft tags bumped to v242.

---

## 2026-02-28 (v241)

- **Output-bound assurance (new packaging spine):** added \S\ref{sec:output-credentials} to `paper.tex`, showing how ABOM + Minimal Evaluation Receipts (MER) can travel with *outputs* via Content Credentials (C2PA) manifests using an `ocf.abom` assertion (digest pointers + optional transparency handles), with privacy-friendly prompt hashing and selective disclosure.
- **New runnable artifact:** `tools/ocf_output_credential_emit_v241.py` + `examples/output_credential_demo_v241/` generate a schematic C2PA-style output credential (`manifest.json`) that binds a content digest to ABOM/MER digests for consumer-facing provenance demos.
- **IDC expansion:** `paper_idc.tex` now includes a case study framing C2PA validator policies (accepted spec versions, required assertions, trust roots) as a driftable interface that benefits from IDC + PUT/RUT non-equivocating update history.
- **Source sanity-check:** confirmed C2PA spec v2.3 (Dec 2025), SCITT SCRAPI draft-07 (Feb 2026), and Rekor v2 GA notes on removal of best-effort search APIs.

---

## 2026-02-28 (v240)

- **PUT/RUT split-view monitoring, quantified:** added Proposition~\ref{prop:put-sampling} + Table~\ref{tab:put-sampling-detection} (generated by `tools/put_gossip_detection_curve_v240.py`) to bound how quickly *sampling-based gossip* detects transparency-log split views under modest monitoring budgets (monitors × samples/day).
- **Witness cosigning spine:** strengthened PUT/RUT non-equivocation discussion in both `paper.tex` and `paper_idc.tex` by explicitly treating *witness-threshold cosigned STHs* (Sigsum / witness-network patterns) as the operational complement to gossip; added a concrete witness-blog citation.
- **Bibliography refresh:** added `su3_witness_sigstore_eth_2024` and wired it into the drift/non-equivocation sections.

---

## 2026-02-27 (v239)

- **Stronger non-equivocation spine:** promoted *keyed equivocation* to a first-class verification DoF and added a simple proposition (receipt-level detectability) to `paper.tex`, plus explicit pointers to the new receipt-only monitor `tools/pcb_equivocation_monitor_v238.py`.
- **IDC companion deepening:** `paper_idc.tex` now treats *discovery drift* as an explicit interface hazard (using Rekor v2's no-index design as a concrete example) and adds a small theorem that frames PUT/RUT consistency proofs as *public equivocation witnesses* under CT/RFC 9162 semantics.
- **Research refresh (sources sanity-check):** verified the live status of the key motivating facts used in the interface-drift sections (Rekor v2 GA note on removing the search index; EC pages on Digital Omnibus/AI Act standardisation; AI Act Service Desk Article 6 guidance deadline language).

---

## 2026-02-27 (v238)

- **Equivocation monitoring from receipts (PCB):** added `tools/pcb_equivocation_monitor_v238.py`, a fail-closed monitor that detects keyed equivocation (same `(serviceId, statementId)` bound to multiple `subjectDigest` values) directly from stapled transparency receipts.
- **New runnable demo:** `examples/pcb_equivocation_demo_v238/` generates two valid receipts that reuse the same `statementId` with different subject digests, and shows the monitor producing an `ok=false` report.
- **Paper updates:** `paper_pcb.tex` now includes an explicit proposition on receipt-level equivocation detectability and points to the monitor + demo; `paper.tex` references the new monitor and demo.
- **Build note:** the monolithic `paper.tex` build is heavy (many embedded listings) and was not recompiled in this container run; compile locally via `latexmk -pdf paper.tex`. The smaller `paper_occ.pdf` and `paper_idc.pdf` are up to date.

---

## 2026-02-27 (v237)

- **Policy-driven PCB:** added a registry-side gate `tools/pcb_registry_gate_v237.py` that enforces a published PCB policy (`schemas/pcb_policy_v1.schema.json`) instead of trusting the submitter's `requires` list.
- **Transparency stapling for PCB:** PCB bundles can now optionally staple SCITT-style receipts (`logReceipts`) and registries can require them per-policy (verified via `tools/scitt_receipt_verify_v237.py`).
- **New runnable demo:** `examples/pcb_policy_demo_v237/` shows policy-as-code + stapled inclusion proof over a bundle subject digest.
- **Schema updates:** `schemas/pcb_bundle_v1.schema.json` now allows optional `policyHint` and `logReceipts`.

Open thread:
- Decide whether certificate digests in the PCB subject should be computed over canonical JSON (float-free) or over raw bytes; current gate uses canonical JSON but allows floats for legacy demo certs.

---

## 2026-02-27 (v236)

- **New companion paper:** `paper_pcb.tex` (Proof-Carrying Benchmarks / fail-closed claim display).
- **FSER prototypes:** added `tools/ccr_emit_v236.py`, `tools/ccr_verify_v236.py`, `tools/eoc_emit_v236.py`, `tools/eoc_verify_v236.py`, plus `examples/fser_demo_v236/`.
- **PCB bundle tooling:** added `tools/pcb_bundle_verify_v236.py` and `examples/pcb_demo_v236/` (bundle verifies EIC+JBC+CCR+EOC and checks EOC↔CCR binding).
- **Generalized JBC refresh:** added `tools/jbc_emit_v236.py`, `tools/jbc_verify_v236.py` with typed scalar label keys and a refreshed `examples/jbc_demo_v236/`.
- **Schemas:** added `schemas/` with minimal JSON Schemas for CCR/EOC/JBC and PCB bundles.

---

## 2026-02-27 (v235)

**Generalized judge drift bridging (transport for multiclass/scalar judging).**
- Upgraded JBC from binary-only to **multiclass** (and bounded-score) transport:
  - New tools: `tools/jbc_emit_v235.py`, `tools/jbc_verify_v235.py`
  - New demo: `examples/jbc_demo_v235/` (win/lose/tie + win-rate score map)
- Paper updates:
  - `paper_eic.tex`: adds a **general transport proposition** for any bounded score function of judge outputs and notes confusion-matrix emission.
  - `paper.tex`: updates JBC subsection + prototype pointers to v235 and clarifies non-binary labels are supported.

**Restored companion artifact.**
- Restored `paper_idc.tex` (Interface Drift Certificates companion) into the evolving archive.

---

## 2026-02-27 (v234)

**New companion papers + verifiable prototypes.**
- Added two companion LaTeX papers:
  - `paper_eic.tex`: **Evaluation Integrity Certificates** (EIC) + **Judge Reliability** (JRC) + **Judge Bridging** (JBC).
  - `paper_fser.tex`: **Full-Stack Evaluation Receipts** (FSER) for agentic systems (channel coverage + egress outcomes).
- New verifiable prototype tools + demos:
  - EIC: `tools/eic_emit_v234.py`, `tools/eic_verify_v234.py`, demo `examples/eic_demo_v234/`
  - JRC: `tools/jrc_emit_v234.py`, `tools/jrc_verify_v234.py`, demo `examples/jrc_demo_v234/`
  - JBC: `tools/jbc_emit_v234.py`, `tools/jbc_verify_v234.py`, demo `examples/jbc_demo_v234/`
- Updated `paper.tex`:
  - Added a JBC subsection to treat **judge drift** as an explicit interface change (default: non-comparable unless bridged).
  - Added citations for *Silent Egress* (implicit prompt injection → stealth network exfil) and recent LLM-judge bias/control papers.
- Added bibliography entries for Feb 2026 arXiv judge papers (FairJudge, BiasScope, SCOPE), Silent Egress, and test-time best-of-$N$ sampling work.

---

## 2026-02-27 (v228)

**Make ABOM's novelty legible: ABOM as an obligation-carrying xBOM.**
- Added Table `\ref{tab:bom-comparison}` (new `tables/bom_comparison_v228.tex`) to crisply distinguish ABOM from Model Cards/Datasheets, AI/ML-BOM standards (SPDX/CycloneDX), model signing/provenance, and risk-scanning frameworks (e.g., AIRS).
- Strengthened Related Work to cite **OpenSSF Model Signing v1.0** and note CycloneDX v1.6's Ecma standardization milestone as part of the broader xBOM ecosystem.
- Added a concrete example of *governance artifact drift* in the Introduction: NIST’s AIRC notes that **AI RMF 1.0 is being revised**, motivating digest-pinned profiles and replayable conformance rules.

**New paper artifact (optional):**
- Added `paper_extended_abstract.tex` as a compact, submission-friendly summary that reuses the same bibliography.

---

## 2026-02-27 (v226)

**Related-work strengthening: AI BOMs vs obligation-carrying assurance.**
- Added a short comparison in Related Work situating ABOM relative to emerging **AI Bill of Materials** and assurance-scanning work (notably the **AIRS framework**, arXiv:2511.12668).
- Clarified the paper's core claim in that comparison: BOMs inventory *what is in the system*; ABOMs additionally encode *what must be true about it* (typed obligations) and *why to believe it* (digest-bound receipts + fail-closed replay), with **audit-local diffs** that make continuous recertification operational.

**Housekeeping.**
- Bumped draft stamp to **v226** (Feb 27, 2026).

---

## 2026-02-26 (v224)

**New: Axis Verification Receipts (AVR).**
- Added AVR: a **DSSE-signed** in-toto Statement whose predicate is an AVS, with an optional *toy* transparency receipt. This closes a practical verifier DoF: **AVS spoofing / post-hoc summary edits**.
- New tools:
  - `tools/avs_emit.py`: wraps an AVS as a signed AVR and can staple a toy SCITT receipt.
  - `tools/avs_verify.py`: verifies AVR signature + optional receipt and checks ABOM subject binding.
  - `tools/avr_demo_v224.py`: reproducible demo that shows AVR verifies and a tampered AVR fails closed.
- Extended `tools/dof_closure_cert_verified.py` to accept `--avr` inputs, optionally verify signatures/receipts, and (with `--require-avr`) treat AVR validity as part of the publishability gate.

**Paper updates.**
- Added an AVR paragraph and listing (DSSE envelope schematic), updated the verification-DoF table, and strengthened Theorem~\ref{thm:dofcv-avs-gate} to allow AVS to be carried as AVR.

---

## 2026-02-26 (v225)

**AVR transparency that is actually append-only (and monitorable).**
- Added a log-backed SCITT/CT-style receipt backend: `tools/toy_scitt_stmt_log_v225.py` maintains a JSONL append-only log of leaves `{statementId, subjectDigest}` and emits receipts with inclusion + (optional) consistency proofs.
- Added a tiny offline monitor for **keyed non-equivocation**: `tools/scitt_equivocation_check_v225.py` flags any `statementId` that appears with multiple distinct `subjectDigest` values.
- Updated `tools/avs_emit.py` to support `--scitt-log <log.jsonl>` so AVR receipts can be stapled from a real append-only log instead of a synthetic tree.
- New runnable demo bundle: `examples/avr_transparency_demo_v225/` (generated by `tools/avr_transparency_demo_v225.py`) intentionally publishes two conflicting but validly signed AVRs under the same `statementId` and shows that inclusion checks pass while the monitor detects equivocation.

**Paper updates.**
- Updated the AVR section to explicitly describe log-backed receipts + keyed equivocation monitoring and added Listing~\ref{lst:avr-log-demo}.

---

## 2026-02-26 (v221)

**Verification degrees of freedom (beyond protocol DoF closure).**
- Added \S
ef{sec:verify-dof} + Table~
ef{tab:verification-dof}: a compact taxonomy of *verification DoFs* (verifier substitution, plugin omission, config drift, trace truncation, receipt equivocation) and the corresponding OCF-LLM countermeasures (MVS pinning, AVS axis-pass requirements, ETC/EDC trace commitments, QTA/NUC non-equivocation gates).
- Added Theorem~
ef{thm:dofcv-avs-gate}: formalizes **DoFCv+AVS** as a *publishability gate* that is sound against "present-but-unchecked" failures under pinned verifier + sound validators.

**Build-things artifact (paper-backed).**
- Added `tools/sim_verify_dof_microstudy_v221.py` and `tables/verify_dof_microstudy_v221.tex`: a tiny synthetic stress test that illustrates how DoFC/DoFCv can admit manipulated claims when axis checks are omitted, while DoFCv+AVS fails closed.

**Citation hygiene.**
- Corrected the dynamic-longitudinal reference to **LLMEval-3** (arXiv:2508.05452) and updated the **LMArena leaderboard policy** URL (last updated 24 Dec 2025).

---

## 2026-02-26 (v220)

**Verified publication gates: DoFCv + AVS (closing verification DoFs, not just protocol DoFs).**
- Added a **verified DoF-closure certificate (DoFCv)**: a DoFC bound to a pinned **MER Verification Summary (MVS)**, optionally enforcing uniqueness/non-equivocation via transparency discovery. This prevents "present-but-unchecked" or verifier-substitution attacks.
- Added an **Axis Verification Summary (AVS)**: a compact per-axis rollup extracted from a resolver trace that records which receipts were actually verified to close each DoF axis.
- Updated the DoF-closure case study (\S
ef{sec:case-dofc-gate}) to show a concrete issuance flow: residual DoF 
ightarrow AVS 
ightarrow DoFCv.

**Research refresh:**
- Integrated **LiveSearchBench** (dynamic retrieval benchmark generation) and **Inference-Time Decontamination** (reusing leaked suites via rewriting) into both the Introduction and the dynamic-bench case study.
- Added the **Arena leaderboard policy** as an example of governance constraints that can be expressed as executable profiles.

**Build-things artifacts:**
- `tools/dof_closure_cert_verified.py`: emits DoFCv from a residual DoF vector + MVS (and optional AVS).
- `tools/avs_from_trace.py`: derives AVS from a resolver trace YAML.
- Added stable wrapper names (`tools/dof_graph.py`, `tools/dof_closure_cert.py`, etc.) for paper-friendly references.

---

## 2026-02-26 (v216)

**Make DoF-closed evaluation publishable: the DoF-closure certificate (DoFC).**
- Added Table~ef{tab:dof-attack-matrix}: a compact *attack matrix* that treats evaluation integrity as a small set of adversary-controlled protocol DoFs (suite, randomness, judge, selection, stopping), each closed by a specific receipt/certificate family.
- Introduced a portable **DoF-closure certificate (DoFC)** (Listing~ef{lst:dofc}) and a concrete issuance tool `tools/dof_closure_cert_v216.py`. DoFC is meant to be stapled to external reports and used as a **publication gate** (pass/fail-closed under a declared profile digest).
- Added a new case study subsection (\Sef{sec:case-dofc-gate}) showing how DoFC turns leaderboard-chasing freedoms into explicit, machine-checkable failures until the missing stopping/monitoring semantics (CSIC/SSIC or fixed-n waiver) are declared.

**Research refresh:**
- Added contamination-aware benchmark references: rephrased-sample contamination analysis (Yang et al., 2023) and contamination-free benchmark design (MMLU-CF, Zhao et al., 2024).

**Build-things artifacts:**
- `tools/dof_closure_cert_v216.py`: emits a compact DoFClosureCertificate from a residual DoF vector (or directly from an MER).
- `examples/dof_closure_demo_v216/`: runnable demo producing `dofc.json` and an optional in-toto-wrapped DoFC statement.

Open threads:
- Bind DoFC to *verified* receipt summaries (not just structural presence) by ingesting resolver traces / verification summary attestations.
- Add a first-class `stopping` field to MER so the stopping axis can be closed without profile inference.

---

## 2026-02-26 (v215)

**Risky new spine: DoF-closed evaluation as a checkable interface.**
- Added \S\ref{sec:dof-closure}: a formal definition of **DoF-closed evidence** for a target claim, plus a simple **DoF graph** view induced by a Minimal Evaluation Receipt (MER) and its stapled certificates.
- Introduced a resolver-facing object: the **residual DoF vector** (which protocol degrees of freedom are pinned vs missing) and a governance rule template: *external publication requires DoF closure for required axes unless explicitly waived by profile policy*.
- Added Figure~\ref{fig:dof-graph} and Listing~\ref{lst:dof-vector} to make the idea concrete.

**Build-things artifact:**
- `tools/dof_graph_v215.py`: parses an MER (or in-toto statement containing an MER predicate), emits a residual DoF vector, and optionally writes a Graphviz `.dot` protocol graph.
- `examples/dof_graph_demo_v215/`: runnable demo built from `examples/mer_demo/mer_bestof8_signed.json`, producing both fail-closed and fixed-n (profile-waived) variants.

Open threads:
- Tie DoF closure to actual certificate verification summaries (not just presence/structure) by ingesting resolver outputs.
- Extend MER to include an explicit `stopping` / `monitoring` declaration so `CSIC/SSIC` closure can be detected without profile assumptions.

---

## 2026-02-26 (v214)

**Stronger spine: dynamic-eval case study + tighter kernel guarantees.**
- Added a new flagship case study subsection: *Dynamic benchmark banks: contamination, selective disclosure, and time-uniform monitoring* (in \S\ref{sec:casestudies}). This ties together BFC (fresh admissible roots), committed suite sampling, selective disclosure (DSC/DSDC), and anytime-valid monitoring (CSIC), and grounds the motivation in recent dynamic-evaluation and contamination literature (LLMEval-Fair, ConStat, Prism).
- Strengthened \S\ref{sec:travel} by replacing the prior informal trace-soundness statement with a more explicit **replayable fail-closed soundness theorem** plus a monotone-tightening lemma (restricted to admissible/consistent evidence sets). This sharpens the “evidence travels” claim into an auditor-facing guarantee.

**Research:** added a new reference for Prism (dynamic benchmarking with MCTS) and integrated it in both the new case study and Related Work.

---

## 2026-02-26 (v213)

**New core formalism: _evidence travel_ + trusted kernel section.** Added a dedicated subsection (\S\ref{sec:travel}) at the top of the Resolution Calculus section that (i) defines an _evidence package_, (ii) gives an operational definition of when evidence “travels” for a target obligation (binding + replay + fail-closed meaning), and (iii) states an informal trace-soundness theorem tying conservative bounds to validator soundness + monotone fail-closed composition.

**Research + citation hardening:** added an explicit reference to Proof-Carrying Authentication (Appel & Felten, CCS’99) to sharpen the “proof-carrying” lineage, complementing existing PCC citations.

Open thread: tighten the informal soundness statement into a fully formal theorem by modeling certificate validators as small-step semantics over a budget algebra and proving monotone progress/preservation for the resolver.

---

## 2026-02-26 (v212)

**Paper polish pass:** consolidated the Introduction's contribution list into a smaller set of research-facing claims (ABOM + fail-closed semantics + audit locality + budgets + drift-safe governance + selective disclosure + prototype evaluation). The per-feature/version changelog remains in `notes.md`, but the main paper now reads more like a conventional systems/security paper rather than an internal release log.

**Research refresh (sources verified):** confirmed (i) the AI Act Service Desk timeline language about the Digital Omnibus proposal to link high-risk obligations’ application to support instruments, (ii) the Commission’s Signatory Taskforce constitutive meeting on 30 Jan 2026, and (iii) CEN-CENELEC’s accelerated AI standards measures mentioning prEN 18286 enquiry and Q4 2026 target; references already exist in `references.bib`.

---

## 2026-02-26 (v211)

**Challengeable overlap-aware window budgets (bottom-$k$/KMV):** v210’s HyperLogLog sketches tighten release-train window budgets when impacted slices overlap, but HLL is not naturally *challengeable*: auditors cannot easily demand evidence that a particular impacted ID was included (or detect omissions) without full disclosure. v211 adds **verifiable bottom-$k$ (KMV) drift sketches** as an alternative: each CCC can staple the $k$ smallest salted hash values of its newly-invalidated IDs, enabling overlap-aware union estimates and explicit $(1-lpha)$ **upper bounds** derived from the order statistics of the $k$-th minimum. RTC gating uses the **upper bound** for sketch-based methods.

**Build-things artifacts:**
- `tools/drift_sketch_bottomk_v211.py`: bottom-$k$ sketch construction, union, KMV estimator, and an order-statistic-based upper bound.
- `tools/attach_drift_sketch_bottomk_v211.py`: attaches bottom-$k$ sketches to CCC/IDC/RDD JSON and optionally redacts explicit ID lists.
- `tools/release_train_certificate_v211.py`: extends RTC verification to support `bottomk` alongside `union_bound`, `exact_ids`, and `hll` methods; reports both estimate and upper bound.
- `tools/release_train_overlap_demo_v211.py`: overlap demo where union-bound window budgeting fails closed (0.24) but bottom-$k$ overlap accounting passes (0.12).

**Notes on correctness:** v211 fixes a subtle union bug by deduplicating hashed values when merging sketches (otherwise overlap can be double-counted). The demo bundle `examples/release_train_overlap_demo_v211/` is regenerated with correct union behavior.

---

## 2026-02-26 (v210)

**Overlap-aware drift budgeting with set sketches (HLL):** v209 RTCs used a conservative union bound (sum of per-step drift fractions) for window budgets. That can be *needlessly pessimistic* when impacted slices overlap (correlated rollouts). v210 adds an optional **overlap-aware** estimate of unique drift debt across the window by stapling a **privacy-preserving HyperLogLog (HLL) sketch** over the newly-invalidated IDs in each IDC/RDD (or derived from cached verification summaries). The RTC verifier can then compute an approximate union (register-wise max) and gate the window using a tighter unique-debt estimate, while falling back to exact-ID unions (if disclosed) or the union bound (if neither ids nor sketches are present).

**Research refresh:** (i) SCRAPI is explicitly a moving receipt-resolution interface; the current IETF draft `draft-ietf-scitt-scrapi-07` (Feb 2026) motivates digest-pinned PRCs/RUT and resolution-drift accounting. (ii) CEN-CENELEC adopted exceptional measures to accelerate AI Act standards delivery (targeting Q4 2026 and including prEN 18286 enquiry), reinforcing that standards pipelines are themselves drifting governance interfaces.

What changed (paper + tools + examples):
- Updated draft tag to **v210** (Feb 26, 2026).
- Paper: added a new contribution bullet and a new paragraph extending RTCs with **sketch-based overlap accounting**; updated the RTC schematic to v210 and referenced the new overlap demo.

Build-things artifacts:
- `tools/drift_sketch_hll_v210.py`: minimal auditable HyperLogLog implementation + union (register-wise max) for drift sets.
- `tools/attach_drift_sketch_v210.py`: attaches HLL sketches to CCC/IDC/RDD JSON (optionally redacting explicit id lists).
- `tools/release_train_certificate_v210.py`: RTC composer/verifier that can gate window budgets using **HLL union estimates** (or exact-id unions) instead of union bounds.
- `tools/release_train_overlap_demo_v210.py`: generates a demo where three CCCs have heavily overlapping newly-invalidated endpoint sets; union-bound budgeting fails closed while HLL-based budgeting passes.

Examples:
- `examples/release_train_overlap_demo_v210/`: contains three CCCs (plain + redacted-with-sketch), two RTC outputs (`rtc_union_bound.json` fails, `rtc_hll.json` passes), and `summary.json`.

Open threads / risks to pursue next:
- Make sketches *challengeable*: add a compact audit path that can prove a claimed invalidation ID is included in the sketch commitment (or use salted per-epoch beacons for re-sampling).
- Add MinHash sketches to estimate overlap directly (Jaccard), enabling tighter bounds on union size and explicit correlated-change modeling.
- Thread sketch digest commitments into CCC/RTC digests and (optionally) PUT/RUT logs so window budgeting becomes fully transparency-verifiable.

---

## 2026-02-26 (v209)

**Release-train certificates (RTCs) + window budgets:** v209 makes CCC-gated change control compositional across real rollouts by introducing a Release-Train Certificate (RTC) that bundles an ordered sequence of CCCs into a digest-pinned update window. The RTC enforces (i) **chain-consistency** (each CCC's old digests match the previous CCC's new digests) to prevent rollback/branching within the window, and (ii) **window drift budgets** (cumulative policy + resolution drift debt bounds) to make governance change-rate explicit.

What changed (paper + tools + examples):
- Updated draft tag to **v209** (Feb 26, 2026).
- Paper: added a new contribution bullet and a new paragraph + Listing \ref{lst:rtc} defining RTCs and explaining chain-consistency + window budgets.

Build-things artifacts:
- `tools/release_train_certificate_v209.py`: composes/verifies a sequence of CCCs into a single RTC, checks chain-consistency, and enforces cumulative drift budgets (conservative union-bound upper estimate).
- `tools/release_train_demo_v209.py`: generates a three-step RTC demo from successive profile tightenings (30d→7d→1d→0d), showing fail-closed behavior when a step exceeds the declared window budget.

Examples:
- `examples/release_train_demo_v209/`: runnable demo bundle containing three CCCs, their stapled inputs, an RTC, and a verifier summary.

Open threads / risks to pursue next:
- Replace the union-bound upper estimate with a cached-set overlap estimator (e.g., Bloom-backed “newly invalidated IDs”) to tighten window-budget accounting.
- Add monotone refinement checks across the whole window (e.g., forbid relaxations unless a compensating mitigation obligation is stapled).

---

## 2026-02-26 (v208)

**CCCs as assurance-case fragments + standards-pipeline drift:** v208 makes CCC-gated updates easier to *review* by exporting a CCC as a deterministic assurance-case (GSN/CAE-style) sub-claim: PUT/RUT non-equivocation, IDC/RDD drift budgets, and optional witness-quorum checks become explicit goals with stapled evidence nodes. This keeps human sign-off audit-local: if only an IDC changes, only that node changes.

We also tighten the EU AI Act 'moving support instruments' story with a concrete institutional example: in Feb 2026 the EU Fundamental Rights Agency (FRA) signed an MoU with CEN-CENELEC about participation in the AI standards process, illustrating that standards pipelines themselves behave like governance interfaces.

What changed (paper + bib + tools + examples):
- Updated draft tag to **v208** (Feb 26, 2026).
- Paper: added a new contribution bullet (assurance-case export for CCC update gates), added a paragraph + Listing \ref{lst:ccc-case} explaining CCC-to-case compilation, and added a new EU standards-pipeline citation (FRA–CEN-CENELEC MoU).
- Bib: added `fra_cencenelec_mou_2026` (FRA MoU news release).

Build-things artifacts:
- `tools/assurance_case_export_v208.py`: extends the ABOM→case exporter to optionally attach a CCC as a structured sub-claim and render a release-case graph (dot/json + optional PDF).

Examples:
- `examples/assurance_case_ccc_demo_v208/`: minimal runnable demo that combines a small 'release ABOM' with the v207 `examples/change_control_demo_v207/ccc.json` and emits a rendered case graph and JSON.

Open threads / risks to pursue next:
- Compose multiple CCCs into a single release-train certificate (batch budgets + monotone refinement checks).
- Extend the CCC→case compiler to ingest consistency proofs across epochs and surface split-view monitoring obligations explicitly in the case graph.
- Treat standards bodies, codes of practice, and guideline templates as first-class 'interface providers' with their own non-equivocation and freshness obligations.

---

## 2026-02-26 (v207)

**Change-control certificates (CCC) and drift-as-obligation:** v207 turns drift accounting into an *executable* release gate by treating policy drift debt (IDC) and resolution drift debt (RDD) as first-class **obligation kinds** that profile/PRC updates must satisfy. Concretely, we introduce a stapled Change-Control Certificate (CCC) that binds (i) a profile PUT receipt, (ii) a PRC RUT receipt, (iii) IDC + RDD locality evidence, and (iv) optional WCO witness bundles over the PUT/RUT checkpoints, and then checks drift-budget compliance fail-closed.

What changed (paper + tools + examples):
- Updated draft tag to **v207** (Feb 26, 2026).
- Paper: added a new contribution bullet and a new paragraph + Listing \ref{lst:ccc} describing CCCs as an executable update-gate that composes PUT/RUT non-equivocation with IDC/RDD drift locality and budget checks.

Build-things artifacts:
- `tools/change_control_certificate_v207.py`: builds + verifies a CCC from stapled receipts and drift reports, enforcing binding checks and budget thresholds fail-closed.
- `tools/ccc_demo_v207.py`: end-to-end generator that produces a combined profile+PRC update bundle (PUT receipt + RUT receipt + IDC + RDD + WCO bundles) and emits a passing CCC.

Examples:
- `examples/change_control_demo_v207/`: runnable demo bundle containing the CCC, its inputs (PUT/RUT receipts, IDC/RDD), witness bundles, and a `verify_ccc.json` summary.

Open threads / risks to pursue next:
- Make CCCs compositional: allow a single CCC to bind *multiple* profiles/PRCs (batch releases) while preserving audit-locality.
- Extend the CCC gate to require and verify **consistency proofs** across epochs (not just inclusion), aligning admission with ongoing split-view monitoring.
- Generalize drift budgets beyond freshness/staleness to cover issuer-set rotations, witness roster changes, SCRAPI draft bumps, and other interface-affecting deltas.

---

## 2026-02-26 (v200)

**Interface drift as a versioned governance API:** v200 treats conformity profiles as living, content-addressed interfaces and introduces a conservative, machine-checkable artifact for policy updates: an **Interface Drift Certificate (IDC)**. The IDC summarizes profile deltas, classifies changes as *proven refinement / proven relaxation / unknown* (conservative), and (when possible) localizes the *newly impacted* verification surface by scanning cached receipt metadata.

What changed (paper + bib + tools):
- Updated draft tag to **v200** (Feb 26, 2026).
- Paper: added a new paragraph block in the threat model framing interface drift as a versioned API (IDC + refinement oracle) and added Table \ref{tab:policy-delta-locality} quantifying audit-locality for a pure-metadata drift (freshness tightening).
- Bib: added an official Commission news reference for the 19 Nov 2025 digital omnibus announcement.

Build-things artifacts:
- `tools/interface_drift_delta_cert_v200.py`: emits an IDC report with profile digests, syntactic delta summary, a conservative refinement label, and optional freshness-locality report.

Examples:
- `examples/interface_drift_delta_cert_demo_v200/`: runnable demo that generates an IDC for tightening freshness 30d→1d and reports the newly impacted slice.

Open threads / risks to pursue next:
- Extend the IDC locality scanner beyond freshness: quorum thresholds, issuer set rotations/pins, and ``required receipt kind'' changes that can be checked from cached metadata.
- Define (and measure) *policy drift debt*: expected refresh work induced purely by profile evolution (independent of artifact changes).

---

## 2026-02-26 (v199)

**Compliance interface drift attacks:** treated the compliance surface itself (guidance, checklists, signatory workflows, receipt-discovery APIs) as a first-class attack surface. v199 makes this explicit in the threat model and adds a mitigation stack: digest-pinned profiles + delta patches + freshness gates + monitored non-equivocation (NUC quorums).

What changed (paper + bib + tools):
- Updated draft tag to **v199** (Feb 26, 2026).
- Paper: added an **interface drift attacks** paragraph in the Threat Model; added Table \ref{tab:interface-drift-attacks} (attack taxonomy + mitigations); and expanded the threats table with a dedicated **Compliance interface drift** row.
- Paper (Intro): strengthened the EU AI Act “moving interfaces” point by noting the **2 Feb 2026 Article 6 guidance deadline** and that reporting indicates it was missed (March/April adoption).

Build-things artifacts:
- `tools/interface_drift_delta_report_v199.py`: compares an old/new OCF-P profile pair (prototype: freshness) and reports the **newly impacted** endpoints/receipts; designed to travel with a delta package as an auditor-facing locality proof.

Examples:
- `examples/interface_drift_delta_demo_v199/`: tiny end-to-end demo showing how tightening freshness from 30d→1d localizes the new refresh surface (newly impacted set) without re-verifying the entire fleet.

Open threads / risks to pursue next:
- Generalize the drift-delta report beyond freshness: key rotations, new mandatory receipts, and constraint additions that can be localized by scanning receipt metadata.
- Bind “interface snapshots” (profiles + guidance templates) to witnessed checkpoints (WCO) so freshness and non-equivocation are enforced cryptographically.

---

## 2026-02-25 (v198)

**Hardening NUC trust with monitor quorums:** a NUC is powerful because it amortizes discovery and makes uniqueness checks offline, but a single monitor can become a new single point of failure. v198 makes *monitor quorum* a first-class pattern.

What changed (paper + bib + tools):
- Updated draft tag to **v198** (Feb 25, 2026).
- Paper: added a paragraph on **quorum NUCs** (k-of-n, family-span) and connected the pattern explicitly to witness cosigning ecosystems and pinned acceptance rules.
- Bib: added citations for **C2SP tlog-cosignature** and the **TrustFabric witnesses** listing (keys/endpoints), to ground the “monitor/witness ecosystem” connection.

Build-things artifacts:
- `tools/nuc_quorum_verify.py`: verifies a quorum of independently-issued NUCs against an expected key + MER digest, and emits a policy-friendly summary JSON.

Examples:
- `examples/nuc_demo_quorum/`: a runnable 2-of-3 demo that *passes* when one monitor observes equivocation (matches=2) but two monitors attest uniqueness, and a *fail-closed* manifest when the quorum is not met.

Open threads / risks to pursue next:
- Bind NUC snapshots to a witnessed checkpoint (WCO) or SCITT inclusion receipt, so monitor staleness can be enforced cryptographically rather than socially.
- Extend `mer_verify.py` to accept a quorum manifest directly (instead of a single `--nuc`) while preserving strict resource caps.

---

## 2026-02-25 (v197)

**Monitored non-equivocation (NUC):** pushed the discovery burden out of verifiers and into a monitoring ecosystem, so high-stakes uniqueness checks can be *offline* and budgetable.

What changed (paper + bib + tools):
- Updated draft tag to **v197** (Feb 25, 2026).
- Paper: added a new **Non-Equivocation Certificate (NUC)** pattern + Listing \ref{lst:nuc}; updated the discovery budget table to include an **offline + NUC** mode; and extended the MVS schematic to show an explicit `nonEquivocationCertificate` check.
- Bib: added a citation for **tile-backed transparency logs** (why reads can be CDN-cacheable and monitoring-friendly) and connected it to Rekor v2’s removal of best-effort search and shift toward dedicated index services.

Build-things artifacts:
- `tools/nuc_issue.py`: issues a DSSE-signable NUC from a Receipt Cache Index (RCI) or a receipt-cache directory, under explicit scan/size caps.
- `tools/nuc_verify.py`: verifies a NUC signature (Ed25519 demo mode) and checks that it attests uniqueness for the given key and MER digest.
- `tools/mer_verify.py`: bumped to v0.4; added optional `--nuc` + `--nuc-public-key` so uniqueness can be satisfied offline by a monitor-issued certificate (or fall back to cache scanning).

Examples:
- `examples/nuc_demo/`: a tiny end-to-end demo: generate a receipt-cache index, issue a NUC for a key, verify it, and show the failure case when equivocation occurs.

Open threads / risks to pursue next:
- Replace the Ed25519 demo keys with a Sigstore/fulcio signing path (or a pinned keyset + TUF root), and discuss how monitors publish and rotate NUC issuer keys.
- Formalize NUC freshness and staleness rules (e.g., require a timestamp authority receipt or SCITT inclusion receipt binding the snapshot time).
- Prototype a verifiable map/index for key→receipt locators (non-inclusion proofs), so uniqueness can be proven without trusting monitor completeness.

---

## 2026-02-25 (v196)

**Discovery budgets + receipt caches:** made the uniqueness story *operationally plausible* under real-world transparency-log constraints (rate limits, sharding, and moving APIs).

What changed (paper + bib + tools):
- Updated draft tag to **v196** (Feb 25, 2026).
- Added a new \"discovery is an interface\" paragraph and Table \ref{tab:discovery-budget}:
  - uses **SCITT SCRAPI** as the stable core (register via `POST /entries`, resolve via `GET /entries/{EntryID}`; async + rate limiting);
  - explains why relying on log-side search is brittle (Rekor v2 removed the best-effort search index; sharding complicates naive lookups);
  - introduces a **Receipt Cache** layer as the pragmatic index for uniqueness checks.
- Bib: added citations for Rekor sharding docs and Sigstore's public BigQuery mirror dataset.

Build-things artifacts:
- `tools/receipt_cache.py`: scans a directory of MER bundles and emits a minimal **Receipt Cache Index (RCI)** for offline discovery/uniqueness.
- `tools/mer_verify.py`: bumped to v0.3; added `--receipt-cache-dir` + scan caps to build an in-memory index (alternative to `--discovery-index`).
- `examples/mer_demo/`: added `receipt_cache/` + `receipt_cache_index.json` and two `*_cache_unique_fail.json` MVS outputs demonstrating equivocation under cache-based uniqueness.

Open threads / risks to pursue next:
- Replace Ed25519 demo signing with a real Sigstore bundle verification path (or a strict, resource-capped subset), and demonstrate verification against a real Rekor v2 entry format.
- Define the precise profile semantics for discovery failure (offline-only vs online-strict vs opportunistic), including caching TTLs and gossip/witness options.
- Quantify discovery overheads empirically on a real receipt corpus (latency distribution, cache hit rates, shard fanout), and link to a reproducible benchmark harness.

---

## 2026-02-25 (v195)

**Receipt non-equivocation, end-to-end:** tightened the MER/MVS path so uniqueness can be *checked* (not just discussed), and made the “MER is a projection” claim concrete.

What changed (paper + bib + tools):
- Updated draft tag to **v195** (Feb 25, 2026).
- MER listings now carry explicit **runId** and **obligationId** fields (for discovery/uniqueness).
- MVS listing now includes a **uniqueReceipt** check and a minimal **discovery** summary, aligning the paper with a real (toy) verifier interface.
- Added Table 
ef{tab:mer-projection}: a tight mapping from MER fields → existing OCF evidence (MER as a *projection*, not a parallel schema).
- Added a short paragraph warning that receipt discovery is an online dependency and an attack surface; cited **CVE-2026-24117** (Rekor SSRF via 	exttt{/api/v1/index/retrieve}).

Build-things artifacts:
- `schemas/mer_predicate_v1.schema.json`: extended with optional `runId` and `obligationId`.
- `tools/mer_emit.py`: new flags `--run-id` and `--obligation-id` that populate those predicate fields.
- `tools/mer_verify.py`: bumped to v0.2 and gained `--discovery-index` (toy offline index) + `--enforce-unique`. Emits `checks.uniqueReceipt` and `checks.discoverySummary` for policy gating.
- `examples/mer_demo/`: added `tlog_index.json` plus “unique-fail” MVS outputs demonstrating the equivocation case.

Open threads / risks to pursue next:
- Replace the toy discovery index with a *real* Rekor/SCITT query path (SCRAPI), including caching rules and batching.
- Add a realistic Sigstore Bundle parsing + SCITT receipt verifier stub (log identity, inclusion proof).
- Formalize the “unique receipt” rule and caching semantics in the profile language (so it’s not just a narrative requirement).
- Quantify discovery overheads in a realistic deployment (latency, batching, shard fanout).

---

## 2026-02-25 (v194)

**Verifier kernel + equivocation guardrails:** moved MER from “attestation format” to a *deployable verification path*.

What changed (paper + bib + tools):
- Updated draft tag to **v194** (Feb 25, 2026) and fixed the “nine contributions” mismatch.
- Added a new verifier-kernel subsection in Sec. \ref{sec:mer-attestation}: ABOM + receipt/bundle + (optional) transparency receipt → a single **MER Verification Summary (MVS)** fact (Listing \ref{lst:mvs}), with an explicit emphasis on *resource-bounded verification*.
- Added an **equivocation case study** (“two MERs” for one ABOM) and two concrete policy patterns: (i) pin receipt digests in ABOM / conformance credentials, and (ii) require log discovery + uniqueness constraints for high-stakes obligations.
- Bib: added an NVD citation for **CVE-2024-45395** to motivate size/complexity caps in receipt verifiers.

Build-things artifacts:
- `schemas/mer_predicate_v1.schema.json`: a concrete JSON Schema for the MER predicate (v1).
- `tools/mer_verify.py`: a minimal verifier that checks DSSE PAE signatures (Ed25519 demo mode), schema validity, ABOM subject binding, and an optional toy Merkle inclusion proof.
- `tools/mer_emit.py`: upgraded with an optional Ed25519 signing mode (still intentionally not a Sigstore/cosign replacement).
- `examples/mer_demo/`: generated Ed25519 keypair + two signed MERs for the same ABOM (`best_of` vs `single`) + corresponding MVS outputs.

Open threads / risks to pursue next:
- Wire MVS as a first-class “certificate” consumed by the resolver (or prove it can remain an external artifact).
- Add a realistic Sigstore Bundle parsing path (message signature + tlog entry) and a SCITT receipt verifier stub that checks log identity and inclusion, even if offline-only.
- Formalize the “unique receipt” rule in the profile language (query obligations + caching rules), and quantify the online discovery costs.
- Add a tighter mapping from MER fields → the existing EAP family (so MER is provably a projection, not a parallel schema).

---

## 2026-02-25 (v193)

**MER goes “on the rails”:** upgraded MER from a schematic JSON blob into a *deployable attestation* story: MER as an **in-toto Statement predicate**, signed via **DSSE**, optionally shipped as a **Sigstore Bundle**, and optionally registered to a **SCITT transparency service** for inclusion receipts (anti-equivocation).

What changed (paper + bib + tools):
- Updated draft tag to **v193** (Feb 25, 2026).
- Added Sec. \ref{sec:mer-attestation}: MER as DSSE/in-toto predicate + Sigstore/SCITT receipt chain; includes Listings \ref{lst:mer-intoto} and \ref{lst:mer-dsse}.
- Added a worked, falsifiable inflation example (single-attempt vs best-of-8) tied directly to MER fields.
- Bib: added GitHub Actions artifact attestation doc; refreshed SLSA VSA URL to the stable v1.1 spec landing (predicateType remains `https://slsa.dev/verification_summary/v1`).

Build-things artifacts:
- Added `tools/mer_emit.py`: tiny helper that emits a canonical MER-in-toto statement (stub) and a DSSE envelope (unsigned) for interop testing.

Open threads / risks to pursue next:
- Make the MER predicate *real*: publish a JSON Schema + versioning rules + parsing rules (in-toto compatible) and add it to `examples/`.
- Add a minimal verifier: take (ABOM digest, bundle/receipt) -> verify signatures + transparency receipt + schema -> produce a single “MER ok” fact for the resolver kernel.
- Decide whether “MER” is a new certificate class in OCF-LLM (or strictly an external projection of existing certs).
- Add a short “equivocation + disclosure” case study: two different MERs for the same ABOM registered to a log; show how policy refuses the inconsistent one.

---

## 2026-02-25 (v192)

**Evaluation inflation, made explicit:** added a compact *evaluation inflation taxonomy* + a proposed *Minimal Evaluation Receipt (MER)* schema that makes the “meaning” of a leaderboard claim portable.

What changed (paper + bib):
- Updated draft tag to **v192** (Feb 25, 2026).
- Added Table \ref{tab:eval-inflation-taxonomy} (degrees of freedom → inflation lever → minimal receipt → OCF guardrail).
- Added a proposed MER interop object (Listing \ref{lst:mer}) and a simple best-of-$m$ inflation lemma (Lemma \ref{lem:bestofm}).
- Strengthened the framing with the “researcher degrees of freedom / garden of forking paths” analogy (Simmons et al. 2011; Gelman & Loken 2013).
- Added a new paragraph on **confidential bank execution**: pairing DSC with remote-attested runners (RATS + SGX/SEV-SNP) for cases where even the sampled suite must stay secret.
- Bib additions: Gelman & Loken (forking paths PDF), CoDeC contamination detection, Intel SGX overview, AMD SEV-SNP whitepaper.

Open threads / risks to pursue next:
- Turn MER into a concrete EAP subset: define a canonical field-set and a DSSE/in-toto predicate, plus a toy exporter/validator (SCITT-ready).
- Add a short “inflation-to-receipts” *worked example*: same base model, two different best-of-$m$ policies, show how claims differ under identical raw logs.
- Flesh out confidential bank execution: what’s the minimum attestation evidence the kernel must validate (key pinning, code digest, replay protection), and how does that interact with BB-EAP and challenge windows?

---

## 2026-02-25 (v191)

**Evaluation degrees-of-freedom: grounded with empirical and theoretical work (leaderboards, contamination, best-of-$n$, and judge drift).**

What changed (paper + bib):
- Updated draft tag to **v191** (Feb 25, 2026).
- Removed a redundant EU AI Act schedule sentence in the intro (the detailed paragraph + citations remain).
- Strengthened the *adaptivity* motivation paragraph with concrete sources:
  - adaptive holdouts / reliable leaderboards: reusable holdout and the Ladder mechanism. (`dwork_reusable_holdout_science_2015`, `blum_hardt_ladder_2015`)
  - contamination / leaderboard overfitting for LLMs: ConStat + LLMEval-3. (`dekoninck_constat_2024`, `zhang_llmeval_fair_2025`)
  - best-of-$n$ selection as an *operationally meaningful* degree of freedom: BoNBoN + BOND. (`gui_bonbon_2024`, `sessa_bond_2024`)
  - judge drift / bias / inconsistency: position bias + TrustJudge + ObjexMT. (`shi_position_bias_llm_judge_2024`, `wang_trustjudge_2025`, `kim_objexmt_2025`)
- Extended the EIC/JRC motivation paragraph to cite ConStat/LLMEval-3 for contamination and the judge papers above for rubric/judge instability.

**Kubernetes admission vignette (deploy-time enforcement).**
- Added a short, realistic rollout gate example in \S\ref{sec:conformance-attest}:
  - a Sigstore policy-controller `ClusterImagePolicy` snippet that requires a CSA/VSA-shaped attestation;
  - an explanation of how `ValidatingAdmissionPolicy` can enforce structural invariants while signature verification stays in a small verifier kernel.

**Next risks to take (v192+):**
1) Add a compact “evaluation inflation taxonomy” table mapping each DOF (retries, best-of-$m$, judge choice, stopping rules, suite selection) to the *minimal* OCF-LLM receipt that closes it (DRC/SPC/SIC/JRC/CSIC), with explicit failure modes.
2) Add a confidentiality-preserving path for dynamic banks (e.g., selective disclosure + TEEs / zk proofs) and show how it fits into ABOM via a new certificate kind, even if the prototype is toy.
3) Tighten the SCITT mapping even further: show an explicit ABOM→SCITT statement schema and an interop checklist with SCRAPI.

---

## 2026-02-25 (v190)

**Hardening the governance-milestones story (dates + sources).**

- Added an explicit sentence in the introduction that pins the EU AI Act phased application dates (2 Feb 2025 unacceptable-risk prohibitions; Aug 2025 GPAI obligations; Aug 2026 high-risk obligations) and cites European Parliament + Reuters.
- Added bibliography entry: `ep_eu_ai_act_topic_page` (European Parliament explainer page).

**Next research passes (queue):**

1) Tighten the *evaluation degrees-of-freedom* discussion with the most recent empirical work on leaderboard peeking / best-of-m selection / judge drift (aim: at least 2–3 high-quality 2024–2026 sources per failure mode).
2) Strengthen the *SCITT bridge* paragraph: map ABOM/EAP/CPC into SCITT "transparent statements" explicitly, and cite the latest IETF draft revision.
3) Add one realistic *Kubernetes admission* vignette: how CPC/apt-like credentials gate rollouts via ValidatingAdmissionPolicy / Sigstore policy-controller, with concrete YAML snippets and failure modes (drift, replay, split-view).

---

## 2026-02-24 (v189)

**Governance resilience + end-to-end deployment realism.**

This revision focuses on making the paper *stronger and more field-ready* without adding brittle complexity:

1) **Governance minimal cut sets (GMCS):** a reliability-style analysis for *evidence providers* (logs, witnesses, evaluators). Profiles induce a boolean structure (e.g., k-of-n, family-span, quorum-on-roots). GMCS reveals single points of failure and quantifies redundancy.
   - New artifacts: `tools/governance_cutsets_v189.py`, `figs/governance_cutsets_v189.pdf`, `tables/governance_cutsets_v189.tex`.

2) **Defense stack evaluation:** a compact Monte Carlo study comparing baseline vs BFC vs PCSC* vs BB-EAP+ETC/EDC+QTA, reporting undetected-manipulation probability vs verification cost and assurance-debt tail risk.
   - New artifacts: `tools/governance_stack_sim_v189.py`, `figs/governance_stack_tradeoffs_v189.pdf`, `tables/governance_stack_tradeoffs_v189.tex`.

3) **End-to-end demo bundle:** ties ABOM + DSSE/in-toto statement + SLSA VSA + (toy) transparency receipts + policy-as-code admission into one script (replayable).
   - New artifacts: `tools/end_to_end_pipeline_v189.py`, `examples/end_to_end_pipeline_v189/`.

Also:
- Tightened the contribution list and narrative around *control loops* and *admission control*.
- Updated citations/related work to align with SCITT, Sigstore policy-controller, Rekor v2, and Kubernetes ValidatingAdmissionPolicy.


## 2026-02-24 (v188)

**Quorum trace-root agreement (QTA) + dispute-aware assurance budgets.**

v187 introduced ETC/EDC: commit the full evaluation trace as a Merkle root (ETC) and allow any challenger to produce a portable one-leaf fraud proof (EDC).
This revision lifts that pattern to a *multi-evaluator* setting and wires disputes into the governance control loop.

1) **QTA (quorum on ETC roots):** for a fixed RunSpecCommit, require $m$ independent evaluator implementations to publish EAPs that carry ETC roots. Admit only if there is a **unique quorum** root (\ge q out of m) and no competing quorum exists; otherwise fail closed.

2) **Aligned vs unaligned faults:** a toy model distinguishes “aligned” wrong roots (shared misinterpretation that yields the same wrong root) from unaligned bugs (different wrong roots). We add a simulator + figure + table to make the knob explicit.

3) **Dispute-aware budgeting:** missing quorum receipts, competing quorums, or pending disputes are treated as deterministic invalidation sources that burn assurance-change budget until resolved; validated disputes localize invalidation via ABOM dependency slices.

Files added:
- `tools/trace_root_quorum_sim_v188.py` → `figs/trace_root_quorum_v188.pdf`, `tables/trace_root_quorum_v188.tex`
- `tools/profile_policy_engine_v188.py` + `examples/policy_demo_v188/`

---

## 2026-02-24 (v187)

**Trace commitments + optimistic dispute windows for evaluations (ETC/EDC).**

BB-EAP (v184) makes challenge indices non-adaptive, but it still leaves a *non-repudiation* gap: without a commitment to the full per-case trace, a verifier can detect cheating locally yet struggle to produce a portable artifact that invalidates the run across downstream consumers.

This revision adds an *optimistic* layer (inspired by fraud-proof systems) for evaluation governance:

1) **ETC (Evaluation Trace Commitment):** publish a CT-style Merkle root over per-case leaf records (case id, seed, policy ids, verdict, output hash), carry the root in EAP, and publish it to a transparency log with receipts.

2) **EDC (Evaluation Dispute Certificate):** if any opened leaf is missing/malformed or disagrees with re-execution under the committed run spec, emit a compact fraud proof: one leaf + inclusion proof + recomputed evidence of inconsistency. Third parties can validate the dispute offline by checking the inclusion proof against the logged root.

3) **Governance knob:** sampling k leaves detects manipulation fraction α with probability ~ 1-(1-α)^k; we include a figure + table and a runnable end-to-end demo.

Files added:
- `tools/trace_commitment_dispute_demo_v187.py`
- `tools/trace_dispute_detection_v187.py` → `figs/trace_dispute_detection_v187.pdf`, `tables/trace_dispute_params_v187.tex`
- `examples/trace_dispute_demo_v187/`

---

## 2026-02-24 (v186)

**Quorum-based evaluator admission (robust diversity in CI).**

v185’s “all-agree” evaluator diversity is intentionally conservative, but it can be brittle under benign noise (minor harness skew, floating-point drift, nondeterministic judge backends), producing *false rejects* that tempt teams to weaken governance checks.

This revision adds a profile-level **evaluator quorum admission** primitive: a profile specifies $(m,q,\epsilon)$ and accepts an evaluation only if at least $q$ of $m$ evaluator implementations form an $\epsilon$-tight agreement cluster. This preserves fail-closed behavior when there is no stable agreement, but tolerates benign disagreement and supports gradual evaluator rollouts.

1) **Quorum intuition:** connects evaluator admission to Byzantine quorum system ideas (explicitly a governance *admission* control, not consensus).
2) **Robust aggregation:** motivates medians / median-of-means as principled summaries in the presence of outliers/heavy tails.
3) **Artifacts (v186):** a simulator generates the quorum-vs-all-agree curve + table, and a new admission-policy demo implements an `evaluator_quorum` check.

### What changed (paper)
- Updated draft tag to **v186** (Feb 24, 2026).
- Added \S\ref{sec:evaluator-quorum} “Quorum-based evaluator admission and robust aggregation (v186)” with Figure~\ref{fig:evaluator-quorum} and Table~\ref{tab:evaluator-quorum}.
- Added a new Contributions bullet for quorum-based evaluator admission.

### What changed (artifacts)
- New plot + table generator:
  - `tools/evaluator_quorum_sim_v186.py` -> `figs/evaluator_quorum_v186.pdf`, `tables/evaluator_quorum_v186.tex`
- New policy-as-code engine + demo:
  - `tools/profile_policy_engine_v186.py` + `examples/policy_demo_v186/`

---

## 2026-02-24 (v185)

**Evaluator diversity / N-version evaluation harnesses (anti-harness-bug / anti-compromise).**

This revision adds a concrete governance knob for the *evaluator itself*: even with BB-EAP/RunSpec commitments, a single buggy or compromised harness can emit a wrong metric. We add an optional, fail-closed requirement that **multiple independent evaluator implementations** execute the same RunSpecCommit and agree within tolerance.

1) **Evaluator diversity model (v185):** a simple correlated-failure mixture shows exponential reduction in accepting a wrong evaluation until a common-mode floor, connecting directly to classic multiversion programming results and to modern “client diversity” arguments in blockchain networks.
2) **Artifacts (v185):** a simulator generates the diversity curve + table, and an admission-policy demo checks evaluator diversity alongside receipt freshness, family-span requirements, and assurance-change budgets.

### What changed (paper)
- Added \S\ref{sec:evaluator-diversity} “Evaluator diversity and harness N-versioning (v185)” with Figure~\ref{fig:evaluator-diversity} and Table~\ref{tab:evaluator-diversity}.
- Added a new Contributions bullet for evaluator diversity as a governance knob.

### What changed (artifacts)
- New plot + table generator:
  - `tools/evaluator_diversity_sim_v185.py` -> `figs/evaluator_diversity_v185.pdf`, `tables/evaluator_diversity_v185.tex`
- New policy-as-code demo:
  - `tools/profile_policy_engine_v185.py` + `examples/policy_demo_v185/`

---

## 2026-02-24 (v184)

**Beacon-bound evaluation attestations + verifier challenge windows (anti-adaptivity).**

This revision hardens the evaluation pipeline against *seed search* and *selective disclosure* by making randomness an explicit, auditable dependency.

1) **BB-EAP (v184):** a RunSpecCommit is transparency-published before a public randomness beacon pulse; the evaluation seed and deterministic spot-check indices are derived from the beacon value and the committed RunSpec.
2) **Challenge window knob (v184):** a compact detection model makes “how much challenge is enough?” explicit; profiles can set a $k$-openings budget and treat missing openings as deterministic invalidation in impact queries.
3) **Artifacts:** a runnable generator emits RunSpecCommit + beacon pulse receipts + deterministic challenge indices + a beacon-bound EAP; plus a plot/table generator for the spot-check parameterization.

### What changed (paper)
- Updated draft tag to **v184** (Feb 24, 2026).
- Added \S
ef{sec:beacon-bound-eval} “Beacon-bound evaluation runs and verifier challenge windows (v184)” with Figure~
ef{fig:beacon-spotcheck-detection} and Table~
ef{tab:beacon-spotcheck-params}.

### What changed (artifacts)
- New runnable demo:
  - `tools/beacon_bound_eap_challenge_demo_v184.py` -> `examples/bbea_challenge_demo_v184/`
- New plot + table generator:
  - `tools/beacon_spotcheck_detection_v184.py` -> `figs/beacon_spotcheck_detection_v184.pdf`, `tables/beacon_spotcheck_params_v184.tex`

---

## 2026-02-24 (v183)

**Standardize transparency receipts end-to-end: COSE/SCITT-shaped receipts + a measurable split-view detection knob.**

This revision strengthens the paper’s transparency story in two ways: (i) receipts become *interoperable artifacts* that can be consumed by emerging SCITT ecosystems, and (ii) anti-equivocation is parameterized so operators can reason about “how much gossip is enough” alongside witness quorum rules.

1) **COSE receipt-shaped transparency artifacts (v183):** a toy exporter shows how DSSE/in-toto attestations can be committed into a Merkle log and returned with a receipt shaped like COSE/SCITT receipt work (checkpoint signature + inclusion proof + optional witness cosigs).
2) **Split-view detection parameterization (v183):** a compact analytic model + figure/table connect gossip rate and partition size to detection probability within a time window, complementing WCO-style witness cosigning.
3) **Artifacts:** a runnable generator + verifier for COSE-shaped receipts, and a plot/table generator for gossip detection curves.

### What changed (paper)
- Updated draft tag to **v183** (Feb 24, 2026).
- Added \S\ref{sec:cose-scitt-receipts} “Interoperable transparency receipts with COSE/SCITT (v183)”.
- Extended \S\ref{sec:case-wco} with Figure~\ref{fig:gossip-detection} and Table~\ref{tab:gossip-detection} to make the anti-split-view knob concrete.

### What changed (artifacts)
- New runnable demo:
  - `tools/cose_receipt_demo_v183.py` -> `examples/cose_receipt_demo_v183/`
- New figure + table generator:
  - `tools/gossip_detection_sim_v183.py` -> `figs/gossip_detection_v183.pdf`, `tables/gossip_detection_v183.tex`

---

## 2026-02-24 (v182)

**Make OCF-LLM receipts plug directly into supply-chain policy and transparency ecosystems.**

This revision introduces *standard attestation shapes* for (i) evaluation runs and (ii) profile conformance, so existing admission-control and transparency tooling can enforce OCF-LLM governance without bespoke wire formats.

1) **EAP (Evaluation Attestation Predicate):** an in-toto Statement predicate that binds an evaluation result artifact to the ABOM digest, suite/bank root, harness identity, decode policy, and randomness binding.
2) **CSA as SLSA VSA:** a Conformance Summary Attestation that reuses the SLSA *Verification Summary Attestation* predicate to sign the outcome of checking an ABOM+receipts against a profile, suitable for deploy-time policy enforcement.
3) **Runnable demo bundle + figure/table:** a toy generator emits DSSE-wrapped statements (Ed25519) and optional toy transparency receipts.

### What changed (paper)
- Updated draft tag to **v182** (Feb 24, 2026).
- Fixed contribution count wording (now **nine** contributions).
- Added \S
ef{sec:conformance-attest} “Conformance Summary Attestations and attested evaluation runs (v182)” with Figure~
ef{fig:eap-vsa-pipeline} and Table~
ef{tab:attestation-receipts}.

### What changed (artifacts)
- New runnable tool + demo:
  - `tools/eap_vsa_demo_v182.py` -> `examples/eap_vsa_demo_v182/`
- New figure generator:
  - `tools/eap_vsa_pipeline_figure_v182.py` -> `figs/eap_vsa_pipeline_v182.pdf`
- New table:
  - `tables/attestation_receipts_v182.tex`

---

## 2026-02-24 (v181)

**Make governance executable at the boundary: profiles as policy-as-code admission policies.**

This revision treats an OCF-LLM profile not only as a static specification, but as an *online admission policy* that can run at deployment-time (or CI-time) and produce replayable decisions with machine-parsable reasons.

1) **New paper subsection:** \S\ref{sec:policy-as-code} “Executable governance profiles as admission policies (v181)”.
   - Connects OCF-LLM profile enforcement to production admission-control patterns (Kubernetes admission controllers; Sigstore policy controller) and policy-as-code engines (OPA/Rego).
   - Emphasizes **replayability**: given signed inputs (ABOM update, receipts, impact slice, budget context), independent verifiers can reproduce the *exact* accept/defer/reject decision.

2) **New runnable reference engine + example:**
   - `tools/profile_policy_engine_v181.py` evaluates a declarative JSON profile against a change request and emits:
     - `decision`: ACCEPT / DEFER / REJECT
     - `reasons`: structured fail-closed explanations
     - `audit_annotations`: key/value strings suitable for an append-only audit log
   - Demo inputs/outputs in `examples/policy_demo_v181/`.

3) **New figure + table:**
   - `figs/policy_admission_pipeline_v181.pdf` (pipeline diagram).
   - `tables/policy_primitives_v181.tex` (policy primitives + systems analogs).

### What changed (paper)
- Added \S\ref{sec:policy-as-code} with Figure~\ref{fig:policy-admission-pipeline} and Table~\ref{tab:policy-primitives}.
- Added new citations connecting the design to admission control and supply-chain policy enforcement.

### What changed (artifacts)
- New tool: `tools/profile_policy_engine_v181.py`.
- New figure generator: `tools/policy_admission_pipeline_figure_v181.py`.
- New runnable demo: `examples/policy_demo_v181/`.

---

## 2026-02-24 (v180)

**Turn assurance-change budgets into an operational control loop (assurance admission control).**

v176 introduced assurance-change budgets and impact queries; v180 takes the next step: it makes budgets actionable via an \emph{admission controller} that can defer or batch changes based on their \emph{measured} blast radius.
The key risk-taking idea is that broad, correlated changes (shared tools, bank evolution) can be cheaper to recertify \emph{batched} (union-of-impacted-slices) than shipped one-by-one, and OCF-LLM makes overlap visible by slice identity.

1) **New paper subsection:** \S
ef{sec:assurance-control} ``Governance control loops: assurance admission control (v180)''.
   - Frames assurance-change budgets as an SRE-style SLO/error-budget analogue, and links to DORA delivery metrics.
   - Argues for batching broad changes when impacted slices overlap.

2) **New runnable simulator + figure + table:**
   - `tools/assurance_controller_v180.py` \(
ightarrow\) `figs/assurance_control_loop_v180.pdf`, `tables/assurance_control_loop_summary_v180.tex`.
   - Illustrates three policies (ship-everything, budget gate, batch+token controller) and the budget/lag trade-offs.

### What changed (paper)
- Updated draft tag to **v180** (Feb 24, 2026).
- Added a new contribution bullet: **Assurance admission control** (SRE-style governance control loop).
- Added \S
ef{sec:assurance-control} with Figure~
ef{fig:assurance-control-loop} and Table~
ef{tab:assurance-control-loop}.

### What changed (artifacts)
- New plot/table generator: `tools/assurance_controller_v180.py`.


## 2026-02-24 (v179)

**Make private coverage checks robust to adaptive sketching, and pull benchmark-evolution failures into impact queries.**

v178 introduced Private Coverage Sketch Certificates (PCSC) and receipt-family robustness.
v179 takes the next risk: it hardens PCSC against *adaptive* sketching and makes ``coverage drift'' show up as a first-class invalidation source in incremental recertification.

1) **Challengeable PCSC\***: add (i) **commit-before-beacon** binding of \((\text{bank root},\ \mathsf{pk}_{\mathrm{VOPRF}},\ \text{sketch policy})\) to a timestamped transparency receipt, and (ii) optional **verifier spot-check openings** for a subset of MinHash positions.
   - Adds Figure `figs/pcsc_challenge_detection_v179.pdf` and Table `tables/pcsc_challenge_detection_v179.tex`.
   - Adds runnable demo: `tools/pcsc_challengeable_demo_v179.py` producing `examples/pcsc_challenge_v179/`.

2) **Coverage drift invalidation in impact queries**: add paper text that treats missing/failing BFC/PNC/PCSC receipts as deterministic invalidations, localized to the claims that actually cite the bank.

### What changed (paper)
- Updated draft tag to **v179** (Feb 24, 2026).
- Extended \S\ref{sec:bfc} with **Verifier-challengeable PCSC and commit-before-beacon (v179)**, including a simple cheating-detection bound.
- Extended \S\ref{sec:impact-queries} with **Coverage drift as a first-class invalidation source (v179)**.

### What changed (artifacts)
- New plot generator:
  - `tools/pcsc_challenge_detection_v179.py` \(\rightarrow\) `figs/pcsc_challenge_detection_v179.pdf`, `tables/pcsc_challenge_detection_v179.tex`
- New runnable demo bundle:
  - `tools/pcsc_challengeable_demo_v179.py` \(\rightarrow\) `examples/pcsc_challenge_v179/`
- Added references for Privacy Pass (RFC 9576/9577/9578) and Sigstore security model.
## 2026-02-24 (v178)

**Make “substantive private benchmark updates” resilient to near-duplicate padding, and make receipt diversity assumptions auditable.**

v177 added (i) correlated-failure modeling for multi-log receipts and (ii) Private Novelty Certificates (PNC) to block *no-op cadence* attacks under selective disclosure.
v178 pushes the story from “new IDs” to “new coverage” and from “independent logs” to “documented failure domains”:

1) **Private Coverage Sketch Certificates (PCSC):** a privacy-preserving coverage check that is harder to game with paraphrases / near-duplicates.
   A PCSC binds bank-level feature sketches (HyperLogLog + MinHash) and can optionally use PSI-CA to lower-bound new feature mass.
2) **Correlation families in profiles:** receipt issuers/witnesses can be tagged with *failure-domain families*, and acceptance rules can require receipts to span ≥ f distinct families.
   This makes common-mode risk explicit and yields a simple robustness accounting curve.

### What changed (paper)
- Updated draft tag to **v178** (Feb 24, 2026).
- Added \S\ref{sec:bfc} extension paragraph: **Near-duplicate padding and private coverage sketches (v178)** introducing PCSC with citations (MinHash, HyperLogLog, privacy-preserving set similarity, PSI-CA).
- Extended the WCO case study with **Correlation families and robustness accounting (v178)** and a new figure:
  - `figs/receipt_family_robustness_v178.pdf` (label `fig:receipt-families`).

### What changed (artifacts)
- New runnable tool + example bundle:
  - `tools/pcsc_coverage_sketch_demo_v178.py`
  - `examples/pcsc_demo_v178/` (banks, sketches, pcsc object, verifier report).
- New plot generator:
  - `tools/plot_receipt_family_robustness_v178.py`
  - emits `figs/receipt_family_robustness_v178.pdf` and `tables/receipt_family_robustness_v178.tex`.

### Next risks to take (v179+)
- **Tighter PCSC privacy:** replace the toy OPRF-salt with a real VOPRF transcript, and make sketches verifier-challengeable (anti-adaptive).
- **Impact-query integration:** treat PCSC/PNC failures as first-class invalidation sources in assurance-debt accounting (assurance-change budget for “coverage drift”).
- **Worst-case adversaries:** model bank maintainers that can *choose* tasks after seeing beacon values; add commit-before-beacon constraints for sketches.



## 2026-02-24 (v177)

**Close two hard loopholes for ``live'' + ``transparent'' evaluation: (i) correlated receipt failures, and (ii) no-op benchmark updates under selective disclosure.**

v176 made incremental recertification a first-class query and tied factoring choices to a measurable assurance-change budget.
v177 tightens the *governance soundness* story under realistic adversaries:

1) ``Receipt diversity'' only helps if failure domains are truly diverse.
   We model *common-mode compromise* explicitly and show that even a small shared-cause probability imposes a floor on security.
2) Freshness/cadence gates do not guarantee that a private benchmark bank is being updated *substantively*.
   We add a privacy-preserving novelty proof that can fail-close ``no-op cadence'' attacks without disclosing the full bank.

### What changed (paper)
- Fixed missing cross-references by introducing/aliasing the intended section labels:
  - `\label{sec:background}`, `\label{sec:model}`, `\label{sec:abom}`, `\label{sec:locality}`, `\label{sec:deltas}`.
- Added the **Audit locality theorem** `thm:audit-locality` and made it explicit in the locality micro-benchmark section.
- Added new packaging labels + text:
  - `\S\ref{sec:tlog}` transparency publication/event streams,
  - `\S\ref{sec:tsp}` timestamping receipts (signed time),
  - `\S\ref{sec:vco}` verifier conformance obligations,
  - `\S\ref{sec:sabom}` sABOM/ABIRC (snapshot ABOMs + transcript ABI pinning).
- Added **Receipt diversity under correlated failures (v177)** with a toy model and a new figure:
  - `figs/multilog_correlated_v177.pdf`.
- Added **Private Novelty Certificates (PNC) (v177)** to make ``substantive bank updates'' checkable under selective disclosure.
  - Adds new citations for VRFs (RFC 9381) and OPRF/VOPRF (RFC 9497).
- Added an **assurance-case export figure** for the runnable Graphviz export:
  - `figs/abom_to_case_v177.pdf` with label `fig:abom-to-case`.

### What changed (artifacts)
- New runnable tool + example bundle:
  - `tools/pnc_private_novelty_demo_v177.py`
  - `examples/pnc_demo_v177/` (`bank_v1.json`, `bank_v2.json`, `pnc_v1.json`, `verify_report.txt`).
- New plot artifact:
  - `figs/multilog_correlated_v177.pdf`.
- New exported assurance-case figure:
  - `figs/abom_to_case_v177.pdf`.

### Next risks to take (v178+)
- **Novelty beyond IDs:** strengthen PNC to resist *near-duplicate* padding (distributional sketches / verifier-hardness attestations) while preserving privacy.
- **Correlation families in profiles:** let OCF-P encode ``failure domain'' tags for receipts/witnesses and compute an ARI-style robustness score automatically.
- **Hard-bind PNC/DSC/BFC:** integrate PNC as an explicit prerequisite of BFC cadence gates for benchmark pipelines that claim ``live'' status.


## 2026-02-24 (v176)

**Make incremental recertification a first-class *query* and turn modularization into a measurable governance lever.**

v175 introduced assurance debt curves and “receipt diversity” tradeoffs.
v176 adds an operator-facing primitive: given a predecessor ABOM and a candidate update, compute the impacted obligations, emit a minimal recheck slice, and account the resulting work against an explicit **assurance-change budget**.

### What changed (paper)
- Added \S\ref{sec:impact-queries}: **Incremental recertification queries and assurance-change budgets**.
- Added a new synthetic figure + table:
  - `figs/assurance_frontier_v176.pdf`
  - `tables/assurance_frontier_summary_v176.tex`
  This frames evidence factoring (more independently versioned artifacts) as an explicit knob that reduces tail recertification cost.
- Strengthened WCO case study with deeper transparency context (witness cosigning + gossip literature; operational Rekor/omniwitness references).
- Expanded related work: continuous assurance-case maintenance (ETB) and ML lifecycle provenance (Atlas).

### What changed (artifacts)
- New tool: `tools/impact_query_v176.py` (changed-node diff → impacted obligations → minimal slice ABOM + debt report).
- New runnable example: `examples/impact_demo_v176/` with `prev_abom.json`, `new_abom.json`, and emitted `impact_slice_abom_v176.json`.
- New benchmark script: `tools/assurance_frontier_v176.py` (frontier plot + LaTeX summary table).

### Next risks to take (v177+)
- **Correlated-failure receipts:** extend receipt-diversity modeling to include shared-cause witness/log outages (profile-encoded correlation families).
- **Private novelty checks:** strengthen NDC with privacy-preserving “new case” sketches (e.g., salted tag commitments / VRF-tagged IDs) to resist benchmark-case recycling without exposing test content.
- **Realistic coupling audits:** run the frontier + debt curves on a larger, more realistic ABOM graph (multi-tenant endpoints, shared tools, shared monitors, multi-suite eval).


## 2026-02-24 (v174)

**Make recertification cost explicit: introduce *assurance debt* and promote WCO split-view resistance into main case studies.**  
v160--v173 established audit-local diffs, delta packages, and freshness/cadence policies. v174 sharpens the paper’s central engineering claim: *continuous recertification is a measurable cost surface*, and ABOM locality turns that surface into an operable metric.

### What changed (paper)
- Updated draft tag to **v174** (Feb 24, 2026).
- Rewrote the abstract for clearer “three degrees of freedom” framing: **change**, **adaptivity**, **governance drift**.
- Added a new Introduction paragraph: **Assurance debt and recertification cost** (defines the expected impacted-check surface as an engineering metric).
- Added a new main-text case study subsection: **Witnessed checkpoints and multi-log pinning (WCO)**, with runnable split-view fail-closed examples from `examples/wco_demo_v1/`.

### Next risks to take (v175+)
- **No-op update defenses:** add a *Nontrivial Delta Certificate (NDC)* that ties “update” to measurable change (e.g., hash diversity + basic distribution-shift attestation), and make profiles able to require it.
- **Receipt diversity composition:** formalize how multiple independent receipts (multi-log + WCO quorums) compose with max-gap cadence policies, and quantify availability vs security tradeoffs.
- **Assurance debt curves:** plot impacted-surface distributions for more realistic shared-dependency graphs (suites + monitors + portfolios) and define an “assurance SLO” (e.g., P95 impacted fraction under prompt-only changes).


## 2026-02-24 (v173)

**Burstiness matters: add a *max-gap* cadence policy for freeze resistance.**  
v170/v172 introduced freshness windows and a cadence constraint of the form “at least $K$ updates in the last $W$ days.” In v173 we make the liveness requirement strictly stronger and executable: a profile can additionally bound the **maximum inter-update gap** within the trailing window, preventing *bursty* schedules that satisfy $K$-in-$W$ but still allow long freeze intervals.

### What changed (paper)
- Updated draft tag to **v173** (Feb 24, 2026).
- Extended \S\ref{sec:bfc} with a new paragraph: **Burstiness and max-gap liveness (v173)**.
- Added a deterministic toy demo:
  - **Table** \ref{tab:bfc-gap}: regular vs bursty schedules under freshness, $K$-in-$W$, and max-gap.
  - **Figure** \ref{fig:bfc-gap}: timeline visualization of the same schedules.
- Connected the “freeze attack” framing to classic software-update defenses (TUF expirations / timestamp role), cited via `tuf_spec_latest` and `tuf_ccs2010`.

### What changed (artifacts)
- Added `tools/bfc_gap_demo_v173.py` (generates `tables/bfc_gap_demo_v173.tex` and `figs/bfc_gap_demo_v173.pdf`).
- Extended the kernel BFC validator in `tools/ocf_resolver.py` with optional **max-gap** enforcement (fail-closed), adding status codes `bad-maxGap` and `gap-too-large`.
- Updated `tables/bfc_failure_codes_v172.tex` to include the new status codes.

### Next risks to take (v174+)
- **Window semantics:** formalize whether gaps are measured over receipt time, declared update time, or both; add a conservative rule that binds them.
- **No-op update attacks:** require an accompanying “delta” certificate that proves non-trivial change (e.g., content-hash diversity or distributional shift attestations).
- **Multi-log pinning:** require two independent transparency receipts and show how witness sets compose with the max-gap policy.

## 2026-02-24 (v170)

**Freshness is not enough: add *cadence* gates for live benchmarks.**  
v169 introduced Bank Freshness Certificates (BFC) as a fail-closed receipt for recency. v170 tightens the story by making *benchmark liveness* checkable: profiles can require *both* (i) max-age freshness and (ii) a minimum update cadence within the same window.

### What changed (paper)
- Updated draft tag to **v170** (Feb 24, 2026).
- Expanded \S\ref{sec:bfc} with a new paragraph: **Cadence constraints and freeze resistance**.
- Added a deterministic toy sweep:
  - **Table** \ref{tab:bfc-sweep}: acceptance rate under combined freshness window $W$ and cadence constraint $K$.
  - **Figure** \ref{fig:bfc-sweep}: sweep visualization.

### What changed (artifacts)
- Added `tools/bfc_cadence_sweep_v170.py` (generates the sweep JSON + LaTeX table + figure).
- Added `examples/bfc_livebench_v170/bfc_sweep_results.json`.
- Added `tables/bfc_acceptance_sweep_v170.tex` and `figs/bfc_acceptance_sweep_v170.pdf` (+ png).

### Next risks to take (v171+)
- **Hard-fail resolver gate:** make freshness+cadence a first-class predicate in `tools/ocf_resolver.py` (not just a demo), with clear failure reasons in the trace.
- **Receipt diversity:** demonstrate the same BFC gate with two independent transparency logs (multi-log pinning) and show how it composes with witness sets.
- **Adversarial updates:** explore minimal “no-op update” attacks and add a content-based sanity check (e.g., require some measured distributional shift signal to accompany updates).

## 2026-02-24 (v169)

**Bank Freshness Certificates (BFC): make "live benchmark recency" fail-closed and replayable.**

### What changed (paper)
- Updated draft tag to **v169** (Feb 24, 2026).
- Added a new subsection: **Bank Freshness Certificates (BFC)** (\S
  ef{sec:bfc}).
  - Defines a minimal, checkable receipt that binds an evaluation to an *admissible* bank root set via (i) BUC replay and (ii) a timestamped transparency receipt.
  - Adds Figure 
  ef{fig:bfc} illustrating the freshness window gate.
- Strengthened the motivation for dynamic evaluation by connecting to *live-updatable* benchmark pipelines:
  - SWE-bench-Live (continuous harvesting + executable envs),
  - SWE-Bench++ / SWE-Universe (scalable PR-derived task generation),
  - LiveBench (monthly refresh with objective grading).
- Grounded the timestamping mechanism in transparency-service practice (SCITT architecture; Sigstore/Rekor signed timestamps).

### What changed (repo artifacts)
- New tool: `tools/bfc_livebench_demo_v169.py`
  - Emits an evolving bank (v1→v2→v3), BUC consistency proofs, a toy SCITT receipt for the latest bank-commit digest, and a BFC object.
- New runnable example bundle: `examples/bfc_livebench_v169/`
  - Includes `bfc_v169.json`, `buc_*.json`, `bank_commit_*.json`, `scitt_receipt_bank_commit_v3.json`, and `freshness_report.json`.
- New figure: `figs/bank_freshness_certificate_v169.pdf` (+ `.png`).

### Next risks to take
- Make BFC a first-class resolver plugin:
  - treat missing/expired freshness receipts as hard failures for dependent performance claims.
- Add *cadence* policies (not just max-age):
  - require "at least one update every Δ days" and check it from BUC + receipt chains.
- Add a small "live benchmark" simulator:
  - weekly task harvesting, dockerized verifiers, and DSC sampling over rotating admissible roots.

## v201 (2026-02-26)
- **EU AI Act timeline sharpened**: incorporated the Digital Omnibus (AI) proposal’s *decision-linked entry-into-application* mechanism and latest-by caps (Annex III: **2 Dec 2027**, Annex I: **2 Aug 2028**), and updated the timeline figure to v2.
- **Policy drift debt**: made “newly-invalidated verification surface” a first-class metric; added a toy accounting table (Table \ref{tab:policy-drift-debt}) and updated the IDC listing.
- **Tooling**: added `interface_drift_delta_cert_v201.py` (extended refinement oracle + drift-debt scan) and `ai_act_timeline_figure_v201.py` to regenerate Figure \ref{fig:ai-act-timeline}.
- **Demos**: added `examples/interface_drift_delta_cert_demo_v201/` (freshness) and `examples/policy_drift_debt_demo_v201/` (freshness / threshold / key pin swap).

## v202 (2026-02-26)
- **Policy Update Transparency (PUT) logs**: added a CT-style, append-only profile-update log design to prevent split-view compliance and make profile evolution non-equivocating. Added a new contribution bullet and an in-paper PUT receipt listing.
- **New tooling**: `tools/policy_update_log_v202.py` (append-only log + inclusion/consistency proofs using RFC 9162 Merkle semantics) and `tools/verify_put_receipt_v202.py` (minimal offline verifier).
- **Runnable demo**: `examples/policy_update_transparency_demo_v202/` generates a small profile-update log, STHs, PUT receipts, a consistency proof (2→3), and a verifier output.
- **Threat model update**: expanded the interface drift taxonomy table with an explicit "split-view profile history" row and mitigation via PUT receipts + STH gossip/witnesses.

## v203 (2026-02-26)

**Profile Resolution Contracts (PRCs) + drift budgets: make receipt discovery and profile tightening operationally checkable.**

### What changed (paper)
- Updated draft tag to **v203** (Feb 26, 2026).
- Added **Profile Resolution Contracts (PRCs)**: a digest-pinned, SCRAPI-shaped contract that pins *how to resolve* PUT proofs (endpoints, log identity, witness policy, STH staleness) and treats receipt discovery as a versioned dependency (Listing \ref{lst:prc}).
- Added **drift budgets**: SRE-style error budgets over **policy drift debt**, enforced as release constraints and checked from sequences of IDCs.
- Strengthened the “moving compliance interface” motivation with evidence that CEN/CENELEC adopted exceptional measures to **accelerate AI standards development** for the EU AI Act (including an enquiry for prEN 18286), reinforcing that compliance support instruments themselves drift.

### What changed (repo artifacts)
- New tool: `tools/profile_resolution_contract_v203.py` (create PRCs; compute PRC digests).
- New tool: `tools/prc_put_resolve_v203.py` (demo adapter: resolve a PUT receipt from PRC + JSONL log).
- New tool: `tools/verify_put_receipt_v203.py` (verifies inclusion + optional PRC-pinned `sth.log_id`).
- New tool: `tools/drift_budget_check_v203.py` (checks a drift budget over a timeline of IDC reports).
- New demo bundle: `examples/prc_put_demo_v203/` (PRC + PUT receipt resolution + verification).
- New demo bundle: `examples/drift_budget_demo_v203/` (30d→7d→1d tightening sequence with a passing drift budget).
- New profiles: `profiles/delta_scitt_freshness_days7_v1.json` and `profiles/delta_scitt_freshness_days30_v1.json`.

### Next risks to take (v204+)
- **Stapled PRCs:** treat PRCs themselves as logged statements (e.g., SCITT) so resolution contracts are non-equivocating and auditable.
- **Witness enforcement:** extend PRCs to require witness signatures (k-of-n) over STHs/receipts, and add a small gossip simulator.
- **Change-control gates:** connect drift budgets to *announced refresh plans* (e.g., require a mitigation artifact for updates exceeding a debt threshold).

## v204 (2026-02-26)

**Stapled PRCs + PUT gossip: make the resolution interface non-equivocating and operationally monitorable.**

### What changed (paper)
- Updated draft tag to **v204**.
- Added **Stapled PRCs and gossipable profile evolution** as a new contribution bullet.
- Extended the PRC section with **split-view detection**: if two parties observe STHs of the same size with different roots, or cannot obtain a valid consistency proof between checkpoints, they have cryptographic evidence of equivocation.

### What changed (repo artifacts)
- New tool: `tools/put_gossip_sim_v204.py` (generates inconsistent PUT views + a gossip report using RFC 9162 consistency verification).
- New runnable demo: `examples/put_gossip_demo_v204/` (log_a/log_b + `gossip_report.json`).

### Next risks to take (v205+)
- **Signed STHs / witness cosigning:** add a toy key + signature field to STH objects and require witness quorum over checkpoints.
- **RUT (Resolution Update Transparency):** log PRC digests and staple them alongside profile PUT receipts so both policy and its resolution contract are non-equivocating.

---

# v205: RUT logs + WCO over PUT/RUT STHs

Implemented a minimal **Resolution Update Transparency (RUT)** log for PRC updates (`tools/resolution_update_log_v205.py`) with RFC 9162 inclusion/consistency proofs and a matching minimal verifier (`tools/verify_rut_receipt_v205.py`).

Added **WCO witness cosigning over STHs** (`tools/wco_sth_bundle_gen_v205.py`) so PUT/RUT checkpoints can be gossipable *and* offline-verifiable via threshold witness bundles (same bundle format + verifier plugin as the existing WCO demo).

Added a combined demo generator (`tools/put_rut_wco_demo_v205.py`) that emits:
- `examples/put_wco_demo_v205/`: PUT receipts + WCO bundle over latest STH
- `examples/rut_wco_demo_v205/`: RUT receipts + WCO bundle over latest STH

Paper updates (to do / done in v205):
- Promote “Resolution Update Transparency” from a mention to a concrete log + receipts.
- Make the “signed STH / witness cosigning” story operational for PUT/RUT, not just SCITT.


---

## v206 (2026-02-26)

**Resolution Drift Debt (RDD): budget and localize PRC updates (the missing half of interface-drift governance).**

### What changed (paper)
- Updated draft tag to **v206**.
- Fixed a typo in the contributions list (\textbf{} formatting for v205).
- Added **Resolution drift debt (RDD) and resolution-drift budgets (v206)** as a new contribution.
- Added a new paragraph + listing defining RDD and explaining how PRC updates (base URL, log ID, witness quorum, STH staleness) induce newly-invalidated cached resolution summaries, with a conservative refinement oracle for monotone PRC fields.

### What changed (repo artifacts)
- New tool: `tools/resolution_drift_debt_v206.py` — computes an RDD report for an old/new PRC pair by scanning a cache of resolution summaries (STH age, witness quorum, SCRAPI draft).
- New runnable demo: `examples/resolution_drift_debt_demo_v206/` — shows a refinement update (1h→5m staleness) localizes refresh work, while non-monotone resolution changes conservatively force full re-resolution.

### Research refresh used in v206
- SCRAPI remains at `draft-ietf-scitt-scrapi-07` (Feb 2026) and is treated as an explicitly pinned interface in PRCs. (See IETF datatracker + archive copy.)
- AI Act Article 6 guidance deadline remains a live example of governance-interface drift: the Service Desk text still names 2 Feb 2026, while reporting notes the deadline was missed.


---

## v223 (2026-02-26)

**Verified publishability gates: close verification DoFs with AVS + a falsifiable omission attack demo.**

### What changed (paper)
- Added a concrete, artifact-backed omission attack table (Table \texttt{verify-dof-attack}) showing that structural DoF closure (DoFC) can pass while an axis is never actually checked, and that requiring AVS forces fail-closed rejection.
- Strengthened the agentic RAG spine motivation with a full-stack privacy note and citation to AgentLeak (internal-channel leakage).

### What changed (repo artifacts)
- New runnable demo directory: \texttt{examples/verify\_dof\_attack\_v222/}.
  - Includes a composite ABOM, a valid MER+MVS, a good resolver trace, and a tampered trace with DRC events removed.
  - Includes AVS + DoFCv outputs demonstrating \textbf{publish} vs \textbf{reject} under the same structural evidence.

### Next risks to take
- **AVS attestation (AVR):** sign AVS as a DSSE in-toto predicate and staple a transparency receipt, so AVS itself is non-equivocating and replayable.
- **Real (not toy) verifier-misalignment experiment:** run the resolver under intentionally misconfigured verifier profiles (missing plugins / loosened checks) and show DoFCv passes but DoFCv+AVS fails on real bundles.

---

## v256 (2026-02-28)

**Share-aware, cost-aware repair planning: synthetic benchmark + improved optimizer.**

### What changed (paper)
- Updated IDC paper draft tag to **v256**.
- Added a new subsection (\S\ref{sec:synth}) with a synthetic benchmark showing that when many new \texttt{anyOf} requirements share an acceptable evidence pathway, a cost-aware planner can dramatically reduce recertification cost by selecting shared actions.
- Added a new table (\texttt{tables/idc\_synth\_bench\_v256.tex}) and figure (\texttt{figs/idc\_synth\_cost\_none\_v256.png}).

### What changed (repo artifacts)
- New module: \texttt{tools/idc\_optimizer\_v256.py}.
  - Exact branch-and-bound for small instances.
  - Local-search + random restarts for larger instances.
- New runnable benchmark: \texttt{tools/idc\_synth\_bench\_v256.py}.
  - Emits a reproducible synthetic profile update family + ABOM fixtures.
  - Produces LaTeX table + plots for the paper.

### Research refresh used in v256
- Updated Key Transparency architecture citation to \texttt{draft-ietf-keytrans-architecture-06} (Jan 2026) in \texttt{references.bib}.

---

## v263 (2026-02-28)

**Churn-sensitive assurance debt + artifact-aware admission control (tail rework pressure).**

### Core idea
- The simple ``debt mass'' observable (fraction of claims currently invalid) is a \emph{union}: repeated changes to already-invalid claims do not show up.
- In practice, repeatedly-hot shared artifacts create \emph{rework} (more eval runs, evidence edits, sign-offs) even when the same claims are already invalid.
- Track a second observable: **churn debt** = outstanding validation work units per claim.

### What changed (repo artifacts)
- New benchmark + controller: `tools/assurance_adc_artifact_churn_v263.py`.
  - Uses the fleet ABOM impact sets directly.
  - Simulates a fixed recertification capacity (work units/day) and a hard fail-closed cap on boolean invalidation.
  - Compares FIFO, value/\Delta-bool greedy, single shadow price, and **artifact-aware** shadow prices for top-$K$ blast-radius artifacts.
  - Emits: `figs/assurance_adc_churn_value_v263.pdf`, `figs/assurance_adc_churn_p95_v263.pdf`, `tables/assurance_adc_churn_summary_v263.tex`.

### What changed (papers)
- `paper_assurance_admission_control.tex`: added a new v263 subsection tying blast-radius attribution to multi-resource shadow prices (boolean invalidation + churn).
- `paper_assurance_debt.tex`: added a brief note on churn debt as an extension to unioned invalidation.

### Next risks to take
- **Batching / coalescing semantics:** if a claim is already invalid, another change should (sometimes) add \emph{less} than 1 unit of churn (delta validation reuse). Fit a concave cost model.
- **Multi-artifact changes:** extend the benchmark to changes that touch sets of artifacts (e.g., prompt+policy+retriever) and test whether per-artifact prices still stabilize tails.
- **Empirical calibration:** extract churn/clear rates from real CI and governance queues; validate that churn explains incidents not predicted by unioned debt.
