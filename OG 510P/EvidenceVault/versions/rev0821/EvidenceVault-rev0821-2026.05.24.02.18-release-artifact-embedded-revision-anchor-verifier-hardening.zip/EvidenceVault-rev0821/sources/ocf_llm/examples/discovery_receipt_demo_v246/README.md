# discovery_receipt_demo_v246

Toy demo of **accountable discoverability** via a *log-backed map* (verifiable key directory).

- `map_entries_viewA.json` and `map_entries_viewB_split.json` are two views of the same mapId.
  In the split view, the same `keyDigest` maps to a different `valueDigest`.
- `viewA/` and `viewB/` contain signed map checkpoints and discovery receipts.
- `combined_receipts/` contains one receipt from each view.

Run:

```bash
python3 tools/ocf_discovery_receipt_demo_v246.py
```

The last step runs `tools/ocf_discovery_drift_monitor_v246.py`, which flags **map equivocation** when multiple roots are observed for the same `mapId`.
