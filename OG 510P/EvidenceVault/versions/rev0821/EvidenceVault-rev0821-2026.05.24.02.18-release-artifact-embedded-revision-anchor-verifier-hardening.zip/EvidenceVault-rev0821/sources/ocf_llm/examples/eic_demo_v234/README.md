# EIC demo (v234)

This demo shows an **Evaluation Integrity Certificate (EIC)** that binds:
- a committed suite (via a Merkle root over canonical JSON)
- a per-case evaluation log that must cover the suite exactly once
- a tally rule (`eventField`)

## Run

From repo root:

```bash
python3 tools/eic_verify_v234.py --cert examples/eic_demo_v234/eic.json
```

Tamper with any line in the suite or the log and verification should fail closed.
