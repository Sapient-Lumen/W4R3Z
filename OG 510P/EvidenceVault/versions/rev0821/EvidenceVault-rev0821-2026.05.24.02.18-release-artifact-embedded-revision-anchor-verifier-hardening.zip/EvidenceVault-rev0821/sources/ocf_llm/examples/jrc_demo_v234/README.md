# JRC demo (v234)

This demo shows a **Judge Reliability Certificate (JRC)** that upper-bounds the judge's
false-negative rate on a calibration set with ground truth.

## Run

From repo root:

```bash
python3 tools/jrc_verify_v234.py --cert examples/jrc_demo_v234/jrc.json
```

Editing any line in the calibration log should cause verification to fail.
