# Change-Control Certificate demo (v207)

This demo shows a combined governance-interface update stapled into a single ChangeControlCertificate (CCC):

- Policy update (profile): freshness 30d -> 7d and adds obligationKinds requiring drift evidence.
- Resolution update (PRC): tightens maximum STH staleness 3600s -> 300s.
- PUT receipt proves the profile digest is in the profile-update log.
- RUT receipt proves the PRC digest is in the PRC-update log.
- IDC + RDD quantify the blast radius (policy drift debt + resolution drift debt).
- WCO witness bundles cosign PUT/RUT checkpoints for offline verification.

Re-run:

```bash
python3 tools/ccc_demo_v207.py --out examples/change_control_demo_v207
```

Verify outputs:

```bash
python3 tools/verify_put_receipt_v202.py --receipt examples/change_control_demo_v207/put/step1/put_receipt.json
python3 tools/verify_rut_receipt_v205.py --receipt examples/change_control_demo_v207/rut/step1/rut_receipt.json
python3 tools/wco_verify_bundle_v205.py --bundle examples/change_control_demo_v207/wco/wco_put_bundle.json
python3 tools/wco_verify_bundle_v205.py --bundle examples/change_control_demo_v207/wco/wco_rut_bundle.json
python3 tools/change_control_certificate_v207.py --put-receipt examples/change_control_demo_v207/put/step1/put_receipt.json --rut-receipt examples/change_control_demo_v207/rut/step1/rut_receipt.json --idc examples/change_control_demo_v207/idc.json --rdd examples/change_control_demo_v207/rdd.json --policy-budget-fraction 0.08 --resolution-budget-fraction 0.10 --wco-put-bundle examples/change_control_demo_v207/wco/wco_put_bundle.json --wco-rut-bundle examples/change_control_demo_v207/wco/wco_rut_bundle.json --out /tmp/ccc.json
```
