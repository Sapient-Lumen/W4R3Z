# ABOM examples

These JSON examples are illustrative and intentionally small. They are designed to be:

- schema-valid (see `../abom_schema_draft.json`),
- easy to diff,
- easy to map into SPDX/CycloneDX export views.

Files:

- `example_abom_v1.json`: minimal ABOM with a predecessor pointer and diff.
- `lean_proof_abom.json`: ABOM for an LLM-assisted Lean proof workflow (deterministic checking + provenance).
- `lean_spec_binding_abom.json`: illustrative `spec_binding` obligation that ties a formal theorem statement to an informal requirement clause (review + tests as evidence).

- `lean_passk_abom.json` and `lean_passk_abom_v2.json`: pass@k autoformalization case study (selection + MNO/FDC) with transcript-binding attempt-log commitments.
- `lean_passk_attempt_log_v1.jsonl` and `lean_passk_attempt_log_v2.jsonl`: synthetic attempt logs (digests-only) committed-to by the ABOMs.
- `resolver_trace_lean_passk.yaml` and `resolver_trace_lean_passk_v2.yaml`: resolver output, including evidence digest verification and audit-locality slice.

- `agentic_rag_abom.json`: ABOM for an agentic RAG system with layered defenses, a DGO cause taxonomy, and an FDC retry certificate.


- `ceb_toy_abom.json`: ABOM that demonstrates **CEB** for partial-overlap causes (prompt-injection + shared parser bug).
- `resolver_trace_ceb_toy.yaml`: replayable trace emitted by `tools/ocf_resolver.py` for the CEB toy.

- `eic_qic_latency_abom.json`: ABOM showing **EIC+QIC**: suite-commitment + log coverage + exceedance tally (EIC) paired with an exact binomial-tail quantile bound (QIC).
- `eic_qic_latency_suite_v1.jsonl` / `eic_qic_latency_eval_log_v1.jsonl` / `eic_qic_latency_summary_v1.json`: synthetic suite, log, and summary evidence.
- `resolver_trace_eic_qic_latency.yaml`: resolver trace validating both certificates (fail-closed).

- `bestof_sampling_abom.json`: toy ABOM showing best-of-$m$ sampling, with explicit MNO+MAO obligations and a small CEB certificate.
- `resolver_trace_bestof5.yaml`: resolver output for `bestof_sampling_abom.json`.

- `rejection_sampling_abom.json`: toy ABOM showing an accept/reject retry loop (RSO) and its geometric-series amplification.
- `resolver_trace_rejection_sampling.yaml`: resolver output for `rejection_sampling_abom.json`.

- `lean_passk_abom_privacy.json`: privacy-preserving variant where the attempt log itself is not present; the ABOM carries only a Merkle-root commitment (`kind: attempt_log_commitment`) plus a SIC inclusion proof for the selected leaf.
- `resolver_trace_lean_passk_privacy.yaml`: resolver trace for the privacy variant; shows `status: ok-membership-only` and `predicateAudited: false` in the SIC check.

- `sic_zk_dual_commitment_sketch_abom.json`: sketch showing SIC-ZK with **dual commitments** (external SHA-256 root + internal SNARK-friendly root) and a bridge proof reference.

- `cpc_profile_conformance_sketch_abom.json`: sketch showing a **Conformity Proof Certificate (CPC)** for profile conformance at tier T5, paired with an explicit verifier conformance obligation (VCO).


### APT projection (selective disclosure)

- `apt_projection_keep_minimal.json`: toy allowlist for a public projection.
- `apt_projection_lean_autoformalization_specbind.json`: projection object produced by `tools/abom_project.py`.

- `dac_prev_latency_abom.json` / `dac_new_latency_abom.json`: minimal release-to-release example demonstrating a **DAC** that certifies the ABOM diff and impacted slice.

- `sabom_mcp_episode_abom_scitt_published.json`: SABOM example with a toy SCITT receipt binding the ABOM digest to a transparency checkpoint.
- `sabom_mcp_episode_abom_scitt_published_v2.json`: same as above, but references `scitt_receipt_sabom_mcp_episode_v2.json` which demonstrates non-power-of-two RFC 9162 proof shapes.
- `scitt_receipt_sabom_mcp_episode_v2.json`: toy SCITT-like receipt (RFC 9162 inclusion + consistency proof).
- `tlog_pub_proof_sabom_mcp_episode_v3.json`: toy CT-style publication proof with non-power-of-two tree size.


### Verifier conformance artifacts (VCO)

- `sic_zk_toy_privacy_vco_vte_abom.json`: toy SIC-ZK privacy ABOM extended with VTC+XVC+VTE (attested VCO bundle).
- `sic_zk_toy_privacy_vco_vte_vtp_abom.json`: same, but adds **VTP**: a SCITT-style statement receipt proving the VCO bundle digest was published to a transparency service.
- `scitt_receipt_vco_bundle_toy_sic_zk_v1.json`: toy statement receipt for the VCO bundle digest.
- `resolver_trace_sic_zk_toy_privacy_vco_vte_vtp.yaml`: resolver trace showing VTC+XVC+VTE+VTP validation.
