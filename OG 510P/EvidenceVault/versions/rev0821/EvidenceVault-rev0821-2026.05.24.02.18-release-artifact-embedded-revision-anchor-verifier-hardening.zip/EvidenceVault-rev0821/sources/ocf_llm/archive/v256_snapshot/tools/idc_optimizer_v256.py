#!/usr/bin/env python3
"""idc_optimizer_v256.py

Cost-aware IDC repair planning: choose (one) option per requirement to minimize
*union* action cost.

Problem:
  - We have requirements R_i.
  - Each R_i has options O_{i,j}, each option is a set of actions.
  - Each action a has cost c(a).
  - Selecting an option per requirement yields a union of actions U.
  - Objective: minimize sum_{a in U} c(a).

This is a variant of minimum-cost set selection / group set cover and is
NP-hard in general. For the paper + demos we provide:
  - exact branch-and-bound for small instances
  - fast local search with random restarts for larger instances

The interface mirrors v255's optimize_actions() output:
  {"total_cost": float, "actions": [..], "selection": [..], "method": str}
"""

from __future__ import annotations

import random
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Set, Tuple


@dataclass
class OptResult:
    total_cost: float
    actions: List[str]
    selection: List[Dict[str, Any]]
    method: str
    wall_ms: float


def _action_cost_fn(costs: Dict[str, float]):
    def c_cost(a: str) -> float:
        if a in costs:
            return float(costs[a])
        if a.startswith("mint_evidence:"):
            return float(costs.get("mint_evidence", 25.0))
        if a.startswith("rerun_obl:"):
            return float(costs.get("rerun_obl:DEFAULT", 8.0))
        if a.startswith("add_artifact_kind:"):
            return float(costs.get("add_artifact_kind:DEFAULT", 7.0))
        return 50.0

    return c_cost


def _union_cost(actions: Set[str], c_cost) -> float:
    return float(sum(c_cost(a) for a in actions))


def optimize_exact(requirements: List[Dict[str, Any]], costs: Dict[str, float]) -> OptResult:
    """Exact branch-and-bound (small n)."""
    t0 = time.perf_counter()
    c_cost = _action_cost_fn(costs)

    best_cost = float("inf")
    best_sel: List[Dict[str, Any]] = []
    best_actions: Set[str] = set()

    # Pre-sort requirements by (min option incremental cost) to improve pruning
    def _opt_cost(opt: Dict[str, Any]) -> float:
        return float(sum(c_cost(a) for a in set(opt.get("actions", []) or [])))

    reqs = []
    for r in requirements:
        opts = list(r.get("options", []) or [])
        if not opts:
            opts = [{"kind": "missing", "actions": []}]
        reqs.append({"id": r["id"], "options": opts})

    reqs.sort(key=lambda r: min(_opt_cost(o) for o in r["options"]))

    def rec(i: int, chosen: Set[str], running_cost: float, sel: List[Dict[str, Any]]):
        nonlocal best_cost, best_sel, best_actions
        if running_cost >= best_cost:
            return
        if i >= len(reqs):
            best_cost = running_cost
            best_sel = list(sel)
            best_actions = set(chosen)
            return

        req = reqs[i]
        for opt in req["options"]:
            opt_actions = set(opt.get("actions", []) or [])
            delta = opt_actions - chosen
            delta_cost = sum(c_cost(a) for a in delta)
            sel.append({"req": req["id"], "opt": opt})
            rec(i + 1, chosen | opt_actions, running_cost + delta_cost, sel)
            sel.pop()

    rec(0, set(), 0.0, [])
    t1 = time.perf_counter()

    return OptResult(
        total_cost=float(best_cost),
        actions=sorted(best_actions),
        selection=best_sel,
        method="exact-bnb",
        wall_ms=1000.0 * (t1 - t0),
    )


def optimize_local_search(
    requirements: List[Dict[str, Any]],
    costs: Dict[str, float],
    restarts: int = 24,
    iters: int = 2000,
    seed: int = 7,
) -> OptResult:
    """Local search with random restarts.

    We maintain one option per requirement. Cost is computed from the union of
    actions. We use action usage counts for O(1) delta evaluation.
    """
    t0 = time.perf_counter()
    rng = random.Random(seed)
    c_cost = _action_cost_fn(costs)

    # Normalize req/opts
    reqs: List[Tuple[str, List[Dict[str, Any]]]] = []
    for r in requirements:
        rid = str(r.get("id"))
        opts = list(r.get("options", []) or [])
        if not opts:
            opts = [{"kind": "missing", "actions": []}]
        # canonicalize actions list
        for o in opts:
            o["actions"] = sorted(set(o.get("actions", []) or []))
        reqs.append((rid, opts))

    def option_raw_cost(opt: Dict[str, Any]) -> float:
        return float(sum(c_cost(a) for a in set(opt.get("actions", []) or [])))

    # Precompute per requirement: options sorted by raw cost
    reqs_sorted_opts: List[Tuple[str, List[Dict[str, Any]]]] = []
    for rid, opts in reqs:
        opts2 = sorted(opts, key=option_raw_cost)
        reqs_sorted_opts.append((rid, opts2))

    best_cost = float("inf")
    best_actions: Set[str] = set()
    best_sel_idx: List[int] = []

    def init_selection(mode: str) -> List[int]:
        sel = []
        for _, opts in reqs_sorted_opts:
            if mode == "cheapest":
                sel.append(0)
            elif mode == "random":
                # biased random: cheaper options more likely
                weights = [1.0 / (1.0 + option_raw_cost(o)) for o in opts]
                s = sum(weights)
                x = rng.random() * s
                acc = 0.0
                j = 0
                for k, w in enumerate(weights):
                    acc += w
                    if acc >= x:
                        j = k
                        break
                sel.append(j)
            else:
                sel.append(0)
        return sel

    def eval_selection(sel_idx: List[int]) -> Tuple[float, Dict[str, int]]:
        counts: Dict[str, int] = {}
        for (rid, opts), j in zip(reqs_sorted_opts, sel_idx):
            acts = opts[j].get("actions", []) or []
            for a in acts:
                counts[a] = counts.get(a, 0) + 1
        actions = set(counts.keys())
        return _union_cost(actions, c_cost), counts

    def selection_actions(counts: Dict[str, int]) -> Set[str]:
        return set(k for k, v in counts.items() if v > 0)

    def try_improve(sel_idx: List[int]) -> Tuple[float, Dict[str, int], List[int]]:
        cost, counts = eval_selection(sel_idx)

        for _ in range(iters):
            improved = False
            # random scan order
            idxs = list(range(len(reqs_sorted_opts)))
            rng.shuffle(idxs)
            for i in idxs:
                rid, opts = reqs_sorted_opts[i]
                cur_j = sel_idx[i]
                cur_actions = set(opts[cur_j].get("actions", []) or [])

                # compute removable action cost if we drop current option
                # but only if no other option uses the action
                removable: List[str] = [a for a in cur_actions if counts.get(a, 0) == 1]
                removable_cost = sum(c_cost(a) for a in removable)

                best_delta = 0.0
                best_j = cur_j

                for j, opt in enumerate(opts):
                    if j == cur_j:
                        continue
                    new_actions = set(opt.get("actions", []) or [])
                    add = [a for a in new_actions if counts.get(a, 0) == 0 or (a in cur_actions and counts.get(a, 0) == 1 and a not in new_actions)]
                    # the above is messy; easier compute delta precisely:
                    # delta_cost = cost(new_union) - cost(old_union)
                    # We can compute by removals and additions:
                    # removals = actions in cur_actions not in new_actions with count==1
                    removals = [a for a in cur_actions if a not in new_actions and counts.get(a, 0) == 1]
                    adds = [a for a in new_actions if a not in cur_actions and counts.get(a, 0) == 0]
                    delta = sum(c_cost(a) for a in adds) - sum(c_cost(a) for a in removals)
                    if delta < best_delta:
                        best_delta = delta
                        best_j = j

                if best_j != cur_j:
                    # apply move
                    new_actions = set(opts[best_j].get("actions", []) or [])
                    # decrement current
                    for a in cur_actions:
                        counts[a] = counts.get(a, 0) - 1
                        if counts[a] <= 0:
                            counts.pop(a, None)
                    # increment new
                    for a in new_actions:
                        counts[a] = counts.get(a, 0) + 1
                    sel_idx[i] = best_j
                    cost += best_delta
                    improved = True

            if not improved:
                break

        return cost, counts, sel_idx

    # Run restarts
    modes = ["cheapest"] + ["random"] * max(0, restarts - 1)
    for mode in modes:
        sel = init_selection(mode)
        c, counts, sel2 = try_improve(sel)
        if c < best_cost:
            best_cost = c
            best_actions = selection_actions(counts)
            best_sel_idx = list(sel2)

    # Materialize selection
    selection: List[Dict[str, Any]] = []
    for (rid, opts), j in zip(reqs_sorted_opts, best_sel_idx):
        selection.append({"req": rid, "opt": opts[j]})

    t1 = time.perf_counter()
    return OptResult(
        total_cost=float(best_cost),
        actions=sorted(best_actions),
        selection=selection,
        method=f"local-search(restarts={restarts})",
        wall_ms=1000.0 * (t1 - t0),
    )


def optimize_auto(
    requirements: List[Dict[str, Any]],
    costs: Dict[str, float],
    exact_n_max: int = 18,
    **kwargs,
) -> OptResult:
    """Pick exact for small instances, heuristic otherwise."""
    if len(requirements) <= exact_n_max:
        return optimize_exact(requirements, costs)
    return optimize_local_search(requirements, costs, **kwargs)


if __name__ == "__main__":
    raise SystemExit("This module is intended to be imported.")
