# v251 snapshot (2026-02-28)

This folder is a lightweight capture of the *current* evolving paper-suite state at v251.

Highlights:
- `paper_v251.tex`: main OCF-LLM paper (contributions updated to include IDCs + ADCP gate).
- `paper_discovery_v251.tex`: accountable discoverability companion (references the v251 conformance bundle).
- `paper_idc_v251.tex`: IDC companion with a worked example table generated from the demo.

New v251 artifacts:
- `discovery_adcp_profile_v251.json`: toy ADCP-ish discovery profile (depth/mode/size bounds + SDT/MID requirement).
- `vectors_v251.json`: runnable discoverability conformance vectors.
- `idc_article53_v251.json`: toy IDC object for Article 53 v1→v2.
- `discovery_conformance_vectors_v251.tex`: paper-friendly summary of the vector bundle.
- `idc_article53_impact_v251.tex`: paper-friendly impact-slice table for the IDC demo.

The full repository (tools, examples, generators) lives one directory up.
