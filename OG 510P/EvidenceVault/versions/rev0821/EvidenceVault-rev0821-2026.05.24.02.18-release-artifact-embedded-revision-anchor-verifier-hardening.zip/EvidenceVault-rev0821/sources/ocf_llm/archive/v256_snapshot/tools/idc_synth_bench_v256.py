#!/usr/bin/env python3
"""idc_synth_bench_v256.py

v256: synthetic benchmark for *cost-aware* IDC repair planning.

Goal
----
Demonstrate that when profile updates introduce (or clarify) alternative
compliance pathways (anyOf), an IDC can compute an *action plan* that is:
  - localized (only new requirements), and
  - cost-aware (choose the cheapest evidence pathway), and
  - share-aware (prefer shared artifacts/evidence that satisfy many requirements).

We build synthetic profile updates where each new requirement can be satisfied
by either:
  - a unique per-requirement artifact ("doc_i") with moderate cost, or
  - a shared artifact kind (chosen from a small pool) with higher *individual*
    cost but strong sharing potential.

Outputs
-------
- examples/idc_synth_bench_v256/report.json
- tables/idc_synth_bench_v256.tex
- figs/idc_synth_cost_v256.png

Run
---
  python3 tools/idc_synth_bench_v256.py
"""

from __future__ import annotations

import json
import random
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple

import matplotlib.pyplot as plt

REPO = Path(__file__).resolve().parents[1]
OUT = REPO / "examples" / "idc_synth_bench_v256"

import sys
sys.path.append(str(Path(__file__).resolve().parent))

from idc_demo_article53_v255 import (  # type: ignore
    load_json,
    error_ids,
    index_profile_constraints,
    normalize_failing_ids,
    requirement_options,
    action_costs,
)
from idc_optimizer_v256 import optimize_auto


def _write_json(p: Path, obj: Any) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def make_profile_pair(n_reqs: int, shared_kinds: List[str], seed: int) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, str]]:
    """Return (v1, v2, req_to_shared_kind).

    v1 contains only a baseline constraint that always passes.
    v2 adds n anyOf wrapper requirements.
    """
    rng = random.Random(seed)

    v1 = {
        "id": f"ocf-p/synth-altpaths/v1/n{n_reqs}",
        "constraints": [
            {"id": "BASE_status_ok", "path": "abom.abomVersion", "present": True}
        ],
    }

    constraints_v2 = list(v1["constraints"])

    req_to_shared: Dict[str, str] = {}

    for i in range(n_reqs):
        rid = f"REQ_{i:03d}"
        shared = rng.choice(shared_kinds)
        req_to_shared[rid] = shared

        # anyOf wrapper: either provide unique doc_i OR the shared artifact kind
        constraints_v2.append({
            "id": rid,
            "anyOf": [
                [
                    {
                        "id": f"{rid}_unique",
                        "path": "abom.artifacts[].kind",
                        "anyEquals": f"doc_{i:03d}",
                    }
                ],
                [
                    {
                        "id": f"{rid}_shared",
                        "path": "abom.artifacts[].kind",
                        "anyEquals": shared,
                    }
                ],
            ],
        })

    v2 = {
        "id": f"ocf-p/synth-altpaths/v2/n{n_reqs}",
        "constraints": constraints_v2,
    }
    return v1, v2, req_to_shared


def make_abom_fixture(n_reqs: int, req_to_shared: Dict[str, str], kind_mode: str, seed: int) -> Dict[str, Any]:
    rng = random.Random(seed)

    artifacts = [
        {
            "id": "A_llm_model",
            "kind": "llm_model",
            "name": "toy",
            "digest": "sha256:" + "a" * 64,
            "meta": {"provider": "example"},
        }
    ]

    if kind_mode == "none":
        pass

    elif kind_mode == "some_unique":
        # include ~30% of unique docs
        for i in range(n_reqs):
            if rng.random() < 0.30:
                artifacts.append({
                    "id": f"A_doc_{i:03d}",
                    "kind": f"doc_{i:03d}",
                    "name": f"doc-{i}",
                    "digest": "sha256:" + ("b" * 64),
                    "meta": {},
                })

    elif kind_mode == "one_shared":
        # include exactly one shared kind (the most common)
        counts: Dict[str, int] = {}
        for k in req_to_shared.values():
            counts[k] = counts.get(k, 0) + 1
        shared = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[0][0]
        artifacts.append({
            "id": f"A_{shared}",
            "kind": shared,
            "name": shared,
            "digest": "sha256:" + ("c" * 64),
            "meta": {},
        })

    elif kind_mode == "all_shared":
        for shared in sorted(set(req_to_shared.values())):
            artifacts.append({
                "id": f"A_{shared}",
                "kind": shared,
                "name": shared,
                "digest": "sha256:" + ("d" * 64),
                "meta": {},
            })

    else:
        raise ValueError(f"unknown kind_mode {kind_mode}")

    return {
        "abomVersion": "0.1",
        "system": {"name": f"synth-{kind_mode}", "version": "v0"},
        "artifacts": artifacts,
        "obligations": [],
        "integrityCertificates": [],
    }


def run_profile_check(profile_path: Path, abom_path: Path, out_path: Path) -> Dict[str, Any]:
    import subprocess

    out_path.parent.mkdir(parents=True, exist_ok=True)
    p = subprocess.run(
        ["python3", "tools/profile_check.py", "--profile", str(profile_path), "--abom", str(abom_path), "--out", str(out_path)],
        cwd=str(REPO),
        capture_output=True,
        text=True,
    )
    # profile_check returns non-zero on failure; we still want the JSON output
    if out_path.exists():
        return json.loads(out_path.read_text(encoding="utf-8"))
    raise RuntimeError(f"profile_check produced no output. stderr={p.stderr}")


def greedy_independent(requirements: List[Dict[str, Any]], costs: Dict[str, float]) -> Tuple[float, List[Dict[str, Any]], List[str]]:
    from idc_optimizer_v256 import _action_cost_fn

    c_cost = _action_cost_fn(costs)
    chosen_actions = set()
    selection = []
    for r in requirements:
        best = None
        best_cost = float("inf")
        for opt in r.get("options", []) or []:
            acts = set(opt.get("actions", []) or [])
            c = sum(c_cost(a) for a in acts)
            if c < best_cost:
                best_cost = c
                best = opt
        if best is None:
            best = {"kind": "missing", "actions": []}
        selection.append({"req": r["id"], "opt": best})
        chosen_actions |= set(best.get("actions", []) or [])

    total = sum(c_cost(a) for a in chosen_actions)
    return float(total), selection, sorted(chosen_actions)


def write_table(rows: List[Dict[str, Any]], out_tex: Path) -> None:
    lines: List[str] = []
    lines.append("\\begin{tabular}{@{}r p{0.14\\linewidth} rrr r@{}}")
    lines.append("\\toprule")
    lines.append("$n$ & Fixture & GreedyCost & OptCost & $\\Delta$ & Opt ms \\\\")
    lines.append("\\midrule")
    for r in rows:
        n = int(r["n_reqs"])
        fx = str(r["fixture"]).replace("_", "\\_")
        gc = float(r["greedy_cost"])
        oc = float(r["opt_cost"])
        d = gc - oc
        ms = float(r["opt_ms"])
        lines.append(f"{n} & {fx} & {gc:.1f} & {oc:.1f} & {d:.1f} & {ms:.1f} \\\\")
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    out_tex.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "profiles").mkdir(exist_ok=True)
    (OUT / "aboms").mkdir(exist_ok=True)
    (OUT / "reports").mkdir(exist_ok=True)

    shared_kinds = [
        "model_card",  # cost 4.0
        "training_content_summary",  # cost 12.0
        "gpai_integration_documentation",  # cost 5.0
    ]

    sizes = [5, 10, 20, 40, 80]
    fixtures = ["none", "some_unique", "one_shared"]

    all_rows: List[Dict[str, Any]] = []
    full_report: Dict[str, Any] = {"sizes": sizes, "fixtures": fixtures, "rows": []}

    for n in sizes:
        prof1, prof2, req_to_shared = make_profile_pair(n, shared_kinds, seed=1000 + n)

        p1 = OUT / "profiles" / f"synth_v1_n{n}.json"
        p2 = OUT / "profiles" / f"synth_v2_n{n}.json"
        _write_json(p1, prof1)
        _write_json(p2, prof2)

        profile2 = prof2
        cidx2 = index_profile_constraints(profile2)

        for fx in fixtures:
            abom_obj = make_abom_fixture(n, req_to_shared, fx, seed=2000 + n)
            abom_path = OUT / "aboms" / f"abom_{fx}_n{n}.json"
            _write_json(abom_path, abom_obj)

            rep1 = OUT / "reports" / f"rep_{fx}_n{n}_v1.json"
            rep2 = OUT / "reports" / f"rep_{fx}_n{n}_v2.json"

            r1 = run_profile_check(p1, abom_path, rep1)
            r2 = run_profile_check(p2, abom_path, rep2)

            e1 = set(error_ids(r1))
            e2 = set(error_ids(r2))
            newly_failing = sorted(e2 - e1)

            trace_obj: Dict[str, Any] = {}  # not needed for pure ABOM constraints

            failing_norm = normalize_failing_ids(newly_failing, profile2)
            reqs: List[Dict[str, Any]] = []
            for rid in failing_norm:
                reqs.append({"id": rid, "options": requirement_options(rid, profile2, cidx2, abom_obj, trace_obj)})

            costs = action_costs(abom_obj)

            greedy_cost, greedy_sel, greedy_actions = greedy_independent(reqs, costs) if reqs else (0.0, [], [])
            opt = optimize_auto(reqs, costs, exact_n_max=18, restarts=32, iters=2000, seed=11) if reqs else None

            row = {
                "n_reqs": n,
                "fixture": fx,
                "new_fail": len(reqs),
                "greedy_cost": greedy_cost,
                "greedy_actions": greedy_actions,
                "opt_cost": float(opt.total_cost) if opt else 0.0,
                "opt_actions": opt.actions if opt else [],
                "opt_method": opt.method if opt else "none",
                "opt_ms": float(opt.wall_ms) if opt else 0.0,
            }
            all_rows.append(row)
            full_report["rows"].append(row)

    # Write report
    _write_json(OUT / "report.json", full_report)

    # LaTeX table
    write_table(all_rows, REPO / "tables" / "idc_synth_bench_v256.tex")

    # Plot: costs vs n for each fixture
    for fx in fixtures:
        xs = [r["n_reqs"] for r in all_rows if r["fixture"] == fx]
        gc = [r["greedy_cost"] for r in all_rows if r["fixture"] == fx]
        oc = [r["opt_cost"] for r in all_rows if r["fixture"] == fx]

        plt.figure()
        plt.plot(xs, gc, marker="o", label="Greedy (per-req)")
        plt.plot(xs, oc, marker="o", label="Optimized (share-aware)")
        plt.xlabel("New anyOf requirements (n)")
        plt.ylabel("Total repair plan cost")
        plt.title(f"Synthetic IDC repair planning (fixture={fx})")
        plt.legend()
        out_png = REPO / "figs" / f"idc_synth_cost_{fx}_v256.png"
        out_png.parent.mkdir(exist_ok=True)
        plt.savefig(out_png, dpi=200, bbox_inches="tight")
        plt.close()

    print("wrote", OUT)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
