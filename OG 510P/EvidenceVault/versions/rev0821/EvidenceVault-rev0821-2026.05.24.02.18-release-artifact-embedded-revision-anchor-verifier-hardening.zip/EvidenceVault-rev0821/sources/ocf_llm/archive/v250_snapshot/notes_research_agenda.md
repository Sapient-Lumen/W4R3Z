# Research agenda and paper-candidate notes (v250)

This file is intentionally forward-looking: it captures *risky* paper directions, experiment ideas, and open problems we can turn into publishable results.

## Paper suite (current)

1. **OCF-LLM (paper.tex)** — Obligation-Carrying Assurance for LLM Systems (full paper).
2. **IDC (paper_idc.tex)** — Interface Drift Certificates (treating checklists as versioned APIs).
3. **AD (paper_discovery.tex)** — Accountable Discoverability (verifiable evidence lookup).

## High-leverage novelty bets

### A. Discoverability as a security property (ADCP -> deployable spec)
- **Bet:** Most transparency systems treat lookup/search as “best effort”; turning it into a **conformance surface** (ADCP + vectors) is a missing piece that makes *receipt portability* real.
- **Hard questions:**
  - Minimum semantics for **portable absence** across common backends (SMT vs prefix trees vs map overlays).
  - Concrete, testable liveness commitments (SDT/MID) that survive mirrors/caches.
  - How to express and detect *index drift* vs *equivocation* vs *availability* with bounded monitors.

### B. Assurance admission control (SRE loop) as governance primitive
- **Bet:** Release governance for AI systems will converge on SRE-style loops, but lacks a rigorous *impact model* and *budget semantics*.
- **Experiments to run:**
  - Simulate “assurance SLO” policies with ABOM diffs from real OSS ML pipelines (or synthetic workloads).
  - Quantify throughput/latency tradeoffs for batch windows under different audit-locality assumptions.

### C. Evidence minimality + privacy-preserving replay
- **Bet:** Regulators and auditors will demand replayable evidence, but organizations will only adopt if *selective disclosure* is native.
- **Open problems:**
  - Composable mABOM projections that are stable under redaction.
  - Challengeable sketches (KMV/HLL variants) that are cheap to verify and resist gaming.

### D. Economics of witness networks for AI assurance
- **Bet:** Witnessing is the “coordination cost” bottleneck. We need a realistic model.
- **Possible angle:** treat witness capacity as a scarce resource; derive rate limits and incentives that align with assurance-change budgets.

## Concrete next steps (for the next turns)

1. **ADCP: make the profile more explicit**
   - Nail the *canonical key derivation* and the proof-bound semantics (size caps + depth + hash).
   - Add a “conformance levels” ladder (L0: offline receipts, L1: MID, L2: split-view monitors).

2. **Runnable experiments**
   - Add a *toy service harness* that serves fixtures and demonstrates a conformance failure (e.g., late indexing, proof bloat, equivocation).
   - Produce one figure: verifier cost vs proof bounds vs monitor sampling budget.

3. **Related-work tightening**
   - Map ADCP requirements to: CT, Sigstore/Rekor, KeyTrans, CONIKS, Key Transparency deployments.
   - For each: identify what is *provable offline* vs what depends on live APIs/mirrors.

4. **Main-paper positioning**
   - Clarify “why OCF-LLM is not just SBOM+attestations”: the differentiator is **fail-closed resolution** + **budgeted composition** + **drift-safe interfaces**.
   - Add a short “research agenda” section that makes explicit what is proved, what is measured, and what remains conjectural.

## What we should *not* do (yet)

- Claim real-world conformance results for public services without running the harness against them.
- Add new cryptography primitives unless they are essential; lean on existing CT/KeyTrans/SCITT building blocks.
