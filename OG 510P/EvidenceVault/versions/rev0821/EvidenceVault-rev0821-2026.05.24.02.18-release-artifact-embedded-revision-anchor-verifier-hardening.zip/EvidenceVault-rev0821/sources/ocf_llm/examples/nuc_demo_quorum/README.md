# NUC quorum demo (v198)

This directory demonstrates **quorum NUCs**: requiring *k-of-n* independently-issued
Non-Equivocation Certificates (NUCs) to satisfy uniqueness checks **offline**.

## What it shows

- **Pass case:** 2-of-3 monitors issue valid NUCs over a single-entry receipt cache.
  A third monitor observes an **equivocation** cache (matches = 2), so its NUC is
  *invalid*, but the quorum still holds.
- **Fail case:** only 1 monitor is valid, so a 2-of-3 policy fails closed.

## Files

- `keys/`: three Ed25519 demo keypairs for monitors.
- `nuc_monitor{1,2}_ok.json`: NUCs over `examples/nuc_demo/receipt_cache_ok_index.json`.
- `nuc_monitor3_equivocation.json`: NUC over `examples/mer_demo/receipt_cache/` (matches=2).
- `quorum_manifest_ok.json`, `quorum_manifest_fail.json`: quorum manifests.
- `nuc_quorum_verify_ok_summary.json`, `nuc_quorum_verify_fail_summary.json`: outputs of `tools/nuc_quorum_verify.py`.

## Reproduce

```bash
# Issue two good NUCs and one equivocation NUC
python3 tools/nuc_issue.py --index examples/nuc_demo/receipt_cache_ok_index.json \
  --abom-digest sha256:... --predicate-type https://ocf.ai/mer/v1 \
  --run-id run-... --obligation-id obl:... \
  --ed25519-private-key examples/nuc_demo_quorum/keys/monitor1_sk.pem \
  --out examples/nuc_demo_quorum/nuc_monitor1_ok.json

python3 tools/nuc_issue.py --receipt-cache-dir examples/mer_demo/receipt_cache \
  --abom-digest sha256:... --predicate-type https://ocf.ai/mer/v1 \
  --run-id run-... --obligation-id obl:... \
  --ed25519-private-key examples/nuc_demo_quorum/keys/monitor3_sk.pem \
  --out examples/nuc_demo_quorum/nuc_monitor3_equivocation.json

# Verify a quorum
python3 tools/nuc_quorum_verify.py --manifest examples/nuc_demo_quorum/quorum_manifest_ok.json
```
