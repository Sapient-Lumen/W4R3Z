#!/usr/bin/env python3
"""blast_radius_attribution_v262.py

v262: Attribute audit locality / assurance-debt tail risk to *artifacts*.

Given a fleet ABOM where each system obligation depends on a small set of
artifacts (prompts, retriever shards, policies, global artifacts), we compute
for each artifact a deterministic "blast radius": the fraction of scoped
obligations impacted if that artifact changes.

We then summarize:
  - Category statistics (prompt/retriever/policy/global)
  - Concentration / Pareto: what fraction of total blast-radius mass is carried
    by the top-K artifacts

Generates:
  - figs/blast_radius_pareto_v262.pdf
  - tables/blast_radius_attribution_summary_v262.tex

Usage:
  python3 tools/blast_radius_attribution_v262.py \
    --abom examples/fleet_abom_v165_policy_shared.json \
    --scope-prefix O_sys_

Notes:
  - This is intentionally *structural* attribution: it ignores semantic
    equivalence (e.g., ABI-preserving rewrites) and assumes fail-closed
    conservative invalidation.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import matplotlib.pyplot as plt


def load_json(p: Path) -> Dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def artifact_kind(aid: str) -> str:
    # Heuristic categories for the fleet ABOM naming scheme.
    if aid.startswith("A_prompt_"):
        return "prompt"
    if aid.startswith("A_retr_"):
        return "retr"
    if aid.startswith("A_policy_"):
        return "policy"
    if aid in ("A_fm", "A_profile", "A_monitor"):
        return "global"
    if aid.startswith("A_fm") or aid.startswith("A_profile") or aid.startswith("A_monitor"):
        return "global"
    return "other"


def quantiles(xs: List[float], qs: List[float]) -> List[float]:
    if not xs:
        return [0.0 for _ in qs]
    arr = np.array(xs, dtype=float)
    return [float(np.quantile(arr, q)) for q in qs]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--abom", required=True, help="Path to ABOM JSON")
    ap.add_argument("--scope-prefix", default="O_sys_", help="Restrict to obligations starting with this prefix")
    ap.add_argument("--top-k", type=int, default=10, help="Top-K artifacts to list in the table")
    ap.add_argument("--out-fig", default="figs/blast_radius_pareto_v262.pdf")
    ap.add_argument("--out-tex", default="tables/blast_radius_attribution_summary_v262.tex")
    args = ap.parse_args()

    abom = load_json(Path(args.abom))
    obligations = [o for o in (abom.get("obligations") or []) if isinstance(o, dict) and str(o.get("id", "")).startswith(args.scope_prefix)]
    total = len(obligations)
    if total == 0:
        raise SystemExit(f"No obligations matched scope prefix {args.scope_prefix!r}")

    # Reverse dependency map: artifact_id -> list of obligation ids impacted.
    rev: Dict[str, List[str]] = {}
    for o in obligations:
        oid = str(o.get("id"))
        for req in (o.get("requires") or []):
            rid = str(req)
            rev.setdefault(rid, []).append(oid)

    artifacts = [a for a in (abom.get("artifacts") or []) if isinstance(a, dict) and a.get("id")]

    rows: List[Tuple[str, str, float, int]] = []  # (artifact_id, kind, frac, count)
    for a in artifacts:
        aid = str(a["id"])
        impacted = rev.get(aid, [])
        cnt = len(impacted)
        frac = cnt / total
        rows.append((aid, artifact_kind(aid), float(frac), int(cnt)))

    # Pareto concentration curve over "blast-radius mass" = sum(frac).
    fracs = np.array([r[2] for r in rows], dtype=float)
    order = np.argsort(-fracs)  # descending
    fracs_sorted = fracs[order]
    total_mass = float(fracs_sorted.sum()) if float(fracs_sorted.sum()) > 0 else 1.0
    cum_mass = np.cumsum(fracs_sorted) / total_mass
    x = (np.arange(len(fracs_sorted)) + 1) / max(1, len(fracs_sorted))

    # Category stats.
    by_kind: Dict[str, List[float]] = {}
    for _, k, f, _ in rows:
        by_kind.setdefault(k, []).append(f)

    # Top-k artifacts by frac.
    top = [rows[i] for i in order[: args.top_k]]

    # Plot: Pareto curve.
    out_fig = Path(args.out_fig)
    out_fig.parent.mkdir(parents=True, exist_ok=True)

    plt.figure(figsize=(6.5, 4.0))
    plt.plot(x, cum_mass, marker="o", markersize=3, linewidth=1.6)
    plt.xlabel("Top fraction of artifacts (sorted by blast radius)")
    plt.ylabel("Cumulative share of blast-radius mass")
    plt.title("Blast-radius concentration (v262)")
    plt.ylim(0.0, 1.02)
    plt.xlim(0.0, 1.0)
    plt.grid(True, alpha=0.25)

    # Annotate a few points.
    for frac_art in (0.01, 0.05, 0.10, 0.20):
        idx = max(1, int(round(frac_art * len(fracs_sorted)))) - 1
        y = float(cum_mass[idx])
        plt.annotate(f"{int(frac_art*100)}% → {int(round(y*100))}%", (x[idx], y), textcoords="offset points", xytext=(6, -10), fontsize=8)

    plt.tight_layout()
    plt.savefig(out_fig, format="pdf")
    plt.close()

    # Write LaTeX table.
    out_tex = Path(args.out_tex)
    out_tex.parent.mkdir(parents=True, exist_ok=True)

    def fmt(p: float) -> str:
        return f"{p*100:.2f}\\%"

    def latex_escape(s: str) -> str:
        # Minimal LaTeX escaping for table cells.
        return (s.replace("\\", r"\textbackslash{}")
                 .replace("&", r"\&")
                 .replace("%", r"\%")
                 .replace("_", r"\_")
                 .replace("#", r"\#")
                 .replace("{", r"\{")
                 .replace("}", r"\}")
                 .replace("~", r"\textasciitilde{}")
                 .replace("^", r"\textasciicircum{}"))

    # Compute concentration stats.
    def mass_share(k: int) -> float:
        if k <= 0:
            return 0.0
        return float(fracs_sorted[:k].sum()) / total_mass

    k1 = 1
    k5 = min(5, len(fracs_sorted))
    k10 = min(10, len(fracs_sorted))
    k1pct = max(1, int(round(0.01 * len(fracs_sorted))))

    lines: List[str] = []
    lines.append("% Auto-generated by tools/blast_radius_attribution_v262.py")
    lines.append("\\begin{tabular}{lrrrr}")
    lines.append("\\toprule")
    lines.append("Category & Count & Median debt & P95 debt & Max debt \\\\")
    lines.append("\\midrule")

    for k in ["prompt", "retr", "policy", "global", "other"]:
        xs = by_kind.get(k, [])
        if not xs:
            continue
        q50, q95, q100 = quantiles(xs, [0.5, 0.95, 1.0])
        lines.append(f"{latex_escape(k)} & {len(xs)} & {fmt(q50)} & {fmt(q95)} & {fmt(q100)} \\\\")

    lines.append("\\midrule")
    lines.append(f"Top 1 artifact share & \\multicolumn{{4}}{{r}}{{{fmt(mass_share(k1))}}} \\\\")
    lines.append(f"Top 5 artifacts share & \\multicolumn{{4}}{{r}}{{{fmt(mass_share(k5))}}} \\\\")
    lines.append(f"Top 10 artifacts share & \\multicolumn{{4}}{{r}}{{{fmt(mass_share(k10))}}} \\\\")
    lines.append(f"Top 1\\% artifacts share & \\multicolumn{{4}}{{r}}{{{fmt(mass_share(k1pct))}}} \\\\")

    lines.append("\\midrule")
    lines.append("\\multicolumn{5}{l}{\\textit{Top artifacts by deterministic blast radius}}\\\\")
    lines.append("Artifact & Kind & Debt & Impacted claims & Share of mass \\\\")
    lines.append("\\midrule")

    for aid, knd, frac, cnt in top:
        share = frac / (total_mass / len(fracs_sorted)) if total_mass > 0 else 0.0
        # share here is relative to average; keep as multiplier.
        lines.append(f"{latex_escape(aid)} & {latex_escape(knd)} & {fmt(frac)} & {cnt} & {share:.1f}\\ensuremath{{\\times}} \\\\")

    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")

    out_tex.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(json.dumps({
        "abom": args.abom,
        "scope": args.scope_prefix,
        "total_claims": total,
        "artifacts": len(rows),
        "out_fig": str(out_fig),
        "out_tex": str(out_tex),
    }, indent=2))


if __name__ == "__main__":
    main()
