# OCF-LLM paper working directory

Current draft: **v263** (February 28, 2026)

Files:
- `paper.tex` — current LaTeX draft (biblatex/biber)
- `paper_extended_abstract.tex` — 2–4 page extended abstract/workshop version (optional)
- `paper_eic.tex` — focused companion paper on Evaluation Integrity Certificates (EIC/JRC/JBC)
- `paper_fser.tex` — focused companion paper on Full-Stack Evaluation Receipts for agentic systems
- `paper_pcb.tex` — companion paper on Proof-Carrying Benchmarks (bundled, fail-closed claim display)
- `paper_assurance_debt.tex` — companion paper on Assurance Debt + Assurance SLOs (continuous recertification/control loops)
- `paper_assurance_admission_control.tex` — companion paper on Assurance Admission Control (budgeted release gating for continuous certification)
- `paper_audit_locality.tex` — companion paper on Audit Locality (impact queries + localized recertification)
- `references.bib` — bibliography
- `notes.md` — running research and writing notes
- `abom_schema_draft.json` — draft ABOM schema
- `examples/` — toy ABOM + resolver trace examples
- `tools/ocf_resolver.py` — tiny reference resolver kernel (prototype)
- `tools/abom_diff.py` — prototype ABOM diff + impacted-slice calculator (audit locality)

Build (this environment):
- `pdflatex paper.tex`
- `biber paper`
- `pdflatex paper.tex` (twice)

Prototypes:
- Resolve a toy ABOM and emit a YAML-ish replay trace:
  - `python3 tools/ocf_resolver.py examples/ceb_toy_abom.json --out examples/resolver_trace_ceb_toy.yaml`
  - `python3 tools/ocf_resolver.py examples/rejection_sampling_abom.json --out examples/resolver_trace_rejection_sampling.yaml`
- Compute a diff and an impacted obligation slice:
  - `python3 tools/abom_diff.py --base examples/ceb_toy_abom.json --new examples/ceb_toy_abom.json --pretty`
- (Optional) Attach audit-locality info
- Generate toy transparency artifacts (RFC 9162 Merkle proofs) and re-run the resolver:
  - `python3 tools/toy_scitt_receipt_gen.py --abom examples/sabom_mcp_episode_abom_scitt_published.json --out examples/scitt_receipt_sabom_mcp_episode_v2.json --statement-id sabom/mcp-episode/v1 --tree-size 13 --leaf-index 9 --prev-size 8`
  - `python3 tools/ocf_resolver.py examples/sabom_mcp_episode_abom_scitt_published_v2.json --out examples/_trace_sabom_scitt_v2.yaml`
 to the resolver trace:
  - `python3 tools/ocf_resolver.py examples/ceb_toy_abom.json --prev-abom examples/ceb_toy_abom.json --out /tmp/trace.yaml`

Tip: `examples/resolver_trace_*.yaml` are replay artifacts emitted by the resolver; they are designed to be cached in CI/audit pipelines.

New in v263:
- Added churn-sensitive assurance-debt + artifact-aware admission-control benchmark: `tools/assurance_adc_artifact_churn_v263.py` (outputs `figs/assurance_adc_churn_value_v263.pdf`, `figs/assurance_adc_churn_p95_v263.pdf`, `tables/assurance_adc_churn_summary_v263.tex`).
- Integrated churn debt and artifact-aware shadow prices into `paper_assurance_admission_control.tex`; added a brief churn-debt note to `paper_assurance_debt.tex`.

New in v262:
- Added blast-radius attribution Pareto + table: `tools/blast_radius_attribution_v262.py` (outputs `figs/blast_radius_pareto_v262.pdf`, `tables/blast_radius_attribution_summary_v262.tex`).
- Added an exact within-day oracle ADC baseline + gap plot: `tools/assurance_adc_oracle_bench_v262.py` (outputs `figs/assurance_adc_oracle_gap_v262.pdf`, `tables/assurance_adc_oracle_summary_v262.tex`).
- Integrated the new artifacts into the Audit Locality and Assurance Debt companion papers; fixed a LaTeX table/proposition nesting issue in `paper_assurance_debt.tex`.

New in v261:
- Added a new audit-locality companion paper: `paper_audit_locality.tex`.
- Added a shadow-price ADC policy + budget sweep harness: `tools/assurance_adc_budget_sweep_v261.py` (outputs `figs/assurance_adc_budget_sweep_v261.pdf` and `tables/assurance_adc_budget_sweep_summary_v261.tex`).

New in v260:
- Added a change-log replay harness: `tools/assurance_debt_replay_v260.py` (outputs `figs/assurance_debt_replay_v260.pdf`, `tables/assurance_debt_replay_summary_v260.tex`, and `examples/assurance_debt_replay_v260.json`).
- Added a value-aware admission-control benchmark: `tools/assurance_adc_frontier_v260.py` (outputs `figs/assurance_adc_frontier_v260.pdf` and `tables/assurance_adc_summary_v260.tex`).
- New companion paper draft: `paper_assurance_admission_control.tex`.

New in v259:
- Added an assurance-debt capacity-planning simulation: `tools/assurance_debt_capacity_v259.py` (outputs `figs/assurance_debt_capacity_v259.pdf` and `tables/assurance_debt_capacity_summary_v259.tex`).
- Added a small debt-metric helper to compute impacted claim fraction from an ABOM + change set: `tools/assurance_debt_metric_v259.py`.

New in v237:
- Policy-driven PCB gate: `tools/pcb_registry_gate_v237.py` enforces a published registry policy (`schemas/pcb_policy_v1.schema.json`) rather than trusting the submitter's `requires` list.
- PCB transparency stapling: bundles may include `logReceipts` (SCITT-style receipts) and policies can require them; verifier: `tools/scitt_receipt_verify_v237.py`.
- Demo: `examples/pcb_policy_demo_v237/`.

New in v209:
- `tools/release_train_certificate_v209.py` composes multiple v207 Change-Control Certificates (CCCs) into a single Release-Train Certificate (RTC) with chain-consistency + window drift budgets.
- `examples/release_train_demo_v209/` is a runnable three-step demo that fails closed when the cumulative policy drift debt exceeds the declared window budget.

New in v19:
- `examples/lean_passk_abom.json` demonstrates **pass@k** + **transcript binding** via an attempt-log commitment.
- The resolver optionally verifies local evidence digests for log-like evidence referenced by the system obligation (fails-closed on mismatch).


New in v20:
- `Selection Integrity Certificates (SIC)` bind a selection predicate + chosen index to a committed attempt log.
- Attempt logs may use `commitmentAlg: merkle-v1` with evidence digests set to the Merkle root; the resolver recomputes and checks this, and validates SICs fail-closed.

New in v40:
- Added OCF-P profile support: `profiles/` contains example profiles; `tools/profile_check.py` checks a profile against an ABOM + resolver trace and can emit a profile projection (`--emit-projection`).
- Example:
  - `python3 tools/profile_check.py --profile profiles/eu_ai_act_annexiv_v0.json --abom examples/eic_qic_latency_abom.json --trace examples/resolver_trace_eic_qic_latency.yaml --emit-projection`


New in v42:
- Added **Equivalence Certificates (EQC)** and an optional **Ledger Normal Form (LNF)** dedup pass for ledger aggregation.
- Example (shows naive union bound vs EQC-deduped bound):
  - `python3 tools/ocf_resolver.py examples/lnf_eqc_dedup_abom.json --out examples/resolver_trace_lnf_eqc_dedup.yaml`


New in v52:
- Added a deterministic **toy transparency-log generator** for CT-style TLOG receipts: `tools/toy_ct_log_gen.py`.
- Added a published sABOM example wired through a **publication obligation**:
  - `examples/sabom_mcp_episode_abom_published.json`
  - `examples/tlog_pub_proof_sabom_mcp_episode_v1.json`
  - `examples/resolver_trace_sabom_mcp_episode_published.yaml`


New in v54:
- Added **Refusal Event Certificates (REC)** as a fail-closed alternative to publication receipts.
- Added generators for generic SCITT-style receipts over arbitrary subjects and for operator-signed refusal-event bundles.
- Example: `examples/sabom_mcp_episode_abom_scitt_refusal.json` + `examples/refusal_bundle_sabom_mcp_episode_v1.json`.



New in v57:
- Added **ABI Refinement Certificates (ABIRC)** for transcript-stable log rewrites (format migrations / privacy projections) and a small helper `tools/abi_hash.py` to compute ABI digests.
- Example: `examples/sabom_mcp_episode_abom_projection.json` now includes `ABIRC_mcp_tools_abi_v1`, and `examples/_trace_abirc.yaml` shows the resolver validating it.


New in v70:
- Compose / refine profiles and emit PRCs:
  - `python3 tools/profile_algebra.py meet --p profiles/eu_ai_act_annexiv_v0.json --q profiles/<other>.json --out /tmp/meet_profile.json`
  - `python3 tools/profile_algebra.py refines --p profiles/eu_ai_act_annexiv_v0.json --q profiles/<other>.json --emit-prc /tmp/prc_out`
- Verify an APT bundle (DSSE + optional toy SCITT receipt):
  - `python3 tools/apt_verify.py --dir examples/apt_eu_ai_act_toy_signed_out --pubkey examples/apt_eu_ai_act_toy_signed_out/issuer_ed25519_public.pem --verify-receipt`


New in v72:
- Added a runnable **Witnessed Checkpoint Obligation (WCO)** demo: quorum witness-cosigning of SCITT-style checkpoints as portable anti-equivocation evidence.
- Generate a witness bundle:
  - `python3 tools/wco_witness_bundle_gen.py --service-id toy-scitt --tree-size 13 --root-digest-hex <hex> --issued-at 2026-02-09T00:00:00Z --threshold 2 --witness-keys 3 --out /tmp/wco_bundle.json`
- Verify WCO end-to-end via the resolver:
  - `python3 tools/ocf_resolver.py examples/wco_demo_v1/abom_wco_ok.json --out examples/wco_demo_v1/trace_ok.yaml`
  - `python3 tools/ocf_resolver.py examples/wco_demo_v1/abom_wco_fail_split.json --out examples/wco_demo_v1/trace_fail.yaml` (expected fail-closed)

New in v86:
- Minimal governance-receipt + CPC + PBC example with fail-closed variants:
  - OK: `examples/cpc_profile_receipt_pbc_abom.json`
  - Stale publication: `examples/cpc_profile_receipt_pbc_abom_stale_policy.json`
  - Policy substitution: `examples/cpc_profile_receipt_pbc_abom_policy_mismatch.json`


New in v160:
- Added a **fleet audit-locality benchmark** (`tools/audit_locality_realistic_bench_v160.py`) that generates `examples/fleet_abom_v160_*.json`, `figs/audit_locality_realistic_v160.pdf`, and `tables/audit_locality_realistic_summary_v160.tex`.
- Extended `tools/ocf_resolver.py` with prototype incremental flags `--prev-abom` and `--only-impacted` to benchmark slice checking.