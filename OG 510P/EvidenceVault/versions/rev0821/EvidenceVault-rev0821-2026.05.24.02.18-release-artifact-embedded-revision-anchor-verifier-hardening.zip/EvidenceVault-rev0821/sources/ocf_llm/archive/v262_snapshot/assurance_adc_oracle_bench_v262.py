#!/usr/bin/env python3
"""assurance_adc_oracle_bench_v262.py

v262: Add an "exact within-day" oracle baseline to the toy Assurance Admission Control (ADC) benchmark.

We keep the v261 rolling-window budget mechanics but add a policy that, each day:
  - considers a bounded candidate set from the backlog (top-M by discounted value), and
  - exhaustively searches all subsets to maximize discounted value subject to residual budget,
    where cost is union(impacted) / N.

This gives a credible ``best possible with today's information'' comparator. It is not a
clairvoyant multi-day optimum, but it is exact for the within-day submodular knapsack instance
we construct.

Generates:
  - figs/assurance_adc_oracle_gap_v262.pdf  (policy value vs oracle)
  - tables/assurance_adc_oracle_summary_v262.tex

Usage:
  python3 tools/assurance_adc_oracle_bench_v262.py

The script is deterministic given seeds.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from typing import Dict, List, Set, Tuple

import numpy as np
import matplotlib.pyplot as plt


@dataclass
class Change:
    day: int
    kind: str
    impacted: Set[int]
    impacted_bits: int
    value: float


def make_fleet(N: int, shards: int, policies: int, seed: int) -> Dict[str, List[Set[int]]]:
    rng = np.random.default_rng(seed)
    idx = np.arange(N)
    rng.shuffle(idx)

    shard_sets: List[Set[int]] = []
    for s in range(shards):
        shard_sets.append(set(idx[s::shards].tolist()))

    rng.shuffle(idx)
    policy_sets: List[Set[int]] = []
    for p in range(policies):
        policy_sets.append(set(idx[p::policies].tolist()))

    return {"shards": shard_sets, "policies": policy_sets}


def to_bits(imp: Set[int]) -> int:
    b = 0
    for i in imp:
        b |= 1 << int(i)
    return b


def draw_value(rng: np.random.Generator, kind: str) -> float:
    params = {
        "prompt": (-0.2, 0.7),
        "retr": (0.2, 0.6),
        "policy": (0.4, 0.6),
        "global": (0.8, 0.7),
    }
    mu, sigma = params.get(kind, (0.0, 0.7))
    return float(np.exp(rng.normal(mu, sigma)))


def sample_change(rng: np.random.Generator, N: int, fleet: Dict[str, List[Set[int]]], mix: Dict[str, float], day: int) -> Change:
    kinds = list(mix.keys())
    probs = np.array([mix[k] for k in kinds], dtype=float)
    probs /= probs.sum()
    kind = str(rng.choice(kinds, p=probs))

    if kind == "prompt":
        impacted = {int(rng.integers(0, N))}
    elif kind == "retr":
        impacted = set(rng.choice(list(fleet["shards"])))
    elif kind == "policy":
        impacted = set(rng.choice(list(fleet["policies"])))
    elif kind == "global":
        impacted = set(range(N))
    else:
        impacted = {int(rng.integers(0, N))}

    return Change(day=day, kind=kind, impacted=impacted, impacted_bits=to_bits(impacted), value=draw_value(rng, kind))


def discount(v: float, delay: int, tau: float) -> float:
    return float(v * np.exp(-delay / max(1e-9, tau)))


def _window_sum(daily_cost: np.ndarray, d: int, W: int) -> float:
    lo = max(0, d - (W - 1))
    return float(daily_cost[lo:d].sum())


def union_cost_bits(bits: int, N: int) -> float:
    return float(bits.bit_count() / N)


def policy_fifo_gate(arrivals: List[List[Change]], N: int, B: float, W: int, tau: float) -> Tuple[float, float, float, int]:
    days = len(arrivals)
    daily_cost = np.zeros(days)
    q: List[Change] = []
    value = 0.0
    lags: List[int] = []

    for d in range(days):
        q.extend(arrivals[d])

        used_bits = 0
        shipped: List[Change] = []
        residual = max(0.0, B - _window_sum(daily_cost, d, W))

        while q:
            c = q[0]
            new_bits = used_bits | c.impacted_bits
            if union_cost_bits(new_bits, N) <= residual + 1e-12:
                q.pop(0)
                shipped.append(c)
                used_bits = new_bits
            else:
                break

        daily_cost[d] = union_cost_bits(used_bits, N)
        for c in shipped:
            delay = d - c.day
            lags.append(delay)
            value += discount(c.value, delay, tau)

    lag_p95 = float(np.quantile(np.array(lags, dtype=float), 0.95)) if lags else 0.0
    lag_mean = float(np.mean(lags)) if lags else 0.0
    return float(value), lag_mean, lag_p95, len(q)


def policy_shadow_price(arrivals: List[List[Change]], N: int, B: float, W: int, tau: float, p0: float = 2.0) -> Tuple[float, float, float, int]:
    days = len(arrivals)
    daily_cost = np.zeros(days)
    backlog: List[Change] = []
    value = 0.0
    lags: List[int] = []

    price = p0
    for d in range(days):
        backlog.extend(arrivals[d])
        residual = max(0.0, B - _window_sum(daily_cost, d, W))

        used_bits = 0
        shipped: List[Change] = []

        # Greedy by net gain under current price.
        while backlog:
            best_i = None
            best_gain = -1e18
            best_new_bits = None
            for i, c in enumerate(backlog):
                new_bits = used_bits | c.impacted_bits
                if union_cost_bits(new_bits, N) > residual + 1e-12:
                    continue
                dv = discount(c.value, d - c.day, tau)
                marg = max(1e-12, union_cost_bits(new_bits, N) - union_cost_bits(used_bits, N))
                gain = dv - price * marg
                if gain > best_gain:
                    best_gain = gain
                    best_i = i
                    best_new_bits = new_bits
            if best_i is None or best_gain <= 0:
                break

            c = backlog.pop(best_i)
            shipped.append(c)
            used_bits = best_new_bits if best_new_bits is not None else used_bits

        daily_cost[d] = union_cost_bits(used_bits, N)
        for c in shipped:
            delay = d - c.day
            lags.append(delay)
            value += discount(c.value, delay, tau)

        # Price update: multiplicative based on burn utilization.
        burn = _window_sum(daily_cost, d + 1, W)  # include today
        util = burn / max(1e-12, B)
        # If we're close to budget, raise price; if far, lower.
        if util > 0.9:
            price *= 1.08
        elif util < 0.6:
            price *= 0.95
        price = float(np.clip(price, 0.1, 50.0))

    lag_p95 = float(np.quantile(np.array(lags, dtype=float), 0.95)) if lags else 0.0
    lag_mean = float(np.mean(lags)) if lags else 0.0
    return float(value), lag_mean, lag_p95, len(backlog)


def policy_value_greedy(arrivals: List[List[Change]], N: int, B: float, W: int, tau: float) -> Tuple[float, float, float, int]:
    days = len(arrivals)
    daily_cost = np.zeros(days)
    backlog: List[Change] = []
    value = 0.0
    lags: List[int] = []

    for d in range(days):
        backlog.extend(arrivals[d])
        residual = max(0.0, B - _window_sum(daily_cost, d, W))

        used_bits = 0
        shipped: List[Change] = []

        while backlog:
            best_i = None
            best_score = -1.0
            best_new_bits = None
            used_cost = union_cost_bits(used_bits, N)
            for i, c in enumerate(backlog):
                new_bits = used_bits | c.impacted_bits
                new_cost = union_cost_bits(new_bits, N)
                if new_cost > residual + 1e-12:
                    continue
                marg = max(1e-12, new_cost - used_cost)
                dv = discount(c.value, d - c.day, tau)
                score = dv / marg
                if score > best_score:
                    best_score = score
                    best_i = i
                    best_new_bits = new_bits

            if best_i is None:
                break

            c = backlog.pop(best_i)
            shipped.append(c)
            used_bits = best_new_bits if best_new_bits is not None else used_bits

        daily_cost[d] = union_cost_bits(used_bits, N)
        for c in shipped:
            delay = d - c.day
            lags.append(delay)
            value += discount(c.value, delay, tau)

    lag_p95 = float(np.quantile(np.array(lags, dtype=float), 0.95)) if lags else 0.0
    lag_mean = float(np.mean(lags)) if lags else 0.0
    return float(value), lag_mean, lag_p95, len(backlog)


def policy_exact_within_day(arrivals: List[List[Change]], N: int, B: float, W: int, tau: float, M: int = 12) -> Tuple[float, float, float, int]:
    """Exact solver for the within-day subset selection problem on top-M candidates.

    Each day we:
      1) select top-M backlog items by discounted value, then
      2) exhaustively search all subsets using DP over bitmasks (O(2^M))
         where cost is union(impacted)/N.

    This is an exact baseline for the *within-day* decision problem; it is not
    a clairvoyant multi-day optimum.
    """

    days = len(arrivals)
    daily_cost = np.zeros(days)
    backlog: List[Change] = []
    value = 0.0
    lags: List[int] = []

    for d in range(days):
        backlog.extend(arrivals[d])
        residual = max(0.0, B - _window_sum(daily_cost, d, W))

        if not backlog or residual <= 1e-12:
            daily_cost[d] = 0.0
            continue

        scored = [(i, discount(c.value, d - c.day, tau)) for i, c in enumerate(backlog)]
        scored.sort(key=lambda t: -t[1])
        cand_idx = [i for i, _ in scored[: min(M, len(scored))]]
        cands = [backlog[i] for i in cand_idx]

        bits = [c.impacted_bits for c in cands]
        vals = [discount(c.value, d - c.day, tau) for c in cands]
        m = len(cands)

        # DP over masks: build union bits + value in O(2^m).
        U = [0] * (1 << m)
        V = [0.0] * (1 << m)
        for mask in range(1, 1 << m):
            lsb = mask & -mask
            j = (lsb.bit_length() - 1)
            prev = mask ^ lsb
            U[mask] = U[prev] | bits[j]
            V[mask] = V[prev] + vals[j]

        best_mask = 0
        best_val = 0.0
        for mask in range(1, 1 << m):
            if union_cost_bits(U[mask], N) <= residual + 1e-12:
                if V[mask] > best_val:
                    best_val = V[mask]
                    best_mask = mask

        shipped_idx: List[int] = []
        used_bits = 0
        if best_mask:
            used_bits = U[best_mask]
            for j in range(m):
                if (best_mask >> j) & 1:
                    shipped_idx.append(cand_idx[j])

        shipped_changes: List[Change] = []
        if shipped_idx:
            shipped_set = set(shipped_idx)
            new_backlog: List[Change] = []
            for i, c in enumerate(backlog):
                if i in shipped_set:
                    shipped_changes.append(c)
                else:
                    new_backlog.append(c)
            backlog = new_backlog

        daily_cost[d] = union_cost_bits(used_bits, N)
        for c in shipped_changes:
            delay = d - c.day
            lags.append(delay)
            value += discount(c.value, delay, tau)

    lag_p95 = float(np.quantile(np.array(lags, dtype=float), 0.95)) if lags else 0.0
    lag_mean = float(np.mean(lags)) if lags else 0.0
    return float(value), lag_mean, lag_p95, len(backlog)


def simulate(seed: int, N: int, days: int, lam: float, shards: int, policies: int, mix: Dict[str, float]) -> List[List[Change]]:
    rng = np.random.default_rng(seed)
    fleet = make_fleet(N, shards, policies, seed=seed)
    arrivals: List[List[Change]] = [[] for _ in range(days)]
    for d in range(days):
        k = int(rng.poisson(lam))
        for _ in range(k):
            arrivals[d].append(sample_change(rng, N, fleet, mix, d))
    return arrivals


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--N", type=int, default=1200)
    ap.add_argument("--days", type=int, default=90)
    ap.add_argument("--lam", type=float, default=6.0, help="mean arrivals/day")
    ap.add_argument("--W", type=int, default=30, help="rolling window")
    ap.add_argument("--tau", type=float, default=10.0, help="discount time constant")
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--out-fig", default="figs/assurance_adc_oracle_gap_v262.pdf")
    ap.add_argument("--out-tex", default="tables/assurance_adc_oracle_summary_v262.tex")
    args = ap.parse_args()

    mix = {"prompt": 0.90, "retr": 0.06, "policy": 0.03, "global": 0.01}

    budgets = np.linspace(0.06, 0.54, 7)  # rolling-window burn budget

    # Collect metrics: policy value ratio to oracle.
    ratios_fifo: List[float] = []
    ratios_greedy: List[float] = []
    ratios_shadow: List[float] = []

    # Also collect a representative point for the table.
    rep_B = float(budgets[len(budgets)//2])
    rep_stats: Dict[str, List[Tuple[float, float, float, int]]] = {"oracle": [], "fifo": [], "greedy": [], "shadow": []}

    for B in budgets:
        vf = []
        vg = []
        vs = []
        vo = []
        for s in range(args.seeds):
            arrivals = simulate(seed=1000 + 31*s, N=args.N, days=args.days, lam=args.lam, shards=40, policies=10, mix=mix)
            o = policy_exact_within_day(arrivals, args.N, B, args.W, args.tau)
            f = policy_fifo_gate(arrivals, args.N, B, args.W, args.tau)
            g = policy_value_greedy(arrivals, args.N, B, args.W, args.tau)
            sh = policy_shadow_price(arrivals, args.N, B, args.W, args.tau)
            vo.append(o[0])
            vf.append(f[0])
            vg.append(g[0])
            vs.append(sh[0])

            if abs(B - rep_B) < 1e-9:
                rep_stats["oracle"].append(o)
                rep_stats["fifo"].append(f)
                rep_stats["greedy"].append(g)
                rep_stats["shadow"].append(sh)

        vo_m = float(np.mean(vo))
        ratios_fifo.append(float(np.mean(vf)) / max(1e-12, vo_m))
        ratios_greedy.append(float(np.mean(vg)) / max(1e-12, vo_m))
        ratios_shadow.append(float(np.mean(vs)) / max(1e-12, vo_m))

    # Plot.
    out_fig = args.out_fig
    Path_out = __import__("pathlib").Path
    Path_out(out_fig).parent.mkdir(parents=True, exist_ok=True)

    plt.figure(figsize=(6.5, 4.0))
    plt.plot(budgets, ratios_fifo, marker="o", linewidth=1.6, label="FIFO")
    plt.plot(budgets, ratios_greedy, marker="o", linewidth=1.6, label="Value-greedy")
    plt.plot(budgets, ratios_shadow, marker="o", linewidth=1.6, label="Shadow-price")
    plt.xlabel("Rolling-window assurance budget $B_W$")
    plt.ylabel("Realized value / oracle value")
    plt.title("ADC gap to exact within-day oracle (v262)")
    plt.ylim(0.0, 1.02)
    plt.grid(True, alpha=0.25)
    plt.legend(frameon=False)
    plt.tight_layout()
    plt.savefig(out_fig, format="pdf")
    plt.close()

    # Table for representative point.
    def agg(xs: List[Tuple[float, float, float, int]]) -> Tuple[float, float, float, float]:
        arr = np.array([[a, b, c, d] for a, b, c, d in xs], dtype=float)
        return float(arr[:, 0].mean()), float(arr[:, 1].mean()), float(arr[:, 2].mean()), float(arr[:, 3].mean())

    oracle_v, oracle_lm, oracle_lp95, oracle_back = agg(rep_stats["oracle"])

    lines: List[str] = []
    lines.append("% Auto-generated by tools/assurance_adc_oracle_bench_v262.py")
    lines.append("\\begin{tabular}{lrrrr}")
    lines.append("\\toprule")
    lines.append("Policy & Value ratio & Mean delay & P95 delay & End backlog \\\\")
    lines.append("\\midrule")

    for name, key in [("Exact oracle", "oracle"), ("FIFO", "fifo"), ("Value-greedy", "greedy"), ("Shadow-price", "shadow")]:
        v, lm, lp95, back = agg(rep_stats[key])
        ratio = v / max(1e-12, oracle_v)
        lines.append(f"{name} & {ratio:.3f} & {lm:.2f} & {lp95:.2f} & {int(round(back))} \\\\")

    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")

    Path_out(args.out_tex).parent.mkdir(parents=True, exist_ok=True)
    Path_out(args.out_tex).write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"Wrote {out_fig} and {args.out_tex}; rep budget B={rep_B:.3f}")


if __name__ == "__main__":
    main()
