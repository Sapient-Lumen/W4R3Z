# DoF-closure certificate demo (v216)

This demo shows how a **residual DoF vector** (from `tools/dof_graph_v215.py`) can be turned into a compact **DoF-closure certificate (DoFC)** that acts as a publication gate.

Commands:

```bash
python3 tools/dof_graph_v215.py \
  --mer examples/mer_demo/mer_bestof8_signed.json \
  --out examples/dof_closure_demo_v216/dof_vector.json

python3 tools/dof_closure_cert_v216.py \
  --dof-vector examples/dof_closure_demo_v216/dof_vector.json \
  --profile-digest sha256:deadbeef \
  --out examples/dof_closure_demo_v216/dofc.json

# Optional: wrap DoFC as an in-toto Statement predicate (schematic).
python3 tools/dof_closure_cert_v216.py \
  --dof-vector examples/dof_closure_demo_v216/dof_vector.json \
  --profile-digest sha256:deadbeef \
  --intoto \
  --out examples/dof_closure_demo_v216/dofc_intoto_statement.json
```

Expected result:
- `dofc.verdict == "fail_closed"` because the input MER does not declare a `stopping/monitoring` spec (the `CSIC/SSIC` axis is open).
- Under a profile that *waives* stopping (fixed-n only), you can recompute the DoF vector with `--assume-fixed-n`.
