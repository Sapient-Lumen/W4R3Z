# FSER demo (v236): CCR + EOC

This is a tiny, runnable toy example of Full-Stack Evaluation Receipts (FSER):

- **CCR** (Channel Coverage Receipt): commits to per-channel trace roots.
- **EOC** (Egress Outcome Certificate): commits to an egress outcome over a suite and *binds* to the CCR.

The demo is intentionally small and uses synthetic traces.

## Files
- `suite.jsonl`: 5-case suite
- `output_trace.jsonl`, `tool_trace.jsonl`, `network_trace.jsonl`: toy channel traces
- `egress_log.jsonl`: per-case egress indicator (`egress`)
- `ccr.json`: emitted CCR
- `eoc.json`: emitted EOC

## Reproduce

From repo root:

```bash
cd examples/fser_demo_v236

python3 ../../tools/ccr_emit_v236.py \
  --run-id fser_demo_run_v236_1 \
  --channel output=output_trace.jsonl \
  --channel tool_calls=tool_trace.jsonl \
  --channel network=network_trace.jsonl \
  --out ccr.json

python3 ../../tools/eoc_emit_v236.py \
  --suite suite.jsonl \
  --log egress_log.jsonl \
  --event-field egress \
  --ccr ccr.json \
  --out eoc.json

python3 ../../tools/ccr_verify_v236.py --cert ccr.json --require output --require tool_calls --require network
python3 ../../tools/eoc_verify_v236.py --cert eoc.json
```
