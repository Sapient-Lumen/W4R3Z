# Research agenda and paper-candidate notes (v255)

This file is intentionally forward-looking: it captures *risky* paper directions, experiment ideas, and open problems we can turn into publishable results.


## v255 progress (2026-02-28)
- Added **cost-aware repair planning** (a small optimization layer) for IDCs: treat `anyOf` constraints as alternative evidence paths and minimize cost (`tools/idc_demo_article53_v255.py`, `tables/idc_article53_repair_cost_v255.tex`).
- Added a compact **alternative-evidence case study** and table (`profiles/toy_altpaths_v1.json` $
ightarrow$ `profiles/toy_altpaths_v2.json`, `tools/idc_demo_altpaths_v255.py`, `tables/idc_toy_altpaths_repair_cost_v255.tex`).
- Added brief positioning vs. **regression test selection** and **safety-case evidence maintenance** in `paper_idc.tex`.

## v254 progress (2026-02-28)
- Added a **minimal repair slice** to the Article~53 IDC demo (`tools/idc_demo_article53_v254.py`), generating `tables/idc_article53_repair_v254.tex`.
- Updated `paper_idc.tex` and the main paper to distinguish *impact closure* from an actionable *repair plan* (mint missing evidence vs reuse prerequisites).

## v253 progress (2026-02-28)
- Upgraded the Article~53 IDC demo to compute an **obligation-graph impact closure** from newly failing constraint IDs (`tools/idc_demo_article53_v253.py`), generating `tables/idc_article53_closure_v253.tex`.
- Updated `paper_idc.tex` to include and explain the closure table (stable requirement IDs + explicit obligation dependencies = audit-local slices).
- Fixed a small `profile_check.py` bug in the `anyPointLeq` helper path (missing helper name).
- Refreshed the KeyTrans architecture bibliography entry to **draft-ietf-keytrans-architecture-07** (Feb 2026).

## v251 progress (2026-02-28)
- Implemented an **ADCP gate** (`tools/ocf_discovery_adcp_gate_v251.py`) and a toy discovery profile with a proof-size cap + SDT requirement (`profiles/discovery_adcp_profile_v251.json`).
- Expanded the discoverability **conformance vector bundle** (`tools/ocf_discovery_conformance_vectors_v251.py`, `examples/discovery_conformance_v251/`).
- Added a concrete **IDC worked example** for Article~53 v1→v2 (`tools/idc_demo_article53_v251.py`) and wired it into `paper_idc.tex`.


## Paper suite (current)

1. **OCF-LLM (paper.tex)** — Obligation-Carrying Assurance for LLM Systems (full paper).
2. **IDC (paper_idc.tex)** — Interface Drift Certificates (treating checklists as versioned APIs).
3. **AD (paper_discovery.tex)** — Accountable Discoverability (verifiable evidence lookup).

## High-leverage novelty bets

### A. Discoverability as a security property (ADCP -> deployable spec)
- **Bet:** Most transparency systems treat lookup/search as “best effort”; turning it into a **conformance surface** (ADCP + vectors) is a missing piece that makes *receipt portability* real.
- **Hard questions:**
  - Minimum semantics for **portable absence** across common backends (SMT vs prefix trees vs map overlays).
  - Concrete, testable liveness commitments (SDT/MID) that survive mirrors/caches.
  - How to express and detect *index drift* vs *equivocation* vs *availability* with bounded monitors.

### B. Assurance admission control (SRE loop) as governance primitive
- **Bet:** Release governance for AI systems will converge on SRE-style loops, but lacks a rigorous *impact model* and *budget semantics*.
- **Experiments to run:**
  - Simulate “assurance SLO” policies with ABOM diffs from real OSS ML pipelines (or synthetic workloads).
  - Quantify throughput/latency tradeoffs for batch windows under different audit-locality assumptions.

### C. Evidence minimality + privacy-preserving replay
- **Bet:** Regulators and auditors will demand replayable evidence, but organizations will only adopt if *selective disclosure* is native.
- **Open problems:**
  - Composable mABOM projections that are stable under redaction.
  - Challengeable sketches (KMV/HLL variants) that are cheap to verify and resist gaming.

### D. Economics of witness networks for AI assurance
- **Bet:** Witnessing is the “coordination cost” bottleneck. We need a realistic model.
- **Possible angle:** treat witness capacity as a scarce resource; derive rate limits and incentives that align with assurance-change budgets.

## Concrete next steps (for the next turns)

1. **ADCP: make the profile more explicit**
   - Nail the *canonical key derivation* and the proof-bound semantics (size caps + depth + hash).
   - Add a “conformance levels” ladder (L0: offline receipts, L1: MID, L2: split-view monitors).

2. **Runnable experiments**
   - Add a *toy service harness* that serves fixtures and demonstrates a conformance failure (e.g., late indexing, proof bloat, equivocation).
   - Produce one figure: verifier cost vs proof bounds vs monitor sampling budget.

3. **Related-work tightening**
   - Map ADCP requirements to: CT, Sigstore/Rekor, KeyTrans, CONIKS, Key Transparency deployments.
   - For each: identify what is *provable offline* vs what depends on live APIs/mirrors.

4. **Main-paper positioning**
   - Clarify “why OCF-LLM is not just SBOM+attestations”: the differentiator is **fail-closed resolution** + **budgeted composition** + **drift-safe interfaces**.
   - Add a short “research agenda” section that makes explicit what is proved, what is measured, and what remains conjectural.

## What we should *not* do (yet)

- Claim real-world conformance results for public services without running the harness against them.
- Add new cryptography primitives unless they are essential; lean on existing CT/KeyTrans/SCITT building blocks.

## v256 progress (2026-02-28)
- Added **share-aware, cost-aware repair planning** for IDC via an exact+heuristic optimizer (`tools/idc_optimizer_v256.py`).
- Added a **synthetic benchmark** (`tools/idc_synth_bench_v256.py`) that generates profile drift instances with many alternative evidence paths and measures cost savings from choosing shared pathways.
- Wired the benchmark into the IDC paper (new table + figure).

### Open research angle (IDC)
- The repair-planning objective (min-cost union of actions subject to per-requirement alternative clauses) is NP-hard in general; there is room for:
  - principled approximations with worst-case bounds (e.g., LP relaxations),
  - domain-specific structure (small option size, bounded action families), and
  - online/streaming variants for large fleets where failures arrive incrementally.
