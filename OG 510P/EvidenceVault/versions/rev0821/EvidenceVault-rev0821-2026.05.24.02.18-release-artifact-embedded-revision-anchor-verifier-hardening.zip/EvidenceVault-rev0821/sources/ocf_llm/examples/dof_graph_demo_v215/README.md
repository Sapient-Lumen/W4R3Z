# DoF graph demo (v215)

This demo turns an existing **Minimal Evaluation Receipt (MER)** into:
- a **residual degrees-of-freedom (DoF) vector** (which axes are pinned vs missing), and
- a **protocol graph** (Graphviz `.dot`) for human review.

## Run

```bash
python3 tools/dof_graph_v215.py \
  --mer examples/mer_demo/mer_bestof8_signed.json \
  --dot-out examples/dof_graph_demo_v215/dof_graph.dot \
  > examples/dof_graph_demo_v215/dof_vector.json
```

To treat stopping as a fixed-n protocol (profile waiver):

```bash
python3 tools/dof_graph_v215.py \
  --mer examples/mer_demo/mer_bestof8_signed.json \
  --assume-fixed-n \
  --dot-out examples/dof_graph_demo_v215/dof_graph_fixedn.dot \
  > examples/dof_graph_demo_v215/dof_vector_fixedn.json
```

The paper uses this demo to illustrate the concept of **DoF-closed evidence**.
