#!/usr/bin/env python3
"""
make_eps_scoring_sim_table.py

Generates `_insert_eps_scoring_sim_table.tex` used by paperD.tex.

This is a *toy* microstructure simulation to illustrate epsilon-scoring:
  score(bid) = price + λ * (ε / 2^-80)

where ε is the bid's declared soundness risk and λ is a shadow price (risk aversion).

The simulation is deterministic given the fixed PRNG seed.
"""
from __future__ import annotations
import argparse
import math
import random
from typing import Dict, List, Tuple


def sample_eps(rng: random.Random) -> float:
    # log-uniform in [2^-90, 2^-60]
    u = rng.uniform(-90.0, -60.0)
    return 2.0 ** u


def run(n_auctions: int, k_bids: int, lambdas: List[float], seed: int = 7) -> List[Dict[str, float]]:
    rng = random.Random(seed)
    base = 2.0 ** (-80.0)
    rows: List[Dict[str, float]] = []
    for lam in lambdas:
        tot_price = 0.0
        tot_log2eps = 0.0
        tot_eps_scaled = 0.0
        tot_score = 0.0
        for _ in range(n_auctions):
            bids: List[Tuple[float, float]] = []
            for _ in range(k_bids):
                price = rng.uniform(1.0, 10.0)
                eps = sample_eps(rng)
                bids.append((price, eps))
            def score(be):
                price, eps = be
                return price + lam * (eps / base)
            price, eps = min(bids, key=score)
            tot_price += price
            tot_log2eps += (-math.log(eps, 2))
            tot_eps_scaled += (eps / base)
            tot_score += score((price, eps))
        rows.append({
            "lambda": lam,
            "price": tot_price / n_auctions,
            "log2eps": tot_log2eps / n_auctions,
            "eps_scaled": tot_eps_scaled / n_auctions,
            "score": tot_score / n_auctions,
        })
    return rows


def to_latex(rows: List[Dict[str, float]]) -> str:
    lines = []
    lines.append(r"\begin{table}[t]")
    lines.append(r"\centering")
    lines.append(r"\caption{Toy simulation of $\varepsilon$-scoring in a reverse auction. "
                 r"Each auction has $k{=}5$ bids with price in $[1,10]$ and $\varepsilon$ log-uniform in $[2^{-90},2^{-60}]$. "
                 r"The score is $\text{price}+\lambda\cdot(\varepsilon/2^{-80})$.}")
    lines.append(r"\label{tab:eps_scoring_sim}")
    lines.append(r"\begin{tabular}{rrrrr}")
    lines.append(r"\toprule")
    lines.append(r"$\lambda$ & mean price & mean $-\log_2\varepsilon$ & mean $\varepsilon/2^{-80}$ & mean score \\")
    lines.append(r"\midrule")
    for r in rows:
        lines.append(f"{r['lambda']:>6g} & {r['price']:.3f} & {r['log2eps']:.2f} & {r['eps_scaled']:.3g} & {r['score']:.3f} \\\\")
    lines.append(r"\bottomrule")
    lines.append(r"\end{tabular}")
    lines.append(r"\end{table}")
    return "\n".join(lines) + "\n"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="_insert_eps_scoring_sim_table.tex")
    ap.add_argument("--n", type=int, default=10000)
    ap.add_argument("--k", type=int, default=5)
    args = ap.parse_args()

    lambdas = [0.0, 0.1, 1.0, 10.0]
    rows = run(args.n, args.k, lambdas)
    tex = to_latex(rows)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(tex)

if __name__ == "__main__":
    main()
