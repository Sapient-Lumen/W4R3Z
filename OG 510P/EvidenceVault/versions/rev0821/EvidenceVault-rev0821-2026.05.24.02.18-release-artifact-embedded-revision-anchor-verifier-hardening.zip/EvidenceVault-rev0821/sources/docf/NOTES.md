## v86.41-ai (2026-02-28) quick notes
- Added a **canonical compact multiproof** encoding for complete (padded) Merkle trees (single ordered `sibling_hashes` list; deterministic verifier; no per-node position metadata).
- Extended the capsule opening micro-protocol with an **optional anti-griefing bond policy**: challengers can be required to post a bond sized to expected verification work, slashed on unsuccessful challenges.
- Updated the capsule cost model table/figure and added a generator (`make_merkle_capsule_costs.py`) to keep numbers reproducible.

## v86.40-ai (2026-02-28) quick notes
- Made Merkle-sealed capsules **fully deployable** by specifying an **executable dispute micro-protocol**: challenge names the exact governance-pinned reveal policy digest and required paths; response opens exactly those leaves with Merkle audit proofs.
- New schemas: `docf_capsule_open_challenge_v0.schema.json`, `docf_capsule_open_response_v0.schema.json`.
- New reference checker: `capsule_open_dispute_ref.py` with deterministic demo vectors (`test_vectors/capsule_open_*_demo.json`).
- Paper~D: added an "Executable capsule opening micro-protocol" paragraph + table + transcript excerpt.

## v86.39-ai (2026-02-28) quick notes
- Added a **Merkle-sealed capsule** format to support privacy-preserving cluster disputes: ledger entries can commit to a capsule root and reveal only dispute-required paths with Merkle audit proofs.
- New artifacts: `docf_merkle_capsule_v0.schema.json`, `merkle_capsule_ref.py`, `examples/merkle_capsule_demo.json`, `examples/merkle_capsule_openings_demo.json`, and `docf_capsule_reveal_policy_v0.schema.json`.
- Paper~D: new subsection on selective disclosure + multiproof tradeoffs, plus a concrete size table (`_insert_merkle_capsule_sizes.tex`) and a cost-model figure (`figures/merkle_capsule_proof_sizes.pdf`).

## v86.36-ai (2026-02-28) quick notes
- Upgraded correlation clusters into an **enforceable commitment layer**: digest-only publication + an optimistic challenge/reveal/adjudicate dispute game with mechanical reclassification.
- New artifacts: `docf_cluster_dispute_fsm_v0.schema.json`, `examples/cluster_dispute_fsm_demo.json`, `_insert_cluster_dispute_table.tex`, `docf_cluster_dispute_case_v0.schema.json`, `cluster_dispute_case_ref.py`, `test_vectors/cluster_dispute_case_demo.json`.
- Paper D now treats cluster assignment as a **cryptographic object** (replayable from evidence) rather than a self-reported tag; Paper E references the same enforcement path for receipt-complete markets.

---

## v86.20 (2026-02-28)
- Added Paper H and a client-policy split-view experiment; see `make_client_policy_experiment.py`.

## v86.32-ai (2026-02-28)
- Paper D: added an online/primal--dual view of risk-budgeted procurement (dynamic $\lambda$) with replayable updates; added two references (Buchbinder--Naor; Hazan).
- Paper A: added an explicit bridge paragraph from per-proof option accounting to portfolio governance ($\eps$-ledgers).
- Added this AI notes entry and refreshed ARCHIVE/CHANGELOG.

# dOCF evolving papers — notes (v86.16, 2026-02-28)

This archive currently contains eight LaTeX drafts:

- `paper.tex` — **full dOCF spec / manifesto** (long-form, includes reference tooling + worked manifests).
- `paperA.tex` — **Paper A (crypto core)**: retries/conditioning + cancellation as first-class soundness objects.
- `paperB.tex` — **Paper B (systems/contract)**: portability contracts + evidence-carrying policies for distributed proving.
- `paperC.tex` — **Paper C (SNL focus)**: security nutrition labels as portable acceptance objects (proof CDNs / markets).
- `paperD.tex` — **Paper D (portfolio governance)**: $\varepsilon$-ledgers, $\varepsilon$-scoring auctions, and anytime-valid performance envelopes.
- `paperE.tex` — **Paper E (receipt completeness)**: attempt DAG commitments + transparency logs + risk budgets as a systems/security framing.
- `paperF.tex` — **Paper F (PCT standardization)**: Proof Certificate Transparency for prover markets (bundles + checkpoints + witnessing).
- `paperG.tex` — **Paper G (witnessing note)**: split-view resistance via checkpoints, consistency proofs, and witness quorums.

## v86.11 updates (this turn)
- Added **Paper D** (portfolio governance): $\varepsilon$-scoring + $\varepsilon$-ledgers + anytime-valid performance-envelope certificates (e-values).
- Bibliography: added canonical references for e-values/safe testing and anytime-valid e-values.


## v86.8 updates (this turn)
- Added a **CT-style gossip quorum layer** for stapled checkpoints: independent observers exchange signed `docf-snl-gossip-bundle-v0` objects bound to the canonical checkpoint payload hash.
- Added **split-view conflict detection** across bundles and a portable **slashing proof** object (`test_vectors/snl_slashing_proof_conflict_demo.json`) that packages the conflicting signed checkpoints plus the observer bundles that carried them.
- Added an **optimistic gossip accumulator** (`docf-snl-gossip-accumulator-v0`): a Merkle-rooted commitment to many bundle digests with sampled inclusion proofs. The reference gate treats this as **monitor-only** evidence (deferred audit), never sufficient for reuse.
- Extended `snl_gate_policy_ref.py` with policy knobs for gossip: `require_gossip_quorum`, `min_gossip_quorum`, `enforce_gossip_allowlist`, plus `allow_accumulator_for_monitor` and accumulator issuer pins.
- Updated the SNL gate microbench table to include **gossip+quorum** and **monitor+accumulator** rows; regenerated demo gate policies/decisions that exercise these paths.
- Papers B/C updated to describe and demonstrate gossip-quorum reuse, conflict slashing proofs, and the optimistic accumulator as a bandwidth/performance tradeoff for monitoring.



## v86.6 updates (this turn)
- Upgraded SNL stapling to include an **RFC9162 consistency witness** (append-only growth evidence) in the demo staple (`test_vectors/snl_staple_demo.json`) and added a new gate policy flag `require_log_consistency` with a **pinned first checkpoint** hash.
- Added **freshness + revocation + key-rotation pins** to the SNL gate policy surface: SNL validity windows, max-age bounds for labels and checkpoints, issuer/witness revocation lists, and allowlists for log signing keys.
- Improved decision telemetry: successful `snl_log_inclusion` checks now include a compact `staple_summary` (tree size, age, keyid, quorum, consistency path length) so caches can log what was actually verified.
- Regenerated the SNL gate microbench table to include the **consistency-verified** path (`SNL_staple+consistency`) and the corresponding gate evaluation overhead.
- Papers B/C updated to embed the full demo staple plus the **consistency-requiring** policy + decision vectors.

## v86.5 updates (this turn)
- Added **witness cosigning** for SNL transparency checkpoints (Sigsum-style). The demo SNL staple now carries a 2-of-3 witness quorum block over the canonical checkpoint payload.
- Extended the **gate policy** with `require_witness_cosignatures`, `min_witness_quorum`, and local witness allowlists; added demo policy + decision vectors for log+quorum reuse.
- Updated the **SNL gate microbench** to measure quorum verification overhead and regenerated `_insert_snl_gate_bench_table.tex`.
- Papers B/C updated to describe witness cosigning as an anti-equivocation hardening layer; Paper C embeds a demo gate policy requiring a witness quorum.

## v86.4 updates (this turn)
- Added a transparency-stapling path for SNLs: `snl_staple_ref.py` emits a deterministic CT/RFC9162-style inclusion witness bound to an SNL digest (`test_vectors/snl_staple_demo.json`).
- Extended the reference gate to optionally require staples (`require_log_inclusion`, `allowed_log_ids`), with demo policy + decision vectors.
- Upgraded the SNL gate microbench to measure the optional staple verification path and regenerated `_insert_snl_gate_bench_table.tex`.
- Papers B/C updated to discuss and demonstrate transparency staples as an optional monitorability layer.

## v86.3 updates (this turn)
- New Paper C: **Security Nutrition Labels for Portable Proof Acceptance** (\`paperC.tex\`), positioned as a systems/security submission centered on cacheable acceptance objects.
- Added a reference sizing + micro-benchmark for the SNL gate path (\`bench_snl_gate_ref.py\`) and a LaTeX insert table (\`_insert_snl_gate_bench_table.tex\`).
- Paper B now includes the SNL gate microbench table and expands case-study context to explicitly mention emerging proving networks (Succinct, Brevis ProverNet, Fermah) with new curated bibliography entries.
- Bibliography: added bibitems for Succinct Network mainnet + whitepaper, Brevis ProverNet blog + whitepaper, and Fermah network docs/blog.

## v86.2 updates (this turn)
- Paper A: added a second cancellation-sizing table for ~64-bit fields (Table `tab:cancel-sizing-64`) and added a new subsection that makes cacheable acceptance explicit via SNL compilation (Theorem `thm:snl-cache`).
- Paper B: added an all-resolved SNL demo plus a reference gate-policy evaluator (`snl_gate_policy_ref.py`) with demo policies and decisions.
- New demo vectors: `option_surface_ledger_demo_ok.json`, `typed_option_repricing_report_demo_ok.json`, `security_nutrition_label_demo_ok.json`, plus SNL gate policies/decisions.

## What feels most novel (and worth doubling down on)

### 1) The “attempt surface” as an explicit interface
Treating retries / aborts / re-auctions / restarts as a *cryptographic object* that must be accounted for (attempt envelope + selection bounds), *and* making it portable across organizations.

**Research punchline:** if you cannot evidence your retry surface, you cannot claim amplification that depends on “fresh independent coins”.

### 2) Grinding Gap Certificates (GGC)
A “small knob” in engineering (micro-retries) becomes a *policy parameter* once it is bounded and logged. This bridges:
- crypto soundness loss accounting
- transparency / non-equivocation (CT / SCITT receipts)
- governance (market rules, auditability)

### 3) ABI + determinism ladders as a portability contract
The compliance vector table (ABI / provenance / determinism / etc.) is essentially a “security nutrition label” that:
- is *machine-checkable*
- has *fail-closed semantics*
- composes with caching / multiproofs / third-party acceptance reuse

## Paper directions (candidate “submission targets”)

### Paper A (crypto)
**Story:** distributed proving creates two overlooked soundness degradations:
1. algebraic cancellation in shard-glue checks
2. abort/retry/conditioning (attempt-selective adversary)

**Hard theorem targets to strengthen**
- Replace union bound in selection accounting with tighter bounds under realistic retry policies (e.g., bandit-like selection, early stopping).
- Model correlation explicitly (shared beacons, partial transcripts) and give “graceful degradation” bounds.
- Give a clean separation lemma: *cancellation term* vs. *conditioning term* vs. *PCS base soundness*.

### Paper B (systems/contract)
**Story:** proofs are now supply-chain artifacts. “Verify” is not the workflow.
Portability contracts make proofs cacheable and reuse-safe across markets and org boundaries.

**Concrete systems targets**
- Implement a minimal contract format (JSON + JCS canonicalization) + reference resolver.
- Demonstrate downgrade behavior on real pipelines (missing receipts → monitoring-only, missing retry cap → non-cacheable).
- Show overhead numbers (bytes + ms) for contract verification and receipt checking.

## Bibliography / reference sanity (quick audit plan)

The long-form spec’s `references.tex` is intentionally expansive.
For submission drafts, we should aggressively **curate** and **verify**:
- Core distributed proving: DIZK, Giraffe.
- Service boundary: zkSaaS (USENIX Security 2023).
- Orchestration: CrowdProve (arXiv:2501.03126), push0 (arXiv:2602.16338).
- Transparency evidence: RFC 9162 (Certificate Transparency), SCITT architecture + receipts profiles.
- Fiat–Shamir with aborts: recent analyses that treat abort loops as security-critical.

Action item: create a curated `references_A.tex` / `references_B.tex` with only sources actually cited in the submission versions.

## Next-turn TODOs (high leverage)

1. **Cull Paper A** to ~12 pages (tight model + 2–3 theorems + one table of practical parameters).
2. **Turn Paper B** into a measurement-backed systems paper:
   - integrate evidence overhead table from the spec
   - add a “resolver algorithm” pseudocode block
3. Add an appendix: “contract downgrade semantics” as a small logic / ruleset.
4. Create a tiny repo-style structure (Makefile + build instructions) and ensure LaTeX compiles cleanly.



New in v86.13:
- `PCT_NOTES.md` — working spec scratchpad for Proof Certificate Transparency (Paper F) + SCITT/Sigstore mapping.
- `pct_bundle_ref.py` — emits/verifies an end-to-end PCT bundle demo.


## v86.17 quick note
- Added partition split-view latency experiment + tables/figures; see `make_split_view_latency_experiment.py`.


## v86.33-ai quick note
- Paper D now includes a fully worked receipt→ledger example and a demo λ schedule figure (`figures/lambda_schedule_demo.pdf`).
- New reference tool: `online_lambda_policy_ref.py`.
