#!/usr/bin/env python3
"""option_surface_ledger_ref.py

Reference tool: compile an Option Surface Ledger (OSL).

Purpose
-------
In strict-deadline proving, security degrades not only with observed retries (Q)
but also with *abort/conditioning options* that let an actor sample multiple
candidates before committing (AOC-style windows, re-auction windows, oracle
updates, etc.). The OSL bundles these option surfaces into one deterministic,
cacheable artifact:

  - Binds the session (sid, manifest_digest)
  - References an MCR digest (receipt-complete observed attempt count)
  - Lists option-bearing boundaries and their attempt-multiplier factors T
  - Conservatively composes them (default: product) into T_total and bias bits

Input JSON (minimal)
--------------------
{
  "sid": "session-id",
  "manifest_digest": "sha256:...",
  "mcr_digest": "sha256:...",
  "options": [
    {"option_kind": "beacon_wait", "aoc": { ... AOC JSON ... }},
    {"option_kind": "reauction_wait", "T": 5}
  ],
  "composition": {"rule": "product"}
}

Output JSON
-----------
{
  "type": "option_surface_ledger",
  ...,
  "derived_total": {"T_total": 150, "bias_bits_total": 8, ...},
  "digest": "sha256:..."
}

This tool is intentionally conservative. If a term cannot be derived, it raises.
Fail-close behavior (treat missing OSL as T_total -> infinity) is a *policy*
choice in the resolver.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from typing import Any, Dict, List


def _ceil_log2(n: int) -> int:
    if n <= 1:
        return 0
    return int(math.ceil(math.log(n, 2)))


def _to_int(x: Any, name: str) -> int:
    if x is None:
        raise ValueError(f"missing {name}")
    if isinstance(x, bool):
        raise TypeError(f"{name} must be an integer")
    if isinstance(x, int):
        return int(x)
    if isinstance(x, str):
        return int(x.strip())
    raise TypeError(f"{name} must be an integer")


def _sha256_hex(obj: Dict[str, Any]) -> str:
    s = json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return "sha256:" + hashlib.sha256(s).hexdigest()


def _extract_T(opt: Dict[str, Any]) -> int:
    # Preference order: explicit T, derived.T, embedded AOC derived.T
    if "T" in opt and opt["T"] is not None:
        return _to_int(opt["T"], "options[].T")

    derived = opt.get("derived") or {}
    if "T" in derived and derived["T"] is not None:
        return _to_int(derived["T"], "options[].derived.T")

    aoc = opt.get("aoc")
    if isinstance(aoc, dict):
        aoc_derived = aoc.get("derived") or {}
        if "T" in aoc_derived and aoc_derived["T"] is not None:
            return _to_int(aoc_derived["T"], "options[].aoc.derived.T")

    raise ValueError("Option entry must provide T, derived.T, or aoc.derived.T")


def _extract_source(opt: Dict[str, Any]) -> Dict[str, Any]:
    if isinstance(opt.get("source"), dict):
        return opt["source"]
    if isinstance(opt.get("aoc"), dict):
        aoc = opt["aoc"]
        return {
            "kind": "aoc",
            "ref": aoc.get("observable", {}).get("ref") or aoc.get("observable", {}).get("source_kind") or "aoc",
            "digest": aoc.get("digest"),
        }
    if "T" in opt:
        return {"kind": "cap", "ref": "explicit_T"}
    return {"kind": "unknown"}


def compile_osl(inp: Dict[str, Any]) -> Dict[str, Any]:
    sid = inp.get("sid")
    manifest_digest = inp.get("manifest_digest")
    mcr_digest = inp.get("mcr_digest")
    if not isinstance(sid, str) or not sid:
        raise ValueError("sid must be a non-empty string")
    if not isinstance(manifest_digest, str) or not manifest_digest:
        raise ValueError("manifest_digest must be a non-empty string")
    if not isinstance(mcr_digest, str) or not mcr_digest:
        raise ValueError("mcr_digest must be a non-empty string")

    comp = inp.get("composition") or {}
    rule = (comp.get("rule") or "product").strip().lower()
    if rule not in {"product", "max", "custom"}:
        raise ValueError("composition.rule must be one of: product, max, custom")

    opts_in: List[Dict[str, Any]] = inp.get("options") or []
    if not isinstance(opts_in, list):
        raise TypeError("options must be a list")

    opts_out: List[Dict[str, Any]] = []
    Ts: List[int] = []
    for i, opt in enumerate(opts_in):
        if not isinstance(opt, dict):
            raise TypeError(f"options[{i}] must be an object")
        kind = opt.get("option_kind")
        if not isinstance(kind, str) or not kind:
            raise ValueError(f"options[{i}].option_kind must be a non-empty string")

        T = _extract_T(opt)
        if T < 1:
            raise ValueError(f"options[{i}] derived T must be >= 1")
        bias_bits = opt.get("bias_bits")
        if bias_bits is None:
            bias_bits = _ceil_log2(T)
        else:
            bias_bits = _to_int(bias_bits, f"options[{i}].bias_bits")

        Ts.append(T)

        out_opt = dict(opt)
        out_opt.pop("T", None)
        out_opt.pop("bias_bits", None)
        # Normalize into the schema shape.
        out_opt.setdefault("option_id", opt.get("option_id") or f"opt-{i}")
        out_opt.setdefault("boundary", opt.get("boundary") or "")
        out_opt["source"] = _extract_source(opt)
        out_opt["derived"] = {
            "T": T,
            "bias_bits": bias_bits,
            "repricing_rule": "bias_bits=ceil(log2 T)",
        }
        out_opt["receipts"] = opt.get("receipts") or {}
        opts_out.append(out_opt)

    if rule == "product":
        T_total = 1
        for T in Ts:
            # Python big ints are fine; keep deterministic.
            T_total *= int(T)
        reprule = "T_total=product(T_i); bias_bits_total=ceil(log2 T_total)"
    elif rule == "max":
        T_total = max(Ts) if Ts else 1
        reprule = "T_total=max(T_i); bias_bits_total=ceil(log2 T_total)"
    else:
        # Custom is reserved for future resolvers; default to product.
        T_total = 1
        for T in Ts:
            T_total *= int(T)
        reprule = "custom (defaulted to product)"

    bias_bits_total = _ceil_log2(T_total)

    out: Dict[str, Any] = {
        "type": "option_surface_ledger",
        "sid": sid,
        "market_id": inp.get("market_id"),
        "manifest_digest": manifest_digest,
        "mcr_digest": mcr_digest,
        "options": opts_out,
        "composition": {"rule": rule, "notes": comp.get("notes", "Conservative default: multiply option factors across boundaries.")},
        "derived_total": {
            "T_total": int(T_total),
            "bias_bits_total": int(bias_bits_total),
            "repricing_rule": reprule,
        },
        "notes": inp.get(
            "notes",
            "OSL is a conservative, cacheable summary of abort/conditioning option surfaces; policies may require it to make attempt repricing auditable.",
        ),
    }

    out_no_digest = dict(out)
    out_no_digest.pop("digest", None)
    out["digest"] = _sha256_hex(out_no_digest)
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="infile", default=None, help="Input JSON file (default: stdin).")
    ap.add_argument("--out", dest="outfile", default=None, help="Output JSON file (default: stdout).")
    args = ap.parse_args()

    raw = sys.stdin.read() if args.infile is None else open(args.infile, "r", encoding="utf-8").read()
    obj = json.loads(raw) if raw.strip() else {}
    out = compile_osl(obj)

    s = json.dumps(out, indent=2, sort_keys=False) + "\n"
    if args.outfile is None:
        sys.stdout.write(s)
    else:
        with open(args.outfile, "w", encoding="utf-8") as f:
            f.write(s)


if __name__ == "__main__":
    main()
