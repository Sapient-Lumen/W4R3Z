#!/usr/bin/env python3
"""cross_log_staple_ref.py

Reference verifier for `docf-cross-log-staple-v0`.
Verifies the primary checkpoint signature and the secondary inclusion witness.

Reference-grade code for paper examples; not hardened.
"""

from __future__ import annotations

import argparse
import json

from log_inclusion_witness_ref import verify_sth_signature, verify_witness
from docf_ref_tools_common import emit_json


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit", action="store_true", help="emit the demo vector (matches test_vectors/cross_log_staple_demo.json)")
    ap.add_argument("--verify", metavar="PATH", help="verify a cross-log staple JSON file")
    args = ap.parse_args()

    if args.emit:
        with open("test_vectors/cross_log_staple_demo.json", "r", encoding="utf-8") as f:
            emit_json(json.load(f))
        return

    if args.verify:
        with open(args.verify, "r", encoding="utf-8") as f:
            obj = json.load(f)
        ok_primary = verify_sth_signature(obj["primary_checkpoint"])
        ok_secondary = verify_witness(obj["secondary_inclusion_witness"])
        ok = ok_primary and ok_secondary
        print("OK" if ok else "FAIL")
        raise SystemExit(0 if ok else 2)

    ap.print_help()


if __name__ == "__main__":
    main()
