#!/usr/bin/env python3
"""verify_global_grinding_budget_cert_ref.py

Reference verifier for `global_grinding_budget_certificate`.

Goals:
- Be small and dependency-light.
- Provide a *fail-closed* check that a relying party/auditor can run offline.

Checks performed:
1) JSON-Schema validation against `docf_global_grinding_budget_cert_v0.schema.json`.
2) Basic semantic checks:
   - Q_total_observed <= Q_total_declared
   - time window is present (if provided) and start < end (lexicographic RFC3339Z)
3) Optional Ed25519 signature check if the certificate includes:
   - issuer_pubkey_b64 (raw Ed25519 pubkey)
   - sig of the form `ed25519:<base64sig>`
   The signature is over the JCS (RFC 8785-style) canonical JSON of the object
   *excluding* the `sig` field.

Usage:
  ./verify_global_grinding_budget_cert_ref.py --in test_vectors/global_grinding_budget_cert_demo.json

Exit codes:
  0 = ok
  2 = verification failed
"""

from __future__ import annotations

import argparse
import base64
import json
from pathlib import Path
from typing import Any, Dict

import jsonschema
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey


ROOT = Path(__file__).resolve().parent
SCHEMA_PATH = ROOT / "docf_global_grinding_budget_cert_v0.schema.json"


def jcs_bytes(x: Any) -> bytes:
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def load_json(p: Path) -> Dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def load_schema() -> Dict[str, Any]:
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def strip_sig(obj: Dict[str, Any]) -> Dict[str, Any]:
    o = dict(obj)
    o.pop("sig", None)
    return o


def verify_sig_if_present(cert: Dict[str, Any]) -> bool:
    sig = cert.get("sig")
    pk_b64 = cert.get("issuer_pubkey_b64")

    if not sig or not pk_b64:
        # Signature verification is optional (schema only requires `sig` as a string).
        return True

    if not isinstance(sig, str) or not sig.startswith("ed25519:"):
        return False

    try:
        sig_raw = base64.b64decode(sig.split(":", 1)[1].encode("ascii"))
        pk_raw = base64.b64decode(pk_b64.encode("ascii"))
        pk = Ed25519PublicKey.from_public_bytes(pk_raw)
        pk.verify(sig_raw, jcs_bytes(strip_sig(cert)))
        return True
    except Exception:
        return False


def semantic_checks(cert: Dict[str, Any]) -> bool:
    try:
        qd = int(cert.get("Q_total_declared", -1))
        qo = int(cert.get("Q_total_observed", -1))
        if qo < 0 or qd < 0 or qo > qd:
            return False

        tw = cert.get("time_window")
        if isinstance(tw, dict):
            s = tw.get("start_utc")
            e = tw.get("end_utc")
            # RFC3339Z timestamps compare lexicographically if normalized.
            if isinstance(s, str) and isinstance(e, str) and s >= e:
                return False

        return True
    except Exception:
        return False


def verify(cert: Dict[str, Any]) -> tuple[bool, str]:
    try:
        jsonschema.validate(instance=cert, schema=load_schema())
    except Exception as e:
        return False, f"schema: {e}"

    if not semantic_checks(cert):
        return False, "semantic: failed (Q_total or time_window)"

    if not verify_sig_if_present(cert):
        return False, "signature: failed"

    return True, "ok"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True, help="Path to certificate JSON")
    args = ap.parse_args()

    cert = load_json(Path(args.inp))
    ok, msg = verify(cert)
    if ok:
        print("OK:", msg)
        return
    print("FAIL:", msg)
    raise SystemExit(2)


if __name__ == "__main__":
    main()
