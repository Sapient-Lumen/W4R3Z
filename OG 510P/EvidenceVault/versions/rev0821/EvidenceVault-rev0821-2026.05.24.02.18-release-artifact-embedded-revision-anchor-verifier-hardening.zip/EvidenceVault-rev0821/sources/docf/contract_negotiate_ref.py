#!/usr/bin/env python3
"""contract_negotiate_ref.py

Reference sketch: build a *contract negotiation transcript* from a list of
participants' docf-policy-v0 policies.

Given N policies:
  1) normalize each into PNF (totalized atoms)
  2) compute the PNF-join (weakest policy stronger than all)
  3) emit a docf-contract-negotiation-v0 object that references the join report
     and (optionally) implication witnesses.

This is intentionally minimal and does not implement real signatures.

Usage:
  python3 contract_negotiate_ref.py --id partyA --policy test_vectors/policy_demo_A.json \
    --id partyB --policy test_vectors/policy_demo_B.json \
    --out test_vectors/contract_negotiation_demo.json
"""

from __future__ import annotations

import argparse
import json
from typing import Any, Dict, List, Tuple

from docf_ref_tools_common import jcs, sha256_hex

import policy_normalize_ref
import policy_pnf_order_ref


def _load(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--id", action="append", dest="ids", required=True)
    ap.add_argument("--policy", action="append", dest="policies", required=True)
    ap.add_argument("--created_at", default="2026-02-24T00:00:00Z")
    ap.add_argument("--out", default="-")
    args = ap.parse_args()

    if len(args.ids) != len(args.policies) or len(args.ids) < 2:
        raise SystemExit("Need >=2 participants and equal --id/--policy counts")

    participants: List[Dict[str, Any]] = []
    pnfs: List[Dict[str, Any]] = []

    for pid, ppath in zip(args.ids, args.policies):
        pol = _load(ppath)
        pnf = policy_normalize_ref.normalize(pol)
        d = sha256_hex(jcs(pnf))
        participants.append({
            "id": pid,
            "policy_nf_digest": "sha256:" + d,
            "policy_nf_ref": "sha256:" + d,
            "sig": {"dsse": "(demo signature omitted)"},
        })
        pnfs.append(pnf)

    # Join iteratively.
    J = pnfs[0]
    for nxt in pnfs[1:]:
        J = policy_pnf_order_ref.join(J, nxt)

    join_digest = sha256_hex(jcs(J))

    # Join report (inline; a real deployment would store separately and staple receipts)
    join_report = {
        "type": "docf-policy-join-report-v0",
        "version": "0",
        "created_at": args.created_at,
        "inputs": [{"name": p["id"], "policy_nf_digest": p["policy_nf_digest"].replace("sha256:", "")} for p in participants],
        "output_policy_nf_digest": join_digest,
        "output_pnf": J,
        "notes": "PNF-join over participant policies (reference sketch).",
    }
    join_report_digest = sha256_hex(jcs(join_report))

    out = {
        "type": "docf-contract-negotiation-v0",
        "version": "0",
        "created_at": args.created_at,
        "protocol": "dCNP-v0",
        "participants": participants,
        "join": {
            "join_report_digest": "sha256:" + join_report_digest,
            "join_report_ref": "sha256:" + join_report_digest,
            "output_policy_nf_digest": "sha256:" + join_digest,
        },
        "dominance_witnesses": [],
        "anchors": [],
        "notes": "Reference negotiation transcript. Add real signatures and transparency anchors in production.",
    }

    if args.out == "-":
        json.dump(out, fp=sys.stdout, indent=2, sort_keys=True)
        print()
    else:
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(out, f, indent=2, sort_keys=True)
            f.write("\n")


if __name__ == "__main__":
    import sys
    main()
