## v86.21 (2026-02-28)
- Implemented the ``replace toy operator IDs'' next step: added `data/witness_pool_snapshot_2026-02-28.json` built from Witness Network tables and public about pages, with deterministic table/analysis generation.
- Added `make_witness_diversity_real_pool.py` to run a sensitivity sweep on the real snapshot plus an augmented multi-instance stress-test (showing when diversity-aware selection materially changes dual-accept risk).
- Updated Paper F/I to cite and include the real snapshot and the stress-test table.

## v86.20 (2026-02-28)
- Added correlated witness compromise as a first-class threat model extension and wired it into Paper F/G/H.
- New artifact: `make_witness_diversity_experiment.py` + `tab:witness_diversity_risk` for quick parameter selection.
- Next research risk: replace toy operator IDs with a parsed view of a real witness config (e.g., a public witness network list) and evaluate diversity heuristics under observed operator clustering.

## v86.19 (2026-02-28)
- Added a toy but replayable client-policy experiment (`make_client_policy_experiment.py`) focusing on hard-partition split views; generated `tab:client_policy_refusal` + `pct_client_policy_refusal_cdf.pdf`.
- Key takeaway: if clients never query outside their default witness locality, a split view can persist indefinitely for that client; even tiny exploration rates close the tail.

## v86.18 notes (topology + polling)
- Added a sparse overlay experiment (`make_split_view_topology_experiment.py`) that separates *detection* from *alert coverage* and surfaces heavy tails on sparse ER-like overlays.
- Added a toy client polling model producing `tab:split-view-client-refusal`.
- Follow-up: (i) fit overlay families to real witness networks (degree distributions) and (ii) model clients as sticky (pinning witnesses) vs rotating (random polling).

# PCT_NOTES.md

**Snapshot:** v86.16-ai (2026-02-28)

## 0. What's new in v86.16

- Added a distributional evaluation pass (`make_pct_distribution_tables.py`) that produces 10k-trial CDFs and robust p50/p95 summary tables for inclusion proofs + witness cosignature verification.
- Added an explicit ``compromise-budget'' table for $t$-of-$m$ witness policies (toy independence model) so deployments can compare witness parameters numerically.
- Paper F/G now cite fresh Sigstore/SCITT operational context (Rekor v2 tile-backed log; Cosign CVE involving skipped TL verification; SCITT architecture draft-16).


This file is the working scratchpad for Paper F (Proof Certificate Transparency) and its concrete build artifacts.

## 1. What is new in v86.13

- We now have a *single portable artifact* (`docf_pct_bundle_v0` / `test_vectors/pct_bundle_demo.json`) that can be stapled to a delivered proof.
- `pct_bundle_ref.py` verifies the bundle end-to-end: recomputes digests, recomputes the Merkle root, verifies inclusion proofs.
- The LaTeX table `_insert_pct_end2end_demo_table.tex` is generated from the demo bundle and gives a concrete staple overhead.

## 2. PCTB-v0 minimal requirements (normative-ish)

A conforming PCT bundle **MUST** include:

1. A *selection receipt* object (e.g., `docf_market_round_cert_v0`), and its digest.
2. An Attempt DAG commitment object (`docf_attempt_dag_v0`), derived from an attempt trace or equivalent receipts.
3. An epsilon ledger (`docf_eps_ledger_v0`) with resolved per-session/epoch soundness entries and an explicit composition rule.
4. A performance envelope certificate (e-values) or an explicit declaration that no performance certificate is provided.
5. A binding certificate (Market Session Certificate) that commits to (1)-(4) digests.
6. A transparency inclusion proof for each digest under a single log root/checkpoint.

A market integrating PCT **SHOULD**:

- refuse settlement unless all required staples are present;
- provide a stable dereference URI for the bundle (SCRAPI-style disclosure patterns);
- use tile/page log APIs to make retrieval cheap at scale.

## 3. SCITT mapping (profile sketch)

A plausible SCITT profile is:

- PCTB is wrapped as a SCITT Signed Statement (COSE_Sign1 or DSSE->COSE).
- The transparency service issues a COSE receipt (e.g., the CCF receipts profile draft).
- The SCRAPI endpoints expose:
  - `/.well-known/scitt/pctb/<sid>` for bundle retrieval,
  - `/.well-known/scitt/receipts/<sid>` for inclusion receipts,
  - `/.well-known/scitt/checkpoints/<epoch>` for checkpoint/consistency.

This is intentionally compatible with Sigstore-style inclusion monitors and existing CT gossip approaches.

## 4. Next experiments to build

1. **(Done in v86.14)** Consistency proofs + checkpoints: `transparency_log_ref.py` now implements RFC~9162-style minimal consistency proofs and includes a tiny demo; `checkpoint_ref.py` signs STH-style checkpoints with Ed25519.
2. **(Done in v86.14)** Split-view adversary demo: `split_view_demo_ref.py` emits a test vector where a log signs two incompatible roots at the same tree size; `witness_monitor_ref.py` refuses to cosign both, producing a concrete ``threshold witness'' mitigation.
3. **(Done in v86.16, partial)** Microbenchmarks: `make_pct_bench_tables.py` generates `test_vectors/pct_bench_results.json` and LaTeX tables for (a) inclusion verification, (b) consistency verification, (c) Ed25519 witness verification, and (d) end-to-end demo bundle emit+verify.
4. **Measurement pass (next):** scale microbenchmarks to distributional experiments: replay synthetic sessions ($N\ge 10^4$) and summarize (a) staple size distribution (inclusion + consistency + witness), (b) verifier CPU time distribution, (c) witness refusal rate under injected equivocations.
5. **Deployment realism (next):** prototype a tile/compact log storage interface (static-CT / tiles) for ``cheap'' verifiers; evaluate incremental fetch costs under light client assumptions (cf. CT tiles / Sigstore Rekor v2 ideas).


## v86.17 worklog (2026-02-28)
- Implemented a replayable partition split-view latency experiment (`make_split_view_latency_experiment.py`).
- Generated `tab:split_view_latency` + scaling table + two CDF figures and wired them into Papers F/G.
- Interpretation: without cross-observation (no gossip), t=1 policies admit indefinite split views; gossip sharply compresses detection time; majority/2/3 thresholds eliminate dual acceptance in the partition model.
- Next risk: replace the complete-graph exponential gossip with a sparse graph + heterogeneous delays (e.g., AS-level), and measure *time-to-quorum-refusal* under client polling.
