#!/usr/bin/env python3
"""witness_set_optimizer_ref.py

Toy witness-set construction algorithm used by the archive.

Goal (demo): choose a witness set of size m that minimizes a conservative
correlation proxy rho_hat induced by clustering along a small set of risk
"domains" (e.g., operator, region). For a given labeling function ell_d(w),
we use:

  rho_d(S) = sum_g n_g(n_g-1) / (m(m-1))
  rho_hat(S) = max_d rho_d(S)

This matches the WDD bound used elsewhere in the archive.

The optimizer is intentionally simple and deterministic:
  greedy min-max: add the next witness that minimizes rho_hat of the partial set.

Usage:
  ./witness_set_optimizer_ref.py --pool test_vectors/witness_candidate_pool_demo.json --m 7 --domains operator,region

Outputs JSON with selected witness IDs and rho metrics.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List, Tuple


def _rho(labels: List[str]) -> float:
    m = len(labels)
    if m <= 1:
        return 0.0
    counts: Dict[str, int] = {}
    for x in labels:
        counts[x] = counts.get(x, 0) + 1
    num = sum(v * (v - 1) for v in counts.values())
    return num / (m * (m - 1))


def rho_hat_for_set(ws: List[Dict[str, Any]], domains: List[str]) -> Tuple[float, Dict[str, float]]:
    by: Dict[str, float] = {}
    for d in domains:
        labels = [str(w.get(d) or w.get("id")) for w in ws]
        by[d] = _rho(labels)
    rh = max(by.values()) if by else 0.0
    return rh, by


def greedy_select(pool: List[Dict[str, Any]], m: int, domains: List[str]) -> Dict[str, Any]:
    remaining = list(pool)
    selected: List[Dict[str, Any]] = []

    while len(selected) < m and remaining:
        best_i = None
        best = None
        best_unique = -1

        for i, cand in enumerate(remaining):
            trial = selected + [cand]
            rh, by = rho_hat_for_set(trial, domains)
            uniq_ops = len({(w.get("operator") or w.get("id")) for w in trial})
            key = (rh, -uniq_ops)  # minimize rho_hat, then maximize unique operators
            if best is None or key < best:
                best = key
                best_i = i
                best_unique = uniq_ops

        selected.append(remaining.pop(best_i))

    rh, by = rho_hat_for_set(selected, domains)
    return {
        "type": "docf_witness_set_selection_demo_v0",
        "m": m,
        "domains": domains,
        "selected_witness_ids": [w["id"] for w in selected],
        "rho_by_domain": {k: float(f"{v:.6g}") for k, v in by.items()},
        "rho_hat": float(f"{rh:.6g}"),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--pool", default="test_vectors/witness_candidate_pool_demo.json")
    ap.add_argument("--m", type=int, default=7)
    ap.add_argument("--domains", default="operator,region")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    pool_obj = json.loads(Path(args.pool).read_text(encoding="utf-8"))
    pool = pool_obj.get("witnesses", [])
    domains = [x.strip() for x in args.domains.split(",") if x.strip()]

    out = greedy_select(pool, args.m, domains)
    if args.out:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(out, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
