## v86.44 (2026-02-28)
- **Tighter multi-homing repricing rule landed.** Paper D now reprices cross-venue exposure in the additive hazard domain $h(\varepsilon)=-\ln(1-\varepsilon)$ (Lemma `lem:additive_hazards_multihoming`), yielding an exposure-factor penalty $\log_2(H/H_\ell)$ that strictly generalizes the homogeneous $\log_2 M$ bound.
- **Heterogeneous-venue demo added.** `make_multihoming_microstructure.py` generates `_insert_multihoming_heterogeneity_table.tex` and `pct_multihoming_heterogeneity_hidden_bits.pdf`, illustrating that hidden bits can far exceed $\log_2 M$ when venues differ in base error.
- **Analogy anchored.** Added a PBS/MEV-Boost multi-relay citation to contextualize multi-source selection as an ecosystem-level exposure vector.

## v86.43 (2026-02-28)
- **Multi-homing made first-class in Paper D.** Added a concrete cross-market subsection with the existing hidden-bits figure + inflation table, plus a ``two portable mitigations'' framing (CMBIs + GGBCs).
- **GGBC tooling upgraded from stub to runnable.** The demo vector now includes an Ed25519 public key and signature, and `verify_global_grinding_budget_cert_ref.py` performs schema + semantic + optional signature verification (fail-closed).
- **SCITT-style wrapper emitted.** `make_scitt_statement_global_grinding_budget_cert_ref.py` produces a deterministic JSON statement wrapper (with a demo vector) suitable for logging in the archive’s CT-style transparency log tools.
- **PCT synthesis tightened.** Paper J now includes a short enforceability story: Merkle-sealed capsules + dispute microprotocol allow digest-by-default correlation claims with challenge-based disclosure.

### Next research pushes (high-risk / high-reward)
- **Adversarial venue selection model.** Extend the multi-homing experiment so venue choice is conditional on partial outcomes/prices (not just ``M markets exist''), then derive a tighter repricing rule than $\log_2 M$ for realistic routing policies.
- **End-to-end exclusivity commitments.** Bind GGBC issuance to stake / identity (or SCITT issuer trust roots) and quantify how much ``budget-backed exclusivity'' reduces worst-case grinding under plausible Sybil models.

## v86.31 (2026-02-28)
- Added an exact threshold-optimization experiment for quorum sizing under WDD correlation budgets: `make_quorum_threshold_optimization_experiment.py`.
  - Emits a paper-ready comparison table `_insert_quorum_threshold_opt_table.tex`, a cost curve `pct_quorum_threshold_opt.pdf`, and replayable JSON `test_vectors/quorum_threshold_opt_results.json`.
- Key empirical takeaway (demo pool): holding $m$ fixed, raising the threshold $t$ can reduce dual-accept probability enough to increase $\rho_{\max}(m,t)$ and restore feasibility under the WDD rule, even though larger $t$ is stricter for liveness.
- Paper J/K: integrated the threshold-optimization result in the quorum sizing section.

## v86.29 (2026-02-28)
- Added a verifier-checkable "quorum sizing" design tool that searches over $(m,t)$ and witness sets to meet both (i) a split-view dual-accept risk budget $B_{\mathrm{dual}}{=}2^{-k}$ and (ii) a liveness target $\Pr[\#\ge t]\ge 1-\delta$, while enforcing the WDD-derived correlation bound. Artifacts: `make_quorum_sizing_solver_experiment.py`, `_insert_quorum_sizing_table.tex`, `pct_quorum_sizing_cost.pdf`, `pct_quorum_sizing_m.pdf`.
- Fixed an important feasibility edge case across budget/\(\rho\) inversion helpers: if the split-view budget is violated even at \(\rho=0\), the correct result is "infeasible" (not an extremely small \(\rho_{\max}\)).
- Paper J: added a new subsection "Quorum sizing as a verifier-checkable design tool" tying WDD budgets to deployable parameter selection and highlighting the operator-diversity feasibility frontier.
- Paper K: added a compact "Sizing tool" paragraph + table to connect the diversity story to a concrete solver.


## v86.25 (2026-02-28)
- Added an analytic (Beta--Binomial) correlation-sensitivity sweep for witness compromise: `make_witness_corr_sweep.py` now generates `_insert_witness_corr_sweep_table.tex` and `pct_witness_corr_sweep.pdf`.
- Paper J: added a new subsection emphasizing that even small common-mode correlation can erase the comfort of count-based witness thresholds; this complements the operator-level and real-pool experiments.
- Paper J + Paper K: migrated SCITT citations to `SCITTArchitectureDraft22`; references now include a dedicated bibitem key for the SCITT architecture draft-22.



## v86.24 (2026-02-28)
- Added multi-homing exposure calculation artifacts: generator + paper-ready table + plot.
- Paper J: new evaluation subsection quantifying hidden soundness bits from multi-homing; expanded standardization path with SCRAPI + SCITT receipts.
- Paper K: added multi-homing table and SCRAPI/receipts linkage.
- References: added SCITT receipts CCF profile draft and a stable Draft-22 key alias.
## v86.23 (2026-02-28)
- Added portability primitives to the flagship papers: cross-market bundle indices (CMBI) and cross-log staples (XLS), with new reproducible generators and paper-ready tables.
- New scripts: `make_cross_market_index_table.py`, `make_cross_log_staple_table.py`.
- Updated `paperJ` and `paperK` to incorporate cross-market multi-homing risk and log-migration cross-logging, plus refreshed transparency/log citations (Rekor v2 GA, Tessera, CT Pages).

## v86.22 (2026-02-28)
- Integrated an Option Surface Ledger (OSL) demo end-to-end: generator script (`make_osl_tax_table.py`) + paper-ready insert (`_insert_osl_tax_table.tex`).
- Strengthened the synthesis draft (`paperJ`) with a dedicated retry-amplification section (incl. beacon-waiting lemma) and added OSL as a first-class PCT artifact.
- Added a focused draft (`paperK`) to isolate and sharpen the “no free options” thesis for prover markets.
- Fixed LaTeX underscore issues in split-view insert tables; removed a duplicate CT-gossip reference; updated SCITT architecture draft reference.

## v86.21 (2026-02-28)
- Added a small, real-world witness pool snapshot assembled from Witness Network public tables and linked about pages (testing/staging/dev only; production table marked unavailable as of snapshot).
- Added an augmented stress-test experiment that replicates multiple instances per operator to show how correlated compromise can re-emerge as operators scale out (same snapshot, different topology).
- Immediate next steps:
  - Expand the snapshot to include additional public witness ecosystems (if/when production tables appear), and record operator/jurisdiction/infrastructure metadata in a structured ``diversity descriptor'' schema.
  - Replace illustrative compromise knobs with a measurement-backed proxy (e.g., key-management class, attested enclave vs soft key, jurisdictional diversity, independent uptime monitoring).
  - Integrate witness-set selection into PCT receipts as a verifiable policy (machine-checkable constraints + auditor replay).

## v86.20 (2026-02-28)
- Added correlated-compromise modeling for witness cosigning (operator-level compromise + residual independent compromise).
- New experiment + LaTeX insert: `tab:witness_diversity_risk` (shows how stronger quorums + risk-aware selection reduce dual-acceptance probability).
- New Paper I: diversity-aware witness-set selection as a portable policy knob for PCT deployments.

## v86.19 (2026-02-28)
- New Paper H: witness selection as a security parameter (quorum thresholds vs detection latency).
- New client-policy experiment: generates `tab:client_policy_refusal` and a CDF figure for time-to-refusal under hard-partition split views.

## v86.18 worklog (2026-02-28)
- Built and integrated a sparse-topology split-view experiment + toy client polling model for PCT.
- Next: calibrate the toy against a concrete witness topology (e.g., public witness network configs) and add a realistic client receipt-fetch cadence model.

# RESEARCH_NOTES.md (AI working notes)
**Snapshot:** v86.13-ai (2026-02-28)

This file is intentionally opinionated: it is a plan for turning the living spec into publishable papers, and for pushing the most novel threads as far as they will go.


## 0b. What I changed in this snapshot (v86.13)
- **Flagship direction:** Paper F now specifies a concrete PCT bundle (PCTB-v0) and a verifier, so the contribution is not purely conceptual.
- **Build artifacts:** added `pct_bundle_ref.py` (emit/verify), `docf_pct_bundle_v0.schema.json`, and `test_vectors/pct_bundle_demo.json`.
- **Selection receipt concreteness:** added `market_round_cert_ref.py` + demo.
- **Overhead is now measurable:** added `_insert_pct_end2end_demo_table.tex` generator.
- **Fresh research hooks:** added CT Pages draft + OpenSSF Sigstore dataset bibitems for scaling/measurement framing.

## 0. What I changed in this snapshot (v86.11)
- **Paper D (`paperD.tex`)**: made the governance/portfolio track more submission-shaped by adding (i) a toy $\varepsilon$-scoring simulation table, and (ii) explicit build artifacts with demo listings (Attempt DAG compiler; working e-value auditor).
- **New Paper E (`paperE.tex`)**: a compact systems/security framing: \emph{receipt completeness} for prover markets (selection receipts + attempt DAG commitments + $\varepsilon$-ledgers + transparency logs).
- **Built tools + demos:**
  - `attempt_dag_compiler_ref.py` (ATS-v1 \rightarrow ADC-v0) and demo vectors in `test_vectors/attempt_trace_demo_v1.json`, `test_vectors/attempt_dag_demo.json`.
  - Implemented `anytime_e_audit_ref.py` (betting-style e-process for latency exceedance) and demo vectors in `test_vectors/perf_stream_demo.json`, `test_vectors/perf_envelope_demo.json`.
  - `make_eps_scoring_sim_table.py` to regenerate `_insert_eps_scoring_sim_table.tex` deterministically.

## 1. Narrative identity decisions
The living spec is trying to be both crypto and systems. The clean split is:

- **Paper A (crypto / CCS-CRYPTO-style):** retries/aborts as a cryptographic object; cancellation bounds; boundary filtration; RPC locking repair; TORR mechanization hook.
- **Paper B (systems / S&P-CCS-style):** portability contracts + fail-closed resolver semantics; PABOM/TPV/gates; threat catalog + conformance harness; market evidence profiles.
- **Paper C (artifact + gate paper):** Security Nutrition Labels (SNLs) as portable acceptance objects, plus stapling (CT/Sigsum/consistency/gossip) and gate policy semantics.
- **Paper D (governance / FC-style or systems-econ):** portfolio risk budgets: $\eps$-scoring auctions, $\eps$-ledgers, and anytime-valid performance envelopes.
- **Living spec (`paper.tex`):** the full schema suite, proofs, test vectors, and reference tools.

## 2. The two sharpest “take risks” claims
### Claim A: Retries are a cryptographic object
Every abort channel (waiting, re-auction, cancellation, internal resampling) must be either:
- **counted** (receipt-complete attempt counting),
- **repriced** (conditioning / min-entropy loss), or
- **failed closed** (no amplification claimed).

Paper A makes this formal with boundary tags and evidenced stopping-time caps.

### Claim B: Governance is portfolio risk accounting, not per-proof checking
Even if each individual proof looks “secure”, the system can be insecure if the market makes $R \gg 1$ attempts cheap and invisible.
Paper D’s perspective is that a proof supply chain needs the equivalent of a budget ledger:
- each accepted proof produces a resolver-grade $\eps$ debit tied to evidence,
- governance chooses bids using $\eps$-scores (Lagrangian relaxation),
- an append-only $\eps$-ledger checkpoint makes budget consumption monitorable and auditable.

## 3. Next tightening steps (high leverage)
### Paper D (portfolio / governance)
1. **Make the ledger semantics sharper than a union bound.**
   - When do two proofs share the same retry/option surface (so we should not double-charge)?
   - Define “overlap-aware” composition rules that stay conservative but reduce pessimism.
2. **Concrete market case study (one only).**
   - A strict-deadline market (Boundless/Succinct-style) where cancellations + re-auctions create a hidden attempt multiplier unless receipts are mandatory.
   - Show a before/after: (i) unverifiable retry policy ⇒ fail-closed $\eps$ downgrade; (ii) receipts ⇒ ledger debit stays tight.
3. **Anytime-valid performance envelopes that bind to attempt IDs.**
   - Define a minimal “performance envelope certificate” schema that commits to a metric stream and e-process rule, and binds to the same session ids as the soundness receipts.

### Paper C (SNLs / transparency)
- Clarify the line between **monitor-only** evidence (gossip/accumulators) vs. **reuse-grade** evidence (witness quorum + consistency).

### Paper A (crypto)
- Polish the “locking” story: exactly which amplification claims collapse without RPC under realistic retry cuts.

## 4. Repo hygiene / archive plan
Each snapshot should ship (at minimum):
- `paper.tex` (living spec)
- `paperA.tex`, `paperB.tex`, `paperC.tex`, `paperD.tex` (paper tracks)
- `RESEARCH_NOTES.md` (this file)
- `ARCHIVE.md` + `CHANGELOG.md` updated

We will keep producing `docf_evolving_docs_*.zip` artifacts so we can always roll back.



## v86.10 worklog (2026-02-28)
- Paper D: rewrote around three checkable primitives: (1) eps-scoring auctions as Lagrangian score, (2) receipt-complete attempt DAGs, (3) eps-ledgers as epoch governance artifacts, plus e-value based performance envelopes.
- Paper A: replaced manual cancellation sizing with autogenerated table; added explicit beacon-waiting option lemma and embedded bias/grinding tables to make the conditioning tax concrete.
- Tooling: added `eps_ledger_ref.py` (schema validation + expression parsing + portfolio bound) and a numeric demo ledger vector.

### Next research risks to take
1. Mechanism design: characterize incentive compatibility for security-tagged bids when eps(b) is resolver-computed from evidence receipts (strategic evidence withholding, collusion, and ``free'' retries).
2. Ledger composition: develop a practical overlap-aware bound (seed groups / option surfaces) with crisp assumptions and a cheap verifier.
3. Performance certificates: pick 1–2 concrete e-process families (e.g., betting martingales for deadline-miss rates) and ship a full end-to-end demo bundle.


## v86.16 worklog (2026-02-28)
- Paper F: added a concrete evaluation section with microbenchmarks for PCT verification primitives and end-to-end bundle emit+verify (Python reference implementations).
- Paper F/G: strengthened split-view discussion with additional CT literature (aggregation-based gossip, LogPicker) and a sharper quorum-intersection lemma for witness thresholds.
- Tooling: added `make_pct_bench_tables.py` to generate `test_vectors/pct_bench_results.json` and LaTeX inserts (`_insert_pct_bench_table.tex`, `_insert_pct_bundle_bench_table.tex`).
- Notes: updated `PCT_NOTES.md` to track the measurement progress and next distributional experiments.



## v86.17 (2026-02-28)
- Added a partition split-view detection-latency experiment with auto-generated LaTeX + CDFs; integrated into Paper F (PCT) and Paper G (witnessing).


## v86.26 (2026-02-28)
- Added a witness-policy primitive: **Witness Diversity Descriptor (WDD)** + a verifier-computable correlation bound.
  - New generator `make_wdd_policy_demo.py` emits: (i) diversity metrics table, (ii) correlation-budget table, (iii) budget curve.
  - Paper J: new subsection "WDD and policy-computable bounds" makes diversity enforceable without hard-coded witness sets.
  - Paper K: compact WDD summary (interoperability-facing).

### Immediate next risks
1. **Schema + signing:** add an explicit WDD object type to the PCT bundle schema (with canonicalization, signer roles, and an auditor signature option).
2. **Selection algorithm:** given a candidate pool + a verifier budget (q, B_dual), construct a witness set that minimizes $\hat\rho$ while keeping availability targets (avoid unanimity).
3. **Adversarial descriptors:** model a malicious issuer who mislabels domains; design cross-checks (e.g., attestations, reproducible evidence, and challengeable claims).
4. **Beyond ICC:** extend from a scalar $\rho$ to a small correlation matrix or a "few-mode" mixture (operator-level + infra-level) while keeping verifier code tiny.


## v86.27 (2026-02-28)
- **PCTB-v2 (policy-carrying bundle):** extended the end-to-end PCT bundle to include a signed/digested **Witness Diversity Descriptor (WDD)** and a verifier-checkable **correlation-budget policy**.
  - New schema stubs: `docf_witness_diversity_descriptor_v0.schema.json`, `docf_pct_bundle_v2.schema.json`.
  - New reference tool: `witness_diversity_descriptor_ref.py` (emit/verify WDD; deterministic digest).
  - Updated `pct_bundle_ref.py` to emit/verify both v1 and v2 bundles. v2 logs the WDD + policy as additional Merkle leaves and binds their digests in the Market Session Certificate.
  - New demo vector: `test_vectors/pct_bundle_demo_v2.json`.
- **Evaluation glue:** added `make_pct_end2end_demo_table_v2.py` producing `_insert_pct_end2end_demo_table_v2.tex` (end-to-end size accounting including WDD + policy).
- **Witness-set construction (toy):** added `witness_set_optimizer_ref.py` (greedy min-max $\hat\rho$) and `make_witness_set_selection_table.py` generating `_insert_witness_set_selection_table.tex` to connect correlation budgets to explicit witness selection.
- **Paper J:** updated to treat PCTB-v1 as the minimal subset and PCTB-v2 as the policy-carrying bundle; switched the end-to-end size table to the v2 demo.

### Next risks (still open)
1. **Witness-set construction:** given a candidate pool + verifier budget, solve the combinatorial witness-set selection problem (availability constraints + diversity minimization) and ship an optimizer + ablations.
2. **Descriptor adversaries:** make WDD claims challengeable (operator/infra attestations, reproducible label evidence, and dispute workflows).
3. **Cross-log / cross-market interaction:** couple CMBIs with correlation budgets to produce a single ecosystem-level split-view budget across markets + logs.

## v86.28 (2026-02-28)
- **Feasibility as a first-class outcome:** added an *exact* witness-set feasibility + cost experiment under WDD policies.
  - `make_witness_policy_feasibility_experiment.py` brute-forces all \(\binom{20}{7}\) sets to find the minimum-cost feasible witness set under a correlation budget and a 99.9\% liveness target.
  - Key observation: if the witness ecosystem has only **5 operators**, then for \(m=7\) the WDD proxy forces \(\hat\rho_{\mathrm{operator}}\ge 4/42\approx 0.095\); budgets requiring \(\rho_{\max}<0.095\) are infeasible unless more operators join.
- **Implied operator requirements:** added `make_operator_diversity_requirements.py` to compute the minimum number of distinct buckets needed as a function of \(k\) (turning "diversity" into an explicit admission requirement).
- **Paper J/K integration:** both drafts now include the feasibility/cost framing and the operator-bucket requirement table.

### Next risks
1. **Sizing solver (m,t):** extend feasibility into a solver that proposes \((m,t)\) and required bucket counts under multiple domains (operator, provider, jurisdiction), including availability constraints.
2. **Adversarial labeling:** add a disputable evidence layer for WDD tags (e.g., signed operator attestations; infra proofs), and model the effect of mislabeling on \(\hat\rho\) and budgets.
3. **Empirical correlation:** replace the scalar ICC with a "few-mode" mixture (operator + provider + shared library) fitted from observed incident co-failures; keep verifier computation tiny.


## v86.30 (2026-02-28)
- **Quorum sizing tradeoff surface:** added `make_quorum_pareto_frontier_experiment.py` to surface a deployment-friendly cost vs redundancy curve under split-view budgets.
  - Uses a fixed threshold policy $t(m)=\max(\lfloor m/2\rfloor{+}1,\lceil 0.7m\rceil)$ and finds the cheapest feasible witness set for each $m$.
  - Emits paper-ready inserts + figures: `_insert_quorum_pareto_frontier_table.tex`, `pct_quorum_pareto_frontier.pdf`.
- **Policy relaxation knob (risk-taking):** introduced an auditable alternative to the conservative WDD proxy aggregation, allowing a domain-weighted correlation scalar $\hat\rho_w=\sum_d w_d\hat\rho_d$.
  - Demo comparison artifacts: `_insert_quorum_agg_comparison_table.tex`, `pct_quorum_agg_comparison.pdf`.
- **Paper J/K integration:** both drafts now include the tradeoff-surface view and a short discussion of max vs weighted aggregation.

### Next risks to take
1. **Full Pareto frontier (exact):** remove the fixed-threshold shortcut and compute the true non-dominated set over $(m,t,\mathrm{cost})$ with pruning/branch-and-bound or MILP.
2. **Weighted domains with evidence:** define how weights are derived from incident data (and how auditors challenge them), so weighted aggregation is not a hand-wavy knob.
3. **Few-mode mixtures:** upgrade from a single scalar to a 2--3 mode correlation model (operator + provider + shared library), keeping verifier compute \(\tilde O(m)\).
