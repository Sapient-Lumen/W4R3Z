#!/usr/bin/env python3
"""
soundness_budget_ref.py

Reference tool for computing conservative retry-amplified soundness bounds in dOCF.

It implements Lemma "Common-mode + per-attempt amplification":

  eps_total <= eps_cm + (1-(1-eps_ind)^Q) <= eps_cm + Q*eps_ind.

This tool is intentionally small and deterministic; it is meant for interoperability
testing (schemas + demo vectors), not for production cryptography.

Usage:
  ./soundness_budget_ref.py compute <input.json>
  ./soundness_budget_ref.py verify <input.json>

Output is a JSON object matching docf-soundness-budget-v0, with the "computed"
fields filled in and a canonical choice of model string.

Copyright:
  This reference artifact is provided as-is for the dOCF paper archive.
"""
from __future__ import annotations

import json
import math
import sys
from typing import Any, Dict


MODEL_EXACT = "eps_total <= eps_common_mode + 1-(1-eps_per_attempt)^Q"
MODEL_LIN   = "eps_total <= eps_common_mode + Q*eps_per_attempt"


def _eps_total(eps_cm: float, eps_ind: float, Q: int) -> float:
    # Exact Bernoulli union bound under conditional independence.
    # Clamp to [0,1] for numeric hygiene.
    if Q <= 0:
        return min(1.0, max(0.0, eps_cm))
    if eps_ind <= 0.0:
        return min(1.0, max(0.0, eps_cm))
    # 1 - (1 - eps_ind)^Q can lose precision if eps_ind is tiny;
    # use log1p for stability.
    one_minus = 1.0 - eps_ind
    if one_minus <= 0.0:
        per = 1.0
    else:
        per = 1.0 - math.exp(Q * math.log(one_minus))
    return min(1.0, max(0.0, eps_cm + per))


def _security_bits(eps: float) -> float:
    if eps <= 0.0:
        return float("inf")
    return -math.log(eps, 2)


def compute(obj: Dict[str, Any]) -> Dict[str, Any]:
    Q = int(obj["Q"])
    eps_cm = float(obj["eps_common_mode"])
    eps_ind = float(obj["eps_per_attempt"])
    eps_total = _eps_total(eps_cm, eps_ind, Q)
    bits = _security_bits(eps_total)
    out = dict(obj)
    out["type"] = "docf-soundness-budget-v0"
    out["version"] = "0"
    out["model"] = MODEL_EXACT
    out["computed"] = {
        "eps_total_bound": eps_total,
        "security_bits_bound": bits,
    }
    return out


def verify(obj: Dict[str, Any]) -> None:
    out = compute(obj)
    got = obj.get("computed", {})
    want = out["computed"]
    eps_ok = abs(float(got.get("eps_total_bound", -1.0)) - want["eps_total_bound"]) <= 1e-18
    bits_ok = abs(float(got.get("security_bits_bound", -1.0)) - want["security_bits_bound"]) <= 1e-9
    model_ok = obj.get("model") in (MODEL_EXACT, MODEL_LIN)
    if not (eps_ok and bits_ok and model_ok):
        raise SystemExit(
            "verify failed: computed fields mismatch or model string invalid\n"
            f"  model_ok={model_ok} eps_ok={eps_ok} bits_ok={bits_ok}\n"
            f"  want={want}\n  got={got}\n"
        )


def main(argv: list[str]) -> None:
    if len(argv) < 3 or argv[1] not in ("compute", "verify"):
        print("Usage: soundness_budget_ref.py compute|verify <input.json>", file=sys.stderr)
        raise SystemExit(2)
    cmd, path = argv[1], argv[2]
    with open(path, "r", encoding="utf-8") as f:
        obj = json.load(f)
    if cmd == "verify":
        verify(obj)
        print("OK")
        return
    out = compute(obj)
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == "__main__":
    main(sys.argv)
