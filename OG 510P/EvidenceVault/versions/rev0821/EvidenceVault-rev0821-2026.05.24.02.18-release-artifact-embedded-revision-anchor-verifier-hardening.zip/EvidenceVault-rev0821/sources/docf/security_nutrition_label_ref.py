#!/usr/bin/env python3
"""security_nutrition_label_ref.py

Reference compiler for a Security Nutrition Label (SNL).

An SNL is an auditor output object intended for caching and policy gates:
it summarizes per-obligation resolved eps/bits for a given volume window,
derived from a Typed Option Repricing Report (TORR) and optionally adjusted
by a Grinding Gap Certificate (GGC) for unobservable micro-retries.

Conservative semantics:
  - Any obligation with missing evidence => status=fail_closed.
  - If a GGC is provided with parameters (m_max, eps_gap),
      adjusted_eps = min(1, m_max * resolved_eps + eps_gap).

This script is reference-grade: deterministic outputs, not a production verifier.

Usage:
  python3 security_nutrition_label_ref.py --torr <torr.json> [--ggc <ggc.json>] --out <snl.json>
  python3 security_nutrition_label_ref.py --emit-demo
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import math
import os
from typing import Any, Dict, Optional, Tuple

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

from docf_ref_tools_common import jcs, load_json


def sha256_pref(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def digest_obj_unsigned(obj: Dict[str, Any]) -> str:
    tmp = dict(obj)
    tmp.pop("digest", None)
    tmp.pop("sig", None)
    return sha256_pref(jcs(tmp))


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _sign_ed25519(priv_bytes: bytes, msg: bytes) -> Tuple[bytes, bytes]:
    priv = Ed25519PrivateKey.from_private_bytes(priv_bytes)
    pub = priv.public_key()
    pub_raw = pub.public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    sig = priv.sign(msg)
    return pub_raw, sig


def compile_snl(torr: Dict[str, Any], ggc: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    m_max = None
    eps_gap = 0.0
    if ggc is not None:
        m_max = int(ggc.get("m_max", 1))
        eps_gap = float(ggc.get("eps_gap", 0.0))

    ob_out = []
    any_fail = False
    eps_total = 0.0

    for o in torr.get("obligations", []):
        oid = o.get("obligation_id", "unknown")
        eps0 = o.get("eps_one_shot", "")
        sens = list(o.get("sensitivity", []))
        resolved = o.get("resolved", {}) or {}
        status = resolved.get("status", "fail_closed")
        if status != "ok":
            any_fail = True
            ob_out.append({
                "obligation_id": oid,
                "status": "fail_closed",
                "eps_one_shot": eps0,
                "sensitivity": sens,
                "notes": resolved.get("notes", "Missing evidence.")
            })
            continue

        eps_r = float(resolved.get("resolved_eps", 1.0))
        bits_r = float(resolved.get("resolved_security_bits", 0.0))

        if m_max is not None:
            eps_adj = min(1.0, float(m_max) * eps_r + eps_gap)
            bits_adj = (-math.log2(eps_adj) if eps_adj > 0 else float("inf"))
        else:
            eps_adj = eps_r
            bits_adj = bits_r

        eps_total += eps_adj

        ob_out.append({
            "obligation_id": oid,
            "status": "ok",
            "eps_one_shot": eps0,
            "sensitivity": sens,
            "resolved_eps": eps_r,
            "resolved_security_bits": bits_r,
            "ggc_adjusted_eps": eps_adj,
            "ggc_adjusted_security_bits": bits_adj,
            "notes": "GGC-adjusted" if m_max is not None else "No GGC"
        })

    overall = {
        "status": "fail_closed" if any_fail else "ok",
        "notes": "Fail-closed: at least one obligation missing evidence." if any_fail else "All obligations resolved."
    }
    if not any_fail:
        eps_total = min(1.0, eps_total)
        overall["eps_total"] = eps_total
        overall["security_bits_total"] = (-math.log2(eps_total) if eps_total > 0 else float("inf"))

    inputs = {
        "torr_digest": sha256_pref(jcs(torr)),
        "torr_path": torr.get("_path", ""),
        "manifest_digest": torr.get("manifest_digest", ""),
        "osl_digest": torr.get("osl_digest", ""),
    }
    if ggc is not None:
        inputs["ggc_digest"] = ggc.get("digest", sha256_pref(jcs(ggc)))
        binds = ggc.get("binds", {}) or {}
        if "policy_nf_digest" in binds:
            inputs["policy_nf_digest"] = binds["policy_nf_digest"]
        if "resolver_id" in binds:
            inputs["resolver_id"] = binds["resolver_id"]

    out = {
        "type": "docf-security-nutrition-label-v1",
        "version": "1",
        "created_at": "2026-02-27T00:00:00Z",
        "validity": {
            "not_before": "2026-02-27T00:00:00Z",
            "not_after": "2026-03-06T00:00:00Z"
        },
        "inputs": inputs,
        "window": {
            "label": "demo-window",
            "volume_N": int(torr.get("volume_N", 0)),
        },
        "overall": overall,
        "obligations": ob_out,
        "notes": "Reference SNL derived from TORR; optional GGC scaling for micro-retries."
    }

    # Deterministic demo signing key (DO NOT USE IN PRODUCTION).
    # We attach issuer metadata first so the digest binds the claimed verification key.
    priv = bytes.fromhex("77" * 32)
    pub_raw, _ = _sign_ed25519(priv, b"")
    out["issuer"] = {
        "alg": "ed25519",
        "keyid": "snl-demo-0",
        "public_key_ed25519_raw_b64": _b64(pub_raw),
    }

    out["digest"] = digest_obj_unsigned(out)
    _, sig = _sign_ed25519(priv, out["digest"].encode("utf-8"))
    out["sig"] = _b64(sig)

    return out


def emit_demo() -> None:
    tv = os.path.join(os.path.dirname(__file__), "test_vectors")
    os.makedirs(tv, exist_ok=True)

    ggc = load_json(os.path.join(tv, "grinding_gap_certificate_demo.json"))

    # Fail-closed demo (missing evidence in TORR)
    torr_fail = load_json(os.path.join(tv, "typed_option_repricing_report_demo.json"))
    torr_fail["_path"] = "test_vectors/typed_option_repricing_report_demo.json"
    out_fail = compile_snl(torr_fail, ggc)
    path_fail = os.path.join(tv, "security_nutrition_label_demo.json")
    with open(path_fail, "w", encoding="utf-8") as f:
        json.dump(out_fail, f, indent=2, ensure_ascii=False, sort_keys=False)
        f.write("\n")

    # All-resolved demo
    torr_ok = load_json(os.path.join(tv, "typed_option_repricing_report_demo_ok.json"))
    torr_ok["_path"] = "test_vectors/typed_option_repricing_report_demo_ok.json"
    out_ok = compile_snl(torr_ok, ggc)
    path_ok = os.path.join(tv, "security_nutrition_label_demo_ok.json")
    with open(path_ok, "w", encoding="utf-8") as f:
        json.dump(out_ok, f, indent=2, ensure_ascii=False, sort_keys=False)
        f.write("\n")

    print(f"Wrote {os.path.basename(path_fail)} and {os.path.basename(path_ok)} under test_vectors/")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--torr", help="Path to typed_option_repricing_report JSON")
    ap.add_argument("--ggc", help="Optional path to grinding_gap_certificate JSON")
    ap.add_argument("--out", help="Output path for SNL JSON")
    ap.add_argument("--emit-demo", action="store_true", help="Write demo vector into test_vectors/")
    args = ap.parse_args()

    if args.emit_demo:
        emit_demo()
        return

    if not args.torr or not args.out:
        raise SystemExit("Provide --torr and --out (or use --emit-demo).")

    torr = load_json(args.torr)
    torr["_path"] = args.torr
    ggc = load_json(args.ggc) if args.ggc else None

    out = compile_snl(torr, ggc)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False, sort_keys=False)
        f.write("\n")


if __name__ == "__main__":
    main()
