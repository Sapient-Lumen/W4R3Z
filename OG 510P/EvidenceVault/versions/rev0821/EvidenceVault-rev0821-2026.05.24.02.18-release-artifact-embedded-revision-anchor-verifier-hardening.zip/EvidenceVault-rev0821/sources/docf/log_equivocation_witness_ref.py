#!/usr/bin/env python3
"""log_equivocation_witness_ref.py

Reference verifier for `docf-log-equivocation-witness-v0`.

Checks that:
  * both checkpoints verify under the same Ed25519 key,
  * both checkpoints claim the same tree_size,
  * the root hashes differ (equivocation),
  * and (if present) the equivocation_id matches a deterministic digest.

This is reference-grade code for paper examples; it is not hardened.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
from typing import Any, Dict

from docf_ref_tools_common import jcs, emit_json, load_json

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature


def b64d(s: str) -> bytes:
    return base64.b64decode(s.encode("utf-8"))


def verify_sth_signature(checkpoint: Dict[str, Any]) -> bool:
    msg_obj = {
        "format": checkpoint["format"],
        "log_id": checkpoint.get("log_id", ""),
        "tree_size": checkpoint["tree_size"],
        "root_hash_sha256_b64": checkpoint["root_hash_sha256_b64"],
        "issued_at": checkpoint["issued_at"],
    }
    msg_bytes = jcs(msg_obj)
    pub_raw = b64d(checkpoint["log_public_key_ed25519_raw_b64"])
    sig = b64d(checkpoint["log_signature_ed25519_b64"])
    pub = Ed25519PublicKey.from_public_bytes(pub_raw)
    try:
        pub.verify(sig, msg_bytes)
        return True
    except InvalidSignature:
        return False


def equivocation_id(checkpoint_a: Dict[str, Any], checkpoint_b: Dict[str, Any]) -> str:
    # Deterministic digest of the pair (order-sensitive).
    pair = {"a": checkpoint_a, "b": checkpoint_b}
    return hashlib.sha256(jcs(pair)).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("witness_json", help="Path to log_equivocation_witness_demo.json (or compatible)")
    args = ap.parse_args()

    w = load_json(args.witness_json)
    a = w["checkpoint_a"]
    b = w["checkpoint_b"]

    ok_a = verify_sth_signature(a)
    ok_b = verify_sth_signature(b)

    same_key = a["log_public_key_ed25519_raw_b64"] == b["log_public_key_ed25519_raw_b64"]
    same_size = int(a["tree_size"]) == int(b["tree_size"])
    root_diff = a["root_hash_sha256_b64"] != b["root_hash_sha256_b64"]

    did = equivocation_id(a, b)
    ok_id = True
    if "equivocation_id_sha256_hex" in w:
        ok_id = (w["equivocation_id_sha256_hex"] == did)

    out = {
        "ok_signature_a": ok_a,
        "ok_signature_b": ok_b,
        "same_key": same_key,
        "same_tree_size": same_size,
        "root_diff": root_diff,
        "equivocation_id_sha256_hex": did,
        "ok_equivocation_id": ok_id,
        "is_equivocation": ok_a and ok_b and same_key and same_size and root_diff,
    }
    emit_json(out)


if __name__ == "__main__":
    main()
