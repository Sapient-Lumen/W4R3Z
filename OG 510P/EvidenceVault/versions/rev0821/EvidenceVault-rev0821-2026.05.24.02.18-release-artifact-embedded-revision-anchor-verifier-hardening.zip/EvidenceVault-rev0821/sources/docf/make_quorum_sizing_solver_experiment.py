#!/usr/bin/env python3
"""make_quorum_sizing_solver_experiment.py

Risk-budget driven quorum sizing for PCT witness verification.

This script turns the paper's policy story into a design tool:

Given:
  - split-view dual-accept risk budget B_dual = 2^{-k}
  - marginal per-witness compromise rate q
  - availability target 1 - delta
  - a witness candidate pool with costs, uptimes, and WDD risk-domain tags

It chooses (m, t) and a minimum-cost witness set S of size m such that:
  (1) WDD-derived clustering bound \hat\rho(S) <= \rho_max(m,t,q,B_dual)
  (2) P[#available >= t] >= 1 - delta

\rho_max is computed using the same exchangeable Beta--Binomial ICC model as the
correlation sensitivity section, by inverting the dual-accept probability.

Outputs:
  - test_vectors/quorum_sizing_results.json
  - _insert_quorum_sizing_table.tex
  - pct_quorum_sizing_cost.pdf
  - pct_quorum_sizing_m.pdf

Notes:
  - This is exact brute force over \binom{n}{m} combinations for each m.
    With n=20 and m<=12, the search is tractable.
  - Objective is lexicographic: minimize m, then minimize cost.

"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path
from typing import Any, Dict, List, Tuple


def _rho(labels: List[str]) -> float:
    m = len(labels)
    if m <= 1:
        return 0.0
    counts: Dict[str, int] = {}
    for x in labels:
        counts[x] = counts.get(x, 0) + 1
    num = sum(v * (v - 1) for v in counts.values())
    return num / (m * (m - 1))


def rho_hat_for_set(ws: List[Dict[str, Any]], domains: List[str]) -> Tuple[float, Dict[str, float]]:
    by: Dict[str, float] = {}
    for d in domains:
        labels = [str(w.get(d) or w.get('id')) for w in ws]
        by[d] = _rho(labels)
    rh = max(by.values()) if by else 0.0
    return rh, by


def poisson_binom_dist(ps: List[float]) -> List[float]:
    """Distribution of independent Bernoulli(p_i) sum."""
    m = len(ps)
    dp = [0.0] * (m + 1)
    dp[0] = 1.0
    for p in ps:
        nxt = [0.0] * (m + 1)
        for j in range(0, m + 1):
            if dp[j] == 0.0:
                continue
            nxt[j] += dp[j] * (1 - p)
            if j + 1 <= m:
                nxt[j + 1] += dp[j] * p
        dp = nxt
    return dp


def tail_from_dist(dp: List[float], t: int) -> float:
    return float(sum(dp[t:]))


def log_beta(a: float, b: float) -> float:
    return math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)


def beta_binom_pmf(m: int, k: int, alpha: float, beta: float) -> float:
    return math.comb(m, k) * math.exp(log_beta(alpha + k, beta + m - k) - log_beta(alpha, beta))


def hypergeom_pmf(N: int, K: int, n: int, k: int) -> float:
    if k < 0 or k > n or k > K or (n - k) > (N - K):
        return 0.0
    return (math.comb(K, k) * math.comb(N - K, n - k)) / math.comb(N, n)


def dual_accept_prob_given_K(m: int, t: int, g: int, K: int) -> float:
    lo = max(0, t - (m - g))
    hi = min(g, K + g - t)
    if lo > hi:
        return 0.0
    return sum(hypergeom_pmf(m, K, g, kA) for kA in range(lo, hi + 1))


def compute_dual_accept(m: int, t: int, q: float, rho: float) -> float:
    g = m // 2

    if rho <= 0.0:
        pD = 0.0
        for K in range(0, m + 1):
            pK = math.comb(m, K) * (q ** K) * ((1 - q) ** (m - K))
            pD += pK * dual_accept_prob_given_K(m, t, g, K)
        return pD

    s = (1.0 / rho) - 1.0
    alpha = max(1e-12, q * s)
    beta = max(1e-12, (1.0 - q) * s)

    pD = 0.0
    for K in range(0, m + 1):
        pK = beta_binom_pmf(m, K, alpha, beta)
        pD += pK * dual_accept_prob_given_K(m, t, g, K)
    return pD


def max_rho_for_budget(m: int, t: int, q: float, budget_dual: float) -> float | None:
    # If even rho=0 exceeds budget, no correlation level can satisfy this budget.
    if compute_dual_accept(m, t, q, 0.0) > budget_dual:
        return None

    lo, hi = 0.0, 0.999
    for _ in range(70):
        mid = (lo + hi) / 2
        pD = compute_dual_accept(m, t, q, mid)
        if pD <= budget_dual:
            lo = mid
        else:
            hi = mid
    return lo


def enumerate_sets(pool: List[Dict[str, Any]], m: int, domains: List[str]):
    """Enumerate all m-sets with precomputed (cost, rho_hat, dp_dist, ids)."""
    out = []
    for comb in itertools.combinations(pool, m):
        ws = list(comb)
        rh, by = rho_hat_for_set(ws, domains)
        ps = [float(w.get('uptime', 1.0)) for w in ws]
        dp = poisson_binom_dist(ps)
        cost = sum(float(w.get('monthly_cost_usd', 0.0)) for w in ws)
        out.append((cost, rh, by, dp, [w['id'] for w in ws]))
    out.sort(key=lambda x: x[0])
    return out


def choose_for_params(
    combos: List[Tuple[float, float, Dict[str, float], List[float], List[str]]],
    t: int,
    rho_max: float,
    delta: float,
):
    """Return first (cheapest) combo satisfying rho and liveness."""
    target = 1.0 - delta
    for cost, rh, by, dp, ids in combos:
        if rh > rho_max + 1e-12:
            continue
        p_live = tail_from_dist(dp, t)
        if p_live + 1e-15 < target:
            continue
        return {
            'selected_witness_ids': ids,
            'rho_hat': float(f"{rh:.6g}"),
            'rho_by_domain': {k: float(f"{v:.6g}") for k, v in by.items()},
            'monthly_cost_usd': float(f"{cost:.6g}"),
            'p_live': float(f"{p_live:.6g}"),
        }
    return None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--pool', default='test_vectors/witness_candidate_pool_demo_v2.json')
    ap.add_argument('--q', type=float, default=0.12)
    ap.add_argument('--delta', type=float, default=1e-3)
    ap.add_argument('--domains', default='operator,provider,impl_family,kms_class')
    ap.add_argument('--budgets_bits', default='6,8,10,12')
    ap.add_argument('--m_min', type=int, default=5)
    ap.add_argument('--m_max', type=int, default=12)
    ap.add_argument('--t_min_frac', type=float, default=0.7)
    ap.add_argument('--out_json', default='test_vectors/quorum_sizing_results.json')
    ap.add_argument('--out_tex', default='_insert_quorum_sizing_table.tex')
    ap.add_argument('--out_cost_fig', default='pct_quorum_sizing_cost.pdf')
    ap.add_argument('--out_m_fig', default='pct_quorum_sizing_m.pdf')
    args = ap.parse_args()

    domains = [x.strip() for x in args.domains.split(',') if x.strip()]
    ks = [int(x.strip()) for x in args.budgets_bits.split(',') if x.strip()]

    pool_obj = json.loads(Path(args.pool).read_text(encoding='utf-8'))
    pool = pool_obj.get('witnesses', [])

    results = []

    # Precompute combos by m once.
    combos_by_m = {}
    for m in range(args.m_min, args.m_max + 1):
        combos_by_m[m] = enumerate_sets(pool, m, domains)

    for k in ks:
        B = 2.0 ** (-k)
        chosen = None
        chosen_mt = None

        for m in range(args.m_min, args.m_max + 1):
            t_lo = max((m // 2) + 1, int(math.ceil(args.t_min_frac * m)))
            best_for_m = None
            best_for_m_mt = None

            for t in range(t_lo, m + 1):
                rho_max = max_rho_for_budget(m, t, args.q, B)
                if rho_max is None:
                    continue
                cand = choose_for_params(combos_by_m[m], t, rho_max, args.delta)
                if not cand:
                    continue
                # objective for fixed m: minimize cost then maximize p_live.
                key = (cand['monthly_cost_usd'], -cand['p_live'], cand['rho_hat'])
                if best_for_m is None or key < best_for_m['key']:
                    best_for_m = {'key': key, 'rho_max': rho_max, 't': t, 'm': m, 'cand': cand}
                    best_for_m_mt = (m, t)

            if best_for_m:
                chosen = best_for_m
                chosen_mt = best_for_m_mt
                break  # minimal m found

        row = {
            'k': k,
            'B_dual': B,
            'q': args.q,
            'delta': args.delta,
        }

        if not chosen:
            row.update({'feasible': False})
        else:
            m, t = chosen_mt
            row.update({
                'feasible': True,
                'm': m,
                't': t,
                'rho_max': float(f"{chosen['rho_max']:.6g}"),
            })
            row.update(chosen['cand'])

        results.append(row)

    out = {
        'type': 'docf_quorum_sizing_results_v0',
        'params': {
            'pool': args.pool,
            'domains': domains,
            'q': args.q,
            'delta': args.delta,
            'm_range': [args.m_min, args.m_max],
            't_min_frac': args.t_min_frac,
        },
        'results': results,
    }

    Path(args.out_json).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out_json).write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding='utf-8')

    # LaTeX table (paper-ready insert). Emit single backslashes for commands.
    tex = []
    tex.append(r'\begin{tabular}{r r r r r r}')
    tex.append(r'\toprule')
    tex.append(r'$k$ & $(m,t)$ & $\rho_{\max}$ & $\hat\rho$ & cost & $P[\#\ge t]$ \\')
    tex.append(r'\midrule')

    for r in results:
        if not r.get('feasible'):
            tex.append(f"{r['k']} & -- & -- & -- & -- & infeasible \\\\")
            continue
        tex.append(
            f"{r['k']} & ({r['m']},{r['t']}) & {r['rho_max']:.4g} & {r['rho_hat']:.4g} & {r['monthly_cost_usd']:.0f} & {r['p_live']:.4g} \\\\")

    tex.append(r'\bottomrule')
    tex.append(r'\end{tabular}')
    Path(args.out_tex).write_text('\n'.join(tex) + '\n', encoding='utf-8')

    # Figures
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt

        ks_plot = [r['k'] for r in results if r.get('feasible')]
        costs = [r['monthly_cost_usd'] for r in results if r.get('feasible')]
        ms = [r['m'] for r in results if r.get('feasible')]

        plt.figure()
        if ks_plot:
            plt.plot(ks_plot, costs, marker='o')
        plt.xlabel('Budget bits k (B_dual = 2^{-k})')
        plt.ylabel('Minimum monthly cost (USD)')
        plt.title('Cheapest feasible quorum as budgets tighten')
        plt.tight_layout()
        plt.savefig(args.out_cost_fig)
        plt.close()

        plt.figure()
        if ks_plot:
            plt.plot(ks_plot, ms, marker='o')
        plt.xlabel('Budget bits k (B_dual = 2^{-k})')
        plt.ylabel('Minimum witness count m')
        plt.title('Witness count required for feasibility')
        plt.tight_layout()
        plt.savefig(args.out_m_fig)
        plt.close()

    except Exception as e:
        Path(args.out_cost_fig).write_text('figure generation failed: ' + str(e), encoding='utf-8')
        Path(args.out_m_fig).write_text('figure generation failed: ' + str(e), encoding='utf-8')


if __name__ == '__main__':
    main()
