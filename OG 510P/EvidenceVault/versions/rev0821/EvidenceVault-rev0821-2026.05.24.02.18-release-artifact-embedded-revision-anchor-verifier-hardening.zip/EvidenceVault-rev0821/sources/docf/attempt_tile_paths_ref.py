#!/usr/bin/env python3
"""
attempt_tile_paths_ref.py

Reference helper for dOCF deployments that use tile-backed transparency logs
(e.g., the C2SP Static Certificate Transparency API).

This tool is deliberately tiny and deterministic. It does not fetch tiles from
the network; it just computes the *paths* to fetch and a few derived bounds.

Usage examples:
  python3 attempt_tile_paths_ref.py --leaf-index 1234067
  python3 attempt_tile_paths_ref.py --leaf-index 1234067 --tree-size 1000000000

Notes:
- The Static CT API encodes tile indices into 3-digit path elements where all but
  the last component begin with 'x'. Example: 1234067 -> x001/x234/067.
- Full hash tiles are 256 hashes wide, i.e., they cover 8 Merkle levels per tile.
"""

from __future__ import annotations

import argparse
import math
from dataclasses import dataclass
from typing import List


@dataclass(frozen=True)
class StaticCTParams:
    tile_width: int = 256          # hashes per tile
    chunk_digits: int = 3          # path encoding digits
    prefix_char: str = "x"         # prefix for all but last chunk

    @property
    def levels_per_tile(self) -> int:
        # tile_width == 2^(levels_per_tile)
        return int(math.log2(self.tile_width))


def encode_tile_index(index: int, chunk_digits: int = 3, prefix_char: str = "x") -> str:
    """
    Encode an integer index into the Static CT directory hierarchy.
    Example: 1234067 -> x001/x234/067 (for chunk_digits=3, prefix_char='x').
    """
    if index < 0:
        raise ValueError("index must be non-negative")
    s = str(index)
    # Left-pad to a multiple of chunk_digits.
    pad = (-len(s)) % chunk_digits
    s = ("0" * pad) + s
    chunks = [s[i:i+chunk_digits] for i in range(0, len(s), chunk_digits)]
    if len(chunks) == 1:
        return chunks[0]
    # Prefix all but the last chunk.
    prefixed = [f"{prefix_char}{c}" for c in chunks[:-1]] + [chunks[-1]]
    return "/".join(prefixed)


def hash_tile_index_for_leaf(leaf_index: int, level: int, params: StaticCTParams) -> int:
    """
    Return the tile index (n) at a given tile level 'level' (0 = leaf-hash tiles).
    In Static CT: tile n at level l covers leaves in blocks of params.tile_width^(l+1).
    """
    if leaf_index < 0:
        raise ValueError("leaf_index must be non-negative")
    if level < 0:
        raise ValueError("level must be non-negative")
    # Each hash at level l summarizes a subtree of size tile_width^level.
    # A tile contains tile_width hashes, so a tile covers tile_width^(level+1) leaves.
    tile_span = params.tile_width ** (level + 1)
    return leaf_index // tile_span


def tiles_needed_for_inclusion(tree_size: int, params: StaticCTParams) -> int:
    """
    Upper bound on the number of *hash tiles* a client needs to fetch to materialize
    a Merkle inclusion proof for a single leaf, assuming the client can fetch the
    relevant tiles at each 8-level stride.

    This is a simple bound used for sizing: ceil(log2(tree_size) / levels_per_tile).
    """
    if tree_size <= 0:
        raise ValueError("tree_size must be positive")
    levels = math.ceil(math.log2(tree_size))
    return math.ceil(levels / params.levels_per_tile)


def data_tile_index_for_leaf(leaf_index: int, params: StaticCTParams) -> int:
    """Data tiles group params.tile_width log entries."""
    if leaf_index < 0:
        raise ValueError("leaf_index must be non-negative")
    return leaf_index // params.tile_width


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--leaf-index", type=int, required=True)
    ap.add_argument("--tree-size", type=int, default=None, help="If set, compute hash-tile bound up to this size.")
    ap.add_argument("--tile-width", type=int, default=256)
    ap.add_argument("--chunk-digits", type=int, default=3)
    ap.add_argument("--prefix-char", type=str, default="x")
    args = ap.parse_args()

    params = StaticCTParams(tile_width=args.tile_width, chunk_digits=args.chunk_digits, prefix_char=args.prefix_char)

    leaf = args.leaf_index
    dt = data_tile_index_for_leaf(leaf, params)
    dt_path = encode_tile_index(dt, params.chunk_digits, params.prefix_char)

    print(f"leaf_index={leaf}")
    print(f"tile_width={params.tile_width}  (levels_per_tile={params.levels_per_tile})")
    print(f"data_tile_index={dt}  path={dt_path}")

    if args.tree_size is not None:
        ht = tiles_needed_for_inclusion(args.tree_size, params)
        print(f"tree_size={args.tree_size}  hash_tiles_needed<= {ht}")

        # Show which tile index at each tile-level would contain the leaf's sibling material.
        # This is illustrative and not a full proof generator.
        max_level = ht - 1
        tile_levels = list(range(0, max_level + 1))
        indices = [hash_tile_index_for_leaf(leaf, lvl, params) for lvl in tile_levels]
        paths = [encode_tile_index(i, params.chunk_digits, params.prefix_char) for i in indices]
        for lvl, i, p in zip(tile_levels, indices, paths):
            print(f"hash_tile_level={lvl} index={i} path={p}")


if __name__ == "__main__":
    main()
