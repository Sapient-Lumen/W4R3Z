#!/usr/bin/env python3
"""snl_gossip_bundle_ref.py (v86.8)

Create *gossip bundles* for SNL transparency staples.

A gossip bundle is a cacheable, signed artifact recording that an observer
(cache/relay/monitor) received a particular transparency checkpoint.

This tool emits deterministic demo bundles:
  - bundle_A observes the demo checkpoint from test_vectors/snl_staple_demo.json
  - bundle_B observes either:
      (a) the same checkpoint (default), or
      (b) a *validly signed conflicting checkpoint* (split-view demo)

Why "validly signed" conflicts matter:
  - A split-view attack on transparency logs is *equivocation by the log signer*.
  - A real slashing/forensics artifact requires two checkpoints that both verify
    under the same log public key but have different roots.

Usage:
  python3 snl_gossip_bundle_ref.py --emit-demo

Outputs under test_vectors/:
  - snl_gossip_bundle_A_demo.json
  - snl_gossip_bundle_B_demo.json
  - snl_gossip_bundle_B_conflict_demo.json  (valid equivocation)
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
from typing import Any, Dict, Tuple

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from docf_ref_tools_common import jcs, load_json, emit_json


def b64e(b: bytes) -> str:
    return base64.b64encode(b).decode("utf-8")


def b64d(s: str) -> bytes:
    return base64.b64decode(s.encode("utf-8"))


def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_pref(b: bytes) -> str:
    return "sha256:" + sha256_hex(b)


def _seed(tag: bytes) -> bytes:
    return hashlib.sha256(tag).digest()[:32]


def demo_observer_keypair(i: int) -> Tuple[bytes, bytes, str, str]:
    oid = f"docf-demo-snl-gossip-observer-{i}"
    seed = _seed(f"docf-demo-snl-gossip-observer-seed-{i}".encode("utf-8"))
    sk = Ed25519PrivateKey.from_private_bytes(seed)
    pk = sk.public_key().public_bytes_raw()
    keyid = "sha256:" + sha256_hex(pk)
    return seed, pk, oid, keyid


def demo_log_keypair() -> Tuple[bytes, bytes]:
    """Must match snl_staple_ref.demo_log_keypair."""
    seed = _seed(b"docf-demo-snl-tlog-key")
    sk = Ed25519PrivateKey.from_private_bytes(seed)
    pk = sk.public_key().public_bytes_raw()
    return seed, pk


def checkpoint_payload(checkpoint: Dict[str, Any]) -> bytes:
    msg_obj = {
        "format": checkpoint["format"],
        "log_id": checkpoint.get("log_id", ""),
        "tree_size": checkpoint["tree_size"],
        "root_hash_sha256_b64": checkpoint["root_hash_sha256_b64"],
        "issued_at": checkpoint["issued_at"],
    }
    return jcs(msg_obj)


def make_checkpoint_like(chk: Dict[str, Any], *, root_hash_b64: str, issued_at: str) -> Dict[str, Any]:
    sk_seed, pk_raw = demo_log_keypair()
    log_id = str(chk.get("log_id", ""))
    tree_size = int(chk.get("tree_size", 0) or 0)

    msg_obj = {
        "format": str(chk.get("format", "docf-demo-checkpoint-v0")),
        "log_id": log_id,
        "tree_size": tree_size,
        "root_hash_sha256_b64": root_hash_b64,
        "issued_at": issued_at,
    }
    msg = jcs(msg_obj)
    sk = Ed25519PrivateKey.from_private_bytes(sk_seed)
    sig = sk.sign(msg)

    out = dict(msg_obj)
    out["log_public_key_ed25519_raw_b64"] = b64e(pk_raw)
    out["log_signature_ed25519_b64"] = b64e(sig)
    out["notes"] = (out.get("notes") or []) + [
        "DEMO: validly signed checkpoint created with the demo log key.",
    ]
    return out


def digest_bundle_unsigned(bundle: Dict[str, Any]) -> str:
    tmp = dict(bundle)
    tmp.pop("digest", None)
    tmp.pop("sig", None)
    return sha256_pref(jcs(tmp))


def sign_bundle(bundle: Dict[str, Any], sk_seed: bytes) -> Dict[str, Any]:
    d = digest_bundle_unsigned(bundle)
    sk = Ed25519PrivateKey.from_private_bytes(sk_seed)
    sig = sk.sign(d.encode("utf-8"))
    out = dict(bundle)
    out["digest"] = d
    out["sig"] = b64e(sig)
    return out


def make_bundle(observer_i: int, chk: Dict[str, Any], received_at: str) -> Dict[str, Any]:
    sk_seed, pk_raw, oid, keyid = demo_observer_keypair(observer_i)
    payload = checkpoint_payload(chk)
    obs = {
        "checkpoint_payload_sha256_hex": sha256_hex(payload),
        "received_at": received_at,
        "checkpoint": chk,
        "notes": [
            "Observation binds the full checkpoint payload (JCS) to a local receipt time.",
            "In a real gossip system, observers would also record transport metadata and consistency proofs.",
        ],
    }
    bundle = {
        "schema": "docf-snl-gossip-bundle-v0",
        "version": "0",
        "log_id": chk.get("log_id", ""),
        "observer": {
            "observer_id": oid,
            "public_key_ed25519_raw_b64": b64e(pk_raw),
            "keyid": keyid,
            "not_before": "2026-02-27T00:00:00Z",
            "not_after": "2027-02-27T00:00:00Z",
            "notes": ["Deterministic demo gossip observer."],
        },
        "observations": [obs],
        "notes": [
            "Gossip bundle is a cacheable artifact: it can be forwarded, stored, and audited.",
            "Gate policies may require a quorum of independent observer signatures over the same checkpoint payload hash.",
        ],
    }
    return sign_bundle(bundle, sk_seed)


def make_valid_conflict_checkpoint(chk: Dict[str, Any]) -> Dict[str, Any]:
    b = b64d(str(chk.get("root_hash_sha256_b64", "")) or "")
    if len(b) == 0:
        b2 = b"\x01" * 32
    else:
        b2 = bytes([b[0] ^ 0x01]) + b[1:]
    root2_b64 = b64e(b2)
    issued_at2 = "2026-02-27T00:01:03Z"
    out = make_checkpoint_like(chk, root_hash_b64=root2_b64, issued_at=issued_at2)
    out["notes"] = (out.get("notes") or []) + [
        "DEMO: this is a *conflicting* signed head for the same (log_id, tree_size).",
        "DEMO: in real deployments, producing two such heads is slashing evidence.",
    ]
    return out


def emit_demo() -> None:
    tv = os.path.join(os.path.dirname(__file__), "test_vectors")
    os.makedirs(tv, exist_ok=True)

    staple = load_json(os.path.join(tv, "snl_staple_demo.json"))
    chk = ((staple.get("witness") or {}).get("checkpoint") or {})

    bundle_a = make_bundle(0, chk, "2026-02-27T00:01:05Z")
    bundle_b = make_bundle(1, chk, "2026-02-27T00:01:06Z")

    chk_conf = make_valid_conflict_checkpoint(chk)
    bundle_b_conf = make_bundle(1, chk_conf, "2026-02-27T00:01:06Z")

    out_a = os.path.join(tv, "snl_gossip_bundle_A_demo.json")
    out_b = os.path.join(tv, "snl_gossip_bundle_B_demo.json")
    out_b_conf = os.path.join(tv, "snl_gossip_bundle_B_conflict_demo.json")

    for path, obj in [(out_a, bundle_a), (out_b, bundle_b), (out_b_conf, bundle_b_conf)]:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, indent=2, ensure_ascii=False)
            f.write("\n")

    emit_json({"bundle_A": bundle_a, "bundle_B": bundle_b, "bundle_B_conflict": bundle_b_conf})
    print(f"Wrote {out_a}")
    print(f"Wrote {out_b}")
    print(f"Wrote {out_b_conf}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit-demo", action="store_true")
    args = ap.parse_args()

    if args.emit_demo:
        emit_demo()
        return

    ap.print_help()


if __name__ == "__main__":
    main()
