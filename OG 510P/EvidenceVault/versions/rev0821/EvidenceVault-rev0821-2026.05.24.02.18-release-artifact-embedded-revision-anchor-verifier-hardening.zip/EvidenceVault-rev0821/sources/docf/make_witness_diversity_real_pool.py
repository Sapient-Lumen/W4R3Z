#!/usr/bin/env python3
"""make_witness_diversity_real_pool.py

Replayable *real-pool* correlated-compromise experiment using a witness snapshot
harvested from public Witness Network tables and about pages.

Key point:
  - The *observed* public pool (as of the snapshot) is already fairly operator-diverse.
  - But deployments often include multiple endpoints per operator (regions, stacks, etc).
    To stress-test this, we also run an **augmented pool** experiment where each operator
    contributes K near-identical witness instances (same operator correlation), and show
    that diversity-aware selection can materially reduce *dual-accept* risk.

This script is self-contained and deterministic. It does NOT claim any specific compromise
probability is accurate; instead it runs a small *sensitivity sweep*.

Inputs:
  data/witness_pool_snapshot_YYYY-MM-DD.json

Outputs:
  test_vectors/pct_witness_diversity_real_results.json
  _insert_witness_diversity_real_table.tex
  pct_witness_diversity_real_bars.pdf
"""
from __future__ import annotations

import argparse, itertools, json
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
TV = ROOT / 'test_vectors'

def load_snapshot(path: Path) -> Dict:
    return json.loads(path.read_text(encoding='utf-8'))

def make_pool(snapshot: Dict, q_op: float, p_ind: float) -> Dict:
    ops = sorted({w['operator'] for w in snapshot['witnesses']})
    operators = [{'id': op, 'compromise_prob': q_op} for op in ops]
    witnesses = []
    for w in snapshot['witnesses']:
        p = p_ind
        notes = ' '.join(w.get('notes', []))
        if 'soft key' in notes or 'best-effort' in notes or w.get('env') in ('dev','testing'):
            p = min(0.05, p_ind * 2.0)
        witnesses.append({
            'id': w['id'],
            'operator': w['operator'],
            'env': w.get('env',''),
            'independent_compromise_prob': p,
        })
    return {'operators': operators, 'witnesses': witnesses, 'params': {'q_op': q_op, 'p_ind_base': p_ind}}

def augment_pool(pool: Dict, k: int) -> Dict:
    """Replicate witnesses so each operator has ~k instances.

    This models the common situation where operators run multiple witness endpoints.
    Instances share the same operator-correlation (compromising the operator compromises all).
    """
    if k <= 1:
        return pool
    W = pool['witnesses']
    ops = {w['operator'] for w in W}
    by_op: Dict[str, List[Dict]] = {op: [] for op in ops}
    for w in W:
        by_op[w['operator']].append(w)
    outW = []
    for op, ws in sorted(by_op.items()):
        # take a representative template per operator (if multiple exist, cycle)
        for i in range(k):
            tmpl = ws[i % len(ws)]
            out = dict(tmpl)
            out['id'] = f"{tmpl['id']}#inst{i+1}"
            outW.append(out)
    return {'operators': pool['operators'], 'witnesses': outW,
            'params': {**pool.get('params',{}), 'augmented_k': k}}

def simulate_compromise(pool: Dict, subset: List[Dict], rng: np.random.Generator) -> np.ndarray:
    op_q = {o['id']: float(o['compromise_prob']) for o in pool['operators']}
    op_comp = {op: (rng.random() < q) for op, q in op_q.items()}
    comp = np.zeros(len(subset), dtype=bool)
    for i, w in enumerate(subset):
        if op_comp[w['operator']]:
            comp[i] = True
        else:
            comp[i] = rng.random() < float(w['independent_compromise_prob'])
    return comp

def estimate(pool: Dict, subset: List[Dict], t: int, trials: int, seed: int) -> Dict[str, float]:
    rng = np.random.default_rng(seed)
    m = len(subset)
    cq = 0
    da = 0
    for _ in range(trials):
        comp = simulate_compromise(pool, subset, rng)
        c = int(comp.sum())
        if c >= t:
            cq += 1
        # hard partition: choose gA indices, compute signer counts via vector sums (fast)
        perm = rng.permutation(m)
        gA = m // 2
        cA = int(comp[perm[:gA]].sum())
        cB = c - cA
        sA = gA + cB
        sB = (m - gA) + cA
        if sA >= t and sB >= t:
            da += 1
    return {'p_compromised_quorum': cq / trials, 'p_dual_accept': da / trials}

def diverse_choice(subsets: List[List[Dict]]) -> List[Dict]:
    # maximize operator diversity, then stable by witness id
    def key(S):
        return (len({w['operator'] for w in S}), tuple(sorted(w['id'] for w in S)))
    return sorted(subsets, key=key, reverse=True)[0]

def run_one(pool: Dict, m: int, t: int, trials: int, seed: int) -> Dict:
    W = pool['witnesses']
    # If there are many witnesses, enumerating all subsets may be huge.
    # For augmented pools, sample subsets for the random baseline.
    n = len(W)
    rng = np.random.default_rng(seed)
    if n <= 12:
        subs = [[W[i] for i in idx] for idx in itertools.combinations(range(n), m)]
        per = []
        for j, S in enumerate(subs):
            per.append((S, estimate(pool, S, t=t, trials=max(400, trials//120), seed=seed + j)))
        da_avg = float(np.mean([r['p_dual_accept'] for _, r in per]))
        cq_avg = float(np.mean([r['p_compromised_quorum'] for _, r in per]))
        Sdiv = diverse_choice([S for S,_ in per])
        rdiv = estimate(pool, Sdiv, t=t, trials=trials, seed=seed + 999)
        Sbest, rbest = sorted(per, key=lambda x: x[1]['p_dual_accept'])[0]
        return {'random': {'p_dual_accept': da_avg, 'p_compromised_quorum': cq_avg},
                'diverse': rdiv, 'best': rbest,
                'diverse_set': [w['id'] for w in Sdiv], 'best_set': [w['id'] for w in Sbest],
                'diverse_ops': len({w['operator'] for w in Sdiv}),
                'best_ops': len({w['operator'] for w in Sbest})}
    else:
        # random baseline: average over sampled subsets
        draws = 200
        da = []
        cq = []
        for j in range(draws):
            idx = rng.choice(n, size=m, replace=False)
            S = [W[int(i)] for i in idx]
            r = estimate(pool, S, t=t, trials=max(200, trials//300), seed=seed + j)
            da.append(r['p_dual_accept']); cq.append(r['p_compromised_quorum'])
        da_avg = float(np.mean(da)); cq_avg = float(np.mean(cq))
        # diverse heuristic: greedy build maximizing new operators
        # start with one witness per operator (choose lowest p), then fill lowest p.
        by_op: Dict[str, List[Dict]] = {}
        for w in W:
            by_op.setdefault(w['operator'], []).append(w)
        chosen = []
        for op, ws in by_op.items():
            ws2 = sorted(ws, key=lambda x: x['independent_compromise_prob'])
            chosen.append(ws2[0])
            if len(chosen) == m:
                break
        if len(chosen) < m:
            remaining = [w for w in W if w not in chosen]
            remaining = sorted(remaining, key=lambda x: x['independent_compromise_prob'])
            chosen.extend(remaining[:(m-len(chosen))])
        Sdiv = chosen[:m]
        rdiv = estimate(pool, Sdiv, t=t, trials=trials, seed=seed + 12345)
        return {'random': {'p_dual_accept': da_avg, 'p_compromised_quorum': cq_avg},
                'diverse': rdiv,
                'diverse_set': [w['id'] for w in Sdiv],
                'diverse_ops': len({w['operator'] for w in Sdiv})}

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--in', dest='inp', default=str(DATA / 'witness_pool_snapshot_2026-02-28.json'))
    ap.add_argument('--m', type=int, default=7)
    ap.add_argument('--t', type=int, default=5)
    ap.add_argument('--augment_k', type=int, default=3)
    ap.add_argument('--trials', type=int, default=50000)
    ap.add_argument('--seed', type=int, default=7)
    ap.add_argument('--out_json', default=str(TV / 'pct_witness_diversity_real_results.json'))
    ap.add_argument('--out_tex', default=str(ROOT / '_insert_witness_diversity_real_table.tex'))
    ap.add_argument('--out_fig', default=str(ROOT / 'pct_witness_diversity_real_bars.pdf'))
    args = ap.parse_args()

    snap = load_snapshot(Path(args.inp))

    q_grid = [1e-3, 1e-2, 5e-2]
    p_grid = [1e-3, 5e-3, 1e-2]

    default = {'q_op': 1e-2, 'p_ind': 5e-3}

    sweep = []
    for q_op in q_grid:
        for p_ind in p_grid:
            base = make_pool(snap, q_op=q_op, p_ind=p_ind)
            aug = augment_pool(base, args.augment_k)

            base_res = run_one(base, m=min(args.m, len(base['witnesses'])), t=min(args.t, min(args.m, len(base['witnesses']))), trials=args.trials, seed=args.seed)
            aug_res  = run_one(aug,  m=args.m, t=args.t, trials=args.trials, seed=args.seed + 4242)

            sweep.append({
                'q_op': q_op, 'p_ind_base': p_ind,
                'base': base_res,
                'augmented': {**aug_res, 'k': args.augment_k, 'n': len(aug['witnesses'])},
            })

    out = {
        'snapshot_in': args.inp,
        'm': args.m, 't': args.t,
        'augment_k': args.augment_k,
        'note': 'Sensitivity sweep. q_op and p_ind are illustrative knobs, not measured.',
        'sweep': sweep,
        'default': default,
    }
    Path(args.out_json).write_text(json.dumps(out, indent=2, sort_keys=True) + '\n', encoding='utf-8')

    # LaTeX: focus on augmented pool (stress test) + default row; show improvement
    lines = []
    lines.append('% Auto-generated by make_witness_diversity_real_pool.py')
    lines.append('\\begin{table}[t]')
    lines.append('\\centering')
    lines.append('\\caption{Witness diversity sensitivity on a \emph{real} witness snapshot (2026-02-28), plus an augmented stress-test where each operator runs $k$ instances (here $k=%d$). Values are Monte Carlo estimates of dual-accept probability under hard partition routing, for a $t$-of-$m$ policy (here $m=%d,t=%d$). The point is not absolute probabilities, but how diversity-aware selection changes risk under correlated compromise.}' % (args.augment_k, args.m, args.t))
    lines.append('\\label{tab:witness_diversity_real}')
    lines.append('\\begin{tabular}{rrrrr}')
    lines.append('\\toprule')
    lines.append('$q_{op}$ & $p_{ind}$ & $\\Pr[DA]$ random & $\\Pr[DA]$ diverse & $\\times$ improv. \\\\')
    lines.append('\\midrule')
    for row in sweep:
        aug = row['augmented']
        da_r = aug['random']['p_dual_accept']
        da_d = aug['diverse']['p_dual_accept']
        improv = (da_r / da_d) if da_d > 0 else float('inf')
        lines.append(f"{row['q_op']:.0e} & {row['p_ind_base']:.0e} & {da_r:.3g} & {da_d:.3g} & {improv:.2g} \\\\")
    lines.append('\\bottomrule')
    lines.append('\\end{tabular}')
    lines.append('\\end{table}')
    Path(args.out_tex).write_text('\n'.join(lines) + '\n', encoding='utf-8')

    # Bar chart for default parameters (augmented)
    drow = [r for r in sweep if (r['q_op']==default['q_op'] and r['p_ind_base']==default['p_ind'])][0]
    aug = drow['augmented']
    labels = ['random(avg)', 'diverse']
    values = [aug['random']['p_dual_accept'], aug['diverse']['p_dual_accept']]
    plt.figure(figsize=(6,3.2))
    plt.bar(labels, values)
    plt.yscale('log')
    plt.ylabel('Estimated dual-accept probability (log scale)')
    plt.title(f'Augmented real pool (k={args.augment_k}, n={aug.get("n")}), m={args.m}, t={args.t} (default q_op={default["q_op"]}, p_ind={default["p_ind"]})')
    plt.tight_layout()
    plt.savefig(args.out_fig)
    plt.close()

if __name__ == '__main__':
    main()
