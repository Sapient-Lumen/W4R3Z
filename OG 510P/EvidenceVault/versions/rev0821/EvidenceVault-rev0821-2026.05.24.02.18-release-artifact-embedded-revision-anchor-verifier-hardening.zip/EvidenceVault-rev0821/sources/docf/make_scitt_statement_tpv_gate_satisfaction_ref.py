#!/usr/bin/env python3
"""make_scitt_statement_tpv_gate_satisfaction_ref.py

Emit a minimal SCITT-style statement payload that commits to a TPV gate
satisfaction object digest.

Pedagogical JSON stand-in for a COSE-carried SCITT statement.

Usage:
  python3 make_scitt_statement_tpv_gate_satisfaction_ref.py \
    --gso test_vectors/tpv_gate_satisfaction_demo.json \
    > test_vectors/tpv_gate_satisfaction_scitt_statement_demo.json
"""

from __future__ import annotations

import argparse
import hashlib
import json
from typing import Any, Dict

from docf_ref_tools_common import jcs, load_json


def sha256_pref(b: bytes) -> str:
    return "sha256:" + hashlib.sha256(b).hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--gso", required=True)
    ap.add_argument("--signer", default="did:web:gatekeeper.example")
    ap.add_argument("--log-id", default="scitt-demo")
    args = ap.parse_args()

    gso = load_json(args.gso)
    dgso = sha256_pref(jcs(gso))

    stmt: Dict[str, Any] = {
        "media_type": "application/scitt-statement+cose",
        "payload": {
            "statement_type": "docf.tpv_gate_satisfaction",
            "gso_digest": dgso,
            "gso_ref": args.gso,
            "gate_policy_nf_digest": gso.get("gate_policy_nf_digest", ""),
            "gate_policy_digest": gso.get("gate_policy_digest", ""),
            "tpv_digest": gso.get("tpv_digest", ""),
            "result": gso.get("result", ""),
            "tpv_subject": gso.get("tpv_subject", {}),
        },
        "signer": args.signer,
        "log_id": args.log_id,
    }

    print(json.dumps(stmt, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
