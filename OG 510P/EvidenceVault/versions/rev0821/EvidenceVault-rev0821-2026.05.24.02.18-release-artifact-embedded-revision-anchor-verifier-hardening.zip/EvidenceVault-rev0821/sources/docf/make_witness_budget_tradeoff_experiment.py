#!/usr/bin/env python3
"""make_witness_budget_tradeoff_experiment.py

Exact (brute-force) witness-set selection under a correlation budget and availability target.

Motivation: WDD lets a verifier enforce a correlation budget \hat\rho <= \rho_max.
This experiment shows the *economic* and *availability* consequences of that policy.

We use a small synthetic candidate pool derived deterministically from the archive's
`witness_candidate_pool_demo.json` with added fields:
  - monthly_cost_usd
  - uptime (prob witness responds)
  - impl_family
  - kms_class

For each split-view risk budget B_dual = 2^{-k}, we compute \rho_max using the
exchangeable Beta--Binomial ICC model (same as other witness experiments), then
choose the minimum-cost witness set of size m that satisfies:
  (1) \hat\rho(S) <= \rho_max
  (2) P[#available >= t] >= 1 - delta

Because the demo pool is small (n=20), we can brute-force all \binom{n}{m} sets.

Outputs:
  - test_vectors/witness_budget_tradeoff_results.json
  - _insert_witness_budget_tradeoff_table.tex
  - pct_witness_budget_tradeoff.pdf

"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple


def tex_escape(s: str) -> str:
    return s.replace('_', r'\\_')


def _rho(labels: List[str]) -> float:
    m = len(labels)
    if m <= 1:
        return 0.0
    counts: Dict[str, int] = {}
    for x in labels:
        counts[x] = counts.get(x, 0) + 1
    num = sum(v * (v - 1) for v in counts.values())
    return num / (m * (m - 1))


def rho_hat_for_set(ws: List[Dict[str, Any]], domains: List[str]) -> Tuple[float, Dict[str, float]]:
    by: Dict[str, float] = {}
    for d in domains:
        labels = [str(w.get(d) or w.get('id')) for w in ws]
        by[d] = _rho(labels)
    rh = max(by.values()) if by else 0.0
    return rh, by


def poisson_binom_tail(ps: List[float], t: int) -> float:
    """Return P[X >= t] for independent Bernoulli(p_i) sum using DP."""
    m = len(ps)
    # dp[j] = P[X=j]
    dp = [0.0] * (m + 1)
    dp[0] = 1.0
    for p in ps:
        nxt = [0.0] * (m + 1)
        for j in range(0, m + 1):
            if dp[j] == 0.0:
                continue
            nxt[j] += dp[j] * (1 - p)
            if j + 1 <= m:
                nxt[j + 1] += dp[j] * p
        dp = nxt
    return sum(dp[t:])


def log_beta(a: float, b: float) -> float:
    return math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)


def beta_binom_pmf(m: int, k: int, alpha: float, beta: float) -> float:
    return math.comb(m, k) * math.exp(log_beta(alpha + k, beta + m - k) - log_beta(alpha, beta))


def hypergeom_pmf(N: int, K: int, n: int, k: int) -> float:
    if k < 0 or k > n or k > K or (n - k) > (N - K):
        return 0.0
    return (math.comb(K, k) * math.comb(N - K, n - k)) / math.comb(N, n)


def dual_accept_prob_given_K(m: int, t: int, g: int, K: int) -> float:
    """P[side A and B both accept] given K compromised among m, partition size g and threshold t."""
    lo = max(0, t - (m - g))
    hi = min(g, K + g - t)
    if lo > hi:
        return 0.0
    return sum(hypergeom_pmf(m, K, g, kA) for kA in range(lo, hi + 1))


def compute_dual_accept(m: int, t: int, q: float, rho: float) -> float:
    """Exchangeable compromise model: Beta--Binomial with ICC rho and marginal q."""
    g = m // 2

    if rho <= 0.0:
        pD = 0.0
        for K in range(0, m + 1):
            pK = math.comb(m, K) * (q**K) * ((1 - q) ** (m - K))
            pD += pK * dual_accept_prob_given_K(m, t, g, K)
        return pD

    s = (1.0 / rho) - 1.0
    alpha = max(1e-12, q * s)
    beta = max(1e-12, (1.0 - q) * s)

    pD = 0.0
    for K in range(0, m + 1):
        pK = beta_binom_pmf(m, K, alpha, beta)
        pD += pK * dual_accept_prob_given_K(m, t, g, K)
    return pD


def max_rho_for_budget(m: int, t: int, q: float, budget_dual: float) -> float | None:
    # If even rho=0 exceeds budget, no correlation level can satisfy this budget.
    if compute_dual_accept(m, t, q, 0.0) > budget_dual:
        return None

    lo, hi = 0.0, 0.999
    for _ in range(70):
        mid = (lo + hi) / 2
        pD = compute_dual_accept(m, t, q, mid)
        if pD <= budget_dual:
            lo = mid
        else:
            hi = mid
    return lo


def best_set_exact(
    pool: List[Dict[str, Any]],
    m: int,
    t: int,
    domains: List[str],
    rho_max: float,
    delta: float,
) -> Dict[str, Any] | None:
    """Return minimum-cost feasible set (exact brute force) or None."""
    best = None
    best_key = None

    for comb in itertools.combinations(pool, m):
        ws = list(comb)
        rh, by = rho_hat_for_set(ws, domains)
        if rh > rho_max + 1e-12:
            continue

        ps = [float(w.get('uptime', 1.0)) for w in ws]
        p_live = poisson_binom_tail(ps, t)
        if p_live < 1.0 - delta:
            continue

        cost = sum(float(w.get('monthly_cost_usd', 0.0)) for w in ws)

        # key: minimize cost; tie-breaker maximize p_live; then minimize rho_hat
        key = (cost, -p_live, rh)
        if best_key is None or key < best_key:
            best_key = key
            best = {
                'selected_witness_ids': [w['id'] for w in ws],
                'rho_hat': float(f"{rh:.6g}"),
                'rho_by_domain': {k: float(f"{v:.6g}") for k, v in by.items()},
                'monthly_cost_usd': float(f"{cost:.6g}"),
                'p_live': float(f"{p_live:.6g}"),
            }

    return best


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--pool', default='test_vectors/witness_candidate_pool_demo_v2.json')
    ap.add_argument('--m', type=int, default=7)
    ap.add_argument('--t', type=int, default=6)
    ap.add_argument('--q', type=float, default=0.12)
    ap.add_argument('--delta', type=float, default=1e-4)
    ap.add_argument('--domains', default='operator,region,impl_family,kms_class')
    ap.add_argument('--budgets_bits', default='6,8,10,12')
    ap.add_argument('--out_json', default='test_vectors/witness_budget_tradeoff_results.json')
    ap.add_argument('--out_tex', default='_insert_witness_budget_tradeoff_table.tex')
    ap.add_argument('--out_fig', default='pct_witness_budget_tradeoff.pdf')
    args = ap.parse_args()

    domains = [x.strip() for x in args.domains.split(',') if x.strip()]
    ks = [int(x.strip()) for x in args.budgets_bits.split(',') if x.strip()]

    pool_obj = json.loads(Path(args.pool).read_text(encoding='utf-8'))
    pool = pool_obj.get('witnesses', [])

    rows = []
    for k in ks:
        budget_dual = 2.0 ** (-k)
        rho_max = max_rho_for_budget(args.m, args.t, args.q, budget_dual)
        if rho_max is None:
            best = None
        else:
            best = best_set_exact(pool, args.m, args.t, domains, rho_max, args.delta)

        row = {
            'k': k,
            'B_dual': budget_dual,
            'rho_max': (None if rho_max is None else float(f"{rho_max:.6g}")),
            'feasible': bool(best),
        }
        if best:
            row.update(best)
        rows.append(row)

    out = {
        'type': 'docf_witness_budget_tradeoff_results_v0',
        'params': {
            'pool': args.pool,
            'm': args.m,
            't': args.t,
            'q': args.q,
            'delta': args.delta,
            'domains': domains,
        },
        'rows': rows,
    }
    Path(args.out_json).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out_json).write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding='utf-8')

    # LaTeX table
    tex = []
    tex.append(r'\\begin{tabular}{r r r r r l}')
    tex.append(r'\\toprule')
    tex.append(r'$k$ & $\\rho_{\\max}$ & $\\hat\\rho$ & cost (USD/mo) & $P[\\ge t\\;live]$ & status \\\\')
    tex.append(r'\\midrule')
    for r in rows:
        if not r['feasible']:
            tex.append(f"{r['k']} & {r['rho_max']:.4g} & -- & -- & -- & infeasible \\\\")
            continue
        status = 'ok'
        tex.append(
            f"{r['k']} & {r['rho_max']:.4g} & {r['rho_hat']:.4g} & {r['monthly_cost_usd']:.0f} & {r['p_live']:.5f} & {status} \\\\")
    tex.append(r'\\midrule')

    # show one representative selection (tightest feasible)
    feas = [r for r in rows if r.get('feasible')]
    if feas:
        tight = max(feas, key=lambda x: x['k'])
        ids = ','.join(tight['selected_witness_ids'])
        ids_short = (ids[:70] + '…') if len(ids) > 72 else ids
        tex.append(r'\\multicolumn{6}{l}{Tightest-feasible selection: ' + tex_escape(ids_short) + r'} \\\\')
    tex.append(r'\\bottomrule')
    tex.append(r'\\end{tabular}')
    Path(args.out_tex).write_text('\n'.join(tex) + '\n', encoding='utf-8')

    # Figure: cost vs k for feasible rows
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt

        xs = [r['k'] for r in rows if r.get('feasible')]
        ys = [r['monthly_cost_usd'] for r in rows if r.get('feasible')]
        plt.figure()
        if xs:
            plt.plot(xs, ys, marker='o')
        plt.xlabel('Budget bits k (B_dual = 2^{-k})')
        plt.ylabel('Minimum monthly cost (USD)')
        plt.title('Cost of meeting a correlation+availability policy')
        plt.tight_layout()
        plt.savefig(args.out_fig)
        plt.close()
    except Exception as e:
        # do not fail the build if matplotlib is unavailable
        Path(args.out_fig).write_text('figure generation failed: ' + str(e), encoding='utf-8')


if __name__ == '__main__':
    main()
