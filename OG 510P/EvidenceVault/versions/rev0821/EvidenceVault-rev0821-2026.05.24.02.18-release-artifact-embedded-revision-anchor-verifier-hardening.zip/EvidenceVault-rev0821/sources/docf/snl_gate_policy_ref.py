#!/usr/bin/env python3
"""snl_gate_policy_ref.py (v86.8)

Reference evaluator for Security Nutrition Labels (SNL).

Given:
  - an SNL (docf-security-nutrition-label-v0 or v1)
  - a local gate policy
  - optionally an SNL transparency staple
this tool deterministically produces a small decision object:
  ACCEPT_REUSE | ACCEPT_MONITOR | REJECT

v86.8 adds:
  - optional CT-style gossip-quorum verification over stapled checkpoints
  - split-view conflict detection across gossip bundles and emission of a portable slashing proof
  - optimistic accumulator support for monitor-only caching / deferred audit

This is *not* production code.

Usage:
  python3 snl_gate_policy_ref.py --snl <snl.json> --policy <policy.json> --out <decision.json> [--staple <snl_staple.json>] [--gossip-bundles a.json b.json ...] [--gossip-accumulator acc.json]
  python3 snl_gate_policy_ref.py --emit-demo
"""

from __future__ import annotations

import argparse
import base64
import datetime
import hashlib
import json
import os
from typing import Any, Dict, List, Tuple

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from docf_ref_tools_common import jcs, load_json
from log_inclusion_witness_ref import ct_leaf_hash, verify_rfc9162_inclusion, verify_sth_signature
from log_consistency_witness_ref import verify_consistency
from snl_slashing_proof_ref import build_slashing_proof


def sha256_pref(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def digest_obj_unsigned(obj: Dict[str, Any]) -> str:
    tmp = dict(obj)
    tmp.pop("digest", None)
    tmp.pop("sig", None)
    return sha256_pref(jcs(tmp))


def rfc3339_to_dt(s: str) -> datetime.datetime:
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    return datetime.datetime.fromisoformat(s)


def policy_now(policy: Dict[str, Any]) -> datetime.datetime:
    # Determinism: demos supply now_rfc3339; otherwise use wall clock.
    now_s = str(policy.get("now_rfc3339", "") or "")
    if now_s:
        return rfc3339_to_dt(now_s)
    return datetime.datetime.now(datetime.timezone.utc)


def checkpoint_payload(checkpoint: Dict[str, Any]) -> bytes:
    msg_obj = {
        "format": checkpoint["format"],
        "log_id": checkpoint.get("log_id", ""),
        "tree_size": checkpoint["tree_size"],
        "root_hash_sha256_b64": checkpoint["root_hash_sha256_b64"],
        "issued_at": checkpoint["issued_at"],
    }
    return jcs(msg_obj)


def checkpoint_payload_sha256_hex(checkpoint: Dict[str, Any]) -> str:
    return sha256_hex(checkpoint_payload(checkpoint))


def checkpoint_keyid_hex(checkpoint: Dict[str, Any]) -> str:
    # Rotation/revocation pin for the log signing key.
    try:
        pub_raw = base64.b64decode(checkpoint["log_public_key_ed25519_raw_b64"])
        return sha256_hex(pub_raw)
    except Exception:
        return ""



def digest_gossip_bundle_unsigned(bundle: Dict[str, Any]) -> str:
    tmp = dict(bundle)
    tmp.pop("digest", None)
    tmp.pop("sig", None)
    return sha256_pref(jcs(tmp))


def verify_gossip_bundle(bundle: Dict[str, Any], policy: Dict[str, Any], *, expected_log_id: str, expected_tree_size: int, expected_payload_sha_hex: str | None) -> Tuple[bool, List[str], Dict[str, Any]]:
    """Verify a docf-snl-gossip-bundle-v0.

    If expected_payload_sha_hex is provided, bind the observation to that exact
    checkpoint payload hash (strict mode). If it is None/empty, verify the
    bundle and checkpoint signature but do not require a payload hash match
    (loose mode, used for split-view detection).
    """
    reasons: List[str] = []
    summary: Dict[str, Any] = {}

    if bundle.get("schema") != "docf-snl-gossip-bundle-v0":
        reasons.append("wrong_schema")
        return False, reasons, summary

    d_expected = digest_gossip_bundle_unsigned(bundle)
    d_got = str(bundle.get("digest", "") or "")
    if d_got != d_expected:
        reasons.append("bad_bundle_digest")
        return False, reasons, summary

    try:
        obs = bundle.get("observer") or {}
        pub_raw = base64.b64decode(str(obs.get("public_key_ed25519_raw_b64", "")) or "")
        sig = base64.b64decode(str(bundle.get("sig", "")) or "")
        Ed25519PublicKey.from_public_bytes(pub_raw).verify(sig, d_got.encode("utf-8"))
    except Exception as e:
        reasons.append(f"bad_bundle_signature:{e}")
        return False, reasons, summary

    oid = str((bundle.get("observer") or {}).get("observer_id", "") or "")
    summary["observer_id"] = oid
    summary["bundle_digest"] = d_got

    # Observer allowlist / revocation.
    revoked = set(policy.get("revoked_gossip_observer_ids") or [])
    if oid and oid in revoked:
        reasons.append("observer_revoked")
        return False, reasons, summary

    if bool(policy.get("enforce_gossip_allowlist", False)):
        allowed = policy.get("allowed_gossip_observers") or []
        allow_map = {str(a.get("observer_id","")): str(a.get("public_key_ed25519_raw_b64","")) for a in allowed}
        if oid not in allow_map:
            reasons.append("observer_not_allowlisted")
            return False, reasons, summary
        # Key pin
        got_pk = str((bundle.get("observer") or {}).get("public_key_ed25519_raw_b64","") or "")
        if allow_map.get(oid) and got_pk != allow_map.get(oid):
            reasons.append("observer_key_mismatch")
            return False, reasons, summary

    # Validity window of observer key (best-effort).
    now = policy_now(policy)
    try:
        ob = bundle.get("observer") or {}
        if ob.get("not_before") and ob.get("not_after"):
            nb = rfc3339_to_dt(str(ob.get("not_before")))
            na = rfc3339_to_dt(str(ob.get("not_after")))
            if not (nb <= now <= na):
                reasons.append("observer_key_outside_validity_window")
                return False, reasons, summary
    except Exception:
        # ignore parse failures; allow policy to pin keys instead
        pass

    # Bind to checkpoint payload (strict mode) or just parse it (loose mode).
    obs0 = (bundle.get("observations") or [{}])[0] if (bundle.get("observations") or []) else {}
    chk = obs0.get("checkpoint") or {}
    ph = str(obs0.get("checkpoint_payload_sha256_hex", "") or "")
    summary["checkpoint_payload_sha256_hex"] = ph
    if expected_payload_sha_hex is not None and str(expected_payload_sha_hex or "") != "":
        if ph != expected_payload_sha_hex:
            reasons.append("payload_hash_mismatch")
            return False, reasons, summary

    if str(bundle.get("log_id","") or "") != expected_log_id:
        reasons.append("log_id_mismatch")
        return False, reasons, summary

    ts = int(chk.get("tree_size", 0) or 0)
    if ts != int(expected_tree_size):
        reasons.append("tree_size_mismatch")
        return False, reasons, summary

    # Check that the payload hash matches the checkpoint contents.
    ph2 = checkpoint_payload_sha256_hex(chk)
    if ph2 != ph:
        reasons.append("payload_hash_recompute_mismatch")
        return False, reasons, summary

    # Verify the log signature on the checkpoint.
    if not verify_sth_signature(chk):
        reasons.append("checkpoint_signature_invalid")
        return False, reasons, summary

    summary["root_hash_sha256_b64"] = chk.get("root_hash_sha256_b64", "")
    summary["checkpoint_issued_at"] = chk.get("issued_at", "")
    return True, reasons, summary


def digest_gossip_accumulator_unsigned(acc: Dict[str, Any]) -> str:
    tmp = dict(acc)
    tmp.pop("digest", None)
    tmp.pop("sig", None)
    return sha256_pref(jcs(tmp))


def verify_gossip_accumulator(
    acc: Dict[str, Any],
    policy: Dict[str, Any],
    *,
    expected_log_id: str,
    expected_tree_size: int,
    expected_payload_sha_hex: str,
) -> Tuple[bool, List[str], Dict[str, Any]]:
    """Verify an optimistic gossip accumulator (monitor-only hint)."""
    reasons: List[str] = []
    summary: Dict[str, Any] = {}

    if acc.get("schema") != "docf-snl-gossip-accumulator-v0":
        reasons.append("wrong_schema")
        return False, reasons, summary

    d_expected = digest_gossip_accumulator_unsigned(acc)
    d_got = str(acc.get("digest", "") or "")
    if d_got != d_expected:
        reasons.append("bad_accumulator_digest")
        return False, reasons, summary

    try:
        issuer = acc.get("issuer") or {}
        pub_raw = base64.b64decode(str(issuer.get("public_key_ed25519_raw_b64", "")) or "")
        sig = base64.b64decode(str(acc.get("sig", "")) or "")
        Ed25519PublicKey.from_public_bytes(pub_raw).verify(sig, d_got.encode("utf-8"))
    except Exception as e:
        reasons.append(f"bad_accumulator_signature:{e}")
        return False, reasons, summary

    aid = str((acc.get("issuer") or {}).get("accumulator_id", "") or "")
    summary["accumulator_id"] = aid
    summary["accumulator_digest"] = d_got

    if bool(policy.get("enforce_accumulator_allowlist", False)):
        allowed = policy.get("allowed_accumulator_issuers") or []
        allow_map = {str(a.get("accumulator_id","")): str(a.get("public_key_ed25519_raw_b64","")) for a in allowed}
        if aid not in allow_map:
            reasons.append("accumulator_not_allowlisted")
            return False, reasons, summary
        got_pk = str((acc.get("issuer") or {}).get("public_key_ed25519_raw_b64","") or "")
        if allow_map.get(aid) and got_pk != allow_map.get(aid):
            reasons.append("accumulator_key_mismatch")
            return False, reasons, summary

    # Bind to expected checkpoint payload.
    if str(acc.get("log_id","") or "") != expected_log_id:
        reasons.append("log_id_mismatch")
        return False, reasons, summary
    if int(acc.get("tree_size", 0) or 0) != int(expected_tree_size):
        reasons.append("tree_size_mismatch")
        return False, reasons, summary
    if str(acc.get("checkpoint_payload_sha256_hex","") or "") != expected_payload_sha_hex:
        reasons.append("payload_hash_mismatch")
        return False, reasons, summary

    entries = acc.get("entries") or []
    if not isinstance(entries, list) or len(entries) == 0:
        reasons.append("no_entries")
        return False, reasons, summary

    # Verify at least one sample inclusion proof (spot-check).
    root_b64 = str(acc.get("merkle_root_sha256_b64","") or "")
    try:
        root_raw = base64.b64decode(root_b64) if root_b64 else b""
    except Exception:
        root_raw = b""
    if not root_raw:
        reasons.append("missing_merkle_root")
        return False, reasons, summary

    sample = acc.get("sample") or []
    ok_any_sample = False
    for s in sample:
        try:
            oid = str(s.get("observer_id","") or "")
            leaf_index = int(s.get("leaf_index", 0) or 0)
            path_b64 = s.get("inclusion_path_sha256_b64") or []
            if leaf_index >= len(entries):
                continue
            e = entries[leaf_index]
            if str(e.get("observer_id","") or "") != oid:
                continue
            # Recompute leaf hash from entry preimage.
            pre = jcs({"observer_id": e["observer_id"], "bundle_digest": e["bundle_digest"]})
            leaf_hash = ct_leaf_hash(pre)
            path = [base64.b64decode(x) for x in path_b64]
            if not verify_rfc9162_inclusion(leaf_index, len(entries), leaf_hash, path, root_raw):
                continue
            # Spot-check that the included bundle verifies and matches the entry digest.
            b = s.get("bundle") or {}
            okb, _, _ = verify_gossip_bundle(b, policy, expected_log_id=expected_log_id, expected_tree_size=expected_tree_size, expected_payload_sha_hex=expected_payload_sha_hex)
            if not okb:
                continue
            if str(b.get("digest","") or "") != str(e.get("bundle_digest","") or ""):
                continue
            ok_any_sample = True
            break
        except Exception:
            continue

    if not ok_any_sample:
        reasons.append("no_valid_sample_inclusion")
        return False, reasons, summary

    summary["entries"] = len(entries)
    summary["sample_ok"] = True
    return True, reasons, summary


def eval_gossip_layer(
    policy: Dict[str, Any],
    *,
    staple_checkpoint: Dict[str, Any],
    gossip_bundles: List[Dict[str, Any]] | None,
    gossip_accumulator: Dict[str, Any] | None,
) -> Tuple[bool, bool, bool, List[Dict[str, Any]]]:
    """Return (ok_quorum, ok_accumulator, conflict, reasons)."""
    reasons: List[Dict[str, Any]] = []
    chk = staple_checkpoint or {}
    expected_log_id = str(chk.get("log_id", "") or "")
    expected_tree_size = int(chk.get("tree_size", 0) or 0)
    expected_payload_sha = checkpoint_payload_sha256_hex(chk)

    require_quorum = bool(policy.get("require_gossip_quorum", False))
    min_quorum = int(policy.get("min_gossip_quorum", 0) or 0)

    ok_quorum = False
    conflict = False

    strict_bundles: List[Dict[str, Any]] = []
    strict_summaries: List[Dict[str, Any]] = []
    loose_bundles: List[Dict[str, Any]] = []

    if gossip_bundles:
        for b in gossip_bundles:
            # Loose verification: accept structurally valid bundles even if they
            # reference a different checkpoint payload hash. Used for split-view detection.
            ok_loose, rs_loose, _summ_loose = verify_gossip_bundle(
                b,
                policy,
                expected_log_id=expected_log_id,
                expected_tree_size=expected_tree_size,
                expected_payload_sha_hex=None,
            )
            if ok_loose:
                loose_bundles.append(b)

            # Strict verification: binds to the stapled checkpoint payload hash.
            ok_strict, rs_strict, summ_strict = verify_gossip_bundle(
                b,
                policy,
                expected_log_id=expected_log_id,
                expected_tree_size=expected_tree_size,
                expected_payload_sha_hex=expected_payload_sha,
            )
            if ok_strict:
                strict_bundles.append(b)
                strict_summaries.append(summ_strict)
            else:
                # Only record failures if the bundle wasn't even loosely valid.
                if not ok_loose:
                    reasons.append({"check": "gossip_bundle", "ok": False, "details": rs_strict, "bundle_digest": b.get("digest","")})
                else:
                    reasons.append({"check": "gossip_bundle_mismatch", "ok": True, "bundle_digest": b.get("digest","")})

        # Conflict detection (split-view): look across loosely valid bundles.
        roots = set()
        for b in loose_bundles:
            obs0 = (b.get("observations") or [{}])[0] if (b.get("observations") or []) else {}
            chk2 = (obs0.get("checkpoint") or {})
            roots.add(str(chk2.get("root_hash_sha256_b64","") or ""))

        if len(roots) > 1:
            conflict = True
            proof = None
            try:
                proof = build_slashing_proof(loose_bundles)
            except Exception as e:
                proof = {"error": str(e)}
            reasons.append({"check": "gossip_conflict", "ok": False, "root_count": len(roots), "slashing_proof": proof})
        else:
            reasons.append({"check": "gossip_conflict", "ok": True, "root_count": len(roots) if roots else 0})

        # Quorum check: require k observers who saw the *same* expected checkpoint payload.
        uniq = sorted(set([str((b.get("observer") or {}).get("observer_id","")) for b in strict_bundles if (b.get("observer") or {}).get("observer_id")]))
        ok_quorum = (len(uniq) >= min_quorum) if require_quorum else (len(uniq) > 0)
        reasons.append({"check": "gossip_quorum", "ok": ok_quorum if require_quorum else True, "require": require_quorum, "min": min_quorum, "got": len(uniq), "observers": uniq, "bundle_summaries": strict_summaries})
    else:
        reasons.append({"check": "gossip_quorum", "ok": False if require_quorum else True, "require": require_quorum, "min": min_quorum, "got": 0, "observers": []})

    ok_acc = False
    if gossip_accumulator:
        oka, rs, summ = verify_gossip_accumulator(gossip_accumulator, policy, expected_log_id=expected_log_id, expected_tree_size=expected_tree_size, expected_payload_sha_hex=expected_payload_sha)
        if oka:
            ok_acc = True
            reasons.append({"check": "gossip_accumulator", "ok": True, "summary": summ})
        else:
            reasons.append({"check": "gossip_accumulator", "ok": False, "details": rs, "acc_digest": gossip_accumulator.get("digest","" )})

    return ok_quorum, ok_acc, conflict, reasons


def verify_snl(snl: Dict[str, Any]) -> Tuple[bool, List[str]]:
    """Verify digest + Ed25519 signature binding for demo SNL objects."""
    reasons: List[str] = []

    d_expected = digest_obj_unsigned(snl)
    d_got = snl.get("digest", "")
    if d_got != d_expected:
        reasons.append(f"bad_digest: expected {d_expected}, got {d_got}")
        return False, reasons

    issuer = snl.get("issuer") or {}
    pub_b64 = issuer.get("public_key_ed25519_raw_b64", "")
    sig_b64 = snl.get("sig", "")
    if not pub_b64 or not sig_b64:
        reasons.append("missing_signature_fields")
        return False, reasons

    try:
        pub = Ed25519PublicKey.from_public_bytes(base64.b64decode(pub_b64))
        sig = base64.b64decode(sig_b64)
        pub.verify(sig, d_got.encode("utf-8"))
    except Exception as e:
        reasons.append(f"bad_signature: {e}")
        return False, reasons

    return True, reasons


def verify_witness_cosignatures(
    checkpoint: Dict[str, Any],
    cos: Dict[str, Any],
    policy: Dict[str, Any],
) -> Tuple[bool, List[str]]:
    """Verify Sigsum-style witness cosignatures over the STH payload."""
    reasons: List[str] = []

    if not cos or cos.get("schema") != "docf-witness-cosignatures-v0":
        reasons.append("missing_or_bad_cosign_schema")
        return False, reasons

    payload = checkpoint_payload(checkpoint)
    payload_sha = hashlib.sha256(payload).hexdigest()
    if cos.get("payload_sha256_hex", "") != payload_sha:
        reasons.append("cosign_payload_hash_mismatch")
        return False, reasons

    now = policy_now(policy)
    revoked_ids = set(policy.get("revoked_witness_ids") or [])

    # Local trust roots: policy supplies the allowed witness set.
    allowed = policy.get("allowed_witnesses") or []
    allowed_map: Dict[str, str] = {}
    for w in allowed:
        if not (isinstance(w, dict) and w.get("witness_id") and w.get("public_key_ed25519_raw_b64")):
            continue
        wid = str(w["witness_id"])
        if wid in revoked_ids:
            continue
        nb = str(w.get("not_before", "") or "")
        na = str(w.get("not_after", "") or "")
        try:
            if nb and now < rfc3339_to_dt(nb):
                continue
            if na and now > rfc3339_to_dt(na):
                continue
        except Exception:
            continue
        allowed_map[wid] = str(w["public_key_ed25519_raw_b64"])

    # If provided, require witness keys match the local allowlist.
    enforce_allowlist = bool(policy.get("enforce_witness_allowlist", True))
    min_quorum = int(policy.get("min_witness_quorum", cos.get("required_quorum", 0) or 0))

    ok_count = 0
    for w in (cos.get("witnesses") or []):
        try:
            wid = str(w.get("witness_id", ""))
            pk_b64 = str(w.get("public_key_ed25519_raw_b64", ""))
            sig_b64 = str(w.get("signature_ed25519_b64", ""))
            if not wid or not pk_b64 or not sig_b64:
                continue
            if wid in revoked_ids:
                continue

            if enforce_allowlist:
                if wid not in allowed_map:
                    continue
                if pk_b64 != allowed_map[wid]:
                    continue

            pub = Ed25519PublicKey.from_public_bytes(base64.b64decode(pk_b64))
            pub.verify(base64.b64decode(sig_b64), payload)
            ok_count += 1
        except Exception:
            continue

    if ok_count < min_quorum:
        reasons.append(f"cosign_quorum_failed: got {ok_count}, need {min_quorum}")
        return False, reasons

    return True, reasons


def verify_snl_staple(
    snl: Dict[str, Any],
    staple: Dict[str, Any],
    policy: Dict[str, Any],
) -> Tuple[bool, List[str]]:
    """Transparency staple verification:
      - RFC9162 inclusion proof + signed checkpoint
      - optional witness cosigning quorum
      - optional RFC9162 consistency witness (append-only evidence)
      - freshness + key-rotation + revocation checks
    """
    reasons: List[str] = []

    if not staple:
        reasons.append("missing_staple")
        return False, reasons

    if staple.get("schema") not in ("docf-snl-staple-v0", "docf-snl-staple-v1"):
        reasons.append("bad_staple_schema")
        return False, reasons

    if staple.get("snl_digest", "") != snl.get("digest", ""):
        reasons.append("staple_digest_mismatch")
        return False, reasons

    w = staple.get("witness") or {}
    if w.get("schema") not in ("docf-log-inclusion-witness-v0", "docf-log-inclusion-witness-v1"):
        reasons.append("bad_witness_schema")
        return False, reasons

    log_id = ((w.get("log") or {}).get("log_id")) or ""
    allowed_logs = policy.get("allowed_log_ids") or []
    if allowed_logs and log_id not in allowed_logs:
        reasons.append(f"untrusted_log:{log_id}")
        return False, reasons

    chk = w.get("checkpoint") or {}

    # Revocation / key-rotation pins for the log signing key.
    log_keyid = checkpoint_keyid_hex(chk)
    revoked_log_keys = set(policy.get("revoked_log_keyids_sha256_hex") or [])
    if log_keyid and log_keyid in revoked_log_keys:
        reasons.append("revoked_log_key")
        return False, reasons

    allowed_log_keys = policy.get("allowed_log_keyids_by_log") or {}
    if allowed_log_keys and log_id in allowed_log_keys:
        allowed_set = set(allowed_log_keys.get(log_id) or [])
        if log_keyid not in allowed_set:
            reasons.append("untrusted_log_key")
            return False, reasons

    # Freshness: checkpoint age bound.
    now = policy_now(policy)
    max_chk_age = policy.get("max_checkpoint_age_seconds")
    if max_chk_age is not None:
        try:
            age = (now - rfc3339_to_dt(str(chk.get("issued_at", "")))).total_seconds()
            if age < 0:
                reasons.append("checkpoint_from_future")
                return False, reasons
            if age > float(max_chk_age):
                reasons.append(f"checkpoint_too_old:{age:.0f}s>{float(max_chk_age):.0f}s")
                return False, reasons
        except Exception:
            reasons.append("checkpoint_time_parse_error")
            return False, reasons

    try:
        if not verify_sth_signature(chk):
            reasons.append("bad_log_checkpoint_signature")
            return False, reasons

        # Optional Sigsum-style witness cosigning over the same checkpoint payload.
        if bool(policy.get("require_witness_cosignatures", False)):
            cos = w.get("witness_cosignatures") or {}
            ok_cos, cos_reasons = verify_witness_cosignatures(chk, cos, policy)
            if not ok_cos:
                reasons.extend(cos_reasons)
                return False, reasons

        tree_size = int(chk["tree_size"])
        leaf_index = int(w["leaf_index"])
        root = base64.b64decode(chk["root_hash_sha256_b64"])
        leaf_hash = base64.b64decode(w["leaf_hash_sha256_b64"])
        path = [base64.b64decode(x) for x in (w.get("inclusion_path_sha256_b64") or [])]

        # Leaf preimage is the ASCII SNL digest string.
        preimage = snl.get("digest", "").encode("utf-8")
        if leaf_hash != ct_leaf_hash(preimage):
            reasons.append("leaf_hash_mismatch")
            return False, reasons

        lp_hex = hashlib.sha256(preimage).hexdigest()
        if w.get("leaf_preimage_digest_sha256_hex", "") != lp_hex:
            reasons.append("leaf_preimage_digest_mismatch")
            return False, reasons

        if not verify_rfc9162_inclusion(leaf_index, tree_size, leaf_hash, path, root):
            reasons.append("bad_inclusion_path")
            return False, reasons

        # Optional RFC9162 consistency witness: anti-split-view / append-only evidence.
        if bool(policy.get("require_log_consistency", False)):
            cw = w.get("consistency_witness") or staple.get("consistency_witness") or {}
            if not cw or cw.get("schema") != "docf-log-consistency-witness-v0":
                reasons.append("missing_consistency_witness")
                return False, reasons
            c1 = cw.get("first_checkpoint") or {}
            c2 = cw.get("second_checkpoint") or {}
            if not (verify_sth_signature(c1) and verify_sth_signature(c2)):
                reasons.append("bad_consistency_checkpoint_signature")
                return False, reasons

            # Ensure the inclusion checkpoint equals the second checkpoint in the consistency witness.
            if str(c2.get("tree_size", "")) != str(chk.get("tree_size", "")) or str(c2.get("root_hash_sha256_b64", "")) != str(chk.get("root_hash_sha256_b64", "")):
                reasons.append("consistency_second_checkpoint_mismatch")
                return False, reasons

            first = int(c1["tree_size"])
            second = int(c2["tree_size"])
            first_hash = base64.b64decode(c1["root_hash_sha256_b64"])
            second_hash = base64.b64decode(c2["root_hash_sha256_b64"])
            cpath = [base64.b64decode(x) for x in (cw.get("consistency_path_sha256_b64") or [])]
            if not verify_consistency(first, first_hash, second, second_hash, cpath):
                reasons.append("bad_consistency_path")
                return False, reasons

            # Optional pin: require the first checkpoint match a locally cached/trusted head.
            pin = str(policy.get("pinned_first_checkpoint_payload_sha256_hex", "") or "")
            if pin:
                got = checkpoint_payload_sha256_hex(c1)
                if got != pin:
                    reasons.append("pinned_first_checkpoint_mismatch")
                    return False, reasons
    except Exception as e:
        reasons.append(f"staple_verify_error:{e}")
        return False, reasons

    return True, reasons


def eval_gate(
    snl: Dict[str, Any],
    policy: Dict[str, Any],
    staple: Dict[str, Any] | None = None,
    gossip_bundles: List[Dict[str, Any]] | None = None,
    gossip_accumulator: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    ok_snl, snl_reasons = verify_snl(snl)

    require_log = bool(policy.get("require_log_inclusion", False))
    ok_staple = True
    staple_reasons: List[str] = []

    # Gossip-layer evaluation state (bound to the stapled checkpoint when present).
    ok_gossip_quorum_eval = True
    ok_gossip_accumulator_eval = False
    if require_log and ok_snl:
        ok_staple, staple_reasons = verify_snl_staple(snl, staple or {}, policy)

    pol_digest = sha256_pref(jcs(policy))
    snl_digest = snl.get("digest", "")

    mode = policy.get("mode", "reuse")  # reuse|monitor
    allow_fail_closed = bool(policy.get("allow_fail_closed", False))
    require_overall_ok = bool(policy.get("require_overall_ok", True))

    min_bits_total = float(policy.get("min_security_bits_total", 0.0))
    per_min = policy.get("per_obligation_min_bits", {}) or {}

    reasons: List[Dict[str, Any]] = []

    if not ok_snl:
        reasons.append({"check": "snl_signature", "ok": False, "details": snl_reasons})
        return {
            "type": "docf-snl-gate-decision-v0",
            "created_at": "2026-02-27T00:00:00Z",
            "policy_digest": pol_digest,
            "snl_digest": snl_digest,
            "decision": "REJECT",
            "reasons": reasons,
        }

    reasons.append({"check": "snl_signature", "ok": True})

    # Policy checks on issuer key revocation + label validity / freshness.
    issuer = snl.get("issuer") or {}
    keyid = str(issuer.get("keyid", "") or "")
    revoked_issuers = set(policy.get("revoked_issuer_keyids") or [])
    if keyid and keyid in revoked_issuers:
        reasons.append({"check": "snl_issuer_revocation", "ok": False, "keyid": keyid})
        return {
            "type": "docf-snl-gate-decision-v0",
            "created_at": "2026-02-27T00:00:00Z",
            "policy_digest": pol_digest,
            "snl_digest": snl_digest,
            "decision": "REJECT",
            "reasons": reasons,
        }
    reasons.append({"check": "snl_issuer_revocation", "ok": True, "keyid": keyid})

    now = policy_now(policy)

    validity = snl.get("validity") or {}
    if validity:
        try:
            nb = rfc3339_to_dt(str(validity.get("not_before", "")))
            na = rfc3339_to_dt(str(validity.get("not_after", "")))
            ok_win = nb <= now <= na
            reasons.append({"check": "snl_validity_window", "ok": ok_win, "now": now.isoformat(), "not_before": nb.isoformat(), "not_after": na.isoformat()})
            if not ok_win:
                return {
                    "type": "docf-snl-gate-decision-v0",
                    "created_at": "2026-02-27T00:00:00Z",
                    "policy_digest": pol_digest,
                    "snl_digest": snl_digest,
                    "decision": "REJECT",
                    "reasons": reasons,
                }
        except Exception:
            reasons.append({"check": "snl_validity_window", "ok": False, "details": ["parse_error"]})
            return {
                "type": "docf-snl-gate-decision-v0",
                "created_at": "2026-02-27T00:00:00Z",
                "policy_digest": pol_digest,
                "snl_digest": snl_digest,
                "decision": "REJECT",
                "reasons": reasons,
            }
    else:
        reasons.append({"check": "snl_validity_window", "ok": True, "notes": "No validity window present."})

    max_snl_age = policy.get("max_snl_age_seconds")
    if max_snl_age is not None:
        try:
            created = rfc3339_to_dt(str(snl.get("created_at", "")))
            age = (now - created).total_seconds()
            ok_age = (0 <= age <= float(max_snl_age))
            reasons.append({"check": "snl_freshness", "ok": ok_age, "age_seconds": age, "max": float(max_snl_age)})
            if not ok_age:
                return {
                    "type": "docf-snl-gate-decision-v0",
                    "created_at": "2026-02-27T00:00:00Z",
                    "policy_digest": pol_digest,
                    "snl_digest": snl_digest,
                    "decision": "REJECT",
                    "reasons": reasons,
                }
        except Exception:
            reasons.append({"check": "snl_freshness", "ok": False, "details": ["parse_error"]})
            return {
                "type": "docf-snl-gate-decision-v0",
                "created_at": "2026-02-27T00:00:00Z",
                "policy_digest": pol_digest,
                "snl_digest": snl_digest,
                "decision": "REJECT",
                "reasons": reasons,
            }

    if require_log:
        if not ok_staple:
            reasons.append({"check": "snl_log_inclusion", "ok": False, "details": staple_reasons})
            return {
                "type": "docf-snl-gate-decision-v0",
                "created_at": "2026-02-27T00:00:00Z",
                "policy_digest": pol_digest,
                "snl_digest": snl_digest,
                "decision": "REJECT",
                "reasons": reasons,
            }
        # Provide a compact summary of the verified staple so downstream systems can log/cache it.
        staple_summary = {}
        try:
            w = (staple or {}).get("witness") or {}
            chk = w.get("checkpoint") or {}
            staple_summary["log_id"] = ((w.get("log") or {}).get("log_id")) or ""
            staple_summary["tree_size"] = int(chk.get("tree_size", 0) or 0)
            staple_summary["checkpoint_issued_at"] = chk.get("issued_at", "")
            staple_summary["log_keyid_sha256_hex"] = checkpoint_keyid_hex(chk)
            max_chk_age = policy.get("max_checkpoint_age_seconds")
            if max_chk_age is not None and chk.get("issued_at"):
                age = (policy_now(policy) - rfc3339_to_dt(str(chk.get("issued_at")))).total_seconds()
                staple_summary["checkpoint_age_seconds"] = age
                staple_summary["max_checkpoint_age_seconds"] = float(max_chk_age)
            if bool(policy.get("require_witness_cosignatures", False)):
                cos = w.get("witness_cosignatures") or {}
                staple_summary["witness_required_quorum"] = int(cos.get("required_quorum", 0) or 0)
                staple_summary["witness_count"] = len(cos.get("witnesses") or [])
            if bool(policy.get("require_log_consistency", False)):
                cw = w.get("consistency_witness") or {}
                c1 = cw.get("first_checkpoint") or {}
                c2 = cw.get("second_checkpoint") or {}
                staple_summary["consistency"] = {
                    "first_tree_size": int(c1.get("tree_size", 0) or 0),
                    "second_tree_size": int(c2.get("tree_size", 0) or 0),
                    "path_len": len(cw.get("consistency_path_sha256_b64") or []),
                    "pin_required": bool(policy.get("pinned_first_checkpoint_payload_sha256_hex", "")),
                }
        except Exception:
            staple_summary = {"error": "summary_failed"}

        reasons.append(
            {
                "check": "snl_log_inclusion",
                "ok": True,
                "log_ids": policy.get("allowed_log_ids", []),
                "require_witness_cosignatures": bool(policy.get("require_witness_cosignatures", False)),
                "require_log_consistency": bool(policy.get("require_log_consistency", False)),
                "staple_summary": staple_summary,
            }
        )
        # Optional: checkpoint gossip layer (anti-split-view across clients).
        if bool(policy.get("require_gossip_quorum", False)) or bool(policy.get("allow_accumulator_for_monitor", False)):
            try:
                w = (staple or {}).get("witness") or {}
                chk = w.get("checkpoint") or {}
                okq, oka, conflict, greasons = eval_gossip_layer(
                    policy,
                    staple_checkpoint=chk,
                    gossip_bundles=gossip_bundles,
                    gossip_accumulator=gossip_accumulator,
                )
                reasons.extend(greasons)
                if conflict:
                    # Split-view evidence should fail closed regardless of mode.
                    return {
                        "type": "docf-snl-gate-decision-v0",
                        "created_at": "2026-02-27T00:00:00Z",
                        "policy_digest": pol_digest,
                        "snl_digest": snl_digest,
                        "decision": "REJECT",
                        "reasons": reasons,
                    }
                # Stash for final hard_ok.
                ok_gossip_quorum_eval = bool(okq)
                ok_gossip_accumulator_eval = bool(oka)
            except Exception as e:
                reasons.append({"check": "gossip_layer", "ok": False, "details": [f"exception:{e}"]})
                ok_gossip_quorum_eval = False
                ok_gossip_accumulator_eval = False


    overall = snl.get("overall") or {}
    overall_status = overall.get("status", "fail_closed")

    if require_overall_ok and overall_status != "ok":
        reasons.append({"check": "overall_status_ok", "ok": False, "got": overall_status})
    else:
        reasons.append({"check": "overall_status_ok", "ok": True, "got": overall_status})

    bits_total = float(overall.get("security_bits_total", 0.0)) if overall_status == "ok" else 0.0
    ok_total = (bits_total >= min_bits_total) if overall_status == "ok" else False
    reasons.append({"check": "min_security_bits_total", "ok": ok_total, "min": min_bits_total, "got": bits_total})

    obligations = snl.get("obligations") or []
    ob_map = {o.get("obligation_id"): o for o in obligations}

    per_ok = True
    for oid, min_bits in per_min.items():
        o = ob_map.get(oid)
        if o is None:
            per_ok = False
            reasons.append({"check": "obligation_present", "ok": False, "obligation_id": oid})
            continue
        if o.get("status") != "ok":
            per_ok = False
            reasons.append({"check": "obligation_resolved", "ok": False, "obligation_id": oid, "status": o.get("status")})
            continue
        b = float(o.get("ggc_adjusted_security_bits", o.get("resolved_security_bits", 0.0)))
        okb = b >= float(min_bits)
        per_ok = per_ok and okb
        reasons.append({"check": "obligation_min_bits", "ok": okb, "obligation_id": oid, "min": float(min_bits), "got": b})

    any_fail_closed = any((o.get("status") != "ok") for o in obligations)
    if any_fail_closed and not allow_fail_closed:
        reasons.append({"check": "allow_fail_closed", "ok": False, "allow": False})
    else:
        reasons.append({"check": "allow_fail_closed", "ok": True, "allow": allow_fail_closed})

    hard_ok = (
        ok_snl
        and (overall_status == "ok" if require_overall_ok else True)
        and ok_total
        and per_ok
        and (not any_fail_closed or allow_fail_closed)
        and (ok_staple if require_log else True)
        and (ok_gossip_quorum_eval if bool(policy.get("require_gossip_quorum", False)) else True)
    )

    if hard_ok and mode == "reuse":
        decision = "ACCEPT_REUSE"
    elif hard_ok and mode == "monitor":
        decision = "ACCEPT_MONITOR"
    else:
        if mode == "monitor" or allow_fail_closed:
            decision = "ACCEPT_MONITOR"
        else:
            decision = "REJECT"

    return {
        "type": "docf-snl-gate-decision-v0",
        "created_at": "2026-02-27T00:00:00Z",
        "policy_digest": pol_digest,
        "snl_digest": snl_digest,
        "decision": decision,
        "reasons": reasons,
        "notes": "Reference gate decision computed from SNL + local policy; not a production verifier.",
    }


def emit_demo() -> None:
    os.makedirs("test_vectors", exist_ok=True)

    reuse_policy = {
        "type": "docf-snl-gate-policy-v0",
        "version": "0",
        "mode": "reuse",
        "now_rfc3339": "2026-02-27T00:02:00Z",
        "require_overall_ok": True,
        "allow_fail_closed": False,
        "min_security_bits_total": 90,
        "per_obligation_min_bits": {
            "cancel_power_basis_glue": 90,
            "market_reauction_deadline_surface": 80,
            "statement_selection_surface": 80,
        },
        "revoked_issuer_keyids": [],
        "max_snl_age_seconds": 86400,
        "notes": "Strict reuse gate: require all obligations resolved and >= thresholds.",
    }

    monitor_policy = {
        "type": "docf-snl-gate-policy-v0",
        "version": "0",
        "mode": "monitor",
        "now_rfc3339": "2026-02-27T00:02:00Z",
        "require_overall_ok": False,
        "allow_fail_closed": True,
        "min_security_bits_total": 0,
        "per_obligation_min_bits": {},
        "revoked_issuer_keyids": [],
        "max_snl_age_seconds": 86400,
        "notes": "Monitor-only gate: tolerate fail-closed and treat label as telemetry rather than cache permission.",
    }

    # Reuse policy with transparency requirement.
    reuse_policy_with_log = dict(reuse_policy)
    reuse_policy_with_log["require_log_inclusion"] = True
    reuse_policy_with_log["allowed_log_ids"] = ["docf-demo-snl-tlog-v0"]
    reuse_policy_with_log["max_checkpoint_age_seconds"] = 3600
    reuse_policy_with_log["revoked_log_keyids_sha256_hex"] = []
    reuse_policy_with_log["allowed_log_keyids_by_log"] = {"docf-demo-snl-tlog-v0": []}
    reuse_policy_with_log["notes"] = "Strict reuse gate + transparency: require SNL inclusion in an allowed append-only log."

    # Reuse policy with transparency + witness cosigning.
    demo_allowed_witnesses = []
    for i in range(3):
        demo_allowed_witnesses.append({"witness_id": f"docf-demo-witness-{i}", "public_key_ed25519_raw_b64": ""})

    reuse_policy_with_log_quorum = dict(reuse_policy_with_log)
    reuse_policy_with_log_quorum["require_witness_cosignatures"] = True
    reuse_policy_with_log_quorum["min_witness_quorum"] = 2
    reuse_policy_with_log_quorum["enforce_witness_allowlist"] = True
    reuse_policy_with_log_quorum["allowed_witnesses"] = demo_allowed_witnesses
    reuse_policy_with_log_quorum["revoked_witness_ids"] = []
    reuse_policy_with_log_quorum["notes"] = "Strict reuse + transparency + 2-of-3 witness cosigning (Sigsum-style)."

    # Reuse policy with transparency + quorum + append-only consistency (anti-split-view).
    reuse_policy_with_log_consistency = dict(reuse_policy_with_log_quorum)
    reuse_policy_with_log_consistency["require_log_consistency"] = True
    reuse_policy_with_log_consistency["pinned_first_checkpoint_payload_sha256_hex"] = ""
    reuse_policy_with_log_consistency["notes"] = (
        "Strict reuse + transparency + 2-of-3 witness cosigning + RFC9162 consistency witness (append-only evidence)."
    )

    with open("test_vectors/snl_gate_policy_reuse_demo.json", "w", encoding="utf-8") as f:
        json.dump(reuse_policy, f, indent=2, sort_keys=True)
        f.write("\n")

    with open("test_vectors/snl_gate_policy_monitor_demo.json", "w", encoding="utf-8") as f:
        json.dump(monitor_policy, f, indent=2, sort_keys=True)
        f.write("\n")

    with open("test_vectors/snl_gate_policy_reuse_with_log_demo.json", "w", encoding="utf-8") as f:
        json.dump(reuse_policy_with_log, f, indent=2, sort_keys=True)
        f.write("\n")

    with open("test_vectors/snl_gate_policy_reuse_with_log_quorum_demo.json", "w", encoding="utf-8") as f:
        json.dump(reuse_policy_with_log_quorum, f, indent=2, sort_keys=True)
        f.write("\n")

    with open("test_vectors/snl_gate_policy_reuse_with_log_consistency_demo.json", "w", encoding="utf-8") as f:
        json.dump(reuse_policy_with_log_consistency, f, indent=2, sort_keys=True)
        f.write("\n")

    # Decisions
    snl_fail = load_json("test_vectors/security_nutrition_label_demo.json")
    d_reuse = eval_gate(snl_fail, reuse_policy)
    d_mon = eval_gate(snl_fail, monitor_policy)

    snl_ok = load_json("test_vectors/security_nutrition_label_demo_ok.json")
    staple = load_json("test_vectors/snl_staple_demo.json") if os.path.exists("test_vectors/snl_staple_demo.json") else None

    # Patch the quorum/consistency policies with witness keys and pinned checkpoints from the staple.
    if staple:
        w = staple.get("witness") or {}
        chk = w.get("checkpoint") or {}
        log_keyid = checkpoint_keyid_hex(chk)

        cos = (w.get("witness_cosignatures") or {})
        ws = cos.get("witnesses") or []
        key_map = {ww.get("witness_id"): ww.get("public_key_ed25519_raw_b64") for ww in ws}

        cw = w.get("consistency_witness") or {}
        c1 = cw.get("first_checkpoint") or {}

        polq = load_json("test_vectors/snl_gate_policy_reuse_with_log_quorum_demo.json")
        for ww in polq.get("allowed_witnesses", []):
            wid = ww.get("witness_id")
            if wid in key_map:
                ww["public_key_ed25519_raw_b64"] = key_map[wid]
        polq["allowed_log_keyids_by_log"] = {chk.get("log_id",""): [log_keyid]}

        with open("test_vectors/snl_gate_policy_reuse_with_log_quorum_demo.json", "w", encoding="utf-8") as f:
            json.dump(polq, f, indent=2, sort_keys=True)
            f.write("\n")
        reuse_policy_with_log_quorum = polq

        polc = load_json("test_vectors/snl_gate_policy_reuse_with_log_consistency_demo.json")
        for ww in polc.get("allowed_witnesses", []):
            wid = ww.get("witness_id")
            if wid in key_map:
                ww["public_key_ed25519_raw_b64"] = key_map[wid]
        polc["allowed_log_keyids_by_log"] = {chk.get("log_id",""): [log_keyid]}
        polc["pinned_first_checkpoint_payload_sha256_hex"] = checkpoint_payload_sha256_hex(c1)
        with open("test_vectors/snl_gate_policy_reuse_with_log_consistency_demo.json", "w", encoding="utf-8") as f:
            json.dump(polc, f, indent=2, sort_keys=True)
            f.write("\n")
        reuse_policy_with_log_consistency = polc

    d_reuse_log = eval_gate(snl_ok, reuse_policy_with_log, staple=staple)
    d_reuse_log_quorum = eval_gate(snl_ok, reuse_policy_with_log_quorum, staple=staple)
    d_reuse_log_consistency = eval_gate(snl_ok, reuse_policy_with_log_consistency, staple=staple)

    with open("test_vectors/snl_gate_decision_reuse_demo.json", "w", encoding="utf-8") as f:
        json.dump(d_reuse, f, indent=2, sort_keys=False)
        f.write("\n")

    with open("test_vectors/snl_gate_decision_monitor_demo.json", "w", encoding="utf-8") as f:
        json.dump(d_mon, f, indent=2, sort_keys=False)
        f.write("\n")

    with open("test_vectors/snl_gate_decision_reuse_with_log_demo.json", "w", encoding="utf-8") as f:
        json.dump(d_reuse_log, f, indent=2, sort_keys=False)
        f.write("\n")

    with open("test_vectors/snl_gate_decision_reuse_with_log_quorum_demo.json", "w", encoding="utf-8") as f:
        json.dump(d_reuse_log_quorum, f, indent=2, sort_keys=False)
        f.write("\n")

    with open("test_vectors/snl_gate_decision_reuse_with_log_consistency_demo.json", "w", encoding="utf-8") as f:
        json.dump(d_reuse_log_consistency, f, indent=2, sort_keys=False)
        f.write("\n")

    
    # --- v86.8: gossip quorum + optimistic accumulator demos (if vectors exist) ---
    if os.path.exists("test_vectors/snl_gossip_bundle_A_demo.json") and staple:
        gbA = load_json("test_vectors/snl_gossip_bundle_A_demo.json")
        gbB = load_json("test_vectors/snl_gossip_bundle_B_demo.json")
        gbB_conf = load_json("test_vectors/snl_gossip_bundle_B_conflict_demo.json")

        # Build a strict reuse policy that also requires a 2-of-N gossip quorum.
        polg = dict(reuse_policy_with_log_consistency)
        polg["require_gossip_quorum"] = True
        polg["min_gossip_quorum"] = 2
        polg["enforce_gossip_allowlist"] = True
        polg["revoked_gossip_observer_ids"] = []
        polg["allowed_gossip_observers"] = []
        for b in [gbA, gbB]:
            ob = b.get("observer") or {}
            polg["allowed_gossip_observers"].append(
                {"observer_id": ob.get("observer_id", ""), "public_key_ed25519_raw_b64": ob.get("public_key_ed25519_raw_b64", "")}
            )
        polg["notes"] = (
            "Strict reuse + transparency + witness cosigning + consistency proof + CT-style gossip quorum over the stapled checkpoint."
        )

        with open("test_vectors/snl_gate_policy_reuse_with_log_consistency_gossip_demo.json", "w", encoding="utf-8") as f:
            json.dump(polg, f, indent=2, sort_keys=True)
            f.write("\n")

        d_reuse_log_consistency_gossip = eval_gate(snl_ok, polg, staple=staple, gossip_bundles=[gbA, gbB])
        with open("test_vectors/snl_gate_decision_reuse_with_log_consistency_gossip_demo.json", "w", encoding="utf-8") as f:
            json.dump(d_reuse_log_consistency_gossip, f, indent=2, sort_keys=False)
            f.write("\n")

        # Conflict case: one observer sees a conflicting checkpoint at the same tree_size.
        d_reuse_log_consistency_gossip_conf = eval_gate(snl_ok, polg, staple=staple, gossip_bundles=[gbA, gbB_conf])
        with open("test_vectors/snl_gate_decision_reuse_with_log_consistency_gossip_conflict_demo.json", "w", encoding="utf-8") as f:
            json.dump(d_reuse_log_consistency_gossip_conf, f, indent=2, sort_keys=False)
            f.write("\n")

    # Monitor-only policy that accepts an optimistic accumulator (deferred audit), if present.
    if os.path.exists("test_vectors/snl_gossip_accumulator_demo.json") and staple:
        acc = load_json("test_vectors/snl_gossip_accumulator_demo.json")
        polm = dict(monitor_policy)
        polm["require_log_inclusion"] = True
        polm["allowed_log_ids"] = ["docf-demo-snl-tlog-v0"]
        polm["max_checkpoint_age_seconds"] = 3600
        polm["allow_accumulator_for_monitor"] = True
        polm["enforce_accumulator_allowlist"] = True
        polm["allowed_accumulator_issuers"] = [
            {
                "accumulator_id": (acc.get("issuer") or {}).get("accumulator_id", ""),
                "public_key_ed25519_raw_b64": (acc.get("issuer") or {}).get("public_key_ed25519_raw_b64", ""),
            }
        ]
        polm["notes"] = "Monitor gate + transparency + accept an optimistic accumulator as a hint for deferred audit (never enough for reuse)."
        with open("test_vectors/snl_gate_policy_monitor_with_log_accumulator_demo.json", "w", encoding="utf-8") as f:
            json.dump(polm, f, indent=2, sort_keys=True)
            f.write("\n")

        d_mon_acc = eval_gate(snl_ok, polm, staple=staple, gossip_accumulator=acc)
        with open("test_vectors/snl_gate_decision_monitor_with_log_accumulator_demo.json", "w", encoding="utf-8") as f:
            json.dump(d_mon_acc, f, indent=2, sort_keys=False)
            f.write("\n")
    print("Wrote demo gate policies and decisions under test_vectors/")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--snl", help="Path to security nutrition label JSON")
    ap.add_argument("--policy", help="Path to gate policy JSON")
    ap.add_argument("--staple", help="Optional path to SNL staple JSON", default="")
    ap.add_argument("--gossip-bundles", nargs="*", default=[], help="Optional list of gossip bundle JSON files (anti-split-view)")
    ap.add_argument("--gossip-accumulator", default="", help="Optional gossip accumulator JSON file (monitor-only hint)")
    ap.add_argument("--out", help="Output path for decision JSON")
    ap.add_argument("--emit-demo", action="store_true", help="Write demo policies + decisions under test_vectors/")
    args = ap.parse_args()

    if args.emit_demo:
        emit_demo()
        return

    if not (args.snl and args.policy and args.out):
        raise SystemExit("Provide --snl, --policy, --out (and optionally --staple), or use --emit-demo.")

    snl = load_json(args.snl)
    pol = load_json(args.policy)
    staple_obj = load_json(args.staple) if args.staple else None
    gb = [load_json(p) for p in args.gossip_bundles] if getattr(args, "gossip_bundles", None) else None
    ga = load_json(args.gossip_accumulator) if getattr(args, "gossip_accumulator", "") else None
    decision = eval_gate(snl, pol, staple=staple_obj, gossip_bundles=gb, gossip_accumulator=ga)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(decision, f, indent=2, sort_keys=False)
        f.write("\n")


if __name__ == "__main__":
    main()
