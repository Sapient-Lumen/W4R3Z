#!/usr/bin/env python3
"""
risk_quote_ref.py

Reference tool for computing a conservative "premium" bound from a soundness bound.

We model loss from invalid accepts as:
  Loss = L * X
where X is the number of invalid accepts in a window and L is a (worst-case) loss
per invalid accept. For portability, we use coarse upper bounds:
  E[X] <= eps_cm + N * eps_total_per_proof
and (if we assume per-proof Bernoulli variability for the independent part):
  Var[X] <= N * p * (1-p)  where p = eps_total_per_proof.

We then support two premium principles:
  expected_value:      Premium = E[Loss]
  variance_principle:  Premium = E[Loss] + beta * Var[Loss]
where Var[Loss] = L^2 * Var[X].

This is not meant to be actuarially correct; it is a governance artifact that makes
the *assumptions* and *loadings* explicit and machine-checkable.

Usage:
  ./risk_quote_ref.py compute <input.json>
  ./risk_quote_ref.py verify  <input.json>
"""
from __future__ import annotations

import json
import math
import sys
from typing import Any, Dict


def compute(obj: Dict[str, Any]) -> Dict[str, Any]:
    N = int(obj["max_proofs"])
    win_s = int(obj["window_seconds"])
    L = float(obj["loss_per_invalid_accept"])
    p = float(obj["eps_total_per_proof_bound"])
    eps_cm = float(obj.get("eps_common_mode_bound", 0.0))
    principle = obj["premium_principle"]
    beta = float(obj.get("loading_beta", 0.0))

    # Expected number of invalid accepts bound (union bound + reserved common-mode).
    exp_X = min(float("inf"), eps_cm + (N * p))
    exp_loss = L * exp_X

    # Variance bound for the independent part (Bernoulli-ish); clamp p in [0,1].
    pp = min(1.0, max(0.0, p))
    var_X = (N * pp * (1.0 - pp)) if N > 0 else 0.0
    var_loss = (L * L) * var_X

    if principle == "expected_value":
        prem = exp_loss
    elif principle == "variance_principle":
        prem = exp_loss + beta * var_loss
    else:
        raise ValueError("unknown premium_principle")

    mult = (prem / exp_loss) if exp_loss > 0 else float("inf")

    out = dict(obj)
    out["type"] = "docf-risk-quote-v0"
    out["version"] = "0"
    out["computed"] = {
        "expected_loss_bound": exp_loss,
        "variance_bound": var_loss,
        "premium_bound": prem,
        "premium_multiple_of_expected_loss": mult,
    }
    return out


def verify(obj: Dict[str, Any]) -> None:
    out = compute(obj)
    got = obj.get("computed", {})
    want = out["computed"]
    prem_ok = abs(float(got.get("premium_bound", -1.0)) - want["premium_bound"]) <= 1e-9
    el_ok = abs(float(got.get("expected_loss_bound", -1.0)) - want["expected_loss_bound"]) <= 1e-9
    if not (prem_ok and el_ok):
        raise SystemExit(f"verify failed\nwant={want}\ngot={got}\n")


def main(argv: list[str]) -> None:
    if len(argv) < 3 or argv[1] not in ("compute", "verify"):
        print("Usage: risk_quote_ref.py compute|verify <input.json>", file=sys.stderr)
        raise SystemExit(2)
    cmd, path = argv[1], argv[2]
    with open(path, "r", encoding="utf-8") as f:
        obj = json.load(f)
    if cmd == "verify":
        verify(obj)
        print("OK")
        return
    out = compute(obj)
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == "__main__":
    main(sys.argv)
