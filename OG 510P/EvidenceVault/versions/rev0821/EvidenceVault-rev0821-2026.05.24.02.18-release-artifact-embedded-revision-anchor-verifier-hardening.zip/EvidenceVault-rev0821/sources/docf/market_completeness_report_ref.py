#!/usr/bin/env python3
"""Reference tool: produce a Market Completeness Report (MCR) from a receipt bundle.

Goal: make the *mechanical* question "is this receipt bundle attempt-complete?" explicit.

This tool is intentionally conservative. It does not assume the market is honest; it only checks
internal consistency and whether the bundle contains the kinds of receipts an auditor would need
to *count* attempts.

Input (toy): a JSON file like market_session_receipts_example.json containing
  - sid (string)
  - selection_receipts (list of refs/paths)
  - attempt_receipts (list of per-attempt terminal events)

Output: docf_market_completeness_report v0-like object:
  - Q_observed: number of distinct attempt ids
  - checks: booleans for a small checklist
  - attempts: normalized per-attempt summaries

Deployments should bind receipt_ref fields to on-chain events / transparency-log inclusion proofs.
"""

import argparse
import hashlib
import json
from typing import Any, Dict, List, Tuple


TERMINAL_EVENTS = {
    "timeout": "timeout",
    "cancel": "cancelled",
    "cancelled": "cancelled",
    "slashed": "slashed",
    "proved": "proved",
    "success": "proved",
    "failed": "failed",
    "reject": "failed",
}


def jcs_bytes(x: Any) -> bytes:
    # Best-effort RFC8785-style canonicalization.
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_hex_pref(x: Any) -> str:
    return "sha256:" + hashlib.sha256(jcs_bytes(x)).hexdigest()


def normalize_attempts(attempt_receipts: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[str]]:
    missing: List[str] = []
    out: List[Dict[str, Any]] = []
    for i, ev in enumerate(attempt_receipts):
        if not isinstance(ev, dict):
            raise ValueError("attempt_receipts must be a list of objects")
        aid = ev.get("attempt_id")
        if not isinstance(aid, str) or not aid:
            raise ValueError(f"attempt_receipts[{i}] missing attempt_id")
        raw = ev.get("event") or ev.get("status")
        if not isinstance(raw, str) or not raw:
            raise ValueError(f"attempt {aid} missing event/status")
        key = raw.lower()
        status = TERMINAL_EVENTS.get(key)
        if status is None:
            missing.append(f"non_terminal_or_unknown_event:{aid}:{raw}")
            status = "unknown"
        witnessed = bool(ev.get("receipt_ref") or ev.get("tx") or ev.get("log_receipt"))
        rec = {
            "attempt_id": aid,
            "status": status,
            "witnessed": witnessed,
        }
        if "round" in ev:
            rec["round"] = ev["round"]
        if "receipt_ref" in ev:
            rec["receipt_ref"] = ev["receipt_ref"]
        out.append(rec)
    return out, missing


def monotone_rounds(attempts: List[Dict[str, Any]]) -> bool:
    rounds = [a.get("round") for a in attempts if isinstance(a.get("round"), int)]
    if not rounds:
        return True
    # Nondecreasing is sufficient for a toy check.
    return all(rounds[i] <= rounds[i + 1] for i in range(len(rounds) - 1))


def derive_report(bundle: Dict[str, Any]) -> Dict[str, Any]:
    sid = bundle.get("sid")
    if not isinstance(sid, str) or not sid:
        raise ValueError("missing required field sid")

    selection = bundle.get("selection_receipts")
    if not isinstance(selection, list) or not selection:
        # Keep going (report will show missing), but the state machine check will fail.
        selection = []

    attempt_receipts = bundle.get("attempt_receipts")
    if not isinstance(attempt_receipts, list) or not attempt_receipts:
        attempt_receipts = []

    attempts, missing = normalize_attempts(attempt_receipts) if attempt_receipts else ([], ["missing:attempt_receipts"])

    # Checks
    attempt_ids = [a["attempt_id"] for a in attempts]
    unique_attempt_ids = len(set(attempt_ids)) == len(attempt_ids)
    terminal_event_per_attempt = all(a["status"] != "unknown" for a in attempts)
    state_machine_ok = bool(selection) and bool(attempts) and (sum(1 for a in attempts if a["status"] == "proved") <= 1)
    anchoring_present = bool(bundle.get("receipt_root")) or all(a.get("witnessed", False) for a in attempts)

    checks = {
        "state_machine_ok": state_machine_ok,
        "terminal_event_per_attempt": terminal_event_per_attempt,
        "unique_attempt_ids": unique_attempt_ids,
        "monotone_round_nonces": monotone_rounds(attempts),
        "anchoring_present": anchoring_present,
    }

    receipts_digest = sha256_hex_pref(bundle)

    report: Dict[str, Any] = {
        "type": "market_completeness_report",
        "sid": sid,
        "market_id": bundle.get("market_id", ""),
        "profile_digest": bundle.get("profile_digest", ""),
        "receipts_digest": receipts_digest,
        "checks": checks,
        "attempts": attempts,
        "Q_observed": len(set(attempt_ids)),
        "eps_enforcement": float(bundle.get("eps_enforcement", 0.0)),
        "missing": missing + ([] if selection else ["missing:selection_receipts"]),
        "notes": "toy MCR: conservative structural checks only; deployments must bind receipt_ref to finality/log proofs",
        "meta": {"tool": "market_completeness_report_ref.py"},
    }

    report["digest"] = sha256_hex_pref({k: v for k, v in report.items() if k != "digest"})
    return report


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="in_path", default="market_session_receipts_example.json")
    ap.add_argument("--out", dest="out_path", default="-")
    args = ap.parse_args()

    bundle = json.load(open(args.in_path, "r", encoding="utf-8"))
    rep = derive_report(bundle)

    out = json.dumps(rep, indent=2, sort_keys=False) + "\n"
    if args.out_path == "-":
        print(out, end="")
    else:
        with open(args.out_path, "w", encoding="utf-8") as f:
            f.write(out)


if __name__ == "__main__":
    main()
