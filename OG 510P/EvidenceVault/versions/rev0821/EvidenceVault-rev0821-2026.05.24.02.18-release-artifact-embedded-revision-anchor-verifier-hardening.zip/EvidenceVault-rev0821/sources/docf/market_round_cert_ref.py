#!/usr/bin/env python3
"""market_round_cert_ref.py

Reference tool: emit a dOCF Market Round Certificate (MRC) demo object
(docf_market_round_cert_v0).

A Market Round Certificate is a minimal *selection receipt*:
- it lists the bids considered in a given round, and
- commits to the selected bid,
- with a timestamp and signature placeholder.

This archive uses the MRC as a concrete example of "what the market claims it selected"
that can be stapled into transparency logs (Paper E/F).

NOTE:
- This is a reference/demo artifact. Real deployments should use a real signature format,
  include auction parameters, and commit to full bid contents (or bid digests + opening rules).
"""

from __future__ import annotations
import argparse
import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Dict, List


def _jcs_bytes(x: Any) -> bytes:
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def _sha256_pref(x: Any) -> str:
    return "sha256:" + hashlib.sha256(_jcs_bytes(x)).hexdigest()

def demo_mrc(now: str | None = None) -> Dict[str, Any]:
    if now is None:
        now = datetime(2026, 2, 28, 12, 0, 0, tzinfo=timezone.utc).isoformat()
    bids = [
        "sha256:" + "0"*64,
        "sha256:" + "1"*64,
        "sha256:" + "2"*64,
    ]
    obj: Dict[str, Any] = {
        "type": "round_certificate",
        "job_id": "job-demo-001",
        "round": 1,
        "bids": bids,
        "selected": bids[1],
        "timestamp": now,
        "sig": "demo-sig:market"
    }
    obj["digest"] = _sha256_pref({k:v for k,v in obj.items() if k != "digest"})
    return obj


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit", action="store_true", help="emit deterministic demo Market Round Certificate")
    ap.add_argument("--out", type=str, default="test_vectors/market_round_cert_demo.json")
    args = ap.parse_args()

    if not args.emit:
        ap.print_help()
        return

    mrc = demo_mrc()
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(mrc, f, indent=2)
        f.write("\n")

    print(mrc["digest"])


if __name__ == "__main__":
    main()
