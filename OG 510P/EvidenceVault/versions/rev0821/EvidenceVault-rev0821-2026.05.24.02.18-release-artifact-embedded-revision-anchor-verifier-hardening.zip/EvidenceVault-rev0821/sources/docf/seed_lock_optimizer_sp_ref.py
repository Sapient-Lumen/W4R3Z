#!/usr/bin/env python3
"""seed_lock_optimizer_sp_ref.py

Seed-lock optimization for *series--parallel* attempt expressions.

This reference tool complements seed_lock_optimizer_ref.py:
  - seed_lock_optimizer_ref.py enumerates seed-lock sets (brute force / greedy).
  - THIS tool exploits the *series--parallel* structure of the extractor's
    attempt expression to compute an exact *frontier* efficiently.

Model:
  - The attempt-trace extractor compiles a witnessed retry skeleton into a
    series--parallel expression E over nonnegative integers using:
        add  : serial composition (union bound / "either branch happens")
        mul  : nested retry (attempt multiplication)
        min  : optional region cap
        var  : per-region retry bound \hat Q_v
        const: integer literal

  - Seed-locking an eligible region v replaces every occurrence of var(v)
    (as a seed-resampling factor) by 1 for the relevant seed group.

Frontier objective:
  For each k = 0..K, compute a best achievable Q(E) using at most k seed-locks,
  together with one witness seed-locked set S_k.

We then optionally compose Q into Theorem~\ref{thm:end2end} via end2end_resolve_ref.py
to compute the recommended minimal repetition count t for a target security level.

This file is dependency-free (besides sibling dOCF reference modules) and is
intended for auditors and paper examples.
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Set, Tuple

from docf_ref_tools_common import jcs, sha256_hex


def _fail(msg: str) -> None:
    raise SystemExit(f"[seed_lock_optimizer_sp_ref] {msg}")


def _load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _jdump(obj: Any) -> str:
    return json.dumps(obj, indent=2, sort_keys=True) + "\n"


@dataclass
class Point:
    q: int
    locked: Set[str]


Frontier = Dict[int, Point]  # locks_used -> best point


def _merge_best(dst: Frontier, k: int, q: int, locked: Set[str]) -> None:
    cur = dst.get(k)
    if cur is None or q < cur.q or (q == cur.q and len(locked) < len(cur.locked)):
        dst[k] = Point(q=q, locked=set(locked))


def _prune(front: Frontier) -> Frontier:
    """Drop dominated points (k1<=k2 and q1<=q2)."""
    ks = sorted(front.keys())
    out: Frontier = {}
    best_q = None
    for k in ks:
        q = front[k].q
        if best_q is None or q < best_q:
            out[k] = front[k]
            best_q = q
    return out


def _combine(
    a: Frontier,
    b: Frontier,
    op: str,
    k_max: int,
) -> Frontier:
    out: Frontier = {}
    for ka, pa in a.items():
        for kb, pb in b.items():
            k = ka + kb
            if k > k_max:
                continue
            if op == "add":
                q = pa.q + pb.q
            elif op == "mul":
                q = pa.q * pb.q
            else:
                _fail(f"unknown op '{op}'")
            _merge_best(out, k, q, pa.locked | pb.locked)
    return _prune(out)


def _frontier_expr(
    expr: Dict[str, Any],
    var_bounds: Dict[str, int],
    eligible: Set[str],
    k_max: int,
) -> Frontier:
    op = expr.get("op")
    if op == "const":
        v = int(expr.get("value", 1))
        return {0: Point(q=v, locked=set())}
    if op == "var":
        name = expr.get("name")
        if not isinstance(name, str) or name not in var_bounds:
            _fail("var node missing name or name not in var_bounds")
        q0 = int(var_bounds[name])
        out: Frontier = {0: Point(q=q0, locked=set())}
        if name in eligible and k_max >= 1:
            out[1] = Point(q=1, locked={name})
        return out
    if op in ("add", "mul"):
        left = expr.get("left")
        right = expr.get("right")
        if not isinstance(left, dict) or not isinstance(right, dict):
            _fail(f"{op} node missing left/right")
        fa = _frontier_expr(left, var_bounds, eligible, k_max)
        fb = _frontier_expr(right, var_bounds, eligible, k_max)
        return _combine(fa, fb, op, k_max)
    if op == "mincap":
        cap = expr.get("cap")
        inner = expr.get("inner")
        if not isinstance(cap, int) or cap < 1:
            _fail("mincap.cap must be a positive int")
        if not isinstance(inner, dict):
            _fail("mincap.inner must be an object")
        f = _frontier_expr(inner, var_bounds, eligible, k_max)
        out: Frontier = {}
        for k, p in f.items():
            _merge_best(out, k, min(p.q, cap), set(p.locked))
        return _prune(out)
    _fail(f"unsupported expr op '{op}'")
    return {}


def optimize_frontier(obj: Dict[str, Any]) -> Dict[str, Any]:
    try:
        from attempt_trace_extractor_ref import run as extract_attempt
        from end2end_resolve_ref import end2end_bound
    except Exception as e:
        _fail(f"failed to import sibling tools: {e}")

    trace = obj.get("attempt_trace")
    if trace is None:
        tp = obj.get("attempt_trace_path")
        if not tp:
            _fail("expected attempt_trace or attempt_trace_path")
        trace = _load_json(str(tp))

    if trace.get("schema") not in ("docf_attempt_trace/v0", "docf_attempt_trace/v1"):
        _fail("attempt_trace must use schema docf_attempt_trace/v0 or docf_attempt_trace/v1")

    # Extract base expression (no seed-locking) so we optimize over that structure.
    t0 = dict(trace)
    if "seed_locked" in t0:
        t0["seed_locked"] = []
    rep0 = extract_attempt(t0)
    expr = rep0.get("expr")
    var_bounds = rep0.get("var_bounds")
    if not isinstance(expr, dict) or not isinstance(var_bounds, dict):
        _fail("extractor output missing expr/var_bounds")
    var_bounds_int = {str(k): int(v) for (k, v) in var_bounds.items()}

    eligible_regions = obj.get("eligible_regions")
    if eligible_regions is None:
        eligible_regions = sorted(list(var_bounds_int.keys()))
    if not isinstance(eligible_regions, list) or any(not isinstance(x, str) for x in eligible_regions):
        _fail("eligible_regions must be an array of strings")
    eligible = set(eligible_regions)
    for r in eligible:
        if r not in var_bounds_int:
            _fail(f"eligible region '{r}' not present in var_bounds")

    k_max = int(obj.get("k_max", len(eligible_regions)))
    k_max = max(0, min(k_max, len(eligible_regions)))

    end2end_params = obj.get("end2end_params", {})
    if not isinstance(end2end_params, dict):
        _fail("end2end_params must be an object")

    target_bits = obj.get("target_security_bits")
    target_bits_f: Optional[float] = None
    if target_bits is not None:
        target_bits_f = float(target_bits)

    trace_digest = sha256_hex(jcs(trace))
    expr_digest = sha256_hex(jcs(expr))

    front = _frontier_expr(expr, var_bounds_int, eligible, k_max)

    frontier_list: List[Dict[str, Any]] = []
    best: Optional[Dict[str, Any]] = None

    for k in sorted(front.keys()):
        p = front[k]
        seed_locked = sorted(list(p.locked))
        Q = int(p.q)
        p2 = dict(end2end_params)
        p2["Q"] = Q
        if "t" not in p2:
            p2["t"] = 1
        if target_bits_f is not None and "target_security_bits" not in p2:
            p2["target_security_bits"] = target_bits_f
        e2 = end2end_bound(p2)
        item = {"k": k, "seed_locked": seed_locked, "Q": Q, "end2end": e2}
        frontier_list.append(item)

        # Best = minimize recommended_min_t, then Q, then k.
        rec = e2.get("recommended_min_t")
        t_rec = rec.get("t") if isinstance(rec, dict) else None
        t_val = int(t_rec) if isinstance(t_rec, (int, float)) else 10 ** 9
        key = (t_val, Q, k)
        if best is None:
            best = dict(item)
            best["objective_key"] = list(key)
        else:
            cur = tuple(best.get("objective_key", [10 ** 9, 10 ** 9, 10 ** 9]))
            if key < cur:
                best = dict(item)
                best["objective_key"] = list(key)

    out: Dict[str, Any] = {
        "schema": "docf_seed_lock_frontier_report/v0",
        "trace_digest_sha256": trace_digest,
        "expr_digest_sha256": expr_digest,
        "eligible_regions": sorted(list(eligible)),
        "k_max": k_max,
        "end2end_params": end2end_params,
        "target_security_bits": target_bits_f,
        "frontier": frontier_list,
        "recommended": best,
        "notes": [
            "Frontier computed by dynamic programming over a series--parallel expression.",
            "Seed-lock eligibility must be justified by protocol design + evidence; this tool does not prove eligibility.",
        ],
    }
    return out


def demo_request() -> Dict[str, Any]:
    return {
        "attempt_trace_path": "test_vectors/attempt_trace_demo.json",
        "eligible_regions": ["auction", "dispute", "in_round"],
        "k_max": 3,
        "target_security_bits": 128,
        "end2end_params": {
            "t": 1,
            "p_base": "2^-80",
            "eps_cancel": "2^-48",
            "b_rep": 2,
            "eps_rep": 0.0,
            "b_att": 10,
            "eps_att": 0.0,
            "eps_cm": "2^-130",
        },
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit", action="store_true", help="emit deterministic demo request+report")
    ap.add_argument("--in", dest="in_path", default=None, help="input JSON (default: stdin)")
    ap.add_argument("--out", dest="out_path", default=None, help="output JSON (default: stdout)")
    args = ap.parse_args()

    if args.emit:
        req = demo_request()
        rep = optimize_frontier(req)
        sys.stdout.write(_jdump({"demo_in": req, "demo_out": rep}))
        return

    raw = sys.stdin.read() if args.in_path is None else open(args.in_path, "r", encoding="utf-8").read()
    obj = json.loads(raw)
    rep = optimize_frontier(obj)
    s = _jdump(rep)
    if args.out_path:
        open(args.out_path, "w", encoding="utf-8").write(s)
    else:
        sys.stdout.write(s)


if __name__ == "__main__":
    main()
