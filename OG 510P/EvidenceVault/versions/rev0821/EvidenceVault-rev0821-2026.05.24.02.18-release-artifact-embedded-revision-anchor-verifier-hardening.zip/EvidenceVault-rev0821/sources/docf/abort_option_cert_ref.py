#!/usr/bin/env python3
"""abort_option_cert_ref.py

Reference tool: compute an Abort Option Certificate (AOC) for a public signal
(beacon/oracle/etc.) that a coordinator/prover may condition on via zero/low-cost
abort.

This tool is intentionally conservative and focuses on the *sampling cap* view:
if an actor can observe up to T independent candidate signal values before
committing to which one is used, then (in the worst case) they gain an
amplification factor T, i.e., bias_bits = ceil(log2 T).

Inputs (JSON):
{
  "sid": "session-id",
  "manifest_digest": "sha256:...",
  "market_id": "optional",
  "observable": {"source_kind": "drand_quicknet", "period_seconds": 3},
  "commitment": {"kind": "btcc", "commit_before_observe": false},
  "window": {"window_seconds": 60}
}

You may alternatively supply a direct cap:
  "window": {"T_cap": 20}

Output JSON:
{
  "type": "abort_option_cert",
  ...,
  "derived": {"T": 20, "p_min": 0.05, "bias_bits": 5, "repricing_rule": "bias_bits=ceil(log2 T)"},
  "digest": "sha256:..."
}

If inputs are insufficient to determine T, the tool raises.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from typing import Any, Dict


def _ceil_log2(n: int) -> int:
    if n <= 1:
        return 0
    return int(math.ceil(math.log(n, 2)))


def _to_float(x: Any, name: str) -> float:
    if x is None:
        raise ValueError(f"missing {name}")
    if isinstance(x, (int, float)):
        return float(x)
    if isinstance(x, str):
        return float(x.strip())
    raise TypeError(f"{name} must be numeric")


def _to_int(x: Any, name: str) -> int:
    if x is None:
        raise ValueError(f"missing {name}")
    if isinstance(x, bool):
        raise TypeError(f"{name} must be an integer")
    if isinstance(x, int):
        return int(x)
    if isinstance(x, str):
        return int(x.strip())
    raise TypeError(f"{name} must be an integer")


def _sha256_hex(obj: Dict[str, Any]) -> str:
    # Canonical-ish: stable JSON with sorted keys and no extra whitespace.
    s = json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return "sha256:" + hashlib.sha256(s).hexdigest()


def compute_T(inp: Dict[str, Any]) -> int:
    commitment = inp.get("commitment") or {}
    if commitment.get("commit_before_observe") is True:
        return 1

    window = inp.get("window") or {}
    if "T_cap" in window and window["T_cap"] is not None:
        T = _to_int(window["T_cap"], "window.T_cap")
        if T < 1:
            raise ValueError("window.T_cap must be >= 1")
        return T

    W = window.get("window_seconds")
    obs = inp.get("observable") or {}
    P = obs.get("period_seconds")

    if W is None or P is None:
        raise ValueError("Need either window.T_cap or both window.window_seconds and observable.period_seconds (unless commitment.commit_before_observe=true).")

    Wf = _to_float(W, "window.window_seconds")
    Pf = _to_float(P, "observable.period_seconds")
    if Pf <= 0:
        raise ValueError("observable.period_seconds must be > 0")
    if Wf < 0:
        raise ValueError("window.window_seconds must be >= 0")
    T = int(math.ceil(Wf / Pf))
    return max(1, T)


def abort_option_cert(inp: Dict[str, Any]) -> Dict[str, Any]:
    sid = inp.get("sid")
    manifest_digest = inp.get("manifest_digest")
    if not isinstance(sid, str) or not sid:
        raise ValueError("sid must be a non-empty string")
    if not isinstance(manifest_digest, str) or not manifest_digest:
        raise ValueError("manifest_digest must be a non-empty string")

    T = compute_T(inp)
    bias_bits = _ceil_log2(T)
    p_min = 1.0 / float(T)

    out: Dict[str, Any] = {
        "type": "abort_option_cert",
        "sid": sid,
        "market_id": inp.get("market_id"),
        "manifest_digest": manifest_digest,
        "observable": inp.get("observable") or {},
        "commitment": inp.get("commitment") or {},
        "window": inp.get("window") or {},
        "derived": {
            "T": T,
            "p_min": p_min,
            "bias_bits": bias_bits,
            "repricing_rule": "bias_bits=ceil(log2 T), p_min=1/T",
        },
        "receipts": inp.get("receipts") or {},
        "notes": inp.get(
            "notes",
            "Conservative conditioning tax: if an actor can sample up to T candidates before committing, treat it as +ceil(log2 T) bias bits.",
        ),
    }

    # Compute digest over the object *without* digest field.
    out_no_digest = dict(out)
    out_no_digest.pop("digest", None)
    out["digest"] = _sha256_hex(out_no_digest)
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="infile", default=None, help="Input JSON file (default: stdin).")
    ap.add_argument("--out", dest="outfile", default=None, help="Output JSON file (default: stdout).")
    args = ap.parse_args()

    raw = sys.stdin.read() if args.infile is None else open(args.infile, "r", encoding="utf-8").read()
    obj = json.loads(raw) if raw.strip() else {}
    cert = abort_option_cert(obj)

    s = json.dumps(cert, indent=2, sort_keys=False) + "\n"
    if args.outfile is None:
        sys.stdout.write(s)
    else:
        with open(args.outfile, "w", encoding="utf-8") as f:
            f.write(s)


if __name__ == "__main__":
    main()
