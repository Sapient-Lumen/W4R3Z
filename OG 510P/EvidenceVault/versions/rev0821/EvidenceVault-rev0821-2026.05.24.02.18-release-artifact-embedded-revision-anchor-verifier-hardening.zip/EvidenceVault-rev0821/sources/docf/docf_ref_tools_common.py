"""
dOCF reference-tool common helpers (illustrative).

These files are intentionally lightweight: they exist so the paper's
`\texttt{*_ref.py}` names resolve inside the evolving snapshot archive.

The tools in this snapshot are *reference-grade sketches*: they produce
deterministic test vectors and demonstrate canonicalization / hashing /
signature binding, but they are not production implementations.
"""
from __future__ import annotations

import argparse, base64, hashlib, json, sys
from typing import Any, Dict

def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def jcs(obj: Any) -> bytes:
    """
    A pragmatic RFC8785-style canonical JSON: sorted keys, UTF-8, no whitespace.
    This is a safe subset sufficient for deterministic test vectors.
    """
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def emit_json(obj: Any) -> None:
    json.dump(obj, sys.stdout, indent=2, ensure_ascii=False)
    sys.stdout.write("\n")

def b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")
