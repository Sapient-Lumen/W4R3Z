#!/usr/bin/env python3
"""cluster_dispute_case_ref.py — reference checker for a cluster-assignment dispute case.

Validates a docf_cluster_dispute_case_v0 JSON and recomputes cluster_id from the
embedded correlation capsule using the same rules as cluster_capsule_ref.py.

Usage:
  python cluster_dispute_case_ref.py test_vectors/cluster_dispute_case_demo.json

Outputs a JSON verdict:
  { "computed_cluster_id": ..., "claimed_cluster_id": ..., "match": true/false }
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from typing import Any, Dict

import jsonschema


def canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def core_fields(capsule: Dict[str, Any]) -> Dict[str, Any]:
    c = dict(capsule)
    c.pop("signatures", None)
    return {
        "type": c.get("type"),
        "rule_digest": c.get("rule_digest"),
        "facts": c.get("facts"),
        "validity": c.get("validity"),
    }


def compute_cluster_id(capsule: Dict[str, Any]) -> str:
    core = core_fields(capsule)
    return "cluster:" + sha256_hex(b"docf-cluster-v0|" + canonical_json(core))


def validate_schema(obj: Dict[str, Any], schema_path: str) -> None:
    schema = json.load(open(schema_path, "r", encoding="utf-8"))
    jsonschema.validate(instance=obj, schema=schema)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("case_json", help="Path to docf_cluster_dispute_case_v0 JSON")
    ap.add_argument("--schema", default="docf_cluster_dispute_case_v0.schema.json", help="Schema path")
    args = ap.parse_args()

    case = json.load(open(args.case_json, "r", encoding="utf-8"))

    schema_path = args.schema
    if not os.path.isabs(schema_path):
        candidate = os.path.join(os.path.dirname(args.case_json), schema_path)
        if os.path.exists(candidate):
            schema_path = candidate

    validate_schema(case, schema_path)

    claimed = case["claimed_cluster_id"]
    capsule = case["capsule"]
    computed = compute_cluster_id(capsule)

    out = {
        "entry_digest_sha256": case["entry_digest_sha256"],
        "claimed_cluster_id": claimed,
        "computed_cluster_id": computed,
        "match": (claimed == computed),
        "capsule_digest_sha256": sha256_hex(canonical_json(capsule)),
    }
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
