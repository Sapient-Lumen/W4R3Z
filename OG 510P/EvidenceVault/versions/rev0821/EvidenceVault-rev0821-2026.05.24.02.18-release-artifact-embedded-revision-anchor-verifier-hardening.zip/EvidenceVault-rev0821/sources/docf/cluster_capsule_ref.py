#!/usr/bin/env python3
"""cluster_capsule_ref.py — reference helper for docf_cluster_capsule_v0.

Computes a deterministic cluster_id digest for a correlation capsule.

Design goal: cluster assignment should be replayable by auditors and difficult to game.
We therefore define:

  cluster_id = sha256("docf-cluster-v0|" || canonical_json(core_fields))

where core_fields excludes signatures and any explicitly non-binding fields.

Usage:
  python cluster_capsule_ref.py examples/cluster_capsule_demo.json

Outputs:
  - cluster_id (hex)
  - capsule_digest (sha256 of canonical full JSON)
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from typing import Any, Dict

import jsonschema


def canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def load_schema(schema_path: str) -> Dict[str, Any]:
    return json.load(open(schema_path, "r", encoding="utf-8"))


def validate(obj: Dict[str, Any], schema_path: str) -> None:
    schema = load_schema(schema_path)
    jsonschema.validate(instance=obj, schema=schema)


def core_fields(capsule: Dict[str, Any]) -> Dict[str, Any]:
    # Exclude signatures and any obviously non-binding presentation fields.
    c = dict(capsule)
    c.pop("signatures", None)
    # Keep only required, security-relevant fields for cluster_id.
    return {
        "type": c.get("type"),
        "rule_digest": c.get("rule_digest"),
        "facts": c.get("facts"),
        "validity": c.get("validity"),
    }


def compute_cluster_id(capsule: Dict[str, Any]) -> str:
    core = core_fields(capsule)
    return sha256_hex(b"docf-cluster-v0|" + canonical_json(core))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("capsule_json", help="Path to docf_cluster_capsule_v0 JSON")
    ap.add_argument("--schema", default="docf_cluster_capsule_v0.schema.json", help="Schema path")
    args = ap.parse_args()

    capsule = json.load(open(args.capsule_json, "r", encoding="utf-8"))

    schema_path = args.schema
    if not os.path.isabs(schema_path):
        schema_path = os.path.join(os.path.dirname(args.capsule_json), schema_path)
        if not os.path.exists(schema_path):
            schema_path = args.schema

    validate(capsule, schema_path)

    cid = compute_cluster_id(capsule)
    full_digest = sha256_hex(canonical_json(capsule))

    out = {
        "cluster_id": "cluster:" + cid,
        "capsule_digest_sha256": full_digest,
    }
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
