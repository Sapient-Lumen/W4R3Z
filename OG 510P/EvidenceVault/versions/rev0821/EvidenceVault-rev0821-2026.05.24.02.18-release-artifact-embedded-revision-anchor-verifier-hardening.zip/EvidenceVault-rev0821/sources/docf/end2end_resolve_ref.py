#!/usr/bin/env python3
"""end2end_resolve_ref.py

Reference tool: compute the bound in Theorem~\ref{thm:end2end}.

This is intentionally small and dependency-free. It reads a JSON object that
provides the theorem parameters (p_base, eps_cancel, t, coin-quality params,
Q, eps_cm) and emits a JSON report with:
  - the resolved epsilon bound and security bits
  - a decomposition of the dominant terms
  - (optional) a minimal t that meets a target security-bits threshold

This is a *reference sketch* for auditors/resolvers; production implementations
should use exact rationals / interval arithmetic as needed.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from typing import Any, Dict, Optional


def _get(d: Dict[str, Any], k: str, default: Any = None) -> Any:
    return d[k] if k in d else default


def _to_float(x: Any) -> float:
    if x is None:
        return 0.0
    if isinstance(x, (int, float)):
        return float(x)
    if isinstance(x, str):
        s = x.strip()
        # Allow "2^-k" literals.
        if s.startswith("2^-" ):
            k = float(s[3:])
            return 2.0 ** (-k)
        return float(s)
    raise TypeError(f"Unsupported numeric type: {type(x)}")


def _bits(x: float) -> Optional[float]:
    if x is None or x <= 0.0:
        return None
    return -math.log(x, 2)


def end2end_bound(params: Dict[str, Any]) -> Dict[str, Any]:
    Q = int(_get(params, "Q"))
    t = int(_get(params, "t"))
    p_base = _to_float(_get(params, "p_base"))
    eps_cancel = _to_float(_get(params, "eps_cancel"))
    eps_cm = _to_float(_get(params, "eps_cm", 0.0))

    b_att = int(_get(params, "b_att", 0))
    eps_att = _to_float(_get(params, "eps_att", 0.0))
    b_rep = int(_get(params, "b_rep", 0))
    eps_rep = _to_float(_get(params, "eps_rep", 0.0))

    p = p_base + eps_cancel
    inner = (2.0 ** b_rep) * p + eps_rep
    per_attempt = (2.0 ** b_att) * (inner ** t) + eps_att
    eps_total = eps_cm + Q * per_attempt

    report: Dict[str, Any] = {
        "p_effective": p,
        "p_effective_bits": _bits(p),
        "per_attempt_term": per_attempt,
        "per_attempt_bits": _bits(per_attempt),
        "eps_crypto_total": Q * per_attempt,
        "eps_crypto_total_bits": _bits(Q * per_attempt),
        "eps_common_mode": eps_cm,
        "eps_common_mode_bits": _bits(eps_cm) if eps_cm > 0 else None,
        "eps_total_bound": eps_total,
        "security_bits_bound": _bits(eps_total),
        "formula": "eps_total <= eps_cm + Q * ( 2^b_att * (2^b_rep*(p_base+eps_cancel) + eps_rep)^t + eps_att )",
        "inputs_echo": {
            "Q": Q,
            "t": t,
            "p_base": p_base,
            "eps_cancel": eps_cancel,
            "b_att": b_att,
            "eps_att": eps_att,
            "b_rep": b_rep,
            "eps_rep": eps_rep,
            "eps_cm": eps_cm,
        },
    }

    target_bits = _get(params, "target_security_bits", None)
    if target_bits is not None:
        target_bits_f = float(target_bits)
        best = None
        for tp in range(1, 65):
            per_attempt_p = (2.0 ** b_att) * (inner ** tp) + eps_att
            eps_total_p = eps_cm + Q * per_attempt_p
            sb = _bits(eps_total_p)
            if sb is not None and sb >= target_bits_f:
                best = {"t": tp, "eps_total_bound": eps_total_p, "security_bits_bound": sb}
                break
        report["target_security_bits"] = target_bits_f
        report["recommended_min_t"] = best

    return report


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="infile", default=None, help="Input JSON file (default: stdin).")
    ap.add_argument("--out", dest="outfile", default=None, help="Output JSON file (default: stdout).")
    args = ap.parse_args()

    raw = sys.stdin.read() if args.infile is None else open(args.infile, "r", encoding="utf-8").read()
    obj = json.loads(raw)
    params = obj.get("params", obj)
    rep = end2end_bound(params)

    out: Any
    if isinstance(obj, dict) and "type" in obj:
        out = dict(obj)
        out["computed"] = rep
    else:
        out = rep

    s = json.dumps(out, indent=2, sort_keys=True)
    if args.outfile is None:
        sys.stdout.write(s + "\n")
    else:
        open(args.outfile, "w", encoding="utf-8").write(s + "\n")


if __name__ == "__main__":
    main()
