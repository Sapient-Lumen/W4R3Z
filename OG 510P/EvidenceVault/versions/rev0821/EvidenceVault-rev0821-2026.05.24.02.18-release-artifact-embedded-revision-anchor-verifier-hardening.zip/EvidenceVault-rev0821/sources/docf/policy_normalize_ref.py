#!/usr/bin/env python3
"""
policy_normalize_ref.py

Reference sketch: compile a docf-policy-v0 JSON policy into a Policy Normal Form (PNF)
object (docf-policy-normal-form-v0) and compute its digest.

v48 notes:
- Normalization is now *total* over the known docf-policy-v0 vocabulary: every optional
  field is expanded into an explicit monotone atom with a "top" (weakest) default.
  This prevents policy laundering via omission and makes dominance/join checks complete.

This exists so the paper's "semantic policy digest" is reproducible by independent toolchains.

Usage:
  - Emit the demo PNF used in the paper:
      python3 policy_normalize_ref.py --emit-demo
  - Normalize an input policy:
      python3 policy_normalize_ref.py --in policy_example_v1.json --out pnf.json

Notes:
  - Canonicalization uses a lightweight RFC 8785 style JSON canonical form:
    json.dumps(sort_keys=True, separators=(",", ":"), ensure_ascii=False).
    This is sufficient for the paper's toy examples but not a hardened JCS library.
"""
from __future__ import annotations

import argparse
import json
import hashlib
import math
import sys
from typing import Any, Dict, List

# "Top" defaults for total normalization.
# For le constraints, larger is weaker, so INF is the top element.
INF_INT = 2**63 - 1
INF_FLOAT = 1e100

# For subset allow-sets, '*' denotes the universal allow-set.
WILDCARD_ANY = "*"

# Weakest ranks for ordered enums.
DEFAULT_ASSURANCE = "AL0"      # weakest
DEFAULT_PROFILE = "Bronze"     # weakest


def jcs_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_pref(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _as_bool(v: Any, default: bool = False) -> bool:
    if v is None:
        return default
    return bool(v)


def _as_int(v: Any, default: int) -> int:
    if v is None:
        return default
    try:
        return int(v)
    except Exception:
        return default


def _as_float(v: Any, default: float) -> float:
    if v is None:
        return default
    try:
        # Accept ints too
        return float(v)
    except Exception:
        return default


def _as_allowset(v: Any) -> List[str]:
    """Return a sorted allow-set. Missing/invalid => universal ('*')."""
    if not isinstance(v, list):
        return [WILDCARD_ANY]
    xs: List[str] = []
    for e in v:
        if isinstance(e, str):
            xs.append(e)
    if not xs:
        return [WILDCARD_ANY]
    xs = sorted(set(xs))
    # If someone explicitly includes '*', treat it as universal.
    if WILDCARD_ANY in xs:
        return [WILDCARD_ANY]
    return xs


def to_atoms(policy: Dict[str, Any]) -> List[Dict[str, Any]]:
    atoms: List[Dict[str, Any]] = []

    # Required core threshold
    atoms.append({"pred": "ge", "path": "/min_security_bits", "op": ">=", "value": policy["min_security_bits"]})

    # Assurance level: weakest default AL0
    atoms.append({"pred": "ge", "path": "/assurance_level", "op": ">=", "value": policy.get("require_assurance_level", DEFAULT_ASSURANCE)})

    # Compliance vector coordinates: weakest defaults 0
    cv = policy.get("require_compliance_vector")
    cv = cv if isinstance(cv, dict) else {}
    atoms.append({"pred": "ge", "path": "/compliance_vector/D", "op": ">=", "value": _as_int(cv.get("D_min"), 0)})
    atoms.append({"pred": "ge", "path": "/compliance_vector/L", "op": ">=", "value": _as_int(cv.get("L_min"), 0)})
    atoms.append({"pred": "ge", "path": "/compliance_vector/A", "op": ">=", "value": _as_int(cv.get("A_min"), 0)})
    atoms.append({"pred": "ge", "path": "/compliance_vector/P", "op": ">=", "value": _as_int(cv.get("P_min"), 0)})

    # ABI requirements: monotone booleans (false < true)
    abi = policy.get("abi_requirements")
    abi = abi if isinstance(abi, dict) else {}
    atoms.append({"pred": "eq", "path": "/abi/require_transcript_abi_digest", "op": "=", "value": _as_bool(abi.get("require_transcript_abi_digest"), False)})
    atoms.append({"pred": "eq", "path": "/abi/require_conformance_suite_digest", "op": "=", "value": _as_bool(abi.get("require_conformance_suite_digest"), False)})
    atoms.append({"pred": "eq", "path": "/abi/require_differential_vectors", "op": "=", "value": _as_bool(abi.get("require_differential_vectors"), False)})

    # Attempt transparency requirements
    at = policy.get("attempt_transparency")
    at = at if isinstance(at, dict) else {}
    atoms.append({"pred": "eq", "path": "/attempt_transparency/require_attempt_certificates", "op": "=", "value": _as_bool(at.get("require_attempt_certificates"), False)})
    atoms.append({"pred": "eq", "path": "/attempt_transparency/require_attempt_dag_commitment", "op": "=", "value": _as_bool(at.get("require_attempt_dag_commitment"), False)})
    atoms.append({"pred": "eq", "path": "/attempt_transparency/require_witnessed_log", "op": "=", "value": _as_bool(at.get("require_witnessed_log"), False)})
    atoms.append({"pred": "ge", "path": "/attempt_transparency/min_witnesses", "op": ">=", "value": _as_int(at.get("min_witnesses"), 0)})

    # Budget caps (le): missing => unbounded
    budgets = policy.get("budgets")
    budgets = budgets if isinstance(budgets, dict) else {}
    atoms.append({"pred": "le", "path": "/budgets/max_Q", "op": "<=", "value": _as_int(budgets.get("max_Q"), INF_INT)})
    atoms.append({"pred": "le", "path": "/budgets/max_eps_abi", "op": "<=", "value": _as_float(budgets.get("max_eps_abi"), INF_FLOAT)})
    atoms.append({"pred": "le", "path": "/budgets/max_eps_bias", "op": "<=", "value": _as_float(budgets.get("max_eps_bias"), INF_FLOAT)})
    atoms.append({"pred": "le", "path": "/budgets/max_eps_enforce", "op": "<=", "value": _as_float(budgets.get("max_eps_enforce"), INF_FLOAT)})
    atoms.append({"pred": "le", "path": "/budgets/max_eps_common_mode", "op": "<=", "value": _as_float(budgets.get("max_eps_common_mode"), INF_FLOAT)})

    # Total eps cap (le): missing => unbounded
    atoms.append({"pred": "le", "path": "/max_eps_total", "op": "<=", "value": _as_float(policy.get("max_eps_total"), INF_FLOAT)})

    # Receipt embedding
    re = policy.get("receipt_embedding")
    re = re if isinstance(re, dict) else {}
    atoms.append({"pred": "eq", "path": "/receipt_embedding/require_docf_digests_in_receipts", "op": "=", "value": _as_bool(re.get("require_docf_digests_in_receipts"), False)})
    atoms.append({"pred": "subset", "path": "/receipt_embedding/acceptable_anchor_kinds", "op": "subset", "value": _as_allowset(re.get("acceptable_anchor_kinds"))})

    # Evidence kind allow-list: missing => universal
    atoms.append({"pred": "subset", "path": "/allowed_evidence_kinds", "op": "subset", "value": _as_allowset(policy.get("allowed_evidence_kinds"))})

    # Deployment profile: ordered enum (Bronze < Silver < Gold); missing => Bronze
    atoms.append({"pred": "ge", "path": "/profile", "op": ">=", "value": policy.get("require_profile", DEFAULT_PROFILE)})

    atoms.sort(key=lambda a: (a["pred"], a["path"], a["op"], json.dumps(a["value"], sort_keys=True)))
    return atoms


def normalize(policy: Dict[str, Any]) -> Dict[str, Any]:
    if policy.get("format") != "docf-policy-v0":
        raise ValueError("Expected format == docf-policy-v0")
    pnf = {
        "type": "docf-policy-normal-form-v0",
        "version": "0",
        "source_policy_format": "docf-policy-v0",
        "jcs_canonical": True,
        "atoms": to_atoms(policy),
        "notes": "Reference normalizer output (toy, total over v0 vocabulary).",
    }
    return pnf


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="in_path")
    ap.add_argument("--out", dest="out_path")
    ap.add_argument("--emit-demo", action="store_true")
    args = ap.parse_args()

    if args.emit_demo:
        in_path = "policy_example_v1.json"
        out_path = "test_vectors/policy_normal_form_demo.json"
    else:
        if not args.in_path:
            ap.error("--in required unless --emit-demo")
        in_path = args.in_path
        out_path = args.out_path or "-"

    with open(in_path, "r", encoding="utf-8") as f:
        policy = json.load(f)
    pnf = normalize(policy)
    digest = sha256_pref(jcs_bytes(pnf))

    if out_path == "-":
        json.dump({"pnf": pnf, "pnf_digest": digest}, sys.stdout, indent=2, sort_keys=True)
        sys.stdout.write("\n")
    else:
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(pnf, f, indent=2, sort_keys=True)
            f.write("\n")
        print(digest)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
