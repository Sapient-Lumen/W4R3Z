#!/usr/bin/env python3
"""make_operator_diversity_requirements.py

Compute minimum required number of distinct *risk buckets* (e.g., operators)
needed to satisfy a correlation budget under the WDD proxy.

For a domain that partitions witnesses into buckets g with counts n_g, the WDD proxy is
  \hat\rho = sum_g n_g(n_g-1)/(m(m-1)).

Given quorum size m and a target \rho_max, the minimum possible \hat\rho is obtained by
spreading witnesses across as many buckets as possible.
This script computes the smallest number of buckets B such that the minimal achievable
\hat\rho(B) <= \rho_max.

We compute \rho_max from the exchangeable ICC model for split-view dual-acceptance
budget B_dual = 2^{-k}.

Outputs:
  - _insert_operator_diversity_requirements_table.tex

"""

from __future__ import annotations

import argparse
import math
from pathlib import Path


def log_beta(a: float, b: float) -> float:
    return math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)


def beta_binom_pmf(m: int, k: int, alpha: float, beta: float) -> float:
    return math.comb(m, k) * math.exp(log_beta(alpha + k, beta + m - k) - log_beta(alpha, beta))


def hypergeom_pmf(N: int, K: int, n: int, k: int) -> float:
    if k < 0 or k > n or k > K or (n - k) > (N - K):
        return 0.0
    return (math.comb(K, k) * math.comb(N - K, n - k)) / math.comb(N, n)


def dual_accept_prob_given_K(m: int, t: int, g: int, K: int) -> float:
    lo = max(0, t - (m - g))
    hi = min(g, K + g - t)
    if lo > hi:
        return 0.0
    return sum(hypergeom_pmf(m, K, g, kA) for kA in range(lo, hi + 1))


def compute_dual_accept(m: int, t: int, q: float, rho: float) -> float:
    g = m // 2

    if rho <= 0.0:
        pD = 0.0
        for K in range(0, m + 1):
            pK = math.comb(m, K) * (q**K) * ((1 - q) ** (m - K))
            pD += pK * dual_accept_prob_given_K(m, t, g, K)
        return pD

    s = (1.0 / rho) - 1.0
    alpha = max(1e-12, q * s)
    beta = max(1e-12, (1.0 - q) * s)

    pD = 0.0
    for K in range(0, m + 1):
        pK = beta_binom_pmf(m, K, alpha, beta)
        pD += pK * dual_accept_prob_given_K(m, t, g, K)
    return pD


def max_rho_for_budget(m: int, t: int, q: float, budget_dual: float) -> float | None:
    # If even rho=0 exceeds budget, no correlation level can satisfy this budget.
    if compute_dual_accept(m, t, q, 0.0) > budget_dual:
        return None

    lo, hi = 0.0, 0.999
    for _ in range(70):
        mid = (lo + hi) / 2
        pD = compute_dual_accept(m, t, q, mid)
        if pD <= budget_dual:
            lo = mid
        else:
            hi = mid
    return lo


def rho_min_for_buckets(m: int, B: int) -> float:
    """Minimal \hat\rho achievable when distributing m items across B buckets."""
    if B <= 0:
        return 1.0
    # balanced as possible
    base = m // B
    rem = m % B
    counts = [base + 1] * rem + [base] * (B - rem)
    num = sum(c * (c - 1) for c in counts)
    return num / (m * (m - 1))


def min_buckets_needed(m: int, rho_max: float) -> int:
    for B in range(1, m + 1):
        if rho_min_for_buckets(m, B) <= rho_max + 1e-18:
            return B
    return m


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--m', type=int, default=7)
    ap.add_argument('--t', type=int, default=6)
    ap.add_argument('--q', type=float, default=0.12)
    ap.add_argument('--budgets_bits', default='6,8,10,12')
    ap.add_argument('--out_tex', default='_insert_operator_diversity_requirements_table.tex')
    args = ap.parse_args()

    ks = [int(x.strip()) for x in args.budgets_bits.split(',') if x.strip()]

    tex = []
    tex.append('\\begin{tabular}{r r r r}')
    tex.append('\\toprule')
    tex.append('$k$ & $\\rho_{\\max}$ & min distinct buckets & example split \\\\')
    tex.append('\\midrule')

    for k in ks:
        budget = 2.0 ** (-k)
        rho_max = max_rho_for_budget(args.m, args.t, args.q, budget)
        if rho_max is None:
            tex.append(f"{k} & -- & -- & infeasible-even-indep \\\\")
            continue
        B = min_buckets_needed(args.m, rho_max)
        base = args.m // B
        rem = args.m % B
        split = [base + 1] * rem + [base] * (B - rem)
        split_str = '[' + ','.join(str(x) for x in split) + ']' 
        tex.append(f"{k} & {rho_max:.4g} & {B} & {split_str} \\\\")

    tex.append('\\bottomrule')
    tex.append('\\end{tabular}')
    Path(args.out_tex).write_text('\n'.join(tex) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
