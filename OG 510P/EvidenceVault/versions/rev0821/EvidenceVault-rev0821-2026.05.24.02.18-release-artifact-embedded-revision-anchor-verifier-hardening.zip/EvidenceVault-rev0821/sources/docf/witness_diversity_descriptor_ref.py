#!/usr/bin/env python3
"""witness_diversity_descriptor_ref.py

Reference implementation for the Witness Diversity Descriptor (WDD).

A WDD is intended to be a *portable, verifier-checkable* object that summarizes
witness-set diversity across a small set of risk domains. It is not a full
attestation system; it provides a conservative scalar correlation lower bound
that can plug into verifier policy.

The conservative bound used here matches the paper text:
  rho_d = sum_g n_g (n_g-1) / (m (m-1))
  rho_hat = max_d rho_d

This equals the *average pairwise correlation* induced by perfect within-group
common-mode failures and independent failures across groups.

Usage:
  ./witness_diversity_descriptor_ref.py --emit-demo \
      --snapshot data/witness_pool_snapshot_2026-02-28.json \
      --witness-ids witness1.smartit.nu/witness1,remora.n621.de,... \
      --out test_vectors/wdd_demo.json

  ./witness_diversity_descriptor_ref.py --verify --in test_vectors/wdd_demo.json

Deterministic; no network access.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List, Tuple


def _jcs_bytes(x: Any) -> bytes:
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _sha256_pref(x: Any) -> str:
    return "sha256:" + hashlib.sha256(_jcs_bytes(x)).hexdigest()


def detect_impl_family(notes: str) -> str:
    n = notes.lower()
    if "sunlight" in n:
        return "sunlight"
    if "litewitness" in n:
        return "litewitness"
    if "sigsum" in n:
        return "sigsum"
    return "other"


def detect_key_family(notes: str) -> str:
    n = notes.lower()
    if "soft key" in n:
        return "soft-key"
    if "hsm" in n or "hardware" in n:
        return "hsm"
    return "other"


def group_corr_lower_bound(labels: List[str]) -> Tuple[float, Dict[str, int]]:
    counts: Dict[str, int] = {}
    for lab in labels:
        counts[lab] = counts.get(lab, 0) + 1
    m = len(labels)
    if m <= 1:
        return 0.0, counts
    num = sum(v * (v - 1) for v in counts.values())
    den = m * (m - 1)
    return num / den, counts


def herfindahl_neff(counts: Dict[str, int]) -> Tuple[float, float]:
    m = sum(counts.values())
    if m == 0:
        return 0.0, 0.0
    H = 0.0
    for v in counts.values():
        s = v / m
        H += s * s
    Neff = 1.0 / H if H > 0 else 0.0
    return H, Neff


def compute_wdd(snapshot: Dict[str, Any], witness_ids: List[str]) -> Dict[str, Any]:
    ws_all = {w["id"]: w for w in snapshot.get("witnesses", []) if "id" in w}
    missing = [wid for wid in witness_ids if wid not in ws_all]
    if missing:
        raise ValueError(f"witness_ids not present in snapshot: {missing}")

    # Build per-witness tags in each risk domain.
    ops: List[str] = []
    impls: List[str] = []
    keys: List[str] = []

    for wid in witness_ids:
        w = ws_all[wid]
        notes = " ".join(w.get("notes", []))

        op = w.get("operator") or wid
        ops.append(op)

        impl = detect_impl_family(notes)
        impls.append(impl if impl != "other" else wid)  # keep unknowns unique

        keyf = detect_key_family(notes)
        keys.append(keyf if keyf != "other" else wid)

    dims = [
        ("Operator", "operator", ops),
        ("Implementation", "impl_family", impls),
        ("Key mgmt", "key_family", keys),
    ]

    by_domain = []
    rho_hat = 0.0
    for name, tag_key, labels in dims:
        rho, counts = group_corr_lower_bound(labels)
        H, Neff = herfindahl_neff(counts)
        row = {
            "name": name,
            "tag_key": tag_key,
            "groups": len(counts),
            "max_group": max(counts.values()) if counts else 0,
            "neff": float(f"{Neff:.6g}"),
            "rho": float(f"{rho:.6g}"),
            "herfindahl": float(f"{H:.6g}"),
        }
        by_domain.append(row)
        rho_hat = max(rho_hat, rho)

    wdd: Dict[str, Any] = {
        "type": "docf_wdd",
        "version": "v0",
        "snapshot": {
            "snapshot_date": snapshot.get("snapshot_date", ""),
            "snapshot_digest": _sha256_pref(snapshot),
        },
        "witness_ids": list(witness_ids),
        "risk_domains": [
            {"name": "Operator", "tag_key": "operator"},
            {"name": "Implementation", "tag_key": "impl_family"},
            {"name": "Key mgmt", "tag_key": "key_family"},
        ],
        "rho_hat": float(f"{rho_hat:.6g}"),
        "metrics": {"by_domain": by_domain},
    }

    # Digest excludes digest field itself.
    wdd["digest"] = _sha256_pref({k: v for k, v in wdd.items() if k != "digest"})
    return wdd


def verify_wdd(wdd: Dict[str, Any]) -> bool:
    if wdd.get("type") != "docf_wdd" or wdd.get("version") != "v0":
        raise ValueError("not a WDD v0 object")
    dig = wdd.get("digest")
    if not isinstance(dig, str) or not dig.startswith("sha256:"):
        raise ValueError("missing digest")
    recomputed = _sha256_pref({k: v for k, v in wdd.items() if k != "digest"})
    if recomputed != dig:
        raise ValueError("digest mismatch")
    return True


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit-demo", action="store_true")
    ap.add_argument("--snapshot", default="data/witness_pool_snapshot_2026-02-28.json")
    ap.add_argument("--witness-ids", default="")
    ap.add_argument("--out", default="test_vectors/wdd_demo.json")
    ap.add_argument("--verify", action="store_true")
    ap.add_argument("--in", dest="inp", default="test_vectors/wdd_demo.json")
    args = ap.parse_args()

    if args.emit_demo:
        snap = json.loads(Path(args.snapshot).read_text(encoding="utf-8"))
        if args.witness_ids.strip():
            wids = [x.strip() for x in args.witness_ids.split(",") if x.strip()]
        else:
            # default: first 7 witnesses
            wids = [w["id"] for w in snap.get("witnesses", [])[:7]]
        wdd = compute_wdd(snap, wids)
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        Path(args.out).write_text(json.dumps(wdd, indent=2, ensure_ascii=False), encoding="utf-8")
        print(f"wrote {args.out}")
        return

    if args.verify:
        wdd = json.loads(Path(args.inp).read_text(encoding="utf-8"))
        ok = verify_wdd(wdd)
        print("verify OK" if ok else "verify FAIL")
        return

    ap.print_help()


if __name__ == "__main__":
    main()
