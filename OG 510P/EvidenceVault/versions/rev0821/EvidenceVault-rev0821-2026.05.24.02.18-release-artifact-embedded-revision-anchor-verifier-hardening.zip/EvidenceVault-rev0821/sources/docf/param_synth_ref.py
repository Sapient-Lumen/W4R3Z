#!/usr/bin/env python3
"""param_synth_ref.py

Reference tool: parameter synthesis for cancellation suppression.

Given a manifest (docf-manifest-v0) and a target end-to-end security level,
this tool computes the *minimal* glue-check repetition count `t` that satisfies
the end-to-end bound from Theorem~\ref{thm:end2end} (as implemented in
end2end_resolve_ref.py), under conservative defaults.

This is deliberately a *reference* calculator:
- It focuses on the cancellation term (derived from manifest.glue + field + ell)
  and the coordinator retry/grinding budget Q (manifest.grinding_budget).
- Other parameters (p_base, eps_cm, bias bits, eps_att/eps_rep) are accepted as
  CLI overrides.

Usage:
  python3 param_synth_ref.py --manifest manifest_grinding_compound_min.json --target-bits 128

Outputs a JSON report that includes:
  - computed eps_cancel and its bits
  - recommended t
  - a manifest patch suggestion (glue.repetitions = t)
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from typing import Any, Dict, Optional, Tuple


def jcs_bytes(x: Any) -> bytes:
    # Best-effort RFC8785-like canonicalization.
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_hex(x: Any) -> str:
    return hashlib.sha256(jcs_bytes(x)).hexdigest()


def parse_num(x: Any) -> float:
    if x is None:
        return 0.0
    if isinstance(x, (int, float)):
        return float(x)
    if isinstance(x, str):
        s = x.strip()
        if s.startswith("2^-"):
            return 2.0 ** (-float(s[3:]))
        return float(s)
    raise TypeError(f"unsupported numeric type: {type(x)}")


def bits(p: float) -> Optional[float]:
    if p <= 0.0:
        return None
    return -math.log(p, 2)


def eps_cancel_from_manifest(man: Dict[str, Any]) -> Tuple[float, Dict[str, Any]]:
    """Compute a conservative one-shot cancellation bound from manifest fields."""
    ell = int(man.get("ell", 1))
    field = man.get("field", {}) if isinstance(man.get("field", {}), dict) else {}
    f_bits = int(field.get("bits", 0) or 0)
    if f_bits <= 0:
        raise ValueError("manifest.field.bits must be a positive integer")

    F = 2.0 ** float(f_bits)  # approximate |F| as 2^bits
    glue = man.get("glue", {}) if isinstance(man.get("glue", {}), dict) else {}
    fam = glue.get("family", "power_basis")
    k = int(glue.get("k", 1) or 1)
    meta: Dict[str, Any] = {"ell": ell, "field_bits": f_bits, "family": fam, "k": k}

    if fam == "power_basis":
        eps = max(0.0, float(ell - 1) / F)
        meta["formula"] = "(ell-1)/|F|"
    elif fam == "random_vector":
        eps = 1.0 / F
        meta["formula"] = "1/|F|"
    elif fam == "prg_vector":
        # PRG expansion is assumed to approximate uniform; we conservatively treat it as random_vector.
        eps = 1.0 / F
        meta["formula"] = "1/|F| (conservative for PRG-expanded vector)"
    elif fam == "kscalar_embedding":
        # Lemma k-scalar: eps <= k(B-1)/|F| with B = ceil(ell^(1/k)).
        B = int(math.ceil(ell ** (1.0 / float(k)))) if k > 0 else ell
        eps = float(k) * max(0.0, float(B - 1)) / F
        meta["B"] = B
        meta["formula"] = "k*(ceil(ell^(1/k))-1)/|F|"
    else:
        raise ValueError(f"unknown glue family: {fam}")
    return eps, meta


def end2end_eps(Q: int, t: int, p_base: float, eps_cancel: float, b_att: int, eps_att: float, b_rep: int, eps_rep: float, eps_cm: float) -> float:
    p = p_base + eps_cancel
    inner = (2.0 ** b_rep) * p + eps_rep
    per_attempt = (2.0 ** b_att) * (inner ** t) + eps_att
    return eps_cm + Q * per_attempt


def synth(man: Dict[str, Any], target_bits: float, overrides: Dict[str, Any]) -> Dict[str, Any]:
    eps_cancel, cancel_meta = eps_cancel_from_manifest(man)
    Q = int(man.get("grinding_budget", 1) or 1)

    p_base = parse_num(overrides.get("p_base", "0.0"))
    eps_cm = parse_num(overrides.get("eps_cm", "0.0"))
    b_att = int(overrides.get("b_att", 0) or 0)
    eps_att = parse_num(overrides.get("eps_att", 0.0))
    b_rep = int(overrides.get("b_rep", 0) or 0)
    eps_rep = parse_num(overrides.get("eps_rep", 0.0))

    best = None
    max_t = int(overrides.get("max_t", 128) or 128)
    for t in range(1, max_t + 1):
        eps_tot = end2end_eps(Q, t, p_base, eps_cancel, b_att, eps_att, b_rep, eps_rep, eps_cm)
        sb = bits(eps_tot)
        if sb is not None and sb >= target_bits:
            best = {"t": t, "eps_total_bound": eps_tot, "security_bits_bound": sb}
            break

    report: Dict[str, Any] = {
        "type": "docf_param_synth_report_v0",
        "target_security_bits": float(target_bits),
        "manifest_digest": "sha256:" + sha256_hex(man),
        "derived": {
            "Q": Q,
            "eps_cancel": eps_cancel,
            "eps_cancel_bits": bits(eps_cancel),
            "cancel_meta": cancel_meta,
        },
        "assumptions": {
            "p_base": p_base,
            "eps_cm": eps_cm,
            "b_att": b_att,
            "eps_att": eps_att,
            "b_rep": b_rep,
            "eps_rep": eps_rep,
            "max_t": max_t,
        },
        "recommended": best,
        "manifest_patch_suggestion": {"glue.repetitions": best["t"] if best else None},
        "notes": "Conservative synthesis: derives eps_cancel from manifest glue family + field size; searches minimal t meeting target via Theorem end2end. Override p_base/eps_cm/bias terms for your deployment.",
        "meta": {"tool": "param_synth_ref.py"},
    }
    report["digest"] = "sha256:" + sha256_hex({k: v for k, v in report.items() if k != "digest"})
    return report


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--manifest", required=True, help="Path to docf-manifest-v0 JSON.")
    ap.add_argument("--target-bits", type=float, required=True, help="Target end-to-end security bits (e.g., 128).")

    # Optional overrides for the end-to-end bound (defaults to 0).
    ap.add_argument("--p-base", default="0.0", help="Base PCS/SNARK one-shot failure probability (float or 2^-k).")
    ap.add_argument("--eps-cm", default="0.0", help="Common-mode failure probability (float or 2^-k).")
    ap.add_argument("--b-att", type=int, default=0, help="Attempt-scope bias bits.")
    ap.add_argument("--eps-att", default="0.0", help="Per-attempt additive term (float or 2^-k).")
    ap.add_argument("--b-rep", type=int, default=0, help="Repetition-scope bias bits.")
    ap.add_argument("--eps-rep", default="0.0", help="Per-repetition additive term (float or 2^-k).")
    ap.add_argument("--max-t", type=int, default=128, help="Max repetition count to search.")
    ap.add_argument("--out", default="-", help="Output path (default stdout).")
    args = ap.parse_args()

    man = json.load(open(args.manifest, "r", encoding="utf-8"))
    overrides = {
        "p_base": args.p_base,
        "eps_cm": args.eps_cm,
        "b_att": args.b_att,
        "eps_att": args.eps_att,
        "b_rep": args.b_rep,
        "eps_rep": args.eps_rep,
        "max_t": args.max_t,
    }
    rep = synth(man, float(args.target_bits), overrides)
    out = json.dumps(rep, indent=2, sort_keys=False) + "\n"
    if args.out == "-" or args.out == "":
        sys.stdout.write(out)
    else:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(out)


if __name__ == "__main__":
    main()
