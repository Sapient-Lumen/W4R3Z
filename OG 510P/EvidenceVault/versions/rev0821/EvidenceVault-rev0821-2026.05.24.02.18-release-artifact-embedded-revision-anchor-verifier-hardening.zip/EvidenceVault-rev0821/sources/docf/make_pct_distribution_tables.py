#!/usr/bin/env python3
"""make_pct_distribution_tables.py

Generate a distributional evaluation pass for Paper F/G.

Compared to microbenchmarks (single point estimates), this script runs a synthetic
parameter sweep over:
  - Merkle inclusion proof length L (log sizes ~2^L)
  - witness quorum size m (number of cosignatures checked)

It produces:
  - test_vectors/pct_dist_results.json
  - LaTeX inserts:
      _insert_pct_dist_summary_table.tex
      _insert_witness_compromise_table.tex
  - Figures:
      pct_total_verify_cdf.pdf
      pct_staple_json_cdf.pdf

The simulation is intentionally *minimal* and CPU-cheap:
we craft balanced-tree inclusion proofs without building huge trees, and we
verify real Ed25519 cosignatures over a fixed checkpoint.
"""

from __future__ import annotations

import base64
import json
import math
import os
import random
import time
from pathlib import Path
from typing import Any, Dict, List, Tuple

import matplotlib.pyplot as plt
import pandas as pd

import transparency_log_ref as tlog
import checkpoint_ref as ckpt
import witness_monitor_ref as wmon

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization


ROOT = Path(__file__).resolve().parent


def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def _seeded_sk(seed_int: int) -> Ed25519PrivateKey:
    seed = seed_int.to_bytes(32, "big")
    return Ed25519PrivateKey.from_private_bytes(seed)


def _balanced_root(leaf_bytes: bytes, siblings: List[bytes], index: int) -> bytes:
    h = tlog.leaf_hash(leaf_bytes)
    for i, sib in enumerate(siblings):
        if ((index >> i) & 1) == 0:
            h = tlog.node_hash(h, sib)
        else:
            h = tlog.node_hash(sib, h)
    return h


def _make_cosig(witness_id: str, sk: Ed25519PrivateKey, checkpoint_obj: Dict[str, Any]) -> Dict[str, Any]:
    msg = ckpt.checkpoint_message(
        checkpoint_obj["log_id"],
        int(checkpoint_obj["tree_size"]),
        checkpoint_obj["root_hash_b64"],
        checkpoint_obj["timestamp"],
    )
    sig = sk.sign(msg)
    pk_raw = sk.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return {
        "type": "docf_witness_cosignature_v0",
        "witness_id": witness_id,
        "witness_public_key_b64": _b64(pk_raw),
        "signature_b64": _b64(sig),
    }


def run_trials(
    num_trials: int = 10000,
    L_min: int = 10,
    L_max: int = 24,
    m_choices: Tuple[int, ...] = (1, 2, 3, 5, 7),
    seed: int = 42,
) -> List[Dict[str, Any]]:
    rng = random.Random(seed)

    # Deterministic log key + checkpoint (we only benchmark verification, so a fixed checkpoint is fine).
    log_sk, _ = ckpt.demo_log_keypair()
    checkpoint_obj = ckpt.sign_checkpoint("docf-demo-log", 2**20, os.urandom(32), log_sk)

    witness_sks = [_seeded_sk(i + 1) for i in range(8)]
    all_cosigs = [_make_cosig(f"w{i}", witness_sks[i], checkpoint_obj) for i in range(8)]
    cosig_subsets = {m: all_cosigs[:m] for m in m_choices}

    out: List[Dict[str, Any]] = []
    for _ in range(num_trials):
        L = rng.randint(L_min, L_max)
        tree_size = 2**L
        index = rng.randrange(tree_size)

        leaf = os.urandom(32)
        siblings = [os.urandom(32) for _ in range(L)]
        root = _balanced_root(leaf, siblings, index)

        t0 = time.perf_counter_ns()
        ok = tlog.verify_inclusion(leaf, index, tree_size, siblings, root)
        t1 = time.perf_counter_ns()
        if not ok:
            raise RuntimeError("verify_inclusion failed")

        m = rng.choice(m_choices)
        cosigs = cosig_subsets[m]

        t2 = time.perf_counter_ns()
        for c in cosigs:
            if not wmon.verify_cosignature(c, checkpoint_obj):
                raise RuntimeError("cosig verify failed")
        t3 = time.perf_counter_ns()

        incl_us = (t1 - t0) / 1000.0
        wit_us = (t3 - t2) / 1000.0

        staple_obj = {
            "proof": {
                "tree_size": tree_size,
                "leaf_index": index,
                "path_b64": [_b64(s) for s in siblings],
                "root_b64": _b64(root),
            },
            "checkpoint": checkpoint_obj,
            "witness_cosigs": cosigs,
        }
        json_bytes = len(json.dumps(staple_obj, separators=(",", ":")).encode("utf-8"))

        raw_bytes_est = 32 * L + 32 + 64 + 64 * m  # path + root + log sig + witness sigs (rough)
        out.append(
            {
                "L": L,
                "tree_size": tree_size,
                "m": m,
                "incl_us": incl_us,
                "wit_us": wit_us,
                "total_us": incl_us + wit_us,
                "json_bytes": json_bytes,
                "raw_bytes_est": raw_bytes_est,
            }
        )

    return out


def _pct(x: List[float], p: float) -> float:
    x2 = sorted(x)
    if not x2:
        return float("nan")
    k = int(math.ceil(p * len(x2))) - 1
    k = max(0, min(k, len(x2) - 1))
    return x2[k]


def _binom_tail(m: int, t: int, p: float) -> float:
    # P[X >= t] for X ~ Bin(m, p)
    from math import comb

    s = 0.0
    for k in range(t, m + 1):
        s += comb(m, k) * (p**k) * ((1 - p) ** (m - k))
    return s


def write_outputs(results: List[Dict[str, Any]]) -> None:
    tv_dir = ROOT / "test_vectors"
    tv_dir.mkdir(exist_ok=True)

    out_path = tv_dir / "pct_dist_results.json"
    out_path.write_text(json.dumps({"meta": {"num_trials": len(results)}, "rows": results}, indent=2), encoding="utf-8")

    df = pd.DataFrame(results)

    # Robust stats: median and p95 (more stable than max under Python jitter).
    summary = {
        "n": len(df),
        "L_min": int(df["L"].min()),
        "L_max": int(df["L"].max()),
        "m_set": sorted(set(int(x) for x in df["m"].unique())),
        "incl_p50": float(df["incl_us"].median()),
        "incl_p95": float(_pct(df["incl_us"].tolist(), 0.95)),
        "wit_p50": float(df["wit_us"].median()),
        "wit_p95": float(_pct(df["wit_us"].tolist(), 0.95)),
        "tot_p50": float(df["total_us"].median()),
        "tot_p95": float(_pct(df["total_us"].tolist(), 0.95)),
        "json_p50": float(df["json_bytes"].median()),
        "json_p95": float(_pct(df["json_bytes"].tolist(), 0.95)),
        "raw_p50": float(df["raw_bytes_est"].median()),
        "raw_p95": float(_pct(df["raw_bytes_est"].tolist(), 0.95)),
    }

    # LaTeX summary table.
    tex = []
    tex.append("\\begin{table}[t]")
    tex.append("\\centering")
    tex.append("\\small")
    tex.append("\\begin{tabular}{lrr}")
    tex.append("\\toprule")
    tex.append("Metric & p50 & p95 \\\\")
    tex.append("\\midrule")
    tex.append(f"Inclusion verify (\\,$\\mu$s) & {summary['incl_p50']:.1f} & {summary['incl_p95']:.1f} \\\\")
    tex.append(f"Witness verify (\\,$\\mu$s) & {summary['wit_p50']:.1f} & {summary['wit_p95']:.1f} \\\\")
    tex.append(f"Total verify (\\,$\\mu$s) & {summary['tot_p50']:.1f} & {summary['tot_p95']:.1f} \\\\")
    tex.append(f"Staple JSON size (bytes) & {summary['json_p50']:.0f} & {summary['json_p95']:.0f} \\\\")
    tex.append(f"Raw payload est. (bytes) & {summary['raw_p50']:.0f} & {summary['raw_p95']:.0f} \\\\")
    tex.append("\\bottomrule")
    tex.append("\\end{tabular}")
    tex.append(
        "\\caption{Distributional micro-evaluation over $n=%d$ synthetic trials "
        "(balanced-tree inclusion proofs with $L\\in[%d,%d]$ and witness cosignatures $m\\in\\{%s\\}$). "
        "We report robust p50/p95 percentiles to reduce Python/OS jitter effects.}"
        % (summary["n"], summary["L_min"], summary["L_max"], ",".join(str(x) for x in summary["m_set"]))
    )
    tex.append("\\label{tab:pct-dist-summary}")
    tex.append("\\end{table}")
    tex.append("")

    (ROOT / "_insert_pct_dist_summary_table.tex").write_text("\n".join(tex), encoding="utf-8")

    # Witness compromise risk table (toy independence model).
    # Choose a "2/3-ish" threshold: t = floor(2m/3)+1.
    p_vals = [0.01, 0.05, 0.10]
    m_vals = [3, 5, 7, 9]
    rows = []
    for m in m_vals:
        t = (2 * m) // 3 + 1
        rows.append((m, t, [_binom_tail(m, t, p) for p in p_vals]))

    tex2 = []
    tex2.append("\\begin{table}[t]")
    tex2.append("\\centering")
    tex2.append("\\small")
    tex2.append("\\begin{tabular}{r r r r r}")
    tex2.append("\\toprule")
    tex2.append("$m$ & $t$ & $p=1\\%$ & $p=5\\%$ & $p=10\\%$ \\\\")
    tex2.append("\\midrule")
    for m, t, probs in rows:
        tex2.append(f"{m} & {t} & {probs[0]:.2e} & {probs[1]:.2e} & {probs[2]:.2e} \\\\")
    tex2.append("\\bottomrule")
    tex2.append("\\end{tabular}")
    tex2.append(
        "\\caption{Toy independence model: if each witness is compromised with probability $p$, "
        "the table reports $\\Pr[\\text{attacker controls }\\ge t\\text{ of }m]$ for a "
        "$t$-of-$m$ cosigning policy with $t=\\lfloor 2m/3\\rfloor+1$.}"
    )
    tex2.append("\\label{tab:witness-compromise}")
    tex2.append("\\end{table}")
    tex2.append("")
    (ROOT / "_insert_witness_compromise_table.tex").write_text("\n".join(tex2), encoding="utf-8")

    # Figures: CDFs for total verify time and JSON size.
    def cdf_plot(values: List[float], xlabel: str, out_pdf: Path) -> None:
        xs = sorted(values)
        ys = [i / (len(xs) - 1) if len(xs) > 1 else 1.0 for i in range(len(xs))]
        plt.figure()
        plt.plot(xs, ys)
        plt.xlabel(xlabel)
        plt.ylabel("CDF")
        plt.tight_layout()
        plt.savefig(out_pdf)
        plt.close()

    cdf_plot(df["total_us"].tolist(), "Total verify time (microseconds)", ROOT / "pct_total_verify_cdf.pdf")
    cdf_plot(df["json_bytes"].tolist(), "Staple JSON size (bytes)", ROOT / "pct_staple_json_cdf.pdf")


def main() -> None:
    results = run_trials()
    write_outputs(results)
    print("Wrote distributional outputs:", len(results), "trials")


if __name__ == "__main__":
    main()
