#!/usr/bin/env python3
"""capsule_open_dispute_ref.py

Executable reference checker for Merkle-sealed capsule selective-disclosure disputes.

Implements a minimal challenge/response micro-protocol:
  - challenge: capsule_open_challenge (sid, root, leaf_count, reveal_policy_digest, requested_paths)
  - response:  capsule_open_response  (sid, root, leaf_count, reveal_policy_digest, openings[], optional multiproof)

Safety goal: adjudication depends only on the committed root and a governance-pinned
reveal policy; proposers cannot "over-reveal" sensitive fields, and challengers
cannot demand forbidden fields.

This tool is dependency-free and replays commitments offline.

Commands:
  emit-demo   -> prints demo policy + challenge + response + verify result
  verify      --policy <json> --challenge <json> --response <json>

Notes:
  - Signatures are treated as opaque strings here; deployments should bind
    signatures to canonical digests.
  - Canonical digest profile: SHA256(canonical_json(obj)).
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from typing import Any, Dict, List, Tuple

# Import Merkle capsule helpers from the local reference tool.
# (This archive keeps tools adjacent; auditors can vendor these functions.)
import merkle_capsule_ref as mcr


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def digest_obj(obj: Any) -> str:
    return sha256_hex(canonical_json(obj))


def load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _policy_required_forbidden(policy: Dict[str, Any]) -> Tuple[List[str], List[str]]:
    req = policy.get("required_paths", [])
    forb = policy.get("forbidden_paths", [])
    if not isinstance(req, list) or not isinstance(forb, list):
        raise ValueError("policy.required_paths and policy.forbidden_paths must be lists")
    req = [str(x) for x in req]
    forb = [str(x) for x in forb]
    return req, forb


def verify(
    policy: Dict[str, Any],
    challenge: Dict[str, Any],
    response: Dict[str, Any],
    bond_policy: Dict[str, Any] | None = None,
    rate_limit_ticket: Dict[str, Any] | None = None,
    ledger_jsonl: str | None = None,
) -> Dict[str, Any]:
    """Verify a capsule-open dispute transcript.

    Returns a dict with ok/bad_reasons.
    """
    bad: List[str] = []

    # Policy digest binding
    policy_digest = digest_obj(policy)
    if challenge.get("reveal_policy_digest_sha256") != policy_digest:
        bad.append("challenge reveal_policy_digest mismatch")
    if response.get("reveal_policy_digest_sha256") != policy_digest:
        bad.append("response reveal_policy_digest mismatch")

    # Basic binding fields must match
    for k in ["sid", "merkle_root_sha256", "leaf_count"]:
        if challenge.get(k) != response.get(k):
            bad.append(f"mismatch field {k}")

    # Enforce minimality: challenge must request exactly policy.required_paths.
    required, forbidden = _policy_required_forbidden(policy)
    requested = challenge.get("requested_paths", [])
    if not isinstance(requested, list):
        bad.append("challenge requested_paths not a list")
        requested = []

    # Canonicalize sets by sorting unique strings.
    req_set = sorted(set(required))
    reqd_set = sorted(set(str(x) for x in requested))
    if reqd_set != req_set:
        bad.append("requested_paths must equal policy.required_paths (minimal reveal)")

    # Forbidden paths must not be requested.
    forb_set = set(forbidden)
    if any(p in forb_set for p in reqd_set):
        bad.append("challenge requests forbidden path")

    # Optional anti-griefing: challenger bond sized to verification work.
    if bond_policy is not None:
        bond_digest = digest_obj(bond_policy)
        if challenge.get("bond_policy_digest_sha256") not in (None, bond_digest):
            bad.append("challenge bond_policy_digest mismatch")
        if "challenge_bond_amount" in challenge:
            try:
                bond_amt = float(challenge.get("challenge_bond_amount", 0.0) or 0.0)
            except Exception:
                bond_amt = 0.0
                bad.append("invalid challenge_bond_amount")

            # work ≈ f(k, log2(n_padded)) with optional clustering assumptions
            leaf_count_int = int(response.get("leaf_count", 0) or 0)
            n = 1
            while n < max(1, leaf_count_int):
                n *= 2
            logn = int(math.log2(n)) if n > 1 else 0

            k = len(req_set)
            model = str(bond_policy.get("work_model", "audit_paths"))
            if model in ("audit_paths", "dense_compact_worst"):
                work_hashes = k * logn
            elif model == "dense_compact_contig_upper":
                work_hashes = logn if k <= 1 else min(k * logn, 2 * logn)
            elif model == "dense_compact_contig_expected":
                work_hashes = logn
            else:
                work_hashes = k * logn
            try:
                B_min = float(bond_policy.get("B_min", 0.0) or 0.0)
                alpha = float(bond_policy.get("alpha_per_hash", 0.0) or 0.0)
            except Exception:
                B_min, alpha = 0.0, 0.0
            min_bond = max(B_min, alpha * float(work_hashes))
            if bond_amt + 1e-12 < min_bond:
                bad.append("challenge bond below policy minimum")

    # Optional replayable rate limit: challenge references a ticket digest + use index.
    # Uniqueness of (ticket_digest, use_index) can be checked by scanning a public ledger.
    if "rate_limit_ticket_digest_sha256" in challenge or "rate_limit_use_index" in challenge:
        td = challenge.get("rate_limit_ticket_digest_sha256")
        ui = challenge.get("rate_limit_use_index")
        if not (isinstance(td, str) and len(td) == 64):
            bad.append("invalid rate_limit_ticket_digest_sha256")
        if not isinstance(ui, int) or ui < 0:
            bad.append("invalid rate_limit_use_index")

        # If a ticket object is provided, bind digest.
        if rate_limit_ticket is not None and isinstance(td, str):
            t_body = {k: v for k, v in rate_limit_ticket.items() if k != "digest_sha256"}
            t_digest = digest_obj(t_body)
            if td != t_digest:
                bad.append("rate limit ticket digest mismatch")

        # If ledger is provided, enforce uniqueness (offline replay).
        if ledger_jsonl is not None and isinstance(td, str) and isinstance(ui, int):
            try:
                with open(ledger_jsonl, "r", encoding="utf-8") as f:
                    seen = 0
                    for ln in f:
                        ln = ln.strip()
                        if not ln:
                            continue
                        try:
                            obj = json.loads(ln)
                        except Exception:
                            continue
                        if obj.get("type") != "capsule_open_challenge":
                            continue
                        if obj.get("rate_limit_ticket_digest_sha256") == td and obj.get("rate_limit_use_index") == ui:
                            seen += 1
                    if seen > 1:
                        bad.append("rate limit (ticket_digest,use_index) reused")
            except Exception:
                bad.append("could not read ledger_jsonl for rate limit check")

    # Response must reveal exactly requested paths; no extra.
    openings = response.get("openings", [])
    if not isinstance(openings, list):
        bad.append("response openings not a list")
        openings = []

    opened_paths = [o.get("path") for o in openings if isinstance(o, dict)]
    opened_set = sorted(set(str(p) for p in opened_paths if p is not None))
    if opened_set != reqd_set:
        bad.append("response openings must cover exactly requested_paths (no extra openings)")

    # Verify Merkle evidence:
    #   - If response provides a compact multiproof, verify it once for all openings.
    #   - Otherwise verify per-opening audit paths.
    try:
        root = bytes.fromhex(str(response.get("merkle_root_sha256")))
    except Exception:
        root = b""
        bad.append("invalid merkle_root_sha256")

    leaf_count = int(response.get("leaf_count", 0) or 0)

    mp = response.get("multiproof")
    if mp is not None:
        if not isinstance(mp, dict):
            bad.append("multiproof must be an object")
        else:
            if mp.get("root_sha256") not in (None, response.get("merkle_root_sha256")):
                bad.append("multiproof.root_sha256 mismatch")
            sib_hex = mp.get("sibling_hashes", [])
            if not isinstance(sib_hex, list):
                bad.append("multiproof.sibling_hashes not a list")
                sib_hex = []
            try:
                sibs = [bytes.fromhex(str(h)) for h in sib_hex]
            except Exception:
                sibs = []
                bad.append("invalid multiproof sibling hash hex")

            tuples: List[Tuple[str, Any, int]] = []
            for o in openings:
                if not isinstance(o, dict):
                    bad.append("opening not an object")
                    continue
                path = o.get("path")
                if path in forb_set:
                    bad.append(f"opened forbidden path: {path}")
                    continue
                if path not in req_set:
                    bad.append(f"opened path not required: {path}")
                    continue
                try:
                    idx = int(o.get("leaf_index"))
                except Exception:
                    bad.append(f"invalid leaf_index for {path}")
                    continue
                tuples.append((str(path), o.get("value"), idx))

            ok = mcr.verify_multiproof(root, tuples, sibs, leaf_count)
            if not ok:
                bad.append("bad merkle multiproof")
    else:
        for o in openings:
            if not isinstance(o, dict):
                bad.append("opening not an object")
                continue
            path = o.get("path")
            if path in forb_set:
                bad.append(f"opened forbidden path: {path}")
                continue
            if path not in req_set:
                bad.append(f"opened path not required: {path}")
                continue

            try:
                idx = int(o.get("leaf_index"))
            except Exception:
                bad.append(f"invalid leaf_index for {path}")
                continue
            ap_hex = o.get("audit_path", [])
            if not isinstance(ap_hex, list):
                bad.append(f"audit_path not list for {path}")
                continue
            try:
                ap = [bytes.fromhex(str(h)) for h in ap_hex]
            except Exception:
                bad.append(f"invalid audit_path hex for {path}")
                continue
            value = o.get("value")
            ok = mcr.verify_audit_path(root, str(path), value, idx, ap, leaf_count)
            if not ok:
                bad.append(f"bad merkle proof for {path}")

    return {"ok": len(bad) == 0, "bad_reasons": bad, "policy_digest_sha256": policy_digest}

def _demo_bond_policy() -> Dict[str, Any]:
    return {
        "type": "docf_capsule_open_bond_policy_v0",
        "policy_id": "bondpolicy:v0:hash_work",
        "B_min": 0.01,
        "alpha_per_hash": 0.0002,
        "work_model": "dense_compact_contig_upper",
        "notes": "Demo: bond proportional to SHA-256 work for verifying k openings in a complete Merkle tree (padded to power-of-two)."
    }


def _demo_policy() -> Dict[str, Any]:
    return {
        "type": "docf_capsule_reveal_policy_v0",
        "policy_id": "revealpolicy:v0:min_fields",
        "required_paths": [
            "/core/prover_system_id",
            "/core/prover_binary_sha256",
            "/core/vk_digest_sha256",
            "/policy/cluster_rule_digest"
        ],
        "forbidden_paths": [
            "/core/operator_id",
            "/core/hardware_profile",
            "/attestations/tpm_quote_digest",
            "/attestations/sigstore_bundle_digest"
        ],
        "notes": "Demo policy: reveal only proof-system binding fields; keep operator identity and hardware private unless separately required."
    }


def _open_paths_from_capsule(capsule_path: str, paths: List[str]) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    capsule = load_json(capsule_path)
    leaves = capsule.get("leaves", [])
    leaves_sorted = sorted(leaves, key=lambda x: x["path"])
    leaf_hashes = [mcr.leaf_hash(e["path"], e.get("value")) for e in leaves_sorted]
    root, levels = mcr.build_tree(leaf_hashes)
    if mcr.hex_bytes(root) != capsule.get("root_sha256"):
        raise ValueError("capsule root mismatch")

    path_to_index = {e["path"]: i for i, e in enumerate(leaves_sorted)}
    openings: List[Dict[str, Any]] = []
    for p in paths:
        if p not in path_to_index:
            raise ValueError(f"path not in capsule: {p}")
        idx = path_to_index[p]
        ap = mcr.audit_path(levels, idx)
        openings.append({
            "path": p,
            "value": leaves_sorted[idx].get("value"),
            "leaf_index": idx,
            "audit_path": [mcr.hex_bytes(x) for x in ap],
        })
    return capsule, openings



def _multiproof_from_capsule(capsule_path: str, paths: List[str]) -> Tuple[Dict[str, Any], Dict[str, Any], List[Dict[str, Any]]]:
    """Return (capsule, multiproof_obj, openings_without_audit_paths)."""
    capsule = load_json(capsule_path)
    leaves = capsule.get("leaves", [])
    leaves_sorted = sorted(leaves, key=lambda x: x["path"])
    leaf_hashes = [mcr.leaf_hash(e["path"], e.get("value")) for e in leaves_sorted]
    root, levels = mcr.build_tree(leaf_hashes)
    if mcr.hex_bytes(root) != capsule.get("root_sha256"):
        raise ValueError("capsule root mismatch")

    path_to_index = {e["path"]: i for i, e in enumerate(leaves_sorted)}
    indices: List[int] = []
    openings: List[Dict[str, Any]] = []
    for p in paths:
        if p not in path_to_index:
            raise ValueError(f"path not in capsule: {p}")
        idx = path_to_index[p]
        indices.append(idx)
        openings.append({
            "path": p,
            "value": leaves_sorted[idx].get("value"),
            "leaf_index": idx,
        })

    sibs = mcr.multiproof_sibling_hashes(levels, indices)
    mp = {
        "type": "docf_merkle_multiproof_v0",
        "profile": "rfc6962_style_sha256_dense_v0",
        "root_sha256": capsule["root_sha256"],
        "leaf_count": capsule["leaf_count"],
        "sibling_hashes": [mcr.hex_bytes(x) for x in sibs],
        "opened_paths": list(paths),
    }
    return capsule, mp, openings


def emit_demo() -> Dict[str, Any]:
    policy = _demo_policy()
    policy_digest = digest_obj(policy)
    bond_policy = _demo_bond_policy()
    bond_policy_digest = digest_obj(bond_policy)

    capsule_path = "examples/merkle_capsule_demo.json"
    capsule, mp, openings = _multiproof_from_capsule(capsule_path, policy["required_paths"])

    # Optional rate-limit ticket (opaque signature in this reference tool)
    rate_ticket = {
        "type": "docf_capsule_open_rate_limit_ticket_v0",
        "ticket_id": "ticket:demo:2026-02-28:challengerA:0001",
        "epoch_id": "2026-02-28T00:00:00Z",
        "challenger_id": "challengerA",
        "max_uses": 3,
        "issuer_id": "governance-demo",
        "issued_at_utc": "2026-02-28T00:00:05Z",
        "expires_at_utc": "2026-02-28T01:00:00Z",
        "issuer_sig": "SIG_DEMO_000000",
    }
    rate_ticket["digest_sha256"] = digest_obj({k: v for k, v in rate_ticket.items() if k != "digest_sha256"})

    sid = "demo-entry-001"
    challenge = {
        "type": "capsule_open_challenge",
        "sid": sid,
        "merkle_root_sha256": capsule["root_sha256"],
        "leaf_count": capsule["leaf_count"],
        "reveal_policy_digest_sha256": policy_digest,
        "requested_paths": list(policy["required_paths"]),
        "bond_policy_digest_sha256": bond_policy_digest,
        "challenge_bond_amount": 0.05,
        "challenge_bond_asset": "unit:demo",
        "rate_limit_ticket_digest_sha256": rate_ticket["digest_sha256"],
        "rate_limit_use_index": 0,
        "challenge_rate_limit_tag": f"ticket:{rate_ticket['digest_sha256']}:0",
        "challenge_deadline_utc": "2026-02-28T00:05:00Z",
        "challenge_nonce": "demo-nonce-0001",
        "challenger_sig": "sig:demo-challenger",
    }

    response = {
        "type": "capsule_open_response",
        "sid": sid,
        "merkle_root_sha256": capsule["root_sha256"],
        "leaf_count": capsule["leaf_count"],
        "reveal_policy_digest_sha256": policy_digest,
        "openings": openings,
        "multiproof": mp,
        "responder_sig": "sig:demo-proposer",
    }

    verdict = verify(policy, challenge, response, bond_policy=bond_policy, rate_limit_ticket=rate_ticket)
    return {"policy": policy, "bond_policy": bond_policy, "rate_limit_ticket": rate_ticket, "challenge": challenge, "response": response, "verdict": verdict}


def main() -> None:
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)

    sp.add_parser("emit-demo")

    v = sp.add_parser("verify")
    v.add_argument("--policy", required=True)
    v.add_argument("--challenge", required=True)
    v.add_argument("--response", required=True)
    v.add_argument("--bond-policy", required=False)
    v.add_argument("--rate-limit-ticket", required=False, help="Optional ticket object JSON for rate limit digest binding")
    v.add_argument("--ledger", required=False, help="Optional JSONL ledger to enforce (ticket_digest,use_index) uniqueness")

    args = ap.parse_args()

    if args.cmd == "emit-demo":
        print(json.dumps(emit_demo(), indent=2, sort_keys=True, ensure_ascii=False))
        return

    if args.cmd == "verify":
        policy = load_json(args.policy)
        challenge = load_json(args.challenge)
        response = load_json(args.response)
        bond_policy = load_json(args.bond_policy) if args.bond_policy else None
        rate_ticket = load_json(args.rate_limit_ticket) if args.rate_limit_ticket else None
        out = verify(policy, challenge, response, bond_policy=bond_policy, rate_limit_ticket=rate_ticket, ledger_jsonl=args.ledger)
        print(json.dumps(out, indent=2, sort_keys=True, ensure_ascii=False))
        sys.exit(0 if out.get("ok") else 2)


if __name__ == "__main__":
    main()
