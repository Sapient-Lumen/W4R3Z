#!/usr/bin/env python3
"""make_scitt_statement_tpv_gate_satisfaction_witnessed_ref.py

Emit a minimal SCITT-style statement payload that commits to a Witnessed TPV
gate satisfaction object (WGSO) digest.

Pedagogical JSON stand-in for a COSE-carried SCITT statement.

Usage:
  python3 make_scitt_statement_tpv_gate_satisfaction_witnessed_ref.py \
    --wgso test_vectors/tpv_gate_satisfaction_witnessed_demo.json \
    > test_vectors/tpv_gate_satisfaction_witnessed_scitt_statement_demo.json
"""

from __future__ import annotations

import argparse
import hashlib
import json
from typing import Any, Dict

from docf_ref_tools_common import jcs, load_json


def sha256_pref(b: bytes) -> str:
    return "sha256:" + hashlib.sha256(b).hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--wgso", required=True)
    ap.add_argument("--signer", default="did:web:gatekeeper.example")
    ap.add_argument("--log-id", default="scitt-demo")
    args = ap.parse_args()

    wgso = load_json(args.wgso)
    dwgso = sha256_pref(jcs(wgso))

    stmt: Dict[str, Any] = {
        "media_type": "application/scitt-statement+cose",
        "payload": {
            "statement_type": "docf.tpv_gate_satisfaction_witnessed",
            "wgso_digest": dwgso,
            "wgso_ref": args.wgso,
            "gate_policy_nf_digest": wgso.get("gate_policy_nf_digest", ""),
            "gate_policy_digest": wgso.get("gate_policy_digest", ""),
            "tpv_digest": wgso.get("tpv_digest", ""),
            "witnessed_checkpoint_bundle_digest": wgso.get("witnessed_checkpoint_bundle_digest", ""),
            "result": wgso.get("result", ""),
            "tpv_subject": wgso.get("tpv_subject", {}),
        },
        "signer": args.signer,
        "log_id": args.log_id,
    }

    print(json.dumps(stmt, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
