#!/usr/bin/env python3
"""make_multihoming_microstructure.py

Generates:
  - `_insert_multihoming_heterogeneity_table.tex`
  - `pct_multihoming_heterogeneity_hidden_bits.pdf`

Purpose
-------
The baseline multi-homing demo (`make_multihoming_experiment.py`) shows the
homogeneous case where each market has the same per-attempt base error `eps0`.
In practice, markets can differ materially in *security level* (proof system,
parameter choices, deployment profile). Then the hidden exposure from routing / multi-homing
is driven by the *weakest* venue, not just the count of venues.

Model
-----
- A statement is posted across M markets. Each market i has per-attempt base error eps0_i.
- Each market discloses r attempts locally.
- Under independence across attempts, the global false-accept probability is
      eps_global = 1 - Π_i (1 - eps0_i)^r
  while a single market j prices
      eps_local  = 1 - (1 - eps0_j)^r

We report "bits" = -log2(eps). Hidden bits = local_bits - global_bits.
We also report the additive-hazard approximation in the small-eps regime:
  h(eps) = -log(1-eps)  (hazard),  h_global = Σ_i r * h(eps0_i)
  eps_global ≈ 1 - exp(-h_global) and hidden bits ≈ log2(h_global / h_local).

This script is deterministic.
"""

from __future__ import annotations

import argparse
import math
from typing import List, Tuple


def prob_after(a: int, eps0: float) -> float:
    """Exact independent repetition: 1 - (1-eps0)^a."""
    return -math.expm1(a * math.log1p(-eps0))


def hazard(eps: float) -> float:
    # h = -ln(1-eps); stable for tiny eps
    return -math.log1p(-eps)


def lg2(x: float) -> float:
    return math.log(x, 2.0)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--r", type=int, default=8, help="attempts disclosed per market")
    ap.add_argument("--Ms", type=str, default="1,2,3,5,10", help="comma-separated M values")
    ap.add_argument("--local_bits", type=float, default=120.0, help="base bits for the local market")
    ap.add_argument("--other_bits", type=float, default=80.0, help="base bits for the other markets")
    ap.add_argument("--out_table", type=str, default="_insert_multihoming_heterogeneity_table.tex")
    ap.add_argument("--out_plot", type=str, default="pct_multihoming_heterogeneity_hidden_bits.pdf")
    args = ap.parse_args()

    r = args.r
    Ms: List[int] = [int(x.strip()) for x in args.Ms.split(",") if x.strip()]

    # Two contrasting scenarios:
    #  A) local is very secure; others are weaker (routing hides big exposure).
    #  B) local is weak; others are very secure (routing hides little additional exposure).
    scenarios = [
        ("Secure local, weak elsewhere", args.local_bits, args.other_bits),
        ("Weak local, secure elsewhere", args.other_bits, args.local_bits),
    ]

    rows: List[Tuple[str, int, float, float, float, float, float]] = []
    # (scenario, M, bits_local, bits_global, hidden_bits, log2M, hazard_ratio_bits)

    plot_series = []

    for (label, b_local0, b_other0) in scenarios:
        eps_local0 = 2.0 ** (-b_local0)
        eps_other0 = 2.0 ** (-b_other0)

        ys = []
        for M in Ms:
            eps_local = prob_after(r, eps_local0)
            # global: 1 local + (M-1) others
            # (1-eps_local0)^r * (1-eps_other0)^(r*(M-1))
            log_term = r * (math.log1p(-eps_local0) + (M - 1) * math.log1p(-eps_other0))
            eps_global = -math.expm1(log_term)

            bits_local = -lg2(eps_local)
            bits_global = -lg2(eps_global)
            hidden = bits_local - bits_global

            # small-eps hazard factor
            h_local = r * hazard(eps_local0)
            h_global = r * (hazard(eps_local0) + (M - 1) * hazard(eps_other0))
            hazard_ratio_bits = lg2(h_global / h_local)

            rows.append((label, M, bits_local, bits_global, hidden, lg2(float(M)), hazard_ratio_bits))
            ys.append(hidden)

        plot_series.append((label, Ms, ys))

    # Write LaTeX table
    with open(args.out_table, "w", encoding="utf-8") as f:
        f.write(r"\begin{tabular}{l r r r r r r}" + "\n")
        f.write(r"\toprule" + "\n")
        f.write(r"Scenario & $M$ & Local bits & Global bits & Hidden bits & $\log_2 M$ & $\log_2(h_g/h_\ell)$ \\" + "\n")
        f.write(r"\midrule" + "\n")
        last = None
        for (label, M, bL, bG, h, l2m, hbits) in rows:
            scen = label if label != last else ""
            f.write(f"{scen} & {M} & {bL:.2f} & {bG:.2f} & {h:.2f} & {l2m:.2f} & {hbits:.2f} \\\\\n")
            last = label
        f.write(r"\bottomrule" + "\n")
        f.write(r"\end{tabular}" + "\n")

    # Plot
    try:
        import matplotlib.pyplot as plt

        plt.figure()
        for (label, xs, ys) in plot_series:
            plt.plot(xs, ys, marker="o", label=label)
        plt.xscale("log", base=10)
        plt.xlabel("Markets M (log scale)")
        plt.ylabel("Hidden bits (local - global)")
        plt.title("Heterogeneous multi-homing: hidden bits depend on weakest venue")
        plt.legend()
        plt.tight_layout()
        plt.savefig(args.out_plot)
        plt.close()
    except Exception:
        pass


if __name__ == "__main__":
    main()
