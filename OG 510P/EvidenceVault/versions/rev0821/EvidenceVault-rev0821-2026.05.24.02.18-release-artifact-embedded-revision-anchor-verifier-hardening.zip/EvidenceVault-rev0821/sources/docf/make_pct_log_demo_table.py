#!/usr/bin/env python3
"""
make_pct_log_demo_table.py

Generates `_insert_pct_log_demo_table.tex` from `test_vectors/pct_log_demo.json`.

Shows:
- tree size
- root hash prefix
- inclusion path length per artifact kind
- inclusion proof bytes (hashes * 32)
"""
from __future__ import annotations
import json
import argparse
from pathlib import Path


def _tex_escape(s: str) -> str:
    return s.replace("_", r"\_")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", default="test_vectors/pct_log_demo.json")
    ap.add_argument("--out", default="_insert_pct_log_demo_table.tex")
    args = ap.parse_args()

    obj = json.loads(Path(args.inp).read_text(encoding="utf-8"))
    root = obj["root_hash"]
    proofs = obj["inclusion_proofs"]

    lines = []
    lines.append(r"\begin{table}[t]")
    lines.append(r"\centering")
    lines.append(r"\caption{Toy Proof-Certificate-Transparency (PCT) log demo: a CT-style Merkle log over three artifact digests (Attempt DAG / $\varepsilon$-ledger / performance envelope). Inclusion proof size scales as $O(\log n)$ hashes; each hash is 32 bytes for SHA-256.}")
    lines.append(r"\label{tab:pct-demo}")
    lines.append(r"\begin{tabular}{lrrrr}")
    lines.append(r"\toprule")
    lines.append(r"Artifact & Leaf idx & Path hashes & Proof bytes & Root (prefix)\\")
    lines.append(r"\midrule")
    for kind, p in proofs.items():
        idx = int(p["leaf_index"])
        path_len = len(p["path"])
        proof_bytes = path_len * 32
        lines.append(f"{_tex_escape(kind)} & {idx} & {path_len} & {proof_bytes} & \\texttt{{{root[:18]}..}}\\\\")
    lines.append(r"\bottomrule")
    lines.append(r"\end{tabular}")
    lines.append(r"\end{table}")

    Path(args.out).write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
