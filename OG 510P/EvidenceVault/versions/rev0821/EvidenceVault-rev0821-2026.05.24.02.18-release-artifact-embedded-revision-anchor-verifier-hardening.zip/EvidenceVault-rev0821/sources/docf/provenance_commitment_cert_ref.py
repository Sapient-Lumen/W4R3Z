#!/usr/bin/env python3
"""provenance_commitment_cert_ref.py

Reference tool: compile a Provenance Commitment Certificate (PCC).

Motivation
----------
SCC (statement commitment) prevents *adaptive statement selection* after public
coins are known, but does not by itself explain *why* the pinned statement/circuit
should be trusted to match an intended semantics.

PCC is a lightweight, cacheable bridge between dOCF manifests and software
supply-chain provenance:
  - Pin the compiled artifact digest (circuit/VK/program)
  - Pin its source + build recipe metadata
  - Optionally point to an external signed attestation (in-toto / SLSA / DSSE)

This tool intentionally avoids external dependencies and emits deterministic
SHA-256 digests over canonical JSON encodings (sorted keys).

Input JSON (minimal)
--------------------
{
  "sid": "...",
  "manifest_digest": "sha256:...",
  "subject": {"subject_kind": "plonk_circuit", "artifact_digest": "sha256:..."},
  "provenance": {"source": {"repo_url": "...", "commit": "..."}, "recipe": {...}}
}

Output JSON
-----------
{
  "type": "provenance_commitment_cert",
  ...,
  "derived": {"provenance_digest": "sha256:...", ...},
  "digest": "sha256:..."
}

Notes
-----
PCC is primarily a governance/compliance artifact (Prov axis P2/P3). It does not
change the cryptographic per-attempt soundness bound directly, but it improves
repeatability and third-party auditability of the statement/circuit semantics.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from typing import Any, Dict


def _canon(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _sha256_hex(obj: Any) -> str:
    return "sha256:" + hashlib.sha256(_canon(obj)).hexdigest()


def compile_pcc(inp: Dict[str, Any]) -> Dict[str, Any]:
    sid = inp.get("sid")
    manifest_digest = inp.get("manifest_digest")
    subject = inp.get("subject")
    provenance = inp.get("provenance")

    if not isinstance(sid, str) or not sid:
        raise ValueError("sid must be a non-empty string")
    if not isinstance(manifest_digest, str) or not manifest_digest:
        raise ValueError("manifest_digest must be a non-empty string")
    if not isinstance(subject, dict):
        raise TypeError("subject must be an object")
    if not isinstance(provenance, dict):
        raise TypeError("provenance must be an object")

    if not isinstance(subject.get("subject_kind"), str) or not subject.get("subject_kind"):
        raise ValueError("subject.subject_kind must be a non-empty string")
    if not isinstance(subject.get("artifact_digest"), str) or not subject.get("artifact_digest"):
        raise ValueError("subject.artifact_digest must be a non-empty string")

    src = provenance.get("source")
    if not isinstance(src, dict):
        raise TypeError("provenance.source must be an object")
    if not isinstance(src.get("repo_url"), str) or not src.get("repo_url"):
        raise ValueError("provenance.source.repo_url must be a non-empty string")
    if not isinstance(src.get("commit"), str) or not src.get("commit"):
        raise ValueError("provenance.source.commit must be a non-empty string")

    # Canonical provenance digest. Exclude any precomputed digests.
    prov_no_digest = json.loads(_canon(provenance).decode("utf-8"))
    # Remove nested digest fields if present.
    for k in ["digest", "provenance_digest", "recipe_digest", "toolchain_digest"]:
        if k in prov_no_digest:
            prov_no_digest.pop(k, None)
    provenance_digest = _sha256_hex(prov_no_digest)

    out: Dict[str, Any] = {
        "type": "provenance_commitment_cert",
        "sid": sid,
        "market_id": inp.get("market_id"),
        "manifest_digest": manifest_digest,
        "subject": subject,
        "provenance": provenance,
        "derived": {
            "provenance_digest": provenance_digest,
            "binding_rule": "policy: subject.artifact_digest must match the subject digest in the referenced provenance attestation (if present)",
            "compliance_hint": "Prov axis: PCC supports P2 (signed provenance) and, with transparency/rebuild checks, P3",
        },
        "receipts": inp.get("receipts") or {},
        "notes": inp.get(
            "notes",
            "PCC pins build/source provenance for a compiled proving artifact (circuit/VK/program) to support third-party audit and common-mode risk mitigation.",
        ),
    }

    out_no_digest = dict(out)
    out_no_digest.pop("digest", None)
    out["digest"] = _sha256_hex(out_no_digest)
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="infile", default=None, help="Input JSON file (default: stdin).")
    ap.add_argument("--out", dest="outfile", default=None, help="Output JSON file (default: stdout).")
    args = ap.parse_args()

    raw = sys.stdin.read() if args.infile is None else open(args.infile, "r", encoding="utf-8").read()
    obj = json.loads(raw) if raw.strip() else {}
    out = compile_pcc(obj)
    s = json.dumps(out, indent=2, sort_keys=False) + "\n"

    if args.outfile is None:
        sys.stdout.write(s)
    else:
        with open(args.outfile, "w", encoding="utf-8") as f:
            f.write(s)


if __name__ == "__main__":
    main()
