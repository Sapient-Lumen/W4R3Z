## v86.41-ai (2026-02-28)
- Added a **canonical compact multiproof** encoding for complete (padded) Merkle trees used by capsule lists (single ordered `sibling_hashes` list; no per-node position metadata).
- Extended the capsule opening micro-protocol with an **optional anti-griefing bond policy** (schema + demo vectors); checker now accepts either audit paths or the compact multiproof.
- Updated the capsule cost model table/figure to include dense-tree compact multiproofs (average case) and added a generator script `make_merkle_capsule_costs.py`.

## v86.40-ai (2026-02-28)
- Added an **executable capsule opening dispute transcript** for Merkle-sealed capsules (challenge/response), making selective disclosure implementable as an optimistic on-chain primitive.
- New schemas: `docf_capsule_open_challenge_v0.schema.json`, `docf_capsule_open_response_v0.schema.json`.
- New tool + vectors: `capsule_open_dispute_ref.py` and `test_vectors/capsule_open_*_demo.json`.

## v86.39-ai (2026-02-28)
- Added Merkle-sealed capsule objects for privacy-preserving dispute games: selective disclosure via audit paths, plus an explicit reveal-policy object to keep adjudication minimal and deterministic.
- New artifacts: `docf_merkle_capsule_v0.schema.json`, `docf_capsule_reveal_policy_v0.schema.json`, `merkle_capsule_ref.py`, and demos under `examples/`.
- Paper D now includes a payload size table (`_insert_merkle_capsule_sizes.tex`) and a cost-model figure (`figures/merkle_capsule_proof_sizes.pdf`) comparing dense audit paths vs sparse-map multiproof metadata and compactness.

## v86.37-ai (2026-02-28)
- Added a bond-based incentive lemma making correlation clusters enforceable in adversarial markets: truthful cluster commitment is a best response when the proposer bond upper-bounds the maximum score gain from misassignment scaled by minimum challenge coverage.
- New paper-ready artifacts: `_insert_cluster_dispute_incentives_table.tex`, `figures/bond_threshold_demo.pdf`, and generator `bond_threshold_demo.py`.
- References: UMA Optimistic Oracle bond+liveness guidance + ``Demystifying Incentives in the Consensus Computer'' (IACR ePrint 2015/702).

## v86.36-ai (2026-02-28)
- Enforced correlation accounting: added a full **cluster-commitment + dispute-game** sketch (digest-only publication, challenge/reveal/adjudicate, reclassification).
- New artifacts: `docf_cluster_dispute_fsm_v0.schema.json`, `examples/cluster_dispute_fsm_demo.json`, `_insert_cluster_dispute_table.tex`, `docf_cluster_dispute_case_v0.schema.json`, `cluster_dispute_case_ref.py`, `test_vectors/cluster_dispute_case_demo.json`.
- Updated Paper D and Paper E to treat correlation capsules as a first-class governance primitive with an enforceable dispute path.
- References: added OP Stack spec pages for Fault Proof / Fault Dispute Game.

## v86.35-ai (2026-02-28)
- Added correlation capsules + deterministic cluster IDs and introduced `independent_clusters` checkpointing.
- Extended online risk tariffs from scalar $\lambda$ to cluster-indexed $\lambda_c$ and added a toy simulation.

## v86.34-ai (2026-02-28)
- Paper D: added market-binding map from current prover-market lifecycles to resolver inputs ($Q$ and option multipliers).
- Paper D: added correlation-aware checkpointing via published clusters + demo figure `figures/cluster_checkpoint_demo.pdf`.
- Added `examples/toy_epoch_ledger_clusters.json` + `cluster_checkpoint_demo.py`.
- Extended `eps_ledger_ref.py` and `docf_eps_ledger_v0.schema.json` to support optional `cluster` fields and `independent_clusters` rule.
- References: added Neely (2010) for virtual-queue / Lyapunov optimization framing of replayable dual updates.

## v86.33-ai (2026-02-28)
- Paper D: added a worked example (receipt → resolved ε → ledger entry → epoch checkpoint) + a demo online λ schedule figure.
- Added `online_lambda_policy_ref.py` and `figures/lambda_schedule_demo.pdf`.
- References: added long-term-constraint OCO works (Mahdavi–Jin–Yang; Jenatton–Huang–Archambeau; Zinkevich).

## v86.32-ai (2026-02-28)
- Paper D: added an online/primal--dual view of risk-budgeted procurement (dynamic $\lambda$) with replayable updates; added two references (Buchbinder--Naor; Hazan).
- Paper A: added an explicit bridge paragraph from per-proof option accounting to portfolio governance ($\eps$-ledgers).
- Added `AI_RESEARCH_NOTES.md`.

## v86.31 (2026-02-28)
- Added an exact threshold-optimization experiment for quorum sizing under WDD budgets: `make_quorum_threshold_optimization_experiment.py`.
  - New artifacts: `_insert_quorum_threshold_opt_table.tex`, `pct_quorum_threshold_opt.pdf`, and `test_vectors/quorum_threshold_opt_results.json`.
- Paper J/K: integrated a new result showing that optimizing $t$ (holding $m$ fixed) can restore feasibility by increasing $\rho_{\max}(m,t)$ while still meeting the same liveness target.

## v86.30 (2026-02-28)
- Added a Pareto-style cost--redundancy exploration for quorum sizing under WDD budgets: `make_quorum_pareto_frontier_experiment.py`.
  - New artifacts: `_insert_quorum_pareto_frontier_table.tex`, `_insert_quorum_agg_comparison_table.tex`, `pct_quorum_pareto_frontier.pdf`, `pct_quorum_agg_comparison.pdf`, and `test_vectors/quorum_pareto_frontier_results.json`.
- Paper J/K: added a short ``tradeoff surface'' view (cost vs witness count under a fixed threshold policy) and a note on domain-weighted vs max aggregation for the WDD correlation proxy.

## v86.29 (2026-02-28)
- Added a quorum sizing solver that searches over $(m,t)$ and witness sets to satisfy a split-view risk budget and a liveness target under the WDD correlation bound: `make_quorum_sizing_solver_experiment.py`.
- New artifacts: `_insert_quorum_sizing_table.tex`, `pct_quorum_sizing_cost.pdf`, `pct_quorum_sizing_m.pdf`, and `test_vectors/quorum_sizing_results.json`.
- Paper J: added a new subsection connecting WDD budgets to deployable quorum selection and highlighting that operator diversity can dominate feasibility.
- Paper K: added a compact sizing-tool summary and solver output table.

## v86.27 (2026-02-28)
- Made WDD a first-class PCT artifact: added `docf_witness_diversity_descriptor_v0.schema.json` and a reference emitter/verifier `witness_diversity_descriptor_ref.py` (deterministic digest).
- Extended PCT bundles to a policy-carrying variant (PCTB-v2): added `docf_pct_bundle_v2.schema.json`, updated `pct_bundle_ref.py` to emit/verify v1+v2, and added `test_vectors/pct_bundle_demo_v2.json`.
- Added v2 end-to-end size accounting: `make_pct_end2end_demo_table_v2.py` and `_insert_pct_end2end_demo_table_v2.tex`; Paper J now includes the v2 table.
- Added a toy witness-set construction reference (`witness_set_optimizer_ref.py`) and a budget/selection table generator (`make_witness_set_selection_table.py`) producing `_insert_witness_set_selection_table.tex` (included in Paper J).

## v86.26 (2026-02-28)
- Added a Witness Diversity Descriptor (WDD) policy artifact and generator: `make_wdd_policy_demo.py` emits WDD diversity metrics, a correlation-budget table, and a budget curve figure.
- Paper J now includes a verifier-facing rule: compute $\hat\rho$ from the WDD and accept only if $\hat\rho$ fits the verifier's split-view risk budget.
- Paper K includes a compact WDD section to connect portability/interoperability to diversity-aware witness policies.
- Bibliography cleanup and freshness: removed a stale SCITT architecture draft key and refreshed SCITT draft metadata/access dates.

## v86.25 (2026-02-28)
- Added an analytic correlation-sensitivity stress-test for witness quorums: `make_witness_corr_sweep.py` generates `_insert_witness_corr_sweep_table.tex` and `pct_witness_corr_sweep.pdf`.
- Paper J: integrated the analytic sweep as an additional deployment lesson (common-mode failures break count-based thresholds).
- Bibliography: added an explicit `SCITTArchitectureDraft22` key and updated paperJ/paperK citations.


## v86.23 (2026-02-28)
- Portability extensions: CMBI + XLS inserts + generators; paperJ/paperK updated; PDFs rebuilt.

## v86.21 (2026-02-28)
- Added a public witness pool snapshot (2026-02-28) assembled from Witness Network tables and linked about pages.
- New artifacts: `data/witness_pool_snapshot_2026-02-28.json`, `make_witness_pool_snapshot_table.py`, `_insert_witness_pool_snapshot_table.tex`.
- Added a real-pool correlated-compromise sensitivity sweep with an augmented stress-test (multiple instances per operator): `make_witness_diversity_real_pool.py`, `test_vectors/pct_witness_diversity_real_results.json`, `_insert_witness_diversity_real_table.tex`, `pct_witness_diversity_real_bars.pdf`.
- Updated `witness_directory_ref.py` to emit/convert the snapshot deterministically.
- Papers: Paper F and Paper I updated to include the snapshot table and real-pool diversity results.

## v86.20 (2026-02-28)
- Added a toy but replayable correlated-compromise model for witness sets and an evaluation of diversity- and risk-aware selection heuristics.
- New artifacts: `make_witness_diversity_experiment.py`, `test_vectors/witness_candidate_pool_demo.json`, `test_vectors/pct_witness_diversity_results.json`, `_insert_witness_diversity_risk_table.tex`, `pct_witness_diversity_risk_bars.pdf`.
- Papers: Paper F/G/H updated; Paper I added as a focused note on witness diversity under correlated compromise.

## v86.19 (2026-02-28)
- Added a client-policy / witness-selection experiment showing that split-view detection can have an infinite tail under hard partitions unless clients occasionally explore across witness sets.
- New artifacts: `make_client_policy_experiment.py`, `test_vectors/pct_client_policy_results.json`, `_insert_client_policy_refusal_table.tex`, `pct_client_policy_refusal_cdf.pdf`.
- Paper F and Paper G: added a new evaluation subsection + table/figure (`tab:client_policy_refusal`, `fig:client_policy_cdf`) emphasizing exploration as a first-class security parameter.
- Added Paper H (`paperH.tex`): focused paper on client policies (quorum thresholds and exploration) for transparency-logged prover markets.

## v86.18 (2026-02-28)
- Added a sparse-overlay split-view experiment (topology sensitivity) and translated alert propagation into a toy client time-to-refusal table.
- Papers F/G now include `tab:split-view-topology`, `tab:split-view-client-refusal`, and the new CDF figures to expose the engineering knobs (overlay sparsity, polling cadence).
- New artifacts: `make_split_view_topology_experiment.py`, `test_vectors/pct_split_view_topology_results.json`, `pct_split_view_topology_detect_cdf.pdf`, `pct_split_view_topology_alert_p95_cdf.pdf`, `pct_split_view_topology_client_refusal_cdf.pdf`.

## v86.17 (2026-02-28)
- Added an adversarial-partition split-view latency experiment (gossip on/off, quorum policies) with auto-generated LaTeX tables and CDF figures.
- Paper F and Paper G now include the latency table (`tab:split_view_latency`) and CDFs to quantify equivocation persistence and the effect of witness gossip.
- New artifacts: `make_split_view_latency_experiment.py`, `test_vectors/pct_split_view_latency_results.json`, `pct_split_view_detect_cdf.pdf`, `pct_split_view_window_cdf.pdf`.

## v86.16 (2026-02-28)
- Paper F: added an explicit evaluation section with PCT verification microbenchmarks (new LaTeX inserts) and expanded split-view hardening citations.
- Paper G: strengthened the witness policy with a quorum-intersection lemma and inserted the threshold table.
- Added `make_pct_bench_tables.py` + `test_vectors/pct_bench_results.json` and generated `_insert_pct_bench_table.tex`, `_insert_pct_bundle_bench_table.tex`.
- Bibliography: added LogPicker (PoPETs'21) and a quantitative evaluation of CT gossip protocols (Oxford'21 thesis).

## v86.14 (2026-02-28)
- Paper G: focused note on witnessing/split-view resistance (`paperG.tex`).
- Paper F: added a split-view threat + mitigation subsection (checkpoints, RFC~9162 consistency, witness thresholding) and a concrete split-view demo table.
- Added RFC~9162 consistency proof generation/verification to `transparency_log_ref.py` (plus a selftest).
- Added signed checkpoints (`checkpoint_ref.py`) and witness cosigning (`witness_monitor_ref.py`).
- Updated the PCT demo bundle to include a checkpoint chain + consistency proof + witness cosigs; introduced PCTB-v1 schema (`docf_pct_bundle_v1.schema.json`).
- Added `split_view_demo_ref.py` + `test_vectors/split_view_demo.json` and `_insert_split_view_demo_table.tex`.

## v86.13 (2026-02-28)
- Paper G: focused note on witnessing/split-view resistance (`paperG.tex`).
- Paper F: expanded the "minimal standard" into an explicit PCT bundle (PCTB-v0) format, grounded in CT paging/tiling + Sigstore + SCITT; added a deployment mapping to Boundless/Succinct lifecycles.
- Paper E: aligned with PCTB-v0 framing and included the end-to-end staple overhead table.
- Added `docf_pct_bundle_v0.schema.json` and a working reference emitter/verifier `pct_bundle_ref.py` producing `test_vectors/pct_bundle_demo.json`.
- Added `market_round_cert_ref.py` + `test_vectors/market_round_cert_demo.json` (selection receipt example).
- Added `_insert_pct_end2end_demo_table.tex` + generator `make_pct_end2end_demo_table.py`.
- Added new bibliography entries for the CT pages extension draft and the OpenSSF Sigstore dataset.

## v86.12 (2026-02-28)
- Paper D: connected $\varepsilon$-scoring to classical scoring-auction procurement; added collusion/commitment caveats.
- Paper E: added CT/SCITT/Sigstore ``transparency substrate'' and PCT inclusion-proof demo table.
- Added Paper F: Proof Certificate Transparency (PCT) standardization track.
- Added `transparency_log_ref.py`, `make_pct_log_demo_table.py`, and `test_vectors/pct_log_demo.json`.

## v86.11 (2026-02-28)
- Paper D: added toy $\varepsilon$-scoring simulation table; added concrete build artifacts (Attempt DAG compiler + working e-value auditor) with demo listings.
- Added Paper E: receipt-complete prover markets (Attempt DAGs + transparency logs + risk budgets).
- Tools + demos: `attempt_dag_compiler_ref.py`, implemented `anytime_e_audit_ref.py`, and new demo vectors under `test_vectors/`.

## v86.10 (2026-02-28)
- Paper D rewrite: eps-scoring auctions, receipt-complete attempt DAGs, and expanded ledger composition + performance certificate discussion.
- Paper A update: standardized cancellation sizing table; added beacon waiting and grinding tax tables/lemmas; added protocol citations.
- Added eps-ledger reference tool (`eps_ledger_ref.py`) and updated `docf_eps_ledger_v0.schema.json` to allow expression-form eps fields; new numeric demo ledger.

## v86.9 (2026-02-27)
- Added Paper D: epsilon-ledgers + epsilon-scoring auctions + anytime-valid performance certificates (e-values).
- Bibliography: added canonical e-value / safe-testing references.

## v86.6 (2026-02-27)
- Anti-equivocation stapling: demo SNL staples now include an **RFC9162 consistency witness** (append-only growth evidence) from a pinned earlier checkpoint to the current head.
- Gate policies: added `require_log_consistency` plus **freshness / revocation / rotation** controls (SNL validity windows, max-age bounds, revocation lists, log-key allowlists).
- Decisions: `snl_log_inclusion` now emits a compact `staple_summary` so caches can record what was verified.
- Papers B/C: embedded the full demo staple and a consistency-requiring policy + decision walkthrough.

## v86.5 (2026-02-27)
- Transparency hardening: demo SNL staples now include **Sigsum-style witness cosignatures** (2-of-3 quorum) over the log checkpoint payload.
- Gate policies: added witness-quorum requirements and a local witness allowlist; new demo vectors: `snl_gate_policy_reuse_with_log_quorum_demo.json` and `snl_gate_decision_reuse_with_log_quorum_demo.json`.
- Benchmarks: updated `bench_snl_gate_ref.py` and regenerated `_insert_snl_gate_bench_table.tex` to include quorum verification.
- Papers B/C: added witness-cosigning discussion and embedded a demo quorum policy in Paper C.

## v86.4 (2026-02-27)
- New Paper C: `paperC.tex` (SNL-focused systems/security draft): Security Nutrition Labels as portable acceptance objects for proof markets, proof CDNs, and verifier services.
- Paper B: integrated an SNL gate-path sizing + micro-benchmark table (`_insert_snl_gate_bench_table.tex`) generated by `bench_snl_gate_ref.py`.
- Paper B: expanded case-study context to explicitly mention emerging proving networks (Succinct Network, Brevis ProverNet, Fermah) and added bibliography entries for their docs/whitepapers.
- Tools: added `bench_snl_gate_ref.py` and `test_vectors/snl_gate_bench_results.json` (reference measurements).
- Draft headers bumped to v86.3.

## v86.1 (2026-02-27)
- Paper A: added a practical cancellation sizing table (Table~\ref{tab:cancel-sizing}).
- Paper B: strengthened portability contracts with minimum-elements + sizing tables and added policy-selection + enforcement-overhead inserts.
- New derived auditor artifact: **Security Nutrition Label (SNL)**:
  - schema: `docf_security_nutrition_label_v0.schema.json`
  - reference compiler: `security_nutrition_label_ref.py`
  - demo vector: `test_vectors/security_nutrition_label_demo.json`
- Draft headers bumped to v86.1.

## v86.0 (2026-02-27)
- Expanded `paperB.tex` from a skeleton into a full draft with:
  - contract model (PABOM + TPV + policy artifacts)
  - fail-closed resolver semantics
  - attempt envelopes + Grinding Gap Certificates
  - market scoring + portfolio budgets
- Bumped version headers in `paper.tex` and `paperA.tex`.

## v85.9 (2026-02-27)
- Living spec: added a **Typed Option Repricing Report (TORR)** auditor artifact bridging boundary tags -> per-obligation resolved epsilon:
  - new schema: `docf_typed_option_repricing_report_v0.schema.json`
  - new reference compiler: `typed_option_repricing_report_ref.py`
  - new demo vectors: `test_vectors/typed_option_repricing_report_input_demo.json` and `test_vectors/typed_option_repricing_report_demo.json`
  - new figure in `paper.tex` showing the demo report
- Paper A: added a mechanization paragraph pointing to TORR; expanded FSwA related-work citations.
- Paper B: connected portability/nutrition labels to stapling a TORR for a declared volume window; fail-closed when evidence is missing.
- Rebuilt PDFs for consistency.

## v85.8 (2026-02-27)
- RPC upgraded from a sketch into a normative object in both `paper.tex` and `paperA.tex`:
  - added an explicit derivation rule for repetition coins from a single anchor boundary
  - added `_insert_rpc_anchoring_profiles_table.tex` (anchoring profiles + required evidence pointers)
- RPC schema tightened for conformance:
  - enumerated example `derivation.kind` and `anchoring.profile` values
  - made `dst` required; added optional `anchoring.commitment_digest`
- Paper B: removed placeholder references and aligned citations to existing `references.tex` entries (zkSaaS, Pianist, HyperPianist).

## v85.7 (2026-02-27)
- Paper A: promoted the retry/option story into a "boundary filtration" formalism and added an explicit repair mechanism:
  - new definitions: **boundary filtration** + **evidenced stopping-time cap** (makes commitment cuts and abort observables explicit)
  - new artifact + theorem: **Repetition Plan Certificate (RPC)** and **Locked repetition plan preserves exponentiation** (pays option tax once; avoids $(T\varepsilon)^t$ collapse)
- Living spec (`paper.tex`): fixed/proved the grinding lemmas and made RPC concrete:
  - added missing proof for Lemma~\ref{lem:grind}; fixed proof for Lemma~\ref{lem:grind-between-reps}
  - added **RPC definition** + shipped `docf_repetition_plan_cert_v0.schema.json` and `test_vectors/repetition_plan_cert_demo.json` (Figure~\ref{fig:rpc-demo})

## v85.6 (2026-02-27)
- Paper A: added a sharp operational result showing that **retry cuts between repetitions can destroy exponential amplification**:
  - new Lemma: sequential option search across repetitions reprices \(\varepsilon^t\) to \((T\varepsilon)^t\) when each repetition can be searched over \(T\) public-coin candidates
  - new one-page **fail-closed resolver calculus**: obligations are repriced only by evidenced attempt counts and option factors; missing evidence forces downgrade
- Living spec (`paper.tex`): mirrored the above as Lemma~\ref{lem:grind-between-reps} in the resolver calculus, making the rule part of the contract semantics.

## v85.4 (2026-02-27)
- Paper A: upgraded the core retry/conditioning result into an **option-sensitive (boundary-tagged) repricing theorem**:
  - added boundary/option-factor formalism and per-term sensitivity sets (so obligations are repriced by $Q\cdot\prod_{b\in S}T_b$, not always by worst-case $QT_{\mathrm{tot}}$)
  - added a typed-union corollary for composing heterogeneous terms without overcharging
- Living spec (`paper.tex`): added a compact **typed repricing** lemma next to the OSL definition to make the boundary-tag idea part of the contract/resolver story.
- Rebuilt PDFs (`paper.pdf`, `paperA.pdf`, `paperB.pdf`) for consistency.
- Added: `paperB.tex` (systems/contract paper skeleton) to begin the planned split.

## v85.2 (2026-02-27)
- Paper: added a formal **attempt-selective coordinator adversary (ASC)** threat model hook near the introduction, linking abort/retry channels to Fiat--Shamir-with-aborts analysis.
- Added: `paperA.tex` (submission-length crypto draft extracting the core theorems: cancellation, conditioning tax, SRPA-G portability).
- Added: `RESEARCH_NOTES.md` (plan for splitting the living spec into Paper A / Paper B and tightening the most novel threads).
- Repo hygiene: removed nested snapshot subdirectories from the distribution working tree (they remain in prior archives).

## v85.1 (2026-02-27)
- Paper: added a **transparency-anchoring receipt** path for Grinding-Gap Certificates (GGCs), including a concrete RFC9162-style inclusion witness demo figure and a small table of **GGC evidence profiles**; cited the emerging IETF SCITT COSE receipts CCF profile as an interchange target.
- Demo artifacts: `test_vectors/grinding_gap_certificate_demo.json` now staples a `transparency{...}` block and includes a new `test_vectors/ggc_log_inclusion_witness_demo.json`.
- Tools: `grinding_gap_certificate_ref.py` generates and writes the demo inclusion witness; digest now excludes auxiliary evidence fields (e.g., `transparency`) to avoid circular self-reference.
- Tools: `verify_srpa_cache_ref.py` adds `--require-ggc-log` to fail-close unless the GGC's inclusion receipt verifies and binds to the digest string.

## v85.0 (2026-02-27)
- Paper: strengthened SRPA-G’s Grinding-Gap Certificates with explicit **cache-context binding** language and a laundering-prevention lemma (Lemma~\ref{lem:ggc-binding}); cited RATS/EAT as practical binding/attestation channels.
- Demo artifacts: upgraded `test_vectors/grinding_gap_certificate_demo.json` to include `binds` fields and a deterministic Ed25519 signature.
- Tools: `verify_srpa_cache_ref.py` now checks GGC binding and signature validity; `portable_acceptance_ref.py` treats binding as a cacheability precondition.

## v84.9 (2026-02-27)
- Paper: upgraded portable acceptance reuse to **SRPA-G** by stapling Grinding-Gap Certificates into PAOs; main theorem and SRPA end-to-end theorem now explicitly scale $\varepsilon_{\mathrm{resolved}}$ by $m_{\max}$ and include $\varepsilon_{\mathrm{gap}}$.
- Added: `_insert_ggc_policy_effect_table.tex` (generated by `ggc_policy_effect_ref.py`) to make policy-setting over $m_{\max}$ concrete.
- Tools: `verify_srpa_cache_ref.py` now optionally requires and consumes a GGC (`--require-ggc`), reporting the implied bit loss; `portable_acceptance_ref.py` now staples a demo GGC; `grinding_gap_certificate_ref.py` now emits `docf-grinding-gap-cert-v0`.

## v84.8 (2026-02-27)
- Paper: added **Grinding-Gap Certificates (GGCs)** (Definition~\ref{def:ggc}) and a formal **Grinding Gap Lemma** (Lemma~\ref{lem:grinding-gap}) connecting silent retry amplification to a $\log_2 m$ soundness overstatement.
- Added: `grinding_gap_certificate_ref.py` + generated artifacts `_insert_grinding_gap_certificate_demo.tex` and `test_vectors/grinding_gap_certificate_demo.json`.
- Market framing: added citations to ${\mathrm{Proo}}\varphi$ (auction-based ZKP market mechanism) and an empirical express-lane auction analogue (Arbitrum Timeboost) to motivate enforceability/observability requirements.

## v84.7 (2026-02-27)
- Paper: added a compact **synthetic micro-retry sweep** (Table~\ref{tab:synthetic-grinding-gap}) showing the exact bit-level overstatement from unreceipted internal retries ($\log_2 m$ bits), making the ``silent amplification'' risk operationally measurable.
- Added: `synthetic_grinding_gap_ref.py` + generated artifacts `_insert_synthetic_grinding_gap_table.tex` and `test_vectors/synthetic_grinding_gap_demo.json`.
- Related work: connected dOCF's manifest+ABI obligations to **Split Prover zkSNARKs** (ePrint 2025/373) as a complementary phase-splitting regime.

## v84.4 (2026-02-27)
- Paper: added a sharper **Contributions** paragraph and introduced SRPA definition + end-to-end theorem framing for split-view robust cache hits.
- Added: `_insert_market_presampling_budget_table.tex` + `market_presampling_budget_ref.py` (toy stress test for micro-retries under strict proving deadlines).

## v84.5 (2026-02-27)
- Fixed: demo-vector **policy digest consistency** across accept token, PABOM cache key, and PAO (policy normal-form digest is now the single source of truth).
- Added: `verify_srpa_cache_ref.py` (executable SRPA cache-hit verifier) and regenerated PAO/witness bundle demos.
- LaTeX hygiene: fixed broken proof environment and repaired bibliography formatting issues.

## v84.6 (2026-02-27)
- Paper: promoted SRPA cache-hit reuse to a headline **Main Theorem** (Theorem~\ref{thm:main-srpa}).
- Added: `_insert_srpa_cache_savings_table.tex` quantifying cache-hit verifier overhead and demonstrating practical audit savings.
- Research refresh: added Datatracker history references for SCITT Architecture and SCRAPI to support maturity/status statements (RFC Editor + review assignments).

## v84.3 (2026-02-27)
- Paper: added a **quorum-intersection sufficiency lemma** for witnessed checkpoints (Lemma~\ref{lem:witness-quorum-intersection}) plus a cache-safety corollary, making WGSO/PAO cacheability criteria *both necessary and sufficient* under explicit witness compromise bounds.
- Added: `_insert_witness_quorum_intersection_table.tex` with operational thresholds.

## v84.2 (2026-02-27)
- Paper: added Proposition~\ref{prop:witnessed-necessary} clarifying that receipt-only transparency is insufficient for **portable cache hits** under split-view; fail-closed downgrade to monitor-only.
- Refreshed: realtime proving datapoint + bibliography (Brevis Pico Prism benchmark post).

## v84.1 (2026-02-27)
- Verified/updated: several high-salience external anchors (Ethereum realtime proving; Boundless proof lifecycle; CISA SBOM 2025; Rekor v2 GA; SCITT drafts).
- Paper: added a theorem-shaped portability/caching monotonicity proposition.

## v84.0 (2026-02-26)
- Gate decisions (split-view robust): added **Witnessed Gate Satisfaction Objects (WGSO)**, binding admission decisions to a quorum-cosigned witnessed checkpoint bundle for non-equivocation. Includes schema, reference generator, and demo vectors + SCITT wrapper.
- Threat semantics tightened: updated threat catalog + conformance harness so cacheable acceptance claims require `transparency.witnessed_checkpoint` evidence (T11), aligning fail-closed reuse with anti-equivocation.
- PAO demo upgraded: portable acceptance demo now staples witnessed checkpoint bundle digest/ref, so its cacheability claim is consistent with the conformance semantics.

## v83.0 (2026-02-26)
- Gate semantics: added **Gate Normal Form (GNF)** for TPV gate policies, enabling cross-organization semantic pinning via a decidable normal-form digest.
- Gate decisions: added **Gate Satisfaction Objects (GSO)** and a minimal SCITT-style statement wrapper to make admission/procurement decisions transparency-loggable and monitorable.
- Paper: integrated new GNF/GSO tables + listings and expanded the posture sizing insert to include gate artifacts.

## v82.0 (2026-02-26)
- TPV gates: added a compact gate-policy object and fail-closed evaluator (`tpv_gate_ref.py`) plus demo policies and outputs; paper now includes a minimum-elements table and demo listings.
- TPV diffs: added a small diff object (`tpv_diff_ref.py`) for watchtower monitoring of posture upgrades/regressions.

## v81.0 (2026-02-26)
- TPV layer: added a compact, signable disclosure object (`docf_threat_posture_vector_v0.schema.json`) plus a conservative conformance→posture generator and demo vectors; paper includes TPV minimum-elements + sizing inserts.

## v80.1 (2026-02-26)
- LaTeX hygiene: fixed the threat-table generators to emit proper row terminators (`\\`), regenerated `_insert_threat_{catalog,conformance}_table.tex`.
- Removed a duplicate inclusion of the PABOM minimum-elements table to avoid duplicate labels.
- Removed a duplicate SnarkPack bibliography entry that caused duplicate hyperref destinations.

## v80.0 (2026-02-26)
- Implemented the **threat-to-obligation catalog** and **threat conformance harness** described in the paper: `threat_catalog.json`, `threat_conformance_ref.py`, and `make_scitt_statement_threat_conformance_ref.py`.
- Added deterministic LaTeX generators `make_threat_catalog_table.py` and `make_threat_conformance_table.py` and regenerated `_insert_threat_{catalog,conformance}_table.tex` from the JSON catalog.
- Paper: added a new PAO reuse/verification subsection, including pseudocode, a monotonicity lemma, and demo PAO publication/receipt listings.

## v79.0 (2026-02-26)
- Added a new **Portable Acceptance Object (PAO)** layer: an acceptance-side companion to PABOM that packages a dACP accept token together with the PABOM cache key, policy/resolver identifiers, and an anchor checkpoint/marker.
- Added `portable_acceptance_ref.py` and demo vectors (`test_vectors/portable_acceptance_{object,scitt_statement,receipt}_demo.json`) plus a PAO minimum-elements table (`_insert_pao_min_elements_table.tex`).

## v78.0 (2026-02-26)
- Added a **PABOM portability contract** table and a short verifier algorithm that turns publication tiers into concrete safe downstream uses (portable monitoring indices vs acceptance cache keys) under fail-closed evaluation.
- Added `pabom_portability_ref.py` and demo vectors (`test_vectors/pabom_{statement,receipt,cachekey}_demo.json`) to make cache-key construction reproducible.

## v77.0 (2026-02-26)
- Added a PABOM publication-tiers ladder (T0--T3) and Table~\ref{tab:pabom-publication-tiers} to make explicit when PABOM digests are safe cache keys / monitoring indices (unsigned vs signed vs transparency-anchored vs witnessed/consensus-anchored).
- New insert file: `_insert_pabom_publication_tiers_table.tex`.

## v76.0 (2026-02-26)
- Added a ``Proof Attestation BOM (PABOM) minimum elements'' interoperability checklist (Table~\ref{tab:pabom-min-elements}) and wired it into the prover supply-chain section.
- New insert file: `_insert_pabom_min_elements_table.tex`.
- Notes + bibliography: spot-checked that referenced supply-chain standards and transparency artifacts remain citable (Rekor v2 GA; IETF SCITT architecture/SCRAPI) and that realtime-proving motivation references are current.

## v75.0 (2026-02-26)
- Hard real-time repricing: added an explicit union-bound repricing paragraph and a concrete table (Table~\ref{tab:realtime-repricing}) showing how volume $N$ and retry/option budgets $Q_{\mathrm{eff}}$ translate window-level targets into per-attempt security requirements.
- New insert file: `_insert_realtime_repricing_table.tex`.
- LaTeX fix: repaired a broken line terminator in `_insert_schema_catalog_optional.tex` (PCC row).

## v74.0 (2026-02-26)
- Provenance Commitment Certificate (PCC): new schema+tool+demo; paper integrates PCC to pin compiled artifact digests (circuit/VK/program) to a source commit + build recipe and optional in-toto/SLSA attestation refs, upgrading the provenance axis $P$ and making build identity monitorable.
- Optional schema catalog: now includes `docf-provenance-commitment-cert-v0`.

## v73.0 (2026-02-26)
- Statement Commitment Certificate (SCC): new schema+tool+demo; paper integrates SCC to price/remove *statement-selection* option surfaces (fallback circuits, program versions, arithmetization swaps) that can otherwise make Fiat–Shamir boundaries adaptive.
- Option repricing report: new schema+tool+demo; deterministic union-bound calculator translating a window-level soundness budget plus $(N,Q,T_{\mathrm{tot}},b_{\mathrm{att}})$ into per-trial bit requirements.
- Schema catalog: optional table now explicitly lists OSL, SCC, and option repricing report.
- Bibliography hygiene: added accessible reference pages for FS attacks and FSwA mechanization/slides; removed a duplicate FSwA entry key.

## v72.0 (2026-02-26)
- Option Surface Ledger (OSL): new schema+tool+demo; paper integrates OSL as the cacheable bridge between receipt completeness (MCR) and abort/conditioning repricing (AOC/caps), yielding a single conservative attempt multiplier and bias-bit budget for the resolver.
- Added citations on Fiat–Shamir with aborts (CRYPTO'23) and practical Fiat–Shamir attacks (ePrint 2025/118) to ground the abort-loop threat surface.

## v71.0 (2026-02-26)
- Abort-option / conditioning-tax upgrade: new AOC schema+tool+demo; paper adds Proposition (free abort breaks soundness), Lemma (min-entropy loss), and an option-surface table.

## v70.0 (2026-02-26)
- Free-option lens + ePBS free-option citation; executable repricing/param-synthesis/bond-schedule tools and new demos.

# Evolving document archive index

This folder is a self-contained snapshot for paper compilation and editing.

## Contents
- `paper.tex` — main LaTeX source (v83.0 header).
- `references.tex` — bibliography (bibitems).
- `/_insert_*.tex` — generated tables/insert snippets referenced by `paper.tex`.
- `docf_*.schema.json` — key JSON schemas (envelope / eps-ledger / manifest / market request), when present.
- `NOTES.md` — working notes.
- `CHANGELOG.md` — human-readable deltas.

## Added in v65.0
- Abstract refresh + strengthened related-work section grounding dOCF in production prover markets and zkSaaS.
- Added ZkCloud operational proving reports to bibliography as an ecosystem datapoint motivating high-throughput proving pipelines.
- Expanded Conclusion with incremental adoption guidance and limitations/open problems.

## Added in v64.0
- Exact series--parallel seed-lock frontier DP (`docf_seed_lock_frontier_report/v0`, `seed_lock_optimizer_sp_ref.py`).
- SSC embedding as an in-toto Statement predicate (`security_claim_in_toto_ref.py`).

## Added in v61.0
- Added `end2end_resolve_with_trace_ref.py`: composes attempt-trace extraction with Theorem~\ref{thm:end2end} to produce an auditor-computable security-bits report from a witnessed retry trace.
- Added JSON Schemas `docf_attempt_trace_v0.schema.json` and `docf_attempt_trace_extract_report_v0.schema.json`.
- Added a burn-fraction refinement to the economic retry cap and instantiated it in the Boundless case study.

## Added in v60.0
- Replaced the stub `attempt_trace_extractor_ref.py` with a working reference extractor that compiles stack-disciplined traces into conservative attempt expressions and evaluates $Q_g$
- Added new demo vectors: `test_vectors/attempt_trace_demo.json` and `test_vectors/attempt_trace_extract_demo.json` (integrated as non-floating listings).
- Added Proposition~\ref{prop:seed-locking-monotone} and supporting text introducing **seed-locking** via a declared `resample_cut`.
- Fixed the manifest figure float scope (figure previously encompassed subsequent paragraphs) and added `\extrafloats{200}` + `placeins` for large-appendix float stability.

## Versioning policy
- Each snapshot is immutable and is zipped as `docf_evolving_docs_vXX_X.zip`.
- New turns produce a new snapshot folder + zip with incremented version.


## Added in v58.0
- Added `end2end_resolve_ref.py`: a tiny resolver reference implementation for Theorem~\ref{thm:end2end} that reports a bit decomposition and searches for minimal repetition count $t$ meeting a target security level.
- Added `test_vectors/end2end_resolve_demo.json` and integrated it into the paper as Figure~\ref{fig:end2end-resolve-demo}.
- Added Table~\ref{tab:end2end-repetition-128} (`_insert_end2end_repetition_design_table.tex`) translating retry+bias overhead into required repetition counts for a 128-bit target.



## Added in v57.0
- Added Theorem~\ref{thm:end2end}, a one-line end-to-end soundness bound that composes cancellation, coin quality, repetitions, retry budgets, and common-mode risk.
- Added a new motivation paragraph tying zkEVM security targets + 	exttt{soundcalc} workflows to sharding/cancellation, plus Table~\ref{tab:cancellation-bits} quantifying cancellation bits vs shard count and weight family.
- Added compact Evaluation and Related Work sections; tightened Boundless market grounding to cite lockCollateral/maxPrice and burn/bounty behavior directly from docs.

## Added in v56.0
- Supply-chain portability upgrade in Section~\ref{sec:prover-supply-chain}: dOCF evidence can be wrapped as in-toto/DSSE attestations, summarized via SLSA VSA, and logged in tile-backed transparency services (e.g., Rekor v2).
- Bibliography additions: SLSA v1.1 blog, SLSA VSA spec, and in-toto attestation releases.

## Added in v55.0
- Reader’s map box near the top of the paper (navigation aid linking the core technical and governance sections).
- Union-bound “volume tax” table connecting governance-window throughput (\(N\)) to required per-proof security bits (\(+\lceil\log_2 N\rceil\)).
- Paper version/date bump to v55.0 (2026-02-25).

## Added in v54.0
- Soundness SLOs (`docf-soundness-slo-v0`): operational error-budget records converting a window budget into a per-bundle \(\eps\) cap.
- Risk quotes (`docf-risk-quote-v0`): optional staplable pricing/bond artifacts derived from \(\eps\) bounds under a declared premium principle.
- Paper integration: new SRE-style soundness error budget discussion + demo figures; bibliography additions.

## Added in v53.0
- Soundness budget artifact (`docf-soundness-budget-v0`): schema + demo + reference tool for common-mode + per-attempt retry amplification bounds.
- Paper integration: Lemma on common-mode vs per-attempt amplification + demo listing.

## Added in v52.0
- Log consistency witnesses (`docf-log-consistency-witness-v0`): RFC~9162 consistency proof stapled between two STH checkpoints (append-only evidence, witness cosigning input).
- Log equivocation witnesses (`docf-log-equivocation-witness-v0`): portable split-view dispute artifacts (two conflicting signed checkpoints at the same tree size).
- Paper integration: new figures + consistency-proof sizing table; optional schema catalog and bibliography updates (CompactLog, Tesseract).

## Added in v51.0
- Portable log inclusion witnesses (`docf-log-inclusion-witness-v0`): staplable RFC~9162 Merkle inclusion paths for attempt leaves.
- Cross-logged checkpoint staples (`docf-cross-log-staple-v0`): bind a primary checkpoint into a secondary log and staple the second inclusion witness.
- Paper integration: inclusion/cross-log figures + inclusion-path sizing insert.


## Added in v50.0
- Witnessed checkpoint bundles: schema + deterministic Ed25519 demo vector and a small verifier tool.
- Paper text now includes the witnessed-checkpoint bundle as an offline-verifiable way to upgrade transparency evidence.

## Added in v49.0
- Totalized Policy Normal Form (PNF): explicit top defaults for every `docf-policy-v0` knob to prevent omission-based policy laundering in dominance/join.
- New contract negotiation transcript schema + demo (`docf-contract-negotiation-v0`) and reference tool (`contract_negotiate_ref.py`).
- Updated dominance/join reference tools and paper text to match the totalized semantics.

## Added in v47.0
- Policy dominance / implication checking for PNF policies (cross-contract accept-token reuse).
- PNF-join negotiation artifact for shared contract ids.
- New schemas: `docf-policy-implication-witness-v0`, `docf-policy-join-report-v0`, `docf-accept-reuse-bundle-v0`.
- New reference tool: `policy_pnf_order_ref.py`.

## Added in v46.0
- Policy Normal Form (PNF) definition + demo test vector.
- Accept token schema + demo test vector for cross-vendor acceptance caching.
- Reference scripts: `policy_normalize_ref.py`, `accept_token_ref.py`.

## Added in v45.0
- Fail-closed policy calculus + interoperability key table.
- Policy-proof schemas + deterministic DSSE vectors.
- Reference-tool stubs (`*_ref.py`) referenced by the paper.

## Added in v42.0
- New SAC section + schema + demo test vector.
- New dOCF assurance levels table.

## Added in v41.0
- Compliance vector table + demo test vector.

## Added in v40.0
- Example JSON artifacts referenced by listings in `paper.tex` (market/session receipts, manifests, ledgers, test vectors) are included to keep the snapshot compilable.

## Added in v43.0
- Attempt DAG Commitments (ADC) schema + demos.

## Added in v44.0
- Policy-as-code artifacts (policy schema, Rego example, compiled checks demo).
- Receipt embedding demo for stapling manifest digests into existing Merkle receipts.
- Tile-backed transparency-log discussion and citations.


## v62.0 additions
- `docf_attempt_trace_v1.schema.json` — attempt-trace schema extension for structured concurrency (fork/join + per-task tid).
- New structured-concurrency attempt-trace demo vectors under `test_vectors/`.

## v86.22 (AI-assisted)
**New/updated papers**
- `paperJ.tex` / `paperJ.pdf`: synthesis draft now includes an explicit *retry amplification* section with a beacon-waiting lemma and a concrete Option Surface Ledger (OSL) example table.
- `paperK.tex` / `paperK.pdf`: new focused draft on “No Free Options” (retry accounting as security derivatives).

**New inserts / scripts**
- `_insert_osl_tax_table.tex`: paper-ready OSL demo table.
- `make_osl_tax_table.py`: deterministic generator for the OSL table from the demo JSON test vector.

**Fixes**
- Escaped underscores in `_insert_split_view_topology_table.tex` and `_insert_split_view_client_refusal_table.tex` to repair `paperF` compilation.
- Deduplicated `Dahlberg2018CTGossip` reference; updated SCITT architecture draft citation to `-22`.

## v86.42 (AI-assisted)
- **Dense-tree clustering lemma**: Paper D now includes an exact, closed-form sibling-hash count for contiguous compact multiproofs in complete Merkle trees (popcount boundary formula), motivating lexicographic path clustering as a governance knob.
- **Cost-model inserts refreshed**: `_insert_merkle_capsule_sizes.tex` and `merkle_capsule_sizes.pdf` regenerated with both random-index and contiguous-index dense multiproof regimes.
- **Bond pricing modes**: `docf_capsule_open_bond_policy_v0` + `capsule_open_bond_policy_ref.py` now support `work_model` modes, including contig-based upper/expected work approximations.
- **Replayable rate limiting**: new ticket schema + reference tool for per-epoch rate-limit tickets; challenge transcripts optionally include ticket digest + use index, enabling offline replay uniqueness checks.

## v86.43 (AI-assisted)
- **Paper D**: new subsection on cross-market multi-homing, integrating the existing CMBI + hidden-bits artifacts and introducing GGBCs as a portable mitigation.
- **GGBC tooling**: upgraded `global_grinding_budget_cert_demo.json` to include Ed25519 signature material; added `verify_global_grinding_budget_cert_ref.py` and a SCITT-style wrapper emitter `make_scitt_statement_global_grinding_budget_cert_ref.py` (with demo statement vector).
- **Paper J**: new subsection on enforceable correlation clusters using Merkle-sealed capsules + dispute microprotocol.

## v86.44 (AI-assisted)
- **Paper D**: added a heterogeneity-aware multi-homing repricing lemma (additive hazards) and a new table+figure showing that hidden bits can far exceed $\log_2 M$ when venues differ in base error.
- **New generator**: `make_multihoming_microstructure.py` producing `_insert_multihoming_heterogeneity_table.tex` and `pct_multihoming_heterogeneity_hidden_bits.pdf`.
