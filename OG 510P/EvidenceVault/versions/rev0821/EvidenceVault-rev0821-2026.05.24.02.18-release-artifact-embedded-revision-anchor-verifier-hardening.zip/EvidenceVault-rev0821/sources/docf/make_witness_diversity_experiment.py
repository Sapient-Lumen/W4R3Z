#!/usr/bin/env python3
"""
make_witness_diversity_experiment.py

Toy but replayable experiment: witness diversity as a security parameter under
*correlated compromise*.

Motivation:
  Many witness/cosigning deployments assume independent witness compromise.
  In practice, witness nodes are often operated by a small number of orgs or
  share correlated infrastructure/jurisdiction. This makes "pick any m witnesses"
  brittle: correlated compromise can make a t-of-m policy far weaker than the
  independent model suggests.

This script models:
  - Operator-level compromise: each operator is compromised with probability q_op.
    If compromised, all its witnesses are compromised.
  - Residual independent compromise: conditional on operator honest, witness i is
    compromised with probability p_i.

We estimate two risks for a chosen witness set S:
  (1) p_compromised_quorum(t): attacker compromises >= t witnesses in S.
  (2) p_dual_accept(t): under a split-view attack with a hard partition of witnesses
      into two groups, attacker obtains t cosignatures for *both* views.
      Honest witnesses sign the first view they see; compromised witnesses sign both.

We compare three selection policies:
  - random: uniform random subsets of size m
  - diverse: greedy to maximize operator diversity, then lowest p_i
  - risk_greedy: greedy minimization of p_dual_accept(t_majority) under the compromise model

Outputs:
  - test_vectors/pct_witness_diversity_results.json
  - _insert_witness_diversity_risk_table.tex
  - pct_witness_diversity_risk_bars.pdf
"""
from __future__ import annotations

import json, math
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
TV = ROOT / "test_vectors"

def _load_pool() -> Dict:
    return json.loads((TV / "witness_candidate_pool_demo.json").read_text(encoding="utf-8"))

def _simulate_compromise(pool: Dict, subset: List[Dict], rng: np.random.Generator) -> np.ndarray:
    """Return boolean compromised array for subset."""
    op_q = {o["id"]: float(o["compromise_prob"]) for o in pool["operators"]}
    # draw operator compromises
    op_comp = {op: (rng.random() < q) for op, q in op_q.items()}
    comp = np.zeros(len(subset), dtype=bool)
    for i, w in enumerate(subset):
        if op_comp[w["operator"]]:
            comp[i] = True
        else:
            comp[i] = rng.random() < float(w["independent_compromise_prob"])
    return comp

def estimate_risks(pool: Dict, subset: List[Dict], t: int, trials: int, seed: int) -> Dict[str, float]:
    rng = np.random.default_rng(seed)
    m = len(subset)
    compromised_quorum = 0
    dual_accept = 0

    for _ in range(trials):
        comp = _simulate_compromise(pool, subset, rng)
        c = int(comp.sum())
        if c >= t:
            compromised_quorum += 1

        # random hard partition into two groups (attacker can route/population-split)
        perm = rng.permutation(m)
        gA = m // 2
        A = set(int(x) for x in perm[:gA])
        # signer counts (see analysis in paper): view A gets all in groupA plus compromised in groupB.
        cB = int(sum(comp[i] for i in range(m) if i not in A))
        cA = int(sum(comp[i] for i in range(m) if i in A))
        sA = gA + cB
        sB = (m - gA) + cA
        if sA >= t and sB >= t:
            dual_accept += 1

    return {
        "p_compromised_quorum": compromised_quorum / trials,
        "p_dual_accept": dual_accept / trials,
    }

def policy_random(pool: Dict, m: int, draws: int, seed: int) -> List[List[Dict]]:
    rng = np.random.default_rng(seed)
    W = pool["witnesses"]
    res = []
    for _ in range(draws):
        idx = rng.choice(len(W), size=m, replace=False)
        res.append([W[int(i)] for i in idx])
    return res

def policy_diverse(pool: Dict, m: int, seed: int) -> List[Dict]:
    rng = np.random.default_rng(seed)
    W = pool["witnesses"].copy()
    rng.shuffle(W)
    chosen = []
    used_ops = set()
    # first pass: unique operators
    for w in W:
        if w["operator"] not in used_ops:
            chosen.append(w)
            used_ops.add(w["operator"])
        if len(chosen) == m:
            return chosen
    # fill remainder: lowest independent p
    remain = [w for w in pool["witnesses"] if w not in chosen]
    remain.sort(key=lambda x: float(x["independent_compromise_prob"]))
    while len(chosen) < m:
        chosen.append(remain.pop(0))
    return chosen

def policy_risk_greedy(pool: Dict, m: int, t: int, seed: int) -> List[Dict]:
    rng = np.random.default_rng(seed)
    W = pool["witnesses"].copy()
    rng.shuffle(W)
    chosen: List[Dict] = []
    # Greedy add: pick witness that minimizes estimated p_dual_accept for the growing set.
    # Use a small Monte Carlo for speed; this is illustrative (not a solver).
    for step in range(m):
        best = None
        best_score = float("inf")
        for w in W:
            if w in chosen:
                continue
            cand = chosen + [w]
            # use fewer trials early; more later
            trials = 2000 if step < 3 else 5000
            est = estimate_risks(pool, cand, t=min(t, len(cand)), trials=trials, seed=seed + 31 * (step + 1) + hash(w["id"]) % 1000)
            score = est["p_dual_accept"] + 0.25 * est["p_compromised_quorum"]
            if score < best_score:
                best_score = score
                best = w
        chosen.append(best)
    return chosen

def subset_summary(subset: List[Dict]) -> Dict:
    ops = sorted({w["operator"] for w in subset})
    return {"witness_ids": [w["id"] for w in subset], "operators": ops}

def main() -> None:
    pool = _load_pool()
    m = 7
    t_majority = m // 2 + 1
    t_twothirds = math.floor(2 * m / 3) + 1  # conservative
    trials = 20000

    # selections
    rand_sets = policy_random(pool, m=m, draws=200, seed=20260228)
    diverse_set = policy_diverse(pool, m=m, seed=20260228)
    risk_set = policy_risk_greedy(pool, m=m, t=t_majority, seed=20260228)

    # aggregate random baseline
    rand_stats = []
    for j, S in enumerate(rand_sets):
        rM = estimate_risks(pool, S, t=t_majority, trials=3000, seed=20260228 + j)
        rand_stats.append(rM)
    rand_pq = float(np.mean([x["p_compromised_quorum"] for x in rand_stats]))
    rand_pd = float(np.mean([x["p_dual_accept"] for x in rand_stats]))

    # full eval for representative sets
    diverse_M = estimate_risks(pool, diverse_set, t=t_majority, trials=trials, seed=20260228 + 999)
    diverse_T = estimate_risks(pool, diverse_set, t=t_twothirds, trials=trials, seed=20260228 + 1999)
    risk_M = estimate_risks(pool, risk_set, t=t_majority, trials=trials, seed=20260228 + 2999)
    risk_T = estimate_risks(pool, risk_set, t=t_twothirds, trials=trials, seed=20260228 + 3999)

    out = {
        "note": "Witness diversity vs correlated compromise (toy).",
        "params": {
            "m": m,
            "t_majority": t_majority,
            "t_twothirds": t_twothirds,
            "trials": trials,
            "operator_compromise": {o["id"]: o["compromise_prob"] for o in pool["operators"]},
            "witness_independent_compromise_range": [
                min(w["independent_compromise_prob"] for w in pool["witnesses"]),
                max(w["independent_compromise_prob"] for w in pool["witnesses"]),
            ],
        },
        "policies": {
            "random_avg": {
                "p_compromised_quorum_majority": rand_pq,
                "p_dual_accept_majority": rand_pd,
                "n_draws": len(rand_sets),
            },
            "diverse_greedy": {
                **subset_summary(diverse_set),
                "majority": diverse_M,
                "two_thirds": diverse_T,
            },
            "risk_greedy": {
                **subset_summary(risk_set),
                "majority": risk_M,
                "two_thirds": risk_T,
            },
        },
    }

    (TV / "pct_witness_diversity_results.json").write_text(json.dumps(out, indent=2), encoding="utf-8")

    # LaTeX table

    def pct(x: float) -> str:
        return f"{100.0*x:0.2f}\\%"


    tex = []
    tex.append(r"\begin{table}[t]")
    tex.append(r"\centering")
    tex.append(r"\caption{Witness diversity under correlated compromise (toy). Operator-level compromise events make naive witness selection brittle. A stronger quorum ($t=5$ for $m=7$) plus risk-aware selection substantially reduces the probability that two inconsistent views can both obtain witness acceptance.}")
    tex.append(r"\label{tab:witness_diversity_risk}")
    tex.append(r"\begin{tabular}{lcccc}")
    tex.append(r"\toprule")
    tex.append(r"Policy & Ops & $p[\ge t_\mathrm{maj}\ \mathrm{comp}]$ & $p[\mathrm{dual}\ t_\mathrm{maj}]$ & $p[\mathrm{dual}\ t_{2/3}]$ \\")
    tex.append(r"\midrule")
    tex.append(rf"Random (avg) & -- & {pct(out['policies']['random_avg']['p_compromised_quorum_majority'])} & {pct(out['policies']['random_avg']['p_dual_accept_majority'])} & -- \\")
    tex.append(rf"Diverse greedy & {len(out['policies']['diverse_greedy']['operators'])} & {pct(diverse_M['p_compromised_quorum'])} & {pct(diverse_M['p_dual_accept'])} & {pct(diverse_T['p_dual_accept'])} \\")
    tex.append(rf"Risk greedy & {len(out['policies']['risk_greedy']['operators'])} & {pct(risk_M['p_compromised_quorum'])} & {pct(risk_M['p_dual_accept'])} & {pct(risk_T['p_dual_accept'])} \\")
    tex.append(r"\bottomrule")
    tex.append(r"\end{tabular}")
    tex.append(r"\end{table}")
    (ROOT / "_insert_witness_diversity_risk_table.tex").write_text("\n".join(tex) + "\n", encoding="utf-8")

    # Simple bar plot for the paper appendix / quick visuals
    labels = ["Random(avg)", "Diverse", "Risk"]
    dual = [out["policies"]["random_avg"]["p_dual_accept_majority"], diverse_M["p_dual_accept"], risk_M["p_dual_accept"]]
    comp = [out["policies"]["random_avg"]["p_compromised_quorum_majority"], diverse_M["p_compromised_quorum"], risk_M["p_compromised_quorum"]]

    x = np.arange(len(labels))
    width = 0.38
    fig, ax = plt.subplots(figsize=(6.4, 3.2))
    ax.bar(x - width/2, comp, width, label="p(compromised quorum)")
    ax.bar(x + width/2, dual, width, label="p(dual accept)")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=0)
    ax.set_ylim(0, max(comp + dual) * 1.25 + 1e-6)
    ax.legend(frameon=False)
    ax.set_ylabel("Probability (toy model)")
    fig.tight_layout()
    fig.savefig(ROOT / "pct_witness_diversity_risk_bars.pdf")
    plt.close(fig)

if __name__ == "__main__":
    main()
