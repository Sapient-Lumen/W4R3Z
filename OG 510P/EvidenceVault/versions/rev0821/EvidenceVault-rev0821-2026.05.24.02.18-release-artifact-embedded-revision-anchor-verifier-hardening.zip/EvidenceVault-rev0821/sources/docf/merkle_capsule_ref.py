#!/usr/bin/env python3
"""
dOCF Merkle Capsule reference tool (dense list variant).

This tool is intentionally small and dependency-free so that auditors can replay
capsule commitments and openings offline.

Hashing profile (RFC 6962 style):
  leaf_hash  = SHA256(0x00 || leaf_bytes)
  node_hash  = SHA256(0x01 || left || right)

Leaf encoding (path_nul_json_v0):
  leaf_bytes = UTF8(path) || b"\x00" || canonical_json(value)

Canonical JSON (docf_canonical_json_v0):
  json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

This is NOT a full RFC 8785 JCS implementation (numbers, escaping details).
If a deployment wants JCS, it should swap canonicalization and pin the digest.

Commands:
  build    --in leaves.json    --out capsule.json
  open       --capsule capsule.json --path /core/prover_binary_sha256
  open-multi --capsule capsule.json --paths /p1,/p2,/p3
  verify-multi --root <hex> --leaf-count N --multiproof multiproof.json
  verify   --root <hex> --leaf-count N --path <p> --value-json <json> --leaf-index i --audit-path <hex,...>

Input leaves.json format:
  [{"path": "/core/prover_binary_sha256", "value": "abcd..."}, ...]
"""

import argparse
import hashlib
import json
import sys
from typing import Any, Dict, List, Tuple


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()


def leaf_hash(path: str, value: Any) -> bytes:
    leaf_bytes = path.encode("utf-8") + b"\x00" + canonical_json(value).encode("utf-8")
    return sha256(b"\x00" + leaf_bytes)


def node_hash(left: bytes, right: bytes) -> bytes:
    return sha256(b"\x01" + left + right)


def build_tree(leaf_hashes: List[bytes]) -> Tuple[bytes, List[List[bytes]]]:
    """Returns (root, levels). Pads leaf list to power-of-two by duplicating last leaf."""
    if not leaf_hashes:
        raise ValueError("Need at least one leaf")
    n = 1
    while n < len(leaf_hashes):
        n *= 2
    padded = list(leaf_hashes)
    while len(padded) < n:
        padded.append(padded[-1])
    levels = [padded]
    cur = padded
    while len(cur) > 1:
        nxt = []
        for i in range(0, len(cur), 2):
            nxt.append(node_hash(cur[i], cur[i + 1]))
        levels.append(nxt)
        cur = nxt
    return levels[-1][0], levels


def audit_path(levels: List[List[bytes]], leaf_index: int) -> List[bytes]:
    path = []
    idx = leaf_index
    for level in range(len(levels) - 1):
        sib = idx ^ 1
        path.append(levels[level][sib])
        idx //= 2
    return path


def verify_audit_path(root: bytes, path: str, value: Any, leaf_index: int, ap: List[bytes], leaf_count: int) -> bool:
    # pad leaf_count to power of two (matches build_tree)
    n = 1
    while n < leaf_count:
        n *= 2
    if leaf_index < 0 or leaf_index >= n:
        return False
    h = leaf_hash(path, value)
    idx = leaf_index
    for sib_hash in ap:
        if idx % 2 == 0:
            h = node_hash(h, sib_hash)
        else:
            h = node_hash(sib_hash, h)
        idx //= 2
    return h == root



def multiproof_sibling_hashes(levels: List[List[bytes]], leaf_indices: List[int]) -> List[bytes]:
    """Compute a canonical sibling-hash list for a set of leaves in a complete binary tree.

    Tree profile assumptions (matches build_tree):
      - leaves padded to power-of-two by duplicating the last leaf
      - levels[0] contains the padded leaves, levels[h] contains the root

    Canonical ordering:
      For each level ℓ from 0..h-1, process node indices in increasing order.
      For each node i in the current frontier, if sibling (i^1) is *not* in the frontier,
      append levels[ℓ][i^1] to the proof list. Then promote i//2 to the next frontier.

    This encoding is 'compact' for complete trees: the verifier needs only the leaf indices
    (carried by openings) plus this sibling list (no extra position metadata).
    """
    cur = sorted(set(int(i) for i in leaf_indices))
    proof: List[bytes] = []
    for level in range(len(levels) - 1):
        cur_set = set(cur)
        processed: set[int] = set()
        nxt_set: set[int] = set()
        for idx in cur:
            if idx in processed:
                continue
            sib = idx ^ 1
            if sib not in cur_set:
                proof.append(levels[level][sib])
            else:
                processed.add(sib)
            processed.add(idx)
            nxt_set.add(idx // 2)
        cur = sorted(nxt_set)
    return proof


def verify_multiproof(root: bytes, openings: List[Tuple[str, Any, int]], sibling_hashes: List[bytes], leaf_count: int) -> bool:
    """Verify a compact multiproof against a committed root.

    Inputs:
      - openings: list of (path, value, leaf_index) for k revealed leaves
      - sibling_hashes: canonical list of sibling hashes (see multiproof_sibling_hashes)

    Returns True iff:
      - all leaf_index are distinct and within [0, leaf_count)
      - the canonical reconstruction consumes *exactly* sibling_hashes
      - reconstructed root equals 'root'
    """
    # pad leaf_count to power of two (matches build_tree)
    n = 1
    while n < leaf_count:
        n *= 2
    if leaf_count <= 0:
        return False

    cur: Dict[int, bytes] = {}
    for path, value, idx in openings:
        if idx < 0 or idx >= leaf_count:
            return False
        if idx in cur:
            return False
        cur[idx] = leaf_hash(str(path), value)

    proof_i = 0

    # height = log2(n)
    height = 0
    tmp = n
    while tmp > 1:
        height += 1
        tmp //= 2

    for _level in range(height):
        cur_indices = sorted(cur.keys())
        cur_set = set(cur_indices)
        processed: set[int] = set()
        nxt: Dict[int, bytes] = {}
        for idx in cur_indices:
            if idx in processed:
                continue
            sib = idx ^ 1
            h = cur[idx]
            if sib in cur_set:
                h_sib = cur[sib]
                processed.add(sib)
            else:
                if proof_i >= len(sibling_hashes):
                    return False
                h_sib = sibling_hashes[proof_i]
                proof_i += 1
            if idx % 2 == 0:
                parent = node_hash(h, h_sib)
            else:
                parent = node_hash(h_sib, h)
            parent_idx = idx // 2
            if parent_idx in nxt and nxt[parent_idx] != parent:
                return False
            nxt[parent_idx] = parent
            processed.add(idx)
        cur = nxt

    if len(cur) != 1 or 0 not in cur:
        return False
    if proof_i != len(sibling_hashes):
        return False
    return cur[0] == root


def hex_bytes(b: bytes) -> str:
    return b.hex()


def parse_hex_list(s: str) -> List[bytes]:
    if not s:
        return []
    parts = [p.strip() for p in s.split(",") if p.strip()]
    return [bytes.fromhex(p) for p in parts]


def cmd_build(args: argparse.Namespace) -> int:
    leaves = json.load(open(args.infile, "r", encoding="utf-8"))
    if not isinstance(leaves, list):
        raise ValueError("Input must be a list of {path,value} objects")
    leaves_sorted = sorted(leaves, key=lambda x: x["path"])
    leaf_hashes = [leaf_hash(e["path"], e.get("value")) for e in leaves_sorted]
    root, _levels = build_tree(leaf_hashes)
    capsule = {
        "type": "docf_merkle_capsule_v0",
        "format": "rfc6962_style_sha256_dense_v0",
        "canonicalization": "docf_canonical_json_v0",
        "leaf_encoding": "path_nul_json_v0",
        "leaf_order": "lex_path_v0",
        "root_sha256": hex_bytes(root),
        "leaf_count": len(leaves_sorted),
        "leaves": leaves_sorted,
    }
    json.dump(capsule, open(args.outfile, "w", encoding="utf-8"), indent=2, sort_keys=True, ensure_ascii=False)
    return 0


def cmd_open(args: argparse.Namespace) -> int:
    capsule = json.load(open(args.capsule, "r", encoding="utf-8"))
    leaves = capsule.get("leaves", [])
    if not leaves:
        raise ValueError("Capsule has no leaves; cannot open without local copy")
    leaves_sorted = sorted(leaves, key=lambda x: x["path"])
    leaf_hashes = [leaf_hash(e["path"], e.get("value")) for e in leaves_sorted]
    root, levels = build_tree(leaf_hashes)
    if hex_bytes(root) != capsule["root_sha256"]:
        raise ValueError("Capsule root mismatch; leaves/canonicalization changed")
    paths = [e["path"] for e in leaves_sorted]
    try:
        idx = paths.index(args.path)
    except ValueError:
        raise ValueError(f"Path not found: {args.path}")
    ap = audit_path(levels, idx)
    opening = {
        "path": leaves_sorted[idx]["path"],
        "value": leaves_sorted[idx].get("value"),
        "leaf_index": idx,
        "audit_path": [hex_bytes(x) for x in ap],
    }
    print(json.dumps(opening, indent=2, sort_keys=True, ensure_ascii=False))
    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    root = bytes.fromhex(args.root)
    value = json.loads(args.value_json)
    ap = parse_hex_list(args.audit_path)
    ok = verify_audit_path(root, args.path, value, args.leaf_index, ap, args.leaf_count)
    print(json.dumps({"ok": bool(ok)}, indent=2))
    return 0 if ok else 2



def cmd_open_multi(args: argparse.Namespace) -> int:
    capsule = json.load(open(args.capsule, "r", encoding="utf-8"))
    leaves = capsule.get("leaves", [])
    if not leaves:
        raise ValueError("Capsule has no leaves; cannot open without local copy")
    leaves_sorted = sorted(leaves, key=lambda x: x["path"])
    leaf_hashes = [leaf_hash(e["path"], e.get("value")) for e in leaves_sorted]
    root, levels = build_tree(leaf_hashes)
    if hex_bytes(root) != capsule["root_sha256"]:
        raise ValueError("Capsule root mismatch; leaves/canonicalization changed")

    paths = [p.strip() for p in str(args.paths).split(",") if p.strip()]
    if not paths:
        raise ValueError("Need at least one path")
    path_to_index = {e["path"]: i for i, e in enumerate(leaves_sorted)}

    indices: List[int] = []
    openings = []
    for pth in paths:
        if pth not in path_to_index:
            raise ValueError(f"Path not found: {pth}")
        idx = path_to_index[pth]
        indices.append(idx)
        openings.append({
            "path": leaves_sorted[idx]["path"],
            "value": leaves_sorted[idx].get("value"),
            "leaf_index": idx,
        })

    sibs = multiproof_sibling_hashes(levels, indices)
    mp = {
        "type": "docf_merkle_multiproof_v0",
        "profile": "rfc6962_style_sha256_dense_v0",
        "root_sha256": hex_bytes(root),
        "leaf_count": capsule.get("leaf_count", len(leaves_sorted)),
        "openings": openings,
        "sibling_hashes": [hex_bytes(x) for x in sibs],
    }
    print(json.dumps(mp, indent=2, sort_keys=True, ensure_ascii=False))
    return 0


def cmd_verify_multi(args: argparse.Namespace) -> int:
    mp = json.load(open(args.multiproof, "r", encoding="utf-8"))
    if not isinstance(mp, dict):
        raise ValueError("multiproof must be a JSON object")
    root_hex = args.root if args.root is not None else mp.get("root_sha256")
    if not root_hex:
        raise ValueError("Need --root or root_sha256 in multiproof")
    root = bytes.fromhex(str(root_hex))
    leaf_count = int(args.leaf_count if args.leaf_count is not None else mp.get("leaf_count", 0) or 0)
    openings = mp.get("openings", [])
    if not isinstance(openings, list):
        raise ValueError("multiproof.openings must be a list")
    sib_hex = mp.get("sibling_hashes", [])
    if not isinstance(sib_hex, list):
        raise ValueError("multiproof.sibling_hashes must be a list")
    sibs = [bytes.fromhex(str(h)) for h in sib_hex]

    tuples: List[Tuple[str, Any, int]] = []
    for o in openings:
        if not isinstance(o, dict):
            raise ValueError("opening must be an object")
        tuples.append((str(o.get("path")), o.get("value"), int(o.get("leaf_index"))))
    ok = verify_multiproof(root, tuples, sibs, leaf_count)
    print(json.dumps({"ok": bool(ok)}, indent=2))
    return 0 if ok else 2


def main() -> int:
    p = argparse.ArgumentParser()
    sp = p.add_subparsers(dest="cmd", required=True)

    b = sp.add_parser("build")
    b.add_argument("--in", dest="infile", required=True)
    b.add_argument("--out", dest="outfile", required=True)

    o = sp.add_parser("open")
    o.add_argument("--capsule", required=True)
    o.add_argument("--path", required=True)

    om = sp.add_parser("open-multi")
    om.add_argument("--capsule", required=True)
    om.add_argument("--paths", required=True, help="comma-separated paths")

    v = sp.add_parser("verify")
    v.add_argument("--root", required=True)
    v.add_argument("--leaf-count", dest="leaf_count", type=int, required=True)

    vm = sp.add_parser("verify-multi")
    vm.add_argument("--multiproof", required=True)
    vm.add_argument("--root", required=False)
    vm.add_argument("--leaf-count", dest="leaf_count", type=int, required=False)
    v.add_argument("--path", required=True)
    v.add_argument("--value-json", dest="value_json", required=True)
    v.add_argument("--leaf-index", dest="leaf_index", type=int, required=True)
    v.add_argument("--audit-path", dest="audit_path", required=True, help="comma-separated hex hashes")

    args = p.parse_args()
    if args.cmd == "build":
        return cmd_build(args)
    if args.cmd == "open":
        return cmd_open(args)
    if args.cmd == "verify":
        return cmd_verify(args)
    if args.cmd == "open-multi":
        return cmd_open_multi(args)
    if args.cmd == "verify-multi":
        return cmd_verify_multi(args)
    raise AssertionError("unreachable")


if __name__ == "__main__":
    sys.exit(main())
