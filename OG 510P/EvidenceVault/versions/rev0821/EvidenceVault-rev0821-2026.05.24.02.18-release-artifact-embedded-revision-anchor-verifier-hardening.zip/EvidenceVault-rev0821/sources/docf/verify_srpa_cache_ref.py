#!/usr/bin/env python3
"""verify_srpa_cache_ref.py

Reference verifier for SRPA cache hits, with optional grinding-robustness checks (SRPA-G), including transparency-anchored GGC receipts.

Given a Portable Acceptance Object (PAO), this tool checks (fail-closed):
  1) PAO internal consistency (policy_nf_digest, cache key material, anchors)
  2) PABOM receipt binds the PABOM statement digest to the anchor checkpoint
  3) Witnessed checkpoint bundle verifies and binds to the same (log_id, root)
  4) Witness quorum intersection condition: 2k > |W| + f
  5) (Optional) Grinding-Gap Certificate (GGC) present+valid (SRPA-G)

If (1)-(4) hold, the PAO may be treated as `cacheable` for *identity/non-equivocation*.
If `--require-ggc` is set, (5) must also hold for the tool to return `cacheable`
(i.e., for a cache hit to be valid for soundness claims under SRPA-G).

Usage:
  python3 verify_srpa_cache_ref.py --verify-demo [--require-ggc] [--require-ggc-log]
  python3 verify_srpa_cache_ref.py --verify <pao_json> [--f 0] [--require-ggc] [--require-ggc-log]

This file is reference-grade for paper examples; it is not hardened.
"""

from __future__ import annotations

import argparse
import base64
import binascii
import hashlib
import json
import os
import sys
import math
from typing import Any, Dict, Optional

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

from docf_ref_tools_common import jcs, load_json
from witnessed_checkpoint_bundle_ref import verify_bundle
from log_inclusion_witness_ref import verify_witness, ct_leaf_hash



def sha256_pref(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def verify_ed25519(pub_raw: bytes, sig: bytes, msg: bytes) -> bool:
    try:
        pub = Ed25519PublicKey.from_public_bytes(pub_raw)
        pub.verify(sig, msg)
        return True
    except (InvalidSignature, Exception):
        return False


def _read(path: str) -> Any:
    return load_json(path)


def _as_path(pao_path: str, ref: str) -> str:
    # Resolve refs. In the archive, demo refs are typically repo-root-relative (e.g. 'test_vectors/...').
    if os.path.isabs(ref):
        return ref
    pao_abs = os.path.abspath(pao_path)
    pao_dir = os.path.dirname(pao_abs)
    repo_root = os.path.dirname(pao_dir)
    if ref.startswith("test_vectors/"):
        return os.path.join(repo_root, ref)
    return os.path.join(pao_dir, ref)


def recompute_pabom_cache_key(statement_digest: str, policy_nf_digest: str, resolver_id: str, anchor: str) -> str:
    key_material = ("pabom-cache-v0|" + statement_digest + "|" + policy_nf_digest + "|" + resolver_id + "|" + anchor).encode("utf-8")
    return sha256_pref(key_material)


def _find_receipt_ref(receipts: Any, kind: str) -> Optional[str]:
    if not isinstance(receipts, list):
        return None
    for r in receipts:
        if isinstance(r, dict) and r.get("kind") == kind:
            ref = r.get("ref")
            if isinstance(ref, str) and ref:
                return ref
    return None


def verify_srpa(pao: Dict[str, Any], pao_path: str, f: int = 0, require_ggc: bool = False, require_ggc_log: bool = False) -> Dict[str, Any]:
    report: Dict[str, Any] = {"ok": False, "class": "monitorable", "checks": []}

    # --- Core fields
    policy_nf = pao.get("policy_nf_digest", "")
    resolver_id = pao.get("resolver_id", "")
    pabom_cache_key = pao.get("pabom_cache_key", "")
    subj = pao.get("subject") or {}
    pabom_stmt_digest = subj.get("pabom_statement_digest", "")
    anchor_obj = pao.get("anchor") or {}
    anchor_log_id = anchor_obj.get("log_id", "")
    anchor_root = anchor_obj.get("checkpoint_root", "")

    # Basic presence
    for (nm, val) in [
        ("policy_nf_digest", policy_nf),
        ("resolver_id", resolver_id),
        ("pabom_cache_key", pabom_cache_key),
        ("pabom_statement_digest", pabom_stmt_digest),
        ("anchor_log_id", anchor_log_id),
        ("anchor_root", anchor_root),
    ]:
        report["checks"].append({"check": f"present:{nm}", "ok": bool(val)})

    if not (policy_nf and resolver_id and pabom_cache_key and pabom_stmt_digest and anchor_log_id and anchor_root):
        report["class"] = "index_only"
        report["reason"] = "missing_core_fields"
        return report

    # --- Policy digest match to embedded accept_token (if present)
    accept_token = pao.get("accept_token") or {}
    token_policy_nf = accept_token.get("policy_nf_digest", "")
    report["checks"].append({
        "check": "policy_nf_matches_accept_token",
        "ok": (token_policy_nf == policy_nf),
        "expected": token_policy_nf,
        "got": policy_nf
    })
    if token_policy_nf and token_policy_nf != policy_nf:
        report["reason"] = "policy_nf_mismatch"
        return report

    # --- Recompute cache key
    recomputed = recompute_pabom_cache_key(pabom_stmt_digest, policy_nf, resolver_id, anchor_root)
    report["checks"].append({"check": "cache_key_recompute", "ok": (recomputed == pabom_cache_key), "expected": recomputed, "got": pabom_cache_key})
    if recomputed != pabom_cache_key:
        report["reason"] = "cache_key_mismatch"
        return report

    # --- Verify PABOM receipt binding
    receipts = pao.get("receipts") or []
    pabom_receipt_ref = _find_receipt_ref(receipts, "pabom_receipt")
    if not pabom_receipt_ref:
        report["reason"] = "missing_pabom_receipt_ref"
        return report

    receipt = _read(_as_path(pao_path, pabom_receipt_ref))
    leaf = receipt.get("leaf") or {}
    report["checks"].append({"check": "receipt_binds_statement_digest", "ok": (leaf.get("statement_sha256") == pabom_stmt_digest)})
    report["checks"].append({"check": "receipt_log_id_matches_anchor", "ok": (receipt.get("log_id") == anchor_log_id)})
    report["checks"].append({"check": "receipt_root_matches_anchor", "ok": (receipt.get("checkpoint_root") == anchor_root)})
    if leaf.get("statement_sha256") != pabom_stmt_digest or receipt.get("log_id") != anchor_log_id or receipt.get("checkpoint_root") != anchor_root:
        report["reason"] = "receipt_binding_failed"
        return report

    # --- Verify witnessed checkpoint bundle (log signature + witness threshold)
    wcb_ref = pao.get("witnessed_checkpoint_bundle_ref", "")
    if not wcb_ref:
        report["reason"] = "missing_wcb_ref"
        return report
    bundle = _read(_as_path(pao_path, wcb_ref))
    vb = verify_bundle(bundle)
    ok_bundle = bool(vb.get("ok")) if ("ok" in vb) else bool(vb.get("ok_log_signature")) and bool(vb.get("ok_threshold"))
    report["checks"].append({"check": "wcb_verify_bundle", "ok": ok_bundle, "details": vb})
    if not ok_bundle:
        report["reason"] = "wcb_invalid"
        return report

    # Bind wcb root to anchor_root
    b64_root = ((bundle.get("checkpoint") or {}).get("root_hash_sha256_b64")) or ""
    try:
        root_bytes = base64.b64decode(b64_root)
        root_hex = binascii.hexlify(root_bytes).decode("utf-8")
        wcb_root_pref = "sha256:" + root_hex
    except Exception:
        wcb_root_pref = ""
    wcb_log_id = ((bundle.get("log") or {}).get("log_id")) or ""
    report["checks"].append({"check": "wcb_log_id_matches_anchor", "ok": (wcb_log_id == anchor_log_id), "expected": anchor_log_id, "got": wcb_log_id})
    report["checks"].append({"check": "wcb_root_matches_anchor", "ok": (wcb_root_pref == anchor_root), "expected": anchor_root, "got": wcb_root_pref})
    if wcb_log_id != anchor_log_id or wcb_root_pref != anchor_root:
        report["reason"] = "wcb_anchor_mismatch"
        return report

    # Quorum intersection gate
    quorum = bundle.get("witness_quorum") or {}
    k = int(quorum.get("threshold") or 0)
    W = quorum.get("witnesses") or []
    n = len(W)
    qi_ok = (2 * k > n + int(f))
    report["checks"].append({"check": "quorum_intersection", "ok": qi_ok, "k": k, "n": n, "f": int(f)})
    if not qi_ok:
        report["reason"] = "quorum_intersection_failed"
        return report

    # --- Optional: Grinding-Gap Certificate (SRPA-G)
    ggc_ref = pao.get("grinding_gap_certificate_ref", "") or _find_receipt_ref(receipts, "grinding_gap_certificate")
    ggc_digest_claim = pao.get("grinding_gap_certificate_digest", "")
    if ggc_ref:
        ggc = _read(_as_path(pao_path, ggc_ref))
        # v85.0 digest convention: commit to the *unsigned* fields (excludes 'digest' and 'sig').
        ggc_digest = ggc.get("digest") or sha256_pref(jcs({k: v for (k, v) in ggc.items() if k not in ("digest", "sig", "transparency")}))
        ggc_digest_recomputed = sha256_pref(jcs({k: v for (k, v) in ggc.items() if k not in ("digest", "sig", "transparency")}))
        ok_digest = (not ggc_digest_claim) or (ggc_digest_claim == ggc_digest)
        ok_self = (ggc_digest == ggc_digest_recomputed)
        m_max = int(ggc.get("m_max") or 0)
        eps_gap = float(ggc.get("eps_gap") or 0.0)

        # Binding: prevent laundering a low-m_max GGC across unrelated cache contexts.
        binds = ggc.get("binds") or {}
        binds_ok = True
        if isinstance(binds, dict):
            for (k, expected) in [
                ("policy_nf_digest", policy_nf),
                ("resolver_id", resolver_id),
                ("pabom_statement_digest", pabom_stmt_digest),
                ("anchor_checkpoint_root", anchor_root),
                ("log_id", anchor_log_id),
            ]:
                v = binds.get(k, "")
                if v and v != expected:
                    binds_ok = False
        else:
            binds_ok = False

        # Optional signature over the digest (domain separated).
        issuer = ggc.get("issuer") or {}
        sig_b64 = ggc.get("sig") or ""
        sig_ok = None
        if isinstance(issuer, dict) and isinstance(sig_b64, str) and sig_b64:
            pk_b64 = issuer.get("public_key_ed25519_raw_b64") or ""
            try:
                pub_raw = base64.b64decode(pk_b64)
                sig = base64.b64decode(sig_b64)
                msg = b"DOCF-GGC-SIG-v0\x00" + str(ggc_digest).encode("utf-8")
                sig_ok = verify_ed25519(pub_raw, sig, msg)
            except Exception:
                sig_ok = False

        bits_lost = math.log2(m_max) if m_max > 0 else None

        # Optional transparency receipt: an inclusion witness over a leaf whose preimage contains the GGC digest string.
        tr = ggc.get("transparency") or {}
        tr_ok = None
        tr_details: Dict[str, Any] = {}
        if isinstance(tr, dict) and tr:
            pre_utf8 = tr.get("leaf_preimage_utf8") or ""
            wit_ref = tr.get("inclusion_witness_ref") or ""
            tr_log_id = tr.get("log_id") or ""
            if isinstance(pre_utf8, str) and isinstance(wit_ref, str) and pre_utf8 and wit_ref:
                try:
                    wit = _read(_as_path(pao_path, wit_ref))
                    ok_wit = verify_witness(wit)
                    # Bind: leaf hash and preimage digest must match the declared preimage.
                    leaf_hash = ct_leaf_hash(pre_utf8.encode("utf-8"))
                    ok_leaf_hash = (base64.b64decode(wit.get("leaf_hash_sha256_b64","")) == leaf_hash)
                    ok_pre_digest = (hashlib.sha256(pre_utf8.encode("utf-8")).hexdigest() == wit.get("leaf_preimage_digest_sha256_hex",""))
                    ok_contains = (str(ggc_digest) in pre_utf8)
                    ok_log = True
                    chk = (wit.get("checkpoint") or {})
                    if tr_log_id and isinstance(chk, dict):
                        ok_log = (chk.get("log_id","") == tr_log_id)
                    tr_ok = bool(ok_wit and ok_leaf_hash and ok_pre_digest and ok_contains and ok_log)
                    tr_details = {
                        "ok_witness": ok_wit,
                        "ok_leaf_hash": ok_leaf_hash,
                        "ok_preimage_digest": ok_pre_digest,
                        "ok_contains_ggc_digest": ok_contains,
                        "ok_log_id_match": ok_log,
                        "witness_ref": wit_ref,
                        "log_id": tr_log_id,
                    }
                except Exception as e:
                    tr_ok = False
                    tr_details = {"error": str(e), "witness_ref": wit_ref}
            else:
                tr_ok = False
                tr_details = {"error": "missing_leaf_preimage_or_witness_ref"}
        if tr_ok is not None:
            report["checks"].append({"check": "ggc_transparency_receipt_valid", "ok": bool(tr_ok), "details": tr_details})
        report["checks"].append({"check": "ggc_present", "ok": True, "ref": ggc_ref})
        report["checks"].append({"check": "ggc_digest_match", "ok": ok_digest, "expected": ggc_digest_claim, "got": ggc_digest})
        report["checks"].append({"check": "ggc_digest_self_consistent", "ok": ok_self, "expected": ggc_digest_recomputed, "got": ggc_digest})
        report["checks"].append({"check": "ggc_has_m_max", "ok": (m_max > 0), "m_max": m_max})
        report["checks"].append({"check": "ggc_eps_gap_range", "ok": (0.0 <= eps_gap <= 1.0), "eps_gap": eps_gap})
        report["checks"].append({"check": "ggc_binds_cache_context", "ok": binds_ok, "binds": binds})
        if sig_ok is not None:
            report["checks"].append({"check": "ggc_sig_valid", "ok": bool(sig_ok), "issuer": issuer})
        report["ggc"] = {"ref": ggc_ref, "digest": ggc_digest, "m_max": m_max, "eps_gap": eps_gap, "bits_lost_log2m": bits_lost}
        if (require_ggc and (not ok_digest or not ok_self or (not binds_ok) or m_max <= 0 or not (0.0 <= eps_gap <= 1.0) or (sig_ok is False))) or (require_ggc_log and (tr_ok is not True)):
            report["reason"] = "ggc_invalid"
            report["class"] = "monitorable"
            return report
    else:
        report["checks"].append({"check": "ggc_present", "ok": False})
        if require_ggc or require_ggc_log:
            report["reason"] = "missing_ggc"
            report["class"] = "monitorable"
            return report

    report["ok"] = True
    report["class"] = "cacheable"
    return report


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--verify-demo", action="store_true")
    ap.add_argument("--verify", type=str, default="")
    ap.add_argument("--f", type=int, default=0, help="Assumed max faulty witnesses for quorum-intersection check.")
    ap.add_argument("--require-ggc", action="store_true", help="require a valid Grinding-Gap Certificate for cacheability (SRPA-G).")
    ap.add_argument("--require-ggc-log", action="store_true", help="require a transparency inclusion receipt for the GGC digest")
    args = ap.parse_args()

    if args.verify_demo:
        pao_path = os.path.join("test_vectors", "portable_acceptance_object_demo.json")
    elif args.verify:
        pao_path = args.verify
    else:
        ap.print_help()
        return 0

    pao = _read(pao_path)
    report = verify_srpa(pao, pao_path, f=args.f, require_ggc=args.require_ggc, require_ggc_log=args.require_ggc_log)
    json.dump(report, sys.stdout, indent=2, sort_keys=True)
    sys.stdout.write("\n")
    return 0 if report.get("ok") else 2


if __name__ == "__main__":
    raise SystemExit(main())
