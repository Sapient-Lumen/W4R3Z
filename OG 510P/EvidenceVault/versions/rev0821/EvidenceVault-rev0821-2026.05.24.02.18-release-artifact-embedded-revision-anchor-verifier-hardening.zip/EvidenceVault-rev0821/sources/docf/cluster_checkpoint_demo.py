#!/usr/bin/env python3
"""cluster_checkpoint_demo.py — generate a tiny figure comparing checkpoint rules.

This is a *toy* illustration: cluster-aware composition can be less conservative
than a global union bound when clusters plausibly model shared failure modes.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import matplotlib.pyplot as plt


def run_rule(ledger_path: Path, rule: str) -> dict:
    here = Path(__file__).resolve().parent
    tool = here / "eps_ledger_ref.py"
    out = subprocess.check_output([sys.executable, str(tool), str(ledger_path), "--schema", str(here / "docf_eps_ledger_v0.schema.json"), "--rule", rule], text=True)
    return json.loads(out)


def main() -> None:
    here = Path(__file__).resolve().parent
    ledger = here / "examples" / "toy_epoch_ledger_clusters.json"
    rules = ["union", "independent", "independent_clusters"]
    outs = [run_rule(ledger, r) for r in rules]
    bits = [o["bits_total"] for o in outs]

    plt.figure(figsize=(5.5, 3.2))
    plt.bar(rules, bits)
    plt.ylabel("bits = -log2(eps_total)")
    plt.title("Toy checkpoint: union vs independence vs cluster-independence")
    plt.tight_layout()

    figdir = here / "figures"
    figdir.mkdir(exist_ok=True)
    outpath = figdir / "cluster_checkpoint_demo.pdf"
    plt.savefig(outpath)
    print(f"Wrote {outpath}")


if __name__ == "__main__":
    main()
