#!/usr/bin/env python3
"""make_quorum_threshold_optimization_experiment.py

Exact threshold optimization for witness quorum sizing.

Motivation (paper-ready):
  The earlier Pareto surface fixed a threshold policy t(m) = max(majority, ceil(0.7 m)).
  That is a reasonable deployment default, but it hides an important degree of freedom:
  for a fixed witness count m and split-view budget B_dual, the verifier can choose
  threshold t to trade liveness against dual-accept risk.

This script computes, for each budget k and each witness count m:
  - the cheapest feasible quorum under the fixed threshold policy, and
  - the cheapest feasible quorum when t is optimized over t in [majority, m].

A quorum is feasible if BOTH hold:
  (i)  rho_hat(S) <= rho_max(m,t,q,B_dual)   (WDD correlation policy)
  (ii) P[#available >= t] >= 1-delta        (liveness)

Where:
  - rho_hat is computed from witness tags via the conservative WDD proxy
      rho_hat = max_d rho_d (or domain-weighted aggregation, optional)
  - rho_max is the maximum exchangeable intraclass correlation rho such that
      P_dual_accept(m,t,q,rho) <= B_dual
    with a feasibility guard:
      if P_dual_accept(m,t,q,0) > B_dual, then no rho can satisfy the budget.

Outputs:
  - test_vectors/quorum_threshold_opt_results.json
  - _insert_quorum_threshold_opt_table.tex
  - pct_quorum_threshold_opt.pdf

Deterministic; no network access.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional


def _rho(labels: List[str]) -> float:
    m = len(labels)
    if m <= 1:
        return 0.0
    counts: Dict[str, int] = {}
    for x in labels:
        counts[x] = counts.get(x, 0) + 1
    num = sum(v * (v - 1) for v in counts.values())
    return num / (m * (m - 1))


def rho_by_domain(ws: List[Dict[str, Any]], domains: List[str]) -> Dict[str, float]:
    return {d: _rho([str(w.get(d) or w.get('id')) for w in ws]) for d in domains}


def rho_aggregate(by: Dict[str, float], agg: str, weights: Dict[str, float]) -> float:
    if not by:
        return 0.0
    if agg == 'max':
        return max(by.values())
    if agg == 'weighted':
        wsum = 0.0
        acc = 0.0
        for d, v in by.items():
            w = float(weights.get(d, 0.0))
            if w <= 0:
                continue
            wsum += w
            acc += w * v
        if wsum <= 0:
            return sum(by.values()) / len(by)
        return acc / wsum
    raise ValueError(f"unknown agg: {agg}")


def poisson_binom_dist(ps: List[float]) -> List[float]:
    m = len(ps)
    dp = [0.0] * (m + 1)
    dp[0] = 1.0
    for p in ps:
        nxt = [0.0] * (m + 1)
        for j in range(m + 1):
            if dp[j] == 0.0:
                continue
            nxt[j] += dp[j] * (1 - p)
            if j + 1 <= m:
                nxt[j + 1] += dp[j] * p
        dp = nxt
    return dp


def tail(dp: List[float], t: int) -> float:
    return float(sum(dp[t:]))


def log_beta(a: float, b: float) -> float:
    return math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)


def beta_binom_pmf(m: int, k: int, alpha: float, beta: float) -> float:
    return math.comb(m, k) * math.exp(log_beta(alpha + k, beta + m - k) - log_beta(alpha, beta))


def hypergeom_pmf(N: int, K: int, n: int, k: int) -> float:
    if k < 0 or k > n or k > K or (n - k) > (N - K):
        return 0.0
    return (math.comb(K, k) * math.comb(N - K, n - k)) / math.comb(N, n)


def dual_accept_prob_given_K(m: int, t: int, g: int, K: int) -> float:
    lo = max(0, t - (m - g))
    hi = min(g, K + g - t)
    if lo > hi:
        return 0.0
    return sum(hypergeom_pmf(m, K, g, kA) for kA in range(lo, hi + 1))


@lru_cache(maxsize=None)
def compute_dual_accept(m: int, t: int, q: float, rho: float) -> float:
    g = m // 2
    if rho <= 0.0:
        pD = 0.0
        for K in range(m + 1):
            pK = math.comb(m, K) * (q ** K) * ((1 - q) ** (m - K))
            pD += pK * dual_accept_prob_given_K(m, t, g, K)
        return pD

    s = (1.0 / rho) - 1.0
    alpha = max(1e-12, q * s)
    beta = max(1e-12, (1.0 - q) * s)
    pD = 0.0
    for K in range(m + 1):
        pK = beta_binom_pmf(m, K, alpha, beta)
        pD += pK * dual_accept_prob_given_K(m, t, g, K)
    return pD


@lru_cache(maxsize=None)
def max_rho_for_budget(m: int, t: int, q: float, budget_dual: float) -> Optional[float]:
    # Feasibility guard: if independence already violates budget, no rho works.
    if compute_dual_accept(m, t, q, 0.0) > budget_dual:
        return None
    lo, hi = 0.0, 0.999
    for _ in range(70):
        mid = (lo + hi) / 2
        if compute_dual_accept(m, t, q, mid) <= budget_dual:
            lo = mid
        else:
            hi = mid
    return lo


def parse_weights(s: str, domains: List[str]) -> Dict[str, float]:
    if not s.strip():
        return {d: 1.0 for d in domains}
    out: Dict[str, float] = {}
    for part in s.split(','):
        part = part.strip()
        if not part:
            continue
        if '=' not in part:
            raise ValueError(f"bad weight token: {part}")
        k, v = part.split('=', 1)
        out[k.strip()] = float(v.strip())
    for d in domains:
        out.setdefault(d, 0.0)
    return out


def majority(m: int) -> int:
    return (m // 2) + 1


def fixed_threshold(m: int, t_min_frac: float) -> int:
    return max(majority(m), int(math.ceil(t_min_frac * m)))


def enumerate_combos_sorted(pool: List[Dict[str, Any]], m: int, domains: List[str], agg: str, weights: Dict[str, float]):
    out = []
    for comb in itertools.combinations(pool, m):
        ws = list(comb)
        by = rho_by_domain(ws, domains)
        rh = rho_aggregate(by, agg=agg, weights=weights)
        ps = [float(w.get('uptime', 1.0)) for w in ws]
        dp = poisson_binom_dist(ps)
        cost = sum(float(w.get('monthly_cost_usd', 0.0)) for w in ws)
        out.append((cost, rh, by, dp, [w['id'] for w in ws]))
    out.sort(key=lambda x: x[0])
    return out


def cheapest_feasible_for_t(
    combos,
    t: int,
    rho_max: float,
    delta: float,
):
    target = 1.0 - delta
    for cost, rh, by, dp, ids in combos:
        if rh > rho_max + 1e-12:
            continue
        p_live = tail(dp, t)
        if p_live + 1e-15 < target:
            continue
        return {
            't': int(t),
            'monthly_cost_usd': float(f"{cost:.6g}"),
            'rho_hat': float(f"{rh:.6g}"),
            'rho_by_domain': {k: float(f"{v:.6g}") for k, v in by.items()},
            'p_live': float(f"{p_live:.6g}"),
            'selected_witness_ids': ids,
        }
    return None


def optimize_threshold_for_m(combos, m: int, q: float, delta: float, budget_dual: float):
    best = None
    for t in range(majority(m), m + 1):
        rm = max_rho_for_budget(m, t, q, budget_dual)
        if rm is None:
            continue
        cand = cheapest_feasible_for_t(combos, t, rm, delta)
        if cand is None:
            continue
        cand['rho_max'] = float(f"{rm:.6g}")
        if best is None or cand['monthly_cost_usd'] < best['monthly_cost_usd'] - 1e-9:
            best = cand
    return best


def fixed_threshold_solution_for_m(combos, m: int, q: float, delta: float, budget_dual: float, t_min_frac: float):
    t = fixed_threshold(m, t_min_frac)
    rm = max_rho_for_budget(m, t, q, budget_dual)
    if rm is None:
        return None
    cand = cheapest_feasible_for_t(combos, t, rm, delta)
    if cand is None:
        return None
    cand['rho_max'] = float(f"{rm:.6g}")
    return cand


def latex_table(rows: List[Dict[str, Any]]) -> str:
    # No leading double-backslashes.
    lines = []
    lines.append(r"\begin{tabular}{r r r r r r}")
    lines.append(r"\toprule")
    lines.append(r"$m$ & $t_{\mathrm{fixed}}$ & cost$_{\mathrm{fixed}}$ & $t^*$ & cost$^*$ & $\Delta$\\")
    lines.append(r"\midrule")
    for r in rows:
        m = r['m']
        tf = r.get('t_fixed')
        cf = r.get('cost_fixed')
        to = r.get('t_opt')
        co = r.get('cost_opt')
        d = r.get('delta')
        def fmt_cost(x):
            return f"{x:.0f}" if isinstance(x, (int, float)) else r"--"
        def fmt_int(x):
            return f"{x:d}" if isinstance(x, int) else r"--"
        def fmt_delta(x):
            if isinstance(x, (int, float)):
                if abs(x) < 1e-9:
                    return r"0\%"
                return f"{x:+.0f}\%"
            return r"--"
        lines.append(f"{m:d} & {fmt_int(tf)} & {fmt_cost(cf)} & {fmt_int(to)} & {fmt_cost(co)} & {fmt_delta(d)}\\\\")
    lines.append(r"\bottomrule")
    lines.append(r"\end{tabular}")
    return "\n".join(lines) + "\n"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--pool', default='test_vectors/witness_candidate_pool_demo_v2.json')
    ap.add_argument('--q', type=float, default=0.12)
    ap.add_argument('--delta', type=float, default=1e-3)
    ap.add_argument('--domains', default='operator,provider,impl_family,kms_class')
    ap.add_argument('--agg', choices=['max', 'weighted'], default='max')
    ap.add_argument('--weights', default='operator=0.6,provider=0.2,impl_family=0.1,kms_class=0.1')
    ap.add_argument('--budgets_bits', default='6')
    ap.add_argument('--m_min', type=int, default=5)
    ap.add_argument('--m_max', type=int, default=10)
    ap.add_argument('--t_min_frac', type=float, default=0.7)
    ap.add_argument('--out_json', default='test_vectors/quorum_threshold_opt_results.json')
    ap.add_argument('--out_tex', default='_insert_quorum_threshold_opt_table.tex')
    ap.add_argument('--out_fig', default='pct_quorum_threshold_opt.pdf')
    args = ap.parse_args()

    pool_path = Path(args.pool)
    obj = json.loads(pool_path.read_text())
    pool = obj['witnesses']
    domains = [d.strip() for d in args.domains.split(',') if d.strip()]
    weights = parse_weights(args.weights, domains)

    budgets_bits = [int(x.strip()) for x in args.budgets_bits.split(',') if x.strip()]
    results: Dict[str, Any] = {
        'type': 'docf_quorum_threshold_opt_results_v1',
        'params': {
            'q': args.q,
            'delta': args.delta,
            'domains': domains,
            'agg': args.agg,
            'weights': weights,
            't_min_frac_fixed': args.t_min_frac,
            'm_range': [args.m_min, args.m_max],
            'budgets_bits': budgets_bits,
        },
        'by_budget_bits': {},
    }

    # Precompute combos by m once.
    combos_by_m = {}
    for m in range(args.m_min, args.m_max + 1):
        combos_by_m[m] = enumerate_combos_sorted(pool, m, domains, agg=args.agg, weights=weights)

    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    # For figure: only plot first budget (keeps figure simple).
    fig_budget = budgets_bits[0] if budgets_bits else 6

    plot_m = []
    plot_cost_fixed = []
    plot_cost_opt = []

    table_rows: List[Dict[str, Any]] = []

    for k in budgets_bits:
        B = 2.0 ** (-k)
        out_rows = []
        for m in range(args.m_min, args.m_max + 1):
            combos = combos_by_m[m]
            sol_fixed = fixed_threshold_solution_for_m(combos, m, args.q, args.delta, B, args.t_min_frac)
            sol_opt = optimize_threshold_for_m(combos, m, args.q, args.delta, B)

            entry = {
                'm': m,
                'budget_bits': k,
                'budget_dual': B,
                'fixed': sol_fixed,
                'opt': sol_opt,
            }
            out_rows.append(entry)

            if k == fig_budget:
                plot_m.append(m)
                plot_cost_fixed.append(sol_fixed['monthly_cost_usd'] if sol_fixed else float('nan'))
                plot_cost_opt.append(sol_opt['monthly_cost_usd'] if sol_opt else float('nan'))

                row = {'m': m}
                if sol_fixed:
                    row['t_fixed'] = int(sol_fixed['t'])
                    row['cost_fixed'] = float(sol_fixed['monthly_cost_usd'])
                else:
                    row['t_fixed'] = None
                    row['cost_fixed'] = None
                if sol_opt:
                    row['t_opt'] = int(sol_opt['t'])
                    row['cost_opt'] = float(sol_opt['monthly_cost_usd'])
                else:
                    row['t_opt'] = None
                    row['cost_opt'] = None
                if sol_fixed and sol_opt and sol_fixed['monthly_cost_usd'] > 0:
                    row['delta'] = 100.0 * (sol_opt['monthly_cost_usd'] - sol_fixed['monthly_cost_usd']) / sol_fixed['monthly_cost_usd']
                else:
                    row['delta'] = None
                table_rows.append(row)

        results['by_budget_bits'][str(k)] = out_rows

    Path(args.out_json).write_text(json.dumps(results, indent=2, sort_keys=True))

    Path(args.out_tex).write_text(latex_table(table_rows))

    # Plot
    plt.figure()
    plt.plot(plot_m, plot_cost_fixed, marker='o', label='fixed t(m)')
    plt.plot(plot_m, plot_cost_opt, marker='o', label='optimized t')
    plt.xlabel('witness count m')
    plt.ylabel('monthly cost (USD)')
    plt.title(f'Threshold optimization at k={fig_budget}, q={args.q}, delta={args.delta}')
    plt.legend()
    plt.tight_layout()
    plt.savefig(args.out_fig)
    plt.close()


if __name__ == '__main__':
    main()
