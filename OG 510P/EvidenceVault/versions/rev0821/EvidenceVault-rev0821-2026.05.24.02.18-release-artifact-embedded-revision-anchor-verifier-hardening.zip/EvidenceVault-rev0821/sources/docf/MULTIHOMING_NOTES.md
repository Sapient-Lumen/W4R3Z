# Multi-homing exposure notes (v86.24)

Core phenomenon: even with local Attempt DAG disclosure, a prover can post the same statement across multiple markets and settle only where an improbable event occurs.
This is economically natural (multi-venue execution), but cryptographically it is *retry amplification*.

Artifacts added in v86.24:
- `make_multihoming_experiment.py` produces:
  - `_insert_multihoming_inflation_table.tex`
  - `pct_multihoming_hidden_bits.pdf`

Next-risk directions:
- Add a 2–3 market microstructure simulation where prices differ and the prover chooses venue conditional on realized outcomes.
- Model correlated attempts (shared beacon / shared transcript) to study when union bounds are loose and how OSL should record correlation tags.
- Explore an ecosystem-level policy: verifiers accept only if a statement digest has a CMBI exposure certificate covering the job's settlement window.

## v86.44-ai additions (2026-02-28)
- Implemented the next-risk direction: a **heterogeneous-venue microstructure demo** via `make_multihoming_microstructure.py`.
  - Generates `_insert_multihoming_heterogeneity_table.tex` and `pct_multihoming_heterogeneity_hidden_bits.pdf`.
  - Shows that the naive \(\log_2 M\) penalty can **underestimate** hidden exposure when the local venue is more secure than at least one other venue used.
- Added an **additive-hazard repricing lemma** (Paper D, Lemma `lem:additive_hazards_multihoming`):
  - Define hazard \(h(\varepsilon)=-\ln(1-\varepsilon)\). Under independence, hazards add across venues and attempts.
  - Hidden bits are governed by an **effective exposure factor** \(H/H_\ell\), not just venue count.

Next-risk directions:
- Extend the demo to a **sequential routing** model where the adversary chooses which venues to post to based on observed *auction clearing prices* and time-to-finality.
- Tie repricing to ecosystem evidence: given a CMBI window + a GGBC attempt cap, compute a conservative \(H\) bound under a venue-class taxonomy (deployment profile → eps0 range).
