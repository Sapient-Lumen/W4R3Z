#!/usr/bin/env python3
"""make_witness_policy_feasibility_experiment.py

Compare *coarse* vs *refined* witness diversity domains for feasibility and cost.

Key point: WDD is only as useful as the *risk-domain tags* it carries.
If the tags are too coarse (e.g., only region with 3 buckets), the induced
correlation lower bound \hat\rho can exceed any reasonable \rho_max, making
policies infeasible even for strong thresholds.

We compare two verifier policies:
  - COARSE: domains = (operator, region)
  - REFINED: domains = (operator, provider, impl_family, kms_class)

For each split-view risk budget B_dual = 2^{-k}, we compute \rho_max using the
exchangeable ICC model, then choose the minimum-cost witness set of size m that
satisfies:
  (1) \hat\rho(S) <= \rho_max
  (2) P[#available >= t] >= 1 - delta

Outputs:
  - test_vectors/witness_policy_feasibility_results.json
  - _insert_witness_policy_feasibility_table.tex
  - pct_witness_policy_feasibility_cost.pdf

"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path
from typing import Any, Dict, List, Tuple


def tex_escape(s: str) -> str:
    return s.replace('_', r'\\_')


def _rho(labels: List[str]) -> float:
    m = len(labels)
    if m <= 1:
        return 0.0
    counts: Dict[str, int] = {}
    for x in labels:
        counts[x] = counts.get(x, 0) + 1
    num = sum(v * (v - 1) for v in counts.values())
    return num / (m * (m - 1))


def rho_hat_for_set(ws: List[Dict[str, Any]], domains: List[str]) -> Tuple[float, Dict[str, float]]:
    by: Dict[str, float] = {}
    for d in domains:
        labels = [str(w.get(d) or w.get('id')) for w in ws]
        by[d] = _rho(labels)
    rh = max(by.values()) if by else 0.0
    return rh, by


def poisson_binom_tail(ps: List[float], t: int) -> float:
    m = len(ps)
    dp = [0.0] * (m + 1)
    dp[0] = 1.0
    for p in ps:
        nxt = [0.0] * (m + 1)
        for j in range(0, m + 1):
            if dp[j] == 0.0:
                continue
            nxt[j] += dp[j] * (1 - p)
            if j + 1 <= m:
                nxt[j + 1] += dp[j] * p
        dp = nxt
    return sum(dp[t:])


def log_beta(a: float, b: float) -> float:
    return math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)


def beta_binom_pmf(m: int, k: int, alpha: float, beta: float) -> float:
    return math.comb(m, k) * math.exp(log_beta(alpha + k, beta + m - k) - log_beta(alpha, beta))


def hypergeom_pmf(N: int, K: int, n: int, k: int) -> float:
    if k < 0 or k > n or k > K or (n - k) > (N - K):
        return 0.0
    return (math.comb(K, k) * math.comb(N - K, n - k)) / math.comb(N, n)


def dual_accept_prob_given_K(m: int, t: int, g: int, K: int) -> float:
    lo = max(0, t - (m - g))
    hi = min(g, K + g - t)
    if lo > hi:
        return 0.0
    return sum(hypergeom_pmf(m, K, g, kA) for kA in range(lo, hi + 1))


def compute_dual_accept(m: int, t: int, q: float, rho: float) -> float:
    g = m // 2

    if rho <= 0.0:
        pD = 0.0
        for K in range(0, m + 1):
            pK = math.comb(m, K) * (q**K) * ((1 - q) ** (m - K))
            pD += pK * dual_accept_prob_given_K(m, t, g, K)
        return pD

    s = (1.0 / rho) - 1.0
    alpha = max(1e-12, q * s)
    beta = max(1e-12, (1.0 - q) * s)

    pD = 0.0
    for K in range(0, m + 1):
        pK = beta_binom_pmf(m, K, alpha, beta)
        pD += pK * dual_accept_prob_given_K(m, t, g, K)
    return pD


def max_rho_for_budget(m: int, t: int, q: float, budget_dual: float) -> float | None:
    # If even rho=0 exceeds budget, no correlation level can satisfy this budget.
    if compute_dual_accept(m, t, q, 0.0) > budget_dual:
        return None

    lo, hi = 0.0, 0.999
    for _ in range(70):
        mid = (lo + hi) / 2
        pD = compute_dual_accept(m, t, q, mid)
        if pD <= budget_dual:
            lo = mid
        else:
            hi = mid
    return lo


def best_set_exact(pool: List[Dict[str, Any]], m: int, t: int, domains: List[str], rho_max: float, delta: float):
    best = None
    best_key = None
    for comb in itertools.combinations(pool, m):
        ws = list(comb)
        rh, by = rho_hat_for_set(ws, domains)
        if rh > rho_max + 1e-12:
            continue
        ps = [float(w.get('uptime', 1.0)) for w in ws]
        p_live = poisson_binom_tail(ps, t)
        if p_live < 1.0 - delta:
            continue
        cost = sum(float(w.get('monthly_cost_usd', 0.0)) for w in ws)
        key = (cost, -p_live, rh)
        if best_key is None or key < best_key:
            best_key = key
            best = {
                'selected_witness_ids': [w['id'] for w in ws],
                'rho_hat': float(f"{rh:.6g}"),
                'rho_by_domain': {k: float(f"{v:.6g}") for k, v in by.items()},
                'monthly_cost_usd': float(f"{cost:.6g}"),
                'p_live': float(f"{p_live:.6g}"),
            }
    return best


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--pool', default='test_vectors/witness_candidate_pool_demo_v2.json')
    ap.add_argument('--m', type=int, default=7)
    ap.add_argument('--t', type=int, default=6)
    ap.add_argument('--q', type=float, default=0.12)
    ap.add_argument('--delta', type=float, default=1e-3)
    ap.add_argument('--budgets_bits', default='6,8,10,12')
    ap.add_argument('--out_json', default='test_vectors/witness_policy_feasibility_results.json')
    ap.add_argument('--out_tex', default='_insert_witness_policy_feasibility_table.tex')
    ap.add_argument('--out_fig', default='pct_witness_policy_feasibility_cost.pdf')
    args = ap.parse_args()

    ks = [int(x.strip()) for x in args.budgets_bits.split(',') if x.strip()]
    pool_obj = json.loads(Path(args.pool).read_text(encoding='utf-8'))
    pool = pool_obj.get('witnesses', [])

    policies = [
        ('coarse', ['operator', 'region']),
        ('refined', ['operator', 'provider', 'impl_family', 'kms_class']),
    ]

    results = []
    for k in ks:
        B = 2.0 ** (-k)
        rho_max = max_rho_for_budget(args.m, args.t, args.q, B)
        for name, domains in policies:
            if rho_max is None:
                best = None
            else:
                best = best_set_exact(pool, args.m, args.t, domains, rho_max, args.delta)
            row = {
                'policy': name,
                'domains': domains,
                'k': k,
                'B_dual': B,
                'rho_max': (None if rho_max is None else float(f"{rho_max:.6g}")),
                'feasible': bool(best),
            }
            if best:
                row.update(best)
            results.append(row)

    out = {
        'type': 'docf_witness_policy_feasibility_results_v0',
        'params': {
            'pool': args.pool,
            'm': args.m,
            't': args.t,
            'q': args.q,
            'delta': args.delta,
        },
        'results': results,
    }
    Path(args.out_json).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out_json).write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding='utf-8')

    # LaTeX table (2 rows per k)
    tex = []
    tex.append('\\begin{tabular}{r l r r r l}')
    tex.append('\\toprule')
    tex.append('$k$ & policy & $\\rho_{\\max}$ & $\\hat\\rho$ & cost & status \\\\')
    tex.append('\\midrule')

    for k in ks:
        rows_k = [r for r in results if r['k'] == k]
        rows_k.sort(key=lambda r: r['policy'])
        for r in rows_k:
            pol = r['policy']
            rho_max = r.get('rho_max')
            if (not r['feasible']) or (rho_max is None):
                rho_max_str = '--' if rho_max is None else f"{rho_max:.4g}"
                tex.append(f"{k} & {pol} & {rho_max_str} & -- & -- & infeasible \\\\")
                continue
            tex.append(f"{k} & {pol} & {rho_max:.4g} & {r['rho_hat']:.4g} & {r['monthly_cost_usd']:.0f} & ok \\\\")
        tex.append('\\addlinespace[0.2em]')

    tex.append('\\bottomrule')
    tex.append('\\end{tabular}')
    Path(args.out_tex).write_text('\n'.join(tex) + '\n', encoding='utf-8')

    # figure: cost vs k for each policy
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt

        plt.figure()
        for pol, _dom in policies:
            xs = []
            ys = []
            for k in ks:
                r = next((x for x in results if x['k']==k and x['policy']==pol), None)
                if r and r.get('feasible') and r.get('rho_max') is not None:
                    xs.append(k)
                    ys.append(r['monthly_cost_usd'])
            if xs:
                plt.plot(xs, ys, marker='o', label=pol)
        plt.xlabel('Budget bits k (B_dual = 2^{-k})')
        plt.ylabel('Minimum monthly cost (USD)')
        plt.title('Feasibility and cost depend on domain granularity')
        plt.legend()
        plt.tight_layout()
        plt.savefig(args.out_fig)
        plt.close()
    except Exception as e:
        Path(args.out_fig).write_text('figure generation failed: ' + str(e), encoding='utf-8')


if __name__ == '__main__':
    main()
