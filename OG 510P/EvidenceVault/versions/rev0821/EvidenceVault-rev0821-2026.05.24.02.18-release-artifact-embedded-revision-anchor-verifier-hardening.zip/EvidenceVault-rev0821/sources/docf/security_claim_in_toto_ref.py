#!/usr/bin/env python3
"""security_claim_in_toto_ref.py

Wrap a docf Security Claim (SSC) as an in-toto Statement v1 predicate.

Motivation:
  - dOCF claims/attestations are useful as *portable cache keys* and as
    transparency-log payloads.
  - In-toto's Statement v1 provides a widely-consumed wrapper with a typed
    predicateType and a standard subject array.

This tool takes an SSC payload (docf_security_claim/v0) and emits:
  - an in-toto Statement v1 whose predicate is the SSC
  - predicateType = https://docf.dev/attestation/security-claim/v1

The output can be DSSE-signed and published to transparency services.

This is a small reference sketch for paper examples; production deployments
should use stable URIs under their own governance.
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Dict, List

from docf_ref_tools_common import jcs, sha256_hex


PREDICATE_TYPE = "https://docf.dev/attestation/security-claim/v1"


def _fail(msg: str) -> None:
    raise SystemExit(f"[security_claim_in_toto_ref] {msg}")


def _load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _jdump(obj: Any) -> str:
    return json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False) + "\n"


def build_statement(ssc: Dict[str, Any], subject_name: str = "docf-bundle") -> Dict[str, Any]:
    if ssc.get("schema") != "docf_security_claim/v0":
        _fail("expected docf_security_claim/v0 payload")

    # Subject should be the thing being attested. For demo purposes we bind to the
    # audit report digest if present; otherwise to the SSC digest itself.
    dig = None
    try:
        dig = ssc.get("subject", {}).get("bundle_digest_sha256")
    except Exception:
        dig = None
    if not isinstance(dig, str) or len(dig) < 16:
        dig = sha256_hex(jcs(ssc))

    subject: List[Dict[str, Any]] = [{"name": subject_name, "digest": {"sha256": dig}}]

    return {
        "_type": "https://in-toto.io/Statement/v1",
        "subject": subject,
        "predicateType": PREDICATE_TYPE,
        "predicate": ssc,
    }


def demo_statement() -> Dict[str, Any]:
    ssc = _load_json("test_vectors/security_claim_demo.json")
    return build_statement(ssc, subject_name="sid:demo:ssc:1")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit", action="store_true", help="emit deterministic demo Statement")
    ap.add_argument("--ssc", dest="ssc_path", default=None, help="input SSC JSON file")
    ap.add_argument("--out", dest="out_path", default=None, help="output JSON (default: stdout)")
    ap.add_argument("--subject-name", dest="subject_name", default="docf-bundle")
    args = ap.parse_args()

    if args.emit:
        st = demo_statement()
        sys.stdout.write(_jdump(st))
        return

    if not args.ssc_path:
        ap.print_help()
        return

    ssc = _load_json(args.ssc_path)
    if not isinstance(ssc, dict):
        _fail("ssc must be a JSON object")
    st = build_statement(ssc, subject_name=str(args.subject_name))
    s = _jdump(st)
    if args.out_path:
        open(args.out_path, "w", encoding="utf-8").write(s)
    else:
        sys.stdout.write(s)


if __name__ == "__main__":
    main()
