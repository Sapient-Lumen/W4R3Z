#!/usr/bin/env python3
"""capsule_open_rate_limit_ticket_ref.py

Reference helper for a replayable, offline-verifiable *rate limit* on capsule-open
challenges.

Idea: governance issues per-epoch "tickets" that grant a challenger up to
max_uses challenges. A challenge references the ticket by digest plus a use_index.
Uniqueness of (ticket_digest, use_index) can be verified by scanning the public
ledger / event log (offline replay).

This is intentionally minimal: signatures are treated as opaque strings in this
reference tool (deployments bind issuer_sig to their preferred signature scheme).

Commands:
  emit-demo
  digest --ticket path.json
  verify --ticket path.json
  next-use --ledger ledger.jsonl --ticket-digest <hex>
  check-ledger --ledger ledger.jsonl

Ledger format: JSON Lines; each line is a JSON object (e.g., capsule_open_challenge).
"""

from __future__ import annotations

import argparse
import hashlib
import json
from typing import Any, Dict, Iterable, Tuple


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest_sha256(obj: Any) -> str:
    return hashlib.sha256(canonical_json(obj).encode("utf-8")).hexdigest()


def load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_jsonl(path: str) -> Iterable[Dict[str, Any]]:
    with open(path, "r", encoding="utf-8") as f:
        for ln in f:
            ln = ln.strip()
            if not ln:
                continue
            yield json.loads(ln)


def ticket_digest(ticket: Dict[str, Any]) -> str:
    body = {k: v for k, v in ticket.items() if k not in ("digest_sha256",)}
    return digest_sha256(body)


def demo_ticket() -> Dict[str, Any]:
    t = {
        "type": "docf_capsule_open_rate_limit_ticket_v0",
        "ticket_id": "ticket:demo:2026-02-28:challengerA:0001",
        "epoch_id": "2026-02-28T00:00:00Z",
        "challenger_id": "challengerA",
        "max_uses": 3,
        "issuer_id": "governance-demo",
        "issued_at_utc": "2026-02-28T00:00:05Z",
        "expires_at_utc": "2026-02-28T01:00:00Z",
        "notes": "Demo only. issuer_sig is opaque in this reference tool.",
        "issuer_sig": "SIG_DEMO_000000",
    }
    t["digest_sha256"] = ticket_digest(t)
    return t


def next_use_index(ledger_path: str, ticket_digest_hex: str) -> int:
    mx = -1
    for obj in load_jsonl(ledger_path):
        if obj.get("type") != "capsule_open_challenge":
            continue
        if obj.get("rate_limit_ticket_digest_sha256") != ticket_digest_hex:
            continue
        ui = obj.get("rate_limit_use_index")
        if isinstance(ui, int) and ui > mx:
            mx = ui
    return mx + 1


def check_ledger_uniqueness(ledger_path: str) -> Tuple[bool, Dict[str, Any]]:
    seen = set()
    dup = []
    for i, obj in enumerate(load_jsonl(ledger_path)):
        if obj.get("type") != "capsule_open_challenge":
            continue
        td = obj.get("rate_limit_ticket_digest_sha256")
        ui = obj.get("rate_limit_use_index")
        if td is None or ui is None:
            continue
        key = (td, int(ui))
        if key in seen:
            dup.append({"line": i + 1, "ticket_digest": td, "use_index": int(ui)})
        seen.add(key)
    ok = len(dup) == 0
    return ok, {"duplicates": dup, "checked_pairs": len(seen)}


def main() -> None:
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)

    sp.add_parser("emit-demo")

    dg = sp.add_parser("digest")
    dg.add_argument("--ticket", required=True)

    vf = sp.add_parser("verify")
    vf.add_argument("--ticket", required=True)

    nu = sp.add_parser("next-use")
    nu.add_argument("--ledger", required=True)
    nu.add_argument("--ticket-digest", required=True)

    cl = sp.add_parser("check-ledger")
    cl.add_argument("--ledger", required=True)

    args = ap.parse_args()

    if args.cmd == "emit-demo":
        print(json.dumps(demo_ticket(), indent=2, sort_keys=True))
        return

    if args.cmd == "digest":
        t = load_json(args.ticket)
        print(ticket_digest(t))
        return

    if args.cmd == "verify":
        t = load_json(args.ticket)
        expected = ticket_digest(t)
        got = t.get("digest_sha256")
        out = {
            "ok": (got == expected) if isinstance(got, str) else False,
            "expected_digest_sha256": expected,
            "got_digest_sha256": got,
        }
        print(json.dumps(out, indent=2, sort_keys=True))
        return

    if args.cmd == "next-use":
        idx = next_use_index(args.ledger, args.ticket_digest)
        print(json.dumps({"next_use_index": idx}, indent=2, sort_keys=True))
        return

    if args.cmd == "check-ledger":
        ok, details = check_ledger_uniqueness(args.ledger)
        out = {"ok": ok, **details}
        print(json.dumps(out, indent=2, sort_keys=True))
        return


if __name__ == "__main__":
    main()
