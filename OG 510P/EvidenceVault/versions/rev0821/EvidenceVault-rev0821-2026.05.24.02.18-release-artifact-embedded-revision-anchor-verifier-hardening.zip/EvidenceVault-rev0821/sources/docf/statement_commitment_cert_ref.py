#!/usr/bin/env python3
"""statement_commitment_cert_ref.py

Reference tool: compile a Statement Commitment Certificate (SCC).

Motivation
----------
Fiat--Shamir (FS) security depends on what is fixed *before* challenges are derived.
In distributed proving and prover markets, an orchestrator can accidentally (or
maliciously) introduce *statement-selection options*:
  - fallback circuits / alternate arithmetizations
  - swapping program versions
  - "try another encoding" retries
  - adaptive circuit rewrites after seeing a beacon / partial transcript

SCC is a small, cacheable artifact that:
  - binds (sid, manifest_digest) to a canonical statement digest
  - carries anchoring evidence that the statement was committed pre-beacon / pre-FS
  - yields deterministic repricing outputs: T=1, bias_bits=0

Input JSON (minimal)
--------------------
{
  "sid": "session-id",
  "manifest_digest": "sha256:...",
  "statement": {
    "statement_kind": "zkvm_program+io",
    "statement_text": "program_hash=...; input_hash=..."
  },
  "commitment": {"kind": "onchain_receipt", "anchor_ref": "tx:0x...", "commit_before_beacon": true}
}

Output JSON
-----------
{
  "type": "statement_commitment_cert",
  "sid": ...,
  "statement": {"statement_digest": "sha256:...", ...},
  "derived": {"T": 1, "bias_bits": 0, ...},
  "digest": "sha256:..."
}

This tool does not verify the anchoring evidence; it only normalizes it.
Verification is a policy/resolver responsibility.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import math
import sys
from typing import Any, Dict


def _sha256_bytes(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _sha256_hex(obj: Dict[str, Any]) -> str:
    s = json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return _sha256_bytes(s)


def _ceil_log2(n: int) -> int:
    if n <= 1:
        return 0
    return int(math.ceil(math.log(n, 2)))


def _derive_statement_digest(stmt: Dict[str, Any]) -> str:
    # Preference order:
    #   1) explicit statement_digest
    #   2) statement_bytes_hex
    #   3) statement_bytes_b64
    #   4) statement_text (utf-8)
    if isinstance(stmt.get("statement_digest"), str) and stmt["statement_digest"].strip():
        return stmt["statement_digest"].strip()

    if isinstance(stmt.get("statement_bytes_hex"), str) and stmt["statement_bytes_hex"].strip():
        hx = stmt["statement_bytes_hex"].strip()
        if hx.startswith("0x"):
            hx = hx[2:]
        data = bytes.fromhex(hx)
        return _sha256_bytes(data)

    if isinstance(stmt.get("statement_bytes_b64"), str) and stmt["statement_bytes_b64"].strip():
        data = base64.b64decode(stmt["statement_bytes_b64"].strip())
        return _sha256_bytes(data)

    if isinstance(stmt.get("statement_text"), str) and stmt["statement_text"].strip():
        data = stmt["statement_text"].encode("utf-8")
        return _sha256_bytes(data)

    raise ValueError("statement must include one of: statement_digest, statement_bytes_hex, statement_bytes_b64, statement_text")


def compile_scc(inp: Dict[str, Any]) -> Dict[str, Any]:
    sid = inp.get("sid")
    manifest_digest = inp.get("manifest_digest")

    if not isinstance(sid, str) or not sid:
        raise ValueError("sid must be a non-empty string")
    if not isinstance(manifest_digest, str) or not manifest_digest:
        raise ValueError("manifest_digest must be a non-empty string")

    stmt = inp.get("statement") or {}
    if not isinstance(stmt, dict):
        raise TypeError("statement must be an object")

    if not isinstance(stmt.get("statement_kind"), str) or not stmt.get("statement_kind"):
        raise ValueError("statement.statement_kind must be a non-empty string")

    statement_digest = _derive_statement_digest(stmt)
    stmt_out = dict(stmt)
    # Drop raw bytes fields to keep SCC compact and cacheable.
    stmt_out.pop("statement_bytes_hex", None)
    stmt_out.pop("statement_bytes_b64", None)
    stmt_out.pop("statement_text", None)
    stmt_out["statement_digest"] = statement_digest

    commitment = inp.get("commitment") or {}
    if not isinstance(commitment, dict):
        raise TypeError("commitment must be an object")
    if not isinstance(commitment.get("kind"), str) or not commitment.get("kind"):
        raise ValueError("commitment.kind must be a non-empty string")

    # Deterministic repricing: statement fixed => no statement-selection option.
    T = 1
    bias_bits = _ceil_log2(T)

    out: Dict[str, Any] = {
        "type": "statement_commitment_cert",
        "sid": sid,
        "market_id": inp.get("market_id"),
        "manifest_digest": manifest_digest,
        "statement": stmt_out,
        "commitment": commitment,
        "derived": {
            "T": int(T),
            "bias_bits": int(bias_bits),
            "repricing_rule": "T=1 (fixed statement) => bias_bits=0",
        },
        "receipts": inp.get("receipts") or {},
        "notes": inp.get(
            "notes",
            "SCC binds a canonical statement digest to (sid, manifest_digest) with anchoring evidence; resolvers can treat missing SCC as a statement-selection option surface.",
        ),
        "meta": {"tool": "statement_commitment_cert_ref.py"},
    }

    out_no_digest = dict(out)
    out_no_digest.pop("digest", None)
    out["digest"] = _sha256_hex(out_no_digest)
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="infile", default=None, help="Input JSON file (default: stdin).")
    ap.add_argument("--out", dest="outfile", default=None, help="Output JSON file (default: stdout).")
    args = ap.parse_args()

    raw = sys.stdin.read() if args.infile is None else open(args.infile, "r", encoding="utf-8").read()
    obj = json.loads(raw) if raw.strip() else {}
    out = compile_scc(obj)

    s = json.dumps(out, indent=2, sort_keys=False) + "\n"
    if args.outfile is None:
        sys.stdout.write(s)
    else:
        with open(args.outfile, "w", encoding="utf-8") as f:
            f.write(s)


if __name__ == "__main__":
    main()
