#!/usr/bin/env python3
"""snl_slashing_proof_ref.py (v86.8)

Emit a compact *slashing/forensics proof* for transparency log equivocation.

A slashing proof is derived from two (or more) gossip bundles that contain
*validly signed* checkpoints for the same (log_id, tree_size) but with different
roots.

Usage:
  python3 snl_slashing_proof_ref.py --bundles a.json b.json --out proof.json
  python3 snl_slashing_proof_ref.py --emit-demo

Demo output:
  test_vectors/snl_slashing_proof_conflict_demo.json
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
from typing import Any, Dict, List, Tuple

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from docf_ref_tools_common import jcs, load_json, emit_json


def b64d(s: str) -> bytes:
    return base64.b64decode(s.encode("utf-8"))


def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_pref(b: bytes) -> str:
    return "sha256:" + sha256_hex(b)


def checkpoint_payload(checkpoint: Dict[str, Any]) -> bytes:
    msg_obj = {
        "format": checkpoint.get("format", ""),
        "log_id": checkpoint.get("log_id", ""),
        "tree_size": checkpoint.get("tree_size", 0),
        "root_hash_sha256_b64": checkpoint.get("root_hash_sha256_b64", ""),
        "issued_at": checkpoint.get("issued_at", ""),
    }
    return jcs(msg_obj)


def verify_checkpoint_signature(chk: Dict[str, Any]) -> bool:
    try:
        pk = b64d(str(chk.get("log_public_key_ed25519_raw_b64", "")) or "")
        sig = b64d(str(chk.get("log_signature_ed25519_b64", "")) or "")
        pub = Ed25519PublicKey.from_public_bytes(pk)
        pub.verify(sig, checkpoint_payload(chk))
        return True
    except Exception:
        return False


def extract(bundle: Dict[str, Any]) -> Tuple[str, int, Dict[str, Any], str, str]:
    """(log_id, tree_size, checkpoint, payload_sha_hex, observer_id)"""
    log_id = str(bundle.get("log_id", ""))
    oid = str((bundle.get("observer") or {}).get("observer_id", ""))
    obs = (bundle.get("observations") or [{}])[0] if (bundle.get("observations") or []) else {}
    chk = obs.get("checkpoint") or {}
    ts = int(chk.get("tree_size", 0) or 0)
    payload_sha = str(obs.get("checkpoint_payload_sha256_hex", "") or "")
    return log_id, ts, chk, payload_sha, oid


def build_slashing_proof(bundles: List[Dict[str, Any]]) -> Dict[str, Any]:
    if len(bundles) < 2:
        raise ValueError("need >=2 bundles")

    by_key: Dict[Tuple[str, int], List[Tuple[Dict[str, Any], str, str, str]]] = {}
    for b in bundles:
        log_id, ts, chk, payload_sha, oid = extract(b)
        root_b64 = str(chk.get("root_hash_sha256_b64", "") or "")
        by_key.setdefault((log_id, ts), []).append((chk, payload_sha, root_b64, oid))

    for (log_id, ts), items in by_key.items():
        roots: Dict[str, List[Tuple[Dict[str, Any], str, str]]] = {}
        for chk, payload_sha, root_b64, oid in items:
            roots.setdefault(root_b64, []).append((chk, payload_sha, oid))
        if len(roots) <= 1:
            continue

        conflicts: List[Dict[str, Any]] = []
        for root_b64, lst in roots.items():
            chk0 = lst[0][0]
            ok_sig = verify_checkpoint_signature(chk0)
            conflicts.append(
                {
                    "root_hash_sha256_b64": root_b64,
                    "checkpoint_payload_sha256_hex": lst[0][1],
                    "checkpoint": chk0,
                    "checkpoint_signature_valid": ok_sig,
                    "observers": [oid for (_, _, oid) in lst],
                }
            )

        proof = {
            "schema": "docf-snl-slashing-proof-v0",
            "version": "0",
            "created_at": "2026-02-27T00:01:20Z",
            "log_id": log_id,
            "tree_size": ts,
            "conflicts": conflicts,
            "bundles": [
                {
                    "observer_id": str((b.get("observer") or {}).get("observer_id", "")),
                    "bundle_digest": str(b.get("digest", "")),
                    "bundle": b,
                }
                for b in bundles
            ],
            "notes": [
                "This object is for research: it packages split-view evidence into a single portable artifact.",
                "If both conflicting checkpoints verify under the same log public key, this is strong equivocation evidence.",
            ],
        }
        proof["digest"] = sha256_pref(jcs(proof))
        return proof

    raise ValueError("no_conflict_found")


def emit_demo() -> None:
    tv = os.path.join(os.path.dirname(__file__), "test_vectors")
    a = load_json(os.path.join(tv, "snl_gossip_bundle_A_demo.json"))
    b = load_json(os.path.join(tv, "snl_gossip_bundle_B_conflict_demo.json"))
    proof = build_slashing_proof([a, b])

    out_path = os.path.join(tv, "snl_slashing_proof_conflict_demo.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(proof, f, indent=2, ensure_ascii=False)
        f.write("\n")
    emit_json(proof)
    print(f"Wrote {out_path}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--bundles", nargs="*", default=[])
    ap.add_argument("--out", type=str, default="")
    ap.add_argument("--emit-demo", action="store_true")
    args = ap.parse_args()

    if args.emit_demo:
        emit_demo()
        return

    if not args.bundles or not args.out:
        ap.print_help()
        return

    bundles = [load_json(p) for p in args.bundles]
    proof = build_slashing_proof(bundles)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(proof, f, indent=2, ensure_ascii=False)
        f.write("\n")


if __name__ == "__main__":
    main()
