#!/usr/bin/env python3
"""
market_presampling_budget_ref.py (reference)
-------------------------------------------

Toy stress test: how many "cheap resampling" trials can fit into the slack of a hard deadline
without materially hurting an on-time SLA target?

Model:
  - Deadline D seconds (e.g. 10s slot with ~10s proving budget).
  - One heavy proving attempt with runtime T ~ LogNormal(mean=mean_T, sigma=sigma_T).
  - Coordinator is allowed to spend at most slack = D - q_p seconds on presampling / abort predicates,
    where q_p is the p-quantile of T, to maintain P(T <= D - presampling_time) >= p.
  - Each presampling trial costs c seconds; max trials n_max = floor(slack / c).
  - If each trial is an independent soundness attempt (e.g., new FS coins / new folding coefficients),
    per-attempt soundness p0 = 2^{-bits0} amplifies to ~ n_max * p0. We report the induced "bits left".

This is not a measurement; it's a parameterized sanity check that motivates dOCF's attempt accounting:
even under tight deadlines, millisecond-scale internal resampling can multiply the effective attempt budget.
"""
import argparse, json, math
from typing import Dict, Any, List

def normal_quantile(p: float) -> float:
    # Acklam's approximation (sufficient for a reference tool; avoids scipy).
    # Source: Peter J. Acklam, "An algorithm for computing the inverse normal cumulative distribution function".
    # Coefficients:
    a = [-3.969683028665376e+01,  2.209460984245205e+02, -2.759285104469687e+02,
          1.383577518672690e+02, -3.066479806614716e+01,  2.506628277459239e+00]
    b = [-5.447609879822406e+01,  1.615858368580409e+02, -1.556989798598866e+02,
          6.680131188771972e+01, -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
         -2.549732539343734e+00,  4.374664141464968e+00,  2.938163982698783e+00]
    d = [ 7.784695709041462e-03,  3.224671290700398e-01,  2.445134137142996e+00,
          3.754408661907416e+00]
    plow = 0.02425
    phigh = 1 - plow
    if p <= 0 or p >= 1:
        raise ValueError("p must be in (0,1)")
    if p < plow:
        q = math.sqrt(-2*math.log(p))
        return (((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) / \
               ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)
    if p > phigh:
        q = math.sqrt(-2*math.log(1-p))
        return -(((((c[0]*q+c[1])*q+c[2])*q+c[3])*q+c[4])*q+c[5]) / \
                ((((d[0]*q+d[1])*q+d[2])*q+d[3])*q+1)
    q = p - 0.5
    r = q*q
    return (((((a[0]*r+a[1])*r+a[2])*r+a[3])*r+a[4])*r+a[5])*q / \
           (((((b[0]*r+b[1])*r+b[2])*r+b[3])*r+b[4])*r+1)

def lognormal_quantile(p: float, mean: float, sigma: float) -> float:
    # Convert from mean parameterization to mu, then quantile.
    mu = math.log(mean) - (sigma*sigma)/2.0
    z = normal_quantile(p)
    return math.exp(mu + sigma*z)

def compute(D: float, mean: float, sigma: float, bits0: float,
            p_targets: List[float], costs_s: List[float]) -> Dict[str, Any]:
    rows = []
    for pt in p_targets:
        qpt = lognormal_quantile(pt, mean, sigma)
        slack = max(0.0, D - qpt)
        for c in costs_s:
            n_max = int(math.floor(slack / c)) if slack > 0 else 0
            eff_bits = max(0.0, bits0 - math.log2(max(1, n_max)))
            rows.append({
                "P_SLA_target": pt,
                "q_p_s": qpt,
                "slack_s": slack,
                "c_s": c,
                "c_ms": int(round(1000*c)),
                "n_max": n_max,
                "eff_bits": round(eff_bits, 1),
            })
    return {
        "model": {
            "deadline_s": D,
            "heavy_runtime_lognormal": {"mean_s": mean, "sigma": sigma},
            "per_attempt_bits": bits0,
        },
        "rows": rows
    }

def to_latex(rows: List[Dict[str, Any]], label: str) -> str:
    # Expect rows already filtered/ordered as desired.
    out = []
    out.append("\\begin{table}[t]")
    out.append("\\centering")
    out.append("\\small")
    out.append("\\begin{tabular}{@{}c r r r@{}}")
    out.append("\\toprule")
    out.append("$P_{\\mathrm{SLA}}$ target & $c$ (ms) & $n_{\\max}$ resamples & eff. bits \\\\")
    out.append("\\midrule")
    for r in rows:
        out.append(f"{r['P_SLA_target']:.2f} & {r['c_ms']} & {r['n_max']} & {r['eff_bits']:.1f} \\\\")
    out.append("\\bottomrule")
    out.append("\\end{tabular}")
    out.append("\\caption{Toy presampling budget stress test for strict-deadline proving. "
               "See \\texttt{market\\_presampling\\_budget\\_ref.py} for the model.}")
    out.append(f"\\label{{{label}}}")
    out.append("\\end{table}")
    return "\n".join(out)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--deadline", type=float, default=10.0)
    ap.add_argument("--mean", type=float, default=5.0)
    ap.add_argument("--sigma", type=float, default=0.3)
    ap.add_argument("--bits0", type=float, default=80.0)
    ap.add_argument("--p", type=float, nargs="+", default=[0.95, 0.90])
    ap.add_argument("--c_ms", type=int, nargs="+", default=[200, 50, 5, 1])
    ap.add_argument("--json_out", type=str, default="")
    ap.add_argument("--latex_out", type=str, default="")
    args = ap.parse_args()

    costs_s = [ms/1000.0 for ms in args.c_ms]
    res = compute(args.deadline, args.mean, args.sigma, args.bits0, args.p, costs_s)

    # Keep the same ordering as inputs.
    order = {(pt, ms): i for i, (pt, ms) in enumerate(
        [(pt, ms) for pt in args.p for ms in args.c_ms]
    )}
    rows_sorted = sorted(res["rows"], key=lambda r: order[(r["P_SLA_target"], r["c_ms"])])

    if args.json_out:
        with open(args.json_out, "w", encoding="utf-8") as f:
            json.dump({"model": res["model"], "rows": rows_sorted}, f, indent=2)

    if args.latex_out:
        latex = to_latex(rows_sorted, label="tab:market-presampling-budget")
        with open(args.latex_out, "w", encoding="utf-8") as f:
            f.write(latex)

    if not args.json_out and not args.latex_out:
        print(json.dumps({"model": res["model"], "rows": rows_sorted}, indent=2))

if __name__ == "__main__":
    main()
