#!/usr/bin/env python3
"""
policy_proof_equivocation_witness_ref.py

Reference sketch for constructing and verifying a policy-proof equivocation witness:
two anchored policy-proof bundles for the same (bundle_digest, policy_id, sid) with
different verdicts, both signed by the same verifier key.

- `--emit` prints the demo witness (matches test_vectors/policy_proof_equivocation_witness_demo.json).
- `--verify <witness_json>` checks basic well-formedness and DSSE signatures.

This is illustrative and intentionally minimal.
"""
from __future__ import annotations

import argparse, base64, json
from typing import Any, Dict, Tuple

from docf_ref_tools_common import emit_json

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
except Exception:
    Ed25519PublicKey = None  # type: ignore

def pae(payload_type: str, payload: bytes) -> bytes:
    return b"DSSEv1 " + str(len(payload_type)).encode() + b" " + payload_type.encode() + b" " + str(len(payload)).encode() + b" " + payload

def verify_dsse(dsse: Dict[str, Any]) -> Dict[str, Any]:
    if Ed25519PublicKey is None:
        raise RuntimeError("cryptography not available; cannot verify")
    payload_type = dsse["payloadType"]
    payload_bytes = base64.b64decode(dsse["payload"])
    sig0 = dsse["signatures"][0]
    sig = base64.b64decode(sig0["sig"])
    pub_raw = base64.b64decode(dsse["public_key_ed25519_raw_b64"])
    pub = Ed25519PublicKey.from_public_bytes(pub_raw)
    pub.verify(sig, pae(payload_type, payload_bytes))
    return json.loads(payload_bytes.decode("utf-8"))

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit", action="store_true")
    ap.add_argument("--verify", type=str, default="")
    args = ap.parse_args()

    if args.emit:
        with open("test_vectors/policy_proof_equivocation_witness_demo.json", "r", encoding="utf-8") as f:
            emit_json(json.load(f))
        return

    if args.verify:
        with open(args.verify, "r", encoding="utf-8") as f:
            w = json.load(f)
        assert w["format"] == "docf-policy-proof-equivocation-witness-v0"
        b0, b1 = w["bundles"]
        p0 = verify_dsse(b0["dsse"])
        p1 = verify_dsse(b1["dsse"])
        s0, s1 = p0["subject"], p1["subject"]
        assert (s0["bundle_digest_sha256"], s0["policy_id"], s0["sid"]) == (s1["bundle_digest_sha256"], s1["policy_id"], s1["sid"])
        assert p0["verdict"] != p1["verdict"], "no equivocation: verdicts identical"
        emit_json({"ok": True, "verdicts": [p0["verdict"], p1["verdict"]], "subject": s0})
        return

    ap.print_help()

if __name__ == "__main__":
    main()
