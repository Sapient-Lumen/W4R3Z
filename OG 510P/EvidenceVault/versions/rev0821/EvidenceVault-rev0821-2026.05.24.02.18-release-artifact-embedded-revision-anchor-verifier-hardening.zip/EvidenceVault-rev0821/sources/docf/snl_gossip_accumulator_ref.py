#!/usr/bin/env python3
"""snl_gossip_accumulator_ref.py (v86.8)

Create an *optimistic gossip quorum accumulator*.

Motivation
----------
A strict gossip-quorum requirement can bloat acceptance objects (many observers,
many signatures). In some deployments (proof CDNs, relays), we'd like a small
"receipt" that *claims* a quorum exists while still enabling later audit.

This file implements a deliberately conservative variant:
  - the accumulator is *signed by an accumulator operator* (not a threshold sig)
  - it commits (Merkle root) to the set of (observer_id, bundle_digest)
  - it includes a *sample* of full gossip bundles for spot-checking

Relying parties choose semantics via policy:
  - strict reuse: require full gossip bundles (no optimism)
  - monitor-only: accept an accumulator as an optimistic hint and audit later

Usage:
  python3 snl_gossip_accumulator_ref.py --bundles a.json b.json --out acc.json
  python3 snl_gossip_accumulator_ref.py --emit-demo

Outputs (demo): test_vectors/snl_gossip_accumulator_demo.json
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
from typing import Any, Dict, List, Tuple

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from docf_ref_tools_common import jcs, load_json, emit_json


def b64e(b: bytes) -> str:
    return base64.b64encode(b).decode("utf-8")


def b64d(s: str) -> bytes:
    return base64.b64decode(s.encode("utf-8"))


def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_pref(b: bytes) -> str:
    return "sha256:" + sha256_hex(b)


def ct_leaf_hash(preimage: bytes) -> bytes:
    return hashlib.sha256(b"\x00" + preimage).digest()


def ct_node_hash(left: bytes, right: bytes) -> bytes:
    return hashlib.sha256(b"\x01" + left + right).digest()


def merkle_root_and_path(leaf_hashes: List[bytes], leaf_index: int) -> Tuple[bytes, List[bytes]]:
    """Pairwise Merkle root + inclusion path (intentionally simple; matches snl_gate_policy_ref)."""
    assert 0 <= leaf_index < len(leaf_hashes)
    path: List[bytes] = []
    idx = leaf_index
    level = list(leaf_hashes)
    while len(level) > 1:
        nxt: List[bytes] = []
        for i in range(0, len(level), 2):
            if i + 1 == len(level):
                nxt.append(level[i])
                if i == idx:
                    idx = len(nxt) - 1
            else:
                left, right = level[i], level[i + 1]
                parent = ct_node_hash(left, right)
                nxt.append(parent)
                if i == idx:
                    path.append(right)
                    idx = len(nxt) - 1
                elif i + 1 == idx:
                    path.append(left)
                    idx = len(nxt) - 1
        level = nxt
    return level[0], path


def _seed(tag: bytes) -> bytes:
    return hashlib.sha256(tag).digest()[:32]


def demo_accumulator_keypair() -> Tuple[bytes, bytes, str, str]:
    aid = "docf-demo-snl-gossip-accumulator-0"
    seed = _seed(b"docf-demo-snl-gossip-accumulator-key")
    sk = Ed25519PrivateKey.from_private_bytes(seed)
    pk = sk.public_key().public_bytes_raw()
    keyid = "sha256:" + sha256_hex(pk)
    return seed, pk, aid, keyid


def digest_unsigned(obj: Dict[str, Any]) -> str:
    tmp = dict(obj)
    tmp.pop("digest", None)
    tmp.pop("sig", None)
    return sha256_pref(jcs(tmp))


def sign(obj: Dict[str, Any], sk_seed: bytes) -> Dict[str, Any]:
    d = digest_unsigned(obj)
    sk = Ed25519PrivateKey.from_private_bytes(sk_seed)
    sig = sk.sign(d.encode("utf-8"))
    out = dict(obj)
    out["digest"] = d
    out["sig"] = b64e(sig)
    return out


def verify_bundle_signature(bundle: Dict[str, Any]) -> bool:
    try:
        if bundle.get("schema") != "docf-snl-gossip-bundle-v0":
            return False
        tmp = dict(bundle)
        tmp.pop("digest", None)
        tmp.pop("sig", None)
        d_expected = sha256_pref(jcs(tmp))
        if str(bundle.get("digest", "")) != d_expected:
            return False
        obs = bundle.get("observer") or {}
        pk_b64 = str(obs.get("public_key_ed25519_raw_b64", ""))
        sig_b64 = str(bundle.get("sig", ""))
        pub = Ed25519PublicKey.from_public_bytes(b64d(pk_b64))
        pub.verify(b64d(sig_b64), d_expected.encode("utf-8"))
        return True
    except Exception:
        return False


def extract_target(bundle: Dict[str, Any]) -> Tuple[str, int, str]:
    log_id = str(bundle.get("log_id", ""))
    obs = (bundle.get("observations") or [{}])[0] if (bundle.get("observations") or []) else {}
    chk = obs.get("checkpoint") or {}
    tree_size = int(chk.get("tree_size", 0) or 0)
    payload_sha = str(obs.get("checkpoint_payload_sha256_hex", "") or "")
    return log_id, tree_size, payload_sha


def build_accumulator(bundles: List[Dict[str, Any]], sample_k: int = 1) -> Dict[str, Any]:
    if not bundles:
        raise ValueError("need at least one bundle")

    for b in bundles:
        if not verify_bundle_signature(b):
            raise ValueError("invalid_bundle_signature")

    t0 = extract_target(bundles[0])
    for b in bundles[1:]:
        if extract_target(b) != t0:
            raise ValueError("bundles_target_mismatch")

    log_id, tree_size, payload_sha = t0

    entries: List[Dict[str, str]] = []
    for b in bundles:
        oid = str((b.get("observer") or {}).get("observer_id", ""))
        d = str(b.get("digest", ""))
        if not oid or not d:
            continue
        entries.append({"observer_id": oid, "bundle_digest": d})

    entries.sort(key=lambda x: x["observer_id"])

    leaf_preimages = [jcs(e) for e in entries]
    leaf_hashes = [ct_leaf_hash(p) for p in leaf_preimages]

    root, _ = merkle_root_and_path(leaf_hashes, 0) if leaf_hashes else (b"", [])

    sk_seed, pk_raw, aid, keyid = demo_accumulator_keypair()

    sample: List[Dict[str, Any]] = []
    k = max(0, min(sample_k, len(entries)))
    for i in range(k):
        oid = entries[i]["observer_id"]
        b = next(bb for bb in bundles if str((bb.get("observer") or {}).get("observer_id", "")) == oid)
        _, path = merkle_root_and_path(leaf_hashes, i)
        sample.append(
            {
                "observer_id": oid,
                "bundle": b,
                "inclusion_path_sha256_b64": [b64e(x) for x in path],
                "leaf_index": i,
            }
        )

    acc = {
        "schema": "docf-snl-gossip-accumulator-v0",
        "version": "0",
        "created_at": "2026-02-27T00:01:10Z",
        "log_id": log_id,
        "tree_size": tree_size,
        "checkpoint_payload_sha256_hex": payload_sha,
        "issuer": {
            "accumulator_id": aid,
            "public_key_ed25519_raw_b64": b64e(pk_raw),
            "keyid": keyid,
            "notes": ["Deterministic demo accumulator operator."],
        },
        "entries": entries,
        "merkle_root_sha256_b64": b64e(root) if root else "",
        "sample": sample,
        "notes": [
            "Accumulator commits to a claimed quorum set without including every bundle inline.",
            "Relying parties should treat this as monitor-only unless they can fetch and verify the missing bundles.",
        ],
    }

    return sign(acc, sk_seed)


def emit_demo() -> None:
    tv = os.path.join(os.path.dirname(__file__), "test_vectors")
    os.makedirs(tv, exist_ok=True)

    a = load_json(os.path.join(tv, "snl_gossip_bundle_A_demo.json"))
    b = load_json(os.path.join(tv, "snl_gossip_bundle_B_demo.json"))

    acc = build_accumulator([a, b], sample_k=1)
    out_path = os.path.join(tv, "snl_gossip_accumulator_demo.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(acc, f, indent=2, ensure_ascii=False)
        f.write("\n")

    emit_json(acc)
    print(f"Wrote {out_path}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--bundles", nargs="*", default=[])
    ap.add_argument("--out", type=str, default="")
    ap.add_argument("--sample", type=int, default=1)
    ap.add_argument("--emit-demo", action="store_true")
    args = ap.parse_args()

    if args.emit_demo:
        emit_demo()
        return

    if not args.bundles or not args.out:
        ap.print_help()
        return

    bundles = [load_json(p) for p in args.bundles]
    acc = build_accumulator(bundles, sample_k=int(args.sample))
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(acc, f, indent=2, ensure_ascii=False)
        f.write("\n")


if __name__ == "__main__":
    main()
