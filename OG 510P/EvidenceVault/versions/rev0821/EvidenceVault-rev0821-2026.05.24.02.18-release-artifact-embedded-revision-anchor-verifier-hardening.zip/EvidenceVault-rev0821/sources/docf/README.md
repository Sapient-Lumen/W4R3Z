# dOCF evolving archive (v86.37-ai)

This folder is a working research archive for multiple paper tracks derived from the living dOCF spec:

- **Obligation-Carrying Distributed Proving (dOCF)** — long-form spec (`paper.tex`)
- **Paper A** — crypto core (retry/cancellation/conditioning) (`paperA.tex`)
- **Paper B** — portability contracts / governance / markets (`paperB.tex`)
- **Paper C** — Security Nutrition Labels (SNLs) + gate semantics + stapling (`paperC.tex`)
- **Paper D** — portfolio risk budgets: $\eps$-ledgers + auditable $\eps$-scoring + anytime-valid performance certificates (`paperD.tex`)
- **Paper E** — receipt-complete prover markets (Attempt DAGs + transparency logs + risk budgets) (`paperE.tex`)
- **Paper F** — Proof Certificate Transparency (PCT) standardization track (`paperF.tex`)
- **Paper G** — witnessed checkpoints and split-view resistance note (`paperG.tex`)
- **Paper H** — client-policy / witness-selection security parameters (`paperH.tex`)
- **Paper I** — witness diversity / correlated compromise selection (`paperI.tex`)

## Build
All papers share `references.tex` (LaTeX `thebibliography`).

If you compile locally, these commands should work (run twice for cross-refs):

- `pdflatex paperA.tex`
- `pdflatex paperB.tex`
- `pdflatex paperC.tex`
- `pdflatex paperD.tex`
- `pdflatex paperE.tex`
- `pdflatex paperF.tex`
- `pdflatex paperG.tex`
- `pdflatex paperH.tex`
- `pdflatex paper.tex` (long; many floats)

## Contents highlights
- `*_insert_*.tex`: auto-generated tables used by the papers/spec.
- `*_ref.py`: reference implementations referenced by the papers.
- `docf_*_v0.schema.json`: JSON schemas for staplable artifacts.
- `test_vectors/`: example artifacts used in listings.

## Snapshot discipline
When making substantive changes, add a short entry to `ARCHIVE.md` and `CHANGELOG.md`.


## Reference tools

- `pct_bundle_ref.py` emits + verifies an end-to-end Proof Certificate Transparency bundle (PCTB-v2) and writes `test_vectors/pct_bundle_demo_v2.json`.
- `make_pct_end2end_demo_table.py` generates `_insert_pct_end2end_demo_table.tex` from the v1 demo bundle.
- `make_pct_end2end_demo_table_v2.py` generates `_insert_pct_end2end_demo_table_v2.tex` from the v2 demo bundle.
- `make_pct_bench_tables.py` generates `test_vectors/pct_bench_results.json` and LaTeX inserts with microbenchmarks.


### Split-view latency experiment (toy)
Run:
- `python3 make_split_view_latency_experiment.py`
This regenerates `tab:split_view_latency` inserts and the CDF figures used by Paper F/G.


### Client-policy split-view experiment (toy)
Run:
- `python3 make_client_policy_experiment.py`
This regenerates `tab:client_policy_refusal` and the CDF figure used by Paper F/G/H.

## New in v86.37-ai
- Added an explicit incentive lemma for enforceable correlation clusters: a replayable bond schedule that upper-bounds misassignment gains (Paper D, `sec:cluster-dispute`).
- New demo figure `figures/bond_threshold_demo.pdf` and helper script `bond_threshold_demo.py`.
