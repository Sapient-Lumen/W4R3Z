#!/usr/bin/env python3
"""Generate a simple bond-threshold figure for the cluster misassignment dispute game.

The figure visualizes the proposition B_p >= Δ / p.
We avoid any specific styling/color choices; matplotlib defaults are used.
"""

import numpy as np
import matplotlib.pyplot as plt


def main() -> None:
    ps = np.linspace(0.05, 1.0, 200)
    deltas = [1.0, 0.25]  # illustrative, normalized units

    plt.figure(figsize=(6.5, 3.6))
    for d in deltas:
        bp = d / ps
        plt.plot(ps, bp, label=f"Δ={d:g}")

    plt.yscale("log")
    plt.xlabel("challenge coverage p")
    plt.ylabel("required proposer bond Bp")
    plt.title("Bond threshold Bp ≥ Δ / p")
    plt.grid(True, which="both", linestyle="--", linewidth=0.5)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig("figures/bond_threshold_demo.pdf")


if __name__ == "__main__":
    main()
