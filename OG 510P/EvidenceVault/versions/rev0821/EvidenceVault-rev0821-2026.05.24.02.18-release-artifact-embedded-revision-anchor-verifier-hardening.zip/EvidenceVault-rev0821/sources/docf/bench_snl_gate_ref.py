#!/usr/bin/env python3
"""bench_snl_gate_ref.py (v86.8)

Micro-benchmark + sizing helper for the SNL gate path.

Outputs:
  - test_vectors/snl_gate_bench_results.json
  - _insert_snl_gate_bench_table.tex (LaTeX insert)

This benchmark is intentionally lightweight. Its purpose is to demonstrate that
SNL-based gating (digesting + signature + threshold checks, optionally plus a
CT-style inclusion witness and witness cosigning) is orders-of-magnitude cheaper
than generating or verifying the underlying proof.

All numbers are for relative comparisons on the runner host.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import statistics
import time
from typing import Any, Dict, List, Optional

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from docf_ref_tools_common import jcs, load_json
from snl_gate_policy_ref import eval_gate, verify_snl, verify_snl_staple


DEFAULT_BENCH_ITERS = int(os.environ.get("DOCF_BENCH_N", "900"))
DEFAULT_WARM_ITERS = int(os.environ.get("DOCF_BENCH_WARM", "120"))

def file_bytes(path: str) -> int:
    return os.path.getsize(path)


def median_us(samples_s: List[float]) -> float:
    return 1e6 * statistics.median(samples_s)


def bench(fn, iters: int = DEFAULT_BENCH_ITERS, warm: int = DEFAULT_WARM_ITERS) -> float:
    for _ in range(warm):
        fn()
    samples: List[float] = []
    for _ in range(iters):
        t0 = time.perf_counter()
        fn()
        samples.append(time.perf_counter() - t0)
    return median_us(samples)


def sig_verify_only(snl: Dict[str, Any]) -> None:
    issuer = snl.get("issuer") or {}
    pub_b64 = issuer.get("public_key_ed25519_raw_b64", "")
    sig_b64 = snl.get("sig", "")
    d = snl.get("digest", "")
    pub = Ed25519PublicKey.from_public_bytes(base64.b64decode(pub_b64))
    pub.verify(base64.b64decode(sig_b64), d.encode("utf-8"))


def digest_only(snl: Dict[str, Any]) -> None:
    tmp = dict(snl)
    tmp.pop("digest", None)
    tmp.pop("sig", None)
    _ = "sha256:" + hashlib.sha256(jcs(tmp)).hexdigest()


def main() -> None:
    tv = "test_vectors"

    snl_ok_path = os.path.join(tv, "security_nutrition_label_demo_ok.json")
    snl_fail_path = os.path.join(tv, "security_nutrition_label_demo.json")
    pol_reuse_path = os.path.join(tv, "snl_gate_policy_reuse_demo.json")
    pol_log_path = os.path.join(tv, "snl_gate_policy_reuse_with_log_demo.json")
    pol_log_quorum_path = os.path.join(tv, "snl_gate_policy_reuse_with_log_quorum_demo.json")
    pol_log_consistency_path = os.path.join(tv, "snl_gate_policy_reuse_with_log_consistency_demo.json")
    pol_log_consistency_gossip_path = os.path.join(tv, "snl_gate_policy_reuse_with_log_consistency_gossip_demo.json")
    pol_mon_acc_path = os.path.join(tv, "snl_gate_policy_monitor_with_log_accumulator_demo.json")
    gossip_bundle_A_path = os.path.join(tv, "snl_gossip_bundle_A_demo.json")
    gossip_bundle_B_path = os.path.join(tv, "snl_gossip_bundle_B_demo.json")
    gossip_acc_path = os.path.join(tv, "snl_gossip_accumulator_demo.json")
    staple_path = os.path.join(tv, "snl_staple_demo.json")

    snl_ok = load_json(snl_ok_path)
    snl_fail = load_json(snl_fail_path)
    pol_reuse = load_json(pol_reuse_path)

    pol_log = load_json(pol_log_path) if os.path.exists(pol_log_path) else None
    pol_log_quorum = load_json(pol_log_quorum_path) if os.path.exists(pol_log_quorum_path) else None
    pol_log_consistency = load_json(pol_log_consistency_path) if os.path.exists(pol_log_consistency_path) else None
    pol_log_consistency_gossip = load_json(pol_log_consistency_gossip_path) if os.path.exists(pol_log_consistency_gossip_path) else None
    pol_mon_acc = load_json(pol_mon_acc_path) if os.path.exists(pol_mon_acc_path) else None

    staple = load_json(staple_path) if os.path.exists(staple_path) else None
    gossipA = load_json(gossip_bundle_A_path) if os.path.exists(gossip_bundle_A_path) else None
    gossipB = load_json(gossip_bundle_B_path) if os.path.exists(gossip_bundle_B_path) else None
    gossipAcc = load_json(gossip_acc_path) if os.path.exists(gossip_acc_path) else None

    # Baseline checks
    t_digest = bench(lambda: digest_only(snl_ok))
    t_sig = bench(lambda: sig_verify_only(snl_ok))
    t_verify = bench(lambda: verify_snl(snl_ok))
    t_gate = bench(lambda: eval_gate(snl_ok, pol_reuse))

    t_staple = None
    t_gate_log = None
    if pol_log and staple:
        t_staple = bench(lambda: verify_snl_staple(snl_ok, staple, pol_log))
        t_gate_log = bench(lambda: eval_gate(snl_ok, pol_log, staple=staple))

    t_staple_quorum = None
    t_gate_log_quorum = None
    if pol_log_quorum and staple:
        t_staple_quorum = bench(lambda: verify_snl_staple(snl_ok, staple, pol_log_quorum))
        t_gate_log_quorum = bench(lambda: eval_gate(snl_ok, pol_log_quorum, staple=staple))

    t_staple_consistency = None
    t_gate_log_consistency = None
    if pol_log_consistency and staple:
        t_staple_consistency = bench(lambda: verify_snl_staple(snl_ok, staple, pol_log_consistency))
        t_gate_log_consistency = bench(lambda: eval_gate(snl_ok, pol_log_consistency, staple=staple))
    t_gate_log_consistency_gossip = None
    if pol_log_consistency_gossip and staple and gossipA and gossipB:
        t_gate_log_consistency_gossip = bench(lambda: eval_gate(snl_ok, pol_log_consistency_gossip, staple=staple, gossip_bundles=[gossipA, gossipB]))

    t_gate_monitor_with_accumulator = None
    if pol_mon_acc and staple and gossipAcc:
        t_gate_monitor_with_accumulator = bench(lambda: eval_gate(snl_ok, pol_mon_acc, staple=staple, gossip_accumulator=gossipAcc))


    # Sizes
    sizes = {
        "TORR_bytes": file_bytes(os.path.join(tv, "typed_option_repricing_report_demo.json"))
        if os.path.exists(os.path.join(tv, "typed_option_repricing_report_demo.json"))
        else None,
        "GGC_bytes": file_bytes(os.path.join(tv, "grinding_gap_certificate_demo.json"))
        if os.path.exists(os.path.join(tv, "grinding_gap_certificate_demo.json"))
        else None,
        "SNL_ok_bytes": file_bytes(snl_ok_path),
        "SNL_fail_bytes": file_bytes(snl_fail_path),
        "GatePolicy_reuse_bytes": file_bytes(pol_reuse_path),
        "GatePolicy_reuse_log_bytes": file_bytes(pol_log_path) if os.path.exists(pol_log_path) else None,
        "GatePolicy_reuse_log_quorum_bytes": file_bytes(pol_log_quorum_path) if os.path.exists(pol_log_quorum_path) else None,
        "GatePolicy_reuse_log_consistency_bytes": file_bytes(pol_log_consistency_path) if os.path.exists(pol_log_consistency_path) else None,
        "SNL_staple_bytes": file_bytes(staple_path) if os.path.exists(staple_path) else None,
        "GatePolicy_reuse_log_consistency_gossip_bytes": file_bytes(pol_log_consistency_gossip_path) if os.path.exists(pol_log_consistency_gossip_path) else None,
        "GatePolicy_monitor_log_accumulator_bytes": file_bytes(pol_mon_acc_path) if os.path.exists(pol_mon_acc_path) else None,
        "GossipBundle_A_bytes": file_bytes(gossip_bundle_A_path) if os.path.exists(gossip_bundle_A_path) else None,
        "GossipBundle_B_bytes": file_bytes(gossip_bundle_B_path) if os.path.exists(gossip_bundle_B_path) else None,
        "GossipAccumulator_bytes": file_bytes(gossip_acc_path) if os.path.exists(gossip_acc_path) else None,
    }

    results = {
        "times_median_us": {
            "digest_only": t_digest,
            "sig_verify_only": t_sig,
            "verify_snl": t_verify,
            "gate_reuse": t_gate,
            "verify_staple": t_staple,
            "gate_reuse_with_log": t_gate_log,
            "verify_staple_with_quorum": t_staple_quorum,
            "gate_reuse_with_log_quorum": t_gate_log_quorum,
            "verify_staple_with_consistency": t_staple_consistency,
            "gate_reuse_with_log_consistency": t_gate_log_consistency,
            "gate_reuse_with_log_consistency_gossip": t_gate_log_consistency_gossip,
            "gate_monitor_with_log_accumulator": t_gate_monitor_with_accumulator,
        },
        "sizes_bytes": sizes,
        "notes": "Reference microbench on demo vectors; use for relative comparison only.",
    }

    os.makedirs(tv, exist_ok=True)
    with open(os.path.join(tv, "snl_gate_bench_results.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, indent=2, sort_keys=False)
        f.write("\n")

    # LaTeX insert table
    def fmt_us(x: Optional[float]) -> str:
        return "--" if x is None else f"${x:.1f}\\,\\mu\\mathrm{{s}}$"

    def fmt_bytes(x: Optional[int]) -> str:
        return "--" if x is None else str(x)

    rows = []
    rows.append(("SNL\\_ok", sizes["SNL_ok_bytes"], f"{fmt_us(t_verify)} (verify)"))
    rows.append(("GatePolicy\\_reuse", sizes["GatePolicy_reuse_bytes"], "--"))
    rows.append(("Gate(reuse)", None, f"{fmt_us(t_gate)} (gate)"))
    if sizes["SNL_staple_bytes"] is not None:
        rows.append(("SNL\\_staple", sizes["SNL_staple_bytes"], f"{fmt_us(t_staple)} (verify)"))
    if t_gate_log is not None:
        rows.append(("Gate(reuse+log)", None, f"{fmt_us(t_gate_log)} (gate)"))
    if sizes["GatePolicy_reuse_log_quorum_bytes"] is not None:
        rows.append(("GatePolicy\\_reuse\\_log\\_quorum", sizes["GatePolicy_reuse_log_quorum_bytes"], "--"))
    if t_staple_quorum is not None:
        rows.append(("SNL\\_staple+quorum", None, f"{fmt_us(t_staple_quorum)} (verify)"))
    if t_gate_log_quorum is not None:
        rows.append(("Gate(reuse+log+quorum)", None, f"{fmt_us(t_gate_log_quorum)} (gate)"))
    if sizes["GatePolicy_reuse_log_consistency_bytes"] is not None:
        rows.append(("GatePolicy\\_reuse\\_log\\_consistency", sizes["GatePolicy_reuse_log_consistency_bytes"], "--"))
    if t_staple_consistency is not None:
        rows.append(("SNL\\_staple+consistency", None, f"{fmt_us(t_staple_consistency)} (verify)"))
    if t_gate_log_consistency is not None:
        rows.append(("Gate(reuse+log+consistency)", None, f"{fmt_us(t_gate_log_consistency)} (gate)"))
    if sizes.get("GatePolicy_reuse_log_consistency_gossip_bytes") is not None:
        rows.append(("GatePolicy\\_reuse\\_log\\_consistency\\_gossip", sizes["GatePolicy_reuse_log_consistency_gossip_bytes"], "--"))
    if sizes.get("GossipBundle_A_bytes") is not None:
        rows.append(("GossipBundle\\_A", sizes["GossipBundle_A_bytes"], "--"))
    if sizes.get("GossipBundle_B_bytes") is not None:
        rows.append(("GossipBundle\\_B", sizes["GossipBundle_B_bytes"], "--"))
    if t_gate_log_consistency_gossip is not None:
        rows.append(("Gate(reuse+log+consistency+gossip)", None, f"{fmt_us(t_gate_log_consistency_gossip)} (gate)"))
    if sizes.get("GatePolicy_monitor_log_accumulator_bytes") is not None:
        rows.append(("GatePolicy\\_monitor\\_log\\_accumulator", sizes["GatePolicy_monitor_log_accumulator_bytes"], "--"))
    if sizes.get("GossipAccumulator_bytes") is not None:
        rows.append(("GossipAccumulator", sizes["GossipAccumulator_bytes"], "--"))
    if t_gate_monitor_with_accumulator is not None:
        rows.append(("Gate(monitor+accumulator)", None, f"{fmt_us(t_gate_monitor_with_accumulator)} (gate)"))

    tex_lines = []
    tex_lines.append("% Auto-generated by bench_snl_gate_ref.py (v86.8)")
    tex_lines.append("\\begin{table}[t]")
    tex_lines.append("\\centering")
    tex_lines.append("\\small")
    tex_lines.append("\\begin{tabular}{lrr}")
    tex_lines.append("\\toprule")
    tex_lines.append("Artifact / step & Bytes & Median time \\\\ ")
    tex_lines.append("\\midrule")
    if sizes["TORR_bytes"] is not None:
        tex_lines.append(f"TORR & {sizes['TORR_bytes']} & -- \\\\ ")
    if sizes["GGC_bytes"] is not None:
        tex_lines.append(f"GGC & {sizes['GGC_bytes']} & -- \\\\ ")
    for name, b, t in rows:
        tex_lines.append(f"{name} & {fmt_bytes(b)} & {t} \\\\ ")
    tex_lines.append("\\bottomrule")
    tex_lines.append("\\end{tabular}")
    tex_lines.append(
        "\\caption{Reference sizing and micro-benchmark for the SNL gate path on demo vectors. "
        "Verification includes canonicalization, digest binding, and Ed25519 signature checks; "
        "the optional SNL\\_staple row verifies a CT-style inclusion witness (RFC9162-style), "
        "and SNL\\_staple+quorum additionally verifies Sigsum-style witness cosignatures over the checkpoint; "
        "SNL\\_staple+consistency additionally verifies an RFC9162 consistency proof linking a pinned earlier checkpoint to the current head. "
        "Results are for relative comparison only.}"
    )
    tex_lines.append("\\label{tab:snl-gate-bench}")
    tex_lines.append("\\end{table}")

    with open("_insert_snl_gate_bench_table.tex", "w", encoding="utf-8") as f:
        f.write("\n".join(tex_lines) + "\n")


if __name__ == "__main__":

    main()
