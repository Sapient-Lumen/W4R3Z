#!/usr/bin/env python3
"""make_wdd_policy_demo.py

v86.26 artifact: Witness Diversity Descriptor (WDD) + verifier rule demo.

Goal:
  Turn the paper's qualitative "witness diversity matters" message into a
  *portable, checkable* policy artifact that can ship inside a PCT bundle.

Inputs:
  - data/witness_pool_snapshot_YYYY-MM-DD.json

We extract a small set of "risk domains" from public fields:
  - operator (from snapshot)
  - implementation family (heuristic parse of notes)
  - key management family (heuristic parse of notes)

We then compute a conservative, explainable correlation lower bound induced by
clustering in each domain:

  rho_domain = \sum_g n_g (n_g-1) / (m (m-1))

Interpretation:
  If witnesses in the same group g fail together (perfect within-group
  correlation) and distinct groups fail independently, then rho_domain is the
  *average pairwise correlation* across the witness set.

A verifier can then (conservatively) take:
  rho_hat = max_d rho_domain

and check whether rho_hat is compatible with its declared risk budgets.

Outputs:
  - _insert_wdd_metrics_table.tex
  - _insert_wdd_policy_budget_table.tex
  - pct_wdd_policy_budget.pdf

Deterministic; no network access.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Dict, List, Tuple

ROOT = Path(__file__).resolve().parent


def log_beta(a: float, b: float) -> float:
    return math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)


def beta_binom_pmf(m: int, k: int, alpha: float, beta: float) -> float:
    return math.comb(m, k) * math.exp(log_beta(alpha + k, beta + m - k) - log_beta(alpha, beta))


def hypergeom_pmf(N: int, K: int, n: int, k: int) -> float:
    if k < 0 or k > n or k > K or (n - k) > (N - K):
        return 0.0
    return (math.comb(K, k) * math.comb(N - K, n - k)) / math.comb(N, n)


def dual_accept_prob_given_K(m: int, t: int, g: int, K: int) -> float:
    """As in make_witness_corr_sweep.py (hard split-view, compromised signs both)."""
    lo = max(0, t - (m - g))
    hi = min(g, K + g - t)
    if lo > hi:
        return 0.0
    return sum(hypergeom_pmf(m, K, g, kA) for kA in range(lo, hi + 1))


def compute_probs(m: int, t: int, q: float, rho: float) -> Tuple[float, float]:
    """Return (P[K>=t], P[dual accept]) under exchangeable Beta–Binomial ICC rho."""
    g = m // 2

    # rho=0 special-case (pure Binomial)
    if rho <= 0.0:
        pQ = 0.0
        pD = 0.0
        for K in range(0, m + 1):
            pK = math.comb(m, K) * (q**K) * ((1 - q) ** (m - K))
            if K >= t:
                pQ += pK
            pD += pK * dual_accept_prob_given_K(m, t, g, K)
        return pQ, pD

    # Beta–Binomial mixture, parameterized by (q, rho)
    s = (1.0 / rho) - 1.0
    alpha = max(1e-12, q * s)
    beta = max(1e-12, (1.0 - q) * s)

    pQ = 0.0
    pD = 0.0
    for K in range(0, m + 1):
        pK = beta_binom_pmf(m, K, alpha, beta)
        if K >= t:
            pQ += pK
        pD += pK * dual_accept_prob_given_K(m, t, g, K)
    return pQ, pD


def detect_impl_family(notes: str) -> str:
    n = notes.lower()
    # coarse families; treat missing as unique per witness
    if "sunlight" in n:
        return "sunlight"
    if "litewitness" in n:
        return "litewitness"
    if "sigsum" in n:
        return "sigsum"
    return "other"


def detect_key_family(notes: str) -> str:
    n = notes.lower()
    if "soft key" in n:
        return "soft-key"
    if "hsm" in n or "hardware" in n:
        return "hsm"
    return "other"


def group_corr_lower_bound(labels: List[str]) -> Tuple[float, Dict[str, int]]:
    """Return (rho_lower_bound, counts) for clustering labels.

    Any label equal to '__unique__:<id>' is treated as its own singleton.
    """
    counts: Dict[str, int] = {}
    for lab in labels:
        counts[lab] = counts.get(lab, 0) + 1
    m = len(labels)
    if m <= 1:
        return 0.0, counts
    num = sum(v * (v - 1) for v in counts.values())
    den = m * (m - 1)
    return num / den, counts


def herfindahl_neff(counts: Dict[str, int]) -> Tuple[float, float]:
    m = sum(counts.values())
    if m == 0:
        return 0.0, 0.0
    H = 0.0
    for v in counts.values():
        s = v / m
        H += s * s
    Neff = 1.0 / H if H > 0 else 0.0
    return H, Neff


def max_rho_for_budget(m: int, t: int, q: float, budget_dual: float) -> float | None:
    # If even rho=0 exceeds budget, no correlation level can satisfy this budget.
    _, pD0 = compute_probs(m, t, q, 0.0)
    if pD0 > budget_dual:
        return None

    """Binary search for maximum rho such that P_dual <= budget."""
    lo, hi = 0.0, 0.999
    for _ in range(70):
        mid = (lo + hi) / 2
        _, pD = compute_probs(m, t, q, mid)
        if pD <= budget_dual:
            lo = mid
        else:
            hi = mid
    return lo


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--inp",
        default=str(ROOT / "data" / "witness_pool_snapshot_2026-02-28.json"),
        help="input snapshot JSON",
    )
    ap.add_argument("--q", type=float, default=0.12, help="marginal witness compromise probability")
    ap.add_argument("--t", type=int, default=6, help="client threshold for demo")
    ap.add_argument("--budgets", type=str, default="8,10,12", help="comma-separated budgets as 2^-k")
    ap.add_argument("--out_metrics", default=str(ROOT / "_insert_wdd_metrics_table.tex"))
    ap.add_argument("--out_budget", default=str(ROOT / "_insert_wdd_policy_budget_table.tex"))
    ap.add_argument("--out_plot", default=str(ROOT / "pct_wdd_policy_budget.pdf"))
    args = ap.parse_args()

    snap = json.loads(Path(args.inp).read_text(encoding="utf-8"))
    ws = snap["witnesses"]
    m = len(ws)

    # Build WDD labels
    ops: List[str] = []
    impls: List[str] = []
    keys: List[str] = []

    for i, w in enumerate(ws):
        notes = " ".join(w.get("notes", []))

        op = w.get("operator") or f"__unique__:{i}"
        ops.append(op)

        impl = detect_impl_family(notes)
        # If we cannot classify ("other"), keep singleton labels so unknown doesn't
        # artificially cluster everything.
        if impl == "other":
            impls.append(f"__unique__:{i}")
        else:
            impls.append(impl)

        keyf = detect_key_family(notes)
        if keyf == "other":
            keys.append(f"__unique__:{i}")
        else:
            keys.append(keyf)

    dims = [
        ("Operator", ops),
        ("Implementation", impls),
        ("Key mgmt", keys),
    ]

    # Compute metrics
    metric_rows: List[Tuple[str, int, int, float, float, float]] = []
    rho_hat = 0.0
    rho_hat_dim = ""

    for name, labels in dims:
        rho, counts = group_corr_lower_bound(labels)
        H, Neff = herfindahl_neff(counts)
        k_groups = len(counts)
        max_group = max(counts.values()) if counts else 0
        metric_rows.append((name, k_groups, max_group, Neff, rho, H))
        if rho > rho_hat:
            rho_hat = rho
            rho_hat_dim = name

    # Risk at rho_hat vs independence
    pQ0, pD0 = compute_probs(m, args.t, args.q, 0.0)
    pQh, pDh = compute_probs(m, args.t, args.q, rho_hat)

    # Policy budgets
    ks = [int(x.strip()) for x in args.budgets.split(",") if x.strip()]
    budget_rows: List[Tuple[int, float, float | None]] = []  # k, budget, rho_max
    for k in ks:
        budget = 2.0 ** (-k)
        rho_max = max_rho_for_budget(m, args.t, args.q, budget)
        budget_rows.append((k, budget, rho_max))

    # Write metrics table
    with open(args.out_metrics, "w", encoding="utf-8") as f:
        f.write(f"% Auto-generated from {Path(args.inp).name}\n")
        f.write(r"\begin{tabular}{l r r r r r}" + "\n")
        f.write(r"\toprule" + "\n")
        f.write(r"Risk domain & Groups & Max group & $N_\mathrm{eff}$ & $\hat\rho_d$ & $H$ \\" + "\n")
        f.write(r"\midrule" + "\n")
        for (name, k_groups, max_group, Neff, rho, H) in metric_rows:
            f.write(f"{name} & {k_groups} & {max_group} & {Neff:.2f} & {rho:.3f} & {H:.3f} \\\\\n")
        f.write(r"\midrule" + "\n")
        f.write(
            rf"\multicolumn{{6}}{{l}}{{Conservative bound: $\hat\rho=\max_d \hat\rho_d = {rho_hat:.3f}$ (from {rho_hat_dim}).}}\\" +
            "\n"
        )
        f.write(
            rf"\multicolumn{{6}}{{l}}{{Demo risk (m={m}, t={args.t}, q={args.q}): $P_\mathrm{{dual}}(\rho=0)={pD0:.3g}$; $P_\mathrm{{dual}}(\hat\rho)={pDh:.3g}$.}}\\" +
            "\n"
        )
        f.write(r"\bottomrule" + "\n")
        f.write(r"\end{tabular}" + "\n")

    # Write policy budget table
    with open(args.out_budget, "w", encoding="utf-8") as f:
        f.write(r"\begin{tabular}{r r r}" + "\n")
        f.write(r"\toprule" + "\n")
        f.write(r"Budget (bits) & $B_\mathrm{dual}=2^{-k}$ & Max allowed $\rho$ (for fixed $t$) \\" + "\n")
        f.write(r"\midrule" + "\n")
        for k, budget, rho_max in budget_rows:
            if rho_max is None:
                continue
            f.write(f"{k} & {budget:.6g} & {rho_max:.3f} \\\\\n")
        f.write(r"\bottomrule" + "\n")
        f.write(r"\end{tabular}" + "\n")

    # Plot: rho_max vs k (budgets)
    try:
        import matplotlib.pyplot as plt

        xs = [k for (k, _, r) in budget_rows if r is not None]
        ys = [r for (_, _, r) in budget_rows if r is not None]
        plt.figure()
        plt.plot(xs, ys, marker="o")
        plt.gca().invert_xaxis()
        plt.xlabel("Budget bits k (B_dual = 2^-k)")
        plt.ylabel("Max allowed intraclass correlation ρ")
        plt.title(f"Correlation budget for split-view (m={m}, t={args.t}, q={args.q})")
        plt.tight_layout()
        plt.savefig(args.out_plot)
        plt.close()
    except Exception:
        pass


if __name__ == "__main__":
    main()
