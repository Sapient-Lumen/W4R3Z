#!/usr/bin/env python3
"""tpv_diff_ref.py

Reference "diff" tool for Threat Posture Vectors (TPVs).

Motivation: monitors often want to detect posture upgrades/downgrades without
re-parsing full manifests. TPVs are designed to be small; a diff makes
continuous monitoring cheaper.

The diff is purely structural: it compares threat sets, grades, and semantic
bindings (catalog/policy_nf/resolver). It does not infer whether a change is
"good"; policy decides.

Usage:
  python3 tpv_diff_ref.py --old A.json --new B.json --out tpv_diff.json --created_at 2026-02-26T00:00:00Z
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List, Set

from docf_ref_tools_common import jcs, load_json


def sha256_pref(b: bytes) -> str:
    return "sha256:" + hashlib.sha256(b).hexdigest()


def to_set(x: Any) -> Set[str]:
    if isinstance(x, list):
        return set(str(v) for v in x)
    return set()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--old", required=True)
    ap.add_argument("--new", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--created_at", default="")
    args = ap.parse_args()

    a = load_json(args.old)
    b = load_json(args.new)

    a_digest = sha256_pref(jcs(a))
    b_digest = sha256_pref(jcs(b))

    a_m = to_set(a.get("mitigated"))
    b_m = to_set(b.get("mitigated"))
    a_o = to_set(a.get("open"))
    b_o = to_set(b.get("open"))

    def grades(x: Any) -> Dict[str, int]:
        g = x.get("grades", {}) if isinstance(x, dict) else {}
        if not isinstance(g, dict):
            return {"L": -1, "D": -1}
        return {"L": int(g.get("L", -1)), "D": int(g.get("D", -1))}

    ga = grades(a)
    gb = grades(b)

    out: Dict[str, Any] = {
        "type": "docf.tpv_diff",
        "version": "v0",
        "created_at": args.created_at or "2026-02-26T00:00:00Z",
        "old": {"path": args.old, "digest": a_digest},
        "new": {"path": args.new, "digest": b_digest},
        "semantic": {
            "catalog_digest": {"old": str(a.get("catalog_digest", "")), "new": str(b.get("catalog_digest", ""))},
            "policy_nf_digest": {"old": str(a.get("policy_nf_digest", "")), "new": str(b.get("policy_nf_digest", ""))},
            "resolver_id": {"old": str(a.get("resolver_id", "")), "new": str(b.get("resolver_id", ""))}
        },
        "grades": {"old": ga, "new": gb, "delta": {"L": gb["L"] - ga["L"], "D": gb["D"] - ga["D"]}},
        "mitigated": {
            "added": sorted(list(b_m - a_m)),
            "removed": sorted(list(a_m - b_m))
        },
        "open": {
            "added": sorted(list(b_o - a_o)),
            "removed": sorted(list(a_o - b_o))
        }
    }

    Path(args.out).write_text(json.dumps(out, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
