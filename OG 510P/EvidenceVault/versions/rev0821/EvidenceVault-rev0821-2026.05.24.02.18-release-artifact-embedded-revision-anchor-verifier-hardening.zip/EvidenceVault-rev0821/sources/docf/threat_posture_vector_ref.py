#!/usr/bin/env python3
"""threat_posture_vector_ref.py

Reference generator for a compact Threat Posture Vector (TPV).

A TPV is a small, signed-and-loggable "nutrition label" derived from the
machine-readable threat catalog and a conservative (fail-closed) feature check.
It is intended to be cheap to publish and easy to compare across prover vendors.

Usage:
  python3 threat_posture_vector_ref.py --in test_vectors/portable_acceptance_object_demo.json \
    --out test_vectors/threat_posture_vector_pao_demo.json

Notes:
  - This tool is intentionally conservative: threats are "mitigated" only when
    all required features are present.
  - A real deployment would sign the canonicalized TPV (JCS) and staple
    transparency receipts; we keep signatures as optional fields.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Tuple

from docf_ref_tools_common import jcs, load_json

ROOT = Path(__file__).resolve().parent


def sha256_pref(b: bytes) -> str:
    return "sha256:" + hashlib.sha256(b).hexdigest()


def infer_subject_kind(obj: Any) -> str:
    if isinstance(obj, dict):
        t = str(obj.get("type", ""))
        if "portable_acceptance" in t:
            return "pao"
        fmt = str(obj.get("format", ""))
        if "pabom" in fmt:
            return "pabom"
    return "manifest"


def infer_anchor(obj: Any) -> Dict[str, Any] | None:
    if not isinstance(obj, dict):
        return None
    a = obj.get("anchor")
    if not isinstance(a, dict):
        return None
    out: Dict[str, Any] = {}
    if isinstance(a.get("log_id"), str):
        out["log_id"] = a["log_id"]
    if isinstance(a.get("checkpoint_root"), str):
        out["checkpoint_root"] = a["checkpoint_root"]
    if isinstance(a.get("epoch"), str):
        out["epoch"] = a["epoch"]
    return out or None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="in_path", required=True)
    ap.add_argument("--catalog", default=str(ROOT / "threat_catalog.json"))
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    obj = load_json(args.in_path)
    catalog = load_json(args.catalog)

    # Reuse the reference logic from the conformance harness.
    import threat_conformance_ref as tcr  # local import

    feats = tcr.infer_features(obj)
    mitigated, open_ = tcr.evaluate_catalog(feats, catalog)
    L, D = tcr.grades_from_features(feats, obj)

    created_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

    subj_kind = infer_subject_kind(obj)
    subj_digest = sha256_pref(jcs(obj))

    # Bind semantics where available.
    pol = ""
    res = ""
    if isinstance(obj, dict):
        pol = str(obj.get("policy_nf_digest", ""))
        res = str(obj.get("resolver_id", ""))

    tpv: Dict[str, Any] = {
        "type": "docf.threat_posture_vector",
        "version": "v0",
        "created_at": created_at,
        "subject": {
            "kind": subj_kind,
            "digest": subj_digest,
        },
        "catalog_digest": sha256_pref(jcs(catalog)),
        "mitigated": mitigated,
        "open": open_,
        "grades": {"L": L, "D": D},
        "policy_nf_digest": pol,
        "resolver_id": res,
    }

    anchor = infer_anchor(obj)
    if anchor is not None:
        tpv["anchor"] = anchor

    # Optional: commit to a full conformance report digest.
    report = {
        "format": "docf-threat-conformance-report-v0",
        "created_at": created_at,
        "input": {"path": args.in_path, "digest": subj_digest},
        "catalog_digest": tpv["catalog_digest"],
        "features": sorted(list(feats)),
        "mitigated": mitigated,
        "open": open_,
        "grades": {"L": L, "D": D},
    }
    tpv["report_digest"] = sha256_pref(jcs(report))

    Path(args.out).write_text(json.dumps(tpv, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
