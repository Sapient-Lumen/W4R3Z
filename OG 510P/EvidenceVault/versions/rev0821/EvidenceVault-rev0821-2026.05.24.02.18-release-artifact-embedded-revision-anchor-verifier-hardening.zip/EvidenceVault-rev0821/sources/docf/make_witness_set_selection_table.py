#!/usr/bin/env python3
"""make_witness_set_selection_table.py

Generate a small table showing witness-set construction under a correlation budget.

- Candidate pool: `test_vectors/witness_candidate_pool_demo.json`
- Selection algorithm: greedy min-max rho_hat (operator + region domains)
- Policy budget: exchangeable Beta–Binomial ICC model with split-view dual-accept budget.

Outputs:
  - `test_vectors/witness_set_selection_results.json`
  - `_insert_witness_set_selection_table.tex`
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import witness_set_optimizer_ref as wsel


def log_beta(a: float, b: float) -> float:
    return math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)


def beta_binom_pmf(m: int, k: int, alpha: float, beta: float) -> float:
    return math.comb(m, k) * math.exp(log_beta(alpha + k, beta + m - k) - log_beta(alpha, beta))


def hypergeom_pmf(N: int, K: int, n: int, k: int) -> float:
    if k < 0 or k > n or k > K or (n - k) > (N - K):
        return 0.0
    return (math.comb(K, k) * math.comb(N - K, n - k)) / math.comb(N, n)


def dual_accept_prob_given_K(m: int, t: int, g: int, K: int) -> float:
    lo = max(0, t - (m - g))
    hi = min(g, K + g - t)
    if lo > hi:
        return 0.0
    return sum(hypergeom_pmf(m, K, g, kA) for kA in range(lo, hi + 1))


def compute_probs(m: int, t: int, q: float, rho: float):
    g = m // 2

    if rho <= 0.0:
        pD = 0.0
        for K in range(0, m + 1):
            pK = math.comb(m, K) * (q**K) * ((1 - q) ** (m - K))
            pD += pK * dual_accept_prob_given_K(m, t, g, K)
        return pD

    s = (1.0 / rho) - 1.0
    alpha = max(1e-12, q * s)
    beta = max(1e-12, (1.0 - q) * s)

    pD = 0.0
    for K in range(0, m + 1):
        pK = beta_binom_pmf(m, K, alpha, beta)
        pD += pK * dual_accept_prob_given_K(m, t, g, K)
    return pD


def max_rho_for_budget(m: int, t: int, q: float, budget_dual: float) -> float | None:
    # If even rho=0 exceeds budget, no correlation level can satisfy this budget.
    if compute_dual_accept(m, t, q, 0.0) > budget_dual:
        return None

    lo, hi = 0.0, 0.999
    for _ in range(70):
        mid = (lo + hi) / 2
        pD = compute_probs(m, t, q, mid)
        if pD <= budget_dual:
            lo = mid
        else:
            hi = mid
    return lo


def tex_escape(s: str) -> str:
    return s.replace('_', '\\_')


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--pool', default='test_vectors/witness_candidate_pool_demo.json')
    ap.add_argument('--m', type=int, default=7)
    ap.add_argument('--t', type=int, default=6)
    ap.add_argument('--q', type=float, default=0.12)
    ap.add_argument('--domains', default='operator,region')
    ap.add_argument('--out_json', default='test_vectors/witness_set_selection_results.json')
    ap.add_argument('--out_tex', default='_insert_witness_set_selection_table.tex')
    args = ap.parse_args()

    domains = [x.strip() for x in args.domains.split(',') if x.strip()]

    # Deterministic selection.
    pool_obj = json.loads(Path(args.pool).read_text(encoding='utf-8'))
    selection = wsel.greedy_select(pool_obj.get('witnesses', []), args.m, domains)

    budgets = [6, 8, 10, 12]
    rows = []
    for k in budgets:
        budget_dual = 2.0 ** (-k)
        rho_max = max_rho_for_budget(args.m, args.t, args.q, budget_dual)
        rho_hat = float(selection['rho_hat'])
        if rho_max is None:
            decision = 'reject'
        else:
            decision = 'accept' if rho_hat <= rho_max else 'reject'
        rows.append({
            'budget_dual_bits': k,
            'rho_max': (None if rho_max is None else float(f"{rho_max:.6g}")),
            'rho_hat': rho_hat,
            'decision': decision,
        })

    out = {
        'type': 'docf_witness_set_selection_results_v0',
        'params': {'m': args.m, 't': args.t, 'q': args.q, 'domains': domains},
        'selection': selection,
        'budgets': rows,
    }
    Path(args.out_json).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out_json).write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding='utf-8')

    # LaTeX table.
    ids = ','.join(selection['selected_witness_ids'])
    ids_short = (ids[:70] + '…') if len(ids) > 72 else ids

    tex = []
    tex.append('\\begin{table}[t]')
    tex.append('\\centering')
    tex.append('\\small')
    tex.append('\\begin{tabular}{r r r l}')
    tex.append('\\toprule')
    tex.append('Budget bits $k$ & $\\rho_{\\max}$ & $\\hat\\rho$ (selected) & decision \\\\')
    tex.append('\\midrule')
    for r in rows:
        tex.append(f"{r['budget_dual_bits']} & {r['rho_max']:.4g} & {r['rho_hat']:.4g} & {r['decision']} \\\\")
    tex.append('\\midrule')
    tex.append('\\multicolumn{4}{l}{Selected witness IDs (greedy): ' + tex_escape(ids_short) + '} \\\\')
    tex.append('\\bottomrule')
    tex.append('\\end{tabular}')
    tex.append('\\caption{Toy witness-set construction under a split-view correlation budget. We select $m=7$ witnesses to minimize $\\hat\\rho$ over (operator, region) domains, then evaluate accept/reject for budgets $2^{-k}$ using the exchangeable Beta--Binomial model (with $q=0.12$, threshold $t=6$).}')
    tex.append('\\label{tab:witness_set_selection}')
    tex.append('\\end{table}')

    Path(args.out_tex).write_text('\n'.join(tex) + '\n', encoding='utf-8')


if __name__ == '__main__':
    main()
