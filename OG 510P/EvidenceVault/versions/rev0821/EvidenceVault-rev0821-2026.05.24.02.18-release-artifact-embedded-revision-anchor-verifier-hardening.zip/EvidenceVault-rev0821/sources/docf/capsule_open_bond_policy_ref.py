#!/usr/bin/env python3
"""capsule_open_bond_policy_ref.py

Reference helper for anti-griefing parameters in the capsule opening dispute.

Goal: deter spam challenges that force repeated selective-disclosure openings.
We model verifier/proposer work as proportional to the number of SHA-256 node
hashes required to check an opening.

Toy work models (complete binary tree with n padded to power-of-two):
  - audit_paths / dense_compact_worst: k * log2(n)
  - dense_compact_contig_upper: min(k*log2(n), 2*log2(n))  (two-boundary range proof)
  - dense_compact_contig_expected: log2(n) (good approximation when k << n)

The contig models correspond to "lexicographic path clustering": required paths
appear as a contiguous block in the capsule's leaf order (e.g., capsule leaves are
sorted by path and required fields live in a tight namespace).

Bond policy pins two knobs:
  - B_min: minimum bond per challenge
  - alpha_per_hash: bond per hash work unit

Minimum bond:
  B_open >= max(B_min, alpha_per_hash * work_hashes(k, n_padded))

This mirrors optimistic-protocol practice where challengers post bonds and lose
them on unsuccessful challenges, deterring griefing.

Commands:
  emit-demo               -> print a demo policy JSON
  min-bond --policy P --k 4 --leaf-count 1024

All units are abstract; deployments bind them to a bond asset and a settlement
mechanism.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from typing import Any, Dict


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest_sha256(obj: Any) -> str:
    return hashlib.sha256(canonical_json(obj).encode("utf-8")).hexdigest()


def n_padded(leaf_count: int) -> int:
    n = 1
    while n < max(1, int(leaf_count)):
        n *= 2
    return n


def work_hashes(k: int, leaf_count: int, model: str = "audit_paths") -> int:
    n = n_padded(leaf_count)
    h = int(math.log2(n))
    k = int(k)
    if k <= 0:
        return 0

    if model in ("audit_paths", "dense_compact_worst"):
        return k * h

    if model == "dense_compact_contig_upper":
        # Two-boundary range proofs in complete trees never exceed ~2h sibling hashes.
        # For k=1 the exact cost is h.
        if k == 1:
            return h
        return min(k * h, 2 * h)

    if model == "dense_compact_contig_expected":
        # When k is small relative to n, E[popcount(a)+popcount(N-(a+k))] ≈ h.
        # This is an aggressive pricing mode; deployments should enable it only
        # when required paths are forced to cluster by the capsule schema/order.
        return h

    return k * h


def min_bond(policy: Dict[str, Any], k: int, leaf_count: int) -> float:
    B_min = float(policy.get("B_min", 0.0))
    alpha = float(policy.get("alpha_per_hash", 0.0))
    model = str(policy.get("work_model", "audit_paths"))
    w = work_hashes(k, leaf_count, model=model)
    return max(B_min, alpha * float(w))


def demo_policy() -> Dict[str, Any]:
    pol = {
        "type": "docf_capsule_open_bond_policy_v0",
        "policy_id": "bondpolicy:v0:hash_work",
        "B_min": 0.01,
        "alpha_per_hash": 0.0002,
        "work_model": "dense_compact_contig_upper",
        "notes": "Demo: bond proportional to SHA-256 work for verifying k openings in a complete Merkle tree (padded to power-of-two).",
    }
    pol["digest_sha256"] = digest_sha256({k: v for k, v in pol.items() if k != "digest_sha256"})
    return pol


def load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def main() -> None:
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)

    sp.add_parser("emit-demo")

    mb = sp.add_parser("min-bond")
    mb.add_argument("--policy", required=True)
    mb.add_argument("--k", type=int, required=True)
    mb.add_argument("--leaf-count", type=int, required=True)

    args = ap.parse_args()

    if args.cmd == "emit-demo":
        print(json.dumps(demo_policy(), indent=2, sort_keys=True))
        return

    if args.cmd == "min-bond":
        pol = load_json(args.policy)
        model = str(pol.get("work_model", "audit_paths"))
        out = {
            "k": args.k,
            "leaf_count": args.leaf_count,
            "n_padded": n_padded(args.leaf_count),
            "work_model": model,
            "work_hashes": work_hashes(args.k, args.leaf_count, model=model),
            "min_bond": min_bond(pol, args.k, args.leaf_count),
            "policy_digest_sha256": digest_sha256({k: v for k, v in pol.items() if k != "digest_sha256"}),
        }
        print(json.dumps(out, indent=2, sort_keys=True))
        return


if __name__ == "__main__":
    main()
