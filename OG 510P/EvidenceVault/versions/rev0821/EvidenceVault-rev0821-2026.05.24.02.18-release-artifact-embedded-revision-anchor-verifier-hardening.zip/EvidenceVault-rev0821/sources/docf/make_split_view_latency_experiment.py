#!/usr/bin/env python3
"""make_split_view_latency_experiment.py

Split-view (equivocation) detection latency experiment for Paper F/G.

We model an adversarial *partition* split view:
  - A subset of witnesses initially sees checkpoint A
  - The complement initially sees checkpoint B
  - Without witness-to-witness gossip, no witness observes both views -> no detection.
  - With witness gossip, views propagate across the partition and are detected.

We measure:
  - p_dual_quorum: probability both views can obtain t-of-m witness cosignatures
  - detection time: time until *any* witness observes both views
  - exposure window (conditional on dual quorum): time between when the *second* quorum is achieved
    and when any witness detects equivocation.

The simulation is deliberately lightweight and uses exponential message delays
(unit mean unless otherwise specified). It is not a network model; it is a
replayable, parameterizable *toy* that makes the split-view failure mode and
witness/gossip knobs concrete.

Outputs:
  - test_vectors/pct_split_view_latency_results.json
  - LaTeX inserts:
      _insert_split_view_latency_table.tex
      _insert_split_view_latency_scaling_table.tex
  - Figures:
      pct_split_view_detect_cdf.pdf
      pct_split_view_window_cdf.pdf
"""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def _dijkstra_multi_source(t_init: np.ndarray, D: np.ndarray) -> np.ndarray:
    """Earliest-arrival times with multiple starting nodes.

    t_init[i] is the time node i first has the item (may be inf).
    D[u,v] is the message delay from u to v once u has the item.
    """
    m = len(t_init)
    t = t_init.copy()
    visited = np.zeros(m, dtype=bool)
    for _ in range(m):
        u = -1
        best = np.inf
        for i in range(m):
            if not visited[i] and t[i] < best:
                best = t[i]
                u = i
        if u == -1 or best == np.inf:
            break
        visited[u] = True
        for v in range(m):
            if visited[v]:
                continue
            cand = t[u] + D[u, v]
            if cand < t[v]:
                t[v] = cand
    return t


def _simulate_partition(
    *,
    trials: int,
    m: int,
    t: int,
    n_clients: int,
    fanout: int,
    pA: float,
    gossip: bool,
    gossip_rate: float,
    seed: int,
) -> Tuple[Dict, np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    gA = max(1, min(m - 1, m // 2))  # adversary partitions witnesses
    groupA = list(range(gA))
    groupB = list(range(gA, m))

    dual = 0
    dets: List[float] = []
    windows: List[float] = []

    for _ in range(trials):
        nA = int(round(n_clients * pA))
        nB = n_clients - nA

        kA = np.zeros(m, dtype=int)
        kB = np.zeros(m, dtype=int)

        # view A only reaches groupA, view B only reaches groupB initially
        if nA * fanout > 0:
            kA_group = rng.multinomial(nA * fanout, [1 / len(groupA)] * len(groupA))
            for idx, c in zip(groupA, kA_group):
                kA[idx] = c
        if nB * fanout > 0:
            kB_group = rng.multinomial(nB * fanout, [1 / len(groupB)] * len(groupB))
            for idx, c in zip(groupB, kB_group):
                kB[idx] = c

        tA_direct = np.full(m, np.inf)
        tB_direct = np.full(m, np.inf)
        for i in range(m):
            if kA[i] > 0:
                tA_direct[i] = rng.exponential(1.0 / kA[i])  # min of k Exp(1)
            if kB[i] > 0:
                tB_direct[i] = rng.exponential(1.0 / kB[i])

        if gossip:
            D = rng.exponential(1.0 / gossip_rate, size=(m, m))
            np.fill_diagonal(D, 0.0)
            tA = _dijkstra_multi_source(tA_direct, D)
            tB = _dijkstra_multi_source(tB_direct, D)
        else:
            tA = tA_direct
            tB = tB_direct

        # detection time: earliest witness with both views
        det = np.inf
        for i in range(m):
            if np.isfinite(tA[i]) and np.isfinite(tB[i]):
                det = min(det, max(tA[i], tB[i]))
        if np.isfinite(det):
            dets.append(float(det))

        # who cosigns which view (honest witness signs the first view it sees at this tree size)
        signA: List[float] = []
        signB: List[float] = []
        for i in range(m):
            if tA[i] < tB[i] and np.isfinite(tA[i]):
                signA.append(float(tA[i]))
            elif tB[i] < tA[i] and np.isfinite(tB[i]):
                signB.append(float(tB[i]))
        signA.sort()
        signB.sort()
        accA = np.inf
        accB = np.inf
        if len(signA) >= t:
            accA = signA[t - 1]
        if len(signB) >= t:
            accB = signB[t - 1]

        if np.isfinite(accA) and np.isfinite(accB):
            dual += 1
            if np.isfinite(det):
                # exposure window starts when the *second* quorum is assembled
                windows.append(max(0.0, float(det) - max(accA, accB)))
            else:
                windows.append(np.inf)

    res = {
        "params": {
            "trials": trials,
            "m": m,
            "t": t,
            "partition_groupA": gA,
            "n_clients": n_clients,
            "fanout": fanout,
            "pA": pA,
            "gossip": gossip,
            "gossip_rate": gossip_rate,
            "seed": seed,
        },
        "p_dual_quorum": dual / trials,
        "det_p50": float(np.percentile(dets, 50)) if dets else None,
        "det_p95": float(np.percentile(dets, 95)) if dets else None,
        "window_p50_cond_dual": float(np.percentile([w for w in windows if np.isfinite(w)], 50))
        if any(np.isfinite(w) for w in windows)
        else None,
        "window_p95_cond_dual": float(np.percentile([w for w in windows if np.isfinite(w)], 95))
        if any(np.isfinite(w) for w in windows)
        else None,
        "window_p_inf_cond_dual": float(sum(not np.isfinite(w) for w in windows) / len(windows)) if windows else None,
        "n_dual": int(len(windows)),
    }
    return res, np.array(dets, dtype=float), np.array([w for w in windows if np.isfinite(w)], dtype=float)


def _latex_escape(s: str) -> str:
    return s.replace("_", "\\_")


def main() -> None:
    root = Path(__file__).resolve().parent
    out_json = root / "test_vectors" / "pct_split_view_latency_results.json"
    out_json.parent.mkdir(parents=True, exist_ok=True)

    # Canonical experiment parameters
    trials = 10000
    n_clients = 40
    fanout = 1
    pA = 0.5

    # Table 1: m=7, policy x gossip
    m = 7
    policies = [
        ("t=1 (no quorum)", 1),
        ("majority", m // 2 + 1),
        ("2/3", math.ceil(2 * m / 3)),
    ]
    rows = []
    # collect arrays for CDF plots (canonical: t=1, gossip on, vary gossip_rate)
    cdf_series = []

    for label, t in policies:
        for gossip in [False, True]:
            res, dets, windows = _simulate_partition(
                trials=trials,
                m=m,
                t=t,
                n_clients=n_clients,
                fanout=fanout,
                pA=pA,
                gossip=gossip,
                gossip_rate=1.0,
                seed=1234 + t + (10 if gossip else 0),
            )
            rows.append({
                "policy": label,
                "m": m,
                "t": t,
                "gossip": "on" if gossip else "off",
                "p_dual": res["p_dual_quorum"],
                "det_p50": res["det_p50"],
                "det_p95": res["det_p95"],
                "win_p50": res["window_p50_cond_dual"],
                "win_p95": res["window_p95_cond_dual"],
                "win_inf": res["window_p_inf_cond_dual"],
            })

    df = pd.DataFrame(rows)

    # Table 2: scaling at t=1 with gossip (detection & exposure vs m)
    scale_rows = []
    for m2 in [3, 5, 7, 9, 11]:
        res, dets, windows = _simulate_partition(
            trials=trials,
            m=m2,
            t=1,
            n_clients=n_clients,
            fanout=fanout,
            pA=pA,
            gossip=True,
            gossip_rate=1.0,
            seed=9000 + m2,
        )
        scale_rows.append({
            "m": m2,
            "partition": m2 // 2,
            "det_p50": res["det_p50"],
            "det_p95": res["det_p95"],
            "win_p50": res["window_p50_cond_dual"],
            "win_p95": res["window_p95_cond_dual"],
            "p_dual": res["p_dual_quorum"],
        })
    df_scale = pd.DataFrame(scale_rows)

    # CDF plots (m=7, t=1, gossip on, vary gossip_rate)
    det_cdfs = []
    win_cdfs = []
    for rate in [0.5, 1.0, 2.0]:
        res, dets, windows = _simulate_partition(
            trials=trials,
            m=7,
            t=1,
            n_clients=n_clients,
            fanout=fanout,
            pA=pA,
            gossip=True,
            gossip_rate=rate,
            seed=int(5000 * rate),
        )
        det_cdfs.append((rate, dets))
        win_cdfs.append((rate, windows))

    # write JSON
    payload = {
        "table_m7": rows,
        "table_scaling_t1": scale_rows,
        "cdf_det_m7_t1": [{"gossip_rate": r, "dets": d.tolist()[:5000]} for (r, d) in det_cdfs],
        "cdf_window_m7_t1": [{"gossip_rate": r, "windows": w.tolist()[:5000]} for (r, w) in win_cdfs],
        "meta": {"trials": trials, "n_clients": n_clients, "fanout": fanout, "pA": pA},
    }
    out_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    # LaTeX Table 1 (m=7)
    def fmt(x):
        if x is None:
            return "--"
        if isinstance(x, float) and (math.isinf(x) or math.isnan(x)):
            return "$\\infty$"
        return f"{x:.3f}"

    lines = []
    lines.append("% Auto-generated by make_split_view_latency_experiment.py")
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append("\\begin{tabular}{l l r r r r}")
    lines.append("\\toprule")
    lines.append("Policy & Gossip & $\\Pr[\\text{dual quorum}]$ & Detect p50 & Detect p95 & Exposure p95 \\\\"
    )
    lines.append("\\midrule")
    for _, r in df.iterrows():
        exposure = r["win_p95"]
        if r["gossip"] == "off":
            det50 = "$\\infty$"
            det95 = "$\\infty$"
            exp95 = "$\\infty$" if r["p_dual"] > 0.0 else "--"
        else:
            det50 = fmt(r["det_p50"])
            det95 = fmt(r["det_p95"])
            exp95 = fmt(exposure) if r["p_dual"] > 0.0 else "--"
        lines.append(
            f"{_latex_escape(r['policy'])} & {r['gossip']} & {r['p_dual']:.3f} & {det50} & {det95} & {exp95} \\\\"
        )
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\caption{Partition split-view toy model (m=7 witnesses, group sizes 3/4, 10k trials). "
                 "Without witness gossip, an adversary can sustain split views indefinitely when clients accept t=1 cosigs. "
                 "With gossip, equivocation is detected quickly. With majority or 2/3 quorums, dual acceptance is impossible in this partition.}")
    lines.append("\\label{tab:split_view_latency}")
    lines.append("\\end{table}")
    (root / "_insert_split_view_latency_table.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")

    # LaTeX Table 2 (scaling)
    lines = []
    lines.append("% Auto-generated by make_split_view_latency_experiment.py")
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append("\\begin{tabular}{r r r r r r}")
    lines.append("\\toprule")
    lines.append("$m$ & partition & $\\Pr[\\text{dual}]$ & Detect p50 & Detect p95 & Exposure p95 \\\\"
    )
    lines.append("\\midrule")
    for _, r in df_scale.iterrows():
        lines.append(f"{int(r['m'])} & {int(r['partition'])}/{int(r['m'])-int(r['partition'])} & {r['p_dual']:.3f} & {fmt(r['det_p50'])} & {fmt(r['det_p95'])} & {fmt(r['win_p95'])} \\\\"
        )
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\caption{Scaling in the same partition model with gossip enabled and a weak t=1 policy. "
                 "Even modest witness fanout plus gossip yields sub-unit median detection and small exposure windows in this toy setup.}")
    lines.append("\\label{tab:split_view_scaling}")
    lines.append("\\end{table}")
    (root / "_insert_split_view_latency_scaling_table.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")

    # Figures (CDFs)
    def plot_cdf(series: List[Tuple[float, np.ndarray]], xlabel: str, outpath: Path):
        plt.figure()
        for rate, arr in series:
            if len(arr) == 0:
                continue
            x = np.sort(arr)
            y = np.arange(1, len(x) + 1) / len(x)
            plt.plot(x, y, label=f"gossip rate={rate}")
        plt.xlabel(xlabel)
        plt.ylabel("CDF")
        plt.legend()
        plt.tight_layout()
        plt.savefig(outpath)
        plt.close()

    plot_cdf(det_cdfs, "Detection time (toy units)", root / "pct_split_view_detect_cdf.pdf")
    plot_cdf(win_cdfs, "Exposure window (toy units)", root / "pct_split_view_window_cdf.pdf")


if __name__ == "__main__":
    main()
