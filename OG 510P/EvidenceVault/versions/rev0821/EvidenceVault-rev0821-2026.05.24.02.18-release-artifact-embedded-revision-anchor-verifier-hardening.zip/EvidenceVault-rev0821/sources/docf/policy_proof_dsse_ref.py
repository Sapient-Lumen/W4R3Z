#!/usr/bin/env python3
"""
policy_proof_dsse_ref.py

Deterministic DSSE wrapper for a docf-policy-proof-v0 payload using Ed25519.

- `--emit` prints the demo DSSE envelope (matches test_vectors/policy_proof_dsse_demo.json).
- `--verify <dsse_json>` verifies the signature and decodes the payload.

This is a reference sketch for paper examples; it is not hardened.
"""
from __future__ import annotations

import argparse, base64, json, sys
from typing import Any, Dict

from docf_ref_tools_common import jcs, sha256_hex, emit_json

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
    from cryptography.hazmat.primitives import serialization
except Exception as e:
    Ed25519PrivateKey = None  # type: ignore

PAYLOAD_TYPE = "application/vnd.docf.policy-proof.v0+json"
KEYID = "docf-test-ed25519-k0"
PRIV_BYTES = bytes.fromhex("11" * 32)

def pae(payload_type: str, payload: bytes) -> bytes:
    # DSSE v1 PAE: b"DSSEv1 " + len(type) + b" " + type + b" " + len(payload) + b" " + payload
    return b"DSSEv1 " + str(len(payload_type)).encode() + b" " + payload_type.encode() + b" " + str(len(payload)).encode() + b" " + payload

def demo_payload() -> Dict[str, Any]:
    # Keep in sync with test_vectors/policy_proof_demo.json
    return {
      "type":"docf-policy-proof-v0",
      "version":0,
      "created_at":"2026-02-24T16:10:00Z",
      "verifier":{
        "id":"docf-policy-proof-ref/v0",
        "audit_bundle_verifier":"audit_bundle_ref.verify_audit_bundle",
        "jcs":"RFC8785-safe-subset",
        "verifier_code_digest_sha256":"0c2f"*16
      },
      "subject":{
        "bundle_digest_sha256":"1f1a8242"*8,
        "policy_id":"alpha_allow",
        "sid":"duplicate-sid-demo"
      },
      "verdict":"ACCEPT",
      "reasons":[],
      "observed":{
        "bundle_version":1,
        "stapled_policy_digest_sha256":"d98e3045"*8
      }
    }

def sign_dsse(payload_obj: Dict[str, Any]) -> Dict[str, Any]:
    if Ed25519PrivateKey is None:
        raise RuntimeError("cryptography not available; cannot sign")
    priv = Ed25519PrivateKey.from_private_bytes(PRIV_BYTES)
    pub = priv.public_key()
    pub_raw = pub.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)

    payload_bytes = jcs(payload_obj)
    # include self-digest inside payload (deterministic)
    payload_obj2 = dict(payload_obj)
    payload_obj2["digest"] = {"sha256": sha256_hex(jcs(payload_obj))}
    payload_bytes = jcs(payload_obj2)

    sig = priv.sign(pae(PAYLOAD_TYPE, payload_bytes))
    return {
      "payloadType": PAYLOAD_TYPE,
      "payload": base64.b64encode(payload_bytes).decode("ascii"),
      "signatures": [{
        "keyid": KEYID,
        "alg": "ed25519",
        "sig": base64.b64encode(sig).decode("ascii")
      }],
      "public_key_ed25519_raw_b64": base64.b64encode(pub_raw).decode("ascii")
    }

def verify_dsse(dsse: Dict[str, Any]) -> Dict[str, Any]:
    if Ed25519PublicKey is None:
        raise RuntimeError("cryptography not available; cannot verify")
    if dsse.get("payloadType") != PAYLOAD_TYPE:
        raise ValueError("unexpected payloadType")
    payload_bytes = base64.b64decode(dsse["payload"])
    sig0 = dsse["signatures"][0]
    sig = base64.b64decode(sig0["sig"])
    pub_raw = base64.b64decode(dsse["public_key_ed25519_raw_b64"])
    pub = Ed25519PublicKey.from_public_bytes(pub_raw)
    pub.verify(sig, pae(PAYLOAD_TYPE, payload_bytes))
    return json.loads(payload_bytes.decode("utf-8"))

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit", action="store_true", help="emit deterministic demo DSSE envelope")
    ap.add_argument("--verify", type=str, default="", help="verify a DSSE JSON file")
    args = ap.parse_args()

    if args.emit:
        env = sign_dsse(demo_payload())
        emit_json(env)
        return

    if args.verify:
        with open(args.verify, "r", encoding="utf-8") as f:
            dsse = json.load(f)
        payload = verify_dsse(dsse)
        emit_json(payload)
        return

    ap.print_help()

if __name__ == "__main__":
    main()
