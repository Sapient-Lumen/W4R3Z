#!/usr/bin/env python3
"""tpv_gate_satisfaction_ref.py

Produce a Gate Satisfaction Object (GSO) for a (TPV, gate policy) pair.

A GSO is designed to be stapled into acceptance workflows and/or logged
in transparency services (e.g., as a SCITT statement committing to the
GSO digest). The key point is semantic pinning:
  - gate_policy_nf_digest binds the *meaning* of the gate (GNF)
  - gate_policy_digest binds the exact policy bytes
  - tpv_digest binds the posture disclosure
  - gate_eval_digest binds the fail-closed evaluation trace

Usage:
  python3 tpv_gate_satisfaction_ref.py \
    --tpv test_vectors/threat_posture_vector_pao_demo.json \
    --policy test_vectors/tpv_gate_policy_demo.json \
    --out test_vectors/tpv_gate_satisfaction_demo.json \
    --created_at 2026-02-26T00:00:00Z \
    --anchor-log-id rekor.sigstore.dev \
    --anchor-checkpoint-root sha256:deadbeef \
    --anchor-epoch 12345

The produced object is intentionally minimal and illustrative.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List

from docf_ref_tools_common import jcs, load_json


def sha256_pref(b: bytes) -> str:
    return "sha256:" + hashlib.sha256(b).hexdigest()


def uniq_sorted(xs: Any) -> List[str]:
    if not isinstance(xs, list):
        return []
    return sorted({str(x) for x in xs})


def norm_allowlist(xs: Any) -> List[str]:
    out = uniq_sorted(xs)
    if "*" in out:
        return ["*"]
    return out


def as_set(x: Any) -> set:
    if isinstance(x, list):
        return set(str(v) for v in x)
    return set()


def match_any(allowed: List[str], value: str) -> bool:
    if not isinstance(allowed, list) or len(allowed) == 0:
        return False
    if "*" in allowed:
        return True
    return value in allowed


def gate_gnf(policy: Dict[str, Any]) -> Dict[str, Any]:
    max_open = policy.get("max_open", "inf")
    if isinstance(max_open, int):
        max_open_nf: Any = int(max_open)
    else:
        max_open_nf = "inf"

    nf: Dict[str, Any] = {
        "type": "docf.tpv_gate_policy_nf",
        "version": "v0",
        "created_at": "",
        "policy_id": str(policy.get("policy_id", "")),
        "catalog_digest": str(policy.get("catalog_digest", "")),
        "require_resolver_id": norm_allowlist(policy.get("require_resolver_id", [])),
        "require_policy_nf_digest": norm_allowlist(policy.get("require_policy_nf_digest", [])),
        "min_L": int(policy.get("min_L", 0)),
        "min_D": int(policy.get("min_D", 0)),
        "require_mitigated": uniq_sorted(policy.get("require_mitigated", [])),
        "forbid_open": uniq_sorted(policy.get("forbid_open", [])),
        "max_open": max_open_nf,
    }
    nf.pop("created_at", None)
    return nf


def eval_gate(tpv: Dict[str, Any], pol: Dict[str, Any]) -> Dict[str, Any]:
    reasons: List[str] = []

    if not (isinstance(tpv, dict) and tpv.get("type") == "docf.threat_posture_vector"):
        reasons.append("tpv.type mismatch or not an object")
    if not (isinstance(pol, dict) and pol.get("type") == "docf.tpv_gate_policy"):
        reasons.append("policy.type mismatch or not an object")

    # Extract required fields fail-closed.
    tpv_catalog = str(tpv.get("catalog_digest", ""))
    tpv_resolver = str(tpv.get("resolver_id", ""))
    tpv_pnf = str(tpv.get("policy_nf_digest", ""))
    grades = tpv.get("grades", {})
    tpv_L = int(grades.get("L", -1)) if isinstance(grades, dict) else -1
    tpv_D = int(grades.get("D", -1)) if isinstance(grades, dict) else -1

    pol_catalog = str(pol.get("catalog_digest", ""))
    pol_allow_res = pol.get("require_resolver_id", [])
    pol_allow_pnf = pol.get("require_policy_nf_digest", [])
    pol_min_L = int(pol.get("min_L", 0))
    pol_min_D = int(pol.get("min_D", 0))
    pol_req_mit = as_set(pol.get("require_mitigated", []))
    pol_forbid_open = as_set(pol.get("forbid_open", []))
    pol_max_open = pol.get("max_open", None)

    # Catalog binding.
    if pol_catalog != "*" and pol_catalog != tpv_catalog:
        reasons.append("catalog_digest mismatch")

    # Semantic binding.
    if not match_any(pol_allow_res, tpv_resolver):
        reasons.append("resolver_id not allowed")
    if not match_any(pol_allow_pnf, tpv_pnf):
        reasons.append("policy_nf_digest not allowed")

    # Grade thresholds.
    if tpv_L < pol_min_L:
        reasons.append(f"L grade too low: {tpv_L} < {pol_min_L}")
    if tpv_D < pol_min_D:
        reasons.append(f"D grade too low: {tpv_D} < {pol_min_D}")

    mitigated = as_set(tpv.get("mitigated", []))
    open_ = as_set(tpv.get("open", []))

    missing = sorted(list(pol_req_mit - mitigated))
    if missing:
        reasons.append("missing required mitigations: " + ",".join(missing))

    bad_open = sorted(list(pol_forbid_open & open_))
    if bad_open:
        reasons.append("forbidden open threats present: " + ",".join(bad_open))

    if isinstance(pol_max_open, int):
        if len(open_) > pol_max_open:
            reasons.append(f"too many open threats: {len(open_)} > {pol_max_open}")

    result = "accept" if len(reasons) == 0 else "reject"

    out: Dict[str, Any] = {
        "type": "docf.tpv_gate_eval",
        "version": "v0",
        "created_at": "",
        "policy_id": str(pol.get("policy_id", "")),
        "tpv_digest": sha256_pref(jcs(tpv)),
        "policy_digest": sha256_pref(jcs(pol)),
        "result": result,
        "reasons": reasons,
    }
    if isinstance(tpv.get("subject"), dict):
        out["tpv_subject"] = tpv["subject"]

    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tpv", required=True)
    ap.add_argument("--policy", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--created_at", default="2026-02-26T00:00:00Z")
    ap.add_argument("--anchor-log-id", default="")
    ap.add_argument("--anchor-checkpoint-root", default="")
    ap.add_argument("--anchor-epoch", default="")
    args = ap.parse_args()

    tpv = load_json(args.tpv)
    pol = load_json(args.policy)

    gnf = gate_gnf(pol)
    gate_policy_nf_digest = sha256_pref(jcs(gnf))
    gate_policy_digest = sha256_pref(jcs(pol))
    tpv_digest = sha256_pref(jcs(tpv))

    gate_eval = eval_gate(tpv, pol)
    gate_eval["created_at"] = args.created_at
    gate_eval_digest = sha256_pref(jcs(gate_eval))

    gso: Dict[str, Any] = {
        "type": "docf.tpv_gate_satisfaction",
        "version": "v0",
        "created_at": args.created_at,
        "gate_policy_nf_digest": gate_policy_nf_digest,
        "gate_policy_digest": gate_policy_digest,
        "tpv_digest": tpv_digest,
        "gate_eval_digest": gate_eval_digest,
        "result": str(gate_eval.get("result", "reject")),
        "reasons": gate_eval.get("reasons", []),
    }

    if isinstance(tpv.get("subject"), dict):
        gso["tpv_subject"] = tpv["subject"]

    if args.anchor_log_id or args.anchor_checkpoint_root or args.anchor_epoch:
        gso["anchor"] = {
            "log_id": args.anchor_log_id,
            "checkpoint_root": args.anchor_checkpoint_root,
            "epoch": args.anchor_epoch,
        }

    Path(args.out).write_text(json.dumps(gso, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    # Emit companion eval next to output for convenience.
    eval_path = Path(args.out).with_name(Path(args.out).stem + "_gate_eval.json")
    eval_path.write_text(json.dumps(gate_eval, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
