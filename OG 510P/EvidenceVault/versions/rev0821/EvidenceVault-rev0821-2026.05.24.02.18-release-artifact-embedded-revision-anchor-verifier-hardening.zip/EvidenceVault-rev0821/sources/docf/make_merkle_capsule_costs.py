#!/usr/bin/env python3
"""make_merkle_capsule_costs.py

Regenerates:
  - _insert_merkle_capsule_sizes.tex
  - figures/merkle_capsule_proof_sizes.pdf

Updates the cost model in Paper D to include a *canonical compact multiproof* for
complete (padded) Merkle trees, alongside prior sparse-map multiproof metadata costs.

We model payload sizes using:
  - 32 bytes per hash
  - 32 bytes per 256-bit index (for sparse-map key / position metadata)

For the complete-tree compact multiproof, proof length (hash count) depends only
on the set of opened leaf indices.

This revision adds a second regime motivated by "lexicographic path clustering":
when the k opened fields are contiguous in the leaf order (e.g., required fields
live in a tight path namespace and the capsule is sorted by path), the sibling-
hash count admits a closed form for complete trees:

  hashes([a,a+k)) = popcount(a) + popcount(N-(a+k)),  where N=2^h.

We report an average over random contiguous blocks (uniform start a).
"""

from __future__ import annotations

import math
import os
import random
from dataclasses import dataclass
from typing import List, Tuple

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


HASH_BYTES = 32
INDEX_BYTES_256 = 32


def n_padded(leaf_count: int) -> int:
    n = 1
    while n < leaf_count:
        n *= 2
    return n


def multiproof_hash_count(indices: List[int], leaf_count: int) -> int:
    """Return number of sibling hashes needed for the canonical compact multiproof."""
    n = n_padded(leaf_count)
    h = int(math.log2(n))
    cur = sorted(set(indices))
    cnt = 0
    for _lvl in range(h):
        cur_set = set(cur)
        processed = set()
        nxt = set()
        for idx in cur:
            if idx in processed:
                continue
            sib = idx ^ 1
            if sib not in cur_set:
                cnt += 1
            else:
                processed.add(sib)
            processed.add(idx)
            nxt.add(idx // 2)
        cur = sorted(nxt)
    return cnt


def avg_multiproof_hash_count(k: int, leaf_count: int, trials: int = 2000, seed: int = 1) -> float:
    rng = random.Random(seed + 1000 * k)
    total = 0
    for _ in range(trials):
        idxs = rng.sample(range(leaf_count), k)
        total += multiproof_hash_count(idxs, leaf_count)
    return total / float(trials)


def popcount(x: int) -> int:
    return bin(int(x)).count('1')


def contig_hash_count(a: int, k: int, leaf_count: int) -> int:
    """Closed-form sibling-hash count for a contiguous interval [a, a+k) in a complete tree."""
    N = n_padded(leaf_count)
    if k <= 0 or k >= N:
        return 0
    b = a + k
    return popcount(a) + popcount(N - b)


def avg_contig_hash_count(k: int, leaf_count: int, trials: int = 4000, seed: int = 7) -> float:
    N = n_padded(leaf_count)
    if k <= 0 or k >= N:
        return 0.0
    rng = random.Random(seed + 997 * k)
    total = 0
    for _ in range(trials):
        a = rng.randrange(0, N - k + 1)
        total += contig_hash_count(a, k, leaf_count)
    return total / float(trials)


def fmt_bytes(b: float) -> str:
    if b < 1024:
        return f"{int(round(b))}"
    kib = b / 1024.0
    return f"{int(round(b))} ({kib:.1f} KiB)"


def main() -> None:
    # Parameters matching Paper D's toy comparison.
    leaf_count_dense = 2 ** 20
    h_dense = int(math.log2(n_padded(leaf_count_dense)))

    # Sparse map comparison (height 256).
    h_sparse = 256

    ks = [1, 2, 4, 8, 16, 32]

    rows: List[Tuple[int, float, float, float, int, int]] = []
    # (k, dense_audit_bytes, dense_mp_bytes_avg_random, dense_mp_bytes_avg_contig, sparse_std_bytes, sparse_compact_bytes)

    for k in ks:
        dense_audit = k * h_dense * HASH_BYTES
        avg_hashes_rand = avg_multiproof_hash_count(k, leaf_count_dense, trials=1500)
        dense_mp_rand = avg_hashes_rand * HASH_BYTES

        avg_hashes_contig = avg_contig_hash_count(k, leaf_count_dense, trials=4000)
        dense_mp_contig = avg_hashes_contig * HASH_BYTES

        # sparse: include hashes + (standard) per-hash position metadata OR (compact) leaf indices only
        sparse_hashes = k * h_sparse * HASH_BYTES
        sparse_std = sparse_hashes + k * h_sparse * INDEX_BYTES_256
        sparse_comp = sparse_hashes + k * INDEX_BYTES_256

        rows.append((k, dense_audit, dense_mp_rand, dense_mp_contig, sparse_std, sparse_comp))

    # Write LaTeX table insert.
    out_tex = []
    out_tex.append(r"\begin{table}[t]")
    out_tex.append(r"\centering")
    out_tex.append(r"\begin{tabular}{rrrrrr}")
    out_tex.append(r"\toprule")
    out_tex.append(r"$k$ & Dense list: $k$ audit paths ($n=2^{20}$) & Dense list: compact multiproof (avg, random) & Dense list: compact multiproof (avg, contiguous) & Sparse map: standard multiproof (h=256) & Sparse map: compact multiproof (h=256)\\\\")
    out_tex.append(r"\midrule")
    for k, dense_audit, dense_mp_rand, dense_mp_contig, sparse_std, sparse_comp in rows:
        out_tex.append(f"{k} & {fmt_bytes(dense_audit)} & {fmt_bytes(dense_mp_rand)} & {fmt_bytes(dense_mp_contig)} & {fmt_bytes(sparse_std)} & {fmt_bytes(sparse_comp)}\\\\")
    out_tex.append(r"\bottomrule")
    out_tex.append(r"\end{tabular}")
    out_tex.append(r"\caption{Payload size comparison for opening $k$ capsule fields. Dense list capsules use RFC~6962-style audit paths (20 hashes per field here). Dense list compact multiproofs share overlapping internal nodes; the hash count depends on the revealed indices, so we report two averages: (i) random $k$-subsets, and (ii) contiguous blocks (modeling lexicographically clustered paths under a path-sorted capsule). Sparse map capsules treat field paths as 256-bit indices (sparse Merkle maps);\\cite{CompactSparseMerkleTrees2018} a na\"ive sparse multiproof must attach position metadata to each non-leaf hash, while compact sparse multiproofs transmit only leaf indices plus hashes. Numbers count 32 bytes per hash and 32 bytes per 256-bit index; other overhead (signatures, values) is system-dependent.}")
    out_tex.append(r"\label{tab:merkle_capsule_sizes}")
    out_tex.append(r"\end{table}")

    with open("_insert_merkle_capsule_sizes.tex", "w", encoding="utf-8") as f:
        f.write("\n".join(out_tex) + "\n")

    # Figure
    xs = [k for k, *_ in rows]
    dense_audit_y = [dense_audit / 1024.0 for _, dense_audit, *_ in rows]
    dense_mp_rand_y = [dense_mp_rand / 1024.0 for _, _, dense_mp_rand, *_ in rows]
    dense_mp_contig_y = [dense_mp_contig / 1024.0 for _, _, _, dense_mp_contig, *_ in rows]
    sparse_std_y = [sparse_std / 1024.0 for _, _, _, _, sparse_std, _ in rows]
    sparse_comp_y = [sparse_comp / 1024.0 for _, _, _, _, _, sparse_comp in rows]

    plt.figure(figsize=(6.8, 4.2))
    plt.plot(xs, dense_audit_y, marker='o', label='Dense list: k audit paths')
    plt.plot(xs, dense_mp_rand_y, marker='o', label='Dense list: compact multiproof (avg, random)')
    plt.plot(xs, dense_mp_contig_y, marker='o', label='Dense list: compact multiproof (avg, contiguous)')
    plt.plot(xs, sparse_std_y, marker='o', label='Sparse map: standard multiproof')
    plt.plot(xs, sparse_comp_y, marker='o', label='Sparse map: compact multiproof')
    plt.xscale('log', base=2)
    plt.yscale('log', base=2)
    plt.xlabel('k opened fields')
    plt.ylabel('payload (KiB, hashes+metadata)')
    plt.grid(True, which='both', linestyle='--', linewidth=0.5)
    plt.legend(fontsize=8)
    plt.tight_layout()
    os.makedirs('figures', exist_ok=True)
    plt.savefig('figures/merkle_capsule_proof_sizes.pdf')


if __name__ == '__main__':
    main()
