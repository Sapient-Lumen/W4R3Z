

## v86.31 (2026-02-28)
- Added a small threshold-optimization result to the quorum sizing section: holding $m$ fixed, increasing $t$ can enlarge $\rho_{\max}(m,t)$ enough to restore feasibility under WDD correlation budgets.
- Paper K now includes the same fixed-vs-optimized threshold table used by the flagship draft.


## v86.24 (2026-02-28)
- Added multi-homing exposure calculation artifacts: generator + paper-ready table + plot.
- Paper J: new evaluation subsection quantifying hidden soundness bits from multi-homing; expanded standardization path with SCRAPI + SCITT receipts.
- Paper K: added multi-homing table and SCRAPI/receipts linkage.
- References: added SCITT receipts CCF profile draft and a stable Draft-22 key alias.
## v86.23 (2026-02-28)
- Tightening plan: keep Paper K short but citation-complete; lean into “multi-homing = hidden retries” and “log migration = equivocation risk” as the two boundary attacks.
- Next experiment to add (fast): simulate multi-homing across 2–3 markets as an extra Q factor, compare repricing with/without CMBI visibility.

# Paper K notes: No Free Options (retry accounting)

## One-sentence claim
Retries/waiting/cancellations are *security derivatives*: if they exist but are not disclosed, the advertised soundness parameter is mispriced. Auditable receipts + an Option Surface Ledger (OSL) make retry power explicit and deterministically reprice it.

## What is genuinely new here
- **Option surfaces as a first-class interface** between crypto parameters and market rules.
- **OSL**: a cacheable, deterministic object that commits to declared retry/conditioning caps and outputs a conservative *bias-bit tax*.
- **No-free-option principle**: mechanisms that enable conditioning on favorable randomness must be revealed or paid for via parameter debits.

## Minimum viable contribution set
1. Formalize abort/conditioning option surfaces (AOCs): observables + caps.
2. Prove conservative repricing bounds (union/product bounds; discuss dependence).
3. Specify OSL object format + verification logic.
4. Show integration paths:
   - stapled into PCT bundles,
   - derived from Attempt DAG commitments + market rules,
   - logged for public auditing.

## Where to tighten the math
- Clarify assumptions behind $\eps_{\mathrm{eff}} = 1-(1-\eps_0)^Q$.
  - independent vs. adaptive attempts;
  - which randomness is actually conditioned on.
- Replace product-of-caps with better composition when surfaces overlap.
  - proposed direction: compute an *overlap graph* from Attempt DAG structure.
- Connect bias bits to standard security notions:
  - Fiat--Shamir / random oracle programmability constraints,
  - selective failure and abort channels.

## Experiments we can run from the archive
- Reuse:
  - `beacon_waiting_sim.py` (waiting options)
  - `monte_carlo_pricing.py` (conditioning value)
  - `eps_scoring_sim.py` and `market_pricing.py` (risk-aware scoring)
- Add (small): generate synthetic markets with different cancel/re-auction caps and compare
  - disclosed OSL taxes vs. hidden-retry ground truth.

## Editorial to-dos
- Add a crisp definition box for AOCs and OSL.
- Add a diagram: Attempt DAG \rightarrow receipts \rightarrow OSL digest \rightarrow $\eps$-ledger.
- Provide one end-to-end worked example:
  - a task with beacon waiting + one re-auction + prover selection,
  - resulting OSL table + implied bit-loss.

## Reference links to keep current
- IETF SCITT drafts (architecture, SCRAPI, CCF receipts profile)
- Sigstore transparency log (Rekor v2; datasets)
- CT pages / tiled logs / witness protocols

(If any of these shift, update `references.tex` and recompile.)

## v86.28 (2026-02-28)
- Added a compact *feasibility check* framing in Paper K: correlation budgets imply concrete admission requirements on witness ecosystems.
- New shared insert `_insert_operator_diversity_requirements_table.tex` computes the implied minimum distinct buckets (e.g., independent operators) needed for $B_{\mathrm{dual}}=2^{-k}$ under $m=7,t=6,q=0.12$.

### Next edit for Paper K
- Decide whether Paper K should keep the WDD feasibility material (as an interoperability hook) or push it into Paper J entirely; if kept, add one sentence connecting this directly to market governance ("who can be a witness" and "how much diversity must be funded").
