#!/usr/bin/env python3
"""tpv_gate_normal_form_ref.py

Compute a canonical Gate Normal Form (GNF) for a TPV gate policy.

Motivation:
  - JSON digests alone are brittle (ordering, duplicates, default omissions).
  - A gate normal form provides a *semantic* digest that collapses harmless
    representational differences, enabling cross-organization comparability.

In this snapshot, GNF is defined for the restricted v0 gate vocabulary
("docf.tpv_gate_policy"). The normal-form digest used elsewhere is:

  gate_policy_nf_digest := sha256(JCS(GNF(gate_policy)))

Usage:
  python3 tpv_gate_normal_form_ref.py \
    --policy test_vectors/tpv_gate_policy_demo.json \
    --out test_vectors/tpv_gate_policy_nf_demo.json

The tool prints the normal-form digest to stdout.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List

from docf_ref_tools_common import jcs, load_json


def sha256_pref(b: bytes) -> str:
    return "sha256:" + hashlib.sha256(b).hexdigest()


def uniq_sorted(xs: Any) -> List[str]:
    if not isinstance(xs, list):
        return []
    return sorted({str(x) for x in xs})


def norm_allowlist(xs: Any) -> List[str]:
    out = uniq_sorted(xs)
    if "*" in out:
        return ["*"]
    return out


def gate_gnf(policy: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(policy, dict) or policy.get("type") != "docf.tpv_gate_policy":
        raise ValueError("policy must be a docf.tpv_gate_policy object")

    max_open = policy.get("max_open", "inf")
    if isinstance(max_open, int):
        max_open_nf: Any = int(max_open)
    else:
        max_open_nf = "inf"

    nf: Dict[str, Any] = {
        "type": "docf.tpv_gate_policy_nf",
        "version": "v0",
        "policy_id": str(policy.get("policy_id", "")),
        "catalog_digest": str(policy.get("catalog_digest", "")),
        "require_resolver_id": norm_allowlist(policy.get("require_resolver_id", [])),
        "require_policy_nf_digest": norm_allowlist(policy.get("require_policy_nf_digest", [])),
        "min_L": int(policy.get("min_L", 0)),
        "min_D": int(policy.get("min_D", 0)),
        "require_mitigated": uniq_sorted(policy.get("require_mitigated", [])),
        "forbid_open": uniq_sorted(policy.get("forbid_open", [])),
        "max_open": max_open_nf,
    }
    return nf


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--policy", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    pol = load_json(args.policy)
    nf = gate_gnf(pol)

    Path(args.out).write_text(json.dumps(nf, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    print(sha256_pref(jcs(nf)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
