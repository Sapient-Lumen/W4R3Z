#!/usr/bin/env python3
"""make_scitt_statement_threat_conformance_ref.py

Emit a minimal SCITT-style statement payload that commits to a threat conformance
report digest.

This is a pedagogical JSON stand-in for a COSE-carried SCITT statement.

Usage:
  python3 make_scitt_statement_threat_conformance_ref.py --report path/to/report.json

Writes to stdout.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Dict

from docf_ref_tools_common import jcs, load_json


def sha256_pref(b: bytes) -> str:
    return "sha256:" + hashlib.sha256(b).hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", required=True)
    ap.add_argument("--signer", default="did:web:auditor.example")
    ap.add_argument("--log-id", default="scitt-demo")
    args = ap.parse_args()

    rep = load_json(args.report)
    drep = sha256_pref(jcs(rep))

    stmt: Dict[str, Any] = {
        "media_type": "application/scitt-statement+cose",
        "payload": {
            "statement_type": "docf.threat_conformance_report",
            "report_digest": drep,
            "report_ref": args.report,
            "input_digest": (rep.get("input") or {}).get("digest", ""),
            "catalog_digest": rep.get("catalog_digest", ""),
            "grades": rep.get("grades", {}),
            "mitigated": rep.get("mitigated", []),
            "open": rep.get("open", []),
        },
        "signer": args.signer,
        "log_id": args.log_id,
    }

    print(json.dumps(stmt, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
