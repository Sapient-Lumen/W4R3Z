#!/usr/bin/env python3
"""Reference tool: emit a Market Session Certificate (MSC).

The MSC is a small "binding" object that commits to:
  - a selection receipt (what the market claims it selected),
  - an attempt session certificate (ASC) summarizing all attempts, and
  - an epsilon ledger (resolved soundness bound entries)
Optionally, it can also commit to a beacon-timing commitment when public coins are beacon-derived.

This tool computes deterministic SHA-256 digests over best-effort JCS canonical JSON.
"""

import argparse
import hashlib
import json
from typing import Any, Dict


def jcs_bytes(x: Any) -> bytes:
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_hex_pref(x: Any) -> str:
    return "sha256:" + hashlib.sha256(jcs_bytes(x)).hexdigest()


def load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--selection", default="market_selection_receipt_example.json")
    ap.add_argument("--asc", default="market_session_asc_example.json")
    ap.add_argument("--ledger", default="ledger_example.json")
    ap.add_argument("--sid", default="sid:market:job:42")
    ap.add_argument("--btcc", default=None, help="Optional beacon timing commitment cert JSON")
    ap.add_argument("--out", default="test_vectors/market_session_cert_demo.json")
    args = ap.parse_args()

    sel = load_json(args.selection)
    asc = load_json(args.asc)
    led = load_json(args.ledger)

    msc: Dict[str, Any] = {
        "type": "market_session_certificate",
        "sid": args.sid,
        "selection_receipt": args.selection,
        "attempt_session": args.asc,
        "eps_ledger": args.ledger,
        "digests": {
            "selection_receipt": sha256_hex_pref(sel),
            "attempt_session": sha256_hex_pref(asc),
            "eps_ledger": sha256_hex_pref(led),
        },
        "sig": "base64:...",
    }

    if args.btcc:
        btcc = load_json(args.btcc)
        msc["btcc"] = args.btcc
        msc["digests"]["btcc"] = sha256_hex_pref(btcc)

    # Deterministic overall digest (excluding sig)
    msc["digest"] = sha256_hex_pref({k: v for k, v in msc.items() if k != "sig"})

    out = json.dumps(msc, indent=2, sort_keys=False) + "\n"
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(out)


if __name__ == "__main__":
    main()
