#!/usr/bin/env python3
"""
make_client_policy_experiment.py

Toy but replayable experiment: client time-to-refusal under a split-view (equivocation)
attack with a hard network partition between witness sets, and a client policy that
occasionally "explores" across the partition.

Outputs:
  - test_vectors/pct_client_policy_results.json
  - _insert_client_policy_refusal_table.tex
  - pct_client_policy_refusal_cdf.pdf

The model is intentionally simple:
  * m witnesses are split into two partitions.
  * the log equivocates: partition 0 sees root A, partition 1 sees root B (same tree size).
  * witness-to-witness gossip is blocked across partitions (gamma_cross=0 in the default table).
  * a client refuses when it queries a witness in the opposite partition (sees mismatching root),
    or when it queries a local witness that has learned an equivocation alert (optional leakage gamma).

This is meant to parameterize client behavior, not to be a full CT model.
"""
import json, math, random
from collections import deque
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def gen_overlay(m, kind, rng):
    adj=[set() for _ in range(m)]
    if kind=="complete":
        for i in range(m):
            for j in range(i+1,m):
                adj[i].add(j); adj[j].add(i)
    elif kind=="ring":
        for i in range(m):
            j=(i+1)%m
            adj[i].add(j); adj[j].add(i)
    elif kind=="erdos_renyi":
        p=min(1.0, (math.log(m)+1.0)/m)
        for i in range(m):
            for j in range(i+1,m):
                if rng.random()<p:
                    adj[i].add(j); adj[j].add(i)
        for i in range(m):
            if not adj[i]:
                j=rng.randrange(m-1)
                if j>=i: j+=1
                adj[i].add(j); adj[j].add(i)
    elif kind=="small_world":
        k=4 if m>=6 else max(2, m-1)
        for i in range(m):
            for d in range(1,k//2+1):
                j=(i+d)%m
                adj[i].add(j); adj[j].add(i)
        beta=0.15
        edges=[]
        for i in range(m):
            for j in list(adj[i]):
                if i<j:
                    edges.append((i,j))
        for (i,j) in edges:
            if rng.random()<beta:
                adj[i].discard(j); adj[j].discard(i)
                kcand=rng.randrange(m)
                while kcand==i or kcand in adj[i]:
                    kcand=rng.randrange(m)
                adj[i].add(kcand); adj[kcand].add(i)
    else:
        raise ValueError(kind)
    return [sorted(list(s)) for s in adj]

def shortest_distances(adj, seeds):
    n=len(adj)
    dist=[math.inf]*n
    dq=deque()
    for s in seeds:
        dist[s]=0
        dq.append(s)
    while dq:
        u=dq.popleft()
        for v in adj[u]:
            if dist[v] is math.inf:
                dist[v]=dist[u]+1
                dq.append(v)
    return dist

def simulate(m=31, overlay_kind="erdos_renyi",
             poll_period=30, fanout_k=1, explore_eps=0.01,
             horizon_s=14400, trials=2500, seed=42,
             gamma_cross=0.0, sticky=False):
    rng=random.Random(seed)
    t0=[]; t1=[]; tmax=[]
    for _ in range(trials):
        trng=random.Random(rng.randrange(10**9))
        full_adj=gen_overlay(m, overlay_kind, trng)

        perm=list(range(m)); trng.shuffle(perm)
        half=m//2
        part=[0]*m
        for idx,i in enumerate(perm):
            part[i]=0 if idx<half else 1

        # within-part adjacency
        adj=[[] for _ in range(m)]
        cross=[]
        for i in range(m):
            for j in full_adj[i]:
                if part[i]==part[j]:
                    adj[i].append(j)
                elif i<j:
                    cross.append((i,j))

        # optional cross leakage: seeds arise from unblocked cross edges
        unblocked=[]
        for (i,j) in cross:
            if trng.random()<gamma_cross:
                unblocked.append((i,j))

        seeds0=set(); seeds1=set()
        for i,j in unblocked:
            if part[i]==0: seeds0.add(i); seeds1.add(j)
            else: seeds1.add(i); seeds0.add(j)

        dist=[math.inf]*m
        if seeds0:
            d0=shortest_distances(adj, list(seeds0))
            for i in range(m):
                if part[i]==0: dist[i]=d0[i]
        if seeds1:
            d1=shortest_distances(adj, list(seeds1))
            for i in range(m):
                if part[i]==1: dist[i]=d1[i]

        # alert_time assumes seeds detect at t=1 and propagate 1 hop/sec
        alert_time=[math.inf]*m
        for i in range(m):
            if dist[i] is not math.inf:
                alert_time[i]=1+dist[i]

        client_part=[0,1]
        refused=[False,False]
        rt=[None,None]

        sticky_set=[None,None]
        if sticky:
            for c in range(2):
                local=[i for i in range(m) if part[i]==client_part[c]]
                sticky_set[c]=[trng.choice(local) for _ in range(fanout_k)]

        for t_s in range(0, horizon_s+1, poll_period):
            for c in range(2):
                if refused[c]:
                    continue
                if sticky:
                    contacted=list(sticky_set[c])
                else:
                    local=[i for i in range(m) if part[i]==client_part[c]]
                    contacted=[trng.choice(local) for _ in range(fanout_k)]

                # exploration: per-contact replacement by an outside witness
                for idx in range(len(contacted)):
                    if trng.random()<explore_eps:
                        outside=[i for i in range(m) if part[i]!=client_part[c]]
                        if outside:
                            contacted[idx]=trng.choice(outside)

                for w in contacted:
                    if part[w]!=client_part[c]:
                        refused[c]=True; rt[c]=t_s; break
                    if alert_time[w] <= t_s:
                        refused[c]=True; rt[c]=t_s; break
            if all(refused):
                break

        if rt[0] is None: rt[0]=horizon_s
        if rt[1] is None: rt[1]=horizon_s
        t0.append(rt[0]); t1.append(rt[1]); tmax.append(max(rt))
    return {"t0":t0, "t1":t1, "tmax":tmax}

def summarize(arr):
    arr=np.array(arr, dtype=float)
    return {
        "p50": float(np.percentile(arr, 50)),
        "p95": float(np.percentile(arr, 95)),
        "p99": float(np.percentile(arr, 99)),
        "mean": float(np.mean(arr)),
    }

def main():
    out_dir=Path(".")
    tv_dir=out_dir/"test_vectors"
    tv_dir.mkdir(exist_ok=True)

    # Default experiment parameters (used in the paper insert)
    m=31
    poll_period=30
    horizon_s=14400
    trials=2500
    overlay="erdos_renyi"
    gamma=0.0  # hard partition

    policies=[
        {"name":"local-only (no explore)", "sticky":False, "eps":0.0, "k":1},
        {"name":"rotating +1% explore", "sticky":False, "eps":0.01, "k":1},
        {"name":"rotating +1% explore (k=2)", "sticky":False, "eps":0.01, "k":2},
        {"name":"rotating +5% explore", "sticky":False, "eps":0.05, "k":1},
        {"name":"sticky +1% explore (k=2)", "sticky":True, "eps":0.01, "k":2},
    ]

    rows=[]
    cdf_series=[]
    for pol in policies:
        sim=simulate(m=m, overlay_kind=overlay,
                     poll_period=poll_period, fanout_k=pol["k"],
                     explore_eps=pol["eps"], horizon_s=horizon_s,
                     trials=trials, seed=42,
                     gamma_cross=gamma, sticky=pol["sticky"])
        per_client=[(a+b)/2 for a,b in zip(sim["t0"], sim["t1"])]
        row={
            "policy": pol["name"],
            "m": m,
            "poll_period_s": poll_period,
            "horizon_s": horizon_s,
            "overlay": overlay,
            "gamma_cross": gamma,
            "k": pol["k"],
            "eps": pol["eps"],
            "sticky": pol["sticky"],
            "per_client": summarize(per_client),
            "both_clients": summarize(sim["tmax"]),
        }
        rows.append(row)

        # keep a couple series for CDF plot (exclude the capped baseline)
        if pol["eps"] in (0.01, 0.05) and pol["k"]==1:
            cdf_series.append((pol["name"], np.array(per_client, dtype=float)))

    payload={"meta":{
                "model":"partitioned-split-view-client-policy-toy",
                "m": m, "poll_period_s": poll_period, "horizon_s": horizon_s,
                "overlay": overlay, "gamma_cross": gamma,
                "trials": trials, "seed": 42},
             "rows": rows}
    (tv_dir/"pct_client_policy_results.json").write_text(json.dumps(payload, indent=2))

    # LaTeX table insert
    def fmt_s(x):
        if x>=3600: return f"{x/3600:.2f}h"
        if x>=60: return f"{x/60:.1f}m"
        return f"{x:.0f}s"

    tex=[]
    tex.append(r"\begin{table}[t]")
    tex.append(r"\centering")
    tex.append(r"\small")
    tex.append(r"\begin{tabular}{lrrrr}")
    tex.append(r"\toprule")
    tex.append(r"Policy & $k$ & explore $\varepsilon$ & $T_{50}$ (client) & $T_{95}$ (client) \\")
    tex.append(r"\midrule")
    def latex_escape(s: str) -> str:
        # Minimal escaping for table text.
        return s.replace("%", r"\%"
            ).replace("_", r"\_")

    for r in rows:
        p50=r["per_client"]["p50"]; p95=r["per_client"]["p95"]
        policy = latex_escape(r["policy"])
        tex.append(f'{policy} & {r["k"]} & {r["eps"]:.3f} & {fmt_s(p50)} & {fmt_s(p95)} \\\\')
    tex.append(r"\bottomrule")
    tex.append(r"\end{tabular}")
    tex.append(r"\caption{Toy split-view under a hard partition: client time-to-refusal depends strongly on ``exploration'' across witness sets. Parameters: $m=31$ witnesses, poll period $P=30$s, horizon 4h, Erd\H{o}s--R\'enyi overlay for within-part gossip, and \emph{no} cross-part witness gossip ($\gamma=0$).}")
    tex.append(r"\label{tab:client_policy_refusal}")
    tex.append(r"\end{table}")
    (out_dir/"_insert_client_policy_refusal_table.tex").write_text("\n".join(tex))

    # CDF plot
    plt.figure()
    for label, arr in cdf_series:
        xs=np.sort(arr)
        ys=np.arange(1,len(xs)+1)/len(xs)
        plt.plot(xs, ys, label=label)
    plt.xlabel("time to refusal (s)")
    plt.ylabel("CDF")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_dir/"pct_client_policy_refusal_cdf.pdf")

if __name__=="__main__":
    main()
