#!/usr/bin/env python3
"""
eps_ledger_ref.py — tiny reference helper for docf-eps-ledger-v0.

This is intentionally small and conservative:
- validates against docf_eps_ledger_v0.schema.json,
- parses epsilon expressions used in toy ledgers (e.g., "2^-80", "<=Q*2^-80"),
- computes a conservative portfolio bound (union bound by default).

Usage:
  python eps_ledger_ref.py ledger.json --Q 1024
  python eps_ledger_ref.py ledger.json --rule independent
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
from typing import Any, Dict, Tuple

import jsonschema


def _sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def canonical_json(obj: Any) -> bytes:
    """Deterministic JSON encoding (RFC 8785-ish minus floats nuances)."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


_EPS_POW_RE = re.compile(r"2\^\s*-\s*([0-9]+(?:\.[0-9]+)?)")
_Q_MUL_RE = re.compile(r"Q\s*\*\s*(.*)")


def parse_eps(value: Any, *, vars: Dict[str, float]) -> float:
    """
    Parse an epsilon field.
    Supported forms:
      - number
      - "2^-80", "2^-78.4"
      - "<=2^-80", "<=Q*2^-80"
      - "<=Q*<something>" where <something> itself is parseable.
    """
    if value is None:
        raise ValueError("eps is null")
    if isinstance(value, (int, float)):
        if value < 0 or value > 1:
            raise ValueError(f"eps out of range: {value}")
        return float(value)

    if not isinstance(value, str):
        raise ValueError(f"eps must be number or string, got {type(value)}")

    s = value.strip()
    if s.startswith("<="):
        s = s[2:].strip()

    # Direct float?
    try:
        f = float(s)
        if f < 0 or f > 1:
            raise ValueError(f"eps out of range: {f}")
        return f
    except ValueError:
        pass

    # Q * expr
    m = _Q_MUL_RE.fullmatch(s.replace(" ", ""))
    if m:
        Q = float(vars.get("Q", 0.0))
        if Q <= 0:
            raise ValueError("expression uses Q but --Q was not provided")
        inner = m.group(1)
        return Q * parse_eps(inner, vars=vars)

    # 2^-x
    m = _EPS_POW_RE.search(s.replace(" ", ""))
    if m:
        x = float(m.group(1))
        return 2.0 ** (-x)

    raise ValueError(f"unsupported eps expression: {value!r}")


def bits_from_eps(eps: float) -> float:
    if eps <= 0:
        return float("inf")
    return -math.log(eps, 2)


def validate_schema(ledger: Dict[str, Any], schema_path: str) -> None:
    schema = json.load(open(schema_path, "r", encoding="utf-8"))
    jsonschema.validate(instance=ledger, schema=schema)


def compute_portfolio_bound(eps_list, rule: str) -> float:
    """Portfolio bound for a list of *numbers* (no metadata)."""
    if rule == "union":
        return sum(eps_list)
    if rule == "independent":
        p = 1.0
        for e in eps_list:
            p *= (1.0 - e)
        return 1.0 - p
    raise ValueError(f"unknown rule: {rule}")


def compute_portfolio_bound_from_entries(entries, rule: str) -> float:
    """Portfolio bound when entries may carry correlation clusters.

    - union: sum of eps
    - independent: assumes entrywise independence
    - independent_clusters: union within each cluster, independence across clusters
    """
    if rule in ("union", "independent"):
        eps_list = [float(e["_eps_value"]) for e in entries]
        return compute_portfolio_bound(eps_list, rule)

    if rule == "independent_clusters":
        clusters = {}
        for e in entries:
            cid = e.get("cluster")
            if not cid:
                # Default: treat each unclustered entry as its own cluster.
                cid = f"__entry__:{e.get('source_digest_sha256','')}"
            clusters[cid] = clusters.get(cid, 0.0) + float(e["_eps_value"])
        p = 1.0
        for cid, s in clusters.items():
            g = min(1.0, s)  # union bound within cluster
            p *= (1.0 - g)
        return 1.0 - p

    raise ValueError(f"unknown rule: {rule}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("ledger_json", help="Path to docf-eps-ledger-v0 JSON")
    ap.add_argument("--schema", default="docf_eps_ledger_v0.schema.json", help="Schema path")
    ap.add_argument("--Q", type=float, default=None, help="Retry multiplier variable for parsing expressions")
    ap.add_argument("--rule", choices=["union", "independent", "independent_clusters"], default="union", help="Composition rule")
    args = ap.parse_args()

    ledger = json.load(open(args.ledger_json, "r", encoding="utf-8"))

    # Resolve schema path relative to ledger file.
    schema_path = args.schema
    if not os.path.isabs(schema_path):
        schema_path = os.path.join(os.path.dirname(args.ledger_json), schema_path)
        if not os.path.exists(schema_path):
            # fall back to cwd
            schema_path = args.schema

    validate_schema(ledger, schema_path)

    vars = {}
    if args.Q is not None:
        vars["Q"] = float(args.Q)

    eps_entries = []
    for ent in ledger.get("entries", []):
        e = parse_eps(ent.get("eps"), vars=vars)
        ent2 = dict(ent)
        ent2["_eps_value"] = float(e)
        eps_entries.append(ent2)

    eps_total = compute_portfolio_bound_from_entries(eps_entries, args.rule)
    out = {
        "format": ledger.get("format"),
        "n_entries": len(eps_entries),
        "rule": args.rule,
        "eps_total": eps_total,
        "bits_total": bits_from_eps(eps_total),
        "ledger_digest_sha256": _sha256_bytes(canonical_json(ledger)),
    }
    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
