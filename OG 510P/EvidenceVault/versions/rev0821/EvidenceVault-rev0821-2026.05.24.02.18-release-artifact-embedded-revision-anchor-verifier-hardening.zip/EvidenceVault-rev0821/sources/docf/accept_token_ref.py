#!/usr/bin/env python3
"""
accept_token_ref.py

Reference sketch: compute a toy docf-accept-token-v0 from:
  - a normalized policy (PNF digest),
  - a statement digest (manifest),
  - an audit bundle digest,
  - a resolver descriptor.

Usage:
  - Emit the demo accept token used in the paper:
      python3 accept_token_ref.py --emit-demo

This is deliberately simple and uses sha256 over concatenated UTF-8 strings for cid/ack
so the paper examples are easy to reproduce.
"""
from __future__ import annotations
import argparse, json, hashlib
from typing import Any, Dict

def jcs_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def sha256_pref(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()

def compute_cid(pnf_digest: str, resolver_digest: str, verifier_id: str, verifier_code_digest: str, log_ids: str) -> str:
    s = "docf:cid:v0|" + pnf_digest + "|" + resolver_digest + "|" + verifier_id + "|" + verifier_code_digest + "|" + log_ids
    return sha256_pref(s.encode("utf-8"))

def compute_ack(cid: str, stmt_digest: str, bundle_digest: str) -> str:
    s = "docf:ack:v0|" + cid + "|" + stmt_digest + "|" + bundle_digest
    return sha256_pref(s.encode("utf-8"))

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit-demo", action="store_true")
    args = ap.parse_args()

    if not args.emit_demo:
        ap.error("This reference script currently only emits the demo token.")

    # Load the demo inputs shipped with the archive.
    with open("policy_example_v1.json", "r", encoding="utf-8") as f:
        policy = json.load(f)
    with open("test_vectors/policy_normal_form_demo.json", "r", encoding="utf-8") as f:
        pnf = json.load(f)
    with open("test_vectors/manifest_example.json", "r", encoding="utf-8") as f:
        manifest = json.load(f)
    with open("test_vectors/policy_proof_bundle_demo.json", "r", encoding="utf-8") as f:
        bundle = json.load(f)
    with open("test_vectors/resolver_descriptor_demo.json", "r", encoding="utf-8") as f:
        resolver_desc = json.load(f)
    with open("test_vectors/attempt_dag_demo.json", "r", encoding="utf-8") as f:
        dag = json.load(f)

    pnf_digest = sha256_pref(jcs_bytes(pnf))
    stmt_digest = sha256_pref(jcs_bytes(manifest))
    bundle_digest = sha256_pref(jcs_bytes(bundle))
    resolver_digest = sha256_pref(jcs_bytes(resolver_desc))

    verifier_id = "auditor_ref"
    verifier_code_digest = sha256_pref(b"auditor_ref.py@v0")
    log_ids = "rekor_v2_tiles_demo|static_ct_demo|scitt_demo"

    cid = compute_cid(pnf_digest, resolver_digest, verifier_id, verifier_code_digest, log_ids)
    ack = compute_ack(cid, stmt_digest, bundle_digest)

    token = {
      "type":"docf-accept-token-v0",
      "version":"0",
      "created_at":"2026-02-24T00:00:00Z",
      "cid":cid,
      "ack":ack,
      "policy_nf_digest":pnf_digest,
      "stmt_digest":stmt_digest,
      "bundle_digest":bundle_digest,
      "policy_proof_bundle_ref":"test_vectors/policy_proof_bundle_demo.json",
      "anchors":[
        {"kind":"tile_log_checkpoint","log_id":"rekor-v2-tiles-demo","ref":"test_vectors/policy_proof_equivocation_witness_demo.json"},
        {"kind":"scitt_receipt","log_id":"scitt-demo","ref":"test_vectors/market_session_cert_scitt_statement_demo.json"}
      ],
      "pointers":{
        "manifest_digest":manifest.get("manifest_digest","sha256:..."),
        "attempt_dag_root":dag["root_commitment"]["merkle_root"],
        "proof_capsule_ref":"proof_capsule_example.json"
      },
      "issuer":{"id":"toy-auditor","pubkey":"ed25519:...demo"}
    }

    with open("test_vectors/accept_token_demo.json", "w", encoding="utf-8") as f:
        json.dump(token, f, indent=2, sort_keys=True)
        f.write("\n")
    print(ack)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
