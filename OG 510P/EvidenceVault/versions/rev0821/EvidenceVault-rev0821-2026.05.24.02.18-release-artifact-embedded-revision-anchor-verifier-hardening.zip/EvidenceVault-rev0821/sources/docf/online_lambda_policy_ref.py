#!/usr/bin/env python3
"""
online_lambda_policy_ref.py (reference)
--------------------------------------

Purpose
  Demonstrate an *online* update rule for the Lagrange multiplier (lambda) used in
  epsilon-scoring procurement:

      score(b) = price(b) + lambda_t * eps_resolved(b)

  where an epoch has a total epsilon budget B (under a declared portfolio rule, often a union bound).

This is a toy / reference tool:
  - Uses an "equal-share" per-job budget b = B / N.
  - Updates a nonnegative virtual queue (lambda) based on normalized budget consumption:
        lambda_{t+1} = max(0, lambda_t + eta * (eps_t / b - 1))
  - Emits a JSON artifact that can be stapled into audits or used to reproduce figures.

This is NOT an endorsement of the specific policy; it is a concrete template that governance can
replace with any declared lambda policy.

Usage
  python online_lambda_policy_ref.py --emit
  python online_lambda_policy_ref.py --n 200 --budget-bits 60 --eta 0.2 --seed 7 --out demo.json
"""
from __future__ import annotations

import argparse
import json
import math
import random
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple


def _eps_from_bits(bits: float) -> float:
    return 2.0 ** (-float(bits))


def demo_eps_bits(n: int, seed: int, *, lo: int = 72, hi: int = 80, bad_prob: float = 0.08) -> List[int]:
    """Generate a synthetic per-job epsilon *bits* sequence."""
    rnd = random.Random(seed)
    out: List[int] = []
    for _ in range(n):
        b = rnd.randint(lo, hi)
        if rnd.random() < bad_prob:
            b = rnd.randint(60, 70)  # occasional worse jobs
        out.append(b)
    return out


def run_policy(*, eps_bits: List[int], budget_bits: float, eta: float) -> Dict[str, Any]:
    n = len(eps_bits)
    eps = [_eps_from_bits(b) for b in eps_bits]
    B = _eps_from_bits(budget_bits)
    b = B / max(1, n)
    lam: List[float] = [0.0]
    cum: List[float] = [0.0]
    for t in range(n):
        cum.append(cum[-1] + eps[t])
        e_norm = eps[t] / b
        lam.append(max(0.0, lam[-1] + eta * (e_norm - 1.0)))
    return {
        "type": "docf_online_lambda_demo_v0",
        "params": {"n": n, "budget_bits": budget_bits, "budget": B, "eta": eta, "per_job_budget": b},
        "sequence": {
            "eps_bits": eps_bits,
            "eps": eps,
            "lambda": lam[1:],
            "cumulative_eps": cum[1:],
            "cumulative_over_budget": [c / B for c in cum[1:]],
        },
        "notes": [
            "Toy equal-share long-term constraint policy (virtual queue).",
            "Use for demos / reproducibility; governance should declare production policy explicitly.",
        ],
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit", action="store_true", help="print a deterministic demo artifact")
    ap.add_argument("--n", type=int, default=100)
    ap.add_argument("--budget-bits", type=float, default=60.0)
    ap.add_argument("--eta", type=float, default=0.2)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--out", type=str, default="", help="write JSON to file (optional)")
    args = ap.parse_args()

    eps_bits = demo_eps_bits(args.n, args.seed)
    obj = run_policy(eps_bits=eps_bits, budget_bits=args.budget_bits, eta=args.eta)

    s = json.dumps(obj, indent=2, sort_keys=True)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(s + "\n")
    if args.emit or not args.out:
        print(s)


if __name__ == "__main__":
    main()
