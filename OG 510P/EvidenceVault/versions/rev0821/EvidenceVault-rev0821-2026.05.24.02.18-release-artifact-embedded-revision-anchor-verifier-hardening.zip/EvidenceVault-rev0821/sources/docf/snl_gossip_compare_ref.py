#!/usr/bin/env python3
"""snl_gossip_compare_ref.py (v86.8)

Compare multiple SNL gossip bundles and emit a disagreement report.

Toy detector for *split-view* evidence:
  - group observed checkpoints by (log_id, tree_size)
  - if multiple distinct checkpoint payload hashes (and/or roots) appear,
    output a disagreement report

Note: v86.8 demos a *validly signed* conflict bundle (see
snl_gossip_bundle_ref.py). Signature verification is performed in
snl_slashing_proof_ref.py; this script stays lightweight and focuses on
structural conflict detection.

Usage:
  python3 snl_gossip_compare_ref.py --bundles a.json b.json --out report.json
  python3 snl_gossip_compare_ref.py --emit-demo

Demo output:
  test_vectors/snl_gossip_disagreement_report_demo.json
"""

from __future__ import annotations

import argparse
import json
import os
from typing import Any, Dict, List, Tuple

from docf_ref_tools_common import load_json, emit_json


def extract_observations(bundle: Dict[str, Any]) -> List[Tuple[str, int, str, str, str]]:
    """Return [(log_id, tree_size, root_b64, payload_sha_hex, observer_id)]."""
    log_id = str(bundle.get("log_id", ""))
    observer_id = str((bundle.get("observer") or {}).get("observer_id", ""))
    out: List[Tuple[str, int, str, str, str]] = []

    for o in (bundle.get("observations") or []):
        chk = o.get("checkpoint") or {}
        try:
            ts = int(chk.get("tree_size", 0) or 0)
            root = str(chk.get("root_hash_sha256_b64", ""))
            ph = str(o.get("checkpoint_payload_sha256_hex", ""))
            out.append((log_id, ts, root, ph, observer_id))
        except Exception:
            continue
    return out


def build_report(bundles: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    by_key: Dict[Tuple[str, int], Dict[str, List[str]]] = {}

    for b in bundles:
        for (log_id, ts, root, ph, oid) in extract_observations(b):
            key = (log_id, ts)
            if key not in by_key:
                by_key[key] = {}
            k2 = f"{root}|{ph}"
            by_key[key].setdefault(k2, []).append(oid)

    reports: List[Dict[str, Any]] = []
    for (log_id, ts), roots in by_key.items():
        if len(roots) <= 1:
            continue
        conflicts: List[Dict[str, Any]] = []
        for k2, observers in roots.items():
            root, ph = k2.split("|", 1)
            conflicts.append(
                {
                    "checkpoint_payload_sha256_hex": ph,
                    "root_hash_sha256_b64": root,
                    "observers": observers,
                }
            )
        reports.append(
            {
                "schema": "docf-snl-gossip-disagreement-report-v0",
                "version": "0",
                "log_id": log_id,
                "tree_size": ts,
                "conflicts": conflicts,
                "notes": [
                    "Multiple distinct roots observed for the same (log_id, tree_size).",
                    "For signature-validated equivocation evidence, see docf-snl-slashing-proof-v0 (snl_slashing_proof_ref.py).",
                ],
            }
        )

    return reports


def emit_demo() -> None:
    tv = os.path.join(os.path.dirname(__file__), "test_vectors")
    a = load_json(os.path.join(tv, "snl_gossip_bundle_A_demo.json"))
    b_path = os.path.join(tv, "snl_gossip_bundle_B_conflict_demo.json")
    if os.path.exists(b_path):
        b = load_json(b_path)
    else:
        b = load_json(os.path.join(tv, "snl_gossip_bundle_B_demo.json"))

    reps = build_report([a, b])
    out_path = os.path.join(tv, "snl_gossip_disagreement_report_demo.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(reps[0] if reps else {}, f, indent=2, ensure_ascii=False)
        f.write("\n")
    emit_json(reps[0] if reps else {})
    print(f"Wrote {out_path}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--bundles", nargs="*", default=[])
    ap.add_argument("--out", type=str, default="")
    ap.add_argument("--emit-demo", action="store_true")
    args = ap.parse_args()

    if args.emit_demo:
        emit_demo()
        return

    if not args.bundles or not args.out:
        ap.print_help()
        return

    bundles = [load_json(p) for p in args.bundles]
    reps = build_report(bundles)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(reps, f, indent=2, ensure_ascii=False)
        f.write("\n")


if __name__ == "__main__":
    main()
