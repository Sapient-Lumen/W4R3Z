#!/usr/bin/env python3
"""tpv_gate_equivalence_ref.py

Produce a tiny equivalence certificate for two TPV gate policies.

In this snapshot, equivalence is *decidable* by construction because
GNF is a canonical normal form for the restricted v0 gate vocabulary.
Two gates are equivalent iff sha256(JCS(GNF(gate))) matches.

Usage:
  python3 tpv_gate_equivalence_ref.py \
    --gate-a test_vectors/tpv_gate_policy_demo.json \
    --gate-b test_vectors/tpv_gate_policy_strict_demo.json \
    --out test_vectors/tpv_gate_equivalence_cert_demo.json
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Dict

from docf_ref_tools_common import jcs, load_json


def sha256_pref(b: bytes) -> str:
    return "sha256:" + hashlib.sha256(b).hexdigest()


def uniq_sorted(xs: Any):
    if not isinstance(xs, list):
        return []
    return sorted({str(x) for x in xs})


def norm_allowlist(xs: Any):
    out = uniq_sorted(xs)
    if "*" in out:
        return ["*"]
    return out


def gate_gnf(policy: Dict[str, Any]) -> Dict[str, Any]:
    max_open = policy.get("max_open", "inf")
    if isinstance(max_open, int):
        max_open_nf: Any = int(max_open)
    else:
        max_open_nf = "inf"

    nf: Dict[str, Any] = {
        "type": "docf.tpv_gate_policy_nf",
        "version": "v0",
        "created_at": str(policy.get("created_at", "")) or "",
        "policy_id": str(policy.get("policy_id", "")),
        "catalog_digest": str(policy.get("catalog_digest", "")),
        "require_resolver_id": norm_allowlist(policy.get("require_resolver_id", [])),
        "require_policy_nf_digest": norm_allowlist(policy.get("require_policy_nf_digest", [])),
        "min_L": int(policy.get("min_L", 0)),
        "min_D": int(policy.get("min_D", 0)),
        "require_mitigated": uniq_sorted(policy.get("require_mitigated", [])),
        "forbid_open": uniq_sorted(policy.get("forbid_open", [])),
        "max_open": max_open_nf,
    }
    # Note: created_at and notes are intentionally not part of the equivalence notion;
    # they can differ while semantics remain equal.
    nf.pop("created_at", None)
    return nf


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--gate-a", required=True)
    ap.add_argument("--gate-b", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--created_at", default="2026-02-26T00:00:00Z")
    args = ap.parse_args()

    a = load_json(args.gate_a)
    b = load_json(args.gate_b)

    a_pol_digest = sha256_pref(jcs(a))
    b_pol_digest = sha256_pref(jcs(b))

    a_nf_digest = sha256_pref(jcs(gate_gnf(a)))
    b_nf_digest = sha256_pref(jcs(gate_gnf(b)))

    eq = a_nf_digest == b_nf_digest

    out: Dict[str, Any] = {
        "type": "docf.tpv_gate_equivalence_cert",
        "version": "v0",
        "created_at": args.created_at,
        "gate_a_policy_digest": a_pol_digest,
        "gate_b_policy_digest": b_pol_digest,
        "gate_a_nf_digest": a_nf_digest,
        "gate_b_nf_digest": b_nf_digest,
        "equivalent": bool(eq),
        "basis": "nf_digest",
    }

    Path(args.out).write_text(json.dumps(out, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
