#!/usr/bin/env python3
"""make_scitt_statement_global_grinding_budget_cert_ref.py

Emit a *toy* SCITT-style statement wrapper for a Global Grinding Budget Certificate.

Why this exists:
- The papers discuss anchoring budget certificates in SCITT/CT/Sigstore-like
  transparency services.
- Implementing full COSE_Sign1 + COSE receipts would add heavy deps.

This tool therefore emits a JSON statement that mirrors the SCITT concept
(`signed statement` + subject digest), and is compatible with the archive's
CT-style demo log tools.

The statement format is *illustrative* and intentionally minimal.

Usage:
  ./make_scitt_statement_global_grinding_budget_cert_ref.py --emit \
      --cert test_vectors/global_grinding_budget_cert_demo.json \
      --out test_vectors/scitt_statement_global_grinding_budget_demo.json

"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
from pathlib import Path
from typing import Any, Dict

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization


def jcs_bytes(x: Any) -> bytes:
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_pref(x: Any) -> str:
    return "sha256:" + hashlib.sha256(jcs_bytes(x)).hexdigest()


def demo_issuer_key() -> tuple[Ed25519PrivateKey, str]:
    seed = b"docf-demo-global-grinding-budget-issuer-key-0000"[:32]
    sk = Ed25519PrivateKey.from_private_bytes(seed)
    pk = sk.public_key().public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
    return sk, base64.b64encode(pk).decode("ascii")


def load_json(p: Path) -> Dict[str, Any]:
    return json.loads(p.read_text(encoding="utf-8"))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit", action="store_true")
    ap.add_argument("--cert", default="test_vectors/global_grinding_budget_cert_demo.json")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    if not args.emit:
        ap.print_help()
        return

    cert = load_json(Path(args.cert))

    sk, pk_b64 = demo_issuer_key()

    stmt: Dict[str, Any] = {
        "type": "docf_scitt_statement_json_v0",
        "media_type_hint": "application/scitt-statement+cose (illustrative JSON wrapper)",
        "subject": {
            "kind": "global_grinding_budget_certificate",
            "digest": sha256_pref(cert),
        },
        "issuer": {
            "issuer_id": cert.get("issuer_id", "unknown"),
            "issuer_pubkey_b64": pk_b64,
        },
        "claims": {
            "epoch": cert.get("epoch"),
            "time_window": cert.get("time_window"),
            "Q_total_declared": cert.get("Q_total_declared"),
            "Q_total_observed": cert.get("Q_total_observed"),
            "ledger_checkpoint": cert.get("ledger_checkpoint"),
        },
    }

    msg = jcs_bytes(stmt)
    sig = sk.sign(msg)
    stmt["sig"] = "ed25519:" + base64.b64encode(sig).decode("ascii")

    out_s = json.dumps(stmt, indent=2) + "\n"
    if args.out:
        Path(args.out).write_text(out_s, encoding="utf-8")
    else:
        print(out_s, end="")


if __name__ == "__main__":
    main()
