#!/usr/bin/env python3
"""
attempt_dag_compiler_ref.py

Reference compiler: Attempt Trace (ATS v1) -> Attempt DAG Commitment (ADC v0).

Why this exists:
- The papers (A/D) argue that "receipt-complete retries" should be represented
  as an auditable graph object (Attempt DAG), not an implicit side channel.
- This tool takes the *skeleton* trace format (docf_attempt_trace_v1) and
  deterministically emits a minimally-populated Attempt DAG object
  (docf_attempt_dag_v0).

⚠️  Note:
- The attempt-trace schema in this archive is intentionally lightweight.
  Real deployments should enrich nodes with:
    - transcript / input-output digests,
    - Signed Attempt Certificate (SAC) pointers,
    - precise timestamps,
    - prover identities and hardware claims.
- This tool demonstrates *structure* and commitment discipline, not a full
  attestation pipeline.

Usage:
  - Compile:  ./attempt_dag_compiler_ref.py --in trace.json --out dag.json
  - Emit demo trace: ./attempt_dag_compiler_ref.py --emit-trace
  - Emit demo dag:   ./attempt_dag_compiler_ref.py --emit

"""
from __future__ import annotations
import argparse
import hashlib
import json
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


def _sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _canon(obj: Any) -> bytes:
    """Canonical JSON bytes (stable across runs)."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _digest_obj(obj: Any, prefix: str = "sha256") -> str:
    return f"{prefix}:{_sha256_hex(_canon(obj))}"


def demo_trace_v1() -> Dict[str, Any]:
    """
    A small structured trace with:
      - shard attempt that retries once,
      - aggregate stage,
      - final stage.
    """
    sid = "demo-sid-001"
    return {
        "schema": "docf-attempt-trace-v1",
        "meta": {
            "sid": sid,
            "prover_id": "demo-prover-A",
            "note": "deterministic demo trace for attempt_dag_compiler_ref.py",
        },
        "seed_group": "seedgrp#demo",
        "seed_locked": True,
        "events": [
            {"op": "enter", "tid": 0, "id": "r1", "v": "shard"},
            {"op": "retry", "tid": 0, "id": "r1", "v": "shard"},
            {"op": "exit",  "tid": 0, "id": "r1", "v": "shard"},

            {"op": "enter", "tid": 0, "id": "r2", "v": "aggregate"},
            {"op": "exit",  "tid": 0, "id": "r2", "v": "aggregate"},

            {"op": "enter", "tid": 0, "id": "r3", "v": "final"},
            {"op": "exit",  "tid": 0, "id": "r3", "v": "final"},
        ],
        "var_bounds": {"Q_max": 2},
    }


@dataclass
class RegionState:
    stage: str
    tid: str
    rid: str
    entered_idx: int
    saw_retry: bool = False
    exited_idx: Optional[int] = None


def compile_attempt_dag(trace: Dict[str, Any]) -> Dict[str, Any]:
    if trace.get("schema") != "docf-attempt-trace-v1":
        raise ValueError("expected schema=docf-attempt-trace-v1")

    meta = trace.get("meta", {}) or {}
    sid = meta.get("sid") or trace.get("sid") or "unknown-sid"
    prover_id = meta.get("prover_id", "unknown-prover")

    # One stack per task id (tid).
    stacks: Dict[str, List[str]] = {}
    regions: Dict[Tuple[str, str], RegionState] = {}  # (tid,rid)->state

    nodes: List[Dict[str, Any]] = []
    node_by_key: Dict[Tuple[str, str], Dict[str, Any]] = {}

    events = trace.get("events", [])
    for idx, ev in enumerate(events):
        op = ev.get("op")
        tid = str(ev.get("tid"))
        rid = str(ev.get("id"))
        stage = str(ev.get("v"))

        stacks.setdefault(tid, [])

        if op == "enter":
            parents: List[str] = []
            if stacks[tid]:
                # nesting parent
                parents.append(stacks[tid][-1])
            attempt_id = f"{tid}:{rid}"
            # deterministic placeholder digests
            input_digest = _digest_obj({"sid": sid, "attempt": attempt_id, "stage": stage, "kind": "input"})
            output_digest = _digest_obj({"sid": sid, "attempt": attempt_id, "stage": stage, "kind": "output"})
            proof_digest = _digest_obj({"sid": sid, "attempt": attempt_id, "stage": stage, "kind": "proof"})

            node = {
                "attempt_id": attempt_id,
                "stage": stage,
                "parents": parents if parents else [],
                "input_digest": input_digest,
                "output_digest": output_digest,
                "proof_digest": proof_digest if stage == "final" else None,
                "seed_binding": {
                    "mode": "committed-seed" if trace.get("seed_locked") else "custom",
                    "seed_commitment": _digest_obj({"seed_group": trace.get("seed_group", "unknown")}),
                },
                "prover": {"prover_id": prover_id},
                "status": "ok",
                "timestamps": {"start": f"e{idx}"},
            }
            # remove nulls for schema friendliness
            if node["proof_digest"] is None:
                del node["proof_digest"]
            if not node["parents"]:
                del node["parents"]

            regions[(tid, rid)] = RegionState(stage=stage, tid=tid, rid=rid, entered_idx=idx)
            node_by_key[(tid, rid)] = node
            nodes.append(node)
            stacks[tid].append(attempt_id)

        elif op == "retry":
            st = regions.get((tid, rid))
            if st is not None:
                st.saw_retry = True
                node = node_by_key[(tid, rid)]
                node["status"] = "fail"
                node["failure"] = "retry"

        elif op == "exit":
            st = regions.get((tid, rid))
            if st is not None:
                st.exited_idx = idx
                node = node_by_key[(tid, rid)]
                node.setdefault("timestamps", {})["end"] = f"e{idx}"
            # pop matching attempt_id if on top; otherwise ignore (trace could be partial).
            attempt_id = f"{tid}:{rid}"
            if stacks[tid] and stacks[tid][-1] == attempt_id:
                stacks[tid].pop()

        # fork/join/choose are ignored in this reference compiler,
        # but a real compiler would add inter-task edges and branch metadata.

    # Root commitment: commit to the ordered node list (already deterministic here).
    root_commitment = _digest_obj(nodes)

    # Pick final proof: the last node with stage=='final', else last node.
    final_node = None
    for n in reversed(nodes):
        if n.get("stage") == "final":
            final_node = n
            break
    if final_node is None:
        final_node = nodes[-1]
    proof_digest = final_node.get("proof_digest") or _digest_obj({"sid": sid, "note": "no-final-proof"})
    final = {"proof_digest": proof_digest, "verifies": True}

    adc = {
        "schema": "docf-attempt-dag-v0",
        "session_id": sid,
        "log": {
            "trace_digest": _digest_obj(trace),
            "compiler": "attempt_dag_compiler_ref.py",
            "note": "structure-only reference compiler; enrich in production",
        },
        "root_commitment": root_commitment,
        "nodes": nodes,
        "final": final,
    }
    return adc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", help="Attempt trace JSON (docf-attempt-trace-v1)")
    ap.add_argument("--out", dest="out", help="Write Attempt DAG JSON here (or stdout if omitted)")
    ap.add_argument("--emit", action="store_true", help="Emit a deterministic demo Attempt DAG to stdout")
    ap.add_argument("--emit-trace", action="store_true", help="Emit a deterministic demo Attempt Trace to stdout")
    args = ap.parse_args()

    if args.emit_trace:
        print(json.dumps(demo_trace_v1(), indent=2))
        return

    if args.emit:
        dag = compile_attempt_dag(demo_trace_v1())
        print(json.dumps(dag, indent=2))
        return

    if not args.inp:
        ap.print_help()
        return

    with open(args.inp, "r", encoding="utf-8") as f:
        trace = json.load(f)
    dag = compile_attempt_dag(trace)
    out = json.dumps(dag, indent=2)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(out + "\n")
    else:
        print(out)


if __name__ == "__main__":
    main()
