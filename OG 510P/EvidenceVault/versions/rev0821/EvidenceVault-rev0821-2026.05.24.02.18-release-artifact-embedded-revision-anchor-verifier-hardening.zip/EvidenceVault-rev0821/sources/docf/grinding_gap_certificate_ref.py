#!/usr/bin/env python3
"""grinding_gap_certificate_ref.py

Reference generator for a minimal Grinding-Gap Certificate (GGC).

A GGC upper-bounds an *invisible* micro-retry factor m for a session: if a system
advertises soundness eps assuming N trials, but can realize up to m*N unreceipted
trials, then conservative accounting scales eps by m (Lemma grinding-gap).

v85.0 strengthens the demo in two ways:
  (1) The GGC is *bound* to the same cache context as the PAO that consumes it
      (policy/resolver IDs, PABOM statement digest, anchor checkpoint root), to
      prevent "certificate laundering" across unrelated sessions.
  (2) The demo includes a deterministic Ed25519 signature over the GGC's digest.
      The digest commits to the *unsigned* fields (excludes 'digest', 'sig', and auxiliary evidence fields (e.g. 'transparency')).

Usage:
  python3 grinding_gap_certificate_ref.py --emit-demo

Writes:
  test_vectors/grinding_gap_certificate_demo.json
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import math
import os
from typing import Any, Dict, Tuple

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

from docf_ref_tools_common import jcs, load_json


def sha256_pref(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def digest_obj_unsigned(obj: Dict[str, Any]) -> str:
    # Convention (v85.0): digest commits to the object with 'digest' and 'sig' removed.
    tmp = dict(obj)
    tmp.pop("digest", None)
    tmp.pop("sig", None)
    tmp.pop("transparency", None)
    return sha256_pref(jcs(tmp))


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _sign_ed25519(priv_bytes: bytes, msg: bytes) -> Tuple[bytes, bytes]:
    priv = Ed25519PrivateKey.from_private_bytes(priv_bytes)
    pub = priv.public_key()
    pub_raw = pub.public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    sig = priv.sign(msg)
    return pub_raw, sig


def ct_leaf_hash(preimage: bytes) -> bytes:
    # RFC 9162 / RFC 6962 leaf hash
    return hashlib.sha256(b"\x00" + preimage).digest()

def ct_node_hash(left: bytes, right: bytes) -> bytes:
    # RFC 9162 / RFC 6962 node hash
    return hashlib.sha256(b"\x01" + left + right).digest()

def merkle_root_and_path(preimages: list[bytes], leaf_index: int) -> tuple[bytes, list[bytes], bytes, str]:
    # Build a full binary tree over len(preimages) leaves (demo uses power-of-two).
    leaf_hashes = [ct_leaf_hash(p) for p in preimages]
    # Record inclusion path for leaf_index.
    path: list[bytes] = []
    level = leaf_hashes[:]
    idx = leaf_index
    while len(level) > 1:
        sib = idx ^ 1
        path.append(level[sib])
        nxt = []
        for i in range(0, len(level), 2):
            nxt.append(ct_node_hash(level[i], level[i+1]))
        level = nxt
        idx //= 2
    root = level[0]
    leaf_preimage = preimages[leaf_index]
    leaf_preimage_digest = hashlib.sha256(leaf_preimage).hexdigest()
    return root, path, leaf_hashes[leaf_index], leaf_preimage_digest

def emit_demo() -> Tuple[Dict[str, Any], Dict[str, Any]]:
    # Bind to the same cache context as the PAO demo vectors.
    accept_token = load_json(os.path.join("test_vectors", "accept_token_demo.json"))
    pabom_cache = load_json(os.path.join("test_vectors", "pabom_cachekey_demo.json"))

    policy_nf_digest = accept_token.get("policy_nf_digest", "sha256:policy_nf_demo")
    resolver_id = (pabom_cache.get("result") or {}).get("resolver_id", "docf-resolver-ref/v0")
    pabom_statement_digest = (pabom_cache.get("result") or {}).get("statement_digest", "sha256:pabom_stmt_demo")
    anchor_root = (pabom_cache.get("result") or {}).get("anchor", "sha256:anchor_demo")
    log_id = (pabom_cache.get("inputs") or {}).get("expected_log_id", "scitt-demo")

    declared = {
        "sid": "sid_demo_ggc",
        "declared_attempt_budget": {"rounds": 3, "Q": 32},
        "eps_claimed": "2^-25",
        "eps_claimed_float": 2.0 ** (-25),
    }
    m_max = 25
    eps_gap = 0.0  # explicit residual failure budget for the evidence channel

    bits_lost = math.log2(m_max)
    adjusted_eps = min(1.0, declared["eps_claimed_float"] * m_max)

    # Deterministic demo signing key (DO NOT USE IN PRODUCTION).
    priv = bytes.fromhex("66" * 32)
    pub_raw, _ = _sign_ed25519(priv, b"probe")  # derive pubkey deterministically

    obj: Dict[str, Any] = {
        "type": "docf-grinding-gap-cert-v0",
        "version": "0",
        "created_at": "2026-02-26T00:00:00Z",
        "issuer": {"keyid": "ggc-demo-0", "alg": "ed25519", "public_key_ed25519_raw_b64": _b64(pub_raw)},
        "binds": {
            "policy_nf_digest": policy_nf_digest,
            "resolver_id": resolver_id,
            "pabom_statement_digest": pabom_statement_digest,
            "anchor_checkpoint_root": anchor_root,
            "log_id": log_id,
        },
        "declared": declared,
        "m_max": m_max,
        "eps_gap": eps_gap,
        "implied": {
            "bits_lost_log2m": round(bits_lost, 6),
            "adjusted_eps_float": adjusted_eps,
        },
        "notes": "Toy GGC: resolver scales eps_claimed by m_max; eps_gap budgets evidence failure (monitoring outage / attestation compromise).",
    }

    obj["digest"] = digest_obj_unsigned(obj)

    # Optional transparency anchoring: log a commitment to the GGC digest in a demo RFC9162-style log.
    # We log the UTF-8 string "DOCF-GGC-DIGEST-v0:<digest>" so verifiers can recompute the leaf hash.
    leaf_preimage_utf8 = "DOCF-GGC-DIGEST-v0:" + obj["digest"]
    preimages = [
        b"demo-leaf-0",
        b"demo-leaf-1",
        b"demo-leaf-2",
        leaf_preimage_utf8.encode("utf-8"),
        b"demo-leaf-4",
        b"demo-leaf-5",
        b"demo-leaf-6",
        b"demo-leaf-7",
    ]
    leaf_index = 3
    root_hash, path_hashes, leaf_hash, leaf_preimage_digest = merkle_root_and_path(preimages, leaf_index)

    # Deterministic demo log key (DO NOT USE IN PRODUCTION).
    log_priv = bytes.fromhex("77" * 32)
    log_pub_raw, _ = _sign_ed25519(log_priv, b"probe-log")

    checkpoint = {
        "format": "rfc9162-sth",
        "log_id": log_id,
        "tree_size": len(preimages),
        "root_hash_sha256_b64": _b64(root_hash),
        "issued_at": "2026-02-26T00:00:00Z",
        "log_public_key_ed25519_raw_b64": _b64(log_pub_raw),
    }
    # Sign the STH payload (JCS).
    msg_obj = {
        "format": checkpoint["format"],
        "log_id": checkpoint.get("log_id", ""),
        "tree_size": checkpoint["tree_size"],
        "root_hash_sha256_b64": checkpoint["root_hash_sha256_b64"],
        "issued_at": checkpoint["issued_at"],
    }
    _, sth_sig = _sign_ed25519(log_priv, jcs(msg_obj))
    checkpoint["log_signature_ed25519_b64"] = _b64(sth_sig)

    witness = {
        "schema": "docf-log-inclusion-witness-v0",
        "version": "0",
        "log": {"name": "demo-scitt-log", "url": "https://example.invalid/scitt-demo"},
        "leaf_index": leaf_index,
        "leaf_hash_sha256_b64": _b64(leaf_hash),
        "leaf_preimage_digest_sha256_hex": leaf_preimage_digest,
        "inclusion_path_sha256_b64": [_b64(x) for x in path_hashes],
        "checkpoint": checkpoint,
        "notes": "Demo inclusion witness for a leaf whose preimage contains the GGC digest string.",
    }

    obj["transparency"] = {
        "profile": "rfc9162-sth",
        "log_id": log_id,
        "leaf_preimage_utf8": leaf_preimage_utf8,
        "inclusion_witness_ref": "test_vectors/ggc_log_inclusion_witness_demo.json",
    }

    # Signature over the digest (domain separated).
    _, sig = _sign_ed25519(priv, (b"DOCF-GGC-SIG-v0\x00" + obj["digest"].encode("utf-8")))
    obj["sig"] = _b64(sig)
    return obj, witness


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit-demo", action="store_true", help="write demo JSON under test_vectors/")
    args = ap.parse_args()
    if not args.emit_demo:
        ap.print_help()
        return 2

    os.makedirs("test_vectors", exist_ok=True)
    obj, witness = emit_demo()
    out_path = os.path.join("test_vectors", "grinding_gap_certificate_demo.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True)
        f.write("\n")
    wit_path = os.path.join("test_vectors", "ggc_log_inclusion_witness_demo.json")
    with open(wit_path, "w", encoding="utf-8") as f:
        json.dump(witness, f, indent=2, sort_keys=True)
        f.write("\n")
    print(obj["digest"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
