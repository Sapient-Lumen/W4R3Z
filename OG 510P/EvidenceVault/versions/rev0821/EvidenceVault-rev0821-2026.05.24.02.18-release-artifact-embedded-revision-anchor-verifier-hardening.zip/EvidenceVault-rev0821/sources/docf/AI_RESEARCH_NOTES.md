# AI Research Notes (living)

## Current focus (v86.44-ai, 2026-02-28)
- **Cross-venue exposure is now repriced in the right domain:** Paper D adds Lemma `lem:additive_hazards_multihoming`, showing multi-homing composes additively in *hazard* space $h(\varepsilon)=-\ln(1-\varepsilon)$, yielding a tighter penalty $\log_2(H/H_\ell)$ than the homogeneous $\log_2 M$ rule.
- **Heterogeneity matters more than count:** a new deterministic microstructure demo (`make_multihoming_microstructure.py`) shows hidden bits can *far exceed* $\log_2 M$ when the local venue is stronger than at least one other venue used; outputs a paper-ready table+figure.
- **Privacy-preserving enforcement remains executable:** sealed capsules + challenge/response disputes + compact multiproofs continue as the main enforcement layer for correlation clusters and evidence publication tiers.
- **Next risks to take:** (i) sequential routing (venue choice depends on observed auction prices / time-to-finality), (ii) conservative $H$ bounds from CMBIs+GGBCs under a venue taxonomy, and (iii) cross-log gossip to make exposure discovery cheap and hard to censor.
---
# AI research notes (v86.34-ai, 2026-02-28)

## v86.34-ai updates (2026-02-28)

- Added market-binding map (Boundless / Succinct SPN / Brevis / Fermah) for where resolver inputs ($Q$ and option multipliers) come from.
- Added correlation-aware checkpointing via published clusters, plus example ledger + demo figure (`figures/cluster_checkpoint_demo.pdf`).
- Extended `eps_ledger_ref.py` with an `independent_clusters` rule and updated the ledger schema with optional `cluster` fields.
- Added Neely (2010) citation to connect replayable dual updates to virtual-queue / Lyapunov optimization.

## v86.33-ai updates (2026-02-28)

- Added a fully worked end-to-end example in Paper D: receipt bundle → resolved ε → ledger entry → epoch checkpoint.
- Added a concrete online λ demo policy + figure (tool: `online_lambda_policy_ref.py`, figure: `figures/lambda_schedule_demo.pdf`).
- Added long-term-constraint OCO references (Mahdavi–Jin–Yang 2012; Jenatton–Huang–Archambeau 2016; Zinkevich 2003).

This file is a *working scratchpad* for the multi-paper dOCF archive. It is meant to capture
what we are optimizing for, what we changed, and where the biggest ``novelty leverage'' seems to be.

## Current strongest paper tracks (my take)

### Track 1: Crypto accounting → market governance (Paper A + Paper D)
**Thesis:** retries, cancellations, beacon waiting, and micro-retries are *option surfaces* that must be explicitly priced and bounded, not hand-waved as ``just engineering''.
Paper A supplies per-proof accounting primitives; Paper D turns resolved ε-values into portfolio governance (ledgers + auditable scoring auctions).

**Why it's novel:** it connects modern prover markets (reverse auctions, locks/slashing, re-auctions) to *quantitative* soundness accounting with a public governance interface (ε budgets + λ tariffs) and optional-stopping-safe performance monitoring (e-values).

**Submission candidates:**
- *Paper A (crypto core)*: keep as theory/definitions + a small number of crisp theorems.
- *Paper D (governance/markets)*: expand into a systems+theory hybrid (mechanism design + auditing interface).

### Track 2: Portable acceptance (Paper C; Paper F)
**Thesis:** proof acceptance is becoming cacheable and reusable across orgs (proof CDNs, bridges, third-party verifiers).
This requires signed ``nutrition labels'' for acceptance assumptions + transparency artifacts that fail closed under mismatch.

**Why it's novel:** treats proof acceptance as a supply-chain object (SBOM/CT/SCITT analogies) with explicit reuse semantics.

## Changes made in v86.33-ai
- Paper D: added Section `Online risk budgets: choosing λ over time` with a replayable primal–dual update; added bibliography entries.
- Paper A: added a bridge paragraph connecting per-proof accounting objects to ε-ledger governance.

## Immediate high-impact edits to pursue next
1. **Paper D: tighten the governance story with one end-to-end worked example.**
   - A single request → selection receipt → resolved ε(b) decomposition → ledger append → checkpoint.
   - Provide 1 concrete numeric budget scenario (e.g., epoch budget 2^-40, 1M proofs/day) and show how λ would scale.

2. **Paper A: make the ``attempt-selective adversary'' (ASC) model extremely crisp.**
   - One boxed definition, one ``bits lost = log2(Q)'' corollary, and one concrete evidence-to-Q mapping (receipts/slashing/bounded windows).
   - Reduce prose and keep 2–3 main threat boundaries (FS boundary, beacon boundary, internal micro-retry boundary).

3. **Connect A ↔ D more mechanically.**
   - Define a tiny resolver API: `Resolve(manifest, receipts, policy_id) -> (ε, breakdown)` and reference it in both papers.
   - Ensure terminology is consistent: option surface, seed group, retry cap Q, bias bits.

4. **Add a minimal empirical section (even if synthetic).**
   - Use existing logs/test vectors to generate a small figure/table:
     - distribution of resolved ε across attempts,
     - cumulative budget burn under different λ schedules,
     - how much overlap-aware accounting saves vs union bound.

## Medium-term risky ideas (worth trying)
- **Dynamic λ as dual variable:** add a short theorem sketch + cite online primal–dual/OCO (already started).
- **Mechanism design with verifiable evidence:** propose a model where bidders commit to evidence profiles and are penalized for missing receipts.
- **``Risk laundering'' attacks:** show how non-portable acceptance causes silent budget resets, and why anchoring checkpoints closes the loop.

## Operational
- If you regenerate tables: run the `make_*.py` scripts that emit `_insert_*.tex` and commit the generated output.
- After substantive changes, add an entry to `ARCHIVE.md` and `CHANGELOG.md`.

### Next risky steps (high-upside)
- **Cluster commitments that auditors can enforce**: specify a deterministic cluster-id function (e.g., hash of {operator-id attestation, prover binary digest, proof params digest, hardware class attestation}) and require it in receipts to prevent cluster-splitting.
- **Empirical calibration loop**: use dispute logs / challenge events to estimate conservative independence between clusters and publish a rolling justification in checkpoints.
- **Mechanism-design splice**: treat `eps_resolved` as a verifiable attribute and analyze incentives for (i) bidding with lower risk, and (ii) misreporting attempt surfaces (penalized by receipts).


## Changes made in v86.41-ai
- **Merkle-sealed capsules:** added a canonical compact multiproof encoding for complete (padded) trees (single ordered sibling-hash list; no proofFlags/position metadata) and wired it into the capsule-opening dispute transcript.
- **Anti-griefing:** introduced an optional challenge-bond policy object sized to expected verification work (hash-count proxy), aligning capsule opening with bond+liveness practice in optimistic protocols.
- **Reproducibility:** added `make_merkle_capsule_costs.py` to regenerate the capsule-opening size table/figure with the new dense-tree multiproof line.

### Open research directions from this addition
- **Tighter bounds for dense-tree multiproof size:** characterize best/worst/expected sibling-hash counts as a function of path ordering (lexicographic clustering) rather than random indices; derive governance-friendly conservative upper bounds.
- **Bond sizing beyond hash-work:** incorporate proposer private costs (proof retrieval, storage reads, signature checks) and adversarial query patterns; consider per-epoch rate limits plus escalating bond schedules.
- **Standardization path:** map the canonical complete-tree multiproof encoding into existing formats (e.g., COSE Merkle proof containers) to make capsule openings interoperable across implementations.


## Changes made in v86.42-ai
- **Closed-form dense-tree multiproof size under path clustering:** proved (and implemented) an exact sibling-hash count for contiguous openings in complete trees: \#hashes$([a,a{+}k))$ = popcount$(a)$ + popcount$(N-(a{+}k))$. Paper D now turns this into a concrete ``design knob'' for governance: place mandatory reveal fields into a tight lexicographic namespace to keep openings small.
- **Cost model upgraded:** `make_merkle_capsule_costs.py` now plots/prints two dense compact-multiproof averages: random opened indices vs contiguous (lexicographically clustered) indices.
- **Bond pricing upgraded:** bond policy schema + reference tool now support `work_model` modes, including contig-based upper/expected work bounds (for deployments that force clustering by schema/order).
- **Replayable rate limiting:** added a minimal ticketed rate-limit mechanism (new schema + ref tool) and wired optional `rate_limit_ticket_digest_sha256` + `rate_limit_use_index` into the capsule-open challenge transcript and verifier. Uniqueness can be checked by offline replay over a JSONL ledger.
