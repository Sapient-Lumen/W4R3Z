#!/usr/bin/env python3
"""make_split_view_topology_experiment.py

Sparse-topology split-view detection experiment for Paper F/G.

Motivation:
  Prior toy models assume "gossip connects everybody." Real witness deployments
  (e.g., tile-based tlogs with witness cosigning) are often sparse overlays.
  A split-view adversary can leverage routing/partitioning to delay detection.

Model (deliberate toy, but replayable and parameterized):
  - m witnesses in an undirected overlay graph (topology choice).
  - At t=0, attacker delivers checkpoint A to group GA and checkpoint B to GB.
  - Witnesses gossip checkpoints along overlay edges.
  - Each message traversing an edge experiences:
        send delay ~ Exp(rate = gossip_rate)
        network delay ~ LogNormal(median = d_med, sigma = d_sigma)
    so edge weight = send + network.
  - A witness "detects equivocation" once it has seen both A and B at the same size.
  - Upon detection, an "ALERT" originates at the detecting witness and gossips with
    the same edge weights; we measure alert coverage times.

Metrics per trial:
  - T_detect: earliest time any witness observes both views.
  - T_alert_p50/p95: time (relative to t=0) until 50%/95% of witnesses have received ALERT.
    (Assumes alerts are broadcast as soon as detection occurs.)
  - Dual-quorum feasibility (analytic): whether both partitions have >= t cosigners.

Outputs:
  - test_vectors/pct_split_view_topology_results.json
  - LaTeX inserts:
      _insert_split_view_topology_table.tex
      _insert_split_view_alert_coverage_table.tex
  - Figures:
      pct_split_view_topology_detect_cdf.pdf
      pct_split_view_topology_alert_p95_cdf.pdf
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parent
TV = ROOT / "test_vectors"


@dataclass(frozen=True)
class TopologySpec:
    name: str
    params: Dict[str, float]


def _ensure_connected(adj: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    """If graph disconnected, add random edges until connected (smallest fix)."""
    n = adj.shape[0]

    def comps():
        seen = np.zeros(n, dtype=bool)
        comp_ids = -np.ones(n, dtype=int)
        cid = 0
        for i in range(n):
            if seen[i]:
                continue
            stack = [i]
            seen[i] = True
            comp_ids[i] = cid
            while stack:
                u = stack.pop()
                for v in np.where(adj[u] > 0)[0]:
                    if not seen[v]:
                        seen[v] = True
                        comp_ids[v] = cid
                        stack.append(v)
            cid += 1
        return cid, comp_ids

    k, comp_ids = comps()
    if k <= 1:
        return adj

    # Connect components by adding edges between random representatives.
    reps = []
    for cid in range(k):
        reps.append(int(rng.choice(np.where(comp_ids == cid)[0])))
    for i in range(1, len(reps)):
        a, b = reps[i - 1], reps[i]
        adj[a, b] = adj[b, a] = 1.0
    return adj


def _adj_complete(n: int) -> np.ndarray:
    adj = np.ones((n, n), dtype=float)
    np.fill_diagonal(adj, 0.0)
    return adj


def _adj_ring(n: int, k: int) -> np.ndarray:
    # k must be even; connect k/2 on each side
    k = int(k)
    if k % 2 == 1:
        k += 1
    half = k // 2
    adj = np.zeros((n, n), dtype=float)
    for i in range(n):
        for d in range(1, half + 1):
            j = (i + d) % n
            adj[i, j] = adj[j, i] = 1.0
    return adj


def _adj_erdos_renyi(n: int, p: float, rng: np.random.Generator) -> np.ndarray:
    m = rng.random((n, n))
    adj = (m < p).astype(float)
    adj = np.triu(adj, 1)
    adj = adj + adj.T
    return adj


def _adj_star(n: int) -> np.ndarray:
    adj = np.zeros((n, n), dtype=float)
    hub = 0
    for i in range(1, n):
        adj[hub, i] = adj[i, hub] = 1.0
    return adj


def _adj_small_world(n: int, k: int, beta: float, rng: np.random.Generator) -> np.ndarray:
    # Watts-Strogatz: start ring k, rewire edges with prob beta
    adj = _adj_ring(n, k)
    half = (k if k % 2 == 0 else k + 1) // 2
    for i in range(n):
        for d in range(1, half + 1):
            j = (i + d) % n
            if rng.random() < beta:
                # rewire i-j to i-new
                adj[i, j] = adj[j, i] = 0.0
                # choose new target not i and not already connected
                candidates = [x for x in range(n) if x != i and adj[i, x] == 0.0]
                if candidates:
                    new = int(rng.choice(candidates))
                    adj[i, new] = adj[new, i] = 1.0
    return adj


def _build_adj(n: int, spec: TopologySpec, rng: np.random.Generator) -> np.ndarray:
    if spec.name == "complete":
        return _adj_complete(n)
    if spec.name == "ring":
        return _adj_ring(n, int(spec.params.get("k", 4)))
    if spec.name == "erdos_renyi":
        adj = _adj_erdos_renyi(n, float(spec.params.get("p", 0.2)), rng)
        return _ensure_connected(adj, rng)
    if spec.name == "star":
        return _adj_star(n)
    if spec.name == "small_world":
        adj = _adj_small_world(n, int(spec.params.get("k", 4)), float(spec.params.get("beta", 0.2)), rng)
        return _ensure_connected(adj, rng)
    raise ValueError(f"unknown topology: {spec}")


def _lognormal_delay(median: float, sigma: float, rng: np.random.Generator, size=None) -> np.ndarray:
    # If X ~ LogNormal(mu, sigma), median = exp(mu).
    mu = math.log(median)
    return rng.lognormal(mean=mu, sigma=sigma, size=size)


def _edge_weights_from_adj(
    adj: np.ndarray,
    gossip_rate: float,
    d_med: float,
    d_sigma: float,
    rng: np.random.Generator,
) -> np.ndarray:
    n = adj.shape[0]
    W = np.full((n, n), np.inf, dtype=float)
    # send delays Exp(rate), network delays LogNormal
    # only where edges exist
    edges = np.where(np.triu(adj, 1) > 0)
    for i, j in zip(edges[0], edges[1]):
        send = rng.exponential(scale=1.0 / gossip_rate)
        net = float(_lognormal_delay(d_med, d_sigma, rng, size=None))
        w = send + net
        W[i, j] = W[j, i] = w
    np.fill_diagonal(W, 0.0)
    return W


def _dijkstra_multi_source(src_mask: np.ndarray, W: np.ndarray) -> np.ndarray:
    """Multi-source Dijkstra on dense weight matrix with inf for missing edges."""
    n = W.shape[0]
    dist = np.full(n, np.inf, dtype=float)
    dist[src_mask] = 0.0
    visited = np.zeros(n, dtype=bool)
    for _ in range(n):
        # choose unvisited with smallest dist
        u = int(np.argmin(np.where(visited, np.inf, dist)))
        if visited[u] or math.isinf(dist[u]):
            break
        visited[u] = True
        # relax neighbors
        w_u = W[u]
        cand = dist[u] + w_u
        dist = np.minimum(dist, cand)
    return dist


def run_experiment(
    m: int = 15,
    trials: int = 3000,
    split_ratio: float = 0.5,
    t_policy: int = 1,
    gossip_rate: float = 2.0,
    d_med: float = 0.25,
    d_sigma: float = 0.35,
    seed: int = 7,
) -> Dict:
    rng = np.random.default_rng(seed)

    specs: List[TopologySpec] = [
        TopologySpec("complete", {}),
        TopologySpec("small_world", {"k": 4, "beta": 0.15}),
        TopologySpec("erdos_renyi", {"p": 0.18}),
        TopologySpec("ring", {"k": 4}),
        TopologySpec("star", {}),
    ]

    # Client polling model: clients poll a random witness every P seconds (independent each poll).
    # We approximate client time-to-refusal as the first poll at which the polled witness has received ALERT.
    poll_intervals = [0.5, 2.0, 5.0]
    clients_per_trial = 50


    rows = []
    for spec in specs:
        det_times = []
        alert_p50 = []
        alert_p95 = []
        client_refusal = {P: [] for P in poll_intervals}
        # We also keep distributions for plotting
        for _ in range(trials):
            # attacker partition
            perm = rng.permutation(m)
            a_size = max(1, int(round(split_ratio * m)))
            GA = set(map(int, perm[:a_size]))
            GB = set(map(int, perm[a_size:]))

            # build overlay and edge weights
            adj = _build_adj(m, spec, rng)
            W = _edge_weights_from_adj(adj, gossip_rate, d_med, d_sigma, rng)

            A_mask = np.array([i in GA for i in range(m)])
            B_mask = ~A_mask

            # arrival times for both views
            tA = _dijkstra_multi_source(A_mask, W)
            tB = _dijkstra_multi_source(B_mask, W)

            both_time = np.maximum(tA, tB)
            Tdet = float(np.min(both_time))
            det_times.append(Tdet)

            # identify one earliest detecting node (argmin tie broken by smallest idx)
            det_node = int(np.argmin(both_time))

            # alert spread from det_node, but starts at time Tdet
            det_mask = np.zeros(m, dtype=bool)
            det_mask[det_node] = True
            tAlert = _dijkstra_multi_source(det_mask, W) + Tdet

            # coverage percentiles
            alert_p50.append(float(np.quantile(tAlert, 0.50)))
            alert_p95.append(float(np.quantile(tAlert, 0.95)))

            # Client time-to-refusal under polling every P seconds.
            for P in poll_intervals:
                for _c in range(clients_per_trial):
                    t_poll = float(rng.random() * P)
                    for _k in range(1000):
                        w = int(rng.integers(0, m))
                        if t_poll >= float(tAlert[w]):
                            client_refusal[P].append(t_poll)
                            break
                        t_poll += P
                    else:
                        client_refusal[P].append(t_poll)

        det = np.array(det_times)
        ap50 = np.array(alert_p50)
        ap95 = np.array(alert_p95)
        # Client time-to-refusal percentiles for each polling interval.
        client_stats = {}
        for P in poll_intervals:
            arr = np.array(client_refusal[P], dtype=float)
            client_stats[str(P)] = {
                "p50_s": float(np.quantile(arr, 0.50)),
                "p95_s": float(np.quantile(arr, 0.95)),
            }

        client_samples = {
            str(P): client_refusal[P][: min(1000, len(client_refusal[P]))]
            for P in poll_intervals
        }


        # analytic dual-quorum feasibility (initial partition-only cosigning)
        # view A has |GA| signers, view B has |GB| signers
        dual_quorum = (min(a_size, m - a_size) >= t_policy)

        rows.append({
            "topology": spec.name,
            "params": spec.params,
            "m": m,
            "t": t_policy,
            "gossip_rate": gossip_rate,
            "d_med": d_med,
            "d_sigma": d_sigma,
            "trials": trials,
            "dual_quorum_feasible": bool(dual_quorum),
            "detect_p50_s": float(np.quantile(det, 0.50)),
            "detect_p95_s": float(np.quantile(det, 0.95)),
            "alert_p50_s": float(np.quantile(ap50, 0.50)),
            "alert_p95_s": float(np.quantile(ap95, 0.95)),
            "client_refusal": client_stats,
            "client_refusal_samples_s": client_samples,
            "detect_samples_s": det_times[: min(1000, len(det_times))],  # cap for json size
            "alert95_samples_s": alert_p95[: min(1000, len(alert_p95))],
        })

    return {"meta": {"seed": seed}, "results": rows}


def _write_latex_tables(results: List[Dict], out_dir: Path) -> None:
    # Main topology table
    df = pd.DataFrame([{
        "Topology": r["topology"],
        "Detect p50 (s)": r["detect_p50_s"],
        "Detect p95 (s)": r["detect_p95_s"],
        "Alert p50 (s)": r["alert_p50_s"],
        "Alert p95 (s)": r["alert_p95_s"],
    } for r in results]).sort_values("Detect p50 (s)")

    def fmt(x): 
        return f"{x:.3f}"

    lines = []
    lines.append(r"\begin{table}[t]")
    lines.append(r"\centering")
    m0 = int(results[0]["m"])
    t0 = int(results[0]["t"])
    gr0 = float(results[0]["gossip_rate"])
    lines.append(rf"\caption{{Sparse-topology split-view toy experiment ($m={m0}$, $t={t0}$, gossip rate $={gr0:.2f}$/s, edge delays Exp$+${{\small LogNormal}}). Reported are p50/p95 detection times (any witness sees both views) and alert coverage times (time until 50\%/95\% of witnesses receive an alert).}}")
    lines.append(r"\label{tab:split-view-topology}")
    lines.append(r"\begin{tabular}{lrrrr}")
    lines.append(r"\toprule")
    lines.append(r"Topology & Detect p50 & Detect p95 & Alert p50 & Alert p95 \\")
    lines.append(r"\midrule")
    for _, row in df.iterrows():
        lines.append(f"{row['Topology']} & {fmt(row['Detect p50 (s)'])} & {fmt(row['Detect p95 (s)'])} & {fmt(row['Alert p50 (s)'])} & {fmt(row['Alert p95 (s)'])} \\\\")
    lines.append(r"\bottomrule")
    lines.append(r"\end{tabular}")
    lines.append(r"\end{table}")
    (out_dir / "_insert_split_view_topology_table.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")

    # Also a simpler alert-focused table (for paperG)
    lines2 = []
    lines2.append(r"\begin{table}[t]")
    lines2.append(r"\centering")
    lines2.append(r"\caption{Alert coverage times from the split-view topology experiment (p50/p95 over trials).}")
    lines2.append(r"\label{tab:split-view-alert-coverage}")
    lines2.append(r"\begin{tabular}{lrr}")
    lines2.append(r"\toprule")
    lines2.append(r"Topology & Alert p50 (s) & Alert p95 (s) \\")
    lines2.append(r"\midrule")
    for _, row in df.iterrows():
        lines2.append(f"{row['Topology']} & {fmt(row['Alert p50 (s)'])} & {fmt(row['Alert p95 (s)'])} \\\\")
    lines2.append(r"\bottomrule")
    lines2.append(r"\end{tabular}")
    lines2.append(r"\end{table}")
    (out_dir / "_insert_split_view_alert_coverage_table.tex").write_text("\n".join(lines2) + "\n", encoding="utf-8")
    # Client refusal table (p95 time-to-refusal) for multiple polling intervals.
    poll_cols = ["0.5", "2.0", "5.0"]
    lines3 = []
    lines3.append(r"\begin{table}[t]")
    lines3.append(r"\centering")
    lines3.append(r"\caption{Toy client time-to-refusal (p95) when clients poll a random witness every $P$ seconds and refuse once the polled witness has received an ALERT.}")
    lines3.append(r"\label{tab:split-view-client-refusal}")
    lines3.append(r"\begin{tabular}{lrrr}")
    lines3.append(r"\toprule")
    lines3.append(r"Topology & $P=0.5$s & $P=2$s & $P=5$s \\")
    lines3.append(r"\midrule")
    for _, row in df.iterrows():
        # find original result row to access client stats
        rr = next(r for r in results if r["topology"] == row["Topology"])
        vals = []
        for pc in poll_cols:
            vals.append(fmt(rr["client_refusal"][pc]["p95_s"]))
        lines3.append(f"{row['Topology']} & {vals[0]} & {vals[1]} & {vals[2]} \\\\")
    lines3.append(r"\bottomrule")
    lines3.append(r"\end{tabular}")
    lines3.append(r"\end{table}")
    (out_dir / "_insert_split_view_client_refusal_table.tex").write_text("\n".join(lines3) + "\n", encoding="utf-8")



def _plot_cdfs(results: List[Dict], out_dir: Path) -> None:
    # Detection CDFs
    plt.figure(figsize=(6.0, 4.0))
    for r in results:
        xs = np.array(r["detect_samples_s"], dtype=float)
        xs = np.sort(xs)
        ys = np.arange(1, len(xs)+1)/len(xs)
        plt.plot(xs, ys, label=r["topology"])
    plt.xlabel("Detection time (s)")
    plt.ylabel("CDF")
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(out_dir / "pct_split_view_topology_detect_cdf.pdf")
    plt.close()

    # Alert p95 CDFs (distribution across trials of the 95% coverage time)
    plt.figure(figsize=(6.0, 4.0))
    for r in results:
        xs = np.array(r["alert95_samples_s"], dtype=float)
        xs = np.sort(xs)
        ys = np.arange(1, len(xs)+1)/len(xs)
        plt.plot(xs, ys, label=r["topology"])
    plt.xlabel("Alert coverage time to 95% of witnesses (s)")
    plt.ylabel("CDF")
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(out_dir / "pct_split_view_topology_alert_p95_cdf.pdf")
    plt.close()

    # Client refusal CDFs (P=2s) across sampled clients.
    plt.figure(figsize=(6.0, 4.0))
    for r in results:
        xs = np.array(r.get("client_refusal_samples_s", {}).get("2.0", []), dtype=float)
        if len(xs) == 0:
            continue
        xs = np.sort(xs)
        ys = np.arange(1, len(xs)+1)/len(xs)
        plt.plot(xs, ys, label=r["topology"])
    plt.xlabel("Client time-to-refusal (s), polling P=2s")
    plt.ylabel("CDF")
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(out_dir / "pct_split_view_topology_client_refusal_cdf.pdf")
    plt.close()


def main() -> None:
    TV.mkdir(exist_ok=True)
    out = run_experiment()
    (TV / "pct_split_view_topology_results.json").write_text(json.dumps(out, indent=2), encoding="utf-8")

    _write_latex_tables(out["results"], ROOT)
    _plot_cdfs(out["results"], ROOT)


if __name__ == "__main__":
    main()
