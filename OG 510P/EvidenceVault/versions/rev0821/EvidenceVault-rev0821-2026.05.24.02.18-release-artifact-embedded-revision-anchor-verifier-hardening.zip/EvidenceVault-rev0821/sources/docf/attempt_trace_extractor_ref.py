#!/usr/bin/env python3
"""
attempt_trace_extractor_ref.py

Reference attempt-trace extractor for dOCF.

This tool demonstrates Theorem~\ref{thm:attempt-extract} on a *stack-disciplined*
attempt-trace skeleton (Definition~\ref{def:attempt-trace-abi}):
it parses enter/exit/retry/choose events, builds a parse tree for retry topology,
and compiles a conservative series--parallel attempt expression
(Definition~\ref{def:attempt-expr}) together with its evaluated bound
\llbracket E_g \rrbracket.

The extractor also supports a practical "seed-locking" knob via a declared
\texttt{resample_cut}: regions outside the cut are treated as *seed-locked*
(no new public-coin draw for a given seed group), which can strictly reduce the
attempt-scope retry multiplier Q_g without weakening liveness.

This is intentionally minimal and deterministic (no cryptographic verification).
Production deployments must bind traces and per-region bounds to authenticated
receipts (e.g., log inclusion proofs) and enforce canonicalization
(RFC 8785 JCS / CBOR).

Usage:
  python3 attempt_trace_extractor_ref.py --in test_vectors/attempt_trace_demo.json
  python3 attempt_trace_extractor_ref.py --emit
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set


###############################################################################
# Utilities
###############################################################################


def _jdump(obj: Any) -> str:
    return json.dumps(obj, indent=2, sort_keys=True) + "\n"


def _fail(msg: str) -> None:
    raise SystemExit(f"[attempt_trace_extractor_ref] {msg}")


def load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


###############################################################################
# Expression IR (JSON-compatible)
###############################################################################


Expr = Dict[str, Any]


def const(v: int) -> Expr:
    return {"op": "const", "value": int(v)}


def var(name: str) -> Expr:
    return {"op": "var", "name": name}


def add(a: Expr, b: Expr) -> Expr:
    return {"op": "add", "left": a, "right": b}


def mul(a: Expr, b: Expr) -> Expr:
    return {"op": "mul", "left": a, "right": b}


def mincap(e: Expr, cap: int) -> Expr:
    return {"op": "min", "cap": int(cap), "expr": e}


def is_const(e: Expr, v: Optional[int] = None) -> bool:
    return e.get("op") == "const" and (v is None or int(e.get("value")) == int(v))


def simplify(e: Expr) -> Expr:
    """Small, safe simplifier that preserves conservativeness exactly."""
    op = e.get("op")
    if op in ("const", "var"):
        return e
    if op == "add":
        l = simplify(e["left"])
        r = simplify(e["right"])
        if is_const(l, 0):
            return r
        if is_const(r, 0):
            return l
        if is_const(l) and is_const(r):
            return const(int(l["value"]) + int(r["value"]))
        return {"op": "add", "left": l, "right": r}
    if op == "mul":
        l = simplify(e["left"])
        r = simplify(e["right"])
        if is_const(l, 0) or is_const(r, 0):
            return const(0)
        if is_const(l, 1):
            return r
        if is_const(r, 1):
            return l
        if is_const(l) and is_const(r):
            return const(int(l["value"]) * int(r["value"]))
        return {"op": "mul", "left": l, "right": r}
    if op == "min":
        inner = simplify(e["expr"])
        cap = int(e["cap"])
        if is_const(inner):
            return const(min(int(inner["value"]), cap))
        return {"op": "min", "cap": cap, "expr": inner}
    return e


def eval_expr(e: Expr, env: Dict[str, int]) -> int:
    op = e.get("op")
    if op == "const":
        return int(e["value"])
    if op == "var":
        name = e["name"]
        if name not in env:
            _fail(f"missing var bound for '{name}'")
        return int(env[name])
    if op == "add":
        return eval_expr(e["left"], env) + eval_expr(e["right"], env)
    if op == "mul":
        return eval_expr(e["left"], env) * eval_expr(e["right"], env)
    if op == "min":
        return min(eval_expr(e["expr"], env), int(e["cap"]))
    _fail(f"unknown expr op: {op}")


###############################################################################
# Trace parsing and compilation
###############################################################################


@dataclass
class Node:
    v: str
    id: str
    tid: str = "main"
    children: List["Node"] = field(default_factory=list)
    saw_retry: bool = False
    saw_choose: bool = False


def parse_trace(events: List[Dict[str, Any]]) -> Node:
    """Parse attempt-trace events into a tree.

    Supports:
      - T2 stack discipline: a single implicit task (tid='main') with well-nested enter/exit.
      - T3 structured concurrency: events may carry a task id 'tid' and may include
        fork/join boundaries. Each task's enter/exit must be well-nested; fork creates a
        new task rooted at a synthetic node that becomes a child of the current scope;
        join asserts that the child task has fully exited (stack back to its root).
    """
    root = Node(v="__root__", id="__root__", tid="__root__")
    stacks: Dict[str, List[Node]] = {"main": [root]}
    closed_tasks: Set[str] = set()

    def _get_tid(ev: Dict[str, Any]) -> str:
        tid = ev.get("tid", "main")
        if isinstance(tid, int):
            return str(tid)
        if isinstance(tid, str):
            return tid
        _fail("event tid must be string or int")
        return "main"

    for i, ev in enumerate(events):
        op = ev.get("op")
        v = ev.get("v")
        eid = ev.get("id")
        tid = _get_tid(ev)

        if tid in closed_tasks:
            _fail(f"event {i}: task '{tid}' already joined/closed")

        if op in ("enter", "exit", "retry", "choose", "fork", "join"):
            if not isinstance(v, str) or not isinstance(eid, str):
                _fail(f"event {i}: expected string fields v/id")
        else:
            _fail(f"event {i}: unknown op '{op}'")

        if tid not in stacks:
            _fail(f"event {i}: unknown task '{tid}' (missing fork?)")
        stack = stacks[tid]

        if op == "enter":
            n = Node(v=v, id=eid, tid=tid)
            stack[-1].children.append(n)
            stack.append(n)

        elif op == "exit":
            if len(stack) <= 1:
                _fail(f"event {i}: exit with empty stack")
            top = stack.pop()
            if top.v != v or top.id != eid:
                _fail(
                    f"event {i}: exit({v},{eid}) does not match enter({top.v},{top.id})"
                )

        elif op == "retry":
            if len(stack) <= 1:
                _fail(f"event {i}: retry with empty stack")
            top = stack[-1]
            if top.v != v or top.id != eid:
                _fail(
                    f"event {i}: retry({v},{eid}) must apply to current region on stack (got {top.v},{top.id})"
                )
            top.saw_retry = True

        elif op == "choose":
            # Minimal support: record that a choice happened in this scope.
            if len(stack) <= 1:
                _fail(f"event {i}: choose with empty stack")
            stack[-1].saw_choose = True

        elif op == "fork":
            # Spawn a child task; b encodes the child tid.
            child = ev.get("b")
            if child is None:
                _fail(f"event {i}: fork requires b=child_tid")
            child_tid = str(child)
            if child_tid in stacks or child_tid in closed_tasks:
                _fail(f"event {i}: fork reuses existing tid '{child_tid}'")
            # Attach a synthetic node to represent this task's root inside the parent scope.
            tnode = Node(v="__task__", id=f"task:{child_tid}", tid=child_tid)
            stack[-1].children.append(tnode)
            stacks[child_tid] = [tnode]

        elif op == "join":
            child = ev.get("b")
            if child is None:
                _fail(f"event {i}: join requires b=child_tid")
            child_tid = str(child)
            if child_tid not in stacks:
                _fail(f"event {i}: join references unknown tid '{child_tid}'")
            if len(stacks[child_tid]) != 1:
                _fail(f"event {i}: join({child_tid}) before child task has fully exited")
            del stacks[child_tid]
            closed_tasks.add(child_tid)

    # After processing, only the main task should remain, and it must be balanced.
    if "main" not in stacks or len(stacks) != 1:
        # Any unjoined child tasks are an error (incomplete trace).
        missing = [k for k in stacks.keys() if k != "main"]
        _fail(f"trace incomplete: unjoined tasks {missing}")
    if len(stacks["main"]) != 1:
        _fail("trace is not stack-disciplined: missing exits in main task")
    return root


def compile_expr(
    n: Node,
    var_bounds: Dict[str, int],
    resample_cut: Set[str],
    caps: Dict[str, int],
) -> Expr:
    """Compile a parse tree into a conservative series--parallel attempt expression."""
    # Compile children in series (disjoint retry tickets), conservatively as addition.
    child_exprs = [compile_expr(c, var_bounds, resample_cut, caps) for c in n.children]
    if not child_exprs:
        body = const(1)
    else:
        body = child_exprs[0]
        for ce in child_exprs[1:]:
            body = add(body, ce)
    body = simplify(body)

    if n.v == "__root__":
        return body

    # Region leaf contribution: Q_v if v resamples this seed group; otherwise 1.
    q_leaf = var(n.v) if (n.v in resample_cut) else const(1)

    # If the region can retry we treat it as nesting: Q_v * body.
    # If it never retries, the region contributes exactly 1 draw of g (for this skeleton),
    # so we drop q_leaf and keep body (which accounts for nested retry regions).
    if n.saw_retry:
        e = mul(q_leaf, body)
    else:
        e = body

    # Optional cap at region.
    cap = caps.get(n.v)
    if cap is not None:
        e = mincap(e, cap)
    return simplify(e)


###############################################################################
# Demo
###############################################################################


def demo_trace() -> Dict[str, Any]:
    # Skeleton: auction retries in series with a nested dispute->in_round retry.
    return {
        "schema": "docf_attempt_trace/v0",
        "seed_group": "g_attempt",
        "var_bounds": {"auction": 6, "dispute": 1, "in_round": 2},
        "resample_cut": ["auction", "dispute", "in_round"],
        "seed_locked": ["in_round"],
        "events": [
            {"op": "enter", "v": "root", "id": "R"},
            {"op": "enter", "v": "auction", "id": "A"},
            {"op": "retry", "v": "auction", "id": "A"},
            {"op": "retry", "v": "auction", "id": "A"},
            {"op": "exit", "v": "auction", "id": "A"},
            {"op": "enter", "v": "dispute", "id": "D"},
            {"op": "enter", "v": "in_round", "id": "I"},
            {"op": "retry", "v": "in_round", "id": "I"},
            {"op": "exit", "v": "in_round", "id": "I"},
            {"op": "retry", "v": "dispute", "id": "D"},
            {"op": "exit", "v": "dispute", "id": "D"},
            {"op": "exit", "v": "root", "id": "R"},
        ],
    }


def run(in_obj: Dict[str, Any]) -> Dict[str, Any]:
    if in_obj.get("schema") not in ("docf_attempt_trace/v0", "docf_attempt_trace/v1"):
        _fail("expected schema 'docf_attempt_trace/v0' or 'docf_attempt_trace/v1'")
    seed_group = in_obj.get("seed_group", "g")
    var_bounds = in_obj.get("var_bounds", {})
    if not isinstance(var_bounds, dict):
        _fail("var_bounds must be an object mapping region->int")
    var_bounds_int: Dict[str, int] = {}
    for k, v in var_bounds.items():
        if not isinstance(k, str) or not isinstance(v, int) or v < 1:
            _fail("var_bounds must map string->positive int")
        var_bounds_int[k] = v

    events = in_obj.get("events", [])
    if not isinstance(events, list):
        _fail("events must be a list")
    root = parse_trace(events)

    caps = in_obj.get("caps", {})
    if caps is None:
        caps = {}
    if not isinstance(caps, dict):
        _fail("caps must be an object mapping region->int")
    caps_int: Dict[str, int] = {}
    for k, v in caps.items():
        if not isinstance(k, str) or not isinstance(v, int) or v < 1:
            _fail("caps must map string->positive int")
        caps_int[k] = v

    resample_cut = set(in_obj.get("resample_cut", list(var_bounds_int.keys())))
    seed_locked = set(in_obj.get("seed_locked", []))
    resample_cut_locked = set(resample_cut) - set(seed_locked)

    expr_full = compile_expr(root, var_bounds_int, resample_cut, caps_int)
    q_full = eval_expr(expr_full, var_bounds_int)

    expr_locked = compile_expr(root, var_bounds_int, resample_cut_locked, caps_int)
    q_locked = eval_expr(expr_locked, var_bounds_int)

    return {
        "schema": "docf_attempt_trace_extract_report/v0",
        "seed_group": seed_group,
        "var_bounds": var_bounds_int,
        "resample_cut": sorted(list(resample_cut)),
        "seed_locked": sorted(list(seed_locked)),
        "expr": expr_full,
        "Q_eval": q_full,
        "expr_seed_locked": expr_locked,
        "Q_eval_seed_locked": q_locked,
        "notes": [
            "Reference demo of attempt-trace extraction.",
            "Production systems must authenticate traces and bind caps to receipts.",
        ],
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="in_path", default=None, help="input docf_attempt_trace/v0 JSON")
    ap.add_argument(
        "--out", dest="out_path", default=None, help="write report JSON here (default: stdout)"
    )
    ap.add_argument("--emit", action="store_true", help="emit deterministic demo input+output")
    args = ap.parse_args()

    if args.emit:
        demo_in = demo_trace()
        demo_out = run(demo_in)
        sys.stdout.write(_jdump({"demo_in": demo_in, "demo_out": demo_out}))
        return

    if not args.in_path:
        ap.print_help()
        return
    in_obj = load_json(args.in_path)
    out_obj = run(in_obj)
    if args.out_path:
        with open(args.out_path, "w", encoding="utf-8") as f:
            f.write(_jdump(out_obj))
    else:
        sys.stdout.write(_jdump(out_obj))


if __name__ == "__main__":
    main()
