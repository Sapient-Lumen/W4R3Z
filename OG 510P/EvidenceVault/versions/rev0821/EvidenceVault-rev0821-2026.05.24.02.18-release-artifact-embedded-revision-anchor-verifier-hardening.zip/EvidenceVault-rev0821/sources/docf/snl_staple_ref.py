#!/usr/bin/env python3
"""snl_staple_ref.py (v86.6)

Create a transparency-log inclusion staple for a Security Nutrition Label (SNL).

Motivation:
  - An SNL is a cacheable auditor output.
  - To make auditor behavior externally monitorable (and reduce equivocation),
    we can require that accepted SNL digests be committed to an append-only
    transparency log (CT-style Merkle tree).

This reference tool emits a *deterministic demo* staple:
  - builds a small RFC9162/RFC6962-style Merkle tree over fixed leaves
  - inserts the SNL digest (ASCII) as one leaf preimage
  - produces a docf-log-inclusion-witness-v0 object as the witness
  - (NEW v86.5) attaches Sigsum-style witness cosignatures over the checkpoint
  - wraps it in a docf-snl-staple-v0 container binding the SNL digest

Usage:
  python3 snl_staple_ref.py --snl <snl.json> --out <snl_staple.json>
  python3 snl_staple_ref.py --emit-demo
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
from typing import Any, Dict, List, Tuple

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from docf_ref_tools_common import jcs, load_json, emit_json


def b64e(b: bytes) -> str:
    return base64.b64encode(b).decode("utf-8")


def ct_leaf_hash(preimage: bytes) -> bytes:
    return hashlib.sha256(b"\x00" + preimage).digest()


def ct_node_hash(left: bytes, right: bytes) -> bytes:
    return hashlib.sha256(b"\x01" + left + right).digest()

def largest_power_of_two_less_than(n: int) -> int:
    k = 1
    while (k << 1) < n:
        k <<= 1
    return k

def mth(leaf_hashes: List[bytes]) -> bytes:
    """Merkle Tree Hash per RFC9162 Section 2.1.1 (for n>=1)."""
    n = len(leaf_hashes)
    assert n >= 1
    if n == 1:
        return leaf_hashes[0]
    k = largest_power_of_two_less_than(n)
    return ct_node_hash(mth(leaf_hashes[:k]), mth(leaf_hashes[k:]))

def subproof(m: int, leaf_hashes: List[bytes], b: bool) -> List[bytes]:
    """SUBPROOF(m, D_n, b) per RFC9162 Section 2.1.4.1."""
    n = len(leaf_hashes)
    assert 0 < m <= n
    if m == n:
        return [] if b else [mth(leaf_hashes)]
    k = largest_power_of_two_less_than(n)
    if m <= k:
        return subproof(m, leaf_hashes[:k], b) + [mth(leaf_hashes[k:])]
    # m > k
    return subproof(m - k, leaf_hashes[k:], False) + [mth(leaf_hashes[:k])]

def consistency_proof(m: int, leaf_hashes: List[bytes]) -> List[bytes]:
    """PROOF(m, D_n) per RFC9162 Section 2.1.4.1."""
    n = len(leaf_hashes)
    assert 0 < m < n
    return subproof(m, leaf_hashes, True)


def merkle_root_and_path(leaf_hashes: List[bytes], leaf_index: int) -> Tuple[bytes, List[bytes]]:
    """Return (root, inclusion_path) for CT-style left-balanced tree."""
    assert 0 <= leaf_index < len(leaf_hashes)
    path: List[bytes] = []
    idx = leaf_index
    level = list(leaf_hashes)
    while len(level) > 1:
        nxt: List[bytes] = []
        for i in range(0, len(level), 2):
            if i + 1 == len(level):
                nxt.append(level[i])
                if i == idx:
                    idx = len(nxt) - 1
            else:
                left, right = level[i], level[i + 1]
                parent = ct_node_hash(left, right)
                nxt.append(parent)
                if i == idx:
                    path.append(right)
                    idx = len(nxt) - 1
                elif i + 1 == idx:
                    path.append(left)
                    idx = len(nxt) - 1
        level = nxt
    return level[0], path


def _seed(tag: bytes) -> bytes:
    return hashlib.sha256(tag).digest()[:32]


def demo_log_keypair() -> Tuple[bytes, bytes]:
    seed = _seed(b"docf-demo-snl-tlog-key")
    sk = Ed25519PrivateKey.from_private_bytes(seed)
    pk = sk.public_key().public_bytes_raw()
    return seed, pk


def demo_witness_keypair(i: int) -> Tuple[bytes, bytes, str]:
    wid = f"docf-demo-witness-{i}"
    seed = _seed(f"docf-demo-snl-tlog-witness-{i}".encode("utf-8"))
    sk = Ed25519PrivateKey.from_private_bytes(seed)
    pk = sk.public_key().public_bytes_raw()
    return seed, pk, wid


def checkpoint_payload(checkpoint: Dict[str, Any]) -> bytes:
    """Return the canonical JCS payload that the log signs (and witnesses cosign)."""
    msg_obj = {
        "format": checkpoint["format"],
        "log_id": checkpoint.get("log_id", ""),
        "tree_size": checkpoint["tree_size"],
        "root_hash_sha256_b64": checkpoint["root_hash_sha256_b64"],
        "issued_at": checkpoint["issued_at"],
    }
    return jcs(msg_obj)


def make_checkpoint(
    log_id: str,
    tree_size: int,
    root_hash_b64: str,
    issued_at: str,
    log_pub_b64: str,
    sk_seed: bytes,
) -> Dict[str, Any]:
    msg_obj = {
        "format": "docf-demo-checkpoint-v0",
        "log_id": log_id,
        "tree_size": tree_size,
        "root_hash_sha256_b64": root_hash_b64,
        "issued_at": issued_at,
    }
    msg = jcs(msg_obj)
    sk = Ed25519PrivateKey.from_private_bytes(sk_seed)
    sig = sk.sign(msg)
    chk = dict(msg_obj)
    chk["log_public_key_ed25519_raw_b64"] = log_pub_b64
    chk["log_signature_ed25519_b64"] = b64e(sig)
    return chk


def make_witness_cosignatures(checkpoint: Dict[str, Any], n: int = 3, quorum: int = 2) -> Dict[str, Any]:
    """Create deterministic witness cosignatures over the checkpoint payload."""
    payload = checkpoint_payload(checkpoint)
    payload_sha = hashlib.sha256(payload).hexdigest()

    witnesses: List[Dict[str, Any]] = []
    for i in range(n):
        seed, pk_raw, wid = demo_witness_keypair(i)
        sk = Ed25519PrivateKey.from_private_bytes(seed)
        sig = sk.sign(payload)
        witnesses.append(
            {
                "witness_id": wid,
                "public_key_ed25519_raw_b64": b64e(pk_raw),
                "signature_ed25519_b64": b64e(sig),
            }
        )

    return {
        "schema": "docf-witness-cosignatures-v0",
        "version": "0",
        "payload_format": "docf-demo-checkpoint-v0-jcs",
        "payload_sha256_hex": payload_sha,
        "required_quorum": quorum,
        "witnesses": witnesses,
        "notes": [
            "Sigsum-style witness cosignatures over the Signed Tree Head (STH) payload.",
            "This is a deterministic demo quorum; production deployments would manage witness trust roots out-of-band.",
        ],
    }


def build_demo_staple(snl: Dict[str, Any]) -> Dict[str, Any]:
    snl_digest = snl.get("digest", "")
    if not isinstance(snl_digest, str) or not snl_digest:
        raise ValueError("SNL missing digest")

    # Deterministic leaves: 7 fixed + 1 SNL digest at index 3
    fixed: List[bytes | None] = [
        b"sha256:demo-leaf-0",
        b"sha256:demo-leaf-1",
        b"sha256:demo-leaf-2",
        None,  # will be SNL digest
        b"sha256:demo-leaf-4",
        b"sha256:demo-leaf-5",
        b"sha256:demo-leaf-6",
        b"sha256:demo-leaf-7",
    ]
    leaf_index = 3
    fixed[leaf_index] = snl_digest.encode("utf-8")
    preimages = fixed  # type: ignore
    leaf_preimage = preimages[leaf_index]

    leaf_hashes = [ct_leaf_hash(x) for x in preimages]
    root, path = merkle_root_and_path(leaf_hashes, leaf_index)

    log_id = "docf-demo-snl-tlog-v0"
    sk_seed, pk_raw = demo_log_keypair()

    # Two checkpoints to enable offline append-only checks:
    #  - chk1 commits the first 4 leaves (prefix tree)
    #  - chk2 commits the full 8-leaf tree (current tree head)
    issued_at_1 = "2026-02-27T00:00:00Z"
    issued_at_2 = "2026-02-27T00:01:00Z"

    root4 = mth(leaf_hashes[:4])
    chk1 = make_checkpoint(
    log_id=log_id,
    tree_size=4,
    root_hash_b64=b64e(root4),
    issued_at=issued_at_1,
    log_pub_b64=b64e(pk_raw),
    sk_seed=sk_seed,
    )

    chk2 = make_checkpoint(
    log_id=log_id,
    tree_size=len(leaf_hashes),
    root_hash_b64=b64e(root),
    issued_at=issued_at_2,
    log_pub_b64=b64e(pk_raw),
    sk_seed=sk_seed,
    )

    witness_cosign = make_witness_cosignatures(chk2, n=3, quorum=2)

    witness = {
        "schema": "docf-log-inclusion-witness-v1",
        "version": "1",
        "log": {
            "log_id": log_id,
            "profile_id": "ct/rfc9162-sha256-ed25519",
            "profile_digest_sha256_hex": hashlib.sha256(b"ct/rfc9162-sha256-ed25519").hexdigest(),
            "notes": [
                "Demo log profile; semantics mirror RFC9162 inclusion proofs over SHA-256 and Ed25519 checkpoints.",
            ],
        },
        "checkpoint": chk2,

        # Optional RFC9162 consistency witness: proves chk2 is an append-only extension of chk1.
        "consistency_witness": {
            "schema": "docf-log-consistency-witness-v0",
            "version": "0",
            "log": {
                "log_id": log_id,
                "profile_id": "ct/rfc9162-sha256-ed25519",
                "profile_digest_sha256_hex": hashlib.sha256(b"ct/rfc9162-sha256-ed25519").hexdigest(),
                "notes": ["Demo log profile; semantics mirror RFC9162 Merkle consistency proofs over SHA-256."]
            },
            "first_checkpoint": chk1,
            "second_checkpoint": chk2,
            "consistency_path_sha256_b64": [b64e(x) for x in consistency_proof(4, leaf_hashes)],
            "notes": "Deterministic demo consistency witness from tree_size=4 to tree_size=8."
        },
        "witness_cosignatures": witness_cosign,
        "leaf_index": leaf_index,
        "leaf_preimage_digest_sha256_hex": hashlib.sha256(leaf_preimage).hexdigest(),
        "leaf_hash_sha256_b64": b64e(leaf_hashes[leaf_index]),
        "inclusion_path_sha256_b64": [b64e(x) for x in path],
        "notes": [
            "Leaf preimage is the ASCII SNL digest string.",
            "This is a deterministic demo witness for papers; not a production log.",
        ],
    }

    staple = {
        "schema": "docf-snl-staple-v1",
        "version": "1",
        "snl_digest": snl_digest,
        "witness": witness,
        "notes": [
            "Staple binds an SNL digest to a transparency-log inclusion proof.",
            "Verifiers can require a staple to reduce auditor equivocation.",
            "Optional witness cosignatures reduce reliance on a single log operator for checkpoint correctness.",
        ],
    }
    return staple


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--snl", type=str, default="")
    ap.add_argument("--out", type=str, default="")
    ap.add_argument("--emit-demo", action="store_true")
    args = ap.parse_args()

    if args.emit_demo:
        tv = os.path.join(os.path.dirname(__file__), "test_vectors")
        os.makedirs(tv, exist_ok=True)
        snl_path = os.path.join(tv, "security_nutrition_label_demo_ok.json")
        snl = load_json(snl_path)
        staple = build_demo_staple(snl)

        out_path = os.path.join(tv, "snl_staple_demo.json")
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(staple, f, indent=2, ensure_ascii=False)
            f.write("\n")

        emit_json(staple)
        print(f"Wrote {out_path}")
        return

    if not args.snl or not args.out:
        ap.print_help()
        return

    snl = load_json(args.snl)
    staple = build_demo_staple(snl)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(staple, f, indent=2, ensure_ascii=False)
        f.write("\n")


if __name__ == "__main__":
    main()
