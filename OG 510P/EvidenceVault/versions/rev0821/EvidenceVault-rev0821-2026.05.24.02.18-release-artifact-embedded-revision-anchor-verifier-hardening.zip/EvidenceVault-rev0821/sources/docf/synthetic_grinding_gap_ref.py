#!/usr/bin/env python3
"""Synthetic grinding-gap evaluation for dOCF.

This tool illustrates how hidden (unreceipted) micro-retry factors translate
into *invisible* soundness loss under a conservative union bound.

It writes:
  - _insert_synthetic_grinding_gap_table.tex (LaTeX table)
  - test_vectors/synthetic_grinding_gap_demo.json (machine-readable output)

The model is intentionally simple:
  base per-attempt failure probability p = 2^{-base_bits}
  observed attempts R_obs = rounds * Q_per_round
  true attempts R_true = R_obs * hidden_multiplier
  effective bits = -log2(min(1, R*p))

The "gap" is the overstatement if an evaluator uses R_obs while the system
actually executed R_true attempts.
"""

import argparse
import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path


@dataclass
class Scenario:
    name: str
    rounds: int
    q_per_round: int
    hidden_multiplier: int


def eff_bits(base_bits: float, R: int) -> float:
    """Return -log2(min(1, R*2^{-base_bits}))"""
    if R <= 0:
        return float("inf")
    # bits = max(0, base_bits - log2 R)
    return max(0.0, base_bits - math.log2(R))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-bits", type=float, default=80.0)
    ap.add_argument("--out-tex", default="_insert_synthetic_grinding_gap_table.tex")
    ap.add_argument("--out-json", default="test_vectors/synthetic_grinding_gap_demo.json")
    args = ap.parse_args()

    base_bits = float(args.base_bits)

    scenarios = [
        Scenario("Hard RT slot", rounds=1, q_per_round=10, hidden_multiplier=1),
        Scenario("Hard RT slot", rounds=1, q_per_round=10, hidden_multiplier=5),
        Scenario("Hard RT slot", rounds=1, q_per_round=10, hidden_multiplier=20),
        Scenario("Hard RT slot", rounds=1, q_per_round=10, hidden_multiplier=50),
        Scenario("Re-auction", rounds=5, q_per_round=3, hidden_multiplier=1),
        Scenario("Re-auction", rounds=5, q_per_round=3, hidden_multiplier=5),
        Scenario("Re-auction", rounds=5, q_per_round=3, hidden_multiplier=20),
        Scenario("Deep re-auction", rounds=8, q_per_round=5, hidden_multiplier=1),
        Scenario("Deep re-auction", rounds=8, q_per_round=5, hidden_multiplier=5),
        Scenario("Deep re-auction", rounds=8, q_per_round=5, hidden_multiplier=20),
    ]

    rows = []
    for sc in scenarios:
        R_obs = sc.rounds * sc.q_per_round
        R_true = R_obs * sc.hidden_multiplier
        bits_obs = eff_bits(base_bits, R_obs)
        bits_true = eff_bits(base_bits, R_true)
        gap = max(0.0, bits_obs - bits_true)
        rows.append(
            {
                **asdict(sc),
                "R_obs": R_obs,
                "R_true": R_true,
                "bits_observed": round(bits_obs, 1),
                "bits_true": round(bits_true, 1),
                "gap_bits": round(gap, 1),
            }
        )

    # Write JSON
    out_json = Path(args.out_json)
    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps({"base_bits": base_bits, "rows": rows}, indent=2))

    # Write LaTeX table
    out_tex = Path(args.out_tex)
    tex = []
    tex.append("\\begin{table}[t]")
    tex.append("\\centering")
    tex.append("\\small")
    tex.append("\\begin{tabular}{p{2.6cm} r r r r r r}")
    tex.append("\\toprule")
    tex.append("Scenario & rounds & $Q$/round & $m$ & $R_{\\mathrm{obs}}$ & bits(obs) & bits(true) \\")
    tex.append("\\midrule")
    for r in rows:
        tex.append(
            f"{r['name']} & {r['rounds']} & {r['q_per_round']} & {r['hidden_multiplier']} & {r['R_obs']} & {r['bits_observed']:.1f} & {r['bits_true']:.1f} \\")
    tex.append("\\bottomrule")
    tex.append("\\end{tabular}")
    tex.append(
        "\\caption{Synthetic grinding-gap sweep. We fix per-attempt error $p=2^{-\\lambda}$ with $\\lambda="
        + f"{base_bits:.0f}"
        + "$ and vary (i) auction rounds and declared per-round retries $Q$, and (ii) an unreceipted internal micro-retry factor $m$. The observed effective soundness (bits(obs)) uses $R_{\\mathrm{obs}}=\\mathrm{rounds}\\cdot Q$, while the true effective soundness (bits(true)) uses $R_{\\mathrm{true}}=m\\cdot R_{\\mathrm{obs}}$. The silent overstatement is $\\log_2 m$ bits (capped at 0 when the union bound saturates). dOCF's receipt-complete interfaces are designed to make $m$ externally bounded so that the resolver never relies on hidden retries.}")
    tex.append("\\label{tab:synthetic-grinding-gap}")
    tex.append("\\end{table}")

    out_tex.write_text("\n".join(tex) + "\n")


if __name__ == "__main__":
    main()
