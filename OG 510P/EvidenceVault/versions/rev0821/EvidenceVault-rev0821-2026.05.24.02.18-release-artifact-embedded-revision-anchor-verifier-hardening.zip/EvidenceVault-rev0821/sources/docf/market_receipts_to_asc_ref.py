#!/usr/bin/env python3
"""Reference tool: derive an Attempt Session Certificate (ASC) from receipt-complete market logs.

This is intentionally conservative and "fail-closed": if it cannot prove attempt completeness
from the provided receipts, it refuses to guess.

Input: a JSON file that contains (at minimum):
  - sid: session/request identifier
  - attempt_receipts: list of attempt events (timeout/cancel/proved/failed)

Output: an ASC JSON object compatible with the paper's Figure on receipts->ASC.

This tool is a reference scaffold; deployments should bind events to on-chain receipts or
transparency-log inclusion proofs.
"""

import argparse
import hashlib
import json
from typing import Any, Dict, List


def jcs_bytes(x: Any) -> bytes:
    # RFC 8785-like canonicalization (best-effort): sorted keys + compact separators.
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_hex_pref(x: Any) -> str:
    return "sha256:" + hashlib.sha256(jcs_bytes(x)).hexdigest()


STATUS_MAP = {
    "timeout": "timeout",
    "cancel": "cancelled",
    "cancelled": "cancelled",
    "slashed": "slashed",
    "proved": "proved",
    "success": "proved",
    "failed": "failed",
    "reject": "failed",
    "unknown": "unknown",
}


def derive_asc(receipts: Dict[str, Any]) -> Dict[str, Any]:
    sid = receipts.get("sid")
    if not sid:
        raise ValueError("missing required field: sid")

    attempt_events = receipts.get("attempt_receipts")
    if not isinstance(attempt_events, list) or not attempt_events:
        raise ValueError("missing required field: attempt_receipts (non-empty list)")

    attempts: List[Dict[str, Any]] = []
    seen = set()
    for ev in attempt_events:
        if not isinstance(ev, dict):
            raise ValueError("attempt_receipts must be a list of objects")
        aid = ev.get("attempt_id")
        if not isinstance(aid, str) or not aid:
            raise ValueError("each attempt receipt must include attempt_id (string)")
        if aid in seen:
            # fail-closed: duplicates are ambiguous without a total order
            raise ValueError(f"duplicate attempt_id in receipts: {aid}")
        seen.add(aid)
        raw = ev.get("event") or ev.get("status")
        if not isinstance(raw, str) or not raw:
            raise ValueError(f"attempt {aid} missing event/status")
        status = STATUS_MAP.get(raw.lower())
        if status is None:
            raise ValueError(f"attempt {aid}: unknown event/status {raw}")

        witnessed = bool(ev.get("receipt_ref") or ev.get("tx") or ev.get("log_receipt"))
        a: Dict[str, Any] = {"id": aid, "status": status, "witnessed": witnessed}
        if "proof_ref" in ev:
            a["proof_ref"] = ev["proof_ref"]
        if "receipt_ref" in ev:
            a["receipt_ref"] = ev["receipt_ref"]
        attempts.append(a)

    asc: Dict[str, Any] = {
        "type": "attempt_session_certificate",
        "sid": sid,
        "Q_declared": receipts.get("Q_declared", len(attempts)),
        "Q_observed": len(attempts),
        "attempts": attempts,
        "meta": {
            "source": "market_receipts_to_asc_ref.py",
            "receipt_root": receipts.get("receipt_root"),
        },
        "sig": "base64:...",
    }

    # Add a deterministic digest for stapling.
    asc["digest"] = sha256_hex_pref({k: v for k, v in asc.items() if k not in ["sig"]})
    return asc


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="in_path", default="market_session_receipts_example.json")
    ap.add_argument("--out", dest="out_path", default="-")
    args = ap.parse_args()

    receipts = json.load(open(args.in_path, "r", encoding="utf-8"))
    asc = derive_asc(receipts)

    out = json.dumps(asc, indent=2, sort_keys=False) + "\n"
    if args.out_path == "-":
        print(out, end="")
    else:
        with open(args.out_path, "w", encoding="utf-8") as f:
            f.write(out)


if __name__ == "__main__":
    main()
