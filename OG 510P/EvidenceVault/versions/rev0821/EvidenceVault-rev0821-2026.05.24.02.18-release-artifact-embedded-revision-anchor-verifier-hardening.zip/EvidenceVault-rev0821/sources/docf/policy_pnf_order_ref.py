#!/usr/bin/env python3
"""policy_pnf_order_ref.py

Reference-grade sketch for dOCF Policy Normal Form (PNF) dominance checks
and PNF-join negotiation.

v48 notes:
- Dominance/join is now complete for the totalized PNF emitted by
  policy_normalize_ref.py (all optional fields expanded with top defaults).
- subset atoms support a '*' wildcard meaning "universal allow-set".

Not production code. Deterministic and intentionally conservative.
"""

from __future__ import annotations

import argparse
from typing import Any, Dict, Tuple, List

from docf_ref_tools_common import load_json, emit_json, jcs, sha256_hex

AL_RANK = {"AL0": 0, "AL1": 1, "AL2": 2, "AL3": 3, "AL4": 4}
PROFILE_RANK = {"Bronze": 0, "Silver": 1, "Gold": 2}
WILDCARD_ANY = "*"


def atom_key(a: Dict[str, Any]) -> Tuple[str, str, str]:
    return (str(a.get("pred")), str(a.get("path")), str(a.get("op")))


def _rank_enum(v: Any) -> int | None:
    if isinstance(v, str) and v in AL_RANK:
        return AL_RANK[v]
    if isinstance(v, str) and v in PROFILE_RANK:
        return PROFILE_RANK[v]
    return None


def _to_allowset(v: Any) -> Tuple[bool, set[str]]:
    """Return (is_universal, set)."""
    if not isinstance(v, list):
        return (True, set())
    xs = {str(x) for x in v if isinstance(x, str)}
    if WILDCARD_ANY in xs or len(xs) == 0:
        return (True, set())
    return (False, xs)


def dominates_atom(a_strong: Dict[str, Any], a_weak: Dict[str, Any]) -> Tuple[bool, str]:
    """Return (dominates?, rule_name). Requires keys already match."""

    pred = a_weak.get("pred")
    vS = a_strong.get("value")
    vW = a_weak.get("value")

    if pred == "ge":
        rS, rW = _rank_enum(vS), _rank_enum(vW)
        if rS is not None and rW is not None:
            return (rS >= rW, "ge_enum")
        try:
            return (float(vS) >= float(vW), "ge_numeric")
        except Exception:
            return (False, "ge_type_error")

    if pred == "le":
        try:
            return (float(vS) <= float(vW), "le_numeric")
        except Exception:
            return (False, "le_type_error")

    if pred == "subset":
        # Semantics: observed set E must satisfy E ⊆ allowset.
        # Stronger policies have smaller allow-sets.
        uniS, setS = _to_allowset(vS)
        uniW, setW = _to_allowset(vW)
        if uniS and uniW:
            return (True, "subset_both_universal")
        if uniS and not uniW:
            # Strong says "allow anything" -> cannot dominate a stricter allow-set.
            return (False, "subset_strong_universal")
        if not uniS and uniW:
            return (True, "subset_weak_universal")
        return (setS.issubset(setW), "subset_allowset")

    if pred == "eq":
        # Monotone booleans: requiring True is stronger than requiring False.
        if isinstance(vW, bool) and isinstance(vS, bool):
            if vW is True:
                return (vS is True, "eq_bool_require")
            return (True, "eq_bool_vacuous")
        # Otherwise treat as literal equality.
        return (vS == vW, "eq_literal")

    return (False, "unknown_pred")


def implies(pnf_strong: Dict[str, Any], pnf_weak: Dict[str, Any]) -> Dict[str, Any]:
    s_atoms = {atom_key(a): (i, a) for i, a in enumerate(pnf_strong.get("atoms", []))}
    mappings: List[Dict[str, Any]] = []
    for j, aW in enumerate(pnf_weak.get("atoms", [])):
        k = atom_key(aW)
        if k not in s_atoms:
            return {"result": False, "reason": f"missing_atom:{k}", "mappings": mappings}
        i, aS = s_atoms[k]
        ok, rule = dominates_atom(aS, aW)
        mappings.append({"weak_atom": j, "strong_atom": i, "rule": rule, "ok": ok})
        if not ok:
            return {"result": False, "reason": f"fails:{k}", "mappings": mappings}
    return {"result": True, "reason": "all_atoms_dominated", "mappings": mappings}


def join(p1: Dict[str, Any], p2: Dict[str, Any]) -> Dict[str, Any]:
    """PNF-join: weakest policy that is stronger than both p1 and p2 (conjunction)."""

    a1 = {atom_key(a): a for a in p1.get("atoms", [])}
    a2 = {atom_key(a): a for a in p2.get("atoms", [])}
    keys = sorted(set(a1.keys()) | set(a2.keys()))
    out_atoms: List[Dict[str, Any]] = []
    conflicts: List[str] = []

    for k in keys:
        if k in a1 and k not in a2:
            out_atoms.append(a1[k])
            continue
        if k in a2 and k not in a1:
            out_atoms.append(a2[k])
            continue

        A, B = a1[k], a2[k]
        pred = A.get("pred")
        vA, vB = A.get("value"), B.get("value")

        if pred == "ge":
            rA, rB = _rank_enum(vA), _rank_enum(vB)
            if rA is not None and rB is not None:
                out = vA if rA >= rB else vB
                out_atoms.append({**A, "value": out})
            else:
                out_atoms.append({**A, "value": max(float(vA), float(vB))})
            continue

        if pred == "le":
            out_atoms.append({**A, "value": min(float(vA), float(vB))})
            continue

        if pred == "subset":
            uniA, setA = _to_allowset(vA)
            uniB, setB = _to_allowset(vB)
            if uniA and uniB:
                out_atoms.append({**A, "value": [WILDCARD_ANY]})
            elif uniA and not uniB:
                out_atoms.append({**A, "value": sorted(setB)})
            elif uniB and not uniA:
                out_atoms.append({**A, "value": sorted(setA)})
            else:
                out_atoms.append({**A, "value": sorted(list(setA & setB))})
            continue

        if pred == "eq":
            if isinstance(vA, bool) and isinstance(vB, bool):
                # Conjunction of requirements: require if either requires.
                out_atoms.append({**A, "value": (vA or vB)})
                continue
            if vA == vB:
                out_atoms.append(A)
                continue
            conflicts.append(f"eq_conflict:{k}")
            out_atoms.append(A)
            continue

        conflicts.append(f"unknown_pred:{k}")
        out_atoms.append(A)

    out = {
        "type": "docf-policy-normal-form-v0",
        "version": "0",
        "source_policy_format": "docf-policy-v0",
        "jcs_canonical": True,
        "atoms": out_atoms,
        "notes": "PNF-join output (reference sketch).",
    }
    if conflicts:
        out["conflicts"] = conflicts
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--strong", help="Strong PNF JSON (docf-policy-normal-form-v0)")
    ap.add_argument("--weak", help="Weak PNF JSON (docf-policy-normal-form-v0)")
    ap.add_argument("--join_a", help="PNF JSON A for join")
    ap.add_argument("--join_b", help="PNF JSON B for join")
    args = ap.parse_args()

    if args.strong and args.weak:
        S = load_json(args.strong)
        W = load_json(args.weak)
        res = implies(S, W)
        out = {
            "type": "docf-policy-implication-check-v0",
            "version": "0",
            "strong_policy_nf_digest": "sha256:" + sha256_hex(jcs(S)),
            "weak_policy_nf_digest": "sha256:" + sha256_hex(jcs(W)),
            **res,
        }
        emit_json(out)
        return

    if args.join_a and args.join_b:
        A = load_json(args.join_a)
        B = load_json(args.join_b)
        J = join(A, B)
        out = {
            "type": "docf-policy-join-report-v0",
            "version": "0",
            "inputs": [
                {"name": "A", "policy_nf_digest": "sha256:" + sha256_hex(jcs(A))},
                {"name": "B", "policy_nf_digest": "sha256:" + sha256_hex(jcs(B))},
            ],
            "output_policy_nf_digest": "sha256:" + sha256_hex(jcs(J)),
            "output_pnf": J,
        }
        emit_json(out)
        return

    ap.error("Provide --strong/--weak or --join_a/--join_b")


if __name__ == "__main__":
    main()
