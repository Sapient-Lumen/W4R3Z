#!/usr/bin/env python3
"""threat_conformance_ref.py

Executable threat conformance harness for the dOCF archive.

Given an input artifact (a manifest, a PAO, or another dOCF JSON object), the
harness:
  - infers a conservative set of "evidence features" present in the artifact,
  - evaluates each threat in threat_catalog.json under a fail-closed rule
    (a threat is mitigated only if all required features are present),
  - reports mitigated vs open threats, and
  - optionally evaluates a tiny governance policy.

This is a *reference-grade* tool: its purpose is determinism and reviewability,
not completeness.

Usage:
  python3 threat_conformance_ref.py --in path/to/artifact.json
  python3 threat_conformance_ref.py --in ... --policy path/to/policy.json --out report.json

Policy format (toy):
  {
    "min_L": 2,
    "min_D": 0,
    "require_mitigated": ["T2", "T9"],
    "deny_if_open": ["T1"]
  }
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple

from docf_ref_tools_common import jcs, load_json

ROOT = Path(__file__).resolve().parent


def sha256_pref(b: bytes) -> str:
    return "sha256:" + hashlib.sha256(b).hexdigest()


def _get(obj: Any, path: str, default: Any = None) -> Any:
    cur = obj
    for p in path.split("."):
        if not isinstance(cur, dict) or p not in cur:
            return default
        cur = cur[p]
    return cur


def infer_features(obj: Any) -> Set[str]:
    feats: Set[str] = set()

    # Explicit override.
    if isinstance(obj, dict) and isinstance(obj.get("docf_features"), list):
        for f in obj["docf_features"]:
            if isinstance(f, str):
                feats.add(f)

    if not isinstance(obj, dict):
        return feats

    # Detect PAO.
    otype = obj.get("type")
    if isinstance(otype, str) and "portable_acceptance" in otype:
        # PAO binds policy+resolver digests.
        if obj.get("policy_nf_digest") and obj.get("resolver_id") and obj.get("pabom_cache_key"):
            feats.add("pao.policy_resolver_bound")
        # Transparency evidence: receipts imply inclusion, but do not by themselves prevent split-view.
        anchor = obj.get("anchor") or {}
        receipts = obj.get("receipts") or []
        if isinstance(anchor, dict) and anchor.get("checkpoint_root") and isinstance(receipts, list) and len(receipts) > 0:
            feats.add("transparency.inclusion")
        # Stronger non-equivocation requires an explicit witnessed checkpoint bundle.
        if obj.get("witnessed_checkpoint_bundle_digest") or obj.get("witnessed_checkpoint_bundle_ref"):
            feats.add("transparency.witnessed_checkpoint")
        feats.add("pao.present")

    # Gate satisfaction objects: admission decisions can be monitorable and, when witnessed, safely reusable.
    if isinstance(otype, str) and "tpv_gate_satisfaction" in otype:
        feats.add("gate_satisfaction.present")
        if obj.get("anchor"):
            feats.add("transparency.inclusion")
        if obj.get("witnessed_checkpoint_bundle_digest") or obj.get("witnessed_checkpoint_bundle_ref"):
            feats.add("transparency.witnessed_checkpoint")

    # Manifest-like objects: identify obligations.
    obligations_list = []
    if isinstance(obj.get("obligations"), list):
        obligations_list = obj["obligations"]
    elif isinstance(obj.get("obligations"), dict):
        # Older toy layout.
        obligations_list = []

    for o in obligations_list:
        if not isinstance(o, dict):
            continue
        oid = str(o.get("id", ""))
        if "ABI" in oid:
            feats.add("fs.abi_pinned")
        if "TLOG" in oid or "REKOR" in oid:
            feats.add("transparency.inclusion")
        if "PROV.SLSA" in oid or "SLSA" in oid:
            feats.add("abi.provenance_pinned")
        if "BTCC" in oid:
            feats.add("coins.btcc")
        if "BLAI" in oid:
            feats.add("coins.blai")
        if "FSQ" in oid or "FS.QUERY" in oid:
            feats.add("fs.query_receipts")

    # Nested toy manifest features.
    if _get(obj, "transcript.abi.abi_digest") is not None:
        feats.add("fs.abi_pinned")

    if _get(obj, "public_coins.beacon.btcc_required", False):
        feats.add("coins.btcc")

    if _get(obj, "public_coins.beacon.blai_required", False):
        feats.add("coins.blai")

    # Cancellation mitigation: k-scalar or explicit repetitions.
    k = _get(obj, "glue.k")
    if isinstance(k, int) and k >= 2:
        feats.add("glue.k_scalar_or_reps")

    glue_scalars = _get(obj, "obligations.cancellation.glue_scalars")
    if isinstance(glue_scalars, int) and glue_scalars >= 2:
        feats.add("glue.k_scalar_or_reps")

    if _get(obj, "obligations.cancellation") is not None and _get(obj, "transcript.abi.abi_digest") is not None:
        # If cancellation is declared and ABI is pinned, allow the feature.
        feats.add("glue.k_scalar_or_reps")

    # Grinding / attempt accounting.
    gb = obj.get("grinding_budget")
    if isinstance(gb, dict):
        if gb.get("Q_bound") is not None:
            feats.add("attempt.q_bounded")
        ek = str(gb.get("evidence_kind", ""))
        if "withheld" not in ek and "witness" in ek:
            feats.add("attempt.non_withholdable")
            feats.add("transparency.witnessed_checkpoint")
        elif "transparency" in ek or "log" in ek:
            feats.add("transparency.inclusion")
    elif isinstance(gb, (int, float)):
        feats.add("attempt.q_bounded")

    # Direct attempt-trace hints.
    if obj.get("attempt_dag_root") or _get(obj, "grinding_budget.attempt_dag_root"):
        feats.add("attempt.q_bounded")

    # Witnessed checkpoint bundles.
    if obj.get("witnessed_checkpoint") or obj.get("witnessed_checkpoint_bundle"):
        feats.add("transparency.witnessed_checkpoint")

    # FS query receipts hints.
    if obj.get("fs_query_receipts") or _get(obj, "transcript.fs_queries") or _get(obj, "transcript.fs_queries_log_root"):
        feats.add("fs.query_receipts")

    # Folding set binding.
    if obj.get("fold_set_commitment") or obj.get("fold_set_merkle_root"):
        feats.add("fold.set_commitment")

    # Channel non-equivocation.
    ch = obj.get("channels") or {}
    if isinstance(ch, dict) and ch.get("model") in ("broadcast", "bulletin_board"):
        feats.add("channels.broadcast_or_log")

    # Defamation / blame dispute objects.
    if obj.get("dispute_map") or obj.get("blame_dispute"):
        feats.add("blame.dispute_objects")

    return feats


def grades_from_features(feats: Set[str], obj: Any) -> Tuple[int, int]:
    # Trace level L (very coarse, conservative).
    L = 0
    if "transparency.witnessed_checkpoint" in feats:
        L = 3
    elif "transparency.inclusion" in feats:
        L = 2
    elif "pao.anchor_witnessed" in feats:
        L = 2
    elif "fs.abi_pinned" in feats or "abi.provenance_pinned" in feats:
        L = 1

    # Determinism grade D.
    D = 0
    if isinstance(obj, dict):
        det = obj.get("determinism") or obj.get("determinism_level")
        if isinstance(det, str) and det.startswith("D") and det[1:].isdigit():
            D = int(det[1:])
        if obj.get("determinism_attestation") or _get(obj, "certificates.determinism"):
            D = max(D, 2)
    return (L, D)


def evaluate_catalog(feats: Set[str], catalog: Dict[str, Any]) -> Tuple[List[str], List[str]]:
    mitigated: List[str] = []
    open_: List[str] = []
    for t in catalog.get("threats", []):
        tid = str(t.get("id"))
        req = t.get("requires_features") or []
        ok = True
        for r in req:
            if r not in feats:
                ok = False
                break
        (mitigated if ok else open_).append(tid)
    mitigated.sort()
    open_.sort()
    return mitigated, open_


def eval_policy(report: Dict[str, Any], policy: Dict[str, Any]) -> Dict[str, Any]:
    L = int(_get(report, "grades.L", 0))
    D = int(_get(report, "grades.D", 0))
    min_L = int(policy.get("min_L", 0))
    min_D = int(policy.get("min_D", 0))
    require_mitigated = set(policy.get("require_mitigated", []) or [])
    deny_if_open = set(policy.get("deny_if_open", []) or [])

    mitigated = set(report.get("mitigated", []) or [])
    open_ = set(report.get("open", []) or [])

    reasons: List[str] = []
    ok = True
    if L < min_L:
        ok = False
        reasons.append(f"L<{min_L}")
    if D < min_D:
        ok = False
        reasons.append(f"D<{min_D}")

    missing = sorted(list(require_mitigated - mitigated))
    if missing:
        ok = False
        reasons.append("missing_mitigations:" + ",".join(missing))

    blocked = sorted(list(deny_if_open & open_))
    if blocked:
        ok = False
        reasons.append("blocked_open:" + ",".join(blocked))

    return {
        "accept": ok,
        "min_L": min_L,
        "min_D": min_D,
        "require_mitigated": sorted(list(require_mitigated)),
        "deny_if_open": sorted(list(deny_if_open)),
        "reasons": reasons,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="in_path", required=True, help="Input manifest/PAO JSON")
    ap.add_argument("--catalog", default=str(ROOT / "threat_catalog.json"))
    ap.add_argument("--policy", default=None)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()

    obj = load_json(args.in_path)
    catalog = load_json(args.catalog)

    feats = infer_features(obj)
    mitigated, open_ = evaluate_catalog(feats, catalog)
    L, D = grades_from_features(feats, obj)

    report: Dict[str, Any] = {
        "format": "docf-threat-conformance-report-v0",
        "created_at": "2026-02-26T00:00:00Z",
        "input": {
            "path": args.in_path,
            "digest": sha256_pref(jcs(obj)),
        },
        "catalog_digest": sha256_pref(jcs(catalog)),
        "features": sorted(list(feats)),
        "mitigated": mitigated,
        "open": open_,
        "grades": {"L": L, "D": D},
    }

    if args.policy:
        pol = load_json(args.policy)
        report["policy_result"] = eval_policy(report, pol)

    out_txt = json.dumps(report, indent=2, sort_keys=True)
    if args.out:
        Path(args.out).write_text(out_txt + "\n", encoding="utf-8")
    else:
        print(out_txt)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
