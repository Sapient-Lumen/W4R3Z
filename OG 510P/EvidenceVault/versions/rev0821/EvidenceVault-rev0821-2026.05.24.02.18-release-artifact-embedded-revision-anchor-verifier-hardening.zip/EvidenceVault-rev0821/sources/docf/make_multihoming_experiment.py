#!/usr/bin/env python3
"""
make_multihoming_experiment.py

Generates:
  - `_insert_multihoming_inflation_table.tex`
  - `pct_multihoming_hidden_bits.pdf`

A small, transparent calculation showing how multi-homing (posting the same statement
across multiple markets) amplifies false-acceptance probability, even if each market
locally discloses its own retry surface.

Model:
  - Each *attempt* has base soundness error eps0 (e.g., 2^-80).
  - Each market exposes r attempts (local Attempt DAG / receipts).
  - The prover multi-homes across M markets and settles wherever a false accept occurs.
  - Assuming independence across attempts, global false accept probability:
        eps_global = 1 - (1 - eps0)^(M*r)
    while a single market would price:
        eps_local  = 1 - (1 - eps0)^r

For small eps0, bits lost ≈ log2(M).

This script intentionally uses only elementary math; it is deterministic.
"""
from __future__ import annotations
import argparse
import math
from typing import List, Tuple

def prob_after(a: int, eps0: float) -> float:
    # exact under independence; safe for tiny eps0 using exp/log
    # 1 - (1-eps0)^a = 1 - exp(a * ln(1-eps0))
    return -math.expm1(a * math.log1p(-eps0))

def lg2(x: float) -> float:
    return math.log(x, 2.0)

def fmt_eps(eps: float) -> str:
    # print as <=2^-b with one decimal, matching archive style
    b = -lg2(eps)
    return f"<=2^{{-{b:.1f}}}"

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--eps0_bits", type=float, default=80.0, help="base attempt epsilon as 2^-eps0_bits")
    ap.add_argument("--r_per_market", type=int, default=8, help="exposed attempts per market (local receipts)")
    ap.add_argument("--markets", type=str, default="1,2,3,5,10,20", help="comma-separated market counts")
    ap.add_argument("--out_table", type=str, default="_insert_multihoming_inflation_table.tex")
    ap.add_argument("--out_plot", type=str, default="pct_multihoming_hidden_bits.pdf")
    args = ap.parse_args()

    eps0 = 2.0 ** (-args.eps0_bits)
    r = args.r_per_market
    Ms: List[int] = [int(x.strip()) for x in args.markets.split(",") if x.strip()]

    # prepare rows
    rows: List[Tuple[int,int,int,float,float,float]] = []
    for M in Ms:
        a_local = r
        a_global = M * r
        eps_local = prob_after(a_local, eps0)
        eps_global = prob_after(a_global, eps0)
        bits_local = -lg2(eps_local)
        bits_global = -lg2(eps_global)
        hidden_bits = bits_local - bits_global
        rows.append((M, r, a_global, bits_local, bits_global, hidden_bits))

    # write LaTeX table
    with open(args.out_table, "w", encoding="utf-8") as f:
        f.write(r"\begin{tabular}{r r r r r r}" + "\n")
        f.write(r"\toprule" + "\n")
        f.write(r"Markets $M$ & Attempts/market $r$ & Total attempts $A$ & Local bits & Global bits & Hidden bits \\" + "\n")
        f.write(r"\midrule" + "\n")
        for (M, r, A, bL, bG, h) in rows:
            f.write(f"{M} & {r} & {A} & {bL:.2f} & {bG:.2f} & {h:.2f} \\\\\n")
        f.write(r"\bottomrule" + "\n")
        f.write(r"\end{tabular}" + "\n")

    # plot: hidden bits vs M
    try:
        import matplotlib.pyplot as plt
        xs = [r[0] for r in rows]
        ys = [r[5] for r in rows]
        plt.figure()
        plt.plot(xs, ys, marker="o")
        plt.xscale("log", base=10)
        plt.xlabel("Markets M (log scale)")
        plt.ylabel("Hidden bits (local - global)")
        plt.title("Multi-homing hidden soundness bits recovered by cross-market exposure")
        plt.tight_layout()
        plt.savefig(args.out_plot)
        plt.close()
    except Exception as e:
        # plotting is optional; table is the main artifact
        pass

if __name__ == "__main__":
    main()
