#!/usr/bin/env python3
"""transparency_log_ref.py

Reference: a minimal Certificate-Transparency-style Merkle log for dOCF artifacts.

Implements:
- RFC 6962 / RFC 9162 hashing convention:
    Leaf hash:  SHA256(0x00 || leaf_bytes)
    Node hash:  SHA256(0x01 || left || right)

- Inclusion proofs for a leaf under a tree root.
- RFC 9162-style Merkle *consistency proofs* between two tree sizes.

This is intentionally small and self-contained. It is used by Paper F (PCT) and
the PCT bundle reference tool to demonstrate that:
  (1) anyone can verify inclusion for a stapled digest, and
  (2) anyone can verify append-only growth via consistency proofs.

Usage (demo):
  # Emit a toy log + inclusion proofs:
  ./transparency_log_ref.py --emit --out test_vectors/pct_log_demo.json

  # Verify a proof inside an emitted log:
  ./transparency_log_ref.py --verify --in test_vectors/pct_log_demo.json --kind attempt_dag_root

  # Self-test consistency proof generation + verification:
  ./transparency_log_ref.py --selftest-consistency
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import random
from typing import Any, Dict, List, Tuple


def _sha256(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()


def _canon(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def leaf_hash(leaf_bytes: bytes) -> bytes:
    return _sha256(b"\x00" + leaf_bytes)


def node_hash(left: bytes, right: bytes) -> bytes:
    return _sha256(b"\x01" + left + right)


def merkle_root(leaf_datas: List[bytes]) -> bytes:
    """Merkle Tree Hash (MTH) over leaf_datas, with odd nodes promoted."""
    leaves = [leaf_hash(d) for d in leaf_datas]
    if not leaves:
        return _sha256(b"")
    level = leaves
    while len(level) > 1:
        nxt: List[bytes] = []
        for i in range(0, len(level), 2):
            if i + 1 == len(level):
                nxt.append(level[i])
            else:
                nxt.append(node_hash(level[i], level[i + 1]))
        level = nxt
    return level[0]


def inclusion_proof(leaf_datas: List[bytes], index: int) -> List[bytes]:
    """Return sibling hashes along the inclusion path for leaf `index`."""
    leaves = [leaf_hash(d) for d in leaf_datas]
    n = len(leaves)
    if index < 0 or index >= n:
        raise ValueError("bad leaf index")
    path: List[bytes] = []
    level = leaves
    idx = index
    while len(level) > 1:
        nxt: List[bytes] = []
        for i in range(0, len(level), 2):
            if i + 1 == len(level):
                nxt.append(level[i])
            else:
                nxt.append(node_hash(level[i], level[i + 1]))
        if idx % 2 == 0:
            sib = idx + 1
            if sib < len(level):
                path.append(level[sib])
        else:
            path.append(level[idx - 1])
        idx //= 2
        level = nxt
    return path


def verify_inclusion(leaf_bytes: bytes, index: int, tree_size: int, path: List[bytes], root: bytes) -> bool:
    """Verify inclusion with the same odd-node promotion rule used above."""
    h = leaf_hash(leaf_bytes)
    idx = int(index)
    n = int(tree_size)
    p = list(path)
    pi = 0

    while n > 1:
        # If this is the last node in an odd-width level, it is carried up.
        if (n % 2 == 1) and (idx == n - 1):
            idx //= 2
            n = (n + 1) // 2
            continue

        if pi >= len(p):
            return False

        sib = p[pi]
        pi += 1
        if idx % 2 == 0:
            h = node_hash(h, sib)
        else:
            h = node_hash(sib, h)

        idx //= 2
        n = (n + 1) // 2

    if pi != len(p):
        return False
    return h == root


def _lsb(x: int) -> int:
    return x & 1


def _is_power_of_two(x: int) -> bool:
    return x > 0 and (x & (x - 1) == 0)


def _largest_power_of_two_smaller_than(n: int) -> int:
    if n <= 1:
        return 0
    k = 1 << (n.bit_length() - 1)
    if k == n:
        k >>= 1
    return k


def consistency_proof_v2(leaf_datas: List[bytes], first: int) -> List[bytes]:
    """Generate RFC 9162 minimal consistency proof between `first` and `n=len(leaf_datas)`.

    Returns a list of node hashes (bytes). Verifier uses `first_hash` (old root)
    and `second_hash` (new root) plus this list to check append-only growth.
    """
    n = len(leaf_datas)
    if not (0 < first < n):
        raise ValueError("need 0 < first < n")

    def subproof(m: int, datas: List[bytes], known: bool) -> List[bytes]:
        # RFC 9162 Section 2.1.4.1: SUBPROOF(m, D_m, true) = {}
        # Otherwise: SUBPROOF(m, D_m, false) = {MTH(D_m)}
        if m == len(datas):
            return [] if known else [merkle_root(datas)]
        k = _largest_power_of_two_smaller_than(len(datas))
        if m <= k:
            return subproof(m, datas[:k], known) + [merkle_root(datas[k:])]
        else:
            return subproof(m - k, datas[k:], False) + [merkle_root(datas[:k])]

    return subproof(first, leaf_datas, True)


def verify_consistency_v2(first: int, first_hash: bytes, second: int, second_hash: bytes, consistency_path: List[bytes]) -> bool:
    """Verify an RFC 9162 consistency proof (Section 2.1.4.2)."""
    if first == second:
        return (first_hash == second_hash) and (len(consistency_path) == 0)

    if len(consistency_path) == 0:
        return False

    path = list(consistency_path)

    # Step 2: if first is a power of 2, prepend first_hash.
    if _is_power_of_two(first):
        path = [first_hash] + path

    fn = first - 1
    sn = second - 1

    # Step 4: if LSB(fn) is set, right-shift equally until LSB(fn) not set.
    if _lsb(fn):
        while _lsb(fn):
            fn >>= 1
            sn >>= 1

    fr = path[0]
    sr = path[0]

    # Step 6: iterate over subsequent c.
    for c in path[1:]:
        if sn == 0:
            return False

        if _lsb(fn) or (fn == sn):
            fr = node_hash(c, fr)
            sr = node_hash(c, sr)
            if not _lsb(fn):
                while (not _lsb(fn)) and (fn != 0):
                    fn >>= 1
                    sn >>= 1
        else:
            sr = node_hash(sr, c)

        fn >>= 1
        sn >>= 1

    return (fr == first_hash) and (sr == second_hash) and (sn == 0)


def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def _unb64(s: str) -> bytes:
    return base64.b64decode(s.encode("ascii"))


def emit_demo(out_path: str) -> None:
    # demo leaves: three core PCT digests + a binding cert digest
    demo = {
        "attempt_dag_root": {"kind": "attempt_dag_root", "digest": "sha256:aa" * 16},
        "eps_ledger_root": {"kind": "eps_ledger_root", "digest": "sha256:bb" * 16},
        "perf_envelope_root": {"kind": "perf_envelope_root", "digest": "sha256:cc" * 16},
        "market_session_cert": {"kind": "market_session_cert", "digest": "sha256:dd" * 16},
    }
    entries = [demo[k] for k in ["attempt_dag_root", "eps_ledger_root", "perf_envelope_root", "market_session_cert"]]
    leaf_datas = [_canon(e) for e in entries]
    root = merkle_root(leaf_datas)

    inc = {}
    for i, e in enumerate(entries):
        inc[e["kind"]] = {
            "leaf_index": i,
            "leaf": e,
            "leaf_bytes_b64": _b64(_canon(e)),
            "inclusion_path_b64": [_b64(x) for x in inclusion_proof(leaf_datas, i)],
        }

    # Also include a consistency proof from size 2 -> size 4 as a tiny example.
    first = 2
    first_hash = merkle_root(leaf_datas[:first])
    second = len(leaf_datas)
    proof = consistency_proof_v2(leaf_datas, first)

    out = {
        "tree_size": len(entries),
        "root_hash_b64": _b64(root),
        "entries": entries,
        "inclusion_proofs": inc,
        "consistency_demo": {
            "first": first,
            "first_hash_b64": _b64(first_hash),
            "second": second,
            "second_hash_b64": _b64(root),
            "consistency_path_b64": [_b64(x) for x in proof],
        },
    }

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print(f"wrote {out_path}")


def verify_demo(inp: str, kind: str) -> None:
    j = json.loads(open(inp, "r", encoding="utf-8").read())
    entries = j["entries"]
    leaf_datas = [_canon(e) for e in entries]
    root = _unb64(j["root_hash_b64"])

    pr = j["inclusion_proofs"][kind]
    leaf_bytes = _unb64(pr["leaf_bytes_b64"])
    index = pr["leaf_index"]
    path = [_unb64(x) for x in pr["inclusion_path_b64"]]

    ok = verify_inclusion(leaf_bytes, index, len(entries), path, root)
    print("inclusion", kind, "OK" if ok else "FAIL")

    # verify demo consistency, if present
    if "consistency_demo" in j:
        cd = j["consistency_demo"]
        okc = verify_consistency_v2(
            cd["first"],
            _unb64(cd["first_hash_b64"]),
            cd["second"],
            _unb64(cd["second_hash_b64"]),
            [_unb64(x) for x in cd["consistency_path_b64"]],
        )
        print("consistency demo", "OK" if okc else "FAIL")


def selftest_consistency(trials: int = 200) -> None:
    for n in range(2, 80):
        datas = [f"leaf{n}:{i}".encode("utf-8") for i in range(n)]
        for _ in range(trials // 10):
            m = random.randint(1, n - 1)
            old = merkle_root(datas[:m])
            new = merkle_root(datas[:n])
            proof = consistency_proof_v2(datas, m)
            ok = verify_consistency_v2(m, old, n, new, proof)
            if not ok:
                raise AssertionError(f"consistency selftest failed: n={n}, m={m}, proof_len={len(proof)}")
    print("consistency selftest OK")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit", action="store_true")
    ap.add_argument("--out", default="test_vectors/pct_log_demo.json")
    ap.add_argument("--verify", action="store_true")
    ap.add_argument("--in", dest="inp", default="test_vectors/pct_log_demo.json")
    ap.add_argument("--kind", default="attempt_dag_root")
    ap.add_argument("--selftest-consistency", action="store_true")
    args = ap.parse_args()

    if args.emit:
        emit_demo(args.out)
        return
    if args.verify:
        verify_demo(args.inp, args.kind)
        return
    if args.selftest_consistency:
        selftest_consistency()
        return

    ap.print_help()


if __name__ == "__main__":
    main()
