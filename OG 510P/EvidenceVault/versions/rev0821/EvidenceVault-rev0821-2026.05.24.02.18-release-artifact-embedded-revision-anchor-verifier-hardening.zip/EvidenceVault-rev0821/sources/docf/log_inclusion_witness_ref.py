#!/usr/bin/env python3
"""log_inclusion_witness_ref.py

Reference verifier/emit helper for `docf-log-inclusion-witness-v0`.

This tool mirrors RFC 9162 Section 2.1.3.2 inclusion-proof verification and
verifies the log's Ed25519 signature over the STH payload (JCS).

It is reference-grade code for paper examples; it is not hardened.
"""

from __future__ import annotations

import argparse
import base64
import json
import hashlib
from typing import Any, Dict, List

from docf_ref_tools_common import jcs, emit_json

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.hazmat.primitives import serialization
from cryptography.exceptions import InvalidSignature


def b64d(s: str) -> bytes:
    return base64.b64decode(s.encode("utf-8"))


def ct_leaf_hash(preimage: bytes) -> bytes:
    # RFC 9162 / RFC 6962 Merkle Tree Hash leaf: SHA256(0x00 || preimage)
    return hashlib.sha256(b"\x00" + preimage).digest()


def ct_node_hash(left: bytes, right: bytes) -> bytes:
    # RFC 9162 / RFC 6962 Merkle Tree Hash node: SHA256(0x01 || left || right)
    return hashlib.sha256(b"\x01" + left + right).digest()


def verify_sth_signature(checkpoint: Dict[str, Any]) -> bool:
    msg_obj = {
        "format": checkpoint["format"],
        "log_id": checkpoint.get("log_id", ""),
        "tree_size": checkpoint["tree_size"],
        "root_hash_sha256_b64": checkpoint["root_hash_sha256_b64"],
        "issued_at": checkpoint["issued_at"],
    }
    msg_bytes = jcs(msg_obj)
    pub_raw = b64d(checkpoint["log_public_key_ed25519_raw_b64"])
    sig = b64d(checkpoint["log_signature_ed25519_b64"])
    pub = Ed25519PublicKey.from_public_bytes(pub_raw)
    try:
        pub.verify(sig, msg_bytes)
        return True
    except InvalidSignature:
        return False


def verify_rfc9162_inclusion(leaf_index: int, tree_size: int, leaf_hash: bytes, path: List[bytes], root_hash: bytes) -> bool:
    # RFC 9162 Section 2.1.3.2 (Verifying an Inclusion Proof)
    if leaf_index >= tree_size:
        return False
    fn = leaf_index
    sn = tree_size - 1
    r = leaf_hash
    for p in path:
        if sn == 0:
            return False
        if (fn & 1) == 1 or fn == sn:
            r = ct_node_hash(p, r)
            if (fn & 1) == 0:
                while fn != 0 and (fn & 1) == 0:
                    fn >>= 1
                    sn >>= 1
        else:
            r = ct_node_hash(r, p)
        fn >>= 1
        sn >>= 1
    return sn == 0 and r == root_hash


def verify_witness(obj: Dict[str, Any]) -> bool:
    chk = obj["checkpoint"]
    if not verify_sth_signature(chk):
        return False
    leaf_hash = b64d(obj["leaf_hash_sha256_b64"])
    root_hash = b64d(chk["root_hash_sha256_b64"])
    path = [b64d(x) for x in obj["inclusion_path_sha256_b64"]]
    return verify_rfc9162_inclusion(obj["leaf_index"], chk["tree_size"], leaf_hash, path, root_hash)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit", action="store_true", help="emit the demo vector (matches test_vectors/log_inclusion_witness_demo.json)")
    ap.add_argument("--verify", metavar="PATH", help="verify a witness JSON file")
    args = ap.parse_args()

    if args.emit:
        with open("test_vectors/log_inclusion_witness_demo.json", "r", encoding="utf-8") as f:
            emit_json(json.load(f))
        return

    if args.verify:
        with open(args.verify, "r", encoding="utf-8") as f:
            obj = json.load(f)
        ok = verify_witness(obj)
        print("OK" if ok else "FAIL")
        raise SystemExit(0 if ok else 2)

    ap.print_help()


if __name__ == "__main__":
    main()
