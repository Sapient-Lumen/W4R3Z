#!/usr/bin/env python3
"""checkpoint_ref.py

Reference: Signed Tree Heads ("checkpoints") for the toy Merkle log.

We model a CT/SCITT/Sigstore-style checkpoint object that signs:
  - log_id (opaque string)
  - tree_size (int)
  - root_hash (base64)
  - timestamp (RFC3339 string)

Signatures use Ed25519 (RFC 8032). This file provides:
  - deterministic demo key generation (seeded)
  - checkpoint creation and verification

This is intentionally minimal; real deployments must rotate keys, publish
log parameters, and define a stable checkpoint encoding.
"""

from __future__ import annotations

import argparse
import base64
import json
from datetime import datetime, timezone
from typing import Any, Dict

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization


def _jcs(x: Any) -> bytes:
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def _unb64(s: str) -> bytes:
    return base64.b64decode(s.encode("ascii"))


def demo_log_keypair() -> tuple[Ed25519PrivateKey, bytes]:
    """Deterministic demo keypair (DO NOT USE IN PROD)."""
    seed = b"docf-demo-log-key-ed25519-seed-000000"[:32]
    sk = Ed25519PrivateKey.from_private_bytes(seed)
    pk = sk.public_key().public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
    return sk, pk


def checkpoint_message(log_id: str, tree_size: int, root_hash_b64: str, timestamp: str) -> bytes:
    msg = {
        "type": "docf_checkpoint_v0",
        "log_id": log_id,
        "tree_size": int(tree_size),
        "root_hash_b64": root_hash_b64,
        "timestamp": timestamp,
    }
    return _jcs(msg)


def sign_checkpoint(log_id: str, tree_size: int, root_hash: bytes, sk: Ed25519PrivateKey) -> Dict[str, Any]:
    ts = datetime.now(timezone.utc).isoformat()
    root_b64 = _b64(root_hash)
    msg = checkpoint_message(log_id, tree_size, root_b64, ts)
    sig = sk.sign(msg)
    pk_raw = sk.public_key().public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
    return {
        "type": "docf_checkpoint_v0",
        "log_id": log_id,
        "tree_size": int(tree_size),
        "root_hash_b64": root_b64,
        "timestamp": ts,
        "log_public_key_b64": _b64(pk_raw),
        "log_signature_b64": _b64(sig),
    }


def verify_checkpoint(ckpt: Dict[str, Any]) -> bool:
    try:
        msg = checkpoint_message(
            ckpt["log_id"],
            int(ckpt["tree_size"]),
            ckpt["root_hash_b64"],
            ckpt["timestamp"],
        )
        pk = Ed25519PublicKey.from_public_bytes(_unb64(ckpt["log_public_key_b64"]))
        pk.verify(_unb64(ckpt["log_signature_b64"]), msg)
        return True
    except Exception:
        return False


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit-demo", action="store_true")
    ap.add_argument("--log-id", default="docf-demo-log")
    ap.add_argument("--tree-size", type=int, default=4)
    ap.add_argument("--root-hash-b64", default=_b64(b"\x00" * 32))
    args = ap.parse_args()

    if args.emit_demo:
        sk, _ = demo_log_keypair()
        ckpt = sign_checkpoint(args.log_id, args.tree_size, _unb64(args.root_hash_b64), sk)
        print(json.dumps(ckpt, indent=2))
        print("verify:", verify_checkpoint(ckpt))
        return

    ap.print_help()


if __name__ == "__main__":
    main()
