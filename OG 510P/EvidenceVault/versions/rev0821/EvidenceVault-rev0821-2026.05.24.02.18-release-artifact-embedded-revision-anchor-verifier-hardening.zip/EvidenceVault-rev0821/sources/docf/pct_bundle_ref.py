#!/usr/bin/env python3
"""pct_bundle_ref.py

Reference tool: emit + verify an end-to-end Proof Certificate Transparency (PCT) bundle.

This tool exists so the papers can point to something concrete: a single JSON
bundle can be stapled to a delivered proof and independently verified.

Bundle content:
  v1 (minimal):
    - Market Round Certificate (MRC): market's selection receipt.
    - Attempt Trace (optional): retry/structured-concurrency trace.
    - Attempt DAG (ADC): auditable commitment derived from the trace.
    - Epsilon Ledger (ELD): resolved soundness-risk budget entries.
    - Performance Envelope Certificate (PEC): anytime-valid performance envelope (e-values).
    - Market Session Certificate (MSC): binds selection+attempts+ledger digests.
    - Transparency Log (TLOG): CT-style Merkle log over key digests.
    - Checkpoint Chain: two Signed Tree Heads (STHs) + RFC 9162 consistency proof.
    - Witness cosignatures: Ed25519 cosigns over the current checkpoint (toy).

  v2 (policy-carrying): v1 plus
    - Witness Diversity Descriptor (WDD): portable diversity metrics + conservative rho_hat.
    - Witness policy: a correlation-budget check (rho_hat <= rho_max).

Usage:
  ./pct_bundle_ref.py --emit-demo --version v2 --out test_vectors/pct_bundle_demo_v2.json
  ./pct_bundle_ref.py --verify --in test_vectors/pct_bundle_demo_v2.json

Deterministic; no network access.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Dict, List, Tuple

import attempt_dag_compiler_ref as adc_ref
import checkpoint_ref
import transparency_log_ref as tlog_ref
import witness_monitor_ref as wmon
import witness_diversity_descriptor_ref as wdd_ref


def _jcs_bytes(x: Any) -> bytes:
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _sha256_pref(x: Any) -> str:
    return "sha256:" + hashlib.sha256(_jcs_bytes(x)).hexdigest()


def _strip_digest_field(obj: Dict[str, Any]) -> Dict[str, Any]:
    o = dict(obj)
    o.pop("digest", None)
    return o


def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def _unb64(s: str) -> bytes:
    return base64.b64decode(s.encode("ascii"))


def load_json(p: str) -> Any:
    return json.loads(Path(p).read_text(encoding="utf-8"))


def demo_market_round_cert() -> Dict[str, Any]:
    mrc = {
        "type": "docf_market_round_cert_v0",
        "round_id": "round-demo-001",
        "sid": "sid-demo-001",
        "policy": {"max_price": 1.0, "deadline_ms": 15000, "min_rep": 0.0},
        "selected": {"prover_id": "prover-A", "price": 0.42, "eta_ms": 4200},
        "note": "Toy selection receipt.",
    }
    mrc["digest"] = _sha256_pref(mrc)
    return mrc


# ---- exchangeable compromise model helpers (for v2 policy demo) ----

def log_beta(a: float, b: float) -> float:
    return math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)


def beta_binom_pmf(m: int, k: int, alpha: float, beta: float) -> float:
    return math.comb(m, k) * math.exp(log_beta(alpha + k, beta + m - k) - log_beta(alpha, beta))


def hypergeom_pmf(N: int, K: int, n: int, k: int) -> float:
    if k < 0 or k > n or k > K or (n - k) > (N - K):
        return 0.0
    return (math.comb(K, k) * math.comb(N - K, n - k)) / math.comb(N, n)


def dual_accept_prob_given_K(m: int, t: int, g: int, K: int) -> float:
    lo = max(0, t - (m - g))
    hi = min(g, K + g - t)
    if lo > hi:
        return 0.0
    return sum(hypergeom_pmf(m, K, g, kA) for kA in range(lo, hi + 1))


def compute_probs(m: int, t: int, q: float, rho: float) -> Tuple[float, float]:
    """Return (P[K>=t], P_dual_accept) under Beta–Binomial ICC rho."""
    g = m // 2

    if rho <= 0.0:
        pQ = 0.0
        pD = 0.0
        for K in range(0, m + 1):
            pK = math.comb(m, K) * (q**K) * ((1 - q) ** (m - K))
            if K >= t:
                pQ += pK
            pD += pK * dual_accept_prob_given_K(m, t, g, K)
        return pQ, pD

    s = (1.0 / rho) - 1.0
    alpha = max(1e-12, q * s)
    beta = max(1e-12, (1.0 - q) * s)

    pQ = 0.0
    pD = 0.0
    for K in range(0, m + 1):
        pK = beta_binom_pmf(m, K, alpha, beta)
        if K >= t:
            pQ += pK
        pD += pK * dual_accept_prob_given_K(m, t, g, K)
    return pQ, pD


def max_rho_for_budget(m: int, t: int, q: float, budget_dual: float) -> float | None:
    # If even rho=0 exceeds budget, no correlation level can satisfy this budget.
    if compute_dual_accept(m, t, q, 0.0) > budget_dual:
        return None

    lo, hi = 0.0, 0.999
    for _ in range(70):
        mid = (lo + hi) / 2
        _, pD = compute_probs(m, t, q, mid)
        if pD <= budget_dual:
            lo = mid
        else:
            hi = mid
    return lo


# ---- Emitters ----

def emit_demo_v1(out_path: str) -> Dict[str, Any]:
    # Attempt trace + DAG
    trace = load_json("test_vectors/attempt_trace_demo_v1.json")
    sid = (trace.get("meta", {}) or {}).get("sid") or trace.get("sid") or "sid-demo-001"
    mrc = demo_market_round_cert()
    dag = adc_ref.compile_attempt_dag(trace)
    dag_digest = _sha256_pref(dag)

    # Epsilon ledger
    eld = load_json("test_vectors/eps_ledger_demo_numeric.json")
    eld_digest = _sha256_pref(eld)

    # Performance envelope certificate
    pec = load_json("test_vectors/perf_envelope_demo.json")
    pec_digest = _sha256_pref(pec)

    # Market session certificate (binds digests)
    msc: Dict[str, Any] = {
        "type": "docf_market_session_cert_v0",
        "sid": sid,
        "selection_receipt": mrc["digest"],
        "attempt_session": dag_digest,
        "eps_ledger": eld_digest,
        "digests": {"mrc": mrc["digest"], "adc": dag_digest, "eld": eld_digest, "pec": pec_digest},
        "sig": "demo-sig:market-session",
    }
    msc["digest"] = _sha256_pref(_strip_digest_field(msc))

    # Build transparency log over the key digests.
    entries = [
        {"kind": "market_round_cert", "digest": mrc["digest"]},
        {"kind": "attempt_dag", "digest": dag_digest},
        {"kind": "eps_ledger", "digest": eld_digest},
        {"kind": "perf_envelope", "digest": pec_digest},
        {"kind": "market_session_cert", "digest": msc["digest"]},
    ]
    leaf_bytes = [_jcs_bytes(e) for e in entries]
    root = tlog_ref.merkle_root(leaf_bytes)

    proofs: Dict[str, Any] = {}
    for i, e in enumerate(entries):
        proof = tlog_ref.inclusion_proof(leaf_bytes, i)
        proofs[e["kind"]] = {
            "leaf_index": i,
            "path_hex": [p.hex() for p in proof],
            "tree_size": len(entries),
            "root_hash_hex": root.hex(),
            "leaf_hash_hex": tlog_ref.leaf_hash(leaf_bytes[i]).hex(),
            "note": "RFC6962/RFC9162 hash construction (0x00 leaf / 0x01 node)",
        }

    tlog_obj = {
        "schema": "pct_tlog_demo_v2",
        "construction": "rfc6962",
        "hash": "sha256",
        "tree_size": len(entries),
        "root_hash_hex": root.hex(),
        "entries": entries,
        "inclusion_proofs": proofs,
        "note": "Toy CT-style log for PCT bundle demo.",
    }

    # --- Checkpoints + consistency proof (RFC 9162 style) ---
    log_id = "docf-demo-log"
    log_sk, _ = checkpoint_ref.demo_log_keypair()

    first = 2
    first_root = tlog_ref.merkle_root(leaf_bytes[:first])
    prev_ckpt = checkpoint_ref.sign_checkpoint(log_id, first, first_root, log_sk)

    second = len(entries)
    curr_ckpt = checkpoint_ref.sign_checkpoint(log_id, second, root, log_sk)

    cons_path = tlog_ref.consistency_proof_v2(leaf_bytes, first)
    cons_path_b64 = [_b64(x) for x in cons_path]

    # --- Witness cosigning (toy, 2-of-2 for the demo) ---
    witnesses = []
    for wid in ["w1", "w2"]:
        wsk, wpk = wmon.demo_witness_keypair(wid)
        st = wmon.WitnessState(wid, wsk, wpk, None)
        _ = st.cosign(prev_ckpt, [])  # establish baseline
        cosig = st.cosign(curr_ckpt, cons_path_b64)
        witnesses.append(cosig)

    bundle: Dict[str, Any] = {
        "type": "pct_bundle",
        "version": "v1",
        "sid": sid,
        "market_round_cert": mrc,
        "attempt_trace": trace,
        "attempt_dag": dag,
        "eps_ledger": eld,
        "perf_envelope": pec,
        "market_session_cert": msc,
        "transparency_log": tlog_obj,
        "checkpoint_chain": {
            "log_id": log_id,
            "previous_checkpoint": prev_ckpt,
            "current_checkpoint": curr_ckpt,
            "consistency_path_b64": cons_path_b64,
            "witness_threshold": 2,
            "witness_cosignatures": witnesses,
        },
    }

    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text(json.dumps(bundle, indent=2, ensure_ascii=False), encoding="utf-8")
    return bundle


def emit_demo_v2(out_path: str, snapshot_path: str = "data/witness_pool_snapshot_2026-02-28.json") -> Dict[str, Any]:
    # Start from the v1 content (but re-emit with a larger witness set).
    trace = load_json("test_vectors/attempt_trace_demo_v1.json")
    sid = (trace.get("meta", {}) or {}).get("sid") or trace.get("sid") or "sid-demo-001"
    mrc = demo_market_round_cert()
    dag = adc_ref.compile_attempt_dag(trace)
    dag_digest = _sha256_pref(dag)

    eld = load_json("test_vectors/eps_ledger_demo_numeric.json")
    eld_digest = _sha256_pref(eld)

    pec = load_json("test_vectors/perf_envelope_demo.json")
    pec_digest = _sha256_pref(pec)

    # --- WDD from public snapshot (first 7 witnesses) ---
    snap = json.loads(Path(snapshot_path).read_text(encoding="utf-8"))
    witness_ids = [w["id"] for w in snap.get("witnesses", [])[:7]]
    wdd = wdd_ref.compute_wdd(snap, witness_ids)
    wdd_digest = wdd["digest"]

    # --- Policy: correlation budget check (toy) ---
    q = 0.12
    threshold = 6
    budget_bits = 8
    budget_dual = 2.0 ** (-budget_bits)

    m = len(witness_ids)
    rho_hat = float(wdd["rho_hat"])
    rho_max = max_rho_for_budget(m, threshold, q, budget_dual)
    if rho_max is None:
        raise ValueError(f"budget infeasible even for independent witnesses: m={m} t={threshold} q={q} B_dual=2^-{budget_bits}")
    decision = "accept" if rho_hat <= rho_max else "reject"

    witness_policy: Dict[str, Any] = {
        "model": "beta_binom_exchangeable_v0",
        "q": q,
        "threshold": threshold,
        "budget_dual_bits": budget_bits,
        "rho_max": float(f"{rho_max:.6g}"),
        "decision": decision,
        "note": "Toy verifier rule: accept only if WDD rho_hat <= rho_max(budget).",
    }
    witness_policy["digest"] = _sha256_pref(_strip_digest_field(witness_policy))
    pol_digest = witness_policy["digest"]

    # Market session certificate (binds digests)
    msc: Dict[str, Any] = {
        "type": "docf_market_session_cert_v0",
        "sid": sid,
        "selection_receipt": mrc["digest"],
        "attempt_session": dag_digest,
        "eps_ledger": eld_digest,
        "digests": {
            "mrc": mrc["digest"],
            "adc": dag_digest,
            "eld": eld_digest,
            "pec": pec_digest,
            "wdd": wdd_digest,
            "witness_policy": pol_digest,
        },
        "sig": "demo-sig:market-session",
    }
    msc["digest"] = _sha256_pref(_strip_digest_field(msc))

    # Build transparency log over the key digests.
    entries = [
        {"kind": "market_round_cert", "digest": mrc["digest"]},
        {"kind": "attempt_dag", "digest": dag_digest},
        {"kind": "eps_ledger", "digest": eld_digest},
        {"kind": "perf_envelope", "digest": pec_digest},
        {"kind": "witness_diversity_descriptor", "digest": wdd_digest},
        {"kind": "witness_policy", "digest": pol_digest},
        {"kind": "market_session_cert", "digest": msc["digest"]},
    ]

    leaf_bytes = [_jcs_bytes(e) for e in entries]
    root = tlog_ref.merkle_root(leaf_bytes)

    proofs: Dict[str, Any] = {}
    for i, e in enumerate(entries):
        proof = tlog_ref.inclusion_proof(leaf_bytes, i)
        proofs[e["kind"]] = {
            "leaf_index": i,
            "path_hex": [p.hex() for p in proof],
            "tree_size": len(entries),
            "root_hash_hex": root.hex(),
            "leaf_hash_hex": tlog_ref.leaf_hash(leaf_bytes[i]).hex(),
            "note": "RFC6962/RFC9162 hash construction (0x00 leaf / 0x01 node)",
        }

    tlog_obj = {
        "schema": "pct_tlog_demo_v2",
        "construction": "rfc6962",
        "hash": "sha256",
        "tree_size": len(entries),
        "root_hash_hex": root.hex(),
        "entries": entries,
        "inclusion_proofs": proofs,
        "note": "Toy CT-style log for PCT bundle demo (v2 policy-carrying bundle).",
    }

    # --- Checkpoints + consistency proof (RFC 9162 style) ---
    log_id = "docf-demo-log"
    log_sk, _ = checkpoint_ref.demo_log_keypair()

    first = 2
    first_root = tlog_ref.merkle_root(leaf_bytes[:first])
    prev_ckpt = checkpoint_ref.sign_checkpoint(log_id, first, first_root, log_sk)

    second = len(entries)
    curr_ckpt = checkpoint_ref.sign_checkpoint(log_id, second, root, log_sk)

    cons_path = tlog_ref.consistency_proof_v2(leaf_bytes, first)
    cons_path_b64 = [_b64(x) for x in cons_path]

    # --- Witness cosigning (toy), using snapshot witness ids ---
    witnesses = []
    for wid in witness_ids:
        wsk, wpk = wmon.demo_witness_keypair(wid)
        st = wmon.WitnessState(wid, wsk, wpk, None)
        _ = st.cosign(prev_ckpt, [])
        cosig = st.cosign(curr_ckpt, cons_path_b64)
        witnesses.append(cosig)

    bundle: Dict[str, Any] = {
        "type": "pct_bundle",
        "version": "v2",
        "sid": sid,
        "market_round_cert": mrc,
        "attempt_trace": trace,
        "attempt_dag": dag,
        "eps_ledger": eld,
        "perf_envelope": pec,
        "witness_diversity_descriptor": wdd,
        "witness_policy": witness_policy,
        "market_session_cert": msc,
        "transparency_log": tlog_obj,
        "checkpoint_chain": {
            "log_id": log_id,
            "previous_checkpoint": prev_ckpt,
            "current_checkpoint": curr_ckpt,
            "consistency_path_b64": cons_path_b64,
            "witness_threshold": threshold,
            "witness_cosignatures": witnesses,
        },
    }

    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_text(json.dumps(bundle, indent=2, ensure_ascii=False), encoding="utf-8")
    return bundle


# ---- Verifier ----

def verify_bundle(inp: str) -> bool:
    b = json.loads(Path(inp).read_text(encoding="utf-8"))

    # Verify Merkle root + inclusion proofs.
    tlog = b["transparency_log"]
    entries = tlog["entries"]
    leaf_bytes = [_jcs_bytes(e) for e in entries]
    root = tlog_ref.merkle_root(leaf_bytes)
    if root.hex() != tlog["root_hash_hex"]:
        raise ValueError("tlog root mismatch")

    for kind, pr in tlog["inclusion_proofs"].items():
        i = int(pr["leaf_index"])
        leaf = leaf_bytes[i]
        path = [bytes.fromhex(x) for x in pr["path_hex"]]
        ok = tlog_ref.verify_inclusion(leaf, i, len(entries), path, root)
        if not ok:
            raise ValueError(f"bad inclusion proof for {kind}")

    # Verify checkpoints + consistency.
    cc = b.get("checkpoint_chain") or {}
    prev = cc.get("previous_checkpoint")
    curr = cc.get("current_checkpoint")
    if prev and (not checkpoint_ref.verify_checkpoint(prev)):
        raise ValueError("bad previous checkpoint signature")
    if curr and (not checkpoint_ref.verify_checkpoint(curr)):
        raise ValueError("bad current checkpoint signature")

    if prev and curr:
        first = int(prev["tree_size"])
        second = int(curr["tree_size"])
        cons_path_b64 = cc.get("consistency_path_b64") or []
        okc = tlog_ref.verify_consistency_v2(
            first,
            _unb64(prev["root_hash_b64"]),
            second,
            _unb64(curr["root_hash_b64"]),
            [_unb64(x) for x in cons_path_b64],
        )
        if not okc:
            raise ValueError("consistency proof failed")

    # Verify witness cosignatures.
    if curr:
        cosigs = cc.get("witness_cosignatures") or []
        thr = int(cc.get("witness_threshold") or 0)
        good = 0
        for cs in cosigs:
            if wmon.verify_cosignature(cs, curr):
                good += 1
        if thr and good < thr:
            raise ValueError("witness threshold not met")

    # v2: verify WDD + policy rule.
    if b.get("version") == "v2":
        wdd = b.get("witness_diversity_descriptor")
        if not isinstance(wdd, dict):
            raise ValueError("missing WDD")
        _ = wdd_ref.verify_wdd(wdd)

        pol = b.get("witness_policy")
        if not isinstance(pol, dict):
            raise ValueError("missing witness_policy")
        pol_digest = pol.get("digest")
        if not isinstance(pol_digest, str) or not pol_digest.startswith("sha256:"):
            raise ValueError("missing policy digest")
        recomputed_pol = _sha256_pref(_strip_digest_field(pol))
        if recomputed_pol != pol_digest:
            raise ValueError("policy digest mismatch")

        witness_ids = wdd.get("witness_ids") or []
        cosig_ids = [cs.get("witness_id") for cs in (cc.get("witness_cosignatures") or [])]
        # Require that the WDD witness set matches the cosignature set (order-insensitive).
        if set(witness_ids) != set(cosig_ids):
            raise ValueError("WDD witness_ids do not match cosignatures")

        rho_hat = float(wdd.get("rho_hat") or 0.0)
        rho_max = float(pol.get("rho_max") or 0.0)
        decision = str(pol.get("decision") or "")
        expected = "accept" if rho_hat <= rho_max else "reject"
        if decision != expected:
            raise ValueError("policy decision inconsistent with (rho_hat <= rho_max)")

    return True


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit-demo", action="store_true")
    ap.add_argument("--version", default="v2", choices=["v1", "v2"], help="bundle version")
    ap.add_argument("--out", default="test_vectors/pct_bundle_demo_v2.json")
    ap.add_argument("--verify", action="store_true")
    ap.add_argument("--in", dest="inp", default="test_vectors/pct_bundle_demo_v2.json")
    ap.add_argument("--snapshot", default="data/witness_pool_snapshot_2026-02-28.json")
    args = ap.parse_args()

    if args.emit_demo:
        if args.version == "v1":
            emit_demo_v1(args.out)
        else:
            emit_demo_v2(args.out, snapshot_path=args.snapshot)
        print(f"wrote {args.out}")
        return

    if args.verify:
        ok = verify_bundle(args.inp)
        print("verify OK" if ok else "verify FAIL")
        return

    ap.print_help()


if __name__ == "__main__":
    main()
