#!/usr/bin/env python3
"""Reference compiler for docf_typed_option_repricing_report_v0.

This is intentionally tiny and deterministic: it consumes an OSL JSON
and an obligations list, and emits a per-obligation conservative repricing.

Semantics (conservative):
  resolved_eps(o) = min(1, volume_N * Q * 2^b_att * prod_{opt in sensitivity(o)} T_opt * eps_one_shot(o)).
If any sensitivity entry is missing from the OSL, fail closed.

The script is *not* a verifier; it is a demo 'auditor output' generator.
"""

import json
import math
import argparse
from typing import Any, Dict, Tuple


def parse_eps(s: str) -> float:
    s = s.strip()
    if s.startswith("2^-"):
        k = float(s[3:])
        return 2.0 ** (-k)
    if "^-" in s and s.startswith("2"):
        # tolerate "2^-128" already handled
        pass
    # allow simple scientific notation
    try:
        return float(s)
    except Exception as e:
        raise ValueError(f"Unrecognized eps format: {s}") from e


def load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def build_T_map(osl: Dict[str, Any]) -> Dict[str, int]:
    T = {}
    for opt in osl.get("options", []):
        opt_id = opt.get("option_id")
        derived = opt.get("derived", {})
        if opt_id and "T" in derived:
            T[opt_id] = int(derived["T"])
    return T


def resolve_obligation(eps_one_shot: float, sensitivity: list, T_map: Dict[str, int], volume_N: int, Q: int, b_att: int) -> Tuple[str, Dict[str, Any]]:
    missing = [x for x in sensitivity if x not in T_map]
    if missing:
        return "fail_closed", {"status": "fail_closed", "missing": missing, "notes": "Missing option evidence for sensitivity entries."}

    mult = float(volume_N) * float(Q) * (2.0 ** float(b_att))
    for x in sensitivity:
        mult *= float(T_map[x])

    resolved_eps = min(1.0, mult * eps_one_shot)
    tax_bits = math.log2(mult) if mult > 0 else float("inf")
    sec_bits = -math.log2(resolved_eps) if resolved_eps > 0 else float("inf")
    return "ok", {
        "status": "ok",
        "multiplier": mult,
        "tax_bits": tax_bits,
        "resolved_eps": resolved_eps,
        "resolved_security_bits": sec_bits,
        "repricing_rule": "resolved_eps = min(1, N * Q * 2^b_att * prod(T_sensitive) * eps_one_shot)"
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--osl", required=True, help="Path to option_surface_ledger JSON")
    ap.add_argument("--in", dest="inp", required=True, help="Path to typed repricing input JSON")
    ap.add_argument("--out", required=True, help="Output path")
    args = ap.parse_args()

    osl = load_json(args.osl)
    inp = load_json(args.inp)

    T_map = build_T_map(osl)

    volume_N = int(inp["volume_N"])
    Q = int(inp.get("Q", osl.get("derived_total", {}).get("Q", 1)))
    b_att = int(inp.get("b_att", 0))

    out = {
        "type": "docf_typed_option_repricing_report_v0",
        "sid": inp["sid"],
        "manifest_digest": inp["manifest_digest"],
        "volume_N": volume_N,
        "osl_digest": osl.get("digest", ""),
        "Q": int(inp.get("Q", 1)),
        "b_att": b_att,
        "resolver_rule": "volume_N * Q * 2^b_att * product(T_sensitive)",
        "obligations": [],
        "notes": "Demo typed repricing report computed from a toy OSL."
    }

    for o in inp["obligations"]:
        eps0 = parse_eps(o["eps_one_shot"])
        status, resolved = resolve_obligation(
            eps0,
            list(o.get("sensitivity", [])),
            T_map,
            volume_N,
            int(inp.get("Q", 1)),
            b_att,
        )
        out["obligations"].append({
            "obligation_id": o["obligation_id"],
            "eps_one_shot": o["eps_one_shot"],
            "sensitivity": o.get("sensitivity", []),
            "resolved": resolved
        })

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, sort_keys=False)
        f.write("\n")


if __name__ == "__main__":
    main()
