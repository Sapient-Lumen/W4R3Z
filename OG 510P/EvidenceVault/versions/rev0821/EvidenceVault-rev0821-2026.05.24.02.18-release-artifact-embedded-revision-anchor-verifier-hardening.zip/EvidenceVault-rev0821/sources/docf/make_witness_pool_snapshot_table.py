#!/usr/bin/env python3
"""make_witness_pool_snapshot_table.py

Generate a LaTeX table summarizing a witness pool snapshot.

Input:
  data/witness_pool_snapshot_YYYY-MM-DD.json

Output:
  _insert_witness_pool_snapshot_table.tex

This is intentionally simple and deterministic so the papers can cite it as a
replayable artifact.

Usage:
  ./make_witness_pool_snapshot_table.py --in data/witness_pool_snapshot_2026-02-28.json
"""
from __future__ import annotations
import argparse, json
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def latex_escape(s: str) -> str:
    return (s.replace('\\','\\textbackslash{}')
             .replace('&','\\&').replace('%','\\%').replace('_','\\_')
             .replace('#','\\#').replace('{','\\{').replace('}','\\}')
             .replace('~','\\textasciitilde{}').replace('^','\\textasciicircum{}'))

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--in', dest='inp', required=True)
    ap.add_argument('--out', default=str(ROOT / '_insert_witness_pool_snapshot_table.tex'))
    args = ap.parse_args()

    snap = json.loads(Path(args.inp).read_text(encoding='utf-8'))
    rows = []
    for w in snap['witnesses']:
        v = w['vkey']
        vshort = v[:32] + '…' + v[-8:]
        u = w.get('add_checkpoint_url', w.get('submission_prefix', ''))
        us = u.replace('https://','')
        ushort = (us[:28] + '…') if len(us) > 31 else us
        rows.append((w['id'], w['operator'], w['env'], vshort, ushort))

    lines = []
    lines.append('% Auto-generated from ' + args.inp)
    lines.append('\\begin{tabular}{lllll}')
    lines.append('\\toprule')
    lines.append('Witness & Operator & Env & vkey (short) & add-checkpoint \\\\')
    lines.append('\\midrule')
    for r in rows:
        lines.append(' & '.join(latex_escape(x) for x in r) + ' \\\\')
    lines.append('\\bottomrule')
    lines.append('\\end{tabular}')
    Path(args.out).write_text('\n'.join(lines) + '\n', encoding='utf-8')

if __name__ == '__main__':
    main()
