#!/usr/bin/env python3
"""seed_lock_optimizer_ref.py

Reference tool: seed-lock optimization over a witnessed attempt trace.

Motivation:
  - attempt_trace_extractor_ref.py turns a stack-disciplined retry trace skeleton into
    a conservative retry multiplier Q_g (Theorem \ref{thm:attempt-extract}).
  - end2end_resolve_ref.py composes Q_g with crypto terms to compute a conservative
    end-to-end security-bits bound and a minimal repetition count t meeting a target
    (Theorem \ref{thm:end2end}).

This tool composes the two and treats the choice of which regions are "seed-locked"
(i.e., do *not* resample the public-coin seed group g on retries) as an explicit,
auditable optimization problem.

Input JSON format (one of):
  {
    "attempt_trace": { ... docf_attempt_trace/v0|v1 ... },
    "eligible_regions": ["in_round", "dispute"],
    "end2end_params": { ... end2end params except Q ... },
    "target_security_bits": 128,
    "max_candidates": 32
  }

  {
    "attempt_trace_path": "test_vectors/attempt_trace_demo.json",
    ...
  }

Output:
  docf_seed_lock_optimization_report/v0

Notes:
  - This is a deterministic, dependency-free reference sketch.
  - It does not prove that a region is actually eligible for seed-locking; it only
    explores declared eligibility sets and reports the resulting accounting.
"""

from __future__ import annotations

import argparse
import itertools
import json
import sys
from typing import Any, Dict, List, Tuple

from docf_ref_tools_common import jcs, sha256_hex


def _fail(msg: str) -> None:
    raise SystemExit(f"[seed_lock_optimizer_ref] {msg}")


def _load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _jdump(obj: Any) -> str:
    return json.dumps(obj, indent=2, sort_keys=True) + "\n"


def _powerset(xs: List[str]) -> List[Tuple[str, ...]]:
    out: List[Tuple[str, ...]] = []
    for r in range(0, len(xs) + 1):
        for comb in itertools.combinations(xs, r):
            out.append(comb)
    return out


def _score_candidate(end2end: Dict[str, Any], Q: int, locked_count: int) -> Tuple:
    """Objective: minimize recommended t, then Q, then locked_count."""
    rec = end2end.get("recommended_min_t")
    t = None
    if isinstance(rec, dict):
        t = rec.get("t")
    t_val = int(t) if isinstance(t, (int, float)) else 10 ** 9
    return (t_val, int(Q), int(locked_count))


def optimize(obj: Dict[str, Any]) -> Dict[str, Any]:
    try:
        from attempt_trace_extractor_ref import run as extract_attempt
        from end2end_resolve_ref import end2end_bound
    except Exception as e:
        _fail(f"failed to import sibling tools: {e}")

    trace = obj.get("attempt_trace")
    if trace is None:
        path = obj.get("attempt_trace_path")
        if not path:
            _fail("expected attempt_trace or attempt_trace_path")
        trace = _load_json(path)

    if trace.get("schema") not in ("docf_attempt_trace/v0", "docf_attempt_trace/v1"):
        _fail("attempt_trace must use schema docf_attempt_trace/v0 or docf_attempt_trace/v1")

    seed_group = trace.get("seed_group", "g")
    var_bounds = trace.get("var_bounds", {})
    if not isinstance(var_bounds, dict) or not var_bounds:
        _fail("attempt_trace.var_bounds must be a non-empty object")

    eligible_regions = obj.get("eligible_regions")
    if eligible_regions is None:
        eligible_regions = sorted(list(var_bounds.keys()))
    if not isinstance(eligible_regions, list) or any(not isinstance(x, str) for x in eligible_regions):
        _fail("eligible_regions must be an array of strings")

    # Ensure eligibility is within declared regions.
    for r in eligible_regions:
        if r not in var_bounds:
            _fail(f"eligible region '{r}' not present in attempt_trace.var_bounds")

    # End2end params, excluding Q; we inject Q per candidate.
    end2end_params = obj.get("end2end_params", {})
    if not isinstance(end2end_params, dict):
        _fail("end2end_params must be an object")

    target_bits = obj.get("target_security_bits")
    if target_bits is not None:
        try:
            target_bits_f = float(target_bits)
        except Exception:
            _fail("target_security_bits must be numeric")
    else:
        target_bits_f = None

    max_candidates = int(obj.get("max_candidates", 64))
    max_candidates = max(4, min(max_candidates, 2048))

    # Canonical trace digest for binding.
    trace_digest = sha256_hex(jcs(trace))

    # Helper to evaluate candidate.
    def eval_candidate(seed_locked: List[str]) -> Dict[str, Any]:
        t2 = dict(trace)
        t2["seed_locked"] = seed_locked
        # Preserve existing resample_cut or default to all regions.
        if "resample_cut" not in t2:
            t2["resample_cut"] = sorted(list(var_bounds.keys()))
        attempt_rep = extract_attempt(t2)
        Q = int(attempt_rep["Q_eval_seed_locked"])

        p2 = dict(end2end_params)
        p2["Q"] = Q
        if target_bits_f is not None and "target_security_bits" not in p2:
            p2["target_security_bits"] = target_bits_f
        # Ensure an explicit t is present for the main computed fields.
        if "t" not in p2:
            p2["t"] = 1

        e2 = end2end_bound(p2)
        return {"seed_locked": sorted(seed_locked), "Q": Q, "end2end": e2}

    # Enumerate candidates.
    warnings: List[str] = []
    candidates: List[Dict[str, Any]] = []

    if len(eligible_regions) <= 12:
        for comb in _powerset(sorted(eligible_regions)):
            candidates.append(eval_candidate(list(comb)))
    else:
        warnings.append(
            f"eligible_regions has size {len(eligible_regions)}; falling back to greedy search (not exhaustive)."
        )
        locked: List[str] = []
        best = eval_candidate(locked)
        candidates.append(best)
        improved = True
        while improved and len(locked) < len(eligible_regions) and len(candidates) < max_candidates:
            improved = False
            cur_score = _score_candidate(best["end2end"], best["Q"], len(locked))
            best_step = None
            for r in eligible_regions:
                if r in locked:
                    continue
                trial = locked + [r]
                rep = eval_candidate(trial)
                sc = _score_candidate(rep["end2end"], rep["Q"], len(trial))
                if sc < cur_score:
                    cur_score = sc
                    best_step = rep
            if best_step is not None:
                locked = best_step["seed_locked"]
                best = best_step
                candidates.append(best_step)
                improved = True

    # Baseline = empty lock set.
    baseline = None
    for c in candidates:
        if c["seed_locked"] == []:
            baseline = c
            break
    if baseline is None:
        baseline = eval_candidate([])
        candidates.append(baseline)

    # Sort + trim.
    candidates_sorted = sorted(
        candidates,
        key=lambda c: _score_candidate(c["end2end"], c["Q"], len(c["seed_locked"]))
    )
    if len(candidates_sorted) > max_candidates:
        candidates_sorted = candidates_sorted[:max_candidates]

    recommended = candidates_sorted[0] if candidates_sorted else baseline

    out = {
        "schema": "docf_seed_lock_optimization_report/v0",
        "seed_group": seed_group,
        "trace_digest_sha256": trace_digest,
        "eligible_regions": sorted(eligible_regions),
        "objective": "minimize recommended_min_t, then Q, then |seed_locked|",
        "end2end_params": end2end_params,
        "target_security_bits": target_bits_f,
        "baseline": baseline,
        "candidates": candidates_sorted,
        "recommended": recommended,
        "warnings": warnings,
        "notes": [
            "This report is purely an accounting/selection helper.",
            "Production use must justify eligibility of seed-locks via protocol design + evidence.",
            "Downstream verifiers should treat missing or weak evidence as fail-closed and ignore optimistic candidates."
        ],
    }
    return out


def demo_request() -> Dict[str, Any]:
    return {
        "attempt_trace_path": "test_vectors/attempt_trace_demo.json",
        "eligible_regions": ["auction", "dispute", "in_round"],
        "target_security_bits": 128,
        "max_candidates": 16,
        "end2end_params": {
            "t": 1,
            "p_base": "2^-80",
            "eps_cancel": "2^-48",
            "b_rep": 2,
            "eps_rep": 0.0,
            "b_att": 10,
            "eps_att": 0.0,
            "eps_cm": "2^-130"
        }
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="in_path", default=None, help="input JSON (default: stdin)")
    ap.add_argument("--out", dest="out_path", default=None, help="output JSON (default: stdout)")
    ap.add_argument("--emit", action="store_true", help="emit deterministic demo request+report")
    args = ap.parse_args()

    if args.emit:
        req = demo_request()
        rep = optimize(req)
        sys.stdout.write(_jdump({"demo_in": req, "demo_out": rep}))
        return

    raw = sys.stdin.read() if args.in_path is None else open(args.in_path, "r", encoding="utf-8").read()
    obj = json.loads(raw)
    rep = optimize(obj)
    s = _jdump(rep)
    if args.out_path:
        open(args.out_path, "w", encoding="utf-8").write(s)
    else:
        sys.stdout.write(s)


if __name__ == "__main__":
    main()
