#!/usr/bin/env python3
"""make_pct_end2end_demo_table.py

Generate `_insert_pct_end2end_demo_table.tex` from `test_vectors/pct_bundle_demo.json`.

The table summarizes:
- component JSON sizes
- inclusion path length + bytes for each stapled digest
- checkpoint/consistency/witness overhead (split-view mitigation)
"""
from __future__ import annotations

import argparse, json, base64
from pathlib import Path

def _tex_escape(s: str) -> str:
    return s.replace("_", "\\_").replace("%", "\\%")

def _bytes_json(x) -> int:
    return len(json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", default="test_vectors/pct_bundle_demo.json")
    ap.add_argument("--out", dest="outp", default="_insert_pct_end2end_demo_table.tex")
    args = ap.parse_args()

    b = json.loads(Path(args.inp).read_text(encoding="utf-8"))
    tlog = b["transparency_log"]
    proofs = tlog["inclusion_proofs"]
    root_pref = tlog["root_hash_hex"][:16] + "…"
    n = int(tlog["tree_size"])

    rows = []
    total_incl_bytes = 0
    comps = [
        ("MRC", "market_round_cert", "market_round_cert"),
        ("ADC", "attempt_dag", "attempt_dag"),
        ("ELD", "eps_ledger", "eps_ledger"),
        ("PEC", "perf_envelope", "perf_envelope"),
        ("MSC", "market_session_cert", "market_session_cert"),
    ]
    for label, proof_kind, obj_key in comps:
        obj = b[obj_key]
        size = _bytes_json(obj)
        p = proofs[proof_kind]
        path_len = len(p["path_hex"])
        path_bytes = path_len * 32
        total_incl_bytes += path_bytes
        dig = obj.get("digest") if isinstance(obj, dict) and "digest" in obj else "(computed)"
        dig_pref = (dig[:18] + "…") if isinstance(dig, str) else "(n/a)"
        rows.append((label, size, dig_pref, path_len, path_bytes))

    # checkpoint chain overhead
    cc = b.get("checkpoint_chain", {})
    prev = cc.get("previous_checkpoint")
    curr = cc.get("current_checkpoint")
    cons_path = cc.get("consistency_path_b64", [])
    cons_len = len(cons_path)
    cons_bytes = cons_len * 32
    total_witness_bytes = sum(_bytes_json(cs) for cs in (cc.get("witness_cosignatures") or []))
    prev_bytes = _bytes_json(prev) if prev else 0
    curr_bytes = _bytes_json(curr) if curr else 0

    total_overhead = total_incl_bytes + cons_bytes + total_witness_bytes + prev_bytes + curr_bytes

    tex = []
    tex.append("\\begin{table}[t]")
    tex.append("\\centering")
    tex.append("\\small")
    tex.append("\\begin{tabular}{l r l r r}")
    tex.append("\\toprule")
    tex.append(f"\\multicolumn{{5}}{{l}}{{TLOG leaves={n}, root={root_pref}}} \\\\")
    tex.append("Item & JSON bytes & digest prefix & incl. len & incl. bytes \\\\")
    tex.append("\\midrule")
    for label, size, dig_pref, path_len, path_bytes in rows:
        tex.append(f"{label} & {size} & {_tex_escape(dig_pref)} & {path_len} & {path_bytes} \\\\")
    tex.append("\\midrule")
    tex.append(f"Prev checkpoint & {prev_bytes} & -- & -- & -- \\\\")
    tex.append(f"Curr checkpoint & {curr_bytes} & -- & -- & -- \\\\")
    tex.append(f"Consistency proof & -- & -- & {cons_len} & {cons_bytes} \\\\")
    tex.append(f"Witness cosigs & {total_witness_bytes} & -- & -- & -- \\\\")
    tex.append("\\midrule")
    tex.append(f"Total staple overhead & \\multicolumn{{4}}{{r}}{{{total_overhead} bytes}} \\\\")
    tex.append("\\bottomrule")
    tex.append("\\end{tabular}")
    tex.append("\\caption{End-to-end PCT bundle demo size accounting. In addition to inclusion paths for each leaf digest, deployments can staple a checkpoint chain (signed tree heads + RFC~9162 consistency) and witness cosignatures to mitigate split-view attacks.}")
    tex.append("\\label{tab:pct_end2end}")
    tex.append("\\end{table}")
    Path(args.outp).write_text("\n".join(tex) + "\n", encoding="utf-8")

if __name__ == "__main__":
    main()
