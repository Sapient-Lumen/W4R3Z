#!/usr/bin/env python3
"""make_quorum_pareto_frontier_experiment.py

A faster, reproducible Pareto-style exploration for witness quorum sizing.

Why this exists:
  - The "single best" quorum from make_quorum_sizing_solver_experiment.py hides
    the design space: redundancy, thresholding, and cost trade off.
  - Full exact search over all (m,t) and all m-sets is expensive.

This script takes a *policy-fixed threshold* approach to surface the tradeoff
with tractable compute:
  - For each m in [m_min, m_max], choose a deterministic threshold
      t(m) = max( floor(m/2)+1, ceil(t_min_frac * m) )
  - For each budget k and each m, find the cheapest witness set S of size m
    satisfying:
      (i)  rho_hat(S) <= rho_max(m,t,q,B_dual)
      (ii) P[#available >= t] >= 1 - delta
    where rho_hat is aggregated either by:
      - max over domains (conservative default)
      - domain-weighted average (auditable but less conservative)

It then reports:
  - a cost-vs-m curve (one feasible point per m), which is already a Pareto
    frontier for minimization in (m, cost).
  - a comparison of max vs weighted aggregation at a representative k.

Outputs:
  - test_vectors/quorum_pareto_frontier_results.json
  - _insert_quorum_pareto_frontier_table.tex
  - _insert_quorum_agg_comparison_table.tex
  - pct_quorum_pareto_frontier.pdf
  - pct_quorum_agg_comparison.pdf

Deterministic; no network access.
"""

from __future__ import annotations

import argparse
import itertools
import json
import math
from pathlib import Path
from typing import Any, Dict, List, Tuple


def _rho(labels: List[str]) -> float:
    m = len(labels)
    if m <= 1:
        return 0.0
    counts: Dict[str, int] = {}
    for x in labels:
        counts[x] = counts.get(x, 0) + 1
    num = sum(v * (v - 1) for v in counts.values())
    return num / (m * (m - 1))


def rho_by_domain(ws: List[Dict[str, Any]], domains: List[str]) -> Dict[str, float]:
    by: Dict[str, float] = {}
    for d in domains:
        labels = [str(w.get(d) or w.get('id')) for w in ws]
        by[d] = _rho(labels)
    return by


def rho_aggregate(by: Dict[str, float], agg: str, weights: Dict[str, float]) -> float:
    if not by:
        return 0.0
    if agg == 'max':
        return max(by.values())
    if agg == 'weighted':
        wsum = 0.0
        acc = 0.0
        for d, v in by.items():
            w = float(weights.get(d, 0.0))
            if w <= 0.0:
                continue
            wsum += w
            acc += w * v
        if wsum <= 0.0:
            return sum(by.values()) / len(by)
        return acc / wsum
    raise ValueError(f"unknown agg: {agg}")


def poisson_binom_dist(ps: List[float]) -> List[float]:
    m = len(ps)
    dp = [0.0] * (m + 1)
    dp[0] = 1.0
    for p in ps:
        nxt = [0.0] * (m + 1)
        for j in range(0, m + 1):
            if dp[j] == 0.0:
                continue
            nxt[j] += dp[j] * (1 - p)
            if j + 1 <= m:
                nxt[j + 1] += dp[j] * p
        dp = nxt
    return dp


def tail_from_dist(dp: List[float], t: int) -> float:
    return float(sum(dp[t:]))


def log_beta(a: float, b: float) -> float:
    return math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)


def beta_binom_pmf(m: int, k: int, alpha: float, beta: float) -> float:
    return math.comb(m, k) * math.exp(log_beta(alpha + k, beta + m - k) - log_beta(alpha, beta))


def hypergeom_pmf(N: int, K: int, n: int, k: int) -> float:
    if k < 0 or k > n or k > K or (n - k) > (N - K):
        return 0.0
    return (math.comb(K, k) * math.comb(N - K, n - k)) / math.comb(N, n)


def dual_accept_prob_given_K(m: int, t: int, g: int, K: int) -> float:
    lo = max(0, t - (m - g))
    hi = min(g, K + g - t)
    if lo > hi:
        return 0.0
    return sum(hypergeom_pmf(m, K, g, kA) for kA in range(lo, hi + 1))


def compute_dual_accept(m: int, t: int, q: float, rho: float) -> float:
    g = m // 2
    if rho <= 0.0:
        pD = 0.0
        for K in range(0, m + 1):
            pK = math.comb(m, K) * (q ** K) * ((1 - q) ** (m - K))
            pD += pK * dual_accept_prob_given_K(m, t, g, K)
        return pD

    s = (1.0 / rho) - 1.0
    alpha = max(1e-12, q * s)
    beta = max(1e-12, (1.0 - q) * s)

    pD = 0.0
    for K in range(0, m + 1):
        pK = beta_binom_pmf(m, K, alpha, beta)
        pD += pK * dual_accept_prob_given_K(m, t, g, K)
    return pD


def max_rho_for_budget(m: int, t: int, q: float, budget_dual: float) -> float | None:
    if compute_dual_accept(m, t, q, 0.0) > budget_dual:
        return None
    lo, hi = 0.0, 0.999
    for _ in range(70):
        mid = (lo + hi) / 2
        if compute_dual_accept(m, t, q, mid) <= budget_dual:
            lo = mid
        else:
            hi = mid
    return lo


def enumerate_sets_sorted(pool: List[Dict[str, Any]], m: int, domains: List[str]):
    out = []
    for comb in itertools.combinations(pool, m):
        ws = list(comb)
        by = rho_by_domain(ws, domains)
        ps = [float(w.get('uptime', 1.0)) for w in ws]
        dp = poisson_binom_dist(ps)
        cost = sum(float(w.get('monthly_cost_usd', 0.0)) for w in ws)
        out.append((cost, by, dp, [w['id'] for w in ws]))
    out.sort(key=lambda x: x[0])
    return out


def parse_weights(s: str, domains: List[str]) -> Dict[str, float]:
    if not s.strip():
        return {d: 1.0 for d in domains}
    out: Dict[str, float] = {}
    for part in s.split(','):
        part = part.strip()
        if not part:
            continue
        if '=' not in part:
            raise ValueError(f"bad weight token: {part}")
        k, v = part.split('=', 1)
        out[k.strip()] = float(v.strip())
    for d in domains:
        out.setdefault(d, 0.0)
    return out


def threshold_policy(m: int, t_min_frac: float) -> int:
    return max((m // 2) + 1, int(math.ceil(t_min_frac * m)))


def cheapest_feasible(
    combos: List[Tuple[float, Dict[str, float], List[float], List[str]]],
    t: int,
    rho_max: float,
    delta: float,
    agg: str,
    weights: Dict[str, float],
):
    target = 1.0 - delta
    for cost, by, dp, ids in combos:
        rh = rho_aggregate(by, agg=agg, weights=weights)
        if rh > rho_max + 1e-12:
            continue
        p_live = tail_from_dist(dp, t)
        if p_live + 1e-15 < target:
            continue
        return {
            't': t,
            'rho_hat': float(f"{rh:.6g}"),
            'rho_by_domain': {k: float(f"{v:.6g}") for k, v in by.items()},
            'monthly_cost_usd': float(f"{cost:.6g}"),
            'p_live': float(f"{p_live:.6g}"),
            'selected_witness_ids': ids,
        }
    return None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument('--pool', default='test_vectors/witness_candidate_pool_demo_v2.json')
    ap.add_argument('--q', type=float, default=0.12)
    ap.add_argument('--delta', type=float, default=1e-3)
    ap.add_argument('--domains', default='operator,provider,impl_family,kms_class')
    ap.add_argument('--budgets_bits', default='6,8,10,12')
    ap.add_argument('--m_min', type=int, default=5)
    ap.add_argument('--m_max', type=int, default=10)
    ap.add_argument('--t_min_frac', type=float, default=0.7)
    ap.add_argument('--agg_main', choices=['max', 'weighted'], default='max')
    ap.add_argument('--weights', default='operator=0.6,provider=0.2,impl_family=0.1,kms_class=0.1')
    ap.add_argument('--out_json', default='test_vectors/quorum_pareto_frontier_results.json')
    ap.add_argument('--out_tex', default='_insert_quorum_pareto_frontier_table.tex')
    ap.add_argument('--out_agg_tex', default='_insert_quorum_agg_comparison_table.tex')
    ap.add_argument('--out_fig', default='pct_quorum_pareto_frontier.pdf')
    ap.add_argument('--out_agg_fig', default='pct_quorum_agg_comparison.pdf')
    args = ap.parse_args()

    domains = [x.strip() for x in args.domains.split(',') if x.strip()]
    weights = parse_weights(args.weights, domains)
    ks = [int(x.strip()) for x in args.budgets_bits.split(',') if x.strip()]

    pool_obj = json.loads(Path(args.pool).read_text(encoding='utf-8'))
    pool = pool_obj.get('witnesses', [])

    combos_by_m = {m: enumerate_sets_sorted(pool, m, domains) for m in range(args.m_min, args.m_max + 1)}

    curve_by_k: Dict[int, List[Dict[str, Any]]] = {}

    for k in ks:
        B = 2.0 ** (-k)
        pts = []
        for m in range(args.m_min, args.m_max + 1):
            t = threshold_policy(m, args.t_min_frac)
            rho_max = max_rho_for_budget(m, t, args.q, B)
            if rho_max is None:
                continue
            cand = cheapest_feasible(combos_by_m[m], t, rho_max, args.delta, args.agg_main, weights)
            if not cand:
                continue
            pts.append({'k': k, 'B_dual': B, 'm': m, 't': t, 'rho_max': float(f"{rho_max:.6g}"), **cand})
        curve_by_k[k] = pts

    out = {
        'type': 'docf_quorum_pareto_frontier_results_v0',
        'params': {
            'pool': args.pool,
            'domains': domains,
            'q': args.q,
            'delta': args.delta,
            'm_range': [args.m_min, args.m_max],
            't_min_frac': args.t_min_frac,
            'threshold_policy': 't(m)=max(floor(m/2)+1, ceil(t_min_frac*m))',
            'agg_main': args.agg_main,
            'weights': weights,
        },
        'curve_by_k': curve_by_k,
    }

    Path(args.out_json).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out_json).write_text(json.dumps(out, indent=2, ensure_ascii=False), encoding='utf-8')

    # LaTeX table: show one row per m for each k (small). If too long, cap to 4 ms.
    lines = []
    lines.append(r'\begin{tabular}{r r r r r r}')
    lines.append(r'\toprule')
    lines.append(r'$k$ & $m$ & $t$ & $\hat\rho$ & cost & $P[\#\ge t]$ \\')
    lines.append(r'\midrule')

    for k in ks:
        pts = curve_by_k.get(k, [])
        if not pts:
            lines.append(f"{k} & -- & -- & -- & -- & infeasible \\\\")
            continue
        # pick up to 4 m-values: min, max, and two evenly spaced
        ms = [p['m'] for p in pts]
        choose = []
        if ms:
            choose = [ms[0]]
            if ms[-1] != ms[0]:
                choose.append(ms[-1])
            if len(ms) >= 4:
                choose.append(ms[len(ms)//3])
                choose.append(ms[2*len(ms)//3])
        choose = sorted(set(choose))[:4]
        for idx, m in enumerate(choose):
            p = next(pp for pp in pts if pp['m'] == m)
            kcell = str(k) if idx == 0 else ''
            lines.append(
                f"{kcell} & {p['m']} & {p['t']} & {p['rho_hat']:.4g} & {p['monthly_cost_usd']:.0f} & {p['p_live']:.4g} \\\\")

    lines.append(r'\bottomrule')
    lines.append(r'\end{tabular}')
    Path(args.out_tex).write_text('\n'.join(lines) + '\n', encoding='utf-8')

    # Aggregator comparison (lexicographic choice) at representative k=min(ks)
    k0 = min(ks) if ks else 6
    B0 = 2.0 ** (-k0)

    def lex_choice(agg: str, weights_local: Dict[str, float]) -> Dict[str, Any] | None:
        best = None
        for m in range(args.m_min, args.m_max + 1):
            t = threshold_policy(m, args.t_min_frac)
            rho_max = max_rho_for_budget(m, t, args.q, B0)
            if rho_max is None:
                continue
            cand = cheapest_feasible(combos_by_m[m], t, rho_max, args.delta, agg, weights_local)
            if not cand:
                continue
            row = {'m': m, 't': t, 'rho_max': rho_max, **cand}
            key = (row['m'], row['monthly_cost_usd'])
            if best is None or key < best['key']:
                best = {'key': key, 'row': row}
        return best['row'] if best else None

    ch_max = lex_choice('max', {d: 1.0 for d in domains})
    ch_w = lex_choice('weighted', weights)

    clines = []
    clines.append(r'\begin{tabular}{r r r r r}')
    clines.append(r'\toprule')
    clines.append(r'agg & $(m,t)$ & $\hat\rho$ & $\rho_{\max}$ & cost \\')
    clines.append(r'\midrule')
    if ch_max:
        clines.append(f"max & ({ch_max['m']},{ch_max['t']}) & {ch_max['rho_hat']:.4g} & {ch_max['rho_max']:.4g} & {ch_max['monthly_cost_usd']:.0f} \\\\")
    else:
        clines.append("max & -- & -- & -- & infeasible \\\\")
    if ch_w:
        clines.append(f"weighted & ({ch_w['m']},{ch_w['t']}) & {ch_w['rho_hat']:.4g} & {ch_w['rho_max']:.4g} & {ch_w['monthly_cost_usd']:.0f} \\\\")
    else:
        clines.append("weighted & -- & -- & -- & infeasible \\\\")
    clines.append(r'\bottomrule')
    clines.append(r'\end{tabular}')
    Path(args.out_agg_tex).write_text('\n'.join(clines) + '\n', encoding='utf-8')

    # Figures
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt

        plt.figure()
        for k in ks:
            pts = curve_by_k.get(k, [])
            if not pts:
                continue
            plt.plot([p['m'] for p in pts], [p['monthly_cost_usd'] for p in pts], marker='o', label=f"k={k}")
        plt.xlabel('Witness count m')
        plt.ylabel('Monthly cost (USD)')
        plt.title(f'Cost vs redundancy under budget (agg={args.agg_main})')
        plt.legend()
        plt.tight_layout()
        plt.savefig(args.out_fig)
        plt.close()

        # Aggregator comparison at k0
        def curve(agg: str, weights_local: Dict[str, float]) -> List[Tuple[int, float]]:
            pts = []
            for m in range(args.m_min, args.m_max + 1):
                t = threshold_policy(m, args.t_min_frac)
                rho_max = max_rho_for_budget(m, t, args.q, B0)
                if rho_max is None:
                    continue
                cand = cheapest_feasible(combos_by_m[m], t, rho_max, args.delta, agg, weights_local)
                if not cand:
                    continue
                pts.append((m, cand['monthly_cost_usd']))
            return pts

        cmax = curve('max', {d: 1.0 for d in domains})
        cw = curve('weighted', weights)

        plt.figure()
        if cmax:
            plt.plot([m for m, _ in cmax], [c for _, c in cmax], marker='o', label='max')
        if cw:
            plt.plot([m for m, _ in cw], [c for _, c in cw], marker='o', label='weighted')
        plt.xlabel('Witness count m')
        plt.ylabel('Monthly cost (USD)')
        plt.title(f'Aggregator comparison at k={k0}')
        plt.legend()
        plt.tight_layout()
        plt.savefig(args.out_agg_fig)
        plt.close()

    except Exception as e:
        Path(args.out_fig).write_text('figure generation failed: ' + str(e), encoding='utf-8')
        Path(args.out_agg_fig).write_text('figure generation failed: ' + str(e), encoding='utf-8')


if __name__ == '__main__':
    main()
