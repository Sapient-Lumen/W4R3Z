#!/usr/bin/env python3
"""tpv_gate_ref.py

Reference evaluator for TPV gate policies.

A TPV (Threat Posture Vector) is intended to be a compact, loggable disclosure
object. A TPV gate is a small procurement/runtime predicate over a TPV.

This tool is deliberately conservative and fail-closed:
  - Any missing required field causes reject.
  - Any catalog/semantic mismatch causes reject unless policy uses wildcard.

Usage:
  python3 tpv_gate_ref.py \
    --tpv test_vectors/threat_posture_vector_pao_demo.json \
    --policy test_vectors/tpv_gate_policy_demo.json \
    --out test_vectors/tpv_gate_eval_demo.json \
    --created_at 2026-02-26T00:00:00Z
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, List

from docf_ref_tools_common import jcs, load_json


def sha256_pref(b: bytes) -> str:
    return "sha256:" + hashlib.sha256(b).hexdigest()


def as_set(x: Any) -> set:
    if isinstance(x, list):
        return set(str(v) for v in x)
    return set()


def match_any(allowed: List[str], value: str) -> bool:
    if not isinstance(allowed, list) or len(allowed) == 0:
        return False
    if "*" in allowed:
        return True
    return value in allowed


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tpv", required=True)
    ap.add_argument("--policy", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--created_at", default="")
    args = ap.parse_args()

    tpv = load_json(args.tpv)
    pol = load_json(args.policy)

    reasons: List[str] = []

    # Basic schema sanity.
    if not (isinstance(tpv, dict) and tpv.get("type") == "docf.threat_posture_vector"):
        reasons.append("tpv.type mismatch or not an object")
    if not (isinstance(pol, dict) and pol.get("type") == "docf.tpv_gate_policy"):
        reasons.append("policy.type mismatch or not an object")

    tpv_digest = sha256_pref(jcs(tpv))
    pol_digest = sha256_pref(jcs(pol))

    # Extract required fields fail-closed.
    tpv_catalog = str(tpv.get("catalog_digest", ""))
    tpv_resolver = str(tpv.get("resolver_id", ""))
    tpv_pnf = str(tpv.get("policy_nf_digest", ""))
    grades = tpv.get("grades", {})
    tpv_L = int(grades.get("L", -1)) if isinstance(grades, dict) else -1
    tpv_D = int(grades.get("D", -1)) if isinstance(grades, dict) else -1

    pol_catalog = str(pol.get("catalog_digest", ""))
    pol_allow_res = pol.get("require_resolver_id", [])
    pol_allow_pnf = pol.get("require_policy_nf_digest", [])
    pol_min_L = int(pol.get("min_L", 0))
    pol_min_D = int(pol.get("min_D", 0))
    pol_req_mit = as_set(pol.get("require_mitigated", []))
    pol_forbid_open = as_set(pol.get("forbid_open", []))
    pol_max_open = pol.get("max_open", None)

    # Catalog binding.
    if pol_catalog != "*" and pol_catalog != tpv_catalog:
        reasons.append("catalog_digest mismatch")

    # Semantic binding.
    if not match_any(pol_allow_res, tpv_resolver):
        reasons.append("resolver_id not allowed")

    if not match_any(pol_allow_pnf, tpv_pnf):
        reasons.append("policy_nf_digest not allowed")

    # Grade thresholds.
    if tpv_L < pol_min_L:
        reasons.append(f"L grade too low: {tpv_L} < {pol_min_L}")
    if tpv_D < pol_min_D:
        reasons.append(f"D grade too low: {tpv_D} < {pol_min_D}")

    mitigated = as_set(tpv.get("mitigated", []))
    open_ = as_set(tpv.get("open", []))

    missing = sorted(list(pol_req_mit - mitigated))
    if missing:
        reasons.append("missing required mitigations: " + ",".join(missing))

    bad_open = sorted(list(pol_forbid_open & open_))
    if bad_open:
        reasons.append("forbidden open threats present: " + ",".join(bad_open))

    if isinstance(pol_max_open, int):
        if len(open_) > pol_max_open:
            reasons.append(f"too many open threats: {len(open_)} > {pol_max_open}")

    result = "accept" if len(reasons) == 0 else "reject"

    created_at = args.created_at or "2026-02-26T00:00:00Z"

    out: Dict[str, Any] = {
        "type": "docf.tpv_gate_eval",
        "version": "v0",
        "created_at": created_at,
        "policy_id": str(pol.get("policy_id", "")),
        "tpv_digest": tpv_digest,
        "policy_digest": pol_digest,
        "result": result,
        "reasons": reasons,
    }

    if isinstance(tpv.get("subject"), dict):
        out["tpv_subject"] = tpv["subject"]

    Path(args.out).write_text(json.dumps(out, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
