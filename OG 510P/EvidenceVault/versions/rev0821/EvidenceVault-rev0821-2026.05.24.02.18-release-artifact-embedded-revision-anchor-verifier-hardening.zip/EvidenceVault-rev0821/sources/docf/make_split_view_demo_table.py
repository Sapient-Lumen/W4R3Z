#!/usr/bin/env python3
"""make_split_view_demo_table.py

Generate `_insert_split_view_demo_table.tex` from `test_vectors/split_view_demo.json`.
"""
from __future__ import annotations
import argparse, json
from pathlib import Path

def _bytes_b64_list(xs):
    import base64
    return sum(len(base64.b64decode(x)) for x in xs)

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", default="test_vectors/split_view_demo.json")
    ap.add_argument("--out", dest="outp", default="_insert_split_view_demo_table.tex")
    args = ap.parse_args()

    d = json.loads(Path(args.inp).read_text(encoding="utf-8"))
    ck2 = d["checkpoint_2"]
    ckA = d["checkpoint_A_4"]
    ckB = d["checkpoint_B_4"]
    pA = d["consistency_path_A_2_to_4_b64"]
    pB = d["consistency_path_B_2_to_4_b64"]
    w = d["witness"]

    def pref(hb64):
        import base64
        h = base64.b64decode(hb64).hex()
        return h[:16] + "…"

    rows = [
        ("C2", ck2["tree_size"], pref(ck2["root_hash_b64"]), "yes", "--", "--"),
        ("CA4", ckA["tree_size"], pref(ckA["root_hash_b64"]), "yes", f"{len(pA)}", f"{_bytes_b64_list(pA)}"),
        ("CB4", ckB["tree_size"], pref(ckB["root_hash_b64"]), "yes", f"{len(pB)}", f"{_bytes_b64_list(pB)}"),
    ]
    # witness status
    wA = "yes" if w.get("cosign_ckA4") else "no"
    wB = "no (refused)" if w.get("cosign_ckB4_error") else "yes"

    tex = []
    tex.append("\\begin{table}[t]")
    tex.append("\\centering")
    tex.append("\\small")
    tex.append("\\begin{tabular}{l r l l r r}")
    tex.append("\\toprule")
    tex.append("Checkpoint & size & root prefix & log-signed & cons. len & cons. bytes \\\\")
    tex.append("\\midrule")
    for (lab, sz, rp, ls, clen, cbytes) in rows:
        tex.append(f"{lab} & {sz} & {rp} & {ls} & {clen} & {cbytes} \\\\")
    tex.append("\\midrule")
    tex.append(f"Witness cosign (CA4) & \\multicolumn{{5}}{{l}}{{{wA}}} \\\\")
    tex.append(f"Witness cosign (CB4) & \\multicolumn{{5}}{{l}}{{{wB}}} \\\\")
    tex.append("\\bottomrule")
    tex.append("\\end{tabular}")
    tex.append("\\caption{Toy split-view demonstration. The log can sign two different checkpoints at the same tree size (CA4 vs CB4). A witness that enforces consistency from its last cosigned checkpoint refuses to cosign both, preventing a client-side threshold policy from accepting both views.}")
    tex.append("\\label{tab:split-view-demo}")
    tex.append("\\end{table}")
    Path(args.outp).write_text("\n".join(tex) + "\n", encoding="utf-8")

if __name__ == "__main__":
    main()
