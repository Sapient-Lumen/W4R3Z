#!/usr/bin/env python3
"""witnessed_checkpoint_bundle_ref.py

Deterministic demo builder/verifier for `docf-witnessed-checkpoint-bundle-v0`.

- `--emit` prints the demo bundle (matches test_vectors/witnessed_checkpoint_bundle_demo.json).
- `--verify <bundle_json>` verifies log signature + witness cosignatures (threshold).

This is reference-grade code for paper examples; it is not hardened.
"""

from __future__ import annotations

import argparse
import base64
import json
from typing import Any, Dict, Tuple

from docf_ref_tools_common import jcs, sha256_hex, emit_json

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives import serialization
from cryptography.exceptions import InvalidSignature


LOG_ID = "scitt-demo"
LOG_PRIV = bytes.fromhex("22" * 32)
WIT_PRIVS = [bytes.fromhex("33" * 32), bytes.fromhex("44" * 32), bytes.fromhex("55" * 32)]
WIT_KEYIDS = ["w0", "w1", "w2"]


def b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def sha256_bytes(data: bytes) -> bytes:
    import hashlib

    return hashlib.sha256(data).digest()


def checkpoint_message(log_id: str, tree_size: int, root_hash_b64: str, issued_at: str) -> Dict[str, Any]:
    # Keep minimal and deterministic; this models the STH payload we cosign.
    return {
        "format": "rfc9162-sth",
        "log_id": log_id,
        "tree_size": tree_size,
        "root_hash_sha256_b64": root_hash_b64,
        "issued_at": issued_at,
    }


def sign_ed25519(priv_bytes: bytes, msg: bytes) -> Tuple[bytes, bytes]:
    priv = Ed25519PrivateKey.from_private_bytes(priv_bytes)
    pub = priv.public_key()
    pub_raw = pub.public_bytes(
        encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw
    )
    sig = priv.sign(msg)
    return pub_raw, sig


def verify_ed25519(pub_raw: bytes, sig: bytes, msg: bytes) -> bool:
    pub = Ed25519PublicKey.from_public_bytes(pub_raw)
    try:
        pub.verify(sig, msg)
        return True
    except InvalidSignature:
        return False


def demo_bundle() -> Dict[str, Any]:
    issued_at = "2026-02-24T16:45:00Z"
    tree_size = 1048576
    root_hash_b64 = b64(sha256_bytes(b"checkpoint_root_demo"))

    msg_obj = checkpoint_message(LOG_ID, tree_size, root_hash_b64, issued_at)
    msg_bytes = jcs(msg_obj)

    log_pub_raw, log_sig = sign_ed25519(LOG_PRIV, msg_bytes)

    # Witness cosigns a domain-separated digest binding the STH payload + log signature.
    cosign_ctx = b"DOCF-WITNESS-COSIGN-v0\x00" + sha256_bytes(msg_bytes + log_sig)

    witnesses = []
    cosigs = []
    for kid, priv in zip(WIT_KEYIDS, WIT_PRIVS):
        pub_raw, sig = sign_ed25519(priv, cosign_ctx)
        witnesses.append({"keyid": kid, "public_key_ed25519_raw_b64": b64(pub_raw)})
        # Only include two signatures to demonstrate threshold logic (2-of-3).
        if kid in ("w0", "w2"):
            cosigs.append({"keyid": kid, "sig_ed25519_b64": b64(sig)})

    core = {
        "schema": "docf-witnessed-checkpoint-bundle-v0",
        "version": 0,
        "log": {
            "log_id": LOG_ID,
            "kind": "static-ct-api",
            "checkpoint_url": "https://example.org/staticct/log/demo/checkpoint",
        },
        "checkpoint": {
            "format": "rfc9162-sth",
            "tree_size": tree_size,
            "root_hash_sha256_b64": root_hash_b64,
            "issued_at": issued_at,
            "log_public_key_ed25519_raw_b64": b64(log_pub_raw),
            "log_signature_ed25519_b64": b64(log_sig),
        },
        "witness_quorum": {"threshold": 2, "witnesses": witnesses},
        "cosignatures": cosigs,
        "notes": "demo bundle: 2-of-3 witness cosignatures over STH payload + log signature",
    }
    core["digest"] = {"sha256": sha256_hex(jcs(core))}
    return core


def verify_bundle(bundle: Dict[str, Any]) -> Dict[str, Any]:
    chk = bundle["checkpoint"]
    msg_obj = checkpoint_message(
        bundle["log"]["log_id"],
        chk["tree_size"],
        chk["root_hash_sha256_b64"],
        chk["issued_at"],
    )
    msg_bytes = jcs(msg_obj)

    log_pub_raw = base64.b64decode(chk["log_public_key_ed25519_raw_b64"])
    log_sig = base64.b64decode(chk["log_signature_ed25519_b64"])

    ok_log = verify_ed25519(log_pub_raw, log_sig, msg_bytes)

    cosign_ctx = b"DOCF-WITNESS-COSIGN-v0\x00" + sha256_bytes(msg_bytes + log_sig)
    wit_pub = {
        w["keyid"]: base64.b64decode(w["public_key_ed25519_raw_b64"])
        for w in bundle["witness_quorum"]["witnesses"]
    }

    ok_cosigs = 0
    good = []
    bad = []
    for cs in bundle["cosignatures"]:
        kid = cs["keyid"]
        sig = base64.b64decode(cs["sig_ed25519_b64"])
        pub = wit_pub.get(kid)
        if pub is None:
            bad.append({"keyid": kid, "reason": "unknown keyid"})
            continue
        if verify_ed25519(pub, sig, cosign_ctx):
            ok_cosigs += 1
            good.append(kid)
        else:
            bad.append({"keyid": kid, "reason": "invalid signature"})

    threshold = int(bundle["witness_quorum"]["threshold"])
    ok_threshold = ok_cosigs >= threshold

    return {
        "ok_log_signature": ok_log,
        "ok_cosignatures": ok_cosigs,
        "threshold": threshold,
        "ok_threshold": ok_threshold,
        "good": good,
        "bad": bad,
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit", action="store_true")
    ap.add_argument("--verify", type=str, default="")
    args = ap.parse_args()

    if args.emit:
        emit_json(demo_bundle())
        return

    if args.verify:
        with open(args.verify, "r", encoding="utf-8") as f:
            bundle = json.load(f)
        emit_json(verify_bundle(bundle))
        return

    ap.print_help()


if __name__ == "__main__":
    main()
