#!/usr/bin/env python3
"""security_claim_ref.py

Reference tool: construct a compact Soundness Security Claim (SSC).

An SSC is a small, signable summary that:
  - states the resolved end-to-end soundness bound (eps_total / security bits)
  - binds that number to key digests (manifest, ABI, attempt trace, audit report)

This is a reference sketch intended for paper examples.
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Dict, Optional

from docf_ref_tools_common import jcs, sha256_hex


def _fail(msg: str) -> None:
    raise SystemExit(f"[security_claim_ref] {msg}")


def _load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _jdump(obj: Any) -> str:
    return json.dumps(obj, indent=2, sort_keys=True, ensure_ascii=False) + "\n"


def build_claim(
    *,
    created_at: str,
    issuer_id: str,
    manifest_obj: Optional[Dict[str, Any]],
    abi_digest_sha256: Optional[str],
    attempt_trace_obj: Optional[Dict[str, Any]],
    audit_report_obj: Dict[str, Any],
    subject: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    # Digests
    digests: Dict[str, Any] = {}
    if manifest_obj is not None:
        digests["manifest_digest_sha256"] = sha256_hex(jcs(manifest_obj))
    else:
        digests["manifest_digest_sha256"] = ""

    if abi_digest_sha256:
        digests["abi_digest_sha256"] = abi_digest_sha256

    if attempt_trace_obj is not None:
        digests["attempt_trace_digest_sha256"] = sha256_hex(jcs(attempt_trace_obj))
        lvl = attempt_trace_obj.get("schema")
        if lvl == "docf_attempt_trace/v1":
            digests["attempt_trace_level"] = "T3"
        elif lvl == "docf_attempt_trace/v0":
            digests["attempt_trace_level"] = "T2"

    digests["audit_report_digest_sha256"] = sha256_hex(jcs(audit_report_obj))

    end2end = audit_report_obj.get("end2end") if isinstance(audit_report_obj, dict) else None
    if not isinstance(end2end, dict):
        _fail("audit_report must contain an 'end2end' object (e.g., docf_end2end_with_trace_report/v0)")

    eps_total = end2end.get("eps_total_bound")
    sec_bits = end2end.get("security_bits_bound")
    if sec_bits is None:
        # Some reports omit it if eps_total<=0; handle gracefully.
        sec_bits = None

    resolved: Dict[str, Any] = {
        "eps_total_bound": eps_total,
        "security_bits_bound": float(sec_bits) if isinstance(sec_bits, (int, float)) else 0.0,
        "model": "theorem:end2end",
        "Q": int(audit_report_obj.get("Q", 0)),
        "t": int(end2end.get("inputs_echo", {}).get("t", 0)) if isinstance(end2end.get("inputs_echo"), dict) else 0,
        "eps_common_mode": end2end.get("eps_common_mode", None),
    }

    claim: Dict[str, Any] = {
        "schema": "docf_security_claim/v0",
        "created_at": created_at,
        "issuer": {
            "id": issuer_id,
            "tool": "security_claim_ref/v0",
        },
        "subject": subject or {},
        "digests": digests,
        "resolved": resolved,
        "notes": [
            "SSC is a compact summary; verifiers should fetch/verify the full evidence bundle when needed.",
            "Digests are computed over RFC8785-safe-subset canonical JSON in this reference tool.",
        ],
    }
    return claim


def demo_claim() -> Dict[str, Any]:
    manifest = _load_json("test_vectors/manifest_example.json")
    attempt_trace = _load_json("test_vectors/attempt_trace_demo.json")
    audit_report = _load_json("test_vectors/end2end_with_trace_demo_out.json")

    # ABI digest is often an external commitment (suite digest, transcript ABI); we use the placeholder from the manifest.
    abi_digest = None
    try:
        abi_digest = manifest.get("transcript", {}).get("abi", {}).get("abi_digest")
        if isinstance(abi_digest, str) and abi_digest.startswith("sha256:"):
            abi_digest = abi_digest.split(":", 1)[1]
    except Exception:
        abi_digest = None

    subj = {
        "sid": "sid:demo:ssc:1",
        "bundle_digest_sha256": sha256_hex(jcs(audit_report)),
    }

    return build_claim(
        created_at="2026-02-25T00:00:00Z",
        issuer_id="docf-auditor-ref/v0",
        manifest_obj=manifest,
        abi_digest_sha256=abi_digest,
        attempt_trace_obj=attempt_trace,
        audit_report_obj=audit_report,
        subject=subj,
    )


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit", action="store_true", help="emit deterministic demo SSC")
    ap.add_argument("--in", dest="in_path", default=None, help="input JSON request (default: stdin)")
    ap.add_argument("--out", dest="out_path", default=None, help="output JSON (default: stdout)")
    args = ap.parse_args()

    if args.emit:
        claim = demo_claim()
        sys.stdout.write(_jdump(claim))
        return

    raw = sys.stdin.read() if args.in_path is None else open(args.in_path, "r", encoding="utf-8").read()
    req = json.loads(raw)

    created_at = req.get("created_at")
    if not isinstance(created_at, str) or not created_at:
        _fail("created_at (RFC3339 string) is required")
    issuer_id = req.get("issuer_id", "docf-auditor")

    manifest_obj = None
    if "manifest" in req:
        manifest_obj = req.get("manifest")
    elif "manifest_path" in req:
        manifest_obj = _load_json(req["manifest_path"])

    attempt_trace_obj = None
    if "attempt_trace" in req:
        attempt_trace_obj = req.get("attempt_trace")
    elif "attempt_trace_path" in req:
        attempt_trace_obj = _load_json(req["attempt_trace_path"])

    audit_report_obj = None
    if "audit_report" in req:
        audit_report_obj = req.get("audit_report")
    elif "audit_report_path" in req:
        audit_report_obj = _load_json(req["audit_report_path"])
    if not isinstance(audit_report_obj, dict):
        _fail("audit_report (object) or audit_report_path is required")

    abi_digest_sha256 = req.get("abi_digest_sha256")

    subject = req.get("subject") if isinstance(req.get("subject"), dict) else None

    claim = build_claim(
        created_at=created_at,
        issuer_id=str(issuer_id),
        manifest_obj=manifest_obj,
        abi_digest_sha256=str(abi_digest_sha256) if abi_digest_sha256 else None,
        attempt_trace_obj=attempt_trace_obj,
        audit_report_obj=audit_report_obj,
        subject=subject,
    )

    s = _jdump(claim)
    if args.out_path:
        open(args.out_path, "w", encoding="utf-8").write(s)
    else:
        sys.stdout.write(s)


if __name__ == "__main__":
    main()
