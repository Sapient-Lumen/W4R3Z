#!/usr/bin/env python3
"""
soundness_slo_ref.py

Reference tool for converting an operational soundness SLO (an "error budget" for
invalid accepts) into a per-proof epsilon cap.

This is a governance-facing analogue of SRE-style error budgets: given an upper bound
N on proofs in a window, and a target budget B on the *expected* number of invalid
accepts in that window, we set:

  max_eps_total_per_proof = max(0, (B - eps_common_mode_reserved) / N)

and report the implied security bits -log2(max_eps_total_per_proof). This uses only
a union bound and does not require independence across proofs; the intent is to
force budgets to be explicit and portable.

Usage:
  ./soundness_slo_ref.py compute <input.json>
  ./soundness_slo_ref.py verify  <input.json>

Input may omit the "computed" block; compute will fill it.
"""
from __future__ import annotations

import json
import math
import sys
from typing import Any, Dict


def _security_bits(eps: float) -> float:
    if eps <= 0.0:
        return float("inf")
    return -math.log(eps, 2)


def compute(obj: Dict[str, Any]) -> Dict[str, Any]:
    window = obj.get("window", {})
    win_s = int(window["window_seconds"])
    N = int(obj["max_proofs"])
    B = float(obj["target_expected_invalid_accepts"])
    eps_cm = float(obj.get("eps_common_mode_reserved", 0.0))

    if N <= 0:
        max_eps = 0.0 if B <= eps_cm else 1.0  # degenerate; treat as unconstrained if budget>cm
    else:
        max_eps = max(0.0, (B - eps_cm) / float(N))

    expected_bound = min(B, eps_cm + N * max_eps if N > 0 else max(B, eps_cm))
    bits = _security_bits(max_eps) if max_eps > 0.0 else float("inf")

    out = dict(obj)
    out["type"] = "docf-soundness-slo-v0"
    out["version"] = "0"
    out["window"] = dict(window)
    out["window"]["window_seconds"] = win_s
    out["computed"] = {
        "max_eps_total_per_proof": max_eps,
        "min_security_bits_per_proof": bits if math.isfinite(bits) else 1e309,
        "expected_invalid_accepts_bound": expected_bound,
    }
    return out


def verify(obj: Dict[str, Any]) -> None:
    out = compute(obj)
    got = obj.get("computed", {})
    want = out["computed"]
    eps_ok = abs(float(got.get("max_eps_total_per_proof", -1.0)) - want["max_eps_total_per_proof"]) <= 1e-30
    exp_ok = abs(float(got.get("expected_invalid_accepts_bound", -1.0)) - want["expected_invalid_accepts_bound"]) <= 1e-18
    if not (eps_ok and exp_ok):
        raise SystemExit(f"verify failed: computed mismatch\nwant={want}\ngot={got}\n")


def main(argv: list[str]) -> None:
    if len(argv) < 3 or argv[1] not in ("compute", "verify"):
        print("Usage: soundness_slo_ref.py compute|verify <input.json>", file=sys.stderr)
        raise SystemExit(2)
    cmd, path = argv[1], argv[2]
    with open(path, "r", encoding="utf-8") as f:
        obj = json.load(f)
    if cmd == "verify":
        verify(obj)
        print("OK")
        return
    out = compute(obj)
    print(json.dumps(out, indent=2, sort_keys=True))


if __name__ == "__main__":
    main(sys.argv)
