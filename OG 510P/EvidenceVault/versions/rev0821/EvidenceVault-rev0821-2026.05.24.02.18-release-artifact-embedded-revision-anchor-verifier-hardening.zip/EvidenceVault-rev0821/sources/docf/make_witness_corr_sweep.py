#!/usr/bin/env python3
"""make_witness_corr_sweep.py

v86.25 artifact: an *analytic* correlated-compromise sweep for witness quorums.

Why this exists (novelty vs the archive's existing witness experiments):
  - Existing scripts model correlation via operator-level compromise + residual independent.
  - This script provides a portable, parameterized *exchangeable* model with a single
    correlation knob (intraclass correlation \rho) and closed-form probabilities.

Model:
  - Witness compromise indicators X_i are exchangeable.
  - Marginal compromise probability: q = P[X_i=1].
  - Pairwise intraclass correlation: rho = Corr(X_i, X_j) for i\neq j.

We implement this via the Beta-Binomial mixture:
  theta ~ Beta(alpha, beta)
  X_i | theta ~ Bernoulli(theta) i.i.d.
Then:
  E[X_i]=q = alpha/(alpha+beta)
  Corr(X_i,X_j)=1/(alpha+beta+1)=rho
So alpha+beta = 1/rho - 1.

We compute two risks for a quorum of size m and threshold t:
  (1) P_quorum = Pr[K>=t], where K = sum_i X_i
  (2) P_dual   = Pr[dual acceptance under a split-view], assuming a hard partition
                into two groups of sizes g=floor(m/2) and m-g. Honest witnesses sign
                only their group's first view; compromised witnesses sign *both* views.

Outputs:
  - _insert_witness_corr_sweep_table.tex
  - pct_witness_corr_sweep.pdf

This script is deterministic.
"""

from __future__ import annotations

import argparse
import math
from typing import List, Tuple


def log_beta(a: float, b: float) -> float:
    return math.lgamma(a) + math.lgamma(b) - math.lgamma(a + b)


def beta_binom_pmf(m: int, k: int, alpha: float, beta: float) -> float:
    return math.comb(m, k) * math.exp(log_beta(alpha + k, beta + m - k) - log_beta(alpha, beta))


def binom_pmf(m: int, k: int, q: float) -> float:
    return math.comb(m, k) * (q**k) * ((1 - q) ** (m - k))


def binom_tail(m: int, t: int, q: float) -> float:
    return sum(binom_pmf(m, k, q) for k in range(t, m + 1))


def hypergeom_pmf(N: int, K: int, n: int, k: int) -> float:
    if k < 0 or k > n or k > K or (n - k) > (N - K):
        return 0.0
    return (math.comb(K, k) * math.comb(N - K, n - k)) / math.comb(N, n)


def dual_accept_prob_given_K(m: int, t: int, g: int, K: int) -> float:
    """Probability of dual-acceptance given K compromised witnesses.

    Let kA be the number of compromised witnesses in group A (size g), drawn
    as Hypergeom(N=m, K=K, n=g). Then:
      signers(view A) = g + (K - kA)
      signers(view B) = (m-g) + kA
    Dual-accept occurs if both counts >= t.
    """
    lo = max(0, t - (m - g))
    hi = min(g, K + g - t)
    if lo > hi:
        return 0.0
    return sum(hypergeom_pmf(m, K, g, kA) for kA in range(lo, hi + 1))


def compute_probs(m: int, t: int, q: float, rho: float) -> Tuple[float, float]:
    g = m // 2

    if rho <= 0.0:
        p_quorum = binom_tail(m, t, q)
        p_dual = sum(binom_pmf(m, K, q) * dual_accept_prob_given_K(m, t, g, K) for K in range(0, m + 1))
        return p_quorum, p_dual

    s = (1.0 / rho) - 1.0
    alpha = max(1e-9, q * s)
    beta = max(1e-9, (1.0 - q) * s)

    p_quorum = 0.0
    p_dual = 0.0
    for K in range(0, m + 1):
        pK = beta_binom_pmf(m, K, alpha, beta)
        if K >= t:
            p_quorum += pK
        p_dual += pK * dual_accept_prob_given_K(m, t, g, K)

    return p_quorum, p_dual


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--m", type=int, default=7)
    ap.add_argument("--t", type=int, default=5)
    ap.add_argument("--q", type=float, default=0.12)
    ap.add_argument("--rhos", type=str, default="0,0.01,0.03,0.05,0.1,0.2")
    ap.add_argument("--out_table", type=str, default="_insert_witness_corr_sweep_table.tex")
    ap.add_argument("--out_plot", type=str, default="pct_witness_corr_sweep.pdf")
    args = ap.parse_args()

    rhos: List[float] = [float(x.strip()) for x in args.rhos.split(",") if x.strip()]

    rows: List[Tuple[float, float, float]] = []
    for rho in rhos:
        pQ, pD = compute_probs(args.m, args.t, args.q, rho)
        rows.append((rho, pQ, pD))

    # LaTeX table
    with open(args.out_table, "w", encoding="utf-8") as f:
        f.write("\\begin{tabular}{r r r}\n")
        f.write("\\toprule\n")
        f.write(r"Correlation $\rho$ & $\Pr[K\ge t]$ & $\Pr[\mathrm{dual\ accept}]$ \\" + "\n")
        f.write("\\midrule\n")
        for rho, pQ, pD in rows:
            f.write(f"{rho:.2f} & {pQ:.4g} & {pD:.4g} \\\\\n")
        f.write("\\bottomrule\n")
        f.write("\\end{tabular}\n")

    # Plot (log-y)
    import matplotlib.pyplot as plt

    xs = [r[0] for r in rows]
    yQ = [max(r[1], 1e-12) for r in rows]
    yD = [max(r[2], 1e-12) for r in rows]

    plt.figure()
    plt.plot(xs, yQ, marker="o", label="P[K>=t]")
    plt.plot(xs, yD, marker="s", label="P[dual accept]")
    plt.yscale("log")
    plt.xlabel("Intraclass correlation ρ")
    plt.ylabel("Probability (log scale)")
    plt.title(f"Correlation sensitivity (m={args.m}, t={args.t}, q={args.q})")
    plt.legend()
    plt.tight_layout()
    plt.savefig(args.out_plot)
    plt.close()


if __name__ == "__main__":
    main()
