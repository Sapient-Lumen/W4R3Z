#!/usr/bin/env python3
"""witness_directory_ref.py

Reference helper used by Paper F/H/I to make witness-set discussions *concrete*.

It operates purely on a local snapshot JSON (checked into the archive) so that
the evolving document bundle is self-contained and deterministic.

Inputs:
  data/witness_pool_snapshot_YYYY-MM-DD.json

Modes:
  --emit           Print a compact directory summary (ids, operators, envs, vkeys).
  --to-pool        Convert snapshot into the 'pool' schema used by diversity experiments.

This is a *reference* tool, not production code.
"""
from __future__ import annotations

import argparse, json
from pathlib import Path
from typing import Dict, List

ROOT = Path(__file__).resolve().parent
DEFAULT_IN = ROOT / "data" / "witness_pool_snapshot_2026-02-28.json"

def _load(p: Path) -> Dict:
    return json.loads(p.read_text(encoding="utf-8"))

def _to_pool(snap: Dict, q_op: float, p_ind: float) -> Dict:
    ops = sorted({w["operator"] for w in snap["witnesses"]})
    operators = [{"id": op, "compromise_prob": q_op} for op in ops]
    witnesses = []
    for w in snap["witnesses"]:
        notes = " ".join(w.get("notes", []))
        p = p_ind
        if "soft key" in notes or "best-effort" in notes or w.get("env") in ("dev","testing"):
            p = min(0.05, p_ind * 2.0)
        witnesses.append({
            "id": w["id"],
            "operator": w["operator"],
            "env": w.get("env",""),
            "independent_compromise_prob": p,
        })
    return {"operators": operators, "witnesses": witnesses, "params": {"q_op": q_op, "p_ind_base": p_ind}}

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", default=str(DEFAULT_IN))
    ap.add_argument("--emit", action="store_true")
    ap.add_argument("--to-pool", action="store_true")
    ap.add_argument("--q-op", type=float, default=1e-2)
    ap.add_argument("--p-ind", type=float, default=5e-3)
    args = ap.parse_args()

    snap = _load(Path(args.inp))

    if args.emit:
        out = {
            "snapshot_date": snap.get("snapshot_date"),
            "count": len(snap.get("witnesses", [])),
            "operators": sorted({w["operator"] for w in snap.get("witnesses", [])}),
            "witnesses": [
                {"id": w["id"], "operator": w["operator"], "env": w.get("env",""), "vkey": w.get("vkey","")}
                for w in snap.get("witnesses", [])
            ],
            "sources": snap.get("sources", {}),
        }
        print(json.dumps(out, indent=2, sort_keys=True))
        return

    if args.to_pool:
        pool = _to_pool(snap, q_op=args.q_op, p_ind=args.p_ind)
        print(json.dumps(pool, indent=2, sort_keys=True))
        return

    ap.print_help()

if __name__ == "__main__":
    main()
