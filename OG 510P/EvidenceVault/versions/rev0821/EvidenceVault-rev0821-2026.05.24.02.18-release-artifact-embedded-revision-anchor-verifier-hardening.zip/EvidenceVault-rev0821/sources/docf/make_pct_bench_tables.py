#!/usr/bin/env python3
"""make_pct_bench_tables.py

Generate reproducible microbenchmarks and LaTeX tables for Paper F/G.

We intentionally benchmark *verification* primitives (hashing + signature checks)
because those dominate the client-side cost model and scale with log size only
through path length (O(log n)).

The benchmarks are for this archive's *reference* Python implementations.
They are not claims about production systems.

Outputs:
  - test_vectors/pct_bench_results.json
  - _insert_pct_bench_table.tex
  - _insert_pct_bundle_bench_table.tex

Usage:
  ./make_pct_bench_tables.py
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Tuple

import hashlib

import transparency_log_ref as tlog
import checkpoint_ref
import witness_monitor_ref as wmon
import pct_bundle_ref


def _sha256(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()


def _node_hash(l: bytes, r: bytes) -> bytes:
    return _sha256(b"\x01" + l + r)


def _leaf_hash(x: bytes) -> bytes:
    return _sha256(b"\x00" + x)


def _fold_inclusion_root_pow2(leaf: bytes, index: int, tree_size: int, path: List[bytes]) -> bytes:
    """Compute a Merkle root for a power-of-two tree size using RFC6962 hashing.

    We generate synthetic (but valid) inclusion instances so we can benchmark
    verification without building a full tree.
    """
    assert tree_size > 0 and (tree_size & (tree_size - 1) == 0), "tree_size must be power of two"
    h = _leaf_hash(leaf)
    idx = index
    for sib in path:
        if idx % 2 == 0:
            h = _node_hash(h, sib)
        else:
            h = _node_hash(sib, h)
        idx //= 2
    return h


def _synthetic_consistency_instance(first: int, second: int, max_tries: int = 32) -> Tuple[bytes, bytes, List[bytes]]:
    """Construct a *synthetic but valid* (first_hash, second_hash, path) triple.

    We pick a random path of length ~log2(second)+2 and compute the implied
    roots by replaying the RFC9162 verifier logic (but without comparing).
    Then we set first_hash/second_hash to those implied roots.

    This lets us benchmark verify_consistency_v2 at scale without building
    large trees.
    """

    if not (0 < first < second):
        raise ValueError("need 0 < first < second")

    import secrets

    # We avoid the "prepend first_hash if power-of-two" corner by allowing it;
    # our construction simply handles it by defining first_hash after.
    for _ in range(max_tries):
        # Start slightly long, then trim to the exact number of nodes consumed
        # before sn hits 0, because the RFC9162 verifier rejects "extra" nodes.
        L = second.bit_length() + 4
        path_full = [secrets.token_bytes(32) for _ in range(L)]

        # Replay verifier logic, computing the implied fr/sr.
        fn = first - 1
        sn = second - 1

        p = list(path_full)
        # Step 2: if first is power of two, verifier prepends first_hash.
        # We can't do that directly. Instead, we *skip* this feature by ensuring
        # first is not power-of-two, or we accept it by constructing as if
        # verifier prepended an unknown first_hash and later solving for it.
        # To keep this robust, we simply pick first not power-of-two in benchmarks.
        # Here we still support power-of-two by treating p[0] as that prepended value.
        # (This is a conservative overestimate of work.)
        if (first & (first - 1)) == 0:
            # Model the prepend by reusing p[0] as the would-be first_hash.
            pass

        if fn & 1:
            while fn & 1:
                fn >>= 1
                sn >>= 1

        fr = p[0]
        sr = p[0]

        used = 1
        for c in p[1:]:
            if sn == 0:
                break
            if (fn & 1) or (fn == sn):
                fr = _node_hash(c, fr)
                sr = _node_hash(c, sr)
                if not (fn & 1):
                    while (not (fn & 1)) and (fn != 0):
                        fn >>= 1
                        sn >>= 1
            else:
                sr = _node_hash(sr, c)
            fn >>= 1
            sn >>= 1
            used += 1

        if sn == 0:
            # Success: the verifier would accept if we set hashes to (fr, sr)
            # and provide exactly the nodes it consumed.
            return fr, sr, path_full[:used]

    raise RuntimeError("failed to synthesize a consistency instance")


@dataclass
class BenchRow:
    name: str
    params: str
    median_us: float


def _median(xs: List[float]) -> float:
    ys = sorted(xs)
    n = len(ys)
    if n == 0:
        return 0.0
    if n % 2 == 1:
        return ys[n // 2]
    return 0.5 * (ys[n // 2 - 1] + ys[n // 2])


def bench_inclusion(n: int, iters: int = 2000) -> BenchRow:
    import secrets

    assert (n & (n - 1)) == 0, "n must be power of two"
    L = n.bit_length() - 1
    leaf = secrets.token_bytes(32)
    path = [secrets.token_bytes(32) for _ in range(L)]
    root = _fold_inclusion_root_pow2(leaf, 0, n, path)

    # Warmup
    tlog.verify_inclusion(leaf, 0, n, path, root)

    ts: List[float] = []
    for _ in range(iters):
        t0 = time.perf_counter()
        ok = tlog.verify_inclusion(leaf, 0, n, path, root)
        t1 = time.perf_counter()
        if not ok:
            raise RuntimeError("verify_inclusion unexpectedly failed")
        ts.append((t1 - t0) * 1e6)

    # Avoid '^' (math-mode) in LaTeX tables.
    return BenchRow("verify_inclusion", f"n=2\\textsuperscript{{{L}}} (path={L} hashes)", _median(ts))


def bench_consistency(first: int, second: int, iters: int = 2000) -> BenchRow:
    fh, sh, path = _synthetic_consistency_instance(first, second)
    # Warmup
    tlog.verify_consistency_v2(first, fh, second, sh, path)

    ts: List[float] = []
    for _ in range(iters):
        t0 = time.perf_counter()
        ok = tlog.verify_consistency_v2(first, fh, second, sh, path)
        t1 = time.perf_counter()
        if not ok:
            raise RuntimeError("verify_consistency unexpectedly failed")
        ts.append((t1 - t0) * 1e6)

    return BenchRow("verify_consistency", f"m={first}, n={second}, path={len(path)} nodes", _median(ts))


def bench_witness_verify(w: int, iters: int = 2000) -> BenchRow:
    """Benchmark verifying w Ed25519 cosignatures over one checkpoint."""
    log_id = "docf-bench-log"
    log_sk, _ = checkpoint_ref.demo_log_keypair()
    root = b"\x11" * 32
    ckpt = checkpoint_ref.sign_checkpoint(log_id, 1024, root, log_sk)

    cosigs = []
    for i in range(w):
        wid = f"w{i+1}"
        wsk, wpk = wmon.demo_witness_keypair(wid)
        st = wmon.WitnessState(wid, wsk, wpk, None)
        cs = st.cosign(ckpt, [])
        cosigs.append(cs)

    # Warmup
    for cs in cosigs:
        wmon.verify_cosignature(cs, ckpt)

    ts: List[float] = []
    for _ in range(iters):
        t0 = time.perf_counter()
        ok = 0
        for cs in cosigs:
            if wmon.verify_cosignature(cs, ckpt):
                ok += 1
        t1 = time.perf_counter()
        if ok != w:
            raise RuntimeError("cosig verify failed")
        ts.append((t1 - t0) * 1e6)

    return BenchRow("verify_witness_cosigs", f"w={w} Ed25519", _median(ts))


def bench_bundle_emit_verify(iters: int = 200) -> Dict[str, Any]:
    """Benchmark end-to-end bundle emit+verify on the demo bundle."""
    tmp = Path("/tmp/pct_bundle_tmp.json")
    emit_ts: List[float] = []
    ver_ts: List[float] = []
    sizes: List[int] = []
    for _ in range(iters):
        t0 = time.perf_counter()
        pct_bundle_ref.emit_demo(str(tmp))
        t1 = time.perf_counter()
        ok = pct_bundle_ref.verify_bundle(str(tmp))
        t2 = time.perf_counter()
        if not ok:
            raise RuntimeError("bundle verify failed")
        emit_ts.append((t1 - t0) * 1e3)  # ms
        ver_ts.append((t2 - t1) * 1e3)  # ms
        sizes.append(tmp.stat().st_size)
    return {
        "emit_median_ms": _median(emit_ts),
        "verify_median_ms": _median(ver_ts),
        "bundle_bytes_median": int(_median([float(x) for x in sizes])),
        "bundle_bytes_min": int(min(sizes)),
        "bundle_bytes_max": int(max(sizes)),
        "iters": iters,
    }


def write_tables(rows: List[BenchRow], bundle_stats: Dict[str, Any]) -> None:
    # LaTeX primitive bench table
    lines = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append("\\begin{tabular}{l l r}")
    lines.append("\\toprule")
    lines.append("Primitive & Parameters & Median verify time (\\textmu s)\\\\")
    lines.append("\\midrule")
    for r in rows:
        # Ensure primitive names with underscores render correctly.
        name = r.name.replace("_", r"\_")
        lines.append(f"\\texttt{{{name}}} & {r.params} & {r.median_us:.2f}\\\\")
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\caption{Microbenchmarks of PCT verification primitives using the archive's Python reference implementations on the snapshot build host. These numbers are for sanity-checking overhead orders of magnitude; production implementations will differ.}")
    lines.append("\\label{tab:pct-bench}")
    lines.append("\\end{table}")
    Path("_insert_pct_bench_table.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")

    # LaTeX end-to-end table
    b = bundle_stats
    lines = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append("\\begin{tabular}{l r}")
    lines.append("\\toprule")
    lines.append("End-to-end PCT bundle (demo) & Value\\\\")
    lines.append("\\midrule")
    lines.append(f"Median emitted bundle size (bytes) & {b['bundle_bytes_median']}\\\\")
    lines.append(f"Median emit time (ms) & {b['emit_median_ms']:.2f}\\\\")
    lines.append(f"Median verify time (ms) & {b['verify_median_ms']:.2f}\\\\")
    lines.append(f"Runs & {b['iters']}\\\\")
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\caption{End-to-end demo bundle emission and verification using \\texttt{pct\\_bundle\\_ref.py}. Times include signature checks, Merkle inclusion checks, and consistency+witness verification.}")
    lines.append("\\label{tab:pct-bundle-bench}")
    lines.append("\\end{table}")
    Path("_insert_pct_bundle_bench_table.tex").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    rows: List[BenchRow] = []
    for n in [2 ** 12, 2 ** 16, 2 ** 20]:
        rows.append(bench_inclusion(n))

    # Consistency: choose non-power-of-two m to exercise more branches.
    rows.append(bench_consistency(1000, 2 ** 16))
    rows.append(bench_consistency(1000, 2 ** 20))

    for w in [1, 3, 5]:
        rows.append(bench_witness_verify(w))

    bundle_stats = bench_bundle_emit_verify(iters=200)

    out = {
        "rows": [r.__dict__ for r in rows],
        "bundle": bundle_stats,
        "env": {
            "python": os.sys.version.split()[0],
        },
    }
    Path("test_vectors").mkdir(exist_ok=True)
    Path("test_vectors/pct_bench_results.json").write_text(json.dumps(out, indent=2), encoding="utf-8")

    write_tables(rows, bundle_stats)
    print("wrote test_vectors/pct_bench_results.json and LaTeX inserts")


if __name__ == "__main__":
    main()
