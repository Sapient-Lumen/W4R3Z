#!/usr/bin/env python3
"""option_repricing_report_ref.py

Reference tool: conservative union-bound repricing that includes retries + option surfaces.

We extend the simple "volume tax" repricer (repricer_ref.py) with two additional
multipliers that show up in strict-deadline distributed proving:

  - Q: observed retry/attempt count per delivered proof (from MCR / trace)
  - T_total: conditioning / abort-option attempt multiplier from Option Surface Ledger (OSL)
  - b_att: any additional per-attempt bias bits not captured by T_total (default 0)

A conservative trial bound for a governance window that accepts N proofs is:

  trials <= N * Q_eff,
  where Q_eff := Q * T_total * 2^{b_att}.

Under a union bound, if each trial has soundness error <= 2^{-s}, then
window error <= trials * 2^{-s}. Therefore the required per-trial security bits are

  s >= window_bits + ceil(log2(N * Q_eff)).

Input JSON
----------
{
  "N": 1000,
  "window_security_bits": 80,
  "Q": 3,
  "T_total": 10,
  "b_att": 0
}

Output JSON
-----------
{
  "type": "docf_option_repricing_report_v0",
  "Q_eff": 30,
  "tax_bits": {"volume": 10, "attempt": 5, "total": 15},
  "per_trial_security_bits_min": 95,
  "per_trial_eps_max": "2^-95.0000"
}

This tool is intentionally conservative and does not model correlation terms,
common-mode failures, or cancellation. It is a governance calculator, not a resolver.
"""

from __future__ import annotations

import argparse
import json
import math
import sys
from typing import Any, Dict


def _to_int(x: Any, name: str) -> int:
    if x is None:
        raise ValueError(f"missing {name}")
    if isinstance(x, bool):
        raise TypeError(f"{name} must be an integer")
    if isinstance(x, int):
        return int(x)
    if isinstance(x, str):
        return int(x.strip())
    raise TypeError(f"{name} must be an integer")


def _to_float(x: Any, name: str) -> float:
    if x is None:
        raise ValueError(f"missing {name}")
    if isinstance(x, (int, float)):
        return float(x)
    if isinstance(x, str):
        s = x.strip()
        if s.startswith("2^-"):
            return 2.0 ** (-float(s[3:]))
        return float(s)
    raise TypeError(f"{name} must be numeric")


def _ceil_log2(n: int) -> int:
    if n <= 1:
        return 0
    return int(math.ceil(math.log(n, 2)))


def option_repricing_report(obj: Dict[str, Any]) -> Dict[str, Any]:
    N = _to_int(obj.get("N", 1), "N")
    if N < 1:
        raise ValueError("N must be >= 1")

    Q = _to_int(obj.get("Q", 1), "Q")
    if Q < 1:
        raise ValueError("Q must be >= 1")

    T_total = _to_int(obj.get("T_total", 1), "T_total")
    if T_total < 1:
        raise ValueError("T_total must be >= 1")

    b_att = _to_int(obj.get("b_att", 0), "b_att")
    if b_att < 0:
        raise ValueError("b_att must be >= 0")

    # Prefer bits; allow eps.
    if "window_security_bits" in obj:
        S = _to_float(obj["window_security_bits"], "window_security_bits")
        if S < 0:
            raise ValueError("window_security_bits must be nonnegative")
        window_eps = 2.0 ** (-S) if S != 0 else 1.0
    elif "window_eps" in obj:
        window_eps = _to_float(obj["window_eps"], "window_eps")
        if window_eps <= 0 or window_eps > 1:
            raise ValueError("window_eps must be in (0,1]")
        S = -math.log(window_eps, 2)
    else:
        raise ValueError("provide either window_security_bits or window_eps")

    Q_eff = int(Q) * int(T_total) * (1 << int(b_att))
    volume_tax = _ceil_log2(N)
    attempt_tax = _ceil_log2(Q_eff)
    total_tax = _ceil_log2(int(N) * int(Q_eff))

    per_bits = float(S) + float(total_tax)
    per_eps = 2.0 ** (-per_bits)

    return {
        "type": "docf_option_repricing_report_v0",
        "N": int(N),
        "Q": int(Q),
        "T_total": int(T_total),
        "b_att": int(b_att),
        "Q_eff": int(Q_eff),
        "window_security_bits": float(S),
        "window_eps": window_eps,
        "tax_bits": {
            "volume": int(volume_tax),
            "attempt": int(attempt_tax),
            "total": int(total_tax),
            "rule": "total=ceil(log2(N*Q_eff))",
        },
        "per_trial_security_bits_min": float(per_bits),
        "per_trial_eps_max": f"2^-{per_bits:.4f}",
        "notes": obj.get(
            "note",
            "Union-bound repricing with retries+options: bits = window_bits + ceil(log2(N*Q*T_total*2^{b_att})).",
        ),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="infile", default=None, help="Input JSON file (default: stdin).")
    ap.add_argument("--out", dest="outfile", default=None, help="Output JSON file (default: stdout).")
    args = ap.parse_args()

    raw = sys.stdin.read() if args.infile is None else open(args.infile, "r", encoding="utf-8").read()
    obj = json.loads(raw) if raw.strip() else {}
    out = option_repricing_report(obj)

    s = json.dumps(out, indent=2, sort_keys=False) + "\n"
    if args.outfile is None:
        sys.stdout.write(s)
    else:
        with open(args.outfile, "w", encoding="utf-8") as f:
            f.write(s)


if __name__ == "__main__":
    main()
