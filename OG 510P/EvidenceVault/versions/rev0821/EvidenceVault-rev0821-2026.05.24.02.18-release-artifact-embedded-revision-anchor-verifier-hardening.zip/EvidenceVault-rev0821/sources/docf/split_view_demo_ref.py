#!/usr/bin/env python3
"""split_view_demo_ref.py

Demonstrate a toy "split-view" attack and why witnesses + consistency matter.

We create:
  - a base log with 2 leaves and checkpoint C2
  - two divergent extensions to size 4:
      branch A adds leaves L2a,L3a -> checkpoint CA4
      branch B adds leaves L2b,L3b -> checkpoint CB4
  The log can sign both checkpoints (same log key), so without gossip/witnessing
  a client can be fooled into accepting either view.

We then add a witness that cosigns only one branch, because cosigning requires:
  - consistency from the last checkpoint it cosigned, and
  - no equivocation at the same tree size.

Output: `test_vectors/split_view_demo.json`
"""

from __future__ import annotations

import argparse
import base64
import json
from pathlib import Path
from typing import Any, Dict, List

import checkpoint_ref
import transparency_log_ref as tlog
import witness_monitor_ref as wmon


def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="test_vectors/split_view_demo.json")
    args = ap.parse_args()

    log_id = "docf-demo-log"
    log_sk, _ = checkpoint_ref.demo_log_keypair()

    # Build leaf sets for base and two divergent histories.
    base_entries = [b"leaf0", b"leaf1"]
    A_entries = base_entries + [b"leaf2A", b"leaf3A"]
    B_entries = base_entries + [b"leaf2B", b"leaf3B"]

    root2 = tlog.merkle_root(base_entries)
    rootA4 = tlog.merkle_root(A_entries)
    rootB4 = tlog.merkle_root(B_entries)

    ck2 = checkpoint_ref.sign_checkpoint(log_id, 2, root2, log_sk)
    ckA4 = checkpoint_ref.sign_checkpoint(log_id, 4, rootA4, log_sk)
    ckB4 = checkpoint_ref.sign_checkpoint(log_id, 4, rootB4, log_sk)

    # Consistency paths from 2->4 for each branch (computed on that branch's data).
    pathA = [_b64(x) for x in tlog.consistency_proof_v2(A_entries, 2)]
    pathB = [_b64(x) for x in tlog.consistency_proof_v2(B_entries, 2)]

    # Witness cosigns ck2, then will cosign only one of {ckA4, ckB4}.
    wsk, wpk = wmon.demo_witness_keypair("w1")
    w = wmon.WitnessState("w1", wsk, wpk, None)
    cosig2 = w.cosign(ck2, [])  # no prior

    cosigA = w.cosign(ckA4, pathA)  # consistent with ck2
    # Attempt to cosign B (same size=4, different root) -> should fail.
    errB = None
    try:
        _ = w.cosign(ckB4, pathB)
    except Exception as e:
        errB = str(e)

    out = {
        "type": "docf_split_view_demo_v0",
        "log_id": log_id,
        "checkpoint_2": ck2,
        "checkpoint_A_4": ckA4,
        "checkpoint_B_4": ckB4,
        "consistency_path_A_2_to_4_b64": pathA,
        "consistency_path_B_2_to_4_b64": pathB,
        "witness": {
            "witness_id": "w1",
            "cosign_ck2": cosig2,
            "cosign_ckA4": cosigA,
            "cosign_ckB4_error": errB,
        },
        "note": "A log can sign both CA4 and CB4 (split view). A witness that requires consistency refuses to cosign both.",
    }

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(f"wrote {args.out}")


if __name__ == "__main__":
    main()
