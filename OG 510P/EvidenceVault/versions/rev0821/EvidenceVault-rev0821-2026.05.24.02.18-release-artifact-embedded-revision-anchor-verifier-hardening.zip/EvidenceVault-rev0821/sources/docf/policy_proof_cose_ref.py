#!/usr/bin/env python3
"""
policy_proof_cose_ref.py

NOTE: COSE_Sign1 is CBOR-based (RFC 9052). This snapshot does not vendor a CBOR
implementation, so this tool emits an *illustrative* "COSE-JSON diagnostic"
object that shows how one would map the docf-policy-proof-v0 payload into
COSE headers and signature bytes.

Use policy_proof_dsse_ref.py for a real signed envelope in this snapshot.
"""
from __future__ import annotations

import argparse, base64, json
from docf_ref_tools_common import jcs, sha256_hex, emit_json

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

PAYLOAD_TYPE = "application/vnd.docf.policy-proof.v0+json"
KEYID = "docf-test-ed25519-k0"
PRIV_BYTES = bytes.fromhex("11" * 32)

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit", action="store_true")
    args = ap.parse_args()
    if not args.emit:
        ap.print_help()
        return

    with open("test_vectors/policy_proof_demo.json", "r", encoding="utf-8") as f:
        payload_obj = json.load(f)

    priv = Ed25519PrivateKey.from_private_bytes(PRIV_BYTES)
    pub = priv.public_key()
    pub_raw = pub.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)

    payload_bytes = jcs(payload_obj)
    sig = priv.sign(payload_bytes)  # placeholder; real COSE signs Sig_structure over CBOR
    cose_like = {
      "cose_json_diagnostic_only": True,
      "protected": {
        "alg": "EdDSA",
        "typ": PAYLOAD_TYPE
      },
      "unprotected": {
        "kid": KEYID
      },
      "payload_b64": base64.b64encode(payload_bytes).decode("ascii"),
      "signature_b64": base64.b64encode(sig).decode("ascii"),
      "pubkey_ed25519_raw_b64": base64.b64encode(pub_raw).decode("ascii"),
      "notes": "This is NOT a wire-format COSE_Sign1. It is a diagnostic mapping."
    }
    emit_json(cose_like)

if __name__ == "__main__":
    main()
