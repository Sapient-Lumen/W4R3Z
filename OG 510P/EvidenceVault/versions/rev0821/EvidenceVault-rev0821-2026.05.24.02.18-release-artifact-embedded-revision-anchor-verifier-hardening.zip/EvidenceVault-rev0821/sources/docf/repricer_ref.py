#!/usr/bin/env python3
"""repricer_ref.py

Reference tool: "repricing" in the sense of turning a *window* (epoch/slot)
security target into a *per-proof* \eps (or bits) requirement under a conservative
union bound.

This is intentionally small and dependency-free. It is meant to be a replayable
calculator for governance docs that say things like:
  - "We will accept at most N proofs per epoch, and the epoch-level false-accept
     budget is <= 2^-S."
  - "Therefore each accepted proof must resolve to at least S + ceil(log2 N)
     bits (plus any additional amplifier terms from retries/bias)."

Input JSON (either file via --in or stdin):
{
  "N": 1000,
  "window_security_bits": 80,
  "note": "optional"
}

Output JSON:
{
  "type": "docf_repricing_report_v0",
  "N": ...,
  "window_security_bits": ...,
  "per_proof_security_bits_min": ...,
  "per_proof_eps_max": "2^-..."
}

This tool does *not* attempt to model retries, bias, or common-mode terms. Those
belong in the end-to-end resolver (end2end_resolve_ref.py). This repricer only
accounts for the volume tax from accepting multiple proofs in a window.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from typing import Any, Dict


def _to_int(x: Any, name: str) -> int:
    if isinstance(x, bool):
        raise TypeError(f"{name} must be an integer")
    if isinstance(x, int):
        return int(x)
    if isinstance(x, str):
        return int(x.strip())
    raise TypeError(f"{name} must be an integer")


def _to_float(x: Any, name: str) -> float:
    if x is None:
        raise ValueError(f"missing {name}")
    if isinstance(x, (int, float)):
        return float(x)
    if isinstance(x, str):
        s = x.strip()
        if s.startswith("2^-"):
            return 2.0 ** (-float(s[3:]))
        return float(s)
    raise TypeError(f"{name} must be numeric")


def _ceil_log2(n: int) -> int:
    if n <= 1:
        return 0
    return int(math.ceil(math.log(n, 2)))


def repricing_report(obj: Dict[str, Any]) -> Dict[str, Any]:
    N = _to_int(obj.get("N", 1), "N")
    if N < 1:
        raise ValueError("N must be >= 1")

    # Prefer bits; allow eps if given.
    if "window_security_bits" in obj:
        S = _to_float(obj["window_security_bits"], "window_security_bits")
        if S < 0:
            raise ValueError("window_security_bits must be nonnegative")
        window_eps = 2.0 ** (-S) if S != 0 else 1.0
    elif "window_eps" in obj:
        window_eps = _to_float(obj["window_eps"], "window_eps")
        if window_eps <= 0 or window_eps > 1:
            raise ValueError("window_eps must be in (0,1]")
        S = -math.log(window_eps, 2)
    else:
        raise ValueError("provide either window_security_bits or window_eps")

    tax = _ceil_log2(N)
    per_bits = S + tax
    per_eps = 2.0 ** (-per_bits)

    out = {
        "type": "docf_repricing_report_v0",
        "N": N,
        "window_security_bits": float(S),
        "window_eps": window_eps,
        "volume_tax_bits": tax,
        "per_proof_security_bits_min": float(per_bits),
        "per_proof_eps_max": f"2^-{per_bits:.4f}",
        "notes": obj.get("note", "Union bound repricing: per-proof bits = window bits + ceil(log2 N)."),
    }
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="infile", default=None, help="Input JSON file (default: stdin).")
    ap.add_argument("--out", dest="outfile", default=None, help="Output JSON file (default: stdout).")
    args = ap.parse_args()

    raw = sys.stdin.read() if args.infile is None else open(args.infile, "r", encoding="utf-8").read()
    obj = json.loads(raw) if raw.strip() else {}
    rep = repricing_report(obj)

    s = json.dumps(rep, indent=2, sort_keys=False) + "\n"
    if args.outfile is None:
        sys.stdout.write(s)
    else:
        with open(args.outfile, "w", encoding="utf-8") as f:
            f.write(s)


if __name__ == "__main__":
    main()
