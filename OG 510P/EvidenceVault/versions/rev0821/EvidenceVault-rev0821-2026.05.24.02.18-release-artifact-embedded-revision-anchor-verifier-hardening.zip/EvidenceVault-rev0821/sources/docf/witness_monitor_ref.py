#!/usr/bin/env python3
"""witness_monitor_ref.py

Reference witness cosigning for transparency checkpoints.

A witness maintains (per log_id) the most recent checkpoint it has cosigned.
To cosign a new checkpoint, the witness:
  1) verifies the log's checkpoint signature, and
  2) verifies a consistency proof from the last cosigned checkpoint to the new one, and
  3) signs the new checkpoint message if consistent.

This is a pragmatic "anti split-view" building block inspired by:
  - CT gossip (draft-ietf-trans-gossip)
  - witness cosigning (CoSi)
  - supply-chain transparency ecosystems (SCITT / Sigstore)

This file is a toy; real deployments need persistence, key mgmt, and witness policies.
"""

from __future__ import annotations

import argparse
import base64
import json
from dataclasses import dataclass
from typing import Any, Dict, Optional

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

import checkpoint_ref
import transparency_log_ref as tlog


def _jcs(x: Any) -> bytes:
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def _unb64(s: str) -> bytes:
    return base64.b64decode(s.encode("ascii"))


def demo_witness_keypair(witness_id: str) -> tuple[Ed25519PrivateKey, bytes]:
    seed = (b"docf-demo-witness-" + witness_id.encode("utf-8") + b"-seed" + b"0" * 64)[:32]
    sk = Ed25519PrivateKey.from_private_bytes(seed)
    pk = sk.public_key().public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
    return sk, pk


@dataclass
class WitnessState:
    witness_id: str
    sk: Ed25519PrivateKey
    pk_raw: bytes
    last_checkpoint: Optional[Dict[str, Any]] = None

    def cosign(self, new_checkpoint: Dict[str, Any], consistency_path_b64: list[str]) -> Dict[str, Any]:
        # Verify log signature.
        if not checkpoint_ref.verify_checkpoint(new_checkpoint):
            raise ValueError("bad log signature on checkpoint")

        # If we have a previous checkpoint, require a valid consistency proof.
        if self.last_checkpoint is not None:
            first = int(self.last_checkpoint["tree_size"])
            second = int(new_checkpoint["tree_size"])
            if second < first:
                raise ValueError("checkpoint moved backwards")
            if second == first:
                # same size: allow only if root hash identical (prevents equivocation at same size)
                if new_checkpoint["root_hash_b64"] != self.last_checkpoint["root_hash_b64"]:
                    raise ValueError("split-view detected: same size, different root")
            else:
                ok = tlog.verify_consistency_v2(
                    first,
                    _unb64(self.last_checkpoint["root_hash_b64"]),
                    second,
                    _unb64(new_checkpoint["root_hash_b64"]),
                    [_unb64(x) for x in consistency_path_b64],
                )
                if not ok:
                    raise ValueError("consistency proof failed")

        # Sign the new checkpoint message.
        msg = checkpoint_ref.checkpoint_message(
            new_checkpoint["log_id"],
            int(new_checkpoint["tree_size"]),
            new_checkpoint["root_hash_b64"],
            new_checkpoint["timestamp"],
        )
        sig = self.sk.sign(msg)

        self.last_checkpoint = new_checkpoint

        return {
            "type": "docf_witness_cosignature_v0",
            "witness_id": self.witness_id,
            "witness_public_key_b64": _b64(self.pk_raw),
            "signature_b64": _b64(sig),
        }


def verify_cosignature(cosig: Dict[str, Any], checkpoint_obj: Dict[str, Any]) -> bool:
    try:
        msg = checkpoint_ref.checkpoint_message(
            checkpoint_obj["log_id"],
            int(checkpoint_obj["tree_size"]),
            checkpoint_obj["root_hash_b64"],
            checkpoint_obj["timestamp"],
        )
        pk = Ed25519PublicKey.from_public_bytes(_unb64(cosig["witness_public_key_b64"]))
        pk.verify(_unb64(cosig["signature_b64"]), msg)
        return True
    except Exception:
        return False


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit-demo", action="store_true")
    ap.add_argument("--witness-id", default="w1")
    args = ap.parse_args()

    if args.emit_demo:
        # Minimal demo: witness cosigns a single checkpoint (no prior state).
        sk, pk = demo_witness_keypair(args.witness_id)
        st = WitnessState(args.witness_id, sk, pk, None)

        log_sk, _ = checkpoint_ref.demo_log_keypair()
        ck = checkpoint_ref.sign_checkpoint("docf-demo-log", 4, b"\x11" * 32, log_sk)
        cosig = st.cosign(ck, [])
        print(json.dumps({"checkpoint": ck, "cosignature": cosig}, indent=2))
        print("verify cosig:", verify_cosignature(cosig, ck))
        return

    ap.print_help()


if __name__ == "__main__":
    main()
