#!/usr/bin/env python3
"""end2end_resolve_with_trace_ref.py

Reference tool: attempt-trace extraction + end-to-end bound.

This tool composes:
  - attempt_trace_extractor_ref.py (Theorem \ref{thm:attempt-extract})
  - end2end_resolve_ref.py         (Theorem \ref{thm:end2end})

so an auditor can go from a *witnessed attempt trace* -> retry multiplier Q
-> conservative security-bits report.

Input JSON format (one of):
  {
    "attempt_trace": { ... docf_attempt_trace/v0 ... },
    "params": { ... end2end params except Q ... },
    "use_seed_locked": true,
    "target_security_bits": 128
  }

or
  {
    "attempt_trace_path": "test_vectors/attempt_trace_demo.json",
    "params": { ... }
  }

The emitted report bundles the extracted attempt report and the end2end report.

Notes:
  - This is intentionally dependency-free; production auditors should use
    exact arithmetic / intervals where appropriate.
  - The tool is deterministic given the inputs.
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any, Dict


def _fail(msg: str) -> None:
    raise SystemExit(f"[end2end_resolve_with_trace_ref] {msg}")


def _load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _jdump(obj: Any) -> str:
    return json.dumps(obj, indent=2, sort_keys=True) + "\n"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="in_path", default=None, help="Input JSON (default: stdin)")
    ap.add_argument("--out", dest="out_path", default=None, help="Output JSON (default: stdout)")
    args = ap.parse_args()

    raw = sys.stdin.read() if args.in_path is None else open(args.in_path, "r", encoding="utf-8").read()
    obj = json.loads(raw)

    # Local imports (kept inside main so the file remains copyable as a single artifact).
    try:
        from attempt_trace_extractor_ref import run as extract_attempt
        from end2end_resolve_ref import end2end_bound
    except Exception as e:
        _fail(f"failed to import sibling tools: {e}")

    trace = obj.get("attempt_trace")
    if trace is None:
        trace_path = obj.get("attempt_trace_path")
        if not trace_path:
            _fail("expected attempt_trace or attempt_trace_path")
        trace = _load_json(trace_path)

    if trace.get("schema") not in ("docf_attempt_trace/v0","docf_attempt_trace/v1"):
        _fail("attempt_trace must use schema docf_attempt_trace/v0 or docf_attempt_trace/v1")

    params = obj.get("params", {})
    if not isinstance(params, dict):
        _fail("params must be an object")

    use_seed_locked = bool(obj.get("use_seed_locked", True))

    attempt_rep = extract_attempt(trace)
    Q = int(attempt_rep["Q_eval_seed_locked"] if use_seed_locked else attempt_rep["Q_eval"])

    # Feed Q and optional target bits into the end2end params.
    p2 = dict(params)
    p2["Q"] = Q
    if "target_security_bits" in obj and "target_security_bits" not in p2:
        p2["target_security_bits"] = obj["target_security_bits"]

    end2end_rep = end2end_bound(p2)

    out = {
        "schema": "docf_end2end_with_trace_report/v0",
        "use_seed_locked": use_seed_locked,
        "Q": Q,
        "attempt_trace_extract": attempt_rep,
        "end2end": end2end_rep,
    }

    if args.out_path:
        with open(args.out_path, "w", encoding="utf-8") as f:
            f.write(_jdump(out))
    else:
        sys.stdout.write(_jdump(out))


if __name__ == "__main__":
    main()
