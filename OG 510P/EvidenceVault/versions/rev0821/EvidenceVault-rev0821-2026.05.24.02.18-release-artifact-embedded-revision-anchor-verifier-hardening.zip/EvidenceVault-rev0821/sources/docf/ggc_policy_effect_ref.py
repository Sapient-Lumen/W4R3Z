#!/usr/bin/env python3
"""ggc_policy_effect_ref.py

Generate a small LaTeX table that makes GGC policy-setting concrete:
how different caps on the invisible micro-retry factor m_max translate into
soundness-bit loss under conservative scaling (Lemma grinding-gap).

Usage:
  python3 ggc_policy_effect_ref.py --emit

Writes:
  _insert_ggc_policy_effect_table.tex
  test_vectors/ggc_policy_effect_demo.json
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List


def emit_table(baseline_bits: float, ms: List[int]) -> Dict[str, Any]:
    rows = []
    for m in ms:
        bits_lost = math.log2(m)
        remaining = max(0.0, baseline_bits - bits_lost)
        rows.append({
            "m_max": m,
            "log2_m": bits_lost,
            "bits_lost": bits_lost,
            "baseline_bits": baseline_bits,
            "remaining_bits": remaining,
            "eps_multiplier": m,
        })
    return {"baseline_bits": baseline_bits, "rows": rows}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit", action="store_true")
    ap.add_argument("--baseline-bits", type=float, default=80.0)
    args = ap.parse_args()
    if not args.emit:
        ap.print_help()
        return 2

    ms = [1, 2, 5, 10, 25, 50, 100, 1000]
    obj = emit_table(args.baseline_bits, ms)

    os.makedirs("test_vectors", exist_ok=True)
    with open(os.path.join("test_vectors", "ggc_policy_effect_demo.json"), "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, sort_keys=True)
        f.write("\n")

    # LaTeX insert (note: row terminators are literal \\ in output)
    lines = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append("\\begin{tabular}{r r r r}")
    lines.append("\\toprule")
    lines.append("$m_{\\max}$ & $\\log_2 m_{\\max}$ & bits lost & remaining bits (from $%.0f$) \\\\ \\midrule" % args.baseline_bits)
    for r in obj["rows"]:
        lines.append(f"{r['m_max']} & {r['log2_m']:.3f} & {r['bits_lost']:.3f} & {r['remaining_bits']:.3f} \\\\")
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\caption{Policy impact of bounding invisible micro-retries. Under the conservative scaling of Lemma~\\ref{lem:grinding-gap}, a Grinding-Gap Certificate with cap $m_{\\max}$ prevents unbounded silent amplification but still degrades an advertised $\\lambda$-bit claim by $\\log_2 m_{\\max}$ bits. This table reports the resulting loss and the remaining bits for a representative baseline of $\\lambda=%.0f$.}" % args.baseline_bits)
    lines.append("\\label{tab:ggc-policy-effect}")
    lines.append("\\end{table}")
    out_tex = "\n".join(lines) + "\n"
    with open("_insert_ggc_policy_effect_table.tex", "w", encoding="utf-8") as f:
        f.write(out_tex)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
