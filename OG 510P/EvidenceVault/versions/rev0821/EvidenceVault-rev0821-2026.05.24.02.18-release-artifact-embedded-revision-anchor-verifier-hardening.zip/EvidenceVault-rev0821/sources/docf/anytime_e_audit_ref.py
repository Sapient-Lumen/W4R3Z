#!/usr/bin/env python3
"""
anytime_e_audit_ref.py

Reference implementation: produce an anytime-valid performance envelope certificate
based on e-values (e-processes / test martingales).

Target use-case in dOCF:
- certify latency / deadline SLOs under OPTIONAL STOPPING:
  audits can stop early (too slow / fast enough / budget exhausted) without
  invalidating the statistical guarantee.

This reference tool focuses on a simple but robust primitive:
- Convert a latency stream into exceedance indicators X_i = 1[latency_i > τ].
- Test the null hypothesis H0: E[X_i | past] <= p0 (exceedance-rate budget).
- Maintain an e-process E_t = Π (1 + λ_t (X_t - p0)),
  with predictable λ_t in [0, 1/p0) ensuring nonnegativity.
- By Ville's inequality, under H0, P(sup_t E_t >= 1/α) <= α.

This is a "betting-style" e-process that only assumes a conditional mean bound.

Inputs:
A JSON file with:
  {
    "sid": "...",
    "metric": "latency_ms",
    "threshold_ms": 1200,
    "p0": 0.01,
    "latencies_ms": [ ... ]
  }

Outputs:
A `docf_perf_envelope_v0` certificate:
  {
    "type": "perf_envelope",
    "sid": "...",
    "metric": "...",
    "e_value": ...,
    "window": { "n": T, "threshold_ms": ..., "p0": ... },
    "method": { ... },
    "sig": "UNSIGNED-REF",
    "meta": { ... }
  }

Usage:
  - Compute: ./anytime_e_audit_ref.py --in perf_stream.json
  - Write cert: ./anytime_e_audit_ref.py --in perf_stream.json --out cert.json
  - Verify: ./anytime_e_audit_ref.py --verify --in perf_stream.json --cert cert.json
  - Emit demo: ./anytime_e_audit_ref.py --emit-stream   (stream)
              ./anytime_e_audit_ref.py --emit          (certificate)

"""
from __future__ import annotations
import argparse
import json
from typing import Any, Dict, List, Optional


def _clip(x: float, lo: float, hi: float) -> float:
    return lo if x < lo else hi if x > hi else x


def compute_e_process_exceedance(
    xs: List[int],
    p0: float,
    *,
    prior_strength: float = 0.5,
    eps: float = 1e-9,
) -> Dict[str, Any]:
    """
    xs: list of 0/1 exceedance indicators.
    p0: exceedance-rate budget under H0 (mean <= p0).

    Returns dict with e_value, history (optional), and auxiliary stats.
    """
    if not (0.0 < p0 < 1.0):
        raise ValueError("p0 must be in (0,1)")
    E = 1.0
    s = 0.0
    history: List[Dict[str, Any]] = []

    for t, x in enumerate(xs, start=1):
        if x not in (0, 1):
            raise ValueError("xs must be 0/1")
        # smoothed past mean (Jeffreys-style prior)
        p_hat = (s + prior_strength) / (t - 1 + 2 * prior_strength) if t > 1 else p0
        # plug-in bet fraction mapped to λ; clipped to preserve nonnegativity
        denom = max(p0 * (1.0 - p0), eps)
        lam = (p_hat - p0) / denom
        lam = _clip(lam, 0.0, (1.0 / p0) - 1e-6)

        factor = 1.0 + lam * (x - p0)
        # numerical guard
        if factor <= 0.0:
            factor = eps

        E *= factor
        s += float(x)

        history.append({"t": t, "x": x, "p_hat": p_hat, "lambda": lam, "factor": factor, "E": E})

    return {
        "e_value": E,
        "n": len(xs),
        "sum_x": int(s),
        "history": history,
    }


def demo_stream() -> Dict[str, Any]:
    # deterministic demo: mostly under threshold, then a burst of exceedances
    sid = "demo-sid-001"
    lat = [900, 980, 1010, 870, 920, 890, 860, 880, 910, 905,
           950, 970, 930, 940, 960, 1500, 1700, 1400, 1600, 1550]
    return {
        "sid": sid,
        "metric": "latency_ms",
        "threshold_ms": 1200,
        "p0": 0.05,
        "latencies_ms": lat,
        "note": "deterministic demo latency stream",
    }


def make_cert(stream: Dict[str, Any], *, include_history: bool = False) -> Dict[str, Any]:
    sid = stream["sid"]
    metric = stream.get("metric", "latency_ms")
    thr = float(stream["threshold_ms"])
    p0 = float(stream["p0"])
    lats = stream["latencies_ms"]

    xs = [1 if float(x) > thr else 0 for x in lats]
    res = compute_e_process_exceedance(xs, p0)

    cert: Dict[str, Any] = {
        "type": "perf_envelope",
        "sid": sid,
        "metric": metric,
        "e_value": float(res["e_value"]),
        "window": {
            "n": int(res["n"]),
            "threshold_ms": thr,
            "p0": p0,
        },
        "method": {
            "kind": "betting-e-process",
            "update": "E_t *= (1 + λ_t (X_t - p0))",
            "lambda_rule": "plug-in clipped, Jeffreys smoothing",
        },
        "sig": "UNSIGNED-REF",
        "meta": {
            "tool": "anytime_e_audit_ref.py",
            "sum_exceed": int(res["sum_x"]),
            "note": stream.get("note", ""),
        },
    }
    if include_history:
        cert["meta"]["history"] = res["history"]
    return cert


def verify(stream: Dict[str, Any], cert: Dict[str, Any]) -> bool:
    recomputed = make_cert(stream, include_history=False)
    # allow small numeric tolerance
    return abs(float(recomputed["e_value"]) - float(cert["e_value"])) <= 1e-6


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", help="Input JSON stream (latencies_ms + threshold_ms + p0)")
    ap.add_argument("--out", dest="out", help="Write certificate JSON here (else stdout)")
    ap.add_argument("--cert", dest="cert", help="Certificate to verify (used with --verify)")
    ap.add_argument("--verify", action="store_true")
    ap.add_argument("--include-history", action="store_true", help="Attach per-step e-process history to meta")
    ap.add_argument("--emit", action="store_true", help="Emit deterministic demo certificate")
    ap.add_argument("--emit-stream", action="store_true", help="Emit deterministic demo stream")
    args = ap.parse_args()

    if args.emit_stream:
        print(json.dumps(demo_stream(), indent=2))
        return

    if args.emit:
        cert = make_cert(demo_stream(), include_history=args.include_history)
        print(json.dumps(cert, indent=2))
        return

    if not args.inp:
        ap.print_help()
        return

    with open(args.inp, "r", encoding="utf-8") as f:
        stream = json.load(f)

    if args.verify:
        if not args.cert:
            raise SystemExit("--verify requires --cert")
        with open(args.cert, "r", encoding="utf-8") as f:
            cert = json.load(f)
        ok = verify(stream, cert)
        print(json.dumps({"ok": ok}, indent=2))
        raise SystemExit(0 if ok else 2)

    cert = make_cert(stream, include_history=args.include_history)
    out = json.dumps(cert, indent=2)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(out + "\n")
    else:
        print(out)


if __name__ == "__main__":
    main()
