#!/usr/bin/env python3
"""dispute_bond_schedule_ref.py

Reference tool: derive a toy dispute-window and bond schedule for an optimistic
prover-market epoch from posted shadow prices (dual multipliers) and realized totals.

This implements the heuristic described in Section~\ref{sec:optimistic-market-round}:
  V_risk := lambda * eps_tot + nu * beta_tot + sum_g mu_g * E_g
  B_coord := kappa * (fee_tot + V_risk)
  B_chal_base := max(B_min, spam_frac * (fee_tot + V_risk))

It also emits a per-round challenger-bond multiplier schedule (k_by_round) that
grows geometrically to make prolonged interactive disputes increasingly expensive.

Input JSON (either file via --in or stdin) expects a "selection receipt"-like object:
{
  "type": "multiresource_selection_receipt",
  "epoch": 12,
  "fee_tot": 1.0,
  "multipliers": {"lambda": 0.35, "nu": 0.10, "mu": {"gpu_seconds": 0.001}},
  "totals": {"eps_tot": "2^-72.0", "beta_tot": 0.40, "E_g": {"gpu_seconds": 320}}
}

Output is a docf-dispute-bond-schedule-v0 compatible object (additionalProperties allowed):
{
  "type": "dispute_bond_schedule",
  "schedule_id": "...",
  "k_by_round": [[1,1.0],[2,1.5],...],
  "window_seconds": ...,
  "bond_coord": ...,
  "bond_chal_base": ...,
  "V_risk": ...
}

All amounts are in the same abstract units as fee_tot and multipliers.

This is a *toy* generator: deployments should replace the window/bond heuristics
with a governance-approved policy, but can still use the same fields and receipts.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from typing import Any, Dict, List, Tuple


def jcs_bytes(x: Any) -> bytes:
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def sha256_hex(x: Any) -> str:
    return hashlib.sha256(jcs_bytes(x)).hexdigest()


def parse_num(x: Any, name: str) -> float:
    if x is None:
        return 0.0
    if isinstance(x, (int, float)):
        return float(x)
    if isinstance(x, str):
        s = x.strip()
        if s.startswith("2^-"):
            return 2.0 ** (-float(s[3:]))
        return float(s)
    raise TypeError(f"{name} must be numeric")


def derive_schedule(sel: Dict[str, Any], *, kappa: float, B_min: float, spam_frac: float, rounds: int, growth: float, W_min_s: int, W_scale_s: int) -> Dict[str, Any]:
    multipliers = sel.get("multipliers", {}) if isinstance(sel.get("multipliers", {}), dict) else {}
    totals = sel.get("totals", {}) if isinstance(sel.get("totals", {}), dict) else {}

    lam = parse_num(multipliers.get("lambda", 0.0), "lambda")
    nu = parse_num(multipliers.get("nu", 0.0), "nu")
    mu = multipliers.get("mu", {}) if isinstance(multipliers.get("mu", {}), dict) else {}

    eps_tot = parse_num(totals.get("eps_tot", 0.0), "eps_tot")
    beta_tot = parse_num(totals.get("beta_tot", 0.0), "beta_tot")
    E_g = totals.get("E_g", {}) if isinstance(totals.get("E_g", {}), dict) else {}

    fee_tot = parse_num(sel.get("fee_tot", 0.0), "fee_tot")

    mu_term = 0.0
    mu_terms: Dict[str, float] = {}
    for g, mg in mu.items():
        if g in E_g:
            term = parse_num(mg, f"mu[{g}]") * parse_num(E_g[g], f"E_g[{g}]")
            mu_terms[g] = term
            mu_term += term

    V_risk = lam * eps_tot + nu * beta_tot + mu_term
    baseline = fee_tot + V_risk

    B_coord = kappa * baseline
    B_chal_base = max(B_min, spam_frac * baseline)

    # Dispute window: scale mildly with baseline (logarithmic) so that "high exposure" epochs get longer scrutiny.
    # This is a policy knob; we keep it simple and deterministic.
    window = int(W_min_s + W_scale_s * max(0.0, math.log(1.0 + baseline, 2)))

    # Challenger bond multipliers per round.
    k_by_round: List[List[Any]] = []
    k = 1.0
    for r in range(1, rounds + 1):
        k_by_round.append([r, round(k, 6)])
        k *= growth

    schedule_id = "schedule:" + sha256_hex({
        "epoch": sel.get("epoch"),
        "baseline": baseline,
        "kappa": kappa,
        "rounds": rounds,
        "growth": growth,
    })[:16]

    out: Dict[str, Any] = {
        "type": "dispute_bond_schedule",
        "schedule_id": schedule_id,
        "k_by_round": k_by_round,
        "epoch": sel.get("epoch"),
        "derived_from": {"selection_receipt_digest": "sha256:" + sha256_hex(sel)},
        "window_seconds": window,
        "fee_tot": fee_tot,
        "multipliers": {"lambda": lam, "nu": nu, "mu": mu},
        "totals": {"eps_tot": totals.get("eps_tot", eps_tot), "beta_tot": beta_tot, "E_g": E_g},
        "V_risk": V_risk,
        "V_risk_terms": {"lambda_eps": lam * eps_tot, "nu_beta": nu * beta_tot, "mu_resources": mu_terms},
        "baseline": baseline,
        "bond_coord": B_coord,
        "bond_chal_base": B_chal_base,
        "policy_params": {"kappa": kappa, "B_min": B_min, "spam_frac": spam_frac, "rounds": rounds, "growth": growth, "W_min_s": W_min_s, "W_scale_s": W_scale_s},
        "meta": {"tool": "dispute_bond_schedule_ref.py"},
    }
    out["digest"] = "sha256:" + sha256_hex({k: v for k, v in out.items() if k != "digest"})
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="infile", default=None, help="Input selection receipt JSON (default: stdin).")
    ap.add_argument("--out", dest="outfile", default="-", help="Output file (default: stdout).")
    ap.add_argument("--kappa", type=float, default=1.25, help="Coordinator bond safety factor (>1).")
    ap.add_argument("--b-min", type=float, default=0.01, help="Minimum challenger bond.")
    ap.add_argument("--spam-frac", type=float, default=0.05, help="Challenger bond as fraction of baseline exposure.")
    ap.add_argument("--rounds", type=int, default=4, help="Number of dispute rounds.")
    ap.add_argument("--growth", type=float, default=1.5, help="Geometric growth factor for challenger bond per round.")
    ap.add_argument("--w-min", type=int, default=1800, help="Minimum dispute window in seconds.")
    ap.add_argument("--w-scale", type=int, default=600, help="Additional seconds per log2(1+baseline).")
    args = ap.parse_args()

    raw = sys.stdin.read() if args.infile is None else open(args.infile, "r", encoding="utf-8").read()
    sel = json.loads(raw)
    out_obj = derive_schedule(
        sel,
        kappa=args.kappa,
        B_min=args.b_min,
        spam_frac=args.spam_frac,
        rounds=args.rounds,
        growth=args.growth,
        W_min_s=args.w_min,
        W_scale_s=args.w_scale,
    )

    s = json.dumps(out_obj, indent=2, sort_keys=False) + "\n"
    if args.outfile == "-" or args.outfile == "":
        sys.stdout.write(s)
    else:
        with open(args.outfile, "w", encoding="utf-8") as f:
            f.write(s)


if __name__ == "__main__":
    main()
