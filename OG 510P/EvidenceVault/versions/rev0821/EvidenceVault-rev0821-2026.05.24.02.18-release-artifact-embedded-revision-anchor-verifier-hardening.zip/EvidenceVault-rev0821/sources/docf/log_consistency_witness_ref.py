#!/usr/bin/env python3
"""log_consistency_witness_ref.py

Reference verifier for `docf-log-consistency-witness-v0`.

Implements RFC 9162 Section 2.1.4.2 (verify consistency between two tree heads),
and verifies the log's Ed25519 signatures over the STH payload (JCS).

This is reference-grade code for paper examples; it is not hardened.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
from typing import Any, Dict, List

from docf_ref_tools_common import jcs, emit_json, load_json

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature


def b64d(s: str) -> bytes:
    return base64.b64decode(s.encode("utf-8"))


def ct_node_hash(left: bytes, right: bytes) -> bytes:
    return hashlib.sha256(b"\x01" + left + right).digest()


def is_power_of_two(x: int) -> bool:
    return x > 0 and (x & (x - 1)) == 0


def verify_sth_signature(checkpoint: Dict[str, Any]) -> bool:
    msg_obj = {
        "format": checkpoint["format"],
        "log_id": checkpoint.get("log_id", ""),
        "tree_size": checkpoint["tree_size"],
        "root_hash_sha256_b64": checkpoint["root_hash_sha256_b64"],
        "issued_at": checkpoint["issued_at"],
    }
    msg_bytes = jcs(msg_obj)
    pub_raw = b64d(checkpoint["log_public_key_ed25519_raw_b64"])
    sig = b64d(checkpoint["log_signature_ed25519_b64"])
    pub = Ed25519PublicKey.from_public_bytes(pub_raw)
    try:
        pub.verify(sig, msg_bytes)
        return True
    except InvalidSignature:
        return False


def verify_consistency(first: int, first_hash: bytes, second: int, second_hash: bytes, path: List[bytes]) -> bool:
    # Mirrors RFC 9162 Section 2.1.4.2.
    if first <= 0 or first >= second:
        return False
    if len(path) == 0:
        return False

    cpath = list(path)
    if is_power_of_two(first):
        cpath = [first_hash] + cpath

    fn = first - 1
    sn = second - 1

    while fn & 1:
        fn >>= 1
        sn >>= 1

    fr = cpath[0]
    sr = cpath[0]

    for c in cpath[1:]:
        if sn == 0:
            return False

        if (fn & 1) or (fn == sn):
            fr = ct_node_hash(c, fr)
            sr = ct_node_hash(c, sr)
            if not (fn & 1):
                while True:
                    fn >>= 1
                    sn >>= 1
                    if (fn & 1) or (fn == 0):
                        break
        else:
            sr = ct_node_hash(sr, c)

        fn >>= 1
        sn >>= 1

    return (sn == 0) and (fr == first_hash) and (sr == second_hash)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("witness_json", help="Path to log_consistency_witness_demo.json (or compatible)")
    args = ap.parse_args()

    w = load_json(args.witness_json)
    c1 = w["first_checkpoint"]
    c2 = w["second_checkpoint"]

    ok_sig_1 = verify_sth_signature(c1)
    ok_sig_2 = verify_sth_signature(c2)

    first = int(c1["tree_size"])
    second = int(c2["tree_size"])
    first_hash = b64d(c1["root_hash_sha256_b64"])
    second_hash = b64d(c2["root_hash_sha256_b64"])
    path = [b64d(x) for x in w["consistency_path_sha256_b64"]]

    ok_cons = verify_consistency(first, first_hash, second, second_hash, path)

    out = {
        "ok_signature_first": ok_sig_1,
        "ok_signature_second": ok_sig_2,
        "ok_consistency": ok_cons,
        "first": first,
        "second": second,
        "path_len": len(path),
    }
    emit_json(out)


if __name__ == "__main__":
    main()
