package docf.policy

# Example: accept a proof if it meets minimum security and evidence requirements.
# Input is a dOCF auditor output (audit_out.json) plus an observed manifest.

default allow := false

min_bits := 80

allow {
  input.eps_resolved > 0
  bits := -log(input.eps_resolved) / log(2)
  bits >= min_bits

  # Evidence: require witnessed transparency log or on-chain slashing receipts.
  some k
  k := input.grades.attempt_evidence.kind
  k == "witnessed_transparency_log" or k == "economic_stake"

  # Require Attempt DAG commitment present (auditable multi-stage retries).
  input.grades.attempt_transparency.has_attempt_dag_commitment == true

  # Require transcript ABI conformance (digest + suite).
  input.grades.abi.has_transcript_abi_digest == true
  input.grades.abi.has_conformance_suite_digest == true
}
