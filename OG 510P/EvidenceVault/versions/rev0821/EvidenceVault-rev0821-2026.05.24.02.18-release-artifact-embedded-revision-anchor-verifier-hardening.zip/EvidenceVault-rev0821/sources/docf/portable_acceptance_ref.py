#!/usr/bin/env python3
"""portable_acceptance_ref.py

Reference sketch: emit a Portable Acceptance Object (PAO) demo vector.

A PAO is the acceptance-side companion to a PABOM: it packages
  - the accept token (dACP),
  - the PABOM cache key (Section: PABOM portability contract),
  - an anchor checkpoint / marker (and, optionally, a witnessed checkpoint bundle),
into a single replayable object suitable for cross-organization caching.

In v85.0 we additionally staple a Grinding-Gap Certificate (GGC) demo artifact to
make cache hits *grinding-robust* for soundness claims (SRPA-G).

Usage:
  python3 portable_acceptance_ref.py --emit-demo

Outputs (written under test_vectors/):
  - portable_acceptance_object_demo.json
  - portable_acceptance_scitt_statement_demo.json
  - portable_acceptance_receipt_demo.json

This file is intentionally a toy reference. It demonstrates
canonicalization, digest binding, and cache-key packaging.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from typing import Any, Dict

from docf_ref_tools_common import jcs


def sha256_pref(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def load(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit-demo", action="store_true")
    args = ap.parse_args()

    if not args.emit_demo:
        ap.print_help()
        return 0

    os.makedirs("test_vectors", exist_ok=True)

    accept_token = load("test_vectors/accept_token_demo.json")
    pabom_cache = load("test_vectors/pabom_cachekey_demo.json")
    wcb = load("test_vectors/witnessed_checkpoint_bundle_demo.json")
    ggc = load("test_vectors/grinding_gap_certificate_demo.json")

    wcb_digest = sha256_pref(jcs(wcb))
    # GGC digest convention: commit to the object with its 'digest', 'sig', and auxiliary evidence fields (e.g., 'transparency') removed.
    ggc_digest = ggc.get("digest") or sha256_pref(jcs({k:v for (k,v) in ggc.items() if k not in ('digest','sig','transparency')}))

    # Extract core identifiers.
    ack = accept_token.get("ack")
    cid = accept_token.get("cid")
    policy_nf = accept_token.get("policy_nf_digest")
    stmt_digest = accept_token.get("stmt_digest")
    bundle_digest = accept_token.get("bundle_digest")

    cache_res = (pabom_cache.get("result") or {})
    pabom_cache_key = cache_res.get("cache_key", "")
    anchor = cache_res.get("anchor", "")
    pabom_stmt_digest = cache_res.get("statement_digest", "")
    resolver_id = cache_res.get("resolver_id", "docf-resolver-ref/v0")
    pabom_policy_nf = cache_res.get("policy_nf_digest", "")

    ggc_digest_recomputed = sha256_pref(jcs({k:v for (k,v) in ggc.items() if k not in ('digest','sig','transparency')}))

    # Binding checks: prevent laundering a low-m_max GGC across unrelated cache contexts.
    binds = ggc.get('binds') or {}
    ggc_binds_ok = (
        (binds.get('policy_nf_digest') in (None, '', policy_nf)) and
        (binds.get('resolver_id') in (None, '', resolver_id)) and
        (binds.get('pabom_statement_digest') in (None, '', pabom_stmt_digest)) and
        (binds.get('anchor_checkpoint_root') in (None, '', anchor))
    )


    cacheability_checks = [
        {"check": "policy_nf_digest_match", "ok": (pabom_policy_nf == policy_nf), "expected": policy_nf, "got": pabom_policy_nf},
        {"check": "has_pabom_cache_key", "ok": bool(pabom_cache_key)},
        {"check": "has_witnessed_checkpoint_bundle", "ok": bool(wcb_digest)},
        {"check": "has_grinding_gap_certificate", "ok": bool(ggc_digest), "m_max": ggc.get("m_max"), "eps_gap": ggc.get("eps_gap", 0.0)},
        {"check": "ggc_binds_cache_context", "ok": bool(ggc_binds_ok), "binds": binds, "expected_anchor": anchor},
        {"check": "ggc_digest_self_consistent", "ok": (ggc_digest == ggc_digest_recomputed), "expected": ggc_digest_recomputed, "got": ggc_digest},
    ]
    cacheable = bool(pabom_cache_key and wcb_digest and ggc_digest and ggc_binds_ok and (pabom_policy_nf == policy_nf))

    accept_token_digest = sha256_pref(jcs(accept_token))

    pao: Dict[str, Any] = {
        "type": "docf.portable_acceptance_object",
        "version": "v0",
        "created_at": "2026-02-26T00:00:00Z",
        "class": "cacheable" if cacheable else "monitorable",
        "cacheability_checks": cacheability_checks,
        "subject": {
            "bundle_digest": bundle_digest,
            "stmt_digest": stmt_digest,
            "manifest_digest": (accept_token.get("pointers") or {}).get("manifest_digest", "sha256:manifest_demo"),
            "abi_digest": "sha256:abi_demo",
            "pabom_statement_digest": pabom_stmt_digest
        },
        "policy_nf_digest": policy_nf,
        "resolver_id": resolver_id,
        "schema_catalog_digest": "sha256:schema_catalog_demo",
        "pabom_cache_key": pabom_cache_key,
        "accept_token": {
            "ack": ack,
            "cid": cid,
            "accept_token_ref": "test_vectors/accept_token_demo.json",
            "accept_token_digest": accept_token_digest
        },
        "anchor": {
            "kind": "scitt",
            "log_id": "scitt-demo",
            "checkpoint_root": anchor,
            "checkpoint_id": (pabom_cache.get("inputs") or {}).get("checkpoint_id", "chk:demo:0001")
        },
        "witnessed_checkpoint_bundle_digest": wcb_digest,
        "witnessed_checkpoint_bundle_ref": "test_vectors/witnessed_checkpoint_bundle_demo.json",
        "grinding_gap_certificate_digest": ggc_digest,
        "grinding_gap_certificate_ref": "test_vectors/grinding_gap_certificate_demo.json",
        "receipts": [
            {"kind": "pabom_receipt", "ref": "test_vectors/pabom_receipt_demo.json"},
            {"kind": "grinding_gap_certificate", "ref": "test_vectors/grinding_gap_certificate_demo.json"},
        ],
        "issuer": {"id": "did:web:auditor.example"}
    }

    # A SCITT-style wrapper for publication.
    scitt_stmt = {
        "media_type": "application/scitt-statement+cose",
        "payload": {
            "statement_type": "docf.portable_acceptance_object",
            "pao_digest": sha256_pref(jcs(pao)),
            "pao_ref": "test_vectors/portable_acceptance_object_demo.json",
            "ack": ack,
            "cid": cid,
            "pabom_cache_key": pabom_cache_key
        },
        "signer": "did:web:auditor.example"
    }

    dS = sha256_pref(jcs(scitt_stmt))
    receipt = {
        "type": "scitt_receipt_demo",
        "log_id": "scitt-demo",
        "checkpoint_root": anchor,
        "checkpoint_id": "chk:demo:0001",
        "leaf": {"statement_sha256": dS},
        "notes": "toy receipt binding the published PAO statement to a checkpoint"
    }

    with open("test_vectors/portable_acceptance_object_demo.json", "w", encoding="utf-8") as f:
        json.dump(pao, f, indent=2, sort_keys=True)
        f.write("\n")

    with open("test_vectors/portable_acceptance_scitt_statement_demo.json", "w", encoding="utf-8") as f:
        json.dump(scitt_stmt, f, indent=2, sort_keys=True)
        f.write("\n")

    with open("test_vectors/portable_acceptance_receipt_demo.json", "w", encoding="utf-8") as f:
        json.dump(receipt, f, indent=2, sort_keys=True)
        f.write("\n")

    print(sha256_pref(jcs(pao)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())