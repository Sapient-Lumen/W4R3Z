#!/usr/bin/env python3
"""pabom_portability_ref.py

Reference sketch: classify whether a PABOM statement is safe to use as
  - a portable monitoring index, and/or
  - an acceptance cache key,
under a fail-closed interpretation.

This tool is intentionally lightweight. It demonstrates deterministic
canonicalization (JCS-style), statement/receipt digest binding, and
versioned cache-key construction.

Usage:
  python3 pabom_portability_ref.py --emit-demo

Outputs (written under test_vectors/):
  - pabom_statement_demo.json
  - pabom_receipt_demo.json
  - pabom_cachekey_demo.json
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from typing import Any, Dict, Tuple

from docf_ref_tools_common import jcs, sha256_hex


def sha256_pref(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def load_json(path: str) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def verify_signature_stub(statement: Dict[str, Any], allowed_publishers: Tuple[str, ...]) -> bool:
    """Toy signature check: in the evolving archive we treat the 'signer' as the identity."""
    signer = statement.get("signer")
    return signer in allowed_publishers


def bind_subject_stub(statement: Dict[str, Any]) -> bool:
    """Toy subject binding check: require the statement names a subject digest and manifest/ABI digests."""
    subj = (statement.get("subject") or [])
    if not subj or not isinstance(subj, list):
        return False
    dig = subj[0].get("digest", {})
    if "sha256" not in dig:
        return False
    pred = ((statement.get("predicate") or {}) if "predicate" in statement else (statement.get("payload") or {}))
    # Accept either in-toto style (predicate) or SCITT payload style (payload).
    # Require at least one of these fields for the demo.
    return ("manifest_digest" in pred) or ("abi_digest" in pred) or ("pabom" in pred) or ("elements" in pred)


def verify_receipt_stub(receipt: Dict[str, Any]) -> bool:
    """Toy receipt check: require a checkpoint_root and leaf.statement_sha256."""
    leaf = receipt.get("leaf", {})
    return bool(receipt.get("checkpoint_root")) and bool(leaf.get("statement_sha256"))


def portability_check(statement: Dict[str, Any], receipt: Dict[str, Any] | None,
                      policy_nf_digest: str, resolver_id: str,
                      allowed_publishers: Tuple[str, ...], expected_log_id: str) -> Dict[str, Any]:
    dS = sha256_pref(jcs(statement))

    if not verify_signature_stub(statement, allowed_publishers):
        return {"class": "index_only", "reason": "signature_unverified", "statement_digest": dS}

    if not bind_subject_stub(statement):
        return {"class": "index_only", "reason": "subject_unbound", "statement_digest": dS}

    if receipt is None:
        return {"class": "index_only", "reason": "no_receipt", "statement_digest": dS}

    if not verify_receipt_stub(receipt):
        return {"class": "monitorable", "reason": "receipt_invalid", "statement_digest": dS}

    if receipt.get("log_id") != expected_log_id:
        return {"class": "monitorable", "reason": "unexpected_log_id", "statement_digest": dS}

    if receipt.get("leaf", {}).get("statement_sha256") != dS:
        return {"class": "monitorable", "reason": "receipt_not_bound_to_statement", "statement_digest": dS}

    anchor = receipt.get("checkpoint_root")
    key_material = ("pabom-cache-v0|" + dS + "|" + policy_nf_digest + "|" + resolver_id + "|" + anchor).encode("utf-8")
    cache_key = sha256_pref(key_material)

    return {
        "class": "cacheable",
        "statement_digest": dS,
        "policy_nf_digest": policy_nf_digest,
        "resolver_id": resolver_id,
        "anchor": anchor,
        "cache_key": cache_key,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--emit-demo", action="store_true")
    args = ap.parse_args()

    if not args.emit_demo:
        ap.print_help()
        return 0

    os.makedirs("test_vectors", exist_ok=True)

    # Demo statement: in-toto-like object kept intentionally small.
    statement = {
        "_type": "https://in-toto.io/Statement/v1",
        "subject": [{
            "name": "docf://session/sid_demo_001#proof_capsule",
            "digest": {"sha256": sha256_hex(b"proof_capsule_demo")}
        }],
        "predicateType": "https://docf.dev/attestation/pabom/v0",
        "predicate": {
            "format": "docf-pabom-v0",
            "manifest_digest": sha256_pref(b"manifest_demo"),
            "abi_digest": sha256_pref(b"abi_demo"),
            "profile": "Gold",
            "determinism_level": "D4",
            "publication_tier": "T2",
        },
        "signer": "did:web:prover.example"
    }

    # Receipt is a toy SCITT/CT-like binding object.
    dS = sha256_pref(jcs(statement))
    receipt = {
        "type": "scitt_receipt_demo",
        "log_id": "scitt-demo",
        "checkpoint_root": sha256_pref(b"checkpoint_root_demo"),
        "checkpoint_id": "chk:demo:0001",
        "leaf": {"statement_sha256": dS},
        "notes": "toy receipt binding a checkpoint to the statement digest"
    }

    # Demo policy/resolver identifiers.
    policy_nf = load_json("test_vectors/policy_normal_form_demo.json")
    policy_nf_digest = sha256_pref(jcs(policy_nf))
    resolver_id = "docf-resolver-ref/v0"

    out = portability_check(statement, receipt, policy_nf_digest, resolver_id,
                            allowed_publishers=("did:web:prover.example",),
                            expected_log_id="scitt-demo")

    with open("test_vectors/pabom_statement_demo.json", "w", encoding="utf-8") as f:
        json.dump(statement, f, indent=2, sort_keys=True)
        f.write("\n")

    with open("test_vectors/pabom_receipt_demo.json", "w", encoding="utf-8") as f:
        json.dump(receipt, f, indent=2, sort_keys=True)
        f.write("\n")

    # Include pointers so the listing is self-explanatory.
    out_wrapped = {
        "tool": "pabom_portability_ref.py",
        "inputs": {
            "statement_ref": "test_vectors/pabom_statement_demo.json",
            "receipt_ref": "test_vectors/pabom_receipt_demo.json",
            "policy_nf_digest": policy_nf_digest,
            "resolver_id": resolver_id,
            "expected_log_id": "scitt-demo",
        },
        "result": out
    }

    with open("test_vectors/pabom_cachekey_demo.json", "w", encoding="utf-8") as f:
        json.dump(out_wrapped, f, indent=2, sort_keys=True)
        f.write("\n")

    print(out.get("cache_key", out.get("class")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
