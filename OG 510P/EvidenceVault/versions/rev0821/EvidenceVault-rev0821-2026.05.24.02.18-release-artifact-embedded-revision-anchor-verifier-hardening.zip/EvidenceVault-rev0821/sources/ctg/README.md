# CTG Evolving Documents (v215)

Contents:
- `paper_pcg.tex` — flagship **"Proof-Carrying Governance for Agentic Tool Use"**
- `paper_conformance.tex` — companion **"Fail-Closed Verifiers ... A Conformance-Testing View"**
- `NOTES.md` — evolving research notes + next steps
- `refs_selected.bib` — bibliography from the upstream CTG archive
- `refs_additions.bib` — small set of web-checked additions used by these papers

New in v215:
- Paired RTT fixtures (accept/reject) + regenerated Merkle manifest (`pcg_manifest_build.py`).
- Stronger semantic verifier (allowlists, confirmations, registry equivocation detection).
- Updated RTT harness/table and added anytime-valid e-values demo artifacts.

- `table_incident_mapping.tex` — maps real incidents to PCG channels/artifacts
- `table_scope_delta_example.tex` — concrete monotone scope-delta example
- `pcg_scope_tools.py` — minimal, dependency-free reference for scope fingerprints + monotone patch checks
- `scope_old.json`, `scope_new.json`, `scope_patch.json` — example scope objects and patch

## Build (latexmk)
```bash
latexmk -pdf paper_pcg.tex
latexmk -pdf paper_conformance.tex
```

These papers use `biblatex` (biber). `latexmk` should invoke `biber` automatically.

## Re-generating closure metrics table
If you have the full CTG archive checkout, you can regenerate `table_closure_metrics.tex` using:
```bash
python ctg_make_table_closure_metrics.py \
  --baseline demo_end_to_end/ctg_safetycase_bundle.json \
  --mutated conformance_suite/policy_drift_across_evidence/demo_end_to_end/ctg_safetycase_bundle.json \
  --authorized conformance_suite/authorized_policy_heterogeneity_partitioned/demo_end_to_end/ctg_safetycase_bundle.json \
  --out table_closure_metrics.tex
```

## Notes
This bundle is self-contained for writing and review: it includes all referenced `table_*.tex` and `fig_*.png` artifacts needed to compile the papers.
