#!/usr/bin/env python3
"""Minimal reference implementation for PCG scope fingerprints and scope-delta patches.

This module is intentionally small and dependency-free so it can be embedded
in verifiers. It implements RFC 8785-style canonical JSON (JCS) for the JSON
subset used by the archive examples, and uses SHA-256 over the canonical
UTF-8 bytes.

NOTE: RFC 8785 has subtle requirements for number formatting. This
implementation is correct for integers and finite decimals that are already
in JSON numeric form; it rejects NaN/Inf and attempts to serialize floats via
Decimal normalization.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Dict, List, Tuple


def _jcs_escape_string(s: str) -> str:
    # json.dumps with ensure_ascii=False handles UTF-8; we want RFC-compliant
    # escaping for control chars and quotes/backslashes.
    return json.dumps(s, ensure_ascii=False, separators=(",", ":"))


def _jcs_number(n: Any) -> str:
    # RFC 8785 requires a deterministic ECMAScript-compatible format.
    if isinstance(n, bool) or n is None:
        raise TypeError("Not a JSON number")

    if isinstance(n, int):
        return str(n)

    # If it's already a Decimal, keep it; if float, convert via repr to preserve value.
    if isinstance(n, Decimal):
        d = n
    elif isinstance(n, float):
        if n != n or n in (float("inf"), float("-inf")):
            raise ValueError("Non-finite numbers are not allowed in JSON/JCS")
        d = Decimal(repr(n))
    else:
        # Try parse numeric strings? treat as Decimal.
        d = Decimal(str(n))

    # Normalize: remove exponent if possible, strip trailing zeros.
    # quantize(1) would change value; instead use normalize, then format.
    d = d.normalize()

    # Decimal.normalize may produce exponent. Use 'f' when exponent is small.
    sign, digits, exp = d.as_tuple()
    if d == 0:
        return "0"

    # If exponent is negative or zero, fixed-point is fine.
    if exp <= 0:
        s = format(d, "f")
    else:
        # Positive exponent: it's an integer.
        s = format(d, "f")

    # Strip trailing zeros after decimal point.
    if "." in s:
        s = s.rstrip("0").rstrip(".")

    # Avoid '-0'
    if s == "-0":
        s = "0"

    return s


def jcs_canonicalize(obj: Any) -> str:
    """Return canonical JSON string (RFC 8785-ish) for supported JSON types."""

    if obj is None:
        return "null"
    if obj is True:
        return "true"
    if obj is False:
        return "false"

    if isinstance(obj, (int, float, Decimal)):
        return _jcs_number(obj)

    if isinstance(obj, str):
        # json.dumps already escapes control chars and quotes properly.
        return _jcs_escape_string(obj)

    if isinstance(obj, list):
        return "[" + ",".join(jcs_canonicalize(x) for x in obj) + "]"

    if isinstance(obj, dict):
        # Keys must be strings in JSON. Sort by Unicode code points.
        items = sorted(obj.items(), key=lambda kv: kv[0])
        parts: List[str] = []
        for k, v in items:
            if not isinstance(k, str):
                raise TypeError("JSON object keys must be strings")
            parts.append(_jcs_escape_string(k) + ":" + jcs_canonicalize(v))
        return "{" + ",".join(parts) + "}"

    raise TypeError(f"Unsupported type for canonical JSON: {type(obj)}")


def sha256_digest_bytes(b: bytes) -> str:
    return "sha256:" + hashlib.sha256(b).hexdigest()


def scope_fingerprint(scope_obj: Dict[str, Any]) -> str:
    canon = jcs_canonicalize(scope_obj).encode("utf-8")
    return sha256_digest_bytes(canon)


@dataclass
class PatchCheckResult:
    ok: bool
    reasons: List[str]


def verify_monotone_patch(old_scope: Dict[str, Any], new_scope: Dict[str, Any], patch: Dict[str, Any]) -> PatchCheckResult:
    """Verify a *monotone-tightening* patch for the subset of fields used in the paper.

    Accepted monotone-tightening changes:
      - sandbox.egress_allowlist: can only shrink (subset)
      - budgets.max_spend_usd: can only decrease
      - monitors: can only add monitors (superset)
    All other keys must remain identical.
    """

    reasons: List[str] = []

    # Fingerprint binding
    old_fp = scope_fingerprint(old_scope)
    new_fp = scope_fingerprint(new_scope)

    if patch.get("from") != old_fp:
        reasons.append("patch.from does not match old scope fingerprint")
    if patch.get("to") != new_fp:
        reasons.append("patch.to does not match new scope fingerprint")

    # Structural checks
    if patch.get("direction") != "tighten":
        reasons.append("patch.direction must be 'tighten'")

    # Enforce allowed changes
    def _get(d: Dict[str, Any], path: Tuple[str, ...], default=None):
        cur: Any = d
        for p in path:
            if not isinstance(cur, dict) or p not in cur:
                return default
            cur = cur[p]
        return cur

    old_allow = set(_get(old_scope, ("sandbox", "egress_allowlist"), []))
    new_allow = set(_get(new_scope, ("sandbox", "egress_allowlist"), []))
    if not new_allow.issubset(old_allow):
        reasons.append("egress_allowlist must only shrink under tighten")

    old_spend = _get(old_scope, ("budgets", "max_spend_usd"), None)
    new_spend = _get(new_scope, ("budgets", "max_spend_usd"), None)
    if old_spend is None or new_spend is None:
        reasons.append("missing budgets.max_spend_usd")
    else:
        if new_spend > old_spend:
            reasons.append("max_spend_usd must not increase under tighten")

    old_mon = set(_get(old_scope, ("monitors",), []))
    new_mon = set(_get(new_scope, ("monitors",), []))
    if not old_mon.issubset(new_mon):
        reasons.append("monitors can only be added (new must be superset)")

    # All other keys must be identical after removing allowed-diff fields.
    def _strip_allowed(x: Dict[str, Any]) -> Dict[str, Any]:
        x = json.loads(json.dumps(x))  # deep copy
        # Remove allowed difference fields
        x.get("sandbox", {}).pop("egress_allowlist", None)
        x.get("budgets", {}).pop("max_spend_usd", None)
        x.pop("monitors", None)
        return x

    if _strip_allowed(old_scope) != _strip_allowed(new_scope):
        reasons.append("non-allowed fields changed under tighten patch")

    return PatchCheckResult(ok=(len(reasons) == 0), reasons=reasons)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--old", required=True, help="Old scope JSON file")
    ap.add_argument("--new", required=True, help="New scope JSON file")
    ap.add_argument("--patch-out", required=True, help="Where to write a patch JSON")
    args = ap.parse_args()

    old_scope = json.load(open(args.old, "r", encoding="utf-8"))
    new_scope = json.load(open(args.new, "r", encoding="utf-8"))

    patch = {
        "from": scope_fingerprint(old_scope),
        "to": scope_fingerprint(new_scope),
        "direction": "tighten",
        "changed": ["sandbox.egress_allowlist", "budgets.max_spend_usd", "monitors"],
    }
    json.dump(patch, open(args.patch_out, "w", encoding="utf-8"), indent=2)

    res = verify_monotone_patch(old_scope, new_scope, patch)
    print("old_fingerprint:", patch["from"])
    print("new_fingerprint:", patch["to"])
    print("patch_ok:", res.ok)
    if not res.ok:
        print("reasons:", res.reasons)


if __name__ == "__main__":
    main()
