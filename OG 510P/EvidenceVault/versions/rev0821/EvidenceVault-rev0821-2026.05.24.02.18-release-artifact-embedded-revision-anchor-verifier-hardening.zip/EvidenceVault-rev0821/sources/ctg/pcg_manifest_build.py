#!/usr/bin/env python3
"""pcg_manifest_build.py — deterministic builder for traces/manifest.json.

Design goals:
  - Dependency-free, paper-facing.
  - Stable ordering of trace files.
  - Emits Merkle root + per-trace inclusion proofs (duplicate-last tree).

v3 note:
  The Merkle tree commits to *leaf data* (not just the trace digest):
    canonical_json({file,digest,scope_fingerprint,tool_registry_snapshot,expected_gate})
This lets a single manifest cover multiple scopes/tool snapshots while remaining
fail-closed: any change to bindings changes the Merkle root.
"""
from __future__ import annotations

import json
import os
from typing import Any, Dict, List

import pcg_trace_tools as rtt


def main() -> int:
    here = os.path.dirname(__file__)
    traces_dir = os.path.join(here, "traces")
    out_path = os.path.join(traces_dir, "manifest.json")

    files = sorted([f for f in os.listdir(traces_dir) if f.endswith(".jsonl")])

    entries: List[Dict[str, Any]] = []
    leaf_datas: List[bytes] = []

    for f in files:
        fpath = os.path.join(traces_dir, f)
        rows = rtt.read_trace_jsonl(fpath)
        meta = rows[0].get("meta", {})
        d = rtt.digest_file_bytes(fpath)
        e = {
            "file": f,
            "digest": d,
            "expected_gate": meta.get("expected_gate"),
            "scope_fingerprint": meta.get("scope_fingerprint"),
            "tool_registry_snapshot": meta.get("tool_registry_snapshot"),
        }
        entries.append(e)

        leaf_obj = {
            "digest": e["digest"],
            "expected_gate": e.get("expected_gate"),
            "file": e["file"],
            "scope_fingerprint": e.get("scope_fingerprint"),
            "tool_registry_snapshot": e.get("tool_registry_snapshot"),
        }
        leaf_datas.append(rtt.canonical_json(leaf_obj).encode("utf-8"))

    root_hex, leaf_hashes = rtt.merkle_root_duplicate_last(leaf_datas)

    for i, e in enumerate(entries):
        e["leaf_index"] = i
        e["merkle_proof"] = rtt.merkle_proof_duplicate_last(leaf_hashes, i)

    manifest = {
        "version": "v3",
        "leaf_data_schema": "canonical_json({file,digest,scope_fingerprint,tool_registry_snapshot,expected_gate})",
        "merkle_root": {
            "algo": "sha256(0x00/0x01; duplicate-last)",
            "root": root_hex,
        },
        "traces": entries,
    }

    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)
        f.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
