"""pcg_trace_tools.py — reference utilities for Replayable Trace Templates (RTTs).

This module is intentionally dependency-free. It supports:
  - Deterministic JSON hashing (for small metadata objects).
  - File digests for JSONL trace files (commitment to exact bytes).
  - A compact Merkle commitment over trace digests (duplicate-last tree).
  - A semantic verifier that enforces *fail-closed* invariants (e.g., no tool
    invocation before trust is established), suitable for conformance testing.

Design note:
  - Production systems should use standardized canonicalization (RFC 8785 JCS)
    for JSON payloads and signed envelopes (e.g., DSSE + Rekor/inclusion proofs).
  - Here we keep the implementation small so it can be embedded in verifiers and
    used as a reproducible artifact alongside the paper.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import posixpath
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Tuple

import pcg_scope_tools as pcg_scope

# ---------------------------
# Basic canonicalization/hash
# ---------------------------

def canonical_json(obj: Any) -> str:
    """Deterministic JSON serialization (sorted keys, compact separators)."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def hash_json(obj: Any) -> str:
    return "sha256:" + sha256_hex(canonical_json(obj).encode("utf-8"))


# ---------------------------
# Trace file digests (JSONL)
# ---------------------------

def digest_file_bytes(path: str) -> str:
    """Digest the *exact* file bytes."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return "sha256:" + h.hexdigest()


def read_trace_jsonl(path: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            out.append(json.loads(line))
    return out


# ---------------------------
# Merkle commitment (simple)
# ---------------------------

def _ct_leaf_hash(data: bytes) -> bytes:
    return hashlib.sha256(b"\x00" + data).digest()


def _ct_node_hash(left: bytes, right: bytes) -> bytes:
    return hashlib.sha256(b"\x01" + left + right).digest()


def merkle_root_duplicate_last(leaf_datas: List[bytes]) -> Tuple[str, List[bytes]]:
    """Return (root_hex, leaf_hashes) for the duplicate-last Merkle tree."""
    leaves = [_ct_leaf_hash(d) for d in leaf_datas]
    if not leaves:
        return hashlib.sha256(b"").hexdigest(), []
    level = leaves[:]
    while len(level) > 1:
        nxt: List[bytes] = []
        for i in range(0, len(level), 2):
            left = level[i]
            right = level[i + 1] if i + 1 < len(level) else level[i]
            nxt.append(_ct_node_hash(left, right))
        level = nxt
    return level[0].hex(), leaves


def merkle_proof_duplicate_last(leaf_hashes: List[bytes], index: int) -> List[Dict[str, str]]:
    """Inclusion proof for duplicate-last Merkle tree."""
    proof: List[Dict[str, str]] = []
    idx = index
    level = leaf_hashes[:]
    while len(level) > 1:
        if idx % 2 == 0:
            sib_idx = idx + 1 if idx + 1 < len(level) else idx
            proof.append({"side": "right", "hash": level[sib_idx].hex()})
        else:
            proof.append({"side": "left", "hash": level[idx - 1].hex()})

        # next level
        nxt: List[bytes] = []
        for i in range(0, len(level), 2):
            left = level[i]
            right = level[i + 1] if i + 1 < len(level) else level[i]
            nxt.append(_ct_node_hash(left, right))
        level = nxt
        idx //= 2
    return proof


def merkle_verify_duplicate_last(leaf_data: bytes, proof: List[Dict[str, str]], root_hex: str) -> bool:
    cur = _ct_leaf_hash(leaf_data)
    for step in proof:
        sib = bytes.fromhex(step["hash"])
        if step["side"] == "right":
            cur = _ct_node_hash(cur, sib)
        else:
            cur = _ct_node_hash(sib, cur)
    return cur.hex() == root_hex


# ---------------------------
# Manifest structures
# ---------------------------

@dataclass(frozen=True)
class ManifestTrace:
    file: str
    digest: str
    expected_gate: str
    scope_fingerprint: str
    tool_registry_snapshot: str
    leaf_index: int
    merkle_proof: List[Dict[str, str]]


@dataclass(frozen=True)
class RTTManifest:
    version: str
    leaf_data_schema: str
    merkle_root_hex: str
    traces: List[ManifestTrace]


def load_manifest(path: str) -> RTTManifest:
    obj = json.load(open(path, "r", encoding="utf-8"))
    mr = obj.get("merkle_root", {})
    traces: List[ManifestTrace] = []
    for i, t in enumerate(obj.get("traces", [])):
        traces.append(
            ManifestTrace(
                file=str(t["file"]),
                digest=str(t["digest"]),
                expected_gate=str(t.get("expected_gate", "")),
                scope_fingerprint=str(t.get("scope_fingerprint", "")),
                tool_registry_snapshot=str(t.get("tool_registry_snapshot", "")),
                leaf_index=int(t.get("leaf_index", i)),
                merkle_proof=list(t.get("merkle_proof", [])),
            )
        )
    return RTTManifest(
        version=str(obj.get("version", "")),
        leaf_data_schema=str(obj.get("leaf_data_schema", "")),
        merkle_root_hex=str(mr.get("root", "")),
        traces=traces,
    )


def verify_manifest(manifest_path: str, traces_dir: str) -> Tuple[bool, List[str]]:
    """Verify that manifest digests match files and inclusion proofs verify.

    For v3 manifests, the Merkle tree commits to *leaf data*:
      canonical_json({file,digest,scope_fingerprint,tool_registry_snapshot,expected_gate}).
    """
    reasons: List[str] = []
    m = load_manifest(manifest_path)

    leaf_datas: List[bytes] = []
    for t in m.traces:
        fpath = os.path.join(traces_dir, t.file)
        if not os.path.exists(fpath):
            reasons.append(f"missing trace file: {t.file}")
            continue
        d = digest_file_bytes(fpath)
        if d != t.digest:
            reasons.append(f"digest mismatch for {t.file}")

        leaf_obj = {
            "digest": t.digest,
            "expected_gate": t.expected_gate,
            "file": t.file,
            "scope_fingerprint": t.scope_fingerprint,
            "tool_registry_snapshot": t.tool_registry_snapshot,
        }
        leaf_datas.append(canonical_json(leaf_obj).encode("utf-8"))

    root_hex, leaf_hashes = merkle_root_duplicate_last(leaf_datas)
    if root_hex != m.merkle_root_hex:
        reasons.append("merkle root mismatch")

    for idx, t in enumerate(m.traces):
        if idx >= len(leaf_datas):
            continue
        ok = merkle_verify_duplicate_last(leaf_datas[idx], t.merkle_proof, m.merkle_root_hex)
        if not ok:
            reasons.append(f"merkle proof failed for {t.file}")

    return (len(reasons) == 0), reasons


# ---------------------------
# Semantic verifier
# ---------------------------

def semantic_verify_trace(rows: List[Dict[str, Any]], manifest_scope_fp: str, manifest_registry_digest: str) -> Tuple[str, List[str]]:
    """Return (verdict, reasons). Verdict in {accept,reject}.

    The verifier is intentionally small but aims to model *fail-closed* practice:
      - Bind traces to an externally published (scope_fingerprint, registry_snapshot).
      - Enforce a trust gate (no tool calls before explicit trust).
      - Enforce a *declared* tool allowlist (meta.allowed_tools), if present.
      - Enforce user confirmation requirements (meta.require_confirm_for), if present.
      - Enforce path and argument policies (meta.path_policies / meta.no_dash_args), if present.
      - Enforce tool-identity continuity within the trace (registry observations must not equivocate).
      - Enforce call/return pairing, monotone time, and expected-block conditions.
    """
    reasons: List[str] = []
    if not rows or "meta" not in rows[0]:
        return "reject", ["trace missing meta header"]
    meta = rows[0]["meta"]

    # --- Bindings to published artifacts (fail closed) ---
    if meta.get("scope_fingerprint") != manifest_scope_fp:
        reasons.append("scope fingerprint mismatch (trace vs manifest)")
    if meta.get("tool_registry_snapshot") != manifest_registry_digest:
        reasons.append("tool registry snapshot mismatch (trace vs manifest)")

    expected = meta.get("expected_gate")

    # --- Recompute and bind scope fingerprint (if scope object is present). ---
    scope_obj = meta.get("scope")
    if isinstance(scope_obj, dict):
        try:
            recomputed = pcg_scope.scope_fingerprint(scope_obj)
            if meta.get("scope_fingerprint") != recomputed:
                reasons.append("scope fingerprint does not match provided scope object")
        except Exception as e:
            reasons.append(f"failed to recompute scope fingerprint: {type(e).__name__}")

    # Policies are first-class: prefer meta.scope.policies, fall back to legacy fields.
    policies: Dict[str, Any] = {}
    if isinstance(scope_obj, dict):
        p = scope_obj.get("policies")
        if isinstance(p, dict):
            policies.update(p)

    # Legacy compatibility (older fixtures may store policies at meta top-level).
    for k in ["trust_required","allowed_tools","require_confirm_for","memory_policy","path_policies","no_dash_args","symlink_map"]:
        if k not in policies and k in meta:
            policies[k] = meta.get(k)

    trust_required = bool(policies.get("trust_required", True))
    allowed_tools = set(policies.get("allowed_tools") or [])
    require_confirm_for = set(policies.get("require_confirm_for") or [])
    memory_policy = str(policies.get("memory_policy", "default"))  # e.g., "user_only"
    path_policies = list(policies.get("path_policies") or [])
    no_dash_args = list(policies.get("no_dash_args") or [])
    symlink_map = list(policies.get("symlink_map") or [])

    # Optional: secrets-at-rest policy (paper-facing model of secret storage).
    secret_storage = str(policies.get("secret_storage", ""))  # e.g., 'encrypted_required'

    # Optional: tool-output firewall policy (paper-facing model).
    sanitize_tool_outputs = policies.get("sanitize_tool_outputs", None)
    sanitize_required = False
    if isinstance(sanitize_tool_outputs, dict):
        sanitize_required = bool(sanitize_tool_outputs.get("required", False))
    elif sanitize_tool_outputs is True:
        sanitize_required = True

    # Optional: TIC-pinned tool registry entries (tool -> version -> digest).
    tool_registry = None
    if isinstance(scope_obj, dict) and isinstance(scope_obj.get("tool_registry"), dict):
        tool_registry = scope_obj.get("tool_registry")

    def _norm_posix(p: str) -> str:
        # Normalize POSIX-like paths used in RTT fixtures.
        p = str(p)
        if not p.startswith("/"):
            p = "/" + p
        return posixpath.normpath(p)

    def _within_root(root: str, p: str) -> bool:
        r = _norm_posix(root)
        q = _norm_posix(p)
        r_slash = r.rstrip("/") + "/"
        return q == r or q.startswith(r_slash)


    def _resolve_symlinks(p: str) -> str:
        """Resolve a small, declarative symlink map (fixture-only model of realpath).

        symlink_map is a list of {link: <path>, target: <path>} rules.
        If p is under link/, replace the prefix with target/.
        """
        q = _norm_posix(p)
        for rule in symlink_map:
            if not isinstance(rule, dict):
                continue
            link = rule.get("link")
            target = rule.get("target")
            if not link or not target:
                continue
            l = _norm_posix(str(link))
            t = _norm_posix(str(target))
            l_slash = l.rstrip("/") + "/"
            if q == l:
                return t
            if q.startswith(l_slash):
                return posixpath.normpath(t + q[len(l):])
        return q

    # --- Basic temporal sanity ---
    last_t = -1e18
    for i, r in enumerate(rows[1:], start=1):
        if "t" in r:
            t = float(r["t"])
            if t < last_t:
                reasons.append(f"non-monotone time at line {i}")
                break
            last_t = t

    # --- Track confirmations ---
    confirmed_tools: set[str] = set()
    for r in rows[1:]:
        if r.get("type") == "user_confirm" and r.get("ok") is True and r.get("tool"):
            confirmed_tools.add(str(r.get("tool")))

    # Optional: secrets-at-rest observations must satisfy policy.
    if secret_storage == 'encrypted_required':
        for r in rows[1:]:
            if r.get('type') == 'observation' and r.get('channel') == 'secrets_store':
                c = r.get('content') or {}
                if c.get('encrypted') is False:
                    reasons.append('secrets_cleartext')
                    break

    # --- Trust gate + allowlist + confirmation gate ---
    trusted = False
    for r in rows[1:]:
        if r.get("type") == "trust_ack" and r.get("trusted") is True:
            trusted = True

        if r.get("type") == "tool_call":
            tool = str(r.get("tool", ""))

            if trust_required and not trusted:
                reasons.append("tool_call before trusted trust_ack")
                break

            if allowed_tools and tool not in allowed_tools:
                reasons.append(f"tool_call to disallowed tool: {tool}")
                break

            if tool in require_confirm_for and tool not in confirmed_tools:
                reasons.append(f"missing user confirmation for tool: {tool}")
                break


            # --- Argument / path policies (paper-facing models of MCP-server hardening) ---
            args = r.get("args") or {}
            for pol in no_dash_args:
                if str(pol.get("tool")) == tool:
                    for a in pol.get("args") or []:
                        v = str(args.get(a, ""))
                        if v.startswith("-"):
                            reasons.append(f"arg_injection:{a}")
                            break
                    if reasons:
                        break
            if reasons:
                break
            for pol in path_policies:
                if str(pol.get("tool")) == tool:
                    a = str(pol.get("arg", ""))
                    root = str(pol.get("root", ""))
                    if a and root and a in args:
                        if not _within_root(root, _resolve_symlinks(str(args.get(a)))):
                            reasons.append(f"path_escape:{a}")
                            break
            if reasons:
                break

            # Heuristic: if memory writes are restricted, flag suspicious payloads.
            if tool in ("memory.write", "memory.append", "memory.update") and memory_policy == "user_only":
                txt = json.dumps(r.get("args", {}), sort_keys=True)
                suspicious = any(s in txt for s in ["SYSTEM:", "http://", "https://", "curl ", "wget "])
                if suspicious:
                    reasons.append("suspicious memory write under user_only policy")
                    break

    # --- Tool-output firewall (sanitization) ---
    if sanitize_required and not reasons:
        SUSPICIOUS = ["SYSTEM:", "TOOL:", "IGNORE PREVIOUS", "BEGIN PROMPT", "<<<", "curl ", "wget "]
        def _has_suspicious(obj: Any) -> bool:
            try:
                txt = json.dumps(obj, sort_keys=True)
            except Exception:
                txt = str(obj)
            txt_u = txt.upper()
            return any(pat in txt_u for pat in [p.upper() for p in SUSPICIOUS])

        needs_sanitize = False
        for r in rows[1:]:
            t = r.get("type")
            # Tool results and external observations can carry attacker-controlled content.
            if t in ("tool_result", "observation"):
                if _has_suspicious(r.get("result") or r.get("content") or r):
                    needs_sanitize = True
                    continue
            if t == "output_sanitized":
                needs_sanitize = False
                continue
            if needs_sanitize and t in ("tool_call", "model_action", "assistant_message"):
                reasons.append("unsanitized_tool_output")
                break

    # --- Tool call/return pairing + expected-block enforcement ---
    pending: List[Tuple[str, Optional[str]]] = []  # (tool, expected_blocked_by)
    for r in rows[1:]:
        if r.get("type") == "tool_call":
            pending.append((str(r.get("tool")), r.get("expected_blocked_by")))
        if r.get("type") == "tool_result":
            if pending:
                tool, exp = pending.pop(0)
                if exp and r.get("ok") is True:
                    reasons.append(f"expected blocked by {exp} but tool_result ok=True for {tool}")
                    break
    if pending and not reasons:
        reasons.append("unmatched tool_call without tool_result")

    # --- Tool identity continuity inside the trace ---
    # If the trace includes registry observations, they must not equivocate.
    tool_digests: Dict[Tuple[str, str], str] = {}
    for r in rows[1:]:
        if r.get("type") == "observation" and r.get("channel") == "registry":
            c = r.get("content") or {}
            tool = str(c.get("tool", ""))
            ver = str(c.get("version", ""))
            dig = str(c.get("digest", ""))
            if tool and ver and dig:
                key = (tool, ver)

                # Enforce TIC-pinned digest if provided in the scope object.
                if isinstance(tool_registry, dict):
                    exp = tool_registry.get(tool)
                    if isinstance(exp, dict):
                        exp_d = exp.get(ver)
                        if exp_d and str(exp_d) != dig:
                            reasons.append('registry_tic_mismatch')
                            break

                if key in tool_digests and tool_digests[key] != dig:
                    reasons.append(f"registry equivocation for {tool}@{ver}")
                    break
                tool_digests[key] = dig

        # If this is an install call with an integrity pin, enforce it against observed registry digest.
        if r.get("type") == "tool_call" and str(r.get("tool")) == "pkg.install":
            a = r.get("args") or {}
            name = str(a.get("name", ""))
            ver = str(a.get("version", ""))
            integ = str(a.get("integrity", ""))
            key = (name, ver)
            if integ and key in tool_digests and tool_digests[key] and integ != tool_digests[key]:
                reasons.append(f"integrity pin mismatch for {name}@{ver}")
                break

    verdict = "accept" if not reasons else "reject"

    # Optional: if trace specifies expected_gate, treat mismatch as a failure.
    if expected in ("accept", "reject") and verdict != expected:
        reasons.append(f"verdict {verdict} != expected_gate {expected}")
        verdict = "reject"

    return verdict, reasons


# ---------------------------
# CLI
# ---------------------------

def cmd_verify(args: argparse.Namespace) -> int:
    ok, reasons = verify_manifest(args.manifest, args.traces_dir)
    if not ok:
        print("MANIFEST FAIL")
        for r in reasons:
            print(" -", r)
        return 2

    m = load_manifest(args.manifest)
    any_fail = False
    for t in m.traces:
        rows = read_trace_jsonl(os.path.join(args.traces_dir, t.file))
        verdict, rs = semantic_verify_trace(rows, t.scope_fingerprint, t.tool_registry_snapshot)
        expected = t.expected_gate or rows[0].get("meta", {}).get("expected_gate", "")
        okv = (verdict == expected)
        print(f"{t.file}: {verdict} (expected {expected})")
        for r in rs:
            print("   *", r)
        if not okv:
            any_fail = True

    return 1 if any_fail else 0


def main() -> None:

    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    ap_v = sub.add_parser("verify", help="Verify manifest + run semantic checks over traces")
    ap_v.add_argument("--manifest", required=True)
    ap_v.add_argument("--traces-dir", required=True)
    ap_v.set_defaults(func=cmd_verify)

    args = ap.parse_args()
    raise SystemExit(args.func(args))


if __name__ == "__main__":
    main()