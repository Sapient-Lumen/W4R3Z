#!/usr/bin/env python3
"""pcg_rtt_harness.py — paper-facing RTT benchmark + mutation checks.

Deterministic harness (no third-party deps). Emits:
  - table_rtt_detection.tex: baseline accuracy + aggregated mutation robustness
  - table_rtt_index.tex: trace-id -> filename mapping

Mutation robustness is evaluated over accept fixtures. Each mutation is applied
across accept traces; if a mutation makes no change to a given trace, that trace
is treated as N/A for that mutation (excluded from the denominator).
"""

from __future__ import annotations

import copy
import json
import os
from typing import Any, Dict, List, Tuple

import pcg_trace_tools as rtt


def _load_manifest() -> List[Dict[str, Any]]:
    here = os.path.dirname(__file__)
    manifest_path = os.path.join(here, "traces", "manifest.json")
    with open(manifest_path, "r", encoding="utf-8") as f:
        m = json.load(f)
    return m["traces"]


def _read_rows(fname: str) -> List[Dict[str, Any]]:
    here = os.path.dirname(__file__)
    return rtt.read_trace_jsonl(os.path.join(here, "traces", fname))


def _trace_id(rows: List[Dict[str, Any]], fname: str) -> str:
    meta = rows[0].get("meta", {}) if rows else {}
    tid = meta.get("template_id")
    return str(tid) if tid else fname


# -----------------
# Mutations (rows -> rows)
# -----------------

def mutate_remove_trust_ack(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = [copy.deepcopy(r) for r in rows]
    return [r for r in out if r.get("type") != "trust_ack"]


def mutate_corrupt_scope_fp(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = [copy.deepcopy(r) for r in rows]
    out[0]["meta"]["scope_fingerprint"] = "sha256:" + "00" * 32
    return out


def mutate_corrupt_registry_digest(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = [copy.deepcopy(r) for r in rows]
    out[0]["meta"]["tool_registry_snapshot"] = "sha256:" + "11" * 32
    return out


def mutate_add_disallowed_tool(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = [copy.deepcopy(r) for r in rows]
    insert_at = len(out)
    for i, r in enumerate(out):
        if r.get("type") == "tool_result":
            insert_at = i + 1
            break
    out.insert(
        insert_at,
        {"type": "tool_call", "t": 999, "tool": "dxt.shell.exec", "args": {"cmd": "echo pwned"}},
    )
    out.insert(
        insert_at + 1,
        {"type": "tool_result", "t": 1000, "tool": "dxt.shell.exec", "ok": True, "result": {"status": "ok"}},
    )
    return out


def mutate_remove_user_confirm(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = [copy.deepcopy(r) for r in rows]
    return [r for r in out if r.get("type") != "user_confirm"]


def mutate_registry_equivocation(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = [copy.deepcopy(r) for r in rows]
    for i, r in enumerate(out):
        if r.get("type") == "observation" and r.get("channel") == "registry":
            c = copy.deepcopy(r)
            c["t"] = float(c.get("t", 0)) + 0.01
            if isinstance(c.get("content"), dict):
                c["content"]["digest"] = "sha256:EVIL"
            out.insert(i + 1, c)
            break
    return out


def mutate_repo_path_escape(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = [copy.deepcopy(r) for r in rows]
    for r in out:
        if r.get("type") == "tool_call":
            a = r.get("args") or {}
            if isinstance(a, dict) and "repo_path" in a:
                a["repo_path"] = "/repos/proj/../secrets"
                r["args"] = a
                break
    return out


def mutate_git_flag_ref(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = [copy.deepcopy(r) for r in rows]
    for r in out:
        if r.get("type") == "tool_call" and str(r.get("tool")) in ("mcp.git.diff", "mcp.git.checkout"):
            a = r.get("args") or {}
            if isinstance(a, dict):
                a["base"] = "--output=/tmp/pwn"
                r["args"] = a
            break
    return out


def mutate_git_init_path_escape(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = [copy.deepcopy(r) for r in rows]
    for r in out:
        if r.get("type") == "tool_call" and str(r.get("tool")) == "mcp.git.init":
            a = r.get("args") or {}
            if isinstance(a, dict):
                a["path"] = "/tmp/evil_repo"
                r["args"] = a
            break
    return out


def mutate_filesystem_symlink_escape(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = [copy.deepcopy(r) for r in rows]
    for r in out:
        if r.get("type") == "tool_call" and str(r.get("tool")) == "mcp.fs.read":
            a = r.get("args") or {}
            if isinstance(a, dict):
                a["path"] = "/workspace/data/link/passwd"
                r["args"] = a
            break
    return out


def mutate_filesystem_prefix_match(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = [copy.deepcopy(r) for r in rows]
    for r in out:
        if r.get("type") == "tool_call" and str(r.get("tool")) == "mcp.fs.read":
            a = r.get("args") or {}
            if isinstance(a, dict) and "path" in a:
                a["path"] = "/workspace/data_evil/secrets.env"
                r["args"] = a
            break
    return out


def mutate_cleartext_secrets(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = [copy.deepcopy(r) for r in rows]
    for r in out:
        if r.get("type") == "observation" and r.get("channel") == "secrets_store":
            c = r.get("content") or {}
            if isinstance(c, dict):
                c["encrypted"] = False
                r["content"] = c
            break
    return out


def mutate_registry_tic_mismatch(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out = [copy.deepcopy(r) for r in rows]
    for r in out:
        if r.get("type") == "observation" and r.get("channel") == "registry":
            c = r.get("content") or {}
            if isinstance(c, dict):
                c["digest"] = "sha256:OLD_DIGEST"
                r["content"] = c
            break
    return out


def mutate_remove_output_sanitizer(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Remove explicit output_sanitized event (tests tool-output firewall fail-closed behavior)."""
    out = [copy.deepcopy(r) for r in rows]
    out2 = []
    removed = False
    for r in out:
        if not removed and r.get("type") == "output_sanitized":
            removed = True
            continue
        out2.append(r)
    return out2


MUTATIONS = [
    ("Remove trust ack", mutate_remove_trust_ack),
    ("Corrupt scope fp", mutate_corrupt_scope_fp),
    ("Corrupt registry digest", mutate_corrupt_registry_digest),
    ("Add disallowed tool", mutate_add_disallowed_tool),
    ("Remove user confirm", mutate_remove_user_confirm),
    ("Remove output sanitizer", mutate_remove_output_sanitizer),
    ("Inject registry equivocation", mutate_registry_equivocation),
    ("Repo path escape", mutate_repo_path_escape),
    ("Flag-like git ref", mutate_git_flag_ref),
    ("Git init path escape", mutate_git_init_path_escape),
    ("FS symlink escape", mutate_filesystem_symlink_escape),
    ("FS prefix-match escape", mutate_filesystem_prefix_match),
    ("Cleartext secrets-at-rest", mutate_cleartext_secrets),
    ("TIC digest mismatch", mutate_registry_tic_mismatch),
]


def main() -> int:
    traces = _load_manifest()
    bindings = {t["file"]: (t.get("scope_fingerprint", ""), t.get("tool_registry_snapshot", "")) for t in traces}

    # Baseline checks
    baseline_rows: List[Tuple[str, str, str, str, str]] = []  # id, file, expected, verdict, ok?
    n_ok = 0
    for t in traces:
        fname = t["file"]
        rows = _read_rows(fname)
        tid = _trace_id(rows, fname)
        verdict, _ = rtt.semantic_verify_trace(rows, t.get("scope_fingerprint", ""), t.get("tool_registry_snapshot", ""))
        expected = rows[0]["meta"].get("expected_gate", "?")
        ok = "ok" if verdict == expected else "bad"
        if ok == "ok":
            n_ok += 1
        baseline_rows.append((tid, fname, expected, verdict, ok))

    # Mutation robustness (aggregated): accept fixtures only
    accept_files = [f for (_, f, exp, _, _) in baseline_rows if exp == "accept"]
    accept_ids = {f: tid for (tid, f, exp, _, _) in baseline_rows if exp == "accept"}

    mut_rows: List[Tuple[str, int, int, List[str]]] = []  # name, applicable, flipped, failures
    for name, fn in MUTATIONS:
        applicable = 0
        flipped = 0
        failures: List[str] = []
        for fname in accept_files:
            rows = _read_rows(fname)
            mrows = fn(rows)
            if json.dumps(rows, sort_keys=True) == json.dumps(mrows, sort_keys=True):
                continue  # N/A
            applicable += 1
            sfp, rg = bindings.get(fname, ("", ""))
            verdict, _ = rtt.semantic_verify_trace(mrows, sfp, rg)
            if verdict == "reject":
                flipped += 1
            else:
                failures.append(accept_ids.get(fname, fname))
        mut_rows.append((name, applicable, flipped, failures))

    here = os.path.dirname(__file__)

    def esc(s: str) -> str:
        return s.replace("_", "\\_")

    # Emit detection table
    out_path = os.path.join(here, "table_rtt_detection.tex")
    lines: List[str] = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append(
        "\\caption{RTT benchmark: baseline accuracy and mutation robustness. Baseline should match each trace's declared \\texttt{expected\\_gate}. Mutation robustness is aggregated over accept fixtures; each mutation is applied to every accept trace for which it makes a change (N/A traces are excluded). A robust fail-closed verifier should flip applicable mutated traces to reject.}"
    )
    lines.append("\\label{tab:rtt_detection}")
    lines.append("\\vspace{2pt}")
    lines.append("\\begin{tabular}{p{0.34\\linewidth}ccc}")
    lines.append("\\toprule")
    lines.append("Trace ID & Expected & Verifier & Match \\\\")
    lines.append("\\midrule")
    for tid, _, expected, verdict, ok in baseline_rows:
        chk = "\\checkmark" if ok == "ok" else ""
        lines.append(f"\\texttt{{{esc(tid)}}} & {expected} & {verdict} & {chk} \\\\")
    lines.append("\\midrule")
    lines.append(f"\\multicolumn{{4}}{{l}}{{\\emph{{Baseline accuracy: {n_ok}/{len(baseline_rows)} correct}}}} \\\\")
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")

    lines.append("\\vspace{6pt}")
    lines.append("\\begin{tabular}{p{0.25\\linewidth}ccc p{0.36\\linewidth}}")
    lines.append("\\toprule")
    lines.append("Mutation & Applicable & Flipped & Rate & Failures (IDs) \\\\")
    lines.append("\\midrule")
    for name, applicable, flipped, failures in mut_rows:
        rate = 0.0 if applicable == 0 else (flipped / applicable)
        fail_str = ", ".join([f"\\texttt{{{esc(x)}}}" for x in failures]) if failures else "--"
        lines.append(f"{name} & {applicable} & {flipped} & {rate:.2f} & {fail_str} \\\\")
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")

    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    # Emit index table
    idx_path = os.path.join(here, "table_rtt_index.tex")
    lines = []
    lines.append("\\begin{table}[t]")
    lines.append("\\centering")
    lines.append("\\small")
    lines.append("\\caption{RTT index: compact trace identifiers used in tables and text.}")
    lines.append("\\label{tab:rtt_index}")
    lines.append("\\begin{tabular}{p{0.40\\linewidth}p{0.50\\linewidth}}")
    lines.append("\\toprule")
    lines.append("Trace ID & File \\\\")
    lines.append("\\midrule")
    for tid, fname, _, _, _ in baseline_rows:
        lines.append(f"\\texttt{{{esc(tid)}}} & \\texttt{{{esc(fname)}}} \\\\")
    lines.append("\\bottomrule")
    lines.append("\\end{tabular}")
    lines.append("\\end{table}")

    with open(idx_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
