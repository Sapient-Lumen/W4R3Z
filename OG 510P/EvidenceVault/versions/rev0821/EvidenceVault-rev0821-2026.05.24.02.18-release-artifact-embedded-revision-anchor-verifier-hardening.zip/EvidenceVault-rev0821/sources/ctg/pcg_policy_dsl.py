#!/usr/bin/env python3
"""pcg_policy_dsl.py — tiny, deterministic policy DSL compiler for PCG scopes.

Why a DSL at all?
  - Humans author policies; machines must verify them deterministically.
  - JSON is precise but easy to hand-edit incorrectly (ordering/duplication).
  - A small line-oriented DSL makes policy review / diffs legible while still
    compiling into the canonical JSON 'policies' object that is signed and
    fingerprinted in the scope.

Design constraints:
  - Dependency-free.
  - Total ordering of outputs (sorted lists) for stable diffs.
  - Conservative parsing: unknown statements are errors.

The compiler emits a dict compatible with the archive's scope schema:
  {
    'trust_required': bool,
    'allowed_tools': [...],
    'require_confirm_for': [...],
    'path_policies': [{'tool':..,'arg':..,'root':..}, ...],
    'no_dash_args': [{'tool':..,'args':[...]} ...],
    'secret_storage': 'encrypted_required' | 'cleartext_ok' (optional)
  }

This module is intentionally minimal; it is *not* a full policy language.
"""

from __future__ import annotations

import argparse
import hashlib
from dataclasses import dataclass
from typing import Dict, List, Optional

import pcg_scope_tools as scope


@dataclass
class CompileResult:
    ok: bool
    policies: Dict
    errors: List[str]


def _tok(line: str) -> List[str]:
    return [t for t in line.strip().split() if t]


def compile_policy(text: str) -> CompileResult:
    allowed_tools: List[str] = []
    confirm_tools: List[str] = []
    path_policies: List[Dict] = []
    no_dash_args: List[Dict] = []
    trust_required: Optional[bool] = None
    secret_storage: Optional[str] = None
    sanitize_required: Optional[bool] = None
    memory_policy: Optional[str] = None

    errors: List[str] = []

    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue

        t = _tok(line)
        if t[:2] == ['trust', 'required'] and len(t) == 2:
            trust_required = True
            continue
        if t[:2] == ['trust', 'optional'] and len(t) == 2:
            trust_required = False
            continue

        if len(t) == 3 and t[0] == 'allow' and t[1] == 'tool':
            allowed_tools.append(t[2])
            continue

        if len(t) == 3 and t[0] == 'confirm' and t[1] == 'tool':
            confirm_tools.append(t[2])
            continue

        # path <tool> <arg> within <root>
        if len(t) == 5 and t[0] == 'path' and t[3] == 'within':
            path_policies.append({'tool': t[1], 'arg': t[2], 'root': t[4]})
            continue

        # nodash <tool> <arg1> [arg2 ...]
        if len(t) >= 3 and t[0] == 'nodash':
            no_dash_args.append({'tool': t[1], 'args': t[2:]})
            continue

        # secrets atrest encrypted|cleartext_ok
        if len(t) == 3 and t[0] == 'secrets' and t[1] == 'atrest':
            if t[2] == 'encrypted':
                secret_storage = 'encrypted_required'
                continue
            if t[2] == 'cleartext_ok':
                secret_storage = 'cleartext_ok'
                continue

        # sanitize outputs required|optional
        if len(t) == 3 and t[0] == 'sanitize' and t[1] == 'outputs':
            if t[2] == 'required':
                sanitize_required = True
                continue
            if t[2] == 'optional':
                sanitize_required = False
                continue

        # memory default|user_only
        if len(t) == 2 and t[0] == 'memory':
            if t[1] in ('default','user_only'):
                memory_policy = t[1]
                continue

        errors.append(f"Unrecognized statement: {raw}")

    if trust_required is None:
        errors.append('Missing required statement: trust required|optional')

    # Canonicalize (stable ordering)
    allowed_tools = sorted(set(allowed_tools))
    confirm_tools = sorted(set(confirm_tools))

    # Canonicalize path policies: sort by (tool,arg,root)
    path_policies = sorted(
        path_policies,
        key=lambda d: (str(d.get('tool')), str(d.get('arg')), str(d.get('root'))),
    )

    # Canonicalize no-dash rules
    nd_norm = []
    for d in no_dash_args:
        nd_norm.append({'tool': d['tool'], 'args': sorted(set(d.get('args') or []))})
    no_dash_args = sorted(nd_norm, key=lambda d: (str(d.get('tool')), ','.join(d.get('args') or [])))

    pol: Dict = {
        'trust_required': bool(trust_required),
        'allowed_tools': allowed_tools,
        'require_confirm_for': confirm_tools,
        'path_policies': path_policies,
        'no_dash_args': no_dash_args,
    }
    if secret_storage:
        pol['secret_storage'] = secret_storage

    if sanitize_required is not None:
        pol['sanitize_tool_outputs'] = {'required': bool(sanitize_required), 'mode': 'strip_instruction_markers'}

    if memory_policy is not None:
        pol['memory_policy'] = memory_policy

    return CompileResult(ok=(len(errors) == 0), policies=pol, errors=errors)


def policy_fingerprint(policies_obj: Dict) -> str:
    """Hash of the canonicalized policy dict (JCS over JSON subset)."""
    canon = scope.jcs_canonicalize(policies_obj).encode('utf-8')
    return 'sha256:' + hashlib.sha256(canon).hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--in', dest='inp', required=True, help='Policy DSL text file')
    ap.add_argument('--out', dest='out', required=True, help='Where to write compiled JSON')
    args = ap.parse_args()

    text = open(args.inp, 'r', encoding='utf-8').read()
    res = compile_policy(text)
    if not res.ok:
        for e in res.errors:
            print('error:', e)
        return 2

    import json

    with open(args.out, 'w', encoding='utf-8') as f:
        json.dump(res.policies, f, indent=2, sort_keys=True)
        f.write('\n')

    print('policy_fingerprint:', policy_fingerprint(res.policies))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
