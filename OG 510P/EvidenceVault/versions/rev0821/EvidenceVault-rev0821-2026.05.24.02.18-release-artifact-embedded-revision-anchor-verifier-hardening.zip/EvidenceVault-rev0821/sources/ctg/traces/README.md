# Replayable Trace Templates (RTTs)

This folder contains *byte-committed* JSONL traces used as evaluation fixtures.

## Files
- `manifest.json` — digests for each trace + a Merkle root commitment.
- `safe_baseline.jsonl` — positive control (expected `accept`).
- `pretrust_mcp_consent_bypass.jsonl` — CVE-anchored pre-trust configuration inversion (expected `reject`).
- `dxt_calendar_injection.jsonl` — calendar-triggered indirect prompt injection -> local execution (expected `reject`).
- `tool_identity_rugpull.jsonl` — tool identity swap under the same name / supply chain (expected `reject`).
- `memory_recommendation_poisoning.jsonl` — persistent-state steering (expected `reject`).

## Verifying
From the workspace root:

```bash
python pcg_trace_tools.py verify --manifest traces/manifest.json --traces-dir traces
python pcg_rtt_harness.py   # emits table_rtt_detection.tex
```

Each trace begins with a `meta` line that binds:
- `scope_fingerprint`
- `tool_registry_snapshot`
- `expected_gate` (accept/reject)

Verifiers should treat *any* mismatch (or missing trust acknowledgement) as a failure and reject the release.

- **tool_output_poisoning(_accept).jsonl**: tool-output indirect prompt injection attempt; requires explicit `output_sanitized` step when `sanitize_tool_outputs.required=true`.

