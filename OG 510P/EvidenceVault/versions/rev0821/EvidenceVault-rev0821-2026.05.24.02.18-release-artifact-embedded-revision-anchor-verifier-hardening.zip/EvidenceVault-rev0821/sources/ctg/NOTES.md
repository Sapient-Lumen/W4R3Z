# Evolving Notes (v217 — 2026-02-28)

This folder is a **working paper workspace** extracted from the CTG archive and edited for a clean, research-paper-facing iteration.

## What changed in v217
- **Scope certificates now carry policies**: RTT fixtures embed a `scope` object (allowlist, confirmation rules, path/arg policies, and symlink/realpath rules) and the verifier recomputes `scope_fingerprint` from it (fail-closed if inconsistent).
- **Manifest format v3**: `traces/manifest.json` now commits *leaf data* `{file,digest,scope_fingerprint,tool_registry_snapshot,expected_gate}` via a Merkle root, enabling a single manifest to cover multiple scopes and registry snapshots without hidden drift.
- **Expanded RTT suite (17 traces)**: added two new paired incidents:
  - `mcp_git_init_escape(_accept).jsonl` models unrestricted `git_init` (CVE-2025-68143).
  - `mcp_fs_symlink_escape(_accept).jsonl` models filesystem symlink escapes (CVE-2025-53109) with a declarative `symlink_map` that the verifier resolves before enforcing root containment.
- **Registry snapshot updated**: `tool_registry_snapshot.json` now includes `mcp.git.init` and `mcp.fs.read`, and all trace bindings were refreshed.
- **Conformance mutations updated**: the harness adds `Git init path escape` and `FS symlink escape` mutations, and the trace-mutation table reflects the new operators.
- **Papers refreshed**: incident mapping + RTT template table updated with the new CVE-driven cases and references (NVD + ZDI).


## What changed in v214
- **Added replayable trace templates (RTTs)**: three incident-inspired JSONL fixtures in `traces/` plus a digest manifest (`traces/manifest.json`) and a paper-facing table (`table_trace_templates.tex`).
- **Built a reference trace envelope verifier**: `pcg_trace_tools.py` computes stable trace digests and checks `meta` bindings (scope fingerprint + tool-registry snapshot).
- **Connected RTTs to the conformance suite**: added trace-driven mutation operator table (`table_trace_mutations.tex`) and integrated it into `paper_conformance.tex`.
- **Flagship evaluation tightened**: added Algorithm~\ref{alg:verify_rtt} for offline RTT verification and clarified how RTT seeds feed mutation testing.

### Previously (v212)
- **Grounded motivation in 2026 incidents**: added an incident→channel→artifact mapping table (`table_incident_mapping.tex`) and tightened intro citations in `paper_pcg.tex`.
- **Made scope evolution executable**: added a concrete scope-delta patch example (`table_scope_delta_example.tex`) plus a small reference implementation (`pcg_scope_tools.py`) and example scopes/patch JSON.
- **Formalized optional-stopping enforceability**: added a ticket + e-ledger theorem (alpha-spending bound) explaining how CapT makes ``dropped failures detectable at the gate.
- Added RFC references for **canonical JSON (RFC 8785)** and **OAuth resource indicators (RFC 8707)** to `refs_additions.bib`.


## What we are trying to claim (flagship: `paper_pcg.tex`)
**Thesis:** tool-using LLM safety needs *proof-carrying governance*: (i) **statistical certificates** that bound multi-channel risk, (ii) **scope binding** that makes those guarantees non-transferable across tool stacks and auth configs, and (iii) **transparency + conformance** so auditors can detect certificate shopping, policy confusion, and verifier bugs.

### Novelty candidates to sharpen (pick 2–4 as the main “we did this” bullets)
1. **Registry-scale scope binding for MCP ecosystems.**
   - Bind certificates to *server identity + auth resource indicators + sandbox/network policy*, not just “tool name”.
   - Tool Identity Continuity (TIC) records: manifest hash + signer + transparency-log inclusion proof.
2. **Menus as lattices + antichain compression.**
   - Make the *selection surface* auditable; certify escalation menus rather than a single threshold.
   - Use maximal antichains to reduce calibration burden while preserving monotone derivations.
3. **Optional-stopping robustness by design.**
   - Anytime-valid tripwires via e-processes for drift + telemetry gaps.
   - Explicitly treat missing telemetry as a *channel* so “monitor outage” is governed, not hand-waved.
4. **Fail-closed verifiers measured via differential conformance.**
   - Treat verifier behavior as part of the security perimeter and ship *mutation suites* that catch policy-confusion and recursive-verification failures.

## Companion paper direction (`paper_conformance.tex`)
**Angle:** “governance artifacts are only as strong as their verifiers.” We frame conformance suites + differential testing as a first-class security primitive, analogous to TLS stacks, container runtime hardening, or compiler fuzzing.

## Auto-generated tables in this workspace
- `table_closure_metrics.tex` is generated from the archive scripts:
  ```bash
  python ctg_make_table_closure_metrics.py \
    --baseline demo_end_to_end/ctg_safetycase_bundle.json \
    --mutated conformance_suite/policy_drift_across_evidence/demo_end_to_end/ctg_safetycase_bundle.json \
    --authorized conformance_suite/authorized_policy_heterogeneity_partitioned/demo_end_to_end/ctg_safetycase_bundle.json \
    --out table_closure_metrics.tex
  ```
- The other `table_*.tex` files are copied from the CTG archive and should be treated as *source-of-truth* artifacts unless regenerated by their scripts.

## Next-turn build plan (high leverage)
1. **Lock the evaluation story.**
   - Minimal end-to-end experiment: generate CTG certificates on a tool benchmark trace; introduce scope drift + telemetry dropout; show tripwire escalation.
2. **Make “scope fingerprint” concrete.**
   - Canonicalization rules (ordering, normalization), and exact fields included for MCP (resource indicator, client sandbox hash, server signer).
3. **Write the “governance adversary” formal model.**
   - Adversary chooses among certificates/menus, calibration subsets, and peeking schedules.
4. **Add a registry deployment sketch.**
   - How an MCP registry could require CTG artifacts and publish inclusion proofs.

## Build instructions
These LaTeX papers reference `refs_selected.bib` (from the archive) plus `refs_additions.bib` (new web-checked additions).
Use `latexmk` or `pdflatex + biber`.
## v216 notes (2026-02-28)
- Added RTT fixtures for MCP git-server hardening cases based on upstream advisories:
  - **CVE-2025-68145 / GHSA-j22h-9j4x-23w5**: missing `repo_path` validation under `--repository`.
  - **CVE-2025-68144 / GHSA-9xwc-hfwc-8w59**: flag-like ref arguments enabling file overwrite.
  - Implemented paper-facing verifier checks via `meta.path_policies` and `meta.no_dash_args` in `pcg_trace_tools.py`.
- Added **e-ledger composition** table + a monitoring figure (`table_eledger_merge_rules.tex`, `fig_eledger_menu_shopping.png`) and integrated into `paper_pcg.tex`.
- Updated trace mutation suite to include `Repo path escape` and `Flag-like git ref` mutations (see `pcg_rtt_harness.py`, `table_trace_mutations.tex`).

### TODO (next high-leverage)
- Add a third RTT seed for **CVE-2025-68143 / GHSA-5cgr-j3jf-jw3v** (`git_init` writing outside the intended repo root).
- Tighten the formalism: specify when path/arg policies live in **scope certificates** vs. trace meta (current fixtures model both, but deployment should bind policies in the scope fingerprint).
- Expand the e-ledger demo to show **selective reporting** attacks vs. witnessed CapT publication (missing attempts become detectably absent).

## v218 notes (2026-02-28)
- **Expanded RTT suite** from 8 paired RTTs to **11 paired RTTs** (+ safe baseline). New fixtures:
  - **Filesystem prefix-match escape** (**CVE-2025-53110**): naive string-prefix checks allow unintended access (added `mcp_fs_prefix_match{,_accept}.jsonl`).
  - **Secrets-at-rest misconfiguration** inspired by **Docker Desktop MCP cleartext secret storage** (**ZDI-26-123**): reject traces that observe cleartext secret stores when scope policy requires encryption (added `docker_mcp_cleartext_secrets{,_accept}.jsonl`).
  - **Registry rollback / split-view under same tool@version**: enforce **TIC-pinned** digest agreement between scope and observed registry entries (added `registry_rollback{,_accept}.jsonl`).
- **Verifier upgrades (`pcg_trace_tools.py`)**:
  - Added a paper-facing `secret_storage: encrypted_required` policy with `secrets_store` observation checks (`secrets_cleartext`).
  - Added optional `scope.tool_registry` (tool -> version -> digest) enforcement for TIC-pinned digest agreement (`registry_tic_mismatch`).
- **Policy DSL prototype**: `pcg_policy_dsl.py` + `policy_examples/example_fs_read.pcg` compiling to canonical scope `policies` JSON with a policy fingerprint.
- **Conformance harness rewrite** (`pcg_rtt_harness.py`):
  - Baseline panel still checks all RTTs (now 23/23 correct).
  - Mutation robustness is now **aggregated** (Applicable/Flipped/Rate) with failure IDs, and a separate index table is emitted (`table_rtt_index.tex`).
- **Paper edits**:
  - Added a short subsection on typed policy DSL compilation and determinism (`paper_pcg.tex`, Listing~\ref{lst:pcg_policy_dsl}).
  - Updated RTT section to reflect the 11-pair suite and added citations for CVE-2025-53110 and ZDI-26-123.
  - Extended trace template/mutation tables and incident mapping with filesystem containment + secrets-at-rest entries.

## v219 (2026-02-28)

- Added tool-output poisoning RTT pair (**tool_output_poisoning(_accept).jsonl**) modeling indirect prompt injection carried in *tool results* (delayed-effect).
- Extended semantic verifier with a **tool-output firewall** invariant: when `sanitize_tool_outputs.required=true`, any instruction-like tool output must be followed by an explicit `output_sanitized` event before further action; otherwise reject fail-closed.
- Added new mutation operator: **Remove output sanitizer**.
- Added transparency analysis for **randomized audits** detecting split-view equivocation; generated `fig_equivocation_audit.png` and `table_equivocation_audit.tex`.
- Expanded related-work coverage on indirect prompt injection benchmarks/defenses (InjecAgent, ASB, WASP, AgentDyn, firewall defenses, AgentSentry).

Next:
- Add RTTs for cross-session memory poisoning (long-horizon IPI) and for *mixed* attacks combining registry rollback + tool-output injection.
- Formalize the policy DSL semantics as a small type system (compile-to-automata) and prove a non-bypass property under deterministic verifiers.

