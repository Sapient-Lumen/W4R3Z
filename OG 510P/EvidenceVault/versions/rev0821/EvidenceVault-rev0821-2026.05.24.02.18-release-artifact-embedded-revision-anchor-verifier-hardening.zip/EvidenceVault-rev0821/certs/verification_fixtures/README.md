# Crypto verification fixtures

This directory contains deliberately small Ed25519 DSSE fixtures introduced in rev0810.

- `rev0810_positive.dsse.json` must verify against `rev0810_ed25519_public.pem`.
- `rev0810_negative_payload_tamper.dsse.json` is syntax-valid but must fail verification because its payload was changed after the positive signature was produced.

Only the public key is shipped. The fixtures are validation artifacts, not production credentials.
