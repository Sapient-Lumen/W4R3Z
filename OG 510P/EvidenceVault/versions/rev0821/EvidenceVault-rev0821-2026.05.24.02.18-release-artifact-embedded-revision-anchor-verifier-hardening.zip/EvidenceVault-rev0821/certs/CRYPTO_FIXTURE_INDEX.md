# Crypto fixture index

This file is the human-readable companion to `certs/CRYPTO_FIXTURE_INDEX.json`.
`scripts/validate_crypto_envelopes.py` treats the listed fixtures as verification obligations, not merely syntax examples.

## Verification profile

- Envelope: `DSSEv1`
- Signature scheme: `Ed25519`
- PAE: `DSSEv1 PAE over payloadType and decoded payload bytes`
- Key ID derivation: `ed25519:<first 16 hex chars of sha256(SubjectPublicKeyInfo DER)>`

## Fixtures

### `rev0810_positive_dsse_ed25519`
- Role: `positive`
- Expected result: `verify_pass`
- Envelope: `certs/verification_fixtures/rev0810_positive.dsse.json`
- Public key: `certs/verification_fixtures/rev0810_ed25519_public.pem`
- Key ID: `ed25519:e817b75d33f70261`
- Payload SHA-256: `d0af4c456dc9f4b3176b64f32ed15590db4c51e6833856abf5c8bcdad343185c`
- PAE SHA-256: `7a837bd809e727e5d3bf5e2190a1134460b28b2cafb1bf275d4b87aa9c91d78b`
- Signature SHA-256: `faf2b4ba1cfce5a28db60dcd94963cea05d2f876e3abee3bd03721f223005224`
- Negative reason: `not_applicable`

### `rev0810_negative_payload_tamper_dsse_ed25519`
- Role: `negative`
- Expected result: `verify_fail`
- Envelope: `certs/verification_fixtures/rev0810_negative_payload_tamper.dsse.json`
- Public key: `certs/verification_fixtures/rev0810_ed25519_public.pem`
- Key ID: `ed25519:e817b75d33f70261`
- Payload SHA-256: `5623eb39e39e16508941c097932dc440fa1377581bf8eb673874720b4bc74e9b`
- PAE SHA-256: `4ce4aea8eb4847b2de33f443758e20dd66005162ae63667cbcefa0b09e121b55`
- Signature SHA-256: `faf2b4ba1cfce5a28db60dcd94963cea05d2f876e3abee3bd03721f223005224`
- Negative reason: `payload_tampered_after_signature`