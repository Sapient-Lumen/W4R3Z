# Curated certificate and receipt examples

This folder contains a **curated, publishable subset** of signed objects / receipts / attestations drawn from the imported legacy trees.

Design goals:
- Provide **small, representative** examples that match the papers' terminology.
- Avoid ephemeral build outputs.
- **Do not ship private keys** (see `REDACTIONS.paths`).

For full historical context, consult `legacy/` and `originals/`.
