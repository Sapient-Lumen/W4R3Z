# Claim-obligation map

This file is the exact human-facing companion to `CLAIM_OBLIGATION_MAP.json`.
It maps selected EvidenceVault paper/release claims to the concrete local surfaces, validators, obligations, limits, and negative-regression expectations that support them.

- Revision: `rev0821`
- Previous revision: `rev0820`
- Generated: `2026-05-24T02:18:00-0400`
- Scope: `archive-claim-to-validator-crosswalk`
- Validator: `scripts/validate_claim_obligation_map.py`
- Claim count: `12`

## Boundary

This map does not create new canon or new paper claims. It records which existing shipped surfaces and validators support selected claims so reviewers can falsify stale or overbroad support statements locally.

## Required canonical papers

- `papers/ev_acceptability_kernel.tex`
- `papers/ev_interpretation_profiles.tex`
- `papers/ev_streamfold.tex`
- `papers/ev_zkrtp.tex`
- `papers/ev_pact_ocf.tex`

## Claim obligations

### COM-0001 — Named archive bundle identity is closed over shipped regular files
- Class: `release_identity`
- Status: `active`
- Summary: A named EvidenceVault release must identify the extracted root, current revision, included roots, file inventory, archive lineage, manifest digests, and acyclic metadata-bridge perimeter before the external ZIP is accepted.
- Archive surfaces: `RELEASE_MANIFEST.json`, `REVISION_RECEIPT.json`, `REVISION_ANCHORS.json`, `ARCHIVE_INDEX.json`, `ARCHIVE_INDEX.md`, `INDEX/files.json`, `INDEX/files.csv`, `MANIFEST.sha256`, `schemas/release_manifest.schema.json`, `scripts/validate_archive_identity.py`, `scripts/rebuild_indexes.py`, `scripts/package_release.py`, `ro-crate-metadata.json`, `RO_CRATE_PROFILE.md`, `schemas/ro_crate_metadata.schema.json`, `scripts/validate_ro_crate_metadata.py`, `scripts/verify_release_artifact.py`, `AUDIT/release_artifact_embedded_revision_anchor_verifier_inventory_rev0821.md`
- Validators: `scripts/validate_archive_identity.py`, `scripts/validate_manifest_index.py`, `scripts/validate_revision_anchors.py`, `scripts/validate_archive_index.py`, `scripts/validate_ro_crate_metadata.py`
- Make targets: `make identity-check`, `make manifest-check`, `make revision-check`, `make archive-index-check`, `make package-release`, `make ro-crate-check`
- Paper references:
  - `papers/ev_acceptability_kernel.tex` — portable acceptability is framed as a fail-closed replay problem whose first closure obligation is identity closure
- Obligations:
  - The archive root, release manifest, revision anchors, archive index, and manifest/index inventories must agree on revision, bundle name, file count, and current lineage.
  - Every shipped file must be covered by RELEASE_MANIFEST.json included_roots and by MANIFEST.sha256/INDEX/files.*.
  - RELEASE_MANIFEST.json identity_digests must cover non-cyclic release-manifest schema, archive-identity validator, and RO-Crate schema/validator surfaces, while identity_digest_exclusions must explicitly name RO-Crate metadata/profile cycle boundaries.
- Known limits:
  - This proves local package identity and contents, not availability of external mirrors after the ZIP leaves the session.
- Negative regression: Adding a root file outside included_roots, changing a manifest digest, or corrupting a non-cyclic release-manifest perimeter digest must fail before package emission.

### COM-0002 — Replay assurance is a full-gate obligation, not a packager shortcut
- Class: `replay_validation`
- Status: `active`
- Summary: The shortest release-facing packaging path must rerun the full gate-equivalent validator sequence after refresh so a direct package invocation cannot bypass an archive-wide failure.
- Archive surfaces: `scripts/gate.py`, `scripts/package_release.py`, `scripts/publish_audit.py`, `scripts/validate_command_runners.py`, `VALIDATION_INDEX.json`, `VALIDATION_INDEX.md`, `Makefile`, `scripts/verify_release_artifact.py`, `AUDIT/release_artifact_embedded_revision_anchor_verifier_inventory_rev0821.md`
- Validators: `scripts/validate_command_runners.py`, `scripts/validate_validation_index.py`, `scripts/validate_makefile_surface.py`
- Make targets: `make gate`, `make runner-check`, `make validation-check`, `make command-surface-check`, `make package-release`
- Paper references:
  - `papers/ev_acceptability_kernel.tex` — fail-closed replay and obligation discharge require the replay rule to be fixed rather than operator-selected
- Obligations:
  - scripts/package_release.py must run the same final validator sequence as scripts/gate.py after refresh.
  - Composite runners must execute child validators by explicit paths in fresh subprocesses with bytecode suppression.
- Known limits:
  - The gate proves the shipped validator set in this archive; it does not prove unshipped validators that a reviewer might wish existed.
- Negative regression: Corrupting a JSON file or removing a gate-listed validator must cause direct package_release.py to fail before ZIP writing.

### COM-0003 — Source and omission provenance remains explicit and locally checkable
- Class: `source_provenance`
- Status: `active`
- Summary: Retained sources, omitted upstream inputs, redactions, pruning, extraction notes, and source-family representation are named by governed ledgers rather than recovered from directory shape alone.
- Archive surfaces: `SOURCE_INDEX.json`, `SOURCE_INDEX.md`, `papers/EXTRACTION_MAP.json`, `UPSTREAM_INPUTS.sha256`, `AUDIT/UPSTREAM_OMISSIONS.csv`, `AUDIT/UPSTREAM_DIFF_REPORT.md`, `REDACTIONS.paths`, `PRUNED_TRANSIENT.paths`, `sources/`
- Validators: `scripts/validate_source_index.py`, `scripts/validate_provenance_ledgers.py`, `scripts/validate_paper_series.py`, `scripts/validate_cross_references.py`
- Make targets: `make source-check`, `make provenance-check`, `make paper-check`, `make cross-reference-check`
- Paper references:
  - `papers/ev_interpretation_profiles.tex` — carried context and governed operativity depend on declared history/evidence coordinates rather than silent substitution
- Obligations:
  - Retained-source roots and family-representation rows must resolve to shipped paths.
  - Omission, redaction, and pruning ledgers must remain parseable, safe, and mutually coherent with present/absent paths.
- Known limits:
  - The ledgers describe the curated archive boundary; they do not fetch or revalidate every possible external upstream artifact.
- Negative regression: Deleting a referenced source root or leaving a redacted path present must fail the source/provenance validators.

### COM-0004 — Public surface status and non-widening posture are explicit
- Class: `public_surface`
- Status: `active`
- Summary: The public surface remains governed by published release ledgers, while PUBLIC_STATUS.* explicitly states the latest public release, current internal revision, revision delta, and no-public-payload-widening posture.
- Archive surfaces: `published/PUBLIC_SURFACE.json`, `published/README.md`, `published/releases/RELEASE_INDEX.json`, `published/releases/LATEST.json`, `published/releases/artifacts/ARTIFACT_INDEX.json`, `release_queue/QUEUE_INDEX.json`, `publishing/CANONICAL_POLICY.json`, `publishing/templates/public_release.md`, `PUBLIC_STATUS.json`, `PUBLIC_STATUS.md`, `schemas/public_status.schema.json`
- Validators: `scripts/validate_publishing.py`, `scripts/validate_embedded_archives.py`, `scripts/validate_archive_identity.py`, `scripts/validate_public_status.py`
- Make targets: `make publishing-check`, `make archive-payload-check`, `make release-ledgers`, `make publish-audit`, `make public-status-check`
- Paper references:
  - `papers/ev_interpretation_profiles.tex` — policy-aware replay separates carried evidence and governed publication/visibility obligations from local representation
- Obligations:
  - Queue and public-release records must have exact Markdown/JSON companion coherence.
  - Materialized public-release bundles must remain fresh with their bundle manifests and portable ZIP metadata.
  - PUBLIC_STATUS.json must mirror the current revision receipt, release manifest, revision anchors, and latest public-release pointer.
  - The status bridge must declare no public payload widening, no queue-state change, and no canonical paper/source payload change unless the governed release surfaces move explicitly.
- Known limits:
  - The public surface intentionally omits most internal archive files; absence from published/ is not evidence of absence from the working archive.
  - PUBLIC_STATUS.* is a status bridge only; it does not publish a new public release or replace the release queue.
- Negative regression: Corrupting PUBLIC_STATUS.json, for example by changing internal_revision_delta or latest_public_release.revision, must cause scripts/validate_public_status.py and direct package release to fail before ZIP emission.

### COM-0005 — Canonical paper payload and extraction surfaces are validated as shipped objects
- Class: `paper_payload`
- Status: `active`
- Summary: The five canonical paper TeX/PDF surfaces, root PDF mirrors, catalog/index pointers, and extraction-map path references must exist and remain locally decodable.
- Archive surfaces: `SERIES.md`, `PAPER_SERIES_INDEX.md`, `CATALOG.md`, `papers/EXTRACTION_MAP.json`, `papers/ev_acceptability_kernel.pdf`, `papers/ev_interpretation_profiles.pdf`, `papers/ev_streamfold.pdf`, `papers/ev_zkrtp.pdf`, `papers/ev_pact_ocf.pdf`
- Validators: `scripts/validate_paper_series.py`, `scripts/validate_payload_formats.py`, `scripts/validate_text_payloads.py`
- Make targets: `make paper-check`, `make payload-format-check`, `make text-check`
- Paper references:
  - `papers/ev_acceptability_kernel.tex` — canonical spine paper in the archive series
  - `papers/ev_interpretation_profiles.tex` — canonical interpretation bridge paper in the archive series
  - `papers/ev_streamfold.tex` — canonical StreamFold/dOCF family note
  - `papers/ev_zkrtp.tex` — canonical zk-RTP family note
  - `papers/ev_pact_ocf.tex` — canonical PACT/OCF family note
- Obligations:
  - The canonical paper list, root PDF mirrors, and extraction-map references must agree on shipped paths.
  - PDF/PNG/residual payload validators must decode format structure beyond SHA-256 presence.
- Known limits:
  - The validators check local paper/package structure; they do not peer-review mathematical correctness of every theorem.
- Negative regression: Removing a compiled canonical PDF, breaking a paper path in EXTRACTION_MAP.json, or corrupting PDF structure must fail paper/payload validation.

### COM-0006 — Historical exceptions are named exceptions, not validator folklore
- Class: `historical_exception`
- Status: `active`
- Summary: Carried-forward duplicate/order and audit-witness body-label anomalies are accepted only when the exact scanned anomaly set is ledgered and rendered.
- Archive surfaces: `AUDIT/HISTORICAL_ANOMALIES.json`, `AUDIT/HISTORICAL_ANOMALIES.md`, `schemas/historical_anomalies.schema.json`, `CHANGELOG.md`, `ARCHIVE_INDEX.json`, `AUDIT/README.md`
- Validators: `scripts/validate_historical_anomalies.py`, `scripts/validate_changelog.py`, `scripts/validate_archive_index.py`, `scripts/validate_audit_witnesses.py`
- Make targets: `make historical-anomaly-check`, `make changelog-check`, `make archive-index-check`, `make audit-witness-check`
- Paper references:
  - `papers/ev_acceptability_kernel.tex` — fail-closed replay makes missing or hidden obligations surface as failed witnesses rather than tacit acceptance
- Obligations:
  - The historical anomaly ledger must exactly match the anomaly set rescanned from changelog, archive index, and retained audit witnesses.
  - Recent duplicate/order drift must fail instead of becoming a new silent exception.
- Known limits:
  - Ledgering preserves inherited archive facts; it does not retroactively normalize old revision labels.
- Negative regression: Removing one ledgered anomaly or introducing a recent duplicate heading must fail historical-anomaly validation.

### COM-0007 — Cryptographic fixture truth is locally falsifiable
- Class: `crypto_truth`
- Status: `active`
- Summary: At least one shipped positive Ed25519 DSSE fixture must verify and at least one negative fixture must fail, so crypto validation distinguishes truth from syntax-valid shape.
- Archive surfaces: `certs/CRYPTO_FIXTURE_INDEX.json`, `certs/CRYPTO_FIXTURE_INDEX.md`, `schemas/crypto_fixture_index.schema.json`, `certs/verification_fixtures/rev0810_ed25519_public.pem`, `certs/verification_fixtures/rev0810_positive.dsse.json`, `certs/verification_fixtures/rev0810_negative_payload_tamper.dsse.json`
- Validators: `scripts/validate_crypto_envelopes.py`
- Make targets: `make crypto-check`
- Paper references:
  - `papers/ev_interpretation_profiles.tex` — externally checkable transparency/obligation components require declared witness forms rather than prose-only trust
- Obligations:
  - The crypto fixture index must mirror its Markdown companion and reference existing key/envelope files.
  - Positive and negative fixtures must match declared key IDs, payload/PAE/signature digests, and expected verification outcomes.
- Known limits:
  - The fixture lane proves local verifier behavior on shipped examples; it does not claim production key custody or external transparency-log inclusion.
- Negative regression: Tampering the positive DSSE payload while refreshing digests must still fail signature verification.

### COM-0008 — Replay toolchain assumptions are explicit and checked
- Class: `toolchain_replay`
- Status: `active`
- Summary: The local replay floor for Python modules, required external commands, and deterministic ZIP constants is governed by a lock surface rather than implicit operator memory.
- Archive surfaces: `TOOLCHAIN_LOCK.json`, `TOOLCHAIN_LOCK.md`, `schemas/toolchain_lock.schema.json`, `scripts/package_release.py`, `scripts/publish_preflight.sh`
- Validators: `scripts/validate_toolchain_lock.py`, `scripts/validate_command_runners.py`, `scripts/validate_archive_identity.py`
- Make targets: `make toolchain-check`, `make runner-check`, `make identity-check`, `make package-release`
- Paper references:
  - `papers/ev_acceptability_kernel.tex` — portable replay depends on fixed closure obligations and witness forms rather than ambient assumptions
- Obligations:
  - Required Python packages, command availability, and ZIP metadata policy constants must be declared and checked.
  - The toolchain lock Markdown companion must exactly render the JSON lock.
- Known limits:
  - The lock records a minimum-supported floor plus observed witnesses; it intentionally does not forbid every newer compatible patch version.
- Negative regression: Declaring a required missing command or changing a package ZIP constant without updating the lock must fail toolchain validation.

### COM-0009 — Decision/frontier memory is bounded recovery surface, not canon replacement
- Class: `decision_memory`
- Status: `active`
- Summary: ADRs, RFCs, the assimilation ledger, and the current frontier preserve durable decisions, unresolved proposals, adopted/rejected pattern memory, and live pressure without moving canon ownership from the papers/publishing/history surfaces.
- Archive surfaces: `ADR_INDEX.json`, `ADR_INDEX.md`, `RFC_INDEX.json`, `RFC_INDEX.md`, `ASSIMILATION_LEDGER.json`, `ASSIMILATION_LEDGER.md`, `CURRENT_FRONTIER.json`, `CURRENT_FRONTIER.md`, `adrs/`, `rfcs/`
- Validators: `scripts/validate_adrs.py`, `scripts/validate_rfcs.py`, `scripts/validate_assimilation_ledger.py`, `scripts/validate_current_frontier.py`
- Make targets: `make adr-check`, `make rfc-check`, `make assimilation-check`, `make frontier-check`
- Paper references:
  - `papers/ev_interpretation_profiles.tex` — governed interpretation separates carried meaning from governance/history surfaces and authority context
- Obligations:
  - Decision/proposal/frontier companions must exactly render their JSON sources where applicable.
  - References from frontier/assimilation/RFC/ADR records must resolve to known records or shipped surfaces.
- Known limits:
  - These surfaces aid recovery and governance memory; they do not amend canonical paper architecture by themselves.
- Negative regression: Introducing an unknown RFC/ADR/assimilation reference or stale Markdown companion must fail the relevant decision/frontier validator.

### COM-0010 — Claim-to-validator support is itself governed and falsifiable
- Class: `claim_crosswalk`
- Status: `active`
- Summary: This map must stay schema-valid, companion-rendered, wired through gate/package surfaces, and tied to existing paths, validators, make targets, and canonical papers.
- Archive surfaces: `CLAIM_OBLIGATION_MAP.json`, `CLAIM_OBLIGATION_MAP.md`, `schemas/claim_obligation_map.schema.json`, `VALIDATION_INDEX.json`, `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `CONTEXT_PACK.json`, `publishing/CANONICAL_POLICY.json`
- Validators: `scripts/validate_claim_obligation_map.py`, `scripts/validate_validation_index.py`, `scripts/validate_control_surfaces.py`, `scripts/validate_cross_references.py`
- Make targets: `make claim-obligation-check`, `make validation-check`, `make control-check`, `make cross-reference-check`, `make gate`, `make package-release`
- Paper references:
  - `papers/ev_acceptability_kernel.tex` — obligation discharge is explicit rather than inferred from scattered witnesses
- Obligations:
  - The map must reference only shipped surfaces, anchored validators, and Makefile/validation-index targets.
  - The map must cover all canonical papers and required claim classes before packaging.
- Known limits:
  - The map is a support crosswalk, not an independent proof of mathematical soundness or a new canonical architecture statement.
- Negative regression: Removing a referenced validator, target, canonical paper reference, or Markdown companion line must fail claim-obligation validation.

### COM-0011 — External research-object metadata is a bridge, not a new truth source
- Class: `external_metadata_bridge`
- Status: `active`
- Summary: The RO-Crate-style metadata surface exposes selected core archive surfaces to external research-object consumers while remaining subordinate to native release-manifest, file-inventory, and validation-index authority.
- Archive surfaces: `ro-crate-metadata.json`, `RO_CRATE_PROFILE.md`, `schemas/ro_crate_metadata.schema.json`, `RELEASE_MANIFEST.json`, `MANIFEST.sha256`, `INDEX/files.json`, `VALIDATION_INDEX.json`, `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `CONTEXT_PACK.json`, `publishing/CANONICAL_POLICY.json`
- Validators: `scripts/validate_ro_crate_metadata.py`, `scripts/validate_json_inventory.py`, `scripts/validate_validation_index.py`, `scripts/validate_cross_references.py`
- Make targets: `make ro-crate-check`, `make json-check`, `make validation-check`, `make cross-reference-check`, `make gate`, `make package-release`
- Paper references:
  - `papers/ev_acceptability_kernel.tex` — portable acceptability depends on replayable local obligations rather than ungoverned external descriptions
  - `papers/ev_interpretation_profiles.tex` — interpretation profiles remain governed by declared surfaces rather than implicit packaging shape
- Obligations:
  - The JSON-LD descriptor must retain the RO-Crate-style metadata descriptor/root dataset shape, exact root revision/date/identifier agreement, and required selected hasPart entries.
  - Every digest-bearing file entity must match the shipped file size and SHA-256, while self-referential inventory surfaces remain listed but not digest-cycled.
  - The bridge must be wired through gate, publish-audit, package-release, context, control, lifecycle, policy, validation, and revision-anchor surfaces before shipping.
- Known limits:
  - The bridge is not an exhaustive RO-Crate profile for every shipped file and does not replace MANIFEST.sha256, INDEX/files.*, or RELEASE_MANIFEST.json.
  - It improves external legibility but does not itself publish, mirror, or widen the governed public payload surface.
- Negative regression: Changing the root version, removing a required hasPart entry, or corrupting a digest-bearing entity must fail RO-Crate metadata validation before package emission.

### COM-0012 — Emitted release artifacts replay embedded inclusion, index, identity, RO-Crate, and crypto fixture evidence from ZIP bytes
- Class: `external_artifact_verification`
- Status: `active`
- Summary: The detached artifact verifier checks the emitted ZIP/sidecar boundary and replays embedded manifest, index, identity-digest, inclusion-fence, RO-Crate bridge semantics, and indexed positive/negative Ed25519 DSSE fixture verification from artifact bytes rather than trusting the live checkout.
- Archive surfaces: `scripts/verify_release_artifact.py`, `scripts/package_release.py`, `scripts/validate_command_runners.py`, `RELEASE_MANIFEST.json`, `schemas/release_manifest.schema.json`, `MANIFEST.sha256`, `INDEX/files.json`, `VALIDATION_INDEX.json`, `CONTROL_SURFACES.json`, `LIFECYCLE_GATES.json`, `CONTEXT_PACK.json`, `publishing/CANONICAL_POLICY.json`, `AUDIT/release_artifact_verifier_inventory_rev0816.md`, `INDEX/files.csv`, `AUDIT/release_artifact_embedded_index_identity_inventory_rev0817.md`, `AUDIT/release_artifact_inclusion_fence_verifier_inventory_rev0818.md`, `ro-crate-metadata.json`, `RO_CRATE_PROFILE.md`, `scripts/validate_ro_crate_metadata.py`, `AUDIT/release_artifact_embedded_ro_crate_semantics_inventory_rev0819.md`, `AUDIT/release_artifact_embedded_crypto_fixture_verifier_inventory_rev0820.md`, `certs/CRYPTO_FIXTURE_INDEX.json`, `certs/CRYPTO_FIXTURE_INDEX.md`, `certs/verification_fixtures/rev0810_ed25519_public.pem`, `certs/verification_fixtures/rev0810_positive.dsse.json`, `certs/verification_fixtures/rev0810_negative_payload_tamper.dsse.json`, `scripts/validate_crypto_envelopes.py`, `AUDIT/crypto_fixture_verification_inventory_rev0810.md`, `AUDIT/release_artifact_embedded_revision_anchor_verifier_inventory_rev0821.md`
- Validators: `scripts/validate_command_runners.py`, `scripts/validate_archive_identity.py`, `scripts/validate_validation_index.py`, `scripts/validate_cross_references.py`
- Make targets: `make runner-check`, `make identity-check`, `make validation-check`, `make cross-reference-check`, `make package-release`
- Paper references:
  - `papers/ev_acceptability_kernel.tex` — portable acceptability and replay failure modes require that artifact evidence be locally checkable rather than only asserted by process logs
- Obligations:
  - The package writer must emit a SHA-256 sidecar for the named ZIP bundle and invoke the detached verifier before reporting package success.
  - The detached verifier must reject sidecar digest drift, unsafe ZIP paths, duplicate or directory entries, non-normalized ZIP timestamps/modes/extra fields, release-manifest included_roots coverage drift, release-manifest identity mismatch, embedded MANIFEST.sha256 coverage/digest mismatch, embedded INDEX/files.json semantic mismatch, and embedded INDEX/files.csv mirror drift.
  - The embedded release manifest included_roots list must be replayed against ZIP members so added payloads cannot hide behind refreshed MANIFEST.sha256, INDEX/files.*, file_count, and sidecar digest values.
  - The release manifest identity_digests map must be replayed against embedded ZIP members so identity-surface corruption cannot be hidden by refreshing MANIFEST.sha256 and the sidecar alone.
  - The release manifest, canonical policy, validation index, lifecycle gates, control surfaces, context pack, and audit witness inventory must expose the verifier boundary so it cannot become an undocumented packaging convention.
  - Embedded RO-Crate descriptor/root, hasPart, digest-bearing file entities, self-referential inventory omissions, directory entities, and exact RO_CRATE_PROFILE.md rendering must be replayed from ZIP bytes.
  - The detached verifier must replay the embedded crypto fixture index, exact Markdown companion, Ed25519 public-key keyid derivation, DSSEv1 PAE bytes, payload/signature digest rows, and positive/negative verification outcomes from ZIP bytes.
- Known limits:
  - The verifier proves the local artifact/sidecar pair, embedded inventory semantics, and embedded identity digest perimeter, not publication to an external registry or long-term mirror availability.
  - The verifier intentionally checks deterministic ZIP policy and embedded SHA-256 inventory; it does not add a new public release or widen the published payload surface.
  - Detached RO-Crate replay checks the compact bridge profile shipped by EvidenceVault; it does not claim exhaustive JSON-LD reasoning or external registry publication.
  - Detached crypto fixture replay checks the compact positive/negative fixture lane shipped by EvidenceVault; it does not claim that every historical demo signature in the archive is a positive verification obligation.
- Negative regression: Mutating the embedded positive DSSE fixture payload, signature, public key, or CRYPTO_FIXTURE_INDEX.json digest rows while refreshing embedded MANIFEST.sha256, INDEX/files.json, INDEX/files.csv, and the .zip.sha256 sidecar must make scripts/verify_release_artifact.py fail before external acceptance.
