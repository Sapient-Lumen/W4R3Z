# Migration audit notes (rev0436)

This file summarizes what EvidenceVault kept vs pruned while consolidating the older archives.

## Retained (high value)
- LaTeX/Markdown sources for all monographs and subpapers (`sources/**`).
- Schemas and canonicalization specs (`schemas/` and `sources/**/schemas`).
- Curated artifacts/certs needed to understand or replay representative examples (`artifacts/curated/`, `certs/curated/`).
- Build helpers + deterministic file inventory (`scripts/`, `INDEX/`, `MANIFEST.sha256`).
- Reproducible upstream coverage audit (`scripts/audit_upstreams.py`, `AUDIT/UPSTREAM_DIFF_REPORT.md`).

## Pruned (low value / risky / redundant)
- Obvious secrets (private keys, signing key material). Omitted paths are listed in `REDACTIONS.paths`.
- Compiled binaries and build caches (kept source instead).
- Nested upstream zips and old revision zips (upstream inputs are recorded by digest in `UPSTREAM_INPUTS.sha256`).

## Restored in this revision
- Additional **legacy PDF renders** that are easy to lose but useful for refereeing / cross-checking:
  - dOCF: `renders/legacy_pdfs/docf/pct/*.pdf` (plot bundle).
  - OCF: `renders/legacy_pdfs/ocf_llm/figs_pdf/*.pdf` (canonical retained figure bundle; exact top-level mirrors are pruned).
  - zkRTP portfolio + zkRTP v2: canonical top-level legacy paper renders under `renders/legacy_pdfs/zkrtp_portfolio/` and `renders/legacy_pdfs/zkrtp_v2/`, plus any unique remaining `paper_subpapers/*.pdf` renders once exact mirrors are pruned.
  - zkRTP portfolio acceptance repro packs: `artifacts/repro_packs/original/*.tar.gz`.

If you want EvidenceVault to be the *only* canonical store after vaulting old archives, the safest policy is:
keep all `sources/**` text sources + schemas, and keep curated figures/artifacts that are not straightforwardly regenerable.

Some curated directories now serve as compact canonical-path indexes when the retained source or cert tree already owns the exact bytes.
