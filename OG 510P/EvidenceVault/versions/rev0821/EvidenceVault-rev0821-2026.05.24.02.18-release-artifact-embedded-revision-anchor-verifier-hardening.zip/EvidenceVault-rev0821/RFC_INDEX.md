# EvidenceVault RFC index

Track bounded unresolved structural proposals that are worth preserving in more detail than one-line deferrals, while keeping them subordinate to canon, revision receipts, standing ADRs, and the assimilation ledger.

| RFC | Status | Date | Summary | Path |
| --- | --- | --- | --- | --- |
| RFC 0001 | Proposed | 2026-03-20 | Preserve a bounded proposal for a future review-ledger layer if review pressure ever outgrows the existing queue/decision/release stack, without widening published/ or creating a second canon. | `rfcs/RFC-0001-structured-review-ledger-lane.md` |
