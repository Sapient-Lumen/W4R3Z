# EvidenceVault ADR index

Track standing architecture decisions that future careful passes should treat as settled unless explicitly superseded, without turning revision receipts or startup aids into the only memory surface.

| ADR | Status | Date | Summary | Path |
| --- | --- | --- | --- | --- |
| ADR 0001 | Accepted | 2026-03-20 | Keep canonical ownership narrow and explicit so startup/control/receipt layers remain support surfaces rather than substitute canon. | `adrs/0001-canonical-ownership-split.md` |
| ADR 0002 | Accepted | 2026-03-20 | Keep published/ as a bounded frontage and require explicit queue/decision/release machinery for public-surface changes. | `adrs/0002-small-stable-public-surface.md` |
| ADR 0003 | Accepted | 2026-03-20 | Treat release-scoped snapshots plus stored digests as the historical authority for prior public releases. | `adrs/0003-immutable-release-snapshots.md` |
| ADR 0004 | Accepted | 2026-03-20 | Keep startup/control/receipt/bundle-identity/command-wrapper layers explicitly derivative or governing rather than pseudo-canon. | `adrs/0004-derivative-startup-and-control-plane.md` |
| ADR 0005 | Accepted | 2026-03-20 | Preserve older audit-batch labels when the witness basis predates the current revision, and explain the boundary instead of rewriting history. | `adrs/0005-historical-audit-label-carry-forward.md` |
