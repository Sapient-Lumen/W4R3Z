# EvidenceVault publishing operator startup

Use this checklist before creating or updating a public release.

## 1. Confirm the canonical sources
- `papers/*.tex` are the canonical papers.
- `SERIES.md` is the sole architecture statement.
- `PUBLISHING.md` is the sole public-release workflow statement.
- `CONTROL_SURFACES.json` and `LIFECYCLE_GATES.json` are the compact crosswalks for which surfaces govern the release path and where checks should fire.
- `SOURCE_INDEX.*` is the compact retained-source and family-representation map; use it before changing source-root coverage, curated mirrors, or legacy-family representation boundaries.
- `ADR_INDEX.*` records the standing structural decisions around public-surface size, release-history authority, and helper-surface status; use it before reopening those boundaries.
- `RFC_INDEX.*` preserves any bounded unresolved publishing-side proposal that was worth more than a one-line deferral but still not ready for landing.
- `ASSIMILATION_LEDGER.*` records which outside patterns were already adopted, rejected, or deferred across revisions; use it before re-litigating publishing imports.
- `AGENTS.md` and `Makefile` are the low-entropy derivative operating/command wrappers; use them for recovery and command accuracy, but do not treat them as canon.
- `REVISION_ANCHORS.json` is the compact cross-check that the current revision-bearing bundle/control surfaces still agree.

## 2. Create or locate the queue item
- Use `python3 scripts/scaffold_queue_item.py ...` for a new candidate if there is no existing queue record.
- Keep the queue item in `release_queue/candidates/` until a written decision exists.

## 3. Decide the release posture
- Is this a publish / hold / no-release pass?
- If the answer is not clearly publish, move the queue item to `release_queue/hold/` and write a decision note.

## 4. Keep the public surface small
- Only place stable, public-facing entry points under `published/`.
- Do not mirror the whole working archive into `published/`.
- Keep review renders, scratch outputs, and convenience byproducts out of the shipped tree.

## 5. Update the public surface deliberately
- Add or remove only the intended public-facing files under `published/`.
- Update `published/PUBLIC_SURFACE.json` to match.
- Add or update the paired public release note under `published/releases/`.
- Freeze one immutable public-surface snapshot under `published/releases/snapshots/`.
- Materialize the deterministic public release bundle under `published/releases/artifacts/`.

## 6. Run the release checks
Preferred compact wrapper:
```bash
make gate
make publish-audit
python3 scripts/rebuild_indexes.py
```

Expanded form:
```bash
bash scripts/build_papers.sh
python3 scripts/validate_opening_surface.py
python3 scripts/validate_source_index.py
python3 scripts/validate_adrs.py
python3 scripts/validate_rfcs.py
python3 scripts/validate_assimilation_ledger.py
python3 scripts/validate_revision_anchors.py
python3 scripts/validate_control_surfaces.py
python3 scripts/validate_archive_identity.py
python3 scripts/validate_command_runners.py
python3 scripts/build_release_queue_index.py
python3 scripts/build_release_ledger.py
python3 scripts/materialize_public_release.py
python3 scripts/validate_publishing.py
bash scripts/publish_preflight.sh
python3 scripts/rebuild_indexes.py
```

## 7. Record the decision and transition the queue item
- Write one concise note in `release_queue/decisions/` using paired `.md` and `.json` files.
- Use `publishing/templates/release_decision.md` for the markdown side.
- Move the queue item with `python3 scripts/transition_queue_item.py ...` once the decision is written.
- Use `python3 scripts/publish_queue_item.py ...` to turn one `published_ready` item into a public release and move it into `release_queue/published/`.
- `published_ready` requires a `publish` decision.
- `hold` requires a `hold` or `no-release` decision.
- `published` requires both a `publish` decision and a public release id.
- Ensure the queue item, release decision, public-surface snapshot, and public release note point to one another before shipping.

## 8. Preserve bundle identity
- Refresh `RELEASE_MANIFEST.json`, `REVISION_ANCHORS.json`, and `ARCHIVE_INDEX.*` when the named archive bundle or current revision-bearing identity changes.
- Keep `AGENTS.md`, `Makefile`, `ADR_INDEX.*`, and `RFC_INDEX.*` aligned with the governed opening and validation surfaces when the command, resumption, standing-boundary, or unresolved-proposal posture changes.
- Keep `CONTROL_SURFACES.json` and `LIFECYCLE_GATES.json` aligned when the release path or authority split changes.
- Keep `ASSIMILATION_LEDGER.*` aligned when a publishing-related outside pattern is adopted, rejected, or deferred.
- Keep `SOURCE_INDEX.*` aligned when retained source roots, their paper consumers, or curated/legacy-only family representation boundaries change.
- Treat `RELEASE_MANIFEST.json` as the one exact packaged-bundle identity surface inside the extracted archive.
- Treat `ARCHIVE_INDEX.*` as a compact recent bundle lineage aid; it complements `CHANGELOG.md` rather than replacing it.

Validation/assurance note: use `VALIDATION_INDEX.md` when you need the shortest truthful map from check targets to governed surfaces and refreshed release/build artifacts.


Note: `CURRENT_FRONTIER.*` may summarize live comparison pressure and deferred structural lanes for future archive passes, but it does not widen the public surface or change release authority.
