# Release queue item

- Date:
- Queue item id:
- State: candidate | hold | published_ready
- Scope:
- Owner:
- Decision id:
- Public release id:

## Tracked paths
- Path(s):

## Summary
State what this queue item is tracking and why it is in this state.

## Next action
State the next concrete queue transition or review action.
