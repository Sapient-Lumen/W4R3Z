# Public release

- Release ID: `EV-PUB-YYYY-MM-DD-slug`
- Date: `YYYY-MM-DD`
- Status: `published`
- Decision: `EV-REL-YYYY-MM-DD-slug`
- Queue item: `EV-QUEUE-YYYY-MM-DD-slug`
- Revision: `rev####`
- Public surface manifest: `published/PUBLIC_SURFACE.json`
- Public surface manifest sha256: `64-hex-digest`
- Public surface snapshot: `published/releases/snapshots/EV-PUB-YYYY-MM-DD-slug.surface.json`
- Public surface snapshot sha256: `64-hex-digest`

## Summary
State the public release in one concise paragraph.

## Public paths
- `published/index.md`

## Public surface snapshot
- `published/releases/snapshots/EV-PUB-YYYY-MM-DD-slug.surface.json`

## Release artifact
- `published/releases/artifacts/EV-PUB-YYYY-MM-DD-slug.zip`
- `published/releases/artifacts/EV-PUB-YYYY-MM-DD-slug.bundle.json`

## Archive note
State any important boundary between the public surface and the full working archive.
