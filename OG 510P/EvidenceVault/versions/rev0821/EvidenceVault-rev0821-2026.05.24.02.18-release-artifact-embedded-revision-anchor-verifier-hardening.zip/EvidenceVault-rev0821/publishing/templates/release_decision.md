# Release decision

- Date:
- Decision id:
- Status: publish | hold | no-release
- Scope:
- Decision owner:

## Materials
- Candidate paths:
- Public-surface paths affected:

## Reasoning
- Why this status:
- Risks / blockers:
- Follow-up needed:

## Checks
- `bash scripts/build_papers.sh`
- `python3 scripts/build_release_queue_index.py`
- `python3 scripts/build_release_ledger.py`
- `python3 scripts/materialize_public_release.py`
- `python3 scripts/validate_publishing.py`
- `bash scripts/publish_preflight.sh`
