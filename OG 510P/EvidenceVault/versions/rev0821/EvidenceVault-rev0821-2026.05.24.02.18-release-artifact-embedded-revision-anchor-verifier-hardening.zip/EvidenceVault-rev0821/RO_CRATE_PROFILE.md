# RO-Crate metadata bridge

This file is the exact human-facing companion to `ro-crate-metadata.json`.
The bridge exposes selected EvidenceVault core archive surfaces as compact JSON-LD research-object metadata without replacing `RELEASE_MANIFEST.json`, `MANIFEST.sha256`, or `INDEX/files.*` as governing inventory surfaces.

- Context: `https://w3id.org/ro/crate/1.2/context`
- Descriptor: `ro-crate-metadata.json`
- Conforms to: `https://w3id.org/ro/crate/1.2`
- Root entity: `./`
- Root version: `rev0821`
- Date published: `2026-05-24`
- Identifier: `EvidenceVault-rev0821-2026.05.24.02.18-release-artifact-embedded-revision-anchor-verifier-hardening`
- Required hasPart entries: `25`
- Digest-checked file entities: `19`

## Required root hasPart entries

- `RELEASE_MANIFEST.json`
- `REVISION_RECEIPT.json`
- `REVISION_ANCHORS.json`
- `VALIDATION_INDEX.json`
- `CLAIM_OBLIGATION_MAP.json`
- `PUBLIC_STATUS.json`
- `TOOLCHAIN_LOCK.json`
- `COMMAND_RUNNER_SEQUENCE.json`
- `SOURCE_INDEX.json`
- `ARCHIVE_INDEX.json`
- `CONTROL_SURFACES.json`
- `LIFECYCLE_GATES.json`
- `papers/EXTRACTION_MAP.json`
- `published/PUBLIC_SURFACE.json`
- `MANIFEST.sha256`
- `INDEX/files.json`
- `ev_acceptability_kernel.pdf`
- `ev_interpretation_profiles.pdf`
- `ev_streamfold.pdf`
- `ev_zkrtp.pdf`
- `ev_pact_ocf.pdf`
- `sources/`
- `artifacts/`
- `certs/`
- `published/`

## Digest-checked file entities

- `RELEASE_MANIFEST.json` — size `7557` — sha256 `f1cff374763c05440113d2e653f923a34317a84b92cb794bc9a18c83b8705776`
- `REVISION_RECEIPT.json` — size `4296` — sha256 `c60397ee932ba4ba65276109d649b11da26846826716f785f9e984a9decab276`
- `REVISION_ANCHORS.json` — size `7641` — sha256 `4fded7089c7f6895694b3ef1db887993078d618396a1bebae8b121eb639da477`
- `VALIDATION_INDEX.json` — size `59361` — sha256 `2226b091f22ac7fcdf3392512dc0464ea62b877e03078d86a5e4172be4009f7b`
- `CLAIM_OBLIGATION_MAP.json` — size `30434` — sha256 `1378f089ef5fddb3441186a9ce44acfbf5dcd572342a66c9b1bd365af8d2b624`
- `PUBLIC_STATUS.json` — size `3954` — sha256 `845ccc85b18bd3365f759c3f67ca39202d7c154cb81f430c8f22e80ba19bb575`
- `TOOLCHAIN_LOCK.json` — size `3899` — sha256 `ca1a8dad69181d485cbdcd281722f8997dc531a6fc1c74f535cc72d6fd4a5899`
- `COMMAND_RUNNER_SEQUENCE.json` — size `17807` — sha256 `b14afdc9379492c14329ed2d7be5d7601330f92a62e61ba0b763e61216e59f6a`
- `SOURCE_INDEX.json` — size `5684` — sha256 `25a857e10af643e51fbc5634646cc57111eb3e3be18f378d079cef707eb45dbe`
- `ARCHIVE_INDEX.json` — size `134060` — sha256 `21f1eb1ccfcea6edb4e25806f12326933d124d5b1b9e03a6db72b346381aca07`
- `CONTROL_SURFACES.json` — size `42701` — sha256 `e8ae9593de501d3bb95e7d24b15350a37bafab8aa22d8fb6a094a021cc8022dc`
- `LIFECYCLE_GATES.json` — size `15074` — sha256 `7182601652359e3ff83d5f52258ed2108da297f3dd6790c0d10b5490a2b81bcb`
- `papers/EXTRACTION_MAP.json` — size `18004` — sha256 `abf8e8be2708e664b61b62e49dc3d6a7506d0adaf86b569ccba27027d3a251ed`
- `published/PUBLIC_SURFACE.json` — size `1206` — sha256 `04f8aebf31f45649629c29686cf421081c93513373db253abff9541841287581`
- `ev_acceptability_kernel.pdf` — size `249005` — sha256 `665c2f68b0e3c9a43783e88aaf39ebf120f7cdd864d9d93b00b326256df0d914`
- `ev_interpretation_profiles.pdf` — size `249321` — sha256 `7e6baf39d9c64b37344d3c8ebfd03fdf5b64f4542267c8d2e5bad5a76fed1bc8`
- `ev_streamfold.pdf` — size `138610` — sha256 `c9e44fc2e390f416a6fc6dae10a09eb77bab826fe402bd323786a579dd28c0b9`
- `ev_zkrtp.pdf` — size `166145` — sha256 `e5a8d8b4c9da31c35565181a17c47adaac03a362008cbd1c5be44b4b589a4488`
- `ev_pact_ocf.pdf` — size `128134` — sha256 `14228720f27c385d3b02f26e91680c604cd47ac6c338372d65b7ebc565c5c9cf`

## Self-referential inventory entries

`MANIFEST.sha256` and `INDEX/files.json` are listed as core inventory surfaces but their own size/hash are omitted from this bridge to avoid a metadata/manifest digest cycle. Their governing verification remains `make manifest-check`.

## Directory entities

- `artifacts/`
- `certs/`
- `published/`
- `sources/`
