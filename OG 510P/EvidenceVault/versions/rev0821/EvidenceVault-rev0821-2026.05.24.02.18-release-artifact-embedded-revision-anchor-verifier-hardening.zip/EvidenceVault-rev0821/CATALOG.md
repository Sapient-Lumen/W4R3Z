# EvidenceVault archive catalog

This file owns archive lookup only.
For series architecture and reading order, see `SERIES.md`; for paper titles, see `PAPER_SERIES_INDEX.md`; for present-state extraction provenance in the uniform `from` / `kind` / `note` schema, see `papers/EXTRACTION_MAP.json`.

## Top-level layout
- `START_HERE.md` — compact maintainer / LLM bootstrap.
- `CONTEXT_PACK.json` — machine-readable orientation pack.
- `papers/` — canonical single-file TeX papers together with their compiled PDFs.
- `sources/` — retained upstream source trees shipped in full.
- `renders/legacy_pdfs/` — retained upstream renders when a family is represented by curated extracts rather than a full source tree; exact duplicate mirrors are pruned to one canonical retained path.
- `schemas/` — selected top-level schemas; fuller sets remain under retained source trees and curated artifacts.
- `certs/` — signed examples; `certs/curated/` is the publishable subset.
- `artifacts/` — curated non-secret artifacts referenced by papers; when a curated directory would otherwise be an exact mirror of a retained source or cert path, it may instead ship a compact `CANONICAL_PATHS.json` index plus any unique local files.
- `published/` — stable public-facing release surface (`index.md`, `reader_guide.md`, `artifact_request.md`, `PUBLIC_SURFACE.json`, `releases/`, and `releases/artifacts/`).
- `publishing/` — publishing control files, templates, and operator startup.
- `release_queue/` — release staging, queue items, and paired written/machine-readable decisions (`release_queue/QUEUE_INDEX.json` is the machine-readable queue-state summary).
- `scripts/` — archive maintenance helpers.
- `INDEX/` — machine-readable inventory.
- `MANIFEST.sha256` — archive checksums.
- `AUDIT/README.md` — audit-surface classification and carry-forward-label rule.

## Family source and artifact pointers

### StreamFold / dOCF
- Paper: `papers/ev_streamfold.tex`
- Curated StreamFold ABI material: `artifacts/curated/streamfold/abi_ir/`
- Curated dOCF / market examples: `artifacts/curated/docf/` (compact path index to canonical retained files under `sources/docf/`)
- Signed examples: `certs/curated/streamfold/`
- Replay packs: `artifacts/repro_packs/`
- Retained source tree: `sources/docf/`
- Legacy renders: `renders/legacy_pdfs/streamfold/`, `renders/legacy_pdfs/docf/`

### zk-RTP
- Paper: `papers/ev_zkrtp.tex`
- Curated policy / audit / correlation material: `artifacts/curated/zkrtp_v2/`
- Signed attestations and decision objects: `certs/curated/zkrtp_v2/`
- Legacy renders: `renders/legacy_pdfs/zkrtp_v2/`, `renders/legacy_pdfs/zkrtp_portfolio/` (canonical top-level legacy paper renders plus any unique subpaper-only PDFs)

### PACT / OCF
- Paper: `papers/ev_pact_ocf.tex`
- Retained source trees: `sources/pact/`, `sources/ctg/`, `sources/ocf_llm/`
- Curated replay packs and policy examples: `artifacts/curated/pact/`, `artifacts/curated/ctg/` (`artifacts/curated/ctg/` is a compact path index to `sources/ctg/`; `artifacts/curated/pact/replay_pack/` keeps only unique local files plus a path index for exact mirrors now owned by `sources/pact/` or `certs/curated/pact/`)
- Signed examples: `certs/curated/pact/`, `certs/curated/ocf_llm/`
- Additional figures/examples: `sources/pact/PACT_workdir/`, `sources/ocf_llm/examples/`; canonical retained legacy figure bundle: `renders/legacy_pdfs/ocf_llm/figs_pdf/`.

## Provenance
- `UPSTREAM.md` — upstream inputs.
- `UPSTREAM_INPUTS.sha256` — digests of the upstream zip inputs used to build this unified archive.
- `REDACTIONS.md` and `REDACTIONS.paths` — redaction policy and omitted secret-key paths.

- `published/releases/snapshots/` — immutable release-scoped public-surface snapshots
