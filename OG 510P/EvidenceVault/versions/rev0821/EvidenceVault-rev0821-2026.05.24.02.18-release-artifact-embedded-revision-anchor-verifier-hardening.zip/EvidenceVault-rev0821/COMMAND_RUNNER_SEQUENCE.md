# Command-runner sequence contract

This file is the exact human-facing companion to `COMMAND_RUNNER_SEQUENCE.json`.
The JSON contract is the governed source of truth for composite runner order; `scripts/gate.py`, `scripts/publish_audit.py`, and `scripts/package_release.py` load it rather than carrying parallel literal validator lists.

- Format: `evidencevault-command-runner-sequence`
- Revision: `rev0821`
- Previous revision: `rev0820`
- Generated at: `2026-05-24T02:18:00-0400`
- Validator: `scripts/validate_command_runners.py`
- Schema: `schemas/command_runner_sequence.schema.json`
- Package-final equals gate: `true`
- Publish-audit must not call gate: `true`

## Policy

- `bytecode_policy`: `PYTHONDONTWRITEBYTECODE=1`
- `child_interpreter`: `sys.executable`
- `cwd`: `archive_root`
- `markdown_companion`: `COMMAND_RUNNER_SEQUENCE.md`
- `package_final_must_equal_gate`: `true`
- `package_refresh_is_builder_only`: `true`
- `publish_audit_must_not_call_gate`: `true`
- `schema`: `schemas/command_runner_sequence.schema.json`
- `validator`: `scripts/validate_command_runners.py`

## Sequences

### `gate` — `scripts/gate.py`

- Make target: `gate`
- Kind: `full_gate`
- Subprocess isolation: `true`
- Steps: `38`
- Description: Full archive validation/build sequence used by make gate.

| # | Role | Script |
| ---: | --- | --- |
| 1 | `validator` | `scripts/validate_opening_surface.py` |
| 2 | `validator` | `scripts/validate_context_pack.py` |
| 3 | `validator` | `scripts/validate_makefile_surface.py` |
| 4 | `validator` | `scripts/validate_toolchain_lock.py` |
| 5 | `builder` | `scripts/build_asset_indexes.py` |
| 6 | `builder` | `scripts/build_dedupe_report.py` |
| 7 | `builder` | `scripts/rebuild_indexes.py` |
| 8 | `validator` | `scripts/validate_manifest_index.py` |
| 9 | `validator` | `scripts/validate_dedupe_report.py` |
| 10 | `validator` | `scripts/validate_json_inventory.py` |
| 11 | `validator` | `scripts/validate_text_payloads.py` |
| 12 | `validator` | `scripts/validate_text_surface_policy.py` |
| 13 | `validator` | `scripts/validate_payload_formats.py` |
| 14 | `validator` | `scripts/validate_crypto_envelopes.py` |
| 15 | `validator` | `scripts/validate_provenance_ledgers.py` |
| 16 | `validator` | `scripts/validate_filesystem_policy.py` |
| 17 | `validator` | `scripts/validate_asset_indexes.py` |
| 18 | `validator` | `scripts/validate_paper_series.py` |
| 19 | `validator` | `scripts/validate_embedded_archives.py` |
| 20 | `validator` | `scripts/validate_source_index.py` |
| 21 | `validator` | `scripts/validate_adrs.py` |
| 22 | `validator` | `scripts/validate_rfcs.py` |
| 23 | `validator` | `scripts/validate_current_frontier.py` |
| 24 | `validator` | `scripts/validate_assimilation_ledger.py` |
| 25 | `validator` | `scripts/validate_revision_anchors.py` |
| 26 | `validator` | `scripts/validate_control_surfaces.py` |
| 27 | `validator` | `scripts/validate_validation_index.py` |
| 28 | `validator` | `scripts/validate_claim_obligation_map.py` |
| 29 | `validator` | `scripts/validate_public_status.py` |
| 30 | `validator` | `scripts/validate_ro_crate_metadata.py` |
| 31 | `validator` | `scripts/validate_changelog.py` |
| 32 | `validator` | `scripts/validate_archive_index.py` |
| 33 | `validator` | `scripts/validate_historical_anomalies.py` |
| 34 | `validator` | `scripts/validate_cross_references.py` |
| 35 | `validator` | `scripts/validate_audit_witnesses.py` |
| 36 | `validator` | `scripts/validate_command_runners.py` |
| 37 | `validator` | `scripts/validate_archive_identity.py` |
| 38 | `validator` | `scripts/validate_publishing.py` |

### `publish_audit` — `scripts/publish_audit.py`

- Make target: `publish-audit`
- Kind: `bounded_release_audit`
- Subprocess isolation: `true`
- Steps: `24`
- Description: Bounded release-materialization and post-refresh validation sequence; intentionally does not call the full gate wrapper.

| # | Role | Script |
| ---: | --- | --- |
| 1 | `builder` | `scripts/build_release_queue_index.py` |
| 2 | `builder` | `scripts/build_release_ledger.py` |
| 3 | `materializer` | `scripts/materialize_public_release.py` |
| 4 | `builder` | `scripts/build_asset_indexes.py` |
| 5 | `builder` | `scripts/build_dedupe_report.py` |
| 6 | `builder` | `scripts/rebuild_indexes.py` |
| 7 | `validator` | `scripts/validate_context_pack.py` |
| 8 | `validator` | `scripts/validate_makefile_surface.py` |
| 9 | `validator` | `scripts/validate_toolchain_lock.py` |
| 10 | `validator` | `scripts/validate_manifest_index.py` |
| 11 | `validator` | `scripts/validate_dedupe_report.py` |
| 12 | `validator` | `scripts/validate_changelog.py` |
| 13 | `validator` | `scripts/validate_archive_index.py` |
| 14 | `validator` | `scripts/validate_historical_anomalies.py` |
| 15 | `validator` | `scripts/validate_claim_obligation_map.py` |
| 16 | `validator` | `scripts/validate_public_status.py` |
| 17 | `validator` | `scripts/validate_ro_crate_metadata.py` |
| 18 | `validator` | `scripts/validate_text_surface_policy.py` |
| 19 | `validator` | `scripts/validate_embedded_archives.py` |
| 20 | `validator` | `scripts/validate_cross_references.py` |
| 21 | `validator` | `scripts/validate_audit_witnesses.py` |
| 22 | `validator` | `scripts/validate_command_runners.py` |
| 23 | `validator` | `scripts/validate_publishing.py` |
| 24 | `validator` | `scripts/validate_archive_identity.py` |

### `package_refresh` — `scripts/package_release.py`

- Make target: `package-release`
- Kind: `package_refresh`
- Subprocess isolation: `true`
- Steps: `3`
- Description: Generated-index and scoped inventory refresh run before package-final validation and ZIP emission.

| # | Role | Script |
| ---: | --- | --- |
| 1 | `builder` | `scripts/build_asset_indexes.py` |
| 2 | `builder` | `scripts/build_dedupe_report.py` |
| 3 | `builder` | `scripts/rebuild_indexes.py` |

### `package_final_validators` — `scripts/package_release.py`

- Make target: `package-release`
- Kind: `package_final_gate_equivalent`
- Subprocess isolation: `true`
- Steps: `38`
- Description: Package-final validation sequence; must remain byte-for-byte equivalent to the full gate sequence.

| # | Role | Script |
| ---: | --- | --- |
| 1 | `validator` | `scripts/validate_opening_surface.py` |
| 2 | `validator` | `scripts/validate_context_pack.py` |
| 3 | `validator` | `scripts/validate_makefile_surface.py` |
| 4 | `validator` | `scripts/validate_toolchain_lock.py` |
| 5 | `builder` | `scripts/build_asset_indexes.py` |
| 6 | `builder` | `scripts/build_dedupe_report.py` |
| 7 | `builder` | `scripts/rebuild_indexes.py` |
| 8 | `validator` | `scripts/validate_manifest_index.py` |
| 9 | `validator` | `scripts/validate_dedupe_report.py` |
| 10 | `validator` | `scripts/validate_json_inventory.py` |
| 11 | `validator` | `scripts/validate_text_payloads.py` |
| 12 | `validator` | `scripts/validate_text_surface_policy.py` |
| 13 | `validator` | `scripts/validate_payload_formats.py` |
| 14 | `validator` | `scripts/validate_crypto_envelopes.py` |
| 15 | `validator` | `scripts/validate_provenance_ledgers.py` |
| 16 | `validator` | `scripts/validate_filesystem_policy.py` |
| 17 | `validator` | `scripts/validate_asset_indexes.py` |
| 18 | `validator` | `scripts/validate_paper_series.py` |
| 19 | `validator` | `scripts/validate_embedded_archives.py` |
| 20 | `validator` | `scripts/validate_source_index.py` |
| 21 | `validator` | `scripts/validate_adrs.py` |
| 22 | `validator` | `scripts/validate_rfcs.py` |
| 23 | `validator` | `scripts/validate_current_frontier.py` |
| 24 | `validator` | `scripts/validate_assimilation_ledger.py` |
| 25 | `validator` | `scripts/validate_revision_anchors.py` |
| 26 | `validator` | `scripts/validate_control_surfaces.py` |
| 27 | `validator` | `scripts/validate_validation_index.py` |
| 28 | `validator` | `scripts/validate_claim_obligation_map.py` |
| 29 | `validator` | `scripts/validate_public_status.py` |
| 30 | `validator` | `scripts/validate_ro_crate_metadata.py` |
| 31 | `validator` | `scripts/validate_changelog.py` |
| 32 | `validator` | `scripts/validate_archive_index.py` |
| 33 | `validator` | `scripts/validate_historical_anomalies.py` |
| 34 | `validator` | `scripts/validate_cross_references.py` |
| 35 | `validator` | `scripts/validate_audit_witnesses.py` |
| 36 | `validator` | `scripts/validate_command_runners.py` |
| 37 | `validator` | `scripts/validate_archive_identity.py` |
| 38 | `validator` | `scripts/validate_publishing.py` |
