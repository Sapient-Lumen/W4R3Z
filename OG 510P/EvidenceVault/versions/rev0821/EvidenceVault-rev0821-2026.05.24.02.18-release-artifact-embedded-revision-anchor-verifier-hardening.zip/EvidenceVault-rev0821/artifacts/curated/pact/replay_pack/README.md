# PACT replay-pack path index

This directory keeps only the unique replay-pack files that are not duplicated elsewhere; exact mirrors now resolve to canonical retained source or cert paths through the index below.

The original mirrored upstream README is retained canonically at `sources/pact/PACT_workdir/replay_pack/README.md`.

Canonical retained paths for the removed exact mirrors:

- `abom.json` -> `sources/pact/PACT_workdir/replay_pack/abom.json`
- `abom_verdict_receipt.dsse.json` -> `certs/curated/pact/PACT_workdir/replay_pack/abom_verdict_receipt.dsse.json`
- `abom_view_one_object.json` -> `sources/pact/PACT_workdir/replay_pack/abom_view_one_object.json`
- `abom_view_two_objects.json` -> `sources/pact/PACT_workdir/replay_pack/abom_view_two_objects.json`
- `abom_vsa.dsse.json` -> `certs/curated/pact/PACT_workdir/replay_pack/abom_vsa.dsse.json`
- `keys.json` -> `sources/pact/PACT_workdir/replay_pack/keys.json`
- `manifest.json` -> `sources/pact/PACT_workdir/replay_pack/manifest.json`
- `policy_decision.dsse.json` -> `certs/curated/pact/PACT_workdir/replay_pack/policy_decision.dsse.json`
- `policy_profile.json` -> `sources/pact/PACT_workdir/replay_pack/policy_profile.json`
- `ppp_run_root.dsse.json` -> `certs/curated/pact/PACT_workdir/replay_pack/ppp_run_root.dsse.json`
- `sdjwt_view_multi_all_payload.sdjwt` -> `sources/pact/PACT_workdir/replay_pack/sdjwt_view_multi_all_payload.sdjwt`
- `sdjwt_view_multi_no_payload.sdjwt` -> `sources/pact/PACT_workdir/replay_pack/sdjwt_view_multi_no_payload.sdjwt`
- `sdjwt_view_multi_one_payload.sdjwt` -> `sources/pact/PACT_workdir/replay_pack/sdjwt_view_multi_one_payload.sdjwt`
- `sdjwt_view_multi_pubkey.json` -> `sources/pact/PACT_workdir/replay_pack/sdjwt_view_multi_pubkey.json`
- `sdjwt_view_no_payload.sdjwt` -> `sources/pact/PACT_workdir/replay_pack/sdjwt_view_no_payload.sdjwt`
- `sdjwt_view_pubkey.json` -> `sources/pact/PACT_workdir/replay_pack/sdjwt_view_pubkey.json`

Unique files still retained locally in this directory:

- `sdjwt_view_with_payload.sdjwt`
- `store/sha256_9cc6a58ac06495164c1c7607bbe14da588e7f0a53203c6b917a856f407b0f26d.json`
- `store/sha256_ed04df9b1d818bf0c29ccaf2115dbd6823b0ba754ca91c5af79cea0759e7d877.json`
- `transcript.json`
