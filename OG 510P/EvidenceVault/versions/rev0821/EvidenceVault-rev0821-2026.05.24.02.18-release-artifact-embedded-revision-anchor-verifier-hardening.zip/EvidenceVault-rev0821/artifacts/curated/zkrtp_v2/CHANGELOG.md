## v2.00 (2026-02-28)

- **New flagship paper:** added `paper/paper_receipt_bound_governance.tex`, proposing *receipt-bound governance objects* (RBGOs): a digest-addressed join key that binds (i) transport-invariant bundle pointers (canon v2), (ii) JCS governance-record digests (RFC 8785), and (iii) optional contract digests (e.g., correlation budgets) and transparency anchors (Rekor v2 / SCITT receipts).
- **Pointer paper updated:** `paper/paper_transparent_pointers.tex` bumped to v2.00; updated to consume regenerated v2.00 conformance/path-safety/benchmark tables and to position RBGOs as the next-layer join primitive.
- **Correlation contracts updated:** `paper/paper_correlation_contracts.tex` bumped to v2.00 and now treats contracts as hashable objects designed to be referenced from pointers/RBGOs.
- **Regenerated evidence artifacts:** ran cross-implementation canon suite (v2), path-safety negative controls, microbenchmarks, and disagreement CI table to keep `paper/generated/` consistent with the new version tag.
- **New example generator:** added `scripts/rbgo_example.py` to produce `audit/rbgo_example_v2_00.json` and `paper/generated/rbgo_example_v2_00.tex` used by the new paper.

## v1.97 (2026-02-28)

- **Strengthened transport-invariant pointers paper:** expanded `paper/paper_transparent_pointers.tex` with (i) explicit attacker games, (ii) a two-layer diagram, (iii) a new canonical-digest microbenchmark table generated from archive scripts, and (iv) tighter mapping to Sigstore/SCITT (including Rekor v2 and the SCITT CCF receipts profile).
- **New benchmark artifact:** added `scripts/bundlecanon_benchmark.py` and its outputs `audit/bundlecanon_benchmark_v1_97.json` + `paper/generated/tab_bundlecanon_benchmark.tex`.
- **Risky standalone split:** added `paper/paper_correlation_contracts.tex` (correlation-constrained multi-proof contracts narrative) reusing existing correlation figures from the archive.
- **Notes update:** added `notes/assistant_notes_v1_97.md` with next-step bets and reviewer-risk register.


## v1.96 (2026-02-28)

- **New paper split (unified pointer-drift story):** added `paper/paper_transparent_pointers.tex`, which unifies canonical bundle digests, governance records (RFC 8785 / JCS), and locator drift resistance (v3) into a single, submission-shaped draft.
- **Conference draft tightening:** `paper/paper_execassurance.tex` now explicitly calls out (v2) digest-set bindings and (v3) locator drift resistance in the headline contributions.
- **Version bump:** updated repo version markers (`README.md`, `CURRENT_DOCUMENTS.md`, `paper/paper.tex`) to v1.96.

## v1.91 (2026-02-28)

- Add a stdlib-only **Go** proof-closure verifier (`verifier_go/`) for cross-implementation auditing of the bundle closure invariant.
- Add a deterministic cross-implementation suite (`scripts/cross_impl_closure_suite.py`) that generates a 1-bit tampered bundle and checks agreement between Python and Go verifiers.
- Add new generated paper tables: `paper/generated/cross_impl_closure_conformance.tex` and `paper/generated/cross_impl_benchmark_table.tex`.
- Update papers (`paper_execassurance`, `paper_metaconformance`, `paper_proofclosure`) to include the new tables and cite ``trusting trust'' / DDC motivation.

## v1.90 — 2026-02-28

- **Portability index (new metric + generator):** added a lightweight, reproducible metric for "how offline" a decision artifact is.
  - New tools: `scripts/portability_index.py` and `scripts/render_portability_index_table.py`.
  - Generates `audit/portability_index_stackA_renewal_v1_90.json` and `paper/generated/portability_index_table.tex`.
  - Reports coverage of locally-committed inputs by a bundle (replay vs. proof-closure), plus bundle sizes.
- **Metamorphic governance paper split (new LaTeX draft):** added `paper/paper_metaconformance.tex`, a risky, submission-shaped paper that treats negative controls + metamorphic relations as a first-class security surface for socio-technical governance.
- **Conference draft strengthened:** `paper/paper_execassurance.tex` now (i) formalizes omission/substitution/equivocation attacker games more explicitly and (ii) reports the portability index alongside existing closure-bundle conformance.
- **Tables regenerated:** refreshed `audit/conformance_suite_report.json`, `paper/generated/tab_*conformance.tex`, and `paper/generated/tab_bundle_verify_benchmark.tex` from scripts to keep the archive self-consistent.


## v1.87 — 2026-02-28

- **Signed governance record pointers:** governance records may now include optional Ed25519 JWS (compact) signatures over `record_digest.value` (JWS/EdDSA) to add an authenticity layer for the loggable pointer object.
  - New tool: `scripts/govrec_jws.py`.
  - Example: `audit/governance_record_stackA_renewal_signed_v1_87.json` + test-only keys under `audit/testkeys/`.
  - `scripts/decision_verifier.py` supports `--pubkey` and `--require-signature` when verifying `--record`.
- **Self-referential digest rule tightened:** `record_digest` is now defined as `sha256(JCS(record_without_record_digest_and_signatures))` so adding/verifying signatures does not change the canonical digest.
  - Updated in `scripts/governance_record.py`, `scripts/decision_verifier.py`, and the record schema.
- **Conformance suite bugfix + extension:** the conformance runner dispatch map now includes the governance-record digest cases (previously defined but not executed) and adds signature tamper negative controls.
  - Regenerated `audit/conformance_suite_report.json` and `paper/generated/tab_governance_record_conformance.tex`.
- **Paper wiring:** executive-assurance, proof-closure, and decision-object drafts now document signed governance records and cite JWS/EdDSA RFCs.


## v1.89 — 2026-02-28

- **Draft unification + positioning:** bumped draft headers to v1.89 and strengthened the main-paper overview + the conference-style executable-assurance draft to foreground \emph{portable decision artifacts} (policy proofs, proof-closure bundles, governance records) as first-class contributions.
- **Archive hygiene:** refreshed repo-level version markers (`README.md`, `CURRENT_DOCUMENTS.md`) and added an assistant-maintained research/plan note under `notes/` to track submission-grade paper splits and next experiments.


## v1.86 — 2026-02-28

- **Governance record digest:** governance records may now include `record_digest = sha256(JCS(record_without_record_digest))` (RFC 8785) to make the *pointer itself* stable and loggable across whitespace/key-order changes.
  - Implemented in `scripts/governance_record.py` (default on) and verified in both `scripts/governance_record.py verify` and `scripts/decision_verifier.py --record`.
  - New concrete record: `audit/governance_record_stackA_renewal_v1_86.json`.
- **Conformance suite extended:** added record-digest negative controls:
  - `GOVREC-RECORD-DIGEST-MISMATCH-FAIL`
  - `GOVREC-RECORD-METADATA-TAMPER-FAIL` (demonstrates why record_digest exists; would pass without the digest check)
- **Paper wiring:** executive-assurance and proof-closure drafts now describe record-level canonicalization and cite RFC 8785.


## v1.85 — 2026-02-28

- **Governance record pointer:** added `scripts/governance_record.py` and a concrete record `audit/governance_record_stackA_renewal_v1_86.json` (format `zk-rtp-governance-record/v1`) that binds a proof-closure bundle zip and the decision-object DSSE by sha256.
- **Small-TCB verifier extension:** `scripts/decision_verifier.py` now supports `--record` to verify the governance record (bundle sha256 + optional statement sha256) and then run receipt integrity + proof-closure checks.
- **Conformance suite extended:** added governance-record tamper vectors and implemented them in `scripts/conformance_runner.py`:
  - `GOVREC-VERIFY-OK`
  - `GOVREC-BUNDLE-SHA-MISMATCH-FAIL`
  - `GOVREC-STATEMENT-SHA-MISMATCH-FAIL`
  - `GOVREC-ZIP-PATH-MISSING-FAIL`
- **Suite bump + regen:** conformance suite bumped to `version: 0.1.10` and `audit/conformance_suite_report.json` regenerated.
- **New generated paper tables:**
  - `scripts/render_governance_record_conformance_table.py` → `paper/generated/tab_governance_record_conformance.tex`
  - `scripts/render_bundle_verify_benchmark_table.py` → `paper/generated/tab_bundle_verify_benchmark.tex`
- **Paper wiring:** `paper/paper_execassurance.tex` and `paper/paper_proofclosure.tex` include the governance-record conformance table and the bundle verification micro-benchmark table.

## v1.84 — 2026-02-28

- **Closure-bundle sufficiency conformance vectors:** added four cases to `audit/conformance_suite_cases.json` and implemented them in `scripts/conformance_runner.py` via the stdlib-only `scripts/decision_verifier.py`:
  - `BUNDLE-VERIFY-OK`
  - `BUNDLE-RECEIPT-TAMPER-FAIL`
  - `BUNDLE-CLOSURE-DIGEST-MISMATCH-FAIL`
  - `BUNDLE-STATEMENT-MISMATCH-FAIL`
- **Generated table for papers:** added `scripts/render_closure_bundle_conformance_table.py` producing `paper/generated/tab_closure_bundle_conformance.tex`.
- **Papers strengthened:** `paper/paper_execassurance.tex` and `paper/paper_proofclosure.tex` now state a sufficiency theorem and include the conformance table.
- **Suite bump + regen:** conformance suite bumped to `version: 0.1.9` and `audit/conformance_suite_report.json` regenerated.

## v1.83 — 2026-02-28

## v1.83 (Feb 28, 2026)
- Added `scripts/decision_verifier.py` (stdlib-only): verifies bundle receipt integrity, optional proof-closure, optional DSSE decision-object binding.
- Added `scripts/bundle_verify_benchmark.py` + generated benchmark report for StackA renewal proof-closure bundle.
- Added a signed StackA renewal decision object (`audit/decision_object_stackA_renewal_v1_83.dsse.json`) and verification report.
- Updated LaTeX drafts to include measured artifact sizes and verifier commands.

- **Proof-closure availability lint:** added `scripts/proof_closure_lint.py` (stdlib-only) to check that a proof-closure bundle contains every locally-committed `file_sha256` digest referenced by the stapled policy proof.
- **Paper wiring:** updated the audit replay recipe (`paper/sections/sec12_reproducible-audit-recipe-how-to-replay-a-decision.tex`) and the print-and-audit appendix (`paper/sections/app01_print-and-audit-stapled-decision-bundle.tex`) to include `proof_closure_lint.py` as a small-TCB verifier step.
- **Draft hygiene fix:** moved stray content that was accidentally placed after `\end{document}` in `paper/paper_execassurance.tex` and `paper/paper_proofclosure.tex` into proper in-document sections.
- **Bibliography normalization:** ensured `sigstore_bundle_format` points to the canonical Sigstore bundle documentation URL.

## v1.81 — 2026-02-28

- **Bundle verifier tightening:** `scripts/stapled_bundle.py verify` gained `--verify-policy-proof` to optionally run `policy_proof_verify` against a (closure) bundle extracted from zip, catching missing committed inputs early.
- **New attestation bridge:** added `scripts/stapled_bundle_attest.py` to emit an in-toto Statement (and optional DSSE envelope) for a stapled bundle zip, binding a portable offline bundle into standard supply-chain attestation plumbing.
- **Citation fix:** corrected `ef_zkevm_realtime_proving_roadmap_2026` bib entry to the live Ethereum Magicians roadmap thread (previous link 404’d).
- **Paper refresh:** updated `paper_execassurance` + `paper_proofclosure` to reference the new verifier/attestation pathway and to clarify the distinction between replay-minimal bundles vs proof-closure bundles.

## v1.79 (2026-02-27)
- **New conference-oriented draft:** added `paper/paper_execassurance.tex`, a shorter cross-domain narrative that reframes ZK-RTP certificates as \emph{executable assurance cases} for cryptographic online services.
  - Centers three ``non-negotiables'': semantics binding (ABIs), fail-closed evaluation, and replayable decision records suitable for transparency logging.
  - Pulls metamorphic governance into the main spine: treat evaluator (checker+policy) correctness as an attack surface.
- **Metadata bump:** updated LaTeX headers and `CURRENT_DOCUMENTS.md` to v1.79.

## v1.77 (2026-02-27)
- **Typed policy DSL bug fix (fail-closed missing):** `scripts/policy_dsl_typed.py` now treats missing fields as *worst-case* under each field's declared polarity (e.g., better=higher missing => -∞), closing a subtle "improvement by omission" hole for min-threshold checks.
- **New monotonicity checker:** `scripts/policy_dsl_typed_monotonicity.py` composes typed weakening witnesses (`evidence_preorder_typed`) with typed policy evaluation to enforce the contract: `accept(E_weak) ⇒ accept(E_strong)` whenever `E_weak \preceq E_strong` is verified.
- **New CI vectors:** conformance suite bumped to v0.1.7 with three cases:
  - `POLICY-DSL-TYPED-MISSING-FAILCLOSED` (missing min-threshold metric must REJECT)
  - `POLICY-DSL-TYPED-MONOTONICITY-OK` (verified weakening cannot improve acceptance)
  - `POLICY-DSL-TYPED-MONOTONICITY-INVALID` (must fail if "weak" is not a verified weakening)
- **New policy artifacts:** `policies/typed_policy_schema_latency_contract.json`, `policies/typed_policy_latency_contract.json`, plus demo evidence mutations under `audit/`.
- **Regenerated outputs:** reran `scripts/conformance_runner.py`, regenerated `paper/generated/conformance_suite_table.tex`, and added monotonicity reports under `audit/`.

## v1.76 (2026-02-27)
- Added typed evidence-weakening profiles (upper/lower bounds) with derivation witnesses and CI vectors.
- New script: `scripts/evidence_preorder_typed.py`, new schema: `schemas/evidence_weakening_profile.schema.json`, and demo profile under `profiles/`.
- Conformance suite expanded with typed-preorder cases; main paper Clause E and Evidence Calculus note updated accordingly.

## v1.75 — 2026-02-27

- **Evidence preorder checker:** added `scripts/evidence_preorder.py` implementing an executable approximation of Clause~E's evidence-weakening preorder (supports key deletion, list subsetting, and `<MISSING>` sentinels).
- **Conformance suite v0.1.5:** added two sanity cases:
  - `EVID-PREORDER-DROP-OK` (dropping an evidence item is a valid weakening)
  - `EVID-PREORDER-EDIT-FAIL` (editing committed digests is not a weakening)
- **New standalone paper:** added `paper/paper_evidencecalc.tex` (evidence calculus connecting PCC + authorization logics + metamorphic conformance).
- **Regenerated suite outputs:** reran `scripts/conformance_runner.py` and regenerated `paper/generated/conformance_suite_table.tex`.

## v1.74 — 2026-02-27

- **Clause-F policy gate:** added `scripts/policy_gate.py` (fail-closed composition of timeliness evidence + non-equivocation scan) and example policies under `policies/`.
- **Gate reports + renderer:** generated `audit/policy_gate_report_accept.json` plus two negative controls (stale timeliness; split view), and added `scripts/render_policy_gate_example_table.py` to render `paper/generated/policy_gate_example_table.tex`.
- **Conformance suite v0.1.4:** added two CI-grade metamorphic cases: `POLICY-GATE-TIMELINESS-STALE` and `POLICY-GATE-SPLITVIEW`.
- **New standalone paper:** added `paper/paper_clauseF.tex` to package Clause~F + policy gates + conformance relations.

## v0.8 — 2026-02-27

- **Clause F (timeliness + non-equivocation):** added a main-paper clause that formalizes SET/MMD promises and witness-threshold checkpoints as portable evidence objects for offline replay.
- **Timeliness evidence object:** added `schemas/timeliness_evidence.schema.json` and `scripts/timeliness_evidence.py`; generated passing and failing example artifacts under `audit/`.
- **Conformance suite v0.1.3:** fixed `scripts/conformance_runner.py` to execute all declared cases (including `TRACE-DIGEST-MISMATCH` and `TIMELINESS-SET-STALE`) and added `PTH-SPLITVIEW-DETECT` split-view negative control.
- **Equivocation scan fix:** repaired `scripts/pth_equivocation_scan.py` to support unverified parsing when operator keys are omitted.

# Changelog


## v1.72 (2026-02-27)

- **New standalone RTP-ABI paper:** added `paper/paper_rtpabi.tex` (schema-validated orchestration ABI + trace-bound invariants + metamorphic conformance).
- **RTP-ABI JSON Schema + validator:** added `schemas/rtp_abi.schema.json` and `scripts/validate_rtp_abi.py` (strict on required semantics fields; permissive on extras).
- **Conformance suite extended:** bumped suite to v0.1.2 and added two high-leverage cases:
  - `ABI-SCHEMA-REQUIRED` (required-field deletion must invalidate ABI)
  - `MONITOR-OMISSION-DETECT` (join-keyed monitor trace omission must be detectable vs orchestration trace)
- **Conformance suite expanded again:** added two new negative controls:
  - `TRACE-DIGEST-MISMATCH` (tampered orchestration trace must fail digest-statement verification)
  - `TIMELINESS-SET-STALE` (stale SET/MMD timeliness promise must fail verification)
- **Main paper case studies:** integrated correlation stress sweep artifacts (Table `rtp-corr-sweep` + Figure `rtp-corr-sweep-plot`) and linked timeliness stapling to the conformance suite.
- **New citations:** added gRPC request hedging docs (`grpc_request_hedging`) and sharp asymptotic time-uniform confidence sequences (`cs_sharp_asymptotic_2025`).
- **Bibliography hygiene:** de-duplicated the cancel-on-completion Queueing Systems 2026 reference (single key: `queueing_coc_2026`).
## v1.70 (2026-02-27)

- **New standalone liveness paper:** added `paper/paper_liveness.tex` (Clause~D: redundancy, cancellation ABIs, and regenerative/busy-cycle certification).
- **New correlation stress artifacts:** added `scripts/build_rtp_corr_sweep_artifacts.py` and generated `paper/figures/corr_sweep_plot.pdf` + `paper/generated/rtp_corr_sweep_table.tex`.
- **Main paper:** Clause~D now highlights hedging/cancellation as an ABI surface and cites redundancy-with-cancellation stability literature.
- **Bibliography:** appended references for redundancy-d stability, redundancy stability survey, cancel-on-completion redundancy (Queueing Systems 2026), and gRPC request hedging.

## v1.69 (2026-02-27)

- **New standalone paper:** added `paper/paper_execmon.tex` (execution-justified benchmarking: trace-bound monitor outputs + transparency receipts + timeliness promises).
- **New runnable demo:** added `scripts/execmon_demo.py` (generates a complete evidence chain under `audit/execmon_demo/`).
- **Main paper:** updated Overview Contributions to explicitly call out execution-justified monitoring (anti-cherry-picking via trace commitments + receipts).
- **Versioning + build targets:** bumped drafts to v1.69 and updated `CURRENT_DOCUMENTS.md` build commands (now includes Clause~E + ExecMon).

## v1.68 (2026-02-27)

- **New standalone Clause~E paper:** added `paper/paper_clauseE.tex` (metamorphic governance evaluation) and `paper/sections/sec03_conservatism_excerpt.tex` (self-contained conservatism contract + monotonicity theorem).
- **Clause~E strengthened with policy-engine testing precedent:** added citation to Cedar’s verification-guided build process (model proofs + differential random testing + property-based testing) to motivate Clause~E’s CI-first posture (`cedar_vgd_2024`).
- **Clause~B freshness:** cited a new sharp asymptotic time-uniform confidence-sequence construction (`gnnettner_kirch_cs_2025`).
- **Versioning + pointers:** bumped drafts to v1.68 and updated `CURRENT_DOCUMENTS.md` build targets.



## v1.66 (2026-02-27)

- **Executable conformance suite:** added `scripts/conformance_runner.py` to run the Appendix A2 metamorphic cases and emit a machine-checkable report (`audit/conformance_suite_report.json`).
- **Trace digest canonicalization hooks:** extended `scripts/orchestration_trace.py` with `--drop-field/--drop-fields` so profiles can declare certain keys (e.g., worker/replica ids) non-semantic and exclude them from the digest.
- **OpenVEX exposure mapping (optional):** added `scripts/openvex_exposure.py` and a minimal monotone delta map (`policies/delta_sys_map_vex.yaml`), used by the conformance suite’s VEX fail-closed case.














## v1.62 (2026-02-27)

- **Paper (Sec13):** rewrote research directions into a substantive section: calibration ledgers for $\delta_{\mathrm{sys}}$, semantics-drift adversary model, horizon declarations for anytime-valid monitors, scheduler ABIs for fork--join quorum proving, privacy-preserving trace commitments, mechanized soundness rows, and an interoperability roadmap.
- **Paper (Sec01/Sec10):** added a contributions list in the Overview and Algorithm~\ref{alg:eval} summarizing fail-closed evaluation and replayable policy-proof issuance.
- **Refs:** annotated CycloneDX spec entry with current version (v1.7) and release date.

## v1.65 (2026-02-27)

- **Profiles appendix:** added a concrete anti-backdating/timeliness paragraph to the receipt-bundle profile and added a new, auto-rendered conformance suite excerpt table.
- **Artifacts:** added `audit/conformance_suite_cases.json` and `scripts/render_conformance_suite_table.py`.

## v1.61 (2026-02-27)

- **Paper:** expanded conclusion; strengthened composition with explicit fail-closed fallback semantics; clarified $\delta_{\mathrm{sys}}$ as governance-selected with overlap as evidence; clarified policy-gated trace status; reframed OntoGSN export as optional interoperability; strengthened Clause~E (metamorphic rationale + limitations).

## v1.60 (2026-02-27)

- **Assurance-case export:** added `scripts/cert_to_ontogsn.py` to compile certificates into a GSN/OntoGSN-shaped JSON graph (goals/strategies/solutions + open-obligation frontier) and `scripts/render_ontogsn_export_table.py` to render a paper table from the committed export.
- **Paper:** integrated the assurance-case export as a first-class interoperability story in \S\ref{sec:cert-semantics} and added Table~\ref{tab:ontogsn-export-example}.

## v1.59 (2026-02-27)

- **Governance fuzzing:** extended `scripts/gov_fuzz.py` with stage-aware evaluation and stapled-proof mutation cases (strip proof pointer, swap to wrong-stage proof, corrupt proof SHA); regenerated `audit/gov_fuzz_report.json` and the paper table (`paper/generated/gov_fuzz_example.tex`).
- **Paper:** updated abstract wording and related work with dynamic assurance-case management (OntoGSN) and new anytime-valid theory (always-valid inference + Ville generalization).
- **Refs:** refreshed SCITT architecture draft metadata (datatracker last updated 2026-02-24) and added new BibTeX entries for OntoGSN (arXiv:2506.11023), Always Valid Inference (arXiv:1512.04922), and the Ville generalization (arXiv:2502.16019).

## v1.58 (2026-02-27)

- **Policy proofs:** upgraded `scripts/policy_proof.py` to a self-reference-safe stapling format (`zk-rtp-policy-proof/v3`) by committing to a canonical *core certificate* digest (`cert_core_json_v1`) that strips stapled pointers (e.g., `policy_proofs`).
- **Verification:** updated `scripts/policy_proof_verify.py` to support per-label digest modes (file hash vs core-cert digest) and to recompute under the proof’s stage context and declared meta-stripped gates.
- **Stage-aware governance demo:** added an interpreted stage-profile policy (`policies/example_policy_staged.yaml`) and generated a concrete stapled renewal example (`audit/policy_proof_stackA_renewal.json`, `schemas/example_cert_stackA_wp_pass_stapled.json`).
- **Paper:** updated the policy-proof semantics section and the reproducible audit recipe to document core-digest stapling and stage-profile replay commands.

## v1.56 (2026-02-27)

- **Paper:** added a staged maturity ladder pattern (Approve / Renew / Production) and integrated it into Clause A as a concrete governance recommendation.
- **Tooling:** extended `scripts/policy_eval.py` with an optional `requirements.min_architecture_whitepaper_phase` gate (W1/W2/W3), fail-closed on missing/unknown phases.
- **Audit workflow:** tightened \S\ref{sec:audit-replay} to start from a stapled offline bundle (`scripts/stapled_bundle.py verify --zip ... --recompute`) and regenerated `audit/stapled_bundle_example.zip`.
- **Citations:** unified SCITT CCF receipts citations to a single BibLaTeX key (`draft_ietf_scitt_receipts_ccf_profile`).

## v1.55 (2026-02-27)

- **Paper:** added an explicit sensitivity subsection (Clause C) showing when dependence-envelope choices matter versus when the systemic-delta floor dominates; included an auto-generated table + plot.
- **Tooling:** added `scripts/render_correlation_sensitivity.py` and generated `paper/generated/correlation_sensitivity.tex` + `paper/figures/correlation_sensitivity.pdf`.

## v1.51 (2026-02-26)

- **Paper:** added a new scope-laundering case study subsection and summary table connecting concrete drift moves (measurement censoring, orchestration cancellation/retry drift, evidence suppression) to ZK-RTP tripwires.
- **Tooling:** added a stdlib-only metamorphic check for Clause C systemic-delta derivations (`scripts/delta_sys_monotone_check.py`); committed demo artifacts (`correlation/delta_sys_missing_overlap.json`, `audit/delta_sys_missing_overlap_monotone_report.json`).
- **Attack suite:** added tests for ABI semantic drift (SemVer-major trigger via `audit/rtp_abi_diff_report.json`) and overlap-evidence omission (monotone delta check); regenerated `paper/generated/attack_suite_example.tex`.

## v1.50 (2026-02-26)

- **Paper:** expanded the “Why now” paragraph with EF’s explicit security/proof-size milestones (M1/M2/M3) and the Security Sprint’s architecture-whitepaper deliverable framing.
- **Paper:** added an evidence-tier→envelope mapping table (E0–E3) to make dependence-envelope selection policy-explicit in Clause C.
- **Paper:** added a light-verifier replay algorithm for offline policy-proof replay from a stapled bundle.
- **Paper:** added an appendix with concrete stapled-bundle excerpts (bundle receipt + policy-proof header) to support “print-and-audit” workflows.
- **Refs:** added a citation entry for the EF Cryptography Team’s zkVM architecture whitepaper requirements PDF.

## v1.49 (2026-02-26)

- **Paper:** added a “verifier roles + minimum offline bytes” table in the stapled-profile section, grounded in committed bundle artifacts.
- **Paper:** added a dependence evidence checklist table in Clause C to make independence evidence actionable beyond SBOM overlap.
- **Paper/Citations:** fixed the soundcalc paragraph to cite the canonical zkEVM Security Sprint February update key.
- **Refs:** updated the Ethproofs “Killers” URL to the canonical working route (`/killer`).
- **Pointers:** updated `CURRENT_DOCUMENTS.md` to v1.49.

## v1.48 (2026-02-26)

- **Paper:** added a governance reader map table (Approve / Renew / Revoke) clarifying which clauses answer which decision.
- **Paper:** fixed a LaTeX structure issue where the RTP target→clauses table accidentally wrapped subsequent text (clean float boundaries).
- **Paper:** removed the duplicated pipeline figure and unified references to the single canonical figure in the Overview.
- **Paper:** added a brief Non-goals / limitations paragraph to clarify what certificates do — and do not — guarantee.
- **Pointers:** updated `CURRENT_DOCUMENTS.md` to v1.48.

## v1.47 (2026-02-26)

- **Paper:** added an **Overview** section (post-abstract) with the pipeline figure + an explicit “artifact-of-record” framing.
- **Paper:** reordered clause sections to match the lettered story (**A → B → C → D**) for readability.
- **Citations:** added EF repricings Part 1 (2025-12-17), EF zkEVM security sprint Feb update (2026-02-11), and the public `eth-act/zkevm-benchmark-runs` repository; refreshed in-text citations to use the new anchors.
- **Pointers:** updated `CURRENT_DOCUMENTS.md` to v1.47.


## v1.46 (2026-02-26)

- **Paper:** added a concrete running-example section with two schematized listings: (i) a minimal certificate skeleton highlighting hash-committed ABIs/evidence and fail-closed triggers/obligations, and (ii) the emitted policy-proof decision record suitable for transparency logging.
- **Paper:** formalized the conservatism contract (evidence weakening preorder + monotone, fail-closed evaluation theorem) to make the anti-gaming guarantee explicit.
- **Notes:** updated `paper/notes.md` with research anchors (EF RTP + security foundations; SCITT/COSE receipts; CT v2; Sigstore/Rekor) and a high-risk next-steps plan.
- **Pointers:** updated `CURRENT_DOCUMENTS.md` to v1.46.


## v1.45 (2026-02-26)

- **Paper:** tightened the Motivation and Contributions to foreground the “real-time proving as an online service” framing and compress contributions into five high-signal items.
- **Notes:** updated `paper/notes.md` to match the new narrative focus and edit plan.
- **Pointers:** updated `CURRENT_DOCUMENTS.md` to v1.45.


## v1.43 (2026-02-26)

- **Portable timeliness bundles:** extended SCITT-style trace transparent statements to optionally staple a SET promise (as a third receipt) and added an offline verifier enforcing (statement signature ∧ inclusion receipt ∧ witnessed checkpoint ∧ SET/MMD).
- **Negative-control bundle:** added a backdated-SET stapled statement to demonstrate MMD failure even when inclusion+checkpoint receipts verify.
- **Paper:** added a new paragraph and auto-rendered table (`paper/generated/orch_trace_timely_bundle_verify_example.tex`) showing fresh vs stale SET-stapled bundles.
- **Citations refresh:** updated the COSE Merkle Tree Proofs draft citation to version -18 (published 2025-12-02).


## v1.42 (2026-02-26)

- **Evidence omission resistance:** added Signed Evidence Timestamp (SET) promises (CT-style) for execution-evidence statements, plus an offline MMD checker with a stale-promise negative control; integrated into the paper with an auto-generated table.
- **Citations refresh:** updated COSE Merkle Tree Proofs draft citation to the latest published version; added SCITT Reference APIs (SCRAPI) draft citation.

## v1.41 (2026-02-26)

- Added receipt-backed monitor↔orchestration consistency attestations: the PASS/FAIL report is bound by digest to its inputs (join-keyed monitor trace, orchestration trace, and monitor-binding statement) and published as a SCITT-style transparent statement with inclusion and witnessed-checkpoint receipts.
- Extended the orchestration trace evidence log (tree size 4) with the consistency attestation and regenerated inclusion receipts and OTCH checkpoint receipts so stapled evidence remains consistent with the latest root.
- Integrated an auto-rendered paper table (`paper/generated/monitor_orch_consistency_scitt_statement_example.tex`) and narrative motivating “non-omittable audits”.
- Bumped paper header to Draft v1.41.

## v1.40 (2026-02-26)

- Added join-keyed monitor↔orchestration trace consistency checking (`scripts/monitor_orch_consistency.py`) and fixture generator (`scripts/gen_monitor_join_trace.py`) producing PASS/FAIL reports under deliberate omission.
- Added an auto-rendered paper table (`paper/generated/monitor_orch_consistency_example.tex`) and integrated a new paragraph explaining how join keys make anti-cherry-picking checks fully mechanical.
- Fixed monitor-binding LaTeX table generators to emit correct row terminators (\\) to avoid compilation instability.
- Bumped paper header to Draft v1.40.

## v1.39 (2026-02-26)

- Added a monitor-binding statement (`scripts/monitor_binding_statement.py`) that cryptographically binds a monitor trace + dataset to the Measurement ABI hash (semantics) and to the orchestration trace-digest statement under the same RTP ABI hash.
- Wrapped the monitor-binding statement as a SCITT-style transparent statement with stapled COSE receipts (`audit/monitor_binding_transparent_statement.cose` + meta) for offline-verifiable monitoring evidence.
- Extended the orchestration trace evidence log with the monitor-binding statement as an additional leaf (tree size 3) and regenerated inclusion receipts, the OTCH checkpoint receipt, and the trace-digest transparent statement so stapled receipts remain consistent.
- Added a new paper subsection “Execution-justified monitoring: binding monitor outputs to trace evidence” plus Lemma `lem:anti-cherrypick` and two auto-rendered tables.
- Bumped paper header to Draft v1.39.

## v1.38 (2026-02-26)

- Added a split-view equivocation demo for the orchestration trace log: stateful witness cosigning prevents conflicting checkpoints for the same tree size (`scripts/orch_trace_splitview_demo.py`) and commits the resulting artifacts under `audit/`.
- Added an auto-rendered LaTeX table (`paper/generated/orch_trace_splitview_demo.tex`) and integrated it into the paper.
- Added Theorem `thm:execution-non-equivocation` and narrative tying Trace ABI receipts to split-view resistance via witnessed checkpoints.
- Bumped paper header to Draft v1.38.

## v1.37 (2026-02-26)

- Added Trace ABI: deterministic orchestration trace digests, trace transparency log, COSE inclusion receipts, witness-cosigned OTCH checkpoints, and SCITT-style transparent statements.
- Integrated trace evidence tables into the paper; updated abstract and contributions to highlight non-equivocating execution evidence.


## v1.36 — 2026-02-26

- **Paper (new claim surface):** added 	extbf{orchestration traces as enforceable evidence} in the RTP ABI section (\S~\ref{sec:orch-traces}), arguing that ABI commitments should map to \emph{checkable} scheduler-trace invariants and can be stapled/logged via the same receipt mechanisms.
- **Artifacts:** added `audit/orchestration_trace_checks_example.json` and an auto-rendered paper table (`paper/generated/orchestration_trace_checks_example.tex`) listing concrete invariants for cancellation, retry caps, dedup, and deadline semantics.
- **ABI transparency demo refreshed:** updated the RTP ABI example to include 	extbf{retry semantics} (policy + attempt cap + reassignment + dedup), regenerated the ABI log, inclusion proof, witnessed ABH, COSE receipts, SCITT-style transparent statement, and stapled-certificate example so hashes/proofs remain consistent.
- **Code:** added `scripts/render_rtp_abi_example_table.py` to keep the example ABI table consistent with the JSON and hash; extended ABI log reporting and rendering to surface retry policy; treated `$.orchestration.retry` as a breaking-change prefix in `scripts/rtp_abi_diff.py`; clarified `max_attempts` interpretation in `docs/rtp_abi_spec.md`.

## v1.34 — 2026-02-26

- **Paper (ecosystem integration):** bumped the draft header to v1.34 and incorporated the zkEVM team's **zkVM Standards v0** release as the canonical reference for the zkVM-guest boundary (RV64IM+Zicclsm target ISA; C APIs for precompiles and guest I/O), positioning ZK-RTP as the complementary standardization layer for governance-facing *evidence artifacts*.
- **Bibliography:** added a bib entry for the standards-v0 release post (`zkevm_zkvm_standards_v0_2026`) and refreshed access dates for a small set of ecosystem anchors.

## v1.33 — 2026-02-25

- **Paper (monitor recency / anti-replay):** added a new paragraph and auto-rendered table formalizing \textbf{monitor attestations as timestamped evidence of observation}, with enforceable freshness constraints and subject digest binding (signature-only is insufficient). Added citation to RFC~3161 timestamping.
- **Artifacts:** committed verifier reports for a fresh attestation, a stale attestation (negative control), and a digest-mismatch mutation (negative control): `audit/monitor_attestation_verify_report_freshness_*.json`.
- **Code:** strengthened `scripts/monitor_attest.py` (freshness + digest checks), upgraded `scripts/certified_decision.py` to accept these policy knobs, added `scripts/monitor_freshness_demo.py` and `scripts/render_monitor_freshness_table.py`.
- **Adversarial suite:** added replay/freshness tests (`ATK-PTH-MONITOR-FRESHNESS-*`) and regenerated the example report/table.

## v1.32 — 2026-02-25

- **Paper (timeliness hardening):** expanded the timeliness invariant into a concrete *attack taxonomy* (delayed publication, equivocation windows, stale monitoring, clock-skew/future-dating) and positioned these as Clause~A obligation triggers and Clause~E negative controls.
- **Artifacts:** added a committed **future-skew** receipt-chain variant and verifier report (`audit/chain/receipt_chain_future_skew*.json`) and updated the auto-rendered timeliness table to compare timely/tardy/future-skew chains.
- **Code:** extended `scripts/receipt_chain.py make-demo` to generate a checkpoint issued *before* the proof timestamp and added `ATK-LOG-FUTURE-SKEW-FAIL` to the adversarial test suite.

## v1.31 — 2026-02-25

- **Paper (governance receipts):** added a new anti-backdating invariant: \textbf{timeliness} as a first-class, machine-checkable constraint on receipt chains (proof-generated time vs. checkpoint issuance time), with citations to Certificate Transparency MMD and supply-chain transparency receipts.
- **Artifacts:** committed timely/tardy chain variants and verifier reports under `audit/chain/` plus an auto-rendered LaTeX table (`paper/generated/receipt_chain_timeliness_example.tex`).
- **Code:** added `scripts/receipt_chain.py` support for timeliness gates, and `scripts/render_receipt_chain_timeliness_table.py` renderer.
- **Fixes:** corrected LaTeX table row terminators and fixed renewal-chain table label/caption so cross-references compile cleanly.

## v1.30 — 2026-02-25

- **Paper (Clause B):** strengthened the **Measurement ABI (M-ABI)** contribution by making it *enforceable*: added a mutation-style negative-control table (auto-rendered from committed artifacts) and positioned M-ABI governance alongside classic benchmark run-rule precedents (SPEC/MLPerf) and metamorphic testing.
- **Artifacts:** committed self-consistent good/bad benchmark-run Statements, verifier outputs, and allowlist policy reports under `audit/` (see `audit/measurement_mutation_suite_report.json`).
- **Code:** extended `scripts/benchmark_run_attest.py` with `--measurement-abi` + deterministic timestamps; added `scripts/verify_benchmark_run_statement.py`, `scripts/measurement_mutation_suite.py`, and a LaTeX table renderer.
- **Policy:** added M-ABI allowlist hooks to `scripts/policy_eval.py` and added example policy/certificates (`policies/example_policy_with_mabi.yaml`, `schemas/example_certificate_mabi*.json`).
- **Monitoring:** extended `scripts/rtp_monitor.py` with optional M-ABI timeout/missing semantics and report embedding.

## v1.29 — 2026-02-25

- **Paper (Clause B/D):** added a new subsection on **Measurement ABIs (M-ABI)** to prevent *silent harness drift* (timeout censoring, missing-record policies, and start/stop semantics), with an auto-generated demo table and figure.
- **Artifacts:** added `audit/measurement_drift_demo_report.json`, `benchmarks/example_latency_with_timeouts.jsonl`, `paper/generated/measurement_drift_demo_table.tex`, and `paper/figures/measurement_drift_demo.pdf`.
- **Code:** added `scripts/measurement_drift_demo.py`, `scripts/measurement_abi_hash.py`, and renderers for the paper table/figure; added reference ABIs in `rtp/measurement_abi_*.json` and documentation `docs/measurement_abi_spec.md`.
- **Schema:** extended the certificate schema with optional `measurement_abi` commitment metadata.

## v1.28 — 2026-02-25

- **Paper (case study):** strengthened the Ethproofs dashboard narrative by compiling a small, hash-committed trajectory snapshot into an auto-rendered table (`tab:ethproofs-snapshot`) so that public claims become diffable artifacts rather than prose.
- **Artifacts:** added `audit/ethproofs_metrics_snapshot_2025.json` and renderer `scripts/render_ethproofs_snapshot_table.py`; committed `paper/generated/ethproofs_snapshot_table.tex`.
- **Docs:** bumped archive version markers (README/paper header/notes).

## v1.27 — 2026-02-25

- **Paper (Clause B):** added a new subsection on **risk ledgers** (statistical error budgeting as a first-class, replayable governance object) and an optional subsection on **e-BH (FDR) risk-sharing** for multi-stream monitoring, with new figure/table.
- **Artifacts:** added `audit/risk_ledger_example.json` + verifier report and auto-rendered Table `tab:risk-ledger-example`; added `audit/ebh_demo.json` plus renderers and committed `paper/figures/ebh_demo_tradeoff.pdf` and `paper/generated/ebh_demo_table.tex`.
- **Code:** added `scripts/verify_risk_ledger.py`, `scripts/risk_ledger_demo.py`, and risk-ledger schema `schemas/zk_rtp_risk_ledger.schema.json`; added e-BH demo scripts and renderers.
- **Bibliography:** added Wang & Ramdas (JRSSB 2022) for e-BH / FDR control with e-values.

## v1.26 — 2026-02-25

- **Paper (Clause B):** added a new subsection on **selection inflation across multiple stacks**, including a conservative union-bound/Ville guarantee that splitting $\alpha$ across stacks ($\alpha/N$ per stack) restores an overall $\le \alpha$ false-trigger bound; integrated a new figure/table and cited the stopped e-BH filtration-hygiene subtlety.
- **Artifacts:** added `scripts/multistack_selection_demo.py` and renderers; committed `audit/multistack_selection_demo_report.json`, `paper/figures/multistack_selection_false_trigger.pdf`, and `paper/generated/multistack_selection_demo_table.tex`.
- **Docs:** bumped archive version markers (README/paper header/notes).


## v1.25 — 2026-02-25

- **Paper (Clause B):** added an auditor-facing optional-stopping (“peeking”) demo subsection with committed figure/table.
- **Artifacts:** added `scripts/peeking_demo.py` plus plot/table renderers; committed `audit/peeking_demo_report.json`, `paper/figures/peeking_demo_false_positive.pdf`, and `paper/generated/peeking_demo_table.tex`.


## v1.24 — 2026-02-25

- **Paper:** clarified framing as an *executable assurance case*; added a compact threat-to-clause mapping table and an auditor-facing conservative checker algorithm box.
- **Docs:** bumped archive version markers (README/paper header/notes).


## v1.23 (2026-02-24)

- **Anytime-valid outage scan (Clause D+++++++):** added a changepoint-mixture e-process scan monitor with a time-uniform Ville guarantee under the dependence-tolerant null `P(Y_t=1|F_{t-1})<=q0`.
- **O(1) update + stdlib tooling:** added `scripts/rtp_scan_eprocess.py` (O(1) per step via `L_t,A_t`) and `scripts/render_rtp_scan_eprocess_table.py`, plus committed example report/table.
- **Paper + bibliography:** integrated Theorem `thm:scan-eprocess` and the example table; added arXiv references for e-detectors and change-detection via confidence sequences.

## v0.8 — 2026-02-24

- **Anytime-valid CS plumbing fixed (Clause D adaptive contracts):** the adaptive run/window monitors now actually honor `--cs {hoeffding,exact,stitched,mixture}` (previously Hoeffding was used regardless of the flag).
- **New beta-mixture (“betting”) CS:** added a time-uniform beta-mixture CS option (`--cs mixture --cs-a --cs-b`) via inversion of a beta-mixture test martingale (Ville).
- **Paper: new proposition + cleanup:** fixed a nested-theorem bug in the confidence-sequence appendix and added Proposition `prop:beta-mixture-cs`. Added the missing Theorem `thm:adaptive-streak`. Updated CS comparison table to include `U_t^{mix}`.
- **Artifacts refreshed:** regenerated `paper/generated/rtp_cs_comparison_example.tex` with the new mixture column.


## v1.21 (2026-02-24)

- Added **peeled exact binomial (Clopper–Pearson) CS** and integrated `--cs exact` into Clause-D tools.
- Added **polynomial stitching CS** (`--cs stitched`) with audit-friendly defaults (`s=2`, ζ(2)=π^2/6), based on Howard et al. / confseq.
- Added **CS comparison artifact** (JSON + LaTeX table) and integrated it into the paper.
- Updated streak boundary statement to allow adaptive dependence under conditional-miss upper bounds.

## v1.19 (2026-02-24)
- Add robust (adversarial-dependence) window boundary option via Azuma--Hoeffding; paper adds Proposition for assumption-minimal window contracts.
- Update window boundary scripts to accept --model (iid|adversarial) and --bound (exact|kl|azuma); reports now record model/bound.
- Update LaTeX renderers for window/adaptive-window tables to include model/bound columns; regenerate example artifacts.
- Bump paper and notes to v1.19.

## v1.18 (2026-02-24)
- Add witness cosigning bundle artifact + scripts + paper table for suppression-resistant Clause-D decisions.
- Add references for transparency.dev witness network and C2SP tlog-witness protocol.



## v1.17 (2026-02-24)
- **Transparency bundle receipt:** added `scripts/rtp_transparency_bundle.py` to emit `rtp_transparency_bundle/v1` committing to the canonical DSSE digest and reserving fields for Rekor/SCITT-style receipts and inclusion proofs.
- **Paper integration:** added an auto-rendered transparency bundle table and a paragraph describing stapling log receipts to renewal/safe-mode decisions.
- **LaTeX fix:** corrected the attestation table renderer to typeset $\alpha_D$ in math mode (compilation + readability).

## v1.16 (2026-02-24)
- **Clause-D contract attestation:** added `scripts/rtp_clauseD_contract_attest.py` to package a unified Clause-D liveness contract report as an in-toto Statement and optional DSSE envelope.
- **Paper integration:** added an auto-rendered attestation table for the Clause-D contract bundle, making liveness triggers loggable/non-repudiable like other governance receipts.

## v1.15 (2026-02-24)
- **Exact window (scan) tails:** upgraded window-boundary monitors to support exact Binomial survival tails (default), with optional KL-Chernoff fallback for speed.
- **Adaptive contract rule clarified:** fixed the paper definition of \(\kappa_t\) to match the code (choose the *tightest still-justified* grid contract).
- **Unified Clause-D contract bundle:** added `scripts/rtp_clauseD_contract.py` + renderer + committed example report/table; paper includes Theorem for the unified trigger under a single \(\alpha_D\) split.

## v1.14 (2026-02-24)
- **Clause D++++ window (scan) contract:** added a time-uniform rolling-window boundary that limits the number of quorum misses in the last $m$ slots (a discrete scan-statistic style contract), complementing streak-based burst limits.
- **Clause D+++++ adaptive window contract:** added Theorem (union-of-contracts) that tightens the window boundary over time using a certified miss-rate confidence sequence, without sacrificing anytime validity.
- **New scripts:** added `scripts/rtp_window_boundary.py` and `scripts/rtp_adaptive_window_boundary.py`, plus LaTeX renderers and committed example reports/tables.
- **Paper + bibliography:** bumped to v1.14, integrated both window contracts, and added references for scan statistics and Chernoff/KL concentration.

## v1.13 (2026-02-24)
- **Clause D+++ adaptive burst contract:** added Theorem (union-of-contracts) that combines an anytime-valid miss-rate confidence sequence with a pre-declared grid of streak boundaries, enabling *tightening* burst limits over time without invalidating anytime guarantees.
- **New scripts:** added `scripts/rtp_adaptive_run_boundary.py` (monitor) and `scripts/render_rtp_adaptive_run_boundary_table.py` (LaTeX renderer), plus a committed example report/table.
- **Paper:** bumped to v1.13 and integrated the adaptive burst contract + example tables.

## v1.12 (2026-02-24)
- **Clause D++ streak boundary:** added a time-uniform run-length boundary for consecutive quorum misses (burst-limited liveness) with a one-line peeled-union proof.
- **New scripts:** added `scripts/rtp_run_boundary.py` (monitor) and `scripts/render_rtp_run_boundary_table.py` (LaTeX renderer), plus a tiny benchmark stream and committed example report/table.
- **Paper + bibliography:** integrated the streak boundary + example table in Clause D and added classical longest-run references (Schilling 1990; Kopoci\'nski 1991).


## v1.11 (2026-02-24)
- **Time-uniform liveness debt:** added Proposition (peeled Hoeffding confidence sequence) and a composition-level paragraph showing how to certify cumulative missed-quorum counts without committing to a fixed horizon.
- **New script:** added `scripts/anytime_hoeffding_cs.py` to emit a conservative, auditor-friendly upper confidence sequence for Bernoulli miss/exceedance rates (Hoeffding + peeling).
- **Paper:** bumped to v1.11.


## v1.09 (2026-02-24)
- **Gossip/monitor model for policy-transition heads:** added `scripts/pth_gossip_sim.py` + `scripts/render_pth_gossip_plot.py` to model split-view detection via push gossip when quorum intersection does not prevent equivocation.
- **New paper figure:** committed `paper/figures/pth_gossip_detection_prob.pdf` and integrated it as Figure~
\ref{fig:pth-gossip-detect}.
- **Bibliography:** added CTv2 (draft-ietf-trans-rfc6962-bis) and verifiable CT monitoring (Dahlberg--Pulls 2017) references.
- **Paper:** updated to v1.09 and expanded the policy-evolution section to explicitly separate prevention (quorum intersection) from detection (gossip/monitors), treating monitor attestations as governance evidence when $2t\le n$.

## v1.07 (2026-02-24)
- **Goalpost integrity (SCITT workflow):** added a dedicated policy-transition transparency log and a SCITT-style transparent statement for policy transitions, stapling (i) a draft-aligned COSE inclusion receipt and (ii) a witness-cosigned checkpoint receipt (PTH).
- **Witnessed policy heads (PTH-in-COSE):** added `scripts/cose_pth_receipt.py` to create and verify witness-cosigned transition-log checkpoints with nested receipts (header label 394), enabling offline verifiers to enforce witness thresholds.
- **Paper:** updated to v1.07 and added a new paragraph + auto-rendered table (Table~\ref{tab:policy-transition-scitt}) demonstrating policy-transition transparent statements as a monitorable defense against silent coefficient drift.
- **Verifier report hygiene:** PTH verifier JSON output is now JSON-safe (no raw bytes-valued CBOR maps).


## v1.08 (2026-02-24)
- **Split-view (equivocation) drill for policy evolution:** added `scripts/policy_transition_splitview_drill.py` to generate two conflicting policy-transition log views and corresponding witness-threshold-valid PTH receipts.
- **Equivocation scanner:** added `scripts/pth_equivocation_scan.py` and a worked failing report `audit/pth_equivocation_scan_report_example.json`; auto-rendered to `paper/generated/pth_equivocation_example.tex`.
- **Consistency proofs for policy-transition log:** `scripts/policy_transition_log.py` now supports RFC~9162-style consistency proofs and verification, enabling renewal-style checkpoint updates for policy evolution.
- **COSE Merkle receipt correctness:** fixed detached-payload signing/verification so detached payloads sign the intended Merkle-root bytes (not CBOR null).
- **Paper:** updated to v1.08 and added a lemma formalizing quorum intersection ($2t>n$) plus a negative-control split-view example table.



## v1.06 (2026-02-24)
- **Sensitivity contract attestation:** added `scripts/sensitivity_contract_attest.py` to package the sensitivity grid + figure as an in-toto Statement (optional DSSE), producing `attestations/sensitivity_contract_acceptcase.{statement,dsse}.json`.
- **Policy transition receipts:** added `scripts/policy_transition_attest.py` + `scripts/render_policy_transition_table.py` to bind old/new policy digests, rationale, and references to a sensitivity contract; committed `attestations/policy_transition_acceptcase_v1.06.{statement,dsse}.json` and generated table `paper/generated/policy_transition_acceptcase_v1.06.tex`.
- **Tightened accept-case policy:** added `policies/certified_decision_acceptcase_v1.06.yaml` (missed-deadline coefficient 10000→14000) plus a regenerated decision report `audit/certified_decision_report_acceptcase_v1.06.json` and decision attestation `attestations/certified_decision_acceptcase_v1.06.{statement,dsse}.json`.
- **Paper:** updated to v1.06 and added a new paragraph + proposition formalizing goalpost integrity via signed, loggable coefficient-update transitions (SCITT/Rekor/CT-aligned).

## v1.05 (2026-02-24)
- **Decision sensitivity contract:** added `scripts/decision_sensitivity_grid.py` + `scripts/render_decision_sensitivity_plot.py` to compute and render acceptance regions over loss coefficients from a certified decision report; committed `audit/decision_sensitivity_acceptcase.json` and paper figure `paper/figures/decision_sensitivity_acceptcase.pdf`.
- **Signed certified decisions:** added `scripts/certified_decision_attest.py` (in-toto Statement + optional DSSE envelope) and `scripts/render_certified_decision_attestation_table.py`; committed attestation artifacts for the accept case and a generated paper table.
- **Paper:** updated to v1.05, added a sensitivity paragraph + figure for certified decisions, and documented certified-decision attestations as loggable governance statements.

## v1.04 (2026-02-24)
- **Certified decisions (multi-horizon semantics):** catastrophic-security risk is now configurable per *security event* (e.g., per-upgrade) via `horizon.security.unit/events`, decoupled from the liveness/energy block horizon; defaults remain backwards compatible.
- **Accept-case evidence bundle:** added disjoint SBOMs, distinct manifests, a bug-class exposure report, and a monotone fail-closed $δ_{sys}$ map with a residual floor, yielding an end-to-end passing certified-decision demo.
- **Paper:** added a second certified-decision table (accept case) and an explicit explanation of why horizon semantics are the hinge between reject vs accept.
- **Tooling:** `multiproof_eval` recomputation consumes optional `bugclass_report_ref` when present; `render_certified_decision_table.py` now renders security unit/events.

## v1.03 (2026-02-24)
- **Certified decision tooling:** added `scripts/certified_decision.py` + `scripts/render_certified_decision_table.py` to compute and render a certified upper bound on worst-case expected governance loss from Clause A/C/D/B artifacts.
- **Paper:** integrated an auto-generated worked example table generated from `audit/certified_decision_report_example.json`.
- **Repo artifacts:** added a decision YAML spec (`policies/certified_decision_example.yaml`) and generated report + LaTeX include under `paper/generated/`.

## v1.02 (2026-02-24)
- **Paper (assurance cases):** added an explicit assurance-case framing (claim–argument–evidence) with citations to ISO/IEC 15026-2, safety-case practice, and OMG SACM.
- **Paper (decision semantics):** added a certified-decision acceptance rule based on bounding worst-case expected governance loss (maxmin / ambiguity-averse), plus a risk-limiting audit analogy for sequential evidence.
- **Paper (Clause E):** added a coverage-contract subsection for governance mutation testing (deletion/downgrade/scope-laundering operator families) and tied the approach to mutation-testing literature and NIST assurance-case tooling survey.
- **Bibliography:** added references for assurance cases (ISO/IEC 15026-2), structured assurance case metamodel (SACM), maxmin expected utility, mutation testing, risk-limiting audits, and the push0 proof-orchestration system (arXiv:2602.16338).

## v1.01 (2026-02-24)
- **Paper:** added a clause “at-a-glance” table summarizing A--E claim surfaces and evidence objects; expanded case-study text to interpret committed monitor/queue tables.
- **Bibliography:** upgraded “Anytime validity is free” to the JRSSB Series B published version (DOI: 10.1093/jrsssb/qkag050) and added Andrews–Chen “Certified Decisions” as governance decision framing.

## v1.00 (2026-02-23)
- **Paper (security + verifier):** added Lemma on nested-receipt witness-threshold soundness and a concrete offline verifier algorithm for ABI SCITT transparent statements stapling inclusion + ABH-in-COSE receipts.
- **Adversarial negative control:** committed a failing verification artifact for a transparent statement with insufficient witness cosignatures (captures the fail-closed error signal as JSON).
- **Attack suite:** added `ATK-ABI-WITNESS-THRESHOLD` to the red-team governance suite and regenerated the paper table.
- **Repo utility:** added `scripts/capture_cmd.py` to record expected failures as small diffable JSON artifacts.

## v0.99 (2026-02-23)
- **ABH-in-COSE receipts:** added `scripts/cose_abh_receipt.py` to encode ABI-log checkpoints as operator-signed COSE_Sign1 with nested witness cosignatures under header label 394.
- **Transparent statement upgrade:** `scripts/scitt_abi_statement.py` now staples both an inclusion receipt and a witnessed checkpoint receipt; verification enforces a witness threshold.
- **Paper + docs:** updated the SCITT paragraph, regenerated `paper/generated/rtp_abi_scitt_statement_example.tex`, and expanded `docs/scitt_abi_statement.md`.
## v0.98 (2026-02-23)
- **SCITT LaTeX fix:** regenerated `paper/generated/rtp_abi_scitt_statement_example.tex` with correct LaTeX row breaks and `\texttt{}` escaping (fixes a hard `\midrule`/`\noalign` compilation error).
- **Fresh draft citations:** updated the SCITT transparent-statement paragraph to cite the current SCITT architecture draft and the COSE receipts draft section that registers header parameter `receipts` (394) and requires receipts to be tagged `COSE_Sign1`.
- **Build verified:** confirmed a deterministic `pdflatex → biber → pdflatex×2` build completes with the SCITT artifact table enabled.
## v0.97 (2026-02-23)
- **SCITT-style ABI publication:** added COSE-based transparent statements for RTP ABIs via `scripts/scitt_abi_statement.py` (Signed Statement + embedded COSE receipts under header label 394).
- **COSE receipts for ABI log:** added `scripts/cose_abi_merkle_receipt.py` to emit/verify inclusion receipts over the ABI transparency log using the COSE merkle-tree proof data model.
- **Paper + artifacts:** extended the RTP ABI section with a SCITT paragraph and generated example table `paper/generated/rtp_abi_scitt_statement_example.tex`; committed example `.cose` artifacts and verification JSON under `audit/`.
- **Docs:** added `docs/scitt_abi_statement.md` with a reproducible workflow.

## v0.96 (2026-02-23)
- **ABI stapling for offline audits:** extended `schemas/zk_rtp_certificate.schema.json` with optional `rtp_abi_staple`, which can embed the ABI payload + inclusion proof + witness-cosigned ABI head (ABH) directly in the certificate.
- **Artifacts + examples:** added `schemas/example_certificate_abi_stapled.json` and `audit/rtp_abi_staple_example.json` demonstrating a complete stapled ABI bundle.
- **Verifier + paper:** added `scripts/rtp_abi_staple_verify.py` (fail-closed offline stapled-bundle verification) and a new generated table `paper/generated/rtp_abi_staple_example.tex` referenced in the RTP ABI section.

## v0.95 (2026-02-23)
- **Witness-cosigned ABI heads (ABH):** added `scripts/abh_witness.py`, a minimal signed-checkpoint + witness-cosign workflow for the ABI transparency log, mirroring the policy-head witness design.
- **Artifacts:** committed a reproducible ABH example (`audit/abi_checkpoint_example.json`, `audit/abh_example.json`, `audit/abh_example_witnessed.json`) and a LaTeX renderer (`scripts/render_rtp_abi_head_table.py`) that produces Table `paper/generated/rtp_abi_head_example.tex`.
- **Docs + paper:** extended `docs/rtp_abi_transparency_log.md` with the ABH workflow and added the witnessed ABH table to the RTP ABI governance section in the paper.

## v0.94 (2026-02-23)
- **RTP ABI transparency log:** added `scripts/abi_log.py`, a minimal CT-style Merkle log over canonical RTP ABI objects (domain-separated leaves), plus committed example artifacts (`audit/rtp_abi_log.jsonl`, root report, inclusion proofs).
- **ABI drift classification:** added `scripts/rtp_abi_diff.py` (semantic diff + conservative breaking/nonbreaking classification + SemVer bump recommendation) and renderers that produce LaTeX tables for the paper.
- **Paper:** extended the RTP ABI section with an ABI-log snapshot and an ABI-diff example; ties ABI governance to SemVer and tile-based transparency log ecosystems.

## v0.93 (2026-02-23)
- **Bibliography:** added missing references used by the paper (Denning lattice IFC; CP-ABE; Saltzer--Schroeder principles; Zeller--Hildebrandt delta debugging; Ethproofs learn/resources; TUF spec; CT RFC 6962; COSE algorithms RFC 9053; RFC 9864; Trillian; and robust risk-aggregation papers).
- **Paper (ABI drift):** introduced a formal RTP-ABI definition near the certificate semantics and framed `rtp_abi_hash` mismatch as an explicit deployment attack surface (silent orchestration changes).
- **Paper (COSE):** noted RFC 9864 deprecating polymorphic COSE algorithm identifiers and added it as a citation.

## v0.92 (2026-02-23)
- **RTP ABI tooling:** added `scripts/rtp_abi_hash.py` plus a concrete ABI example (`audit/rtp_abi_example.json` and `audit/rtp_abi_example_hash.txt`) to make the `rtp_abi_hash` commitment reproducible.
- **Schema:** extended `schemas/zk_rtp_certificate.schema.json` with an optional `rtp_abi` object (parallel to `transcript_abi`) for machine-checkable operational semantics.
- **Paper:** fixed RTP-ABI LaTeX formatting, added an example RTP ABI commitment table, added RFC 8785 to the bibliography, and updated the Ethproofs roadmap citation to the canonical HackMD post.
- **Spec:** clarified numeric encoding guidance in `docs/rtp_abi_spec.md` (avoid floating-point; prefer integer microseconds/watts or decimal strings).

## v0.91 (2026-02-23)
- **Paper (RTP ABI):** introduced an explicit RTP ABI concept (slot spacing, deadlines, cancellation/preemption, measurement boundaries) and treated ABI-hash changes as breaking reissues.
- **Paper (Clause D++):** emphasized cancellation semantics as a first-class, attestable parameter that can dominate quorum liveness under overload.


## v0.90 (2026-02-23)
- **Paper (audit UX):** added an ``Auditor walk-through'' subsection with two offline, one-command verification paths: (i) verify a minimal stapled bundle (hashes + recomputed policy decision) and (ii) verify a signed COSE governance bundle (outer signature + embedded receipt chain + witness checkpoints).
- **Paper (Clause D++):** added a new empirical CDF figure showing how cancel-on-quorum vs no cancellation changes the quorum completion-delay distribution, miss rate, and compute envelope on the committed multi-stack queue benchmark.
- **Artifacts:** added `paper/figures/multiproof_cancel_ecdf.pdf` generated from `benchmarks/example_multistack_queue_2k.jsonl` using the same simulation code as the Clause D++ queue monitor.

## v0.89 (2026-02-23)
- **Paper:** added an explicit end-to-end composition theorem that composes Clause A (per-stack soundness), Clause C (systemic-mixture correlation envelope), and Clause D/D+ (quorum liveness) into per-slot and finite-horizon bounds.
- **Paper:** added a queue-amplification figure derived from the committed benchmark stream to show how rare service-time spikes inflate end-to-end waiting times under slot arrivals.
- **Citations:** filled missing references and refreshed a few URLs for SSDF, SLSA, and anytime-valid inference.

## v0.88 (2026-02-23)
- **Paper:** tightened the contributions section to be shorter and more publishable; updated date/version.
- **Citations:** updated SLSA reference to v1.2 and added citations for NIST SSDF and COSE RFC 9052; added a foundational reference for anytime-valid martingale-based inference.

## v0.87 (2026-02-22)
- **Activation receipts (timelock):** added `scripts/policy_activation_receipt.py` to generate deterministic activation reports + compact COSE\_Sign1 receipts that bind a patch report digest to a `not_before` timestamp.
- **Budget heads with timelock gating:** extended `scripts/policy_budget_head.py` to verify and embed an optional activation receipt; the checkpoint now surfaces an `activation` state and fails closed with `timelock_pending` until activation.
- **Paper:** updated the budgeted policy heads subsection to introduce staged rollout windows and updated the auto-rendered table to show `PENDING` when activation is delayed.

## v0.86 (2026-02-22)
- **Waiver receipts:** added `scripts/waiver_receipt.py` to generate deterministic waiver reports + compact COSE\_Sign1 receipts that pin waiver scope (patch/policy digests) and expiry, making exceptions auditable and portable.
- **Budget heads with waivers:** extended `scripts/policy_budget_head.py` to verify and embed an optional waiver; the checkpoint verdict now separates the raw budget result from the effective (waived) result.
- **Paper:** updated the budgeted policy heads subsection to define waiver receipts (citing operational exemption patterns) and updated the auto-rendered table to show budget vs effective verdict.

## v0.85 (2026-02-22)
- **Budgeted policy heads:** added `scripts/policy_budget_head.py` and `scripts/render_policy_budget_head_table.py` to bind a policy-patch receipt + fleet portfolio probes into a witness-cosignable SPH extension that evaluates explicit migration budgets. New demo artifacts: `audit/policy_budget_checkpoint.json`, `audit/policy_budget_sph_signed.json`, `audit/policy_budget_sph_cosigned.json`, and generated Table `paper/generated/policy_budget_head_example.tex`.
- **Robustness:** fixed `scripts/sph_witness.py verify` to tolerate optional witness-side `--log/--state` parameters without attribute errors.

## v0.84 (2026-02-22)
- **Portfolio probes and migration budgets (typed DSL):** added `scripts/policy_dsl_portfolio_probe.py` and `scripts/render_policy_dsl_portfolio_probe_table.py` plus a small demo portfolio in `audit/policy_dsl_portfolio_example/`. The probe computes acceptance rates and cheapest repair sets across a fleet, turning policy upgrades into auditable migration budgets.

## v0.80 (2026-02-22)
- **Build stability:** fixed `scripts/render_stapled_bundle_table.py` and regenerated `paper/generated/stapled_bundle_example.tex`, so `latexmk` succeeds without manual patching.
- **Policy I/O-closure lint:** added `scripts/policy_closure_lint.py` to enforce that all policy `*_ref`/`*_refs` dependencies exist in-repo and (optionally) are committed by a policy proof.

## v0.79 (2026-02-22)
- **Stapled bundle exporter:** added `scripts/stapled_bundle.py` to export a self-contained directory/zip from a stapled profile, with a receipt manifest of hashes + sizes.
  - New demo artifacts: `audit/stapled_bundle_example/`, `audit/stapled_bundle_example.zip`, `audit/stapled_bundle_example_receipt.json`.
- **Offline recomputation support:** added optional `--repo-root` flags to `scripts/policy_eval.py` and `scripts/policy_proof_verify.py` to recompute acceptance against extracted bundles without rewriting paths.
- **Paper:** added a "Stapled bundle export" paragraph + generated Table `paper/generated/stapled_bundle_example.tex`, and a new contributions bullet for bundle exports.

## v0.78 (2026-02-22)
- **Size-aware stapling (min-bytes):** upgraded `scripts/stapled_profile.py` with a `--objective min-bytes` mode (size-aware greedy deletion + random restarts) to target compact offline staples.
- **Stapled-profile reliance diffs:** added `scripts/stapled_profile_diff.py` and `scripts/render_stapled_profile_diff_table.py` plus demo artifacts (`audit/policy_proof_{legacy,current}_v2.json`, `audit/stapled_profile_{legacy,current}.json`, `audit/stapled_profile_diff_example.json`) and generated Table `paper/generated/stapled_profile_diff_example.tex`.
- **Demo policy knob:** added `policies/example_policy_legacy.yaml` to simulate governance maturation (turning on attack-suite gating + derivation auditing) and drive reliance-diff examples.
- **Paper:** expanded the stapling section to discuss size-aware heuristics and reliance diffs; added a new contributions bullet and the reliance-diff example table.

## v0.77 (2026-02-22)
- **Stapled evidence profile tooling:** added `scripts/stapled_profile.py` (greedy-minimal offline bundles under fail-closed evaluation) and `scripts/render_stapled_profile_table.py`, plus demo artifacts `audit/stapled_profile_example.json` and generated Table `paper/generated/stapled_profile_example.tex`.
- **Policy proof I/O closure:** strengthened `scripts/policy_proof.py` to commit to policy-referenced artifacts (`*_ref` / `*_refs`) in addition to certificate-referenced evidence, preventing hidden dependencies.
- **Policy evaluation hardening:** tightened `scripts/policy_eval.py` to treat missing/invalid overlap reports and missing systemic-delta derivation evidence fail-closed when required by policy.
- **Paper:** added a short "policy I/O closure" paragraph in \S\ref{sec:policyproof}, inserted the stapled-profile example table, fixed the stapled contribution bullet, and cited *push0* for real-time proof orchestration in Clause~D.

## v0.74 (2026-02-22)
- **Witness-set epochs (rotation):** added a minimal, auditable mechanism for witness membership/key rotation without relying on an online directory.
  - New tool: `scripts/witness_epoch.py` (epoch declarations, quorum-authorized transitions, verification).
  - New paper table renderer: `scripts/render_witness_epoch_transition_table.py`.
  - New committed demo artifacts under `audit/witness_epochs/` plus a rotated witness keypair `audit/witness_keys/w4_*.pem`.
- **Paper:** added a governance receipts paragraph on witness-set epochs and auto-rendered Table `paper/generated/witness_epoch_transition_example.tex`.

## v0.73 (2026-02-22)
- **Typed monotone policy DSL (polarity-aware):** added `scripts/policy_dsl_typed.py` plus evaluator and fuzz harness wrappers, and a worked example schema+policy under `policies/`. The typechecker enforces that policy leaves are upward-closed under a per-metric direction (higher/lower is better), preventing polarity mistakes from breaking monotonic acceptance.
- **Paper:** added a polarity-aware policy paragraph and an auto-rendered table (`paper/generated/policy_dsl_typed_example.tex`).
- **BEP-MT (tile-backed Merkle catalogs):** added a two-level, tile-backed commitment for very large fixture catalogs with projection proofs and verification tooling (`scripts/bep_catalog_tile_*`). Added committed demo artifacts and an auto-rendered paper table (`paper/generated/bep_catalog_tile_verify_example.tex`).

## v0.72 (2026-02-22)
- **Monotone policy DSL (fail-closed by construction):** added `scripts/policy_dsl.py` (semantics), `scripts/policy_dsl_eval.py` (CLI evaluator), and `scripts/policy_dsl_fuzz.py` (monotonicity fuzz harness), plus a worked example policy `policies/monotone_policy_dsl_example.json` and committed state/eval artifacts under `audit/`.
- **Paper:** extended the conservatism-contract section with a monotone-by-construction policy DSL paragraph and auto-rendered Table `paper/generated/policy_dsl_example.tex`.
- **BEP-M receipts:** added COSE receipt packaging for BEP-M projections (`scripts/bep_catalog_merkle_receipt.py`) and verification (`scripts/bep_catalog_merkle_receipt_verify.py`), plus committed receipt artifacts and an auto-rendered paper table (`paper/generated/bep_catalog_merkle_receipt_example.tex`).

## v0.71 (2026-02-22)
- **BEP-M (Merkleized catalogs / verifiable projections):** added CT-style Merkle commitments for fixture catalogs and inclusion-proof bundles for selected fixtures.
  - New scripts: `scripts/bep_catalog_merkle_commit.py`, `scripts/bep_catalog_merkle_prove.py`, `scripts/bep_catalog_merkle_verify.py`.
  - New demo artifacts: `audit/bep_catalog_merkle_commit_example.json`, `audit/bep_catalog_merkle_projection_example.json`, `audit/bep_catalog_merkle_verify_report_example.json`.
- **Paper:** added a BEP-M paragraph and an auto-rendered table (`paper/generated/bep_catalog_merkle_verify_example.tex`) showing membership verification for a fixture projection.

## v0.70 (2026-02-22)
- **Joint BEP-S:** added `scripts/joint_bep_strat_verify.py` to verify cross-stack, quota-enforced stratified draws (shared binding key + selected list + dataset/report commitments).
- **Demo artifacts:** added a synthetic 2k-fixture stratified multistack pool (`scripts/gen_stratified_multistack_pool.py` + `benchmarks/strat_multistack_catalog_2k.json` / `benchmarks/strat_multistack_pool_2k.jsonl`) and a complete three-stack Joint BEP-S bundle under `audit/`.
- **Paper:** added a Joint BEP-S paragraph and an auto-rendered verification table (`paper/generated/joint_bep_strat_verify_example.tex`).

## v0.69 (2026-02-22)
- **BEP-S (stratified benchmark entropy):** added `scripts/fixture_draw_stratified.py` (quota-based per-stratum fixture draws) and `scripts/bep_strat_verify.py` (fail-closed verifier). Added a committed example catalog and verification artifacts.
- **Paper:** integrated BEP-S as a governance hook for mandatory "killer" fixtures, with an auto-rendered verification table (`paper/generated/bep_strat_verify_example.tex`).
- **References:** added citations for Ethproofs "killers" and Brevis Pico Prism to ground adversarial fixture motivation and the broader RTP ecosystem.

## v0.60 (2026-02-20)
- **C2SP alignment for witnessed checkpoints:** added references and paper text aligning SPH checkpoints/cosignatures with C2SP tlog-checkpoint/tlog-cosignature/tlog-witness and real witness network operations (transparency.dev).
- **Stateful witness enforcement:** upgraded `scripts/sph_witness.py` with optional witness-side checkpoint recomputation and append-only enforcement using CT consistency proofs and a persisted witness state file; added example `audit/sph_cosigned_stateful_w1.json` and `audit/witness_state/w1.json`.
- **LaTeX hardening:** regenerated the governance fuzz table with underscore escaping to avoid brittle compilation assumptions.
- **Paper:** added Proposition `prop:sph-quorum` formalizing a quorum anti-equivocation guarantee under a witness consistency contract.

## v0.59 (2026-02-20)
- **Witness-cosigned policy-log heads:** added `scripts/sph_witness.py` plus demo keys and artifacts (`audit/sph_cosigned.json`) to attach operator signatures and threshold witness cosignatures to policy-log checkpoints. Updated the paper and `docs/policy_transparency_log.md`.
- **Portfolio planning tool:** added `scripts/portfolio_select.py` to enumerate $k$-of-$r$ portfolios, re-derive $\delta_{\mathrm{sys}}$ per subset from evidence, and compute systemic-mixture bounds; added LaTeX renderer `scripts/render_portfolio_table.py` and generated `paper/generated/portfolio_selection_table.tex`.
- **Related-work refresh:** updated SCITT architecture reference to `draft-ietf-scitt-architecture-22` and added citations for CoSi and Sigsum witness cosigning.

## v0.58 (2026-02-20)
- Added Clause E on adversarial governance evaluation (metamorphic testing lens).
- Added governance fuzz harness (`scripts/gov_fuzz.py`) and LaTeX renderer (`scripts/render_gov_fuzz_table.py`).
- Hardened `scripts/policy_eval.py` to treat missing obligations and missing soundness ledgers fail-closed.

## v0.56 — 2026-02-20

- **Conservatism contract formalization:** added an explicit C1--C4 invariant list, evidence-weakening order, and a fail-closed monotonicity proposition (dropping/weakening evidence cannot improve acceptance) in \S\ref{sec:policyproof}.
- **SBOM/provenance primary sources:** added bibliographic entries and citations for NTIA SBOM Minimum Elements (EO 14028), CISA 2025 update, ISO/IEC 5962 (SPDX), and ECMA-424 (CycloneDX); also added citations for the SLSA provenance spec and Sigstore security model.
- **Incident durability:** added an NVD CVE cross-reference for the RISC Zero underconstrained zkVM circuit vulnerability (CVE-2025-52484).

## v0.53 — 2026-02-19

- **Systemic delta (quorum-aware):** introduced a CCCG-based decomposition that refines the coarse \(\delta_{\mathrm{sys}}\) into thresholded bounds \(\delta_{\mathrm{sys}}^{(k)}\) relevant for $k$-of-$r$ acceptance.
- **Artifacts:** added `policies/cccg_budgets.yaml`, `scripts/cccg_quorum_delta.py`, `scripts/render_cccg_quorum_table.py`, and committed `correlation/cccg_quorum_delta.json` plus generated paper tables `paper/generated/cccg_quorum_delta.tex`.
- **Paper:** added a new systemic-delta subsection connecting coupling-group evidence to classic common-cause failure (CCF) modeling (CCCGs) and added new citations (Shorthill et al. 2022; ZkCloud proving every Ethereum block in 2025).

## v0.52 — 2026-02-18

- **Conservatism contract:** strengthened the evidence-preorder framing and monotonicity-based no-risk-laundering proposition in \S\ref{sec:deltasys}.
- **Governance incident card:** added a minimal incident artifact and auto-rendered table for a disclosed zkVM soundness bug (`audit/incident_risc0_underconstrained_2025.json` and `paper/generated/incident_case_risc0.tex`).
- **Benchmarking realism hooks:** cited the eth-act zkEVM benchmarking workload repository as a natural fit for BEP catalogs.

## v0.51 — 2026-02-18

- **Systemic delta (Clause C):** added an interpretable **bug-class exposure report** (`scripts/bug_class_report.py`) that maps overlap + provenance features into governance-facing common-mode risk signals (toolchain/GPU/spec/crypto/assumption regime).
- **Paper:** documented the bug-class ledger and added an auto-generated table (`paper/generated/bugclass_metrics.tex`).
- **Conservatism contract:** added a best-effort **monotonicity checker** for systemic-delta mappings in `scripts/delta_sys_model.py`, embedding results into `correlation/systemic_delta_derivation.monotonicity`.
- **Policy/schema:** bumped `policies/delta_sys_map.yaml` to v5 and extended the certificate schema to include `bugclass_report_ref`, `evidence_preorder`, and `monotonicity` fields.

## v0.44 — 2026-02-16

- **Paper:** upgraded BEP into a governance-grade anti-cherry-picking mechanism: added a grinding/abort bound lemma, an auto-rendered BEP verification table, and an equivocation-scan example for transparency-log monitoring.
- **Artifacts:** added `scripts/bep_verify.py`, `scripts/bep_log_scan.py`, and renderers for paper tables; regenerated BEP example draw/attestation artifacts and committed the generated LaTeX tables.
- **Policy/schema:** extended `scripts/policy_eval.py` with optional `require_bep`, added `policies/example_policy_bep.yaml`, and extended the certificate schema fixture with optional BEP references/digests.

## v0.43 — 2026-02-16

- **Paper:** introduced the Benchmark Entropy Protocol (BEP): beacon-seeded fixture draws + DSSE/in-toto run attestations + transparency-log inclusion to make anti-cherry-picking claims checkable.
- **Artifacts:** added `scripts/fixture_draw.py` and BEP example attestations.

## v0.42 — 2026-02-16

- **Paper:** added a new Motivation subsection linking EF's RTP north-star to ZK-RTP artifacts, with a mapping table and a governance-loop figure.
- **Paper:** expanded the two-sided drift detector section with an explicit benchmark-gaming (mixture/strata) model and a stop-rule safety proposition.
- **Artifacts:** added `paper/figures/zk_rtp_pipeline.pdf`.
- **Schema/policy:** added optional `hardware.capex_usd` and `hardware.power_kw` fields and policy checks (`max_capex_usd`, `max_power_kw`).

## v0.41 — 2026-02-16

- **Paper:** tightened abstract to foreground the four certificate clauses and the executable artifacts (schema, checkers, diffable reports).
- **Paper:** added a new Motivation subsection "Design goals and threat model" mapping concrete failure modes (forgery, benchmark gaming, correlated failures, queue-induced liveness collapse, governance equivocation) to Clauses A–D and to policy-proof / transparency-log workflows.
- **Notes:** bumped working-notes header to v0.41.

## v0.39 — 2026-02-13

- **Clause D+ (quorum liveness over queues):** added `scripts/rtp_multiproof_queue_monitor.py` to simulate per-stack FIFO queues under slot arrivals and certify k-of-r *slot-level* quorum deadlines via an anytime-valid e-process.
- **Artifacts:** added a deterministic synthetic generator (`scripts/gen_multistack_queue_benchmark.py`), an example stream (`benchmarks/example_multistack_queue_2k.jsonl`), an example report (`audit/rtp_multiproof_queue_report_example.json`), and an auto-generated paper table (`paper/generated/rtp_multiproof_queue_example.tex`).
- **Paper:** added a new subsection composing queue-aware monitoring with multi-proof liveness, framing the result as a fork-join queue certificate and highlighting policy levers (purging/cancellation, heterogeneity).

## v0.38 — 2026-02-13

- **Queue-aware RTP:** added `scripts/rtp_queue_monitor.py` to upgrade per-block tail monitoring into a *slot-level liveness* claim on end-to-end completion delay via Lindley's recursion.
- **Artifacts:** committed `audit/rtp_queue_report_example.json` and an auto-generated paper table `paper/generated/rtp_queue_example.tex`.
- **Paper:** added a new Clause-B subsection on queueing amplification and its connection to $k$-of-$r$ multi-proof fork-join models; added classic queueing citations (Lindley 1952; Kingman 1962; fork-join survey).

## v0.37 — 2026-02-13

- **Verified monitoring:** added replayable monitor traces with a hash-chain commitment (`scripts/rtp_monitor_trace.py`, `scripts/verify_monitor_trace.py`) and a paper subsection proposing zkVM proof-of-monitoring receipts.
- **Artifacts:** committed example trace + summary under `audit/` and auto-generated `paper/generated/rtp_monitor_trace_example.tex`.

## v0.34 — 2026-02-13

- **Monitoring:** added a time-uniform beta-mixture confidence sequence for exceedance rates (`scripts/confseq.py`) and exported it from `scripts/rtp_monitor.py` (tunable via `--alpha-cs`).
- **Paper:** added a Clause-B subsection on confidence sequences and bidirectional governance (range-checking + regression alarms), and updated the example monitor table to include \(\hat p\) and \(\overline p_{CS}\).
- **Benchmark integrity:** added `scripts/benchmark_run_attest.py` to emit an in-toto Statement binding the dataset + monitor report; committed an example statement under `audit/benchmark_run_statement_example.json`.

## v0.33 — 2026-02-13

- **Paper:** added a mixture e-process subsection and an auto-generated comparison table contrasting fixed-$p_1$ LR vs grid-mixture monitors (diffable from committed JSON reports).
- **Monitoring:** extended `scripts/rtp_monitor.py` with `--method mixture-grid`; committed `audit/rtp_monitor_mixture_report_example.json`.
- **Supply-chain bridge:** added `scripts/policy_proof_attest.py` to emit in-toto Statements and optional DSSE envelopes for policy proofs; committed example outputs under `attestations/`.
- **Docs:** added `docs/policy_proof_attestation.md` describing the in-toto/DSSE packaging.

## v0.30 — 2026-02-11

- **Paper:** made Clause B monitor output diffable by adding an auto-generated monitor table (`paper/generated/rtp_monitor_example.tex`) rendered from a committed JSON report.
- **Artifacts:** added a tiny benchmark stream (`benchmarks/example_latency.jsonl`) and its deterministic monitor report (`audit/rtp_monitor_report_example.json`).
- **Tooling:** added `scripts/render_rtp_monitor_table.py` to render the Clause B table directly from the report.
- **Bibliography:** expanded anytime-valid inference references (Ramdas e-values ebook; Ly tutorial; Koning/van Meer “anytime validity is free”).

## v0.29 — 2026-02-11

- **Paper:** added a subsection on certificate renewal reports and drift monitoring; included an auto-generated renewal diff table (`paper/generated/renewal_diff_stackA.tex`).
- **Tooling:** added `scripts/renewal_check.py` to produce a renewal governance diff and derived regression metrics.
- **Artifacts:** added an upgraded example certificate (`schemas/example_cert_stackA_renewed.json`) and a deterministic renewal report (`audit/renewal_report_stackA.json`).

## v0.28 — 2026-02-11

- **Paper:** added an explicit *envelope upgrade lattice* subsection clarifying evidence-gated permissions vs. numeric tightness; added a short lemma and an auto-generated empirical table of envelope-debt bits.
- **Tooling:** added `scripts/envelope_debt_sim.py` which deterministically generates `paper/generated/envelope_debt_sim.tex` for diffable PDF numbers.
- **Bibliography:** added missing entries for RFC 9162 + Sigstore/Rekor references already cited in the draft.

## v0.27 — 2026-02-11

- **Tooling:** added *risk-debt accounting* to `scripts/multiproof_eval.py`: report the tightest available envelope bound under current evidence/policy constraints plus `envelope_debt_factor` / `envelope_debt_bits` for the chosen envelope.
- **Tooling:** enriched multiproof audit output with explicit envelope-selection metadata (`desired_envelope`, `chosen_envelope`, `fallback_chain`, `fallback_steps`, `available_envelopes`).
- **Paper:** added a “Risk-debt accounting” paragraph and bumped the draft header to v0.27.

## v0.26 — 2026-02-11

- **Tooling:** implemented governance-grade envelope selection: explicit desired envelope + policy-defined fallback ladder (`--desired-envelope`, `--allow-fallback`, `--fallback-chain`, `--max-fallback-steps`).
- **Schema/Examples:** strengthened `correlation.dependence_attestation` to support multi-envelope support sets (`supports_envelopes`) and explicit evidence tiers (`E0..E3`).
- **Paper:** updated dependence-attestation definition and added a monotonicity lemma; documented explicit fallback semantics.

## v0.25 — 2026-02-11

- **Paper:** introduced *dependence attestations* binding envelope choice to signed, monitorable evidence bundles; expanded the minimal policy language to cover Markov/product/pairwise/LP.
- **Tooling:** extended schema + evaluator to optionally require dependence attestations for non-Markov envelopes.
- **Bibliography:** refreshed transparency-log references (Rekor v2 GA; OpenSSF dataset; rekor-monitor).

## v0.24 — 2026-02-11

- **Tooling:** made the LP dependence envelope numerically fail-closed at cryptographic scales (HiGHS can return spuriously-zero objectives for RHS ∼ 1e-24).
  The checker now row-scales constraints, validates against a trivial feasible lower bound, and falls back to legacy simplex when HiGHS underestimates.
  LP results are additionally capped by trusted analytic envelopes (Markov; and a pairwise cap for $k{=}2$ when $u_{ij}$ are present).
- **Paper:** bumped header to v0.24 and added an implementation-note warning about LP numerical fragility.
- **CI artifacts:** refreshed `policy_report.json` and `audit/policy_report.json` under the improved LP checker.

## v0.20 — 2026-02-11

- **Paper:** corrected Clause C semantics by separating an **assumption-free Markov envelope** from an explicit **product envelope** (elementary symmetric polynomial), and updated the worked example to report both.
- **Tooling:** extended `scripts/risk_bounds.py` and `scripts/multiproof_eval.py` to support `--bound-method {markov,product}` / `multiproof.bound_method`.
- **Tooling:** fixed a governance bug in `scripts/multiproof_eval.py` (single-cert failures could reference an uninitialized list) and refreshed the paper draft header to v0.20.
- **Bibliography:** expanded common-mode risk citations (Littlewood \& Miller 1989; Littlewood 1996).

## v0.19 — 2026-02-11

- **Paper:** added a fail-closed monotonicity lemma (conservatism contract ⇒ governance decisions).
- **Paper:** added a worked multiproof example demonstrating systemic-delta domination.
- **Paper:** fixed an assumption-graph LaTeX typo and repaired stray `\newblock` rendering typos in the bibliography.
- **Tooling:** regenerated `paper/generated/correlation_metrics.tex`.

## v0.18 — 2026-02-11

- **Paper:** rewrote the abstract to foreground governance primitives (scope calculus + transcript ABI, anytime-valid evidence, correlation envelopes, policy proof objects).
- **Paper:** expanded the Contributions list, added a Transcript-ABI scope-extractor paragraph, and added a new Related Work section (practice gaps, zkEVM RTP/diversity, transparency logs, supply-chain standards, anytime-valid inference, common-mode risk).
- **Schema:** updated schema description to v0.18 (no breaking field changes).
- **Notes:** added a v0.18 snapshot + forward TODOs.

## v0.17 — 2026-02-09

- **Paper:** stabilized Clause B (anytime-valid monitoring) and Clause C (systemic-delta + overlap evidence) narrative and refreshed citations.
- **Tooling:** refreshed e-process and policy evaluation scripts; regenerated example outputs.

## v0.15 — 2026-02-09

- **Policy proof objects:** added `scripts/policy_proof.py` to generate a tamper-evident evaluation record (hash commitments + derived quantities + accept/reject), and an example artifact in `audit/policy_proof_example.json`.
- **Conservatism contract:** added `docs/conservatism_contract.md` defining monotonicity + missing-evidence floors + stable IDs + tamper-evident decision records.
- **Paper update:** new subsection on policy proof objects and the conservatism contract.
- **Example refresh:** re-embedded systemic-delta derivations so example certs conservatively dominate recomputed deltas; bumped example `version` fields to v0.15.
- **Robustness:** relaxed a float-comparison in `scripts/policy_eval.py` (declared vs. recomputed delta) to avoid spurious failures.

## v0.11 — 2026-02-08

- **Scope registry for external regimes (Clause A / DB-LPB):** added `docs/scope_registry.yaml` and `scripts/scope_registry.py`, and extended the schema so that scopes of kind `proximity-gap`/`list-recovery` must cite a stable `registry_id` (validated fail-closed by `scripts/check_cert.py`).
- **DB-LPB sharpened:** rewrote the DB-LPB subsection to explicitly decompose binding error into (external proximity term) + (injectivity via Schwartz–Zippel determinant) + (rest), making it easier to audit which parts are code-theoretic vs. algebraic vs. protocol-specific.
- **Examples updated:** example certificates now include a proximity-gap scope entry bound to arXiv:2601.10047.

## v0.8 — 2026-02-08

- **Governed systemic-delta derivation (Clause C):** added an auditable, monotone evidence→risk transform:
  - `policies/delta_sys_map.yaml` (reviewable mapping config)
  - `scripts/delta_sys_model.py` + `scripts/delta_sys.py` (derive and emit a derivation record)
  - updated schema + example certs to include `correlation.systemic_delta_derivation`.
- **Calibration hook (Clause C):** added `scripts/calibrate_delta.py` to compute an anytime-valid Clopper–Pearson alpha-spending upper bound from a common-mode incident log, to be fed into the systemic-delta derivation.
- **Fail-closed checker improvements:** `scripts/check_cert.py` now checks that a declared `systemic_delta` dominates its own `derived_delta` if a derivation block is present.
- **Policy semantics improved:** `scripts/policy_eval.py` now supports separating *cryptographic soundness* (`min_bits_total`, `max_eps_total`) from *systemic common-mode risk* (`max_systemic_delta`), and can (optionally) recompute and verify the derivation record.
- **Multiproof evaluator refreshed:** `scripts/multiproof_eval.py` now supports `--policy` input and uses max(declared, derived) delta_sys by default.
- **Paper updates:** expanded Clause C to make the systemic-delta calculus checkable and governance-friendly; clarified that multi-proof acceptance is frequently dominated by common-mode risk without strong independence evidence.

## v0.7 — 2026-02-08

- **k-of-r risk bounds made executable:** added `scripts/risk_bounds.py` (elementary-symmetric union bound) and `scripts/multiproof_eval.py` to compute conservative false-accept bounds for *sets* of certificates.
- **Evidence tiers (E0–E3):** schema supports an optional `evidence_tier` on ledger rows and obligations, enabling governance to distinguish claim-only vs. mechanized vs. formal evidence.
- **Multi-proof demo artifacts:** toy `schemas/example_cert_stackA/B/C.json` and a sample multi-proof policy `policies/example_multiproof_policy.yaml`.
- **Checker report enriched:** `scripts/check_cert.py` summarizes ledger evidence tiers.

## v0.6 — 2026-02-08

- Added `scripts/policy_eval.py` and `scripts/sbom_overlap.py` (correlation evidence from CycloneDX/SPDX).
- Paper edits to Clause C emphasizing dependency evidence and fail-closed correlation assumptions.

## v0.5 — 2026-02-08

- Major paper rewrite: explicit policy semantics, scope calculus, and conservative correlation envelope.
- Schema v0.5: adds `obligations[]`, `budgets.soundness.scopes[]`, and `ledger_rows[].scope_ids`.
- Checker: validates scope references and obligations; exits nonzero on structural errors by default.
- Added `scripts/eprocess.py`: minimal anytime-valid e-process for Clause B exceedance monitoring.
- Refreshed citations to primary sources (EF zkEVM RTP + security foundations; zkEVM benchmarking/repricing posts; supply-chain specs).

## v0.4 — 2026-02-08

- Reframed paper around a governance-grade “certificate” artifact with explicit clauses (A/B/C).
- Added: scope calculus (randomness freshness/reuse assumptions).
- Added: anytime-valid statistical framing for Clause B.
- Added: SBOM / supply-chain evidence tiering for Clause C.
- Added: manual bibliography entries for new citations (BibTeX not required for builds here).

## v0.40 (2026-02-14)
- Added Clause D++: cancel-on-quorum hedging with explicit cancellation semantics and compute-cost envelope.
- Added regeneration / busy-cycle Hoeffding-mixture e-process for queue-derived liveness and cost claims.
- New monitor and renderer: scripts/rtp_multiproof_cancel_queue_monitor.py, scripts/render_rtp_multiproof_cancel_queue_table.py.
- New example artifacts: audit/rtp_multiproof_cancel_queue_report_example.json, paper/generated/rtp_multiproof_cancel_queue_example.tex.
## v1.80 — 2026-02-28

- Expanded `paper/paper_execassurance.tex` into a conference-style draft (executable assurance cases).
- Fixed `policy_proof.py` evidence closure: commit to additional decision-critical refs (architecture whitepaper closure/requirements/outline, budget/report pointers).
- Fixed `stapled_profile.py` omission simulation by guarding `policy_eval`'s `exists()` and `_sha256_file`.
- Added `stapled_bundle.py --include-proof-closure` to produce fully-offline proof-verification bundles.
- Added fresh policy proof + stapled profile + bundles for the staged renewal example; updated audit-replay recipe in LaTeX.

## v1.92 — 2026-02-28

- **Go verifier:** extended `verifier_go/` from proof-closure-only to a unified stdlib-only verifier supporting `--mode receipt|closure|full`.
- **Cross-implementation:** added `scripts/cross_impl_receipt_suite.py` (Python vs Go receipt integrity) including a metamorphic \emph{zip-entry reorder} control and a deterministic tamper negative control.
- **Paper:** updated `paper_execassurance.tex` contributions + inserted cross-implementation receipt table (Table~\ref{tab:cross_impl_receipt}).
- **Tooling:** refreshed cross-impl closure suite outputs to `*_v1_92.*` and updated benchmark script defaults.
## v1.93 — 2026-02-28

- **Canonical bundle digests:** added a transport-invariant, content-derived digest for stapled bundles (`scripts/bundle_canonical_digest.py`) with two scopes: `canon_all` (all zip entries) and `canon_receipt` (receipt-covered entries only).
- **Metamorphic suite:** added `scripts/make_bundle_variants.py` and `scripts/cross_impl_canon_suite.py` to generate and test reorder + metadata-churn + junk-file controls; outputs `audit/cross_impl_canon_suite_report_v1_93.json` and `paper/generated/cross_impl_canon_conformance_v1_93.tex`.
- **Go verifier:** extended `verifier_go/` with `--mode canon` to compute canonical digests (stdlib-only) and match Python.
- **Paper updates:** `paper_execassurance.tex`, `paper_metaconformance.tex`, and `paper_proofclosure.tex` now include Table~\ref{tab:canon_digest_invariance} and discuss transport invariance.
- **New split note:** added `paper/paper_bundlecanon.tex` (canonical bundle digests as governance pointers).
- **References:** added reproducible-builds archive nondeterminism citation.

## v1.95 — 2026-02-28

- **Governance record v3 (locator drift resistance):** added `zk-rtp-governance-record/v3` schema and verifier logic. v3 excludes locator fields (`bundle.zip_path`, `bundle.size_bytes`, `bundle.locators`) from `record_digest` scope so records can gain new mirrors/paths without re-logging.
- **Two-layer non-equivocation section:** expanded `paper/paper_govrec_signed.tex` with an explicit reduction-style argument tying logged `record_digest` commitments to bundle digest binding.
- **CT-style log demo for governance digests:** added `scripts/govrec_log.py` and demo artifacts `audit/govrec_log_demo_v1_95.jsonl`, `audit/govrec_inclusion_proof_1_v1_95.json`, plus figure `paper/generated/fig_govrec_log_demo_v1_95.tex`.
- **Conformance suite extensions:** added v2 digest-mismatch and v3 zip-path drift cases; regenerated `paper/generated/tab_governance_record_conformance.tex`.

## v1.94 — 2026-02-28

- **Governance record v2:** added `zk-rtp-governance-record/v2` (`schemas/zk_rtp_governance_record_v2.schema.json`) where bundles are bound by a digest set with `primary_alg` (supports `sha256-zip`, `sha256-canon-all`, `sha256-canon-receipt`).
- **Statement-level canonical binding:** extended `scripts/decision_object.py` with repeatable `--extra-subject name:sha256` to add non-file ``virtual subjects'' (used to bind canonical bundle digests).
- **Verifier updates:** `scripts/governance_record.py`, `scripts/decision_verifier.py`, and `scripts/govrec_jws.py` now accept v2 records and enforce digest-set bindings.
- **Cross-implementation JCS suite:** added `verifier_go/zkrtp_jcs_digest` (Go) and `scripts/cross_impl_govrec_jcs_suite.py` (Python) producing `audit/govrec_jcs_suite_report_v1_94.json` and LaTeX table `paper/generated/govrec_jcs_invariance_table.tex`.
- **Paper updates:** refreshed `paper_bundlecanon.tex` to v1.94, expanded `paper_govrec_signed.tex` to cover v2 + JCS cross-impl, and updated the main audit recipe and interoperability appendix.
