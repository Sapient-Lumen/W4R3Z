# Current documents

**Latest archive version: v2.02 (Feb 28, 2026).**

## Papers (LaTeX sources)
- `paper/paper_receipt_bound_governance.tex` (RBGO + receipt graphs; v2.02)
- `paper/paper_transparent_pointers.tex` (transparent pointers / canon v2; v2.02)
- `paper/paper_correlation_contracts.tex` (correlation contracts; v2.02)

## Notes
- `notes/assistant_notes_v2_02.md` (what changed + repro commands)
- `notes/archive_index.md` (version index)

## Built PDFs (in the release directory)
- `paper_transparent_pointers_v2_02.pdf`
- `paper_correlation_contracts_v2_02.pdf`
- `paper_receipt_bound_governance_v2_02.pdf`
