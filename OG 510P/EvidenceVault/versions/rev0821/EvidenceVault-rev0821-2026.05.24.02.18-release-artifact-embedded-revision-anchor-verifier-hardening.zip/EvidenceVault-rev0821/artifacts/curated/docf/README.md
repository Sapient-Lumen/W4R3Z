# Curated dOCF path index

This directory now keeps a compact canonical-path index instead of shipping byte-identical mirrors of retained dOCF source and test-vector files.

Canonical retained paths for the removed exact mirrors:

- `capsule_open_bond_policy_demo.json` -> `sources/docf/test_vectors/capsule_open_bond_policy_demo.json`
- `capsule_open_reveal_policy_demo.json` -> `sources/docf/test_vectors/capsule_open_reveal_policy_demo.json`
- `capsule_open_verdict_demo.json` -> `sources/docf/test_vectors/capsule_open_verdict_demo.json`
- `capsule_reveal_policy_demo.json` -> `sources/docf/test_vectors/capsule_reveal_policy_demo.json`
- `cross_market_bundle_index_demo.json` -> `sources/docf/test_vectors/cross_market_bundle_index_demo.json`
- `docf_capsule_open_bond_policy_v0.schema.json` -> `sources/docf/docf_capsule_open_bond_policy_v0.schema.json`
- `docf_capsule_reveal_policy_v0.schema.json` -> `sources/docf/docf_capsule_reveal_policy_v0.schema.json`
- `grinding_budget_cert_example_asc_market.json` -> `sources/docf/grinding_budget_cert_example_asc_market.json`
- `grinding_budget_cert_scitt_statement_demo.json` -> `sources/docf/test_vectors/grinding_budget_cert_scitt_statement_demo.json`
- `ledger_example.json` -> `sources/docf/ledger_example.json`
- `manifest_attempt_expr_attestation_assumptions.json` -> `sources/docf/manifest_attempt_expr_attestation_assumptions.json`
- `manifest_attempt_expr_attestation_vars.json` -> `sources/docf/manifest_attempt_expr_attestation_vars.json`
- `manifest_boundless_market.json` -> `sources/docf/manifest_boundless_market.json`
- `market_bid_example.json` -> `sources/docf/market_bid_example.json`
- `market_bundle_index_demo.json` -> `sources/docf/test_vectors/market_bundle_index_demo.json`
- `market_clearing_cert_example.json` -> `sources/docf/market_clearing_cert_example.json`
- `market_clearing_dispute_example.json` -> `sources/docf/market_clearing_dispute_example.json`
- `market_dispute_bond_schedule_demo.json` -> `sources/docf/market_dispute_bond_schedule_demo.json`
- `market_epoch_selection_example.json` -> `sources/docf/market_epoch_selection_example.json`
- `market_evidence_profile_example_boundless.json` -> `sources/docf/market_evidence_profile_example_boundless.json`
- `market_multiresource_selection_example.json` -> `sources/docf/market_multiresource_selection_example.json`
- `market_multiresource_selection_receipt_demo.json` -> `sources/docf/market_multiresource_selection_receipt_demo.json`
- `market_round_cert_demo.json` -> `sources/docf/market_round_cert_demo.json`
- `market_selection_receipt_example.json` -> `sources/docf/market_selection_receipt_example.json`
- `market_selection_receipt_scitt_statement_example.json` -> `sources/docf/market_selection_receipt_scitt_statement_example.json`
- `market_session_cert_scitt_statement_demo.json` -> `sources/docf/test_vectors/market_session_cert_scitt_statement_demo.json`
- `market_session_receipts_example.json` -> `sources/docf/market_session_receipts_example.json`
- `pabom_receipt_demo.json` -> `sources/docf/test_vectors/pabom_receipt_demo.json`
- `policy_example_v0.json` -> `sources/docf/policy_example_v0.json`
- `portable_acceptance_receipt_demo.json` -> `sources/docf/test_vectors/portable_acceptance_receipt_demo.json`
