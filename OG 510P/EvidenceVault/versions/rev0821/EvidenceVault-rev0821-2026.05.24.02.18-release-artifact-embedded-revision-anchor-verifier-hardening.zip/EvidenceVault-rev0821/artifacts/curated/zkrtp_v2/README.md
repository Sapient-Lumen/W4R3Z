# ZK-RTP (evolving draft v2.00)


## Standalone paper splits (work-in-progress)
- `paper/paper_receipt_bound_governance.tex`: receipt-bound governance objects (RBGO): a join key binding bundle pointers + governance digests + contract digests + receipts.
- `paper/paper_transparent_pointers.tex`: transport-invariant governance pointers for decision bundles (canonical bundle digests + governance records + locator drift resistance; maps to Sigstore/SCITT).
- `paper/paper_correlation_contracts.tex`: correlation-constrained multi-proof contracts (governance-facing correlation budgets for $k$-of-$r$ strategies).

This archive contains an evolving LaTeX draft and notes for a paper proposing **ZK-RTP Certificates**
(RTP = Real-Time Proving): a governance-grade certificate format that binds together

- (A) cryptographic soundness accounting (soundness ledgers + explicit scope assumptions),
- (B) real-time proving evidence under a declared workload distribution (anytime-valid monitoring),
- (C) multiproofs security under *explicit* correlated-failure models grounded in dependency evidence (SBOMs / attestations),
- (D) multiproofs liveness under queueing/cancellation semantics, and
- (E) adversarial governance evaluation via omission-style metamorphic tests, and
- (F) timeliness + non-equivocation as portable evidence objects (SET/MMD + witness checkpoints).

**New in v1.94:** transport-invariant \emph{governance pointers}: a governance record v2 format that binds bundles by a digest set (including canonical bundle digests) plus a Python+Go cross-implementation suite for the record-level JCS digest.

## Build (paper)

From `paper/` (recommended):

```bash
latexmk -pdf -interaction=nonstopmode -halt-on-error paper.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error spec.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error paper_clauseB.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error paper_clauseE.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error paper_clauseF.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error paper_evidencecalc.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error paper_execmon.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error paper_rtpabi.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error paper_liveness.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error paper_execassurance.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error paper_metaconformance.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error paper_bundlecanon.tex
```

Outputs `paper.pdf`, `spec.pdf`, `paper_clauseB.pdf`, `paper_clauseE.pdf`, `paper_clauseF.pdf`, `paper_evidencecalc.pdf`, and companion PDFs (`paper_execmon.pdf`, `paper_rtpabi.pdf`, `paper_liveness.pdf`).

## Demo (execution-justified monitoring bundle)

From the repo root:

```bash
python3 scripts/execmon_demo.py
```

This generates a complete trace→log→receipts→SET→transparent statement→monitor-binding→consistency chain under `audit/execmon_demo/`.

Note: the repository root may include older snapshot PDFs for archival purposes; `paper/paper.pdf` (or the exported `zk_rtp_paper_v*.pdf`) is the canonical build artifact.

## Contents

- `paper/paper.tex` — current LaTeX draft
- `paper/paper_execmon.tex` — standalone paper: execution-justified benchmarking
- `paper/paper_rtpabi.tex` — standalone paper: RTP-ABI (schema + conformance)
- `paper/paper_liveness.tex` — standalone paper: multi-prover liveness contracts
- `paper/notes.md` — paper-facing notes (what changed + next edits)
- `notes/notes.md` — extended research notes / next steps
- `docs/scope_registry.yaml` — registry of external scope regimes (proximity gaps / list recovery)
- `docs/assumption_graph.md` — Clause-C extension: assumption-graph metrics and interpretation
- `docs/conservatism_contract.md` — invariants for monotone, fail-closed, tamper-evident governance
- `scripts/assumption_graph.py` — reference implementation of assumption-graph closure/core/cut
- `schemas/zk_rtp_certificate.schema.json` — draft JSON schema for certificates (v0.18)
- `schemas/example_certificate.json` — example certificate (v0.18)
- `schemas/example_cert_stackA.json`, `example_cert_stackB.json`, `example_cert_stackC.json` — toy certificates for multi-proof demos (v0.19)
- `scripts/render_cert.py` — tiny renderer (JSON → Markdown)
- `scripts/check_cert.py` — conservative checker (fail-closed on scope inconsistencies)
- `scripts/eprocess.py` — anytime-valid exceedance monitoring primitive (Clause B)
- `scripts/rtp_monitor.py` — reference monitor that ingests benchmark streams, computes e-values (optionally per stratum), and outputs a report with dataset hashes
- `scripts/render_rtp_monitor_table.py` — render a compact LaTeX table from a monitor report (diffable PDF numbers)
- `scripts/fixture_draw.py` — BEP reference drawer (beacon + catalog → selected fixtures)
- `scripts/bep_verify.py` — fail-closed verifier for BEP draw artifacts
- `scripts/fixture_draw_stratified.py` — BEP-S stratified drawer (beacon + labeled catalog + quotas → selected fixtures)
- `scripts/bep_strat_verify.py` — fail-closed verifier for BEP-S stratified draw artifacts
- `scripts/bep_log_scan.py` — transparency-log equivocation scanner for BEP run attestations
- `scripts/bep_abort_budget.py` — abort-budget checker for beacon grinding (BEP+)
- `benchmarks/example_latency.jsonl` — tiny example benchmark stream used for the Clause-B table
- `audit/rtp_monitor_report_example.json` — deterministic monitor report for the example stream
- `scripts/sbom_overlap.py` — SBOM overlap metrics (CycloneDX/SPDX) for correlation evidence (Clause C)
- `scripts/correlation_features.py` — provenance-derived correlation features (toolchain/audit/spec/kernels) + optional regime diversity metrics from cert scopes
- `scripts/policy_eval.py` — evaluate a certificate against a YAML policy (single-certificate governance hook)
- `scripts/policy_proof.py` — produce a tamper-evident policy proof object (hash commitments + decision)
- `scripts/risk_bounds.py` — conservative k-of-r risk bounds (elementary-symmetric union bound)
- `scripts/multiproof_eval.py` — evaluate a k-of-r policy across *multiple* certificates
- `scripts/certified_decision.py` — compute a certified upper bound on worst-case governance loss (accept/reject) from Clause A/C/D/B artifacts
- `scripts/render_certified_decision_table.py` — render LaTeX decision records (reject + accept worked examples)
- `scripts/ci_check.py` — end-to-end checker: schema + certificate + policy (+ optional multiproof)
- `scripts/delta_sys.py` — derive a governed systemic delta from overlap/calibration evidence
- `scripts/calibrate_delta.py` — compute an anytime-valid calibration bound from common-mode incident logs
- `policies/example_policy.yaml` — sample single-certificate policy
- `policies/example_multiproof_policy.yaml` — sample multi-certificate policy
- `sboms/` — toy SBOMs used in the example overlap report
- `correlation/sbom_overlap.json` — example overlap report
- `correlation/features_report.json` — example provenance + regime-diversity features report

## Status

Early draft intended to be **high-signal** and **fail-closed**.


### Bundle attestations (in-toto / DSSE)

- Emit an in-toto Statement for an offline bundle zip:
  - `python3 scripts/stapled_bundle_attest.py --bundle-zip audit/proof_closure_bundle_stackA_renewal_v1_80.zip`
- Optionally emit a DSSE envelope (demo Ed25519 key):
  - `python3 scripts/stapled_bundle_attest.py --bundle-zip <bundle.zip> --dsse`

### Offline proof-closure lint (small TCB)

- Check that a proof-closure bundle contains every locally-committed `file_sha256` digest referenced by a policy proof:
  - `python3 scripts/proof_closure_lint.py --policy-proof audit/policy_proof_stackA_renewal_fresh_v1_80.json --bundle-zip audit/proof_closure_bundle_stackA_renewal_v1_80.zip`



Example outputs (StackA renewal):
- `attestations/stapled_bundle_attestation_stackA_renewal.statement.json`
- `attestations/stapled_bundle_attestation_stackA_renewal.dsse.json` (demo Ed25519)
