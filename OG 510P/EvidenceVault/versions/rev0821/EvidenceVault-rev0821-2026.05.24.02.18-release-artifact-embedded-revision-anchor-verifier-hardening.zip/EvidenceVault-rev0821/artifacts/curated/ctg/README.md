# Curated CTG path index

This directory now keeps a compact canonical-path index instead of shipping byte-identical mirrors of the retained CTG source tree.

The original mirrored upstream README is retained canonically at `sources/ctg/README.md`.

Canonical retained paths for the removed exact mirrors:

- `NOTES.md` -> `sources/ctg/NOTES.md`
- `pcg_manifest_build.py` -> `sources/ctg/pcg_manifest_build.py`
- `pcg_policy_dsl.py` -> `sources/ctg/pcg_policy_dsl.py`
- `pcg_rtt_harness.py` -> `sources/ctg/pcg_rtt_harness.py`
- `pcg_scope_tools.py` -> `sources/ctg/pcg_scope_tools.py`
- `pcg_trace_tools.py` -> `sources/ctg/pcg_trace_tools.py`
- `policy_examples/example_fs_read.json` -> `sources/ctg/policy_examples/example_fs_read.json`
- `policy_examples/example_fs_read.pcg` -> `sources/ctg/policy_examples/example_fs_read.pcg`
- `scope_new.json` -> `sources/ctg/scope_new.json`
- `scope_old.json` -> `sources/ctg/scope_old.json`
- `scope_patch.json` -> `sources/ctg/scope_patch.json`
