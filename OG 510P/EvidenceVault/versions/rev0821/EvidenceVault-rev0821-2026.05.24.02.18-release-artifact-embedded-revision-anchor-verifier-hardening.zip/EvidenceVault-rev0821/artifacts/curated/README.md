# Curated artifacts

This folder collects a small set of non-secret artifacts referenced by the papers.
For full context, see `legacy/`.
