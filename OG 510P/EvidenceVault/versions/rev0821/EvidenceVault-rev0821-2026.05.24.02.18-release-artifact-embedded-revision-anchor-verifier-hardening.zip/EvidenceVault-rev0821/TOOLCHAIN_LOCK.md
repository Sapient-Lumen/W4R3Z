# EvidenceVault toolchain lock

This file is the exact human-facing companion to `TOOLCHAIN_LOCK.json`.
It records the local replay floor, observed package versions, and deterministic package assumptions checked by `scripts/validate_toolchain_lock.py`.

## Environment policy
- Revision: `rev0821`
- Generated: `2026-05-24T02:18:00-0400`
- Version enforcement: `minimum-supported-with-observed-witness`
- Strict exact replay: `false`
- Bytecode policy: `PYTHONDONTWRITEBYTECODE=1`
- Observed versions are witnesses: `true`

## Python runtime
- Executable hint: `python3`
- Implementation: `CPython`
- Minimum version: `3.11.0`
- Observed version: `3.13.5`
- Required for: `gate validators`, `package release`, `publish audit`, `schema validation`, `cryptographic fixture verification`, `release artifact verification`

## Required Python packages

| Distribution | Import | Minimum | Observed | Required | Used by | Reason |
| --- | --- | --- | --- | --- | --- | --- |
| `jsonschema` | `jsonschema` | `4.0.0` | `4.26.0` | `true` | `schema-backed validators`, `JSON inventory validator` | Draft 2020-12 JSON Schema validation for governed machine-readable surfaces. |
| `PyYAML` | `yaml` | `6.0.0` | `6.0.3` | `true` | `JSON/YAML inventory validator`, `text payload validator` | YAML parsing for retained payload and registry-backed text-surface checks. |
| `cryptography` | `cryptography` | `3.4.8` | `3.4.8` | `true` | `crypto envelope validator`, `Ed25519 DSSE fixture verification`, `release artifact embedded Ed25519 DSSE fixture verification` | Ed25519 public-key parsing and signature verification for indexed DSSE fixtures in both live crypto validation and detached release-artifact verification. |

## Required external commands

| Command | Required | Scope | Reason |
| --- | --- | --- | --- |
| `bash` | `true` | Makefile shell, preflight wrapper, and paper-build wrapper | Operator-facing wrappers are bash scripts with strict shell mode. |
| `make` | `true` | documented operator command surface | The archive exposes validation and packaging through Makefile targets. |
| `sha256sum` | `true` | checksum witnesses, manifest review, and release sidecar comparison | publish_preflight.sh verifies MANIFEST.sha256 with sha256sum. |
| `pdflatex` | `false` | optional canonical paper rebuild target | scripts/build_papers.sh rebuilds shipped paper PDFs from TeX sources; this is not required for gate/package replay when PDFs are unchanged. |
| `unzip` | `true` | post-package ZIP integrity witness generation | Release operators use unzip -t as an external compressed-data sanity check. |

## Package policy
- ZIP timestamp: `1980-01-01T00:00:00`
- ZIP compression: `ZIP_DEFLATED`
- ZIP compresslevel: `6`
- ZIP entry order: `lexicographic-shipped-file-order`
- ZIP file mode policy: `regular-file-unix-mode-from-source`
- ZIP extra fields: `forbidden`
- ZIP directory entries: `forbidden`
- Manifest verification command: `sha256sum -c MANIFEST.sha256 >/dev/null`

## Boundary note

The lock intentionally records a minimum-supported replay floor plus observed-version witnesses rather than forbidding newer compatible patch releases.
The package-policy rows are stricter: they must match `scripts/package_release.py` because ZIP identity depends on those constants.
