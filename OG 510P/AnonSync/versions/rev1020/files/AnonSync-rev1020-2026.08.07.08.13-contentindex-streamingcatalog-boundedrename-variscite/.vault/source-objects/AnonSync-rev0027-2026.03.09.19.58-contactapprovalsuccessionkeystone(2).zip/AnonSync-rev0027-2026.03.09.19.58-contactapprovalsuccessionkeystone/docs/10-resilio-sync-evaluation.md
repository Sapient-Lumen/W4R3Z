# Resilio Sync evaluation (deeper pass, revised again)

## Bottom line

Resilio Sync is still a serious reference point.
Its official help center shows Sync v3 releases through `3.1.2.1076` on `31/Oct/2025`, and Resilio's v3 rollout documents also say that Sync v3 functionality is fully available for non-commercial use behind v3 licensing/activation.
So any AnonSync case that depends on “Resilio is abandoned”, “its good features are still gated away from most users”, or “it has no control surface” is weak.

The better question is this:

> Which Resilio ideas are strong enough to preserve, and which exact semantics are the strongest reasons not to clone it?

This revision answers that more operationally.

---

## What Resilio still does unusually well

### 1) It remains maintained enough to matter

Resilio still publishes official Sync v3 release notes, with 3.0.x across 2024-2025 and 3.1.x through late 2025.
That means AnonSync is reacting to a living product, not a dead one.

Implication:

- differentiation must be principled, not dismissive

### 2) The bar is not just “old Free vs old Pro” anymore

Resilio's Sync v3 help pages say the product is available free of charge for non-commercial use and that functionality is fully available for non-commercial use.
That matters because the real competitive bar is a modern convenience-rich product, not a historically more limited free tier.

Implication:

- AnonSync cannot justify itself by assuming formerly premium convenience remains out of reach for ordinary personal users

### 3) Its materialization model is still excellent product design

Resilio's device-facing sync states — `Disconnected`, `Selective Sync`, and `Synced` — answer a very human question directly:

> “How much of this share exists here right now?”

That is more than a UI flourish.
It is a compact user mental model for space, availability, and intent.

AnonSync should keep this idea, though with clearer names and machine-readable state.

### 4) Selective Sync remains one of the best ideas in this category

Selective Sync keeps the directory visible while materializing only requested content and leaving the rest as placeholders.
That is strong because it decouples:

- visibility of a dataset
- membership in a share
- physical materialization of content

This is worth borrowing almost verbatim at the product level, even if AnonSync chooses different placeholder mechanics at first.

### 5) Encrypted folders encode a real and valuable topology

Resilio's encrypted-folder flow supports a practical deployment pattern:

- trusted device stores plaintext
- untrusted device stores ciphertext only
- later trusted device can recover through the encrypted intermediary

That is a real feature, not marketing garnish.
It is one of the strongest reasons AnonSync should include encrypted-untrusted replicas early.

### 6) Advanced folders introduced meaningful PKI-based permissions

Official docs say Standard folders use randomly generated keys while Advanced folders use digital certificates and support features such as on-the-fly permission changes, revoke, owner semantics, and better peer identity treatment.
That is a substantive architectural improvement, not merely a licensing distinction.

This is one of the places where Resilio got the product direction right.

### 7) Linking genuinely reduces user friction

Resilio's linking flow is powerful for personal-device meshes.
Official docs emphasize that linked devices automatically gain visibility of all Sync folders, that approvals can be broadened across linked devices, and that sync mode can be chosen per linked device.
That convenience is real.
We should not understate it.

### 8) It is more scriptable and configurable than a lazy critique suggests

Resilio does expose configuration mode, Linux CLI behavior, Windows command-line switches, WebUI configuration, LAN-only tuning, and power-user preferences.
So the honest criticism is **not** “Resilio cannot be automated.”
The honest criticism is narrower:

- the control surface is partial
- important concepts are distributed unevenly across UI, config, startup flags, and support articles
- the most capable trust semantics are not consistently available from every surface

### 9) Its convenience model still leans on default locations and mode side effects

Resilio's own help docs say that when linked devices are in `Selective Sync` or `Synced` mode, new folders are automatically put into the default folder location. If you want a custom location for a newly visible linked folder, the documented workaround is to switch that device into `Disconnected` mode and then manually click `Connect` for each desired folder. If a same-named folder already exists, Sync can create another copy with an added index.

That is a very revealing product signal.
Resilio *does* offer a fix, but the fix depends on knowing that four separate concepts are coupled together:

- share visibility from linked devices
- local acceptance of that visibility
- default synchronization mode
- default path placement

AnonSync should break those apart.
Visibility should not imply path creation, and path choice should not require a device-global mode change just to handle one share safely.

### 10) Its selective-sync delete semantics are useful, but easy to conflate

Resilio's docs say Selective Sync uses placeholders, that previously synced files can revert to placeholders when deleted, and that the UI distinguishes `Remove from this device` from `Remove from all devices`. Its power-user preferences even include toggles like disabling `Remove from all devices` for selective-sync shares.

This is not evidence that the product is poorly designed. It is evidence that materialization control and distributed deletion are close enough to confuse users unless the surface is very explicit.

AnonSync should therefore avoid ambiguous deletion semantics in its own control surface.
Operators should see separate verbs for:

- fetching content
- evicting local content
- removing local materialization only
- deleting from the replicated share

### 11) Ownership across linked devices is broader than we should want

Resilio's docs explicitly say that when data is shared across your own devices linked to one identity, all of those devices act as Owners.
That is convenient for personal use, but it also collapses what AnonSync should keep distinct:

- being in the same personal constellation
- being allowed to write
- being allowed to re-share
- being allowed to revoke others

AnonSync should not inherit that collapse by default.

### 12) Its restore story still leaks implementation details into the user contract

Resilio's Archive feature is genuinely useful: when a peer updates or deletes a file, other peers can keep the old or deleted copy in `.sync/Archive`, and the default retention is 30 days on desktops and 1 day on mobiles. But the restore flow is still manual: you browse a hidden directory or a desktop UI action, move or copy files back yourself, and the docs warn that Sync should already be running or the restored file may be re-archived on the next rescan as older than the current version.

That is not a fatal flaw. It is a strong signal that restore is still partly modeled as a filesystem ritual instead of a supported control-surface operation.

AnonSync should do better here:

- file history should be queryable
- restore targets and scope should be explicit
- restore should not require knowing hidden on-disk conventions
- restore should emit the same audit/events model as other high-signal mutations

### 13) Important operator state still leaks through hidden service files

Resilio's docs say each synced folder receives a hidden `.sync` folder, that this folder is critical for syncing, and that deleting or moving it causes a `Service files missing` error. The same docs also place `IgnoreList` and `Archive` inside that hidden service directory. Ignore rules are case-sensitive and Resilio explicitly says it is advisable — but not compulsory — to keep the same `IgnoreList` on all peers to avoid confusion about share-size differences.

That is a revealing product signal.
It means important policy and recovery behavior is still partly modeled as:

- hidden files inside the share
- peer-local conventions that may drift
- support knowledge about which service artifacts are safe to touch

AnonSync should reject that as operator contract.
Implementation files may exist, but their meaning should be exposed through supported objects such as:

- ignore-rule sets
- history/versioning policy
- service-health findings
- drift status between intended and observed rule state

### 14) Conflict handling is documented, but still too file-ritual-oriented

Resilio's docs explicitly warn users not to simply delete a `.Conflict` file or folder, because doing so deletes the corresponding real file or folder on the remote peer. Its power-user preferences also document `fix_conflicting_paths`, and warn that disabling it can leave the share unsynced and produce unpredictable results.

This is useful honesty from the vendor.
It is also strong evidence that conflict handling is still too close to magic filenames and support-article lore.

AnonSync should instead model conflicts as first-class cases with:

- stable IDs
- explicit kind (`content`, `case`, `delete-vs-modify`, `path-mapping`)
- candidate versions or paths
- safe resolution actions
- audit and event records for the chosen resolution

### 15) Linked-device least privilege and compatibility still reveal product seams

Resilio's docs say that linked devices under one identity act as Owners for data shared across your own devices, and the documented way to achieve a read-only linked-device result is to use a Standard folder with a Read Only key and manual disconnect/re-add steps.
At the same time, the v3 FAQ says v2 and v3 preserve synchronization compatibility, but linked devices under one identity should all be updated to v3 to avoid license conflicts; the linking guide separately warns that mixed-version linking can lead to lost access to Sync UI and shares configuration.

That combination is revealing.
The product offers real convenience, but two important operator questions still fall out of the main model:

- how do I keep a personal device mesh convenient **without** collapsing least privilege into owner-like authority?
- how do I preview compatibility and downgrade risks **before** linking or adopting a device into the constellation?

AnonSync should treat both as first-class interface concerns.

### 16) Approval memory and delegated approver scope are still too implicit

Resilio's own docs say that by default you only need to approve a person once, because the product retains a certificate with that identity and future folder sharing can then skip approval. The same docs say a remote user can choose to automatically approve all of your linked devices for future sharing after approving one of them, and that you can approve a new peer from any linked device where the folder is already in `Selective Sync` or `Synced` mode. Standard-folder docs separately say that a peer can share the key it has without limitations.

That is not a trivial UX detail.
It means there is a real product concept hiding behind convenience language:

- remembered approval
- delegated future approval
- approver scope across linked devices
- authority that can outlive the original one-off interaction

Resilio benefits from that convenience, but the model is still too implicit for the product AnonSync should become.
AnonSync should expose future approval as a supported object with explicit scope, expiry, approver set, and maximum role.

### 16a) Unknown-contact admission and future introductions still blur into convenience

Resilio's docs say that once devices are linked, all folders become available on all linked devices, that a remote user can choose to automatically approve all of your linked devices for future sharing after approving one device, and that you can approve new peers from any linked device where the folder is already active. The same linking guide still warns that linking already-initialized devices can cause one device to lose its certificate and take over the other device's configured shares.

That combination is revealing.
Resilio has solved a real convenience problem, but it still smears together several things AnonSync should keep distinct:

- relationship memory
- pending contact admission
- future approval scope
- own-device convenience
- successor or replacement continuity

A narrower comparison helps here. Syncthing's docs keep introducer behavior explicit rather than ambient, and its REST API exposes pending remote devices as their own records that can later be removed or ignored. That does **not** make Syncthing AnonSync's model, but it does validate the idea that “unknown peer pending queue” and “bounded automatic introductions” are real first-class seams, not UI garnish.

AnonSync should therefore expose:

- contact records separate from grants
- pending-peer records separate from links
- introduction policy separate from ordinary linking
- successor continuity separate from both ordinary linking and raw device replacement

### 17) Share governance is still too coarse and share-type-dependent

Resilio's docs are clear that in Advanced folders only users with `Owner` permission can invite others or revoke access, while linked devices under one identity all act as Owners for your own-device syncing. Those same docs also say Standard folders have no Owner concept and peers can re-share the key they have without limitation, and local-share docs say Owner access is not possible there and changing access can require remove-and-re-share ritual.

That combination is revealing.
The product has real authority semantics, but they are still spread across:

- one overloaded `Owner` concept in Advanced folders
- no stewardship concept at all in Standard folders
- linked-device convenience that fans authority out very broadly
- local-share edge cases where governance must be reconstructed by re-sharing

AnonSync should not copy that shape.
It should separate:

- data mutation rights
- grant / revoke authority
- delegation bounds
- succession / handoff when a steward departs

A product that wants to be inspectable should expose those as explicit supported state, not as a byproduct of whichever share type happened to be chosen.

### 18) Read-only safety is still bundled too tightly with mode and share-type quirks

Resilio's own docs say read-only peers do support one-way sync, but they also say local attempts to update a file on a read-only peer will stop synchronization for that file. The same docs position `Overwrite any changed files` as the preventative answer: rename, delete, and content edits are reverted, while added files stay local and unsynced. Folder-preferences docs add that this option is potentially destructive, disabled for read-only folders with Selective Sync on, and config-mode docs expose it again as `overwrite changes`. Encrypted-folder docs go further and say encrypted backup peers are read-only, have `Overwrite any changed files` always activated, and do not support Selective Sync.

That is a real product seam.
Resilio clearly has three different concerns in play:

- what authority a peer has (`ro`, `rw`, `owner`, encrypted-only)
- whether local changes should propagate
- what should happen **locally** after an accidental add / modify / delete on a non-authoritative target

But the public surface still bundles them too much.
Depending on how the share was created and mounted, the operator can end up with:

- file-level sync stopping until reviewed
- destructive auto-revert behavior
- preserved but unsynced added files
- selective-sync caveats that remove the overwrite option entirely
- encrypted-replica behavior where overwrite is forced on and selective sync is unavailable

Syncthing's documented send-only / receive-only folder types are useful as a contrast, because they separate propagation posture from local-remediation actions like `Override Changes` and `Revert Local Changes` more explicitly.
AnonSync should go one step further and make local deviation policy a first-class supported object.

---

## Where we should *not* clone Resilio

### 1) Linking expands trust more broadly than AnonSync should allow

This is the most important divergence.
Resilio's docs say that once devices are linked, all folders become visible and accessible on all linked devices, and future approvals can be broadened across linked devices.
That is convenient, but it ties together:

- identity linkage
- access-surface expansion
- approval policy
- default replication posture

AnonSync should separate those concerns.
Linking should create a relationship, not an authority explosion.

### 2) Linking can also replace identities in ways we should explicitly reject

Resilio's linking guide says that if two already-running Sync installations with different certificates are linked, one device can lose its certificate, take the other's certificate, remove Advanced folders from the app, and copy in folders from the other instance.

That is a bright red design signal for AnonSync.
Even if some users tolerate it, this is the opposite of the identity model we should want.

AnonSync should adopt the rule:

> linking never overwrites a local identity; replacement is always a separate, explicit recovery workflow.

### 3) Standard vs Advanced reveals a split product model

Resilio's docs make clear that Standard and Advanced folders have different semantics, and the configuration-mode docs explicitly say that config mode can create only Standard folders, not Advanced folders. Folder preferences are also explicitly desktop-only in the help docs.
That means the product's most capable trust/permission model is not uniformly available across control surfaces or platforms.

This is exactly the kind of split AnonSync should avoid.
If a concept matters, it must exist consistently in:

- CLI
- daemon API
- config/import format
- future UI/TUI

### 4) LAN-only behavior is supported, but not clean enough

Resilio documents how to force LAN-only operation by disabling tracker and relay, enabling LAN multicast, and in some cases clearing cached public endpoint state by temporarily setting peer-expiration to `0`, restarting, then restoring the previous value.
That is useful, but it also shows that transport policy is partly hidden behind retained state and operational workaround.

AnonSync should make discovery and transport state inspectable objects:

- what discovery policy is active
- what addresses were learned
- what cached endpoints exist
- why a given transport path was chosen
- what to clear when changing policy

### 4a) Route controls still blur together publication, dialing, and fallback

Resilio's docs give a careful operator enough information to reconstruct the network model:

- tracker use publishes share-related reachability information so peers can learn each other's IP:ports
- LAN discovery announcements carry ShareIDs plus IP:port on the local network
- predefined hosts are direct dial targets that can work with tracker, relay, and LAN search disabled
- relay use changes the data path when direct reachability fails

That is useful documentation, but it still leaves one crucial product question under-modeled:

> what exactly am I authorizing the product to publish, to whom, and via which infrastructure?

The problem is not merely that Resilio has tracker/relay/LAN/predefined-host knobs.
The problem is that those knobs still mostly speak the language of **transport success**, while a privacy-respecting operator often needs the language of **topology exposure**:

- which services learn this device's public address
- which services learn that this ShareID exists here
- whether the product will announce publicly but dial privately
- whether relays are public, private, or fully forbidden
- whether route fallback can widen metadata exposure even if file contents stay encrypted

AnonSync should not collapse those questions into one discovery toggle.
Publication, dialing, and fallback should be distinct inspectable outcomes.

### 4b) Operators still reconstruct too many decisions from symptoms

Resilio's current docs are helpful, but the explanation path is still scattered.
Folder Preferences says peers are found through tracker, LAN search, predefined hosts, and optional relay fallback. The ports/protocols article explains that Sync learns tracker and relay addresses, publishes local/public addresses and share lists to the tracker, then tries direct TCP/UDP peer connections before switching to relay if necessary. The relay article says a relay-connected peer is shown by a relay icon in the peer list. The main-view and troubleshooting docs say users should click the `X of Y peers` link to inspect peer state and then work through tracker, relay, multicast, firewall, or multi-NIC troubleshooting when things are not connecting.

That is enough to operate the product carefully. It is not yet a strong operator contract. The product is still asking the user to move between:

- final symptoms in the peer list
- route knobs in preferences
- retained-state caveats in support articles
- troubleshooting lore about which candidate path probably failed

For AnonSync, the lesson is not that peer icons are bad. The lesson is that peer icons are insufficient. A serious interface should surface a decision trace for important outcomes such as:

- why a relay route won instead of a direct route
- which direct candidates were tried and why they were rejected
- which publication facts made the chosen route possible
- whether cached endpoints or stale policy state influenced the result
- why a later policy tightening did or did not change the active path

### 4c) Pause and schedule still blur temporary override versus durable intent

Resilio does support useful runtime suppression controls. The docs describe both a global pause button and per-folder pause controls, and the scheduler can apply weekly bandwidth limits or a `Paused` state for selected day/hour cells.

That is real product value. It is not yet a clean operator contract. The same docs also say that when Sync is paused, or scheduled as paused:

- zero-sized files still sync
- file deletions still sync
- new files are still rescanned and indexed
- scheduled-paused peers may still upload to non-paused peers while not downloading

This means “pause” is doing something narrower and stranger than the plain-language label suggests. It mostly suppresses byte transfer, but not all observable share activity, and not always symmetrically. The bandwidth story is also split: Sync Preferences says bandwidth limits apply only to Internet connections by default, and LAN rate limiting requires a separate `rate_limit_local_peers` power-user setting.

For AnonSync, the lesson is not “never pause.” The lesson is that a privacy-respecting operator surface should distinguish at least:

- temporary transfer quiesce
- drain / upload-only shutdown preparation
- temporary throttling
- durable discovery / routing / grant policy
- what expires automatically versus what becomes standing configuration

If the user has to remember that a maintenance window still permits delete propagation, still changes share size through rescans, and may require a different power-user knob for LAN rate limiting, the interface is still overloaded.

There is another useful lesson hiding here. Resilio's support guidance for faster sync still pushes operators toward directness-first tactics such as UPnP/port forwarding and predefined hosts when they want speed. That is evidence that speed pressure is real, not hypothetical. For AnonSync, the answer should not be “pretend nobody will want this.” The answer should be a first-class temporary direct-speed lease that keeps the exception visible and time-bounded instead of letting it silently become the default WAN posture.


### 5) Recovery is not first-class enough

Resilio explicitly says cloning a Sync instance with plain copies, drive cloners, `dd`, or Time Machine is unsupported and may cause strange behavior.
That is understandable from a support perspective, but it leaves a product gap.
Users still need:

- device replacement
- state backup
- trust graph migration
- disaster recovery

AnonSync should not normalize “do a clean install and re-share everything” as the main answer.
Recovery should be a product feature.

### 6) The interface story is still fragmented even when the feature list is good

A careful reading of the docs shows a pattern:

- some controls live in share preferences
- some in advanced preferences / power-user settings
- some in config files
- some in startup flags
- some in WebUI-specific or platform-specific instructions
- some are desktop-only
- some support notes explain how cached state changes the result

That does not make Resilio bad.
It does, however, make it the wrong model for a product whose main reason to exist is inspectable control.


### 7) Least privilege should not require a weaker share type or manual ritual

Resilio's docs show a particularly sharp seam here:

- linked devices acting as Owners is the default personal-mesh convenience
- read-only across linked devices requires dropping to a Standard-folder/read-only-key flow
- Standard folders then lose on-the-fly permission changes and stronger user/owner semantics

That is too much product-model switching for one everyday intent.
AnonSync should preserve one coherent share/grant model while still allowing per-device roles like `readonly-viewer`, `mirror`, or `encrypted-cache`.

### 8) Compatibility warnings should appear before commitment, not after surprise

Resilio's own upgrade/linking docs are candid that linked mixed-version constellations are a bad idea and can cause licensing/configuration trouble.
That is helpful documentation, but the product lesson is sharper:

- link/share/adopt flows should have a supported preflight stage
- preflight should report blockers, warnings, and feature downgrades
- the operator should not need to discover compatibility hazards only after linking or upgrading

### 9) Device-list cleanup and trust retirement are still too easy to confuse

Resilio's docs now make an awkward distinction very explicit:

- you cannot remotely unlink another linked device
- clearing an offline device only hides it from view and the same device will reappear if it comes back online
- uninstall guidance says that if you do not unlink/remove first, the old instance simply keeps showing up as offline on other peers
- changing identity means unlinking locally and generating a new certificate, which also removes Advanced folders from that Sync instance

Those are understandable product choices in isolation, but together they leave too much operator meaning trapped in ritual:

- was this just cosmetic cleanup?
- did we actually revoke trust?
- is the old device still allowed to reconnect if it comes back online?
- was this a replacement with continuity, or a brand-new identity?

Syncthing is helpful here not because it solves everything, but because its public model is crisper in two important ways:

- the device ID is directly derived from the public key / certificate material
- generating or validating config does not silently replace an existing device certificate
- explicit ignored-device state exists as configuration, rather than pretending visibility cleanup and trust retirement are the same thing

That suggests a sharper AnonSync rule:

> retiring, ignoring, revoking, replacing, and rotating are not UI variants of one action; they are different state transitions with different security and continuity consequences.

---

### 10) Share stewardship should not depend on an overloaded Owner bit or share-type ritual

Resilio's docs show a useful but awkward split:

- Advanced folders use `Owner` as the place where write access, grant authority, and revoke authority come together
- linked personal devices broaden that owner-equivalent power across the whole linked set
- Standard folders have no Owner concept and let peers re-share keys without the same bounded governance model
- local shares cannot carry Owner at all and may need remove/re-share steps to change authority

That is enough to build real workflows, but it is too coarse and too mode-dependent for AnonSync's thesis.
The product should let an operator answer more exact questions:

- who may change data?
- who may grant or revoke others?
- who may delegate further?
- who is allowed to hand stewardship to a successor?
- what happens if the current steward leaves or is retired?

If those answers still depend mainly on whether the share happened to be “Advanced”, “Standard”, or “local”, the interface model is not explicit enough.

### 11a) Convergence still arrives through symptoms, warnings, and support lore more than one settlement contract

Resilio's docs are candid about several distinct states that operators must mentally combine:

- `My files don't sync` tells users to inspect `X of Y peers`, status warnings, sync history, and per-peer file queues
- `Time difference` says freshness decisions depend on converted GMT modification times and that more than 600 seconds of skew blocks transfer, with mobile devices even showing an empty list instead of files
- the watcher-exhaustion warning says local changes may no longer be noticed immediately and will only upload after manual or periodic rescan
- `Some internal tasks are taking time to complete` says hidden read/hash/merge/dedup work may still be active even when the system can later recover on its own

Those are individually reasonable diagnostics.
Together they reveal a missing public contract:

- is the share merely idle right now?
- is it fully caught up against currently reachable peers?
- is change detection degraded such that “looks settled” is weaker than usual?
- is hidden background work still changing the answer?
- would a cutover / backup / relocation be acting on trustworthy state or on provisional state?

Syncthing is helpful as a contrast because its public REST and event surfaces explicitly expose folder state, `need*` counts, completion percentages, and folder-completion events.
That is still not a perfect settlement theorem, but it is much closer to a product that treats convergence as supported machine state instead of peer-list inference.

AnonSync should go further and make settlement confidence first-class.

### 11b) File-system and path semantics still leak through conflicts, toggles, and folklore

Resilio's docs still expose an awkward truth about cross-platform syncing: important behavior at the filename and filesystem boundary is partly explained after the fact through conflict files and power-user toggles.
Official docs say conflicts can arise from case-insensitive filesystems, decomposed Unicode, prohibited symbols, linked junctions, and re-adding folders that already contain conflict artifacts.
They also document toggles such as `ignore_symlinks`, `normalize_unicode_paths`, `sync_extended_attributes`, `fix_conflicting_paths`, and `sync_max_time_diff`.

That is useful honesty from the product.
It is also evidence that a serious operator surface should not make people infer compatibility from emergent conflict names or hidden advanced settings.

The deeper problem is not just “some platforms differ.”
The deeper problem is that several distinct questions are easy to conflate:

- can these peers represent the same pathnames without collision
- do they agree on Unicode normalization behavior
- will symbolic links, junction-like entries, xattrs, or ACL-adjacent metadata behave the same way
- what timestamp skew or filesystem granularity will block or distort transfer
- whether a warning is merely advisory, auto-correctable, or a hard blocker for safe adoption

Syncthing is not perfect here either, but its docs point in a cleaner direction.
They explicitly document what kinds of metadata are or are not synchronized, note that support depends on OS and filesystem, expose case-sensitivity safety checks as `caseSensitiveFS`, and expose Unicode normalization handling as `autoNormalize`.
That is still configuration-heavy, but it is much closer to an inspectable public model than conflict-file folklore.

So AnonSync should not clone Resilio's posture here.
It should treat filesystem/path semantics as first-class compatibility state.

## What this forces AnonSync to do

The non-cloning case is now specific enough to generate requirements.

### Requirement 1 — linking must be relationship-only by default

Device linking may simplify discovery and policy installation.
It must **not** automatically imply global folder visibility, owner-equivalent power, or future auto-approval unless those outcomes are explicit policy objects.

### Requirement 2 — replacement must be a recovery workflow, never a side effect

The product must distinguish clearly between:

- adding a device
- linking a device
- replacing a lost device
- rotating or revoking identity

Those must not collapse into one fuzzy “connect this thing” flow.

### Requirement 3 — advanced trust semantics must not be surface-specific

If AnonSync has an advanced trust model, it must be available uniformly from:

- CLI
- daemon API
- config import/export
- future UI/TUI

No “the real model exists in UI only” split.

### Requirement 4 — policy changes must expose retained-state consequences

Changing route/discovery policy must show:

- which live settings changed
- which cached state remains
- whether cache clear is recommended or required
- which peers or shares are affected

### Requirement 5 — incoming handling must be per-share, not hidden behind a device-wide default

The product should distinguish clearly between:

- seeing that a share exists
- accepting or rejecting it for this device
- choosing a local path
- choosing a materialization mode

No operator should need to flip an entire device into a different linked-folder default mode just to place one share carefully.

### Requirement 6 — restore must be a supported interface, not a support ritual

Operators should be able to ask for file history and restore through normal CLI/API surfaces.
The contract must make explicit:

- what candidate versions exist
- whether restore is local-only or replicated back into the share
- whether a plan/review step is required
- which audit/event records were produced

If restore requires hidden archive spelunking, the product has not really exposed the model.

### Requirement 7 — provenance must be queryable

Operators should be able to answer questions like:

- why does this linked group have this auto-grant?
- which profile created this policy?
- which recovery workflow rebound this grant?
- why is this route still being chosen?

If those answers are buried in folklore, the product has already started drifting toward the thing it claims to improve.

### Requirement 8 — ignore and history policy must not live as hidden-service-file folklore

Operators should be able to inspect and change ignore/versioning behavior through supported surfaces.
At minimum the product should expose:

- the effective ignore rules for a share
- whether rule drift exists across peers or local policy layers
- where history/versioning is stored and retained
- whether service-state damage requires repair

Hidden implementation files may still exist on disk, but they should not be the only serious control surface.

### Requirement 9 — conflicts must be first-class records with safe resolution paths

Operators should be able to inspect conflicts as structured cases rather than infer the situation from filenames alone.
The contract should make explicit:

- what conflicted
- which candidates exist
- which resolution would stay local vs affect the replicated share
- which resolution was chosen and why

If the safe answer is still “rename things in the filesystem carefully and hope you understood the support article,” the model is not explicit enough.

### Requirement 10 — path binding must be explicit and compared before merge

Resilio's official docs say a local folder rename only affects that device, moving a share is limited by platform and drive boundaries, reconnect can propose a different default path and create a duplicate-index directory, and connecting a pre-populated folder can merge content while letting the latest timestamp win when same-named files differ.
Syncthing's FAQ reacts in the opposite direction: it says there is no direct move workflow, recommends remove/move/re-add, and warns that if devices are not already in sync the winner after a move can be unpredictable.

Those are two different product choices, but they reveal the same missing contract:

- share identity
- local path binding
- existing on-disk contents
- conflict policy during adoption or relocation

should not be implicitly braided together.

AnonSync should therefore treat adoption into a non-empty path and relocation of an existing mount as compared, reviewable actions.
At minimum the product should expose:

- whether the target path is empty, already bound, or contains service markers for this share or some other share
- which files are identical locally and remotely
- which files are local-only
- which files are remote-only
- which paths are true collisions requiring policy or manual review
- which winner policy would apply, if any
- whether the action is safe only when fully in sync first

If the safe answer is still “point it at the folder and trust the reconnect dialog” or “remove/re-add and hope you timed it correctly,” the interface is not explicit enough.

### Requirement 11 — linked-device convenience must preserve least privilege

Operators should be able to keep a personal-device constellation convenient while still assigning distinct roles such as:

- primary writable device
- read-only viewer
- receive-only mirror
- encrypted replica

No routine intent should require falling back to a weaker share type or manual key ceremony just to avoid owner-like authority.

### Requirement 12 — preflight must be a first-class control surface

Before linking a device, accepting an invite, adopting a share, or applying a role that may degrade capability, the product should support a preview that reports:

- blockers
- warnings
- compatibility/version-family hazards
- feature downgrades
- permission/authority consequences

If the safest answer still lives mainly in release notes, upgrade FAQs, or tribal memory, the operator surface is not explicit enough.

### Requirement 13 — approval memory must be explicit, scoped, and revocable

If the product wants “approve once” convenience, it should still make the remembered approval visible as first-class state.
Operators should be able to inspect:

- which peer or identity was previously approved
- what future shares that approval can cover
- which local devices are allowed to exercise it
- what maximum role or permission it can imply
- when it expires, was used, or was revoked

That is how AnonSync keeps convenience while refusing ambient trust drift.

### Requirement 14 — destructive actions must expose preservation evidence

Before evicting, removing locally, deleting from the share, or restoring back into replicated state, the operator should be able to inspect a preservation report that says:

- what will remain on this device after the action
- how many known plaintext replicas remain and whether any are currently reachable
- whether the remaining copies are only encrypted replicas
- whether version history exists for this path and on which peers
- whether history retention or size caps make that rollback path weaker than it looks
- whether policy blocks the action or requires an elevated acknowledgement because preservation would become too weak

If the operator still has to remember “this menu item is safe, that filesystem delete is not, and the hidden archive may or may not keep a copy depending on file size and platform”, the interface is not explicit enough.

### Requirement 15 — topology policy must expose disclosure, not just route preference

A discovery policy should answer not only:

- can peers connect?
- which route wins?

but also:

- which infrastructure learns this device/share reachability?
- which announcements are local-only vs private-infrastructure-only vs public-infrastructure-visible?
- whether a policy publishes addresses, only dials known targets, or does both
- which fallback step would widen metadata exposure if direct connection fails

If an operator cannot distinguish “announce publicly, dial privately, relay only as last resort” from “never announce publicly at all”, the control surface is still too coarse for the product thesis.

### Requirement 16 — temporary operational changes must be explicit leases

The product should model maintenance intent separately from durable policy.
Operators should be able to inspect:

- what target is under an override
- whether the override blocks upload, download, announcement, or only new transfer starts
- whether scans, indexing, and delete propagation continue
- when the override expires automatically
- who created it and why
- what durable policy resumes when it ends

If a surprising state still gets explained mainly as “that share is paused, except deletions still go through and this LAN rate limit lives somewhere else,” the contract is still too implicit for AnonSync's thesis.

### Requirement 17 — retirement, ignore, revoke, replace, and rotate must be separate supported workflows

Operators should be able to ask for one of these intents explicitly:

- hide an offline device from ordinary views without changing trust
- ignore or suppress future unsolicited contact from a device or identity
- revoke active grants / approval memory / route publication tied to a device
- replace a dead device with a successor while preserving selected continuity
- rotate identity material without pretending it was just cosmetic cleanup

The product should make visible for each retirement action:

- whether the old device can still reconnect
- whether any grants or approval-memory records still reference it
- whether the action is cosmetic, suppressive, revoking, or continuity-preserving
- whether a successor device inherits any role, share visibility, or recovery posture
- what remote cleanup remains impossible until peers observe the retirement

If the operator still has to remember that “hide” is not “unlink”, “unlink” is not “replace”, and “new identity” quietly means “new certificate plus share fallout”, the trust model is not explicit enough.

### Requirement 18 — share stewardship must be explicit, bounded, and transferable

The product should not rely on one coarse Owner bit to carry every governance meaning.
Operators should be able to inspect for each share:

- who currently has data-write rights
- who currently has grant / revoke authority
- whether delegation is allowed and with what bounds
- whether a steward can nominate or pre-approve a successor
- whether a handoff requires quorum, review, or plan/apply
- what happens to grants and approval-memory records if the current steward departs

The product should also support a first-class stewardship record or plan that makes clear:

- the current steward set
- the candidate successor set
- the exact authority to be transferred
- what will remain non-transferable
- what recovery or retirement preconditions must already be satisfied
- which audit and event records will explain the handoff later

If the answer is still “make them Owner”, “re-share with a different key”, or “switch share type and do it again”, the contract is still too coarse for AnonSync's reason to exist.

### Requirement 19 — local deviation policy must be explicit on non-authoritative mounts

The product should not make operators infer local-remediation behavior from a mix of permission level, mount mode, and share type.
For any role or mount that is not supposed to authoritatively propagate local edits, operators should be able to inspect:

- whether local adds are preserved, quarantined, auto-reverted, or blocked pending review
- whether local content edits are preserved-and-flagged, turned into conflict material, or auto-reverted
- whether local deletes are treated as re-fetch, preserved absence pending review, or auto-revert
- whether the system keeps pulling remote updates while local deviation exists
- whether deviation causes a warning, a blocked path, or a review-required state
- whether any part of the policy is forced by capability limits rather than chosen intentionally

The product should also expose that policy in plans, explain surfaces, and role profiles so the operator can answer before attach:

- what happens if someone accidentally edits a supposedly read-only copy
- whether the policy will silently destroy those local edits
- whether a receive-only mirror can keep local forensic evidence without propagating it
- whether an encrypted replica is forced into stricter remediation because of its trust posture
- what exact event or audit record will show that deviation was detected or auto-remediated

If the answer is still “depends whether overwrite is on”, “depends whether selective mode disables the checkbox”, or “depends which share type you happened to start from”, the contract is still not explicit enough.

### Requirement 20 — filesystem compatibility must be a first-class preflight and runtime surface

Case-only collisions, Unicode-normalization mismatches, prohibited symbols, symlink/junction handling, metadata support, and clock/filesystem quirks should not surface only as later conflict files or support-article discoveries.

AnonSync should expose:

- local filesystem profiles for each mount target
- peer/share compatibility reports that classify findings as `ok`, `auto-correctable`, `warning`, or `blocked`
- explicit policy about symlink handling, path normalization, and metadata classes
- explainable downgrade or auto-rewrite behavior where normalization or metadata stripping is unavoidable
- durable findings when a mount is operating under reduced filesystem fidelity

That is a stronger answer than either copying Resilio's folklore-heavy model or merely inheriting Syncthing's advanced-setting vocabulary.

### Requirement 21 — settlement confidence must be explicit and queryable

A sync product should not force operators to guess whether a share is really safe to treat as settled.
At minimum the product should expose:

- transfer completion counts and source availability separately
- whether current convergence is based on healthy continuous change detection or degraded periodic rescan
- whether clock-skew findings make freshness comparison unreliable or blocked
- whether hidden merge / hash / dedup work is still in progress
- whether the daemon considers the share `idle`, `converged`, `degraded-converged`, `blocked`, or `unknown`
- whether a requested barrier such as cutover / backup / relocate / restore has stronger preconditions than ordinary idle status

Resilio's own docs show why this matters: peer counts and status warnings are only part of the picture, watcher exhaustion weakens freshness detection, excessive time difference blocks transfer and can hide files on mobile, and internal background tasks may still be running even when the product can eventually recover.
If the operator still has to combine those clues manually before asking “can I trust this share as a clean handoff point?”, the interface is not explicit enough.

### Requirement 22 — namespace projection and suppression must be explicit

A sync system should distinguish at least four questions:

- is this path part of the share namespace that peers learn about?
- if content is suppressed, do peers still learn the directory shape?
- on this mount, should the path be omitted, shown as placeholder/metadata-only, or fully materialized?
- when a tighter rule is added later, does it leave already-indexed structure visible, require review, or retract it?

Resilio's own docs say `IgnoreList` lives in hidden `.sync`, is case-sensitive, will not work with files that have already been synced, and that once Sync has scanned and indexed the directory tree its structural information is stored in the database and always passed to other peers until the share is disconnected. The same family of docs says Selective Sync presents new files as placeholders, deleting a synced local copy can revert it to a placeholder, and removing the Selective Sync share removes placeholders from that device's filesystem. Those behaviors are individually understandable, but together they still blur ignore, namespace visibility, and materialization.

AnonSync should therefore expose:

- share-level projection rules that decide namespace announcement/suppression
- mount-level projection rules that decide `omit`, `placeholder`, `metadata-only`, or `full` local visibility
- path-test surfaces that answer both questions together for a concrete path
- tighten behavior that says whether already-indexed or already-materialized paths are left alone, reviewed, evicted safely, or blocked pending operator review

If the operator still has to remember that “ignore later stops bytes but not already-indexed structure” while separate placeholder rules still decide what appears locally, the interface is not explicit enough.


### Requirement 23 — bundled privacy transports must still be explicit operator state

If AnonSync ships Tor and I2P inside the product, that does **not** justify making them magical.

The product still needs explicit operator-visible state for:

- which transport engine is present
- whether it is compiled in or activated from an embedded payload
- whether it is currently cold, warming, ready, degraded, or failed
- whether a route was rejected because policy forbade it, because the runtime was cold, or because bootstrap failed
- whether the daemon is using a long-lived transport session or some more transient route strategy

Otherwise “privacy transport support” would remain marketing language rather than a public contract.

### Requirement 24 — Linux-first must name support tiers, not just a philosophy

Saying “Linux is first-class” is still too soft unless the archive names the real v1 support boundary.

AnonSync should therefore publish at least:

- which Linux filesystems are first-class for correctness claims
- which filesystems are probeable but only best effort
- which metadata/ACL/xattr/symlink guarantees are required for strong support
- which environments should surface warnings or blocks before share adoption

That is part of the non-cloning case too.
Resilio can chase broader convenience.
AnonSync earns its keep by being more explicit about what it will support well before it claims broad platform parity.

### Requirement 25 — exposure, dialing, and temporary direct exceptions must be separate supported surfaces

Resilio's current docs make it clear that serious route control exists, but it is spread across multiple mental models:

- tracker / relay / direct path behavior in the network article
- `known_hosts`, `use_tracker`, `use_relay`, and `tunnel_protocols` in power-user preferences
- LAN-only support guidance that still requires cache-clearing rituals if an Internet path was learned before

That is real capability.
It is also exactly the kind of fragmented operator contract AnonSync should not clone.

AnonSync should expose at least four distinct supported surfaces:

- a **publication profile** that answers who can learn this device/share reachability and through which infrastructure
- a **dial policy** that answers which route classes may actually be attempted and in what preference order
- **known-host records** that answer which peer-pinned direct paths are allowed without turning on ambient public direct
- **route leases** that answer which temporary exceptions are active right now and when they end

If the operator still has to reconstruct “what will be published?” by combining one screen, one hidden preference, one cache fact, and one troubleshooting article, the route surface is still too implicit.

### Requirement 26 — peer-pinned direct paths should exist without enabling ambient public direct

Resilio's `folder_defaults.known_hosts` preference is a good clue.
There is real value in saying:

> “I trust **this** peer at **this** address for **this** share or policy window.”

That is not the same thing as saying:

> “public clearnet direct is generally allowed now.”

AnonSync should therefore support peer-pinned direct admission as a first-class concept with:

- peer scope and optional share scope
- explicit provenance and reason
- optional expiry
- visible interaction with the base privacy policy
- explainable effective state when the pin is the reason a route became eligible

That gives AnonSync a better answer than either extreme:

- not “never use direct, ever”
- not “enable public direct and hope the operator remembers why”

### Requirement 27 — temporary bulk-speed exceptions should be bounded by more than vibes

The archive already decided that WAN clearnet direct must not be the default.
This pass adds the stronger follow-through:

- a temporary direct exception should normally carry a **TTL**
- it should also be able to carry an optional **byte cap** or other exhaustion condition
- the route surface should say whether the exception ended because time expired, byte budget was consumed, or the operator canceled it

That matters because “temporary” often stops being temporary when the only bound is human memory.
A bulk-seeding window that automatically collapses after 250 GiB or 90 minutes is much more honest than a toggle the user meant to undo later.

### Requirement 28 — Linux-local semantics should outrank network-share convenience

Resilio's own docs are useful here too.
They say SMB setups can lose immediate notifications and fall back to rescans, that some NAS/SMB patterns can lose or corrupt files, that symlink behavior is platform-dependent, and that xattr syncing still depends on whitelists and hidden service files such as `.sync/StreamsList` and `.sync/Streams`.

That does **not** mean Resilio is bad.
It means AnonSync should resist the temptation to treat remote/network-share convenience as the main design center.

Linux-first should continue to mean:

- local Linux filesystems are the correctness bar
- network filesystems are explicit warning-tier or best-effort targets unless proven otherwise
- metadata fidelity, watcher quality, symlink policy, and xattr contract are supported surfaces, not service-directory folklore

## Where Resilio is still probably the better choice

The archive should also stay honest about where Resilio still looks stronger.

Resilio is probably still the better fit if the operator mainly wants:

- maximum automatic speed from ordinary clearnet direct paths
- a polished, convenience-heavy, multi-platform consumer experience
- less interest in inspectable policy, route provenance, or recovery governance
- less concern about default metadata exposure on WAN routes

That matters because the right AnonSync argument is **not** “Resilio is bad.”
It is:

> Resilio is strong at a different set of defaults, and AnonSync should exist only if it is willing to choose a sharper privacy/control model all the way down.

## Final judgment

Resilio Sync remains strong enough that cloning it naïvely would produce an impressive but strategically muddled product.
The better move is narrower and more opinionated:

> preserve Resilio's best user-facing ideas, but replace its trust-broadening linkage semantics and fragmented operator surface with explicit policies, explicit publication and exposure reports, explicit known-host records, explicit route leases for temporary direct exceptions, explicit provenance, explicit recovery, explicit preservation reports for destructive actions, explicit retirement records for trust-changing device exits, explicit stewardship records for share governance and handoff, explicit deviation policies for non-authoritative local edits, explicit filesystem-compatibility reports before real paths are bound, explicit projection policies that separate share namespace announcement from local mount visibility, and explicit convergence reports that separate idle status from trustworthy settlement confidence.



### Requirement 29 — contacts, pending peers, and future introductions must be separate public state

Unknown or newly introduced peers should not silently become trusted, linked, or visible-share-bearing just because the operator wanted convenience elsewhere in the constellation. Contact memory, pending-peer admission, ignore/quarantine, and bounded introduction policy should all be separate supported objects.

### Requirement 30 — successor continuity must be reviewed rather than inherited by convenience

Device replacement should be able to carry forward exactly the right things — perhaps some grants, perhaps no future approvals, perhaps limited contact memory — without pretending that successor continuity is the same as either linking or identity takeover.