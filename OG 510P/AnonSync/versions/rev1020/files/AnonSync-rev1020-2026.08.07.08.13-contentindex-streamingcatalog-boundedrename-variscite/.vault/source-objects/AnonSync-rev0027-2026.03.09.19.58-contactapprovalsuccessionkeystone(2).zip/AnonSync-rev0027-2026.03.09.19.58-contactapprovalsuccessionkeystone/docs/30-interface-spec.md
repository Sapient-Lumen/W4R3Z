# Interface spec (v1 draft, operator surface)

## Design principles

1. **One daemon, one shared model.**
   CLI, API, UI, and TUI are clients of the same object graph.

2. **Everything important is addressable.**
   Devices, shares, grants, mounts, policies, invites, claims, transfers, backups, recovery bundles, plans, and events all have stable IDs.

3. **Human by default, machine on demand.**
   Read commands support `--json`; watch commands support stream output.

4. **States describe local reality.**
   Prefer `detached`, `selective`, `full`, `metadata-only`, `partial`, `complete`, `encrypted-only`.

5. **Linking is not replacement.**
   Linking can create relationships and install policies; it never overwrites local identity.

6. **Transport and publication are visible policy.**
   Relay, tracker, LAN discovery, known-host pinning, address publication, and endpoint cache are first-class configuration.

7. **Recovery is part of the primary surface.**
   Backup, import, replacement, rotation, and revocation are not “support-only” edge cases.

8. **Convenience must compile to explicit policy.**
   Profile-driven flows may exist, but their effects must be inspectable and reversible.

9. **High-signal mutations should be previewable and replay-safe.**
   When an operation can widen trust, rebind identity, or change recovery posture, the interface should prefer `plan -> review -> apply` over blind fire-and-forget mutation.

10. **Visibility is staged before local path adoption.**
   A share becoming visible through linking or policy should not silently create a path. Incoming visibility is an explicit object that can later be adopted.

11. **File scope must be explicit.**
   Fetching, evicting local bytes, and deleting replicated data are separate operations with separate verbs.

12. **Restore must be first-class.**
   Version history and restoration should be exposed through normal commands, not hidden archive spelunking.

13. **Hidden service files are implementation detail.**
   Ignore rules, conflict cases, and service metadata should be inspectable through supported surfaces rather than ad hoc filesystem rituals.

14. **Compatibility and privilege consequences should be previewable.**
   Linking, adoption, and role changes should expose blockers, downgrade warnings, and authority consequences before commitment.

15. **Offers and recovery material should be inspectable.**
   Invites, visible share offers, and recovery prerequisites should be supported objects rather than hidden side effects or log archaeology.

16. **Path binding is a compared action.**
   Adopting a share into a path or relocating an existing mount into a non-empty path should expose comparison results, collision classes, and explicit winner policy before commit.

17. **Destructive actions need preservation evidence.**
   Eviction, local remove, share-wide delete, and share-scope restore should expose replica/history coverage before apply.

18. **Retirement intent must be explicit.**
   Hiding an offline device, ignoring future contact, revoking trust, replacing hardware, and rotating identity are distinct operations with distinct audit and continuity consequences.

19. **Filesystem compatibility is supported state.**
   Case rules, Unicode normalization, symlink handling, metadata fidelity, and path-safety blockers should be inspectable before and after adoption.

20. **Namespace projection is explicit.**
   Share-wide namespace suppression, local mount-view omission, placeholder-visible projection, and byte materialization should not be inferred from one overloaded ignore rule.

21. **Unknown peers are staged before trust.**
   New or newly introduced peers should first land in contact or pending state; linking, granting, and future approval should remain separate decisions.

---

## Command-language rules

### Naming

Binary name:

```text
anonsync
```

Resource names should be stable, lower-case, and shell-friendly where possible.
User-facing labels can be richer, but selectors should prefer simple handles.

### Selectors

Every object should be addressable by one of:

- stable ID
- unique local handle/label
- path, where path is the natural selector
- local token file or bundle path, where the object naturally originates from an artifact

If a selector is ambiguous, the command must fail with an ambiguity error rather than guessing.

Examples:

```text
anonsync share show workdocs
anonsync share show shr_01J...
anonsync mount show ~/Sync/workdocs
```

### Read vs mutate

Read commands:

- default to human-readable output
- support `--json`
- never have side effects

Mutating commands:

- support `--json`
- support `--yes` for non-interactive mode
- should support `--reason <text>` for auditability on sensitive operations
- should support `--profile <name>` when invoking convenience presets
- should support `--plan` when the command class is high-signal

### Preview levels

Three preview forms are useful:

```text
--dry-run
--plan
anonsync plan show <plan_id>
```

Semantics:

- `--dry-run` is an inline preview for simple local changes
- `--plan` creates a durable plan object for review and later apply
- `plan show` renders the same intent as a first-class object with preconditions and drift boundaries

The preview output must explain:

- which objects would change
- which policies would be created or updated
- whether trust scope would expand
- whether route/cache state is affected
- whether any action becomes hard to undo without recovery or revoke
- for destructive file actions, what preservation evidence exists or is missing after the action

### Preconditions and drift

High-signal apply paths should support precondition checks.
At minimum the contract should include:

- expected object version
- expected identity status where relevant
- expected policy revision where relevant

If the world changed after the preview was generated, apply must fail loudly rather than silently reinterpret the request.

### Explainability

For important objects, the CLI should support at least one of:

```text
--explain
--show-provenance
anonsync audit --subject <id>
```

The goal is that an operator can answer:

- why this grant exists
- why this route is active
- which serious route candidates were rejected and why
- what this policy currently publishes about reachability
- which profile created this policy
- which recovery step rebound this device or share state

### Exit status

A minimal exit-code contract:

- `0` success
- `1` generic failure
- `2` usage / selector ambiguity / invalid flags
- `3` policy violation / trust boundary rejection
- `4` remote or peer state prevents completion
- `5` recovery flow required
- `6` precondition failed / plan drifted

The richer machine contract is the structured error code emitted under `--json`.

---

## Concept model

### Device

A locally controlled node with its own keypair and daemon state.

Fields:

- `device_id`
- `display_name`
- `trust_class` (`trusted`, `untrusted`, `relay`)
- `identity_status` (`normal`, `rotating`, `revoked`, `replaced`)
- `addresses[]`
- `capabilities[]`
- `software_version`
- `protocol_family`
- `compatibility_status` (`unknown`, `ok`, `warning`, `blocked`)
- `last_seen`
- `linked_group_id` nullable
- `retirement_status` (`active`, `hidden`, `ignored`, `revoking`, `replaced`, `retired`)

### Contact record

A durable relationship-memory object for a peer or potential peer.
This exists so “someone I know”, “someone I linked”, “someone currently pending”, and “someone explicitly ignored” are not collapsed into one overloaded device row.

Fields:

- `contact_id`
- `primary_device_id` nullable
- `display_name`
- `relationship_class` (`self-device`, `known-peer`, `collaborator`, `unknown`)
- `contact_state` (`pending`, `trusted`, `quarantined`, `ignored`, `revoked`)
- `linked_group_id` nullable
- `future_introduction_policy` (`disabled`, `share-scoped`, `bounded`, `review-required`)
- `approval_summary`
- `last_seen_identity_refs[]`
- `successor_policy` (`none`, `manual-review`, `carry-limited`, `carry-all-with-review`)
- `provenance_ref` nullable

### Pending peer

A first-class queue record for an unknown or newly introduced peer that has tried to contact this node or announce a share relationship.

Fields:

- `pending_peer_id`
- `observed_device_id` nullable
- `observed_name` nullable
- `source` (`manual-invite`, `share-announcement`, `linked-introduction`, `recovery`, `direct-contact`)
- `linked_group_hint` nullable
- `candidate_contact_id` nullable
- `offered_actions[]` (`trust-contact`, `link`, `claim-share`, `ignore`, `quarantine`)
- `expires_at` nullable
- `decision_status` (`pending`, `accepted`, `dismissed`, `ignored`, `quarantined`)
- `provenance_ref` nullable

### Introduction policy

A bounded policy describing when one trusted device or linked group may surface additional peers without silently turning those peers into full trust.

Fields:

- `introduction_policy_id`
- `scope_type` (`link`, `share`, `tag`)
- `scope_id`
- `mode` (`disabled`, `pending-only`, `share-scoped`, `bounded-auto-link`)
- `max_permission` (`none`, `ro`, `rw`)
- `requires_claim` boolean
- `requires_preflight` boolean
- `auto_visible_share_limit` (`none`, `matched-only`)
- `provenance_ref` nullable

### Share

A logical synchronized dataset.

Fields:

- `share_id`
- `label`
- `origin_device`
- `default_mode` (`detached`, `selective`, `full`)
- `write_policy` (`send-receive`, `send-only`, `receive-only`)
- `encryption_policy` (`plaintext`, `encrypted-at-rest-on-untrusted-peers`)
- `discovery_policy_id`
- `conflict_policy`
- `versioning_policy`
- `ignore_policy_id`
- `projection_policy_id` nullable

### Grant

A permission relationship between a share and a device or policy group.

Fields:

- `grant_id`
- `share_id`
- `subject_type` (`device`, `linked-group`, `tag`)
- `subject_id`
- `permission` (`ro`, `rw`, `owner`, `encrypted-replica`)
- `reshare_capability` (`none`, `delegate`, `admin`)
- `mount_mode_cap` (`detached`, `selective`, `full`)
- `role_id` nullable
- `created_by`
- `created_at`
- `origin` (`manual`, `policy`, `invite`, `recovery`)
- `provenance_ref` nullable


### Role profile

A reusable least-privilege bundle for grants and local adoption.
The point is to keep one coherent share/grant model while still supporting roles like read-only viewer, receive-only mirror, or encrypted cache.

Fields:

- `role_id`
- `label`
- `permission`
- `write_policy_cap` (`send-receive`, `send-only`, `receive-only`)
- `mount_mode_cap` (`detached`, `selective`, `full`)
- `plaintext_access` (`allowed`, `forbidden`)
- `reshare_capability` (`none`, `delegate`, `admin`)
- `deviation_policy_cap[]`
- `provenance_ref` nullable

### Deviation policy

A first-class policy describing what happens when a non-authoritative local target is changed anyway.
This exists so read-only, receive-only, mirror, and encrypted-replica behavior is not inferred from a fragile mix of role, mode, and share type.

Fields:

- `deviation_policy_id`
- `label`
- `allowed_write_policy[]` (`send-only`, `receive-only`, `encrypted-replica`)
- `on_local_add` (`preserve-and-flag`, `quarantine`, `auto-revert`, `block-pending-review`)
- `on_local_modify` (`preserve-and-flag`, `conflict-copy`, `auto-revert`, `block-pending-review`)
- `on_local_delete` (`preserve-and-flag`, `re-fetch`, `auto-revert`, `block-pending-review`)
- `remote_progress_when_deviated` (`continue-with-warning`, `pause-path`, `review-required`)
- `forced_by_capability` boolean
- `provenance_ref` nullable

### Stewardship record

A first-class record describing who governs a share and how authority can be handed off.
This exists so write access, grant power, and succession are not inferred from one coarse Owner bit.

Fields:

- `stewardship_id`
- `share_id`
- `steward_set[]`
- `grantor_set[]`
- `delegation_policy` (`none`, `bounded`, `open-with-cap`)
- `max_delegable_role` nullable
- `handoff_policy` (`single-steward-approval`, `dual-review`, `quorum`, `recovery-gated`)
- `candidate_successors[]`
- `departure_behavior` (`freeze-grants`, `retain-existing`, `rebind-to-successor`, `require-review`)
- `active_handoff_plan_id` nullable
- `created_at`
- `updated_at`
- `provenance_ref` nullable

### Mount

A local attachment of a share into a filesystem path. Adoption into a mount is a separate step from merely learning that the share exists.

Fields:

- `mount_id`
- `share_id`
- `path`
- `materialization_mode` (`detached`, `selective`, `full`)
- `placeholder_strategy` (`none`, `virtual`, `sidecar`)
- `pin_policy` (`manual`, `sticky`, `always-full`)
- `binding_status` (`bound`, `relocating`, `drifted`, `blocked`)
- `deviation_policy_id` nullable
- `projection_policy_id` nullable
- `path_binding_provenance_ref` nullable


### Incoming share

A share exposure that is visible locally but not yet adopted into a path.
The lifecycle is intentionally staged:

- `visible` — the share is known through linking, manual share, or recovery policy
- `incoming` — the operator can inspect and decide what to do locally
- `adopted` — the share is attached to a local path as a mount

This separates discovery from acceptance and path placement.

Fields:

- `incoming_id`
- `share_id`
- `source_device`
- `visibility_origin` (`manual-share`, `linked-policy`, `recovery`)
- `suggested_label`
- `suggested_path` nullable
- `default_mode_offer` (`detached`, `selective`, `full`)
- `adoption_status` (`pending`, `adopted`, `rejected`, `deferred`)
- `requires_path_choice`
- `provenance_ref` nullable


### Path comparison

A durable comparison report for adopting or relocating a share into a target path.
This exists so non-empty-path binding is reviewable instead of guessed from later file outcomes.

Fields:

- `comparison_id`
- `share_id`
- `target_path`
- `source_ref` (`incoming`, `mount`)
- `source_id`
- `path_state` (`missing`, `empty`, `non-empty`, `already-bound-self`, `already-bound-other`, `service-marker-conflict`)
- `identical_count`
- `local_only_count`
- `remote_only_count`
- `collision_count`
- `marker_status` (`ok`, `missing`, `foreign`, `conflicting`)
- `recommended_action` (`safe-bind`, `plan-required`, `blocked`)
- `generated_at`
- `provenance_ref` nullable


### Filesystem profile

A machine-readable summary of a local mount target's path and metadata semantics.
The point is to stop treating case collisions, normalization drift, symlink behavior, and metadata loss as after-the-fact surprises.

Fields:

- `fs_profile_id`
- `path`
- `platform_family`
- `filesystem_type`
- `case_sensitivity` (`sensitive`, `insensitive`, `unknown`)
- `unicode_normalization` (`none`, `nfc`, `nfd`, `mixed`, `unknown`)
- `utf8_requirement` (`required`, `best-effort`, `unknown`)
- `prohibited_name_rules[]`
- `prohibited_character_rules[]`
- `symlink_support` (`preserve`, `ignore`, `blocked`, `unknown`)
- `junction_support` (`preserve`, `flatten`, `blocked`, `unknown`)
- `xattr_support` (`full`, `partial`, `none`, `unknown`)
- `acl_support` (`full`, `partial`, `none`, `unknown`)
- `permission_fidelity` (`full`, `partial`, `minimal`, `unknown`)
- `timestamp_precision` (`ns`, `us`, `ms`, `s`, `unknown`)
- `clock_status` (`ok`, `warning`, `blocked`, `unknown`)
- `special_file_policy` (`ignore`, `preserve-subset`, `blocked`)
- `observed_at`
- `provenance_ref` nullable

### Filesystem compatibility report

A durable report comparing one or more filesystem profiles against the pathname and metadata demands of a share or mount action.
This exists so operators can see whether path semantics are safe before bind, adopt, restore, or role changes commit.

Fields:

- `fs_compat_report_id`
- `target_action` (`incoming-adopt`, `mount-relocate`, `grant`, `restore`, `share-set`)
- `share_id` nullable
- `subject_refs[]`
- `fs_profile_refs[]`
- `status` (`ok`, `auto-correctable`, `warning`, `blocked`)
- `path_findings[]`
- `metadata_findings[]`
- `normalization_actions[]`
- `blocked_patterns[]`
- `recommended_policy_changes[]`
- `generated_at`
- `provenance_ref` nullable

### Convergence report

A durable report describing whether current share state is merely idle, transfer-complete, or trustworthy enough to treat as settled for a specific purpose.
This exists so operators do not infer cutover safety from peer counts and warning badges alone.

Fields:

- `convergence_report_id`
- `target_scope` (`share`, `mount`, `device`, `system`)
- `target_ref`
- `intent` (`status`, `cutover`, `backup`, `relocate`, `restore`, `maintenance-drain`)
- `state` (`idle`, `syncing`, `converged`, `degraded-converged`, `blocked`, `unknown`)
- `local_need_bytes`
- `local_need_items`
- `remote_need_bytes` nullable
- `remote_need_items` nullable
- `reachable_sources`
- `required_sources`
- `watcher_health` (`ok`, `degraded`, `unknown`)
- `clock_health` (`ok`, `warning`, `blocked`, `unknown`)
- `background_work` (`none`, `hashing`, `merging`, `dedup-copy`, `mixed`, `unknown`)
- `detection_mode` (`continuous`, `periodic-rescan`, `mixed`, `unknown`)
- `blocking_findings[]`
- `confidence` (`high`, `medium`, `low`, `none`)
- `recommended_wait` nullable
- `generated_at`
- `provenance_ref` nullable

### Ignore policy

A supported rule set that controls what the local daemon ignores for a share.
The point is not only filtering.
The point is that ignore behavior should be inspectable and mutable without editing hidden dotfiles.

Fields:

- `ignore_policy_id`
- `projection_policy_id` nullable
- `share_id`
- `consistency_mode` (`local-ok`, `warn-on-drift`, `require-match`)
- `rules[]` (stable rule objects)
- `default_rule_source` (`built-in`, `profile`, `import`)
- `drift_status` (`unknown`, `in-sync`, `drifted`)
- `provenance_ref` nullable

### Projection policy

A first-class rule set that controls share-wide namespace announcement or local mount-view projection.
This exists so operators can tell the difference between:

- suppressing a path from the share namespace peers learn about
- hiding a path only on one local mount
- showing a path as placeholder/metadata-only instead of fully materialized bytes
- tightening a rule after structure or bytes already exist

Fields:

- `projection_policy_id`
- `subject_type` (`share`, `mount`)
- `subject_id`
- `rule_ordering` (`first-match`)
- `default_namespace_visibility` (`visible`, `hidden`) nullable
- `default_remote_announcement` (`announce`, `suppress`) nullable
- `default_local_projection` (`omit`, `placeholder`, `metadata-only`, `full`) nullable
- `tighten_behavior` (`no-retrochange`, `review-existing`, `evict-existing-safe`, `block-until-reviewed`)
- `rules[]` (stable rule objects with match, namespace_visibility, remote_announcement, local_projection)
- `drift_status` (`unknown`, `in-sync`, `drifted`)
- `provenance_ref` nullable

### Conflict item

A structured record of a detected conflict or path collision.
Conflicts are first-class cases, not just filenames with a suffix.

Fields:

- `conflict_id`
- `share_id`
- `path`
- `kind` (`content`, `case`, `delete-vs-modify`, `path-mapping`)
- `status` (`open`, `resolved`, `deferred`)
- `candidates[]`
- `recommended_actions[]`
- `detected_at`
- `provenance_ref` nullable

### Invite

A capability-bearing token or file used to add a device to a share or constellation.
The invite is the offered capability, not the acceptance itself.

Fields:

- `invite_id`
- `target_scope` (`device-link`, `share-access`)
- `permissions`
- `expiry`
- `one_time`
- `peer_pinning`
- `transport_hints[]`
- `offered_role_id` nullable
- `claim_required` (`true`, `false`)

### Claim

A durable acceptance record prepared from an invite or incoming share before it mutates local state.
Claims exist so operators can inspect the difference between “this was offered” and “this machine accepted it this way.”

Fields:

- `claim_id`
- `source_type` (`invite`, `incoming`)
- `source_ref`
- `target_action` (`link`, `grant`, `incoming-adopt`)
- `requested_role_id` nullable
- `requested_path` nullable
- `requested_mode` nullable
- `status` (`draft`, `preflighted`, `planned`, `applied`, `rejected`, `expired`)
- `compatibility_report_id` nullable
- `provenance_ref` nullable

### Approval memory

A durable record that some future approvals may proceed without a fresh prompt, but only within bounded scope.
This exists so “approved before” is inspectable state rather than hidden certificate memory.

Fields:

- `approval_id`
- `subject_identity_ref`
- `granted_by_ref`
- `scope` (`share`, `share-tag`, `linked-group`)
- `scope_ref` nullable
- `max_role_id` nullable
- `max_permission` (`ro`, `rw`, `owner`, `encrypted-replica`)
- `approver_scope` (`origin-only`, `linked-group`, `named-devices`)
- `approver_devices[]`
- `expires_at` nullable
- `status` (`active`, `revoked`, `expired`)
- `last_used_at` nullable
- `provenance_ref` nullable

### Linked-group policy

A reusable policy that defines what linking should and should not imply.

Fields:

- `linked_group_id`
- `label`
- `default_mount_mode`
- `auto_grant_rule` (`none`, `prompt`, `tagged-shares-only`, `all-new-shares`)
- `max_permission` (`ro`, `rw`)
- `allow_share_visibility_without_mount` (`true`, `false`)


### Compatibility report

A durable preview object that explains whether a pending link, invite acceptance, grant, or adoption action is safe to commit.

Fields:

- `report_id`
- `target_action` (`link`, `invite-accept`, `grant`, `incoming-adopt`, `share-set`)
- `subject_refs[]`
- `status` (`ok`, `warning`, `blocked`)
- `blockers[]`
- `warnings[]`
- `downgrades[]`
- `authority_changes[]`
- `recommended_roles[]`
- `generated_at`
- `provenance_ref` nullable

### Publication profile

A first-class supported summary of what the daemon publishes about reachability.
This may exist as its own object or as a supported nested object inside discovery policy, but it must be inspectable directly.

Fields:

- `publication_profile_id`
- `scope_type` (`system`, `policy`, `share`)
- `scope_id` nullable
- `publish_presence_via[]` (`lan`, `private-discovery`, `public-tracker`, `tor-onion`, `i2p-destination`)
- `publish_endpoint_classes[]` (`lan-addresses`, `approved-known-hosts`, `tor-onion`, `i2p-destination`)
- `share_membership_visibility` (`none`, `approved-peers-only`, `discovery-service-visible`)
- `endpoint_cache_policy` (`disabled`, `ephemeral`, `retained-with-ttl`, `retained-until-cleared`)
- `clear_cache_on_narrowing` (`true`, `false`)
- `provenance_ref` nullable

### Known-host record

A peer-pinned direct-path admission record.
This exists so “I trust this peer at this address” does not silently widen into “public direct is generally allowed now”.

Fields:

- `known_host_id`
- `peer_id`
- `address`
- `scope_type` (`system`, `policy`, `share`, `peer-share`)
- `scope_id` nullable
- `allowed_use` (`dial-only`, `dial-and-accept`)
- `origin` (`manual`, `recovery`, `import`, `policy-derived`)
- `created_by`
- `created_at`
- `expires_at` nullable
- `last_verified_at` nullable
- `health_state` (`unknown`, `reachable`, `stale`, `failed`)
- `provenance_ref` nullable

### Exposure report

A supported preview/status object that answers what reachability facts are currently being published and which steps would widen exposure.

Fields:

- `exposure_report_id`
- `subject_type` (`policy`, `share`, `peer`, `route`)
- `subject_id`
- `baseline_publication_profile_ref`
- `active_route_leases[]`
- `currently_published_to[]` (`lan`, `approved-peer`, `private-infra`, `public-infra`)
- `published_endpoint_classes[]`
- `candidate_route_classes[]`
- `widening_steps[]`
- `cached_endpoint_findings[]`
- `recommended_actions[]`
- `generated_at`
- `decision_trace_ref` nullable

### Discovery policy

How peers are found, what reachability is published, and how fallback is handled.
A serious operator surface must separate announcement from dialing.
It must also distinguish overlay-first privacy routing from faster clearnet direct options.

Fields:

- `discovery_policy_id`
- `announce_scope` (`off`, `lan-only`, `private-infra-only`, `public-ok`)
- `announce_via[]` (`lan`, `tracker`, `private-discovery`, `tor-onion`, `i2p-destination`)
- `dial_via[]` (`known-host-clearnet`, `lan-direct`, `public-direct`, `private-relay`, `public-relay`, `tor`, `i2p`)
- `tracker_mode` (`enabled`, `disabled`, `private-only`)
- `relay_mode` (`enabled`, `disabled`, `trusted-only`, `private-only`)
- `relay_pool` (`public`, `private`, `mixed`, `none`)
- `tor_mode` (`disabled`, `allowed`, `preferred`, `required`)
- `i2p_mode` (`disabled`, `allowed`, `preferred`, `required`)
- `lan_discovery` (`enabled`, `disabled`)
- `clearnet_direct_mode` (`disabled`, `manual-opt-in`, `allowed`)
- `manual_speed_override_scope` (`none`, `per-share`, `per-peer`, `per-device`, `per-policy`)
- `known_hosts[]`
- `listen_addresses[]`
- `fallback_order[]`
- `cache_public_endpoints` (`enabled`, `disabled`)
- `accept_inbound_from` (`approved-peers`, `known-hosts-only`, `policy-bound`)
- `transport_runtime_refs[]`
- `exposure_summary_ref` nullable
- `decision_trace_ref` nullable

Notes:

- the default WAN-oriented privacy policy should prefer Tor and/or I2P before any public direct path
- WAN clearnet direct should require manual enablement rather than silently participating by default
- a policy may still allow LAN direct as a normal local-network behavior without enabling WAN clearnet direct

### Transport runtime

A supported object describing one transport engine that the daemon can use or activate.
This exists so bundled privacy transports do not become hidden magic.

Fields:

- `transport_runtime_id`
- `engine` (`lan`, `clearnet`, `tor`, `i2p`)
- `integration_kind` (`native`, `embedded-helper`)
- `binary_origin` (`compiled-in`, `embedded-payload`, `system-external`)
- `lifecycle_state` (`off`, `lazy`, `warming`, `ready`, `degraded`, `failed`)
- `version`
- `runtime_path` nullable
- `payload_version` nullable
- `payload_digest` nullable
- `persistence_dir` nullable
- `update_mode` (`daemon-release-only`, `independent-payload`, `external-managed`)
- `provenance_summary` nullable
- `last_verified_at` nullable
- `policy_disable_reason` nullable
- `runtime_owner` (`daemon`, `external`, `shared`)
- `bootstrap_state` (`not-required`, `pending`, `in-progress`, `ready`, `degraded`, `failed`)
- `health_findings[]`
- `last_started_at` nullable
- `last_failed_at` nullable
- `decision_trace_ref` nullable

### Transport session

A public object describing how a transport runtime is currently being used for real route work.

This exists because an operator should be able to distinguish:

- “Tor is installed”
- “Tor is warm”
- “Tor is currently carrying these routes”
- “I2P is warm but only one long-lived session is being reused for this share class”
- “clearnet direct is active only because a manual speed override created a temporary route lease”

Fields:

- `transport_session_id`
- `engine` (`tor`, `i2p`, `clearnet`)
- `runtime_ref`
- `scope_type` (`system`, `policy`, `share`, `peer`)
- `scope_id` nullable
- `session_strategy` (`singleton`, `shared-pool`, `dedicated`)
- `privacy_class` (`overlay`, `local-direct`, `wan-direct`)
- `state` (`planned`, `opening`, `ready`, `active`, `cooling`, `degraded`, `failed`)
- `identity_scope` (`system`, `policy`, `share`, `peer`, `implementation-defined`)
- `endpoint_summary`
- `reuse_policy` (`reuse-preferred`, `reuse-required`, `ephemeral-ok`)
- `opened_at`
- `last_used_at` nullable
- `active_route_count`
- `reason`
- `decision_trace_ref` nullable

Notes:

- I2P should usually prefer a very small number of long-lived shared sessions rather than per-transfer session churn
- public WAN clearnet direct should normally appear only through an explicit override or policy exception
- LAN direct may still be ordinary and non-alarming within a local-only policy

### Decision trace

A structured explanation for why a high-signal outcome won.

Fields:

- `decision_trace_id`
- `subject_type` (`route`, `grant`, `approval`, `claim`, `restore`, `mount-bind`, `recovery`)
- `subject_id`
- `decision_kind` (`selection`, `authorization`, `adoption`, `restore-scope`, `rebind`)
- `selected_outcome`
- `candidate_outcomes[]`
- `rejected_candidates[]` with `reason_code`, `reason_text`
- `facts[]` (`policy`, `capability`, `cache`, `precondition`, `operator-choice`)
- `policy_refs[]`
- `cache_refs[]`
- `generated_at`
- `stale_at` nullable
- `provenance_ref` nullable

### Preservation report

A structured safety summary for a risky file mutation.

Fields:

- `preservation_report_id`
- `share_id`
- `path`
- `for_action` (`evict`, `remove-local`, `remove-share`, `restore-share`)
- `current_materialization` (`placeholder`, `partial`, `full`, `absent`)
- `local_state_after_action` (`placeholder`, `present`, `absent`)
- `known_plaintext_replicas`
- `known_plaintext_online`
- `known_encrypted_replicas`
- `history_candidates`
- `history_retention_summary` nullable
- `history_gaps[]` (`none-configured`, `ttl-short`, `size-cap`, `remote-only`, `offline-uncertain`)
- `risk_level` (`low`, `guarded`, `high`, `blocked`)
- `blockers[]`
- `recommended_safer_actions[]`
- `generated_at`
- `decision_trace_ref` nullable

### Route lease

A temporary route or exposure exception that sits on top of durable discovery policy.
This is narrower than the generic maintenance override because it exists specifically for transport/exposure changes such as temporary direct-speed windows.

Fields:

- `route_lease_id`
- `effect` (`allow-public-direct`, `prefer-known-host`, `prefer-overlay`, `suspend-public-discovery`, `drain-route-class`)
- `subject_type` (`system`, `policy`, `share`, `peer`, `peer-share`)
- `subject_id` nullable
- `peer_id` nullable
- `known_host_ref` nullable
- `reason`
- `created_by`
- `created_at`
- `expires_at` nullable
- `byte_cap` nullable
- `transfer_cap` nullable
- `exhaustion_policy` (`expire`, `re-evaluate`, `hold-until-cancelled`)
- `effective_state_ref`
- `provenance_ref` nullable

Notes:

- a direct-speed lease should normally have a TTL and may additionally have a byte cap
- route output should say whether a public-direct candidate is eligible only because of a route lease
- policy reads should distinguish durable baseline from lease-modified effective state

### Override lease

A temporary runtime change that sits **on top of** durable policy without silently rewriting it.

Fields:

- `override_id`
- `target_type` (`system`, `device`, `share`, `mount`, `policy`)
- `target_id` nullable
- `mode` (`pause-transfer`, `drain-egress`, `suspend-ingress`, `throttle`, `maintenance`)
- `effects[]` (`block-download`, `block-upload`, `allow-inflight-upload`, `allow-scan`, `allow-index-publish`, `allow-delete-propagation`)
- `rate_caps` nullable
- `reason`
- `created_by`
- `created_at`
- `expires_at` nullable
- `cancelable`
- `effective_state_ref`

### Retirement record

A first-class record describing how a device or identity is being exited from the mesh.
This exists so cosmetic cleanup, ignored contact, trust revocation, successor replacement, and identity rotation are not conflated.

Fields:

- `retirement_id`
- `subject_type` (`device`, `identity`)
- `subject_id`
- `intent` (`hide`, `ignore`, `revoke`, `replace`, `rotate-identity`)
- `status` (`planned`, `active`, `completed`, `canceled`)
- `replacement_device_id` nullable
- `grant_action` (`none`, `freeze`, `revoke`, `rebind-to-successor`)
- `approval_action` (`none`, `freeze`, `revoke`)
- `publication_action` (`none`, `stop-announcing`, `clear-route-cache`)
- `recovery_bundle_id` nullable
- `created_by`
- `created_at`
- `completed_at` nullable
- `provenance_ref` nullable

### Transfer

A data movement operation tracked by the daemon.

Fields:

- `transfer_id`
- `share_id`
- `path`
- `direction`
- `source_device`
- `destination_device`
- `priority`
- `bytes_done`
- `bytes_total`
- `state`
- `explanation`

### Backup set

A portable, inspectable state bundle.

Fields:

- `backup_id`
- `created_at`
- `contains_identity`
- `contains_share_metadata`
- `contains_cached_endpoints`
- `encrypted`
- `format_version`

### Recovery bundle

A supported export of recovery prerequisites for one workflow such as encrypted offline decrypt, device replacement, or grant reconciliation.
This exists so operators do not have to rediscover hidden keys, database names, or log details under stress.

Fields:

- `recovery_bundle_id`
- `bundle_type` (`encrypted-offline-decrypt`, `device-replacement`, `grant-reconciliation`)
- `share_id` nullable
- `created_at`
- `contains_keys`
- `contains_wrapped_secrets`
- `contains_metadata`
- `db_dependency` (`none`, `optional`, `required`)
- `sufficiency_status` (`unknown`, `sufficient`, `partial`, `insufficient`)
- `verification_findings[]`
- `encrypted`
- `format_version`

### Plan

A durable preview of an intended mutation.

Fields:

- `plan_id`
- `action_type`
- `created_at`
- `created_by`
- `target_objects[]`
- `preconditions[]`
- `effects[]`
- `risk_flags[]`
- `provenance_ref`
- `expires_at` nullable

### Replica state

Per device, per share:

- `absent`
- `metadata-only`
- `partial`
- `complete`
- `encrypted-only`

---

## Top-level groups

```text
anonsync init
anonsync daemon ...
anonsync device ...
anonsync contact ...
anonsync pending ...
anonsync link ...
anonsync share ...
anonsync grant ...
anonsync incoming ...
anonsync ignore ...
anonsync conflict ...
anonsync role ...
anonsync deviation ...
anonsync stewardship ...
anonsync preflight ...
anonsync mount ...
anonsync file ...
anonsync invite ...
anonsync claim ...
anonsync approval ...
anonsync policy ...
anonsync override ...
anonsync route ...
anonsync explain ...
anonsync transfer ...
anonsync history ...
anonsync events ...
anonsync status ...
anonsync doctor ...
anonsync audit ...
anonsync plan ...
anonsync backup ...
anonsync recover ...
```

Rules:

- every mutable command supports `--yes` for non-interactive use
- every read command supports `--json`
- long-running commands support `--watch` or `--follow`
- destructive or global commands require an explicit flag rather than positional ambiguity
- every failed command should emit a short machine-readable error code in `--json` mode
- commands that can affect local bytes only vs replicated share state must require an explicit scope flag when the distinction matters
- read surfaces should report both durable policy and active override leases when temporary state changes the effective behavior

---

## Core commands

### `anonsync init`

Create local device identity and daemon state.

```text
anonsync init --name laptop-ember
anonsync init --name archive-box --storage /srv/anonsync
anonsync init --name studio-nas --listen 0.0.0.0:4747
```

Output includes:

- device ID
- config path
- storage path
- local control socket path
- active discovery policy

### `anonsync daemon`

Manage the local daemon.

```text
anonsync daemon start
anonsync daemon stop
anonsync daemon restart
anonsync daemon status
anonsync daemon logs --follow
anonsync daemon capabilities
```

### `anonsync device`

#### Add known peer

```text
anonsync device add --name studio-nas --addr 10.0.0.8:4747
anonsync device add --invite ./peer.invite
```

#### Inspect and list

```text
anonsync device list
anonsync device show dev_01J...
anonsync device show dev_01J... --show-provenance
```

#### Modify trust posture

```text
anonsync device set dev_01J... --trust-class untrusted
anonsync device set dev_01J... --addr vpn.example.net:4747
anonsync device set dev_01J... --tag laptop
```

#### Retire / ignore / replace

```text
anonsync device retire dev_01J... --intent hide
anonsync device retire dev_01J... --intent revoke --plan --reason "stolen laptop"
anonsync device ignore dev_01J... --reason "unsolicited old identity"
anonsync device replace dev_old --successor dev_new --plan
anonsync device retirement show rtr_01J...
```

Important rules:

- adding or linking a device never replaces the current device identity
- conflicting identity data returns an explicit remediation error
- untrusted devices cannot receive plaintext for shares whose policy forbids it
- device add/link flows should expose compatibility warnings before commitment when version-family or capability mismatches are known
- retirement intent must be explicit: `hide`, `ignore`, `revoke`, and `replace` are distinct and must not be guessed from one overloaded remove action
- successor replacement should reference the reviewed continuity consequences for grants, approval memory, and recovery posture

### `anonsync contact`

Review and manage relationship memory without silently granting or linking anything.

```text
anonsync contact list
anonsync contact show ctc_01J...
anonsync contact trust ctc_01J... --class collaborator
anonsync contact quarantine ctc_01J... --reason "unexpected fingerprint drift"
anonsync contact ignore ctc_01J... --reason "unsolicited peer"
anonsync contact set ctc_01J... --future-introductions share-scoped
```

Semantics:

- a contact record may exist before any share grant exists
- contact trust is not itself a share grant or mount adoption
- ignored and quarantined states must be visible and auditable
- successor continuity policy belongs here, not in hidden replacement folklore

### `anonsync pending`

Review unknown or newly introduced peers before they become ordinary trust state.

```text
anonsync pending peer list
anonsync pending peer show ppd_01J...
anonsync pending peer accept ppd_01J... --as-contact alex --plan
anonsync pending peer dismiss ppd_01J... --reason "not now"
anonsync pending peer ignore ppd_01J... --reason "unsolicited contact"
```

Semantics:

- pending peers are a first-class queue, not log archaeology
- accept may create a contact, a device record, or a claim plan, but must say which
- dismiss is temporary review state; ignore is durable future suppression
- linked-device introduction may surface a pending peer, but not silently create ambient trust

### `anonsync link`

Create and manage personal-device constellations.

```text
anonsync link create --label personal --auto-grant-rule prompt
anonsync preflight link --group personal --invite ./desktop.link
anonsync link add --group personal --invite ./desktop.link
anonsync link show personal
anonsync link set personal --auto-grant-rule tagged-shares-only --max-permission ro
anonsync link set personal --introduction-policy pending-only
```

Semantics:

- linking creates relationship state, not identity merger
- linking may install a default policy, but never implies `owner`
- broad share visibility is opt-in policy, not a hard-coded side effect
- visible shares can land in `incoming` state without creating local paths
- introductions are disabled or pending-only by default; any wider behavior must be explicit policy
- linked-group convenience must still respect role caps and compatibility blockers surfaced by preflight

#### Profiles

Named profiles should exist for common cases.

Examples:

- `personal-easy`
- `personal-strict`
- `team-strict`
- `encrypted-cache`
- `lan-only`

Profile installation must be inspectable:

```text
anonsync link create --label personal --profile personal-strict --plan
anonsync plan show pln_01J...
```

The plan should show the exact linked-group and discovery-policy objects that would be created.

### `anonsync share`

#### Create

```text
anonsync share create ~/Documents/work --label workdocs
anonsync share create /srv/media --label media --mode selective
anonsync share create ./vault --label vault --encrypt-on-untrusted
```

Flags:

- `--label <name>`
- `--mode detached|selective|full`
- `--write-policy send-receive|send-only|receive-only`
- `--encrypt-on-untrusted`
- `--policy <discovery-policy-id>`
- `--ignore <pathspec>` repeated (bootstrap sugar for the share's ignore policy)

#### Inspect and mutate

```text
anonsync share list
anonsync share show workdocs
anonsync share show workdocs --show-provenance
anonsync share set workdocs --write-policy send-only
anonsync share set media --policy lan-only
anonsync share pause media
anonsync share resume media
anonsync share rescan media
```

Default semantic rule:

- creating a share does **not** automatically grant it to linked devices unless an explicit linked-group policy says so

### `anonsync grant`

#### Grant access

```text
anonsync grant create workdocs --device studio-nas --perm rw
anonsync grant create vault --device cache-vps --perm encrypted-replica
anonsync grant create receipts --group personal --role readonly-viewer
anonsync preflight grant receipts --group personal --role readonly-viewer
```

#### Inspect and modify

```text
anonsync grant list --share workdocs
anonsync grant set grt_01J... --perm ro
anonsync grant revoke grt_01J...
```

Permissions for v1:

- `ro`
- `rw`
- `owner`
- `encrypted-replica`

Notes:

- `owner` should be rare and auditable
- `encrypted-replica` means store/seed ciphertext only
- linked-group membership is not equivalent to owner capability
- role application must not exceed linked-group caps or target-device capabilities
- trust-expanding grants should support `--plan`

### `anonsync incoming`

Inspect and adopt newly visible shares.

```text
anonsync incoming list
anonsync incoming show inc_01J...
anonsync incoming compare inc_01J... --path ~/Sync/workdocs
anonsync preflight adopt inc_01J... --role laptop-cache
anonsync incoming adopt inc_01J... --path ~/Sync/workdocs --mode selective --role laptop-cache
anonsync incoming defer inc_01J... --reason "wait for external disk"
anonsync incoming reject inc_01J... --reason "wrong machine"
```

Semantics:

- an incoming item means the share is visible, not yet mounted
- `compare` reports whether the target path is empty, already bound, or populated with identical/local-only/remote-only/colliding content
- adopt chooses the local path and initial mount mode
- role choice can constrain permission, write policy, and plaintext access without changing the share model
- reject records operator intent and provenance instead of silently ignoring the share
- defer keeps the item visible without committing to a path yet
- policies may auto-adopt only when that behavior is explicit and reviewable
- adoption into a non-empty path should normally require a comparison report and often a plan
- handling one incoming share must not require changing a device-wide linked-folder default

### `anonsync ignore`

Inspect and mutate ignore behavior without editing hidden service files.

```text
anonsync ignore list workdocs
anonsync ignore add workdocs '*.tmp'
anonsync ignore remove workdocs ign_01J...
anonsync ignore test workdocs build/output.log
anonsync ignore set-consistency workdocs --mode warn-on-drift
```

Semantics:

- ignore rules are first-class supported data
- rule additions/removals should be incremental, not whole-list replacement by default
- `test` explains why a path is or is not ignored
- consistency mode states whether peer-local drift is acceptable, warned on, or rejected
- a future UI may render these rules differently, but it should not invent a different model

### `anonsync projection`

Inspect and mutate namespace-announcement and mount-view projection behavior without guessing from hidden ignore timing.

```text
anonsync projection show workdocs
anonsync projection test workdocs build/output.log
anonsync projection add workdocs --match 'build/**' --namespace hidden --announce suppress
anonsync projection add mnt_01J... --match 'build/**' --local omit
anonsync projection set-tighten-behavior workdocs --mode review-existing
```

Semantics:

- share selectors control namespace visibility / remote announcement; mount selectors control local projection
- `test` should answer whether a concrete path is announced to peers, visible in namespace, omitted locally, placeholder-visible, metadata-only, or fully materialized
- tightening a rule must not silently strand already-indexed or already-materialized paths; the policy should say whether review, safe eviction, or blocking is required
- mount-view projection may hide a path locally without changing replicated share namespace
- future UI/TUI layers may render projection differently, but they should not invent a different model

### `anonsync conflict`

Inspect and resolve conflicts as explicit cases.

```text
anonsync conflict list --share workdocs
anonsync conflict show cft_01J...
anonsync conflict resolve cft_01J... --winner candidate_02 --plan
anonsync conflict defer cft_01J... --reason "need editor review"
```

Semantics:

- conflicts have stable IDs, kinds, and candidate records
- the operator should not need to infer the situation from a magic filename alone
- resolution output must explain local-only vs replicated consequences
- destructive or share-wide resolutions should usually prefer `--plan`


### `anonsync role`

Inspect and manage reusable least-privilege templates.

```text
anonsync role list
anonsync role show readonly-viewer
anonsync role create --name readonly-viewer --perm ro --write-policy receive-only --mode selective --deviation-policy mirror-flag
anonsync role create --name encrypted-cache --perm encrypted-replica --plaintext forbidden --mode detached
```

Semantics:

- roles are convenience bundles, not a second share type
- applying a role compiles to explicit grant and mount constraints
- roles should be reusable across link, grant, and incoming-adopt flows
- role output should explain any capability or policy constraints that could downgrade or block application

### `anonsync deviation`

```text
anonsync deviation create --name mirror-flag --for receive-only --on-add preserve-and-flag --on-modify preserve-and-flag --on-delete re-fetch
anonsync deviation show mirror-flag
anonsync deviation list
anonsync deviation update mirror-flag --on-modify conflict-copy
```

Deviation policies are reusable policy objects, not hidden side effects of a role or share type.
They must be applicable from roles, mounts, or plans, and explain surfaces should always show which deviation policy is effective.

### `anonsync stewardship`

```text
anonsync stewardship list
anonsync stewardship show <share>
anonsync stewardship plan-handoff <share> --to <device|identity> [--policy ...]
anonsync stewardship apply <plan_id>
anonsync stewardship cancel <plan_id>
```

Rules:

- handoff plans must say exactly which authority moves (`grant`, `revoke`, `delegate`, `data-write`)
- handoff preview must show what stays with the current steward and what becomes successor-only
- if retirement or recovery state blocks safe handoff, the command must say so explicitly

### `anonsync preflight`

Generate a compatibility/authority report before commitment.

```text
anonsync preflight link --invite ./desktop.link
anonsync preflight grant receipts --group personal --role readonly-viewer
anonsync preflight adopt inc_01J... --role laptop-cache
anonsync preflight show rpt_01J...
```

Semantics:

- preflight reports blockers, warnings, downgrade notes, and authority consequences
- it should be callable independently of the later mutation for review or automation
- accepted plans may embed a referenced preflight report when risk is high
- a future UI may render this differently, but it should not invent a different model

### `anonsync mount`

#### Attach share locally

```text
anonsync mount attach workdocs ~/Sync/workdocs --mode selective
anonsync mount attach media /mnt/media --mode full
```

#### Inspect and change mode

```text
anonsync mount list
anonsync mount show mnt_01J...
anonsync mount set mnt_01J... --mode selective
anonsync mount set-deviation mnt_01J... --policy mirror-flag
anonsync mount compare mnt_01J... --path /Volumes/External/workdocs
anonsync mount relocate mnt_01J... /Volumes/External/workdocs --plan
```

Semantics:

- `detached`: share known locally, no file data materialized
- `selective`: metadata visible, fetch explicit files or directories on demand
- `full`: all reachable content replicated locally
- `set-deviation` changes the active local-remediation policy without changing granted authority
- `compare` previews relocation into a target path and reports identical/local-only/remote-only/collision classes
- `relocate` changes the local binding path without pretending the share label changed everywhere
- relocation into a non-empty path should usually require a comparison report and `--plan`

### `anonsync file`

#### Fetch

```text
anonsync file fetch media Movies/2025/
anonsync file fetch workdocs report.pdf
anonsync file fetch vault --recursive Secrets/Taxes/
```

#### Evict local materialization

```text
anonsync file evict media Movies/2025/bigfile.mkv
anonsync file evict workdocs --recursive old-exports/
```

#### Remove with explicit scope

```text
anonsync file remove media Movies/2025/bigfile.mkv --scope local
anonsync file remove vault Secrets/Taxes/report.pdf --scope share --plan
```

#### Check preservation posture

```text
anonsync file check media Movies/2025/bigfile.mkv --for evict
anonsync file check vault Secrets/Taxes/report.pdf --for remove-share
```

#### Pin / unpin

```text
anonsync file pin media Podcasts/
anonsync file unpin media Podcasts/
```

#### History / restore

```text
anonsync file history media Movies/2025/bigfile.mkv
anonsync file restore media Movies/2025/bigfile.mkv --entry hst_01J... --scope local
anonsync file restore vault Secrets/Taxes/report.pdf --entry hst_01J... --scope share --plan
```

Semantics:

- `fetch` materializes content
- `evict` removes local content while preserving share state
- `remove --scope local` removes the local copy or local placeholder state only
- `remove --scope share` is a replicated delete and should usually prefer `--plan`
- `check --for ...` generates a preservation report before a risky file mutation
- `pin` means keep local data across space-reclamation passes
- `history` lists restorable prior states with provenance and scope
- `restore --scope local` restores only on this device or mount
- `restore --scope share` writes a restored version back into replicated share state and should usually prefer `--plan`
- destructive plans should reference preservation evidence such as remaining plaintext replicas, encrypted-only remnants, and history gaps
- if preservation would become too weak, the command should block or require a more explicit acknowledgement than an ordinary local remove
- the CLI must never overload one ambiguous delete action to mean both local eviction and distributed delete
- the CLI must never require hidden archive-directory knowledge for ordinary restore workflows

### `anonsync invite`

#### Create

```text
anonsync invite create --type device-link --output desktop.link
anonsync invite create --type share-access --share vault --perm encrypted-replica --output vps.invite
```

#### Inspect

```text
anonsync invite show ./desktop.link
```

Semantics:

- invites are offered capability artifacts
- inspecting an invite should reveal scope, expiry, peer pinning, suggested role, and whether a claim review is required
- `invite accept` may exist as convenience sugar, but the public model should still pass through an explicit claim object when state changes are non-trivial

### `anonsync claim`

Prepare and review acceptance of an invite or incoming share before applying it locally.

```text
anonsync claim prepare --invite ./desktop.link --group personal
anonsync claim prepare --incoming inc_01J... --path ~/Sync/workdocs --mode selective --role readonly-viewer
anonsync claim show clm_01J...
anonsync claim apply clm_01J...
anonsync claim reject clm_01J... --reason "wrong machine"
```

Semantics:

- claim creation captures the operator's intended local outcome
- a claim may reference a preflight report or plan when risk is high
- claim history distinguishes offered access from accepted local state
- claim apply should fail safely if referenced invite, incoming state, or compatibility facts have drifted

### `anonsync approval`

Inspect and manage bounded future-approval records.

```text
anonsync approval list --peer alex
anonsync approval show apr_01J...
anonsync approval issue --peer alex --scope share-tag:photos --max-role readonly-viewer --approver-scope linked-group --expires 90d --plan
anonsync approval revoke apr_01J...
anonsync approval test --peer alex --share vacation-2026
```

Semantics:

- there is no hidden “approved before” state outside these records
- approval memory must be bounded by scope, approver scope, expiry, and maximum role
- broad identity-wide future approval should usually prefer `--plan`
- `approval test` explains whether a future share would be auto-approved and why
- audit must show when a later invite, share, or linked-device action consumed an approval record

### `anonsync policy`

```text
anonsync policy list
anonsync policy show lan-only
anonsync policy create --name lan-only --tracker disabled --relay disabled --lan enabled
anonsync policy create \
  --name privacy-mixed \
  --tor preferred \
  --i2p allowed \
  --clearnet-direct manual-opt-in \
  --dial-via lan-direct,tor,i2p,private-relay
anonsync policy cache clear --policy lan-only
```

Expectations:

- policy output should show live settings and retained cache effects separately
- policy output should say explicitly whether WAN clearnet direct is disabled, manual-only, or generally allowed
- cache-clear operations should say which learned routes or endpoints are being invalidated

### `anonsync exposure`

Preview or inspect what a policy/share/peer currently publishes about reachability.

```text
anonsync exposure show --policy privacy-mixed
anonsync exposure show --share media --effective
anonsync exposure show --peer laptop --json
```

Expectations:

- output distinguishes baseline policy from active route leases
- output shows which infrastructure classes can currently learn reachability
- output warns when cached endpoints may outlive a policy narrowing until explicitly cleared
- operators can tell whether a peer-pinned known-host path exists without confusing that with ambient public direct

### `anonsync transport`

Inspect, warm, cool, or verify the bundled transport engines.

```text
anonsync transport list
anonsync transport show tor
anonsync transport show i2p --json
anonsync transport warm tor
anonsync transport warm i2p
anonsync transport cool i2p
anonsync transport verify tor
anonsync transport verify i2p
anonsync transport session list
anonsync transport session show tss_01J...
```

Expectations:

- output should show whether the engine is compiled in or activated from an embedded payload
- output should show bootstrap state, health findings, any runtime path that was created locally, and any persistent state path the engine expects to reuse
- `verify` should expose payload/build version, digest, update mode, and provenance facts safe for local inspection
- operators should be able to tell whether a route was unavailable because policy forbade it, because the runtime was cold, because bootstrap failed, or because verification/provenance checks are degraded
- session output should show whether the daemon is reusing a long-lived shared overlay session or creating something more dedicated
- a future UI should not need a hidden transport model beyond what these commands already expose

### `anonsync override`

Create or inspect temporary runtime overrides without rewriting durable grants, links, or discovery policy.

```text
anonsync override create --target share:docs --mode pause-transfer --ttl 2h --reason "metered uplink"
anonsync override create --target device:laptop --mode drain-egress --ttl 45m --reason "shutdown maintenance"
anonsync override create --target policy:travel --mode throttle --down 4MiB/s --up 1MiB/s --ttl 8h
anonsync override list
anonsync override show ov_01J...
anonsync override cancel ov_01J...
```

Rules:

- overrides are additive temporary leases, not hidden edits to the underlying policy object
- every override must either expire automatically or require an explicit `--no-expiry` acknowledgement
- `status`, `policy show`, `route`, and `explain` should reveal the effective behavior together with contributing overrides
- high-risk overrides that affect publication or delete behavior should require a reviewed plan before apply

### `anonsync route`

Inspect effective connectivity and route-decision traces.

```text
anonsync route list
anonsync route show --share workdocs
anonsync route show --peer laptop --explain
anonsync route show --share media --decision-trace
anonsync route known-host add --peer laptop --addr sync.example.net:3847 --share media --ttl 7d --reason "trusted home uplink"
anonsync route known-host list --peer laptop
anonsync route allow-clearnet-direct --share media --ttl 2h --byte-cap 250GiB --reason "trusted bulk transfer"
anonsync route allow-clearnet-direct --peer laptop --ttl 30m --reason "initial seed to trusted peer"
anonsync route lease list
anonsync route lease show rls_01J...
anonsync route lease cancel rls_01J...
```

Expectations:

- route output should show active path, viable candidates, and rejected candidates separately
- route output should show transport class (`lan-direct`, `tor`, `i2p`, `public-direct`, `private-relay`, etc.) and exposure class separately
- `--explain` should include the policy, cache, capability, and manual-override facts that made the current route win
- decision-trace output should say whether the explanation is current or derived from older policy/cache state
- operators should not need to infer relay/direct choice from icons alone
- if WAN clearnet direct is active, the output should say whether that happened because of a manual speed override and when that override expires
- route output should distinguish peer-pinned known-host direct from general public direct
- route and explain output should make it obvious when a temporary bulk-speed lease is the only reason a public-direct candidate is eligible
- when a byte cap exists, route/lease output should show remaining budget or the exhaustion reason after the lease ends

### `anonsync explain`

Generic decision-path inspection for high-signal objects.

```text
anonsync explain grant grn_01J...
anonsync explain claim clm_01J...
anonsync explain route --share workdocs
anonsync explain mount mnt_01J...
```

Expectations:

- output should summarize selected outcome, rejected alternatives, and decisive facts
- explanations should reuse stable reason codes so automation and future UIs can depend on them
- an object with no meaningful decision path should say so explicitly instead of inventing fake detail

### `anonsync plan`

```text
anonsync plan list
anonsync plan show pln_01J...
anonsync plan apply pln_01J...
anonsync plan cancel pln_01J...
```

Plan objects are required for operations that:

- widen trust scope
- replace or rebind identities
- rewrite grants after recovery
- install multi-object policy bundles

### `anonsync transfer`

```text
anonsync transfer list
anonsync transfer show trf_01J...
anonsync transfer set trf_01J... --priority high
```

### `anonsync history`

Optional convenience group for operators who think in terms of version history rather than file actions.
It should be thin sugar over the same file-history model.

```text
anonsync history list --share media --path Movies/2025/bigfile.mkv
anonsync history show hst_01J...
```

### `anonsync status`

Status output should surface active deviation state for non-authoritative mounts, including whether local adds, edits, or deletes have been preserved, auto-remediated, or are blocking remote progress.


```text
anonsync status
anonsync status --json
anonsync status --watch
```

Human output should answer:

- which peers are online
- which shares are degraded
- which routes are active
- whether any linked-group or policy changes are pending apply
- whether compatibility warnings or role downgrades are pending review
- whether any share is only apparently idle versus actually converged with high confidence

### `anonsync converge`

Inspect or wait for settlement confidence instead of guessing from generic status output.

```text
anonsync converge show --share workdocs
anonsync converge show --share workdocs --intent cutover
anonsync converge wait --share workdocs --intent backup --timeout 10m
anonsync converge explain cvr_01J...
```

Semantics:

- convergence is stronger than “no transfer currently queued”
- reports should distinguish `converged` from `degraded-converged`
- source availability, watcher health, clock health, and hidden background work all affect confidence
- `wait` should return structured blocker information instead of sleeping blindly until timeout
- intent matters: a casual status check may accept lower confidence than relocation, backup, or cutover
- future UI/TUI layers should consume the same report rather than inventing their own readiness heuristic

### `anonsync doctor`

```text
anonsync doctor
anonsync doctor --share media
anonsync doctor --device studio-nas
```

Doctor is the diagnosis surface, not a secret-debug fallback.
It should emit stable finding codes, including compatibility/preflight findings that explain blocked or downgraded actions.
It should also point at convergence reports when idle-looking state is degraded by watcher exhaustion, clock skew, hidden merge work, or missing sources.

### `anonsync audit`

```text
anonsync audit
anonsync audit --type grant.created
anonsync audit --subject shr_01J...
anonsync audit --correlation corr_01J...
```

### `anonsync backup` and `anonsync recover`

```text
anonsync backup create --output ./mesh.asb
anonsync recover bundle export --type encrypted-offline-decrypt --share vault --output ./vault.arb
anonsync recover bundle verify ./vault.arb
anonsync recover import ./mesh.asb
anonsync recover replace-device --old dev_dead --new dev_new --plan
anonsync recover rotate-identity --device dev_01J... --plan
anonsync recover revoke-device --device dev_01J... --plan
anonsync recover decrypt-replica --input /mnt/cache/vault --bundle ./vault.arb --output ./vault-restored
anonsync plan apply pln_01J...
```

Semantics:

- recovery should surface rewritten grants and policy consequences before apply
- replacement is distinct from linking
- offline encrypted-replica recovery should be possible without a running daemon when sufficient recovery material is available
- recovery bundles make prerequisites explicit and verifiable ahead of failure
- bundle verification should say whether decrypt can proceed, whether metadata is partial, and whether any hidden daemon-state dependency remains
- rotation and revocation produce audit entries and events that are easy to query
- recovery plans should carry forward compatibility and role consequences where device capabilities changed
- retirement records should show whether the action was cosmetic cleanup, active trust retirement, or continuity-preserving replacement


## Filesystem compatibility surfaces

The CLI should expose explicit filesystem-semantics inspection rather than leaving operators to infer behavior from later conflicts.

Suggested commands:

```text
anonsync fs profile <path>
anonsync fs profile <path> --json
anonsync fs support
anonsync fs support --path <target>
anonsync fs compare --share <share> --path <target>
anonsync fs compare --mount <mount> --path <target>
anonsync fs explain <report_id>
anonsync mount adopt <incoming> --path <target> --fs-report <report_id>
anonsync doctor <share-or-path> --include fs
```

Expected semantics:

- `fs profile` reports local path semantics and fidelity limits
- `fs support` reports the daemon's declared support tier for either the host generally or a specific target path
- `fs compare` generates a durable filesystem compatibility report
- `mount adopt` and `mount relocate` should be able to require a fresh fs compatibility report when risk is non-trivial
- `doctor` should surface runtime drift when a mounted path no longer satisfies expected semantics
- `explain` should say whether a rename, normalization rewrite, metadata strip, or symlink downgrade is expected and why
