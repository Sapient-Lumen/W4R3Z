# Architecture decisions

## ADR-001 — Open, inspectable behavior beats opaque convenience

**Decision:** Design for inspectability first.

**Why:** The strongest non-Resilio reason to build AnonSync is to make peer-to-peer sync more auditable and controllable.

**Implications:**

- documented protocol and schemas
- stable machine-readable state
- explicit diagnostics
- fewer hidden heuristics

## ADR-002 — Device identities are durable; linking never overwrites them

**Decision:** A device keeps its identity unless the local operator explicitly rotates or replaces it through recovery workflows.

**Why:** Resilio's documented linking behavior shows that certificate takeover can be destructive and confusing.

**Implications:**

- linking creates relationships, not mergers
- conflict resolution must be explicit
- share state cannot be silently rebound to a new certificate

## ADR-003 — Materialization state is first-class

**Decision:** Every mount/share pairing exposes a materialization mode.

**Modes:**

- `detached`
- `selective`
- `full`

**Why:** This is one of Resilio's genuinely strong product insights and should be preserved.

## ADR-004 — Encrypted-untrusted replicas are a v1 feature, not a someday add-on

**Decision:** Support encrypted-replica peers early.

**Why:** This is strategically differentiating, operationally useful, and aligned with the product thesis.

**Implications:**

- permissions must include `encrypted-replica`
- status tooling must distinguish plaintext and ciphertext holders
- fetch logic must explain when only encrypted copies exist

## ADR-005 — Placeholder semantics are optional, not foundational

**Decision:** Do not make cross-platform placeholder files the basis of v1.

**Why:** Placeholder implementation details can consume disproportionate complexity and obscure the real product value.

**Implications:**

- support virtual and sidecar strategies first
- add native placeholder integrations later where they are robust

## ADR-006 — Start with personal/small-team scope

**Decision:** Ignore enterprise fleet scope for now.

**Why:** Wide deployment support and central management can easily dominate the roadmap and bury the core product insight.

**Implications:**

- no centralized multi-tenant admin plane in v1
- no huge-job distribution story yet
- better local operator experience first

## ADR-007 — Strong diagnostics are part of the product, not support work

**Decision:** `status`, `events`, and `doctor` are first-class surfaces.

**Why:** Sync products fail hardest when users cannot tell what is happening.

**Implications:**

- the daemon tracks explanation-rich transfer states
- every blocked sync has a reason string
- the UI/TUI can be built atop the same event stream

## ADR-008 — Discovery/relay behavior is policy, not a hidden advanced setting

**Decision:** Tracker, relay, LAN discovery, known-host controls, and endpoint cache management are explicit policy objects.

**Why:** Resilio's official docs show that transport behavior materially changes privacy, reachability, and operator expectations.

**Implications:**

- shares can bind to named discovery policies
- status must show the effective path used
- LAN-only operation becomes a normal supported workflow

## ADR-009 — Linked devices do not imply owner authority by default

**Decision:** Device linking and share ownership are separate concepts.

**Why:** Resilio's linked-device model is convenient, but too broad for a system that wants auditable trust boundaries.

**Implications:**

- share grants remain explicit objects
- linked-device auto-grants are opt-in policy
- admin authority can be reviewed independently of personal-device membership

## ADR-010 — Recovery must be explicit; cloning is not the workflow

**Decision:** Support backup/export/import/replacement flows, but do not rely on opaque disk cloning.

**Why:** Operators still need hardware replacement and disaster-recovery workflows, and unsupported cloning is an unsatisfying answer.

**Implications:**

- explicit backup and recover commands
- trust reconciliation paths
- auditable identity rotation and replacement events

## ADR-011 — API and CLI are two views of one object model

**Decision:** The local daemon API is a first-class surface, not a private implementation detail.

**Why:** Resilio's split across UI/config/startup flags is precisely the kind of fragmentation AnonSync should avoid.

**Implications:**

- future UI/TUI must consume the same events and objects
- config import/export maps to the same schema family
- machine users are not second-class users

## ADR-012 — “Easy mode” behaviors must decompose into explicit policies

**Decision:** Convenience features such as linking, auto-grants, or default selective mounts must compile to inspectable policy objects.

**Why:** Hidden convenience is where trust expansion becomes hard to audit.

**Implications:**

- every auto-grant has provenance
- users can list and revoke policy-derived grants
- defaults are explainable and reversible

## ADR-013 — Observability and audit are part of the control plane

**Decision:** Expose metrics, audit, route selection, and health summaries through supported CLI/API surfaces.

**Why:** A sync product that only exposes raw logs leaves operators reconstructing the system model by hand.

**Implications:**

- `status`, `doctor`, `audit`, and `metrics` are supported interfaces
- route/cache state must be inspectable without debug builds
- security-relevant changes must leave machine-readable audit entries

## ADR-014 — High-signal mutations use plan/apply with drift detection

**Decision:** Trust-expanding, recovery-rebinding, or multi-object mutations should prefer explicit plan objects that are reviewed and then applied against checked preconditions.

**Why:** A plain `dry-run` is useful, but not strong enough when the world may change between preview and execution.

**Implications:**

- plan objects become part of the public object model
- applies can fail safely on drift instead of guessing intent
- audit can record both reviewed intent and executed change

## ADR-015 — Capability differences must be explicit and queryable

**Decision:** Local and remote capability differences should be inspectable through supported CLI/API surfaces.

**Why:** Partial feature support is inevitable across platforms, but silent degradation recreates the same black-box feeling this project is meant to avoid.

**Implications:**

- daemon exposes capability sets
- operators can tell why a requested strategy is unavailable
- CLI and future UI use the same capability facts when offering or rejecting actions


## ADR-016 — Newly visible shares are staged before local path adoption

**Decision:** Shares made visible through linking, policy, invite acceptance, or recovery should first appear as incoming objects unless the operator or policy explicitly chooses auto-adoption.

**Why:** Resilio's docs show that linked-device convenience can couple visibility, default mode, and default path placement tightly enough to create duplicate folders or require reconnect rituals.

**Implications:**

- incoming visibility becomes part of the public object model
- path choice is explicit and auditable
- visibility and mount existence are no longer conflated

## ADR-017 — Local eviction and share-wide delete use distinct verbs and scopes

**Decision:** The interface must separate local materialization actions from replicated delete actions.

**Why:** Selective-sync systems naturally sit close to a dangerous ambiguity: freeing local space and deleting shared state can look similar unless the contract is explicit.

**Implications:**

- CLI/API require explicit scope on remove actions where ambiguity exists
- plan/apply is preferred for share-wide delete on sensitive paths
- audit and events distinguish local eviction from replicated delete


## ADR-018 — File history and restore are supported surfaces, not hidden archive rituals

**Decision:** The product must expose file history and restore through supported CLI/API objects and actions.

**Why:** Resilio's Archive feature is valuable, but its documented restore path still depends on hidden directories, desktop-only affordances, and timing-sensitive manual steps.

**Implications:**

- restore candidates have stable IDs and provenance
- restore requires explicit scope (`local` vs `share`)
- share-wide restore can use plan/apply when risk warrants it
- audit and events cover restore actions like any other high-signal mutation


## ADR-019 — Ignore, conflict, and service-metadata state are supported surfaces

**Decision:** Ignore rules, conflict cases, and service-metadata health are part of the public control model.

**Why:** Resilio's docs show too much important operator state leaking through hidden `.sync` files, magic conflict filenames, and support-article warnings about what not to delete.

**Implications:**

- ignore rules become inspectable objects with provenance and drift state
- conflicts become structured records with safe resolution actions
- damaged service metadata is surfaced through health/doctor, not discovered only after breakage

## ADR-020 — Incremental rule mutation beats whole-array replacement

**Decision:** List-like policy surfaces should prefer item-level resources or explicit add/remove actions over generic whole-array replacement.

**Why:** Operators frequently mean “change one rule”, and array-replacement patch semantics are too easy to misuse when the blast radius is broader than it looks.

**Implications:**

- ignore rules get add/remove/test style operations
- CLI/API avoid accidental deletion of neighboring rules during routine edits
- future UI/TUI can use the same safe mutation model instead of inventing client-side merge logic


## ADR-021 — Compatibility and authority consequences are preflight objects

**Decision:** Link, invite-accept, grant, and adoption workflows should expose supported preflight reports with blockers, warnings, downgrade notes, and authority changes.

**Why:** Resilio's docs are clear enough that mixed-version linking and linked-device convenience can have real configuration or authority consequences, but too much of that knowledge still lives in FAQs and support notes.

**Implications:**

- preflight becomes part of the public object model
- plans may reference a preflight report and fail if it becomes stale
- UI/CLI can share one compatibility-warning vocabulary

## ADR-022 — Least privilege must survive convenient linking

**Decision:** Personal-device linking should support explicit per-device/per-share roles without requiring a separate weaker share type.

**Why:** Resilio's documented path to read-only behavior across linked devices pushes users toward Standard-folder key rituals and away from the stronger Advanced-folder model.

**Implications:**

- role templates become first-class resources
- linked-group membership never implies owner-like authority by itself
- share/grant semantics stay coherent even when one personal device is read-only, receive-only, or encrypted-only

## ADR-023 — Offers and invites require explicit claims before non-trivial local mutation

**Decision:** Visible shares and capability-bearing invites should pass through a durable claim/acceptance object before they create mounts, grants, or linked-group effects when the outcome is non-trivial.

**Why:** Resilio's current product shows that awareness, access, path choice, and authority expansion are easy to blur. AnonSync should keep “what was offered” distinct from “what this machine accepted.”

**Implications:**

- claims become part of the public object model
- invite inspection is side-effect free
- claim review can reference preflight and plan objects
- audit records can distinguish offered capability, claimed outcome, rejection, and expiry

## ADR-024 — Recovery-material sufficiency is supported state, not folklore

**Decision:** Recovery prerequisites for encrypted offline decrypt and similar workflows should be exportable, inspectable, and verifiable through supported recovery-bundle objects.

**Why:** Recovery that depends on remembered hidden database paths, debug logs, or lucky retained local state is too fragile for the product AnonSync aims to be.

**Implications:**

- recovery bundles become part of the supported surface
- doctor/status can report degraded recovery posture
- offline recovery aims to minimize database dependency where design permits
- rotation or replacement can explicitly invalidate stale recovery material


## ADR-025 — Approval memory is explicit, scoped, and revocable

**Decision:** Any remembered future-approval convenience must compile to a first-class approval object with bounded scope, approver scope, expiry, maximum role, and auditability.

**Why:** Resilio's docs make it clear that “approved before” and “can approve from any linked device” are real product concepts, but they remain too implicit for the trust model AnonSync wants.

**Implications:**

- there is no hidden ambient approval state outside the supported approval surface
- future-share convenience can be tested and reviewed before it is exercised
- linked devices may approve on one another's behalf only when explicit approver scope says so
- audit and events can explain why a later share or invite auto-approved


## ADR-026 — Path binding and relocation are explicit compared actions

**Decision:** Adopting a share into a populated path or relocating an existing mount must generate a comparison object and should usually go through plan/apply.

**Why:** Resilio's docs show permissive reconnect and pre-populated-folder workflows where default paths, duplicate-index folders, and timestamp-win replacement can decide outcomes, while Syncthing's docs react by warning that move/rename is dangerous unless the folder is already fully in sync. AnonSync should surface that risk instead of inheriting either folklore-driven extreme.

**Implications:**

- share identity and local path binding remain separate concepts
- non-empty target paths produce explicit identical/local-only/remote-only/collision findings
- service-marker or foreign-binding conflicts become health/preflight findings, not surprise later errors
- relocation is auditable as local path rebinding rather than hidden filesystem drift


## ADR-027 — Publication scope and route selection are distinct policy surfaces

**Decision:** Discovery policy must distinguish what the daemon publishes about reachability from how it later dials or relays traffic.

**Why:** Current Resilio docs make the network model reconstructable, but still mostly in the language of transport success: tracker, relay, LAN search, predefined hosts. A product centered on inspectable trust needs the language of exposure as well: who can learn that this device/share relationship exists, and through which service.

**Implications:**

- policy objects expose announce scope, dial methods, relay pool choice, and fallback order separately
- route/exposure summaries explain both the active path and the metadata disclosure that enabled it
- future UI/TUI cannot reduce topology policy back into a few unlabeled checkboxes


## ADR-028 — Decision traces are public contract, not debug garnish

**Decision:** High-signal outcomes should expose structured decision traces through supported CLI/API surfaces.

**Why:** Resilio's current docs are good enough to reconstruct route behavior, but too much explanation still arrives as a mix of peer-list symptoms, icon hints, and troubleshooting lore. A product built around inspectability should expose the decision path directly.

**Implications:**

- routes, claims, approval consumption, restore scope, and recovery rebinds can expose selected outcome plus rejected alternatives
- traces carry stable reason codes and freshness so automation can trust them
- future UI/TUI should consume the same trace objects instead of inventing its own inference layer


## ADR-029 — Temporary runtime overrides are explicit leases, not silent policy edits

Sync operators often need short-lived changes: pause during a metered connection, drain before shutdown, or temporary throttling during maintenance.
If those changes silently rewrite durable share or route policy, the product accumulates invisible drift and later surprises.

Decision:

- represent short-lived operational changes as first-class override leases
- require explicit target, effect, provenance, and expiry
- expose effective-state views that combine durable policy with active leases
- keep lease expiry reversible without manual cleanup

Consequence:

AnonSync can offer convenient maintenance controls without inheriting overloaded pause semantics or burying temporary intent inside long-lived configuration.


## ADR-030 — Destructive file mutations carry preservation reports

**Decision:** Share-wide delete, local remove, eviction, and share-scope restore should expose preservation evidence when rollback posture materially affects safety.

**Why:** Resilio's docs make destructive consequences depend too much on placeholder state, exact invocation path, hidden preferences, and Archive assumptions. AnonSync should not ask operators to reconstruct that safety model by memory.

**Implications:**

- the control plane can generate preservation reports for risky file actions
- plans for destructive mutations can reference fresh preservation evidence
- remaining plaintext replicas, encrypted-only remnants, and history gaps become visible state instead of folklore
- future UI/TUI integrations must preserve the same blast-radius model as CLI/API surfaces

## ADR-031 — Retirement, ignore, revoke, replace, and rotate are distinct public actions

**Decision:** Introduce a first-class retirement record so device exit semantics are explicit instead of inferred from disappearance, unlinking, or list hygiene.

**Why:** Current sync products too easily blur cosmetic cleanup, ignored future contact, trust revocation, hardware replacement, and identity rotation. Those intents have different security and continuity consequences and should not be bundled into one overloaded “remove device” gesture.

**Consequences:**

- CLI and API gain retirement resources and explicit intent values
- recovery workflows can reference retirement records when replacement or revocation is the real action
- audit and event streams can explain whether an old device was hidden, ignored, revoked, or replaced
- remote-lag / not-yet-observed retirement becomes supported status instead of ghost-device folklore

## ADR-032 — Share stewardship and handoff are first-class state

**Decision:** Introduce a first-class stewardship record so share governance is explicit instead of inferred from one permission bit or from share-type-specific rituals.

**Why:** Current sync products make authority either too broad (all linked devices act as owners) or too mode-dependent (Standard vs Advanced vs local-share behavior). AnonSync should keep data mutation rights, grant power, delegation, and succession visible as separate public concepts.

**Consequences:**

- CLI and API gain stewardship resources and handoff-plan workflows
- recovery and retirement workflows can say how stewardship changes, instead of leaving authority transfer implicit
- audit and event streams can explain who handed off what authority and under which review policy
- future UI/TUI layers must preserve the same separation between data rights and governance rights


## ADR-033 — Permission, propagation, and local-deviation remediation are distinct public state

Resilio's current read-only guidance still spreads a critical operator question across permission type, selective-sync caveats, overwrite toggles, and encrypted-folder special cases.
That is enough evidence that “can this target write?”, “will local changes propagate?”, and “what happens when someone edits it anyway?” should not live in one overloaded concept.

Therefore AnonSync should expose deviation policy as a first-class supported object.
Roles and mounts may reference it, plans and explain surfaces must show it, and events must report when local deviation is detected or auto-remediated.
That keeps one-way / mirror behavior inspectable without forcing operators to memorize share-type folklore.


## ADR-034 — Filesystem compatibility is first-class state, not conflict folklore

**Decision:** Case rules, Unicode normalization, prohibited names, symlink handling, metadata fidelity, and timestamp/clock safety must be exposed through supported filesystem-profile and compatibility-report surfaces.

**Why:** Resilio's docs still teach too much of this boundary through conflict examples and power-user toggles, while Syncthing's docs point toward a cleaner model of explicit capability and safety settings. AnonSync should not make operators discover pathname or metadata incompatibility only after bind or pull has already started.

**Consequences:**

- CLI and API gain filesystem-profile and filesystem-compatibility resources
- adopt / relocate / restore workflows can require a fresh fs compatibility report as a precondition
- doctor / explain surfaces can say whether the system is operating under reduced pathname or metadata fidelity
- normalization rewrites and metadata stripping become explicit policy choices instead of magic fallout


## ADR-035 — Namespace projection is first-class state, not ignore folklore

**Decision:** Introduce explicit projection-policy objects so share namespace announcement and local mount-view projection are supported state rather than inferred from hidden ignore files or placeholder timing.

**Why:** Resilio's docs make clear that `IgnoreList` edits do not retroactively hide already-synced files, that once a tree is indexed its structure continues to be passed to peers until disconnect, and that Selective Sync separately controls placeholder-visible local projection. Those are individually understandable behaviors, but they still leave operators reconstructing “who sees the name?” from folklore.

**Consequences:**

- CLI and API gain projection-policy and path-test surfaces
- share-level namespace suppression and mount-level omission/placeholder behavior become separate supported concepts
- tighten behavior for already-indexed or already-materialized paths becomes explicit reviewable state
- future UI/TUI layers must preserve the same distinction between namespace announcement, local projection, and byte materialization


## ADR-036 — Settlement confidence is first-class state, not status folklore

**Decision:** Introduce explicit convergence-report and convergence-wait surfaces so the product can distinguish idle status from trustworthy settlement confidence.

**Why:** Resilio's current docs still ask operators to combine peer counts, status warnings, excessive time-difference errors, watcher-exhaustion warnings, and hidden internal-task caveats to decide whether a share is really safe to treat as settled. That is too much inference for a product centered on inspectable control.

**Consequences:**

- CLI and API gain convergence-report and wait-for-settlement resources
- status, doctor, and explain surfaces can report `degraded-converged` instead of pretending every idle share is equally trustworthy
- cutover / backup / relocate workflows can depend on explicit readiness evidence instead of ad hoc polling
- future UI/TUI layers must preserve the same distinction between completion, health, and settlement confidence

## ADR-037 — Tor and I2P are first-class transport engines

**Decision:** Treat Tor and I2P as supported transport engines and route classes, not merely external proxy compatibility modes.

**Why:** If AnonSync wants privacy-routed operation to be central, the route model cannot remain clearnet-first with anonymity added later as an option. Tor's Arti project is explicitly embeddable and production-quality for client use, while I2P's own application guidance encourages bundling a router and using SAM for non-Java applications.

**Implications:**

- route policies can express `tor` and `i2p` directly
- bundled transport runtimes get explicit health/inspection surfaces
- CLI/API can explain when a privacy route failed because the engine was cold, unhealthy, or policy-disabled

## ADR-038 — WAN clearnet direct is a manual override, not a default

**Decision:** Keep faster WAN clearnet direct available, but require manual enablement or explicit policy opt-in.

**Why:** Direct IP-to-IP can materially improve speed, but making it the default would quietly re-center the product on the clearnet-first transport hierarchy it is trying not to inherit.

**Implications:**

- default privacy-oriented policies use Tor/I2P before public direct paths
- route/explain surfaces must say when manual speed override is active
- temporary direct enablement should expire cleanly without rewriting durable baseline policy

## ADR-039 — Linux-first quality bar beats early cross-platform parity

**Decision:** Optimize v1 design quality for Linux and common Linux filesystems before treating Windows/macOS as equal design centers.

**Why:** The archive is already deep in daemon semantics, watcher behavior, path binding, and filesystem compatibility. Spreading that effort too early across every desktop platform would dilute correctness and observability where the project most wants to be strong.

**Implications:**

- roadmap and testing center on Linux-first headless operation
- filesystem-compatibility work starts with common Linux semantics
- other platforms remain future work unless they can fit without bending the primary model



## ADR-040 — Privacy-transport session lifecycle must be explicit

Transport engines, transport runtimes, transport sessions, and route outcomes are related but not identical.
The product should expose all four.

Why:

- bundled runtimes otherwise become magical
- route debugging becomes guesswork
- I2P in particular should usually avoid per-transfer session churn
- a future UI should consume the same public transport/session model as the CLI

Consequence:

- the interface and API expose transport-session objects
- I2P defaults toward a very small number of long-lived shared sessions
- manual clearnet speed overrides create visible temporary route state rather than silently widening the base policy

## ADR-041 — Linux-first support requires explicit filesystem tiers

“Linux-first” is not a complete decision until the project publishes which filesystem environments it supports strongly.

Why:

- operators need a correctness contract before adoption or relocation
- xattr/ACL/symlink/network-filesystem behavior is part of the trust boundary
- warning-tier and blocked environments should be visible before data lands there

Consequence:

- the archive names first-class Linux filesystems for v1
- filesystem support tier is exposed as public state
- adopt / relocate / restore / selective workflows can depend on filesystem-probe results

## ADR-042 — Peer-pinned direct paths and route-speed windows are first-class state

**Decision:** Introduce first-class known-host records and route leases for transport exceptions.

**Why:** Resilio's documented `known_hosts`, tracker/relay toggles, and LAN-only cache-clearing rituals show that operators really do need fine-grained route control. But hiding that control inside preference pages and remembered endpoint state makes exposure hard to reason about.

**Consequences:**

- peer-pinned direct admission becomes distinct from ambient public direct
- temporary speed windows become auditable route leases with scope, reason, expiry, and optional byte caps
- exposure reports can explain who currently learns reachability and why a direct candidate exists at all


## ADR-043 — Contacts and pending peers are first-class state, not side effects of linking

**Decision:** Introduce explicit contact and pending-peer surfaces in the public control model.

**Why:** Resilio's linked-device behavior shows that convenience can easily smear together relationship memory, future approval, and ambient visibility. Syncthing's explicit pending-device queue validates that unknown-peer admission is a real product seam worth modeling directly.

**Consequences:**

- unknown or newly introduced peers land in a queue before trust
- ignore and quarantine become durable supported states
- future UI/TUI work gets a supported admission queue instead of inventing one from logs

## ADR-044 — Successor continuity is reviewed state, not ambient inheritance

**Decision:** Treat device succession as an explicit reviewed continuity plan.

**Why:** Linking and replacement solve different problems. The project should not recreate Resilio-style certificate takeover or ambient owner-like carry-forward just because replacing hardware needs to stay practical.

**Consequences:**

- replacement plans show which grants, approvals, contacts, and known-hosts carry forward
- some continuity may be preserved without pretending the successor is literally the same authority
- recovery, retirement, and stewardship surfaces converge on one explicit successor contract
