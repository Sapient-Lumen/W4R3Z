# Daemon API spec (v1 draft)

## Purpose

This document specifies the local daemon control plane that backs the CLI and any future UI/TUI.
The goal is not “have an API somewhere”; the goal is:

- one control model
- local-first administration
- stable enough machine semantics for serious tooling
- explicit events and diagnostics
- observability and audit as first-class surfaces
- previewable, explainable mutation semantics

## Transport

### Preferred local transport

On desktop/server platforms, the daemon should expose:

- a Unix domain socket on Unix-like systems
- a named pipe on Windows

This is the default control channel for local CLI interaction.

### Optional loopback HTTP

The daemon may also expose loopback HTTP for local tooling and a future web UI.
Default bind:

- `127.0.0.1:<port>` only

It must **not** listen on non-loopback interfaces by default.

## Authentication

### Local socket/pipe

Access control is primarily OS-level.
The daemon should verify the connecting user where possible.

### Loopback HTTP

Use a local bearer token generated on first init and stored in daemon state.
Support:

- `Authorization: Bearer <token>`

No unauthenticated mutating endpoints.

## API versioning

Base path:

```text
/v1/
```

Rules:

- additive fields are allowed in minor revisions
- existing field meaning must not silently change
- breaking changes require `/v2/`
- event type names are append-only where possible

## Mutation semantics

### Object identity

All durable objects should include:

- stable ID
- creation timestamp
- update timestamp
- monotonic `version`

### Safe updates

`PATCH` is for bounded field changes only.
High-semantics operations should use action endpoints.

Examples:

- good `PATCH`: rename a share, change a mount mode cap, toggle relay policy
- action endpoint instead of `PATCH`: replace device, rotate identity, revoke peer, clear route cache, apply plan

### List-like policy mutation

List-like policy surfaces such as ignore rules should not rely on ambiguous whole-array replacement by default.
Where an operator means “add one rule” or “remove one rule”, the API should expose item-level resources or explicit action endpoints.
This matters because raw config-patch models in other systems often replace child arrays wholesale, which is technically simple but operator-hostile.

### Idempotency

Mutating HTTP requests should accept an optional idempotency token header for local tooling.
This matters most for retries from wrappers or UI clients.

### Preconditions

High-signal mutating requests should accept version preconditions.
At minimum the API should support one of:

- `If-Match` on the target object version
- explicit `expected_version` fields in action requests
- plan-bound preconditions when applying a previously created plan

If a precondition fails, the API should return a structured drift error rather than silently applying against new state.

---

## Core resource families

### System

```text
GET  /v1/system/info
GET  /v1/system/status
GET  /v1/system/health
GET  /v1/system/logs
GET  /v1/system/paths
GET  /v1/system/capabilities
POST /v1/system/rescan
POST /v1/system/shutdown
```

`GET /v1/system/status` should report at least:

- local device identity
- daemon uptime
- storage path
- active discovery/topology policy
- online peer count
- degraded share count
- open compatibility/preflight warnings count
- pending claims count
- degraded recovery-bundle sufficiency count
- open retirement records count
- active filesystem-compatibility warnings count
- degraded convergence-report count
- active transport-session count by engine
- filesystem paths currently in blocked or warning tier

`GET /v1/system/health` should classify findings as:

- `ok`
- `warning`
- `critical`

### Convergence

```text
GET  /v1/convergence/reports
POST /v1/convergence/reports
GET  /v1/convergence/reports/{convergence_report_id}
POST /v1/convergence/reports/{convergence_report_id}/refresh
POST /v1/convergence/wait
```

These resources exist so tooling can distinguish:

- transfer completion
- source reachability
- degraded change detection due to watcher limits or scan fallback
- clock/freshness blockers
- hidden background work that still weakens settlement confidence

A convergence report should expose at least:

- target scope and intent (`status`, `cutover`, `backup`, `relocate`, `restore`, `maintenance-drain`)
- local and remote `need*` style counts where known
- reachable versus required sources
- watcher / scan health and detection mode
- clock health and any freshness blockers
- background-work classification (`hashing`, `merging`, `dedup-copy`, etc.)
- final state (`idle`, `syncing`, `converged`, `degraded-converged`, `blocked`, `unknown`) and confidence

`POST /v1/convergence/wait` should allow a caller to block until a target satisfies a requested minimum state, or return structured blocker reasons if it cannot.

`GET /v1/system/capabilities` should report:

- supported placeholder strategies
- supported encryption/replica features
- supported invite kinds
- supported route/policy features
- embedded transport-engine inventory and integration kind
- Linux-first filesystem scope / support tier summaries
- explicit v1 platform-scope statement (`linux-only`, `linux-primary`, etc.)
- version/compatibility hints relevant to CLI and UI clients
- supported role templates and downgrade reasons when roles cannot apply cleanly

### Transports

```text
GET  /v1/transports
GET  /v1/transports/{engine}
GET  /v1/transports/{engine}/provenance
POST /v1/transports/{engine}/warm
POST /v1/transports/{engine}/cool
POST /v1/transports/{engine}/verify
GET  /v1/transports/sessions
GET  /v1/transports/sessions/{transport_session_id}
```

These resources exist so bundled Tor/I2P support is not a hidden side effect.
They should expose at least:

- engine name and integration kind
- whether the engine is compiled in or activated from an embedded payload
- bootstrap state and health findings
- runtime paths created locally, if any
- persistent state paths reused across restarts, if any
- whether the engine is merely cold, policy-disabled, verification-degraded, or genuinely failed
- version/build metadata that is safe to expose locally
- update mode (`daemon-release-only`, `independent-payload`, `external-managed`)
- digest/signature/provenance facts the local operator can verify

`GET /v1/transports/{engine}/provenance` should expose the stable facts behind the runtime: payload origin, version/build identifiers, digest, signer/provenance summary, persistence directory, and update mode.

`POST /v1/transports/{engine}/warm` should allow the CLI or a future UI to bring a privacy transport to ready state before a transfer without mutating durable policy.

`POST /v1/transports/{engine}/verify` should recompute or re-check locally available provenance facts without changing durable route policy.

Transport-session resources should expose at least:

- the engine and runtime in use
- whether the session is shared or dedicated
- scope (`system`, `policy`, `share`, `peer`)
- identity scope and reuse posture where that is knowable
- whether the session is overlay, LAN-direct, or WAN-direct
- route counts, last-used time, and degradation reasons
- why the daemon chose reuse versus dedicated sessioning

### Filesystems

```text
GET  /v1/filesystems/support
POST /v1/filesystems/probes
GET  /v1/filesystems/probes/{report_id}
```

These resources exist so Linux support boundaries and target-path safety are first-class inspectable state.

They should expose at least:

- detected filesystem family
- support tier
- case / normalization / xattr / ACL / symlink posture
- whether the target is local, foreign, networked, or FUSE-like
- blockers or warnings for adopt / relocate / restore / selective workflows

### Devices

```text
GET    /v1/devices
POST   /v1/devices
GET    /v1/devices/{device_id}
PATCH  /v1/devices/{device_id}
DELETE /v1/devices/{device_id}
```

Mutations must reject identity-replacement semantics by default.
A device replacement should use the recovery workflow, not a generic patch.
Device representations should also expose enough version/capability metadata for preflight reporting.

### Contacts

```text
GET    /v1/contacts
POST   /v1/contacts
GET    /v1/contacts/{contact_id}
PATCH  /v1/contacts/{contact_id}
POST   /v1/contacts/{contact_id}/trust
POST   /v1/contacts/{contact_id}/quarantine
POST   /v1/contacts/{contact_id}/ignore
```

Contact resources exist so future approval, successor continuity, and relationship memory do not hide inside raw device rows.
They should expose at least:

- relationship class
- contact state
- linked-group membership if any
- future-introduction policy summary
- approval summary and successor policy

### Pending peers

```text
GET    /v1/pending/peers
POST   /v1/pending/peers/{pending_peer_id}/accept
POST   /v1/pending/peers/{pending_peer_id}/dismiss
POST   /v1/pending/peers/{pending_peer_id}/ignore
```

Pending-peer resources exist so unknown or newly introduced devices are reviewable supported state.
They should expose at least:

- observed identity hints
- source of the contact or introduction
- candidate contact / link / claim outcomes
- durable ignore or quarantine decisions

### Retirements

```text
GET    /v1/retirements
POST   /v1/retirements
GET    /v1/retirements/{retirement_id}
POST   /v1/retirements/{retirement_id}/apply
POST   /v1/retirements/{retirement_id}/cancel
```

Retirement resources exist so tooling can distinguish:

- cosmetic hiding
- ignored future contact
- trust revocation
- successor replacement
- identity rotation

A retirement resource should say explicitly whether the old device may still reconnect, whether grants or approval-memory records are being revoked or rebound, and whether a successor device inherits any continuity.

### Links / linked groups

```text
GET    /v1/links
POST   /v1/links
GET    /v1/links/{linked_group_id}
PATCH  /v1/links/{linked_group_id}
POST   /v1/links/{linked_group_id}/members
DELETE /v1/links/{linked_group_id}/members/{device_id}
```

The crucial design point:

- linking is separate from granting
- linking is separate from share visibility policy
- linking is separate from identity replacement
- share visibility can produce incoming objects without creating mounts
- introduction policy must be explicit; ordinary linking does not imply ambient auto-add

### Shares

```text
GET    /v1/shares
POST   /v1/shares
GET    /v1/shares/{share_id}
PATCH  /v1/shares/{share_id}
POST   /v1/shares/{share_id}/pause
POST   /v1/shares/{share_id}/resume
POST   /v1/shares/{share_id}/rescan
```

### Grants

```text
GET    /v1/grants
POST   /v1/grants
GET    /v1/grants/{grant_id}
PATCH  /v1/grants/{grant_id}
DELETE /v1/grants/{grant_id}
```

Grant objects should expose:

- subject identity
- permission
- mode cap
- origin of the grant (`manual`, `policy`, `invite`, `recovery`)
- provenance reference where available

That provenance field matters for auditability.

### Stewardship

```text
GET    /v1/stewardship
GET    /v1/stewardship/{share_id}
PATCH  /v1/stewardship/{share_id}
POST   /v1/stewardship/{share_id}/handoff-plans
GET    /v1/stewardship/handoff-plans/{plan_id}
POST   /v1/stewardship/handoff-plans/{plan_id}/apply
POST   /v1/stewardship/handoff-plans/{plan_id}/cancel
```

Stewardship resources exist so tooling can distinguish:

- data-write rights
- grant / revoke authority
- delegation bounds
- successor nomination and handoff policy
- share governance changes caused by retirement or recovery

A handoff plan should say explicitly what authority moves, what remains with the current steward, and whether retirement / recovery state blocks safe apply.

### Incoming share visibility

```text
GET    /v1/incoming
POST   /v1/incoming/{incoming_id}/compare
GET    /v1/incoming/{incoming_id}
POST   /v1/incoming/{incoming_id}/adopt
POST   /v1/incoming/{incoming_id}/reject
```

These resources represent shares that are visible locally through linking, manual sharing, or recovery, but not yet adopted into a local path.
They exist specifically to avoid coupling share visibility to default-path creation.
Handling one incoming share must not depend on flipping a whole device into a different linked-folder default mode.

### Ignore rules and drift

```text
GET    /v1/shares/{share_id}/ignore-rules
POST   /v1/shares/{share_id}/ignore-rules
GET    /v1/shares/{share_id}/ignore-rules/{rule_id}
PATCH  /v1/shares/{share_id}/ignore-rules/{rule_id}
DELETE /v1/shares/{share_id}/ignore-rules/{rule_id}
POST   /v1/shares/{share_id}/ignore-rules/test
GET    /v1/shares/{share_id}/ignore-drift
```

These resources exist so ignore behavior is a supported part of the control plane rather than an edit-this-hidden-file ritual.
The API should expose:

- the effective ordered rule set
- each rule's origin (`built-in`, `manual`, `profile`, `import`)
- drift or mismatch state where relevant
- whether the daemon considers the current rule state healthy

### Projection policies

```text
GET    /v1/projection-policies
POST   /v1/projection-policies
GET    /v1/projection-policies/{projection_policy_id}
PATCH  /v1/projection-policies/{projection_policy_id}
DELETE /v1/projection-policies/{projection_policy_id}
POST   /v1/projection-policies/{projection_policy_id}/test
```

These resources exist so operators can distinguish namespace suppression from local mount-view omission or placeholder projection.
A projection policy should expose at least:

- whether it applies to a `share` namespace or a `mount` view
- default namespace visibility / remote announcement posture where relevant
- default local projection posture (`omit`, `placeholder`, `metadata-only`, `full`) where relevant
- ordered rules with stable IDs and provenance
- tighten behavior when rules are made stricter after paths are already indexed or materialized
- whether the daemon considers current projection state healthy or review-required

`POST .../test` should answer for a concrete path whether peers learn the path, whether the local mount shows it, whether bytes are expected locally, and whether existing indexed/materialized state creates a review requirement.

### Conflicts

```text
GET  /v1/conflicts
GET  /v1/conflicts/{conflict_id}
POST /v1/conflicts/{conflict_id}/resolve
POST /v1/conflicts/{conflict_id}/defer
```

Conflict objects should include structured candidate data and recommended actions.
The API should not require callers to interpret magic filenames or hidden archive paths in order to resolve an ordinary sync conflict safely.


### Roles

```text
GET    /v1/roles
POST   /v1/roles
GET    /v1/roles/{role_id}
PATCH  /v1/roles/{role_id}
DELETE /v1/roles/{role_id}
```

Roles are reusable least-privilege bundles, not alternate share types.
They exist so link/grant/adopt flows can preserve convenience without collapsing everything into owner-like authority.


### Deviation policies

```text
GET    /v1/deviation-policies
POST   /v1/deviation-policies
GET    /v1/deviation-policies/{policy_id}
PATCH  /v1/deviation-policies/{policy_id}
DELETE /v1/deviation-policies/{policy_id}
```

Deviation-policy resources exist so local-remediation behavior on non-authoritative mounts is not inferred from share type or mode alone.
They should expose at least:

- which write-policy classes the policy applies to
- separate add / modify / delete handling
- whether remote progress continues, pauses, or requires review while deviation exists
- whether capability limits forced stricter remediation than the operator requested

### Path comparisons

```text
GET    /v1/comparisons
GET    /v1/comparisons/{comparison_id}
POST   /v1/comparisons/{comparison_id}/refresh
```

Comparison objects should summarize at least:

- target path state (`empty`, `non-empty`, `already-bound-self`, `already-bound-other`, `service-marker-conflict`)
- identical/local-only/remote-only/collision counts
- whether the compared share appears fully in sync first or not
- whether a later adopt/relocate should be blocked, allowed directly, or forced through plan/apply

The daemon should not silently resolve a non-empty-path adoption or relocation by timestamp folklore alone.
If some automatic winner rule exists, it must be surfaced explicitly in the comparison or resulting plan.

### Mounts

```text
GET    /v1/mounts
POST   /v1/mounts
GET    /v1/mounts/{mount_id}
PATCH  /v1/mounts/{mount_id}
DELETE /v1/mounts/{mount_id}
POST   /v1/mounts/{mount_id}/compare
POST   /v1/mounts/{mount_id}/relocate
POST   /v1/mounts/{mount_id}/set-deviation-policy
GET    /v1/mounts/{mount_id}/deviation-state
POST   /v1/mounts/{mount_id}/review-deviation
```

Mount resources should expose the effective deviation policy and any active deviation state so tooling can answer whether local adds, edits, or deletes are merely flagged, auto-remediated, or currently blocking review.

### Files and materialization

```text
POST /v1/files/fetch
POST /v1/files/evict
POST /v1/files/remove
POST /v1/files/check
POST /v1/files/pin
POST /v1/files/unpin
GET  /v1/files/state?share_id=...&path=...
GET  /v1/files/history?share_id=...&path=...
POST /v1/files/restore
```

These should be task-oriented endpoints because the object being changed is usually “path within mount/share”, not a standalone durable resource.

`POST /v1/files/remove` should require an explicit scope field such as `local` or `share`.
The API should never infer distributed-delete semantics from a generic remove request.

`POST /v1/files/check` should generate a preservation report for actions such as `evict`, `remove-local`, `remove-share`, or `restore-share`.
That report should include remaining plaintext coverage, encrypted-only coverage, history coverage, and any blockers caused by weak rollback posture.

`GET /v1/files/history` should return candidate restore points with provenance, source, and allowed restore scopes.
`POST /v1/files/restore` should require an explicit restore scope and should usually return a plan object for share-wide restore on sensitive paths.
Destructive plans should reference a fresh preservation report when rollback posture materially affects safety.

### Claims

```text
GET    /v1/claims
POST   /v1/claims
GET    /v1/claims/{claim_id}
POST   /v1/claims/{claim_id}/apply
POST   /v1/claims/{claim_id}/reject
```

Claim resources make invite and incoming-share acceptance durable and inspectable.
They should capture at least:

- source invite or incoming reference
- intended local path / mode / role outcome
- referenced preflight or plan IDs
- expiry or drift conditions
- whether the claim widened authority, created a mount, or only staged incoming visibility

### Approval memory

```text
GET    /v1/approvals
POST   /v1/approvals
GET    /v1/approvals/{approval_id}
PATCH  /v1/approvals/{approval_id}
POST   /v1/approvals/{approval_id}/revoke
POST   /v1/approvals/test
```

Approval resources make remembered future approval explicit.
They should capture at least:

- approved subject identity or peer
- bounded scope such as one share, one tag/class of shares, or one linked group
- approver scope (`origin-only`, `linked-group`, `named-devices`)
- maximum role or permission the approval can imply
- expiry, revocation, and last-use facts
- provenance for who issued the approval and under which policy or plan

`POST /v1/approvals/test` should answer whether a hypothetical future share or invite would be auto-approved, and which approval object would authorize it.

### Policies

```text
GET    /v1/policies
POST   /v1/policies
GET    /v1/policies/{policy_id}
PATCH  /v1/policies/{policy_id}
POST   /v1/policies/{policy_id}/cache/clear
GET    /v1/policies/{policy_id}/exposure
```

`GET /v1/policies/{policy_id}/exposure` should summarize at least:

- what the policy publishes about this device/share reachability
- which infrastructure classes receive that publication (`lan`, `private-discovery`, `public-tracker`, `private-relay`, `public-relay`)
- whether the daemon is only dialing known targets or also accepting tracker-learned routes
- which fallback steps would widen metadata exposure compared with the preferred route

### Exposure reports, known hosts, and route leases

```text
GET    /v1/exposure/reports
POST   /v1/exposure/reports
GET    /v1/exposure/reports/{exposure_report_id}
GET    /v1/known-hosts
POST   /v1/known-hosts
GET    /v1/known-hosts/{known_host_id}
DELETE /v1/known-hosts/{known_host_id}
GET    /v1/route-leases
POST   /v1/route-leases
GET    /v1/route-leases/{route_lease_id}
DELETE /v1/route-leases/{route_lease_id}
```

These resources exist so exposure and temporary direct exceptions are supported state rather than preference-page folklore.
They should expose at least:

- what the baseline publication posture is
- which infrastructure classes can currently learn reachability
- which peer-pinned known-host paths exist and for what scope
- which temporary route leases widen or narrow that posture right now
- whether cached endpoint state could preserve an older wider route posture until cleared

`POST /v1/route-leases` should accept explicit scope, effect, TTL, reason, and optional exhaustion bounds such as byte caps.
If a lease modifies public-direct eligibility, `GET /v1/exposure/reports/...` and `GET /v1/routes/...` should both show that fact.

### Overrides and effective state

```text
GET    /v1/overrides
POST   /v1/overrides
GET    /v1/overrides/{override_id}
DELETE /v1/overrides/{override_id}
GET    /v1/effective-state
GET    /v1/effective-state/{subject_type}/{subject_id}
```

These resources exist so maintenance intent does not masquerade as durable configuration.
They should expose at least:

- target scope and mode
- explicit effects on upload, download, scanning, announcement, and delete propagation
- creation provenance and reason
- automatic expiry time or explicit no-expiry acknowledgement
- which underlying policies remain unchanged
- the combined effective state after applying active leases

`GET /v1/effective-state/...` should be cheap enough that CLI and UI surfaces can show it by default whenever temporary overrides affect behavior.

### Routing and peer paths

```text
GET /v1/routes
GET /v1/routes/peers/{device_id}
GET /v1/routes/peers/{device_id}/decision
GET /v1/routes/shares/{share_id}
GET /v1/routes/shares/{share_id}/decision
```

These endpoints exist because transport is policy, not hidden plumbing.
They should expose at least:

- currently active route
- candidate routes
- route source (`lan`, `known-host`, `tracker`, `relay`, `tor`, `i2p`)
- transport class versus exposure class as separate fields
- whether the selected route depended on public or private infrastructure
- cached endpoint entries
- publication facts that made the route possible
- participating transport-runtime references and their current lifecycle state
- whether WAN clearnet direct required a manual override and, if so, that override's scope, expiry, and any byte/transfer exhaustion bound
- whether a direct candidate exists only because of a peer-pinned known-host record
- refusal / fallback reason when a better path was not used
- whether a cache clear is recommended after policy changes
- a structured decision trace with selected route, rejected candidates, and decisive facts when requested

### Transfers

```text
GET   /v1/transfers
GET   /v1/transfers/{transfer_id}
PATCH /v1/transfers/{transfer_id}
```

`PATCH` should allow only limited, explicit actions such as priority changes or cancellation.



### Filesystem profiles and compatibility

```text
GET  /v1/fs/profiles
POST /v1/fs/profiles:inspect
GET  /v1/fs/profiles/{fs_profile_id}
POST /v1/fs/compare
GET  /v1/fs/reports/{fs_compat_report_id}
```

These resources exist so pathname and metadata semantics are inspectable before an action commits.
A filesystem profile should report at least:

- path inspected
- filesystem type and platform family
- case-sensitivity posture
- Unicode normalization posture
- prohibited-name / prohibited-character rules
- symlink / junction handling posture
- metadata fidelity for permissions, xattrs, ACLs, and specials
- timestamp precision and clock-safety findings

A filesystem compatibility report should report at least:

- whether pathnames are safe without rewrite
- whether normalization rewrite or case-fold protection would be required
- whether symlinks or junction-like entries will be blocked, flattened, or preserved
- whether metadata classes will be dropped or downgraded
- whether the finding is `ok`, `auto-correctable`, `warning`, or `blocked`
- which later action can reference the report as a precondition

### Preflight / compatibility reports

```text
POST /v1/preflight/link
POST /v1/preflight/grant
POST /v1/preflight/adopt
GET  /v1/preflight/{report_id}
```

These resources exist so compatibility and authority consequences are inspectable **before** commitment.
A report should include:

- blockers
- warnings
- feature downgrades
- authority changes
- recommended roles or alternative actions
- referenced subject versions/capabilities used to generate the report

Preflight generation should be cheap enough to call routinely from CLI and UI clients.
If a later apply or accept step depends on preflighted assumptions, the plan or action should reference the report and fail explicitly when the report is stale.

### Plans

```text
GET    /v1/plans
POST   /v1/plans
GET    /v1/plans/{plan_id}
POST   /v1/plans/{plan_id}/apply
DELETE /v1/plans/{plan_id}
```

Plan resources are preferred for operations that:

- widen trust boundaries
- install multi-object policy bundles
- replace devices or rebind grants
- depend on exact object versions at preview time

Plan objects should include:

- intended action type
- affected objects
- preconditions
- risk flags
- provenance / initiator
- referenced preservation reports where destructive safety is relevant
- expiry if the preview becomes stale by design

### Backup / recovery

```text
GET  /v1/backups
POST /v1/backups
GET  /v1/backups/{backup_id}
GET  /v1/recovery-bundles
POST /v1/recovery-bundles
GET  /v1/recovery-bundles/{recovery_bundle_id}
POST /v1/recovery-bundles/{recovery_bundle_id}/verify
POST /v1/recover/import
POST /v1/recover/replace-device
POST /v1/recover/rotate-identity
POST /v1/recover/revoke-device
```

Recovery endpoints are intentionally explicit.
Where the real operator intent is trust retirement, the endpoint should return or reference a retirement record instead of pretending that replacement, revocation, and cosmetic cleanup are the same operation.
They should produce high-signal events and audit entries.
Where recovery mutates multiple grants or policies, returning a plan object is preferable.

Recovery-bundle resources exist so encrypted recovery posture is inspectable before failure.
Verification should answer at least:

- whether offline decrypt is presently possible
- whether a surviving daemon/database is still required
- whether metadata is complete enough for target workflow
- which secrets or provenance records are missing

One important boundary: some recovery work should intentionally stay outside the daemon API.
If encrypted-replica recovery must still work after local daemon state is lost, an offline CLI path such as `recover decrypt-replica` is justified precisely because it does not depend on the daemon surviving.
The daemon-side API should still be able to export and verify the recovery material needed for that path while the system is healthy.

### Explain / provenance

```text
GET /v1/explain/{object_type}/{object_id}
```

This endpoint should return a structured decision trace when one exists, including selected outcome, rejected candidates, decisive facts, freshness, and provenance references.

It should answer questions such as:

- why this grant exists
- which policy or profile created this linked-group behavior
- why this route is currently active
- which route candidates were rejected and for what reason
- what exposure policy allowed this route to exist
- which recovery workflow changed this device state

### Audit

```text
GET /v1/audit
GET /v1/audit/{entry_id}
```

Audit entries should be queryable by:

- time range
- type
- subject object
- initiator
- correlation ID
- provenance reference

### Metrics

```text
GET /v1/metrics
```

Format may be JSON initially, with a Prometheus-friendly surface later.
The point is not style.
The point is that transfer, route, event, and health counters are a supported interface.

---

## Event stream

## Why this matters

Syncthing's long-poll event API is a useful reference point: one stream, stable IDs, `since`, optional filtering.
AnonSync should adopt the spirit of that model while making event payloads more operator-oriented.

### Long-poll endpoint

```text
GET /v1/events?since=<event_id>&types=a,b,c&limit=100&timeout=60
```

Behavior:

- returns events after `since`
- blocks until new events are available or timeout expires
- supports filtering by event type
- returns monotonically increasing IDs

If the requested cursor is older than the retained buffer window, the API should return an explicit continuity error rather than pretending no gap exists.

### SSE endpoint

Optional but desirable:

```text
GET /v1/events/stream
```

For simple UI/TUI and dashboard consumers.

### Event envelope

```json
{
  "event_id": "evt_000123",
  "time": "2026-03-09T08:00:00-05:00",
  "type": "transfer.blocked",
  "subject_type": "transfer",
  "subject_id": "trf_01J...",
  "severity": "warning",
  "reason": "PLAINTEXT_SOURCE_UNAVAILABLE",
  "correlation_id": "corr_01J...",
  "data": {
    "share_id": "shr_01J...",
    "path": "Secrets/Taxes/report.pdf",
    "peer_candidates": 2,
    "plaintext_candidates": 0
  }
}
```

### Event classes for v1

#### Identity and trust

- `contact.created`
- `contact.trusted`
- `contact.quarantined`
- `contact.ignored`
- `pending_peer.observed`
- `pending_peer.accepted`
- `pending_peer.dismissed`
- `pending_peer.ignored`
- `device.added`
- `device.updated`
- `device.hidden`
- `device.ignored`
- `device.retirement_started`
- `device.retirement_completed`
- `device.revoked`
- `link.created`
- `link.member_added`
- `identity.rotation_started`
- `identity.rotation_completed`
- `recovery.replace_device_started`
- `recovery.replace_device_completed`

#### Share and grant lifecycle

- `share.created`
- `share.updated`
- `share.paused`
- `share.resumed`
- `incoming.visible`
- `incoming.adopted`
- `incoming.rejected`
- `ignore.rule_added`
- `ignore.rule_removed`
- `ignore.drift_detected`
- `projection.updated`
- `projection.review_required`
- `grant.created`
- `grant.updated`
- `grant.revoked`
- `role.created`
- `role.updated`
- `deviation_policy.created`
- `deviation_policy.updated`
- `preflight.generated`
- `claim.created`
- `claim.applied`
- `claim.rejected`
- `recovery_bundle.exported`
- `recovery_bundle.verified`
- `compatibility.warning`
- `filesystem.compatibility.warning`
- `filesystem.compatibility.blocked`
- `filesystem.profile.changed`

#### Plans and preconditions

- `plan.created`
- `plan.applied`
- `plan.canceled`
- `precondition.failed`

#### Convergence and readiness

- `convergence.report_generated`
- `convergence.state_changed`
- `convergence.blocked`
- `convergence.degraded`

#### Mount and materialization

- `mount.attached`
- `mount.mode_changed`
- `mount.deviation_detected`
- `mount.deviation_cleared`
- `mount.deviation_auto_remediated`
- `file.fetch_queued`
- `file.materialized`
- `file.evicted`
- `file.check_generated`
- `file.remove_local`
- `file.remove_share`
- `file.remove_blocked`
- `file.pin_changed`
- `file.restored_local`
- `file.restored_share`
- `conflict.detected`
- `conflict.resolved`

#### Transport and transfer

- `peer.connected`
- `peer.disconnected`
- `transfer.started`
- `transfer.progress`
- `transfer.blocked`
- `transfer.completed`
- `transfer.failed`
- `route.selected`
- `route.candidate_rejected`
- `route.cache_cleared`
- `decision.trace_recorded`
- `policy.path_changed`

#### Overrides and effective state

- `override.created`
- `override.expiring`
- `override.expired`
- `effective-state.changed`

#### Diagnosis and recovery

- `doctor.finding`
- `backup.created`
- `backup.imported`
- `audit.entry_written`

## Error model

Mutating endpoints should return structured errors.

Example:

```json
{
  "error": {
    "code": "IDENTITY_REPLACEMENT_REQUIRES_RECOVERY_FLOW",
    "message": "Linking cannot overwrite the current device identity.",
    "hint": "Use POST /v1/recover/replace-device instead."
  }
}
```

Drift example:

```json
{
  "error": {
    "code": "PRECONDITION_FAILED",
    "message": "The target share changed after the plan was created.",
    "hint": "Refresh the plan and review new effects before apply."
  }
}
```

## Compatibility contract

The daemon API should be stable enough for:

- shell tooling
- small local dashboards
- TUI/web UI clients
- backup/inspection utilities

It does **not** need to promise perfect forever stability from day one.
But it should promise that object meanings, event semantics, provenance fields, compatibility/preflight semantics, and recovery semantics do not churn casually.
