# Status

## Scope of this revision

This revision is an in-place continuation of `rev0026`, driven by the current request:

- continue research
- evaluate Resilio Sync further, again with real care
- keep the non-cloning case concrete rather than vibes-based
- spend more effort on the interface spec
- preserve Tor and I2P as truly first-class bundled transports
- keep clearnet WAN direct available only as a manual non-default speed option
- treat Linux as the real v1 platform slice rather than a polite platform preference
- keep tightening the archive rather than letting it sprawl

## Honesty note

This package **does** build on the immediately previous AnonSync revision mounted in the working filesystem for this run.
The work therefore reflects a true continuation pass rather than a fresh reconstruction.

## Immediate output of this pass

The archive now contains:

- a new contact / link / approval / succession spec that makes relationship memory, pending peer admission, bounded future approval, and device replacement one coherent interface seam
- richer interface/API surfaces for contact records, pending peers, introduction policy, and successor continuity
- two new canonical flows: reviewing a newly contacting peer before it turns into trust, and allowing bounded introductions without ambient auto-add behavior
- a sharper Resilio comparison around all-devices-as-Owners, automatic cross-device visibility, future linked-device approvals, and certificate takeover during linking
- a narrow Syncthing comparison that validates two concrete ideas worth borrowing: explicit introducer mode and explicit pending-device queues
- archive hygiene fixes for duplicate flow numbering and drifted requirement numbering
- a refreshed open-questions file that now also tracks bounded introductions and successor carry-forward rules

## The main shift

`rev0026` made route exposure, known-host direct paths, and temporary direct-speed exceptions first-class.

`rev0027` adds the next authority layer:

> it is not enough to expose route and grant choice if the archive still leaves contact admission, future approval, and successor continuity scattered across unrelated objects.

That changes the archive in six specific ways:

- the archive now decomposes device convenience into contacts, pending peers, links, grants, approvals, and successor workflows
- unknown or newly introduced peers can be staged, dismissed, ignored, trusted, or linked without silently creating share visibility
- bounded introduction becomes an explicit policy decision instead of ambient linked-device magic
- successor continuity is now described as reviewed state that can carry or revoke grants, approvals, and contact memory intentionally
- Resilio's convenience semantics become evidence of real user demand, but not evidence that broad owner-like authority is the right default
- Linux-first remains explicit: the project still refuses to spread attention across Windows/macOS parity before the local control-plane contract is solid

## What still remains unresolved

This revision intentionally does **not** overclaim closure on several important questions:

- which I2P router implementation should ship first behind the stable contract
- how transport identities should be scoped across device/share/policy boundaries
- how bounded introductions should work, if at all, without recreating ambient trust
- how overlay scheduling should differ from clearnet scheduling in detail
- when, if ever, independently updated bundled transport payloads become worth the extra trust and complexity cost

That narrower unresolved set is what the revised `55-critical-open-questions.md` now tracks.
