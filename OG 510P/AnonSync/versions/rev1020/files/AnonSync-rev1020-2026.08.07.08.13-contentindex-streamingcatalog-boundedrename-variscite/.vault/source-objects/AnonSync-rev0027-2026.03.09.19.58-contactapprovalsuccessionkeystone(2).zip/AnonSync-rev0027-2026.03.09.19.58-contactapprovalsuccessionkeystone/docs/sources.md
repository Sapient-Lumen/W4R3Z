# Sources

This revision intentionally relied on a small set of load-bearing sources checked on 2026-03-09.

## Resilio official

- Resilio Sync 3.0 change log  
  https://help.resilio.com/hc/en-us/articles/31386579044755-Resilio-Sync-3-0-change-log

- Important before updating to Resilio Sync 3.0.0  
  https://help.resilio.com/hc/en-us/articles/31193941051795-Important-before-updating-to-Resilio-Sync-3-0-0

- FAQ Resilio Sync 3.0.0  
  https://help.resilio.com/hc/en-us/articles/32109883606035-FAQ-Resilio-Sync-3-0-0

- Running Sync in configuration mode  
  https://help.resilio.com/hc/en-us/articles/206178884-Running-Sync-in-configuration-mode

- Is there a Command Line Interface (CLI) for Resilio Sync on Windows?  
  https://help.resilio.com/hc/en-us/articles/205506359-Is-there-a-Command-Line-Interface-CLI-for-Resilio-Sync-on-Windows

- Configuring WebUI  
  https://help.resilio.com/hc/en-us/articles/115001184490-Configuring-WebUI

- Sync Private Identity & Linking My Devices  
  https://help.resilio.com/hc/en-us/articles/205457815-Sync-Private-Identity-Linking-My-Devices

- Sync functionality in detail  
  https://help.resilio.com/hc/en-us/articles/204754389-Sync-functionality-in-detail

- Sync Share Dialog (Desktop)  
  https://help.resilio.com/hc/en-us/articles/204790709-Sync-Share-Dialog-Desktop

- Is one-way synchronization possible?  
  https://help.resilio.com/hc/en-us/articles/204754279-Is-one-way-synchronization-possible

- How to create a Read Only folder while syncing across linked devices?  
  https://help.resilio.com/hc/en-us/articles/206216565-How-to-create-a-Read-Only-folder-while-syncing-across-linked-devices

- Comprehensive guide to syncing (Desktop-Desktop)  
  https://help.resilio.com/hc/en-us/articles/204754939-Comprehensive-guide-to-syncing-Desktop-Desktop

- Can I move or rename a syncing folder?  
  https://help.resilio.com/hc/en-us/articles/205450655-Can-I-move-or-rename-a-syncing-folder

- Disconnecting and Removing Folders  
  https://help.resilio.com/hc/en-us/articles/205457785-Disconnecting-and-Removing-Folders

- What's the difference between Standard and Advanced folders?  
  https://help.resilio.com/hc/en-us/articles/204754679-What-s-the-difference-between-Standard-and-Advanced-folders

- User Management  
  https://help.resilio.com/hc/en-us/articles/205471375-User-Management

- Selective Sync  
  https://help.resilio.com/hc/en-us/articles/205458095-Selective-Sync

- Conflict files in Sync  
  https://help.resilio.com/hc/en-us/articles/204753629-Conflict-files-in-Sync

- Ignoring files in Sync (Ignore List)  
  https://help.resilio.com/hc/en-us/articles/205458165-Ignoring-files-in-Sync-Ignore-List

- Synchronization Modes  
  https://help.resilio.com/hc/en-us/articles/205457775-Synchronization-Modes

- What Is an RSLS File?  
  https://help.resilio.com/hc/en-us/articles/206115384-What-Is-an-RSLS-File

- Folder Preferences  
  https://help.resilio.com/hc/en-us/articles/205458125-Folder-Preferences

- Sync Preferences  
  https://help.resilio.com/hc/en-us/articles/204762669-Sync-Preferences

- How to pause syncing  
  https://help.resilio.com/hc/en-us/articles/206217325-How-to-pause-syncing

- Running Sync on schedule  
  https://help.resilio.com/hc/en-us/articles/210783266-Running-Sync-on-schedule

- Using Archive for file versioning and restoring deleted files.  
  https://help.resilio.com/hc/en-us/articles/204754239-Using-Archive-for-file-versioning-and-restoring-deleted-files

- How to manually set the location of the folders synced across linked devices?  
  https://help.resilio.com/hc/en-us/articles/206216615-How-to-manually-set-the-location-of-the-folders-synced-across-linked-devices

- Folders are duplicating with an index (i) in their name.  
  https://help.resilio.com/hc/en-us/articles/204753869-Folders-are-duplicating-with-an-index-i-in-their-name

- Can I force Sync to do local network (LAN) syncing only and not sync via the Internet?  
  https://help.resilio.com/hc/en-us/articles/204754349-Can-I-force-Sync-to-do-local-network-LAN-syncing-only-and-not-sync-via-the-Internet

- Power user preferences  
  https://help.resilio.com/hc/en-us/articles/207371636-Power-user-preferences

- What ports and protocols are used by Sync?  
  https://help.resilio.com/hc/en-us/articles/204754759-What-ports-and-protocols-are-used-by-Sync

- Key structure and flow  
  https://help.resilio.com/hc/en-us/articles/206767810-Key-structure-and-flow

- What is a Relay Server?  
  https://help.resilio.com/hc/en-us/articles/204754779-What-is-a-Relay-Server

- Sync Main View (Desktop)  
  https://help.resilio.com/hc/en-us/articles/204755009-Sync-Main-View-Desktop

- My files don't sync  
  https://help.resilio.com/hc/en-us/articles/205450355-My-files-don-t-sync

- Peers aren't connecting  
  https://help.resilio.com/hc/en-us/articles/205450205-Peers-aren-t-connecting

- "Time difference" error  
  https://help.resilio.com/hc/en-us/articles/204753599--Time-difference-error

- Agent run out of system notify watchers. Updated files will be uploaded only after periodic folder rescan  
  https://help.resilio.com/hc/en-us/articles/360015593120-Agent-run-out-of-system-notify-watchers-Updated-files-will-be-uploaded-only-after-periodic-folder-rescan

- Some internal tasks are taking time to complete  
  https://help.resilio.com/hc/en-us/articles/360015586600-Some-internal-tasks-are-taking-time-to-complete

- Cloning Sync  
  https://help.resilio.com/hc/en-us/articles/360018421940-Cloning-Sync

- How to clear offline devices? (desktop only)  
  https://help.resilio.com/hc/en-us/articles/204762439-How-to-clear-offline-devices-desktop-only

- Can I change the name of my Sync identity?  
  https://help.resilio.com/hc/en-us/articles/206163443-Can-I-change-the-name-of-my-Sync-identity

- How to uninstall Sync?  
  https://help.resilio.com/hc/en-us/articles/204775029-How-to-uninstall-Sync

- Sync and SMB file shares  
  https://help.resilio.com/hc/en-us/articles/207755736-Sync-and-SMB-file-shares

- Soft links, hard links and symbolic links  
  https://help.resilio.com/hc/en-us/articles/205504529-Soft-links-hard-links-and-symbolic-links

- Alt Streams and Xattrs in Sync  
  https://help.resilio.com/hc/en-us/articles/204754729-Alt-Streams-and-Xattrs-in-Sync

## Syncthing official

- REST API  
  https://docs.syncthing.net/dev/rest.html

- Event API  
  https://docs.syncthing.net/dev/events.html

- DevicePaused  
  https://docs.syncthing.net/events/devicepaused.html

- FolderPaused  
  https://docs.syncthing.net/events/folderpaused.html

- Prometheus-Style Metrics  
  https://docs.syncthing.net/users/metrics.html

- GET /rest/stats/device  
  https://docs.syncthing.net/rest/stats-device-get.html

- GET /rest/stats/folder  
  https://docs.syncthing.net/rest/stats-folder-get.html

- Debug Endpoints  
  https://docs.syncthing.net/v1.21.0/rest/debug.html

- Command Line Operation  
  https://docs.syncthing.net/users/syncthing.html

- Config Endpoints  
  https://docs.syncthing.net/rest/config.html

- Understanding Synchronization  
  https://docs.syncthing.net/users/syncing.html

- File Versioning  
  https://docs.syncthing.net/users/versioning.html

- ignoreDelete  
  https://docs.syncthing.net/advanced/folder-ignoredelete.html

- Untrusted Device Encryption  
  https://docs.syncthing.net/specs/untrusted.html

- Introducer Configuration  
  https://docs.syncthing.net/users/introducer.html

- Security Principles  
  https://docs.syncthing.net/users/security.html

- Syncthing Discovery Server  
  https://docs.syncthing.net/users/stdiscosrv.html

- Understanding Device IDs  
  https://docs.syncthing.net/dev/device-ids.html

- Syncthing Configuration  
  https://docs.syncthing.net/users/config.html

- GET /rest/cluster/pending/devices  
  https://docs.syncthing.net/rest/cluster-pending-devices-get.html

- DELETE /rest/cluster/pending/devices  
  https://docs.syncthing.net/rest/cluster-pending-devices-delete.html

- Syncthing Relay Server  
  https://docs.syncthing.net/users/strelaysrv.html

- FAQ  
  https://docs.syncthing.net/users/faq.html

- Folder Types  
  https://docs.syncthing.net/users/foldertypes.html

- GET /rest/db/status  
  https://docs.syncthing.net/rest/db-status-get.html

- GET /rest/db/completion  
  https://docs.syncthing.net/rest/db-completion-get.html

- FolderCompletion  
  https://docs.syncthing.net/events/foldercompletion.html

- caseSensitiveFS  
  https://docs.syncthing.net/advanced/folder-caseSensitiveFS.html

- autoNormalize  
  https://docs.syncthing.net/advanced/folder-autonormalize.html

- Untrusted (Encrypted) Devices  
  https://docs.syncthing.net/users/untrusted.html

## Tor / Arti official

- Frequently Asked Questions | Arti  
  https://arti.torproject.org/FAQs/

## I2P official

- Documentation index  
  https://i2p.net/en/docs/

- Embedding I2P in your Application  
  https://i2p.net/en/docs/applications/embedding/

- SAM V3  
  https://i2p.net/en/docs/api/samv3/

- Application Development  
  https://i2p.net/en/docs/development/applications/

- Bittorrent over I2P  
  https://i2p.net/en/docs/applications/bittorrent/

- I2P Development Roadmap  
  https://i2p.net/en/get-involved/roadmap/

- New I2P Routers (embedding context and router diversity)  
  https://beta.i2p.net/en/blog/2025/10/16/new-i2p-routers/

## Linux / kernel / man-pages official

- inotify(7)  
  https://man7.org/linux/man-pages/man7/inotify.7.html

- rename(2)  
  https://man7.org/linux/man-pages/man2/rename.2.html

- open(2)  
  https://man7.org/linux/man-pages/man2/open.2.html

- ext4 extended attributes  
  https://docs.kernel.org/filesystems/ext4/attributes.html

- Btrfs  
  https://docs.kernel.org/filesystems/btrfs.html

- CIFS usage  
  https://docs.kernel.org/admin-guide/cifs/usage.html

## Reading note

These sources were used to answer a narrow question:

- what Resilio currently still does well
- what should be borrowed conceptually
- what should be rejected as product philosophy
- what a coherent CLI/API/event/audit/plan surface should look like when control and diagnostics are first-class
- where Resilio's current owner/share-type semantics still leave stewardship and handoff too implicit
- where bundled Tor/I2P support needs a real runtime/session model instead of magical privacy claims
- where Linux-first scope should become an explicit filesystem-support contract rather than a generic platform slogan
