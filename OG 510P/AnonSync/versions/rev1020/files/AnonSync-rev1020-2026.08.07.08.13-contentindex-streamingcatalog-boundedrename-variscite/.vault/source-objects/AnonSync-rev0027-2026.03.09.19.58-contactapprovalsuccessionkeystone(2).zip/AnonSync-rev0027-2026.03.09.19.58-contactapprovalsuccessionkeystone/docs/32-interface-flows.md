# Interface flows (canonical operator journeys)

These flows exist as design tests.
If the proposed surface cannot express them clearly, the interface is not ready.

## Flow 1 — link two personal devices without universal hidden authority

Goal:

- link laptop and desktop as personal devices
- allow future convenience
- avoid implicit owner semantics

Suggested flow:

```text
anonsync link create --label personal --profile personal-strict --plan
anonsync plan show pln_01J...
anonsync plan apply pln_01J...
anonsync link add --group personal --invite ./desktop.link
anonsync link show personal --show-provenance
```

Expected semantics:

- devices become members of a linked group
- no local identity is replaced
- no share grant is created unless profile/policy says so
- provenance shows which profile created which defaults

Expected operator answers from CLI alone:

- what the linked group implies
- what it does **not** imply
- whether future shares will auto-grant anywhere
- who or what created those defaults

## Flow 2 — add an untrusted encrypted cache node

Goal:

- use a cheap VPS as storage/transit only
- ensure no plaintext lands there

Suggested flow:

```text
anonsync device add --name cache-vps --addr cache.example.net:4747
anonsync device set cache-vps --trust-class untrusted
anonsync grant create vault --device cache-vps --perm encrypted-replica --plan
anonsync plan show pln_01J...
anonsync plan apply pln_01J...
anonsync status --json
```

Expected semantics:

- remote node can store ciphertext only
- status shows at least one encrypted-only replica
- fetch on another device explains whether a plaintext source is currently reachable

Expected operator answers from CLI alone:

- does this device have plaintext authority?
- which grant caused the ciphertext-only behavior?
- is the share still recoverable if the origin goes offline?

## Flow 3 — make a LAN-only sync policy actually legible

Goal:

- restrict a share to LAN-only sync
- confirm that no tracker/relay path is still in effect

Suggested flow:

```text
anonsync policy create --name lan-only --tracker disabled --relay disabled --lan enabled
anonsync share set media --policy lan-only --plan
anonsync plan show pln_01J...
anonsync plan apply pln_01J...
anonsync policy cache clear --policy lan-only
anonsync doctor --share media
```

Expected semantics:

- share now uses the named policy
- cached non-LAN endpoints are removable through an explicit command
- status and doctor explain whether viable LAN paths exist

Expected operator answers from CLI alone:

- which policy is active
- which peers are currently reachable through LAN
- whether stale non-LAN cached routes were cleared
- why sync is blocked if no viable LAN route exists

## Flow 4 — replace a lost laptop without identity folklore

Goal:

- replace a dead laptop with a new machine
- preserve trust semantics explicitly
- avoid clone-style magic

Suggested flow:

```text
anonsync backup create --output ./preloss.asb
# later on replacement machine
anonsync recover import ./preloss.asb
anonsync recover replace-device --old dev_dead --new dev_new --reason "hardware replacement" --plan
anonsync plan show pln_01J...
anonsync plan apply pln_01J...
anonsync audit --type recovery.replace_device_completed
```

Expected semantics:

- recovery is explicit and auditable
- linked-group membership and grants are reconciled through recovery, not through linking
- any residual access for the dead device can be revoked explicitly

Expected audit highlights:

- initiator
- old device ID
- new device ID
- objects rewritten
- grants re-bound or revoked
- correlation IDs to emitted recovery events

## Flow 5 — answer “why can’t this file fetch?” without guesswork

Goal:

- diagnose a blocked fetch in selective mode

Suggested flow:

```text
anonsync file fetch vault Secrets/Taxes/report.pdf
anonsync transfer list --json
anonsync doctor --share vault
anonsync events --type transfer.blocked --since evt_000120
```

Expected semantics:

- blocked state includes a stable reason code
- doctor points to the same underlying condition as transfer state and event stream
- operator can tell whether the issue is:
  - no reachable peer
  - only encrypted replicas reachable
  - trust/policy mismatch
  - invalid mount or local path permissions

## Flow 6 — widen trust only after an explicit reviewed plan

Goal:

- promote a device from read-only to read-write on a sensitive share
- ensure the operator sees the real blast radius before apply

Suggested flow:

```text
anonsync grant set grt_01J... --perm rw --reason "promote studio laptop" --plan
anonsync plan show pln_01J...
anonsync audit --subject grt_01J...
anonsync plan apply pln_01J...
```

Expected semantics:

- the preview states that write authority is expanding
- any linked-group or policy-derived implications are listed explicitly
- apply fails if relevant share/grant state changed after preview

Expected operator answers from CLI alone:

- exactly what new authority is being granted
- whether any policy references depend on this grant
- whether the plan is still valid to apply

## Flow 7 — capability mismatch should be legible, not mysterious

Goal:

- understand why a requested placeholder or transport feature is unavailable on this host

Suggested flow:

```text
anonsync daemon capabilities
anonsync mount attach media ~/Media --mode selective --json
anonsync doctor --device self
```

Expected semantics:

- capability output states which placeholder strategies are supported locally
- mount or policy operations degrade explicitly or fail explicitly, never silently half-work
- doctor points to the same capability facts as the command failure


## Flow 8 — adopt or relocate into a populated path only after a real comparison

Goal:

- bind a visible share to an already-populated local directory, or move an existing mount to a new path
- surface what is identical, local-only, remote-only, or colliding before commit
- avoid reconnect-dialog or timestamp-win guesswork

Suggested flow:

```text
anonsync incoming compare inc_01J... --path /Volumes/External/Media
anonsync incoming adopt inc_01J... --path /Volumes/External/Media --mode selective --plan
anonsync plan show pln_01J...
anonsync mount compare mnt_01J... --path /Volumes/Archive/Media
anonsync mount relocate mnt_01J... /Volumes/Archive/Media --plan
```

Expected semantics:

- comparison reports whether the target path is empty, already bound, or non-empty
- output classifies identical content, local-only content, remote-only content, and true collisions
- adopt/relocate into a non-empty path does not silently proceed without that comparison becoming part of the review surface
- local path rebinding is auditable separately from share identity or permission changes

Expected operator answers from CLI alone:

- whether the target path is safe to bind directly
- which files would be merged harmlessly
- which paths need policy or manual resolution first
- whether the action changes only local binding or also wider replicated state


## Flow 9 — verify the bundled privacy runtimes before trusting them

Goal:

- inspect what exactly shipped for Tor and I2P on this host
- confirm persistence and update posture
- avoid treating embedded privacy support as a black box

Suggested flow:

```text
anonsync transport list
anonsync transport show tor
anonsync transport verify tor
anonsync transport show i2p
anonsync transport verify i2p
anonsync transport session list
```

Expected semantics:

- output states whether Tor is compiled in and whether I2P is carried as an embedded helper/runtime payload
- verification shows version/build facts, digest/provenance summary, persistence path, and update mode
- the operator can tell whether a degraded transport problem is a bootstrap problem, a verification problem, or an ordinary policy-disable outcome
- session output stays separate from runtime output so “present”, “warm”, and “actively carrying routes” do not blur together

Expected operator answers from CLI alone:

- what exactly is bundled here
- where any persistent runtime state lives
- whether updates come only with daemon releases or through another channel
- whether the runtime is merely present, actually warm, or currently active in route selection

## Flow 10 — grant a temporary clearnet-direct bulk-transfer lease without rewriting durable policy

Goal:

- keep overlay-first WAN policy as the default
- temporarily allow direct clearnet for a trusted high-bandwidth transfer
- make the exception easy to inspect and easy to expire

Suggested flow:

```text
anonsync route show --share media --decision-trace
anonsync route allow-clearnet-direct --share media --ttl 90m --reason "initial seed to trusted workstation"
anonsync route show --share media --explain
anonsync override list
anonsync effective-state share media
```

Expected semantics:

- the normal policy remains overlay-first before and after the lease
- the direct-speed exception has explicit scope, reason, and expiry
- route output says directly that `public-direct` became eligible only because of the active lease
- effective-state output makes clear that durable discovery policy was not rewritten underneath the exception

Expected operator answers from CLI alone:

- what the normal route would have been without the lease
- when the lease expires automatically
- whether the lease is share-scoped, peer-scoped, or broader than intended
- whether a current direct route is ambient policy or a deliberate temporary exception

## Interface quality test

The interface is probably not ready if any of these flows require:

- undocumented support knowledge
- UI-only rescue steps
- guessing hidden transport state
- linking as a substitute for recovery
- manual log scraping just to understand ordinary blocked states
- re-running a dangerous mutation without knowing whether the preview is still valid
- silently creating default-path mounts for newly visible shares
- binding a share into a non-empty path without a comparison report
- using one delete verb for both local space reclamation and distributed deletion


## Flow 11 — adopt a newly visible share without accidental default-path creation

Goal:

- let a linked or manually shared dataset become visible
- choose a local path deliberately
- avoid surprise duplicate folders or default-path mounts
- do this per share without flipping the whole device into a different default mode

Suggested flow:

```text
anonsync incoming list
anonsync incoming show inc_01J...
anonsync incoming defer inc_01J... --reason "waiting for external disk"
anonsync incoming adopt inc_01J... --path ~/Sync/media --mode selective
anonsync mount show ~/Sync/media --show-provenance
```

Expected semantics:

- the share can be visible before a mount exists
- adoption chooses path and initial materialization mode explicitly
- provenance shows whether visibility came from linking, manual share, or recovery
- declining or deferring adoption is a first-class action

Expected operator answers from CLI alone:

- why this share is visible here
- whether it is already mounted anywhere locally
- which policy made it visible
- which path choice actually bound it to the filesystem

## Flow 12 — evict local bytes without risking a share-wide delete

Goal:

- free local disk space on a selective/full mount
- keep the share intact elsewhere
- make destructive share-wide delete a separate reviewed action

Suggested flow:

```text
anonsync file evict media Movies/2025/bigfile.mkv
anonsync file remove media Movies/2025/bigfile.mkv --scope local
anonsync file remove media Movies/2025/bigfile.mkv --scope share --plan
anonsync plan show pln_01J...
```

Expected semantics:

- eviction and local-only remove never delete remote replicas
- share-wide delete is explicitly scoped and previewable
- the command surface makes the blast radius legible before apply

Expected operator answers from CLI alone:

- whether the bytes are still stored locally
- whether the file still exists in the replicated share
- whether the action touched metadata/materialization only or shared state too

## Flow 13 — prove what survives before a share-wide delete

Goal:

- decide whether deleting from the replicated share still leaves any recoverable copy
- distinguish remaining plaintext replicas from encrypted-only remnants
- avoid assuming version history exists when retention or size caps mean it does not

Suggested flow:

```text
anonsync file check vault Secrets/Taxes/report.pdf --for remove-share
anonsync file remove vault Secrets/Taxes/report.pdf --scope share --plan
anonsync plan show pln_01J...
```

Expected semantics:

- `file check` reports local post-action state, known remaining plaintext replicas, encrypted-only replicas, and history coverage/gaps
- `remove --scope share --plan` references that preservation report instead of forcing the operator to reconstruct safety from folklore
- the plan becomes guarded or blocked when the action would leave no known plaintext copy and no credible rollback path

Expected operator answers from CLI alone:

- whether any plaintext bytes will remain anywhere after the delete
- whether recovery would depend only on encrypted replicas or limited history retention
- whether the daemon considers the action low-risk, guarded, high-risk, or blocked

## Flow 14 — recover from encrypted-replica data after local state loss

Goal:

- recover useful data from an encrypted-untrusted replica
- avoid requiring the original daemon state to still exist
- keep the workflow explicit and auditable

Suggested flow:

```text
anonsync recover decrypt-replica --input /mnt/cache/vault --output ./vault-restored
anonsync recover import ./mesh.asb
anonsync doctor --share vault
```

Expected semantics:

- offline recovery can operate without a running daemon when sufficient recovery material exists
- recovery material requirements are explicit
- later daemon-side import/reconciliation remains a separate, auditable step

Expected operator answers from CLI alone:

- whether recovery material is sufficient
- whether recovered output is plaintext, partial, or blocked by missing keys
- what daemon-side follow-up is still required


## Flow 15 — restore a deleted file without browsing hidden archive directories

Goal:

- inspect recoverable prior versions of a file
- restore locally without surprising other peers
- require an explicit reviewed path for replicated restore back into the share

Suggested flow:

```text
anonsync file history workdocs report.docx
anonsync file restore workdocs report.docx --entry hst_01J... --scope local
anonsync file restore workdocs report.docx --entry hst_01J... --scope share --plan
anonsync plan show pln_01J...
```

Expected semantics:

- history output shows candidate restore points, source, capture time, and allowed restore scopes
- local restore does not mutate replicated share state
- share-scope restore is previewable and auditable
- the user never needs to know hidden on-disk archive conventions to perform an ordinary restore

Expected operator answers from CLI alone:

- which prior versions exist
- where they came from
- whether restoring this version will affect only this device or the whole share
- which audit/event records were produced


## Flow 16 — resolve a conflict without treating a magic filename as the API

Goal:

- inspect an actual conflict case
- choose a winner deliberately
- avoid the "delete the weird filename and hope" workflow

Suggested flow:

```text
anonsync conflict list --share workdocs
anonsync conflict show cft_01J...
anonsync conflict resolve cft_01J... --winner candidate_02 --plan
anonsync plan show pln_01J...
anonsync plan apply pln_01J...
```

Expected semantics:

- conflict output shows type, path, candidates, and likely blast radius
- resolution makes clear whether the result is local-only or changes replicated share state
- the user never needs to infer the safe action from a suffix like `.Conflict`
- audit and events record how the conflict was resolved

Expected operator answers from CLI alone:

- what actually conflicted
- which candidates exist
- which resolution was chosen
- whether the resolution affected just this device or the cluster

## Flow 17 — change ignore behavior without editing hidden service files

Goal:

- inspect ignore rules for a share
- add a rule safely
- test whether a path will be ignored
- see whether rule drift exists

Suggested flow:

```text
anonsync ignore list workdocs
anonsync ignore add workdocs '*.tmp'
anonsync ignore test workdocs build/output.log
anonsync ignore set-consistency workdocs --mode warn-on-drift
anonsync share rescan workdocs
```

Expected semantics:

- ignore rules are listed as supported objects with provenance
- adding a rule is incremental and auditable, not a full hidden-file rewrite by default
- `test` explains rule matches in human-readable and machine-readable forms
- drift warnings are explicit if peer-local or imported rule state diverges from policy expectations

Expected operator answers from CLI alone:

- which ignore rules are active
- why a path is ignored or indexed
- whether drift exists
- which audit/event records were produced by the rule change


## Flow 18 — preview a mixed-version or capability-mismatched link before accepting it

Goals:

- inspect a pending personal-device link
- surface version-family, role, or feature downgrade risks before commitment
- avoid learning about compatibility trouble only after identity or policy state changed

Example:

```text
anonsync preflight link --invite ./old-laptop.link
anonsync preflight show rpt_01J...
anonsync link add --group personal --invite ./old-laptop.link --plan
anonsync plan show pln_01J...
```

Expected behavior:

- preflight reports `ok`, `warning`, or `blocked`
- warnings explain concrete downgrade or compatibility consequences
- blocked output points to the exact remediation path instead of letting the operator discover it after the fact
- if the later plan references the report, apply fails when relevant capabilities or versions changed since preview

Operator questions this flow must answer clearly:

- what exactly is incompatible or risky
- whether the issue is a blocker or merely a warning
- whether a different role or policy would make the action safe
- which audit/event records captured the preview and later acceptance

## Flow 19 — add a read-only personal device without downgrading the share model

Goals:

- keep a convenient linked personal mesh
- attach one device as read-only or receive-only
- avoid falling back to a weaker share type or manual key-entry ritual

Example:

```text
anonsync role create --name readonly-viewer --perm ro --write-policy receive-only --mode selective
anonsync preflight grant receipts --group personal --role readonly-viewer
anonsync grant create receipts --group personal --role readonly-viewer
anonsync incoming list
anonsync incoming adopt inc_01J... --path ~/Receipts --role readonly-viewer
```

Expected behavior:

- the same share/grant model stays in use; only the applied role changes
- preflight explains whether the target device can satisfy the role without downgrade
- authority does not silently expand to owner-like power just because the device is part of a personal linked group
- the eventual grant and adoption surfaces show the chosen role and resulting constraints explicitly

Operator questions this flow must answer clearly:

- what authority this device actually receives
- whether local edits will propagate or be blocked
- whether plaintext is permitted on the target device
- whether any capability mismatch forced a different outcome than the requested role

## Flow 20 — claim an offered share without silently turning visibility into a mount

Goal:

- inspect a share-access invite or newly visible incoming share
- choose the local outcome deliberately
- keep an auditable record of what was offered versus what was claimed

Suggested flow:

```text
anonsync invite show ./media.invite
anonsync claim prepare --invite ./media.invite --path ~/Sync/media --mode selective --role readonly-viewer
anonsync claim show clm_01J...
anonsync claim apply clm_01J...
anonsync incoming list
```

Expected semantics:

- inspecting the invite does not itself create a mount
- claim preparation records intended local path, mode, and role
- claim apply can create incoming or adopted state explicitly, but not by surprise
- audit can distinguish offered capability from accepted local state

Expected operator answers from CLI alone:

- what was actually offered
- what this machine claimed
- whether the claim widened authority, created a mount, or only staged visibility
- what drift or expiry would now block apply

## Flow 21 — verify encrypted offline-recovery material before disaster

Goal:

- export supported recovery prerequisites for an encrypted share
- verify sufficiency while the system is healthy
- avoid discovering too late that recovery depends on hidden database state

Suggested flow:

```text
anonsync recover bundle export --type encrypted-offline-decrypt --share vault --output ./vault.arb
anonsync recover bundle verify ./vault.arb
anonsync status
anonsync doctor --share vault
```

Expected semantics:

- recovery bundle export produces a durable artifact with explicit scope and format
- verification says whether offline decrypt is sufficient, partial, or blocked
- status and doctor surface degraded recovery posture when bundle sufficiency changes
- operators do not need to recover database names from logs just to know whether recovery will work

Expected operator answers from CLI alone:

- do I currently have enough material to decrypt offline?
- what dependency, if any, still exists on daemon/database state?
- which share or workflow this bundle covers
- whether rotation or replacement has invalidated older recovery material


## Flow 22 — approve a collaborator for one future share class without creating ambient trust

Goal:

- keep the convenience of not re-approving the same collaborator every time
- bound that convenience to one class of future shares
- make later approval use auditable from CLI/API alone

Suggested flow:

```text
anonsync approval issue --peer alex --scope share-tag:photos --max-role readonly-viewer --approver-scope linked-group --expires 90d --plan
anonsync plan apply pln_01J...
anonsync approval list --peer alex
anonsync approval test --peer alex --share vacation-2026
```

Expected semantics:

- the approval becomes a durable object with explicit scope, approver scope, expiry, and maximum role
- later photo-share invites may use this approval without a fresh prompt, but unrelated shares may not
- audit can show which later action consumed the approval record
- operators do not have to remember invisible certificate history to understand why a future share auto-approved

Expected operator answers from CLI alone:

- what class of future shares this peer is pre-approved for
- which local devices may exercise that approval
- when the approval expires or was last used
- whether the approval can imply read-only, read-write, owner, or encrypted-only access

## Flow 23 — prove a share only uses approved discovery and relay infrastructure

Goal:

- allow only approved topology exposure for one share
- verify not just the chosen route, but what metadata the policy publishes and to whom

Suggested flow:

```text
anonsync policy create --name private-topology \
  --announce-scope private-infra-only \
  --announce-via private-discovery \
  --dial-via known-host,private-discovery \
  --relay private-only \
  --fallback-order known-host,private-discovery,private-relay
anonsync share set workdocs --policy private-topology --plan
anonsync plan show pln_01J...
anonsync plan apply pln_01J...
anonsync policy show private-topology --explain
anonsync route show --share workdocs --json
anonsync policy exposure show private-topology
```

Expected semantics:

- the share binds to a named topology policy, not just a bag of route toggles
- route output explains whether the current path depended on public or private infrastructure
- exposure output explains what reachability is being published, where, and under which fallback rules

Expected operator answers from CLI alone:

- does this policy publish anything to public discovery infrastructure?
- can the daemon still fall back to a relay, and if so which class of relay?
- is it dialing only known/private targets, or also tracker-learned targets?
- what exact policy or fallback step would widen metadata exposure from the current baseline?


## Flow 24 — explain why a route won and what would change it

Goal:

- answer why the daemon chose one route for a share
- identify which alternative paths were rejected
- verify whether policy tightening or cache clearing would actually change the result

Suggested flow:

```text
anonsync route show --share workdocs --explain
anonsync explain route --share workdocs
anonsync policy show private-topology --explain
anonsync doctor --share workdocs
```

Expected semantics:

- route output shows the active path plus serious rejected candidates
- explanation output names decisive facts such as policy restrictions, stale endpoints, missing direct reachability, or relay prohibition
- output says whether the explanation is current or was generated before the last policy/cache change
- doctor can point to the exact remediation if the operator wants a different route

Expected operator answers from CLI alone:

- why did this share use relay/direct/known-host instead of another candidate?
- which candidate routes failed because of policy, and which failed because of reachability?
- would clearing cached endpoints materially change anything?
- which policy change would be required to prevent this route class in the future?


## Flow 25 — drain a device for maintenance without mutating its long-term policy

Goal: prepare a laptop for shutdown on a weak uplink without rewriting grants, share modes, or discovery policy.

```bash
anonsync override create \
  --target device:laptop-ember \
  --mode drain-egress \
  --ttl 45m \
  --reason "shutdown maintenance"

anonsync status --device laptop-ember --json
anonsync explain device laptop-ember --effective
anonsync route show --device laptop-ember --effective
anonsync override show ov_01J...
```

Expected behavior:

- the operator can see that current behavior differs from baseline because of an active override lease
- uploads already in flight may finish, but new downloads do not start
- grants, linked-group policy, and discovery policy remain unchanged durable objects
- the lease carries its own expiry and reason

Later:

```bash
anonsync override list --active
anonsync events --follow
```

The daemon should emit a clean `override.expired` / `effective-state.changed` sequence and the device should return to baseline policy without any hidden config drift.

## Flow 26 — retire a stolen or dead device without confusing cleanup, ignore, revoke, and replace

Problem: a laptop is stolen or a NAS dies. The operator needs to decide whether to merely hide the old device from ordinary lists, ignore future contact from it, revoke its existing authority, or bind a successor device into selected continuity.

```text
$ anonsync device show laptop-old --explain
Device: laptop-old
Trust class: trusted
Retirement status: active
Linked group: personal
Grants: 6
Approval-memory references: 2
Last seen: 2026-03-06T19:11:00-05:00

$ anonsync device retire laptop-old --intent revoke --reason "stolen on train" --plan
Plan: pln_01JRT...
Would create retirement record: rtr_01JRT...
Effects:
  - stop announcements for successorless device references
  - revoke 6 grants
  - revoke 2 approval-memory records
  - clear cached route preferences referencing laptop-old
  - leave historical audit and file-history records intact

$ anonsync plan show pln_01JRT...
Risk: medium
Old device may reconnect after network delay: yes, until peers observe revocation
Successor binding: none
Remote cleanup remaining: 2 peers have not yet observed the retirement

$ anonsync device replace laptop-old --successor laptop-new --plan
Plan: pln_01JRU...
Would create retirement record: rtr_01JRU...
Continuity review:
  - grants to rebind: 4
  - grants to revoke: 2
  - approval-memory to carry forward: 0
  - recovery bundle required: no

$ anonsync plan apply pln_01JRU... --yes
Applied. Retirement record rtr_01JRU... is active.

$ anonsync device retirement show rtr_01JRU...
Intent: replace
Subject: laptop-old
Successor: laptop-new
Grant action: rebind-to-successor
Approval action: revoke
Publication action: stop-announcing
Status: completed
Residual cleanup: one offline peer has not yet observed the retirement
```

What this demonstrates:

- the operator never has to pretend that “remove from list” and “revoke trust” are the same thing
- replacement continuity is reviewed before apply
- remote lag is visible instead of treated as mysterious ghost-device behavior
- the retirement record becomes the durable explanation surface for the exit

## Flow 27 — hand off a small-team share without turning everyone into owners

Problem: a project lead is leaving the share, but the team should not solve that by widening owner-equivalent authority across every linked device or by re-sharing the whole folder with a new key.

```text
$ anonsync stewardship show team-notes
Share: team-notes
Stewards: [lead-laptop]
Grantors: [lead-laptop]
Delegation policy: bounded
Max delegable role: collaborator
Handoff policy: dual-review
Candidate successors: [ops-nas, deputy-laptop]

$ anonsync stewardship plan-handoff team-notes --to deputy-laptop --reviewer ops-nas --plan
Plan: pln_01JRV...
Would update stewardship record: stw_01JRV...
Authority to transfer:
  - grant
  - revoke
Authority to retain:
  - none
Blocked by recovery/retirement state: no
Existing grants affected: 0
Approval-memory records to re-scope: 2

$ anonsync plan show pln_01JRV...
Risk: medium
Preconditions satisfied: yes
Effects:
  - deputy-laptop becomes steward for share team-notes
  - approval-memory scope narrows to successor steward set
  - lead-laptop keeps data access until retirement record completes

$ anonsync stewardship apply pln_01JRV... --yes
Applied. Stewardship record updated.

$ anonsync stewardship show team-notes --explain
Stewards: [deputy-laptop]
Grantors: [deputy-laptop]
Departure behavior for lead-laptop: freeze-grants until retirement completes
Last change provenance: plan pln_01JRV... by lead-laptop reviewed by ops-nas
```

What this demonstrates:

- share governance is not overloaded onto a coarse Owner bit
- a successor can be reviewed before authority moves
- data access and grant authority can diverge during the transition
- later audit can explain exactly how stewardship changed


## Flow 28 — attach a read-only mirror without choosing between silent desync and silent overwrite

Problem: an operator wants a non-authoritative mirror or backup target. They need to know whether accidental local edits will be preserved, auto-reverted, or block further pulls, instead of discovering that behavior from a mode-specific caveat later.

```text
$ anonsync deviation create --name mirror-flag --for receive-only --on-add preserve-and-flag --on-modify preserve-and-flag --on-delete re-fetch
Created deviation policy devpol_01JS0...

$ anonsync role create --name backup-mirror --perm ro --write-policy receive-only --mode full --deviation-policy mirror-flag
Created role rol_01JS0...

$ anonsync grant create project-archive --device backupbox --role backup-mirror
Created grant grt_01JS0...

$ anonsync mount show project-archive --device backupbox --explain
Mount: mnt_01JS0...
Role: backup-mirror
Write policy: receive-only
Deviation policy: mirror-flag
Local add: preserve-and-flag
Local modify: preserve-and-flag
Local delete: re-fetch
Remote progress while deviated: continue-with-warning
Forced by capability: no

$ anonsync status project-archive --device backupbox --explain
Status: degraded-by-local-deviation
Detected deviation:
  - path: reports/q4.csv
  - class: local-modify
  - propagation: blocked from leaving backupbox
  - local bytes preserved: yes
  - remote pulls continue: yes
Recommended actions:
  - review deviation
  - revert local copy
  - clone into conflict artifact
```

What this demonstrates:

- one-way or mirror behavior is not just “read-only plus folklore”
- the operator can inspect add / modify / delete remediation separately
- accidental local edits do not have to choose between silent sync breakage and silent destructive overwrite
- any forced stricter behavior is visible as capability-derived policy, not as a surprise side effect


## Flow 29 — adopt into a mac/windows-mixed path without learning case and Unicode collisions the hard way

Problem: the operator is about to adopt a share containing mixed-case names, decomposed Unicode names, symlinks, and xattrs onto a target path whose filesystem may not preserve all of those semantics.
They need a preflighted answer before creating a mount, not a pile of later `.Conflict`-style surprises.

```text
$ anonsync fs profile ~/Incoming/photos
Path: /Users/alex/Incoming/photos
Filesystem: apfs
Case sensitivity: insensitive
Unicode normalization: nfd
Symlink support: preserve
Junction support: blocked
xattr support: full
ACL support: partial
Timestamp precision: ns
Clock status: ok

$ anonsync fs compare --share travel-archive --path ~/Incoming/photos
Filesystem compatibility report: fsr_01JS9...
Status: warning
Path findings:
  - 2 case-only collisions would be blocked on target
  - 3 names require normalization rewrite to target form nfd
Metadata findings:
  - Windows-style junction entries in share cannot be preserved on target
  - 14 xattr keys will downgrade to portable subset
Recommended actions:
  - reject current path and choose case-sensitive target
  - or continue with explicit normalization policy portable-nfd
  - or strip unsupported metadata classes during adopt

$ anonsync fs explain fsr_01JS9...
Blocked patterns:
  - Reports/Q1.csv vs reports/q1.csv
Auto-correctable:
  - café.jpg -> café.jpg on target normalization
Downgrade consequences:
  - junction-like entries become ordinary directories: not allowed by default
  - xattr set portable-only removes non-portable keys on pull

$ anonsync mount adopt inc_01JS9... --path ~/Incoming/photos --plan --fs-report fsr_01JS9...
Plan: pln_01JS9...
Risk: medium
Preconditions:
  - fs report fsr_01JS9... still fresh
  - share path set unchanged since report generation
Policy deltas:
  - apply normalization policy portable-nfd
  - deny junction preservation on this mount
  - preserve xattrs only in portable subset
```

What this demonstrates:

- filesystem/path semantics are first-class compatibility state, not support lore
- pathname and metadata risk is visible before adoption commits
- auto-correctable rewrites are explicit policy, not magic side effects
- blocked patterns stay blocked until the operator chooses a safer target or different policy


## Flow 30 — hide build outputs from peers without guessing whether names still leak through as placeholders

Problem: a developer share contains `build/` and `.cache/` paths. The operator wants those paths suppressed from the share namespace peers learn about, and also wants a selective local mount on one laptop to omit them entirely instead of showing placeholder noise. They need to know what changes for peers, what changes only locally, and whether already-indexed structure requires review.

```text
$ anonsync projection show codebase
Share projection: prj_01JT1...
Default namespace visibility: visible
Default remote announcement: announce
Tighten behavior: review-existing
No explicit rules

$ anonsync projection test codebase build/output/app.tar
Path: build/output/app.tar
Share namespace visibility: visible
Remote announcement: announce
Local mount default projection: placeholder
Existing indexed structure: yes
Existing local bytes on this device: no
Review required if tightened: yes

$ anonsync projection add codebase --match 'build/**' --namespace hidden --announce suppress
Added rule prjr_01JT1...

$ anonsync projection add mnt_01JT1... --match 'build/**' --local omit
Added rule prjr_01JT2...

$ anonsync projection test codebase build/output/app.tar
Path: build/output/app.tar
Share namespace visibility: hidden
Remote announcement: suppress
Mount mnt_01JT1... local projection: omit
Existing indexed structure: requires review before full retraction
Suggested next step: plan projection-tighten codebase --path build/output/app.tar

$ anonsync plan create --action projection-tighten --share codebase --path build/output/app.tar
Plan: pln_01JT1...
Risk: medium
Effects:
  - stop announcing build/** to peers
  - omit build/** from mount mnt_01JT1...
  - leave already-materialized bytes on workstation-1 unchanged
  - mark previously indexed remote structure for review on peers that have already seen it
```

What this demonstrates:

- share-wide namespace suppression and local mount-view hiding are separate supported actions
- `projection test` answers both “will peers still see the name?” and “will this mount still show a placeholder?”
- tightening rules after indexing is explicit reviewable state, not hidden ignore-timing folklore
- local omission does not silently imply share-wide suppression, and share-wide suppression does not silently delete already-materialized local bytes


## Flow 31 — prove a share is settled enough for cutover instead of guessing from peer counts and warnings

Problem: an operator wants to relocate a mount and treat the current laptop copy as the handoff baseline. The share looks quiet in ordinary status output, but they need to know whether that really means "safe to cut over" or whether clock skew, watcher fallback, hidden merge work, or missing sources still weaken confidence.

```text
$ anonsync status
Shares:
  workdocs   idle   peers 2/3   warnings 1

$ anonsync converge show --share workdocs --intent cutover
Convergence report: cvr_01JU4...
State: degraded-converged
Confidence: medium
Reachable sources: 2 / 3 required
Detection mode: periodic-rescan
Watcher health: degraded
Clock health: ok
Background work: none
Blocking findings: none
Why not high confidence:
  - local watcher exhaustion detected; fresh local edits are only guaranteed on rescan
  - peer studio-nas currently unreachable, so remote completeness is known only for reachable peers
Suggested next step: raise watcher limit, force rescan, or lower required source set for cutover intent

$ anonsync doctor --share workdocs
Findings:
  - WATCHER_EXHAUSTED on laptop-1: local change detection degraded to periodic rescan
  - SOURCE_UNREACHABLE peer studio-nas for share workdocs

$ anonsync share rescan workdocs
Rescan queued

$ anonsync converge wait --share workdocs --intent cutover --timeout 10m
Waiting for: high-confidence convergence
...
Result: blocked
Reason codes:
  - SOURCE_UNREACHABLE
Suggested alternatives:
  - retry with --intent relocate-local-only
  - or mark studio-nas non-required for this cutover plan

$ anonsync converge show --share workdocs --intent relocate --json
{
  "state": "degraded-converged",
  "confidence": "medium",
  "required_sources": 3,
  "reachable_sources": 2,
  "watcher_health": "degraded",
  "detection_mode": "periodic-rescan",
  "blocking_findings": []
}
```

What this demonstrates:

- idle status and settlement confidence are different supported answers
- watcher exhaustion, missing sources, and hidden background work can lower confidence without necessarily meaning "actively syncing"
- a caller can wait for a required readiness level and get structured blocker reasons instead of hand-rolled polling
- cutover, backup, and relocate can demand stricter readiness than casual status inspection

## Flow 32 — keep WAN traffic overlay-first by default

Goal: confirm that a privacy-oriented policy uses Tor and/or I2P for WAN traffic and does not silently fall back to clearnet direct.

```text
anonsync policy create \
  --name privacy-mixed \
  --tor preferred \
  --i2p allowed \
  --clearnet-direct manual-opt-in \
  --dial-via lan-direct,tor,i2p,private-relay

anonsync share set workdocs --policy privacy-mixed
anonsync route show --share workdocs --explain
```

The surface is ready when:

- the policy says explicitly that WAN clearnet direct is manual-only
- route output says which overlay class is active and why
- no operator has to guess whether “direct” is active merely because transfer speed looks good

## Flow 33 — deliberately enable faster clearnet direct for one transfer window

Goal: allow a trusted peer/share to use faster direct WAN routing temporarily without silently rewriting the long-lived privacy stance.

```text
anonsync route allow-clearnet-direct \
  --share media \
  --peer studio-seed \
  --ttl 2h \
  --reason "trusted bulk transfer"

anonsync route show --share media --explain
anonsync override list
```

The surface is ready when:

- the output says direct clearnet is active because of a manual override
- the override has a visible expiry
- policy and effective-state views make it obvious that the durable baseline remains overlay-first

## Flow 34 — inspect bundled Tor/I2P runtime health on Linux

Goal: confirm that the transport engines shipped inside the AnonSync binary story are actually healthy and ready on this host.

```text
anonsync transport list
anonsync transport show tor
anonsync transport show i2p
anonsync doctor
```

The surface is ready when:

- `transport show` distinguishes compiled-in versus embedded-payload integration
- bootstrap and health findings are visible without debug logs
- doctor can say whether a missing privacy route is blocked by policy, bootstrap failure, or Linux-host filesystem/runtime problems



## Flow 35 — warm bundled privacy transports and inspect real session use

Goal:

- keep overlay routing as the default WAN posture
- confirm that the daemon is using inspectable bundled runtimes
- confirm that I2P is reusing a stable shared session instead of churning per transfer

Suggested flow:

```text
anonsync transport list
anonsync transport warm tor
anonsync transport warm i2p
anonsync transport session list
anonsync route show --share archive --decision-trace
```

Expected semantics:

- engine output distinguishes compiled-in versus embedded-helper runtime
- session output distinguishes warm runtime from active route participation
- route output shows whether overlay paths are currently viable and which session(s) they depend on
- operators can tell whether clearnet direct is absent because it is disabled by policy, not because the daemon silently forgot it exists

Expected operator answers from CLI alone:

- which privacy engines are merely installed versus actually warm
- which routes are currently active
- whether I2P is using a shared long-lived session
- whether any WAN direct path is active only because of a manual override

## Flow 36 — deliberately enable faster WAN direct for a short bulk-transfer window

Goal:

- keep privacy-default routing intact
- allow a trusted high-speed bulk copy over clearnet direct
- make the privacy trade explicit and temporary

Suggested flow:

```text
anonsync route show --share media --explain
anonsync route allow-clearnet-direct --share media --ttl 90m --reason "trusted bulk transfer"
anonsync route show --share media --decision-trace
anonsync override list
```

Expected semantics:

- the override is visible as a lease, not a hidden policy edit
- route output states that WAN direct is active because of a temporary operator choice
- decision trace shows which overlay candidates lost and why
- after lease expiry, normal overlay-first routing resumes automatically

## Flow 37 — probe a Linux target path before adoption and learn the support tier

Goal:

- adopt or relocate into a real Linux path safely
- know whether the target filesystem is first-class, warning-tier, or best effort
- surface xattr/ACL/symlink/pathname risk before commitment

Suggested flow:

```text
anonsync fs profile /srv/archive
anonsync fs support --path /srv/archive
anonsync fs compare --share archive --path /srv/archive
anonsync fs explain fsr_01J...
anonsync incoming adopt inc_01J... --path /srv/archive --mode selective --plan
```

Expected semantics:

- support output names the effective support tier
- compare output explains case, normalization, xattr, ACL, special-file, and symlink posture
- adoption requires or strongly prefers a fresh filesystem report when risk is non-trivial
- operators can block themselves from pretending that a weak target path is equivalent to ext4/xfs/btrfs

## Flow 38 — preview route exposure before adopting a WAN posture

Goal:

- understand who can learn reachability before a route policy is exercised
- separate baseline publication from temporary leases
- avoid reconstructing exposure from route symptoms after the fact

Suggested flow:

```text
anonsync exposure show --policy privacy-mixed
anonsync exposure show --share media --effective
anonsync route show --share media --decision-trace
```

Expected semantics:

- exposure output names the infrastructure classes that can currently learn reachability
- effective output shows whether a temporary route lease is widening the baseline stance
- the route decision trace and the exposure report agree on why a candidate is eligible

## Flow 39 — admit a peer-pinned direct path without enabling public direct everywhere

Goal:

- trust one peer at one address for one share window
- gain speed when appropriate
- keep ambient public direct disabled

Suggested flow:

```text
anonsync route known-host add \
  --peer laptop-ember \
  --addr sync.example.net:3847 \
  --share media \
  --ttl 7d \
  --reason "trusted home uplink"
anonsync exposure show --share media --effective
anonsync route show --share media --explain
```

Expected semantics:

- the new path is visible as a known-host record, not a hidden global preference change
- exposure output says that public direct is still not generally allowed
- route output can say when the peer-pinned path is the reason a direct candidate now exists

## Flow 40 — grant a bulk-speed exception that expires by time or bytes

Goal:

- temporarily allow faster public direct for a trusted transfer window
- keep that exception bounded enough that it cannot quietly become ambient policy

Suggested flow:

```text
anonsync route allow-clearnet-direct \
  --share media \
  --peer laptop-ember \
  --ttl 90m \
  --byte-cap 250GiB \
  --reason "trusted bulk transfer"
anonsync route lease show rls_01J...
anonsync route show --share media --decision-trace
```

Expected semantics:

- the speed exception is represented as a first-class route lease
- the lease shows both its expiry time and byte budget when present
- after lease exhaustion, the daemon re-evaluates the route against baseline policy without rewriting that baseline


## Flow 41 — review a newly contacting peer without silently linking or auto-sharing

Goal:

- inspect an unknown or newly introduced peer
- decide whether to trust, defer, quarantine, or ignore
- keep that decision separate from grants and mounts

Suggested flow:

```text
anonsync pending peer list
anonsync pending peer show ppd_01J...
anonsync pending peer accept ppd_01J... --as-contact alex --plan
anonsync plan show pln_01J...
anonsync plan apply pln_01J...
anonsync contact show alex --show-provenance
```

Expected semantics:

- the pending peer record explains whether the contact came from direct contact, linked-device introduction, or share announcement
- accepting the pending peer must say whether it will create only a contact, a link membership, a claim plan, or some combination
- no share grant or mount should appear merely because contact trust was accepted
- ignore and quarantine remain visible durable states, not silent disappearance

Expected operator answers from CLI alone:

- who surfaced this peer and why
- whether the peer was merely trusted as a contact or also linked into a constellation
- whether any future approval or introduction scope was created

## Flow 42 — allow bounded introductions for one trusted constellation without ambient auto-add

Goal:

- allow one trusted device group to surface additional peers for one narrow scope
- keep new peers staged in pending state unless stronger policy is explicitly reviewed
- prove the policy is narrower than Resilio-style ambient linked-device spread

Suggested flow:

```text
anonsync link show personal
anonsync link set personal --introduction-policy pending-only --plan
anonsync plan show pln_01J...
anonsync plan apply pln_01J...
anonsync pending peer list --watch
anonsync contact list
```

Expected semantics:

- the plan shows exactly which link or share scope receives introduction rights
- default outcome is a pending-peer record, not automatic grant or owner-like authority
- explain output shows who may introduce whom, and what happens next when they do
- successor replacement or contact ignore state should be able to narrow or suppress that behavior later

Expected operator answers from CLI alone:

- whether introductions are disabled, pending-only, share-scoped, or wider
- whether any newly surfaced peer automatically gained share visibility or only entered the queue
- how to revoke the policy cleanly without deleting the underlying link group