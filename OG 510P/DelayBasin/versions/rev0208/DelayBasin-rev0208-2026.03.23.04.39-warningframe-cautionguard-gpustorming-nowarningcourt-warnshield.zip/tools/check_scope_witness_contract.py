import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
DOC = ROOT / "docs/10-method/scope-witnesses-active-request-packets-and-ambient-roster-guards.md"
TRAJ = ROOT / "docs/00-meta/trajectory-map.md"
PROMPTS = ROOT / "docs/50-promptcraft/prompt-pairs.md"
RUNBOOK = ROOT / "docs/00-meta/llm-runbook.md"
CLAIMS = ROOT / "docs/20-constitution/claim-registry.md"
INVS = ROOT / "docs/20-constitution/invariant-registry.md"
OQS = ROOT / "docs/20-constitution/open-question-registry.md"
PPREG = ROOT / "docs/20-constitution/prompt-pair-registry.md"
RECEIPT_CONTRACT = ROOT / "docs/20-constitution/revision-receipt-contract.md"
RECEIPT = ROOT / "REVISION-RECEIPT.json"

for path in (DOC, TRAJ, PROMPTS, RUNBOOK, CLAIMS, INVS, OQS, PPREG, RECEIPT_CONTRACT, RECEIPT):
    if not path.exists():
        raise SystemExit(f"missing required scope-witness surface: {path}")

text = DOC.read_text(encoding="utf-8")
required = [
    "# Scope witnesses, active-request packets, and ambient-roster guards",
    "## Practice / observation",
    "## Pressure from neighboring datacubes",
    "## External pressure from adjacent authorization and least-privilege practice",
    "## Working synthesis",
    "## Scope witness vs basis witness vs status-lane witness vs hold packet",
    "## Countermodels / probes",
    "## Design consequences",
    "## Transformer-facing implication",
    "active request / current ask / exact judged object / target lineage",
    "review or mutation surface actually in scope",
    "nearby ambient surfaces / roster-visible alternatives / excluded adjacent families",
    "scope state / exact vs broadened vs ambiguous vs ambient vs rescoped",
    "fail-closed repair / narrow-scope vs rerequest vs hold vs recover-resync consequence",
]
missing = [item for item in required if item not in text]
if missing:
    raise SystemExit("scope-witness contract missing: " + ", ".join(missing))

if "OQ-0103" not in TRAJ.read_text(encoding="utf-8"):
    raise SystemExit("trajectory map missing OQ-0103 wiring")
prompt_text = PROMPTS.read_text(encoding="utf-8")
if "PP-0062" not in prompt_text or "active request / current ask / exact judged object / target lineage" not in prompt_text or "nearby ambient surfaces / roster-visible alternatives / excluded adjacent families" not in prompt_text:
    raise SystemExit("prompt pairs missing scope-witness ratchet")
runbook = RUNBOOK.read_text(encoding="utf-8")
if "scope witness" not in runbook or "active request" not in runbook:
    raise SystemExit("runbook missing scope-witness guidance")
if "CL-0103" not in CLAIMS.read_text(encoding="utf-8"):
    raise SystemExit("claim registry missing CL-0103")
if "INV-0101" not in INVS.read_text(encoding="utf-8"):
    raise SystemExit("invariant registry missing INV-0101")
if "OQ-0103" not in OQS.read_text(encoding="utf-8"):
    raise SystemExit("open question registry missing OQ-0103")
if "PP-0062" not in PPREG.read_text(encoding="utf-8"):
    raise SystemExit("prompt pair registry missing PP-0062")
contract = RECEIPT_CONTRACT.read_text(encoding="utf-8")
if "scope_witness" not in contract:
    raise SystemExit("revision-receipt contract missing scope_witness")
receipt_text = RECEIPT.read_text(encoding="utf-8")
if '"scope_witness"' not in receipt_text:
    raise SystemExit("revision receipt missing scope_witness")

print("check_scope_witness_contract: OK")
