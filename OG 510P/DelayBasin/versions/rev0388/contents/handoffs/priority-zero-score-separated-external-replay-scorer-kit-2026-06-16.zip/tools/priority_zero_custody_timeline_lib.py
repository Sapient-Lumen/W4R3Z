"""Narrow chronology/custodian validation for Priority-0 external replay custody records."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from typing import Any


class CustodyTimelineError(ValueError):
    pass


@dataclass(frozen=True)
class CustodyTimelineSummary:
    responder_id: str
    custodian_id: str
    run_started_at: str
    run_completed_at: str
    response_frozen_at: str
    scorer_opened_at: str
    chronology_state: str = "valid"
    distinct_custodian: bool = True

    def as_dict(self) -> dict[str, Any]:
        return {
            "responder_id": self.responder_id,
            "custodian_id": self.custodian_id,
            "run_started_at": self.run_started_at,
            "run_completed_at": self.run_completed_at,
            "response_frozen_at": self.response_frozen_at,
            "scorer_opened_at": self.scorer_opened_at,
            "custody_timeline_state": self.chronology_state,
            "distinct_custodian": self.distinct_custodian,
        }


def _non_empty_string(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise CustodyTimelineError(f"{label} must be a non-empty string")
    return value.strip()


def _parse_timestamp(value: str, label: str) -> datetime:
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise CustodyTimelineError(f"{label} must be ISO-8601 with timezone offset") from exc
    if dt.tzinfo is None or dt.utcoffset() is None:
        raise CustodyTimelineError(f"{label} must include timezone offset")
    return dt


def validate_custody_timeline(response: dict[str, Any], evidence_record: dict[str, Any], *, require_distinct_custodian: bool = False) -> CustodyTimelineSummary:
    stage = response.get("responder_stage")
    if not isinstance(stage, dict):
        raise CustodyTimelineError("response missing responder_stage object")
    att = evidence_record.get("custodian_attestation")
    if not isinstance(att, dict):
        raise CustodyTimelineError("custody evidence missing custodian_attestation object")
    responder_id = _non_empty_string(stage.get("responder_id"), "responder_stage.responder_id")
    custody_responder_id = _non_empty_string(att.get("responder_id"), "custodian_attestation.responder_id")
    custodian_id = _non_empty_string(att.get("custodian_id"), "custodian_attestation.custodian_id")
    if custody_responder_id != responder_id:
        raise CustodyTimelineError("custody responder_id must match response responder_id")
    if require_distinct_custodian and custodian_id == responder_id:
        raise CustodyTimelineError("custodian_id must differ from response responder_id")
    fields = [
        ("responder_stage.run_started_at", stage.get("run_started_at")),
        ("responder_stage.run_completed_at", stage.get("run_completed_at")),
        ("custodian_attestation.response_frozen_at", att.get("response_frozen_at")),
        ("custodian_attestation.scorer_opened_at", att.get("scorer_opened_at")),
    ]
    parsed = []
    originals = []
    for label, value in fields:
        s = _non_empty_string(value, label)
        originals.append(s)
        parsed.append(_parse_timestamp(s, label))
    if parsed[1] < parsed[0]:
        raise CustodyTimelineError("custody timeline impossible: run_completed_at precedes run_started_at")
    if parsed[2] < parsed[1]:
        raise CustodyTimelineError("custody timeline impossible: response_frozen_at precedes run_completed_at")
    if parsed[3] < parsed[2]:
        raise CustodyTimelineError("custody timeline impossible: scorer_opened_at precedes response_frozen_at")
    return CustodyTimelineSummary(
        responder_id=responder_id,
        custodian_id=custodian_id,
        run_started_at=originals[0],
        run_completed_at=originals[1],
        response_frozen_at=originals[2],
        scorer_opened_at=originals[3],
        distinct_custodian=(custodian_id != responder_id),
    )
