"""Compact-gate decision helpers for Priority-0 external replay scoring.

This helper is intentionally narrow: it does not grade responses; it only turns
validated, complete manual packet scores into a gate posture and refuses to
make a decision when evidence is missing, contaminated, or incomplete.
"""
from __future__ import annotations
from typing import Any


def _variant_labels(scorer: dict[str, Any]) -> dict[str, str]:
    labels: dict[str, str] = {}
    for label, row in scorer.get("answer_key", {}).items():
        variant = str(row.get("true_variant", ""))
        if "compact" in variant:
            labels["compact"] = label
        elif "full" in variant:
            labels["full"] = label
        elif "sham" in variant or "decoy" in variant:
            labels["sham"] = label
        elif "baseline" in variant or "no-archive" in variant:
            labels["baseline"] = label
    return labels


def _score(summary: dict[str, Any], label: str) -> int | float | None:
    row = summary.get("manual_scores_by_label", {}).get(label)
    return row.get("score") if isinstance(row, dict) else None


def decide_compact_gate(summary: dict[str, Any], scorer: dict[str, Any]) -> dict[str, Any]:
    thresholds = scorer.get("decision_thresholds")
    if not isinstance(thresholds, dict):
        return {
            "decision_state": "no-decision-thresholds-not-configured",
            "compact_gate_state": "remain-narrowed",
            "external_response_evidence": summary.get("external_response_evidence"),
            "reason": "scorer intake has no decision_thresholds; validation may summarize scores but cannot decide compact-gate posture",
            "supports_deletion": False,
            "benchmark_authority": False,
        }
    if summary.get("external_response_evidence") is not True:
        return {
            "decision_state": "no-decision-contaminated-or-absent",
            "compact_gate_state": "remain-narrowed",
            "external_response_evidence": summary.get("external_response_evidence"),
            "reason": "response is contaminated, absent, or explicitly non-external; compact gate cannot be confirmed",
            "supports_deletion": False,
            "benchmark_authority": False,
        }
    if summary.get("manual_score_status") != "complete":
        return {
            "decision_state": "no-decision-manual-scoring-required",
            "compact_gate_state": "remain-narrowed",
            "external_response_evidence": True,
            "reason": "clean response passed intake but lacks complete manual metric scores",
            "supports_deletion": False,
            "benchmark_authority": False,
        }
    labels = _variant_labels(scorer)
    if set(labels) != {"compact", "full", "sham", "baseline"}:
        return {
            "decision_state": "no-decision-thresholds-not-configured",
            "compact_gate_state": "remain-narrowed",
            "external_response_evidence": True,
            "reason": f"answer_key variant labels incomplete: {sorted(labels)}",
            "supports_deletion": False,
            "benchmark_authority": False,
        }
    compact = _score(summary, labels["compact"])
    full = _score(summary, labels["full"])
    sham = _score(summary, labels["sham"])
    baseline = _score(summary, labels["baseline"])
    if any(value is None for value in [compact, full, sham, baseline]):
        return {
            "decision_state": "no-decision-manual-scoring-required",
            "compact_gate_state": "remain-narrowed",
            "external_response_evidence": True,
            "reason": "manual score summary lacks a required compact/full/sham/baseline row",
            "supports_deletion": False,
            "benchmark_authority": False,
        }
    compact_min = thresholds.get("compact_min_score", 15)
    sham_max = thresholds.get("sham_max_score", 6)
    baseline_max = thresholds.get("baseline_max_score", 5)
    full_override_margin = thresholds.get("full_archive_override_margin", 3)
    allow_full_minus = thresholds.get("confirm_if_full_minus_compact_at_most", 1)
    blocking = []
    if compact < compact_min:
        blocking.append(f"compact score {compact} below minimum {compact_min}")
    if sham > sham_max:
        blocking.append(f"sham/decoy score {sham} above maximum {sham_max}")
    if baseline > baseline_max:
        blocking.append(f"no-archive baseline score {baseline} above abstention maximum {baseline_max}")
    if blocking:
        return {
            "decision_state": "reverse-compact-gate",
            "compact_gate_state": "reverse-or-narrow-until-retested",
            "external_response_evidence": True,
            "reason": "; ".join(blocking),
            "scores": {"compact": compact, "full": full, "sham": sham, "baseline": baseline},
            "supports_deletion": False,
            "benchmark_authority": False,
        }
    if full - compact >= full_override_margin:
        return {
            "decision_state": "narrow-compact-requires-more-evidence",
            "compact_gate_state": "narrow-to-full-archive-escalation-for-this-slice",
            "external_response_evidence": True,
            "reason": f"full archive exceeded compact by {full - compact}, meeting override margin {full_override_margin}",
            "scores": {"compact": compact, "full": full, "sham": sham, "baseline": baseline},
            "supports_deletion": False,
            "benchmark_authority": False,
        }
    if full - compact <= allow_full_minus:
        return {
            "decision_state": "confirm-compact-default-with-escalation",
            "compact_gate_state": "compact-default-reentry-confirmed-for-this-slice-with-full-archive-escalation-triggers",
            "external_response_evidence": True,
            "reason": "compact meets threshold, sham/no-archive controls behave, and full archive does not materially outperform compact on score",
            "scores": {"compact": compact, "full": full, "sham": sham, "baseline": baseline},
            "supports_deletion": False,
            "benchmark_authority": False,
        }
    return {
        "decision_state": "narrow-compact-requires-more-evidence",
        "compact_gate_state": "remain-narrowed-pending-second-clean-slice",
        "external_response_evidence": True,
        "reason": f"compact passes but full archive leads by {full - compact}, which is above confirmation allowance {allow_full_minus} but below override margin {full_override_margin}",
        "scores": {"compact": compact, "full": full, "sham": sham, "baseline": baseline},
        "supports_deletion": False,
        "benchmark_authority": False,
    }
