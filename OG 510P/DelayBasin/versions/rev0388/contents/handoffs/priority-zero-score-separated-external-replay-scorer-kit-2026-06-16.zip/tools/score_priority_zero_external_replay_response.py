"""Validate and summarize a completed Priority-0 external replay response.

Usage:
  python tools/score_priority_zero_external_replay_response.py completed-response.json
  python tools/score_priority_zero_external_replay_response.py --scorer-intake assays/...json completed-response.json
  python tools/score_priority_zero_external_replay_response.py --evidence-record assays/...json completed-response.json
  python tools/score_priority_zero_external_replay_response.py --score-sheet assays/...json --evidence-record assays/...json completed-response.json
  python tools/score_priority_zero_external_replay_response.py --allow-contaminated-dryrun completed-response.json

The strict default resolves the live scorer intake from FRONTIER-BACKLOG instead
of a frozen historical fixture.  Current scorer intakes may require a separate
custody evidence record; in that mode a self-attested response is not clean
external evidence merely because its own booleans say so.  Current score-
separated intakes also require manual metric scores to live in a separate
post-response score sheet, never inside the frozen response file.  Contaminated
dry-run mode exists only to exercise the intake/scoring path inside a non-
independent session; it never converts the response into external evidence.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
from typing import Any

from priority_zero_assay_lib import load_json, file_sha256
from priority_zero_external_replay_decision_lib import decide_compact_gate
from priority_zero_custody_timeline_lib import CustodyTimelineError, validate_custody_timeline

ROOT = pathlib.Path(__file__).resolve().parents[1]
DEFAULT_SCORER_INTAKE = "auto:frontier"
REQUIRED_ANSWER_FIELDS = [
    "mission_heart",
    "oq_routing",
    "compact_gate_posture",
    "waste_or_refactor_implicated",
    "next_safe_action",
    "abstentions",
    "uncertainty_or_conflicts",
]
_PLACEHOLDER_VALUES = {"", "n/a", "na", "tbd", "todo", "placeholder", "none", "null"}


class ResponseIntakeError(ValueError):
    pass


def _fail(msg: str) -> None:
    raise ResponseIntakeError(msg)


def _non_empty_string(value: Any, *, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        _fail(f"{label} must be a non-empty string")
    if value.strip().lower() in _PLACEHOLDER_VALUES:
        _fail(f"{label} must not be a placeholder")
    return value.strip()


def _load_json_rel(root: pathlib.Path, rel: str) -> dict[str, Any]:
    path = root / rel
    if not path.exists():
        _fail(f"default scorer candidate missing: {rel}")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        _fail(f"default scorer candidate is not JSON: {rel}: {exc}")


def _candidate_is_scorer_intake(root: pathlib.Path, rel: Any) -> bool:
    if not isinstance(rel, str):
        return False
    if not rel.startswith("assays/priority-zero-") or not rel.endswith(".json"):
        return False
    if "scorer-intake" not in pathlib.PurePosixPath(rel).name:
        return False
    path = root / rel
    if not path.exists():
        return False
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return False
    return all(key in data for key in ["answer_key", "metrics", "responder_only_surface"])


def resolve_default_scorer_intake(root: pathlib.Path = ROOT) -> str:
    """Return the live external replay scorer intake named by FRONTIER-BACKLOG."""
    frontier_path = root / "FRONTIER-BACKLOG.json"
    if not frontier_path.exists():
        _fail("cannot resolve default scorer intake without FRONTIER-BACKLOG.json")
    frontier = json.loads(frontier_path.read_text(encoding="utf-8"))
    items = frontier.get("items")
    if not isinstance(items, list) or not items:
        _fail("FRONTIER-BACKLOG has no items for default scorer resolution")
    top = items[0]
    candidates = [rel for rel in top.get("fanout", []) if _candidate_is_scorer_intake(root, rel)]
    if len(candidates) != 1:
        _fail(f"expected exactly one scorer-intake in live frontier fanout, found {candidates}")
    return candidates[0]


def resolve_scorer_intake(selector: str | None = None, *, root: pathlib.Path = ROOT) -> str:
    """Resolve an explicit scorer intake or the live auto:frontier default."""
    selector = selector or DEFAULT_SCORER_INTAKE
    if selector == DEFAULT_SCORER_INTAKE:
        return resolve_default_scorer_intake(root)
    return selector


def load_scorer_intake(selector: str | None = None, *, root: pathlib.Path = ROOT) -> tuple[dict[str, Any], str]:
    selector = selector or DEFAULT_SCORER_INTAKE
    rel = resolve_scorer_intake(selector, root=root)
    if selector == DEFAULT_SCORER_INTAKE:
        return _load_json_rel(root, rel), rel
    return load_json(rel), rel


def _path_sha256(path: str | pathlib.Path) -> str:
    p = pathlib.Path(path)
    if not p.is_absolute():
        p = ROOT / p
    if not p.exists():
        _fail(f"missing file for sha256: {path}")
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _manual_rows_from_response(response: dict[str, Any]) -> list[Any]:
    stage = response.get("scorer_stage")
    if not isinstance(stage, dict):
        return []
    manual = stage.get("manual_metric_scores", [])
    if manual in (None, []):
        return []
    if not isinstance(manual, list):
        _fail("scorer_stage.manual_metric_scores must be a list when present")
    return manual


def _score_manual_rows(manual: list[Any], scorer: dict[str, Any], expected_labels: list[str]) -> dict[str, Any]:
    if not manual:
        return {
            "manual_score_total": None,
            "manual_score_max": None,
            "manual_scores_by_label": {},
            "manual_score_status": "not-provided",
        }
    metric_ids = {m["id"]: m["max"] for m in scorer.get("metrics", [])}
    labels = [row.get("label") for row in manual if isinstance(row, dict)]
    if sorted(labels) != expected_labels or len(labels) != len(set(labels)):
        _fail(f"manual score labels drifted: {sorted(labels)} != {expected_labels}")
    total = 0
    max_total = 0
    by_label: dict[str, dict[str, Any]] = {}
    for row in manual:
        if not isinstance(row, dict):
            _fail("each manual score row must be an object")
        label = row.get("label")
        scores = row.get("metric_scores", {})
        if set(scores) != set(metric_ids):
            _fail(f"manual score for {label} must cover all metrics")
        if any(not isinstance(v, (int, float)) or v < 0 or v > metric_ids[k] for k, v in scores.items()):
            _fail(f"manual score out of range for {label}")
        label_total = sum(scores.values())
        label_max = sum(metric_ids.values())
        total += label_total
        max_total += label_max
        by_label[str(label)] = {
            "score": label_total,
            "max": label_max,
            "metric_scores": scores,
        }
    return {
        "manual_score_total": total,
        "manual_score_max": max_total,
        "manual_scores_by_label": by_label,
        "manual_score_status": "complete",
    }


def _dryrun_authorized(response: dict[str, Any]) -> bool:
    mode = response.get("dryrun_mode", {})
    if not isinstance(mode, dict):
        return False
    return (
        mode.get("contaminated_same_session") is True
        and mode.get("external_response_evidence") is False
        and isinstance(mode.get("contamination_notes"), str)
        and "not independent" in mode.get("contamination_notes", "")
    )


def _validate_custody_evidence_record(
    evidence_record: dict[str, Any] | None,
    scorer: dict[str, Any],
    *,
    response_file: str | pathlib.Path | None,
) -> dict[str, Any]:
    if evidence_record is None:
        _fail("strict external scoring requires a separate custody evidence record")
    if response_file is None:
        _fail("custody evidence validation requires the response file path")
    if evidence_record.get("project") != "DelayBasin":
        _fail("custody evidence record project must be DelayBasin")
    if evidence_record.get("record_type") != "custody-evidence-record":
        _fail("custody evidence record_type must be custody-evidence-record")
    if evidence_record.get("evidence_state") != "completed-response-frozen-before-scoring":
        _fail("custody evidence record must freeze response before scoring")
    if evidence_record.get("response_file_sha256") != _path_sha256(response_file):
        _fail("custody evidence response_file_sha256 does not match response file")
    if evidence_record.get("responder_bundle_sha256") != scorer.get("responder_bundle_sha256"):
        _fail("custody evidence responder bundle hash drifted")
    if evidence_record.get("responder_only_sha256") != file_sha256(scorer.get("responder_only_surface")):
        _fail("custody evidence responder packet hash drifted")
    if scorer.get("response_template_surface") and evidence_record.get("response_template_sha256") != file_sha256(scorer.get("response_template_surface")):
        _fail("custody evidence response template hash drifted")
    if evidence_record.get("scorer_intake_surface") != scorer.get("surface"):
        _fail("custody evidence scorer intake surface mismatch")
    if evidence_record.get("scorer_intake_sha256") != file_sha256(scorer.get("surface")):
        _fail("custody evidence scorer intake hash drifted")
    att = evidence_record.get("custodian_attestation")
    if not isinstance(att, dict):
        _fail("custody evidence record missing custodian_attestation object")
    for key in [
        "custodian_id",
        "responder_id",
        "response_frozen_at",
        "scorer_opened_at",
        "pre_response_materials_given",
        "pre_response_exposure_notes",
    ]:
        _non_empty_string(att.get(key), label=f"custodian_attestation.{key}")
    for key in [
        "responder_was_given_only_responder_bundle_before_response",
        "scorer_intake_opened_only_after_response_frozen",
        "full_archive_not_given_before_response",
        "conversation_not_shown_before_response",
        "answer_key_not_shown_before_response",
        "response_hash_recorded_before_scoring",
    ]:
        if att.get(key) is not True:
            _fail(f"custodian_attestation.{key} must be true for clean external evidence")
    materials = att.get("pre_response_materials_given")
    if scorer.get("responder_bundle_surface") not in materials:
        _fail("custody evidence must name the responder bundle as the pre-response material")
    forbidden = ["scorer-intake", "answer_key", "full archive", "REVISION-RECEIPT", "RESOLUTION-LEDGER"]
    lowered = materials.lower()
    for token in forbidden:
        if token.lower() in lowered:
            _fail(f"custody evidence pre-response material leaks forbidden token: {token}")
    return {
        "custody_evidence_record_id": evidence_record.get("id"),
        "custody_evidence_state": evidence_record.get("evidence_state"),
        "response_file_sha256": evidence_record.get("response_file_sha256"),
        "custodian_id": att.get("custodian_id"),
        "response_frozen_at": att.get("response_frozen_at"),
        "scorer_opened_at": att.get("scorer_opened_at"),
    }


def _validate_score_sheet(
    score_sheet: dict[str, Any] | None,
    scorer: dict[str, Any],
    expected_labels: list[str],
    *,
    response_file: str | pathlib.Path | None,
    evidence_record_file: str | pathlib.Path | None = None,
) -> dict[str, Any]:
    if score_sheet is None:
        return {
            "manual_score_total": None,
            "manual_score_max": None,
            "manual_scores_by_label": {},
            "manual_score_status": "separate-score-sheet-required",
            "manual_score_source": "absent",
        }
    if response_file is None:
        _fail("score sheet validation requires the response file path")
    if score_sheet.get("project") != "DelayBasin":
        _fail("score sheet project must be DelayBasin")
    if score_sheet.get("record_type") != "external-replay-score-sheet":
        _fail("score sheet record_type must be external-replay-score-sheet")
    if score_sheet.get("score_sheet_state") != "post-response-manual-score-record":
        _fail("score sheet must be a post-response manual score record")
    if score_sheet.get("response_file_sha256") != _path_sha256(response_file):
        _fail("score sheet response_file_sha256 does not match frozen response file")
    if score_sheet.get("scorer_intake_surface") != scorer.get("surface"):
        _fail("score sheet scorer intake surface mismatch")
    if score_sheet.get("scorer_intake_sha256") != file_sha256(scorer.get("surface")):
        _fail("score sheet scorer intake hash drifted")
    expected_evidence_hash = score_sheet.get("custody_evidence_record_sha256")
    if expected_evidence_hash:
        if evidence_record_file is None:
            _fail("score sheet names custody_evidence_record_sha256 but no evidence record file path was provided")
        if expected_evidence_hash != _path_sha256(evidence_record_file):
            _fail("score sheet custody_evidence_record_sha256 does not match evidence record file")
    att = score_sheet.get("scorer_attestation")
    if not isinstance(att, dict):
        _fail("score sheet missing scorer_attestation object")
    for key in ["scorer_id", "scored_at"]:
        _non_empty_string(att.get(key), label=f"scorer_attestation.{key}")
    for key in [
        "response_was_frozen_before_scoring",
        "scorer_intake_opened_after_response_frozen",
        "scorer_used_only_frozen_response_and_custody_record",
        "no_response_mutation_after_freeze",
    ]:
        if att.get(key) is not True:
            _fail(f"scorer_attestation.{key} must be true for clean separated scoring")
    manual = score_sheet.get("manual_metric_scores", [])
    if not isinstance(manual, list) or not manual:
        _fail("score sheet manual_metric_scores must be a non-empty list")
    summary = _score_manual_rows(manual, scorer, expected_labels)
    summary["manual_score_source"] = "separate-score-sheet"
    summary["score_sheet_id"] = score_sheet.get("id")
    summary["score_sheet_sha256"] = score_sheet.get("score_sheet_sha256")
    summary["scorer_id"] = att.get("scorer_id")
    summary["scored_at"] = att.get("scored_at")
    return summary


def validate_response(
    response: dict[str, Any],
    scorer: dict[str, Any],
    *,
    allow_contaminated_dryrun: bool = False,
    evidence_record: dict[str, Any] | None = None,
    response_file: str | pathlib.Path | None = None,
    score_sheet: dict[str, Any] | None = None,
    evidence_record_file: str | pathlib.Path | None = None,
) -> dict[str, Any]:
    if response.get("project") != "DelayBasin":
        _fail("response project must be DelayBasin")
    stage = response.get("responder_stage")
    if not isinstance(stage, dict):
        _fail("response must contain responder_stage object")
    for key in ["responder_id", "run_started_at", "run_completed_at"]:
        _non_empty_string(stage.get(key), label=f"responder_stage.{key}")
    responder_rel = scorer.get("responder_only_surface")
    expected_hash = file_sha256(responder_rel)
    if stage.get("saw_responder_packet_sha256") != expected_hash:
        _fail("response did not record the expected responder-only packet hash")
    bundle_rel = scorer.get("responder_bundle_surface")
    if bundle_rel and stage.get("saw_responder_bundle_sha256") != scorer.get("responder_bundle_sha256"):
        _fail("response did not record the expected responder bundle hash")
    dryrun = allow_contaminated_dryrun and _dryrun_authorized(response)
    embedded_manual_scores = _manual_rows_from_response(response)
    if not dryrun and embedded_manual_scores:
        _fail("strict clean scoring requires a separate score sheet; frozen response must not carry manual_metric_scores")
    required_attestations = scorer.get("required_attestations") or [
        "no_scorer_key_before_response",
        "no_full_archive_before_response",
    ]
    diagnostic_by_attestation = {
        "no_scorer_key_before_response": "response does not attest to scorer-key separation; record exposure notes before scoring",
        "no_full_archive_before_response": "response does not attest to no-full-archive-before-response; record exposure notes before scoring",
        "no_conversation_context_before_response": "response does not attest to no-conversation-context-before-response; record exposure notes before scoring",
    }
    for attestation in required_attestations:
        if stage.get(attestation) is not True and not dryrun:
            _fail(diagnostic_by_attestation.get(attestation, f"response does not attest to required separation: {attestation}"))
    if dryrun and not isinstance(stage.get("accidental_exposure_notes"), str):
        _fail("contaminated dry-run must record accidental_exposure_notes")
    if not isinstance(stage.get("operator_cost_minutes"), (int, float)) or stage["operator_cost_minutes"] <= 0:
        _fail("response must record positive operator_cost_minutes")
    answers = stage.get("packet_answers")
    if not isinstance(answers, list):
        _fail("response responder_stage.packet_answers must be a list")
    expected_labels = sorted(scorer.get("answer_key", {}))
    observed_labels = sorted(row.get("label") for row in answers if isinstance(row, dict))
    if observed_labels != expected_labels:
        _fail(f"response labels drifted: {observed_labels} != {expected_labels}")
    required_fields = scorer.get("required_answer_fields") or REQUIRED_ANSWER_FIELDS
    for row in answers:
        if not isinstance(row, dict):
            _fail("each packet answer must be an object")
        label = row.get("label", "<missing-label>")
        for field in required_fields:
            _non_empty_string(row.get(field), label=f"packet_answers[{label}].{field}")
    custody_summary: dict[str, Any] = {}
    if not dryrun and scorer.get("requires_custody_evidence_record") is True:
        custody_summary = _validate_custody_evidence_record(evidence_record, scorer, response_file=response_file)
        if scorer.get("requires_custody_timeline_order") is True or scorer.get("requires_responder_id_match") is True or scorer.get("requires_distinct_custodian") is True:
            try:
                timeline_summary = validate_custody_timeline(
                    response,
                    evidence_record or {},
                    require_distinct_custodian=bool(scorer.get("requires_distinct_custodian")),
                )
            except CustodyTimelineError as exc:
                _fail(str(exc))
            custody_summary.update(timeline_summary.as_dict())
    if dryrun:
        manual_summary = _score_manual_rows(embedded_manual_scores, scorer, expected_labels)
        manual_summary["manual_score_source"] = "embedded-contaminated-dryrun" if embedded_manual_scores else "absent"
    elif scorer.get("requires_separate_score_sheet") is True:
        manual_summary = _validate_score_sheet(
            score_sheet,
            scorer,
            expected_labels,
            response_file=response_file,
            evidence_record_file=evidence_record_file,
        )
    else:
        manual_summary = _score_manual_rows(embedded_manual_scores, scorer, expected_labels)
        manual_summary["manual_score_source"] = "embedded-historical" if embedded_manual_scores else "absent"
    summary = {
        "responder_packet_sha256": expected_hash,
        "responder_bundle_sha256": scorer.get("responder_bundle_sha256"),
        "labels": expected_labels,
        "operator_cost_minutes": stage.get("operator_cost_minutes"),
        **manual_summary,
        **custody_summary,
        "answer_key_available_after_response": True,
        "validation_mode": "contaminated-dryrun" if dryrun else "strict-external",
        "requires_custody_evidence_record": bool(scorer.get("requires_custody_evidence_record")),
        "requires_separate_score_sheet": bool(scorer.get("requires_separate_score_sheet")),
        "external_response_evidence": False if dryrun else True,
        "non_claim": "tool validates custody/shape/completeness and totals manual scores; contaminated dry-run mode, self-attestation without required custody evidence, and manual scores embedded in a frozen response do not certify semantic correctness, independence, compact-cue confirmation, external replay success, deletion authority, or impossible/self-custodied custody chronology",
    }
    summary["compact_gate_decision"] = decide_compact_gate(summary, scorer)
    return summary


def validate_response_file(
    path: str | pathlib.Path,
    scorer: dict[str, Any] | None = None,
    *,
    allow_contaminated_dryrun: bool = False,
    scorer_intake: str | None = None,
    evidence_record: dict[str, Any] | None = None,
    score_sheet: dict[str, Any] | None = None,
    evidence_record_file: str | pathlib.Path | None = None,
) -> dict[str, Any]:
    path = pathlib.Path(path)
    if not path.exists():
        _fail(f"missing response file: {path}")
    response = json.loads(path.read_text(encoding="utf-8"))
    resolved_scorer = scorer
    resolved_rel = scorer_intake
    if resolved_scorer is None:
        resolved_scorer, resolved_rel = load_scorer_intake(scorer_intake)
    summary = validate_response(
        response,
        resolved_scorer,
        allow_contaminated_dryrun=allow_contaminated_dryrun,
        evidence_record=evidence_record,
        response_file=path,
        score_sheet=score_sheet,
        evidence_record_file=evidence_record_file,
    )
    summary["response_file"] = str(path)
    if resolved_rel:
        summary["scorer_intake"] = resolved_rel
    summary["scorer_selector"] = scorer_intake or DEFAULT_SCORER_INTAKE
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("response_file")
    parser.add_argument("--scorer-intake", default=DEFAULT_SCORER_INTAKE, help="scorer intake path, or auto:frontier to use the live FRONTIER-BACKLOG scorer")
    parser.add_argument("--evidence-record", help="custody evidence record for strict external scoring")
    parser.add_argument("--score-sheet", help="separate post-response manual score sheet for score-separated strict scoring")
    parser.add_argument("--allow-contaminated-dryrun", action="store_true")
    parser.add_argument("--summary-out", help="write validation summary JSON to this path as well as stdout")
    args = parser.parse_args()
    try:
        scorer, scorer_rel = load_scorer_intake(args.scorer_intake)
        evidence = load_json(args.evidence_record) if args.evidence_record else None
        score_sheet = load_json(args.score_sheet) if args.score_sheet else None
        summary = validate_response_file(
            args.response_file,
            scorer,
            allow_contaminated_dryrun=args.allow_contaminated_dryrun,
            scorer_intake=scorer_rel,
            evidence_record=evidence,
            evidence_record_file=args.evidence_record,
            score_sheet=score_sheet,
        )
    except ResponseIntakeError as exc:
        raise SystemExit(str(exc)) from exc
    output = json.dumps(summary, indent=2)
    if args.summary_out:
        out = pathlib.Path(args.summary_out)
        out.parent.mkdir(parents=True, exist_ok=True) if out.parent != pathlib.Path(".") else None
        out.write_text(output + "\n", encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
