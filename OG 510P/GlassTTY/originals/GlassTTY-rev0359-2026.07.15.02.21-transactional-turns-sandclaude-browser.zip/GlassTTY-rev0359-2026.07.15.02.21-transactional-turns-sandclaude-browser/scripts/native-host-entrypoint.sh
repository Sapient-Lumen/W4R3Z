#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export PYTHONPATH="$ROOT/daemon/src${PYTHONPATH:+:$PYTHONPATH}"
exec python3 -m glassttyd.native_host "$@"
