# Relabeling, dependence, and category-integrity ladder

## Question in one sentence

Given the archive's closed rule that **category labels are rebuttable and should yield to real control, dependence, residual claim, and standing only as far as needed to stop arbitrage**, **what is the smallest workable ladder for deciding when tax design should respect a chosen label, when it should recognize an intermediate dependence category, when it should recharacterize labor, profit, household flow, or AI activity for a specific base, and when it should disregard the label altogether because it functions mainly as controller-side escape?**[S9][S10][S19][S20][S21][S26][S27][S34][S35][S44][S75][S76]

## Closed rules invoked

This memo does **not** reopen the archive's constitutional waist. It relies on:

- [`../10-framework/classification-arbitrage-and-substance-over-form-routing.md`](../10-framework/classification-arbitrage-and-substance-over-form-routing.md)
- [`../10-framework/beneficial-ownership-and-anti-fragmentation-routing.md`](../10-framework/beneficial-ownership-and-anti-fragmentation-routing.md)
- [`../10-framework/assessment-units-care-and-dependency-routing.md`](../10-framework/assessment-units-care-and-dependency-routing.md)
- [`../10-framework/tax-subjecthood-and-liability-routing.md`](../10-framework/tax-subjecthood-and-liability-routing.md)
- [`../10-framework/standing-representation-and-remedy-routing.md`](../10-framework/standing-representation-and-remedy-routing.md)
- [`../10-framework/administration-explanation-and-appeal-routing.md`](../10-framework/administration-explanation-and-appeal-routing.md)

The constitutional part is already settled: **follow real control, dependence, benefit, and risk rather than contractual theater; preserve genuinely different arrangements where substance really differs; and refuse to let shells, wrappers, or owned model instances manufacture fake independence or fake personhood for tax convenience.**[S9][S10][S19][S20][S21][S27][S34][S35][S44][S75][S76]

## Why calibration is still needed

The closed rule fixes the direction, but a usable operating ladder still has to avoid six different failures at once:

1. **binary worker classification** where all borderline cases are forced into pure employee or pure independent-contractor boxes even when another entity controls market access, pricing, or organization while the worker still bears meaningful economic risk,[S75][S76]
2. **payroll and labor-tax escape by relabeling** where ordinary dependent work is rewritten as entrepreneurial service provision or platform selling with little real change in control,[S21][S75][S76]
3. **fee-flow and royalty alchemy** where residual group profit is relabeled as deductible service or licensing income through related-party choreography,[S9][S21][S34][S35]
4. **household or nominee recoding** where person-based income, wealth, or control is routed through family firms, nominee vehicles, or light shells to move it into a softer bucket,[S34][S35]
5. **fake machine independence** where an owned or tightly controlled AI system is described as an independent vendor, contractor, or proto-person in order to thin controller-side liability,[S10][S19][S20]
6. and **universal anti-sham overreach** where the response to those problems becomes so blunt that genuine small firms, real contractors, and real plurality disappear into one compliance bucket.[S26][S27][S75][S76]

## Small option set

### Option A — printed-label formalism

Respect the contract, invoice path, or entity wrapper unless there is overwhelming sham evidence. This minimizes disputes in the short run, but it is too weak against disguised dependence, related-party fee relabeling, and fake machine independence.[S9][S10][S21][S34][S35][S75][S76]

### Option B — one-axis anti-sham rule

Use one dominant test such as legal control, invoice issuer, or beneficial owner alone. This catches some easy cases, but it is too crude for mixed-dependence work, intermediate contractor cases, and multi-layer controller stacks.[S34][S35][S75][S76]

### Option C — base-specific multi-factor recharacterization with an intermediate dependence lane

Recognize that some cases are neither fully independent nor fully ordinary employment, and recharacterize only for the contested base or obligation: payroll withholding, social contribution, simplified-regime access, related-party deduction limits, controller-side AI liability, or anti-splitting thresholds.[S21][S26][S27][S75][S76]

This is the narrowest approach that still respects genuine difference.

### Option D — controller-side disregard for repeated or structured fiction

Where the label survives only because shells, nominee chains, or owned model instances stand between the state and the real controller, disregard the label for the contested tax purpose and route liability, withholding, bonding, or reporting to the controller chain instead.[S10][S19][S20][S34][S35]

## Provisional recommendation

Adopt a **five-stage practical ladder**:

| Stage | When it should apply | Classification answer | Main guardrail |
|---|---|---|---|
| 0. ordinary category-respect lane | the legal label broadly matches who sets terms, bears risk, captures residual upside, and can exit or redesign the activity | **respect the chosen category** | do not reclassify merely because another category would raise more revenue |
| 1. mixed-dependence lane | another entity materially controls prices, access to clients, workflow, or terms, but the actor still bears some real economic risk or invests own tools/capital | **use an intermediate dependence treatment with enhanced disclosure rather than forcing false pure independence or false pure employment** | do not let binary classification erase real but partial autonomy |
| 2. contested-base recharacterization lane | one label is clearly defeating the moral target of a specific tax base or obligation | **recharacterize for that base only** — e.g. payroll / withholding, simplified-regime access, related-party deduction limits, or benefit clawback | keep the rewrite base-specific rather than turning one tax dispute into total legal recoding |
| 3. controller-group look-through lane | the relabeling works only because a household, trust, shell, or affiliate chain fragments one real controller or beneficiary pattern into multiple categories | **trace through to beneficial owners, common control, or the responsible controller group for the contested rule** | do not import anti-fragmentation logic into ordinary person-based human taxation unless a real anti-avoidance trigger exists |
| 4. barred-fiction lane | the category depends on pretending an owned AI system, nominee entity, or repeat sham intermediary is an independent taxpayer, vendor, or rights-bearing subject when standing and control say otherwise | **disregard the fiction and route liability to the accountable controller / beneficiary side** | do not let machine fluency, API separation, or wrapper form simulate independent civic tax subjecthood |

The archive's provisional setting is therefore **stage 0 by default, stage 1 for genuine intermediate dependence, stage 2 for base-specific relabeling fights, stage 3 where the category dodge relies on controller or beneficiary chains, and stage 4 where the label is essentially an escape device for a stronger actor rather than a real social form**.[S9][S10][S19][S20][S21][S26][S27][S34][S35][S44][S75][S76]

That is the narrowest workable recommendation because it defeats disguised dependence and controller-side laundering without collapsing every unusual arrangement into one universal bucket.

For current AI taxation, the practical implication is sharp: **an owned or tightly controlled LLM stack may be technically distributed across wrappers, vendors, or interfaces, but it does not become an independent civic taxpayer merely because the controller inserts another label between itself and the burden.**[S10][S19][S20][S34][S35]

## Anti-patterns

- **Contract worship** — assuming the printed label decides the tax category even when pricing power, work organization, or shutdown power point elsewhere.[S21][S75][S76]
- **Binary purity fetish** — insisting every worker is either fully independent or fully employed, leaving no principled lane for dependent contractors and other in-between cases.[S75][S76]
- **One-base universalism** — treating a payroll, VAT, wealth, or profit recharacterization as if it automatically rewrote every legal relation for every other purpose.[S26][S27]
- **Household or shell recoding** — moving person-based income or control into family entities, nominee holdings, or thin firms without changing who really benefits.[S34][S35]
- **Machine-vendor theater** — claiming the model, bot, or wrapper is the real seller or taxpayer when ownership, deployment control, and beneficiary chains remain human-controlled.[S10][S19][S20]

## What would change the recommendation

This ladder should be tightened, loosened, or partly replaced if any of the following become clearer:

- administrations become substantially better at observing dependent-contractor patterns and intermediate dependence directly, which could widen stage 1 and reduce cruder stage-2 fights,[S75][S76]
- simplified-regime abuse or related-party relabeling proves more systematic, pushing more cases from stage 2 toward stage 3,[S9][S26][S34][S35]
- notice, explanation, and appeal design improve enough that base-specific recharacterization can stay narrow without becoming arbitrary,[S27][S44]
- or some future artificial system actually crosses into rights-bearing personhood with standing and remedy, in which case stage 4 would no longer apply to that class and the archive should re-enter the regime-switch framework instead of treating the old anti-fiction rule as eternal.[S19][S20]

## Source IDs only

[S9][S10][S19][S20][S21][S26][S27][S34][S35][S44][S75][S76]

[S9]: ../../SOURCES.md#S9
[S10]: ../../SOURCES.md#S10
[S19]: ../../SOURCES.md#S19
[S20]: ../../SOURCES.md#S20
[S21]: ../../SOURCES.md#S21
[S26]: ../../SOURCES.md#S26
[S27]: ../../SOURCES.md#S27
[S34]: ../../SOURCES.md#S34
[S35]: ../../SOURCES.md#S35
[S44]: ../../SOURCES.md#S44
[S75]: ../../SOURCES.md#S75
[S76]: ../../SOURCES.md#S76
