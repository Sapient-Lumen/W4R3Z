"""Core workflow model + runner."""
