# Current public context — rev0051

Rev0051 refreshed public context before changing filing state. The result is unchanged from the prior boundary: broad 3.3.11 release-candidate language and public path traversal PRs remain context only.

|row|source|observed|decision|
|---|---|---|---|
|homepage-stable-rc|https://nicotine-plus.org/|Homepage observed with stable 3.3.10 and a request for testers to help test 3.3.11 release candidate.|context only; source-refresh caveat retained|
|news-3.3.11-rc1|https://nicotine-plus.org/NEWS.html|NEWS observed with Version 3.3.11 Release Candidate 1 and broad correction language for uncompressed network message size limits, upload spoofing, username identity, distributed search, and empty-room search crash.|overlap context only; keep packet-specific claim boundaries|
|milestone-3.3.11|https://github.com/nicotine-plus/nicotine-plus/milestone/15|Milestone observed as 97% complete, last updated Jun 12 2026, with open PR #3781.|public-watch only|
|pr-3781|https://github.com/nicotine-plus/nicotine-plus/pull/3781|Open safe_path_join path traversal PR with note that safe_path_join removes illegal/path traversal components and keeps final path under base path.|public-watch only; not a private packet|
|pr-3723|https://github.com/nicotine-plus/nicotine-plus/pull/3723|Closed clean_path path traversal PR; historical public context for path traversal handling.|public-overlap only|
