# Current public context refresh — rev0050

Observed during rev0050 creation.

|row|source|observed|decision|
|---|---|---|---|
|homepage-stable-rc|https://nicotine-plus.org/|Homepage lists 3.3.10 as stable and points testers to the 3.3.11 release candidate.|context only|
|news-3.3.11-rc1|https://nicotine-plus.org/NEWS.html|NEWS lists 3.3.11 RC1 and broad corrections around uncompressed message limits, upload spoofing, username identity, distributed search, and empty-room search.|overlap context; retain packet-specific claim boundaries|
|milestone-pr-3781|https://github.com/nicotine-plus/nicotine-plus/milestone/15|3.3.11 milestone observed as 97% complete with open PR #3781.|public-watch only|
|pr-3781|https://github.com/nicotine-plus/nicotine-plus/pull/3781|Open safe_path_join path-traversal PR.|public-watch only; not a private packet|
|pr-3723|https://github.com/nicotine-plus/nicotine-plus/pull/3723|Closed clean_path path-traversal PR and historical discussion.|historical public-overlap context only|

Decision: context only; no new private packet is opened and no existing production-gated packet is retired.
