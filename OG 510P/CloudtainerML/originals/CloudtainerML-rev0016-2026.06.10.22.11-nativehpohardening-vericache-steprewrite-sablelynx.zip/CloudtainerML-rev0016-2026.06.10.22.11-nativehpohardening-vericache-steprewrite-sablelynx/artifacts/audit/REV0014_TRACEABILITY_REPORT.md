# Traceability report — rev0014

## Summary

- source_count: 207
- idea_count: 180
- cell_count: 181
- probe_file_count: 38
- probe_output_count: 70
- orphan_p0_source_count: 0
- orphan_p0_idea_count: 0
- cell_note_missing_count: 0

## P0 gaps

- P0 sources missing idea/cell links: 0
- P0 ideas missing cells: 0
- cells missing cell notes: 0

## Refactor rule

Every P0 source should bind to at least one idea and cell; every runnable probe should have a cell note and primary metric output.
