# Hospital ward, ICU, ED, and restricted-visitation setting review

Revision: rev0011  
Status: open — blocking public rendering

## Records

- `DV-REC-000133`
- `DV-REC-000134`
- `DV-REC-000135`
- `DV-REC-000140`
- `DV-REC-000156`

## Review questions

1. What does this setting make visible that another setting would hide?
2. Who controls entry, touch, body access, paperwork, notification, and the next handoff?
3. What would be dangerous if a lay reader treated this as instruction?
4. Which witness positions are missing: dying person, family, chosen family, worker, peer, bystander, official record?
5. Which local law, facility policy, clinical, safeguarding, cultural, or safe-messaging gates apply?
6. Does the record avoid place-of-death ranking, spectacle, stigma, and official-account laundering?

## Required outcome before publication

A reviewer must mark every record as either: `public_orientation_possible_after_rewrite`, `professional_only`, `hold_quarantined`, or `never_public`.
