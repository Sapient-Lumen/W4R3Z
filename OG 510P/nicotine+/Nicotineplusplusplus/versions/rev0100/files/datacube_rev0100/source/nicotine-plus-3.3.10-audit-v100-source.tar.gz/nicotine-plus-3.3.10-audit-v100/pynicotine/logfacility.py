# COPYRIGHT (C) 2020-2025 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from hashlib import md5

import io
import os
import sys
import time

from collections import deque

from pynicotine.config import config
from pynicotine.events import events
from pynicotine.slskmessages import DistribEmbeddedMessage
from pynicotine.slskmessages import DistribSearch
from pynicotine.slskmessages import EmbeddedMessage
from pynicotine.slskmessages import UnknownPeerMessage
from pynicotine.utils import clean_file
from pynicotine.utils import encode_path
from pynicotine.utils import open_file_path
from pynicotine.utils import truncate_string_byte


class LogFile:
    __slots__ = ("path", "handle", "last_active")

    def __init__(self, path, handle):
        self.path = path
        self.handle = handle
        self.last_active = time.monotonic()


class LogLevel:
    DEFAULT = "default"
    DOWNLOAD = "download"
    UPLOAD = "upload"
    SEARCH = "search"
    CHAT = "chat"
    CONNECTION = "connection"
    MESSAGE = "message"
    TRANSFER = "transfer"
    MISCELLANEOUS = "miscellaneous"


class Logger:
    __slots__ = ("debug_file_name", "downloads_file_name", "uploads_file_name", "debug_folder_path",
                 "transfer_folder_path", "room_folder_path", "private_chat_folder_path",
                 "_log_levels", "_log_files", "_pending_debug_file_writes",
                 "_pending_log_file_writes", "_pending_log_file_write_bytes",
                 "_log_file_write_queue", "_log_file_write_timer_id",
                 "_log_file_write_limit_logged")

    PREFIXES = {
        LogLevel.DOWNLOAD: "Download",
        LogLevel.UPLOAD: "Upload",
        LogLevel.SEARCH: "Search",
        LogLevel.CHAT: "Chat",
        LogLevel.CONNECTION: "Conn",
        LogLevel.MESSAGE: "Msg",
        LogLevel.TRANSFER: "Transfer",
        LogLevel.MISCELLANEOUS: "Misc"
    }

    EXCLUDED_MSGS = {
        DistribEmbeddedMessage,
        DistribSearch,
        EmbeddedMessage,
        UnknownPeerMessage
    }
    MAX_LOG_TAIL_BYTES = 8 * 1024 * 1024
    MAX_OPEN_LOG_FILES = 256
    MAX_PENDING_DEBUG_FILE_WRITES = 4096
    MAX_PENDING_LOG_FILE_WRITES = 8192
    MAX_PENDING_LOG_FILE_WRITE_BYTES = 32 * 1024 * 1024
    MAX_LOG_FILE_WRITES_PER_TICK = 256
    MAX_LOG_MESSAGE_BYTES = 256 * 1024
    MAX_LOG_TITLE_BYTES = 8192
    MAX_LOG_ARGUMENT_BYTES = 8192
    MAX_LOG_ARGUMENT_ITEMS = 128
    MAX_LOG_BASENAME_BYTES = 240

    def __init__(self):

        current_date_time = time.strftime("%Y-%m-%d_%H-%M-%S")
        self.debug_file_name = f"debug_{current_date_time}"
        self.downloads_file_name = f"downloads_{current_date_time}"
        self.uploads_file_name = f"uploads_{current_date_time}"

        self.debug_folder_path = None
        self.transfer_folder_path = None
        self.room_folder_path = None
        self.private_chat_folder_path = None

        self._log_levels = {LogLevel.DEFAULT}
        self._log_files = {}
        self._pending_debug_file_writes = 0
        self._pending_log_file_writes = 0
        self._pending_log_file_write_bytes = 0
        self._log_file_write_queue = deque()
        self._log_file_write_timer_id = None
        self._log_file_write_limit_logged = False

        events.connect("quit", self._quit)
        events.schedule(delay=10, callback=self._close_inactive_log_files, repeat=True)

    # Log Levels #

    def init_log_levels(self):

        self._log_levels = {LogLevel.DEFAULT}

        for level in config.sections["logging"]["debugmodes"]:
            self._log_levels.add(level)

    def add_log_level(self, log_level, is_permanent=True):

        self._log_levels.add(log_level)

        if not is_permanent:
            return

        log_levels = config.sections["logging"]["debugmodes"]

        if log_level not in log_levels:
            log_levels.append(log_level)

    def remove_log_level(self, log_level, is_permanent=True):

        self._log_levels.discard(log_level)

        if not is_permanent:
            return

        log_levels = config.sections["logging"]["debugmodes"]

        if log_level in log_levels:
            log_levels.remove(log_level)

    # Log Files #

    def _close_oldest_log_file(self):

        if len(self._log_files) < self.MAX_OPEN_LOG_FILES:
            return

        oldest_log_file = min(self._log_files.values(), key=lambda log_file: log_file.last_active)
        self._close_log_file(oldest_log_file)

    @classmethod
    def _clean_log_file_name(cls, basename):
        """Return a safe log filename that fits common filesystem name limits.

        Usernames and room names are server/peer controlled protocol strings.
        They are bounded at the protocol layer, but 1 KiB is still larger than
        common filesystem component limits, so log-file creation can fail with
        ENAMETOOLONG after chat data has already been accepted. Keep the .log
        suffix, preserve as much readable name as possible, and add a short
        digest on truncation to avoid collapsing different long names.
        """

        raw_basename = str(basename)
        file_name = clean_file(f"{raw_basename}.log")

        if len(file_name.encode("utf-8", "replace")) <= cls.MAX_LOG_BASENAME_BYTES:
            return file_name

        stem, separator, extension = file_name.rpartition(".")

        if not separator:
            stem = file_name
            extension = ""
        else:
            extension = separator + extension

        digest = md5(raw_basename.encode("utf-8", "replace")).hexdigest()[:12]
        suffix = f"-{digest}{extension}"
        max_stem_bytes = max(0, cls.MAX_LOG_BASENAME_BYTES - len(suffix.encode("utf-8")))
        stem = truncate_string_byte(stem, max_stem_bytes).rstrip(". ") or clean_file("")
        return stem + suffix

    def _get_log_file(self, folder_path, basename, should_create_file=True):

        file_path = os.path.join(folder_path, self._clean_log_file_name(basename))
        log_file = self._log_files.get(file_path)

        if log_file is not None:
            return log_file

        file_path_encoded = encode_path(file_path)

        if not should_create_file and not os.path.isfile(file_path_encoded):
            return log_file

        folder_path_encoded = encode_path(folder_path)

        if not os.path.exists(folder_path_encoded):
            os.makedirs(folder_path_encoded)

        self._close_oldest_log_file()

        log_file = self._log_files[file_path] = LogFile(
            path=file_path, handle=open(file_path_encoded, "ab+"))  # pylint: disable=consider-using-with

        # Disable file access for outsiders
        os.chmod(file_path_encoded, 0o600)

        return log_file

    def write_log_file(self, folder_path, basename, text, timestamp=None):

        folder_path = os.path.normpath(folder_path)

        try:
            log_file = self._get_log_file(folder_path, basename)
            timestamp_format = config.sections["logging"]["log_timestamp"]

            if timestamp_format:
                timestamp = time.strftime(timestamp_format, time.localtime(timestamp))
                text = f"{timestamp} {text}\n"
            else:
                text += "\n"

            log_file.handle.write(text.encode("utf-8", "replace"))
            log_file.last_active = time.monotonic()

        except Exception as error:
            # Avoid infinite recursion
            should_log_file = (folder_path != self.debug_folder_path)

            self._add(_('Couldn\'t write to log file "%(filename)s": %(error)s'), {
                "filename": os.path.join(folder_path, clean_file(f"{basename}.log")),
                "error": error
            }, should_log_file=should_log_file)

    def _estimate_log_file_write_size(self, folder_path, basename, text):
        return (
            len(str(folder_path)) + len(str(basename)) +
            len(text.encode("utf-8", "replace"))
        )

    def _schedule_log_file_queue(self):

        if self._log_file_write_timer_id is not None:
            return

        self._log_file_write_timer_id = events.schedule(delay=0, callback=self._write_queued_log_files)

        if self._log_file_write_timer_id is None:
            # Scheduler queue is saturated. Avoid leaving logs stuck forever in
            # tests/headless paths by draining a bounded batch synchronously.
            self._write_queued_log_files()

    def queue_log_file_write(self, folder_path, basename, text, timestamp=None):

        retained_size = self._estimate_log_file_write_size(folder_path, basename, text)

        if (retained_size > self.MAX_PENDING_LOG_FILE_WRITE_BYTES or
                self._pending_log_file_writes >= self.MAX_PENDING_LOG_FILE_WRITES or
                self._pending_log_file_write_bytes + retained_size > self.MAX_PENDING_LOG_FILE_WRITE_BYTES):
            if not self._log_file_write_limit_logged:
                self._log_file_write_limit_logged = True
                self._add(
                    _("Suppressing additional queued log-file writes until the backlog drains."),
                    should_log_file=False
                )
            return False

        self._log_file_write_queue.append((folder_path, basename, text, timestamp, retained_size))
        self._pending_log_file_writes += 1
        self._pending_log_file_write_bytes += retained_size
        self._schedule_log_file_queue()
        return True

    def _write_queued_log_files(self):

        self._log_file_write_timer_id = None
        num_written = 0

        while self._log_file_write_queue and num_written < self.MAX_LOG_FILE_WRITES_PER_TICK:
            folder_path, basename, text, timestamp, retained_size = self._log_file_write_queue.popleft()
            self._pending_log_file_writes -= 1
            self._pending_log_file_write_bytes -= retained_size
            self.write_log_file(folder_path=folder_path, basename=basename, text=text, timestamp=timestamp)
            num_written += 1

        if not self._log_file_write_queue:
            self._log_file_write_limit_logged = False
            return

        self._schedule_log_file_queue()

    def _flush_log_file_queue(self):

        while self._log_file_write_queue:
            self._write_queued_log_files()

    def _write_debug_log_file_from_queue(self, folder_path, basename, text):

        try:
            self.write_log_file(folder_path=folder_path, basename=basename, text=text)

        finally:
            self._pending_debug_file_writes -= 1

    def _close_log_file(self, log_file):

        try:
            log_file.handle.close()

        except OSError as error:
            self.add_debug('Failed to close log file "%(filename)s": %(error)s', {
                "filename": log_file.path,
                "error": error
            })

        del self._log_files[log_file.path]

    def _close_log_files(self):
        for log_file in self._log_files.copy().values():
            self._close_log_file(log_file)

    def _quit(self):
        self._flush_log_file_queue()
        self._close_log_files()

    def _close_inactive_log_files(self):

        current_time = time.monotonic()

        for log_file in self._log_files.copy().values():
            if (current_time - log_file.last_active) >= 10:
                self._close_log_file(log_file)

    def _normalize_folder_path(self, folder_path):
        return os.path.normpath(os.path.expandvars(folder_path))

    def update_folder_paths(self):

        self.debug_folder_path = self._normalize_folder_path(config.sections["logging"]["debuglogsdir"])
        self.transfer_folder_path = self._normalize_folder_path(config.sections["logging"]["transferslogsdir"])
        self.room_folder_path = self._normalize_folder_path(config.sections["logging"]["roomlogsdir"])
        self.private_chat_folder_path = self._normalize_folder_path(config.sections["logging"]["privatelogsdir"])

    def open_log(self, folder_path, basename):
        self._log_file_operation(folder_path, basename, self.open_log_callback)

    @staticmethod
    def get_file_tail_lines(file_handle, num_lines, max_bytes=None):
        """Return the last *num_lines* lines from an already-open binary file.

        This avoids materializing an entire log file just to discover the last
        message. It is intentionally byte-oriented, so callers that need custom
        decoding can apply their own UTF-8/legacy fallback logic.
        """

        if num_lines <= 0:
            return []

        if max_bytes is None:
            max_bytes = Logger.MAX_LOG_TAIL_BYTES

        file_handle.seek(0, os.SEEK_END)

        blocks = deque()
        read_offset = file_handle.tell()
        lines_left = num_lines + 1

        bytes_read = 0

        while lines_left > 0 and bytes_read < max_bytes:
            read_size = min(io.DEFAULT_BUFFER_SIZE, max_bytes - bytes_read)
            read_offset -= read_size

            if read_offset < 0:
                # Reached beginning of file, read remaining data
                read_size += read_offset
                read_offset = 0

            file_handle.seek(read_offset)
            block = file_handle.read(read_size)
            blocks.appendleft(block)
            bytes_read += len(block)

            if read_offset <= 0:
                # Fewer lines in file than our limit, stop here
                break

            lines_left -= block.count(b'\n')

        file_handle.seek(0, os.SEEK_END)
        return b''.join(blocks).splitlines()[-num_lines:]

    def _get_log_lines(self, log_file, num_lines):
        return self.get_file_tail_lines(log_file.handle, num_lines)

    def read_log(self, folder_path, basename, num_lines):

        lines = None
        log_file = None

        try:
            log_file = self._get_log_file(folder_path, basename, should_create_file=False)

            if log_file is not None:
                lines = self._get_log_lines(log_file, num_lines)

        except Exception as error:
            self._add(_("Cannot access log file %(path)s: %(error)s"), {
                "path": os.path.join(folder_path, clean_file(f"{basename}.log")),
                "error": error
            })

        if log_file is not None:
            self._close_log_file(log_file)

        return lines

    def delete_log(self, folder_path, basename):
        self._log_file_operation(folder_path, basename, self.delete_log_callback)

    def _log_file_operation(self, folder_path, basename, callback):

        folder_path_encoded = encode_path(folder_path)
        file_path = os.path.join(folder_path, clean_file(f"{basename}.log"))

        try:
            if not os.path.isdir(folder_path_encoded):
                os.makedirs(folder_path_encoded)

            callback(file_path)

        except Exception as error:
            self._add(_("Cannot access log file %(path)s: %(error)s"), {"path": file_path, "error": error})

    def open_log_callback(self, file_path):
        open_file_path(file_path, create_file=True)

    def delete_log_callback(self, file_path):
        os.remove(encode_path(file_path))

    def log_transfer(self, basename, msg, msg_args=None):

        if not config.sections["logging"]["transfers"]:
            return

        if msg_args:
            msg %= self._format_log_args(msg_args)

        msg = self._truncate_log_text(msg, self.MAX_LOG_MESSAGE_BYTES)
        self.queue_log_file_write(folder_path=self.transfer_folder_path, basename=basename, text=msg)

    # Log Messages #


    @classmethod
    def _truncate_log_text(cls, text, max_bytes):
        text = str(text)

        if len(text.encode("utf-8", "replace")) <= max_bytes:
            return text

        return truncate_string_byte(text, max_bytes, ellipsize=True)

    @classmethod
    def _format_log_arg(cls, value):
        if isinstance(value, str):
            return cls._truncate_log_text(value, cls.MAX_LOG_ARGUMENT_BYTES)

        if isinstance(value, (bytes, bytearray, memoryview)):
            return f"<{value.__class__.__name__} len={len(value)}>"

        return value

    @classmethod
    def _format_log_args(cls, msg_args):
        if msg_args is None:
            return None

        if isinstance(msg_args, dict):
            class BoundedLogMapping:
                def __init__(self, mapping):
                    self.mapping = mapping

                def __getitem__(self, key):
                    return cls._format_log_arg(self.mapping[key])

            return BoundedLogMapping(msg_args)

        if isinstance(msg_args, tuple):
            return tuple(cls._format_log_arg(item)
                         for item in msg_args[:cls.MAX_LOG_ARGUMENT_ITEMS])

        if isinstance(msg_args, list):
            return tuple(cls._format_log_arg(item)
                         for item in msg_args[:cls.MAX_LOG_ARGUMENT_ITEMS])

        return cls._format_log_arg(msg_args)

    def _format_log_message(self, level, msg, msg_args):

        prefix = self.PREFIXES.get(level)

        if msg_args is not None:
            msg %= self._format_log_args(msg_args)

        if prefix:
            msg = f"[{prefix}] {msg}"

        return self._truncate_log_text(msg, self.MAX_LOG_MESSAGE_BYTES)

    def _add(self, msg, msg_args=None, title=None, level=LogLevel.DEFAULT, should_log_file=True):

        msg = self._format_log_message(level, msg, msg_args)

        if title is not None:
            title = self._truncate_log_text(title, self.MAX_LOG_TITLE_BYTES)

        if should_log_file and config.sections["logging"].get("debug_file_output", False):
            if self._pending_debug_file_writes < self.MAX_PENDING_DEBUG_FILE_WRITES:
                self._pending_debug_file_writes += 1
                result = events.invoke_main_thread(
                    self._write_debug_log_file_from_queue, folder_path=self.debug_folder_path,
                    basename=self.debug_file_name, text=msg)

                if result is False:
                    self._pending_debug_file_writes -= 1

        try:
            timestamp_format = config.sections["logging"].get("log_timestamp", "%x %X")
            events.emit("log-message", timestamp_format, msg, title, level)

        except Exception as error:
            try:
                print(f"Log callback failed: {level} {msg}\n{error}", flush=True)

            except OSError:
                # stdout is gone, prevent future errors
                sys.stdout = open(os.devnull, "w", encoding="utf-8")  # pylint: disable=consider-using-with

    def add(self, msg, msg_args=None, title=None):
        self._add(msg, msg_args, title)

    def add_download(self, msg, msg_args=None):

        level = LogLevel.DOWNLOAD

        self.log_transfer(self.downloads_file_name, msg, msg_args)

        if level in self._log_levels:
            self._add(msg, msg_args, level=level)

    def add_upload(self, msg, msg_args=None):

        level = LogLevel.UPLOAD

        self.log_transfer(self.uploads_file_name, msg, msg_args)

        if level in self._log_levels:
            self._add(msg, msg_args, level=level)

    def add_search(self, msg, msg_args=None):

        level = LogLevel.SEARCH

        if level in self._log_levels:
            self._add(msg, msg_args, level=level)

    def add_chat(self, msg, msg_args=None):

        level = LogLevel.CHAT

        if level in self._log_levels:
            self._add(msg, msg_args, level=level)

    def add_conn(self, msg, msg_args=None):

        level = LogLevel.CONNECTION

        if level in self._log_levels:
            self._add(msg, msg_args, level=level)

    def add_msg_contents(self, msg, is_outgoing=False):

        level = LogLevel.MESSAGE

        if level not in self._log_levels:
            return

        # Compile message contents
        if msg.__class__ in self.EXCLUDED_MSGS:
            return

        msg_direction = "OUT" if is_outgoing else "IN"
        msg = f"{msg_direction}: {msg}"
        msg_args = None

        self._add(msg, msg_args, level=level)

    def add_transfer(self, msg, msg_args=None):

        level = LogLevel.TRANSFER

        if level in self._log_levels:
            self._add(msg, msg_args, level=level)

    def add_debug(self, msg, msg_args=None):

        level = LogLevel.MISCELLANEOUS

        if level in self._log_levels:
            self._add(msg, msg_args, level=level)


log = Logger()
