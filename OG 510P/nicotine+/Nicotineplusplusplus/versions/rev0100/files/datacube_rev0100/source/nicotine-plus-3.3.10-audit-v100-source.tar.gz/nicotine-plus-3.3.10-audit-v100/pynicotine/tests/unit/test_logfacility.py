# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007

import os
import tempfile

from collections import deque

from unittest import TestCase
from unittest.mock import patch

from pynicotine.config import config
from pynicotine.logfacility import LogFile
from pynicotine.logfacility import Logger


class LoggerTest(TestCase):

    def test_get_log_file_closes_oldest_handle_at_cap(self):
        old_max_open_log_files = Logger.MAX_OPEN_LOG_FILES
        Logger.MAX_OPEN_LOG_FILES = 2

        try:
            with tempfile.TemporaryDirectory() as temp_dir:
                logger = object.__new__(Logger)
                logger._log_files = {}

                first = logger._get_log_file(temp_dir, "one")
                second = logger._get_log_file(temp_dir, "two")
                first.last_active = 0
                second.last_active = 1

                third = logger._get_log_file(temp_dir, "three")

                self.assertEqual(2, len(logger._log_files))
                self.assertTrue(first.handle.closed)
                self.assertNotIn(first.path, logger._log_files)
                self.assertIn(second.path, logger._log_files)
                self.assertIn(third.path, logger._log_files)

                logger._close_log_files()

        finally:
            Logger.MAX_OPEN_LOG_FILES = old_max_open_log_files


    def test_log_file_name_is_truncated_with_digest(self):
        old_limit = Logger.MAX_LOG_BASENAME_BYTES
        Logger.MAX_LOG_BASENAME_BYTES = 32

        try:
            file_name = Logger._clean_log_file_name("room" + ("x" * 100))
        finally:
            Logger.MAX_LOG_BASENAME_BYTES = old_limit

        self.assertTrue(file_name.endswith(".log"))
        self.assertLessEqual(len(file_name.encode("utf-8")), 32)
        self.assertIn("-", file_name)

    def test_get_log_lines_caps_bytes_read_for_long_lines(self):
        old_max_tail_bytes = Logger.MAX_LOG_TAIL_BYTES
        Logger.MAX_LOG_TAIL_BYTES = 16

        try:
            with tempfile.NamedTemporaryFile(delete=False) as handle:
                file_path = handle.name
                handle.write(b"x" * 100)
                handle.flush()

            try:
                with open(file_path, "rb+") as handle:
                    logger = object.__new__(Logger)
                    lines = logger._get_log_lines(LogFile(file_path, handle), num_lines=1)
            finally:
                os.remove(file_path)

        finally:
            Logger.MAX_LOG_TAIL_BYTES = old_max_tail_bytes

        self.assertEqual([b"x" * 16], lines)

    def test_get_log_lines_zero_returns_no_lines(self):
        with tempfile.NamedTemporaryFile(delete=False) as handle:
            file_path = handle.name
            handle.write(b"one\ntwo\nthree\n")
            handle.flush()

        try:
            with open(file_path, "rb+") as handle:
                logger = object.__new__(Logger)
                lines = logger._get_log_lines(LogFile(file_path, handle), num_lines=0)
        finally:
            os.remove(file_path)

        self.assertEqual([], lines)


    def test_log_file_name_is_truncated_before_open(self):
        old_max_basename = Logger.MAX_LOG_BASENAME_BYTES
        Logger.MAX_LOG_BASENAME_BYTES = 64

        try:
            file_name = Logger._clean_log_file_name("room-" + ("x" * 512))
        finally:
            Logger.MAX_LOG_BASENAME_BYTES = old_max_basename

        self.assertLessEqual(len(file_name.encode("utf-8")), 64)
        self.assertTrue(file_name.endswith(".log"))
        self.assertIn("-", file_name)

    def test_log_file_name_truncation_avoids_collisions(self):
        old_max_basename = Logger.MAX_LOG_BASENAME_BYTES
        Logger.MAX_LOG_BASENAME_BYTES = 48

        try:
            first = Logger._clean_log_file_name("room-" + ("x" * 256) + "1")
            second = Logger._clean_log_file_name("room-" + ("x" * 256) + "2")
        finally:
            Logger.MAX_LOG_BASENAME_BYTES = old_max_basename

        self.assertNotEqual(first, second)
        self.assertLessEqual(len(first.encode("utf-8")), 48)
        self.assertLessEqual(len(second.encode("utf-8")), 48)

    def test_get_file_tail_lines_avoids_full_file_scan(self):
        with tempfile.NamedTemporaryFile(delete=False) as handle:
            file_path = handle.name
            handle.write((b"old\n" * 1000) + b"newest\n")
            handle.flush()

        try:
            with open(file_path, "rb+") as handle:
                lines = Logger.get_file_tail_lines(handle, num_lines=1, max_bytes=64)
        finally:
            os.remove(file_path)

        self.assertEqual([b"newest"], lines)

    def test_debug_file_output_caps_pending_main_thread_writes(self):
        old_max_pending_writes = Logger.MAX_PENDING_DEBUG_FILE_WRITES
        old_debug_file_output = config.sections["logging"].get("debug_file_output", False)
        Logger.MAX_PENDING_DEBUG_FILE_WRITES = 2
        config.sections["logging"]["debug_file_output"] = True

        try:
            logger = object.__new__(Logger)
            logger.debug_folder_path = tempfile.gettempdir()
            logger.debug_file_name = "debug"
            logger._pending_debug_file_writes = 0

            queued_callbacks = []

            class FakeEvents:

                @staticmethod
                def invoke_main_thread(callback, **kwargs):
                    queued_callbacks.append((callback, kwargs))

                @staticmethod
                def emit(*_args, **_kwargs):
                    pass

            with patch("pynicotine.logfacility.events", FakeEvents):
                logger._add("one")
                logger._add("two")
                logger._add("three")

                self.assertEqual(2, len(queued_callbacks))
                self.assertEqual(2, logger._pending_debug_file_writes)

                callback, kwargs = queued_callbacks.pop(0)

                with patch.object(Logger, "write_log_file"):
                    callback(**kwargs)

                logger._add("four")

                self.assertEqual(2, len(queued_callbacks))
                self.assertEqual(2, logger._pending_debug_file_writes)

        finally:
            config.sections["logging"]["debug_file_output"] = old_debug_file_output
            Logger.MAX_PENDING_DEBUG_FILE_WRITES = old_max_pending_writes


    def test_log_message_and_title_are_truncated_before_emit(self):
        logger = object.__new__(Logger)
        old_max_message = Logger.MAX_LOG_MESSAGE_BYTES
        old_max_title = Logger.MAX_LOG_TITLE_BYTES
        Logger.MAX_LOG_MESSAGE_BYTES = 32
        Logger.MAX_LOG_TITLE_BYTES = 16

        emitted = []

        class FakeEvents:
            @staticmethod
            def emit(*args):
                emitted.append(args)

        old_debug_file_output = config.sections["logging"].get("debug_file_output", False)
        config.sections["logging"]["debug_file_output"] = False

        try:
            with patch("pynicotine.logfacility.events", FakeEvents):
                logger._add("x" * 128, title="t" * 128)

            _event_name, _timestamp_format, message, title, _level = emitted[0]
            self.assertLessEqual(len(message.encode("utf-8")), Logger.MAX_LOG_MESSAGE_BYTES)
            self.assertLessEqual(len(title.encode("utf-8")), Logger.MAX_LOG_TITLE_BYTES)
            self.assertIn("…", message)
            self.assertIn("…", title)

        finally:
            config.sections["logging"]["debug_file_output"] = old_debug_file_output
            Logger.MAX_LOG_MESSAGE_BYTES = old_max_message
            Logger.MAX_LOG_TITLE_BYTES = old_max_title

    def test_log_arguments_are_bounded_before_formatting(self):
        logger = object.__new__(Logger)
        old_max_arg = Logger.MAX_LOG_ARGUMENT_BYTES
        old_max_message = Logger.MAX_LOG_MESSAGE_BYTES
        Logger.MAX_LOG_ARGUMENT_BYTES = 16
        Logger.MAX_LOG_MESSAGE_BYTES = 64

        try:
            message = logger._format_log_message(None, "value=%(value)s", {"value": "x" * 128})
            self.assertLessEqual(len(message.encode("utf-8")), Logger.MAX_LOG_MESSAGE_BYTES)
            self.assertIn("…", message)

            message = logger._format_log_message(None, "blob=%s", (b"x" * 128,))
            self.assertEqual("blob=<bytes len=128>", message)

        finally:
            Logger.MAX_LOG_ARGUMENT_BYTES = old_max_arg
            Logger.MAX_LOG_MESSAGE_BYTES = old_max_message

    def test_chat_and_transfer_log_writes_are_queued(self):
        old_transfers = config.sections["logging"].get("transfers", False)
        config.sections["logging"]["transfers"] = True

        try:
            logger = object.__new__(Logger)
            logger.transfer_folder_path = tempfile.gettempdir()

            with patch.object(Logger, "queue_log_file_write", return_value=True) as queue_write, \
                    patch.object(Logger, "write_log_file") as direct_write:
                logger.log_transfer("downloads", "Downloaded %s", ("file",))

            direct_write.assert_not_called()
            queue_write.assert_called_once_with(
                folder_path=tempfile.gettempdir(), basename="downloads", text="Downloaded file")

        finally:
            config.sections["logging"]["transfers"] = old_transfers

    def test_log_file_write_queue_releases_budget_in_batches(self):
        logger = object.__new__(Logger)
        logger._log_file_write_queue = deque()
        logger._pending_log_file_writes = 0
        logger._pending_log_file_write_bytes = 0
        logger._log_file_write_timer_id = None
        logger._log_file_write_limit_logged = False

        old_batch_size = Logger.MAX_LOG_FILE_WRITES_PER_TICK
        Logger.MAX_LOG_FILE_WRITES_PER_TICK = 1

        class FakeEvents:

            num_scheduled = 0

            @classmethod
            def schedule(cls, **_kwargs):
                cls.num_scheduled += 1
                return cls.num_scheduled

        try:
            with patch("pynicotine.logfacility.events", FakeEvents), \
                    patch.object(Logger, "write_log_file") as direct_write:
                self.assertTrue(logger.queue_log_file_write("/tmp", "a", "one"))
                self.assertTrue(logger.queue_log_file_write("/tmp", "b", "two"))
                self.assertEqual(2, logger._pending_log_file_writes)

                logger._write_queued_log_files()

                self.assertEqual(1, direct_write.call_count)
                self.assertEqual(1, logger._pending_log_file_writes)
                self.assertGreater(logger._pending_log_file_write_bytes, 0)
                self.assertIsNotNone(logger._log_file_write_timer_id)

                logger._write_queued_log_files()

                self.assertEqual(2, direct_write.call_count)
                self.assertEqual(0, logger._pending_log_file_writes)
                self.assertEqual(0, logger._pending_log_file_write_bytes)

        finally:
            Logger.MAX_LOG_FILE_WRITES_PER_TICK = old_batch_size

    def test_log_file_write_queue_honors_batch_size(self):
        logger = object.__new__(Logger)
        logger._log_file_write_queue = deque([
            ("/tmp", "a", "one", None, 1),
            ("/tmp", "b", "two", None, 1),
            ("/tmp", "c", "three", None, 1),
        ])
        logger._pending_log_file_writes = 3
        logger._pending_log_file_write_bytes = 3
        logger._log_file_write_timer_id = None
        logger._log_file_write_limit_logged = False

        old_batch_size = Logger.MAX_LOG_FILE_WRITES_PER_TICK
        Logger.MAX_LOG_FILE_WRITES_PER_TICK = 2

        class FakeEvents:
            @staticmethod
            def schedule(**_kwargs):
                return 1

        try:
            with patch("pynicotine.logfacility.events", FakeEvents), \
                    patch.object(Logger, "write_log_file") as direct_write:
                logger._write_queued_log_files()

            self.assertEqual(2, direct_write.call_count)
            self.assertEqual(1, logger._pending_log_file_writes)
            self.assertEqual(1, logger._pending_log_file_write_bytes)
            self.assertIsNotNone(logger._log_file_write_timer_id)

        finally:
            Logger.MAX_LOG_FILE_WRITES_PER_TICK = old_batch_size
