# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007

import os
import struct
import tempfile

from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import patch

from pynicotine.config import config
from pynicotine.core import core
from pynicotine.events import events
from pynicotine.slskmessages import USER_INFO_USERS_ALLOWED
from pynicotine.slskmessages import USER_INTERESTS_USERS_ALLOWED
from pynicotine.slskmessages import UserInfoRequest
from pynicotine.slskmessages import UserInfoResponse
from pynicotine.slskmessages import UserInterests
from pynicotine.userinfo import MAX_PROFILE_PICTURE_WIDTH
from pynicotine.userinfo import get_profile_picture_dimensions
from pynicotine.userinfo import UserInfo
from pynicotine.userinfo import validate_profile_picture


class UserInfoTest(TestCase):

    # pylint: disable=protected-access

    def test_show_user_grants_only_after_network_queue_accepts(self):
        userinfo = UserInfo()
        old_users = core.users

        try:
            core.users = SimpleNamespace(login_username="me", watch_user=lambda *_args, **_kwargs: True)

            with patch.object(type(core), "send_message_to_server", return_value=False), \
                    patch.object(type(core), "send_message_to_peer", return_value=False):
                userinfo.show_user("peer", refresh=True)

            self.assertFalse(USER_INTERESTS_USERS_ALLOWED.is_allowed("peer"))
            self.assertFalse(USER_INFO_USERS_ALLOWED.is_allowed("peer"))

            with patch.object(type(core), "send_message_to_server", return_value=True), \
                    patch.object(type(core), "send_message_to_peer", return_value=True):
                userinfo.show_user("other", refresh=True)

            self.assertTrue(USER_INTERESTS_USERS_ALLOWED.is_allowed("other"))
            self.assertTrue(USER_INFO_USERS_ALLOWED.is_allowed("other"))

        finally:
            core.users = old_users

    def test_user_info_response_delivery_failure_retries_request(self):
        userinfo = UserInfo()
        userinfo.users.add("peer")
        scheduled_callbacks = []

        def schedule(_events, delay, callback, callback_args=None, repeat=False):
            scheduled_callbacks.append((delay, callback, callback_args or ()))
            return len(scheduled_callbacks)

        USER_INFO_USERS_ALLOWED.clear()

        try:
            with patch.object(events.__class__, "schedule", schedule), \
                    patch.object(type(core), "send_message_to_peer", return_value=True) as send_message:
                userinfo._peer_response_delivery_failed(
                    UserInfoResponse, "peer", ("user-info-response",))
                self.assertEqual(1, len(scheduled_callbacks))
                _delay, callback, callback_args = scheduled_callbacks.pop(0)
                callback(*callback_args)

            self.assertEqual("peer", send_message.call_args.args[0])
            self.assertIsInstance(send_message.call_args.args[1], UserInfoRequest)
            self.assertTrue(USER_INFO_USERS_ALLOWED.is_allowed("peer"))

        finally:
            USER_INFO_USERS_ALLOWED.clear()

    @staticmethod
    def _png_header(width, height):
        return (
            b"\x89PNG\r\n\x1a\n"
            + struct.pack(">I", 13)
            + b"IHDR"
            + struct.pack(">II", width, height)
            + b"\x08\x02\x00\x00\x00\x00\x00\x00\x00"
        )

    @staticmethod
    def _jpeg_header(width, height):
        return (
            b"\xff\xd8"
            b"\xff\xe0\x00\x04\x00\x00"
            b"\xff\xc0\x00\x0b\x08" + struct.pack(">HH", height, width) + b"\x01\x01\x00"
        )

    def tearDown(self):
        USER_INFO_USERS_ALLOWED.clear()
        USER_INTERESTS_USERS_ALLOWED.clear()

    def test_remove_user_tolerates_missing_users_component_on_quit(self):
        userinfo = UserInfo()
        userinfo.users.add("peer")
        old_users = core.users
        core.users = None

        try:
            userinfo.remove_user("peer")
        finally:
            core.users = old_users

        self.assertNotIn("peer", userinfo.users)

    def test_user_info_peer_request_unsent_retries_and_restores_grant(self):
        userinfo = UserInfo()
        userinfo.users.add("peer")
        scheduled_callbacks = []

        def schedule(_events, delay, callback, callback_args=None, repeat=False):
            scheduled_callbacks.append((delay, callback, callback_args or ()))
            return len(scheduled_callbacks)

        with patch.object(events.__class__, "schedule", schedule), \
                patch.object(type(core), "send_message_to_peer", return_value=True):
            userinfo._peer_request_unsent(UserInfoRequest, "peer", UserInfoRequest())
            self.assertEqual(1, len(scheduled_callbacks))
            _delay, callback, callback_args = scheduled_callbacks.pop(0)
            callback(*callback_args)

        self.assertTrue(USER_INFO_USERS_ALLOWED.is_allowed("peer"))
        self.assertFalse(userinfo._user_request_retry_queue)

    def test_user_interests_unsent_retries_and_restores_grant(self):
        userinfo = UserInfo()
        userinfo.users.add("peer")
        scheduled_callbacks = []

        def schedule(_events, delay, callback, callback_args=None, repeat=False):
            scheduled_callbacks.append((delay, callback, callback_args or ()))
            return len(scheduled_callbacks)

        with patch.object(events.__class__, "schedule", schedule), \
                patch.object(type(core), "send_message_to_server", return_value=True):
            userinfo._server_message_unsent(UserInterests("peer"))
            self.assertEqual(1, len(scheduled_callbacks))
            _delay, callback, callback_args = scheduled_callbacks.pop(0)
            callback(*callback_args)

        self.assertTrue(USER_INTERESTS_USERS_ALLOWED.is_allowed("peer"))
        self.assertFalse(userinfo._user_request_retry_queue)

    def test_user_interests_delivery_failure_retries_and_restores_grant(self):
        userinfo = UserInfo()
        userinfo.users.add("peer")
        scheduled_callbacks = []

        def schedule(_events, delay, callback, callback_args=None, repeat=False):
            scheduled_callbacks.append((delay, callback, callback_args or ()))
            return len(scheduled_callbacks)

        with patch.object(events.__class__, "schedule", schedule), \
                patch.object(type(core), "send_message_to_server", return_value=True):
            userinfo._server_response_delivery_failed(UserInterests, ("user-interests", "peer"))
            self.assertEqual(1, len(scheduled_callbacks))
            _delay, callback, callback_args = scheduled_callbacks.pop(0)
            callback(*callback_args)

        self.assertTrue(USER_INTERESTS_USERS_ALLOWED.is_allowed("peer"))
        self.assertFalse(userinfo._user_request_retry_queue)

    def test_user_interests_handler_discards_leftover_grant_without_rejecting(self):
        USER_INTERESTS_USERS_ALLOWED.add("peer")
        msg = SimpleNamespace(user="peer")

        UserInfo._user_interests(msg)

        self.assertEqual("peer", msg.user)
        self.assertFalse(USER_INTERESTS_USERS_ALLOWED.is_allowed("peer"))

    def test_user_interests_accepts_requested_response_once(self):
        USER_INTERESTS_USERS_ALLOWED.add("peer")
        msg = SimpleNamespace(user="peer")

        UserInfo._user_interests(msg)

        self.assertEqual("peer", msg.user)
        self.assertFalse(USER_INTERESTS_USERS_ALLOWED.is_allowed("peer"))

    def test_profile_picture_dimension_parser_reads_common_headers(self):
        self.assertEqual((640, 480), get_profile_picture_dimensions(self._png_header(640, 480)))
        self.assertEqual((320, 240), get_profile_picture_dimensions(b"GIF89a" + struct.pack("<HH", 320, 240)))
        self.assertEqual((1024, 768), get_profile_picture_dimensions(self._jpeg_header(1024, 768)))

    def test_profile_picture_validation_rejects_large_dimensions(self):
        validate_profile_picture(self._png_header(100, 100))

        with self.assertRaises(ValueError):
            validate_profile_picture(self._png_header(MAX_PROFILE_PICTURE_WIDTH + 1, 1))

        with self.assertRaises(ValueError):
            validate_profile_picture(self._png_header(8000, 6000))

    def test_info_request_tracking_prunes_stale_entries_when_full(self):
        userinfo = UserInfo()
        old_max = UserInfo.MAX_INFO_REQUEST_TIMES
        old_retention = UserInfo.INFO_REQUEST_TIMES_RETENTION
        UserInfo.MAX_INFO_REQUEST_TIMES = 2
        UserInfo.INFO_REQUEST_TIMES_RETENTION = 60

        try:
            userinfo.requested_info_times = {"old1": 0, "old2": 1}

            with patch("pynicotine.userinfo.time.monotonic", return_value=120):
                self.assertFalse(userinfo._is_user_info_request_limited("newuser"))

        finally:
            UserInfo.MAX_INFO_REQUEST_TIMES = old_max
            UserInfo.INFO_REQUEST_TIMES_RETENTION = old_retention

        self.assertEqual({"newuser": 120}, userinfo.requested_info_times)

    def test_info_request_tracking_limits_new_recent_users_when_full(self):
        userinfo = UserInfo()
        old_max = UserInfo.MAX_INFO_REQUEST_TIMES
        old_retention = UserInfo.INFO_REQUEST_TIMES_RETENTION
        UserInfo.MAX_INFO_REQUEST_TIMES = 2
        UserInfo.INFO_REQUEST_TIMES_RETENTION = 60

        try:
            userinfo.requested_info_times = {"user1": 90, "user2": 95}

            with patch("pynicotine.userinfo.time.monotonic", return_value=100):
                self.assertTrue(userinfo._is_user_info_request_limited("newuser"))

        finally:
            UserInfo.MAX_INFO_REQUEST_TIMES = old_max
            UserInfo.INFO_REQUEST_TIMES_RETENTION = old_retention

        self.assertEqual({"user1": 90, "user2": 95}, userinfo.requested_info_times)

    def test_info_request_address_budget_blocks_username_rotation(self):
        """A peer should not bypass profile request limits by rotating claimed usernames."""

        userinfo = UserInfo()
        old_limit = UserInfo.MAX_INFO_REQUESTS_PER_ADDRESS
        UserInfo.MAX_INFO_REQUESTS_PER_ADDRESS = 2

        try:
            with patch("pynicotine.userinfo.time.monotonic", return_value=1234.0):
                self.assertFalse(userinfo._is_user_info_request_limited("user1", "203.0.113.5"))
                self.assertFalse(userinfo._is_user_info_request_limited("user2", "203.0.113.5"))
                self.assertTrue(userinfo._is_user_info_request_limited("user3", "203.0.113.5"))
                self.assertFalse(userinfo._is_user_info_request_limited("user4", "203.0.113.6"))

        finally:
            UserInfo.MAX_INFO_REQUESTS_PER_ADDRESS = old_limit

    def test_info_request_address_budget_prunes_old_entries(self):
        """Old address-budget entries are pruned before blocking new requesters."""

        userinfo = UserInfo()
        old_limit = UserInfo.MAX_INFO_REQUESTS_PER_ADDRESS
        UserInfo.MAX_INFO_REQUESTS_PER_ADDRESS = 1

        try:
            userinfo.requested_info_address_times["203.0.113.5"].append(1000.0)
        except KeyError:
            from collections import deque
            userinfo.requested_info_address_times["203.0.113.5"] = deque([1000.0])

        try:
            with patch("pynicotine.userinfo.time.monotonic", return_value=1234.0):
                self.assertFalse(userinfo._is_user_info_request_limited("newuser", "203.0.113.5"))

        finally:
            UserInfo.MAX_INFO_REQUESTS_PER_ADDRESS = old_limit

        self.assertEqual([1234.0], list(userinfo.requested_info_address_times["203.0.113.5"]))

    def test_user_info_request_ledger_rolls_back_when_response_queue_rejects(self):
        """Do not rate-limit a peer for a profile response we failed to queue."""

        userinfo = UserInfo()
        msg = SimpleNamespace(username="remoteuser", addr=("203.0.113.5", 1234))

        with patch("pynicotine.userinfo.time.monotonic", return_value=1234.0), \
                patch.object(UserInfo, "_get_user_info_response", return_value=SimpleNamespace()), \
                patch.object(type(core), "send_message_to_peer", return_value=False):
            userinfo._user_info_request(msg)

        self.assertEqual({}, userinfo.requested_info_times)
        self.assertEqual({}, userinfo.requested_info_address_times)

    def test_user_info_request_ledger_rolls_back_when_response_output_fails_later(self):
        """Do not rate-limit a peer when an accepted profile response dies below peer output."""

        userinfo = UserInfo()

        with patch("pynicotine.userinfo.time.monotonic", return_value=1234.0):
            marker = userinfo._record_user_info_request("remoteuser", "203.0.113.5")

        self.assertIn("remoteuser", userinfo.requested_info_times)

        userinfo._peer_response_unsent(UserInfoResponse, "remoteuser", ("user-info-request", marker))

        self.assertEqual({}, userinfo.requested_info_times)
        self.assertEqual({}, userinfo.requested_info_address_times)

    def test_profile_picture_cache_avoids_repeated_reads_until_file_changes(self):
        userinfo_config = config.sections.setdefault("userinfo", {})
        old_picture_path = userinfo_config.get("pic")

        try:
            with tempfile.TemporaryDirectory() as temp_dir:
                picture_path = os.path.join(temp_dir, "profile.png")

                with open(picture_path, "wb") as file_handle:
                    file_handle.write(b"picture")

                userinfo_config["pic"] = picture_path
                userinfo = UserInfo()

                with patch.object(UserInfo, "_read_profile_picture", wraps=UserInfo._read_profile_picture) as read_mock:
                    self.assertEqual(b"picture", userinfo._get_cached_profile_picture())
                    self.assertEqual(b"picture", userinfo._get_cached_profile_picture())
                    self.assertEqual(1, read_mock.call_count)

                    with open(picture_path, "ab") as file_handle:
                        file_handle.write(b"2")

                    self.assertEqual(b"picture2", userinfo._get_cached_profile_picture())
                    self.assertEqual(2, read_mock.call_count)

        finally:
            if old_picture_path is None:
                userinfo_config.pop("pic", None)
            else:
                userinfo_config["pic"] = old_picture_path

    def test_profile_picture_cache_clears_when_no_picture_configured(self):
        userinfo_config = config.sections.setdefault("userinfo", {})
        old_picture_path = userinfo_config.get("pic")

        try:
            userinfo_config["pic"] = ""
            userinfo = UserInfo()
            userinfo._profile_picture_cache_key = ("old", 1, 2, 3, 4)
            userinfo._profile_picture_cache_data = b"old"

            self.assertIsNone(userinfo._get_cached_profile_picture())
            self.assertIsNone(userinfo._profile_picture_cache_key)
            self.assertIsNone(userinfo._profile_picture_cache_data)

        finally:
            if old_picture_path is None:
                userinfo_config.pop("pic", None)
            else:
                userinfo_config["pic"] = old_picture_path

    def test_read_profile_picture_accepts_regular_file(self):
        userinfo_config = config.sections.setdefault("userinfo", {})
        old_picture_path = userinfo_config.get("pic")

        try:
            with tempfile.TemporaryDirectory() as temp_dir:
                picture_path = os.path.join(temp_dir, "profile.png")

                with open(picture_path, "wb") as file_handle:
                    file_handle.write(b"picture")

                userinfo_config["pic"] = picture_path

                self.assertEqual(b"picture", UserInfo._read_profile_picture())

        finally:
            if old_picture_path is None:
                userinfo_config.pop("pic", None)
            else:
                userinfo_config["pic"] = old_picture_path

    def test_read_profile_picture_rejects_special_file(self):
        if not hasattr(os, "mkfifo"):
            self.skipTest("mkfifo is unavailable on this platform")

        userinfo_config = config.sections.setdefault("userinfo", {})
        old_picture_path = userinfo_config.get("pic")

        try:
            with tempfile.TemporaryDirectory() as temp_dir:
                picture_path = os.path.join(temp_dir, "profile-pipe")
                os.mkfifo(picture_path)
                userinfo_config["pic"] = picture_path

                with self.assertRaises(OSError):
                    UserInfo._read_profile_picture()

        finally:
            if old_picture_path is None:
                userinfo_config.pop("pic", None)
            else:
                userinfo_config["pic"] = old_picture_path
