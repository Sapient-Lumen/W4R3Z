# COPYRIGHT (C) 2020-2024 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import ipaddress
import re
import socket
import struct
import sys
import time

from threading import Lock
from threading import Thread
from urllib.parse import urljoin
from urllib.parse import urlsplit

import pynicotine

from pynicotine.config import config
from pynicotine.events import events
from pynicotine.logfacility import log
from pynicotine.utils import execute_command


class PortmapError(Exception):
    pass


class BaseImplementation:
    __slots__ = ("port", "local_ip_address")

    def __init__(self):
        self.port = None
        self.local_ip_address = None

    def set_port(self, port, local_ip_address):
        self.port = port
        self.local_ip_address = local_ip_address


class NATPMP(BaseImplementation):
    """Implementation of the NAT-PMP protocol.

    https://www.rfc-editor.org/rfc/rfc6886.
    """

    __slots__ = ("_gateway_address",)

    NAME = "NAT-PMP"
    REQUEST_PORT = 5351
    REQUEST_ATTEMPTS = 2  # spec says 9, but 2 should be enough
    REQUEST_INIT_TIMEOUT = 0.250  # seconds
    MAX_RESPONSES_PER_ATTEMPT = 16
    SUCCESS_RESULT = 0

    class PortmapResponse:
        __slots__ = ("message", "result", "private_port", "public_port", "lease_duration")

        RESPONSE_SIZE = struct.calcsize('!BBHIHHI')
        RESPONSE_VERSION = 0
        TCP_RESPONSE_OP_CODE = 128 + 2

        def __init__(self, message):

            if len(message) != self.RESPONSE_SIZE:
                raise PortmapError(
                    f"NAT-PMP response length is {len(message)} bytes, expected {self.RESPONSE_SIZE}"
                )

            self.message = message
            (
                version,
                op_code,
                self.result,
                _sec_since_epoch,
                self.private_port,
                self.public_port,
                self.lease_duration
            ) = struct.unpack('!BBHIHHI', message)

            if version != self.RESPONSE_VERSION:
                raise PortmapError(f"NAT-PMP response version {version} is invalid")

            if op_code != self.TCP_RESPONSE_OP_CODE:
                raise PortmapError(f"NAT-PMP response op code {op_code} is invalid")

        def __bytes__(self):
            return self.message

    class PortmapRequest:
        __slots__ = ("_public_port", "_private_port", "_lease_duration")

        RESERVED_VALUE = 0
        TCP_OP_CODE = 2
        VERSION = 0

        def __init__(self, public_port, private_port, lease_duration):

            self._public_port = public_port
            self._private_port = private_port
            self._lease_duration = lease_duration

        def sendto(self, sock, addr, num_attempt):

            msg = bytes(self)
            ip_address, port = addr
            sock.sendto(msg, addr)

            log.add_debug(
                "NAT-PMP: Portmap request attempt %s of %s to gateway %s, port %s: %s",
                (num_attempt, NATPMP.REQUEST_ATTEMPTS, ip_address, port, msg)
            )

        def __bytes__(self):

            return struct.pack(
                '!BBHHHI',
                self.VERSION,
                self.TCP_OP_CODE,
                self.RESERVED_VALUE,
                self._private_port,
                self._public_port,
                self._lease_duration
            )

    def __init__(self):
        super().__init__()
        self._gateway_address = None

    @staticmethod
    def _get_gateway_address():

        if sys.platform == "linux":
            gateway_address = None

            with open("/proc/net/route", encoding="utf-8") as file_handle:
                next(file_handle)  # Skip header

                for line in file_handle:
                    routes = line.strip().split()
                    destination_address = socket.inet_ntoa(struct.pack("<L", int(routes[1], 16)))

                    if destination_address != "0.0.0.0":
                        continue

                    gateway_address = socket.inet_ntoa(struct.pack("<L", int(routes[2], 16)))
                    break

            return gateway_address

        if sys.platform == "win32":
            gateway_pattern = re.compile(b".*?0.0.0.0 +0.0.0.0 +(.*?) +?[^\n]*\n")
        else:
            gateway_pattern = re.compile(b"(?:default|0\\.0\\.0\\.0|::/0)\\s+([\\w\\.:]+)\\s+.*UG")

        output = execute_command("netstat -rn", returnoutput=True, hidden=True)
        return gateway_pattern.search(output).group(1)


    @staticmethod
    def _normalize_gateway_address(gateway_address):

        if isinstance(gateway_address, bytes):
            gateway_address = gateway_address.decode("ascii", "strict")

        try:
            gateway_ip = ipaddress.ip_address(gateway_address)

        except (TypeError, ValueError, UnicodeDecodeError) as error:
            raise PortmapError(f"Invalid NAT-PMP gateway address {gateway_address!r}") from error

        if (gateway_ip.version != 4 or gateway_ip.is_unspecified or gateway_ip.is_loopback
                or gateway_ip.is_multicast or gateway_ip.is_link_local
                or gateway_ip == ipaddress.IPv4Address("255.255.255.255")):
            raise PortmapError(f"Invalid NAT-PMP gateway address {gateway_address!r}")

        return str(gateway_ip)

    @staticmethod
    def _is_expected_response_source(source_address, gateway_address):

        if not isinstance(source_address, tuple) or len(source_address) < 2:
            return False

        if source_address[1] != NATPMP.REQUEST_PORT:
            return False

        try:
            return ipaddress.ip_address(source_address[0]) == ipaddress.ip_address(gateway_address)

        except ValueError:
            return False

    @staticmethod
    def _check_portmap_response(response, public_port, private_port, lease_duration):
        """Validate that a NAT-PMP response corresponds to our outstanding request."""

        if response.private_port != private_port:
            raise PortmapError(
                f"NAT-PMP response private port {response.private_port} does not match request {private_port}"
            )

        if response.public_port != public_port:
            raise PortmapError(
                f"NAT-PMP response public port {response.public_port} does not match request {public_port}"
            )

        if response.lease_duration > lease_duration:
            raise PortmapError(
                f"NAT-PMP response lease duration {response.lease_duration} exceeds request {lease_duration}"
            )

    def _recv_portmap_response(self, sock, gateway_address, public_port, private_port, lease_duration):

        for _response_num in range(self.MAX_RESPONSES_PER_ATTEMPT):
            try:
                message, source_address = sock.recvfrom(self.PortmapResponse.RESPONSE_SIZE + 1)

            except socket.timeout:
                return None

            if not self._is_expected_response_source(source_address, gateway_address):
                log.add_debug("NAT-PMP: Ignoring response from unexpected address %s", source_address)
                continue

            response = self.PortmapResponse(message=message)
            self._check_portmap_response(response, public_port, private_port, lease_duration)
            return response

        raise PortmapError(
            f"NAT-PMP: maximum unexpected response count reached ({self.MAX_RESPONSES_PER_ATTEMPT})"
        )

    def _request_port_mapping(self, public_port, private_port, lease_duration):

        gateway_address = self._normalize_gateway_address(self._gateway_address)

        with socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM, proto=socket.IPPROTO_UDP) as sock:
            log.add_debug("NAT-PMP: Binding socket to local IP address %s", self.local_ip_address)

            sock.bind((self.local_ip_address, 0))
            request = self.PortmapRequest(public_port, private_port, lease_duration)
            timeout = self.REQUEST_INIT_TIMEOUT

            for i in range(1, self.REQUEST_ATTEMPTS + 1):
                sock.settimeout(timeout)
                request.sendto(sock, (gateway_address, self.REQUEST_PORT), i)

                try:
                    response = self._recv_portmap_response(sock, gateway_address, public_port, private_port, lease_duration)

                    if response is not None:
                        return response.result

                    timeout *= 2

                except PortmapError:
                    raise

                except socket.timeout:
                    timeout *= 2

        log.add_debug("NAT-PMP: Giving up, all %s portmap requests timed out", self.REQUEST_ATTEMPTS)

        return None

    def add_port_mapping(self, lease_duration):

        self._gateway_address = self._get_gateway_address()
        result = self._request_port_mapping(
            public_port=self.port,
            private_port=self.port,
            lease_duration=lease_duration
        )

        if result != self.SUCCESS_RESULT:
            raise PortmapError(f"NAT-PMP error code {result}")

    def remove_port_mapping(self):

        result = self._request_port_mapping(
            public_port=0,
            private_port=self.port,
            lease_duration=0
        )
        self._gateway_address = None

        if result != self.SUCCESS_RESULT:
            raise PortmapError(f"NAT-PMP error code {result}")


class UPnP(BaseImplementation):
    """Implementation of the UPnP protocol."""

    __slots__ = ("_service",)

    NAME = "UPnP"
    USER_AGENT = (
        f"Python/{sys.version.split()[0]} "
        "UPnP/2.0 "
        f"{pynicotine.__application_name__}/{pynicotine.__version__}"
    )
    MULTICAST_HOST = "239.255.255.250"
    MULTICAST_PORT = 1900
    MULTICAST_TTL = 2         # Should default to 2 according to UPnP specification
    MX_RESPONSE_DELAY = 1     # At least 1 second is sufficient according to UPnP specification
    HTTP_REQUEST_TIMEOUT = 5
    MAX_HTTP_RESPONSE_SIZE = 1048576
    MAX_DISCOVERY_LOCATIONS = 32
    MAX_DEVICE_DESCRIPTION_REQUESTS = 8
    MAX_LOCATION_URL_BYTES = 2048
    MAX_LOCATION_HOSTNAME_BYTES = 253
    MAX_CONTROL_URL_BYTES = 2048
    MAX_SSDP_RESPONSE_BYTES = 32768
    MAX_DISCOVERY_RESPONSES = 256
    MAX_XML_ELEMENTS = 8192
    MAX_XML_TEXT_BYTES = 65536
    LOCAL_LOCATION_HOSTNAME_SUFFIXES = (".local", ".lan", ".home", ".localdomain")

    @staticmethod
    def _read_http_response(response, max_size=None):
        """Read a UPnP HTTP response with a hard size limit."""

        if max_size is None:
            max_size = UPnP.MAX_HTTP_RESPONSE_SIZE

        response_body = response.read(max_size + 1)

        if len(response_body) > max_size:
            raise PortmapError(f"UPnP HTTP response exceeds maximum size of {max_size} bytes")

        return response_body

    @staticmethod
    def _read_http_error_body(error):
        if 300 <= getattr(error, "code", 0) < 400:
            raise PortmapError(f"UPnP HTTP redirects are not allowed: {error.code}") from error

        return UPnP._read_http_response(error)

    @staticmethod
    def _open_http_response(request, timeout):
        """Open a UPnP URL without following redirects away from the validated target."""

        from urllib.request import build_opener
        from urllib.request import HTTPRedirectHandler

        class NoRedirectHandler(HTTPRedirectHandler):
            def redirect_request(self, *_args, **_kwargs):
                return None

        return build_opener(NoRedirectHandler).open(request, timeout=timeout)


    @staticmethod
    def _is_dangerous_xml(response_body):
        upper_body = response_body.upper()
        return b"<!DOCTYPE" in upper_body or b"<!ENTITY" in upper_body

    @staticmethod
    def _check_xml_element_budget(xml):
        num_elements = 0

        for element in xml.iter():
            num_elements += 1

            if num_elements > UPnP.MAX_XML_ELEMENTS:
                raise PortmapError(f"UPnP XML response exceeds maximum element count of {UPnP.MAX_XML_ELEMENTS}")

            for text in (element.text, element.tail):
                if text and len(text.encode("utf-8", "replace")) > UPnP.MAX_XML_TEXT_BYTES:
                    raise PortmapError(
                        f"UPnP XML text field exceeds maximum size of {UPnP.MAX_XML_TEXT_BYTES} bytes")

            for attr_value in element.attrib.values():
                if len(attr_value.encode("utf-8", "replace")) > UPnP.MAX_XML_TEXT_BYTES:
                    raise PortmapError(
                        f"UPnP XML attribute exceeds maximum size of {UPnP.MAX_XML_TEXT_BYTES} bytes")

    @staticmethod
    def _parse_xml_response(response_body, context="UPnP XML response"):
        if UPnP._is_dangerous_xml(response_body):
            raise PortmapError(f"{context} contains a forbidden document type or entity declaration")

        from xml.etree import ElementTree

        try:
            xml = ElementTree.fromstring(response_body.decode("utf-8", "replace"))

        except Exception as error:
            raise PortmapError(f"Invalid {context}: {error}") from error

        UPnP._check_xml_element_budget(xml)
        return xml

    @staticmethod
    def _is_local_location_hostname(hostname):
        """Return whether a hostname-shaped SSDP LOCATION target is plausibly local.

        IP literals can be compared against the responding address. Hostnames
        cannot be proven local without making another outbound request, so keep
        them to common local discovery shapes instead of accepting arbitrary
        fully-qualified domains from a UDP multicast response.
        """

        hostname = hostname.rstrip(".").lower()

        if not hostname:
            return False

        try:
            encoded_hostname = hostname.encode("idna")
        except UnicodeError:
            return False

        if len(encoded_hostname) > UPnP.MAX_LOCATION_HOSTNAME_BYTES:
            return False

        labels = hostname.split(".")

        for label in labels:
            if not label or len(label) > 63:
                return False

            if label.startswith("-") or label.endswith("-"):
                return False

            if not all(char.isalnum() or char == "-" for char in label):
                return False

        if len(labels) == 1:
            return True

        return any(hostname.endswith(suffix) for suffix in UPnP.LOCAL_LOCATION_HOSTNAME_SUFFIXES)


    @staticmethod
    def _is_valid_ssdp_source_address(source_ip_address, private_ip_address):
        """Validate the packet source address before trusting SSDP headers."""

        try:
            source_ip = ipaddress.ip_address(source_ip_address)
            private_ip = ipaddress.ip_address(private_ip_address)

        except ValueError:
            return False

        if source_ip.version != private_ip.version:
            return False

        if source_ip.is_loopback or source_ip.is_unspecified or source_ip.is_multicast:
            return False

        if not private_ip.is_global and source_ip.is_global:
            return False

        return True

    @staticmethod
    def _is_valid_location_url(location, source_ip_address=None):
        """Validate a device-description URL before making an outbound request."""

        if len(location.encode("utf-8", "replace")) > UPnP.MAX_LOCATION_URL_BYTES:
            return False

        if any(ord(char) < 32 for char in location):
            return False

        try:
            location_parts = urlsplit(location)

        except ValueError:
            return False

        if location_parts.scheme not in {"http", "https"} or not location_parts.netloc:
            return False

        if location_parts.username or location_parts.password or location_parts.fragment:
            return False

        try:
            # Accessing .port raises ValueError for invalid ports.
            port = location_parts.port

        except ValueError:
            return False

        if port is not None and not (0 < port <= 65535):
            return False

        hostname = location_parts.hostname

        if not hostname:
            return False

        if hostname.lower() in {"localhost", "localhost.localdomain"}:
            return source_ip_address in {"127.0.0.1", "::1"}

        try:
            location_ip = ipaddress.ip_address(hostname)

        except ValueError:
            return UPnP._is_local_location_hostname(hostname)

        if source_ip_address is None:
            return not (location_ip.is_loopback or location_ip.is_unspecified or location_ip.is_multicast)

        try:
            source_ip = ipaddress.ip_address(source_ip_address)

        except ValueError:
            return False

        if location_ip == source_ip:
            return True

        if location_ip.is_loopback or location_ip.is_unspecified or location_ip.is_multicast:
            return False

        if not source_ip.is_global and location_ip.is_global:
            return False

        return True


    @staticmethod
    def _resolve_control_url(control_url, location_url):
        """Return an absolute same-origin control URL from a device description.

        Device descriptions are local-network controlled input.  A service's
        controlURL can be relative, but it must not redirect SOAP traffic away
        from the already-validated device description origin or smuggle userinfo,
        fragments, control characters, or grossly large URL strings into the
        follow-up request path.
        """

        if control_url is None:
            return None

        control_url = str(control_url).strip()

        if not control_url:
            return None

        if len(control_url.encode("utf-8", "replace")) > UPnP.MAX_CONTROL_URL_BYTES:
            return None

        if any(ord(char) < 32 for char in control_url):
            return None

        try:
            location_parts = urlsplit(location_url)
            resolved_url = urljoin(location_url, control_url)
            resolved_parts = urlsplit(resolved_url)

        except ValueError:
            return None

        if resolved_parts.scheme not in {"http", "https"}:
            return None

        if resolved_parts.username or resolved_parts.password or resolved_parts.fragment:
            return None

        try:
            _control_port = resolved_parts.port

        except ValueError:
            return None

        if (resolved_parts.scheme, resolved_parts.netloc) != (location_parts.scheme, location_parts.netloc):
            return None

        if len(resolved_url.encode("utf-8", "replace")) > UPnP.MAX_CONTROL_URL_BYTES:
            return None

        return resolved_url

    class Service:
        __slots__ = ("service_type", "control_url")

        def __init__(self, service_type, control_url):
            self.service_type = service_type
            self.control_url = control_url

    class SSDPResponse:
        """Simple Service Discovery Protocol (SSDP) response."""

        __slots__ = ("message", "headers", "source_ip_address", "status_line")

        MAX_HEADER_LINES = 64
        MAX_HEADER_LINE_BYTES = 8192

        def __init__(self, message, source_ip_address=None):

            import email.parser

            self.message = message
            self.source_ip_address = source_ip_address
            lines = message.splitlines()
            self.status_line = lines[0].strip() if lines else ""
            header_lines = []

            for line in lines[1:self.MAX_HEADER_LINES + 1]:
                if len(line.encode("utf-8", "replace")) > self.MAX_HEADER_LINE_BYTES:
                    continue

                header_lines.append(line)

            self.headers = list(email.parser.Parser().parsestr("\r\n".join(header_lines)).items())

        def is_successful_response(self):
            parts = self.status_line.split(None, 2)
            return len(parts) >= 2 and parts[0].startswith("HTTP/") and parts[1] == "200"

        def __bytes__(self):
            return self.message.encode("utf-8")

    class SSDPRequest:
        """Simple Service Discovery Protocol (SSDP) request."""

        __slots__ = ("headers",)

        def __init__(self, search_target):

            self.headers = {
                "HOST": f"{UPnP.MULTICAST_HOST}:{UPnP.MULTICAST_PORT}",
                "ST": search_target,
                "MAN": '"ssdp:discover"',
                "MX": str(UPnP.MX_RESPONSE_DELAY),
                "USER-AGENT": UPnP.USER_AGENT
            }

        def sendto(self, sock, addr):

            msg = bytes(self)
            sock.sendto(msg, addr)

            log.add_debug("UPnP: SSDP request sent: %s", msg)

        def __bytes__(self):

            headers = ["M-SEARCH * HTTP/1.1"]

            for header_name, header_value in self.headers.items():
                headers.append(f"{header_name}: {header_value}")

            return "\r\n".join(headers).encode("utf-8") + b"\r\n\r\n"

    class SSDP:

        @staticmethod
        def get_service_control_url(location_url):

            service_type = None
            control_url = None

            try:
                from urllib.error import HTTPError

                try:
                    with UPnP._open_http_response(location_url, timeout=UPnP.HTTP_REQUEST_TIMEOUT) as response:
                        response_body = UPnP._read_http_response(response)

                except HTTPError as error:
                    # Received HTTP error, check what the response body says.
                    response_body = UPnP._read_http_error_body(error)

                log.add_debug("UPnP: Device description response from %s: %s", (location_url, response_body))

                xml = UPnP._parse_xml_response(response_body, context="UPnP device description")

                for service in xml.findall(".//{urn:schemas-upnp-org:device-1-0}service"):
                    found_service_type = service.find(".//{urn:schemas-upnp-org:device-1-0}serviceType").text

                    if found_service_type in {
                        "urn:schemas-upnp-org:service:WANIPConnection:2",
                        "urn:schemas-upnp-org:service:WANIPConnection:1",
                        "urn:schemas-upnp-org:service:WANPPPConnection:1"
                    }:
                        # We found a router with UPnP enabled.  Resolve the
                        # SOAP control URL relative to the validated device
                        # description URL, but keep it on the same origin.
                        control_url = UPnP._resolve_control_url(
                            service.findtext(".//{urn:schemas-upnp-org:device-1-0}controlURL"),
                            location_url
                        )

                        if control_url is None:
                            log.add_debug(
                                "UPnP: Invalid control URL for service %s, ignoring",
                                found_service_type
                            )
                            continue

                        service_type = found_service_type
                        break

            except Exception as error:
                # Invalid response
                log.add_debug("UPnP: Invalid device description response from %s: %s", (location_url, error))

            return service_type, control_url

        @staticmethod
        def add_service(services, locations, ssdp_response):

            response_headers = {k.upper(): v for k, v in ssdp_response.headers}
            log.add_debug("UPnP: Device search response: %s", bytes(ssdp_response))

            if not ssdp_response.is_successful_response():
                log.add_debug("UPnP: Ignoring non-successful SSDP response: %s", ssdp_response.status_line)
                return

            if "LOCATION" not in response_headers:
                log.add_debug("UPnP: M-SEARCH response did not contain a LOCATION header: %s", ssdp_response.headers)
                return

            location = response_headers["LOCATION"].strip()

            if not UPnP._is_valid_location_url(location, ssdp_response.source_ip_address):
                log.add_debug("UPnP: Invalid device location URL %s, ignoring", location)
                return

            if location in locations:
                log.add_debug("UPnP: Device location was previously processed, ignoring")
                return

            if len(locations) >= UPnP.MAX_DEVICE_DESCRIPTION_REQUESTS:
                log.add_debug(
                    "UPnP: Maximum number of device description requests reached (%s), ignoring %s",
                    (UPnP.MAX_DEVICE_DESCRIPTION_REQUESTS, location)
                )
                return

            if len(locations) >= UPnP.MAX_DISCOVERY_LOCATIONS:
                log.add_debug(
                    "UPnP: Maximum number of device locations reached (%s), ignoring %s",
                    (UPnP.MAX_DISCOVERY_LOCATIONS, location)
                )
                return

            locations.add(location)

            service_type, control_url = UPnP.SSDP.get_service_control_url(location)

            if service_type is None or control_url is None:
                log.add_debug("UPnP: No router with UPnP enabled in device search response, ignoring")
                return

            log.add_debug("UPnP: Device details: service_type '%s'; control_url '%s'", (service_type, control_url))

            if service_type in services:
                log.add_debug("UPnP: Service was previously added, ignoring")
                return

            services[service_type] = UPnP.Service(service_type=service_type, control_url=control_url)

            log.add_debug("UPnP: Added service to list")

        @staticmethod
        def get_services(private_ip):

            log.add_debug("UPnP: Discovering... delay=%s seconds", UPnP.MX_RESPONSE_DELAY)

            # Create a UDP socket and set its timeout
            with socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM, proto=socket.IPPROTO_UDP) as sock:
                log.add_debug("UPnP: Binding socket to local IP address %s", private_ip)

                sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(private_ip))
                sock.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, struct.pack("B", UPnP.MULTICAST_TTL))
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                sock.settimeout(UPnP.MX_RESPONSE_DELAY + 0.1)  # Larger timeout in case data arrives at the last moment
                sock.bind((private_ip, 0))

                # Protocol 2
                wan_igd2 = UPnP.SSDPRequest("urn:schemas-upnp-org:device:InternetGatewayDevice:2")
                wan_ip2 = UPnP.SSDPRequest("urn:schemas-upnp-org:service:WANIPConnection:2")

                wan_igd2.sendto(sock, (UPnP.MULTICAST_HOST, UPnP.MULTICAST_PORT))
                wan_ip2.sendto(sock, (UPnP.MULTICAST_HOST, UPnP.MULTICAST_PORT))

                # Protocol 1
                wan_igd1 = UPnP.SSDPRequest("urn:schemas-upnp-org:device:InternetGatewayDevice:1")
                wan_ip1 = UPnP.SSDPRequest("urn:schemas-upnp-org:service:WANIPConnection:1")
                wan_ppp1 = UPnP.SSDPRequest("urn:schemas-upnp-org:service:WANPPPConnection:1")

                wan_igd1.sendto(sock, (UPnP.MULTICAST_HOST, UPnP.MULTICAST_PORT))
                wan_ip1.sendto(sock, (UPnP.MULTICAST_HOST, UPnP.MULTICAST_PORT))
                wan_ppp1.sendto(sock, (UPnP.MULTICAST_HOST, UPnP.MULTICAST_PORT))

                locations = set()
                services = {}

                # Use an absolute deadline and response cap. A noisy or hostile LAN peer can otherwise keep
                # sending SSDP responses often enough that the per-recv timeout never fires.
                response_deadline = time.monotonic() + UPnP.MX_RESPONSE_DELAY + 0.1
                num_responses = 0

                while num_responses < UPnP.MAX_DISCOVERY_RESPONSES:
                    response_timeout = response_deadline - time.monotonic()

                    if response_timeout <= 0:
                        break

                    try:
                        sock.settimeout(response_timeout)
                        message, source_address = sock.recvfrom(UPnP.MAX_SSDP_RESPONSE_BYTES + 1)
                        num_responses += 1

                        if len(message) > UPnP.MAX_SSDP_RESPONSE_BYTES:
                            log.add_debug(
                                "UPnP: Ignoring oversized SSDP response of %s bytes", len(message))
                            continue

                        source_ip_address = source_address[0] if source_address else None

                        if not UPnP._is_valid_ssdp_source_address(source_ip_address, private_ip):
                            log.add_debug(
                                "UPnP: Ignoring SSDP response from invalid source address %s", source_ip_address)
                            continue

                        UPnP.SSDP.add_service(
                            services, locations, UPnP.SSDPResponse(
                                message.decode("utf-8", "replace"), source_ip_address=source_ip_address))

                    except socket.timeout:
                        break

                if num_responses >= UPnP.MAX_DISCOVERY_RESPONSES:
                    log.add_debug("UPnP: Maximum number of discovery responses reached (%s)", num_responses)

                log.add_debug("UPnP: %s service(s) detected", len(services))

            return services

    def __init__(self):
        super().__init__()
        self._service = None

    @staticmethod
    def _find_service(private_ip):

        services = UPnP.SSDP.get_services(private_ip)
        service = services.get("urn:schemas-upnp-org:service:WANIPConnection:2")

        if not service:
            service = services.get("urn:schemas-upnp-org:service:WANIPConnection:1")

        if not service:
            service = services.get("urn:schemas-upnp-org:service:WANPPPConnection:1")

        return service

    def _request_port_mapping(self, public_port, private_ip, private_port, mapping_description, lease_duration):
        """Function that adds a port mapping to the router.

        If a port mapping already exists, it is updated with a lease
        period of 12 hours.
        """

        from urllib.error import HTTPError
        from urllib.request import Request

        service_type = self._service.service_type
        control_url = self._service.control_url

        log.add_debug("UPnP: Adding port mapping (%s %s, %s) at url '%s'",
                      (private_ip, private_port, service_type, control_url))

        headers = {
            "Host": urlsplit(control_url).netloc,
            "Content-Type": "text/xml; charset=utf-8",
            "USER-AGENT": self.USER_AGENT,
            "SOAPACTION": f'"{service_type}#AddPortMapping"'
        }

        body = (
            ('<?xml version="1.0"?>\r\n'
             + '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
             + 's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">'
             + "<s:Body>"
             + '<u:AddPortMapping xmlns:u="%s">'
             + "<NewRemoteHost></NewRemoteHost>"
             + "<NewExternalPort>%s</NewExternalPort>"
             + "<NewProtocol>TCP</NewProtocol>"
             + "<NewInternalPort>%s</NewInternalPort>"
             + "<NewInternalClient>%s</NewInternalClient>"
             + "<NewEnabled>1</NewEnabled>"
             + "<NewPortMappingDescription>%s</NewPortMappingDescription>"
             + "<NewLeaseDuration>%s</NewLeaseDuration>"
             + "</u:AddPortMapping>"
             + "</s:Body>"
             + "</s:Envelope>\r\n") %
            (service_type, public_port, private_port, private_ip, mapping_description, lease_duration)
        ).encode("utf-8")

        log.add_debug("UPnP: Add port mapping request headers: %s", headers)
        log.add_debug("UPnP: Add port mapping request contents: %s", body)

        try:
            request = Request(control_url, data=body, headers=headers)
            with UPnP._open_http_response(request, timeout=self.HTTP_REQUEST_TIMEOUT) as response:
                response_body = UPnP._read_http_response(response)

        except HTTPError as error:
            # Received HTTP error, but response might also contain UPnP error code.
            # E.g. MikroTik routers that send UPnP error 725 (OnlyPermanentLeasesSupported).
            response_body = UPnP._read_http_error_body(error)

        xml = UPnP._parse_xml_response(response_body, context="UPnP AddPortMapping response")

        if xml.find(".//{http://schemas.xmlsoap.org/soap/envelope/}Body") is None:
            raise PortmapError(f"Invalid response: {response_body}")

        log.add_debug("UPnP: Add port mapping response: %s", response_body)

        error_code = xml.findtext(".//{urn:schemas-upnp-org:control-1-0}errorCode")
        error_description = xml.findtext(".//{urn:schemas-upnp-org:control-1-0}errorDescription")

        return error_code, error_description

    def add_port_mapping(self, lease_duration):
        """This function supports creating a Port Mapping via the UPnP IGDv1
        and IGDv2 protocol.

        Any UPnP port mapping done with IGDv2 will expire after a
        maximum of 7 days (lease period), according to the protocol. We
        set the lease period to a shorter 12 hours, and regularly renew
        the port mapping.
        """

        # Find router
        self._service = self._find_service(self.local_ip_address)

        if not self._service:
            raise PortmapError(_("No UPnP devices found"))

        # Perform the port mapping
        log.add_debug("UPnP: Trying to redirect external WAN port %s TCP => %s port %s TCP",
                      (self.port, self.local_ip_address, self.port))

        error_code, error_description = self._request_port_mapping(
            public_port=self.port,
            private_ip=self.local_ip_address,
            private_port=self.port,
            mapping_description="NicotinePlus",
            lease_duration=lease_duration
        )

        if error_code == "725" and lease_duration > 0:
            log.add_debug("UPnP: Router requested permanent lease duration")
            self.add_port_mapping(lease_duration=0)
            return

        if error_code or error_description:
            raise PortmapError(f"Error code {error_code}: {error_description}")

    def remove_port_mapping(self):

        if not self._service:
            return

        from urllib.error import HTTPError
        from urllib.request import Request

        service_type = self._service.service_type
        control_url = self._service.control_url
        self._service = None

        headers = {
            "Host": urlsplit(control_url).netloc,
            "Content-Type": "text/xml; charset=utf-8",
            "SOAPACTION": f'"{service_type}#DeletePortMapping"'
        }

        body = (
            ('<?xml version="1.0"?>\r\n'
             + '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
             + 's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">'
             + "<s:Body>"
             + '<u:DeletePortMapping xmlns:u="%s">'
             + "<NewRemoteHost></NewRemoteHost>"
             + "<NewExternalPort>%s</NewExternalPort>"
             + "<NewProtocol>TCP</NewProtocol>"
             + "</u:DeletePortMapping>"
             + "</s:Body>"
             + "</s:Envelope>\r\n") %
            (service_type, self.port)
        ).encode("utf-8")

        log.add_debug("UPnP: Remove port mapping request headers: %s", headers)
        log.add_debug("UPnP: Remove port mapping request contents: %s", body)

        try:
            request = Request(control_url, data=body, headers=headers)
            with UPnP._open_http_response(request, timeout=self.HTTP_REQUEST_TIMEOUT) as response:
                response_body = UPnP._read_http_response(response)

        except HTTPError as error:
            # Received HTTP error, but response body might contain useful information.
            response_body = UPnP._read_http_error_body(error)

        log.add_debug("UPnP: Remove port mapping response: %s", response_body)


class PortMapper:
    """Class that handles Port Mapping."""

    __slots__ = ("_active_implementation", "_has_port", "_is_mapping_port", "_timer",
                 "_natpmp", "_operation_lock", "_operation_thread", "_queued_operation", "_upnp")

    RENEWAL_INTERVAL = 7200   # 2 hours
    LEASE_DURATION = 43200    # 12 hours

    OPERATION_ADD = "add"
    OPERATION_REMOVE = "remove"

    def __init__(self):

        self._active_implementation = None
        self._has_port = False
        self._is_mapping_port = False
        self._timer = None
        self._natpmp = NATPMP()
        self._operation_lock = Lock()
        self._operation_thread = None
        self._queued_operation = None
        self._upnp = UPnP()


    def _run_port_mapping_operations(self, operation):
        """Run queued port-mapping operations from a single worker thread."""

        try:
            while operation is not None:
                if operation == self.OPERATION_ADD:
                    self._add_port_mapping()
                else:
                    self._remove_port_mapping()

                with self._operation_lock:
                    operation = self._queued_operation
                    self._queued_operation = None

                    if operation is None:
                        self._operation_thread = None
                        return

        finally:
            with self._operation_lock:
                if self._operation_thread is not None:
                    self._operation_thread = None

    def _schedule_port_mapping_operation(self, operation):
        """Start one worker, or collapse repeated add/remove requests into one pending operation."""

        with self._operation_lock:
            if self._operation_thread is not None:
                self._queued_operation = operation
                return

            thread = Thread(
                target=self._run_port_mapping_operations,
                args=(operation,),
                name="PortMapping",
                daemon=True
            )
            self._operation_thread = thread

        try:
            thread.start()

        except Exception:
            with self._operation_lock:
                if self._operation_thread is thread:
                    self._operation_thread = None

            raise

    def _wait_until_ready(self):

        while self._is_mapping_port:
            # Port mapping in progress, wait until it's finished
            time.sleep(0.1)

    def _add_port_mapping(self):

        self._wait_until_ready()

        if not config.sections["server"]["upnp"]:
            return

        self._is_mapping_port = True
        log.add_debug("Creating Port Mapping rule...")

        try:
            self._active_implementation = self._natpmp
            self._natpmp.add_port_mapping(self.LEASE_DURATION)

        except Exception as natpmp_error:
            log.add_debug("NAT-PMP not available, falling back to UPnP: %s", natpmp_error)

            try:
                self._active_implementation = self._upnp
                self._upnp.add_port_mapping(self.LEASE_DURATION)

            except Exception as upnp_error:
                log.add(_("%(protocol)s: Failed to forward external port %(external_port)s: %(error)s"), {
                    "protocol": self._active_implementation.NAME,
                    "external_port": self._active_implementation.port,
                    "error": upnp_error
                })

                if str(upnp_error) != _("No UPnP devices found"):
                    from traceback import format_exc
                    log.add_debug(format_exc())

                self._active_implementation = None
                self._is_mapping_port = False
                return

        log.add(_("%(protocol)s: External port %(external_port)s successfully forwarded to local "
                  "IP address %(ip_address)s port %(local_port)s"), {
            "protocol": self._active_implementation.NAME,
            "external_port": self._active_implementation.port,
            "ip_address": self._active_implementation.local_ip_address,
            "local_port": self._active_implementation.port
        })
        self._is_mapping_port = False

    def _remove_port_mapping(self):

        self._wait_until_ready()

        if not self._active_implementation:
            return

        self._is_mapping_port = True

        try:
            self._active_implementation.remove_port_mapping()

        except Exception as error:
            log.add_debug("%s: Failed to remove port mapping: %s", (self._active_implementation.NAME, error))

        self._active_implementation = None
        self._is_mapping_port = False

    def _start_renewal_timer(self):
        self._cancel_renewal_timer()
        self._timer = events.schedule(delay=self.RENEWAL_INTERVAL, callback=self.add_port_mapping)

    def _cancel_renewal_timer(self):
        events.cancel_scheduled(self._timer)

    def set_port(self, port, local_ip_address):

        self._natpmp.set_port(port, local_ip_address)
        self._upnp.set_port(port, local_ip_address)

        self._has_port = (port is not None)

    def add_port_mapping(self, blocking=False):

        # Check if we want to do a port mapping
        if not config.sections["server"]["upnp"]:
            return

        if not self._has_port:
            return

        # Do the port mapping
        if blocking:
            self._add_port_mapping()
        else:
            self._schedule_port_mapping_operation(self.OPERATION_ADD)

        # Renew port mapping entry regularly
        self._start_renewal_timer()

    def remove_port_mapping(self, blocking=False):

        self._cancel_renewal_timer()

        if blocking:
            self._remove_port_mapping()
            return

        self._schedule_port_mapping_operation(self.OPERATION_REMOVE)
