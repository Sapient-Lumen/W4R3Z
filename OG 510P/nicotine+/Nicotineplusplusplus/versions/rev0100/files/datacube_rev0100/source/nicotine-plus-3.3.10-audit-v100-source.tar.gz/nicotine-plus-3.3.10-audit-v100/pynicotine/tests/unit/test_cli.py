# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007

from unittest import TestCase
from unittest.mock import patch

from pynicotine.cli import CLI


class CLITest(TestCase):

    # pylint: disable=protected-access

    def test_prompt_log_queue_uses_byte_budget_and_releases_on_flush(self):
        cli = CLI()
        printed_messages = []
        old_bytes = CLI.MAX_QUEUED_LOG_MESSAGE_BYTES
        old_message_bytes = CLI.MAX_LOG_MESSAGE_BYTES

        try:
            CLI.MAX_QUEUED_LOG_MESSAGE_BYTES = 10
            CLI.MAX_LOG_MESSAGE_BYTES = 100
            cli._input_processor.has_custom_prompt = True

            with patch.object(CLI, "_print_log_message", lambda _self, message: printed_messages.append(message)):
                cli._log_message(None, "12345", None, None)
                cli._log_message(None, "67890", None, None)
                cli._log_message(None, "abcde", None, None)

                self.assertEqual(2, len(cli._log_message_queue))
                self.assertLessEqual(cli._log_message_queue_bytes, CLI.MAX_QUEUED_LOG_MESSAGE_BYTES)

                cli._cli_prompt_finished()

        finally:
            CLI.MAX_QUEUED_LOG_MESSAGE_BYTES = old_bytes
            CLI.MAX_LOG_MESSAGE_BYTES = old_message_bytes

        self.assertEqual(["67890", "abcde"], printed_messages)
        self.assertEqual(0, cli._log_message_queue_bytes)
        self.assertFalse(cli._log_message_queue)

    def test_prompt_log_message_is_truncated_before_queueing(self):
        cli = CLI()
        old_message_bytes = CLI.MAX_LOG_MESSAGE_BYTES

        try:
            CLI.MAX_LOG_MESSAGE_BYTES = 8
            cli._input_processor.has_custom_prompt = True
            cli._log_message(None, "x" * 100, None, None)

            queued_message, retained_size = cli._log_message_queue[0]

        finally:
            CLI.MAX_LOG_MESSAGE_BYTES = old_message_bytes

        self.assertLessEqual(retained_size, 8)
        self.assertLessEqual(len(queued_message.encode("utf-8", "replace")), 8)
