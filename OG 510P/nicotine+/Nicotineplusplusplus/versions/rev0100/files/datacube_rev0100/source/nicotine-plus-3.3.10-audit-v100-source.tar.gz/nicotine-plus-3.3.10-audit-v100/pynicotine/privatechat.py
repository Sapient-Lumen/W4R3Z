# COPYRIGHT (C) 2020-2024 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import pynicotine
import time

from collections import deque
from itertools import islice
from pynicotine.config import config
from pynicotine.core import core
from pynicotine.events import events
from pynicotine.logfacility import log
from pynicotine.slskmessages import MessageAcked
from pynicotine.slskmessages import MessageUser
from pynicotine.slskmessages import MessageUsers
from pynicotine.slskmessages import SayChatroom
from pynicotine.slskmessages import SlskMessage
from pynicotine.slskmessages import UserStatus
from pynicotine.utils import censor_text
from pynicotine.utils import find_whole_word
from pynicotine.utils import replace_text
from pynicotine.watchbatch import WatchUserBatcher


class PrivateChat:
    __slots__ = (
        "completions", "private_message_queue", "away_message_users", "users",
        "_private_message_queue_bytes", "_private_message_queue_limit_logged",
        "_server_login_watch_batcher", "_away_message_times",
        "_away_message_limit_logged", "_ctcp_reply_times",
        "_ctcp_reply_user_times", "_ctcp_reply_limit_logged",
        "_message_users_queue", "_message_users_timer_id", "_message_users_limit_logged",
        "_private_message_flush_queue", "_private_message_flush_timer_id",
        "_private_message_flush_limit_logged", "_recent_private_message_ids",
        "_recent_private_message_id_queue", "_recent_private_message_replay_limit_logged",
        "_message_ack_retry_queue", "_message_ack_retry_ids",
        "_message_ack_retry_timer_id", "_message_ack_retry_limit_logged",
        "_message_send_retry_queue", "_message_send_retry_timer_id",
        "_message_send_retry_bytes", "_message_send_retry_limit_logged"
    )

    CTCP_VERSION = "\x01VERSION\x01"
    MAX_PRIVATE_MESSAGE_QUEUE_USERS = 1024
    MAX_PRIVATE_MESSAGES_PER_USER = 64
    MAX_PRIVATE_MESSAGE_QUEUE_BYTES = 32 * 1024 * 1024
    MAX_PRIVATE_MESSAGE_BYTES = 64 * 1024
    MAX_PRIVATE_CHAT_USERS = 4096
    MAX_COMPLETIONS = 20000
    MAX_AWAY_MESSAGE_USERS = 8192
    MAX_AWAY_AUTO_REPLIES_PER_MINUTE = 60
    AWAY_AUTO_REPLY_RATE_PERIOD = 60
    MAX_CTCP_REPLIES_PER_MINUTE = 30
    MAX_CTCP_REPLY_USERS = 8192
    CTCP_REPLY_RATE_PERIOD = 60
    CTCP_REPLY_USER_COOLDOWN = 60
    MAX_SERVER_LOGIN_WATCHES_PER_TICK = 1000
    MAX_PENDING_SERVER_LOGIN_WATCHES = 65536
    MAX_MESSAGE_USERS_PER_BATCH = 500
    MAX_MESSAGE_USER_BATCHES_PER_TICK = 4
    MAX_PENDING_MESSAGE_USERS = 20000
    MESSAGE_USERS_RETRY_DELAY = 1
    MAX_PRIVATE_MESSAGE_FLUSHES_PER_TICK = 64
    MAX_PENDING_PRIVATE_MESSAGE_FLUSHES = 4096
    MAX_RECENT_PRIVATE_MESSAGE_IDS = 100000
    MAX_PENDING_MESSAGE_ACK_RETRIES = 65536
    MAX_MESSAGE_ACK_RETRIES_PER_TICK = 512
    MESSAGE_ACK_RETRY_DELAY = 1
    MAX_PENDING_MESSAGE_SEND_RETRIES = 4096
    MAX_PENDING_MESSAGE_SEND_RETRY_BYTES = 4 * 1024 * 1024
    MAX_MESSAGE_SEND_RETRIES_PER_TICK = 128
    MESSAGE_SEND_RETRY_DELAY = 1

    def __init__(self):

        self.completions = set()
        self.private_message_queue = {}
        self.away_message_users = set()
        self.users = set()
        self._private_message_queue_bytes = 0
        self._private_message_queue_limit_logged = False
        self._away_message_times = deque()
        self._away_message_limit_logged = False
        self._ctcp_reply_times = deque()
        self._ctcp_reply_user_times = {}
        self._ctcp_reply_limit_logged = False
        self._server_login_watch_batcher = WatchUserBatcher(
            "privatechat", lambda username: username in self.users,
            lambda: self.MAX_SERVER_LOGIN_WATCHES_PER_TICK,
            lambda: self.MAX_PENDING_SERVER_LOGIN_WATCHES
        )
        self._message_users_queue = deque()
        self._message_users_timer_id = None
        self._message_users_limit_logged = False
        self._private_message_flush_queue = deque()
        self._private_message_flush_timer_id = None
        self._private_message_flush_limit_logged = False
        self._recent_private_message_ids = set()
        self._recent_private_message_id_queue = deque()
        self._recent_private_message_replay_limit_logged = False
        self._message_ack_retry_queue = deque()
        self._message_ack_retry_ids = set()
        self._message_ack_retry_timer_id = None
        self._message_ack_retry_limit_logged = False
        self._message_send_retry_queue = deque()
        self._message_send_retry_timer_id = None
        self._message_send_retry_bytes = 0
        self._message_send_retry_limit_logged = False

        for event_name, callback in (
            ("message-user", self._message_user),
            ("peer-address", self._get_peer_address),
            ("quit", self._quit),
            ("server-login", self._server_login),
            ("server-disconnect", self._server_disconnect),
            ("server-message-unsent", self._server_message_unsent),
            ("start", self._start),
            ("user-status", self._user_status)
        ):
            events.connect(event_name, callback)

    def _start(self):

        if not config.sections["privatechat"]["store"]:
            # Clear list of previously open chats if we don't want to restore them
            config.sections["privatechat"]["users"].clear()
            return

        for username in config.sections["privatechat"]["users"]:
            if len(self.users) >= self.MAX_PRIVATE_CHAT_USERS:
                log.add_debug(
                    "Private chat restore limit of %s users reached; ignoring remaining saved tabs",
                    self.MAX_PRIVATE_CHAT_USERS
                )
                break

            if isinstance(username, str) and username not in self.users:
                self.show_user(username, switch_page=False, remembered=True)

        self.update_completions()

    def _quit(self):
        self._server_login_watch_batcher.cancel()
        self.remove_all_users(is_permanent=False)
        self.completions.clear()
        self._cancel_message_users_queue()
        self._cancel_private_message_flush_queue()
        self._clear_private_message_queue()
        self._clear_private_message_replay_state()
        self._cancel_message_ack_retry_queue()
        self._cancel_message_send_retry_queue()
        self._clear_away_message_state()
        self._clear_ctcp_reply_state()

    def _server_login(self, msg):

        if not msg.success:
            return

        self._server_login_watch_batcher.queue(self.users)

    def _server_disconnect(self, _msg):

        self._server_login_watch_batcher.cancel()
        self._cancel_message_users_queue()
        self._cancel_private_message_flush_queue()
        self._clear_private_message_queue()
        self._clear_private_message_replay_state()
        self._cancel_message_ack_retry_queue()
        self._cancel_message_send_retry_queue()
        self._clear_away_message_state()
        self._clear_ctcp_reply_state()
        self.update_completions()

    def add_user(self, username):

        if not isinstance(username, str):
            return False

        if len(username.encode("utf-8", "replace")) > MessageUser.MAX_USERNAME_FIELD_BYTES:
            log.add_debug("Ignoring private chat user with username exceeding %s bytes",
                          MessageUser.MAX_USERNAME_FIELD_BYTES)
            return False

        if username in self.users:
            return True

        if len(self.users) >= self.MAX_PRIVATE_CHAT_USERS:
            log.add_debug("Private chat user limit of %s reached, ignoring new tab for user %s",
                          (self.MAX_PRIVATE_CHAT_USERS, username))
            return False

        self.users.add(username)

        if username not in config.sections["privatechat"]["users"]:
            config.sections["privatechat"]["users"].insert(0, username)

        return True

    def remove_user(self, username, is_permanent=True):

        if is_permanent and username in config.sections["privatechat"]["users"]:
            config.sections["privatechat"]["users"].remove(username)

        self.users.remove(username)
        core.users.unwatch_user(username, context="privatechat")
        events.emit("private-chat-remove-user", username)

    def remove_all_users(self, is_permanent=True):
        for username in self.users.copy():
            self.remove_user(username, is_permanent)

    def show_user(self, username, switch_page=True, remembered=False):

        if not self.add_user(username):
            return False

        events.emit("private-chat-show-user", username, switch_page, remembered)
        core.users.watch_user(username, context="privatechat")
        return True

    def clear_private_messages(self, username):
        events.emit("clear-private-messages", username)

    @staticmethod
    def _get_queued_private_message_size(msg):
        message = getattr(msg, "message", "")

        if not isinstance(message, str):
            message = str(message)

        return len(message.encode("utf-8", "replace"))

    def _release_private_message_queue(self, username):
        queued_messages = self.private_message_queue.pop(username, None)

        if not queued_messages:
            return []

        self._private_message_queue_bytes = max(
            0,
            self._private_message_queue_bytes
            - sum(self._get_queued_private_message_size(queued_msg) for queued_msg in queued_messages)
        )
        return queued_messages

    def _clear_private_message_queue(self):
        self.private_message_queue.clear()
        self._private_message_queue_bytes = 0
        self._private_message_queue_limit_logged = False

    def _drop_oldest_private_message_queue_user(self):
        if not self.private_message_queue:
            return False

        oldest_username = next(iter(self.private_message_queue))
        self._release_private_message_queue(oldest_username)
        return True

    def private_message_queue_add(self, msg):
        """Queue a private message until we've received a user's IP address."""

        username = msg.user
        msg_size = self._get_queued_private_message_size(msg)

        if msg_size > self.MAX_PRIVATE_MESSAGE_BYTES:
            if not self._private_message_queue_limit_logged:
                log.add_debug("Private message queue item byte limit of %s reached, ignoring queued message",
                              self.MAX_PRIVATE_MESSAGE_BYTES)
                self._private_message_queue_limit_logged = True
            return

        while (self._private_message_queue_bytes + msg_size > self.MAX_PRIVATE_MESSAGE_QUEUE_BYTES
                and self._drop_oldest_private_message_queue_user()):
            pass

        if self._private_message_queue_bytes + msg_size > self.MAX_PRIVATE_MESSAGE_QUEUE_BYTES:
            if not self._private_message_queue_limit_logged:
                log.add_debug("Private message queue byte limit of %s reached, ignoring queued message",
                              self.MAX_PRIVATE_MESSAGE_QUEUE_BYTES)
                self._private_message_queue_limit_logged = True
            return

        messages = self.private_message_queue.get(username)

        if messages is None:
            while (len(self.private_message_queue) >= self.MAX_PRIVATE_MESSAGE_QUEUE_USERS
                    and self._drop_oldest_private_message_queue_user()):
                pass

            if len(self.private_message_queue) >= self.MAX_PRIVATE_MESSAGE_QUEUE_USERS:
                if not self._private_message_queue_limit_logged:
                    log.add_debug("Private message queued-user limit of %s reached, ignoring queued message",
                                  self.MAX_PRIVATE_MESSAGE_QUEUE_USERS)
                    self._private_message_queue_limit_logged = True
                return

            messages = self.private_message_queue[username] = []

        if len(messages) >= self.MAX_PRIVATE_MESSAGES_PER_USER:
            dropped_msg = messages.pop(0)
            self._private_message_queue_bytes = max(
                0, self._private_message_queue_bytes - self._get_queued_private_message_size(dropped_msg))

        messages.append(msg)
        self._private_message_queue_bytes += msg_size

    def _clear_away_message_state(self):
        self.away_message_users.clear()
        self._away_message_times.clear()
        self._away_message_limit_logged = False

    def _can_send_away_message(self, username):
        if username in self.away_message_users:
            return False

        if len(self.away_message_users) >= self.MAX_AWAY_MESSAGE_USERS:
            if not self._away_message_limit_logged:
                log.add_debug(
                    "Away auto-reply user limit of %s reached; ignoring additional auto-replies",
                    self.MAX_AWAY_MESSAGE_USERS
                )
                self._away_message_limit_logged = True
            return False

        now = time.monotonic()
        cutoff_time = now - self.AWAY_AUTO_REPLY_RATE_PERIOD

        while self._away_message_times and self._away_message_times[0] <= cutoff_time:
            self._away_message_times.popleft()

        if len(self._away_message_times) >= self.MAX_AWAY_AUTO_REPLIES_PER_MINUTE:
            if not self._away_message_limit_logged:
                log.add_debug(
                    "Away auto-reply rate limit of %s per minute reached; ignoring additional auto-replies",
                    self.MAX_AWAY_AUTO_REPLIES_PER_MINUTE
                )
                self._away_message_limit_logged = True
            return False

        self._away_message_times.append(now)
        self.away_message_users.add(username)
        self._away_message_limit_logged = False
        return True

    def _clear_ctcp_reply_state(self):
        self._ctcp_reply_times.clear()
        self._ctcp_reply_user_times.clear()
        self._ctcp_reply_limit_logged = False

    def _can_send_ctcp_reply(self, username):
        now = time.monotonic()
        cutoff_time = now - self.CTCP_REPLY_RATE_PERIOD

        while self._ctcp_reply_times and self._ctcp_reply_times[0] <= cutoff_time:
            self._ctcp_reply_times.popleft()

        for queued_username, last_reply_time in list(self._ctcp_reply_user_times.items()):
            if last_reply_time <= cutoff_time:
                del self._ctcp_reply_user_times[queued_username]

        last_reply_time = self._ctcp_reply_user_times.get(username)

        if last_reply_time is not None and (now - last_reply_time) < self.CTCP_REPLY_USER_COOLDOWN:
            return False

        if (username not in self._ctcp_reply_user_times
                and len(self._ctcp_reply_user_times) >= self.MAX_CTCP_REPLY_USERS):
            if not self._ctcp_reply_limit_logged:
                log.add_debug(
                    "CTCP auto-reply user limit of %s reached; ignoring additional CTCP replies",
                    self.MAX_CTCP_REPLY_USERS
                )
                self._ctcp_reply_limit_logged = True
            return False

        if len(self._ctcp_reply_times) >= self.MAX_CTCP_REPLIES_PER_MINUTE:
            if not self._ctcp_reply_limit_logged:
                log.add_debug(
                    "CTCP auto-reply rate limit of %s per minute reached; ignoring additional CTCP replies",
                    self.MAX_CTCP_REPLIES_PER_MINUTE
                )
                self._ctcp_reply_limit_logged = True
            return False

        self._ctcp_reply_times.append(now)
        self._ctcp_reply_user_times[username] = now
        self._ctcp_reply_limit_logged = False
        return True

    def send_automatic_message(self, username, message):
        self.send_message(username, f"[Automatic Message] {message}")

    def echo_message(self, username, message, message_type="local"):
        events.emit("echo-private-message", username, message, message_type)

    @staticmethod
    def _cap_outgoing_message_field(message):
        return SlskMessage.truncate_string_bytes(message, SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES)

    @staticmethod
    def _cap_outgoing_username(username):
        return SlskMessage.truncate_string_bytes(username, SlskMessage.MAX_USERNAME_FIELD_BYTES)

    def send_message(self, username, message):

        user_text = core.pluginhandler.outgoing_private_chat_event(username, message)
        if user_text is None:
            return

        username, message = user_text
        username = self._cap_outgoing_username(username)
        message = self._cap_outgoing_message_field(message)

        if config.sections["words"]["replacewords"] and message != self.CTCP_VERSION:
            message = replace_text(message, config.sections["words"]["autoreplaced"])
            message = self._cap_outgoing_message_field(message)

        msg = MessageUser(username, message)

        if core.send_message_to_server(msg) is False:
            log.add_debug("Deferring outgoing private message to %s; network queue rejected it", username)
            self._queue_message_send_retry(msg, notify_on_success=True)
            return

        core.pluginhandler.outgoing_private_chat_notification(username, message)
        events.emit("message-user", msg)

    def _cancel_message_users_queue(self):
        events.cancel_scheduled(self._message_users_timer_id)
        self._message_users_timer_id = None
        self._message_users_queue.clear()
        self._message_users_limit_logged = False

    def _queue_message_users_batch(self, batch, message):
        if len(self._message_users_queue) * self.MAX_MESSAGE_USERS_PER_BATCH >= self.MAX_PENDING_MESSAGE_USERS:
            if not self._message_users_limit_logged:
                log.add_debug(
                    "Private message bulk-send queue reached %s users; discarding additional users",
                    self.MAX_PENDING_MESSAGE_USERS
                )
                self._message_users_limit_logged = True
            return False

        self._message_users_queue.append((tuple(batch), message))
        return True

    def _schedule_message_users_queue(self, delay=0):
        if not self._message_users_queue or self._message_users_timer_id is not None:
            return

        self._message_users_timer_id = events.schedule(delay=delay, callback=self._process_message_users_queue)

        if self._message_users_timer_id is None:
            self._message_users_queue.clear()

    def _process_message_users_queue(self):
        self._message_users_timer_id = None
        num_batches = 0
        retry_delay = 0

        while self._message_users_queue and num_batches < self.MAX_MESSAGE_USER_BATCHES_PER_TICK:
            users, message = self._message_users_queue.popleft()

            if core.send_message_to_server(MessageUsers(users, message)) is False:
                self._message_users_queue.appendleft((users, message))
                retry_delay = self.MESSAGE_USERS_RETRY_DELAY
                break

            num_batches += 1

        if self._message_users_queue:
            self._schedule_message_users_queue(delay=retry_delay)
        else:
            self._message_users_limit_logged = False

    def _queue_message_users(self, users, message):
        message = self._cap_outgoing_message_field(message)
        batch = []
        total_users = 0

        for username in users:
            username = self._cap_outgoing_username(username)
            if total_users >= self.MAX_PENDING_MESSAGE_USERS:
                if not self._message_users_limit_logged:
                    log.add_debug(
                        "Private message bulk-send request reached %s users; discarding additional users",
                        self.MAX_PENDING_MESSAGE_USERS
                    )
                    self._message_users_limit_logged = True
                break

            batch.append(username)
            total_users += 1

            if len(batch) >= self.MAX_MESSAGE_USERS_PER_BATCH:
                if not self._queue_message_users_batch(batch, message):
                    break
                batch = []

        if batch:
            self._queue_message_users_batch(batch, message)

        if not self._message_users_queue:
            return False

        self._process_message_users_queue()
        return True

    def send_message_users(self, target, message):

        if not message:
            return

        users = None

        if target == "buddies":
            users = core.buddies.users

        elif target == "downloading":
            users = core.uploads.iter_downloading_users()

        if users:
            self._queue_message_users(users, message)

    def _cancel_private_message_flush_queue(self):
        events.cancel_scheduled(self._private_message_flush_timer_id)
        self._private_message_flush_timer_id = None
        self._private_message_flush_queue.clear()
        self._private_message_flush_limit_logged = False

    def _schedule_private_message_flush_queue(self):
        if (not self._private_message_flush_queue
                or self._private_message_flush_timer_id is not None):
            return

        self._private_message_flush_timer_id = events.schedule(
            delay=0, callback=self._process_private_message_flush_queue)

        if self._private_message_flush_timer_id is None:
            # Scheduler is saturated. Keep message processing bounded, but do
            # not leave messages stuck behind a missing continuation timer.
            self._process_private_message_flush_queue()

    def _process_private_message_flush_queue(self):
        self._private_message_flush_timer_id = None
        num_processed = 0

        while (self._private_message_flush_queue
                and num_processed < self.MAX_PRIVATE_MESSAGE_FLUSHES_PER_TICK):
            username, queued_msg = self._private_message_flush_queue.popleft()
            queued_msg.user = username
            events.emit("message-user", queued_msg, queued_message=True)
            num_processed += 1

        if self._private_message_flush_queue:
            if not self._private_message_flush_limit_logged:
                log.add_debug(
                    "Flushing queued private messages in batches of %s to avoid a peer-address fanout burst",
                    self.MAX_PRIVATE_MESSAGE_FLUSHES_PER_TICK
                )
                self._private_message_flush_limit_logged = True

            self._schedule_private_message_flush_queue()
        else:
            self._private_message_flush_limit_logged = False

    def _drop_pending_private_message_flushes(self, username):
        if not self._private_message_flush_queue:
            return

        self._private_message_flush_queue = deque(
            (queued_username, queued_msg)
            for queued_username, queued_msg in self._private_message_flush_queue
            if queued_username != username
        )

    def _queue_private_message_flushes(self, username, queued_messages):
        for queued_msg in queued_messages:
            if len(self._private_message_flush_queue) >= self.MAX_PENDING_PRIVATE_MESSAGE_FLUSHES:
                if not self._private_message_flush_limit_logged:
                    log.add_debug(
                        "Queued private-message flush limit of %s reached, dropping additional messages",
                        self.MAX_PENDING_PRIVATE_MESSAGE_FLUSHES
                    )
                    self._private_message_flush_limit_logged = True
                break

            self._private_message_flush_queue.append((username, queued_msg))

        if self._private_message_flush_queue:
            self._process_private_message_flush_queue()

    def _get_peer_address(self, msg):
        """Server code 3.

        Received a user's IP address, process any queued private
        messages and check if the IP is ignored
        """

        username = msg.user

        if username not in self.private_message_queue:
            return

        queued_messages = self._release_private_message_queue(username)
        self._queue_private_message_flushes(username, queued_messages)

    def _user_status(self, msg):
        """Server code 7."""

        if msg.user == core.users.login_username and msg.status != UserStatus.AWAY:
            # Reset list of users we've sent away messages to when the away session ends
            self._clear_away_message_state()

        if msg.status == UserStatus.OFFLINE:
            self._release_private_message_queue(msg.user)
            self._drop_pending_private_message_flushes(msg.user)

    def _clear_private_message_replay_state(self):
        self._recent_private_message_ids.clear()
        self._recent_private_message_id_queue.clear()
        self._recent_private_message_replay_limit_logged = False

    def _remember_private_message_id(self, username, message_id):
        """Return False if a server private-message ID was seen recently.

        The server retries private messages until clients acknowledge them. A
        buggy or hostile server/MITM can also replay an already-acked message
        ID. Avoid running duplicate IDs through chat logs, plugins, UI rows and
        notifications again, while still allowing the caller to acknowledge the
        replay. Keep this process-local and count-bounded; message IDs are not
        durable application state.
        """

        if message_id is None:
            return True

        key = (username, message_id)

        if key in self._recent_private_message_ids:
            return False

        if len(self._recent_private_message_id_queue) >= self.MAX_RECENT_PRIVATE_MESSAGE_IDS:
            oldest_key = self._recent_private_message_id_queue.popleft()
            self._recent_private_message_ids.discard(oldest_key)

            if not self._recent_private_message_replay_limit_logged:
                log.add_debug(
                    "Retained private-message ID cache reached %s entries; discarding oldest replay guards",
                    self.MAX_RECENT_PRIVATE_MESSAGE_IDS
                )
                self._recent_private_message_replay_limit_logged = True

        self._recent_private_message_ids.add(key)
        self._recent_private_message_id_queue.append(key)
        return True

    def _has_recent_private_message_id(self, username, message_id):

        if message_id is None:
            return False

        return (username, message_id) in self._recent_private_message_ids

    def _cancel_message_ack_retry_queue(self):
        events.cancel_scheduled(self._message_ack_retry_timer_id)
        self._message_ack_retry_timer_id = None
        self._message_ack_retry_queue.clear()
        self._message_ack_retry_ids.clear()
        self._message_ack_retry_limit_logged = False

    def _queue_message_ack_retry(self, message_id):
        if message_id is None or message_id in self._message_ack_retry_ids:
            return

        if len(self._message_ack_retry_queue) >= self.MAX_PENDING_MESSAGE_ACK_RETRIES:
            if not self._message_ack_retry_limit_logged:
                log.add_debug(
                    "Private-message acknowledgement retry queue reached %s entries; discarding additional acks",
                    self.MAX_PENDING_MESSAGE_ACK_RETRIES
                )
                self._message_ack_retry_limit_logged = True

            return

        self._message_ack_retry_queue.append(message_id)
        self._message_ack_retry_ids.add(message_id)
        self._schedule_message_ack_retry_queue(delay=self.MESSAGE_ACK_RETRY_DELAY)

    def _schedule_message_ack_retry_queue(self, delay=0):
        if not self._message_ack_retry_queue or self._message_ack_retry_timer_id is not None:
            return

        self._message_ack_retry_timer_id = events.schedule(
            delay=delay, callback=self._process_message_ack_retry_queue)

        if self._message_ack_retry_timer_id is None:
            # Scheduler saturation is backpressure too. Keep the deduped queue
            # so the next incoming duplicate/retry can still acknowledge, but do
            # not spin synchronously from the caller path.
            self._message_ack_retry_limit_logged = True

    def _process_message_ack_retry_queue(self):
        self._message_ack_retry_timer_id = None
        num_processed = 0
        retry_delay = 0

        while (self._message_ack_retry_queue
                and num_processed < self.MAX_MESSAGE_ACK_RETRIES_PER_TICK):
            message_id = self._message_ack_retry_queue.popleft()
            self._message_ack_retry_ids.discard(message_id)

            if core.send_message_to_server(MessageAcked(message_id)) is False:
                self._message_ack_retry_queue.appendleft(message_id)
                self._message_ack_retry_ids.add(message_id)
                retry_delay = self.MESSAGE_ACK_RETRY_DELAY
                break

            num_processed += 1

        if self._message_ack_retry_queue:
            self._schedule_message_ack_retry_queue(delay=retry_delay)
        else:
            self._message_ack_retry_limit_logged = False

    def _cancel_message_send_retry_queue(self):
        events.cancel_scheduled(self._message_send_retry_timer_id)
        self._message_send_retry_timer_id = None
        self._message_send_retry_queue.clear()
        self._message_send_retry_bytes = 0
        self._message_send_retry_limit_logged = False

    @staticmethod
    def _estimate_message_send_retry_size(msg):
        return sum(
            len(str(value).encode("utf-8", "replace"))
            for value in (getattr(msg, "user", ""), getattr(msg, "message", ""), getattr(msg, "msg", ""))
            if value is not None
        )

    def _queue_message_send_retry(self, msg, notify_on_success=False):
        msg_size = self._estimate_message_send_retry_size(msg)

        if (len(self._message_send_retry_queue) >= self.MAX_PENDING_MESSAGE_SEND_RETRIES
                or self._message_send_retry_bytes + msg_size > self.MAX_PENDING_MESSAGE_SEND_RETRY_BYTES):
            if not self._message_send_retry_limit_logged:
                log.add_debug(
                    "Outgoing private-message retry queue reached %(items)s entries or %(bytes)s bytes; "
                    "discarding additional messages", {
                        "items": self.MAX_PENDING_MESSAGE_SEND_RETRIES,
                        "bytes": self.MAX_PENDING_MESSAGE_SEND_RETRY_BYTES
                    })
                self._message_send_retry_limit_logged = True

            return False

        self._message_send_retry_queue.append((msg, notify_on_success, msg_size))
        self._message_send_retry_bytes += msg_size
        self._schedule_message_send_retry_queue(delay=self.MESSAGE_SEND_RETRY_DELAY)
        return True

    def _schedule_message_send_retry_queue(self, delay=0):
        if not self._message_send_retry_queue or self._message_send_retry_timer_id is not None:
            return

        self._message_send_retry_timer_id = events.schedule(
            delay=delay, callback=self._process_message_send_retry_queue)

        if self._message_send_retry_timer_id is None:
            self._message_send_retry_limit_logged = True

    def _process_message_send_retry_queue(self):
        self._message_send_retry_timer_id = None
        num_processed = 0
        retry_delay = 0

        while (self._message_send_retry_queue
                and num_processed < self.MAX_MESSAGE_SEND_RETRIES_PER_TICK):
            msg, notify_on_success, msg_size = self._message_send_retry_queue.popleft()
            self._message_send_retry_bytes = max(0, self._message_send_retry_bytes - msg_size)

            if core.send_message_to_server(msg) is False:
                self._message_send_retry_queue.appendleft((msg, notify_on_success, msg_size))
                self._message_send_retry_bytes += msg_size
                retry_delay = self.MESSAGE_SEND_RETRY_DELAY
                break

            if notify_on_success and msg.__class__ is MessageUser:
                core.pluginhandler.outgoing_private_chat_notification(msg.user, msg.message)
                events.emit("message-user", msg)

            num_processed += 1

        if self._message_send_retry_queue:
            self._schedule_message_send_retry_queue(delay=retry_delay)
        else:
            self._message_send_retry_bytes = 0
            self._message_send_retry_limit_logged = False

    def _server_message_unsent(self, msg):
        msg_class = msg.__class__

        if msg_class is MessageAcked:
            self._queue_message_ack_retry(msg.msgid)
            return

        if msg_class in {MessageUser, MessageUsers}:
            self._queue_message_send_retry(msg)

    def _acknowledge_private_message(self, username, message_id):

        if message_id is None:
            return True

        if core.send_message_to_server(MessageAcked(message_id)) is False:
            log.add_debug(
                "Deferring private message ID %s from user %s; acknowledgement was rejected by the network queue",
                (message_id, username)
            )
            return False

        return True

    def get_message_type(self, text, is_outgoing_message):

        if text.startswith("/me "):
            return "action"

        if is_outgoing_message:
            return "local"

        if core.users.login_username and find_whole_word(core.users.login_username.lower(), text.lower()) > -1:
            return "hilite"

        return "remote"

    def _message_user(self, msg, queued_message=False):
        """Server code 22."""

        is_outgoing_message = (msg.message_id is None)

        username = msg.user
        tag_username = (core.users.login_username if is_outgoing_message else username)
        message = msg.message
        timestamp = msg.timestamp if not msg.is_new_message else None

        if not is_outgoing_message:
            if not queued_message:
                is_duplicate_message = self._has_recent_private_message_id(username, msg.message_id)

                if not self._acknowledge_private_message(username, msg.message_id):
                    # Do not poison the replay cache or deliver/log/plugin-dispatch
                    # the message until the acknowledgement has actually been
                    # accepted into the server output path. The server retries
                    # private messages until acknowledged, so a later retry can
                    # be processed once local backpressure clears.
                    msg.user = None
                    return

                if is_duplicate_message:
                    log.add_debug(
                        "Ignoring replayed private message ID %s from user %s",
                        (msg.message_id, username)
                    )
                    msg.user = None
                    return

                self._remember_private_message_id(username, msg.message_id)

            if username == "server":
                start_str = "The room you are trying to enter ("

                if message.startswith(start_str) and ") " in message:
                    # Redirect message to chat room tab if join wasn't successful
                    msg.user = None
                    room = message[len(start_str):message.rfind(") ")]
                    events.emit("say-chat-room", SayChatroom(room=room, message=message, user=username))
                    return
            else:
                # Check ignore status for all other users except "server"
                if core.network_filter.is_user_ignored(username):
                    msg.user = None
                    return

                user_address = core.users.addresses.get(username)

                if user_address is not None:
                    if core.network_filter.is_user_ip_ignored(username):
                        msg.user = None
                        return

                elif not queued_message:
                    # Ask for user's IP address and queue the private message until we receive the address
                    if username not in self.private_message_queue and not core.users.request_ip_address(username):
                        msg.user = None
                        return

                    self.private_message_queue_add(msg)
                    msg.user = None
                    return

            user_text = core.pluginhandler.incoming_private_chat_event(username, message)
            if user_text is None:
                msg.user = None
                return

            if not self.show_user(username, switch_page=False):
                msg.user = None
                return

            _username, msg.message = user_text
            message = msg.message

            log.add_chat(_("Private message from user '%(user)s': %(message)s"), {
                "user": username,
                "message": message
            })

        msg.message_type = self.get_message_type(message, is_outgoing_message)
        is_action_message = (msg.message_type == "action")
        is_ctcp_version = (message == self.CTCP_VERSION)

        # SEND CLIENT VERSION to user if the following string is sent
        if is_ctcp_version:
            msg.message = message = "CTCP VERSION"

        if is_action_message:
            message = message.replace("/me ", "", 1)

        if not is_outgoing_message and config.sections["words"]["censorwords"]:
            message = censor_text(message, censored_patterns=config.sections["words"]["censored"])

        if is_action_message:
            msg.formatted_message = msg.message = f"* {tag_username} {message}"
        else:
            msg.formatted_message = f"[{tag_username}] {message}"

        if config.sections["logging"]["privatechat"] or username in config.sections["logging"]["private_chats"]:
            log.queue_log_file_write(
                folder_path=log.private_chat_folder_path,
                basename=username, text=msg.formatted_message, timestamp=timestamp
            )

        if is_outgoing_message:
            return

        core.pluginhandler.incoming_private_chat_notification(username, msg.message)

        if (is_ctcp_version and not config.sections["server"]["ctcpmsgs"]
                and self._can_send_ctcp_reply(username)):
            self.send_message(username, f"{pynicotine.__application_name__} {pynicotine.__version__}")

        if not msg.is_new_message:
            # Message was sent while offline, don't auto-reply
            return

        autoreply = config.sections["server"]["autoreply"]

        if (autoreply and core.users.login_status == UserStatus.AWAY
                and self._can_send_away_message(username)):
            self.send_automatic_message(username, autoreply)

    def update_completions(self):

        self.completions.clear()

        def add_limited(items):
            remaining = self.MAX_COMPLETIONS - len(self.completions)

            if remaining <= 0:
                return False

            self.completions.update(islice(items, remaining))
            return len(self.completions) < self.MAX_COMPLETIONS

        add_limited((config.sections["server"]["login"],))

        if config.sections["words"]["buddies"]:
            add_limited(core.buddies.users)

        if config.sections["words"]["commands"] and len(self.completions) < self.MAX_COMPLETIONS:
            add_limited(core.pluginhandler.iter_command_list(
                "private_chat", limit=self.MAX_COMPLETIONS - len(self.completions)))

        if config.sections["words"]["roomnames"] and len(self.completions) < self.MAX_COMPLETIONS:
            # Room lists can be very large and are server-controlled. Keep
            # login/buddy/command completions first, then fill remaining slots
            # with rooms instead of copying the entire room cache.
            add_limited(core.chatrooms.server_rooms)

        events.emit("private-chat-completions", self.completions.copy())
