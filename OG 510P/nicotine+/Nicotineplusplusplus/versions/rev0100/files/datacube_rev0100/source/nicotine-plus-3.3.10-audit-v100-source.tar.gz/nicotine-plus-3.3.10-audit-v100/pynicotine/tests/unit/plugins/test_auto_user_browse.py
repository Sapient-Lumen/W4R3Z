# COPYRIGHT (C) 2026 Nicotine+ Contributors

from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock
from unittest.mock import patch

from pynicotine.plugins.auto_user_browse import Plugin
from pynicotine.slskmessages import UserStatus


class AutoUserBrowsePluginTest(TestCase):

    def _plugin(self):
        plugin = Plugin()
        plugin.core = SimpleNamespace(
            users=SimpleNamespace(statuses={}),
            userbrowse=SimpleNamespace(browse_user=Mock())
        )
        plugin.settings["users"] = ["user1", "user2", "user3", "user4", "user5"]
        return plugin

    def test_status_burst_uses_single_delayed_timer_and_batches_browses(self):
        plugin = self._plugin()

        old_batch = Plugin.MAX_BROWSE_USERS_PER_TICK
        Plugin.MAX_BROWSE_USERS_PER_TICK = 2

        schedule = Mock(side_effect=[101, 102, 103])
        fake_events = SimpleNamespace(schedule=schedule, cancel_scheduled=Mock())

        try:
            with patch("pynicotine.plugins.auto_user_browse.events", fake_events):
                for username in plugin.settings["users"]:
                    plugin.user_status_notification(username, UserStatus.ONLINE, None)

                self.assertEqual(1, schedule.call_count)
                self.assertEqual(5, len(plugin.pending_browse_users))

                plugin._process_browse_queue()
                self.assertEqual(
                    [("user1",), ("user2",)],
                    [call.args for call in plugin.core.userbrowse.browse_user.call_args_list]
                )
                self.assertEqual(2, schedule.call_count)
                self.assertEqual(3, len(plugin.pending_browse_users))

        finally:
            Plugin.MAX_BROWSE_USERS_PER_TICK = old_batch

    def test_processed_user_cap_blocks_additional_scheduled_browses(self):
        plugin = self._plugin()

        old_limit = Plugin.MAX_PROCESSED_USERS
        Plugin.MAX_PROCESSED_USERS = 1
        fake_events = SimpleNamespace(schedule=Mock(return_value=1), cancel_scheduled=Mock())

        try:
            with patch("pynicotine.plugins.auto_user_browse.events", fake_events):
                plugin.user_status_notification("user1", UserStatus.ONLINE, None)
                plugin.user_status_notification("user2", UserStatus.ONLINE, None)

            self.assertEqual({"user1"}, plugin.processed_users)
            self.assertEqual(["user1"], list(plugin.pending_browse_users))

        finally:
            Plugin.MAX_PROCESSED_USERS = old_limit
