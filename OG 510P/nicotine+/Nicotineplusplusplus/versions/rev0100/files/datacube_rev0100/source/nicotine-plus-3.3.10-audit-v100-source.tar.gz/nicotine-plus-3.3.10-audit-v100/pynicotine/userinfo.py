# COPYRIGHT (C) 2021-2024 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os
import stat
import struct
import time

from collections import deque

from pynicotine.config import config
from pynicotine.core import core
from pynicotine.events import events
from pynicotine.logfacility import log
from pynicotine.shares import PermissionLevel
from pynicotine.slskmessages import CloseConnection
from pynicotine.slskmessages import SlskMessage
from pynicotine.slskmessages import USER_INFO_USERS_ALLOWED
from pynicotine.slskmessages import USER_INTERESTS_USERS_ALLOWED
from pynicotine.slskmessages import UserInfoRequest
from pynicotine.slskmessages import UserInfoResponse
from pynicotine.slskmessages import UserInterests
from pynicotine.utils import encode_path
from pynicotine.utils import unescape
from pynicotine.watchbatch import WatchUserBatcher


MAX_PROFILE_PICTURE_WIDTH = 8192
MAX_PROFILE_PICTURE_HEIGHT = 8192
MAX_PROFILE_PICTURE_PIXELS = 40_000_000
MAX_PROFILE_PICTURE_HEADER_SCAN_SIZE = 262144


def _unpack_u24_le(data, offset):
    return data[offset] | (data[offset + 1] << 8) | (data[offset + 2] << 16)


def get_profile_picture_dimensions(data):
    """Return (width, height) for supported image headers, or (None, None)."""

    if len(data) >= 24 and data.startswith(b"\x89PNG\r\n\x1a\n") and data[12:16] == b"IHDR":
        return struct.unpack(">II", data[16:24])

    if len(data) >= 10 and data[:6] in {b"GIF87a", b"GIF89a"}:
        return struct.unpack("<HH", data[6:10])

    if len(data) >= 26 and data.startswith(b"BM"):
        dib_header_size = struct.unpack("<I", data[14:18])[0]

        if dib_header_size >= 40 and len(data) >= 26:
            width, height = struct.unpack("<ii", data[18:26])
            return abs(width), abs(height)

    if len(data) >= 30 and data[:4] == b"RIFF" and data[8:12] == b"WEBP" and data[12:16] == b"VP8X":
        # VP8X stores canvas dimensions as 24-bit little-endian values minus one.
        return _unpack_u24_le(data, 24) + 1, _unpack_u24_le(data, 27) + 1

    if len(data) >= 4 and data[:2] == b"\xff\xd8":
        pos = 2
        data_len = min(len(data), MAX_PROFILE_PICTURE_HEADER_SCAN_SIZE)

        while pos + 1 < data_len:
            if data[pos] != 0xFF:
                pos += 1
                continue

            while pos < data_len and data[pos] == 0xFF:
                pos += 1

            if pos >= data_len:
                break

            marker = data[pos]
            pos += 1

            if marker in {0xD8, 0xD9} or 0xD0 <= marker <= 0xD7:
                continue

            if pos + 2 > data_len:
                break

            segment_size = struct.unpack(">H", data[pos:pos + 2])[0]

            if segment_size < 2:
                break

            segment_start = pos + 2

            if marker in {
                0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF
            } and segment_start + 5 <= data_len:
                height, width = struct.unpack(">HH", data[segment_start + 1:segment_start + 5])
                return width, height

            pos += segment_size

    return None, None


def validate_profile_picture(data):
    """Reject profile pictures that are small on the wire but huge when decoded."""

    if not data:
        return

    if len(data) > UserInfoResponse.MAX_PICTURE_SIZE:
        raise ValueError("picture exceeds maximum size")

    width, height = get_profile_picture_dimensions(data)

    if width is None or height is None:
        return

    if width <= 0 or height <= 0:
        raise ValueError("picture has invalid dimensions")

    if (width > MAX_PROFILE_PICTURE_WIDTH
            or height > MAX_PROFILE_PICTURE_HEIGHT
            or width * height > MAX_PROFILE_PICTURE_PIXELS):
        raise ValueError("picture dimensions exceed maximum size")


class UserInfo:
    __slots__ = ("users", "requested_info_times", "requested_info_address_times",
                 "_users_limit_logged", "_profile_picture_cache_key", "_profile_picture_cache_data",
                 "_server_login_watch_batcher", "_user_request_retry_queue",
                 "_user_request_retry_keys", "_user_request_retry_timer_id",
                 "_user_request_retry_limit_logged")

    INFO_REQUEST_INTERVAL = 0.4
    INFO_REQUEST_TIMES_RETENTION = 60
    MAX_INFO_REQUEST_TIMES = 4096
    MAX_INFO_REQUEST_ADDRESS_TIMES = 4096
    MAX_INFO_REQUESTS_PER_ADDRESS = 64
    MAX_USER_INFO_USERS = 4096
    MAX_SERVER_LOGIN_WATCHES_PER_TICK = 1000
    MAX_PENDING_SERVER_LOGIN_WATCHES = 65536
    MAX_PENDING_USER_REQUEST_RETRIES = 4096
    MAX_USER_REQUEST_RETRIES_PER_TICK = 128
    USER_REQUEST_RETRY_DELAY = 1

    def __init__(self):

        self.users = set()
        self.requested_info_times = {}
        self.requested_info_address_times = {}
        self._users_limit_logged = False
        self._profile_picture_cache_key = None
        self._profile_picture_cache_data = None
        self._server_login_watch_batcher = WatchUserBatcher(
            "userinfo", lambda username: username in self.users,
            lambda: self.MAX_SERVER_LOGIN_WATCHES_PER_TICK,
            lambda: self.MAX_PENDING_SERVER_LOGIN_WATCHES
        )
        self._user_request_retry_queue = deque()
        self._user_request_retry_keys = set()
        self._user_request_retry_timer_id = None
        self._user_request_retry_limit_logged = False

        for event_name, callback in (
            ("quit", self._quit),
            ("server-login", self._server_login),
            ("server-disconnect", self._server_disconnect),
            ("peer-request-unsent", self._peer_request_unsent),
            ("peer-response-delivery-failed", self._peer_response_delivery_failed),
            ("peer-response-unsent", self._peer_response_unsent),
            ("server-message-unsent", self._server_message_unsent),
            ("server-response-delivery-failed", self._server_response_delivery_failed),
            ("user-info-progress", self._user_info_progress),
            ("user-interests", self._user_interests),
            ("user-info-request", self._user_info_request)
        ):
            events.connect(event_name, callback)

    def _quit(self):
        self._server_login_watch_batcher.cancel()
        self._clear_user_request_retries()
        USER_INFO_USERS_ALLOWED.clear()
        USER_INTERESTS_USERS_ALLOWED.clear()
        self.remove_all_users()

    def _server_login(self, msg):

        if not msg.success:
            return

        self._server_login_watch_batcher.queue(self.users)

    def _server_disconnect(self, _msg):
        self._server_login_watch_batcher.cancel()
        self._clear_user_request_retries()
        self.requested_info_times.clear()
        self.requested_info_address_times.clear()
        USER_INFO_USERS_ALLOWED.clear()
        USER_INTERESTS_USERS_ALLOWED.clear()

    def _clear_user_request_retries(self):
        if self._user_request_retry_timer_id is not None:
            events.cancel_scheduled(self._user_request_retry_timer_id)
            self._user_request_retry_timer_id = None

        self._user_request_retry_queue.clear()
        self._user_request_retry_keys.clear()
        self._user_request_retry_limit_logged = False

    def _queue_user_request_retry(self, username, msg_class):
        if not username or msg_class not in {UserInfoRequest, UserInterests}:
            return False

        key = (username, msg_class)

        if key in self._user_request_retry_keys:
            return True

        if len(self._user_request_retry_queue) >= self.MAX_PENDING_USER_REQUEST_RETRIES:
            if not self._user_request_retry_limit_logged:
                log.add_debug(
                    "User Info request retry queue reached %s items; discarding additional retries",
                    self.MAX_PENDING_USER_REQUEST_RETRIES
                )
                self._user_request_retry_limit_logged = True

            return False

        self._user_request_retry_keys.add(key)
        self._user_request_retry_queue.append(key)
        self._schedule_user_request_retries(delay=self.USER_REQUEST_RETRY_DELAY)
        return True

    def _schedule_user_request_retries(self, delay=0):
        if self._user_request_retry_timer_id is not None:
            return

        self._user_request_retry_timer_id = events.schedule(
            delay=delay, callback=self._process_user_request_retries)

        if self._user_request_retry_timer_id is None:
            self._clear_user_request_retries()

    def _is_user_request_retry_stale(self, username, _msg_class):
        return username not in self.users

    def _send_user_interests_request(self, username):
        if core.send_message_to_server(UserInterests(username)) is False:
            self._queue_user_request_retry(username, UserInterests)
            return False

        USER_INTERESTS_USERS_ALLOWED.add(username)
        return True

    def _send_user_info_request(self, username):
        if core.send_message_to_peer(username, UserInfoRequest()) is False:
            self._queue_user_request_retry(username, UserInfoRequest)
            return False

        USER_INFO_USERS_ALLOWED.add(username)
        return True

    def _process_user_request_retries(self):
        self._user_request_retry_timer_id = None
        num_processed = 0

        while (self._user_request_retry_queue
                and num_processed < self.MAX_USER_REQUEST_RETRIES_PER_TICK):
            username, msg_class = self._user_request_retry_queue.popleft()
            self._user_request_retry_keys.discard((username, msg_class))
            num_processed += 1

            if self._is_user_request_retry_stale(username, msg_class):
                continue

            if msg_class is UserInterests:
                if not self._send_user_interests_request(username):
                    break

            elif msg_class is UserInfoRequest:
                if not self._send_user_info_request(username):
                    break

        if self._user_request_retry_queue:
            self._schedule_user_request_retries(delay=self.USER_REQUEST_RETRY_DELAY)
        else:
            self._user_request_retry_limit_logged = False

    def _peer_request_unsent(self, msg_class, username, _msg):
        if msg_class is not UserInfoRequest:
            return

        USER_INFO_USERS_ALLOWED.discard(username)
        self._queue_user_request_retry(username, UserInfoRequest)

    def _peer_response_delivery_failed(self, msg_class, username, rollback_info):
        if msg_class is not UserInfoResponse:
            return

        if rollback_info != ("user-info-response",):
            return

        USER_INFO_USERS_ALLOWED.discard(username)
        self._queue_user_request_retry(username, UserInfoRequest)

    def _server_message_unsent(self, msg):
        if msg.__class__ is not UserInterests:
            return

        USER_INTERESTS_USERS_ALLOWED.discard(msg.user)
        self._queue_user_request_retry(msg.user, UserInterests)

    def _server_response_delivery_failed(self, msg_class, rollback_info):
        if msg_class is not UserInterests or not rollback_info:
            return

        rollback_kind, username = rollback_info

        if rollback_kind != "user-interests":
            return

        USER_INTERESTS_USERS_ALLOWED.discard(username)
        self._queue_user_request_retry(username, UserInterests)

    def _peer_response_unsent(self, msg_class, _username, rollback_info):
        """Undo user-info request limiter state when a queued response dies below peer output."""

        if msg_class is not UserInfoResponse or not rollback_info:
            return

        rollback_kind, request_marker = rollback_info

        if rollback_kind == "user-info-request":
            self._rollback_user_info_request(request_marker)

    @staticmethod
    def _get_profile_picture_path():
        return os.path.expandvars(config.sections.get("userinfo", {}).get("pic", ""))

    @classmethod
    def _get_profile_picture_cache_key(cls):
        picture_path = cls._get_profile_picture_path()

        if not picture_path:
            return None

        picture_path_encoded = encode_path(picture_path)
        file_stat = os.lstat(picture_path_encoded)

        if not stat.S_ISREG(file_stat.st_mode):
            raise OSError("picture is not a regular file")

        if file_stat.st_size > UserInfoResponse.MAX_PICTURE_SIZE:
            raise OSError("picture exceeds maximum size")

        return (
            os.path.normpath(picture_path),
            file_stat.st_dev,
            file_stat.st_ino,
            file_stat.st_mtime_ns,
            file_stat.st_size
        )

    @staticmethod
    def _read_profile_picture():
        """Read the configured profile picture without blocking on special files."""

        picture_path = UserInfo._get_profile_picture_path()

        if not picture_path:
            return None

        picture_path_encoded = encode_path(picture_path)
        file_stat = os.lstat(picture_path_encoded)

        if not stat.S_ISREG(file_stat.st_mode):
            raise OSError("picture is not a regular file")

        if file_stat.st_size > UserInfoResponse.MAX_PICTURE_SIZE:
            raise OSError("picture exceeds maximum size")

        flags = os.O_RDONLY

        if hasattr(os, "O_BINARY"):
            flags |= os.O_BINARY

        if hasattr(os, "O_NOFOLLOW"):
            flags |= os.O_NOFOLLOW

        fd = os.open(picture_path_encoded, flags)

        try:
            opened_stat = os.fstat(fd)

            if not stat.S_ISREG(opened_stat.st_mode):
                raise OSError("picture is not a regular file")

            if (opened_stat.st_dev, opened_stat.st_ino) != (file_stat.st_dev, file_stat.st_ino):
                raise OSError("picture changed while opening")

            if opened_stat.st_size > UserInfoResponse.MAX_PICTURE_SIZE:
                raise OSError("picture exceeds maximum size")

            with os.fdopen(fd, "rb") as file_handle:
                fd = None
                pic = file_handle.read(UserInfoResponse.MAX_PICTURE_SIZE + 1)

        finally:
            if fd is not None:
                os.close(fd)

        if len(pic) > UserInfoResponse.MAX_PICTURE_SIZE:
            raise OSError("picture exceeds maximum size")

        return pic

    def _get_cached_profile_picture(self):
        """Return the configured profile picture, avoiding repeated disk reads.

        Profile info requests can arrive from many peers. The picture is static
        most of the time, so cache it by path/inode/mtime/size and only re-read
        it when the configured file changes.
        """

        cache_key = self._get_profile_picture_cache_key()

        if cache_key is None:
            self._profile_picture_cache_key = None
            self._profile_picture_cache_data = None
            return None

        if cache_key == self._profile_picture_cache_key:
            return self._profile_picture_cache_data

        picture = self._read_profile_picture()
        self._profile_picture_cache_key = cache_key
        self._profile_picture_cache_data = picture
        return picture

    def _prune_info_request_times(self, request_time):
        min_request_time = request_time - self.INFO_REQUEST_TIMES_RETENTION
        self.requested_info_times = {
            current_username: current_request_time
            for current_username, current_request_time in self.requested_info_times.items()
            if current_request_time >= min_request_time
        }

    def _prune_info_address_request_times(self, request_time):
        min_request_time = request_time - self.INFO_REQUEST_TIMES_RETENTION

        for ip_address, address_request_times in tuple(self.requested_info_address_times.items()):
            while address_request_times and address_request_times[0] < min_request_time:
                address_request_times.popleft()

            if not address_request_times:
                self.requested_info_address_times.pop(ip_address, None)

    def _allow_info_address_request(self, ip_address, request_time):
        if not ip_address:
            return True

        address_request_times = self.requested_info_address_times.get(ip_address)
        min_request_time = request_time - self.INFO_REQUEST_TIMES_RETENTION

        if address_request_times is None:
            if len(self.requested_info_address_times) >= self.MAX_INFO_REQUEST_ADDRESS_TIMES:
                self._prune_info_address_request_times(request_time)

                if len(self.requested_info_address_times) >= self.MAX_INFO_REQUEST_ADDRESS_TIMES:
                    return False

            address_request_times = deque()
            self.requested_info_address_times[ip_address] = address_request_times
        else:
            while address_request_times and address_request_times[0] < min_request_time:
                address_request_times.popleft()

        if len(address_request_times) >= self.MAX_INFO_REQUESTS_PER_ADDRESS:
            return False

        address_request_times.append(request_time)
        return True

    def _rollback_info_address_request(self, ip_address, request_time):

        if not ip_address:
            return

        address_request_times = self.requested_info_address_times.get(ip_address)

        if not address_request_times:
            return

        try:
            address_request_times.remove(request_time)

        except ValueError:
            return

        if not address_request_times:
            self.requested_info_address_times.pop(ip_address, None)

    def _record_user_info_request(self, username, ip_address=None):
        request_time = time.monotonic()
        last_request_time = self.requested_info_times.get(username)

        if (last_request_time is not None
                and request_time < last_request_time + self.INFO_REQUEST_INTERVAL):
            return None

        if username not in self.requested_info_times and len(self.requested_info_times) >= self.MAX_INFO_REQUEST_TIMES:
            self._prune_info_request_times(request_time)

            if len(self.requested_info_times) >= self.MAX_INFO_REQUEST_TIMES:
                return None

        if not self._allow_info_address_request(ip_address, request_time):
            return None

        self.requested_info_times[username] = request_time
        return username, ip_address, request_time, last_request_time

    def _is_user_info_request_limited(self, username, ip_address=None):
        return self._record_user_info_request(username, ip_address) is None

    def _rollback_user_info_request(self, marker):

        if marker is None:
            return

        username, ip_address, request_time, previous_time = marker

        if self.requested_info_times.get(username) == request_time:
            if previous_time is None:
                self.requested_info_times.pop(username, None)
            else:
                self.requested_info_times[username] = previous_time

        self._rollback_info_address_request(ip_address, request_time)

    def _get_user_info_response(self, requesting_username=None, requesting_ip_address=None):

        if requesting_username is not None and requesting_ip_address is not None:
            permission_level, reject_reason = core.shares.check_user_permission(
                requesting_username, requesting_ip_address)
        else:
            permission_level = PermissionLevel.PUBLIC
            reject_reason = None

        if permission_level == PermissionLevel.BANNED:
            # Hide most details from banned users
            pic = None
            descr = ""
            totalupl = queuesize = uploadallowed = 0
            slotsavail = False

            if reject_reason:
                descr = f"You are not allowed to download my shared files.\nReason: {reject_reason}"
        else:
            try:
                pic = self._get_cached_profile_picture()

            except Exception:
                pic = None

            descr = unescape(config.sections["userinfo"]["descr"])

            totalupl = core.uploads.get_total_uploads_allowed()
            queuesize = core.uploads.get_upload_queue_size(requesting_username)
            slotsavail = core.uploads.is_new_upload_accepted()

            if config.sections["transfers"]["remotedownloads"]:
                uploadallowed = config.sections["transfers"]["uploadallowed"]
            else:
                uploadallowed = 0

        msg = UserInfoResponse(
            descr=descr, pic=pic, totalupl=totalupl, queuesize=queuesize, slotsavail=slotsavail,
            uploadallowed=uploadallowed
        )
        msg.username = core.users.login_username or config.sections["server"]["login"]
        return msg

    @staticmethod
    def _user_interests(msg):
        """Server code 57."""

        # The network parser request-gates server UserInterests responses before
        # list parsing/UI fanout. Discard a leftover grant for direct unit paths
        # or older callers, but don't reject a legitimate response whose one-shot
        # grant was already consumed by the parser.
        USER_INTERESTS_USERS_ALLOWED.discard(msg.user)

    def show_user(self, username=None, refresh=False, switch_page=True):

        local_username = core.users.login_username or config.sections["server"]["login"]

        if not username:
            username = local_username

            if not username:
                core.setup()
                return

        if not isinstance(username, str):
            return

        if len(username.encode("utf-8", "replace")) > SlskMessage.MAX_USERNAME_FIELD_BYTES:
            log.add_debug("Ignoring user info request for username exceeding %s bytes",
                          SlskMessage.MAX_USERNAME_FIELD_BYTES)
            return

        if username not in self.users:
            if len(self.users) >= self.MAX_USER_INFO_USERS:
                if not self._users_limit_logged:
                    log.add_debug(
                        "User Info retained-user limit of %s users reached; ignoring additional users",
                        self.MAX_USER_INFO_USERS
                    )
                    self._users_limit_logged = True

                return

            self.users.add(username)
            refresh = True

        events.emit("user-info-show-user", user=username, refresh=refresh, switch_page=switch_page)

        if not refresh:
            return

        # Request user status, speed and number of shared files
        core.users.watch_user(username, context="userinfo")

        # Request user interests
        self._send_user_interests_request(username)

        if username == local_username:
            msg = self._get_user_info_response()
            events.emit("user-info-response", msg)
        else:
            # Request user description, picture and queue information
            self._send_user_info_request(username)

    def remove_user(self, username):

        USER_INFO_USERS_ALLOWED.discard(username)
        USER_INTERESTS_USERS_ALLOWED.discard(username)
        self.users.remove(username)
        if core.users is not None:
            core.users.unwatch_user(username, context="userinfo")
        events.emit("user-info-remove-user", username)

    def remove_all_users(self):
        for username in self.users.copy():
            self.remove_user(username)

    @staticmethod
    def save_user_picture(file_path, picture_bytes):

        try:
            with open(encode_path(file_path), "wb") as file_handle:
                file_handle.write(picture_bytes)

            log.add(_("Picture saved to %s"), file_path)

        except Exception as error:
            log.add(_("Cannot save picture to %(filename)s: %(error)s"), {
                "filename": file_path,
                "error": error
            })

    def _user_info_progress(self, username, sock, _buffer_len, _msg_size_total):

        if username not in self.users:
            # We've removed the user. Close the connection to stop the user from
            # sending their response and wasting bandwidth.
            core.send_message_to_network_thread(CloseConnection(sock))

    def _user_info_request(self, msg):
        """Peer code 15."""

        username = msg.username
        ip_address, _port = msg.addr
        request_marker = self._record_user_info_request(username, ip_address)

        if request_marker is None:
            # Ignoring request, because it's less than half a second since the
            # last one by this user, or because the tracking table is full of
            # recent requesters.
            return

        msg = self._get_user_info_response(username, ip_address)
        msg.unsent_rollback_info = ("user-info-request", request_marker)

        if core.send_message_to_peer(username, msg) is False:
            self._rollback_user_info_request(request_marker)
            log.add_debug(
                "Discarding user info request from %s; peer output queue rejected the response",
                username
            )
            return

        log.add(_("User %(user)s is viewing your profile"), {"user": username})
