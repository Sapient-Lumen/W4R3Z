# COPYRIGHT (C) 2020-2023 Nicotine+ Contributors
# COPYRIGHT (C) 2009 daelstorm <daelstorm@gmail.com>
# COPYRIGHT (C) 2008 quinox <quinox@users.sf.net>
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from itertools import islice

from pynicotine.pluginsystem import BasePlugin
from pynicotine.pluginsystem import returncode


class Plugin(BasePlugin):

    MAX_PASTE_CHARS = 64 * 1024
    MAX_PASTE_LINES = 1000

    @classmethod
    def _iter_nonempty_lines(cls, line, max_lines):
        """Yield a bounded nonempty-line prefix without trusting plugin settings."""

        try:
            max_lines = int(max_lines)
        except (TypeError, ValueError):
            max_lines = 0

        max_lines = max(0, min(max_lines, cls.MAX_PASTE_LINES))

        if max_lines <= 0:
            return iter(())

        line = str(line)[:cls.MAX_PASTE_CHARS]
        return islice((part for part in line.splitlines() if part), max_lines)

    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)

        self.settings = {
            "maxpubliclines": 4,
            "maxprivatelines": 8
        }
        self.metasettings = {
            "maxpubliclines": {
                "description": "The maximum number of lines that will be pasted in public",
                "type": "int"
            },
            "maxprivatelines": {
                "description": "The maximum number of lines that will be pasted in private",
                "type": "int"
            }
        }

    def outgoing_private_chat_event(self, user, line):

        lines = list(self._iter_nonempty_lines(line, self.settings.get("maxprivatelines", 0)))

        if len(lines) > 1:
            if len(str(line)) > self.MAX_PASTE_CHARS or str(line).count("\n") + 1 > len(lines):
                self.log("Posting at most %s lines from a bounded multi-line private message.", len(lines))
            else:
                self.log("Splitting lines.")

            for split_line in lines:
                self.send_private(user, split_line)

            return returncode["zap"]

        return None

    def outgoing_public_chat_event(self, room, line):

        lines = list(self._iter_nonempty_lines(line, self.settings.get("maxpubliclines", 0)))

        if len(lines) > 1:
            if len(str(line)) > self.MAX_PASTE_CHARS or str(line).count("\n") + 1 > len(lines):
                self.log("Posting at most %s lines from a bounded multi-line public message.", len(lines))
            else:
                self.log("Splitting lines.")

            for split_line in lines:
                self.send_public(room, split_line)

            return returncode["zap"]

        return None
