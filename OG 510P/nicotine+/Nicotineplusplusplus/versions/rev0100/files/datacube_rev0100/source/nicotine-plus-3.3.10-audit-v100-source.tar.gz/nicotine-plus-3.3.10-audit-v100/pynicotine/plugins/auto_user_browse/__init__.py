# COPYRIGHT (C) 2021-2024 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from collections import deque

from pynicotine.events import events
from pynicotine.logfacility import log
from pynicotine.pluginsystem import BasePlugin
from pynicotine.slskmessages import UserStatus


class Plugin(BasePlugin):

    AUTO_BROWSE_DELAY = 30
    MAX_PROCESSED_USERS = 16384
    MAX_PENDING_BROWSE_USERS = 1024
    MAX_BROWSE_USERS_PER_TICK = 25

    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)

        self.settings = {
            "users": []
        }
        self.metasettings = {
            "users": {
                "description": "Username",
                "type": "list string"
            }
        }
        self.processed_users = set()
        self.pending_browse_users = deque()
        self.pending_browse_usernames = set()
        self.browse_timer_id = None
        self.limit_logged = False

    def _clear_state(self):
        events.cancel_scheduled(self.browse_timer_id)
        self.browse_timer_id = None
        self.processed_users.clear()
        self.pending_browse_users.clear()
        self.pending_browse_usernames.clear()
        self.limit_logged = False

    def _schedule_browse(self, delay=None):
        if self.browse_timer_id is not None or not self.pending_browse_users:
            return

        self.browse_timer_id = events.schedule(
            delay=self.AUTO_BROWSE_DELAY if delay is None else delay,
            callback=self._process_browse_queue
        )

        if self.browse_timer_id is None:
            # Scheduler capacity is saturated. Release our retained queue instead
            # of turning the plugin into a long-lived memory sink.
            self.pending_browse_users.clear()
            self.pending_browse_usernames.clear()

    def _queue_browse_user(self, user):
        if user in self.pending_browse_usernames:
            return

        if len(self.pending_browse_users) >= self.MAX_PENDING_BROWSE_USERS:
            if not self.limit_logged:
                log.add_debug(
                    "Auto User Browse pending-user limit of %s reached; ignoring additional users",
                    self.MAX_PENDING_BROWSE_USERS
                )
                self.limit_logged = True
            self.processed_users.discard(user)
            return

        self.pending_browse_users.append(user)
        self.pending_browse_usernames.add(user)
        self._schedule_browse()

    def _process_browse_queue(self):
        self.browse_timer_id = None
        num_processed = 0

        while self.pending_browse_users and num_processed < self.MAX_BROWSE_USERS_PER_TICK:
            user = self.pending_browse_users.popleft()
            self.pending_browse_usernames.discard(user)
            num_processed += 1

            if user not in self.processed_users:
                continue

            if self.core.users.statuses.get(user) == UserStatus.OFFLINE:
                self.processed_users.discard(user)
                continue

            self.core.userbrowse.browse_user(user, switch_page=False)

        if self.pending_browse_users:
            self._schedule_browse(delay=0)
        else:
            self.limit_logged = False

    def browse_user(self, user):
        if user in self.processed_users:
            self.core.userbrowse.browse_user(user, switch_page=False)

    def disable(self):
        self._clear_state()

    def user_status_notification(self, user, status, _privileged):

        if status == UserStatus.OFFLINE:
            self.processed_users.discard(user)
            self.pending_browse_usernames.discard(user)
            return

        if user not in self.settings["users"]:
            return

        if user in self.processed_users:
            return

        if len(self.processed_users) >= self.MAX_PROCESSED_USERS:
            if not self.limit_logged:
                log.add_debug(
                    "Auto User Browse processed-user limit of %s reached; ignoring additional users",
                    self.MAX_PROCESSED_USERS
                )
                self.limit_logged = True
            return

        # Wait before browsing shares to ensure they are ready and the server
        # doesn't send an invalid port for the user. Use one batched timer instead
        # of one scheduled callback per status notification.
        self.processed_users.add(user)
        self._queue_browse_user(user)

    def server_disconnect_notification(self, userchoice):
        self._clear_state()
