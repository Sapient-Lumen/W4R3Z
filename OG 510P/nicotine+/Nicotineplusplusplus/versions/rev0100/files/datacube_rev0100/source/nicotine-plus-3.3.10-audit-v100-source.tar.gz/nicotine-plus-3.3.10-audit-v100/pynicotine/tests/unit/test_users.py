# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007

from collections import deque
from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock
from unittest.mock import patch

import pynicotine.users as users_module
from pynicotine.core import core
from pynicotine.slskmessages import ChangePassword
from pynicotine.slskmessages import CheckPrivileges
from pynicotine.slskmessages import CheckPrivileges
from pynicotine.slskmessages import GetPeerAddress
from pynicotine.slskmessages import GetUserStats
from pynicotine.slskmessages import GetUserStatus
from pynicotine.slskmessages import GivePrivileges
from pynicotine.slskmessages import SlskMessage
from pynicotine.slskmessages import SetStatus
from pynicotine.slskmessages import UnwatchUser
from pynicotine.slskmessages import UserStatus
from pynicotine.slskmessages import WatchUser
from pynicotine.users import Users
from pynicotine.users import WatchedUser


class patch_users_core:

    def __init__(self, new_core):
        self.new_core = new_core
        self.old_core = None

    def __enter__(self):
        self.old_core = users_module.core
        users_module.core = self.new_core

    def __exit__(self, *_args):
        users_module.core = self.old_core


class patch_users_events:

    def __init__(self, new_events):
        self.new_events = new_events
        self.old_events = None

    def __enter__(self):
        self.old_events = users_module.events
        users_module.events = self.new_events

    def __exit__(self, *_args):
        users_module.events = self.old_events


class UsersTest(TestCase):



    def test_unsent_watch_user_retries_lower_output_failure(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        watched_user = WatchedUser("peer")
        watched_user.contexts = {"search"}
        watched_user.is_implicit = False
        users.watched = {"peer": watched_user}
        users._server_user_request_retries = deque()
        users._server_user_request_retry_keys = set()
        users._server_user_request_retry_timer_id = None
        users._server_user_request_retry_limit_logged = False
        scheduled_callbacks = []
        sent_messages = []
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append(callback) or 123),
            cancel_scheduled=Mock()
        )

        with patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)), \
                patch_users_events(fake_events):
            users._server_message_unsent(WatchUser("peer"))
            self.assertEqual(1, len(scheduled_callbacks))
            scheduled_callbacks.pop(0)()

        self.assertEqual([WatchUser, GetUserStatus], [message.__class__ for message in sent_messages])
        self.assertFalse(users._server_user_request_retries)

    def test_unsent_unwatch_user_retries_after_local_state_removed(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        users.watched = {}
        users._server_user_request_retries = deque()
        users._server_user_request_retry_keys = set()
        users._server_user_request_retry_timer_id = None
        users._server_user_request_retry_limit_logged = False
        scheduled_callbacks = []
        sent_messages = []
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append(callback) or 456),
            cancel_scheduled=Mock()
        )

        with patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)), \
                patch_users_events(fake_events):
            users._server_message_unsent(UnwatchUser("peer"))
            scheduled_callbacks.pop(0)()

        self.assertEqual([UnwatchUser], [message.__class__ for message in sent_messages])

    def test_unsent_unwatch_user_skip_if_user_was_rewatched(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        watched_user = WatchedUser("peer")
        watched_user.contexts = {"privatechat"}
        watched_user.is_implicit = False
        users.watched = {"peer": watched_user}
        users._server_user_request_retries = deque()
        users._server_user_request_retry_keys = set()
        users._server_user_request_retry_timer_id = None
        users._server_user_request_retry_limit_logged = False
        scheduled_callbacks = []
        fake_core = SimpleNamespace(send_message_to_server=Mock())
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append(callback) or 789),
            cancel_scheduled=Mock()
        )

        with patch_users_core(fake_core), patch_users_events(fake_events):
            users._server_message_unsent(UnwatchUser("peer"))
            scheduled_callbacks.pop(0)()

        fake_core.send_message_to_server.assert_not_called()

    def test_unsent_peer_address_request_clears_pending_ledger(self):
        users = object.__new__(Users)
        users._ip_requested = {"peer": True}
        users._ip_request_times = {"peer": 123.0}

        users._server_message_unsent(GetPeerAddress("peer"))

        self.assertNotIn("peer", users._ip_requested)
        self.assertNotIn("peer", users._ip_request_times)

    def test_unsent_user_stats_request_clears_pending_ledger(self):
        users = object.__new__(Users)
        users._stats_requested = {"peer": 123.0}

        users._server_message_unsent(GetUserStats("peer"))

        self.assertNotIn("peer", users._stats_requested)

    def test_unsent_password_and_privilege_requests_clear_pending_ledgers(self):
        users = object.__new__(Users)
        users._pending_password_changes = {"secret"}
        users._pending_privilege_checks = 1
        users._should_open_privileges_url = True

        users._server_message_unsent(ChangePassword("secret"))
        users._server_message_unsent(CheckPrivileges())

        self.assertFalse(users._pending_password_changes)
        self.assertEqual(0, users._pending_privilege_checks)
        self.assertFalse(users._should_open_privileges_url)


    def test_unsent_privilege_gift_is_retried(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        users._pending_privilege_gifts = deque()
        users._privilege_gift_timer_id = None
        users._privilege_gift_limit_logged = False

        fake_events = SimpleNamespace(schedule=Mock(return_value=321))

        with patch_users_events(fake_events):
            users._server_message_unsent(GivePrivileges("friend", 7))

        self.assertEqual([("friend", 7)], list(users._pending_privilege_gifts))
        self.assertEqual(321, users._privilege_gift_timer_id)
        fake_events.schedule.assert_called_once()

    def test_privilege_gift_retries_after_public_queue_rejection(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        users._pending_privilege_gifts = deque()
        users._privilege_gift_timer_id = None
        users._privilege_gift_limit_logged = False

        fake_core = SimpleNamespace(send_message_to_server=Mock(return_value=False))
        fake_events = SimpleNamespace(schedule=Mock(return_value=654))

        with patch_users_core(fake_core), patch_users_events(fake_events):
            self.assertTrue(users.request_give_privileges("friend", 3))

        self.assertEqual([("friend", 3)], list(users._pending_privilege_gifts))
        fake_core.send_message_to_server.assert_called_once()
        fake_events.schedule.assert_called_once()

    def test_unknown_server_status_is_normalized_before_storage(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        users.login_username = "me"
        users.addresses = {}
        users.countries = {}
        users.statuses = {}
        users.watched = {"peer": WatchedUser("peer")}
        users.privileged = set()
        users._ip_requested = {}
        users._ip_requested_limit_logged = False
        users._pending_watch_removals = set()

        notifications = []

        class DummyPluginHandler:
            enabled_plugins = set()

            @staticmethod
            def user_status_notification(username, status, privileged):
                notifications.append((username, status, privileged))

        old_pluginhandler = core.pluginhandler
        core.pluginhandler = DummyPluginHandler()

        try:
            msg = SimpleNamespace(user="peer", status=99, privileged=None)
            users._user_status(msg)

        finally:
            core.pluginhandler = old_pluginhandler

        self.assertEqual(UserStatus.OFFLINE, msg.status)
        self.assertEqual(UserStatus.OFFLINE, users.statuses["peer"])
        self.assertEqual([("peer", UserStatus.OFFLINE, None)], notifications)


    def test_watch_user_caps_new_users(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        users.login_username = "me"
        users.watched = {"existing": WatchedUser("existing")}
        users._watched_users_limit_logged = False

        sent_messages = []
        old_limit = Users.MAX_WATCHED_USERS

        try:
            Users.MAX_WATCHED_USERS = 1
            with patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)):
                self.assertFalse(users.watch_user("new", context="test"))

        finally:
            Users.MAX_WATCHED_USERS = old_limit

        self.assertEqual(["existing"], list(users.watched))
        self.assertEqual([], sent_messages)
        self.assertTrue(users._watched_users_limit_logged)

    def test_watch_user_allows_existing_user_at_cap(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        users.login_username = "me"
        users.watched = {"existing": WatchedUser("existing")}
        users._watched_users_limit_logged = False

        old_limit = Users.MAX_WATCHED_USERS

        try:
            Users.MAX_WATCHED_USERS = 1
            self.assertTrue(users.watch_user("existing", context="test", is_implicit=True))

        finally:
            Users.MAX_WATCHED_USERS = old_limit

        self.assertEqual({"test"}, users.watched["existing"].contexts)
        self.assertFalse(users._watched_users_limit_logged)

    def test_watch_user_caps_implicit_contexts_per_user(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        users.login_username = "me"
        watched_user = WatchedUser("peer")
        watched_user.contexts = {"chatrooms_old"}
        users.watched = {"peer": watched_user}
        users._watch_contexts_limit_logged = False

        old_limit = Users.MAX_WATCH_CONTEXTS_PER_USER

        try:
            Users.MAX_WATCH_CONTEXTS_PER_USER = 1
            self.assertFalse(users.watch_user("peer", context="chatrooms_new", is_implicit=True))

        finally:
            Users.MAX_WATCH_CONTEXTS_PER_USER = old_limit

        self.assertEqual({"chatrooms_old"}, watched_user.contexts)
        self.assertTrue(users._watch_contexts_limit_logged)

    def test_watch_user_allows_explicit_context_at_implicit_context_cap(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        users.login_username = "me"
        watched_user = WatchedUser("peer")
        watched_user.contexts = {"chatrooms_old"}
        watched_user.is_implicit = False
        users.watched = {"peer": watched_user}
        users._watch_contexts_limit_logged = False

        old_limit = Users.MAX_WATCH_CONTEXTS_PER_USER

        try:
            Users.MAX_WATCH_CONTEXTS_PER_USER = 1
            self.assertTrue(users.watch_user("peer", context="privatechat", is_implicit=False))

        finally:
            Users.MAX_WATCH_CONTEXTS_PER_USER = old_limit

        self.assertEqual({"chatrooms_old", "privatechat"}, watched_user.contexts)
        self.assertFalse(users._watch_contexts_limit_logged)

    def test_watch_user_allows_login_user_at_cap(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        users.login_username = "me"
        users.watched = {"existing": WatchedUser("existing")}
        users._watched_users_limit_logged = False

        sent_messages = []
        old_limit = Users.MAX_WATCHED_USERS

        try:
            Users.MAX_WATCHED_USERS = 1
            with patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)):
                self.assertTrue(users.watch_user("me", context="login"))

        finally:
            Users.MAX_WATCHED_USERS = old_limit

        self.assertIn("me", users.watched)
        self.assertFalse(users._watched_users_limit_logged)
        self.assertEqual(2, len(sent_messages))



    def test_set_away_mode_rejection_does_not_update_local_status_or_emit(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        users.login_username = "me"
        fake_config = SimpleNamespace(sections={"server": {"away": False}})
        fake_events = SimpleNamespace(emit=Mock())

        with patch_users_core(SimpleNamespace(send_message_to_server=Mock(return_value=False))), \
                patch_users_events(fake_events), patch.object(users_module, "config", fake_config):
            self.assertFalse(users.set_away_mode(True, save_state=True))

        self.assertEqual(UserStatus.ONLINE, users.login_status)
        self.assertFalse(fake_config.sections["server"]["away"])
        fake_events.emit.assert_not_called()

    def test_set_away_mode_accepts_before_updating_local_status(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        users.login_username = "me"
        sent_messages = []
        fake_config = SimpleNamespace(sections={"server": {"away": False}})
        fake_events = SimpleNamespace(emit=Mock())

        with patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)), \
                patch_users_events(fake_events), patch.object(users_module, "config", fake_config):
            self.assertTrue(users.set_away_mode(True, save_state=True))

        self.assertEqual(UserStatus.AWAY, users.login_status)
        self.assertTrue(fake_config.sections["server"]["away"])
        self.assertEqual(1, len(sent_messages))
        self.assertIsInstance(sent_messages[0], SetStatus)
        fake_events.emit.assert_called_once()


    def test_lower_unsent_set_status_is_retried_while_still_current(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.AWAY
        users._status_retry_msg = None
        users._status_retry_timer_id = None
        scheduled_callbacks = []
        fake_core = SimpleNamespace(send_message_to_server=Mock(side_effect=[False, True]))
        fake_events = SimpleNamespace(
            schedule=Mock(side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 1),
            cancel_scheduled=Mock()
        )

        with patch_users_core(fake_core), patch_users_events(fake_events):
            users._server_message_unsent(SetStatus(UserStatus.AWAY))

            self.assertIsNotNone(users._status_retry_msg)
            self.assertEqual(1, len(scheduled_callbacks))

            _delay, callback = scheduled_callbacks.pop(0)
            callback()
            self.assertIsNotNone(users._status_retry_msg)
            self.assertEqual(1, len(scheduled_callbacks))

            _delay, callback = scheduled_callbacks.pop(0)
            callback()

        self.assertIsNone(users._status_retry_msg)
        self.assertEqual(2, fake_core.send_message_to_server.call_count)
        self.assertTrue(all(
            isinstance(call.args[0], SetStatus) for call in fake_core.send_message_to_server.call_args_list
        ))

    def test_lower_unsent_set_status_skip_stale_status(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        users._status_retry_msg = None
        users._status_retry_timer_id = None
        fake_events = SimpleNamespace(schedule=Mock(), cancel_scheduled=Mock())

        with patch_users_events(fake_events):
            users._server_message_unsent(SetStatus(UserStatus.AWAY))

        self.assertIsNone(users._status_retry_msg)
        fake_events.schedule.assert_not_called()

    def test_unwatch_user_rejection_preserves_final_explicit_watch_context(self):
        users = object.__new__(Users)
        watched_user = WatchedUser("peer")
        watched_user.contexts = {"privatechat"}
        watched_user.is_implicit = False
        users.watched = {"peer": watched_user}
        users.addresses = {"peer": ("203.0.113.10", 2234)}
        users.countries = {"peer": "US"}
        users.statuses = {"peer": UserStatus.ONLINE}

        with patch_users_core(SimpleNamespace(send_message_to_server=Mock(return_value=False))):
            self.assertFalse(users.unwatch_user("peer", context="privatechat"))

        self.assertIn("peer", users.watched)
        self.assertEqual({"privatechat"}, users.watched["peer"].contexts)
        self.assertIn("peer", users.addresses)
        self.assertIn("peer", users.countries)
        self.assertIn("peer", users.statuses)

    def test_unwatch_user_acceptance_removes_final_explicit_watch_context(self):
        users = object.__new__(Users)
        watched_user = WatchedUser("peer")
        watched_user.contexts = {"privatechat"}
        watched_user.is_implicit = False
        users.watched = {"peer": watched_user}
        users.addresses = {"peer": ("203.0.113.10", 2234)}
        users.countries = {"peer": "US"}
        users.statuses = {"peer": UserStatus.ONLINE}
        sent_messages = []

        with patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)):
            self.assertTrue(users.unwatch_user("peer", context="privatechat"))

        self.assertNotIn("peer", users.watched)
        self.assertNotIn("peer", users.addresses)
        self.assertNotIn("peer", users.countries)
        self.assertNotIn("peer", users.statuses)
        self.assertEqual(1, len(sent_messages))
        self.assertIsInstance(sent_messages[0], UnwatchUser)

    def test_request_check_privileges_caps_pending_requests(self):
        users = object.__new__(Users)
        users._pending_privilege_checks = 1
        users._privilege_check_limit_logged = False
        users._should_open_privileges_url = False
        sent_messages = []
        old_limit = Users.MAX_PENDING_PRIVILEGE_CHECKS

        try:
            Users.MAX_PENDING_PRIVILEGE_CHECKS = 1
            with patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)):
                self.assertFalse(users.request_check_privileges(should_open_url=True))

        finally:
            Users.MAX_PENDING_PRIVILEGE_CHECKS = old_limit

        self.assertEqual(1, users._pending_privilege_checks)
        self.assertFalse(users._should_open_privileges_url)
        self.assertEqual([], sent_messages)
        self.assertTrue(users._privilege_check_limit_logged)

    def test_request_check_privileges_records_pending_request(self):
        users = object.__new__(Users)
        users._pending_privilege_checks = 0
        users._privilege_check_limit_logged = True
        users._should_open_privileges_url = False
        sent_messages = []

        with patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)):
            self.assertTrue(users.request_check_privileges(should_open_url=True))

        self.assertEqual(1, users._pending_privilege_checks)
        self.assertTrue(users._should_open_privileges_url)
        self.assertFalse(users._privilege_check_limit_logged)
        self.assertEqual(1, len(sent_messages))
        self.assertIsInstance(sent_messages[0], CheckPrivileges)

    def test_check_privileges_ignores_unsolicited_response(self):
        users = object.__new__(Users)
        users._pending_privilege_checks = 0
        users._should_open_privileges_url = True
        users.privileges_left = None
        msg = SimpleNamespace(seconds=3600)

        with patch.object(users, "open_privileges_url") as open_url:
            users._check_privileges(msg)

        self.assertIsNone(msg.seconds)
        self.assertIsNone(users.privileges_left)
        self.assertTrue(users._should_open_privileges_url)
        open_url.assert_not_called()

    def test_check_privileges_consumes_requested_response_once(self):
        users = object.__new__(Users)
        users._pending_privilege_checks = 1
        users._should_open_privileges_url = True
        users.privileges_left = None
        msg = SimpleNamespace(seconds=3600)

        with patch.object(users_module, "log", SimpleNamespace(add=Mock())):
            users._check_privileges(msg)

        self.assertEqual(0, users._pending_privilege_checks)
        self.assertEqual(3600, users.privileges_left)
        self.assertFalse(users._should_open_privileges_url)

        users._check_privileges(msg)
        self.assertIsNone(msg.seconds)
        self.assertEqual(3600, users.privileges_left)

    def test_request_change_password_caps_pending_requests(self):
        users = object.__new__(Users)
        users._pending_password_changes = {"existing"}
        users._password_change_limit_logged = False

        sent_messages = []
        old_limit = Users.MAX_PENDING_PASSWORD_CHANGES

        try:
            Users.MAX_PENDING_PASSWORD_CHANGES = 1

            with patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)):
                self.assertFalse(users.request_change_password("new-password"))

        finally:
            Users.MAX_PENDING_PASSWORD_CHANGES = old_limit

        self.assertEqual({"existing"}, users._pending_password_changes)
        self.assertEqual([], sent_messages)
        self.assertTrue(users._password_change_limit_logged)

    def test_request_change_password_records_request(self):
        users = object.__new__(Users)
        users._pending_password_changes = set()
        users._password_change_limit_logged = True
        sent_messages = []

        with patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)):
            self.assertTrue(users.request_change_password("new-password"))

        self.assertEqual({"new-password"}, users._pending_password_changes)
        self.assertFalse(users._password_change_limit_logged)
        self.assertEqual(1, len(sent_messages))
        self.assertIsInstance(sent_messages[0], ChangePassword)


    def test_request_change_password_truncates_before_retaining_request(self):
        users = object.__new__(Users)
        users._pending_password_changes = set()
        users._password_change_limit_logged = False
        sent_messages = []
        password = "é" * (SlskMessage.MAX_PASSWORD_FIELD_BYTES + 100)

        with patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)):
            self.assertTrue(users.request_change_password(password))

        retained_password = next(iter(users._pending_password_changes))
        self.assertLessEqual(len(retained_password.encode("utf-8")), SlskMessage.MAX_PASSWORD_FIELD_BYTES)
        self.assertEqual(retained_password, sent_messages[0].password)

    def test_change_password_ignores_unsolicited_response(self):
        users = object.__new__(Users)
        users._pending_password_changes = set()
        fake_config = SimpleNamespace(sections={"server": {"passw": "old-password"}},
                                      write_configuration=Mock())
        msg = SimpleNamespace(password="attacker-password")

        with patch.object(users_module, "config", fake_config):
            users._change_password(msg)

        self.assertIsNone(msg.password)
        self.assertEqual("old-password", fake_config.sections["server"]["passw"])
        fake_config.write_configuration.assert_not_called()

    def test_change_password_accepts_requested_response_once(self):
        users = object.__new__(Users)
        users._pending_password_changes = {"new-password"}
        fake_config = SimpleNamespace(sections={"server": {"passw": "old-password"}},
                                      write_configuration=Mock())
        msg = SimpleNamespace(password="new-password")

        with patch.object(users_module, "config", fake_config):
            users._change_password(msg)

        self.assertEqual("new-password", fake_config.sections["server"]["passw"])
        self.assertEqual(set(), users._pending_password_changes)
        fake_config.write_configuration.assert_called_once_with()

        fake_config.write_configuration.reset_mock()
        users._change_password(msg)

        self.assertIsNone(msg.password)
        fake_config.write_configuration.assert_not_called()

    def test_request_check_privileges_caps_pending_requests(self):
        users = object.__new__(Users)
        users._pending_privilege_checks = 1
        users._privilege_check_limit_logged = False
        users._should_open_privileges_url = False

        sent_messages = []
        old_limit = Users.MAX_PENDING_PRIVILEGE_CHECKS

        try:
            Users.MAX_PENDING_PRIVILEGE_CHECKS = 1

            with patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)):
                self.assertFalse(users.request_check_privileges(should_open_url=True))

        finally:
            Users.MAX_PENDING_PRIVILEGE_CHECKS = old_limit

        self.assertEqual(1, users._pending_privilege_checks)
        self.assertFalse(users._should_open_privileges_url)
        self.assertEqual([], sent_messages)
        self.assertTrue(users._privilege_check_limit_logged)

    def test_request_check_privileges_records_request(self):
        users = object.__new__(Users)
        users._pending_privilege_checks = 0
        users._privilege_check_limit_logged = True
        users._should_open_privileges_url = False
        sent_messages = []

        with patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)):
            self.assertTrue(users.request_check_privileges(should_open_url=True))

        self.assertEqual(1, users._pending_privilege_checks)
        self.assertTrue(users._should_open_privileges_url)
        self.assertFalse(users._privilege_check_limit_logged)
        self.assertEqual(1, len(sent_messages))
        self.assertIsInstance(sent_messages[0], CheckPrivileges)

    def test_check_privileges_ignores_unsolicited_response(self):
        users = object.__new__(Users)
        users._pending_privilege_checks = 0
        users._should_open_privileges_url = True
        users.privileges_left = 100
        msg = SimpleNamespace(seconds=0)

        users._check_privileges(msg)

        self.assertIsNone(msg.seconds)
        self.assertEqual(100, users.privileges_left)
        self.assertTrue(users._should_open_privileges_url)

    def test_check_privileges_accepts_requested_response_once(self):
        users = object.__new__(Users)
        users._pending_privilege_checks = 1
        users._should_open_privileges_url = False
        users.privileges_left = None
        msg = SimpleNamespace(seconds=3600)

        with patch.object(users_module, "log", SimpleNamespace(add=Mock())):
            users._check_privileges(msg)

        self.assertEqual(0, users._pending_privilege_checks)
        self.assertEqual(3600, users.privileges_left)

        users._check_privileges(msg)
        self.assertIsNone(msg.seconds)


    def test_request_ip_address_rejection_does_not_record_pending_state(self):
        users = object.__new__(Users)
        users._ip_requested = {}
        users._ip_request_times = {}
        users._ip_requested_limit_logged = False

        with patch.object(users_module.time, "monotonic", return_value=123), \
                patch_users_core(SimpleNamespace(send_message_to_server=Mock(return_value=False))):
            self.assertFalse(users.request_ip_address("peer", notify=True))

        self.assertEqual({}, users._ip_requested)
        self.assertEqual({}, users._ip_request_times)

    def test_request_user_stats_rejection_does_not_record_pending_state(self):
        users = object.__new__(Users)
        users._stats_requested = {}
        users._stats_requested_limit_logged = False

        with patch.object(users_module.time, "monotonic", return_value=123), \
                patch_users_core(SimpleNamespace(send_message_to_server=Mock(return_value=False))):
            self.assertFalse(users.request_user_stats("peer"))

        self.assertEqual({}, users._stats_requested)

    def test_request_check_privileges_rejection_does_not_record_pending_state(self):
        users = object.__new__(Users)
        users._pending_privilege_checks = 0
        users._privilege_check_limit_logged = False
        users._should_open_privileges_url = False

        with patch_users_core(SimpleNamespace(send_message_to_server=Mock(return_value=False))):
            self.assertFalse(users.request_check_privileges(should_open_url=True))

        self.assertEqual(0, users._pending_privilege_checks)
        self.assertFalse(users._should_open_privileges_url)

    def test_request_change_password_rejection_does_not_record_pending_state(self):
        users = object.__new__(Users)
        users._pending_password_changes = set()
        users._password_change_limit_logged = False

        with patch_users_core(SimpleNamespace(send_message_to_server=Mock(return_value=False))):
            self.assertFalse(users.request_change_password("new-password"))

        self.assertEqual(set(), users._pending_password_changes)

    def test_watch_user_rejection_does_not_create_local_watch(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        users.login_username = "me"
        users.watched = {}
        users._watched_users_limit_logged = False
        users._watch_contexts_limit_logged = False

        with patch_users_core(SimpleNamespace(send_message_to_server=Mock(return_value=False))):
            self.assertFalse(users.watch_user("peer", context="search"))

        self.assertTrue(users.last_watch_failure_retryable)
        self.assertNotIn("peer", users.watched)

    def test_watch_user_accepts_primary_watch_even_if_privilege_lookup_is_dropped(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        users.login_username = "me"
        users.watched = {}
        users._watched_users_limit_logged = False
        users._watch_contexts_limit_logged = False
        send_results = iter((True, False))
        sent_messages = []

        def send_message(message):
            sent_messages.append(message)
            return next(send_results)

        with patch_users_core(SimpleNamespace(send_message_to_server=send_message)):
            self.assertTrue(users.watch_user("peer", context="search"))

        self.assertFalse(users.last_watch_failure_retryable)
        self.assertIn("peer", users.watched)
        self.assertFalse(users.watched["peer"].is_implicit)
        self.assertEqual({"search"}, users.watched["peer"].contexts)
        self.assertIsInstance(sent_messages[0], WatchUser)

    def test_request_ip_address_caps_pending_requests(self):
        users = object.__new__(Users)
        users._ip_requested = {"existing": False}
        users._ip_requested_limit_logged = False

        sent_messages = []
        old_limit = Users.MAX_PENDING_IP_REQUESTS
        old_core = users_module.core

        try:
            Users.MAX_PENDING_IP_REQUESTS = 1
            users_module.core = SimpleNamespace(send_message_to_server=sent_messages.append)
            users.request_ip_address("new")

        finally:
            Users.MAX_PENDING_IP_REQUESTS = old_limit
            users_module.core = old_core

        self.assertEqual([], sent_messages)
        self.assertNotIn("new", users._ip_requested)
        self.assertTrue(users._ip_requested_limit_logged)

    def test_request_ip_address_allows_existing_pending_request_at_limit(self):
        users = object.__new__(Users)
        users._ip_requested = {"existing": False}
        users._ip_requested_limit_logged = False

        sent_messages = []
        old_limit = Users.MAX_PENDING_IP_REQUESTS
        old_core = users_module.core

        try:
            Users.MAX_PENDING_IP_REQUESTS = 1
            users_module.core = SimpleNamespace(send_message_to_server=sent_messages.append)
            users.request_ip_address("existing")

        finally:
            Users.MAX_PENDING_IP_REQUESTS = old_limit
            users_module.core = old_core

        self.assertEqual([], sent_messages)
        self.assertEqual({"existing": False}, users._ip_requested)
        self.assertFalse(users._ip_requested_limit_logged)



    def test_unsolicited_peer_address_poisoned_for_later_listeners(self):
        users = object.__new__(Users)
        users._ip_requested = {}
        users._ip_request_times = {}

        fake_core = SimpleNamespace(network_filter=SimpleNamespace(get_country_code=Mock()))

        with patch_users_core(fake_core):
            msg = SimpleNamespace(user="stranger", ip_address="1.2.3.4", port=2234)
            users._get_peer_address(msg)

        self.assertIsNone(msg.user)
        fake_core.network_filter.get_country_code.assert_not_called()

    def test_pending_peer_address_notify_request_is_upgraded(self):
        users = object.__new__(Users)
        users._ip_requested = {"peer": False}
        users._ip_request_times = {"peer": 123}
        users._ip_requested_limit_logged = False

        sent_messages = []

        with patch.object(users_module.time, "monotonic", return_value=124), \
                patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)):
            self.assertTrue(users.request_ip_address("peer", notify=True))

        self.assertEqual({"peer": True}, users._ip_requested)
        self.assertEqual([], sent_messages)

    def test_request_ip_address_prunes_stale_pending_request(self):
        users = object.__new__(Users)
        users._ip_requested = {"stale": False}
        users._ip_request_times = {"stale": 10}
        users._ip_requested_limit_logged = False

        sent_messages = []
        old_limit = Users.MAX_PENDING_IP_REQUESTS
        old_retention = Users.IP_REQUEST_RETENTION

        try:
            Users.MAX_PENDING_IP_REQUESTS = 1
            Users.IP_REQUEST_RETENTION = 60

            with patch.object(users_module.time, "monotonic", return_value=100), \
                    patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)):
                self.assertTrue(users.request_ip_address("fresh"))

        finally:
            Users.MAX_PENDING_IP_REQUESTS = old_limit
            Users.IP_REQUEST_RETENTION = old_retention

        self.assertNotIn("stale", users._ip_requested)
        self.assertIn("fresh", users._ip_requested)
        self.assertEqual(100, users._ip_request_times["fresh"])
        self.assertEqual(1, len(sent_messages))

    def test_request_user_stats_caps_pending_requests(self):
        users = object.__new__(Users)
        users._stats_requested = {"existing": 999}
        users._stats_requested_limit_logged = False

        sent_messages = []
        old_limit = Users.MAX_PENDING_USER_STATS_REQUESTS
        old_retention = Users.USER_STATS_REQUEST_RETENTION

        try:
            Users.MAX_PENDING_USER_STATS_REQUESTS = 1
            Users.USER_STATS_REQUEST_RETENTION = 10000

            with patch.object(users_module.time, "monotonic", return_value=1000), \
                    patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)):
                users.request_user_stats("new")

        finally:
            Users.MAX_PENDING_USER_STATS_REQUESTS = old_limit
            Users.USER_STATS_REQUEST_RETENTION = old_retention

        self.assertEqual([], sent_messages)
        self.assertEqual({"existing": 999}, users._stats_requested)
        self.assertTrue(users._stats_requested_limit_logged)

    def test_request_user_stats_deduplicates_pending_requests(self):
        users = object.__new__(Users)
        users._stats_requested = {"existing": 999}
        users._stats_requested_limit_logged = False

        sent_messages = []
        old_retention = Users.USER_STATS_REQUEST_RETENTION

        try:
            Users.USER_STATS_REQUEST_RETENTION = 10000

            with patch.object(users_module.time, "monotonic", return_value=1000), \
                    patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)):
                users.request_user_stats("existing")

        finally:
            Users.USER_STATS_REQUEST_RETENTION = old_retention

        self.assertEqual([], sent_messages)
        self.assertEqual({"existing": 999}, users._stats_requested)

    def test_request_user_stats_retries_stale_duplicate_request(self):
        """A lost UserStats response should not suppress future requests forever."""

        users = object.__new__(Users)
        users._stats_requested = {"existing": 1}
        users._stats_requested_limit_logged = True

        sent_messages = []
        old_retention = Users.USER_STATS_REQUEST_RETENTION

        try:
            Users.USER_STATS_REQUEST_RETENTION = 60

            with patch.object(users_module.time, "monotonic", return_value=1000), \
                    patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)):
                self.assertTrue(users.request_user_stats("existing"))

        finally:
            Users.USER_STATS_REQUEST_RETENTION = old_retention

        self.assertEqual({"existing": 1000}, users._stats_requested)
        self.assertFalse(users._stats_requested_limit_logged)
        self.assertEqual(1, len(sent_messages))
        self.assertIsInstance(sent_messages[0], GetUserStats)

    def test_request_user_stats_records_pending_request(self):
        users = object.__new__(Users)
        users._stats_requested = {}
        users._stats_requested_limit_logged = False

        sent_messages = []

        with patch.object(users_module.time, "monotonic", return_value=123), \
                patch_users_core(SimpleNamespace(send_message_to_server=sent_messages.append)):
            users.request_user_stats("new")

        self.assertEqual({"new": 123}, users._stats_requested)
        self.assertEqual(1, len(sent_messages))
        self.assertIsInstance(sent_messages[0], GetUserStats)

    def test_privileged_users_cache_is_capped(self):
        users = object.__new__(Users)
        users.privileged = {"existing"}
        users._privileged_limit_logged = False

        old_limit = Users.MAX_PRIVILEGED_USERS

        try:
            Users.MAX_PRIVILEGED_USERS = 2
            users._privileged_users(SimpleNamespace(users=["existing", "new1", "new2"]))

        finally:
            Users.MAX_PRIVILEGED_USERS = old_limit

        self.assertEqual({"existing", "new1"}, users.privileged)
        self.assertTrue(users._privileged_limit_logged)

    def test_user_status_privileged_update_respects_cache_cap(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        users.login_username = "me"
        users.addresses = {}
        users.countries = {}
        users.statuses = {}
        users.watched = {"new": WatchedUser("new")}
        users.privileged = {"existing"}
        users._ip_requested = {}
        users._ip_requested_limit_logged = False
        users._privileged_limit_logged = False
        users._pending_watch_removals = set()
        users._pending_watch_removals_limit_logged = False

        fake_core = SimpleNamespace(
            pluginhandler=SimpleNamespace(user_status_notification=Mock()),
            send_message_to_server=Mock()
        )
        old_limit = Users.MAX_PRIVILEGED_USERS

        try:
            Users.MAX_PRIVILEGED_USERS = 1
            with patch_users_core(fake_core):
                users._user_status(SimpleNamespace(user="new", status=UserStatus.ONLINE, privileged=True))

        finally:
            Users.MAX_PRIVILEGED_USERS = old_limit

        self.assertEqual({"existing"}, users.privileged)
        self.assertTrue(users._privileged_limit_logged)
        fake_core.pluginhandler.user_status_notification.assert_called_once_with(
            "new", UserStatus.ONLINE, True)

    def test_unsolicited_user_status_is_ignored(self):
        users = object.__new__(Users)
        users.login_status = UserStatus.ONLINE
        users.login_username = "me"
        users.addresses = {}
        users.countries = {}
        users.statuses = {}
        users.watched = {}
        users.privileged = set()
        users._ip_requested = {}
        users._ip_requested_limit_logged = False
        users._privileged_limit_logged = False
        users._pending_watch_removals = set()
        users._pending_watch_removals_limit_logged = False

        fake_core = SimpleNamespace(pluginhandler=SimpleNamespace(user_status_notification=Mock()))

        with patch_users_core(fake_core):
            msg = SimpleNamespace(user="stranger", status=UserStatus.ONLINE, privileged=True)
            users._user_status(msg)

        self.assertIsNone(msg.user)
        self.assertEqual({}, users.statuses)
        self.assertEqual(set(), users.privileged)
        fake_core.pluginhandler.user_status_notification.assert_not_called()

    def test_unsolicited_user_stats_is_ignored(self):
        users = object.__new__(Users)
        users.login_username = "me"
        users.watched = {}
        users._stats_requested = {}

        fake_core = SimpleNamespace(pluginhandler=SimpleNamespace(user_stats_notification=Mock()))

        with patch_users_core(fake_core):
            msg = SimpleNamespace(user="stranger", avgspeed=100, files=10, dirs=1)
            users._user_stats(msg)

        self.assertIsNone(msg.user)
        fake_core.pluginhandler.user_stats_notification.assert_not_called()

    def test_requested_user_stats_for_unwatched_user_is_accepted(self):
        users = object.__new__(Users)
        users.login_username = "me"
        users.watched = {}
        users._stats_requested = {"stranger": 123}

        fake_core = SimpleNamespace(pluginhandler=SimpleNamespace(user_stats_notification=Mock()))

        with patch_users_core(fake_core):
            msg = SimpleNamespace(user="stranger", avgspeed=100, files=10, dirs=1)
            users._user_stats(msg)

        self.assertEqual({}, users._stats_requested)
        fake_core.pluginhandler.user_stats_notification.assert_called_once_with(
            "stranger", stats={
                "avgspeed": 100,
                "files": 10,
                "dirs": 1,
                "shared_size": None,
                "source": "server"
            }
        )

    def test_watched_user_stats_update_and_notify(self):
        users = object.__new__(Users)
        users.login_username = "me"
        users.watched = {"peer": WatchedUser("peer")}
        users._stats_requested = {}

        fake_core = SimpleNamespace(pluginhandler=SimpleNamespace(user_stats_notification=Mock()))

        with patch_users_core(fake_core):
            users._user_stats(SimpleNamespace(user="peer", avgspeed=10, files=20, dirs=3))

        self.assertEqual(10, users.watched["peer"].upload_speed)
        self.assertEqual(20, users.watched["peer"].files)
        self.assertEqual(3, users.watched["peer"].folders)
        fake_core.pluginhandler.user_stats_notification.assert_called_once_with("peer", stats={
            "avgspeed": 10,
            "files": 20,
            "dirs": 3,
            "shared_size": None,
            "source": "server"
        })

    def test_connect_to_peer_privileged_update_respects_cache_cap(self):
        users = object.__new__(Users)
        users.privileged = {"existing"}
        users._privileged_limit_logged = False

        old_limit = Users.MAX_PRIVILEGED_USERS

        try:
            Users.MAX_PRIVILEGED_USERS = 1
            users._connect_to_peer(SimpleNamespace(user="new", privileged=True))

        finally:
            Users.MAX_PRIVILEGED_USERS = old_limit

        self.assertEqual({"existing"}, users.privileged)
        self.assertTrue(users._privileged_limit_logged)

    def test_watch_user_not_exists_ignores_unwatched_user(self):
        users = object.__new__(Users)
        users.login_username = "me"
        users.watched = {}
        users._pending_watch_removals = set()
        users._pending_watch_removals_limit_logged = False

        msg = SimpleNamespace(user="ghost", userexists=False, contains_stats=False)
        users._watch_user(msg)

        self.assertIsNone(msg.user)
        self.assertEqual(set(), users._pending_watch_removals)
        self.assertFalse(users._pending_watch_removals_limit_logged)

    def test_unsolicited_watch_user_stats_is_ignored(self):
        users = object.__new__(Users)
        users.login_username = "me"
        users.watched = {}
        users._pending_watch_removals = set()
        users._pending_watch_removals_limit_logged = False

        fake_events = SimpleNamespace(emit=Mock())

        with patch_users_events(fake_events):
            msg = SimpleNamespace(
                user="stranger", userexists=True, contains_stats=True,
                status=UserStatus.ONLINE, avgspeed=100, files=10, dirs=1)
            users._watch_user(msg)

        self.assertIsNone(msg.user)
        fake_events.emit.assert_not_called()

    def test_watched_watch_user_stats_normalizes_unknown_status(self):
        users = object.__new__(Users)
        users.login_username = "me"
        users.watched = {"peer": WatchedUser("peer")}
        users._pending_watch_removals = set()
        users._pending_watch_removals_limit_logged = False

        fake_events = SimpleNamespace(emit=Mock())

        with patch_users_events(fake_events):
            msg = SimpleNamespace(
                user="peer", userexists=True, contains_stats=True,
                status=99, avgspeed=100, files=10, dirs=1)
            users._watch_user(msg)

        self.assertEqual(UserStatus.OFFLINE, msg.status)
        fake_events.emit.assert_called_once_with("user-stats", msg)

    def test_pending_watch_removals_are_capped(self):
        users = object.__new__(Users)
        users.login_username = "me"
        users.watched = {"existing": WatchedUser("existing"), "new": WatchedUser("new")}
        users._pending_watch_removals = {"existing"}
        users._pending_watch_removals_limit_logged = False

        old_limit = Users.MAX_PENDING_WATCH_REMOVALS

        try:
            Users.MAX_PENDING_WATCH_REMOVALS = 1
            users._watch_user(SimpleNamespace(user="new", userexists=False, contains_stats=False))

        finally:
            Users.MAX_PENDING_WATCH_REMOVALS = old_limit

        self.assertEqual({"existing"}, users._pending_watch_removals)
        self.assertTrue(users._pending_watch_removals_limit_logged)

    def test_unsolicited_peer_address_response_is_ignored(self):
        users = object.__new__(Users)
        users.login_username = "me"
        users.addresses = {}
        users.countries = {}
        users.watched = {"peer": WatchedUser("peer")}
        users._ip_requested = {}

        fake_core = SimpleNamespace(
            network_filter=SimpleNamespace(get_country_code=Mock(return_value="US")),
            pluginhandler=SimpleNamespace(user_resolve_notification=Mock())
        )
        fake_events = SimpleNamespace(emit=Mock())

        with patch_users_core(fake_core), patch_users_events(fake_events):
            users._get_peer_address(SimpleNamespace(user="peer", ip_address="203.0.113.10", port=2234))

        self.assertEqual({}, users.addresses)
        self.assertEqual({}, users.countries)
        fake_core.network_filter.get_country_code.assert_not_called()
        fake_core.pluginhandler.user_resolve_notification.assert_not_called()
        fake_events.emit.assert_not_called()

    def test_invalid_requested_peer_address_response_is_poisoned_after_popping_request(self):
        users = object.__new__(Users)
        users.login_username = "me"
        users.addresses = {}
        users.countries = {}
        users.watched = {"peer": WatchedUser("peer")}
        users._ip_requested = {"peer": True}
        users._ip_request_times = {"peer": 123}

        fake_core = SimpleNamespace(
            network_filter=SimpleNamespace(get_country_code=Mock(return_value="US")),
            pluginhandler=SimpleNamespace(user_resolve_notification=Mock())
        )
        fake_events = SimpleNamespace(emit=Mock())
        msg = SimpleNamespace(user="peer", ip_address="127.0.0.1", port=2234)

        with patch_users_core(fake_core), patch_users_events(fake_events):
            users._get_peer_address(msg)

        self.assertIsNone(msg.user)
        self.assertEqual({}, users._ip_requested)
        self.assertEqual({}, users._ip_request_times)
        self.assertEqual({}, users.addresses)
        self.assertEqual({}, users.countries)
        fake_core.network_filter.get_country_code.assert_not_called()
        fake_core.pluginhandler.user_resolve_notification.assert_not_called()
        fake_events.emit.assert_not_called()

    def test_requested_peer_address_response_updates_watched_user(self):
        users = object.__new__(Users)
        users.login_username = "me"
        users.addresses = {}
        users.countries = {}
        users.watched = {"peer": WatchedUser("peer")}
        users._ip_requested = {"peer": False}

        fake_core = SimpleNamespace(
            network_filter=SimpleNamespace(get_country_code=Mock(return_value="US")),
            pluginhandler=SimpleNamespace(user_resolve_notification=Mock())
        )
        fake_events = SimpleNamespace(emit=Mock())

        with patch_users_core(fake_core), patch_users_events(fake_events):
            users._get_peer_address(SimpleNamespace(user="peer", ip_address="203.0.113.10", port=2234))

        self.assertEqual({"peer": ("203.0.113.10", 2234)}, users.addresses)
        self.assertEqual({"peer": "US"}, users.countries)
        fake_core.pluginhandler.user_resolve_notification.assert_called_once_with("peer", "203.0.113.10", 2234)
        fake_events.emit.assert_called_once_with("user-country", "peer", "US")

    def test_admin_message_rate_limit_suppresses_bursts(self):
        users = object.__new__(Users)
        users._admin_message_times = deque()
        users._admin_message_limit_logged = False

        old_limit = Users.MAX_ADMIN_MESSAGES_PER_MINUTE
        old_period = Users.ADMIN_MESSAGE_RATE_PERIOD

        try:
            Users.MAX_ADMIN_MESSAGES_PER_MINUTE = 2
            Users.ADMIN_MESSAGE_RATE_PERIOD = 60
            added_messages = []

            fake_log = SimpleNamespace(
                add=lambda message, title=None: added_messages.append((message, title)),
                add_debug=Mock()
            )

            with patch.object(users_module.time, "monotonic", side_effect=[1, 2, 3]), \
                    patch.object(users_module, "log", fake_log):
                users._admin_message(SimpleNamespace(msg="one"))
                users._admin_message(SimpleNamespace(msg="two"))
                users._admin_message(SimpleNamespace(msg="three"))

        finally:
            Users.MAX_ADMIN_MESSAGES_PER_MINUTE = old_limit
            Users.ADMIN_MESSAGE_RATE_PERIOD = old_period

        self.assertEqual(2, len(added_messages))
        self.assertEqual(["one", "two"], [message for message, _title in added_messages])
        self.assertTrue(users._admin_message_limit_logged)

    def test_admin_message_rate_limit_expires(self):
        users = object.__new__(Users)
        users._admin_message_times = deque()
        users._admin_message_limit_logged = False

        old_limit = Users.MAX_ADMIN_MESSAGES_PER_MINUTE
        old_period = Users.ADMIN_MESSAGE_RATE_PERIOD

        try:
            Users.MAX_ADMIN_MESSAGES_PER_MINUTE = 1
            Users.ADMIN_MESSAGE_RATE_PERIOD = 60
            added_messages = []

            fake_log = SimpleNamespace(
                add=lambda message, title=None: added_messages.append((message, title)),
                add_debug=Mock()
            )

            with patch.object(users_module.time, "monotonic", side_effect=[1, 62]), \
                    patch.object(users_module, "log", fake_log):
                users._admin_message(SimpleNamespace(msg="one"))
                users._admin_message(SimpleNamespace(msg="two"))

        finally:
            Users.MAX_ADMIN_MESSAGES_PER_MINUTE = old_limit
            Users.ADMIN_MESSAGE_RATE_PERIOD = old_period

        self.assertEqual(["one", "two"], [message for message, _title in added_messages])
        self.assertFalse(users._admin_message_limit_logged)
