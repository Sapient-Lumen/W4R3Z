# COPYRIGHT (C) 2021-2023 Nicotine+ Contributors
# COPYRIGHT (C) 2021 Inso-m-niaC
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import json
import re

from collections import OrderedDict
from threading import Lock
from threading import Thread

from pynicotine.events import events
from pynicotine.pluginsystem import BasePlugin
from pynicotine.utils import human_length
from pynicotine.utils import humanize


class Plugin(BasePlugin):

    MAX_API_RESPONSE_BYTES = 1024 * 1024
    MAX_PENDING_LOOKUPS = 16
    MAX_CACHED_RESPONSES = 128
    MAX_LAST_VIDEO_SOURCES = 4096
    MAX_FORMAT_LINES = 16
    MAX_FORMAT_LINE_CHARS = 4096
    MAX_API_FIELD_CHARS = 8192
    MAX_API_INTEGER_DIGITS = 64

    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)

        self.settings = {
            "api_key": "",
            "color": "Local",
            "format": [
                "* Title: %title%",
                "* Duration: %duration% - Views: %views%"]
        }
        self.metasettings = {
            "api_key": {
                "description": "YouTube Data v3 API key:",
                "type": "string"
            },
            "color": {
                "description": "Message color:",
                "type": "dropdown",
                "options": ("Remote", "Local", "Action", "Hilite")
            },
            "format": {
                "description": "Message format",
                "type": "list string"
            }
        }

        self.last_video_id = {
            "private": OrderedDict(),
            "public": OrderedDict()
        }
        self.video_cache = OrderedDict()
        self.pending_lookups = set()
        self.lookup_lock = Lock()
        self.lookup_limit_logged = False
        self.is_enabled = True

    def disable(self):
        self.is_enabled = False

        with self.lookup_lock:
            self.pending_lookups.clear()

    def incoming_public_chat_notification(self, room, user, line):

        if (self.core.network_filter.is_user_ignored(user)
                or self.core.network_filter.is_user_ip_ignored(user)):
            return

        video_id = self.get_video_id("public", room, line)
        if not video_id:
            return

        self.queue_video_lookup("public", room, video_id)

    def incoming_private_chat_notification(self, user, line):

        if (self.core.network_filter.is_user_ignored(user)
                or self.core.network_filter.is_user_ip_ignored(user)):
            return

        video_id = self.get_video_id("private", user, line)
        if not video_id:
            return

        self.queue_video_lookup("private", user, video_id)

    def get_video_id(self, mode, source, line):

        match = re.search(r"(https?://((m|music)\.)?|www\.)youtu(\.be/|be\.com/(shorts/|watch\S+v=))"
                          r"(?P<video_id>[-\w]{11})", line)
        if not match:
            return None

        video_id = match.group("video_id")
        last_video_ids = self.last_video_id[mode]

        if source in last_video_ids and last_video_ids[source] == video_id:
            last_video_ids.move_to_end(source)
            return None

        last_video_ids[source] = video_id
        last_video_ids.move_to_end(source)

        while len(last_video_ids) > self.MAX_LAST_VIDEO_SOURCES:
            last_video_ids.popitem(last=False)

        return video_id

    def queue_video_lookup(self, mode, target, video_id):
        """Fetch YouTube metadata without blocking the chat/UI event path."""

        with self.lookup_lock:
            parsed = self.video_cache.get(video_id)

            if parsed is not None:
                self.video_cache.move_to_end(video_id)

        if parsed is not None:
            self.show_parsed_response(mode, target, parsed)
            return

        lookup_key = (mode, target, video_id)

        with self.lookup_lock:
            if lookup_key in self.pending_lookups:
                return

            if len(self.pending_lookups) >= self.MAX_PENDING_LOOKUPS:
                if not self.lookup_limit_logged:
                    self.log("YouTube lookup queue limit reached, dropping additional lookups")
                    self.lookup_limit_logged = True

                return

            self.pending_lookups.add(lookup_key)

        Thread(target=self._lookup_video, args=(lookup_key, mode, target, video_id),
               name="YouTubeInfoLookup", daemon=True).start()

    def _lookup_video(self, lookup_key, mode, target, video_id):

        parsed = self.parse_response(video_id)

        with self.lookup_lock:
            self.pending_lookups.discard(lookup_key)

            if len(self.pending_lookups) < self.MAX_PENDING_LOOKUPS:
                self.lookup_limit_logged = False

            if parsed:
                self.video_cache[video_id] = parsed
                self.video_cache.move_to_end(video_id)

                while len(self.video_cache) > self.MAX_CACHED_RESPONSES:
                    self.video_cache.popitem(last=False)

        if parsed:
            events.invoke_main_thread(self.show_parsed_response, mode, target, parsed)

    def show_parsed_response(self, mode, target, parsed):

        if not self.is_enabled:
            return

        color = self.settings["color"].lower()

        for index, msg in enumerate(self.settings["format"]):
            if index >= self.MAX_FORMAT_LINES:
                self.log("YouTube info format line limit reached, skipping remaining lines")
                break

            text = self.str_replace(msg, parsed)

            if len(text) > self.MAX_FORMAT_LINE_CHARS:
                text = text[:self.MAX_FORMAT_LINE_CHARS]

            if mode == "public":
                self.echo_public(target, text, color)
            else:
                self.echo_private(target, text, color)

    def read_response_body(self, response):
        response_body = response.read(self.MAX_API_RESPONSE_BYTES + 1)

        if len(response_body) > self.MAX_API_RESPONSE_BYTES:
            self.log("YouTube API response exceeds %s bytes", self.MAX_API_RESPONSE_BYTES)
            return None

        return response_body.decode("utf-8", "replace")

    def parse_response(self, video_id):

        api_key = self.settings["api_key"]

        if not api_key:
            self.log("No API key specified")
            return None

        try:
            from urllib.request import urlopen
            with urlopen((f"https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics,contentDetails"
                          f"&id={video_id}&key={api_key}"), timeout=10) as response:
                response_body = self.read_response_body(response)

                if response_body is None:
                    return None

        except Exception as error:
            self.log("Failed to connect to www.googleapis.com: %s", error)
            return None

        try:
            data = json.loads(response_body)

        except Exception as error:
            self.log("Failed to parse response from www.googleapis.com: %s", error)
            return None

        if "error" in data:
            error_message = data["error"].get("message", False)
            if not error_message:
                # This should not occur
                error_message = data["error"]
            self.log(error_message)
            return None

        total_results = data.get("pageInfo", {}).get("totalResults", False)

        if not total_results:
            if isinstance(total_results, int):
                # Video removed / invalid id
                self.log("Video unavailable")

            elif isinstance(total_results, bool):
                # This should not occur
                self.log("Youtube API appears to be broken")
            return None

        try:
            data = data["items"][0]

            title = data["snippet"]["title"]
            description = data["snippet"]["description"]
            channel = data["snippet"]["channelTitle"]
            live = data["snippet"]["liveBroadcastContent"]

            duration = data["contentDetails"]["duration"]
            quality = data["contentDetails"]["definition"].upper()

            views = data["statistics"].get("viewCount", "RESTRICTED")
            likes = data["statistics"].get("likeCount", "LIKES")

        except KeyError:
            # This should not occur
            self.log('An error occurred while parsing id "%s"', video_id)
            return None

        likes = self.format_api_count(likes, fallback="LIKES")
        views = self.format_api_count(views, fallback="RESTRICTED")

        if live in {"live", "upcoming"}:
            duration = live.upper()
        else:
            duration = self.get_duration(duration)

        return {
            "%title%": self.truncate_api_field(title),
            "%description%": self.truncate_api_field(description),
            "%duration%": self.truncate_api_field(duration),
            "%quality%": self.truncate_api_field(quality),
            "%channel%": self.truncate_api_field(channel),
            "%views%": views,
            "%likes%": likes
        }

    @classmethod
    def truncate_api_field(cls, value):
        value = str(value)

        if len(value) <= cls.MAX_API_FIELD_CHARS:
            return value

        return value[:cls.MAX_API_FIELD_CHARS]

    @classmethod
    def format_api_count(cls, value, fallback):
        if value == fallback:
            return fallback

        value = str(value)

        if len(value) > cls.MAX_API_INTEGER_DIGITS or not value.isdigit():
            return fallback

        return humanize(int(value))

    @staticmethod
    def str_replace(subject, replacements):

        for string, replacement in replacements.items():
            if string in subject:
                subject = subject.replace(string, replacement)

        return subject

    @staticmethod
    def get_duration(iso_8601_duration):

        seconds = 0
        intervals = {"D": 86400, "H": 3600, "M": 60, "S": 1}

        for num, designator in re.findall(r"(\d+)([DHMS])", iso_8601_duration):
            seconds += intervals[designator] * int(num)

        return human_length(seconds)
