# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

from unittest import TestCase

from pynicotine.events import Events
from pynicotine.events import SchedulerEvent


class EventsTest(TestCase):

    def test_emit_reports_false_callback_result(self):
        """Queue-style events can report local backpressure to callers."""

        events = Events()
        calls = []
        events.connect("start", lambda: calls.append("first"))

        def reject():
            calls.append("second")
            return False

        events.connect("start", reject)

        self.assertFalse(events.emit("start"))
        self.assertEqual(["first", "second"], calls)

    def test_emit_reports_true_when_callbacks_accept(self):
        events = Events()
        events.connect("start", lambda: None)
        self.assertTrue(events.emit("start"))


    def test_queue_network_message_without_consumer_is_rejected(self):
        """Accepted-work callers should not succeed when no network queue is registered."""

        events = Events()
        self.assertFalse(events.emit("queue-network-message", object()))

    def test_queue_network_message_reports_registered_consumer_acceptance(self):
        events = Events()
        events.connect("queue-network-message", lambda _msg: True)
        self.assertTrue(events.emit("queue-network-message", object()))

    def test_main_thread_event_processing_is_batched(self):
        """Large cross-thread event bursts should not monopolize one main-loop tick."""

        events = Events()
        events.connect("thread-callback", events._thread_callback)
        processed_events = []

        for index in range(3):
            events.invoke_main_thread(processed_events.append, index)

        self.assertTrue(events.process_thread_events(max_events=2))
        self.assertEqual([0, 1], processed_events)
        self.assertEqual(1, len(events._thread_events))

        self.assertTrue(events.process_thread_events(max_events=2))
        self.assertEqual([0, 1, 2], processed_events)
        self.assertFalse(events._thread_events)

    def test_repeating_scheduler_skips_missed_intervals_after_stall(self):
        """A long sleep or main-loop stall should not replay every missed repeat."""

        self.assertEqual(1010, Events._get_next_repeat_time(event_time=100, delay=10, current_time=1000))

    def test_repeating_scheduler_keeps_normal_next_interval(self):
        self.assertEqual(110, Events._get_next_repeat_time(event_time=100, delay=10, current_time=100.5))

    def test_scheduler_heap_skips_cancelled_and_rescheduled_events(self):
        """Large timer sets should not need a full min() scan each scheduler tick."""

        events = Events()
        slow_event = SchedulerEvent(1, next_time=50)
        cancelled_event = SchedulerEvent(2, next_time=10)
        rescheduled_event = SchedulerEvent(3, next_time=20)

        events._add_scheduler_event(slow_event)
        events._add_scheduler_event(cancelled_event)
        events._add_scheduler_event(rescheduled_event)

        events._scheduler_events.pop(cancelled_event.event_id)
        rescheduled_event.next_time = 5
        events._add_scheduler_event(rescheduled_event)

        self.assertIs(rescheduled_event, events._get_next_scheduler_event())
        events._scheduler_events.pop(rescheduled_event.event_id)
        self.assertIs(slow_event, events._get_next_scheduler_event())

    def test_transfer_progress_events_are_coalesced_by_transfer(self):
        """Stale progress samples for one transfer should collapse to newest state."""

        events = Events()
        processed_events = []
        events.connect("file-download-progress", lambda *args: processed_events.append(args))

        self.assertTrue(events.emit_main_thread("file-download-progress", "alice", 1, 100))
        self.assertTrue(events.emit_main_thread("file-download-progress", "alice", 1, 200))
        self.assertTrue(events.emit_main_thread("file-download-progress", "bob", 1, 300))

        self.assertEqual(2, len(events._thread_events))
        self.assertEqual(2, len(events._coalesced_thread_events))

        self.assertTrue(events.process_thread_events(max_events=0))
        self.assertEqual([
            ("alice", 1, 200),
            ("bob", 1, 300)
        ], processed_events)
        self.assertFalse(events._coalesced_thread_events)

    def test_keyword_transfer_progress_events_are_coalesced_by_transfer(self):
        """Network-thread progress events use keyword transfer identifiers."""

        events = Events()
        processed_events = []
        events.connect("file-upload-progress", lambda **kwargs: processed_events.append(kwargs))

        self.assertTrue(events.emit_main_thread(
            "file-upload-progress", username="alice", token=1, bytes_left=100))
        self.assertTrue(events.emit_main_thread(
            "file-upload-progress", username="alice", token=1, bytes_left=50))

        self.assertEqual(1, len(events._thread_events))
        self.assertTrue(events.process_thread_events(max_events=0))
        self.assertEqual([{
            "username": "alice",
            "token": 1,
            "bytes_left": 50
        }], processed_events)

    def test_mixed_large_peer_response_progress_events_are_coalesced_by_socket(self):
        """Huge browse/user-info progress updates should collapse to newest state per socket."""

        events = Events()
        processed_events = []
        sock = object()
        events.connect("shared-file-list-progress", lambda *args: processed_events.append(args))
        events.connect("user-info-progress", lambda *args: processed_events.append(args))

        self.assertTrue(events.emit_main_thread("shared-file-list-progress", "alice", sock, 100, 1000))
        self.assertTrue(events.emit_main_thread("shared-file-list-progress", "alice", sock, 500, 1000))
        self.assertTrue(events.emit_main_thread("user-info-progress", "alice", sock, 10, 100))
        self.assertTrue(events.emit_main_thread("user-info-progress", "alice", sock, 90, 100))

        self.assertEqual(2, len(events._thread_events))
        self.assertEqual(2, len(events._coalesced_thread_events))

        self.assertTrue(events.process_thread_events(max_events=0))
        self.assertEqual([
            ("alice", sock, 500, 1000),
            ("alice", sock, 90, 100)
        ], processed_events)
        self.assertFalse(events._coalesced_thread_events)

    def test_shared_file_list_progress_events_are_coalesced_per_user_and_socket(self):
        """Huge browse/user-info response progress should collapse to latest state."""

        events = Events()
        processed_events = []
        sock = object()
        events.connect("shared-file-list-progress", lambda *args: processed_events.append(args))

        self.assertTrue(events.emit_main_thread("shared-file-list-progress", "alice", sock, 100, 1000))
        self.assertTrue(events.emit_main_thread("shared-file-list-progress", "alice", sock, 500, 1000))
        self.assertTrue(events.emit_main_thread("shared-file-list-progress", "bob", sock, 200, 1000))

        self.assertEqual(2, len(events._thread_events))
        self.assertEqual(2, len(events._coalesced_thread_events))

        self.assertTrue(events.process_thread_events(max_events=0))
        self.assertEqual([
            ("alice", sock, 500, 1000),
            ("bob", sock, 200, 1000)
        ], processed_events)

    def test_keyword_large_peer_response_progress_events_are_coalesced(self):
        events = Events()
        processed_events = []
        sock = object()
        events.connect("user-info-progress", lambda **kwargs: processed_events.append(kwargs))

        self.assertTrue(events.emit_main_thread(
            "user-info-progress", username="alice", sock=sock, buffer_len=100, msg_size_total=1000))
        self.assertTrue(events.emit_main_thread(
            "user-info-progress", username="alice", sock=sock, buffer_len=600, msg_size_total=1000))

        self.assertEqual(1, len(events._thread_events))
        self.assertTrue(events.process_thread_events(max_events=0))
        self.assertEqual([{
            "username": "alice",
            "sock": sock,
            "buffer_len": 600,
            "msg_size_total": 1000
        }], processed_events)

    def test_thread_event_queue_has_hard_cap_for_noncritical_events(self):
        """Non-critical bursts should not grow the cross-thread queue forever."""

        events = Events()
        old_limit = Events.MAX_PENDING_THREAD_EVENTS
        Events.MAX_PENDING_THREAD_EVENTS = 2

        try:
            self.assertTrue(events.emit_main_thread("log-message", "first", 0, "tag"))
            self.assertTrue(events.emit_main_thread("log-message", "second", 0, "tag"))
            self.assertFalse(events.emit_main_thread("log-message", "third", 0, "tag"))
            self.assertEqual(2, len(events._thread_events))
            self.assertEqual(1, events._dropped_thread_events)

            self.assertFalse(events.invoke_main_thread(lambda: None))
            self.assertEqual(2, len(events._thread_events))
            self.assertEqual(2, events._dropped_thread_events)

            self.assertTrue(events.invoke_main_thread(lambda: None, _critical=True))
            self.assertEqual(3, len(events._thread_events))

        finally:
            Events.MAX_PENDING_THREAD_EVENTS = old_limit

    def test_dropped_coalesced_event_is_not_left_in_coalescing_map(self):
        events = Events()
        old_limit = Events.MAX_PENDING_THREAD_EVENTS
        Events.MAX_PENDING_THREAD_EVENTS = 1

        try:
            self.assertTrue(events.emit_main_thread("log-message", "first", 0, "tag"))
            self.assertFalse(events.emit_main_thread("file-download-progress", "alice", 1, 100))
            self.assertFalse(events._coalesced_thread_events)

            events.process_thread_events(max_events=0)
            self.assertTrue(events.emit_main_thread("file-download-progress", "alice", 1, 200))
            self.assertEqual(1, len(events._thread_events))
            self.assertIn(("file-download-progress", "alice", 1), events._coalesced_thread_events)

        finally:
            Events.MAX_PENDING_THREAD_EVENTS = old_limit

    def test_noncritical_thread_callbacks_are_bounded(self):
        """Generic thread-callback work should not bypass pending-event caps."""

        events = Events()
        old_limit = Events.MAX_PENDING_THREAD_EVENTS
        Events.MAX_PENDING_THREAD_EVENTS = 1

        try:
            self.assertTrue(events.invoke_main_thread(lambda: None))
            self.assertFalse(events.invoke_main_thread(lambda: None))
            self.assertEqual(1, len(events._thread_events))
            self.assertEqual(1, events._dropped_thread_events)

            self.assertTrue(events.invoke_main_thread(lambda: None, _critical=True))
            self.assertEqual(2, len(events._thread_events))

        finally:
            Events.MAX_PENDING_THREAD_EVENTS = old_limit



    def test_control_plane_thread_events_bypass_noncritical_backpressure(self):
        """State-transition events should not be dropped behind noisy UI/log work."""

        events = Events()
        old_limit = Events.MAX_PENDING_THREAD_EVENTS
        Events.MAX_PENDING_THREAD_EVENTS = 1
        processed = []
        events.connect("log-message", lambda msg, *_unused: processed.append(("log", msg)))
        events.connect("server-disconnect", lambda msg: processed.append(("disconnect", msg)))
        events.connect("peer-connection-error", lambda **kwargs: processed.append(("peer-error", kwargs)))

        try:
            self.assertTrue(events.emit_main_thread("log-message", "first", 0, "tag"))
            self.assertFalse(events.emit_main_thread("log-message", "dropped", 0, "tag"))
            self.assertTrue(events.emit_main_thread("server-disconnect", "control"))
            self.assertTrue(events.emit_main_thread("peer-connection-error", username="alice", conn_type="P"))
            self.assertEqual(3, len(events._thread_events))

            events.process_thread_events(max_events=10)
            self.assertEqual(("log", "first"), processed[0])
            self.assertEqual(("disconnect", "control"), processed[1])
            self.assertEqual("peer-error", processed[2][0])
            self.assertEqual("alice", processed[2][1]["username"])

        finally:
            Events.MAX_PENDING_THREAD_EVENTS = old_limit

    def test_control_plane_thread_events_bypass_byte_backpressure(self):
        """Small lifecycle events should survive when byte budget rejects noisy payloads."""

        events = Events()
        old_limit = Events.MAX_PENDING_THREAD_EVENT_BYTES
        Events.MAX_PENDING_THREAD_EVENT_BYTES = 64

        try:
            self.assertFalse(events.emit_main_thread("log-message", "x" * 4096, 0, "tag"))
            self.assertTrue(events.emit_main_thread("file-connection-closed", username="alice", token=1))
            self.assertEqual(1, len(events._thread_events))
            self.assertEqual("file-connection-closed", events._thread_events[0].event_name)

        finally:
            Events.MAX_PENDING_THREAD_EVENT_BYTES = old_limit



    def test_heavy_folder_contents_response_uses_retry_signal_not_critical_shelf(self):
        """Heavy folder responses should fail delivery so the owner can re-request, not fill the critical shelf."""

        events = Events()
        old_regular_limit = Events.MAX_PENDING_THREAD_EVENTS
        Events.MAX_PENDING_THREAD_EVENTS = 1

        try:
            self.assertTrue(events.emit_main_thread("log-message", "noise", 0, "tag"))
            self.assertFalse(events.emit_main_thread("folder-contents-response", object()))
            self.assertEqual(["log-message"], [event.event_name for event in events._thread_events])
            self.assertEqual(0, events._critical_thread_events)

        finally:
            Events.MAX_PENDING_THREAD_EVENTS = old_regular_limit

    def test_transfer_protocol_events_bypass_noncritical_backpressure(self):
        """Parsed transfer-control messages should not be shed as UI/log noise."""

        events = Events()
        old_regular_limit = Events.MAX_PENDING_THREAD_EVENTS
        Events.MAX_PENDING_THREAD_EVENTS = 1

        try:
            self.assertTrue(events.emit_main_thread("log-message", "noise", 0, "tag"))
            self.assertFalse(events.emit_main_thread("room-list", object()))
            self.assertTrue(events.emit_main_thread("transfer-response", object()))
            self.assertTrue(events.emit_main_thread("queue-upload", object()))
            self.assertEqual([
                "log-message",
                "transfer-response",
                "queue-upload"
            ], [event.event_name for event in events._thread_events])
            self.assertEqual(2, events._critical_thread_events)

        finally:
            Events.MAX_PENDING_THREAD_EVENTS = old_regular_limit


    def test_user_state_protocol_events_bypass_noncritical_backpressure(self):
        """Parsed user state should not be shed as UI/log noise."""

        events = Events()
        old_regular_limit = Events.MAX_PENDING_THREAD_EVENTS
        Events.MAX_PENDING_THREAD_EVENTS = 1

        try:
            self.assertTrue(events.emit_main_thread("log-message", "noise", 0, "tag"))
            self.assertFalse(events.emit_main_thread("admin-message", "dropped-ui"))

            for event_name in (
                "user-status",
                "user-stats",
                "watch-user",
                "user-country",
                "privileged-users"
            ):
                self.assertTrue(events.emit_main_thread(event_name, object()))

            self.assertEqual([
                "log-message",
                "user-status",
                "user-stats",
                "watch-user",
                "user-country",
                "privileged-users"
            ], [event.event_name for event in events._thread_events])
            self.assertEqual(5, events._critical_thread_events)

        finally:
            Events.MAX_PENDING_THREAD_EVENTS = old_regular_limit

    def test_critical_thread_events_have_separate_hard_cap(self):
        """Lifecycle events bypass noisy UI caps, but not an unlimited critical shelf."""

        events = Events()
        old_critical_limit = Events.MAX_PENDING_CRITICAL_THREAD_EVENTS
        old_regular_limit = Events.MAX_PENDING_THREAD_EVENTS
        Events.MAX_PENDING_CRITICAL_THREAD_EVENTS = 2
        Events.MAX_PENDING_THREAD_EVENTS = 1

        try:
            self.assertTrue(events.emit_main_thread("log-message", "noise", 0, "tag"))
            self.assertFalse(events.emit_main_thread("log-message", "dropped", 0, "tag"))
            self.assertTrue(events.emit_main_thread("peer-connection-error", username="alice", conn_type="P"))
            self.assertTrue(events.emit_main_thread("peer-connection-error", username="bob", conn_type="P"))
            self.assertFalse(events.emit_main_thread("peer-connection-error", username="carol", conn_type="P"))
            self.assertEqual(3, len(events._thread_events))
            self.assertEqual(2, events._critical_thread_events)

            events.process_thread_events(max_events=2)
            self.assertEqual(1, events._critical_thread_events)
            self.assertTrue(events.emit_main_thread("peer-connection-error", username="dave", conn_type="P"))

        finally:
            Events.MAX_PENDING_CRITICAL_THREAD_EVENTS = old_critical_limit
            Events.MAX_PENDING_THREAD_EVENTS = old_regular_limit

    def test_global_control_thread_events_remain_unsheddable(self):
        """A peer-error burst should not hide disconnect/quit control transitions."""

        events = Events()
        old_critical_limit = Events.MAX_PENDING_CRITICAL_THREAD_EVENTS
        Events.MAX_PENDING_CRITICAL_THREAD_EVENTS = 1

        try:
            self.assertTrue(events.emit_main_thread("peer-connection-error", username="alice", conn_type="P"))
            self.assertFalse(events.emit_main_thread("peer-connection-error", username="bob", conn_type="P"))
            self.assertTrue(events.emit_main_thread("server-disconnect", "control"))
            self.assertTrue(events.emit_main_thread("quit"))
            self.assertEqual(3, len(events._thread_events))

        finally:
            Events.MAX_PENDING_CRITICAL_THREAD_EVENTS = old_critical_limit

    def test_shares_ready_is_unsheddable_control_transition(self):
        """Share scanner completion should not be dropped behind lifecycle bursts."""

        events = Events()
        old_critical_limit = Events.MAX_PENDING_CRITICAL_THREAD_EVENTS
        Events.MAX_PENDING_CRITICAL_THREAD_EVENTS = 1

        try:
            self.assertTrue(events.emit_main_thread("peer-connection-error", username="alice", conn_type="P"))
            self.assertFalse(events.emit_main_thread("peer-connection-error", username="bob", conn_type="P"))
            self.assertTrue(events.emit_main_thread("shares-ready", True))
            self.assertEqual([
                "peer-connection-error",
                "shares-ready"
            ], [event.event_name for event in events._thread_events])

        finally:
            Events.MAX_PENDING_CRITICAL_THREAD_EVENTS = old_critical_limit

    def test_share_scanning_progress_is_coalesced(self):
        """Large share scans should keep latest progress instead of every update."""

        events = Events()
        processed = []
        events.connect("shares-scanning", lambda *args: processed.append(args))

        self.assertTrue(events.emit_main_thread("shares-scanning", 1))
        self.assertTrue(events.emit_main_thread("shares-scanning", 2))
        self.assertTrue(events.emit_main_thread("shares-scanning", 3))
        self.assertEqual(1, len(events._thread_events))

        events.process_thread_events(max_events=10)
        self.assertEqual([(3,)], processed)

    def test_server_message_unsent_rollback_event_uses_critical_cap(self):
        """Rollback events are important, but still burst-bounded.

        A server-output failure storm can produce many rollback events. Keep them
        on the critical shelf so they bypass noisy UI/log caps, but do not let
        them bypass the critical shelf itself. Global lifecycle controls such as
        quit/disconnect remain unsheddable.
        """

        events = Events()
        old_critical_limit = Events.MAX_PENDING_CRITICAL_THREAD_EVENTS
        Events.MAX_PENDING_CRITICAL_THREAD_EVENTS = 1

        try:
            self.assertTrue(events.emit_main_thread("server-message-unsent", object()))
            self.assertFalse(events.emit_main_thread("server-message-unsent", object()))
            self.assertTrue(events.emit_main_thread("server-disconnect", "control"))
            self.assertEqual([
                "server-message-unsent",
                "server-disconnect"
            ], [event.event_name for event in events._thread_events])

        finally:
            Events.MAX_PENDING_CRITICAL_THREAD_EVENTS = old_critical_limit

    def test_critical_thread_event_byte_budget_is_released(self):
        events = Events()
        old_byte_limit = Events.MAX_PENDING_CRITICAL_THREAD_EVENT_BYTES
        Events.MAX_PENDING_CRITICAL_THREAD_EVENT_BYTES = 1024

        try:
            self.assertFalse(events.emit_main_thread(
                "peer-connection-error", username="alice", conn_type="P", error="x" * 4096))
            self.assertEqual(0, events._critical_thread_events)
            self.assertTrue(events.emit_main_thread(
                "peer-connection-error", username="alice", conn_type="P", error="small"))
            self.assertEqual(1, events._critical_thread_events)
            events.process_thread_events(max_events=1)
            self.assertEqual(0, events._critical_thread_events)
            self.assertEqual(0, events._critical_thread_event_bytes)

        finally:
            Events.MAX_PENDING_CRITICAL_THREAD_EVENT_BYTES = old_byte_limit

    def test_thread_event_queue_has_byte_budget_for_heavy_payloads(self):
        """One huge main-thread event should not bypass the count cap."""

        class HeavyPayload:
            __slots__ = ("payload",)

            def __init__(self):
                self.payload = "x" * 4096

        events = Events()
        old_limit = Events.MAX_PENDING_THREAD_EVENT_BYTES
        Events.MAX_PENDING_THREAD_EVENT_BYTES = 1024

        try:
            self.assertFalse(events.emit_main_thread("log-message", HeavyPayload(), 0, "tag"))
            self.assertFalse(events._thread_events)
            self.assertEqual(0, events._thread_event_bytes)
            self.assertEqual(1, events._dropped_thread_events)

            self.assertTrue(events.emit_main_thread("quit"))
            self.assertEqual(1, len(events._thread_events))

        finally:
            Events.MAX_PENDING_THREAD_EVENT_BYTES = old_limit

    def test_thread_event_byte_accounting_is_released_when_processed(self):
        """The retained-byte budget should track pending, not historical, events."""

        events = Events()
        processed = []
        events.connect("log-message", lambda msg, *_unused: processed.append(msg))

        self.assertTrue(events.emit_main_thread("log-message", "x" * 1000, 0, "tag"))
        retained = events._thread_events[0].retained_size
        self.assertGreater(retained, 0)
        self.assertEqual(retained, events._thread_event_bytes)

        events.process_thread_events(max_events=1)

        self.assertEqual(["x" * 1000], processed)
        self.assertEqual(0, events._thread_event_bytes)

    def test_coalesced_thread_event_updates_byte_accounting(self):
        """Replacing stale progress payloads should release the old retained size."""

        events = Events()
        sock = object()

        self.assertTrue(events.emit_main_thread("shared-file-list-progress", "alice", sock, 1, 2))
        old_size = events._thread_event_bytes
        self.assertTrue(events.emit_main_thread("shared-file-list-progress", "alice", sock, "x" * 1000, 2))

        self.assertEqual(1, len(events._thread_events))
        self.assertEqual(events._thread_events[0].retained_size, events._thread_event_bytes)
        self.assertGreater(events._thread_event_bytes, old_size)

    def test_scheduler_callbacks_are_coalesced_until_main_thread_runs(self):
        """Repeating scheduled callbacks should not bypass thread-event caps during UI stalls."""

        events = Events()
        events.connect("thread-callback", events._thread_callback)
        processed_events = []
        event = SchedulerEvent(7, callback=processed_events.append, callback_args=("tick",))

        self.assertTrue(events._invoke_scheduler_callback(event))
        self.assertFalse(events._invoke_scheduler_callback(event))
        self.assertEqual(1, len(events._thread_events))
        self.assertIn(event.event_id, events._pending_scheduler_callback_ids)

        self.assertTrue(events.process_thread_events(max_events=0))
        self.assertEqual(["tick"], processed_events)
        self.assertFalse(events._pending_scheduler_callback_ids)

        self.assertTrue(events._invoke_scheduler_callback(event))
        self.assertEqual(1, len(events._thread_events))

    def test_scheduler_callback_stays_coalesced_while_callback_is_running(self):
        """A slow scheduled callback should not let its repeat enqueue duplicates."""

        events = Events()
        events.connect("thread-callback", events._thread_callback)
        callback_attempts = []
        event = SchedulerEvent(42)

        def callback():
            callback_attempts.append("started")
            self.assertFalse(events._invoke_scheduler_callback(event))
            self.assertEqual(0, len(events._thread_events))
            self.assertIn(event.event_id, events._pending_scheduler_callback_ids)

        event.callback = callback
        event.callback_args = ()

        self.assertTrue(events._invoke_scheduler_callback(event))
        self.assertEqual(1, len(events._thread_events))

        self.assertTrue(events.process_thread_events(max_events=1))
        self.assertEqual(["started"], callback_attempts)
        self.assertFalse(events._pending_scheduler_callback_ids)
        self.assertFalse(events._thread_events)

        self.assertTrue(events._invoke_scheduler_callback(event))
        self.assertEqual(1, len(events._thread_events))

    def test_scheduler_callback_pending_id_is_released_after_exception(self):
        """Callback failures should not wedge future scheduler invocations forever."""

        events = Events()

        def callback():
            raise RuntimeError("boom")

        with self.assertRaises(RuntimeError):
            events._run_scheduler_callback(99, callback, ())

        self.assertNotIn(99, events._pending_scheduler_callback_ids)

    def test_scheduler_cancel_deduplicates_pending_tombstones(self):
        """Bulk cleanup should not enqueue duplicate cancel records for the same timer."""

        events = Events()
        event = SchedulerEvent(5, next_time=10)
        events._add_scheduler_event(event)

        events.cancel_scheduled(None)
        events.cancel_scheduled(event.event_id)
        events.cancel_scheduled(event.event_id)
        events.cancel_scheduled(event.event_id)

        self.assertEqual(1, len(events._pending_scheduler_events))
        self.assertEqual({event.event_id}, events._pending_scheduler_cancel_ids)

        events._process_pending_scheduler_event(events._pending_scheduler_events.popleft())
        self.assertNotIn(event.event_id, events._scheduler_events)
        self.assertFalse(events._pending_scheduler_cancel_ids)

    def test_scheduler_cancel_queue_has_hard_cap(self):
        """Many distinct cancellation tombstones should not grow the scheduler queue forever."""

        events = Events()
        old_cancel_limit = Events.MAX_PENDING_SCHEDULER_CANCELS
        old_event_limit = Events.MAX_SCHEDULED_EVENTS
        Events.MAX_PENDING_SCHEDULER_CANCELS = 2
        Events.MAX_SCHEDULED_EVENTS = 10

        try:
            events.cancel_scheduled(1)
            events.cancel_scheduled(2)
            events.cancel_scheduled(3)

            self.assertEqual(2, len(events._pending_scheduler_events))
            self.assertEqual({1, 2}, events._pending_scheduler_cancel_ids)
            self.assertEqual(1, events._dropped_scheduler_events)

        finally:
            Events.MAX_PENDING_SCHEDULER_CANCELS = old_cancel_limit
            Events.MAX_SCHEDULED_EVENTS = old_event_limit

    def test_scheduler_cancel_respects_pending_event_queue_cap(self):
        """Cancel requests should obey the same pending scheduler queue budget as new timers."""

        events = Events()
        old_event_limit = Events.MAX_SCHEDULED_EVENTS
        Events.MAX_SCHEDULED_EVENTS = 1

        try:
            self.assertEqual(1, events.schedule(10, lambda: None))
            events.cancel_scheduled(99)

            self.assertEqual(1, len(events._pending_scheduler_events))
            self.assertEqual(set(), events._pending_scheduler_cancel_ids)
            self.assertEqual(1, events._dropped_scheduler_events)

        finally:
            Events.MAX_SCHEDULED_EVENTS = old_event_limit

    def test_scheduler_event_queue_has_hard_cap_for_new_timers(self):
        """A stalled scheduler thread should not let new timer requests grow without bound."""

        events = Events()
        old_limit = Events.MAX_SCHEDULED_EVENTS
        Events.MAX_SCHEDULED_EVENTS = 2

        try:
            self.assertEqual(1, events.schedule(10, lambda: None))
            self.assertEqual(2, events.schedule(10, lambda: None))
            self.assertIsNone(events.schedule(10, lambda: None))
            self.assertEqual(2, len(events._pending_scheduler_events))
            self.assertEqual(1, events._dropped_scheduler_events)

        finally:
            Events.MAX_SCHEDULED_EVENTS = old_limit

    def test_scheduler_event_queue_has_byte_budget_for_callback_args(self):
        """Large retained timer arguments should not bypass the scheduled-event count cap."""

        events = Events()
        old_limit = Events.MAX_SCHEDULED_EVENT_BYTES
        Events.MAX_SCHEDULED_EVENT_BYTES = 1024

        try:
            self.assertIsNone(events.schedule(10, lambda value: None, callback_args=("x" * 4096,)))
            self.assertFalse(events._pending_scheduler_events)
            self.assertEqual(0, events._scheduler_event_bytes)
            self.assertEqual(1, events._dropped_scheduler_events)
            self.assertTrue(events._scheduler_event_byte_limit_logged)

            self.assertEqual(1, events.schedule(10, lambda value: None, callback_args=("ok",)))
            self.assertEqual(events._pending_scheduler_events[0].retained_size, events._scheduler_event_bytes)

        finally:
            Events.MAX_SCHEDULED_EVENT_BYTES = old_limit

    def test_scheduler_event_byte_accounting_is_released_on_cancel(self):
        """Cancelling an active scheduled event should release retained callback args."""

        events = Events()
        event_id = events.schedule(10, lambda value: None, callback_args=("x" * 2048,))
        retained_size = events._scheduler_event_bytes

        self.assertGreater(retained_size, 0)
        self.assertEqual(1, events._process_pending_scheduler_events(max_events=0))
        self.assertEqual(retained_size, events._scheduler_event_bytes)

        events.cancel_scheduled(event_id)
        events._process_pending_scheduler_events(max_events=0)

        self.assertEqual(0, events._scheduler_event_bytes)
        self.assertNotIn(event_id, events._scheduler_events)

    def test_scheduler_event_byte_accounting_is_released_when_finished(self):
        """Finished one-shot events should release retained callback args."""

        events = Events()
        event_id = events.schedule(10, lambda value: None, callback_args=("x" * 2048,))
        retained_size = events._scheduler_event_bytes

        self.assertGreater(retained_size, 0)
        events._process_pending_scheduler_events(max_events=0)
        event = events._scheduler_events.pop(event_id)
        events._release_scheduler_event_size(event)

        self.assertEqual(0, events._scheduler_event_bytes)
        self.assertEqual(0, event.retained_size)

    def test_quit_clears_scheduler_event_byte_accounting(self):
        """Shutdown should discard pending/active timers and their retained byte accounting."""

        events = Events()
        events.schedule(10, lambda value: None, callback_args=("pending" * 512,))
        events._process_pending_scheduler_events(max_events=0)
        events.schedule(10, lambda value: None, callback_args=("queued" * 512,))

        self.assertGreater(events._scheduler_event_bytes, 0)

        events._quit()

        self.assertEqual(0, events._scheduler_event_bytes)
        self.assertFalse(events._pending_scheduler_events)
        self.assertFalse(events._scheduler_events)
        self.assertFalse(events._scheduler_event_heap)

    def test_pending_scheduler_events_are_processed_in_bounded_batches(self):
        """Timer-management bursts should not monopolize one scheduler cycle."""

        events = Events()
        old_limit = Events.MAX_PENDING_SCHEDULER_EVENTS_PER_CYCLE
        Events.MAX_PENDING_SCHEDULER_EVENTS_PER_CYCLE = 2

        try:
            events._pending_scheduler_events.extend([
                SchedulerEvent(1, next_time=10),
                SchedulerEvent(2, next_time=20),
                SchedulerEvent(3, next_time=30),
            ])

            self.assertEqual(2, events._process_pending_scheduler_events())
            self.assertEqual(1, len(events._pending_scheduler_events))
            self.assertEqual({1, 2}, set(events._scheduler_events))

            self.assertEqual(1, events._process_pending_scheduler_events())
            self.assertFalse(events._pending_scheduler_events)
            self.assertEqual({1, 2, 3}, set(events._scheduler_events))

        finally:
            Events.MAX_PENDING_SCHEDULER_EVENTS_PER_CYCLE = old_limit


    def test_scheduler_cycle_waits_for_pending_cancellations_before_due_timer(self):
        """Batching pending scheduler records must not allow cancelled timers to fire early."""

        events = Events()
        old_limit = Events.MAX_PENDING_SCHEDULER_EVENTS_PER_CYCLE
        Events.MAX_PENDING_SCHEDULER_EVENTS_PER_CYCLE = 1

        try:
            events._pending_scheduler_events.extend([
                SchedulerEvent(1, next_time=0, callback=lambda: None, callback_args=()),
                SchedulerEvent(1, next_time=None),
            ])

            self.assertFalse(events._process_pending_scheduler_cycle())
            self.assertIn(1, events._scheduler_events)
            self.assertEqual(1, len(events._pending_scheduler_events))

            # The next scheduler cycle applies the cancel before _run_scheduler
            # is allowed to inspect due timers.
            self.assertTrue(events._process_pending_scheduler_cycle())
            self.assertNotIn(1, events._scheduler_events)
            self.assertIsNone(events._get_next_scheduler_event())

        finally:
            Events.MAX_PENDING_SCHEDULER_EVENTS_PER_CYCLE = old_limit

    def test_quit_drain_is_bounded_and_discards_remainder(self):
        """Shutdown should not process an entire stale main-thread backlog."""

        events = Events()
        processed_events = []
        events.connect("thread-callback", events._thread_callback)
        events.connect("quit", events._quit)
        old_limit = Events.MAX_QUIT_THREAD_EVENTS
        Events.MAX_QUIT_THREAD_EVENTS = 2

        try:
            for index in range(5):
                events.invoke_main_thread(processed_events.append, index)

            events.emit("quit")

            self.assertEqual([0, 1], processed_events)
            self.assertFalse(events._thread_events)
            self.assertFalse(events._callbacks)

        finally:
            Events.MAX_QUIT_THREAD_EVENTS = old_limit

    def test_quit_emit_does_not_mutate_callback_order(self):
        """Nested/error quit paths should not flip the registered callback list in place."""

        events = Events()
        calls = []
        events.connect("quit", lambda: calls.append("first"))
        events.connect("quit", lambda: calls.append("second"))

        events.emit("quit")
        events.emit("quit")

        self.assertEqual(["second", "first", "second", "first"], calls)

    def test_scheduler_callback_bypasses_noncritical_thread_event_cap_once(self):
        """Due scheduled callbacks must not be lost merely because non-critical UI events are full."""

        events = Events()
        event = SchedulerEvent(77, callback=lambda: None, callback_args=())
        old_limit = Events.MAX_PENDING_THREAD_EVENTS
        Events.MAX_PENDING_THREAD_EVENTS = 1

        try:
            self.assertTrue(events.emit_main_thread("log-message", "first", 0, "tag"))
            self.assertFalse(events.emit_main_thread("log-message", "second", 0, "tag"))

            self.assertTrue(events._invoke_scheduler_callback(event))
            self.assertEqual(2, len(events._thread_events))
            self.assertIn(event.event_id, events._pending_scheduler_callback_ids)

            self.assertFalse(events._invoke_scheduler_callback(event))
            self.assertEqual(2, len(events._thread_events))

        finally:
            Events.MAX_PENDING_THREAD_EVENTS = old_limit


    def test_scheduler_callback_pending_lane_has_hard_cap(self):
        """Critical scheduled callbacks should not grow the main-thread queue without a budget."""

        events = Events()
        first_event = SchedulerEvent(1, callback=lambda: None, callback_args=())
        second_event = SchedulerEvent(2, callback=lambda: None, callback_args=())
        old_limit = Events.MAX_PENDING_SCHEDULER_CALLBACKS
        Events.MAX_PENDING_SCHEDULER_CALLBACKS = 1

        try:
            self.assertTrue(events._invoke_scheduler_callback(first_event))
            self.assertFalse(events._invoke_scheduler_callback(second_event))
            self.assertEqual(1, len(events._thread_events))
            self.assertEqual({first_event.event_id}, events._pending_scheduler_callback_ids)
            self.assertEqual(1, events._deferred_scheduler_callbacks)

        finally:
            Events.MAX_PENDING_SCHEDULER_CALLBACKS = old_limit

    def test_scheduler_callback_backpressure_keeps_due_event_scheduled(self):
        """When the callback lane is full, a due timer should be deferred rather than dropped."""

        events = Events()
        event = SchedulerEvent(7, next_time=10, callback=lambda: None, callback_args=())
        old_delay = Events.SCHEDULER_CALLBACK_RETRY_DELAY
        old_limit = Events.MAX_PENDING_SCHEDULER_CALLBACKS
        Events.SCHEDULER_CALLBACK_RETRY_DELAY = 5

        try:
            events._pending_scheduler_callback_ids.add(99)
            Events.MAX_PENDING_SCHEDULER_CALLBACKS = 1
            events._add_scheduler_event(event)
            self.assertTrue(events._scheduler_callback_backpressured(event))

            events._defer_scheduler_callback(event, current_time=100)
            self.assertEqual(105, event.next_time)
            self.assertIs(event, events._scheduler_events[event.event_id])
            self.assertEqual(1, events._deferred_scheduler_callbacks)
            self.assertEqual((105, event.event_id), events._scheduler_event_heap[-1])

        finally:
            Events.MAX_PENDING_SCHEDULER_CALLBACKS = old_limit
            Events.SCHEDULER_CALLBACK_RETRY_DELAY = old_delay

    def test_due_scheduler_callback_retries_when_main_thread_bridge_rejects_after_precheck(self):
        """A one-shot due timer should survive a late main-thread bridge rejection."""

        events = Events()
        event = SchedulerEvent(123, next_time=0, delay=0, repeat=False, callback=lambda: None, callback_args=())
        old_delay = Events.SCHEDULER_CALLBACK_RETRY_DELAY
        Events.SCHEDULER_CALLBACK_RETRY_DELAY = 5

        try:
            events._add_scheduler_event(event)

            def reject_bridge(*_args, **_kwargs):
                return False

            from unittest.mock import patch

            with patch.object(Events, "emit_main_thread", reject_bridge):
                self.assertFalse(events._queue_due_scheduler_callback(event, current_time=100))

            self.assertIs(event, events._scheduler_events[event.event_id])
            self.assertEqual(105, event.next_time)
            self.assertEqual((105, event.event_id), events._scheduler_event_heap[-1])
            self.assertNotIn(event.event_id, events._pending_scheduler_callback_ids)
            self.assertEqual(1, events._deferred_scheduler_callbacks)

        finally:
            Events.SCHEDULER_CALLBACK_RETRY_DELAY = old_delay


    def test_callback_plugin_name_handles_builtin_plugin_modules(self):
        """Built-in plugin callbacks should be attributed to the plugin, not to 'pynicotine'."""

        from pynicotine.events import get_callback_plugin_name

        def callback():
            pass

        callback.__module__ = "pynicotine.plugins.auto_user_browse"
        self.assertEqual("auto_user_browse", get_callback_plugin_name(callback))

        callback.__module__ = "pynicotine.plugins.youtube_info.helpers"
        self.assertEqual("youtube_info", get_callback_plugin_name(callback))

        callback.__module__ = "third_party_plugin"
        self.assertEqual("third_party_plugin", get_callback_plugin_name(callback))

    def test_builtin_plugin_event_callback_exception_is_logged_not_fatal(self):
        """A direct event callback from a built-in plugin should not be mistaken for core code."""

        from types import SimpleNamespace
        from unittest.mock import Mock
        from unittest.mock import patch
        from pynicotine import core

        events = Events()

        def callback():
            raise RuntimeError("plugin boom")

        callback.__module__ = "pynicotine.plugins.auto_user_browse"
        events.connect("start", callback)
        pluginhandler = SimpleNamespace(
            enabled_plugins={"auto_user_browse": object()},
            show_plugin_error=Mock()
        )

        with patch.object(core, "pluginhandler", pluginhandler):
            events.emit("start")

        pluginhandler.show_plugin_error.assert_called_once()

    def test_scheduler_callback_byte_backpressure_defers_due_callback(self):
        """Due scheduler callbacks should not bypass thread-event byte caps with large retained args."""

        events = Events()
        old_limit = Events.MAX_PENDING_SCHEDULER_CALLBACK_BYTES
        Events.MAX_PENDING_SCHEDULER_CALLBACK_BYTES = 1

        try:
            event = SchedulerEvent(
                1, next_time=0, delay=0, repeat=False,
                callback=lambda value: None, callback_args=("x" * 4096,), retained_size=4096
            )

            self.assertTrue(events._scheduler_callback_backpressured(event))
            self.assertEqual(0, events._pending_scheduler_callback_bytes)
            self.assertTrue(events._scheduler_callback_byte_limit_logged)

        finally:
            Events.MAX_PENDING_SCHEDULER_CALLBACK_BYTES = old_limit

    def test_scheduler_callback_byte_accounting_releases_after_main_thread_runs(self):
        """Bytes moved from due timers into the main-thread callback lane should be accounted and released."""

        events = Events()
        events.connect("thread-callback", events._thread_callback)
        callback_values = []
        event = SchedulerEvent(
            7, next_time=0, delay=0, repeat=False,
            callback=callback_values.append, callback_args=("payload",), retained_size=1234
        )

        self.assertTrue(events._invoke_scheduler_callback(event))
        self.assertEqual({event.event_id}, events._pending_scheduler_callback_ids)
        self.assertEqual(1234, events._pending_scheduler_callback_bytes)
        self.assertEqual({event.event_id: 1234}, events._pending_scheduler_callback_sizes)

        events.process_thread_events(max_events=0)

        self.assertEqual(["payload"], callback_values)
        self.assertFalse(events._pending_scheduler_callback_ids)
        self.assertFalse(events._pending_scheduler_callback_sizes)
        self.assertEqual(0, events._pending_scheduler_callback_bytes)

    def test_duplicate_event_callback_registration_is_ignored(self):
        """Duplicate callback registration should not multiply event fanout."""

        events = Events()
        calls = []

        def callback():
            calls.append(True)

        self.assertTrue(events.connect("start", callback))
        self.assertFalse(events.connect("start", callback))
        events.emit("start")

        self.assertEqual([True], calls)

    def test_event_callback_registration_has_hard_cap(self):
        """A plugin cannot register an unbounded number of callbacks for one event."""

        events = Events()
        old_limit = Events.MAX_CALLBACKS_PER_EVENT
        Events.MAX_CALLBACKS_PER_EVENT = 2

        try:
            self.assertTrue(events.connect("start", lambda: None))
            self.assertTrue(events.connect("start", lambda: None))
            self.assertFalse(events.connect("start", lambda: None))
            self.assertEqual(2, len(events._callbacks["start"]))

        finally:
            Events.MAX_CALLBACKS_PER_EVENT = old_limit

