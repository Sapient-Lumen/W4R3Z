import importlib, os, sys, unittest
mods=[]
for dirpath, _dirs, files in os.walk('pynicotine/tests/unit'):
    for name in files:
        if name.startswith('test_') and name.endswith('.py'):
            mod=os.path.join(dirpath,name)[:-3].replace(os.sep,'.')
            if mod.endswith('test_i18n') or mod.endswith('shares.test_shares'):
                continue
            mods.append(mod)
mods.sort()
loader=unittest.TestLoader(); suite=unittest.TestSuite()
for m in mods:
    suite.addTests(loader.loadTestsFromModule(importlib.import_module(m)))
r=unittest.TextTestRunner(verbosity=1).run(suite)
sys.exit(not r.wasSuccessful())
