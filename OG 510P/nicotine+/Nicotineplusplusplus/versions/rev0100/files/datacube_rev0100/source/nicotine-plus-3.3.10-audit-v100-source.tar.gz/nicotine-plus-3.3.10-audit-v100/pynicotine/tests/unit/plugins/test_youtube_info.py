# COPYRIGHT (C) 2026 Nicotine+ Contributors

import json

from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock
from unittest.mock import patch

from pynicotine.plugins.youtube_info import Plugin


class YoutubeInfoPluginTest(TestCase):

    def _plugin(self):
        plugin = Plugin()
        plugin.human_name = "YouTube Info"
        plugin.log = Mock()
        plugin.core = SimpleNamespace(
            network_filter=SimpleNamespace(
                is_user_ignored=Mock(return_value=False),
                is_user_ip_ignored=Mock(return_value=False)
            )
        )
        return plugin

    def test_incoming_public_chat_queues_lookup_without_synchronous_fetch(self):
        plugin = self._plugin()
        plugin.parse_response = Mock(return_value={})

        with patch("pynicotine.plugins.youtube_info.Thread") as thread_class:
            plugin.incoming_public_chat_notification(
                "room", "user", "https://www.youtube.com/watch?v=dQw4w9WgXcQ")

        plugin.parse_response.assert_not_called()
        thread_class.assert_called_once()
        thread_class.return_value.start.assert_called_once()

    def test_queue_video_lookup_caps_pending_threads(self):
        plugin = self._plugin()

        with patch("pynicotine.plugins.youtube_info.Thread") as thread_class:
            for index in range(plugin.MAX_PENDING_LOOKUPS + 1):
                plugin.queue_video_lookup("public", "room", f"video{index:011d}"[-11:])

        self.assertEqual(plugin.MAX_PENDING_LOOKUPS, len(plugin.pending_lookups))
        self.assertEqual(plugin.MAX_PENDING_LOOKUPS, thread_class.call_count)
        plugin.log.assert_called_once()

    def test_read_response_body_rejects_oversized_response(self):
        plugin = self._plugin()
        response = SimpleNamespace(read=Mock(return_value=b"x" * (plugin.MAX_API_RESPONSE_BYTES + 1)))

        self.assertIsNone(plugin.read_response_body(response))
        plugin.log.assert_called_once()

    def test_last_video_id_cache_is_bounded_per_mode(self):
        plugin = self._plugin()
        old_limit = Plugin.MAX_LAST_VIDEO_SOURCES

        try:
            Plugin.MAX_LAST_VIDEO_SOURCES = 2
            plugin.get_video_id("public", "room0", "https://youtu.be/aaaaaaaaaaa")
            plugin.get_video_id("public", "room1", "https://youtu.be/bbbbbbbbbbb")
            plugin.get_video_id("public", "room2", "https://youtu.be/ccccccccccc")

        finally:
            Plugin.MAX_LAST_VIDEO_SOURCES = old_limit

        self.assertNotIn("room0", plugin.last_video_id["public"])
        self.assertEqual(["room1", "room2"], list(plugin.last_video_id["public"]))
        self.assertEqual({}, plugin.last_video_id["private"])


    def test_api_fields_and_counts_are_bounded(self):
        plugin = self._plugin()
        old_field_chars = Plugin.MAX_API_FIELD_CHARS
        old_digit_count = Plugin.MAX_API_INTEGER_DIGITS

        try:
            Plugin.MAX_API_FIELD_CHARS = 4
            Plugin.MAX_API_INTEGER_DIGITS = 3

            self.assertEqual("abcd", plugin.truncate_api_field("abcdef"))
            self.assertEqual("123", plugin.format_api_count("123", fallback="RESTRICTED"))
            self.assertEqual("RESTRICTED", plugin.format_api_count("1234", fallback="RESTRICTED"))
            self.assertEqual("LIKES", plugin.format_api_count("not-a-number", fallback="LIKES"))

        finally:
            Plugin.MAX_API_FIELD_CHARS = old_field_chars
            Plugin.MAX_API_INTEGER_DIGITS = old_digit_count

    def test_parse_response_bounds_youtube_payload_fields(self):
        plugin = self._plugin()
        plugin.settings["api_key"] = "api-key"
        old_field_chars = Plugin.MAX_API_FIELD_CHARS
        old_digit_count = Plugin.MAX_API_INTEGER_DIGITS

        class FakeResponse:
            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

            @staticmethod
            def read(_size):
                return json.dumps({
                    "pageInfo": {"totalResults": 1},
                    "items": [{
                        "snippet": {
                            "title": "abcdef",
                            "description": "ghijkl",
                            "channelTitle": "channel",
                            "liveBroadcastContent": "none"
                        },
                        "contentDetails": {"duration": "PT1S", "definition": "hd"},
                        "statistics": {"viewCount": "9" * 10, "likeCount": "123"}
                    }]
                }).encode()

        try:
            Plugin.MAX_API_FIELD_CHARS = 4
            Plugin.MAX_API_INTEGER_DIGITS = 3

            with patch("urllib.request.urlopen", return_value=FakeResponse()):
                parsed = plugin.parse_response("dQw4w9WgXcQ")

            self.assertEqual("abcd", parsed["%title%"] )
            self.assertEqual("ghij", parsed["%description%"] )
            self.assertEqual("RESTRICTED", parsed["%views%"] )
            self.assertEqual("123", parsed["%likes%"] )

        finally:
            Plugin.MAX_API_FIELD_CHARS = old_field_chars
            Plugin.MAX_API_INTEGER_DIGITS = old_digit_count

    def test_show_parsed_response_caps_format_fanout_and_line_length(self):
        plugin = self._plugin()
        plugin.echo_public = Mock()
        plugin.settings["format"] = ["%title%"] * (plugin.MAX_FORMAT_LINES + 2)
        parsed = {"%title%": "x" * (plugin.MAX_FORMAT_LINE_CHARS + 10)}

        plugin.show_parsed_response("public", "room", parsed)

        self.assertEqual(plugin.MAX_FORMAT_LINES, plugin.echo_public.call_count)
        for call in plugin.echo_public.call_args_list:
            _room, text, _color = call.args
            self.assertLessEqual(len(text), plugin.MAX_FORMAT_LINE_CHARS)
        plugin.log.assert_called_once()
