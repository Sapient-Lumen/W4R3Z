# COPYRIGHT (C) 2020-2024 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import time

from collections import deque
from threading import Thread

from pynicotine.config import config
from pynicotine.events import events
from pynicotine.logfacility import log
from pynicotine.utils import execute_command


class Notifications:
    __slots__ = ("tts", "_tts_thread", "_tts_queue_limit_logged", "_tts_command_times",
                 "_tts_command_limit_logged", "_popup_notification_times",
                 "_popup_notification_limit_logged")

    MAX_TTS_QUEUE = 100
    MAX_TTS_MESSAGE_CHARS = 4096
    MAX_NOTIFICATION_MESSAGE_CHARS = 4096
    MAX_NOTIFICATION_TITLE_CHARS = 512
    MAX_TTS_COMMANDS_PER_MINUTE = 60
    MAX_POPUP_NOTIFICATIONS_PER_MINUTE = 120

    def __init__(self):

        self.tts = deque()
        self._tts_thread = None
        self._tts_queue_limit_logged = False
        self._tts_command_times = deque()
        self._tts_command_limit_logged = False
        self._popup_notification_times = deque()
        self._popup_notification_limit_logged = False

        events.connect("quit", self._quit)

    def _quit(self):
        self.tts.clear()
        self._tts_command_times.clear()
        self._popup_notification_times.clear()

    # Notification Messages #

    def _allow_popup_notification(self):

        current_time = time.monotonic()
        cutoff_time = current_time - 60
        notification_times = self._popup_notification_times

        while notification_times and notification_times[0] < cutoff_time:
            notification_times.popleft()

        if len(notification_times) >= self.MAX_POPUP_NOTIFICATIONS_PER_MINUTE:
            if not self._popup_notification_limit_logged:
                log.add_debug(
                    "Popup notification limit of %s per minute reached, dropping additional notifications",
                    self.MAX_POPUP_NOTIFICATIONS_PER_MINUTE
                )
                self._popup_notification_limit_logged = True

            return False

        notification_times.append(current_time)
        self._popup_notification_limit_logged = False
        return True

    @classmethod
    def _truncate_notification_text(cls, text, max_chars):
        if text is None:
            return None

        text = str(text)

        if len(text) <= max_chars:
            return text

        return text[:max_chars]

    def _prepare_notification_payload(self, message, title):
        return (
            self._truncate_notification_text(message, self.MAX_NOTIFICATION_MESSAGE_CHARS),
            self._truncate_notification_text(title, self.MAX_NOTIFICATION_TITLE_CHARS)
        )

    def show_notification(self, message, title=None):
        message, title = self._prepare_notification_payload(message, title)

        if not self._allow_popup_notification():
            return

        events.emit("show-notification", message, title=title)

    def show_chatroom_notification(self, room, message, title=None, high_priority=False):
        message, title = self._prepare_notification_payload(message, title)

        if not self._allow_popup_notification():
            return

        events.emit("show-chatroom-notification", room, message, title=title, high_priority=high_priority)

    def show_download_notification(self, message, title=None, high_priority=False):
        message, title = self._prepare_notification_payload(message, title)

        if not self._allow_popup_notification():
            return

        events.emit("show-download-notification", message, title=title, high_priority=high_priority)

    def show_private_chat_notification(self, username, message, title=None):
        message, title = self._prepare_notification_payload(message, title)

        if not self._allow_popup_notification():
            return

        events.emit("show-private-chat-notification", username, message, title=title)

    def show_search_notification(self, search_token, message, title=None):
        message, title = self._prepare_notification_payload(message, title)

        if not self._allow_popup_notification():
            return

        events.emit("show-search-notification", search_token, message, title=title)

    # TTS #

    def new_tts(self, message, args=None):

        if not config.sections["ui"]["speechenabled"]:
            return

        if args:
            for key, value in args.items():
                args[key] = (value.replace("_", " ").replace("[", " ").replace("]", " ")
                                  .replace("(", " ").replace(")", " "))

            try:
                message %= args

            except Exception as error:
                log.add(_("Text-to-speech for message failed: %s"), error)
                return

        if len(message) > self.MAX_TTS_MESSAGE_CHARS:
            message = message[:self.MAX_TTS_MESSAGE_CHARS]

        if len(self.tts) >= self.MAX_TTS_QUEUE:
            if not self._tts_queue_limit_logged:
                log.add_debug("Text-to-speech queue limit reached, dropping additional messages")
                self._tts_queue_limit_logged = True

            return

        self.tts.append(message)

        if self._tts_thread and self._tts_thread.is_alive():
            return

        self._tts_thread = Thread(target=self.play_tts, name="TTS", daemon=True)
        self._tts_thread.start()


    def _allow_tts_command(self):

        current_time = time.monotonic()
        cutoff_time = current_time - 60
        command_times = self._tts_command_times

        while command_times and command_times[0] < cutoff_time:
            command_times.popleft()

        if len(command_times) >= self.MAX_TTS_COMMANDS_PER_MINUTE:
            if not self._tts_command_limit_logged:
                log.add_debug(
                    "Text-to-speech command launch limit of %s per minute reached, dropping messages",
                    self.MAX_TTS_COMMANDS_PER_MINUTE
                )
                self._tts_command_limit_logged = True

            return False

        command_times.append(current_time)
        self._tts_command_limit_logged = False
        return True

    def play_tts(self):

        while self.tts:
            try:
                message = self.tts.popleft()

                if not self._allow_tts_command():
                    continue

                execute_command(config.sections["ui"]["speechcommand"], message, background=False, hidden=True)

            except Exception as error:
                log.add(_("Text-to-speech for message failed: %s"), error)

        self._tts_queue_limit_logged = False
