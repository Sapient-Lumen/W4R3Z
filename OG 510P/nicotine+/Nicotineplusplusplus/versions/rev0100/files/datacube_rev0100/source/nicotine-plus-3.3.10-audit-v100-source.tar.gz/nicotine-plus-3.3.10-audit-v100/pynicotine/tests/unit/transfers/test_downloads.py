# COPYRIGHT (C) 2021-2025 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import errno
import json
import os
import re
import shutil

from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock
from unittest.mock import patch

import pynicotine.transfers as transfers_module

from pynicotine.config import config
from pynicotine.core import core
from pynicotine.downloads import Downloads
from pynicotine.downloads import RequestedFolder
from pynicotine.events import events
from pynicotine.slskmessages import FileAttribute
from pynicotine.slskmessages import FileTransferInit
from pynicotine.slskmessages import FolderContentsRequest
from pynicotine.slskmessages import FolderContentsResponse
from pynicotine.slskmessages import PlaceInQueueRequest
from pynicotine.slskmessages import QueueUpload
from pynicotine.slskmessages import FOLDER_TOKENS_ALLOWED
from pynicotine.slskmessages import TransferDirection
from pynicotine.slskmessages import TransferRejectReason
from pynicotine.slskmessages import TransferRequest
from pynicotine.slskmessages import TransferResponse
from pynicotine.slskmessages import UserStatus
from pynicotine.transfers import Transfer
from pynicotine.transfers import Transfers
from pynicotine.transfers import TransferStatus
from pynicotine.utils import UINT64_LIMIT
from pynicotine.userbrowse import BrowsedUser

CURRENT_FOLDER_PATH = os.path.dirname(os.path.realpath(__file__))
DATA_FOLDER_PATH = os.path.join(CURRENT_FOLDER_PATH, "temp_data")
TRANSFERS_BASENAME = "downloads.json"
TRANSFERS_FILE_PATH = os.path.join(CURRENT_FOLDER_PATH, TRANSFERS_BASENAME)
SAVED_TRANSFERS_FILE_PATH = os.path.join(DATA_FOLDER_PATH, TRANSFERS_BASENAME)


class DownloadsTest(TestCase):

    # pylint: disable=protected-access

    def setUp(self):

        config.set_data_folder(DATA_FOLDER_PATH)
        config.set_config_file(os.path.join(DATA_FOLDER_PATH, "temp_config"))

        if not os.path.exists(DATA_FOLDER_PATH):
            os.makedirs(DATA_FOLDER_PATH)

        shutil.copy(TRANSFERS_FILE_PATH, os.path.join(DATA_FOLDER_PATH, TRANSFERS_BASENAME))

        core.init_components(enabled_components={"users", "downloads", "userbrowse"})
        self._network_acceptor = lambda _msg: True
        events.connect("queue-network-message", self._network_acceptor)
        config.sections["transfers"]["downloaddir"] = DATA_FOLDER_PATH
        config.sections["transfers"]["incompletedir"] = DATA_FOLDER_PATH

        core.start()

    def tearDown(self):
        FOLDER_TOKENS_ALLOWED.clear()

        try:
            events.disconnect("queue-network-message", self._network_acceptor)
        except ValueError:
            pass

        core.quit()

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(DATA_FOLDER_PATH, ignore_errors=True)





    def test_folder_contents_response_delivery_failure_retries_request(self):
        downloads = core.downloads
        requested_folder = RequestedFolder("peer", "Music", DATA_FOLDER_PATH)
        requested_folder.token = 123
        downloads._requested_folders["peer"]["Music"] = requested_folder

        with patch.object(events.__class__, "schedule", return_value=456), \
                patch.object(type(core), "send_message_to_peer", return_value=True) as send_message:
            downloads._peer_response_delivery_failed(
                FolderContentsResponse, "peer", ("folder-contents-response", 123, "Music"))

        self.assertTrue(requested_folder.has_retried)
        self.assertEqual(456, requested_folder.request_timer_id)
        self.assertNotEqual(123, requested_folder.token)
        self.assertIn(("peer", requested_folder.token), FOLDER_TOKENS_ALLOWED)
        self.assertEqual("peer", send_message.call_args.args[0])
        self.assertIsInstance(send_message.call_args.args[1], FolderContentsRequest)

    def test_unsent_positive_transfer_response_rolls_back_new_remote_upload_download(self):
        downloads = core.downloads
        transfer = Transfer("peer", "Folder\\remote.mp3", DATA_FOLDER_PATH, 123)
        downloads._append_transfer(transfer)
        response = TransferResponse(allowed=True, token=123)
        response.rollback_info = ("new", transfer)

        downloads._peer_message_unsent(response)

        self.assertIsNone(downloads.get_transfer("peer", "Folder\\remote.mp3"))
        self.assertIsNone(response.rollback_info)



    def test_unsent_queue_upload_retries_lower_output_failure(self):
        downloads = core.downloads
        core.users.login_status = UserStatus.ONLINE
        core.users.statuses["peer"] = UserStatus.ONLINE
        transfer = Transfer("peer", "Folder\\queued.mp3", DATA_FOLDER_PATH, 123)
        downloads._append_transfer(transfer)

        with patch.object(core, "shares", SimpleNamespace(initialized=True)), \
                patch.object(core.__class__, "send_message_to_peer", return_value=True):
            downloads._enqueue_transfer(transfer)

        request = QueueUpload("Folder\\queued.mp3")
        request.username = "peer"

        with patch.object(events.__class__, "schedule", return_value=456):
            downloads._peer_message_unsent(request)

        self.assertIn(transfer, downloads._pending_queue_messages)
        self.assertEqual("Folder\\queued.mp3", downloads._pending_queue_messages[transfer].file)
        self.assertEqual(456, downloads._pending_queue_flush_timer_id)

    def test_unsent_folder_contents_request_retries_immediately(self):
        downloads = core.downloads
        username = "folderpeer"
        folder_path = "Share\\Album"
        old_token = 111

        requested_folder = RequestedFolder(username, folder_path, DATA_FOLDER_PATH)
        requested_folder.token = old_token
        requested_folder.request_timer_id = 123
        downloads._requested_folders[username][folder_path] = requested_folder
        FOLDER_TOKENS_ALLOWED.add((username, old_token))

        request = FolderContentsRequest(folder_path, old_token)
        request.username = username

        with patch.object(events.__class__, "cancel_scheduled") as cancel_scheduled, \
                patch.object(events.__class__, "schedule", return_value=456), \
                patch.object(core.__class__, "send_message_to_peer", return_value=True) as send_message_to_peer:
            downloads._peer_request_unsent(FolderContentsRequest, username, request)

        self.assertTrue(requested_folder.has_retried)
        self.assertEqual(456, requested_folder.request_timer_id)
        self.assertNotEqual(old_token, requested_folder.token)
        self.assertNotIn((username, old_token), FOLDER_TOKENS_ALLOWED)
        self.assertIn((username, requested_folder.token), FOLDER_TOKENS_ALLOWED)
        cancel_scheduled.assert_called_once_with(123)
        send_message_to_peer.assert_called_once()
        self.assertIsInstance(send_message_to_peer.call_args.args[1], FolderContentsRequest)

    def test_unsent_queue_position_request_retries_lower_output_failure(self):
        downloads = core.downloads
        core.users.login_status = UserStatus.ONLINE
        core.users.statuses["peer"] = UserStatus.ONLINE
        transfer = Transfer("peer", "Folder\\queued.mp3", DATA_FOLDER_PATH, 123)
        downloads._append_transfer(transfer)

        with patch.object(core, "shares", SimpleNamespace(initialized=True)), \
                patch.object(core.__class__, "send_message_to_peer", return_value=True):
            downloads._enqueue_transfer(transfer)

        request = PlaceInQueueRequest("Folder\\queued.mp3")
        request.username = "peer"

        with patch.object(events.__class__, "schedule", return_value=789):
            downloads._peer_message_unsent(request)

        self.assertEqual([transfer], list(downloads._queue_position_request_retry_queue))
        self.assertEqual(789, downloads._queue_position_request_retry_timer_id)

    def test_enqueue_folder_grants_token_only_after_peer_queue_accepts(self):
        downloads = core.downloads
        username = "user"
        folder_path = "Album"

        with patch.object(type(events), "schedule", return_value=123), \
                patch.object(type(events), "cancel_scheduled", return_value=None), \
                patch.object(type(core), "send_message_to_peer", return_value=False):
            self.assertFalse(downloads.enqueue_folder(username, folder_path))

        self.assertEqual({}, downloads._requested_folders)
        self.assertEqual(0, len(FOLDER_TOKENS_ALLOWED))

        with patch.object(type(events), "schedule", return_value=124), \
                patch.object(type(events), "cancel_scheduled", return_value=None), \
                patch.object(type(core), "send_message_to_peer", return_value=True):
            self.assertTrue(downloads.enqueue_folder(username, folder_path))

            self.assertIn(username, downloads._requested_folders)
            requested_folder = downloads._requested_folders[username][folder_path]
            self.assertIn((username, requested_folder.token), FOLDER_TOKENS_ALLOWED)
            downloads._remove_requested_folder(requested_folder)

    def test_enqueue_folder_does_not_grant_token_without_timeout(self):
        downloads = core.downloads
        username = "user"
        folder_path = "Album"

        with patch.object(type(events), "schedule", return_value=None):
            self.assertFalse(downloads.enqueue_folder(username, folder_path))

        self.assertEqual({}, downloads._requested_folders)
        self.assertEqual(0, len(FOLDER_TOKENS_ALLOWED))

    def test_retry_download_moves_finished_incomplete_after_folder_error(self):
        downloads = core.downloads
        username = "user"
        virtual_path = "Folder\\song.mp3"
        size = 4
        transfer = Transfer(
            username, virtual_path, DATA_FOLDER_PATH, size, status=TransferStatus.DOWNLOAD_FOLDER_ERROR,
            current_byte_offset=size
        )
        downloads._append_transfer(transfer)
        downloads._fail_transfer(transfer)

        incomplete_file_path = downloads.get_incomplete_download_file_path(username, virtual_path)

        with open(incomplete_file_path, "wb") as file_handle:
            file_handle.write(b"data")

        finished_calls = []
        old_pluginhandler = core.pluginhandler
        old_statistics = core.statistics
        old_notifications = core.notifications
        core.pluginhandler = SimpleNamespace(
            download_finished_notification=lambda *args: finished_calls.append(args)
        )
        core.statistics = SimpleNamespace(append_stat_value=lambda *_args: None)
        core.notifications = SimpleNamespace(show_download_notification=lambda *_args, **_kwargs: None)

        try:
            downloads.retry_download(transfer)
        finally:
            core.pluginhandler = old_pluginhandler
            core.statistics = old_statistics
            core.notifications = old_notifications

        complete_file_path, file_exists = downloads.get_complete_download_file_path(
            username, virtual_path, size, DATA_FOLDER_PATH)

        self.assertTrue(file_exists)
        self.assertFalse(os.path.exists(incomplete_file_path))
        self.assertEqual(TransferStatus.FINISHED, transfer.status)
        self.assertNotIn(virtual_path, downloads.failed_users.get(username, {}))
        self.assertEqual([(username, virtual_path, complete_file_path)], finished_calls)

    def test_file_close_uses_authoritative_final_download_offset(self):
        """A dropped final progress event must not make a completed download abort."""

        username = "finaldownloaduser"
        virtual_path = "Folder\\Final.mp3"
        sock = object()
        download = Transfer(
            username=username, virtual_path=virtual_path, folder_path=DATA_FOLDER_PATH,
            size=100, status=TransferStatus.TRANSFERRING, current_byte_offset=90
        )
        download.last_byte_offset = 90
        download.start_time = 0
        download.sock = sock
        download.token = 123
        core.downloads._append_transfer(download)
        core.downloads.active_users[username][download.token] = download

        old_statistics = core.statistics
        core.statistics = SimpleNamespace(append_stat_value=lambda *_args: None)

        try:
            with patch.object(Downloads, "_finish_transfer") as finish_transfer:
                core.downloads._file_connection_closed(username, download.token, sock, bytes_left=0)
        finally:
            core.statistics = old_statistics

        self.assertEqual(100, download.current_byte_offset)
        finish_transfer.assert_called_once_with(download)

    def test_folder_destination_truncates_long_remote_components(self):
        downloads = core.downloads
        old_limit = Downloads.MAX_DOWNLOAD_FOLDER_COMPONENTS
        Downloads.MAX_DOWNLOAD_FOLDER_COMPONENTS = 4

        try:
            with patch.object(Downloads, "get_basename_byte_limit", return_value=32):
                destination = downloads.get_folder_destination(
                    "user", "Root\\" + ("x" * 256) + "\\" + ("y" * 256),
                    root_folder_path="Root", download_folder_path=DATA_FOLDER_PATH
                )

                parts = os.path.relpath(destination, DATA_FOLDER_PATH).split(os.sep)

                self.assertEqual(3, len(parts))
                self.assertEqual("Root", parts[0])
                self.assertLessEqual(len(parts[1].encode("utf-8")), 32)
                self.assertLessEqual(len(parts[2].encode("utf-8")), 32)

        finally:
            Downloads.MAX_DOWNLOAD_FOLDER_COMPONENTS = old_limit

    def test_folder_destination_caps_component_count(self):
        downloads = core.downloads
        old_limit = Downloads.MAX_DOWNLOAD_FOLDER_COMPONENTS
        Downloads.MAX_DOWNLOAD_FOLDER_COMPONENTS = 2

        try:
            with patch.object(Downloads, "get_basename_byte_limit", return_value=64):
                destination = downloads.get_folder_destination(
                    "user", "Root\\a\\b\\c\\d", root_folder_path="Root",
                    download_folder_path=DATA_FOLDER_PATH
                )

                parts = os.path.relpath(destination, DATA_FOLDER_PATH).split(os.sep)

                self.assertEqual(3, len(parts))
                self.assertEqual(["Root", "a"], parts[:2])
                self.assertTrue(parts[2].startswith("("))

        finally:
            Downloads.MAX_DOWNLOAD_FOLDER_COMPONENTS = old_limit

    def test_finished_download_commands_are_batched(self):
        downloads = core.downloads
        config.sections["transfers"]["afterfinish"] = "echo $"
        config.sections["notifications"]["notification_popup_file"] = False

        executed = []

        with patch.object(Downloads, "MAX_FINISHED_COMMANDS_PER_TICK", 2), \
                patch.object(Downloads, "_schedule_finished_commands", lambda _self: None), \
                patch("pynicotine.downloads.execute_command",
                      side_effect=lambda command, target_path, **_kwargs: executed.append((command, target_path))):
            for index in range(5):
                downloads._file_downloaded_actions("user", f"/tmp/file{index}.mp3")

            self.assertEqual(5, len(downloads._finished_command_queue))
            downloads._process_finished_commands()
            self.assertEqual(2, len(executed))
            self.assertEqual(3, len(downloads._finished_command_queue))

            downloads._process_finished_commands()
            downloads._process_finished_commands()

        self.assertEqual(5, len(executed))
        self.assertFalse(downloads._finished_command_queue)
        self.assertEqual(0, downloads._finished_command_bytes)

    def test_finished_download_command_queue_has_byte_budget(self):
        downloads = core.downloads

        with patch.object(Downloads, "MAX_PENDING_FINISHED_COMMAND_BYTES", 256), \
                patch.object(Downloads, "_schedule_finished_commands", lambda _self: None):
            self.assertFalse(downloads._queue_finished_command("x" * 512, "/tmp/file.mp3"))
            self.assertFalse(downloads._finished_command_queue)

            self.assertTrue(downloads._queue_finished_command("cmd", "a"))
            self.assertFalse(downloads._queue_finished_command("cmd", "b" * 256))
            self.assertEqual(1, len(downloads._finished_command_queue))

    def test_bulk_download_abort_actions_are_batched(self):
        downloads = core.downloads
        transfers = [Transfer(f"bulk{i}", f"file{i}.mp3") for i in range(5)]

        for transfer in transfers:
            transfer.status = TransferStatus.QUEUED

        aborted = []

        with patch.object(Downloads, "MAX_BULK_DOWNLOAD_ACTIONS_PER_TICK", 2), \
                patch.object(Downloads, "_abort_transfer", side_effect=lambda transfer, **_kwargs: aborted.append(transfer)), \
                patch.object(Downloads, "_schedule_bulk_download_actions",
                             lambda _self: setattr(_self, "_bulk_download_action_timer_id", 123)):
            downloads.abort_downloads(transfers, status=TransferStatus.PAUSED)

            self.assertEqual(transfers[:2], aborted)
            self.assertEqual(3, len(downloads._bulk_download_action_queue))
            self.assertEqual(123, downloads._bulk_download_action_timer_id)

            downloads._process_bulk_download_actions()
            self.assertEqual(transfers[:4], aborted)
            self.assertEqual(1, len(downloads._bulk_download_action_queue))

            downloads._process_bulk_download_actions()
            self.assertEqual(transfers, aborted)
            self.assertFalse(downloads._bulk_download_action_queue)

    def test_bulk_download_clear_all_actions_are_batched(self):
        downloads = core.downloads
        downloads.transfers.clear()
        transfers = [Transfer(f"clear{i}", f"file{i}.mp3") for i in range(5)]

        for transfer in transfers:
            transfer.status = TransferStatus.FINISHED
            downloads._append_transfer(transfer)

        cleared = []

        with patch.object(Downloads, "MAX_BULK_DOWNLOAD_ACTIONS_PER_TICK", 2), \
                patch.object(Downloads, "MAX_BULK_DOWNLOAD_SOURCE_SCANS_PER_TICK", 2), \
                patch.object(Downloads, "_clear_transfer", side_effect=lambda transfer, **_kwargs: cleared.append(transfer)), \
                patch.object(Downloads, "_schedule_bulk_download_actions",
                             lambda _self: setattr(_self, "_bulk_download_action_timer_id", 456)):
            downloads.clear_downloads(statuses={TransferStatus.FINISHED})

            self.assertEqual(transfers[:2], cleared)
            self.assertFalse(downloads._bulk_download_action_queue)
            self.assertIsNotNone(downloads._bulk_download_clear_all_state)
            self.assertEqual(456, downloads._bulk_download_action_timer_id)

            downloads._process_bulk_download_actions()
            downloads._process_bulk_download_actions()
            self.assertEqual(transfers, cleared)
            self.assertFalse(downloads._bulk_download_action_queue)
            self.assertIsNone(downloads._bulk_download_clear_all_state)

    def test_bulk_download_clear_all_unfiltered_avoids_seen_key_ledger(self):
        downloads = core.downloads
        downloads.transfers.clear()
        transfers = [Transfer(f"clearall{i}", f"file{i}.mp3") for i in range(5)]

        for transfer in transfers:
            transfer.status = TransferStatus.FINISHED
            downloads._append_transfer(transfer)

        with patch.object(Downloads, "MAX_BULK_DOWNLOAD_ACTIONS_PER_TICK", 2), \
                patch.object(Downloads, "MAX_BULK_DOWNLOAD_SOURCE_SCANS_PER_TICK", 2), \
                patch.object(Downloads, "_schedule_bulk_download_actions",
                             lambda _self: setattr(_self, "_bulk_download_action_timer_id", 789)):
            downloads.clear_downloads()

            self.assertEqual(3, len(downloads.transfers))
            self.assertIsNotNone(downloads._bulk_download_clear_all_state)
            self.assertIsNone(downloads._bulk_download_clear_all_state[2])
            self.assertFalse(downloads._bulk_download_action_queue)

            downloads._process_bulk_download_actions()
            self.assertEqual(1, len(downloads.transfers))

            downloads._process_bulk_download_actions()
            self.assertFalse(downloads.transfers)
            self.assertIsNone(downloads._bulk_download_clear_all_state)

    def test_server_login_watches_failed_users_in_bounded_batches(self):
        downloads = core.downloads
        downloads.failed_users.clear()

        for index in range(5):
            username = f"failed{index}"
            downloads.failed_users[username][f"file{index}.mp3"] = Transfer(username, f"file{index}.mp3")

        watched_users = []

        def watch_user(username, context=None, **_kwargs):
            watched_users.append((username, context))
            return True

        with patch.object(Transfers, "MAX_SERVER_LOGIN_WATCH_USERS_PER_TICK", 2), \
                patch.object(core, "users", SimpleNamespace(watch_user=watch_user)):
            Transfers._server_login(downloads, SimpleNamespace(success=True))

            self.assertEqual(2, len(watched_users))
            self.assertEqual(3, downloads._server_login_watch_remaining)
            self.assertIsNotNone(downloads._server_login_watch_timer_id)

            downloads._process_server_login_watches()
            self.assertEqual(4, len(watched_users))
            self.assertEqual(1, downloads._server_login_watch_remaining)

            downloads._process_server_login_watches()
            self.assertEqual(5, len(watched_users))
            self.assertEqual(0, downloads._server_login_watch_remaining)
            self.assertFalse(downloads._server_login_watch_users)

        self.assertEqual({"downloads"}, {context for _username, context in watched_users})


    def test_server_login_retries_retryable_watch_failure(self):
        downloads = core.downloads
        downloads.failed_users.clear()
        downloads._server_login_watch_timer_id = None
        downloads._server_login_watch_remaining = 0

        downloads.failed_users["failed"]["file.mp3"] = Transfer("failed", "file.mp3")
        calls = []
        scheduled = []

        class FakeUsers:
            last_watch_failure_retryable = False

            def watch_user(self, username, context=None, **_kwargs):
                calls.append((username, context))

                if len(calls) == 1:
                    self.last_watch_failure_retryable = True
                    return False

                self.last_watch_failure_retryable = False
                return True

        fake_users = FakeUsers()

        def fake_schedule(delay, callback):
            scheduled.append((delay, callback))
            return len(scheduled)

        fake_events = SimpleNamespace(schedule=fake_schedule, cancel_scheduled=Mock())

        with patch.object(core, "users", fake_users), \
                patch.object(transfers_module, "events", fake_events):
            Transfers._server_login(downloads, SimpleNamespace(success=True))

            self.assertEqual([("failed", "downloads")], calls)
            self.assertEqual(1, downloads._server_login_watch_remaining)
            self.assertEqual(1, len(scheduled))
            self.assertEqual(Transfers.SERVER_LOGIN_WATCH_RETRY_DELAY, scheduled[0][0])

            _delay, callback = scheduled.pop(0)
            callback()

        self.assertEqual([("failed", "downloads"), ("failed", "downloads")], calls)
        self.assertEqual(0, downloads._server_login_watch_remaining)
        self.assertIsNone(downloads._server_login_watch_timer_id)

    def test_server_disconnect_cancels_pending_server_login_watches(self):
        downloads = core.downloads
        downloads.failed_users.clear()

        for index in range(3):
            username = f"failed{index}"
            downloads.failed_users[username][f"file{index}.mp3"] = Transfer(username, f"file{index}.mp3")

        with patch.object(Transfers, "MAX_SERVER_LOGIN_WATCH_USERS_PER_TICK", 1), \
                patch.object(core, "users", SimpleNamespace(watch_user=lambda *args, **kwargs: True)):
            Transfers._server_login(downloads, SimpleNamespace(success=True))
            self.assertTrue(downloads._server_login_watch_remaining)

            Transfers._server_disconnect(downloads, SimpleNamespace())

        self.assertFalse(downloads._server_login_watch_remaining)
        self.assertFalse(downloads._server_login_watch_users)
        self.assertIsNone(downloads._server_login_watch_timer_id)

    def test_server_disconnect_emits_single_batched_abort_parent_update(self):
        downloads = core.downloads
        downloads.transfers.clear()
        downloads.queued_transfers.clear()
        downloads.queued_users.clear()
        downloads.active_users.clear()
        downloads.failed_users.clear()

        transfer1 = Transfer("peer", "one.mp3", size=1)
        transfer2 = Transfer("peer", "two.mp3", size=2)
        downloads._append_transfer(transfer1)
        downloads._append_transfer(transfer2)
        downloads._enqueue_transfer(transfer1)
        downloads._enqueue_transfer(transfer2)

        single_updates = []
        batch_updates = []

        def on_abort_download(transfer, status, update_parent):
            single_updates.append((transfer, status, update_parent))

        def on_abort_downloads(transfers, status):
            batch_updates.append((list(transfers), status))

        events.connect("abort-download", on_abort_download)
        events.connect("abort-downloads", on_abort_downloads)

        try:
            downloads._server_disconnect(SimpleNamespace())

        finally:
            events.disconnect("abort-download", on_abort_download)
            events.disconnect("abort-downloads", on_abort_downloads)

        # Already-inactive failed transfers are updated through the batched
        # event only, avoiding per-transfer GUI fanout during disconnect.
        self.assertEqual([], single_updates)
        self.assertEqual(1, len(batch_updates))
        self.assertEqual([transfer1, transfer2], batch_updates[0][0])
        self.assertEqual(TransferStatus.USER_LOGGED_OFF, batch_updates[0][1])

    def test_server_disconnect_aborts_transfers_in_bounded_batches(self):
        downloads = core.downloads
        downloads.transfers.clear()
        downloads.queued_transfers.clear()
        downloads.queued_users.clear()
        downloads.active_users.clear()
        downloads.failed_users.clear()

        transfers = [Transfer("peer", f"file{i}.mp3", size=i) for i in range(3)]

        for transfer in transfers:
            downloads._append_transfer(transfer)
            downloads._enqueue_transfer(transfer)

        old_limit = downloads.__class__.MAX_SERVER_DISCONNECT_ABORTS_PER_TICK
        downloads.__class__.MAX_SERVER_DISCONNECT_ABORTS_PER_TICK = 1
        batch_updates = []
        scheduled_callbacks = []

        def on_abort_downloads(aborted_transfers, status):
            batch_updates.append((list(aborted_transfers), status))

        def schedule(_events, delay, callback, callback_args=None, repeat=False):
            scheduled_callbacks.append(callback)
            return len(scheduled_callbacks)

        events.connect("abort-downloads", on_abort_downloads)

        try:
            with patch.object(events.__class__, "schedule", schedule):
                downloads._server_disconnect(SimpleNamespace())

                self.assertEqual([[transfers[0]]], [batch[0] for batch in batch_updates])
                self.assertEqual(2, sum(count for _username, count in downloads._server_disconnect_failed_user_counts))
                self.assertEqual(1, len(scheduled_callbacks))

                while scheduled_callbacks:
                    callback = scheduled_callbacks.pop(0)
                    callback()

            self.assertEqual([[transfer] for transfer in transfers], [batch[0] for batch in batch_updates])
            self.assertEqual(
                [TransferStatus.USER_LOGGED_OFF] * len(transfers),
                [batch[1] for batch in batch_updates]
            )
            self.assertFalse(downloads._server_disconnect_failed_user_counts)
            self.assertFalse(downloads._server_disconnect_transfer_sources)
            self.assertFalse(downloads.queued_users)
            self.assertFalse(downloads.queued_transfers)

        finally:
            downloads.__class__.MAX_SERVER_DISCONNECT_ABORTS_PER_TICK = old_limit
            events.disconnect("abort-downloads", on_abort_downloads)

    def test_load_incomplete_transfer_rows_use_default_status(self):
        """Verify that old/incomplete transfer rows don't inherit a previous status."""

        transfer_rows = [
            ["first_user", "Folder\\First.mp3", ""],
            ["finished_user", "Folder\\Finished.mp3", "", TransferStatus.FINISHED],
            ["next_user", "Folder\\Next.mp3", ""],
        ]

        transfers = list(core.downloads._get_stored_transfers(
            TRANSFERS_FILE_PATH, lambda _path: transfer_rows))

        self.assertEqual(transfers[0].status, TransferStatus.USER_LOGGED_OFF)
        self.assertEqual(transfers[1].status, TransferStatus.FINISHED)
        self.assertEqual(transfers[2].status, TransferStatus.USER_LOGGED_OFF)

    def test_load_transfer_with_malformed_file_attributes(self):
        """Verify that malformed legacy file attribute strings do not abort loading."""

        transfer_rows = [
            ["user", "Folder\\File.mp3", "", TransferStatus.PAUSED, 0, None, "{"],
            ["user2", "Folder\\File2.mp3", "", TransferStatus.PAUSED, 0, None, {None: 1}],
            ["user3", "Folder\\File3.mp3", "", TransferStatus.PAUSED, 0, None, "192", "bad:length"],
        ]

        transfers = list(core.downloads._get_stored_transfers(
            TRANSFERS_FILE_PATH, lambda _path: transfer_rows))

        self.assertEqual(transfers[0].file_attributes, {})
        self.assertEqual(transfers[1].file_attributes, {})
        self.assertEqual(transfers[2].file_attributes, {FileAttribute.BITRATE: 192})

    def test_large_transfer_json_file_streams_rows_without_json_load(self):
        """Huge transfer lists should not be materialized by json.load() before validation."""

        transfers_file_path = os.path.join(DATA_FOLDER_PATH, "large-downloads.json")
        transfer_rows = [
            ["user1", "Folder\\One.mp3", "", TransferStatus.PAUSED, 100, 0],
            ["user2", "Folder\\Two.mp3", "", TransferStatus.FINISHED, 200, 200],
        ]

        with open(transfers_file_path, "w", encoding="utf-8") as file_handle:
            file_handle.write("[")
            for index, transfer_row in enumerate(transfer_rows):
                if index:
                    file_handle.write(",\n")
                file_handle.write(json.dumps(transfer_row))
            file_handle.write("]")

        old_limit = Transfers.MAX_TRANSFER_LIST_JSON_LOAD_BYTES

        try:
            Transfers.MAX_TRANSFER_LIST_JSON_LOAD_BYTES = 1

            with patch("pynicotine.transfers.json.load", side_effect=AssertionError("json.load should not run")):
                loaded_rows = core.downloads._load_transfers_file(transfers_file_path)
                self.assertNotIsInstance(loaded_rows, list)
                transfers = list(core.downloads._get_stored_transfers(
                    transfers_file_path, lambda _path: loaded_rows))

        finally:
            Transfers.MAX_TRANSFER_LIST_JSON_LOAD_BYTES = old_limit
            os.unlink(transfers_file_path)

        self.assertEqual(["Folder\\One.mp3", "Folder\\Two.mp3"], [
            transfer.virtual_path for transfer in transfers
        ])
        self.assertEqual(TransferStatus.FINISHED, transfers[1].status)

    def test_minified_large_transfer_json_file_streams_rows(self):
        """A large minified transfer array should stream rows without whole-file json.load()."""

        transfers_file_path = os.path.join(DATA_FOLDER_PATH, "minified-downloads.json")
        transfer_rows = [
            ["user1", "Folder\\One.mp3", "", TransferStatus.PAUSED, 100, 0],
            ["user2", "Folder\\Two.mp3", "", TransferStatus.FINISHED, 200, 200],
        ]

        with open(transfers_file_path, "w", encoding="utf-8") as file_handle:
            json.dump(transfer_rows, file_handle, separators=(",", ":"))

        old_limit = Transfers.MAX_TRANSFER_LIST_JSON_LOAD_BYTES

        try:
            Transfers.MAX_TRANSFER_LIST_JSON_LOAD_BYTES = 1

            with patch("pynicotine.transfers.json.load", side_effect=AssertionError("json.load should not run")):
                loaded_rows = core.downloads._load_transfers_file(transfers_file_path)
                self.assertNotIsInstance(loaded_rows, list)
                transfers = list(core.downloads._get_stored_transfers(
                    transfers_file_path, lambda _path: loaded_rows))

        finally:
            Transfers.MAX_TRANSFER_LIST_JSON_LOAD_BYTES = old_limit
            os.unlink(transfers_file_path)

        self.assertEqual(["Folder\\One.mp3", "Folder\\Two.mp3"], [
            transfer.virtual_path for transfer in transfers
        ])
        self.assertEqual(TransferStatus.FINISHED, transfers[1].status)

    def test_oversized_legacy_transfer_pickle_is_rejected_before_unpickle(self):
        transfers_file_path = os.path.join(DATA_FOLDER_PATH, "legacy-downloads.pickle")
        old_limit = Transfers.MAX_LEGACY_TRANSFER_FILE_BYTES

        try:
            Transfers.MAX_LEGACY_TRANSFER_FILE_BYTES = 4

            with open(transfers_file_path, "wb") as file_handle:
                file_handle.write(b"not-a-pickle")

            with self.assertRaises(ValueError):
                core.downloads._load_legacy_transfers_file(transfers_file_path)

        finally:
            Transfers.MAX_LEGACY_TRANSFER_FILE_BYTES = old_limit
            os.unlink(transfers_file_path)

    def test_transfer_keys_include_username_boundary(self):
        """Verify users and paths are keyed separately instead of concatenated."""

        core.downloads.transfers.clear()

        first_transfer = Transfer(username="ab", virtual_path="c")
        second_transfer = Transfer(username="a", virtual_path="bc")

        core.downloads._append_transfer(first_transfer)
        core.downloads._append_transfer(second_transfer)

        self.assertEqual(len(core.downloads.transfers), 2)
        self.assertIs(core.downloads.get_transfer("ab", "c"), first_transfer)
        self.assertIs(core.downloads.get_transfer("a", "bc"), second_transfer)

    def test_folder_destination_sanitizes_virtual_path_components(self):
        """Verify folder downloads cannot pass traversal components to the local filesystem."""

        destination = core.downloads.get_folder_destination(
            username="user",
            folder_path="Album\\..\\..\\evil",
            root_folder_path="Album",
            download_folder_path=DATA_FOLDER_PATH
        )

        self.assertEqual(
            destination,
            os.path.join(DATA_FOLDER_PATH, "Album", "_", "_", "evil")
        )

    def test_incomplete_download_open_accepts_regular_file(self):
        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as temp_dir:
            incomplete_file_path = os.path.join(temp_dir, "incomplete.mp3")

            file_handle = core.downloads._open_incomplete_download_file(incomplete_file_path)
            try:
                file_handle.write(b"data")
            finally:
                file_handle.close()

            self.assertEqual(os.path.getsize(incomplete_file_path), 4)

    def test_incomplete_download_open_rejects_symlink(self):
        """Download resume must not follow a stale incomplete-file symlink."""

        if not hasattr(os, "symlink") or not hasattr(os, "O_NOFOLLOW"):
            self.skipTest("symbolic link no-follow checks are not supported on this platform")

        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as temp_dir:
            target_path = os.path.join(temp_dir, "target.mp3")
            symlink_path = os.path.join(temp_dir, "incomplete.mp3")

            with open(target_path, "wb") as file_handle:
                file_handle.write(b"existing")

            try:
                os.symlink(target_path, symlink_path)
            except OSError as error:
                self.skipTest(f"creating symbolic link failed: {error}")

            with self.assertRaises(OSError):
                core.downloads._open_incomplete_download_file(symlink_path)

    def test_incomplete_download_open_rejects_fifo(self):
        """Download resume must not block on a stale incomplete-file FIFO."""

        if not hasattr(os, "mkfifo"):
            self.skipTest("creating FIFOs is not supported on this platform")

        from tempfile import TemporaryDirectory

        with TemporaryDirectory() as temp_dir:
            fifo_path = os.path.join(temp_dir, "incomplete_pipe")

            try:
                os.mkfifo(fifo_path)
            except OSError as error:
                self.skipTest(f"creating FIFO failed: {error}")

            with self.assertRaises(OSError):
                core.downloads._open_incomplete_download_file(fifo_path)

    def test_load_downloads(self):
        """Test loading a downloads.json file."""

        transfers = list(core.downloads.transfers.values())
        self.assertEqual(len(transfers), 17)

        transfer = transfers[16]

        self.assertEqual(transfer.username, "user17")
        self.assertEqual(transfer.virtual_path, "Downloaded\\Song17.mp3")
        self.assertEqual(transfer.status, TransferStatus.USER_LOGGED_OFF)
        self.assertEqual(transfer.size, 0)
        self.assertIsNone(transfer.current_byte_offset)
        self.assertFalse(transfer.file_attributes)

        transfer = transfers[0]

        self.assertEqual(transfer.username, "user1")
        self.assertEqual(transfer.virtual_path, "Downloaded\\Song1.mp3")
        self.assertEqual(transfer.status, TransferStatus.PAUSED)
        self.assertEqual(transfer.size, 10093741)
        self.assertEqual(transfer.current_byte_offset, 5000)
        self.assertEqual(transfer.file_attributes, {
            FileAttribute.BITRATE: 320,
            FileAttribute.DURATION: 252
        })

        # File attribute dictionary represented as string (downgrade from >=3.3.0 to earlier and upgrade again)
        self.assertEqual(transfers[15].file_attributes, {
            FileAttribute.BITRATE: 256,
            FileAttribute.DURATION: 476
        })

        # Legacy bitrate/duration strings (Nicotine+ <3.3.0)
        self.assertEqual(transfers[14].file_attributes, {
            FileAttribute.BITRATE: 128,
            FileAttribute.DURATION: 290
        })

        # Legacy bitrate/duration strings (vbr) (Nicotine+ <3.3.0)
        self.assertEqual(transfers[13].file_attributes, {
            FileAttribute.BITRATE: 238,
            FileAttribute.VBR: 1,
            FileAttribute.DURATION: 173
        })

        # Empty legacy bitrate/duration strings (Nicotine+ <3.3.0)
        self.assertFalse(transfers[12].file_attributes)

    def test_load_downloads_handles_short_and_malformed_rows(self):
        """Verify that older or malformed transfer rows don't corrupt later rows."""

        transfer_rows = [
            ["user-minimal1", "Downloaded\\Minimal1.mp3", ""],
            ["user-finished", "Downloaded\\Finished.mp3", "", TransferStatus.FINISHED, 1000, 1000],
            ["user-minimal2", "Downloaded\\Minimal2.mp3", ""],
            ["user-badattrs", "Downloaded\\BadAttrs.mp3", "", TransferStatus.PAUSED, 1000, 0, "{"],
            ["user-baddict", "Downloaded\\BadDict.mp3", "", TransferStatus.PAUSED, 1000, 0, {"bad": 1}],
            [
                "user-badduration", "Downloaded\\BadDuration.mp3", "", TransferStatus.PAUSED, 1000, 0, "128",
                "bad:duration"
            ]
        ]

        transfers = list(core.downloads._get_stored_transfers(
            transfers_file_path="unused",
            load_func=lambda _path: transfer_rows
        ))

        self.assertEqual(transfers[0].status, TransferStatus.USER_LOGGED_OFF)
        self.assertEqual(transfers[1].status, TransferStatus.FINISHED)
        self.assertEqual(transfers[2].status, TransferStatus.USER_LOGGED_OFF)
        self.assertFalse(transfers[3].file_attributes)
        self.assertFalse(transfers[4].file_attributes)
        self.assertEqual(transfers[5].file_attributes, {FileAttribute.BITRATE: 128})


    def test_load_downloads_rejects_nonfinite_and_gross_persisted_fields(self):
        """Malformed persisted transfer values should not reach GTK uint columns or huge dict keys."""

        old_username_limit = Transfers.MAX_STORED_TRANSFER_USERNAME_CHARS
        old_path_limit = Transfers.MAX_STORED_TRANSFER_PATH_CHARS
        old_folder_limit = Transfers.MAX_STORED_TRANSFER_FOLDER_PATH_CHARS
        old_attr_limit = Transfers.MAX_STORED_TRANSFER_ATTRIBUTE_ITEMS

        try:
            Transfers.MAX_STORED_TRANSFER_USERNAME_CHARS = 10
            Transfers.MAX_STORED_TRANSFER_PATH_CHARS = 20
            Transfers.MAX_STORED_TRANSFER_FOLDER_PATH_CHARS = 20
            Transfers.MAX_STORED_TRANSFER_ATTRIBUTE_ITEMS = 1

            transfer_rows = [
                ["user", "Folder\\Finite.mp3", "", TransferStatus.PAUSED, float("inf"), float("nan")],
                ["user", "Folder\\Huge.mp3", "", TransferStatus.PAUSED, UINT64_LIMIT + 10, UINT64_LIMIT + 20],
                ["user", "Folder\\Attrs.mp3", "", TransferStatus.PAUSED, 100, 0, {
                    str(FileAttribute.BITRATE): float("inf"),
                    str(FileAttribute.DURATION): 999
                }],
                ["u" * 11, "Folder\\SkippedUser.mp3", "", TransferStatus.PAUSED, 1, 0],
                ["user", "F" * 21, "", TransferStatus.PAUSED, 1, 0],
                ["user", "Folder\\SkippedFolder.mp3", "F" * 21, TransferStatus.PAUSED, 1, 0],
            ]

            transfers = list(core.downloads._get_stored_transfers(
                transfers_file_path="unused",
                load_func=lambda _path: transfer_rows
            ))

        finally:
            Transfers.MAX_STORED_TRANSFER_USERNAME_CHARS = old_username_limit
            Transfers.MAX_STORED_TRANSFER_PATH_CHARS = old_path_limit
            Transfers.MAX_STORED_TRANSFER_FOLDER_PATH_CHARS = old_folder_limit
            Transfers.MAX_STORED_TRANSFER_ATTRIBUTE_ITEMS = old_attr_limit

        self.assertEqual(3, len(transfers))
        self.assertEqual(0, transfers[0].size)
        self.assertIsNone(transfers[0].current_byte_offset)
        self.assertEqual(UINT64_LIMIT, transfers[1].size)
        self.assertEqual(UINT64_LIMIT, transfers[1].current_byte_offset)
        self.assertEqual({FileAttribute.BITRATE: 0}, transfers[2].file_attributes)

    def test_save_downloads(self):
        """Verify that the order of the download list at the end of the session
        is identical to the one we loaded.

        Ignore the last four transfers, since their missing properties
        will be added at the end of the session.
        """

        old_transfers = core.downloads._load_transfers_file(TRANSFERS_FILE_PATH)[:12]
        core.downloads._save_transfers(force=True)
        saved_transfers = core.downloads._load_transfers_file(SAVED_TRANSFERS_FILE_PATH)[:12]

        self.assertEqual(old_transfers, saved_transfers)

    def test_enqueue_download_respects_total_download_cap(self):
        """Verify that huge download queues stop accepting additional rows."""

        downloads_class = Downloads
        old_limit = downloads_class.MAX_TOTAL_DOWNLOADS
        downloads_class.MAX_TOTAL_DOWNLOADS = len(core.downloads.transfers)

        try:
            result = core.downloads.enqueue_download("limituser", "Folder\\Limit.mp3", "")
        finally:
            downloads_class.MAX_TOTAL_DOWNLOADS = old_limit
            core.downloads._download_queue_limit_logged = False

        self.assertFalse(result)
        self.assertIsNone(core.downloads.get_transfer("limituser", "Folder\\Limit.mp3"))

    def test_load_downloads_respects_total_download_cap(self):
        """A persisted oversized queue should not bypass the gross download cap on startup."""

        downloads_class = Downloads
        old_limit = downloads_class.MAX_TOTAL_DOWNLOADS
        downloads_class.MAX_TOTAL_DOWNLOADS = 2
        core.downloads.transfers.clear()
        core.downloads.failed_users.clear()

        transfer_rows = [
            ["user1", "Folder\\One.mp3", ""],
            ["user2", "Folder\\Two.mp3", ""],
            ["user3", "Folder\\Three.mp3", ""],
        ]

        try:
            with open(SAVED_TRANSFERS_FILE_PATH, "w", encoding="utf-8") as transfers_file:
                json.dump(transfer_rows, transfers_file)

            core.downloads._load_transfers()

            self.assertEqual(2, len(core.downloads.transfers))
            self.assertIsNotNone(core.downloads.get_transfer("user1", "Folder\\One.mp3"))
            self.assertIsNotNone(core.downloads.get_transfer("user2", "Folder\\Two.mp3"))
            self.assertIsNone(core.downloads.get_transfer("user3", "Folder\\Three.mp3"))

        finally:
            downloads_class.MAX_TOTAL_DOWNLOADS = old_limit
            core.downloads._download_queue_limit_logged = False

    def test_queue_download(self):
        """Verify that new downloads are prepended to the list."""

        config.sections["transfers"]["usernamesubfolders"] = False

        core.downloads.enqueue_download("newuser", "Hello\\Path\\File.mp3", "")
        transfer = list(core.downloads.transfers.values())[-1]

        self.assertEqual(transfer.username, "newuser")
        self.assertEqual(transfer.virtual_path, "Hello\\Path\\File.mp3")
        self.assertEqual(transfer.folder_path, config.data_folder_path)


    def test_queue_upload_is_retained_when_peer_queue_rejects(self):
        """A queued download should retry QueueUpload if the network queue is saturated."""

        schedule_calls = []

        def schedule(_events, delay, callback, callback_args=None, repeat=False):
            schedule_calls.append((delay, callback, callback_args, repeat))
            return len(schedule_calls)

        core.users.login_status = UserStatus.ONLINE
        core.users.statuses["queueduser"] = UserStatus.ONLINE

        with patch.object(core, "shares", SimpleNamespace(initialized=True)), \
                patch.object(core.users, "login_status", UserStatus.ONLINE), \
                patch.dict(core.users.statuses, {"queueduser": UserStatus.ONLINE}), \
                patch.object(core.__class__, "send_message_to_peer", return_value=False), \
                patch.object(events.__class__, "schedule", schedule):
            self.assertTrue(core.downloads.enqueue_download("queueduser", "Folder\\Queued.mp3", ""))

        transfer = core.downloads.get_transfer("queueduser", "Folder\\Queued.mp3")
        self.assertIsNotNone(transfer)
        self.assertIn(transfer, core.downloads._pending_queue_messages)
        self.assertEqual([1], [call[0] for call in schedule_calls])

    def test_pending_queue_upload_is_preserved_when_flush_rejects(self):
        """Shares-ready flush should not drop QueueUpload messages rejected by backpressure."""

        transfer = Transfer(username="flushuser", virtual_path="Folder\\Flush.mp3")
        msg = object()
        core.downloads._pending_queue_messages[transfer] = msg
        schedule_calls = []

        def schedule(_events, delay, callback, callback_args=None, repeat=False):
            schedule_calls.append((delay, callback, callback_args, repeat))
            return len(schedule_calls)

        with patch.object(core.__class__, "send_message_to_peer", return_value=False), \
                patch.object(events.__class__, "schedule", schedule):
            core.downloads._flush_pending_queue_messages()

        self.assertIs(core.downloads._pending_queue_messages[transfer], msg)
        self.assertEqual([1], [call[0] for call in schedule_calls])

    def test_pending_queue_uploads_are_flushed_in_batches(self):
        """Delayed QueueUpload messages shouldn't be emitted in one shares-ready burst."""

        old_limit = core.downloads.__class__.MAX_PENDING_QUEUE_MESSAGES_PER_READY_TICK
        core.downloads.__class__.MAX_PENDING_QUEUE_MESSAGES_PER_READY_TICK = 2

        try:
            for index in range(5):
                transfer = Transfer(username=f"user{index}", virtual_path=f"Folder\\File{index}.mp3")
                core.downloads._pending_queue_messages[transfer] = object()

            sent_messages = []
            scheduled_callbacks = []

            def send_message_to_peer(_core, username, msg):
                sent_messages.append((username, msg))
                return True

            def schedule(_events, delay, callback, callback_args=None, repeat=False):
                scheduled_callbacks.append((delay, callback, callback_args, repeat))
                return len(scheduled_callbacks)

            with patch.object(core.__class__, "send_message_to_peer", send_message_to_peer), \
                    patch.object(events.__class__, "schedule", schedule):
                core.downloads._shares_ready(True)

                self.assertEqual(2, len(sent_messages))
                self.assertEqual(3, len(core.downloads._pending_queue_messages))
                self.assertEqual(1, len(scheduled_callbacks))

                scheduled_callbacks.pop()[1]()
                self.assertEqual(4, len(sent_messages))
                self.assertEqual(1, len(core.downloads._pending_queue_messages))

                scheduled_callbacks.pop()[1]()
                self.assertEqual(5, len(sent_messages))
                self.assertFalse(core.downloads._pending_queue_messages)

        finally:
            core.downloads.__class__.MAX_PENDING_QUEUE_MESSAGES_PER_READY_TICK = old_limit

    def test_total_download_queue_is_bounded(self):
        """A single oversized folder response shouldn't grow the download list without bound."""

        old_limit = core.downloads.__class__.MAX_TOTAL_DOWNLOADS
        core.downloads.__class__.MAX_TOTAL_DOWNLOADS = len(core.downloads.transfers) + 1

        try:
            self.assertTrue(core.downloads.enqueue_download("capuser", "Folder\\One.mp3", ""))
            self.assertFalse(core.downloads.enqueue_download("capuser", "Folder\\Two.mp3", ""))
            self.assertIsNotNone(core.downloads.get_transfer("capuser", "Folder\\One.mp3"))
            self.assertIsNone(core.downloads.get_transfer("capuser", "Folder\\Two.mp3"))

        finally:
            core.downloads.__class__.MAX_TOTAL_DOWNLOADS = old_limit

    def test_user_online_only_resumes_user_logged_off_downloads(self):
        """A user-status update must not requeue unrelated failed download states."""

        username = "retryuser"
        core.users.login_status = UserStatus.ONLINE
        core.users.statuses[username] = UserStatus.ONLINE
        core.users.watch_user(username, context="downloads")
        offline_download = Transfer(username=username, virtual_path="Folder\\Offline.mp3")
        io_download = Transfer(username=username, virtual_path="Folder\\IoError.mp3")

        offline_download.status = TransferStatus.USER_LOGGED_OFF
        io_download.status = TransferStatus.LOCAL_FILE_ERROR

        for download in (offline_download, io_download):
            core.downloads._append_transfer(download)
            core.downloads._fail_transfer(download)

        core.downloads._online_users.discard(username)
        core.users.watch_user(username, context="downloads")
        with patch.object(core, "shares", SimpleNamespace(initialized=True)), \
                patch.object(core.__class__, "send_message_to_peer", lambda *_args, **_kwargs: True):
            core.downloads._user_status(SimpleNamespace(user=username, status=UserStatus.ONLINE))

        self.assertEqual(TransferStatus.QUEUED, offline_download.status)
        self.assertIn(offline_download.virtual_path, core.downloads.queued_users[username])

        self.assertEqual(TransferStatus.LOCAL_FILE_ERROR, io_download.status)
        self.assertIn(io_download.virtual_path, core.downloads.failed_users[username])
        self.assertNotIn(io_download.virtual_path, core.downloads.queued_users.get(username, {}))

    def test_user_status_download_resumes_are_batched(self):
        """A user-status update should not resume every offline download in one tick."""

        downloads_class = core.downloads.__class__
        old_limit = downloads_class.MAX_USER_STATUS_DOWNLOAD_RESUMES_PER_TICK
        downloads_class.MAX_USER_STATUS_DOWNLOAD_RESUMES_PER_TICK = 2
        username = "bulkstatususer"

        try:
            core.users.login_status = UserStatus.ONLINE
            core.users.statuses[username] = UserStatus.ONLINE
            core.users.watch_user(username, context="downloads")

            for index in range(5):
                download = Transfer(username=username, virtual_path=f"Folder\\Offline{index}.mp3")
                download.status = TransferStatus.USER_LOGGED_OFF
                core.downloads._append_transfer(download)
                core.downloads._fail_transfer(download)

            schedule_calls = []

            def schedule(_events, delay, callback, callback_args=None, repeat=False):
                schedule_calls.append((delay, callback, callback_args, repeat))
                return len(schedule_calls)

            with patch.object(core, "shares", SimpleNamespace(initialized=True)), \
                    patch.object(core.__class__, "send_message_to_peer", lambda *_args, **_kwargs: True), \
                    patch.object(events.__class__, "schedule", schedule):
                core.downloads._user_status(SimpleNamespace(user=username, status=UserStatus.ONLINE))

                self.assertEqual(2, len(core.downloads.queued_users[username]))
                self.assertEqual(3, sum(
                    download.status == TransferStatus.USER_LOGGED_OFF
                    for download in core.downloads.failed_users[username].values()
                ))
                self.assertEqual(1, len(schedule_calls))

                schedule_calls.pop(0)[1]()
                self.assertEqual(4, len(core.downloads.queued_users[username]))
                self.assertEqual(1, sum(
                    download.status == TransferStatus.USER_LOGGED_OFF
                    for download in core.downloads.failed_users[username].values()
                ))

                schedule_calls.pop(0)[1]()
                self.assertEqual(5, len(core.downloads.queued_users[username]))
                self.assertFalse(any(
                    download.status == TransferStatus.USER_LOGGED_OFF
                    for download in core.downloads.failed_users.get(username, {}).values()
                ))

        finally:
            downloads_class.MAX_USER_STATUS_DOWNLOAD_RESUMES_PER_TICK = old_limit
            core.downloads._user_status_resume_timer_id = None
            core.downloads._user_status_resume_queue.clear()
            core.downloads._user_status_resume_users.clear()

    def test_user_offline_download_aborts_are_batched(self):
        """A user-status offline update should not abort every failed download in one tick."""

        downloads_class = core.downloads.__class__
        old_limit = downloads_class.MAX_USER_STATUS_DOWNLOAD_OFFLINE_ABORTS_PER_TICK
        downloads_class.MAX_USER_STATUS_DOWNLOAD_OFFLINE_ABORTS_PER_TICK = 2
        username = "bulkofflinestatususer"

        try:
            core.users.login_status = UserStatus.ONLINE
            core.users.statuses[username] = UserStatus.ONLINE
            core.users.watch_user(username, context="downloads")
            core.downloads._online_users.add(username)

            for index in range(5):
                download = Transfer(username=username, virtual_path=f"Folder\\Timeout{index}.mp3")
                download.status = TransferStatus.CONNECTION_TIMEOUT
                core.downloads._append_transfer(download)
                core.downloads._fail_transfer(download)

            schedule_calls = []

            def schedule(_events, delay, callback, callback_args=None, repeat=False):
                schedule_calls.append((delay, callback, callback_args, repeat))
                return len(schedule_calls)

            with patch.object(events.__class__, "schedule", schedule):
                core.downloads._user_status(SimpleNamespace(user=username, status=UserStatus.OFFLINE))

                self.assertEqual(2, sum(
                    download.status == TransferStatus.USER_LOGGED_OFF
                    for download in core.downloads.failed_users[username].values()
                ))
                self.assertEqual(3, sum(
                    download.status == TransferStatus.CONNECTION_TIMEOUT
                    for download in core.downloads.failed_users[username].values()
                ))
                self.assertEqual(1, len(schedule_calls))

                schedule_calls.pop(0)[1]()
                self.assertEqual(4, sum(
                    download.status == TransferStatus.USER_LOGGED_OFF
                    for download in core.downloads.failed_users[username].values()
                ))
                self.assertEqual(1, sum(
                    download.status == TransferStatus.CONNECTION_TIMEOUT
                    for download in core.downloads.failed_users[username].values()
                ))

                schedule_calls.pop(0)[1]()
                self.assertTrue(all(
                    download.status == TransferStatus.USER_LOGGED_OFF
                    for download in core.downloads.failed_users[username].values()
                ))

        finally:
            downloads_class.MAX_USER_STATUS_DOWNLOAD_OFFLINE_ABORTS_PER_TICK = old_limit
            core.downloads._user_status_offline_timer_id = None
            core.downloads._user_status_offline_queue.clear()
            core.downloads._user_status_offline_users.clear()

    def test_retry_failed_connection_downloads_batches_large_failed_sets(self):
        """Connection-retry timers should not process every failed download in one tick."""

        downloads_class = core.downloads.__class__
        old_limit = downloads_class.MAX_FAILED_DOWNLOAD_RETRIES_PER_TICK
        downloads_class.MAX_FAILED_DOWNLOAD_RETRIES_PER_TICK = 2

        try:
            core.users.login_status = UserStatus.ONLINE
            core.users.statuses["retryuser"] = UserStatus.ONLINE
            for index in range(5):
                download = Transfer(username="retryuser", virtual_path=f"Folder\\Timeout{index}.mp3")
                download.status = TransferStatus.CONNECTION_TIMEOUT
                core.downloads._append_transfer(download)
                core.downloads._fail_transfer(download)

            scheduled_callbacks = []

            def schedule(_events, delay, callback, callback_args=None, repeat=False):
                scheduled_callbacks.append((delay, callback, callback_args, repeat))
                return len(scheduled_callbacks)

            with patch.object(core, "shares", SimpleNamespace(initialized=True)), \
                    patch.object(core.__class__, "send_message_to_peer", lambda *_args, **_kwargs: True), \
                    patch.object(events.__class__, "schedule", schedule):
                core.downloads._retry_failed_connection_downloads()

            self.assertEqual(2, len(core.downloads.queued_transfers))
            self.assertEqual(3, len(core.downloads.failed_users["retryuser"]))
            self.assertEqual(1, len(scheduled_callbacks))
            self.assertEqual(0, scheduled_callbacks[0][0])
            self.assertIs(core.downloads._retry_failed_connection_downloads.__func__, scheduled_callbacks[0][1].__func__)

        finally:
            downloads_class.MAX_FAILED_DOWNLOAD_RETRIES_PER_TICK = old_limit

    def test_transfer_autosave_skips_when_clean(self):
        """Idle autosave ticks shouldn't rewrite/fsync a large unchanged transfer list."""

        core.downloads._transfers_dirty = False

        with patch("pynicotine.transfers.write_file_and_backup") as write_file:
            core.downloads._save_transfers()
            write_file.assert_not_called()

        core.downloads.enqueue_download("newuser", "Hello\\Path\\Dirty.mp3", "")

        with patch("pynicotine.transfers.write_file_and_backup", return_value=True) as write_file:
            core.downloads._save_transfers()
            write_file.assert_called_once()

        self.assertFalse(core.downloads._transfers_dirty)

    def test_transfer_autosave_keeps_dirty_flag_when_save_fails(self):
        """A failed persistence attempt should be retried on the next autosave tick."""

        core.downloads._allow_saving_transfers = True
        core.downloads._transfers_dirty = True

        with patch("pynicotine.transfers.write_file_and_backup", return_value=False):
            core.downloads._save_transfers()

        self.assertTrue(core.downloads._transfers_dirty)

    def test_long_basename(self):
        """Verify that the basename in download paths doesn't exceed 255 bytes.

        The basename can be shorter than 255 bytes when a truncated
        multi-byte character is discarded.
        """

        username = "abc"
        finished_folder_path = os.path.join(os.sep, "path", "to", "somewhere", "downloads")

        # Short file extension
        virtual_path = ("Music\\Test\\片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片"
                        "片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片"
                        "片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片.mp3")
        incomplete_file_path = core.downloads.get_incomplete_download_file_path(username, virtual_path)
        incomplete_basename = os.path.basename(incomplete_file_path)

        self.assertLessEqual(
            len(incomplete_basename.encode()),
            core.downloads.get_basename_byte_limit(config.data_folder_path)
        )
        self.assertTrue(incomplete_basename.startswith(
            f"INCOMPLETE{core.downloads._get_incomplete_download_hash(username, virtual_path)}"
        ))
        self.assertTrue(incomplete_basename.endswith(".mp3"))

        # Long file extension
        virtual_path = ("Music\\Test\\abc123456.片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片"
                        "片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片"
                        "片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片")
        incomplete_file_path = core.downloads.get_incomplete_download_file_path(username, virtual_path)
        incomplete_basename = os.path.basename(incomplete_file_path)

        self.assertLessEqual(
            len(incomplete_basename.encode()),
            core.downloads.get_basename_byte_limit(config.data_folder_path)
        )
        self.assertTrue(incomplete_basename.startswith(
            f"INCOMPLETE{core.downloads._get_incomplete_download_hash(username, virtual_path)}."
        ))
        self.assertTrue(incomplete_basename.endswith("片"))

        # Finished download
        basename = ("片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片"
                    "片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片"
                    "片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片.mp3")
        finished_basename = core.downloads.get_download_basename(basename, finished_folder_path)

        self.assertLessEqual(
            len(finished_basename.encode()),
            core.downloads.get_basename_byte_limit(config.data_folder_path)
        )
        self.assertTrue(finished_basename.startswith("片"))
        self.assertTrue(finished_basename.endswith(".mp3"))

        basename = ("abc123456.片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片"
                    "片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片"
                    "片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片片")
        finished_basename = core.downloads.get_download_basename(basename, finished_folder_path)

        self.assertLessEqual(
            len(finished_basename.encode()),
            core.downloads.get_basename_byte_limit(config.data_folder_path)
        )
        self.assertTrue(finished_basename.startswith(".片"))
        self.assertTrue(finished_basename.endswith("片"))

    def test_download_basename_conflict_search_is_bounded_and_truncated(self):
        """Filename conflict suffixes must not loop forever or exceed the filesystem basename limit."""

        old_limit = core.downloads.__class__.MAX_FILENAME_CONFLICT_ATTEMPTS
        core.downloads.__class__.MAX_FILENAME_CONFLICT_ATTEMPTS = 2

        try:
            with patch.object(core.downloads.__class__, "get_basename_byte_limit", lambda _downloads, _folder_path: 12), \
                    patch("pynicotine.downloads.os.path.exists", side_effect=(True, True, False)) as exists:
                basename = core.downloads.get_download_basename(
                    "Folder\\abcdefgh.mp3", DATA_FOLDER_PATH, avoid_conflict=True)

            self.assertEqual("abcd (2).mp3", basename)
            self.assertLessEqual(len(basename.encode()), 12)
            self.assertEqual(3, exists.call_count)

        finally:
            core.downloads.__class__.MAX_FILENAME_CONFLICT_ATTEMPTS = old_limit

    def test_complete_download_path_conflict_search_is_bounded_and_truncated(self):
        """Finished-download path lookup must not probe unbounded numeric suffixes."""

        old_limit = core.downloads.__class__.MAX_FILENAME_CONFLICT_ATTEMPTS
        core.downloads.__class__.MAX_FILENAME_CONFLICT_ATTEMPTS = 2

        class StatResult:
            st_size = 1

        try:
            with patch.object(core.downloads.__class__, "get_basename_byte_limit", lambda _downloads, _folder_path: 12), \
                    patch("pynicotine.downloads.os.path.exists", side_effect=(True, True, False)) as exists, \
                    patch("pynicotine.downloads.os.stat", return_value=StatResult()):
                file_path, file_exists = core.downloads.get_complete_download_file_path(
                    "user", "Folder\\abcdefgh.mp3", 2, DATA_FOLDER_PATH)

            self.assertFalse(file_exists)
            self.assertEqual(os.path.join(DATA_FOLDER_PATH, "abcd (2).mp3"), file_path)
            self.assertLessEqual(len(os.path.basename(file_path).encode()), 12)
            self.assertEqual(3, exists.call_count)

        finally:
            core.downloads.__class__.MAX_FILENAME_CONFLICT_ATTEMPTS = old_limit

    def test_pending_folder_requests_are_bounded(self):
        """Recursive folder requests should not accumulate unlimited outstanding tokens."""

        old_total_limit = core.downloads.__class__.MAX_PENDING_FOLDER_REQUESTS
        old_user_limit = core.downloads.__class__.MAX_PENDING_FOLDER_REQUESTS_PER_USER
        core.downloads.__class__.MAX_PENDING_FOLDER_REQUESTS = 2
        core.downloads.__class__.MAX_PENDING_FOLDER_REQUESTS_PER_USER = 1

        sent_messages = []

        def send_message_to_peer(_core, username, msg):
            sent_messages.append((username, msg))
            return True

        def schedule(_events, delay, callback, callback_args=None, repeat=False):
            return len(sent_messages) + 1

        try:
            with patch.object(core.__class__, "send_message_to_peer", send_message_to_peer), \
                    patch.object(events.__class__, "schedule", schedule), \
                    patch.object(events.__class__, "cancel_scheduled"):
                self.assertTrue(core.downloads.enqueue_folder("user1", "Share\\A"))
                self.assertFalse(core.downloads.enqueue_folder("user1", "Share\\B"))
                self.assertTrue(core.downloads.enqueue_folder("user2", "Share\\A"))
                self.assertFalse(core.downloads.enqueue_folder("user3", "Share\\A"))

            self.assertEqual(2, len(sent_messages))
            self.assertEqual(2, core.downloads._get_num_requested_folders())
            self.assertNotIn("user3", core.downloads._requested_folders)

        finally:
            core.downloads.__class__.MAX_PENDING_FOLDER_REQUESTS = old_total_limit
            core.downloads.__class__.MAX_PENDING_FOLDER_REQUESTS_PER_USER = old_user_limit

    def test_delete_stale_incomplete_downloads_skips_transfer_scan_without_candidates(self):
        """Quit cleanup should not walk a huge transfer list when no incomplete files exist."""

        core.downloads.transfers.clear()
        core.downloads.queued_transfers.clear()
        core.downloads.queued_users.clear()
        core.downloads.active_users.clear()
        core.downloads.failed_users.clear()

        for index in range(1000):
            transfer = Transfer("peer", f"Folder\\Large{index}.mp3", size=1)
            transfer.current_byte_offset = 1
            core.downloads._append_transfer(transfer)

        get_paths_calls = []

        def get_incomplete_download_file_paths(_downloads, username, virtual_path):
            get_paths_calls.append((username, virtual_path))
            return ()

        with patch.object(
            core.downloads.__class__, "get_incomplete_download_file_paths", get_incomplete_download_file_paths
        ):
            core.downloads._delete_stale_incomplete_downloads()

        self.assertFalse(get_paths_calls)

    def test_incomplete_download_paths_include_username_boundary(self):
        """Incomplete temp files for ambiguous username/path pairs remain distinct."""

        first_path = core.downloads.get_incomplete_download_file_path("b", "ca")
        second_path = core.downloads.get_incomplete_download_file_path("ab", "c")
        legacy_first_hash = core.downloads._get_incomplete_download_hash("b", "ca", legacy=True)
        legacy_second_hash = core.downloads._get_incomplete_download_hash("ab", "c", legacy=True)
        legacy_first_path = core.downloads.get_incomplete_download_file_path("b", "ca", legacy=True)

        self.assertEqual(legacy_first_hash, legacy_second_hash)
        self.assertNotEqual(first_path, second_path)
        self.assertNotEqual(first_path, legacy_first_path)
        self.assertEqual(
            set(core.downloads.get_incomplete_download_file_paths("b", "ca")),
            {first_path, legacy_first_path}
        )

    def test_download_folder_destination_sanitizes_remote_components(self):
        """Remote folder names must not escape the chosen download directory."""

        username = "newuser"
        config.sections["transfers"]["usernamesubfolders"] = False

        destination = core.downloads.get_folder_destination(
            username, "Share\\..\\..\\escape", root_folder_path="Share", download_folder_path="downloads")

        self.assertEqual(destination, os.path.join("downloads", "Share", "_", "_", "escape"))
        self.assertEqual(
            os.path.commonpath([os.path.abspath("downloads"), os.path.abspath(destination)]),
            os.path.abspath("downloads")
        )


    def test_download_folder_destination_caps_remote_components(self):
        username = "componentuser"
        config.sections["transfers"]["usernamesubfolders"] = False
        old_components = Downloads.MAX_DOWNLOAD_FOLDER_COMPONENTS
        Downloads.MAX_DOWNLOAD_FOLDER_COMPONENTS = 1

        try:
            destination = core.downloads.get_folder_destination(
                username, "Share\\" + ("a" * 500) + "\\" + ("b" * 500),
                root_folder_path="Share", download_folder_path="downloads")
        finally:
            Downloads.MAX_DOWNLOAD_FOLDER_COMPONENTS = old_components

        relative = os.path.relpath(destination, "downloads")
        components = relative.split(os.sep)
        self.assertEqual(2, len(components))
        self.assertLessEqual(len(components[0].encode("utf-8")), core.downloads.get_basename_byte_limit("downloads"))

    def test_folder_contents_response_requires_matching_token(self):
        """Stale folder responses with the same user/folder must not enqueue downloads."""

        username = "folderuser"
        folder_path = "Share\\Album"
        token = 12345
        initial_transfer_count = len(core.downloads.transfers)

        requested_folder = RequestedFolder(username, folder_path, None)
        requested_folder.token = token
        core.downloads._requested_folders[username][folder_path] = requested_folder
        FOLDER_TOKENS_ALLOWED.add((username, token))

        stale_response = FolderContentsResponse(
            directory=folder_path, token=token + 1, shares={folder_path: [(1, "stale.mp3", 123, None, {})]}
        )
        stale_response.username = username

        core.downloads._folder_contents_response(stale_response)

        self.assertEqual(initial_transfer_count, len(core.downloads.transfers))
        self.assertIn(folder_path, core.downloads._requested_folders[username])
        self.assertIn((username, token), FOLDER_TOKENS_ALLOWED)

        valid_response = FolderContentsResponse(
            directory=folder_path, token=token, shares={folder_path: [(1, "song.mp3", 123, None, {})]}
        )
        valid_response.username = username

        core.downloads._folder_contents_response(valid_response)

        self.assertIsNotNone(core.downloads.get_transfer(username, "Share\\Album\\song.mp3"))
        self.assertNotIn(folder_path, core.downloads._requested_folders[username])
        self.assertNotIn((username, token), FOLDER_TOKENS_ALLOWED)

    def test_folder_contents_response_uses_direct_requested_folder_lookup(self):
        """Huge folder responses should not scan unrelated folders when the requested path is present."""

        username = "folderuser"
        folder_path = "Share\\Album"
        token = 55555

        class NoItemsDict(dict):
            def items(self):
                raise AssertionError("_folder_contents_response should use a direct folder lookup")

        requested_folder = RequestedFolder(username, folder_path, None)
        requested_folder.token = token
        core.downloads._requested_folders[username][folder_path] = requested_folder
        FOLDER_TOKENS_ALLOWED.add((username, token))

        response = SimpleNamespace(
            username=username,
            dir=folder_path,
            token=token,
            list=NoItemsDict({folder_path: [(1, "song.mp3", 123, None, {})]})
        )

        core.downloads._folder_contents_response(response)

        self.assertIsNotNone(core.downloads.get_transfer(username, "Share\\Album\\song.mp3"))
        self.assertNotIn(folder_path, core.downloads._requested_folders[username])
        self.assertNotIn((username, token), FOLDER_TOKENS_ALLOWED)

    def test_large_folder_confirmation_preserves_matching_token(self):
        """The confirmation callback for a large folder should still be able to use the response."""

        username = "folderuser"
        folder_path = "Share\\Big Album"
        token = 54321
        files = [(1, f"song{index}.mp3", 123 + index, None, {}) for index in range(101)]

        requested_folder = RequestedFolder(username, folder_path, None)
        requested_folder.token = token
        requested_folder.request_timer_id = 999
        core.downloads._requested_folders[username][folder_path] = requested_folder
        FOLDER_TOKENS_ALLOWED.add((username, token))

        response = FolderContentsResponse(directory=folder_path, token=token, shares={folder_path: files})
        response.username = username

        emitted_events = []

        def large_folder_callback(*args):
            emitted_events.append(args)

        events.connect("download-large-folder", large_folder_callback)

        with patch.object(events.__class__, "cancel_scheduled") as cancel_scheduled:
            try:
                core.downloads._folder_contents_response(response)

            finally:
                events.disconnect("download-large-folder", large_folder_callback)

        cancel_scheduled.assert_called_once_with(999)
        self.assertIsNone(requested_folder.request_timer_id)

        _username, _folder_path, num_files, callback, callback_args = emitted_events[0]
        self.assertEqual(101, num_files)

        callback(*callback_args)

        self.assertIsNotNone(core.downloads.get_transfer(username, "Share\\Big Album\\song100.mp3"))
        self.assertNotIn(folder_path, core.downloads._requested_folders[username])
        self.assertNotIn((username, token), FOLDER_TOKENS_ALLOWED)

    def test_confirmed_large_folder_downloads_are_enqueued_in_batches(self):
        """A confirmed huge folder should not enqueue every file in one callback turn."""

        username = "folderuser"
        folder_path = "Share\\Huge Album"
        token = 65432
        files = [(1, f"song{index}.mp3", 123 + index, None, {}) for index in range(5)]

        requested_folder = RequestedFolder(username, folder_path, None)
        requested_folder.token = token
        core.downloads._requested_folders[username][folder_path] = requested_folder
        FOLDER_TOKENS_ALLOWED.add((username, token))

        response = FolderContentsResponse(directory=folder_path, token=token, shares={folder_path: files})
        response.username = username

        original_limit = Downloads.MAX_FOLDER_DOWNLOAD_FILES_PER_TICK
        scheduled_callbacks = []

        def schedule(_events, delay, callback, callback_args=None, repeat=False):
            scheduled_callbacks.append((delay, callback, callback_args or ()))
            return len(scheduled_callbacks)

        try:
            Downloads.MAX_FOLDER_DOWNLOAD_FILES_PER_TICK = 2

            with patch.object(events.__class__, "schedule", schedule):
                core.downloads._folder_contents_response(response, check_num_files=False)

                self.assertIsNotNone(core.downloads.get_transfer(username, "Share\\Huge Album\\song0.mp3"))
                self.assertIsNotNone(core.downloads.get_transfer(username, "Share\\Huge Album\\song1.mp3"))
                self.assertIsNone(core.downloads.get_transfer(username, "Share\\Huge Album\\song2.mp3"))
                self.assertEqual(1, len(scheduled_callbacks))

                while scheduled_callbacks:
                    _delay, callback, callback_args = scheduled_callbacks.pop(0)
                    callback(*callback_args)

        finally:
            Downloads.MAX_FOLDER_DOWNLOAD_FILES_PER_TICK = original_limit

        self.assertIsNotNone(core.downloads.get_transfer(username, "Share\\Huge Album\\song4.mp3"))
        self.assertFalse(core.downloads._pending_folder_downloads)
        self.assertIsNone(core.downloads._pending_folder_download_timer_id)
        self.assertNotIn(folder_path, core.downloads._requested_folders.get(username, {}))
        self.assertNotIn((username, token), FOLDER_TOKENS_ALLOWED)

    def test_disconnect_clears_pending_folder_download_batches(self):
        """Folder-download continuation work should not survive disconnect cleanup."""

        username = "folderuser"
        folder_path = "Share\\Huge Album"
        token = 76543
        files = [(1, f"song{index}.mp3", 123 + index, None, {}) for index in range(4)]

        requested_folder = RequestedFolder(username, folder_path, None)
        requested_folder.token = token
        core.downloads._requested_folders[username][folder_path] = requested_folder
        FOLDER_TOKENS_ALLOWED.add((username, token))

        response = FolderContentsResponse(directory=folder_path, token=token, shares={folder_path: files})
        response.username = username

        original_limit = Downloads.MAX_FOLDER_DOWNLOAD_FILES_PER_TICK

        def schedule(_events, delay, callback, callback_args=None, repeat=False):
            return 999

        try:
            Downloads.MAX_FOLDER_DOWNLOAD_FILES_PER_TICK = 1

            with patch.object(events.__class__, "schedule", schedule), \
                    patch.object(events.__class__, "cancel_scheduled") as cancel_scheduled:
                core.downloads._folder_contents_response(response, check_num_files=False)

                self.assertEqual(999, core.downloads._pending_folder_download_timer_id)
                self.assertTrue(core.downloads._pending_folder_downloads)

                core.downloads._server_disconnect(SimpleNamespace())

            cancel_scheduled.assert_any_call(999)

        finally:
            Downloads.MAX_FOLDER_DOWNLOAD_FILES_PER_TICK = original_limit

        self.assertFalse(core.downloads._pending_folder_downloads)
        self.assertIsNone(core.downloads._pending_folder_download_timer_id)

    def test_download_filter_regex_is_cached_between_lookups(self):
        """Folder downloads should not recompile the same filter regexp for every file."""

        config.sections["transfers"]["downloadregexp"] = "Song"
        core.downloads._download_filter_regex = None
        core.downloads._download_filter_regex_pattern = None

        with patch("pynicotine.downloads.re.compile", wraps=re.compile) as compile_regex:
            first_regex = core.downloads._get_download_filter_regex()
            second_regex = core.downloads._get_download_filter_regex()

        self.assertIs(first_regex, second_regex)
        self.assertEqual(1, compile_regex.call_count)

    def test_update_download_filters_caps_filter_count_and_pattern_bytes(self):
        """Huge imported download-filter lists should not build an unbounded composite regexp."""

        old_filters = config.sections["transfers"]["downloadfilters"]
        old_regexp = config.sections["transfers"]["downloadregexp"]
        old_count_limit = Downloads.MAX_DOWNLOAD_FILTERS
        old_byte_limit = Downloads.MAX_DOWNLOAD_FILTER_PATTERN_BYTES

        try:
            config.sections["transfers"]["downloadfilters"] = [("a", False), ("b", False), ("c", False)]
            Downloads.MAX_DOWNLOAD_FILTERS = 2
            Downloads.MAX_DOWNLOAD_FILTER_PATTERN_BYTES = 1024
            core.downloads._download_filter_regex = None
            core.downloads._download_filter_regex_pattern = None
            core.downloads.update_download_filters()

            self.assertIn("a", config.sections["transfers"]["downloadregexp"])
            self.assertIn("b", config.sections["transfers"]["downloadregexp"])
            self.assertNotIn("c", config.sections["transfers"]["downloadregexp"])

            config.sections["transfers"]["downloadfilters"] = [("short", False), ("x" * 128, False)]
            Downloads.MAX_DOWNLOAD_FILTERS = 10
            Downloads.MAX_DOWNLOAD_FILTER_PATTERN_BYTES = 32
            core.downloads.update_download_filters()

            self.assertIn("short", config.sections["transfers"]["downloadregexp"])
            self.assertNotIn("x" * 32, config.sections["transfers"]["downloadregexp"])

        finally:
            config.sections["transfers"]["downloadfilters"] = old_filters
            config.sections["transfers"]["downloadregexp"] = old_regexp
            Downloads.MAX_DOWNLOAD_FILTERS = old_count_limit
            Downloads.MAX_DOWNLOAD_FILTER_PATTERN_BYTES = old_byte_limit
            core.downloads._download_filter_regex = None
            core.downloads._download_filter_regex_pattern = None
            core.downloads._download_filter_limit_logged = False


    def test_update_download_filters_normalizes_rows_before_regex_work(self):
        """Malformed or oversized saved filters should not crash filter rebuilds."""

        old_filters = config.sections["transfers"]["downloadfilters"]
        old_regexp = config.sections["transfers"]["downloadregexp"]
        old_count_limit = Downloads.MAX_DOWNLOAD_FILTERS
        old_item_limit = Downloads.MAX_DOWNLOAD_FILTER_ITEM_BYTES
        old_pattern_limit = Downloads.MAX_DOWNLOAD_FILTER_PATTERN_BYTES

        try:
            Downloads.MAX_DOWNLOAD_FILTERS = 3
            Downloads.MAX_DOWNLOAD_FILTER_ITEM_BYTES = 8
            Downloads.MAX_DOWNLOAD_FILTER_PATTERN_BYTES = 1024
            config.sections["transfers"]["downloadfilters"] = [
                "bad-row",
                ["valid", False],
                ["wild*", True],
                ["x" * 64, False],
                ["too", False, "many"],
                [None, False]
            ]

            core.downloads.update_download_filters()
            downloadregexp = config.sections["transfers"]["downloadregexp"]

            self.assertIn("valid", downloadregexp)
            self.assertIn("wild.*", downloadregexp)
            self.assertNotIn("x" * 16, downloadregexp)

        finally:
            config.sections["transfers"]["downloadfilters"] = old_filters
            config.sections["transfers"]["downloadregexp"] = old_regexp
            Downloads.MAX_DOWNLOAD_FILTERS = old_count_limit
            Downloads.MAX_DOWNLOAD_FILTER_ITEM_BYTES = old_item_limit
            Downloads.MAX_DOWNLOAD_FILTER_PATTERN_BYTES = old_pattern_limit
            core.downloads._download_filter_regex = None
            core.downloads._download_filter_regex_pattern = None
            core.downloads._download_filter_limit_logged = False

    def test_get_limited_download_filters_keeps_only_sorted_prefix(self):
        """Limit retained filter rows before full sort/materialization work."""

        old_count_limit = Downloads.MAX_DOWNLOAD_FILTERS

        try:
            Downloads.MAX_DOWNLOAD_FILTERS = 2
            limited_filters, truncated = Downloads._get_limited_download_filters([
                ("z", False),
                ("a", False),
                ("m", False),
                ["bad", False, "extra"],
                "bad-row"
            ])

            self.assertEqual([("a", False), ("m", False)], limited_filters)
            self.assertTrue(truncated)

        finally:
            Downloads.MAX_DOWNLOAD_FILTERS = old_count_limit

    def test_get_download_filter_regex_ignores_invalid_or_oversized_cached_pattern(self):
        """A corrupt cached regexp in config should not crash download enqueue paths."""

        old_regexp = config.sections["transfers"]["downloadregexp"]
        old_byte_limit = Downloads.MAX_DOWNLOAD_FILTER_PATTERN_BYTES

        try:
            core.downloads._download_filter_regex = None
            core.downloads._download_filter_regex_pattern = None
            config.sections["transfers"]["downloadregexp"] = "("
            self.assertIsNone(core.downloads._get_download_filter_regex())

            Downloads.MAX_DOWNLOAD_FILTER_PATTERN_BYTES = 8
            config.sections["transfers"]["downloadregexp"] = "x" * 128
            self.assertIsNone(core.downloads._get_download_filter_regex())

            config.sections["transfers"]["downloadregexp"] = ".*.*suffix$"
            self.assertIsNone(core.downloads._get_download_filter_regex())

        finally:
            config.sections["transfers"]["downloadregexp"] = old_regexp
            Downloads.MAX_DOWNLOAD_FILTER_PATTERN_BYTES = old_byte_limit
            core.downloads._download_filter_regex = None
            core.downloads._download_filter_regex_pattern = None

    def test_download_filter_rejects_nested_repeat_regexps(self):
        """Reject ReDoS-prone shapes before they run on peer-provided paths."""

        old_filters = config.sections["transfers"]["downloadfilters"]
        old_regexp = config.sections["transfers"]["downloadregexp"]

        try:
            config.sections["transfers"]["downloadfilters"] = [
                ("safe", False),
                ("(a+)+$", True),
                ("nested", False)
            ]

            core.downloads.update_download_filters()
            downloadregexp = config.sections["transfers"]["downloadregexp"]

            self.assertIn("safe", downloadregexp)
            self.assertIn("nested", downloadregexp)
            self.assertNotIn("(a+)+", downloadregexp)

            config.sections["transfers"]["downloadregexp"] = "(a+)+$"
            core.downloads._download_filter_regex = None
            core.downloads._download_filter_regex_pattern = None
            self.assertIsNone(core.downloads._get_download_filter_regex())

        finally:
            config.sections["transfers"]["downloadfilters"] = old_filters
            config.sections["transfers"]["downloadregexp"] = old_regexp
            core.downloads._download_filter_regex = None
            core.downloads._download_filter_regex_pattern = None

    def test_transfer_keys_do_not_collide_by_concatenation(self):
        """Username/path pairs that concatenate to the same string remain distinct."""

        core.downloads.transfers.clear()

        core.downloads.enqueue_download("ab", "c", "")
        core.downloads.enqueue_download("a", "bc", "")

        first_transfer = core.downloads.get_transfer("ab", "c")
        second_transfer = core.downloads.get_transfer("a", "bc")

        self.assertIsNotNone(first_transfer)
        self.assertIsNotNone(second_transfer)
        self.assertIsNot(first_transfer, second_transfer)
        self.assertEqual(2, len(core.downloads.transfers))

    def test_download_folder_destination(self):
        """Verify that the correct download destination is used."""

        username = "newuser"
        folder_path = "Hello\\Path"
        config.sections["transfers"]["usernamesubfolders"] = False
        destination_default = core.downloads.get_folder_destination(username, folder_path)

        core.downloads._requested_folders[username][folder_path] = RequestedFolder(
            username=username, folder_path=folder_path, download_folder_path="Hello Test Path"
        )
        destination_custom = core.downloads.get_folder_destination(username, folder_path)
        core.downloads._requested_folders.clear()

        destination_custom_second = core.downloads.get_folder_destination(
            username, folder_path, download_folder_path="Hello Test Path 2")

        config.sections["transfers"]["usernamesubfolders"] = True
        destination_user = core.downloads.get_folder_destination(username, folder_path)

        folder_path = "Hello"
        destination_root = core.downloads.get_folder_destination(username, folder_path)

        folder_path = "Hello\\Path\\Depth\\Hello Depth Test Path"
        destination_depth = core.downloads.get_folder_destination(username, folder_path)

        self.assertEqual(destination_default, os.path.join(config.data_folder_path, "Path"))
        self.assertEqual(destination_custom, os.path.join("Hello Test Path", "Path"))
        self.assertEqual(destination_custom_second, os.path.join("Hello Test Path 2", "Path"))
        self.assertEqual(destination_user, os.path.join(config.data_folder_path, "newuser", "Path"))
        self.assertEqual(destination_root, os.path.join(config.data_folder_path, "newuser", "Hello"))
        self.assertEqual(destination_depth, os.path.join(config.data_folder_path, "newuser", "Hello Depth Test Path"))

        traversal_parent = core.downloads.get_folder_destination(username, "Hello\\..")
        traversal_absolute = core.downloads.get_folder_destination(username, "Hello\\/tmp")

        self.assertEqual(traversal_parent, os.path.join(config.data_folder_path, "newuser", "_"))
        self.assertEqual(traversal_absolute, os.path.join(config.data_folder_path, "newuser", "tmp"))
        self.assertEqual(
            os.path.commonpath([os.path.abspath(config.data_folder_path), os.path.abspath(traversal_parent)]),
            os.path.abspath(config.data_folder_path)
        )
        self.assertEqual(
            os.path.commonpath([os.path.abspath(config.data_folder_path), os.path.abspath(traversal_absolute)]),
            os.path.abspath(config.data_folder_path)
        )

    def test_download_subfolders(self):
        """Verify that subfolders are downloaded to the correct location."""

        username = "random"
        browsed_user = core.userbrowse.users[username] = BrowsedUser(username)
        browsed_user.public_folders = dict([
            ("share", [
                (1, "root1.mp3", 1000, "", {})
            ]),
            ("share\\Music", [
                (1, "music1.mp3", 1000000, "", {}),
                (1, "music2.mp3", 2000000, "", {})
            ]),
            ("share\\Soulseek", [
                (1, "file1.mp3", 3000000, "", {}),
                (1, "file2.mp3", 4000000, "", {})
            ]),
            ("share\\Soulseek\\folder1", [
                (1, "file3.mp3", 5000000, "", {})
            ]),
            ("share\\Soulseek\\folder1\\sub1", [
                (1, "file4.mp3", 6000000, "", {})
            ]),
            ("share\\Soulseek\\folder2", [
                (1, "file5.mp3", 7000000, "", {})
            ]),
            ("share\\Soulseek\\folder2\\sub2", [
                (1, "file6.mp3", 8000000, "", {})
            ]),
            ("share\\SoulseekSecond", [
                (1, "file7.mp3", 9000000, "", {}),
                (1, "file8.mp3", 10000000, "", {})
            ])
        ])

        # Share root
        target_folder_path = "share"

        core.downloads.transfers.clear()
        core.userbrowse.download_folder(username, target_folder_path, download_folder_path="test", recurse=True)

        transfers = list(core.downloads.transfers.values())
        self.assertEqual(len(transfers), 11)

        self.assertEqual(transfers[10].folder_path, os.path.join("test", "share", "SoulseekSecond"))
        self.assertEqual(transfers[9].folder_path, os.path.join("test", "share", "SoulseekSecond"))
        self.assertEqual(transfers[8].folder_path, os.path.join("test", "share", "Soulseek", "folder2", "sub2"))
        self.assertEqual(transfers[7].folder_path, os.path.join("test", "share", "Soulseek", "folder2"))
        self.assertEqual(transfers[6].folder_path, os.path.join("test", "share", "Soulseek", "folder1", "sub1"))
        self.assertEqual(transfers[5].folder_path, os.path.join("test", "share", "Soulseek", "folder1"))
        self.assertEqual(transfers[4].folder_path, os.path.join("test", "share", "Soulseek"))
        self.assertEqual(transfers[3].folder_path, os.path.join("test", "share", "Soulseek"))
        self.assertEqual(transfers[2].folder_path, os.path.join("test", "share", "Music"))
        self.assertEqual(transfers[1].folder_path, os.path.join("test", "share", "Music"))
        self.assertEqual(transfers[0].folder_path, os.path.join("test", "share"))

        # Share subfolder
        target_folder_path = "share\\Soulseek"

        core.downloads.transfers.clear()
        core.userbrowse.download_folder(username, target_folder_path, download_folder_path="test2", recurse=True)

        transfers = list(core.downloads.transfers.values())
        self.assertEqual(len(transfers), 6)

        self.assertEqual(transfers[5].folder_path, os.path.join("test2", "Soulseek", "folder2", "sub2"))
        self.assertEqual(transfers[4].folder_path, os.path.join("test2", "Soulseek", "folder2"))
        self.assertEqual(transfers[3].folder_path, os.path.join("test2", "Soulseek", "folder1", "sub1"))
        self.assertEqual(transfers[2].folder_path, os.path.join("test2", "Soulseek", "folder1"))
        self.assertEqual(transfers[1].folder_path, os.path.join("test2", "Soulseek"))
        self.assertEqual(transfers[0].folder_path, os.path.join("test2", "Soulseek"))

    def test_cross_device_finished_move_uses_compatibility_copy_for_small_files(self):
        """Small cross-device completion moves are still allowed for compatibility."""

        transfer = Transfer("moveuser", "Folder\\Small.mp3", DATA_FOLDER_PATH, size=10)
        incomplete_file_path = os.path.join(DATA_FOLDER_PATH, "INCOMPLETE-small").encode("utf-8")

        def replace(_source, _destination):
            raise OSError(errno.EXDEV, "Invalid cross-device link")

        with patch("pynicotine.downloads.os.replace", side_effect=replace), \
                patch("pynicotine.downloads.os.path.getsize", return_value=10), \
                patch("pynicotine.downloads.shutil.move") as move_file, \
                patch.object(Downloads, "_abort_transfer") as abort_transfer:
            download_file_path = core.downloads._move_finished_transfer(transfer, incomplete_file_path)

        self.assertEqual(os.path.join(DATA_FOLDER_PATH, "Small.mp3"), download_file_path)
        move_file.assert_called_once()
        abort_transfer.assert_not_called()

    def test_cross_device_finished_move_rejects_gross_synchronous_copy(self):
        """A huge EXDEV fallback must not copy synchronously in the main/core path."""

        old_limit = Downloads.MAX_SYNCHRONOUS_CROSS_DEVICE_MOVE_BYTES
        Downloads.MAX_SYNCHRONOUS_CROSS_DEVICE_MOVE_BYTES = 10
        transfer = Transfer("moveuser", "Folder\\Huge.mp3", DATA_FOLDER_PATH, size=11)
        incomplete_file_path = os.path.join(DATA_FOLDER_PATH, "INCOMPLETE-huge").encode("utf-8")

        def replace(_source, _destination):
            raise OSError(errno.EXDEV, "Invalid cross-device link")

        notification_calls = []
        notifications = SimpleNamespace(
            show_download_notification=lambda *args, **kwargs: notification_calls.append((args, kwargs))
        )

        try:
            with patch("pynicotine.downloads.os.replace", side_effect=replace), \
                    patch("pynicotine.downloads.os.path.getsize", return_value=11), \
                    patch("pynicotine.downloads.shutil.move") as move_file, \
                    patch.object(Downloads, "_abort_transfer") as abort_transfer, \
                    patch.object(core, "notifications", notifications):
                download_file_path = core.downloads._move_finished_transfer(transfer, incomplete_file_path)

        finally:
            Downloads.MAX_SYNCHRONOUS_CROSS_DEVICE_MOVE_BYTES = old_limit

        self.assertIsNone(download_file_path)
        move_file.assert_not_called()
        abort_transfer.assert_called_once_with(transfer, status=TransferStatus.DOWNLOAD_FOLDER_ERROR)
        self.assertEqual(1, len(notification_calls))

    def test_oversized_incomplete_download_restarts_instead_of_finishing(self):
        """A stale partial file larger than the expected size must not be moved as complete."""

        username = "resumeuser"
        virtual_path = "Folder\\Song.mp3"
        transfer = Transfer(username, virtual_path, DATA_FOLDER_PATH, size=10)

        core.downloads._append_transfer(transfer)
        core.downloads._activate_transfer(transfer, token=321)

        incomplete_file_path = core.downloads.get_incomplete_download_file_path(username, virtual_path)
        os.makedirs(os.path.dirname(incomplete_file_path), exist_ok=True)

        with open(incomplete_file_path, "wb") as file_handle:
            file_handle.write(b"x" * 20)

        msg = FileTransferInit(token=321)
        msg.username = username
        msg.sock = object()
        msg.is_outgoing = False

        class DummyStatistics:
            @staticmethod
            def append_stat_value(_stat_id, _stat_value):
                return None

        class DummyPluginHandler:
            @staticmethod
            def download_started_notification(_username, _virtual_path, _file_path):
                return None

        with patch.object(core.__class__, "send_message_to_network_thread") as send_message_to_network_thread, \
                patch.object(core.__class__, "send_message_to_peer") as send_message_to_peer, \
                patch.object(core, "statistics", DummyStatistics()), \
                patch.object(core, "pluginhandler", DummyPluginHandler()):
            core.downloads._file_transfer_init(msg)

        self.assertEqual(TransferStatus.TRANSFERRING, transfer.status)
        self.assertEqual(0, transfer.current_byte_offset)
        self.assertEqual(10, transfer.size)
        self.assertEqual(0, os.path.getsize(incomplete_file_path))
        self.assertEqual(1, send_message_to_network_thread.call_count)
        self.assertEqual(1, send_message_to_peer.call_count)

        transfer.file_handle.close()
        transfer.file_handle = None

    def test_file_transfer_init_aborts_when_download_reader_cannot_be_queued(self):
        username = "readerrejectuser"
        virtual_path = "Folder\\Song.mp3"
        transfer = Transfer(username, virtual_path, DATA_FOLDER_PATH, size=10)

        core.downloads._append_transfer(transfer)
        core.downloads._activate_transfer(transfer, token=777)

        msg = FileTransferInit(token=777)
        msg.username = username
        msg.sock = object()
        msg.is_outgoing = False

        class DummyStatistics:
            @staticmethod
            def append_stat_value(_stat_id, _stat_value):
                return None

        class DummyPluginHandler:
            download_started_notification = Mock()

        with patch.object(core.__class__, "send_message_to_network_thread", return_value=False) as send_network, \
                patch.object(core.__class__, "send_message_to_peer") as send_peer, \
                patch.object(core, "statistics", DummyStatistics()), \
                patch.object(core, "pluginhandler", DummyPluginHandler()):
            core.downloads._file_transfer_init(msg)

        self.assertEqual(TransferStatus.CONNECTION_CLOSED, transfer.status)
        self.assertIsNone(transfer.file_handle)
        self.assertIsNone(transfer.sock)
        self.assertIn(virtual_path, core.downloads.failed_users[username])
        self.assertEqual(2, send_network.call_count)
        send_peer.assert_not_called()
        DummyPluginHandler.download_started_notification.assert_not_called()

    def test_file_transfer_init_aborts_when_file_offset_cannot_be_queued(self):
        username = "offsetrejectuser"
        virtual_path = "Folder\\Song.mp3"
        transfer = Transfer(username, virtual_path, DATA_FOLDER_PATH, size=10)

        core.downloads._append_transfer(transfer)
        core.downloads._activate_transfer(transfer, token=778)

        msg = FileTransferInit(token=778)
        msg.username = username
        msg.sock = object()
        msg.is_outgoing = False

        class DummyStatistics:
            @staticmethod
            def append_stat_value(_stat_id, _stat_value):
                return None

        class DummyPluginHandler:
            download_started_notification = Mock()

        with patch.object(core.__class__, "send_message_to_network_thread", return_value=True) as send_network, \
                patch.object(core.__class__, "send_message_to_peer", return_value=False) as send_peer, \
                patch.object(core, "statistics", DummyStatistics()), \
                patch.object(core, "pluginhandler", DummyPluginHandler()):
            core.downloads._file_transfer_init(msg)

        self.assertEqual(TransferStatus.CONNECTION_CLOSED, transfer.status)
        self.assertIsNone(transfer.file_handle)
        self.assertIsNone(transfer.sock)
        self.assertIn(virtual_path, core.downloads.failed_users[username])
        self.assertEqual(2, send_network.call_count)
        send_peer.assert_called_once()
        DummyPluginHandler.download_started_notification.assert_not_called()

    def test_folder_finished_check_uses_pending_download_index(self):
        """Folder-completion checks should be O(1), not scan all transfers per finished file."""

        downloads = core.downloads
        downloads.transfers.clear()
        downloads.queued_transfers.clear()
        downloads.queued_users.clear()
        downloads.active_users.clear()
        downloads.failed_users.clear()
        downloads._pending_download_folder_counts.clear()
        downloads._pending_download_folder_transfer_keys.clear()

        username = "folderindexuser"
        folder_path = os.path.join(DATA_FOLDER_PATH, "album-folder")
        core.users.login_status = UserStatus.ONLINE
        core.users.statuses[username] = UserStatus.ONLINE
        config.sections["notifications"]["notification_popup_folder"] = False

        old_shares = core.shares
        core.shares = SimpleNamespace(initialized=True)
        self.addCleanup(setattr, core, "shares", old_shares)

        transfers = [Transfer(username, f"Remote\\File{i}.mp3", folder_path, size=1) for i in range(3)]

        with patch.object(Downloads, "get_complete_download_file_path",
                          return_value=(os.path.join(DATA_FOLDER_PATH, "missing.mp3"), False)):
            for transfer in transfers:
                downloads._append_transfer(transfer)
                self.assertTrue(downloads._enqueue_transfer(transfer, bypass_filter=True))

        self.assertEqual(3, downloads._pending_download_folder_counts[(username, folder_path)])

        finished_folders = []

        def on_folder_download_finished(finished_folder_path):
            finished_folders.append(finished_folder_path)

        events.connect("folder-download-finished", on_folder_download_finished)

        try:
            downloads._folder_downloaded_actions(username, folder_path)
            self.assertEqual([], finished_folders)

            downloads._dequeue_transfer(transfers[0])
            downloads._dequeue_transfer(transfers[1])
            downloads._folder_downloaded_actions(username, folder_path)
            self.assertEqual([], finished_folders)
            self.assertEqual(1, downloads._pending_download_folder_counts[(username, folder_path)])

            downloads._dequeue_transfer(transfers[2])
            downloads._folder_downloaded_actions(username, folder_path)
            self.assertEqual([folder_path], finished_folders)
            self.assertNotIn((username, folder_path), downloads._pending_download_folder_counts)

        finally:
            events.disconnect("folder-download-finished", on_folder_download_finished)

    def test_transfer_request_rejects_duplicate_active_token(self):
        """A peer must not remap an active transfer token onto a different download."""

        username = "tokenuser"
        core.users.login_status = UserStatus.ONLINE
        core.users.statuses[username] = UserStatus.ONLINE
        active = Transfer(username, "Folder\\Active.mp3", DATA_FOLDER_PATH, size=1)
        queued = Transfer(username, "Folder\\Queued.mp3", DATA_FOLDER_PATH, size=2)
        old_shares = core.shares
        core.shares = SimpleNamespace(initialized=True)
        self.addCleanup(setattr, core, "shares", old_shares)

        core.downloads._append_transfer(active)
        core.downloads._activate_transfer(active, token=42)
        core.downloads._append_transfer(queued)

        with patch.object(Downloads, "get_complete_download_file_path",
                          return_value=(os.path.join(DATA_FOLDER_PATH, "tokenuser-queued.mp3"), False)):
            self.assertTrue(core.downloads._enqueue_transfer(queued, bypass_filter=True))

        msg = TransferRequest(
            direction=TransferDirection.UPLOAD,
            token=42,
            file=queued.virtual_path,
            filesize=queued.size
        )
        msg.username = username

        response = core.downloads._transfer_request_downloads(msg)

        self.assertFalse(response.allowed)
        self.assertEqual(TransferRejectReason.CANCELLED, response.reason)
        self.assertIs(core.downloads.active_users[username][42], active)
        self.assertIn(queued, core.downloads.queued_transfers)
        self.assertIsNone(queued.token)

    def test_transfer_request_response_rejection_restores_queued_download(self):
        """Do not leave a queued download active if the acceptance response was not queued."""

        username = "queueuser"
        virtual_path = "Folder\\Queued.mp3"
        core.users.login_status = UserStatus.ONLINE
        core.users.statuses[username] = UserStatus.ONLINE

        old_shares = core.shares
        core.shares = SimpleNamespace(initialized=True)
        self.addCleanup(setattr, core, "shares", old_shares)

        download = Transfer(username, virtual_path, DATA_FOLDER_PATH, size=2)
        core.downloads._append_transfer(download)

        with patch.object(Downloads, "get_complete_download_file_path",
                          return_value=(os.path.join(DATA_FOLDER_PATH, "queued.mp3"), False)), \
                patch.object(type(core), "send_message_to_peer", return_value=True):
            self.assertTrue(core.downloads._enqueue_transfer(download, bypass_filter=True))

        msg = TransferRequest(
            direction=TransferDirection.UPLOAD,
            token=777,
            file=virtual_path,
            filesize=99
        )
        msg.username = username

        with patch.object(type(core), "send_message_to_peer", return_value=False) as send_message_to_peer:
            core.downloads._transfer_request(msg)

        self.assertEqual(1, send_message_to_peer.call_count)
        response = send_message_to_peer.call_args.args[1]
        self.assertTrue(response.allowed)
        self.assertIn(download, core.downloads.queued_transfers)
        self.assertNotIn(777, core.downloads.active_users.get(username, {}))
        self.assertEqual(TransferStatus.QUEUED, download.status)
        self.assertIsNone(download.token)
        self.assertEqual(2, download.size)
        self.assertFalse(download.size_changed)

    def test_transfer_request_response_rejection_clears_remote_upload_download(self):
        """Do not retain a remotely initiated download if the acceptance response was not queued."""

        username = "remoteuser"
        virtual_path = "RemoteRootFile.mp3"

        transfer_config = config.sections["transfers"]
        original_settings = {
            "remotedownloads": transfer_config["remotedownloads"],
            "uploadallowed": transfer_config["uploadallowed"],
            "uploaddir": transfer_config["uploaddir"]
        }
        self.addCleanup(transfer_config.update, original_settings)

        transfer_config["remotedownloads"] = True
        transfer_config["uploadallowed"] = 1
        transfer_config["uploaddir"] = DATA_FOLDER_PATH

        msg = TransferRequest(
            direction=TransferDirection.UPLOAD,
            token=123,
            file=virtual_path,
            filesize=1234
        )
        msg.username = username

        with patch.object(type(core), "send_message_to_peer", return_value=False) as send_message_to_peer:
            core.downloads._transfer_request(msg)

        self.assertEqual(1, send_message_to_peer.call_count)
        self.assertTrue(send_message_to_peer.call_args.args[1].allowed)
        self.assertIsNone(core.downloads.get_transfer(username, virtual_path))
        self.assertNotIn(username, core.downloads.active_users)

    def test_receive_remote_upload_with_root_file(self):
        """Verify that a remote upload request for a root file is accepted safely."""

        username = "remoteuser"
        virtual_path = "RemoteRootFile.mp3"

        transfer_config = config.sections["transfers"]
        original_settings = {
            "remotedownloads": transfer_config["remotedownloads"],
            "uploadallowed": transfer_config["uploadallowed"],
            "uploaddir": transfer_config["uploaddir"]
        }
        self.addCleanup(transfer_config.update, original_settings)

        transfer_config["remotedownloads"] = True
        transfer_config["uploadallowed"] = 1
        transfer_config["uploaddir"] = DATA_FOLDER_PATH

        msg = TransferRequest(
            direction=TransferDirection.UPLOAD,
            token=123,
            file=virtual_path,
            filesize=1234
        )
        msg.username = username

        response = core.downloads._transfer_request_downloads(msg)
        transfer = core.downloads.get_transfer(username, virtual_path)

        self.assertTrue(response.allowed)
        self.assertEqual(transfer.folder_path, os.path.join(DATA_FOLDER_PATH, username))

    def test_request_queue_positions_batches_large_download_queues(self):
        """Verify that large download queues are sampled over multiple timer ticks."""

        downloads_class = core.downloads.__class__
        old_limit = downloads_class.MAX_QUEUE_POSITION_REQUESTS_PER_TICK
        downloads_class.MAX_QUEUE_POSITION_REQUESTS_PER_TICK = 2
        core.downloads.queued_transfers.clear()

        try:
            transfers = [Transfer(f"user{i}", f"Folder\\Song{i}.mp3") for i in range(5)]

            for transfer in transfers:
                transfer.legacy_attempt = False
                core.downloads.queued_transfers[transfer] = None

            with patch.object(core.__class__, "send_message_to_peer") as send_message_to_peer:
                core.downloads._request_queue_positions()
                first_usernames = [call.args[0] for call in send_message_to_peer.call_args_list]

                send_message_to_peer.reset_mock()
                core.downloads._request_queue_positions()
                second_usernames = [call.args[0] for call in send_message_to_peer.call_args_list]

                send_message_to_peer.reset_mock()
                core.downloads._request_queue_positions()
                third_usernames = [call.args[0] for call in send_message_to_peer.call_args_list]

        finally:
            downloads_class.MAX_QUEUE_POSITION_REQUESTS_PER_TICK = old_limit
            core.downloads.queued_transfers.clear()
            core.downloads._queue_position_request_iterator = None

        self.assertEqual(first_usernames, ["user0", "user1"])
        self.assertEqual(second_usernames, ["user2", "user3"])
        self.assertEqual(third_usernames, ["user4", "user0"])

    def test_request_queue_position_retries_when_network_queue_rejects(self):
        downloads = core.downloads
        downloads_class = downloads.__class__
        old_limit = downloads_class.MAX_QUEUE_POSITION_REQUESTS_PER_TICK
        downloads_class.MAX_QUEUE_POSITION_REQUESTS_PER_TICK = 2
        downloads.queued_transfers.clear()
        downloads.queued_users.clear()
        downloads._queue_position_request_retry_queue.clear()
        downloads._queue_position_request_retry_keys.clear()
        downloads._queue_position_request_retry_timer_id = None
        scheduled_callbacks = []

        transfer1 = Transfer("user1", "Folder\\Song1.mp3")
        transfer2 = Transfer("user2", "Folder\\Song2.mp3")

        for transfer in (transfer1, transfer2):
            transfer.legacy_attempt = False
            downloads.queued_transfers[transfer] = None
            downloads.queued_users[transfer.username][transfer.virtual_path] = transfer

        try:
            with patch.object(core.__class__, "send_message_to_peer", side_effect=[False, True]), \
                    patch.object(type(events), "schedule", side_effect=lambda delay, callback: scheduled_callbacks.append((delay, callback)) or 123):
                downloads._request_queue_positions()

                self.assertEqual([transfer1], list(downloads._queue_position_request_retry_queue))
                self.assertEqual(1, len(scheduled_callbacks))
                self.assertEqual(1, scheduled_callbacks[0][0])

                _delay, callback = scheduled_callbacks.pop(0)
                callback()

            self.assertEqual([], list(downloads._queue_position_request_retry_queue))
            self.assertEqual(set(), downloads._queue_position_request_retry_keys)

        finally:
            downloads_class.MAX_QUEUE_POSITION_REQUESTS_PER_TICK = old_limit
            downloads.queued_transfers.clear()
            downloads.queued_users.clear()
            downloads._queue_position_request_iterator = None
            downloads._queue_position_request_retry_queue.clear()
            downloads._queue_position_request_retry_keys.clear()
            downloads._queue_position_request_retry_timer_id = None

    def test_queue_position_retry_skips_download_removed_before_retry(self):
        downloads = core.downloads
        downloads._queue_position_request_retry_queue.clear()
        downloads._queue_position_request_retry_keys.clear()
        transfer = Transfer("user", "Folder\\Song.mp3")
        transfer.legacy_attempt = False
        downloads._queue_queue_position_request_retry(transfer)

        with patch.object(core.__class__, "send_message_to_peer") as send_message_to_peer:
            downloads._process_queue_position_request_retries()

        send_message_to_peer.assert_not_called()
        self.assertEqual([], list(downloads._queue_position_request_retry_queue))
        self.assertEqual(set(), downloads._queue_position_request_retry_keys)

    def test_delete_stale_incomplete_downloads(self):
        """Verify that only files matching the pattern for incomplete downloads are deleted."""

        file_names = (
            ("test_file.txt", True),
            ("test_file.mp3", True),
            ("INCOMPLETEsomefilename.mp3", True),
            ("INCOMPLETE435ed7e9f07f740abf511a62c00eef6e", True),
            ("INCOMPLETE435ed7e9f07f740abf511a62c00eef6efile.mp3", False)
        )

        for basename, _exists in file_names:
            file_path = os.path.join(DATA_FOLDER_PATH, basename)

            with open(file_path, "wb"):
                pass

            self.assertTrue(os.path.isfile(file_path))

        core.downloads._delete_stale_incomplete_downloads()

        for basename, exists in file_names:
            self.assertEqual(os.path.isfile(os.path.join(DATA_FOLDER_PATH, basename)), exists)
