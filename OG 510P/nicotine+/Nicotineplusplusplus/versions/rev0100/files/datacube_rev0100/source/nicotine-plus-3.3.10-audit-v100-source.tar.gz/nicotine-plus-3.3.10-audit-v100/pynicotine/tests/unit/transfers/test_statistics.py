# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007

from unittest import TestCase

import pynicotine.transfers as transfers_module
from pynicotine.config import config
from pynicotine.transfers import Statistics


class DummyEvents:

    def __init__(self):
        self.callbacks = []
        self.cancelled = []
        self.emitted = []
        self.next_id = 0

    def connect(self, *_args):
        pass

    def schedule(self, delay, callback, callback_args=None, repeat=False):
        self.next_id += 1
        self.callbacks.append((self.next_id, callback, callback_args or ()))
        return self.next_id

    def cancel_scheduled(self, event_id):
        self.cancelled.append(event_id)

    def emit(self, *args):
        self.emitted.append(args)

    def run_next(self):
        _event_id, callback, callback_args = self.callbacks.pop(0)
        callback(*callback_args)


class patch_transfers_events:

    def __init__(self, new_events):
        self.new_events = new_events
        self.old_events = None

    def __enter__(self):
        self.old_events = transfers_module.events
        transfers_module.events = self.new_events

    def __exit__(self, *_args):
        transfers_module.events = self.old_events


class StatisticsTest(TestCase):

    def setUp(self):
        self.old_defaults = config.defaults.copy()
        self.old_sections = config.sections.copy()
        config.defaults["statistics"] = {
            "downloaded_size": 0,
            "uploaded_size": 0,
            "since_timestamp": 0
        }
        config.sections["statistics"] = {
            "downloaded_size": 0,
            "uploaded_size": 0,
            "since_timestamp": 0
        }

    def tearDown(self):
        config.defaults.clear()
        config.defaults.update(self.old_defaults)
        config.sections.clear()
        config.sections.update(self.old_sections)

    @staticmethod
    def _new_statistics():
        stats = object.__new__(Statistics)
        stats.session_stats = {
            "downloaded_size": 0,
            "uploaded_size": 0,
            "since_timestamp": 0
        }
        stats._pending_stat_update_queue = transfers_module.deque()
        stats._pending_stat_update_ids = set()
        stats._pending_stat_update_timer_id = None
        stats._stat_update_limit_logged = False
        return stats

    def test_append_stat_value_coalesces_duplicate_update_events(self):
        fake_events = DummyEvents()
        stats = self._new_statistics()

        with patch_transfers_events(fake_events):
            stats.append_stat_value("downloaded_size", 10)
            stats.append_stat_value("downloaded_size", 5)

            self.assertEqual(["downloaded_size"], list(stats._pending_stat_update_queue))
            self.assertEqual([], fake_events.emitted)

            fake_events.run_next()

        self.assertEqual(15, stats.session_stats["downloaded_size"])
        self.assertEqual(15, config.sections["statistics"]["downloaded_size"])
        self.assertEqual([
            ("update-stat", "downloaded_size", 15, 15)
        ], fake_events.emitted)

    def test_stat_update_flush_is_batched(self):
        fake_events = DummyEvents()
        stats = self._new_statistics()
        old_limit = Statistics.MAX_STAT_UPDATES_PER_TICK

        try:
            Statistics.MAX_STAT_UPDATES_PER_TICK = 1

            with patch_transfers_events(fake_events):
                stats.append_stat_value("downloaded_size", 1)
                stats.append_stat_value("uploaded_size", 2)

                self.assertEqual(1, len(fake_events.callbacks))
                fake_events.run_next()

                self.assertEqual([
                    ("update-stat", "downloaded_size", 1, 1)
                ], fake_events.emitted)
                self.assertEqual(["uploaded_size"], list(stats._pending_stat_update_queue))
                self.assertEqual(1, len(fake_events.callbacks))

                fake_events.run_next()

        finally:
            Statistics.MAX_STAT_UPDATES_PER_TICK = old_limit

        self.assertEqual([
            ("update-stat", "downloaded_size", 1, 1),
            ("update-stat", "uploaded_size", 2, 2)
        ], fake_events.emitted)
        self.assertEqual([], list(stats._pending_stat_update_queue))
