# COPYRIGHT (C) 2026 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

import os
import sys
import tempfile

from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock
from unittest.mock import patch

from pynicotine.utils import clean_file
from pynicotine.utils import copy_file_bounded
from pynicotine.utils import execute_command
from pynicotine.utils import factorize
from pynicotine.utils import open_uri
from pynicotine.utils import read_http_response
from pynicotine.utils import replace_text
from pynicotine.utils import write_file_and_backup
from pynicotine import utils


class UtilsTest(TestCase):

    def test_clean_file_avoids_windows_reserved_device_names(self):
        for basename in ("CON", "con.txt", "NUL.tar.gz", "COM1.flac", "LPT9", "COM¹.mp3"):
            self.assertTrue(clean_file(basename).startswith("_"), basename)

    def test_clean_file_keeps_non_reserved_stems(self):
        self.assertEqual("Concert.mp3", clean_file("Concert.mp3"))
        self.assertEqual("LPT10.txt", clean_file("LPT10.txt"))


    def test_copy_file_bounded_copies_regular_files(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            source_path = os.path.join(temp_dir, "source.bin")
            destination_path = os.path.join(temp_dir, "destination.bin")

            with open(source_path, "wb") as file_handle:
                file_handle.write(b"payload")

            copy_file_bounded(source_path, destination_path, max_size=16)

            with open(destination_path, "rb") as file_handle:
                self.assertEqual(b"payload", file_handle.read())

    def test_copy_file_bounded_rejects_oversized_sources(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            source_path = os.path.join(temp_dir, "source.bin")
            destination_path = os.path.join(temp_dir, "destination.bin")

            with open(source_path, "wb") as file_handle:
                file_handle.write(b"payload")

            with self.assertRaises(OSError):
                copy_file_bounded(source_path, destination_path, max_size=3)

            self.assertFalse(os.path.exists(destination_path))

    def test_copy_file_bounded_rejects_symlinks(self):
        if not hasattr(os, "symlink"):
            self.skipTest("platform lacks symlink support")

        with tempfile.TemporaryDirectory() as temp_dir:
            source_path = os.path.join(temp_dir, "source.bin")
            symlink_path = os.path.join(temp_dir, "source-link.bin")
            destination_path = os.path.join(temp_dir, "destination.bin")

            with open(source_path, "wb") as file_handle:
                file_handle.write(b"payload")

            try:
                os.symlink(source_path, symlink_path)
            except (OSError, NotImplementedError):
                self.skipTest("platform cannot create symlinks")

            with self.assertRaises(OSError):
                copy_file_bounded(symlink_path, destination_path, max_size=16)

            self.assertFalse(os.path.exists(destination_path))

    def test_factorize_rejects_non_finite_values(self):
        for value in ("inf", "+inf", "-inf", "1e999", "nan"):
            self.assertEqual((None, 1), factorize(value))

        self.assertEqual((None, 1024 ** 3), factorize("infg"))

    def test_read_http_response_enforces_gross_size_limit(self):
        class FakeResponse:
            def __init__(self, body):
                self.body = body

            def read(self, size=-1):
                if size < 0:
                    return self.body
                return self.body[:size]

        self.assertEqual(b"1234", read_http_response(FakeResponse(b"1234"), max_size=4))

        with self.assertRaises(ValueError):
            read_http_response(FakeResponse(b"12345"), max_size=4)

    def test_open_uri_rejects_gross_url_before_external_open(self):
        old_limit = utils.MAX_OPEN_URI_BYTES

        try:
            utils.MAX_OPEN_URI_BYTES = 16

            with patch("pynicotine.utils._try_open_uri", side_effect=AssertionError("opened gross URL")):
                self.assertFalse(open_uri("https://example.com/" + "x" * 32))

        finally:
            utils.MAX_OPEN_URI_BYTES = old_limit

    def test_open_uri_respects_soulseek_url_rejection(self):
        fake_config = SimpleNamespace(sections={"urls": {"protocols": {}}})
        fake_core = SimpleNamespace(userbrowse=SimpleNamespace(open_soulseek_url=Mock(return_value=False)))

        with patch("pynicotine.config.config", fake_config), patch("pynicotine.core.core", fake_core):
            self.assertFalse(open_uri("slsk://alice/folder"))

        fake_core.userbrowse.open_soulseek_url.assert_called_once_with("slsk://alice/folder")


    def test_write_file_and_backup_preserves_original_when_callback_fails(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "state.json")

            with open(file_path, "w", encoding="utf-8") as file_handle:
                file_handle.write("old")

            def failing_callback(_file_handle):
                raise RuntimeError("boom")

            self.assertFalse(write_file_and_backup(file_path, failing_callback))

            with open(file_path, encoding="utf-8") as file_handle:
                self.assertEqual("old", file_handle.read())

            self.assertFalse(os.path.exists(f"{file_path}.new"))

    def test_write_file_and_backup_replaces_after_new_file_is_written(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            file_path = os.path.join(temp_dir, "state.json")

            with open(file_path, "w", encoding="utf-8") as file_handle:
                file_handle.write("old")

            self.assertTrue(write_file_and_backup(file_path, lambda file_handle: file_handle.write("new")))

            with open(file_path, encoding="utf-8") as file_handle:
                self.assertEqual("new", file_handle.read())

            with open(f"{file_path}.old", encoding="utf-8") as file_handle:
                self.assertEqual("old", file_handle.read())

            self.assertFalse(os.path.exists(f"{file_path}.new"))




    def test_strace_formats_large_arguments_with_caps(self):
        old_args = utils.MAX_STRACE_ARGUMENTS
        old_repr = utils.MAX_STRACE_REPR_BYTES
        old_line = utils.MAX_STRACE_LINE_BYTES

        try:
            utils.MAX_STRACE_ARGUMENTS = 2
            utils.MAX_STRACE_REPR_BYTES = 10
            utils.MAX_STRACE_LINE_BYTES = 40
            call = utils._format_strace_call("func", ("x" * 100, "y" * 100, "z"), {"kw": "v" * 100})

        finally:
            utils.MAX_STRACE_ARGUMENTS = old_args
            utils.MAX_STRACE_REPR_BYTES = old_repr
            utils.MAX_STRACE_LINE_BYTES = old_line

        self.assertLessEqual(len(call.encode("utf-8", "replace")), 40)
        self.assertIn("…", call)

    def test_bounded_debug_repr_handles_bad_repr(self):
        class BadRepr:
            def __repr__(self):
                raise RuntimeError("boom")

        self.assertIn("repr failed", utils._bounded_debug_repr(BadRepr()))

    def test_text_filters_are_bounded(self):
        old_max_patterns = utils.MAX_TEXT_FILTER_PATTERNS
        old_max_pattern_chars = utils.MAX_TEXT_FILTER_PATTERN_CHARS
        old_max_replacement_chars = utils.MAX_TEXT_FILTER_REPLACEMENT_CHARS
        old_max_output_chars = utils.MAX_TEXT_FILTER_OUTPUT_CHARS

        try:
            utils.MAX_TEXT_FILTER_PATTERNS = 2
            utils.MAX_TEXT_FILTER_PATTERN_CHARS = 4
            utils.MAX_TEXT_FILTER_REPLACEMENT_CHARS = 4
            utils.MAX_TEXT_FILTER_OUTPUT_CHARS = 10

            # Third pattern is ignored by the gross pattern cap, and an
            # overlong pattern is ignored instead of spending hot-path work.
            self.assertEqual("BBBB c d", replace_text("a c d", {"a": "BBBBBB", "toolong": "x", "d": "z"}))

            censored = utils.censor_text("bad ugly later", ["bad", "ugly", "later"])
            self.assertEqual("*** **** later", censored)

            self.assertEqual("BBBBBBBBBB", replace_text("aaa", {"a": "BBBBBB"}))

            # Empty patterns are ignored instead of expanding/reprocessing every
            # character on hot chat paths.
            self.assertEqual("hello", replace_text("hello", {"": "boom"}))
            self.assertEqual("hello", utils.censor_text("hello", [""]))

        finally:
            utils.MAX_TEXT_FILTER_PATTERNS = old_max_patterns
            utils.MAX_TEXT_FILTER_PATTERN_CHARS = old_max_pattern_chars
            utils.MAX_TEXT_FILTER_REPLACEMENT_CHARS = old_max_replacement_chars
            utils.MAX_TEXT_FILTER_OUTPUT_CHARS = old_max_output_chars

    def test_execute_command_closes_parent_pipe_handles_for_background_pipelines(self):
        import subprocess

        processes = []

        class FakeStdout:
            def __init__(self):
                self.closed = False

            def close(self):
                self.closed = True

        class FakeProcess:
            def __init__(self, _args, startupinfo=None, stdin=None, stdout=None):
                self.stdin = stdin
                self.stdout = FakeStdout() if stdout == subprocess.PIPE else None
                self.wait_count = 0
                processes.append(self)

            def wait(self):
                self.wait_count += 1
                return 0

        with patch("subprocess.Popen", side_effect=FakeProcess):
            self.assertTrue(execute_command("cmd1 | cmd2 | cmd3", background=True))

        self.assertEqual(3, len(processes))
        self.assertTrue(processes[0].stdout.closed)
        self.assertTrue(processes[1].stdout.closed)
        self.assertIsNone(processes[2].stdout)
        self.assertIs(processes[1].stdin, processes[0].stdout)
        self.assertIs(processes[2].stdin, processes[1].stdout)

    def test_execute_command_waits_for_all_foreground_pipeline_processes(self):
        import subprocess

        processes = []

        class FakeStdout:
            def close(self):
                pass

        class FakeProcess:
            def __init__(self, _args, startupinfo=None, stdin=None, stdout=None):
                self.stdin = stdin
                self.stdout = FakeStdout() if stdout == subprocess.PIPE else None
                self.wait_count = 0
                processes.append(self)

            def wait(self):
                self.wait_count += 1
                return 0

        with patch("subprocess.Popen", side_effect=FakeProcess):
            self.assertTrue(execute_command("cmd1 | cmd2", background=False))

        self.assertEqual([1, 1], [process.wait_count for process in processes])



    def test_execute_command_returnoutput_waits_for_all_pipeline_processes(self):
        import subprocess

        processes = []

        class FakeStdout:
            def __init__(self):
                self.closed = False
                self._read_once = False

            def read(self, _size=-1):
                if self._read_once:
                    return b""

                self._read_once = True
                return b"ok"

            def close(self):
                self.closed = True

        class FakeProcess:
            def __init__(self, _args, startupinfo=None, stdin=None, stdout=None):
                self.stdin = stdin
                self.stdout = FakeStdout() if stdout == subprocess.PIPE else None
                self.wait_count = 0
                processes.append(self)

            def wait(self):
                self.wait_count += 1
                return 0

        with patch("subprocess.Popen", side_effect=FakeProcess):
            self.assertEqual(b"ok", execute_command("cmd1 | cmd2 | cmd3", returnoutput=True))

        self.assertEqual(3, len(processes))
        self.assertEqual([1, 1, 1], [process.wait_count for process in processes])
        self.assertTrue(all(process.stdout is None or process.stdout.closed for process in processes))

    def test_execute_command_returnoutput_unbounded_waits_for_all_pipeline_processes(self):
        import subprocess

        processes = []

        class FakeStdout:
            def close(self):
                pass

        class FakeProcess:
            def __init__(self, _args, startupinfo=None, stdin=None, stdout=None):
                self.stdin = stdin
                self.stdout = FakeStdout() if stdout == subprocess.PIPE else None
                self.wait_count = 0
                self.communicate_count = 0
                processes.append(self)

            def wait(self):
                self.wait_count += 1
                return 0

            def communicate(self):
                self.communicate_count += 1
                return b"out", b""

        with patch("subprocess.Popen", side_effect=FakeProcess):
            self.assertEqual(
                b"out",
                execute_command("cmd1 | cmd2", returnoutput=True, max_output_size=None)
            )

        self.assertEqual([1, 0], [process.wait_count for process in processes])
        self.assertEqual([0, 1], [process.communicate_count for process in processes])

    def test_execute_command_rejects_replacement_that_expands_arguments_too_much(self):
        with patch("subprocess.Popen") as popen:
            with self.assertRaises(RuntimeError):
                execute_command("cmd $", replacement="x" * (utils.MAX_EXECUTE_COMMAND_ARG_BYTES + 1))

            popen.assert_not_called()

    def test_execute_command_rejects_replacement_that_expands_argv_too_much(self):
        placeholder_count = (utils.MAX_EXECUTE_COMMAND_ARGV_BYTES // 2048) + 2
        command = "cmd " + " ".join("$" for _ in range(placeholder_count))

        with patch("subprocess.Popen") as popen:
            with self.assertRaises(RuntimeError):
                execute_command(command, replacement="x" * 2048)

            popen.assert_not_called()

    def test_execute_command_cleans_up_started_pipeline_processes_on_later_failure(self):
        import subprocess

        processes = []

        class FakeStdout:
            def __init__(self):
                self.closed = False

            def close(self):
                self.closed = True

        class FakeProcess:
            def __init__(self, args, startupinfo=None, stdin=None, stdout=None):
                if args == ["bad"]:
                    raise OSError("missing command")

                self.stdin = stdin
                self.stdout = FakeStdout() if stdout == subprocess.PIPE else None
                self.kill_count = 0
                self.wait_count = 0
                processes.append(self)

            def poll(self):
                return None

            def kill(self):
                self.kill_count += 1

            def wait(self):
                self.wait_count += 1
                return 0

        with patch("subprocess.Popen", side_effect=FakeProcess):
            with self.assertRaises(RuntimeError):
                execute_command("cmd1 | bad | cmd3", background=True)

        self.assertEqual(1, len(processes))
        self.assertTrue(processes[0].stdout.closed)
        self.assertEqual(1, processes[0].kill_count)
        self.assertEqual(1, processes[0].wait_count)

    def test_execute_command_rejects_empty_and_gross_pipelines_before_spawn(self):
        with patch("subprocess.Popen") as popen:
            with self.assertRaises(RuntimeError):
                execute_command("cmd1 | | cmd2", background=True)

            popen.assert_not_called()

        command = " | ".join(f"cmd{i}" for i in range(utils.MAX_EXECUTE_COMMAND_PIPELINES + 1))

        with patch("subprocess.Popen") as popen:
            with self.assertRaises(RuntimeError):
                execute_command(command, background=True)

            popen.assert_not_called()

    def test_execute_command_rejects_gross_command_size_before_spawn(self):
        with patch("subprocess.Popen") as popen:
            with self.assertRaises(RuntimeError):
                execute_command("x" * (utils.MAX_EXECUTE_COMMAND_BYTES + 1), background=True)

            popen.assert_not_called()

    def test_execute_command_returnoutput_enforces_gross_output_limit(self):
        with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False) as script_file:
            script_file.write('import sys\nsys.stdout.write("x" * 2048)\n')
            script_path = script_file.name

        try:
            command = f'"{sys.executable}" "{script_path}"'

            self.assertEqual(2048, len(execute_command(command, returnoutput=True, max_output_size=4096)))

            with self.assertRaises(RuntimeError):
                execute_command(command, returnoutput=True, max_output_size=16)

        finally:
            os.unlink(script_path)

    def test_open_uri_rejects_gross_or_malformed_external_uri_before_launcher(self):
        with patch("pynicotine.utils._try_open_uri", side_effect=AssertionError("launcher called")):
            self.assertFalse(open_uri("http://" + ("x" * (utils.MAX_EXTERNAL_URI_BYTES + 1))))
            self.assertFalse(open_uri("noscheme"))
            self.assertFalse(open_uri("bad scheme://example"))
