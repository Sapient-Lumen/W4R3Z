# COPYRIGHT (C) 2020-2024 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from collections import deque
from itertools import islice

from pynicotine.config import config
from pynicotine.core import core
from pynicotine.events import events
from pynicotine.logfacility import log
from pynicotine.slskmessages import JoinGlobalRoom
from pynicotine.slskmessages import JoinRoom
from pynicotine.slskmessages import LeaveGlobalRoom
from pynicotine.slskmessages import LeaveRoom
from pynicotine.slskmessages import PrivateRoomAddOperator
from pynicotine.slskmessages import PrivateRoomAddUser
from pynicotine.slskmessages import PrivateRoomCancelMembership
from pynicotine.slskmessages import PrivateRoomDisown
from pynicotine.slskmessages import PrivateRoomRemoveOperator
from pynicotine.slskmessages import PrivateRoomRemoveUser
from pynicotine.slskmessages import PrivateRoomToggle
from pynicotine.slskmessages import RoomList
from pynicotine.slskmessages import RoomTickerSet
from pynicotine.slskmessages import RoomTickerState
from pynicotine.slskmessages import SayChatroom
from pynicotine.slskmessages import SlskMessage
from pynicotine.slskmessages import UserStatus
from pynicotine.utils import censor_text
from pynicotine.utils import find_whole_word
from pynicotine.utils import replace_text


class JoinedRoom:
    __slots__ = ("name", "is_private", "users", "tickers")

    def __init__(self, name, is_private=False):

        self.name = name
        self.is_private = is_private
        self.users = set()
        self.tickers = {}


class PrivateRoom:
    __slots__ = ("name", "owner", "members", "operators")

    def __init__(self, name):

        self.name = name
        self.owner = None
        self.members = set()
        self.operators = set()


class ChatRooms:
    __slots__ = ("completions", "server_rooms", "joined_rooms", "private_rooms",
                 "_joined_room_users_limit_logged", "_joined_rooms_limit_logged", "_server_rooms_limit_logged",
                 "_private_rooms_limit_logged", "_private_room_members_limit_logged",
                 "_private_room_operators_limit_logged", "_room_user_status_limit_logged",
                 "_room_unwatch_queue",
                 "_room_unwatch_keys", "_room_unwatch_timer_id",
                 "_room_unwatch_limit_logged", "_autojoin_queue",
                 "_autojoin_keys", "_autojoin_timer_id",
                 "_autojoin_limit_logged", "_unsolicited_leave_queue",
                 "_unsolicited_leave_keys", "_unsolicited_leave_timer_id",
                 "_unsolicited_leave_limit_logged", "_room_control_queue",
                 "_room_control_keys", "_room_control_timer_id",
                 "_room_control_limit_logged", "_room_message_retry_queue",
                 "_room_message_retry_timer_id", "_room_message_retry_bytes",
                 "_room_message_retry_limit_logged")

    # Trailing spaces to avoid conflict with regular rooms
    GLOBAL_ROOM_NAME = "Public "
    ROOM_NAME_MAX_LENGTH = 24
    MAX_ROOM_TICKERS = RoomTickerState.MAX_ROOM_TICKERS
    MAX_JOINED_ROOMS = 4096
    MAX_JOINED_ROOM_USERS = 20000
    MAX_SERVER_ROOMS = 50000
    MAX_PRIVATE_ROOMS = 8192
    MAX_PRIVATE_ROOM_MEMBERS = 20000
    MAX_PRIVATE_ROOM_OPERATORS = 4096
    MAX_COMPLETIONS = 20000
    MAX_ROOM_UNWATCHES_PER_TICK = 1000
    MAX_PENDING_ROOM_UNWATCHES = 100000
    MAX_AUTOJOIN_ROOMS_PER_TICK = 100
    MAX_PENDING_AUTOJOIN_ROOMS = 4096
    MAX_UNSOLICITED_LEAVE_ROOMS_PER_TICK = 100
    MAX_PENDING_UNSOLICITED_LEAVE_ROOMS = 4096
    MAX_ROOM_CONTROL_MESSAGES_PER_TICK = 16
    MAX_PENDING_ROOM_CONTROL_MESSAGES = 64
    MAX_ROOM_MESSAGE_RETRIES_PER_TICK = 64
    MAX_PENDING_ROOM_MESSAGE_RETRIES = 4096
    MAX_PENDING_ROOM_MESSAGE_RETRY_BYTES = 4 * 1024 * 1024
    AUTOJOIN_RETRY_DELAY = 1
    UNSOLICITED_LEAVE_RETRY_DELAY = 1
    ROOM_CONTROL_RETRY_DELAY = 1
    ROOM_MESSAGE_RETRY_DELAY = 1

    def __init__(self):

        self.completions = set()
        self.server_rooms = set()
        self.joined_rooms = {}
        self.private_rooms = {}
        self._joined_room_users_limit_logged = False
        self._joined_rooms_limit_logged = False
        self._server_rooms_limit_logged = False
        self._private_rooms_limit_logged = False
        self._private_room_members_limit_logged = False
        self._private_room_operators_limit_logged = False
        self._room_user_status_limit_logged = False
        self._room_unwatch_queue = deque()
        self._room_unwatch_keys = set()
        self._room_unwatch_timer_id = None
        self._room_unwatch_limit_logged = False
        self._autojoin_queue = deque()
        self._autojoin_keys = set()
        self._autojoin_timer_id = None
        self._autojoin_limit_logged = False
        self._unsolicited_leave_queue = deque()
        self._unsolicited_leave_keys = set()
        self._unsolicited_leave_timer_id = None
        self._unsolicited_leave_limit_logged = False
        self._room_control_queue = deque()
        self._room_control_keys = set()
        self._room_control_timer_id = None
        self._room_control_limit_logged = False
        self._room_message_retry_queue = deque()
        self._room_message_retry_timer_id = None
        self._room_message_retry_bytes = 0
        self._room_message_retry_limit_logged = False

        for event_name, callback in (
            ("global-room-message", self._global_room_message),
            ("join-room", self._join_room),
            ("leave-room", self._leave_room),
            ("private-room-add-operator", self._private_room_add_operator),
            ("private-room-add-user", self._private_room_add_user),
            ("private-room-added", self._private_room_added),
            ("private-room-operator-added", self._private_room_operator_added),
            ("private-room-operator-removed", self._private_room_operator_removed),
            ("private-room-operators", self._private_room_operators),
            ("private-room-remove-operator", self._private_room_remove_operator),
            ("private-room-remove-user", self._private_room_remove_user),
            ("private-room-removed", self._private_room_removed),
            ("private-room-toggle", self._private_room_toggle),
            ("private-room-users", self._private_room_users),
            ("quit", self._quit),
            ("room-list", self._room_list),
            ("say-chat-room", self._say_chat_room),
            ("server-login", self._server_login),
            ("server-disconnect", self._server_disconnect),
            ("server-message-unsent", self._server_message_unsent),
            ("server-response-delivery-failed", self._server_response_delivery_failed),
            ("start", self._start),
            ("ticker-add", self._ticker_add),
            ("ticker-remove", self._ticker_remove),
            ("ticker-state", self._ticker_state),
            ("user-joined-room", self._user_joined_room),
            ("user-left-room", self._user_left_room)
        ):
            events.connect(event_name, callback)

    def _start(self):

        restored_rooms = config.sections["server"]["autojoin"]
        seen_rooms = set()

        for room in restored_rooms:
            if not isinstance(room, str) or room in seen_rooms:
                continue

            seen_rooms.add(room)

            if not self.show_room(room, is_private=(room in self.private_rooms), switch_page=False, remembered=True):
                break

    def _quit(self):
        self.remove_all_rooms(is_permanent=False, force=True)
        self._cancel_room_unwatches()
        self._cancel_autojoin_queue()
        self._cancel_unsolicited_leave_rooms()
        self._cancel_room_control_messages()
        self._cancel_room_message_retries()
        self.completions.clear()

    def _cancel_room_unwatches(self):
        events.cancel_scheduled(self._room_unwatch_timer_id)
        self._room_unwatch_timer_id = None
        self._room_unwatch_queue.clear()
        self._room_unwatch_keys.clear()
        self._room_unwatch_limit_logged = False

    def _schedule_room_unwatches(self):

        if self._room_unwatch_timer_id is not None:
            return

        self._room_unwatch_timer_id = events.schedule(delay=0, callback=self._process_room_unwatches)

        if self._room_unwatch_timer_id is None:
            # Scheduler work is saturated; drop stale cleanup instead of
            # retaining an unreachable room-user backlog indefinitely.
            self._room_unwatch_queue.clear()
            self._room_unwatch_keys.clear()

    def _queue_room_unwatches(self, room, usernames):
        context = f"chatrooms_{room}"

        for username in usernames:
            key = (room, username)

            if key in self._room_unwatch_keys:
                continue

            if len(self._room_unwatch_queue) >= self.MAX_PENDING_ROOM_UNWATCHES:
                if not self._room_unwatch_limit_logged:
                    log.add_debug(
                        "Room unwatch queue reached %s users; discarding additional room-user cleanup",
                        self.MAX_PENDING_ROOM_UNWATCHES
                    )
                    self._room_unwatch_limit_logged = True

                break

            self._room_unwatch_queue.append((room, username, context))
            self._room_unwatch_keys.add(key)

        self._process_room_unwatches()

    def _process_room_unwatches(self):
        self._room_unwatch_timer_id = None
        num_processed = 0

        while self._room_unwatch_queue and num_processed < self.MAX_ROOM_UNWATCHES_PER_TICK:
            room, username, context = self._room_unwatch_queue.popleft()
            self._room_unwatch_keys.discard((room, username))
            num_processed += 1

            room_obj = self.joined_rooms.get(room)

            if room_obj is not None and username in room_obj.users:
                # The user rejoined before the deferred cleanup ran.
                continue

            core.users.unwatch_user(username, context=context)

        if self._room_unwatch_queue:
            self._schedule_room_unwatches()
        else:
            self._room_unwatch_limit_logged = False

    def _cancel_autojoin_queue(self):
        events.cancel_scheduled(self._autojoin_timer_id)
        self._autojoin_timer_id = None
        self._autojoin_queue.clear()
        self._autojoin_keys.clear()
        self._autojoin_limit_logged = False

    def _cancel_unsolicited_leave_rooms(self):
        events.cancel_scheduled(self._unsolicited_leave_timer_id)
        self._unsolicited_leave_timer_id = None
        self._unsolicited_leave_queue.clear()
        self._unsolicited_leave_keys.clear()
        self._unsolicited_leave_limit_logged = False

    def _schedule_unsolicited_leave_rooms(self, delay=0):

        if self._unsolicited_leave_timer_id is not None:
            return

        self._unsolicited_leave_timer_id = events.schedule(
            delay=delay, callback=self._process_unsolicited_leave_rooms)

        if self._unsolicited_leave_timer_id is None:
            # Scheduler work is saturated. Drop stale defensive leave commands
            # rather than retaining an unbounded server-originated backlog.
            self._unsolicited_leave_queue.clear()
            self._unsolicited_leave_keys.clear()

    def _queue_unsolicited_leave_room(self, room):

        if room in self._unsolicited_leave_keys:
            return True

        if len(self._unsolicited_leave_queue) >= self.MAX_PENDING_UNSOLICITED_LEAVE_ROOMS:
            if not self._unsolicited_leave_limit_logged:
                log.add_debug(
                    "Unsolicited room leave queue reached %s rooms; dropping additional defensive leaves",
                    self.MAX_PENDING_UNSOLICITED_LEAVE_ROOMS
                )
                self._unsolicited_leave_limit_logged = True

            return False

        self._unsolicited_leave_queue.append(room)
        self._unsolicited_leave_keys.add(room)
        return True

    def _process_unsolicited_leave_rooms(self):
        self._unsolicited_leave_timer_id = None
        num_processed = 0
        retry_delay = 0

        while (self._unsolicited_leave_queue
                and num_processed < self.MAX_UNSOLICITED_LEAVE_ROOMS_PER_TICK):
            room = self._unsolicited_leave_queue.popleft()
            self._unsolicited_leave_keys.discard(room)
            num_processed += 1

            if room in self.joined_rooms:
                # The user explicitly joined before the defensive leave ran.
                continue

            if not self._send_leave_room_request(room):
                self._unsolicited_leave_queue.appendleft(room)
                self._unsolicited_leave_keys.add(room)
                retry_delay = self.UNSOLICITED_LEAVE_RETRY_DELAY
                break

        if self._unsolicited_leave_queue:
            if not self._unsolicited_leave_limit_logged:
                log.add_debug(
                    "Defensive leaves for unsolicited rooms are continuing in batches of %s rooms",
                    self.MAX_UNSOLICITED_LEAVE_ROOMS_PER_TICK
                )
                self._unsolicited_leave_limit_logged = True

            self._schedule_unsolicited_leave_rooms(delay=retry_delay)
        else:
            self._unsolicited_leave_limit_logged = False


    def _queue_unsent_room_control_message(self, msg):
        """Retry room-control requests that were accepted above but never reached server output."""

        msg_class = msg.__class__

        if msg_class is RoomList:
            return self._queue_room_control_message(("room-list", None), msg)

        if msg_class is PrivateRoomToggle:
            return self._queue_room_control_message(("private-room-toggle", bool(msg.enabled)), msg)

        if msg_class is JoinGlobalRoom:
            room = self.GLOBAL_ROOM_NAME

            if room not in self.joined_rooms:
                return False

            return self._queue_room_control_message(("join-room", room), msg)

        if msg_class is JoinRoom:
            room = getattr(msg, "room", None)

            if room not in self.joined_rooms:
                return False

            return self._queue_room_control_message(("join-room", room), msg)

        if msg_class is LeaveGlobalRoom:
            return self._queue_room_control_message(("leave-room", self.GLOBAL_ROOM_NAME), msg)

        if msg_class is LeaveRoom:
            return self._queue_room_control_message(("leave-room", getattr(msg, "room", None)), msg)

        if msg_class in {PrivateRoomDisown, PrivateRoomCancelMembership}:
            return self._queue_room_control_message((msg_class.__name__, getattr(msg, "room", None)), msg)

        if msg_class in {
            PrivateRoomAddUser,
            PrivateRoomRemoveUser,
            PrivateRoomAddOperator,
            PrivateRoomRemoveOperator
        }:
            return self._queue_room_control_message(
                (msg_class.__name__, getattr(msg, "room", None), getattr(msg, "user", None)), msg)

        return False


    @staticmethod
    def _estimate_room_message_retry_size(msg):
        room = getattr(msg, "room", "") or ""
        message = getattr(msg, "message", getattr(msg, "msg", "")) or ""
        return len(room.encode("utf-8", "replace")) + len(message.encode("utf-8", "replace")) + 64

    @staticmethod
    def _get_room_message_retry_room(msg):
        return getattr(msg, "room", None)

    def _is_room_message_retry_stale(self, msg):
        room = self._get_room_message_retry_room(msg)
        return room is not None and room not in self.joined_rooms

    def _ensure_room_message_retry_state(self):
        if not hasattr(self, "_room_message_retry_queue"):
            self._room_message_retry_queue = deque()
            self._room_message_retry_timer_id = None
            self._room_message_retry_bytes = 0
            self._room_message_retry_limit_logged = False

    def _cancel_room_message_retries(self):
        self._ensure_room_message_retry_state()
        events.cancel_scheduled(self._room_message_retry_timer_id)
        self._room_message_retry_timer_id = None
        self._room_message_retry_queue.clear()
        self._room_message_retry_bytes = 0
        self._room_message_retry_limit_logged = False

    def _schedule_room_message_retries(self, delay=0):
        self._ensure_room_message_retry_state()

        if not self._room_message_retry_queue or self._room_message_retry_timer_id is not None:
            return

        self._room_message_retry_timer_id = events.schedule(
            delay=delay, callback=self._process_room_message_retries)

        if self._room_message_retry_timer_id is None:
            self._cancel_room_message_retries()

    def _queue_room_message_retry(self, msg, notify_on_success=False):
        self._ensure_room_message_retry_state()

        if self._is_room_message_retry_stale(msg):
            return False

        msg_size = self._estimate_room_message_retry_size(msg)

        if (len(self._room_message_retry_queue) >= self.MAX_PENDING_ROOM_MESSAGE_RETRIES
                or self._room_message_retry_bytes + msg_size > self.MAX_PENDING_ROOM_MESSAGE_RETRY_BYTES):
            if not self._room_message_retry_limit_logged:
                log.add_debug(
                    "Room message retry queue reached %(items)s items or %(bytes)s bytes; "
                    "discarding additional unsent room messages", {
                        "items": self.MAX_PENDING_ROOM_MESSAGE_RETRIES,
                        "bytes": self.MAX_PENDING_ROOM_MESSAGE_RETRY_BYTES
                    })
                self._room_message_retry_limit_logged = True

            return False

        self._room_message_retry_queue.append((msg, msg_size, notify_on_success))
        self._room_message_retry_bytes += msg_size
        self._schedule_room_message_retries(delay=self.ROOM_MESSAGE_RETRY_DELAY)
        return True

    def _process_room_message_retries(self):
        self._ensure_room_message_retry_state()
        self._room_message_retry_timer_id = None
        num_processed = 0
        retry_delay = 0

        while (self._room_message_retry_queue
                and num_processed < self.MAX_ROOM_MESSAGE_RETRIES_PER_TICK):
            msg, msg_size, notify_on_success = self._room_message_retry_queue.popleft()
            self._room_message_retry_bytes = max(0, self._room_message_retry_bytes - msg_size)
            num_processed += 1

            if self._is_room_message_retry_stale(msg):
                continue

            if core.send_message_to_server(msg) is False:
                self._room_message_retry_queue.appendleft((msg, msg_size, notify_on_success))
                self._room_message_retry_bytes += msg_size
                retry_delay = self.ROOM_MESSAGE_RETRY_DELAY
                break

            if notify_on_success and msg.__class__ is SayChatroom:
                core.pluginhandler.outgoing_public_chat_notification(msg.room, msg.message)

        if self._room_message_retry_queue:
            self._schedule_room_message_retries(delay=retry_delay)
        else:
            self._room_message_retry_limit_logged = False

    def _queue_unsent_room_message(self, msg):
        if msg.__class__ not in {SayChatroom, RoomTickerSet}:
            return False

        return self._queue_room_message_retry(msg)

    def _server_message_unsent(self, msg):
        if self._queue_unsent_room_control_message(msg):
            log.add_debug(
                "Retrying room-control server message %s after lower server output rejected it",
                msg.__class__.__name__
            )
            return

        if self._queue_unsent_room_message(msg):
            log.add_debug(
                "Retrying room message %s after lower server output rejected it",
                msg.__class__.__name__
            )

    def _server_response_delivery_failed(self, msg_class, rollback_info):
        if msg_class is not RoomList or rollback_info != ("room-list",):
            return

        if self._queue_room_control_message(("room-list", None), RoomList()):
            log.add_debug("Retrying room list request after parsed room list response could not be delivered")

    def _schedule_autojoin_rooms(self, delay=0):

        if self._autojoin_timer_id is not None:
            return

        self._autojoin_timer_id = events.schedule(delay=delay, callback=self._process_autojoin_rooms)

        if self._autojoin_timer_id is None:
            # Scheduler work is saturated; drop stale autojoin requests instead
            # of retaining a login-time room backlog indefinitely.
            self._autojoin_queue.clear()
            self._autojoin_keys.clear()

    def _queue_autojoin_room(self, room):

        if room in self._autojoin_keys:
            return True

        if len(self._autojoin_queue) >= self.MAX_PENDING_AUTOJOIN_ROOMS:
            if not self._autojoin_limit_logged:
                log.add_debug(
                    "Autojoin queue reached %s rooms; discarding additional remembered rooms",
                    self.MAX_PENDING_AUTOJOIN_ROOMS
                )
                self._autojoin_limit_logged = True

            return False

        self._autojoin_queue.append(room)
        self._autojoin_keys.add(room)
        return True

    def _send_join_room_request(self, room, is_private=False):

        if room == self.GLOBAL_ROOM_NAME:
            msg = JoinGlobalRoom()
        else:
            msg = JoinRoom(room, is_private)

        if core.send_message_to_server(msg) is False:
            log.add_debug("Discarding local room join request for %s; network queue rejected it", room)
            return False

        return True

    def _send_leave_room_request(self, room):

        if room == self.GLOBAL_ROOM_NAME:
            msg = LeaveGlobalRoom()
        else:
            msg = LeaveRoom(room)

        if core.send_message_to_server(msg) is False:
            log.add_debug("Keeping local room state for %s; leave request was rejected by the network queue", room)
            return False

        return True

    def _schedule_room_control_messages(self, delay=0):

        if self._room_control_timer_id is not None:
            return

        self._room_control_timer_id = events.schedule(delay=delay, callback=self._process_room_control_messages)

        if self._room_control_timer_id is None:
            self._room_control_queue.clear()
            self._room_control_keys.clear()

    def _cancel_room_control_messages(self):

        timer_id = getattr(self, "_room_control_timer_id", None)

        if timer_id is not None:
            events.cancel_scheduled(timer_id)

        self._room_control_timer_id = None

        if hasattr(self, "_room_control_queue"):
            self._room_control_queue.clear()

        if hasattr(self, "_room_control_keys"):
            self._room_control_keys.clear()

        self._room_control_limit_logged = False

    def _queue_room_control_message(self, key, message):

        if key in self._room_control_keys:
            return True

        if len(self._room_control_queue) >= self.MAX_PENDING_ROOM_CONTROL_MESSAGES:
            if not self._room_control_limit_logged:
                log.add_debug(
                    "Room-control retry queue reached %s messages; discarding additional login-sync work",
                    self.MAX_PENDING_ROOM_CONTROL_MESSAGES
                )
                self._room_control_limit_logged = True

            return False

        self._room_control_queue.append((key, message))
        self._room_control_keys.add(key)
        self._schedule_room_control_messages(delay=self.ROOM_CONTROL_RETRY_DELAY)
        return True

    def _process_room_control_messages(self):
        self._room_control_timer_id = None
        num_processed = 0
        retry_delay = 0

        while self._room_control_queue and num_processed < self.MAX_ROOM_CONTROL_MESSAGES_PER_TICK:
            key, message = self._room_control_queue.popleft()
            self._room_control_keys.discard(key)
            num_processed += 1

            if core.send_message_to_server(message) is False:
                self._room_control_queue.appendleft((key, message))
                self._room_control_keys.add(key)
                retry_delay = self.ROOM_CONTROL_RETRY_DELAY
                break

        if self._room_control_queue:
            self._schedule_room_control_messages(delay=retry_delay)
        else:
            self._room_control_limit_logged = False

    def _process_autojoin_rooms(self):
        self._autojoin_timer_id = None
        num_processed = 0
        retry_delay = 0

        while self._autojoin_queue and num_processed < self.MAX_AUTOJOIN_ROOMS_PER_TICK:
            room = self._autojoin_queue.popleft()
            self._autojoin_keys.discard(room)
            num_processed += 1

            room_obj = self.joined_rooms.get(room)
            if room_obj is None:
                # The user removed the room before the deferred autojoin ran.
                continue

            if not self._send_join_room_request(room, room_obj.is_private):
                # Keep the remembered room pending if local network backpressure
                # rejects the join command. Dropping it here would leave the UI
                # and config believing autojoin happened when no server request
                # was accepted.
                self._autojoin_queue.appendleft(room)
                self._autojoin_keys.add(room)
                retry_delay = self.AUTOJOIN_RETRY_DELAY
                break

        if self._autojoin_queue:
            if not self._autojoin_limit_logged:
                log.add_debug(
                    "Autojoin is continuing in batches of %s rooms to avoid login-time network bursts",
                    self.MAX_AUTOJOIN_ROOMS_PER_TICK
                )
                self._autojoin_limit_logged = True

            self._schedule_autojoin_rooms(delay=retry_delay)
        else:
            self._autojoin_limit_logged = False

    def _server_login(self, msg):

        if not msg.success:
            return

        # Request a complete room list. A limited room list not including blacklisted rooms and
        # rooms with few users is automatically sent when logging in, but subsequent room list
        # requests contain all rooms.
        self.request_room_list(retry=True)

        self.request_private_room_toggle(config.sections["server"]["private_chatrooms"], retry=True)

        for room in self.joined_rooms:
            self._queue_autojoin_room(room)

        self._process_autojoin_rooms()

    def _server_disconnect(self, _msg):
        self._cancel_room_unwatches()
        self._cancel_autojoin_queue()
        self._cancel_unsolicited_leave_rooms()
        self._cancel_room_control_messages()
        self._cancel_room_message_retries()

        for room_obj in self.joined_rooms.values():
            room_obj.tickers.clear()
            room_obj.users.clear()

        self.server_rooms.clear()
        self.private_rooms.clear()
        self._joined_room_users_limit_logged = False
        self._joined_rooms_limit_logged = False
        self._server_rooms_limit_logged = False
        self._private_rooms_limit_logged = False
        self._private_room_members_limit_logged = False
        self._private_room_operators_limit_logged = False
        self._room_user_status_limit_logged = False
        self.update_completions()

    def show_room(self, room, is_private=False, switch_page=True, remembered=False):

        if not isinstance(room, str):
            return False

        if len(room.encode("utf-8", "replace")) > SlskMessage.MAX_ROOM_FIELD_BYTES:
            log.add_debug("Ignoring room with name exceeding %s bytes", SlskMessage.MAX_ROOM_FIELD_BYTES)
            return False

        room_obj = self.joined_rooms.get(room)

        if room_obj is None:
            if len(self.joined_rooms) >= self.MAX_JOINED_ROOMS:
                if not self._joined_rooms_limit_logged:
                    log.add_debug(
                        "Joined-room restore/open limit of %s rooms reached; ignoring additional rooms",
                        self.MAX_JOINED_ROOMS
                    )
                    self._joined_rooms_limit_logged = True

                return False

            if not remembered and not self._send_join_room_request(room, is_private):
                return False

            self.joined_rooms[room] = room_obj = JoinedRoom(name=room, is_private=is_private)

            if room not in config.sections["server"]["autojoin"]:
                position = 0 if room == self.GLOBAL_ROOM_NAME else -1
                config.sections["server"]["autojoin"].insert(position, room)

        elif not room_obj.users and not self._send_join_room_request(room, room_obj.is_private):
            return False

        events.emit("show-room", room, is_private, switch_page, remembered)
        return True

    def remove_room(self, room, is_permanent=True, force=False):

        if room not in self.joined_rooms:
            return False

        if not force and not self._send_leave_room_request(room):
            return False

        room_obj = self.joined_rooms.pop(room)
        room_users = tuple(room_obj.users)
        room_obj.users.clear()
        self._queue_room_unwatches(room, room_users)

        if is_permanent:
            if room in config.sections["columns"]["chat_room"]:
                del config.sections["columns"]["chat_room"][room]

            if room in config.sections["server"]["autojoin"]:
                config.sections["server"]["autojoin"].remove(room)

        events.emit("remove-room", room)
        return True

    def remove_all_rooms(self, is_permanent=True, force=False):
        for room in self.joined_rooms.copy():
            self.remove_room(room, is_permanent, force=force)

    @classmethod
    def sanitize_room_name(cls, room):
        """Sanitize room name according to server requirements."""

        # Replace non-ASCII characters
        room = room.strip().encode("ascii", errors="replace").decode()

        # Remove two or more consecutive spaces
        room = " ".join(room.split())

        # Limit to 24 characters
        room = room[:cls.ROOM_NAME_MAX_LENGTH]
        return room

    def clear_room_messages(self, room):
        events.emit("clear-room-messages", room)

    def echo_message(self, room, message, message_type="local"):
        events.emit("echo-room-message", room, message, message_type)

    def send_message(self, room, message):

        if room not in self.joined_rooms:
            return

        event = core.pluginhandler.outgoing_public_chat_event(room, message)
        if event is None:
            return

        room, message = event
        room = SlskMessage.truncate_string_bytes(room, SlskMessage.MAX_ROOM_FIELD_BYTES)
        message = SlskMessage.truncate_string_bytes(message, SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES)

        if config.sections["words"]["replacewords"]:
            message = replace_text(message, config.sections["words"]["autoreplaced"])
            message = SlskMessage.truncate_string_bytes(message, SlskMessage.MAX_CHAT_MESSAGE_FIELD_BYTES)

        msg = SayChatroom(room, message)

        if core.send_message_to_server(msg) is False:
            log.add_debug("Deferring outgoing chat room message to %s; network queue rejected it", room)
            self._queue_room_message_retry(msg, notify_on_success=True)
            return

        core.pluginhandler.outgoing_public_chat_notification(room, message)

    def _send_private_room_member_control(self, msg):

        if core.send_message_to_server(msg) is False:
            log.add_debug(
                "Discarding private-room control request for %s/%s; network queue rejected it",
                (getattr(msg, "room", None), getattr(msg, "user", None))
            )
            return False

        return True

    def add_user_to_private_room(self, room, username):
        return self._send_private_room_member_control(PrivateRoomAddUser(room, username))

    def add_operator_to_private_room(self, room, username):
        return self._send_private_room_member_control(PrivateRoomAddOperator(room, username))

    def remove_user_from_private_room(self, room, username):
        return self._send_private_room_member_control(PrivateRoomRemoveUser(room, username))

    def remove_operator_from_private_room(self, room, username):
        return self._send_private_room_member_control(PrivateRoomRemoveOperator(room, username))

    def is_private_room_owned(self, room):
        private_room = self.private_rooms.get(room)
        return private_room is not None and private_room.owner == core.users.login_username

    def is_private_room_member(self, room):
        return room in self.private_rooms

    def is_private_room_operator(self, room):
        private_room = self.private_rooms.get(room)
        return private_room is not None and core.users.login_username in private_room.operators

    def request_room_list(self, retry=False):
        msg = RoomList()

        if core.send_message_to_server(msg) is not False:
            return True

        if retry:
            self._queue_room_control_message(("room-list", None), msg)

        return False

    def request_private_room_disown(self, room):

        if not self.is_private_room_owned(room):
            return False

        if core.send_message_to_server(PrivateRoomDisown(room)) is False:
            return False

        del self.private_rooms[room]
        return True

    def request_private_room_cancel_membership(self, room):

        if not self.is_private_room_member(room):
            return False

        if core.send_message_to_server(PrivateRoomCancelMembership(room)) is False:
            return False

        del self.private_rooms[room]
        return True

    def request_private_room_toggle(self, enabled, retry=False):
        msg = PrivateRoomToggle(enabled)

        if core.send_message_to_server(msg) is not False:
            return True

        if retry:
            self._queue_room_control_message(("private-room-toggle", bool(enabled)), msg)

        return False

    def request_update_ticker(self, room, message):
        msg = RoomTickerSet(room, message)

        if core.send_message_to_server(msg) is not False:
            return True

        return self._queue_room_message_retry(msg)

    def _normalize_room_user_status(self, username, status):

        if status in {UserStatus.ONLINE, UserStatus.AWAY, UserStatus.OFFLINE}:
            return status

        if not self._room_user_status_limit_logged:
            log.add_debug(
                "Received unknown room-user status %s for %s; treating as offline",
                (status, username)
            )
            self._room_user_status_limit_logged = True

        return UserStatus.OFFLINE

    def _update_room_user(self, room_obj, user_data):

        username = user_data.username

        if username not in room_obj.users and len(room_obj.users) >= self.MAX_JOINED_ROOM_USERS:
            if not self._joined_room_users_limit_logged:
                log.add_debug("Discarding additional joined room users from server response; "
                              "joined room user limit %s reached", self.MAX_JOINED_ROOM_USERS)
                self._joined_room_users_limit_logged = True

            return False

        if not core.users.watch_user(username, context=f"chatrooms_{room_obj.name}", is_implicit=True):
            return False

        room_obj.users.add(username)
        watched_user = core.users.watched[username]
        watched_user.upload_speed = user_data.avgspeed
        watched_user.files = user_data.files
        watched_user.folders = user_data.dirs

        user_data.status = self._normalize_room_user_status(username, user_data.status)
        core.users.statuses[username] = user_data.status

        # Request user's IP address, so we can get the country and ignore messages by IP
        if username not in core.users.addresses:
            core.users.request_ip_address(username)

        # Replace server-provided country with our own
        if username in core.users.countries:
            user_data.country = core.users.countries[username]

        return True

    def _add_server_room(self, room):

        if room in self.server_rooms:
            return True

        if len(self.server_rooms) >= self.MAX_SERVER_ROOMS:
            if not self._server_rooms_limit_logged:
                log.add_debug("Server room cache limit of %s reached", self.MAX_SERVER_ROOMS)
                self._server_rooms_limit_logged = True

            return False

        self.server_rooms.add(room)
        return True

    def _get_or_create_private_room(self, room):

        private_room = self.private_rooms.get(room)

        if private_room is not None:
            return private_room

        if len(self.private_rooms) >= self.MAX_PRIVATE_ROOMS:
            if not self._private_rooms_limit_logged:
                log.add_debug("Private room cache limit of %s reached", self.MAX_PRIVATE_ROOMS)
                self._private_rooms_limit_logged = True

            return None

        private_room = self.private_rooms[room] = PrivateRoom(room)
        return private_room

    def _add_limited_private_room_items(self, items, new_items, max_items, log_attr):

        accepted_items = []

        for item in new_items:
            if item in items:
                accepted_items.append(item)
                continue

            if len(items) >= max_items:
                if not getattr(self, log_attr):
                    log.add_debug("Private room member/operator limit of %s reached", max_items)
                    setattr(self, log_attr, True)

                break

            items.add(item)
            accepted_items.append(item)

        return accepted_items

    def _update_private_room(self, room, owner=None, members=None, operators=None,
                             replace_members=False, replace_operators=False):

        private_room = self._get_or_create_private_room(room)

        if private_room is None:
            return None

        if owner:
            private_room.owner = owner

        if replace_members:
            private_room.members.clear()

        if members:
            self._add_limited_private_room_items(
                private_room.members, members, self.MAX_PRIVATE_ROOM_MEMBERS,
                "_private_room_members_limit_logged")

        if replace_operators:
            private_room.operators.clear()

        if operators:
            self._add_limited_private_room_items(
                private_room.operators, operators, self.MAX_PRIVATE_ROOM_OPERATORS,
                "_private_room_operators_limit_logged")

        return private_room

    def _join_room(self, msg):
        """Server code 14."""

        room_obj = self.joined_rooms.get(msg.room)

        if room_obj is None:
            # Reject unsolicited room join messages from the server. Queue and
            # batch the defensive leave instead of letting a malicious/buggy
            # server turn many unsolicited JoinRoom replies into a synchronous
            # server-output burst.
            if self._queue_unsolicited_leave_room(msg.room):
                self._schedule_unsolicited_leave_rooms()

            return

        room_obj.is_private = msg.private
        self._add_server_room(msg.room)

        if msg.private:
            self._update_private_room(msg.room, owner=msg.owner, operators=msg.operators)

        accepted_users = []

        for user_data in msg.users:
            if self._update_room_user(room_obj, user_data):
                accepted_users.append(user_data)

        # Keep downstream GUI/plugin work aligned with the users accepted into
        # core state instead of rendering the full server-supplied list.
        msg.users = accepted_users
        core.pluginhandler.join_chatroom_notification(msg.room)

    def _leave_room(self, msg):
        """Server code 15."""

        room_obj = self.joined_rooms.get(msg.room)

        if room_obj is not None:
            room_users = tuple(room_obj.users)
            room_obj.users.clear()
            self._queue_room_unwatches(msg.room, room_users)

        core.pluginhandler.leave_chatroom_notification(msg.room)

    def _private_room_users(self, msg):
        """Server code 133."""

        private_room = self._get_or_create_private_room(msg.room)

        if private_room is None:
            msg.users = []
            return

        private_room.members.clear()
        msg.users = self._add_limited_private_room_items(
            private_room.members, msg.users, self.MAX_PRIVATE_ROOM_MEMBERS,
            "_private_room_members_limit_logged")

    def _private_room_add_user(self, msg):
        """Server code 134."""

        private_room = self.private_rooms.get(msg.room)

        if private_room is not None:
            self._add_limited_private_room_items(
                private_room.members, (msg.user,), self.MAX_PRIVATE_ROOM_MEMBERS,
                "_private_room_members_limit_logged")

    def _private_room_remove_user(self, msg):
        """Server code 135."""

        private_room = self.private_rooms.get(msg.room)

        if private_room is not None:
            private_room.members.discard(msg.user)

    def _private_room_added(self, msg):
        """Server code 139."""

        if msg.room in self.private_rooms:
            return

        self._update_private_room(msg.room)

        if msg.room in self.joined_rooms:
            # Room tab previously opened, join room now
            self.show_room(msg.room, is_private=True, switch_page=False)

        log.add(_("You have been added to a private room: %(room)s"), {"room": msg.room})

    def _private_room_removed(self, msg):
        """Server code 140."""

        if msg.room in self.private_rooms:
            del self.private_rooms[msg.room]

    def _private_room_toggle(self, msg):
        """Server code 141."""

        config.sections["server"]["private_chatrooms"] = msg.enabled

    def _private_room_add_operator(self, msg):
        """Server code 143."""

        private_room = self.private_rooms.get(msg.room)

        if private_room is not None:
            self._add_limited_private_room_items(
                private_room.operators, (msg.user,), self.MAX_PRIVATE_ROOM_OPERATORS,
                "_private_room_operators_limit_logged")

    def _private_room_remove_operator(self, msg):
        """Server code 144."""

        private_room = self.private_rooms.get(msg.room)

        if private_room is not None:
            private_room.operators.discard(msg.user)

    def _private_room_operator_added(self, msg):
        """Server code 145."""

        private_room = self.private_rooms.get(msg.room)

        if private_room is not None:
            self._add_limited_private_room_items(
                private_room.operators, (core.users.login_username,), self.MAX_PRIVATE_ROOM_OPERATORS,
                "_private_room_operators_limit_logged")

    def _private_room_operator_removed(self, msg):
        """Server code 146."""

        private_room = self.private_rooms.get(msg.room)

        if private_room is not None:
            private_room.operators.discard(core.users.login_username)

    def _private_room_operators(self, msg):
        """Server code 148."""

        private_room = self._get_or_create_private_room(msg.room)

        if private_room is None:
            msg.operators = []
            return

        private_room.operators.clear()
        msg.operators = self._add_limited_private_room_items(
            private_room.operators, msg.operators, self.MAX_PRIVATE_ROOM_OPERATORS,
            "_private_room_operators_limit_logged")

    def _global_room_message(self, msg):
        """Server code 152."""

        if self.GLOBAL_ROOM_NAME not in self.joined_rooms:
            msg.room = None
            return

        self._say_chat_room(msg, is_global=True)

    def _room_list(self, msg):
        """Server code 64."""

        # RoomList is a full server snapshot. Replace the cache instead of
        # accumulating stale room names across repeated refreshes.
        self.server_rooms.clear()

        for room, _user_count in msg.rooms:
            self._add_server_room(room)

        for room, _user_count in msg.ownedprivaterooms:
            self._update_private_room(room, owner=core.users.login_username)

        for room, _user_count in msg.otherprivaterooms:
            self._update_private_room(room)

        if config.sections["words"]["roomnames"]:
            self.update_completions()
            core.privatechat.update_completions()

    def get_message_type(self, user, text):

        if text.startswith("/me "):
            return "action"

        if user == core.users.login_username:
            return "local"

        if core.users.login_username and find_whole_word(core.users.login_username.lower(), text.lower()) > -1:
            return "hilite"

        return "remote"

    def _say_chat_room(self, msg, is_global=False):
        """Server code 13."""

        room = msg.room
        username = msg.user

        if not is_global:
            if room not in self.joined_rooms:
                msg.room = None
                return

            if username != "server":
                if core.network_filter.is_user_ignored(username):
                    msg.room = None
                    return

                if core.network_filter.is_user_ip_ignored(username):
                    msg.room = None
                    return

            event = core.pluginhandler.incoming_public_chat_event(room, username, msg.message)
            if event is None:
                msg.room = None
                return

            _room, _username, msg.message = event

            log.add_chat(_("Chat message from user '%(user)s' in room '%(room)s': %(message)s"), {
                "user": username,
                "room": room,
                "message": msg.message
            })
        else:
            room = self.GLOBAL_ROOM_NAME

        message = msg.message
        msg.message_type = self.get_message_type(username, message)
        is_action_message = (msg.message_type == "action")

        if is_action_message:
            message = message.replace("/me ", "", 1)

        if config.sections["words"]["censorwords"] and username != core.users.login_username:
            message = censor_text(message, censored_patterns=config.sections["words"]["censored"])

        if is_action_message:
            msg.formatted_message = msg.message = f"* {username} {message}"
        else:
            msg.formatted_message = f"[{username}] {message}"

        if is_global:
            msg.formatted_message = f"{msg.room} | {msg.formatted_message}"

        if config.sections["logging"]["chatrooms"] or room in config.sections["logging"]["rooms"]:
            log.queue_log_file_write(
                folder_path=log.room_folder_path,
                basename=room, text=msg.formatted_message
            )

        if is_global:
            core.pluginhandler.public_room_message_notification(msg.room, username, msg.message)
        else:
            core.pluginhandler.incoming_public_chat_notification(room, username, msg.message)

    def _user_joined_room(self, msg):
        """Server code 16."""

        room_obj = self.joined_rooms.get(msg.room)

        if room_obj is None:
            msg.room = None
            return

        if not self._update_room_user(room_obj, msg.userdata):
            msg.room = None
            return

        core.pluginhandler.user_join_chatroom_notification(msg.room, msg.userdata.username)

    def _user_left_room(self, msg):
        """Server code 17."""

        room_obj = self.joined_rooms.get(msg.room)

        if room_obj is None:
            msg.room = None
            return

        username = msg.username
        room_obj.users.discard(username)
        core.users.unwatch_user(username, context=f"chatrooms_{msg.room}")

        core.pluginhandler.user_leave_chatroom_notification(msg.room, username)

    def _store_room_ticker(self, room_obj, username, message):

        tickers = room_obj.tickers

        if username not in tickers and len(tickers) >= self.MAX_ROOM_TICKERS:
            tickers.pop(next(iter(tickers)), None)

        tickers[username] = message

    def _ticker_state(self, msg):
        """Server code 113."""

        room_obj = self.joined_rooms.get(msg.room)

        if room_obj is None:
            msg.room = None
            return

        room_obj.tickers.clear()

        for username, message in msg.msgs:
            if core.network_filter.is_user_ignored(username) or \
                    core.network_filter.is_user_ip_ignored(username):
                # User ignored, ignore ticker message
                continue

            self._store_room_ticker(room_obj, username, message)

    def _ticker_add(self, msg):
        """Server code 114."""

        room_obj = self.joined_rooms.get(msg.room)

        if room_obj is None:
            msg.room = None
            return

        username = msg.user

        if core.network_filter.is_user_ignored(username) or core.network_filter.is_user_ip_ignored(username):
            # User ignored, ignore Ticker messages
            return

        self._store_room_ticker(room_obj, username, msg.msg)

    def _ticker_remove(self, msg):
        """Server code 115."""

        room_obj = self.joined_rooms.get(msg.room)

        if room_obj is None:
            msg.room = None
            return

        room_obj.tickers.pop(msg.user, None)

    def update_completions(self):

        self.completions.clear()

        def add_limited(items):
            remaining = self.MAX_COMPLETIONS - len(self.completions)

            if remaining <= 0:
                return False

            self.completions.update(islice(items, remaining))
            return len(self.completions) < self.MAX_COMPLETIONS

        add_limited((config.sections["server"]["login"],))

        if config.sections["words"]["roomnames"]:
            # Server room lists can be enormous. Add room names first for room
            # chat, but do not let them explode completion sorting/model work.
            add_limited(self.server_rooms)

        if config.sections["words"]["buddies"]:
            add_limited(core.buddies.users)

        if config.sections["words"]["commands"] and len(self.completions) < self.MAX_COMPLETIONS:
            add_limited(core.pluginhandler.iter_command_list(
                "chatroom", limit=self.MAX_COMPLETIONS - len(self.completions)))

        events.emit("room-completions", self.completions.copy())
