# COPYRIGHT (C) 2020-2025 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import io
import json
import os

from collections import deque
from itertools import chain
from threading import Thread

from pynicotine.config import config
from pynicotine.core import core
from pynicotine.events import events
from pynicotine.logfacility import log
from pynicotine.slskmessages import CloseConnection
from pynicotine.slskmessages import FileListMessage
from pynicotine.slskmessages import SharedFileListRequest
from pynicotine.slskmessages import SHARED_FILE_LIST_USERS_ALLOWED
from pynicotine.slskmessages import SharedFileListResponse
from pynicotine.slskmessages import UploadQueueNotification
from pynicotine.utils import clean_file
from pynicotine.utils import encode_path
from pynicotine.utils import UINT32_LIMIT
from pynicotine.utils import UINT64_LIMIT
from pynicotine.utils import write_file_and_backup
from pynicotine.watchbatch import WatchUserBatcher


class BrowsedUser:
    __slots__ = ("username", "public_folders", "private_folders", "num_folders", "num_files",
                 "shared_size")

    def __init__(self, username):

        self.username = username
        self.public_folders = {}
        self.private_folders = {}
        self.num_folders = None
        self.num_files = None
        self.shared_size = None

    def clear(self):

        self.public_folders.clear()
        self.private_folders.clear()
        self.num_folders = self.num_files = self.shared_size = None


class PendingBrowsedFolderTransfer:
    __slots__ = (
        "kind", "username", "requested_folder_path", "download_folder_path", "recurse",
        "folder_iterator", "folder_path", "destination_folder_path", "files", "file_index"
    )

    def __init__(self, kind, username, requested_folder_path, download_folder_path, recurse, folder_iterator):
        self.kind = kind
        self.username = username
        self.requested_folder_path = requested_folder_path
        self.download_folder_path = download_folder_path
        self.recurse = recurse
        self.folder_iterator = folder_iterator
        self.folder_path = None
        self.destination_folder_path = None
        self.files = None
        self.file_index = 0


class LimitedDecompressedReader(io.RawIOBase):
    """File-like wrapper that caps bytes produced by a decompressor."""

    def __init__(self, file_handle, max_bytes):
        self.file_handle = file_handle
        self.max_bytes = max_bytes
        self.bytes_read = 0

    def readable(self):
        return True

    def _check_size(self, size):
        if size is None or size < 0:
            return self.max_bytes - self.bytes_read + 1

        if self.bytes_read + size > self.max_bytes:
            raise ValueError("legacy saved shares list exceeds maximum decompressed size")

        return size

    def _record_read(self, data):
        self.bytes_read += len(data)

        if self.bytes_read > self.max_bytes:
            raise ValueError("legacy saved shares list exceeds maximum decompressed size")

        return data

    def read(self, size=-1):
        return self._record_read(self.file_handle.read(self._check_size(size)))

    def readline(self, size=-1):
        return self._record_read(self.file_handle.readline(self._check_size(size)))


class UserBrowse:
    __slots__ = ("users", "_users_limit_logged", "_bulk_folder_limit_logged", "_local_share_parse_keys",
                 "_local_share_delivery_retry_queue", "_local_share_delivery_retry_keys",
                 "_local_share_delivery_retry_timer_id", "_local_share_delivery_retry_limit_logged",
                 "_pending_folder_transfers", "_pending_folder_transfer_timer_id",
                 "_server_login_watch_batcher", "_peer_request_retry_queue",
                 "_peer_request_retry_keys", "_peer_request_retry_timer_id",
                 "_peer_request_retry_limit_logged")

    LARGE_FOLDER_CONFIRM_FILE_LIMIT = 1000
    MAX_BROWSED_USERS = 4096
    MAX_BULK_FOLDER_TRANSFER_FILES = 100000
    MAX_FOLDER_TRANSFER_FILES_PER_TICK = 1000
    MAX_PENDING_FOLDER_TRANSFER_JOBS = 512
    MAX_SERVER_LOGIN_WATCHES_PER_TICK = 1000
    MAX_PENDING_SERVER_LOGIN_WATCHES = 65536
    MAX_PENDING_PEER_REQUEST_RETRIES = 4096
    MAX_PEER_REQUEST_RETRIES_PER_TICK = 128
    PEER_REQUEST_RETRY_DELAY = 1
    MAX_PENDING_LOCAL_SHARE_DELIVERY_RETRIES = 32
    MAX_LOCAL_SHARE_DELIVERY_RETRIES_PER_TICK = 2
    LOCAL_SHARE_DELIVERY_RETRY_DELAY = 1
    MAX_SAVED_SHARES_FILE_SIZE = 536870912
    MAX_LEGACY_SAVED_SHARES_DECOMPRESSED_BYTES = MAX_SAVED_SHARES_FILE_SIZE
    SAVED_SHARES_JSON_CHUNK_SIZE = 64 * 1024
    MAX_SAVED_SHARES_JSON_ITEM_BYTES = 64 * 1024 * 1024
    MAX_SAVED_SHARES_FOLDERS = SharedFileListResponse.MAX_RESULT_FOLDERS
    MAX_SAVED_SHARES_FILES = SharedFileListResponse.MAX_RESULT_FILES
    MAX_SAVED_FILE_INFO_FIELDS = 8
    MAX_SAVED_FILE_ATTRIBUTE_ITEMS = 64
    MAX_SAVED_FILE_ATTRIBUTE_VALUE = UINT32_LIMIT
    MAX_SOULSEEK_URL_BYTES = 64 * 1024

    def __init__(self):

        self.users = {}
        self._users_limit_logged = False
        self._bulk_folder_limit_logged = False
        self._local_share_parse_keys = set()
        self._local_share_delivery_retry_queue = deque()
        self._local_share_delivery_retry_keys = set()
        self._local_share_delivery_retry_timer_id = None
        self._local_share_delivery_retry_limit_logged = False
        self._pending_folder_transfers = deque()
        self._pending_folder_transfer_timer_id = None
        self._server_login_watch_batcher = WatchUserBatcher(
            "userbrowse", lambda username: username in self.users,
            lambda: self.MAX_SERVER_LOGIN_WATCHES_PER_TICK,
            lambda: self.MAX_PENDING_SERVER_LOGIN_WATCHES
        )
        self._peer_request_retry_queue = deque()
        self._peer_request_retry_keys = set()
        self._peer_request_retry_timer_id = None
        self._peer_request_retry_limit_logged = False

        for event_name, callback in (
            ("quit", self._quit),
            ("server-login", self._server_login),
            ("server-disconnect", self._server_disconnect),
            ("peer-request-unsent", self._peer_request_unsent),
            ("peer-response-delivery-failed", self._peer_response_delivery_failed),
            ("shared-file-list-progress", self._shared_file_list_progress),
            ("shared-file-list-response", self._shared_file_list_response)
        ):
            events.connect(event_name, callback)

    def _quit(self):
        self._server_login_watch_batcher.cancel()
        self._clear_pending_folder_transfers()
        self._clear_peer_request_retries()
        self._clear_local_share_delivery_retries()
        self._local_share_parse_keys.clear()
        SHARED_FILE_LIST_USERS_ALLOWED.clear()
        self.remove_all_users()

    def _server_disconnect(self, _msg):
        self._server_login_watch_batcher.cancel()
        self._clear_pending_folder_transfers()
        self._clear_peer_request_retries()
        self._clear_local_share_delivery_retries()
        SHARED_FILE_LIST_USERS_ALLOWED.clear()

    def _server_login(self, msg):

        if not msg.success:
            return

        self._server_login_watch_batcher.queue(self.users)

    def send_upload_attempt_notification(self, username):
        """Send notification to user when attempting to initiate upload from
        our end."""

        return self._send_upload_queue_notification(username)

    def _clear_local_share_delivery_retries(self):
        if self._local_share_delivery_retry_timer_id is not None:
            events.cancel_scheduled(self._local_share_delivery_retry_timer_id)
            self._local_share_delivery_retry_timer_id = None

        self._local_share_delivery_retry_queue.clear()
        self._local_share_delivery_retry_keys.clear()
        self._local_share_delivery_retry_limit_logged = False

    def _queue_local_share_delivery_retry(self, username, permission_level):
        key = (username, permission_level)

        if key in self._local_share_delivery_retry_keys:
            return True

        if len(self._local_share_delivery_retry_queue) >= self.MAX_PENDING_LOCAL_SHARE_DELIVERY_RETRIES:
            if not self._local_share_delivery_retry_limit_logged:
                log.add_debug(
                    "Local shares delivery retry queue reached %s items; discarding additional retries",
                    self.MAX_PENDING_LOCAL_SHARE_DELIVERY_RETRIES
                )
                self._local_share_delivery_retry_limit_logged = True

            return False

        self._local_share_delivery_retry_keys.add(key)
        self._local_share_delivery_retry_queue.append(key)
        self._schedule_local_share_delivery_retries(delay=self.LOCAL_SHARE_DELIVERY_RETRY_DELAY)
        return True

    def _schedule_local_share_delivery_retries(self, delay=0):
        if self._local_share_delivery_retry_timer_id is not None:
            return

        self._local_share_delivery_retry_timer_id = events.schedule(
            delay=delay, callback=self._process_local_share_delivery_retries)

        if self._local_share_delivery_retry_timer_id is None:
            self._clear_local_share_delivery_retries()

    def _start_local_share_parser(self, username, permission_level):
        msg = core.shares.compressed_shares.get(permission_level)

        if msg is None:
            return False

        parse_key = (username, permission_level)

        if parse_key in self._local_share_parse_keys:
            log.add_debug("Local shares parse already in progress for user %s", username)
            return True

        self._local_share_parse_keys.add(parse_key)
        Thread(
            target=self._parse_local_shares,
            args=(username, msg.copy_without_results(), permission_level, parse_key),
            name="LocalShareParser", daemon=True
        ).start()
        return True

    def _process_local_share_delivery_retries(self):
        self._local_share_delivery_retry_timer_id = None
        num_processed = 0

        while (self._local_share_delivery_retry_queue
                and num_processed < self.MAX_LOCAL_SHARE_DELIVERY_RETRIES_PER_TICK):
            username, permission_level = self._local_share_delivery_retry_queue.popleft()
            self._local_share_delivery_retry_keys.discard((username, permission_level))
            num_processed += 1

            if username not in self.users:
                continue

            if not self._start_local_share_parser(username, permission_level):
                continue

        if self._local_share_delivery_retry_queue:
            self._schedule_local_share_delivery_retries(delay=self.LOCAL_SHARE_DELIVERY_RETRY_DELAY)
        else:
            self._local_share_delivery_retry_limit_logged = False

    def _clear_peer_request_retries(self):
        if self._peer_request_retry_timer_id is not None:
            events.cancel_scheduled(self._peer_request_retry_timer_id)
            self._peer_request_retry_timer_id = None

        self._peer_request_retry_queue.clear()
        self._peer_request_retry_keys.clear()
        self._peer_request_retry_limit_logged = False

    def _queue_peer_request_retry(self, username, msg_class):
        if not username or msg_class not in {SharedFileListRequest, UploadQueueNotification}:
            return False

        key = (username, msg_class)

        if key in self._peer_request_retry_keys:
            return True

        if len(self._peer_request_retry_queue) >= self.MAX_PENDING_PEER_REQUEST_RETRIES:
            if not self._peer_request_retry_limit_logged:
                log.add_debug(
                    "User Browse peer-request retry queue reached %s items; discarding additional retries",
                    self.MAX_PENDING_PEER_REQUEST_RETRIES
                )
                self._peer_request_retry_limit_logged = True

            return False

        self._peer_request_retry_keys.add(key)
        self._peer_request_retry_queue.append(key)
        self._schedule_peer_request_retries(delay=self.PEER_REQUEST_RETRY_DELAY)
        return True

    def _schedule_peer_request_retries(self, delay=0):
        if self._peer_request_retry_timer_id is not None:
            return

        self._peer_request_retry_timer_id = events.schedule(
            delay=delay, callback=self._process_peer_request_retries)

        if self._peer_request_retry_timer_id is None:
            self._clear_peer_request_retries()

    def _is_upload_queue_notification_retry_stale(self, username):
        uploads = getattr(core, "uploads", None)

        if uploads is None:
            return False

        for attr in ("queued_users", "active_users", "failed_users"):
            mapping = getattr(uploads, attr, None)

            if mapping is not None and username in mapping and mapping[username]:
                return False

        return True

    def _is_peer_request_retry_stale(self, username, msg_class):
        if msg_class is SharedFileListRequest:
            return username not in self.users

        if msg_class is UploadQueueNotification:
            return self._is_upload_queue_notification_retry_stale(username)

        return True

    def _send_shared_file_list_request(self, username):
        if core.send_message_to_peer(username, SharedFileListRequest()) is False:
            self._queue_peer_request_retry(username, SharedFileListRequest)
            return False

        SHARED_FILE_LIST_USERS_ALLOWED.add(username)
        return True

    def _send_upload_queue_notification(self, username):
        if core.send_message_to_peer(username, UploadQueueNotification()) is False:
            self._queue_peer_request_retry(username, UploadQueueNotification)
            return False

        return True

    def _process_peer_request_retries(self):
        self._peer_request_retry_timer_id = None
        num_processed = 0

        while (self._peer_request_retry_queue
                and num_processed < self.MAX_PEER_REQUEST_RETRIES_PER_TICK):
            username, msg_class = self._peer_request_retry_queue.popleft()
            self._peer_request_retry_keys.discard((username, msg_class))
            num_processed += 1

            if self._is_peer_request_retry_stale(username, msg_class):
                continue

            if msg_class is SharedFileListRequest:
                if not self._send_shared_file_list_request(username):
                    break

            elif msg_class is UploadQueueNotification:
                if not self._send_upload_queue_notification(username):
                    break

        if self._peer_request_retry_queue:
            self._schedule_peer_request_retries(delay=self.PEER_REQUEST_RETRY_DELAY)
        else:
            self._peer_request_retry_limit_logged = False

    def _peer_request_unsent(self, msg_class, username, _msg):
        if msg_class is SharedFileListRequest:
            SHARED_FILE_LIST_USERS_ALLOWED.discard(username)

        self._queue_peer_request_retry(username, msg_class)

    def _peer_response_delivery_failed(self, msg_class, username, rollback_info):
        if msg_class is not SharedFileListResponse:
            return

        if rollback_info != ("shared-file-list-response",):
            return

        SHARED_FILE_LIST_USERS_ALLOWED.discard(username)
        self._queue_peer_request_retry(username, SharedFileListRequest)

    def _show_user(self, username, path=None, new_request=False, switch_page=True):

        if not isinstance(username, str):
            return False

        if len(username.encode("utf-8", "replace")) > FileListMessage.MAX_USERNAME_FIELD_BYTES:
            log.add_debug("Ignoring browsed user with username exceeding %s bytes",
                          FileListMessage.MAX_USERNAME_FIELD_BYTES)
            return False

        if username not in self.users:
            if len(self.users) >= self.MAX_BROWSED_USERS:
                if not self._users_limit_logged:
                    log.add_debug(
                        "User Browse retained-user limit of %s users reached; ignoring additional users",
                        self.MAX_BROWSED_USERS
                    )
                    self._users_limit_logged = True

                return False

            self.users[username] = BrowsedUser(username)

        events.emit(
            "user-browse-show-user", user=username, path=path, new_request=new_request,
            switch_page=switch_page
        )
        return True

    def remove_user(self, username):

        self._clear_pending_folder_transfers(username)
        SHARED_FILE_LIST_USERS_ALLOWED.discard(username)
        del self.users[username]
        if core.users is not None:
            core.users.unwatch_user(username, context="userbrowse")
        events.emit("user-browse-remove-user", username)

    def remove_all_users(self):
        for username in self.users.copy():
            self.remove_user(username)

    def _parse_local_shares(self, username, msg, permission_level=None, parse_key=None):
        """Parse a local shares list and show it in the UI."""

        try:
            msg.parse_network_message(memoryview(msg.make_network_message()))
            msg.username = username

            if events.emit_main_thread("shared-file-list-response", msg) is False:
                # Local self-browse uses the same heavyweight response object as a
                # remote browse, but it originates in this parser thread instead of
                # the network thread. If the bounded main-thread bridge rejects it,
                # do not keep the huge parsed payload alive. Reparse from the
                # cached compressed shares list later while the local browse tab is
                # still retained.
                self._queue_local_share_delivery_retry(username, permission_level)

        finally:
            if parse_key is not None:
                self._local_share_parse_keys.discard(parse_key)

    def browse_local_shares(self, path=None, permission_level=None, new_request=False, switch_page=True):
        """Browse your own shares."""

        username = core.users.login_username or config.sections["server"]["login"]

        if not username:
            core.setup()
            return

        if username not in self.users or new_request:
            if not permission_level:
                # Check our own permission level, and show relevant shares for it
                current_permission_level, _reason = core.shares.check_user_permission(username)
            else:
                current_permission_level = permission_level

            self._start_local_share_parser(username, current_permission_level)

        if not self._show_user(username, path=path, new_request=new_request, switch_page=switch_page):
            return

        core.users.watch_user(username, context="userbrowse")

    def request_user_shares(self, username):
        return self._send_shared_file_list_request(username)

    def browse_user(self, username, path=None, new_request=False, switch_page=True):
        """Browse a user's shares."""

        if not username:
            return

        browsed_user = self.users.get(username)
        local_username = core.users.login_username or config.sections["server"]["login"]

        if browsed_user is not None and new_request:
            browsed_user.clear()

        if username == local_username:
            self.browse_local_shares(path, new_request=new_request, switch_page=switch_page)
            return

        if not self._show_user(username, path=path, new_request=new_request, switch_page=switch_page):
            return

        core.users.watch_user(username, context="userbrowse")

        if browsed_user is None or new_request:
            self.request_user_shares(username)

    def create_user_shares_folder(self):

        shares_folder = os.path.join(config.data_folder_path, "usershares")
        shares_folder_encoded = encode_path(shares_folder)

        try:
            if not os.path.isdir(shares_folder_encoded):
                os.makedirs(shares_folder_encoded)

        except Exception as error:
            log.add(_("Can't create directory '%(folder)s', reported error: %(error)s"),
                    {"folder": shares_folder, "error": error})
            return None

        return shares_folder

    def iter_matching_folders(self, requested_folder_path, browsed_user, recurse=False):

        for folders in (browsed_user.public_folders, browsed_user.private_folders):
            for folder_path, files in folders.items():
                if (requested_folder_path != folder_path
                        and not (recurse and folder_path.startswith(f"{requested_folder_path}\\"))):
                    continue

                yield folder_path, files

                if not recurse:
                    return

    @staticmethod
    def _iter_folder_items(folders):
        if hasattr(folders, "items"):
            return folders.items()

        return folders

    @staticmethod
    def _coerce_folder_mapping(folders):
        if isinstance(folders, dict):
            return folders

        return dict(folders)

    @classmethod
    def _validate_loaded_shares_list(cls, shares_list):
        """Reject gross saved browse lists before retaining/emitting them."""

        num_folders = 0
        num_files = 0

        for folder_path, files in cls._iter_folder_items(shares_list):
            num_folders += 1

            if num_folders > cls.MAX_SAVED_SHARES_FOLDERS:
                raise ValueError("saved shares list contains too many folders")

            if not isinstance(folder_path, str):
                raise TypeError("Invalid folder path")

            num_files += len(files)

            if num_files > cls.MAX_SAVED_SHARES_FILES:
                raise ValueError("saved shares list contains too many files")

        return num_folders, num_files

    @staticmethod
    def _write_saved_folder_item(file_handle, json_encoder, folder_path, files):
        """Write one saved shares-list folder without encoding all files at once."""

        file_handle.write("[")
        file_handle.write(json_encoder.encode(folder_path))
        file_handle.write(", [")

        is_first_file = True

        for file_info in files:
            if is_first_file:
                is_first_file = False
            else:
                file_handle.write(",")

            file_handle.write(json_encoder.encode(file_info))

        file_handle.write("]]")

    @classmethod
    def _iter_saved_json_folder_events(cls, file_handle):
        """Stream saved browse-cache folder/file records from the JSON array.

        The saved browse format is a top-level array of ``[folder, files]``
        pairs. Previous streaming avoided whole-file json.load(), but still
        decoded each whole folder item at once. A single huge flat folder can be
        the common case for shared music archives, so stream the folder record
        and each nested file record separately. The final in-memory browse
        model still stores the file list, but this avoids an additional decoded
        ``[folder, files...]`` tree and keeps the item-buffer cap meaningful for
        one record instead of an entire folder.
        """

        decoder = json.JSONDecoder()
        buffer = ""
        pos = 0
        eof = False

        def compact_buffer():
            nonlocal buffer, pos

            if pos <= 0:
                return

            buffer = buffer[pos:]
            pos = 0

        def read_more():
            nonlocal buffer, eof

            if eof:
                return False

            compact_buffer()
            chunk = file_handle.read(cls.SAVED_SHARES_JSON_CHUNK_SIZE)

            if chunk == "":
                eof = True
                return False

            buffer += chunk

            if len(buffer) > cls.MAX_SAVED_SHARES_JSON_ITEM_BYTES:
                raise ValueError(
                    "saved shares JSON record exceeds maximum buffered size "
                    f"{cls.MAX_SAVED_SHARES_JSON_ITEM_BYTES} bytes"
                )

            return True

        def skip_whitespace():
            nonlocal pos

            while True:
                while pos < len(buffer) and buffer[pos].isspace():
                    pos += 1

                if pos < len(buffer) or eof:
                    return

                read_more()

        def peek_char():
            skip_whitespace()

            while pos >= len(buffer) and read_more():
                skip_whitespace()

            if pos >= len(buffer):
                return None

            return buffer[pos]

        def expect_char(char):
            nonlocal pos

            if peek_char() != char:
                raise ValueError(f"expected '{char}' in saved shares JSON")

            pos += 1

        def decode_value(description):
            nonlocal pos

            skip_whitespace()

            while True:
                try:
                    value, pos = decoder.raw_decode(buffer, pos)
                    return value

                except json.JSONDecodeError:
                    if eof:
                        raise ValueError(f"invalid or truncated {description} in saved shares JSON") from None

                    if not read_more() and eof:
                        raise ValueError(f"invalid or truncated {description} in saved shares JSON") from None

        if not read_more() and eof:
            raise ValueError("saved shares JSON is empty")

        expect_char("[")

        if peek_char() == "]":
            pos += 1
            return

        while True:
            expect_char("[")
            folder_path = decode_value("folder path")
            yield "folder", folder_path
            expect_char(",")
            expect_char("[")

            if peek_char() != "]":
                while True:
                    yield "file", decode_value("file record")

                    char = peek_char()

                    if char == ",":
                        pos += 1
                        continue

                    if char == "]":
                        break

                    raise ValueError("expected ',' or ']' in saved shares file list")

            expect_char("]")
            expect_char("]")
            yield "end-folder", None

            char = peek_char()

            if char == ",":
                pos += 1
                continue

            if char == "]":
                pos += 1

                if peek_char() is not None:
                    raise ValueError("unexpected trailing data in saved shares JSON")

                return

            raise ValueError("expected ',' or ']' in saved shares JSON array")

    @classmethod
    def _check_saved_string_size(cls, value, max_bytes, description):
        if len(value.encode("utf-8", "replace")) > max_bytes:
            raise ValueError(f"saved shares {description} exceeds maximum size")

    @classmethod
    def _normalize_saved_uint(cls, value, maximum, description):
        if isinstance(value, bool) or not isinstance(value, int):
            raise TypeError(f"Invalid saved shares {description}")

        if value < 0 or value > maximum:
            raise ValueError(f"saved shares {description} is out of range")

        return value

    @classmethod
    def _normalize_saved_file_attributes(cls, attrs):
        if isinstance(attrs, dict):
            if len(attrs) > cls.MAX_SAVED_FILE_ATTRIBUTE_ITEMS:
                raise ValueError("saved shares file record contains too many attributes")

            normalized_attrs = {}

            for key, value in attrs.items():
                try:
                    key = int(key)
                except (TypeError, ValueError) as error:
                    raise TypeError("Invalid saved shares file attribute key") from error

                key = cls._normalize_saved_uint(key, UINT32_LIMIT, "file attribute key")
                value = cls._normalize_saved_uint(
                    value, cls.MAX_SAVED_FILE_ATTRIBUTE_VALUE, "file attribute value")
                normalized_attrs[key] = value

            return normalized_attrs

        attrs = list(attrs)

        if len(attrs) > cls.MAX_SAVED_FILE_ATTRIBUTE_ITEMS:
            raise ValueError("saved shares file record contains too many attributes")

        for value in attrs:
            cls._normalize_saved_uint(value, cls.MAX_SAVED_FILE_ATTRIBUTE_VALUE, "file attribute value")

        return attrs

    @classmethod
    def _normalize_loaded_file_info(cls, file_info):
        if not isinstance(file_info, list) or len(file_info) < 5:
            raise TypeError("Invalid file info")

        if len(file_info) > cls.MAX_SAVED_FILE_INFO_FIELDS:
            raise ValueError("saved shares file record contains too many fields")

        if not isinstance(file_info[1], str):
            raise TypeError("Invalid file name")

        cls._check_saved_string_size(file_info[1], FileListMessage.MAX_BASENAME_BYTES, "file name")
        file_size = cls._normalize_saved_uint(file_info[2], UINT64_LIMIT, "file size")
        attrs = cls._normalize_saved_file_attributes(file_info[4])

        return [file_info[0], file_info[1], file_size, "", attrs]

    @classmethod
    def _load_saved_json_shares_list(cls, file_handle):
        shares = {}
        num_folders = 0
        num_files = 0
        shared_size = 0
        folder_path = None
        normalized_files = None

        for event_type, value in cls._iter_saved_json_folder_events(file_handle):
            if event_type == "folder":
                if not isinstance(value, str):
                    raise TypeError("Invalid folder path")

                cls._check_saved_string_size(value, FileListMessage.MAX_VIRTUAL_PATH_BYTES, "folder path")

                if normalized_files is not None:
                    raise ValueError("saved shares folder was not closed")

                num_folders += 1

                if num_folders > cls.MAX_SAVED_SHARES_FOLDERS:
                    raise ValueError("saved shares list contains too many folders")

                folder_path = value
                normalized_files = []
                continue

            if event_type == "file":
                if normalized_files is None:
                    raise ValueError("saved shares file record outside folder")

                file_info = cls._normalize_loaded_file_info(value)
                normalized_files.append(file_info)
                num_files += 1
                shared_size += file_info[2]

                if num_files > cls.MAX_SAVED_SHARES_FILES:
                    raise ValueError("saved shares list contains too many files")

                continue

            if event_type != "end-folder" or normalized_files is None:
                raise ValueError("invalid saved shares JSON state")

            shares[folder_path] = normalized_files
            folder_path = None
            normalized_files = None

        if normalized_files is not None:
            raise ValueError("saved shares JSON ended inside folder")

        return shares, num_folders, num_files, shared_size

    @classmethod
    def _load_legacy_shares_list(cls, shares_list):
        cls._validate_loaded_shares_list(shares_list)
        shares = {}
        num_folders = 0
        num_files = 0
        shared_size = 0

        for folder_path, files in cls._iter_folder_items(shares_list):
            if not isinstance(folder_path, str):
                raise TypeError("Invalid folder path")

            cls._check_saved_string_size(folder_path, FileListMessage.MAX_VIRTUAL_PATH_BYTES, "folder path")

            num_folders += 1
            normalized_files = []

            for file_info in files:
                file_info = list(file_info)
                file_info = cls._normalize_loaded_file_info(file_info)
                normalized_files.append(file_info)
                num_files += 1
                shared_size += file_info[2]

            shares[folder_path] = normalized_files

        return shares, num_folders, num_files, shared_size

    def load_shares_list_from_disk(self, file_path):

        file_path_encoded = encode_path(file_path)

        try:
            if os.path.getsize(file_path_encoded) > self.MAX_SAVED_SHARES_FILE_SIZE:
                raise ValueError("saved shares list exceeds maximum file size")

            try:
                # Try legacy format first
                import bz2

                with bz2.BZ2File(file_path_encoded) as file_handle:
                    from pynicotine.shares import RestrictedUnpickler
                    limited_file_handle = LimitedDecompressedReader(
                        file_handle, self.MAX_LEGACY_SAVED_SHARES_DECOMPRESSED_BYTES)
                    shares_list = RestrictedUnpickler(limited_file_handle, encoding="utf-8").load()
                    shares, num_folders, num_files, shared_size = self._load_legacy_shares_list(shares_list)

            except Exception:
                # Try new format. Stream top-level folder entries to avoid materializing
                # the entire saved browse cache before validating and emitting it.
                with open(file_path_encoded, encoding="utf-8") as file_handle:
                    shares, num_folders, num_files, shared_size = self._load_saved_json_shares_list(file_handle)

        except Exception as error:
            log.add(_("Loading Shares from disk failed: %(error)s"), {"error": error})
            return

        username = os.path.basename(file_path)
        browsed_user = self.users.get(username)

        if browsed_user is not None:
            browsed_user.clear()

        if not self._show_user(username):
            return

        msg = SharedFileListResponse()
        msg.username = username
        msg.list = shares
        msg.num_folders = num_folders
        msg.num_files = num_files
        msg.shared_size = shared_size

        events.emit("shared-file-list-response", msg)

    def _write_saved_shares_list_to_file(self, file_handle, browsed_user):
        # Dump every folder to the file individually to avoid large memory usage.
        # The caller is expected to provide a temporary file managed by
        # write_file_and_backup(), so a failed save does not truncate the last
        # readable browse cache.
        json_encoder = json.JSONEncoder(check_circular=False, ensure_ascii=False)
        is_first_item = True

        file_handle.write("[")

        for folders in (browsed_user.public_folders, browsed_user.private_folders):
            for folder_path, files in folders.items():
                if is_first_item:
                    is_first_item = False
                else:
                    file_handle.write(",\n")

                self._write_saved_folder_item(file_handle, json_encoder, folder_path, files)

        file_handle.write("]")

    def save_shares_list_to_disk(self, username):

        folder_path = self.create_user_shares_folder()

        if not folder_path:
            return

        try:
            file_path = os.path.join(folder_path, clean_file(username))
            browsed_user = self.users[username]

            if not write_file_and_backup(
                file_path,
                lambda file_handle: self._write_saved_shares_list_to_file(file_handle, browsed_user)
            ):
                return

            log.add(_("Saved list of shared files for user '%(user)s' to %(dir)s"),
                    {"user": username, "dir": folder_path})

        except Exception as error:
            log.add(_("Can't save shares, '%(user)s', reported error: %(error)s"), {"user": username, "error": error})

    def _check_bulk_folder_transfer_limit(self, username, requested_folder_path, num_files):

        if num_files <= self.MAX_BULK_FOLDER_TRANSFER_FILES:
            self._bulk_folder_limit_logged = False
            return True

        if not self._bulk_folder_limit_logged:
            log.add_transfer(
                "Folder %s for user %s contains %s files, exceeding the bulk folder transfer limit of %s",
                (requested_folder_path, username, num_files, self.MAX_BULK_FOLDER_TRANSFER_FILES)
            )
            self._bulk_folder_limit_logged = True

        return False

    def _count_matching_folder_files(self, username, requested_folder_path, browsed_user, recurse=False,
                                     stop_after=None):

        num_files = 0

        for _folder_path, files in self.iter_matching_folders(requested_folder_path, browsed_user, recurse=recurse):
            num_files += len(files)

            if stop_after is not None and num_files > stop_after:
                break

            if not self._check_bulk_folder_transfer_limit(username, requested_folder_path, num_files):
                break

        return num_files

    def _clear_pending_folder_transfers(self, username=None):

        if username is None:
            self._pending_folder_transfers.clear()
        else:
            self._pending_folder_transfers = deque(
                pending_transfer for pending_transfer in self._pending_folder_transfers
                if pending_transfer.username != username
            )

        if not self._pending_folder_transfers and self._pending_folder_transfer_timer_id is not None:
            events.cancel_scheduled(self._pending_folder_transfer_timer_id)
            self._pending_folder_transfer_timer_id = None

    def _add_pending_folder_transfer(self, kind, username, requested_folder_path, download_folder_path, recurse,
                                     browsed_user):

        if len(self._pending_folder_transfers) >= self.MAX_PENDING_FOLDER_TRANSFER_JOBS:
            log.add_transfer(
                "Maximum number of pending browsed folder transfer jobs reached; "
                "ignoring folder %s for user %s", (requested_folder_path, username)
            )
            return

        self._pending_folder_transfers.append(PendingBrowsedFolderTransfer(
            kind, username, requested_folder_path, download_folder_path, recurse,
            self.iter_matching_folders(requested_folder_path, browsed_user=browsed_user, recurse=recurse)
        ))

        if self._pending_folder_transfer_timer_id is None:
            self._process_pending_folder_transfers()

    def _schedule_pending_folder_transfers(self):

        if self._pending_folder_transfer_timer_id is not None or not self._pending_folder_transfers:
            return

        self._pending_folder_transfer_timer_id = events.schedule(
            delay=0, callback=self._process_pending_folder_transfers
        )

    def _advance_pending_folder_transfer(self, pending_transfer):

        try:
            pending_transfer.folder_path, pending_transfer.files = next(pending_transfer.folder_iterator)

        except StopIteration:
            return False

        pending_transfer.file_index = 0

        if pending_transfer.kind == "download":
            pending_transfer.destination_folder_path = core.downloads.get_folder_destination(
                pending_transfer.username, pending_transfer.folder_path,
                root_folder_path=pending_transfer.requested_folder_path,
                download_folder_path=pending_transfer.download_folder_path
            )

        return True

    def _process_pending_folder_transfers(self):

        self._pending_folder_transfer_timer_id = None
        num_processed = 0

        while self._pending_folder_transfers and num_processed < self.MAX_FOLDER_TRANSFER_FILES_PER_TICK:
            pending_transfer = self._pending_folder_transfers[0]

            while pending_transfer.files is None or pending_transfer.file_index >= len(pending_transfer.files):
                if not self._advance_pending_folder_transfer(pending_transfer):
                    self._pending_folder_transfers.popleft()
                    break

            if not self._pending_folder_transfers or self._pending_folder_transfers[0] is not pending_transfer:
                continue

            while pending_transfer.file_index < len(pending_transfer.files) \
                    and num_processed < self.MAX_FOLDER_TRANSFER_FILES_PER_TICK:
                file_data = pending_transfer.files[pending_transfer.file_index]
                pending_transfer.file_index += 1
                num_processed += 1

                if pending_transfer.kind == "download":
                    _code, basename, file_size, _ext, file_attributes, *_unused = file_data
                    file_path = "\\".join([pending_transfer.folder_path, basename])

                    if core.downloads.enqueue_download(
                        pending_transfer.username, file_path,
                        folder_path=pending_transfer.destination_folder_path, size=file_size,
                        file_attributes=file_attributes
                    ) is False:
                        pending_transfer.file_index = len(pending_transfer.files)
                        break

                else:
                    _code, basename, *_unused = file_data
                    file_path = "\\".join([pending_transfer.folder_path, basename])
                    core.uploads.enqueue_upload(pending_transfer.username, file_path)

        self._schedule_pending_folder_transfers()

    def download_file(self, username, folder_path, file_data, download_folder_path=None):

        _code, basename, file_size, _ext, file_attributes, *_unused = file_data
        file_path = "\\".join([folder_path, basename])

        core.downloads.enqueue_download(
            username, file_path, folder_path=download_folder_path, size=file_size, file_attributes=file_attributes)

    def download_folder(self, username, requested_folder_path, download_folder_path=None, recurse=False,
                        check_num_files=True):

        if requested_folder_path is None:
            return

        browsed_user = self.users[username]
        stop_after = self.LARGE_FOLDER_CONFIRM_FILE_LIMIT if check_num_files else None
        num_files = self._count_matching_folder_files(
            username, requested_folder_path, browsed_user, recurse=recurse, stop_after=stop_after)

        if not self._check_bulk_folder_transfer_limit(username, requested_folder_path, num_files):
            return

        if check_num_files and num_files > self.LARGE_FOLDER_CONFIRM_FILE_LIMIT:
            # Large folder, ask user for confirmation before downloading
            check_num_files = False
            events.emit(
                "download-large-folder", username, requested_folder_path, num_files,
                self.download_folder, (
                    username, requested_folder_path, download_folder_path, recurse, check_num_files
                )
            )
            return

        self._add_pending_folder_transfer(
            "download", username, requested_folder_path, download_folder_path, recurse, browsed_user
        )

    def upload_file(self, username, folder_path, file_data):

        _code, basename, *_unused = file_data
        file_path = "\\".join([folder_path, basename])

        core.uploads.enqueue_upload(username, file_path)

    def upload_folder(self, username, requested_folder_path, local_browsed_user, recurse=False):

        if not requested_folder_path or not username:
            return

        num_files = self._count_matching_folder_files(
            username, requested_folder_path, local_browsed_user, recurse=recurse)

        if not self._check_bulk_folder_transfer_limit(username, requested_folder_path, num_files):
            return

        self._add_pending_folder_transfer(
            "upload", username, requested_folder_path, None, recurse, local_browsed_user
        )

    @staticmethod
    def get_soulseek_url(username, path):

        import urllib.parse
        path = path.replace("\\", "/")
        return "slsk://" + urllib.parse.quote(f"{username}/{path}")

    @classmethod
    def _parse_soulseek_url(cls, url):
        """Parse an external slsk:// URL without retaining gross inputs.

        slsk:// links can arrive from the desktop/browser URI handler. Bound the
        raw string before percent decoding, then bound the decoded username and
        optional virtual path before they reach browse tabs, watch ledgers or
        peer-share requests.
        """

        import urllib.parse

        if not isinstance(url, str):
            return None

        if len(url.encode("utf-8", "replace")) > cls.MAX_SOULSEEK_URL_BYTES:
            return None

        url = urllib.parse.unquote(url.replace("slsk://", "", 1))

        if len(url.encode("utf-8", "replace")) > cls.MAX_SOULSEEK_URL_BYTES:
            return None

        username, _separator, file_path = url.partition("/")
        file_path = file_path.replace("/", "\\")

        if not username:
            return None

        if len(username.encode("utf-8", "replace")) > FileListMessage.MAX_USERNAME_FIELD_BYTES:
            return None

        if len(file_path.encode("utf-8", "replace")) > FileListMessage.MAX_VIRTUAL_PATH_BYTES:
            return None

        return username, file_path

    def open_soulseek_url(self, url):

        parsed_url = self._parse_soulseek_url(url)

        if parsed_url is None:
            log.add_debug("Ignoring malformed or oversized Soulseek URL")
            return False

        username, file_path = parsed_url

        self.browse_user(username, path=file_path)
        return True

    def _shared_file_list_progress(self, username, sock, _buffer_len, _msg_size_total):

        if username not in self.users:
            # We've removed the user. Close the connection to stop the user from
            # sending their response and wasting bandwidth.
            core.send_message_to_network_thread(CloseConnection(sock))

    def _shared_file_list_response(self, msg):

        username = msg.username
        browsed_user = self.users.get(username)

        if browsed_user is None:
            # The browse tab/request may have been removed while a large shares
            # list was still being parsed or waiting in the main-thread queue.
            # Avoid walking the entire result just to discard it.
            SHARED_FILE_LIST_USERS_ALLOWED.discard(username)
            return

        SHARED_FILE_LIST_USERS_ALLOWED.discard(username)

        if (getattr(msg, "num_folders", None) is not None
                and getattr(msg, "num_files", None) is not None
                and getattr(msg, "shared_size", None) is not None):
            num_folders = msg.num_folders
            num_files = msg.num_files
            shared_size = msg.shared_size
        else:
            num_folders = len(msg.list) + len(msg.privatelist)
            num_files = 0
            shared_size = 0

            for _folder_path, files in chain(
                    self._iter_folder_items(msg.list), self._iter_folder_items(msg.privatelist)):
                for file_info in files:
                    shared_size += file_info[2]

                num_files += len(files)

        browsed_user.public_folders = self._coerce_folder_mapping(msg.list)
        browsed_user.private_folders = self._coerce_folder_mapping(msg.privatelist)
        browsed_user.num_folders = num_folders
        browsed_user.num_files = num_files
        browsed_user.shared_size = shared_size

        core.pluginhandler.user_stats_notification(username, stats={
            "avgspeed": None,
            "files": num_files,
            "dirs": num_folders,
            "shared_size": shared_size,
            "source": "peer"
        })
