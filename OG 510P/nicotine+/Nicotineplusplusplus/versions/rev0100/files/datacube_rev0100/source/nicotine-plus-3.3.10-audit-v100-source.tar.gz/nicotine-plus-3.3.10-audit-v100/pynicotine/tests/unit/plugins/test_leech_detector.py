# COPYRIGHT (C) 2026 Nicotine+ Contributors

from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import Mock

from pynicotine.plugins.leech_detector import Plugin


class LeechDetectorPluginTest(TestCase):

    def _plugin(self):
        plugin = Plugin()
        plugin.core = SimpleNamespace(
            buddies=SimpleNamespace(users=set()),
            userbrowse=SimpleNamespace(request_user_shares=Mock()),
            users=SimpleNamespace(watched=set(), request_user_stats=Mock())
        )
        plugin.log = Mock()
        plugin.send_private = Mock()
        return plugin

    def test_probed_user_cache_evicts_oldest_user_at_cap(self):
        plugin = self._plugin()

        old_limit = Plugin.MAX_PROBED_USERS
        Plugin.MAX_PROBED_USERS = 2

        try:
            plugin._remember_probed_user("user1", "requesting_stats")
            plugin._remember_probed_user("user2", "requesting_stats")
            plugin._remember_probed_user("user3", "requesting_stats")

            self.assertNotIn("user1", plugin.probed_users)
            self.assertEqual({"user2", "user3"}, set(plugin.probed_users))

        finally:
            Plugin.MAX_PROBED_USERS = old_limit

    def test_automatic_message_lines_and_detected_leechers_are_capped(self):
        plugin = self._plugin()
        plugin.probed_users["leecher"] = "pending_leecher"
        plugin.settings["message"] = "one\ntwo\nthree\nfour"
        plugin.settings["detected_leechers"] = ["old1", "old2"]

        old_lines = Plugin.MAX_MESSAGE_LINES
        old_detected = Plugin.MAX_DETECTED_LEECHERS
        Plugin.MAX_MESSAGE_LINES = 2
        Plugin.MAX_DETECTED_LEECHERS = 2

        try:
            plugin.upload_finished_notification("leecher")

            self.assertEqual(
                [("leecher", "one"), ("leecher", "two")],
                [call.args[:2] for call in plugin.send_private.call_args_list]
            )
            self.assertEqual(["old2", "leecher"], plugin.settings["detected_leechers"])

        finally:
            Plugin.MAX_MESSAGE_LINES = old_lines
            Plugin.MAX_DETECTED_LEECHERS = old_detected
