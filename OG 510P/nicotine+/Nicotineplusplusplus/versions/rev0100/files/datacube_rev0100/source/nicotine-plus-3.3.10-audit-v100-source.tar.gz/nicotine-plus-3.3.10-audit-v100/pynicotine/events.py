# COPYRIGHT (C) 2022-2025 Nicotine+ Contributors
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import heapq
import time

from collections import defaultdict
from collections import deque
from threading import Thread


EVENT_NAMES = {
    # General
    "check-latest-version",
    "cli-command",
    "cli-prompt-finished",
    "confirm-quit",
    "enable-message-queue",
    "log-message",
    "queue-network-message",
    "quit",
    "schedule-quit",
    "set-connection-stats",
    "setup",
    "start",
    "thread-callback",

    # Users
    "admin-message",
    "change-password",
    "check-privileges",
    "connect-to-peer",
    "invalid-password",
    "invalid-username",
    "peer-address",
    "peer-message-unsent",
    "peer-request-unsent",
    "peer-response-delivery-failed",
    "peer-response-unsent",
    "privileged-users",
    "server-disconnect",
    "server-login",
    "server-message-unsent",
    "server-response-delivery-failed",
    "server-reconnect",
    "user-country",
    "user-stats",
    "user-status",
    "watch-user",

    # Notification messages
    "show-notification",
    "show-chatroom-notification",
    "show-download-notification",
    "show-private-chat-notification",
    "show-search-notification",

    # Buddy list
    "add-buddy",
    "buddy-note",
    "buddy-notify",
    "buddy-last-seen",
    "buddy-prioritized",
    "buddy-trusted",
    "remove-buddy",

    # Chatrooms
    "clear-room-messages",
    "echo-room-message",
    "global-room-message",
    "join-room",
    "leave-room",
    "private-room-add-operator",
    "private-room-add-user",
    "private-room-added",
    "private-room-operator-added",
    "private-room-operator-removed",
    "private-room-operators",
    "private-room-remove-operator",
    "private-room-remove-user",
    "private-room-removed",
    "private-room-toggle",
    "private-room-users",
    "remove-room",
    "room-completions",
    "room-list",
    "say-chat-room",
    "show-room",
    "ticker-add",
    "ticker-remove",
    "ticker-state",
    "user-joined-room",
    "user-left-room",

    # Interests
    "add-dislike",
    "add-interest",
    "global-recommendations",
    "item-recommendations",
    "item-similar-users",
    "recommendations",
    "remove-dislike",
    "remove-interest",
    "similar-users",

    # Network filter
    "ban-user",
    "ban-user-ip",
    "ignore-user",
    "ignore-user-ip",
    "unban-user",
    "unban-user-ip",
    "unignore-user",
    "unignore-user-ip",

    # Private chat
    "clear-private-messages",
    "echo-private-message",
    "message-user",
    "private-chat-completions",
    "private-chat-remove-user",
    "private-chat-show-user",

    # Search
    "add-search",
    "add-wish",
    "excluded-search-phrases",
    "file-search-request-distributed",
    "file-search-request-server",
    "file-search-response",
    "remove-search",
    "remove-wish",
    "set-wishlist-interval",
    "show-search",

    # Statistics
    "update-stat",

    # Shares
    "folder-contents-request",
    "shared-file-list-progress",
    "shared-file-list-request",
    "shared-file-list-response",
    "shares-preparing",
    "shares-ready",
    "shares-scanning",
    "shares-unavailable",
    "user-browse-remove-user",
    "user-browse-show-user",

    # Transfers
    "abort-download",
    "abort-downloads",
    "abort-upload",
    "abort-uploads",
    "clear-download",
    "clear-downloads",
    "clear-upload",
    "clear-uploads",
    "download-connection-closed",
    "download-file-error",
    "download-large-folder",
    "file-connection-closed",
    "file-download-progress",
    "file-transfer-init",
    "file-upload-progress",
    "folder-contents-response",
    "folder-download-finished",
    "peer-connection-closed",
    "peer-connection-error",
    "place-in-queue-request",
    "place-in-queue-response",
    "queue-upload",
    "transfer-request",
    "transfer-response",
    "update-download",
    "update-download-limits",
    "update-upload",
    "update-upload-limits",
    "upload-denied",
    "upload-failed",
    "upload-file-error",
    "uploads-shutdown-request",
    "uploads-shutdown-cancel",

    # User info
    "user-info-progress",
    "user-info-remove-user",
    "user-info-request",
    "user-info-response",
    "user-info-show-user",
    "user-interests",
}



def get_callback_plugin_name(function):
    module_name = getattr(function, "__module__", None)

    if not module_name:
        return None

    if module_name.startswith("pynicotine.plugins."):
        parts = module_name.split(".", 3)
        return parts[2] if len(parts) > 2 else None

    return module_name.split(".", 1)[0]


class SchedulerEvent:

    __slots__ = ("event_id", "next_time", "delay", "repeat", "callback", "callback_args", "retained_size")

    def __init__(self, event_id, next_time=None, delay=None, repeat=None,
                 callback=None, callback_args=None, retained_size=0):

        self.event_id = event_id
        self.next_time = next_time
        self.delay = delay
        self.repeat = repeat
        self.callback = callback
        self.callback_args = callback_args
        self.retained_size = retained_size


class ThreadEvent:

    __slots__ = ("event_name", "args", "kwargs", "coalesce_key", "retained_size", "is_critical")

    def __init__(self, event_name, args, kwargs, coalesce_key=None, retained_size=0, is_critical=False):

        self.event_name = event_name
        self.args = args
        self.kwargs = kwargs
        self.coalesce_key = coalesce_key
        self.retained_size = retained_size
        self.is_critical = is_critical


class Events:
    __slots__ = ("_callbacks", "_thread_events", "_thread_event_bytes", "_thread_event_byte_limit_logged",
                 "_coalesced_thread_events", "_critical_thread_events",
                 "_critical_thread_event_bytes", "_critical_thread_event_limit_logged",
                 "_dropped_thread_events",
                 "_pending_scheduler_events", "_pending_scheduler_cancel_ids",
                 "_pending_scheduler_callback_ids", "_pending_scheduler_callback_sizes",
                 "_pending_scheduler_callback_bytes", "_scheduler_callback_byte_limit_logged",
                 "_dropped_scheduler_events", "_deferred_scheduler_callbacks",
                 "_scheduler_events", "_scheduler_event_heap", "_scheduler_event_id",
                 "_scheduler_event_bytes", "_scheduler_event_byte_limit_logged", "_is_active")

    SCHEDULER_MAX_IDLE = 1
    MAX_THREAD_EVENTS_PER_TICK = 1000
    MAX_QUIT_THREAD_EVENTS = 1000
    MAX_PENDING_THREAD_EVENTS = 65536
    MAX_PENDING_THREAD_EVENT_BYTES = 256 * 1024 * 1024
    MAX_PENDING_CRITICAL_THREAD_EVENTS = 16384
    MAX_PENDING_CRITICAL_THREAD_EVENT_BYTES = 128 * 1024 * 1024
    MAX_SCHEDULED_EVENTS = 65536
    MAX_SCHEDULED_EVENT_BYTES = 128 * 1024 * 1024
    MAX_PENDING_SCHEDULER_CANCELS = 65536
    MAX_PENDING_SCHEDULER_EVENTS_PER_CYCLE = 4096
    MAX_PENDING_SCHEDULER_CALLBACKS = 8192
    MAX_PENDING_SCHEDULER_CALLBACK_BYTES = 128 * 1024 * 1024
    MAX_CALLBACKS_PER_EVENT = 4096
    SCHEDULER_CALLBACK_RETRY_DELAY = 0.1
    # These events are small control-plane transitions that keep core state machines
    # consistent after network-thread decisions. Main-thread queue caps should shed
    # noisy UI/log/progress work first, not disconnect/login/error transitions whose
    # loss can leave transfers, rooms or peer ledgers in stale states.
    CRITICAL_THREAD_EVENTS = {
        "quit",
        "server-login",
        "server-disconnect",
        "server-message-unsent",
        "server-response-delivery-failed",
        "server-reconnect",
        "shares-ready",
        "peer-connection-error",
        "peer-connection-closed",
        "file-connection-closed",
        "download-file-error",
        "upload-file-error",
        # Parsed network protocol messages that drive transfer/session state.
        # Losing these behind noisy UI/log backlog can leave local ledgers,
        # transfer rows or peer handshakes stale even though the wire message
        # was already accepted and parsed. They still use the critical shelf
        # caps below, unlike global connect/disconnect transitions.
        "change-password",
        "check-privileges",
        "connect-to-peer",
        "excluded-search-phrases",
        "message-user",
        "peer-address",
        # Parsed user/cache state messages can drive transfer retry/cancel logic,
        # IP-filter/cache updates and privilege state. Dropping them behind log/UI
        # backlog leaves accepted wire state unapplied, while these payloads are
        # small enough to fit the bounded critical shelf.
        "privileged-users",
        "set-wishlist-interval",
        "user-country",
        "user-stats",
        "user-status",
        "watch-user",
        "peer-message-unsent",
        "peer-request-unsent",
        "peer-response-delivery-failed",
        "peer-response-unsent",
        "file-transfer-init",
        "file-search-request-distributed",
        "file-search-request-server",
        "folder-contents-request",
        "join-room",
        "leave-room",
        "place-in-queue-request",
        "place-in-queue-response",
        "private-room-add-operator",
        "private-room-add-user",
        "private-room-added",
        "private-room-operator-added",
        "private-room-operator-removed",
        "private-room-operators",
        "private-room-remove-operator",
        "private-room-remove-user",
        "private-room-removed",
        "private-room-toggle",
        "private-room-users",
        "queue-upload",
        "shared-file-list-request",
        "ticker-add",
        "ticker-remove",
        "ticker-state",
        "transfer-request",
        "transfer-response",
        "upload-denied",
        "upload-failed",
        "user-info-request",
        "user-joined-room",
        "user-left-room"
    }
    # Server lifecycle/quit events are process-level transitions and are not
    # expected to arrive in attacker-controlled bursts. They stay unsheddable so
    # peer/file error bursts cannot hide a global disconnect or shutdown. Other
    # critical events get a separate high-water mark below.
    UNSHEDDABLE_THREAD_EVENTS = {
        "quit",
        "server-login",
        "server-disconnect",
        "server-reconnect",
        "shares-ready"
    }
    COALESCED_THREAD_EVENTS = {
        "file-download-progress",
        "file-upload-progress",
        "shared-file-list-progress",
        "user-info-progress"
    }

    def __init__(self):

        self._callbacks = defaultdict(list)
        self._thread_events = deque()
        self._thread_event_bytes = 0
        self._thread_event_byte_limit_logged = False
        self._coalesced_thread_events = {}
        self._critical_thread_events = 0
        self._critical_thread_event_bytes = 0
        self._critical_thread_event_limit_logged = False
        self._dropped_thread_events = 0
        self._pending_scheduler_events = deque()
        self._pending_scheduler_cancel_ids = set()
        self._pending_scheduler_callback_ids = set()
        self._pending_scheduler_callback_sizes = {}
        self._pending_scheduler_callback_bytes = 0
        self._scheduler_callback_byte_limit_logged = False
        self._dropped_scheduler_events = 0
        self._deferred_scheduler_callbacks = 0
        self._scheduler_events = {}
        self._scheduler_event_heap = []
        self._scheduler_event_id = 0
        self._scheduler_event_bytes = 0
        self._scheduler_event_byte_limit_logged = False
        self._is_active = False

    def enable(self):

        if self._is_active:
            return

        self._is_active = True

        for event_name, callback in (
            ("quit", self._quit),
            ("thread-callback", self._thread_callback)
        ):
            self.connect(event_name, callback)

        Thread(target=self._run_scheduler, name="SchedulerThread", daemon=True).start()

    def connect(self, event_name, function):

        if event_name not in EVENT_NAMES:
            raise ValueError(f"Unknown event {event_name}")

        callbacks = self._callbacks[event_name]

        if function in callbacks:
            return False

        if len(callbacks) >= self.MAX_CALLBACKS_PER_EVENT:
            return False

        callbacks.append(function)
        return True

    def disconnect(self, event_name, function):
        self._callbacks[event_name].remove(function)

    def emit(self, event_name, *args, **kwargs):

        callbacks = self._callbacks[event_name]

        if event_name == "queue-network-message" and not callbacks:
            # Queue-style senders use the return value as an accepted-work
            # boundary. With no network-thread consumer registered, reporting
            # success would let callers mutate local state for a message that
            # cannot be queued anywhere.
            return False

        if event_name == "quit":
            # Event and log modules register callbacks first, but need to quit last
            callbacks = list(reversed(callbacks))

        accepted = True

        for function in callbacks:
            try:
                if function(*args, **kwargs) is False:
                    accepted = False

            except Exception as error:
                from pynicotine import core
                plugin_name = get_callback_plugin_name(function)
                pluginhandler = getattr(core, "pluginhandler", None)

                if pluginhandler is None or plugin_name not in pluginhandler.enabled_plugins:
                    core.quit()
                    raise error

                # Exception occurred in a plugin callback, log a message and continue
                pluginhandler.show_plugin_error(plugin_name, error)

        return accepted

    def _get_thread_event_coalesce_key(self, event_name, args, kwargs):

        if event_name in {"file-download-progress", "file-upload-progress"}:
            if len(args) >= 2:
                username, token = args[:2]
            else:
                username = kwargs.get("username")
                token = kwargs.get("token")

        elif event_name in {"shared-file-list-progress", "user-info-progress"}:
            if len(args) >= 2:
                username, token = args[:2]
            else:
                username = kwargs.get("username")
                token = kwargs.get("sock")

        elif event_name == "shares-scanning":
            # The share scanner can report progress for a very large number of
            # folders. During GTK stalls only the newest progress value matters;
            # the final shares-ready state transition is emitted separately and
            # must never be hidden behind a progress catch-up storm.
            return (event_name,)

        else:
            return None

        if username is None or token is None:
            return None

        # Transfer and large peer-response progress events are keyed by the
        # stable transfer/socket identity. During UI stalls or very fast peers,
        # keeping only the latest progress update avoids catch-up storms without
        # dropping completion/error/response events.
        return event_name, username, token

    @classmethod
    def _estimate_thread_event_size(cls, event_name, args, kwargs):
        """Estimate retained bytes for a cross-thread event payload.

        Count caps protect against huge numbers of events, but one parsed peer
        response or deferred callback can retain large nested lists/strings while
        the main thread is stalled. This intentionally approximates retained
        payload size instead of walking Python object internals exactly.
        """

        total = len(event_name) + 128
        seen = set()
        limit = cls.MAX_PENDING_THREAD_EVENT_BYTES

        def add(value):
            nonlocal total

            if value is None or total > limit:
                return

            value_id = id(value)

            if value_id in seen:
                return

            seen.add(value_id)

            if isinstance(value, (bytes, bytearray, memoryview)):
                total += len(value)
                return

            if isinstance(value, str):
                total += len(value.encode("utf-8", "replace"))
                return

            if isinstance(value, dict):
                total += len(value) * 64

                for key, item in value.items():
                    add(key)
                    add(item)

                    if total > limit:
                        break

                return

            if isinstance(value, (list, tuple, set, frozenset, deque)):
                total += len(value) * 32

                for item in value:
                    add(item)

                    if total > limit:
                        break

                return

            for attr in getattr(value, "__slots__", ()):  # slskmessages and transfer objects are slot-based
                try:
                    add(getattr(value, attr))

                except AttributeError:
                    continue

                if total > limit:
                    break

        add(args)
        add(kwargs)
        return total

    def _release_thread_event_size(self, event):
        retained_size = getattr(event, "retained_size", 0)

        if getattr(event, "is_critical", False):
            self._critical_thread_events = max(0, self._critical_thread_events - 1)

            if retained_size > 0:
                self._critical_thread_event_bytes = max(
                    0, self._critical_thread_event_bytes - retained_size)

            if (self._critical_thread_events < (self.MAX_PENDING_CRITICAL_THREAD_EVENTS // 2)
                    and self._critical_thread_event_bytes < (self.MAX_PENDING_CRITICAL_THREAD_EVENT_BYTES // 2)):
                self._critical_thread_event_limit_logged = False

        if retained_size <= 0:
            return

        self._thread_event_bytes = max(0, self._thread_event_bytes - retained_size)

        if self._thread_event_bytes < (self.MAX_PENDING_THREAD_EVENT_BYTES // 2):
            self._thread_event_byte_limit_logged = False

    def _clear_thread_events(self):
        self._thread_events.clear()
        self._coalesced_thread_events.clear()
        self._critical_thread_events = 0
        self._critical_thread_event_bytes = 0
        self._critical_thread_event_limit_logged = False
        self._thread_event_bytes = 0
        self._thread_event_byte_limit_logged = False

    @classmethod
    def _estimate_scheduler_event_size(cls, callback_args):
        """Estimate retained bytes for callback args held by scheduler timers."""

        if callback_args is None:
            callback_args = ()

        return cls._estimate_thread_event_size("scheduler-callback", callback_args, {})

    def _release_scheduler_event_size(self, event):
        retained_size = getattr(event, "retained_size", 0)

        if retained_size <= 0:
            return

        self._scheduler_event_bytes = max(0, self._scheduler_event_bytes - retained_size)
        event.retained_size = 0

        if self._scheduler_event_bytes < (self.MAX_SCHEDULED_EVENT_BYTES // 2):
            self._scheduler_event_byte_limit_logged = False

    def _clear_scheduler_events(self):
        self._pending_scheduler_events.clear()
        self._pending_scheduler_cancel_ids.clear()
        self._pending_scheduler_callback_ids.clear()
        self._pending_scheduler_callback_sizes.clear()
        self._pending_scheduler_callback_bytes = 0
        self._scheduler_callback_byte_limit_logged = False
        self._scheduler_events.clear()
        self._scheduler_event_heap.clear()
        self._scheduler_event_bytes = 0
        self._scheduler_event_byte_limit_logged = False

    def _can_enqueue_critical_thread_event(self, event_name, retained_size, replacing_event=None):
        if event_name in self.UNSHEDDABLE_THREAD_EVENTS:
            return True

        current_critical_events = self._critical_thread_events
        current_critical_bytes = self._critical_thread_event_bytes

        if replacing_event is not None and getattr(replacing_event, "is_critical", False):
            current_critical_events = max(0, current_critical_events - 1)
            current_critical_bytes = max(0, current_critical_bytes - getattr(replacing_event, "retained_size", 0))

        if current_critical_events >= self.MAX_PENDING_CRITICAL_THREAD_EVENTS:
            self._critical_thread_event_limit_logged = True
            return False

        if current_critical_bytes + retained_size > self.MAX_PENDING_CRITICAL_THREAD_EVENT_BYTES:
            self._critical_thread_event_limit_logged = True
            return False

        return True

    def emit_main_thread(self, event_name, *args, _is_critical=False, **kwargs):

        coalesce_key = self._get_thread_event_coalesce_key(event_name, args, kwargs)
        is_critical = _is_critical or event_name in self.CRITICAL_THREAD_EVENTS

        retained_size = self._estimate_thread_event_size(event_name, args, kwargs)

        if coalesce_key is not None:
            event = self._coalesced_thread_events.get(coalesce_key)

            if event is not None:
                old_size = event.retained_size
                new_total = self._thread_event_bytes - old_size + retained_size

                if (not is_critical
                        and new_total > self.MAX_PENDING_THREAD_EVENT_BYTES):
                    self._dropped_thread_events += 1
                    return False

                if is_critical and not self._can_enqueue_critical_thread_event(
                        event_name, retained_size, replacing_event=event):
                    self._dropped_thread_events += 1
                    return False

                event.args = args
                event.kwargs = kwargs
                event.retained_size = retained_size
                self._thread_event_bytes = max(0, self._thread_event_bytes - old_size + retained_size)

                if event.is_critical:
                    self._critical_thread_event_bytes = max(
                        0, self._critical_thread_event_bytes - old_size + retained_size)

                elif is_critical:
                    event.is_critical = True
                    self._critical_thread_events += 1
                    self._critical_thread_event_bytes += retained_size

                return True

        if (not is_critical
                and len(self._thread_events) >= self.MAX_PENDING_THREAD_EVENTS):
            self._dropped_thread_events += 1
            return False

        if (not is_critical
                and self._thread_event_bytes + retained_size > self.MAX_PENDING_THREAD_EVENT_BYTES):
            self._dropped_thread_events += 1
            self._thread_event_byte_limit_logged = True
            return False

        if is_critical and not self._can_enqueue_critical_thread_event(event_name, retained_size):
            self._dropped_thread_events += 1
            return False

        event = ThreadEvent(
            event_name, args, kwargs, coalesce_key=coalesce_key,
            retained_size=retained_size, is_critical=is_critical)

        if coalesce_key is not None:
            self._coalesced_thread_events[coalesce_key] = event

        self._thread_events.append(event)
        self._thread_event_bytes += retained_size

        if is_critical:
            self._critical_thread_events += 1
            self._critical_thread_event_bytes += retained_size

        return True

    def invoke_main_thread(self, callback, *args, _critical=False, **kwargs):
        return self.emit_main_thread("thread-callback", callback, *args, _is_critical=_critical, **kwargs)

    def _release_pending_scheduler_callback_size(self, event_id):
        retained_size = self._pending_scheduler_callback_sizes.pop(event_id, 0)

        if retained_size <= 0:
            return

        self._pending_scheduler_callback_bytes = max(0, self._pending_scheduler_callback_bytes - retained_size)

        if self._pending_scheduler_callback_bytes < (self.MAX_PENDING_SCHEDULER_CALLBACK_BYTES // 2):
            self._scheduler_callback_byte_limit_logged = False

    def _clear_pending_scheduler_callback(self, event_id):
        self._pending_scheduler_callback_ids.discard(event_id)
        self._release_pending_scheduler_callback_size(event_id)

    def _run_scheduler_callback(self, event_id, callback, callback_args):
        # Keep the event marked as pending while the callback itself runs. A
        # slow callback still occupies the main thread; allowing the scheduler
        # to enqueue the same repeating callback during that window recreates
        # the catch-up storm that this coalescing layer is meant to prevent.
        try:
            callback(*callback_args)
        finally:
            self._clear_pending_scheduler_callback(event_id)

    def _scheduler_callback_backpressured(self, event):
        if event.event_id in self._pending_scheduler_callback_ids:
            return False

        if len(self._pending_scheduler_callback_ids) >= self.MAX_PENDING_SCHEDULER_CALLBACKS:
            return True

        retained_size = getattr(event, "retained_size", 0)

        if self._pending_scheduler_callback_bytes + retained_size > self.MAX_PENDING_SCHEDULER_CALLBACK_BYTES:
            self._scheduler_callback_byte_limit_logged = True
            return True

        return False

    def _defer_scheduler_callback(self, event, current_time):
        event.next_time = (current_time + self.SCHEDULER_CALLBACK_RETRY_DELAY)
        heapq.heappush(self._scheduler_event_heap, (event.next_time, event.event_id))
        self._deferred_scheduler_callbacks += 1

    def _invoke_scheduler_callback(self, event):
        if event.event_id in self._pending_scheduler_callback_ids:
            return False

        if self._scheduler_callback_backpressured(event):
            self._deferred_scheduler_callbacks += 1
            return False

        retained_size = getattr(event, "retained_size", 0)
        self._pending_scheduler_callback_ids.add(event.event_id)

        if retained_size > 0:
            self._pending_scheduler_callback_sizes[event.event_id] = retained_size
            self._pending_scheduler_callback_bytes += retained_size

        if not self.emit_main_thread(
                "thread-callback", self._run_scheduler_callback, event.event_id,
                event.callback, event.callback_args, _is_critical=True):
            self._clear_pending_scheduler_callback(event.event_id)
            return False

        return True

    def _queue_due_scheduler_callback(self, event, current_time):
        if self._scheduler_callback_backpressured(event):
            # The main-thread callback lane is already saturated with due
            # scheduler work. Keep this event alive and retry shortly
            # instead of appending another critical thread event.
            self._defer_scheduler_callback(event, current_time)
            return False

        if not self._invoke_scheduler_callback(event):
            # A second backpressure gate can reject the callback after the
            # scheduler-lane check, for example if the main-thread critical
            # queue fills between checks. Keep the due timer alive and retry it
            # later; one-shot callbacks must not be silently dropped merely
            # because the bridge was full for this scheduler cycle.
            self._defer_scheduler_callback(event, current_time)
            return False

        return True

    def schedule(self, delay, callback, callback_args=None, repeat=False):

        if callback_args is None:
            callback_args = ()

        retained_size = self._estimate_scheduler_event_size(callback_args)

        if len(self._scheduler_events) + len(self._pending_scheduler_events) >= self.MAX_SCHEDULED_EVENTS:
            self._dropped_scheduler_events += 1
            return None

        if self._scheduler_event_bytes + retained_size > self.MAX_SCHEDULED_EVENT_BYTES:
            self._scheduler_event_byte_limit_logged = True
            self._dropped_scheduler_events += 1
            return None

        self._scheduler_event_id += 1
        next_time = (time.monotonic() + delay)
        self._scheduler_event_bytes += retained_size

        self._pending_scheduler_events.append(
            SchedulerEvent(
                self._scheduler_event_id, next_time, delay, repeat, callback, callback_args,
                retained_size=retained_size
            )
        )
        return self._scheduler_event_id

    def cancel_scheduled(self, event_id):

        if event_id is None or event_id in self._pending_scheduler_cancel_ids:
            return

        if len(self._pending_scheduler_cancel_ids) >= self.MAX_PENDING_SCHEDULER_CANCELS:
            self._dropped_scheduler_events += 1
            return

        if len(self._pending_scheduler_events) >= self.MAX_SCHEDULED_EVENTS:
            self._dropped_scheduler_events += 1
            return

        self._pending_scheduler_cancel_ids.add(event_id)
        self._pending_scheduler_events.append(SchedulerEvent(event_id, next_time=None))

    def process_thread_events(self, max_events=None):
        """Called by the main loop 10 times per second to emit thread events in
        the main thread.

        Return value indicates if the main loop should continue
        processing events.
        """

        if not self._thread_events:
            if not self._is_active:
                return False

            return True

        if max_events is None:
            max_events = self.MAX_THREAD_EVENTS_PER_TICK

        event_list = []

        while self._thread_events and (max_events <= 0 or len(event_list) < max_events):
            event = self._thread_events.popleft()
            self._release_thread_event_size(event)

            if event.coalesce_key is not None:
                self._coalesced_thread_events.pop(event.coalesce_key, None)

            event_list.append(event)

        for event in event_list:
            self.emit(event.event_name, *event.args, **event.kwargs)

        return True

    @staticmethod
    def _get_next_repeat_time(event_time, delay, current_time):
        next_time = (event_time + delay)

        if next_time <= current_time:
            return (current_time + delay)

        return next_time

    @classmethod
    def _reschedule_repeating_event(cls, event, current_time):
        event.next_time = cls._get_next_repeat_time(event.next_time, event.delay, current_time)

    def _add_scheduler_event(self, event):
        self._scheduler_events[event.event_id] = event
        heapq.heappush(self._scheduler_event_heap, (event.next_time, event.event_id))

    def _process_pending_scheduler_event(self, event):

        if event.next_time is not None:
            self._add_scheduler_event(event)
            return

        self._pending_scheduler_cancel_ids.discard(event.event_id)
        removed_event = self._scheduler_events.pop(event.event_id, None)

        if removed_event is not None:
            self._release_scheduler_event_size(removed_event)

    def _process_pending_scheduler_events(self, max_events=None):
        if max_events is None:
            max_events = self.MAX_PENDING_SCHEDULER_EVENTS_PER_CYCLE

        processed_events = 0

        while self._pending_scheduler_events and (max_events <= 0 or processed_events < max_events):
            self._process_pending_scheduler_event(self._pending_scheduler_events.popleft())
            processed_events += 1

        return processed_events

    def _process_pending_scheduler_cycle(self):
        """Process one bounded scheduler-management batch.

        Return True only when all pending add/cancel records have been applied.
        The scheduler must not run due timers while cancellation tombstones are
        still waiting behind the per-cycle batch limit, otherwise a timer that
        was already cancelled by another thread can fire once before its cancel
        record is processed.
        """

        self._process_pending_scheduler_events()
        return not self._pending_scheduler_events

    def _get_next_scheduler_event(self):

        while self._scheduler_event_heap:
            next_time, event_id = self._scheduler_event_heap[0]
            event = self._scheduler_events.get(event_id)

            if event is not None and event.next_time == next_time:
                return event

            # The heap entry belongs to a cancelled or rescheduled event.
            heapq.heappop(self._scheduler_event_heap)

        return None

    def _run_scheduler(self):

        while self._is_active:
            # Scheduled event additions/removals from other threads. Process these in
            # batches so a timer-management burst cannot monopolize the scheduler
            # thread and delay already-due callbacks indefinitely. Keep draining
            # queued add/cancel records across cycles before running due timers,
            # so a cancellation tombstone cannot sit behind the batch limit while
            # its already-due timer fires once.
            if not self._process_pending_scheduler_cycle():
                continue

            # No scheduled events
            event = self._get_next_scheduler_event()

            if event is None:
                if self._pending_scheduler_events:
                    continue

                time.sleep(self.SCHEDULER_MAX_IDLE)
                continue

            # Retrieve upcoming event
            event_time = event.next_time
            current_time = time.monotonic()
            sleep_time = (event_time - current_time)

            if sleep_time > 0:
                time.sleep(min(sleep_time, self.SCHEDULER_MAX_IDLE))
                continue

            if not self._queue_due_scheduler_callback(event, current_time):
                time.sleep(min(self.SCHEDULER_CALLBACK_RETRY_DELAY, self.SCHEDULER_MAX_IDLE))
                continue

            if event.repeat:
                self._reschedule_repeating_event(event, time.monotonic())
                heapq.heappush(self._scheduler_event_heap, (event.next_time, event.event_id))
                continue

            finished_event = self._scheduler_events.pop(event.event_id, None)

            if finished_event is not None:
                self._release_scheduler_event_size(finished_event)

    def _thread_callback(self, callback, *args, **kwargs):
        callback(*args, **kwargs)

    def _quit(self):

        # Process a bounded snapshot of already queued thread events so
        # essential callbacks posted by worker threads still have a chance to
        # run. Do not drain the whole queue: a backlog can contain tens of
        # thousands of stale UI/log/progress events, and callbacks can enqueue
        # more work while quitting. Shutdown should not become an unbounded
        # catch-up loop.
        self.process_thread_events(max_events=self.MAX_QUIT_THREAD_EVENTS)

        self._is_active = False
        self._callbacks.clear()
        self._clear_thread_events()
        self._dropped_thread_events = 0
        self._clear_scheduler_events()
        self._dropped_scheduler_events = 0
        self._deferred_scheduler_callbacks = 0


events = Events()
