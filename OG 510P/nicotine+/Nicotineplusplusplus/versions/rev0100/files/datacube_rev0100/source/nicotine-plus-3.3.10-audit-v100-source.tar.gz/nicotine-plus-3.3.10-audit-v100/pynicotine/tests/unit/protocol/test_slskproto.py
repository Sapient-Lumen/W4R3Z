# COPYRIGHT (C) 2020-2025 Nicotine+ Contributors
# COPYRIGHT (C) 2020 Lene Preuss <lene.preuss@gmail.com>
#
# GNU GENERAL PUBLIC LICENSE
#    Version 3, 29 June 2007
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

import os
import pickle
import selectors
import shutil
import socket
import sys
import time

from collections import defaultdict
from collections import deque
from types import SimpleNamespace

from time import sleep
from unittest import TestCase
from unittest.mock import MagicMock
from unittest.mock import Mock
from unittest.mock import patch

from pynicotine.config import config
from pynicotine.core import core
from pynicotine.events import events
import pynicotine.slskproto as slskproto_module
from pynicotine.slskmessages import DISTRIBUTED_MESSAGE_CODES
from pynicotine.slskmessages import PEER_INIT_MESSAGE_CODES
from pynicotine.slskmessages import PEER_MESSAGE_CODES
from pynicotine.slskmessages import AcceptChildren
from pynicotine.slskmessages import CantConnectToPeer
from pynicotine.slskmessages import ConnectionType
from pynicotine.slskmessages import ChangePassword
from pynicotine.slskmessages import CheckPrivileges
from pynicotine.slskmessages import CloseConnection
from pynicotine.slskmessages import ConnectToPeer
from pynicotine.slskmessages import DistribBranchLevel
from pynicotine.slskmessages import DistribBranchRoot
from pynicotine.slskmessages import DistribEmbeddedMessage
from pynicotine.slskmessages import DistribSearch
from pynicotine.slskmessages import DownloadFile
from pynicotine.slskmessages import EmitNetworkMessageEvents
from pynicotine.slskmessages import EmbeddedMessage
from pynicotine.slskmessages import ExcludedSearchPhrases
from pynicotine.slskmessages import FileOffset
from pynicotine.slskmessages import FileSearch
from pynicotine.slskmessages import FileSearchResponse
from pynicotine.slskmessages import FOLDER_TOKENS_ALLOWED
from pynicotine.slskmessages import FolderContentsRequest
from pynicotine.slskmessages import FolderContentsResponse
from pynicotine.slskmessages import FileTransferInit
from pynicotine.slskmessages import GetPeerAddress
from pynicotine.slskmessages import GetUserStats
from pynicotine.slskmessages import GetUserStatus
from pynicotine.slskmessages import GLOBAL_RECOMMENDATIONS_ALLOWED
from pynicotine.slskmessages import GLOBAL_ROOM_FEED_ALLOWED
from pynicotine.slskmessages import GlobalRoomMessage
from pynicotine.slskmessages import GlobalUserList
from pynicotine.slskmessages import GlobalRecommendations
from pynicotine.slskmessages import ITEM_RECOMMENDATIONS_ALLOWED
from pynicotine.slskmessages import ITEM_SIMILAR_USERS_ALLOWED
from pynicotine.slskmessages import ItemRecommendations
from pynicotine.slskmessages import ItemSimilarUsers
from pynicotine.slskmessages import RECOMMENDATIONS_ALLOWED
from pynicotine.slskmessages import Recommendations
from pynicotine.slskmessages import SEARCH_TOKENS_ALLOWED
from pynicotine.slskmessages import SIMILAR_USERS_ALLOWED
from pynicotine.slskmessages import SimilarUsers
from pynicotine.slskmessages import USER_INTERESTS_USERS_ALLOWED
from pynicotine.slskmessages import UserInterests
from pynicotine.slskmessages import UserSearch
from pynicotine.slskmessages import RoomList
from pynicotine.slskmessages import RoomSearch
from pynicotine.slskmessages import RoomTickerAdd
from pynicotine.slskmessages import RoomTickerRemove
from pynicotine.slskmessages import RoomTickerState
from pynicotine.slskmessages import WishlistSearch
from pynicotine.slskmessages import JoinGlobalRoom
from pynicotine.slskmessages import JoinRoom
from pynicotine.slskmessages import LeaveGlobalRoom
from pynicotine.slskmessages import LeaveRoom
from pynicotine.slskmessages import Login
from pynicotine.slskmessages import MessageUser
from pynicotine.slskmessages import MessageAcked
from pynicotine.slskmessages import PeerInit
from pynicotine.slskmessages import PlaceInQueueRequest
from pynicotine.slskmessages import PMessageUser
from pynicotine.slskmessages import PrivateRoomAddUser
from pynicotine.slskmessages import PrivateRoomAdded
from pynicotine.slskmessages import PrivateRoomOperators
from pynicotine.slskmessages import PrivateRoomRemoveUser
from pynicotine.slskmessages import PrivateRoomToggle
from pynicotine.slskmessages import PrivateRoomUsers
from pynicotine.slskmessages import PossibleParents
from pynicotine.slskmessages import QueueUpload
from pynicotine.slskmessages import SharedFileListRequest
from pynicotine.slskmessages import SHARED_FILE_LIST_USERS_ALLOWED
from pynicotine.slskmessages import SharedFileListResponse
from pynicotine.slskmessages import SERVER_MESSAGE_CODES
from pynicotine.slskmessages import ServerConnect
from pynicotine.slskmessages import ServerDisconnect
from pynicotine.slskmessages import SetDownloadLimit
from pynicotine.slskmessages import SetWaitPort
from pynicotine.slskmessages import SayChatroom
from pynicotine.slskmessages import ServerMessage
from pynicotine.slskmessages import ServerPing
from pynicotine.slskmessages import TransferDirection
from pynicotine.slskmessages import TransferRequest
from pynicotine.slskmessages import TransferResponse
from pynicotine.slskmessages import UploadFile
from pynicotine.slskmessages import UploadQueueNotification
from pynicotine.slskmessages import USER_INFO_USERS_ALLOWED
from pynicotine.slskmessages import UserInfoRequest
from pynicotine.slskmessages import UserInfoResponse
from pynicotine.slskmessages import UserJoinedRoom
from pynicotine.slskmessages import UserLeftRoom
from pynicotine.slskmessages import UserStatus
from pynicotine.slskmessages import WishlistInterval
from pynicotine.slskproto import NetworkThread
from pynicotine.slskproto import PendingPeerConnection
from pynicotine.slskproto import PeerConnection
from pynicotine.slskproto import ServerConnection
from pynicotine.utils import encode_path

DATA_FOLDER_PATH = os.path.join(os.path.dirname(os.path.realpath(__file__)), "temp_data")
SLSKPROTO_RUN_TIME = 1.5  # Time (in s) needed for SoulseekNetworkThread main loop to run at least once


class MockSocket(Mock):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.events = None

    def set_data(self, datafile):

        windows_line_ending = b"\r\n"
        unix_line_ending = b"\n"

        file_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), datafile)

        with open(encode_path(file_path), "rb") as file_handle:
            content = file_handle.read()

        content = content.replace(windows_line_ending, unix_line_ending)
        logs = pickle.loads(content, encoding="bytes")
        self.events = {}

        for mode in b"send", b"recv":
            for time, event in logs[b"transactions"][mode].items():
                self.events[time] = (mode.decode("latin1"), event)

    @staticmethod
    def send(data):
        print(f"sending data {data}")

    @staticmethod
    def recv(bufsize):
        print(f"recving {bufsize} data")
        return b""


class NetworkThreadUnitTest(TestCase):

    # pylint: disable=protected-access

    def test_parse_error_log_content_is_bounded(self):
        """Malformed huge messages should not be stringified in full for debug logs."""

        class FailingMessage:
            def parse_network_message(self, _message):
                raise ValueError("bad message")

        content = memoryview(b"x" * (NetworkThread.MAX_LOGGED_MESSAGE_CONTENT_SIZE + 100))

        fake_log = SimpleNamespace(add_debug=Mock())

        with patch.object(slskproto_module, "log", fake_log):
            self.assertIsNone(NetworkThread._unpack_network_message(
                FailingMessage, content, len(content), conn_type="peer"))

        logged_content = fake_log.add_debug.call_args.args[1][3]
        self.assertIn("bytes omitted", logged_content)
        self.assertLess(len(logged_content), NetworkThread.MAX_LOGGED_MESSAGE_CONTENT_SIZE + 80)

    def test_large_message_progress_events_are_throttled(self):
        """Huge browse/user-info responses should not enqueue progress on every recv()."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.PEER)
        )
        msg_size = NetworkThread.MAX_INCOMING_MESSAGE_SIZE - 1
        header = bytearray(
            SharedFileListResponse.pack_uint32(msg_size)
            + SharedFileListResponse.pack_uint32(PEER_MESSAGE_CODES[SharedFileListResponse])
        )

        old_interval = NetworkThread.LARGE_MESSAGE_PROGRESS_INTERVAL
        NetworkThread.LARGE_MESSAGE_PROGRESS_INTERVAL = 100
        SHARED_FILE_LIST_USERS_ALLOWED.clear()
        SHARED_FILE_LIST_USERS_ALLOWED.add("user")

        try:
            fake_events = SimpleNamespace(emit_main_thread=Mock())

            with patch.object(slskproto_module, "events", fake_events):
                conn.in_buffer = header[:]
                network_thread._process_peer_input(conn)

                conn.in_buffer = header[:] + (b"x" * 50)
                network_thread._process_peer_input(conn)

                conn.in_buffer = header[:] + (b"x" * 100)
                network_thread._process_peer_input(conn)

            emit_main_thread = fake_events.emit_main_thread
            self.assertEqual(2, emit_main_thread.call_count)
            self.assertEqual("shared-file-list-progress", emit_main_thread.call_args_list[0].args[0])
            self.assertEqual("shared-file-list-progress", emit_main_thread.call_args_list[1].args[0])

        finally:
            NetworkThread.LARGE_MESSAGE_PROGRESS_INTERVAL = old_interval
            SHARED_FILE_LIST_USERS_ALLOWED.clear()

    def test_indirect_request_timeouts_are_batched(self):
        """A large indirect-connect timeout set should not emit all failures in one cycle."""

        network_thread = self._create_network_thread()
        old_limit = NetworkThread.MAX_INDIRECT_REQUEST_TIMEOUTS_PER_TICK
        NetworkThread.MAX_INDIRECT_REQUEST_TIMEOUTS_PER_TICK = 2
        network_thread._indirect_request_error = Mock()

        try:
            for token in range(5):
                init = PeerInit(target_user=f"user{token}", conn_type=ConnectionType.PEER)
                network_thread._token_init_msgs[token] = (init, 0)

            network_thread._check_indirect_request_timeouts(
                current_time=NetworkThread.INDIRECT_REQUEST_TIMEOUT + 1
            )

            self.assertEqual(2, network_thread._indirect_request_error.call_count)
            self.assertEqual(3, len(network_thread._token_init_msgs))

            network_thread._check_indirect_request_timeouts(
                current_time=NetworkThread.INDIRECT_REQUEST_TIMEOUT + 1
            )

            self.assertEqual(4, network_thread._indirect_request_error.call_count)
            self.assertEqual(1, len(network_thread._token_init_msgs))

        finally:
            NetworkThread.MAX_INDIRECT_REQUEST_TIMEOUTS_PER_TICK = old_limit

    def test_indirect_request_timeout_check_stops_at_first_fresh_request(self):
        """The timeout tick should not scan the full pending table when the oldest request is fresh."""

        class CountingDict(dict):
            items_seen = 0

            def items(self):
                for item in super().items():
                    self.items_seen += 1
                    yield item

        network_thread = self._create_network_thread()
        network_thread._token_init_msgs = CountingDict()
        network_thread._indirect_request_error = Mock()

        for token in range(100):
            init = PeerInit(target_user=f"user{token}", conn_type=ConnectionType.PEER)
            network_thread._token_init_msgs[token] = (init, 100)

        network_thread._check_indirect_request_timeouts(current_time=101)

        self.assertEqual(1, network_thread._token_init_msgs.items_seen)
        self.assertEqual(100, len(network_thread._token_init_msgs))
        network_thread._indirect_request_error.assert_not_called()

    def test_expire_all_indirect_request_timeouts_ignores_batch_limit(self):
        """Server-disconnect cleanup still releases all indirect requests immediately."""

        network_thread = self._create_network_thread()
        old_limit = NetworkThread.MAX_INDIRECT_REQUEST_TIMEOUTS_PER_TICK
        NetworkThread.MAX_INDIRECT_REQUEST_TIMEOUTS_PER_TICK = 1
        network_thread._indirect_request_error = Mock()

        try:
            for token in range(3):
                init = PeerInit(target_user=f"user{token}", conn_type=ConnectionType.PEER)
                network_thread._token_init_msgs[token] = (init, 0)

            network_thread._check_indirect_request_timeouts(current_time=0, expire_all=True)

            self.assertEqual(3, network_thread._indirect_request_error.call_count)
            self.assertFalse(network_thread._token_init_msgs)

        finally:
            NetworkThread.MAX_INDIRECT_REQUEST_TIMEOUTS_PER_TICK = old_limit

    def test_pending_peer_connection_time_is_not_refreshed_while_socket_cap_persists(self):
        """Retrying a socket-pressure queue entry should preserve its original age."""

        network_thread = self._create_network_thread()
        network_thread._num_sockets = NetworkThread.MAX_SOCKETS
        addr = ("1.2.3.4", 1234)
        init = PeerInit(target_user="peer", conn_type=ConnectionType.PEER)

        with patch.object(slskproto_module.time, "monotonic", return_value=10):
            network_thread._init_peer_connection(addr, init)

        pending_key = network_thread._get_pending_peer_conn_key(addr, init, None)
        queued_time = network_thread._pending_peer_conns[pending_key].queued_time
        self.assertEqual(10, queued_time)

        with patch.object(slskproto_module.time, "monotonic", return_value=20):
            network_thread._init_peer_connection(addr, init)

        self.assertIs(init, network_thread._pending_peer_conns[pending_key].init)
        self.assertEqual(queued_time, network_thread._pending_peer_conns[pending_key].queued_time)

    def test_stale_pending_peer_connections_are_dropped(self):
        """Pending peer connections should not be retained forever under socket pressure."""

        network_thread = self._create_network_thread()
        addr = ("1.2.3.4", 1234)
        init = PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        pending_key = network_thread._get_pending_peer_conn_key(addr, init, None)
        network_thread._pending_peer_conns[pending_key] = PendingPeerConnection(
            addr, init, queued_time=0
        )
        network_thread._drop_pending_peer_connection = Mock()

        network_thread._process_pending_peer_connections(
            current_time=NetworkThread.MAX_PENDING_PEER_CONNECTION_AGE + 1
        )

        self.assertNotIn(pending_key, network_thread._pending_peer_conns)
        network_thread._drop_pending_peer_connection.assert_called_once_with(init, response_token=None)

    def test_pending_network_message_queue_drops_noncritical_messages_after_cap(self):
        """Bound outgoing queue growth when producers outpace the network thread."""

        network_thread = object.__new__(NetworkThread)
        network_thread._should_process_queue = True
        self._set_message_queue(network_thread, [SimpleNamespace(msg_type=ServerMessage.msg_type)])
        network_thread._dropped_network_messages = 0

        old_limit = NetworkThread.MAX_PENDING_NETWORK_MESSAGES
        NetworkThread.MAX_PENDING_NETWORK_MESSAGES = 1

        try:
            fake_log = SimpleNamespace(add_conn=Mock())

            with patch.object(slskproto_module, "log", fake_log):
                self.assertFalse(network_thread._queue_network_message(
                    SimpleNamespace(msg_type=ServerMessage.msg_type)))

            self.assertEqual(1, len(network_thread._message_queue))
            self.assertEqual(1, network_thread._dropped_network_messages)
            fake_log.add_conn.assert_called_once()

        finally:
            NetworkThread.MAX_PENDING_NETWORK_MESSAGES = old_limit

    def test_pending_network_message_queue_keeps_critical_internal_messages_after_cap(self):
        """Shutdown/connectivity messages should still pass a full non-critical queue."""

        network_thread = object.__new__(NetworkThread)
        network_thread._should_process_queue = True
        self._set_message_queue(network_thread, [SimpleNamespace(msg_type=ServerMessage.msg_type)])
        network_thread._dropped_network_messages = 0

        old_limit = NetworkThread.MAX_PENDING_NETWORK_MESSAGES
        NetworkThread.MAX_PENDING_NETWORK_MESSAGES = 1

        try:
            self.assertTrue(network_thread._queue_network_message(ServerConnect()))

            self.assertEqual(2, len(network_thread._message_queue))
            self.assertEqual(0, network_thread._dropped_network_messages)

        finally:
            NetworkThread.MAX_PENDING_NETWORK_MESSAGES = old_limit

    def test_emit_network_message_events_are_batched(self):
        """Deferred replay batches should not emit every event in one network-thread turn."""

        network_thread = self._create_network_thread()
        self._set_message_queue(network_thread)
        network_msgs = [SimpleNamespace(index=index) for index in range(5)]
        original_msgs = list(network_msgs)

        old_limit = NetworkThread.MAX_EMITTED_NETWORK_MESSAGE_EVENTS_PER_BATCH
        NetworkThread.MAX_EMITTED_NETWORK_MESSAGE_EVENTS_PER_BATCH = 2

        try:
            network_thread._process_internal_message(EmitNetworkMessageEvents(network_msgs))

        finally:
            NetworkThread.MAX_EMITTED_NETWORK_MESSAGE_EVENTS_PER_BATCH = old_limit

        self.assertEqual(original_msgs[:2], [call.args[0] for call in network_thread._emit_network_message_event.call_args_list])
        self.assertEqual(1, len(network_thread._message_queue))
        queued_msg = network_thread._message_queue[0]
        self.assertIsInstance(queued_msg, EmitNetworkMessageEvents)
        self.assertIs(network_msgs, queued_msg.msgs)
        self.assertEqual(original_msgs[2:], queued_msg.msgs)

    def test_emit_network_message_events_preserves_accepted_tail_when_queue_is_full(self):
        """An already accepted deferred replay tail should not disappear under later queue pressure."""

        network_thread = self._create_network_thread()
        self._set_message_queue(network_thread)
        network_msgs = [SimpleNamespace(index=index, payload="x" * 100) for index in range(3)]
        original_msgs = list(network_msgs)

        old_batch_limit = NetworkThread.MAX_EMITTED_NETWORK_MESSAGE_EVENTS_PER_BATCH
        old_byte_limit = NetworkThread.MAX_PENDING_NETWORK_MESSAGE_BYTES
        NetworkThread.MAX_EMITTED_NETWORK_MESSAGE_EVENTS_PER_BATCH = 1
        NetworkThread.MAX_PENDING_NETWORK_MESSAGE_BYTES = 0

        try:
            network_thread._process_internal_message(EmitNetworkMessageEvents(network_msgs))

        finally:
            NetworkThread.MAX_EMITTED_NETWORK_MESSAGE_EVENTS_PER_BATCH = old_batch_limit
            NetworkThread.MAX_PENDING_NETWORK_MESSAGE_BYTES = old_byte_limit

        self.assertEqual(original_msgs[:1], [call.args[0] for call in network_thread._emit_network_message_event.call_args_list])
        self.assertEqual(1, len(network_thread._message_queue))
        queued_msg = network_thread._message_queue[0]
        self.assertIsInstance(queued_msg, EmitNetworkMessageEvents)
        self.assertEqual(original_msgs[1:], queued_msg.msgs)

    def test_emit_network_message_events_does_not_requeue_complete_batch(self):
        """Small deferred replay batches should finish without scheduling a continuation."""

        network_thread = self._create_network_thread()
        self._set_message_queue(network_thread)
        network_msgs = [SimpleNamespace(index=index) for index in range(2)]

        old_limit = NetworkThread.MAX_EMITTED_NETWORK_MESSAGE_EVENTS_PER_BATCH
        NetworkThread.MAX_EMITTED_NETWORK_MESSAGE_EVENTS_PER_BATCH = 2

        try:
            network_thread._process_internal_message(EmitNetworkMessageEvents(network_msgs))

        finally:
            NetworkThread.MAX_EMITTED_NETWORK_MESSAGE_EVENTS_PER_BATCH = old_limit

        self.assertEqual(network_msgs, [call.args[0] for call in network_thread._emit_network_message_event.call_args_list])
        self.assertFalse(network_thread._message_queue)

    def test_queue_network_message_rejects_server_message_without_connection(self):
        network_thread = self._create_network_thread()
        self._set_message_queue(network_thread)
        network_thread._server_conn = None

        self.assertFalse(network_thread._queue_network_message(SayChatroom("room", "hello")))
        self.assertEqual(0, len(network_thread._message_queue))

    def test_queue_network_message_accepts_server_message_with_connection(self):
        network_thread = self._create_network_thread()
        self._set_message_queue(network_thread)
        network_thread._server_conn = ServerConnection(sock=MockSocket())

        self.assertTrue(network_thread._queue_network_message(SayChatroom("room", "hello")))
        self.assertEqual(1, len(network_thread._message_queue))

    def test_pending_network_message_queue_has_byte_budget(self):
        """Heavy queued message objects should not bypass count/socket buffer caps."""

        class HeavyMessage:
            __slots__ = ("msg_type", "payload")

            def __init__(self):
                self.msg_type = ServerMessage.msg_type
                self.payload = "x" * 4096

        network_thread = object.__new__(NetworkThread)
        network_thread._should_process_queue = True
        self._set_message_queue(network_thread)
        network_thread._dropped_network_messages = 0
        network_thread._pending_transfer_network_messages = 0
        network_thread._dropped_transfer_network_messages = 0

        old_limit = NetworkThread.MAX_PENDING_NETWORK_MESSAGE_BYTES
        NetworkThread.MAX_PENDING_NETWORK_MESSAGE_BYTES = 1024

        try:
            fake_log = SimpleNamespace(add_conn=Mock())

            with patch.object(slskproto_module, "log", fake_log):
                network_thread._queue_network_message(HeavyMessage())

            self.assertFalse(network_thread._message_queue)
            self.assertEqual(0, network_thread._pending_network_message_bytes)
            self.assertEqual(1, network_thread._dropped_network_messages)
            fake_log.add_conn.assert_called_once()

        finally:
            NetworkThread.MAX_PENDING_NETWORK_MESSAGE_BYTES = old_limit

    def test_pending_network_message_queue_releases_byte_accounting_when_processed(self):
        """The retained-object byte cap should measure current queue contents."""

        network_thread = object.__new__(NetworkThread)
        self._set_message_queue(network_thread, [0, 1], sizes=[600, 700])
        network_thread._pending_transfer_network_messages = 0
        network_thread._dropped_network_messages = 0
        network_thread._dropped_transfer_network_messages = 0
        network_thread._process_outgoing_messages = Mock()

        old_limit = NetworkThread.MAX_QUEUED_MESSAGES_PER_CYCLE
        NetworkThread.MAX_QUEUED_MESSAGES_PER_CYCLE = 1

        try:
            network_thread._process_queue_messages()

            self.assertEqual(700, network_thread._pending_network_message_bytes)
            self.assertEqual([1], list(network_thread._message_queue))
            self.assertEqual([0], network_thread._process_outgoing_messages.call_args.args[0])

        finally:
            NetworkThread.MAX_QUEUED_MESSAGES_PER_CYCLE = old_limit

    def test_priority_network_messages_preserve_relative_order(self):
        """Priority controls should jump normal backlog without reversing each other."""

        network_thread = object.__new__(NetworkThread)
        network_thread._should_process_queue = True
        self._set_message_queue(network_thread, [SimpleNamespace(msg_type=ServerMessage.msg_type)], sizes=[100])
        network_thread._pending_transfer_network_messages = 0
        network_thread._dropped_network_messages = 0
        network_thread._dropped_transfer_network_messages = 0

        network_thread._queue_network_message(ServerConnect())
        network_thread._queue_network_message(ServerDisconnect())

        self.assertIsInstance(network_thread._message_queue[0], ServerConnect)
        self.assertIsInstance(network_thread._message_queue[1], ServerDisconnect)
        self.assertIs(network_thread._message_queue[2].msg_type, ServerMessage.msg_type)

    def test_lifecycle_control_messages_bypass_queue_byte_budget(self):
        """Tiny disconnect/connect controls should still be deliverable under memory pressure."""

        network_thread = object.__new__(NetworkThread)
        network_thread._should_process_queue = True
        self._set_message_queue(network_thread, [object()], sizes=[NetworkThread.MAX_PENDING_NETWORK_MESSAGE_BYTES])
        network_thread._dropped_network_messages = 0
        network_thread._pending_transfer_network_messages = 0
        network_thread._dropped_transfer_network_messages = 0

        network_thread._queue_network_message(ServerConnect())

        self.assertEqual(2, len(network_thread._message_queue))
        self.assertEqual(0, network_thread._dropped_network_messages)

    def test_lifecycle_control_messages_are_prioritized_ahead_of_backlog(self):
        """Accepted lifecycle controls should not wait behind a full backlog."""

        network_thread = object.__new__(NetworkThread)
        network_thread._should_process_queue = True
        self._set_message_queue(network_thread, [object(), object()], sizes=[10, 20])
        network_thread._dropped_network_messages = 0
        network_thread._pending_transfer_network_messages = 0
        network_thread._dropped_transfer_network_messages = 0

        self.assertTrue(network_thread._queue_network_message(ServerDisconnect()))

        self.assertIsInstance(network_thread._message_queue[0], ServerDisconnect)
        self.assertEqual(3, len(network_thread._message_queue))

    def test_duplicate_close_connection_messages_are_coalesced(self):
        """Closing the same socket is idempotent; one queued close is enough."""

        network_thread = object.__new__(NetworkThread)
        network_thread._should_process_queue = True
        sock = MockSocket()
        self._set_message_queue(network_thread, [CloseConnection(sock)])
        network_thread._dropped_network_messages = 0
        network_thread._pending_transfer_network_messages = 0
        network_thread._dropped_transfer_network_messages = 0

        self.assertTrue(network_thread._queue_network_message(CloseConnection(sock)))

        self.assertEqual(1, len(network_thread._message_queue))
        self.assertIs(network_thread._message_queue[0].sock, sock)

    def test_close_connection_dedupe_key_is_released_when_popped(self):
        """A later close request can be queued after the first one is processed."""

        network_thread = object.__new__(NetworkThread)
        network_thread._should_process_queue = True
        sock = MockSocket()
        self._set_message_queue(network_thread, [CloseConnection(sock)])
        network_thread._dropped_network_messages = 0
        network_thread._pending_transfer_network_messages = 0
        network_thread._dropped_transfer_network_messages = 0

        self.assertIsInstance(network_thread._pop_network_message_queue(), CloseConnection)
        self.assertTrue(network_thread._queue_network_message(CloseConnection(sock)))

        self.assertEqual(1, len(network_thread._message_queue))
        self.assertIs(network_thread._message_queue[0].sock, sock)

    def test_latest_only_limit_messages_are_coalesced(self):
        """Only the latest queued bandwidth-limit value is useful."""

        network_thread = object.__new__(NetworkThread)
        network_thread._should_process_queue = True
        self._set_message_queue(network_thread, [SetDownloadLimit(10)], sizes=[100])
        network_thread._dropped_network_messages = 0
        network_thread._pending_transfer_network_messages = 0
        network_thread._dropped_transfer_network_messages = 0

        self.assertTrue(network_thread._queue_network_message(SetDownloadLimit(20)))

        self.assertEqual(1, len(network_thread._message_queue))
        self.assertIsInstance(network_thread._message_queue[0], SetDownloadLimit)
        self.assertEqual(20, network_thread._message_queue[0].limit)

    def test_transfer_network_message_queue_has_own_cap(self):
        """File-transfer control messages must not bypass all queue budgets."""

        network_thread = object.__new__(NetworkThread)
        network_thread._should_process_queue = True
        self._set_message_queue(network_thread, [FileTransferInit(token=1)])
        network_thread._pending_transfer_network_messages = 1
        network_thread._dropped_transfer_network_messages = 0
        network_thread._dropped_network_messages = 0

        old_limit = NetworkThread.MAX_PENDING_TRANSFER_NETWORK_MESSAGES
        NetworkThread.MAX_PENDING_TRANSFER_NETWORK_MESSAGES = 1

        try:
            fake_log = SimpleNamespace(add_conn=Mock())

            with patch.object(slskproto_module, "log", fake_log):
                network_thread._queue_network_message(FileTransferInit(token=2))

            self.assertEqual(1, len(network_thread._message_queue))
            self.assertEqual(1, network_thread._dropped_transfer_network_messages)
            fake_log.add_conn.assert_called_once()

        finally:
            NetworkThread.MAX_PENDING_TRANSFER_NETWORK_MESSAGES = old_limit

    def test_internal_connect_messages_do_not_count_against_transfer_queue_cap(self):
        """Connect/disconnect control messages still pass the transfer-message cap."""

        network_thread = object.__new__(NetworkThread)
        network_thread._should_process_queue = True
        self._set_message_queue(network_thread, [FileTransferInit(token=1)])
        network_thread._pending_transfer_network_messages = 1
        network_thread._dropped_transfer_network_messages = 0
        network_thread._dropped_network_messages = 0

        old_limit = NetworkThread.MAX_PENDING_TRANSFER_NETWORK_MESSAGES
        NetworkThread.MAX_PENDING_TRANSFER_NETWORK_MESSAGES = 1

        try:
            network_thread._queue_network_message(ServerConnect())

            self.assertEqual(2, len(network_thread._message_queue))
            self.assertEqual(1, network_thread._pending_transfer_network_messages)
            self.assertEqual(0, network_thread._dropped_transfer_network_messages)

        finally:
            NetworkThread.MAX_PENDING_TRANSFER_NETWORK_MESSAGES = old_limit

    def test_transfer_network_message_count_released_when_queue_is_processed(self):
        """The transfer-message cap tracks queued messages, not historical messages."""

        network_thread = object.__new__(NetworkThread)
        self._set_message_queue(network_thread, [FileTransferInit(token=1), DownloadFile()])
        network_thread._pending_transfer_network_messages = 2
        network_thread._dropped_network_messages = 0
        network_thread._dropped_transfer_network_messages = 0
        network_thread._process_outgoing_messages = Mock()

        old_limit = NetworkThread.MAX_QUEUED_MESSAGES_PER_CYCLE
        NetworkThread.MAX_QUEUED_MESSAGES_PER_CYCLE = 1

        try:
            network_thread._process_queue_messages()

            self.assertEqual(1, network_thread._pending_transfer_network_messages)
            self.assertEqual(1, len(network_thread._message_queue))
            self.assertIsInstance(network_thread._message_queue[0], DownloadFile)

        finally:
            NetworkThread.MAX_QUEUED_MESSAGES_PER_CYCLE = old_limit

    def test_queue_message_processing_is_batched(self):
        """Huge bursts of queued outgoing messages should not monopolize a network cycle."""

        network_thread = object.__new__(NetworkThread)
        self._set_message_queue(network_thread, range(5))
        network_thread._dropped_network_messages = 0
        network_thread._process_outgoing_messages = Mock()

        old_limit = NetworkThread.MAX_QUEUED_MESSAGES_PER_CYCLE
        NetworkThread.MAX_QUEUED_MESSAGES_PER_CYCLE = 3

        try:
            network_thread._process_queue_messages()

            self.assertEqual([0, 1, 2], network_thread._process_outgoing_messages.call_args.args[0])
            self.assertEqual([3, 4], list(network_thread._message_queue))

        finally:
            NetworkThread.MAX_QUEUED_MESSAGES_PER_CYCLE = old_limit

    def test_incoming_server_messages_are_batched(self):
        """Huge bursts of complete incoming messages should not monopolize one cycle."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket())
        msg = (
            ServerMessage.pack_uint32(NetworkThread.SERVER_PEER_MESSAGE_CODE_SIZE)
            + ServerMessage.pack_uint32(0xFFFFFFFE)
        )
        conn.in_buffer = bytearray(msg * 5)

        old_limit = NetworkThread.MAX_INCOMING_MESSAGES_PER_CONNECTION_CYCLE
        NetworkThread.MAX_INCOMING_MESSAGES_PER_CONNECTION_CYCLE = 3

        try:
            fake_log = SimpleNamespace(add_debug=Mock(), add_conn=Mock())

            with patch.object(slskproto_module, "log", fake_log):
                network_thread._process_server_input(conn)

            self.assertEqual(bytearray(msg * 2), conn.in_buffer)
            network_thread._close_connection.assert_not_called()

        finally:
            NetworkThread.MAX_INCOMING_MESSAGES_PER_CONNECTION_CYCLE = old_limit

    def test_buffered_connection_messages_are_revisited(self):
        """Batched parsing leaves in-memory data that must be processed next cycle."""

        network_thread = object.__new__(NetworkThread)
        conn = PeerConnection(sock=MockSocket())
        conn.in_buffer = bytearray(b"pending")
        network_thread._conns = {conn.sock: conn}

        def process_conn_messages(processed_conn):
            processed_conn.in_buffer.clear()

        network_thread._process_conn_incoming_messages = Mock(side_effect=process_conn_messages)

        network_thread._process_buffered_conn_messages()

        network_thread._process_conn_incoming_messages.assert_called_once_with(conn)
        self.assertFalse(conn.in_buffer)

    def test_incoming_peer_connection_accepts_are_batched(self):
        """Connection floods should not monopolize one network cycle."""

        network_thread = object.__new__(NetworkThread)
        network_thread._num_sockets = 0
        network_thread._conns = {}
        network_thread._selector = Mock()
        network_thread._incoming_preinit_peer_addresses = defaultdict(int)
        network_thread._incoming_preinit_peer_address_limit_logged = False

        class AcceptedSocket:
            def setblocking(self, _blocking):
                pass

            def setsockopt(self, *_args):
                pass

        sockets = [AcceptedSocket() for _unused in range(5)]
        network_thread._listen_socket = Mock(
            accept=Mock(side_effect=[(sock, ("203.0.113.1", 5000 + index))
                                     for index, sock in enumerate(sockets)])
        )

        old_limit = NetworkThread.MAX_INCOMING_ACCEPTS_PER_CYCLE
        NetworkThread.MAX_INCOMING_ACCEPTS_PER_CYCLE = 3

        try:
            network_thread._accept_incoming_peer_connections()

            self.assertEqual(3, network_thread._listen_socket.accept.call_count)
            self.assertEqual(3, network_thread._num_sockets)
            self.assertEqual(3, len(network_thread._conns))
            self.assertEqual(3, network_thread._selector.register.call_count)

        finally:
            NetworkThread.MAX_INCOMING_ACCEPTS_PER_CYCLE = old_limit

    def test_incoming_preinit_peer_connections_are_limited_per_address(self):
        """One address should not occupy unlimited accepted sockets before PeerInit."""

        network_thread = object.__new__(NetworkThread)
        network_thread._num_sockets = 0
        network_thread._conns = {}
        network_thread._selector = Mock()
        network_thread._incoming_preinit_peer_addresses = defaultdict(int)
        network_thread._incoming_preinit_peer_address_limit_logged = False

        class AcceptedSocket:
            def __init__(self):
                self.closed = False

            def setblocking(self, _blocking):
                pass

            def setsockopt(self, *_args):
                pass

            def shutdown(self, *_args):
                pass

            def close(self):
                self.closed = True

        sockets = [AcceptedSocket() for _unused in range(4)]
        network_thread._listen_socket = Mock(
            accept=Mock(side_effect=[(sock, ("203.0.113.10", 5000 + index))
                                     for index, sock in enumerate(sockets)])
        )

        old_accept_limit = NetworkThread.MAX_INCOMING_ACCEPTS_PER_CYCLE
        old_preinit_limit = NetworkThread.MAX_INCOMING_PREINIT_CONNECTIONS_PER_ADDRESS
        NetworkThread.MAX_INCOMING_ACCEPTS_PER_CYCLE = 4
        NetworkThread.MAX_INCOMING_PREINIT_CONNECTIONS_PER_ADDRESS = 2

        try:
            network_thread._accept_incoming_peer_connections()

            self.assertEqual(4, network_thread._listen_socket.accept.call_count)
            self.assertEqual(2, network_thread._num_sockets)
            self.assertEqual(2, len(network_thread._conns))
            self.assertEqual(2, network_thread._selector.register.call_count)
            self.assertFalse(sockets[0].closed)
            self.assertFalse(sockets[1].closed)
            self.assertTrue(sockets[2].closed)
            self.assertTrue(sockets[3].closed)
            self.assertEqual(2, network_thread._incoming_preinit_peer_addresses["203.0.113.10"])

        finally:
            NetworkThread.MAX_INCOMING_ACCEPTS_PER_CYCLE = old_accept_limit
            NetworkThread.MAX_INCOMING_PREINIT_CONNECTIONS_PER_ADDRESS = old_preinit_limit

    def test_preinit_peer_address_slot_is_released_on_peer_init(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket(), addr=("203.0.113.20", 5000))

        self.assertTrue(network_thread._reserve_preinit_peer_address(conn))
        conn.in_buffer = self._pack_peer_init_message(username="remoteuser")

        network_thread._process_peer_init_input(conn)

        self.assertIsNone(conn.preinit_address_key)
        self.assertNotIn("203.0.113.20", network_thread._incoming_preinit_peer_addresses)
        network_thread._close_connection.assert_not_called()

    def test_preinit_peer_address_slot_is_released_on_close(self):
        network_thread = self._create_network_thread()
        sock = MockSocket()
        conn = PeerConnection(sock=sock, addr=("203.0.113.30", 5000))
        network_thread._selector = Mock()
        network_thread._server_conn = None
        network_thread._conns = {sock: conn}
        network_thread._num_sockets = 1

        self.assertTrue(network_thread._reserve_preinit_peer_address(conn))

        NetworkThread._close_connection(network_thread, conn)

        self.assertIsNone(conn.preinit_address_key)
        self.assertNotIn("203.0.113.30", network_thread._incoming_preinit_peer_addresses)

    def test_pending_peer_connection_retries_are_batched(self):
        """Socket pressure recovery should not retry every pending peer connection in one tick."""

        network_thread = self._create_network_thread()
        network_thread._init_peer_connection = Mock()

        for index in range(5):
            network_thread._pending_peer_conns[index] = SimpleNamespace(
                addr=("203.0.113.10", 2000 + index),
                init=PeerInit(target_user=f"user{index}", conn_type=ConnectionType.PEER),
                response_token=None
            )

        old_limit = NetworkThread.MAX_PENDING_PEER_CONNECTION_RETRIES_PER_TICK
        NetworkThread.MAX_PENDING_PEER_CONNECTION_RETRIES_PER_TICK = 2

        try:
            network_thread._process_pending_peer_connections()

            self.assertEqual(2, network_thread._init_peer_connection.call_count)

        finally:
            NetworkThread.MAX_PENDING_PEER_CONNECTION_RETRIES_PER_TICK = old_limit

    def test_successful_login_starts_port_mapping_without_blocking_network_thread(self):
        """UPnP/NAT-PMP port mapping should not block server message parsing on login."""

        network_thread = self._create_network_thread()
        network_thread._server_address = ("server.example", 2242)
        network_thread._user_addresses = {"localuser": ("192.0.2.10", 2234)}
        network_thread._portmapper = SimpleNamespace(set_port=Mock(), add_port_mapping=Mock())
        network_thread._send_have_no_parent = Mock()

        msg = Login()
        msg.success = True

        with patch.object(NetworkThread, "_unpack_network_message", return_value=msg):
            self.assertTrue(network_thread._process_server_message(
                SERVER_MESSAGE_CODES[Login], 0, memoryview(b""), 0, 0))

        network_thread._portmapper.set_port.assert_called_once_with(2234, "192.0.2.10")
        network_thread._portmapper.add_port_mapping.assert_called_once_with(blocking=False)

    def test_incoming_indirect_connection_request_is_rate_limited(self):
        """Server/MITM ConnectToPeer bursts should not create unbounded outbound sockets."""

        network_thread = self._create_network_thread()
        network_thread._connect_to_peer = Mock()
        network_thread._incoming_indirect_conn_times = deque([100.0])
        network_thread._incoming_indirect_conn_limit_logged = False

        msg = ConnectToPeer()
        msg.user = "peer"
        msg.conn_type = ConnectionType.PEER
        msg.ip_address = "203.0.113.20"
        msg.port = 2234
        msg.token = 777
        msg.privileged = False

        old_limit = NetworkThread.MAX_INCOMING_INDIRECT_CONNECTS_PER_MINUTE
        NetworkThread.MAX_INCOMING_INDIRECT_CONNECTS_PER_MINUTE = 1

        try:
            with patch.object(slskproto_module.time, "monotonic", return_value=120.0), \
                    patch.object(NetworkThread, "_unpack_network_message", return_value=msg):
                self.assertTrue(network_thread._process_server_message(
                    SERVER_MESSAGE_CODES[ConnectToPeer], 0, memoryview(b""), 0, 0))

        finally:
            NetworkThread.MAX_INCOMING_INDIRECT_CONNECTS_PER_MINUTE = old_limit

        network_thread._connect_to_peer.assert_not_called()
        network_thread._emit_network_message_event.assert_not_called()
        network_thread._send_message_to_server.assert_called_once()
        response = network_thread._send_message_to_server.call_args.args[0]
        self.assertIsInstance(response, CantConnectToPeer)
        self.assertEqual(777, response.token)
        self.assertEqual("peer", response.user)

    def test_incoming_indirect_connection_request_is_allowed_below_rate_limit(self):
        network_thread = self._create_network_thread()
        network_thread._connect_to_peer = Mock()

        msg = ConnectToPeer()
        msg.user = "peer"
        msg.conn_type = ConnectionType.PEER
        msg.ip_address = "203.0.113.20"
        msg.port = 2234
        msg.token = 778
        msg.privileged = False

        with patch.object(slskproto_module.time, "monotonic", return_value=120.0), \
                patch.object(NetworkThread, "_unpack_network_message", return_value=msg):
            self.assertTrue(network_thread._process_server_message(
                SERVER_MESSAGE_CODES[ConnectToPeer], 0, memoryview(b""), 0, 0))

        network_thread._connect_to_peer.assert_called_once()
        username, addr, init = network_thread._connect_to_peer.call_args.args[:3]
        self.assertEqual("peer", username)
        self.assertEqual(("203.0.113.20", 2234), addr)
        self.assertEqual(ConnectionType.PEER, init.conn_type)
        self.assertEqual(778, network_thread._connect_to_peer.call_args.kwargs["response_token"])
        network_thread._send_message_to_server.assert_not_called()

    def test_outgoing_non_file_message_buffer_cap_closes_connection(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )
        conn.out_buffer += b"x" * 8

        old_limit = NetworkThread.MAX_OUTGOING_MESSAGE_BUFFER_SIZE
        NetworkThread.MAX_OUTGOING_MESSAGE_BUFFER_SIZE = 16

        try:
            self.assertFalse(network_thread._append_outgoing_message(conn, b"head", b"payload", "peer message"))

        finally:
            NetworkThread.MAX_OUTGOING_MESSAGE_BUFFER_SIZE = old_limit

        network_thread._close_connection.assert_called_once_with(conn)
        self.assertEqual(b"x" * 8, conn.out_buffer)

    def test_outgoing_non_file_message_buffer_cap_allows_bounded_message(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )

        old_limit = NetworkThread.MAX_OUTGOING_MESSAGE_BUFFER_SIZE
        NetworkThread.MAX_OUTGOING_MESSAGE_BUFFER_SIZE = 16

        try:
            self.assertTrue(network_thread._append_outgoing_message(conn, b"head", b"payload", "peer message"))

        finally:
            NetworkThread.MAX_OUTGOING_MESSAGE_BUFFER_SIZE = old_limit

        network_thread._close_connection.assert_not_called()
        self.assertEqual(b"headpayload", conn.out_buffer)

    def test_outgoing_server_message_buffer_cap_closes_connection(self):
        network_thread = self._create_network_thread()
        conn = ServerConnection(sock=MockSocket())
        conn.out_buffer += b"x" * 8

        old_limit = NetworkThread.MAX_SERVER_OUTGOING_MESSAGE_BUFFER_SIZE
        NetworkThread.MAX_SERVER_OUTGOING_MESSAGE_BUFFER_SIZE = 16

        try:
            self.assertFalse(network_thread._append_server_message(conn, b"head", b"payload"))

        finally:
            NetworkThread.MAX_SERVER_OUTGOING_MESSAGE_BUFFER_SIZE = old_limit

        network_thread._close_connection.assert_called_once_with(conn)
        self.assertEqual(b"x" * 8, conn.out_buffer)

    def test_wait_port_report_retries_when_initial_send_fails(self):
        """SetWaitPort is sent inside the network thread and still needs retry semantics."""

        network_thread = self._create_network_thread()
        network_thread._send_message_to_server = Mock(side_effect=[False, True])

        self.assertFalse(network_thread._send_wait_port_report(2242))
        self.assertEqual(1, len(network_thread._wait_port_report_retries))

        network_thread._server_conn = ServerConnection(sock=MockSocket())
        network_thread._process_wait_port_report_retries()

        self.assertFalse(network_thread._wait_port_report_retries)
        self.assertEqual([2242, 2242], [call.args[0].port for call in network_thread._send_message_to_server.call_args_list])

    def test_server_login_failure_closes_bootstrap_connection(self):
        """A connection that cannot queue Login should not remain half-established."""

        network_thread = self._create_network_thread()
        conn = ServerConnection(sock=MockSocket(), addr=("server.example", 2242), login=("user", "pass"))
        network_thread._send_message_to_server = Mock(return_value=False)
        network_thread._listen_port = 2242
        network_thread._local_ip_address = "203.0.113.1"

        network_thread._establish_outgoing_server_connection(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        self.assertEqual(1, network_thread._send_message_to_server.call_count)

    def test_successful_login_retries_failed_wait_port_report(self):
        """Login success plus SetWaitPort failure should keep the listen-port report pending."""

        network_thread = self._create_network_thread()
        conn = ServerConnection(sock=MockSocket(), addr=("server.example", 2242), login=("user", "pass"))
        network_thread._listen_port = 2242
        network_thread._local_ip_address = "203.0.113.1"
        network_thread._send_message_to_server = Mock(side_effect=[True, False])

        network_thread._establish_outgoing_server_connection(conn)

        network_thread._close_connection.assert_not_called()
        self.assertEqual([2242], [msg.port for msg in network_thread._wait_port_report_retries])

    def test_outgoing_server_message_buffer_cap_allows_bounded_message(self):
        network_thread = self._create_network_thread()
        conn = ServerConnection(sock=MockSocket())

        old_limit = NetworkThread.MAX_SERVER_OUTGOING_MESSAGE_BUFFER_SIZE
        NetworkThread.MAX_SERVER_OUTGOING_MESSAGE_BUFFER_SIZE = 16

        try:
            self.assertTrue(network_thread._append_server_message(conn, b"head", b"payload"))

        finally:
            NetworkThread.MAX_SERVER_OUTGOING_MESSAGE_BUFFER_SIZE = old_limit

        network_thread._close_connection.assert_not_called()
        self.assertEqual(b"headpayload", conn.out_buffer)
        self.assertEqual(len(b"headpayload"), conn.out_buffer_tracked_size)
        self.assertEqual(len(b"headpayload"), network_thread._outgoing_buffer_bytes)

    def test_server_message_queue_rejects_without_active_server_connection(self):
        """Accepted-work callers need immediate failure when no server socket exists."""

        network_thread = self._create_network_thread()
        network_thread._server_conn = None
        fake_log = SimpleNamespace(add_conn=Mock())

        with patch.object(slskproto_module, "log", fake_log):
            self.assertFalse(network_thread._queue_network_message(SetWaitPort(1)))

        self.assertFalse(network_thread._message_queue)
        fake_log.add_conn.assert_called_once()

    def test_server_message_queue_accepts_with_active_server_connection(self):
        network_thread = self._create_network_thread()
        network_thread._server_conn = ServerConnection(sock=MockSocket())

        self.assertTrue(network_thread._queue_network_message(SetWaitPort(1)))
        self.assertEqual(1, len(network_thread._message_queue))

    def test_rejected_server_output_does_not_mutate_request_ledgers(self):
        """Local request ledgers should only update after server output is actually queued."""

        network_thread = self._create_network_thread()
        network_thread._server_conn = ServerConnection(sock=MockSocket())
        network_thread._append_server_message = Mock(return_value=False)

        network_thread._process_server_output(GetPeerAddress("peer"))

        self.assertNotIn("peer", network_thread._requested_peer_addresses)
        network_thread._modify_connection_events.assert_not_called()

    def test_queued_server_output_mutates_request_ledgers(self):
        network_thread = self._create_network_thread()
        network_thread._server_conn = ServerConnection(sock=MockSocket())
        network_thread._append_server_message = Mock(return_value=True)

        network_thread._process_server_output(GetPeerAddress("peer"))

        self.assertIn("peer", network_thread._requested_peer_addresses)
        network_thread._modify_connection_events.assert_called_once()

    def test_unsent_server_request_emits_main_thread_rollback_event(self):
        network_thread = self._create_network_thread()
        network_thread._server_conn = None
        msg = GetUserStats("peer")

        fake_events = SimpleNamespace(emit_main_thread=Mock())

        with patch("pynicotine.slskproto.events", fake_events):
            network_thread._process_outgoing_messages([msg])

        fake_events.emit_main_thread.assert_called_once_with("server-message-unsent", msg)
        self.assertFalse(network_thread._main_thread_lifecycle_event_retries)

    def test_unsent_server_request_uses_lifecycle_retry_when_main_thread_full(self):
        network_thread = self._create_network_thread()
        network_thread._server_conn = None
        msg = GetUserStats("peer")

        fake_events = SimpleNamespace(emit_main_thread=Mock(return_value=False))

        with patch("pynicotine.slskproto.events", fake_events):
            network_thread._process_outgoing_messages([msg])

        fake_events.emit_main_thread.assert_called_once_with("server-message-unsent", msg)
        self.assertEqual(1, len(network_thread._main_thread_lifecycle_event_retries))
        event_name, args, kwargs = network_thread._main_thread_lifecycle_event_retries[0]
        self.assertEqual("server-message-unsent", event_name)
        self.assertEqual((msg,), args)
        self.assertEqual({}, kwargs)

    def test_queued_server_request_without_live_connection_revokes_response_grant(self):
        network_thread = self._create_network_thread()
        network_thread._server_conn = None
        USER_INTERESTS_USERS_ALLOWED.clear()
        USER_INTERESTS_USERS_ALLOWED.add("peer")

        try:
            network_thread._process_outgoing_messages([UserInterests("peer")])

            self.assertNotIn("peer", USER_INTERESTS_USERS_ALLOWED)

        finally:
            USER_INTERESTS_USERS_ALLOWED.clear()

    def test_queued_server_request_with_closed_socket_revokes_response_grant(self):
        network_thread = self._create_network_thread()
        sock = MockSocket()
        network_thread._server_conn = ServerConnection(sock=sock)
        network_thread._conns.clear()
        SEARCH_TOKENS_ALLOWED.clear()
        SEARCH_TOKENS_ALLOWED.add(456)

        try:
            network_thread._process_outgoing_messages([FileSearch(456, "term")])

            self.assertNotIn(456, SEARCH_TOKENS_ALLOWED)

        finally:
            SEARCH_TOKENS_ALLOWED.clear()

    def test_rejected_server_output_revokes_search_response_grant(self):
        """Server search response grants must follow socket-output acceptance."""

        network_thread = self._create_network_thread()
        network_thread._server_conn = ServerConnection(sock=MockSocket())
        network_thread._append_server_message = Mock(return_value=False)
        SEARCH_TOKENS_ALLOWED.clear()
        SEARCH_TOKENS_ALLOWED.add(123)

        try:
            self.assertFalse(network_thread._process_server_output(FileSearch(123, "music")))
            self.assertNotIn(123, SEARCH_TOKENS_ALLOWED)

        finally:
            SEARCH_TOKENS_ALLOWED.clear()

    def test_rejected_server_output_revokes_user_interests_response_grant(self):
        network_thread = self._create_network_thread()
        network_thread._server_conn = ServerConnection(sock=MockSocket())
        network_thread._append_server_message = Mock(return_value=False)
        USER_INTERESTS_USERS_ALLOWED.clear()
        USER_INTERESTS_USERS_ALLOWED.add("peer")

        try:
            self.assertFalse(network_thread._process_server_output(UserInterests("peer")))
            self.assertNotIn("peer", USER_INTERESTS_USERS_ALLOWED)

        finally:
            USER_INTERESTS_USERS_ALLOWED.clear()

    def test_rejected_server_output_revokes_keyless_interest_response_grant(self):
        network_thread = self._create_network_thread()
        network_thread._server_conn = ServerConnection(sock=MockSocket())
        network_thread._append_server_message = Mock(return_value=False)
        RECOMMENDATIONS_ALLOWED.clear()
        RECOMMENDATIONS_ALLOWED.add()

        try:
            self.assertFalse(network_thread._process_server_output(Recommendations()))
            self.assertFalse(RECOMMENDATIONS_ALLOWED.is_allowed())

        finally:
            RECOMMENDATIONS_ALLOWED.clear()

    def test_process_outgoing_server_without_socket_revokes_response_grant(self):
        """A queued server request dropped at the lower no-socket boundary should revoke its grant."""

        network_thread = self._create_network_thread()
        network_thread._server_conn = None
        USER_INTERESTS_USERS_ALLOWED.clear()
        USER_INTERESTS_USERS_ALLOWED.add("peer")

        try:
            network_thread._process_outgoing_messages([UserInterests("peer")])
            self.assertNotIn("peer", USER_INTERESTS_USERS_ALLOWED)

        finally:
            USER_INTERESTS_USERS_ALLOWED.clear()

    def test_clearing_network_queue_revokes_unsent_grants(self):
        """Disconnect queue cleanup should not leave response grants for dropped requests."""

        network_thread = self._create_network_thread()
        self._set_message_queue(network_thread, [UserInterests("peer"), SharedFileListRequest()])
        network_thread._message_queue[1].username = "browsepeer"
        USER_INTERESTS_USERS_ALLOWED.clear()
        USER_INTERESTS_USERS_ALLOWED.add("peer")
        SHARED_FILE_LIST_USERS_ALLOWED.clear()
        SHARED_FILE_LIST_USERS_ALLOWED.add("browsepeer")

        try:
            network_thread._clear_network_message_queue(revoke_unsent=True)
            self.assertNotIn("peer", USER_INTERESTS_USERS_ALLOWED)
            self.assertNotIn("browsepeer", SHARED_FILE_LIST_USERS_ALLOWED)

        finally:
            USER_INTERESTS_USERS_ALLOWED.clear()
            SHARED_FILE_LIST_USERS_ALLOWED.clear()

    @staticmethod
    def _make_global_room_message_content(room="room", user="peer", message="hello"):
        msg = GlobalRoomMessage()
        return bytearray(
            msg.pack_string(room)
            + msg.pack_string(user)
            + msg.pack_string(message)
        )

    def test_unsolicited_global_room_message_is_rejected_before_parse(self):
        """Deprecated public-feed messages should require an explicit local opt-in."""

        network_thread = self._create_network_thread()
        content = self._make_global_room_message_content()
        GLOBAL_ROOM_FEED_ALLOWED.clear()

        try:
            with patch.object(GlobalRoomMessage, "parse_network_message", side_effect=AssertionError):
                self.assertTrue(network_thread._process_server_message(
                    SERVER_MESSAGE_CODES[GlobalRoomMessage], len(content) + 4, content, 0, len(content)))

            network_thread._emit_network_message_event.assert_not_called()

        finally:
            GLOBAL_ROOM_FEED_ALLOWED.clear()

    def test_global_room_message_parses_after_join_feed_output_is_queued(self):
        network_thread = self._create_network_thread()
        content = self._make_global_room_message_content(message="allowed")
        GLOBAL_ROOM_FEED_ALLOWED.clear()
        network_thread._server_conn = ServerConnection(sock=MockSocket())
        network_thread._append_server_message = Mock(return_value=True)

        try:
            network_thread._process_server_output(JoinGlobalRoom())
            self.assertTrue(GLOBAL_ROOM_FEED_ALLOWED.is_allowed())
            self.assertTrue(network_thread._process_server_message(
                SERVER_MESSAGE_CODES[GlobalRoomMessage], len(content) + 4, content, 0, len(content)))

            msg = network_thread._emit_network_message_event.call_args.args[0]
            self.assertIsInstance(msg, GlobalRoomMessage)
            self.assertEqual("allowed", msg.message)

        finally:
            GLOBAL_ROOM_FEED_ALLOWED.clear()

    def test_rejected_global_room_join_does_not_open_feed_gate(self):
        network_thread = self._create_network_thread()
        GLOBAL_ROOM_FEED_ALLOWED.clear()
        network_thread._server_conn = ServerConnection(sock=MockSocket())
        network_thread._append_server_message = Mock(return_value=False)

        try:
            network_thread._process_server_output(JoinGlobalRoom())
            self.assertFalse(GLOBAL_ROOM_FEED_ALLOWED.is_allowed())
            network_thread._modify_connection_events.assert_not_called()

        finally:
            GLOBAL_ROOM_FEED_ALLOWED.clear()

    def test_leave_global_room_output_closes_feed_gate(self):
        network_thread = self._create_network_thread()
        GLOBAL_ROOM_FEED_ALLOWED.allow()
        network_thread._server_conn = ServerConnection(sock=MockSocket())
        network_thread._append_server_message = Mock(return_value=True)

        try:
            network_thread._process_server_output(LeaveGlobalRoom())
            self.assertFalse(GLOBAL_ROOM_FEED_ALLOWED.is_allowed())

        finally:
            GLOBAL_ROOM_FEED_ALLOWED.clear()

    def test_server_disconnect_closes_global_room_feed_gate(self):
        network_thread = self._create_network_thread()
        network_thread._listen_socket = None
        network_thread._portmapper = None
        network_thread._parent_conn = None
        network_thread._potential_parents = {}
        network_thread._branch_level = 0
        network_thread._branch_root = None
        network_thread._is_server_parent = False
        network_thread._distrib_parent_min_speed = 0
        network_thread._distrib_parent_speed_ratio = 1
        network_thread._max_distrib_children = 0
        network_thread._upload_speed = 0
        network_thread._server_address = None
        network_thread._server_relogged = False
        network_thread._manual_server_disconnect = False
        network_thread._manual_server_reconnect = False
        network_thread._check_indirect_request_timeouts = Mock()
        network_thread._clear_network_message_queue = Mock()
        GLOBAL_ROOM_FEED_ALLOWED.allow()

        try:
            network_thread._server_disconnect()
            self.assertFalse(GLOBAL_ROOM_FEED_ALLOWED.is_allowed())

        finally:
            GLOBAL_ROOM_FEED_ALLOWED.clear()

    def test_outgoing_buffer_budget_rejects_excess_non_file_data(self):
        """Many stalled peers must not grow aggregate non-file output buffers without a global cap."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )
        network_thread._outgoing_buffer_bytes = 8

        old_limit = NetworkThread.MAX_OUTGOING_BUFFER_BYTES
        NetworkThread.MAX_OUTGOING_BUFFER_BYTES = 10

        try:
            fake_log = SimpleNamespace(add_conn=Mock())

            with patch.object(slskproto_module, "log", fake_log):
                self.assertFalse(network_thread._append_outgoing_message(conn, b"h", b"xx", "peer message"))

        finally:
            NetworkThread.MAX_OUTGOING_BUFFER_BYTES = old_limit

        self.assertFalse(conn.out_buffer)
        self.assertEqual(0, conn.out_buffer_tracked_size)
        self.assertEqual(8, network_thread._outgoing_buffer_bytes)
        network_thread._close_connection.assert_called_once_with(conn)
        fake_log.add_conn.assert_called_once()

    def test_outgoing_buffer_budget_tracks_send_and_close_release(self):
        """Sent bytes and closed sockets should release aggregate non-file output budget."""

        network_thread = self._create_network_thread()
        sock = MockSocket()
        sock.send = Mock(return_value=3)
        conn = PeerConnection(
            sock=sock,
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )
        conn.out_buffer = bytearray(b"abcdef")
        conn.out_buffer_tracked_size = 6
        network_thread._outgoing_buffer_bytes = 6

        self.assertTrue(network_thread._write_data(conn, current_time=123))

        self.assertEqual(bytearray(b"def"), conn.out_buffer)
        self.assertEqual(3, conn.out_buffer_tracked_size)
        self.assertEqual(3, network_thread._outgoing_buffer_bytes)

        network_thread._clear_outgoing_buffer(conn)

        self.assertEqual(0, conn.out_buffer_tracked_size)
        self.assertEqual(0, network_thread._outgoing_buffer_bytes)

    def test_outgoing_server_message_without_connection_is_dropped(self):
        """Queued server messages must not crash the network thread after disconnect."""

        network_thread = self._create_network_thread()
        network_thread._server_conn = None
        network_thread._should_process_queue = True
        msg = SimpleNamespace(msg_type=ServerMessage.msg_type)
        fake_log = SimpleNamespace(add_conn=Mock(), add_msg_contents=Mock())

        with patch.object(slskproto_module, "log", fake_log):
            network_thread._process_outgoing_messages([msg])

        fake_log.add_conn.assert_called_once()
        fake_log.add_msg_contents.assert_not_called()

    def test_incoming_buffer_budget_allows_bounded_non_file_data(self):
        """Non-file recv data should reserve aggregate buffer budget."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )

        old_limit = NetworkThread.MAX_INCOMING_BUFFER_BYTES
        NetworkThread.MAX_INCOMING_BUFFER_BYTES = 10

        try:
            self.assertTrue(network_thread._append_incoming_data(conn, b"payload", 7))

        finally:
            NetworkThread.MAX_INCOMING_BUFFER_BYTES = old_limit

        self.assertEqual(bytearray(b"payload"), conn.in_buffer)
        self.assertEqual(7, network_thread._incoming_buffer_bytes)
        network_thread._close_connection.assert_not_called()

    def test_incoming_buffer_budget_rejects_excess_non_file_data(self):
        """Many partial non-file messages must not grow raw input buffers without a global cap."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )
        network_thread._incoming_buffer_bytes = 8

        old_limit = NetworkThread.MAX_INCOMING_BUFFER_BYTES
        NetworkThread.MAX_INCOMING_BUFFER_BYTES = 10

        try:
            fake_log = SimpleNamespace(add_conn=Mock())

            with patch.object(slskproto_module, "log", fake_log):
                self.assertFalse(network_thread._append_incoming_data(conn, b"abc", 3))

        finally:
            NetworkThread.MAX_INCOMING_BUFFER_BYTES = old_limit

        self.assertFalse(conn.in_buffer)
        self.assertEqual(8, network_thread._incoming_buffer_bytes)
        network_thread._close_connection.assert_called_once_with(conn)
        fake_log.add_conn.assert_called_once()

    def test_incoming_buffer_budget_tracks_parser_discard_and_close(self):
        """Parsed bytes and closed sockets should release aggregate input-buffer budget."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )
        conn.in_buffer = bytearray(b"abcdefgh")
        network_thread._incoming_buffer_bytes = len(conn.in_buffer)

        network_thread._discard_incoming_data(conn, 3)

        self.assertEqual(bytearray(b"defgh"), conn.in_buffer)
        self.assertEqual(5, network_thread._incoming_buffer_bytes)

        network_thread._clear_incoming_buffer(conn)

        self.assertFalse(conn.in_buffer)
        self.assertEqual(0, network_thread._incoming_buffer_bytes)

    def test_read_data_uses_incoming_buffer_budget(self):
        """Socket reads should not append beyond the aggregate non-file input-buffer budget."""

        network_thread = self._create_network_thread()
        sock = MockSocket()
        sock.recv = Mock(return_value=b"abc")
        conn = PeerConnection(
            sock=sock,
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )
        conn.recv_size = 1024
        network_thread._incoming_buffer_bytes = 8

        old_limit = NetworkThread.MAX_INCOMING_BUFFER_BYTES
        NetworkThread.MAX_INCOMING_BUFFER_BYTES = 10

        try:
            fake_log = SimpleNamespace(add_conn=Mock())

            with patch.object(slskproto_module, "log", fake_log):
                self.assertFalse(network_thread._read_data(conn, current_time=123))

        finally:
            NetworkThread.MAX_INCOMING_BUFFER_BYTES = old_limit

        self.assertFalse(conn.in_buffer)
        self.assertEqual(8, network_thread._incoming_buffer_bytes)
        network_thread._close_connection.assert_called_once_with(conn)

    def test_ready_input_socket_does_not_close_connection_twice(self):
        """Budget helpers may already close a connection before _read_data returns False."""

        network_thread = self._create_network_thread()
        sock = MockSocket()
        conn = PeerConnection(sock=sock, init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER))
        network_thread._conns[sock] = conn

        def read_and_close(_conn, _current_time):
            conn.sock = None
            return False

        network_thread._read_data = Mock(side_effect=read_and_close)
        network_thread._process_ready_input_socket(sock, current_time=123)

        network_thread._close_connection.assert_not_called()

    def test_close_connection_is_idempotent(self):
        """A connection closed by a budget helper can be closed again by its caller safely."""

        network_thread = object.__new__(NetworkThread)
        network_thread._selector = Mock()
        network_thread._conns = {}
        network_thread._num_sockets = 1
        network_thread._server_conn = None
        network_thread._file_init_msgs = {}
        network_thread._file_download_msgs = {}
        network_thread._file_upload_msgs = {}
        network_thread._total_downloads = 0
        network_thread._total_uploads = 0
        network_thread._total_download_bandwidth = 0
        network_thread._total_upload_bandwidth = 0
        network_thread._total_downloads = 0
        network_thread._total_uploads = 0
        network_thread._should_process_queue = True
        network_thread._calc_download_limit = Mock()
        network_thread._calc_upload_limit_function = Mock()
        network_thread._incoming_buffer_bytes = 4
        network_thread._large_peer_message_buffer_bytes = 0
        network_thread._large_peer_message_buffer_count = 0
        network_thread._large_peer_message_buffer_limit_logged = False
        network_thread._child_peers = {}
        network_thread._parent_conn = None
        network_thread._username_init_msgs = {}
        network_thread._token_init_msgs = {}

        sock = MockSocket()
        sock.shutdown = Mock()
        sock.close = Mock()
        conn = PeerConnection(
            sock=sock,
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )
        conn.in_buffer = bytearray(b"data")
        network_thread._conns[sock] = conn

        network_thread._close_connection(conn)
        network_thread._close_connection(conn)

        self.assertIsNone(conn.sock)
        self.assertEqual(0, network_thread._num_sockets)
        self.assertEqual(0, network_thread._incoming_buffer_bytes)
        self.assertFalse(conn.in_buffer)

    def test_ready_socket_processing_is_batched(self):
        network_thread = self._create_network_thread()
        network_thread._listen_socket = MockSocket()
        network_thread._process_ready_input_socket = Mock()
        network_thread._process_ready_output_socket = Mock()

        sockets = [MockSocket() for _unused in range(5)]
        ready_sockets = [
            (SimpleNamespace(fileobj=sock), selectors.EVENT_READ)
            for sock in sockets
        ]
        network_thread._selector = SimpleNamespace(select=Mock(return_value=ready_sockets))

        old_limit = NetworkThread.MAX_READY_SOCKETS_PER_CYCLE
        NetworkThread.MAX_READY_SOCKETS_PER_CYCLE = 3

        try:
            network_thread._process_ready_sockets(current_time=123)

        finally:
            NetworkThread.MAX_READY_SOCKETS_PER_CYCLE = old_limit

        self.assertEqual(3, network_thread._process_ready_input_socket.call_count)
        self.assertEqual(sockets[:3], [
            call.args[0] for call in network_thread._process_ready_input_socket.call_args_list
        ])
        network_thread._process_ready_output_socket.assert_not_called()

    def test_large_incoming_peer_message_budget_rejects_excess_connections(self):
        network_thread = self._create_network_thread()
        conn1 = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="peer1", conn_type=ConnectionType.PEER)
        )
        conn2 = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="peer2", conn_type=ConnectionType.PEER)
        )

        msg_size = 48
        header = bytearray(
            SharedFileListResponse.pack_uint32(msg_size)
            + SharedFileListResponse.pack_uint32(PEER_MESSAGE_CODES[SharedFileListResponse])
        )

        old_threshold = NetworkThread.LARGE_INCOMING_MESSAGE_THRESHOLD
        old_bytes = NetworkThread.MAX_LARGE_INCOMING_PEER_MESSAGE_BYTES
        old_messages = NetworkThread.MAX_LARGE_INCOMING_PEER_MESSAGES
        NetworkThread.LARGE_INCOMING_MESSAGE_THRESHOLD = 16
        NetworkThread.MAX_LARGE_INCOMING_PEER_MESSAGE_BYTES = 80
        NetworkThread.MAX_LARGE_INCOMING_PEER_MESSAGES = 1
        SHARED_FILE_LIST_USERS_ALLOWED.clear()
        SHARED_FILE_LIST_USERS_ALLOWED.update({"peer1", "peer2"})

        try:
            fake_events = SimpleNamespace(emit_main_thread=Mock())
            fake_log = SimpleNamespace(add_conn=Mock(), add_debug=Mock())

            with patch.object(slskproto_module, "events", fake_events), \
                    patch.object(slskproto_module, "log", fake_log):
                conn1.in_buffer = header[:]
                network_thread._process_peer_input(conn1)

                conn2.in_buffer = header[:]
                network_thread._process_peer_input(conn2)

            self.assertEqual(msg_size + 4, conn1.large_message_size_total)
            self.assertEqual(msg_size + 4, network_thread._large_peer_message_buffer_bytes)
            self.assertEqual(1, network_thread._large_peer_message_buffer_count)
            network_thread._close_connection.assert_called_once_with(conn2)
            fake_log.add_conn.assert_called_once()

        finally:
            NetworkThread.LARGE_INCOMING_MESSAGE_THRESHOLD = old_threshold
            NetworkThread.MAX_LARGE_INCOMING_PEER_MESSAGE_BYTES = old_bytes
            NetworkThread.MAX_LARGE_INCOMING_PEER_MESSAGES = old_messages
            SHARED_FILE_LIST_USERS_ALLOWED.clear()

    def test_large_incoming_peer_message_budget_released_on_close(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )

        old_threshold = NetworkThread.LARGE_INCOMING_MESSAGE_THRESHOLD
        NetworkThread.LARGE_INCOMING_MESSAGE_THRESHOLD = 16

        try:
            self.assertTrue(network_thread._register_large_message_buffer(conn, 64))
            self.assertEqual(64, network_thread._large_peer_message_buffer_bytes)
            self.assertEqual(1, network_thread._large_peer_message_buffer_count)

            network_thread._unregister_large_message_buffer(conn)
            self.assertEqual(0, conn.large_message_size_total)
            self.assertEqual(0, network_thread._large_peer_message_buffer_bytes)
            self.assertEqual(0, network_thread._large_peer_message_buffer_count)

        finally:
            NetworkThread.LARGE_INCOMING_MESSAGE_THRESHOLD = old_threshold


    @staticmethod
    def _pack_peer_message(msg_class, payload):
        return bytearray(
            msg_class.pack_uint32(len(payload) + NetworkThread.SERVER_PEER_MESSAGE_CODE_SIZE)
            + msg_class.pack_uint32(PEER_MESSAGE_CODES[msg_class])
            + payload
        )

    @staticmethod
    def _pack_ip_address(ip_address):
        return socket.inet_aton(ip_address)[::-1]

    @staticmethod
    def _pack_get_peer_address_payload(username, ip_address, port):
        return bytearray(
            GetPeerAddress.pack_string(username)
            + NetworkThreadUnitTest._pack_ip_address(ip_address)
            + GetPeerAddress.pack_uint32(port)
            + GetPeerAddress.pack_uint32(0)
            + b"\0\0"
        )

    @staticmethod
    def _pack_connect_to_peer_payload(username, conn_type, ip_address, port, token=1234):
        return bytearray(
            ConnectToPeer.pack_string(username)
            + ConnectToPeer.pack_string(conn_type)
            + NetworkThreadUnitTest._pack_ip_address(ip_address)
            + ConnectToPeer.pack_uint32(port)
            + ConnectToPeer.pack_uint32(token)
            + ConnectToPeer.pack_bool(False)
            + ConnectToPeer.pack_uint32(0)
            + ConnectToPeer.pack_uint32(0)
        )

    def test_peer_address_validator_rejects_non_remote_destinations(self):
        self.assertTrue(NetworkThread._is_valid_peer_address(("8.8.8.8", 2234)))
        self.assertTrue(NetworkThread._is_valid_peer_address(("0.0.0.0", 0), allow_offline=True))
        self.assertFalse(NetworkThread._is_valid_peer_address(("127.0.0.1", 2234)))
        self.assertFalse(NetworkThread._is_valid_peer_address(("224.0.0.1", 2234)))
        self.assertFalse(NetworkThread._is_valid_peer_address(("169.254.1.1", 2234)))
        self.assertFalse(NetworkThread._is_valid_peer_address(("8.8.8.8", 70000)))

    def test_get_peer_address_invalid_address_rejects_pending_inits_before_event(self):
        network_thread = self._create_network_thread()
        init = PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        network_thread._pending_init_msgs["peer"].append(init)
        network_thread._requested_peer_addresses.add("peer")
        network_thread._emit_peer_connection_error = Mock()
        network_thread._clear_queued_peer_messages = Mock()
        network_thread._remove_init_message = Mock()
        payload = self._pack_get_peer_address_payload("peer", "127.0.0.1", 2234)

        self.assertTrue(network_thread._process_server_message(
            SERVER_MESSAGE_CODES[GetPeerAddress], len(payload) + 4, payload, 0, len(payload)))

        network_thread._emit_peer_connection_error.assert_called_once_with(
            "peer", ConnectionType.PEER, init)
        network_thread._clear_queued_peer_messages.assert_called_once_with(init, revoke_unsent=True)
        network_thread._remove_init_message.assert_called_once_with(init)
        network_thread._emit_network_message_event.assert_called_once()
        emitted_msg = network_thread._emit_network_message_event.call_args.args[0]
        self.assertIsInstance(emitted_msg, GetPeerAddress)
        self.assertEqual("peer", emitted_msg.user)

    def test_connect_to_peer_invalid_address_gets_cant_connect_without_dialing(self):
        network_thread = self._create_network_thread()
        network_thread._connect_to_peer = Mock()
        payload = self._pack_connect_to_peer_payload("peer", ConnectionType.PEER, "127.0.0.1", 2234, token=55)

        self.assertTrue(network_thread._process_server_message(
            SERVER_MESSAGE_CODES[ConnectToPeer], len(payload) + 4, payload, 0, len(payload)))

        network_thread._connect_to_peer.assert_not_called()
        network_thread._send_message_to_server.assert_called_once()
        cant_connect_msg = network_thread._send_message_to_server.call_args.args[0]
        self.assertIsInstance(cant_connect_msg, CantConnectToPeer)
        self.assertEqual(55, cant_connect_msg.token)
        self.assertEqual("peer", cant_connect_msg.user)
        network_thread._emit_network_message_event.assert_not_called()

    def test_possible_parents_filters_invalid_peer_addresses(self):
        network_thread = self._create_network_thread()
        network_thread._parent_conn = None
        network_thread._potential_parents = {}
        network_thread._initiate_connection_to_peer = Mock()
        payload = bytearray(PossibleParents.pack_uint32(2))
        payload += PossibleParents.pack_string("badparent")
        payload += self._pack_ip_address("127.0.0.1")
        payload += PossibleParents.pack_uint32(2234)
        payload += PossibleParents.pack_string("goodparent")
        payload += self._pack_ip_address("8.8.8.8")
        payload += PossibleParents.pack_uint32(2234)

        self.assertTrue(network_thread._process_server_message(
            SERVER_MESSAGE_CODES[PossibleParents], len(payload) + 4, payload, 0, len(payload)))

        self.assertEqual({"goodparent": ("8.8.8.8", 2234)}, network_thread._potential_parents)
        network_thread._initiate_connection_to_peer.assert_called_once_with(
            "goodparent", ConnectionType.DISTRIBUTED, in_address=("8.8.8.8", 2234))

    def test_unsolicited_user_interests_response_is_rejected_before_parse(self):
        """Interest lists should be request-gated before list parsing/UI fanout."""

        network_thread = self._create_network_thread()
        payload = UserInterests.pack_string("peer") + UserInterests.pack_uint32(0) + UserInterests.pack_uint32(0)
        USER_INTERESTS_USERS_ALLOWED.clear()

        try:
            with patch.object(UserInterests, "parse_network_message", side_effect=AssertionError):
                self.assertTrue(network_thread._process_server_message(
                    SERVER_MESSAGE_CODES[UserInterests], len(payload) + 4, payload, 0, len(payload)))

            network_thread._emit_network_message_event.assert_not_called()

        finally:
            USER_INTERESTS_USERS_ALLOWED.clear()

    def test_allowed_user_interests_response_consumes_grant_before_parse(self):
        network_thread = self._create_network_thread()
        payload = UserInterests.pack_string("peer") + UserInterests.pack_uint32(0) + UserInterests.pack_uint32(0)
        USER_INTERESTS_USERS_ALLOWED.clear()
        USER_INTERESTS_USERS_ALLOWED.add("peer")

        try:
            self.assertTrue(network_thread._process_server_message(
                SERVER_MESSAGE_CODES[UserInterests], len(payload) + 4, payload, 0, len(payload)))

            self.assertNotIn("peer", USER_INTERESTS_USERS_ALLOWED)
            network_thread._emit_network_message_event.assert_called_once()
            self.assertIsInstance(network_thread._emit_network_message_event.call_args.args[0], UserInterests)

        finally:
            USER_INTERESTS_USERS_ALLOWED.clear()

    def test_malformed_allowed_user_interests_response_consumes_grant(self):
        """A malformed granted interest response should not leave a reusable grant."""

        network_thread = self._create_network_thread()
        payload = UserInterests.pack_string("peer") + UserInterests.pack_uint32(1)
        USER_INTERESTS_USERS_ALLOWED.clear()
        USER_INTERESTS_USERS_ALLOWED.add("peer")

        try:
            self.assertTrue(network_thread._process_server_message(
                SERVER_MESSAGE_CODES[UserInterests], len(payload) + 4, payload, 0, len(payload)))

            self.assertNotIn("peer", USER_INTERESTS_USERS_ALLOWED)
            network_thread._emit_network_message_event.assert_not_called()

        finally:
            USER_INTERESTS_USERS_ALLOWED.clear()

    def test_unsent_server_user_interests_request_revokes_response_grant(self):
        network_thread = self._create_network_thread()
        msg = UserInterests("peer")
        USER_INTERESTS_USERS_ALLOWED.clear()
        USER_INTERESTS_USERS_ALLOWED.add("peer")

        try:
            with patch.object(NetworkThread, "_pack_network_message", return_value=None):
                self.assertFalse(network_thread._process_server_output(msg))

            self.assertNotIn("peer", USER_INTERESTS_USERS_ALLOWED)

        finally:
            USER_INTERESTS_USERS_ALLOWED.clear()

    def test_unsent_server_search_request_revokes_response_token(self):
        network_thread = self._create_network_thread()
        msg = FileSearch(123, "term")
        SEARCH_TOKENS_ALLOWED.clear()
        SEARCH_TOKENS_ALLOWED.add(123)

        try:
            with patch.object(NetworkThread, "_pack_network_message", return_value=None):
                self.assertFalse(network_thread._process_server_output(msg))

            self.assertNotIn(123, SEARCH_TOKENS_ALLOWED)

        finally:
            SEARCH_TOKENS_ALLOWED.clear()

    def test_rejected_server_output_buffer_revokes_response_grant(self):
        network_thread = self._create_network_thread()
        network_thread._server_conn = ServerConnection(sock=MockSocket())
        msg = UserInterests("peer")
        USER_INTERESTS_USERS_ALLOWED.clear()
        USER_INTERESTS_USERS_ALLOWED.add("peer")

        old_limit = NetworkThread.MAX_SERVER_OUTGOING_MESSAGE_BUFFER_SIZE
        NetworkThread.MAX_SERVER_OUTGOING_MESSAGE_BUFFER_SIZE = 1

        try:
            self.assertFalse(network_thread._process_server_output(msg))
            self.assertNotIn("peer", USER_INTERESTS_USERS_ALLOWED)
            network_thread._close_connection.assert_called_once_with(network_thread._server_conn)

        finally:
            NetworkThread.MAX_SERVER_OUTGOING_MESSAGE_BUFFER_SIZE = old_limit
            USER_INTERESTS_USERS_ALLOWED.clear()

    def test_unsent_targeted_search_releases_only_one_response_grant(self):
        token = 321
        SEARCH_TOKENS_ALLOWED.clear()
        SEARCH_TOKENS_ALLOWED.add(token)
        SEARCH_TOKENS_ALLOWED.add(token)

        try:
            NetworkThread._revoke_unsent_server_request_grant(UserSearch("peer", token, "term"))

            self.assertIn(token, SEARCH_TOKENS_ALLOWED)

            NetworkThread._revoke_unsent_server_request_grant(UserSearch("peer2", token, "term"))

            self.assertNotIn(token, SEARCH_TOKENS_ALLOWED)

        finally:
            SEARCH_TOKENS_ALLOWED.clear()

    def test_unsent_server_request_revocation_covers_all_search_request_types(self):
        for msg in (
                UserSearch("peer", 1, "term"),
                RoomSearch("room", 2, "term"),
                WishlistSearch(3, "term")):
            SEARCH_TOKENS_ALLOWED.clear()
            SEARCH_TOKENS_ALLOWED.add(msg.token)
            NetworkThread._revoke_unsent_server_request_grant(msg)
            self.assertNotIn(msg.token, SEARCH_TOKENS_ALLOWED)

    def test_unsolicited_item_recommendations_response_is_rejected_before_parse(self):
        network_thread = self._create_network_thread()
        payload = ItemRecommendations.pack_string("ambient") + ItemRecommendations.pack_uint32(0)
        ITEM_RECOMMENDATIONS_ALLOWED.clear()

        try:
            with patch.object(ItemRecommendations, "parse_network_message", side_effect=AssertionError):
                self.assertTrue(network_thread._process_server_message(
                    SERVER_MESSAGE_CODES[ItemRecommendations], len(payload) + 4, payload, 0, len(payload)))

            network_thread._emit_network_message_event.assert_not_called()

        finally:
            ITEM_RECOMMENDATIONS_ALLOWED.clear()

    def test_allowed_item_recommendations_response_consumes_grant_before_parse(self):
        network_thread = self._create_network_thread()
        payload = ItemRecommendations.pack_string("ambient") + ItemRecommendations.pack_uint32(0)
        ITEM_RECOMMENDATIONS_ALLOWED.clear()
        ITEM_RECOMMENDATIONS_ALLOWED.add("ambient")

        try:
            self.assertTrue(network_thread._process_server_message(
                SERVER_MESSAGE_CODES[ItemRecommendations], len(payload) + 4, payload, 0, len(payload)))

            self.assertNotIn("ambient", ITEM_RECOMMENDATIONS_ALLOWED)
            network_thread._emit_network_message_event.assert_called_once()
            self.assertIsInstance(network_thread._emit_network_message_event.call_args.args[0], ItemRecommendations)

        finally:
            ITEM_RECOMMENDATIONS_ALLOWED.clear()

    def test_unsolicited_item_similar_users_response_is_rejected_before_parse(self):
        network_thread = self._create_network_thread()
        payload = ItemSimilarUsers.pack_string("ambient") + ItemSimilarUsers.pack_uint32(0)
        ITEM_SIMILAR_USERS_ALLOWED.clear()

        try:
            with patch.object(ItemSimilarUsers, "parse_network_message", side_effect=AssertionError):
                self.assertTrue(network_thread._process_server_message(
                    SERVER_MESSAGE_CODES[ItemSimilarUsers], len(payload) + 4, payload, 0, len(payload)))

            network_thread._emit_network_message_event.assert_not_called()

        finally:
            ITEM_SIMILAR_USERS_ALLOWED.clear()

    def test_keyless_recommendation_response_grants_are_checked_before_parse(self):
        network_thread = self._create_network_thread()
        payload = Recommendations.pack_uint32(0)
        RECOMMENDATIONS_ALLOWED.clear()

        try:
            with patch.object(Recommendations, "parse_network_message", side_effect=AssertionError):
                self.assertTrue(network_thread._process_server_message(
                    SERVER_MESSAGE_CODES[Recommendations], len(payload) + 4, payload, 0, len(payload)))

            network_thread._emit_network_message_event.assert_not_called()

            RECOMMENDATIONS_ALLOWED.add()
            self.assertTrue(network_thread._process_server_message(
                SERVER_MESSAGE_CODES[Recommendations], len(payload) + 4, payload, 0, len(payload)))

            self.assertFalse(RECOMMENDATIONS_ALLOWED.is_allowed())
            network_thread._emit_network_message_event.assert_called_once()
            self.assertIsInstance(network_thread._emit_network_message_event.call_args.args[0], Recommendations)

        finally:
            RECOMMENDATIONS_ALLOWED.clear()

    def test_malformed_keyless_recommendations_response_consumes_grant(self):
        network_thread = self._create_network_thread()
        payload = Recommendations.pack_uint32(1)
        RECOMMENDATIONS_ALLOWED.clear()
        RECOMMENDATIONS_ALLOWED.add()

        try:
            self.assertTrue(network_thread._process_server_message(
                SERVER_MESSAGE_CODES[Recommendations], len(payload) + 4, payload, 0, len(payload)))

            self.assertFalse(RECOMMENDATIONS_ALLOWED.is_allowed())
            network_thread._emit_network_message_event.assert_not_called()

        finally:
            RECOMMENDATIONS_ALLOWED.clear()

    def test_global_recommendations_and_similar_users_grants_are_checked_before_parse(self):
        network_thread = self._create_network_thread()
        GLOBAL_RECOMMENDATIONS_ALLOWED.clear()
        SIMILAR_USERS_ALLOWED.clear()
        global_payload = GlobalRecommendations.pack_uint32(0)
        similar_payload = SimilarUsers.pack_uint32(0)

        try:
            GLOBAL_RECOMMENDATIONS_ALLOWED.add()
            SIMILAR_USERS_ALLOWED.add()

            self.assertTrue(network_thread._process_server_message(
                SERVER_MESSAGE_CODES[GlobalRecommendations], len(global_payload) + 4,
                global_payload, 0, len(global_payload)))
            self.assertTrue(network_thread._process_server_message(
                SERVER_MESSAGE_CODES[SimilarUsers], len(similar_payload) + 4,
                similar_payload, 0, len(similar_payload)))

            self.assertFalse(GLOBAL_RECOMMENDATIONS_ALLOWED.is_allowed())
            self.assertFalse(SIMILAR_USERS_ALLOWED.is_allowed())
            self.assertEqual(2, network_thread._emit_network_message_event.call_count)

        finally:
            GLOBAL_RECOMMENDATIONS_ALLOWED.clear()
            SIMILAR_USERS_ALLOWED.clear()

    def test_unsolicited_shared_file_list_response_is_rejected_before_parse(self):
        """Huge browse responses should be request-gated before decompression/parsing."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )
        conn.in_buffer = self._pack_peer_message(SharedFileListResponse, b"not a compressed share list")
        SHARED_FILE_LIST_USERS_ALLOWED.clear()

        try:
            with patch.object(SharedFileListResponse, "parse_network_message", side_effect=AssertionError):
                network_thread._process_peer_input(conn)

            network_thread._close_connection.assert_called_once_with(conn)
            network_thread._emit_network_message_event.assert_not_called()

        finally:
            SHARED_FILE_LIST_USERS_ALLOWED.clear()

    def test_allowed_shared_file_list_response_consumes_grant(self):
        """A shared-file-list grant should allow one response and then be removed."""

        import zlib

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )
        payload = zlib.compress(SharedFileListResponse.pack_uint32(0))
        conn.in_buffer = self._pack_peer_message(SharedFileListResponse, payload)
        SHARED_FILE_LIST_USERS_ALLOWED.clear()
        SHARED_FILE_LIST_USERS_ALLOWED.add("peer")

        try:
            network_thread._process_peer_input(conn)

            self.assertNotIn("peer", SHARED_FILE_LIST_USERS_ALLOWED)
            network_thread._close_connection.assert_not_called()
            network_thread._emit_network_message_event.assert_called_once()
            self.assertIsInstance(
                network_thread._emit_network_message_event.call_args.args[0], SharedFileListResponse
            )

        finally:
            SHARED_FILE_LIST_USERS_ALLOWED.clear()

    def test_malformed_allowed_shared_file_list_response_consumes_grant(self):
        """Malformed heavyweight responses should not leave a reusable one-shot grant."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )
        conn.in_buffer = self._pack_peer_message(SharedFileListResponse, b"not zlib")
        SHARED_FILE_LIST_USERS_ALLOWED.clear()
        SHARED_FILE_LIST_USERS_ALLOWED.add("peer")

        try:
            network_thread._process_peer_input(conn)

            self.assertNotIn("peer", SHARED_FILE_LIST_USERS_ALLOWED)
            network_thread._close_connection.assert_not_called()
            network_thread._emit_network_message_event.assert_called_once_with(None)

        finally:
            SHARED_FILE_LIST_USERS_ALLOWED.clear()

    def test_unsolicited_user_info_response_is_rejected_before_parse(self):
        """User-info responses should be request-gated before picture/description parsing."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )
        conn.in_buffer = self._pack_peer_message(UserInfoResponse, b"bogus user info response")
        USER_INFO_USERS_ALLOWED.clear()

        try:
            with patch.object(UserInfoResponse, "parse_network_message", side_effect=AssertionError):
                network_thread._process_peer_input(conn)

            network_thread._close_connection.assert_called_once_with(conn)
            network_thread._emit_network_message_event.assert_not_called()

        finally:
            USER_INFO_USERS_ALLOWED.clear()

    def test_expired_shared_file_list_response_grant_is_rejected_before_parse(self):
        """A stale heavyweight response grant should not allow a late large response."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )
        conn.in_buffer = self._pack_peer_message(SharedFileListResponse, b"late response")
        old_ttl = type(SHARED_FILE_LIST_USERS_ALLOWED).GRANT_TTL
        SHARED_FILE_LIST_USERS_ALLOWED.clear()
        SHARED_FILE_LIST_USERS_ALLOWED.add("peer")
        type(SHARED_FILE_LIST_USERS_ALLOWED).GRANT_TTL = 1
        SHARED_FILE_LIST_USERS_ALLOWED.grant_times["peer"] = time.monotonic() - 2

        try:
            with patch.object(SharedFileListResponse, "parse_network_message", side_effect=AssertionError):
                network_thread._process_peer_input(conn)

            self.assertNotIn("peer", SHARED_FILE_LIST_USERS_ALLOWED)
            network_thread._close_connection.assert_called_once_with(conn)
            network_thread._emit_network_message_event.assert_not_called()

        finally:
            type(SHARED_FILE_LIST_USERS_ALLOWED).GRANT_TTL = old_ttl
            SHARED_FILE_LIST_USERS_ALLOWED.clear()

    def test_expired_user_info_response_grant_is_rejected_before_parse(self):
        """A stale user-info grant should not allow a late profile response."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )
        conn.in_buffer = self._pack_peer_message(UserInfoResponse, b"late response")
        old_ttl = type(USER_INFO_USERS_ALLOWED).GRANT_TTL
        USER_INFO_USERS_ALLOWED.clear()
        USER_INFO_USERS_ALLOWED.add("peer")
        type(USER_INFO_USERS_ALLOWED).GRANT_TTL = 1
        USER_INFO_USERS_ALLOWED.grant_times["peer"] = time.monotonic() - 2

        try:
            with patch.object(UserInfoResponse, "parse_network_message", side_effect=AssertionError):
                network_thread._process_peer_input(conn)

            self.assertNotIn("peer", USER_INFO_USERS_ALLOWED)
            network_thread._close_connection.assert_called_once_with(conn)
            network_thread._emit_network_message_event.assert_not_called()

        finally:
            type(USER_INFO_USERS_ALLOWED).GRANT_TTL = old_ttl
            USER_INFO_USERS_ALLOWED.clear()

    def test_allowed_user_info_response_consumes_grant(self):
        """A user-info grant should allow one response and then be removed."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        )
        payload = UserInfoResponse(
            descr="", pic=None, totalupl=0, queuesize=0, slotsavail=False, uploadallowed=0
        ).make_network_message()
        conn.in_buffer = self._pack_peer_message(UserInfoResponse, payload)
        USER_INFO_USERS_ALLOWED.clear()
        USER_INFO_USERS_ALLOWED.add("peer")

        try:
            network_thread._process_peer_input(conn)

            self.assertNotIn("peer", USER_INFO_USERS_ALLOWED)
            network_thread._close_connection.assert_not_called()
            network_thread._emit_network_message_event.assert_called_once()
            self.assertIsInstance(network_thread._emit_network_message_event.call_args.args[0], UserInfoResponse)

        finally:
            USER_INFO_USERS_ALLOWED.clear()

    @staticmethod
    def _set_message_queue(network_thread, messages=None, sizes=None):
        messages = list(messages or [])
        if sizes is None:
            sizes = [0] * len(messages)

        network_thread._message_queue = deque(messages)
        network_thread._message_queue_sizes = deque(sizes)
        network_thread._pending_network_message_bytes = sum(sizes)
        network_thread._pending_network_message_byte_limit_logged = False
        network_thread._server_message_unavailable_limit_logged = False
        network_thread._queued_close_connection_socks = {msg.sock for msg in messages if msg.__class__ is CloseConnection and msg.sock is not None}

    @staticmethod
    def _create_network_thread():
        network_thread = object.__new__(NetworkThread)
        network_thread._file_init_msgs = {}
        network_thread._file_upload_msgs = {}
        network_thread._file_download_msgs = {}
        network_thread._conns_downloaded = {}
        network_thread._conns_uploaded = {}
        network_thread._download_limit_split = 0
        network_thread._upload_limit_split = 0
        network_thread._total_download_bandwidth = 0
        network_thread._total_upload_bandwidth = 0
        network_thread._total_downloads = 0
        network_thread._total_uploads = 0
        network_thread._server_username = "localuser"
        network_thread._username_init_msgs = {}
        network_thread._pending_init_msgs = defaultdict(list)
        network_thread._pending_peer_conns = {}
        network_thread._pending_peer_message_count = 0
        network_thread._pending_peer_message_bytes = 0
        network_thread._pending_peer_message_limit_logged = False
        network_thread._token_init_msgs = {}
        network_thread._requested_peer_addresses = set()
        network_thread._user_addresses = {}
        network_thread._token = 0
        network_thread._should_process_queue = True
        network_thread._conns = {}
        network_thread._close_connection = Mock()
        network_thread._send_message_to_server = Mock()
        network_thread._add_init_message = Mock(return_value=True)
        network_thread._process_conn_messages = Mock()
        network_thread._accept_child_peer_connection = Mock()
        network_thread._incoming_buffer_bytes = 0
        network_thread._incoming_buffer_limit_logged = False
        network_thread._outgoing_buffer_bytes = 0
        network_thread._outgoing_buffer_limit_logged = False
        network_thread._file_upload_buffer_bytes = 0
        network_thread._file_upload_buffer_limit_logged = False
        network_thread._file_download_cycle_bytes = 0
        network_thread._large_peer_message_buffer_bytes = 0
        network_thread._large_peer_message_buffer_count = 0
        network_thread._large_peer_message_buffer_limit_logged = False
        network_thread._incoming_preinit_peer_addresses = defaultdict(int)
        network_thread._incoming_preinit_peer_address_limit_logged = False
        network_thread._incoming_indirect_conn_times = deque()
        network_thread._incoming_indirect_conn_limit_logged = False
        network_thread._forwarded_distributed_searches = {}
        network_thread._forwarded_distributed_search_order = deque()
        network_thread._distributed_server_control_retries = deque()
        network_thread._distributed_server_control_retry_keys = set()
        network_thread._distributed_server_control_retry_limit_logged = False
        network_thread._wait_port_report_retries = deque()
        network_thread._wait_port_report_retry_keys = set()
        network_thread._wait_port_report_retry_limit_logged = False
        network_thread._cant_connect_to_peer_retries = deque()
        network_thread._cant_connect_to_peer_retry_keys = set()
        network_thread._cant_connect_to_peer_retry_limit_logged = False
        network_thread._main_thread_lifecycle_event_retries = deque()
        network_thread._main_thread_lifecycle_event_retry_bytes = 0
        network_thread._main_thread_lifecycle_event_retry_limit_logged = False
        network_thread._server_conn = None
        NetworkThreadUnitTest._set_message_queue(network_thread)
        network_thread._dropped_network_messages = 0
        network_thread._pending_transfer_network_messages = 0
        network_thread._dropped_transfer_network_messages = 0
        network_thread._emit_network_message_event = Mock()
        network_thread._modify_connection_events = Mock()
        return network_thread

    @staticmethod
    def _pack_peer_init_message(username="peer", conn_type=ConnectionType.PEER):
        init = PeerInit(init_user=username, conn_type=conn_type)
        msg_content = init.make_network_message()
        return bytearray(
            init.pack_uint32(len(msg_content) + 1)
            + init.pack_uint8(PEER_INIT_MESSAGE_CODES[PeerInit])
            + msg_content
        )


    def test_main_thread_lifecycle_event_is_retried_after_bridge_backpressure(self):
        """Tiny lifecycle events should not disappear if the main-thread shelf is full."""

        network_thread = self._create_network_thread()
        emit_main_thread = Mock(side_effect=[False, True])

        with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
            self.assertTrue(network_thread._emit_main_thread_lifecycle_event(
                "file-connection-closed", username="user", token=123, sock=None, timed_out=False
            ))
            self.assertEqual(1, len(network_thread._main_thread_lifecycle_event_retries))

            network_thread._process_main_thread_lifecycle_event_retries()

        self.assertFalse(network_thread._main_thread_lifecycle_event_retries)
        self.assertEqual(2, emit_main_thread.call_count)
        self.assertEqual("file-connection-closed", emit_main_thread.call_args.args[0])

    def test_priority_lifecycle_retries_are_inserted_before_preserved_payloads(self):
        """Tiny cleanup/rollback events should not wait behind bulkier preserved wire events."""

        network_thread = self._create_network_thread()
        message = MessageUser()
        message.message = "hello"

        self.assertTrue(network_thread._queue_main_thread_lifecycle_event_retry(
            "message-user", (message,), {}))
        self.assertTrue(network_thread._queue_main_thread_lifecycle_event_retry(
            "file-connection-closed", (), {"username": "peer", "token": 1, "sock": None, "timed_out": False}))
        self.assertTrue(network_thread._queue_main_thread_lifecycle_event_retry(
            "peer-message-unsent", (TransferRequest(),), {}))

        self.assertEqual([
            "file-connection-closed",
            "peer-message-unsent",
            "message-user"
        ], [event_name for event_name, _args, _kwargs in network_thread._main_thread_lifecycle_event_retries])

    def test_priority_lifecycle_retry_evicts_nonpriority_when_shelf_is_full(self):
        """Cleanup events should displace preserved payloads rather than being dropped."""

        network_thread = self._create_network_thread()
        message = MessageUser()
        message.message = "hello"

        with patch.object(slskproto_module.NetworkThread, "MAX_MAIN_THREAD_LIFECYCLE_EVENT_RETRIES", 1):
            self.assertTrue(network_thread._queue_main_thread_lifecycle_event_retry(
                "message-user", (message,), {}))
            self.assertTrue(network_thread._queue_main_thread_lifecycle_event_retry(
                "file-connection-closed", (), {
                    "username": "peer", "token": 1, "sock": None, "timed_out": False
                }))

        self.assertEqual(1, len(network_thread._main_thread_lifecycle_event_retries))
        event_name, _args, kwargs = network_thread._main_thread_lifecycle_event_retries[0]
        self.assertEqual("file-connection-closed", event_name)
        self.assertEqual("peer", kwargs["username"])
        self.assertGreater(network_thread._main_thread_lifecycle_event_retry_bytes, 0)

    def test_priority_lifecycle_retry_does_not_evict_existing_priority_events(self):
        """Priority cleanup ordering should be preserved when the shelf contains only priority events."""

        network_thread = self._create_network_thread()

        with patch.object(slskproto_module.NetworkThread, "MAX_MAIN_THREAD_LIFECYCLE_EVENT_RETRIES", 1):
            self.assertTrue(network_thread._queue_main_thread_lifecycle_event_retry(
                "peer-message-unsent", (QueueUpload("a.mp3"),), {}))
            self.assertFalse(network_thread._queue_main_thread_lifecycle_event_retry(
                "file-connection-closed", (), {
                    "username": "peer", "token": 1, "sock": None, "timed_out": False
                }))

        self.assertEqual(1, len(network_thread._main_thread_lifecycle_event_retries))
        event_name, args, _kwargs = network_thread._main_thread_lifecycle_event_retries[0]
        self.assertEqual("peer-message-unsent", event_name)
        self.assertEqual("a.mp3", args[0].file)

    def test_retryable_parsed_message_uses_lifecycle_retry_when_main_thread_full(self):
        """Small accepted wire-state messages must not be shed behind noisy main-thread backlog."""

        network_thread = self._create_network_thread()
        msg = GetUserStatus("peer", UserStatus.ONLINE)
        emit_main_thread = Mock(return_value=False)

        with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
            NetworkThread._emit_network_message_event(network_thread, msg)

        emit_main_thread.assert_called_once_with("user-status", msg)
        self.assertEqual(1, len(network_thread._main_thread_lifecycle_event_retries))
        event_name, args, kwargs = network_thread._main_thread_lifecycle_event_retries[0]
        self.assertEqual("user-status", event_name)
        self.assertEqual((msg,), args)
        self.assertEqual({}, kwargs)

    def test_retryable_parsed_private_message_uses_lifecycle_retry_when_main_thread_full(self):
        """Private messages need retry preservation because ACK delivery happens in the main thread."""

        network_thread = self._create_network_thread()
        msg = MessageUser("peer", "hello")
        msg.message_id = 123
        emit_main_thread = Mock(return_value=False)

        with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
            NetworkThread._emit_network_message_event(network_thread, msg)

        emit_main_thread.assert_called_once_with("message-user", msg)
        self.assertEqual(1, len(network_thread._main_thread_lifecycle_event_retries))
        event_name, args, kwargs = network_thread._main_thread_lifecycle_event_retries[0]
        self.assertEqual("message-user", event_name)
        self.assertEqual((msg,), args)
        self.assertEqual({}, kwargs)
        self.assertGreater(network_thread._main_thread_lifecycle_event_retry_bytes, 0)

    def test_heavy_peer_response_delivery_failure_emits_lightweight_retry_signal(self):
        """Dropped heavy responses should trigger small retry metadata, not payload retention."""

        search_response = FileSearchResponse(
            search_username="local", token=456, shares=[], freeulslots=True, ulspeed=0, inqueue=0)
        cases = (
            (FileSearchResponse, search_response, "file-search-response", ("file-search-response", 456, "peer")),
            (SharedFileListResponse, SharedFileListResponse(),
             "shared-file-list-response", ("shared-file-list-response",)),
            (UserInfoResponse, UserInfoResponse(), "user-info-response", ("user-info-response",)),
            (FolderContentsResponse, FolderContentsResponse("Music", token=123, shares={}),
             "folder-contents-response", ("folder-contents-response", 123, "Music")),
        )

        for msg_class, msg, event_name, rollback_info in cases:
            with self.subTest(event_name=event_name):
                network_thread = self._create_network_thread()
                msg.username = "peer"
                emit_main_thread = Mock(side_effect=[False, True])

                with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
                    NetworkThread._emit_network_message_event(network_thread, msg)

                self.assertEqual(2, emit_main_thread.call_count)
                emit_main_thread.assert_any_call(event_name, msg)
                emit_main_thread.assert_any_call(
                    "peer-response-delivery-failed", msg_class, "peer", rollback_info)
                self.assertFalse(network_thread._main_thread_lifecycle_event_retries)

    def test_heavy_server_response_delivery_failure_emits_lightweight_retry_signal(self):
        """Dropped heavyweight server responses should trigger small retry metadata."""

        cases = (
            (Recommendations(), ("recommendations",)),
            (GlobalRecommendations(), ("global-recommendations",)),
            (SimilarUsers(), ("similar-users",)),
            (UserInterests("peer"), ("user-interests", "peer")),
            (ItemRecommendations("artist"), ("item-recommendations", "artist")),
            (ItemSimilarUsers("song"), ("item-similar-users", "song")),
            (RoomList(), ("room-list",)),
        )

        for msg, rollback_info in cases:
            with self.subTest(msg_class=msg.__class__.__name__):
                network_thread = self._create_network_thread()
                emit_main_thread = Mock(side_effect=[False, True])

                with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
                    NetworkThread._emit_network_message_event(network_thread, msg)

                event_name = slskproto_module.NETWORK_MESSAGE_EVENTS[msg.__class__]
                emit_main_thread.assert_any_call(event_name, msg)
                emit_main_thread.assert_any_call(
                    "server-response-delivery-failed", msg.__class__, rollback_info)
                self.assertFalse(network_thread._main_thread_lifecycle_event_retries)

    def test_retryable_incoming_request_messages_use_lifecycle_retry_when_main_thread_full(self):
        """Accepted peer/search requests should not be dropped before response generation."""

        request_cases = (
            (FileSearch(token=1, text="rare term"), "file-search-request-server"),
            (DistribSearch(search_username="peer", token=2, searchterm="rare term"),
             "file-search-request-distributed"),
            (FolderContentsRequest(directory="Music", token=3), "folder-contents-request"),
            (SharedFileListRequest(), "shared-file-list-request"),
            (UserInfoRequest(), "user-info-request"),
        )

        for msg, event_name in request_cases:
            with self.subTest(event_name=event_name):
                network_thread = self._create_network_thread()
                emit_main_thread = Mock(return_value=False)

                with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
                    NetworkThread._emit_network_message_event(network_thread, msg)

                emit_main_thread.assert_called_once_with(event_name, msg)
                self.assertEqual(1, len(network_thread._main_thread_lifecycle_event_retries))
                queued_event_name, args, kwargs = network_thread._main_thread_lifecycle_event_retries[0]
                self.assertEqual(event_name, queued_event_name)
                self.assertEqual((msg,), args)
                self.assertEqual({}, kwargs)
                self.assertGreater(network_thread._main_thread_lifecycle_event_retry_bytes, 0)

    def test_small_server_state_messages_use_lifecycle_retry_when_main_thread_full(self):
        """Accepted small server state must not be shed before owner modules apply it."""

        joined = JoinRoom("room")
        joined.users = []
        left = LeaveRoom("room")
        user_joined = UserJoinedRoom()
        user_joined.room = "room"
        user_joined.userdata = SimpleNamespace(username="peer", status=UserStatus.ONLINE)
        user_left = UserLeftRoom()
        user_left.room = "room"
        user_left.username = "peer"
        priv_users = PrivateRoomUsers()
        priv_users.room = "room"
        priv_users.users = ["peer"]
        priv_ops = PrivateRoomOperators()
        priv_ops.room = "room"
        priv_ops.operators = ["peer"]
        ticker_state = RoomTickerState()
        ticker_state.room = "room"
        ticker_state.msgs = [("peer", "hello")]
        ticker_add = RoomTickerAdd()
        ticker_add.room = "room"
        ticker_add.user = "peer"
        ticker_add.msg = "hello"
        ticker_remove = RoomTickerRemove()
        ticker_remove.room = "room"
        ticker_remove.user = "peer"
        excluded = ExcludedSearchPhrases()
        excluded.phrases = ["blocked"]
        wishlist = WishlistInterval()
        wishlist.seconds = 123
        changed = ChangePassword("new")
        privileges = CheckPrivileges()
        privileges.seconds = 456

        state_cases = (
            (joined, "join-room"),
            (left, "leave-room"),
            (user_joined, "user-joined-room"),
            (user_left, "user-left-room"),
            (PrivateRoomAddUser("room", "peer"), "private-room-add-user"),
            (PrivateRoomRemoveUser("room", "peer"), "private-room-remove-user"),
            (PrivateRoomAdded("room"), "private-room-added"),
            (PrivateRoomToggle(True), "private-room-toggle"),
            (priv_users, "private-room-users"),
            (priv_ops, "private-room-operators"),
            (ticker_state, "ticker-state"),
            (ticker_add, "ticker-add"),
            (ticker_remove, "ticker-remove"),
            (excluded, "excluded-search-phrases"),
            (wishlist, "set-wishlist-interval"),
            (changed, "change-password"),
            (privileges, "check-privileges"),
        )

        for msg, event_name in state_cases:
            with self.subTest(event_name=event_name):
                network_thread = self._create_network_thread()
                emit_main_thread = Mock(return_value=False)

                with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
                    NetworkThread._emit_network_message_event(network_thread, msg)

                emit_main_thread.assert_called_once_with(event_name, msg)
                self.assertEqual(1, len(network_thread._main_thread_lifecycle_event_retries))
                queued_event_name, args, kwargs = network_thread._main_thread_lifecycle_event_retries[0]
                self.assertEqual(event_name, queued_event_name)
                self.assertEqual((msg,), args)
                self.assertEqual({}, kwargs)
                self.assertGreater(network_thread._main_thread_lifecycle_event_retry_bytes, 0)

    def test_lifecycle_retry_shelf_has_byte_budget(self):
        """Retry preservation must not become an unbounded retained-message shelf."""

        network_thread = self._create_network_thread()
        msg = MessageUser("peer", "x" * 2048)
        emit_main_thread = Mock(return_value=False)

        with patch.object(slskproto_module.NetworkThread, "MAX_MAIN_THREAD_LIFECYCLE_EVENT_RETRY_BYTES", 256), \
                patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
            NetworkThread._emit_network_message_event(network_thread, msg)

        emit_main_thread.assert_called_once_with("message-user", msg)
        self.assertFalse(network_thread._main_thread_lifecycle_event_retries)
        self.assertEqual(0, network_thread._main_thread_lifecycle_event_retry_bytes)
        self.assertTrue(network_thread._main_thread_lifecycle_event_retry_limit_logged)

    def test_main_thread_lifecycle_retry_preserves_order_when_still_full(self):
        """A still-full main-thread bridge should keep the event at the head of the retry queue."""

        network_thread = self._create_network_thread()
        emit_main_thread = Mock(return_value=False)

        with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
            network_thread._emit_main_thread_lifecycle_event("peer-message-unsent", QueueUpload("a.mp3"))
            network_thread._emit_main_thread_lifecycle_event("peer-message-unsent", QueueUpload("b.mp3"))
            network_thread._process_main_thread_lifecycle_event_retries()

        self.assertEqual(2, len(network_thread._main_thread_lifecycle_event_retries))
        _event_name, args, _kwargs = network_thread._main_thread_lifecycle_event_retries[0]
        self.assertEqual("a.mp3", args[0].file)

    def test_file_connection_close_queues_lifecycle_retry_when_main_thread_full(self):
        """Closed file sockets must preserve cleanup notifications under bridge backpressure."""

        network_thread = self._create_network_thread()
        sock = MockSocket()
        init = PeerInit(target_user="user", conn_type=ConnectionType.FILE)
        init.sock = sock
        conn = PeerConnection(sock=sock, init=init)
        conn.is_established = True
        file_init = FileTransferInit(token=123)
        network_thread._conns = {sock: conn}
        network_thread._num_sockets = 1
        network_thread._file_init_msgs = {conn: file_init}
        network_thread._selector = SimpleNamespace(unregister=Mock())
        network_thread._close_socket = Mock()
        network_thread._clear_incoming_buffer = Mock()
        network_thread._clear_output_buffers = Mock()
        network_thread._release_preinit_peer_address = Mock()
        network_thread._remove_child_peer_connection = Mock()
        network_thread._send_have_no_parent = Mock()
        network_thread._calc_download_limit = Mock()
        network_thread._calc_upload_limit_function = Mock()
        emit_main_thread = Mock(return_value=False)

        with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
            NetworkThread._close_connection(network_thread, conn)

        self.assertEqual(1, len(network_thread._main_thread_lifecycle_event_retries))
        event_name, _args, kwargs = network_thread._main_thread_lifecycle_event_retries[0]
        self.assertEqual("file-connection-closed", event_name)
        self.assertEqual("user", kwargs["username"])
        self.assertEqual(123, kwargs["token"])

    def test_file_connection_close_carries_final_download_offset(self):
        """Close cleanup must not depend on a final coalesced progress event."""

        network_thread = self._create_network_thread()
        sock = MockSocket()
        init = PeerInit(target_user="user", conn_type=ConnectionType.FILE)
        init.sock = sock
        conn = PeerConnection(sock=sock, init=init)
        conn.is_established = True
        file_init = FileTransferInit(token=321)
        network_thread._conns = {sock: conn}
        network_thread._num_sockets = 1
        network_thread._file_init_msgs = {conn: file_init}
        network_thread._file_download_msgs = {conn: DownloadFile(leftbytes=0)}
        network_thread._selector = SimpleNamespace(unregister=Mock())
        network_thread._close_socket = Mock()
        network_thread._clear_incoming_buffer = Mock()
        network_thread._clear_output_buffers = Mock()
        network_thread._release_preinit_peer_address = Mock()
        network_thread._remove_child_peer_connection = Mock()
        network_thread._send_have_no_parent = Mock()
        network_thread._calc_download_limit = Mock()
        network_thread._calc_upload_limit_function = Mock()
        emit_main_thread = Mock(return_value=True)

        with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
            NetworkThread._close_connection(network_thread, conn)

        emit_main_thread.assert_any_call(
            "file-connection-closed", username="user", token=321, sock=sock,
            timed_out=False, bytes_left=0
        )

    def test_file_connection_close_carries_final_upload_offset(self):
        """Close cleanup must receive the last uploaded byte offset if progress is shed."""

        network_thread = self._create_network_thread()
        sock = MockSocket()
        init = PeerInit(target_user="user", conn_type=ConnectionType.FILE)
        init.sock = sock
        conn = PeerConnection(sock=sock, init=init)
        conn.is_established = True
        file_init = FileTransferInit(token=654)
        upload_file = UploadFile(size=100, username="user")
        upload_file.offset = 40
        upload_file.sentbytes = 60
        network_thread._conns = {sock: conn}
        network_thread._num_sockets = 1
        network_thread._file_init_msgs = {conn: file_init}
        network_thread._file_upload_msgs = {conn: upload_file}
        network_thread._selector = SimpleNamespace(unregister=Mock())
        network_thread._close_socket = Mock()
        network_thread._clear_incoming_buffer = Mock()
        network_thread._clear_output_buffers = Mock()
        network_thread._release_preinit_peer_address = Mock()
        network_thread._remove_child_peer_connection = Mock()
        network_thread._send_have_no_parent = Mock()
        network_thread._calc_download_limit = Mock()
        network_thread._calc_upload_limit_function = Mock()
        emit_main_thread = Mock(return_value=True)

        with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
            NetworkThread._close_connection(network_thread, conn)

        emit_main_thread.assert_any_call(
            "file-connection-closed", username="user", token=654, sock=sock,
            timed_out=False, current_byte_offset=100
        )


    def test_peer_init_output_failure_skips_queued_peer_messages(self):
        """Queued peer messages must not be processed if the PeerInit frame cannot be queued."""

        network_thread = self._create_network_thread()
        sock = MockSocket()
        init = PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        init.outgoing_msgs.append(QueueUpload("queued.mp3"))
        conn = PeerConnection(sock=sock, init=init)
        network_thread._conns[sock] = conn
        network_thread._append_outgoing_message = Mock(return_value=False)

        network_thread._establish_outgoing_peer_connection(conn)

        network_thread._process_conn_messages.assert_not_called()
        network_thread._accept_child_peer_connection.assert_not_called()

    def test_pierce_firewall_output_failure_skips_child_accept_and_queued_messages(self):
        """Queued child messages must not be processed if PierceFireWall cannot be queued."""

        network_thread = self._create_network_thread()
        sock = MockSocket()
        init = PeerInit(target_user="peer", conn_type=ConnectionType.DISTRIBUTED)
        init.outgoing_msgs.append(QueueUpload("queued.mp3"))
        conn = PeerConnection(sock=sock, init=init, response_token=123)
        network_thread._conns[sock] = conn
        network_thread._append_outgoing_message = Mock(return_value=False)

        network_thread._establish_outgoing_peer_connection(conn)

        network_thread._accept_child_peer_connection.assert_not_called()
        network_thread._process_conn_messages.assert_not_called()

    def test_peer_init_pack_failure_closes_connection(self):
        """A peer-init pack failure should fail closed before queued peer messages run."""

        network_thread = self._create_network_thread()
        sock = MockSocket()
        init = PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        init.sock = sock
        conn = PeerConnection(sock=sock, init=init)
        network_thread._conns[sock] = conn
        network_thread._pack_network_message = Mock(return_value=None)

        self.assertFalse(network_thread._process_peer_init_output(init))

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._modify_connection_events.assert_not_called()

    def test_peer_init_waits_for_complete_header(self):
        network_thread = self._create_network_thread()
        packet = self._pack_peer_init_message()
        conn = PeerConnection(sock=MockSocket())
        conn.in_buffer = packet[:3]

        self.assertIsNone(network_thread._process_peer_init_input(conn))

        self.assertEqual(packet[:3], conn.in_buffer)
        network_thread._close_connection.assert_not_called()

    def test_peer_init_waits_for_complete_message(self):
        network_thread = self._create_network_thread()
        packet = self._pack_peer_init_message(username="remoteuser")
        conn = PeerConnection(sock=MockSocket())
        conn.in_buffer = packet[:-1]

        self.assertIsNone(network_thread._process_peer_init_input(conn))

        self.assertEqual(packet[:-1], conn.in_buffer)
        self.assertTrue(conn.has_post_init_activity)
        network_thread._close_connection.assert_not_called()

        conn.in_buffer += packet[-1:]
        init = network_thread._process_peer_init_input(conn)

        self.assertEqual("remoteuser", init.target_user)
        self.assertEqual(ConnectionType.PEER, init.conn_type)
        self.assertFalse(conn.in_buffer)

    def test_peer_init_allows_matching_cached_peer_address(self):
        network_thread = self._create_network_thread()
        network_thread._user_addresses["remoteuser"] = ("203.0.113.10", 2234)
        packet = self._pack_peer_init_message(username="remoteuser")
        conn = PeerConnection(sock=MockSocket(), addr=("203.0.113.10", 49152))
        conn.in_buffer = packet

        init = network_thread._process_peer_init_input(conn)

        self.assertIsNotNone(init)
        self.assertEqual("remoteuser", init.target_user)
        network_thread._close_connection.assert_not_called()
        network_thread._emit_network_message_event.assert_called_once()

    def test_peer_init_rejects_claimed_cached_user_from_different_address(self):
        network_thread = self._create_network_thread()
        network_thread._user_addresses["trusted"] = ("203.0.113.10", 2234)
        packet = self._pack_peer_init_message(username="trusted")
        conn = PeerConnection(sock=MockSocket(), addr=("198.51.100.20", 49152))
        conn.in_buffer = packet

        self.assertIsNone(network_thread._process_peer_init_input(conn))

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._emit_network_message_event.assert_not_called()

    def test_peer_init_allows_unknown_user_without_cached_address(self):
        network_thread = self._create_network_thread()
        packet = self._pack_peer_init_message(username="unknown")
        conn = PeerConnection(sock=MockSocket(), addr=("198.51.100.20", 49152))
        conn.in_buffer = packet

        init = network_thread._process_peer_init_input(conn)

        self.assertIsNotNone(init)
        self.assertEqual("unknown", init.target_user)
        network_thread._close_connection.assert_not_called()

    def test_peer_init_rejects_message_size_without_type_byte(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket(), addr=("1.2.3.4", 1234))
        conn.in_buffer = bytearray(
            PeerInit.pack_uint32(0)
            + PeerInit.pack_uint8(PEER_INIT_MESSAGE_CODES[PeerInit])
        )

        self.assertIsNone(network_thread._process_peer_init_input(conn))

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._emit_network_message_event.assert_not_called()

    def test_peer_init_rejects_message_larger_than_class_limit_before_full_payload(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket(), addr=("1.2.3.4", 1234))
        msg_size = PeerInit.MAX_INCOMING_MESSAGE_SIZE + 1
        conn.in_buffer = bytearray(
            PeerInit.pack_uint32(msg_size)
            + PeerInit.pack_uint8(PEER_INIT_MESSAGE_CODES[PeerInit])
        )

        self.assertIsNone(network_thread._process_peer_init_input(conn))

        network_thread._close_connection.assert_called_once_with(conn)
        self.assertFalse(conn.has_post_init_activity)
        network_thread._emit_network_message_event.assert_not_called()

    def test_server_message_rejects_size_without_message_code(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket())
        conn.in_buffer = bytearray(
            ServerMessage.pack_uint32(NetworkThread.SERVER_PEER_MESSAGE_CODE_SIZE - 1)
            + ServerMessage.pack_uint32(0)
        )

        network_thread._process_server_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._emit_network_message_event.assert_not_called()

    def test_server_message_rejects_message_larger_than_class_limit_before_full_payload(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket())
        msg_size = EmbeddedMessage.MAX_INCOMING_MESSAGE_SIZE + 1
        conn.in_buffer = bytearray(
            EmbeddedMessage.pack_uint32(msg_size)
            + EmbeddedMessage.pack_uint32(SERVER_MESSAGE_CODES[EmbeddedMessage])
        )

        network_thread._process_server_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._emit_network_message_event.assert_not_called()

    def test_tiny_server_message_rejects_oversized_declared_payload_before_full_payload(self):
        """Tiny server-control messages should not inherit the broad list-message cap."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket())
        msg_size = ServerPing.MAX_INCOMING_MESSAGE_SIZE + 1
        conn.in_buffer = bytearray(
            ServerMessage.pack_uint32(msg_size)
            + ServerMessage.pack_uint32(SERVER_MESSAGE_CODES[ServerPing])
        )

        network_thread._process_server_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._emit_network_message_event.assert_not_called()

    def test_login_message_rejects_oversized_declared_payload_before_full_payload(self):
        """Login responses should not inherit the broad server-list message budget."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket())
        msg_size = Login.MAX_INCOMING_MESSAGE_SIZE + 1
        conn.in_buffer = bytearray(
            ServerMessage.pack_uint32(msg_size)
            + ServerMessage.pack_uint32(SERVER_MESSAGE_CODES[Login])
        )

        network_thread._process_server_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._emit_network_message_event.assert_not_called()

    def test_unhandled_server_control_message_rejects_oversized_declared_payload_before_parsing(self):
        """Outbound-only/obsolete server codes should be capped before buffering giant tails."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket())
        msg_size = SetWaitPort.MAX_INCOMING_MESSAGE_SIZE + 1
        conn.in_buffer = bytearray(
            ServerMessage.pack_uint32(msg_size)
            + ServerMessage.pack_uint32(SERVER_MESSAGE_CODES[SetWaitPort])
        )

        network_thread._process_server_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._emit_network_message_event.assert_not_called()

    def test_private_room_delta_rejects_oversized_declared_payload_before_full_payload(self):
        """Two-string private-room deltas should not inherit a multi-megabyte list cap."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket())
        msg_size = PrivateRoomAddUser.MAX_INCOMING_MESSAGE_SIZE + 1
        conn.in_buffer = bytearray(
            ServerMessage.pack_uint32(msg_size)
            + ServerMessage.pack_uint32(SERVER_MESSAGE_CODES[PrivateRoomAddUser])
        )

        network_thread._process_server_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._emit_network_message_event.assert_not_called()

    def test_excluded_search_phrases_rejects_oversized_declared_payload_before_full_payload(self):
        """Excluded phrase lists have a tighter computed cap than the generic list budget."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket())
        msg_size = ExcludedSearchPhrases.MAX_INCOMING_MESSAGE_SIZE + 1
        conn.in_buffer = bytearray(
            ServerMessage.pack_uint32(msg_size)
            + ServerMessage.pack_uint32(SERVER_MESSAGE_CODES[ExcludedSearchPhrases])
        )

        network_thread._process_server_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._emit_network_message_event.assert_not_called()

    def test_message_acked_rejects_oversized_declared_payload_before_full_payload(self):
        """Private-message ACKs are fixed-size server-control messages."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket())
        msg_size = MessageAcked.MAX_INCOMING_MESSAGE_SIZE + 1
        conn.in_buffer = bytearray(
            ServerMessage.pack_uint32(msg_size)
            + ServerMessage.pack_uint32(SERVER_MESSAGE_CODES[MessageAcked])
        )

        network_thread._process_server_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._emit_network_message_event.assert_not_called()

    def test_user_status_message_rejects_oversized_declared_payload_before_full_payload(self):
        """Status updates are bounded by username+status fields, not list-message size."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket())
        msg_size = GetUserStatus.MAX_INCOMING_MESSAGE_SIZE + 1
        conn.in_buffer = bytearray(
            ServerMessage.pack_uint32(msg_size)
            + ServerMessage.pack_uint32(SERVER_MESSAGE_CODES[GetUserStatus])
        )

        network_thread._process_server_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._emit_network_message_event.assert_not_called()

    def test_server_message_rejects_unknown_type_before_full_payload(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket())
        msg_size = ServerMessage.MAX_UNKNOWN_SERVER_MESSAGE_SIZE + 1
        conn.in_buffer = bytearray(
            ServerMessage.pack_uint32(msg_size)
            + ServerMessage.pack_uint32(0xFFFFFFFF)
        )

        network_thread._process_server_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._emit_network_message_event.assert_not_called()

    def test_unhandled_server_message_is_skipped_without_parsing(self):
        """Known server messages with no event/internal effect should not be materialized."""

        network_thread = self._create_network_thread()
        msg_content = GlobalUserList.pack_uint32(1)

        with patch.object(GlobalUserList, "parse_network_message", side_effect=AssertionError("parsed")):
            self.assertTrue(network_thread._process_server_message(
                SERVER_MESSAGE_CODES[GlobalUserList], len(msg_content), msg_content, 0, len(msg_content)
            ))

        network_thread._emit_network_message_event.assert_not_called()

    def test_unhandled_peer_message_is_skipped_without_parsing(self):
        """Known obsolete peer messages with no event should be discarded after framing."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.PEER)
        )
        msg_content = PMessageUser.pack_string("old peer text")
        conn.in_buffer = bytearray(
            PMessageUser.pack_uint32(len(msg_content) + NetworkThread.SERVER_PEER_MESSAGE_CODE_SIZE)
            + PMessageUser.pack_uint32(PEER_MESSAGE_CODES[PMessageUser])
            + msg_content
        )

        with patch.object(PMessageUser, "parse_network_message", side_effect=AssertionError("parsed")):
            network_thread._process_peer_input(conn)

        self.assertFalse(conn.in_buffer)
        network_thread._close_connection.assert_not_called()
        network_thread._emit_network_message_event.assert_not_called()

    def test_possible_parents_connection_attempts_are_bounded(self):
        network_thread = self._create_network_thread()
        network_thread._parent_conn = None
        network_thread._potential_parents = {}
        network_thread._initiate_connection_to_peer = Mock()

        msg = PossibleParents()
        msg.list = {f"user{i}": ("203.0.113.1", 2234) for i in range(20)}

        old_limit = NetworkThread.MAX_POSSIBLE_PARENT_CONNECTION_ATTEMPTS
        NetworkThread.MAX_POSSIBLE_PARENT_CONNECTION_ATTEMPTS = 3

        try:
            with patch.object(slskproto_module.NetworkThread, "_unpack_network_message", return_value=msg):
                self.assertTrue(network_thread._process_server_message(
                    SERVER_MESSAGE_CODES[PossibleParents], 0, memoryview(b""), 0, 0
                ))

        finally:
            NetworkThread.MAX_POSSIBLE_PARENT_CONNECTION_ATTEMPTS = old_limit

        self.assertEqual(3, network_thread._initiate_connection_to_peer.call_count)

    def test_peer_message_rejects_size_without_message_code(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.PEER)
        )
        conn.in_buffer = bytearray(
            UserInfoResponse.pack_uint32(NetworkThread.SERVER_PEER_MESSAGE_CODE_SIZE - 1)
            + UserInfoResponse.pack_uint32(PEER_MESSAGE_CODES[UserInfoResponse])
        )

        network_thread._process_peer_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._emit_network_message_event.assert_not_called()

    def test_peer_message_rejects_message_larger_than_class_limit_before_full_payload(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.PEER)
        )
        msg_size = QueueUpload.MAX_INCOMING_MESSAGE_SIZE + 1
        conn.in_buffer = bytearray(
            QueueUpload.pack_uint32(msg_size)
            + QueueUpload.pack_uint32(PEER_MESSAGE_CODES[QueueUpload])
        )

        network_thread._process_peer_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        self.assertFalse(conn.has_post_init_activity)
        network_thread._emit_network_message_event.assert_not_called()

    def test_peer_transfer_response_rejects_oversized_declared_payload_before_full_payload(self):
        """Small peer transfer-control messages should not inherit the broad text cap."""

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.PEER)
        )
        msg_size = TransferResponse.MAX_INCOMING_MESSAGE_SIZE + 1
        conn.in_buffer = bytearray(
            TransferResponse.pack_uint32(msg_size)
            + TransferResponse.pack_uint32(PEER_MESSAGE_CODES[TransferResponse])
        )

        network_thread._process_peer_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        self.assertFalse(conn.has_post_init_activity)
        network_thread._emit_network_message_event.assert_not_called()

    def test_peer_message_rejects_unknown_type_before_full_payload(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.PEER)
        )
        conn.in_buffer = bytearray(
            ServerMessage.pack_uint32(NetworkThread.MAX_INCOMING_MESSAGE_SIZE)
            + ServerMessage.pack_uint32(0xFFFFFFFF)
        )

        network_thread._process_peer_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        self.assertFalse(conn.has_post_init_activity)
        network_thread._emit_network_message_event.assert_not_called()

    def test_distributed_message_rejects_size_without_message_code(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.DISTRIBUTED)
        )
        conn.in_buffer = bytearray(
            DistribSearch.pack_uint32(0)
            + DistribSearch.pack_uint8(DISTRIBUTED_MESSAGE_CODES[DistribSearch])
        )

        network_thread._process_distrib_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._emit_network_message_event.assert_not_called()

    def test_distributed_message_rejects_unknown_type_before_full_payload(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.DISTRIBUTED)
        )
        conn.in_buffer = bytearray(
            DistribSearch.pack_uint32(NetworkThread.MAX_INCOMING_MESSAGE_SIZE)
            + DistribSearch.pack_uint8(0xFF)
        )

        network_thread._process_distrib_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        self.assertFalse(conn.has_post_init_activity)
        network_thread._emit_network_message_event.assert_not_called()

    def test_distributed_message_rejects_message_larger_than_class_limit_before_full_payload(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.DISTRIBUTED)
        )
        msg_size = DistribSearch.MAX_INCOMING_MESSAGE_SIZE + 1
        conn.in_buffer = bytearray(
            DistribSearch.pack_uint32(msg_size)
            + DistribSearch.pack_uint8(DISTRIBUTED_MESSAGE_CODES[DistribSearch])
        )

        network_thread._process_distrib_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        self.assertFalse(conn.has_post_init_activity)
        network_thread._emit_network_message_event.assert_not_called()

    def test_embedded_distributed_message_rejects_tight_declared_payload_before_full_payload(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.DISTRIBUTED)
        )
        msg_size = DistribEmbeddedMessage.MAX_INCOMING_MESSAGE_SIZE + 1
        conn.in_buffer = bytearray(
            DistribEmbeddedMessage.pack_uint32(msg_size)
            + DistribEmbeddedMessage.pack_uint8(DISTRIBUTED_MESSAGE_CODES[DistribEmbeddedMessage])
        )

        network_thread._process_distrib_input(conn)

        network_thread._close_connection.assert_called_once_with(conn)
        self.assertFalse(conn.has_post_init_activity)
        network_thread._emit_network_message_event.assert_not_called()

    def test_peer_connection_keys_do_not_collide_by_concatenation(self):
        network_thread = object.__new__(NetworkThread)
        network_thread._username_init_msgs = {}

        first_init = PeerInit(target_user="ab", conn_type="c")
        second_init = PeerInit(target_user="a", conn_type="bc")

        self.assertTrue(network_thread._add_init_message(first_init))
        self.assertTrue(network_thread._add_init_message(second_init))
        self.assertEqual(2, len(network_thread._username_init_msgs))
        self.assertIs(first_init, network_thread._username_init_msgs[("ab", "c")])
        self.assertIs(second_init, network_thread._username_init_msgs[("a", "bc")])

    def test_pending_peer_connections_do_not_collide_by_address(self):
        network_thread = self._create_network_thread()
        network_thread._pending_peer_conns = {}
        network_thread._num_sockets = NetworkThread.MAX_SOCKETS
        addr = ("203.0.113.12", 2234)

        first_init = PeerInit(target_user="user1", conn_type=ConnectionType.PEER)
        second_init = PeerInit(target_user="user2", conn_type=ConnectionType.DISTRIBUTED)

        network_thread._init_peer_connection(addr, first_init, response_token=101)
        network_thread._init_peer_connection(addr, second_init, response_token=202)

        self.assertEqual(2, len(network_thread._pending_peer_conns))
        self.assertEqual({101, 202}, {pending.response_token for pending in network_thread._pending_peer_conns.values()})

    def test_pending_peer_connection_retries_with_original_response_token(self):
        network_thread = self._create_network_thread()
        network_thread._pending_peer_conns = {}
        network_thread._num_sockets = NetworkThread.MAX_SOCKETS
        addr = ("203.0.113.12", 2234)
        init = PeerInit(target_user="user", conn_type=ConnectionType.PEER)

        network_thread._init_peer_connection(addr, init, response_token=303)

        network_thread._num_sockets = 0
        network_thread._init_peer_connection = Mock()
        network_thread._check_connections(current_time=0)

        network_thread._init_peer_connection.assert_called_once_with(addr, init, response_token=303)

    def test_pending_peer_message_queue_is_capped(self):
        network_thread = self._create_network_thread()
        init = PeerInit(target_user="user", conn_type=ConnectionType.PEER)

        old_limit = NetworkThread.MAX_PENDING_PEER_MESSAGES_PER_INIT
        NetworkThread.MAX_PENDING_PEER_MESSAGES_PER_INIT = 1

        try:
            self.assertTrue(network_thread._queue_peer_message(init, QueueUpload("first")))
            self.assertFalse(network_thread._queue_peer_message(init, QueueUpload("second")))
        finally:
            NetworkThread.MAX_PENDING_PEER_MESSAGES_PER_INIT = old_limit

        self.assertEqual(1, len(init.outgoing_msgs))
        self.assertEqual("first", init.outgoing_msgs[0].file)

    def test_aggregate_pending_peer_message_queue_is_capped(self):
        network_thread = self._create_network_thread()
        first_init = PeerInit(target_user="user1", conn_type=ConnectionType.PEER)
        second_init = PeerInit(target_user="user2", conn_type=ConnectionType.PEER)

        old_limit = NetworkThread.MAX_PENDING_PEER_MESSAGES
        NetworkThread.MAX_PENDING_PEER_MESSAGES = 1

        try:
            self.assertTrue(network_thread._queue_peer_message(first_init, QueueUpload("first")))
            self.assertFalse(network_thread._queue_peer_message(second_init, QueueUpload("second")))
        finally:
            NetworkThread.MAX_PENDING_PEER_MESSAGES = old_limit

        self.assertEqual(1, network_thread._pending_peer_message_count)
        self.assertEqual(1, len(first_init.outgoing_msgs))
        self.assertEqual([], second_init.outgoing_msgs)

    def test_pending_peer_message_byte_queue_is_capped(self):
        """Heavy peer messages should not bypass pre-connection queues by being few but huge."""

        network_thread = self._create_network_thread()
        init = PeerInit(target_user="user", conn_type=ConnectionType.PEER)

        old_init_limit = NetworkThread.MAX_PENDING_PEER_MESSAGE_BYTES_PER_INIT
        old_total_limit = NetworkThread.MAX_PENDING_PEER_MESSAGE_BYTES
        NetworkThread.MAX_PENDING_PEER_MESSAGE_BYTES_PER_INIT = 512
        NetworkThread.MAX_PENDING_PEER_MESSAGE_BYTES = 1024

        try:
            self.assertFalse(network_thread._queue_peer_message(init, QueueUpload("x" * 1024)))

        finally:
            NetworkThread.MAX_PENDING_PEER_MESSAGE_BYTES_PER_INIT = old_init_limit
            NetworkThread.MAX_PENDING_PEER_MESSAGE_BYTES = old_total_limit

        self.assertEqual([], init.outgoing_msgs)
        self.assertEqual(0, init.outgoing_msg_bytes)
        self.assertEqual(0, network_thread._pending_peer_message_bytes)

    def test_pending_peer_message_bytes_released_when_cleared(self):
        network_thread = self._create_network_thread()
        init = PeerInit(target_user="user", conn_type=ConnectionType.PEER)

        self.assertTrue(network_thread._queue_peer_message(init, QueueUpload("queued")))
        self.assertGreater(init.outgoing_msg_bytes, 0)
        self.assertEqual(init.outgoing_msg_bytes, network_thread._pending_peer_message_bytes)

        network_thread._clear_queued_peer_messages(init)

        self.assertEqual([], init.outgoing_msgs)
        self.assertEqual(0, init.outgoing_msg_bytes)
        self.assertEqual(0, network_thread._pending_peer_message_bytes)

    def test_pending_peer_message_bytes_transfer_between_inits(self):
        network_thread = self._create_network_thread()
        source_init = PeerInit(target_user="user", conn_type=ConnectionType.PEER)
        target_init = PeerInit(target_user="user", conn_type=ConnectionType.DISTRIBUTED)

        self.assertTrue(network_thread._queue_peer_message(source_init, QueueUpload("queued")))
        queued_bytes = source_init.outgoing_msg_bytes

        network_thread._transfer_queued_peer_messages(source_init, target_init)

        self.assertEqual([], source_init.outgoing_msgs)
        self.assertEqual(0, source_init.outgoing_msg_bytes)
        self.assertEqual(queued_bytes, target_init.outgoing_msg_bytes)
        self.assertEqual(queued_bytes, network_thread._pending_peer_message_bytes)

        network_thread._clear_queued_peer_messages(target_init)
        self.assertEqual(0, network_thread._pending_peer_message_bytes)

    def test_peer_connection_failure_events_filter_non_transfer_messages(self):
        """Connection errors should not copy heavyweight browse/info messages into the UI event queue."""

        messages = [
            SharedFileListRequest(),
            UserInfoRequest(),
            QueueUpload("downloaded.mp3"),
            PlaceInQueueRequest("queued.mp3"),
            TransferRequest(direction=1, token=123, file="uploaded.mp3", filesize=10),
            FileTransferInit(token=456),
        ]

        filtered_messages = NetworkThread._get_peer_connection_failure_messages(messages)

        self.assertEqual([QueueUpload, PlaceInQueueRequest, TransferRequest, FileTransferInit], [
            msg.__class__ for msg in filtered_messages
        ])

    def test_peer_connection_error_uses_filtered_message_payload(self):
        """Main-thread error events should receive only transfer-control messages needed by handlers."""

        network_thread = self._create_network_thread()
        init = PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        init.outgoing_msgs.extend([SharedFileListRequest(), QueueUpload("downloaded.mp3")])
        fake_events = SimpleNamespace(emit_main_thread=Mock())

        with patch.object(slskproto_module, "events", fake_events):
            network_thread._emit_peer_connection_error("peer", ConnectionType.PEER, init, is_offline=True)

        calls = fake_events.emit_main_thread.call_args_list
        self.assertEqual("peer-request-unsent", calls[0].args[0])
        self.assertEqual((SharedFileListRequest, "peer", init.outgoing_msgs[0]), calls[0].args[1:])

        _event_name, = calls[1].args
        kwargs = calls[1].kwargs
        self.assertEqual("peer-connection-error", _event_name)
        self.assertEqual("peer", kwargs["username"])
        self.assertTrue(kwargs["is_offline"])
        self.assertEqual([QueueUpload], [msg.__class__ for msg in kwargs["msgs"]])

    def test_peer_output_pack_failure_emits_unsent_transfer_event(self):
        network_thread = self._create_network_thread()
        msg = TransferRequest(
            direction=TransferDirection.UPLOAD, token=123, file="Folder\\file.mp3", filesize=456
        )
        msg.username = "peer"
        msg.sock = MockSocket()
        network_thread._pack_network_message = Mock(return_value=None)
        fake_events = SimpleNamespace(emit_main_thread=Mock())

        with patch.object(slskproto_module, "events", fake_events):
            network_thread._process_peer_output(msg)

        fake_events.emit_main_thread.assert_called_once_with("peer-message-unsent", msg)


    def test_peer_output_pack_failure_emits_unsent_queue_upload_event(self):
        network_thread = self._create_network_thread()
        msg = QueueUpload("Folder\\queued.mp3")
        msg.username = "peer"
        msg.sock = MockSocket()
        network_thread._pack_network_message = Mock(return_value=None)
        fake_events = SimpleNamespace(emit_main_thread=Mock())

        with patch.object(slskproto_module, "events", fake_events):
            network_thread._process_peer_output(msg)

        fake_events.emit_main_thread.assert_called_once_with("peer-message-unsent", msg)

    def test_file_transfer_init_output_failure_emits_unsent_peer_event(self):
        network_thread = self._create_network_thread()
        sock = MockSocket()
        conn = PeerConnection(sock=sock, init=PeerInit(target_user="peer", conn_type=ConnectionType.FILE))
        network_thread._conns[sock] = conn
        network_thread._append_file_control_data = Mock(return_value=False)
        msg = FileTransferInit(token=55, is_outgoing=True)
        msg.username = "peer"
        msg.sock = sock
        fake_events = SimpleNamespace(emit_main_thread=Mock())

        with patch.object(slskproto_module, "events", fake_events):
            network_thread._process_file_output(msg)

        fake_events.emit_main_thread.assert_called_once_with("peer-message-unsent", msg)

    def test_file_offset_pack_failure_closes_download_connection(self):
        """A failed file-offset write should not leave the download file socket waiting forever."""

        network_thread = self._create_network_thread()
        sock = MockSocket()
        conn = PeerConnection(sock=sock, init=PeerInit(target_user="peer", conn_type=ConnectionType.FILE))
        network_thread._conns[sock] = conn
        network_thread._pack_network_message = Mock(return_value=None)
        msg = FileOffset(sock=sock, offset=12)

        network_thread._process_file_output(msg)

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._modify_connection_events.assert_not_called()

    def test_file_offset_output_failure_closes_download_connection(self):
        """A rejected file-offset buffer append should close the file connection and trigger cleanup."""

        network_thread = self._create_network_thread()
        sock = MockSocket()
        conn = PeerConnection(sock=sock, init=PeerInit(target_user="peer", conn_type=ConnectionType.FILE))
        network_thread._conns[sock] = conn
        network_thread._append_file_control_data = Mock(return_value=False)
        msg = FileOffset(sock=sock, offset=12)

        network_thread._process_file_output(msg)

        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._modify_connection_events.assert_not_called()

    def test_peer_response_output_failure_emits_lightweight_rollback_event(self):
        """Large peer responses should report only rollback metadata to the main thread on output failure."""

        network_thread = self._create_network_thread()
        msg = SharedFileListResponse()
        msg.username = "peer"
        msg.unsent_rollback_info = ("shared-file-list-request", ("peer", "203.0.113.5", 1234.0, None))
        fake_events = SimpleNamespace(emit_main_thread=Mock())

        with patch.object(slskproto_module, "events", fake_events):
            network_thread._handle_unsent_peer_message(msg)

        fake_events.emit_main_thread.assert_called_once_with(
            "peer-response-unsent", SharedFileListResponse, "peer",
            ("shared-file-list-request", ("peer", "203.0.113.5", 1234.0, None))
        )
        self.assertIsNone(msg.unsent_rollback_info)

    def test_unsent_shared_file_list_request_revokes_response_grant(self):
        """A browse response grant should not survive if the peer request cannot be queued."""

        network_thread = self._create_network_thread()
        init = PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        network_thread._username_init_msgs[("peer", ConnectionType.PEER)] = init
        old_limit = NetworkThread.MAX_PENDING_PEER_MESSAGES_PER_INIT
        NetworkThread.MAX_PENDING_PEER_MESSAGES_PER_INIT = 0
        SHARED_FILE_LIST_USERS_ALLOWED.clear()
        SHARED_FILE_LIST_USERS_ALLOWED.add("peer")

        try:
            network_thread._send_message_to_peer("peer", SharedFileListRequest())
            self.assertNotIn("peer", SHARED_FILE_LIST_USERS_ALLOWED)

        finally:
            NetworkThread.MAX_PENDING_PEER_MESSAGES_PER_INIT = old_limit
            SHARED_FILE_LIST_USERS_ALLOWED.clear()

    def test_peer_output_failure_revokes_user_info_response_grant(self):
        """A profile response grant should be dropped when socket output rejects the request."""

        network_thread = self._create_network_thread()
        sock = MockSocket()
        conn = PeerConnection(sock=sock, init=PeerInit(target_user="peer", conn_type=ConnectionType.PEER))
        network_thread._conns[sock] = conn
        network_thread._append_outgoing_message = Mock(return_value=False)
        msg = UserInfoRequest()
        msg.username = "peer"
        msg.sock = sock
        USER_INFO_USERS_ALLOWED.clear()
        USER_INFO_USERS_ALLOWED.add("peer")

        try:
            network_thread._process_peer_output(msg)
            self.assertNotIn("peer", USER_INFO_USERS_ALLOWED)

        finally:
            USER_INFO_USERS_ALLOWED.clear()

    def test_peer_output_failure_emits_lightweight_request_unsent_event(self):
        """Small peer requests should notify their owner when they die below peer output."""

        network_thread = self._create_network_thread()
        msg = UploadQueueNotification()
        msg.username = "peer"
        fake_events = SimpleNamespace(emit_main_thread=Mock())

        with patch.object(slskproto_module, "events", fake_events):
            network_thread._handle_unsent_peer_message(msg)

        fake_events.emit_main_thread.assert_called_once_with(
            "peer-request-unsent", UploadQueueNotification, "peer", msg
        )

    def test_peer_connection_error_emits_request_unsent_for_browse_request(self):
        """Pre-connection failures should return lightweight retry signals for request owners."""

        network_thread = self._create_network_thread()
        init = PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        request = SharedFileListRequest()
        request.username = "peer"
        init.outgoing_msgs.append(request)
        fake_events = SimpleNamespace(emit_main_thread=Mock())

        with patch.object(slskproto_module, "events", fake_events):
            network_thread._emit_peer_connection_error("peer", ConnectionType.PEER, init)

        calls = fake_events.emit_main_thread.call_args_list
        self.assertEqual("peer-request-unsent", calls[0].args[0])
        self.assertEqual((SharedFileListRequest, "peer", request), calls[0].args[1:])
        self.assertEqual("peer-connection-error", calls[1].args[0])

    def test_peer_connection_error_revokes_unsent_folder_response_grant(self):
        """A folder response token should not survive if its request dies before sending."""

        network_thread = self._create_network_thread()
        init = PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        init.outgoing_msgs.append(FolderContentsRequest("Music", token=123))
        FOLDER_TOKENS_ALLOWED.clear()
        FOLDER_TOKENS_ALLOWED.add(("peer", 123))
        fake_events = SimpleNamespace(emit_main_thread=Mock())

        try:
            with patch.object(slskproto_module, "events", fake_events):
                network_thread._emit_peer_connection_error("peer", ConnectionType.PEER, init)

            self.assertNotIn(("peer", 123), FOLDER_TOKENS_ALLOWED)

        finally:
            FOLDER_TOKENS_ALLOWED.clear()

    def test_clearing_queued_peer_messages_can_revoke_heavy_grants(self):
        """Pre-connection queue cleanup should optionally revoke unsent request grants."""

        network_thread = self._create_network_thread()
        init = PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        init.outgoing_msgs.append(SharedFileListRequest())
        SHARED_FILE_LIST_USERS_ALLOWED.clear()
        SHARED_FILE_LIST_USERS_ALLOWED.add("peer")

        try:
            network_thread._clear_queued_peer_messages(init, revoke_unsent=True)
            self.assertNotIn("peer", SHARED_FILE_LIST_USERS_ALLOWED)
            self.assertFalse(init.outgoing_msgs)

        finally:
            SHARED_FILE_LIST_USERS_ALLOWED.clear()

    def test_direct_peer_init_registration_failure_revokes_grant(self):
        """A cached-address peer request can fail before socket output and must drop its grant."""

        network_thread = self._create_network_thread()
        network_thread._add_init_message = Mock(return_value=False)
        init = PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        init.outgoing_msgs.append(UserInfoRequest())
        USER_INFO_USERS_ALLOWED.clear()
        USER_INFO_USERS_ALLOWED.add("peer")

        try:
            network_thread._connect_to_peer("peer", ("203.0.113.20", 1234), init)
            self.assertNotIn("peer", USER_INFO_USERS_ALLOWED)

        finally:
            USER_INFO_USERS_ALLOWED.clear()

    def test_process_queue_messages_limits_heavy_peer_responses_per_cycle(self):
        """A queue full of heavyweight responses should not be compressed/sent in one cycle."""

        network_thread = self._create_network_thread()
        network_thread._message_queue = deque([
            object.__new__(SharedFileListResponse),
            object.__new__(SharedFileListResponse),
            object.__new__(SharedFileListResponse),
        ])
        network_thread._pending_transfer_network_messages = 0
        network_thread._dropped_network_messages = 0
        network_thread._dropped_transfer_network_messages = 0
        network_thread._process_outgoing_messages = Mock()

        old_limit = NetworkThread.MAX_HEAVY_OUTGOING_MESSAGES_PER_CYCLE
        NetworkThread.MAX_HEAVY_OUTGOING_MESSAGES_PER_CYCLE = 2

        try:
            network_thread._process_queue_messages()

        finally:
            NetworkThread.MAX_HEAVY_OUTGOING_MESSAGES_PER_CYCLE = old_limit

        sent_messages = network_thread._process_outgoing_messages.call_args.args[0]
        self.assertEqual(2, len(sent_messages))
        self.assertEqual(1, len(network_thread._message_queue))

    def test_pending_peer_message_count_released_when_messages_processed(self):
        network_thread = self._create_network_thread()
        network_thread._process_outgoing_messages = Mock()
        init = PeerInit(target_user="user", conn_type=ConnectionType.PEER)
        init.sock = MockSocket()

        self.assertTrue(network_thread._queue_peer_message(init, QueueUpload("first")))
        self.assertEqual(1, network_thread._pending_peer_message_count)

        NetworkThread._process_conn_messages(network_thread, init)

        self.assertEqual(0, network_thread._pending_peer_message_count)
        self.assertEqual([], init.outgoing_msgs)
        network_thread._process_outgoing_messages.assert_called_once()

    def test_pending_peer_message_count_released_when_peer_address_is_offline(self):
        network_thread = self._create_network_thread()
        init = PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        self.assertTrue(network_thread._queue_peer_message(init, QueueUpload("queued")))
        network_thread._pending_init_msgs["peer"].append(init)
        network_thread._requested_peer_addresses.add("peer")
        msg = GetPeerAddress("peer")
        msg.ip_address = "0.0.0.0"
        msg.port = 0

        with patch.object(slskproto_module.NetworkThread, "_unpack_network_message", return_value=msg), \
                patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=Mock())):
            self.assertTrue(network_thread._process_server_message(
                SERVER_MESSAGE_CODES[GetPeerAddress], 0, bytearray(), 0, 0))

        self.assertEqual(0, network_thread._pending_peer_message_count)
        self.assertEqual([], init.outgoing_msgs)

    def test_pending_peer_message_count_released_when_direct_init_is_rejected(self):
        network_thread = self._create_network_thread()
        network_thread._add_init_message = Mock(return_value=False)
        init = PeerInit(target_user="peer", conn_type=ConnectionType.PEER)

        self.assertTrue(network_thread._queue_peer_message(init, QueueUpload("queued")))
        self.assertEqual(1, network_thread._pending_peer_message_count)

        network_thread._connect_to_peer("peer", ("203.0.113.10", 2234), init)

        self.assertEqual(0, network_thread._pending_peer_message_count)
        self.assertEqual([], init.outgoing_msgs)
        network_thread._add_init_message.assert_called_once_with(init)

    def test_pending_peer_message_count_released_when_invalid_direct_address_has_no_indirect_request(self):
        network_thread = self._create_network_thread()
        network_thread._num_sockets = 0
        network_thread._connect_to_peer_indirect = Mock(return_value=None)
        init = PeerInit(target_user="peer", conn_type=ConnectionType.PEER)

        self.assertTrue(network_thread._queue_peer_message(init, QueueUpload("queued")))
        self.assertEqual(1, network_thread._pending_peer_message_count)

        with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=Mock())):
            network_thread._init_peer_connection(("203.0.113.10", 0), init)

        self.assertEqual(0, network_thread._pending_peer_message_count)
        self.assertEqual([], init.outgoing_msgs)

    def test_pending_peer_init_user_queue_is_capped(self):
        network_thread = self._create_network_thread()

        old_limit = NetworkThread.MAX_PENDING_PEER_INIT_USERS
        NetworkThread.MAX_PENDING_PEER_INIT_USERS = 1

        try:
            first_init = PeerInit(target_user="user1", conn_type=ConnectionType.PEER)
            self.assertTrue(network_thread._queue_pending_init_message("user1", first_init))

            second_init = PeerInit(target_user="user2", conn_type=ConnectionType.PEER)
            second_init.outgoing_msgs.append(QueueUpload("queued"))

            fake_events = SimpleNamespace(emit_main_thread=Mock())

            with patch.object(slskproto_module, "events", fake_events):
                self.assertFalse(network_thread._queue_pending_init_message("user2", second_init))

            fake_events.emit_main_thread.assert_called_once()
            self.assertNotIn("user2", network_thread._pending_init_msgs)
            self.assertEqual([], second_init.outgoing_msgs)
        finally:
            NetworkThread.MAX_PENDING_PEER_INIT_USERS = old_limit

    def test_pending_file_inits_share_one_address_request_per_user(self):
        network_thread = self._create_network_thread()
        network_thread._send_message_to_server = Mock()
        network_thread._connect_to_peer = Mock()

        network_thread._initiate_connection_to_peer(
            "user", ConnectionType.FILE, FileTransferInit(token=1))
        network_thread._initiate_connection_to_peer(
            "user", ConnectionType.FILE, FileTransferInit(token=2))

        self.assertEqual(2, len(network_thread._pending_init_msgs["user"]))
        network_thread._send_message_to_server.assert_called_once()
        self.assertIsInstance(network_thread._send_message_to_server.call_args.args[0], GetPeerAddress)

    def test_rejected_peer_address_request_rolls_back_pending_init(self):
        network_thread = self._create_network_thread()
        network_thread._send_message_to_server = Mock(return_value=False)
        network_thread._connect_to_peer = Mock()
        fake_events = SimpleNamespace(emit_main_thread=Mock())

        with patch.object(slskproto_module, "events", fake_events):
            network_thread._initiate_connection_to_peer(
                "user", ConnectionType.PEER, QueueUpload("queued"))

        self.assertNotIn("user", network_thread._pending_init_msgs)
        self.assertEqual(0, network_thread._pending_peer_message_count)
        self.assertEqual(0, network_thread._pending_peer_message_bytes)
        network_thread._send_message_to_server.assert_called_once()
        network_thread._connect_to_peer.assert_not_called()
        fake_events.emit_main_thread.assert_called_once()

    def test_outgoing_peer_address_request_marks_expected_response(self):
        network_thread = self._create_network_thread()
        network_thread._server_conn = PeerConnection(sock=MockSocket())
        network_thread._server_conn.out_buffer = bytearray()
        network_thread._conns = {network_thread._server_conn.sock: network_thread._server_conn}
        network_thread._should_process_queue = True

        network_thread._process_server_output(GetPeerAddress("peer"))

        self.assertIn("peer", network_thread._requested_peer_addresses)

    def test_rejected_server_output_does_not_mark_expected_peer_address(self):
        network_thread = self._create_network_thread()
        network_thread._server_conn = ServerConnection(sock=MockSocket())
        network_thread._append_server_message = Mock(return_value=False)

        network_thread._process_server_output(GetPeerAddress("peer"))

        self.assertFalse(network_thread._requested_peer_addresses)
        network_thread._modify_connection_events.assert_not_called()

    def test_accepted_server_output_marks_expected_peer_address(self):
        network_thread = self._create_network_thread()
        network_thread._server_conn = ServerConnection(sock=MockSocket())
        network_thread._append_server_message = Mock(return_value=True)

        network_thread._process_server_output(GetPeerAddress("peer"))

        self.assertEqual({"peer"}, network_thread._requested_peer_addresses)
        network_thread._modify_connection_events.assert_called_once()

    def test_unsolicited_peer_address_response_is_ignored(self):
        network_thread = self._create_network_thread()
        network_thread._user_addresses = {"peer": None}
        network_thread._connect_to_peer = Mock()
        msg = GetPeerAddress("peer")
        msg.ip_address = "203.0.113.10"
        msg.port = 2234

        fake_log = SimpleNamespace(add_conn=Mock())

        with patch.object(slskproto_module.NetworkThread, "_unpack_network_message", return_value=msg), \
                patch.object(slskproto_module, "log", fake_log):
            self.assertTrue(network_thread._process_server_message(
                SERVER_MESSAGE_CODES[GetPeerAddress], 0, bytearray(), 0, 0))

        self.assertEqual({"peer": None}, network_thread._user_addresses)
        network_thread._connect_to_peer.assert_not_called()
        network_thread._emit_network_message_event.assert_not_called()
        self.assertFalse(network_thread._requested_peer_addresses)

    def test_requested_peer_address_response_updates_cache_and_emits(self):
        network_thread = self._create_network_thread()
        network_thread._requested_peer_addresses.add("peer")
        network_thread._user_addresses = {"peer": None}
        network_thread._connect_to_peer = Mock()
        msg = GetPeerAddress("peer")
        msg.ip_address = "203.0.113.10"
        msg.port = 2234

        with patch.object(slskproto_module.NetworkThread, "_unpack_network_message", return_value=msg):
            self.assertTrue(network_thread._process_server_message(
                SERVER_MESSAGE_CODES[GetPeerAddress], 0, bytearray(), 0, 0))

        self.assertEqual({"peer": ("203.0.113.10", 2234)}, network_thread._user_addresses)
        network_thread._connect_to_peer.assert_not_called()
        network_thread._emit_network_message_event.assert_called_once_with(msg)
        self.assertFalse(network_thread._requested_peer_addresses)

    def test_pending_peer_init_allows_peer_address_response_without_marker(self):
        network_thread = self._create_network_thread()
        network_thread._connect_to_peer = Mock()
        init = PeerInit(target_user="peer", conn_type=ConnectionType.PEER)
        network_thread._pending_init_msgs["peer"].append(init)
        msg = GetPeerAddress("peer")
        msg.ip_address = "203.0.113.10"
        msg.port = 2234

        with patch.object(slskproto_module.NetworkThread, "_unpack_network_message", return_value=msg):
            self.assertTrue(network_thread._process_server_message(
                SERVER_MESSAGE_CODES[GetPeerAddress], 0, bytearray(), 0, 0))

        network_thread._connect_to_peer.assert_called_once_with("peer", ("203.0.113.10", 2234), init)
        self.assertNotIn("peer", network_thread._pending_init_msgs)

    def test_pending_peer_connections_are_capped_under_socket_pressure(self):
        network_thread = self._create_network_thread()
        network_thread._num_sockets = NetworkThread.MAX_SOCKETS
        network_thread._pending_peer_conns = {("existing",): object()}
        addr = ("203.0.113.12", 2234)
        init = PeerInit(target_user="user", conn_type=ConnectionType.PEER)
        init.outgoing_msgs.append(QueueUpload("queued"))

        old_limit = NetworkThread.MAX_PENDING_PEER_CONNECTIONS
        NetworkThread.MAX_PENDING_PEER_CONNECTIONS = 1

        try:
            fake_events = SimpleNamespace(emit_main_thread=Mock())

            with patch.object(slskproto_module, "events", fake_events):
                network_thread._init_peer_connection(addr, init)

            fake_events.emit_main_thread.assert_called_once()
            self.assertEqual(1, len(network_thread._pending_peer_conns))
            self.assertEqual([], init.outgoing_msgs)
        finally:
            NetworkThread.MAX_PENDING_PEER_CONNECTIONS = old_limit

    def test_pending_indirect_requests_are_capped(self):
        network_thread = self._create_network_thread()
        init = PeerInit(target_user="user", conn_type=ConnectionType.PEER)
        network_thread._token_init_msgs = {123: (init, 0)}

        old_limit = NetworkThread.MAX_PENDING_INDIRECT_REQUESTS
        NetworkThread.MAX_PENDING_INDIRECT_REQUESTS = 1

        try:
            self.assertIsNone(network_thread._connect_to_peer_indirect(init))
        finally:
            NetworkThread.MAX_PENDING_INDIRECT_REQUESTS = old_limit

        network_thread._send_message_to_server.assert_not_called()
        self.assertEqual({123}, set(network_thread._token_init_msgs))

    def test_rejected_indirect_request_does_not_store_token(self):
        network_thread = self._create_network_thread()
        network_thread._send_message_to_server = Mock(return_value=False)
        init = PeerInit(target_user="user", conn_type=ConnectionType.PEER)

        self.assertIsNone(network_thread._connect_to_peer_indirect(init))

        network_thread._send_message_to_server.assert_called_once()
        self.assertFalse(network_thread._token_init_msgs)

    def test_accepted_indirect_request_stores_token(self):
        network_thread = self._create_network_thread()
        network_thread._send_message_to_server = Mock(return_value=True)
        init = PeerInit(target_user="user", conn_type=ConnectionType.PEER)

        token = network_thread._connect_to_peer_indirect(init)

        self.assertIsNotNone(token)
        self.assertEqual((init, network_thread._token_init_msgs[token][1]), network_thread._token_init_msgs[token])
        network_thread._send_message_to_server.assert_called_once()

    def test_invalid_indirect_response_port_sends_cant_connect_and_removes_init(self):
        network_thread = self._create_network_thread()
        network_thread._pending_peer_conns = {}
        network_thread._num_sockets = 0
        network_thread._connect_to_peer_indirect = Mock()
        network_thread._send_message_to_server = Mock()
        init = PeerInit(target_user="user", conn_type=ConnectionType.PEER)
        init_key = network_thread._get_init_key("user", ConnectionType.PEER)
        network_thread._username_init_msgs[init_key] = init

        network_thread._init_peer_connection(("203.0.113.12", 0), init, response_token=404)

        network_thread._connect_to_peer_indirect.assert_not_called()
        msg = network_thread._send_message_to_server.call_args.args[0]
        self.assertIsInstance(msg, CantConnectToPeer)
        self.assertEqual(404, msg.token)
        self.assertEqual("user", msg.user)
        self.assertNotIn(init_key, network_thread._username_init_msgs)

    def test_indirect_response_socket_creation_failure_sends_cant_connect_and_removes_init(self):
        network_thread = self._create_network_thread()
        network_thread._selector = Mock()
        network_thread._num_sockets = 0
        network_thread._interface_name = None
        network_thread._interface_address = None
        network_thread._connect_to_peer_indirect = Mock()
        init = PeerInit(target_user="user", conn_type=ConnectionType.PEER)
        init_key = network_thread._get_init_key("user", ConnectionType.PEER)
        network_thread._username_init_msgs[init_key] = init

        with patch.object(slskproto_module.socket, "socket", side_effect=OSError("too many open files")):
            network_thread._init_peer_connection(("203.0.113.12", 2234), init, response_token=405)

        msg = network_thread._send_message_to_server.call_args.args[0]
        self.assertIsInstance(msg, CantConnectToPeer)
        self.assertEqual(405, msg.token)
        self.assertNotIn(init_key, network_thread._username_init_msgs)
        self.assertEqual({}, network_thread._conns)
        self.assertIsNone(init.sock)

    def test_indirect_response_selector_register_failure_closes_socket_and_removes_init(self):
        network_thread = self._create_network_thread()
        network_thread._selector = Mock()
        network_thread._selector.register.side_effect = OSError("register failed")
        network_thread._num_sockets = 0
        network_thread._interface_name = None
        network_thread._interface_address = None
        network_thread._connect_to_peer_indirect = Mock()
        network_thread._close_socket = Mock()
        sock = MockSocket()
        init = PeerInit(target_user="user", conn_type=ConnectionType.PEER)
        init_key = network_thread._get_init_key("user", ConnectionType.PEER)
        network_thread._username_init_msgs[init_key] = init

        with patch.object(slskproto_module.socket, "socket", return_value=sock):
            network_thread._init_peer_connection(("203.0.113.12", 2234), init, response_token=406)

        msg = network_thread._send_message_to_server.call_args.args[0]
        self.assertIsInstance(msg, CantConnectToPeer)
        self.assertEqual(406, msg.token)
        self.assertNotIn(init_key, network_thread._username_init_msgs)
        self.assertNotIn(sock, network_thread._conns)
        self.assertIsNone(init.sock)
        network_thread._close_socket.assert_called_once_with(sock)

    def test_server_socket_creation_failure_disconnects_cleanly(self):
        network_thread = object.__new__(NetworkThread)
        network_thread._selector = Mock()
        network_thread._num_sockets = 0
        network_thread._conns = {}
        network_thread._server_conn = None
        network_thread._interface_name = None
        network_thread._interface_address = None
        network_thread._set_server_timer = Mock()
        network_thread._server_disconnect = Mock()
        msg = SimpleNamespace(addr=("203.0.113.20", 2242), login=("user", "pass"))

        with patch.object(slskproto_module.socket, "socket", side_effect=OSError("too many open files")):
            network_thread._init_server_conn(msg)

        network_thread._set_server_timer.assert_called_once()
        network_thread._server_disconnect.assert_called_once()
        self.assertEqual({}, network_thread._conns)
        self.assertEqual(0, network_thread._num_sockets)

    def test_listen_socket_creation_failure_does_not_leak_socket_count(self):
        network_thread = object.__new__(NetworkThread)
        network_thread._selector = Mock()
        network_thread._listen_socket = None
        network_thread._listen_port = 2234
        network_thread._num_sockets = 0
        network_thread._set_server_timer = Mock()

        with patch.object(slskproto_module.socket, "socket", side_effect=OSError("too many open files")):
            self.assertFalse(network_thread._create_listen_socket())

        network_thread._set_server_timer.assert_called_once_with(use_fixed_timeout=True)
        self.assertIsNone(network_thread._listen_socket)
        self.assertEqual(0, network_thread._num_sockets)

    def test_file_transfer_init_waits_for_complete_token(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.FILE)
        )
        msg_content = bytearray(FileTransferInit(token=123).make_network_message())

        self.assertEqual(0, network_thread._process_file_init_message(conn, msg_content[:2]))
        self.assertNotIn(conn, network_thread._file_init_msgs)
        network_thread._emit_network_message_event.assert_not_called()

        self.assertEqual(4, network_thread._process_file_init_message(conn, msg_content))
        self.assertEqual(123, network_thread._file_init_msgs[conn].token)

    def test_file_transfer_init_is_registered_after_output_is_queued(self):
        network_thread = self._create_network_thread()
        sock = MockSocket()
        conn = PeerConnection(
            sock=sock,
            init=PeerInit(target_user="user", conn_type=ConnectionType.FILE)
        )
        network_thread._conns[sock] = conn
        network_thread._append_file_control_data = Mock(return_value=False)
        network_thread._handle_unsent_peer_message = Mock()
        msg = FileTransferInit(token=123)
        msg.sock = sock

        network_thread._process_file_output(msg)

        self.assertNotIn(conn, network_thread._file_init_msgs)
        network_thread._handle_unsent_peer_message.assert_called_once_with(msg)
        network_thread._emit_network_message_event.assert_not_called()

    def test_unattached_download_file_handoff_closes_file_and_emits_lifecycle_event(self):
        network_thread = self._create_network_thread()
        sock = MockSocket()
        file_handle = Mock()
        emit_main_thread = Mock()
        msg = DownloadFile(sock=sock, token=456, file=file_handle, leftbytes=1024, username="user")

        with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
            network_thread._process_internal_messages(msg)

        file_handle.close.assert_called_once_with()
        emit_main_thread.assert_called_once_with(
            "file-connection-closed", username="user", token=456, sock=sock, timed_out=False
        )
        self.assertFalse(network_thread._file_download_msgs)
        self.assertEqual(0, network_thread._total_downloads)

    def test_unattached_upload_file_handoff_closes_file_and_emits_lifecycle_event(self):
        network_thread = self._create_network_thread()
        sock = MockSocket()
        file_handle = Mock()
        emit_main_thread = Mock()
        msg = UploadFile(sock=sock, token=789, file=file_handle, size=1024, username="user")

        with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
            network_thread._process_internal_messages(msg)

        file_handle.close.assert_called_once_with()
        emit_main_thread.assert_called_once_with(
            "file-connection-closed", username="user", token=789, sock=sock, timed_out=False
        )
        self.assertFalse(network_thread._file_upload_msgs)
        self.assertEqual(0, network_thread._total_uploads)

    def test_file_offset_waits_for_complete_offset(self):
        class MockFile:
            def __init__(self):
                self.offsets = []

            def seek(self, offset):
                self.offsets.append(offset)

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.FILE)
        )
        file_handle = MockFile()
        file_upload = UploadFile(token=456, file=file_handle, size=100, offset=None)
        network_thread._file_upload_msgs[conn] = file_upload
        msg_content = bytearray(FileOffset(offset=12).make_network_message())

        self.assertEqual(0, network_thread._process_file_offset_message(conn, msg_content[:4]))
        self.assertIsNone(file_upload.offset)
        self.assertEqual([], file_handle.offsets)

        with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=Mock())):
            self.assertEqual(8, network_thread._process_file_offset_message(conn, msg_content))

        self.assertEqual(12, file_upload.offset)
        self.assertEqual([12], file_handle.offsets)

    def test_file_offset_larger_than_upload_size_closes_connection(self):
        class MockFile:
            @staticmethod
            def seek(_offset):
                raise AssertionError("invalid offsets should be rejected before seeking")

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.FILE)
        )
        file_upload = UploadFile(token=456, file=MockFile(), size=100, offset=None)
        network_thread._file_upload_msgs[conn] = file_upload
        msg_content = bytearray(FileOffset(offset=101).make_network_message())
        emit_main_thread = Mock()

        with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
            self.assertIsNone(network_thread._process_file_offset_message(conn, msg_content))

        self.assertIsNone(file_upload.offset)
        network_thread._close_connection.assert_called_once_with(conn)
        self.assertEqual(("upload-file-error",), emit_main_thread.call_args.args)
        self.assertEqual("user", emit_main_thread.call_args.kwargs["username"])
        self.assertEqual(456, emit_main_thread.call_args.kwargs["token"])
        self.assertIsInstance(emit_main_thread.call_args.kwargs["error"], ValueError)

    def test_user_info_message_size_limit_closes_connection_before_full_body(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=MockSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.PEER)
        )
        old_max_size = UserInfoResponse.MAX_INCOMING_MESSAGE_SIZE
        UserInfoResponse.MAX_INCOMING_MESSAGE_SIZE = 8

        try:
            conn.in_buffer = bytearray(
                UserInfoResponse.pack_uint32(9)
                + UserInfoResponse.pack_uint32(PEER_MESSAGE_CODES[UserInfoResponse])
            )

            network_thread._process_peer_input(conn)

            network_thread._close_connection.assert_called_once_with(conn)
            network_thread._emit_network_message_event.assert_not_called()

        finally:
            UserInfoResponse.MAX_INCOMING_MESSAGE_SIZE = old_max_size

    def test_recv_size_growth_is_capped(self):
        class RecvSocket(MockSocket):
            def recv(self, _bufsize):
                return b"x" * NetworkThread.MAX_SOCKET_RECV_SIZE

        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=RecvSocket())
        conn.recv_size = NetworkThread.MAX_SOCKET_RECV_SIZE

        self.assertTrue(network_thread._read_data(conn, current_time=1))
        self.assertEqual(NetworkThread.MAX_SOCKET_RECV_SIZE, conn.recv_size)

    def test_recv_size_shrink_keeps_minimum(self):
        class RecvSocket(MockSocket):
            def recv(self, _bufsize):
                return b"x"

        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=RecvSocket())
        conn.recv_size = NetworkThread.MIN_SOCKET_RECV_SIZE

        self.assertTrue(network_thread._read_data(conn, current_time=1))
        self.assertEqual(NetworkThread.MIN_SOCKET_RECV_SIZE, conn.recv_size)

    def test_download_speed_limit_exhaustion_waits_without_recv_zero(self):
        class RecvSocket(MockSocket):
            def recv(self, _bufsize):
                raise AssertionError("recv() should not be called when the per-cycle quota is exhausted")

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=RecvSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.FILE)
        )
        network_thread._file_download_msgs[conn] = DownloadFile(leftbytes=1000)
        network_thread._download_limit_split = 1024
        network_thread._conns_downloaded[conn] = 1024

        self.assertTrue(network_thread._read_data(conn, current_time=1))
        self.assertEqual(1000, network_thread._file_download_msgs[conn].leftbytes)

    def test_file_download_recv_size_is_limited_by_cycle_budget(self):
        """Many ready downloads should not write unlimited bytes in one network cycle."""

        class RecvSocket(MockSocket):
            recv_sizes = []

            def recv(self, bufsize):
                self.recv_sizes.append(bufsize)
                return b"x" * bufsize

        class MockFile:
            def __init__(self):
                self.writes = []

            def write(self, data):
                self.writes.append(bytes(data))

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=RecvSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.FILE)
        )
        file_handle = MockFile()
        network_thread._file_download_msgs[conn] = DownloadFile(file=file_handle, leftbytes=1000)
        network_thread._file_download_cycle_bytes = 8

        old_limit = NetworkThread.MAX_FILE_DOWNLOAD_WRITE_BYTES_PER_CYCLE
        NetworkThread.MAX_FILE_DOWNLOAD_WRITE_BYTES_PER_CYCLE = 10

        try:
            conn.recv_size = 100
            self.assertTrue(network_thread._read_data(conn, current_time=1))

        finally:
            NetworkThread.MAX_FILE_DOWNLOAD_WRITE_BYTES_PER_CYCLE = old_limit

        self.assertEqual([2], conn.sock.recv_sizes)
        self.assertEqual([b"xx"], file_handle.writes)
        self.assertEqual(10, network_thread._file_download_cycle_bytes)
        self.assertEqual(998, network_thread._file_download_msgs[conn].leftbytes)

    def test_file_download_cycle_budget_exhaustion_waits_without_recv_zero(self):
        """Avoid recv(0) and let the next network cycle resume file downloads."""

        class RecvSocket(MockSocket):
            def recv(self, _bufsize):
                raise AssertionError("recv() should not be called when the file-download cycle budget is exhausted")

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=RecvSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.FILE)
        )
        network_thread._file_download_msgs[conn] = DownloadFile(file=Mock(), leftbytes=1000)
        network_thread._file_download_cycle_bytes = 10

        old_limit = NetworkThread.MAX_FILE_DOWNLOAD_WRITE_BYTES_PER_CYCLE
        NetworkThread.MAX_FILE_DOWNLOAD_WRITE_BYTES_PER_CYCLE = 10

        try:
            self.assertTrue(network_thread._read_data(conn, current_time=1))

        finally:
            NetworkThread.MAX_FILE_DOWNLOAD_WRITE_BYTES_PER_CYCLE = old_limit

        self.assertEqual(1000, network_thread._file_download_msgs[conn].leftbytes)

    def test_file_download_recv_size_is_limited_by_remaining_bytes(self):
        """Do not read a full socket buffer when the transfer is about to finish."""

        class RecvSocket(MockSocket):
            recv_sizes = []

            def recv(self, bufsize):
                self.recv_sizes.append(bufsize)
                return b"x" * bufsize

        class MockFile:
            def write(self, _data):
                return None

        network_thread = self._create_network_thread()
        conn = PeerConnection(
            sock=RecvSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.FILE)
        )
        network_thread._file_download_msgs[conn] = DownloadFile(file=MockFile(), leftbytes=3)
        conn.recv_size = 100

        self.assertFalse(network_thread._read_data(conn, current_time=1))
        self.assertEqual([3], conn.sock.recv_sizes)
        self.assertEqual(3, network_thread._file_download_cycle_bytes)
        self.assertEqual(0, network_thread._file_download_msgs[conn].leftbytes)

    def test_upload_speed_limit_exhaustion_waits_without_send_zero(self):
        class SendSocket(MockSocket):
            def send(self, _data):
                raise AssertionError("send() should not be called when the per-cycle quota is exhausted")

        network_thread = self._create_network_thread()
        network_thread._process_upload = Mock()
        conn = PeerConnection(
            sock=SendSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.FILE)
        )
        conn.out_buffer = bytearray(b"x" * 128)
        network_thread._file_upload_msgs[conn] = UploadFile(size=1000, offset=0)
        network_thread._upload_limit_split = 64
        network_thread._conns_uploaded[conn] = 64

        self.assertTrue(network_thread._write_data(conn, current_time=1))
        self.assertEqual(bytearray(b"x" * 128), conn.out_buffer)
        network_thread._process_upload.assert_not_called()
        network_thread._modify_connection_events.assert_not_called()

    def test_upload_speed_limit_negative_quota_waits_without_negative_slice(self):
        class SendSocket(MockSocket):
            def send(self, _data):
                raise AssertionError("send() should not be called for negative remaining quota")

        network_thread = self._create_network_thread()
        network_thread._process_upload = Mock()
        conn = PeerConnection(
            sock=SendSocket(),
            init=PeerInit(target_user="user", conn_type=ConnectionType.FILE)
        )
        conn.out_buffer = bytearray(b"x" * 128)
        network_thread._file_upload_msgs[conn] = UploadFile(size=1000, offset=0)
        network_thread._upload_limit_split = 64
        network_thread._conns_uploaded[conn] = 65

        self.assertTrue(network_thread._write_data(conn, current_time=1))
        self.assertEqual(bytearray(b"x" * 128), conn.out_buffer)
        network_thread._process_upload.assert_not_called()

    def test_write_data_rejects_zero_byte_send(self):
        class SendSocket(MockSocket):
            def send(self, _data):
                return 0

        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=SendSocket())
        conn.out_buffer = bytearray(b"payload")

        with self.assertRaises(OSError):
            network_thread._write_data(conn, current_time=1)

        self.assertEqual(bytearray(b"payload"), conn.out_buffer)
        network_thread._modify_connection_events.assert_not_called()

    def test_file_upload_read_ahead_is_capped(self):
        class MockFile:
            def __init__(self):
                self.read_sizes = []

            def read(self, size=-1):
                self.read_sizes.append(size)
                return b"x" * size

        network_thread = self._create_network_thread()
        conn = PeerConnection(init=PeerInit(target_user="user", conn_type=ConnectionType.FILE))
        conn.last_active = 1

        file_handle = MockFile()
        num_sent_bytes = NetworkThread.MAX_FILE_UPLOAD_BUFFER_SIZE * 4
        file_upload = UploadFile(file=file_handle, size=num_sent_bytes * 10, offset=0)

        network_thread._file_upload_msgs[conn] = file_upload
        network_thread._process_upload(conn, num_sent_bytes=num_sent_bytes, current_time=2)

        self.assertEqual([NetworkThread.MAX_FILE_UPLOAD_BUFFER_SIZE], file_handle.read_sizes)
        self.assertEqual(NetworkThread.MAX_FILE_UPLOAD_BUFFER_SIZE, conn.file_upload_buffer_tracked_size)
        self.assertEqual(NetworkThread.MAX_FILE_UPLOAD_BUFFER_SIZE, network_thread._file_upload_buffer_bytes)

    def test_file_upload_read_ahead_respects_aggregate_budget(self):
        class MockFile:
            def __init__(self):
                self.read_sizes = []

            def read(self, size=-1):
                self.read_sizes.append(size)
                return b"x" * size

        network_thread = self._create_network_thread()
        conn = PeerConnection(init=PeerInit(target_user="user", conn_type=ConnectionType.FILE))
        conn.last_active = 1
        file_handle = MockFile()
        file_upload = UploadFile(file=file_handle, size=1000, offset=0)
        network_thread._file_upload_msgs[conn] = file_upload

        old_limit = NetworkThread.MAX_FILE_UPLOAD_BUFFER_BYTES
        NetworkThread.MAX_FILE_UPLOAD_BUFFER_BYTES = 16
        network_thread._file_upload_buffer_bytes = 12

        try:
            self.assertTrue(network_thread._process_upload(conn, num_sent_bytes=128, current_time=2))

        finally:
            NetworkThread.MAX_FILE_UPLOAD_BUFFER_BYTES = old_limit

        self.assertEqual([4], file_handle.read_sizes)
        self.assertEqual(bytearray(b"xxxx"), conn.out_buffer)
        self.assertEqual(4, conn.file_upload_buffer_tracked_size)
        self.assertEqual(16, network_thread._file_upload_buffer_bytes)

    def test_file_upload_buffer_budget_rejects_excess_data(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(init=PeerInit(target_user="user", conn_type=ConnectionType.FILE))
        network_thread._file_upload_buffer_bytes = 9

        old_limit = NetworkThread.MAX_FILE_UPLOAD_BUFFER_BYTES
        NetworkThread.MAX_FILE_UPLOAD_BUFFER_BYTES = 10

        try:
            fake_log = SimpleNamespace(add_conn=Mock())

            with patch.object(slskproto_module, "log", fake_log):
                self.assertFalse(network_thread._append_file_upload_data(conn, b"xx"))

        finally:
            NetworkThread.MAX_FILE_UPLOAD_BUFFER_BYTES = old_limit

        self.assertFalse(conn.out_buffer)
        self.assertEqual(0, conn.file_upload_buffer_tracked_size)
        self.assertEqual(9, network_thread._file_upload_buffer_bytes)
        fake_log.add_conn.assert_called_once()

    def test_file_upload_aggregate_budget_exhaustion_is_reported_as_error(self):
        class MockFile:
            read = Mock(return_value=b"x")

        network_thread = self._create_network_thread()
        conn = PeerConnection(init=PeerInit(target_user="user", conn_type=ConnectionType.FILE))
        conn.last_active = 1

        old_limit = NetworkThread.MAX_FILE_UPLOAD_BUFFER_BYTES
        NetworkThread.MAX_FILE_UPLOAD_BUFFER_BYTES = 10

        file_upload = UploadFile(token=506, file=MockFile(), size=1000, offset=0)
        network_thread._file_upload_buffer_bytes = 10
        network_thread._file_upload_msgs[conn] = file_upload
        emit_main_thread = Mock()

        try:
            with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
                self.assertFalse(network_thread._process_upload(conn, num_sent_bytes=100, current_time=2))

        finally:
            NetworkThread.MAX_FILE_UPLOAD_BUFFER_BYTES = old_limit

        file_upload.file.read.assert_not_called()
        self.assertEqual(("upload-file-error",), emit_main_thread.call_args.args)
        self.assertEqual("user", emit_main_thread.call_args.kwargs["username"])
        self.assertEqual(506, emit_main_thread.call_args.kwargs["token"])
        self.assertIsInstance(emit_main_thread.call_args.kwargs["error"], OSError)

    def test_file_upload_buffer_budget_tracks_send_and_close_release(self):
        """Sent upload read-ahead and closed sockets should release the aggregate upload budget."""

        network_thread = self._create_network_thread()
        sock = MockSocket()
        sock.send = Mock(return_value=3)
        conn = PeerConnection(
            sock=sock,
            init=PeerInit(target_user="peer", conn_type=ConnectionType.FILE)
        )
        conn.out_buffer = bytearray(b"abcdef")
        conn.file_upload_buffer_tracked_size = 6
        network_thread._file_upload_buffer_bytes = 6
        network_thread._file_upload_msgs[conn] = UploadFile(size=1000, offset=0)
        network_thread._process_upload = Mock(return_value=True)

        self.assertTrue(network_thread._write_data(conn, current_time=123))

        self.assertEqual(bytearray(b"def"), conn.out_buffer)
        self.assertEqual(3, conn.file_upload_buffer_tracked_size)
        self.assertEqual(3, network_thread._file_upload_buffer_bytes)
        network_thread._process_upload.assert_called_once_with(conn, 3, 123)

        network_thread._clear_file_upload_buffer(conn)

        self.assertEqual(0, conn.file_upload_buffer_tracked_size)
        self.assertEqual(0, network_thread._file_upload_buffer_bytes)

    def test_file_upload_empty_read_is_reported_as_error(self):
        class MockFile:
            @staticmethod
            def read(_size=-1):
                return b""

        network_thread = self._create_network_thread()
        conn = PeerConnection(init=PeerInit(target_user="user", conn_type=ConnectionType.FILE))
        conn.last_active = 1
        file_upload = UploadFile(token=505, file=MockFile(), size=1000, offset=0)
        network_thread._file_upload_msgs[conn] = file_upload
        emit_main_thread = Mock()

        with patch.object(slskproto_module, "events", SimpleNamespace(emit_main_thread=emit_main_thread)):
            self.assertFalse(network_thread._process_upload(conn, num_sent_bytes=1, current_time=2))

        self.assertEqual(("upload-file-error",), emit_main_thread.call_args.args)
        self.assertEqual("user", emit_main_thread.call_args.kwargs["username"])
        self.assertEqual(505, emit_main_thread.call_args.kwargs["token"])
        self.assertIsInstance(emit_main_thread.call_args.kwargs["error"], OSError)

    def test_malformed_embedded_distributed_message_is_ignored(self):
        msg = DistribEmbeddedMessage(
            distrib_code=DISTRIBUTED_MESSAGE_CODES[DistribSearch],
            distrib_message=b"\x00"
        )

        self.assertIsNone(NetworkThread._unpack_embedded_message(msg))

    def test_oversized_embedded_distributed_message_is_ignored(self):
        old_max_size = DistribSearch.MAX_INCOMING_MESSAGE_SIZE
        DistribSearch.MAX_INCOMING_MESSAGE_SIZE = 2

        try:
            msg = DistribEmbeddedMessage(
                distrib_code=DISTRIBUTED_MESSAGE_CODES[DistribSearch],
                distrib_message=b"xx"
            )

            self.assertIsNone(NetworkThread._unpack_embedded_message(msg))

        finally:
            DistribSearch.MAX_INCOMING_MESSAGE_SIZE = old_max_size

    def test_maximum_distributed_branch_level_is_rejected_before_forwarding(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket(), init=PeerInit(init_user="parent", conn_type=ConnectionType.DISTRIBUTED))
        conn.init = SimpleNamespace(target_user="parent")
        network_thread._parent_conn = conn
        network_thread._potential_parents = {}
        network_thread._is_server_parent = False
        network_thread._branch_level = 0
        network_thread._child_peers = {}
        network_thread._max_distrib_children = 0
        network_thread._send_message_to_child_peers = Mock()
        payload = DistribBranchLevel.pack_int32(0x7fffffff)

        self.assertFalse(network_thread._process_distrib_message(
            conn, DISTRIBUTED_MESSAGE_CODES[DistribBranchLevel], len(payload) + 1, payload, 0, len(payload)))

        network_thread._send_message_to_server.assert_not_called()
        network_thread._send_message_to_child_peers.assert_not_called()
        network_thread._emit_network_message_event.assert_not_called()

    def test_potential_distributed_parent_adoption_requires_server_output(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket(), init=PeerInit(init_user="parent", conn_type=ConnectionType.DISTRIBUTED))
        conn.init = SimpleNamespace(target_user="parent")
        network_thread._parent_conn = None
        network_thread._potential_parents = {"parent": conn}
        network_thread._is_server_parent = True
        network_thread._branch_level = 9
        network_thread._branch_root = "oldroot"
        network_thread._child_peers = {}
        network_thread._max_distrib_children = 2
        network_thread._send_message_to_child_peers = Mock()
        network_thread._send_message_to_server = Mock(side_effect=[True, False])
        payload = DistribBranchLevel.pack_int32(0)

        self.assertFalse(network_thread._process_distrib_message(
            conn, DISTRIBUTED_MESSAGE_CODES[DistribBranchLevel], len(payload), payload, 0, len(payload)))

        self.assertIsNone(network_thread._parent_conn)
        self.assertEqual(9, network_thread._branch_level)
        self.assertEqual("oldroot", network_thread._branch_root)
        self.assertTrue(network_thread._is_server_parent)
        network_thread._send_message_to_child_peers.assert_not_called()
        network_thread._emit_network_message_event.assert_not_called()

    def test_parent_branch_level_update_requires_server_output_before_state_change(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket(), init=PeerInit(init_user="parent", conn_type=ConnectionType.DISTRIBUTED))
        conn.init = SimpleNamespace(target_user="parent")
        network_thread._parent_conn = conn
        network_thread._potential_parents = {}
        network_thread._branch_level = 4
        network_thread._branch_root = "root"
        network_thread._child_peers = {}
        network_thread._send_message_to_child_peers = Mock()
        network_thread._send_message_to_server = Mock(return_value=False)
        payload = DistribBranchLevel.pack_int32(1)

        self.assertFalse(network_thread._process_distrib_message(
            conn, DISTRIBUTED_MESSAGE_CODES[DistribBranchLevel], len(payload), payload, 0, len(payload)))

        self.assertEqual(4, network_thread._branch_level)
        network_thread._send_message_to_child_peers.assert_not_called()
        network_thread._emit_network_message_event.assert_not_called()

    def test_parent_branch_root_update_requires_server_output_before_state_change(self):
        network_thread = self._create_network_thread()
        conn = PeerConnection(sock=MockSocket(), init=PeerInit(init_user="parent", conn_type=ConnectionType.DISTRIBUTED))
        conn.init = SimpleNamespace(target_user="parent")
        network_thread._parent_conn = conn
        network_thread._potential_parents = {}
        network_thread._branch_root = "oldroot"
        network_thread._send_message_to_child_peers = Mock()
        network_thread._send_message_to_server = Mock(return_value=False)
        payload = DistribBranchRoot("newroot").make_network_message()

        self.assertFalse(network_thread._process_distrib_message(
            conn, DISTRIBUTED_MESSAGE_CODES[DistribBranchRoot], len(payload), payload, 0, len(payload)))

        self.assertEqual("oldroot", network_thread._branch_root)
        network_thread._send_message_to_child_peers.assert_not_called()
        network_thread._emit_network_message_event.assert_not_called()

    def test_distributed_child_adoption_requires_initial_branch_output(self):
        network_thread = self._create_network_thread()
        sock = MockSocket()
        conn = PeerConnection(
            sock=sock, init=PeerInit(target_user="child", conn_type=ConnectionType.DISTRIBUTED)
        )
        network_thread._conns[sock] = conn
        network_thread._potential_parents = {}
        network_thread._parent_conn = None
        network_thread._is_server_parent = True
        network_thread._branch_level = 2
        network_thread._child_peers = {}
        network_thread._max_distrib_children = 1
        network_thread._send_distributed_message_to_connection = Mock(return_value=False)

        NetworkThread._accept_child_peer_connection(network_thread, conn)

        self.assertNotIn("child", network_thread._child_peers)
        network_thread._close_connection.assert_called_once_with(conn)
        network_thread._send_message_to_server.assert_not_called()

    def test_distributed_child_adoption_sends_branch_state_before_retaining_child(self):
        network_thread = self._create_network_thread()
        sock = MockSocket()
        conn = PeerConnection(
            sock=sock, init=PeerInit(target_user="child", conn_type=ConnectionType.DISTRIBUTED)
        )
        network_thread._conns[sock] = conn
        network_thread._potential_parents = {}
        network_thread._parent_conn = PeerConnection(
            sock=MockSocket(), init=PeerInit(target_user="parent", conn_type=ConnectionType.DISTRIBUTED)
        )
        network_thread._is_server_parent = False
        network_thread._branch_level = 2
        network_thread._branch_root = "root"
        network_thread._child_peers = {}
        network_thread._max_distrib_children = 3
        sent_messages = []

        def send_branch(_conn, msg):
            sent_messages.append(msg)
            self.assertNotIn("child", network_thread._child_peers)
            return True

        network_thread._send_distributed_message_to_connection = Mock(side_effect=send_branch)

        NetworkThread._accept_child_peer_connection(network_thread, conn)

        self.assertIs(conn, network_thread._child_peers["child"])
        self.assertEqual([DistribBranchLevel, DistribBranchRoot], [msg.__class__ for msg in sent_messages])
        network_thread._close_connection.assert_not_called()

    def test_child_peer_fanout_closes_connection_on_lower_output_failure(self):
        network_thread = self._create_network_thread()
        good_conn = PeerConnection(sock=MockSocket(), init=PeerInit(target_user="good", conn_type=ConnectionType.DISTRIBUTED))
        bad_conn = PeerConnection(sock=MockSocket(), init=PeerInit(target_user="bad", conn_type=ConnectionType.DISTRIBUTED))
        network_thread._child_peers = {"good": good_conn, "bad": bad_conn}
        network_thread._send_distributed_message_to_connection = Mock(side_effect=[True, False])

        network_thread._send_message_to_child_peers(DistribBranchLevel(3))

        network_thread._close_connection.assert_called_once_with(bad_conn)

    def test_queued_distributed_message_closes_connection_on_lower_output_failure(self):
        network_thread = self._create_network_thread()
        sock = MockSocket()
        conn = PeerConnection(
            sock=sock, init=PeerInit(target_user="child", conn_type=ConnectionType.DISTRIBUTED)
        )
        network_thread._conns[sock] = conn
        network_thread._append_outgoing_message = Mock(return_value=False)
        msg = DistribBranchLevel(3)
        msg.sock = sock

        network_thread._process_outgoing_messages([msg])

        network_thread._close_connection.assert_called_once_with(conn)

    def test_distributed_server_control_retry_after_local_output_failure(self):
        network_thread = self._create_network_thread()
        sock = MockSocket()
        network_thread._server_conn = ServerConnection(sock=sock)
        network_thread._conns[sock] = network_thread._server_conn
        network_thread._send_message_to_server = Mock(side_effect=[False, True])

        msg = AcceptChildren(True)
        self.assertFalse(network_thread._send_distributed_server_control_message(msg))

        self.assertEqual([msg], list(network_thread._distributed_server_control_retries))
        network_thread._process_distributed_server_control_retries()

        self.assertEqual([], list(network_thread._distributed_server_control_retries))
        self.assertEqual(2, network_thread._send_message_to_server.call_count)

    def test_distributed_server_control_retry_deduplicates_same_state(self):
        network_thread = self._create_network_thread()
        network_thread._send_message_to_server = Mock(return_value=False)

        network_thread._send_distributed_server_control_message(AcceptChildren(True))
        network_thread._send_distributed_server_control_message(AcceptChildren(True))
        network_thread._send_distributed_server_control_message(AcceptChildren(False))

        self.assertEqual(2, len(network_thread._distributed_server_control_retries))
        self.assertEqual(
            [(AcceptChildren, (True,)), (AcceptChildren, (False,))],
            [network_thread._get_distributed_server_control_retry_key(msg)
             for msg in network_thread._distributed_server_control_retries]
        )

    def test_child_capacity_update_queues_accept_children_retry_on_failure(self):
        network_thread = self._create_network_thread()
        network_thread._child_peers = {"child": object()}
        network_thread._max_distrib_children = 1
        network_thread._should_process_queue = True
        network_thread._send_message_to_server = Mock(return_value=False)

        NetworkThread._remove_child_peer_connection(network_thread, "child")

        self.assertEqual(1, len(network_thread._distributed_server_control_retries))
        retry_msg = network_thread._distributed_server_control_retries[0]
        self.assertIsInstance(retry_msg, AcceptChildren)
        self.assertTrue(retry_msg.enabled)

    def test_cant_connect_to_peer_retry_after_local_output_failure(self):
        network_thread = self._create_network_thread()
        network_thread._send_message_to_server = Mock(side_effect=[False, True])
        network_thread._server_conn = ServerConnection(sock=MockSocket())

        self.assertFalse(network_thread._send_cant_connect_to_peer(123, "peer"))

        self.assertEqual(1, len(network_thread._cant_connect_to_peer_retries))
        retry_msg = network_thread._cant_connect_to_peer_retries[0]
        self.assertIsInstance(retry_msg, CantConnectToPeer)
        self.assertEqual(123, retry_msg.token)
        self.assertEqual("peer", retry_msg.user)

        network_thread._process_cant_connect_to_peer_retries()

        self.assertEqual([], list(network_thread._cant_connect_to_peer_retries))
        self.assertEqual(2, network_thread._send_message_to_server.call_count)

    def test_cant_connect_to_peer_retry_deduplicates_same_token_and_user(self):
        network_thread = self._create_network_thread()
        network_thread._send_message_to_server = Mock(return_value=False)

        self.assertFalse(network_thread._send_cant_connect_to_peer(123, "peer"))
        self.assertFalse(network_thread._send_cant_connect_to_peer(123, "peer"))
        self.assertFalse(network_thread._send_cant_connect_to_peer(124, "peer"))

        self.assertEqual(2, len(network_thread._cant_connect_to_peer_retries))
        self.assertEqual(
            [(123, "peer"), (124, "peer")],
            [network_thread._get_cant_connect_to_peer_retry_key(msg)
             for msg in network_thread._cant_connect_to_peer_retries]
        )

    def test_unsent_cant_connect_to_peer_does_not_emit_main_thread_rollback(self):
        network_thread = self._create_network_thread()
        msg = CantConnectToPeer(321, "peer")
        fake_events = SimpleNamespace(emit_main_thread=Mock())

        with patch.object(slskproto_module, "events", fake_events):
            network_thread._handle_unsent_server_request(msg)

        self.assertEqual([msg], list(network_thread._cant_connect_to_peer_retries))
        fake_events.emit_main_thread.assert_not_called()

    def test_distributed_server_control_retries_clear_on_disconnect(self):
        network_thread = self._create_network_thread()
        network_thread._distributed_server_control_retries.append(AcceptChildren(True))
        network_thread._distributed_server_control_retry_keys.add((AcceptChildren, (True,)))
        network_thread._distributed_server_control_retry_limit_logged = True
        network_thread._selector = Mock()
        network_thread._listen_socket = None
        network_thread._portmapper = None
        network_thread._server_address = None
        network_thread._server_conn = None
        network_thread._pending_peer_conns = {}
        network_thread._pending_init_msgs = {}
        network_thread._username_init_msgs = {}
        network_thread._potential_parents = {}
        network_thread._parent_conn = None
        network_thread._child_peers = {}
        network_thread._conns = {}
        network_thread._check_indirect_request_timeouts = Mock()
        network_thread._close_connection = Mock()

        NetworkThread._server_disconnect(network_thread)

        self.assertFalse(network_thread._distributed_server_control_retries)
        self.assertFalse(network_thread._distributed_server_control_retry_keys)
        self.assertFalse(network_thread._distributed_server_control_retry_limit_logged)

    def test_duplicate_distributed_search_is_not_forwarded_to_children(self):
        network_thread = self._create_network_thread()
        msg = DistribSearch(search_username="peer", token=123, searchterm="term")

        self.assertTrue(network_thread._should_forward_distributed_search(msg, current_time=1000))
        self.assertFalse(network_thread._should_forward_distributed_search(msg, current_time=1001))

    def test_forwarded_distributed_search_ledger_expires_entries(self):
        network_thread = self._create_network_thread()
        msg = DistribSearch(search_username="peer", token=123, searchterm="term")

        self.assertTrue(network_thread._should_forward_distributed_search(msg, current_time=1000))
        self.assertTrue(network_thread._should_forward_distributed_search(
            msg, current_time=1000 + NetworkThread.FORWARDED_DISTRIBUTED_SEARCH_TTL + 1))

    def test_distributed_search_forwarding_ledger_drops_oldest_when_full(self):
        network_thread = self._create_network_thread()
        old_limit = NetworkThread.MAX_FORWARDED_DISTRIBUTED_SEARCHES
        NetworkThread.MAX_FORWARDED_DISTRIBUTED_SEARCHES = 1

        try:
            first = DistribSearch(search_username="peer1", token=1, searchterm="term")
            second = DistribSearch(search_username="peer2", token=2, searchterm="term")

            self.assertTrue(network_thread._should_forward_distributed_search(first, current_time=1000))
            self.assertTrue(network_thread._should_forward_distributed_search(second, current_time=1001))
            self.assertNotIn(("peer1", 1), network_thread._forwarded_distributed_searches)
            self.assertIn(("peer2", 2), network_thread._forwarded_distributed_searches)

        finally:
            NetworkThread.MAX_FORWARDED_DISTRIBUTED_SEARCHES = old_limit



class SoulseekNetworkTest(TestCase):

    def setUp(self):

        # Windows doesn't accept mock_socket in select() calls
        selectors.DefaultSelector = MagicMock()

        config.set_data_folder(DATA_FOLDER_PATH)
        config.set_config_file(os.path.join(DATA_FOLDER_PATH, "temp_config"))

        core.init_components(enabled_components={"network_thread"})

        config.sections["server"]["upnp"] = False
        core.start()
        events.emit("enable-message-queue")

        # Slight delay to allow the network thread to fully start
        sleep(SLSKPROTO_RUN_TIME / 2)

    def tearDown(self):

        core.quit()

        sleep(SLSKPROTO_RUN_TIME / 2)

        events.process_thread_events()

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(DATA_FOLDER_PATH)

    @patch("socket.socket")
    def test_server_conn(self, _mock_socket):

        core.send_message_to_network_thread(
            ServerConnect(addr=("0.0.0.0", 0), login=("dummy", "dummy"), listen_port=65525)
        )
        sleep(SLSKPROTO_RUN_TIME)

        # pylint: disable=no-member,protected-access
        sock = core._network_thread._server_conn.sock

        if hasattr(socket, "TCP_KEEPIDLE") or hasattr(socket, "TCP_KEEPALIVE"):
            if sys.platform == "win32":
                self.assertEqual(sock.setsockopt.call_count, 5)

            elif hasattr(socket, "TCP_USER_TIMEOUT"):
                self.assertEqual(sock.setsockopt.call_count, 7)

            else:
                self.assertEqual(sock.setsockopt.call_count, 6)

        elif hasattr(socket, "SIO_KEEPALIVE_VALS"):
            self.assertEqual(sock.ioctl.call_count, 1)
            self.assertEqual(sock.setsockopt.call_count, 2)

        self.assertEqual(sock.setblocking.call_count, 2)
        self.assertEqual(sock.connect_ex.call_count, 1)

    def test_login(self):

        core.send_message_to_network_thread(
            ServerConnect(addr=("0.0.0.0", 0), login=("dummy", "dummy"), listen_port=65525)
        )
        sleep(SLSKPROTO_RUN_TIME / 2)

        core.send_message_to_server(SetWaitPort(1))

        sleep(SLSKPROTO_RUN_TIME)
